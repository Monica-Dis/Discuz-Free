<?php

/**
 * yaoqing_robot For Discuz!X 2.0+
 * ============================================================================
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�ʹ�ã�
 * �������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
 * @package    index
 * @module	   tp_exam 
 * @date	     2013-7-25
 * @author	   gaotianpeng
 * @copyright  Copyright (c) 2012 yaoqing_robot Platform Inc. (http://www.fanzhuce.com)
 */

/*
//--------------Tall us what you think!----------------------------------
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	global $_G;

	$isMobile = checkmobile();
	if($isMobile){
		$url = $_SERVER['REQUEST_URI'];
		$rule  = "/tp_exam:index&mod=exam&item=([1-9])$/";  

		if(preg_match($rule,$url,$result))
		{
			header("Location: plugin.php?id=tpgao_m:m&mod=exam&item=".$result[1]);
		}
		else
			header("Location: plugin.php?id=tpgao_m:m");
			
		exit;
	}

	
	$config = array();
	$config = $_G['cache']['plugin']['tp_exam'];
	$opendiy = $config['opendiy'];
	$paper_show_number = $config['paper_show_number'];
	$list_style = $config['list_style'];
	$forcelogin = $config['forcelogin'];
	$exammode = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='opensingleexam'");
	$grouptips = $config['exam_paper_denid_tips'];

	$navtitle	= $config['navtitle'];
	$metakeywords	= $config['metakeywords'];
	$metadescription = $config['metadescription'];
	$closelogo = $config['closelogo'];
	$logourl = $config['logourl'];
	$openerrorbook = $config['openerrorbook'];


	//��ȡ������Ϣ
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_paper_func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam.rand.func.php";


	$_G['setting']['switchwidthauto'] = 0;
	$_G['setting']['allowwidthauto'] = 1;

	$type = GetExamType();
	$typeid = daddslashes($_GET['typeid']);
	if(empty($typeid)){
		$treecollaps = 'style="display:none"';
	}
	else{
		$treecollaps = 'style="display:none"';
		$treelevel = GetTreeLevelByTypeId($type,$typeid);
	}

	$tree=array(); //Ŀ¼��
	
	$html='';
	$pre_2=false;
	$pre_1=false;
	
	$_G['cookie']['cookie_cate'] = isset( $_G['cookie']['cookie_cate']) ? explode(';',  $_G['cookie']['cookie_cate']) : array();
	$type0 = C::t('#tp_exam#tp_exam_type')->fetch_all_by_sort(0);
	
	$tree = $type0;
	
	
	$line = '[';
	$children = 'children: [';

	foreach($type0 as $k=>$v)
	{
		$node = '{id:'.$v['id'].',name:"'.$v['name'].'",open:';
		$node .= in_array($v['id'],$_G['cookie']['cookie_cate'])?'true':'false';
		
		$line .= $node.",";
		
		
		if(hasChild($v['id'])){
			
			$l = getJson($v['id']);
			
			$tree[$v['id']]['subtype'] = getTree($v['id']);
			
			$line .= $l;
		}
		
		$line .= "},";
	}
	
	$line .= ',]';
	
	function getJson($id)
	{
		global $_G;

		$type = getTree($id);
		
		$children = 'children: [';
		
		foreach($type as $k=>$v){
			$node = '{id:'.$v['id'].',name:"'.$v['name'].'",open:';
	
			$node .= in_array($v['id'],$_G['cookie']['cookie_cate'])?'true':'false';

			$children .= $node;
			$children .= ',';
			
			if(hasChild($v['id'])){
				$l = getJson3($v['id']);
				
				$children .= $l;
				
				//echo '<br>'.$children.'<br>';
			}
		
			$children .= '},';
		}
		
		$children .= ']';

		return $children;
	}
	
	
	function getJson3($id){
		global $_G;

		$type = getTree($id);
		
		$children = 'children: [';
		
		foreach($type as $k=>$v){
			$node = '{id:'.$v['id'].',name:"'.$v['name'].'",open:';
	
			$node .= in_array($v['id'],$_G['cookie']['cookie_cate'])?'true':'false';

			$children .= $node;
			$children .= ',';
		
			$children .= '},';
		}
		
		$children .= ']';

		return $children;
	}
	

	foreach($type as $k=>$v)
	{
		$treecollaps = 'style="display:none"';
		
		if($v['treelevel'] == 0 )
		{
			if($pre_1)
			{
				$pre_1=false;
				$html.='</li></ul>';
			}
			if($pre_2)
			{
				$pre_2=false;
				$html.='';
			}

			$html.='<li class="tree_0"><a href="plugin.php?id=tp_exam:index&typeid='.$v['id'].'&shorturl='.$v[shorturl].'"> '.$v[name].'</a>';

		}
		else
		if($v['treelevel'] == 1)
		{
			$treecollaps = 'style="display:none"';
			
			if(!$pre_1)
				{$html .= '<ul>';}
			else
			if($pre_2)
			{
				$html .= '<ul>';
			}
			
			$pre_1=true;
			if($pre_2)
			{
				$html.='</li></ul>';
			}
			
			$pre_2=false;
			
			$ChildId = GetChild($type,$typeid);
			if($ChildId){
				
				if($v['parent'] == $typeid)
				{
					$treecollaps = '';
				}
			}
			
			$Parent = GetTypeParent($type,$ChildId);
			//�ڵ���һ��ID
			$TreePreId = GetTypePreId($type,$typeid);
			$TypePreTreeId = GetTypePreId($type,$v['id']);
			
			//��ʾͬ�����
			if( GetTypePreId($type,$v['id']) == $TreePreId ||
				GetTypePreId($type,$v['id']) == GetTypePreId($type,$TreePreId)){
				$treecollaps = '';
			}

			if($v['id'] == $TreePreId || $v['id'] == $typeid){
				$treecollaps = '';
			}
			if($TreePreId == $TypePreTreeId){
				$treecollaps = '';
			}
			if(GetChild($type,$v['id']) == $typeid && !empty($typeid)){
				$treecollaps = '';
			}
			$html.='<li class="tree_1" '.$treecollaps. '><a href="plugin.php?id=tp_exam:index&typeid='.$v[id].'"  > '.$v[name].'</a>';
		}
		else
		if($v['treelevel'] == 2)
		{
			$treecollaps = 'style="display:none"';
			$pre_2=true;
			
			if(GetChild($type,$typeid)){

				if($v['parent'] == $typeid)
				{
					$treecollaps = '';
				}
			}
			
			if($v['id'] == $typeid){
				$treecollaps = '';
			}
			
			$TreePreId = GetTypePreId($type,$typeid);
			$TypePreTreeId = GetTypePreId($type,$v['id']);
			//��ʾͬ�����
			if( GetTypePreId($type,$v['id']) == $TreePreId ||
				GetTypePreId($type,$v['id']) == GetTypePreId($type,$TreePreId)){
				$treecollaps = '';
			}
			
			$html.='<ul><li class="tree_2" '.$treecollaps. '><a href="plugin.php?id=tp_exam:index&typeid='.$v[id].'"> '.$v[name].'</a></li></ul>';
		}
		
	}

	$timu = GetExamTimu();
	//$paper = GetPaperType();
	$timu_count = count($timu) - 1;

 $mod = daddslashes($_GET['mod']);
 
if($mod == 'login')
{
		$config = array();
		$config = $_G['cache']['plugin']['tp_exam'];
		
	$item = daddslashes($_GET['item']);
	$examName  = GetExamName($item);
	$exam_info = $config['exam_info'];
	
	$verify = GetVerifyItem();
	
	//������ͼ
	include template('tp_exam:main');
}
else
if($mod == 'list' || $mod == '')
{

		$typeid = intval($_GET['typeid']);
		$shorturl = daddslashes($_GET['shorturl']);
		$st = daddslashes($_GET['st']);
		$payment = intval($_GET['payment']);
		
		if(empty($st)) $st = $list_style;

		//��ҳ��Ϣ
		$perpage = $paper_show_number;

		$page = max(1, intval(daddslashes($_GET['page'])));
		$listStart = ($page-1) *$perpage;
		$listEnd = $page*$perpage;

		$where = '';
		$count = $totalnum;
		$ChildId = GetChildTypeIdArray($typeid);
			
		if($typeid == 0) {
			$paper = C::t('#tp_exam#tp_exam_paper#')->fetch_all_paper($listStart,$perpage,$payment);
			$totalnum = C::t('#tp_exam#tp_exam_paper#')->fetch_count($payment);
			$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 
			$multi = multi($totalnum, $perpage, $page, multi_link($typeid,$payment),$pagecount);
		}
		else{
			$paper = C::t('#tp_exam#tp_exam_paper#')->get_paper_by_typeidarr($ChildId,$listStart,$perpage,$payment);
			$totalnum = C::t('#tp_exam#tp_exam_paper#')->fetch_count_by_typeid($ChildId,$payment);
			$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 
			$multi = multi($totalnum, $perpage, $page, multi_link($typeid,$payment) ,$pagecount);
		}

		$PaperScore = GetPaperItemScore($paper);

	
		$template = 'list';
		if($list_style == 3) {
			$template = '101test/101test';
			$tree3 = getTree($typeid);
			$tree3_title = GetNameParent($typeid);
			$tree_level =  tree_level($typeid);
			$tree_name = gettypeidname($typeid);
		}
		
		if($opendiy)
		{
			include template("diy:tp_exam/$template");
		}
		else
		{
			include template("tp_exam:$template");
		}
		
}
else
if($mod == 'exam')
{
	$verifyid = intval($_GET['v']);
	
		//�ж��û��Ƿ��¼
	if(!$_G['uid'] && $forcelogin){
		$exam_must_login_tips=lang('plugin/tp_exam', 'exam_must_login_tips');
		showmessage($exam_must_login_tips, NULL, array(), array('login' => 1));
	}
	
	$admin_exam_exam_timer_leave_tips=lang('plugin/tp_exam', 'admin_exam_exam_timer_leave_tips');
	$admin_exam_exam_timer_leave_min_tips=lang('plugin/tp_exam', 'admin_exam_exam_timer_leave_min_tips');
	$admin_exam_exam_timer_leave_sec_tips=lang('plugin/tp_exam', 'admin_exam_exam_timer_leave_sec_tips');
	$low_credit_tip=lang('plugin/tpgao_questionsyn', 'low_credit_tip');
	
	$exam_common_null=lang('plugin/tp_exam', 'exam_common_null');
	
	$item = daddslashes($_GET['item']);
	$TimerEvent = 1;
	$randmod = GetRandMode($item);
	
	if(!$randmod)
	{
		$danxuan = GetDaXuanByPaperID($item);
		$duoxuan = GetDuoXuanByPaperID($item);
		$panduan = GetPanDuanByPaperID($item);
		$tiankong = GetTiankongByPaperID($item);
		//�������Ҫ�ദ��һ�������������Ŀ
		$tiankong_ask = GetTiankongAsk($tiankong);
		
		//�Ķ�������Ҫ��������ά�֣�����һһ��Ӧ
		$Yuedulijie = GetYuedulijieByPaperID($item);
		$y_danxuan=GetYuedulijie_SingleByPaperID($item);
		$y_duoxuan=GetYuedulijie_MultiByPaperID($item);
		$y_panduan=GetYuedulijie_PanduanByPaperID($item);
		$y_tiankong=GetYuedulijie_TiankongByPaperID($item);
		$y_tiankong=y_GetTiankongAsk($y_tiankong);
		$y_wenda=GetYuedulijie_WendaByPaperID($item);


		//������
		$Peiwu = GetPeiwuByPaperID($item);
		$p_danxuan = GetPeiwu_SingleByPaperId($item);

		$wenda = GetWendaByPaperID($item);

	}
	else
	{
		/*
		$total_number = $randmod;
		$maxitem=array();
		$max=array();
		$maxitem[0] = GetDanxuanCount($item);
		$maxitem[1] = GetDuoxuanCount($item);
		$maxitem[2] = GetPanduanCount($item);
		$maxitem[3] = GetTiankongCount($item);
		$maxitem[4] = GetWendaCount($item);
	
		$min=array(0,0,0,0,0);
		$randomnumber = 5;
		*/
		
		$needrandom=array();
		$skey = DB::result_first("SELECT random_item FROM ".DB::table('tpexam_paper')." where id='$item'");
		$random_arr = explode(",",$skey);
		
		/*
		if($random_arr[0] == -1 &&
		$random_arr[1] == -1 &&
		$random_arr[2] == -1 &&
		$random_arr[3] == -1 &&
		$random_arr[4] == -1 ){
			
			$tiku_num = GetRandomByTotal($min,$maxitem,$randmod,5);

		}else{
			foreach($random_arr as $k=>$v){
				if($v==-1)
					$tiku_num[$k] = 0;
				else
					$tiku_num[$k] = $v;
			}
		}
		*/

	if(empty($tiku_num[0])) {
			$tiku_num[0] = 0;
		}
		$danxuan = GetDaXuanByRand($item,$random_arr[0]);
		if(empty($tiku_num[1])) {
			$tiku_num[1] = 0;
		}
		$duoxuan = GetDuoXuanByRand($item,$random_arr[1]);
		if(empty($tiku_num[2])) {
			$tiku_num[2] = 0;
		}
		$panduan = GetPanduanByRand($item,$random_arr[2]);
		if(empty($tiku_num[3])) {
			$tiku_num[3] = 0;
		}
		$tiankong = GetTiankongByRand($item,$random_arr[3]);
		$tiankong_ask = GetTiankongAsk($tiankong);

		if(empty($tiku_num[4])) {
			$tiku_num[4] = 0;
		}
		$wenda = GetWendaByRand($item,$random_arr[4]);

	}

	$exam = GetExamByPaperID($item);
	$needlogin = GetNeedLogin($item);
	$needPractise = GetNeedPractise($item);
	$needpay = GetNeedPay($item);
	$paper_no_pause = DB::result_first("SELECT paper_no_pause FROM ".DB::table('tpexam_paper')." where id='$item'");

	//�ж��Ƿ��շ�
	if($needpay)
	{
		header("Location: plugin.php?id=tp_exam:pay&needpay=$item");
	}
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/paper_permission.php";
	$permission = new paper_permission;
	$permission->setlang(array('group'=>$grouptips));
	$permission->permissioncheck($_G['uid'],$item);
			
		
//	�ж��Ƿ���Ҫ��֤����ʱ��
	$ret = CheckOnlinetime($_G['uid'],$item);
	if(!$ret['oltime'])
	{
		showmessage($ret['moduletips']);
	}
	
	

			
	$question_config = $_G['cache']['plugin']['tpgao_questionsyn'];
	$questionsyn = $question_config['start'];
	
	$uid = $_G['uid'];
	$cookie = "tpexam_login_".$item."_".$uid;
	$logined = $_COOKIE[$cookie];

	$showanswer = GetPaperShowAnswer($item);
	$PaperInfo = GetPaperInfo($item);
	$paper_item_timu_desc_arr = GetPaperItemTimuDesc($item);
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='nocopy'");
	$nocopy = $skey['nocopy'];
	$examtime = $exam['papertime'];
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/paperctrl.inc.php";

	setcookie($cookie,'false', time()+3600);
	include template('tp_exam:exam');
		

}else
if($mod == 'comb')
{
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/comb.func.inc.php";
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/app/comb.inc.php";
}



function GetVerifyItem()
{
	$ret = array();
	$item = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify')." where id = 1");
	
	
	$admin_tuan_verify_name = lang('plugin/tp_exam', 'admin_tuan_verify_name');
	$admin_tuan_verify_belongcompany = lang('plugin/tp_exam', 'admin_tuan_verify_belongcompany');
	$admin_tuan_verify_idcard = lang('plugin/tp_exam', 'admin_tuan_verify_idcard');
	$admin_tuan_verify_studentid = lang('plugin/tp_exam', 'admin_tuan_verify_studentid');
	
	if($data = DB::fetch($query))
	{
		if($data['name']) {$item['desc'] = $admin_tuan_verify_name;$item['type']= 1;$ret[]=$item;}
		
		if($data['company']) {$item['desc'] = $admin_tuan_verify_belongcompany;$item['type']= 2;$ret[]=$item;}
		
		if($data['idcard']) {$item['desc'] = $admin_tuan_verify_idcard;$item['type']= 3;$ret[]=$item;}
		
		if($data['student_id']) {$item['desc'] = $admin_tuan_verify_studentid;$item['type']= 4;$ret[]=$item;}
		
		
		return $ret;
	}
	
	return $ret;
}
function GetTreeLevelByTypeId($type,$typeid){

		if(GetTypeParent($type,$typeid) == 0) return 0;
		else if(GetChild($type,$typeid)) return 1;
		else return 2;

}

function GetChild($type,$typeid){

	$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where parent = '$typeid'");
	while($data = DB::fetch($query))
	{
		return $data['id'];
	}
	return 0;

}

function GetTypePreId($type,$typeid){

	$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where id = '$typeid'");
	while($data = DB::fetch($query))
	{
		return $data['parent'];
	}

	return 0;
}

function GetTypeParent($type,$typeid){

	$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where id = '$typeid'");
	while($data = DB::fetch($query))
	{
		return $data['parent'];
	}
	return 0;

}

function GetNameParent($typeid){

	$pid = GetTypeParent($typeid,$typeid);
	
	$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where id = '$pid'");
	while($data = DB::fetch($query))
	{
		return $data['name'];
	}
	
	return 0;

}

function GetChildTypeIdArray($typeid){
	
	$idarr=array();
	
	
	
	//����1��
	$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where parent = '$typeid'");
	while($data = DB::fetch($query))
	{
		$idarr[]=$data['id'];
	}

	if(count($idarr)>0){
		$idlist = implode(",",$idarr);

		//����2��
		$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where parent  IN ($idlist) ");
		while($data = DB::fetch($query))
		{
			$idarr[]=$data['id'];
		}
	}
	
	$idarr[]=$typeid;
	
	return $idarr;
}

function hasChild($tid)
{
	$query = DB::query("select * from ".DB::table('tpexam_type')." where parent = $tid");
	$d = DB::fetch($query);
	return is_array($d);
}

function getTree($tid)
{
	$tree=array();
	$query = DB::query("select * from ".DB::table('tpexam_type')." where parent = $tid order by sort asc");
	while($d = DB::fetch($query))
	{
		$d['subtype'] = getTree($d['id']);
		$tree[]=$d;
	}
	return $tree;
}

function tree_level($typeid)
{
	$query = DB::query("select * from ".DB::table('tpexam_type')." where id = '$typeid'");
	if($d = DB::fetch($query))
	{
		return $d['parent'];
	}
}

function multi_link($typeid,$payment)
{
	$link = 'plugin.php?id=tp_exam:index';
	
	if($typeid > 0){
		$link .= "&typeid=$typeid";
	}
	
	if($payment > 0){
		$link .= "&payment=$payment";
	}
	
	return $link;
}

function gettypeidname($typeid){
	$query = DB::query("select * from ".DB::table('tpexam_type')." where id = '$typeid'");
	if($d = DB::fetch($query))
	{
		return $d['name'];
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>
