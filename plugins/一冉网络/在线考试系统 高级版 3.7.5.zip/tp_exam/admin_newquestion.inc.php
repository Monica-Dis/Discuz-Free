<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

date_default_timezone_set('PRC'); 
ini_set('date.timezone','Asia/Shanghai');

//��ȡ������Ϣ
$edit = trim($_GET['edit']);
$type = trim($_GET['type']);

require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	
if(!submitcheck('submit')) {

	$paper = GetPaperType();
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='support_g'");
	$support_g = $skey['support_g'];

	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='yuedulijie'");
	$yuedulijie = $skey['yuedulijie'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='peiwu'");
	$peiwu = $skey['peiwu'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='upload_img'");
	$upload_img = $skey['upload_img'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='upload_audio'");
	$upload_audio = $skey;
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='upload_video'");
	$upload_video = $skey;
	
	//��ȡ����
	$default = $paper[0]['id'];
	if($default > 0){
		
		$usegroups = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='usegroups'");
		$papergroups = array();
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_groups')." where paperid = $default order by id desc");
		while($d = DB::fetch($query))
		{
			$papergroups[]=$d;
		}
	}

	
	//�Ķ���������
	if($default > 0){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_yuedulijie')." where belong_paper='$default' order by id desc");
		while($timu = DB::fetch($query))
		{
			$yuedulijie_arr[]=$timu;
		}
	}
	
	$admin_pub_type6 = lang('plugin/tp_exam', 'admin_pub_type6');
	$formhash = formhash();
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/admin_list.php";
}
else
{
	$timu_type = daddslashes($_GET['timutype']);
	$nickname = daddslashes($_GET['nickname']);
	$content = daddslashes($_GET['content']);
	
	$image_path = daddslashes($_GET['image_path']);
	$parser_image_path = daddslashes($_GET['parser_image_path']);
	
	$audio_path = daddslashes($_GET['audio_path']);
	$video_path = daddslashes($_GET['video_path']);
	$useqbank = dintval($_GET['useqbank']);
	
	/*image*/
	if(empty($image_path))
	{
		$image = daddslashes($_GET['image']);
		if($_FILES['image']['error'] !== 0 && !empty($_FILES['image']['name'])) {
			cpmsg('File Not Exist');
		}
	
		if(!empty($_FILES['image']['name']) && !in_array(strtolower(fileext($_FILES['image']['name'])), array('jpg', 'gif', 'png'))) {
			cpmsg('File Ext Error');
		}
		$upload = new discuz_upload();
		if($upload->init($_FILES['image'], 'forum') && $upload->save(1)) {
			$imageurl = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
		}
	}
	else
	{
		$imageurl = $image_path;
	}
	/*image end*/

	/*parser image*/
	if(empty($parser_image_path))
	{
		$parser_image = daddslashes($_GET['parser_image']);
		if($_FILES['parser_image']['error'] !== 0 && !empty($_FILES['parser_image']['name'])) {
			cpmsg('File Not Exist');
		}
	
		if(!empty($_FILES['parser_image']['name']) && !in_array(strtolower(fileext($_FILES['parser_image']['name'])), array('jpg', 'gif', 'png'))) {
			cpmsg('File Ext Error');
		}
		$upload = new discuz_upload();
		if($upload->init($_FILES['parser_image'], 'forum') && $upload->save(1)) {
			$parser_imageurl = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'forum/'.$upload->attach['attachment'];
		}
	}
	else
	{
		$parser_imageurl = $parser_image_path;
	}
	
	/*image end*/
	
	/*audio*/
	if(empty($audio_path))
	{
		$image = daddslashes($_GET['audio']);
		if($_FILES['audio']['error'] !== 0 && !empty($_FILES['audio']['name'])) {
			cpmsg('File Not Exist');
		}
	
		if(!empty($_FILES['audio']['name']) && !in_array(strtolower(fileext($_FILES['audio']['name'])), array('mp3', 'wav', 'wmv'))) {
			cpmsg('audio File Ext Error');
		}
		$upload = new discuz_upload();
		if($upload->init($_FILES['audio'], 'common') && $upload->save(1)) {
			$audiourl = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		}
	}
	else
	{
		$audiourl = $audio_path;
	}
	/*audio end*/
	/*video*/
	if(empty($video_path))
	{
		$image = daddslashes($_GET['video']);
		if($_FILES['video']['error'] !== 0 && !empty($_FILES['video']['name'])) {
			cpmsg('File Not Exist');
		}
	
		if(!empty($_FILES['video']['name']) && !in_array(strtolower(fileext($_FILES['video']['name'])), array('mpg', 'wmv', 'avi','flv','mp4','swf'))) {
			cpmsg('video File Ext Error');
		}
		$upload = new discuz_upload();
		if($upload->init($_FILES['video'], 'common') && $upload->save(1)) {
			$videourl = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
		}
	}
	else
	{
		 $videourl=$video_path;
	}
	/*video end*/
	
	//����������鷢������ֱ�ӽ�tpexam_tiku
	$usegroups = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='usegroups'");
	if($usegroups){
		
		//require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_tiku.php";
//		cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_newquestion', 'succeed');

	}
	
	//�ж��ǲ���ʹ�����¼��
	if($useqbank){
		$xuhao = dintval($_GET['xuhao']);
		if($xuhao > 0){
			require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/useqbank.inc.php";
			cpmsg('&#x6210;&#x529F;&#x63D0;&#x53D6;&#x9898;&#x5E93;&#x6570;&#x636E;'.$xuhao, 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_newquestion', 'succeed');	
		}else{
			cpmsg('&#x6CA1;&#x6709;&#x8BE5;&#x9898;&#x5E93;&#x5E8F;&#x53F7;', 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_newquestion', 'succeed');	
		}
		
	}
	switch($timu_type)
	{
		case 0:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/single_select.inc.php";
		break;
		case 1:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/multi_select.inc.php";
		break;
		case 2:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/panduan.inc.php";
		break;
		case 3:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/wenda.inc.php";
		break;
		case 4:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tiankong.inc.php";
		break;
		case 5:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/yuedulijie.inc.php";
		break;
		case 6:
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/peiwu.inc.php";
		break;				
	}


	$newids = array();
	$delarr = daddslashes($_GET['delete']);
	foreach($delarr as $id) {
		$newids[] = intval($id);
	}
	
	if($ids = dimplode($newids)) {
		DB::delete('tpexam_timu', "id IN($ids)");
		
		cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_newquestion', 'succeed');
	}
		

	cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_newquestion', 'succeed');
}
//From: di'.'sm.t'.'aoba'.'o.com
?>