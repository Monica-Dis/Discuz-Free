<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: test.php 33234 2013-12-20 22:59:14Z mpage $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$vars = $_G['cache']['plugin']['tp_exam'];
loadcache('dzapp_home_nav');

dsetcookie('mobile', '2');

	$page = intval($_G['page']);
	if(empty($page)) $page=1;
	
	//$pagenum = 4;
	//$limit_start = $pagenum * ($page - 1);
	//$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_examrecord')." where uid = '$_G[uid]'");

	$list = array();
	//$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." Order By id DESC LIMIT $limit_start,$pagenum");
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." Order By id DESC");
	while($row = DB::fetch($query)){
		$row['name'] = $row['name'];
		$row['papertime'] = $row['papertime'];
		$row['needlogin'] = $row['needlogin'];
		$row['needpay'] = $row['needpay'];
		$list[] = $row;
	}
	
	//$multi = multi($totalnum, $pagenum, $page, "plugin.php?id=tp_tuangou:my&filter={$filter}");
	
	include template('tp_exam:mobile_home');

?>