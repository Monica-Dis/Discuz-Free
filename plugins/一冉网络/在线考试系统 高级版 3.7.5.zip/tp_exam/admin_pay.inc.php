<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";

$payment = GetPaymentInfo();

$unseri_pay = unserialize($payment['svalue']);

if(!submitcheck('submit')) {
		$query = DB::query("SELECT svalue FROM ".DB::table("tpexam_setting")." WHERE skey = 'pay'");
		$seri_pay = DB::fetch($query);

		$payment = unserialize($seri_pay['svalue']);
	
	include_once template('tp_exam:admin_pay');
	
}else if(submitcheck('submit')){
	
		$success = lang('plugin/tp_exam', 'admin_common_success');
		$alipayid = daddslashes($_POST['alipayid']);
		$alipaykey = daddslashes($_POST['alipaykey']);
		$alipayuser = daddslashes($_POST['alipayuser']);
		$alipaytype = daddslashes($_POST['alipaytype']);
		
		if($alipaytype == 3)
		{
			writeconfig(3,$alipayid,$alipaykey);
		}
		else
		if($alipaytype == 2)
		{
			writeconfig(2,$alipayid,$alipaykey);
		}
		
		$payment = array('alipayid'=>$alipayid,
		'alipaykey'=>$alipaykey,
		'alipayuser'=>$alipayuser,
		'alipaytype'=>$alipaytype
		);
				
			$seri_pay = serialize($payment);
				
			DB::update('tpexam_setting', array(
			'svalue'=>$seri_pay
			), "skey='pay'");	
		

		
	  cpmsg($success, "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam", 'succeed');
}

/*
1 ����
2 ����
3 ˫�ӿ�
*/
function writeconfig($type,$id,$key)
{
	$DOCUMENT_ROOT = DISCUZ_ROOT; 
	
	if($type == 3)
	{
		$file = "$DOCUMENT_ROOT/source/plugin/tp_exam/payment/alipaydual/config.php";
	}
	else
	if($type == 2)
	{
		$file = "$DOCUMENT_ROOT/source/plugin/tp_exam/payment/alipaysubmit/config.php";
	}
	if (file_exists($file))
	{
		@unlink($file);
	}
	
	if (!file_exists($file)) { //ע�����վ���ʵ��·�� 
	$fp = fopen($file,'ab'); //�Զ�����׷�ӷ�ʽ���ļ�,û�ļ��ʹ��� 

	$content = "<?php\r\n\$alipay_config['partner']='".$id."';\r\n\$alipay_config['key']='".$key."';\r\n?>";
	fwrite($fp, $content, strlen($content)); //�����һ����¼ 
	fclose($fp); //�ر��ļ� 
	}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>