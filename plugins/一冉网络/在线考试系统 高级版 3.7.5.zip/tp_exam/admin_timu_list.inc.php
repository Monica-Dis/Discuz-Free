<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$item = trim($_GET['del']);
$edititem = trim($_GET['edit']);
$type = trim($_GET['type']);

$app = daddslashes($_GET['app']);

$app = in_array($app, array('dan', 'duo', 'pan', 'tian', 'wen')) ? $app : 'all';


require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';

if(!submitcheck('submit') && !submitcheck('export') && empty($item) && empty($edititem)) {

$atcives[$app] = ' class="active"';

	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	$admin_pub_type6 = lang('plugin/tp_exam', 'admin_pub_type6');
	$admin_pub_type7 = lang('plugin/tp_exam', 'admin_pub_type7');
	$admin_type_all = lang('plugin/tp_exam', 'admin_type_all');


$ukey = daddslashes($_GET['ukey']);
$perpage = 20;
$start = ($page-1)*$perpage;
$mpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_timu_list';

showformheader('plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_timu_list');
$html = <<<EOF
<div style="float:left;padding-top:5px;padding-bottom:5px;">
<input type="hidden" name="id"  value="index">
<input type="hidden" name="FORMHASH" value="{FORMHASH}">
<div class="m_fr tuansearch">&#x641C;&#x7D22;&#x9898;&#x5E93; <input type="text" size="50" name="ukey"> 
	<select name="searchtype">
	<option value="0">&#x6309;&#x9898;&#x76EE;</option>
	<option value="1">&#x6309;&#x8BD5;&#x5377;</option>
	</select> 
	<input type="submit" class="plr5 pn pnc" name="searchsubmit" id="editsubmit" value="&#x641C;&#x7D22;">
</div>
</div>
EOF;
    
echo $html;
showformfooter(); /*dism��taobao��com*/
showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/

if(!empty($ukey)){
	$searchtype = dintval($_GET['searchtype']);
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/app/admin_timu_list_search.php";
	exit;
}

showtabcss();	
showtableheader('','tp_tuan_tb');
showtablerow('', array(''), 
array('<div class="tp_tuan_tab tp_tuan_min"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_timu_list&app=all" '.$atcives['all'].'><i></i><ins></ins>'.$admin_type_all.'</a>
																						<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_timu_list&app=dan" '.$atcives['dan'].'><i></i><ins></ins>'.$admin_pub_type1.'</a>
																						<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_timu_list&app=duo" '.$atcives['duo'].'><i></i><ins></ins>'.$admin_pub_type2.'</a>
																						<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_timu_list&app=pan" '.$atcives['pan'].'><i></i><ins></ins>'.$admin_pub_type3.'</a>
																						<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_timu_list&app=tian" '.$atcives['tian'].'><i></i><ins></ins>'.$admin_pub_type5.'</a>
																						<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_timu_list&app=wen" '.$atcives['wen'].'><i></i><ins></ins>'.$admin_pub_type4.'</a></div>'));

showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/

require_once DISCUZ_ROOT."./source/plugin/tp_exam/app/admin_timu_list_{$app}.php";

	
}elseif(submitcheck('export')){
	$fetch = DB::fetch_all("SELECT * FROM ".DB::table('tpexam_tiku')." ORDER BY ID DESC");
	include_once DISCUZ_ROOT."./source/plugin/tp_exam/module/module_word.inc.php";
	$word=new Word();
	$word->start();
	$data = '';
	foreach($fetch as $key =>$val){
		$data .= '��Ŀ:'.$val['subject'].'<br>';
		$tid = dintval($val['tid']);

		if($tid == 1){
			$data .= ext_danxuan($val);
		}elseif($tid == 2){
			$data .= ext_duoxuan($val);
		}elseif($tid == 3){
			$data .= ext_panduan($val);
		}elseif($tid == 4){
			$data .= ext_tiankong($val);
		}elseif($tid == 5){
			$data .= ext_wenda($val);
		}

		$data .= '<br>';
	}
	echo $data;
	$word->save("data.doc");//����word���ҽ���.
	cpmsg('&#x9898;&#x5E93;&#x5DF2;&#x7ECF;&#x5BFC;&#x51FA;', 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_timu_list', 'succeed');
}elseif(!empty($item))
{

	//ɾ����Ӧ�����
	switch($type)
	{
		case 'danxuan':
		DB::delete('tpexam_tiku_danxuan', "id IN($item)");
		break;
		case 'duoxuan':
		DB::delete('tpexam_tiku_duoxuan', "id IN($item)");
		break;
		case 'panduan':
		DB::delete('tpexam_tiku_panduan', "id IN($item)");
		break;
		case 'wenda':
		DB::delete('tpexam_tiku_wenda', "id IN($item)");
		break;
		case 'tiankong':
		DB::delete('tpexam_tiku_tiankong', "id IN($item)");
		break;
		case 'peiwu':
		DB::delete('tpexam_tiku_peiwu', "id IN($item)");
		break;
		case 'yuedu':
		DB::delete('tpexam_tiku_yuedulijie', "id IN($item)");
		break;
		case 'all':
		DB::query("TRUNCATE ".DB::table('tpexam_tiku_danxuan'));
		DB::query("TRUNCATE ".DB::table('tpexam_tiku_duoxuan'));
		DB::query("TRUNCATE ".DB::table('tpexam_tiku_panduan'));
		DB::query("TRUNCATE ".DB::table('tpexam_tiku_wenda'));
		DB::query("TRUNCATE ".DB::table('tpexam_tiku_tiankong'));
		break;
		
	}
	
	cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_timu_list', 'succeed');
}
elseif(empty($edititem))
{
		$newids = array();
		$delarr = daddslashes($_GET['delete']);
		foreach($delarr as $id=>$v) 
		{
			$typearr = explode("_",$v);
			$item = $typearr[0];
				switch($typearr[1])
				{
						case 'danxuan':
						DB::delete('tpexam_tiku_danxuan', "id IN($item)");
						DB::delete('tpexam_tiku', "tid=1 and oid IN($item)");
						break;
						case 'duoxuan':
						DB::delete('tpexam_tiku_duoxuan', "id IN($item)");
						DB::delete('tpexam_tiku', "tid=2 and oid IN($item)");
						break;
						case 'panduan':
						DB::delete('tpexam_tiku_panduan', "id IN($item)");
						DB::delete('tpexam_tiku', "tid=3 and oid IN($item)");
						break;
						case 'wenda':
						DB::delete('tpexam_tiku_wenda', "id IN($item)");
						DB::delete('tpexam_tiku', "tid=4 and oid IN($item)");
						break;
						case 'tiankong':
						DB::delete('tpexam_tiku_tiankong', "id IN($item)");
						DB::delete('tpexam_tiku', "tid=5 and oid IN($item)");
						break;
						case 'yuedu':
						DB::delete('tpexam_tiku_yuedulijie', "id IN($item)");
						DB::delete('tpexam_tiku', "tid=5 and oid IN($item)");
						break;
				}
		}

		cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_timu_list', 'succeed');

}


function GetTypeDesc($type,$type_arr)
{
	switch($type)
	{
		case 'danxuan':
			return $type_arr[0];
		break;
		case 'duoxuan':
			return $type_arr[1];
		break;
		case 'panduan':
			return $type_arr[2];
		break;
		case 'wenda':
			return $type_arr[3];
		break;
		case 'tiankong':
			return $type_arr[4];
		break;
		case 'yuedu':
			return $type_arr[5];
		case 'peiwu':
			return $type_arr[6];
	}
}

function GetTypeByTid($tid){
	switch($tid)
	{
		case 1:
			return 'danxuan';
		break;
		case 2:
			return 'duoxuan';
		break;
		case 3:
			return 'panduan';
		break;
		case 4:
			return 'tiankong';
		break;
		case 5:
			return 'wenda';
		break;
		case 'yuedu':
			return $type_arr[5];
		case 'peiwu':
			return $type_arr[6];
	}
}

if(!empty($edititem))
{
	require_once DISCUZ_ROOT.'./source/plugin/tp_exam/app/admin_timu_list_edit.inc.php';
}


function  GetPageList($tiKu,$totalnum, $listStart, $listEnd){

	if($listEnd > $totalnum){
		$listEnd = $totalnum;
	}
	for($i=$listStart;$i<$listEnd;$i++){
		GetSingleRow($tiKu,$i);
	}
}

function GetSingleRow($tiKu,$i){
		global $type_arr;
		$row = $tiKu[$i];

		global $admin_common_delete ;
		global $admin_common_edit ;
	
		$valarr = array();
		$valarr[] = "<input type='checkbox' name='delete[]' value='$row[id]_$row[type]'/>[ID:$row[eid]]";
		$valarr[] = GetTypeDesc($row['type'],$type_arr);
		$valarr[] = cutstr($row['ask'],30,"...");
		$valarr[] = GetPaperName($row['paper']);
		$valarr[] = $row['score'];
		$valarr[] = date('Y-m-d G:i:s',$row['data']);
		$valarr[] = $row['publish_uid'];
		$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&del=".$row['id']."&type=".$row['type']."\">".$admin_common_delete."</a>";
		$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_timu_list&edit=".$row['id']."&type=".$row['type']."\">".$admin_common_edit."</a>";
		showtablerow('id="td_'.$row['id'].'"', array('class="td45" style="width:120px;"','class="td35"', 'class="td35"','class="td35"','',''), $valarr);
}
//From: d'.'is'.'m.tao'.'ba'.'o.com
?>