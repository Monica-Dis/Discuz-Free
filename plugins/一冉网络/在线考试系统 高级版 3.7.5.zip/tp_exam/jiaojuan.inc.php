<?php

/**
 * yaoqing_robot For Discuz!X 2.0+
 * ============================================================================
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�ʹ�ã�
 * �������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
 * @package    jiaojuan
 * @module	   index 
 * @date	     2013-06-27
 * @author	   gaotianpeng
 * @copyright  Copyright (c) 2012 yaoqing_robot Platform Inc. (http://www.dxtm.net)
 */

/*
//--------------Tall us what you think!----------------------------------
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;

//��ȡ������Ϣ
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_paper_func.php";

$_G['setting']['switchwidthauto'] = 0;
$_G['setting']['allowwidthauto'] = 1;

$config = $_G['cache']['plugin']['tp_exam'];
$error_unshow = $config['error_unshow'];
$openreward = $config['openreward'];
$rewardcredit = $config['rewardcredit'];
$logourl = $config['logourl'];
$openerrorbook = $config['openerrorbook'];
	
$item = daddslashes($_POST['item']);
$exam_usetime = daddslashes($_POST['usetime']);

if(empty($item)){
	showmessage(lang('plugin/tp_exam', 'admin_session_timeout'), "plugin.php?id=tp_exam:index", 'succeed');
	die();
}

$total_score = 0;


$danxuan_a = daddslashes($_POST['s_answer']);
$duoxuan_a = daddslashes($_POST['m_answer']);
$panduan_a = daddslashes($_POST['p_answer']);
$tiankong_a = daddslashes($_POST['t_answer']);
$wenda_a = daddslashes($_POST['w_answer']);
$pwdan_a = daddslashes($_POST['pwd_answer']);  //���鵥ѡ���
$yuedu_answer_a = daddslashes($_POST['yuedu_answer']);
$peiwu_answer_a = daddslashes($_POST['peiwu_answer']);

$verifyid = intval($_POST['verifyid']);

//����������
$peiwu_jiaojuan_info = GetPeiwuJiaojuanInfo($peiwu_answer_a);
$total_peiwu_score = GetPeiwuScore($peiwu_jiaojuan_info);

if(daddslashes($_GET['mod']) == '')
{

//�Ķ�������Ҫ��������ά�֣�һ�����������࣬һ��������������ѡ�������飬����һһ��Ӧ
$Yuedulijie = GetYuedulijieByPaperID($item);
$Yuedulijie_single=GetYuedulijie_SingleByPaperID($item);

require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_random.func.php";
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/comb.func.inc.php";
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/include_papererrorbook.php";

$e = new paper_errorbook();
$e->paperid = $item;
$e->uid = $_G['uid'];

$id_arr_danxuan=array();
$danxuan_item=array();
foreach($danxuan_a as $k=>$v)
{
	$answer_danxuan = GetDanxuanAnswer_ById($k);

	$checkResult = checkDanxuanAnswer($v,$answer_danxuan);
	$danxuan_item['r']='W';
	$danxuan_item['id']=$k;
		
	if($checkResult['result'])
	{
		$danxuan_score += $checkResult['score'];
		$danxuan_item['r']='R';
	}
	$danxuan_item['parser']=$checkResult['parser'];
	$danxuan_item['needbuyparser']=$checkResult['needbuyparser'];
	$danxuan_item['parser']=$checkResult['parser'];
	$danxuan_item['daan']=$checkResult['daan'];
	$danxuan_item['type']=1;
	$id_arr_danxuan[]=$k;
	$adjust_danxuan[$k]=$danxuan_item;
	unset($danxuan_item);
}


//��ѡ�жϽ���


//��ѡ�жϿ�ʼ
$duoxuan_item=array();
$id_arr_duoxuan=array();

foreach($duoxuan_a as $k=>$v)
{
	$answer_duoxuan = GetDuoxuanAnswer_ById($k);
	//print_r($answer_duoxuan);
	
	$checkResult = checkDuoxuanAnswerScheme($item,$v,$answer_duoxuan);
	$duoxuan_item['r']='W';
	$duoxuan_item['id']=$k;
	
	//print_r($checkResult);
	if($checkResult['result'])
	{
		$duoxuan_item['r']='R';
	}
	
	$duoxuan_score += $checkResult['score'];
	$duoxuan_item['parser']=$checkResult['parser'];
	$duoxuan_item['needbuyparser']=$checkResult['needbuyparser'];
	$duoxuan_item['parser']=$checkResult['parser'];
	$duoxuan_item['daan']=$checkResult['daan'];
	$duoxuan_item['type']=2;
	$id_arr_duoxuan[]=$k;
	$adjust_duoxuan[$k]=$duoxuan_item;
	unset($duoxuan_item);
}

/*
	AddErrorDuoxuanToComb($adjust_duoxuan,$item);
	UpdateQuestionRecord($adjust_duoxuan,2,$_G['uid'],$item);
	*/

//��ѡ�жϽ���

//�ж��⿪ʼ
$panduan_item=array();
$id_arr_panduan=array();
foreach($panduan_a as $k=>$v)
{
	$answer_panduan = GetPanduanAnswer_ById($k);
	
	$checkResult = checkPanduanAnswer($v,$answer_panduan);
	$panduan_item['r']='W';
	$panduan_item['id']=$k;
		
	if($checkResult['result'])
	{
		$panduan_score += $checkResult['score'];
		$panduan_item['r']='R';
	}
	$panduan_item['parser']=$checkResult['parser'];
	$panduan_item['needbuyparser']=$checkResult['needbuyparser'];
	$panduan_item['parser']=$checkResult['parser'];
	$panduan_item['daan']=$checkResult['daan'];
	$panduan_item['type']=3;
	$id_arr_panduan[]=$k;
	$adjust_panduan[$k]=$panduan_item;
	unset($panduan_item);
}
/*
AddErrorPanduanToComb($adjust_panduan,$item);
UpdateQuestionRecord($adjust_panduan,3,$_G['uid'],$item);
*/

//�ж������

//����⿪ʼ
$tiankong_item=array();
$id_arr_tiankong=array();


foreach($tiankong_a as $k=>$v)
{
	$answer_tiankong = GetTiankongAnswer_ById($k);
	$checkResult = checkTiankongAnswer($v,$answer_tiankong);
	

	$tiankong_item['r']='W';
	$tiankong_item['id']=$k;
		
	if($checkResult['result'])
	{
		$tiankong_score += $checkResult['score'];
		$tiankong_item['r']='R';
	}
	$tiankong_item['parser']=$checkResult['parser'];
	$tiankong_item['needbuyparser']=$checkResult['needbuyparser'];
	$tiankong_item['parser']=$checkResult['parser'];
	$tiankong_item['daan']=$checkResult['daan'];
	$tiankong_item['type']=4;
	$id_arr_tiankong[]=$k;
	$adjust_tiankong[$k]=$tiankong_item;
	unset($tiankong_item);
}

//��������

//�ʴ��⿪ʼ
$wenda_item=array();
$id_arr_wenda=array();
foreach($wenda_a as $k=>$v)
{
	$answer_wenda = GetWendaAnswer_ById($k);
	$wenda_item['id']=$k;
	$wenda_item['parser']=$answer_wenda['answer_parser'];
	$wenda_item['daan']=$answer_wenda['answer'];
	$wenda_item['usranswer']=$wenda_a[$k];
	$wenda_item['type']=5;
	$id_arr_wenda[]=$k;

	$adjust_wenda[$k]=$wenda_item;
	unset($wenda_item);
}
/*
//�ʴ������
*/

if($openerrorbook){
$e->paper_addbygroup($adjust_danxuan);
$e->paper_addbygroup($adjust_duoxuan);
$e->paper_addbygroup($adjust_panduan);
$e->paper_addbygroup($adjust_tiankong);
$e->paper_addbygroup($adjust_wenda);
}

//��������
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/comment.inc.php";
$question_config = $_G['cache']['plugin']['tpgao_questionsyn'];
$questionsyn = $question_config['start'];
	
$randmod = GetRandMode($item);

if($randmod){
	$Peiwu=array();
}

$danxuan = GetDaXuanByItemArray($id_arr_danxuan);
$duoxuan = GetDuoXuanByItemArray($id_arr_duoxuan);	
$panduan = GetPanduanByItemArray($id_arr_panduan);
$tiankong = GetTiankongByItemArray($id_arr_tiankong);
$wenda = GetWendaByItemArray($id_arr_wenda);
//�������Ҫ�ദ��һ�������������Ŀ
$tiankong_ask = GetTiankongAsk($tiankong,$tiankong_a);


//$panduan_answer = GetAnswerByPaperID_PanDuan($item,$panduan_a);
//$panduan_score =  GetScore_PanDuan($panduan_answer);
//$tiankong_answer = GetAnswerByPaperID_Tiankong($item,$tiankong_a);
//$tiankong_score =  GetScore_Tiankong($tiankong_answer);

//�Ķ�������Ҫ��������ά�֣�һ�����������࣬һ��������������ѡ�������飬����һһ��Ӧ
$Yuedulijie = GetYuedulijieByPaperID($item);
$y_danxuan=GetYuedulijie_SingleByPaperID($item);
$y_duoxuan=GetYuedulijie_MultiByPaperID($item);
$y_panduan=GetYuedulijie_PanduanByPaperID($item);
$y_tiankong=GetYuedulijie_TiankongByPaperID($item);
$y_tiankong = y_GetTiankongAsk($y_tiankong,$tiankong_a);

$y_wenda=GetYuedulijie_WendaByPaperID($item);
		
//$yuedulijie_list_answer = GetAnswerByPaperID_Yuedulijie($item,$yuedu_answer_a);//�Ķ�����������ѡ����
$yuedulijie_list_score = GetScore_Yuedulijie($yuedulijie_list_answer);//�Ķ�����������ѡ����

//������
$Peiwu = GetPeiwuByPaperID($item);
$p_danxuan = GetPeiwu_SingleByPaperId($item);



//�����Ǹ���ID���жϣ������������ID�Ű���ж�
//$adjust_panduan = panduan_answer_adjust($panduan,$panduan_answer);
//$adjust_tiankong = tiankong_answer_adjust($tiankong,$tiankong_answer);

$adjust_yuedulijie = yuedulijie_answer_adjust($Yuedulijie_single,$yuedulijie_list_answer);

//��ȡ�Ƿ���ʾ��
$showanswer = GetPaperShowAnswer($item);

$PaperInfo = GetPaperInfo($item);

$jiaojuan = true;

$admin_exam_exam_timer_leave_min_tips = 	$admin_common_op = lang('plugin/tp_exam', 'admin_exam_exam_timer_leave_min_tips');

$total_score = $danxuan_score + $duoxuan_score + $panduan_score + $tiankong_score + $yuedulijie_list_score + $peiwu_score;;

$uid = $_G['uid'];
$nextpaper = GetNextPaper($item);

date_default_timezone_set('PRC');

$recordid = submit_record($uid,$item,$exam_usetime,time(),$total_score);

require_once libfile('include/paperrecord','plugin/tp_exam');
//saveuseranswer($danxuan_a,$duoxuan_a,$panduan_a,$tiankong_a,$wenda_a,$wimg,$recordid);
SerializeUserSubmit($danxuan_a,$duoxuan_a,$panduan_a,$tiankong_a,$wenda_a,$recordid);

$paper_item_timu_desc_arr = GetPaperItemTimuDesc($item);

//���ӻ���
if($openreward){
	$score_add_credits = $skey;
	$addcredit = 'extcredits'.$rewardcredit;
	$uid = $_G['uid'];
	updatemembercount($uid, array($addcredit => $total_score));
}

$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='nocopy'");
$nocopy = $skey['nocopy'];
	
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/comb.func.inc.php";
require_once libfile('include/papersetting','plugin/tp_exam');
$setting = getSetting($item);

//����δ��ɻ��ֹ����������ÿ�λ��ֹ���
$have = C::t('#tp_exam#tp_exam_buy#')->fetch_unfinish_order($uid,$item);
if(is_array($have) && !empty($have)){
		DB::update('tpexam_buy',array('finish'=>1),"id='$have[id]'");
}


$submitbehaviour = DISCUZ_ROOT."./source/plugin/tpgao_jiaojuan/jiaojuan.inc.php";
if(file_exists($submitbehaviour)){
	$inpaper = 1;
	require_once DISCUZ_ROOT."./source/plugin/tpgao_jiaojuan/jiaojuan.inc.php";
}

include template('tp_exam:exam');

}


function submit_record($uid,$exam_type,$usetime,$exam_time,$score)
{
	global $verifyid;
	
	$insert = DB::insert('tpexam_examrecord', array(
				'uid'=>$uid,
				'exam_type' => $exam_type,
				'usetime' => $usetime,
				'date' => $exam_time,
				'score'=> $score,
				'verifyid'=>$verifyid
				),1);
				
		return $insert;
}

function GetRandMode($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id = $item");
	
	while($data = DB::fetch($query))
	{
		return $data['rand'];
	}
	
	return 0;
}

function GetNextPaper($item){
	
		$query = DB::query("SELECT * FROM ".DB::table("tpexam_paper")." order by id asc");
		while($data = DB::fetch($query))
		{
			if($data['id'] > $item){
				return $data['id'];
			}
	
		}
		
		return 0;
}


?>
