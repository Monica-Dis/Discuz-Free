<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$config_exam = $_G['cache']['plugin']['tp_exam'];
$config_syn = $_G['cache']['plugin']['tpgao_questionsyn'];
$viewparser_credit = $config_exam['viewparser_credit'];
$viewnum  = $config_syn['parser_credit_num'];
	
$paperid=daddslashes($_GET['paperid']);
$deductcredit=daddslashes($_GET['deductcredit']);
$formhash = daddslashes($_GET['formhash']);

require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_exam.func.php";

if($formhash != formhash()){
	exit('Access Denied');
}

$app = daddslashes($_GET['mod']);

$app = in_array($app, array('deduce', 'favorite' , 'spechars')) ? $app : 'deduce';

if($app == 'deduce'){

	if($viewparser_credit > 0){
		
			$credit="extcredits".$viewparser_credit;//���׻���
			$uid = $_G['uid'];
			updatemembercount($uid, array($credit => $viewnum));
		
			//��ȡ����
			$timutype = daddslashes($_GET['timutype']);
			$item = daddslashes($_GET['item']);
			$table_name = $timutype;
			
			$type = $timutype;
			switch($type)
			{
				case '1':
					$table_name = 'tpexam_tiku_danxuan';
				break;
				case '2':
					$table_name = 'tpexam_tiku_duoxuan';
				break;
				case '3':$table_name = 'tpexam_tiku_panduan';break;
				case '4':$table_name = 'tpexam_tiku_tiankong';break;
				case '5':$table_name = 'tpexam_tiku_wenda';break;
			}
	
			$parser = GetAnswerParser($table_name,$item);
			
			echo $parser;
			
	}
			die();	
}elseif($app == 'spechars' ){
	
	include_once template('tp_exam:tools');
	
}elseif($app == 'favorite')
{
		$admin_exam_exam_fav_success = lang('plugin/tp_exam', 'admin_exam_exam_fav_success');
		$admin_exam_exam_fav_exist = lang('plugin/tp_exam', 'admin_exam_exam_fav_exist');
			
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_favorite')." where uid = '$_G[uid]' and favorite_belongpaper = '$paperid'");
		
		if($row = DB::fetch($query))
		{
			echo $admin_exam_exam_fav_exist;
		}
		else
		{
				DB::insert('tpexam_favorite', array(
				'favorite_belongpaper' => $paperid,
				'date' => time(),
				'uid' => $_G['uid']
				));
				
			echo $admin_exam_exam_fav_success;
		}
}
//From: di'.'sm.t'.'aoba'.'o.com
?>