<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


	require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/comb.func.inc.php';
	require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';
	
	global $_G;
	$config = array();
	$config = $_G['cache']['plugin']['tpgao_m'];
	$forcelogin = $config['anoy'];
	
			//�ж��û��Ƿ��¼
	if(!$_G['uid'] && !$forcelogin){
		$exam_must_login_tips=lang('plugin/tp_exam', 'exam_must_login_tips');
		showmessage($exam_must_login_tips, NULL, array(), array('login' => 1));
	}
	
	
	$errid = $_GET['errid'];
	$errortype = $_GET['errortype'];
	$errall = $_GET['errall'];
	$mtype = $_GET['mtype'];
	$sort = intval($_GET['sort']);
	
	
	global $_G;
	$config = array();
	$config = $_G['cache']['plugin']['tpgao_mexam'];
	$openviewerr = $config['openviewerr'];
	
	$uid = $_G['uid'];
	$username = getuserbyuid($uid);
	$username = $username['username'];
		
	
	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	$admin_pub_type6 = lang('plugin/tp_exam', 'admin_pub_type6');
	$admin_pub_type7 = lang('plugin/tp_exam', 'admin_pub_type7');
	
	$exam_up_page = lang('plugin/tp_exam', 'exam_up_page');
	$exam_down_page = lang('plugin/tp_exam', 'exam_down_page');
	
	$type_arr=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5,$admin_pub_type6,$admin_pub_type7);


	if(isset($errid) && isset($errortype)){
		$errid = intval($_GET['errid']);
		$errortype = intval($_GET['errortype']);
	
		$pid = 2;
		$needPractise = 0;
		if($errortype == 1){
			
			$dan = GetDanxuanById($errid);
			
			$data = $dan['option1']."\r\n".$dan['option2']."\r\n".$dan['option3']."\r\n".$dan['option4'];
			if($dan['option5']!='') $data .= "\r\n".$dan['option5'];
			if($dan['option6']!='') $data .= "\r\n".$dan['option6'];
			if($dan['option7']!='') $data .= "\r\n".$dan['option7'];
		
			$arr = array('type'=>1,'id'=>1,'eid'=>$dan['id'],'image'=>$dan['image'],'parserimage'=>$dan['parser_img_path'],'subject'=>$dan['ask'],'score'=>$dan['score'],'data'=>$data);
			$groups[]=$arr;
		}else if($errortype == 2){
			$duo = GetDuoxuanById($errid);
			$data = $duo['option1']."\r\n".$duo['option2']."\r\n".$duo['option3']."\r\n".$duo['option4'];
			if($duo['option5']!='') $data .= "\r\n".$duo['option5'];
			if($duo['option6']!='') $data .= "\r\n".$duo['option6'];
			if($duo['option7']!='') $data .= "\r\n".$duo['option7'];
		
			$arr = array('type'=>2,'id'=>1,'eid'=>$duo['id'],'image'=>$duo['image'],'parserimage'=>$duo['parser_img_path'],'subject'=>$duo['ask'],'score'=>$duo['score'],'data'=>$data);
			$groups[]=$arr;
		}

		//������ͼ
		include template('tpgao_m:m');
		exit;
	}elseif(isset($errall)){
		$sort = intval($_GET['sort']);
		$mtype = intval($_GET['mtype']);
		
		$where = 'Order By id desc';

		$idarr = GetChildTypeIdArray($mtype);
		if(count($idarr)>0){
			$in = implode(",",$idarr);
			$paperarr=array();
			$query = DB::query("SELECT id FROM ".DB::table('tpexam_paper')." where belong IN ($in)");
			while($row = DB::fetch($query)){
				$paperarr[]=$row['id'];
			}
			if(count($paperarr)>0){
				$paperarr = implode(",",$paperarr);
				$paperin = 'and paperid IN('.$paperarr.')';
			}
		}
		
		$index = 1;
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_errorbook')." where uid = '$_G[uid]' $paperin $where ");
		
		while($row = DB::fetch($query)){
			if($row['errortype'] == 1){
				$dan = GetDanxuanById($row['errorid']);
				$data = $dan['option1']."\r\n".$dan['option2']."\r\n".$dan['option3']."\r\n".$dan['option4'];
				if($dan['option5']!='') $data .= "\r\n".$dan['option5'];
				if($dan['option6']!='') $data .= "\r\n".$dan['option6'];
				if($dan['option7']!='') $data .= "\r\n".$dan['option7'];
		
				$arr = array('type'=>1,'id'=>$index,'eid'=>$dan['id'],'image'=>$dan['image'],'parserimage'=>$dan['parser_img_path'],'subject'=>$dan['ask'],'score'=>$dan['score'],'data'=>$data);
				$groups[]=$arr;
				$index++;
			}else if($row['errortype'] == 2){
				$duo = GetDuoxuanById($row['errorid']);
				$data = $duo['option1']."\r\n".$duo['option2']."\r\n".$duo['option3']."\r\n".$duo['option4'];
				if($duo['option5']!='') $data .= "\r\n".$duo['option5'];
				if($duo['option6']!='') $data .= "\r\n".$duo['option6'];
				if($duo['option7']!='') $data .= "\r\n".$duo['option7'];
		
				$arr = array('type'=>2,'id'=>$index,'eid'=>$duo['id'],'image'=>$duo['image'],'parserimage'=>$duo['parser_img_path'],'subject'=>$duo['ask'],'score'=>$duo['score'],'data'=>$data);
				$groups[]=$arr;
				$index++;
			}
		}
		
		$isPC = !checkmobile();
		$cid ='';
		$pid = 2;
		$needPractise = $openviewerr;
		
		//������ͼ
		include template('tp_exam:m');
		exit;
		
	}else if(isset($mtype)){//ȡ��ǰ�������
		
		$mtype = intval($mtype);
		$idarr = GetChildTypeIdArray($mtype);
		$in = implode(",",$idarr);
		$paperarr=array();
		$query = DB::query("SELECT id FROM ".DB::table('tpexam_paper')." where belong IN ($in)");
		while($row = DB::fetch($query)){
			$paperarr[]=$row['id'];
		}

		if(count($paperarr)==0){include template('tpgao_mexam:merrbook');exit;}
		
		$sort = intval($_GET['sort']);
		
		$in = implode(",",$paperarr);
		$where = 'Order By wrong';
		if($sort == 1){
			$where = 'Order By wrong';
		}else if($sort == 2){
			$where = 'Order By qright';
		}else if($sort == 3){
			$where = 'Order By rightratio';
		}else if($sort == 4){
			$where = 'Order By wrongratio';
		}
		$page = intval($_G['page']);
		if(empty($page)) $page=1;
	
		$perpage = 6;
		$limit_start = $perpage * ($page - 1);
	
		$limit_end = $limit_start + $perpage ;
		$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_userexam_questionstatus')." where uid = '$_G[uid]' and paperid IN ($in) $where desc");
		$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 
		
		
		$pagearr=array();
		for($i=1;$i<=$pagecount;$i++)
		{
			$pagearr[] = $i;
		}
	
		$err_item=array();
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_userexam_questionstatus')." where uid='$_G[uid]' and paperid IN ($in) $where desc limit $limit_start,$perpage");
		while($row = DB::fetch($query)){
			$error[] = $row;
		}

		include template('tp_exam:merrbook');
		
		exit;
	}else if(isset($sort)){


	$page = intval($_G['page']);
	if(empty($page)) $page=1;
	
	$perpage = 6;
	$limit_start = $perpage * ($page - 1);
	
	$limit_end = $limit_start + $perpage ;
	
	$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_tiku_errorbook')." where uid = '$_G[uid]'");
	$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 
	
	$pagearr=array();
	for($i=1;$i<=$pagecount;$i++)
	{
		$pagearr[] = $i;
	}

	$where = 'order by id';

	$error = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_errorbook')." where uid = $_G[uid] $where desc limit $limit_start,$perpage");

	while($row = DB::fetch($query)){
			$row['typename'] = GetTypeDesc($row['errortype'],$type_arr);
			$row['subject'] = GetSubject($row['errortype'],$row['errorid']);
			$row['wrong'] = GetWrongTimes($row['errortype'],$row['errorid']);
			$error[] = $row;
	}
		
		include template('tp_exam:merrbook');
	}


function GetTypeDesc($type,$type_arr)
{
	switch($type)
	{
		case 1:
			return $type_arr[0];
		break;
		case 2:
			return $type_arr[1];
		break;
		case 3:
			return $type_arr[2];
		break;
		case 5:
			return $type_arr[3];
		break;
		case 4:
			return $type_arr[4];
		break;
		case 6:
			return $type_arr[5];
		case 7:
			return $type_arr[6];
	}
}


function GetChildTypeIdArray($typeid){
	
	$idarr=array();

	//����1��
	$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where parent = '$typeid'");
	while($data = DB::fetch($query))
	{
		$idarr[]=$data['id'];
	}

	if(count($idarr)>0){
		$idlist = implode(",",$idarr);

		//����2��
		$query = DB::query("SELECT * FROM ".DB::table("tpexam_type")." where parent  IN ($idlist) ");
		while($data = DB::fetch($query))
		{
			$idarr[]=$data['id'];
		}
	}
	return $idarr;
}

function GetCurrentTypeError($arr){
	$groups = array();
	$index = 1;

	foreach($arr as $k=>$v){
			if($v[0] == 1){
				$dan = GetDanxuanById($v[1]);
				$data = $dan['option1']."\r\n".$dan['option2']."\r\n".$dan['option3']."\r\n".$dan['option4'];
				if($dan['option5']!='') $data .= "\r\n".$dan['option5'];
				if($dan['option6']!='') $data .= "\r\n".$dan['option6'];
				if($dan['option7']!='') $data .= "\r\n".$dan['option7'];
		
				$arr = array('type'=>1,'id'=>$index,'eid'=>$dan['id'],'image'=>$dan['image'],'parserimage'=>$dan['parser_img_path'],'subject'=>$dan['ask'],'score'=>$dan['score'],'data'=>$data);
				$groups[]=$arr;
				$index++;
			}
			elseif($v[0] == 2){
				
			}
	}
	
	return $groups;
}


function GetSubject($errortype,$errorid)
{
	$wrong=array();
	$table = 'tpexam_tiku_danxuan';
	switch($errortype){
		case 1:$table = 'tpexam_tiku_danxuan';break;
		case 2:$table = 'tpexam_tiku_duoxuan';break;
		case 3:$table = 'tpexam_tiku_panduan';break;
		case 4:$table = 'tpexam_tiku_tiankong';break;
		case 5:$table = 'tpexam_tiku_wenda';break;
	}
	
	$query = DB::query("SELECT * FROM ".DB::table($table)." where id = $errorid");
	while($data = DB::fetch($query)){
		$wrong = $data;
	}
	
	return $wrong['ask'];
}

function GetWrongTimes($errortype,$errorid)
{
	$wrong=array();
	$query = DB::query("SELECT * FROM ".DB::table("tpexam_userexam_questionstatus")." where questiontype = $errortype and questionid = $errorid");
	while($data = DB::fetch($query)){
		$wrong = $data;
	}
	
	return $wrong['wrong'];
}
//From: di'.'sm.t'.'aoba'.'o.com
?>