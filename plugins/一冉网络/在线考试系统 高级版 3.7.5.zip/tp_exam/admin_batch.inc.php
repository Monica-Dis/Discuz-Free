<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


setlocale(LC_ALL, 'zh_CN');
if($_G['charset'] == 'utf-8') {
	$utf8=true;
}

require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/csvpaper.inc.php";

if(!submitcheck('submit')) {

	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	$mobile_file = DISCUZ_ROOT."./source/plugin/tp_exam/module/module_batch.inc.php";
	
	if(!file_exists($mobile_file))
	{
		$admin_module_batch_notexist_tips = lang('plugin/tp_exam', 'admin_module_batch_notexist_tips');

		showtips($admin_module_batch_notexist_tips);
		die();
	}
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/module/module_batch.inc.php";
	
}else if(submitcheck('submit')){

		if(isset($updatetiku)){
			$updatetiku =  daddslashes($_POST['updatetiku']);
			
			UpdateTiku();
			
			cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_batch', 'succeed');
			exit;
		}

		$paper =  daddslashes($_POST['belong_paper']);
		$timu_type =  daddslashes($_POST['timutype']);
		$single_five =  daddslashes($_POST['single_five']);
		

		$filename = $_FILES['shoplogo']['name'];
		

		if($_FILES['shoplogo']['error'] != 0 && !empty($_FILES['shoplogo']['name'])) {
			echo 'File Not Exist';
			exit;
	}
	
	if(!empty($_FILES['shoplogo']['name']) && !in_array(strtolower(fileext($_FILES['shoplogo']['name'])), array('csv', 'gif', 'png'))) {
		echo 'File Not Support';
		exit;
	}
	
		$url = '';
 		$data = file($_FILES['shoplogo']['tmp_name']);
 		
 		if($timu_type == 8){
 			if($_G['charset'] == 'utf-8') {
				$utf8=true;
			}

 			ImportCSVPaper($data,$utf8);
 			cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_batch', 'succeed');
    }		
    
 		foreach ($data AS $line)
    {
    	switch($timu_type)
    	{
    		case 1:
    			ImportDanxuan($paper,$line);
    		break;
    		case 2:
    			ImportDuoxuan($paper,$line);
    		break;
    		case 3:
    			ImportPanduan($paper,$line);
    		break;
    		case 5:
    			ImportWenda($paper,$line);
    			break;
    		case 4:
    			ImportTiankong($paper,$line);
    		break;
    		case 6:
    			ImportYuedulijie($paper,$line);
    		break;
    		case 7:
    			ImportPeiwu($paper,$line);
    		break;  		
    	}
    
    }
		
	//���µ�ѡ��

	cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_batch', 'succeed');
	

}

function ImportDanxuan($paperid,$csvline)
{

	list($id,$ask,$option1,$option2,$option3,$option4,$option5,$option6,$option7,$answer,$belong_paper,$score,$data,$publish_uid,$viewParser_credits,$answer_parser,$yuedu,$image,$audio,$video)=explode(',',$csvline);

	global $utf8;
	
	if($utf8) {
	$answer_parser = iconv("gb2312","utf-8",$answer_parser);
	$ask = iconv("gb2312","utf-8",$ask);
	$option1 = iconv("gb2312","utf-8",$option1);
	$option2 = iconv("gb2312","utf-8",$option2);
	$option3 = iconv("gb2312","utf-8",$option3);
	$option4 = iconv("gb2312","utf-8",$option4);
	$option5 = iconv("gb2312","utf-8",$option5);
	$option6 = iconv("gb2312","utf-8",$option6);
	$option7 = iconv("gb2312","utf-8",$option7);
	$answer = iconv("gb2312","utf-8",$answer);
	}
	
	DB::insert('tpexam_tiku_danxuan', array(
     'ask' => $ask,
     'option1' => $option1,
     'option2' => $option2,
     'option3' => $option3,
     'option4' => $option4,
     'option5' => $option5,
     'option6' => $option6,
     'option7' => $option7,
     'answer' => $answer,
     'belong_paper' => $belong_paper,
     'score' => $score,
     'data' => $data,
     'publish_uid' => $publish_uid,
     'viewParser_credits' => $viewParser_credits,
     'answer_parser' => $answer_parser,
     'yuedulijie_timutype'=>$yuedu,
     'image'=>trim($image)
    ));
    
}

function ImportDuoxuan($paperid,$csvline)
{
	list($id,$ask,$option1,$option2,$option3,$option4,$option5,$option6,$option7,$answer1,$answer2,$answer3,$answer4,$answer5,$answer6,$answer7,$belong_paper,$score,$data,$publish_uid,$viewParser_credits,$answer_parser,$image,$audio,$video)=explode(',',$csvline);
	
	global $utf8;
	
	if($utf8) {
	$answer_parser = iconv("gb2312","utf-8",$answer_parser);
	$ask = iconv("gb2312","utf-8",$ask);
	$option1 = iconv("gb2312","utf-8",$option1);
	$option2 = iconv("gb2312","utf-8",$option2);
	$option3 = iconv("gb2312","utf-8",$option3);
	$option4 = iconv("gb2312","utf-8",$option4);
	$option5 = iconv("gb2312","utf-8",$option5);
	$option6 = iconv("gb2312","utf-8",$option6);
	$option7 = iconv("gb2312","utf-8",$option7);
	$answer1 = iconv("gb2312","utf-8",$answer1);
	$answer2 = iconv("gb2312","utf-8",$answer2);
	$answer3 = iconv("gb2312","utf-8",$answer3);
	$answer4 = iconv("gb2312","utf-8",$answer4);
	$answer5 = iconv("gb2312","utf-8",$answer5);
	$answer6 = iconv("gb2312","utf-8",$answer6);
	$answer7 = iconv("gb2312","utf-8",$answer7);
	}
		
	DB::insert('tpexam_tiku_duoxuan', array(
     'ask' => $ask,
     'option1' => $option1,
     'option2' => $option2,
     'option3' => $option3,
     'option4' => $option4,
     'option5' => $option5,
     'option6' => $option6,
     'option7' => $option7,
     'answer1' => $answer1,
     'answer2' => $answer2,
     'answer3' => $answer3,
     'answer4' => $answer4,
     'answer5' => $answer5,
     'answer6' => $answer6,
     'answer7' => $answer7,
     'belong_paper' => $belong_paper,
     'score' => $score,
     'data' => $data,
     'publish_uid' => $publish_uid,
     'viewParser_credits' => $viewParser_credits,
     'answer_parser' => $answer_parser,
     'image'=>trim($image)
    ));
    
}

function ImportPanduan($paperid,$csvline)
{
	list($id,$ask,$answer,$belong_paper,$score,$data,$publish_uid,$viewParser_credits,$answer_parser,$image,$audio,$video)=explode(',',$csvline);
	
	global $utf8;
	
	if($utf8) {
	$answer_parser = iconv("gb2312","utf-8",$answer_parser);
	$ask = iconv("gb2312","utf-8",$ask);
	}
		
	DB::insert('tpexam_tiku_panduan', array(
     'ask' => $ask,
     'answer' => $answer,
     'belong_paper' => $belong_paper,
     'score' => $score,
     'data' => $data,
     'publish_uid' => $publish_uid,
     'viewParser_credits' => $viewParser_credits,
     'answer_parser' => $answer_parser,
     'image'=>trim($image)
    ));
    
}

function ImportWenda($paperid,$csvline)
{
	list($id,$ask,$answer,$score,$belong_paper,$data,$publish_uid,$viewParser_credits,$answer_parser,$image,$audio,$video,$parser_img_path)=explode(',',$csvline);
	global $utf8;
	
	if($utf8) {
	$answer_parser = iconv("gb2312","utf-8",$answer_parser);
	$ask = iconv("gb2312","utf-8",$ask);
	}
	
	DB::insert('tpexam_tiku_wenda', array(
     'ask' => $ask,
     'answer' => $answer,
     'belong_paper' => $belong_paper,
     'score' => $score,
     'data' => $data,
     'publish_uid' => $publish_uid,
     'viewParser_credits' => $viewParser_credits,
     'answer_parser' => $answer_parser,
     'image'=>$image,
     'audio'=>$audio,
     'video'=>$video,
     'parser_img_path'=>$parser_img_path,
    ));

}
function ImportTiankong($paperid,$csvline)
{
	list($id,$ask,$answer,$score,$belong_paper,$data,$publish_uid,$viewParser_credits,$answer_parser,$image_url,$audio_url,$video_url)=explode(',',$csvline);
	global $utf8;
	
	if($utf8) {
	$answer_parser = iconv("gb2312","utf-8",$answer_parser);
	$ask = iconv("gb2312","utf-8",$ask);
	$answer = iconv("gb2312","utf-8",$answer);
	}
		
	DB::insert('tpexam_tiku_tiankong', array(
     'ask' => $ask,
     'answer' => $answer,
     'belong_paper' => $belong_paper,
     'score' => $score,
     'data' => $data,
     'image' => trim($image_url),
     'audio' => trim($audio_url),
     'video' => trim($video_url),
     'publish_uid' => $publish_uid,
     'viewParser_credits' => $viewParser_credits,
     'answer_parser' => $answer_parser
    ));
    
}

function ImportYuedulijie($paperid,$csvline)
{
	list($id,$ask,$child,$belong_paper,$score,$nickname)=explode(',',$csvline);
	global $utf8;
	
	if($utf8) {
	$ask = iconv("gb2312","utf-8",$ask);
	}	
	
	DB::insert('tpexam_tiku_yuedulijie',array(
	'ask' => $question,
	'score'=>$score ,
	'belong_paper'=> $belong_paper,
	'nickname'=> $nickname));
}

function ImportPeiwu($paperid,$csvline)
{
	list($id,$ask,$belong_paper,$score,$nickname,$option1,$option2,$option3,$option4,$option5,$option6,$option7,$answer1,$answer2,$answer3,$answer4,$answer5,$answer6,$answer7,$data,$publish_uid,$viewParser_credits,$answer_parser)=explode(',',$csvline);
	global $utf8;
	
	if($utf8) {
	$ask = iconv("gb2312","utf-8",$ask);
	$option1 = iconv("gb2312","utf-8",$option1);
	$option2 = iconv("gb2312","utf-8",$option2);
	$option3 = iconv("gb2312","utf-8",$option3);
	$option4 = iconv("gb2312","utf-8",$option4);
	$option5 = iconv("gb2312","utf-8",$option5);
	$option6 = iconv("gb2312","utf-8",$option6);
	$option7 = iconv("gb2312","utf-8",$option7);
	$answer1 = iconv("gb2312","utf-8",$answer1);
	$answer2 = iconv("gb2312","utf-8",$answer2);
	$answer3 = iconv("gb2312","utf-8",$answer3);
	$answer4 = iconv("gb2312","utf-8",$answer4);
	$answer5 = iconv("gb2312","utf-8",$answer5);
	$answer6 = iconv("gb2312","utf-8",$answer6);
	$answer7 = iconv("gb2312","utf-8",$answer7);
	$answer_parser = iconv("gb2312","utf-8",$answer_parser);
	}
	
	DB::insert('tpexam_tiku_peiwu',array(
	'ask'=>$question,
	'belong_paper'=>$belong_paper,
	'score'=>$score,
	'nickname'=>$nickname,
	'option1'=>$option1,
	'option2'=>$option2,
	'option3'=>$option3,
	'option4'=>$option4,
	'option5'=>$option5,
	'option6'=>$option6,
	'option7'=>$option7,
	'answer1'=>$answer1,
	'answer2'=>$answer2,
	'answer3'=>$answer3,
	'answer4'=>$answer4,
	'answer5'=>$answer5,
	'answer6'=>$answer6,
	'answer7'=>$answer7,
	'data'=>time(),
	'publish_uid'=>$_G['uid'],
	'viewParser_credits'=>$viewParser_credits,
	'answer_parser'=>$answer_parser));
}

function ImportCSVPaper($csv,$utf8)
{
	global $utf8;
	
	//��Ŀ����	��Ŀ���	С����	�����	С���	ѡ��1	ѡ��2	ѡ��3	ѡ��4	ѡ��5	��	����	������Ŀ	1����Ŀ¼	2����Ŀ¼	�Ծ�����
	
	$level0=array();
	$level1=array();
	$level2=array();
	$paper=array();
	
	foreach($csv as $k=>$csvline){
		
		list($type,$id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername) = explode(',',$csvline);

		$ret = ProcessLine($utf8,$type,$id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername);	
		
		if($ret['level0'] == 1){
			
		}
	}
	
}

	function UpdateTiku()
	{
		UpdateDanxuan();
		UpdateDuoxuan();
		UpdatePanduan();
		UpdateTiankong();
		UpdateWenda();
	}
	
	function UpdateDanxuan(){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan'));
		while($data = DB::fetch($query))
		{
			if(empty($data['eid'])){
				DB::insert('tpexam_tiku',array('eid'=>0,'tid'=>1,'oid'=>$data['id'],'paperid'=>$data['belong_paper']));
				$eid = mysql_insert_id();
				DB::update('tpexam_tiku',array('eid'=>$eid),"id='$eid'");
				DB::update('tpexam_tiku_danxuan',array('eid'=>$eid),"id='$data[id]'");
			}
		}
	}

	function UpdateDuoxuan(){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan'));
		while($data = DB::fetch($query))
		{
			if(empty($data['eid'])){
				DB::insert('tpexam_tiku',array('eid'=>0,'tid'=>2,'oid'=>$data['id'],'paperid'=>$data['belong_paper']));
				$eid = mysql_insert_id();
				DB::update('tpexam_tiku',array('eid'=>$eid),"id='$eid'");
				DB::update('tpexam_tiku_duoxuan',array('eid'=>$eid),"id='$data[id]'");
			}
		}
	}
	
		function UpdatePanduan(){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan'));
		while($data = DB::fetch($query))
		{
			if(empty($data['eid'])){
				DB::insert('tpexam_tiku',array('eid'=>0,'tid'=>3,'oid'=>$data['id'],'paperid'=>$data['belong_paper']));
				$eid = mysql_insert_id();
				DB::update('tpexam_tiku',array('eid'=>$eid),"id='$eid'");
				DB::update('tpexam_tiku_panduan',array('eid'=>$eid),"id='$data[id]'");
			}
		}
	}
	
		function UpdateTiankong(){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong'));
		while($data = DB::fetch($query))
		{
			if(empty($data['eid'])){
				DB::insert('tpexam_tiku',array('eid'=>0,'tid'=>4,'oid'=>$data['id'],'paperid'=>$data['belong_paper']));
				$eid = mysql_insert_id();
				DB::update('tpexam_tiku',array('eid'=>$eid),"id='$eid'");
				DB::update('tpexam_tiku_tiankong',array('eid'=>$eid),"id='$data[id]'");
			}
		}
	}
		function UpdateWenda(){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda'));
		while($data = DB::fetch($query))
		{
			if(empty($data['eid'])){
				DB::insert('tpexam_tiku',array('eid'=>0,'tid'=>5,'oid'=>$data['id'],'paperid'=>$data['belong_paper']));
				$eid = mysql_insert_id();
				DB::update('tpexam_tiku',array('eid'=>$eid),"id='$eid'");
				DB::update('tpexam_tiku_wenda',array('eid'=>$eid),"id='$data[id]'");
			}
		}
	}
//From: di'.'sm.t'.'aoba'.'o.com
?>