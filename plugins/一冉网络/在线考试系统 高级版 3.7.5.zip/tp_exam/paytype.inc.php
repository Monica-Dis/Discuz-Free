<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	require_once DISCUZ_ROOT."./source/plugin/tp_jifen/include/tpjifen_func.php";

	$payment = GetPaymentInfo();
	$unseri_pay = unserialize($payment['svalue']);

	$partner = $unseri_pay['alipayid'];
	$key = $unseri_pay['alipaykey'];
	$seller_email = $unseri_pay['alipayuser'];
			
	$paytype = $unseri_pay['alipaytype'];
	$payment = daddslashes($_GET['payment']);
	$credit = daddslashes($_GET['credit']);
	
	global $_G;
 		
 		
 		$uid = $_G['uid'];
 	  $user = $_G['username'];
 		

 
 		if($_G['uid'])
 		{
 			$username = $_G['username'];
 			
 		}
 		else
 		{
 			
 			$exam_pay_must_login_tip = lang('plugin/tp_exam', 'exam_pay_must_login_tip');
 			
 			echo $exam_pay_must_login_tip;
 		}
 		
	switch($paytype)
	{
		case '1': //��ʱ
		{
			DirectPay($payment,$username);
		}
		break;
		case '2': //����
			SubmitPay($payment,$username);
		break;
		case '3': //˫�ӿ�
		DualPay($payment,$username);
		break;
	}

function DirectPay($pay,$username)
{
	global $uid;
	
		//ͬ��ҳ�����
	$url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
	$return_url = dirname($url).'/source/plugin/tp_jifen/payment/return_url.php';
	
 	$flag = 0;
 	$subject = $username."(".$uid.")"."pay for exam";

 //Ҫpost������ 
	$argv = array('subject'=>$subject, 'total_fee'=>$pay,'alibody'=>$uid);
	
	
//����Ҫpost���ַ��� 
	foreach ($argv as $key=>$value) {
  global $_G;
  
    if ($flag!=0) {
        $params .= "&"; 
        $flag = 1; 
    } 
    
    $params.= $key."="; 
    $params .= $value;
    $flag = 1; 
    } 
    
  //  echo "������ת��֧������ֵ���ģ���ȴ�......";
    
    $csetting = $_G['cache']['plugin']['tp_jifen'];
		$ali_id = $csetting['ali_num'];
		$ali_key = $csetting['ali_key'];
		$ali_mail = $csetting['ali_mail'];
		
		$ret_url='http://'.$_SERVER['SERVER_NAME'].$_SERVER["REQUEST_URI"];
		$return_url = dirname($ret_url).'/source/plugin/tp_jifen/return_url.php';

    $url =  'source/plugin/tp_jifen/alipayto.php?subject='.urlencode($subject).'&uid='.$uid.'&total_fee='.$pay.'&aliid='.$ali_id.'&alikey='.$ali_key.'&alimail='.$ali_mail.'&return_url='.$return_url;
    
		header('Location:'.$url);
}


function SubmitPay($pay,$username)
{
	global $uid;
	global $unseri_pay;
	$partner = $unseri_pay['alipayid'];
	$key = $unseri_pay['alipaykey'];
	$seller_email = $unseri_pay['alipayuser'];
	
	$p1 = $username."(".$uid.")".$pay." pay for exam";
	
	$p2 = $username ;
	$subdir = dirname($_SERVER["REQUEST_URI"]);
	if($subdir == "" || strlen($subdir) == 1)
	{
		$notify_url = 'http://'.$_SERVER['SERVER_NAME'].'/source/plugin/tp_jifen/payment/alipaysubmit/notify_url.php';
		$return_url = 'http://'.$_SERVER['SERVER_NAME'].'/source/plugin/tp_jifen/payment/alipaysubmit/return_url.php';
	}
	else
	{
		$notify_url = 'http://'.$_SERVER['SERVER_NAME'].$subdir.'/source/plugin/tp_jifen/payment/alipaysubmit/notify_url.php';
		$return_url = 'http://'.$_SERVER['SERVER_NAME'].$subdir.'/source/plugin/tp_jifen/payment/alipaysubmit/return_url.php';
	}
	$url =  'source/plugin/tp_jifen/payment/alipaysubmit/alipaySubmit.php?subject='.urlencode($p1).'&body='.urlencode($p2).'&total_fee='.$pay.'&partner='.$partner.'&key='.$key.'&seller_email='.$seller_email.'&return_url='.$return_url.'&notify_url='.$notify_url.'&credit='.$credit.'&uid='.$uid.'&buynum='.$payment;
	header('Location:'.$url);
}


function DualPay($pay,$username)
{
		global $uid;
		global $unseri_pay;
		$partner = $unseri_pay['alipayid'];
		$key = $unseri_pay['alipaykey'];
		$seller_email = $unseri_pay['alipayuser'];
		
		$p1 = $username."(".$uid.")".$pay." pay for exam";
		$p2 = $username ;
	
		$return_url = dirname($url).'/source/plugin/tp_jifen/payment/alipaydual/return_url.php';
		$url =  'source/plugin/tp_jifen/payment/alipaydual/alipaydual.php?WIDseller_email='.$seller_email.'&WIDout_trade_no='.$order_info['order_id'].'&WIDsubject='.urlencode($p1).'&WIDprice='.$pay.'&WIDbody='.urlencode($p2).'&WIDshow_url='.'&WIDreceive_name='.$order_info[''].'&WIDreceive_address='.$p2.'&WIDreceive_phone='.$order_info['phone'].'&WIDreceive_mobile='.$order_info['phone'].'&partner='.$partner.'&key='.$key.'&return_url='.$return_url.'&buy_num='.$payment.'&uid='.$uid.'&credit='.$credit;
		header('Location:'.$url);
}
//From: di'.'sm.t'.'aoba'.'o.com
?>