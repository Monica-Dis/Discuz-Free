<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	$datatype=daddslashes($_GET['datatype']);
	$dataid=daddslashes($_GET['dataid']);
	$postdata=daddslashes($_GET['postdata']);
	$appmode=daddslashes($_GET['appmode']);
	$datarank=daddslashes($_GET['datarank']);

if($appmode==0){

	if(!empty($datatype) && !empty($dataid)){

		$datatype = intval($datatype);
		$dataid = intval($dataid);
	
		$admin_common_success = lang('plugin/tp_exam','admin_common_success');
		$username = getuserbyuid($_G['uid']);
		$username = $username['username'];
		DB::insert('tpexam_tiku_comment', array(
		'comment' => $postdata,
		'uid' => $_G['uid'],
		'question_rank' => $datarank,
		'question_id' => $dataid,
		'question_type' => $datatype,
		'upvote' => 0,
		'oppose' => 0,
		'postdata' => time(),
		'postip' => $_G['clientip'],
		'username'=>$username
		));

		echo json_encode($admin_common_success);
	}
	}
	else if($appmode==1){

		$comment=array();
		$page=daddslashes($_GET['page']);
		$commtype=daddslashes($_GET['commtype']);
		$commid=daddslashes($_GET['commid']);
		
		$perpage = 3;
		$page = max(1, $page);
		$listStart = ($page-1) *$perpage;
		$listEnd = $page*$perpage;
		
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_comment')." where question_type = $commtype and question_id = $commid  order by id desc limit $listStart,3");
		while($data = DB::fetch($query))
		{
			$comment[]=$data;
		}

		echo json_encode($comment);
	}
	else if($appmode==2){
		$totalnum=daddslashes($_GET['totalnum']);
		$curpage=daddslashes($_GET['curpage']);
		$commtype=daddslashes($_GET['commtype']);
		$commid=daddslashes($_GET['commid']);
		
		$exam_up_page = lang('plugin/tp_exam', 'exam_up_page');
		$exam_down_page = lang('plugin/tp_exam', 'exam_down_page');
		
		include 'include/page.class.php';
		$page = new Page($totalnum,3,10,'p1',$totalnum,$curpage);
		$page->pageType = '%up%<span class="number">%numberD%</span>%down%';
		$page->pageShow = array('up'=>'<'.$exam_up_page,'down'=>$exam_down_page.'>');
		$page->pageSetJsFun();
		$page->pageSetParam($commtype,$commid);
		$page->pageSetPage($curpage);
		$p1 = $page->pageShow();
		echo $p1;
	}else if ($appmode==3){
		$commid=daddslashes($_GET['commid']);
		$mode=daddslashes($_GET['mode']);
		if($mode==1){
			$skey = DB::result_first("SELECT upvote FROM ".DB::table('tpexam_tiku_comment')." where id = '$commid'");
			$count = $skey + 1;
			
			DB::update('tpexam_tiku_comment', array(
			'upvote' => $count
			),"id='$commid'");
		
			$exam_up_comment_addone = lang('plugin/tp_exam', 'exam_up_comment_addone');
			echo $exam_up_comment_addone;
		}
		else if ($mode == 0){
			$skey = DB::result_first("SELECT oppose FROM ".DB::table('tpexam_tiku_comment')." where id = '$commid'");
			$count = $skey + 1;
	
			DB::update('tpexam_tiku_comment', array(
			'oppose' => $count
			),"id='$commid'");
		
		
			$exam_down_comment_addone = lang('plugin/tp_exam', 'exam_down_comment_addone');
			echo $exam_down_comment_addone;
		}
	}
//From: di'.'sm.t'.'aoba'.'o.com
?>
