<?php

	if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(submitcheck('submit')){
	
	$p1 = daddslashes($_POST['1']); //����
	$p2 = daddslashes($_POST['2']); //��˾
	$p3 = daddslashes($_POST['3']); //����
	$p4 = daddslashes($_POST['4']); //ѧ��
	
	$m = daddslashes($_POST['m']);
	
	$item = daddslashes($_POST['item']);
	$password = daddslashes($_POST['password']);
		
	$uid = $_G['uid'];
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify'));

	$cookie = "tpexam_login_".$item."_".$uid;
	$login_succ =  lang('plugin/tp_exam', 'exam_login_fail');

	if($data = DB::fetch($query))
	{
		if($data['verify_mode'] == 1) //��¼ģʽ
		{
			$info = GetLoginedInfo($item,$uid);
			if(isset($password)){
				if(!VerifyPassword($item)){
					LoginFail();
				}
			}
			
			LoginSuccess($info,$p1,$p2,$p3,$p4);
		}
		else
		{
			$verify = $data;
			$verifyedid = 0;
			
			if($verify['name']==1){
				$verifyedid = MyVerifyName($p1);
				if(!$verifyedid){
					LoginFail('1');
				}
			}
			
			if($verify['company']==1){
				$verifyedid = VerifyCompany($p2);
				 if(!$verifyedid){
				 	LoginFail('2');
				}
			}
			if($verify['idcard']==1){
				$verifyedid = VerifyIDCard($p3);
				if(!$verifyedid){
					LoginFail('3');
				}
			}
			if($verify['student_id']==1){
				$verifyedid = VerifyStudId($p4);
				if(!$verifyedid){
					LoginFail('4');
				}
			}
			
			if(isset($password)){
				if(!VerifyPassword($item)){
					LoginFail('5');
				}
			}
			
			
			//$info = GetLoginedInfo($item,$uid);
			//echo 'VerifyLoginTimes='.$verifyedid;
			
			if(VerifyLoginTimes($item,$verifyedid)){
				LoginFail('6');
			}
			
			LoginSuccess($verifyedid,$p1,$p2,$p3,$p4);

		}
	}
	
}


	function verifyname($verify_item,$username,$company)
	{
		 $verify_arr = explode("|",$verify_item);
		 
		 $username = trim($username);
		 $company = trim($company);
		 
		 if(count($verify_arr)==1)
		 {
		 	$sql = "SELECT * FROM ".DB::table('tpexam_verify_data')." where username = '$username'";
		 }
		else
		 {
		 	$sql = "SELECT * FROM ".DB::table('tpexam_verify_data')." where username = '$username' ";
		 }

		 $query = DB::query($sql);
		 while($data = DB::fetch($query))
		 {
		 	
		 		$sql2= "SELECT * FROM ".DB::table('tpexam_verify_data')." where id = $data[id]";
		 		$query2 = DB::query($sql2);
		 		while($data2 = DB::fetch($query2))
				{
					if(trim($data2['company']) == trim($company))
					{
						return $data['id'];
					}
					
				}
		 }
		
		 return 0;
	}
	
	function GetVerifyData()
	{
		$sql = "SELECT * FROM ".DB::table('tpexam_verify');
		$query = DB::query($sql);
		while($data=DB::fetch($query))
		{
			return $data;
		}
	}

	function MyVerifyName($name)
	{
		$name = trim($name);
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where username = '$name'");
		while($data=DB::fetch($query))
		{
			return $data['id'];
		}
		
		return 0;
		
	}

	function VerifyCompany($company)
	{
		$company = trim($company);
		$sql = "SELECT * FROM ".DB::table('tpexam_verify_data')." where company = '$company'";
		$query = DB::query($sql);
		while($data=DB::fetch($query))
		{
			return $data['id'];
		}
		return 0;
	}
	function VerifyIDCard($idcard)
	{
		$idcard = trim($idcard);
		$sql = "SELECT * FROM ".DB::table('tpexam_verify_data')." where idcard = '$idcard'";
		$query = DB::query($sql);
		while($data=DB::fetch($query))
		{
			return $data['id'];
		}
		return 0;
	}

	function VerifyStudId($studid)
	{
		$studid = trim($studid);
		$sql = "SELECT * FROM ".DB::table('tpexam_verify_data')." where student_id = '$studid'";
		$query = DB::query($sql);
		while($data=DB::fetch($query))
		{
			return $data['id'];
		}
		return 0;
	}
	
	function LoginFail($step)
	{	
		global $_G;
		global $m;
		global $item;
		
		$login_succ =  lang('plugin/tp_exam', 'exam_login_fail').$step;
		$exam_reach_times =  lang('plugin/tp_exam', 'exam_reach_times');
		if($step == '6'){
			$login_succ  = $exam_reach_times;
		}
		
		$uid = $_G['uid'];
		$cookie = "tpexam_login_".$item."_".$uid;
		setcookie($cookie,'false');
		
		$isMobile = checkmobile();
		if($isMobile){
			showmessage($login_succ, "plugin.php?id=tpgao_mexam:index&mod=exam&item=$item", 'succeed');
		}else{
			showmessage($login_succ, "plugin.php?id=tp_exam:index&mod=exam&item=$item", 'succeed');	
		}
		exit;
	}

	function LoginSuccess($verifyitemid,$p1,$p2,$p3,$p4)
	{
		global $_G;
		global $m;
		global $item;
		
		$login_succ =  lang('plugin/tp_exam', 'exam_login_success');
		$uid = $_G['uid'];
		$cookie = "tpexam_login_".$item."_".$uid;
		setcookie($cookie,'true');
		
		//д���ݿ�
		DB::update('tpexam_verify_data', array('uid'=>$uid,
		'username'=>$p1,
		'idcard'=>$p3,
		'company'=>$p2,
		'student_id'=>$p4), "id=$verifyitemid");
		
		$isMobile = checkmobile();
		
		if($isMobile){
			showmessage($login_succ, "plugin.php?id=tpgao_mexam:index&mod=exam&item=$item&v=$verifyitemid", 'succeed');
		}else{
			showmessage($login_succ, "plugin.php?id=tp_exam:index&mod=exam&item=$item&v=$verifyitemid", 'succeed');	
		}
	
		exit;
	}


	function VerifyPassword($item){
		global $password;
			//��֤����
			if(isset($password)){
				$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id='$item'");
				while($data = DB::fetch($query)){
					if($data['password']==$password){
						return 1;
					}
				}
			}
			
			return 0;
	}
	
	function GetLoginedInfo($item,$uid)
	{
		if($uid>0)
			$where = "and uid = $uid";
		else
			$where = "";
		
			$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where belongpaper=$item $where");
			while($data = DB::fetch($query)){
				return $data['id'];
			}
		
			DB::insert('tpexam_verify_data', array(
			'username' => '',
			'idcard' => '',
			'company' => '',
			'student_id' => '',
			'uid' => $uid,
			'belongpaper'=>$item
			));
			
			$mysqlid = mysql_insert_id();
			return $mysqlid;
	}
/*
1 - reach
0 - unreach
*/
	function VerifyLoginTimes($paperid,$vid){
		$skey = DB::result_first("SELECT verifylogintimes FROM ".DB::table('tpexam_paper')." where id = $paperid");
		
		//echo 'skey='.$skey;
		//echo 'vid='.$vid;
		
		if($skey > 0){

			$skeynow = DB::result_first("SELECT  logintimes  FROM ".DB::table('tpexam_verify_data')." where id = $vid");
			
			
			$skeynow = $skeynow['logintimes'];
			//echo 'skeynow='.$skeynow;
			
			if($skeynow>=$skey){
				return 1;
			}
		}
		
		return 0;
	}
	
?>