<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: test.php 33234 2013-12-20 22:59:14Z mpage $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$vars = $_G['cache']['plugin']['tp_exam'];

dsetcookie('mobile', '2');
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/mobile_func.php";

$item = daddslashes($_GET['item']);
$type = daddslashes($_GET['type']);

$filter = in_array($type, array('0', '1', '2','3','4')) ? $type : '0';

$danxuan = GetDaXuanByPaperID($item);
$duoxuan = GetDuoXuanByPaperID($item);
$panduan = GetPanDuanByPaperID($item);
$tiankong = GetTiankongByPaperID($item);

//�������Ҫ�ദ��һ�������������Ŀ
$tiankong_ask = GetTiankongAsk_m($tiankong);

$wenda = GetWendaByPaperID($item);

$timulist=array();
switch($filter)
{
	case '0':$timulist = $danxuan;break;
	case '1':$timulist = $duoxuan;break;
	case '2':$timulist = $panduan;break;
	case '3':$timulist = $wenda;break;
	case '4':$timulist = $tiankong_ask;break;
}

//��������Ŀ����
$count_danxuan = count($danxuan);
$count_duoxuan = count($duoxuan);
$count_panduan = count($panduan);
$count_tiankong = count($tiankong);
$count_wenda = count($wenda);

$exam = GetExamByPaperID($item);
$needlogin = GetNeedLogin($item);
$needpay = GetNeedPay($item);

//�����Ŀ����
	$timu_count_arr = array(count($danxuan),count($duoxuan),count($panduan),count($wenda),count($tiankong));
	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
					
	$timu_type=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5);
	

	//�ж��Ƿ��¼
	if(!$_G['uid'])
	{
		header("Location: member.php?mod=logging&action=login");
	}

	
	//�ж��Ƿ���Ҫ���ֹ���
	session_start();
	$needcredit = GetNeedCredits($item);
	if($needcredit[0])
	{
		if(!isset($_SESSION['credits_buyed'])) //�������
		{
			header("Location: plugin.php?id=tp_exam:mobile_buy&needpay=$item");
		}
	}
	
	//�ж��Ƿ��շ�
	if($needpay)
	{
		header("Location: plugin.php?id=tp_exam:pay&needpay=$item");
	}
	

	$admin_exam_exam_timer_leave_tips=lang('plugin/tp_exam', 'admin_exam_exam_timer_leave_tips');
	$admin_exam_exam_timer_leave_min_tips=lang('plugin/tp_exam', 'admin_exam_exam_timer_leave_min_tips');
	$admin_exam_exam_timer_leave_sec_tips=lang('plugin/tp_exam', 'admin_exam_exam_timer_leave_sec_tips');
	$examtime = $exam['papertime'];
	

	include template('tp_exam:mobile_exam');

?>