<?php


if (!defined('IN_DISCUZ')  ) {
    exit('Access Denied');
}


class examanswer_record{
	
	var $pluginvar;
	var $paperid;
	var $score;
	var $verifyid;
	var $uniquecode;
	
	function examanswer_record(){
		
		global $_G;
		loadcache('plugin');
		$this->pluginvar = $_G['cache']['plugin']['tp_exam'];

	}
	
	/**
	 * 
	 * ���ô�����
	 * @param int $fid
	 * @return array
	 */
	function setuseranswer($arr){

		$arr = serialize($arr);
		
		//ֱ�Ӵ������ݿ�
		
	}
	
	function setanswerpaper($paperid){
		
		$this->paperid = $peperid;
		
	}
/*
uid
exam_type
usetime
date
score
verifyid
uniquecode
*/

}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>