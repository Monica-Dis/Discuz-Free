<?php

 /*
 ���߿���ϵͳ  tp_exam
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$op = trim($_G['gp_op']);
$id = trim($_G['gp_id']);

if(!submitcheck('submit') && empty($op)) {
	$id = lang('plugin/tp_exam', 'admin_common_id');
	$parent = lang('plugin/tp_exam', 'admin_common_parent');
	$shorturl = lang('plugin/tp_exam', 'admin_common_shorturl');
	$name = lang('plugin/tp_exam', 'admin_common_name');
	$op = lang('plugin/tp_exam', 'admin_common_op');
	$exam_sort = lang('plugin/tp_exam', 'exam_sort');
	
	showtips(lang('plugin/tp_exam', 'admin_type_tips'));
	
  showformheader('plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_type', 'editsubmit');
	showtableheader();

	showsubtitle(array($id, $exam_sort,$parent,$shorturl, $name, $operation));
	
	$perpage = 15;
	$page = max(1, intval($_GET['page']));
	$listStart = ($page-1) *$perpage;
	$totalnum = DB::result_first("SELECT count(*) FROM ".DB::table('tpexam_type'));
	$pagenum = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 

	$multi = multi($totalnum, $perpage, $page, ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_type");


	$query = DB::query('SELECT * FROM '.DB::table('tpexam_type')." order by id asc limit $listStart,$perpage");
	while($value = DB::fetch($query))
	{
		$valarr = array();
		$valarr[] = "<input type='checkbox' name='delete[]' value='$value[id]'/>$value[id]";
		$valarr[] = '<input type="text" id="sort_'.$value['id'].'" class="txt" name="sort['.$value['id'].']" value="'.$value['sort'].'"/>';
		$valarr[] = '<input type="text" id="parent_'.$value['id'].'" class="txt" name="parent['.$value['id'].']" value="'.$value['parent'].'"/>';
		
		$valarr[] = '<input type="text" id="shorturl_'.$value['id'].'" class="txt" name="shorturl['.$value['id'].']" value="'.$value['shorturl'].'"/>';
		$valarr[] = '<input type="text" id="name'.$value['id'].'" class="txt" name="name['.$value['id'].']" value="'.$value['name'].'"/>';
		$valarr[] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_type&op=del&id='.$value[id].'">'.cplang('delete').'</a>';
		showtablerow('id="td_'.$value['id'].'"', array('class="td25"', 'class="td25"','','',''), $valarr);
	}
	
	showtablerow('', array('colspan=3'), array(
			'<div><a href="javascript:;" onclick="addrow(this, 0, 1);return false;" class="addtr">'.cplang('add').'</a></div>'
		));

	//showsubmit('submit', 'submit','','');
	showsubmit('submit', 'submit', 'del', '', $multi);
	
	$adminurl = ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_type";
	
echo <<<SCRIPT
<script type="text/javascript">
var rowtypedata = [
	[[1,'', '','',''],[1,'<input type="text" class="txt" name="sortnew[]" value="0" />', 'td25'],[1,'<input type="text" class="txt" name="parentnew[]" value="0" />', 'td35'],[1,'<input type="text" class="txt" name="shorturlnew[]" value="" />', ''],[1,'<input type="text" class="txt" name="namenew[]" value="" />','']],
];

function refreshdistrict(province, city) {
	location.href = "$adminurl"
		+ "&province="+province+"&city="+city
		+"&pid="+$(province).value + "&cid="+$(city).value;
}

function editdistrict(did) {
	$('input_' + did).style.display = "block";
	$('span_' + did).style.display = "none";
}

function deletedistrict(did) {
	var elem = $('p_' + did);
	elem.parentNode.removeChild(elem);
	var elem = $('td_' + did);
	elem.parentNode.removeChild(elem);
}
</script>
SCRIPT;
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism��taobao��com*/
	
}else 
	{
		if(submitcheck('submit')){
	
	
		$success = lang('plugin/tp_exam', 'admin_common_success');
		
		
		$newids = array();
		$delarr = daddslashes($_GET['delete']);
		foreach($delarr as $id=>$v) 
		{
			DB::delete('tpexam_type', "id IN($v)");
		}
		
		if(!empty($_POST['parentnew'])) {
		$inserts = array();
		$displayorder = '';
		foreach(daddslashes($_POST['parentnew']) as $key => $value) {
			$parentnew = trim(daddslashes($_POST['parentnew'][$key]));
			$shorturlnew = trim(daddslashes($_POST['shorturlnew'][$key]));
			$namenew = trim(daddslashes($_POST['namenew'][$key]));
			$sortnew = trim(daddslashes($_POST['sortnew'][$key]));

			if(!empty($namenew)) {
				$inserts[] = "('','$parentnew', '$namenew','$shorturlnew',0,'$sort')";
				DB::query("INSERT INTO ".DB::table('tpexam_type')." (id , parent, name, shorturl , total, sort  ) VALUES ".implode(',',$inserts));
			}
			
			unset($inserts);
		}
		
	
	}


// ����
	$parent = daddslashes($_GET['parent']);

	if(is_array($parent)) {
		
		foreach($parent as $id => $val) {
			$par = intval(daddslashes($_GET['parent'][$id]));
			$shorturl = daddslashes($_GET['shorturl'][$id]);
			$name = daddslashes($_GET['name'][$id]);
			$sort = daddslashes($_GET['sort'][$id]);
			
			DB::update('tpexam_type', array(
				'parent' => $par,
				'shorturl' => $shorturl,
				'name' => $name,
				'total'=> 0,
				'sort'=>$sort,
				), "id='$id'");
				
		}
		
		
	}

	cpmsg($success, "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_type", 'succeed');
	
	}
	else
	{

		if(!empty($op))
		{
				DB::delete('tpexam_type', "id IN($id)");
				cpmsg(lang('plugin/tp_tuangou', 'admin_common_success'), "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_type", 'succeed');	
		}
	}

}
//From: d'.'is'.'m.tao'.'ba'.'o.com
?>