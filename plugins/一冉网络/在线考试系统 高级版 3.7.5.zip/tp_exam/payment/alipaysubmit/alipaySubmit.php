<?php

$subject    = $_GET['subject'];
$body    = $_GET['body'];
$total_fee    = $_GET['total_fee'];
$seller_email = $_GET['seller_email'];
$return_url    = $_GET['return_url'];
$buy_num    = $_GET['buy_num'];
$credit    = $_GET['credit'];
$uid    = $_GET['uid'];
$notify_url    = trim($_GET['notify_url']);

$param = $uid.'|'.$credit.'|'.$buy_num;
/*
echo 'subject='.$subject;
echo 'body='.$body;
echo 'total_fee='.$total_fee;
echo 'seller_email='.$seller_email;
echo 'return_url='.$return_url;
echo 'buy_num='.$buy_num;
echo 'credit='.$credit;
echo 'uid='.$uid;
echo 'notify_url='.$notify_url;
*/
?>

<html>
<head>
<title>alipay submit</title>
</head>
<body onload="alipayment.submit();">

<form name='alipayment' action='alipayapi.php' method='post'>
<input type='hidden' name='WIDseller_email'					value='<?php echo $seller_email; ?>'>
<input type='hidden' name='WIDout_trade_no'				value='<?php echo $param; ?>'>
<input type='hidden' name='WIDsubject'				value='<?php echo $subject; ?>'>
<input type='hidden' name='WIDprice'					value='<?php echo $total_fee; ?>'>
<input type='hidden' name='WIDbody'					value='<?php echo $body; ?>'>
<input type='hidden' name='return_url'					value='<?php echo $return_url; ?>'>
<input type='hidden' name='WIDshow_url'					value='<?php echo ''; ?>'>
<input type='hidden' name='WIDreceive_name'					value='<?php echo ''; ?>'>
<input type='hidden' name='WIDreceive_address'				value='<?php echo ''; ?>'>
<input type='hidden' name='WIDreceive_zip'					value='<?php echo ''; ?>'>
<input type='hidden' name='WIDreceive_phone'					value='<?php echo ''; ?>'>
<input type='hidden' name='WIDreceive_mobile'					value='<?php echo ''; ?>'>
<input type='hidden' name='item'					value='<?php echo $item; ?>'>
<input type='hidden' name='paysn'					value='<?php echo $paysn; ?>'>
<input type='hidden' name='buy_num'					value='<?php echo $buy_num; ?>'>
<input type='hidden' name='partner'					value='<?php echo $partner; ?>'>
<input type='hidden' name='key'					value='<?php echo $key; ?>'>
<input type='hidden' name='notify_url'					value='<?php echo $notify_url; ?>'>
</form>

</body>
</html>
