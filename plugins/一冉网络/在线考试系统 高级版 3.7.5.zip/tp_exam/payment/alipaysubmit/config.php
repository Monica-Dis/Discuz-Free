<?php
$alipay_config['partner']='2088902850837064';
$alipay_config['key']='c3lhny92suvyjjv1zkucq9onv12mtq2r';
?>