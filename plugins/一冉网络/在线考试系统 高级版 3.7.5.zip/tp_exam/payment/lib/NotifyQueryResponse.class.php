<?php
//---------------------------------------------------------
//֪ͨ��ѯ��Ӧ
//---------------------------------------------------------
require_once ("common/CommonResponse.class.php");
class NotifyQueryResponse extends CommonResponse{
	
	function NotifyQueryResponse($paraMap, $secretKey) {
		$this->CommonResponse($paraMap, $secretKey);
	}
	
}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>