<?

$WIDseller_email = $_GET['WIDseller_email'];
$WIDout_trade_no = $_GET['WIDout_trade_no'];
$WIDsubject = $_GET['WIDsubject'];
$WIDprice = $_GET['WIDprice'];
$WIDbody = $_GET['WIDbody'];
$WIDshow_url = $_GET['WIDshow_url'];
$WIDreceive_name = $_GET['WIDreceive_name'];
$WIDreceive_address = $_GET['WIDreceive_address'];
$WIDreceive_zip = $_GET['WIDreceive_zip'];
$WIDreceive_phone = $_GET['WIDreceive_phone'];
$WIDreceive_mobile = $_GET['WIDreceive_mobile'];

$partner = $_GET['partner'];
$key = $_GET['key'];
$return_url = $_GET['return_url'];
$buy_num = $_GET['buy_num'];
$uid = $_GET['uid'];
$credit    = $_GET['credit'];

$param = $uid.'|'.$credit.'|'.$buy_num;
?>

<html>
<head>
<title>To Dual Alipay</title>
</head>
<body onLoad="document.alipayment.submit();">

<form name='alipayment' action=alipayapi.php  method=post>
<input type='hidden' name='WIDseller_email'					value='<?php echo $WIDseller_email; ?>'>
<input type='hidden' name='WIDout_trade_no'					value='<?php echo $param; ?>'>
<input type='hidden' name='WIDsubject'					value='<?php echo $WIDsubject; ?>'>
<input type='hidden' name='WIDprice'					value='<?php echo $WIDprice; ?>'>
<input type='hidden' name='WIDbody'					value='<?php echo $WIDbody; ?>'>
<input type='hidden' name='WIDshow_url'					value='<?php echo $WIDshow_url; ?>'>
<input type='hidden' name='WIDreceive_name'					value='<?php echo $WIDreceive_name; ?>'>
<input type='hidden' name='WIDreceive_address'					value='<?php echo $WIDreceive_address; ?>'>
<input type='hidden' name='WIDreceive_zip'					value='<?php echo $WIDreceive_zip; ?>'>
<input type='hidden' name='WIDreceive_phone'					value='<?php echo $WIDreceive_phone; ?>'>
<input type='hidden' name='WIDreceive_mobile'					value='<?php echo $WIDreceive_mobile; ?>'>
<input type='hidden' name='partner'					value='<?php echo $partner; ?>'>
<input type='hidden' name='key'					value='<?php echo $key; ?>'>
<input type='hidden' name='return_url'					value='<?php echo $return_url; ?>'>
</form>

</body>
</html>