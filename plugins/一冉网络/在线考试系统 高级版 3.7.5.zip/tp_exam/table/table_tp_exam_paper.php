<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_tp_exam_paper extends discuz_table
{

	public function __construct() {

		$this->_table = 'tpexam_paper';
		$this->_pk    = 'id';

		parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	public function getdata(){
		return DB::fetch_all('SELECT * FROM '.DB::table($this->_table).' ORDER BY id ASC', null, $this->_pk);
	}
	
	public function get_paper_info($paperid)
	{
		if($paperid > 0){
			$paper = DB::fetch_first("select * from %t where `id`='%d'", array($this->_table, $paperid));
			return $paper;
		}
	}
	
	public function get_paper_by_typeidarr($typeidarr,$limitstart,$count,$payment){
		if(count($typeidarr) > 0){
			if($payment > 0){
				$payment == 2 ? $payment = 0:$payment;
				return DB::fetch_all("SELECT * FROM ".DB::table($this->_table)." WHERE belong IN (%n) and needcredit = %d order by sort desc limit %d,%d", array($typeidarr,$payment,$limitstart,$count));
			}
			else{
				return DB::fetch_all("SELECT * FROM ".DB::table($this->_table)." WHERE belong IN (%n) order by sort desc limit %d,%d", array($typeidarr,$limitstart,$count));
			}
		}
	}
	
	public function fetch_all_paper($limitstart,$count,$payment)
	{
		if($payment > 0){
			$payment == 2 ? $payment = 0:$payment;
			return DB::fetch_all("SELECT * FROM ".DB::table($this->_table)." where needcredit = %d order by id,order by id desc,sort desc limit %d,%d", array($payment,$limitstart,$count));
		}else{
			return DB::fetch_all("SELECT * FROM ".DB::table($this->_table)." order by id desc, sort desc limit %d,%d", array($limitstart,$count));
		}
	}
	
	public function fetch_count_by_typeid($typeidarr,$payment){
		if(count($typeidarr) > 0){
			if($payment > 0){
				$payment == 2 ? $payment = 0:$payment;
				return DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_paper')." where belong IN (%n) and needcredit = '$payment'",array($typeidarr));
			}else{
				return DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_paper')." where belong IN (%n)",array($typeidarr));
			}
		}
	}
	
	public function fetch_count($payment){
			if($payment > 0){
				$payment == 2 ? $payment = 0:$payment;
				return DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_paper')." where needcredit = '$payment'");
			}else{
				return DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_paper'));
			}
	}
	
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>