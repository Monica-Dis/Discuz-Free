<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class table_tp_exam_knowledge extends discuz_table{
	public function __construct() {

			$this->_table = 'tpexam_knowledge';
			$this->_pk    = 'id';

			parent::__construct(); /*dis'.'m.t'.'ao'.'bao.com*/
	}
	public function fetch_upid_by_id($id){
		return DB::result_first('SELECT upid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	public function fetch_subid_by_id($id){
		return DB::result_first('SELECT subid FROM %t WHERE id=%d',array($this->_table,$id));
	}
	public function fetch_all_by_upid($upid){
		return DB::fetch_all('SELECT * FROM %t WHERE upid=%d ORDER BY displayorder ASC',array($this->_table,$upid),'id');
	}
	public function fetch_all_by_type($type){
		return DB::fetch_all('select * from %t where id=%d ORDER BY displayorder ASC',array($this->_table,$type));
	}
	public function getlevel($typeid){
		return DB::result_first('select level from %t where id=%d ORDER BY displayorder ASC',array($this->_table,$typeid),'id');
	}
	
	public function fetch_all_sub_by_type($typeid)
	{
		$type =  DB::result_first('SELECT subid FROM %t WHERE id=%d ',array($this->_table,$typeid),'id');
		if($type){
			return DB::fetch_all('select * from %t where id IN ('.$type.') ORDER BY displayorder ASC',array($this->_table));
		}
	}
	
	public function fetch_rootid_by_id($typeid){
		$r = DB::result_first('SELECT upid FROM %t WHERE id=%d',array($this->_table,$typeid));
		$t = DB::result_first('SELECT upid FROM %t WHERE id=%d',array($this->_table,$r));
		return $t;
	}
	
	public function fetch_all_subtype_by_id($typeid){


		if($typeid==0){
			$subid = DB::fetch_all('select id from %t  ORDER BY displayorder ASC',array($this->_table,$typeid));
			foreach($subid as $k => $v){
				$ids[] = $v['id'];
			}
			$ids[] = 0;
			return $ids;
		}else{
			$subtype = DB::result_first('select subid from %t where id=%d',array($this->_table,$typeid),'id');
			$typesub = explode(",",$subtype);
			foreach($typesub as $key =>$subid){
				
				$thirdtype = DB::result_first('select subid from %t where id=%d',array($this->_table,$subid),'id');
				if($thirdtype){
					$subtype .= ",".$thirdtype;
				}
			}
			
			if($subtype){
				$subtype .= ",".$typeid;
			}else
			{
				$subtype .= $typeid;
			}
			
			return explode(",",$subtype) ;
		}
		
	}
	
	public function fetch_all_byname($typename,$level = 0)
	{
		return DB::result_first('SELECT * FROM %t WHERE subject=%s and level = %d',array($this->_table,$typename,$level));
	}
	
}




?>