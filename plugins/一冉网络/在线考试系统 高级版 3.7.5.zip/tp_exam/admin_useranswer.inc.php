<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


$user_answer = trim($_GET['useranswer']);
$delanswer = trim($_GET['delanswer']);

require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_paper_func.php";

if(!submitcheck('submit')) {

	$admin_exam_record_tips = lang('plugin/tp_exam', 'admin_exam_record_tips');
	$admin_exam_record_company = lang('plugin/tp_exam', 'admin_exam_record_company');
	$admin_exam_record_name = lang('plugin/tp_exam', 'admin_exam_record_name');
	$admin_exam_record_paper = lang('plugin/tp_exam', 'admin_exam_record_paper');
	$admin_exam_record_usetime = lang('plugin/tp_exam', 'admin_exam_record_usetime');
	$admin_exam_record_timedata = lang('plugin/tp_exam', 'admin_exam_record_timedata');
	$admin_exam_record_score = lang('plugin/tp_exam', 'admin_exam_record_score');
	$admin_common_delete = lang('plugin/tp_exam', 'admin_common_delete');

	$admin_common_op = lang('plugin/tp_exam', 'admin_common_op');
		
	showtips($admin_exam_record_tips);

	$totalnum = DB::result_first("SELECT count(*) FROM ".DB::table('tpexam_examrecord'));
		
	$multi = multi($totalnum, $pagenum, $page, ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_examrecord&app={$app}{$linkadd}");
		
	showformheader("plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_examrecord&useranswer=".$user_answer, 'order_submit');
	showtableheader();

	showtitle('Exam Number'.'&nbsp;'.$totalnum);

	
	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	$admin_record_addition = lang('plugin/tp_exam', 'admin_record_addition');
	$admin_record_image = lang('plugin/tp_exam', 'admin_record_image');
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_useranswer')." where belongrecord = $user_answer");

	showsubtitle(array('id',$admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type5,$admin_pub_type4,$admin_record_addition,$admin_common_op));
	
	$limit_start = $pagenum * ($page - 1);
	
	while($row = DB::fetch($query)) {
		
		if(!empty($row['serializedata'])){

			$uanswer = unserialize($row['serializedata']);

			$answer=array();
			foreach($uanswer as $k=>$val){

				$answer[] = $val;
			}
			
			
			include_once template('tp_exam:admin_answerrecord');
		}else{
			$valarr = array();
			$valarr[] = $row['id'];
			$valarr[] = getuseranswer($user_answer,'danxuan');
			$valarr[] = getuseranswer($user_answer,'duoxuan');
			$valarr[] = getuseranswer($user_answer,'panduan');
			$valarr[] = getuseranswer($user_answer,'tiankong');
			$valarr[] = getuseranswer($user_answer,'wenda');
			$valarr[] = '<input type="text" size="5" value="'.$row['addition'].'" name="addition['.$user_answer.']">';
			$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_examrecord&useranswer=".$row['id']."&delanswer=".$row['id']."\">".$admin_common_delete."</a>";
			showtablerow('id="td_'.$row['id'].'"', array('class="td25"','class="td35"', 'class="td35"','class="td35"','','','',''), $valarr);
			unset($valarr);
		}
	}
	
	showsubmit('additionsubmit', 'submit','','');
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism��taobao��com*/	

}
else
{
	if(!empty($delanswer)){
		DB::delete('tpexam_useranswer', "id IN($delanswer)");
	}
	else{
		foreach(daddslashes($_POST['addition']) as $key => $value) {
			DB::update('tpexam_useranswer',array('addition'=>$value),"id IN($key)");
		}
	}
	cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_examrecord', 'succeed');
}
//From: di'.'sm.t'.'aoba'.'o.com
?>