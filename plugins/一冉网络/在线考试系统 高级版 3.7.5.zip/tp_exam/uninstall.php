<?php
/*
	[dxtm.net!] (C)2001-2013 Inc.
	BY QQ:155121944  tp
*/


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql = '';


$sql = <<<EOF
DROP TABLE IF EXISTS `pre_tpexam_paper`;
DROP TABLE IF EXISTS `pre_tpexam_tiku_danxuan`;
DROP TABLE IF EXISTS `pre_tpexam_tiku_duoxuan`;
DROP TABLE IF EXISTS `pre_tpexam_tiku_panduan`;
DROP TABLE IF EXISTS `pre_tpexam_tiku_wenda`;
DROP TABLE IF EXISTS `pre_tpexam_timu`;
DROP TABLE IF EXISTS `pre_tpexam_tiku_peiwu`;
DROP TABLE IF EXISTS `pre_tpexam_type`;
DROP TABLE IF EXISTS `pre_tpexam_verify`;
DROP TABLE IF EXISTS `pre_tpexam_examrecord`;
DROP TABLE IF EXISTS `pre_tpexam_setting`;
DROP TABLE IF EXISTS `pre_tpexam_tiku_tiankong`;
DROP TABLE IF EXISTS `pre_tpexam_verify_data`;
DROP TABLE IF EXISTS `pre_tpexam_favorite`;
DROP TABLE IF EXISTS `pre_tpexam_tiku_yuedulijie`;
DROP TABLE IF EXISTS `pre_tpexam_permission`;
DROP TABLE IF EXISTS `pre_tpexam_useranswer`;
DROP TABLE IF EXISTS `pre_tpexam_buy`;
DROP TABLE IF EXISTS `pre_tpexam_paperctrl`;
DROP TABLE IF EXISTS `pre_tpexam_tiku_errorbook`;
DROP TABLE IF EXISTS `pre_tpexam_tiku_comment`;
DROP TABLE IF EXISTS `pre_tpexam_userexam_info`;
DROP TABLE IF EXISTS `pre_tpexam_userexam_questionstatus`;
DROP TABLE IF EXISTS `pre_tpexam_statistics`;
DROP TABLE IF EXISTS `pre_tpexam_tiku`;
DROP TABLE IF EXISTS `pre_tpexam_sclient`;
DROP TABLE IF EXISTS `pre_tpexam_sclient_class`;
DROP TABLE IF EXISTS `pre_tpexam_examscore`;
DROP TABLE IF EXISTS `pre_tpexam_chapter`;
DROP TABLE IF EXISTS `pre_tpexam_groups`;
DROP TABLE IF EXISTS `pre_tpexam_module`;
DROP TABLE IF EXISTS `pre_tpexam_module_item`;
EOF;


runquery($sql);

$finish = TRUE;

?>