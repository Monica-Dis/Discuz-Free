<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

setlocale(LC_ALL, 'zh_CN');
if($_G['charset'] == 'utf-8') {
	$utf8=true;
}

$act = daddslashes($_GET['act']);

if(!submitcheck('submit')&& empty($act) ) {

	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	
	$file = DISCUZ_ROOT."./source/plugin/tp_exam/module/module_verify.inc.php";
	if(!file_exists($file))
	{
		$admin_module_verify_notexist_tips = lang('plugin/tp_exam', 'admin_module_verify_notexist_tips');

		showtips($admin_module_verify_notexist_tips);
		die();
	}
	
	$skey = DB::result_first("SELECT name FROM ".DB::table('tpexam_verify'));
	$name = $skey;
	
	$skey = DB::result_first("SELECT company FROM ".DB::table('tpexam_verify'));
	$company = $skey;
	$skey = DB::result_first("SELECT idcard FROM ".DB::table('tpexam_verify'));
	$idcard = $skey;
	$skey = DB::result_first("SELECT student_id FROM ".DB::table('tpexam_verify'));
	$student_id = $skey;
	$skey = DB::result_first("SELECT verify_mode FROM ".DB::table('tpexam_verify'));
	$verify_mode = $skey;
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/module/module_verify.inc.php";
	
	
}else if(submitcheck('submit') && empty($act)){
	
		$idcard =  daddslashes($_POST['idcard']);
		$company =  daddslashes($_POST['company']);
		$usrname =  daddslashes($_POST['usrname']);
		$studentnum =  daddslashes($_POST['studentnum']);
		$verify_mode =  daddslashes($_POST['verify_mode']);


		DB::update('tpexam_verify', array(
     'name' => $usrname,
     'company' => $company,
     'idcard' => $idcard,
     'student_id' => $studentnum,
     'verify_mode' => $verify_mode,
    ),'id=1');
    
    cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_verify', 'succeed');
}
else if(submitcheck('submit') && $act=='upload')
{
		$filename = $_FILES['shoplogo']['name'];
		if($_FILES['shoplogo']['error'] != 0 && !empty($_FILES['shoplogo']['name'])) {
			echo 'File Not Exist';
			exit;
	}
	
	if(!empty($_FILES['shoplogo']['name']) && !in_array(strtolower(fileext($_FILES['shoplogo']['name'])), array('csv', 'gif', 'png'))) {
		echo 'File Not Support';
		exit;
	}
	
		$url = '';
 		$data = file($_FILES['shoplogo']['tmp_name']);
 		foreach ($data AS $line)
 		{
 			list($id,$username,$idcard,$company,$student,$uid,$belong)=explode(',',$line);
 			
 				if($utf8) {
					$username = iconv("gb2312","utf-8",$username);
					$company = iconv("gb2312","utf-8",$company);
				}
				DB::insert('tpexam_verify_data', array(
     	'username' => $username,
     	'company' => $company,
     	'idcard' => $idcard,
     	'student_id' => $student,
     	'uid'=>$uid,
     	'belongpaper'=>$belong));		
				
 		}
 		

    cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_verify', 'succeed');
    
}elseif(submitcheck('submit') && $act == 'del'){
	
	$delete = daddslashes($_GET['delete']);
	
	foreach($delete as $key=>$index){
		
		DB::delete('tpexam_verify_data',"id = '$index'");
	}
	cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_verify', 'succeed');
	
}

require_once DISCUZ_ROOT."./source/plugin/tp_exam/module/module_verify.inc.php";

?>