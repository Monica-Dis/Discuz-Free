<?php
/*
��ȡ�ϸ����
*/
function GetQualifiedTime($uid,$paperid)
{
	
	return $qualifiedTime;
}

function GetQualifiedLine($paperid)
{
	$skey = DB::result_first("SELECT value FROM ".DB::table('tpexam_module')." where module='qualified' and belongpaper=$paperid");
	
	return $skey;
}

function GetUserExamByData($uid,$paperid)
{
	$area = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord')." where uid = $uid and exam_type=$paperid order by date ASC");
	
	while($data = DB::fetch($query))
	{
		$area[] = $data;
	}
	
	return $area;
}
/*
GetOrderUserExamReport
*/
function GetOrderUserExamReport($userarr,$papid)
{

	$userarrorder=array();
	$userarrorderitem=array();
	
	foreach($userarr as $k=>$v)
	{
		//print_r($v);
		$currentuid = $v['uid'];
		
		if(!isset($fristuid))$fristuid = $v['uid'];;
		
		if(trim($currentuid) == trim($fristuid))
		{
			$userarrorderitem[]=$v;
		}
		else
		{
			$userexam = GetUserExamByData($fristuid,$papid);//�û��μ�ĳ���Ծ���ʱ���С���������
			
			unset($fristuid);
			$fristuid = $v['uid'];
			$userarrorder[]=$userexam;
			
			 unset($userexam);
		}
		
	}
	unset($userexam);
	$userexam = GetUserExamByData($fristuid,$papid);//�û��μ�ĳ���Ծ���ʱ���С���������
	$fristuid = $v['uid'];
	$userarrorder[]=$userexam;

	return $userarrorder;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>