<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
	if(!submitcheck('editsubmit')){
		
	showtips(lang('plugin/tp_exam', 'admin_verify_tips'));
	
  showformheader('plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_verify&act=del', 'editsubmit');
	showtableheader();

	$tdstyle = array('class="td35"','class="td35" ', 'class="td35"', 'class="td35"','class="td35"');
	$admin_tuan_verify_idcard = lang('plugin/tp_exam','admin_tuan_verify_idcard');
	$admin_tuan_verify_belongcompany = lang('plugin/tp_exam','admin_tuan_verify_belongcompany');
	$admin_tuan_verify_name = lang('plugin/tp_exam','admin_tuan_verify_name');
	$admin_tuan_verify_studentid = lang('plugin/tp_exam','admin_tuan_verify_studentid');
	$admin_tuan_verify_reserved1 = lang('plugin/tp_exam','admin_tuan_verify_reserved');
	$admin_tuan_verify_reserved2 = lang('plugin/tp_exam','admin_tuan_verify_reserved');
	$admin_tuan_verify_reserved3 = lang('plugin/tp_exam','admin_tuan_verify_reserved');
	$admin_tuan_verify_reserved4 = lang('plugin/tp_exam','admin_tuan_verify_reserved');

	showsubtitle(array('', $admin_tuan_verify_idcard,$admin_tuan_verify_belongcompany,$admin_tuan_verify_name,$admin_tuan_verify_studentid,$admin_tuan_verify_reserved1,$admin_tuan_verify_reserved2,$admin_tuan_verify_reserved2,$admin_tuan_verify_reserved2),'header',$tdstyle);

	$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_verify_data'));
	$perpage = 12;
	$page = max(1, intval($_GET['page']));
	$listStart = ($page-1) *$perpage;
	$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 
	$multi = multi($totalnum, $perpage, $page, "admin.php?action=plugins&operation=config&do=".$_GET['do']."&identifier=tp_exam&pmod=admin_verify",$pagecount);
			
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." order by id desc limit $listStart,$perpage");
	while($value = DB::fetch($query))
	{
		$valarr = array();
		$valarr[] = "<input type='checkbox' name='delete[]' value='$value[id]'/>ID:$value[id]";
		$valarr[] = $value['idcard'];
		$valarr[] = $value['company'];
		$valarr[] = $value['username'];
		$valarr[] = $value['student_id'];
		$valarr[] = '';
		$valarr[] = '';
		$valarr[] = '';
		$valarr[] = '';
		showtablerow('id="td_'.$value['id'].'"', array('class="td35" style="width:85px;"', 'class="td35"','class="td35"', 'class="td35"' ,'class="td35"','class="td35"','class="td35"', 'class="td35"' ,'class="td35"'), $valarr);
	}
	
	showsubmit('submit', 'submit', 'del', '', $multi);
	
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism��taobao��com*/
	
	showtips('&#x6280;&#x5DE7;&#x63D0;&#x793A;');
	
	include_once template('tp_exam:admin_verify');
}
//From: di'.'sm.t'.'aoba'.'o.com
?>