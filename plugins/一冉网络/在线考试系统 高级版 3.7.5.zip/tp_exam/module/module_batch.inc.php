<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	$admin_pub_type6 = lang('plugin/tp_exam', 'admin_pub_type6');
	$admin_pub_type7 = lang('plugin/tp_exam', 'admin_pub_type7');
	$admin_pub_type8 = lang('plugin/tp_exam', 'admin_pub_type8');

	$timu_type=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type5,$admin_pub_type4,$admin_pub_type6,$admin_pub_type7,$admin_pub_type8);

	$type = GetPaperType();
	$admin_belongtype = lang('plugin/tp_exam', 'admin_belongtype');
	$admin_exam_batch_csv = lang('plugin/tp_exam', 'admin_exam_batch_csv');

	showtips(lang('plugin/tp_exam', 'admin_type_tips'));

	
	include_once template('tp_exam:admin_csv');
	
?>