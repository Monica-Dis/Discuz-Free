<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_paper_func.php";
	
	$needpay = intval($_GET['needpay']);
	$buy_credits_number = daddslashes($_GET['buy_credits_number']);
	
	if(!$_G['uid']){
		$exam_must_login_tips=lang('plugin/tp_exam', 'exam_must_login_tips');
		showmessage($exam_must_login_tips, NULL, array(), array('login' => 1));
	}
	
	if(!submitcheck('submit')) {
		$config = array();
		global $_G;
		$config = $_G['cache']['plugin']['tp_exam'];
		$buypaper_credit_type=$config['buypaper_credit_type'];
		$uid = $_G['uid'];
		$addcredit = 'extcredits'.$buypaper_credit_type;

		$needcredit = GetNeedCredits($needpay);
		$extcredit = GetCurrentCreditsbyExt($_G['uid'],$addcredit);
		$extcredit = DB::result_first("SELECT $addcredit FROM ".DB::table('common_member_count')." WHERE uid = '$uid'");
		
		include template('tp_exam:buy_credit');
	}
	else
	{
		$item = intval($_GET['item']);
		session_start();
		
		$config = array();
		global $_G;
		$config = $_G['cache']['plugin']['tp_exam'];
		$buypaper_credit_type=$config['buypaper_credit_type'];
		$admin_tpgao_use_credits_low = lang('plugin/tp_exam','admin_tpgao_use_credits_low');
	
		$addcredit = 'extcredits'.$buypaper_credit_type;
		
		$uid = $_G['uid'];

		$credits = DB::result_first("SELECT ".$addcredit." FROM ".DB::table('common_member_count')." where uid = $_G[uid]");

		if($credits < $buy_credits_number){
			showmessage($admin_tpgao_use_credits_low, "plugin.php?id=tp_exam:index", 'succeed');
		}
		
		updatemembercount($uid, array($addcredit => -$buy_credits_number));
		
		//$_SESSION['credits_buyed_'.$item]=1;
		$aftercredit = DB::result_first("SELECT ".$addcredit." FROM ".DB::table('common_member_count')." where uid = $_G[uid]");
		//���ݿ��¼
		WriteBuyRecordDB($uid,$buypaper_credit_type,$item,$buy_credits_number,$credits,$aftercredit);
		
		include_once libfile('function/credit');
		$log['extcredits'.$buypaper_credit_type] = -$buy_credits_number;
		credit_log($_G['uid'], '', $_G['uid'], $log,"&#x8BD5;&#x5377;&#x8D2D;&#x4E70;","&#x8003;&#x8BD5;&#x79EF;&#x5206;&#x53D8;&#x52A8;");
				
		require_once libfile ( 'include/common','plugin/tp_exam' );
		
		if(checkmobile()){
			showmessage(lang('plugin/tp_exam', 'exam_buy_success'), "plugin.php?id=tpgao_m:m&mod=exam&item=".$item."&formhash=".formhash(), 'succeed');
		}
		
		
		$exammode = GetCommonExamLink();
		if($exammode){
			showmessage(lang('plugin/tp_exam', 'exam_buy_success'), "plugin.php?id=tpgao_singleexam&paperid=$needpay", 'succeed');
		}else{
			showmessage(lang('plugin/tp_exam', 'exam_buy_success'), "plugin.php?id=tp_exam:index&mod=exam&item=".$item, 'succeed');
		}
		

	}
//From: di'.'sm.t'.'aoba'.'o.com
?>