<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

global $_G;

if(!submitcheck('submit')) {

	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/syn.inc.php";
	$singleexam =  DISCUZ_ROOT."./source/plugin/tpgao_singleexam/tpgao_singleexam.inc.php";

	showtips(lang('plugin/tp_exam', 'admin_type_tips'));
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='single_five'");
	
	$exam_timu_yes=lang('plugin/tp_exam', 'exam_timu_yes');
	$exam_timu_no=lang('plugin/tp_exam', 'exam_timu_no');
	$exam_common_null=lang('plugin/tp_exam', 'exam_common_null');
	
	$forum = GetForum();

	$single_five = $skey['single_five'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='support_g'");
	$support_g_permission = $skey['support_g'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='support_g'");
	$support_g = $skey['support_g'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='nocopy'");
	$nocopy_permission  = $skey['nocopy'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='nocopy'");
	$nocopy = $skey['nocopy'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='syn_bbs'");
	$bbs_syn = $skey;
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='skippaper'");
	$skippaper = $skey['skippaper'];

	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='comment_question_p'");
	$comment_question_p  = $skey['comment_question_p'];
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='comment_question'");
	$comment_question = $skey['comment_question'];
	
	$questionimg = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='questionimg'");

	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='kaoshisyn'");
	$kaoshisyn  = $skey['kaoshisyn'];

	$opensingleexam = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='opensingleexam'");
	$usegroups = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='usegroups'");
	
	include_once template('tp_exam:admin_setting');
	
}else if(submitcheck('submit')){
		
	$single_five =  daddslashes($_POST['single_five']);
	$support_g =  daddslashes($_POST['support_g']);
	$nocopy =  daddslashes($_POST['nocopy']);
	$syn_bbs =  daddslashes($_POST['syn_bbs']);
	$skippaper =  daddslashes($_POST['skippaper']);
	$comment_question =  daddslashes($_POST['comment_question']);
	$opensingleexam =  intval($_POST['opensingleexam']);
	$questionimg =  intval($_POST['questionimg']);
	$usegroups =  intval($_POST['usegroups']);

	//���µ�ѡ��
	DB::update('tpexam_setting', array(	'svalue' => $single_five),"skey='single_five'");
	DB::update('tpexam_setting', array(	'svalue' => $support_g),"skey='support_g'");
	DB::update('tpexam_setting', array(	'svalue' => $nocopy),"skey='nocopy'");
	DB::update('tpexam_setting', array(	'svalue' => $syn_bbs),"skey='syn_bbs'");
	DB::update('tpexam_setting', array(	'svalue' => $skippaper),"skey='skippaper'");
	DB::update('tpexam_setting', array(	'svalue' => $comment_question),"skey='comment_question'");
	DB::update('tpexam_setting', array(	'svalue' => $opensingleexam),"skey='opensingleexam'");
	DB::update('tpexam_setting', array(	'svalue' => $questionimg),"skey='questionimg'");
	DB::update('tpexam_setting', array(	'svalue' => $usegroups),"skey='usegroups'");
	
	cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tp_exam&pmod=admin_setting', 'succeed');
	

}
//From: di'.'sm.t'.'aoba'.'o.com
?>