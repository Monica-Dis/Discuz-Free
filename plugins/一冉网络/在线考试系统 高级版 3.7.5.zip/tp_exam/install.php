<?php

/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_tpexam_examrecord` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `exam_type` int(11) NOT NULL,
  `usetime` int(11) NOT NULL,
  `date` varchar(256) NOT NULL,
  `score` int(11) NOT NULL,
  `verifyid` int(11) NOT NULL,
  `uniquecode` varchar(256) NOT NULL,
  `requestevaluate` varchar(256) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM   ;

CREATE TABLE IF NOT EXISTS `pre_tpexam_paper` (
  `id` int(11) NOT NULL auto_increment,
  `belong` int(11) NOT NULL,
  `shorturl` varchar(256) NOT NULL,
  `name` varchar(256) NOT NULL,
  `papertime` varchar(256) NOT NULL,
  `needlogin` int(11) NOT NULL,
  `needpay` int(11) NOT NULL,
  `practise` int(11) NOT NULL,
  `rand` int(11) NOT NULL,
  `showanswer` int(11) NOT NULL,
  `paperinfo` varchar(1024) NOT NULL,
  `paper_timu_item_desc` varchar(1024) NOT NULL,
  `examgroup` varchar(256) NOT NULL,
  `needcredit` int(11) NOT NULL,
  `buycredits` int(11) NOT NULL,
  `buyonlyonce` int(11) NOT NULL,
  `auditing` int(11) NOT NULL,
  `pubuid` int(11) NOT NULL,
  `random_item` varchar(256) NOT NULL,
  `examtimes` int(11) NOT NULL,
  `usetimespan` int(11) NOT NULL,
  `startexamtime` varchar(256) NOT NULL,
  `endexamtime` varchar(256) NOT NULL,
  `paper_no_pause` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `paperscore` int(11) NOT NULL,
  `questionnumber` int(11) NOT NULL,
  `password` varchar(256) NOT NULL,
  `verifylogintimes` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `usescorescheme` int(11) NOT NULL,
  `usesysprofile` int(11) NOT NULL,
  `paperdata` int(11) NOT NULL,
  `openmedal` int(11) NOT NULL,
  `price` varchar(50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku_danxuan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ask` varchar(1024) NOT NULL,
  `option1` varchar(512) NOT NULL,
  `option2` varchar(512) NOT NULL,
  `option3` varchar(512) NOT NULL,
  `option4` varchar(512) NOT NULL,
  `option5` varchar(512) NOT NULL,
  `option6` varchar(512) NOT NULL,
  `option7` varchar(512) NOT NULL,
  `answer` varchar(256) NOT NULL,
  `belong_paper` int(11) NOT NULL,
  `score` double NOT NULL,
  `data` varchar(256) NOT NULL,
  `publish_uid` int(11) NOT NULL,
  `viewParser_credits` int(11) NOT NULL,
  `answer_parser` text NOT NULL,
  `yuedulijie_timutype` int(11) NOT NULL,
  `image` varchar(512) NOT NULL,
  `audio` varchar(512) NOT NULL,
  `video` varchar(512) NOT NULL,
  `parser_img_path` varchar(512) NOT NULL,
  `tid` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `peiwu` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  `optionscore` varchar(20) NOT NULL,
  `flowchart` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku_duoxuan` (
  `id` int(11) NOT NULL auto_increment,
  `ask` varchar(1024) NOT NULL,
  `option1` varchar(512) NOT NULL,
  `option2` varchar(512) NOT NULL,
  `option3` varchar(512) NOT NULL,
  `option4` varchar(512) NOT NULL,
  `option5` varchar(512) NOT NULL,
  `option6` varchar(512) NOT NULL,
  `option7` varchar(512) NOT NULL,
  `answer1` varchar(50) NOT NULL,
  `answer2` varchar(50) NOT NULL,
  `answer3` varchar(50) NOT NULL,
  `answer4` varchar(50) NOT NULL,
  `answer5` varchar(50) NOT NULL,
  `answer6` varchar(50) NOT NULL,
  `answer7` varchar(50) NOT NULL,
  `belong_paper` int(11) NOT NULL,
  `score` double NOT NULL,
  `data` varchar(256) NOT NULL,
  `publish_uid` int(11) NOT NULL,
  `viewParser_credits` int(11) NOT NULL,
  `answer_parser` text NOT NULL,
  `yuedulijie_timutype` int(11) NOT NULL,  
  `image` varchar(512) NOT NULL,
  `audio` varchar(512) NOT NULL,
  `video` varchar(512) NOT NULL,
  `parser_img_path` varchar(512) NOT NULL,
  `tid` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `peiwu` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM   ;

CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku_tiankong` (
  `id` int(11) NOT NULL auto_increment,
  `ask` varchar(1024) NOT NULL,
  `answer` varchar(256) NOT NULL,
  `score` double NOT NULL,
  `belong_paper` int(11) NOT NULL,
  `data` varchar(256) NOT NULL,
  `publish_uid` int(11) NOT NULL,
  `viewParser_credits` int(11) NOT NULL,
  `answer_parser` varchar(2048) NOT NULL,
  `yuedulijie_timutype` int(11) NOT NULL,
  `image` varchar(512) NOT NULL,
  `audio` varchar(512) NOT NULL,
  `video` varchar(512) NOT NULL,
  `parser_img_path` varchar(512) NOT NULL,
  `tid` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku_panduan` (
  `id` int(11) NOT NULL auto_increment,
  `ask` varchar(1024) NOT NULL,
  `answer` int(11) NOT NULL,
  `belong_paper` int(11) NOT NULL,
  `score` double NOT NULL,
  `data` varchar(256) NOT NULL,
  `publish_uid` int(11) NOT NULL,
  `viewParser_credits` int(11) NOT NULL,
  `answer_parser` varchar(2048) NOT NULL,
  `yuedulijie_timutype` int(11) NOT NULL,
  `image` varchar(512) NOT NULL,
  `audio` varchar(512) NOT NULL,
  `video` varchar(512) NOT NULL,
  `parser_img_path` varchar(512) NOT NULL,
  `tid` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM   ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku_wenda` (
  `id` int(11) NOT NULL auto_increment,
  `ask` varchar(1024) NOT NULL,
  `answer` varchar(1024) NOT NULL,
  `belong_paper` int(11) NOT NULL,
  `score` double NOT NULL,
  `data` varchar(256) NOT NULL,
  `publish_uid` int(11) NOT NULL,
  `viewParser_credits` int(11) NOT NULL,
  `answer_parser` varchar(2048) NOT NULL,
  `yuedulijie_timutype` int(11) NOT NULL,
  `image` varchar(512) NOT NULL,
  `audio` varchar(512) NOT NULL,
  `video` varchar(512) NOT NULL,
  `parser_img_path` varchar(512) NOT NULL,
  `tid` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_chapter` (
  `id` int(11) NOT NULL auto_increment,
  `chaptername` varchar(256) NOT NULL,
  `belongnode` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;

CREATE TABLE IF NOT EXISTS `pre_tpexam_timu` (
  `id` int(11) NOT NULL auto_increment,
  `timu` varchar(1024) NOT NULL,
  `answer1` varchar(256) NOT NULL,
  `answer2` varchar(256) NOT NULL,
  `answer3` varchar(256) NOT NULL,
  `answer4` varchar(256) NOT NULL,
  `daan1` varchar(256) NOT NULL,
  `daan2` varchar(256) NOT NULL,
  `daan3` varchar(256) NOT NULL,
  `daan4` varchar(256) NOT NULL,
  `belongtype` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM   ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_type` (
  `id` int(11) NOT NULL auto_increment,
  `parent` int(11) NOT NULL,
  `name` varchar(256) NOT NULL,
  `shorturl` varchar(256) NOT NULL,
  `total` int(11) NOT NULL,
  `sort` int(11) NOT NULL,
  `up` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_verify` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `name` int(11) NOT NULL,
  `company` int(11) NOT NULL,
  `idcard` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `verify_mode` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  ;

INSERT INTO `pre_tpexam_verify` (
`id` ,
`uid` ,
`name` ,
`company` ,
`idcard` ,
`student_id` ,
`verify_mode`
)
VALUES (
NULL ,  '1',  '1',  '1',  '1',  '1',  '1'
);


CREATE TABLE IF NOT EXISTS `pre_tpexam_setting` (
  `skey` varchar(256) NOT NULL,
  `svalue` varchar(1024) NOT NULL,
  PRIMARY KEY (`skey`)
) ENGINE=MyISAM;


INSERT INTO `pre_tpexam_setting` (`skey`, `svalue`) VALUES
('single_five', '0'),
('support_g', '0'),
('mobile', '1'),
('nocopy', '0'),
('syn_bbs', '0'),
('skippaper', '0'),
('paper_exam_times_reach_msg', '0'),
('paper_exam_time_span_msg', '0'),
('comment_question', '0'),
('opensingleexam', '0'),
('questionimg', '0'),
('usegroups', '0'),
('pay', 'a:4:{s:8:"alipayid";s:16:"2088902850837064";s:9:"alipaykey";s:32:"c3lhny92suvyjjv1zkucq9onv12mtq2r";s:10:"alipayuser";s:18:"13865513822@qq.com";s:10:"alipaytype";s:1:"2";}');


CREATE TABLE IF NOT EXISTS `pre_tpexam_favorite` (
  `id` int(11) NOT NULL auto_increment,
  `favorite_belongpaper` int(11) NOT NULL,
  `date` varchar(256) NOT NULL,
  `deserved1` int(11) NOT NULL,
  `deserved2` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_verify_data` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(256) NOT NULL,
  `idcard` varchar(256) NOT NULL,
  `company` varchar(256) NOT NULL,
  `student_id` varchar(256) NOT NULL,
   `logintimes` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `belongpaper` int(11) NOT NULL,
  `uniquecode` varchar(256) NOT NULL,
  `identifycode` varchar(256) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_module` (
  `id` int(11) NOT NULL auto_increment,
  `module` varchar(256) NOT NULL,
  `reserved` int(11) NOT NULL,
  `value` varchar(256) NOT NULL,
  `belongpaper` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_module_item` (
  `id` int(11) NOT NULL auto_increment,
  `modulename` varchar(256) NOT NULL,
  `moduledesc` varchar(256) NOT NULL,
  `modulefailtips` varchar(256) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku_peiwu` (
  `id` int(11) NOT NULL auto_increment,
  `ask` varchar(1024) NOT NULL,
  `belong_paper` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `nickname` varchar(256) NOT NULL,
  `option1` varchar(256) NOT NULL,
  `option2` varchar(256) NOT NULL,
  `option3` varchar(256) NOT NULL,
  `option4` varchar(256) NOT NULL,
  `option5` varchar(256) NOT NULL,
  `option6` varchar(256) NOT NULL,
  `option7` varchar(256) NOT NULL,
  `answer1` varchar(256) NOT NULL,
  `answer2` varchar(256) NOT NULL,
  `answer3` varchar(256) NOT NULL,
  `answer4` varchar(256) NOT NULL,
  `answer5` varchar(256) NOT NULL,
  `answer6` varchar(256) NOT NULL,
  `answer7` varchar(256) NOT NULL,
  `data` varchar(256) NOT NULL,
  `publish_uid` int(11) NOT NULL,
  `viewParser_credits` int(11) NOT NULL,
  `answer_parser` varchar(1024) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_permission` (
  `id` int(11) NOT NULL auto_increment,
  `skey` varchar(256) NOT NULL,
  `svalue` varchar(256) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM   ;


INSERT INTO `pre_tpexam_permission` (`id`, `skey`, `svalue`) VALUES
(1, 'yuedulijie', '0'),
(2, 'upload_video', '0');


CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku_yuedulijie` (
  `id` int(11) NOT NULL auto_increment,
  `ask` varchar(1024) NOT NULL,
  `child_danxuan` varchar(256) NOT NULL,
  `belong_paper` int(11) NOT NULL,
  `score` int(11) NOT NULL,
  `nickname` varchar(256) NOT NULL,
  `image` varchar(512) NOT NULL,
  `video` varchar(512) NOT NULL,
  `content` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM   ;




CREATE TABLE IF NOT EXISTS `pre_tpexam_useranswer` (
  `id` int(11) NOT NULL auto_increment,
  `belongrecord` int(11) NOT NULL,
  `danxuan` varchar(1024) NOT NULL,
  `duoxuan` varchar(1024) NOT NULL,
  `panduan` varchar(1024) NOT NULL,
  `tiankong` varchar(1024) NOT NULL,
  `wenda` varchar(1024) NOT NULL,
  `addition` varchar(256) NOT NULL,
  `wendauserimage` varchar(1024) NOT NULL,
  `serializedata` text NOT NULL,
  `imgserializedata` text NOT NULL,
  `source` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_buy` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `paperid` int(11) NOT NULL,
  `buynum` int(11) NOT NULL,
  `buytime` varchar(256) NOT NULL,
  `creditstype` int(11) NOT NULL,
  `finish` int(11) NOT NULL,
  `orderid` varchar(256) NOT NULL,
  `precredit` varchar(20) NOT NULL,
  `aftercredit` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_paperctrl` (
  `id` int(11) NOT NULL auto_increment,
  `paperid` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `examtimes` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku_errorbook` (
  `id` int(11) NOT NULL auto_increment,
  `errortype` int(11) NOT NULL,
  `errorid` int(11) NOT NULL,
  `errortimes` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `paperid` int(11) NOT NULL,
  `errordata` varchar(50) NOT NULL,
  `righttimes` int(11) NOT NULL,
  `rightratio` varchar(256) NOT NULL,
  `wrongratio` varchar(256) NOT NULL,
  `lastwrongdata` int(11) NOT NULL,
  `tikuid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM   ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku_comment` (
  `id` int(11) NOT NULL auto_increment,
  `comment` varchar(1024) NOT NULL,
  `uid` int(11) NOT NULL,
  `question_rank` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `question_type` int(11) NOT NULL,
  `upvote` int(11) NOT NULL,
  `oppose` int(11) NOT NULL,
  `postdata` varchar(256) NOT NULL,
  `postip` varchar(256) NOT NULL,
  `username` varchar(256) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM ;

CREATE TABLE IF NOT EXISTS `pre_tpexam_userexam_info` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `paperid` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `right` int(11) NOT NULL,
  `unexamed` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_userexam_questionstatus` (
  `id` int(11) NOT NULL auto_increment,
  `paperid` int(11) NOT NULL,
  `questiontype` int(11) NOT NULL,
  `questionid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `qright` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `eid` int(11) NOT NULL,
  `examed` int(11) NOT NULL,
	`rightratio` int(11) NOT NULL,
  `lastdata` int(11) NOT NULL,
  `wrongratio` int(11) NOT NULL,
  `lastquestion` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_tiku` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `oid` int(11) NOT NULL,
  `groupid` int(11) NOT NULL,
  `paperid` int(11) NOT NULL,
  `examed` int(11) NOT NULL,
  `subject` text NOT NULL,
  `addtime` int(11) NOT NULL,
  `result` varchar(256) NOT NULL,
  `option` text NOT NULL,
  `parser` text NOT NULL,
  `image` text NOT NULL,
  `score` float NOT NULL,
  `viewParser_credits` int(11) NOT NULL,
  `peiwu` int(11) NOT NULL,
  `yuedulijie` int(11) NOT NULL,
  `bindid` int(11) NOT NULL,
  `optionscore` varchar(20) NOT NULL,
  `video` varchar(256) NOT NULL,
  `flowchart` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  ;



CREATE TABLE IF NOT EXISTS `pre_tpexam_statistics` (
  `id` int(11) NOT NULL auto_increment,
  `lasttype` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_sclient` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `username` varchar(256) NOT NULL,
  `class` int(11) NOT NULL,
  `rate` double NOT NULL,
  `accuracy` double NOT NULL,
  `year` int(11) NOT NULL,
  `profress` varchar(256) NOT NULL,
  `edu` varchar(256) NOT NULL,
  `university` int(11) NOT NULL,
  `city` int(11) NOT NULL,
  `district` int(11) NOT NULL,
  `needupdate` int(11) NOT NULL,
  `progress` double NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_sclient_class` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(256) NOT NULL,
  `classid` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_examscore` (
  `id` int(11) NOT NULL auto_increment,
  `schemename` varchar(256) NOT NULL,
  `right1` double NOT NULL,
  `right2` double NOT NULL,
  `right3` double NOT NULL,
  `right4` double NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_groups` (
  `id` int(11) NOT NULL auto_increment,
  `paperid` int(11) NOT NULL,
  `subject` text NOT NULL,
  `content` text NOT NULL,
  `grouprand` int(11) NOT NULL,
  `displayorder` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


CREATE TABLE IF NOT EXISTS `pre_tpexam_knowledge` (
  `id` int(11) NOT NULL auto_increment,
  `level` int(11) NOT NULL,
  `upid` int(11) NOT NULL,
  `subid` varchar(256) NOT NULL,
  `subject` varchar(256) NOT NULL,
  `displayorder` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM ;

EOF;

runquery($sql);


if(file_exists(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')) {
	$pluginid = 'tp_exam';
	$Hooks = array('forumdisplay_topBar', 'forumdisplay_sideBar', 'viewthread_topBar', 'viewthread_sideBar');
	$data = array();
	foreach($Hooks as $Hook) {
		$data[] = array($Hook => array('plugin' => $pluginid, 'include' => 'api.class.php', 'class' => $pluginid.'_api', 'method' => $Hook));
	}
	require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
	WeChatHook::updateAPIHook($data);
}


$finish = TRUE;

?>