<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

	showtips(lang('plugin/tp_exam', 'admin_help_tips'));
	
	/*1109907225*/
	
	showtips('&#x5EFA;&#x8BAE;&#x8003;&#x8BD5;&#x7CFB;&#x7EDF;&#x914D;&#x5408;&#x4EE5;&#x4E0B;&#x63D2;&#x4EF6;&#x4F7F;&#x7528;&#xFF0C;&#x6548;&#x679C;&#x66F4;&#x597D;');
	
	echo '<br><br>';
	echo '<font color="red">&#x5728;&#x7EBF;&#x89C6;&#x9891;&#x7F51;&#x6821;&#x6559;&#x80B2;</font>:'.'<a href="http://dism.taobao.com/?@tpgao_edu.plugin">http://dism.taobao.com/?@tpgao_edu.plugin</a><br><br>';
	echo '<font color="red">&#x5728;&#x7EBF;&#x95EE;&#x7B54;&#x6559;&#x80B2;&#x5E73;&#x53F0;</font>:'.'<a href="http://dism.taobao.com/?@tpgao_wenda.plugin">http://dism.taobao.com/?@tpgao_wenda.plugin</a><br><br>';
	
?>