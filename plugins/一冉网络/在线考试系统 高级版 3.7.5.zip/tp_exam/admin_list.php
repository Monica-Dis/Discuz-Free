<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')|| !defined('IN_ADMINCP') ) {
    exit('Access Denied');
}

//��ȡ������Ϣ


	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	$admin_pub_type6 = lang('plugin/tp_exam', 'admin_pub_type6');
	$admin_pub_type7 = lang('plugin/tp_exam', 'admin_pub_type7');
	$exam_common_null = lang('plugin/tp_exam', 'exam_common_null');
	
	
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='tiankong_p'");
	$tiankong_p = $skey['tiankong_p'];
	if($tiankong_p!=1){$admin_pub_type5 = 'NULL';}
	
	$timu_type=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5);
	
	//ģ����
	if($yuedulijie==1){
		$timu_type[]=$admin_pub_type6;
	}else{
	$timu_type[]= '';
	}
		
	if($peiwu==1){
		$timu_type[]=$admin_pub_type7;
	}else{
		$timu_type[]='';
	}
	
	$id = lang('plugin/tp_exam', 'xuhao');
	$shorturl = lang('plugin/tp_exam', 'tihao');
	$name = lang('plugin/tp_exam', 'timu');
	$op = lang('plugin/tp_exam', 'daan');
	
	$exam_timu_backup = lang('plugin/tp_exam', 'exam_timu_backup');
	$exam_timu_corrent = lang('plugin/tp_exam', 'exam_timu_corrent');
	$exam_timu_yes = lang('plugin/tp_exam', 'exam_timu_yes');
	$exam_timu_no = lang('plugin/tp_exam', 'exam_timu_no');
	$exam_timu_wenda_tips = lang('plugin/tp_exam', 'exam_timu_wenda_tips');
	$exam_timu_tiankong_tips1 = lang('plugin/tp_exam', 'exam_timu_tiankong_tips1');
	$exam_timu_tiankong_tips2 = lang('plugin/tp_exam', 'exam_timu_tiankong_tips2');
	$exam_timu_tiankong_tips3 = lang('plugin/tp_exam', 'exam_timu_tiankong_tips3');
	
	showtips(lang('plugin/tp_exam', 'admin_type_tips'));
	
	$query = DB::query('SELECT * FROM '.DB::table('tpexam_paper')." order by id desc");
	
	if($usegroups){
		$groups = getpapergroupjson();
		$groups = array2json($groups);
	}else{
		$groups = getpaperyuedujson();
		$groups = array2json($groups);
	}
	
	include_once template('tp_exam:admin_pubexam');
	
	
	function getpapergroupjson()
	{
		$papergroups=array();
		
		$query = DB::query("select * from ".DB::table('tpexam_groups'));
		
		while($d = DB::fetch($query)){
			$papergroup['subject'] = $d['subject'];
			$papergroup['id'] = $d['id'];
			
			$papergroups[$d['paperid']][]=$papergroup;
		}
		
		return $papergroups;
	}
	
	function getpaperyuedujson()
	{
		$papergroups=array();
		
		$query = DB::query("select * from ".DB::table('tpexam_tiku_yuedulijie'));
		
		while($d = DB::fetch($query)){
			$papergroup['subject'] = $d['ask'];
			$papergroup['id'] = $d['id'];
			
			$papergroups[$d['belong_paper']][]=$papergroup;
		}
		
		return $papergroups;
	}
	
	function array2json($arr) {
    //if(function_exists('json_encode')) return json_encode($arr); //Lastest versions of PHP already has this functionality. 
    $parts = array(); 
    $is_list = false; 

    //Find out if the given array is a numerical array 
    $keys = array_keys($arr); 
    $max_length = count($arr)-1; 
    if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1 
        $is_list = true; 
        for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position 
            if($i != $keys[$i]) { //A key fails at position check. 
                $is_list = false; //It is an associative array. 
                break; 
            } 
        } 
    } 

    foreach($arr as $key=>$value) { 
        if(is_array($value)) { //Custom handling for arrays 
            if($is_list) $parts[] = array2json($value); /* :RECURSION: */ 
            else $parts[] = '"' . $key . '":' . array2json($value); /* :RECURSION: */ 
        } else { 
            $str = ''; 
            if(!$is_list) $str = '"' . $key . '":'; 

            //Custom handling for multiple data types 
            if(is_numeric($value)) $str .= $value; //Numbers 
            elseif($value === false) $str .= 'false'; //The booleans 
            elseif($value === true) $str .= 'true'; 
            else $str .= '"' . addslashes($value) . '"'; //All other things 
            // :TODO: Is there any more datatype we should be in the lookout for? (Object?) 
			$str = str_replace(array("\r\n","\n"),"\\n", $str);
            $parts[] = $str; 
        } 
    } 
    $json = implode(',',$parts); 
     
    if($is_list) return '[' . $json . ']';//Return numerical JSON 
    return '{ ' . $json . ' }';//Return associative JSON 
}
//From: d'.'is'.'m.tao'.'ba'.'o.com
?>
