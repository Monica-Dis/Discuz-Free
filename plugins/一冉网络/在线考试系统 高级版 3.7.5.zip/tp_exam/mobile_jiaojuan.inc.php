<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: test.php 33234 2013-12-20 22:59:14Z mpage $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//��ȡ������Ϣ

require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/mobile_func.php";
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";

$config = $_G['cache']['plugin']['tp_exam'];

$item = daddslashes($_GET['item']);
$type = daddslashes($_GET['type']);
$comebyexam = daddslashes($_GET['comebyexam']);

if(empty($comebyexam)){header("location:plugin.php?id=tp_exam:mobile_exam&item={$item}");die();}

if(empty($item)){header("location:plugin.php?id=tp_exam:mobile_home");die();}

$filter = in_array($type, array('0', '1', '2','3','4')) ? $type : '0';


$json_answer_danxuan = daddslashes($_POST['json_answer_danxuan']);
$json_answer_duoxuan = daddslashes($_POST['json_answer_duoxuan']);
$json_answer_panduan = daddslashes($_POST['json_answer_panduan']);
$json_answer_tiankong = daddslashes($_POST['json_answer_tiankong']);


$total_score = 0;

$danxuan_a = explode("_",$json_answer_danxuan);
$duoxuan_a = explode("_",$json_answer_duoxuan);
$panduan_a = explode("_",$json_answer_panduan);
$tiankong_a = explode("_",$json_answer_tiankong);


$danxuan = GetDaXuanByPaperID($item);

$duoxuan = GetDuoXuanByPaperID($item);
$panduan = GetPanduanByPaperID($item);
$tiankong = GetTiankongByPaperID($item);
$wenda = GetWendaByPaperID($item);
//�������Ҫ�ദ��һ�������������Ŀ
$tiankong_ask = GetTiankongAsk_m($tiankong);


$danxuan_answer = GetAnswerByPaperID_DanXuan_m($item,$danxuan_a);
$duoxuan_answer = GetAnswerByPaperID_DuoXuan_m($item,$duoxuan_a);
$panduan_answer = GetAnswerByPaperID_Panduan_m($item,$panduan_a);
$tiankong_answer = GetAnswerByPaperID_Tiankong_m($item,$tiankong_a);

//�����ֵ
$danxuan_score =  GetScore_DanXuan_m($danxuan_answer);
$duoxuan_score =  GetScore_DuoXuan_m($duoxuan_answer);
$panduan_score =  GetScore_Panduan_m($panduan_answer);
$tiankong_score =  GetScore_Tiankong_m($tiankong_answer);

$total_score = $danxuan_score + $duoxuan_score + $panduan_score + $tiankong_score;

$timulist=array();
switch($filter)
{
	case '0':$timulist = $danxuan;break;
	case '1':$timulist = $duoxuan;break;
	case '2':$timulist = $panduan;break;
	case '3':$timulist = $tiankong;break;
	case '4':$timulist = $wenda;break;
}

$jiaojuan = true;

//�����Ŀ����
	$timu_count_arr = array(count($danxuan),count($duoxuan),count($panduan),count($tiankong),count($wenda));
	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
					
					
	$timu_type=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5);
	
	date_default_timezone_set('Asia/Shanghai');
	
	$admin_exam_record_score = lang('plugin/tp_exam', 'admin_exam_record_score');

	$uid = $_G['uid'];

	//���ӻ���
	$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='score_add_credits'");
	$score_add_credits = $skey;
	if(!empty($score_add_credits))
	{
		$addcredit = 'extcredits'.$score_add_credits;

		$count = DB::result_first("SELECT $addcredit FROM ".DB::table('common_member_count')." WHERE uid= $uid");
		$count_credit = $count ;

		$count_credit = $count_credit + $total_score;
//	updatemembercount($uid, array($addcredit => $total_score));

		DB::update('common_member_count', array(
		$addcredit=>$count_credit
		), "uid=$uid");
	}
	submit_record($uid,$item,$exam_usetime,time(),$total_score);


function submit_record($uid,$exam_type,$usetime,$exam_time,$score)
{
	DB::insert('tpexam_examrecord', array(
				'uid'=>$uid,
				'exam_type' => $exam_type,
				'usetime' => $usetime,
				'date' => $exam_time,
				'score'=> $score
				));
}

$tips = GetTips($total_score);

$tips='';
include template('tp_exam:mobile_jiaojuan');

function GetTips($score)
{
	
	if($score==100)
	{
		$tip = '100�֣����绰�������ϣ������أ�������';
	}
	else if($score>90 && $score<100)
	{
		$tip = '90�����ϣ����绰�������������';
	}
		else if($score>=80 && $score<90)
	{
		$tip = '80�����ϣ����绰�弶������Ŭ����';
	}
	else if($score>=70 && $score<80)
	{
		$tip = '70�����ϣ����绰�ļ�������Ŭ����';
	}
	else if($score>=60 && $score<70)
	{
		$tip = '60�����ϣ����绰����������Ŭ����';
	}
	else if($score>=50 && $score<60)
	{
		$tip = '50�����ϣ����绰����������Ŭ����';
	}
	else if($score>=40 && $score<50)
	{
		$tip = '40�����ϣ����绰һ��������Ŭ����';
	}
	else if($score < 40)
	{
		$tip = '40�����£����绰̫��ˣ�Ŭ��ѧ�㡣';
	}
	return $tip;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>