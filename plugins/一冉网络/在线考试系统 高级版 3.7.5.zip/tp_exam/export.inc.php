<?php
 // load library

	require 'include/php-excel.class.php';
	
	require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';
	
	global $_G;
	$mode = $_GET['mode'];
	$mod = intval($_POST['mod']);

	$admin_user_record_idcard = lang('plugin/tp_exam','admin_user_record_idcard');
	$admin_user_record_studentid = lang('plugin/tp_exam','admin_user_record_studentid');
	$admin_exam_record_paper = lang('plugin/tp_exam','admin_exam_record_paper');
	$admin_exam_record_timedata = lang('plugin/tp_exam','admin_exam_record_timedata');
	$admin_exam_record_usetime = lang('plugin/tp_exam','admin_exam_record_usetime');
	$admin_exam_record_score = lang('plugin/tp_exam','admin_exam_record_score');
	$my_score_query_member = lang('plugin/tp_exam','my_score_query_member');
	$admin_exam_record_company = lang('plugin/tp_exam','admin_exam_record_company');
	$admin_exam_record_name = lang('plugin/tp_exam', 'admin_exam_record_name');
	
	
	if($_G['charset'] != 'gbk') {
		$admin_user_record_idcard = diconv($admin_user_record_idcard, $_G['charset'], 'GBK');
		$admin_user_record_studentid = diconv($admin_user_record_studentid, $_G['charset'], 'GBK');
		$admin_exam_record_paper = diconv($admin_exam_record_paper, $_G['charset'], 'GBK');
		$admin_exam_record_timedata = diconv($admin_exam_record_timedata, $_G['charset'], 'GBK');
		$admin_exam_record_usetime = diconv($admin_exam_record_usetime, $_G['charset'], 'GBK');
		$admin_exam_record_score = diconv($admin_exam_record_score, $_G['charset'], 'GBK');
		$my_score_query_member = diconv($my_score_query_member, $_G['charset'], 'GBK');
		$admin_exam_record_company = diconv($admin_exam_record_company, $_G['charset'], 'GBK');
		$admin_exam_record_name = diconv($admin_exam_record_name, $_G['charset'], 'GBK');
	}
	
	
	if($mode == 'usereport'){

	$where =' order by id asc';

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord').$where);

	
	$data = array(1 => array ('id','uid',$admin_exam_record_company,$admin_exam_record_name,$admin_user_record_idcard,$admin_user_record_studentid,$admin_exam_record_paper,$admin_exam_record_usetime,$admin_exam_record_timedata,$admin_exam_record_score));
  
  
	while($row = DB::fetch($query)) {
		$valarr = array();
		$valarr[] = $row['id'];
		$username = getuserbyuid($row['uid']);
		$valarr[] = $row['uid'].'('.$username['username'].')';
		$verifyid = $row['verifyid'];
		$paperid = $row['exam_type'];
		
		$company = GetVerifyCompany($paperid,$row['uid'],$verifyid);
		$name = GetVerifyName($paperid,$row['uid'],$verifyid);
		$idcard = GetVerifyIdcard($paperid,$row['uid'],$verifyid);
		$studentid = GetVerifyStudentId($paperid,$row['uid'],$verifyid);
		
		$valarr[] = iconv("utf-8","gb2312",$company);
		$valarr[] = iconv("utf-8","gb2312",$name);
		$valarr[] = iconv("utf-8","gb2312",$idcard);
		$valarr[] = iconv("utf-8","gb2312",$studentid);

		$valarr[] = $row['exam_type'];
		$valarr[] = $row['usetime'];
		$valarr[] = date('Y-m-d G:i:s',$row['date']);
		$valarr[] = $row['score'];
		$data[]=$valarr;
		unset($valarr);
	}
	
	$xls = new Excel_XML('gb2312', false, 'UserInfo');
	$xls->addArray($data);
	$xls->generateXML('userinfo');
}
else
{
	/*
	$belong_paper = daddslashes($_POST['belong_paper']);
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord')." where exam_type = $belong_paper order by uid asc");

	$user_arr = array();
	while($row = DB::fetch($query)) {
		$user_arr[] = $row;
	}

	if(count($user_arr) == 0) {echo 'No User Examed!!!';die();}

	$user_arr_order = GetOrderUserExamReport($user_arr,$belong_paper);

	$qulifiedtime = 1;
	$qulifiedtime_arr=array();
	$user_arr=array();
	
	$line = GetQualifiedLine($belong_paper); //��ȡ���Ծ�������
	
	foreach($user_arr_order as $n=>$val) //�û�ѭ��
	{
		$large_line = false;
		foreach($val as $k=>$value) //�û����ο���ѭ��
		{

			if($value['score'] > $line) //���ںϸ���
			{
				$qulifiedtime_arr[]=$qulifiedtime;
				$large_line = true;
				break;
			}
			
			$qulifiedtime++;
		}
		
		if(!$large_line) $qulifiedtime_arr[]= -1; //û�г���������
		
		$qulifiedtime = 1;
		$user_arr[] = $val[0]['uid'];
	}
	
	//��ʼ��ʾ
	$export = array(1 => array ('id','uid','time','line'));
	foreach($user_arr as $kk=>$vv)
	{
		$valarr = array();
		$valarr[] = $kk;
		$valarr[] = $vv;
		$valarr[] = $qulifiedtime_arr[$kk];
		$valarr[] = $line;
		$export[] =  $valarr;
		unset($valarr);
	}
	

	
	$xls = new Excel_XML('gb2312', false, 'UserInfo');
	$xls->addArray($export);
	$xls->generateXML('userinfo');
	*/
}
//print_r($data);
 ?>