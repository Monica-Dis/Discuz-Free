<?php

	require_once DISCUZ_ROOT."./source/plugin/tp_exam/module/module_func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	
  require 'include/php-excel.class.php';
	 
	$type = GetPaperType();

if(!submitcheck('submit')) {
	showtips('Please Select Exam Paper');

	$module_report = DISCUZ_ROOT."./source/plugin/tp_exam/module/module_report.inc.php";
	if(!file_exists($module_report))
	{
		$admin_module_batch_notexist_tips = lang('plugin/tp_exam', 'admin_module_batch_notexist_tips');

		showtips($admin_module_batch_notexist_tips);
		die();
	}
	
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/module/module_report.inc.php";

}
else
{

	$belong_paper = daddslashes($_POST['belong_paper']);
	$exam_admin_report_qulified_time = lang('plugin/tp_exam', 'exam_admin_report_qulified_time');
	$exam_admin_report_qulified_line = lang('plugin/tp_exam', 'exam_admin_report_qulified_line');
	
	
	showtips('Please Select Exam Paper');


	echo "<form action='admin.php?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_report' enctype='multipart/form-data' method='POST'>";
	echo "<select name='belong_paper'>";
	for($i=0;$i<count($type);$i++)
	{
		echo "<option value='".$type[$i]['id']."'>".$type[$i]['name']."</option>";
	}
	echo "</select>";
	echo "<input type='submit' class='btn' id='submit_submit' name='submit' value='Query' >";
	echo "<input type='hidden' name='formhash' value='$_G[formhash]'>";
	echo "</form>";
	
	$totalnum = DB::result_first("SELECT count(*) FROM ".DB::table('tpexam_examrecord'));
		
	$multi = multi($totalnum, $pagenum, $page, ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_examrecord&app={$app}{$linkadd}");
		
	//showformheader("plugins&operation=config&do={$pluginid}&identifier=tp_tuangou&pmod=admin_recipt&app={$app}", 'order_submit');
	showtableheader();

	showtitle('Exam Number'.'&nbsp;'.$totalnum);

	showsubtitle(array('id','uid',$exam_admin_report_qulified_time,$exam_admin_report_qulified_line,'op'));
	
	$limit_start = $pagenum * ($page - 1);


	$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord')." where exam_type = $belong_paper order by uid asc");

	$user_arr = array();
	while($row = DB::fetch($query)) {
		$user_arr[] = $row;
	}
	

	if(count($user_arr) == 0) {echo 'No User Examed!!!';die();}

	$user_arr_order = GetOrderUserExamReport($user_arr,$belong_paper);

	$qulifiedtime = 1;
	$qulifiedtime_arr=array();
	$user_arr=array();
	
	$line = GetQualifiedLine($belong_paper); //��ȡ���Ծ�������

	foreach($user_arr_order as $n=>$val) //�û�ѭ��
	{
		$large_line = false;
		foreach($val as $k=>$value) //�û����ο���ѭ��
		{

			if($value['score'] > $line) //���ںϸ���
			{
				$qulifiedtime_arr[]=$qulifiedtime;
				$large_line = true;
				break;
			}
			
			$qulifiedtime++;
		}
		
		if(!$large_line) $qulifiedtime_arr[]= -1; //û�г���������
		
		$qulifiedtime = 1;
		$user_arr[] = $val[0]['uid'];
	}
	
	//��ʼ��ʾ
	
	foreach($user_arr as $kk=>$vv)
	{
		$valarr = array();
		$valarr[] = $kk;
		$valarr[] = $vv;
		$valarr[] = $qulifiedtime_arr[$kk];
		$valarr[] = $line;
		//$export[] =  $valarr;
		$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_examrecord&del=".$row['id']."\">".'ɾ��'."</a>";
		showtablerow('id="td_'.$row['id'].'"', array('class="td25"','class="td25"', 'class="td25"','class="td25"','','','',''), $valarr);
		unset($valarr);
	}
	
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism��taobao��com*/	
	
	echo "<form action='plugin.php?id=tp_exam:export' method='POST'>";
	echo "<input type='submit' class='btn' id='submit_submit' name='submit' value='Export' >";
	echo "<input type='hidden' name='mode' class='btn' value='usrereport' />";
	echo "<input type='hidden' name='belong_paper' class='btn' value='$belong_paper' />";
	echo "<input type='hidden' name='formhash' value='$_G[formhash]'>";
	echo "</form>";
	
}
//From: di'.'sm.t'.'aoba'.'o.com
?>