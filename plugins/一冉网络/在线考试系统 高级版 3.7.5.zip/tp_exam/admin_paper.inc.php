<?php

 /*
 ε  tp_exam
 */
 
if(!defined('IN_DISCUZ') ) {
	exit('Access Denied');
}

$op = trim(daddslashes($_GET['op']));
$id = trim(daddslashes($_GET['id']));
$app = trim(daddslashes($_GET['app']));

$filter = in_array($app, array('advance','papergroups','groupdelete')) ? $app : '';

require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/syn.inc.php";
require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/func.score.php";


if(!submitcheck('submit') && empty($op) && empty($app) && !submitcheck('editsubmit')) {

	$id = lang('plugin/tp_exam', 'admin_common_id');
	$belong = lang('plugin/tp_exam', 'admin_belongtype');
	$shorturl = lang('plugin/tp_exam', 'admin_common_shorturl');
	$admin_exam_paper_name = lang('plugin/tp_exam', 'admin_exam_paper_name');
	$exam_time = lang('plugin/tp_exam', 'admin_exam_time');
	$exam_mustlogin = lang('plugin/tp_exam', 'admin_exam_mustlogin');
	$exam_must_pay = lang('plugin/tp_exam', 'admin_exam_must_pay');
	$admin_practise_mode = lang('plugin/tp_exam', 'admin_practise_mode');
	$admin_view_show_answer = lang('plugin/tp_exam', 'admin_view_show_answer');
	$admin_view_paper_info = lang('plugin/tp_exam', 'admin_view_paper_info');
	$admin_view_paper_advance = lang('plugin/tp_exam', 'admin_view_paper_advance');
	$admin_paper_rand_mode = lang('plugin/tp_exam', 'admin_paper_rand_mode');
	$admin_common_submit = lang('plugin/tp_exam', 'admin_common_submit');
	$admin_common_delete = lang('plugin/tp_exam', 'admin_common_delete');
	$admin_audit_paper_yes = lang('plugin/tp_exam', 'admin_audit_paper_yes');
	$exam_sort = lang('plugin/tp_exam', 'exam_sort');
	$admin_use_score_scheme = lang('plugin/tp_exam','admin_use_score_scheme');
	$admin_groups = lang('plugin/tp_exam','admin_groups');
	$op = lang('plugin/tp_exam', 'admin_common_op');
	
	showtips(lang('plugin/tp_exam', 'admin_paper_tips'));
	
  showformheader('plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_paper', 'editsubmit');
	showtableheader();

	showsubtitle(array($id, $exam_sort,$belong,$shorturl,
	$admin_exam_paper_name,
	$exam_time,
	$exam_mustlogin,
	$admin_view_show_answer,
	$admin_practise_mode,
	$admin_use_score_scheme,
	$admin_paper_rand_mode,
	$admin_view_paper_info,
	$admin_groups,
	$admin_view_paper_advance,
	$op));
	
	
	$perpage = 10;
	$page = max(1, intval($_GET['page']));
	$listStart = ($page-1) *$perpage;
	$totalnum = DB::result_first("SELECT count(*) FROM ".DB::table('tpexam_paper'));
	$pagenum = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 

	$multi = multi($totalnum, $perpage, $page, ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_paper");

	$query = DB::query('SELECT * FROM '.DB::table('tpexam_paper')." order by id desc limit $listStart,$perpage");
	while($value = DB::fetch($query))
	{
		$valarr = array();
		$valarr[] = '<input type="text" id="id_'.$value['id'].'" class="txt" name="id['.$value['id'].']" value="'.$value['id'].'"/>';
		$valarr[] = '<input type="text" id="sort_'.$value['id'].'" class="txt" name="sort['.$value['id'].']" value="'.$value['sort'].'"/>';
		$valarr[] = '<input type="text" id="belong_'.$value['id'].'" class="txt" name="belong['.$value['id'].']" value="'.$value['belong'].'"/>';
		$valarr[] = '<input type="text" id="shorturl_'.$value['id'].'" class="txt" name="shorturl['.$value['id'].']" value="'.$value['shorturl'].'"/>';
		$valarr[] = '<input type="text" id="name_'.$value['id'].'" class="txt" name="name['.$value['id'].']" value="'.$value['name'].'"/>';
		$valarr[] = '<input type="text" id="papertime_'.$value['id'].'" class="txt" name="papertime['.$value['id'].']" value="'.$value['papertime'].'"/>';
		$valarr[] = '<input type="text" id="needlogin_'.$value['id'].'" class="txt" name="needlogin['.$value['id'].']" value="'.$value['needlogin'].'"/>';
		$valarr[] = '<input type="text" id="showanswer_'.$value['id'].'" class="txt" name="showanswer['.$value['id'].']" value="'.$value['showanswer'].'"/>';
		$valarr[] = '<input type="text" id="practise_'.$value['id'].'" class="txt" name="practise['.$value['id'].']" value="'.$value['practise'].'"/>';
		$valarr[] = GetScoreScheme($value['id'],$value['usescorescheme']);
		$valarr[] = '<input type="text" id="rand_'.$value['id'].'" class="txt" name="rand['.$value['id'].']" value="'.$value['rand'].'"/>';
		$valarr[] = '<input type="text" id="paperinfo_'.$value['id'].'" class="txt" name="paperinfo['.$value['id'].']" value="'.$value['paperinfo'].'"/>';
		$valarr[] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_paper&app=papergroups&id='.$value[id].'">'.$admin_view_paper_advance.'</a>';
		$valarr[] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_paper&app=advance&id='.$value[id].'">'.$admin_view_paper_advance.'</a>';
		$valarr[] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_paper&op=del&id='.$value[id].'">'.cplang('delete').'</a>';
		showtablerow('id="td_'.$value['id'].'"', array('class="td25"', 'class="td25"','class="td25"','class="td25"','class="td35"','class="td25"','class="td25"','class="td25"','class="td25"','class="td25"','class="td25"'), $valarr);
	}
	
	showtablerow('', array('colspan=3'), array(
			'<div><a href="javascript:;" onclick="addrow(this, 0, 1);return false;" class="addtr">'.cplang('add').'</a></div>'
		));
		
	//showsubmit('submit', 'submit','',$multi);
	showsubmit('submit', 'submit', 'del', '', $multi);
	
	$adminurl = ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_type";
	
echo <<<SCRIPT
<script type="text/javascript">
var rowtypedata = [[[1,'', '','','',''],[1,'<input type="text" class="txt" name="sortnew[]" value="0" />', 'td25'],[1,'<input type="text" class="txt" name="belongnew[]" value="0" />', 'td25'],[1,'<input type="text" class="txt" name="shorturlnew[]" value="TYPE" />', 'td25'],[1,'<input type="text" class="txt" name="namenew[]" value="" />', 'td35'],[1,'<input type="text" class="txt" name="papertimenew[]" value="120" />','td25'],[1,'<input type="text" class="txt" name="needloginnew[]" value="0" />','td25'],[1,'<input type="text" class="txt" name="showanswernew[]" value="1" />','td25'],[1,'<input type="text" class="txt" name="practisenew[]" value="0" />','td25'],[1,'<input type="text" class="txt" name="scoreschemenew[]" value="0" />','td25'],[1,'<input type="text" class="txt" name="randnew[]" value="0" />','td25'],[1,'<input type="text" class="txt" name="paperinfonew[]" value="PaperInfo" />','td35']]];
</script>
SCRIPT;
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism·taobao·com*/

	showtips(lang('plugin/tp_exam', 'admin_audit_paper_tips'));
	
  showformheader('plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_paper', 'editsubmit');
	showtableheader();

	showsubtitle(array($id, $belong,$shorturl,$admin_exam_paper_name,$exam_time,$exam_mustlogin,$admin_view_show_answer,$admin_practise_mode,$admin_paper_rand_mode,$admin_view_paper_info, $admin_exam_timulist_pubname,$admin_view_paper_advance,$op));
	
	$query = DB::query('SELECT * FROM '.DB::table('tpexam_paper').' where auditing = 1');
	while($value = DB::fetch($query))
	{
		$valarr = array();
		$valarr[] = "<input type='checkbox' name='delete[]' value='$value[id]'/>";
		$valarr[] = '<input type="text" id="belong_'.$value['belong'].'" class="txt" name="belong['.$value['id'].']" value="'.$value['belong'].'" readonly="true"/>';
		$valarr[] = '<input type="text" id="shorturl_'.$value['id'].'" class="txt" name="shorturl['.$value['id'].']" value="'.$value['shorturl'].'" readonly="true"/>';
		$valarr[] = '<input type="text" id="name_'.$value['id'].'" class="txt" name="name['.$value['id'].']" value="'.$value['name'].'" readonly="true""/>';
		$valarr[] = '<input type="text" id="papertime_'.$value['id'].'" class="txt" name="papertime['.$value['id'].']" value="'.$value['papertime'].'" readonly="true"/>';
		$valarr[] = '<input type="text" id="needlogin_'.$value['id'].'" class="txt" name="needlogin['.$value['id'].']" value="'.$value['needlogin'].'" readonly="true"/>';
		$valarr[] = '<input type="text" id="showanswer_'.$value['id'].'" class="txt" name="showanswer['.$value['id'].']" value="'.$value['showanswer'].'" readonly="true""/>';
		$valarr[] = '<input type="text" id="practise_'.$value['id'].'" class="txt" name="practise['.$value['id'].']" value="'.$value['practise'].'" readonly="true"/>';
		$valarr[] = '<input type="text" id="rand_'.$value['id'].'" class="txt" name="rand['.$value['id'].']" value="'.$value['rand'].'" readonly="true"/>';
		$valarr[] = '<input type="text" id="paperinfo_'.$value['id'].'" class="txt" name="paperinfo['.$value['id'].']" value="'.$value['paperinfo'].'" readonly="true"/>';
		$valarr[] = '<input type="text" id="pubuid_'.$value['pubuid'].'" class="txt" name="pubuid['.$value['pubuid'].']" value="'.$value['pubuid'].'" readonly="true"/>';
		$valarr[] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_paper&app=advance&id='.$value[id].'">'.$admin_audit_paper_yes.'</a>';
		$valarr[] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=tp_exam&pmod=admin_paper&op=del&id='.$value[id].'">'.cplang('delete').'</a>';
		showtablerow('id="td_'.$value['id'].'"', array('class="td25"', 'class="td25"','class="td25"','class="td45"','class="td25"','class="td25"','class="td25"','class="td25"','class="td25"','class="td45"','class="td25"'), $valarr);
	}
	

	showtablerow('', 'colspan=3', array(
	 '<input type="checkbox" name="chkall" id="chkallcNmn" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')"><label for="chkallcNmn">'.$admin_common_delete.'</label>'.'<td colspan="15"><div class="fixsel"><input type="submit" class="btn" id="submit_submit" name="submit" title="" value="'.$admin_common_submit.'">&nbsp<input type="submit" class="btn" id="submit_submit" name="editsubmit" title="" value="'.$admin_audit_paper_yes.'"></div></td>'
		));
		
	showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
	showformfooter(); /*dism·taobao·com*/
	
}elseif($filter == 'papergroups'){
	
	if(!submitcheck('submit')){
		$groups=array();
		$query = DB::query("select * from ".DB::table('tpexam_groups')." where paperid = $id");
		while($d=DB::fetch($query)){
			$groups[]=$d;
		}

		include template("tp_exam:papergroups");
	}else{
		
		$subject = trim(daddslashes($_POST['subject']));
		$content = trim(daddslashes($_POST['content']));
		$grouprand = intval($_POST['grouprand']);
		
		$paperid = intval($_POST['paperid']);
		
		DB::insert('tpexam_groups',array('subject'=>$subject,
		'content'=>$content,
		'paperid'=>$paperid,
		'grouprand'=>$grouprand));
		
		cpmsg(lang('plugin/tp_exam', 'admin_common_success'), "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_paper&app={$_GET['app']}&id={$_GET['id']}", 'succeed');	
	}
	
	exit;
}elseif($filter == 'groupdelete'){
	$delid = intval($_GET['item']);
	$paperid = intval($_GET['paperid']);
	
	DB::delete('tpexam_groups', "id IN($delid)");
	cpmsg(lang('plugin/tp_exam', 'admin_common_success'), "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_paper&app=papergroups&id={$paperid}", 'succeed');	
	
	exit;
}
else
{
		if(submitcheck('submit')){
		global $_G;
		
		$success = lang('plugin/tp_exam', 'admin_common_success');
		
		if(!empty($_POST['shorturlnew'])) {

		$inserts = array();
		$displayorder = '';
		foreach(daddslashes($_POST['shorturlnew']) as $key => $value) {
		$belongnew = trim(daddslashes($_POST['belongnew'][$key]));
		$shorturlnew = trim(daddslashes($_POST['shorturlnew'][$key]));
		$namenew = trim(daddslashes($_POST['namenew'][$key]));
		$papertimenew = trim(daddslashes($_POST['papertimenew'][$key]));
		$needloginnew = trim(daddslashes($_POST['needloginnew'][$key]));
		$needpaynew = trim(daddslashes($_POST['needpaynew'][$key]));
		$practisenew = trim(daddslashes($_POST['practisenew'][$key]));
		$scoreschemenew = trim(daddslashes($_POST['scoreschemenew'][$key]));
		$randnew = trim(daddslashes($_POST['randnew'][$key]));
		$showanswernew = trim(daddslashes($_POST['showanswernew'][$key]));
		$paperinfonew = trim(daddslashes($_POST['paperinfonew'][$key]));
		$sortnew = trim(daddslashes($_POST['sortnew'][$key]));
		$timestamp = TIMESTAMP;
		
			if(!empty($shorturlnew)) {
				
					$fid_syn = GetSynFid();
					if($fid_syn > 0){
						require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/syn.inc.php";
						
						$template = '<link href="source/plugin/tp_exam/static/exam.css" type="text/css" rel="stylesheet"><div id="vu_tuan"><div class="tuan_main"><h2><span>'.lang('plugin/vu_tuan', 'thetuan') .' </span>'.$title.'</h2><div class="tuan_attr z"><div class="btn_buy_wrap"><div class="btn_buy"><p class="nowprice z">'.lang('plugin/vu_tuan', 'rmb_flag').$shop_price.'</p><a class="button y" id="buy_button" href="'.$buyurl.'"></a></div></div><ul class="price_all"><li><span class="tit">'.lang('plugin/vu_tuan', 'zhekou').'</span><p>'.$zhe['discount'].lang('plugin/vu_tuan', 'zhe').'</p></li><li><span class="tit">'.lang('plugin/vu_tuan', 'oldprice').'</span><p><del>'.lang('plugin/vu_tuan', 'rmb_flag').$market_price.'</del></p></li><li><span class="tit">'.lang('plugin/vu_tuan', 'jiesheng').'</span><p>'.lang('plugin/vu_tuan', 'rmb_flag').$zhe['left'].'</p></li></ul><div class="tuan_time" id="tuan_time" starttime="'.$starttime.'" endtime="'.$overtime.'"></div><div class="buy_info"><p class="people_num">'.lang('plugin/vu_tuan', 'gongyou').'<span id="people_num"></span>'.lang('plugin/vu_tuan', 'numbuy').'</p><div id="deal_fail" class="deal_fail"></div></div></div><div class="tuan_show y"><div style="display:block;" class="slidebox"><ul class="slideshow"><li><img width="500" height="300" src="source/plugin/vu_tuan/static/pic/'.$defaultimg['url'].'"></li></ul></div><div class="intro"><div class="e"></div><div class="s"></div>'.$editmessage.'</div></div></div><div class="tuan_bot"></div></div>';
						$t_arr = postForum($_G['uid'],$_G['username'],$fid_syn,TIMESTAMP,$namenew,$template.$message,$_G['clientip'],'');
						//DB::update('tpexam_paper',array('tid' => $t_arr['tid']),"gid=$gid");
				}
				
				$inserts[] = "('', '$belongnew','$namenew','$shorturlnew','$papertimenew','$needloginnew','$practisenew','$scoreschemenew','$randnew','$showanswernew','$paperinfonew','$t_arr[tid]','$sortnew','$timestamp')";
				DB::query("INSERT INTO ".DB::table('tpexam_paper')." (id , belong,name, shorturl ,papertime,needlogin,practise,usescorescheme,rand,showanswer,paperinfo,tid ,sort,paperdata) VALUES ".implode(',',$inserts));

		
		
			}
			
			unset($inserts);
		}

		
	}


	$parent = daddslashes($_GET['shorturl']);
	
	if(is_array($parent)) {
		foreach($parent as $id => $val) {
			$par = daddslashes($_GET['belong'][$id]);
			$shorturl = daddslashes($_GET['shorturl'][$id]);
			$name = daddslashes($_GET['name'][$id]);
			$papertime = daddslashes($_GET['papertime'][$id]);
			$needlogin = daddslashes($_GET['needlogin'][$id]);
			$needpay = daddslashes($_GET['needpay'][$id]);
			$practise = daddslashes($_GET['practise'][$id]);
			$scorescheme = daddslashes($_GET['scorescheme'][$id]);
			$rand = daddslashes($_GET['rand'][$id]);
			$showanswer = daddslashes($_GET['showanswer'][$id]);
			$paperinfo = daddslashes($_GET['paperinfo'][$id]);
			$sort = daddslashes($_GET['sort'][$id]);
			
				DB::update('tpexam_paper', array(
				'belong' => $par,
				'shorturl' => $shorturl,
				'name' => $name,
				'papertime'=>$papertime,
				'needlogin'=>$needlogin,
				'needpay'=>$needpay,
				'practise'=>$practise,
				'rand'=>$rand,
				'showanswer'=>$showanswer,
				'paperinfo'=>$paperinfo,
				'sort'=>$sort,
				'usescorescheme'=>$scorescheme
				), "id='$id'");
				
		}
		
		
	}
	
	//
	$paper_id = daddslashes($_POST['item']);
	if(!empty($op))
	{

		if($op == 'advance') //
		{

				//"yg
				$module_system  = array();
				$updatemodule=array();
				
				$module_sql = DB::query("SELECT * FROM ".DB::table('tpexam_module_item'));
				while($mod = DB::fetch($module_sql))
				{
					$module_system[] = $mod;
				}
				
				foreach($module_system as $k=>$value){
				
					$find = false;
					$modulename = $value['modulename'];
					$module = daddslashes($_POST[$modulename."_name"]);
					$post_val = daddslashes($_POST[$modulename."_val"]);
					
					$paper = DB::result_first("SELECT * FROM ".DB::table('tpexam_module')." where belongpaper = $paper_id");
				
					$query = DB::query("SELECT * FROM ".DB::table('tpexam_module')." where belongpaper = $paper_id");
					while($data = DB::fetch($query))
					{
						if($data['module'] == $module) //g
						{

									DB::update('tpexam_module', array('value' => $post_val	),array('module' => $module), "id=$paper_id");
									
									$find = true;
						}
					}
					
					if(!$find)
					{
						DB::insert('tpexam_module', array('value'=>$post_val,'module'=>$module,'belongpaper'=>$paper_id));
					}
				
				}
				
				//,
				$paper_timu_item_desc = daddslashes($_POST['paper_timu_item_desc']);
				DB::update('tpexam_paper', array('paper_timu_item_desc' => $paper_timu_item_desc	), "id='$paper_id'");
				

				$exam_paper_group = daddslashes($_POST['exam_paper_group']);
				foreach($exam_paper_group as $k=>$val)
				{
					if(!empty($combine))
					{
						$combine .= "|";
					}

					$combine.=$val;
				}

				DB::update('tpexam_paper', array('examgroup' =>$combine), "id=".$paper_id);
				
				//
				$paper_buy_credits = daddslashes($_POST['paper_buy_credits']);
				$param=explode("|",$paper_buy_credits);
				DB::update('tpexam_paper', array('buycredits' =>$param[1],'needcredit'=>$param[0],'buyonlyonce'=>$param[2]), "id=".$paper_id);
				
				//
				$random_item = daddslashes($_POST['random_item']);
				DB::update('tpexam_paper', array('random_item' =>$random_item), "id=".$paper_id);
				
				//
				$examtimes = daddslashes($_POST['canexamtime']);
				$paper_exam_times_reach_msg = daddslashes($_GET['paper_exam_times_reach_msg']);

				DB::update('tpexam_paper', array('examtimes' =>$examtimes), "id=".$paper_id);
				DB::update('tpexam_setting', array('svalue' =>$paper_exam_times_reach_msg), "skey='paper_exam_times_reach_msg'");
				
				//
				$usetimespan = daddslashes($_POST['usetimespan']);
				$startexamtime = daddslashes($_POST['startexamtime']);
				$endexamtime = daddslashes($_POST['endexamtime']);
				$paper_exam_time_span_msg = daddslashes($_POST['paper_exam_time_span_msg']);
				
				DB::update('tpexam_paper', array('usetimespan' =>$usetimespan,'startexamtime'=>$startexamtime,'endexamtime'=>$endexamtime), "id=".$paper_id);

				DB::update('tpexam_setting', array('svalue' =>$paper_exam_time_span_msg), "skey='paper_exam_time_span_msg'");
				
				//paper_no_pause
				$paper_no_pause = daddslashes($_POST['paper_no_pause']);
				DB::update('tpexam_paper', array('paper_no_pause' =>$paper_no_pause), "id=".$paper_id);
				
				$paper_score = daddslashes($_POST['paper_score']);
				DB::update('tpexam_paper', array('paperscore' =>$paper_score), "id=".$paper_id);
				
				$paper_password = daddslashes($_POST['password']);
				DB::update('tpexam_paper', array('password' =>$paper_password), "id=".$paper_id);
				
				$verifylogintimes = daddslashes($_POST['verifylogintimes']);
				DB::update('tpexam_paper', array('verifylogintimes' =>$verifylogintimes), "id=".$paper_id);
				
				$usesysprofile = daddslashes($_POST['usesysprofile']);
				DB::update('tpexam_paper', array('usesysprofile' =>$usesysprofile), "id=".$paper_id);
				
		}
	}
	
	
	cpmsg($success, "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_paper", 'succeed');
	
	}
	else 
	if(submitcheck('editsubmit')){
		$success = lang('plugin/tp_exam', 'admin_common_success');
		
		$newids = array();
		$delarr = daddslashes($_GET['delete']);
		foreach($delarr as $id=>$v) 
		{
			DB::update('tpexam_paper', array('auditing'=>0),"id IN($v)");
		}
		
		cpmsg(lang('plugin/tp_exam', 'admin_common_success'), "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_paper", 'succeed');	
	}
	else 
	{
		if(!empty($op))
		{
				DB::delete('tpexam_paper', "id IN($id)");
				//DB::delete('tpexam_module', "belongpaper IN($id)"); //g
				cpmsg(lang('plugin/tp_exam', 'admin_common_success'), "action=plugins&operation=config&do={$pluginid}&identifier=tp_exam&pmod=admin_paper", 'succeed');	
		}
	}

		
}
	if(!empty($app))
	{
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/admin_paper_advance.inc.php";
	}
	
	
?>