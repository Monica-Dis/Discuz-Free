<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tp_exam.func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_paper_func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam.rand.func.php";
	require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/m.func.php";

	
	
	//$mtype = in_array('mtype','tk','resultdata','total','mod')?$mtype:0;
	$mexam_main_ui = lang('plugin/tp_exam','mexam_main_ui');
	$username = getuserbyuid($_G['uid']);
	$username = $username['username'];
	$item = intval($_GET['item']);
	
	//���
	if(isset($_GET['tk']))
	{
			$eid = intval($_GET['eid']);
			$as = $_GET['as'];
			
			$v = explode(",",$as);
			
			$tid_arr = GetTidByEid($eid);
			
			$tk = GetTiankongById($tid_arr['oid']);

			$tk = $tk['ask'];
			
			$ask = preg_replace("/#[0-9]+/","<input type=\"text\" onchange=\"echange(this,$eid,1);\" class=\"txt\"  
			value=\"$v[0]\" size=\\1 name=\"tk[]\">",$tk,1);
			
			$index=1;
			$replacedTime = 1;
			while(preg_match("/#[0-9]+/", $ask, $matches)){

				$replacedTime  = $replacedTime + 1;

				$ask = preg_replace("/#[0-9]+/","<input type=\"text\" onchange=\"echange(this,$eid,$replacedTime);\" class=\"txt\"  
				value=\"".$v[$index]."\" size=\\1 name=\"tk[]\">",$ask,1);
				
				$index = $index + 1;
			}
			
			echo $ask;

		exit;
	}
	
	//��
	if(isset($_GET['resultdata']))
	{
			$resultdata = trim($_GET['resultdata']);
			$resultdata = explode(';', $resultdata);
			
			$eid=array();
			foreach($resultdata as $k=>$value){
				$result_arr = explode(",",$value);
				$eid[]=$result_arr;
			}
	 		
			$exams=array();

	 		foreach($eid as $pid=>$v){

	 			$exam = GetExam($v);
	 			$exams[]=$exam;
	 		}

			
			
			//saveuseranswer($danxuan_a,$duoxuan_a,$panduan_a,$tiankong_a,$wenda_a,$recordid);
		
			echo array2json($exams);

		exit;
	}
	
	if(isset($_GET['total'])){
		$total_score = intval($_GET['total']);
		$usetime = intval($_GET['usetime']);
		$item = intval($_GET['item']);
		
		$recordid = submit_record($_G['uid'],$item,$usetime,time(),$total_score);
		
		exit;
	}
	
	//����
	if(isset($_GET['mod'])){
		$mod= $_GET['mod'];
		
		//���ģʽ
		global $_G;
		$config = array();
		$config = $_G['cache']['plugin']['tpgao_m'];
		$login = $config['login'];
		
		
		if($item > 0){
			
			$randmod = GetRandMode($item);
			if($randmod){
				require_once DISCUZ_ROOT."./source/plugin/tp_exam/app/random_t.inc.php";
			}else{
				require_once DISCUZ_ROOT."./source/plugin/tp_exam/app/normal_t.inc.php";
			}
			
			
			require_once DISCUZ_ROOT."./source/plugin/tp_exam/app/paperctrl.inc.php";

			$index = 1;
			foreach($danxuan as $k=>$v){
				$type = 1;
				$id = $index;
				$oid = $v['id'];
				$eid = $v['eid'];
				$score = $v['score'];
				$subject = $v['ask'];
				$image = $v['image'];
				$parserimage = $v['parser_img_path'];
				
				$data = $v['option1']."\r\n".$v['option2']."\r\n".$v['option3']."\r\n".$v['option4'];
				if($v['option5']!='') $data .= "\r\n".$v['option5'];
				if($v['option6']!='') $data .= "\r\n".$v['option6'];
				if($v['option7']!='') $data .= "\r\n".$v['option7'];
				
				$arr = array('type'=>$type,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
				$groups[]=$arr;
				$index++;
			}
			
			foreach($duoxuan as $k=>$v){
				$type = 2;
				$id = $index;
				$eid = $v['eid'];
				$score = $v['score'];
				$subject = $v['ask'];
				$oid = $v['id'];
				$image = $v['image'];
				$parserimage = $v['parser_img_path'];
				
				$data = $v['option1']."\r\n".$v['option2']."\r\n".$v['option3']."\r\n".$v['option4'];
				if($v['option5']!='') $data .= "\r\n".$v['option5'];
				if($v['option6']!='') $data .= "\r\n".$v['option6'];
				if($v['option7']!='') $data .= "\r\n".$v['option7'];
				
				$arr = array('type'=>$type,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
				$groups[]=$arr;
				$index++;
			}
			
			foreach($panduan as $k=>$v){
				$type = 3;
				$id = $index;
				$eid = $v['eid'];
				$score = $v['score'];
				$subject = $v['ask'];
				$data = '';
				$oid = $v['id'];
				$image = $v['image'];
				$parserimage = $v['parser_img_path'];
			
				$arr = array('type'=>$type,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
				$groups[]=$arr;
				$index++;
			}
			
			foreach($tiankong as $k=>$v){
				$type = 4;
				$id = $index;
				$eid = $v['eid'];
				$score = $v['score'];
				$subject = $v['ask'];
				$data = '';
				$oid = $v['id'];
				$image = $v['image'];
				$parserimage = $v['parser_img_path'];
			
				$arr = array('type'=>$type,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
				$groups[]=$arr;
				$index++;
			}
			
			foreach($wenda as $k=>$v){
				$type = 5;
				$id = $index;
				$eid = $v['eid'];
				$score = $v['score'];
				$subject = $v['ask'];
				$data = '';
				$oid = $v['id'];
				$image = $v['image'];
				$parserimage = $v['parser_img_path'];
			
				$arr = array('type'=>$type,'id'=>$id,'eid'=>$eid,'oid'=>$oid,'image'=>$image,'parserimage'=>$parserimage,'subject'=>$subject,'score'=>$score,'data'=>$data);
				$groups[]=$arr;
				$index++;
			}
			
			$pages   = 2 ;
			$isPC = !checkmobile();
			$cid ='';
			$papers = array('pid'=>2,
			'cid'=>2,
			'uid'=>2,
			'fgid'=>2,
			'username'=>2,
			'starttime'=>2,
			'content'=>2,
			'last_time'=>2,
			'last_user'=>2,
			'pv'=>2,
			'submit'=>2,
			'minute'=>2,
			'pass'=>2,
			'pwd'=>2,
			'price'=>2,
			'public'=>2,
			'status'=>2,
			'color'=>2,
			'delay'=>2,
			'twice'=>2,
			'stick'=>2,
			'wait'=>2,
			'addtime'=>2,
			'edittime'=>2
			);
			$pid = 2;
	
			$exam = GetExamByPaperID($item);


			include template('tp_exam:m');
		}
		exit;
	}
	
	$mtype= intval($_GET['mtype']);
	//�б�
	if(isset ($mtype)){
		
		
		$mtype= intval($_GET['mtype']);
		if($mtype > 0){
			$currentType = GetNextType($mtype);
			$parentType = GteParentType($mtype);
			$paper = GetPaperList($mtype);
			
		}else{
			$currentType = GetNextType(0);
			$paper = GetPaperList(0);
		}
		
		$uid = $_G['uid'];
		$username = getuserbyuid($uid);
		$username = $username['username'];
		
		$admin_exam_record_paper = lang('plugin/tp_exam','admin_exam_record_paper');
		
		include template('tp_exam:mtype');
		exit;
	}
	
	function GetExam($group){
		
		///m&resultdata=1,1;1,2;1,3;1,4;1,5;1,6;2,1;3,1;3,2;3,3;4,1;5,1&0.6033715463709086
		if($group[0]==1){
			$tid = GetDanxuanById($group[1]);
			$tid['result']=$tid['answer'];
			
		}else if ($group[0]==2){
			$tid = GetDuoxuanById($group[1]);
			$tid['result']=$tid['answer1'].$tid['answer2'].$tid['answer3'].$tid['answer4'].$tid['answer5'].$tid['answer6'].$tid['answer7'];

		}else if ($group[0]==3){
			$tid = GetPanduanById($group[1]);
			$tid['result']=$tid['answer']==0?2:$tid['answer'];

		}else if ($group[0]==4){
			$tid = GetTiankongById($group[1]);
			$tid['result']=$tid['answer'];

		}else if ($group[0]==5){
			$eid = trim($group[1]);
			$tid = GetWendaById($group[1]);
			global $_G;
			

			if($_G['charset']!='gbk'){
				$answer = iconv('gb2312','utf-8',$tid['answer']);
				$parser = iconv('gb2312','utf-8',$tid['answer_parser']);
			
				$tid['result']=$answer;
				$tid['answer_parser']=$parser;
			}
		}
		
		return $tid;

	}
	
	
function array2json($arr) {
    //if(function_exists('json_encode')) return json_encode($arr); //Lastest versions of PHP already has this functionality. 
    $parts = array(); 
    $is_list = false; 

    //Find out if the given array is a numerical array 
    $keys = array_keys($arr); 
    $max_length = count($arr)-1; 
    if(($keys[0] == 0) and ($keys[$max_length] == $max_length)) {//See if the first key is 0 and last key is length - 1 
        $is_list = true; 
        for($i=0; $i<count($keys); $i++) { //See if each key correspondes to its position 
            if($i != $keys[$i]) { //A key fails at position check. 
                $is_list = false; //It is an associative array. 
                break; 
            } 
        } 
    } 

    foreach($arr as $key=>$value) { 
        if(is_array($value)) { //Custom handling for arrays 
            if($is_list) $parts[] = array2json($value); /* :RECURSION: */ 
            else $parts[] = '"' . $key . '":' . array2json($value); /* :RECURSION: */ 
        } else { 
            $str = ''; 
            if(!$is_list) $str = '"' . $key . '":'; 

            //Custom handling for multiple data types 
            if(is_numeric($value)) $str .= $value; //Numbers 
            elseif($value === false) $str .= 'false'; //The booleans 
            elseif($value === true) $str .= 'true'; 
            else $str .= '"' . addslashes($value) . '"'; //All other things 
            // :TODO: Is there any more datatype we should be in the lookout for? (Object?) 
			$str = str_replace(array("\r\n","\n"),"\\n", $str);
            $parts[] = $str; 
        } 
    } 
    $json = implode(',',$parts); 
     
    if($is_list) return '[' . $json . ']';//Return numerical JSON 
    return '{ ' . $json . ' }';//Return associative JSON 
}

function submit_record($uid,$exam_type,$usetime,$exam_time,$score)
{
	global $verifyid;
	
	DB::insert('tpexam_examrecord', array(
				'uid'=>$uid,
				'exam_type' => $exam_type,
				'usetime' => $usetime,
				'date' => $exam_time,
				'score'=> $score
				));
	

	return mysql_insert_id();
}



?>