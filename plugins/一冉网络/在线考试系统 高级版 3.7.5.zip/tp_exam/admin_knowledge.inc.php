<?php 
/**
 * tp_exam For Discuz!X 2.0+
 * ============================================================================
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�ʹ�ã�
 * �������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
 * @package    index
 * @module	   tp_exam 
 * @date	     2013-7-25
 * @author	   gaotianpeng
 * @copyright  Copyright (c) 2012 tpgao_kaoshi Platform Inc. (http://www.dxtm.net)
 */

/*
//--------------Tall us what you think!----------------------------------
*/

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


$act = addslashes($_GET['act']);
$formhash = addslashes($_GET['formhash']);
if(!submitcheck('editsubmit') && empty($act)) {

?>
	<script type="text/JavaScript">
	var rowtypedata = [
		[[1,'<input type="text" class="txt" name="newcatorder[]" value="0" />', 'td25'], [2, '<input name="newcat[]" value="" size="20" type="text" class="txt" />']],
		[[1,'<input type="text" class="txt" name="newsuborder[{1}][]" value="0" />', 'td25'], [2, '<div class="board"><input name="newsubcat[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
		[[1,'<input type="text" class="txt" name="newthirdorder[{1}][]" value="0" />', 'td25'], [2, '<div class="lastchildboard"><input name="newthird[{1}][]" value="" size="20" type="text" class="txt" /></div>']],
		];

	function del(id) {
		if(confirm('<?php echo lang('plugin/tp_exam', 'del_confirm');?>')) {
			window.location = '<?php echo ADMINSCRIPT;?>?action=plugins&operation=config&identifier=tp_exam&pmod=admin_knowledge&act=del&tid='+ id + '&formhash=<?php echo formhash();?>';
		} else {
			return false;
		}
	}
	</script>
<?php

	
		
	$id = lang('plugin/tp_exam', 'plugin_id');
	$parent = lang('plugin/tp_exam', 'plugin_parent');
	$shorturl = lang('plugin/tp_exam', 'admin_common_shorturl');
	$name = lang('plugin/tp_exam', 'plugin_type_name');
	$op = lang('plugin/tp_exam', 'admin_common_op');
	
	showtips(lang('plugin/tp_exam', 'admin_know_tips'));

	showformheader('plugins&operation=config&do='.$_GET['do'].'&identifier=tp_exam&pmod=admin_knowledge');
		showtableheader('');
		showsubtitle(array('ID',lang('plugin/tp_exam','s2'),lang('plugin/tp_exam','s3'),  lang('plugin/tp_exam','s4')));

		$brandtype = C::t('#tp_exam#tp_exam_knowledge')->fetch_all_by_upid(0);
		foreach($brandtype as $key=>$value){

			$bt = C::t('#tp_exam#tp_exam_knowledge')->fetch_all_by_upid($key);
			foreach($bt as $k=>$v){
				$th = C::t('#tp_exam#tp_exam_knowledge')->fetch_all_by_upid($k);
				$brandtype[$key]['subtype'][$k] = $v;
				
				foreach($th as $ke=>$val){
					$brandtype[$key]['subtype'][$k]['subtype'][$ke] =  $val;
				}

			}
		}
	
		if($brandtype) {
			foreach($brandtype as $id=>$type) {
				$show = '<tr class="hover"><td class="td25">ID:'.$id.'</td><td class="td25"><input type="text" class="txt" name="order['.$id.']" value="'.$type['displayorder'].'" /></td><td><div class="parentboard"><input type="text" class="txt" name="name['.$id.']" value="'.$type['subject'].'" style="width:150px;"></div></td>';
				if($type['level']  > 0) {
						$show .= '<td><a  onclick="del('.$id.')" href="###">'.lang('plugin/tp_exam','s5').'</td></tr>';
				} else {
					$show .= '<td><a  onclick="del('.$id.')" href="###">'.lang('plugin/tp_exam','s5').'</td></tr>';
				}
				echo $show;
				
				
				if($type['subtype'] ) {
					
					foreach($type['subtype'] as $subid=>$stype) {
						echo '<tr class="hover"><td class="td25">ID:'.$subid.'</td><td class="td25"><input type="text" class="txt" name="order['.$subid.']" value="'.$stype['displayorder'].'" /></td><td><div class="board"><input type="text" class="txt" name="name['.$subid.']" value="'.$stype['subject'].'"><a href="###" onclick="addrowdirect = 1;addrow(this, 2, '.$subid.')" class="addchildboard">'.lang('plugin/tp_exam','admin_add_subtype').'</a></div></td><td><a  onclick="del('.$subid.')" href="###">'.lang('plugin/tp_exam','s6').'</td></tr>';
						
						if( $stype['subtype'] ){
							foreach($stype['subtype'] as $tid=>$ttype) {
								echo '<tr class="hover"><td class="td25">ID:'.$tid.'</td><td class="td25"><input type="text" class="txt" name="order['.$tid.']" value="'.$ttype['displayorder'].'"></td><td><div id="cb_36" class="lastchildboard"><input type="text" name="name['.$tid.']" value="'.$ttype['subject'].'" class="txt"></div></td><td><a  onclick="del('.$tid.')" href="###">'.lang('plugin/tp_exam','s6').'</td></tr>';
							}
						}
					}
					
				}
				echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div class="lastboard"><a href="###" onclick="addrow(this, 1,'.$id.' )" class="addtr">'.lang('plugin/tp_exam','s7').'</a></div></td></tr>';
			}	
		}
		
		echo '<tr class="hover"><td class="td25">&nbsp;</td><td colspan="2" ><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/tp_exam','s8').'</a></div></td></tr>';
		

		showsubmit('editsubmit');
		showtablefooter(); /*d'.'is'.'m.ta'.'obao.com*/
		showformfooter(); /*dism��taobao��com*/
		
}elseif($act == 'del' && formhash() == $formhash){
	
	$tid = intval($_GET['tid']);
	DB::delete("tpexam_knowledge","id=$tid");
	cpmsg(lang('plugin/tp_exam','s9'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=tp_exam&pmod=admin_knowledge', 'succeed');	
	
}else
	{
		$order = $_GET['order'];
		$name = $_GET['name'];
		$newsubcat = $_GET['newsubcat'];
		$newcat = $_GET['newcat'];
		$newthird = $_GET['newthird'];
		$newsuborder = $_GET['newsuborder'];
		$newcatorder = $_GET['newcatorder'];
		$newthirdorder = $_GET['newthirdorder'];
		
	if(is_array($order)) {
			foreach($order as $id=>$value) {
				C::t('#tp_exam#tp_exam_knowledge')->update($id,array('displayorder'=>$value,'subject'=>$name[$id]));
			}
		}
		
		if(is_array($newcat)) {
			foreach($newcat as $key=>$name) {
				if(empty($name)) {
					continue;
				}
				$cid=C::t('#tp_exam#tp_exam_knowledge')->insert(array('upid' => '0', 'subject' => $name, 'displayorder' => $newcatorder[$key]),1);
			}
		}

		if(is_array($newsubcat)) {
			foreach($newsubcat as $cid=>$subcat) {
				$sub=C::t('#tp_exam#tp_exam_knowledge')->fetch($cid);
				$subtype =$sub['subid'];
				foreach($subcat as $key=>$name) {
					$subid=C::t('#tp_exam#tp_exam_knowledge')->insert(array('upid' => $cid, 'level'=>1,'subject' => $name, 'displayorder' => $newsuborder[$cid][$key]),1);
					$subtype .= $subtype ? ','.$subid : $subid;
				}
				C::t('#tp_exam#tp_exam_knowledge')->update($cid,array('subid'=>$subtype));
			}
		}

	if(is_array($newthird)) {
			foreach($newthird as $cid=>$subcat) {
				$sub=C::t('#tp_exam#tp_exam_knowledge')->fetch($cid);
				$subtype =$sub['subid'];
				foreach($subcat as $key=>$name) {
					$subid=C::t('#tp_exam#tp_exam_knowledge')->insert(array('upid' => $cid, 'level'=>2,'subject' => $name, 'displayorder' => $newthirdorder[$cid][$key]),1);
					$subtype .= $subtype ? ','.$subid : $subid;
				}
				C::t('#tp_exam#tp_exam_knowledge')->update($cid,array('subid'=>$subtype));
			}
		}
		
		cpmsg(lang('plugin/tp_exam','s9'), 'action=plugins&operation=config&do='.$_GET['do'].'&identifier=tp_exam&pmod=admin_knowledge', 'succeed');	

}
//From: di'.'sm.t'.'aoba'.'o.com
?>