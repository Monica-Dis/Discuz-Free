<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}
	$answer = daddslashes($_GET['answer']);
	$score = daddslashes($_GET['score']);
	$belong_paper = daddslashes($_GET['belong_paper']);
	$question = daddslashes($_GET['question']);
	$viewParserCredits = daddslashes($_GET['viewParserCredits']);
	$answerparser = daddslashes($_GET['answerparser']);
	$yuedulijie_timutype = daddslashes($_GET['yuedulijie_timutype']); //id
	$bgroups = intval($_GET['bgroups']);
		
	$insert = DB::insert('tpexam_tiku_wenda',array(
	'ask' => $question,
	'answer'=> $answer,
	'score'=>$score,
	'belong_paper'=>$belong_paper,
	'viewParser_credits'=>$viewParserCredits,
	'answer_parser'=>$answerparser,
	'yuedulijie_timutype'=>$yuedulijie_timutype,
	'image'=>$imageurl,
	'audio'=>$audiourl,
	'video'=>$videourl,
	'parser_img_path'=>$parser_imageurl),1);
	
	//$oid = mysql_insert_id();
	
	$post = array(
	'eid'=>0,
	'tid'	 => 5,
	'oid'	 => $insert,
	'groupid'=>$bgroups,
	'paperid'=>$belong_paper,
	'subject'=> $question,
	'option'=>'',
	'parser'=>$answerparser,
	'result'=>$answer,
	'image'=>$imageurl,
	'score'=>$score,
	'viewParser_credits'=>$viewParserCredits,
	'addtime'=> TIMESTAMP ,
	'yuedulijie'=>$yuedulijie_timutype,
	);
	
	$insert_eid = DB::insert('tpexam_tiku', $post, true);
	
	//$oid = mysql_insert_id();
	//$skey = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_tiku'));
	//$eid = $skey + 1;
	//DB::insert('tpexam_tiku', array('eid'=>$eid,'tid'=>5,'oid'=>$oid,'paperid'=>$belong_paper));
	
	//$eid = mysql_insert_id();
	DB::update('tpexam_tiku_wenda', array('eid'=>$insert_eid),"id IN ($insert)");
	
?>