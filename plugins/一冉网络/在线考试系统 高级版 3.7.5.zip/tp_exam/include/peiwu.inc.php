<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

	$score = daddslashes($_GET['score']);
	$question = daddslashes($_GET['question']);
	$belong_paper = daddslashes($_GET['belong_paper']);
	$nickname = daddslashes($_GET['nickname']);
	$ask = daddslashes($_GET['ask']);	
	$answer = daddslashes($_GET['answer']);
	$option = daddslashes($_GET['option']);
	$nickname = daddslashes($_GET['nickname']);
	
		DB::insert('tpexam_tiku_peiwu',array(
	'ask' => $question,
	'score'=>$score ,
	'belong_paper'=> $belong_paper,
	'nickname'=> $nickname));
	
	/*
	DB::insert('tpexam_tiku_peiwu',array(
	'ask'=>$question,
	'belong_paper'=>$belong_paper,
	'score'=>$score,
	'nickname'=>$nickname,
	'option1'=>$option[0],
	'option2'=>$option[1],
	'option3'=>$option[2],
	'option4'=>$option[3],
	'option5'=>$option[4],
	'option6'=>$option[5],
	'option7'=>$option[6],
	'answer1'=>$answer[0],
	'answer2'=>$answer[1],
	'answer3'=>$answer[2],
	'answer4'=>$answer[3],
	'answer5'=>$answer[4],
	'answer6'=>$answer[5],
	'answer7'=>$answer[6],
	'data'=>time(),
	'publish_uid'=>$_G['uid'],
	'viewParser_credits'=>$viewParser_credits,
	'answer_parser'=>$answer_parser));*/

?>