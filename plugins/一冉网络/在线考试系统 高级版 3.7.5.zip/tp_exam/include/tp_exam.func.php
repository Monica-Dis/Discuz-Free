<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if($_G['charset'] == 'utf-8') {
	$timu_type = arrayico("gb2312","utf-8",$timu_type);
}


function showtabcss(){
	
	$CSS = '<style type="text/css">
		.tp_tuan_tb{margin-top: 5px}
		.tp_tuan_tb td{padding:0px !important; border:none;}
		.tp_tuan_tab {background: url(source/plugin/tp_exam/static/bg_tab.gif) repeat-x 0px 22px;height: 28px;width: 100%;overflow: hidden;padding: 0px 10px;}
		.tp_tuan_tab a {display: block;position: relative;float: left;height: 20px;padding: 0px 10px;margin-top: 2px;background: url(source/plugin/tp_exam/static/bg_tab.gif) repeat-x 0px -100px;color: #999;text-decoration: none;line-height: 20px;*line-height: 22px;font-size: 12px;width: 100px;overflow: hidden;}
		.tp_tuan_tab_min a {width: 75px;}
		.tp_tuan_tab a i, .tp_tuan_tab a ins {background: url(source/plugin/tp_exam/static/bg_tab.gif) no-repeat;display: block;height: 20px;width: 5px;position: absolute;top: 0px;}
		.tp_tuan_tab a i{left: 0px;background-position: 0px -125px;}
		.tp_tuan_tab a ins {right: 0px;background-position: 0px -150px;}
		.tp_tuan_tab a.active {margin: 0px;height: 28px;background-position: 0px -10px;font-weight: bold;color: #FFF;line-height: 22px;*line-height: 24px;}
		.tp_tuan_tab a.active i, .lodov_tab a.active ins {height: 28px;	}
		.tp_tuan_tab a.active i{background-position: 0px -40px;}
		.tp_tuan_tab a.active ins {background-position: 0px -70px;}
		</style>';	
		
	echo $CSS;
}


function arrayico($in_charset,$out_charset,$arr){
	
    return eval('return '.iconv($in_charset,$out_charset,var_export($arr,true).';'));   
    
   $temp=array();
   foreach($arr as $k=>$v){
   	$a = iconv("gb2312","utf-8",$v);
   	$temp[]=$a;
   }
   
   return $temp;
}


function GetExamTypeCollapsible()
{
	$TopLevel = array();
	$OneLevel = array();
	$TwoLevel = array();
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_type')." where parent = 0");
	
	while($data = DB::fetch($query))
	{
		$level = GetLevel($data[id]);
		

		$data['nextlevel'] = $level;
		
		$TopLevel[]=$data;
	}
	
	return $TopLevel;	
}

function GetLevel($level){
	$one=array();
	$sql = DB::query("SELECT * FROM ".DB::table('tpexam_type')." where parent = $level");
	while($info = DB::fetch($sql))
	{
		$info['nextlevel'] = GetNextLevel($info['id']);
		$one[]=$info;
	}
	return $one;
}
function GetNextLevel($level){
	$two=array();
	$sql = DB::query("SELECT * FROM ".DB::table('tpexam_type')." where parent = $level");
	while($info = DB::fetch($sql))
	{
		$info['nextlevel'] = GetNextLevel($info['id']);
		$two[]=$info;
	}
	return $two;
}
function GetExamType()
{
	$area = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_type')." where parent = 0 order by sort asc");
	
	while($data = DB::fetch($query))
	{
		$data['treelevel'] = 0;
		$area[] = $data;
		
		$sql = DB::query("SELECT * FROM ".DB::table('tpexam_type')." where parent = $data[id] order by sort asc");
		while($info = DB::fetch($sql))
		{
			$info['treelevel'] = 1;
			$area[] = $info;
			
			$sql2 = DB::query("SELECT * FROM ".DB::table('tpexam_type')." where parent = $info[id] order by sort asc");
			while($list = DB::fetch($sql2))
			{
				$list['treelevel'] = 2;
				$area[] = $list;
			}
		}
		
	}
	
	return $area;
}

//
//��ȡ�Ծ�����
//
function GetPaperType($start=-1,$end=-1)
{
	$count = $end - $start;
	
	if($start != -1 && $end != -1)
	{
		$where = "limit $start,$count";
	}
	$area = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper') );
	
	if($data = DB::fetch($query))
	{
		$sql = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." order by sort desc $where");
		while($info = DB::fetch($sql))
		{
			$area[] = $info;
		}
		
	}

	return $area;
}

//
//�������������Ծ���$typeid ��� all
//�������Ծ� �������д $shorturl��$typeid��Ϊ0
//������ֱ����д$typeidΪ�Ծ�����

//�ѱ����溯��ȡ��GetPaperByTypeId
//
function GetExamTypeByTypeId($typeid,$shorturl,$start,$end)
{
	$area = array();

	if($typeid=='all') {
		return GetPaperType($start,$end);
	}
	else if ($typeid == 0){
		$type_item = DB::result_first("SELECT id FROM ".DB::table('tpexam_type')." where shorturl = '$shorturl'"); //��ȡID shorturl
		
		$query =  DB::query("SELECT * FROM ".DB::table('tpexam_type')." where parent = $type_item"); //����ID�����е�����
		while($row = DB::fetch($query))
		{
			$sql = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where belong = $row[id]  order by sort desc"); //��ÿ�������������Ծ�
			while($data = DB::fetch($sql))
			{
				$area[] = $data;
			}
		}
	}
	else if($typeid > 0) //ֱ�Ӳ��������Ծ�
	{
			$sql = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where belong = $typeid  order by sort desc"); //��ÿ�������������Ծ�
			while($data = DB::fetch($sql))
			{
				$area[] = $data;
			}
	}
	return $area;
}

//
//�жϽڵ��Ƿ������������ģ��
//
function GetNodeRandomModule($typeid)
{
	if($typeid!='all')
	{
		$sql = DB::query("SELECT * FROM ".DB::table('tpexam_chapter')." where belongnode = $typeid"); //��ÿ�������������Ծ�
		if($data = DB::fetch($sql))
		{
			return true;
		}
	}
	return false;
}

function GetPaperbyPaperId($paperid)
{
	$paper_arr=array();

	
	return $paper_arr;
}

function GetChildType($typeid)
{
	$typeid_arr=array();
	
	$query =  DB::query("SELECT * FROM ".DB::table('tpexam_type')." where parent = $typeid"); //����ID�� 
	while($row = DB::fetch($query))
	{
		$typeid_arr[]=$row['id'];
	}
	
	return $typeid_arr;
	
}
//�°溯����ȡ�������GetExamTypeByTypeId//

function GetPaperByTypeId($typeid,$shorturl,$start,$end)
{

		$paper_arr = array();
		$mainTypeList=array();
		
		$count = $end - $start;
		
		if($typeid == 'all'){
		
			return GetExamTypeByTypeId(0,'all',$start,$end);
			die();
		}
		
		$type_query= DB::query("SELECT * FROM ".DB::table('tpexam_type')." where id = $typeid order by sort asc"); //��ȡID 
		$current_arr=array();
		$brother = DB::fetch($type_query);  //��ѯ���ڵ�
		$current_arr[]=$brother['id'];
		
		//�Ȼ�õ�ǰ�������Ծ�
		$paper_arr = GetPaperbyPaperId($typeid);
		
		$childType = GetChildType($typeid);

		foreach($childType as $k=>$v){
			$mainTypeList[] = $v;
		}

		$mainTypeList[] = $current_arr[0];

		//��ȡ�����Ծ�
		foreach($mainTypeList as $n=>$value)
		{
				$paper_query =  DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where belong = $value order by sort desc limit $start,$end" ); //����ID�� 
				while($paper_row = DB::fetch($paper_query))
				{
					$paper_arr[]=$paper_row;
				}

		}

		return $paper_arr;
}



function GetPaperShowAnswer($item)
{
	$area = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id=$item");
	
	if($data = DB::fetch($query))
	{
		return $data['showanswer'];
	}
	
	return 1;
}

function GetPaperInfo($item)
{

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id=$item");
	
	if($data = DB::fetch($query))
	{
		return $data['paperinfo'];
	}
	
	return "";
}

function GetPaperParam($item)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id=$item");
	
	if($data = DB::fetch($query))
	{
		return $data;
	}
	
}

function GetExamTimu()
{
	$timu = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_timu'));
	
	while($data = DB::fetch($query))
	{
		$timu[] = $data;
	}
	
	return $timu;
}

function GetExamAnswer($obj)
{
	$daan=array();
	
	$daanarr=array();//����ȷ״̬
	
	$daan['ok']= 1; //�����ȷ״̬
		
	$result = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_timu'). " GROUP BY id ASC");
	
	$i = 0;
	$correct=true;
	$current_timu = 1;

	while($data = DB::fetch($query))
	{
		$result[] = $data;
	}
	

		foreach($obj as $k=>$v)
		{
			$item = $i + 1;
			$dest = $result[$current_timu - 1]['daan'.$item];
			
			//echo " ȡ���ĵ�".$item."��ѡ���".$dest;
			//echo " �����ĵ�".$k."��ѡ���".$v;
			if($v == 's')
			{
				//echo "  ��������������".$current_timu."���<br>";
				$i= 0;
				$correct=true;
			
				$daanarr[]=$daan;
				$daan['ok']= 1;
				
				$current_timu = $current_timu +1;
				continue;
			}
			
			//echo " û������������";
			if($correct) //�����û���������ж�
			{
				//echo 'ok';
				if($dest != $v )
				{
					$correct=false;
					//echo " ��".$current_timu."���".$dest."=>".$v."<br>";
					$daan['ok']= 0;
				}
				else
				{
				//	echo " ��ȷ ת��һѡ��<br>";
				}
			}
			else
			{
				//echo " �����Ѵ������β��ж�";
			}
			
			$i=$i+1;
		}
		
		//echo '�ܴ𰸿�ʼ';
		//print_r($daanarr);
		
		return $daanarr;
}
	
//
//�жϸ��Ծ��Ƿ���Ҫ��д������Ϣ
//
function GetNeedLogin($needitem)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id= $needitem");
	
	if($data = DB::fetch($query))
	{
		return $data['needlogin'];
	}
}

function GetNeedPractise($needpractise)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id= $needpractise");
	if($data = DB::fetch($query))
	{
		return $data['practise'];
	}
	return false;
}
//
//�ж�����ʱ���Ƿ����Ҫ��
//Ϊ�ջ�0����ֱ�ӷ��У�������Ҫ����Ҫ��
//
function CheckOnlinetime($uid,$paperid)
{
		$module['oltime'] = true;
		$query = DB::query("SELECT * FROM ".DB::table('common_member_count')." where uid= $uid");
		
		if($data = DB::fetch($query))
		{
			$paper =  DB::query("SELECT * FROM ".DB::table('tpexam_module')." where belongpaper= $paperid");
			
			while($row = DB::fetch($paper))
			{

				if(trim($row['module']) == 'onlinetime')
				{
					if($data['oltime'] < $row['value']  )
					{

						$module['oltime'] = false;
						
						$module1 =  DB::query("SELECT * FROM ".DB::table('tpexam_module_item')." where modulename = '$row[module]'");
						if($mod = DB::fetch($module1))
						{
							$module['moduletips'] = $mod['modulefailtips'];
						}
					}
				}
			}


		}
		
		return $module;
}

//
//����ID��ȡ�Ծ�����
//
function GetExamName($item)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id= $item");
	
	if($data = DB::fetch($query))
	{
		return $data['name'];
	}
}

//
//�����Ծ�����ȡ��ѡ��
//0 - δ��
//1 - ȫ��
//2 - �ѿ�
//
function GetDaXuanByPaperID($item)
{
	$tiku=array();

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belong_paper = $item and yuedulijie_timutype <= 0 and peiwu = 0 order by id ASC");
	//tpexam_tiku_danxuan
	
	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����
		$data['option1']=str_replace("\'","'",$data['option1']);//����
		$data['option2']=str_replace("\'","'",$data['option2']);//����
		$data['option3']=str_replace("\'","'",$data['option3']);//����
		$data['option4']=str_replace("\'","'",$data['option4']);//����
		$data['option5']=str_replace("\'","'",$data['option5']);//����
		$data['option6']=str_replace("\'","'",$data['option6']);//����
		$data['option7']=str_replace("\'","'",$data['option7']);//����
		
		require_once libfile ( 'function/discuzcode' );
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 1, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);

		//����video
		if (is_numeric($data['video'])) {
			require_once libfile ('include/askvideo','plugin/tp_exam');
		 	$data['videoid'] = $data['video'];
		 	$data['video'] = getaskvideo($data['video']);
		 	$data['videosrc_url'] = getaskvideosrcurl($data['videoid']);
		 	$data['videochapter_info'] = getaskvideocpidinfo($data['videoid']);
		}
		$data['image']=trim($data['image']);//����
		 $tiku[] = $data;
	}
	
	return $tiku;
}

//�����Ծ�����ȡ��ѡ��
//
//0 - δ��
//1 - ȫ��
//2 - �ѿ�
//
function GetDuoXuanByPaperID($item,$unexam=1)
{
	$tiku=array();
	if($unexam==1){
		$where = "where belong_paper = $item and yuedulijie_timutype <= 0 and peiwu = 0 ";
	}
	else{
		$where = "where belong_paper = $item and examed = $unexam and yuedulijie_timutype <= 0 and peiwu = 0 ";
	}
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." $where order by id asc" );

	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����
		$data['option1']=str_replace("\'","'",$data['option1']);//����
		$data['option2']=str_replace("\'","'",$data['option2']);//����
		$data['option3']=str_replace("\'","'",$data['option3']);//����
		$data['option4']=str_replace("\'","'",$data['option4']);//����
		$data['option5']=str_replace("\'","'",$data['option5']);//����
		
		require_once libfile ( 'function/discuzcode' );
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);

		if (is_numeric($data['video'])) {
			require_once libfile ('include/askvideo','plugin/tp_exam');
		 	$data['videoid'] = $data['video'];
		 	$data['video'] = getaskvideo($data['video']);
		 	$data['videosrc_url'] = getaskvideosrcurl($data['videoid']);
		 	$data['videochapter_info'] = getaskvideocpidinfo($data['videoid']);
		}
		
		 $tiku[] = $data;
	}
	
	return $tiku;
}

function GetPanDuanByPaperID($item,$unexam=1)
{
	$tiku=array();
	if($unexam==1){
		$where = "where belong_paper = $item and yuedulijie_timutype <= 0 ";
	}
	else{
		$where = "where belong_paper = $item and examed = $unexam and yuedulijie_timutype <= 0 ";
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." $where order by id asc");

	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����

		//����video
		if (is_numeric($data['video'])) {
			require_once libfile ('include/askvideo','plugin/tp_exam');
		 	$data['videoid'] = $data['video'];
		 	$data['video'] = getaskvideo($data['video']);
		 	$data['videosrc_url'] = getaskvideosrcurl($data['videoid']);
		 	$data['videochapter_info'] = getaskvideocpidinfo($data['videoid']);
		}
		
		 $tiku[] = $data;
	}
	
	return $tiku;
}


function GetTiankongByPaperID($item,$unexam=1)
{
	$tiku=array();
	if($unexam==1){
		$where = "where belong_paper = $item and yuedulijie_timutype <= 0 ";
	}
	else{
		$where = "where belong_paper = $item and examed = $unexam and yuedulijie_timutype <= 0 ";
	}
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." $where order by id asc");

	while($data = DB::fetch($query))
	{
		  $data['ask']=str_replace("\'","'",$data['ask']);//����

		//����video
		if (is_numeric($data['video'])) {
			require_once libfile ('include/askvideo','plugin/tp_exam');
		 	$data['videoid'] = $data['video'];
		 	$data['video'] = getaskvideo($data['video']);
		 	$data['videosrc_url'] = getaskvideosrcurl($data['videoid']);
		 	$data['videochapter_info'] = getaskvideocpidinfo($data['videoid']);
		}
		
		 $tiku[] = $data;
	}
	
	return $tiku;
}


function GetYuedulijieByPaperID($item)
{
	$tiku=array();
	require_once libfile ( 'function/discuzcode' );
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_yuedulijie')." where belong_paper = $item order by id asc");
	while($data = DB::fetch($query))
	{
		
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$tiku[]=$data;
	}
	
	return $tiku;
}

function GetPeiwuByPaperID($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_peiwu')." where belong_paper = $item");
	while($data = DB::fetch($query))
	{
		$tiku[]=$data;
	}
	
	return $tiku;
}

function GetSingleByIdList($id_arr)
{
	
	$tiku=array();
	
	$id_item_arr=array();
	
	foreach($id_arr as $k=>$v)
	{

			//echo 'v='.$v.'<br>';
			
			$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where id = $v");
			while($data = DB::fetch($query))
			{
				//echo 'find id='.$v.'<br>';
				//$id_item_arr[]=$data;
				$tiku[]=$data;
			}
		
			//$tiku[]=$id_item_arr;
			//unset($id_item_arr);

	}
	
	return $tiku;
}

function GetYuedulijie_SingleByPaperID($item)
{
	$tiku=array();
	$single_arr=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belong_paper = $item and yuedulijie_timutype > 0");
	while($data = DB::fetch($query))
	{
		$tiku[$data['yuedulijie_timutype']][]=$data;
	}
	return $tiku;
}

function GetYuedulijie_MultiByPaperID($item){
		$tiku=array();
	$single_arr=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where belong_paper = $item and yuedulijie_timutype > 0");
	while($data = DB::fetch($query))
	{
		$tiku[$data['yuedulijie_timutype']][]=$data;
	}
	return $tiku;
}
function GetYuedulijie_PanduanByPaperID($item){
		$tiku=array();
	$single_arr=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where belong_paper = $item and yuedulijie_timutype > 0");
	while($data = DB::fetch($query))
	{
		$tiku[$data['yuedulijie_timutype']][]=$data;
	}
	return $tiku;
}

function GetYuedulijie_TiankongByPaperID($item){
	$tiku=array();
	$single_arr=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where belong_paper = $item and yuedulijie_timutype > 0");
	while($data = DB::fetch($query))
	{
		$tiku[$data['yuedulijie_timutype']][$data['id']]=$data;
	}
	return $tiku;
}

function GetYuedulijie_WendaByPaperID($item){
	$tiku=array();
	$single_arr=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." where belong_paper = $item and yuedulijie_timutype > 0");
	while($data = DB::fetch($query))
	{
		$tiku[$data['yuedulijie_timutype']][]=$data;
	}
	return $tiku;
}

function GetPeiwu_SingleByPaperId($item)
{
	$tiku=array();
	$single_arr=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belong_paper = $item order by id asc ");
	while($data = DB::fetch($query))
	{
		$tiku[$data['peiwu']][$data['id']]=$data;
	}
	return $tiku;
}


function GetWendaByPaperID($item,$unexam=1)
{
	$tiku=array();
	if($unexam==1){
		$where = "where belong_paper = $item and yuedulijie_timutype <= 0 ";
	}
	else{
		$where = "where belong_paper = $item and examed = $unexam and yuedulijie_timutype <= 0 ";
	}
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." $where order by id asc");

	while($data = DB::fetch($query))
	{
		 $data['ask']=str_replace("\'","'",$data['ask']);//����	
		 
		//����video
		if (is_numeric($data['video'])) {
			require_once libfile ('include/askvideo','plugin/tp_exam');
		 	$data['videoid'] = $data['video'];
		 	$data['video'] = getaskvideo($data['video']);
		 	$data['videosrc_url'] = getaskvideosrcurl($data['videoid']);
		 	$data['videochapter_info'] = getaskvideocpidinfo($data['videoid']);
		}
		
		 $tiku[] = $data;
	}
	
	return $tiku;
}

function GetDaAnByID($item,$param)
{
	$ret = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where id = $item");
	
	if($data = DB::fetch($query))
	{
		$ret['daan'] = $data['answer'];
	}
	
	return $ret;
}

function GetAnswerByPaperID_DanXuan($item,$usrAnswer)
{
	$tiku=array();
	$ret=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belong_paper = $item");
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	

	foreach($usrAnswer as $k=>$v)
	{
		$singleDaan = GetDaAnByID($k);

		if(trim($singleDaan['daan']) == trim($v[0]))
		{
			$singleDaan['r'] = 'R';
		}
		else
		{
			$singleDaan['r'] = 'W';
		}
		
		$singleDaan['id'] = $k;
		$singleDaan['parser'] = GetAnswerParser($k,'tpexam_tiku_danxuan');
		$singleDaan['needbuyparser'] = GetAnswerParser($k,'tpexam_tiku_danxuan',1);
		$ret[] = $singleDaan;
	}

	return $ret;
}

function GetDaAnByID_duoxuan($item)
{
	$ret = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where id = $item");
	$k=1;
	if($data = DB::fetch($query))
	{
		while($k<6)
		{
			$ret[] = $data['answer'.$k];
			$k++;
		}
	}
	return $ret;
}

function GetAnswerByPaperID_DuoXuan($item,$usrAnswer)
{
	$tiku=array();
	$ret=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where belong_paper = $item");
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	//print_r($usrAnswer);
	
	foreach($usrAnswer as $k=>$v)
	{
		$MuliteDaan = GetDaAnByID_duoxuan($k);
		//echo 'k='.$k;
		//print_r($MuliteDaan);
		//echo "<br>";
		if($v[0] == $MuliteDaan[0] &&
		$v[1] == $MuliteDaan[1] &&
		$v[2] == $MuliteDaan[2] &&
		$v[3] == $MuliteDaan[3] &&
		$v[4] == $MuliteDaan[4]
		)
		{
			$MuliteDaan['r'] = 'R';
		}
		else
		{
			$MuliteDaan['r'] = 'W';
		}
		$MuliteDaan['daan'] = $MuliteDaan[0].$MuliteDaan[1].$MuliteDaan[2].$MuliteDaan[3].$MuliteDaan[4];
		$MuliteDaan['id'] = $k;
		$MuliteDaan['parser'] = GetAnswerParser($k,'tpexam_tiku_duoxuan');
		$MuliteDaan['needbuyparser'] = GetAnswerParser($k,'tpexam_tiku_duoxuan',1);
		$ret[] = $MuliteDaan;
	}
	
	return $ret;
}

function GetDaAnByID_panduan($item)
{
	$ret = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where id = $item");

	if($data = DB::fetch($query))
	{
		
		if($data['answer'] == 1)
			$ret['daan'] = 1;
		else
			$ret['daan'] = 0;

	}
	return $ret;
}


function GetAnswerByPaperID_PanDuan($item,$usrAnswer)
{
	$tiku=array();
	$ret=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where belong_paper = $item");
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	foreach($usrAnswer as $k=>$v)
	{
		$panduan = GetDaAnByID_panduan($k);

		if(trim($v[1]) == trim($panduan['daan']) )
		{

				$panduan['r'] = 'R';
		}
		else
		{

			$panduan['r'] = 'W';
		}
	

		$panduan['id'] = $k;
		$panduan['parser'] = GetAnswerParser($k,'tpexam_tiku_panduan');
		$panduan['needbuyparser'] = GetAnswerParser($k,'tpexam_tiku_panduan',1);
		$ret[] = $panduan;
	}
	
	return $ret;
}

function isTiankongEquel($usrAnswer,$Answer)
{

	$ok=1;
	foreach($usrAnswer as $k=>$value)
	{
		if($value == '') 
			return false;
		else
		{
			if(trim($value) != trim($Answer[$k]))
			{
				$ok=0;
			}
			if($ok==0)
			{
				return false;
			}
		}
		
	}
	
	if($ok) 
		return true;
	else
		return false;
}

function GetTiankongAnswerById($record,$iid)
{
	foreach($record as $n=>$v)
	{
		if($v['id'] == $iid)
		{
			return $v['answer'];
		}
	}
}

function GetAnswerScore($iid,$table)
{
	$ret = 0;
	$query = DB::query("SELECT * FROM ".DB::table($table)." where id = $iid");
	
	if($data = DB::fetch($query))
	{
			$ret = $data['score'];
	}
	
	return $ret;	
}
function GetAnswerByPaperID_Tiankong($item,$usrAnswer)
{
	$tiku=array();
	$ret=array();
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where belong_paper = $item");
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}

	foreach($usrAnswer as $k=>$v)
	{

		$answer = GetTiankongAnswerById($tiku,$k);
		$result = explode("|",$answer);
		$tiankong = array();
		if(isTiankongEquel($v,$result))
		{
			//echo '����ȷ';
			$tiankong['r'] = 'R';
			$tiankong['daan'] = $answer;
			$tiankong['score'] = GetAnswerScore($k,'tpexam_tiku_tiankong');
		}
		else
		{
			$tiankong['r'] = 'W';
			$tiankong['daan'] = $answer;
			$tiankong['score'] = 0;
			//echo '�𰸴�';
		}

			$tiankong['id'] = $k;
			$tiankong['userAnswer'] = $v;
			$tiankong['parser'] = GetAnswerParser($k,'tpexam_tiku_tiankong');
			$tiankong['needbuyparser'] = GetAnswerParser($k,'tpexam_tiku_tiankong',1);
			$ret[] = $tiankong;
	}
	
	return $ret;
}

function GetAnswerByPaperID_Yuedulijie($item,$usrAnswer)
{
	$tiku=array();
	$ret=array();

	foreach($usrAnswer as $k=>$v)
	{
		$singleDaan = GetDaAnByID($k);

		if(trim($singleDaan['daan']) == trim($v[0]))
		{
			$singleDaan['r'] = 'R';
		}
		else
		{
			$singleDaan['r'] = 'W';
		}
		
		$singleDaan['id'] = $k;
		$singleDaan['parser'] = GetAnswerParser($k,'tpexam_tiku_danxuan');
		$singleDaan['needbuyparser'] = GetAnswerParser($k,'tpexam_tiku_danxuan',1);
		$ret[] = $singleDaan;
	}

	return $ret;
}

function GetScore_Yuedulijie($answer)
{
	$danxuan_score = 0;
	
	foreach($answer as $k=>$v)
	{
		if($v['r'] == 'R')
		{
			$single_score = GetSingleScorebyId_danxuan($v['id']);
			$danxuan_score = $danxuan_score + $single_score['score'];
		}
	}
	
	return $danxuan_score;
	
}

//
//��������
//
function GetSingleScorebyId_danxuan($item)
{
	$score = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where id = $item");
	if($data = DB::fetch($query))
	{
		$score  = $data;
	}
	
	return $score;
}
function GetScore_DanXuan($answer)
{
	$danxuan_score = 0;
	
	foreach($answer as $k=>$v)
	{
		if($v['r'] == 'R')
		{
			$single_score = GetSingleScorebyId_danxuan($v['id']);
			$danxuan_score = $danxuan_score + $single_score['score'];
		}
	}
	
	return $danxuan_score;
	
}

function GetSingleScorebyId_duoxuan($item)
{
	$score = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where id = $item");
	if($data = DB::fetch($query))
	{
		$score  = $data;
	}
	
	return $score;
}
function GetScore_DuoXuan($answer)
{
	$duoxuan_score = 0;
	
	foreach($answer as $k=>$v)
	{
		if($v['r'] == 'R')
		{
			$single_score = GetSingleScorebyId_duoxuan($v['id']);
			$duoxuan_score = $duoxuan_score + $single_score['score'];
		}
	}
	
	return $duoxuan_score;
}

function GetSingleScorebyId_panduan($item)
{
	$score = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where id = $item");
	if($data = DB::fetch($query))
	{
		$score  = $data;
	}
	
	return $score;
}
function GetScore_PanDuan($answer)
{
	$panduan_score = 0;
	
	foreach($answer as $k=>$v)
	{
		if($v['r'] == 'R')
		{
			$single_score = GetSingleScorebyId_panduan($v['id']);
			$panduan_score = $panduan_score + $single_score['score'];
		}
	}
	
	return $panduan_score;
}

function GetScore_Tiankong($answer)
{
	$tiankong_score= 0;
	foreach($answer as $k=>$v)
	{
		if($v['r'] == 'R')
		{
			$tiankong_score += $v['score'];
		}
	}
	
	return $tiankong_score;
}

function GetVerifyCompanyByUnqiCode($item,$UnqiCode)
{
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where uniquecode = '$UnqiCode'");
		if($data = DB::fetch($query))
		{
			$company  = $data['company'];
		}
	
		return $company;
}

function GetVerifyNameByUnqiCode($item,$UnqiCode)
{
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where uniquecode = '$UnqiCode'");
		if($data = DB::fetch($query))
		{
			$username  = $data['username'];
		}
	
		return $username;
}
function GetVerifyIdcardByUnqiCode($item,$UnqiCode)
{
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where uniquecode = '$UnqiCode'");
		if($data = DB::fetch($query))
		{
			$idcard  = $data['idcard'];
		}
	
		return $idcard;
}
function GetVerifyStudentIdByUnqiCode($item,$UnqiCode)
{
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where uniquecode = '$UnqiCode'");
		if($data = DB::fetch($query))
		{
			$student_id  = $data['student_id'];
		}
	
		return $student_id;
}

function GetVerifyCompany($item,$uid,$verifyid=0)
{
	
	if($verifyid > 0){
		$where = " where id = $verifyid";
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." $where");
		if($data = DB::fetch($query))
		{
			$company  = $data['company'];
		}
	
		return $company;
	}
	
	if($uid>0){
		$where = "and belongpaper = $item";
	}
	else{
		$where="";
	}
	
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where uid = $uid $where");
	if($data = DB::fetch($query))
	{
		$company  = $data['company'];
	}
	
	return $company;
}

function GetVerifyName($item,$uid,$verifyid=0)
{
	if($verifyid > 0){
		$where = " where id = $verifyid";
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." $where");
		if($data = DB::fetch($query))
		{
			$company  = $data['username'];
		}
	
		return $company;
	}
	
	if($uid>0){
		$where = "and belongpaper = $item";
	}
	else{
		$where="";
	}
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where uid = $uid $where");
	if($data = DB::fetch($query))
	{
		$Name  = $data['username'];
	}
	
	return $Name;
}


function GetVerifyIdcard($item,$uid,$verifyid=0)
{
	if($verifyid > 0){
		$where = " where id = $verifyid";
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." $where");
		if($data = DB::fetch($query))
		{
			$company  = $data['idcard'];
		}
	
		return $company;
	}
	
	
	if($uid>0){
		$where = "and belongpaper = $item";
	}
	else{
		$where="";
	}
	
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where uid = $uid $where");
	if($data = DB::fetch($query))
	{
		$Name  = $data['idcard'];
	}
	
	return $Name;
}

function GetVerifyStudentId($item,$uid,$verifyid=0)
{
	if($verifyid > 0){
		$where = " where id = $verifyid";
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." $where");
		if($data = DB::fetch($query))
		{
			$company  = $data['student_id'];
		}
	
		return $company;
	}
	
	if($uid>0){
		$where = "and belongpaper = $item";
	}
	else{
		$where="";
	}
	
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_verify_data')." where uid = $uid $where");
	if($data = DB::fetch($query))
	{
		$Name  = $data['student_id'];
	}
	
	return $Name;
}

function GetAllTypeTiKu($dan=1,$duo=1,$pan=1,$tian=1,$wen=1)
{
	$ret=array();
	$timu=array();
	
	if($dan){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." order by id desc");
		while($data = DB::fetch($query))
		{
			$timu['id']=$data['id'];
			$timu['ask']=$data['ask'];
			$timu['score']=$data['score'];
			$timu['paper']=$data['belong_paper'];
			$timu['data']=$data['data'];
			$timu['publish_uid']=$data['publish_uid'];
			$timu['type']='danxuan';
			$timu['tid']=$data['tid'];
			$ret[]  = $timu;
			unset($timu);
		}
	}
	if($duo){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." order by id desc");
		while($data = DB::fetch($query))
		{
			$timu['id']=$data['id'];
			$timu['ask']=$data['ask'];
			$timu['score']=$data['score'];
			$timu['paper']=$data['belong_paper'];
			$timu['data']=$data['data'];
			$timu['publish_uid']=$data['publish_uid'];
			$timu['type']='duoxuan';
			$timu['tid']=$data['tid'];
			$ret[]  = $timu;
			unset($timu);
		}
	}
	if($pan){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." order by id desc");
		while($data = DB::fetch($query))
		{
			$timu['id']=$data['id'];
			$timu['ask']=$data['ask'];
			$timu['score']=$data['score'];
			$timu['paper']=$data['belong_paper'];
			$timu['data']=$data['data'];
			$timu['publish_uid']=$data['publish_uid'];
			$timu['type']='panduan';
			$timu['tid']=$data['tid'];
			$ret[]  = $timu;
			unset($timu);
		}
	}
	if($wen){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." order by id desc");
		while($data = DB::fetch($query))
		{
			$timu['id']=$data['id'];
			$timu['ask']=$data['ask'];
			$timu['score']=$data['score'];
			$timu['paper']=$data['belong_paper'];
			$timu['data']=$data['data'];
			$timu['publish_uid']=$data['publish_uid'];
			$timu['type']='wenda';
			$timu['tid']=$data['tid'];
			$ret[]  = $timu;
			unset($timu);
		}
	}
	if($tian){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." order by id desc");
		while($data = DB::fetch($query))
		{
			$timu['id']=$data['id'];
			$timu['ask']=$data['ask'];
			$timu['score']=$data['score'];
			$timu['paper']=$data['belong_paper'];
			$timu['data']=$data['data'];
			$timu['publish_uid']=$data['publish_uid'];
			$timu['type']='tiankong';
			$timu['tid']=$data['tid'];
			$ret[]  = $timu;
			unset($timu);
		}
	}

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_yuedulijie')." order by id desc");
	while($data = DB::fetch($query))
	{
		$timu['id']=$data['id'];
		$timu['ask']=$data['ask'];
		$timu['score']=$data['score'];
		$timu['paper']=$data['belong_paper'];
		$timu['data']=$data['data'];
		$timu['publish_uid']=$data['publish_uid'];
		$timu['type']='yuedu';
		$timu['tid']=$data['tid'];
		$ret[] = $timu;
		unset($timu);
	}	
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_peiwu')." order by id desc");
	while($data = DB::fetch($query))
	{
		$timu['id']=$data['id'];
		$timu['ask']=$data['ask'];
		$timu['score']=$data['score'];
		$timu['paper']=$data['belong_paper'];
		$timu['data']=$data['data'];
		$timu['publish_uid']=$data['publish_uid'];
		$timu['type']='peiwu';
		$timu['tid']=$data['tid'];
		$ret[] = $timu;
		unset($timu);
	}	
	
	return $ret;
}

function GetPaperName($item)
{
	$paper = '';
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." WHERE id= $item");

	if($data = DB::fetch($query))
	{
		$paper = $data['name'];
	}

	return $paper;
}

function GetExamByPaperID($item)
{
	$paper = array();
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." WHERE id= $item");
	
	if($data = DB::fetch($query))
	{
		$paper = $data;
	}
	
	return $paper;
}

function danxuan_answer_adjust($list,$answer)
{
	$ret = array();
	foreach($list as $k=>$v)
	{
		$ret[] = '';
		foreach($answer as $n=>$val)
		{
			if($v['id'] == $val['id'])
			{
				$ret[$k] = $val;
				break;
			}
		}
	}

	return $ret;
}

function duoxuan_answer_adjust($list,$answer)
{
//	print_r($list);
//	print_r($answer);
	$ret = array();
	foreach($list as $k=>$v)
	{
		$ret[] = '';
		foreach($answer as $n=>$val)
		{
			if($v['id'] == $val['id'])
			{
				$ret[$k] = $val;
				break;
			}
		}
	}
	
	//print_r($ret);
	return $ret;
}

function panduan_answer_adjust($list,$answer)
{
	$ret = array();
	foreach($list as $k=>$v)
	{
		$ret[] = '';
		foreach($answer as $n=>$val)
		{
			if($v['id'] == $val['id'])
			{
				$ret[$k] = $val;
				break;
			}
		}
	}

	return $ret;
}

function tiankong_answer_adjust($list,$answer)
{

	$ret = array();
	foreach($list as $k=>$v)
	{
		$ret[] = '';
		foreach($answer as $n=>$val)
		{
			if($v['id'] == $val['id'])
			{
				$ret[$k] = $val;
				break;
			}
		}
	}

	return $ret;
}

function yuedulijie_answer_adjust($list,$answer)
{
	//�����ά����
	$single_list=array();
	foreach($list as $n1=>$v1)
	{
		foreach($v1 as $n2=>$v2)
		{
			$single_list[] = $v2;
		}
	}

	$ret = array();
	foreach($single_list as $k=>$v)
	{
		$ret[] = '';
		foreach($answer as $n=>$val)
		{
			if($v['id'] == $val['id'])
			{
				$ret[$k] = $val;
				break;
			}
		}
	}

	return $ret;
}

function GetNeedPay($needitem)
{
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id= $needitem");
	
	if($data = DB::fetch($query))
	{
		return $data['needpay'];
	}
}

function GetPaymentInfo()
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_setting')." where skey = 'pay'");
	if($data = DB::fetch($query))
	{

		return $data;
	}
	
	return $ret;
}

function GetTiankongAsk($tiankong,$usrAnswer=0,$mobile=0)
{

	$replacedTime = 0;
	
	foreach($tiankong as $n=>$v)
	{
		$ask = $tiankong[$n]['ask'];
		$id = $v['id'];
		if(is_array($usrAnswer)){
			$usr = $usrAnswer[$id][$replacedTime + 1];
		}
	
		if(!$mobile){
			$ask = preg_replace("/#([0-9]+)/","<input style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\"  value=\"".$usr."\" size=\\1 name=\"t_answer[".$tiankong[$n]['id']."][]\">",$ask,1);
		}
		else{
			$ask = preg_replace("/#([0-9]+)/","<input data-role='none' style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\"  value=\"".$usr."\" size=\\1 name=\"t_answer[".$tiankong[$n]['id']."][]\">",$ask,1);	
		}
		
	
		while(preg_match( '/#\d+/', $ask, $matches)){
			$replacedTime  = $replacedTime + 1;
			if(is_array($usrAnswer)){
				$usr = $usrAnswer[$v['id']][$replacedTime + 1];
			}
			if($mobile){
				$ask = preg_replace("/#([0-9]+)/","<input data-role='none' style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\"  value=\"".$usr."\" size=\\1 name=\"t_answer[".$tiankong[$n]['id']."][]\">",$ask,1);	
			}
			else{
				$ask = preg_replace("/#([0-9]+)/","<input data-role='none' style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\"  value=\"".$usr."\" size=\\1 name=\"t_answer[".$tiankong[$n]['id']."][]\">",$ask,1);	
			}
		}
		
		$replacedTime = 0;
		$result[] = $ask; 
		
	}
	
	return $result;
}

function y_GetTiankongAsk($tiankong,$usrAnswer=0,$mobile=0)
{

	$replacedTime = 0;
	foreach($tiankong as $n=>$v)
	{
		foreach($v as $k=>$val)
		{
			$ask = $val['ask'];
			
			$id = $val['id'];
			if(is_array($usrAnswer) && !empty($usrAnswer)){
				$usr = $usrAnswer[$id][$replacedTime + 1];
			}
		
			if(!$mobile){
				$ask = preg_replace("/#([0-9]+)/","<input style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\"  value=\"".$usr."\" size=\\1 name=\"t_answer[".$id."][]\">",$ask,1);
			}
			else{
				$ask = preg_replace("/#([0-9]+)/","<input data-role='none' style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\"  value=\"".$usr."\" size=\\1 name=\"t_answer[".$id."][]\">",$ask,1);	
			}
			
			while(preg_match( '/#\d+/', $ask, $matches)){
				$replacedTime  = $replacedTime + 1;
				if(is_array($usrAnswer)){
					$usr = $usrAnswer[$id][$replacedTime + 1];
				}
				if($mobile){
						$ask = preg_replace("/#([0-9]+)/","<input data-role='none' style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\"  value=\"".$usr."\" size=\\1 name=\"t_answer[".$id."][]\">",$ask,1);	
				}
				else{
					$ask = preg_replace("/#([0-9]+)/","<input data-role='none' style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\"  value=\"".$usr."\" size=\\1 name=\"t_answer[".$id."][]\">",$ask,1);	
				}
			}
		
			$replacedTime = 0;
			//$result[] = $ask; 
		
			$tiankong[$n][$k]['ask']=  $ask;
		}

	}
	
	return $tiankong;

}

function GetAnswerParser($item,$param,$needbuy = 0)
{
	$ret = '';
	$query = DB::query("SELECT * FROM ".DB::table($param)." where id = $item");
	
	if($data = DB::fetch($query))
	{
		if(!$needbuy)
		{
			$ret = $data['answer_parser'];
		}
		else
		{
			$ret = $data['viewParser_credits'];
		}
	}
	
	return $ret;
}

function GetDanxuanById($item)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where id = $item");
	if($data = DB::fetch($query))
	{
		require_once libfile ( 'function/discuzcode' );
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		
		return $data;
	}
}

function GetDanxuanByIdArray($idarr)
{
	$tiku=array();
	$list = implode(",",$idarr);
	if(count($idarr)>0){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where id IN ($list)");
		while($data = DB::fetch($query))
		{
			$tiku[]=$data;
		}
	}
	return $tiku;
}

function GetDuoxuanById($item)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where id = $item");
	if($data = DB::fetch($query))
	{
		require_once libfile ( 'function/discuzcode' );
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		return $data;
	}
}

function GetDuoxuanByIdArray($idarr)
{

	$tiku=array();
	
	if(count($idarr)==0)
		return;

	$list = implode(",",$idarr);
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where id IN ($list)");
	while($data = DB::fetch($query))
	{
		$tiku[]=$data;
	}
	
	return $tiku;
}

function GetPanduanById($item)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where id = $item");
	if($data = DB::fetch($query))
	{
		require_once libfile ( 'function/discuzcode' );
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);

		return $data;
	}
}

function GetPanduanByIdArray($idarr)
{
	$tiku=array();
	
	if(count($idarr)==0)return;
	
	$list = implode(",",$idarr);
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where id IN ($list)");
	while($data = DB::fetch($query))
	{
		$tiku[]=$data;
	}
	return $tiku;
}

function GetTiankongById($item)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where id = $item");
	if($data = DB::fetch($query))
	{

		return $data;
	}
}

function GetTiankongByIdArray($idarr)
{
	$tiku=array();
	
	if(count($idarr)==0)return;
	
	$list = implode(",",$idarr);
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where id IN ($list)");
	while($data = DB::fetch($query))
	{
		$tiku[]=$data;
	}
	return $tiku;
}

function GetWendaById($item)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." where id = $item");
	if($data = DB::fetch($query))
	{
		require_once libfile ( 'function/discuzcode' );
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);

		return $data;
	}
}

function GetWendaByIdArray($idarr)
{
	$tiku=array();
	
	if(count($idarr)==0)return;
	
	$list = implode(",",$idarr);
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." where id IN ($list)");
	while($data = DB::fetch($query))
	{
		$tiku[]=$data;
	}
	return $tiku;
}
function GetPeiwuJiaojuanInfo($peiwu_a)
{
	$total_peiwu=array();
		
	foreach($peiwu_a as $k=>$val)
	{
		$peiwuInfo = GetPeiwuInfoById($k);
		
		$jiaojuanInfo = ProcessPeiwu($val,$peiwuInfo);

		$total_peiwu[$k] = $jiaojuanInfo;
	}
	
	return $total_peiwu;
}

function GetPeiwuInfoById($peiwuid)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_peiwu')." where id = $peiwuid");
	if($data = DB::fetch($query))
	{
		return $data;
	}
	
	return $data;
}

function ProcessPeiwu($usr,$sys)
{
	$ret=array();
	
	$right = 1;
	$reply = 0;
	$ret['r'] = 'R';
	
	foreach($usr as $n=>$val)
	{
		if($val != -1){
			$reply = 1;
			break;
		}
	}
	
	for($i=0;$i<7;$i++)
	{
			$num = $i + 1;
			$answer = 'answer'.$num;
			
		if(trim($sys[$answer])!="")
		{
			if($usr[$i] != trim($sys[$answer]))
			{
				$right = 0;
				$ret['r'] = 'W';
				break;
			}
		}
	}
	
	$ret['daan'] = $sys['answer1'].$sys['answer2'].$sys['answer3'].$sys['answer4'].$sys['answer5'].$sys['answer6'].$sys['answer7'];
	$ret['score'] = $sys['score'];
	$ret['parser'] = $sys['answer_parser'];
	$ret['reply'] = $reply ;
	
	return $ret;
}

function GetPeiwuScore($info)
{
	$total = 0;

	foreach($info as $k=>$v)
	{
		if(trim($v['r']) == 'R')
		{
			$total += $v['score'];
		}
	}
	
	return $total;
}

function SetExamStatus_Examed($paperid ,$eid,$uid,$right=0,$wrong=0){

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_userexam_questionstatus')." where uid = $uid and eid = $eid");
	if($data = DB::fetch($query))
	{
		$r_right = $data['right'];
		$r_wrong = $data['wrong'];
		
		if($right > 0) $right = $r_right + $right; 
		if($wrong > 0) $wrong = $r_wrong + $wrong;
		
		DB::update('tpexam_userexam_questionstatus',array('right'=>$right,'wrong'=>$wrong),array('uid'=>$uid,'eid'=>$eid));
	}
	else{
		DB::insert('tpexam_userexam_questionstatus',array('right'=>$right,'wrong'=>$wrong,'paperid'=>$paperid,'uid'=>$uid,'eid'=>$eid,'examed'=>1));
	}
}


function GetQuestionExamStatus($eid,$uid)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_userexam_questionstatus')." where uid = $uid and eid = $eid");
	if($data = DB::fetch($query))
	{
		return 1;
	}
	
	return 0;
}

function GetTikuUnexamCount($paperid,$uid)
{
	$eid1=array();
	$eid2=array();
	
	$query1 = DB::query("SELECT eid FROM ".DB::table('tpexam_tiku')." where paperid = $paperid order by id asc");
	while($data = DB::fetch($query1))
	{
		$eid1[]=$data['eid'];
	}
	
	if(count($eid1)>0) $list = implode(",",$eid1);
	else return 0;
	
	unset($eid2);
	$query2 = DB::query("SELECT eid FROM ".DB::table('tpexam_userexam_questionstatus')." where uid = $uid and eid IN ($list) and examed = 1 order by id asc");
	while($data = DB::fetch($query2))
	{

			$eid = $data['eid'];
			$eid2[]=$eid;

	}
	
	$eid3=array();
	foreach($eid1 as $k=>$v){
		
		if(!in_array($v, $eid2))
			$eid3[]=$v;
	}
	
	return count($eid3);
}

function GetTikuByPaperID_unexam($paperid,$uid)
{
	$eid1=array();
	$eid2=array();
	
	$query1 = DB::query("SELECT eid FROM ".DB::table('tpexam_tiku')." where paperid = $paperid order by id asc");
	while($data = DB::fetch($query1))
	{
		$eid1[]=$data['eid'];
	}
	
	if(count($eid1)>0) $list = implode(",",$eid1);

	unset($eid2);
	if(count($eid1)>0){
		$query2 = DB::query("SELECT eid FROM ".DB::table('tpexam_userexam_questionstatus')." where uid = $uid and eid IN ($list) and examed = 1 order by id asc");
		while($data = DB::fetch($query2))
		{
				$eid = $data['eid'];
				$eid2[]=$eid;
		}
	}

	$eid3=array();
	foreach($eid1 as $k=>$v){
		
		if(!in_array($v, $eid2))
			$eid3[]=$v;
	}
	
	if(count($eid3)>0)
	$t = GetTikuByEidArray($eid3);
	
	
	return $t;

}

function GetTikuByEidArray($eidarr)
{
	$dan_tiku=array();
	$duo_tiku=array();
	$pan_tiku=array();
	$tian_tiku=array();
	$wen_tiku=array();
	
	$eidlist = implode(",",$eidarr);

	$query1 = DB::query("SELECT tid,oid FROM ".DB::table('tpexam_tiku')." where eid IN ($eidlist) order by id asc");
	while($data = DB::fetch($query1))
	{
		if($data['tid']==1){
			$dan_tiku[]=$data['oid'];
		}else if($data['tid']==2){
			$duo_tiku[]=$data['oid'];
		}else if($data['tid']==3){
			$pan_tiku[]=$data['oid'];
		}else if($data['tid']==4){
			$tian_tiku[]=$data['oid'];
		}else if($data['tid']==5){
			$wen_tiku[]=$data['oid'];
		}
	}
	
	return array('dan'=>$dan_tiku,
	'duo'=>$duo_tiku,
	'pan'=>$pan_tiku,
	'tian'=>$tian_tiku,
	'wen'=>$wen_tiku);
}

function UpdateQuestionRecord($tiku,$tid,$uid,$paperid)
{
	$lastquestion=1;
	
	$eid=array();
	$right = $wrong = 0;
	foreach($tiku as $k=>$v){
		$eid[]=$v['id'];
	}

	$teid = GetEidByArray($tid,$eid);

	foreach($teid as $p=>$val)
	{
		if($tiku[$p]['r']=='R'){
			$right = 1;
			$lastquestion=2;
		}
		else{
			$wrong = 1;
			$lastquestion=1;
		}
		
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_userexam_questionstatus')." where eid = $val and uid=$uid limit 0,1");
		
		if($data = DB::fetch($query)){
			if($tiku[$p]['r']=='R'){
					$right = $data['qright'] + 1;
					$wrong = $data['wrong'];
			}else{
				$wrong = $data['wrong'] + 1;
				$right = $data['qright'];
			}
			
			$ratio = $right + $wrong;

			$rightratio = $right / $ratio;
			$wrongratio = ($wrong / $ratio)*10;

			$wrongratio = floor($wrongratio);

			DB::update('tpexam_userexam_questionstatus',array('qright'=>$right,'wrong'=>$wrong,'rightratio'=>$rightratio,'wrongratio'=>$wrongratio,'lastdata'=>TIMESTAMP,'lastquestion'=>$lastquestion),"eid=$val and uid=$uid");
		}else{
			$ratio = $right + $wrong;
			$rightratio = $right / $ratio;
			$wrongratio = ($wrong / $ratio)*10;
			$wrongration = floor($wrongratio);
			DB::insert('tpexam_userexam_questionstatus',array('questiontype'=>$tid,'questionid'=>$tiku[$p]['id'], 'paperid'=>$paperid,'eid'=>$val,'examed'=>1,'uid'=>$uid,'qright'=>$right,'wrong'=>$wrong,'rightratio'=>$rightratio,'wrongratio'=>$wrongratio,'lastdata'=>TIMESTAMP,'lastquestion'=>$lastquestion));
		}
	}

}

function GetEid($tid,$oid)
{
		$query = DB::query("SELECT eid FROM ".DB::table('tpexam_tiku')." where tid = $tid and oid = $oid order by id asc");
		while($data = DB::fetch($query)){
			return $data['eid'];
		}
			
		return 0;
}

function GetEidByArray($tid,$eidarr)
{
		$eidarray=array();
		$len = count($eidarr);
		if(count($eidarr)>0){
			$eidlist = implode(",",$eidarr);

			$query = DB::query("SELECT eid FROM ".DB::table('tpexam_tiku')." where tid = $tid and oid IN ($eidlist) order by id asc");
			while($data = DB::fetch($query)){
				$eidarray[]=$data['eid'];
			}
		}

		return $eidarray;
}

function GetPaperWrongQuestion($uid,$paperid)
{
	//$skey = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_userexam_questionstatus')." where uid = $uid and paperid = $paperid and lastquestion=1 order by id asc");
	
	//�����Ч��
	//$skey = DB::result_first("SELECT * FROM ".DB::table('tpexam_userexam_questionstatus')." where uid = $uid and paperid = $paperid and lastquestion=1 order by id asc");
	$index = 0;
	$query = DB::query("select * from ".DB::table("tpexam_userexam_questionstatus")." where uid = $uid and paperid = $paperid and lastquestion=1 order by id asc");
	while($d = DB::fetch($query)){
		
		$available = GetAvailable($d['questiontype'],$d['questionid']);
		if($available) $index++;
	}
	
	return $index;
}

function GetAvailable($tid,$oid)
{
	$table = GetTable($tid);
	
	$skey = DB::result_first("SELECT id FROM ".DB::table($table)." where id = $oid");
	
	if($skey > 0)
		return 1;
	else
		return 0;
}

function GetTable($tid)
{
	switch($tid)
	{
		case 1:return 'tpexam_tiku_danxuan';break;
		case 2:return 'tpexam_tiku_duoxuan';break;
		case 3:return 'tpexam_tiku_panduan';break;
		case 4:return 'tpexam_tiku_tiankong';break;
		case 5:return 'tpexam_tiku_wenda';break;
	}
}

function GetPaperRightQuestion($uid,$paperid)
{
	$skey = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_userexam_questionstatus')." where uid = $uid and paperid = $paperid and lastquestion=2 order by id asc");
	return $skey;
}

function GetPaperUnexamQuestion($paperid,$uid)
{
	$skey = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_tiku')." where paperid = $paperid order by id asc");
	return $skey;	
}

function GetTikuByPaperID_err($paperid,$uid)
{
	$eidarr=array();

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_userexam_questionstatus')." where uid = $uid and paperid = $paperid and lastquestion=1 order by id asc");
	while($data = DB::fetch($query))
	{
			$questiontype = $data['questiontype'];
			$questionid = $data['questionid'];
			
			$eid = GetEid($questiontype,$questionid);
			if($eid > 0){
				$eidarr[]=$eid;
			}
	}

	if(count($eidarr)>0)
	$t = GetTikuByEidArray($eidarr);
	
	return $t;
}

function GetPassword($item)
{
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id=$item");
		while($data = DB::fetch($query))
		{
			$pass = $data['password'];
		}
		
		return $pass;
}
//From: d'.'is'.'m.tao'.'ba'.'o.com
?>
