<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

	$option = daddslashes($_GET['option']);
	$score = intval($_GET['score']);
	$answer = daddslashes($_GET['answer']);
	$belong_paper = daddslashes($_GET['belong_paper']);
	$question = daddslashes($_GET['question']);
	$viewParserCredits = daddslashes($_GET['viewParserCredits']);
	$answerparser = daddslashes($_GET['answerparser']);
	$yuedulijie_timutype = daddslashes($_GET['yuedulijie_timutype']); //id
	$peiwu_timutype = daddslashes($_GET['peiwu_timutype']);
	$bgroups = intval($_GET['bgroups']);
	

		$post = array(
		'eid'=>0,
		'tid'	 => $timu_type ,
		'oid'	 => 0 ,
		'score'=>$score,
		'groupid'=>$bgroups ,
		'paperid'=>$belong_paper,
		'subject'=> $question,
		'option'=>implode("\r\n",$option),
		'parser'=>$answerparser,
		'result'=>$answer[0],
		'image'=>$imageurl,
		'viewParser_credits'=>$viewParserCredits,
		'addtime'=> TIMESTAMP ,
		'yuedulijie'=>$yuedulijie_timutype,
	);
	
	$insert_eid = DB::insert('tpexam_tiku', $post, true);
	
	
?>