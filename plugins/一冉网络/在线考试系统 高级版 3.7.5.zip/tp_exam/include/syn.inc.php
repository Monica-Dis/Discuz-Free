<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

function editForum($uid,$username,$fid,$currenttime,$title,$content,$ip,$tid,$pid){

	$tid = DB::update('forum_thread',array('fid' => $fid,

											'subject' => $title),"tid=$tid");

	DB::update('forum_post' , array('fid' => $fid,
									'first' => 1,
									'subject' => $title,
									'message' => $content,
									'useip' => $ip,
									'usesig' => 1,
									'position' => 1,
									'htmlon' => 1),"pid=$pid");

}

function postForum($uid,$username,$fid,$currenttime,$title,$content,$ip,$thumb = '',$js=''){

	global $_G;

	$data = array();

	require_once libfile('function/forum');

	$tid = C::t('forum_thread')->insert(array('fid' => $fid,

											'author' => $username,
											'authorid' => $uid,
											'subject' => $title,
											'dateline' => $currenttime,
											'lastpost' => $currenttime,
											'lastposter' => $username,
											'displayorder' => 0, 
											'views' => 1),true);

	if($js!=''){
		$content = $js . $content;
	}
	
	$pid = insertpost(array('pid' => $pid,

									'fid' => $fid,
									'tid' => $tid,
									'first' => 1,
									'author' => $username,
									'authorid' => $uid,
									'subject' => $title,
									'dateline' => $currenttime,
									'message' => $content,
									'useip' => $ip,
									'usesig' => 1,
									'invisible' => 0,
									'position' => 1,
									'htmlon' => 1));

	$lastpost = "$tid\t".$title."\t$currenttime\t$username";
	C::t('forum_forum')->update($fid, array('lastpost' => $lastpost));
	C::t('forum_forum')->update_forum_counter($fid, 1, 1, 1);
	if($_G['cache']['plugin']['tp_exam']['tohome']){
		require_once libfile('function/post');

		$feed = array(

				'icon' => '',
				'title_template' => '',
				'title_data' => array(),
				'body_template' => '',
				'body_data' => array(),
				'title_data'=>array(),
				'images'=>array()

			);

		$feed['icon'] = 'thread';
		$feed['title_template'] = 'feed_thread_title';
		$feed['body_template'] = 'feed_thread_message';
		$feed['body_data'] = array(
			'subject' => "<a href=\"forum.php?mod=viewthread&tid=$tid\">$title</a>",
			'message' => messagecutstr($content, 150)
		);

		if($thumb != ''){
			$feed['images'] = array($thumb);
			$feed['image_links'] = array("forum.php?mod=viewthread&do=tradeinfo&tid=$tid&pid=$pid");
		}
		$feed['title_data']['hash_data'] = "tid{$tid}";
		$feed['id'] = $tid;
		$feed['idtype'] = 'tid';
		if($feed['icon']) {

			postfeed($feed);

		}

	}

	return array('tid' => $tid, 'pid' => $pid);
}

function GetForum()
{
	$forum_arr=array();
	$query = DB::query("select * from ".DB::table('forum_forum')." where type = 'forum' and status = 1");
	while($data = DB::fetch($query))
	{
		$forum['name']=$data['name'];
		$forum['threads']=$data['threads'];
		$forum['fid']=$data['fid'];
		$forum_arr[]=$forum;
	}
	
	return $forum_arr;
}

function GetSynFid(){
	
	$sql = DB::query("SELECT * FROM ".DB::table('tpexam_setting')." where skey='syn_bbs'");
	while($info = DB::fetch($sql))
	{
		$svalue = $info['svalue'];
	}
	return $svalue;
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>