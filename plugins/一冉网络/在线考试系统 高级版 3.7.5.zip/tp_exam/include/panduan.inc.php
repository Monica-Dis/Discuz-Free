<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}
	$option = daddslashes($_GET['option']);
	$score = daddslashes($_GET['score']);
	$answer = daddslashes($_GET['answer']);
	$belong_paper = daddslashes($_GET['belong_paper']);
	$question = daddslashes($_GET['question']);
	$viewParserCredits = daddslashes($_GET['viewParserCredits']);
	$answerparser = daddslashes($_GET['answerparser']);
	$yuedulijie_timutype = daddslashes($_GET['yuedulijie_timutype']); //id
	$bgroups = intval($_GET['bgroups']);
	
	$insert = DB::insert('tpexam_tiku_panduan',array(
	'ask' => $question,
	'answer'=> $answer[0],
	'score'=>$score,
	'belong_paper'=>$belong_paper,
	'viewParser_credits'=>$viewParserCredits,
	'answer_parser'=>$answerparser,
	'yuedulijie_timutype'=>$yuedulijie_timutype,
	'image'=>$imageurl,
	'audio'=>$audiourl,
	'video'=>$videourl,
	'data'=>time(),
	'publish_uid'=>$_G['uid'],
	'parser_img_path'=>$parser_imageurl),1);
	
	//$oid = mysql_insert_id();
//	$skey = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_tiku'));
	//$eid = $skey + 1;
	
	/*
	DB::insert('tpexam_tiku', array('eid'=>$eid,'tid'=>3,'oid'=>$oid,'paperid'=>$belong_paper));
	*/
		$post = array(
	'eid'=>0,
	'tid'	 => 3,
	'oid'	 => $insert ,
	'groupid'=>$bgroups,
	'paperid'=>$belong_paper,
	'subject'=> $question,
	'option'=>'',
	'parser'=>$answerparser,
	'result'=>$answer,
	'image'=>$imageurl,
	'viewParser_credits'=>$viewParserCredits,
	'addtime'=> TIMESTAMP ,
	'score'=>$score,
	'yuedulijie'=>$yuedulijie_timutype,
	);
	
	$insert_eid = DB::insert('tpexam_tiku', $post, true);
	
	//$eid = mysql_insert_id();
	DB::update('tpexam_tiku_panduan', array('eid'=>$insert_eid),"id IN ($insert)");
?>