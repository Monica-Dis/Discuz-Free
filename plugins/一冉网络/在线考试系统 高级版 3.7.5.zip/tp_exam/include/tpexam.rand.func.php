<?php

 /*
 ���߿���ϵͳ  tp_exam
 */
 
if(!defined('IN_DISCUZ') ) {
	exit('Access Denied');
}


function GetDaXuanByRand($item,$num)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belong_paper = $item  order by rand() limit 0,$num");
	
	
	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����
		$data['option1']=str_replace("\'","'",$data['option1']);//����
		$data['option2']=str_replace("\'","'",$data['option2']);//����
		$data['option3']=str_replace("\'","'",$data['option3']);//����
		$data['option4']=str_replace("\'","'",$data['option4']);//����
		$data['option5']=str_replace("\'","'",$data['option5']);//����
		
		require_once libfile ( 'function/discuzcode' );
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		
		 $tiku[] = $data;
	}
	
	return $tiku;
}

function GetDuoXuanByRand($item,$num)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where belong_paper = $item  order by rand() limit 0,$num");
	
	
	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����
		$data['option1']=str_replace("\'","'",$data['option1']);//����
		$data['option2']=str_replace("\'","'",$data['option2']);//����
		$data['option3']=str_replace("\'","'",$data['option3']);//����
		$data['option4']=str_replace("\'","'",$data['option4']);//����
		$data['option5']=str_replace("\'","'",$data['option5']);//����
		
		require_once libfile ( 'function/discuzcode' );
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		
		$tiku[] = $data;
	}
	
	return $tiku;	
}

function GetPanduanByRand($item,$num)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where belong_paper = $item  order by rand() limit 0,$num");
	
	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����
		
		$tiku[] = $data;
	}

	return $tiku;	
}

function GetTiankongByRand($item,$num)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where belong_paper = $item  order by rand() limit 0,$num");
	
	while($data = DB::fetch($query))
	{
		$tiku[] = $data;
	}

	return $tiku;	
}

function GetWendaByRand($item,$num)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." where belong_paper = $item  order by rand() limit 0,$num");
	
	while($data = DB::fetch($query))
	{
		$data['ask']=str_replace("\'","'",$data['ask']);//����
		
		$tiku[] = $data;
	}

	return $tiku;	
}

function GetRandMode($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id = $item");
	
	while($data = DB::fetch($query))
	{
		return $data['rand'];
	}
	
	return 0;
}

/*
$total = �ܺ�
$min_num = ���飬ÿ�������
$max_num = ���飬ÿ�������
$times = ������Ҳ����Ҫ���ٸ�
*/
function GetRandomByTotal($min_num,$max_num,$total=100,$times=5){
	
// ��������
 
$average=$total/$times;
$now=0;

$total_ti = $max_num[0]+$max_num[1]+$max_num[2];

if($total_ti < $total) return $max_num;

for($i=0;$i<$times;$i++)
{
    $off=0;
    $tmp=0;
    if($i==$times-1)
    {
        $tmp=$total-$now;
        if($tmp>$max_num[$i]||$tmp<0)
        {
            $off=$now=0;
            $i=0;
            // echo "$tmp|";// ������Ҫ�������
            unset($num);
            $tmp=rand($min_num[$i],$max_num[$i]);
            $off=$tmp-$average;
            $now=$now+$tmp;
            $num[]=$tmp;
            continue;
        }
        else
        {
            $num[]=$tmp;
            break;
        }
    }
 
    if($off==0)
    {
        $tmp=rand($min_num[$i],$max_num[$i]);
    }
    else
    {
        $tmp=rand($min_num[$i]-$off,$max_num[$i]-$off);
        $tmp=($tmp+$off);
    }
    $off=$tmp-$average;
    $now=$now+$tmp;
    $num[]=$tmp;
}

// ����
$con='';

foreach($num as $val)
{
    $total_my=$total_my+$val;
    //echo $con."$val";
    $con="+";
}

//echo '='.$total_my;	
return $num;
}

function GetDanxuanCount($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belong_paper = $item  order by id asc");
	
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return count($tiku);	
}

function GetDuoxuanCount($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where belong_paper = $item  order by id asc");
	
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return count($tiku);	
}

function GetPanduanCount($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where belong_paper = $item  order by id asc");
	
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return count($tiku);	
}

function GetTiankongCount($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where belong_paper = $item  order by id asc");
	
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return count($tiku);	
}

function GetWendaCount($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." where belong_paper = $item  order by id asc");
	
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return count($tiku);	
}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>