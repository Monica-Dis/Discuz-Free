<?php

function GetAnswerByPaperID_DanXuan_m($item,$usrAnswer)
{
	$tiku=array();
	$ret=array();
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belong_paper = $item");
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
		 
		 $singleDaan['daan'] = $data['answer'];
		 if($usrAnswer[$data['id']] == $data['answer'])
		 {
		 	$singleDaan['r']='R';
		 }
		 else
		 {
		 	$singleDaan['r']='W';
		 }
		 
		 $singleDaan['id'] = $data['id'];
		 $ret[] = $singleDaan;
	}

	
	return $ret;
}

function GetAnswerByPaperID_DuoXuan_m($item,$usrAnswer)
{
	$tiku=array();
	$ret=array();
	
	foreach($usrAnswer as $k=>$v)
	{
		$duoxuan_answer_arr = explode("|",$v);
		$user_answer_a = '';
		foreach($duoxuan_answer_arr as $n=>$val)
		{
			if($val =='A' || $val =='B' ||$val =='C' ||$val =='D' ||$val =='E' )
			$user_answer_a .= $val;
		}
		
		$duoxuan_arr[]=$user_answer_a;
	}
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where belong_paper = $item");
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
		 //��ϴ�
		 
		 $duoxuan_a = $data['answer1'].$data['answer2'].$data['answer3'].$data['answer4'].$data['answer5'];
		 
		 if($duoxuan_arr[$data['id']] == $duoxuan_a)
		 {
		 	$singleDaan['r']='R';
		 }
		 else
		 {
		 	$singleDaan['r']='W';
		 }
		 
		 $singleDaan['id'] = $data['id'];
		 $singleDaan['daan'] = $duoxuan_a;
		 $ret[] = $singleDaan;
	}

	
	return $ret;	
}

function GetAnswerByPaperID_Panduan_m($item,$usrAnswer)
{
	$tiku=array();
	$ret=array();
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where belong_paper = $item");
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
		 
		 $singleDaan['daan'] = $data['answer'];


		 		if($usrAnswer[$data['id']]==$data['answer'])
		 		{
			 		$singleDaan['r']='R';
			 	}
			 	else
		 		{
		 			$singleDaan['r']='W';
		 		}
		 	

		 	
		 	$singleDaan['id'] = $data['id'];
		 	$ret[] = $singleDaan;
		 
	}

	
	return $ret;	
}

/*
1����ȷ�𰸲��ɶ�����򰴴�����
2��
*/
function tiankong_checkright($usranswer,$answer,$id)
{
/*	echo '<br>-------------<br>';
	print_r($usranswer);
	echo '<br>';
	print_r($answer);
	echo 'id='.$id;
	echo '<br>-------------<br>';
	*/

	foreach($answer as $k=>$v)
	{

		if(trim($v) != $usranswer[$id][$k])
		{
			return false;
		}
	}

	return true;
}

function GetAnswerByPaperID_Tiankong_m($item,$usrAnswer)
{
	$tiku=array();
	$ret=array();
	

	foreach($usrAnswer as $k=>$v)
	{
		$tiankong_answer_arr = explode("|",$v);
		$tiankong_arr[]=$tiankong_answer_arr;
	}
	

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where belong_paper = $item");
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
		 
		 $singleDaan['daan'] = $data['answer'];
				
			$answer_arr = explode("\n",$data['answer']);
			
		 	if(tiankong_checkright($tiankong_arr,$answer_arr,$data['id']))
		 	{
				$singleDaan['r']='R';
			}
				else
		 	{
		 		$singleDaan['r']='W';
		 	}
		 	
		 	$singleDaan['id'] = $data['id'];
		 	$ret[] = $singleDaan;
		 
	}

	
	return $ret;	
}


function GetSingleScorebyId_danxuan_m($item)
{
	$score = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where id = $item");
	if($data = DB::fetch($query))
	{
		$score  = $data;
	}
	
	return $score;
}

function GetScore_DanXuan_m($answer)
{
	$danxuan_score = 0;
	
	foreach($answer as $k=>$v)
	{
		if($v['r'] == 'R')
		{
			$single_score = GetSingleScorebyId_danxuan_m($v['id']);
			$danxuan_score = $danxuan_score + $single_score['score'];
		}
	}
	
	return $danxuan_score;
	
}

function GetSingleScorebyId_duoxuan_m($item)
{
	$score = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where id = $item");
	if($data = DB::fetch($query))
	{
		$score  = $data;
	}
	
	return $score;
}

function GetScore_DuoXuan_m($answer)
{
	$total_duoxuan_score = 0;
	
	foreach($answer as $k=>$v)
	{
		
		if($v['r'] == 'R')
		{
			
			$single_score = GetSingleScorebyId_duoxuan_m($v['id']);

			$total_duoxuan_score = $total_duoxuan_score + $single_score['score'];
		}
	}
	

	return $total_duoxuan_score;
}

function GetSingleScorebyId_panduan_m($item)
{
	$score = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where id = $item");
	if($data = DB::fetch($query))
	{
		$score  = $data;
	}
	
	return $score;
}

function GetScore_Panduan_m($answer)
{
	$total_panduan_score = 0;
	
	foreach($answer as $k=>$v)
	{
		
		if($v['r'] == 'R')
		{
			
			$single_score = GetSingleScorebyId_panduan_m($v['id']);

			$total_panduan_score = $total_panduan_score + $single_score['score'];
		}
	}
	

	return $total_panduan_score;	
}

function GetTiankongAsk_m($tiankong)
{
	foreach($tiankong as $n=>$v)
	{
		$ask = $tiankong[$n]['ask'];
		
		$id = $tiankong[$n]['id'];
		
		$replace_time = 0;
		$line = preg_replace("/#([0-9]+)/","<input style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\" value=\"\" size=\\1 onclick=\"javascript:this.focus();\" onkeyup=\"selectinput_tiankong(this,3,$id,$replace_time);\" name=\"t_answer[".$tiankong[$n]['id']."][$replace_time]\">",$ask,1,$replaced);
		while($replaced>0)
		{
			$replace_time++;
			$line = preg_replace("/#([0-9]+)/","<input style=\"border:1px;border-bottom-style:solid;border-top-style:none;border-left-style:none;border-right-style:none;\" type=\"text\" class=\"txt\" value=\"\" size=\\1 onclick=\"javascript:this.focus();\" onkeyup=\"selectinput_tiankong(this,3,$id,$replace_time);\" name=\"t_answer[".$tiankong[$n]['id']."][$replace_time]\">",$line,1,$replaced);	
			
		}
		$result[] = $line;
	}
	//print_r($result);
	return $result;
}

function GetSingleScorebyId_tiankong_m($item)
{
	$score = array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where id = $item");
	if($data = DB::fetch($query))
	{
		$score  = $data;
	}
	
	return $score;
}

function GetScore_Tiankong_m($answer)
{
	$total_tiankong_score = 0;
	
	foreach($answer as $k=>$v)
	{
		
		if($v['r'] == 'R')
		{
			
			$single_score = GetSingleScorebyId_tiankong_m($v['id']);

			$total_tiankong_score = $total_tiankong_score + $single_score['score'];
		}
	}
	

	return $total_tiankong_score;		
}

function GetNeedCredits($needitem)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id= $needitem");
	
	if($data = DB::fetch($query))
	{
		return array($data['needcredit'],$data['buycredits']);
	}
	
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>