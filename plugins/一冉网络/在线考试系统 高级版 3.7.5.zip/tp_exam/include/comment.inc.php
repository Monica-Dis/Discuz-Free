<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include 'page.class.php';

$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_permission')." where skey='comment_question_p'");
$comment_question_p = $skey['comment_question_p'];

$skey = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='comment_question'");
$comment_question = $skey['comment_question'];
	
if($comment_question_p && $comment_question){

	$danxuan_count = GetDanxuanCommentCountByIdArray($id_arr_danxuan);
	$danxuan_multi = GetDanxuanPageMulti($id_arr_danxuan,$danxuan_count);
	$danxuan_comment = GetDanxuanCommentByIdArray($id_arr_danxuan);

	$duoxuan_count = GetDuoxuanCommentCountByIdArray($id_arr_duoxuan);
	$duoxuan_multi = GetDuoxuanPageMulti($id_arr_duoxuan,$duoxuan_count);
	$duoxuan_comment = GetDuoxuanCommentByIdArray($id_arr_duoxuan);


	$panduan_count = GetPanduanCommentCountByIdArray($id_arr_panduan);
	$panduan_multi = GetPanduanPageMulti($id_arr_panduan,$panduan_count);
	$panduan_comment = GetPanduanCommentByIdArray($id_arr_panduan);

	$tiankong_count = GetTiankongCommentCountByIdArray($id_arr_duoxuan);
	$tiankong_multi = GetTiankongPageMulti($id_arr_tiankong,$tiankong_count);
	$tiankong_comment = GetTiankongCommentByIdArray($id_arr_tiankong);

	$wenda_count = GetWendaCommentCountByIdArray($id_arr_wenda);
	$wenda_multi = GetWendaPageMulti($id_arr_wenda,$wenda_count);
	$wenda_comment = GetWendaCommentByIdArray($id_arr_wenda);

}else{
	$comment_question=0;

}

function GetCommentById($dantype,$danid,$start,$end){
	$comment=array();
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_comment')." where question_type = $dantype and question_id = $danid  order by id desc limit $start,$end");
	while($data = DB::fetch($query))
	{
		$user = getuserbyuid($data['uid']);
		$data['username'] = $user['username'];
		$comment[] = $data;
	}
	return $comment;
}

function GetDanxuanCommentByIdArray($id_arr_danxuan){
	$comm_arr=array();
	foreach($id_arr_danxuan as $k=>$value){
		$dancomment = GetCommentById(1,$value,0,3);
		$comm_arr[$value]=$dancomment;
	}
	
	return $comm_arr;
}

function GetDuoxuanCommentByIdArray($id_arr_duoxuan){
	$comm_arr=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$duocomment = GetCommentById(2,$value,0,3);
		$comm_arr[$value]=$duocomment;
	}

	return $comm_arr;
}

function GetPanduanCommentByIdArray($id_arr_duoxuan){
	$comm_arr=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$duocomment = GetCommentById(3,$value,0,3);
		$comm_arr[$value]=$duocomment;
	}
	
	return $comm_arr;
}

function GetTiankongCommentByIdArray($id_arr_duoxuan){
	$comm_arr=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$duocomment = GetCommentById(4,$value,0,3);
		$comm_arr[$value]=$duocomment;
	}
	
	return $comm_arr;
}

function GetWendaCommentByIdArray($id_arr_duoxuan){
	$comm_arr=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$duocomment = GetCommentById(5,$value,0,3);
		$comm_arr[$value]=$duocomment;
	}
	
	return $comm_arr;
}

function GetCommentCount($commid,$type){
	$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_tiku_comment')." WHERE question_type = $type and question_id = $commid");
	return $totalnum;
}

function GetDanxuanCommentCountByIdArray($id_arr_danxuan){
	$count_comm=array();
	foreach($id_arr_danxuan as $k=>$value){
		$count = GetCommentCount($value,1);
		$count_comm[]=$count;
	}	
	return $count_comm;
}

function GetDuoxuanCommentCountByIdArray($id_arr_duoxuan){
	$count_comm=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$count = GetCommentCount($value,2);
		$count_comm[]=$count;
	}	
	return $count_comm;
}

function GetPanduanCommentCountByIdArray($id_arr_duoxuan){
	$count_comm=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$count = GetCommentCount($value,3);
		$count_comm[]=$count;
	}	
	return $count_comm;
}

function GetTiankongCommentCountByIdArray($id_arr_duoxuan){
	$count_comm=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$count = GetCommentCount($value,4);
		$count_comm[]=$count;
	}	
	return $count_comm;
}

function GetWendaCommentCountByIdArray($id_arr_duoxuan){
	$count_comm=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$count = GetCommentCount($value,5);
		$count_comm[]=$count;
	}	
	return $count_comm;
}

function GetDanxuanPageMulti($id_arr_danxuan,$dan_count_list){
	$multi_array=array();
	foreach($id_arr_danxuan as $k=>$value){
		$totalnum = $dan_count_list[$k];
		$perpage = 3;
		$page = 1;
		$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0;
		
		$exam_up_page = lang('plugin/tp_exam', 'exam_up_page');
		$exam_down_page = lang('plugin/tp_exam', 'exam_down_page');
		
		$page = new Page($totalnum,$perpage,10,'p1',$totalnum);
		$page->pageType = '%up%<span class="number">%numberD%</span>%down%';
		$page->pageShow = array('up'=>'< '.$exam_up_page,'down'=>$exam_down_page.' >');
		$page->pageSetJsFun();
		$page->pageSetParam(1,1);
		$p1 = $page->pageShow();
	
		$multi = $p1;

		$pos = strpos($multi,"2");

		if(!$pos) $multi = '';
		
		$multi_array[$value] = $multi;
	}
	return $multi_array;
}

function GetduoxuanPageMulti($id_arr_duoxuan,$duo_count_list){
	$multi_array=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$totalnum = $duo_count_list[$k];
		$perpage = 3;
		$page = 1;
		$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0;
		
		$exam_up_page = lang('plugin/tp_exam', 'exam_up_page');
		$exam_down_page = lang('plugin/tp_exam', 'exam_down_page');
		
		$page = new Page($totalnum,$perpage,10,'p1',$totalnum);
		$page->pageType = '%up%<span class="number">%numberD%</span>%down%';
		$page->pageShow = array('up'=>'< '.$exam_up_page,'down'=>$exam_down_page.' >');
		$page->pageSetJsFun();
		$page->pageSetParam(2,1);
		$p1 = $page->pageShow();
	
		$multi = $p1;

		$pos = strpos($multi,"2");
		if(!$pos) $multi = '';
		
		$multi_array[$value] = $multi;
	}
	return $multi_array;
}

function GetPanduanPageMulti($id_arr_duoxuan,$duo_count_list){
	$multi_array=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$totalnum = $duo_count_list[$k];
		$perpage = 3;
		$page = 1;
		$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0;
		
		$exam_up_page = lang('plugin/tp_exam', 'exam_up_page');
		$exam_down_page = lang('plugin/tp_exam', 'exam_down_page');
		
		$page = new Page($totalnum,$perpage,10,'p1',$totalnum);
		$page->pageType = '%up%<span class="number">%numberD%</span>%down%';
		$page->pageShow = array('up'=>'< '.$exam_up_page,'down'=>$exam_down_page.' >');
		$page->pageSetJsFun();
		$page->pageSetParam(3,1);
		$p1 = $page->pageShow();
	
		$multi = $p1;

		$pos = strpos($multi,"2");
		if(!$pos) $multi = '';
		
		$multi_array[$value] = $multi;
	}
	return $multi_array;
}

function GetTiankongPageMulti($id_arr_duoxuan,$duo_count_list){
	$multi_array=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$totalnum = $duo_count_list[$k];
		$perpage = 3;
		$page = 1;
		$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0;
		
		$exam_up_page = lang('plugin/tp_exam', 'exam_up_page');
		$exam_down_page = lang('plugin/tp_exam', 'exam_down_page');
		
		$page = new Page($totalnum,$perpage,10,'p1',$totalnum);
		$page->pageType = '%up%<span class="number">%numberD%</span>%down%';
		$page->pageShow = array('up'=>'< '.$exam_up_page,'down'=>$exam_down_page.' >');
		$page->pageSetJsFun();
		$page->pageSetParam(4,1);
		$p1 = $page->pageShow();
	
		$multi = $p1;

		$pos = strpos($multi,"2");
		if(!$pos) $multi = '';
		
		$multi_array[$value] = $multi;
	}
	return $multi_array;
}

function GetWendaPageMulti($id_arr_duoxuan,$duo_count_list){
	$multi_array=array();
	foreach($id_arr_duoxuan as $k=>$value){
		$totalnum = $duo_count_list[$k];
		$perpage = 3;
		$page = 1;
		$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0;
		
		$exam_up_page = lang('plugin/tp_exam', 'exam_up_page');
		$exam_down_page = lang('plugin/tp_exam', 'exam_down_page');
		
		$page = new Page($totalnum,$perpage,10,'p1',$totalnum);
		$page->pageType = '%up%<span class="number">%numberD%</span>%down%';
		$page->pageShow = array('up'=>'< '.$exam_up_page,'down'=>$exam_down_page.' >');
		$page->pageSetJsFun();
		$page->pageSetParam(5,1);
		$p1 = $page->pageShow();
	
		$multi = $p1;

		$pos = strpos($multi,"2");
		if(!$pos) $multi = '';
		
		$multi_array[$value] = $multi;
	}
	return $multi_array;
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>