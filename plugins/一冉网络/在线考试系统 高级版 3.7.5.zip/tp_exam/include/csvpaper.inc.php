<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$ATests=array();

function ProcessLine($utf8,$type,$id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername)
{

	switch($type){
		case 'ATests':
			ATests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8);
		break;
		case 'BTests':
			BTests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8);
		break;
		case 'XTests':
			XTests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8);
		break;
		case 'JDTests':
			JDTests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8);
		break;
		case 'A3Tests':
			A3Tests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer1,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8);
		break;
		case 'PDTests':
			PDTests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8);
		break;
	}
}

function ATests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8){
	global $ATests;
	
	if($utf8){
		$tree0 = iconv("gb2312","utf-8",$tree0);
		$tree1 = iconv("gb2312","utf-8",$tree1);	
		$tree2 = iconv("gb2312","utf-8",$tree2);	
		$papername = iconv("gb2312","utf-8",$papername);	
		$small_ask = iconv("gb2312","utf-8",$small_ask);	
		$option1 = iconv("gb2312","utf-8",$option1);	
		$option2 = iconv("gb2312","utf-8",$option2);	
		$option3 = iconv("gb2312","utf-8",$option3);	
		$option4 = iconv("gb2312","utf-8",$option4);	
		$option5 = iconv("gb2312","utf-8",$option5);	
		$answer = iconv("gb2312","utf-8",$answer);	
	}
	
	//�������
	if($tree0!=""){
		$treeid0 = InsertTree($tree0,0);
	}
	if($tree1!=""){
		$treeid1 = InsertSubTree($tree1,$treeid0);
	}
	if($tree2!=""){
		$treeid2 = InsertSubTree($tree2,$treeid1);
	}
	//�����Ծ�
	if($tree2!=""){
		$paperid = InsertPaper($treeid2,$papername);
	}
	else
	if($tree2=="" && $tree1 != "")
	{
		$paperid = InsertPaper($treeid1,$papername);
	}
	else
		$paperid = InsertPaper($treeid0,$papername);
	
	//���뵱ǰ����
	DB::insert('tpexam_tiku_danxuan', array(
	'ask' => $small_ask,
	'option1' => $option1,
	'option2' => $option2,
	'option3' => $option3,
	'option4'=> $option4,
	'option5'=> $option5,
	'option6'=> '',
	'option7'=> '',	
	'answer'=> $answer,
	'score'=>'2',
	'data'=>time(),
	'publish_uid'=>$_G['uid'],
	'belong_paper'=>$paperid,
	'viewParser_credits'=>0,
	'answer_parser'=>$parser,
	'yuedulijie_timutype'=>0,
	'image'=>'',
	'audio'=>'',
	'video'=>'',
	'parser_img_path'=>''));
	
	$myid = mysql_insert_id();
	$AT['id']=$myid;
	$AT['child_id']=$child_id;
	
	$ATests[]= $AT;
}

function XTests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8){
	
	if($utf8){
		$tree0 = iconv("gb2312","utf-8",$tree0);
		$tree1 = iconv("gb2312","utf-8",$tree1);	
		$tree2 = iconv("gb2312","utf-8",$tree2);	
		$papername = iconv("gb2312","utf-8",$papername);	
		$small_ask = iconv("gb2312","utf-8",$small_ask);	
		$option1 = iconv("gb2312","utf-8",$option1);	
		$option2 = iconv("gb2312","utf-8",$option2);	
		$option3 = iconv("gb2312","utf-8",$option3);	
		$option4 = iconv("gb2312","utf-8",$option4);	
		$option5 = iconv("gb2312","utf-8",$option5);	
		$answer = iconv("gb2312","utf-8",$answer);	
	}
	
	//�������
	if($tree0!=""){
		$treeid0 = InsertTree($tree0,0);
	}
	if($tree1!=""){
		$treeid1 = InsertSubTree($tree1,$treeid0);
	}
	if($tree2!=""){
		$treeid2 = InsertSubTree($tree2,$treeid1);
	}
	//�����Ծ�
	if($tree2!=""){
		$paperid = InsertPaper($treeid2,$papername);
	}
	else
	if($tree2=="" && $tree1 != "")
	{
		$paperid = InsertPaper($treeid1,$papername);
	}
	else
		$paperid = InsertPaper($treeid0,$papername);
	
	//���������
	$answer_arr=array();
	for($i=0;$i<strlen($answer);$i++){
		$char = substr($answer,$i,1);
		$answer_arr[]=$char;
	}
	
		DB::insert('tpexam_tiku_duoxuan',array(
	'ask' => $small_ask,
	'option1' => $option1,
	'option2' => $option2,
	'option3' => $option3,
	'option4'=> $option4,
	'option5'=> $option5,
	'option6'=> '',
	'option7'=> '',
	'answer1'=> $answer_arr[0],
	'answer2'=> $answer_arr[1],
	'answer3'=> $answer_arr[2],
	'answer4'=> $answer_arr[3],
	'answer5'=> $answer_arr[4],
	'answer6'=> '',
	'answer7'=> '',
	'score'=>2,
	'belong_paper'=>$paperid	,
	'viewParser_credits'=>0,
	'answer_parser'=>$parser,
	'image'=>'',
	'audio'=>'',
	'video'=>'',
	'parser_img_path'=>''));
	
		
}

function PDTests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8){
	if($utf8){
		$tree0 = iconv("gb2312","utf-8",$tree0);
		$tree1 = iconv("gb2312","utf-8",$tree1);	
		$tree2 = iconv("gb2312","utf-8",$tree2);	
		$papername = iconv("gb2312","utf-8",$papername);	
		$small_ask = iconv("gb2312","utf-8",$small_ask);	
		$option1 = iconv("gb2312","utf-8",$option1);	
		$option2 = iconv("gb2312","utf-8",$option2);	
		$option3 = iconv("gb2312","utf-8",$option3);	
		$option4 = iconv("gb2312","utf-8",$option4);	
		$option5 = iconv("gb2312","utf-8",$option5);	
		$answer = iconv("gb2312","utf-8",$answer);	
	}
	
	//�������
	if($tree0!=""){
		$treeid0 = InsertTree($tree0,0);
	}
	if($tree1!=""){
		$treeid1 = InsertSubTree($tree1,$treeid0);
	}
	if($tree2!=""){
		$treeid2 = InsertSubTree($tree2,$treeid1);
	}
	//�����Ծ�
	if($tree2!=""){
		$paperid = InsertPaper($treeid2,$papername);
	}
	else
	if($tree2=="" && $tree1 != "")
	{
		$paperid = InsertPaper($treeid1,$papername);
	}
	else
		$paperid = InsertPaper($treeid0,$papername);

	DB::insert('tpexam_tiku_panduan',array(
	'ask' => $small_ask,
	'answer'=> $answer,
	'score'=>2,
	'belong_paper'=>$paperid,
	'viewParser_credits'=>0,
	'answer_parser'=>$parser,
	'image'=>'',
	'audio'=>'',
	'video'=>'',
	'parser_img_path'=>''));
}

function JDTests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8){

	if($utf8){
		$tree0 = iconv("gb2312","utf-8",$tree0);
		$tree1 = iconv("gb2312","utf-8",$tree1);	
		$tree2 = iconv("gb2312","utf-8",$tree2);	
		$papername = iconv("gb2312","utf-8",$papername);	
		$small_ask = iconv("gb2312","utf-8",$small_ask);	
		$option1 = iconv("gb2312","utf-8",$option1);	
		$option2 = iconv("gb2312","utf-8",$option2);	
		$option3 = iconv("gb2312","utf-8",$option3);	
		$option4 = iconv("gb2312","utf-8",$option4);	
		$option5 = iconv("gb2312","utf-8",$option5);	
		$answer = iconv("gb2312","utf-8",$answer);	
	}
	
	//�������
	if($tree0!=""){
		$treeid0 = InsertTree($tree0,0);
	}
	if($tree1!=""){
		$treeid1 = InsertSubTree($tree1,$treeid0);
	}
	if($tree2!=""){
		$treeid2 = InsertSubTree($tree2,$treeid1);
	}
	//�����Ծ�
	if($tree2!=""){
		$paperid = InsertPaper($treeid2,$papername);
	}
	else
	if($tree2=="" && $tree1 != "")
	{
		$paperid = InsertPaper($treeid1,$papername);
	}
	else
		$paperid = InsertPaper($treeid0,$papername);
		
	 DB::insert('tpexam_tiku_wenda',array(
	'ask' => $small_ask,
	'answer'=> $answer,
	'score'=>2,
	'belong_paper'=>$paperid,
	'viewParser_credits'=>0,
	'answer_parser'=>$parser,
	'image'=>'',
	'audio'=>'',
	'video'=>'',
	'parser_img_path'=>''));
	
}

function A3Tests($id,$child_id,$main_ask,$small_ask,$option1,$option2,$option3,$option4,$option5,$answer1,$answer,$parser,$tree0,$tree1,$tree2,$papername,$utf8){
	
		if($utf8){
		$main_ask = iconv("gb2312","utf-8",$main_ask);	
	}
	
	$ret = TypeAndPaper($tree0,$tree1,$tree2,$papername,$utf8);
	$paperid = $ret[3];
	
	DB::insert('tpexam_tiku_yuedulijie',array(
	'ask' => $main_ask,
	'score'=>2 ,
	'belong_paper'=> $paperid,
	'nickname'=> 'batch'));
	
	$myid = mysql_insert_id();
	
	ProcessChild($id,$myid);
}

function ProcessChild($id,$myid)
{
	global $ATests;

	//�������
	foreach($ATests as $k=>$value){
		$child_danxuan .= $value['id'];
		$child_danxuan .= "|";
	}
	
	$child_danxuan = substr($child_danxuan,0,strlen($child_danxuan)-1);

	DB::update('tpexam_tiku_yuedulijie',array(
				'child_danxuan' => $child_danxuan),'id='.$myid);
				
	foreach($ATests as $k=>$value){
		if(trim($value['child_id']) == trim($id)){
				DB::update('tpexam_tiku_danxuan',array(
				'yuedulijie_timutype' => $myid),'id='.$value[id]);
		}
	}
}

function TypeAndPaper($tree0,$tree1,$tree2,$papername,$utf8)
{
		if($utf8){
		$tree0 = iconv("gb2312","utf-8",$tree0);
		$tree1 = iconv("gb2312","utf-8",$tree1);	
		$tree2 = iconv("gb2312","utf-8",$tree2);	
		$papername = iconv("gb2312","utf-8",$papername);	
		$small_ask = iconv("gb2312","utf-8",$small_ask);	
		$option1 = iconv("gb2312","utf-8",$option1);	
		$option2 = iconv("gb2312","utf-8",$option2);	
		$option3 = iconv("gb2312","utf-8",$option3);	
		$option4 = iconv("gb2312","utf-8",$option4);	
		$option5 = iconv("gb2312","utf-8",$option5);	
		$answer = iconv("gb2312","utf-8",$answer);	
	}
	
	//�������
	if($tree0!=""){
		$treeid0 = InsertTree($tree0,0);
	}
	if($tree1!=""){
		$treeid1 = InsertSubTree($tree1,$treeid0);
	}
	if($tree2!=""){
		$treeid2 = InsertSubTree($tree2,$treeid1);
	}
	//�����Ծ�
	if($tree2!=""){
		$paperid = InsertPaper($treeid2,$papername);
	}
	else
	if($tree2=="" && $tree1 != "")
	{
		$paperid = InsertPaper($treeid1,$papername);
	}
	else
		$paperid = InsertPaper($treeid0,$papername);
		
	return array($treeid0,$treeid1,$treeid2,$paperid);
}

function InsertTree($tree0,$level=0)
{
	$treeid = InsertTree0($tree0);
	return $treeid;
}

function InsertTree0($tree)
{
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_type'));
		while($data = DB::fetch($query))
		{
			if($data['name'] == trim($tree))
			{
				return $data['id'];
			}
		}
	
		$inserts[] = "('','0', '$tree','batch',0)";
		DB::query("INSERT INTO ".DB::table('tpexam_type')." (id , parent, name, shorturl , total  ) VALUES ".implode(',',$inserts));
		
		$myid = mysql_insert_id();
		
		return $myid;
}

function InsertSubTree($tree,$treeid){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_type'));
		while($data = DB::fetch($query))
		{
			if($data['name'] == trim($tree))
			{
				return $data['id'];
			}
		}
		
		$inserts[] = "('','$treeid', '$tree','batch',0)";
		DB::query("INSERT INTO ".DB::table('tpexam_type')." (id , parent, name, shorturl , total  ) VALUES ".implode(',',$inserts));
		
		$myid = mysql_insert_id();
		
		return $myid;	
}

function InsertPaper($treeid,$papername){

		$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper'));
		while($data = DB::fetch($query))
		{	
			if(trim($data['name']) == trim($papername))
			{
				return $data['id'];
			}
		}
		
	$inserts[] = "('', '$treeid','$papername','batch','90','0','1','0','0','0','0')";
	DB::query("INSERT INTO ".DB::table('tpexam_paper')." (id , belong,name, shorturl ,papertime,needlogin,practise,rand,showanswer,paperinfo,tid ) VALUES ".implode(',',$inserts));
	
	$myid = mysql_insert_id();
	return $myid;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>