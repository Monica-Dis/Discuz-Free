<?php

/**
 * tp_exam For Discuz!X 2.0+
 * ============================================================================
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�ʹ�ã�
 * �������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
 * @package    lib_papersetting
 * @module	   tp_exam
 * @date	     2013-7-25
 * @author	   gaotianpeng
 * @copyright  Copyright (c) 2012 tpgao_kaoshi Platform Inc. (http://www.fanzhuce.com)
 */

/*
//--------------Tall us what you think!----------------------------------
*/

if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

function savePaperRecord($uid,$paperid,$time,$date,$score,$vid)
{

	$insert = DB::insert('tpexam_examrecord', array(
				'uid'=>$uid,
				'exam_type' => $paperid,
				'usetime' => $time,
				'date' => $date,
				'score'=> $score,
				'verifyid'=>$vid
				),1);

		return $insert;

}

function saveUserAnswerRecord($belongrecord,$wendauserimage,$serializedata,$imgserializedata)
{
	$insert = DB::insert('tpexam_useranswer', array(
				'belongrecord'=>$belongrecord,
				'wendauserimage'=>$wendauserimage,
				'serializedata'=>$serializedata,
				'source'=>1,
				'imgserializedata'=>$imgserializedata
				),1);

		return $insert;
}


function SerializeUserSubmit($useranswer_danxuan,
$useranswer_duoxuan,
$useranswer_panduan,
$useranswer_tiankong,
$useranswer_wenda,
$recordid,$imguploaddata=array()){
	
		$thing = array();

		
		foreach($useranswer_danxuan as $k=>$v)
		{
			$eid = $v[0];
			$v = array_splice($v,1);

			$thing[] = array('tikuid'=>$eid,'tikugroupid'=> -4 ,'tdanswer'=>implode(",",$v));
			
		}
		
		
		foreach($useranswer_duoxuan as $k=>$v)
		{
			$eid = $v[0];
			$v = array_splice($v,1);

			$thing[] = array('tikuid'=>$eid,'tikugroupid'=> -4 ,'tdanswer'=>implode(",",$v));
			
		}

		foreach($useranswer_panduan as $k=>$v)
		{

			$eid = $v[0];
			$v = array_splice($v,1);

			$thing[] = array('tikuid'=>$eid,'tikugroupid'=> -4 ,'tdanswer'=>implode(",",$v));
			

		}
		
		foreach($useranswer_tiankong as $k=>$v)
		{
			$eid = $v[0];
			$v = array_splice($v,1);

			$thing[] = array('tikuid'=>$eid,'tikugroupid'=> -4 ,'tdanswer'=>implode(",",$v));
			
		}
		
		foreach($useranswer_wenda as $k=>$v)
		{
			$eid = $v[0];
			$v = array_splice($v,1);

			$thing[] = array('tikuid'=>$eid,'tikugroupid'=> -4 ,'tdanswer'=>implode(",",$v));
			
		}	

		$serialize = serialize($thing);
		
		$newtikuimguploaddata=array();
		

		foreach ($imguploaddata as $k=>$value) {
		 	 // loop through values 
		 	 $tikuid =  DB::result_first("SELECT id FROM ".DB::table('tpexam_tiku')." WHERE tid = 5 and oid = '$k'");

		 	 $newtikuimguploaddata[$tikuid]=$value;
		}
		
		$newtikuimguploaddata = serialize($newtikuimguploaddata);
		saveUserAnswerRecord($recordid,'',$serialize,$newtikuimguploaddata);
		
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>