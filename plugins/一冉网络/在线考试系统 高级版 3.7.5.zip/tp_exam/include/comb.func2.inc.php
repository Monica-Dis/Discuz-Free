<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function GetDanXuanByIdComb($item){
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where id = $item");
	if($data = DB::fetch($query))
	{
		return $data;
	}
}

function GetDuoXuanByIdComb($item){
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where id = $item");
	if($data = DB::fetch($query))
	{
		return $data;
	}
}
function GetPanduanByIdComb($item){
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where id = $item");
	if($data = DB::fetch($query))
	{
		return $data;
	}
}

function GetTiankongByIdComb($item){
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where id = $item");
	if($data = DB::fetch($query))
	{
		return $data;
	}
}

function GetWendaByIdComb($item){
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." where id = $item");
	if($data = DB::fetch($query))
	{
		return $data;
	}
}


function AddErrorDanxuanToComb($adjust_danxuan,$item){
	global $_G;

	foreach($adjust_danxuan as $k=>$v){
		$uid = $_G['uid'];
		$type = 1;
		$orderid = $v['id'];
		$paperid = $item;
		if($v['r']=='W' && !empty($orderid)){
			AddTiToComb($uid,$type,$orderid,$paperid);
		}
	}
}
function AddErrorDuoxuanToComb($adjust_duoxuan,$item){
	global $_G;
	
	foreach($adjust_duoxuan as $k=>$v){
		$uid = $_G['uid'];
		$type = 2;
		$orderid = $v[id];
		$paperid = $item;
		if($v['r']=='W' && !empty($orderid)){
			AddTiToComb($uid,$type,$orderid,$paperid);
		}
	}
}
function AddErrorPanduanToComb($adjust_panduan,$item){
	global $_G;

	foreach($adjust_panduan as $k=>$v){
		$uid = $_G['uid'];
		$type = 3;
		$orderid = $v[id];
		$paperid = $item;
		if($v['r']=='W' && !empty($orderid)){
			AddTiToComb($uid,$type,$orderid,$paperid);
		}
	}
}
function AddErrorTiankongToComb($adjust_duoxuan,$item){
	global $_G;

	foreach($adjust_duoxuan as $k=>$v){
		$uid = $_G['uid'];
		$type = 4;
		$orderid = $v[id];
		$paperid = $item;
		if($v['r']=='W' && !empty($orderid)){
			AddTiToComb($uid,$type,$orderid,$paperid);
		}
	}
}
function AddErrorWendaToComb($adjust_duoxuan,$item){
	global $_G;

	foreach($adjust_duoxuan as $k=>$v){
		$uid = $_G['uid'];
		$type = 5;
		$orderid = $v[id];
		$paperid = $item;
		if($v['r']=='W' && !empty($orderid)){
			AddTiToComb($uid,$type,$orderid,$paperid);
		}
	}
}

function AddTiToComb($uid,$type,$orderid,$paperid){
	$timenow = time();
	$findrecord = 0;
	
	$query = DB::query("SELECT id,errortimes FROM ".DB::table('tpexam_tiku_errorbook')." where errortype ='$type' and errorid = $orderid");
	while($data = DB::fetch($query))
	{
		$error_count = $data['errortimes'] + 1;

			DB::update('tpexam_tiku_errorbook', array(
			'errortimes' => $error_count
			),"id=".$data['id']);	
			
			$findrecord = 1;
	}
	
	if(!$findrecord){
			DB::insert('tpexam_tiku_errorbook', array(
			'uid'=>$uid,
			'errortype' => $type,
			'errorid'=>$orderid,
			'errortimes' => 1,
			'errordata' => $timenow,
			'paperid'=> $paperid
			));
	}
	
	
}

function GetSubjectById($item,$length=30){
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where id = $item");
	if($data = DB::fetch($query))
	{
		$subject = cutstr($data['ask'],$length,"...");
		return $subject;
	}	
}

function GetDanXuanByIdArrayComb($item_array){
	
	$danxuan_array=array();

	foreach($item_array as $k=>$value){
		
		$danxuan = GetDanXuanByIdComb($value);
		$danxuan_array[]=$danxuan;

	}
	
	return $danxuan_array;
}

function GetDuoXuanByIdArrayComb($item_array){
	$duoxuan_array=array();
	
	foreach($item_array as $k=>$value){
		
		$duoxuan = GetDuoXuanByIdComb($value);
		$duoxuan_array[]=$duoxuan;
	}
	
	return $duoxuan_array;	
}

function GetPanduanByIdArrayComb($item_array){
	$panduan_array=array();
	
	foreach($item_array as $k=>$value){
		
		$panduan = GetPanduanByIdComb($value);
		$panduan_array[]=$panduan;
	}
	
	return $panduan_array;	
}

function GetTiankongByIdArrayComb($item_array){
	$tiankong_array=array();
	
	foreach($item_array as $k=>$value){
		
		$tiankong = GetTiankongByIdComb($value);
		$tiankong_array[]=$tiankong;
	}
	
	return $tiankong_array;	
}

function GetWendaByIdArrayComb($item_array){
	$wenda_array=array();
	
	foreach($item_array as $k=>$value){
		
		$wenda = GetWendaByIdComb($value);
		$wenda_array[]=$wenda;
	}
	
	return $wenda_array;	
}

function GetErrorBook($uid)
{
	
	$error=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_errorbook')." where uid = '$uid'");
	while($data = DB::fetch($query))
	{
		$error[] = $data;
	}
	
	return $error;
}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>