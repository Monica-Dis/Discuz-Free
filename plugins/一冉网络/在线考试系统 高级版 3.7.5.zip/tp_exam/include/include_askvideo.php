<?PHP


if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

function getaskvideo($videoid){
	$vid = C::t('#tpgao_edu#tpgao_edu_video#')->fetch_by_id($videoid);
	return $vid['video_url'];
}

function getaskvideosrcurl($videoid){
	$vid = C::t('#tpgao_edu#tpgao_edu_video#')->fetch_by_id($videoid);
	$cpid = $vid['cpid'];
	$url = 'plugin.php?id=tpgao_edu:view&typeid='.$vid['typeid'].'&courseid='.$vid['courseid'].'&cpid='.$vid['cpid'];
	return $url;
}

function getaskvideocpidinfo($videoid){
	$vid = C::t('#tpgao_edu#tpgao_edu_video#')->fetch_by_id($videoid);

	$cpid = $vid['cpid'];
	$subject = C::t('#tpgao_edu#tpgao_edu_chapter#')->fetch_subject_by_id($cpid);
	return $subject;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>