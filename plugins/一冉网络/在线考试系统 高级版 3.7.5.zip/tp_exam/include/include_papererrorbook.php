<?php

/**
 * tp_exam For Discuz!X 2.0+
 * ============================================================================
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�ʹ�ã�
 * �������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
 * @package    lib_papersetting
 * @module	   tp_exam
 * @date	     2013-7-25
 * @author	   gaotianpeng
 * @copyright  Copyright (c) 2012 tpgao_kaoshi Platform Inc. (http://www.fanzhuce.com)
 */

/*
//--------------Tall us what you think!----------------------------------
*/

if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}


class paper_errorbook{
	
	var $paperid = 0;
	var $uid = 0;
	
	function paper_errorbook()
	{
		
	}
	
	function paper_addbygroup($group)
	{
		$tikuid=0;
		foreach($group as $key=>$value){
			if($value['r'] == 'W'){
				
				$tikuid = $value['id'];
				
				if($value['type'] > 0) //˵���Ǿɵ�ID��ת�����µ�
				{
					$tikuid = $this->gettikuid($value['type'],$key);
				}
				
				
				$this->paper_additem($tikuid,$value);
			}
		}
	}
	
	function paper_additem($id,$question)
	{
		$result = C::t('#tp_exam#tp_exam_errorbook#')->fetch_by_id($id,$this->uid);
		
		if(is_array($result) && empty($result) && $id > 0){
			
			$error = DB::fetch_first("SELECT * FROM ".DB::table("tpexam_tiku")." WHERE id='$id'");
			
			C::t('#tp_exam#tp_exam_errorbook#')->insert(array('tikuid'=>$id,
			'paperid'=>$this->paperid,
			'uid'=>$this->uid,
			'errortype'=>$error['tid'],
			'errorid'=>$error['oid'],
			'errordata'=>TIMESTAMP));
		}
	}
	
	function gettikuid($type,$id)
	{
		if($type == 1){
			return DB::result_first("SELECT eid FROM ".DB::table('tpexam_tiku_danxuan')." WHERE id='$id'");
		}elseif($type == 2){
			return DB::result_first("SELECT eid FROM ".DB::table('tpexam_tiku_duoxuan')." WHERE id='$id'");
		}elseif($type == 3){
			return DB::result_first("SELECT eid FROM ".DB::table('tpexam_tiku_panduan')." WHERE id='$id'");
		}elseif($type == 4){
			return DB::result_first("SELECT eid FROM ".DB::table('tpexam_tiku_tiankong')." WHERE id='$id'");
		}elseif($type == 5){
			return DB::result_first("SELECT eid FROM ".DB::table('tpexam_tiku_wenda')." WHERE id='$id'");
		}
	}
}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>