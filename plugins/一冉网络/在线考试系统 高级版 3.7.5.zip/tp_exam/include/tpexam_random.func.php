<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
���ݽڵ�ţ����ɱ��ڵ��������½ڵ�ѡ���������
$typeid - �ڵ��
*/
function GetDaXuanByRandom($typeid,$number)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belongnode = $typeid and yuedulijie_timutype = -1 order by rand() ASC limit 0, $number");
	//tpexam_tiku_danxuan
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return $tiku;
}
function GetDaXuanCount($typeid)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belongnode = $typeid and yuedulijie_timutype = -1 order by id ASC");

	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return $tiku;
}

function GetDaXuanByChapterExercise($typeid,$chapterid,$number)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belongnode = $typeid and yuedulijie_timutype = -1 and belongchapter = $chapterid order by id ASC limit 0, $number");
	//tpexam_tiku_danxuan
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return $tiku;	
}

function GetDanxuanAnswer_ById($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where id=$item");
	while($data = DB::fetch($query))
	{
		
		require_once libfile ( 'function/discuzcode' );
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['answer_parser']  = discuzcode ( $data['answer_parser'] , 0, 0, 1, 0, 1, 1, 1, 0, 0, 0 ,1);
		
				//����video
		if (is_numeric($data['video'])) {
			require_once libfile ('include/askvideo','plugin/tp_exam');
		 	$data['videoid'] = $data['video'];
		 	$data['video'] = getaskvideo($data['video']);
		 	$data['videosrc_url'] = getaskvideosrcurl($data['videoid']);
		 	$data['videochapter_info'] = getaskvideocpidinfo($data['videoid']);
		}
		
		$tiku = $data;
		return $tiku;
	}
	return $tiku;
}

function GetDuoxuanAnswer_ById($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where id=$item");
	while($data = DB::fetch($query))
	{
		require_once libfile ( 'function/discuzcode' );
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option1']  = discuzcode ( $data['option1'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option2']  = discuzcode ( $data['option2'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option3']  = discuzcode ( $data['option3'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option4']  = discuzcode ( $data['option4'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option5']  = discuzcode ( $data['option5'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option6']  = discuzcode ( $data['option6'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$data['option7']  = discuzcode ( $data['option7'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		
		$tiku = $data;
		return $tiku;
	}
	return $tiku;
}

function GetPanduanAnswer_ById($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where id=$item");
	while($data = DB::fetch($query))
	{
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$tiku = $data;
		return $tiku;
	}
	return $tiku;	
}

function GetTiankongAnswer_ById($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where id=$item");
	while($data = DB::fetch($query))
	{
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$tiku = $data;
		return $tiku;
	}
	return $tiku;	
}

function GetWendaAnswer_ById($item)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." where id=$item");
	if($data = DB::fetch($query))
	{
		$data['ask']  = discuzcode ( $data['ask'] , 0, 0, 0, 0, 1, 1, 1, 0, 0, 0 ,1);
		$tiku = $data;
		return $tiku;
	}
	
	return $tiku;	
}

function checkDanxuanAnswer($user,$system)
{
	//��һ��ʼ��Ϊ-1��ȡ�ڶ������������������Ҳ���ڶ�����
	/*echo 'user='.$user[1] .'<br>';
	echo 'system='.$system['answer'].'<br>';*/
	$result=array();

	if(!empty($user[1]))
	{
		if($user[1]==$system['answer'])
		{
			$result['result']=1;
		}
	}
	else
		$result['result']=0;
	
	$result['parser']=$system['answer_parser'];
	$result['score']=$system['score'];
	$result['needbuyparser']=$system['viewParser_credits'];
	$result['daan']=$system['answer'];
	return $result;
}

function checkDuoxuanAnswer($user,$system)
{
	//��һ��ʼ��Ϊ-1��ȡ�ڶ������������������Ҳ���ڶ�����
	/*echo 'user='.$user[1] .'<br>';
	echo 'system='.$system['answer1'].$system['answer2'].$system['answer3'].$system['answer4'].$system['answer5'].'<br>';*/
	$result=array();
	$score = 0;
	if(!empty($user[1]))
	{
		if($user[1]==$system['answer1'] &&
		$user[2]==$system['answer2'] &&
		$user[3]==$system['answer3'] &&
		$user[4]==$system['answer4'] && 
		$user[5]==$system['answer5']
		)
		{
			$score = $system['score'];
			$result['result']=1;
		}else{
			$result['result']=0;
		}
	}
	else{

		$result['result']=0;
	}
		
	
	$result['parser']=$system['answer_parser'];
	$result['score']=$score;
	$result['needbuyparser']=$system['viewParser_credits'];
	$result['daan']=$system['answer1'].$system['answer2'].$system['answer3'].$system['answer4'].$system['answer5'].$system['answer6'].$system['answer7'];

	return $result;
}

/*
ʹ�üƷַ����Ʒ� 
*/
function checkDuoxuanAnswerScheme($paperId,$user,$system)
{
	//�ж��Ծ��Ƿ����üƷַ���
	$useScoreScheme = GetUseScoreScheme($paperId);
	if(!$useScoreScheme){ //δʹ��
		return checkDuoxuanAnswer($user,$system); //ֱ�ӵ�����ǰ��
		
	}else{ //����

		$check = checkDuoxuanAnswer($user,$system);

		if($check['result'] == 1) return $check;  //���ȫ�ԣ��Ͳ���Ҫ�Ʒַ���
		
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/func.score.php";
		
		$scoreScheme = new scoreScheme();

		$myscheme = $scoreScheme->getSchemeByPaperId($paperId);
		//print_r($myscheme);
		$scoreScheme->setUserAnswer($user);
		$scoreScheme->setSystemAnswer($system);
		$scoreScheme->setScheme($myscheme);
		$act = $scoreScheme->getResult();
		//print_r($act);
		
		return $act;
	}
}

function GetUseScoreScheme($paperId)
{
	$query  = DB::query ("select * from ".DB::table('tpexam_paper')." where id = $paperId");
	while($db = DB::fetch($query)){
		return $db['usescorescheme'];
	}
	
	return 0;
}

function checkPanduanAnswer($user,$system)
{
//��һ��ʼ��Ϊ-1��ȡ�ڶ������������������Ҳ���ڶ�����
	/*echo 'user='.$user[1] .'<br>';
	echo 'system='.$system['answer'].'<br>';*/
	$result=array();

	if(isset($user[1]))
	{
		if($user[1]==$system['answer'])
		{
			$result['result']=1;
		}
	}
	else
		$result['result']=0;
	
	$result['parser']=$system['answer_parser'];
	$result['score']=$system['score'];
	$result['needbuyparser']=$system['viewParser_credits'];
	$result['daan']=$system['answer'];
	return $result;	
}

function result_subject($user,$system){
	
}

function checkTiankongAnswer($user,$system)
{
	$result=array();
	
	$result['score']=0;
	
	//print_r($user);
	//print_r($system);
	
	if(isset($user))
	{
		$user = array_splice($user,1);
		
		
		$u_answer = implode("|",$user);
		$s_answer = explode("|",$system['answer']);
		$s_score = explode(",",$system['score']);
		
		
		//print_r($u_answer);
		//print_r($s_answer);
		
		foreach($user as $key=>$val){
			if($val == $s_answer[$key]){

				$result['result']=1;
				$result['score'] = $result['score'] + $s_score[$key];
			}
		}
		/*
		if(trim($u_answer)==trim($system['answer']))
		{
			$result['result']=1;
			$result['score']=$system['score'];
		}
		*/
		
	}
	else
		$result['result']=0;
	
	$result['parser']=$system['answer_parser'];
	$result['needbuyparser']=$system['viewParser_credits'];
	$result['daan']=$system['answer'];
	
	$result['subject'] = result_subject($user,$system);
	
	return $result;	
}


function GetDBTable($t)
{
	$table = 'tpexam_tiku_danxuan';
	
	if($t == 1){
			$table = "tpexam_tiku_danxuan";
	}elseif($t == 2){
		$table = "tpexam_tiku_duoxuan";
	}elseif($t == 3){
		$table = "tpexam_tiku_panduan";
	}elseif($t == 4){
		$table = "tpexam_tiku_tiankong";
	}elseif($t == 5){
		$table = "tpexam_tiku_wenda";
	}
	
	return $table;
}

function isYuedu($t,$id)
{
	$table = GetDBTable($t);
	
	$query = DB::query("select * from ".DB::table($table)." where id = $id");
	$d = DB::fetch($query);
	
	if($d['yuedulijie_timutype'] > 0)
		return 1;

	return 0;
}

function GetDaXuanByItemArray($item_arr)
{
	$tiku=array();
	foreach($item_arr as $k=>$v)
	{
		$y = isYuedu(1,$v);
		if(!$y){
			$item_tiku = GetDanxuanAnswer_ById($v);
			$tiku[]=$item_tiku;
		}
	}
	return $tiku;
}


function GetDuoXuanByItemArray($item_arr)
{
	$tiku=array();
	foreach($item_arr as $k=>$v)
	{
		$y = isYuedu(2,$v);
		if(!$y){
			$item_tiku = GetDuoxuanAnswer_ById($v);
			$tiku[]=$item_tiku;
		}
	}
	return $tiku;	
}

function GetPanduanByItemArray($item_arr)
{
	$tiku=array();
	foreach($item_arr as $k=>$v)
	{
		$y = isYuedu(3,$v);
		if(!$y){
			$item_tiku = GetPanduanAnswer_ById($v);
			$tiku[]=$item_tiku;
		}
	}
	return $tiku;	
}

function GetTiankongByItemArray($item_arr)
{
	$tiku=array();
	foreach($item_arr as $k=>$v)
	{
		$y = isYuedu(4,$v);
		if(!$y){
			$item_tiku = GetTiankongAnswer_ById($v);
			$tiku[]=$item_tiku;
		}
	}
	
	return $tiku;	
}

function GetWendaByItemArray($item_arr)
{
	$tiku=array();
	foreach($item_arr as $k=>$v)
	{
		$y = isYuedu(5,$v);
		if(!$y){
			$item_tiku = GetWendaAnswer_ById($v);
			$tiku[]=$item_tiku;
		}
	}
	
	return $tiku;	
}

function GetRandomNumber()
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_setting')." where skey='random_number'");
	while($data = DB::fetch($query))
	{
		$tiku = $data['svalue'];
		return $tiku;
	}	
}
function GetRandomTime()
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_setting')." where skey='RandomTimer'");
	while($data = DB::fetch($query))
	{
		$tiku = $data['svalue'];
		return $tiku;
	}	
}
function GetDuoXuanByRandom($typeid,$number)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where belongnode = $typeid order by rand() ASC limit 0, $number");
	//tpexam_tiku_danxuan
	
	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return $tiku;	
}
function GetDuoXuanCount($typeid)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where belongnode = $typeid order by id ASC");

	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return $tiku;		
}

function GetItemExerciseNumber()
{
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_setting')." where skey='ItemNumber'");
	while($data = DB::fetch($query))
	{
		$tiku = $data['svalue'];
		return $tiku;
	}	
}

function GetNumber_Item($arr,$number)
{
	$item_arr=array();
	
	$random_arr=array();
	$random_final_arr=array(0,0,0,0,0);
	
	foreach($arr as $k=>$v)
	{
		if($v>$number)
			$item_arr[]=$number;
		else
		{
			if($v>0)
				$item_arr[]=$v;
		}
	}

	//���ɹ̶��ܺ͵����������ÿ�ҪС�ڻ����������
	$random_arr[0]= rand(0,$item_arr[0]);
	$random_arr[1]= rand(0,$item_arr[1]);
	$random_arr[2]= rand(0,$item_arr[2]);
	$random_arr[3]= rand(0,$item_arr[3]);
	$random_arr[4]= rand(0,$item_arr[4]);
	
	$total = $random_arr[0]+$random_arr[1]+$random_arr[2]+$random_arr[3]+$random_arr[4];

	if($random_arr[0]+$random_arr[1] > $number)
	{
		return array($random_arr[0],$random_arr[1],0,0,0);
	}
	
	if($random_arr[0]+$random_arr[1]+$random_arr[2] > $number)
	{
		return array($random_arr[0],$random_arr[1],$random_arr[2],0,0);
	}
	
	if($random_arr[0]+$random_arr[1]+$random_arr[2]+$random_arr[3] > $number)
	{
		return array($random_arr[0],$random_arr[1],$random_arr[2],$random_arr[3],0);
	}
	
	return $random_arr;

}

function GetDaXuanChapterCount($typeid,$chapterid)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belongnode = $typeid and yuedulijie_timutype = -1 and belongchapter = $chapterid order by id ASC");

	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return $tiku;	
}
function GetDuoXuanChapterCount($typeid,$chapterid)
{
	$tiku=array();
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where belongnode = $typeid  and belongchapter = $chapterid order by id ASC");

	while($data = DB::fetch($query))
	{
		 $tiku[] = $data;
	}
	
	return $tiku;		
}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>