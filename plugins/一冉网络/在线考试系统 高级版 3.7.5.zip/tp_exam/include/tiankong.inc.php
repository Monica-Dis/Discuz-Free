<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}
	$score = daddslashes($_GET['score']);
	$answer = daddslashes($_GET['answer']);
	$belong_paper = daddslashes($_GET['belong_paper']);
	$question = daddslashes($_GET['question']);
	$viewParserCredits = daddslashes($_GET['viewParserCredits']);
	$answerparser = daddslashes($_GET['answerparser']);
	$yuedulijie_timutype = daddslashes($_GET['yuedulijie_timutype']); //id
	
	$oid = DB::insert('tpexam_tiku_tiankong',array(
	'ask' => $question,
	'answer'=> $answer,
	'score'=>$score,
	'belong_paper'=>$belong_paper,
	'viewParser_credits'=>$viewParserCredits,
	'answer_parser'=>$answerparser,
	'yuedulijie_timutype'=>$yuedulijie_timutype,
	'image'=>$imageurl,
	'audio'=>$audiourl,
	'video'=>$videourl,
	'parser_img_path'=>$parser_imageurl),1);
	
	//$skey = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_tiku'));
	//$eid = $skey + 1;
	
	$eid = DB::insert('tpexam_tiku', array('eid'=>$eid,
	'tid'=>4,
	'subject'=>$question,
	'result'=>$answer,
	'oid'=>$oid,
	'score'=>$score,
	'paperid'=>$belong_paper),1);
	
	//$eid = mysql_insert_id();
	DB::update('tpexam_tiku_tiankong', array('eid'=>$eid),"id IN ($oid)");
	
?>