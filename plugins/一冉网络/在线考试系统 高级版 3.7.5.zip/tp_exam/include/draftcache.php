<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


/*
����
*/
	$paperid = intval($_GET['item']);
	$uid = intval($_G['uid']);
	$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_cache_tpexam_draft_'.$paperid.'_'.$uid.'.php';
	$cacheinfo = lang('plugin/tp_exam','cacheinfo');
	
	if(file_exists($cache_file) && !$cache){
		$showcachedlg=1;
	}

	if($cache){
		@include_once $cache_file;
		$draftcache = array_iconv("utf-8",CHARSET,$draftcache);
	}
	
	if(!checkmobile()){
		$tiankong=array();
		foreach ($draftcache as $key=>$value) {
	 		if(is_array($value)){

	 		foreach ($value as $key1=>$value1) {
	 					$tiku = C::t('#tp_exam#tp_exam_tiku#')->fetch_by_id($value1[0]);
	 					if($tiku['tid'] == 1){
	 						$danxuan_a[$key1][1] = $value1[1];
	 					}elseif ($tiku['tid']==2) {
	 						$duoxuan_a[$key1][1] = $value1[1];
	 						$duoxuan_a[$key1][2] = $value1[2];
	 						$duoxuan_a[$key1][3] = $value1[3];
	 						$duoxuan_a[$key1][4] = $value1[4];
	 						$duoxuan_a[$key1][5] = $value1[5];
	 						$duoxuan_a[$key1][6] = $value1[6];
	 						$duoxuan_a[$key1][7] = $value1[7];
	 					}elseif ($tiku['tid']==3) {
	 						$value1[1] == 2 ? $value1[1] = 0 : '';  //�����ֻ���
	 						$panduan_a[$key1][1] = $value1[1];
	 					}elseif ($tiku['tid']==4) {
	 						foreach ($value1 as &$value) {
	 						 	$tiankong_a[$key1][] = $value;
	 						} 

	 					}elseif ($tiku['tid']==5) {
	 						$adjust_wenda[$key1]['usranswer'][1] = $value1[1];
	 					}
	 			}

	 		}
		}
		$tiankong = GetTiankongByPaperID($item);
		$tiankong_ask = GetTiankongAsk($tiankong,$tiankong_a);
		
	}else{
		
		foreach ($draftcache as $key=>$value) {
	 		if(is_array($value)){

	 		foreach ($value as $key1=>$value1) {
	 					$tiku = C::t('#tp_exam#tp_exam_tiku#')->fetch_by_id($value1[0]);
	 					if($tiku['tid'] == 1){
	 						$cache_danxuan_a[$key1][1] = $value1[1];
	 					}elseif ($tiku['tid']==2) {
							array_splice($value1,0,1);
	 						$value = implode("\n", $value1);
	 						$cache_duoxuan_a[$key1][1] = $value;
	 					}elseif ($tiku['tid']==3) {
	 						$value1[1] == 0?$value1[1] = 2:'';
							$cache_panduan_a[$key1][1] = $value1[1];
	 					}elseif ($tiku['tid']==4) {
	 						array_splice($value1,0,1);
	 						$value = implode(",", $value1);
	 						$cache_tiankong_a[$key1][1] = $value;
	 					}elseif ($tiku['tid']==5) {
	 						$cache_wenda_a[$key1][1] = $value1[1];
	 					}
	 			}

	 		}
		}
	}
	
	
	
	
	function array_iconv($in_charset,$out_charset,$arr){  
        return eval('return '.iconv($in_charset,$out_charset,var_export($arr,true).';'));  
  }
//From: di'.'sm.t'.'aoba'.'o.com
?>