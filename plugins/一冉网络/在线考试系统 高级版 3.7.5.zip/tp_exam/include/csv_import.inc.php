<?php

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


	$filename = $_FILES['shoplogo']['name'];
	if($_FILES['shoplogo']['error'] !== 0 && !empty($_FILES['shoplogo']['name'])) {
		cpmsg('File Not Exist');
		exit;
	}
	
	$admin_csv_import_files = lang('plugin/tp_exam', 'admin_csv_import_files');
	$admin_csv_import_files_nodata = lang('plugin/tp_exam', 'admin_csv_import_files_nodata');
	$admin_csv_import_files_success = lang('plugin/tp_exam', 'admin_csv_import_files_success');
	$admin_csv_import_files_fail = lang('plugin/tp_exam', 'admin_csv_import_files_fail');
	
	echo $_FILES['shoplogo']['name'];
	if (empty ($filename)) {
		
		echo $admin_csv_import_files;
		exit;
	}
	$handle = fopen($filename, 'r');
	$result = input_csv($handle); //����csv
	$len_result = count($result);
	if($len_result==0){
		echo $admin_csv_import_files_nodata;
		exit;
	}
	
	
	for ($i = 1; $i < $len_result; $i++) { //ѭ����ȡ���ֶ�ֵ
		$name = iconv('gb2312', 'utf-8', $result[$i][0]); //����ת��
		$sex = iconv('gb2312', 'utf-8', $result[$i][1]);
		$age = $result[$i][2];
		$data_values .= "('$name','$sex','$age'),";
	}
	$data_values = substr($data_values,0,-1); //ȥ�����һ������
	fclose($handle); //�ر�ָ��
	$query = mysql_query("insert into student (name,sex,age) values $data_values");//�����������ݱ���
	if($query){
		echo $admin_csv_import_files_success;
	}else{
		echo $admin_csv_import_files_fail;
	}
	
?>