<?php

function GetPaperItemTimuDesc($item)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id = '$item'");

	while($row = DB::fetch($query))
	{
		$paper_timu_item_desc = $row['paper_timu_item_desc'];
		$paper_timu_item_desc_arr=explode("\n",$paper_timu_item_desc);
		
	}	
	
	return $paper_timu_item_desc_arr;
}

function GetPeiwuAnswerByPaperID($item)
{
	return array('A','B','C','D','E','F','G');
}


function GetAnswerByPaperID_Peiwu($item,$usrAnswer)
{
	
}

function canExamPaper($item)
{
	//group
	global $_G;
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id = $item");
	while($data = DB::fetch($query))
	{
		
		
		if($data['examgroup']==0){
			return array('pass'=>1,'vip'=>0);
		}
		
		$group_arr= explode("|",$data['examgroup']);

		if(in_array($_G['groupid'],$group_arr) )
			return array('pass'=>1,'vip'=>1);
	}

	return array('pass'=>0,'vip'=>0);
}

function GetNeedCredits($needitem)
{
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id= $needitem");
	
	if($data = DB::fetch($query))
	{
		return array($data['needcredit'],$data['buycredits'],$data['buyonlyonce']);
	}
	
}

function GetCurrentCreditsbyExt($uid,$ext){

	return DB::result_first("SELECT '$ext' FROM ".DB::table('common_member_count')." WHERE uid = '$uid'");
}

function saveuseranswer($useranswer_danxuan,
$useranswer_duoxuan,
$useranswer_panduan,
$useranswer_tiankong,
$useranswer_wenda,
$wenda_user_image,
$recordid)
{

		foreach($useranswer_tiankong as $k=>$v)
		{
			if(count($v)==0)
			{
				$tiankong .= '-';
				$tiankong .= '|';
				continue;
			}
			foreach($v as $n=>$val)	
			{

					$tiankong .=$val;
					$tiankong .= '|';
			}
			
			$tiankong .= '||';
		}

		foreach($useranswer_danxuan as $k=>$v)
		{
			//$danxuan .= $k;
			if(count($v)==1)
			{
				$danxuan .= '-';
				$danxuan .= '|';
				continue;
			}
			foreach($v as $n=>$val)	
			{
				if($n)
				{
					$danxuan .=$val;
					$danxuan .= '|';
				}
			}
		}
		
		foreach($useranswer_duoxuan as $k=>$v)
		{
			//$danxuan .= $k;
			if(count($v)==1)
			{
				$duoxuan .= '-';
				$duoxuan .= '|';
				continue;
			}
			foreach($v as $n=>$val)	
			{
				if($n)
				{
					$duoxuan .=$val;
				}
			}
			$duoxuan .= '|';
		}
		
		foreach($useranswer_panduan as $k=>$v)
		{

			if(count($v)==1)
			{
				$panduan .= '-';
				$panduan .= '|';
				continue;
			}
			foreach($v as $n=>$val)	
			{
				if($n)
				{
					$panduan .=$val;
				}
			}
			$panduan .= '|';
		}
		
		foreach($useranswer_wenda as $k=>$v)
		{
			$wenda .= $v[0].'(<a href="'.$v['answerimage'].'"><img src="'.$v['answerimage'].'" width="30" height="30"></a>)';
			$wenda .= "|";
		}	
	
		DB::insert('tpexam_useranswer', array(
				'belongrecord' => $recordid,
				'danxuan' => $danxuan,
				'duoxuan' => $duoxuan,
				'panduan'=> $panduan,
				'tiankong'=> $tiankong,
				'wenda'=> $wenda,
				));
				
}

function getuseranswer($answerid,$item)
{

	$query = DB::query("SELECT * FROM ".DB::table('tpexam_useranswer')." where belongrecord = $answerid");
	if($data = DB::fetch($query))
	{
		return $data[$item];
	}
}


/*
�����Ծ��ֿܷ�ʼ
*/
function GetDanxuanScore($item){
	$dan_score = 0;
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_danxuan')." where belong_paper = $item");
	while($data = DB::fetch($query))
	{
		$dan_score = $dan_score + $data['score'];
	}	
	
	return $dan_score;
}

function GetDuoxuanScore($item){
	$duo_score = 0;
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_duoxuan')." where belong_paper = $item");
	while($data = DB::fetch($query))
	{
		$duo_score = $duo_score + $data['score'];
	}	
	
	return $duo_score;
}
function GetPanduanScore($item){
	$pan_score = 0;
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_panduan')." where belong_paper = $item");
	while($data = DB::fetch($query))
	{
		$pan_score = $pan_score + $data['score'];
	}	
	
	return $pan_score;
}
function GetTiankongScore($item){
	$tian_score = 0;
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_tiankong')." where belong_paper = $item");
	while($data = DB::fetch($query))
	{
		$tian_score = $tian_score + $data['score'];
	}	
	
	return $tian_score;
}
function GetWendaScore($item){
	$wen_score = 0;
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku_wenda')." where belong_paper = $item");
	while($data = DB::fetch($query))
	{
		$wen_score = $wen_score + $data['score'];
	}	
	
	return $wen_score;
}
function GetPaperItemScore($paper){
	$paperscore=array();
	
	foreach($paper as $k=>$value)
	{
		
		$itemscore = 0;

		$d_score = GetDanxuanScore($value[id]);
		
		$m_score = GetDuoxuanScore($value[id]);
		$p_score = GetPanduanScore($value[id]);
		$t_score = GetTiankongScore($value[id]);
		$w_score = GetWendaScore($value[id]);
		
		$itemscore = $d_score + $m_score + $p_score + $t_score+ $w_score;
		
		$paperscore[]= $itemscore;
	}
	
	return $paperscore;
}
/*�����Ծ��ֽܷ���*/

//��¼����
function WriteBuyRecordDB($uid,$creditstype,$buypaper,$buynum ,$pre,$after){
	
	$query = DB::query("select * from ".DB::table("tpexam_buy")." where uid = $uid");
	
	//if(!DB::fetch($query)){
		$orderid = dgmdate(TIMESTAMP, 'YmdHis').random(18);
		
		DB::insert('tpexam_buy',array(
		'uid' => $uid,
		'orderid'=>$orderid,
		'finish'=>1,
		'paperid' => $buypaper,
		'buynum' => $buynum,
		'buytime' => TIMESTAMP,
		'creditstype'=> $creditstype,
		'precredit'=>$pre,
		'aftercredit'=>$after));
	//}

	 
}

//�û��Ƿ���
function GetUserBuyedPaper($uid,$paperid){
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_buy')." where uid = $uid");
	while($data = DB::fetch($query))
	{
		if($data['paperid'] == $paperid){
			return 1;
		}
	}	
	
	return 0;
}

function GetPaperTimes($paper){
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id = $paper");
	while($data = DB::fetch($query)){
		return $data['examtimes'];
	}
	
	return 0;
}

function GetPaperTimeSpan($paper){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id = $paper");
	while($data = DB::fetch($query)){
		return $data['usetimespan'];
	}
	return 0;
}
//From: di'.'sm.t'.'aoba'.'o.com
?>