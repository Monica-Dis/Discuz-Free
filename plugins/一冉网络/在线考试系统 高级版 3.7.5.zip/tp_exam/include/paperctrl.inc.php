<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	
	
	
	$paper_exam_time_span_msg = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='paper_exam_time_span_msg'");
	
	$timespan = PaperInTimeSpan($item);
	
	if(is_array($timespan)){
		$now =date("Y-m-d H:i:s");

		if(strtotime($now) < strtotime($timespan[0])){
			showmessage($paper_exam_time_span_msg,'plugin.php?id=tp_exam:index');
		}
		if(strtotime($now) > strtotime($timespan[1])){
			showmessage($paper_exam_time_span_msg,'plugin.php?id=tp_exam:index');
		}

	}
	
	
	function PaperTimesReach($uid,$canExamTimes,$paperid){
		$paper_exam_times_reach_msg = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='paper_exam_times_reach_msg'");
		$examtimes = DB::result_first("SELECT examtimes FROM ".DB::table('tpexam_paper')." where id = $paperid");
		if(!$examtimes){
			return 0;
		}
		$paper = array();
		$record = 0;
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_paperctrl')." where uid = $uid");
		while($data = DB::fetch($query)){
			if($paperid == $data['paperid']){
				$record = 1;
				
				if($data['examtimes'] < $canExamTimes){
					$newTimes = intval($data['examtimes']) + 1;
					DB::update('tpexam_paperctrl', array('examtimes' =>$newTimes), "id=".$data['id']);
				}
				else{
					showmessage($paper_exam_times_reach_msg,'plugin.php?id=tp_exam:index');
				}

			}
		}

		if(!$record){
			DB::insert('tpexam_paperctrl', array('examtimes' =>1,'uid'=>$uid,'paperid'=>$paperid));
		}
	}


	function PaperInTimeSpan($paper){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_paper')." where id = $paper");
		while($data = DB::fetch($query)){
			if($data['usetimespan'] == 1){
				return array($data['startexamtime'],$data['endexamtime']);
			}
		}
		
		return 0;
	}
	
	
	function usersubmitpaper($uid,$paperid){
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord')." where uid ='$uid' and exam_type = $paperid");
		while($data = DB::fetch($query)){
			return array('uid'=>$uid,
			'paperid'=>$paperid,
			'score'=>$data['score']);
		}
		return array('uid'=>0,
		'paperid'=>0,
		'score'=>0);
	}
	
	require_once libfile('include/papersetting','plugin/tp_exam');
	$setting = getSetting($item);
	$papersetting = getpaperSetting($item);
	require_once libfile('function/cache');
	$cache_file = DISCUZ_ROOT.'./data/sysdata/cache_tpexam_alert.php';
	if(file_exists($cache_file)){
		@include_once DISCUZ_ROOT.'./data/sysdata/cache_tpexam_alert.php';
	}else{
		$paper=0;
		$uidarr[$_G['uid']][$item]=$paper;
		$readalert = $uidarr;
		$cacheArray .= "\$readalert=".arrayeval($readalert).";\n";
		writetocache('tpexam_alert', $cacheArray);
	}
	
	if($papersetting['examtimes'] > 0 && $readalert[$_G['uid']][$item] == 0){
		$paper=1;
		$readalert[$_G['uid']][$item]=$paper;
		$cacheArray .= "\$readalert=".arrayeval($readalert).";\n";
		writetocache('tpexam_alert', $cacheArray);

		dheader("Location: plugin.php?id=tp_exam:alert&t=%e6%9c%ac%e8%af%95%e5%8d%b7%e5%8f%97%e6%ac%a1%e6%95%b0%e6%8e%a7%e5%88%b6%ef%bc%8c%e6%8f%90%e4%ba%a4%e8%af%95%e5%8d%b7%e5%90%8e%e5%b0%86%e8%ae%a1%e4%b8%80%e6%ac%a1%ef%bc%8c%e7%a1%ae%e8%ae%a4%e7%bb%a7%e7%bb%ad%e5%90%97&paperid=".$item);
	}
		$paper=0;
		$readalert[$_G['uid']][$item]=$paper;
		$cacheArray .= "\$readalert=".arrayeval($readalert).";\n";
		writetocache('tpexam_alert', $cacheArray);
		
		
?>