<?php

function GetAnswerParser($timu_type,$item)
{
	$result = array();
	$item = intval($item);
	
	$query = DB::query("SELECT * FROM ".DB::table($timu_type). " where id=$item");
	
	while($data = DB::fetch($query))
	{
		$result = $data['answer_parser'];
	}
	
	return $result;
}

//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>
