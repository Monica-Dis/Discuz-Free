<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function GetScoreScheme($id,$used)
{
	$admin_null = lang('plugin/tp_exam','admin_null');
	
	$query  = DB::query ("select * from ".DB::table('tpexam_examscore')." order by id asc");
	
	$index = 0;
	while($db = DB::fetch($query)){
		
		if($index == 0){
			$html = '<select name="scorescheme['.$id.']"><option value ="0">'.$admin_null.'</option>';
			$index = 1;
		}
		
		if($used == $db['id'])
		{
			$html .= '<option value="'.$db['id'].'" selected>'.$db['schemename'].'</option>';
		}else{
			$html .= '<option value="'.$db['id'].'">'.$db['schemename'].'</option>';
		}
	}
	$html .= '</select>';
	
	return $html;
}


class scoreScheme{
	
	public $scheme;
	public $useranswer;
	public $systemanswer;
	

	function setUserAnswer($user){
		$this->useranswer=$user;
	}
	
	function setSystemAnswer($system){
		$this->systemanswer = $system;
	}


	function getResult()
	{
		$act=array();
		
		$score = 0;
		$result = 0;
		
		$rnum = $this->getRightNum($this->useranswer,$this->systemanswer);
		$wnum = $this->getWrongNum($this->useranswer,$this->systemanswer);

		switch($rnum){
			case 1:
				$score = $this->scheme['right1'];break;
			case 2:
				$score = $this->scheme['right2'];break;
			case 3:
				$score = $this->scheme['right3'];break;
			case 4:
				$score = $this->scheme['right4'];break;
		}
		if($wnum>0){
			$score = 0;
		}
		
		$act['result'] = $result;
		$act['parser']=$this->systemanswer['answer_parser'];
		$act['score']=$score;
		$act['needbuyparser']=$this->systemanswer['viewParser_credits'];
		$act['daan']=$this->systemanswer['answer1'].$this->systemanswer['answer2'].$this->systemanswer['answer3'].$this->systemanswer['answer4'].$this->systemanswer['answer5'].$this->systemanswer['answer6'].$this->systemanswer['answer7'];
	
		return $act;
	}

	function getSchemeByPaperId($pid)
	{
		$sid = 0;
		
		$query  = DB::query ("select * from ".DB::table('tpexam_paper')." where id = $pid");
		while($db = DB::fetch($query)){
			$sid = $db['usescorescheme'];
		}
		
		$query  = DB::query ("select * from ".DB::table('tpexam_examscore')." where id = $sid");
		while($s = DB::fetch($query)){
			return $s;
		}
		return array();
	}

	function setScheme($scheme)
	{
		$this->scheme['right1'] = $scheme['right1'];
		$this->scheme['right2'] = $scheme['right2'];
		$this->scheme['right3'] = $scheme['right3'];
		$this->scheme['right4'] = $scheme['right4'];
	
	}
		
	function getRightNum($user,$system)
	{
		$total = 0;
		$index = 1;
		
		if(count($user) > 1){
				
				foreach($user as $k=>$v)
				{
					if($k > 0){
					if(in_array($user[$k],$system)) {
						$total++;
					}
				}
					
				}
			
			return $total;
		}
		
		return 0;
	}

	function getWrongNum($user,$system) //����ѡ�����Ϊ0������Ϊ��ѡ�����÷�
	{
		$total = 0;
		$index = 1;
		
		if(count($user) > 1){
				
				foreach($user as $k=>$v)
				{
					if($k > 0){
					if(!in_array($user[$k],$system)) {
						$total++;
					}
				}
					
				}
			
			return $total;
		}
		
		return 0;
	}
}
//From: d'.'i'.'sm.ta'.'o'.'bao.com
?>