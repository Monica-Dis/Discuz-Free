<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}
	$option = daddslashes($_GET['option']);
	$score = daddslashes($_GET['score']);
	$answer = daddslashes($_GET['answer']);
	$belong_paper = daddslashes($_GET['belong_paper']);
	$question = daddslashes($_GET['question']);
	$viewParserCredits = daddslashes($_GET['viewParserCredits']);
	$answerparser = daddslashes($_GET['answerparser']);
	$yuedulijie_timutype = daddslashes($_GET['yuedulijie_timutype']); //id
	$bgroups = intval($_GET['bgroups']);
	
	$insert = DB::insert('tpexam_tiku_duoxuan',array(
	'ask' => $question,
	'option1' => $option[0],
	'option2' => $option[1],
	'option3' => $option[2],
	'option4'=> $option[3],
	'option5'=> $option[4],
	'option6'=> $option[5],
	'option7'=> $option[6],
	'answer1'=> $answer[0],
	'answer2'=> $answer[1],
	'answer3'=> $answer[2],
	'answer4'=> $answer[3],
	'answer5'=> $answer[4],
	'answer6'=> $answer[5],
	'answer7'=> $answer[6],
	'score'=>$score,
	'data'=>TIMESTAMP,
	'belong_paper'=>$belong_paper	,
	'viewParser_credits'=>$viewParserCredits,
	'yuedulijie_timutype'=>$yuedulijie_timutype,
	'answer_parser'=>$answerparser,
	'image'=>$imageurl,
	'audio'=>$audiourl,
	'video'=>$videourl,
	'parser_img_path'=>$parser_imageurl),1);
	
	//$mid = mysql_insert_id();
	
	//$skey = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_tiku'));
	//$eid = $skey + 1;
	
	$post = array(
	'eid'=>0,
	'tid'	 => 2,
	'oid'	 => $insert,
	'groupid'=>$bgroups,
	'paperid'=>$belong_paper,
	'subject'=> $question,
	'option'=>implode("\r\n",$option),
	'parser'=>$answerparser,
	'result'=>$answer[0].$answer[1].$answer[2].$answer[3].$answer[4].$answer[5].$answer[6],
	'image'=>$imageurl,
	'viewParser_credits'=>$viewParserCredits,
	'addtime'=> TIMESTAMP ,
	'score'=>$score,
	'yuedulijie'=>$yuedulijie_timutype,
	);
	
	//DB::insert('tpexam_tiku', array('eid'=>$eid,'tid'=>2,'oid'=>$oid,'paperid'=>$belong_paper));
	$insert_eid = DB::insert('tpexam_tiku', $post, true);
	//$eid = mysql_insert_id();
	
	DB::update('tpexam_tiku_duoxuan', array('eid'=>$insert_eid),"id='$insert'");
	
?>