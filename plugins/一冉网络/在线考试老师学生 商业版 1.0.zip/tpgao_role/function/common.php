<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


function getreview_auddit($examid){
	$key =  DB::fetch_first("SELECT * FROM ".DB::table('tpexam_role_teacher')." WHERE examedid = '$examid'");
	if(is_array($key) && !empty($key)){
		
		return json_decode('['.$key['review_auddit'].']');
	}
}

function getreview_audditdesc($examid){
	$key =  DB::fetch_first("SELECT * FROM ".DB::table('tpexam_role_teacher')." WHERE examedid = '$examid'");
	if(is_array($key) && !empty($key)){
		return unserialize($key['review_audditdesc']);
	}
}

function getallwendascorebypaper($paperid){
	
	$score = 0;
	if($paperid > 0){
		
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku')." WHERE tid = 5 and paperid = '$paperid'");
		while($d = DB::fetch($query)){
			$score += $d['score'];
		}
		
	}
	
	return $score;
}

function getuidbyanswerid($answerid){
	$belongrecord = DB::result_first("SELECT belongrecord FROM ".DB::table("tpexam_useranswer")." WHERE id = '$answerid'");
	$uid = DB::result_first("SELECT uid FROM ".DB::table("tpexam_examrecord")." WHERE id = '$belongrecord'");
	return $uid;
}
//From: Dism_taobao_com
?>