<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

//�ж��û��Ƿ��¼
if(!$_G['uid']){
	$exam_must_login_tips=lang('plugin/tp_exam', 'exam_must_login_tips');
	showmessage($exam_must_login_tips, NULL, array(), array('login' => 1));
}

$app = daddslashes($_GET['app']);

$app = in_array($app, array('query', 'record' , 'useranswer','all','examed','storeorder','pubexam','paper_pub','mypaper','mytimu','error_book','scorequery','remove')) ? $app : 'query';

$is_store = false;
$store_group = $_G['cache']['plugin']['tp_exam']['store_group_timu'];

$store = unserialize($store_group);

foreach($store as $k=>$val)
{
	if($val == $_G['group']['groupid']){
		$is_store = true;
		break;
	}	
}

if(in_array($app, array('pubexam')) && !$is_store && $_G['adminid']!=1){
	showmessage('parameters_error');
}

require_once DISCUZ_ROOT."./source/plugin/tpgao_role/app/my_{$app}.php";

?>