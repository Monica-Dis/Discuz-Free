<?php
/**
 *	[������У(upgrade)] (C)2012-2099
 *	Version: 1.4 20121031
 *	Date: 2014-09-20 13:06
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');



$sql = <<<EOF

ALTER TABLE `pre_tpgao_edu_course` ADD `ignorecreditbuy` varchar(512) NOT NULL;
ALTER TABLE `pre_tpgao_edu_course` ADD `groupsdefaultplay` varchar(512) NOT NULL;
ALTER TABLE `pre_tpgao_edu_course` ADD `usergroup_playcpid_permission` varchar(512) NOT NULL;

EOF;

runquery($sql);


$finish = TRUE;

?>