<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$config = $_G['cache']['plugin']['tpgao_role'];
$deductcredits = $config['deductcredits'];
$teachercredits = $config['teachercredits'];

$examedid= intval($_GET['examedid']);

if(!submitcheck('submit')){
	
	$opactives['record'] = "class='a'";

	if(!$examedid) showmessage(lang('plugin/tpgao_role','error_no_examid'));
	
	$teachergroup = 0;
	global $_G;
	$config = $_G['cache']['plugin']['tpgao_role'];
	$viewgroups = $config['viewgroups'];
	$is_store = false;
	$store_group = $_G['cache']['plugin']['tpgao_role']['viewgroups'];
	$store = unserialize($store_group);
	foreach($store as $k=>$val)
	{
		if($val == $_G['group']['groupid']){
			$teachergroup = 1;
			break;
		}	
	}

	if($_G['adminid']==1){
		$teachergroup = 1;
	}

	//��ҳ��Ϣ
	$perpage = 15;
	$page = max(1, intval(daddslashes($_GET['page'])));
	$listStart = ($page-1) *$perpage;
	$listEnd = $page*$perpage;
	
	$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_examrecord'));
	$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 
	$multi = multi($totalnum, $perpage, $page, "plugin.php?id=tpgao_role:my",$pagecount);
	
	$list=array();
	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord')." order by id desc limit $listStart,$perpage");

	$answer = array();

	require_once DISCUZ_ROOT.'./source/plugin/tp_exam/function/function_common.php';
	$sql = DB::query("SELECT * FROM ".DB::table('tpexam_useranswer')." where belongrecord = $examedid"); //��ÿ�������������Ծ�
	while($row = DB::fetch($sql)) {
		
		if(!empty($row['serializedata'])){
			
			$uanswer = unserialize($row['serializedata']);
			$imgserializedata = unserialize($row['imgserializedata']);

			$answer=array();
			foreach($uanswer as $k=>$val){
				
				//$val = get_object_vars($val);
				 if (is_object($val)) {
            $val = (array)($val);
        }
        
				//$val['tikutid'] = gettikutid($val['tikuid']);
				$tikuid = $val['tikuid'];
				
					if($tikuid > 0){
						$val['tikutid'] = DB::result_first("SELECT tid FROM ".DB::table('tpexam_tiku')." WHERE id = '$tikuid'");
					}
					
				$answer[] = $val;
			}
			
			$opactives['order'] = 'class="a"';
			
		}
	}
	
	require_once DISCUZ_ROOT.'./source/plugin/tpgao_role/function/common.php';

	$auddit = getreview_auddit($examedid);
	$auddit = (array)$auddit[0];
	$newauddit=array();
	foreach($auddit as $key=>$val){
		$newauddit[$key] = $val;
	}

	$audditdesc = getreview_audditdesc($examedid);
	

	$uid = getuidbyanswerid($examedid);

	$lowcredit = 0;
	if($deductcredits){
		
		$t = 'extcredits'.$teachercredits;
		$usercount = DB::result_first("SELECT $t FROM ".DB::table('common_member_count')." WHERE uid = '$uid'");
		$paperid = DB::result_first("SELECT exam_type FROM ".DB::table('tpexam_examrecord')." WHERE id = '$examedid'");
		require_once DISCUZ_ROOT.'./source/plugin/tpgao_role/function/common.php';
		$score = getallwendascorebypaper($paperid);
		
		if($usercount < $score){
			$lowcredit = 1;
		}
	}
	
	include template("tpgao_role:my_record");

}else{

	$examedid = intval($_POST['examedid']);
	$auddit = json_encode($_POST['auddit']);
	
	$audditdesc = serialize($_POST['audditdesc']);
	$uid = intval($_POST['uid']);
	
	//total
	$total = 0.0;
	foreach ($_POST['auddit'] as &$value) {
	 	 // loop through values 
	 	 $total += $value;
	} 
	
	DB::update('tpexam_examrecord',array('auditscore'=>$total),"id='$examedid'");
	
	//$paperid = DB::result_first("SELECT exam_type FROM ".DB::table('tpexam_examrecord')." WHERE id = '$examedid'");
	$id = DB::result_first("SELECT id FROM ".DB::table('tpexam_role_teacher')." WHERE examedid = '$examedid'");
	if(!$id){
		DB::insert("tpexam_role_teacher",array("uid"=>$uid,
		'examedid'=>$examedid,
		'review_auddit'=>$auddit,
		'review_audditdesc'=>$audditdesc));

	}else{

		DB::update("tpexam_role_teacher",array("uid"=>$uid,
		'examedid'=>$examedid,
		'review_auddit'=>$auddit,
		'review_audditdesc'=>$audditdesc),"id='$id'");
		
	}

	if($deductcredits){
		
		$t = 'extcredits'.$teachercredits;
		$usercount = DB::result_first("SELECT $t FROM ".DB::table('common_member_count')." WHERE uid = '$uid'");
		$paperid = DB::result_first("SELECT exam_type FROM ".DB::table('tpexam_examrecord')." WHERE id = '$examedid'");
		require_once DISCUZ_ROOT.'./source/plugin/tpgao_role/function/common.php';
		$score = getallwendascorebypaper($paperid);
		

		if($usercount > $score){
			updatemembercount($uid, array($t => '-'.$score));//�۳�������
		}
	}
	
	showmessage(lang('plugin/tpgao_role','op_success'));

}

//From: Dism��taobao��com
?>