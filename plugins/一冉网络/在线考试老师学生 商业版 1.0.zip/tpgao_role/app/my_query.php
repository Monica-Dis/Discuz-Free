<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';

global $_G;

if(!submitcheck('submit')){
	
	$opactives['query'] = "class='a'";

	//��ҳ��Ϣ
	$perpage = 15;
	$page = max(1, intval(daddslashes($_GET['page'])));
	$listStart = ($page-1) *$perpage;
	$listEnd = $page*$perpage;
	

	
	
	//�鿴�Ƿ����鵵����
	
	$list=array();
	$config_category = $_G['cache']['plugin']['tpgao_examcategory'];
	$config_role = $_G['cache']['plugin']['tpgao_role'];
	$open_category = $config_category['start'];
	$open_role = $config_role['opencategory'];
	
	$uid = $_G['uid'];
	
	$paperfilter=array();

	
	$query = DB::query("SELECT * FROM ".DB::table('tpexam_examrecord')." order by id desc limit $listStart,$perpage");
	while($data = DB::fetch($query)){
		
			if($open_category && $open_role){
				//��ȡ��ǰ��ʦ��ʹ�õķ���
					if(!paperbelongteacher($data['exam_type'],$uid)){
						continue;
					}
				
			}
		$paperid = $data['exam_type'];
		$username = getuserbyuid($data['uid']);
		$data['username'] = $data['uid'].'('.$username['username'].')';
		$data['company'] = GetVerifyCompany($paperid,$data['uid'],$verifyid);
		$data['name'] = GetVerifyName($paperid,$data['uid'],$verifyid);
		$data['idcard'] = GetVerifyIdcard($paperid,$data['uid'],$verifyid);
		$data['studentid'] = GetVerifyStudentId($paperid,$data['uid'],$verifyid);
		
		$list[]=$data;
	}
	

	//$totalnum = DB::result_first("SELECT COUNT(*) FROM ".DB::table('tpexam_examrecord'));
	$totalnum = count($list);
	$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 
	$multi = multi($totalnum, $perpage, $page, "plugin.php?id=tpgao_role:my",$pagecount);
	
	include template("tpgao_role:my_query");
	
	
}

function paperbelongteacher($pid,$uid){
	
	if($pid > 0 && $uid > 0){
		$all = DB::fetch_all("SELECT * FROM ".DB::table('tpgao_examcategory_paper')." WHERE paperid = '$pid'");
		foreach($all as $key =>$val){
			$teacheridarr = explode(",",$val['map']);
			if(in_array($uid,$teacheridarr))
				return true;
		}
	}
	
	return false;
}
//From: Dism_taobao_com
?>