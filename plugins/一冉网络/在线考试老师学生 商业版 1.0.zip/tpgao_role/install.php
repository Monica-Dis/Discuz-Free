<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');


define('PLUGIN_ACT_ROOT', dirname(__FILE__).'/');


$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_tpexam_role_teacher` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `examedid` int(11) NOT NULL,
  `review_auddit` text NOT NULL,
  `review_audditdesc` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;


EOF;

runquery($sql);

$finish = TRUE;

?>