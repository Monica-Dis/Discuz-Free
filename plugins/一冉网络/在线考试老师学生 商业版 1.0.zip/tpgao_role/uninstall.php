<?php
/*
	[dxtm.net!] (C)2001-2013 Inc.
	BY QQ:155121944  tp
*/


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');


$sql = '';


$sql = <<<EOF

DROP TABLE `pre_tpexam_role_teacher`;

EOF;

runquery($sql);

$finish = TRUE;

?>