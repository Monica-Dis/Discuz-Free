<?php

/**
 * yaoqing_robot For Discuz!X 2.0+
 * ============================================================================
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�ʹ�ã�
 * �������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
 * @package    index
 * @module	   tp_exam 
 * @date	     2013-7-25
 * @author	   gaotianpeng
 * @copyright  Copyright (c) 2012 yaoqing_robot Platform Inc. (http://www.fanzhuce.com)
 */

/*
//--------------Tall us what you think!----------------------------------
*/


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once libfile('lib/GetVerifySetting','plugin/tpgao_verifylogin');
$mode = getVerifyMode();
$vitem = getVerifyItem();
$uid = $_G['uid'];

if(!submitcheck('submit')){
	global $_G;
	$config = array();
	$config = $_G['cache']['plugin']['tpgao_verifylogin'];
	$shuoming = $config['shuoming'];
	$paperid = intval($_GET['paperid']);

	$lang_verify=array('idcard'=>lang('plugin/tp_exam','admin_tuan_verify_idcard'),'student_id'=>lang('plugin/tp_exam','admin_tuan_verify_studentid'),'name'=>lang('plugin/tp_exam','admin_tuan_verify_name'),'company'=>lang('plugin/tp_exam','admin_tuan_verify_belongcompany'));
	
	include template('tpgao_verifylogin:nav');
	
}else{
	
	$idcard = daddslashes($_POST['idcard']);
	$student_id = daddslashes($_POST['student_id']);
	$name = daddslashes($_POST['name']);
	$company = daddslashes($_POST['company']);
	$paperid = intval($_POST['paperid']);
	
	$usritem = array('idcard'=>$idcard,'student_id'=>$student_id,'name'=>$name,'company'=>$company,'reserved1'=>0,'reserved2'=>0,'reserved3'=>0,'reserved4'=>0);
	
	
	$r = setVerifyItem($mode,$vitem,$usritem);
	if($mode == 0){//��֤ģʽ
		if($r > 0){
		
		

		$key = DB::result_first("SELECT  id FROM ".DB::table('tpexam_verifylogin')." WHERE uid = '$uid' and paperid = '$paperid'");
		
		if($key > 0){ //���������֤ʱ��
			DB::update('tpexam_verifylogin',array('lastverifydata'=>TIMESTAMP,'verifyitem'=>$r),"id='$key'");
		}else{
			DB::insert('tpexam_verifylogin',array('lastverifydata'=>TIMESTAMP,
			'uid'=>$uid,
			'paperid'=>$paperid,
			'verifyitem'=>$r));
		}
		
		$exammode = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='opensingleexam'");
		if($exammode){
			dheader("location: plugin.php?id=tpgao_singleexam&paperid=".$paperid);
		}else{
			dheader("location: plugin.php?id=tp_exam:index&mod=exam&item=".$paperid);
		}
		
		/*
		$uid = $_G['uid'];
		$cookie = serialize(array('pid'=>$paperid,'uid'=>$uid));
		
		//dsetcookie("{$paperid}_verify_cookie",$cookie,time() + 86400);
		session_start();
		$_SESSION["{$paperid}_{$uid}_verify_cookie"]= $cookie;

		$opensingleexam = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='opensingleexam'");
		if($opensingleexam){
				//��ʾ��֪

		$_G['cookie']['idcard'] = $idcard;
		$_G['cookie']['student_id'] = $student_id;
		$_G['cookie']['name'] = $name;
		$_G['cookie']['company'] = $company;
		
		dsetcookie('idcard',$idcard);
		dsetcookie('student_id',$student_id);
		dsetcookie('name',$name);
		dsetcookie('company',$company);
		
		//$i = getcookie('idcard');
		//echo 'i='.$i;
		
		header("location: plugin.php?id=tpgao_verifylogin:alert&paperid=$paperid&vid=$r");
			 	//header("location: plugin.php?id=tpgao_singleexam&paperid=$paperid");
		}else{
			header("location: plugin.php?id=tp_exam:index&mod=login&item=$paperid");
		}
		*/
		}else{
			$lang = lang('plugin/tpgao_verifylogin','verify_login_error');
			showmessage($lang,"plugin.php?id=tpgao_verifylogin:index&paperid={$paperid}");
		}
	}else{//��¼ģʽ
		$id = DB::result_first("SELECT id FROM ".DB::table('tpexam_verify_data')." where uid='$uid'"); //���м���Ƿ����и�UID�ļ�¼
		
		//��¼����
		if($id > 0){
			DB::update('tpexam_verify_data',array('idcard'=>$idcard,
			'student_id'=>$student_id,
			'username'=>$name,
			'company'=>$company,
			'belongpaper'=>$paperid),"id='$id'");
		}else{
			$id = DB::insert('tpexam_verify_data',array('idcard'=>$idcard,
			'student_id'=>$student_id,
			'username'=>$name,
			'company'=>$company,
			'uid'=>$uid,
			'belongpaper'=>$paperid),1);
		}

		//��¼����
		$key = DB::result_first("SELECT  id FROM ".DB::table('tpexam_verifylogin')." WHERE uid = '$uid' and paperid = '$paperid'");
		
		if($key > 0){ //���������֤ʱ��
			DB::update('tpexam_verifylogin',array('lastverifydata'=>TIMESTAMP,'verifyitem'=>$id),"id='$key'");
		}else{
			DB::insert('tpexam_verifylogin',array('lastverifydata'=>TIMESTAMP,
			'uid'=>$uid,
			'paperid'=>$paperid,
			'verifyitem'=>$id
			));
		}
		
		if(checkmobile()){
			dheader("location: plugin.php?id=tpgao_m:m&mod=exam&item=".$paperid."&formhash=".formhash());
		}
		
		$exammode = DB::result_first("SELECT svalue FROM ".DB::table('tpexam_setting')." where skey='opensingleexam'");
		if($exammode){
			dheader("location: plugin.php?id=tpgao_singleexam&paperid=".$paperid);
		}else{
			dheader("location: plugin.php?id=tp_exam:index&mod=exam&item=".$paperid);
		}

	}

}
//From: Dism��taobao��com
?>