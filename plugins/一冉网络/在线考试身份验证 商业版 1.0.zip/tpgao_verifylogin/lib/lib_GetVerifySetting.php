<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-09-01
 */

/*
//--------------Tall us what you think!----------------------------------
*/

if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}


function getVerifySetting()
{
	return $setting;
}

function getVerifyMode()
{
	$vmode = C::t('#tpgao_verifylogin#tpexam_verify#')->getverifymode();
	return $vmode;
}

function getVerifyItem()
{
	$item = array('idcard'=>0,'student_id'=>0,'name'=>0,'company'=>0,'reserved1'=>0,'reserved2'=>0,'reserved3'=>0,'reserved4'=>0);
	
	$v = C::t('#tpgao_verifylogin#tpexam_verify#')->getverifyitem();
	
	if($v['student_id']) $item['student_id'] = 1;
	if($v['idcard']) $item['idcard'] = 1;
	if($v['company']) $item['company'] = 1;
	if($v['name']) $item['name'] = 1;
	
	
	return $item;
}


function setVerifyItem($mode,$verifyItem,$userVerify)
{
	
	foreach($verifyItem as $key=>$index){
		
		if($index){
			
			$arr[$key] = $userVerify[$key];
			
		}
	}
	
	return verifyItem($mode,$arr);
}

function verifyItem($mode,$arr){
	
	if($mode){ //��¼
		addrecord($arr);
	}else{
		
		return verifyrecord($arr);
	}
	
}

function addrecord($arr){
	$arr1=array();
	foreach($arr as $key=>$index){
		if($key == 'name') $key = 'username';
		$arr1[$key] = $index;
	}
	
	DB::insert('tpexam_verify_data',$arr1);
}

function verifyrecord($arr){
	
	$where = ' where ';
	$arr1=array();
	$in = 1;
	foreach($arr as $key=>$index){
		if($key == 'name') $key = 'username';
		$arr1[$key] = $index;
		
		$where .= $key ."= '".$index ."'";
		
		if( $in < count($arr)) $where .=" and ";
		
		$in++;
	}

	$sql = DB::query("select * from ".DB::table('tpexam_verify_data').$where);
	
	if($d = DB::fetch($sql)){
		return $d['id'];
	}
	
	return 0;
}

function getPaperVerify($paperid){
	return DB::result_first("SELECT needlogin FROM ".DB::table('tpexam_paper')." where id='$paperid'");	
}
//From: Dism_taobao_com
?>