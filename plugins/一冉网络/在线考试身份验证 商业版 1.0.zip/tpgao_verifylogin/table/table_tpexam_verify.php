<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-09-01
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_tpexam_verify extends discuz_table
{

	public function __construct() {

		$this->_table = 'tpexam_verify';
		$this->_pk    = 'id';

		parent::__construct();
	}

	public function getsetverify()
	{
		
	}
	
	public function getverifymode()
	{
		return DB::result_first("SELECT verify_mode FROM %t WHERE id = 1",array($this->_table),'id');
	}
	
	public function getverifyitem()
	{
		return DB::fetch_first("SELECT * FROM %t WHERE id = 1",array($this->_table),'id');
	}
}
//From: Dism_taobao_com
?>