<?php


if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF


CREATE TABLE IF NOT EXISTS `pre_tpexam_verifylogin` (
  `id` int(11) NOT NULL auto_increment,
  `uid` int(11) NOT NULL,
  `paperid` int(11) NOT NULL,
  `lastverifydata` int(11) NOT NULL,
  `verifyitem` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  ;

EOF;

runquery($sql);

$finish = TRUE;

?>