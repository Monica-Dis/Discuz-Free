<?php 
/**
 * tpgao_verifylogin For Discuz!X 2.0+
 * ============================================================================
 * �ⲻ��һ��������������ֻ���ڲ�������ҵĿ�ĵ�ǰ���¶Գ����������޸ĺ�ʹ�ã�
 * �������Գ���������κ���ʽ�κ�Ŀ�ĵ��ٷ�����
 * ============================================================================
 * @package    index
 * @module	   tpgao_singleexam 
 * @date	     2015-7-25
 * @author	   gaotianpeng
 * @copyright  Copyright (c) 2012 tpgao_singleexam Platform Inc. (http://www.fanzhuce.com)
 */

/*
//--------------Tall us what you think!----------------------------------
*/

if (!defined('IN_DISCUZ')  ) {
    exit('Access Denied');
}

if(!submitcheck('submit')){

	$paperid = intval($_GET['paperid']);
	$vid = intval($_GET['vid']);
	
	require_once libfile('lib/GetVerifySetting','plugin/tpgao_verifylogin');
	$vitem = getVerifyItem();
	$lang_verify=array('idcard'=>lang('plugin/tp_exam','admin_tuan_verify_idcard'),'student_id'=>lang('plugin/tp_exam','admin_tuan_verify_studentid'),'name'=>lang('plugin/tp_exam','admin_tuan_verify_name'),'company'=>lang('plugin/tp_exam','admin_tuan_verify_belongcompany'));

	$idcard = daddslashes($_G['cookie']['idcard']);
	$student_id = daddslashes($_G['cookie']['student_id']);
	$name = daddslashes($_G['cookie']['name']);
	$company = daddslashes($_G['cookie']['company']);

	global $_G;
	$config = array();
	$config = $_G['cache']['plugin']['tpgao_verifylogin'];
	$xuzhi = $config['xuzhi'];
	
	include template('tpgao_verifylogin:alert');
	
}
//From: Dism_taobao_com
?>