<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

		$datatype =  intval($_GET['datatype']);
		$dataid =  intval($_GET['dataid']);
		$tikuid =  intval($_GET['tikuid']);

		if(!empty($datatype) && !empty($dataid) && $tikuid > 0){
				

				global $_G;
				$config = array();
				$config = $_G['cache']['plugin']['tpgao_questionsyn'];
				$bbs = $config['bbs'];
				$credit_num = $config['credit_num'];
				$credit_type = $config['credit_type'];

				$parser_credit_num = $config['parser_credit_num'];
				$parser_credit_type = $config['parser_credit_type'];
	
				$table = GetTable($datatype);

				$tid = GetTid($tikuid);
				

				if(!empty($credit_type)){
					$credit_type = 'extcredits'.$credit_type;
					$skey = DB::result_first("SELECT $credit_type FROM ".DB::table('common_member_count')." where uid='$_G[uid]'");
				}
				
				if($credit_num >0){
					if($credit_num > 0 && $skey >= $credit_num){
						updatemembercount($_G['uid'], array($credit_type => -$credit_num));
					}
					else {
						echo -1;
						die();
					}
				}

				if($tid==0){  //�½�����
					require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/syn.inc.php";

					$tiKu = GetTiku($table,$dataid);
					
					$thread_subject = $tiKu['ask'];
					//�������Ҫ���α���
					$thread_subject = preg_replace("/#([0-9]+)/","_____",$thread_subject,1);
					while(preg_match( '/#\d+/', $thread_subject, $matches)){
						$thread_subject = preg_replace("/#([0-9]+)/","_____",$thread_subject,1);
					}
	
					$thread_message = GetTiKuString($datatype,$tiKu);
					
					
					$js = '<script>function viewparser(etype,eid){
						showWindow("showMsgBox", "plugin.php?id=tpgao_questionsyn:showMsg&timutype="+etype+"&item="+eid+"&credit='.$parser_credit_num.'&mod=sh", "get", 0);	
					}</script>';
					
					$template = $thread_message;
					
//					echo $template;
					$t_arr = postForum($_G['uid'],$_G['username'],$bbs ,TIMESTAMP,$thread_subject,$template.$message,$_G['clientip'],'',$js);
					$tid = $t_arr['tid'];

					DB::update('tpexam_tiku',array('bindid' => $t_arr['tid']),"id=$tikuid");
					
					
					echo $tid;
					exit;
				}
				else
					echo $tid;
				

	}
	
	function GetTid($tikuid){
		$tid = 0;
		$query = DB::query("SELECT * FROM ".DB::table('tpexam_tiku')." where id = '$tikuid'");
		while($data = DB::fetch($query))
		{
			$tid = $data['bindid'];
		}
		
		return $tid;
	}
	
	function GetTiku($table,$id){
		$query = DB::query("SELECT * FROM ".DB::table($table)." where id = '$id'");
		if($data = DB::fetch($query))
		{
			return $data;
		}
	}
	
	function GetTiKuString($datatype,$tiKu){
		global $parser_credit_num,$tikuid;
		
		if($datatype==1) {
			
			$admin_pub_type1 = lang('plugin/tp_exam','admin_pub_type1');
			$timu = lang('plugin/tp_exam','timu');
			$exam_option = lang('plugin/tp_exam','exam_option');
			$exam_timu_corrent = lang('plugin/tp_exam','exam_timu_corrent');
			
			$type = '['.$admin_pub_type1.']<br> '.$timu.' ';
			
			$message = $type.$tiKu['ask'].'<br>'.'<br>';
			
			//����ͼƬ
			if($tiKu['image'] != ''){
				$img = '<img src="'.$tiKu['image'].'">';
				$message .= $img;
			}
		
			$exam_option = '<br>'.
			'A.'.$tiKu['option1'].'<br>'.
			'B.'.$tiKu['option2'].'<br>'.
			'C.'.$tiKu['option3'].'<br>'.
			'D.'.$tiKu['option4'].'<br>';
			
			if($tiKu['option5'] != ''){
				$exam_option .=	'E.'.$tiKu['option5'].'<br>';
			}
			if($tiKu['option6'] != ''){
				$exam_option .=	'F.'.$tiKu['option6'].'<br>';
			}
			if($tiKu['option7'] != ''){
				$exam_option .=	'G.'.$tiKu['option7'].'<br>';
			}
			
			$message .= $exam_option.'<br>';
			$message .= $exam_timu_corrent;
			$message .= $tiKu['answer'].'<br>';

			if($parser_credit_num>0){
				$admin_pubexam_answer_parser = lang('plugin/tpgao_questionsyn','admin_pubexam_answer_parser');
				
				$btn = '<div id="parserbtn"><input class="parserbtn"  onclick="viewparser(1,'.$tiKu['id'].');" type="button" name="parserbtn" value="'.$admin_pubexam_answer_parser.'" style="height: 23px"></div>';
				$message .= $btn .'<br>';
			}
			else{
				$message .= $tiKu['answer_parser'].'<br>';
			}
		}
		else if($datatype==2){
			$admin_pub_type2 = lang('plugin/tp_exam','admin_pub_type2');
			$exam_option = lang('plugin/tp_exam','exam_option');
			$exam_timu_corrent = lang('plugin/tp_exam','exam_timu_corrent');
			$timu = lang('plugin/tp_exam','timu');
				
			$type = '['.$admin_pub_type2.']<br> '.$timu.' ';
			$message = $type.$tiKu['ask'].'<br>';

			//����ͼƬ
			if($tiKu['image'] != ''){
				$img = '<img src="'.$tiKu['image'].'">';
				$message .= $img;
			}
			
			$exam_option = '<br>'.
			'A.'.$tiKu['option1'].'<br>'.
			'B.'.$tiKu['option2'].'<br>'.
			'C.'.$tiKu['option3'].'<br>'.
			'D.'.$tiKu['option4'].'<br>'.
			'E.'.$tiKu['option5'].'<br>';
			
			if($tiKu['option6'] != '')
			$exam_option .= 
			'F.'.$tiKu['option6'].'<br>'.
			'G.'.$tiKu['option7'].'<br>';
			
			$message .= $exam_option.'<br>';
			$message .= $exam_timu_corrent.'<br>';
			$message .= $tiKu['answer1'].$tiKu['answer2'].$tiKu['answer3'].$tiKu['answer4'].$tiKu['answer5'].$tiKu['answer6'].$tiKu['answer7'].'<br>';
			
			if($parser_credit_num>0){
				$admin_pubexam_answer_parser = lang('plugin/tpgao_questionsyn','admin_pubexam_answer_parser');
				
				$btn = '<div id="parserbtn"><input class="parserbtn"  onclick="viewparser(2,'.$tiKu['id'].');" type="button" name="parserbtn" value="'.$admin_pubexam_answer_parser.'" style="height: 23px"></div>';
				$message .= $btn .'<br>';
			}
			else{
				$message .= $tiKu['answer_parser'].'<br>';
			}
			
		}
		else if($datatype==3){
			$exam_option = lang('plugin/tp_exam','exam_option');
			$exam_right = lang('plugin/tp_exam','exam_right');
			$exam_wrong = lang('plugin/tp_exam','exam_wrong');
			$exam_timu_corrent = lang('plugin/tp_exam','exam_timu_corrent');
						
			$message = $tiKu['ask'].'<br>'.'<br>';
			//����ͼƬ
			if($tiKu['image'] != ''){
				$img = '<img src="'.$tiKu['image'].'">';
				$message .= $img;
			}
			
			$message .= $exam_option.'<br>'.
			$exam_right.'<br>'.
			$exam_wrong.'<br>';
			
			
			$message .= $exam_timu_corrent.'<br>';
			if($tiKu['answer']==1)
				$message .= $exam_right.'<br>';
			else
				$message .= $exam_wrong.'<br>';
			
			if($parser_credit_num>0){
				$admin_pubexam_answer_parser = lang('plugin/tpgao_questionsyn','admin_pubexam_answer_parser');
				
				$btn = '<div id="parserbtn"><input class="parserbtn"  onclick="viewparser(3,'.$tiKu['id'].');" type="button" name="parserbtn" value="'.$admin_pubexam_answer_parser.'" style="height: 23px"></div>';
				$message .= $btn .'<br>';
			}
			else{
				$message .= $tiKu['answer_parser'].'<br>';
			}
			
		}
		else if($datatype==4){
			$exam_timu_corrent = lang('plugin/tp_exam','exam_timu_corrent');
			$message = $tiKu['ask'].'<br>'.'<br>';

			//����ͼƬ
			if($tiKu['image'] != ''){
				$img = '<img src="'.$tiKu['image'].'">';
				$message .= $img;
			}
			
			$message .= $exam_timu_corrent.'<br>';
			$message .= $tiKu['answer'].'<br>';

			if($parser_credit_num>0){
				$admin_pubexam_answer_parser = lang('plugin/tpgao_questionsyn','admin_pubexam_answer_parser');
				
				$btn = '<div id="parserbtn"><input class="parserbtn"  onclick="viewparser(4,'.$tiKu['id'].');" type="button" name="parserbtn" value="'.$admin_pubexam_answer_parser.'" style="height: 23px"></div>';
				$message .= $btn .'<br>';
			}
			else{
				$message .= $tiKu['answer_parser'].'<br>';
			}
			
			
			//�������Ҫ���α���
			$message = preg_replace("/#([0-9]+)/","_____",$message,1);
			while(preg_match( '/#\d+/', $message, $matches)){
				$message = preg_replace("/#([0-9]+)/","_____",$message,1);
			}
			
		}
		else if($datatype==5){
			$exam_timu_corrent = lang('plugin/tp_exam','exam_timu_corrent');
			$message = $tiKu['ask'].'<br>'.'<br>';

			//����ͼƬ
			if($tiKu['image'] != ''){
				$img = '<img src="'.$tiKu['image'].'">';
				$message .= $img;
			}
			
			$message .= $exam_timu_corrent.'<br>';
			$message .= $tiKu['answer'].'<br>';

			if($parser_credit_num>0){
				$admin_pubexam_answer_parser = lang('plugin/tpgao_questionsyn','admin_pubexam_answer_parser');
				
				$btn = '<div id="parserbtn"><input class="parserbtn"  onclick="viewparser(5,'.$tiKu['id'].');" type="button" name="parserbtn" value="'.$admin_pubexam_answer_parser.'" style="height: 23px"></div>';
				$message .= $btn .'<br>';
			}
			else{
				$message .= $tiKu['answer_parser'].'<br>';
			}
			
		}
		

		$link = GetSourcePaper($tikuid);

		return $message . $link;
		
	}
	
	function GetTable($datatype){
		
		if($datatype==1) 
				return 'tpexam_tiku_danxuan';
		else if($datatype==2) 
				return 'tpexam_tiku_duoxuan';
		else if($datatype==3) 
				return 'tpexam_tiku_panduan';
		else if($datatype==4) 
				return 'tpexam_tiku_tiankong';
		else if($datatype==5) 
				return 'tpexam_tiku_wenda';
	}
	
	function GetSourcePaper($tikuid)
	{
		$paperid = DB::result_first("SELECT paperid FROM ".DB::table('tpexam_tiku')." WHERE id = '$tikuid'");
		if($paperid > 0){
			$str1 = '&#x6765;&#x81EA;&#x300A;';
			$str2 = '&#x300B;&#x8BD5;&#x5377;';
			
			$name = DB::result_first("SELECT name FROM ".DB::table('tpexam_paper')." WHERE id = '$paperid'");
			
			require_once libfile('function/common','plugin/tp_exam');
			$link = getexampaperlink($paperid);
			
			return $str = '[url='.$link.']'.$str1 . $name . $str2 .'[/url]<br><br>';
		}
	}
	
?>