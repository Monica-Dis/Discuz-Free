<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/tp_exam/include/tp_exam.func.php';



if(!submitcheck('submit') ) {
	
	showformheader("plugins&operation=config&do={$pluginid}&identifier=tpgao_questionsyn&pmod=admin_tid", 'order_submit');
	showhiddenfields(array('tid'=>$_G['gp_tid']));
	showtableheader();

	$admin_exam_timulist_type = lang('plugin/tp_exam', 'admin_exam_timulist_type');
	$timu = lang('plugin/tp_exam', 'timu');
	$admin_exam_timulist_paper = lang('plugin/tp_exam', 'admin_exam_timulist_paper');
	$admin_exam_timulist_score = lang('plugin/tp_exam', 'admin_exam_timulist_score');
	$admin_exam_timulist_pubtime = lang('plugin/tp_exam', 'admin_exam_timulist_pubtime');
	$admin_exam_timulist_pubname = lang('plugin/tp_exam', 'admin_exam_timulist_pubname');
	$admin_common_op = lang('plugin/tp_exam', 'admin_common_op');
	$admin_common_delete = lang('plugin/tp_exam', 'admin_common_delete');
	$admin_parser_tid = lang('plugin/tpgao_questionsyn', 'admin_parser_tid');
	$admin_parser_tid_all = lang('plugin/tpgao_questionsyn', 'admin_parser_tid_all');
	$admin_parser_tid_bind = lang('plugin/tpgao_questionsyn', 'admin_parser_tid_bind');
	
	$admin_pub_type1 = lang('plugin/tp_exam', 'admin_pub_type1');
	$admin_pub_type2 = lang('plugin/tp_exam', 'admin_pub_type2');
	$admin_pub_type3 = lang('plugin/tp_exam', 'admin_pub_type3');
	$admin_pub_type4 = lang('plugin/tp_exam', 'admin_pub_type4');
	$admin_pub_type5 = lang('plugin/tp_exam', 'admin_pub_type5');
	$admin_pub_type6 = lang('plugin/tp_exam', 'admin_pub_type6');
	$admin_pub_type7 = lang('plugin/tp_exam', 'admin_pub_type7');
	
	$type_arr=array($admin_pub_type1,$admin_pub_type2,$admin_pub_type3,$admin_pub_type4,$admin_pub_type5,$admin_pub_type6,$admin_pub_type7);
	
	showsubtitle(array('ID',$admin_exam_timulist_type,$timu,$admin_exam_timulist_paper,$admin_exam_timulist_score,$admin_exam_timulist_pubtime,$admin_parser_tid_bind));
	
	$tiKu = GetAllTypeTiKu();
	$bind = C::t('#tp_exam#tp_exam_tiku')->getallbind();
	


	//��ҳ��Ϣ��ʼ
	$perpage = 15;
	$page = max(1, intval(daddslashes($_GET['page'])));
	$listStart = ($page-1) *$perpage;
	$listEnd = $page*$perpage;
	
	$where = '';
	$totalnum = count($tiKu);

	$pagecount = $totalnum ? (($totalnum < $perpage) ? 1 : (($totalnum % $perpage) ? ((int)($totalnum / $perpage) + 1) : ($totalnum / $perpage))) : 0; 

	$multi = multi($totalnum, $perpage, $page, ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tpgao_questionsyn&pmod=admin_tid",$pagecount);
	
	//GetPageList($tiKu,$totalnum, $listStart, $listEnd);
	
	foreach($bind as $key=>$row){
		$valarr = array();
		$valarr[] = "<input type='checkbox' name='delete[]' value='$row[id]'/>[ID:$row[id]]";
		$valarr[] = GetTypeDesc($row['tid'],$type_arr);
		$valarr[] = cutstr($row['subject'],30,"...");
		$valarr[] = GetPaperName($row['paperid']);
		$valarr[] = $row['score'];
		$valarr[] = date('Y-m-d G:i:s',$row['data']);
		$valarr[] = $row['bindid'];
		//$valarr[] = "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do={$pluginid}&identifier=tpgao_questionsyn&pmod=admin_tid&unbind=".$row['id']."&type=".$row['type']."\">".$admin_parser_tid."</a>";
		showtablerow('id="td_'.$row['id'].'"', array('class="td45" style="width:120px;"','class="td35"', 'class="td35"','class="td35"','',''), $valarr);
	}
	showsubmit('submit', 'submit', 'del', '', $multi);
	
	showtablefooter();
	showformfooter();/*Dism_taobao-com*/
}else{
	
	$delete = daddslashes($_GET['delete']);
	$type = daddslashes($_GET['type']);
	
	foreach($delete as $key=>$val){
		
		DB::update('tpexam_tiku',array('bindid'=>0),"id=$val");
		
	}
	/*
	DB::update('tpexam_tiku_danxuan',array('tid'=>0));
	DB::update('tpexam_tiku_duoxuan', array('tid'=>0));
	DB::update('tpexam_tiku_panduan', array('tid'=>0));
	DB::update('tpexam_tiku_wenda', array('tid'=>0));
	DB::update('tpexam_tiku_tiankong', array('tid'=>0));
	*/
	cpmsg(lang('plugin/tp_exam', 'admin_common_success'), 'action=plugins&operation=config&do=$do&identifier=tpgao_questionsyn&pmod=admin_tid', 'succeed');
}


function GetTypeDesc($type,$type_arr)
{
	switch($type)
	{
		case 1:
			return $type_arr[0];
		break;
		case 2:
			return $type_arr[1];
		break;
		case 3:
			return $type_arr[2];
		break;
		case 4:
			return $type_arr[3];
		break;
		case 5:
			return $type_arr[4];
		break;
		case 6:
			return $type_arr[5];
		case 7:
			return $type_arr[6];
	}
}
//From: dis'.'m.tao'.'bao.com
?>