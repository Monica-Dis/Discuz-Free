<?php
/**

 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

	$formhash = daddslashes($_GET['formhash']);
	$timutype = daddslashes($_GET['timutype']);
	$item = daddslashes($_GET['item']);
		
	if(formhash()==$formhash){
		
		global $_G;
		$config = array();
		$config = $_G['cache']['plugin']['tpgao_questionsyn'];
		$parser_credit_num = $config['parser_credit_num'];
		$parser_credit_type = $config['parser_credit_type'];
		
		if($parser_credit_num > 0 && !empty($parser_credit_type) && $_G['uid'] > 0){
			
			$credit_type = 'extcredits'.$parser_credit_type;
			$skey = DB::result_first("SELECT $credit_type FROM ".DB::table('common_member_count')." where uid='$_G[uid]'");
			
			if($skey >= $parser_credit_num && $_G['uid'] > 0){
				
				$admin_parser_success = lang('plugin/tpgao_questionsyn','admin_parser_success');
				updatemembercount($_G['uid'], array($credit_type => -$parser_credit_num));
								
				$answer = GetAnswer($timutype,$item);
				echo $answer;
				exit;
			}
			else
			{
				$low_credit_tip = lang('plugin/tpgao_questionsyn','low_credit_tip');
				showmessage($low_credit_tip,null,array(), array('alert' => 'right'));
			}
		}
		
			
	}
	
	echo 'null';

	function GetAnswer($type,$item){
			switch($type)
			{
				case '1':	$table_name = 'tpexam_tiku_danxuan';break;
				case '2':	$table_name = 'tpexam_tiku_duoxuan';break;
				case '3':$table_name = 'tpexam_tiku_panduan';break;
				case '4':$table_name = 'tpexam_tiku_tiankong';break;
				case '5':$table_name = 'tpexam_tiku_wenda';break;
			}
	
		require_once DISCUZ_ROOT."./source/plugin/tp_exam/include/tpexam_exam.func.php";
		
		$parser = GetAnswerParser($table_name,$item);
		
		return $parser;
	}
//From: dis'.'m.tao'.'bao.com
?>