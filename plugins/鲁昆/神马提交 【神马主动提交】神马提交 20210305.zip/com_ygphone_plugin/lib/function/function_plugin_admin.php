<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once libfile('function/common_cpcore','plugin/com_ygphone_plugin/lib');
function pluginAdmin(){
    initCommonYg();
    if (!submitcheck('admin_main')){
     defaultAdminShow();
    }
}

function defaultAdminShow(){
    global $_YG;
    getAllConfig();
    $ygphonePlugin=array(
        'baidu'=>array(
            'name'=>lang($_YG['lang'],'baidu_submit_name'),
            'identify'=>'com_ygphone_plugin_baidu_submit',
            'rid'=>90510
        ),
        'bing'=>array(
        'name'=>lang($_YG['lang'],'bing_submit_name'),
        'identify'=>'com_ygphone_plugin_bing_submit',
            'rid'=>90518
    ),
        'sm'=>array(
            'name'=>lang($_YG['lang'],'sm_submit_name'),
            'identify'=>'com_ygphone_plugin_sm_submit',
            'rid'=>90515
        ),
        'qh'=>array(
            'name'=>lang($_YG['lang'],'qh_submit_name'),
            'identify'=>'com_ygphone_plugin_360_submit',
            'rid'=>90479
        )
    );
    $goInstall=lang($_YG['lang'],'go_install');
    $settingName=lang($_YG['lang'],'setting_name');
    showtableheader(lang($_YG['lang'],'install_detail_header'), 'tb tb2 fixpadding');
        showtablerow('', array('class="vtop td24 lineheight"', 'class="td24"'), array(
            '',
            lang($_YG['lang'],'plugin_name_header'), lang($_YG['lang'],'plugin_status_header'),
            lang($_YG['lang'],'operate_header')));
    foreach ($ygphonePlugin as $id=>$item){
        $logUrl='https://dism.taobao.com?_'.$item['identify'];
        $pmod=$id.'_submit_setting';
        $cpmsgurl = ADMINSCRIPT.'?action=plugins&operation=config&identifier=' . $item['identify'] . '&pmod=' . $pmod;
        if (empty($_YG['config']['submit'][$id])){
         include_once libfile('function/ini','plugin/'.$item['identify'].'/lib');
         if (intval($ygphone_ini[$id])<10){
             $download="https://dism.taobao.com/plugins/".$item['identify'].'.'.$item['rid'].'.'.'html';
             showtablerow('', array('class="vtop td24 lineheight"', 'class="td24"'), array(
                 "<img src=\"$logUrl\" "."onerror=\"this.src='static/image/admincp/plugin_logo.png';this.onerror=null\" width=\"60\" height=\"60\" align=\"left\">",
                 $item['name'], lang($_YG['lang'],'no_install'),
             "<a target='_blank' style='font-size: 20px;color: red' href=\"$download\">$goInstall</a>"));
         }else{

             showtablerow('', array('class="vtop td24 lineheight"', 'class="td24"'), array(
                 "<img src=\"$logUrl\" "."onerror=\"this.src='static/image/admincp/plugin_logo.png';this.onerror=null\" width=\"60\" height=\"60\" align=\"left\">",
                 $item['name'], lang($_YG['lang'],'already_install'),  "<a href=\"$cpmsgurl\" style=\"color: #00FFFF;font-size: 14px\">$settingName</a>"));
         }
     }else{

         showtablerow('', array('class="vtop td24 lineheight"', 'class="td24"'), array(
             "<img src=\"$logUrl\" "."onerror=\"this.src='static/image/admincp/plugin_logo.png';this.onerror=null\" width=\"60\" height=\"60\" align=\"left\">",
             $item['name'], lang($_YG['lang'],'already_open'),  "<a href=\"$cpmsgurl\" style=\"color: #00FFFF;font-size: 14px\">$settingName</a>"));
     }

    }
    showtablefooter(); /*dism��taobao��com*/
}