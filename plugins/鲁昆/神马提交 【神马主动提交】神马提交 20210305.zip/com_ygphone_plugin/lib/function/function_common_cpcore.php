<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
function initCommonYg(){
    global $_YG,$_G;
    $_YG=array();
    $_YG['version']=20210304;
    $_YG['suf']=array(
        'baidu',
        'qh',
        'sm',
        'bing',);
    $_YG['cache']=DISCUZ_ROOT.'./data/sysdata/cache_com_ygphone_plugin.php';
    $_YG['js_code_file']=DISCUZ_ROOT.'./source/plugin/com_ygphone_plugin/template/js_code.htm';
    $_YG['reqparam']=$_GET;
    $_YG['identifier']=$_YG['reqparam']['identifier'];
    $_YG['pmod']=$_YG['reqparam']['pmod'];
    $_YG['mpurl'] = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=" . $_YG['identifier'] . '&pmod=' . $_YG['pmod'];
    $_YG['action'] = 'plugins&operation=config&do=' . $pluginid . '&identifier=' . $_YG['identifier'] . '&pmod=' . $_YG['pmod'];
    $_YG['cpmsgurl'] = 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $_YG['identifier'] . '&pmod=' . $_YG['pmod'];
    $_YG['lang'] = 'plugin/com_ygphone_plugin';
    $_YG['plang'] = 'plugin/'.$_YG['identifier'];
    $_YG['website']=trim($_G['siteurl'],'/');
    $pmodArr=explode('_',$_YG['pmod']);
    $_YG['id']=$pmodArr[0];
    if (empty($_YG['id'])){
        $_YG['id']='ygphone';
    }
    $_YG['type']=$pmodArr[1];
    if (empty($_YG['type'])){
        $_YG['type']='plugin';
    }
    $_YG['pmodtype']=end($pmodArr);

}
function initCpCoreYg(){
    initCommonYg();
    global $_YG;
    $_YG['setting']=getConfig($_YG['id'],$_YG['type']);
    $_YG['db']=C::t('#com_ygphone_plugin#ygphone');
    $_YG['recordcss'] = $_YG['website'].'/source/plugin/com_ygphone_plugin/template/record.css';
    $_YG['categories']=DB::fetch_all("SELECT `catid`,`catname` FROM %t", array('portal_category'));
}

/**
 * @param $id
 * @param $type
 * @return array
 */
function getConfig($id,$type){
    global $_YG;
    include $_YG['cache'];
    $setting=array();
    switch ($type){
        case 'plugin':
            $setting=$ygphone['config'][$type];
            break;
        default:
            $setting['plugin']=$ygphone['config']['plugin'];
            $setting[$id]=$ygphone['config'][$type][$id];
    }
    return  $setting;
}

function getAllConfig(){
    global $_YG;
    include $_YG['cache'];
    $_YG['config']=$ygphone['config'];
    return 0;
}

/**
 * @param $perpage
 * @return int
 */
function checkPerpage($perpage)
{
    $perpage = abs(intval($perpage));
    if (empty($perpage)) {
        return 20;
    }
    if ($perpage > 200) {
        return 200;
    }
    return $perpage;
}

function writeToYgphoneCache($config,$id=null,$type=null){
    if (empty($config)){
        return 0;
    }
    global $_YG;
    if (empty($id)){
        $id=$_YG['id'];
    }
    if (empty($type)){
        $type=$_YG['type'];
    }
    require_once libfile('function/cache');
    $ygphone=array();
    include $_YG['cache'];
    switch ($id){
        case 'ygphone':
            $ygphone['config']['plugin']=$config;
            break;
        default:$ygphone['config'][$type][$id]=$config;
    }
    $cacheArr = '';
    $cacheArr .= "\$ygphone = " . arrayeval($ygphone) . ";\n";
    writetocache('com_ygphone_plugin', $cacheArr);
    return 0;

}

function writeToAllCache($config){
    if (!is_array($config)){
        return 0;
    }
    require_once libfile('function/cache');
    $cacheArr = '';
    $cacheArr .= "\$ygphone = " . arrayeval($config) . ";\n";
    writetocache('com_ygphone_plugin', $cacheArr);
    return 0;
}
function unsetModulesFromCache($id,$type){
    global $_YG;
    if (!in_array($id,$_YG['suf'])){
        return 0;
    }
    include $_YG['cache'];
    unset($ygphone['config'][$type][$id]);
    return writeToAllCache($ygphone);
}


function getNum($id=null,$pmodType=null){
    global $_YG;
    if (empty($id)){
        $id=$_YG['id'];
    }
    if (empty($pmodType)){
        $pmodType=$_YG['pmodtype'];
    }
    $_YG['num']=intval($_YG['db']->queryNumById($id,$pmodType));
    return 0;
}

function getPerpageData($perpage,$page,$id=null,$pmodType=null){
    global $_YG;
    if (empty($id)){
        $id=$_YG['id'];
    }
    if (empty($pmodType)){
        $pmodType=$_YG['pmodtype'];
    }
    $_YG['perdata']=$_YG['db']->queryPerData($id,$pmodType,$perpage,$page);

}

/**
 * @param $int
 * @return int
 */
function checkIntBool($int)
{
    if (empty($int)) {
        return 0;
    }
    return 1;
}

function checkStr($str){
    $str=trim($str);
    if (empty($str)){
        return '';
    }
    return $str;
}

function checkCidSetting($cids)
{
    if (empty($cids)) {
        return '';
    }
    if (is_array($cids)) {
        return implode(',', $cids);
    }
    $cids = trim($cids);
    return $cids;
}
/**
 * @param $rate
 * @return int
 */
function checkRate($rate)
{
    if (is_null($rate)) {
        $rate = 3;
    }
    $rate = abs(intval($rate));
    if ($rate > 365) {
        $rate = 365;
    }
    return $rate;
}

/**
 * @param $forms
 * @return string
 */
function checkCids($cids)
{
    $cids = trim($cids);
    if (empty($cids)) {
        return '';
    }
    return $cids;
}




/**
 * @return string
 */
function forumMultipleHeader()
{
    $fsh = '<select name="forums[]" multiple="multiple" size="10" class="ps">';
    return $fsh;
}

/**
 * @return string
 */
function categoryMultipleHeader()
{
    $csh = '<select name="categories[]" multiple="multiple" size="10" class="ps">';
    return $csh;
}

/**
 * @return string
 */
function multipleFooter()
{
    $fsf = '</select>';
    return $fsf;
}

function categoryMultipleBody($selectCategories)
{
    global $_YG;
    if (gettype($selectCategories) == 'string') {
        $selectCategories = explode(',', $selectCategories);
    }
    $s = '';
    $catCount = count($_YG['categories']);
    for ($i = 0; $i < $catCount; $i++) {
        $selected = '';
        if (in_array($_YG['categories'][$i]['catid'], $selectCategories)) {
            $selected = ' selected';
        }
        $s .= '<option value="'
            . $_YG['categories'][$i]['catid']
            . '" '
            . $selected
            . '>'
            . $_YG['categories'][$i]['catname']
            . '</option>';
    }
    return $s;
}

/**
 * @param $selectForums
 * @return string
 */
function forumMultipleBody($selectForums)
{
    if (gettype($selectForums) == 'string') {
        $selectForums = explode(',', $selectForums);
    }
    loadcache('forums');
    global $_G;
    $s = '';
    $forms = $_G['cache']['forums'];
    foreach ($forms as $fid => $form) {
        $selected = '';
        if (in_array($fid, $selectForums)) {
            $selected = ' selected';
        }
        $type = $form['type'];
        switch ($type) {
            case 'group':
                $s .= '<optgroup label="--'
                    . $form['name']
                    . '">';
                break;
            case 'forum':
                $s .= '<option value="'
                    . $form['fid']
                    . '" '
                    . $selected
                    . '>'
                    . $form['name']
                    . '</option>';
                break;
            case 'sub':
                $s .= '<option value="'
                    . $form['fid']
                    . '" '
                    . $selected
                    . '>&nbsp;&nbsp;&nbsp;'
                    . $form['name']
                    . '</option>';
                break;
        }
    }
    return $s;
}

/**
 * @param $selectForums
 * @return string
 */
function forumMultiple($selectForums)
{
    return forumMultipleHeader() . forumMultipleBody($selectForums) . multipleFooter();
}

/**
 * @param $selectCategories
 * @return string
 */
function categoryMultiple($selectCategories)
{
    return categoryMultipleHeader() . categoryMultipleBody($selectCategories) . multipleFooter();
}