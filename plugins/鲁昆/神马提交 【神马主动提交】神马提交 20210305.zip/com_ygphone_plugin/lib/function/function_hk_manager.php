<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function initCommonYg(){
    global $_YG;
    $_YG=array();
    $_YG['cachetoid']=array(
        'baidu'=>'baidu',
        'qh'=>'360',
        'bing'=>'bing',
        'sm'=>'sm'
    );
    $_YG['data']=array(
        'sid'=>0,
        'mbd'=>'',
        'mqh'=>'',
        'msm'=>'',
        'mby'=>'',
        'sbd'=>0,
        'sqh'=>0,
        'ssm'=>0,
        'sby'=>0,
        'cbd'=>0,
        'cqh'=>0,
        'csm'=>0,
        'cby'=>0,
        'title'=>'',
        'link'=>'',
        'author'=>'',
        'time'=>'',
        'ip'=>'',
        'mod'=>0,
        'type'=>0
    );
    $_YG['mod']=$_GET['mod'];
    $_YG['cache']=DISCUZ_ROOT.'./data/sysdata/cache_com_ygphone_plugin.php';
    $_YG['setting']=getYgphoneConfig();
    if (empty($_YG['setting']['submit'])||empty($_YG['setting']['plugin'])){
        $_YG='';
        return 0;
    }
    $_YG['db']=C::t('#com_ygphone_plugin#ygphone');
    return 0;
}
function initHkPostYg(){
    initCommonYg();
    global $_YG,$_G;
    $_YG['newmods']=array('post');
    $_YG['msgs']=array('post_newthread_succeed');
    $_YG['actions']=array('newthread');
    $_YG['action']=$_GET['action'];
    if (!in_array($_G['messageparam'][0],$_YG['msgs'])||!in_array($_YG['mod'],$_YG['newmods'])||!in_array($_YG['action'],$_YG['actions'])||$_GET['topicsubmit']!='yes'){
    $_YG='';
    return 0;
}
    $_YG['data']['sid']=$_G['messageparam'][2]['tid'];
    $_YG['data']['time']=intval($_GET['posttime']);
    $_YG['data']['title']=$_GET['subject'];
    $_YG['data']['author']=$_G['username'];
    $_YG['data']['mod']=2;
    $_YG['data']['type']=1;
    $_YG['data']['ip']=$_G['clientip'];
    $_YG['data']['link']=$_YG['setting']['plugin']['website'].'/'.trim($_G['messageparam'][1], '/');
    $_YG['submitkinds']=0;
    newThreadManager();
    return 0;
}

function newThreadManager(){
    global $_YG,$_G;
    if (empty($_YG['data']['sid'])){
    $_YG='';
    return 0;
}
    $fid=$_G['messageparam'][2]['fid'];
    foreach ($_YG['setting']['submit'] as $id=>$item){
        $selectForums=explode(',',$item['forums']);
        if ($id=='qh'||$item['view']!=0||!in_array($fid,$selectForums)||$item['new']!=1){
            continue;
        }
        $libname='function/'.$id.'_submit_script';
        $folder='plugin/com_ygphone_plugin_'.$_YG['cachetoid'][$id].'_submit/lib';
        require_once libfile($libname,$folder );
    }
    if ($_YG['submitkinds']==0){
        $_YG='';
        return 0;
    }
    $_YG['db']->insertData($_YG['data']);
    return 0;
}
function initHkViewYg(){
    initCommonYg();
   global $_YG;
   if (empty($_YG)){
       return 0;
   }
    $_YG['viewmods']=array('view','viewthread');
   if (!in_array($_YG['mod'],$_YG['viewmods'])){
       $_YG=array();
       return 0;
   }
    $_YG['data']['mod']=1;
    $_YG['submitkinds']=0;
    $_YG['data']['link']=$_YG['setting']['plugin']['website'].'/'.trim($_SERVER['REQUEST_URI'], '/');
    $_YG['db']=C::t('#com_ygphone_plugin#ygphone');
    switch ($_YG['mod']){
        case 'view':
            $_YG['data']['type']=2;
            viewArticleManager();
            break;
        case 'viewthread':
            $_YG['data']['type']=1;
            viewthreadManager();
            break;
        default: $_YG=array();
        return 0;
    }
    return 0;
}

function viewArticleManager(){
    global $_YG,$_G;
    $_YG['data']['sid']=intval($_GET['aid']);
    if (empty($_YG['data']['sid'])){
        $_YG='';
        return 0;
    }
    $_YG['data']['time']=$_G['timestamp'];
    $articleInfo=DB::fetch_first("SELECT `catid`,`username`,`title` FROM %t WHERE `aid`=%d",array('portal_article_title',$_YG['data']['sid']));
    if (empty($articleInfo)){
        $_YG='';
        return 0;
    }

    foreach ( $_YG['setting']['submit'] as $id=>$item) {
        if (intval($item['view'])!=1){
            continue;
        }

        $selectCategories=explode(',',$item['categories']);
        if (empty($selectCategories)){
            continue;
        }

        if (!in_array(intval($articleInfo['catid']),$selectCategories)){
            continue;
        }
        $lastSubTime=intval($_YG['db']->queryLastTime($_YG['data']['sid'],$id,$_YG['data']['type']));
        if ($_YG['data']['time']-$lastSubTime<intval($item['rate']*24*60*60)){

            continue;
        }
        $libname='function/'.$id.'_submit_script';
        $folder='plugin/com_ygphone_plugin_'.$_YG['cachetoid'][$id].'_submit/lib';
        require_once libfile($libname,$folder );
    }
    if ($_YG['submitkinds']==0){
        $_YG='';
        return 0;
    }
    $_YG['data']['ip']=$_G['clientip'];
    $_YG['data']['author']=$articleInfo['username'];
    $_YG['data']['title']=$articleInfo['title'];
    $_YG['db']->insertData($_YG['data']);
    return 0;
}
function viewthreadManager(){
    global $_YG,$_G;
    $_YG['data']['sid']=intval($_G['thread']['tid']);
    if (empty($_YG['data']['sid'])||$_G['thread']['displayorder'] < 0){
        $_YG='';
        return 0;
    }
    $_YG['data']['time']=$_G['timestamp'];
    foreach ( $_YG['setting']['submit'] as $id=>$item) {
        if (intval($item['view'])!=1){
            continue;
        }

        $selectForums=explode(',',$item['forums']);
        if (!in_array(intval($_G['thread']['fid']),$selectForums)){
            continue;
        }
        $lastSubTime=intval($_YG['db']->queryLastTime($_YG['data']['sid'],$id,$_YG['data']['type']));
        if ($_G['timestamp']-$lastSubTime<intval($item['rate']*24*60*60)){
            continue;
        }
        $libname='function/'.$id.'_submit_script';
        $folder='plugin/com_ygphone_plugin_'.$_YG['cachetoid'][$id].'_submit/lib';
        require_once libfile($libname,$folder );
    }
    if ($_YG['submitkinds']==0){
        $_YG='';
        return 0;
    }
    $_YG['data']['ip']=$_G['clientip'];
    $_YG['data']['author']=$_G['thread']['author'];
    $_YG['data']['title']=$_G['thread']['subject'];
    $_YG['db']->insertData($_YG['data']);
    return 0;
}

function getYgphoneConfig(){
    global $_YG;
    include $_YG['cache'];
    if (empty($ygphone['config'])){
        return '';
    }
    return $ygphone['config'];
}