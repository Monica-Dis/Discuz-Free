<?php
/**
 *	[ygphone插件基础包(com_ygphone_plugin.{modulename})] Copyright (c) 2021 by dism.taobao.com
 *	Version: 20210302
 *	Date: 2021-3-2 01:44
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_com_ygphone_plugin {
	//TODO - Insert your code here
function global_footer(){
    include_once libfile('function/hk_manager', 'plugin/com_ygphone_plugin/lib');
    initHkViewYg();
}
}
class plugin_com_ygphone_plugin_forum extends plugin_com_ygphone_plugin{
    function post_message(){
        include_once libfile('function/hk_manager', 'plugin/com_ygphone_plugin/lib');
        initHkPostYg();
    }
}
//From: Dism_taobao-com
?>