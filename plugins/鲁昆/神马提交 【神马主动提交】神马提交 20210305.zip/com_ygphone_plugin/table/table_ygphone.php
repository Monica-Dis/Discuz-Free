<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_ygphone extends discuz_table
{
    protected $_spk;
    protected $_cpk;
    protected $_bfields;
    protected $_ecfields;

    public function __construct($para = array())
    {
        $this->_table = 'com_ygphone_plugin';
        $this->_pk = 'sid';
        $this->_bfields = array(
            '`sid`',
            '`title`',
            '`link`',
            '`author`',
            lang('plugin/com_ygphone_plugin', 'sub_mod_format'),
            lang('plugin/com_ygphone_plugin', 'date_format'),
            '`ip`',
            lang('plugin/com_ygphone_plugin', 'sub_type_format'),
        );
        $this->_ecfields = array(
            'qh' => array(
                '`mqh` as msg',
                '`sqh` as status',
                '`cqh` as code',
            ),
            'baidu' => array(
                '`mbd` as msg',
                '`sbd` as status',
                '`cbd` as code',
            ),
            'bing' => array(
                '`mby` as msg',
                '`sby` as status',
                '`cby` as code',
            ),
            'sm' => array(
                '`msm` as msg',
                '`ssm` as status',
                '`csm` as code',
            ),
        );
        $this->_spk = array(
            'baidu' => 'sbd',
            'qh' => 'sqh',
            'sm' => 'ssm',
            'bing' => 'sby',);
        $this->_cpk = array(
            'baidu' => 'cbd',
            'qh' => 'cqh',
            'sm' => 'csm',
            'bing' => 'cby',
        );

        parent::__construct($para);
    }

    /**
     * @param $sid
     * @param $id
     * @param $type
     * @return mixed
     */
    function queryLastTime($sid, $id,$type)
    {
        $c=$this->_cpk[$id];
        $sql = "SELECT MAX(`time`) FROM %t WHERE `sid`=%d AND $c=200 AND `type`=%d;";
        return DB::result_first($sql, array($this->_table,$sid,$type));
    }

    /**
     * @param $data
     * @return mixed
     */
    function insertData($data)
    {
        return DB::insert($this->_table, $data, false, false, false);
    }

    /**
     * @param $type
     * @param $fieldName
     * @return mixed
     */
    function queryNum($type)
    {
        switch ($type) {
            case 'record':
                $sql = 'SELECT COUNT(*) FROM %t';
                break;
            case 'succeed':
                $sql = 'SELECT COUNT(*) FROM %t WHERE status=1';
                break;
            case 'failed':
                $sql = 'SELECT COUNT(*) FROM %t WHERE status=0';
                break;
        }
        return DB::result_first($sql, array($this->_table));
    }

    /**
     * @param $id
     * @param $type
     * @return int
     */
    function queryNumById($id, $type)
    {
        $statusFiledName = $this->_spk[$id];
        $codeFiledName = $this->_cpk[$id];
        if (empty($statusFiledName) || empty($codeFiledName)) {
            return 0;
        }
        $sql = '';
        switch ($type) {
            case 'record':
                $sql = "SELECT COUNT(*) FROM %t WHERE $statusFiledName=1";
                break;
            case 'succeed':
                $sql = "SELECT COUNT(*) FROM %t WHERE $codeFiledName=200";
                break;
            case 'failed':
                $sql = "SELECT COUNT(*) FROM %t WHERE $statusFiledName=1 AND $codeFiledName<>200";
                break;
            default:
                return 0;
        }
        return DB::result_first($sql, array($this->_table));
    }

    function queryPerData($id, $type, $perpage, $page)
    {
        $sfn = $this->_spk[$id];
        $cfn = $this->_cpk[$id];
        if (empty($sfn) || empty($cfn)) {
            return '';
        }
        $selectFields = array_merge($this->_bfields, $this->_ecfields[$id]);
        $selectFiledStr = implode(',', $selectFields);
        $start = ($page - 1) * $perpage;
        $sql = "SELECT $selectFiledStr FROM "
            . DB::table($this->_table)
            . " WHERE $sfn=1 ";
        switch ($type) {
            case 'record':
                break;
            case 'succeed':
                $sql .= " AND $cfn=200";
                break;
            case 'failed':
                $sql .= " AND $cfn<>200";
                break;
            default:return '';
        }
        $sql .= ' ORDER BY '
            . DB::order('time', 'DESC')
            . DB::limit($start, $perpage);
        return DB::fetch_all($sql);
    }
}