<?php
/**
 *	[神马提交(com_ygphone_plugin_sm_submit.{modulename})] Copyright (c) 2021 by dism.taobao.com
 *	Version: 20210204
 *	Date: 2021-2-4 12:08
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_com_ygphone_plugin_sm_submit {
	//TODO - Insert your code here

}
class plugin_com_ygphone_plugin_sm_submit_forum extends plugin_com_ygphone_plugin_sm_submit{
    //TODO - Insert your code here
    function viewthread_top()
    {
        require_once libfile('function/sm_view', 'plugin/com_ygphone_plugin_sm_submit/lib');
        smViewSubmit();
        return '';
    }

    function post_message($var)
    {
        require_once libfile('function/sm_new', 'plugin/com_ygphone_plugin_sm_submit/lib');
        smNewSubmit($var);
        return '';
    }

}
//From: Dism_taobao-com
?>