<?php
/**
 *    [神马提交(com_ygphone_plugin_sm_submit.uninstall)] Copyright (c) 2021 by dism.taobao.com
 *    Version: 20210204
 *    Date: 2021-2-4 12:08
 */

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
require_once libfile('function/common_cpcore', 'plugin/com_ygphone_plugin/lib');
initCommonYg();
unsetModulesFromCache('sm','submit');
$finish = true;
?>