<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_sm_submit extends discuz_table
{
public function __construct($para = array())
{
    $this->_table='com_ygphone_plugin_sm_submit';
    $this->_pk='sid';
    parent::__construct($para);
}

    /**
     * @param $tid
     * @return array
     */
    function queryLastTime($tid){
        $sql="SELECT `sub_last_time`,`sub_times` FROM %t WHERE `tid`=%d";
        return DB::fetch_first($sql,array($this->_table,$tid));
    }

    /**
     * @param $data
     * @return mixed
     */
    function smInsertData($data){
        return DB::insert($this->_table,$data,false,false,false);
    }

    /**
     * @param $data
     * @param $tid
     * @return bool
     */
    function smUpdateData($data,$tid){
        return DB::update($this->_table, $data,array('tid'=>$tid));
    }

    /**
     * @return mixed
     */
    function queryNum($type){
        $sql='';
        switch ($type){
            case 'record':
                $sql='SELECT COUNT(*) FROM %t';
                break;
            case 'succeed':
                $sql='SELECT COUNT(*) FROM %t WHERE status=1';
                break;
            case 'failed':
                $sql='SELECT COUNT(*) FROM %t WHERE status=0';
                break;
        }
        return DB::result_first($sql,array($this->_table));
    }

    /**
     * @param $curPage
     * @param $perpage
     * @param $type
     * @return array
     */
    function queryAllPerData($curPage,$perpage,$type){
        $sql='';
        switch ($type){
            case 'record':
                $sql='SELECT * FROM %t'
                    .' ORDER BY '
                    .DB::order('sub_last_time','DESC')
                    .DB::limit(($curPage-1)*$perpage,$perpage);
                break;
            case 'succeed':
            $sql='SELECT * FROM %t'
                    .' WHERE status=1 '
                    .' ORDER BY '
                    .DB::order('sub_last_time','DESC')
                    .DB::limit(($curPage-1)*$perpage,$perpage);
                break;
            case 'failed':
            $sql='SELECT * FROM %t'
                .' WHERE status=0 '
                .' ORDER BY '
                    .DB::order('sub_last_time','DESC')
                    .DB::limit(($curPage-1)*$perpage,$perpage);
                break;
        }
        return DB::fetch_all($sql,array($this->_table));
    }

    /**
     * @param $type
     * @return int
     */
    function delAllData($type){
        switch ($type){
            case 'record':
                $this->truncate();
                break;
            case 'succeed':
                DB::delete($this->_table,'status=1');
                break;
            case 'failed':
                DB::delete($this->_table,'status=0');
                break;
        }
        return 0;
    }
}