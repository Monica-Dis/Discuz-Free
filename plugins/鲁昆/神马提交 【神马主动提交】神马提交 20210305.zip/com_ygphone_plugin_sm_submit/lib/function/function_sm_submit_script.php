<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_YG;
if (empty($_YG)){
    return 0;
}
if (empty($_YG['setting']['submit']['sm']['user'])){
    return 0;
}
if (empty($_YG['setting']['submit']['sm']['authkey'])){
    return 0;
}
$_YG['submitkinds']+=1;
$_YG['data']['ssm'] = 1;
submitToSm();
return 0;

/**
 * @return int
 */
function submitToSm()
{
    global $_YG;
    $site=trim(trim($_YG['setting']['plugin']['website'],'https://'),'http://');
    $urls = array(
        $_YG['data']['link'],
    );
    $api = 'https://data.zhanzhang.sm.cn/push?site=' . $site . '&user_name=' . $_YG['setting']['submit']['sm']['user'] . '&resource_name=mip_add&token=' . $_YG['setting']['submit']['sm']['authkey'];
    $ch = curl_init();
    $options = array(
        CURLOPT_URL => $api,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => implode("\n", $urls),
        CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
    );
    curl_setopt_array($ch, $options);
    $result = curl_exec($ch);
    return evalSmResult($result);
}

/**
 * @param $result
 * @return int
 */
function evalSmResult($result)
{
    global $_YG;

    if (empty($result)) {
        $_YG['data']['csm'] = 100;
        $_YG['data']['msm'] = 'Internal server error';
        return 0;
    }
    $result = json_decode($result);
    if ($result->returnCode == 200) {
        $_YG['data']['csm'] = 200;
        $message=$result->errorMsg;
        if (empty($message)) {
            $_YG['data']['msm'] = 'ok';
            return 0;
        }
        $_YG['data']['msm'] = $message;
    }
    $_YG['data']['csm'] = intval($result->returnCode);
    $_YG['data']['msm'] = $result->errorMsg;
    return 0;
}