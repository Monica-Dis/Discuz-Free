<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
define('SM_CACHE', DISCUZ_ROOT . './data/sysdata/cache_smsubmit.php');
function smViewSubmit()
{
    if (!isSmViewSub()) {
        return 0;
    }
    $data = createSmData(submitToSm());
    return insertSmData($data);
}

/**
 * @param $data
 * @return int
 */
function insertSmData($data)
{
    global $_G, $smTempTimes;
    $table = '#com_ygphone_plugin_sm_submit#sm_submit';
    $db = C::t($table);
    if ($smTempTimes !== 0) {
        $db->smUpdateData($data, intval($_G['tid']));
        return 0;
    }
    $db->smInsertData($data);
    return 0;
}

function createSmData($data)
{
    global $_G, $submitUrl, $smTempTimes;
    if (empty($data)) {
        $data = array();
    }
    $data['tid'] = intval($_G['tid']);
    $data['subject'] = addslashes($_G['thread']['subject']);
    $data['url'] = addslashes($submitUrl);
    $data['author'] = addslashes($_G['thread']['author']);
    $data['sub_last_time'] = intval($_G['timestamp']);
    $data['sub_times'] = $smTempTimes + 1;
    $data['clientip'] = $_G['clientip'];
    $data['sub_type'] = 'view';
    return $data;
}

/**
 * @return array
 */
function submitToSm()
{
    global $_G, $smAuthkey, $submitUrl, $smUserName;
    $webSite = trim($_G['siteurl'], '/');
    $hostName = trim(trim($webSite, 'http://'), 'https://');
    $submitUrl = $webSite . '/' . trim($_SERVER['REQUEST_URI'], '/');
    $urls = array(
        $submitUrl,
    );
    $api = 'https://data.zhanzhang.sm.cn/push?site=' . $hostName . '&user_name=' . $smUserName . '&resource_name=mip_add&token=' . $smAuthkey;
    $ch = curl_init();
    $options = array(
        CURLOPT_URL => $api,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => implode("\n", $urls),
        CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
    );
    curl_setopt_array($ch, $options);
    $result = curl_exec($ch);
    return evalSmResult($result);
}

/**
 * @param $result
 * @return array
 */
function evalSmResult($result)
{
    $data = array();
    if (empty($result)) {
        $data['status'] = 0;
        $data['return_code'] = 0;
        $data['message'] = 'unknown';
        return $data;
    }
    $result = json_decode($result);
    if ($result->returnCode == 200) {
        $data['status'] = 1;
        $data['return_code'] = 200;
        if (empty($result->errorMsg)) {
            $data['message'] = 'ok';
            return $data;
        }
        $data['message'] = $result->errorMsg;
        return $data;
    }
    $data['status'] = 0;
    $data['return_code'] = intval($result->returnCode);
    $data['message'] = $result->errorMsg;
    return $data;
}

/**
 * @return bool
 */
function isSmViewSub()
{
    global $_G;
    if ($_G['thread']['displayorder'] < 0) {
        return false;
    }
    if (empty($_G['tid'])) {
        return false;
    }
    $tid = intval($_G['tid']);
    $config = getSmConfig();
    if (empty($config)) {
        return false;
    }
    if ($config['view'] != 1) {
        return false;
    }
    if (empty(trim($config['authkey']))) {
        return false;
    }
    if (empty(trim($config['user_name']))) {
        return false;
    }

    $forums=explode(',',$config['forums']);
    if (!in_array($_G['fid'],$forums)){
        return false;
    }
    $lastTimestamp = getSmSubTimestamp($tid);
    $cacheRate = abs(intval($config['rate'])) * 24 * 60 * 60;
    $accessTimestamp = $_G['timestamp'];
    if ($accessTimestamp - $lastTimestamp < $cacheRate) {
        return false;
    }
    global $smAuthkey, $smUserName;
    $smAuthkey = trim($config['authkey']);
    $smUserName = trim($config['user_name']);
    return true;
}

/**
 * @param $tid
 * @return int
 */
function getSmSubTimestamp($tid)
{
    $table = '#com_ygphone_plugin_sm_submit#sm_submit';
    $db = C::t($table);
    $baseInfo = $db->queryLastTime($tid);
    global $smTempTimes;
    if (empty($baseInfo)) {
        $smTempTimes = 0;
        return 0;
    }
    $smTempTimes = intval($baseInfo['sub_times']);
    return intval($baseInfo['sub_last_time']);
}

/**
 * @return array|mixed
 */
function getSmConfig()
{
    include SM_CACHE;
    if (empty($submit['config'])) {
        return array();
    }
    return $submit['config'];
}