<?php
$ygphone_ini=array(
    'sm'=>20210305
);