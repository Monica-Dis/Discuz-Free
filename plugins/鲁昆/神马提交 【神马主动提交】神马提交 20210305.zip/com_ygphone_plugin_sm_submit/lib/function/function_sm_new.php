<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/sm_view', 'plugin/com_ygphone_plugin_sm_submit/lib');
function smNewSubmit($var)
{
    if (!isSmNew()) {
        return 0;
    }
    $data = createSmNewData(submitNewToSm($var));
    return insertSmNewData($data);
}

function submitNewToSm($var)
{
    global $_G, $smAuthkey, $smSubmitUrl,$smUserName;
    $webSite = trim($_G['siteurl'], '/');
    $hostName=trim(trim($webSite,'https://'),'http://');
    $smSubmitUrl = $webSite . '/' . trim($var['param'][1], '/');
    $urls = array(
        $smSubmitUrl,
    );
    $api = 'https://data.zhanzhang.sm.cn/push?site=' . $hostName . '&user_name=' . $smUserName . '&resource_name=mip_add&token=' . $smAuthkey;
    $ch = curl_init();
    $options = array(
        CURLOPT_URL => $api,
        CURLOPT_POST => true,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POSTFIELDS => implode("\n", $urls),
        CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
    );
    curl_setopt_array($ch, $options);
    $result = curl_exec($ch);
    return evalSmResult($result);
}

function createSmNewData($data)
{
    global $_G, $smSubmitUrl;
    if (empty($data)) {
        $data = array();
    }
    $data['tid'] = intval($_G['messageparam'][2]['tid']);
    $data['subject'] = addslashes($_GET['subject']);
    $data['url'] = addslashes($smSubmitUrl);
    $data['author'] = addslashes($_G['username']);
    $data['sub_last_time'] = intval($_G['timestamp']);
    $data['sub_times'] = 1;
    $data['clientip'] = $_G['clientip'];
    $data['sub_type'] = 'new';
    return $data;
}

function insertSmNewData($data)
{
    $table = '#com_ygphone_plugin_sm_submit#sm_submit';
    $db = C::t($table);
    $db->smInsertData($data);
    return 0;
}

function isSmNew()
{
    global $_G, $authkey,$smUserName;
    if ($_G['messageparam'][0] != 'post_newthread_succeed') {
        return false;
    }
    $config = getSmConfig();
    if (empty($config)) {
        return false;
    }
    $authkey = trim($config['authkey']);
    if (empty($authkey)) {
        return false;
    }
    $smUserName=trim($config['user_name']);
    if (empty($smUserName)) {
        return false;
    }
    $forums=explode(',',$config['forums']);
    if (!in_array($_G['fid'],$forums)){
        return false;
    }
    if ($config['new'] != 1) {
        return false;
    }
    if (!empty($config['view'])) {
        return false;
    }
    return true;
}