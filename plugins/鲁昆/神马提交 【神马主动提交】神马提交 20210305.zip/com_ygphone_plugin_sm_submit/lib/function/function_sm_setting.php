<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

require_once libfile('function/common_cpcore', 'plugin/com_ygphone_plugin/lib');
require_once libfile('function/sm_common_cpcore','plugin/com_ygphone_plugin_sm_submit/lib');
/**
 * @return int
 */
function smSetting()
{
    initCpCoreYg();

    if (!submitcheck('sm_main')) {
        defaultSmShow();
        return 0;
    } else {
        return smReqSet();
    }
}

function defaultSmShow()
{
    global $_YG;
    $smSetting=checkSmConfig($_YG['setting']);
    showtips('','tips',true,lang($_YG['plang'],'setting_tips'));
    showformheader($_YG['action']);
    showtableheader(); /*d'.'i'.'sm.ta'.'o'.'bao.com*/
    showsetting(lang($_YG['plang'], 'user_setting_title'), 'user', $smSetting['user'], 'textarea', '', 0, lang($_YG['plang'], 'token_setting_comment'));
    showsetting(lang($_YG['plang'], 'token_setting_title'), 'authkey', $smSetting['authkey'], 'textarea', '', 0, lang($_YG['plang'], 'token_setting_comment'));
    showsetting(lang($_YG['lang'], 'forum_setting_title'), 'forums', '', forumMultiple($smSetting['forums']), '', 0, lang($_YG['lang'], 'forum_setting_comment'));
    if (!empty($_YG['categories'])) {
        showsetting(lang($_YG['lang'], 'category_setting_title'), 'categories', '', categoryMultiple($smSetting['categories']), '', 0, lang($_YG['lang'], 'category_setting_comment'));
    }
    showsetting(lang($_YG['lang'], 'open_view_title'), 'view', $smSetting['view'], 'radio', '', 0, '');
    showsetting(lang($_YG['lang'], 'open_new_title'), 'new', $smSetting['new'], 'radio', '', 0, '');
    showsetting(lang($_YG['lang'], 'rate_setting_title'), 'rate', $smSetting['rate'], 'number', '', 0, lang($_YG['lang'], 'rate_setting_comment'));
    showtablefooter(); /*dism��taobao��com*/
    showsubmit('sm_main', lang($_YG['lang'], 'button_submit_value'));
    showformfooter(); /*dism _ taobao _com*/
}

/**
 * @return int
 */
function smReqSet()
{
    global $_YG;
    $_YG['setting']['sm']['user'] = smCheckSubUser($_YG['reqparam']['user']);
    $_YG['setting']['sm']['authkey'] = smCheckSubAuthkey($_YG['reqparam']['authkey']);
    $_YG['setting']['sm']['forums'] = checkCidSetting($_YG['reqparam']['forums']);
    $_YG['setting']['sm']['categories'] = checkCidSetting($_YG['reqparam']['categories']);
    $_YG['setting']['sm']['new'] = checkIntBool($_YG['reqparam']['new']);
    $_YG['setting']['sm']['view'] = checkIntBool($_YG['reqparam']['view']);
    $_YG['setting']['sm']['rate'] = checkRate($_YG['reqparam']['rate']);
    writeToYgphoneCache($_YG['setting']['sm']);
    cpmsg(lang($_YG['lang'], 'cpmsg_succeed'), $_YG['cpmsgurl'], 'succeed');
    return 0;
}

/**
 * @param $authkey
 * @return string
 */
function smCheckSubAuthkey($authkey)
{
    global $_YG;
    if (empty($authkey)) {
        cpmsg(lang($_YG['plang'], 'authkey_error_tip'), $_YG['cpmsgurl'], 'error');
        return '';
    }
    $authkey = preg_replace('/\s+/', '', $authkey);
    if (empty($authkey)) {
        cpmsg(lang($_YG['plang'], 'authkey_error_tip'), $_YG['cpmsgurl'], 'error');
        return '';
    }
    $authkeyArr = explode('=', $authkey);
    $authkey = $authkeyArr[count($authkeyArr) - 1];
    $authkey=trim($authkey);
    if (empty($authkey)){
        cpmsg(lang($_YG['plang'], 'authkey_null_error_tip'), $_YG['cpmsgurl'], 'error');
        return '';
    }
    return $authkey . '';
}

function smCheckSubUser($user){
    global $_YG;
    if (empty($user)) {
        cpmsg(lang($_YG['plang'], 'user_error_tip'), $_YG['cpmsgurl'], 'error');
        return '';
    }
    $user = preg_replace('/\s+/', '', $user);
    if (empty($user)) {
        cpmsg(lang($_YG['plang'], 'user_error_tip'), $_YG['cpmsgurl'], 'error');
        return '';
    }
    $userArr = preg_split("/[=&]+/",$user.' ');
    if (count($userArr)>=4){
        $user = $userArr[3];
    }elseif (count($userArr)==1){
        $user=$userArr[0];
    }else{
        cpmsg(lang($_YG['plang'], 'user_error_tip'), $_YG['cpmsgurl'], 'error');
        return '';
    }
    $user=trim($user);
    if (empty($user)){
        cpmsg(lang($_YG['plang'], 'user_null_error_tip'), $_YG['cpmsgurl'], 'error');
        return '';
    }

    return $user;
}