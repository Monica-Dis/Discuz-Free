<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
$plyes=($_G['cache']['plugin']['xlwsq_tel']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
if($_G['mobile']) {
	$menubgcolor=$mobilemenubgcolor;
}
$appurls = $_G['siteurl'] . "plugin.php?id=xlwsq_tel:xlwsq_tel_user";
$fabuset = unserialize($groups);
$mianshenhe = unserialize($mianshenhe);
$navtitle = $title;
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
$p = $_GET['p'] ? $_GET['p'] : 'index';
if ($p == 'index'||$p == 'mylist') {
    $uid = intval($_G['uid']);
    $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE uid='$uid'");
    $pager = intval($_GET['page']);
    $pager = max($pager, 1);
    $starts = ($pager - 1) * 15;
    if ($countr) {
        $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE uid='$uid' ORDER BY display ASC,dateline DESC LIMIT $starts,15");
        while ($rw = DB::fetch($rs)) {
            $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$rw[cate]'"));
            if ($pa['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$pa[upid]'");
                $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
            } else {
                $rw['cate'] = $pa['subject'];
            }
            $manylist[] = $rw;
        }
    }
    $appurl = $_G['siteurl'] . "plugin.php?id=xlwsq_tel:xlwsq_tel_user&p=index";
    $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 15, $pager, $appurl . $pageadd) . "</div>";
} elseif ($p == 'adminalllist') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tel_item'));
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " ORDER BY display ASC,dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $appurl = $_G['siteurl'] . "plugin.php?id=xlwsq_tel:xlwsq_tel_user&p=adminalllist";
        $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager, $appurl . $pageadd) . "</div>";
    } else {
		showmessage(lang('plugin/xlwsq_tel', 'wuquanxiancaozuo') , dreferer());
    }
    if (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tel_item') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tel', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tel_item') . " SET display='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tel', 'gengxinok') , dreferer());
	}elseif(submitcheck('applysubmtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_tel_item')." SET changyong='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_tel', 'gengxinok'), dreferer());

	}elseif(submitcheck('applysubmqxtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
			$aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_tel_item')." SET changyong='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_tel', 'gengxinok'), dreferer());	
    } elseif (submitcheck('applysubmzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tel_item') . " SET top='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tel', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
			$aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tel_item') . " SET top='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tel', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $ssd) {
			$aid = intval($ssd);
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE id ='$ssd'LIMIT 0 , 1");
             for ($i = 1; $i <= 5; $i++) {
               $pic = 'pic'.$i;
		       unlink($active[$pic]);
             }
            DB::query("DELETE a,b FROM " . DB::table('plugin_xlwsq_tel_item') . " AS a LEFT JOIN " . DB::table('plugin_xlwsq_tel_favorites') . " AS b ON a.id = b.sid  WHERE a.id = '$ssd' ");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tel', 'shanchuok') , dreferer());
    }

} elseif ($p == 'add') {
    include_once 'source/plugin/xlwsq_tel/class/resizeimage.class.php';
    $groups = unserialize($groups);
    if (!in_array($_G['groupid'], $groups)) {
        showmessage(lang('plugin/xlwsq_tel', 'wuquanxiancaozuo') , '', array() , array('login' => true));
    } else {
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
        if (submitcheck('applysubmit')) {
            $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
            $title = dhtmlspecialchars($_GET['title']);
            $tel = dhtmlspecialchars($_GET['tel']);
            $qq = dhtmlspecialchars($_GET['qq']);
            $weixin = dhtmlspecialchars($_GET['weixin']);
            $wangzhi = addslashes($_GET['wangzhi']);
            $dizhi = dhtmlspecialchars($_GET['dizhi']);
            $zhuying = dhtmlspecialchars($_GET['zhuying']);
            $info =dhtmlspecialchars($_GET['info']);
            $top = intval($_GET['top']);
            $changyong = intval($_GET['changyong']);
            if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
                $display = 1;
            } else {
                $display = 0;
            }
            $diynum = intval($_GET['diynum']);
            $color = dhtmlspecialchars($_GET['color']);
            if ($chongfutijiao == 0) {
               $chongfu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tel_item'). " where title = '$title'");
               if($chongfu>=1){
	                $chongfub = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE  title = '$title'");
			        if($chongfub['id']!=$id){
						showmessage(lang('plugin/xlwsq_tel', 'mingchengcunzai'));
					}
			   }			
			}
            if ($_FILES['file']['error'] == 0) {
                $rand = date("YmdHis") . random(3, $numeric = 1);
                $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                $arr = explode(".", $_FILES["file"]["name"]);
                $hz = $arr[count($arr) - 1];
                if (!in_array($hz, $filetype)) {
                    showmessage(lang('plugin/xlwsq_tel', 'tupiangeshibuzhengque'));
                }
                $filepath = "source/plugin/xlwsq_tel/upimg/" . date("Ymd") . "/";
                $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
                if (!file_exists($filepath)) {
                    mkdir($filepath);
                }
                if (@copy($_FILES['file']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath . $randname))) {
                        @unlink($_FILES['file']['tmp_name']);
                }
                $pic = "source/plugin/xlwsq_tel/upimg/" . date("Ymd") . "/" . $randname . "";
				$imageinfo = getimagesize($pic);
			    if ($imageinfo[0] > 600) {
					 new myThumbClass($pic,1,2,$pic,1,600); 
			    }
            }
            DB::insert('plugin_xlwsq_tel_item', array(
                'id' => '',
                'uid' => $_G['uid'],
                'author' => $_G['username'],
                'cate' => $cate,
                'title' => $title,
                'pic' => $pic,
                'tel' => $tel,
                'qq' => $qq,
                'weixin' => $weixin,
                'wangzhi' => $wangzhi,
                'dizhi' => $dizhi,
                'zhuying' => $zhuying,
                'info' => $info,
                'top' => $top,
                'changyong' => $changyong,
                'display' => $display,
                'diynum' => $diynum,
                'color' => $color,
                'updateline' => $_G['timestamp'],
                'dateline' => $_G['timestamp']
            ));
            if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
                showmessage(lang('plugin/xlwsq_tel', 'fabuchenggong') , 'plugin.php?id=xlwsq_tel:xlwsq_tel_user&p=index', array() , array('alert' => 'right'));
            } else {
                for ($i = 0; $i < count($admins); $i++) {
                    $message = '<a href="plugin.php?id=xlwsq_tel&#58;xlwsq_tel_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_tel', 'yonghufabuxinxinxi') . '</a>';
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                }
                showmessage(lang('plugin/xlwsq_tel', 'fabudengdaishenhe') , 'plugin.php?id=xlwsq_tel:xlwsq_tel_user&p=index', array() , array('alert' => 'right'));
            }
        }
    }

} elseif ($p == 'edit') {
    include_once 'source/plugin/xlwsq_tel/class/resizeimage.class.php';
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE id='$id'");
    $uid = intval($active['uid']);
    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_tel', 'caozuocuowu') , '', array() , array('login' => true));
    }
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    if (submitcheck('applysubmit')) {
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $title = dhtmlspecialchars($_GET['title']);
        $pic = dhtmlspecialchars($_GET['pic']);
        $tel = dhtmlspecialchars($_GET['tel']);
        $qq = dhtmlspecialchars($_GET['qq']);
        $weixin = dhtmlspecialchars($_GET['weixin']);
        $wangzhi = addslashes($_GET['wangzhi']);
        $dizhi = dhtmlspecialchars($_GET['dizhi']);
        $zhuying = dhtmlspecialchars($_GET['zhuying']);
        $info = dhtmlspecialchars($_GET['info']);
        $top = intval($_GET['top']);
        $changyong = intval($_GET['changyong']);
        if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
            $display = 1;
        } else {
            $display = 0;
        }
        $diynum = intval($_GET['diynum']);
        $color = addslashes($_GET['color']);
        $timestamp = $_G['timestamp'];
        if ($chongfutijiao == 0) {
               $chongfu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tel_item'). " where title = '$title'");
               if($chongfu>=1){
	                $chongfub = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE  title = '$title'");
			        if($chongfub['id']!=$id){
						showmessage(lang('plugin/xlwsq_tel', 'mingchengcunzai'));
					}
			   }			
	    }
        if ($_FILES['file']['error'] == 0) {
            if ($active["pic"] != false) {
                unlink($active["pic"]);
            }
            $rand = date("YmdHis") . random(3, $numeric = 1);
            $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
            $arr = explode(".", $_FILES["file"]["name"]);
            $hz = $arr[count($arr) - 1];
            if (!in_array($hz, $filetype)) {
                showmessage(lang('plugin/xlwsq_tel', 'tupiangeshibuzhengque'));
            }
            $filepath = "source/plugin/xlwsq_tel/upimg/" . date("Ymd") . "/";
            $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
            if (!file_exists($filepath)) {
                mkdir($filepath);
            }
            if (@copy($_FILES['file']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath . $randname))) {
                        @unlink($_FILES['file']['tmp_name']);
            }
            $pic = "source/plugin/xlwsq_tel/upimg/" . date("Ymd") . "/" . $randname . "";
			$imageinfo = getimagesize($pic);
			if ($imageinfo[0] > 600) {
				new myThumbClass($pic,1,2,$pic,1,600); 
		    }
        }
        DB::update('plugin_xlwsq_tel_item', array(
            'cate' => $cate,
            'title' => $title,
            'pic' => $pic,
            'tel' => $tel,
            'qq' => $qq,
            'weixin' => $weixin,
            'wangzhi' => $wangzhi,
            'dizhi' => $dizhi,
            'zhuying' => $zhuying,
            'info' => $info,
            'top' => $top,
            'changyong' => $changyong,
            'color' => $color,
            'display' => $display,
            'diynum' => $diynum
        ) , "id='$id'");
        if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
			showmessage(lang('plugin/xlwsq_tel', 'gengxinok') , dreferer());
        } else {
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_tel&#58;xlwsq_tel_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_tel', 'yonghufabuxinxinxi') . '</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
            showmessage(lang('plugin/xlwsq_tel', 'fabudengdaishenhe') , dreferer());
        }
    }
} elseif ($p == 'favorites') {
    $uid = intval($_G['uid']);
    $appurl = $_G['siteurl'] . "plugin.php?id=xlwsq_tel:xlwsq_tel_user";
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tel_favorites') . " WHERE uid='$uid'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 20;
    if ($counts) {
        $sql = "SELECT * FROM " . DB::table('plugin_xlwsq_tel_favorites') . " WHERE uid = '$uid' ORDER BY dateline DESC LIMIT $starts,20";
        $query = DB::query($sql);
        $sc = $scs = array();
        while ($sc = DB::fetch($query)) {
            $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " where id = '$sc[sid]'");
            $sc['title'] = $item['title'];
            $sc['tel'] = $item['tel'];
            $sc['info'] = $item['info'];
            $scs[] = $sc;
        }
    }
    $multis = "<div class='pages cl'>" . multi($counts, 20, $pages, $appurl . "&p=$p" . $pageadd) . "</div>";
} elseif ($p == 'favoritesdel') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if ($_GET['formhash'] == FORMHASH) {
        DB::query("DELETE FROM " . DB::table('plugin_xlwsq_tel_favorites') . " WHERE id = '$id' and uid = '$uid'");
        showmessage(lang('plugin/xlwsq_tel', 'shanchuok') , dreferer());
    }
} elseif ($p == 'shenheok') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tel_item') . " SET display='1' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_tel', 'shenheok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_tel', 'caozuocuowu'));
    }
} elseif ($p == 'qxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tel_item') . " SET display='0' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_tel', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_tel', 'caozuocuowu'));
    }
} elseif ($p == 'del') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE id ='$id'");
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$active['uid']==$uid) {
        if ($_GET['formhash'] == FORMHASH) {
            if ($active["pic"] != false) {
               unlink($active["pic"]);
            }
            DB::query("DELETE a,b FROM " . DB::table('plugin_xlwsq_tel_item') . " AS a LEFT JOIN " . DB::table('plugin_xlwsq_tel_favorites') . " AS b ON a.id = b.sid WHERE a.id = '$id' ");
            showmessage(lang('plugin/xlwsq_tel', 'shanchuok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_tel', 'caozuocuowub'));
    }
}
include (template("xlwsq_tel:xlwsq_tel_user"));
?>