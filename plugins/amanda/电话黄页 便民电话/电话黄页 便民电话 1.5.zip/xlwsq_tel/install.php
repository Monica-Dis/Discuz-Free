<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_tel_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `author` varchar(80) NOT NULL,
	  `cate` int(11) NOT NULL,
	  `title` varchar(50) NOT NULL,
	  `pic` text NOT NULL,
	  `info` text NOT NULL,
   	  `tel`  varchar(20) NOT NULL,
   	  `qq`  varchar(20) NOT NULL,
   	  `weixin`  varchar(30) NOT NULL,
   	  `dizhi`  varchar(255) NOT NULL,
   	  `wangzhi`  text NOT NULL,
   	  `zhuying`  varchar(255) NOT NULL,
	  `top` tinyint(1)  NOT NULL,
	  `changyong` tinyint(1)  NOT NULL,
	  `color` text NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `updateline` int(11) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_tel_cate` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` varchar(255) NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(1) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_tel_favorites` (
   	  `id` int(11) NOT NULL auto_increment,
 	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
INSERT INTO `pre_plugin_xlwsq_tel_cate` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '', '$installlang[cate1]', 0),
(2, 0, '', '$installlang[cate2]', 0),
(3, 0, '', '$installlang[cate3]', 0),
(4, 0, '', '$installlang[cate4]', 0),
(5, 0, '', '$installlang[cate5]', 0),
(6, 0, '', '$installlang[cate6]', 0),
(7, 0, '', '$installlang[cate7]', 0),
(8, 0, '', '$installlang[cate8]', 0),
(9, 0, '', '$installlang[cate9]', 0),
(10, 0, '', '$installlang[cate10]', 0),
(11, 0, '', '$installlang[cate11]', 0),
(12, 0, '', '$installlang[cate12]', 0),
(13, 0, '', '$installlang[cate13]', 0),
(14, 0, '', '$installlang[cate14]', 0),
(15, 0, '', '$installlang[cate15]', 0);
EOF;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_tel/discuz_plugin_xlwsq_tel.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_tel/discuz_plugin_xlwsq_tel_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_tel/discuz_plugin_xlwsq_tel_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_tel/discuz_plugin_xlwsq_tel_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_tel/discuz_plugin_xlwsq_tel_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_tel/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_tel/install.php');
runquery($sql);
$finish =true;
?>