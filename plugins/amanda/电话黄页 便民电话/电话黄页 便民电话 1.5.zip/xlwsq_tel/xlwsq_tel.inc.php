<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/xlwsq_tel/function/function_core.php';
global $_G;
if (!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plyes=($_G['cache']['plugin']['xlwsq_tel']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
if($_G['mobile']) {
    $menubgcolor=$mobilemenubgcolor;
    $eacha=$mobileeacha;
    $footad=$mobilefootad ? $mobilefootad : $footad;
}
$appurl = $_G['siteurl'] . "plugin.php?id=xlwsq_tel";
$style=$_GET['style'] ? $_GET['style'] : $style;
$lititlewidth=$liwidth-98;
$licwidth=$liwidth-110;
$fabuset = unserialize($groups);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$navtitle = $title;
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if($mod == 'index') {
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    if($_POST['type']==1){ 
		   $where="dizhi like '%".addcslashes(addslashes($key), '%')."%' AND display!='0' AND";
	    }elseif($_POST['type']==2){ 
		   $where="info like '%".addcslashes(addslashes($key), '%')."%' AND display!='0' AND";
	    }else{ 
		   $where="title like '%".addcslashes(addslashes($key), '%')."%' AND display!='0' AND";
		}
	$keync=urlencode($key);
	$pageadd="&key=$keync";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$cate_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
        $av_d[$cate_id] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $sd = intval($_GET['b']);
    if ($sd) {
        $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$sd'");
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
        $av_d[$sd] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    if ($_GET['cy']) {
		$px="changyong = '1' AND display!='0' ORDER BY diynum DESC,updateline DESC,dateline DESC"; $pageadd="&cy=cy";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE $where $wb $wc changyong = '1' AND display!='0' ");
	}else{
		$px="display!='0' ORDER BY top DESC,diynum DESC,updateline DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE $where $wb $wc display!='0'");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE $where $wb $wc $px LIMIT $starts,$eacha");
        $mythread = $mythreads = array();
        while ($mythread = DB::fetch($query)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$cate[upid]'");
                $mythread['cate'] = $cate['subject'];
            } else {
                $mythread['cate'] = $cate['subject'];
            }
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px;'>" . multi($counts, $eacha, $pages, 'plugin.php?id=xlwsq_tel' .$pageadd. $pageadds . $pageaddx) . "</div>";
    $r_id = intval($_GET['a']);
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tel_item')." WHERE changyong ='1' AND display!='0' ORDER BY diynum DESC, dateline DESC LIMIT $changyongset");
	$tuijian = $tuijians = array();
	while($tuijian = DB::fetch($query)){
		$tuijians[] = $tuijian;
	}
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . "-" . $mcateb['subject']. "-";
      } else {
           $catenav = $mcate['subject']. "-";
      }
    }
    $navtitle = $catenav .$title;
    include template('xlwsq_tel:list');
}elseif($_GET['mod']=='qrpic'){
    include_once 'source/plugin/xlwsq_tel/class/qrcode.class.php';
	$sid = intval($_GET['sid']);
    $value=$_G['siteurl'].'plugin.php?id=xlwsq_tel&mod=view&sid='.$sid;
    QRcode::png($value, false,L,6);
    include template('xlwsq_tel:qrpic');
}elseif($_GET['mod']=='indexqrpic'){
    include_once 'source/plugin/xlwsq_tel/class/qrcode.class.php';
    QRcode::png($appurl, false,L,6);
}elseif($_GET['mod']=='view'){
	$sid = intval($_GET['sid']);
    if($_G['groupid']==1 || in_array($_G['uid'], $admins)){
	   $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE id = '$sid'");
	}else{
	   $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tel_item')." WHERE id = '$sid' AND display!='0'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_tel', 'error') , "plugin.php?id=xlwsq_tel") : '';
    $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_favorites') . " WHERE sid = '$sid' AND uid = '$_G[uid]'");
    $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$mythread[cate]'");
	if ($cate['upid'] != 0) {
        $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$cate[upid]'");
        $mythread['cate'] = $cate_t['subject'] . " - " . $cate['subject'];
        $mythread['b'] = $cate['id'];
        $mythread['a'] = $cate['upid'];
    } else {
        $mythread['cate'] = $cate['subject'];
        $mythread['a'] = $cate['id'];
        $mythread['b'] = '0';
    }
    include template('xlwsq_tel:view');
}elseif($_GET['mod']=='view2'){
	$sid = intval($_GET['sid']);
    if($_G['groupid']==1 || in_array($_G['uid'], $admins)){
	   $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE id = '$sid'");
	}else{
	   $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tel_item')." WHERE id = '$sid' AND display!='0'");
	}
    $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$mythread[cate]'");
	if ($cate['upid'] != 0) {
        $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_cate') . " WHERE id = '$cate[upid]'");
        $mythread['cate'] = $cate_t['subject'] . " - " . $cate['subject'];
    } else {
        $mythread['cate'] = $cate['subject'];
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tel_item')." WHERE changyong ='1' AND display!='0' ORDER BY diynum DESC, dateline DESC LIMIT $changyongset");
	$tuijian = $tuijians = array();
	while($tuijian = DB::fetch($query)){
		$tuijians[] = $tuijian;
	}
    include template('xlwsq_tel:view2');
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_tel_favorites') . " WHERE sid = '$sid' and uid = '$uid'");
            showmessage(lang('plugin/xlwsq_tel', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
        } else {
            DB::insert('plugin_xlwsq_tel_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'dateline' => $_G['timestamp']));
            showmessage(lang('plugin/xlwsq_tel', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
        }
    }
} elseif ($_GET['mod'] == 'report') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE id = '$sid'");
	if(submitcheck('addreport')){
        $url = 'plugin.php?id=xlwsq_tel&mod=view&sid='.$sid;
		$urlkey = md5($url);
    	$message =cutstr(dhtmlspecialchars(trim($_GET['message'])), 300, '');
	if($reportid = C::t('common_report')->fetch_by_urlkey($urlkey)) {
		C::t('common_report')->update_num($reportid, $message);
	}else {
		DB::insert('common_report',array('id' => '','urlkey' => $urlkey,'url' => $url,'message' => $message,'uid' => $_G['uid'],'username' =>$_G[username],'num' => '1', 'dateline' => $_G['timestamp']));
	}
            for ($i = 0; $i < count($admins); $i++) {
                notification_add($admins[$i], 'report', 'new_report', array('from_id' => 1, 'from_idtype' => 'newreport'), 1);
            }
        showmessage(lang('plugin/xlwsq_tel', 'tijiaochenggong') , 'plugin.php?id=xlwsq_tel&mod=view&sid='.$sid, array() , array('alert' => 'right'));
	 }
    include template('xlwsq_tel:report');
} elseif ($_GET['mod'] == 'freshen') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $now = date('Y-m-d', $_G['timestamp']);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tel_item') . " WHERE id = '$sid'");
    $uid = intval($info['uid']);
    $updateline = date('Y-m-d', $info['updateline']);
    if ($_GET['formhash'] == FORMHASH) {
        if ($info['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
            if ($now == $updateline) {
                showmessage(lang('plugin/xlwsq_tel', 'shuaxinshibai') , '', array() , array('alert' => 'error'));
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_tel_item') . " SET `updateline` = '$_G[timestamp]' WHERE `id` = '$sid'");
                showmessage(lang('plugin/xlwsq_tel', 'shuaxinok') , '', array() , array('alert' => 'right'));
            }
        } else {
            showmessage(lang('plugin/xlwsq_tel', 'caozuocuowu') , dreferer());
        }
    }
}
//From: dis'.'m.tao'.'bao.com
?>