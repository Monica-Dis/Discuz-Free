<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
$plyes=($_G['cache']['plugin']['xlwsq_wallad']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
if($_G['mobile']) {
	$menubgcolor=$mobilemenubgcolor;
}
$fabuset = unserialize($groups);
$mianshenhe = unserialize($mianshenhe);
$newpicdx=$picdx*1024;
$navtitle = $title;
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
if($badword) {
    $badword = explode("|", $badword);
    $badwordfilter = array_combine($badword,array_fill(0,count($badword),'*'));
}
$credit = abs($credit);
$_G['uid'] = $_G['uid'] ? $_G['uid'] : '0';
$p = $_GET['p'] ? $_GET['p'] : 'index';
if ($p != 'index' && $p != 'add' && $p != 'edit' && $p != 'del') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
}
if ($p == 'mylist'||$p == 'index') {
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
    $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE $where uid='$uid' AND uid!='0'");
    $pager = intval($_GET['page']);
    $pager = max($pager, 1);
    $starts = ($pager - 1) * 15;
    if ($countr) {
        $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE $where uid='$uid' ORDER BY display ASC,dateline DESC LIMIT $starts,15");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
    }
    $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 15, $pager, 'plugin.php?id=xlwsq_wallad:xlwsq_wallad_user&p='.$p.'' . $pageadd) . "</div>";
	$moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
} elseif ($p == 'adminalllist') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $where=$pageadd="";
        if($_GET['key']){
            $key=stripsearchkey($_GET['key']);
	        $where=" where title like '%".addcslashes(addslashes($key), '%_')."%'";
	        $keync=urlencode($key);
	        $pageadd="&key=$keync";
        }
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_item').$where);
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " $where ORDER BY display ASC,dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager, 'plugin.php?id=xlwsq_wallad:xlwsq_wallad_user&p=adminalllist' . $pageadd) . "</div>";
    } else {
        showmessage(lang('plugin/xlwsq_wallad', 'wuquanxiancaozuo') , '', array() , array('alert' => 'error'));
    }
    if (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wallad', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET display='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wallad', 'gengxinok') , dreferer());
	}elseif(submitcheck('applysubmtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_wallad_item')." SET tuijian='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_wallad', 'gengxinok'), dreferer());
	}elseif(submitcheck('applysubmqxtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_wallad_item')." SET tuijian='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_wallad', 'gengxinok'), dreferer());	
    } elseif (submitcheck('applysubmzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET top='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wallad', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET top='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wallad', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id ='$aid'LIMIT 0 , 1");
             for ($i = 1; $i <= 5; $i++) {
               $pic = 'pic'.$i;
		       unlink($active[$pic]);
             }
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id = '$aid'");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wallad', 'shanchuok') , dreferer());
    }
}elseif($p=='adminxfjl'){	
    $where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    $keytype = intval($_GET['keytype']);
    if($key){
        if($keytype==1){
            $where=" WHERE author ='$key' ";
        }elseif($keytype==2){
            $where=" WHERE title ='$key' ";
    	}
	    $keync=urlencode($key);
	    $pageadd="&keytype=$keytype&key=$keync";
    }	
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wallad_record').$where);
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 30;
    if($counts) {
	    $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wallad_record')." $where ORDER BY dateline DESC LIMIT $starts,30");
	    $manylist = $manylists = array();
	    while($manylist = DB::fetch($query)){
	        $manylists[] = $manylist;
	    }
    }
	$multis = "<div class='pages cl' style='margin:5px'>".multi($counts, 30, $pages, "plugin.php?id=xlwsq_wallad:xlwsq_wallad_user&p=".$p.$pageadd)."</div>";
} elseif ($p == 'add') {
    include_once 'source/plugin/xlwsq_wallad/class/upic.class.php';
    include_once 'source/plugin/xlwsq_wallad/class/watermark.class.php';
    $groups = unserialize($groups);
    if (!in_array($_G['groupid'], $groups)) {
		showmessage(lang('plugin/xlwsq_wallad','wuquanxiancaozuo'), dreferer());
    } else {
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE uid='$_G[uid]'");
	    if ($countr >= $xianzhishuliang && $xianzhishuliang!='0' && $_G['groupid'] != "1" && !in_array($_G['uid'], $admins)) {
            if(!$_G['uid']){
                !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
            } else {
		        showmessage(lang('plugin/xlwsq_wallad', 'xianzhitishi').$xianzhishuliang.lang('plugin/xlwsq_wallad', 'tiaoxinxi'), dreferer());
	        }
	    }
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
        while ($row = DB::fetch($query)) {
            $cates[$row['id']] = $row;
        }
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
        while ($row = DB::fetch($query)) {
            $areas[$row['id']] = $row;
        }
	    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
        $paymoney = getuserprofile('extcredits'."$paytype");
        if(($credit!="0" && $paytype)&&!$_G['uid']){
            $tixing= lang('plugin/xlwsq_wallad', 'xiaohaotishi').$credit.$moneytype.lang('plugin/xlwsq_wallad', 'xiaohaotishi2');
	        showmessage(lang('plugin/xlwsq_wallad',$tixing) , '', array() , array('login' => true));
        }
        if (submitcheck('applysubmit')) {
            $uid = intval($_G['uid']);
            $title = dhtmlspecialchars($_GET['title']);
			if($badword) {
                $title = strtr($title, $badwordfilter);
			}
            $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
            $area = intval($_GET['area_two']) ? intval($_GET['area_two']) : intval($_GET['area_1']);
            $info =dhtmlspecialchars($_GET['info']);
			if($badword) {
                $info = strtr($info, $badwordfilter);
			}
            $lianxiren = dhtmlspecialchars($_GET['lianxiren']);
            $tel = dhtmlspecialchars($_GET['tel']);
            $qq = dhtmlspecialchars($_GET['qq']);
            $weixin = dhtmlspecialchars($_GET['weixin']);
            $endtime = dhtmlspecialchars($_GET['endtime']);
            $price = dhtmlspecialchars($_GET['price']);
            $pic1 = dhtmlspecialchars($_GET['pic1']);
            $pic2 = dhtmlspecialchars($_GET['pic2']);
            $pic3 = dhtmlspecialchars($_GET['pic3']);
            $pic4 = dhtmlspecialchars($_GET['pic4']);
            $pic5 = dhtmlspecialchars($_GET['pic5']);
	        if ($_GET['endtime'] != "") {$endtime=strtotime($_GET['endtime']);} else {$endtime = 0;}
            $top = intval($_GET['top']);
            $tuijian = intval($_GET['tuijian']);
            if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins) || in_array($_G['groupid'], $mianshenhe)) {
                $display = 1;
            } else {
                $display = 0;
            }
            $diynum = intval($_GET['diynum']);
            $color = dhtmlspecialchars($_GET['color']);
            $password = dhtmlspecialchars($_GET['password']);
	        if(!$password && !$uid){
		           showmessage(lang('plugin/xlwsq_wallad', 'youkexushezhimima'),'');
	        }
            if($credit!="0" && $paytype){
                if($paymoney<$credit){
                    $tixing= lang('plugin/xlwsq_wallad', 'xiaohaotishi').$credit.$moneytype;
                    if (empty($chongzhiurl)) {
	                    showmessage($tixing, dreferer());
	                }else{
                        showmessage($tixing, 'plugin.php?id=xlwsq_wallad&mod=chongzhi', array() , array('alert' => 'error'));
                    }
                }
            }
            for ($i = 1; $i <= 5; $i++) {
                $pic = 'pic'.$i;
                $spic = 'spic'.$i;
                if ($_FILES[$pic]['tmp_name']) {
				    $picsize = $_FILES[$pic]['size'];
                    $picname = $_FILES[$pic]['name'];
				    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
				       if ($imageinfo[0] <= 0) {
                          showmessage(lang('plugin/xlwsq_wallad', 'tupiangeshibuzhengque'));
				       }
                    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                    $arr = explode(".", $_FILES[$pic]["name"]);
                    $hz = $arr[count($arr) - 1];
                    if (!in_array($hz, $filetype)) {
                       showmessage(lang('plugin/xlwsq_wallad', 'tupiangeshibuzhengque'));
                    }
                    $update = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999);
                    $pics =$update. "." . $hz;
                    $spics =$update .  "_s" ."." . $hz;
					$img_dir = "source/plugin/xlwsq_wallad/upimg/" . date("Ymd") . "/";
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $$pic = $img_dir . $pics;
					$$spic = $img_dir. $spics;
                    if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
						@copy($_FILES[$pic]['tmp_name'], $$spic);
                        @unlink($_FILES[$pic]['tmp_name']);
                    }
					if ($imageinfo[0] > 300) {
						imageUpdateSize($$spic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/300));
					}
				    if ($picsize > $newpicdx) {
						if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
							imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$newpicwidth));
							
                        }else{
							imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]);
						}
					}
                    if($imgwater && $imageinfo[0] > $waterwidth){
	                   imageUpdateLogo($$pic,$imgwater);
                    }
              }
              $pic= dhtmlspecialchars($pic);
            }
            $newsid = DB::insert('plugin_xlwsq_wallad_item', array('id'=>NULL), true);
            if($credit!="0" && $paytype){
	            updatemembercount($_G['uid'], array($paytype => -$credit));
			    DB::insert('plugin_xlwsq_wallad_record',array('id' => '','sid' => $newsid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $title,'pay' => $credit,'moneytype' => $moneytype,'xftype' => '1','dateline' =>$_G['timestamp']));
            }
            DB::update('plugin_xlwsq_wallad_item', array('uid' => $uid,'author' => $_G['username'],'title' => $title,'cate' => $cate,'area' => $area,'info' => $info,'lianxiren' => $lianxiren,'tel' => $tel,'qq' => $qq,'weixin' => $weixin,'endtime' => $endtime,'price' => $price,'pic1' => $pic1,'pic2' => $pic2,'pic3' => $pic3,'pic4' => $pic4,'pic5' => $pic5,'spic1' => $spic1,'spic2' => $spic2,'spic3' => $spic3,'spic4' => $spic4,'spic5' => $spic5,'top' => $top,'tuijian' => $tuijian,'display' => $display,'diynum' => $diynum,'color' => $color,'dateline' => $_G['timestamp'],'updateline' => $_G['timestamp'],'password' => $password,), "id='$newsid'");
            if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins) || in_array($_G['groupid'], $mianshenhe)) {
                showmessage(lang('plugin/xlwsq_wallad', 'fabuchenggong') , 'plugin.php?id=xlwsq_wallad', array() , array('alert' => 'right'));
            } else {
                for ($i = 0; $i < count($admins); $i++) {
                    $message = '<a href="plugin.php?id=xlwsq_wallad&#58;xlwsq_wallad_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_wallad', 'yonghufabuxinxinxi') . '</a>';
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                }
                showmessage(lang('plugin/xlwsq_wallad', 'fabudengdaishenhe') , 'plugin.php?id=xlwsq_wallad', array() , array('alert' => 'right'));
            }
        }
    }

} elseif ($p == 'edit') {
    include_once 'source/plugin/xlwsq_wallad/class/upic.class.php';
    include_once 'source/plugin/xlwsq_wallad/class/watermark.class.php';
    $id = intval($_GET['sid']);
    $password = dhtmlspecialchars($_GET['password']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id='$id'");
    if(submitcheck('applysubrenling')){
       if($password != $active['password']){
          showmessage(lang('plugin/xlwsq_wallad', 'koulingcuowu'));
       }
    }  
    $uid = intval($active['uid']);
    if (empty($active['uid'])||(!empty($active['uid']) && $active['uid'] == $_G['uid']) || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_wallad', 'caozuocuowu') , '', array() , array('login' => true));
    }
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    $areaid = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id='$active[area]'");
    if ($areaid) {
        $areatwoshow = '<select name="area_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE upid='$areaid'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['area']) {
                $areatwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $areatwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $areatwoshow.= '</select>';
    } else {
        $areaid = $active['area'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $areas[$row['id']] = $row;
    }
    if (submitcheck('applysubmit')) {
         if ((!empty($active['uid']) && $active['uid'] == $_G['uid']) || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
	         } elseif ($active['password'] !=$password){
               showmessage(lang('plugin/xlwsq_wallad', 'koulingcuowu'));
		 } 
        $sid = intval($_GET['sid']);
        $title = dhtmlspecialchars($_GET['title']);
		if($badword) {
            $title = strtr($title, $badwordfilter);
		}
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $area = intval($_GET['area_two']) ? intval($_GET['area_two']) : intval($_GET['area_1']);
        $info = dhtmlspecialchars($_GET['info']);
		if($badword) {
            $info = strtr($info, $badwordfilter);
		}
        $tel = dhtmlspecialchars($_GET['tel']);
        $qq = dhtmlspecialchars($_GET['qq']);
        $weixin = dhtmlspecialchars($_GET['weixin']);
        $lianxiren = dhtmlspecialchars($_GET['lianxiren']);
	    if ($_GET['endtime'] != "") {$endtime=strtotime($_GET['endtime']);} else {$endtime = 0;}
        $price = dhtmlspecialchars($_GET['price']);
        $pic1 = dhtmlspecialchars($_GET['pic1']);
        $pic2 = dhtmlspecialchars($_GET['pic2']);
        $pic3 = dhtmlspecialchars($_GET['pic3']);
        $pic4 = dhtmlspecialchars($_GET['pic4']);
        $pic5 = dhtmlspecialchars($_GET['pic5']);
        $spic1 = dhtmlspecialchars($_GET['spic1']);
        $spic2 = dhtmlspecialchars($_GET['spic2']);
        $spic3 = dhtmlspecialchars($_GET['spic3']);
        $spic4 = dhtmlspecialchars($_GET['spic4']);
        $spic5 = dhtmlspecialchars($_GET['spic5']);
        $top = intval($_GET['top']);
        $tuijian = intval($_GET['tuijian']);
        if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)|| in_array($_G['groupid'], $mianshenhe)) {
            $display = 1;
        } else {
            $display = 0;
        }
        $diynum = intval($_GET['diynum']);
        $color = dhtmlspecialchars($_GET['color']);
        $timestamp = $_G['timestamp'];
        for ($i = 1; $i <= 5; $i++) {
            $pic = 'pic'.$i;
            $spic = 'spic'.$i;
            $picdel = 'picdelete'.$i;
			    if ($_GET[$picdel]==1){
		            unlink($active[$pic]);
		            unlink($active[$spic]);
                    $$pic = "";
                    $$spic = "";
	            }
           if ($_FILES[$pic]['tmp_name']) {
			    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
				if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_wallad', 'tupiangeshibuzhengque'));
			    }
			   	if ($active[$pic]!=false){
		            unlink($active[$pic]);
	            }
			   	if ($active[$spic]!=false){
		            unlink($active[$spic]);
	            }
				$picsize = $_FILES[$pic]['size'];
                $picname = $_FILES[$pic]['name'];
                    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                    $arr = explode(".", $_FILES[$pic]["name"]);
                    $hz = $arr[count($arr) - 1];
                    if (!in_array($hz, $filetype)) {
                       showmessage(lang('plugin/xlwsq_wallad', 'tupiangeshibuzhengque'));
                    }
                    $update = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999);
                    $pics =$update. "." . $hz;
                    $spics =$update .  "_s" ."." . $hz;
					$img_dir = "source/plugin/xlwsq_wallad/upimg/" . date("Ymd") . "/";
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $$pic = $img_dir . $pics;
					$$spic = $img_dir. $spics;
                    if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
						@copy($_FILES[$pic]['tmp_name'], $$spic);
                        @unlink($_FILES[$pic]['tmp_name']);
                    }
					if ($imageinfo[0] > 300) {
						imageUpdateSize($$spic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/300));
					}
				    if ($picsize > $newpicdx) {
						if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
							imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$newpicwidth));
							
                        }else{
							imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]);
						}
					}
                    if($imgwater && $imageinfo[0] > $waterwidth){
	                   imageUpdateLogo($$pic,$imgwater);
                    }
           }
           $pic= dhtmlspecialchars($pic);
        }
        DB::update('plugin_xlwsq_wallad_item', array(
            'title' => $title,
            'cate' => $cate,
            'area' => $area,
            'info' => $info,
            'lianxiren' => $lianxiren,
            'tel' => $tel,
            'qq' => $qq,
            'weixin' => $weixin,
            'price' => $price,
            'pic1' => $pic1,
            'pic2' => $pic2,
            'pic3' => $pic3,
            'pic4' => $pic4,
            'pic5' => $pic5,
            'spic1' => $spic1,
            'spic2' => $spic2,
            'spic3' => $spic3,
            'spic4' => $spic4,
            'spic5' => $spic5,
            'top' => $top,
            'endtime' => $endtime,
            'tuijian' => $tuijian,
            'color' => $color,
            'display' => $display,
            'diynum' => $diynum
        ) , "id='$sid'");
        if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)|| in_array($_G['groupid'], $mianshenhe)) {
			showmessage(lang('plugin/xlwsq_wallad', 'gengxinok') , 'plugin.php?id=xlwsq_wallad&mod=view&sid='.$sid , array() , array('alert' => 'right'));
        } else {
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_wallad&#58;xlwsq_wallad_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_wallad', 'yonghufabuxinxinxi') . '</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
            showmessage(lang('plugin/xlwsq_wallad', 'fabudengdaishenhe') , 'plugin.php?id=xlwsq_wallad', array() , array('alert' => 'right'));
        }
    }
}elseif($p=='xfjl'){
    $where=$pageadd="";
    $key=stripsearchkey($_GET['key']);
    if($_GET['key']){
	    $where="title like '%".addcslashes(addslashes($key), '%')."%_' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	$uid = intval($_G['uid']);
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wallad_record')." WHERE $where uid='$uid'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
        $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wallad_record')." WHERE $where uid='$uid' ORDER BY id DESC LIMIT $starts,20");
	    $manylist = $manylists = array();
	    while($manylist = DB::fetch($query)){
		    $manylists[] = $manylist;
	    }
    }
	$multis = "<div class='pages cl' style='margin-top:10px'>".multi($counts, 20, $pages, 'plugin.php?id=xlwsq_wallad:xlwsq_wallad_user&p='.$p.$pageadd)."</div>";
} elseif ($p == 'favorites') {
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_favorites') . " WHERE  $where uid='$uid'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 20;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_favorites') . " WHERE  $where uid = '$uid' ORDER BY dateline DESC LIMIT $starts,20");
        $sc = $scs = array();
        while ($sc = DB::fetch($query)) {
            $scs[] = $sc;
        }
    }
    $multis = "<div class='pages cl'style='margin-top:10px'>" . multi($counts, 20, $pages, 'plugin.php?id=xlwsq_wallad:xlwsq_wallad_user&p='.$p. $pageadd) . "</div>";
} elseif ($p == 'favoritesdel') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if ($_GET['formhash'] == FORMHASH) {
        DB::query("DELETE FROM " . DB::table('plugin_xlwsq_wallad_favorites') . " WHERE id = '$id' and uid = '$uid'");
        showmessage(lang('plugin/xlwsq_wallad', 'shanchuok') , dreferer());
    }
} elseif ($p == 'shenheok') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET display='1' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_wallad', 'shenheok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_wallad', 'caozuocuowu'));
    }
 
} elseif ($p == 'qxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET display='0' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_wallad', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_wallad', 'caozuocuowu'));
    }
} elseif ($p == 'complete') {
    $uid = intval($_G['uid']);
    $sid = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id='$sid'");
    if ($active['uid']==$uid && !empty($active['uid'])) {
        if ($_GET['formhash'] == FORMHASH) {
            if ($active['endtime']!=0) {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET endtime='0'  WHERE id='$sid'");
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET endtime='$_G[timestamp]' WHERE id='$sid'");
            }
                showmessage(lang('plugin/xlwsq_wallad', 'gengxinok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_wallad', 'caozuocuowu'));
    }
} elseif ($p == 'onekeydel') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins) && $_GET['formhash'] == FORMHASH) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE (endtime != 0 && endtime < $_G[timestamp])");
		while ($daoqi = DB::fetch($query)) {
		    for ($i = 1; $i <= 5; $i++) {
                $pic = 'pic'.$i;
		        unlink($daoqi[$pic]);
            }
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE (endtime != 0 && endtime < $_G[timestamp])");
        }
        showmessage(lang('plugin/xlwsq_wallad', 'shanchuok') , dreferer());
    } else {
        showmessage(lang('plugin/xlwsq_wallad', 'caozuocuowu'));
    }
} elseif ($p == 'del') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id ='$id'");
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||($active['uid']==$uid && !empty($active['uid']))||(empty($active['uid']) && $active['password']==$_GET['password'])) {
        if ($_GET['formhash'] == FORMHASH) {
             for ($i = 1; $i <= 5; $i++) {
               $pic = 'pic'.$i;
		       unlink($active[$pic]);
             }
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id = '$id'");
            showmessage(lang('plugin/xlwsq_wallad', 'shanchuok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_wallad', 'caozuocuowu'));
    }
}
include (template("xlwsq_wallad:xlwsq_wallad_user"));
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
//From: Dism_taobao-com
?>