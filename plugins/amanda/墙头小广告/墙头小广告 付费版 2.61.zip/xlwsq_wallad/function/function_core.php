<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$catecachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_wallad_catecachedata.php';
$areacachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_wallad_areacachedata.php';
if(file_exists($catecachefile)){
		require_once DISCUZ_ROOT.'data/sysdata/cache_xlwsq_wallad_catecachedata.php';
}else{
	xlwsq_wallad_updatacatecache();
}
if(file_exists($areacachefile)){
		require_once DISCUZ_ROOT.'data/sysdata/cache_xlwsq_wallad_areacachedata.php';
}else{
	xlwsq_wallad_updataareacache();
}
function  xlwsq_wallad_updatacatecache(){
	require_once libfile('function/cache');
    $typecatequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
    $typecatedata = array();
    $upidcatedata = array();
    while ($typecate = DB::fetch($typecatequery)) {
        $typecatedata[$typecate['id']] = $typecate;
        $upidcatequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " where upid = " . $typecate['id'] . "  ORDER BY displayorder DESC,id ASC");
        while ($upidcate = DB::fetch($upidcatequery)) {
            $upidcatedata[$typecate['id']][$upidcate['id']] = $upidcate;
        }
    }
	writetocache('xlwsq_wallad_catecachedata', getcachevars(array('typecatedata' => $typecatedata,  'upidcatedata' => $upidcatedata)));
}
function  xlwsq_wallad_updataareacache(){
	require_once libfile('function/cache');
    $typeareaquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
    $typeareadata = array();
    $upidareadata = array();
    while ($typearea = DB::fetch($typeareaquery)) {
        $typeareadata[$typearea['id']] = $typearea;
        $upidareaquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " where upid = " . $typearea['id'] . "  ORDER BY displayorder DESC,id ASC");
        while ($upidarea = DB::fetch($upidareaquery)) {
            $upidareadata[$typearea['id']][$upidarea['id']] = $upidarea;
        }
    }
	writetocache('xlwsq_wallad_areacachedata', getcachevars(array('typeareadata' => $typeareadata,  'upidareadata' => $upidareadata)));
}
//From: Dism_taobao-com
?>