<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/xlwsq_wallad/function/function_core.php';
global $_G;
if (!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plyes=($_G['cache']['plugin']['xlwsq_wallad']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
$mainwidth = intval($mainwidth);
$liwidth = intval($liwidth);
$liheight = intval($liheight);
$neirongliheight =$liheight-146;
if($_G['mobile']) {
    $menubgcolor=$mobilemenubgcolor;
    $eacha=$mobileeacha ? $mobileeacha : $eacha;
    $footad=$mobilefootad ? $mobilefootad : $footad;
}
$fabuset = unserialize($groups);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$viewgroups = unserialize($viewgroups);
$navtitle = $title;
$creditc = abs($creditc);
$creditd = abs($creditd);
$_G['uid'] = $_G['uid'] ? $_G['uid'] : '0';
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if($mod == 'index') {
    $where=$pageadd="";
    if ($_GET['key']) {
        $key=stripsearchkey($_GET['key']);
		$where="title like '%".addcslashes(addslashes($key), '%_')."%' AND display!='0' OR info like '%" . addcslashes(addslashes($key), '%_') . "%'  AND display!='0' AND";
        $keync = urlencode($key);
        $pageadd = "&key=$keync";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$cate_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
        $av_d[$cate_id] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $sd = intval($_GET['b']);
    if ($sd) {
        $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$sd'");
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
        $av_d[$sd] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }

    $b_area_id = intval($_GET['bc']);
    if ($b_area_id) {
        $marea = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$b_area_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id='$b_area_id'");
        if ($subids) {
            $b_area = "area IN ($b_area_id,$subids) AND";
        } else {
            $b_area = "area=$b_area_id AND";
        }
        $pageaddbc = "&bc=$b_area_id";
        $av_dc[$b_area_id] = ' class="cur-on"';
    } else {
        $av_dc[0] = ' class="cur-on"';
    }
    $s_area_id = intval($_GET['sc']);
    if ($s_area_id) {
        $mareab = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$s_area_id'");
        $s_area = "area='$s_area_id' AND";
        $pageaddsc = "&sc=$s_area_id";
        $av_dc[$s_area_id] = ' class="cur-on"';
    } else {
        $av_dc[0] = ' class="cur-on"';
    }
    if ($guoqixianshi==0){
		$daoqishijian = "AND (endtime = 0 OR endtime > $_G[timestamp])";
    }
    if ($_GET['tj']) {
		$px="tuijian = '1' AND display='1' $daoqishijian ORDER BY dateline DESC"; $pageadd="&tj=t";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE $where $wb $wc $b_area $s_area tuijian = '1' AND display='1' $daoqishijian");
    }elseif ($_GET['jdq']) {
		$px="display='1' AND (endtime != 0 && endtime > $_G[timestamp]) ORDER BY endtime ASC"; $pageadd="&jdq=jdq";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE $where $wb $wc $b_area $s_area display='1' AND (endtime != 0 && endtime > $_G[timestamp])");
    }elseif ($_GET['jg']) {
		$px="display='1' AND price>'0' $daoqishijian ORDER BY price ASC"; $pageadd="&jg=jg";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE $where $wb $wc $b_area $s_area display='1' AND price>'0' $daoqishijian");
    }elseif ($_GET['rq']) {
		$px="display='1' AND view>'0' $daoqishijian ORDER BY view DESC"; $pageadd="&rq=rq";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE $where $wb $wc $b_area $s_area display='1' AND view>'0' $daoqishijian");
    }elseif ($_GET['wgq']) {
		$px="display='1' AND (endtime = 0 OR endtime > $_G[timestamp]) ORDER BY top DESC,topdateline DESC,diynum DESC,updateline DESC";$pageadd="&wgq=wgq";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE $where $wb $wc $b_area $s_area display='1' AND (endtime = 0 OR endtime > $_G[timestamp])");	
	}else{
		$px="display='1' $daoqishijian ORDER BY top DESC,topdateline DESC,diynum DESC,updateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE $where $wb $wc $b_area $s_area display='1' $daoqishijian");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE $where $wb $wc $b_area $s_area $px LIMIT $starts,$eacha");
        $mythread = $mythreads = array();
        while ($mythread = DB::fetch($query)) {
            if ($mythread['topdateline']!='0'){DB::query("UPDATE ".DB::table('plugin_xlwsq_wallad_item')." SET `topdateline` = '0',`color` = '' WHERE topdateline <= ".time());}
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$cate[upid]'");
                $mythread['catecid'] = $cate['upid'];
                $mythread['catescid'] = $mythread['cate'];
				$mythread['catename'] = $cate_t['subject'].' - '.$cate['subject'];
            } else {
                $mythread['catecid'] = $mythread['cate'];
                $mythread['catescid'] ='0';
                $mythread['catename'] = $cate['subject'];
            }
            $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$mythread[area]'");
            if ($area['upid'] != 0) {
                $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$area[upid]'");
                $mythread['areacid'] = $area['upid'];
                $mythread['areascid'] = $mythread['area'];
			    $mythread['areaname'] = $area_t['subject'].' - '.$area['subject'];
            } else {
                $mythread['areacid'] = $mythread['area'];
                $mythread['areascid'] ='0';
                $mythread['areaname'] = $area['subject'];
            }
			$mythread['dinfo'] = discuzcode($mythread['info']);
			$mythread['info'] = strip_tags(discuzcode($mythread['info']));
			if($badword) {
                $str = "/".$badword."/";
                $mythread['dinfo'] = preg_replace($str, "*", $mythread['dinfo']);
                $mythread['info'] = preg_replace($str, "*", $mythread['info']);
                $mythread['title'] = preg_replace($str, "*", $mythread['title']);
			}
		    $mythread['price'] = setmoneyUnit($mythread['price']);
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px 10px 10px 0;'>" . multi($counts, $eacha, $pages, 'plugin.php?id=xlwsq_wallad' . $pageadd. $pageadds . $pageaddx . $pageaddbc . $pageaddsc) . "</div>";
    $r_id = intval($_GET['a']);
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    $bc_id = intval($_GET['bc']);
    $bc_subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id='$bc_id'");
    if ($bc_subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id IN ($bc_subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $local_sc[$ros['id']] = $ros;
        }
    }
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . "-" . $mcateb['subject']. "-";
      } else {
           $catenav = $mcate['subject']. "-";
      }
    }
    if ($b_area_id!='0') {
      if ($s_area_id!='0') {
           $areanav = $marea['subject'] . "-" . $mareab['subject']. "-";
      } else {
           $areanav = $marea['subject']. "-";
      }
    }
    $navtitle = $catenav . $areanav.$navtitle;
    include template('xlwsq_wallad:list');
} elseif ($_GET['mod'] == 'view') {
    $sid = intval($_GET['sid']);
    if($_G['groupid']==1 || in_array($_G['uid'], $admins)){
	   $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id = '$sid'");
	}else{
	   $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wallad_item')." WHERE id = '$sid' AND display!='0'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_wallad', 'error') , "plugin.php?id=xlwsq_wallad") : '';
    DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET `view` = view+1 WHERE `id` = '$sid'");
    $mythread['info'] = discuzcode($mythread['info']);
	if($badword) {
        $str = "/".$badword."/";
        $mythread['info'] = preg_replace($str, "*", $mythread['info']);
        $mythread['title'] = preg_replace($str, "*", $mythread['title']);
	}
    $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_favorites') . " WHERE sid = '$sid' AND uid = '$_G[uid]'");
    if ($guoqixianshi==0){
		$daoqishijian = "AND (endtime = 0 OR endtime > $_G[timestamp])";
    }
    $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$mythread[cate]'");
	if ($cate['upid'] != 0) {
        $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$cate[upid]'");
        $mythread['cate'] = $cate_t['subject'] . " - " . $cate['subject'];
        $mythread['b'] = $cate['id'];
        $mythread['a'] = $cate['upid'];
    } else {
        $mythread['cate'] = $cate['subject'];
        $mythread['a'] = $cate['id'];
        $mythread['b'] = '0';
    }
    $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$mythread[area]'");
    if ($area['upid'] != 0) {
        $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$area[upid]'");
        $mythread['area'] = $area_t['subject'] . " - " . $area['subject'];
        $mythread['d'] = $area['id'];
        $mythread['c'] = $area['upid'];
    } else {
        $mythread['area'] = $area['subject'];
        $mythread['c'] = $area['id'];
        $mythread['d'] = '0';
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wallad_item')." WHERE tuijian='1'  AND cate='$mythread[cate]' AND id!='$mythread[id]'  AND display!='0' $daoqishijian ORDER BY updateline DESC LIMIT 10");
	$tuijian = $tuijians = array();
	while($tuijian = DB::fetch($query)){
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$tuijian[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$cate[upid]'");
            $tuijian['cate'] = $cate_t['subject'] .' - '.$cate['subject'];
        } else {
            $tuijian['cate'] = $cate['subject'];
        }
        $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$tuijian[area]'");
        if ($area['upid'] != 0) {
            $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$area[upid]'");
            $tuijian['area'] = $area_t['subject']." - ".$area['subject'];
        } else {
            $tuijian['area'] = $area['subject'];
        }
		$tuijian['price'] = setmoneyUnit($tuijian['price']);
		$tuijians[] = $tuijian;
	}
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE view >'0'  AND cate='$mythread[cate]' AND id!='$mythread[id]'  AND display!='0' $daoqishijian ORDER BY view DESC LIMIT 10");
    $hot = $hots = array();
    while ($hot = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$hot[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_cate') . " WHERE id = '$cate[upid]'");
            $hot['cate'] = $cate_t['subject'] .' - '.$cate['subject'];
        } else {
            $hot['cate'] = $cate['subject'];
        }
        $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$hot[area]'");
        if ($area['upid'] != 0) {
            $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_area') . " WHERE id = '$area[upid]'");
            $hot['area'] = $area_t['subject']." - ".$area['subject'];
        } else {
            $hot['area'] = $area['subject'];
        }
		$hot['price'] = setmoneyUnit($hot['price']);
        $hots[] = $hot;
    }
    $navtitle = $mythread['title'] . " - " . $title;
	$metakeywords = $mythread['title'];
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($mythread['dinfo']) , 80, '...'));
    include template('xlwsq_wallad:view');
} elseif ($_GET['mod'] == 'zhiding') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditc == '0'||!$paytype){
		showmessage(lang('plugin/xlwsq_wallad', 'zhidinggongnengweikaifang'));
	}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id = '$sid'");
    if($item['top']=="1"){
		showmessage(lang('plugin/xlwsq_wallad', 'yizhiding'), array(), array('alert' => 'error'));
	}
    $color = dhtmlspecialchars($_GET['topcolor']);
	$daytime = intval($_GET['day']);
	$time = ($daytime * 86400)+$_G['timestamp']; 
    $newcreditc = $daytime * $creditc; 
    $moneytypec = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubzhiding')){
	    if($_GET['day']<="0"){	
		    showmessage(lang('plugin/xlwsq_wallad', 'zhidingtianshuweitianxie'), dreferer());
	    }else{
            if($paymoney<$newcreditc){
                $tixing= lang('plugin/xlwsq_wallad', 'zhidingxiaohaotishi').$newcreditc.$moneytypec;
        	    showmessage(lang('plugin/xlwsq_wallad', $tixing));
            }else{
                DB::insert('plugin_xlwsq_wallad_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'day' => $daytime,'pay' => $newcreditc,'moneytype' => $moneytypec,'xftype' => '2','endtime' => $time,'dateline' =>$_G['timestamp']));
				DB::query("UPDATE ".DB::table('plugin_xlwsq_wallad_item')." SET `topdateline` = '$time' , `color` = '$color' WHERE `id` = '$sid'");	                   updatemembercount($_G['uid'], array($paytype => -$newcreditc));
            }
			showmessage(lang('plugin/xlwsq_wallad', 'tijiaochenggong'),dreferer());
        }
	}
	include template('xlwsq_wallad:zhiding');
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
        $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id = '$sid'");
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_wallad_favorites') . " WHERE sid = '$sid' and uid = '$uid'");
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_wallad', 'quxiaoshoucang'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_wallad', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
			}
        } else {
            DB::insert('plugin_xlwsq_wallad_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'title' => $info['title'],'dateline' => $_G['timestamp']));
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_wallad', 'shoucangchenggong'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_wallad', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
			}
        }
    }
} elseif ($_GET['mod'] == 'miaoshen') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditd == '0'||!$paytype){showmessage(lang('plugin/xlwsq_wallad', 'miaoshenweikaiqi'));}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id = '$sid'");
    if($item['display']=="1"){
		showmessage(lang('plugin/xlwsq_wallad', 'miaoshentongguo'), array(), array('alert' => 'error'));
	}
    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubmiaoshen')){
        if($paymoney<$creditd){
            $tixing= lang('plugin/xlwsq_wallad', 'miaoshenshibai').$creditd.$moneytype;
        	showmessage(lang('plugin/xlwsq_wallad', $tixing));
        }else{
			DB::query("UPDATE ".DB::table('plugin_xlwsq_wallad_item')." SET `display` = '1' WHERE `id` = '$sid'");
			updatemembercount($_G['uid'], array($paytype => -$creditd));
			DB::insert('plugin_xlwsq_wallad_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'pay' => $creditd,'moneytype' => $moneytype,'xftype' => '4','dateline' =>$_G['timestamp']));
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_wallad&mod=view&sid='.$item[id].'" target="_blank">'.lang('plugin/xlwsq_wallad', 'miaoshenweisend').$item[title].'</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
		    if($_G['mobile']) {
                showmessage(lang('plugin/xlwsq_wallad', 'tijiaochenggong') , 'plugin.php?id=xlwsq_wallad:xlwsq_wallad_user&amp;p=mylist', array() , array('alert' => 'right'));
		   	} else {
                showmessage(lang('plugin/xlwsq_wallad', 'tijiaochenggong'),dreferer());
			}
        }
	}
	include template('xlwsq_wallad:miaoshen');
} elseif ($_GET['mod'] == 'freshen') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $now = date('Y-m-d', $_G['timestamp']);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id = '$sid'");
    $uid = intval($info['uid']);
    $updateline = date('Y-m-d', $info['updateline']);
    if ($_GET['formhash'] == FORMHASH) {
        if ($info['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
            if ($now == $updateline) {
                showmessage(lang('plugin/xlwsq_wallad', 'shuaxinshibai') , '', array() , array('alert' => 'error'));
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_wallad_item') . " SET `updateline` = '$_G[timestamp]' WHERE `id` = '$sid'");
                DB::insert('plugin_xlwsq_wallad_record',array('id' => '','sid' => $sid,'title' => $info['title'],'xftype' => '3','uid' => $_G['uid'],'author' => $_G['username'],'dateline' =>$_G['timestamp']));
                showmessage(lang('plugin/xlwsq_wallad', 'shuaxinok') , '', array() , array('alert' => 'right'));
            }
        } else {
            showmessage(lang('plugin/xlwsq_wallad', 'caozuocuowu') , dreferer());
        }
    }
} elseif ($_GET['mod'] == 'chongzhi') {
    $refererurl = $_SERVER["HTTP_REFERER"];
    if ($chongzhifanhui == '1') {
        header('Location: ' . $chongzhiurl);
    } else{
	    include template('xlwsq_wallad:chongzhi');
    }
} elseif ($_GET['mod'] == 'report') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id = '$sid'");
	if(submitcheck('addreport')){
        $url = 'plugin.php?id=xlwsq_wallad&mod=view&sid='.$sid;
		$urlkey = md5($url);
    	$message =cutstr(dhtmlspecialchars(trim($_GET['message'])), 300, '');
	    if($reportid = C::t('common_report')->fetch_by_urlkey($urlkey)) {
		    C::t('common_report')->update_num($reportid, $message);
	    }else {
		    DB::insert('common_report',array('id' => '','urlkey' => $urlkey,'url' => $url,'message' => $message,'uid' => $_G['uid'],'username' =>$_G[username],'num' => '1', 'dateline' => $_G['timestamp']));
	    }
        for ($i = 0; $i < count($admins); $i++) {
            notification_add($admins[$i], 'report', 'new_report', array('from_id' => 1, 'from_idtype' => 'newreport'), 1);
        }
        showmessage(lang('plugin/xlwsq_wallad', 'tijiaochenggong') , 'plugin.php?id=xlwsq_wallad&mod=view&sid='.$sid, array() , array('alert' => 'right'));
	}
    include template('xlwsq_wallad:report');
}elseif($_GET['mod']=='renling'||$_GET['mod']=='youkedel'){
   if($_GET['mod']=='renling'){!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';}
   $sid = intval($_GET['sid']);
   $password = dhtmlspecialchars($_GET['password']);
   $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wallad_item') . " WHERE id = '$sid'");
   !$info ? showmessage(lang('plugin/xlwsq_wallad', 'error') , "plugin.php?id=xlwsq_wallad") : '';
   if(submitcheck('applysubrenling')){
       if($password == $info['password']){
          DB::update('plugin_xlwsq_wallad_item', array('password' => '','uid' => $_G['uid'],'author' => $_G['username']),"id='$sid'");
          showmessage(lang('plugin/xlwsq_wallad', 'renlingchenggong'), 'plugin.php?id=xlwsq_wallad', array(), array('alert' => 'right'));
       }else{
          showmessage(lang('plugin/xlwsq_wallad', 'koulingcuowu'));
       }
   }    
   include template('xlwsq_wallad:kouling');
}elseif($_GET['mod']=='qrpic'){
    include_once 'source/plugin/xlwsq_wallad/class/qrcode.class.php';
    $sid = intval($_GET['sid']);
    if($html == 1){
        $value=$_G['siteurl'].$mininame.'_'.$sid.'.html';
    }else{
        $value=$_G['siteurl'].'plugin.php?id=xlwsq_wallad&mod=view&sid='.$sid;
    }
    $errorCorrectionLevel = "L";
    $matrixPointSize = "6";
    QRcode::png($value, false, $errorCorrectionLevel, $matrixPointSize);
}
function setmoneyUnit($nprice) {
    if($nprice >= 10000){
        $showMoeny = (int)($nprice/100);
        return ($showMoeny/100).lang('plugin/xlwsq_wallad', 'wan');
    }elseif($nprice < 10000){
        $intMoeny = floatval($nprice);
        return $intMoeny;
    }else{
        return  $nprice;
    }
}
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
//From: Dism_taobao-com
?>