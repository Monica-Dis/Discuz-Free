<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wallad_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `author` varchar(80) NOT NULL,
	  `cate` int(11) NOT NULL,
	  `area` int(11) NOT NULL,
	  `title` varchar(50) NOT NULL,
	  `info` text NOT NULL,
   	  `lianxiren` varchar(50) NOT NULL,
   	  `tel`  varchar(20) NOT NULL,
   	  `qq`  varchar(20) NOT NULL,
   	  `weixin`  varchar(60) NOT NULL,
	  `pic1` varchar(255) NOT NULL,
	  `pic2` varchar(255) NOT NULL,
	  `pic3` varchar(255) NOT NULL,
	  `pic4` varchar(255) NOT NULL,
	  `pic5` varchar(255) NOT NULL,
	  `spic1` varchar(255) NOT NULL,
	  `spic2` varchar(255) NOT NULL,
	  `spic3` varchar(255) NOT NULL,
	  `spic4` varchar(255) NOT NULL,
	  `spic5` varchar(255) NOT NULL,
	  `price` double(9,2) NOT NULL,
	  `view` int(11) NOT NULL,
	  `top` tinyint(1)  NOT NULL,
	  `tuijian` tinyint(1)  NOT NULL,
	  `topdateline` int(11) NOT NULL,
	  `color` text NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `updateline` int(11) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  `endtime` int(11) NOT NULL,
   	  `password` varchar(50) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wallad_cate` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wallad_area` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wallad_record` (
	  `id` int(11) NOT NULL auto_increment,
      `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `title` text NOT NULL,
   	  `day` int(11) NOT NULL,
   	  `pay` int(11) NOT NULL,
   	  `moneytype` varchar(20) NOT NULL,
   	  `endtime` int(11) NOT NULL,
   	  `xftype` int(11) NOT NULL,
   	  `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wallad_favorites` (
   	  `id` int(11) NOT NULL auto_increment,
 	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `title` varchar(80) NULL,
   	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;

INSERT INTO `pre_plugin_xlwsq_wallad_cate` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '9,10,11,39,40,41', '$installlang[cate1]', 90),
(2, 0, '12,13', '$installlang[cate2]', 80),
(3, 0, '14,15', '$installlang[cate3]', 70),
(4, 0, '16,17,42,43,44', '$installlang[cate4]', 60),
(5, 0, '18,19,45,46', '$installlang[cate5]', 50),
(6, 0, '20,21,22,24,63,64', '$installlang[cate6]', 40),
(7, 0, '25,26,27,28,47,49,50,51,52,53', '$installlang[cate7]', 30),
(8, 0, '29,30,31,54,55,56,57,58,59,60', '$installlang[cate8]', 10),
(9, 1, '', '$installlang[cate10]', 0),
(10, 1, '', '$installlang[cate11]', 0),
(11, 1, '', '$installlang[cate12]', 0),
(12, 2, '', '$installlang[cate13]', 0),
(13, 2, '', '$installlang[cate14]', 0),
(14, 3, '', '$installlang[cate13]', 0),
(15, 3, '', '$installlang[cate14]', 0),
(16, 4, '', '$installlang[cate19]', 0),
(17, 4, '', '$installlang[cate20]', 0),
(18, 5, '', '$installlang[cate11]', 0),
(19, 5, '', '$installlang[cate16]', 0),
(20, 6, '', '$installlang[cate11]', 0),
(21, 6, '', '$installlang[cate10]', 0),
(22, 6, '', '$installlang[cate16]', 0),
(64, 6, '', '$installlang[cate18]', 0),
(24, 6, '', '$installlang[cate17]', 0),
(25, 7, '', '$installlang[cate21]', 0),
(26, 7, '', '$installlang[cate22]', 0),
(27, 7, '', '$installlang[cate23]', 0),
(28, 7, '', '$installlang[cate24]', 0),
(29, 8, '', '$installlang[cate25]', 0),
(30, 8, '', '$installlang[cate26]', 0),
(31, 8, '', '$installlang[cate27]', 0),
(32, 0, '', '$installlang[cate9]', 100),
(33, 0, '36,37,61', '$installlang[cate28]', 20),
(36, 33, '', '$installlang[cate29]', 0),
(37, 33, '', '$installlang[cate30]', 0),
(61, 33, '', '$installlang[cate31]', 0),
(39, 1, '', '$installlang[cate17]', 0),
(40, 1, '', '$installlang[cate16]', 0),
(41, 1, '', '$installlang[cate18]', 0),
(42, 4, '', '$installlang[cate32]', 0),
(43, 4, '', '$installlang[cate33]', 0),
(44, 4, '', '$installlang[cate18]', 0),
(45, 5, '', '$installlang[cate34]', 0),
(46, 5, '', '$installlang[cate18]', 0),
(47, 7, '', '$installlang[cate35]', 0),
(63, 6, '', '$installlang[cate36]', 0),
(49, 7, '', '$installlang[cate37]', 0),
(50, 7, '', '$installlang[cate38]', 0),
(51, 7, '', '$installlang[cate39]', 0),
(52, 7, '', '$installlang[cate40]', 0),
(53, 7, '', '$installlang[cate18]', 0),
(54, 8, '', '$installlang[cate41]', 0),
(55, 8, '', '$installlang[cate42]', 0),
(56, 8, '', '$installlang[cate43]', 0),
(57, 8, '', '$installlang[cate44]', 0),
(58, 8, '', '$installlang[cate45]', 0),
(59, 8, '', '$installlang[cate46]', 0),
(60, 8, '', '$installlang[cate18]', 0);

INSERT INTO `pre_plugin_xlwsq_wallad_area` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '6', '$installlang[area1]', 0),
(2, 0, '4,5', '$installlang[area2]', 0),
(3, 0, '', '$installlang[area3]', 0),
(4, 2, '', '$installlang[area4]', 0),
(5, 2, '', '$installlang[area5]', 0),
(6, 1, '', '$installlang[area6]', 0);
EOF;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wallad/discuz_plugin_xlwsq_wallad.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wallad/discuz_plugin_xlwsq_wallad_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wallad/discuz_plugin_xlwsq_wallad_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wallad/discuz_plugin_xlwsq_wallad_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wallad/discuz_plugin_xlwsq_wallad_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wallad/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wallad/install.php');
runquery($sql);
$finish =true;
?>