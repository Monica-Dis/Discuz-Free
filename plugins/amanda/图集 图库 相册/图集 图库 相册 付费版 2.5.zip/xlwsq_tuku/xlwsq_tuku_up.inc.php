<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$plyes=($_G['cache']['plugin']['xlwsq_tuku']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
if (file_exists("source/plugin/xlwsq_tuku/qiniusdk/autoload.php") && $pingtaiset==1) {
    require_once 'qiniusdk/autoload.php';
}else{
    include_once 'source/plugin/xlwsq_tuku/class/upic.class.php';
    include_once 'source/plugin/xlwsq_tuku/class/watermark.class.php';
}
$mianshenhe = unserialize($mianshenhe);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$sid = intval($_GET['sid']);
if (!empty($_FILES) && $_GET['formhash'] == FORMHASH) {
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid'");
    if ($maxpic <= $count) {
		 exit ;
	}
	$img_dir = "source/plugin/xlwsq_tuku/upimg/".$sid."/";
	if(!file_exists($img_dir)){ 
		mkdir($img_dir); 
	}
	$picname = $_FILES['Filedata']['tmp_name'];
    $imageinfo = getimagesize($picname);
    if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
        $display = 1;
    } else {
        $display = 0;
    }
	if ($imageinfo[0] > 0) {
	    if($qiniuconfig['upToken']){
            $pic = qiniuupload($_FILES['Filedata']);
            $spic =$pic.$qiniusimg;
	    }else{
            $fileTypes = array('jpg','jpeg','gif','png','JPG','JEPG','GIF','PNG');
            $hz = getExt($_FILES['Filedata']['name']);
            $update = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999);
            $pic =$img_dir .$update. "." . $hz;
            $spic =$img_dir .$update .  "_s" ."." . $hz;
            $fileParts = pathinfo($_FILES['Filedata']['name']);
            if (in_array($hz,$fileTypes)) {
		        @move_uploaded_file($picname,$spic);
			    @copy($spic,$pic);
            }
		    if ($imageinfo[0] > '300') {
                new myThumbClass($spic,1,2,$spic,1,300); 
		    }
		    if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
			    new myThumbClass($pic,1,2,$pic,1,$newpicwidth); 
		    }
            if($imgwater && $imageinfo[0] > $waterwidth){
	            $wm = new WaterMark();
	            $wm->setImSrc($pic);
	            $wm->setImWater($imgwater);
	            $wm->mark(1,$imgwaterweizhi,0,0);
            }
	    }
	    DB::insert('plugin_xlwsq_tuku_img', array('id' => '','sid' => $sid,'img' =>$pic,'simg' =>$spic,'display' => $display,'savearea' => $pingtaiset,'dateline' => $_G['timestamp']));
        $picid = DB::insert_id();
        $piccount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND display!='0'");
	    DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set piccount='$piccount' where id=$sid");
        $fengmiancount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND fengmian='1'");
		if ($fengmiancount == '0') {
	       $pic = $spic ? $spic : $pic;
           DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='0' where sid=$sid");
	       DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='1' where id=$picid");
	       DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set pic='$pic' where id=$sid");
        }
	    echo $pic;
	}
}
function getExt($fileName){
	$ext = explode(".", $fileName);
	$ext = $ext[count($ext) - 1];
	return strtolower($ext);
}
//From: Dism_taobao-com
?>