<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
@require_once 'source/plugin/xlwsq_tuku/function/function_core.php';
require_once libfile('function/discuzcode');
$language = DISCUZ_ROOT.'source/plugin/xlwsq_tuku/language.'.currentlang().'.php';
if(file_exists($language)){
    include_once 'language.'.currentlang().'.php';
}else{
    include_once 'language.php';
}
global $_G;
if (!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plyes=($_G['cache']['plugin']['xlwsq_tuku']);
foreach($plyes as $xmlkey=>$value){ 
    $$xmlkey=$value;
}
if($_G['mobile']) {
    $eacha=$mobileeacha;
    $footad=$mobilefootad;
    $indexnewnum=$mobilenewnum;
    $indexhotnum=$mobilehotnum;
    $indextjnum=$mobiletjnum;
    $indexztnum=$mobilenewztnum;
}
$fabuset = unserialize($groups);
$free = unserialize($free);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$diysd = parconfig($sd);
$xingxingpingjia = parconfig($xingxingpingjia);
$payset=$payset/100;
$viewphotowidthb=$viewphotowidth - 34;
$viewphotoheightb=$viewphotoheight + 10;
$viewphotoheightc=$viewphotoheight - 35;
$navtitle = $title;
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if ($mod == 'index') {
    $cate_id = intval($_GET['a']);
    $sd = intval($_GET['b']);
    $newquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . "  WHERE  display!='0'  ORDER BY id DESC LIMIT $indexnewnum");
    while ($new = DB::fetch($newquery)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$new[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$cate[upid]'");
            $new['catescid'] = $cate['upid'];
            $new['catename'] = $cate_t['subject'];
            $new['catesname'] =$cate['subject'];
	    }else{
            $new['catescid'] = $new['cate'];
	      	$new['catename'] = $cate['subject'];
        }
        $news[] = $new;
    }
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE  display!='0' ORDER BY view DESC LIMIT $indexhotnum");
    while ($hot = DB::fetch($hotquery)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$hot[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$cate[upid]'");
            $hot['catescid'] = $cate['upid'];
            $hot['catename'] = $cate_t['subject'];
            $hot['catesname'] =$cate['subject'];
	    }else{
            $hot['catescid'] = $hot['cate'];
	        $hot['catename'] = $cate['subject'];
        }
        $hots[] = $hot;
    }
    $tuijianquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY diynum DESC,dateline DESC LIMIT $indextjnum");
    while ($tuijian = DB::fetch($tuijianquery)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$tuijian[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$cate[upid]'");
            $tuijian['catescid'] = $cate['upid'];
            $tuijian['catename'] = $cate_t['subject'];
            $tuijian['catesname'] =$cate['subject'];
	    }else{
            $tuijian['catescid'] = $tuijian['cate'];
	      	$tuijian['catename'] = $cate['subject'];
        }
        $tuijians[] = $tuijian;
    }
    $newztquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_zhuanti') . " WHERE display='1' ORDER BY diynum DESC,id DESC LIMIT $indexztnum");
    while ($newzt = DB::fetch($newztquery)) {
        $newzts[] = $newzt;
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_banner')." WHERE display='1' ORDER BY diynum DESC,id DESC");
	while($banner = DB::fetch($query)){
		$banners[] = $banner;
	}
	$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE  display!='0'");
    include template('xlwsq_tuku:index');
} elseif ($mod == 'list') {
    $where=$pageadd="";
    if ($_GET['key']!='') {
        $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key),'%_')."%' AND display!='0' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }elseif($_GET['biaoqian']!=''){
        $biaoqian=stripsearchkey($_GET['biaoqian']);
	    $where="biaoqian like '%".addcslashes(addslashes($biaoqian),'%_')."%' AND display!='0' AND";
	    $biaoqiankeync=urlencode($biaoqian);
	    $pageadd="&biaoqian=$biaoqiankeync";
        $biaoqiannav=$biaoqian. " - ";
    }elseif($_GET['uid']){
	    $uid=intval($_GET['uid']);
	    $where="uid='$uid' AND";
	    $uidnc=urlencode($uid);
	    $pageadd="&uid=$uidnc";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
        $av_d[$cate_id] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$cate_id'");
    $sd = intval($_GET['b']);
    if ($sd) {
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
        $av_d[$sd] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$sd'");
    if ($_GET['paixu']=='tj') {
		$px="tuijian = '1' AND display!='0' ORDER BY diynum DESC,dateline DESC"; $pageadd="&paixu=tj";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where $wb $wc tuijian = '1' AND display!='0'");
	}elseif ($_GET['paixu']=='view') {
		$px="view > '0' AND display!='0' ORDER BY view DESC"; $pageadd="&paixu=view";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where $wb $wc view > '0' AND display!='0'");
	}elseif ($_GET['paixu']=='free') {
		$px="price = '0' AND display!='0' ORDER BY diynum DESC,dateline DESC"; $pageadd="&paixu=free";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where $wb $wc price = '0' AND display!='0'");
	}elseif ($_GET['paixu']=='pay') {
		$px="price > '0' AND display!='0' ORDER BY diynum DESC,dateline DESC"; $pageadd="&paixu=pay";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where $wb $wc price > '0' AND display!='0'");
	}else{
		$px="display!='0' ORDER BY top DESC,diynum DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where $wb $wc display!='0'");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where $wb $wc $px LIMIT $starts,$eacha");
        while ($mythread = DB::fetch($query)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$cate[upid]'");
                $mythread['catescid'] = $cate['upid'];
                $mythread['catename'] = $cate_t['subject'];
                $mythread['catesname'] =$cate['subject'];
	        }else{
                $mythread['catescid'] = $mythread['cate'];
	         	$mythread['catename'] = $cate['subject'];
            }
            $mythread['title']=str_replace($key,"<font color='#ff0000'>$key</font>",$mythread['title']);
	        $sdtype = explode(" ",$mythread['dpname']);
	        $mythread['sdtype']= explode(" ",$mythread['dpname']);
            $mythreads[] = $mythread;
        }
    }
    $multis = multi($counts,$eacha,$pages,'plugin.php?id=xlwsq_tuku&mod=list'.$pageadd.$pageadds.$pageaddx);
    $r_id = intval($_GET['a']);
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . "-" . $mcateb['subject']. "-";
      } else {
           $catenav = $mcate['subject']. "-";
      }
    }
    $navtitle = $biaoqiannav. $catenav.$title;
    include template('xlwsq_tuku:list');
} elseif ($mod == 'userresourcelist') {
    $uid = intval($_GET['uid']);
    $where=$pageadd="";
    if($_GET['key']!=''){
        $key=stripsearchkey(trim($_GET['key']));
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	$userinfo = DB::fetch_first("SELECT * FROM " . DB::table('common_member') . " WHERE uid = '$uid'");
	!$userinfo ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
	$tukuuserinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_userinfo') . " WHERE uid = '$uid'");
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where uid='$uid' AND display='1' ");
    $pager = intval($_GET['page']);
    $pager = max($pager, 1);
    $starts = ($pager - 1) * $eacha;
    if ($counts) {
        $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where uid='$uid' AND display='1' ORDER BY display ASC,dateline DESC LIMIT $starts,$eacha");
        while ($mythread = DB::fetch($rs)) {
            $cate = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$mythread[cate]'"));
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$cate[upid]'");
                $mythread['catescid'] = $cate['upid'];
                $mythread['catename'] = $cate_t['subject'];
                $mythread['catesname'] =$cate['subject'];
            } else {
               $mythread['catescid'] = $mythread['cate'];
		       $mythread['catename'] = $cate['subject'];
            }
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px 0;'>" . multi($counts,$eacha, $pager, 'plugin.php?id=xlwsq_tuku&mod=userresourcelist&uid='.$uid. $pageadd) . "</div>";
    $navtitle = $userinfo['username'] .lang('plugin/xlwsq_tuku', 'navgerentuji').$title;
	include template('xlwsq_tuku:userresourcelist');
} elseif ($_GET['mod'] == 'userinfoedit') {
    $uid = intval($_GET['uid']);
    $userinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_userinfo') . " WHERE uid = '$uid'");
    if ($userinfo['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
        if (submitcheck('applysubuserinfoedit')) {
            $pic =dhtmlspecialchars($_GET['pic']);;
            $info =dhtmlspecialchars($_GET['info']);;
		    if($_FILES['file']['error']==0){
                if ($userinfo["pic"]!=false){
	                unlink($userinfo["pic"]);
	            }
			    $filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			    $arr=explode(".", $_FILES["file"]["name"]);
		    	$hz=$arr[count($arr)-1];
		    	if(!in_array($hz, $filetype)){
			    	showmessage(lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque'));	
		    	}
		        $imageinfo = getimagesize($_FILES['file']['tmp_name']);
			    if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque'));
			    }
			    $filepath = "source/plugin/xlwsq_tuku/userimg/".$uid."/";
			    $randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			    if(!file_exists($filepath)){ mkdir($filepath); }
		    	if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
			     	@unlink($_FILES['file']['tmp_name']);
			    }
			    $pic ="source/plugin/xlwsq_tuku/userimg/".$uid."/".$randname;
		    }
            if ($userinfo) {
                DB::update('plugin_xlwsq_tuku_userinfo', array('pic' => $pic,'info' => $info,'dateline' => $_G['timestamp']) , "uid='$uid'");
            }else{
		    	DB::insert('plugin_xlwsq_tuku_userinfo', array('id' => '','uid' => $uid,'info' => $info,'pic' => $pic,'dateline' => $_G['timestamp']));
            }
			showmessage(lang('plugin/xlwsq_tuku', 'tijiaochenggong'), 'plugin.php?id=xlwsq_tuku&mod=userresourcelist&uid='.$uid);
        }
    } else {
		showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), 'plugin.php?id=xlwsq_tuku&mod=userresourcelist&uid='.$uid);
    }
	include template('xlwsq_tuku:userinfoedit');
} elseif ($_GET['mod'] == 'view'||$_GET['mod'] == 'pinglunlist') {
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
        $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_item')." WHERE id = '$sid' AND display!='0'");
	}else{
	    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id = '$sid'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    if($mythread['viewgroup']!=''){
        $group = explode(",", $mythread['viewgroup']);
        if (!in_array($_G['groupid'], $group) && $_G['groupid']!=1 && !in_array($_G['uid'], $admins) && $uid!=$mythread['uid']) {
		    showmessage(lang('plugin/xlwsq_tuku', 'wuquanxianliulan'), dreferer());
	    }
    }
    $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
    DB::query("UPDATE " . DB::table('plugin_xlwsq_tuku_item') . " SET `view` = view+1 WHERE `id` = '$sid'");
    $cate = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_cate')." WHERE id = '$mythread[cate]'");
	if($cate['upid']!=0){
		$cate_t = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_cate')." WHERE id = '$cate[upid]'");
        $mythread['catescid'] = $cate['upid'];
        $mythread['catename'] = $cate_t['subject'];
        $mythread['catesname'] =$cate['subject'];
	}else{
        $mythread['catescid'] = $mythread['cate'];
		$mythread['catename'] = $cate['subject'];
    }
	$dinfo = discuzcode($mythread['info']);
    $biaoqian = explode(" ",$mythread['biaoqian']);
	$sdtype = explode(" ",$mythread['dpname']);
	$mythread['sdtype']=$sdtype;
    $mythread['fenxiangnshu']= DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_item')." WHERE uid='$mythread[uid]' AND  display!='0'");
	$piccount = $mythread['piccount'];
    if($sortset=='1'){
      $sort='DESC';
	}else{
      $sort='ASC';
	}
    if($_G['mobile']) {
        $imgquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_img')." WHERE sid = '$sid' AND display!='0' ORDER BY diynum ASC,id $sort LIMIT 12");
    }else{
        $imgquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_img')." WHERE sid = '$sid' AND display!='0' ORDER BY diynum ASC,id $sort");
    }
	while($imglist = DB::fetch($imgquery)){
        $pic = getimagesize($imglist['img']);
		$imglist['wdith'] = $pic[0];
		$imglist['height'] = $pic[1];
		$imglistid[] = $imglist['id'];
		$imglists[] = $imglist;
    }
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE view >'0' AND display!='0' ORDER BY view DESC LIMIT $hotnum");
    while ($hot = DB::fetch($hotquery)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$hot[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$cate[upid]'");
            $hot['cate'] = $cate['subject'];
        } else {
            $hot['cate'] = $cate['subject'];
        }
        $hots[] = $hot;
    }
    $tuijianquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY diynum DESC,dateline DESC LIMIT $tjnum");
    while ($tuijian = DB::fetch($tuijianquery)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$tuijian[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$cate[upid]'");
            $tuijian['cate'] = $cate['subject'];
        } else {
            $tuijian['cate'] = $cate['subject'];
        }
        $tuijians[] = $tuijian;
    }
    $buy = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_record') . " WHERE sid = '$sid' AND buyuid = '$uid'");
    $ypl= DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE sid = '$sid' AND uid='$uid'");
    if(submitcheck('applysubmit')){	
	    if(!$_G['uid']){showmessage(lang('plugin/xlwsq_tuku', 'youkewuquanxianpinglun'), array(), array('alert' => 'error'));}   
	    if($duocipingset ==0 && $ypl){
		    showmessage(lang('plugin/xlwsq_tuku', 'yijingpinglunguo'), array(), array('alert' => 'error'));
		}
		$message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
        $pf0 = intval($_GET['pf0']);
        $pf1 = intval($_GET['pf1']);
        $pf2 = intval($_GET['pf2']);
        $pf3 = intval($_GET['pf3']);
        $pf4 = intval($_GET['pf4']);
		if(empty($_GET['pf0'])){$pfa = 0;}else{$pfa = 1;}
		if(empty($_GET['pf1'])){$pfb = 0;}else{$pfb = 1;}
		if(empty($_GET['pf2'])){$pfc = 0;}else{$pfc = 1;}
		if(empty($_GET['pf3'])){$pfd = 0;}else{$pfd = 1;}
		if(empty($_GET['pf4'])){$pfe = 0;}else{$pfe = 1;}
	    if ($_G['groupid']=="1"){$display =1; }else{$display = intval($display);}
		DB::insert('plugin_xlwsq_tuku_post',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'message' => $message,'display' => $display,'dateline' => time()));
        $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE sid='$sid' AND display!='0'"); 
		$sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe' FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE sid='$sid' AND display!='0'";
		$result = DB::query($sql);
		$row = DB::fetch($result);  
		$pf0 = intval($row['pf0']);
		$pf1 = intval($row['pf1']);
		$pf2 = intval($row['pf2']);
		$pf3 = intval($row['pf3']);
		$pf4 = intval($row['pf4']);
		$pfa = intval($row['pfa']);
		$pfb = intval($row['pfb']);
		$pfc = intval($row['pfc']);
		$pfd = intval($row['pfd']);
		$pfe = intval($row['pfe']);
		DB::update('plugin_xlwsq_tuku_item', array('pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'dpcount' => $dpcount), "id='$sid'");
        if($pinglunaddshuliang > '0' && $pinglunextcredita){
	       $plf = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_pinglunjiangli') . " WHERE sid = '$sid' AND uid = '$uid'");
           if (!$plf){
		       updatemembercount($uid, array($pinglunextcredita => +$pinglunaddshuliang));
			   $moneytype = $_G['setting']['extcredits'][$pinglunextcredita]['title'];
		       DB::insert('plugin_xlwsq_tuku_pinglunjiangli',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'title' => $mythread['title'],'jianglishu' => $pinglunaddshuliang,'moneytype' => $moneytype,'dateline' => $_G['timestamp']));
		   }
	    }
		if(intval($display) == 0){
			showmessage(lang('plugin/xlwsq_tuku', 'pinglundengdaishenhezhong'),dreferer());
		}else{
			showmessage(lang('plugin/xlwsq_tuku', 'tijiaochenggong'), dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
		}
    }
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE sid='$sid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$postquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE sid='$sid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$postdata= array();
		$replydata= array();
		while($pl = DB::fetch($postquery)){
		    $recount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_reply')." WHERE dpid = ".$pl['id']." AND display!='0'");
            $pl['count']=$recount;
			$postdata[$pl['id']] = $pl;
			$replyquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_reply'). " WHERE dpid = ".$pl['id']." AND display!='0' ORDER BY dateline DESC LIMIT 5");
		    while($re = DB::fetch($replyquery)){
			    $reinfo = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_reply')." WHERE id = ".$re['redpid'].""); 
                $re['rereauthor']  = $reinfo['reauthor'];
                $re['reremessage']  = $reinfo['remessage'];
		   		$replydata[$pl['id']][$re['id']] = $re;
		   		$re['recount'] = $pl['reply'];	
			}
		}
		$postdata = dhtmlspecialchars($postdata);
		$replydata = dhtmlspecialchars($replydata);
	}
	$multi = "<div class='pages cl' style='margin:10px 5px;'>" .multi($count, $each, $page,'plugin.php?id=xlwsq_tuku&mod=view&sid='.$sid.'')."</div>";
	$mobilemulti = multi($count, $each, $page,'plugin.php?id=xlwsq_tuku&mod=pinglunlist&sid='.$sid.'');
    if($_GET['pinglun'] == 'del'){
        if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	        $sid = intval($_GET['sid']);
	        $did = intval($_GET['did']);
            if($_GET['formhash'] == FORMHASH) {
	            DB::query("DELETE a,b FROM ".DB::table('plugin_xlwsq_tuku_post')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_tuku_reply')." AS b ON a.id = b.dpid WHERE a.id = '$did' ");
	            $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE sid='$sid' AND display!='0'"); 
				$sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe' FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE sid='$sid' AND display!='0' ";
				$result = DB::query($sql);
				$row = DB::fetch($result);  
				$pf0 = intval($row['pf0']);
				$pf1 = intval($row['pf1']);
				$pf2 = intval($row['pf2']);
				$pf3 = intval($row['pf3']);
				$pf4 = intval($row['pf4']);
				$pfa = intval($row['pfa']);
				$pfb = intval($row['pfb']);
				$pfc = intval($row['pfc']);
				$pfd = intval($row['pfd']);
				$pfe = intval($row['pfe']);
	            DB::update('plugin_xlwsq_tuku_item', array('pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'dpcount' => $dpcount), "id='$sid'");
	            showmessage(lang('plugin/xlwsq_tuku', 'shanchuok'), dreferer());
            }
        }else{		
	        showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
        }
    }
    if ($mythread['catename']) {
      $catename = " - " . $mythread['catename'];
    }
    $navtitle = $mythread['title'].$catename. " - ".$title;
	$metakeywords = $mythread['biaoqian'];
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($dinfo) , 80, '...'));
	if($_GET['mod']=='view'){
        include template('xlwsq_tuku:view');
	}elseif($_GET['mod']=='pinglunlist'){
		include template('xlwsq_tuku:pinglunlist');
	}
} elseif ($_GET['mod'] == 'pic') {
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
        $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_item')." WHERE id = '$sid' AND display!='0'");
	}else{
	    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id = '$sid'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    if($mythread['viewgroup']!=''){
        $group = explode(",", $mythread['viewgroup']);
        if (!in_array($_G['groupid'], $group) && $_G['groupid']!=1 && !in_array($_G['uid'], $admins) && $uid!=$mythread['uid']) {
		    showmessage(lang('plugin/xlwsq_tuku', 'wuquanxianliulan'), dreferer());
	    }
    }
    $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
    $buy = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_record') . " WHERE sid = '$sid' AND buyuid = '$uid'");
	$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND display!='0'");
	$piccount=$countr;
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * $mobilepicnum;
    if($sortset=='1'){
      $sort='DESC';
	}else{
      $sort='ASC';
	}
	if($countr) {
	    $imgquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_img')." WHERE sid = '$sid' AND display!='0' ORDER BY  diynum ASC,id $sort LIMIT $starts,$mobilepicnum");
	    while($imglist = DB::fetch($imgquery)){
            $pic = getimagesize($imglist['img']);
		    $imglist['wdith'] = $pic[0];
		    $imglist['height'] = $pic[1];
		    $imglists[] = $imglist;
	   }
	}
	$multir =multi($countr, $mobilepicnum, $pages,'plugin.php?id=xlwsq_tuku&mod=pic&sid='.$sid.'');
    $navtitle = $mythread['title']. " - " .$mythread['catename']. " - " . $title;
	$metakeywords = $mythread['biaoqian'];
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($mythread['info']) , 80, '...'));
    include template('xlwsq_tuku:pic');	
}elseif($_GET['mod']=='pay'){
    $sid = intval($_GET['sid']);
    $itemsql = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_item')." WHERE `id` = '$sid' AND display!='0'");
    !$itemsql ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    $group = explode(",", $itemsql['viewgroup']);
    if (!in_array($_G['groupid'], $group)) {showmessage(lang('plugin/xlwsq_tuku', 'wuquanxianliulan'), dreferer());}
	$moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	$did = intval($_GET['did']);
	$uid = intval($_G['uid']);
    $buy = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_record') . " WHERE sid = '$sid' AND buyuid = '$uid'");
    if(!$buy){
        $price=$itemsql['price'];
        $fabuuid=$itemsql['uid'];
        $fabuauthor=$itemsql['author'];
        $title=$itemsql['title'];
        if($price=="0"||$fabuuid == $_G['uid']||in_array($_G['uid'], $admins)||$_G['groupid']=="1"||in_array($_G['groupid'], $free)){
        }else{
            if($paymoney<$price){
                $tixing= lang('plugin/xlwsq_tuku', 'xiaohaotishi').$price.$moneytype.lang('plugin/xlwsq_tuku', 'jifenbuzu');
                if (empty($chongzhiurl)) {
	                showmessage($tixing, dreferer());
	            }else{
                    showmessage($tixing, 'plugin.php?id=xlwsq_tuku&mod=viewchongzhi&sid='.$sid, array() , array('alert' => 'error'));
                }
            }else{
			    if($_G['uid']!=$fabuuid){
                    $income=intval($price*$payset);
					DB::insert('plugin_xlwsq_tuku_record',array('id' => '','sid' => $sid,'selluid' => $fabuuid,'seller' => $fabuauthor,'buyuid' => $uid,'buyer' => $_G['username'],'buyerpay' => $price,'title' => $title,'sellincome' => $income,'moneytype' => $moneytype,'type' => '1','dateline' => $_G['timestamp']));
	                updatemembercount($_G['uid'], array($paytype => -$price));
	                updatemembercount($fabuuid, array($paytype => +$income));
					showmessage(lang('plugin/xlwsq_tuku', 'payok') , dreferer());
                }
            }
        }
    }
} elseif ($_GET['mod'] == 'zhuantilist') {
    $cate_id = intval($_GET['a']);
    $sd = intval($_GET['b']);
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    $where=" AND title like '%".addcslashes(addslashes($key), '%_')."%' ";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	if ($_GET['paixu']=='view') {
		$px=" WHERE display='1' $where ORDER BY view DESC"; $pageadd="&paixu=view";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_zhuanti').$px);
	}else{
		$px=" WHERE display='1' $where ORDER BY diynum DESC,id DESC";
	    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_zhuanti').$px);
    }
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $ztlistnum;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_zhuanti') . " $px LIMIT $starts,$ztlistnum");
        while ($mythread = DB::fetch($query)) {
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px;'>" . multi($counts,$ztlistnum,$pages,'plugin.php?id=xlwsq_tuku&mod=zhuantilist'.$pageadd)."</div>";
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_zhuanti') . " WHERE view >'0' AND display='1' ORDER BY view DESC LIMIT $hotztnum");
    while ($hot = DB::fetch($hotquery)) {
        $hots[] = $hot;
    }
    $navtitle = lang('plugin/xlwsq_tuku', 'zhuanti'). " - " . $title;
    include template('xlwsq_tuku:zhuantilist');
} elseif ($_GET['mod'] == 'zhuantiview') {
	$ztid = intval($_GET['ztid']);
    $zhuanti = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_zhuanti') . " WHERE id='$ztid' AND display='1'");
    !$zhuanti ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
	DB::query("UPDATE " . DB::table('plugin_xlwsq_tuku_zhuanti') . " SET `view` = view+1 WHERE `id` = '$ztid'");
	$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item')." WHERE instr(concat(',',`zhuanti`,','),',$ztid,') AND display='1'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE instr(concat(',',`zhuanti`,','),',$ztid,')  AND display='1' ORDER BY diynum DESC,id DESC LIMIT $starts,$eacha");
        while ($mythread = DB::fetch($query)) {
            $cate = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_cate')." WHERE id = '$mythread[cate]'");
	        if($cate['upid']!=0){
	        	$cate_t = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_cate')." WHERE id = '$cate[upid]'");
                $mythread['catescid'] = $cate['upid'];
                $mythread['catename'] = $cate_t['subject'];
                $mythread['catesname'] =$cate['subject'];
	        }else{
                $mythread['catescid'] = $mythread['cate'];
	         	$mythread['catename'] = $cate['subject'];
            }
            $mythreads[] = $mythread;
        }
	    $mythreads = dhtmlspecialchars($mythreads);
    }
    $multis =multi($counts,$eacha,$pages,'plugin.php?id=xlwsq_tuku&mod=zhuantiview&ztid='.$ztid.'');
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_zhuanti') . " WHERE view >'0' ORDER BY view DESC LIMIT $hotztnum");
    while ($hot = DB::fetch($hotquery)) {
        $hots[] = $hot;
    }
    $navtitle = $zhuanti['title']. " - " . lang('plugin/xlwsq_tuku', 'zhuanti'). " - " . $title;
    $metadescription = cutstr(strip_tags($zhuanti['info']) , 80, '...');
    include template('xlwsq_tuku:zhuantiview');
}elseif($_GET['mod']=='reply'){
	$dpid = intval($_GET['dpid']);
    $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE id = '$dpid' AND display!='0'");
    !$pl ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_item')." WHERE id = '$pl[sid]'");
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_reply')." WHERE dpid='$dpid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_reply')." WHERE dpid='$dpid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$pl = $pls = array();
		while($pl = DB::fetch($query)) {
		    $reinfo = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_reply')." WHERE id = ".$pl['redpid'].""); 
            $pl['rereuid']  = $reinfo['reuid'];
            $pl['rereauthor']  = $reinfo['reauthor'];
            $pl['reremessage']  = $reinfo['remessage'];
			$pls[] = $pl;
		}
		$pls = dhtmlspecialchars($pls);
	}
	$multi = "<div class='pages cl'>".multi($count, $each, $page,'plugin.php?id=xlwsq_tuku&mod=reply&dpid='.$dpid.'')."</div>";
    $navtitle = $item['title']." - ".$t_title;	
	$metadescription =  cutstr(strip_tags($item['info']), 100, '...');
	$metakeywords = $item['biaoqian'];
	include template('xlwsq_tuku:replylist');
} elseif ($_GET['mod'] == 'viewchongzhi'||$_GET['mod'] == 'usercenterchongzhi') {
    $sid = intval($_GET['sid']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id = '$sid' and display!='0'");
	include template('xlwsq_tuku:chongzhi');
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
	    $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_item')." WHERE id = '$sid'");
        !$item ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_tuku_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
            showmessage(lang('plugin/xlwsq_tuku', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
        } else {
            DB::insert('plugin_xlwsq_tuku_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'title' => $item['title'],'dateline' => $_G['timestamp']));
            showmessage(lang('plugin/xlwsq_tuku', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
        }
    }
}
//From: Dism_taobao-com
?>