<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$plyes=($_G['cache']['plugin']['xlwsq_tuku']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
if (file_exists("source/plugin/xlwsq_tuku/qiniusdk/autoload.php") && $pingtaiset==1) {
    require_once 'qiniusdk/autoload.php';
}else{
    include_once 'source/plugin/xlwsq_tuku/class/upic.class.php';
    include_once 'source/plugin/xlwsq_tuku/class/watermark.class.php';
}
$uploaddx=$uploaddx*1024;
$mianshenhe = unserialize($mianshenhe);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$sid = intval($_GET['sid']);
$maxpic = intval($maxpic);
if ($_FILES['file']['error']==0 && $_GET['formhash'] == FORMHASH) {
    $count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid'");
    if ($maxpic <= $count) {
        echo json_encode(array("error" =>lang('plugin/xlwsq_tuku', 'tianjiatupianshibai')));
		exit ;
	}
    $picname = $_FILES['file']['name'];
	$picsize = $_FILES['file']['size'];
	$imageinfo = getimagesize($_FILES['file']['tmp_name']);
	if ($imageinfo[0] <= 0) {
        echo json_encode(array("error" =>lang('plugin/xlwsq_tuku', 'feifatupianleixing')));
		exit ;
	}
    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
	$arr=explode(".", strtolower($_FILES['file']["name"]));
    $hz = $arr[count($arr) - 1];
    if (!in_array($hz, $filetype)) {
        echo json_encode(array("error" => lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque')));
	    exit ;
    }
    if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
        $display = 1;
    } else {
        $display = 0;
    }
	if($qiniuconfig['upToken']){
        $pic = qiniuupload($_FILES['file']);
        $spic =$pic.$qiniusimg;
	    DB::insert('plugin_xlwsq_tuku_img', array('id' => '','sid' => $sid,'img' =>$pic,'simg' =>$spic,'display' => $display,'savearea' => $pingtaiset,'dateline' => $_G['timestamp']));
        $picid = DB::insert_id();
        $fengmiancount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND fengmian='1'");
		if ($fengmiancount == '0') {
	        $pic = $spic ? $spic : $pic;
            DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='0' where sid=$sid");
	        DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='1' where id=$picid");
	        DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set pic='$pic' where id=$sid");
		}
        $piccount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND display!='0'");
	    DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set piccount='$piccount' where id=$sid");
		echo json_encode(array("error" => "0", "pic" => $spic, "name" => $picname));
	}else{
        $update = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999);
        $pics =$update. "." . $hz;
        $spics =$update .  "_s" ."." . $hz;
	    $img_dir = "source/plugin/xlwsq_tuku/upimg/".$sid. "/";
        if (!is_dir($img_dir)) {
			mkdir($img_dir);
        }
        $pic = $img_dir . $pics;
        $spic = $img_dir. $spics;
            if($picsize <= $uploaddx){
                if (@copy($_FILES['file']['tmp_name'], $pic) || @move_uploaded_file($_FILES['file']['tmp_name'], $pic)) {
			        @copy($_FILES['file']['tmp_name'], $spic);
                    @unlink($_FILES['file']['tmp_name']);
                }
            }else{
                echo json_encode(array("error" =>lang('plugin/xlwsq_tuku', 'tupiantaida')));
                exit ;
            }
		    if ($imageinfo[0] > 300) {
			    new myThumbClass($spic,1,2,$spic,1,300); 
		    }
		    if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
			    new myThumbClass($pic,1,2,$pic,1,$newpicwidth); 
		    }
            if($imgwater && $imageinfo[0] > $waterwidth){
	            $wm = new WaterMark();
	            $wm->setImSrc($pic);
	            $wm->setImWater($imgwater);
	            $wm->mark(1,$imgwaterweizhi,0,0);
            }
	        DB::insert('plugin_xlwsq_tuku_img', array('id' => '','sid' => $sid,'img' =>$pic,'simg' =>$spic,'display' => $display,'savearea' => $pingtaiset,'dateline' => $_G['timestamp']));

         $picid = DB::insert_id();
         $fengmiancount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND fengmian='1'");
		 if ($fengmiancount == '0') {
	        $pic = $spic ? $spic : $pic;
            DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='0' where sid=$sid");
	        DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='1' where id=$picid");
	    	DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set pic='$pic' where id=$sid");
         }
         $piccount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND display!='0'");
	     DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set piccount='$piccount' where id=$sid");
	     echo json_encode(array("error" => "0", "pic" => $spic));
	}
}
//From: Dism_taobao-com
?>