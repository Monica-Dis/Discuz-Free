$(function () {
    $('.fix-top-menu .close, .fix-top-menu .bg').on('touchstart', function (e) {
        e.stopPropagation();
        e.preventDefault();
        $('.fix-top-menu').hide();
        $('.articleHead .navBtn').show();
    });
    $(' .articleHead .navBtn').on('click', function (e) {
        e.stopPropagation();
        e.preventDefault();
        window.scrollTo(0, 0);
        $('.fix-top-menu').show();
        $('.articleHead .navBtn').hide();
        $('.fix-top-menu').css('top', $('header').position().top);
    });
});