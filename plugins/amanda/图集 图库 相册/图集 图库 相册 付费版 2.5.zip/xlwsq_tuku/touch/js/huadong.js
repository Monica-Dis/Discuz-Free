$(function(){
	//���򻬶�
	$(".plist").each(function(i){
		var idStr = $(this).attr("id");
		var parent_class =  $(this).attr("class");
		var child_class =  $("."+parent_class).children(i).children(0).attr("class");
		createIScroll(idStr,"g-ppt-btn");
	});			
})
function createIScroll(idStr, tabClassStr){
	var snap = false;
	var classStr =  $("#"+idStr).attr("class");
	var splitClassStr = classStr.split(" ");
	var scrollObj = new IScroll("#"+idStr,{
			snap: snap,
			momentum: !snap,
			resize: true,			
			disableMouse: true,
    		disablePointer: true,
			eventPassthrough: true,
			scrollX: true,
			scrollY: false,
			preventDefault: false 			
	});		
	return snap;
}