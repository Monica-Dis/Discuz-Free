/*
 * jQuery - jcImg v1.0
 * Copyright(c) 2012 by Adam��
 * Date: 2012-08-24
 * qq : 1741498
 */
;(function(jQuery){
	jQuery.fn.jcImg= function(options) {
		var defaults = {
			Default : 1,
			speed : 400,
			height :64,
			width : 115,
			textBg : .8,
			page : 7
		};
		var tt = 7;
		var imgsrclist = {};
		var currentNum = 0;
		var bigImglist = jQuery(this).find("img")
		var len = bigImglist.length;
		var options = jQuery.extend(defaults,options);
		return this.each(function() {
            var jQuerythis = jQuery(this),
				jQueryimgs = jQuery(this).find("img"),
				imgLen = 0,
				selectText = "",
				ImgIdx = 0,
				arrPath = [],
				arrTitle = [];
			// default info
			for(var x = 0; x < jQueryimgs.length; x++){
				var jQuerythisImg = jQueryimgs.eq(x)
                jQuerythisImgs = jQuerythisImg.attr("data-src");
				var _src = jQuerythisImg.attr("src");
                jQuerythisImg.attr({"src":"","data-src":_src});
				if(x<tt){jQuerythisImg.attr("src",_src);}
				imgsrclist['img_'+x] = _src

				if((x+1) == options.Default ){
					selectText = jQuerythisImg.attr("title");
					ImgIdx = x;
					imgShow(ImgIdx);
				};
				arrTitle.push(jQuerythisImg.attr("title"))
				//if(x < tt){
					arrPath.push("<dd><div></div><img src="+ jQuerythisImgs +" height=" + options.height + " width=" + options.width+ " /></dd>");
				//}else{
					//arrPath.push("<dd><div></div><img data-src="+ jQuerythisImg.attr("data-src") +" height=" + options.height + " width=" + options.width+ " /></dd>");
				//}
				
				imgLen = x + 1;
			};
			currentNum = tt;
			// Creat Dom
			var fnText = function(text,idx,len){
					return "<div id='imgText'><b></b><p><span>" + text + "</span><samp>" + idx +" / " + len + "</samp></p></div>";
				},
				fnBtn = function(){
					return "<b id='prev'></b><b id='next'></b>";
				},
				fnSmallImg = function(){
					return "<div id='smallImg'><dl></dl><div id='imgHover'></div></div>"
				};
			jQuerythis.prepend(fnText(selectText,ImgIdx+1,imgLen) + fnBtn()).append(fnSmallImg());
			var jQuerySmallImgS = jQuery("#smallImg").find("dl"),
				jQueryimgText = jQuery("#imgText"),
			    jQueryimgTextBg = jQueryimgText.find("b"),
				jQueryprev = jQuery("#prev",jQuerythis),
				jQuerynext = jQuery("#next",jQuerythis),
				jQueryimgHover = jQuery("#imgHover"),
				jQueryspan = jQueryimgText.find("span"),
				jQuerysamp = jQueryimgText.find("samp");
			jQuerySmallImgS.html(arrPath.join(""));
			var imgSwidth = jQuerySmallImgS.find("dd:eq(0)").outerWidth(true);
			imgScroll(jQueryimgHover,ImgIdx,imgSwidth,100);
			jQuerySmallImgS.find("div").fadeTo(0,.5);
			jQueryimgTextBg.fadeTo(0,options.textBg,function(){
				jQuery(this).parents("div").show();	
			});
			// Control
			function imgShow(index){
				jQuerythis.find("li:eq(" + index + ")").fadeIn(options.speed).siblings().fadeOut(options.speed/2);
				return false;
			};
			function imgScroll(Dom,index,width,speed){
				Dom.show().stop().animate({"left":(index%options.page)*width },speed,function(){
					jQuerySmallImgS.find("dd:eq("+ index +")").find("div").hide().parent().siblings().find("div").show();	
				});
				return false;
			};
			jQuerySmallImgS.find("dd").mouseover(function(){
				ImgIdx = jQuery(this).index();
				imgScroll(jQueryimgHover,ImgIdx,imgSwidth,150);
				imgShow(ImgIdx);
				jQueryspan.text(arrTitle[ImgIdx]);
				jQuerysamp.text((ImgIdx+1) + " / " + imgLen);
				
			});
			var pages = imgLen/options.page,
			    thisPage = 0,
				nLeft = options.page * imgSwidth;
				/*if(/^\d+jQuery/.test(imgLen/options.page)){
					pages += 1;	
				};*/
			jQueryprev.click(function(){
				jQueryimgHover.hide(0,function(){
					jQuery(this).css({"left":options.page*imgSwidth});
				});
				if(thisPage > 0 ) {
					thisPage--;
					jQuerySmallImgS.animate({"left":-nLeft*thisPage},200);
				};
				return false;
			});
			jQuerynext.click(function(){
				jQueryimgHover.hide(0,function(){
					jQuery(this).css({"left":0});
				});
				if(thisPage < pages-1 ) {
					thisPage++;
					jQuerySmallImgS.animate({"left":-nLeft*thisPage},200);
					console.log("click")
					for(var i = currentNum; i< currentNum+tt; i++){
						if(i < len){
							bigImglist.eq(i).attr("src", imgsrclist['img_'+i])
						}
					}
					currentNum = currentNum + tt;
					
				};
				return false;
			});
	
		});
	};
})(jQuery)