<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
@require_once 'source/plugin/xlwsq_tuku/function/function_core.php';
$language = DISCUZ_ROOT.'source/plugin/xlwsq_tuku/language.'.currentlang().'.php';
if(file_exists($language)){
  include_once 'language.'.currentlang().'.php';
}else{
  include_once 'language.php';
}
loadcache('plugin');
$plyes=($_G['cache']['plugin']['xlwsq_tuku']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
if($_G['mobile']) {
    $menubgcolor=$mobilecolor;
}
$zhuantilogowidth=600;
$p = $_GET['p'] ? $_GET['p'] : 'index';
$fabuset = unserialize($groups);
$mianshenhe = unserialize($mianshenhe);
$diysd = parconfig($sd);
$uploaddx=$uploaddx*1024;
$maxpic = intval($maxpic);
$navtitle = $title;
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
if ($p == 'mylist'||$p == 'index') {
    if ($p == 'mylist') {
	    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    }
    $where=$pageadd="";
    if($_GET['key']!=''){
        $key=stripsearchkey(trim($_GET['key']));
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
    $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where uid='$uid' AND uid!='0'");
    $pager = intval($_GET['page']);
    $pager = max($pager, 1);
    $starts = ($pager - 1) * 20;
    if ($countr) {
        $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE $where uid='$uid' ORDER BY display ASC,dateline DESC LIMIT $starts,20");
        while ($rw = DB::fetch($rs)) {
            $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$rw[cate]'"));
            if ($pa['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$pa[upid]'");
                $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
            } else {
                $rw['cate'] = $pa['subject'];
            }
            $manylist[] = $rw;
        }
    }
    $multir = "<div class='pages cl' style='margin:10px 0;'>" . multi($countr, 20, $pager, 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p='.$p. $pageadd) . "</div>";
	$moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
} elseif ($p == 'adminalllist') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $where=$pageadd="";
        if($_GET['key']!=''){
            $key=stripsearchkey(trim($_GET['key']));
	        $where=" where title like '%".addcslashes(addslashes($key), '%')."%'";
	        $keync=urlencode($key);
	        $pageadd="&key=$keync";
        }
	    $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_item').$where);
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " $where ORDER BY display ASC,dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $multir = "<div class='pages cl' style='margin:10px 0;'>" . multi($countr, 20, $pager, 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p='.$p. $pageadd) . "</div>";
    } else {
        showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), dreferer());
    }
    if (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tuku_item') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tuku', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tuku_item') . " SET display='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tuku', 'gengxinok') , dreferer());

	}elseif(submitcheck('applysubmtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_tuku_item')." SET tuijian='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_tuku', 'gengxinok'), dreferer());
	}elseif(submitcheck('applysubmqxtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_tuku_item')." SET tuijian='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_tuku', 'gengxinok'), dreferer());	
    } elseif (submitcheck('applysubmzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tuku_item') . " SET top='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tuku', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tuku_item') . " SET top='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tuku', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
           $aid = intval($aid);
           deldir("source/plugin/xlwsq_tuku/upimg/".$aid);
           DB::query("DELETE a,b,c,d FROM ".DB::table('plugin_xlwsq_tuku_item')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_tuku_img')." AS b ON a.id = b.sid LEFT JOIN ".DB::table('plugin_xlwsq_tuku_post')." AS c ON a.id = c.sid LEFT JOIN ".DB::table('plugin_xlwsq_tuku_reply')." AS d ON d.id = d.dpid WHERE a.id = '$aid' ");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tuku', 'shanchuok') , dreferer());
    }
}elseif($p=='adminpic'){
    if($_G['groupid']!=1&&!in_array($_G['uid'], $admins)){
	    showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), dreferer());
	}
    if ($_GET['action'] == 'daishen'){
		$ds = " WHERE display ='0'";
		$dss = " AND b.display ='0'";
		$pageadd="&action=daishen";
    }
    $countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img').$ds);
	$pager = intval($_GET['page']);
	$pager = max($pager, 1);
	$starts = ($pager - 1) * 10;
	if($countr) {			
		$rs = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_item')." a, ".DB::table('plugin_xlwsq_tuku_img')." b WHERE a.id = b.sid $dss ORDER BY b.dateline DESC LIMIT $starts,10");
		while ($rw=DB::fetch($rs)){
			$manylist[]=$rw;
		}
	}
	$multir = "<div class='pages cl' style='margin:10px 0;'>".multi($countr, 10, $pager, 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p='.$p.$pageadd)."</div>";
    if(submitcheck('applysubmdel')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
		    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_img')." WHERE id ='$aid' LIMIT 1");
	        unlink($active["img"]);
	        unlink($active["simg"]);
			DB::delete('plugin_xlwsq_tuku_img',array('id'=> $aid));
            $piccount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$active[sid]' AND display!='0'");
            DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set piccount='$piccount' where id=$active[sid]");
			$nums++;
		}
        showmessage(lang('plugin/xlwsq_tuku', 'shanchuok'), dreferer());
    }elseif (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
		    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_img')." WHERE id ='$aid' LIMIT 1");
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tuku_img') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $piccount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$active[sid]' AND display!='0'");
            DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set piccount='$piccount' where id=$active[sid]");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tuku', 'gengxinok') , dreferer());
	}
}elseif($p=='adminpinglun'){
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        if ($_GET['action'] == 'daishen'){
			$ds = " WHERE display ='0'";
			$dss = " AND b.display ='0'";
			$pageadd="&action=daishen";
		}elseif ($_GET['action'] == 'yishen'){
			$ds = " WHERE display ='1'";
			$dss = " AND b.display ='1'";
			$pageadd="&action=yishen";
        }
		$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_post').$ds);
		$pager = intval($_GET['page']);
		$pager = max($pager, 1);
		$starts = ($pager - 1) * 20;
		if($countr) {
			$rs=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_item')." a, ".DB::table('plugin_xlwsq_tuku_post')." b WHERE  a.id = b.sid $dss ORDER BY b.dateline DESC LIMIT $starts,20");
			while ($rw=DB::fetch($rs)){
		        $recount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_reply')." WHERE dpid = ".$rw['id']." AND display!='0'");
		        $rw['count'] = $recount; 
				$manylist[]=$rw;
			}
		}
		$multir = "<div class='pages cl' style='margin-top:10px;'>".multi($countr, 20, $pager, 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_use&p='.$p.$pageadd)."</div>";
	}else{
		showmessage(lang('plugin/xlwsq_tuku', 'caozuocuowu'));
	}
	if(submitcheck('applysubmsh')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
            $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_post')." where id = '$aid'");
		    DB::query("UPDATE ".DB::table('plugin_xlwsq_tuku_post')." SET display='1' WHERE id='$aid' LIMIT 1");
	        $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_post')." where sid='$pl[sid]' AND display!='0' ");
            $sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe' FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE sid='$pl[sid]' AND display!='0' ";
		    $result = DB::query($sql);
		    $row = DB::fetch($result);  
		    $pf0 = intval($row['pf0']);
		    $pf1 = intval($row['pf1']);
	    	$pf2 = intval($row['pf2']);
	    	$pf3 = intval($row['pf3']);
	     	$pf4 = intval($row['pf4']);
	    	$pfa = intval($row['pfa']);
	    	$pfb = intval($row['pfb']);
    		$pfc = intval($row['pfc']);
    		$pfd = intval($row['pfd']);
    		$pfe = intval($row['pfe']);
            DB::update('plugin_xlwsq_tuku_item', array('pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'dpcount' => $dpcount), "id='$pl[sid]'");
    		$nums++;
		}
	    showmessage(lang('plugin/xlwsq_tuku', 'gengxinok'), dreferer());	
	}elseif(submitcheck('applysubmdel')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $ssd) {
        $ssd = intval($ssd);
 		    $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_post')." where id = '$ssd'");
  		    $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_item')." where id = '$pl[sid]'");
			DB::delete('plugin_xlwsq_tuku_post',array('id'=> $ssd));
			DB::delete('plugin_xlwsq_tuku_reply',array('dpid'=> $ssd));
			$dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_post')." where sid='$pl[sid]'"); 
			$sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe'FROM ".DB::table('plugin_xlwsq_tuku_post')." WHERE sid='$pl[sid]'";
			$result = DB::query($sql);
			$row = DB::fetch($result);  
			$pf0 = intval($row['pf0']);
			$pf1 = intval($row['pf1']);
			$pf2 = intval($row['pf2']);
			$pf3 = intval($row['pf3']);
			$pf4 = intval($row['pf4']);
			$pfa = intval($row['pfa']);
			$pfb = intval($row['pfb']);
			$pfc = intval($row['pfc']);
			$pfd = intval($row['pfd']);
			$pfe = intval($row['pfe']);
	        DB::update('plugin_xlwsq_tuku_item', array('pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'dpcount' => $dpcount),"id ='$pl[sid]'");
			$nums++;
		}
            showmessage(lang('plugin/xlwsq_tuku', 'shanchuok'), dreferer());
    }
}elseif($p=='adminxfjl'||$p=='adminpingfenjiangli'){	
    if($_G['groupid']!=1&&!in_array($_G['uid'], $admins)){
	    showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), dreferer());
	}
    $where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    $keytype = intval($_GET['keytype']);
	if($p=='adminxfjl'){	
        if($key){
            if($keytype==1){
                $where=" WHERE buyer ='$key' ";
            }elseif($keytype==2){
                $where=" WHERE seller ='$key' ";
            }else{
                $where=" WHERE title ='$key' ";
            }
	        $keync=urlencode($key);
	        $pageadd="&keytype=$keytype&key=$keync";
        }
	    $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_record').$where);
	}elseif($p=='adminpingfenjiangli'){
        if($key){
            if($keytype==1){
                $where=" WHERE author ='$key' ";
            }elseif($keytype==2){
                $where=" WHERE title ='$key' ";
	        }
	        $keync=urlencode($key);
	        $pageadd="&keytype=$keytype&key=$keync";
        }
	    $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_pinglunjiangli').$where);
	}
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 30;
    if($counts) {
  	    if($p=='adminxfjl'){	
	        $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_record')." $where ORDER BY dateline DESC LIMIT $starts,30");
        }elseif($p=='adminpingfenjiangli'){
		    $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_pinglunjiangli')." $where ORDER BY dateline DESC LIMIT $starts,30");
        }
	    $manylist = $manylists = array();
	    while($manylist = DB::fetch($query)){
		    $manylists[] = $manylist;
	    }
    }
	$multis = "<div class='pages cl' style='margin:5px'>".multi($counts, 30, $pages, 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p='.$p.$pageadd)."</div>";
} elseif ($p == 'add') {
    $groups = unserialize($groups);
    if (!in_array($_G['groupid'], $groups)) {
        showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo') , '', array() , array('login' => true));
    } else {
        include_once 'source/plugin/xlwsq_tuku/class/upic.class.php';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
        while ($row = DB::fetch($query)) {
            $cates[$row['id']] = $row;
        }
        $zhuantiquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_zhuanti') . "  ORDER BY diynum DESC,id ASC");
        while ($zhuanti = DB::fetch($zhuantiquery)) {
            $zhuantis[] = $zhuanti;
        }
        $grouplistquery = DB::query("SELECT * FROM " . DB::table('common_usergroup') . "  ORDER BY groupid ASC");
        while ($grouplist = DB::fetch($grouplistquery)) {
            $grouplists[] = $grouplist;
        }
        if (submitcheck('applysubmit')) {
            $title = dhtmlspecialchars($_GET['title']);
			$cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
		    $sd1 = dhtmlspecialchars($_GET['sd1']);
		    $sd2 = dhtmlspecialchars($_GET['sd2']);
		    $sd3 = dhtmlspecialchars($_GET['sd3']);
		    $sd4 = dhtmlspecialchars($_GET['sd4']);
		    $sd5 = dhtmlspecialchars($_GET['sd5']);
            $info = dhtmlspecialchars($_GET['info']);
			$price=intval($_GET['price']);
            $dpname = dhtmlspecialchars(merge_spaces($_GET['dpname']));
            $biaoqian = dhtmlspecialchars(merge_spaces($_GET['biaoqian']));
		    $tuijian=intval($_GET['tuijian']);
			$top=intval($_GET['top']);
            if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
                 $display =1; 
            }else{
				 $display =0; 
            }
			$diynum=intval($_GET['diynum']);
            $zhuanti =  dhtmlspecialchars(implode(',',$_GET["zhuanti"]));
            $viewgroup =  dhtmlspecialchars(implode(',',$_GET["viewgroup"]));
            DB::insert('plugin_xlwsq_tuku_item', array(
                'id' => '',
                'uid' => $_G['uid'],
                'author' => $_G['username'],
                'title' => $title,
                'cate' => $cate,
                'sd1' => $sd1,
                'sd2' => $sd2,
                'sd3' => $sd3,
                'sd4' => $sd4,
                'sd5' => $sd5,
                'info' => $info,
                'price' => $price,
                'dpname' => $dpname,
                'biaoqian' => $biaoqian,
                'top' => $top,
                'tuijian' => $tuijian,
                'display' => $display,
                'diynum' => $diynum,
                'zhuanti' => $zhuanti,
                'viewgroup' => $viewgroup,
                'dateline' => $_G['timestamp']
            ));
            $picid = DB::insert_id();
            if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
                if ($upimgset!=2) {
                   showmessage(lang('plugin/xlwsq_tuku', 'chuangjianchenggong') , 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=html5up&sid='.$picid, array() , array('alert' => 'right'));
				} else {
                   showmessage(lang('plugin/xlwsq_tuku', 'chuangjianchenggong') , 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=addpic&sid='.$picid, array() , array('alert' => 'right'));
                }
             } else {
                for ($i = 0; $i < count($admins); $i++) {
                    $message = '<a href="plugin.php?id=xlwsq_tuku&#58;xlwsq_tuku_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_tuku', 'yonghufabuxinxinxi') . '</a>';
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                }
                showmessage(lang('plugin/xlwsq_tuku', 'chuangjianchenggongdaishen') , 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=html5up&sid='.$picid, array() , array('alert' => 'right'));
            }
        }
    }
} elseif ($p == 'edit') {
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id='$id'");
	!$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    include_once 'source/plugin/xlwsq_tuku/class/upic.class.php';
    $uid = intval($active['uid']);
    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_tuku', 'caozuocuowu') , '', array() , array('login' => true));
    }
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    $zhuantiquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_zhuanti') . "  ORDER BY diynum DESC,id ASC");
    while ($zhuanti = DB::fetch($zhuantiquery)) {
        $zhuantis[] = $zhuanti;
    }
    $grouplistquery = DB::query("SELECT * FROM " . DB::table('common_usergroup') . "  ORDER BY groupid ASC");
    while ($grouplist = DB::fetch($grouplistquery)) {
        $grouplists[] = $grouplist;
    }
    $zhuantiarray = change($active['zhuanti']);
    $grouplistarray = change($active['viewgroup']);
    if (submitcheck('applysubmit')) {
        $title = dhtmlspecialchars($_GET['title']);
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
		$sd1 = dhtmlspecialchars($_GET["sd1"]);
		$sd2 = dhtmlspecialchars($_GET["sd2"]);
		$sd3 = dhtmlspecialchars($_GET["sd3"]);
		$sd4 = dhtmlspecialchars($_GET["sd4"]);
		$sd5 = dhtmlspecialchars($_GET["sd5"]);
        $info = dhtmlspecialchars($_GET['info']);
		$price=intval($_GET['price']);
        $dpname = dhtmlspecialchars(merge_spaces($_GET['dpname']));
        $biaoqian = dhtmlspecialchars(merge_spaces($_GET['biaoqian']));
        $top = intval($_GET['top']);
        $tuijian = intval($_GET['tuijian']);
        if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
            $display = 1;
        } else {
            $display = 0;
        }
        $diynum = intval($_GET['diynum']);
        if ($_G['groupid']=="1" ||in_array($_G['uid'], $admins)){
            $viewgroup =  dhtmlspecialchars(implode(',',$_GET["viewgroup"]));
            $zhuanti =  dhtmlspecialchars(implode(',',$_GET["zhuanti"]));
        } else {
            $viewgroup =  dhtmlspecialchars($_GET["viewgroup"]);
            $zhuanti =  dhtmlspecialchars($_GET["zhuanti"]);
        }
        DB::update('plugin_xlwsq_tuku_item', array(
            'title' => $title,
            'cate' => $cate,
            'sd1' => $sd1,
            'sd2' => $sd2,
            'sd3' => $sd3,
            'sd4' => $sd4,
            'sd5' => $sd5,
            'info' => $info,
            'price' => $price,
            'dpname' => $dpname,
            'biaoqian' => $biaoqian,
            'top' => $top,
            'tuijian' => $tuijian,
            'display' => $display,
            'diynum' => $diynum,
            'viewgroup' => $viewgroup,
            'zhuanti' => $zhuanti
        ) , "id='$id'");
        if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
		    showmessage(lang('plugin/xlwsq_tuku', 'gengxinok') , dreferer());
        } else {
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_tuku&#58;xlwsq_tuku_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_tuku', 'yonghufabuxinxinxi') . '</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
            showmessage(lang('plugin/xlwsq_tuku', 'fabudengdaishenhe') , dreferer());
        }
    }
} elseif ($p == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $where=$pageadd="";
    if($_GET['key']!=''){
        $key=stripsearchkey(trim($_GET['key']));
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_favorites') . " WHERE uid='$uid'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 20;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_favorites') . " WHERE $where uid = '$uid' ORDER BY dateline DESC LIMIT $starts,20");
        while ($sc = DB::fetch($query)) {
            $scs[] = $sc;
        }
    }
    $multis = "<div class='pages cl'>" . multi($counts, 20, $pages, 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p='.$p . $pageadd) . "</div>";
} elseif ($p == 'favoritesdel') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_favorites') . " WHERE id = '$id' and uid = '$uid'");
	!$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    if ($_GET['formhash'] == FORMHASH) {
        DB::query("DELETE FROM " . DB::table('plugin_xlwsq_tuku_favorites') . " WHERE id = '$id' and uid = '$uid'");
        showmessage(lang('plugin/xlwsq_tuku', 'shanchuok') , dreferer());
    }
} elseif ($p == 'addpic') {
    if (file_exists("source/plugin/xlwsq_tuku/qiniusdk/autoload.php") && $pingtaiset==1) {
        require_once 'qiniusdk/autoload.php';
    }else{
        include_once 'source/plugin/xlwsq_tuku/class/upic.class.php';
        include_once 'source/plugin/xlwsq_tuku/class/watermark.class.php';
    }
    $sid = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id='$sid'");
	!$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    $uid = intval($active['uid']);
    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_tuku', 'caozuocuowu') , '', array() , array('login' => true));
    }
    if (submitcheck('addpic')) {
	   $count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid'");
       if ($maxpic <= $count) {
	       showmessage(lang('plugin/xlwsq_tuku', 'tianjiatupianshibai'), dreferer());
	   }
        if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
            $display = 1;
        } else {
            $display = 0;
        }
        for ($i = 1; $i <= $maxpic - $count; $i++) {
           $pic = 'pic'.$i;
           $diynum = 'diynum'.$i;
	       $picinfo = 'picinfo'.$i;
           if ($_FILES[$pic]['tmp_name']) {
			   		$picsize = $_FILES[$pic]['size'];
				    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
				       if ($imageinfo[0] <= 0) {
                          showmessage(lang('plugin/xlwsq_tuku', 'feifatupianleixing'));
				       }
                    $picname = $_FILES[$pic]['name'];
                    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
					$arr=explode(".", strtolower($_FILES[$pic]["name"]));
                    $hz = $arr[count($arr) - 1];
                    if (!in_array($hz, $filetype)) {
                       showmessage(lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque'));
                    }
	                if($qiniuconfig['upToken']){
                        $$pic = qiniuupload($_FILES[$pic]);
                        $$spic =$$pic.$qiniusimg;
	                }else{
                        $update = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999);
                        $pics =$update. "." . $hz;
                        $spics =$update .  "_s" ."." . $hz;
				        $img_dir = "source/plugin/xlwsq_tuku/upimg/".$sid. "/";
                        if (!is_dir($img_dir)) {
                            mkdir($img_dir);
                        }
                        $$pic = $img_dir . $pics;
                        $$spic = $img_dir. $spics;
			            if($picsize <= $uploaddx){ 
                            if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
					            @copy($_FILES[$pic]['tmp_name'], $$spic);@unlink($_FILES[$pic]['tmp_name']);
                            }
			            }else{
				            showmessage(lang('plugin/xlwsq_tuku', 'tupiantaida'));	
			            }
					    if ($imageinfo[0] > 300) {
			     	        new myThumbClass($$spic,1,2,$$spic,1,300); 
					    }
				        if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
					        new myThumbClass($$pic,1,2,$$pic,1,$newpicwidth); 
				        }
                        if($imgwater && $imageinfo[0] > $waterwidth){
	                        $wm = new WaterMark();
	                        $wm->setImSrc($$pic);
	                        $wm->setImWater($imgwater);
	                        $wm->mark(1,$imgwaterweizhi,0,0);
                        }
	                }
                    DB::insert('plugin_xlwsq_tuku_img', array('id' => '','diynum' => intval($_GET[$diynum]),'sid' => $sid,'img' => $$pic,'simg' => $$spic,'picinfo' => dhtmlspecialchars($_GET[$picinfo]),'display' => $display,'savearea' => $pingtaiset,'dateline' => $_G['timestamp']));
				    $fengmianpic = $$spic ? $$spic : $$pic;
           }elseif($_GET[$pic]!=''){
		            DB::insert('plugin_xlwsq_tuku_img', array('id' => '','diynum' => intval($_GET[$diynum]),'sid' => $sid,'img' =>dhtmlspecialchars($_GET[$pic]),'picinfo' => dhtmlspecialchars($_GET[$picinfo]),'display' => $display,'savearea' => $pingtaiset,'dateline' => $_G['timestamp']));
				   $fengmianpic = dhtmlspecialchars($_GET[$pic]);
		   }
          $fengmiancount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND fengmian='1'");
		  if ($fengmiancount == '0') {
            $picid = DB::insert_id();
            DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='0' where sid=$sid");
	        DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='1' where id=$picid");
	    	DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set pic='$fengmianpic' where id=$sid");
          }
           $piccount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND display!='0'");
           DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set piccount='$piccount' where id=$sid");
        }
        if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
                showmessage(lang('plugin/xlwsq_tuku', 'tijiaochenggong') , 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=addpiclist&sid='.$sid, array() , array('alert' => 'right'));
             } else {
                for ($i = 0; $i < count($admins); $i++) {
                    $message = '<a href="plugin.php?id=xlwsq_tuku&#58;xlwsq_tuku_user&p=adminpic&action=daishen" target="_blank">' . lang('plugin/xlwsq_tuku', 'yongtupianxinxi') . '</a>';
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                }
                showmessage(lang('plugin/xlwsq_tuku', 'fabudengdaishenhe') , 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=addpiclist&sid='.$sid, array() , array('alert' => 'right'));
        }
    }
} elseif ($p == 'addpiclist') {
    $sid = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id='$sid'");
	!$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    $uid = intval($active['uid']);
    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_tuku', 'caozuocuowu') , '', array() , array('login' => true));
    }
	$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 15;
    if($sortset=='1'){
      $sort='DESC';
	}else{
      $sort='ASC';
	}
	if($countr) {
	    $picquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_img')." WHERE sid = '$sid' ORDER BY diynum ASC,id $sort LIMIT $starts,15");
	    while($piclist = DB::fetch($picquery)){
		    $piclists[] = $piclist;
	    }
	}
	$multir =multi($countr, 15, $pages,'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=addpiclist&sid='.$sid.''.$pageadd);
    if(submitcheck('editpicsubmit')){	
		foreach($_GET['picinfo'] as $id => $val) {
		    DB::update('plugin_xlwsq_tuku_img', array('diynum' => intval($_GET['diynum'][$id]),'picinfo' => dhtmlspecialchars($_GET['picinfo'][$id])), "id='$id'");
		}
        $piccount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND display!='0'");
        DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set piccount='$piccount' where id=$sid");
	    showmessage(lang('plugin/xlwsq_tuku', 'gengxinok') , dreferer());
	}elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
	        $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_img')." WHERE id = '$aid'");
	        while($delz = DB::fetch($query)){
		        if ($delz["img"]!=false){
			      unlink($delz["img"]);
		        }
		        if ($delz["simg"]!=false){
		          unlink($delz["simg"]);
		        }
	        }
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_tuku_img') . " WHERE id = '$aid' AND sid = '$sid'");
        	$piccount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_img'). " WHERE sid='$sid' AND display!='0'");
	        DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set piccount='$piccount' where id=$sid");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_tuku', 'shanchuok') , dreferer());
    }
} elseif ($p == 'massuppic'||$p == 'html5up') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id='$sid'");
	!$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    if ($active['uid'] != $_G['uid'] && $_G['groupid'] != "1" && !in_array($_G['uid'], $admins)) {
        showmessage(lang('plugin/xlwsq_tuku', 'caozuocuowu') , '', array() , array('login' => true));
    }
} elseif ($p == 'fengmianshezhi') {
    $sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id='$sid'");
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$item['uid'] == $_G['uid']) {
        $picid = intval($_GET['picid']);
        $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_img') . " WHERE id='$picid'");
		!$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'), dreferer()) : '';
        $img = dhtmlspecialchars($active['img']);
        $simg= dhtmlspecialchars($active['simg']);
        $pic = $simg ? $simg : $img;
        if ($_GET['formhash'] == FORMHASH) {
	    	DB::query("update ".DB::table("plugin_xlwsq_tuku_item")." set pic='$pic' where id=$sid");
            DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='0' where sid=$sid");
	    	DB::query("update ".DB::table("plugin_xlwsq_tuku_img")." set fengmian='1' where id=$picid");
            showmessage(lang('plugin/xlwsq_tuku', 'gengxinok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_tuku', 'caozuocuowu'));
    }
} elseif ($p == 'shenheok') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id='$id'");
	    !$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tuku_item') . " SET display='1' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_tuku', 'shenheok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_tuku', 'caozuocuowu'));
    }
} elseif ($p == 'qxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id='$id'");
        !$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_tuku_item') . " SET display='0' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_tuku', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_tuku', 'caozuocuowu'));
    }
} elseif ($p == 'del') {
    $uid = intval($_G['uid']);
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_item') . " WHERE id ='$id'");
	!$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$active['uid']==$uid) {
        if ($_GET['formhash'] == FORMHASH) {
           deldir("source/plugin/xlwsq_tuku/upimg/".$id);
           DB::query("DELETE a,b,c,d FROM ".DB::table('plugin_xlwsq_tuku_item')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_tuku_img')." AS b ON a.id = b.sid LEFT JOIN ".DB::table('plugin_xlwsq_tuku_post')." AS c ON a.id = c.sid LEFT JOIN ".DB::table('plugin_xlwsq_tuku_reply')." AS d ON d.id = d.dpid WHERE a.id = '$id' ");
		   showmessage(lang('plugin/xlwsq_tuku', 'shanchuok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_tuku', 'caozuocuowu'));
    }
}elseif($p=='xfjl'||$p=='syjl'){
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $where=$pageadd="";
    if($_GET['key']!=''){
        $key=stripsearchkey(trim($_GET['key']));
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	$uid = intval($_G['uid']);
	if($p=='xfjl'){
	    $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_record')." WHERE $where buyuid='$uid'");
    }elseif($p=='syjl'){
	    $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_tuku_record')." WHERE $where selluid='$uid' AND sellincome >'0' ");
    }
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
	   if($p=='xfjl'){
          $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_record')." WHERE $where buyuid='$uid' ORDER BY dateline DESC LIMIT $starts,20");
       }elseif($p=='syjl'){
	      $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_record')." WHERE $where selluid='$uid' AND sellincome >'0'  ORDER BY dateline DESC LIMIT $starts,20");
       }
	   while($manylist = DB::fetch($query)){
	   	    $manylists[] = $manylist;
	   }
    }
	$multis = "<div class='pages cl'>".multi($counts, 20, $pages, 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p='.$p.$pageadd)."</div>";
}elseif($p=='zhuantiadd'){	
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        include_once 'source/plugin/xlwsq_tuku/class/upic.class.php';
	    if(submitcheck('addzhuantisubmit')){
            $title = dhtmlspecialchars($_GET['title']);
            $pic = dhtmlspecialchars($_GET['pic']);
            $info = dhtmlspecialchars($_GET['info']);
            $diynum = intval($_GET['diynum']);
            $display = intval($_GET['display']);
			if($_FILES['file']['error']==0){
				$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
				$arr=explode(".", $_FILES["file"]["name"]);
				$hz=$arr[count($arr)-1];
				if(!in_array($hz, $filetype)){
					showmessage(lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque'));	
				}
				$imageinfo = getimagesize($_FILES['file']['tmp_name']);
				if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque'));
				}
				$filepath = "source/plugin/xlwsq_tuku/zhuanti/";
				$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
				if(!file_exists($filepath)){ mkdir($filepath); }			
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					 @unlink($_FILES['file']['tmp_name']);
				}
				$pic = "source/plugin/xlwsq_tuku/zhuanti/".$randname."";
				if ($imageinfo[0] > $zhuantilogowidth) {
			     	 new myThumbClass($pic,1,2,$pic,1,$zhuantilogowidth); 
				}
			}
		    DB::insert('plugin_xlwsq_tuku_zhuanti',array('id' => '','title' => $title,'pic' => $pic,'info' => $info, 'diynum' => $diynum,'display' => $display,'dateline' => $_G['timestamp']));
		    showmessage(lang('plugin/xlwsq_tuku', 'fabuchenggong'), "plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=zhuanti", array(), array('alert' => right));
	    }
    }else{
		showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
    }
}elseif($p=='zhuantiedit'){	
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        include_once 'source/plugin/xlwsq_tuku/class/upic.class.php';
        $id=intval($_GET['bid']);
	    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_zhuanti')." WHERE id ='$id'");
	    !$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
	    if(submitcheck('editzhuantisubmit')){
            $title = dhtmlspecialchars($_GET['title']);
            $pic = dhtmlspecialchars($_GET['pic']);
            $info = dhtmlspecialchars($_GET['info']);
            $diynum = intval($_GET['diynum']);
            $display = intval($_GET['display']);
			if($_FILES['file']['error']==0){
                if ($active["pic"]!=false){
	                unlink($active["pic"]);
	            }
				$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
				$arr=explode(".", $_FILES["file"]["name"]);
				$hz=$arr[count($arr)-1];
				if(!in_array($hz, $filetype)){
					showmessage(lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque'));	
				}
			    $imageinfo = getimagesize($_FILES['file']['tmp_name']);
				if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque'));
				}
				$filepath = "source/plugin/xlwsq_tuku/zhuanti/";
				$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
				if(!file_exists($filepath)){ mkdir($filepath); }
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					@unlink($_FILES['file']['tmp_name']);
				}
				$pic = "source/plugin/xlwsq_tuku/zhuanti/".$randname."";
				if ($imageinfo[0] > $zhuantilogowidth) {
			        new myThumbClass($pic,1,2,$pic,1,$zhuantilogowidth); 
				}
			}
		    DB::update('plugin_xlwsq_tuku_zhuanti',array('title' => $title,'pic' => $pic,'info' => $info,'diynum' => $diynum,'display' => $display,'dateline' => $_G['timestamp']),"id='$id'");
		    showmessage(lang('plugin/xlwsq_tuku', 'fabuchenggong'), dreferer());
	    }
    }else{
	    showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
    }
}elseif($p=='zhuanti'||$p=='banner'){	
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $where=$pageadd="";
        if($_GET['key']){
            $key=stripsearchkey($_GET['key']);
	        $where=" where title like '%".addcslashes(addslashes($key), '%_')."%'";
	        $keync=urlencode($key);
	        $pageadd="&key=$keync";
        }
        if($p=='zhuanti'){	
	        $count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_zhuanti').$where);
        }elseif($p=='banner'){	
	        $count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_tuku_banner').$where);
        }
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 10;
        if ($count) {
            if($p=='zhuanti'){	
   	            $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_zhuanti') . " $where ORDER BY diynum DESC,id DESC LIMIT $starts,10");
            }elseif($p=='banner'){	
                $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_tuku_banner') . " $where ORDER BY diynum DESC,id DESC LIMIT $starts,10");
            }
            while ($manylist = DB::fetch($query)) {
                $manylists[] = $manylist;
            }
        }
        $multis = "<div class='pages cl' style='margin:10px 0;'>" . multi($count, 10, $pager, 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p='.$p . $pageadd) . "</div>";
    }else{
		showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
    }
}elseif ($p=='zhuantidel'||$p=='bannerdel'){
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id=intval($_GET['bid']);
        if($p=='zhuantidel'){	
	        $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_zhuanti')." WHERE id ='$id'");
        }elseif($p=='bannerdel'){	
	        $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_banner')." WHERE id ='$id'");
        }
	    !$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
        if($_GET['formhash'] == FORMHASH) {
			if ($active["pic"]!=false){
		        unlink($active["pic"]);
	        }
            if($p=='zhuantidel'){	
	            DB::query("DELETE FROM ".DB::table('plugin_xlwsq_tuku_zhuanti')." WHERE id = '$id'");
                showmessage(lang('plugin/xlwsq_tuku', 'shanchuok'), 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=zhuanti', array(), array('alert' => 'right'));
            }elseif($p=='bannerdel'){	
	            DB::query("DELETE FROM ".DB::table('plugin_xlwsq_tuku_banner')." WHERE id = '$id'");
                showmessage(lang('plugin/xlwsq_tuku', 'shanchuok'), 'plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=banner', array(), array('alert' => 'right'));
            }
        }
    }else{
        showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
    }
}elseif($p=='banneradd'){	
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	    if(submitcheck('addbannersubmit')){
            $title = dhtmlspecialchars($_GET['title']);
            $pic = dhtmlspecialchars($_GET['pic']);
            $url = dhtmlspecialchars($_GET['url']);
            $display = intval($_GET['display']);
            $diynum = intval($_GET['diynum']);
            $timestamp = $_G['timestamp'];
			if($_FILES['file']['error']==0){
				$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
				$arr=explode(".", $_FILES["file"]["name"]);
				$hz=$arr[count($arr)-1];
				if(!in_array($hz, $filetype)){
					showmessage(lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque'));	
				}
				$filepath = "source/plugin/xlwsq_tuku/banner/";
				$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
				if(!file_exists($filepath)){ mkdir($filepath); }			
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					@unlink($_FILES['file']['tmp_name']);
				}
				$pic = "source/plugin/xlwsq_tuku/banner/".$randname."";
			}
		    DB::insert('plugin_xlwsq_tuku_banner',array('id' => '','title' => $title,'pic' => $pic,'url' => $url,'display' => $display, 'diynum' => $diynum, 'dateline' => $timestamp));
		    showmessage(lang('plugin/xlwsq_tuku', 'fabuchenggong'), "plugin.php?id=xlwsq_tuku:xlwsq_tuku_user&p=banner", array(), array('alert' => 'right'));
	    }
    }else{
		showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
    }
}elseif($p=='banneredit'){	
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id=intval($_GET['bid']);
	    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_tuku_banner')." WHERE id ='$id'");
	    !$active ? showmessage(lang('plugin/xlwsq_tuku', 'error'),"plugin.php?id=xlwsq_tuku") : '';
	    if(submitcheck('editbannersubmit')){
            $title = dhtmlspecialchars($_GET['title']);
            $pic = dhtmlspecialchars($_GET['pic']);
            $url = dhtmlspecialchars($_GET['url']);
            $display = intval($_GET['display']);
            $diynum = intval($_GET['diynum']);
			if($_FILES['file']['error']==0){
                if ($active["pic"]!=false){
	                unlink($active["pic"]);
	            }
				$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
				$arr=explode(".", $_FILES["file"]["name"]);
				$hz=$arr[count($arr)-1];
				if(!in_array($hz, $filetype)){
					showmessage(lang('plugin/xlwsq_tuku', 'tupiangeshibuzhengque'));	
				}
				$filepath = "source/plugin/xlwsq_tuku/banner/";
				$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
				if(!file_exists($filepath)){ mkdir($filepath); }
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					 @unlink($_FILES['file']['tmp_name']);
				}
				$pic = "source/plugin/xlwsq_tuku/banner/".$randname."";
			}
		    DB::update('plugin_xlwsq_tuku_banner',array('title' => $title,'pic' => $pic,'url' => $url,'display' => $display,'diynum' => $diynum),"id='$id'");
		    showmessage(lang('plugin/xlwsq_tuku', 'fabuchenggong'), dreferer());
	    }
    }else{
	    showmessage(lang('plugin/xlwsq_tuku', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
    }
}
include (template("xlwsq_tuku:xlwsq_tuku_user"));
?>