<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$blockclass = array(
	'name' => lang('plugin/xlwsq_card','blockclass_xlwsq_card'), 
);

?>