<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class block_xlwsq_card extends discuz_block{
	var $setting = array();
	function block_xlwsq_card(){
		$this->setting = array(
			'titlelength' => array(
				'title' =>  lang('plugin/xlwsq_card','blockclass_biaotiling'),
				'type' => 'text',
				'default' => 40
			),
			'infolength'	=> array(
				'title' => lang('plugin/xlwsq_card','blockclass_infoling'),
				'type' => 'text',
				'default' => 80
			),
			'param' => array(
				'title' => lang('plugin/xlwsq_card','blockclass_fangshi'),
				'type' => 'select',
				'value' => array(
					array('0', lang('plugin/xlwsq_card','blockclass_news')),
					array('1', lang('plugin/xlwsq_card','blockclass_top')),
					array('2', lang('plugin/xlwsq_card','blockclass_tuijian')),
				),
				'default' => '0'
			),
			'catid' => array(
				'title' => lang('plugin/xlwsq_card','blockclass_cate'),
				'type' => 'select',
				'value' => array()
			),
			'areaid' => array(
				'title' => lang('plugin/xlwsq_card','blockclass_area'),
				'type' => 'select',
				'value' => array()
			),
			'cardpic' => array(
				'title' => lang('plugin/xlwsq_card','blockclass_pic3'),
				'type' => 'radio',
			    'value' => '0'
			),
			'startrow' => array(
				'title' => lang('plugin/xlwsq_card','blockclass_qishihangshu'),
				'type' => 'text',
				'default' => 0
			),
		);
	}
	function name() {
		return  lang('plugin/xlwsq_card','blockclass_data');
	}
	function blockclass() {
		return array('sample', lang('plugin/xlwsq_card','blockclass_mokuai'));
	}
	function fields() {
		return array(
			'id' => array('name' => lang('plugin/xlwsq_card', 'blockclass_id'), 'formtype' => 'text', 'datatype' => 'int'),
			'title' => array('name' => lang('plugin/xlwsq_card','blockclass_title'), 'formtype' => 'title', 'datatype' => 'title'),
			'url' => array('name' => lang('plugin/xlwsq_card', 'blockclass_url'), 'formtype' => 'text', 'datatype' => 'string'),
			'pic' => array('name' => lang('plugin/xlwsq_card','blockclass_pic'), 'formtype' => 'pic', 'datatype' => 'pic'),
			'pic2' => array('name' => lang('plugin/xlwsq_card','blockclass_pic2'), 'formtype' => 'pic', 'datatype' => 'pic'),
			'cate' => array('name' => lang('plugin/xlwsq_card','blockclass_cate'), 'formtype' => 'text', 'datatype' => 'string'),
			'area' => array('name' => lang('plugin/xlwsq_card','blockclass_area'), 'formtype' => 'text', 'datatype' => 'string'),
			'lianxiren' => array('name' => lang('plugin/xlwsq_card','blockclass_lianxiren'), 'formtype' => 'text', 'datatype' => 'string'),
			'tel' => array('name' => lang('plugin/xlwsq_card','blockclass_tel'), 'formtype' => 'text', 'datatype' => 'string'),
			'weixin' => array('name' => lang('plugin/xlwsq_card','blockclass_weixin'),'formtype' => 'text', 'datatype' => 'string'),
			'http' => array('name' => lang('plugin/xlwsq_card','blockclass_web'), 'formtype' => 'text', 'datatype' => 'string'),
			'info' => array('name' => lang('plugin/xlwsq_card','blockclass_info'), 'formtype' => 'text', 'datatype' => 'string'),
			'address' => array('name' => lang('plugin/xlwsq_card','blockclass_address'), 'formtype' => 'text', 'datatype' => 'string'),
			'view' => array('name' => lang('plugin/xlwsq_card','blockclass_view'), 'formtype' => 'text', 'datatype' => 'int'),
			'dateline' => array('name' => lang('plugin/xlwsq_card','blockclass_dateline'), 'formtype' => 'date', 'datatype' => 'date'),
		);
	}
	function getsetting() {
		global $_G;
		$settings = $this->setting;
        $cates =DB::fetch_all("SELECT * FROM ".DB::table('plugin_xlwsq_card_cate')." WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
		if($settings['catid']) {
		   $settings['catid']['value'][] = array(0,lang('plugin/xlwsq_card','blockclass_quanbu'));
		   foreach($cates as $value) {
			  if($value['upid'] == 0) {
				 $settings['catid']['value'][] = array($value['id'], $value['subject']);
				 $cate_t = DB::fetch_all("SELECT * FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE upid = '$value[id]'");
				 foreach($cate_t as $subid) {
					$settings['catid']['value'][] = array($subid['id'],str_repeat('&nbsp;', 4).$subid['subject']);
				 }
			  }
		   }
	    }
        $areas =DB::fetch_all("SELECT * FROM ".DB::table('plugin_xlwsq_card_area')." WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
		if($settings['areaid']) {
		   $settings['areaid']['value'][] = array(0,lang('plugin/xlwsq_card','blockclass_quanbu'));
		   foreach($areas as $value) {
			  if($value['upid'] == 0) {
				 $settings['areaid']['value'][] = array($value['id'], $value['subject']);
				 $area_t = DB::fetch_all("SELECT * FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE upid = '$value[id]'");
				 foreach($area_t as $subid) {
					$settings['areaid']['value'][] = array($subid['id'],str_repeat('&nbsp;', 4).$subid['subject']);
				 }
			  }
		   }
	    }
		return $settings;
	}
	function getdata($style, $parameter) {
		global $_G;
		$returndata = array('html' => '', 'data' => '');
		$parameter = $this->cookparameter($parameter);
		$titlelength = isset($parameter['titlelength']) ? intval($parameter['titlelength']) : 40;
		$infolength = isset($parameter['infolength']) ? intval($parameter['infolength']) : 80;
		$startrow	 = isset($parameter['startrow']) ? intval($parameter['startrow']) : 0;
		$items		 = !empty($parameter['items']) ? intval($parameter['items']) : 10;
		$bannedids = !empty($parameter['bannedids']) ? explode(',', $parameter['bannedids']) : array();
		$sqlban = !empty($bannedids) ? ' AND id NOT IN ('.dimplode($bannedids).')' : '';
		if($parameter['catid']!=0){	
			$catid =  $parameter['catid'];
			  $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id='$catid'");
              if ($subids) {
                     $cid = "cate IN ($catid,$subids) AND";
                   } else {
                     $cid = "cate=$catid AND";
              }
		}
		if($parameter['areaid']!=0){	
			$areaid =  $parameter['areaid'];
			  $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id='$areaid'");
              if ($subids) {
                     $aid = "area IN ($areaid,$subids) AND";
                   } else {
                     $aid = "area=$areaid AND";
              }
		}
		if($parameter['cardpic']!=0){	
            $pic = "pic !='' AND";
		}
		if($parameter['param']==0){	
            $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_card_item')." WHERE  $cid $aid $pic display!='0' $sqlban ORDER BY dateline DESC LIMIT $startrow, $items");
		}elseif($parameter['param']==1){
            $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_card_item')." WHERE  $cid $aid $pic top='1' AND display!='0' $sqlban ORDER BY dateline DESC LIMIT $startrow, $items");
		}elseif($parameter['param']==2){
			$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_card_item')." WHERE  $cid $aid $pic view >'1' AND  display!='0' $sqlban ORDER BY view DESC LIMIT $startrow, $items");
		}
		$datalist = $list = array();
		while($data = DB::fetch($query)) {
			$cate = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_card_cate')." WHERE id = '$data[cate]'");
				   if($cate['upid']!=0){
				      $cate_t = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_card_cate')." WHERE id = '$cate[upid]'");
			          $data['cate'] = $cate_t['subject'];
			          $data['scate'] = $cate['subject'];
				   }else{
			          $data['cate'] = $cate['subject'];
		           }
			$area = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_card_area')." WHERE id = '$data[area]'");
				   if($area['upid']!=0){
				      $area_t = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_card_area')." WHERE id = '$area[upid]'");
			          $data['area'] = $area_t['subject'];
			          $data['sarea'] = $area['subject'];
				   }else{
			          $data['area'] = $area['subject'];
		           }
			$list[] = array(
				'id' => $data['id'],
				'idtype' => 'id',
				'url' => 'plugin.php?id=xlwsq_card&mod=view&sid='.$data['id'],
			    'title' => cutstr($data['title'], $titlelength, ''),
				'fields' => array(
				    'info' => cutstr($data['info'], $infolength, ''),
				    'cate' => $data['cate'],
				    'area' => $data['area'],
					'pic' => $data['pic'],
					'pic2' => $data['pic2'],
					'lianxiren' => $data['lianxiren'],
					'tel' => $data['tel'],
					'http' => $data['url'],
					'weixin' => $data['weixin'],
					'view' => $data['view'],
					'address' => $data['address'],
					'dateline' => $data['dateline'],
				)
			);
		}
		return array('html' => '', 'data' => $list);
	}
}
?>