<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_card_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(4) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `author` varchar(80) NOT NULL,
	  `cate` int(11) NOT NULL,
	  `area` int(11) NOT NULL,
	  `title` varchar(255) NOT NULL,
	  `pic` varchar(255) NOT NULL,
   	  `pic2` varchar(255) NOT NULL,
   	  `address`  varchar(255) NOT NULL,
   	  `tel`  varchar(100) NOT NULL,
   	  `qq`  varchar(20) NOT NULL,
   	  `email`  varchar(100) NOT NULL,
   	  `lianxiren` varchar(50) NOT NULL,
   	  `weixin`  varchar(100) NOT NULL,
   	  `url` text NOT NULL,
	  `info` text NOT NULL,
	  `view` int(11) NOT NULL,
	  `top` tinyint(1)  NOT NULL,
	  `tuijian` tinyint(1)  NOT NULL,
	  `color` text NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `updateline` int(11) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_card_cate` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` varchar(255) NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(1) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_card_area` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(1) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_card_favorites` (
   	  `id` int(11) NOT NULL auto_increment,
 	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
INSERT INTO `pre_plugin_xlwsq_card_cate` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '', '$installlang[cate1]', 0),
(2, 0, '', '$installlang[cate2]', 0),
(3, 0, '', '$installlang[cate3]', 0),
(4, 0, '', '$installlang[cate4]', 0),
(5, 0, '', '$installlang[cate5]', 0),
(6, 0, '', '$installlang[cate6]', 0),
(7, 0, '', '$installlang[cate7]', 0),
(8, 0, '', '$installlang[cate8]', 0);
EOF;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_card/discuz_plugin_xlwsq_card.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_card/discuz_plugin_xlwsq_card_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_card/discuz_plugin_xlwsq_card_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_card/discuz_plugin_xlwsq_card_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_card/discuz_plugin_xlwsq_card_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_card/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_card/install.php');
runquery($sql);
$finish =true;
?>