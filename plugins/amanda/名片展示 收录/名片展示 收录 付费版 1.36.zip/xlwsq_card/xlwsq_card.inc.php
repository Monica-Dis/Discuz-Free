<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/xlwsq_card/function/function_core.php';
global $_G;
if (!isset($_G['cache']['plugin'])) {loadcache('plugin');}
$plyes=($_G['cache']['plugin']['xlwsq_card']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
$viewgroups = unserialize($viewgroups);
if (!in_array($_G['groupid'], $viewgroups)) {
	showmessage(lang('plugin/xlwsq_card', 'wuquanxianfangwen') , '', array() , array('login' => true));
}
if($_G['mobile']) {
  $menubgcolor=$mobilemenubgcolor;
  $eacha=$mobileeacha;
  $footad=$mobilefootad ? $mobilefootad : $footad;
}
$liimgheight = $liheight-30;
$appurl = $_G['siteurl'] . "plugin.php?id=xlwsq_card";
$fabuset = unserialize($groups);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$navtitle = $title;
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if($mod == 'index') {
	$where=$pageadd="";
    if ($_GET['key']) {
        $key=stripsearchkey($_GET['key']);
        $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND display!='0'  AND";
        $keync = urlencode($key);
        $pageadd = "&key=$keync";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id = '$cate_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
    }
    $sd = intval($_GET['b']);
    if ($sd) {
        $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id = '$sd'");
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
    }
    $area_id = intval($_GET['bc']);
    if ($area_id) {
        $marea = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id = '$area_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id='$area_id'");
        if ($subids) {
            $b_area = "area IN ($subids) AND";
        } else {
            $b_area = "area=$area_id AND";
        }
        $pageaddbc = "&bc=$area_id";
    }
    $s_area_id = intval($_GET['sc']);
    if ($s_area_id) {
        $mareab = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id = '$s_area_id'");
        $s_area = "area='$s_area_id' AND";
        $pageaddsc = "&sc=$s_area_id";
    }
    if ($_GET['paixu']=='tj') {
		$px="tuijian = '1' AND display ='1'  ORDER BY top DESC,diynum DESC,dateline DESC"; $pageadd="&paixu=tj";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_card_item') . " WHERE $where $wb $wc $b_area $s_area  tuijian = '1' AND display ='1' ");
	}elseif ($_GET['paixu']=='rq') {
		$px="display ='1' ORDER BY view DESC,dateline DESC"; $pageadd="&paixu=rq";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_card_item') . " WHERE $where $wb $wc $b_area $s_area  display ='1'");
	}else{
		$px="display ='1' ORDER BY top DESC,diynum DESC,updateline DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_card_item') . " WHERE $where $wb $wc $b_area $s_area  display ='1'");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
          $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_card_item') . " WHERE $where $wb $wc $b_area $s_area $px LIMIT $starts,$eacha");
        $mythread = $mythreads = array();
        while ($mythread = DB::fetch($query)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id = '$cate[upid]'");
                $mythread['catecid'] = $cate['upid'];
                $mythread['catescid'] = $mythread['cate'];
                $mythread['catename'] = $cate['subject'];
            } else {
                $mythread['catecid'] = $mythread['cate'];
                $mythread['catescid'] ='0';
                $mythread['catename'] = $cate['subject'];
            }
            $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id = '$mythread[area]'");
            if ($area['upid'] != 0) {
                $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id = '$area[upid]'");
                $mythread['areacid'] = $area['upid'];
                $mythread['areascid'] = $mythread['area'];
                $mythread['areaname'] = $area['subject'];
            } else {
                $mythread['areacid'] = $mythread['area'];
                $mythread['areascid'] ='0';
                $mythread['areaname'] = $area['subject'];
            }
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px;'>" . multi($counts, $eacha, $pages, $appurl .$pageadd. $pageadds . $pageaddbc . $pageaddsc . $pageaddx . $pageaddm) . "</div>";
    $r_id = intval($_GET['a']);
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    $bc_id = intval($_GET['bc']);
    $bc_subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id='$bc_id'");
    if ($bc_subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id IN ($bc_subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $local_sc[$ros['id']] = $ros;
        }
    }
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . " - " . $mcateb['subject']. " - ";
      } else {
           $catenav = $mcate['subject']. " - ";
      }
    }
    if ($area_id!='0') {
      if ($s_area_id!='0') {
           $areanav = $marea['subject'] . " - " . $mareab['subject']. " - ";
      } else {
           $areanav = $marea['subject']. " - ";
      }
    }
    $navtitle = $catenav . $areanav.$title;
    include template('xlwsq_card:list');
} elseif ($_GET['mod'] == 'view') {
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
        $error = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_item') . " WHERE id = '$sid' and display!='0'");
        !$error ? showmessage(lang('plugin/xlwsq_card', 'error') , "plugin.php?id=xlwsq_card") : '';
	}
    DB::query("UPDATE " . DB::table('plugin_xlwsq_card_item') . " SET `view` = view+1 WHERE `id` = '$sid'");
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_item') . " WHERE id='$sid'");
    $mythread['info'] = discuzcode($mythread['info']);
	$prev = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_card_item')." WHERE id>'$sid' AND display!='0' AND cate ='$mythread[cate]' ORDER BY id asc LIMIT 0,1");
	$next = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_card_item')." WHERE id<'$sid' AND display!='0' AND cate ='$mythread[cate]'  ORDER BY id desc LIMIT 0,1");
    $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id = '$mythread[cate]'");
	if ($cate['upid'] != 0) {
        $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_cate') . " WHERE id = '$cate[upid]'");
        $mythread['cate'] = $cate_t['subject'] . " - " . $cate['subject'];
        $mythread['b'] = $cate['id'];
        $mythread['a'] = $cate['upid'];
    } else {
        $mythread['cate'] = $cate['subject'];
        $mythread['a'] = $cate['id'];
        $mythread['b'] = '0';
    }
    $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id = '$mythread[area]'");
    if ($area['upid'] != 0) {
        $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_area') . " WHERE id = '$area[upid]'");
        $mythread['area'] = $area_t['subject'] . " - " . $area['subject'];
        $mythread['d'] = $area['id'];
        $mythread['c'] = $area['upid'];
    } else {
        $mythread['area'] = $area['subject'];
        $mythread['c'] = $area['id'];
        $mythread['d'] = '0';
    }
    $navtitle = $mythread['title'] . " - " . $title;
    $metadescription = cutstr(strip_tags($mythread['info']) , 100, '...');
    include template('xlwsq_card:view');
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_card_favorites') . " WHERE sid = '$sid' and uid = '$uid'");
            showmessage(lang('plugin/xlwsq_card', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
        } else {
            DB::insert('plugin_xlwsq_card_favorites', array(
                'id' => '',
                'sid' => $sid,
                'uid' => $uid,
                'dateline' =>$_G['timestamp']
            ));
            showmessage(lang('plugin/xlwsq_card', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
        }
    }
} elseif ($_GET['mod'] == 'freshen') {
    $sid = intval($_GET['sid']);
    $timestamp = $_G['timestamp'];
    $now = date('Y-m-d', $timestamp);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_card_item') . " WHERE id = '$sid'");
    $uid = intval($info['uid']);
    $updateline = date('Y-m-d', $info['updateline']);
    if ($_GET['formhash'] == FORMHASH) {
        if ($info['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
            if ($now == $updateline) {
                showmessage(lang('plugin/xlwsq_card', 'shuaxinshibai') , '', array() , array('alert' => 'error'));
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_card_item') . " SET `updateline` = '$timestamp' WHERE `id` = '$sid'");
                showmessage(lang('plugin/xlwsq_card', 'shuaxinok') , '', array() , array('alert' => 'right'));
            }
        } else {
            showmessage(lang('plugin/xlwsq_card', 'caozuocuowu') , dreferer());
        }
    }
}
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
//From: Dism_taobao_com
?>