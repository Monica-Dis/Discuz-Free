!
function(o) {
	o.fn.apphover = function(t) {
		var e, a = {
			offsetTarget: "body"
		};
		return e = t && t.offsetTarget ? t.offsetTarget: a.offsetTarget,
		this.on("mouseenter", "li",
		function() {
			var t = o(this);
			t.addClass("active"),
			t.find(".quickdown").animate({
				top: "0"
			},
			150,
			function() {
				o(this).show()
			})
		}).on("mouseleave", "li",
		function() {
			var t = o(this);
			t.removeClass("active"),
			t.find(".quickdown").css("top", "28px")
		}).on("mousemove", "li",
		function(t) {
			var a = o(this),
			i = a.find(".lxyqun-popover"),
			n = t.pageX,
			s = t.pageY,
			f = s - 100 - 160,
			r = n + 28;
			if (a.hasClass("last") && (r = n - 28 - 259), "body" !== e) {
				var p = o(e).position();
				f -= p.top,
				r -= p.left,
				f = 0 > f ? 2 : f
			}
			440 > s && (f = Math.max(f, 180)),
			i.css({
				top: f,
				left: r
			})
		})
	}
} (window.jQuery);