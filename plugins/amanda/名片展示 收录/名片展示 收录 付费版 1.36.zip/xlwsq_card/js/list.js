!
function() {
    jQuery(".lxyqun-bd").apphover()
} ();