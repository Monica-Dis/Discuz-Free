<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $qiniuconfig;
$qiniuconfig = array();
$qiniuconfig['qiniuak']       = $ak;
$qiniuconfig['qiniusk']       = $sk;
$qiniuconfig['qiniuyuming']   = $yuming;
$qiniuconfig['qiniukongjian'] = $kongjian;
if($quyu==1){
    $qiniuquyu='https://upload-z2.qiniup.com';//huanan
}elseif($quyu==2){
    $qiniuquyu='https://upload.qiniup.com';//huadong
}elseif($quyu==3){
    $qiniuquyu='https://upload-z1.qiniup.com';//huabei
}elseif($quyu==4){
    $qiniuquyu='https://upload-na0.qiniup.com';//beimei
}elseif($quyu==5){
    $qiniuquyu='https://upload-as0.qiniup.com';//dongnanya
}else{
    $qiniuquyu='https://upload-z2.qiniup.com';//huanan
}
if($qiniuconfig['qiniuak'] && $qiniuconfig['qiniusk'] && $qiniuconfig['qiniuyuming'] && $qiniuconfig['qiniukongjian'] && $qiniuquyu){
    require_once __DIR__ . '/Qiniu/Auth.php';
    require_once __DIR__ . '/Qiniu/Config.php';
    require_once __DIR__ . '/Qiniu/Etag.php';
    require_once __DIR__ . '/Qiniu/functions.php';
    require_once __DIR__ . '/Qiniu/Zone.php';
    require_once __DIR__ . '/Qiniu/Http/Client.php';
    require_once __DIR__ . '/Qiniu/Http/Error2.php';
    require_once __DIR__ . '/Qiniu/Http/Request.php';
    require_once __DIR__ . '/Qiniu/Http/Response.php';
    require_once __DIR__ . '/Qiniu/Processing/ImageUrlBuilder.php';
    require_once __DIR__ . '/Qiniu/Processing/Operation.php';
    require_once __DIR__ . '/Qiniu/Processing/PersistentFop.php';
    require_once __DIR__ . '/Qiniu/Storage/BucketManager.php';
    require_once __DIR__ . '/Qiniu/Storage/FormUploader.php';
    require_once __DIR__ . '/Qiniu/Storage/ResumeUploader.php';
    require_once __DIR__ . '/Qiniu/Storage/UploadManager.php';
    $qiniuconfig['auth'] = new Auth($qiniuconfig['qiniuak'], $qiniuconfig['qiniusk']);
    $qiniuconfig['upToken'] = $qiniuconfig['auth']->uploadToken($qiniuconfig['qiniukongjian']);
}
function qiniuupload($file)
{
    global $qiniuconfig;
    $ext = substr($file['name'],strrpos($file['name'],'.'));
    $name = str_replace(array(" ",'.'), array('',''), microtime()).rand(1,9999).$ext;
    $path = date('Y/m/d/H/',time()).$name;
    $uploadMgr = new UploadManager();
    list($ret, $err) = $uploadMgr->putFile($qiniuconfig['upToken'], $path, $file['tmp_name']);
    if ($err !== null) {
        exit('Qiniu ERROR:' . $err);
    } else {
        return $qiniuconfig['qiniuyuming'].'/'.$ret['key'];
    }
}
function qiniudelete($file)
{
    global $qiniuconfig;
    $bucketMgr = new BucketManager($qiniuconfig['auth']);
    $err = $bucketMgr->delete($qiniuconfig['qiniukongjian'], $file);
    if($err){
        // exit($err->message());
    }else{
        return true;
    }
}
function qiniudeleteimg($url){
    global $qiniuconfig;
    if(strripos($url,$qiniuconfig['qiniuyuming']) !== false){
        $file = (substr($url,stripos($url,'/',8)+1));
        qiniudelete($file);
    }
}