<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class block_xlwsq_down extends discuz_block{
	var $setting = array();
	function block_xlwsq_down(){
		$this->setting = array(
			'titlelength' => array(
				'title' =>  lang('plugin/xlwsq_down','blockclass_biaotiling'),
				'type' => 'text',
				'default' => 40
			),
			'infolength'	=> array(
				'title' => lang('plugin/xlwsq_down','blockclass_infoling'),
				'type' => 'text',
				'default' => 80
			),
			'param' => array(
				'title' => lang('plugin/xlwsq_down','blockclass_fangshi'),
				'type' => 'select',
				'value' => array(
					array('0', lang('plugin/xlwsq_down','blockclass_new')),
					array('1', lang('plugin/xlwsq_down','blockclass_top')),
					array('2', lang('plugin/xlwsq_down','blockclass_tuijian')),
					array('3', lang('plugin/xlwsq_down','blockclass_view')),
					array('4', lang('plugin/xlwsq_down','blockclass_down')),
				),
				'default' => '0'
			),
			'catid' => array(
				'title' => lang('plugin/xlwsq_down','blockclass_cate'),
				'type' => 'select',
				'value' => array()
			),
			'yuyanid' => array(
				'title' => lang('plugin/xlwsq_down','blockclass_diycate'),
				'type' => 'select',
				'value' => array()
			),
			'startrow' => array(
				'title' => lang('plugin/xlwsq_down','blockclass_qishihangshu'),
				'type' => 'text',
				'default' => 0
			),
		);
	}
	function name() {
		return  lang('plugin/xlwsq_down','blockclass_data');
	}
	function blockclass() {
		return array('sample', lang('plugin/xlwsq_down','blockclass_mokuai'));
	}
	function fields() {
		return array(
			'id' => array('name' => lang('plugin/xlwsq_down', 'blockclass_id'), 'formtype' => 'text', 'datatype' => 'int'),
			'title' => array('name' => lang('plugin/xlwsq_down','blockclass_title'), 'formtype' => 'title', 'datatype' => 'title'),
			'url' => array('name' => lang('plugin/xlwsq_down','blockclass_url'), 'formtype' => 'text', 'datatype' => 'string'),
			'pic' => array('name' => lang('plugin/xlwsq_down','blockclass_pic'), 'formtype' => 'pic', 'datatype' => 'pic'),
			'cate' => array('name' => lang('plugin/xlwsq_down','blockclass_cate'), 'formtype' => 'text', 'datatype' => 'string'),
			'sd1' => array('name' => lang('plugin/xlwsq_down','blockclass_sd1'), 'formtype' => 'text', 'datatype' => 'string'),
			'sd2' => array('name' => lang('plugin/xlwsq_down','blockclass_sd2'), 'formtype' => 'text', 'datatype' => 'string'),
			'sd3' => array('name' => lang('plugin/xlwsq_down','blockclass_sd3'), 'formtype' => 'text', 'datatype' => 'string'),
			'sd4' => array('name' => lang('plugin/xlwsq_down','blockclass_sd4'), 'formtype' => 'text', 'datatype' => 'string'),
			'sd5' => array('name' => lang('plugin/xlwsq_down','blockclass_sd5'), 'formtype' => 'text', 'datatype' => 'string'),
			'info' => array('name' => lang('plugin/xlwsq_down','blockclass_info'), 'formtype' => 'text', 'datatype' => 'string'),
			'view' => array('name' => lang('plugin/xlwsq_down','blockclass_view'), 'formtype' => 'text', 'datatype' => 'int'),
			'down' => array('name' => lang('plugin/xlwsq_down','blockclass_down'), 'formtype' => 'text', 'datatype' => 'int'),
			'dianpingshu' => array('name' => lang('plugin/xlwsq_down','blockclass_dianpingshu'), 'formtype' => 'text', 'datatype' => 'int'),
			'zongtipingjia' => array('name' => lang('plugin/xlwsq_down','blockclass_zongtipingjia'), 'formtype' => 'text', 'datatype' => 'int'),
			'pxing' => array('name' => lang('plugin/xlwsq_down','blockclass_pxing'), 'formtype' => 'text', 'datatype' => 'int'),
			'dateline' => array('name' => lang('plugin/xlwsq_down','blockclass_dateline'), 'formtype' => 'date', 'datatype' => 'date'),
		);
	}
	function getsetting() {
		global $_G;
		$settings = $this->setting;
		$yuyan = $_G['cache']['plugin']['xlwsq_down']['yuyan'];
	    $yuyanlist = explode ("\n", str_replace ("\r", "", $yuyan));
        $cates =DB::fetch_all("SELECT * FROM ".DB::table('plugin_xlwsq_down_cate')." WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
		if($settings['catid']) {
		   $settings['catid']['value'][] = array(0,lang('plugin/xlwsq_down','blockclass_quanbu'));
		   foreach($cates as $value) {
			  if($value['upid'] == 0) {
				 $settings['catid']['value'][] = array($value['id'], $value['subject']);
				 $cate_t = DB::fetch_all("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE upid = '$value[id]'");
				 foreach($cate_t as $subid) {
					$settings['catid']['value'][] = array($subid['id'],str_repeat('&nbsp;', 5).$subid['subject']);
				 }
			  }
		   }
	    }
		if($settings['yuyanid']) {
			$settings['yuyanid']['value'][] = array(0,lang('plugin/xlwsq_down','blockclass_quanbu'));
            foreach($yuyanlist as $value){
	           $arr=explode('=',$value);
			   $settings['yuyanid']['value'][] = array($arr[0],$arr[1]);
            }
		}
		return $settings;
	}
	function getdata($style, $parameter) {
		global $_G;
		$yuyan = $_G['cache']['plugin']['xlwsq_down']['yuyan'];
	    $yuyanlist = explode ("\n", str_replace ("\r", "", $yuyan));
		$returndata = array('html' => '', 'data' => '');
		$parameter = $this->cookparameter($parameter);
		$titlelength = isset($parameter['titlelength']) ? intval($parameter['titlelength']) : 40;
		$infolength = isset($parameter['infolength']) ? intval($parameter['infolength']) : 220;
		$startrow	 = isset($parameter['startrow']) ? intval($parameter['startrow']) : 0;
		$items		 = !empty($parameter['items']) ? intval($parameter['items']) : 6;
		$bannedids = !empty($parameter['bannedids']) ? explode(',', $parameter['bannedids']) : array();
		$sqlban = !empty($bannedids) ? ' AND id NOT IN ('.dimplode($bannedids).')' : '';
		if($parameter['catid']!=0){	
			$catid =  $parameter['catid'];
			  $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id='$catid'");
              if ($subids) {
                     $cid = "cate IN ($catid,$subids) AND";
                   } else {
                     $cid = "cate=$catid AND";
              }
		}
		if($parameter['yuyanid']!=0){	
			$yuyanid =  $parameter['yuyanid'];
			$wheres = "instr(concat(',',`yuyan`,','),',$yuyanid,') AND";
		}
		if($parameter['param']==1){
            $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE $cid $wheres top ='1' AND display!='0' $sqlban ORDER BY dateline DESC LIMIT $startrow, $items");
		}elseif($parameter['param']==2){
			$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE $cid $wheres tuijian ='1' AND display!='0' $sqlban ORDER BY dateline DESC LIMIT $startrow, $items");

		}elseif($parameter['param']==3){
			$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE $cid $wheres view >'0' AND display!='0' $sqlban ORDER BY view DESC LIMIT $startrow, $items");

		}elseif($parameter['param']==4){
			$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE $cid $wheres down >'0' AND  display!='0' $sqlban ORDER BY down DESC LIMIT $startrow, $items");

		}else{	
            $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE $cid $wheres display!='0' $sqlban ORDER BY dateline DESC LIMIT $startrow, $items");
		}
		$datalist = $list = array();
		while($data = DB::fetch($query)) {
            $zongtipingjia=round($data[pf0]/$data[pfa],1);
            $pxing=intval($zongtipingjia)*2;
			$cate = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_cate')." WHERE id = '$data[cate]'");
				   if($cate['upid']!=0){
				      $cate_t = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_cate')." WHERE id = '$cate[upid]'");
					  $data['cate'] = $cate_t['subject'] . " - " . $cate['subject'];
				   }else{
			          $data['cate'] = $cate['subject'];
		           }
			$list[] = array(
				'id' => $data['id'],
				'idtype' => 'id',
				'url' => 'plugin.php?id=xlwsq_down&mod=view&sid='.$data['id'],
			    'title' => cutstr($data['title'], $titlelength, ''),
				'pic' => $data['pic'] ? $data['pic'] : 'source/plugin/xlwsq_down/images/nopic.jpg',
				'fields' => array(
				    'info' => cutstr($data['info'], $infolength, ''),
				    'cate' => $data['cate'],
					'sd1' => $data['sd1'],
					'sd2' => $data['sd2'],
					'sd3' => $data['sd3'],
					'sd4' => $data['sd4'],
					'sd5' => $data['sd5'],
					'view' => $data['view'],
					'down' => $data['down'],
					'zongtipingjia' => $zongtipingjia,
					'pxing' => $pxing,
					'dianpingshu' => $data['dpcount'],
					'dateline' => $data['dateline'],
				)
			);
		}
		return array('html' => '', 'data' => $list);
	}
}
?>