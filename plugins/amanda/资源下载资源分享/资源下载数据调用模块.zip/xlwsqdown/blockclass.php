<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$blockclass = array(
	'name' => lang('plugin/xlwsq_down','blockclass_xlwsq_down'), 
);
?>