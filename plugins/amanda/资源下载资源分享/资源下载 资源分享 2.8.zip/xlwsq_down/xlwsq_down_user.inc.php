<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
$plyes=($_G['cache']['plugin']['xlwsq_down']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
$fabuset = unserialize($groups);
$mianshenhe = unserialize($mianshenhe);
$yonghupriceset = unserialize($yonghupriceset);
$diysd = parconfig($sd);
$yuyan = parconfig($yuyan);
$uptype = strtolower($uptype);
$uploaddx=$uploaddx*1024;
$navtitle = $title;
$chuliwidth = 1000;
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$p = $_GET['p'] ? $_GET['p'] : 'index';
!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
if ($p == 'mylist'||$p == 'index') {
    if ($_G['uid']) {
        $where=$pageadd="";
        if($_GET['key']){
          $key=stripsearchkey($_GET['key']);
	      $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	      $keync=urlencode($key);
	      $pageadd="&key=$keync";
        }
        $uid = intval($_G['uid']);
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where uid='$uid'");
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where uid='$uid' ORDER BY display ASC,dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $multir = "<div class='pages cl' style='margin:10px 0;'>" . multi($countr, 20, $pager, 'plugin.php?id=xlwsq_down:xlwsq_down_user&p='.$p. $pageadd) . "</div>";
	    $moneytype = $_G['setting']['extcredits'][$softpaytype]['title'];
        $paymoney = getuserprofile('extcredits'."$softpaytype");
    } else {
        showmessage(lang('plugin/xlwsq_down', 'youkewuquanxian') , '', array() , array('login' => true));
    }
} elseif ($p == 'adminalllist') {
    if (file_exists("source/plugin/xlwsq_down/qiniusdk/autoload.php") && $pingtaiset==1) {
      require_once 'qiniusdk/autoload.php';
    }
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $where=$pageadd="";
        if($_GET['key']){
          $key=stripsearchkey($_GET['key']);
	      $where=" where title like '%".addcslashes(addslashes($key), '%')."%'";
	      $keync=urlencode($key);
	      $pageadd="&key=$keync";
        }
	    $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item').$where);
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " $where ORDER BY display ASC,dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $multir = "<div class='pages cl' style='margin:10px 0;'>" . multi($countr, 20, $pager, 'plugin.php?id=xlwsq_down:xlwsq_down_user&p=adminalllist' . $pageadd) . "</div>";
    } else {
        showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), dreferer());
    }
    if (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_down_item') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_down', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_down_item') . " SET display='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_down', 'gengxinok') , dreferer());

	}elseif(submitcheck('applysubmtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_down_item')." SET tuijian='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_down', 'gengxinok'), dreferer());
	}elseif(submitcheck('applysubmqxtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_down_item')." SET tuijian='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_down', 'gengxinok'), dreferer());	
    } elseif (submitcheck('applysubmzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_down_item') . " SET top='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_down', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_down_item') . " SET top='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_down', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id ='$aid'LIMIT 0 , 1");
            if ($active["pic"] != false) {
                unlink($active["pic"]);
             }
	        $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_img')." WHERE sid = '$aid'");
	        while($delz = DB::fetch($query)){
		        if ($delz["img"]!=false){
				  if($qiniuconfig['upToken']){qiniudeleteimg($delz['img']);}
			      unlink($delz["img"]);
		        }
	        }
	        $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_down')." WHERE sid = '$aid'");
	        while($delz = DB::fetch($query)){
		        if ($delz["downurl"]!=false){
                  if($qiniuconfig['upToken']){qiniudeleteimg($delz['downurl']);}
			      unlink($delz["downurl"]);
		        }
	        }
           DB::query("DELETE a,b,c,d,e,f FROM ".DB::table('plugin_xlwsq_down_item')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_down_img')." AS b ON a.id = b.sid LEFT JOIN ".DB::table('plugin_xlwsq_down_down')." AS c ON a.id = c.sid LEFT JOIN ".DB::table('plugin_xlwsq_down_post')." AS d ON a.id = d.sid LEFT JOIN ".DB::table('plugin_xlwsq_down_reply')." AS e ON e.id = e.dpid LEFT JOIN ".DB::table('plugin_xlwsq_down_favorites')." AS f ON a.id = f.sid WHERE a.id = '$aid' ");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_down', 'shanchuok') , dreferer());
    }
}elseif($p=='adminpic'){
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
      if (file_exists("source/plugin/xlwsq_down/qiniusdk/autoload.php") && $pingtaiset==1) {
         require_once 'qiniusdk/autoload.php';
      }
        if ($_GET['action'] == 'daishen'){
			$ds = " WHERE display ='0'";
			$dss = " AND b.display ='0'";
			$pageadd="&action=daishen";
        }
        $countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_img').$ds);
		$pager = intval($_GET['page']);
		$pager = max($pager, 1);
		$starts = ($pager - 1) * 10;
		if($countr) {			
			$rs = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." a, ".DB::table('plugin_xlwsq_down_img')." b WHERE a.id = b.sid $dss ORDER BY b.dateline DESC LIMIT $starts,10");
			while ($rw=DB::fetch($rs)){
				$manylist[]=$rw;
			}
	        $manylist = dhtmlspecialchars($manylist);
		}
		$multir = "<div class='pages cl' style='margin:10px 0;'>".multi($countr, 10, $pager, "plugin.php?id=xlwsq_down:xlwsq_down_user&p=adminpic".$pageadd)."</div>";
     if(submitcheck('applysubmdel')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
		    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_img')." WHERE id ='$aid'LIMIT 0 , 1");
            if($qiniuconfig['upToken']){qiniudeleteimg($delz['img']);}
	        unlink($active["img"]);
			DB::delete('plugin_xlwsq_down_img',array('id'=> $aid));
			$nums++;
		}
            showmessage(lang('plugin/xlwsq_down', 'shanchuok'), dreferer());
     }elseif (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_down_img') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_down', 'gengxinok') , dreferer());
	 }
    }else{
		showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), dreferer());
	}
}elseif($p=='adminpinglun'){
if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        if ($_GET['action'] == 'daishen'){
			$ds = " WHERE display ='0'";
			$dss = " AND b.display ='0'";
			$pageadd="&action=daishen";
		}elseif ($_GET['action'] == 'yishen'){
			$ds = " WHERE display ='1'";
			$dss = " AND b.display ='1'";
			$pageadd="&action=yishen";
        }
		$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_post').$ds);
		$pager = intval($_GET['page']);
		$pager = max($pager, 1);
		$starts = ($pager - 1) * 20;
		if($countr) {
			$rs=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." a, ".DB::table('plugin_xlwsq_down_post')." b WHERE  a.id = b.sid $dss ORDER BY b.dateline DESC LIMIT $starts,20");
			while ($rw=DB::fetch($rs)){
		            $recount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_reply')." WHERE dpid = ".$rw['id']." AND display!='0'");
		            $rw['count'] = $recount; 
				$manylist[]=$rw;
			}
			    $manylist = dhtmlspecialchars($manylist);
		}
		$multir = "<div class='pages cl' style='margin-top:10px;'>".multi($countr, 20, $pager, "plugin.php?id=xlwsq_down:xlwsq_down_user&p=adminpinglun".$pageadd)."</div>";
	}else{
		   showmessage(lang('plugin/xlwsq_down', 'caozuocuowu'));
	}
	if(submitcheck('applysubmsh')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
        $aid = intval($aid);
        $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_post')." where id = '$aid'");
			DB::query("UPDATE ".DB::table('plugin_xlwsq_down_post')." SET display='1' WHERE id='$aid' LIMIT 1");
	    $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_post')." where sid='$pl[sid]' AND display!='0' ");
        $sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pf5) AS 'pf5' , sum(pf6) AS 'pf6' , sum(pf7) AS 'pf7' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe' ,sum(pff) AS 'pff' ,sum(pfg) AS 'pfg' ,sum(pfh) AS 'pfh'  FROM ".DB::table('plugin_xlwsq_down_post')." WHERE sid='$pl[sid]' AND display!='0' ";
					$result = DB::query($sql);
					$row = DB::fetch($result);  
						$pf0 = intval($row['pf0']);
						$pf1 = intval($row['pf1']);
						$pf2 = intval($row['pf2']);
						$pf3 = intval($row['pf3']);
						$pf4 = intval($row['pf4']);
						$pf5 = intval($row['pf5']);
						$pf6 = intval($row['pf6']);
						$pf7 = intval($row['pf7']);
						$pfa = intval($row['pfa']);
						$pfb = intval($row['pfb']);
						$pfc = intval($row['pfc']);
						$pfd = intval($row['pfd']);
						$pfe = intval($row['pfe']);
						$pff = intval($row['pff']);
						$pfg = intval($row['pfg']);
						$pfh = intval($row['pfh']);
              DB::update('plugin_xlwsq_down_item', array('pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pff' => $pff,'pfg' => $pfg,'pfh' => $pfh,'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'pf5' => $pf5,'pf6' => $pf6,'pf7' => $pf7,'dpcount' => $dpcount), "id='$pl[sid]'");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_down', 'gengxinok'), dreferer());	
	}elseif(submitcheck('applysubmdel')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $ssd) {
        $ssd = intval($ssd);
 		    $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_post')." where id = '$ssd'");
  		    $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." where id = '$pl[sid]'");
			DB::delete('plugin_xlwsq_down_post',array('id'=> $ssd));
			DB::delete('plugin_xlwsq_down_reply',array('dpid'=> $ssd));
			        $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_post')." where sid='$pl[sid]'"); 
					$sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pf5) AS 'pf5' , sum(pf6) AS 'pf6' , sum(pf7) AS 'pf7' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe' ,sum(pff) AS 'pff' ,sum(pfg) AS 'pfg' ,sum(pfh) AS 'pfh'  FROM ".DB::table('plugin_xlwsq_down_post')." WHERE sid='$pl[sid]'";
					$result = DB::query($sql);
					$row = DB::fetch($result);  
						$pf0 = intval($row['pf0']);
						$pf1 = intval($row['pf1']);
						$pf2 = intval($row['pf2']);
						$pf3 = intval($row['pf3']);
						$pf4 = intval($row['pf4']);
						$pf5 = intval($row['pf5']);
						$pf6 = intval($row['pf6']);
						$pf7 = intval($row['pf7']);
						$pfa = intval($row['pfa']);
						$pfb = intval($row['pfb']);
						$pfc = intval($row['pfc']);
						$pfd = intval($row['pfd']);
						$pfe = intval($row['pfe']);
						$pff = intval($row['pff']);
						$pfg = intval($row['pfg']);
						$pfh = intval($row['pfh']);
	        DB::update('plugin_xlwsq_down_item', array('pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'pf5' => $pf5,'pf6' => $pf6,'pf7' => $pf7,'pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pff' => $pff,'pfg' => $pfg,'pfh' => $pfh,'dpcount' => $dpcount),"id ='$pl[sid]'");
			$nums++;
		}
            showmessage(lang('plugin/xlwsq_down', 'shanchuok'), dreferer());
    }
}elseif($p=='adminxfjl'){	
    $where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    $keytype = intval($_GET['keytype']);
    if($key){
     if($keytype==1){
        $where=" WHERE buyer ='$key' ";
     }elseif($keytype==2){
        $where=" WHERE seller ='$key' ";
     }else{
        $where=" WHERE title ='$key' ";
	 }
	 $keync=urlencode($key);
	 $pageadd="&keytype=$keytype&key=$keync";
    }
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_record').$where);
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 30;
    if($counts) {
	  $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_record')." $where ORDER BY dateline DESC LIMIT $starts,30");
	  $sy = $sys = array();
	  while($sy = DB::fetch($query)){
		$sys[] = $sy;
	  }
    }
	$multis = "<div class='pages cl' style='margin:5px'>".multi($counts, 30, $pages, "plugin.php?id=xlwsq_down:xlwsq_down_user&p=".$p.$pageadd)."</div>";
}elseif($p=='adminpingfenjiangli'||$p=='adminxzjl'){	
    $where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    $keytype = intval($_GET['keytype']);
       if($key){
         if($keytype==1){
            $where=" WHERE author ='$key' ";
         }elseif($keytype==2){
            $where=" WHERE title ='$key' ";
         }elseif($keytype==3){
            $where=" WHERE downname ='$key' ";
	     }
	     $keync=urlencode($key);
	     $pageadd="&keytype=$keytype&key=$keync";
       }
	if($p=='adminpingfenjiangli'){
	   $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_pinglunjiangli').$where);
    }elseif($p=='adminxzjl'){
	   $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_xiazaijilu').$where);
    }
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 30;
    if($counts) {
	 if($p=='adminpingfenjiangli'){
	  $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_pinglunjiangli')." $where ORDER BY dateline DESC LIMIT $starts,30");
     }elseif($p=='adminxzjl'){
	  $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_xiazaijilu')." $where ORDER BY dateline DESC LIMIT $starts,30");
     }
	  $manylist = $manylists = array();
	  while($manylist = DB::fetch($query)){
		$manylists[] = $manylist;
	  }
    }
	$multis = "<div class='pages cl' style='margin:5px'>".multi($counts, 30, $pages, "plugin.php?id=xlwsq_down:xlwsq_down_user&p=".$p.$pageadd)."</div>";
} elseif ($p == 'add') {
    if (file_exists("source/plugin/xlwsq_down/qiniusdk/autoload.php") && $pingtaiset==1) {
         require_once 'qiniusdk/autoload.php';
    }
    $groups = unserialize($groups);
    if (!in_array($_G['groupid'], $groups)) {
        showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo') , '', array() , array('login' => true));
    } else {
    include_once 'source/plugin/xlwsq_down/class/upic.class.php';
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    $zhuantiquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_zhuanti') . "  ORDER BY diynum DESC,id ASC");
    while ($zhuanti = DB::fetch($zhuantiquery)) {
        $zhuantis[] = $zhuanti;
    }
    $grouplistquery = DB::query("SELECT * FROM " . DB::table('common_usergroup') . "  ORDER BY groupid ASC");
    while ($grouplist = DB::fetch($grouplistquery)) {
        $grouplists[] = $grouplist;
    }
        if (submitcheck('applysubmit')) {
            $title = dhtmlspecialchars($_GET['title']);
			$cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
            $yuyan =  dhtmlspecialchars(implode(',',$_GET["yuyan"]));
		    $pic = dhtmlspecialchars($_GET['pic']);
		    $video = daddslashes($_GET['video']);
		    $sd1 = dhtmlspecialchars($_GET['sd1']);
		    $sd2 = dhtmlspecialchars($_GET['sd2']);
		    $sd3 = dhtmlspecialchars($_GET['sd3']);
		    $sd4 = dhtmlspecialchars($_GET['sd4']);
		    $sd5 = dhtmlspecialchars($_GET['sd5']);
            $webname = dhtmlspecialchars($_GET['webname']);
            $url = dhtmlspecialchars($_GET['url']);
            $info = addslashes($_GET['info']);
	        $downname = dhtmlspecialchars($_GET['downname']);
        	$downurl = dhtmlspecialchars($_GET['downurl']);
	        $tiquma = dhtmlspecialchars($_GET['tiquma']);
        	$jieyamima = dhtmlspecialchars($_GET['jieyamima']);
			$price=intval($_GET['price']);
            $dpname = dhtmlspecialchars(merge_spaces($_GET['dpname']));
			$type = 0;
		    $biaoqian = dhtmlspecialchars($_GET['biaoqian']);
		    $tuijian=intval($_GET['tuijian']);
			$top=intval($_GET['top']);
            if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
                  $display =1; 
            }else{
				 $display =0; 
            }
		    $view=intval($_GET['view']);
		    $down=intval($_GET['down']);
			$diynum=intval($_GET['diynum']);
            $zhuanti =  dhtmlspecialchars(implode(',',$_GET["zhuanti"]));
            $downgroup =  dhtmlspecialchars(implode(',',$_GET["downgroup"]));
            if ($_FILES['file']['tmp_name']) {
				$imageinfo = getimagesize($_FILES['file']['tmp_name']);
				    if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_down', 'feifatupianleixing'));
				}
                $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                $arr = explode(".", $_FILES["file"]["name"]);
                $hz = $arr[count($arr) - 1];
                if (!in_array($hz, $filetype)) {
                    showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));
                }
                $filepath = "source/plugin/xlwsq_down/logo/" . date("Ymd") . "/";
                $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
                if (!file_exists($filepath)) {
                    mkdir($filepath);
                }
                if (@copy($_FILES['file']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath . $randname))) {
                    @unlink($_FILES['file']['tmp_name']);
                }
                $pic = "source/plugin/xlwsq_down/logo/".date("Ymd")."/".$randname."";
			    if ($imageinfo[0] > 250) {
					imageUpdateSize($pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/250));
				}
            }
            DB::insert('plugin_xlwsq_down_item', array(
                'id' => '',
                'uid' => $_G['uid'],
                'author' => $_G['username'],
                'title' => $title,
                'pic' => $pic,
                'cate' => $cate,
                'video' => $video,
                'sd1' => $sd1,
                'sd2' => $sd2,
                'sd3' => $sd3,
                'sd4' => $sd4,
                'sd5' => $sd5,
                'webname' => $webname,
                'url' => $url,
                'yuyan' => $yuyan,
                'info' => $info,
                'price' => $price,
                'dpname' => $dpname,
                'biaoqian' => $biaoqian,
                'top' => $top,
                'tuijian' => $tuijian,
                'view' => $view,
                'down' => $down,
                'display' => $display,
                'diynum' => $diynum,
                'zhuanti' => $zhuanti,
                'downgroup' => $downgroup,
                'dateline' => $_G['timestamp']
            ));
		    $sid = DB::insert_id();
            if($uploadset!=2|| $_G['groupid'] == "1" || in_array($_G['uid'], $admins)){
               if ($_FILES['file2']['tmp_name']) {
				 $type = 1;
			     $filesize = $_FILES['file2']['size'] <= $uploaddx ;   
			     $filetype = explode(",",$uptype);
			     $arr=explode(".", strtolower($_FILES["file2"]["name"]));
				 $upname = addslashes($arr[0]);
			     $hz=$arr[count($arr)-1];
			     if(!in_array($hz, $filetype)){
				   showmessage(lang('plugin/xlwsq_down', 'fujiangeshibuzhengque'));	
			     }
			     if($qiniuconfig['upToken']){
                	$downurl = qiniuupload($_FILES['file2']);
                 }else{
			        $filepath = "source/plugin/xlwsq_down/upload/".$sid. "/";
		            $randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			        if(!file_exists($filepath)){ mkdir($filepath); }
			          if($filesize){ 
			             if(@copy($_FILES['file2']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file2']['tmp_name'], $filepath.$randname))) {
					        @unlink($_FILES['file2']['tmp_name']);
				         }
			          }else{
				        showmessage(lang('plugin/xlwsq_down', 'chaochudaxiao'));	
			          }
		            $downurl = "source/plugin/xlwsq_down/upload/".$sid. "/".$randname."";
                    }
                 }
             }
             for ($i = 1; $i <= 10; $i++) {
               $pic = 'pic'.$i;
               if ($_FILES[$pic]['tmp_name']) {
				    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
				       if ($imageinfo[0] <= 0) {
                          showmessage(lang('plugin/xlwsq_down', 'feifatupianleixing'));
				       }
                    $picname = $_FILES[$pic]['name'];
                    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                    $arr = explode(".", $_FILES[$pic]["name"]);
                    $hz = $arr[count($arr) - 1];
                    if (!in_array($hz, $filetype)) {
                       showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));
                    }
                    if($qiniuconfig['upToken']){
                    	$$pic = qiniuupload($_FILES[$pic]);
                    }else{
                        $pics = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
				        $img_dir = "source/plugin/xlwsq_down/upimg/".$sid. "/";
                        if (!is_dir($img_dir)) {
                             mkdir($img_dir);
                        }
                        $$pic = $img_dir . $pics;
                        if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
                               @unlink($_FILES[$pic]['tmp_name']);
                        }
			            if ($imageinfo[0] > $chuliwidth) {
							imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$chuliwidth));
						}
                    }
                    DB::insert('plugin_xlwsq_down_img', array('id' => '','sid' => $sid,'img' => $$pic,'display' => 1,'dateline' => $_G['timestamp']));
               }elseif($_GET[$pic]!=''){
		            DB::insert('plugin_xlwsq_down_img', array('id' => '','sid' => $sid,'img' =>addslashes($_GET[$pic]),'display' => 1,'dateline' => $_G['timestamp']));
		       }
             }
			 if($downurl!=""){
				 $downname =  $downname ? $downname : $upname;
			     DB::insert('plugin_xlwsq_down_down', array('id' => '','sid' => $sid,'downname' => $downname,'downurl' => $downurl,'jieyamima' => $jieyamima,'tiquma' => $tiquma,'type' => $type,'dateline' => $_G['timestamp']));
             }
             if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
                showmessage(lang('plugin/xlwsq_down', 'fabuchenggong') , 'plugin.php?id=xlwsq_down:xlwsq_down_user&p=index', array() , array('alert' => 'right'));
             } else {
                for ($i = 0; $i < count($admins); $i++) {
                    $message = '<a href="plugin.php?id=xlwsq_down&#58;xlwsq_down_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_down', 'yonghufabuxinxinxi') . '</a>';
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                }
                showmessage(lang('plugin/xlwsq_down', 'fabudengdaishenhe') , 'plugin.php?id=xlwsq_down:xlwsq_down_user&p=index', array() , array('alert' => 'right'));
            }
        }
    }
} elseif ($p == 'edit') {
    include_once 'source/plugin/xlwsq_down/class/upic.class.php';
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id='$id'");
    $uid = intval($active['uid']);
    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_down', 'caozuocuowu') , '', array() , array('login' => true));
    }
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    $zhuantiquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_zhuanti') . "  ORDER BY diynum DESC,id ASC");
    while ($zhuanti = DB::fetch($zhuantiquery)) {
        $zhuantis[] = $zhuanti;
    }
    $grouplistquery = DB::query("SELECT * FROM " . DB::table('common_usergroup') . "  ORDER BY groupid ASC");
    while ($grouplist = DB::fetch($grouplistquery)) {
        $grouplists[] = $grouplist;
    }
    $yuyanarray = change($active['yuyan']);
    $zhuantiarray = change($active['zhuanti']);
    $grouplistarray = change($active['downgroup']);
    if (submitcheck('applysubmit')) {
        $title = dhtmlspecialchars($_GET['title']);
        $pic = dhtmlspecialchars($_GET['pic']);
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
		$sd1 = dhtmlspecialchars($_GET["sd1"]);
		$sd2 = dhtmlspecialchars($_GET["sd2"]);
		$sd3 = dhtmlspecialchars($_GET["sd3"]);
		$sd4 = dhtmlspecialchars($_GET["sd4"]);
		$sd5 = dhtmlspecialchars($_GET["sd5"]);
        $webname = dhtmlspecialchars($_GET['webname']);
        $url = dhtmlspecialchars($_GET['url']);
        $yuyan =  dhtmlspecialchars(implode(',',$_GET["yuyan"]));
		$video = daddslashes($_GET["video"]);
        $info = daddslashes($_GET['info']);
		$price=intval($_GET['price']);
        $dpname = dhtmlspecialchars(merge_spaces($_GET['dpname']));
        $biaoqian = dhtmlspecialchars($_GET['biaoqian']);
        $top = intval($_GET['top']);
        $tuijian = intval($_GET['tuijian']);
        if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
            $display = 1;
        } else {
            $display = 0;
        }
	    $view=intval($_GET['view']);
	    $down=intval($_GET['down']);
        $diynum = intval($_GET['diynum']);
        if ($_G['groupid']=="1" ||in_array($_G['uid'], $admins)||$yonghudownset=="1"){
            $downgroup =  dhtmlspecialchars(implode(',',$_GET["downgroup"]));
        } else {
            $downgroup =  dhtmlspecialchars($_GET["downgroup"]);
        }
        if ($_G['groupid']=="1" ||in_array($_G['uid'], $admins)){
            $zhuanti =  dhtmlspecialchars(implode(',',$_GET["zhuanti"]));
        } else {
            $zhuanti =  dhtmlspecialchars($_GET["zhuanti"]);
        }
            if ($_FILES['file']['tmp_name']) {
				$imageinfo = getimagesize($_FILES['file']['tmp_name']);
				    if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_down', 'feifatupianleixing'));
				}
                if ($active["pic"] != false) {
                  unlink($active["pic"]);
                }
                $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                $arr = explode(".", $_FILES["file"]["name"]);
                $hz = $arr[count($arr) - 1];
                if (!in_array($hz, $filetype)) {
                    showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));
                }
                $filepath = "source/plugin/xlwsq_down/logo/" . date("Ymd") . "/";
                $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
                if (!file_exists($filepath)) {
                    mkdir($filepath);
                }
                if (@copy($_FILES['file']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath . $randname))) {
                        @unlink($_FILES['file']['tmp_name']);
                }
                $pic = "source/plugin/xlwsq_down/logo/" . date("Ymd") . "/" . $randname . "";
			    if ($imageinfo[0] > 250) {
					imageUpdateSize($pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/250));
				}
            }
        DB::update('plugin_xlwsq_down_item', array(
            'title' => $title,
            'pic' => $pic,
            'cate' => $cate,
            'sd1' => $sd1,
            'sd2' => $sd2,
            'sd3' => $sd3,
            'sd4' => $sd4,
            'sd5' => $sd5,
            'webname' => $webname,
            'url' => $url,
            'yuyan' => $yuyan,
            'video' => $video,
            'info' => $info,
            'price' => $price,
            'dpname' => $dpname,
            'biaoqian' => $biaoqian,
            'top' => $top,
            'tuijian' => $tuijian,
            'view' => $view,
            'down' => $down,
            'display' => $display,
            'diynum' => $diynum,
            'downgroup' => $downgroup,
            'zhuanti' => $zhuanti
        ) , "id='$id'");
        if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
		    showmessage(lang('plugin/xlwsq_down', 'gengxinok') , dreferer());
        } else {
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_down&#58;xlwsq_down_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_down', 'yonghufabuxinxinxi') . '</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
            showmessage(lang('plugin/xlwsq_down', 'fabudengdaishenhe') , dreferer());
        }
    }
} elseif ($p == 'favorites') {
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_favorites') . " WHERE uid='$uid'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 20;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_favorites') . " WHERE $where uid = '$uid' ORDER BY dateline DESC LIMIT $starts,20");
        while ($sc = DB::fetch($query)) {
            $scs[] = $sc;
        }
    }
    $multis = "<div class='pages cl'>" . multi($counts, 20, $pages, "plugin.php?id=xlwsq_down:xlwsq_down_user" . "&p=$p" . $pageadd) . "</div>";
} elseif ($p == 'favoritesdel') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if ($_GET['formhash'] == FORMHASH) {
        DB::query("DELETE FROM " . DB::table('plugin_xlwsq_down_favorites') . " WHERE id = '$id' and uid = '$uid'");
        showmessage(lang('plugin/xlwsq_down', 'shanchuok') , dreferer());
    }
} elseif ($p == 'addpic') {
    if (file_exists("source/plugin/xlwsq_down/qiniusdk/autoload.php") && $pingtaiset==1) {
       require_once 'qiniusdk/autoload.php';
    }
    include_once 'source/plugin/xlwsq_down/class/upic.class.php';
    $sid = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id='$sid'");
    $uid = intval($active['uid']);
    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_down', 'caozuocuowu') , '', array() , array('login' => true));
    }
	$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_img'). " WHERE sid='$sid' AND display='1' ");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
	if($countr) {
	   $picquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_img')." WHERE sid = '$sid' AND display='1' ORDER BY  dateline DESC LIMIT $starts,20");
	   while($piclist = DB::fetch($picquery)){
		$piclists[] = $piclist;
	   }
    	$piclists = dhtmlspecialchars($piclists);
	}
	$multir = "<div class='pages cl' style='margin-top:10px;'>".multi($countr, 20, $pages,'plugin.php?id=xlwsq_down:xlwsq_down_user&p=addpic&sid='.$sid.''.$pageadd)."</div>";
    if (submitcheck('addpic')) {
        for ($i = 1; $i <= 10; $i++) {
           $pic = 'pic'.$i;
           if ($_FILES[$pic]['tmp_name']) {
				    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
				       if ($imageinfo[0] <= 0) {
                          showmessage(lang('plugin/xlwsq_down', 'feifatupianleixing'));
				       }
                    $picname = $_FILES[$pic]['name'];
                    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                    $arr = explode(".", $_FILES[$pic]["name"]);
                    $hz = $arr[count($arr) - 1];
                    if (!in_array($hz, $filetype)) {
                       showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));
                    }
                    if($qiniuconfig['upToken']){
                       $$pic = qiniuupload($_FILES[$pic]);
                    }else{
                       $pics = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
				       $img_dir = "source/plugin/xlwsq_down/upimg/".$sid. "/";
                       if (!is_dir($img_dir)) {
                          mkdir($img_dir);
                       }
                       $$pic = $img_dir . $pics;
                       if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
                         @unlink($_FILES[$pic]['tmp_name']);
                       }
                       $imageinfo = getimagesize($$pic);
			           if ($imageinfo[0] > $chuliwidth) {
					       imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$chuliwidth));
				       }
                    }
                    DB::insert('plugin_xlwsq_down_img', array('id' => '','sid' => $sid,'img' => $$pic,'display' => 1,'dateline' => $_G['timestamp']));
           }elseif($_GET[$pic]!=''){
		            DB::insert('plugin_xlwsq_down_img', array('id' => '','sid' => $sid,'img' =>addslashes($_GET[$pic]),'display' => 1,'dateline' => $_G['timestamp']));
		   }
        }
        showmessage(lang('plugin/xlwsq_down', 'gengxinok') , dreferer());
    }
    if (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
	        $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_img')." WHERE id = '$aid'");
	        while($delz = DB::fetch($query)){
		        if ($delz["img"]!=false){
                  if($qiniuconfig['upToken']){qiniudeleteimg($delz['img']);}
			      unlink($delz["img"]);
		        }
	        }
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_down_img') . " WHERE id = '$aid' AND sid = '$sid'");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_down', 'shanchuok') , dreferer());
    }
} elseif ($p == 'adddown') {
    if (file_exists("source/plugin/xlwsq_down/qiniusdk/autoload.php") && $pingtaiset==1) {
        require_once 'qiniusdk/autoload.php';
    }
    $sid = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id='$sid'");
	$downsql = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_down')." WHERE sid='$sid' ORDER BY diynum ASC,id DESC");
	while($down = DB::fetch($downsql)){
		$downs[] = $down;
	}
    $downs = dhtmlspecialchars($downs);
    $uid = intval($active['uid']);
    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_down', 'caozuocuowu') , '', array() , array('login' => true));
    }
    if (submitcheck('adddownsubmit')) {
     for ($i = 1; $i <= 10; $i++) {
         $pic = 'pic'.$i;
         $diynum = 'diynum'.$i;
	     $downname = 'downname'.$i;
	     $downurl = 'downurl'.$i;
	     $downtiquma = 'downtiquma'.$i;
	     $downjieyamima = 'downjieyamima'.$i;
          if ($_FILES[$downurl]['tmp_name']) {
            $downurlname = $_FILES[$downurl]['name'];
			$filesize = $_FILES[$downurl]['size'] <= $uploaddx ;   
			$filetype = explode(",",$uptype);
			$arr=explode(".", strtolower($_FILES[$downurl]["name"]));
			$downname =  addslashes($_GET[$downname]) ? addslashes($_GET[$downname]) : addslashes($arr[0]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
				showmessage(lang('plugin/xlwsq_down', 'fujiangeshibuzhengque'));	
			}
			if($qiniuconfig['upToken']){
				$$downurl = qiniuupload($_FILES[$downurl]);
			}else{
			   $filepath = "source/plugin/xlwsq_down/upload/".$sid. "/";
		       $randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
		       $$downurl =$filepath.$randname;
			   if(!file_exists($filepath)){ mkdir($filepath); }
			   if($filesize){ 
			      if(@copy($_FILES[$downurl]['tmp_name'], $$downurl) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES[$downurl]['tmp_name'], $$downurl))) {
					@unlink($_FILES[$downurl]['tmp_name']);
				  }
			   }else{
				 showmessage(lang('plugin/xlwsq_down', 'chaochudaxiao'));	
			   }
			}
		    DB::insert('plugin_xlwsq_down_down', array('id' => '','diynum' => intval($_GET[$diynum]),'sid' => $sid,'downname' => $downname,'downurl' => $$downurl,'type' => 1,'tiquma' => addslashes($_GET[$downtiquma]),'jieyamima' => addslashes($_GET[$downjieyamima]),'dateline' => $_G['timestamp']));  
	      }elseif($_GET[$downurl]!=''){
            DB::insert('plugin_xlwsq_down_down', array('id' => '','diynum' => intval($_GET[$diynum]),'sid' => $sid,'downname' => addslashes($_GET[$downname]),'downurl' => addslashes($_GET[$downurl]),'type' => 0,'tiquma' => addslashes($_GET[$downtiquma]),'jieyamima' => addslashes($_GET[$downjieyamima]),'dateline' => $_G['timestamp']));
          }
     }
     showmessage(lang('plugin/xlwsq_down', 'tijiaochenggong') , dreferer());
    }elseif(submitcheck('editdownsubmit')){	
		foreach($_GET['downurl'] as $id => $val) {
				DB::update('plugin_xlwsq_down_down', array('diynum' => intval($_GET['diynum'][$id]),'downname' => addslashes($_GET['downname'][$id]),'downurl' => addslashes($_GET['downurl'][$id]),'tiquma' => addslashes($_GET['downtiquma'][$id]),'jieyamima' => addslashes($_GET['downjieyamima'][$id])), "id='$id'");
		}
	    showmessage(lang('plugin/xlwsq_down', 'gengxinok') , dreferer());
	}elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
	        $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_down')." WHERE id = '$aid'");
	        while($delz = DB::fetch($query)){
		        if ($delz["downurl"]!=false){
				  if($qiniuconfig['upToken']){qiniudeleteimg($delz['downurl']);}
			      unlink($delz["downurl"]);
		        }
	        }
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_down_down') . " WHERE id = '$aid' AND sid = '$sid'");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_down', 'shanchuok') , dreferer());
     }
} elseif ($p == 'massup') {
    $uid = intval($_G['uid']);
    $sid = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id='$sid'");
	!$active ? showmessage(lang('plugin/xlwsq_down', 'error'),"plugin.php?id=xlwsq_down") : '';
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$active['uid']==$uid) {
      $arr = explode(',', $uptype);
	  $upleixing='';
       foreach ($arr as $hz) {
         $upleixing .= '*.' . $hz . ';';
       }
	}else{
        showmessage(lang('plugin/xlwsq_down', 'caozuocuowu') , '', array() , array('login' => true));
    }
} elseif ($p == 'shenheok') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_down_item') . " SET display='1' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_down', 'shenheok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_down', 'caozuocuowu'));
    }
} elseif ($p == 'qxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_down_item') . " SET display='0' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_down', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_down', 'caozuocuowu'));
    }
} elseif ($p == 'del') {
    if (file_exists("source/plugin/xlwsq_down/qiniusdk/autoload.php") && $pingtaiset==1) {
       require_once 'qiniusdk/autoload.php';
    }
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id ='$id' AND uid='$uid'");
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$active['uid']==$uid) {
        if ($_GET['formhash'] == FORMHASH) {
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id ='$id'");
			if ($active["pic"] != false) {
                  unlink($active["pic"]);
            }
	       $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_img')." WHERE sid = '$id'");
	       while($delz = DB::fetch($query)){
		     if ($delz["img"]!=false){
			   if($qiniuconfig['upToken']){qiniudeleteimg($delz['img']);}
			   unlink($delz["img"]);
	         }
	       }
	       $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_down')." WHERE sid = '$id'");
	       while($delz = DB::fetch($query)){
		     if ($delz["downurl"]!=false){
               if($qiniuconfig['upToken']){qiniudeleteimg($delz['downurl']);}
			   unlink($delz["downurl"]);
	         }
	       }
           DB::query("DELETE a,b,c,d,e,f FROM ".DB::table('plugin_xlwsq_down_item')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_down_img')." AS b ON a.id = b.sid LEFT JOIN ".DB::table('plugin_xlwsq_down_down')." AS c ON a.id = c.sid LEFT JOIN ".DB::table('plugin_xlwsq_down_post')." AS d ON a.id = d.sid LEFT JOIN ".DB::table('plugin_xlwsq_down_reply')." AS e ON e.id = e.dpid LEFT JOIN ".DB::table('plugin_xlwsq_down_favorites')." AS f ON a.id = f.sid WHERE a.id = '$id' ");
		   showmessage(lang('plugin/xlwsq_down', 'shanchuok') , dreferer());
        }
    }
}elseif($p=='xfjl'){	
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	$uid = intval($_G['uid']);
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_record')." WHERE $where buyuid='$uid'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
        $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_record')." WHERE $where buyuid='$uid' ORDER BY dateline DESC LIMIT $starts,20");
	    while($xiaofei = DB::fetch($query)){
		$xiaofeis[] = $xiaofei;
	  }
    }
	$multis = "<div class='pages cl'>".multi($counts, 20, $pages, 'plugin.php?id=xlwsq_down:xlwsq_down_user&p='.$p.$pageadd)."</div>";
}elseif($p=='syjl'){	
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	$uid = intval($_G['uid']);
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_record')." WHERE $where selluid='$uid' AND sellincome >'0' ");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
	    $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_record')." WHERE $where selluid='$uid' AND sellincome >'0'  ORDER BY dateline DESC LIMIT $starts,20");
	    $sy = $sys = array();
	    while($sy = DB::fetch($query)){
		    $sys[] = $sy;
	    }
    }
	$multis = "<div class='pages cl'>".multi($counts, 20, $pages, 'plugin.php?id=xlwsq_down:xlwsq_down_user&p='.$p.$pageadd)."</div>";
}elseif($p=='xzjl'){	
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	$uid = intval($_G['uid']);
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_xiazaijilu')." WHERE $where uid='$uid'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
	    $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_xiazaijilu')." WHERE $where uid='$uid' ORDER BY dateline DESC LIMIT $starts,20");
	    $xzjl = $xzjls = array();
	    while($xzjl = DB::fetch($query)){
		    $xzjls[] = $xzjl;
	    }
    }
	$multis = "<div class='pages cl'>".multi($counts, 20, $pages, 'plugin.php?id=xlwsq_down:xlwsq_down_user&p='.$p.$pageadd)."</div>";
}elseif($p=='zhuantiadd'){	
    if ($zhuantiset=='0') {
        showmessage(lang('plugin/xlwsq_down', 'zhuantiweikaiqi') , dreferer());
    }
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	    if(submitcheck('addzhuantisubmit')){
            $title = dhtmlspecialchars($_GET['title']);
            $pic = dhtmlspecialchars($_GET['pic']);
            $info = dhtmlspecialchars($_GET['info']);
            $diynum = intval($_GET['diynum']);
			$display = intval($_GET['display']);
			if($_FILES['file']['error']==0){
				$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
				$arr=explode(".", $_FILES["file"]["name"]);
				$hz=$arr[count($arr)-1];
				if(!in_array($hz, $filetype)){
					showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));	
				}
				$filepath = "source/plugin/xlwsq_down/zhuanti/".date("Ymd")."/";
				$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
				if(!file_exists($filepath)){ mkdir($filepath); }			
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
			   	    @unlink($_FILES['file']['tmp_name']);
				}
				$pic = "source/plugin/xlwsq_down/zhuanti/".date("Ymd")."/".$randname."";
			}
		    DB::insert('plugin_xlwsq_down_zhuanti',array('id' => '','title' => $title,'pic' => $pic,'info' => $info, 'display' => $display,'diynum' => $diynum));
		    showmessage(lang('plugin/xlwsq_down', 'fabuchenggong'), "plugin.php?id=xlwsq_down:xlwsq_down_user&p=zhuanti", array(), array('alert' => 'right'));
	    }
    }else{
		showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), '', array(), array('alert' => 'right'));
    }
}elseif($p=='zhuantiedit'){	
    if ($zhuantiset=='0') {
        showmessage(lang('plugin/xlwsq_down', 'zhuantiweikaiqi') , dreferer());
    }
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id=intval($_GET['bid']);
	    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_zhuanti')." WHERE id ='$id'");
	    if(submitcheck('editzhuantisubmit')){
            $title = dhtmlspecialchars($_GET['title']);
            $pic = dhtmlspecialchars($_GET['pic']);
            $info = dhtmlspecialchars($_GET['info']);
            $diynum = addslashes($_GET['diynum']);
			$display = intval($_GET['display']);
			if($_FILES['file']['error']==0){
                if ($active["pic"]!=false){
	                unlink($active["pic"]);
	            }
				$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
				$arr=explode(".", $_FILES["file"]["name"]);
				$hz=$arr[count($arr)-1];
				if(!in_array($hz, $filetype)){
					showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));	
				}
				$filepath = "source/plugin/xlwsq_down/zhuanti/".date("Ymd")."/";
				$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
				if(!file_exists($filepath)){ mkdir($filepath); }
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					 @unlink($_FILES['file']['tmp_name']);
				}
				$pic = "source/plugin/xlwsq_down/zhuanti/".date("Ymd")."/".$randname."";
			}
		    DB::update('plugin_xlwsq_down_zhuanti',array('title' => $title,'pic' => $pic,'info' => $info,'display' => $display,'diynum' => $diynum),"id='$id'");
		    showmessage(lang('plugin/xlwsq_down', 'fabuchenggong'), dreferer());
	    }
    }else{
	    showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), '', array(), array('alert' => 'right'));
    }
}elseif($p=='zhuanti'){	
    if ($zhuantiset=='0') {
        showmessage(lang('plugin/xlwsq_down', 'zhuantiweikaiqi') , dreferer());
    }
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $where=$pageadd="";
        if($_GET['key']){
             $key=stripsearchkey($_GET['key']);
	         $where=" where title like '%".addcslashes(addslashes($key), '%')."%'";
	         $keync=urlencode($key);
	         $pageadd="&key=$keync";
        }
	    $count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_zhuanti').$where);
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 10;
        if ($count) {
            $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_zhuanti') . " $where ORDER BY diynum DESC,id DESC LIMIT $starts,10");
            while ($zhuanti = DB::fetch($query)) {
                $zhuantis[] = $zhuanti;
            }
        }
        $multipage = "<div class='pages cl' style='margin:10px 0;'>" . multi($count, 10, $pager, "plugin.php?id=xlwsq_down:xlwsq_down_user&p=zhuanti". $pageadd) . "</div>";
    }else{
		showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), '', array(), array('alert' => 'right'));
    }
}elseif ($p=='zhuantidel'){
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $id=intval($_GET['bid']);
    if($_GET['formhash'] == FORMHASH) {
			$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_zhuanti')." WHERE id ='$id'");
			if ($active["pic"]!=false){
		    unlink($active["pic"]);
	        }
	       DB::query("DELETE FROM ".DB::table('plugin_xlwsq_down_zhuanti')." WHERE id = '$id'");
           showmessage(lang('plugin/xlwsq_down', 'shanchuok'), 'plugin.php?id=xlwsq_down:xlwsq_down_user&p=zhuanti', array(), array('alert' => 'right'));
    }
  }else{
       showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), '', array(), array('alert' => 'right'));
  }
//banner
}elseif($p=='banneradd'){	
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	    if(submitcheck('addbannersubmit')){
            $title = dhtmlspecialchars($_GET['title']);
            $pic = dhtmlspecialchars($_GET['pic']);
            $url = dhtmlspecialchars($_GET['url']);
            $display = intval($_GET['display']);
            $diynum = intval($_GET['diynum']);
            $timestamp = $_G['timestamp'];
			if($_FILES['file']['error']==0){
				$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
				$arr=explode(".", $_FILES["file"]["name"]);
				$hz=$arr[count($arr)-1];
				if(!in_array($hz, $filetype)){
				    showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));	
				}
				$filepath = "source/plugin/xlwsq_down/banner/".date("Ymd")."/";
				$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
				if(!file_exists($filepath)){ mkdir($filepath); }			
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					 @unlink($_FILES['file']['tmp_name']);
				}
				$pic = "source/plugin/xlwsq_down/banner/".date("Ymd")."/".$randname."";
			}
	   	    DB::insert('plugin_xlwsq_down_banner',array('id' => '','title' => $title,'pic' => $pic,'url' => $url, 'diynum' => $diynum,'display' => $display, 'dateline' => $timestamp));
		    showmessage(lang('plugin/xlwsq_down', 'fabuchenggong'), "plugin.php?id=xlwsq_down:xlwsq_down_user&p=banner", array(), array('alert' => 'right'));
	    }
    }else{
		showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), '', array(), array('alert' => 'right'));
    }
}elseif($p=='banneredit'){	
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id=intval($_GET['bid']);
	    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_banner')." WHERE id ='$id'");
	    if(submitcheck('editbannersubmit')){
            $title = dhtmlspecialchars($_GET['title']);
            $pic = dhtmlspecialchars($_GET['pic']);
            $url = dhtmlspecialchars($_GET['url']);
            $display = intval($_GET['display']);
            $diynum = intval($_GET['diynum']);
		    if($_FILES['file']['error']==0){
                if ($active["pic"]!=false){
	                unlink($active["pic"]);
	            }
	            $filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
		        $arr=explode(".", $_FILES["file"]["name"]);
	   	        $hz=$arr[count($arr)-1];
		        if(!in_array($hz, $filetype)){
		    	    showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));	
		        }
		        $filepath = "source/plugin/xlwsq_down/banner/".date("Ymd")."/";
		        $randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
		        if(!file_exists($filepath)){ mkdir($filepath); }
		        if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'],   $filepath.$randname))) {
		            @unlink($_FILES['file']['tmp_name']);
		        }
		        $pic = "source/plugin/xlwsq_down/banner/".date("Ymd")."/".$randname."";
		    }
            DB::update('plugin_xlwsq_down_banner',array('title' => $title,'pic' => $pic,'diynum' => $diynum,'display' => $display,'url' => $url),"id='$id'");
	        showmessage(lang('plugin/xlwsq_down', 'fabuchenggong'), dreferer());
	    }
    }else{
	    showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), '', array(), array('alert' => 'right'));
    }
}elseif($p=='banner'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $perpage = 10;
    $page = max(1, intval($_GET['page']));
    $start_limit = ($page - 1) * $perpage;
    $count = DB::result_first("SELECT count(*) FROM ".DB::table('plugin_xlwsq_down_banner'));
    $multipage = multi($count, $perpage, $page, "plugin.php?id=xlwsq_down:xlwsq_down_user&p=banner");
    $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_banner'). " ORDER BY id DESC LIMIT $start_limit, $perpage");
	$banner = $banners = array();
	while($banner = DB::fetch($query)){
		$banner['dateline'] = gmdate('Y-m-d', $banner['dateline'] + $_G['setting']['timeoffset'] * 3600); 
		$banners[] = $banner;
	}
    $banners = dhtmlspecialchars($banners);
   }else{
		showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), '', array(), array('alert' => 'right'));
   }
}elseif ($p=='bannerdel'){
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $id=intval($_GET['bid']);
    if($_GET['formhash'] == FORMHASH) {
			$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_banner')." WHERE id ='$id'");
			if ($active["pic"]!=false){
		    unlink($active["pic"]);
	        }
	       DB::query("DELETE FROM ".DB::table('plugin_xlwsq_down_banner')." WHERE id = '$id'");
           showmessage(lang('plugin/xlwsq_down', 'shanchuok'), 'plugin.php?id=xlwsq_down:xlwsq_down_user&p=banner', array(), array('alert' => 'right'));
    }
  }else{
       showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), '', array(), array('alert' => 'right'));
  }

}
include (template("xlwsq_down:xlwsq_down_user"));
function change($str){
	$return = array();
	$array = explode(",",$str);
	foreach ($array as $v){
		$t = explode(" ",$v);
		$return[$t[0]] = $t[0];
	}
	return $return;
}
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
function merge_spaces($string){
    return preg_replace("/\s(?=\s)/","\\1",$string);
}
//From: d'.'is'.'m.ta'.'obao.com
?>