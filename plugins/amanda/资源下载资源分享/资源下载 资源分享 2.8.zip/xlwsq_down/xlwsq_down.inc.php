<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
global $_G;
if (!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plyes=($_G['cache']['plugin']['xlwsq_down']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
$fabuset = unserialize($groups);
$free = unserialize($free);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$diysd = parconfig($sd);
$menuyuyan = parconfig($yuyan);
$ztinfowidth = intval($ztinfowidth);
$xingxingpingjia = parconfig($xingxingpingjia);
$payset=$payset/100;
$chuliwidth = 1000;
$navtitle = $title;
if (!$_GET['mod']) {
    @require_once DISCUZ_ROOT.'source/plugin/xlwsq_down/function/function_core.php';
    $where=$pageadd="";
    if($_GET['key']){
      $key=stripsearchkey($_GET['key']);
	  $where="title like '%".addcslashes(addslashes($key), '%')."%' AND ";
	  $keync=urlencode($key);
	  $pageadd="&key=$keync";
    }elseif($_GET['biaoqian']){
      $biaoqian=stripsearchkey($_GET['biaoqian']);
	  $where="biaoqian like '%".addcslashes(addslashes($biaoqian), '%')."%' AND ";
	  $biaoqiankeync=urlencode($biaoqian);
	  $pageadd="&biaoqian=$biaoqiankeync";
      $biaoqiannav=$biaoqian. " - ";
    }elseif($_GET['uid']){
	  $uid=intval($_GET['uid']);
	  $where="uid='$uid' AND";
	  $keync=urlencode($uid);
	  $pageadd="&uid=$keync";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
        $av_d[$cate_id] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$cate_id'");
    $sd = intval($_GET['b']);
    if ($sd) {
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
        $av_d[$sd] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$sd'");
    $yuyan = intval($_GET['yy']);
    if ($yuyan){
		$syy[] = "yuyan = '$yuyan'";
		$pageaddyy="&yy=$yuyan";
		$yy_hover[$yuyan] = ' class="cur-on"'; 
    }
	if ($syy){ $yy ="instr(concat(',',`yuyan`,','),',$yuyan,') AND";}
    if ($_GET['paixu']=='tj') {
		$px="tuijian = '1' AND display='1' ORDER BY diynum DESC,dateline DESC"; $pageadd="&paixu=tj";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where $wb $wc $yy tuijian = '1' AND display='1'");
	}elseif ($_GET['paixu']=='free') {
		$px="price = '0' AND display='1' ORDER BY diynum DESC,dateline DESC"; $pageadd="&paixu=free";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where $wb $wc $yy price = '0' AND display='1'");
	}elseif ($_GET['paixu']=='view') {
		$px="view > '0' AND display='1' ORDER BY view DESC"; $pageadd="&paixu=view";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where $wb $wc $yy view > '0' AND display='1'");
	}elseif ($_GET['paixu']=='down') {
		$px="down > '0' AND display='1' ORDER BY down DESC"; $pageadd="&paixu=down";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where $wb $wc $yy down > '0' AND display='1'");
	}elseif ($_GET['paixu']=='pay') {
		$px="price > '0' AND display='1' ORDER BY diynum DESC,dateline DESC"; $pageadd="&paixu=pay";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where $wb $wc $yy price > '0' AND display='1'");
	}else{
		$px="display='1' ORDER BY top DESC,diynum DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where $wb $wc $yy display='1'");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where $wb $wc $yy $px LIMIT $starts,$eacha");
        while ($mythread = DB::fetch($query)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$cate[upid]'");
                $mythread['cate'] = $cate['subject'];
            } else {
                $mythread['cate'] = $cate['subject'];
            }
			$mythread['info'] = str_replace('&nbsp;','',strip_tags(ubb($mythread['info']),"<b><p><i><s>"));
            $mythread['title']=str_replace($key,"<font color='#ff0000'>$key</font>",$mythread['title']);
	        $sdtype = explode(" ",$mythread['dpname']);
	        $mythread['sdtype']= explode(" ",$mythread['dpname']);
            $mythreads[] = $mythread;
        }
    }
    $multis = multi($counts,$eacha,$pages,"plugin.php?id=xlwsq_down".$pageadd.$pageadds.$pageaddx.$pageaddyy);
    $r_id = intval($_GET['a']);
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $local[$row['id']] = $row;
    }
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE down >'0' AND display!='0' ORDER BY down DESC LIMIT $hotnum");
    while ($hot = DB::fetch($hotquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$hot[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$hot[upid]'");
                $hot['cate'] = $cate['subject'];
            } else {
                $hot['cate'] = $cate['subject'];
            }
        $hots[] = $hot;
    }

    $tuijianquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY diynum DESC,dateline DESC LIMIT $tjnum");
    while ($tuijian = DB::fetch($tuijianquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$tuijian[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$cate[upid]'");
                $tuijian['cate'] = $cate['subject'];
            } else {
                $tuijian['cate'] = $cate['subject'];
            }
        $tuijians[] = $tuijian;
    }

    $newztquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_zhuanti') . " WHERE display='1' ORDER BY id DESC LIMIT $newztnum");
    while ($newzt = DB::fetch($newztquery)) {
        $newzts[] = $newzt;
    }

	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_banner')."  WHERE display='1' ORDER BY diynum DESC,id DESC");
	while($banner = DB::fetch($query)){
		$banners[] = $banner;
	}
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . "-" . $mcateb['subject']. "-";
      } else {
           $catenav = $mcate['subject']. "-";
      }
    }
    $navtitle = $biaoqiannav. $catenav.$title;
    include template('xlwsq_down:list');
} elseif ($_GET['mod'] == 'index') {
    $catequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE upid='0' AND icon!='' AND display='1' ORDER BY displayorder DESC,id ASC");
    while ($cate = DB::fetch($catequery)) {
		  $cates[] = $cate;
    }
    $newquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . "  ORDER BY id DESC LIMIT $mobilenewnum");
    while ($new = DB::fetch($newquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$new[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$cate[upid]'");
				if ($cate_t) {
                    $new['cate'] = $cate['subject'];
				}
            } else {
                $new['cate'] = $cate['subject'];
            }
        $news[] = $new;
    }
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE down >'0' AND display!='0' ORDER BY down DESC LIMIT $mobilehotnum");
    while ($hot = DB::fetch($hotquery)) {
        $hots[] = $hot;
    }
    $renqiquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE view >'0' AND display!='0' ORDER BY view DESC LIMIT $mobilerenqinum");
    while ($renqi = DB::fetch($renqiquery)) {
        $renqis[] = $renqi;
    }
    $tuijianquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY diynum DESC,dateline DESC LIMIT $mobiletjnum");
    while ($tuijian = DB::fetch($tuijianquery)) {
        $tuijians[] = $tuijian;
    }
    $newztquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_zhuanti') . "  ORDER BY id DESC LIMIT $mobilenewztnum");
    while ($newzt = DB::fetch($newztquery)) {
        $newzts[] = $newzt;
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_banner')." WHERE id ORDER BY id DESC");
	while($banner = DB::fetch($query)){
		$banners[] = $banner;
	}
    include template('xlwsq_down:index');
} elseif ($_GET['mod'] == 'view'||$_GET['mod'] == 'pinglunlist') {
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
       $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE id = '$sid' AND display!='0'");
	}else{
	   $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id = '$sid'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_down', 'error'),"plugin.php?id=xlwsq_down") : '';
    $mythread['tupianshu']= DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_img')." WHERE sid='$sid' AND display!='0'");
    $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
    DB::query("UPDATE " . DB::table('plugin_xlwsq_down_item') . " SET `view` = view+1 WHERE `id` = '$sid'");
    $cate = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_cate')." WHERE id = '$mythread[cate]'");
	  if($cate['upid']!=0){
		$cate_t = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_cate')." WHERE id = '$cate[upid]'");
        $mythread['catescid'] = $cate['upid'];
        $mythread['catename'] = $cate_t['subject'];
        $mythread['catesname'] =$cate['subject'];
	  }else{
        $mythread['catescid'] = $mythread['cate'];
		$mythread['catename'] = $cate['subject'];
    }
	$dinfo = discuzcode($mythread['info']);
	$videotype = gontenfile(strtolower($mythread['video']));
    if (strpos($mythread[video], '</iframe>') !== FALSE) {
       $vid=stripslashes($mythread[video]);
       $pcvideo= "$vid";
       $mvideo= "$vid";
	}elseif (strpos($mythread['video'], 'player.youku.com') !== FALSE) {
	   $vid1=explode("sid/",$mythread['video']);
	   $vid2=explode("/v.swf",$vid1[1]);
	   $vid=$vid2[0];
       $pcvideo= "<iframe width='100%' height='450' src='//player.youku.com/embed/$vid' allowfullscreen frameborder='0'></iframe>";
       $mvideo= "<iframe width='100%' height='200' src='//player.youku.com/embed/$vid' allowfullscreen frameborder='0'></iframe>";
	}elseif (strpos($mythread[video], 'cloud.youku.com') !== FALSE) {
	   $vid=explode("vid=",$mythread[video]);
       $pcvideo= "<iframe width='100%' height='550' src='//player.youku.com/embed/$vid[1]' allowfullscreen frameborder='0'></iframe>";
       $mvideo= "<iframe width='100%' height='200' src='//player.youku.com/embed/$vid[1]' allowfullscreen frameborder='0'></iframe>";
	}elseif (strpos($mythread[video], 'static.video.qq.com') !== FALSE) {
       $qqurl = str_replace('static.video.qq.com/TPout.swf', 'v.qq.com/iframe/player.html', $mythread['video']);
       $mvideo= "<iframe width='100%' height='200' src='$qqurl' allowfullscreen frameborder='0'></iframe>";
       $pcvideo= "<iframe width='100%' height='450' src='$qqurl' allowfullscreen frameborder='0'></iframe>";
	}elseif (strpos($mythread[video], 'imgcache.qq.com') !== FALSE) {
       $qqurl = str_replace('imgcache.qq.com/tencentvideo_v1/playerv3/TPout.swf', 'v.qq.com/iframe/player.html?', $mythread['video']);
	   $vid=explode("vid/",$mythread[video]);
	   $murl=$qqurl.$vid;
       $mvideo= "<iframe width='100%' height='230' src='$murl' allowfullscreen frameborder='0'></iframe>";
       $pcvideo= "<iframe width='100%' height='450' src='$murl' allowfullscreen frameborder='0'></iframe>";
	}elseif (strpos($mythread[video], 'player.video.qiyi.com') !== FALSE) {
       $vid =explode("/",$mythread[video]);
	   $vid2=explode("tvId=",$mythread[video]);
	   $vid3=explode("-isPurchase",$vid2[1]);
       $mvideo= "<iframe width='100%' height='200' src='//open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=$vid[3]&tvId=$vid3[0]' allowfullscreen frameborder='0'></iframe>";
       $pcvideo= "<iframe width='100%' height='450' src='//open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=$vid[3]&tvId=$vid3[0]' allowfullscreen frameborder='0'></iframe>";
	}else{
       $mvideo= "<embed src='$mythread[video]' width='100%' height='200' allowFullScreen='true' type='application/x-shockwave-flash'>";
       $pcvideo= "<embed src='$mythread[video]' width='100%' height='450' allowFullScreen='true' type='application/x-shockwave-flash'>";
	}
    $biaoqian = explode(",",$mythread['biaoqian']);
	$yuyan = change($mythread['yuyan']);
	$sdtype = explode(" ",$mythread['dpname']);
	$mythread['sdtype']=$sdtype;
    if (!preg_match('/(http:\/\/)|(https:\/\/)/i', $mythread['url']) && $mythread['url']) {
      $mythread['url'] = "//" . $mythread['url'];
    }
    $mythread['fenxiangnshu']= DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_item')." WHERE uid='$mythread[uid]' AND  display!='0'");
    $shifouyouxiazai = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_xiazaijilu')." WHERE `sid` = '$sid' AND `uid` = '$uid'");
    $daojishi = $_G['timestamp'] - $shifouyouxiazai['dateline'];
    $xiazaipinglunshijian = $xiazaipinglunshijian*60;
    $shengyushijian= intval(($xiazaipinglunshijian-$daojishi)/60);
	$downquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_down')." WHERE sid = '$sid' AND  downurl!='' ORDER BY diynum ASC,id DESC");
	while($downlist = DB::fetch($downquery)){
        $downlist['size'] = filesize($downlist['downurl']);
		$downlists[] = $downlist;
	}
	$imgquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_img')." WHERE sid = '$sid' AND  display!='0' ORDER BY dateline DESC LIMIT $jietushuliang");
	while($imglist = DB::fetch($imgquery)){
		$imglistid[] = $imglist['id'];
		$imglists[] = $imglist;
	}
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE down >'0' AND display!='0' ORDER BY down DESC LIMIT $hotnum");
    while ($hot = DB::fetch($hotquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$hot[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$hot[upid]'");
				if ($cate_t) {
                    $hot['cate'] = $cate['subject'];
                }
            } else {
                $hot['cate'] = $cate['subject'];
            }
        $hots[] = $hot;
    }
    $tuijianquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY diynum DESC,dateline DESC LIMIT $tjnum");
    while ($tuijian = DB::fetch($tuijianquery)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$tuijian[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$cate[upid]'");
			if ($cate_t) {
                $tuijian['cate'] = $cate['subject'];
			}
        } else {
            $tuijian['cate'] = $cate['subject'];
        }
        $tuijians[] = $tuijian;
    }
    $buy = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_record') . " WHERE sid = '$sid' AND buyuid = '$uid'");
	$ypl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_post') . " WHERE sid = '$sid' AND uid = '$uid'");
    if(submitcheck('applysubmit')){	
	    if(!$_G['uid']){showmessage(lang('plugin/xlwsq_down', 'youkewuquanxianpinglun'), array(), array('alert' => 'error'));}
        if($xiazaipinglun == '1' && !$shifouyouxiazai){
            showmessage(lang('plugin/xlwsq_down', 'xiazaiyaoqiu'),dreferer());   
	    }
	    if($duocipingset ==0 && $ypl){
			showmessage(lang('plugin/xlwsq_down', 'yijingpinglunguo'), array(), array('alert' => 'error'));
		}
		    $message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
            $pf0 = intval($_GET['pf0']);
            $pf1 = intval($_GET['pf1']);
            $pf2 = intval($_GET['pf2']);
            $pf3 = intval($_GET['pf3']);
            $pf4 = intval($_GET['pf4']);
            $pf5 = intval($_GET['pf5']);
            $pf6 = intval($_GET['pf6']);
            $pf7 = intval($_GET['pf7']);
			if(empty($_GET['pf0'])){$pfa = 0;}else{$pfa = 1;}
			if(empty($_GET['pf1'])){$pfb = 0;}else{$pfb = 1;}
			if(empty($_GET['pf2'])){$pfc = 0;}else{$pfc = 1;}
			if(empty($_GET['pf3'])){$pfd = 0;}else{$pfd = 1;}
			if(empty($_GET['pf4'])){$pfe = 0;}else{$pfe = 1;}
			if(empty($_GET['pf5'])){$pff = 0;}else{$pff = 1;}
			if(empty($_GET['pf6'])){$pfg = 0;}else{$pfg = 1;}
			if(empty($_GET['pf7'])){$pfh = 0;}else{$pfh = 1;}
	        if($_G['groupid']==1||in_array($_G['uid'], $admins)){
				$display =1; 
			}else{
				$display = intval($display);
			}
			DB::insert('plugin_xlwsq_down_post',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'pf5' => $pf5,'pf6' => $pf6,'pf7' => $pf7,'pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pff' => $pff,'pfg' => $pfg,'pfh' => $pfh,'message' => $message,'display' => $display,'dateline' => time()));
            $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_post')." WHERE sid='$sid' AND display!='0'"); 
			$sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pf5) AS 'pf5' , sum(pf6) AS 'pf6' , sum(pf7) AS 'pf7' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe' ,sum(pff) AS 'pff' ,sum(pfg) AS 'pfg' ,sum(pfh) AS 'pfh'  FROM ".DB::table('plugin_xlwsq_down_post')." WHERE sid='$sid' AND display!='0'";
			$result = DB::query($sql);
			$row = DB::fetch($result);  
			$pf0 = intval($row['pf0']);
			$pf1 = intval($row['pf1']);
			$pf2 = intval($row['pf2']);
			$pf3 = intval($row['pf3']);
			$pf4 = intval($row['pf4']);
			$pf5 = intval($row['pf5']);
			$pf6 = intval($row['pf6']);
			$pf7 = intval($row['pf7']);
			$pfa = intval($row['pfa']);
			$pfb = intval($row['pfb']);
			$pfc = intval($row['pfc']);
			$pfd = intval($row['pfd']);
			$pfe = intval($row['pfe']);
			$pff = intval($row['pff']);
			$pfg = intval($row['pfg']);
			$pfh = intval($row['pfh']);
			DB::update('plugin_xlwsq_down_item', array('pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pff' => $pff,'pfg' => $pfg,'pfh' => $pfh,'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'pf5' => $pf5,'pf6' => $pf6,'pf7' => $pf7,'dpcount' => $dpcount), "id='$sid'");
            if($pinglunaddshuliang > '0' && $pinglunextcredita){
	            $plf = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_pinglunjiangli') . " WHERE sid = '$sid' AND uid = '$uid'");
                if (!$plf){
				    updatemembercount($uid, array($pinglunextcredita => +$pinglunaddshuliang));
				    $moneytype = $_G['setting']['extcredits'][$pinglunextcredita]['title'];
		        	DB::insert('plugin_xlwsq_down_pinglunjiangli',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'title' => $mythread['title'],'jianglishu' => $pinglunaddshuliang,'moneytype' => $moneytype,'dateline' => $_G['timestamp']));
			    }
            }
			if(intval($display) == 0){
			    showmessage(lang('plugin/xlwsq_down', 'pinglundengdaishenhezhong'),dreferer());
			}else{
				showmessage(lang('plugin/xlwsq_down', 'tijiaochenggong'), dreferer(), array(), array('showdialog' => true, 'locationtime' => true));
			}
    }
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_post')." WHERE sid='$sid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$postquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_post')." WHERE sid='$sid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$postdata= array();
		$replydata= array();
		while($pl = DB::fetch($postquery)){
			$recount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_reply')." WHERE dpid = ".$pl['id']." AND display!='0'");
            $pl['count']=$recount;
			$postdata[$pl['id']] = $pl;
			$replyquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_reply'). " where dpid = ".$pl['id']." AND display!='0' ORDER BY dateline DESC LIMIT 5");
		    while($re = DB::fetch($replyquery)){
			    $reinfo = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_reply')." WHERE id = ".$re['redpid'].""); 
                $re['rereauthor']  = $reinfo['reauthor'];
                $re['reremessage']  = $reinfo['remessage'];
		   		$replydata[$pl['id']][$re['id']] = $re;
		   		$re['recount'] = $pl['reply'];	
			}

		}
		$postdata = dhtmlspecialchars($postdata);
		$replydata = dhtmlspecialchars($replydata);
	}
	$multi = "<div class='pages cl' style='margin:10px 5px;'>" .multi($count, $each, $page,'plugin.php?id=xlwsq_down:xlwsq_down:&mod=view&sid='.$sid.'')."</div>";
	$mobliemulti = multi($count, $each, $page,'plugin.php?id=xlwsq_down:xlwsq_down:&mod=pinglunlist&sid='.$sid.'');
    if($_GET['pinglun'] == 'del'){
        if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	        $sid = intval($_GET['sid']);
	        $did = intval($_GET['did']);
            if($_GET['formhash'] == FORMHASH) {
	            DB::query("DELETE a,b FROM ".DB::table('plugin_xlwsq_down_post')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_down_reply')." AS b ON a.id = b.dpid WHERE a.id = '$did' ");
	            $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_post')." WHERE sid='$sid' AND display!='0'"); 
				$sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pf5) AS 'pf5' , sum(pf6) AS 'pf6' , sum(pf7) AS 'pf7' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe' ,sum(pff) AS 'pff' ,sum(pfg) AS 'pfg' ,sum(pfh) AS 'pfh'  FROM ".DB::table('plugin_xlwsq_down_post')." WHERE sid='$sid' AND display!='0' ";
				$result = DB::query($sql);
				$row = DB::fetch($result);  
				$pf0 = intval($row['pf0']);
				$pf1 = intval($row['pf1']);
				$pf2 = intval($row['pf2']);
				$pf3 = intval($row['pf3']);
				$pf4 = intval($row['pf4']);
				$pf5 = intval($row['pf5']);
				$pf6 = intval($row['pf6']);
				$pf7 = intval($row['pf7']);
				$pfa = intval($row['pfa']);
				$pfb = intval($row['pfb']);
				$pfc = intval($row['pfc']);
				$pfd = intval($row['pfd']);
				$pfe = intval($row['pfe']);
				$pff = intval($row['pff']);
				$pfg = intval($row['pfg']);
				$pfh = intval($row['pfh']);
	            DB::update('plugin_xlwsq_down_item', array('pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pff' => $pff,'pfg' => $pfg,'pfh' => $pfh,'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'pf5' => $pf5,'pf6' => $pf6,'pf7' => $pf7,'dpcount' => $dpcount), "id='$sid'");
	            showmessage(lang('plugin/xlwsq_down', 'shanchuok'), dreferer());
            }
        }else{		
	        showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), '', array(), array('alert' => 'right'));
        }
    }
    $navtitle = $mythread['title'] . " - " . $title;
	$metakeywords = $mythread['biaoqian'];
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($dinfo) , 80, '...'));
	if($_GET['mod']=='view'){
        include template('xlwsq_down:view');
	}elseif($_GET['mod']=='pinglunlist'){
		include template('xlwsq_down:pinglunlist');
	}
} elseif ($_GET['mod'] == 'report') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id = '$sid'");
	if(submitcheck('addreport')){
        $url = 'plugin.php?id=xlwsq_down&mod=view&sid='.$sid;
		$urlkey = md5($url);
    	$message =cutstr(dhtmlspecialchars(trim($_GET['message'])), 300, '');
	if($reportid = C::t('common_report')->fetch_by_urlkey($urlkey)) {
		C::t('common_report')->update_num($reportid, $message);
	}else {
		DB::insert('common_report',array('id' => '','urlkey' => $urlkey,'url' => $url,'message' => $message,'uid' => $_G['uid'],'username' =>$_G['username'],'num' => '1', 'dateline' => $_G['timestamp']));
	}
    for ($i = 0; $i < count($admins); $i++) {
        notification_add($admins[$i], 'report', 'new_report', array('from_id' => 1, 'from_idtype' => 'newreport'), 1);
    }
    showmessage(lang('plugin/xlwsq_down', 'jubaochenggong') , 'plugin.php?id=xlwsq_down&mod=view&sid='.$sid, array() , array('alert' => 'right'));
	}
    include template('xlwsq_down:report');
}elseif($_GET['mod']=='down'){
    $sid = intval($_GET['sid']);
	$did = intval($_GET['did']);
	$uid = intval($_G['uid']);
    $itemsql = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE `id` = '$sid'");
    if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
        $error = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE id = '$sid' and display!='0'");
        !$error ? showmessage(lang('plugin/xlwsq_down', 'error'),"plugin.php?id=xlwsq_down") : '';
    }
    $group = explode(",", $itemsql['downgroup']);
    if ($itemsql['uid']!=$_G['uid'] && !in_array($_G['groupid'], $group) && !empty($itemsql['downgroup'])) {
       if (empty($wuquanxianxiazaiurl)) {
	       showmessage($wuquanxianxiazaitishi, dreferer());
	   }else{
           showmessage($wuquanxianxiazaitishi, $wuquanxianxiazaiurl, array() , array('alert' => 'error'));
       }
	}
	$moneytype = $_G['setting']['extcredits'][$softpaytype]['title'];
    $paymoney = getuserprofile('extcredits'."$softpaytype");
    $buy = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_record') . " WHERE sid = '$sid' AND buyuid = '$uid'");
    if($buy){
	}else{
       $price=$itemsql['price'];
       $fabuuid=$itemsql['uid'];
       $fabuauthor=$itemsql['author'];
       $title=$itemsql['title'];
     if($price=="0"||$fabuuid == $_G['uid']||$_G['groupid']=="1"||in_array($_G['groupid'], $free)){
      }else{
       if($paymoney<$price){
         $tixing= lang('plugin/xlwsq_down', 'xiaohaotishi').$price.$moneytype.lang('plugin/xlwsq_down', 'jifenbuzu');
             if(!$_G['uid']){
                  showmessage('not_loggedin', NULL, array() , array('login' => 1)) ;
	         }else{
                 if (empty($chongzhiurl)) {
	                 showmessage($tixing, dreferer());
	             }else{
                     showmessage($tixing, 'plugin.php?id=xlwsq_down&mod=chongzhi&sid='.$sid, array() , array('alert' => 'error'));
                 }
	         }
       }else{
			 if($_G['uid']!=$fabuuid){
                 $income=intval($price*$payset);
	             updatemembercount($_G['uid'], array($softpaytype => -$price));
	             updatemembercount($fabuuid, array($softpaytype => +$income));
				 DB::insert('plugin_xlwsq_down_record',array('id' => '','sid' => $sid,'selluid' => $fabuuid,'seller' => $fabuauthor,'buyuid' => $uid,'buyer' => $_G['username'],'buyerpay' => $price,'title' => $title,'sellincome' => $income,'moneytype' => $moneytype,'dateline' => $_G['timestamp']));
                 showmessage(lang('plugin/xlwsq_down', 'zhifuchenggong'), 'plugin.php?id=xlwsq_down&mod=view&sid='.$sid.'#downlist', array() , array('alert' => 'right'));
             }
         }
     }
    }
    $downurlsql = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_down')." WHERE `id` = '$did'");
	if($downurlsql){
        DB::query("UPDATE " . DB::table('plugin_xlwsq_down_item') . " SET `down` = down+1 WHERE `id` = '$sid'");
        DB::query("UPDATE " . DB::table('plugin_xlwsq_down_down') . " SET `down` = down+1 WHERE `id` = '$did'");
		DB::insert('plugin_xlwsq_down_xiazaijilu',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'title' => $itemsql['title'],'downname' => $downurlsql['downname'],'did' => $downurlsql['id'],'dateline' => $_G['timestamp']));
	}
    if (!preg_match('/(http:\/\/)|(https:\/\/)/i', $downurlsql['downurl'])) {
        header('Location: '.$_G['siteurl'].$downurlsql['downurl']);
	}else{
        header('Location: ' . $downurlsql['downurl']);
	}
}elseif($_GET['mod']=='viewmima'){
    $sid = intval($_GET['sid']);
	$did = intval($_GET['did']);
	$uid = intval($_G['uid']);
    $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE `id` = '$sid'");
    $buy = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_record') . " WHERE sid = '$sid' AND buyuid = '$uid'");
    $down = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_down')." WHERE `id` = '$did'");
    include template('xlwsq_down:viewmima');
} elseif ($_GET['mod'] == 'pic') {
    $sid = intval($_GET['sid']);
    if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
       $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE id = '$sid' AND display!='0'");
	}else{
	   $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE id = '$sid'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_down', 'error'),"plugin.php?id=xlwsq_down") : '';
	$mythread = dhtmlspecialchars($mythread);
	$yuyan = change($mythread['yuyan']);
	$sdtype = explode(" ",$mythread['dpname']);
	$mythread['sdtype']=$sdtype;
	$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_img'). " WHERE sid='$sid' AND display!='0'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 24;
	if($countr) {
	   $picquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_img')." WHERE sid = '$sid' AND display!='0' ORDER BY  dateline DESC LIMIT $starts,24");
	   while($piclist = DB::fetch($picquery)){
		$piclistid[] = $piclist['id'];
		$piclists[] = $piclist;
	   }
	}
	$multir = "<div class='pages cl' style='margin:5px;'>".multi($countr, 24, $pages,'plugin.php?id=xlwsq_down&mod=pic&sid='.$sid.'')."</div>";
    $navtitle = $mythread['title'] . " - " . $title;
	$metakeywords = $mythread['biaoqian'];
    include template('xlwsq_down:pic');
} elseif ($_GET['mod'] == 'zhuantilist') {
    if ($zhuantiset=='0') {
        showmessage(lang('plugin/xlwsq_down', 'zhuantiweikaiqi') , dreferer());
    }
    $cate_id = intval($_GET['a']);
    $sd = intval($_GET['b']);
    $yuyan = intval($_GET['yy']);
    $where=$pageadd="";
    if($_GET['key']){
      $key=stripsearchkey($_GET['key']);
	  $where=" AND title like '%".addcslashes(addslashes($key), '%_')."%' '";
	  $keync=urlencode($key);
	  $pageadd="&key=$keync";
    }
	if ($_GET['paixu']=='view') {
		$px="WHERE display='1' $where ORDER BY view DESC"; $pageadd="&paixu=view";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_zhuanti')." WHERE display='1'".$where);
	}else{
		$px="WHERE display='1' $where ORDER BY diynum DESC,id DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_zhuanti')." WHERE display='1'".$where);
    }
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $ztlistnum;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_zhuanti') . " $px LIMIT $starts,$ztlistnum");
        while ($mythread = DB::fetch($query)) {
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px;'>" . multi($counts,$ztlistnum,$pages,'plugin.php?id=xlwsq_down&mod=zhuantilist'.$pageadd)."</div>";
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $local[$row['id']] = $row;
    }
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_zhuanti') . " WHERE display='1' AND view >'0' ORDER BY view DESC LIMIT $hotztnum");
    while ($hot = DB::fetch($hotquery)) {
        $hots[] = $hot;
    }
    $navtitle = lang('plugin/xlwsq_down', 'zhuanti'). " - " . $title;
    include template('xlwsq_down:zhuantilist');
} elseif ($_GET['mod'] == 'zhuantiview') {
    if ($zhuantiset=='0') {
        showmessage(lang('plugin/xlwsq_down', 'zhuantiweikaiqi') , dreferer());
    }
	$ztid = intval($_GET['ztid']);
    $zhuanti = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_zhuanti') . " WHERE display='1' AND id='$ztid'");
    !$zhuanti ? showmessage(lang('plugin/xlwsq_down', 'error'),"plugin.php?id=xlwsq_down") : '';
	DB::query("UPDATE " . DB::table('plugin_xlwsq_down_zhuanti') . " SET `view` = view+1 WHERE `id` = '$ztid'");
	$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item')." WHERE instr(concat(',',`zhuanti`,','),',$ztid,') AND display!='0'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $ztviewnum;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE instr(concat(',',`zhuanti`,','),',$ztid,')  AND display!='0' ORDER BY diynum DESC,id DESC LIMIT $starts,$ztviewnum");
        while ($mythread = DB::fetch($query)) {
             $cate = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_cate')." WHERE id = '$mythread[cate]'");
	         if($cate['upid']!=0){
	        	$cate_t = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_cate')." WHERE id = '$cate[upid]'");
		        $mythread['cate'] = $cate['subject'];
	         }else{
		        $mythread['cate'] = $cate['subject'];
             }
            $mythreads[] = $mythread;
        }
	    $mythreads = dhtmlspecialchars($mythreads);
    }
    $multis =multi($counts,$ztviewnum,$pages,'plugin.php?id=xlwsq_down&mod=zhuantiview&ztid='.$ztid.'');
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_zhuanti') . " WHERE  display='1' AND  view >'0' ORDER BY view DESC LIMIT $hotztnum");
    while ($hot = DB::fetch($hotquery)) {
        $hots[] = $hot;
    }
    $navtitle = $zhuanti['title']. " - " . lang('plugin/xlwsq_down', 'zhuanti'). " - " . $title;
    $metadescription = cutstr(strip_tags($zhuanti['info']) , 80, '...');
    include template('xlwsq_down:zhuantiview');
}elseif($_GET['mod']=='useraddpic'){
	if ($useruppicset == 0){showmessage(lang('plugin/xlwsq_down', 'weikaifang'));};
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    include_once 'source/plugin/xlwsq_down/class/upic.class.php';
    $sid = intval($_GET['sid']);
    if (submitcheck('addpic')) {
        for ($i = 1; $i <= 10; $i++) {
            $pic = 'pic'.$i;
            if ($_FILES[$pic]['tmp_name']) {
			    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
			    if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_down', 'feifatupianleixing'));
				}
                $picname = $_FILES[$pic]['name'];
                $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                $arr = explode(".", $_FILES[$pic]["name"]);
                $hz = $arr[count($arr) - 1];
                if (!in_array($hz, $filetype)) {
                   showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));
                }
                $pics = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
			    $img_dir = "source/plugin/xlwsq_down/upimg/".$sid. "/";
                if (!is_dir($img_dir)) {
                   mkdir($img_dir);
                }
                $$pic = $img_dir . $pics;
                if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
                   @unlink($_FILES[$pic]['tmp_name']);
                }
                $imageinfo = getimagesize($$pic);
			    if ($imageinfo[0] > $chuliwidth) {
					imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$chuliwidth));
                }else{
					imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]);
				}
                DB::insert('plugin_xlwsq_down_img', array('id' => '','sid' => $sid,'img' => $$pic,'display' => 0,'dateline' => $_G['timestamp']));
           }elseif($_GET[$pic]!=''){
		        DB::insert('plugin_xlwsq_down_img', array('id' => '','sid' => $sid,'img' =>addslashes($_GET[$pic]),'display' => 0,'dateline' => $_G['timestamp']));
		   }
        }
		showmessage(lang('plugin/xlwsq_down', 'fabudengdaishenhe'), 'plugin.php?id=xlwsq_down&mod=pic&sid='.$sid);
    }
    include template('xlwsq_down:useraddpic');
} elseif ($mod == 'userresourcelist') {
    $uid = intval($_GET['uid']);
    $where=$pageadd="";
    if($_GET['key']!=''){
        $key=stripsearchkey(trim($_GET['key']));
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	$userinfo = DB::fetch_first("SELECT * FROM " . DB::table('common_member') . " WHERE uid = '$uid'");
	!$userinfo ? showmessage(lang('plugin/xlwsq_down', 'error'),"plugin.php?id=xlwsq_down") : '';
	$tukuuserinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_userinfo') . " WHERE uid = '$uid'");
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where uid='$uid' AND display='1' ");
    $pager = intval($_GET['page']);
    $pager = max($pager, 1);
    $starts = ($pager - 1) * $eacha;
    if ($counts) {
        $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE $where uid='$uid' AND display='1' ORDER BY display ASC,dateline DESC LIMIT $starts,$eacha");
        while ($mythread = DB::fetch($rs)) {
            $cate = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$mythread[cate]'"));
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$cate[upid]'");
				if ($cate_t) {
                    $mythread['cate'] = $cate_t['subject'] . " - " . $cate['subject'];
				}
            } else {
                $mythread['cate'] = $cate['subject'];
            }
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px 0;'>" . multi($counts,$eacha, $pager, 'plugin.php?id=xlwsq_down&mod=userresourcelist&uid='.$uid. $pageadd) . "</div>";

    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE down >'0' AND display!='0' AND uid='$uid' ORDER BY down DESC LIMIT $hotnum");
    while ($hot = DB::fetch($hotquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$hot[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$hot[upid]'");
				if ($cate_t) {
                    $hot['cate'] = $cate['subject'];
				}
            } else {
                $hot['cate'] = $cate['subject'];
            }
        $hots[] = $hot;
    }
    $tuijianquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_down_item') . " WHERE tuijian ='1' AND display!='0' AND uid='$uid' ORDER BY diynum DESC,dateline DESC LIMIT $tjnum");
    while ($tuijian = DB::fetch($tuijianquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$tuijian[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_cate') . " WHERE id = '$cate[upid]'");
				if ($cate_t) {
                    $tuijian['cate'] = $cate['subject'];
				}
            } else {
                $tuijian['cate'] = $cate['subject'];
            }
        $tuijians[] = $tuijian;
    }

    $navtitle = $userinfo['username'] .lang('plugin/xlwsq_down', 'navgerentuji').$title;
	include template('xlwsq_down:userresourcelist');
} elseif ($_GET['mod'] == 'userinfoedit') {
    $uid = intval($_GET['uid']);
    $userinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_userinfo') . " WHERE uid = '$uid'");
    if ($userinfo['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
        if (submitcheck('applysubuserinfoedit')) {
            $pic =dhtmlspecialchars($_GET['pic']);;
            $info =dhtmlspecialchars($_GET['info']);;
		    if($_FILES['file']['error']==0){
                if ($userinfo["pic"]!=false){
	                unlink($userinfo["pic"]);
	            }
			    $filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			    $arr=explode(".", $_FILES["file"]["name"]);
		    	$hz=$arr[count($arr)-1];
		    	if(!in_array($hz, $filetype)){
			    	showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));	
		    	}
		        $imageinfo = getimagesize($_FILES['file']['tmp_name']);
			    if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_down', 'tupiangeshibuzhengque'));
			    }
			    $filepath = "source/plugin/xlwsq_down/userimg/".$uid."/";
			    $randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			    if(!file_exists($filepath)){ mkdir($filepath); }
		    	if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
			     	@unlink($_FILES['file']['tmp_name']);
			    }
			    $pic ="source/plugin/xlwsq_down/userimg/".$uid."/".$randname;
		    }
            if ($userinfo) {
                DB::update('plugin_xlwsq_down_userinfo', array('pic' => $pic,'info' => $info,'dateline' => $_G['timestamp']) , "uid='$uid'");
            }else{
		    	DB::insert('plugin_xlwsq_down_userinfo', array('id' => '','uid' => $uid,'info' => $info,'pic' => $pic,'dateline' => $_G['timestamp']));
            }
			showmessage(lang('plugin/xlwsq_down', 'tijiaochenggong'), 'plugin.php?id=xlwsq_down&mod=userresourcelist&uid='.$uid);
        }
    } else {
		showmessage(lang('plugin/xlwsq_down', 'wuquanxiancaozuo'), 'plugin.php?id=xlwsq_down&mod=userresourcelist&uid='.$uid);
    }
	include template('xlwsq_down:userinfoedit');
}elseif($_GET['mod']=='reply'){
	$dpid = intval($_GET['dpid']);
    $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_post')." WHERE id = '$dpid' AND display!='0'");
    if (!$pl){
		showmessage(lang('plugin/xlwsq_down', 'error'), array(), array('alert' => 'error'));
	  }
    $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE id = '$pl[sid]'");
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_down_reply')." WHERE dpid='$dpid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_down_reply')." WHERE dpid='$dpid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$pl = $pls = array();
		while($pl = DB::fetch($query)) {
		    $reinfo = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_reply')." WHERE id = ".$pl['redpid'].""); 
            $pl['rereuid']  = $reinfo['reuid'];
            $pl['rereauthor']  = $reinfo['reauthor'];
            $pl['reremessage']  = $reinfo['remessage'];
			$pls[] = $pl;
		}
		$pls = dhtmlspecialchars($pls);
	}
	$multi = "<div class='pages cl'>".multi($count, $each, $page,'plugin.php?id=xlwsq_down:xlwsq_down:&mod=reply&dpid='.$dpid.'')."</div>";
    $navtitle = $item['title']." - ".$t_title;	
	$metadescription =  cutstr(strip_tags($item['info']), 100, '...');
	$metakeywords = $item['biaoqian'];
	include template('xlwsq_down:replylist');
} elseif ($_GET['mod'] == 'chongzhi') {
    $refererurl = $_SERVER["HTTP_REFERER"];
    if ($chongzhifanhui == '1') {
        header('Location: ' . $chongzhiurl);
    } else{
	    include template('xlwsq_down:chongzhi');
    }
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
	    $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_down_item')." WHERE id = '$sid'");
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_down_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_down_favorites') . " WHERE sid = '$sid' and uid = '$uid'");
            showmessage(lang('plugin/xlwsq_down', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
        } else {
            DB::insert('plugin_xlwsq_down_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'title' => $item['title'],'dateline' => $_G['timestamp']));
            showmessage(lang('plugin/xlwsq_down', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
        }
    }
}
function change($str){
	$return = array();
	$array = explode(",",$str);
	foreach ($array as $v){
		$t = explode(" ",$v);
		$return[$t[0]] = $t[0];
	}
	return $return;
}
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
function ubb($Text) {
      $Text=preg_replace("/\r/","<br>",$Text);
      $Text=preg_replace("/\[url=(.+?)\](.+?)\[\/url\]/is","<a href='\\1' target='_blank'>\\2</a>",$Text);
      $Text=preg_replace("/\[img\](.+?)\[\/img\]/is","<a href='\\1' target='_blank'><img src='\\1'></a>",$Text);
      $Text=preg_replace("/\[img=(.+?),(.+?)\](.+?)\[\/img\]/is","<a href='\\3' target='_blank'><img src='\\3' width='\\1' height='\\2'></a>",$Text);
      $Text=preg_replace("/\[color=(.+?)\](.+?)\[\/color\]/is","<font color=\\1>\\2</font>",$Text);
      $Text=preg_replace("/\[b\](.+?)\[\/b\]/is","<b>\\1</b>",$Text);
      return $Text;
}
function formatSize($size) { 
    $sizes = array(" Bytes", " KB", " MB", " GB", " TB", " PB", " EB", " ZB", " YB"); 
    if ($size == 0) {  
        return('n/a');  
    } else { 
      return (round($size/pow(1024, ($i = floor(log($size, 1024)))), 2) . $sizes[$i]);  
    } 
}
function gontenfile($str){
$gonten= explode('.',$str);
$gonten = array_reverse($gonten);
return $gonten[0];
}
//From: d'.'is'.'m.ta'.'obao.com
?>