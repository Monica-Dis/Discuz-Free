<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$plyes=($_G['cache']['plugin']['xlwsq_down']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
if (file_exists("source/plugin/xlwsq_down/qiniusdk/autoload.php") && $pingtaiset==1) {
  require_once 'qiniusdk/autoload.php';
}
$uploaddx=$uploaddx*1024;
$sid = intval($_GET['sid']);
$filetype = explode(",",$uptype);
if ($_FILES['file']['error']==0 && $_GET['formhash'] == FORMHASH) {
	 $picsize = $_FILES['file']['size'];
	 $filetype = explode(",",$uptype);
	 $arr=explode(".", strtolower($_FILES['file']["name"]));
     $hz = $arr[count($arr) - 1];
     $upname = addslashes(diconv(urldecode($arr[0]), 'UTF-8'));
     $pic1 = "source/plugin/xlwsq_down/images/fujian.png";
     $pic2 = "source/plugin/xlwsq_down/images/error.jpg";
	 if($qiniuconfig['upToken']){
        if($picsize <= $uploaddx  && in_array($hz,$filetype)){
            $downurl = qiniuupload($_FILES['file']);
        	 DB::insert('plugin_xlwsq_down_down', array('id' => '','sid' => $sid,'downname' => $upname,'downurl' => $downurl,'type' => 1));  
			 echo json_encode(array("error" => "0", "pic" => $pic1, "name" => $_FILES['file']["name"]));
        }else{
			 echo json_encode(array("error" => "0", "pic" => $pic2, "name" => $_FILES['file']["name"]));
		}
	}else{
        $update = date('YmdHis') . rand(100, 999);
        $upload_dir = "source/plugin/xlwsq_down/upload/".$sid."/";
        if(!file_exists($upload_dir)){
           mkdir($upload_dir,0777,true);
        }
        $downurl =$upload_dir .$update. "." . $hz;
        if($picsize <= $uploaddx  && in_array($hz,$filetype)){
            if (@copy($_FILES['file']['tmp_name'], $downurl) || @move_uploaded_file($_FILES['file']['tmp_name'], $downurl)) {
             @unlink($_FILES['file']['tmp_name']);
            }
        	 DB::insert('plugin_xlwsq_down_down', array('id' => '','sid' => $sid,'downname' => $upname,'downurl' => $downurl,'type' => 1));  
			 echo json_encode(array("error" => "0", "pic" => $pic1, "name" => $_FILES['file']["name"]));
        }else{
			 echo json_encode(array("error" => "0", "pic" => $pic2, "name" => $_FILES['file']["name"]));
		}
    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>