<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `author` varchar(80) NOT NULL,
	  `title` varchar(255) NOT NULL,
	  `pic` text NOT NULL,
	  `cate` int(11) NOT NULL,
	  `video` text NOT NULL,
	  `sd1` varchar(255) NOT NULL,
	  `sd2` varchar(255) NOT NULL,
	  `sd3` varchar(255) NOT NULL,
	  `sd4` varchar(255) NOT NULL,
	  `sd5` varchar(255) NOT NULL,
	  `url` text NOT NULL,
	  `webname` varchar(255) NOT NULL,
	  `yuyan` varchar(80) NOT NULL,
	  `info` text NOT NULL,
	  `price` int(11) NOT NULL,
	  `dpname` varchar(255) NOT NULL,
	  `biaoqian` varchar(255) NOT NULL,
	  `view` int(11) NOT NULL,
	  `down` int(11) NOT NULL,
   	  `pf0` int(11) NOT NULL,
 	  `pf1` int(11) NOT NULL,
   	  `pf2` int(11) NOT NULL,
   	  `pf3` int(11) NOT NULL,
   	  `pf4` int(11) NOT NULL,
   	  `pf5` int(11) NOT NULL,
   	  `pf6` int(11) NOT NULL,
   	  `pf7` int(11) NOT NULL,
   	  `pfa` int(11) NOT NULL,
   	  `pfb` int(11) NOT NULL,
   	  `pfc` int(11) NOT NULL,
   	  `pfd` int(11) NOT NULL,
   	  `pfe` int(11) NOT NULL,
   	  `pff` int(11) NOT NULL,
   	  `pfg` int(11) NOT NULL,
   	  `pfh` int(11) NOT NULL,
      `dpcount` int(11) NOT NULL,
      `tuijian` tinyint(1) NOT NULL,
	  `top` tinyint(1)  NOT NULL,
	  `downgroup` varchar(255) NOT NULL,
	  `zhuanti` varchar(255) NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_cate` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `icon` varchar(255) NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `displayorder` int(1) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_post` (
	  `id` int(11) NOT NULL auto_increment,
	  `sid` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
  	  `author` varchar(80) NOT NULL,
  	  `message` text NOT NULL,
   	  `pf0` int(11) NOT NULL,
 	  `pf1` int(11) NOT NULL,
   	  `pf2` int(11) NOT NULL,
   	  `pf3` int(11) NOT NULL,
   	  `pf4` int(11) NOT NULL,
   	  `pf5` int(11) NOT NULL,
   	  `pf6` int(11) NOT NULL,
   	  `pf7` int(11) NOT NULL,
   	  `pfa` int(11) NOT NULL,
   	  `pfb` int(11) NOT NULL,
   	  `pfc` int(11) NOT NULL,
   	  `pfd` int(11) NOT NULL,
   	  `pfe` int(11) NOT NULL,
   	  `pff` int(11) NOT NULL,
   	  `pfg` int(11) NOT NULL,
   	  `pfh` int(11) NOT NULL,
  	  `display` tinyint(1) NOT NULL,
 	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_reply` (
	  `id` int(11) NOT NULL auto_increment,
	  `dpid` int(11) NOT NULL,
	  `redpid` int(11) NOT NULL,
	  `reuid` int(11) NOT NULL,
  	  `reauthor` varchar(80) NOT NULL,
  	  `remessage` text NOT NULL,
  	  `display` tinyint(1) NOT NULL,
 	  `dateline` int(10) NOT NULL,
      PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_img` (
	  `id` int(11) NOT NULL auto_increment,
	  `sid` int(11) NOT NULL,
	  `img` text NOT NULL,
  	  `display` tinyint(1) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_down` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(11) NOT NULL,
	  `sid` int(11) NOT NULL,
	  `downname` varchar(255) NOT NULL,
      `downurl` text NOT NULL,
      `type` tinyint(1)  NOT NULL,
	  `down` int(11) NOT NULL,
	  `tiquma` varchar(50) NOT NULL,
	  `jieyamima` varchar(100) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_favorites` (
   	  `id` int(11) NOT NULL auto_increment,
 	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
	  `title` varchar(255) NOT NULL,
   	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_record` (
      `id` int(11) NOT NULL auto_increment,
      `sid` int(11) NOT NULL,
      `buyuid` int(11) NOT NULL,
      `buyer` varchar(80) NOT NULL,
      `buyerpay` int(11) NOT NULL,
      `selluid` int(11) NOT NULL,
      `seller` varchar(80) NOT NULL,
      `title` varchar(255) NULL,
      `sellincome` int(11) NOT NULL,
      `moneytype` varchar(30) NOT NULL,
      `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_banner` (
	  `id` int(11) NOT NULL auto_increment,
	  `title` varchar(255) NOT NULL,
	  `pic` text NOT NULL,
	  `info` varchar(255) NOT NULL,
	  `url` varchar(255) NOT NULL,
	  `diynum` int(11) NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_zhuanti` (
	  `id` int(11) NOT NULL auto_increment,
	  `title` varchar(255) NOT NULL,
	  `pic` text NOT NULL,
	  `info` varchar(255) NOT NULL,
	  `diynum` int(11) NOT NULL,
	  `view` int(11) NOT NULL,
      `display` tinyint(1) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
    CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_pinglunjiangli` (
	  `id` int(11) NOT NULL auto_increment,
      `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `title` varchar(255) NOT NULL,
   	  `jianglishu` int(11) NOT NULL,
   	  `moneytype` varchar(20) NOT NULL,
   	  `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;
    CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_xiazaijilu` (
	  `id` int(11) NOT NULL auto_increment,
      `sid` int(11) NOT NULL,
   	  `did` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `title` varchar(255) NOT NULL,
   	  `downname` varchar(255) NOT NULL,
   	  `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_down_userinfo` (
   	  `id` int(11) NOT NULL auto_increment,
   	  `uid` int(11) NOT NULL,
	  `pic` text NOT NULL,
	  `info` text NOT NULL,
   	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`),
      INDEX name (id,uid)
   ) ENGINE=MyISAM;
INSERT INTO `pre_plugin_xlwsq_down_cate` (`id`, `upid`, `subid`, `subject`, `icon`, `display`, `displayorder`) VALUES
(1, 0, '', '$installlang[cate1]', 'source/plugin/xlwsq_down/images/cate1.jpg', 1, 0),
(2, 0, '', '$installlang[cate2]', 'source/plugin/xlwsq_down/images/cate2.jpg', 1, 0),
(3, 0, '', '$installlang[cate3]', 'source/plugin/xlwsq_down/images/cate3.jpg', 1, 0),
(4, 0, '', '$installlang[cate4]', 'source/plugin/xlwsq_down/images/cate4.jpg', 1, 0),
(5, 0, '', '$installlang[cate5]', 'source/plugin/xlwsq_down/images/cate5.jpg', 1, 0),
(6, 0, '', '$installlang[cate6]', 'source/plugin/xlwsq_down/images/cate6.jpg', 1, 0),
(7, 0, '', '$installlang[cate7]', 'source/plugin/xlwsq_down/images/cate7.jpg', 1, 0),
(8, 0, '', '$installlang[cate8]', 'source/plugin/xlwsq_down/images/cate8.jpg', 1, 0),
(9, 0, '', '$installlang[cate9]', '', 0, 0),
(10, 0, '', '$installlang[cate10]', '', 0, 0);
EOF;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_down/discuz_plugin_xlwsq_down.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_down/discuz_plugin_xlwsq_down_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_down/discuz_plugin_xlwsq_down_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_down/discuz_plugin_xlwsq_down_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_down/discuz_plugin_xlwsq_down_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_down/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_down/install.php');
runquery($sql);
$finish =true;
?>