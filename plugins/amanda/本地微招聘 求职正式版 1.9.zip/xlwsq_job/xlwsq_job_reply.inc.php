<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/discuzcode');
global $_G;
if (!isset($_G['cache']['plugin'])) {loadcache('plugin');}
$plyes=($_G['cache']['plugin']['xlwsq_job']);
$menubgcolor=$plyes['menubgcolor'];
!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';
if($_GET['option'] == 'reply'){
		$id = intval($_GET['did']);
		$sid = intval($_GET['sid']);
        $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_post') . " WHERE id = '$id'");
		$pl['message'] = discuzcode($pl['message']);
        $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid'");
		if($item['uid']==$_G['uid']||$_G['groupid']=="1"){}
           else{
		      showmessage(lang('plugin/xlwsq_job', 'caozuocuowu'), '', array(), array('login' => true));
     	}
		if(submitcheck('applysubreply')){
		        $reply = strip_tags(addslashes($_GET['reply']),"<b><p><i><s>");
					DB::update('plugin_xlwsq_job_post', array('reply' => $reply), "id='$id'");
					$pid = $pl['bbspid'];
					if(!empty($reply)){
                       $bbsmessage =$pl['message'].'[hr][size=2][color=#ff0000]'.lang('plugin/xlwsq_job', 'louzhuhuifu').'[/color][color=#1E90FF]'.$reply.'[/color][/size]';
					}else{
					   $bbsmessage =$pl['message'];
					}
                    DB::query("UPDATE ".DB::table('forum_post')." SET  message='$bbsmessage' where pid='$pid'");
					   if($_G['mobile']) {
                          showmessage(lang('plugin/xlwsq_job', 'tijiaochenggong'), 'plugin.php?id=xlwsq_job&mod=view&sid='.$item['id']);
					   } else {
                          showmessage(lang('plugin/xlwsq_job', 'tijiaochenggong'),dreferer());
					   }
		}
		include template('xlwsq_job:reply');
}
//From: d'.'is'.'m.ta'.'obao.com
?>