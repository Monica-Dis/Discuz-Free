<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/xlwsq_job/function/function_core.php';
global $_G;
if (!isset($_G['cache']['plugin'])) {loadcache('plugin');}
$plyes=($_G['cache']['plugin']['xlwsq_job']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
if($_G['mobile']) {
    $menubgcolor=$mobilemenubgcolor;
    $eacha=$mobileeacha;
    $footad=$mobilefootad ? $mobilefootad : $footad;
}
$bannerheight = intval($bannerheight);
$mobilebannerheight = intval($mobilebannerheight);
$mainwidth = intval($mainwidth);
$fulilist = parconfig($fuli);
$fenleilist = parconfig($fenlei);
$jglist = parconfig($jg);
$danweilist = parconfig($danwei);
$fabuset = unserialize($groups);
$groupso = $groupso ? $groupso : '1';
$zhaopingviewgroups = unserialize($zhaopingviewgroups);
$qiuzhiviewgroups = unserialize($qiuzhiviewgroups);
$checkphonegroups = unserialize($checkphonegroups);
$admins = explode(",", $groupso);
$navtitle = $title;
$creditc = abs($creditc);
$creditd = abs($creditd);
$_G['uid'] = $_G['uid'] ? $_G['uid'] : '0';
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if($mod == 'index') {
    $where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    $keytype = intval($_GET['keytype']);
    if($key){
	    if($keytype==1){ 
		   $where="zhiwei like '%".addcslashes(addslashes($key), '%_')."%'  AND ";
	    }elseif($keytype==2){ 
		   $where="comname like '%".addcslashes(addslashes($key), '%_')."%' AND ";
	    }else{ 
		   $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND ";
		}
	$keync=urlencode($key);
	$pageadd="&keytype=$keytype&key=$keync";
    }elseif($_GET['uid']){
		$fuid=intval(trim($_GET['uid']));
		$where="uid='$fuid' AND";
	    $fuidnc=urlencode($fuid);
	    $pageadd="&uid=$fuidnc";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$cate_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
    }
    $sd = intval($_GET['b']);
    if ($sd) {
        $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$sd'");
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
    }
    $b_area_id = intval($_GET['bc']);
    if ($b_area_id) {
        $marea = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_area') . " WHERE id = '$b_area_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_job_area') . " WHERE id='$b_area_id'");
        if ($subids) {
            $b_area = "area IN ($b_area_id,$subids) AND";
        } else {
            $b_area = "area=$b_area_id AND";
        }
        $pageaddbc = "&bc=$b_area_id";
    }
    $s_area_id = intval($_GET['sc']);
    if ($s_area_id) {
        $mareab = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_area') . " WHERE id = '$s_area_id'");
        $s_area = "area='$s_area_id' AND";
        $pageaddsc = "&sc=$s_area_id";
    }
    $money = dhtmlspecialchars($_GET['money']);
    if ($money=='mianyi'){
            $price = "price = '0' AND";
		    $pagejg="&money=$money";
    }elseif ($money){
	     $jgarr=explode('~',$money);
         if ($jgarr[0]==''){
		   $price = "(price <= '$jgarr[1]' AND price != '0') AND";
         }elseif ($jgarr[0]!='' && $jgarr[1]!=''){
		   $price = "(price >= '$jgarr[0]' AND price <= '$jgarr[1]') AND";
         }elseif ($jgarr[1]==''){
		   $price = "price >= '$jgarr[0]' AND";
         }
		$pagejg="&money=$money";
    }else{
		$money='0';
    }
    $fenlei = intval($_GET['type']);
    if ($fenlei){
		$type = "fenlei = '$fenlei' AND";
		$pageaddt="&type=$fenlei";
    }
    if ($guoqixianshi==0){
		$daoqishijian = "AND (endtime = 0 OR endtime > $_G[timestamp])";
    }
    if ($_GET['tj']) {
		$px="tuijian = '1' AND display ='1' $daoqishijian ORDER BY top DESC,diynum DESC,dateline DESC"; $pageadd="&tj=tj";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE $where $wb $wc $b_area $s_area $price $type tuijian = '1' AND display ='1' $daoqishijian");
    }elseif ($_GET['jg']) {
		$px="display ='1' AND price>'0' $daoqishijian ORDER BY price ASC,diynum DESC,dateline DESC"; $pageadd="&jg=jg";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE $where $wb $wc $b_area $s_area $price $type display ='1' AND price>'0' $daoqishijian");
    }elseif ($_GET['hjg']) {
		$px="display ='1' AND price>'0' $daoqishijian ORDER BY price DESC,diynum DESC,dateline DESC"; $pageadd="&hjg=hjg";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE $where $wb $wc $b_area $s_area $price $type display ='1' AND price>'0' $daoqishijian");
    }elseif ($_GET['rq']) {
		$px="display ='1'  $daoqishijian ORDER BY view DESC,diynum DESC,dateline DESC"; $pageadd="&rq=rq";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE $where $wb $wc $b_area $s_area $price $type display ='1' $daoqishijian");
	}else{
		$px="display ='1' $daoqishijian ORDER BY top DESC,topdateline DESC,diynum DESC,updateline DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE $where $wb $wc $b_area $s_area $price $type display ='1'  $daoqishijian");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE $where $wb $wc $b_area $s_area  $price $type $px LIMIT $starts,$eacha");
        $mythread = $mythreads = array();
        while ($mythread = DB::fetch($query)) {
            if ($mythread['topdateline']!='0'){DB::query("UPDATE ".DB::table('plugin_xlwsq_job_item')." SET `topdateline` = '0',`color` = '' WHERE topdateline!= '0' AND topdateline <= ".$_G['timestamp']);}
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$cate[upid]'");
                $mythread['cate'] = $cate_t['subject'].'-'.$cate['subject'];
            } else {
                $mythread['cate'] = $cate['subject'];
            }
            $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_area') . " WHERE id = '$mythread[area]'");
            if ($area['upid'] != 0) {
                $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_area') . " WHERE id = '$area[upid]'");
                $mythread['area'] = $area_t['subject'].'-'.$area['subject'];
            } else {
                $mythread['area'] = $area['subject'];
            }
			    $mythread['dinfo'] = discuzcode($mythread['info']);
			    $mythread['info'] = strip_tags(discuzcode($mythread['info']));
				$mythread['price'] = setUnit($mythread['price']);
                $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px 10px 10px 0;'>" . multi($counts, $eacha, $pages, 'plugin.php?id=xlwsq_job' . $pageadd. $pageadds . $pageaddx . $pageaddbc . $pageaddsc.$pagejg.$pageaddt) . "</div>";
    $r_id = intval($_GET['a']);
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    $bc_id = intval($_GET['bc']);
    $bc_subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_job_area') . " WHERE id='$bc_id'");
    if ($bc_subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_job_area') . " WHERE id IN ($bc_subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $local_sc[$ros['id']] = $ros;
        }
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE tuijian ='1' AND display!='0' $daoqishijian ORDER BY updateline DESC,dateline DESC LIMIT $tjnum");
    $tuijian = $tuijians = array();
    while ($tuijian = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$tuijian[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$cate[upid]'");
            $tuijian['cate'] = $cate_t['subject']." - ".$cate['subject'];
        } else {
            $tuijian['cate'] = $cate['subject'];
        }
        $tuijians[] = $tuijian;
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE view >'0' AND display!='0' $daoqishijian ORDER BY view DESC LIMIT $hotnum");
    $hot = $hots = array();
    while ($hot = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$hot[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$cate[upid]'");
            $hot['cate'] = $cate_t['subject']." - ".$cate['subject'];
        } else {
            $hot['cate'] = $cate['subject'];
        }
        $hots[] = $hot;
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_job_banner')." WHERE display='1' ORDER BY diynum DESC,id DESC");
	while($banner = DB::fetch($query)){
		$banners[] = $banner;
	}
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . " - " . $mcateb['subject']. " - ";
      } else {
           $catenav = $mcate['subject']. " - ";
      }
    }
    if ($b_area_id!='0') {
      if ($s_area_id!='0') {
           $areanav = $marea['subject'] . " - " . $mareab['subject']. " - ";
      } else {
           $areanav = $marea['subject']. " - ";
      }
    }
    $navtitle = $catenav . $areanav.$navtitle;
    include template('xlwsq_job:list');
} elseif ($_GET['mod'] == 'view') {
    $sid = intval($_GET['sid']);
    if($_G['groupid']==1 || in_array($_G['uid'], $admins)){
	   $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid'");
	}else{
	   $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_job_item')." WHERE id = '$sid' AND display='1'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_job', 'error') , "plugin.php?id=xlwsq_job") : '';
    if($mythread['fenlei']%2==1){
       if (!in_array($_G['groupid'], $zhaopingviewgroups) && $_G['groupid'] != "1" && !in_array($_G['uid'], $admins) && $_G['uid'] != $mythread['uid']) {
        showmessage($wuquanxiantishi , '', array() , array('login' => true));
       }
	}else{
       if (!in_array($_G['groupid'], $qiuzhiviewgroups) && $_G['groupid'] != "1" && !in_array($_G['uid'], $admins) && $_G['uid'] !=  $mythread['uid']) {
        showmessage($wuquanxiantishi, '', array() , array('login' => true));
       }
	}
    DB::query("UPDATE " . DB::table('plugin_xlwsq_job_item') . " SET `view` = view+1 WHERE `id` = '$sid'");
    $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_favorites') . " WHERE sid = '$sid' AND uid = '$_G[uid]'");
	$mythread['fabushu']= DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_job_item')." WHERE uid='$mythread[uid]' AND  display!='0'");
    $mythread['info'] = discuzcode($mythread['info']);
    $mythread['cominfo'] = discuzcode($mythread['cominfo']);
	$fuli = change($mythread['fuli']);
    $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$mythread[cate]'");
	if ($cate['upid'] != 0) {
        $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_cate') . " WHERE id = '$cate[upid]'");
        $mythread['cate'] = $cate_t['subject'] . " - " . $cate['subject'];
    } else {
        $mythread['cate'] = $cate['subject'];
    }
    $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_area') . " WHERE id = '$mythread[area]'");
    if ($area['upid'] != 0) {
        $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_area') . " WHERE id = '$area[upid]'");
        $mythread['area'] = $area_t['subject'] . " - " . $area['subject'];
    } else {
        $mythread['area'] = $area['subject'];
    }
    if ($guoqixianshi==0){
		$daoqishijian = "AND (endtime = 0 OR endtime > $_G[timestamp])";
    }
	$othercount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_job_item')." WHERE comname != '' AND comname = '$mythread[comname]' AND id!='$mythread[id]' AND  zhiwei!='' AND display!='0' $daoqishijian"); 
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE comname != '' AND comname = '$mythread[comname]' AND id!='$mythread[id]' AND  zhiwei!='' AND display!='0' $daoqishijian ORDER BY updateline DESC,dateline DESC LIMIT $hotnum");
    $other = $others = array();
    while ($other = DB::fetch($query)) {
        $others[] = $other;
    }
    if(submitcheck('applysubmit')){	
	    $uid = intval($_G['uid']);
	    if($youkepinglunset==1){
            !$_G['uid'] ? $_G['username'] = $_G['clientip'] :'';
        }else{
	        if(!$_G['uid']){
	 	        showmessage(lang('plugin/xlwsq_job', 'youkewuquanxianpinglun'), array(), array('alert' => 'error'));
	        }
        }
	    if(empty($_GET['message'])){
		    showmessage(lang('plugin/xlwsq_job', 'wupinglunneirong'), dreferer());
	    }else{
	        $author = $_G['username'];
		    $message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
			$display = 1; 
            $pid = DB::insert('forum_post_tableid', array('pid'=>NULL), true);
            $fid = $bbsfid;
			$tid = $mythread['bbstid'];
			DB::insert('plugin_xlwsq_job_post',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $author,'message' => $message,'bbspid' => $pid,'display' => $display,'dateline' => $_G['timestamp']));
			$dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_job_post')." WHERE sid='$sid'"); 
            DB::query("UPDATE " . DB::table('plugin_xlwsq_job_item') . " SET `dpcount` = '$dpcount' WHERE `id` = '$sid'");
            $systemmessage = '<a href="plugin.php?id=xlwsq_job&mod=view&sid='.$sid.'" target="_blank">'.lang('plugin/xlwsq_job', 'liuyantishi').$mythread['title']. '</a>';
			if($mythread['uid']){
				notification_add($mythread['uid'], 'system', $systemmessage, $notevars = array() , $system = 0);
			}
			if($fid!=0){
                $active = DB::fetch_first("SELECT * FROM " . DB::table('forum_post') . " WHERE tid='$tid'");
                if($active['tid']){
				    DB::query("INSERT INTO ".DB::table('forum_post')." (pid, fid, tid, first, author, authorid, dateline, message) VALUES ('$pid', '$fid', '$tid', '0', '$_G[username]', $_G[uid], '$_G[timestamp]', '$message')");
				}
			}
		}
		showmessage(lang('plugin/xlwsq_job', 'tijiaochenggong'),dreferer());
    }
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_job_post')." WHERE sid='$sid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_job_post')." WHERE sid='$sid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$pl = $pls = array();
		while($pl = DB::fetch($query)) {
			$pls[] = $pl;
		}
		$pls = dhtmlspecialchars($pls);
	}
	$multi = "<div class='pages cl'>".multi($count, $each, $page,'plugin.php?id=xlwsq_job&mod=view&sid='.$sid.'')."</div>";
    if($_GET['pinglun'] == 'del'){
	    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
        $uid = intval($_G['uid']);
	    $did = intval($_GET['did']);
        $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_job_post')." WHERE id = '$did'");
	    $pid = $pl['bbspid'];
	    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$pl['uid']==$uid||$mythread['uid']==$uid) {
            if ($_GET['formhash'] == FORMHASH) {
                DB::query("DELETE a,b FROM " . DB::table('plugin_xlwsq_job_post') . " AS a LEFT JOIN " . DB::table('forum_post') . " AS b ON a.bbspid = b.pid WHERE a.bbspid = '$pid' ");
				$dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_job_post')." WHERE sid='$sid'"); 
                DB::query("UPDATE " . DB::table('plugin_xlwsq_job_item') . " SET `dpcount` = '$dpcount' WHERE `id` = '$sid'");
	            showmessage(lang('plugin/xlwsq_job', 'shanchuok'), dreferer());
            }
	    }else{
	        showmessage(lang('plugin/xlwsq_job', 'wuquanxiancaozuo'));
        }
    }
    $navtitle = $mythread['title'] . " - " . $title;
	$metakeywords = $mythread['title'];
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($mythread['info']) , 80, '...'));
    include template('xlwsq_job:view');
} elseif ($_GET['mod'] == 'chongzhi') {
    $refererurl = $_SERVER["HTTP_REFERER"];
    if ($chongzhifanhui == '1') {
        header('Location: ' . $chongzhiurl);
    } else{
	    include template('xlwsq_job:chongzhi');
    }
} elseif ($_GET['mod'] == 'miaoshen') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditd == '0'||!$paytype){
		showmessage(lang('plugin/xlwsq_job', 'miaoshenweikaiqi'));
	}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid'");
    if($item['display']=="1"){
		showmessage(lang('plugin/xlwsq_job', 'miaoshentongguo'), array(), array('alert' => 'error'));
	}
    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubmiaoshen')){
        if($paymoney<$creditd){
            $tixing= lang('plugin/xlwsq_job', 'miaoshenshibai').$creditd.$moneytype;
        	showmessage(lang('plugin/xlwsq_job', $tixing));
        }else{
		    DB::query("UPDATE ".DB::table('plugin_xlwsq_job_item')." SET `display` = '1' WHERE `id` = '$sid'");
			updatemembercount($_G['uid'], array($paytype => -$creditd));
			DB::insert('plugin_xlwsq_job_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'pay' => $creditd,'moneytype' => $moneytype,'xftype' => '4','dateline' =>$_G['timestamp']));
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_job&mod=view&sid='.$item[id].'" target="_blank">'.lang('plugin/xlwsq_job', 'miaoshenweisend').$item[title].'</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
		    if($_G['mobile']) {
                showmessage(lang('plugin/xlwsq_job', 'tijiaochenggong') , 'plugin.php?id=xlwsq_job:xlwsq_job_user&amp;p=mylist', array() , array('alert' => 'right'));
		   	} else {
                showmessage(lang('plugin/xlwsq_job', 'tijiaochenggong'),dreferer());
		    }
        }
	}
	include template('xlwsq_job:miaoshen');
} elseif ($_GET['mod'] == 'zhiding') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditc == '0'||!$paytype){showmessage(lang('plugin/xlwsq_job', 'zhidinggongnengweikaifang'));}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid'");
    if($item['top']=="1"){
		showmessage(lang('plugin/xlwsq_job', 'yizhiding'), array(), array('alert' => 'error'));
	}
    $color = dhtmlspecialchars($_GET['topcolor']);
	$daytime = intval($_GET['day']);
	$time = ($daytime * 86400)+$_G['timestamp']; 
    $newcreditc = $daytime * $creditc; 
    $moneytypec = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubzhiding')){
	    if($_GET['day']<="0"){	
		    showmessage(lang('plugin/xlwsq_job', 'zhidingtianshuweitianxie'), dreferer());
	    }else{
            if($paymoney<$newcreditc){
                $tixing= lang('plugin/xlwsq_job', 'zhidingxiaohaotishi').$newcreditc.$moneytypec;
        	    showmessage(lang('plugin/xlwsq_job', $tixing));
            }else{
                DB::insert('plugin_xlwsq_job_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'day' => $daytime,'pay' => $newcreditc,'moneytype' => $moneytypec,'endtime' => $time,'xftype' => '2','dateline' =>$_G['timestamp']));
			    DB::query("UPDATE ".DB::table('plugin_xlwsq_job_item')." SET `topdateline` = '$time' , `color` = '$color' WHERE `id` = '$sid'");	                   updatemembercount($_G['uid'], array($paytype => -$newcreditc));
            }
			showmessage(lang('plugin/xlwsq_job', 'tijiaochenggong'),dreferer());
        }
	}
	include template('xlwsq_job:zhiding');
} elseif ($_GET['mod'] == 'yingpin') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    require_once libfile('function/mail');  
    include_once 'source/plugin/xlwsq_job/class/upic.class.php';
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid'");
    $yingpin = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_yingpin') . " WHERE sid = '$sid' AND uid = '$uid'");
    $myresume = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_myresume') . " WHERE uid = '$uid'");
    if ($yingpin) {
		if($_G['mobile']) {
            showmessage(lang('plugin/xlwsq_job', 'touguole'),dreferer());
		} else {
            showmessage(lang('plugin/xlwsq_job', 'touguole') , '', array() , array('alert' => 'error'));
		}
    }
	$moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
    if (submitcheck('applytoudi')) {
        $lianxiren = dhtmlspecialchars($_GET['lianxiren']);
        $sex = dhtmlspecialchars($_GET['sex']);
        $age = intval($_GET['age']);
        $xueli = dhtmlspecialchars($_GET['xueli']);
        $jingyan = dhtmlspecialchars($_GET['jingyan']);
        $myresumeinfo = dhtmlspecialchars($_GET['myresume']);
        if (!$myresumeinfo) {showmessage(lang('plugin/xlwsq_job', 'yingpinmeiyoujianli'),dreferer());}
        $pic = dhtmlspecialchars($_GET['pic']);
        $tel = dhtmlspecialchars($_GET['tel']);
        $qq = dhtmlspecialchars($_GET['qq']);
        $email = dhtmlspecialchars($_GET['email']);
            if($paytype && $paymoney<$credite){
                $tixing= lang('plugin/xlwsq_job', 'xiaohaotishi').$credite.$moneytype;
        	    showmessage(lang('plugin/xlwsq_job', $tixing));
            }else{
                DB::insert('plugin_xlwsq_job_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $info['title'],'pay' => $credite,'moneytype' => $moneytype,'xftype' => '5','dateline' =>$_G['timestamp']));
				updatemembercount($_G['uid'], array($paytype => -$credite));
            }
            if ($_FILES['file']['error'] == 0) {
				$picsize = $_FILES['file']['size'];
				$imageinfo = getimagesize($_FILES['file']['tmp_name']);
				if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_job', 'tupiangeshibuzhengque'));
			    }
                $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                $arr = explode(".", $_FILES["file"]["name"]);
                $hz = $arr[count($arr) - 1];
                if (!in_array($hz, $filetype)) {
                    showmessage(lang('plugin/xlwsq_job', 'tupiangeshibuzhengque'));
                }
                $filepath = "source/plugin/xlwsq_job/upimg/" . date("Ymd") . "/";
                $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
                if (!file_exists($filepath)) {
                    mkdir($filepath);
                }
				if ($picsize < 2097152) {
                    if (@copy($_FILES['file']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath . $randname))) {
                        @unlink($_FILES['file']['tmp_name']);
                    }
                }else{
				    showmessage(lang('plugin/xlwsq_job', 'chaochudaxiao'));	
				}
                $pic = "source/plugin/xlwsq_job/upimg/" . date("Ymd") . "/" . $randname . "";
                $resizeimage = new myThumbClass($pic,$imageinfo[0],$imageinfo[1],$pic,0,0); 
            }
            DB::insert('plugin_xlwsq_job_yingpin', array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'lianxiren' => $lianxiren,'sex' => $sex,'age' => $age,'pic' => $pic,'title' => $info['title'],'zhiwei' => $info['zhiwei'],'comname' => $info['comname'],'xueli' => $xueli,'jingyan' => $jingyan,'myresume' => $myresumeinfo,'zhuangtai' => '0','tel' => $tel,'qq' => $qq,'email' => $email,'dateline' => $_G['timestamp']));
            if(!$myresume){
                DB::insert('plugin_xlwsq_job_myresume', array('id' => '','uid' => $uid,'author' => $_G['username'],'pic' => $pic,'lianxiren' => $lianxiren,'sex' => $sex,'age' => $age,'xueli' => $xueli,'jingyan' => $jingyan,'userinfo' => $myresumeinfo,'tel' => $tel,'qq' => $qq,'email' => $email));
            }
			$jlcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_job_yingpin')." WHERE sid='$sid'"); 
            DB::query("UPDATE " . DB::table('plugin_xlwsq_job_item') . " SET `jlcount` = '$jlcount' WHERE `id` = '$sid'");
			if($info['uid']){
                $message = '<a href="plugin.php?id=xlwsq_job&mod=view&mod=yingpinlist&sid='.$info[id].'" target="_blank">'.lang('plugin/xlwsq_job', 'yingpintishi').$lianxiren.lang('plugin/xlwsq_job', 'yingpintishi1').$info['title']. '</a>';
                $emailsendtitle = lang('plugin/xlwsq_job', 'yingpintishi').$lianxiren.lang('plugin/xlwsq_job', 'yingpintishi1').$info['title'];
                $emailsendinfo = '<br><br><br><a href="'.$_G['siteurl'].'plugin.php?id=xlwsq_job" target="_blank">'.lang('plugin/xlwsq_job', 'emaillaizi').$plywebname.lang('plugin/xlwsq_job', 'emailwuhuifu').'</a>';
                sendmail($info['email'],$emailsendtitle,$emailsendinfo,$from = '');
	            notification_add($info['uid'], 'system', $message, $notevars = array() , $system = 0);
			}
            showmessage(lang('plugin/xlwsq_job', 'tijiaochenggong') , 'plugin.php?id=xlwsq_job&mod=view&mod=view&sid='.$sid, array() , array('alert' => 'right'));
    }
	include template('xlwsq_job:yingpin');
} elseif ($_GET['mod'] == 'viewyingpin') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid'");
    $tuid = intval($_GET['tuid']);
    $myresume = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_yingpin') . " WHERE sid = '$sid' AND uid = '$tuid'");
	include template('xlwsq_job:yingpin');
} elseif ($_GET['mod'] == 'dafu') {
    require_once libfile('function/mail');  
    $sid = intval($_GET['sid']);
    $tuid = intval($_GET['tuid']);
    $zhuangtai = intval($_GET['zhuangtai']);
    $liyou = dhtmlspecialchars($_GET['liyou']);
    $email = dhtmlspecialchars($_GET['email']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid' AND uid = '$_G[uid]'");
	!$mythread ? showmessage(lang('plugin/xlwsq_job', 'caozuocuowu') , "plugin.php?id=xlwsq_job") : '';
    if (submitcheck('applytoudi')) {
        DB::query("UPDATE " . DB::table('plugin_xlwsq_job_yingpin') . " SET `liyou` = '$liyou' , `zhuangtai` = '$zhuangtai' WHERE sid = '$sid' AND uid = '$tuid' ");
        $message = '<a href="plugin.php?id=xlwsq_job&#58;xlwsq_job_user&p=myyingpin'.'" target="_blank">'.lang('plugin/xlwsq_job', 'yingpintishi2').$liyou.'</a>';
        $emailsendtitle = $mythread['comname'].lang('plugin/xlwsq_job', 'emaildafu').$liyou;
        $emailsendinfo = '<br><br><br><a href="'.$_G['siteurl'].'plugin.php?id=xlwsq_job" target="_blank">'.lang('plugin/xlwsq_job', 'emaillaizi').$plywebname.lang('plugin/xlwsq_job', 'emailwuhuifu').'</a>';
        sendmail($email,$emailsendtitle,$emailsendinfo,$from = '');
        notification_add($tuid, 'system', $message, $notevars = array() , $system = 0);
        showmessage(lang('plugin/xlwsq_job', 'tijiaochenggong') , 'plugin.php?id=xlwsq_job&mod=view&mod=yingpinlist&sid='.$sid, array() , array('alert' => 'right'));
    }
	include template('xlwsq_job:yingpin');
}elseif($_GET['mod'] =='yingpinlist'){
	$sid = intval($_GET['sid']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id='$sid'");
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_job_yingpin')." WHERE sid='$sid'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
       $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_job_yingpin')." WHERE sid='$sid' ORDER BY zhuangtai ASC ,id DESC LIMIT $starts,20");
	   $yingpinlist = $yingpinlists = array();
	     while($yingpinlist = DB::fetch($query)){
		   $yingpinlists[] = $yingpinlist;
	     }
    }
	$multis = "<div class='pages cl' style='margin-top:10px'>".multi($counts, 20, $pages, 'plugin.php?id=xlwsq_job&mod=yingpinlist')."</div>";
    include template('xlwsq_job:yingpinlist');
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
        $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid'");
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_job_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_job', 'quxiaoshoucang'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_job', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
			}
        } else {
            DB::insert('plugin_xlwsq_job_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'title' => $info['title'],'zhiwei' => $info['zhiwei'],'dateline' => $_G['timestamp']));
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_job', 'shoucangchenggong'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_job', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
			}
        }
    }
} elseif ($_GET['mod'] == 'freshen') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $now = date('Y-m-d', $_G['timestamp']);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid'");
    $uid = intval($info['uid']);
    $updateline = date('Y-m-d', $info['updateline']);
    if ($_GET['formhash'] == FORMHASH) {
        if ($info['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
            if ($now == $updateline) {
                showmessage(lang('plugin/xlwsq_job', 'shuaxinshibai') , '', array() , array('alert' => 'error'));
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_job_item') . " SET `updateline` = '$_G[timestamp]' WHERE `id` = '$sid'");
                DB::insert('plugin_xlwsq_job_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $info['title'],'xftype' => '3','dateline' =>$_G['timestamp']));
                showmessage(lang('plugin/xlwsq_job', 'shuaxinok') , '', array() , array('alert' => 'right'));
            }
        } else {
            showmessage(lang('plugin/xlwsq_job', 'caozuocuowu') , dreferer());
        }
    }
}elseif($_GET['mod']=='renling'||$_GET['mod']=='youkedel'){
   if($_GET['mod']=='renling'){!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';}
   $sid = intval($_GET['sid']);
   $password = dhtmlspecialchars($_GET['password']);
   $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_job_item') . " WHERE id = '$sid'");
   !$info ? showmessage(lang('plugin/xlwsq_job', 'error') , "plugin.php?id=xlwsq_job") : '';
   if(submitcheck('applysubrenling')){
       if($password == $info['password']){
          DB::update('plugin_xlwsq_job_item', array('password' => '','uid' => $_G['uid'],'author' => $_G['username']),"id='$sid'");
          showmessage(lang('plugin/xlwsq_job', 'renlingchenggong'), 'plugin.php?id=xlwsq_job', array(), array('alert' => 'right'));
       }else{
          showmessage(lang('plugin/xlwsq_job', 'koulingcuowu'));
       }
   }    
   include template('xlwsq_job:kouling');
}elseif($_GET['mod']=='qrpic'){
    include_once 'source/plugin/xlwsq_job/class/qrcode.class.php';
	$sid = intval($_GET['sid']);
	  if($html == 1){
         $value=$_G['siteurl'].$mininame.'_'.$sid.'.html';
      }else{
         $value=$_G['siteurl'].'plugin.php?id=xlwsq_job&mod=view&sid='.$sid;
      }
    QRcode::png($value, false,L,6);
}
function setUnit($nprice) {
    if($nprice >= 10000){
        $showMoeny = (int)($nprice/100);
        return ($showMoeny/100).lang('plugin/xlwsq_job', 'wan');
    }else{
        return  $nprice;
    }
}
//From: d'.'is'.'m.ta'.'obao.com
?>