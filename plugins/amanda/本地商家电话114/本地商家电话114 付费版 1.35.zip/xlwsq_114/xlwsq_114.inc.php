<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/xlwsq_114/function/function_core.php';
global $_G;
if (!isset($_G['cache']['plugin'])) {
	loadcache('plugin');
}
$plyes=($_G['cache']['plugin']['xlwsq_114']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
if($_G['mobile']) {
    $menubgcolor=$mobilemenubgcolor;
    $eacha=$mobileeacha ? $mobileeacha : $eacha;
    $footad=$mobilefootad ? $mobilefootad : $footad;
}
$defaultpic = $defaultpic ? $defaultpic : 'source/plugin/xlwsq_114/images/nopic.jpg';
$mainwidth = intval($mainwidth);
$fabuset = unserialize($groups);
$viewgroups = unserialize($viewgroups);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$navtitle = $title;
$creditc = abs($creditc);
$creditd = abs($creditd);
$_G['uid'] = $_G['uid'] ? $_G['uid'] : '0';
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if (!in_array($_G['groupid'], $viewgroups) && $_G['groupid'] != "1" && !in_array($_G['uid'], $admins)) {
    showmessage(lang('plugin/xlwsq_114', 'wuquanxianfangwen') , '', array() , array('login' => true));
}
if($mod == 'index') {
    $where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    $keytype = intval($_GET['keytype']);
    if($key){
	    if($keytype==1){ 
		   $where="zhuying LIKE '%".addcslashes(addslashes($key), '%_')."%' AND display!='0' AND ";
	    }elseif($keytype==2){ 
		   $where="address LIKE '%".addcslashes(addslashes($key), '%_')."%' AND display!='0' AND ";
	    }else{ 
		   $where="title LIKE '%".addcslashes(addslashes($key), '%_')."%' AND display!='0' AND ";
		}
	$keync=urlencode($key);
	$pageadd="&keytype=$keytype&key=$keync";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$cate_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
    }
    $sd = intval($_GET['b']);
    if ($sd) {
        $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$sd'");
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
    }
    $area_id = intval($_GET['bc']);
    if ($area_id) {
        $marea = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE id = '$area_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE id='$area_id'");
        if ($subids) {
            $b_area = "area IN ($area_id,$subids) AND";
        } else {
            $b_area = "area=$area_id AND";
        }
        $pageaddbc = "&bc=$area_id";
    }
    $s_area_id = intval($_GET['sc']);
    if ($s_area_id) {
        $mareab = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE id = '$s_area_id'");
        $s_area = "area='$s_area_id' AND";
        $pageaddsc = "&sc=$s_area_id";
    }
    if ($_GET['paixu']=='tj') {
		$px="tuijian = '1' AND display ='1'  ORDER BY top DESC,diynum DESC,dateline DESC"; $pageadd="&paixu=tj";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE $where $wb $wc $b_area $s_area  tuijian = '1' AND display ='1' ");
	}elseif ($_GET['paixu']=='rq') {
		$px="display ='1' ORDER BY view DESC,dateline DESC"; $pageadd="&paixu=rq";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE $where $wb $wc $b_area $s_area  display ='1'");
	}else{
		$px="display ='1' ORDER BY top DESC,topdateline DESC,diynum DESC,updateline DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE $where $wb $wc $b_area $s_area  display ='1'");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE $where $wb $wc $b_area $s_area $px LIMIT $starts,$eacha");
        $mythread = $mythreads = array();
        while ($mythread = DB::fetch($query)) {
            if ($mythread['topdateline']!='0'){DB::query("UPDATE ".DB::table('plugin_xlwsq_114_item')." SET `topdateline` = '0',`color` = '' WHERE topdateline!= '0' AND  topdateline <= ".$_G['timestamp']);}
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$cate[upid]'");
                $mythread['catecid'] = $cate['upid'];
                $mythread['catescid'] = $mythread['cate'];
                $mythread['catename'] = $cate['subject'];
            } else {
                $mythread['catecid'] = $mythread['cate'];
                $mythread['catescid'] ='0';
                $mythread['catename'] = $cate['subject'];
            }
            $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE id = '$mythread[area]'");
            if ($area['upid'] != 0) {
                $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE id = '$area[upid]'");
                $mythread['areacid'] = $area['upid'];
                $mythread['areascid'] = $mythread['area'];
                $mythread['areaname'] = $area['subject'];
            } else {
                $mythread['areacid'] = $mythread['area'];
                $mythread['areascid'] ='0';
                $mythread['areaname'] = $area['subject'];
            }
                $mythreads[] = $mythread;
        }
    }
    $multis =multi($counts, $eacha, $pages, 'plugin.php?id=xlwsq_114' . $pageadd. $pageadds . $pageaddx . $pageaddbc . $pageaddsc);
    $r_id = intval($_GET['a']);
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    $bc_id = intval($_GET['bc']);
    $bc_subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE id='$bc_id'");
    if ($bc_subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE id IN ($bc_subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $local_sc[$ros['id']] = $ros;
        }
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_114_banner')." WHERE display!='0' ORDER BY diynum DESC,id DESC");
	while($banner = DB::fetch($query)){
		$banners[] = $banner;
	}
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . "-" . $mcateb['subject']. "-";
      } else {
           $catenav = $mcate['subject']. "-";
      }
    }
    if ($area_id!='0') {
      if ($s_area_id!='0') {
           $areanav = $marea['subject'] . "-" . $mareab['subject']. "-";
      } else {
           $areanav = $marea['subject']. "-";
      }
    }
    $navtitle = $catenav . $areanav.$title;
    include template('xlwsq_114:list');
} elseif ($_GET['mod'] == 'view') {
    $sid = intval($_GET['sid']);
    if($_G['groupid']==1 || in_array($_G['uid'], $admins)){
	   $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE id = '$sid'");
	}else{
	   $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_114_item')." WHERE id = '$sid' AND display!='0'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_114', 'error') , "plugin.php?id=xlwsq_114") : '';
    DB::query("UPDATE " . DB::table('plugin_xlwsq_114_item') . " SET `view` = view+1 WHERE `id` = '$sid'");
    $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_favorites') . " WHERE sid = '$sid' AND uid = '$_G[uid]'");
    $mythread['dinfo'] = discuzcode($mythread['info']);
	$dituzuobiao = explode(",",$mythread['zuobiao']);
	$mythread['lat'] = $dituzuobiao[0];
	$mythread['lng'] = $dituzuobiao[1];
    if (!preg_match('/(http:\/\/)|(https:\/\/)/i', $mythread['weburl'])) {
      $mythread['weburl'] = "http://" . $mythread['weburl'];
    }
    $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$mythread[cate]'");
	if ($cate['upid'] != 0) {
        $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$cate[upid]'");
        $mythread['cate'] = $cate_t['subject'] . " - " . $cate['subject'];
    } else {
        $mythread['cate'] = $cate['subject'];
    }
    $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE id = '$mythread[area]'");
    if ($area['upid'] != 0) {
        $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE id = '$area[upid]'");
        $mythread['area'] = $area_t['subject'] . " - " . $area['subject'];
    } else {
        $mythread['area'] = $area['subject'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY updateline DESC,dateline DESC LIMIT $tjnum");
	$tuijian = $tuijians = array();
    while ($tuijian = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$tuijian[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$cate[upid]'");
            $tuijian['cate'] = $cate['subject'];
        } else {
            $tuijian['cate'] = $cate['subject'];
        }
        $tuijians[] = $tuijian;
    }

    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE view >'0' AND display!='0' ORDER BY view DESC LIMIT $hotnum");
    $hot = $hots = array();
    while ($hot = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$hot[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE id = '$cate[upid]'");
            $hot['cate'] = $cate['subject'];
        } else {
            $hot['cate'] = $cate['subject'];
        }
        $hots[] = $hot;
    }
    if(submitcheck('applysubmit')){	
	   $uid = intval($_G['uid']);
	   if($youkepinglunset==1){
        !$_G['uid'] ? $_G['username'] = $_G['clientip'] :'';
       }else{
	        if(!$_G['uid']){
			   showmessage(lang('plugin/xlwsq_114', 'youkewuquanxianpinglun'), dreferer());
	        }
       }
	   if(empty($_GET['message'])){
			   showmessage(lang('plugin/xlwsq_114', 'wupinglunneirong'), dreferer());
	   }else{
			        $author = $_G['username'];
		        	$message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
					$display = 1; 
                    $pid = DB::insert('forum_post_tableid', array('pid'=>NULL), true);
                    $fid = $bbsfid;
					$tid = $mythread['bbstid'];
					DB::insert('plugin_xlwsq_114_post',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $author,'message' => $message,'bbspid' => $pid,'display' => $display,'dateline' => $_G['timestamp']));
					$dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_114_post')." WHERE sid='$sid'"); 
                    DB::query("UPDATE " . DB::table('plugin_xlwsq_114_item') . " SET `dpcount` = '$dpcount' WHERE `id` = '$sid'");
                    $systemmessage = '<a href="plugin.php?id=xlwsq_114&mod=view&sid='.$sid.'" target="_blank">'.lang('plugin/xlwsq_114', 'liuyantishi').$mythread['title']. '</a>';
					if($mythread['uid']){
					   notification_add($mythread['uid'], 'system', $systemmessage, $notevars = array() , $system = 0);
					}
					if($fid!=0){
                       $active = DB::fetch_first("SELECT * FROM " . DB::table('forum_post') . " WHERE tid='$tid'");
                       if($active['tid']){
						   DB::query("INSERT INTO ".DB::table('forum_post')." (pid, fid, tid, first, author, authorid, dateline, message) VALUES ('$pid', '$fid', '$tid', '0', '$_G[username]', $_G[uid], '$_G[timestamp]', '$message')");
					   }
					}
		}
					showmessage(lang('plugin/xlwsq_114', 'tijiaochenggong'),dreferer());
    }
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_114_post')." WHERE sid='$sid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_114_post')." WHERE sid='$sid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$pl = $pls = array();
		while($pl = DB::fetch($query)) {
			$pls[] = $pl;
		}
			$pls = dhtmlspecialchars($pls);
	}
	$multi = "<div class='pages cl'>".multi($count, $each, $page,'plugin.php?id=xlwsq_114&mod=view&sid='.$sid.'')."</div>";
    if($_GET['pinglun'] == 'del'){
	    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
        $uid = intval($_G['uid']);
	    $did = intval($_GET['did']);
        $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_114_post')." where id = '$did'");
		$pid = $pl['bbspid'];
	    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$pl['uid']==$uid||$mythread['uid']==$uid) {
            if ($_GET['formhash'] == FORMHASH) {
                DB::query("DELETE a,b FROM " . DB::table('plugin_xlwsq_114_post') . " AS a LEFT JOIN " . DB::table('forum_post') . " AS b ON a.bbspid = b.pid WHERE a.bbspid = '$pid' ");
				$dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_114_post')." WHERE sid='$sid'"); 
                DB::query("UPDATE " . DB::table('plugin_xlwsq_114_item') . " SET `dpcount` = '$dpcount' WHERE `id` = '$sid'");
	            showmessage(lang('plugin/xlwsq_114', 'shanchuok'), dreferer());
            }
	    }else{
		    showmessage(lang('plugin/xlwsq_114', 'wuquanxiancaozuo'),dreferer());
        }
    }
    $navtitle = $mythread['title'] . " - " . $title;
	$metakeywords = $mythread['title'];
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($mythread['dinfo']) , 80, '...'));
    include template('xlwsq_114:view');
} elseif ($_GET['mod'] == 'zhiding') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditc == '0'||!$paytype){showmessage(lang('plugin/xlwsq_114', 'zhidinggongnengweikaifang'));}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE id = '$sid'");
    if($item['top']=="1"){
		showmessage(lang('plugin/xlwsq_114', 'yizhiding'), array(), array('alert' => 'error'));
	}
    $color = dhtmlspecialchars($_GET['topcolor']);
	$daytime = intval($_GET['day']);
	$time = ($daytime * 86400)+$_G['timestamp']; 
    $newcreditc = $daytime * $creditc; 
    $moneytypec = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubzhiding')){
	    if($_GET['day']<="0"){	
		    showmessage(lang('plugin/xlwsq_114', 'zhidingtianshuweitianxie'), dreferer());
	    }else{
            if($paymoney<$newcreditc){
                $tixing= lang('plugin/xlwsq_114', 'zhidingxiaohaotishi').$newcreditc.$moneytypec;
        	    showmessage(lang('plugin/xlwsq_114', $tixing));
            }else{
                DB::insert('plugin_xlwsq_114_xfjl',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'day' => $daytime,'pay' => $newcreditc,'moneytype' => $moneytypec,'xftype' => '2','endtime' => $time,'dateline' =>$_G['timestamp']));
				DB::query("UPDATE ".DB::table('plugin_xlwsq_114_item')." SET `topdateline` = '$time' , `color` = '$color' WHERE `id` = '$sid'");	                   updatemembercount($_G['uid'], array($paytype => -$newcreditc));
            }
				showmessage(lang('plugin/xlwsq_114', 'tijiaochenggong'),dreferer());
	    }
	}
	include template('xlwsq_114:zhiding');
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
        $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE id = '$sid'");
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_114_favorites') . " WHERE sid = '$sid' and uid = '$uid'");
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_114', 'quxiaoshoucang'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_114', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
			}
        } else {
            DB::insert('plugin_xlwsq_114_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'title' => $info['title'],'dateline' => $_G['timestamp']));
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_114', 'shoucangchenggong'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_114', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
			}
        }
    }
} elseif ($_GET['mod'] == 'report') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE id = '$sid'");
	if(submitcheck('addreport')){
        $url = 'plugin.php?id=xlwsq_114&mod=view&sid='.$sid;
		$urlkey = md5($url);
    	$message =cutstr(dhtmlspecialchars(trim($_GET['message'])), 300, '');
	if($reportid = C::t('common_report')->fetch_by_urlkey($urlkey)) {
		C::t('common_report')->update_num($reportid, $message);
	}else {
		DB::insert('common_report',array('id' => '','urlkey' => $urlkey,'url' => $url,'message' => $message,'uid' => $_G['uid'],'username' =>$_G[username],'num' => '1', 'dateline' => $_G['timestamp']));
	}
        for ($i = 0; $i < count($admins); $i++) {
            notification_add($admins[$i], 'report', 'new_report', array('from_id' => 1, 'from_idtype' => 'newreport'), 1);
        }
        showmessage(lang('plugin/xlwsq_114', 'tijiaochenggong') , 'plugin.php?id=xlwsq_114&mod=view&sid='.$sid, array() , array('alert' => 'right'));
	 }
    include template('xlwsq_114:report');
} elseif ($_GET['mod'] == 'freshen') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $now = date('Y-m-d', $_G['timestamp']);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE id = '$sid'");
    $uid = intval($info['uid']);
    $updateline = date('Y-m-d', $info['updateline']);
    if ($_GET['formhash'] == FORMHASH) {
        if ($info['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
            if ($now == $updateline) {
                showmessage(lang('plugin/xlwsq_114', 'shuaxinshibai') , '', array() , array('alert' => 'error'));
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_114_item') . " SET `updateline` = '$_G[timestamp]' WHERE `id` = '$sid'");
                DB::insert('plugin_xlwsq_114_xfjl',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'xftype' => '3','title' => $info['title'],'dateline' =>$_G['timestamp']));
                showmessage(lang('plugin/xlwsq_114', 'shuaxinok') , '', array() , array('alert' => 'right'));
            }
        } else {
            showmessage(lang('plugin/xlwsq_114', 'caozuocuowu') , dreferer());
        }
    }
}elseif($_GET['mod']=='renling'||$_GET['mod']=='youkedel'){
   if($_GET['mod']=='renling'){!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';}
   $sid = intval($_GET['sid']);
   $password = dhtmlspecialchars($_GET['password']);
   $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE id = '$sid'");
   !$info ? showmessage(lang('plugin/xlwsq_114', 'error') , "plugin.php?id=xlwsq_114") : '';
   if(submitcheck('applysubrenling')){
       if($password == $info['password']){
           DB::update('plugin_xlwsq_114_item', array('password' => '','uid' => $_G['uid'],'author' => $_G['username']),"id='$sid'");
           showmessage(lang('plugin/xlwsq_114', 'renlingchenggong'), 'plugin.php?id=xlwsq_114&mod=view&sid='.$sid, array(), array('alert' => 'right'));
       }else{
           showmessage(lang('plugin/xlwsq_114', 'koulingcuowu'));
       }
   }    
   include template('xlwsq_114:kouling');
}elseif($_GET['mod']=='qrpic'){
    include_once 'source/plugin/xlwsq_114/class/qrcode.class.php';
	$sid = intval($_GET['sid']);
	  if($html == 1){
          $value=$_G['siteurl'].$mininame.'_'.$sid.'.html';
      }else{
          $value=$_G['siteurl'].'plugin.php?id=xlwsq_114&mod=view&sid='.$sid;
      }
    QRcode::png($value, false,L,6);
}
//From: Dism��taobao��com
?>