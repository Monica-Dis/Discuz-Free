<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/discuzcode');
global $_G;
if (!isset($_G['cache']['plugin'])) {loadcache('plugin');}
$plyes=($_G['cache']['plugin']['xlwsq_114']);
$menubgcolor=$plyes['menubgcolor'];
!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';
if($_GET['option'] == 'reply'){
		$id = intval($_GET['did']);
		$sid = intval($_GET['sid']);
        $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_post') . " WHERE id = '$id'");
		$pl['message'] = discuzcode($pl['message']);
        $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_114_item') . " WHERE id = '$sid'");
		if($item['uid']==$_G['uid']||$_G['groupid']=="1"){}
           else{
		      showmessage(lang('plugin/xlwsq_114', 'caozuocuowu'), '', array(), array('login' => true));
     	}
		if(submitcheck('applysubreply')){
		        $reply = strip_tags(addslashes($_GET['reply']),"<b><p><i><s>");
					DB::update('plugin_xlwsq_114_post', array('reply' => $reply), "id='$id'");
					$pid = $pl['bbspid'];
					if(!empty($reply)){
                       $bbsmessage =$pl['message'].'[hr][size=2][color=#ff0000]'.lang('plugin/xlwsq_114', 'louzhuhuifu').'[/color][color=#1E90FF]'.$reply.'[/color][/size]';
					}else{
					   $bbsmessage =$pl['message'];
					}
                    DB::query("UPDATE ".DB::table('forum_post')." SET  message='$bbsmessage' where pid='$pid'");
					   if($_G['mobile']) {
                          showmessage(lang('plugin/xlwsq_114', 'tijiaochenggong'), 'plugin.php?id=xlwsq_114&mod=view&sid='.$item['id']);
					   } else {
                          showmessage(lang('plugin/xlwsq_114', 'tijiaochenggong'),dreferer());
					   }
		}
		include template('xlwsq_114:reply');
}
//From: Dism��taobao��com
?>