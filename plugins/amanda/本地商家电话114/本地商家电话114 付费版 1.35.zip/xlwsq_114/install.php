<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_114_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `author` varchar(80) NOT NULL,
	  `cate` int(11) NOT NULL,
	  `area` int(11) NOT NULL,
	  `title` varchar(80) NOT NULL,
   	  `pic` varchar(255) NOT NULL,
   	  `zhuying` varchar(255) NOT NULL,
   	  `yingyeshijian` varchar(255) NOT NULL,
	  `info` text NOT NULL,
	  `address` text NOT NULL,
	  `weburl` text NOT NULL,
      `zuobiao` varchar(40) NOT NULL,
   	  `lianxiren` varchar(50) NOT NULL,
   	  `tel`  varchar(20) NOT NULL,
   	  `tel2`  varchar(20) NOT NULL,
   	  `tel3`  varchar(20) NOT NULL,
   	  `qq`  varchar(20) NOT NULL,
   	  `weixin`  varchar(60) NOT NULL,
   	  `qita`  varchar(100) NOT NULL,
	  `view` int(11) NOT NULL,
	  `top` tinyint(1)  NOT NULL,
	  `tuijian` tinyint(1)  NOT NULL,
	  `topdateline` int(11) NOT NULL,
	  `color` text NOT NULL,
	  `dpcount` int(11) NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `updateline` int(11) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  `bbstid` int(11) NOT NULL,
   	  `password` varchar(50) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_114_cate` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_114_area` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_114_xfjl` (
	  `id` int(11) NOT NULL auto_increment,
      `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `title` varchar(255) NOT NULL,
   	  `day` int(11) NOT NULL,
   	  `pay` int(11) NOT NULL,
   	  `moneytype` varchar(20) NOT NULL,
   	  `endtime` int(11) NOT NULL,
   	  `xftype` tinyint(1) NOT NULL,
   	  `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_114_favorites` (
   	  `id` int(11) NOT NULL auto_increment,
 	  `sid` int(11) NOT NULL,
   	  `title`varchar(100) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_114_banner` (
	  `id` int(11) NOT NULL auto_increment,
	  `title` varchar(255) NOT NULL,
	  `pic` text NOT NULL,
	  `info` varchar(255) NOT NULL,
	  `url` varchar(255) NOT NULL,
	  `diynum` int(11) NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_114_post` (
	  `id` int(11) NOT NULL auto_increment,
	  `sid` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
  	  `author` varchar(50) NOT NULL,
  	  `message` text NOT NULL,
  	  `reply` text NOT NULL,
	  `bbspid` int(11) NOT NULL,
  	  `display` tinyint(4) NOT NULL,
 	  `dateline` int(10) NOT NULL,
      PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;
INSERT INTO `pre_plugin_xlwsq_114_cate` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '', '$installlang[cate1]', 0),
(2, 0, '', '$installlang[cate2]', 0),
(3, 0, '', '$installlang[cate3]', 0),
(4, 0, '', '$installlang[cate4]', 0),
(5, 0, '', '$installlang[cate5]', 0),
(6, 0, '', '$installlang[cate6]', 0),
(7, 0, '', '$installlang[cate7]', 0),
(8, 0, '', '$installlang[cate8]', 0),
(9, 0, '', '$installlang[cate9]', 0),
(10, 0, '', '$installlang[cate10]', 0);
INSERT INTO `pre_plugin_xlwsq_114_area` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '', '$installlang[area1]', 0);
INSERT INTO `pre_plugin_xlwsq_114_banner` (`id`, `title`, `pic`, `info`, `url`, `diynum`, `display`, `dateline`) VALUES
(1, '', 'source/plugin/xlwsq_114/banner/1.jpg', '', 'plugin.php?id=xlwsq_114:xlwsq_114_user&amp;p=add', 0, 1, 1525403607);
EOF;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_114/discuz_plugin_xlwsq_114.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_114/discuz_plugin_xlwsq_114_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_114/discuz_plugin_xlwsq_114_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_114/discuz_plugin_xlwsq_114_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_114/discuz_plugin_xlwsq_114_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_114/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_114/install.php');
runquery($sql);
$finish =true;
?>