<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$catecachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_114_catecachedata.php';
$areacachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_114_areacachedata.php';
if(file_exists($catecachefile)){
		require_once DISCUZ_ROOT.'data/sysdata/cache_xlwsq_114_catecachedata.php';
}else{
	xlwsq_114_updatacatecache();
}
if(file_exists($areacachefile)){
		require_once DISCUZ_ROOT.'data/sysdata/cache_xlwsq_114_areacachedata.php';
}else{
	xlwsq_114_updataareacache();
}
function  xlwsq_114_updatacatecache(){
	require_once libfile('function/cache');
    $typecatequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
    $typecatedata = array();
    $upidcatedata = array();
    while ($typecate = DB::fetch($typecatequery)) {
        $typecatedata[$typecate['id']] = $typecate;
        $upidcatequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_114_cate') . " where upid = " . $typecate['id'] . "  ORDER BY displayorder DESC,id ASC");
        while ($upidcate = DB::fetch($upidcatequery)) {
            $upidcatedata[$typecate['id']][$upidcate['id']] = $upidcate;
        }
    }
	writetocache('xlwsq_114_catecachedata', getcachevars(array('typecatedata' => $typecatedata,  'upidcatedata' => $upidcatedata)));
}
function  xlwsq_114_updataareacache(){
	require_once libfile('function/cache');
    $typeareaquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_114_area') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
    $typeareadata = array();
    $upidareadata = array();
    while ($typearea = DB::fetch($typeareaquery)) {
        $typeareadata[$typearea['id']] = $typearea;
        $upidareaquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_114_area') . " where upid = " . $typearea['id'] . "  ORDER BY displayorder DESC,id ASC");
        while ($upidarea = DB::fetch($upidareaquery)) {
            $upidareadata[$typearea['id']][$upidarea['id']] = $upidarea;
        }
    }
	writetocache('xlwsq_114_areacachedata', getcachevars(array('typeareadata' => $typeareadata,  'upidareadata' => $upidareadata)));
}
//From: Dism��taobao��com
?>