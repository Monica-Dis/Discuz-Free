<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$catecachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_114_catecachedata.php';
if(file_exists($catecachefile)){@unlink($catecachefile);}
$areacachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_114_areacachedata.php';
if(file_exists($areacachefile)){@unlink($areacachefile);}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_plugin_xlwsq_114_item`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_114_cate`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_114_area`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_114_banner`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_114_xfjl`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_114_favorites`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_114_post`;
EOF;
runquery($sql);
$finish = TRUE;
?>