<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/discuzcode');
global $_G;
if (!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plyes=($_G['cache']['plugin']['xlwsq_video']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
if($_G['mobile']) {
    $eacha=$mobileeacha;
}
$admins = explode(",", $groupso);
$menucate= parconfig($category);
$appurl=$_G['siteurl']."plugin.php?id=xlwsq_video";
$fabuset= unserialize($groups);
$navtitle = $title;
$listwidth = intval($listwidth);
$mainwidth = intval($mainwidth);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$defaultpic = $defaultpic ? $defaultpic : 'source/plugin/xlwsq_video/images/nopic.jpg';
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if ($mod == 'index') {
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
		$where="title like '%".addcslashes($key, '%_')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }elseif($_GET['bozhu']){
		$key=addslashes(trim($_GET['bozhu']));
		$where="author='$key' AND";
	    $keync=urlencode($key);
	    $pageadd="&bozhu=$keync";
    }elseif($_GET['biaoqian']){
		$key=addslashes(trim($_GET['biaoqian']));
		$where="biaoqian like '%".addcslashes($key, '%_')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&biaoqian=$keync";
    }
    $cate = intval($_GET['m']);
    if ($cate){
		$sm[] = "cate = '$cate'";
		$pageaddm="&m=$cate";
		$m_hover[$cate] = ' class="on"'; 
    }
	if ($sm){ $fm ="instr(concat(',',`cate`,','),',$cate,') AND";}

    if ($_GET['paixu']=='tj') {
		$px="tuijian = '1' AND display ='1' ORDER BY diynum DESC,dateline DESC"; $pageadd="&paixu=tj";
		$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_item')." WHERE  $where $fm tuijian = '1' AND display ='1'");
    }elseif($_GET['paixu']=='view') {
		$px="view > '0' AND display ='1' ORDER BY view DESC"; $pageadd="&paixu=hot";
		$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_item')." WHERE  $where $fm view > '0' AND display ='1'");
	}else{
		$px="display ='1' ORDER BY top DESC,diynum DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_item')." WHERE  $where $fm  display ='1'");
	}

	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * $eacha;
	if($counts) { 
		$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE $where $fm $px LIMIT $starts,$eacha");
		$mythread = $mythreads = array();
		while($mythread = DB::fetch($query)){
		    $pingluncount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$mythread[id]' AND display ='1'"); 
			$mythread['pingluncount'] = $pingluncount;
			$mythreads[] = $mythread;
		}
	}
	$multis =multi($counts, $eacha, $pages, "plugin.php?id=xlwsq_video".$pageadd.$pageaddm);

	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_banner')." WHERE id ORDER BY id DESC");
	$banner = $banners = array();
	while($banner = DB::fetch($query)){
		$banners[] = $banner;
	}
    if($_GET['m']!=0){
	    $navtitle = $menucate[$cate]." - ".$title." - ".$metadescription;
      }else{
	    $navtitle = $title." - ".$metadescription;
    }
	include template('xlwsq_video:list');
}elseif($_GET['mod']=='view'||$_GET['mod']=='adminview'){
	$sid = intval($_GET['sid']);
	$uid = intval($_G['uid']);
    if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
       $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE id = '$sid' AND display!='0'");
	}else{
	   $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_video_item') . " WHERE id = '$sid'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_video', 'error'),"plugin.php?id=xlwsq_video") : '';
    if($mythread['viewgroup']!=''){
       $group = explode(",", $mythread['viewgroup']);
       if (!in_array($_G['groupid'], $group) && $_G['groupid']!=1 && !in_array($_G['uid'], $admins) && $uid!=$mythread['uid']) {
		   showmessage(lang('plugin/xlwsq_video', 'yonghuzuwuquanxianguankan'), dreferer());
	   }
    }
    DB::query("UPDATE ".DB::table('plugin_xlwsq_video_item')." SET `view` = view+1 WHERE `id` = '$sid'");
	$mythread['dinfo'] = discuzcode($mythread['info']);
    $biaoqian = explode(",",$mythread['biaoqian']);
    $mythread['videocounts']= DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_item')." WHERE uid='$mythread[uid]' AND  display!='0'");
    $dashangjilu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid = '$sid' AND uid = '$uid' AND pay!='0'");
    $category = change($mythread['cate']);

	$videotype = gontenfile(strtolower($mythread['videourl']));
    if (strpos($mythread[videourl], '</iframe>') !== FALSE) {
       $vid=stripslashes($mythread[videourl]);
       $pcvideo= "$vid";
       $mvideo= "$vid";
	}elseif (strpos($mythread['videourl'], 'player.youku.com') !== FALSE) {
	   $vid1=explode("sid/",$mythread['videourl']);
	   $vid2=explode("/v.swf",$vid1[1]);
	   $vid=$vid2[0];
       $pcvideo= "<iframe width='100%' height='550' src='//player.youku.com/embed/$vid' allowfullscreen='true' frameborder='0'></iframe>";
       $mvideo= "<iframe width='100%' height='200' src='//player.youku.com/embed/$vid'  allowfullscreen='true' frameborder='0'></iframe>";
	}elseif (strpos($mythread['videourl'], 'cloud.youku.com') !== FALSE) {
	   $vid=explode("vid=",$mythread['videourl']);
       $pcvideo= "<iframe width='100%' height='550' src='//player.youku.com/embed/$vid[1]' allowfullscreen='true' frameborder='0'></iframe>";
       $mvideo= "<iframe width='100%' height='200' src='//player.youku.com/embed/$vid[1]' allowfullscreen='true'  frameborder='0'></iframe>";
	}elseif (strpos($mythread['videourl'], 'static.video.qq.com') !== FALSE) {
       $qqurl = str_replace('static.video.qq.com/TPout.swf', 'v.qq.com/iframe/player.html', $mythread['videourl']);
       $pcvideo= "<iframe width='100%' height='550' src='$qqurl' allowfullscreen='true' frameborder='0'></iframe>";
       $mvideo= "<iframe width='100%' height='200' src='$qqurl' allowfullscreen='true' frameborder='0'></iframe>";
	}elseif (strpos($mythread['videourl'], 'imgcache.qq.com') !== FALSE) {
       $vid =explode("=",$mythread['videourl']);
	   $vid2=explode("vid=",$mythread['videourl']);
       $mvideo= "<iframe width='100%' height='200' src='//v.qq.com/iframe/player.html?vid=$vid2[1]' allowfullscreen='true' frameborder='0'></iframe>";
       $pcvideo= "<iframe width='100%' height='550' src='//v.qq.com/iframe/player.html?vid=$vid2[1]' allowfullscreen='true' frameborder='0'></iframe>";
	}elseif (strpos($mythread['videourl'], 'www.youtube.com') !== FALSE) {
       $qqurl = str_replace('www.youtube.com/watch?v=', 'www.youtube.com/embed/', $mythread['videourl']);
       $pcvideo= "<iframe width='100%' height='550' src='$qqurl' allowfullscreen='true' frameborder='0'></iframe>";
       $mvideo= "<iframe width='100%' height='200' src='$qqurl' allowfullscreen='true' frameborder='0'></iframe>";
	}elseif (strpos($mythread['videourl'], 'youtu.be') !== FALSE) {
       $qqurl = str_replace('youtu.be/', 'www.youtube.com/embed/', $mythread['videourl']);
       $pcvideo= "<iframe width='100%' height='550' src='$qqurl' allowfullscreen='true' frameborder='0'></iframe>";
       $mvideo= "<iframe width='100%' height='200' src='$qqurl' allowfullscreen='true' frameborder='0'></iframe>";
	}elseif (strpos($mythread['videourl'], 'player.video.qiyi.com') !== FALSE) {
       $vid =explode("/",$mythread['videourl']);
	   $vid2=explode("tvId=",$mythread['videourl']);
	   $vid3=explode("-isPurchase",$vid2[1]);
       $mvideo= "<iframe width='100%' height='200' src='//open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=$vid[3]&tvId=$vid3[0]' allowfullscreen='true' frameborder='0'></iframe>";
       $pcvideo= "<iframe width='100%' height='550' src='//open.iqiyi.com/developer/player_js/coopPlayerIndex.html?vid=$vid[3]&tvId=$vid3[0]' allowfullscreen='true' frameborder='0'></iframe>";
	}else{
       $mvideo= "<embed src='$mythread[videourl]' width='100%' height='200' allowFullScreen='true' type='application/x-shockwave-flash'>";
       $pcvideo= "<embed src='$mythread[videourl]' width='100%' height='550' allowFullScreen='true' type='application/x-shockwave-flash'>";
	}
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE tuijian ='1' AND display!='0' ORDER BY dateline DESC LIMIT $shuliang");
	$tuijian = $tuijians = array();
	while($tuijian = DB::fetch($query)){
		$tuijians[] = $tuijian;
	}
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE view >'1' AND display!='0' ORDER BY view DESC LIMIT $shuliang");
	$hot = $hots = array();
	while($hot = DB::fetch($query)){
		$hots[] = $hot;
	}
	if($mythread['cate']){
	 $where="cate in ($mythread[cate]) AND ";
	}
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE  $where id!='$mythread[id]' AND display!='0' ORDER BY RAND() LIMIT $shuliang"); 
	$tonglei = $tongleis = array();
	while($tonglei = DB::fetch($query)){
		$tongleis[] = $tonglei;
	}
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE uid ='$mythread[uid]' AND id!='$mythread[id]' AND display!='0' ORDER BY dateline DESC LIMIT $shuliang");
	$new = $news = array();
	while($new = DB::fetch($query)){
		$news[] = $new;
	}

	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$sid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	
	if($count) {
		$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$sid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$pl = $pls = array();
		while($pl = DB::fetch($query)) {
			$pl['message'] = discuzcode($pl['message']);
			$pl['reply'] = discuzcode($pl['reply']);
			$pls[] = $pl;
		}
			$pls = dhtmlspecialchars($pls);
	}
	$multi = "<div class='pages cl' style='margin-top:10px'>".multi($count, $each, $page,'plugin.php?id=xlwsq_video&mod=view&sid='.$sid.'')."</div>";

    if($_GET['pinglun'] == 'del'){
	    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	         $did = intval($_GET['did']);
             if($_GET['formhash'] == FORMHASH) {
                  $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_post')." where id = '$did'");
	            if($pl){
	              DB::delete('plugin_xlwsq_video_post',array('id'=> $did));
					$result = DB::query("SELECT sum(voter) AS 'voter' , sum(total) AS 'total'  FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$sid' AND display!='0' ");
					$row = DB::fetch($result);  
					$voter = intval($row['voter']);
					$total = intval($row['total']);
	                DB::update('plugin_xlwsq_video_item', array('total' => $total,'voter' => $voter),"id ='$sid'");
	              showmessage(lang('plugin/xlwsq_video', 'shanchuok'), dreferer());
	            }else{
	              showmessage(lang('plugin/xlwsq_video', 'caozuocuowu'));
                }
             }
	    }else{
	  	    showmessage(lang('plugin/xlwsq_video', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
	    }
    }
    $navtitle = $mythread['title']." - ".$title;	
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($mythread['info']) , 80, '...'));
	$metakeywords = $mythread['biaoqian'];
	include template('xlwsq_video:view');
}elseif($_GET['mod']=='favorites'){
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_video_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_video_favorites') . " WHERE sid = '$sid' and uid = '$uid'");
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_video', 'quxiaoshoucang'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_video', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
			}
        } else {
	        $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE id = '$sid'");
            !$item ? showmessage(lang('plugin/xlwsq_video', 'error'),"plugin.php?id=xlwsq_video") : '';
            DB::insert('plugin_xlwsq_video_favorites',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'title' => $item['title'],'dateline' => time()));
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_video', 'shoucangchenggong'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_video', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
			}
        }
    }
}
function change($str){
	$return = array();
	$array = explode(",",$str);
	foreach ($array as $v){
		$t = explode(" ",$v);
		$return[$t[0]] = $t[0];
	}
	return $return;
}
function parconfig($str){
	$return = array();
	$array = explode("\n",str_replace("\r","",$str));
	foreach ($array as $v){
	   $t = explode("=",$v);
	   $t[0] = trim($t[0]);
	   $return[$t[0]] = $t[1];
	}
	return $return;
} 
function gontenfile($str){
$gonten= explode('.',$str);
$gonten = array_reverse($gonten);
return $gonten[0];
}
//From: dis'.'m.tao'.'bao.com
?>