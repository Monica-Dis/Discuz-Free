
jQuery(document).ready(function($) { 

	navSwitch();
	
	$(".h_r_seach").click(function(event) { 
$("#searchbd").toggle(); 
$("#sliderTxt").toggle(); 
$(".right_nav").toggle(); 
}); 
	


    //�˵�����
    $('.swipeWrap').each(function()
    {
        var t = $(this);
        var menuSwiper = new Swiper('.swipeWrap',
        {
            slidesPerView:'auto',
            offsetPxBefore: 0,
            offsetPxAfter: 0,
            calculateHeight: true,
            onTouchEnd:function(swiper)
            { 
                var swiperIndex = menuSwiper.activeIndex;
                if( swiperIndex==0 )
                {
                    t.siblings('.nextBtn').removeClass('lastPage');    
                }
                else
                {
                    t.siblings('.nextBtn').addClass('lastPage');   
                }
                   
            }
        });
    });
    //ȫ��ͼƬ����
    var mySwiper = new Swiper('#slider',
    {
        pagination: '#position',
        loop: true,
        grabCursor: true,
        paginationClickable: true,
        autoplay: 5000,
        autoplayDisableOnInteraction: false
    });
});

/*-------------------------------------------    
	 Nav Dropdown
-------------------------------------------*/
function navSwitch() {	
		
	$(".nav-js").click(function(){
		$(".large-nav").slideToggle();
		$(this).toggleClass("active"); return false;
	});
}
