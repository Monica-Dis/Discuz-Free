jQuery(document).ready(function () {
	// nav滑动+定位导航
	if(jQuery('#Nav .swiper-container').length>0){
		Nav();
	}
	function Nav(){
		//Nav-滑动
	  	var mySwiperNav = new Swiper('#Nav .swiper-container', {
			freeMode: true,
			freeModeMomentumRatio: 0.5,
			slidesPerView: 'auto',
		});
		//Nav-定位
		var swiperWidth = jQuery(document).width(),
			maxTranslate = mySwiperNav.maxTranslate(),
			maxWidth = -maxTranslate + swiperWidth / 2
			slideActive = jQuery('#Nav .active'),
			slideWidth = slideActive.width(),
			num = slideActive.index(),
			slideLeft = slideActive.offset().left,
			slideCenter = slideLeft + slideWidth / 2;
			
		if(slideCenter < swiperWidth /2){
			mySwiperNav.setTranslate(0)
		} else if(slideCenter > maxWidth){
			mySwiperNav.setTranslate(maxTranslate)
		} else{
			nowTlanslate = slideCenter - swiperWidth / 2
			mySwiperNav.setTranslate(-nowTlanslate)
		}
	}
})