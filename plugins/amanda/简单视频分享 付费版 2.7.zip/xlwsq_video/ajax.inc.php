<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {exit('Access Denied');}
global $_G;
loadcache('plugin');
$plyconfig=($_G['cache']['plugin']['xlwsq_video']);
$display=$plyconfig['display'];
$youkepinglunset=$plyconfig['youkepinglunset'];
$dashanshuset=$plyconfig['dashanshuset'];
$dashancishuset=$plyconfig['dashancishuset'];
if($youkepinglunset==1){
	!$_G['uid'] ? $_G['username'] = $_G['clientip'] :'';
}
$uid=intval($_G["uid"]);
$sid=intval($_GET['sid']);
$message=dhtmlspecialchars($_GET['message']);
if(!$_G['mobile']) {
    $message=iconv('utf-8',$_G['charset'],$message);
}
$voter = 1;
$total = intval($_GET['total']);
$pay = intval($_GET['pay']);
$mtype = intval($_GET['moneytype']);
if ($_G['groupid']=="1"||in_array($_G['uid'], $admins)){
   $display =1; 
}else{
   $display = intval($plyconfig['display']);
}
$action=addslashes($_GET['action']);
if($action=="add" && $_GET['formhash'] == FORMHASH){
    if($sid){
        if($pay>'0'){
	        if($pay>$dashanshuset && $dashanshuset >"0"){
	   	        $pay = '0';
                $moneytype ='';
	        }else{
	            $dashangjilu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid = '$sid' AND uid = '$uid' AND pay!='0'");
		        if($dashancishuset !="0"  && ($dashangjilu >= $dashancishuset)){
		  	        $pay = '0';
                    $moneytype ='';
		        }else{
			        $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE id='$sid'");
                    $moneytype = $_G['setting']['extcredits'][$mtype]['title'];
                    $paymoney = getuserprofile('extcredits'."$mtype");
          	        if($paymoney>$pay){
				        updatemembercount($_G['uid'], array($mtype => -$pay));
				        updatemembercount($mythread['uid'], array($mtype => +$pay));
                    }else{
				        $pay = '0';
                        $moneytype ='';
			        }
		        }
	        }
        }
	    DB::insert('plugin_xlwsq_video_post',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'hsuid' =>intval($mythread['uid']),'hsauthor' => addslashes($mythread['author']),'title' => addslashes($mythread['title']),'message' => $message,'voter' => $voter,'total' => $total,'pay' => $pay,'moneytype' => $moneytype,'display' => $display,'dateline' => time()));
	    $result = DB::query("SELECT sum(voter) AS 'voters' , sum(total) AS 'totals' FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$sid' AND display!='0'");
     	$row = DB::fetch($result);  
	    $voter = intval($row['voters']);
	    $total = intval($row['totals']);
    	DB::update('plugin_xlwsq_video_item', array('voter' => $voter, 'total' => $total), "id='$sid'");
    }	
}elseif($action=="del" && $_GET['formhash'] == FORMHASH){
    $did = intval($_GET['did']);
    $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_post')." where id = '$did'");
    if($pl){
	    DB::delete('plugin_xlwsq_video_post',array('id'=> $did));
	    $result = DB::query("SELECT sum(voter) AS 'voter' , sum(total) AS 'total'  FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$pl[sid]' AND display!='0' ");
		$row = DB::fetch($result);  
	    $voter = intval($row['voter']);
	    $total = intval($row['total']);
	    DB::update('plugin_xlwsq_video_item', array('total' => $total,'voter' => $voter),"id ='$pl[sid]'");
		$returns['text']=lang('plugin/xlwsq_video', 'shanchuok');
   }else{
		$returns['text']=lang('plugin/xlwsq_video', 'caozuocuowu');
   }
   $returns['text']=iconv($_G['charset'],'utf-8',$returns['text']);
   echo json_encode($returns);	
}
//From: dis'.'m.tao'.'bao.com
?>