<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
loadcache('plugin');
$plyes=($_G['cache']['plugin']['xlwsq_video']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
$p = $_GET['p'] ? $_GET['p'] : 'index';
$fabuset= unserialize($groups);
$mianshenhe= unserialize($mianshenhe);
$menucate= parconfig($category);
$navtitle = $title;
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';
if($p=='index'){
		$uid = intval($_G['uid']);
		$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_item')." WHERE uid='$uid'");
		$pager = intval($_GET['page']);
		$pager = max($pager, 1);
		$starts = ($pager - 1) * 20;
		if($countr) {
			$rs=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE uid='$uid' ORDER BY display ASC,dateline DESC LIMIT $starts,20");
			while ($rw=DB::fetch($rs)){
				$manylist[]=$rw;
			}
		}
		$multir = "<div class='pages cl'  style='margin:10px 0;'>".multi($countr, 20, $pager,"plugin.php?id=xlwsq_video:xlwsq_video_user&p=".$p)."</div>";
}elseif($p=='adminalllist'){
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
		$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_item'));
		$pager = intval($_GET['page']);
		$pager = max($pager, 1);
		$starts = ($pager - 1) * 20;
		if($countr) {
			$rs=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." ORDER BY display ASC, dateline DESC LIMIT $starts,20");
			while ($rw=DB::fetch($rs)){
				$manylist[]=$rw;
			}
		}
		$multir = "<div class='pages cl'  style='margin:10px 0;'>".multi($countr, 20, $pager, "plugin.php?id=xlwsq_video:xlwsq_video_user&p=".$p)."</div>";
  	 if(submitcheck('applysubmsh')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
		    $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_video_item')." SET display='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_video', 'gengxinok'), dreferer());	
	 }elseif(submitcheck('applysubmqxsh')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
		    $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_video_item')." SET display='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_video', 'gengxinok'), dreferer());
	 }elseif(submitcheck('applysubmtj')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
		    $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_video_item')." SET tuijian='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
	 	showmessage(lang('plugin/xlwsq_video', 'gengxinok'), dreferer());
	 }elseif(submitcheck('applysubmqxtj')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
		    $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_video_item')." SET tuijian='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_video', 'gengxinok'), dreferer());	
	 }elseif(submitcheck('applysubmzd')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
		    $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_video_item')." SET top='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_video', 'gengxinok'), dreferer());
	 }elseif(submitcheck('applysubmqxzd')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
		    $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_video_item')." SET top='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_video', 'gengxinok'), dreferer());	
	 }elseif(submitcheck('applysubmdel')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
		    $aid = intval($aid);
			$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE id ='$aid'LIMIT 0 , 1");
			   if ($active["pic"]!=false){
			      unlink($active["pic"]);
			   }
               DB::query("DELETE a,b,c FROM ".DB::table('plugin_xlwsq_video_item')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_video_favorites')." AS b ON a.id = b.sid LEFT JOIN ".DB::table('plugin_xlwsq_video_post')." AS c ON c.sid = a.id WHERE a.id = '$aid' ");$nums++;
		 }
            showmessage(lang('plugin/xlwsq_video', 'shanchuok'), dreferer());	
      }
	}else{
		showmessage(lang('plugin/xlwsq_video', 'wuquanxiancaozuo'), dreferer());
	}
}elseif($p=='add'){
    include_once 'source/plugin/xlwsq_video/class/upic.class.php';
	$groups = unserialize($groups);
	if(!in_array($_G['groupid'], $groups)){
		showmessage(lang('plugin/xlwsq_video', 'wuquanxiancaozuo'), '', array(), array('login' => true));
	}else{
        $grouplistquery = DB::query("SELECT * FROM " . DB::table('common_usergroup') . "  ORDER BY groupid ASC");
        while ($grouplist = DB::fetch($grouplistquery)) {
            $grouplists[] = $grouplist;
        }
	}
	if(submitcheck('applysubmit')){
		$uid = intval($_G['uid']);	
        $title = dhtmlspecialchars($_GET['title']);
        $pic = dhtmlspecialchars($_GET['pic']);
		$cate = dhtmlspecialchars(implode(',',$_GET["cate"]));
		$jianping = dhtmlspecialchars($_GET['jianping']);
        $info = dhtmlspecialchars($_GET['info']);
	    $videourl = addslashes($_GET['videourl']);
		$object = addslashes($_GET['object']);
	    $biaoqian = dhtmlspecialchars($_GET['biaoqian']);
        $viewgroup = dhtmlspecialchars(implode(',',$_GET["viewgroup"]));
		$tuijian=intval($_GET['tuijian']);
		$view=intval($_GET['view']);
		$top=intval($_GET['top']);
        if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
            $display =1; 
        }else{
			$display =0; 
        }
		$diynum=intval($_GET['diynum']);
		$timestamp = $_G['timestamp'];
		if($_FILES['file']['error']==0){
			$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			$arr=explode(".", $_FILES["file"]["name"]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
				showmessage(lang('plugin/xlwsq_video', 'tupiangeshibuzhengque'));	
			}
			$imageinfo = getimagesize($_FILES['file']['tmp_name']);
			if ($imageinfo[0] <= 0) {
                showmessage(lang('plugin/xlwsq_video', 'tupiangeshibuzhengque'));
			}
			$filepath = "source/plugin/xlwsq_video/upimg/".date("Ymd")."/";
			$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			if(!file_exists($filepath)){ mkdir($filepath); }
			if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
				 @unlink($_FILES['file']['tmp_name']);
			}
			$pic = "source/plugin/xlwsq_video/upimg/".date("Ymd")."/".$randname."";
			if ($imageinfo[0] > 640) {
				 new myThumbClass($pic,1,2,$pic,1,640); 
		    }
		}	
		DB::insert('plugin_xlwsq_video_item',array('id' => '','uid' => $uid,'author' => $_G['username'],'title' => $title,'pic' => $pic,'cate' =>$cate,'jianping' =>$jianping,'info' => $info,'viewgroup' => $viewgroup,'videourl' => $videourl,'object' => $object,'biaoqian' => $biaoqian,'tuijian' => $tuijian,'top' => $top,'view' => $view,'display' => $display,'diynum' => $diynum,'dateline' => $timestamp));
		if($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)){
			showmessage(lang('plugin/xlwsq_video', 'fabuchenggong'), 'plugin.php?id=xlwsq_video:xlwsq_video_user&p=index', array(), array('alert' => 'right'));
		}else{
			for($i=0;$i<count($admins);$i++){
			    $message ='<a href="plugin.php?id=xlwsq_video&#58;xlwsq_video_user&p=adminalllist" target="_blank">'.lang('plugin/xlwsq_video', 'yonghufabuxinxinxi').'</a>';
				notification_add($admins[$i], 'system',$message,  $notevars = array(), $system = 0);
			}
			showmessage(lang('plugin/xlwsq_video', 'fabudengdaishenhe'), 'plugin.php?id=xlwsq_video:xlwsq_video_user&p=index', array(), array('alert' => 'right'));
		}
	}
}elseif($p=='edit'){
    include_once 'source/plugin/xlwsq_video/class/upic.class.php';
	$id = intval($_GET['sid']);
	$active = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE id='$id'");
	$uid = intval($active['uid']);
	if($active['uid']==$_G['uid']||$_G['groupid']=="1"||in_array($_G['uid'], $admins)){}
    else{
		showmessage(lang('plugin/xlwsq_video', 'caozuocuowu'), '', array(), array('login' => true));	
	}
    $grouplistquery = DB::query("SELECT * FROM " . DB::table('common_usergroup') . "  ORDER BY groupid ASC");
    while ($grouplist = DB::fetch($grouplistquery)) {
        $grouplists[] = $grouplist;
    }
    $grouplistarray = change($active['viewgroup']);
    $array = change($active['cate']);
	if(submitcheck('applysubmit')){
	    $sid = intval($_GET['sid']);
        $title = dhtmlspecialchars($_GET['title']);
        $pic = dhtmlspecialchars($_GET['pic']);
		$cate = dhtmlspecialchars(implode(',',$_GET["cate"]));
		$jianping = dhtmlspecialchars($_GET['jianping']);
        $info = dhtmlspecialchars($_GET['info']);
		$videourl = addslashes($_GET['videourl']);
		$object = addslashes($_GET['object']);
	    $biaoqian = dhtmlspecialchars($_GET['biaoqian']);
		$tuijian=intval($_GET['tuijian']);
		$view=intval($_GET['view']);
		$top=intval($_GET['top']);
        if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
            $display =1; 
        }else{
			$display = 0 ; 
        }	
		$diynum=intval($_GET['diynum']);
        if ($_G['groupid']=="1" ||in_array($_G['uid'], $admins)){
            $viewgroup =  dhtmlspecialchars(implode(',',$_GET["viewgroup"]));
        } else {
            $viewgroup =  dhtmlspecialchars($_GET["viewgroup"]);
        }
		$timestamp = $_G['timestamp'];
		if($_FILES['file']['error']==0){
			$imageinfo = getimagesize($_FILES['file']['tmp_name']);
			if ($imageinfo[0] <= 0) {
                showmessage(lang('plugin/xlwsq_video', 'tupiangeshibuzhengque'));
			}
			if ($active["pic"]!=false){
		        unlink($active["pic"]);
	        }
			$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			$arr=explode(".", $_FILES["file"]["name"]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
			    showmessage(lang('plugin/xlwsq_video', 'tupiangeshibuzhengque'));	
			}
			$filepath = "source/plugin/xlwsq_video/upimg/".date("Ymd")."/";
			$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			if(!file_exists($filepath)){ mkdir($filepath); }
			if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
				 @unlink($_FILES['file']['tmp_name']);
			}
			$pic = "source/plugin/xlwsq_video/upimg/".date("Ymd")."/".$randname."";
			if ($imageinfo[0] > 640) {
				 new myThumbClass($pic,1,2,$pic,1,640); 
		    }
		}	
		DB::update('plugin_xlwsq_video_item',array('title' => $title,'pic' => $pic,'cate' =>$cate,'jianping' =>$jianping,'info' => $info,'viewgroup' => $viewgroup,'videourl' => $videourl,'object' => $object,'biaoqian' => $biaoqian,'tuijian' => $tuijian,'view' => $view,'top' => $top,'display' => $display,'diynum' => $diynum),"id='$sid'");
	    showmessage(lang('plugin/xlwsq_video', 'gengxinok'), dreferer());
	}
}elseif($p=='dsjl'||$p=='hsjl'){	
	$uid = intval($_G['uid']);
	if($p=='dsjl'){	
	   $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_post')." WHERE uid='$uid' AND pay!='0'");
    }else{
	   $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_post')." WHERE hsuid='$uid' AND pay!='0'");
    }
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
		if($p=='dsjl'){	
	        $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_post')." WHERE uid = '$uid' AND pay!='0' ORDER BY dateline DESC LIMIT $starts,20");
        }else{
            $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_post')." WHERE  hsuid='$uid' AND pay!='0' ORDER BY dateline DESC LIMIT $starts,20");
        }
	    $ds = $dss = array();
	    while($ds = DB::fetch($query)){
	    	$ds['dateline'] = gmdate('Y-m-d H:i', $ds['dateline'] + $_G['setting']['timeoffset'] * 3600); 
		    $dss[] = $ds;
	    }
    }
 	$multis = "<div class='pages cl' style='margin-top:10px'>".multi($counts, 20, $pages, "plugin.php?id=xlwsq_video:xlwsq_video_user&p=".$p)."</div>";
}elseif($p=='favorites'){	
	$uid = intval($_G['uid']);
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_favorites')." WHERE uid='$uid'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
	   $sql = "SELECT * FROM ".DB::table('plugin_xlwsq_video_favorites')." WHERE uid = '$uid' ORDER BY dateline DESC LIMIT $starts,20";
	   $query = DB::query($sql);
	   $sc = $scs = array();
	   while($sc = DB::fetch($query)){
		  $scs[] = $sc;
	   }
    }
	$multis = "<div class='pages cl'>".multi($counts, 20, $pages, "plugin.php?id=xlwsq_video:xlwsq_video_user&p=".$p)."</div>";
}elseif ($p=='favoritesdel'){
	$id=intval($_GET['sid']);
	$uid = intval($_G['uid']);
    if($_GET['formhash'] == FORMHASH) {
      $favorite = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_favorites')." where id = '$id'");
	  	if($favorite){
	       DB::query("DELETE FROM ".DB::table('plugin_xlwsq_video_favorites')." WHERE id = '$id' and uid = '$uid'");
           showmessage(lang('plugin/xlwsq_video', 'shanchuok'), dreferer());
        }else{
	       showmessage(lang('plugin/xlwsq_video', 'caozuocuowu'));
		}
    }
}elseif($p=='plshenheok'){	
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id = intval($_GET['sid']);
     if($_GET['formhash'] == FORMHASH) {
        $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_post')." where id = '$id'");
		    DB::query("UPDATE ".DB::table('plugin_xlwsq_video_post')." SET display='1' WHERE id='$id' LIMIT 1");
			$result = DB::query("SELECT sum(voter) AS 'voter' , sum(total) AS 'total'  FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$pl[sid]' AND display!='0'");
			$row = DB::fetch($result);  
			$voter = intval($row['voter']);
			$total = intval($row['total']);
	        DB::update('plugin_xlwsq_video_item', array('total' => $total,'voter' => $voter),"id ='$pl[sid]'");
        showmessage(lang('plugin/xlwsq_video', 'shenheok'), dreferer());
      }
	}else{
	    showmessage(lang('plugin/xlwsq_video', 'caozuocuowu'));
	}
}elseif($p=='plqxshenhe'){	
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id = intval($_GET['sid']);
     if($_GET['formhash'] == FORMHASH) {
        $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_post')." where id = '$id'");
		    DB::query("UPDATE ".DB::table('plugin_xlwsq_video_post')." SET display='0' WHERE id='$id'");
			$result = DB::query("SELECT sum(voter) AS 'voter' , sum(total) AS 'total'  FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$pl[sid]' AND display!='0'");
			$row = DB::fetch($result);  
			$voter = intval($row['voter']);
			$total = intval($row['total']);
	        DB::update('plugin_xlwsq_video_item', array('total' => $total,'voter' => $voter),"id ='$pl[sid]'");
		showmessage(lang('plugin/xlwsq_video', 'qxshenhe'), dreferer());
      }
	}else{
	    showmessage(lang('plugin/xlwsq_video', 'caozuocuowu'));
	}
}elseif($p=='adminpinglun'){
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
		$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_video_post'));
		$pager = intval($_GET['page']);
		$pager = max($pager, 1);
		$starts = ($pager - 1) * 20;
		if($countr) {
			$rs=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." a, ".DB::table('plugin_xlwsq_video_post')." b WHERE  a.id = b.sid ORDER BY b.dateline DESC LIMIT $starts,20");
			while ($rw=DB::fetch($rs)){
				$manylist[]=$rw;
			}
		}
		$multir = "<div class='pages cl' style='margin:10px 0;'>".multi($countr, 20, $pager, "plugin.php?id=xlwsq_video:xlwsq_video_user&p=adminpinglun")."</div>";
	}else{
		showmessage(lang('plugin/xlwsq_video', 'caozuocuowu'));
	}
	if(submitcheck('applysubmsh')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
		  $aid = intval($aid);
          $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_post')." where id = '$aid'");
			DB::query("UPDATE ".DB::table('plugin_xlwsq_video_post')." SET display='1' WHERE id='$aid' LIMIT 1");
			$result = DB::query("SELECT sum(voter) AS 'voter' , sum(total) AS 'total'  FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$pl[sid]' AND display!='0'");
			$row = DB::fetch($result);  
			$voter = intval($row['voter']);
			$total = intval($row['total']);
	        DB::update('plugin_xlwsq_video_item', array('total' => $total,'voter' => $voter),"id ='$pl[sid]'");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_video', 'gengxinok'), dreferer());	
	}elseif(submitcheck('applysubmdel')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
		  $aid = intval($aid);
          $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_post')." where id = '$aid'");
		    DB::delete('plugin_xlwsq_video_post',array('id'=> $aid));
			$result = DB::query("SELECT sum(voter) AS 'voter' , sum(total) AS 'total'  FROM ".DB::table('plugin_xlwsq_video_post')." WHERE sid='$pl[sid]' AND display!='0'");
			$row = DB::fetch($result);  
			$voter = intval($row['voter']);
			$total = intval($row['total']);
	        DB::update('plugin_xlwsq_video_item', array('total' => $total,'voter' => $voter),"id ='$pl[sid]'");
			$nums++;
		}
        showmessage(lang('plugin/xlwsq_video', 'shanchuok'), dreferer());
    }
}elseif($p=='shenheok'){	
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id = intval($_GET['sid']);
	  if($_GET['formhash'] == FORMHASH) {
		DB::query("UPDATE ".DB::table('plugin_xlwsq_video_item')." SET display='1' WHERE id='$id'");
        showmessage(lang('plugin/xlwsq_video', 'shenheok'), dreferer());
      }
	}else{
		showmessage(lang('plugin/xlwsq_video', 'caozuocuowu'));
	}
}elseif($p=='qxshenhe'){	
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id = intval($_GET['sid']);
	  if($_GET['formhash'] == FORMHASH) {
		DB::query("UPDATE ".DB::table('plugin_xlwsq_video_item')." SET display='0' WHERE id='$id'");
        showmessage(lang('plugin/xlwsq_video', 'qxshenhe'), dreferer());
      }
	}else{
		showmessage(lang('plugin/xlwsq_video', 'caozuocuowu'));
	}
}elseif ($p=='del'){
 $id = intval($_GET['sid']);
 if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    if($_GET['formhash'] == FORMHASH) {
	    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE id ='{$id}'");
		if ($active["pic"]!=false){
		    unlink($active["pic"]);
		}
        DB::query("DELETE a,b,c FROM ".DB::table('plugin_xlwsq_video_item')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_video_favorites')." AS b ON a.id = b.sid LEFT JOIN ".DB::table('plugin_xlwsq_video_post')." AS c ON c.sid = a.id WHERE a.id = '$id' ");
		showmessage(lang('plugin/xlwsq_video', 'shanchuok'), dreferer());
    }
 }else{
	$uid = intval($_G['uid']);
    if($_GET['formhash'] == FORMHASH) {
	    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_item')." WHERE id ='$id' AND uid='$uid'");
	    if($active['uid']!=$uid){
		   showmessage(lang('plugin/xlwsq_video', 'caozuocuowu'), '', array(), array('login' => true));	
	    }
		if ($active["pic"]!=false){
		   unlink($active["pic"]);
		}
        DB::query("DELETE a,b,c FROM ".DB::table('plugin_xlwsq_video_item')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_video_favorites')." AS b ON a.id = b.sid LEFT JOIN ".DB::table('plugin_xlwsq_video_post')." AS c ON c.sid = a.id WHERE a.id = '$id' ");
		showmessage(lang('plugin/xlwsq_video', 'shanchuok'), dreferer());
    }
  }
//banner
}elseif($p=='banneradd'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	if(submitcheck('addbannersubmit')){
        $title = dhtmlspecialchars($_GET['title']);
        $pic = dhtmlspecialchars($_GET['pic']);
        $url = addslashes($_GET['url']);
        $timestamp = $_G['timestamp'];
		if($_FILES['file']['error']==0){
			$rand=date("YmdHis").random(3, $numeric =1);
			$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			$arr=explode(".", $_FILES["file"]["name"]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
				showmessage(lang('plugin/xlwsq_video', 'tupiangeshibuzhengque'));	
			}
			$filepath = "source/plugin/xlwsq_video/banner/".date("Ymd")."/";
			$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			if(!file_exists($filepath)){ mkdir($filepath); }			
			if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
				@unlink($_FILES['file']['tmp_name']);
			}
			$pic = "source/plugin/xlwsq_video/banner/".date("Ymd")."/".$randname."";
		}
		DB::insert('plugin_xlwsq_video_banner',array('id' => '','title' => $title,'pic' => $pic,'url' => $url, 'dateline' => $timestamp));
		showmessage(lang('plugin/xlwsq_video', 'fabuchenggong'), "plugin.php?id=xlwsq_video:xlwsq_video_user&p=banner", array(), array('alert' => 'right'));
	 }
  }else{
		showmessage(lang('plugin/xlwsq_video', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
  }
}elseif($p=='banneredit'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $id=intval($_GET['bid']);
	$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_banner')." WHERE id ='$id'");
	if(submitcheck('editbannersubmit')){
        $title = dhtmlspecialchars($_GET['title']);
        $pic = dhtmlspecialchars($_GET['pic']);
        $url = addslashes($_GET['url']);
		if($_FILES['file']['error']==0){
			if (isset($active['pic'])){
	            unlink($active["pic"]);
	        }
			$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			$arr=explode(".", $_FILES["file"]["name"]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
				showmessage(lang('plugin/xlwsq_video', 'tupiangeshibuzhengque'));	
			}
			$filepath = "source/plugin/xlwsq_video/banner/".date("Ymd")."/";
			$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
			if(!file_exists($filepath)){ mkdir($filepath); }
			if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
				 @unlink($_FILES['file']['tmp_name']);
			}
			$pic = "source/plugin/xlwsq_video/banner/".date("Ymd")."/".$randname."";
		}
		DB::update('plugin_xlwsq_video_banner',array('title' => $title,'pic' => $pic,'url' => $url),"id='$id'");
		showmessage(lang('plugin/xlwsq_video', 'fabuchenggong'), dreferer());
	}
  }else{
	  showmessage(lang('plugin/xlwsq_video', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
  }
}elseif($p=='banner'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $perpage = 10;
    $page = max(1, intval($_GET['page']));
    $start_limit = ($page - 1) * $perpage;
    $count = DB::result_first("SELECT count(*) FROM ".DB::table('plugin_xlwsq_video_banner'));
    $multipage = multi($count, $perpage, $page, "plugin.php?id=xlwsq_video:xlwsq_video_user&p=banner");
    $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_video_banner'). " ORDER BY id DESC LIMIT $start_limit, $perpage");
	$banner = $banners = array();
	while($banner = DB::fetch($query)){
		$banner['dateline'] = gmdate('Y-m-d', $banner['dateline'] + $_G['setting']['timeoffset'] * 3600); 
		$banners[] = $banner;
	}
   }else{
		showmessage(lang('plugin/xlwsq_video', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
   }
}elseif ($p=='bannerdel'){
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $id=intval($_GET['bid']);
    if($_GET['formhash'] == FORMHASH) {
		$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_video_banner')." WHERE id ='$id'");
		if ($active["pic"]!=false){
		    unlink($active["pic"]);
	    }
	    DB::query("DELETE FROM ".DB::table('plugin_xlwsq_video_banner')." WHERE id = '$id'");
        showmessage(lang('plugin/xlwsq_video', 'shanchuok'), 'plugin.php?id=xlwsq_video:xlwsq_video_user&p=banner', array(), array('alert' => 'right'));
    }
  }else{
       showmessage(lang('plugin/xlwsq_video', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
  }
}
include(template("xlwsq_video:xlwsq_video_user"));
function change($str){
	$return = array();
	$array = explode(",",$str);
	foreach ($array as $v){
		$t = explode(" ",$v);
		$return[$t[0]] = $t[0];
	}
	return $return;
}
function parconfig($str){
	$return = array();
	$array = explode("\n",str_replace("\r","",$str));
	foreach ($array as $v){
	   $t = explode("=",$v);
	   $t[0] = trim($t[0]);
	   $return[$t[0]] = $t[1];
	}
	return $return;
} 
?>