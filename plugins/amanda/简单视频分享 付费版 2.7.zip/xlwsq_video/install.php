<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_video_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(4) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `author` varchar(100) NOT NULL,
	  `title` text NOT NULL,
	  `pic` text NOT NULL,
	  `cate` text NOT NULL,
	  `jianping` text NOT NULL,
	  `info` text NOT NULL,
	  `videourl` text NOT NULL,
	  `object` text NOT NULL,
	  `biaoqian` text NOT NULL,
	  `view` int(11) NOT NULL,
   	  `voter` int(11) NOT NULL,
   	  `total` int(11) NOT NULL,
      `tuijian` tinyint(1) NOT NULL,
	  `top` tinyint(1)  NOT NULL,
	  `price` int(11) NOT NULL,
	  `viewgroup` varchar(255) NOT NULL,
	  `password` varchar(100) NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_video_favorites` (
   	  `id` int(11) NOT NULL auto_increment,
 	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `title` varchar(255) NOT NULL,
   	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_video_post` (
   	  `id` int(11) NOT NULL auto_increment,
   	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `hsuid` int(11) NOT NULL,
   	  `hsauthor` varchar(100) NOT NULL,
  	  `title` text NOT NULL,
  	  `message` text NOT NULL,
  	  `reply` text NOT NULL,
   	  `pay` int(11) NOT NULL,
   	  `moneytype` text NOT NULL,
   	  `voter` int(11) NOT NULL,
   	  `total` int(11) NOT NULL,
   	  `display` tinyint(4) NOT NULL,
   	  `dateline` int(10) NOT NULL,
   	  PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_video_banner` (
	  `id` int(11) NOT NULL auto_increment,
	  `title` text NOT NULL,
	  `pic` text NOT NULL,
	  `url` text NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
EOF;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_video/discuz_plugin_xlwsq_video.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_video/discuz_plugin_xlwsq_video_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_video/discuz_plugin_xlwsq_video_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_video/discuz_plugin_xlwsq_video_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_video/discuz_plugin_xlwsq_video_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_video/install.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_video/upgrade.php');
runquery($sql);
$finish =true;
?>