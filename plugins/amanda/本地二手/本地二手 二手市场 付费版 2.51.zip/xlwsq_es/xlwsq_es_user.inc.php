<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
$plyes=($_G['cache']['plugin']['xlwsq_es']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
if($_G['mobile']) {
	$menubgcolor=$mobilemenubgcolor;
}
$fabuset = unserialize($groups);
$mianshenhe = unserialize($mianshenhe);
$viewgroups = unserialize($viewgroups);
$chengse = parconfig($chengse);
$newpicdx=$picdx*1024;
$newpicwidth=intval($newpicwidth);
$navtitle = $title;
$fid =  intval($bbsfid);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$credit = abs($credit);
$_G['uid'] = $_G['uid'] ? $_G['uid'] : '0';
$p = $_GET['p'] ? $_GET['p'] : 'index';
if (!in_array($_G['groupid'], $viewgroups) && $_G['groupid'] != "1" && !in_array($_G['uid'], $admins)) {
    showmessage(lang('plugin/xlwsq_es', 'wuquanxianfangwen') , '', array() , array('login' => true));
}
if ($p != 'index' && $p != 'add' && $p != 'add2' && $p != 'edit' && $p != 'del') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
}
if ($p == 'mylist'||$p == 'index'||$p == 'completion') {
    $where=$pageadd="";
    $key=stripsearchkey($_GET['key']);
    if($_GET['key']){
	    $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
    if ($p == 'completion') {
       $sold=" AND sold='4'"; 
    }
    $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE $where uid='$uid' AND uid!='0' $sold");
    $pager = intval($_GET['page']);
    $pager = max($pager, 1);
    $starts = ($pager - 1) * 20;
    if ($countr) {
        $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE $where uid='$uid' AND uid!='0' $sold ORDER BY display ASC,dateline DESC LIMIT $starts,20");
        while ($rw = DB::fetch($rs)) {
            if ($rw['topdateline']!='0'){DB::query("UPDATE ".DB::table('plugin_xlwsq_es_item')." SET `topdateline` = '0',`color` = '' WHERE topdateline!= '0' AND  topdateline <= ".$_G['timestamp']);}
            $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$rw[cate]'"));
            if ($pa['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$pa[upid]'");
                $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
            } else {
                $rw['cate'] = $pa['subject'];
            }
            $manylist[] = $rw;
        }
    }
    $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager, 'plugin.php?id=xlwsq_es:xlwsq_es_user&p='.$p.'' . $pageadd) . "</div>";
	$moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
} elseif ($p == 'adminalllist') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $where=$pageadd="";
        $key=stripsearchkey($_GET['key']);
        if($_GET['key']){
	      $where=" where title like '%".addcslashes(addslashes($key), '%_')."%'";
	      $keync=urlencode($key);
	      $pageadd="&key=$keync";
        }
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_es_item').$where);
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " $where ORDER BY display ASC,dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager, 'plugin.php?id=xlwsq_es:xlwsq_es_user&p=adminalllist' . $pageadd) . "</div>";
    } else {
        showmessage(lang('plugin/xlwsq_es', 'wuquanxiancaozuo') , '', array() , array('alert' => 'error'));
    }
    if (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
			$active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id='$aid'");
            DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET display='1' WHERE id='$aid' LIMIT 1");
			DB::query("UPDATE " . DB::table('forum_thread') . " SET displayorder='0' WHERE tid='$active[bbstid]'");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_es', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
			$active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id='$aid'");
            DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET display='0' WHERE id='$aid' LIMIT 1");
			DB::query("UPDATE " . DB::table('forum_thread') . " SET displayorder='-2' WHERE tid='$active[bbstid]'");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_es', 'gengxinok') , dreferer());
	}elseif(submitcheck('applysubmtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_es_item')." SET tuijian='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_es', 'gengxinok'), dreferer());
	}elseif(submitcheck('applysubmqxtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_es_item')." SET tuijian='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_es', 'gengxinok'), dreferer());	
    } elseif (submitcheck('applysubmzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
			$active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id='$aid'");
            DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET top='1' WHERE id='$aid' LIMIT 1");
			DB::query("UPDATE " . DB::table('forum_thread') . " SET displayorder='1' WHERE tid='$active[bbstid]'");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_es', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
			$active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id='$aid'");
            DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET top='0' WHERE id='$aid' LIMIT 1");
			DB::query("UPDATE " . DB::table('forum_thread') . " SET displayorder='0' WHERE tid='$active[bbstid]'");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_es', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxtg')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET `topdateline` = '0',`color` = '' WHERE topdateline!= '0' AND id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_es', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id ='$aid'LIMIT 0 , 1");
			if ($active["spic"]!=false){
			   unlink($active["spic"]);
			}
            for ($i = 1; $i <= 5; $i++) {
               $pic = 'pic'.$i;
		       unlink($active[$pic]);
            }
            DB::query("DELETE a,b FROM " . DB::table('plugin_xlwsq_es_item') . " AS a LEFT JOIN " . DB::table('plugin_xlwsq_es_post') . " AS b ON a.id = b.sid  WHERE a.id = '$aid' ");
			DB::query("DELETE a,b FROM " . DB::table('forum_thread') . " AS a LEFT JOIN " . DB::table('forum_post') . " AS b ON a.tid = b.tid WHERE a.tid = '$active[bbstid]' ");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_es', 'shanchuok') , dreferer());
    }
}elseif($p=='adminxfjl'){	
    $where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    $keytype = intval($_GET['keytype']);
    if($key){
        if($keytype==1){
            $where=" WHERE author ='$key' ";
        }elseif($keytype==2){
            $where=" WHERE title ='$key' ";
	    }
	    $keync=urlencode($key);
	    $pageadd="&keytype=$keytype&key=$keync";
    }	
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_es_record').$where);
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 30;
    if($counts) {
	    $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_es_record')." $where ORDER BY dateline DESC LIMIT $starts,30");
	    $manylist = $manylists = array();
	    while($manylist = DB::fetch($query)){
		    $manylists[] = $manylist;
	    }
    }
	$multis = "<div class='pages cl' style='margin:5px'>".multi($counts, 30, $pages, "plugin.php?id=xlwsq_es:xlwsq_es_user&p=".$p.$pageadd)."</div>";
} elseif ($p == 'add'||$p == 'add2') {
    $groups = unserialize($groups);
    if (!in_array($_G['groupid'], $groups)) {
	    showmessage(lang('plugin/xlwsq_es','wuquanxiancaozuo'), '', array() , array('login' => true));
    }else{
	    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
        $paymoney = getuserprofile('extcredits'."$paytype");
        if(($credit!="0" && $paytype)&&!$_G['uid']){
            $tixing= lang('plugin/xlwsq_es', 'xiaohaotishi').$credit.$moneytype.lang('plugin/xlwsq_es', 'xiaohaotishi2');
	        showmessage(lang('plugin/xlwsq_es',$tixing) , '', array() , array('login' => true));
        }
        include_once 'source/plugin/xlwsq_es/class/upic.class.php';
        include_once 'source/plugin/xlwsq_es/class/watermark.class.php';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
        while ($row = DB::fetch($query)) {
            $cates[$row['id']] = $row;
        }
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
        while ($row = DB::fetch($query)) {
            $areas[$row['id']] = $row;
        }
        if (submitcheck('applysubmit')) {
            $uid = intval($_G['uid']);
            $title = strip_tags(daddslashes($_GET['title']));
            $fenlei = intval($_GET['fenlei']);
            $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
            $area = intval($_GET['area_two']) ? intval($_GET['area_two']) : intval($_GET['area_1']);
            $chengse = dhtmlspecialchars($_GET['chengse']);
            $info = strip_tags(daddslashes($_GET['info']));
            $peisongfangshi =dhtmlspecialchars($_GET['peisongfangshi']);
	    	$tel = strip_tags(daddslashes($_GET['tel']));
		    $qq = strip_tags(daddslashes($_GET['qq']));
		    $weixin = strip_tags(daddslashes($_GET['weixin']));
		    $lianxiren = strip_tags(daddslashes($_GET['lianxiren']));
            $endtime = dhtmlspecialchars($_GET['endtime']);
			$price = strip_tags(daddslashes($_GET['price']));
			$view = intval($_GET['view']);
	        if ($_GET['endtime'] != "") {$endtime=strtotime($_GET['endtime']);} else {$endtime = 0;}
            $top = intval($_GET['top']);
            $tuijian = intval($_GET['tuijian']);
            if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins) || in_array($_G['groupid'], $mianshenhe)) {
                $display = 1;
                $displayorder = 0;
            } else {
                $display = 0;
                $displayorder = -2;
            }
            $diynum = intval($_GET['diynum']);
            $color = dhtmlspecialchars($_GET['color']);
            $password = dhtmlspecialchars($_GET['password']);
	        if(!$password && !$uid){
		        showmessage(lang('plugin/xlwsq_es', 'youkexushezhimima'),'');
	        }
            if($credit!="0" && $paytype){
                if($paymoney<$credit){
                    $tixing= lang('plugin/xlwsq_es', 'xiaohaotishi').$credit.$moneytype;
        	        showmessage(lang('plugin/xlwsq_es', $tixing), dreferer());
                }
            }
            for ($i = 1; $i <= 5; $i++) {
                $pic = 'pic'.$i;
                $spic = 'spic'.$i;
                if ($_FILES[$pic]['tmp_name']) {
				    $picsize = $_FILES[$pic]['size'];
                    $picname = $_FILES[$pic]['name'];
                    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                    $arr = explode(".", $_FILES[$pic]["name"]);
                    $hz = $arr[count($arr) - 1];
                    if (!in_array($hz, $filetype)) {
                       showmessage(lang('plugin/xlwsq_es', 'tupiangeshibuzhengque'));
                    }
				    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
				    if ($imageinfo[0] <= 0) {
                            showmessage(lang('plugin/xlwsq_es', 'tupiangeshibuzhengque'));
				    }
                    $update = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999);
                    $pics =$update. ".";
                    $spics =$update .  "_s" .".";
					$img_dir = "source/plugin/xlwsq_es/upimg/" . date("Ymd") . "/";
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $$pic = $img_dir . $pics. $hz;
					$$spic = $img_dir. $spics. $hz;
                    if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
					   if ($i==1) { @copy($_FILES[$pic]['tmp_name'], $$spic) ;}
                        @unlink($_FILES[$pic]['tmp_name']);
                    }
					if ($i==1 && $imageinfo[0] > 220) {
						imageUpdateSize($$spic,220,160);
					}
				    if ($picsize > $newpicdx) {
						if ($imageinfo[0] > $newpicwidth) {
							imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$newpicwidth));
							
                        }else{
							imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]);
						}
					}
                    if($imgwater && $imageinfo[0] > $waterwidth){
	                   imageUpdateLogo($$pic,$imgwater);
                    }
              }
              $pic= dhtmlspecialchars($pic);
            }
            $newsid = DB::insert('plugin_xlwsq_es_item', array('id'=>NULL), true);
            if($credit!="0" && $paytype){
	             updatemembercount($_G['uid'], array($paytype => -$credit));
			     DB::insert('plugin_xlwsq_es_record',array('id' => '','sid' => $newsid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $title,'pay' => $credit,'moneytype' => $moneytype,'xftype' => '1','dateline' =>$_G['timestamp']));
            }
			if($fid!=0){
			  if($pic1!=""){$bbspic1='[img=130,110]'.$_G['siteurl'].$pic1.'[/img]';}
			  if($pic2!=""){$bbspic2='[img=130,110]'.$_G['siteurl'].$pic2.'[/img]';}
			  if($pic3!=""){$bbspic3='[img=130,110]'.$_G['siteurl'].$pic3.'[/img]';}
			  if($pic4!=""){$bbspic4='[img=130,110]'.$_G['siteurl'].$pic4.'[/img]';}
			  if($pic5!=""){$bbspic5='[img=130,110]'.$_G['siteurl'].$pic5.'[/img]';}
			  if($price>'0'){$bbsprice=$price.lang('plugin/xlwsq_es', 'bbsyuan');}else{$bbsprice=lang('plugin/xlwsq_es', 'bbsmianyi');}
			  if($fenlei==1){
				$typeid=$saletypeid;
                $bbsinfo=$info.'[hr]'.$bbspic1.$bbspic2.$bbspic3.$bbspic4.$bbspic5.'[hr][table=100%][tr][td=15%][b]'.lang('plugin/xlwsq_es', 'bbsxinjiuchengdu').'[b][/td][td=30%]'.$chengse.'[/td][td=10%][b] '.lang('plugin/xlwsq_es', 'bbsjiage').'[/b][/td][td=30%]'.$bbsprice.'[/td][/tr][tr][td][b]'.lang('plugin/xlwsq_es', 'bbslianxiren').'[/b][/td][td]'.$lianxiren.'[/td][td][b]'.lang('plugin/xlwsq_es', 'bbsdianhua').'[/b][/td][td]'.$tel.'[/td][/tr][tr][td][b]QQ [/b][/td][td]'.$qq.'[/td][td][b]'.lang('plugin/xlwsq_es', 'bbsweixin').'[/b][/td][td]'.$weixin.'[/td][/tr][/table][hr][align=center][url=plugin.php?id=xlwsq_es&mod=view&sid='.$newsid.']'.lang('plugin/xlwsq_es', 'bbschakan').'[/url][/align]';
              }else{
				$typeid=$buytypeid;
                $bbsinfo=$info.'[hr]'.$bbspic1.$bbspic2.$bbspic3.$bbspic4.$bbspic5.'[hr][table=100%][tr][td=15%][b]'.lang('plugin/xlwsq_es', 'bbslianxiren').'[/b][/td][td]'.$lianxiren.'[/td][td=15%][b]'.lang('plugin/xlwsq_es', 'bbsdianhua').'[/b][/td][td]'.$tel.'[/td][/tr][tr][td=15%][b]QQ [/b][/td][td]'.$qq.'[/td][td=15%][b]'.lang('plugin/xlwsq_es', 'bbsweixin').'[/b][/td][td]'.$weixin.'[/td][/tr][/table][hr][align=center][url=plugin.php?id=xlwsq_es&mod=view&sid='.$newsid.']'.lang('plugin/xlwsq_es', 'bbschakan').'[/url][/align]';
			  }
              DB::query("INSERT INTO ".DB::table('forum_thread')." (fid, views, typeid, sortid, author, authorid, subject,displayorder, dateline, lastpost, lastposter, status, closed) VALUES ($fid, 0,  $typeid,0, '$_G[username]', $_G[uid], '$title','$displayorder', '$_G[timestamp]', '$_G[timestamp]', '$_G[username]', '0', '0')");
              $tid = DB::insert_id();
              $pid = DB::insert('forum_post_tableid', array('pid'=>NULL), true);
              DB::query("INSERT INTO ".DB::table('forum_post')." (pid, fid, tid, first, author, authorid, subject, dateline, message) VALUES ('$pid', $fid, '$tid', '1', '$_G[username]', $_G[uid], '$title', '$_G[timestamp]', '$bbsinfo')");
              DB::query("UPDATE ".DB::table('forum_forum')." SET threads=threads+1, posts=posts+1, todayposts=todayposts+1 WHERE fid='$fid'", 'UNBUFFERED');
			}
            DB::update('plugin_xlwsq_es_item', array('uid' => $uid,'author' => $_G['username'],'title' => $title,'fenlei' => $fenlei,'cate' => $cate,'area' => $area,'chengse' => $chengse,'info' => $info,'peisongfangshi' => $peisongfangshi,'lianxiren' => $lianxiren,'tel' => $tel,'qq' => $qq,'weixin' => $weixin,'endtime' => $endtime,'price' => $price,'spic' => $spic1,'pic1' => $pic1,'pic2' => $pic2,'pic3' => $pic3,'pic4' => $pic4,'pic5' => $pic5,'view' => $view,'top' => $top,'tuijian' => $tuijian,'display' => $display,'diynum' => $diynum,'color' => $color,'dateline' => $_G['timestamp'],'updateline' => $_G['timestamp'],'password' => $password,'bbstid' => $tid
            ), "id='$newsid'");

            if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins) || in_array($_G['groupid'], $mianshenhe)) {
                showmessage(lang('plugin/xlwsq_es', 'fabuchenggong') , 'plugin.php?id=xlwsq_es', array() , array('alert' => 'right'));
            } else {
                for ($i = 0; $i < count($admins); $i++) {
                    $message = '<a href="plugin.php?id=xlwsq_es&#58;xlwsq_es_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_es', 'yonghufabuxinxinxi') . '</a>';
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                }
                showmessage(lang('plugin/xlwsq_es', 'fabudengdaishenhe') , 'plugin.php?id=xlwsq_es', array() , array('alert' => 'right'));
            }
        }
    }
} elseif ($p == 'edit') {
    include_once 'source/plugin/xlwsq_es/class/upic.class.php';
    include_once 'source/plugin/xlwsq_es/class/watermark.class.php';
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id='$id'");
    $fenlei = $active['fenlei'];
    $tid = intval($active['bbstid']);
    $uid = intval($active['uid']);
    $password = dhtmlspecialchars($_GET['password']);
    if(submitcheck('applysubrenling')){
       if($password != $active['password']){
          showmessage(lang('plugin/xlwsq_es', 'koulingcuowu'));
       }
    }  
    if (empty($active['uid'])||(!empty($active['uid']) && $active['uid'] == $_G['uid']) || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
	} else {
        showmessage(lang('plugin/xlwsq_es', 'caozuocuowu') , '', array() , array('login' => true));
    }
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    $areaid = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id='$active[area]'");
    if ($areaid) {
        $areatwoshow = '<select name="area_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE upid='$areaid'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['area']) {
                $areatwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $areatwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $areatwoshow.= '</select>';
    } else {
        $areaid = $active['area'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $areas[$row['id']] = $row;
    }
    if (submitcheck('applysubmit')) {
        $password = dhtmlspecialchars($_GET['password']);
         if ((!empty($active['uid']) && $active['uid'] == $_G['uid']) || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
	         } elseif ($active['password'] !=$password){
               showmessage(lang('plugin/xlwsq_es', 'koulingcuowu'));
		 } 
        $sid = intval($_GET['sid']);
		$title = strip_tags(daddslashes($_GET['title']));
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $area = intval($_GET['area_two']) ? intval($_GET['area_two']) : intval($_GET['area_1']);
        $chengse = dhtmlspecialchars($_GET['chengse']);
		$info = strip_tags(daddslashes($_GET['info']));
        $peisongfangshi = dhtmlspecialchars($_GET['peisongfangshi']);
		$tel = strip_tags(daddslashes($_GET['tel']));
		$qq = strip_tags(daddslashes($_GET['qq']));
		$weixin = strip_tags(daddslashes($_GET['weixin']));
		$lianxiren = strip_tags(daddslashes($_GET['lianxiren']));
	    if ($_GET['endtime'] != "") {
			$endtime=strtotime($_GET['endtime']);
		} else {
			$endtime = 0;
		}
		$price = strip_tags(daddslashes($_GET['price']));
		$spic = strip_tags(daddslashes($_GET['spic']));
		$pic1 = strip_tags(daddslashes($_GET['pic1']));
		$pic2 = strip_tags(daddslashes($_GET['pic2']));
		$pic3 = strip_tags(daddslashes($_GET['pic3']));
		$pic4 = strip_tags(daddslashes($_GET['pic4']));
		$pic5 = strip_tags(daddslashes($_GET['pic5']));
        $view = intval($_GET['view']);
        $top = intval($_GET['top']);
        $tuijian = intval($_GET['tuijian']);
        if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)|| in_array($_G['groupid'], $mianshenhe)) {
            $display = 1;
            $displayorder = 0;
       } else {
            $display = 0;
            $displayorder = -2;
        }
        $diynum = intval($_GET['diynum']);
        $color = dhtmlspecialchars($_GET['color']);
        $timestamp = $_G['timestamp'];
        for ($i = 1; $i <= 5; $i++) {
           $pic = 'pic'.$i;
           $spic = 'spic'.$i;
           $picdel = 'picdelete'.$i;
			   	if ($_GET[$picdel]==1){
		            unlink($active[$pic]);
                    $$pic = "";
                    if ($i==1) { 
		                unlink($active[spic]);
						$$spic = "";
					}
	            }
           if ($_FILES[$pic]['tmp_name']) {
			   	if ($active[$pic]!=false){
		            unlink($active[$pic]);
                    if ($i==1) { 
		                unlink($active[spic]);
					}
	            }
				$picsize = $_FILES[$pic]['size'];
                $picname = $_FILES[$pic]['name'];
                    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                    $arr = explode(".", $_FILES[$pic]["name"]);
                    $hz = $arr[count($arr) - 1];
                    if (!in_array($hz, $filetype)) {
                       showmessage(lang('plugin/xlwsq_es', 'tupiangeshibuzhengque'));
                    }
				    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
				    if ($imageinfo[0] <= 0) {
                       showmessage(lang('plugin/xlwsq_es', 'tupiangeshibuzhengque'));
				    }
                    $update = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999);
                    $pics =$update. ".";
                    $spics =$update .  "_s" .".";
					$img_dir = "source/plugin/xlwsq_es/upimg/" . date("Ymd") . "/";
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $$pic = $img_dir . $pics. $hz;
					$$spic = $img_dir. $spics. $hz;
                    if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
						if ($i==1) { @copy($_FILES[$pic]['tmp_name'], $$spic) ;}
                        @unlink($_FILES[$pic]['tmp_name']);
                    }
					if ($i==1 && $imageinfo[0] > 220) {
						imageUpdateSize($$spic,220,160);
					}
				    if ($picsize > $newpicdx) {
						if ($imageinfo[0] > $newpicwidth) {
							imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$newpicwidth));
							
                        }else{
							imageUpdateSize($$pic,$imageinfo[0],$imageinfo[1]);
						}
					}
                    if($imgwater && $imageinfo[0] > $waterwidth){
	                   imageUpdateLogo($$pic,$imgwater);
                    }
           }
           $pic= dhtmlspecialchars($pic);
        }
        DB::update('plugin_xlwsq_es_item', array('title' => $title,'cate' => $cate,'area' => $area,'chengse' => $chengse,'info' => $info,'peisongfangshi' => $peisongfangshi,'lianxiren' => $lianxiren,'tel' => $tel,'qq' => $qq,'weixin' => $weixin,'price' => $price,'spic' => $spic1,'pic1' => $pic1,'pic2' => $pic2,'pic3' => $pic3,'pic4' => $pic4,'pic5' => $pic5,'view' => $view,'top' => $top,'endtime' => $endtime,'tuijian' => $tuijian,'color' => $color,'display' => $display,'diynum' => $diynum) , "id='$sid'");
		if($fid!=0){
	         	if($pic1!=""){$bbspic1='[img]'.$_G['siteurl'].$pic1.'[/img]';}
		        if($pic2!=""){$bbspic2='[img]'.$_G['siteurl'].$pic2.'[/img]';}
		        if($pic3!=""){$bbspic3='[img]'.$_G['siteurl'].$pic3.'[/img]';}
		        if($pic4!=""){$bbspic4='[img]'.$_G['siteurl'].$pic4.'[/img]';}
		        if($pic5!=""){$bbspic5='[img]'.$_G['siteurl'].$pic5.'[/img]';}
		        if($price>'0'){$bbsprice=$price.lang('plugin/xlwsq_es', 'bbsyuan');}else{$bbsprice=lang('plugin/xlwsq_es', 'bbsmianyi');}
		  if($fenlei==1){
                $bbsinfo=$info.'[hr]'.$bbspic1.$bbspic2.$bbspic3.$bbspic4.$bbspic5.'[hr][table=100%][tr][td=15%][b]'.lang('plugin/xlwsq_es', 'bbsxinjiuchengdu').'[/b][/td][td=30%]'.$chengse.'[/td][td=10%][b] '.lang('plugin/xlwsq_es', 'bbsjiage').'[/b][/td][td=30%]'.$bbsprice.'[/td][/tr][tr][td][b]'.lang('plugin/xlwsq_es', 'bbslianxiren').'[/b][/td][td]'.$lianxiren.'[/td][td][b]'.lang('plugin/xlwsq_es', 'bbsdianhua').'[/b][/td][td]'.$tel.'[/td][/tr][tr][td][b]QQ [/b][/td][td]'.$qq.'[/td][td][b]'.lang('plugin/xlwsq_es', 'bbsweixin').'[/b][/td][td]'.$weixin.'[/td][/tr][/table][hr][align=center][url=plugin.php?id=xlwsq_es&mod=view&sid='.$sid.']'.lang('plugin/xlwsq_es', 'bbschakan').'[/url][/align]';
          }else{
                $bbsinfo=$info.'[hr]'.$bbspic1.$bbspic2.$bbspic3.$bbspic4.$bbspic5.'[hr][table=100%][tr][td=15%][b]'.lang('plugin/xlwsq_es', 'bbslianxiren').'[/b][/td][td]'.$lianxiren.'[/td][td=15%][b]'.lang('plugin/xlwsq_es', 'bbsdianhua').'[/b][/td][td]'.$tel.'[/td][/tr][tr][td=15%][b]QQ [/b][/td][td]'.$qq.'[/td][td=15%][b]'.lang('plugin/xlwsq_es', 'bbsweixin').'[/b][/td][td]'.$weixin.'[/td][/tr][/table][hr][align=center][url=plugin.php?id=xlwsq_es&mod=view&sid='.$sid.']'.lang('plugin/xlwsq_es', 'bbschakan').'[/url][/align]';
		  }
          DB::query("UPDATE ".DB::table('forum_thread')." SET subject='$title', displayorder='$displayorder' where tid='$tid'");
          DB::query("UPDATE ".DB::table('forum_post')." SET  message='$bbsinfo' where tid='$tid' AND first='1'");
		}
        if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)|| in_array($_G['groupid'], $mianshenhe)) {
				showmessage(lang('plugin/xlwsq_es', 'gengxinok') , 'plugin.php?id=xlwsq_es&mod=view&sid='.$sid , array() , array('alert' => 'right'));
        } else {
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_es&#58;xlwsq_es_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_es', 'yonghufabuxinxinxi') . '</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
            showmessage(lang('plugin/xlwsq_es', 'fabudengdaishenhe') , dreferer());
        }
    }
}elseif($p=='xfjl'){
    $where=$pageadd="";
    $key=stripsearchkey($_GET['key']);
    if($_GET['key']){
	    $where="title like '%".addcslashes(addslashes($key), '%')."%_' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	$uid = intval($_G['uid']);
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_es_record')." WHERE $where uid='$uid'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
       $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_es_record')." WHERE $where uid='$uid' ORDER BY id DESC LIMIT $starts,20");
	   $xiaofei = $xiaofeis = array();
	     while($xiaofei = DB::fetch($query)){
		   $xiaofeis[] = $xiaofei;
	     }
    }
	$multis = "<div class='pages cl' style='margin-top:10px'>".multi($counts, 20, $pages, 'plugin.php?id=xlwsq_es:xlwsq_es_user&p=xfjl'.$pageadd)."</div>";
} elseif ($p == 'favorites') {
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_es_favorites') . " WHERE  $where uid='$uid'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 20;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_favorites') . " WHERE  $where uid = '$uid' ORDER BY dateline DESC LIMIT $starts,20");
        $sc = $scs = array();
        while ($sc = DB::fetch($query)) {
            $scs[] = $sc;
        }
    }
    $multis = "<div class='pages cl'style='margin-top:10px'>" . multi($counts, 20, $pages, 'plugin.php?id=xlwsq_es:xlwsq_es_user&p='.$p. $pageadd) . "</div>";
} elseif ($p == 'favoritesdel') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if ($_GET['formhash'] == FORMHASH) {
        DB::query("DELETE FROM " . DB::table('plugin_xlwsq_es_favorites') . " WHERE id = '$id' and uid = '$uid'");
        showmessage(lang('plugin/xlwsq_es', 'shanchuok') , dreferer());
    }
}elseif($p=='adminpinglun'){
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
		$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_es_post'));
		$pager = intval($_GET['page']);
		$pager = max($pager, 1);
		$starts = ($pager - 1) * 30;
		if($countr) {
			$rs=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_es_item')." a, ".DB::table('plugin_xlwsq_es_post')." b WHERE  a.id = b.sid ORDER BY b.dateline DESC LIMIT $starts,30");
			while ($rw=DB::fetch($rs)){
				$manylist[]=$rw;
			}
		}
		$multir = "<div class='pages cl' style='margin-top:10px;'>".multi($countr, 30, $pager, 'plugin.php?id=xlwsq_es:xlwsq_es_user&p=adminpinglun')."</div>";
	}else{
		   showmessage(lang('plugin/xlwsq_es', 'caozuocuowu'));
	}
	if(submitcheck('applysubmdel')){
		$aid = intval($_GET['aid']);
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
           $aid = intval($aid);
           $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_es_post')." where id = '$aid'");
		   $pid = $pl['bbspid'];
		   DB::query("DELETE a,b FROM " . DB::table('plugin_xlwsq_es_post') . " AS a LEFT JOIN " . DB::table('forum_post') . " AS b ON a.bbspid = b.pid WHERE a.bbspid = '$pid' ");
		   $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_es_post')." WHERE sid='$pl[sid]'");
           DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET `dpcount` = '$dpcount' WHERE id = '$pl[sid]'");
		   $nums++;
		}
            showmessage(lang('plugin/xlwsq_es', 'shanchuok'), dreferer());
    }

} elseif ($p == 'sold') {
    $uid = intval($_G['uid']);
    $sid = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id='$sid'");
    if (($active['uid']==$uid && !empty($active['uid']))||$_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        if ($_GET['formhash'] == FORMHASH) {
            if ($active['sold']==4) {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET sold='0',chengjiaoshijian='0'  WHERE id='$sid'");
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET sold='4',chengjiaoshijian='$_G[timestamp]' WHERE id='$sid'");
            }
                showmessage(lang('plugin/xlwsq_es', 'gengxinok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_es', 'caozuocuowu'));
    }
} elseif ($p == 'shenheok') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $sid = intval($_GET['sid']);
		$active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id='$sid'");
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET display='1' WHERE id='$sid'");
            DB::query("UPDATE " . DB::table('forum_thread') . " SET displayorder='0' WHERE tid='$active[bbstid]'");
            showmessage(lang('plugin/xlwsq_es', 'shenheok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_es', 'caozuocuowu'));
    }
 
} elseif ($p == 'qxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $sid = intval($_GET['sid']);
		$active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id='$sid'");
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET display='0' WHERE id='$sid'");
            DB::query("UPDATE " . DB::table('forum_thread') . " SET displayorder='-2' WHERE tid='$active[bbstid]'");
            showmessage(lang('plugin/xlwsq_es', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_es', 'caozuocuowu'));
    }
} elseif ($p == 'onekeydel') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins) && $_GET['formhash'] == FORMHASH) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE (endtime != 0 && endtime < $_G[timestamp]) && sold != '4' ");
		while ($daoqi = DB::fetch($query)) {
		    for ($i = 1; $i <= 5; $i++) {
                $pic = 'pic'.$i;
		        unlink($daoqi[$pic]);
            }
			if ($daoqi["spic"]!=false){
			   unlink($daoqi["spic"]);
			}
            DB::query("DELETE a,b,c FROM " . DB::table('plugin_xlwsq_es_item') . " AS a LEFT JOIN ". DB::table('plugin_xlwsq_es_favorites') . " AS b ON b.sid = a.id LEFT JOIN " . DB::table('plugin_xlwsq_es_post') . " AS c ON c.sid = a.id  WHERE a.id = '$daoqi[id]' ");
			DB::query("DELETE a,b FROM " . DB::table('forum_thread') . " AS a LEFT JOIN " . DB::table('forum_post') . " AS b ON a.tid = b.tid WHERE a.tid = '$daoqi[bbstid]' ");
        }
        showmessage(lang('plugin/xlwsq_es', 'shanchuok') , dreferer());
    } else {
        showmessage(lang('plugin/xlwsq_es', 'caozuocuowu'));
    }
} elseif ($p == 'del') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id ='$id'");
    $tid = intval($active['bbstid']);
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||($active['uid']==$uid && !empty($active['uid']))||(empty($active['uid']) && $active['password']==$_GET['password'])) {
        if ($_GET['formhash'] == FORMHASH) {
            for ($i = 1; $i <= 5; $i++) {
               $pic = 'pic'.$i;
		       unlink($active[$pic]);
            }
			if ($active["spic"]!=false){
			   unlink($active["spic"]);
			}
            DB::query("DELETE a,b FROM " . DB::table('plugin_xlwsq_es_item') . " AS a LEFT JOIN " . DB::table('plugin_xlwsq_es_post') . " AS b ON a.id = b.sid  WHERE a.id = '$id' ");
			DB::query("DELETE a,b FROM " . DB::table('forum_thread') . " AS a LEFT JOIN " . DB::table('forum_post') . " AS b ON a.tid = b.tid WHERE a.tid = '$tid' ");
            showmessage(lang('plugin/xlwsq_es', 'shanchuok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_es', 'caozuocuowub'));
    }
//banner
}elseif($p=='banner'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $where=$pageadd="";
    if($_GET['key']){
      $key=stripsearchkey($_GET['key']);
	  $where=" where title like '%".addcslashes(addslashes($key), '%_')."%'";
	  $keync=urlencode($key);
	  $pageadd="&key=$keync";
    }
	$count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_es_banner').$where);
    $pager = intval($_GET['page']);
    $pager = max($pager, 1);
    $starts = ($pager - 1) * 10;
     if ($count) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_banner') . " $where ORDER BY diynum DESC,id DESC LIMIT $starts,10");
        while ($manylist = DB::fetch($query)) {
                $manylists[] = $manylist;
        }
     }
    $multis = "<div class='pages cl' style='margin:10px 0;'>" . multi($count, 10, $pager, 'plugin.php?id=xlwsq_es:xlwsq_es_user&p=' .$p . $pageadd) . "</div>";
  }else{
		showmessage(lang('plugin/xlwsq_es', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
  }
}elseif($p=='banneradd'){	
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	    if(submitcheck('addbannersubmit')){
			$title = strip_tags(daddslashes($_GET['title']));
            $pic = strip_tags(daddslashes($_GET['pic']));
            $url = strip_tags(daddslashes($_GET['url']));
            $display = intval($_GET['display']);
            $diynum = intval($_GET['diynum']);
			if($_FILES['file']['error']==0){
				$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
				$arr=explode(".", $_FILES["file"]["name"]);
				$hz=$arr[count($arr)-1];
				if(!in_array($hz, $filetype)){
					showmessage(lang('plugin/xlwsq_es', 'tupiangeshibuzhengque'));	
				}
			    $imageinfo = getimagesize($_FILES['file']['tmp_name']);
				if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_es', 'tupiangeshibuzhengque'));
			    }
				$filepath = "source/plugin/xlwsq_es/banner/";
				$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
				if(!file_exists($filepath)){ mkdir($filepath); }			
				if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					@unlink($_FILES['file']['tmp_name']);
				}
				$pic = "source/plugin/xlwsq_es/banner/".$randname."";
			}
		    DB::insert('plugin_xlwsq_es_banner',array('id' => '','title' => $title,'pic' => $pic,'url' => $url,'diynum' => $diynum,'display' => $display, 'dateline' => $_G['timestamp']));
		    showmessage(lang('plugin/xlwsq_es', 'fabuchenggong'), "plugin.php?id=xlwsq_es:xlwsq_es_user&p=banner", array(), array('alert' => 'right'));
	    }

    }else{
		showmessage(lang('plugin/xlwsq_es', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
    }
}elseif($p=='banneredit'){	
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id=intval($_GET['bid']);
	    $active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_es_banner')." WHERE id ='$id'");
	    if(submitcheck('editbannersubmit')){
			$title = strip_tags(daddslashes($_GET['title']));
            $pic = strip_tags(daddslashes($_GET['pic']));
            $url = strip_tags(daddslashes($_GET['url']));
            $display = intval($_GET['display']);
            $diynum = intval($_GET['diynum']);
			if($_FILES['file']['error']==0){
                if ($active["pic"]!=false){
	                unlink($active["pic"]);
	            }
				$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
				$arr=explode(".", $_FILES["file"]["name"]);
				$hz=$arr[count($arr)-1];
				if(!in_array($hz, $filetype)){
					showmessage(lang('plugin/xlwsq_es', 'tupiangeshibuzhengque'));	
				}
			    $imageinfo = getimagesize($_FILES['file']['tmp_name']);
				if ($imageinfo[0] <= 0) {
                    showmessage(lang('plugin/xlwsq_es', 'tupiangeshibuzhengque'));
				}
				$filepath = "source/plugin/xlwsq_es/banner/";
				$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
				if(!file_exists($filepath)){ mkdir($filepath); }
					if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
						@unlink($_FILES['file']['tmp_name']);
				}
				$pic = "source/plugin/xlwsq_es/banner/".$randname."";
			}
		    DB::update('plugin_xlwsq_es_banner',array('title' => $title,'pic' => $pic,'url' => $url,'display' => $display,'diynum' => $diynum),"id='$id'");
		    showmessage(lang('plugin/xlwsq_es', 'fabuchenggong'), dreferer());
	    }
    }else{
	    showmessage(lang('plugin/xlwsq_es', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
    }
}elseif ($p=='bannerdel'){
    if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id=intval($_GET['bid']);
        if($_GET['formhash'] == FORMHASH) {
			$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_es_banner')." WHERE id ='$id'");
			if ($active["pic"]!=false){
		    unlink($active["pic"]);
	        }
	       DB::query("DELETE FROM ".DB::table('plugin_xlwsq_es_banner')." WHERE id = '$id'");
           showmessage(lang('plugin/xlwsq_es', 'shanchuok'), 'plugin.php?id=xlwsq_es:xlwsq_es_user&p=banner', array(), array('alert' => 'right'));
        }
    }else{
        showmessage(lang('plugin/xlwsq_es', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
    }
}
include (template("xlwsq_es:xlwsq_es_user"));
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
//From: d'.'is'.'m.ta'.'obao.com
?>