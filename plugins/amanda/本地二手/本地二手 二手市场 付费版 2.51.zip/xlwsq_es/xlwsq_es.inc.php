<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
global $_G;
if (!isset($_G['cache']['plugin'])) {loadcache('plugin');}
$plyes=($_G['cache']['plugin']['xlwsq_es']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
if($_G['mobile']) {
   $menubgcolor=$mobilemenubgcolor;
   $eacha=$mobileeacha ? $mobileeacha : $eacha;
   $footad=$mobilefootad ? $mobilefootad : $footad;
}
$bannerheight = intval($bannerheight);
$mobilebannerheight = intval($mobilebannerheight);
$fabuset = unserialize($groups);
$viewgroups = unserialize($viewgroups);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$navtitle = $title;
$creditc = abs($creditc);
$creditd = abs($creditd);
$secondhandchengse = parconfig($chengse);
$_G['uid'] = $_G['uid'] ? $_G['uid'] : '0';
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if (!in_array($_G['groupid'], $viewgroups) && $_G['groupid'] != "1" && !in_array($_G['uid'], $admins)) {
    showmessage(lang('plugin/xlwsq_es', 'wuquanxianfangwen') , '', array() , array('login' => true));
}
if($mod == 'index') {
    @require_once DISCUZ_ROOT.'source/plugin/xlwsq_es/function/function_core.php';
    $where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    if ($key) {
		$where="title like '%".addcslashes(addslashes($key), '%_')."%' AND display!='0' OR info like '%" . addcslashes(addslashes($key), '%_') . "%'  AND display!='0' AND";
        $keync = urlencode($key);
        $pageadd = "&key=$keync";
    }elseif($_GET['uid']){
		$fuid=intval(trim($_GET['uid']));
		$where="uid='$fuid' AND";
	    $fuidnc=urlencode($fuid);
	    $pageadd="&uid=$fuidnc";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$cate_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
    }
    $sd = intval($_GET['b']);
    if ($sd) {
        $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$sd'");
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
    }
    $b_area_id = intval($_GET['bc']);
    if ($b_area_id) {
        $marea = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id = '$b_area_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id='$b_area_id'");
        if ($subids) {
            $b_area = "area IN ($b_area_id,$subids) AND";
        } else {
            $b_area = "area=$b_area_id AND";
        }
        $pageaddbc = "&bc=$b_area_id";
    }
    $s_area_id = intval($_GET['sc']);
    if ($s_area_id) {
        $mareab = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id = '$s_area_id'");
        $s_area = "area='$s_area_id' AND";
        $pageaddsc = "&sc=$s_area_id";
    }
	$chengse=intval($_GET['chengse']);
    if ($chengse){
	    $css="chengse='$secondhandchengse[$chengse]' AND chengse!='' AND";
	    $pagecs="&cs=$chengse";
    }
    $fenlei = intval($_GET['type']);
    if ($fenlei){
		$type = "fenlei = '$fenlei' AND";
		$pageaddt="&type=$fenlei";
    }
    if ($guoqixianshi==0){
		$daoqishijian = "AND (endtime = 0 OR endtime > $_G[timestamp])";
    }
    if ($_GET['tj']) {
		$px="tuijian = '1' AND display ='1' $daoqishijian ORDER BY top DESC,diynum DESC,dateline DESC"; $pageadd="&tj=t";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE $where $wb $wc $b_area $s_area $css $type tuijian = '1' AND display ='1' $daoqishijian");
    }elseif ($_GET['jg']) {
		$px="display ='1' AND price>'0' $daoqishijian ORDER BY price ASC,diynum DESC,dateline DESC"; $pageadd="&jg=jg";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE $where $wb $wc $b_area $s_area $css $type display ='1' AND price>'0' $daoqishijian");
    }elseif ($_GET['hjg']) {
		$px="display ='1' AND price>'0' $daoqishijian ORDER BY price DESC,diynum DESC,dateline DESC"; $pageadd="&hjg=hjg";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE $where $wb $wc $b_area $s_area $css $type display ='1' AND price>'0' $daoqishijian");
    }elseif ($_GET['rq']) {
		$px="display ='1' $daoqishijian ORDER BY view DESC,diynum DESC,dateline DESC"; $pageadd="&rq=rq";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE $where $wb $wc $b_area $s_area $css $type display ='1' $daoqishijian");
	}else{
		$px="display ='1' $daoqishijian ORDER BY top DESC,topdateline DESC,diynum DESC,updateline DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE $where $wb $wc $b_area $s_area $css $type display ='1'  $daoqishijian");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE $where $wb $wc $b_area $s_area $css $type $px LIMIT $starts,$eacha");
        $mythread = $mythreads = array();
        while ($mythread = DB::fetch($query)) {
            if ($mythread['topdateline']!='0'){DB::query("UPDATE ".DB::table('plugin_xlwsq_es_item')." SET `topdateline` = '0',`color` = '' WHERE topdateline!= '0' AND topdateline <= ".$_G['timestamp']);}
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$cate[upid]'");
                $mythread['cate'] = $cate_t['subject'].'-'.$cate['subject'];
            } else {
                $mythread['cate'] = $cate['subject'];
            }
            $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id = '$mythread[area]'");
            if ($area['upid'] != 0) {
                $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id = '$area[upid]'");
                $mythread['area'] = $area_t['subject'].'-'.$area['subject'];
            } else {
                $mythread['area'] = $area['subject'];
            }
			    $mythread['dinfo'] = discuzcode($mythread['info']);
			    $mythread['info'] = strip_tags(discuzcode($mythread['info']));
			    $mythread['title']=str_replace($key,"<font color='#ff0000'>$key</font>",$mythread['title']);
			    $mythread['price'] = setmoneyUnit($mythread['price']);
                $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px 10px 10px 0;'>" . multi($counts, $eacha, $pages, 'plugin.php?id=xlwsq_es' . $pageadd. $pageadds . $pageaddx . $pageaddbc . $pageaddsc.$pagecs.$pageaddt) . "</div>";
    $r_id = intval($_GET['a']);
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    $bc_id = intval($_GET['bc']);
    $bc_subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id='$bc_id'");
    if ($bc_subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id IN ($bc_subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $local_sc[$ros['id']] = $ros;
        }
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_es_banner')." WHERE display!='0' ORDER BY diynum DESC,id DESC");
	while($banner = DB::fetch($query)){
		$banners[] = $banner;
	}
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . " - " . $mcateb['subject']. " - ";
      } else {
           $catenav = $mcate['subject']. " - ";
      }
    }
    if ($b_area_id!='0') {
      if ($s_area_id!='0') {
           $areanav = $marea['subject'] . " - " . $mareab['subject']. " - ";
      } else {
           $areanav = $marea['subject']. " - ";
      }
    }
    $navtitle = $catenav . $areanav.$navtitle;
    include template('xlwsq_es:list');
} elseif ($_GET['mod'] == 'view') {
    $sid = intval($_GET['sid']);
    if($_G['groupid']==1 || in_array($_G['uid'], $admins)){
	   $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id = '$sid'");
	}else{
	   $mythread = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_es_item')." WHERE id = '$sid' AND display!='0'");
	}
    !$mythread ? showmessage(lang('plugin/xlwsq_es', 'error') , "plugin.php?id=xlwsq_es") : '';
    DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET `view` = view+1 WHERE `id` = '$sid'");
    $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_favorites') . " WHERE sid = '$sid' AND uid = '$_G[uid]'");
	$mythread['fabushu']= DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_es_item')." WHERE uid='$mythread[uid]' AND  display!='0'");
    $mythread['info'] = discuzcode($mythread['info']);
    $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$mythread[cate]'");
	if ($cate['upid'] != 0) {
        $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$cate[upid]'");
        $mythread['cate'] = $cate_t['subject'] . " - " . $cate['subject'];
    } else {
        $mythread['cate'] = $cate['subject'];
    }
    $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id = '$mythread[area]'");
    if ($area['upid'] != 0) {
        $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_area') . " WHERE id = '$area[upid]'");
        $mythread['area'] = $area_t['subject'] . " - " . $area['subject'];
    } else {
        $mythread['area'] = $area['subject'];
    }
    if ($guoqixianshi==0){
		$daoqishijian = "AND (endtime = 0 OR endtime > $_G[timestamp])";
    }
    if ($mythread['fenlei']==1){
		$navfenlei = lang('plugin/xlwsq_es', 'chushou');
    }else{
		$navfenlei = lang('plugin/xlwsq_es', 'qiugou');
	}
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE tuijian ='1' AND display!='0' $daoqishijian  ORDER BY updateline DESC,dateline DESC LIMIT 10");
    $tuijian = $tuijians = array();
    while ($tuijian = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$tuijian[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$cate[upid]'");
            $tuijian['cate'] = $cate_t['subject']." - ".$cate['subject'];
        } else {
            $tuijian['cate'] = $cate['subject'];
        }
		$tuijian['price'] = setmoneyUnit($tuijian['price']);
        $tuijians[] = $tuijian;
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE view >'0' AND display!='0' $daoqishijian ORDER BY view DESC LIMIT 10");
    $hot = $hots = array();
    while ($hot = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$hot[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$cate[upid]'");
            $hot['cate'] = $cate_t['subject']." - ".$cate['subject'];
        } else {
            $hot['cate'] = $cate['subject'];
        }
		$hot['price'] = setmoneyUnit($hot['price']);
        $hots[] = $hot;
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_es_item')." WHERE uid ='$mythread[uid]' AND display!='0' $daoqishijian ORDER BY updateline DESC,dateline DESC LIMIT 10");
	$new = $news = array();
	while($new = DB::fetch($query)){
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$new[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_cate') . " WHERE id = '$cate[upid]'");
            $new['cate'] = $cate_t['subject']." - ".$cate['subject'];
        } else {
            $new['cate'] = $cate['subject'];
        }
		$new['price'] = setmoneyUnit($new['price']);
		$news[] = $new;
	}
    if(submitcheck('applysubmit')){	
	   if($pinglunset==0){
	 	       showmessage(lang('plugin/xlwsq_es', 'liuyanguanbitishi'), array(), array('alert' => 'error'));
	   }
	   $uid = intval($_G['uid']);
	   if($youkepinglunset==1){
        !$_G['uid'] ? $_G['username'] = $_G['clientip'] :'';
       }else{
	        if(!$_G['uid']){
	 	       showmessage(lang('plugin/xlwsq_es', 'youkewuquanxianpinglun'), array(), array('alert' => 'error'));
	        }
       }
	   if(empty($_GET['message'])){
		    showmessage(lang('plugin/xlwsq_es', 'wupinglunneirong'), dreferer());
	   }else{
			$author = $_G['username'];
		    $message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
			$display = 1; 
            $pid = DB::insert('forum_post_tableid', array('pid'=>NULL), true);
            $fid = $bbsfid;
			$tid = $mythread['bbstid'];
			DB::insert('plugin_xlwsq_es_post',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $author,'message' => $message,'bbspid' => $pid,'display' => $display,'dateline' => $_G['timestamp']));
			$dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_es_post')." WHERE sid='$sid'"); 
            DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET `dpcount` = '$dpcount' WHERE `id` = '$sid'");
            $systemmessage = '<a href="plugin.php?id=xlwsq_es&mod=view&sid='.$sid.'" target="_blank">'.lang('plugin/xlwsq_es', 'liuyantishi').$mythread['title']. '</a>';
			if($mythread['uid']){
				notification_add($mythread['uid'], 'system', $systemmessage, $notevars = array() , $system = 0);
			}
			if($fid!=0){
                $active = DB::fetch_first("SELECT * FROM " . DB::table('forum_post') . " WHERE tid='$tid'");
                if($active['tid']){
				    DB::query("INSERT INTO ".DB::table('forum_post')." (pid, fid, tid, first, author, authorid, dateline, message) VALUES ('$pid', '$fid', '$tid', '0', '$_G[username]', $_G[uid], '$_G[timestamp]', '$message')");
				}
			}
		}
		showmessage(lang('plugin/xlwsq_es', 'tijiaochenggong'),dreferer());
    }
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_es_post')." WHERE sid='$sid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_es_post')." WHERE sid='$sid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$pl = $pls = array();
		while($pl = DB::fetch($query)) {
			$pls[] = $pl;
		}
			$pls = dhtmlspecialchars($pls);
	}
	$multi = "<div class='pages cl'>".multi($count, $each, $page,'plugin.php?id=xlwsq_es&mod=view&sid='.$sid.'')."</div>";

    if($_GET['pinglun'] == 'del'){
	    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
        $uid = intval($_G['uid']);
	    $did = intval($_GET['did']);
        $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_es_post')." where id = '$did'");
	    $pid = $pl['bbspid'];
	    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$pl['uid']==$uid||$mythread['uid']==$uid) {
            if ($_GET['formhash'] == FORMHASH) {
                DB::query("DELETE a,b FROM " . DB::table('plugin_xlwsq_es_post') . " AS a LEFT JOIN " . DB::table('forum_post') . " AS b ON a.bbspid = b.pid WHERE a.bbspid = '$pid' ");
				$dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_es_post')." WHERE sid='$sid'"); 
                DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET `dpcount` = '$dpcount' WHERE `id` = '$sid'");
	            showmessage(lang('plugin/xlwsq_es', 'shanchuok'), dreferer());
            }
	    }else{
	            showmessage(lang('plugin/xlwsq_es', 'wuquanxiancaozuo'));
	    }
    }
    $navtitle = $navfenlei.$mythread['title'] . " - " . $title;
	$metakeywords = $mythread['title'];
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($mythread['info']) , 80, '...'));
    include template('xlwsq_es:view');
} elseif ($_GET['mod'] == 'zhiding') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditc == '0'||!$paytype){showmessage(lang('plugin/xlwsq_es', 'zhidinggongnengweikaifang'));}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id = '$sid'");
    if($item['top']=="1"){
		showmessage(lang('plugin/xlwsq_es', 'yizhiding'), array(), array('alert' => 'error'));
	}
    $color = dhtmlspecialchars($_GET['topcolor']);
	$daytime = intval($_GET['day']);
	$time = ($daytime * 86400)+$_G['timestamp']; 
    $newcreditc = $daytime * $creditc; 
    $moneytypec = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubzhiding')){
	    if($_GET['day']<="0"){	
		    showmessage(lang('plugin/xlwsq_es', 'zhidingtianshuweitianxie'), dreferer());
	    }else{
            if($paymoney<$newcreditc){
                $tixing= lang('plugin/xlwsq_es', 'zhidingxiaohaotishi').$newcreditc.$moneytypec;
        	    showmessage($tixing);
            }else{
                DB::insert('plugin_xlwsq_es_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'day' => $daytime,'pay' => $newcreditc,'moneytype' => $moneytypec,'xftype' => '2','endtime' => $time,'dateline' =>$_G['timestamp']));
				DB::query("UPDATE ".DB::table('plugin_xlwsq_es_item')." SET `topdateline` = '$time' , `color` = '$color' WHERE `id` = '$sid'");	                   updatemembercount($_G['uid'], array($paytype => -$newcreditc));
            }
			showmessage(lang('plugin/xlwsq_es', 'tijiaochenggong'),dreferer());
	    }
	}
	include template('xlwsq_es:zhiding');
} elseif ($_GET['mod'] == 'miaoshen') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditd == '0'||!$paytype){showmessage(lang('plugin/xlwsq_es', 'miaoshenweikaiqi'));}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id = '$sid'");
    if($item['display']=="1"){
		showmessage(lang('plugin/xlwsq_es', 'miaoshentongguo'), array(), array('alert' => 'error'));
	}
    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubmiaoshen')){
        if($paymoney<$creditd){
            $tixing= lang('plugin/xlwsq_es', 'miaoshenshibai').$creditd.$moneytype;
        	showmessage($tixing);
        }else{
			DB::query("UPDATE ".DB::table('plugin_xlwsq_es_item')." SET `display` = '1' WHERE `id` = '$sid'");
		    updatemembercount($_G['uid'], array($paytype => -$creditd));
			DB::insert('plugin_xlwsq_es_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'pay' => $creditd,'moneytype' => $moneytype,'xftype' => '4','dateline' =>$_G['timestamp']));
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_es&mod=view&sid='.$item[id].'" target="_blank">'.lang('plugin/xlwsq_es', 'miaoshenweisend').$item[title].'</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
		    if($_G['mobile']) {
                showmessage(lang('plugin/xlwsq_es', 'tijiaochenggong') , 'plugin.php?id=xlwsq_es:xlwsq_es_user&amp;p=mylist', array() , array('alert' => 'right'));
		   	} else {
                showmessage(lang('plugin/xlwsq_es', 'tijiaochenggong'),dreferer());
		    }
        }
	}
	include template('xlwsq_es:miaoshen');
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
        $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id = '$sid'");
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_es_favorites') . " WHERE sid = '$sid' and uid = '$uid'");
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_es', 'quxiaoshoucang'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_es', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
			}
        } else {
            DB::insert('plugin_xlwsq_es_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'title' => $info['title'],'dateline' => $_G['timestamp']));
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_es', 'shoucangchenggong'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_es', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
			}
            
        }
    }
} elseif ($_GET['mod'] == 'freshen') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $now = date('Y-m-d', $_G['timestamp']);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id = '$sid'");
    $uid = intval($info['uid']);
    $updateline = date('Y-m-d', $info['updateline']);
    if ($_GET['formhash'] == FORMHASH) {
        if ($info['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
            if ($now == $updateline) {
                showmessage(lang('plugin/xlwsq_es', 'shuaxinshibai') , '', array() , array('alert' => 'error'));
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_es_item') . " SET `updateline` = '$_G[timestamp]' WHERE `id` = '$sid'");
                DB::insert('plugin_xlwsq_es_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'title' => $info['title'],'author' => $_G['username'],'xftype' => '3','dateline' =>$_G['timestamp']));
                showmessage(lang('plugin/xlwsq_es', 'shuaxinok') , '', array() , array('alert' => 'right'));
            }
        } else {
            showmessage(lang('plugin/xlwsq_es', 'caozuocuowu') , dreferer());
        }
    }
}elseif($_GET['mod']=='renling'||$_GET['mod']=='youkedel'){
   if($_GET['mod']=='renling'){!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';}
   $sid = intval($_GET['sid']);
   $password = dhtmlspecialchars($_GET['password']);
   $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_es_item') . " WHERE id = '$sid'");
   !$info ? showmessage(lang('plugin/xlwsq_es', 'error') , "plugin.php?id=xlwsq_es") : '';
   if(submitcheck('applysubrenling')){
       if($password == $info['password']){
          DB::update('plugin_xlwsq_es_item', array('password' => '','uid' => $_G['uid'],'author' => $_G['username']),"id='$sid'");
          showmessage(lang('plugin/xlwsq_es', 'renlingchenggong'), 'plugin.php?id=xlwsq_es', array(), array('alert' => 'right'));
       }else{
          showmessage(lang('plugin/xlwsq_es', 'koulingcuowu'));
       }
   }    
   include template('xlwsq_es:kouling');
}elseif($_GET['mod']=='qrpic'){
    include_once 'source/plugin/xlwsq_es/class/qrcode.class.php';
	$sid = intval($_GET['sid']);
	  if($html == 1){
         $value=$_G['siteurl'].$mininame.'_'.$sid.'.html';
      }else{
         $value=$_G['siteurl'].'plugin.php?id=xlwsq_es&mod=view&sid='.$sid;
      }
    QRcode::png($value, false,L,6);
}
function setmoneyUnit($nprice) {
    if($nprice >= 10000){
        $showMoeny = (int)($nprice/100);
        return ($showMoeny/100).lang('plugin/xlwsq_es', 'wan');
    }else{
        return  $nprice;
    }
}
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
//From: d'.'is'.'m.ta'.'obao.com
?>