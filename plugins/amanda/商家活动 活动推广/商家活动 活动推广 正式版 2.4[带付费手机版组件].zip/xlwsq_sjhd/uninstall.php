<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
include_once 'source/plugin/xlwsq_sjhd/function/function_core.php';
$catecachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_sjhd_catecachedata.php';
if(file_exists($catecachefile)){@unlink($catecachefile);}
$areacachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_sjhd_areacachedata.php';
if(file_exists($areacachefile)){@unlink($areacachefile);}
$diyfile = DISCUZ_ROOT.'source/class/block/xlwsqsjhd';
if(file_exists($diyfile)){deldir('source/class/block/xlwsqsjhd');}
$sql = <<<EOF
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_item`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_img`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_shopimg`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_cate`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_area`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_record`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_favorites`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_user`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_post`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_yuyue`;
DROP TABLE IF EXISTS `pre_plugin_xlwsq_sjhd_rl`;
EOF;
runquery($sql);
$finish = TRUE;
?>