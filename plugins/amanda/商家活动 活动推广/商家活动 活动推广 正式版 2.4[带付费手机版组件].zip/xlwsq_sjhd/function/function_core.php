<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$catecachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_sjhd_catecachedata.php';
$areacachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_sjhd_areacachedata.php';
if(file_exists($catecachefile)){
		require_once DISCUZ_ROOT.'data/sysdata/cache_xlwsq_sjhd_catecachedata.php';
}else{
	xlwsq_sjhd_updatacatecache();
}
if(file_exists($areacachefile)){
		require_once DISCUZ_ROOT.'data/sysdata/cache_xlwsq_sjhd_areacachedata.php';
}else{
	xlwsq_sjhd_updataareacache();
}
function  xlwsq_sjhd_updatacatecache(){
	require_once libfile('function/cache');
    $typecatequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
    $typecatedata = array();
    $upidcatedata = array();
    while ($typecate = DB::fetch($typecatequery)) {
        $typecatedata[$typecate['id']] = $typecate;
        $upidcatequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " where upid = " . $typecate['id'] . "  ORDER BY displayorder DESC,id ASC");
        while ($upidcate = DB::fetch($upidcatequery)) {
            $upidcatedata[$typecate['id']][$upidcate['id']] = $upidcate;
        }
    }
	writetocache('xlwsq_sjhd_catecachedata', getcachevars(array('typecatedata' => $typecatedata,  'upidcatedata' => $upidcatedata)));
}
function  xlwsq_sjhd_updataareacache(){
	require_once libfile('function/cache');
    $typeareaquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
    $typeareadata = array();
    $upidareadata = array();
    while ($typearea = DB::fetch($typeareaquery)) {
        $typeareadata[$typearea['id']] = $typearea;
        $upidareaquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " where upid = " . $typearea['id'] . "  ORDER BY displayorder DESC,id ASC");
        while ($upidarea = DB::fetch($upidareaquery)) {
            $upidareadata[$typearea['id']][$upidarea['id']] = $upidarea;
        }
    }
	writetocache('xlwsq_sjhd_areacachedata', getcachevars(array('typeareadata' => $typeareadata,  'upidareadata' => $upidareadata)));
}
function deldir($dir) {
  $dh=opendir($dir);
  while ($file=readdir($dh)) {
    if($file!="." && $file!="..") {
      $fullpath=$dir."/".$file;
      if(!is_dir($fullpath)) {
          unlink($fullpath);
      } else {
          deldir($fullpath);
      }
    }
  }
  closedir($dh);
  if(rmdir($dir)) {
    return true;
  } else {
    return false;
  }
}
//From: Dism��taobao��com
?>