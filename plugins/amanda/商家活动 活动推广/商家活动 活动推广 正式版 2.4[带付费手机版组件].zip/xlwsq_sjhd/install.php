<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `sjuid` int(11) NOT NULL,
	  `author` varchar(80) NOT NULL,
	  `cate` int(11) NOT NULL,
	  `area` int(11) NOT NULL,
	  `online` varchar(80) NOT NULL,
	  `title` varchar(100) NOT NULL,
	  `pic` text  NOT NULL,
      `starttime` int(11) NOT NULL,
	  `endtime` int(11) NOT NULL,
	  `beizhu` varchar(80) NOT NULL,
	  `price` varchar(20) NOT NULL,
	  `address` varchar(255)  NOT NULL,
      `lng` varchar(30) NOT NULL,
      `lat` varchar(30) NOT NULL,
	  `info` text NOT NULL,
	  `view` int(11) NOT NULL,
      `yuyue` tinyint(1) NOT NULL,
	  `renshu` int(11) NOT NULL,
	  `yiyuyuerenshu` int(11) NOT NULL,
	  `top` tinyint(1)  NOT NULL,
	  `tuijian` tinyint(1)  NOT NULL,
	  `topdateline` int(11) NOT NULL,
	  `color` varchar(20) NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `updateline` int(11) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`),
      INDEX name (id,sjuid,cate,area)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_img` (
	  `id` int(11) NOT NULL auto_increment,
	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
	  `sjuid` int(11) NOT NULL,
	  `img` text NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`),
      INDEX name (id,sid,uid)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_shopimg` (
	  `id` int(11) NOT NULL auto_increment,
   	  `uid` int(11) NOT NULL,
	  `sjuid` int(11) NOT NULL,
	  `comimg` varchar(255) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`),
      INDEX name (id,sjuid)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_cate` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_area` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_record` (
	  `id` int(11) NOT NULL auto_increment,
      `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `title` text NOT NULL,
   	  `day` int(11) NOT NULL,
   	  `pay` int(11) NOT NULL,
   	  `moneytype` varchar(20) NOT NULL,
   	  `endtime` int(11) NOT NULL,
   	  `paytype` tinyint(1) NOT NULL,
   	  `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_favorites` (
   	  `id` int(11) NOT NULL auto_increment,
   	  `uid` int(11) NOT NULL,
 	  `sid` int(11) NOT NULL,
	  `title` varchar(255) NOT NULL,
   	  `shoucangshijian` int(11) NOT NULL,
      PRIMARY KEY  (`id`),
      INDEX name (sid,uid)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_user` (
   	  `sjuid` int(11) NOT NULL auto_increment,
	  `diynum` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `comname` varchar(80) NOT NULL,
	  `cate` int(11) NOT NULL,
	  `area` int(11) NOT NULL,
   	  `comlogo` text NOT NULL,
   	  `address` varchar(255) NOT NULL,
   	  `lianxiren` varchar(30) NOT NULL,
   	  `tel` varchar(30) NOT NULL,
   	  `fax` varchar(30) NOT NULL,
   	  `qq` varchar(30) NOT NULL,
   	  `weixin` varchar(50) NOT NULL,
   	  `email` varchar(50) NOT NULL,
   	  `cominfo` text NOT NULL,
   	  `homepage` text NOT NULL,
      `lng` varchar(30) NOT NULL,
      `lat` varchar(30) NOT NULL,
      `renling` tinyint(1) NOT NULL,
      `display` tinyint(1) NOT NULL,
   	  `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`sjuid`),
       INDEX name (sjuid,uid)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_post` (
	  `pid` int(11) NOT NULL auto_increment,
	  `sid` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `sjuid` int(11) NOT NULL,
  	  `author` varchar(50) NOT NULL,
  	  `message` text NOT NULL,
  	  `reply` text NOT NULL,
 	  `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`pid`),
       INDEX name (sid,uid)
    ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_yuyue` (
   	  `yyid` int(11) NOT NULL auto_increment,
	  `sid` int(11) NOT NULL,
	  `title` varchar(80) NOT NULL,
   	  `yyuid` int(11) NOT NULL,
   	  `sjuid` int(11) NOT NULL,
   	  `xingming` varchar(30) NOT NULL,
   	  `tel` varchar(30) NOT NULL,
   	  `qq` varchar(30) NOT NULL,
   	  `weixin` varchar(80) NOT NULL,
   	  `qitabeizhu` varchar(255) NOT NULL,
      `starttime` int(11) NOT NULL,
	  `endtime` int(11) NOT NULL,
   	  `yuyeshijian` int(11) NOT NULL,
 	  `jujueliyou` text NOT NULL,
      `display` tinyint(1) NOT NULL,
      PRIMARY KEY  (`yyid`),
      INDEX name (sid,yyuid,sjuid)
    ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_sjhd_rl` (
     `id` int(11) NOT NULL auto_increment,
     `sjuid` int(11) NOT NULL,
	 `comname` varchar(80) NOT NULL,
     `uid` int(11) NOT NULL,
	 `author` varchar(80) NOT NULL,
	 `tel` varchar(20) NOT NULL,
	 `qq` varchar(30) NOT NULL,
   	 `liyou` text NOT NULL,
   	 `dateline` int(11) NOT NULL,
     PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
INSERT INTO `pre_plugin_xlwsq_sjhd_cate` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '', '$installlang[cate1]', 0),
(2, 0, '', '$installlang[cate2]', 0),
(3, 0, '', '$installlang[cate3]', 0),
(4, 0, '', '$installlang[cate4]', 0),
(5, 0, '', '$installlang[cate5]', 0),
(6, 0, '', '$installlang[cate6]', 0),
(7, 0, '', '$installlang[cate7]', 0),
(8, 0, '', '$installlang[cate8]', 0),
(9, 0, '', '$installlang[cate9]', 0);
INSERT INTO `pre_plugin_xlwsq_sjhd_area` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '6', '$installlang[area1]', 0),
(2, 0, '4,5', '$installlang[area2]', 0),
(3, 0, '', '$installlang[area3]', 0),
(4, 2, '', '$installlang[area4]', 0),
(5, 2, '', '$installlang[area5]', 0),
(6, 1, '', '$installlang[area6]', 0);
EOF;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/discuz_plugin_xlwsq_sjhd.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/discuz_plugin_xlwsq_sjhd_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/discuz_plugin_xlwsq_sjhd_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/discuz_plugin_xlwsq_sjhd_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/discuz_plugin_xlwsq_sjhd_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/install.php');
runquery($sql);
$finish =true;
?>