<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOT
ALTER TABLE `pre_plugin_xlwsq_sjhd_yuyue` ADD `jujueliyou` text NOT NULL AFTER `yuyeshijian`,
ADD `display` tinyint(1) NOT NULL AFTER `jujueliyou`;
EOT;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/discuz_plugin_xlwsq_sjhd_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/discuz_plugin_xlwsq_sjhd_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/discuz_plugin_xlwsq_sjhd_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/discuz_plugin_xlwsq_sjhd_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/install.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_sjhd/upgrade.php');
runquery($sql);
$finish = TRUE;
?>