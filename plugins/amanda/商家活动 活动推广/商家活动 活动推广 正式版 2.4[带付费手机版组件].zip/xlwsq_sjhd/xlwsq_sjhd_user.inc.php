<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
require_once 'source/plugin/xlwsq_sjhd/function/function_core.php';
$plyes=($_G['cache']['plugin']['xlwsq_sjhd']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
$catecselect = parconfig($catecselect);
$fabuset = unserialize($groups);
$mianshenhe = unserialize($mianshenhe);
$zuobiao = explode(",",$map_center);
$newpicdx=$picdx*1024;
$navtitle = $title;
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
if($_G['mobile']) {
  $menubgcolor=$plyes['mobilemenubgcolor'];
}else{
  $menubgcolor=$plyes['menubgcolor'];
}
$credit = abs($credit);
$p = $_GET['p'] ? $_GET['p'] : 'index';
if ($p != 'index' && $p != 'add' && $p != 'edit' && $p != 'del') {!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';}
if ($p == 'mylist'||$p == 'index') {
     $where=$pageadd="";
     $uid = intval($_G['uid']);
     $sjuid = intval($_GET['sjuid']);
     if ($sjuid) {
        $shopid = "sjuid='$sjuid' AND ";
	 }
     $sjquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE uid='$uid'");
     while ($sj = DB::fetch($sjquery)) {
        $sjs[] = $sj;
     }
    if($_GET['key']){
       $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE $where $shopid uid='$uid'");
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
    if ($countr) {
         $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE $where $shopid uid='$uid' ORDER BY display ASC,dateline DESC LIMIT $starts,20");
         while ($rw = DB::fetch($rs)) {
             $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$rw[cate]'"));
             if ($pa['upid'] != 0) {
                 $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$pa[upid]'");
                 $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
             } else {
                 $rw['cate'] = $pa['subject'];
             }
             $manylist[] = $rw;
         }
     }
     $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager,'plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=index'. $pageadd) . "</div>";
} elseif ($p == 'myshoplist') {
     $where=$pageadd="";
     if ($_GET['key']) {
            $key=stripsearchkey($_GET['key']);
		    $where="comname like '%".addcslashes(addslashes($key), '%')."%' AND";
            $keync = urlencode($key);
            $pageadd = "&key=$keync";
     }
	 $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE $where uid='$_G[uid]'");
     $pages = intval($_GET['page']);
     $pages = max($pages, 1);
     $starts = ($pages - 1) * 20;
     if ($counts) {
            $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE $where uid='$_G[uid]' ORDER BY sjuid DESC LIMIT $starts,20");
            while ($rw = DB::fetch($query)) {
               $manylist[] = $rw;
            }
    }
    $multis = "<div class='pages cl' style='margin-top:10px'>" . multi($counts,20,$pages,"plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=myshoplist$pageadd")."</div>";
} elseif ($p == 'adminalllist') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $where=$pageadd="";
        if($_GET['key']){
          $key=stripsearchkey($_GET['key']);
	      $where=" where title like '%".addcslashes(addslashes($key), '%')."%'";
	      $keync=urlencode($key);
	      $pageadd="&key=$keync";
        }
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_item').$where);
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . "  $where ORDER BY display ASC,dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager, "plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=adminalllist". $pageadd) . "</div>";
    } else {
        showmessage(lang('plugin/xlwsq_sjhd', 'wuquanxiancaozuo') , '', array() , array('alert' => 'error'));
    }
    if (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_item') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_item') . " SET display='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok') , dreferer());
	}elseif(submitcheck('applysubmtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_sjhd_item')." SET tuijian='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok'), dreferer());
	}elseif(submitcheck('applysubmqxtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_sjhd_item')." SET tuijian='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok'), dreferer());	
    } elseif (submitcheck('applysubmzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_item') . " SET top='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_item') . " SET top='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id ='$aid'LIMIT 0 , 1");
            if ($active["pic"] != false) {
                unlink($active["pic"]);
            }
	        $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_sjhd_img')." WHERE sid = '$aid'");
	        $delz = $delzs = array();
	        while($delz = DB::fetch($query)){
		        if ($delz["img"]!=false){
			      unlink($delz["img"]);
		        }
		        $delzs[] = $delz;
	        }
            DB::query("DELETE a,b,c FROM " . DB::table('plugin_xlwsq_sjhd_item')." AS a LEFT JOIN ". DB::table('plugin_xlwsq_sjhd_img') . " AS b ON b.sid = a.id LEFT JOIN ".DB::table('plugin_xlwsq_sjhd_post') . " AS c ON c.sid = a.id  WHERE a.id = '$aid' ");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_sjhd', 'shanchuok') , dreferer());
    }
} elseif ($p == 'adminshoplist') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $where=$pageadd="";
        if ($_GET['key']) {
            $key=stripsearchkey($_GET['key']);
		    $where=" WHERE comname like '%".addcslashes(addslashes($key), '%')."%'";
            $keync = urlencode($key);
            $pageadd = "&key=$keync";
        }
	    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_user').$where);
        $pages = intval($_GET['page']);
        $pages = max($pages, 1);
        $starts = ($pages - 1) * 20;
        if ($counts) {
            $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " $where ORDER BY display ASC,sjuid DESC  LIMIT $starts,20");
            while ($rw = DB::fetch($query)) {
               $manylist[] = $rw;
            }
        }
        $multis = "<div class='pages cl' style='margin-top:10px'>" . multi($counts,20,$pages,"plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=adminshoplist$pageadd")."</div>";
		if (submitcheck('applysubmsh')) {
           $pl_id = implode('|', $_GET['piliang']);
           $deid = explode('|', $pl_id);
           $nums = 0;
           foreach ($deid as $aid) {
              $sjuid = intval($aid);
              DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_user') . " SET display='1' WHERE sjuid='$sjuid' LIMIT 1");
              $nums++;
           }
           showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok') , dreferer());
        } elseif (submitcheck('applysubmqxsh')) {
           $pl_id = implode('|', $_GET['piliang']);
           $deid = explode('|', $pl_id);
           $nums = 0;
           foreach ($deid as $aid) {
              $sjuid = intval($aid);
              DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_user') . " SET display='0' WHERE sjuid='$sjuid' LIMIT 1");
              $nums++;
           }
           showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok') , dreferer());
        } elseif (submitcheck('applysubkrl')) {
           $pl_id = implode('|', $_GET['piliang']);
           $deid = explode('|', $pl_id);
           $nums = 0;
           foreach ($deid as $aid) {
              $sjuid = intval($aid);
              DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_user') . " SET renling='1' WHERE sjuid='$sjuid' LIMIT 1");
              $nums++;
           }
           showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok') , dreferer());
        } elseif (submitcheck('applysubbkrl')) {
           $pl_id = implode('|', $_GET['piliang']);
           $deid = explode('|', $pl_id);
           $nums = 0;
           foreach ($deid as $aid) {
              $sjuid = intval($aid);
              DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_user') . " SET renling='0' WHERE sjuid='$sjuid' LIMIT 1");
              $nums++;
           }
           showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok') , dreferer());
        } elseif (submitcheck('applysubmdel')) {
           $pl_id = implode('|', $_GET['piliang']);
           $deid = explode('|', $pl_id);
           $nums = 0;
           foreach ($deid as $aid) {
              $sjuid = intval($aid);
              deldir("source/plugin/xlwsq_sjhd/upimg/".$sjuid);
              DB::query("DELETE a,b,c,d,e FROM " . DB::table('plugin_xlwsq_sjhd_user') . " AS a LEFT JOIN " . DB::table('plugin_xlwsq_sjhd_item') . " AS b ON a.sjuid = b.sjuid LEFT JOIN " . DB::table('plugin_xlwsq_sjhd_img') . " AS c ON c.sjuid = b.sjuid LEFT JOIN " . DB::table('plugin_xlwsq_sjhd_post') . " AS d ON d.sid = b.id LEFT JOIN " . DB::table('plugin_xlwsq_sjhd_shopimg') . " AS e ON e.sjuid = a.sjuid WHERE a.sjuid = '$sjuid' ");
              $nums++;
           }
           showmessage(lang('plugin/xlwsq_sjhd', 'shanchuok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_sjhd', 'wuquanxiancaozuo') , dreferer());
    }
} elseif ($p == 'add') {
    include_once 'source/plugin/xlwsq_sjhd/class/upic.class.php';
    $uid = intval($_G['uid']);
    $sjuid = intval($_GET['sjuid']);
    $groups = unserialize($groups);
    if (!in_array($_G['groupid'], $groups)) {
        showmessage(lang('plugin/xlwsq_sjhd', 'wuquanxiancaozuo') , '', array() , array('login' => true));
	}
    if ($sjuid > 0) {
	    $userinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$sjuid' AND uid='$uid'");
        !$userinfo ? showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu') , "plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user") : '';
    }
    $userinfo['lat'] = $userinfo['lat'] ? $userinfo['lat'] : $zuobiao[0];
    $userinfo['lng'] = $userinfo['lng'] ? $userinfo['lng'] : $zuobiao[1];
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id='$userinfo[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $userinfo['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $userinfo['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
      while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
      }
    $areaid = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id='$userinfo[area]'");
    if ($areaid) {
        $areatwoshow = '<select name="area_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE upid='$areaid'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $userinfo['area']) {
                $areatwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $areatwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $areatwoshow.= '</select>';
    } else {
        $areaid = $userinfo['area'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
      while ($row = DB::fetch($query)) {
        $areas[$row['id']] = $row;
      }
    $sjquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE uid='$uid' AND display='1' ORDER BY sjuid DESC");
      while ($sj = DB::fetch($sjquery)) {
        $sjs[] = $sj;
      }
	$moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
    if($credit!="0" && $paytype){
        if($paymoney<$credit){
           $tixing= lang('plugin/xlwsq_sjhd', 'xiaohaotishi').$credit.$moneytype;
           if (empty($chongzhiurl)) {
	           showmessage($tixing, dreferer());
	       }else{
               showmessage($tixing, 'plugin.php?id=xlwsq_sjhd&mod=chongzhi', array() , array('alert' => 'error'));
           }
        }
    }
    if (submitcheck('applysubmit')) {
       $title = dhtmlspecialchars($_GET['title']);
       $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
       $area = intval($_GET['area_two']) ? intval($_GET['area_two']) : intval($_GET['area_1']);
       $pic = dhtmlspecialchars($_GET['pic']);
	   if ($_GET['starttime'] != "") {$starttime=strtotime($_GET['starttime']);}else{$starttime = 0;}
	   if ($_GET['endtime'] != "") {$endtime=strtotime($_GET['endtime']);}else{$endtime = 0;}
       $beizhu = dhtmlspecialchars($_GET['beizhu']);
       $price =dhtmlspecialchars($_GET['price']);
       $online = dhtmlspecialchars(implode(',',$_GET["online"]));
       $address = dhtmlspecialchars($_GET['address']);
	   $lng = dhtmlspecialchars($_GET['lng']);
       $lat = dhtmlspecialchars($_GET['lat']);
       $info =dhtmlspecialchars($_GET['info']);
       $yuyue = intval($_GET['yuyue']);
       $view = intval($_GET['view']);
       $renshu = intval($_GET['renshu']);
       $top = intval($_GET['top']);
       $tuijian = intval($_GET['tuijian']);
       if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins) || in_array($_G['groupid'], $mianshenhe)) {
           $display = 1;
       } else {
           $display = 0;
       }
       $diynum = intval($_GET['diynum']);
       $color = dhtmlspecialchars($_GET['color']);
       if ($_FILES['file']['tmp_name']) {
		   $imageinfo = getimagesize($_FILES['file']['tmp_name']);
		   $picsize = $_FILES['file']['size'];
		   if ($picsize > $newpicdx) {
		       showmessage(lang('plugin/xlwsq_sjhd', 'chaochudaxiao')); 
		   }
		   if ($imageinfo[0] <= 0) {
			   showmessage(lang('plugin/xlwsq_sjhd', 'feifatupianleixing'));
		   }
		   $filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
		   $arr=explode(".", $_FILES["file"]["name"]);
		   $hz=$arr[count($arr)-1];
		   if(!in_array($hz, $filetype)){
			   showmessage(lang('plugin/xlwsq_sjhd', 'tupiangeshibuzhengque'));
		   }
		   $filepath = "source/plugin/xlwsq_sjhd/upimg/".$sjuid."/activity/";
		   $randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
		   if(!file_exists($filepath)){mkdir($filepath,0777,true);}
		   if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
			   @unlink($_FILES['file']['tmp_name']);
		   }
		   $pic = "source/plugin/xlwsq_sjhd/upimg/".$sjuid."/activity/".$randname."";
		   if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
			   imageUpdateSize($pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$newpicwidth));	
           }else{
			   imageUpdateSize($pic,$imageinfo[0],$imageinfo[1]);
		   }
	    }
        DB::insert('plugin_xlwsq_sjhd_item', array('id' => '','sjuid' => $sjuid,'uid' => $uid,'author' => $_G['username'],'title' => $title,'cate' => $cate,'area' => $area,'pic' => $pic,'starttime' => $starttime,'endtime' => $endtime,'beizhu' => $beizhu,'price' => $price,'online' => $online,'address' => $address,'lng' => $lng,'lat' => $lat,'info' => $info,'yuyue' => $yuyue,'renshu' => $renshu,'top' => $top,'tuijian' => $tuijian,'display' => $display,'view' => $view,'diynum' => $diynum,'color' => $color,'dateline' => $_G['timestamp'],'updateline' => $_G['timestamp']));
	    $aid = DB::insert_id();
        if($credit!="0" && $paytype){
			updatemembercount($_G['uid'], array($paytype => -$credit));
           DB::insert('plugin_xlwsq_sjhd_record',array('id' => '','sid' => $aid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $title,'pay' => $credit,'moneytype' => $moneytype,'paytype' => 2,'dateline' =>$_G['timestamp']));
        }
		
	    $countz = count($_GET['filelist']);
		   for($i=0;$i<$countz;$i++){
	           $img = dhtmlspecialchars($_GET['filelist'][$i]);	
			   DB::query("INSERT INTO ".DB::table('plugin_xlwsq_sjhd_img')." ( `id` , `sid`,`uid`,`sjuid`, `img`,`dateline` ) VALUES (NULL , '$aid','$uid','$sjuid', '$img','$_G[timestamp]');");
		   }  
         if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins) || in_array($_G['groupid'], $mianshenhe)) {
               showmessage(lang('plugin/xlwsq_sjhd', 'fabuchenggong') , 'plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=index', array() , array('alert' => 'right'));
         } else {
			   $key=stripsearchkey($title);
               for ($i = 0; $i < count($admins); $i++) {
                    $message = "<a href='plugin.php?id=xlwsq_sjhd&#58;xlwsq_sjhd_user&p=adminalllist&key=$key' target='_blank'>" . lang('plugin/xlwsq_sjhd', 'yonghufabuxinxinxi') . $title."</a>";
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
               }
               showmessage(lang('plugin/xlwsq_sjhd', 'fabudengdaishenhe') , 'plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=index', array() , array('alert' => 'right'));
         }
    }
} elseif ($p == 'edit') {
    include_once 'source/plugin/xlwsq_sjhd/class/upic.class.php';
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id='$id'");
    $active['lat'] = $active['lat'] ? $active['lat'] : $zuobiao[0];
    $active['lng'] = $active['lng'] ? $active['lng'] : $zuobiao[1];
    $uid = intval($active['uid']);
    $sjuid = intval($active['sjuid']);
    $userinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$sjuid'");
    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu') , '', array() , array('login' => true));
    }
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }

    $areaid = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id='$active[area]'");
    if ($areaid) {
        $areatwoshow = '<select name="area_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE upid='$areaid'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['area']) {
                $areatwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $areatwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $areatwoshow.= '</select>';
    } else {
        $areaid = $active['area'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $areas[$row['id']] = $row;
    }
	$imgsql = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_sjhd_img')." WHERE sid='$id' ORDER BY img DESC");
	while($img = DB::fetch($imgsql)){
		$imgs[] = $img;
	}
    $catecarray = change($active['online']);
    if (submitcheck('applysubmit')) {
        $sjuid = intval($_GET['sjuid']);
        $title = dhtmlspecialchars($_GET['title']);
        $pic = dhtmlspecialchars($_GET['pic']);
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $area = intval($_GET['area_two']) ? intval($_GET['area_two']) : intval($_GET['area_1']);
	    if ($_GET['starttime']!= "") {$starttime=strtotime($_GET['starttime']);}else{$starttime = 0;}
	    if ($_GET['endtime'] != "") {$endtime=strtotime($_GET['endtime']);}else{$endtime = 0;}
        $beizhu = dhtmlspecialchars($_GET['beizhu']);
        $price = dhtmlspecialchars($_GET['price']);
        $online = dhtmlspecialchars(implode(',',$_GET["online"]));
        $address = dhtmlspecialchars($_GET['address']);
		$lng = dhtmlspecialchars($_GET['lng']);
        $lat = dhtmlspecialchars($_GET['lat']);
        $info = dhtmlspecialchars($_GET['info']);
        $view = intval($_GET['view']);
        $yuyue = intval($_GET['yuyue']);
        $renshu = intval($_GET['renshu']);
        $top = intval($_GET['top']);
        $tuijian = intval($_GET['tuijian']);
        if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)|| in_array($_G['groupid'], $mianshenhe)) {
            $display = 1;
        } else {
            $display = 0;
        }
        $diynum = intval($_GET['diynum']);
        $color = dhtmlspecialchars($_GET['color']);
        $timestamp = $_G['timestamp'];
        if ($_FILES['file']['tmp_name']) {
		    $imageinfo = getimagesize($_FILES['file']['tmp_name']);
		    $picsize = $_FILES['file']['size'];
			if ($imageinfo[0] <= 0) {
                showmessage(lang('plugin/xlwsq_sjhd', 'feifatupianleixing'));
			}
		    if ($picsize > $newpicdx) {
		        showmessage(lang('plugin/xlwsq_sjhd', 'chaochudaxiao')); 
		    }
            if ($active["pic"]!=false){
	            unlink($active["pic"]);
	        }
			$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			$arr=explode(".", $_FILES["file"]["name"]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
				showmessage(lang('plugin/xlwsq_sjhd', 'tupiangeshibuzhengque'));	
			}
			$filepath = "source/plugin/xlwsq_sjhd/upimg/".$sjuid."/activity/";
			$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
            if(!file_exists($filepath)){mkdir($filepath,0777,true);}
			if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					 @unlink($_FILES['file']['tmp_name']);
			}
			$pic = "source/plugin/xlwsq_sjhd/upimg/".$sjuid."/activity/".$randname."";
		    if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
				imageUpdateSize($pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$newpicwidth));	
            }else{
				imageUpdateSize($pic,$imageinfo[0],$imageinfo[1]);
		    }
		}
        DB::update('plugin_xlwsq_sjhd_item', array('sjuid' => $sjuid,'title' => $title,'cate' => $cate,'area' => $area,'pic' => $pic,'starttime' => $starttime,'endtime' => $endtime,'beizhu' => $beizhu,'price' => $price,'online' => $online,'address' => $address,'lng' => $lng,'lat' => $lat,'info' => $info,'yuyue' => $yuyue,'renshu' => $renshu,'top' => $top,'tuijian' => $tuijian,'color' => $color,'display' => $display,'view' => $view,'diynum' => $diynum) , "id='$id'");
        DB::query("delete from ".DB::table('plugin_xlwsq_sjhd_img')." where sid='$id'");
		$countz = count($_GET['filelist']);
			 for($i=0;$i<$countz;$i++){
			  $imgs = dhtmlspecialchars($_GET['filelist'][$i]);
			  DB::query("INSERT INTO ".DB::table('plugin_xlwsq_sjhd_img')." ( `id` , `sid`, `uid`, `sjuid`,`img`,`dateline` ) VALUES (NULL , '$id','$uid','$sjuid', '$imgs','$timestamp');");
		     }  
        if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)|| in_array($_G['groupid'], $mianshenhe)) {
			showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok') , dreferer());
        } else {
			$key=stripsearchkey($title);
            for ($i = 0; $i < count($admins); $i++) {
               $message = "<a href='plugin.php?id=xlwsq_sjhd&#58;xlwsq_sjhd_user&p=adminalllist&key=$key' target='_blank'>" . lang('plugin/xlwsq_sjhd', 'yonghufabuxinxinxi') . $title."</a>";
               notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
            showmessage(lang('plugin/xlwsq_sjhd', 'fabudengdaishenhe') , dreferer());
        }
    }
}elseif($p=='userinfoedit'||$p=='userinfoadd'||$p=='adminuserinfo'){
    $sjuid = intval($_GET['sjuid']);
	if($p=='userinfoadd'){
	  if($usershopnum){
         $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE uid='$_G[uid]'");
	     if ($countr >= $usershopnum && $usershopnum!='0' && $_G['groupid'] != "1" && !in_array($_G['uid'], $admins)) {
		     showmessage(lang('plugin/xlwsq_sjhd', 'xianzhitishi').$xianzhishuliang.$usershopnum.lang('plugin/xlwsq_sjhd', 'tiaoxinxi'), dreferer());
	     }
	  }
	  $userinfo['lat'] = $zuobiao[0];
      $userinfo['lng'] = $zuobiao[1];
	}else{	
	  if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
	     $userinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$sjuid'");
	  }else{
         $userinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$sjuid' AND uid='$_G[uid]'");
	  }	  
      !$userinfo ? showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu') , "plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user") : '';
      $userinfo['lat'] = $userinfo['lat'] ? $userinfo['lat'] : $zuobiao[0];
      $userinfo['lng'] = $userinfo['lng'] ? $userinfo['lng'] : $zuobiao[1];
	  $imgsql = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_sjhd_shopimg')." WHERE sjuid='$sjuid' ORDER BY comimg DESC");
	   while($img = DB::fetch($imgsql)){
	  	$imgs[] = $img;
	  }
	}
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id='$userinfo[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $userinfo['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $userinfo['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    $areaid = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id='$userinfo[area]'");
    if ($areaid) {
        $areatwoshow = '<select name="area_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE upid='$areaid'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $userinfo['area']) {
                $areatwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $areatwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $areatwoshow.= '</select>';
    } else {
        $areaid = $userinfo['area'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $areas[$row['id']] = $row;
    }
	if(submitcheck('applysuser')){
        $comname = dhtmlspecialchars($_GET['comname']);
        if (!$comname) {
           showmessage(lang('plugin/xlwsq_sjhd', 'meidianpuming'));
        }
        if($p=='userinfoadd'){
            $chongming = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE comname='$comname'"); 
            if($chongming){
		        showmessage(lang('plugin/xlwsq_sjhd', 'dianmingyicunzai') , dreferer());
            }
		}
        if($p=='userinfoedit'){
            $chongming = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE comname='$comname'"); 
            if($chongming && $chongming[sjuid]!=$sjuid){
		        showmessage(lang('plugin/xlwsq_sjhd', 'dianmingyicunzai') , dreferer());
            }
		}
        $uid = intval($_GET['uid']);
        $comlogo = dhtmlspecialchars($_GET['comlogo']);
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $area = intval($_GET['area_two']) ? intval($_GET['area_two']) : intval($_GET['area_1']);
		$lianxiren = dhtmlspecialchars($_GET['lianxiren']);
        $tel = dhtmlspecialchars($_GET['tel']);
		$fax = dhtmlspecialchars($_GET['fax']);
		$qq = dhtmlspecialchars($_GET['qq']);
		$weixin = dhtmlspecialchars($_GET['weixin']);
		$email = dhtmlspecialchars($_GET['email']);
        $address = dhtmlspecialchars($_GET['address']);
        $lat = dhtmlspecialchars($_GET['lat']);
        $lng = dhtmlspecialchars($_GET['lng']);
        $cominfo = dhtmlspecialchars($_GET['cominfo']);
        $homepage = dhtmlspecialchars($_GET['homepage']);
        $renling = intval($_GET['renling']);
        $diynum = intval($_GET['diynum']);
        $timestamp = $_G['timestamp'];
        if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)|| in_array($_G['groupid'], $mianshenhe)) {
            $display = 1;
        } else {
            $display = 0;
        }
        if ($_FILES['file']['tmp_name']) {
			$imageinfo = getimagesize($_FILES['file']['tmp_name']);
			if ($imageinfo[0] <= 0) {
                showmessage(lang('plugin/xlwsq_sjhd', 'feifatupianleixing'));
			}
            if ($userinfo["comlogo"]!=false){
	            unlink($userinfo["comlogo"]);
	        }
			$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
			$arr=explode(".", $_FILES["file"]["name"]);
			$hz=$arr[count($arr)-1];
			if(!in_array($hz, $filetype)){
				showmessage(lang('plugin/xlwsq_sjhd', 'tupiangeshibuzhengque'));	
			}
			$filepath = "source/plugin/xlwsq_sjhd/upimg/".$sjuid."/shop/";
			$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
            if(!file_exists($filepath)){mkdir($filepath,0777,true);}
			if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
					 @unlink($_FILES['file']['tmp_name']);
			}
			$comlogo = "source/plugin/xlwsq_sjhd/upimg/".$sjuid."/shop/".$randname."";
		}
		if($p=='userinfoadd'){
			DB::insert('plugin_xlwsq_sjhd_user',array('sjuid' => '','uid' => $uid,'comname' => $comname,'display' => $display,'diynum' => $diynum,'dateline' => $timestamp));
	        $aid = DB::insert_id(); 
		}else{
			DB::update('plugin_xlwsq_sjhd_user', array('comname' => $comname,'cate' => $cate,'area' => $area,'comlogo' => $comlogo,'lianxiren' => $lianxiren,'tel' => $tel, 'fax' => $fax,'qq' => $qq, 'weixin' => $weixin,'email' => $email,'address' => $address,'lat' => $lat,'lng' => $lng,'cominfo' => $cominfo,'homepage' => $homepage,'renling' => $renling,'display' => $display,'diynum' => $diynum), "sjuid ='$sjuid'");
		}
        if ($_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
			   if($p=='userinfoedit'){
                    showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong') , dreferer());
			   }elseif($p=='userinfoadd'){
                    showmessage(lang('plugin/xlwsq_sjhd', 'chuangjianshangpuchenggong') , 'plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=userinfoedit&sjuid='.$aid, array(),array('alert' => 'right'));
			   }elseif($p=='adminuserinfo'){
                    showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong') , dreferer());
			   }
        }elseif (in_array($_G['groupid'], $mianshenhe)) {
               showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong') , 'plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=myshoplist', array() , array('alert' => 'right'));
        }else{
			   $key=stripsearchkey($comname);
               for ($i = 0; $i < count($admins); $i++) {
                    $message = "<a href='plugin.php?id=xlwsq_sjhd&#58;xlwsq_sjhd_user&p=adminshoplist&key=$key' target='_blank'>" . lang('plugin/xlwsq_sjhd', 'yonghufabudianpu') . $comname."</a>";
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
               }
			   $aid = $aid ? $aid : $sjuid;
               showmessage(lang('plugin/xlwsq_sjhd', 'chuangjianshangpuchenggongb') , 'plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=userinfoedit&sjuid='.$aid, array(),array('alert' => 'right'));
        }
	}
} elseif ($p == 'comdel') {
    $sjuid = intval($_GET['sjuid']);
    $uid = intval($_G['uid']);
	$active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid ='$sjuid'");
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$active['uid']==$uid) {
        if ($_GET['formhash'] == FORMHASH) {
		   deldir("source/plugin/xlwsq_sjhd/upimg/".$sjuid);
           DB::query("DELETE a,b,c,d,e FROM " . DB::table('plugin_xlwsq_sjhd_user') . " AS a LEFT JOIN " . DB::table('plugin_xlwsq_sjhd_item') . " AS b ON a.sjuid = b.sjuid LEFT JOIN " . DB::table('plugin_xlwsq_sjhd_img') . " AS c ON c.sjuid = b.sjuid LEFT JOIN " . DB::table('plugin_xlwsq_sjhd_post') . " AS d ON d.sid = b.id LEFT JOIN " . DB::table('plugin_xlwsq_sjhd_shopimg') . " AS e ON e.sjuid = a.sjuid WHERE a.sjuid = '$sjuid' ");
            showmessage(lang('plugin/xlwsq_sjhd', 'shanchuok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_sjhd', 'wuquanxiancaozuo') , dreferer());
    }
} elseif ($p == 'shopshenheok'||$p == 'shopqxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)&&$_GET['formhash'] == FORMHASH) {
        $sjuid = intval($_GET['sjuid']);
        if ($p == 'shopshenheok') {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_user') . " SET display='1' WHERE sjuid='$sjuid'");
            showmessage(lang('plugin/xlwsq_sjhd', 'shenheok') , dreferer());
        } else {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_user') . " SET display='0' WHERE sjuid='$sjuid'");
            showmessage(lang('plugin/xlwsq_sjhd', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu'));
    }
}elseif($p=='xfjl'){	
    $where=$pageadd="";
    if($_GET['key']){
       $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
	$uid = intval($_G['uid']);
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_record')." WHERE $where uid='$uid' AND paytype !='0'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
      $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_sjhd_record')." WHERE $where uid='$uid' AND paytype !='0' ORDER BY id DESC LIMIT $starts,20");
	  while($xiaofei = DB::fetch($query)){
		$xiaofeis[] = $xiaofei;
	  }
    }
	$multis = "<div class='pages cl'>".multi($counts, 20, $pages, "plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user"."&p=$p".$pageadd)."</div>";

} elseif ($p == 'favorites') {
    $where=$pageadd="";
    if($_GET['key']){
       $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_favorites') . " WHERE $where uid='$uid'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 20;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_favorites') . " WHERE $where uid = '$uid' ORDER BY shoucangshijian DESC LIMIT $starts,20");
        $sc = $scs = array();
        while ($sc = DB::fetch($query)) {
            $scs[] = $sc;
        }
    }
    $multis = "<div class='pages cl'>" . multi($counts, 20, $pages, "plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user" . "&p=$p" . $pageadd) . "</div>";
} elseif ($p == 'favoritesdel') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if ($_GET['formhash'] == FORMHASH) {
        DB::query("DELETE FROM " . DB::table('plugin_xlwsq_sjhd_favorites') . " WHERE id = '$id' and uid = '$uid'");
        showmessage(lang('plugin/xlwsq_sjhd', 'shanchuok') , dreferer());
    }
} elseif ($p == 'yuyue') {
    $where=$pageadd="";
    if($_GET['key']){
       $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_yuyue') . " WHERE $where yyuid='$uid'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 20;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_yuyue') . " WHERE $where yyuid = '$uid' ORDER BY yyid DESC LIMIT $starts,20");
        while ($yuyue = DB::fetch($query)) {
            $yuyues[] = $yuyue;
        }
    }
    $multis = "<div class='pages cl'>" . multi($counts, 20, $pages,"plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user". "&p=$p" . $pageadd) . "</div>";
} elseif ($p == 'yuyuedel') {
    $yyid = intval($_GET['yyid']);
    $yyuid = intval($_G['uid']);
    if ($_GET['formhash'] == FORMHASH) {
        $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_yuyue') . " WHERE yyid='$yyid'");
        DB::query("DELETE FROM " . DB::table('plugin_xlwsq_sjhd_yuyue') . " WHERE yyid = '$yyid' and yyuid = '$yyuid'");
        $yiyuyuerenshu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_yuyue')." WHERE sid='$active[sid]'");
		DB::update('plugin_xlwsq_sjhd_item', array('yiyuyuerenshu' => $yiyuyuerenshu),"id='$active[sid]'");
        $message = '<a href="plugin.php?id=xlwsq_sjhd&mod=view&sid='.$active[sid].'" target="_blank">' .$active[xingming] .lang('plugin/xlwsq_sjhd', 'yuyuexitongquxiaotixing') . '</a>';
        notification_add($active[sjuid], 'system',$message,  $notevars = array(), $system = 0);
        showmessage(lang('plugin/xlwsq_sjhd', 'yuyuequxiao') , dreferer());
    }
} elseif ($p == 'shenheok'||$p == 'qxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)&&$_GET['formhash'] == FORMHASH) {
        $id = intval($_GET['sid']);
        if ($p == 'shenheok') {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_item') . " SET display='1' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_sjhd', 'shenheok') , dreferer());
        } else {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_item') . " SET display='0' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_sjhd', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu'));
    }
} elseif ($p == 'bukerenling'||$p == 'kerenling') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)&&$_GET['formhash'] == FORMHASH) {
        $sjuid = intval($_GET['sjuid']);
        if ($p == 'bukerenling') {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_user') . " SET renling='1' WHERE sjuid='$sjuid'");
            showmessage(lang('plugin/xlwsq_sjhd', 'renlingcaozuochenggong') , dreferer());
        } else {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_user') . " SET renling='0' WHERE sjuid='$sjuid'");
            showmessage(lang('plugin/xlwsq_sjhd', 'renlingcaozuochenggong') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu'));
    }
}elseif($p=='adminrenling'){	
	$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_rl'));
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
    if($counts) {
	   $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_sjhd_rl')." ORDER BY dateline DESC LIMIT $starts,20");
	   $rl = $rls = array();
	   while($rl = DB::fetch($query)){
		  $rls[] = $rl;
	    }
    }
	$multis = "<div class='pages cl'>".multi($counts, 20, $pages, "plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user"."&p=$p".$pageadd)."</div>";
}elseif ($p=='adminrenlingagree'){
	$rlid=intval($_GET['rlid']);
	$sjuid=intval($_GET['sjuid']);
	$comname=dhtmlspecialchars($_GET['comname']);
	$uid=intval($_GET['uid']);
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
      if($_GET['formhash'] == FORMHASH) {
           DB::update('plugin_xlwsq_sjhd_user', array('uid' => $uid,'renling' => 0), "sjuid='$sjuid'");
           DB::update('plugin_xlwsq_sjhd_item', array('uid' => $uid), "sjuid='$sjuid'");
           DB::delete('plugin_xlwsq_sjhd_rl',array('id'=> $rlid));
           $message = '<a href="plugin.php?id=xlwsq_sjhd&mod=cominfo&sjuid='.$sjuid.'" target="_blank">'.lang('plugin/xlwsq_sjhd', 'renlingtongyitishi') .$comname  . '</a>';
           notification_add($uid, 'system', $message, $notevars = array() , $system = 0);
           showmessage(lang('plugin/xlwsq_sjhd', 'renlingagree'), dreferer());
      }
	}else{
           showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu'), dreferer());
	}
}elseif ($p=='adminrenlingdel'){
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	  $rlid=intval($_GET['rlid']);
	  $sjuid=intval($_GET['sjuid']);
	  $comname=dhtmlspecialchars($_GET['comname']);
	  $uid=intval($_GET['uid']);
      if($_GET['formhash'] == FORMHASH) {
           $message = '<a href="plugin.php?id=xlwsq_sjhd&mod=cominfo&sjuid='.$sjuid.'" target="_blank">' .$comname .lang('plugin/xlwsq_sjhd', 'renlingjujuetishi') . '</a>';
           DB::delete('plugin_xlwsq_sjhd_rl',array('id'=> $rlid));
           notification_add($uid, 'system', $message, $notevars = array() , $system = 0);
           showmessage(lang('plugin/xlwsq_sjhd', 'renlingjujue'), dreferer());
      }
	}else{
           showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu'), dreferer());
	}
}elseif ($p=='shopchange'){
	$sjuid=intval($_GET['sjuid']);
	$uid=intval($_GET['uid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$sjuid'");
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	  if(submitcheck('applysub')){
           DB::update('plugin_xlwsq_sjhd_user', array('uid' => $uid), "sjuid='$sjuid'");
           DB::update('plugin_xlwsq_sjhd_item', array('uid' => $uid), "sjuid='$sjuid'");
           showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok'), dreferer());
      }
	}else{
           showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu'), dreferer());
	}
}elseif ($p=='itemchange'){
	$sid=intval($_GET['sid']);
	$sjuid=intval($_GET['sjuid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id='$sid'");
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$sjuid'");
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	  if(submitcheck('applysub')){
           DB::update('plugin_xlwsq_sjhd_item', array('uid' => $active['uid'],'sjuid' => $sjuid), "id='$sid'");
           showmessage(lang('plugin/xlwsq_sjhd', 'gengxinok'), dreferer());
      }
	}else{
           showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu'), dreferer());
	}
} elseif ($p == 'del') {
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id ='$sid'");
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$active['uid']==$uid) {
        if ($_GET['formhash'] == FORMHASH) {
            if ($active["pic"] != false) {
                unlink($active["pic"]);
            }
	        $query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_sjhd_img')." WHERE sid = '$sid'");
	        $delz = $delzs = array();
	        while($delz = DB::fetch($query)){
		        if ($delz["img"]!=false){
			      unlink($delz["img"]);
		        }
		        $delzs[] = $delz;
	        }
            DB::query("DELETE a,b,c FROM " . DB::table('plugin_xlwsq_sjhd_item') . " AS a LEFT JOIN ". DB::table('plugin_xlwsq_sjhd_img') . " AS b ON b.sid = a.id LEFT JOIN " . DB::table('plugin_xlwsq_sjhd_post') . " AS c ON c.sid = a.id  WHERE a.id = '$sid' ");
            showmessage(lang('plugin/xlwsq_sjhd', 'shanchuok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu'));
    }
}
include (template("xlwsq_sjhd:xlwsq_sjhd_user"));
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
function change($str){
	$return = array();
	$array = explode(",",$str);
	foreach ($array as $v){
		$t = explode(" ",$v);
		$return[$t[0]] = $t[0];
	}
	return $return;
}
//From: Dism��taobao��com
?>