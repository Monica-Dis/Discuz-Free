<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/xlwsq_sjhd/function/function_core.php';
global $_G;
if (!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plyes=($_G['cache']['plugin']['xlwsq_sjhd']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
$menucatec = parconfig($catecselect);
if($_G['mobile']) {
  $menubgcolor=$plyes['mobilemenubgcolor'];
}else{
  $menubgcolor=$plyes['menubgcolor'];
}
$fabuset = unserialize($groups);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$navtitle = $title;
$creditb = abs($creditb);
$creditc = abs($creditc);
$creditd = abs($creditd);
$credite = abs($credite);
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if($mod == 'index') {
    $where=$pageadd="";
    if ($_GET['key']) {
        $key=stripsearchkey($_GET['key']);
		$where="title like '%".addcslashes(addslashes($key), '%')."%' AND display!='0' OR info like '%" . addcslashes(addslashes($key), '%') . "%'  AND display!='0' AND";
        $keync = urlencode($key);
        $pageadd = "&key=$keync";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
    }
    $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$cate_id'");
    $sd = intval($_GET['b']);
    if ($sd) {
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
    }
    $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$sd'");
    $b_area_id = intval($_GET['bc']);
    if ($b_area_id) {
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id='$b_area_id'");
        if ($subids) {
            $b_area = "area IN ($b_area_id,$subids) AND";
        } else {
            $b_area = "area=$b_area_id AND";
        }
        $pageaddbc = "&bc=$b_area_id";
    }
    $marea = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id = '$b_area_id'");
    $s_area_id = intval($_GET['sc']);
    if ($s_area_id) {
        $s_area = "area='$s_area_id' AND";
        $pageaddsc = "&sc=$s_area_id";
    }
    $mareab = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id = '$s_area_id'");
    $zt = intval($_GET['zt']);

    $lx = intval($_GET['lx']);
    if ($lx) {
        $sn[] = "online = '$lx'";
        $pageaddn = "&lx=$lx";
    }
    if ($sn){$fn="online like '%".addcslashes(addslashes($lx), '%_')."%' AND";}

    if ($_GET['tj']) {
		$px="tuijian = '1' AND display!='0' AND (endtime = 0 OR endtime > $_G[timestamp]) ORDER BY dateline DESC"; $pageadd="&tj=t";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE $where $wb $wc $b_area $s_area $fn tuijian = '1' AND display='1' AND (endtime = 0 OR endtime > $_G[timestamp])");
	}elseif($zt==1){
		$px="display!='0' AND starttime > $_G[timestamp] ORDER BY starttime ASC"; $pageadd="&zt=1";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE $where $wb $wc $b_area $s_area $fn display='1' AND  starttime > $_G[timestamp]");
	}elseif($zt==2){
		$px="display!='0' AND starttime < $_G[timestamp] AND (endtime = '0' OR endtime != 0 AND endtime > $_G[timestamp]) ORDER BY dateline DESC"; $pageadd="&zt=2";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE $where $wb $wc $b_area $s_area $fn display='1' AND starttime < $_G[timestamp] AND (endtime = '0' OR endtime != 0 AND endtime > $_G[timestamp]) ");
	}elseif($zt==3){
		$px="display!='0' AND (endtime != 0 AND endtime < $_G[timestamp]) ORDER BY endtime ASC"; $pageadd="&zt=3";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE $where $wb $wc $b_area $s_area $fn display='1' AND (endtime != 0 AND endtime < $_G[timestamp])");
	}else{
		$px="display!='0'   ORDER BY top DESC,topdateline DESC,diynum DESC,updateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE $where $wb $wc $b_area $s_area $fn display='1'");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE $where $wb $wc $b_area $s_area $fn $px LIMIT $starts,$eacha");
        $mythread = $mythreads = array();
        while ($mythread = DB::fetch($query)) {
            if ($mythread['topdateline'] !='0'){DB::query("UPDATE ".DB::table('plugin_xlwsq_sjhd_item')." SET `topdateline` = '0',`color` = '' WHERE topdateline <= ".time());}
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$cate[upid]'");
                $mythread['cate'] = $cate['subject'];
            } else {
                $mythread['cate'] = $cate['subject'];
            }
            $area = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id = '$mythread[area]'");
            if ($area['upid'] != 0) {
                $area_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id = '$area[upid]'");
                $mythread['area'] = $area['subject'];
            } else {
                $mythread['area'] = $area['subject'];
            }
			    $mythread['info'] = strip_tags(discuzcode($mythread['info']));
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px 0;'>" . multi($counts, $eacha, $pages,"plugin.php?id=xlwsq_sjhd" . $pageadd. $pageadds . $pageaddx . $pageaddbc . $pageaddsc) . "</div>";

    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id='$cate_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }

    $bc_subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id='$b_area_id'");
    if ($bc_subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id IN ($bc_subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $local_sc[$ros['id']] = $ros;
        }
    }
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE view >'0' AND display!='0' ORDER BY view DESC LIMIT $hotnum");
    while ($hot = DB::fetch($hotquery)) {
            $hotcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$hot[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$hotcate[upid]'");
                $hot['cate'] = $hotcate['subject'];
            } else {
                $hot['cate'] = $hotcate['subject'];
            }
        $hots[] = $hot;
    }
    $tuijianquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY diynum DESC,dateline DESC LIMIT $tjnum");
    while ($tuijian = DB::fetch($tuijianquery)) {
            $tjcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$tuijian[cate]'");
            if ($tjcate['upid'] != 0) {
                $tjcate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$tjcate[upid]'");
                $tuijian['cate'] = $tjcate['subject'];
            } else {
                $tuijian['cate'] = $tjcate['subject'];
            }
        $tuijians[] = $tuijian;
    }
    $sjquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE display!='0' ORDER BY sjuid DESC LIMIT $newsjnum");
    while ($newsj = DB::fetch($sjquery)) {
        $newsjs[] = $newsj;
    }
    if ($cate_id!='0') {
      if ($sd!='0') {
           $navtitle = $mcate['subject'] . "-" . $mcateb['subject']. "-" .$title;
      } else {
           $navtitle = $mcate['subject']. "-".$title;
      }
    }
    include template('xlwsq_sjhd:list');
}elseif($_GET['mod']=='indexqrpic'){
    include_once 'source/plugin/xlwsq_sjhd/class/qrcode.class.php';
    QRcode::png('plugin.php?id=xlwsq_sjhd', false,L,6);
}elseif($_GET['mod']=='qrpic'){
    include_once 'source/plugin/xlwsq_sjhd/class/qrcode.class.php';
	$sid = intval($_GET['sid']);
    $value=$_G['siteurl'].'plugin.php?id=xlwsq_sjhd&mod=view&sid='.$sid;
    QRcode::png($value, false,L,6);
}elseif($_GET['mod']=='sjqrpic'){
    include_once 'source/plugin/xlwsq_sjhd/class/qrcode.class.php';
	$sjuid = intval($_GET['sjuid']);
    $value=$_G['siteurl'].'plugin.php?id=xlwsq_sjhd&mod=cominfo&sjuid='.$sjuid;
    QRcode::png($value, false,L,6);
} elseif ($_GET['mod'] == 'view'||$_GET['mod'] == 'liuyan') {
    $sid = intval($_GET['sid']);
    if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
       $error = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id = '$sid' and display!='0'");
       !$error ? showmessage(lang('plugin/xlwsq_sjhd', 'error') , "plugin.php?id=xlwsq_sjhd") : '';
	}
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id='$sid'");
    !$mythread ? showmessage(lang('plugin/xlwsq_sjhd', 'error') , "plugin.php?id=xlwsq_sjhd") : '';
    $shop = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$mythread[sjuid]'");
	$hdcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_item')." WHERE sjuid='$mythread[sjuid]' AND display!='0'");
	$yycount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_yuyue')." WHERE sid='$sid'");
    $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_favorites') . " WHERE sid = '$sid' AND uid = '$_G[uid]'");
    $mythread['dinfo'] = discuzcode($mythread['info']);
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE sjuid='$mythread[sjuid]' AND display!='0' AND id !='$sid' ORDER BY dateline DESC LIMIT 10");
    while ($hot = DB::fetch($query)) {
        $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$hot[cate]'");
        if ($cate['upid'] != 0) {
            $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$cate[upid]'");
            $hot['cate'] = $cate_t['subject']." - ".$cate['subject'];
        } else {
            $hot['cate'] = $cate['subject'];
        }
        $hots[] = $hot;
    }
    DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_item') . " SET `view` = view+1 WHERE `id` = '$sid'");

    if(submitcheck('applysubmit')){	
	   !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
		if(empty($_GET['message'])){
			showmessage(lang('plugin/xlwsq_sjhd', 'wupinglunneirong'), dreferer());
		}else{
			$author = $_G['username'];
		    $message = dhtmlspecialchars($_GET['message']);
		    DB::insert('plugin_xlwsq_sjhd_post',array('pid' => '','sid' => $sid,'uid' => $_G['uid'],'sjuid' => $mythread['uid'],'author' => $author,'message' => $message,'dateline' => $_G['timestamp']));
			$tixing = '<a href="plugin.php?id=xlwsq_sjhd&mod=view&sid='.$sid.'" target="_blank">'.lang('plugin/xlwsq_sjhd', 'liuyantixing').$message. '</a>';
            notification_add($mythread['uid'], 'system',$tixing,  $notevars = array(), $system = 0);
		    if($_G['mobile']) {
				 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'), 'plugin.php?id=xlwsq_sjhd&mod=liuyan&sid='.$sid);
			} else {
                 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'),dreferer());
			}
		}
    }
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_post')." WHERE sid='$sid'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_sjhd_post')." WHERE sid='$sid' ORDER BY dateline DESC LIMIT $start,$each");
		while($pl = DB::fetch($query)) {
			$pls[] = $pl;
		}
	}
	$multi = "<div class='pages cl' style='margin:10px'>".multi($count, $each, $page,'plugin.php?id=xlwsq_sjhd&mod=view&sid='.$sid.'')."</div>";
	$mobilemulti = "<div class='pages cl' style='margin:10px'>".multi($count, $each, $page,'plugin.php?id=xlwsq_sjhd&mod=liuyan&sid='.$sid.'')."</div>";
 	
    if($_GET['pinglun'] == 'del'){
	   $sid = intval($_GET['sid']);
	   $pid = intval($_GET['did']);
       $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_sjhd_post')." where pid = '$pid'");
       if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins) || $_G['uid']==$pl['sjuid'] && $_GET['formhash'] == FORMHASH) {
	      DB::delete('plugin_xlwsq_sjhd_post',array('pid'=> $pid));
	      showmessage(lang('plugin/xlwsq_sjhd', 'shanchuok'), dreferer());
	   }else{
		  showmessage(lang('plugin/xlwsq_sjhd', 'wuquanxiancaozuo'), '', array(), array('alert' => 'error'));
	   }
    }
    $navtitle = $mythread['title'] . " - " . $title;
	$metakeywords = $mythread['title'];
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($mythread['dinfo']) , 80, '...'));
	if($_GET['mod']=='liuyan'){
       include template('xlwsq_sjhd:liuyan');
	}else{
       include template('xlwsq_sjhd:view');
	}
} elseif ($_GET['mod'] == 'yuyue') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
	$yyuid = intval($_G['uid']);
	$yysid = intval($_GET['yysid']);
	$item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id='$yysid'");
	    if($item['yuyue']!=1){
		    showmessage(lang('plugin/xlwsq_sjhd', 'yuyueweikaiqiyuyue') , '', array() , array('alert' => 'error'));
        }elseif($item['endtime']!="0" && $item['endtime']<$_G['timestamp']){
		    showmessage(lang('plugin/xlwsq_sjhd', 'yuyuetingzhi') , '', array() , array('alert' => 'error'));
        }elseif($item['renshu']!=0 && $item['yiyuyuerenshu']>=$item['renshu']){
		    showmessage(lang('plugin/xlwsq_sjhd', 'yuyuemingeman') , '', array() , array('alert' => 'error'));
        }
        $useryuyue = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_yuyue') . " WHERE sid ='$yysid' AND yyuid='$yyuid'");
        if ($useryuyue){showmessage(lang('plugin/xlwsq_sjhd', 'yuyuechongfu'), array(), array('alert' => 'error'));}
		if(submitcheck('applysubdz')){
            if(empty($_GET['xingming'])||empty($_GET['tel'])){
		        showmessage(lang('plugin/xlwsq_sjhd', 'yuyuemeiyoulianxiren'), dreferer());
	        }
			$sjuid = intval($item['uid']);
            $title = dhtmlspecialchars($item['title']);
            $xingming = dhtmlspecialchars($_GET['xingming']);
            $tel = dhtmlspecialchars($_GET['tel']);
            $qq = dhtmlspecialchars($_GET['qq']);
            $weixin = dhtmlspecialchars($_GET['weixin']);
			$qitabeizhu = dhtmlspecialchars($_GET['qitabeizhu']);
            $starttime = dhtmlspecialchars($item['starttime']);
            $endtime = dhtmlspecialchars($item['endtime']);
			DB::insert('plugin_xlwsq_sjhd_yuyue',array('yyid' => '','sid' => $yysid, 'yyuid' => $yyuid, 'title' => $title, 'sjuid' => $sjuid ,'xingming' => $xingming, 'tel' => $tel, 'qq' => $qq, 'weixin' => $weixin, 'qitabeizhu' => $qitabeizhu, 'starttime' => $starttime, 'endtime' => $endtime, 'yuyeshijian' => $_G['timestamp']));
			$yiyuyuerenshu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_yuyue')." WHERE sid='$yysid'");
			DB::update('plugin_xlwsq_sjhd_item', array('yiyuyuerenshu' => $yiyuyuerenshu),"id='$yysid'");
            $message = '<a href="plugin.php?id=xlwsq_sjhd&mod=yuyuelist&sid='.$item[id].'" target="_blank">'.lang('plugin/xlwsq_sjhd', 'yuyuexitongtixinga').$xingming.lang('plugin/xlwsq_sjhd', 'yuyuexitongtixingb'). '</a>';
            notification_add($item[uid], 'system',$message,  $notevars = array(), $system = 0);
		    if($_G['mobile']) {
				 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'), 'plugin.php?id=xlwsq_sjhd&mod=yuyuelist&sid='.$yysid);
			} else {
                 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'), dreferer(), array(), array('locationtime'=>2, 'showdialog'=>1, 'showmsg' => true, 'closetime' => 2));
			}
		}
	include template('xlwsq_sjhd:yuyue');
} elseif ($_GET['mod'] == 'yuyuelist') {
    $sid = intval($_GET['sid']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id='$sid'");
	$yycount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_yuyue')." WHERE sid='$sid'");
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 20;
	if($yycount) {
    	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_sjhd_yuyue')." WHERE sid='$sid' ORDER BY yuyeshijian DESC LIMIT $starts,20");
	     while($yuyuelist = DB::fetch($query)){
			$yuyuelists[] = $yuyuelist;
	    }
	}
	$yymultis = "<div class='pages cl' style='margin:0 5px 10px 0'>".multi($yycount, 20, $pages,'plugin.php?id=xlwsq_sjhd&mod=yuyuelist&sid='.$sid)."</div>";
	include template('xlwsq_sjhd:yuyuelist');
} elseif ($_GET['mod'] == 'yuyuejujue') {
    $yyid = intval($_GET['yyid']);
    $display = intval($_GET['display']);
    $info = dhtmlspecialchars($_GET['info']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_yuyue') . " WHERE yyid='$yyid'");
	$item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id='$active[sid]'");
    if($active['sjuid']!=$_G['uid']){
	    showmessage(lang('plugin/xlwsq_sjhd', 'feishangjiawuquanxiancaozuo') , '', array() , array('alert' => 'error'));
	}
    $tongguorenshu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_yuyue')." WHERE sid='$active[sid]' AND display=1");
    $dairenshu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_yuyue')." WHERE sid='$active[sid]' AND display=0");
    $yijurenshu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_yuyue')." WHERE sid='$active[sid]' AND display=2");
	if(submitcheck('applysubjj')){
        DB::update('plugin_xlwsq_sjhd_yuyue', array('display' => $display,'jujueliyou' => $info) , "yyid='$yyid'");
        $yiyuyuerenshu = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_sjhd_yuyue')." WHERE sid='$active[sid]'");
		DB::update('plugin_xlwsq_sjhd_item', array('yiyuyuerenshu' => $yiyuyuerenshu),"id='$active[sid]'");
        if($display=='2') {
            $message = '<a href="plugin.php?id=xlwsq_sjhd&mod=view&sid='.$active[sid].'" target="_blank">' .lang('plugin/xlwsq_sjhd', 'yuyuebeijujue').$active[title] .lang('plugin/xlwsq_sjhd', 'yuyuebeijujue2') .$info. '</a>';
            notification_add($active[yyuid], 'system',$message,  $notevars = array(), $system = 0);
        }
		if($_G['mobile']) {
			 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'), 'plugin.php?id=xlwsq_sjhd&mod=yuyuelist&sid='.$active[sid]);
	    } else {
             showmessage(lang('plugin/xlwsq_sjhd', 'yuyuecaozuochenggong') , dreferer());
	    }
    }
	include template('xlwsq_sjhd:yuyuejujue');
} elseif ($_GET['mod'] == 'shoplist') {
    $where=$pageadd="";
    if ($_GET['key']) {
        $key=stripsearchkey($_GET['key']);
		$where=" comname like '%".addcslashes(addslashes($key), '%')."%' AND ";
        $keync = urlencode($key);
        $pageadd = "&key=$keync";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
        $av_d[$cate_id] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$cate_id'");
    $sd = intval($_GET['b']);
    if ($sd) {
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
        $av_d[$sd] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$sd'");
    $b_area_id = intval($_GET['bc']);
    if ($b_area_id) {
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id='$b_area_id'");
        if ($subids) {
            $b_area = "area IN ($b_area_id,$subids) AND";
        } else {
            $b_area = "area=$b_area_id AND";
        }
        $pageaddbc = "&bc=$b_area_id";
        $av_dc[$b_area_id] = ' class="cur-on"';
    } else {
        $av_dc[0] = ' class="cur-on"';
    }
    $marea = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id = '$b_area_id'");
    $s_area_id = intval($_GET['sc']);
    if ($s_area_id) {
        $s_area = "area='$s_area_id' AND";
        $pageaddsc = "&sc=$s_area_id";
        $av_dc[$s_area_id] = ' class="cur-on"';
    } else {
        $av_dc[0] = ' class="cur-on"';
    }
    $mareab = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id = '$s_area_id'");
	$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_user')." WHERE $where $wb $wc $b_area $s_area display!='0'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $sjnum;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE $where $wb $wc $b_area $s_area display!='0' ORDER BY diynum DESC,sjuid DESC LIMIT $starts,$sjnum");
        while ($mythread = DB::fetch($query)) {
			$mythread['dcominfo'] = strip_tags(discuzcode($mythread['cominfo']));
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px;'>" . multi($counts,$sjnum,$pages,"plugin.php?id=xlwsq_sjhd&mod=shoplist$pageadd".$pageadds.$pageaddx.$pageaddbc.$pageaddsc)."</div>";
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $local[$row['id']] = $row;
    }
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id='$cate_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $local_bc[$row['id']] = $row;
    }
    $bc_subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id='$b_area_id'");
    if ($bc_subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE id IN ($bc_subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $local_sc[$ros['id']] = $ros;
        }
    }
    $navtitle = lang('plugin/xlwsq_sjhd', 'shoplist'). " - " . $title;
    include template('xlwsq_sjhd:shoplist');
} elseif ($_GET['mod'] == 'shopinfo'||$_GET['mod'] == 'shopprolist'||$_GET['mod'] == 'cominfo') {
	$sjuid = intval($_GET['sjuid']);
	if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
       $shopinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$sjuid' AND display!='0'");
	}else{
       $shopinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$sjuid'");
	}
    !$shopinfo ? showmessage(lang('plugin/xlwsq_sjhd', 'sjerror') , "plugin.php?id=xlwsq_sjhd&mod=shoplist") : '';
    $shopinfo['dcominfo'] = discuzcode($shopinfo['cominfo']);
    if (!preg_match('/(http:\/\/)|(https:\/\/)/i', $shopinfo['homepage']) && $shopinfo['homepage']) {
      $shopinfo['homepage'] = "http://" . $shopinfo['homepage'];
    }
	$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_sjhd_item')." WHERE sjuid='$sjuid' AND display!='0'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 10;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE sjuid='$sjuid' AND display!='0' ORDER BY top DESC,topdateline DESC,diynum DESC,updateline DESC,id DESC LIMIT $starts,10");
        while ($shopprolist = DB::fetch($query)) {
          $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$shopprolist[cate]'");
           if ($cate['upid'] != 0) {
              $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE id = '$cate[upid]'");
              $shopprolist['cate'] = $cate_t['subject']." - ".$cate['subject'];
           } else {
              $shopprolist['cate'] = $cate['subject'];
           }
		   $shopprolist['dinfo'] = strip_tags(discuzcode($shopprolist['info']));
           $shopprolists[] = $shopprolist;
        }
    }
    $multis =multi($counts,10,$pages,'plugin.php?id=xlwsq_sjhd&mod=shopprolist&sjuid='.$sjuid.'');
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE view >'0' AND sjuid='$sjuid' AND display!='0' ORDER BY view DESC LIMIT 10");
    while ($hot = DB::fetch($hotquery)) {
        $hots[] = $hot;
    }
    $navtitle = $shopinfo['comname']. " - " .  $title;
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($shopinfo['dcominfo']) , 80, '...'));
	if($_GET['mod']=='shopinfo'){
       include template('xlwsq_sjhd:shopinfo');
	}else{
	   include template('xlwsq_sjhd:shopprolist');
	}
}elseif($_GET['mod']=='renling'){
   !$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';
   $sjuid = intval($_GET['sjuid']);
   $shopinfo = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid='$sjuid'");
   $comname = dhtmlspecialchars($shopinfo['comname']);
   $author = dhtmlspecialchars($_GET['author']);
   $uid = intval($_G['uid']);
   $tel = dhtmlspecialchars($_GET['tel']);
   $qq = dhtmlspecialchars($_GET['qq']);
   $liyou = dhtmlspecialchars($_GET['liyou']);
   $renling = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_rl') . " WHERE sjuid = '$sjuid' AND uid = '$uid'");
   if ($renling){
	 showmessage(lang('plugin/xlwsq_sjhd', 'renlingguole'), array(), array('alert' => 'error'));
   }else{
    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	 if(submitcheck('applysubrenling')){
       if($creditb!="0"){
           if($paymoney<$creditb){
                $renlingtixing= lang('plugin/xlwsq_sjhd', 'renlingxiaohaotishi').$creditb.$moneytype;
        	     showmessage(lang('plugin/xlwsq_sjhd', $renlingtixing), dreferer());
           }else{
	             updatemembercount($_G['uid'], array($paytype => -$creditb));
                 DB::insert('plugin_xlwsq_sjhd_record',array('id' => '','sid' => $sjuid,'uid' => $uid,'author' => $_G['username'],'title' => $comname,'paytype' => 4,'pay' => $creditb,'moneytype' => $moneytype,'dateline' =>$_G['timestamp']));
                 DB::INSERT('plugin_xlwsq_sjhd_rl',array('sjuid'=> $sjuid,'comname'=> $comname,'uid'=> $uid,'author'=> $author,'tel'=> $tel,'qq'=> $qq,'liyou'=> $liyou,'dateline'=> $_G['timestamp'])); 
                 for ($i = 0; $i < count($admins); $i++) {
                    $message = "<a href='plugin.php?id=xlwsq_sjhd&#58;xlwsq_sjhd_user&p=adminrenling' target='_blank'>".$author . lang('plugin/xlwsq_sjhd', 'renlingtixing') . $comname."</a>";
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                 }
                 showmessage(lang('plugin/xlwsq_sjhd', 'renlingchenggong'), 'plugin.php?id=xlwsq_sjhd&mod=cominfo&sjuid='.$sjuid, array(), array('alert' => 'right'));
           }
       }
	 }
    }	
	include template('xlwsq_sjhd:renlingshenqing');
} elseif ($_GET['mod'] == 'chongzhi') {
    $refererurl = $_SERVER["HTTP_REFERER"];
    if ($chongzhifanhui == '1') {
        header('Location: ' . $chongzhiurl);
    } else{
	    include template('xlwsq_sjhd:chongzhi');
    }
} elseif ($_GET['mod'] == 'zhiding') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditc == '0'){showmessage(lang('plugin/xlwsq_sjhd', 'zhidinggongnengweikaifang'));}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id = '$sid'");
    if($item['top']=="1"){
		showmessage(lang('plugin/xlwsq_sjhd', 'yizhiding'), array(), array('alert' => 'error'));
	}
    $title = dhtmlspecialchars($item['title']);
    $color = dhtmlspecialchars($_GET['topcolor']);
	$daytime = intval($_GET['day']);
	$time = ($daytime * 86400)+$_G['timestamp']; 
    $newcreditc = $daytime * $creditc; 
    $moneytypec = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubzhiding')){
	    if($_GET['day']<="0"){	
		 	showmessage(lang('plugin/xlwsq_sjhd', 'zhidingtianshuweitianxie'), dreferer());
	    }else{
            if($paymoney<$newcreditc){
                $tixing= lang('plugin/xlwsq_sjhd', 'zhidingxiaohaotishi').$newcreditc.$moneytypec;
        	    showmessage(lang('plugin/xlwsq_sjhd', $tixing));
            }else{
                DB::insert('plugin_xlwsq_sjhd_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $title,'day' => $daytime,'pay' => $newcreditc,'moneytype' => $moneytypec,'endtime' => $time,'paytype' => 1,'dateline' =>$_G['timestamp']));
				DB::query("UPDATE ".DB::table('plugin_xlwsq_sjhd_item')." SET `topdateline` = '$time' , `color` = '$color' WHERE `id` = '$sid'");	                   updatemembercount($_G['uid'], array($paytype => -$newcreditc));
            }
			showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'),dreferer());
        }
	}
		include template('xlwsq_sjhd:zhiding');
} elseif ($_GET['mod'] == 'miaoshen') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditd == '0'){showmessage(lang('plugin/xlwsq_sjhd', 'miaoshenweikaiqi'));}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id = '$sid'");
    if($item['display']=="1"){
		showmessage(lang('plugin/xlwsq_sjhd', 'miaoshentongguo'), array(), array('alert' => 'error'));
	}
    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubmiaoshen')){
          if($paymoney<$creditd){
              $tixing= lang('plugin/xlwsq_sjhd', 'miaoshenshibai').$creditd.$moneytype;
        	  showmessage(lang('plugin/xlwsq_sjhd', $tixing));
          }else{
			  DB::query("UPDATE ".DB::table('plugin_xlwsq_sjhd_item')." SET `display` = '1' WHERE `id` = '$sid'");
              DB::insert('plugin_xlwsq_sjhd_record',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'paytype' => 3,'pay' => $creditd,'moneytype' => $moneytype,'dateline' =>$_G['timestamp']));
			  updatemembercount($_G['uid'], array($paytype => -$creditd));
              for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_sjhd&mod=view&sid='.$item[id].'" target="_blank">'.lang('plugin/xlwsq_sjhd', 'miaoshenweisend').$item[title].'</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
              }
		      if($_G['mobile']) {
				 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'), 'plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=mylist');
		   	  } else {
                 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'),dreferer());
			  }
          }
	}
	include template('xlwsq_sjhd:miaoshen');
} elseif ($_GET['mod'] == 'shopmiaoshen') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($credite == '0'){showmessage(lang('plugin/xlwsq_sjhd', 'miaoshenweikaiqi'));}
	$sjuid = intval($_GET['sjuid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_user') . " WHERE sjuid = '$sjuid'");
    if($item['display']=="1"){
		showmessage(lang('plugin/xlwsq_sjhd', 'miaoshentongguo'), array(), array('alert' => 'error'));
	}
    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubmiaoshen')){
          if($paymoney<$credite){
              $tixing= lang('plugin/xlwsq_sjhd', 'miaoshenshibai').$credite.$moneytype;
        	  showmessage(lang('plugin/xlwsq_sjhd', $tixing));
          }else{
			  DB::query("UPDATE ".DB::table('plugin_xlwsq_sjhd_user')." SET `display` = '1' WHERE `sjuid` = '$sjuid'");
              DB::insert('plugin_xlwsq_sjhd_record',array('id' => '','sid' => $sjuid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['comname'],'paytype' => 5,'pay' => $credite,'moneytype' => $moneytype,'dateline' =>$_G['timestamp']));
			  updatemembercount($_G['uid'], array($paytype => -$credite));
              for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_sjhd&mod=cominfo&sjuid='.$item[sjuid].'" target="_blank">'.lang('plugin/xlwsq_sjhd', 'miaoshenweisend').$item[comname].'</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
              }
		      if($_G['mobile']) {
				 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'), 'plugin.php?id=xlwsq_sjhd:xlwsq_sjhd_user&p=myshoplist');
		   	  } else {
                 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'),dreferer());
			  }
          }
	}
	include template('xlwsq_sjhd:miaoshen');
} elseif ($_GET['mod'] == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
        $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id = '$sid'");
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_sjhd_favorites') . " WHERE sid = '$sid' and uid = '$uid'");
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_sjhd', 'quxiaoshoucang'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_sjhd', 'quxiaoshoucang') , '', array() , array('alert' => 'right'));
			}
        } else {
            DB::insert('plugin_xlwsq_sjhd_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'title' => $info['title'],'shoucangshijian' => $_G['timestamp']));
			if($_G['mobile']) {
                 showmessage(lang('plugin/xlwsq_sjhd', 'shoucangchenggong'),dreferer());
			} else {
                showmessage(lang('plugin/xlwsq_sjhd', 'shoucangchenggong') , '', array() , array('alert' => 'right'));
			}
            
        }
    }
} elseif ($_GET['mod'] == 'freshen') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $now = date('Y-m-d', $_G['timestamp']);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id = '$sid'");
    $uid = intval($info['uid']);
    $updateline = date('Y-m-d', $info['updateline']);
    if ($_GET['formhash'] == FORMHASH) {
        if ($info['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
            if ($now == $updateline) {
                showmessage(lang('plugin/xlwsq_sjhd', 'shuaxinshibai') , '', array() , array('alert' => 'error'));
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_sjhd_item') . " SET `updateline` = '$_G[timestamp]' WHERE `id` = '$sid'");
                showmessage(lang('plugin/xlwsq_sjhd', 'shuaxinok') , '', array() , array('alert' => 'right'));
            }
        } else {
            showmessage(lang('plugin/xlwsq_sjhd', 'caozuocuowu') , dreferer());
        }
    }
}
function ubb($Text) {
      $Text=preg_replace("/\r/","<br>",$Text);
      $Text=preg_replace("/\[url=(.+?)\](.+?)\[\/url\]/is","<a href='\\1' target='_blank'>\\2</a>",$Text);
      $Text=preg_replace("/\[img\](.+?)\[\/img\]/is","<img src='\\1' onclick='zoom(this)'>",$Text);
      $Text=preg_replace("/\[img=(.+?),(.+?)\](.+?)\[\/img\]/is","<img src='\\3' width='\\1' height='\\2' onclick='zoom(this)'>",$Text);
      $Text=preg_replace("/\[color=(.+?)\](.+?)\[\/color\]/is","<font color=\\1>\\2</font>",$Text);
      $Text=preg_replace("/\[b\](.+?)\[\/b\]/is","<b>\\1</b>",$Text);
      return $Text;
}
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
//From: Dism��taobao��com
?>