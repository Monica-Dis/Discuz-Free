<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function xlwsq_sjhd_getcache(){
		global $_G,$typedata,$upiddata,$areatypedata,$areaupiddata;
		$cachefile = DISCUZ_ROOT.'data/sysdata/cache_xlwsq_sjhd_cachedata.php';
		if(file_exists($cachefile)){
				@require_once DISCUZ_ROOT.'data/sysdata/cache_xlwsq_sjhd_cachedata.php';
		}else{
				xlwsq_sjhd_updatacache();
		}
}
function  xlwsq_sjhd_updatacache(){
	global $_G,$typedata,$upiddata;
    require_once libfile('function/cache');
      $typequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
      $typedata = array();
      $upiddata = array();
      while ($type = DB::fetch($typequery)) {
        $typedata[$type['id']] = $type;
        $upidquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_cate') . " where upid = " . $type['id'] . "  ORDER BY  displayorder DESC,id ASC");
        while ($upid = DB::fetch($upidquery)) {
            $upiddata[$type['id']][$upid['id']] = $upid;
        }
      }
      $areatypequery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " WHERE  upid='0' ORDER BY displayorder DESC,id ASC");
      $areatypedata = array();
      $areaupiddata = array();
      while ($areatype = DB::fetch($areatypequery)) {
        $areatypedata[$areatype['id']] = $areatype;
        $areaupidquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_area') . " where upid = " . $areatype['id'] . "  ORDER BY  displayorder DESC,id ASC");
        while ($areaupid = DB::fetch($areaupidquery)) {
            $areaupiddata[$areatype['id']][$areaupid['id']] = $areaupid;
        }
      }
	  writetocache('xlwsq_sjhd_cachedata', getcachevars(array('typedata' => $typedata, 'upiddata' => $upiddata, 'areatypedata' => $areatypedata, 'areaupiddata' => $areaupiddata)));
}
//From: Dism��taobao��com
?>