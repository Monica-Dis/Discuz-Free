<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/discuzcode');
if (!isset($_G['cache']['plugin'])) {loadcache('plugin');}
$plyes=($_G['cache']['plugin']['xlwsq_sjhd']);
if($_G['mobile']) {
  $menubgcolor=$plyes['mobilemenubgcolor'];
}else{
  $menubgcolor=$plyes['menubgcolor'];
}
!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';
if($_GET['option'] == 'reply'){
		$pid = intval($_GET['did']);
		$sid = intval($_GET['sid']);
        $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_post') . " WHERE pid = '$pid'");
		$pl['message'] = discuzcode($pl['message']);
        $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_sjhd_item') . " WHERE id = '$sid'");
		if($item['uid']!=$_G['uid']){
			showmessage(lang('plugin/xlwsq_sjhd', 'faburencainenghuifu'),dreferer());
		}
		if(submitcheck('applysubreply')){
		   	$reply = dhtmlspecialchars($_GET['reply']);
			DB::update('plugin_xlwsq_sjhd_post', array('reply' => $reply), "pid='$pid'");
			$tixing = '<a href="plugin.php?id=xlwsq_sjhd&mod=view&sid='.$sid.'" target="_blank">'.lang('plugin/xlwsq_sjhd', 'liuyanhuifutixing').$reply. '</a>';
            notification_add($pl['uid'], 'system',$tixing,  $notevars = array(), $system = 0);
		    if($_G['mobile']) {
				 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'), 'plugin.php?id=xlwsq_sjhd&mod=liuyan&sid='.$sid);
			} else {
                 showmessage(lang('plugin/xlwsq_sjhd', 'tijiaochenggong'),dreferer());
			}
		}
		include template('xlwsq_sjhd:reply');
}
//From: Dism��taobao��com
?>