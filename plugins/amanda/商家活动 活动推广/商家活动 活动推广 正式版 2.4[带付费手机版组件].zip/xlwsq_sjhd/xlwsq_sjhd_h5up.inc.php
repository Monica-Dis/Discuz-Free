<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once 'source/plugin/xlwsq_sjhd/class/upic.class.php';
include_once 'source/plugin/xlwsq_sjhd/class/watermark.class.php';
$plyes=($_G['cache']['plugin']['xlwsq_sjhd']);
foreach($plyes as $key=>$value){ 
    $$key=$value;
}
$uploaddx=$picdx*1024;
$uid = intval($_G['uid']);
$sjuid = intval($_GET['sjuid']);
$shopid = intval($_GET['shopid']);
$sid = intval($_GET['sid']);
$p = daddslashes($_GET['p']);
if ($_FILES['file']['error']==0 && $_GET['formhash'] == FORMHASH) {
	 $picsize = $_FILES['file']['size'];
	 $imageinfo = getimagesize($_FILES['file']['tmp_name']);
		 if ($imageinfo[0] <= 0) {
             echo json_encode(array("error" =>lang('plugin/xlwsq_sjhd', 'tupiangeshibuzhengque')));
			 exit ;
		 }
     $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
	 $arr=explode(".", strtolower($_FILES['file']["name"]));
     $hz = $arr[count($arr) - 1];
         if (!in_array($hz, $filetype)) {
             echo json_encode(array("error" => lang('plugin/xlwsq_sjhd', 'tupiangeshibuzhengque')));
			 exit ;
         }
     $update = date('YmdHis') . rand(100, 999);
     $pics =$update. "." . $hz;
	 if ($p=='userinfoedit'||$p=='adminuserinfo') {
	    $img_dir = "source/plugin/xlwsq_sjhd/upimg/".$sjuid."/shop/";
     }else{
	    $img_dir = "source/plugin/xlwsq_sjhd/upimg/".$shopid."/activity/";
     }
     if(!file_exists($img_dir)){
      mkdir($img_dir,0777,true);
     }
     $pic = $img_dir . $pics;
        if($picsize <= $uploaddx){
            if (@copy($_FILES['file']['tmp_name'], $pic) || @move_uploaded_file($_FILES['file']['tmp_name'], $pic)) {
             @unlink($_FILES['file']['tmp_name']);
            }
        }else{
            echo json_encode(array("error" =>lang('plugin/xlwsq_sjhd', 'tupiantaida')));
            exit ;
        }
		if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
			imageUpdateSize($pic,$imageinfo[0],$imageinfo[1]/($imageinfo[0]/$newpicwidth));	
        }else{
			imageUpdateSize($pic,$imageinfo[0],$imageinfo[1]);
		}
        if($imgwater && $imageinfo[0] > $waterwidth){
	        imageUpdateLogo($pic,$imgwater);
        }
	    if ($p=='userinfoedit'||$p=='adminuserinfo') {
	      DB::insert('plugin_xlwsq_sjhd_shopimg', array('id' => '','uid' => $uid,'sjuid' => $sjuid,'comimg' =>$pic,'dateline' => $_G['timestamp']));
		}
	    echo json_encode(array("error" => "0", "pic" => $pic));
}
//From: Dism��taobao��com
?>