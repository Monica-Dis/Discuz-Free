<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!empty($_FILES)) {
	$filepath = "source/plugin/xlwsq_sjhd/upimg/".date("Ymd")."/";
	if(!file_exists($filepath)){ mkdir($filepath); }
	$tempFile = $_FILES['Filedata']['tmp_name'];
    $imageinfo = getimagesize($tempFile);
	  if ($imageinfo[0] > 0) {
	    $targetPath = $_SERVER['DOCUMENT_ROOT'] . $_REQUEST['folder'] . date("Ymd") . '/';
	    $name = date('YmdHis')."_".rand(1000,9999).'.'.getExt($_FILES['Filedata']['name']);
        $fileTypes = array('jpg','jpeg','gif','png','JPG','JEPG','GIF','PNG');
        $fileParts = pathinfo($_FILES['Filedata']['name']);
        if (in_array($fileParts['extension'],$fileTypes)) {
	      $path = $filepath . $name;
	      move_uploaded_file($tempFile,$path);
	      echo $path;
        }
	  }
}
function getExt($fileName){
	$ext = explode(".", $fileName);
	$ext = $ext[count($ext) - 1];
	return strtolower($ext);
}
//From: Dism��taobao��com
?>