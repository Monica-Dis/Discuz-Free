<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_zt_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(4) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `author` varchar(80) NOT NULL,
	  `cate` int(11) NOT NULL,
	  `cateb` text NOT NULL,
	  `catec` text NOT NULL,
	  `title` varchar(255) NOT NULL,
	  `pic` varchar(255) NOT NULL,
   	  `pic2` varchar(255) NOT NULL,
   	  `url` text NOT NULL,
	  `info` text NOT NULL,
	  `view` int(11) NOT NULL,
	  `top` tinyint(1)  NOT NULL,
	  `tuijian` tinyint(1)  NOT NULL,
	  `color` text NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_zt_cate` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(1) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
INSERT INTO `pre_plugin_xlwsq_zt_cate` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '', '$installlang[cate1]', 0),
(2, 0, '', '$installlang[cate2]', 0),
(3, 0, '', '$installlang[cate3]', 0),
(4, 0, '', '$installlang[cate4]', 0),
(5, 0, '', '$installlang[cate5]', 0),
(6, 0, '', '$installlang[cate6]', 0),
(7, 0, '', '$installlang[cate7]', 0),
(8, 0, '', '$installlang[cate8]', 0);
EOF;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_zt/discuz_plugin_xlwsq_zt.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_zt/discuz_plugin_xlwsq_zt_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_zt/discuz_plugin_xlwsq_zt_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_zt/discuz_plugin_xlwsq_zt_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_zt/discuz_plugin_xlwsq_zt_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_zt/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_zt/install.php');
runquery($sql);
$finish =true;
?>