<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
global $_G;
if (!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plyes=($_G['cache']['plugin']['xlwsq_zt']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
if($_G['mobile']) {
  $menubgcolor=$mobilemenubgcolor;
  $eacha=$mobileeacha;
  $footad=$mobilefootad ? $mobilefootad : $footad;
}
$mainwidth = intval($mainwidth);
$bannerheight = intval($bannerheight);
$appurl = $_G['siteurl'] . "plugin.php?id=xlwsq_zt";
$fabuset = unserialize($groups);
$menucateb = parconfig($catebselect);
$menucatec = parconfig($catecselect);
$navtitle = $title;
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if($mod == 'index') {
    $where=$pageadd="";
    if ($_GET['key']) {
        $key=stripsearchkey($_GET['key']);
        $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND display!='0' AND";
        $keync = urlencode($key);
        $pageadd = "&key=$keync";
    }elseif($_GET['sid']){
	    $key=stripsearchkey($_GET['sid']);
		$where="id='$key' AND";
	    $keync = urlencode($key);
	    $pageadd="&key=$keync";
	}
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id = '$cate_id'");
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
        $av_d[$cate_id] = ' class="cur-on"';
		$cateidtitle = $mcate['subject'] . "-" . $mcateb['subject']. "-" .$title;
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $sd = intval($_GET['b']);
    if ($sd) {
        $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id = '$sd'");
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
        $av_d[$sd] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $sdtype = intval($_GET['m']);
    if ($sdtype) {
        $sm[] = "cateb = '$sdtype'";
        $pageaddm = "&m=$sdtype";
        $m_hover[$sdtype] = ' class="cur-on"';
        if ($menucateb[$sdtype]) {$cidtitle=$menucateb[$sdtype]." - ";}
    }
    if ($sm){ $fm ="instr(concat(',',`cateb`,','),',$sdtype,') AND";}
    $sdtypeb = intval($_GET['n']);
    if ($sdtypeb) {
        $sn[] = "catec = '$sdtypeb'";
        $pageaddn = "&n=$sdtypeb";
        $n_hover[$sdtypeb] = ' class="cur-on"';
        if ($menucatec[$sdtypeb]) {$sidtitle=$menucatec[$sdtypeb]." - ";}
    }
    if ($sn){ $fn ="instr(concat(',',`catec`,','),',$sdtypeb,') AND";}

	if($_GET['tj']){
		$px="tuijian = '1' OR tuijian = '2' AND display='1' ORDER BY dateline DESC"; $pageadd="&tj=t";
        $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_zt_item') . " WHERE $where $wb $wc $fm $fn tuijian='1' OR tuijian = '2'  AND display='1'");	
	}elseif($_GET['rq']){
		$px="view > '0' AND display!='0' ORDER BY view DESC"; $pageadd="&rq=rq";
        $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_zt_item') . " WHERE $where $wb $wc $fm $fn view>'0' AND display!='0'");	
	}else{
		$px="display!='0' ORDER BY top DESC,diynum DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_zt_item')." WHERE $where $wb $wc $fm $fn display!='0'");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_item') . " WHERE $where $wb $wc $fm $fn $px LIMIT $starts,$eacha");
        $mythread = $mythreads = array();
        while ($mythread = DB::fetch($query)) {
			$cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id = '$cate[upid]'");
                $mythread['cate'] = $cate['subject'];
            } else {
                $mythread['cate'] = $cate['subject'];
            }
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl'>" . multi($counts, $eacha, $pages, $appurl . $pageadd.$pageadds .$pageaddx . $pageaddm . $pageaddn) . "</div>";
    $r_id = intval($_GET['a']);
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $local[$row['id']] = $row;
    }
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_zt_item')." WHERE tuijian ='2' AND display!='0' ORDER BY diynum DESC,dateline DESC");
	$tuijian = $tuijians = array();
	while($tuijian = DB::fetch($query)){
		$tuijians[] = $tuijian;
	}
    if ($cate_id!='0') {
      if ($sd!='0') {
           $navtitle = $mcate['subject'] . " - " . $mcateb['subject']. " - " .$cidtitle.$sidtitle.$title;
      } else {
           $navtitle = $mcate['subject']. " - " .$cidtitle.$sidtitle.$title;
      }
    }
    include template('xlwsq_zt:list');
} elseif ($_GET['mod'] == 'view') {
    $r_id = intval($_GET['a']);
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $local[$row['id']] = $row;
    }
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    $sid = intval($_GET['sid']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_zt_item') . " WHERE id = '$sid' and display!='0'");
    !$mythread ? showmessage(lang('plugin/xlwsq_zt', 'error') , "plugin.php?id=xlwsq_zt") : '';
    $url = $mythread['url'];
    DB::query("UPDATE " . DB::table('plugin_xlwsq_zt_item') . " SET `view` = view+1 WHERE `id` = '$sid'");
    $navtitle = $mythread['title']. " - " .$title;
    if($_G['mobile']) {	
		include template('xlwsq_zt:view');
	} else {
	    header('Location: '.$url);
	}
}
function parconfig($str) {
    $return = array();
    $array = explode("\n", str_replace("\r", "", $str));
    foreach ($array as $v) {
        $t = explode("=", $v);
        $t[0] = trim($t[0]);
        $return[$t[0]] = $t[1];
    }
    return $return;
}
//From: Dism��taobao��com
?>