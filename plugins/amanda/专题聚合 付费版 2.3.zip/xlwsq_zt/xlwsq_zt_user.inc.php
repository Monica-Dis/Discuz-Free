<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
loadcache('plugin');
$plyes=($_G['cache']['plugin']['xlwsq_zt']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
$appurls = $_G['siteurl'] . "plugin.php?id=xlwsq_zt:xlwsq_zt_user";
$catebselect = parconfig($catebselect);
$catecselect = parconfig($catecselect);
$picdx = $picdx * 1024;
$navtitle = $title;
$admins = explode(",", $groupso);
$p = $_GET['p'] ? $_GET['p'] : 'index';
if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {} else {showmessage(lang('plugin/xlwsq_zt', 'wuquanxiancaozuo') , '', array() , array('alert' => 'right'));}
if ($p == 'adminalllist'||$p == 'index') {
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_zt_item'));
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_item') . " ORDER BY dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $appurl = $_G['siteurl'] . "plugin.php?id=xlwsq_zt:xlwsq_zt_user&p=adminalllist";
        $multir = "<div class='pages cl' style='margin-top:10px;'>" . multi($countr, 20, $pager, $appurl . $pageadd) . "</div>";
    if (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_zt_item') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_zt', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_zt_item') . " SET display='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_zt', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_zt_item') . " SET top='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_zt', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_zt_item') . " SET top='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_zt', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_zt_item') . " WHERE id ='$aid'LIMIT 0 , 1");
            if ($active["pic"] != false) {
                unlink($active["pic"]);
            }
            if ($active["pic2"] != false) {
                unlink($active["pic2"]);
            }
		    DB::query("DELETE FROM ".DB::table('plugin_xlwsq_zt_item')." WHERE id = '$aid' ");$nums++;
        }
        showmessage(lang('plugin/xlwsq_zt', 'shanchuok') , dreferer());
    }

} elseif ($p == 'add') {
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE upid='0'  ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
        if (submitcheck('applysubmit')) {
            $uid = intval($_G['uid']);
            $title = daddslashes($_GET['title']);
            $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
            $cateb = daddslashes(implode(',',$_GET["cateb"]));
            $catec = daddslashes(implode(',',$_GET["catec"]));
            $url = daddslashes($_GET['url']);
            $info = daddslashes($_GET['info']);
            $top = intval($_GET['top']);
            $tuijian = intval($_GET['tuijian']);
			$display = intval($_GET['display']);
            $diynum = intval($_GET['diynum']);
            $timestamp = $_G['timestamp'];
            $color = dhtmlspecialchars($_GET['color']);
            if ($_FILES['file']['error'] == 0) {
                $rand = date("YmdHis") . random(3, $numeric = 1);
                $filesize = $_FILES['file']['size'] <= $picdx;
                $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                $arr = explode(".", $_FILES["file"]["name"]);
                $hz = $arr[count($arr) - 1];
                if (!in_array($hz, $filetype)) {
                    showmessage(lang('plugin/xlwsq_zt', 'tupiangeshibuzhengque'));
                }
                $filepath = "source/plugin/xlwsq_zt/upimg/" . date("Ymd") . "/";
                $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
                if (!file_exists($filepath)) {
                    mkdir($filepath);
                }
                if ($filesize) {
                    if (@copy($_FILES['file']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath . $randname))) {
                        @unlink($_FILES['file']['tmp_name']);
                    }
                } else {
                    showmessage(lang('plugin/xlwsq_zt', 'chaochudaxiao'));
                }
                $pic = "source/plugin/xlwsq_zt/upimg/" . date("Ymd") . "/" . $randname . "";
            }
            if ($_FILES['file2']['error'] == 0) {
                $rand = date("YmdHis") . random(3, $numeric = 1);
                $filesize = $_FILES['file2']['size'] <= $picdx;
                $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                $arr = explode(".", $_FILES["file2"]["name"]);
                $hz = $arr[count($arr) - 1];
                if (!in_array($hz, $filetype)) {
                    showmessage(lang('plugin/xlwsq_zt', 'tupiangeshibuzhengque'));
                }
                $filepath = "source/plugin/xlwsq_zt/banner/" . date("Ymd") . "/";
                $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
                if (!file_exists($filepath)) {
                    mkdir($filepath);
                }
                if ($filesize) {
                    if (@copy($_FILES['file2']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file2']['tmp_name'], $filepath . $randname))) {
                        @unlink($_FILES['file2']['tmp_name']);
                    }
                } else {
                    showmessage(lang('plugin/xlwsq_zt', 'chaochudaxiao'));
                }
                $pic2 = "source/plugin/xlwsq_zt/banner/" . date("Ymd") . "/" . $randname . "";
            }
            DB::insert('plugin_xlwsq_zt_item', array(
                'id' => '',
                'uid' => $uid,
                'author' => $_G['username'],
                'title' => $title,
                'pic' => $pic,
                'pic2' => $pic2,
                'cate' => $cate,
                'cateb' => $cateb,
                'catec' => $catec,
                'url' => $url,
                'info' => $info,
                'top' => $top,
                'tuijian' => $tuijian,
                'color' => $color,
                'display' => $display,
                'diynum' => $diynum,
                'dateline' => $timestamp
            ));
            if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
                showmessage(lang('plugin/xlwsq_zt', 'fabuchenggong') , 'plugin.php?id=xlwsq_zt:xlwsq_zt_user&p=index', array() , array('alert' => 'right'));
            } else {
                for ($i = 0; $i < count($admins); $i++) {
                    $message = '<a href="plugin.php?id=xlwsq_zt&#58;xlwsq_zt_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_zt', 'yonghufabuxinxinxi') . '</a>';
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                }
                showmessage(lang('plugin/xlwsq_zt', 'fabudengdaishenhe') , 'plugin.php?id=xlwsq_zt:xlwsq_zt_user&p=index', array() , array('alert' => 'right'));
            }
        }
} elseif ($p == 'edit') {
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_zt_item') . " WHERE id='$id'");
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_zt_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC ");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    $catecarray = change($active['catec']);
    $catebarray = change($active['cateb']);
    if (submitcheck('applysubmit')) {
        $sid = intval($_GET['sid']);
        $title = daddslashes($_GET['title']);
        $pic = daddslashes($_GET['pic']);
        $pic2 = daddslashes($_GET['pic2']);
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $cateb = daddslashes(implode(',',$_GET["cateb"]));
        $catec = daddslashes(implode(',',$_GET["catec"]));
        $url = daddslashes($_GET['url']);
        $info = daddslashes($_GET['info']);
        $top = intval($_GET['top']);
        $tuijian = intval($_GET['tuijian']);
        $display = intval($_GET['display']);
        $color = dhtmlspecialchars($_GET['color']);
        $diynum = intval($_GET['diynum']);
        if ($_GET['gengxin']==1) {
            $timestamp = $_G['timestamp'];
        }else{
            $timestamp = $active['dateline'];
		}
        if ($_FILES['file']['error'] == 0) {
            if ($active["pic"] != false) {
                unlink($active["pic"]);
            }
            $filesize = $_FILES['file']['size'] <= $picdx;
            $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
            $arr = explode(".", $_FILES["file"]["name"]);
            $hz = $arr[count($arr) - 1];
            if (!in_array($hz, $filetype)) {
                showmessage(lang('plugin/xlwsq_zt', 'tupiangeshibuzhengque'));
            }
            $filepath = "source/plugin/xlwsq_zt/upimg/" . date("Ymd") . "/";
            $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
            if (!file_exists($filepath)) {
                mkdir($filepath);
            }
            if ($filesize) {
                    if (@copy($_FILES['file']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath . $randname))) {
                        @unlink($_FILES['file']['tmp_name']);
                    }
            } else {
                    showmessage(lang('plugin/xlwsq_zt', 'chaochudaxiao'));
            }
            $pic = "source/plugin/xlwsq_zt/upimg/" . date("Ymd") . "/" . $randname . "";
        }
        if ($_FILES['file2']['error'] == 0) {
            if ($active["pic2"] != false) {
                unlink($active["pic2"]);
            }
            $filesize = $_FILES['file2']['size'] <= $picdx;
            $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
            $arr = explode(".", $_FILES["file2"]["name"]);
            $hz = $arr[count($arr) - 1];
            if (!in_array($hz, $filetype)) {
                showmessage(lang('plugin/xlwsq_zt', 'tupiangeshibuzhengque'));
            }
            $filepath = "source/plugin/xlwsq_zt/banner/" . date("Ymd") . "/";
            $randname = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
            if (!file_exists($filepath)) {
                mkdir($filepath);
            }
            if ($filesize) {
                    if (@copy($_FILES['file2']['tmp_name'], $filepath . $randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file2']['tmp_name'], $filepath . $randname))) {
                        @unlink($_FILES['file2']['tmp_name']);
                    }
            } else {
                    showmessage(lang('plugin/xlwsq_zt', 'chaochudaxiao'));
            }
            $pic2 = "source/plugin/xlwsq_zt/banner/" . date("Ymd") . "/" . $randname . "";
        }
        DB::update('plugin_xlwsq_zt_item', array(
            'title' => $title,
            'pic' => $pic,
            'pic2' => $pic2,
            'cate' => $cate,
            'cateb' => $cateb,
            'catec' => $catec,
            'url' => $url,
            'info' => $info,
            'top' => $top,
            'tuijian' => $tuijian,
            'color' => $color,
            'display' => $display,
            'dateline' => $timestamp,
            'diynum' => $diynum
        ) , "id='$sid'");

            showmessage(lang('plugin/xlwsq_zt', 'gengxinok') , dreferer());
    }
} elseif ($p == 'shenheok') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_zt_item') . " SET display='1' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_zt', 'gengxinok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_zt', 'caozuocuowu'));
    }
} elseif ($p == 'qxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_zt_item') . " SET display='0' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_zt', 'gengxinok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_zt', 'caozuocuowu'));
    }
} elseif ($p == 'del') {
    $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_zt_item') . " WHERE id ='$id'");
            if ($active["pic"] != false) {
                unlink($active["pic"]);
            }
            if ($active["pic2"] != false) {
                unlink($active["pic2"]);
            }
			DB::query("DELETE FROM ".DB::table('plugin_xlwsq_zt_item')." WHERE id = '$id'");
            showmessage(lang('plugin/xlwsq_zt', 'shanchuok') , dreferer());
        }
}
include (template("xlwsq_zt:xlwsq_zt_user"));
function change($str){
	$return = array();
	$array = explode(",",$str);
	foreach ($array as $v){
		$t = explode(" ",$v);
		$return[$t[0]] = $t[0];
	}
	return $return;
}
function parconfig($str){
	$return = array();
	$array = explode("\n",str_replace("\r","",$str));
	foreach ($array as $v){
	   $t = explode("=",$v);
	   $t[0] = trim($t[0]);
	   $return[$t[0]] = $t[1];
	}
	return $return;
} 
?>