<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	$action = daddslashes($_GET['action']);
	$bl_name= dhtmlspecialchars($_GET['bl']);
	if($action == 'cate') {
		$lid = intval($_GET['lid']);
		$show = '';
		if($lid) {
			$subid = DB::result_first("SELECT subid FROM ".DB::table('plugin_xlwsq_zt_cate')." WHERE id='{$lid}'");
			if($subid) {
				$show = '<select class="ps" name="'.$bl_name.'" id="'.$bl_name.'"><option value=""></option>';
				$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_zt_cate')." WHERE id IN ({$subid})");
				while($row = DB::fetch($query)) {
					$show .= '<option value="'.$row['id'].'">'.$row['subject'].'</option>';
				}
				$show .= '</select>';
			} else {
				$show = '';
			}
		}
	}elseif($action=='area'){
		$lid = intval($_GET['lid']);
		$show = '';
		if($lid) {
			$subid = DB::result_first("SELECT subid FROM ".DB::table('plugin_xlwsq_zt_area')." WHERE id='{$lid}'");
			if($subid) {
				$show = '<select class="ps" name="'.$bl_name.'" id="'.$bl_name.'"><option value=""></option>';
				$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_zt_area')." WHERE id IN ({$subid})");
				while($row = DB::fetch($query)) {
					$show .= '<option value="'.$row['id'].'">'.$row['subject'].'</option>';
				}
				$show .= '</select>';
			} else {
				$show = '';
			}
		}
	}
include template("xlwsq_zt:select");
?>