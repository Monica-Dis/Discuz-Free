<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once 'source/plugin/xlwsq_wxdh/function/function_core.php';
loadcache('plugin');
$plyes=($_G['cache']['plugin']['xlwsq_wxdh']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
if($_G['mobile']) {
  $menubgcolor=$mobilecolor;
  $footad=$mobilefootad;
}
$zhuantilogowidth=600;
$fabuset = unserialize($groups);
$mianshenhe = unserialize($mianshenhe);
$diysdlist = parconfig($diysd);
$leixinglist = parconfig($leixing);
$navtitle = $title;
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$p = $_GET['p'] ? $_GET['p'] : 'index';
if ($p == 'mylist'||$p == 'index') {
    if ($p == 'mylist') {
	    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    }
        $where=$pageadd="";
        if($_GET['key']){
          $key=stripsearchkey($_GET['key']);
	      $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND";
	      $keync=urlencode($key);
	      $pageadd="&key=$keync";
        }
        $uid = intval($_G['uid']);
        $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE $where uid='$uid'");
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE $where uid='$uid' ORDER BY display ASC,dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                if ($rw['topdateline']!='0'){DB::query("UPDATE ".DB::table('plugin_xlwsq_wxdh_item')." SET `topdateline` = '0',`color` = '' WHERE topdateline!= '0' AND  topdateline <= ".$_G['timestamp']);}
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $multir = "<div class='pages cl' style='margin:10px 0;'>" . multi($countr, 20, $pager, 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p='.$p. $pageadd) . "</div>";
	    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
        $paymoney = getuserprofile('extcredits'."$paytype");
} elseif ($p == 'adminalllist') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $where=$pageadd="";
		$adminleixing = intval($_GET['lx']);
        if ($adminleixing){$lx = "WHERE leixing ='$adminleixing AND'";$pageadd="&lx=$adminleixing";}
        if($_GET['key']){
          $key=stripsearchkey($_GET['key']);
	      $where="WHERE title like '%".addcslashes(addslashes($key), '%_')."%' ";
	      $keync=urlencode($key);
	      $pageadd="&key=$keync";
        }
	    $countr = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_item') .  " $lx $where ");
        $pager = intval($_GET['page']);
        $pager = max($pager, 1);
        $starts = ($pager - 1) * 20;
        if ($countr) {
            $rs = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " $lx $where ORDER BY display ASC,dateline DESC LIMIT $starts,20");
            while ($rw = DB::fetch($rs)) {
                $pa = DB::fetch(DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$rw[cate]'"));
                if ($pa['upid'] != 0) {
                    $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$pa[upid]'");
                    $rw['cate'] = $cate_t['subject'] . " - " . $pa['subject'];
                } else {
                    $rw['cate'] = $pa['subject'];
                }
                $manylist[] = $rw;
            }
        }
        $multir = "<div class='pages cl' style='margin:10px 0;'>" . multi($countr, 20, $pager, 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p=adminalllist'.$pageadd) . "</div>";
    } else {
        showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), dreferer());
    }
    if (submitcheck('applysubmsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_item') . " SET display='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wxdh', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxsh')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_item') . " SET display='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wxdh', 'gengxinok') , dreferer());

	}elseif(submitcheck('applysubmtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_wxdh_item')." SET tuijian='1' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_wxdh', 'gengxinok'), dreferer());
	}elseif(submitcheck('applysubmqxtj')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
            $aid = intval($aid);
			DB::query("UPDATE ".DB::table('plugin_xlwsq_wxdh_item')." SET tuijian='0' WHERE id='$aid' LIMIT 1");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_wxdh', 'gengxinok'), dreferer());	
    } elseif (submitcheck('applysubmzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_item') . " SET top='1' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wxdh', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxzd')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_item') . " SET top='0' WHERE id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wxdh', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmqxtg')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_item') . " SET `topdateline` = '0',`color` = '' WHERE topdateline!= '0' AND id='$aid' LIMIT 1");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wxdh', 'gengxinok') , dreferer());
    } elseif (submitcheck('applysubmdel')) {
        $pl_id = implode('|', $_GET['piliang']);
        $deid = explode('|', $pl_id);
        $nums = 0;
        foreach ($deid as $aid) {
            $aid = intval($aid);
            $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE id ='$aid'LIMIT 0 , 1");
             for ($i = 1; $i <= 5; $i++) {
               $pic = 'pic'.$i;
		       unlink($active[$pic]);
             }
            DB::query("DELETE a,b,c FROM ".DB::table('plugin_xlwsq_wxdh_item')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_wxdh_post')." AS b ON b.sid = a.id LEFT JOIN ".DB::table('plugin_xlwsq_wxdh_reply')." AS c ON c.dpid = b.id WHERE a.id = '$aid' ");
            $nums++;
        }
        showmessage(lang('plugin/xlwsq_wxdh', 'shanchuok') , dreferer());
    }
}elseif($p=='adminpinglun'){
if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        if ($_GET['action'] == 'daishen'){
			$ds = " WHERE display ='0'";
			$dss = " AND b.display ='0'";
			$pageadd="&action=daishen";
		}elseif ($_GET['action'] == 'yishen'){
			$ds = " WHERE display ='1'";
			$dss = " AND b.display ='1'";
			$pageadd="&action=yishen";
        }
		$countr = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_post').$ds);
		$pager = intval($_GET['page']);
		$pager = max($pager, 1);
		$starts = ($pager - 1) * 20;
		if($countr) {
			$rs=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_item')." a, ".DB::table('plugin_xlwsq_wxdh_post')." b WHERE  a.id = b.sid $dss ORDER BY b.dateline DESC LIMIT $starts,20");
			while ($rw=DB::fetch($rs)){
		            $recount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_reply')." WHERE dpid = ".$rw['id']." AND display!='0'");
		            $rw['count'] = $recount; 
				$manylist[]=$rw;
			}
			    $manylist = dhtmlspecialchars($manylist);
		}
		$multir = "<div class='cl' style='margin:5px;'>".multi($countr, 20, $pager, 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p=adminpinglun'.$pageadd)."</div>";
	}else{
		   showmessage(lang('plugin/xlwsq_wxdh', 'caozuocuowu'));
	}
	if(submitcheck('applysubmsh')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $aid) {
           $aid = intval($aid);
           $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_post')." where id = '$aid'");
		    DB::query("UPDATE ".DB::table('plugin_xlwsq_wxdh_post')." SET display='1' WHERE id='$aid' LIMIT 1");
	       $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_post')." where sid='$pl[sid]' AND display!='0' ");
           $sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4', sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe' FROM ".DB::table('plugin_xlwsq_wxdh_post')." WHERE sid='$pl[sid]' AND display!='0' ";
					$result = DB::query($sql);
					$row = DB::fetch($result);  
						$pf0 = intval($row['pf0']);
						$pf1 = intval($row['pf1']);
						$pf2 = intval($row['pf2']);
						$pf3 = intval($row['pf3']);
						$pf4 = intval($row['pf4']);
						$pfa = intval($row['pfa']);
						$pfb = intval($row['pfb']);
						$pfc = intval($row['pfc']);
						$pfd = intval($row['pfd']);
						$pfe = intval($row['pfe']);
              DB::update('plugin_xlwsq_wxdh_item', array('pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'dpcount' => $dpcount), "id='$pl[sid]'");
			$nums++;
		}
		showmessage(lang('plugin/xlwsq_wxdh', 'gengxinok'), dreferer());	
	}elseif(submitcheck('applysubmdel')){
		$pl_id = implode('|', $_GET['piliang']);
		$deid = explode('|', $pl_id);
		$nums = 0;
		foreach($deid as $ssd) {
        $ssd = intval($ssd);
 		    $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_post')." where id = '$ssd'");
  		    $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_item')." where id = '$pl[sid]'");
			DB::delete('plugin_xlwsq_wxdh_post',array('id'=> $ssd));
			DB::delete('plugin_xlwsq_wxdh_reply',array('dpid'=> $ssd));
			        $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_post')." where sid='$pl[sid]'"); 
					$sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe'  FROM ".DB::table('plugin_xlwsq_wxdh_post')." WHERE sid='$pl[sid]'";
					$result = DB::query($sql);
					$row = DB::fetch($result);  
						$pf0 = intval($row['pf0']);
						$pf1 = intval($row['pf1']);
						$pf2 = intval($row['pf2']);
						$pf3 = intval($row['pf3']);
						$pf4 = intval($row['pf4']);
						$pfa = intval($row['pfa']);
						$pfb = intval($row['pfb']);
						$pfc = intval($row['pfc']);
						$pfd = intval($row['pfd']);
						$pfe = intval($row['pfe']);
	        DB::update('plugin_xlwsq_wxdh_item', array('pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'dpcount' => $dpcount),"id ='$pl[sid]'");
			$nums++;
		}
            showmessage(lang('plugin/xlwsq_wxdh', 'shanchuok'), dreferer());
    }
}elseif($p=='adminxfjl'||$p=='adminpingfenjiangli'){
    if($_G['groupid']!=1&&!in_array($_G['uid'], $admins)){
		    showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), dreferer());
	}
    $where=$pageadd="";
	$key=stripsearchkey($_GET['key']);
    $keytype = intval($_GET['keytype']);
    if($key){
     if($keytype==1){
        $where=" WHERE author ='$key' ";
     }elseif($keytype==2){
        $where=" WHERE title ='$key' ";
	 }
	 $keync=urlencode($key);
	 $pageadd="&keytype=$keytype&key=$keync";
    }
	if($p=='adminxfjl'){	
	   $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_xfjl').$where);
     }elseif($p=='adminpingfenjiangli'){
	   $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_pinglunjiangli').$where);
	}
	$pages = intval($_GET['page']);
	$pages = max($pages, 1);
	$starts = ($pages - 1) * 30;
    if($counts) {
  	  if($p=='adminxfjl'){	
	     $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_xfjl')." $where ORDER BY dateline DESC LIMIT $starts,30");
      }elseif($p=='adminpingfenjiangli'){
		 $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_pinglunjiangli')." $where ORDER BY dateline DESC LIMIT $starts,30");
      }
	  $manylist = $manylists = array();
	  while($manylist = DB::fetch($query)){
		$manylists[] = $manylist;
	  }
    }
	$multis = "<div class='cl' style='margin:5px'>".multi($counts, 30, $pages, 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p='.$p.$pageadd)."</div>";
} elseif ($p == 'add') {
  $groups = unserialize($groups);
  if (!in_array($_G['groupid'], $groups)) {
        showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo') , '', array() , array('login' => true));
  } else {
    include_once 'source/plugin/xlwsq_wxdh/class/upic.class.php';
    include_once 'source/plugin/xlwsq_wxdh/class/watermark.class.php';
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;   
    }
    $zhuantiquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti') . "  ORDER BY diynum DESC,id ASC");
    while ($zhuanti = DB::fetch($zhuantiquery)) {
        $zhuantis[] = $zhuanti;
    }
	$moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
        if (submitcheck('applysubmit')) {
            if(($credit!="0" && $paytype)&&($paymoney<$credit)){
               $tixing= lang('plugin/xlwsq_wxdh', 'xiaohaotishi').$credit.$moneytype;
               if (empty($chongzhiurl)) {
	              showmessage($tixing, dreferer());
	           }else{
                  showmessage($tixing, 'plugin.php?id=xlwsq_wxdh&mod=usercenterchongzhi', array() , array('alert' => error));
               }
            }
            $title = dhtmlspecialchars($_GET['title']);
			$cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
            $leixing = intval($_GET['leixing']);
		    $sd1 = dhtmlspecialchars($_GET['sd1']);
		    $sd2 = dhtmlspecialchars($_GET['sd2']);
		    $sd3 = dhtmlspecialchars($_GET['sd3']);
		    $sd4 = dhtmlspecialchars($_GET['sd4']);
		    $sd5 = dhtmlspecialchars($_GET['sd5']);
            $info = addslashes($_GET['info']);
            $dpname = dhtmlspecialchars(merge_spaces($_GET['dpname']));
            $biaoqian = dhtmlspecialchars(merge_spaces($_GET['biaoqian']));
		    $view=intval($_GET['view']);
		    $tuijian=intval($_GET['tuijian']);
			$top=intval($_GET['top']);
		    $color = dhtmlspecialchars($_GET['color']);
            if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
                  $display =1; 
            }else{
				 $display =0; 
            }
			$diynum=intval($_GET['diynum']);
            $zhuanti =  dhtmlspecialchars(implode(',',$_GET["zhuanti"]));
            for ($i = 1; $i <= 5; $i++) {
               $pic = 'pic'.$i;
               if ($_FILES[$pic]['tmp_name']) {
				    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
					$picsize = $_FILES[$pic]['size'];
				    if ($imageinfo[0] <= 0) {
                        showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));
				    }
                    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                    $arr = explode(".", $_FILES[$pic]["name"]);
                    $hz = $arr[count($arr) - 1];
                    if (!in_array($hz, $filetype)) {
                       showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));
                    }
                    $pics = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
				    $img_dir = "source/plugin/xlwsq_wxdh/upimg/" . date("Ymd") . "/";
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $$pic = $img_dir . $pics;
                    if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
                        @unlink($_FILES[$pic]['tmp_name']);
                    }
               }
               if($logowaterset==1){
				   $pici=0;
			   }else{
			       $pici=2;
			   }
			   if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
				   new myThumbClass($$pic,1,2,$$pic,1,$newpicwidth); 
				   $imageinfo = getimagesize($$pic);
			   }
               if(($i>$pici)&& $imgwater && $imageinfo[0] > $waterwidth){
	                $wm = new WaterMark();
	                $wm->setImSrc($$pic);
	                $wm->setImWater($imgwater);
	                $wm->mark(1,$imgwaterweizhi,0,0);
			   }
            }
            DB::insert('plugin_xlwsq_wxdh_item', array('id' => '','uid' => $_G['uid'],'author' => $_G['username'],'cate' => $cate,'leixing' => $leixing,'title' => $title,'pic1' => $pic1,'pic2' => $pic2,'pic3' => $pic3,'pic4' => $pic4,'pic5' => $pic5,'sd1' => $sd1,'sd2' => $sd2,'sd3' => $sd3,'sd4' => $sd4,'sd5' => $sd5,'info' => $info,'dpname' => $dpname,'biaoqian' => $biaoqian,'view' => $view,'top' => $top,'tuijian' => $tuijian,'color' => $color,'display' => $display,'diynum' => $diynum, 'zhuanti' => $zhuanti,'dateline' => $_G['timestamp']));
			 if($credit!="0" && $paytype){
			   $xfid = DB::insert_id();
			   $moneytypec = $_G['setting']['extcredits'][$paytype]['title'];
	           updatemembercount($_G['uid'], array($paytype => -$credit));
			   DB::insert('plugin_xlwsq_wxdh_xfjl',array('id' => '','sid' => $xfid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $title,'pay' => $credit,'moneytype' => $moneytypec,'xftype' => '1','dateline' =>$_G['timestamp']));
             }
             if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
                showmessage(lang('plugin/xlwsq_wxdh', 'fabuchenggong') , 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p=index', array() , array('alert' => right));
             } else {
                for ($i = 0; $i < count($admins); $i++) {
                    $message = '<a href="plugin.php?id=xlwsq_wxdh&#58;xlwsq_wxdh_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_wxdh', 'yonghufabuxinxinxi') . '</a>';
                    notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                }
                showmessage(lang('plugin/xlwsq_wxdh', 'fabudengdaishenhe') , 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p=index', array() , array('alert' => right));
            }
        }
  }
} elseif ($p == 'edit') {
    $id = intval($_GET['sid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE id='$id'");
    $uid = intval($active['uid']);
    if ($active['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
    } else {
        showmessage(lang('plugin/xlwsq_wxdh', 'caozuocuowu') , '', array() , array('login' => true));
    }
    include_once 'source/plugin/xlwsq_wxdh/class/upic.class.php';
    include_once 'source/plugin/xlwsq_wxdh/class/watermark.class.php';
    $cate = DB::result_first("SELECT upid FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id='$active[cate]'");
    if ($cate) {
        $catetwoshow = '<select name="cate_two" >';
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE upid='$cate'");
        while ($row = DB::fetch($query)) {
            if ($row['id'] == $active['cate']) {
                $catetwoshow.= '<option value="' . $row['id'] . '" selected >' . $row['subject'] . '</option>';
            } else {
                $catetwoshow.= '<option value="' . $row['id'] . '">' . $row['subject'] . '</option>';
            }
        }
        $catetwoshow.= '</select>';
    } else {
        $cate = $active['cate'];
    }
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $cates[$row['id']] = $row;
    }
    $zhuantiquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti') . "  ORDER BY diynum DESC,id ASC");
    while ($zhuanti = DB::fetch($zhuantiquery)) {
        $zhuantis[] = $zhuanti;
    }
    $zhuantiarray = change($active['zhuanti']);
    if (submitcheck('applysubmit')) {
        $cate = intval($_GET['cate_two']) ? intval($_GET['cate_two']) : intval($_GET['cate_1']);
        $leixing = dhtmlspecialchars($_GET['leixing']);
        $title = dhtmlspecialchars($_GET['title']);
        $pic1 = dhtmlspecialchars($_GET['pic1']);
        $pic2 = dhtmlspecialchars($_GET['pic2']);
        $pic3 = dhtmlspecialchars($_GET['pic3']);
        $pic4 = dhtmlspecialchars($_GET['pic4']);
        $pic5 = dhtmlspecialchars($_GET['pic5']);
		$sd1 = dhtmlspecialchars($_GET["sd1"]);
		$sd2 = dhtmlspecialchars($_GET["sd2"]);
		$sd3 = dhtmlspecialchars($_GET["sd3"]);
		$sd4 = dhtmlspecialchars($_GET["sd4"]);
		$sd5 = dhtmlspecialchars($_GET["sd5"]);
        $info = addslashes($_GET['info']);
        $dpname = dhtmlspecialchars(merge_spaces($_GET['dpname']));
        $biaoqian = dhtmlspecialchars(merge_spaces($_GET['biaoqian']));
        $top = intval($_GET['top']);
        $view = intval($_GET['view']);
        $tuijian = intval($_GET['tuijian']);
        $color = dhtmlspecialchars($_GET["color"]);
        if ($_G['groupid']=="1"||in_array($_G['groupid'], $mianshenhe)||in_array($_G['uid'], $admins)){
            $display = 1;
        } else {
            $display = 0;
        }
        $diynum = intval($_GET['diynum']);
		$topdateline = dhtmlspecialchars($_GET['topdateline']);
        if ($_G['groupid']=="1" ||in_array($_G['uid'], $admins)){
            $zhuanti =  dhtmlspecialchars(implode(',',$_GET["zhuanti"]));
        } else {
            $zhuanti =  dhtmlspecialchars($_GET["zhuanti"]);
        }
            for ($i = 1; $i <= 5; $i++) {
               $pic = 'pic'.$i;
               $picdel = 'picdelete'.$i;
			   if ($_GET[$picdel]==1){
		            unlink($active[$pic]);
                    $$pic = "";
	           }
               if ($_FILES[$pic]['tmp_name']) {
                    if ($active[$pic]!=false){
	                   unlink($active[$pic]);
	                }
				    $imageinfo = getimagesize($_FILES[$pic]['tmp_name']);
					$picsize = $_FILES[$pic]['size'];
				    if ($imageinfo[0] <= 0) {
                        showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));
				    }
                    $filetype = array("jpg","jpeg","gif","png","JPG","JPEG","GIF","PNG");
                    $arr = explode(".", $_FILES[$pic]["name"]);
                    $hz = $arr[count($arr) - 1];
                    if (!in_array($hz, $filetype)) {
                       showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));
                    }
                    $pics = date("Y") . date("m") . date("d") . date("H") . date("i") . date("s") . rand(100, 999) . "." . $hz;
				    $img_dir = "source/plugin/xlwsq_wxdh/upimg/" . date("Ymd") . "/";
                    if (!is_dir($img_dir)) {
                        mkdir($img_dir);
                    }
                    $$pic = $img_dir . $pics;
                    if (@copy($_FILES[$pic]['tmp_name'], $$pic) || @move_uploaded_file($_FILES[$pic]['tmp_name'], $$pic)) {
                        @unlink($_FILES[$pic]['tmp_name']);
                    }
               }
               if($logowaterset==1){
				   $pici=0;
			   }else{
			       $pici=2;
			   }
			   if (($imageinfo[0] > $newpicwidth) && $newpicwidth!='0') {
				   new myThumbClass($$pic,1,2,$$pic,1,$newpicwidth); 
				   $imageinfo = getimagesize($$pic);
			   }
               if(($i>$pici)&& $imgwater && $imageinfo[0] > $waterwidth){
	                $wm = new WaterMark();
	                $wm->setImSrc($$pic);
	                $wm->setImWater($imgwater);
	                $wm->mark(1,$imgwaterweizhi,0,0);
               }
            }
        DB::update('plugin_xlwsq_wxdh_item', array('cate' => $cate,'leixing' => $leixing,'title' => $title,'sd1' => $sd1,'sd2' => $sd2,'sd3' => $sd3,'sd4' => $sd4,'sd5' => $sd5,'info' => $info,'pic1' => $pic1,'pic2' => $pic2,'pic3' => $pic3,'pic4' => $pic4,'pic5' => $pic5,'dpname' => $dpname,'biaoqian' => $biaoqian,'view' => $view,'top' => $top,'tuijian' => $tuijian,'color' => $color,'display' => $display,'diynum' => $diynum,'topdateline' => $topdateline,'zhuanti' => $zhuanti) , "id='$id'");
        if ($_G['groupid'] == "1" || in_array($_G['groupid'], $mianshenhe)) {
		    showmessage(lang('plugin/xlwsq_wxdh', 'gengxinok') , dreferer());
        } else {
            for ($i = 0; $i < count($admins); $i++) {
                $message = '<a href="plugin.php?id=xlwsq_wxdh&#58;xlwsq_wxdh_user&p=adminalllist" target="_blank">' . lang('plugin/xlwsq_wxdh', 'yonghufabuxinxinxi') . '</a>';
                notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
            }
            showmessage(lang('plugin/xlwsq_wxdh', 'fabudengdaishenhe') , dreferer());
        }
    }
} elseif ($p == 'favorites'||$p=='xfjl') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $where=$pageadd="";
    if($_GET['key']){
        $key=stripsearchkey($_GET['key']);
	    $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND";
	    $keync=urlencode($key);
	    $pageadd="&key=$keync";
    }
    $uid = intval($_G['uid']);
	if ($p == 'favorites') {
       $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_favorites') . " WHERE $where uid='$uid'");
    } elseif ($p == 'xfjl') {
       $counts = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_xfjl')." WHERE $where uid='$uid'");
    }
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * 20;
    if ($counts) {
	   if ($p == 'favorites') {
           $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_favorites') . " WHERE $where uid = '$uid' ORDER BY dateline DESC LIMIT $starts,20");
       } elseif ($p == 'xfjl') {
           $query=DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_xfjl')." WHERE $where uid='$uid' ORDER BY id DESC LIMIT $starts,20");
       }
	   $manylist = $manylists = array();
	   while($manylist = DB::fetch($query)){
		$manylists[] = $manylist;
	   }
    }
    $multis = "<div class='cl'style='margin:5px;'>" . multi($counts, 20, $pages, 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p='.$p. $pageadd) . "</div>";
} elseif ($p == 'favoritesdel') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if ($_GET['formhash'] == FORMHASH) {
        DB::query("DELETE FROM " . DB::table('plugin_xlwsq_wxdh_favorites') . " WHERE id = '$id' and uid = '$uid'");
        showmessage(lang('plugin/xlwsq_wxdh', 'shanchuok') , dreferer());
    }
} elseif ($p == 'shenheok') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_item') . " SET display='1' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_wxdh', 'shenheok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_wxdh', 'caozuocuowu'));
    }
} elseif ($p == 'qxshenhe') {
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)) {
        $id = intval($_GET['sid']);
        if ($_GET['formhash'] == FORMHASH) {
            DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_item') . " SET display='0' WHERE id='$id'");
            showmessage(lang('plugin/xlwsq_wxdh', 'qxshenhe') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_wxdh', 'caozuocuowu'));
    }
} elseif ($p == 'del') {
    $id = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    $active = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE id ='$id'");
    if ($_G['groupid'] == 1 || in_array($_G['uid'], $admins)||$active['uid']==$uid) {
        if ($_GET['formhash'] == FORMHASH) {
             for ($i = 1; $i <= 5; $i++) {
               $pic = 'pic'.$i;
		       unlink($active[$pic]);
             }
            DB::query("DELETE a,b,c FROM ".DB::table('plugin_xlwsq_wxdh_item')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_wxdh_post')." AS b ON b.sid = a.id LEFT JOIN ".DB::table('plugin_xlwsq_wxdh_reply')." AS c ON c.dpid = b.id WHERE a.id = '$id' ");
            showmessage(lang('plugin/xlwsq_wxdh', 'shanchuok') , dreferer());
        }
    } else {
        showmessage(lang('plugin/xlwsq_wxdh', 'caozuocuowub'));
    }
}elseif($p=='zhuantiadd'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    include_once 'source/plugin/xlwsq_wxdh/class/upic.class.php';
	if(submitcheck('addzhuantisubmit')){
                    $title = dhtmlspecialchars($_GET['title']);
                    $pic = dhtmlspecialchars($_GET['pic']);
                    $info = dhtmlspecialchars($_GET['info']);
                    $diynum = intval($_GET['diynum']);
                    $display = intval($_GET['display']);
						if($_FILES['file']['error']==0){
							$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
							$arr=explode(".", $_FILES["file"]["name"]);
							$hz=$arr[count($arr)-1];
							if(!in_array($hz, $filetype)){
								showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));	
							}
				            $imageinfo = getimagesize($_FILES['file']['tmp_name']);
				            if ($imageinfo[0] <= 0) {
                                showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));
				            }
							$filepath = "source/plugin/xlwsq_wxdh/zhuanti/";
							$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
							if(!file_exists($filepath)){ mkdir($filepath); }			
								if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
									 @unlink($_FILES['file']['tmp_name']);
								}
							$pic = "source/plugin/xlwsq_wxdh/zhuanti/".$randname."";
					        if ($imageinfo[0] > $zhuantilogowidth) {
			     	           new myThumbClass($pic,1,2,$pic,1,$zhuantilogowidth); 
					        }
						}
		DB::insert('plugin_xlwsq_wxdh_zhuanti',array('id' => '','title' => $title,'pic' => $pic,'info' => $info,'display' => $display, 'diynum' => $diynum,'dateline' => $_G['timestamp']));
		showmessage(lang('plugin/xlwsq_wxdh', 'fabuchenggong'), "plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p=zhuanti", array(), array('alert' => right));
	 }
  }else{
		showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
  }
}elseif($p=='zhuantiedit'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $id=intval($_GET['bid']);
	$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_zhuanti')." WHERE id ='$id'");
    include_once 'source/plugin/xlwsq_wxdh/class/upic.class.php';
	if(submitcheck('editzhuantisubmit')){
                    $title = dhtmlspecialchars($_GET['title']);
                    $pic = dhtmlspecialchars($_GET['pic']);
                    $info = dhtmlspecialchars($_GET['info']);
                    $diynum = intval($_GET['diynum']);
                    $display = intval($_GET['display']);
						if($_FILES['file']['error']==0){
                              if ($active["pic"]!=false){
	                             unlink($active["pic"]);
	                           }
							$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
							$arr=explode(".", $_FILES["file"]["name"]);
							$hz=$arr[count($arr)-1];
							if(!in_array($hz, $filetype)){
								showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));	
							}
				            $imageinfo = getimagesize($_FILES['file']['tmp_name']);
				            if ($imageinfo[0] <= 0) {
                                showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));
				            }
							$filepath = "source/plugin/xlwsq_wxdh/zhuanti/";
							$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
							if(!file_exists($filepath)){ mkdir($filepath); }
								if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
									 @unlink($_FILES['file']['tmp_name']);
								}
							$pic = "source/plugin/xlwsq_wxdh/zhuanti/".$randname."";
					        if ($imageinfo[0] > $zhuantilogowidth) {
			     	           new myThumbClass($pic,1,2,$pic,1,$zhuantilogowidth); 
					        }
						}
		DB::update('plugin_xlwsq_wxdh_zhuanti',array('title' => $title,'pic' => $pic,'info' => $info,'display' => $display,'diynum' => $diynum,'dateline' => $_G['timestamp']),"id='$id'");
		showmessage(lang('plugin/xlwsq_wxdh', 'fabuchenggong'), dreferer());
	}
  }else{
	  showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
  }

}elseif($p=='zhuanti'||$p=='banner'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $where=$pageadd="";
    if($_GET['key']){
      $key=stripsearchkey($_GET['key']);
	  $where=" where title like '%".addcslashes(addslashes($key), '%_')."%'";
	  $keync=urlencode($key);
	  $pageadd="&key=$keync";
    }
  if($p=='zhuanti'){	
	$count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti').$where);
  }elseif($p=='banner'){	
	$count = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_banner').$where);
  }
    $pager = intval($_GET['page']);
    $pager = max($pager, 1);
    $starts = ($pager - 1) * 10;
     if ($count) {
       if($p=='zhuanti'){	
   	      $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti') . " $where ORDER BY diynum DESC,id DESC LIMIT $starts,10");
       }elseif($p=='banner'){	
          $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_banner') . " $where ORDER BY diynum DESC,id DESC LIMIT $starts,10");
       }
        while ($manylist = DB::fetch($query)) {
                $manylists[] = $manylist;
        }
     }
    $multis = "<div class='cl' style='margin:5px;'>" . multi($count, 10, $pager, 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p='.$p. $pageadd) . "</div>";
  }else{
		showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
  }
}elseif ($p=='zhuantidel'){
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $id=intval($_GET['bid']);
    if($_GET['formhash'] == FORMHASH) {
			$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_zhuanti')." WHERE id ='$id'");
			if ($active["pic"]!=false){
		    unlink($active["pic"]);
	        }
	       DB::query("DELETE FROM ".DB::table('plugin_xlwsq_wxdh_zhuanti')." WHERE id = '$id'");
           showmessage(lang('plugin/xlwsq_wxdh', 'shanchuok'), 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p=zhuanti', array(), array('alert' => right));
    }
  }else{
       showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
  }
//banner
}elseif($p=='banneradd'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	if(submitcheck('addbannersubmit')){
                    $title = dhtmlspecialchars($_GET['title']);
                    $pic = dhtmlspecialchars($_GET['pic']);
                    $url = dhtmlspecialchars($_GET['url']);
                    $diynum = intval($_GET['diynum']);
					$display = intval($_GET['display']);
						if($_FILES['file']['error']==0){
							$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
							$arr=explode(".", $_FILES["file"]["name"]);
							$hz=$arr[count($arr)-1];
							if(!in_array($hz, $filetype)){
								showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));	
							}
				            $imageinfo = getimagesize($_FILES['file']['tmp_name']);
				            if ($imageinfo[0] <= 0) {
                                showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));
				            }
							$filepath = "source/plugin/xlwsq_wxdh/banner/";
							$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
							if(!file_exists($filepath)){ mkdir($filepath); }			
								if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
									 @unlink($_FILES['file']['tmp_name']);
								}
							$pic = "source/plugin/xlwsq_wxdh/banner/".$randname."";
						}
		DB::insert('plugin_xlwsq_wxdh_banner',array('id' => '','title' => $title,'pic' => $pic,'url' => $url,'display' => $display,'diynum' => $diynum, 'dateline' => $_G['timestamp']));
		showmessage(lang('plugin/xlwsq_wxdh', 'fabuchenggong'), "plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p=banner", array(), array('alert' => right));
	 }

  }else{
		showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
  }

}elseif($p=='banneredit'){	
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $id=intval($_GET['bid']);
	$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_banner')." WHERE id ='$id'");
	if(submitcheck('editbannersubmit')){
                    $title = dhtmlspecialchars($_GET['title']);
                    $pic = dhtmlspecialchars($_GET['pic']);
                    $url = dhtmlspecialchars($_GET['url']);
                    $diynum = intval($_GET['diynum']);
                    $display = intval($_GET['display']);
						if($_FILES['file']['error']==0){
                              if ($active["pic"]!=false){
	                             unlink($active["pic"]);
	                           }
							$filetype = array("jpg", "jpeg", "gif", "png","JPG","JPEG","GIF","PNG");
							$arr=explode(".", $_FILES["file"]["name"]);
							$hz=$arr[count($arr)-1];
							if(!in_array($hz, $filetype)){
								showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));	
							}
				            $imageinfo = getimagesize($_FILES['file']['tmp_name']);
				            if ($imageinfo[0] <= 0) {
                                showmessage(lang('plugin/xlwsq_wxdh', 'tupiangeshibuzhengque'));
				            }
							$filepath = "source/plugin/xlwsq_wxdh/banner/";
							$randname = date("Y").date("m").date("d").date("H").date("i").date("s").rand(100, 999).".".$hz;
							if(!file_exists($filepath)){ mkdir($filepath); }
								if(@copy($_FILES['file']['tmp_name'], $filepath.$randname) || (function_exists('move_uploaded_file') && @move_uploaded_file($_FILES['file']['tmp_name'], $filepath.$randname))) {
									 @unlink($_FILES['file']['tmp_name']);
								}
							$pic = "source/plugin/xlwsq_wxdh/banner/".$randname."";
						}

		DB::update('plugin_xlwsq_wxdh_banner',array('title' => $title,'pic' => $pic,'url' => $url,'display' => $display,'diynum' => $diynum),"id='$id'");
		showmessage(lang('plugin/xlwsq_wxdh', 'fabuchenggong'), dreferer());
	}
  }else{
	  showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
  }
}elseif ($p=='bannerdel'){
  if($_G['groupid']==1||in_array($_G['uid'], $admins)){
    $id=intval($_GET['bid']);
    if($_GET['formhash'] == FORMHASH) {
			$active=DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_banner')." WHERE id ='$id'");
			if ($active["pic"]!=false){
		    unlink($active["pic"]);
	        }
	       DB::query("DELETE FROM ".DB::table('plugin_xlwsq_wxdh_banner')." WHERE id = '$id'");
           showmessage(lang('plugin/xlwsq_wxdh', 'shanchuok'), 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&p=banner', array(), array('alert' => right));
    }
  }else{
       showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
  }

}
include (template("xlwsq_wxdh:xlwsq_wxdh_user"));
?>