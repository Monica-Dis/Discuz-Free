<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wxdh_item` (
	  `id` int(11) NOT NULL auto_increment,
	  `diynum` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
	  `author` varchar(80) NOT NULL,
	  `cate` int(11) NOT NULL,
	  `leixing` int(11) NOT NULL,
	  `title` varchar(255) NOT NULL,
	  `pic1` text NOT NULL,
	  `pic2` text NOT NULL,
	  `pic3` text NOT NULL,
	  `pic4` text NOT NULL,
	  `pic5` text NOT NULL,
	  `sd1` varchar(150) NOT NULL,
	  `sd2` varchar(150) NOT NULL,
	  `sd3` varchar(150) NOT NULL,
	  `sd4` varchar(150) NOT NULL,
	  `sd5` varchar(150) NOT NULL,
	  `info` text NOT NULL,
	  `dpname` varchar(100) NOT NULL,
	  `biaoqian` varchar(150) NOT NULL,
	  `view` int(11) NOT NULL,
   	  `pf0` int(11) NOT NULL,
 	  `pf1` int(11) NOT NULL,
   	  `pf2` int(11) NOT NULL,
   	  `pf3` int(11) NOT NULL,
   	  `pf4` int(11) NOT NULL,
   	  `pfa` int(11) NOT NULL,
   	  `pfb` int(11) NOT NULL,
   	  `pfc` int(11) NOT NULL,
   	  `pfd` int(11) NOT NULL,
   	  `pfe` int(11) NOT NULL,
      `dpcount` int(11) NOT NULL,
      `tuijian` tinyint(1) NOT NULL,
	  `top` tinyint(1)  NOT NULL,
	  `zhuanti` varchar(255) NOT NULL,
      `display` tinyint(1) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  `updateline` int(11) NOT NULL,
	  `topdateline` int(11) NOT NULL,
	  `color`  varchar(20) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wxdh_cate` (
	  `id` int(11) NOT NULL auto_increment,
	  `upid` int(11) NOT NULL,
	  `subid` text NOT NULL,
	  `subject` varchar(255) NOT NULL,
	  `displayorder` int(1) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wxdh_post` (
	  `id` int(11) NOT NULL auto_increment,
	  `sid` int(11) NOT NULL,
	  `uid` int(11) NOT NULL,
  	  `author` varchar(80) NOT NULL,
  	  `message` text NOT NULL,
   	  `pf0` int(11) NOT NULL,
 	  `pf1` int(11) NOT NULL,
   	  `pf2` int(11) NOT NULL,
   	  `pf3` int(11) NOT NULL,
   	  `pf4` int(11) NOT NULL,
   	  `pf5` int(11) NOT NULL,
   	  `pf6` int(11) NOT NULL,
   	  `pf7` int(11) NOT NULL,
   	  `pfa` int(11) NOT NULL,
   	  `pfb` int(11) NOT NULL,
   	  `pfc` int(11) NOT NULL,
   	  `pfd` int(11) NOT NULL,
   	  `pfe` int(11) NOT NULL,
   	  `pff` int(11) NOT NULL,
   	  `pfg` int(11) NOT NULL,
   	  `pfh` int(11) NOT NULL,
  	  `display` tinyint(1) NOT NULL,
 	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wxdh_reply` (
	  `id` int(11) NOT NULL auto_increment,
	  `dpid` int(11) NOT NULL,
	  `redpid` int(11) NOT NULL,
	  `reuid` int(11) NOT NULL,
  	  `reauthor` varchar(80) NOT NULL,
  	  `remessage` text NOT NULL,
  	  `display` tinyint(1) NOT NULL,
 	  `dateline` int(10) NOT NULL,
      PRIMARY KEY  (`id`)
    ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wxdh_favorites` (
   	  `id` int(11) NOT NULL auto_increment,
 	  `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
	  `title` varchar(255) NOT NULL,
   	  `dateline` int(11) NOT NULL,
      PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wxdh_xfjl` (
	  `id` int(11) NOT NULL auto_increment,
      `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `title` varchar(255) NOT NULL,
   	  `day` int(11) NOT NULL,
   	  `pay` int(11) NOT NULL,
   	  `moneytype` varchar(20) NOT NULL,
   	  `endtime` int(11) NOT NULL,
   	  `xftype` int(11) NOT NULL,
   	  `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
   CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wxdh_pinglunjiangli` (
	  `id` int(11) NOT NULL auto_increment,
      `sid` int(11) NOT NULL,
   	  `uid` int(11) NOT NULL,
   	  `author` varchar(100) NOT NULL,
   	  `title` varchar(255) NOT NULL,
   	  `jianglishu` int(11) NOT NULL,
   	  `moneytype` varchar(20) NOT NULL,
   	  `dateline` int(11) NOT NULL,
       PRIMARY KEY  (`id`)
   ) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wxdh_banner` (
	  `id` int(11) NOT NULL auto_increment,
	  `title` varchar(255) NOT NULL,
	  `pic` text NOT NULL,
	  `info` varchar(255) NOT NULL,
	  `url` varchar(255) NOT NULL,
	  `diynum` int(11) NOT NULL,
  	  `display` tinyint(1) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
	CREATE TABLE IF NOT EXISTS `pre_plugin_xlwsq_wxdh_zhuanti` (
	  `id` int(11) NOT NULL auto_increment,
	  `title` varchar(255) NOT NULL,
	  `pic` text NOT NULL,
	  `info` varchar(255) NOT NULL,
	  `diynum` int(11) NOT NULL,
	  `view` int(11) NOT NULL,
  	  `display` tinyint(1) NOT NULL,
	  `dateline` int(11) NOT NULL,
	  PRIMARY KEY  (`id`)
	) ENGINE=MyISAM;
INSERT INTO `pre_plugin_xlwsq_wxdh_zhuanti` (`id`,`title`,`pic`,`display`) VALUES
(1,'$installlang[zhuanti6]','source/plugin/xlwsq_wxdh/zhuanti/20180205163506322.jpg',1),
(2,'$installlang[zhuanti5]','source/plugin/xlwsq_wxdh/zhuanti/20180205163636275.jpg',1),
(3,'$installlang[zhuanti4]','source/plugin/xlwsq_wxdh/zhuanti/20180205163848349.jpg',1),
(4,'$installlang[zhuanti3]','source/plugin/xlwsq_wxdh/zhuanti/20180205164005152.jpg',1),
(5,'$installlang[zhuanti2]','source/plugin/xlwsq_wxdh/zhuanti/20180205170608209.jpg',1),
(6,'$installlang[zhuanti1]','source/plugin/xlwsq_wxdh/zhuanti/20180205170722583.jpg',1);
INSERT INTO `pre_plugin_xlwsq_wxdh_banner` (`id`, `title`, `pic`, `info`, `url`, `diynum`, `dateline`) VALUES
(1, '', 'source/plugin/xlwsq_wxdh/banner/2.jpg', '', '', '', 1518011678),
(2, '', 'source/plugin/xlwsq_wxdh/banner/1.jpg', '', '', '', 1518011696);
INSERT INTO `pre_plugin_xlwsq_wxdh_cate` (`id`, `upid`, `subid`, `subject`, `displayorder`) VALUES
(1, 0, '8,9,10,11,12', '$installlang[cate1]', 0),
(2, 0, '15,16,17,18,19,20,21,22,23,24', '$installlang[cate4]', 0),
(3, 0, '25,26,27,28,29', '$installlang[cate3]', 0),
(4, 0, '30,31,32,33,34,35,36', '$installlang[cate2]', 0),
(5, 0, '37,38,39', '$installlang[cate5]', 0),
(6, 0, '40,41,42,43,44,45,46', '$installlang[cate6]', 0),
(7, 0, '', '$installlang[cate7]', 0),
(8, 1, '', '$installlang[cate8]', 0),
(9, 1, '', '$installlang[cate9]', 0),
(10, 1, '', '$installlang[cate10]', 0),
(11, 1, '', '$installlang[cate11]', 0),
(12, 1, '', '$installlang[cate12]', 0),
(16, 2, '', '$installlang[cate13]', 0),
(15, 2, '', '$installlang[cate14]', 0),
(17, 2, '', '$installlang[cate15]', 0),
(18, 2, '', '$installlang[cate16]', 0),
(19, 2, '', '$installlang[cate17]', 0),
(20, 2, '', '$installlang[cate18]', 0),
(21, 2, '', '$installlang[cate19]', 0),
(22, 2, '', '$installlang[cate20]', 0),
(23, 2, '', '$installlang[cate21]', 0),
(24, 2, '', '$installlang[cate22]', 0),
(25, 3, '', '$installlang[cate23]', 0),
(26, 3, '', '$installlang[cate24]', 0),
(27, 3, '', '$installlang[cate25]', 0),
(28, 3, '', '$installlang[cate26]', 0),
(29, 3, '', '$installlang[cate27]', 0),
(30, 4, '', '$installlang[cate28]', 0),
(31, 4, '', '$installlang[cate29]', 0),
(32, 4, '', '$installlang[cate30]', 0),
(33, 4, '', '$installlang[cate31]', 0),
(34, 4, '', '$installlang[cate32]', 0),
(35, 4, '', '$installlang[cate33]', 0),
(36, 4, '', '$installlang[cate34]', 0),
(37, 5, '', '$installlang[cate35]', 0),
(38, 5, '', '$installlang[cate36]', 0),
(39, 5, '', '$installlang[cate37]', 0),
(40, 6, '', '$installlang[cate38]', 0),
(41, 6, '', '$installlang[cate39]', 0),
(42, 6, '', '$installlang[cate40]', 0),
(43, 6, '', '$installlang[cate41]', 0),
(44, 6, '', '$installlang[cate42]', 0),
(45, 6, '', '$installlang[cate43]', 0),
(46, 6, '', '$installlang[cate44]', 0);

INSERT INTO `pre_plugin_xlwsq_wxdh_item` (`id`, `diynum`, `uid`, `author`, `cate`, `leixing`, `title`, `pic1`, `pic2`, `pic3`, `pic4`, `pic5`, `sd1`, `sd2`, `sd3`, `sd4`, `sd5`, `info`, `dpname`, `biaoqian`, `view`, `pf0`, `pf1`, `pf2`, `pf3`, `pf4`, `pfa`, `pfb`, `pfc`, `pfd`, `pfe`, `dpcount`, `tuijian`, `top`, `zhuanti`, `display`, `dateline`, `updateline`, `topdateline`, `color`) VALUES
(1, 0, 1, 'admin', 11, 1, '$installlang[item1]', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118221638679.jpg', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118221638407.jpg', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118221638466.jpg', '', '', '', '', '', '', '', '$installlang[item2]', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 1, 1547820998, 0, 0, ''),
(2, 0, 1, 'admin', 16, 2, '$installlang[item3]', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118222233844.png', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118222233512.jpg', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118222233673.jpg', '', '', '', '', '', '', '', '$installlang[item4]', '$installlang[item13]', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 1, 1547821353, 0, 0, ''),
(3, 0, 1, 'admin', 8, 5, '$installlang[item5]', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118222613505.jpg', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118222613630.png', '', '', '', '', '', '', '', '', '$installlang[item6]', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '', 1, 1547821573, 0, 0, ''),
(4, 0, 1, 'admin', 7, 2, '$installlang[item7]', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118223405879.jpg', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118223405827.jpg', '', '', '', '', '', '', '', '', '$installlang[item8]', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 1, 1547822045, 0, 0, ''),
(5, 0, 1, 'admin', 20, 1, '$installlang[item9]', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118223646446.jpg', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118223646670.jpg', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118223646760.jpg', '', '', '', '', '', '', '', '$installlang[item10]', '$installlang[item13]', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 1, 1547822206, 0, 0, ''),
(6, 0, 1, 'admin', 40, 1, '$installlang[item11]', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118224014829.png', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118224014170.jpg', 'source/plugin/xlwsq_wxdh/upimg/20190118/20190118224014783.png', '', '', '', '', '', '', '', '$installlang[item12]', '$installlang[item13]', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '', 1, 1547822414, 0, 0, '');

EOF;
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wxdh/discuz_plugin_xlwsq_wxdh.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wxdh/discuz_plugin_xlwsq_wxdh_SC_GBK.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wxdh/discuz_plugin_xlwsq_wxdh_SC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wxdh/discuz_plugin_xlwsq_wxdh_TC_BIG5.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wxdh/discuz_plugin_xlwsq_wxdh_TC_UTF8.xml');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wxdh/upgrade.php');
@unlink(DISCUZ_ROOT.'source/plugin/xlwsq_wxdh/install.php');
runquery($sql);
$finish =true;
?>