           if (typeof FileReader == 'undefined') {
                document.getElementById("xmTanDiv").InnerHTML = "<h1>&#x5F53;&#x524D;&#x6D4F;&#x89C8;&#x5668;&#x4E0D;&#x652F;&#x6301;FileReader&#x63A5;&#x53E3;</h1>";
                document.getElementById("xdaTanFileImg").setAttribute("disabled", "disabled");
            }
            function xmTanUploadImg(obj) {
                var file = obj.files[0];
                console.log(obj);console.log(file);
                console.log("file.size = " + file.size);
                var reader = new FileReader();
                reader.onload = function (e) {
                    console.log("&#x6210;&#x529F;&#x8BFB;&#x53D6;....");
                    var img = document.getElementById("xmTanImg");
                    img.src = e.target.result;
                }
                reader.readAsDataURL(file)
            }
				
            if (typeof FileReader == 'undefined') {
                document.getElementById("xmTanDiv2").InnerHTML = "<h1>&#x5F53;&#x524D;&#x6D4F;&#x89C8;&#x5668;&#x4E0D;&#x652F;&#x6301;FileReader&#x63A5;&#x53E3;</h1>";
                document.getElementById("xdaTanFileImg2").setAttribute("disabled", "disabled");
            }
            function xmTanUploadImg2(obj) {
                var file = obj.files[0];
                console.log(obj);console.log(file);
                console.log("file.size = " + file.size);
                var reader = new FileReader();
                reader.onloadstart = function (e) {
                    console.log("&#x5F00;&#x59CB;&#x8BFB;&#x53D6;....");
                }
                reader.onload = function (e) {
                    console.log("&#x6210;&#x529F;&#x8BFB;&#x53D6;....");
                    var img = document.getElementById("xmTanImg2");
                    img.src = e.target.result;
                }
                reader.readAsDataURL(file)
            }
		   
            function xmTanUploadImg3(obj) {
                var file = obj.files[0];
                console.log(obj);console.log(file);
                console.log("file.size = " + file.size);
                var reader = new FileReader();
                reader.onload = function (e) {
                    console.log("&#x6210;&#x529F;&#x8BFB;&#x53D6;....");
                    var img = document.getElementById("xmTanImg3");
                    img.src = e.target.result;
                }
                reader.
				readAsDataURL(file)
            }
		   
            function xmTanUploadImg4(obj) {
                var file = obj.files[0];
                console.log(obj);console.log(file);
                console.log("file.size = " + file.size);
                var reader = new FileReader();
                reader.onload = function (e) {
                    console.log("&#x6210;&#x529F;&#x8BFB;&#x53D6;....");
                    var img = document.getElementById("xmTanImg4");
                    img.src = e.target.result;
                }
                reader.readAsDataURL(file)
            }

            function xmTanUploadImg5(obj) {
                var file = obj.files[0];
                console.log(obj);console.log(file);
                console.log("file.size = " + file.size);
                var reader = new FileReader();
                reader.onload = function (e) {
                    console.log("&#x6210;&#x529F;&#x8BFB;&#x53D6;....");
                    var img = document.getElementById("xmTanImg5");
                    img.src = e.target.result
                }
                reader.readAsDataURL(file)
            }