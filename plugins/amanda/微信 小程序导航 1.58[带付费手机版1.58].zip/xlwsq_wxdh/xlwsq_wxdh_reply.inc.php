<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once libfile('function/discuzcode');
global $_G;
if(!isset($_G['cache']['plugin'])){ loadcache('plugin'); }
$plyes=($_G['cache']['plugin']['xlwsq_wxdh']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
!$_G['uid'] ? showmessage('not_loggedin', NULL, array(), array('login' => 1)) : '';
$uid = intval($_G['uid']);
if($_GET['option'] == 'reply'){
	    $id = intval($_GET['did']);
        $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_post') . " WHERE id = '$id'");
		if($pl['uid']==$_G['uid']){
			 showmessage(lang('plugin/xlwsq_wxdh', 'bunenggeizijihuifu'), array(), array('alert' => error));
		} 
	    $pl['message'] = discuzcode($pl['message']);
		if(submitcheck('applysubreply')){
		    if ($_G['groupid']=="1"||in_array($_G['uid'], $admins)){
				$display =1; 
			}else{
				$display = intval($display) == 1 ? 1 : 0;
			}
		    $message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
			DB::insert('plugin_xlwsq_wxdh_reply',array('id' => '','dpid' => $id,'reuid' => $uid,'reauthor' => $_G['username'],'remessage' => $message,'display' => $display,'dateline' => time()));
	        if($display == 1||in_array($_G['uid'], $admins)||$_G['groupid']=="1"){
			    if($_G['mobile']) {
					 showmessage(lang('plugin/xlwsq_wxdh', 'tijiaochenggong'), 'plugin.php?id=xlwsq_wxdh&mod=pinglunlist&sid='.$pl['sid']);
			    } else {
                     showmessage(lang('plugin/xlwsq_wxdh', 'tijiaochenggong'),dreferer());
				}
			}else{
				if($_G['mobile']) {
                     showmessage(lang('plugin/xlwsq_wxdh', 'pinglundengdaishenhezhong'), 'plugin.php?id=xlwsq_wxdh&mod=pinglunlist&sid='.$pl['sid']);
			    } else {
                     showmessage(lang('plugin/xlwsq_wxdh', 'pinglundengdaishenhezhong'),dreferer());
				}
			}
		}
		include template('xlwsq_wxdh:reply');
}elseif($_GET['option'] == 'rereply'){
	    $sid = intval($_GET['sid']);
	    $id = intval($_GET['reid']);
        $pl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_reply') . " WHERE id = '$id'");
        if($pl['reuid']==$_G['uid']){showmessage(lang('plugin/xlwsq_wxdh', 'bunenggeizijihuifu'), array(), array('alert' => error));} 
	    $reauthor = dhtmlspecialchars($pl['reauthor']);
	    $remessage = discuzcode($pl['remessage']);
	    $rereauthor = dhtmlspecialchars($_GET['rereauthor']);
	    $dpid = intval($_GET['dpid']);
	    $redpid = intval($_GET['redpid']);
		if(submitcheck('applysubrereply')){
		     if ($_G['groupid']=="1"||in_array($_G['uid'], $admins)){$display =1; }else{$display = intval($display) == 1 ? 1 : 0;}
		     $message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
		     DB::insert('plugin_xlwsq_wxdh_reply',array('id' => '','dpid' => $dpid,'reuid' => $uid,'reauthor' => $_G['username'],'redpid' => $redpid,'remessage' => $message,'display' => $display,'dateline' => time()));
			 if($display == 1||in_array($_G['uid'], $admins)||$_G['groupid']=="1"){
			    if($_G['mobile']) {
                    showmessage(lang('plugin/xlwsq_wxdh', 'tijiaochenggong'), 'plugin.php?id=xlwsq_wxdh&mod=reply&dpid='.$dpid);
			    } else {
                    showmessage(lang('plugin/xlwsq_wxdh', 'tijiaochenggong'),dreferer());
			    }
			 }else{
			    if($_G['mobile']) {
                    showmessage(lang('plugin/xlwsq_wxdh', 'pinglundengdaishenhezhong'), 'plugin.php?id=xlwsq_wxdh&mod=reply&dpid='.$dpid);
				} else {
                    showmessage(lang('plugin/xlwsq_wxdh', 'pinglundengdaishenhezhong'), dreferer());
				}
			 }
		}
		include template('xlwsq_wxdh:reply');
}elseif($_GET['option'] == 'shenhe'){
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
        $id = intval($_GET['reid']);
		 if($_GET['formhash'] == FORMHASH) {
		   DB::query("UPDATE ".DB::table('plugin_xlwsq_wxdh_reply')." SET display='1' WHERE id='$id'");
          showmessage(lang('plugin/xlwsq_wxdh', 'caozuochenggong'), dreferer());
         }
	}else{
		   showmessage(lang('plugin/xlwsq_wxdh', 'caozuocuowu'));
	}
}elseif($_GET['option'] == 'del'){
	if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	     $reid = intval($_GET['reid']);
         if($_GET['formhash'] == FORMHASH) {
              $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_reply')." where id = '$reid'");
	            if($pl){
	               DB::delete('plugin_xlwsq_wxdh_reply',array('id'=> $reid));
	               showmessage(lang('plugin/xlwsq_wxdh', 'shanchuok'), dreferer());
	            }else{
	               showmessage(lang('plugin/xlwsq_wxdh', 'caozuocuowu'));
                }
         }
    }else{
		showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
	}
}
//From: Dism��taobao��com
?>