<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once libfile('function/discuzcode');
require_once 'source/plugin/xlwsq_wxdh/function/function_core.php';
global $_G;
if (!isset($_G['cache']['plugin'])) {
    loadcache('plugin');
}
$plyes=($_G['cache']['plugin']['xlwsq_wxdh']);
foreach($plyes as $key=>$value){ 
 $$key=$value;
}
$defaultpic = $defaultpic ? $defaultpic : 'source/plugin/xlwsq_wxdh/images/nopic.jpg';
if($_G['mobile']) {
  $menubgcolor=$mobilecolor;
  $eacha=$mobileeacha;
  $footad=$mobilefootad;
  $indexnewnum=$mobilenewnum;
  $indexhotnum=$mobilehotnum;
  $indextjnum=$mobiletjnum;
  $indexztnum=$mobileztnum;
}
$fabuset = unserialize($groups);
$free = unserialize($free);
$groupso = $groupso ? $groupso : '1';
$admins = explode(",", $groupso);
$diysdlist = parconfig($diysd);
$leixinglist = parconfig($leixing);
$xingxingpingjia = parconfig($xingxingpingjia);
$navtitle = $title;
$mod = $_GET['mod'] ? $_GET['mod'] : 'index';
if ($mod == 'index') {
    $cate_id = intval($_GET['a']);
    $sd = intval($_GET['b']);
    $leixing = intval($_GET['lx']);
    $newquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . "  WHERE  display!='0' ORDER BY id DESC LIMIT $indexnewnum");
    while ($new = DB::fetch($newquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$new[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$cate[upid]'");
                $new['catecid'] = $cate['upid'];
                $new['catename'] = $cate['subject'];
            } else {
                $new['catename'] = $cate['subject'];
                $new['catecid'] = $new['cate'];
            }
        $news[] = $new;
    }
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE  display!='0' ORDER BY view DESC LIMIT $indexhotnum");
    while ($hot = DB::fetch($hotquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$hot[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$cate[upid]'");
                $hot['catecid'] = $cate['upid'];
                $hot['catename'] = $cate['subject'];
            } else {
                $hot['catename'] = $cate['subject'];
                $hot['catecid'] = $hot['cate'];
            }
        $hots[] = $hot;
    }
    $tuijianquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY diynum DESC,dateline DESC LIMIT $indextjnum");
    while ($tuijian = DB::fetch($tuijianquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$tuijian[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$cate[upid]'");
                $tuijian['catecid'] = $cate['upid'];
                $tuijian['catename'] = $cate['subject'];
            } else {
                $tuijian['catename'] = $cate['subject'];
                $tuijian['catecid'] = $tuijian['cate'];
            }
        $tuijians[] = $tuijian;
    }
    $newztquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti') . "  WHERE display='1' ORDER BY diynum DESC,id DESC LIMIT $indexztnum");
    while ($newzt = DB::fetch($newztquery)) {
        $newzts[] = $newzt;
    }
	$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_banner')." WHERE display='1'  ORDER BY diynum DESC,id DESC");
	while($banner = DB::fetch($query)){
		$banners[] = $banner;
	}
	$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE  display!='0'");
    include template('xlwsq_wxdh:index');
} elseif ($mod == 'list') {
    $where=$pageadd="";
    if($_GET['key']){
      $key=stripsearchkey($_GET['key']);
	  $where="title like '%".addcslashes(addslashes($key), '%_')."%' AND display!='0' AND";
	  $keync=urlencode($key);
	  $pageadd="&key=$keync";
    }elseif($_GET['biaoqian']){
      $biaoqian=stripsearchkey($_GET['biaoqian']);
	  $where="biaoqian like '%".addcslashes(addslashes($biaoqian), '%_')."%' AND display!='0' AND";
	  $biaoqiankeync=urlencode($biaoqian);
	  $pageadd="&biaoqian=$biaoqiankeync";
      $biaoqiannav=$biaoqian. " - ";
    }elseif($_GET['uid']){
	  $uid=intval($_GET['uid']);
	  $where="uid='$uid' AND";
	  $keync=urlencode($uid);
	  $pageadd="&uid=$keync";
    }
    $cate_id = intval($_GET['a']);
    if ($cate_id) {
        $subids = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id='$cate_id'");
        if ($subids) {
            $wb = "cate IN ($cate_id,$subids) AND";
        } else {
            $wb = "cate=$cate_id AND";
        }
        $pageadds = "&a=$cate_id";
        $av_d[$cate_id] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $mcate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$cate_id'");
    $sd = intval($_GET['b']);
    if ($sd) {
        $wc = "cate='$sd' AND";
        $pageaddx = "&b=$sd";
        $av_d[$sd] = ' class="cur-on"';
    } else {
        $av_d[0] = ' class="cur-on"';
    }
    $mcateb = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$sd'");
    $leixing = intval($_GET['lx']);
    if ($leixing){
		$lx = "leixing = '$leixing' AND ";
		$pageadlx="&lx=$leixing";
    }
    if ($_GET['paixu']=='tj') {
		$px="tuijian = '1' AND display!='0' ORDER BY top DESC,topdateline DESC,updateline DESC,dateline DESC"; $pageadd="&paixu=tj";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE $where $wb $wc $lx tuijian = '1' AND display!='0'");
	}elseif ($_GET['paixu']=='view') {
		$px=" display!='0' ORDER BY top DESC,topdateline DESC,view DESC"; $pageadd="&paixu=view";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE $where $wb $wc $lx display!='0'");
	}else{
		$px="display!='0' ORDER BY top DESC,topdateline DESC,diynum DESC,updateline DESC,dateline DESC";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE $where $wb $wc $lx display!='0'");
	}
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $eacha;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE $where $wb $wc $lx $px LIMIT $starts,$eacha");
        while ($mythread = DB::fetch($query)) {
            if ($mythread['topdateline']!='0'){DB::query("UPDATE ".DB::table('plugin_xlwsq_wxdh_item')." SET `topdateline` = '0',`color` = '' WHERE topdateline!= '0' AND  topdateline <= ".$_G['timestamp']);}
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$mythread[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$cate[upid]'");
                $mythread['catecid'] = $cate['upid'];
                $mythread['catename'] = $cate['subject'];
            } else {
                $mythread['catename'] = $cate['subject'];
                $mythread['catecid'] = $mythread['cate'];
            }
			$mythread['info'] = str_replace('&nbsp;','',strip_tags($mythread['info'],"<b><p><i><s>"));
            $mythread['title'] = str_replace($key,"<font color='#ff0000'>$key</font>",$mythread['title']);
	        $sdtype = explode(" ",$mythread['dpname']);
	        $mythread['sdtype']= explode(" ",$mythread['dpname']);
            $mythreads[] = $mythread;
        }
    }
    $multis = multi($counts,$eacha,$pages,'plugin.php?id=xlwsq_wxdh&mod=list'.$pageadd.$pageadds.$pageaddx);
    $r_id = intval($_GET['a']);
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $local[$row['id']] = $row;
    }
    $subid = DB::result_first("SELECT subid FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id='$r_id'");
    if ($subid) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id IN ($subid) ORDER BY displayorder DESC,id ASC");
        while ($ros = DB::fetch($query)) {
            $locals[$ros['id']] = $ros;
        }
    }
    if ($cate_id!='0') {
      if ($sd!='0') {
           $catenav = $mcate['subject'] . "-" . $mcateb['subject']. "-";
      } else {
           $catenav = $mcate['subject']. "-";
      }
    }
    $navtitle = $biaoqiannav. $catenav.$title;
    include template('xlwsq_wxdh:list');
} elseif ($mod == 'view'||$mod == 'pinglunlist') {
    $sid = intval($_GET['sid']);
    $uid = intval($_G['uid']);
    if($_G['groupid']!=1 && !in_array($_G['uid'], $admins)){
      $error = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_item')." WHERE id = '$sid' and display!='0'");
      !$error ? showmessage(lang('plugin/xlwsq_wxdh', 'error'),"plugin.php?id=xlwsq_wxdh") : '';
	}
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE id = '$sid'");
    DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_item') . " SET `view` = view+1 WHERE `id` = '$sid'");
    $cate = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_cate')." WHERE id = '$mythread[cate]'");
	  if($cate['upid']!=0){
		$cate_t = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_cate')." WHERE id = '$cate[upid]'");
        $mythread['catescid'] = $cate['upid'];
        $mythread['catename'] = $cate_t['subject'];
        $mythread['catesname'] =$cate['subject'];
	  }else{
        $mythread['catescid'] = $mythread['cate'];
		$mythread['catename'] = $cate['subject'];
    }
	$dinfo = discuzcode($mythread['info']);
    $biaoqian = explode(" ",$mythread['biaoqian']);
	$sdtype = explode(" ",$mythread['dpname']);
	$mythread['sdtype']=$sdtype;
	$favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE view >'0' AND display!='0' ORDER BY view DESC LIMIT $hotnum");
    while ($hot = DB::fetch($hotquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$hot[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$cate[upid]'");
                $hot['cate'] = $cate['subject'];
            } else {
                $hot['cate'] = $cate['subject'];
            }
        $hots[] = $hot;
    }
    $tuijianquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE tuijian ='1' AND display!='0' ORDER BY diynum DESC,dateline DESC LIMIT $tjnum");
    while ($tuijian = DB::fetch($tuijianquery)) {
            $cate = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$tuijian[cate]'");
            if ($cate['upid'] != 0) {
                $cate_t = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE id = '$cate[upid]'");
                $tuijian['cate'] = $cate['subject'];
            } else {
                $tuijian['cate'] = $cate['subject'];
            }
        $tuijians[] = $tuijian;
    }
	$ypl = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_post') . " WHERE sid = '$sid' AND uid = '$uid'");
    if(submitcheck('applysubmit')){	
	   if(!$_G['uid']){showmessage(lang('plugin/xlwsq_wxdh', 'youkewuquanxianpinglun'), array(), array('alert' => right));}   
		        	$message = strip_tags(addslashes($_GET['message']),"<b><p><i><s>");
                 	$pf0 = intval($_GET['pf0']);
                 	$pf1 = intval($_GET['pf1']);
                 	$pf2 = intval($_GET['pf2']);
                 	$pf3 = intval($_GET['pf3']);
                 	$pf4 = intval($_GET['pf4']);
					if(empty($_GET['pf0'])){$pfa = 0;}else{$pfa = 1;}
					if(empty($_GET['pf1'])){$pfb = 0;}else{$pfb = 1;}
					if(empty($_GET['pf2'])){$pfc = 0;}else{$pfc = 1;}
					if(empty($_GET['pf3'])){$pfd = 0;}else{$pfd = 1;}
					if(empty($_GET['pf4'])){$pfe = 0;}else{$pfe = 1;}
	                if ($_G['groupid']=="1"){$display =1; }else{$display = intval($display);}
					DB::insert('plugin_xlwsq_wxdh_post',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'message' => $message,'display' => $display,'dateline' =>$_G['timestamp']));
                    $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_post')." WHERE sid='$sid' AND display!='0'"); 
					$sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' ,sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe' FROM ".DB::table('plugin_xlwsq_wxdh_post')." WHERE sid='$sid' AND display!='0'";
					$result = DB::query($sql);
					$row = DB::fetch($result);  
						$pf0 = intval($row['pf0']);
						$pf1 = intval($row['pf1']);
						$pf2 = intval($row['pf2']);
						$pf3 = intval($row['pf3']);
						$pf4 = intval($row['pf4']);
						$pfa = intval($row['pfa']);
						$pfb = intval($row['pfb']);
						$pfc = intval($row['pfc']);
						$pfd = intval($row['pfd']);
						$pfe = intval($row['pfe']);
					DB::update('plugin_xlwsq_wxdh_item', array('pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'dpcount' => $dpcount), "id='$sid'");
            if($pinglunaddshuliang > '0' && $pinglunextcredita){
	           $plf = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_pinglunjiangli') . " WHERE sid = '$sid' AND uid = '$uid'");
               if (!$plf){
				    updatemembercount($uid, array($pinglunextcredita => +$pinglunaddshuliang));
				    $moneytype = $_G['setting']['extcredits'][$pinglunextcredita]['title'];
		        	DB::insert('plugin_xlwsq_wxdh_pinglunjiangli',array('id' => '','sid' => $sid,'uid' => $uid,'author' => $_G['username'],'title' => $mythread['title'],'jianglishu' => $pinglunaddshuliang,'moneytype' => $moneytype,'dateline' => $_G['timestamp']));
			   }
	         }
			if(intval($display) == 0){
					showmessage(lang('plugin/xlwsq_wxdh', 'pinglundengdaishenhezhong'),dreferer());
				}else{
					showmessage(lang('plugin/xlwsq_wxdh', 'tijiaochenggong'),dreferer());
			}
    }
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_post')." WHERE sid='$sid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$postquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_post')." WHERE sid='$sid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$postdata= array();
		$replydata= array();
		while($pl = DB::fetch($postquery)){
			$recount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_reply')." WHERE dpid = ".$pl['id']." AND display!='0'");
            $pl['count']=$recount;
			$postdata[$pl['id']] = $pl;
			$replyquery = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_reply'). " where dpid = ".$pl['id']." AND display!='0' ORDER BY dateline DESC LIMIT 5");
		   while($re = DB::fetch($replyquery)){
				  $reinfo = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_reply')." WHERE id = ".$re['redpid'].""); 
                 $re['rereauthor']  = $reinfo['reauthor'];
                 $re['reremessage']  = $reinfo['remessage'];
		   		 $replydata[$pl['id']][$re['id']] = $re;
		   		 $re['recount'] = $pl['reply'];	
			 }
		}
	}
	$multi = "<div class='pages cl' style='margin:10px 5px;'>" .multi($count, $each, $page,'plugin.php?id=xlwsq_wxdh&mod=view&sid='.$sid.'')."</div>";
	$mobliemulti = "<div class='pages cl' style='margin:10px 0;'>" .multi($count, $each, $page,'plugin.php?id=xlwsq_wxdh&mod=pinglunlist&sid='.$sid.'')."</div>";
    if($_GET['pinglun'] == 'del'){
       if($_G['groupid']==1||in_array($_G['uid'], $admins)){
	      $sid = intval($_GET['sid']);
	      $did = intval($_GET['did']);
          if($_GET['formhash'] == FORMHASH) {
             DB::query("DELETE a,b FROM ".DB::table('plugin_xlwsq_wxdh_post')." AS a LEFT JOIN ".DB::table('plugin_xlwsq_wxdh_reply')." AS b ON a.id = b.dpid WHERE a.id = '$did' ");
	                $dpcount = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_post')." WHERE sid='$sid' AND display!='0'"); 
					$sql = "SELECT sum(pf0) AS 'pf0' , sum(pf1) AS 'pf1' , sum(pf2) AS 'pf2' , sum(pf3) AS 'pf3' , sum(pf4) AS 'pf4' , sum(pfa) AS 'pfa' ,sum(pfb) AS 'pfb' ,sum(pfc) AS 'pfc' ,sum(pfd) AS 'pfd' ,sum(pfe) AS 'pfe'  FROM ".DB::table('plugin_xlwsq_wxdh_post')." WHERE sid='$sid' AND display!='0' ";
					$result = DB::query($sql);
					$row = DB::fetch($result);  
						$pf0 = intval($row['pf0']);
						$pf1 = intval($row['pf1']);
						$pf2 = intval($row['pf2']);
						$pf3 = intval($row['pf3']);
						$pf4 = intval($row['pf4']);
						$pfa = intval($row['pfa']);
						$pfb = intval($row['pfb']);
						$pfc = intval($row['pfc']);
						$pfd = intval($row['pfd']);
						$pfe = intval($row['pfe']);
	        DB::update('plugin_xlwsq_wxdh_item', array('pfa' => $pfa,'pfb' => $pfb,'pfc' => $pfc,'pfd' => $pfd,'pfe' => $pfe,'pf0' => $pf0,'pf1' => $pf1,'pf2' => $pf2,'pf3' => $pf3,'pf4' => $pf4,'dpcount' => $dpcount), "id='$sid'");
	        showmessage(lang('plugin/xlwsq_wxdh', 'shanchuok'), dreferer());
          }
       }else{		
	        showmessage(lang('plugin/xlwsq_wxdh', 'wuquanxiancaozuo'), '', array(), array('alert' => right));
     }
    }
    $navtitle = $mythread['title'] . " - " . $title;
	$metakeywords = $mythread['biaoqian'];
    $metadescription = preg_replace('/\r|\n/', '',cutstr(strip_tags($dinfo) , 80, '...'));
	if($_GET['mod']=='view'){
        include template('xlwsq_wxdh:view');
	}elseif($_GET['mod']=='pinglunlist'){
		include template('xlwsq_wxdh:pinglunlist');
	}
} elseif ($mod == 'zhiding') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditc == '0'||!$paytype){showmessage(lang('plugin/xlwsq_wxdh', 'zhidinggongnengweikaifang'));}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE id = '$sid'");
    if($item['top']=="1"){
		showmessage(lang('plugin/xlwsq_wxdh', 'yizhiding'), array(), array('alert' => error));
	}
    if ($item['topdateline']!='0'){DB::query("UPDATE ".DB::table('plugin_xlwsq_wxdh_item')." SET `topdateline` = '0',`color` = '' WHERE topdateline!= '0' AND  topdateline <= ".$_G['timestamp']);}
    $color = dhtmlspecialchars($_GET['topcolor']);
	$daytime = intval($_GET['day']);
	$time = ($daytime * 86400)+$_G['timestamp']; 
    $newcreditc = $daytime * $creditc; 
    $moneytypec = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubzhiding')){
		  if($_GET['day']<="0"){	
		 				showmessage(lang('plugin/xlwsq_wxdh', 'zhidingtianshuweitianxie'), dreferer());
	      }else{
                 if($paymoney<$newcreditc){
                       $tixing= lang('plugin/xlwsq_wxdh', 'zhidingxiaohaotishi').$newcreditc.$moneytypec;
                       if (empty($chongzhiurl)) {
	                       showmessage($tixing, dreferer());
	                   }else{
				           showmessage($tixing, 'plugin.php?id=xlwsq_wxdh&mod=viewchongzhi&sid='.$sid, array() , array('alert' => error));
                       }
                 }else{
                       DB::insert('plugin_xlwsq_wxdh_xfjl',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'day' => $daytime,'pay' => $newcreditc,'moneytype' => $moneytypec,'endtime' => $time,'xftype' => '2','dateline' =>$_G['timestamp']));
					   DB::query("UPDATE ".DB::table('plugin_xlwsq_wxdh_item')." SET `topdateline` = '$time' , `color` = '$color' WHERE `id` = '$sid'");	                   updatemembercount($_G['uid'], array($paytype => -$newcreditc));
                 }
				  showmessage(lang('plugin/xlwsq_wxdh', 'tijiaochenggong'),dreferer());
          }
	}
	include template('xlwsq_wxdh:zhiding');
} elseif ($mod == 'freshen') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    $sid = intval($_GET['sid']);
    $now = date('Y-m-d', $_G['timestamp']);
    $info = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE id = '$sid'");
    $uid = intval($info['uid']);
    $updateline = date('Y-m-d', $info['updateline']);
    if ($_GET['formhash'] == FORMHASH) {
        if ($info['uid'] == $_G['uid'] || $_G['groupid'] == "1" || in_array($_G['uid'], $admins)) {
            if ($now == $updateline) {
                showmessage(lang('plugin/xlwsq_wxdh', 'shuaxinshibai') , '', array() , array('alert' => error));
            } else {
                DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_item') . " SET `updateline` = '$_G[timestamp]' WHERE `id` = '$sid'");
                DB::insert('plugin_xlwsq_wxdh_xfjl',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $info['title'],'xftype' => '3','dateline' =>$_G['timestamp']));
                showmessage(lang('plugin/xlwsq_wxdh', 'shuaxinok') , '', array() , array('alert' => right));
            }
        } else {
            showmessage(lang('plugin/xlwsq_wxdh', 'caozuocuowu') , dreferer());
        }
    }
} elseif ($_GET['mod'] == 'viewchongzhi'||$_GET['mod'] == 'usercenterchongzhi') {
    $sid = intval($_GET['sid']);
    $mythread = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE id = '$sid' and display!='0'");
	include template('xlwsq_wxdh:chongzhi');
} elseif ($mod == 'zhuantilist') {
    $cate_id = intval($_GET['a']);
    $sd = intval($_GET['b']);
    $leixing = intval($_GET['lx']);
    $where=$pageadd="";
    if($_GET['key']){
      $key=stripsearchkey($_GET['key']);
	  $where=" AND title like '%".addcslashes(addslashes($key), '%_')."%' ";
	  $keync=urlencode($key);
	  $pageadd="&key=$keync";
    }
	if ($_GET['paixu']=='view') {
		$px="WHERE display='1' $where ORDER BY view DESC"; $pageadd="&paixu=view";
		$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti')." WHERE display='1'".$where);
	}else{
		$px="WHERE display='1' $where ORDER BY diynum DESC,id DESC";
	    $counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti')." WHERE display='1'".$where);
    }
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $ztlistnum;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti') . " $px LIMIT $starts,$ztlistnum");
        while ($mythread = DB::fetch($query)) {
            $mythreads[] = $mythread;
        }
    }
    $multis = "<div class='pages cl' style='margin:10px;'>" . multi($counts,$ztlistnum,$pages,'plugin.php?id=xlwsq_wxdh&mod=zhuantilist'.$pageadd)."</div>";
    $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_cate') . " WHERE upid='0' ORDER BY displayorder DESC,id ASC");
    while ($row = DB::fetch($query)) {
        $local[$row['id']] = $row;
    }
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti') . " WHERE view >'0' ORDER BY view DESC LIMIT $hotztnum");
    while ($hot = DB::fetch($hotquery)) {
        $hots[] = $hot;
    }
    $navtitle = lang('plugin/xlwsq_wxdh', 'zhuanti'). " - " . $title;
    include template('xlwsq_wxdh:zhuantilist');
} elseif ($mod == 'zhuantiview') {
	$ztid = intval($_GET['ztid']);
    $zhuanti = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti') . " WHERE id='$ztid' AND display='1'");
    !$zhuanti ? showmessage(lang('plugin/xlwsq_wxdh', 'error'),"plugin.php?id=xlwsq_wxdh") : '';
	DB::query("UPDATE " . DB::table('plugin_xlwsq_wxdh_zhuanti') . " SET `view` = view+1 WHERE `id` = '$ztid'");
	$counts = DB::result_first("SELECT COUNT(*) FROM " . DB::table('plugin_xlwsq_wxdh_item')." WHERE instr(concat(',',`zhuanti`,','),',$ztid,') AND display!='0'");
    $pages = intval($_GET['page']);
    $pages = max($pages, 1);
    $starts = ($pages - 1) * $ztinfolistnum;
    if ($counts) {
        $query = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE instr(concat(',',`zhuanti`,','),',$ztid,')  AND display!='0' ORDER BY diynum DESC,id DESC LIMIT $starts,$ztinfolistnum");
        while ($mythread = DB::fetch($query)) {
             $cate = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_cate')." WHERE id = '$mythread[cate]'");
	         if($cate['upid']!=0){
	        	$cate_t = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_cate')." WHERE id = '$cate[upid]'");
                $mythread['catecid'] = $cate['upid'];
                $mythread['catename'] = $cate['subject'];
             } else {
                $mythread['catename'] = $cate['subject'];
             }
            $mythreads[] = $mythread;
        }
    }
    $multis =multi($counts,$ztinfolistnum,$pages,'plugin.php?id=xlwsq_wxdh&mod=zhuantiview&ztid='.$ztid.'');
    $hotquery = DB::query("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_zhuanti') . " WHERE display='1' AND view >'0' ORDER BY view DESC LIMIT $hotztnum");
    while ($hot = DB::fetch($hotquery)) {
        $hots[] = $hot;
    }
    $navtitle = $zhuanti['title']. " - " . lang('plugin/xlwsq_wxdh', 'zhuanti'). " - " . $title;
    $metadescription = cutstr(strip_tags($zhuanti['info']) , 80, '...');
    include template('xlwsq_wxdh:zhuantiview');
}elseif($mod=='reply'){
	$dpid = intval($_GET['dpid']);
    $pl = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_post')." WHERE id = '$dpid' AND display!='0'");
    if (!$pl){showmessage(lang('plugin/xlwsq_wxdh', 'error'), array(), array('alert' => error));}
    $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_item')." WHERE id = '$pl[sid]'");
	$count = DB::result_first("SELECT COUNT(*) FROM ".DB::table('plugin_xlwsq_wxdh_reply')." WHERE dpid='$dpid' AND display!='0'");
	$page = intval($_GET['page']);
	$page = max($page, 1);
	$start = ($page - 1) * $each;
	if($count) {
		$query = DB::query("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_reply')." WHERE dpid='$dpid' AND display!='0' ORDER BY dateline DESC LIMIT $start,$each");
		$pl = $pls = array();
		while($pl = DB::fetch($query)) {
			     $reinfo = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_reply')." WHERE id = ".$pl['redpid'].""); 
                 $pl['rereuid']  = $reinfo['reuid'];
                 $pl['rereauthor']  = $reinfo['reauthor'];
                 $pl['reremessage']  = $reinfo['remessage'];
			$pls[] = $pl;
		}
	}
	$multi = "<div class='cl'>".multi($count, $each, $page,'plugin.php?id=xlwsq_wxdh&mod=reply&dpid='.$dpid.'')."</div>";
    $navtitle = $item['title']." - ".$t_title;	
	$metadescription =  cutstr(strip_tags($item['info']), 100, '...');
	$metakeywords = $item['biaoqian'];
	include template('xlwsq_wxdh:replylist');

} elseif ($_GET['mod'] == 'miaoshen') {
	!$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if($creditd == '0'||!$paytype){showmessage(lang('plugin/xlwsq_wxdh', 'miaoshenweikaiqi'));}
	$sid = intval($_GET['sid']);
    $item = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_item') . " WHERE id = '$sid'");
    if($item['display']=="1"){
		showmessage(lang('plugin/xlwsq_wxdh', 'miaoshentongguo'), array(), array('alert' => error));
	}
    $moneytype = $_G['setting']['extcredits'][$paytype]['title'];
    $paymoney = getuserprofile('extcredits'."$paytype");
	if(submitcheck('applysubmiaoshen')){
          if($paymoney<$creditd){
                 $tixing= lang('plugin/xlwsq_wxdh', 'miaoshenshibai').$creditd.$moneytype;
        	     showmessage(lang('plugin/xlwsq_wxdh', $tixing));
          }else{
				 DB::query("UPDATE ".DB::table('plugin_xlwsq_wxdh_item')." SET `display` = '1' WHERE `id` = '$sid'");
				 updatemembercount($_G['uid'], array($paytype => -$creditd));
				 DB::insert('plugin_xlwsq_wxdh_xfjl',array('id' => '','sid' => $sid,'uid' => $_G['uid'],'author' => $_G['username'],'title' => $item['title'],'pay' => $creditd,'moneytype' => $moneytype,'xftype' => '4','dateline' =>$_G['timestamp']));
                 for ($i = 0; $i < count($admins); $i++) {
                        $message = '<a href="plugin.php?id=xlwsq_wxdh&mod=view&sid='.$item[id].'" target="_blank">'.lang('plugin/xlwsq_wxdh', 'miaoshenweisend').$item[title].'</a>';
                        notification_add($admins[$i], 'system', $message, $notevars = array() , $system = 0);
                 }
		         if($_G['mobile']) {
                        showmessage(lang('plugin/xlwsq_wxdh', 'tijiaochenggong') , 'plugin.php?id=xlwsq_wxdh:xlwsq_wxdh_user&amp;p=mylist', array() , array('alert' => right));
		   	     } else {
                        showmessage(lang('plugin/xlwsq_wxdh', 'tijiaochenggong'),dreferer());
			     }
          }
	}
	include template('xlwsq_wxdh:miaoshen');



} elseif ($mod == 'favorites') {
    !$_G['uid'] ? showmessage('not_loggedin', NULL, array() , array('login' => 1)) : '';
    if ($_GET['formhash'] == FORMHASH) {
        $sid = intval($_GET['sid']);
        $uid = intval($_G['uid']);
	    $item = DB::fetch_first("SELECT * FROM ".DB::table('plugin_xlwsq_wxdh_item')." WHERE id = '$sid'");
        $favorites = DB::fetch_first("SELECT * FROM " . DB::table('plugin_xlwsq_wxdh_favorites') . " WHERE sid = '$sid' AND uid = '$uid'");
        if ($favorites) {
            DB::query("DELETE FROM " . DB::table('plugin_xlwsq_wxdh_favorites') . " WHERE sid = '$sid' and uid = '$uid'");
            showmessage(lang('plugin/xlwsq_wxdh', 'quxiaoshoucang') , '', array() , array('alert' => right));
        } else {
            DB::insert('plugin_xlwsq_wxdh_favorites', array('id' => '','sid' => $sid,'uid' => $uid,'title' => $item['title'],'dateline' => $_G['timestamp']));
            showmessage(lang('plugin/xlwsq_wxdh', 'shoucangchenggong') , '', array() , array('alert' => right));
        }
    }
}
//From: Dism��taobao��com
?>
