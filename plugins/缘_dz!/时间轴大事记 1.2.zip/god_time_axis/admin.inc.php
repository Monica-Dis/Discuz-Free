<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
echo '<script src="static/js/calendar.js" type="text/javascript"></script>';
if(submitcheck('submit')){
	$del_arr = array();
	$del_arr = $_GET['delete'];
	if($del_arr){
		foreach($del_arr as $item){
			$item = daddslashes($item);
			if($item){
				$del_ids .= $del_ids ? ",'{$item}'" : "'{$item}'";
			}
		}
		if($del_ids){
			DB::delete('plugin_god_time_axis', "id IN ({$del_ids})");
		}
	}
	cpmsg(lang('plugin/god_time_axis','delete_succeed'), 'action=plugins&operation=config&identifier=god_time_axis&pmod=admin', 'succeed');
}
elseif(submitcheck('import')){
	$time = strtotime($_GET['time']);
	$text['text'] = str_replace("\n", '<br>', $_GET['text']);
	$text['href'] = $_GET['text_href'];
	$text = serialize($text);
	DB::insert('plugin_god_time_axis', array('time'=>$time, 'text'=>$text));
	cpmsg(lang('plugin/god_time_axis','add_succeed'), 'action=plugins&operation=config&identifier=god_time_axis&pmod=admin', 'succeed');
}

// 输出已存在的
showformheader('plugins&operation=config&identifier=god_time_axis&pmod=admin');
showtableheader(lang('plugin/god_time_axis','dashiji_be'));
showsubtitle(explode('|', lang('plugin/god_time_axis','text_tab')));
$page = intval($_GET['page']) ? intval($_GET['page']) : 1;
$start = ($page-1) * 10;
$nowtime = TIMESTAMP;

$query = DB::query('SELECT id,time,text FROM '.DB::table('plugin_god_time_axis')." ORDER BY time DESC LIMIT {$start},10");

while($result=DB::fetch($query)){
	$result['text'] = unserialize($result['text']);
	//$text_admin = $result['text']['text'].$result['text']['href'];
	$text_admin = $result['text']['text'];
	showtablerow('', array('class="delete"', 'class="time"'), array(
		'<input type="checkbox" class="checkbox" name="delete[]" value="'.$result['id'].'" />',
		date('Y-m-d',$result['time']),
		'<input type="text" disabled onclick="this.select()" value="' .htmlspecialchars($text_admin, ENT_QUOTES). '" size="70" />',
	));
}
$num = DB::result_first('select count(*) from ' . DB::table('plugin_god_time_axis'));
$pagesize = 10;

$pages = multi($num, $pagesize, $page, ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=god_time_axis&pmod=admin&page='.$page);

showsubmit('submit');
showtablefooter(); /*Dism·taobao·com*/
showformfooter(); /*Dism_taobao_com*/
// 分页
echo $pages;

// 内容提交
showtableheader(lang('plugin/god_time_axis','text_add'));
showformheader('plugins&operation=config&identifier=god_time_axis&pmod=admin');
showsetting(lang('plugin/god_time_axis','text_time'), 'time', dgmdate(TIMESTAMP+86400, 'd'), 'calendar');
showsetting(lang('plugin/god_time_axis','text'), 'text', '', 'textarea', '', '', lang('plugin/god_time_axis','textarea_tips'));
showsetting(lang('plugin/god_time_axis','text_href'), 'text_href', '', 'text', '', '', lang('plugin/god_time_axis','text_tips'));
showsubmit('import', 'import');
showformfooter(); /*Dism_taobao_com*/
showtablefooter(); /*Dism·taobao·com*/
?>