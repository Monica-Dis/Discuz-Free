<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/

if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS cdb_plugin_god_time_axis;
EOF;

runquery($sql);
$finish = TRUE; /*dism·taobao·com*/
?>