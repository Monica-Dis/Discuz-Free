<?php 
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
// 后台配置
//global $_G;
$config = $_G['cache']['plugin']['god_time_axis'];

$about = DB::fetch_all("SELECT time,text FROM ".DB::table('plugin_god_time_axis')." ORDER BY time DESC");
//print_r($about);
$text = array();
foreach($about as $id => $temp){
	$temp['text'] = unserialize($temp['text']);
	$text[] = $temp;
}
$navtitle = lang('plugin/god_time_axis','dashiji');
$read_text = lang('plugin/god_time_axis','read_more');
include template('god_time_axis:index');
?>