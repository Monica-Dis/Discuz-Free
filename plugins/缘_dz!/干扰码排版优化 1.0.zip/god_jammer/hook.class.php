<?php
/**
 *	[干扰码排版优化] 
 *  应用更新支持：https://dism.taobao.com
 *	Version: 1.0
 *	最新插件：http://t.cn/Aiux1Jx1
**/

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_god_jammer_forum {

	function viewthread_top(){
		global $_G;
		$config = array();
		$config = $_G['cache']['plugin']['god_jammer'];
		$config['use_forum'] = unserialize($config['use_forum']);

		if(!in_array($_G['fid'], $config['use_forum'])){
			return '';
		}

		$cssdata = '<style>.jammer{position:absolute;height:14px;overflow:hidden;z-index:-1}</style>';
		return $cssdata;
	}
}
// 手机版
class mobileplugin_god_jammer_forum {
	function viewthread_top_mobile(){
		global $_G;
		$config = array();
		$config = $_G['cache']['plugin']['god_jammer'];
		$config['use_forum'] = unserialize($config['use_forum']);

		if(!in_array($_G['fid'], $config['use_forum'])){
			return '';
		}

		$cssdata = '<style>.jammer{position:absolute;height:14px;overflow:hidden;z-index:-1}</style>';
		return $cssdata;
	}
}
//From: Dism·taobao·com
?>
