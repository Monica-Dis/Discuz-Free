<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_thread extends discuz_table{
	public function __construct() {
		$this->_table = 'zhikai_sinalogin_thread';
		$this->_pk    = 'tid';
		parent::__construct();
	}
	
}
//From: Dism��taobao��com
?>