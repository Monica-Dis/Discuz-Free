<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_bind extends discuz_table{
	public function __construct() {
		$this->_table = 'zhikai_sinalogin_bind';
		$this->_pk    = 'openid';
		parent::__construct();
	}

	public function fetch_by_uid($uid){
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d",array($this->_table,$uid));
	}
	
	
}
//From: Dism��taobao��com
?>