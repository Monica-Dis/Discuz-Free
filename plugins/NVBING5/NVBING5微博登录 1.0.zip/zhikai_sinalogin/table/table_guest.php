<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_guest extends discuz_table{
	public function __construct() {
		$this->_table = 'zhikai_sinalogin_guest';
		$this->_pk    = 'openid';
		parent::__construct();
	}
	
}
//From: Dism��taobao��com
?>