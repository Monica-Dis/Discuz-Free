<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$bindinfo = C::t("#zhikai_sinalogin#bind")->fetch_by_uid($_G['uid']);
if(submitcheck('unbind') && $bindinfo){
	C::t("#zhikai_sinalogin#bind")->delete($bindinfo['openid']);
	showmessage(lang('plugin/zhikai_sinalogin','AD4CKk'),dreferer());
}
//From: Dism_taobao_com
?>