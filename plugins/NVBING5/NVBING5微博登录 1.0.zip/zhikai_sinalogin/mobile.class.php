<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_zhikai_sinalogin_member {
	function logging_bottom_mobile(){
		global $_G;
		return '<div class="n5_wbdlkz" style="margin: 20px 55px;background: #ff4761;height: 45px;line-height: 45px;font-size: 15px;border-radius: 2px;text-align: center;"><a href="plugin.php?id=zhikai_sinalogin" style="color: #fff;">'.lang('plugin/zhikai_sinalogin','Wwmj82').'</a></div>';
	}
}
//From: Dism��taobao��com
?>