<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
DROP TABLE IF EXISTS `cdb_zhikai_sinalogin_bind`;
DROP TABLE IF EXISTS `cdb_zhikai_sinalogin_guest`;
DROP TABLE IF EXISTS `cdb_zhikai_sinalogin_thread`;
EOF;
runquery($sql);
?>