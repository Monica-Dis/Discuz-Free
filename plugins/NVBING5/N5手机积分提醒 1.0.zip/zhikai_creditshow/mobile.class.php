<?php

/**
 *      (C)2001-2099 NVBING5.
 *      This is NOT a freeware, use is subject to license terms
 *      $Id: mobile.class.php 2017-12-04 08:50:02Z Todd $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/* 插件代码开始 */

class mobileplugin_zhikai_creditshow {
	function global_footer_mobile(){
		global $_G;
		if(!$_G['uid']) return '';
		$pvars = $_G['cache']['plugin']['zhikai_creditshow'];
		$opacity = dintval($pvars['transparent'])/100;
		include template("zhikai_creditshow:show");
		return $return;
	}
}
//From: Dism·taobao·com
?>