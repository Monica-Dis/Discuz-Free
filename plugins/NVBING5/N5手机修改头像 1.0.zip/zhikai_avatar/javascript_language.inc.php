<?php

if( !defined('IN_DISCUZ') ) {
	exit('Access Denied');
}

include 'language/'.currentlang().'.php';
$jlang = $language['js'];
echo 'var lang_charset=lang={};lang_charset.set="'.$_GET['charset'].'";';
foreach ($language['js'] as $k => $v) {
	echo 'lang._'.$k.'="'.$v.'";';
}
//From: Dism��taobao��com
?>