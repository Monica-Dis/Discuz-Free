<?php
/*
 *	[���ܷ���Ԥ������(yuzhe_presetvalue.php)] (C)2012-2099 Copyright (c) 2020 by dism.taobao.com
 *	Version: 85599
 *	From: DisM.taobao.Com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_yuzhe_presetvalue {

}
class plugin_yuzhe_presetvalue_forum extends plugin_yuzhe_presetvalue {
	function post_top_output() {
		global $_G,$message;

		$presetvaluetype = intval($_G['cache']['plugin']['yuzhe_presetvalue']['presetvaluefid']);
		if (!$presetvaluetype || $_GET['mod'] != 'post' || $_GET['action'] != 'newthread' || $message){return '';}

		global $policykey,$postinfo,$special,$sortid,$typeid;
		$presetvalueids = $_G['cache']['plugin']['yuzhe_presetvalue']['presetvalue'];
		if ($presetvaluetype == 2){
			$presetvalueid = $sortid;
		}elseif ($presetvaluetype == 3){
			$presetvalueid = $special;
		}else{
			if (!$sortid && !$special){$presetvalueid = $_G['fid'];}
		}
		if ($presetvalueid){
			$matchpresetvalue = "/\{id:([0-9,]+)\}([\s\S]*?)\{\/id\}/i";
			if (preg_match($matchpresetvalue, $presetvalueids)){
				$arrpresetvalue = array();
				preg_match_all($matchpresetvalue, $presetvalueids, $arrpresetvalue);
				foreach ($arrpresetvalue[1] as $num => $id){
					if (in_array($presetvalueid, explode(',', $id))){
						$message = $arrpresetvalue[2][$num];
						break;
					}
				}
				if (!$message){
					$arrpresetvalue = array();
					$matchpresetvalue = "/\{id:other\}([\s\S]*?)\{\/id\}/i";
					if (preg_match($matchpresetvalue, $presetvalueids)){
						preg_match($matchpresetvalue, $presetvalueids, $arrpresetvalue);
						$message = $arrpresetvalue[1];
					}
				}

			}
		}
	}
}
//From: Dism_taobao-com
?>