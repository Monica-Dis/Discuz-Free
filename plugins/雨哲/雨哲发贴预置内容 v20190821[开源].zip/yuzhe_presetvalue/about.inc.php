<?php
/*
 *	[���ܷ���Ԥ������(yuzhe_presetvalue.php)] (C)2012-2099 Copyright (c) 2020 by dism.taobao.com
 *	Version: 85599
 *	From: DisM.taobao.Com
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

echo str_replace(array('{domain}', '{endtime}'), array($yuzhe_presetvalue_cert['ClientUrl'], $yuzhe_presetvalue_endtime), lang('plugin/yuzhe_presetvalue', 'adminabout'));
?>