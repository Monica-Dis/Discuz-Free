function _yuzhe_insertimgall_insertAttachimgTag(aid) {
	if(wysiwyg) {
		_yuzhe_insertimgall_insertText('<img src="' + $('image_' + aid).src + '" border="0" aid="attachimg_' + aid + '" alt="" />', false);
	} else {
		var txt = '[attachimg]' + aid + '[/attachimg]';
		_yuzhe_insertimgall_insertText(txt, strlen(txt), 0);
	}
}

function _yuzhe_insertimgall_insertText(text, movestart, moveend, select, sel) {
	checkFocus();
	if(wysiwyg) {
		try {
			var sel = editdoc.getSelection();
			var range = sel.getRangeAt(0);
			if(range && range.insertNode) {
				range.deleteContents();
			}
			var frag = range.createContextualFragment(text);
			var lnode = frag.lastChild;
			range.insertNode(frag);
			range.setEndAfter(lnode);
			range.setStartAfter(lnode);
			sel.removeAllRanges();
			sel.addRange(range);
		} catch(e) {
			sel = null;
			if(!isUndefined(editdoc.selection) && editdoc.selection.type != 'Text' && editdoc.selection.type != 'None') {
				movestart = false;
				editdoc.selection.clear();
			}

			if(isUndefined(sel) || sel == null) {
				sel = editdoc.selection.createRange();
			}

			sel.pasteHTML(text);

			if(text.indexOf('\n') == -1) {
				if(!isUndefined(movestart)) {
					sel.moveStart('character', -strlen(text) + movestart);
					sel.moveEnd('character', -moveend);
				} else if(movestart != false) {
					sel.moveStart('character', -strlen(text));
				}
				if(!isUndefined(select) && select) {
					sel.select();
				}
			}
		}

	} else {
		if(!isUndefined(editdoc.selectionStart)) {
			if(editdoc._selectionStart) {
				editdoc.selectionStart = editdoc._selectionStart;
				editdoc.selectionEnd = editdoc._selectionEnd;
				editdoc._selectionStart = 0;
				editdoc._selectionEnd = 0;
			}
			var opn = editdoc.selectionStart + 0;
			editdoc.value = editdoc.value.substr(0, editdoc.selectionStart) + text + editdoc.value.substr(editdoc.selectionEnd);

			if(!isUndefined(movestart)) {
				editdoc.selectionStart = opn + movestart;
				editdoc.selectionEnd = opn + strlen(text) - moveend;
			} else if(movestart !== false) {
				editdoc.selectionStart = opn;
				editdoc.selectionEnd = opn + strlen(text);
			}
		} else if(document.selection && document.selection.createRange) {
			if(isUndefined(sel)) {
				sel = document.selection.createRange();
			}
			if(editbox.sel) {
				sel = editbox.sel;
				editbox.sel = null;
			}
			sel.text = text.replace(/\r?\n/g, '\r\n');
			if(!isUndefined(movestart)) {
				sel.moveStart('character', -strlen(text) +movestart);
				sel.moveEnd('character', -moveend);
			} else if(movestart !== false) {
				sel.moveStart('character', -strlen(text));
			}
			sel.select();
		} else {
			editdoc.value += text;
		}
	}
	checkFocus();
}