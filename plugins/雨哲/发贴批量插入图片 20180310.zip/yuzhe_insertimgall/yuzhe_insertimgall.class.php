<?php
/*
 *	[���ܷ�����������ͼƬ({modulename})] (C)2012-2099 Powered by ����(web:www.yuzhe.name QQ:425162224).
 *	Version: 71684
 *	Date: 1561544711
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_yuzhe_insertimgall {

}

class plugin_yuzhe_insertimgall_forum {
	function post_image_tab_extra(){
		global $_G;
		$return = '';
		$lang = $_G['cache']['plugin']['yuzhe_insertimgall'];
		//�ж��û��飬֧��ѡ�񡰿ա�ʱ������
		$insertallimggroup = (array)dunserialize($lang['groups']);
		if(in_array('', $insertallimggroup)) {
			$insertallimggroup = array();
		}
		//�жϰ�飬֧��ѡ�񡰿ա�ʱ������
		$insertallimgforum = (array)dunserialize($lang['forums']);
		if(in_array('', $insertallimgforum)) {
			$insertallimgforum = array();
		}

		$insertallimg = (!$insertallimggroup || in_array($_G['groupid'], $insertallimggroup)) && (!$insertallimgforum || in_array($_G['fid'], $insertallimgforum));
		if ($insertallimg){
			include template("yuzhe_insertimgall:return");
		}
		return $return;
	}
}
//From: Dism_taobao_com
?>