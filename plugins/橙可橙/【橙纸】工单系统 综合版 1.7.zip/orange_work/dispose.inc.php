<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
    if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    $limit = 10;
    $uid = $_G['uid'];
    $siteurl = $_G['siteurl'];
    $username = $_G['username'];
    $act = addslashes($_GET['act']);
    $lang = lang('plugin/orange_work');
    $orange_work = $_G['cache']['plugin']['orange_work'];
    $s = isset($_GET['s']) ? dintval($_GET['s']) : -1;
    $condition = array('status'=>$s,'deal_uid'=>$s ==-1 ? 0 : $uid);
    require_once dirname(__FILE__) . '/orange_work.class.php';
    
    if( !in_array($uid,array_filter(explode("\r\n",$orange_work['site_manage']))) ){
    	dheader('location:plugin.php?id=orange_work');
    }
    
    
    if( !$act ){
    	$work_order = C::t('#orange_work#work_order')->get_order_list( 0,$limit,$condition );
    	$work_page = ceil( C::t('#orange_work#work_order')->get_order_count( $condition )/$limit );
        include template('orange_work:dispose');
    }else if( $act == 'detail' ){
    	$order_id = intval($_GET['order_id']);
    	$order = C::t('#orange_work#work_order')->get_order_first( $order_id );
    	if( $order['deal_uid'] && $order['deal_uid'] != $uid ){dheader('location:plugin.php?id=orange_work:dispose');}
		$work = C::t('#orange_work#work_item')->get_work_first( $order['wid'] );
		$order['content'] = unserialize($order['content']);
		$orange_work['site_name'] = $work['work_name'];
		$record = C::t('#orange_work#work_record')->get_record_all( array('orderid'=>$order_id) );
        include template('orange_work:dispose_detail');
    }else if( $act == 'publish' ){
    	if( $_GET['formhash'] != FORMHASH ){OrangeWork::output(false);}
    	$data = OrangeWork::check_array( $_GET );
    	$order = C::t('#orange_work#work_order')->get_order_first( $data['orderid'] );
    	$work = C::t('#orange_work#work_item')->get_work_first( $order['wid'] );
    	if( $order['deal_uid'] != $uid ){
    		//OrangeWork::output(false,0,0,1);
    	}
    	$publish['deal_uid'] = $uid;
    	$publish['orderid'] = $data['orderid'];
    	$publish['content'] = $data['content'];
    	$publish['add_time'] = $_G['timestamp'];
    	$publish['pics'] = implode(',',OrangeWork::check_array( $_GET['pics'],3 ));
    	// 工单回复
    	$result = C::t('#orange_work#work_record')->insert( $publish );
    	// 工单状态更新
    	C::t('#orange_work#work_order')->update( array('notice'=>2,'status'=>1,'deal_name'=>$_G['username']),array('id'=>$order['id']) );
    	// 马甲客户端推送
    	if( $orange_work['mag_host'] && $orange_work['mag_secret'] ){
    		$notice_cont = str_replace('order',$work['work_name'],$lang['h_work_notice_cont']);
    		file_get_contents($orange_work['mag_host'].'/mag/push/v1/push/sendPush?user_id='.$order['uid'].'&title='.urlencode($lang['h_work_notice']).'&content='.urlencode($notice_cont).'&link='.urlencode($_G['siteurl'].'plugin.php?id=orange_work:order&order_id='.$order['id']).'&secret='.$orange_work['mag_secret']);
    	}
    	OrangeWork::output($result);
    }else if( $act == 'ajax_list' ){
    	$start = intval($_GET['start']);
    	$work_order = C::t('#orange_work#work_order')->get_order_list( $start,$limit,$condition );
    	include template('orange_work:ajax_list');
    }
    
?>