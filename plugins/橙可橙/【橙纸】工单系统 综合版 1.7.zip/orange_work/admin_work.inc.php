<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    $lang = lang('plugin/orange_work');
    $act = dhtmlspecialchars($_GET['act']);
    require_once dirname(__FILE__) . '/orange_work.class.php';
    
    
    if( !$act ){
    	$perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
		$start_limit = ($page - 1) * $perpage;
		$count = C::t('#orange_work#work_item')->get_work_count();
        $mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=orange_work&pmod=admin_work";
		$multipage = multi($count, $perpage, $page, $mpurl, 0, 3);
        $work_list = C::t('#orange_work#work_item')->get_work_list($start_limit,$perpage);
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_work&act=del', 'enctype');
		showtableheader();
		echo    '<tr class="header"><th></th><th>'.
                $lang['a_id'].'</th><th>'.
				$lang['a_work_logo'].'</th><th>'.
				$lang['a_work_name'].'</th><th>'.
                $lang['a_work_sort'].'</th><th>'.
				$lang['a_work_status'].'</th><th>'.
				$lang['a_handle'].
                '</th><th></th></tr>';
		foreach($work_list as $list) {
	            $work_status = $list['work_status']?$lang['a_open']:$lang['a_stop'];
	            echo'<tr class="hover">'.
	                '<th class="td25"><input class="checkbox" type="checkbox" name="delete['.$list['id'].']" value="'.$list['id'].'"></th>'.
	                '<th>'.$list['id'].'</th>'.
	                '<th><a href="'.$list['work_icon'].'" target="_blank" title="'.$lang['a_big_image'].'"><img src="'.$list['work_icon'].'" width="30"/></a></th>'.
	                '<th>'.$list['work_name'].'</th>'.
	                '<th>'.$list['work_sort'].'</th>'.
	                '<th>'.$work_status.'</th>'.
	                '<th><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_work&act=edit&id='.$list['id'].'">'.$lang['a_edit'].'</a></th>'.
	                '</tr>';
		}
		$add = '<input type="button" class="btn" onclick="location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_work&act=add\'" value="'.$lang['a_add'].'" />';
	
	    showsubmit('submit',$lang['a_del'], $add, '', $multipage);
	
		showtablefooter(); /*dism _ taobao _ com*/
		showformfooter(); /*dism��taobao��com*/
    }
    
    else if( $act=='add' || $act=='edit' ){
        if( !submitcheck('submit') ) {
            $id = intval($_GET['id']);
            if( $id ){
                $work = C::t('#orange_work#work_item')->get_work_first($id);
                $work['work_options'] = unserialize($work['work_options']);
            }
            $type = OrangeWork::create_select(
            	'type[]',
            	array(
            		array(1,$lang['a_type_1']),
            		array(2,$lang['a_type_2']),
            		array(3,$lang['a_type_3']),
            		array(4,$lang['a_type_4'])
            	)
        	);
        	$fill = OrangeWork::create_select(
            	'fill[]',
            	array(
            		array(1,$lang['a_fill_1']),
            		array(2,$lang['a_fill_2'])
            	)
        	);
            include template('orange_work:admin_work');
        }else{
            $data = array();
            $id = intval($_GET['id']);
            if( $_FILES['work_icon']['tmp_name'] ) {
                require_once dirname(__FILE__) . '/work_upload.class.php';
                $_FILES['work_icon']['tmp_name'] && $data['work_icon'] = OrangeWork::upload('',$_FILES['work_icon']);
            }
            $data['work_sort'] = intval($_GET['work_sort']);
            $data['work_pics'] = intval($_GET['work_pics']);
            $data['work_price'] = intval($_GET['work_price']);
            $data['work_name'] = addslashes($_GET['work_name']);
            $data['work_status'] = intval($_GET['work_status']);
            $data['work_pics_intro'] = addslashes($_GET['work_pics_intro']);
            $data['work_options'] = serialize(array(
            	'type'=>OrangeWork::check_array($_GET['type'],1),
            	'fill'=>OrangeWork::check_array($_GET['fill'],1),
            	'name'=>OrangeWork::check_array($_GET['name'],0),
            	'sort'=>OrangeWork::check_array($_GET['sort'],1),
            	'value'=>OrangeWork::check_array($_GET['value']),
            	'intro'=>OrangeWork::check_array($_GET['intro'],0),
            ));
            if( $id ){
                C::t('#orange_work#work_item')->update($data,array('id'=>$id));
            }else{
                C::t('#orange_work#work_item')->insert($data);
            }
            cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_work', 'succeed');
        }
    }
    
    elseif($act == 'del') {
	if(submitcheck('submit')) {
            foreach($_POST['delete'] as $delete) {
                C::t('#orange_work#work_item')->delete(array('id'=>$delete));
            }
            cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_work', 'succeed');
        }

    }
//From: Dism��taobao��com
?>