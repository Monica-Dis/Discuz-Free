<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class OrangeWork {
	
    const PLUGIN_ID = 'orange_work';
    
    
    public static function initial_data( $data=array(),$field1='',$field2='',$type=1 ){
        $arr = array();
        foreach( $data as $val ){
            switch( $type ){
                case 1:
                    $arr[$val[$field1]] = $val[$field1];
                    break;
                case 2:
                    $arr[$val[$field1]] = $val[$field2];
                    break;
                case 3:
                    $arr[$val[$field1]][] = $val[$field2];
                    break;
                case 4:
                    $arr[$val[$field1]] = array($val[$field1],$val[$field2]);
                    break;
                case 5:
                    $arr[$val[$field1]][] = $val;
                    break;
                case 6:
                    $arr[$val[$field1]] = $val;
                    break;
                default:
                    break;
            }
        }
        return $arr;
    }
    
    public static function initial_cont( $data ){
    	$cont = "";
    	$data = unserialize($data);
    	foreach( $data['name'] as $key=>$val ){
    		$cont .= $val." : ".$data['val'][$key]."<br>";
    	}
    	return $cont;
    }
    
    
    public static function param_join( $data ){
        $param_data = array();
        foreach( $data as $key=>$val ){
            $param_data[] = $key.'='.$val;
        }
        return implode('&',$param_data);
    }
    
    
    
    public static function convert_lang( $charset,$lang ){
        if( strpos($charset,'g')!==false ){
            $lang = iconv('GB2312','UTF-8',$lang);
        }
        return $lang;
    }
    
    
    
    public static function auto_iconv( $lang ){
        global $_G;
        return mb_convert_encoding($lang,$_G['charset'],'auto');
    }
    
    
    public static function create_select($name='',$data=array(),$selected='',$initial=array()){
        $select = '<select name="'.$name.'" id="'.$name.'">';
        if( $initial ){
            $select .= '<option value="'.$initial[0].'">'.$initial[1].'</option>';
        }
        foreach( $data as $val ){
            $sed = $selected==$val[0]?'selected':'';
            $select .= '<option value="'.$val[0].'" '.$sed.'>'.$val[1].'</option>';
        }
        $select .= "</select>";
        return $select;
    }
    
    
    public static function upload( $basepath='',$FILE ){
        
        if($FILE['tmp_name']) {
            $upload = new work_upload();
            if(!$upload->init($FILE, 'orange_work','work_upload', random(8)) || !$upload->save()) {
                $pic = '';
            }
            $pic = $basepath.$upload->attach['attachment'];
        } else {
            $pic = '';
        }
        return $pic;
    }
    
    
    
    public static function check_array( $array,$type=0 ){
        $types = array(
            '0'=>'addslashes',
            '1'=>'intval',
            '2'=>'strtotime',
            '3'=>'dhtmlspecialchars',
            '4'=>'auto_iconv'
            );
        return array_map($types[$type],$array);
    }
   	
    public static function output($success=0, $msg='',$id=0,$status=0) {
        $data['success'] = $success;
        $data['message'] = $msg;
        $data['id'] = $id;
        $data['status'] = $status;
        echo json_encode($data);
        exit;
    }

}
