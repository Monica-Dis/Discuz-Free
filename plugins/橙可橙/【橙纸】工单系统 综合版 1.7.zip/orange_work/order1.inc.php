<?php
    if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    $uid = $_G['uid'];
    $siteurl = $_G['siteurl'];
    $username = $_G['username'];
    $act = addslashes($_GET['act']);
    $lang = lang('plugin/orange_work');
    $orange_work = $_G['cache']['plugin']['orange_work'];
    require_once dirname(__FILE__) . '/orange_work.class.php';
    
    if( !$uid ){dheader('location:member.php?mod=logging&action=login');}
    
    
    if( !$act ){
    	$order_id = intval($_GET['order_id']);
    	$order = C::t('#orange_work#work_order')->get_order_first( $order_id );
    	if( $order['uid'] != $uid ){dheader('location:plugin.php?id=orange_work');}
		$work = C::t('#orange_work#work_item')->get_work_first( $order['wid'] );
		$order['content'] = unserialize($order['content']);
		$orange_work['site_name'] = $work['work_name'];
		$record = C::t('#orange_work#work_record')->get_record_all( array('orderid'=>$order_id) );
        include template('orange_work:handle');
    }else if( $act == 'publish' ){
    	if( $_GET['formhash'] != FORMHASH ){OrangeWork::output(false);}
    	$data = OrangeWork::check_array( $_GET );
    	$order = C::t('#orange_work#work_order')->get_order_first( $data['orderid'] );
    	if( $order['status'] != 1 ){
    		OrangeWork::output(false,0,0,1);
    	}
    	$publish['uid'] = $uid;
    	$publish['orderid'] = $data['orderid'];
    	$publish['content'] = $data['content'];
    	$publish['add_time'] = $_G['timestamp'];
    	$publish['pics'] = implode(',',OrangeWork::check_array( $_GET['pics'],3 ));
    	$result = C::t('#orange_work#work_record')->insert( $publish );
    	C::t('#orange_work#work_order')->update( array('notice'=>1),array('id'=>$order['id']) );
    	OrangeWork::output($result);
    }else if( $act == 'finish' ){
    	$order_id = intval($_GET['order_id']);
    	if( $_GET['formhash'] != FORMHASH ){OrangeWork::output(false);}
    	$order = C::t('#orange_work#work_order')->get_order_first( $order_id );
    	$work = C::t('#orange_work#work_item')->get_work_first( $order['wid'] );
    	if( $order['status'] == 1 ){
    		C::t('#orange_work#work_order')->update(array('status'=>2,'deduct'=>1,'notice'=>0,'price'=>$work['work_price']),array('id'=>$order_id));
			!$order['deduct'] && updatemembercount($order['uid'],array('extcredits'.$orange_work['site_money']=>-$work['work_price']),true,'WRK',1,1,1,1);
			OrangeWork::output(true);
    	}else{
    		OrangeWork::output(false);
    	}
    }else if( $act == 'cancel' ){
    	$order_id = intval($_GET['order_id']);
    	if( $_GET['formhash'] != FORMHASH ){OrangeWork::output(false);}
    	$order = C::t('#orange_work#work_order')->get_order_first( $order_id );
    	if( $order['status'] == 0 ){
    		C::t('#orange_work#work_order')->update(array('status'=>3),array('id'=>$order_id));
			OrangeWork::output(true);
    	}else{
    		OrangeWork::output(false);
    	}
    }else if( $act == 'snatch' ){
    	$status = 0;
    	$order_id = intval($_GET['order_id']);
    	if( $_GET['formhash'] != FORMHASH ){OrangeWork::output(false);}
    	$order = C::t('#orange_work#work_order')->get_order_first( $order_id );
    	if( !$order['deal_uid'] ){
    		$status = 1;
    		C::t('#orange_work#work_order')->update(array('deal_uid'=>$uid),array('id'=>$order_id));
    	}
    	OrangeWork::output($status);
    }
?>