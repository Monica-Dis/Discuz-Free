<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    $uid = $_G['uid'];
    $siteurl = $_G['siteurl'];
    $username = $_G['username'];
    $act = addslashes($_GET['act']);
    $lang = lang('plugin/orange_work');
    $orange_work = $_G['cache']['plugin']['orange_work'];
    require_once dirname(__FILE__) . '/orange_work.class.php';
    
    if( !$uid ){dheader('location:member.php?mod=logging&action=login');}
    
    
    if( !$act ){
    	$option_type = array(1=>'input',2=>'select',3=>'checkbox',4=>'textarea');
    	$work_id = intval($_GET['work_id']);
		$work = C::t('#orange_work#work_item')->get_work_first($work_id);
		$work['work_options'] = unserialize($work['work_options']);
		$orange_work['site_name'] = $work['work_name'];
		$sort_rule = $work_options = array();
		foreach( $work['work_options']['sort'] as $key=>$val){
			$sort_rule[$key] = $val;
		}
		asort($sort_rule);
		
		foreach( $sort_rule as $key=>$val ){
			$work_options[] = array(
				'type'=>$work['work_options']['type'][$key],
				'fill'=>$work['work_options']['fill'][$key],
				'name'=>$work['work_options']['name'][$key],
				'intro'=>$work['work_options']['intro'][$key],
				'value'=>explode(',',$work['work_options']['value'][$key])
			);
		}
        include template('orange_work:publish');
    }else if( $act == 'publish' ){
    	if( $_GET['formhash'] != FORMHASH ){OrangeWork::output(false,0,0,1);}
    	$data = OrangeWork::check_array( $_GET,3 );
    	
    	$work = C::t('#orange_work#work_item')->get_work_first($data['wid']);
    	$extcred = DB::fetch_first('SELECT extcredits1,extcredits2,extcredits3,extcredits4,extcredits5,extcredits6,extcredits7,extcredits8 FROM ' . DB::table('common_member_count') . ' WHERE uid=' . $uid);
    	if( $work['work_price'] && $extcred['extcredits'.$orange_work['site_money']] < $work['work_price'] ){
    		OrangeWork::output(-1);
    	}
    	
    	$data['name'] = OrangeWork::check_array( $_GET['name'],3 );
    	$data['type'] = OrangeWork::check_array( $_GET['type'],0 );
    	$data['val'] = $_GET['val'];

		foreach( $data['val'] as &$val ){
			if( is_array($val) ){
				$val = implode(',',OrangeWork::check_array( $val,3 ));
			}else{
				$val = addslashes($val);
			}
		}
		
		$publish['status'] = 0;
    	$publish['uid'] = $uid;
    	$publish['wid'] = $data['wid'];
    	$publish['user_name'] = $username;
    	$publish['add_time'] = $_G['timestamp'];
    	$publish['pics'] = implode(',',OrangeWork::check_array( $_GET['pics'],3 ));
    	$publish['content'] = serialize(array('name'=>$data['name'],'val'=>$data['val'],'type'=>$data['type']));
    	$result = C::t('#orange_work#work_order')->insert( $publish );
    	OrangeWork::output($result);
    }
    
    else if( $act == 'upload' ){
        if( !$uid || FORMHASH != $_GET['formhash']){
            OrangeWork::output(0);
        }
        require_once dirname(__FILE__) . '/work_upload.class.php';
        if (empty($_FILES)) {
            OrangeWork::output(false,'not_file');
        }
        
        foreach ($_FILES as $file) {
            $data['success'] = true;
            $data['pic'] = OrangeWork::upload('',$file);
            echo json_encode($data);
        }
    }
//From: Dism��taobao��com
?>