<?php
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    loadcache('plugin');
    $act = addslashes($_GET['act']);
    $lang = lang('plugin/orange_work');
    $orange_work = $_G['cache']['plugin']['orange_work'];
    require_once dirname(__FILE__) . '/orange_work.class.php';
    
    if( !$act ){
        $perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
		$start_limit = ($page - 1) * $perpage;
        $condition['wid'] = intval($_GET['wid']);
        $condition['notice'] = intval($_GET['notice']);
        $condition['title'] = addslashes($_GET['title']);
        $condition['status'] = isset($_GET['status'])?intval($_GET['status']):-1;
        $condition['deduct'] = isset($_GET['deduct'])?intval($_GET['deduct']):-1;
        $public_param = "&".OrangeWork::param_join($condition);
        $count = C::t('#orange_work#work_order')->get_order_count($condition);
        $mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=orange_work&pmod=admin_order".$public_param;
		$multipage = multi($count, $perpage, $page, $mpurl, 0, 3);
        $order_list = C::t('#orange_work#work_order')->get_order_list($start_limit,$perpage,$condition);
        
        $answer_select = OrangeWork::create_select('notice',array(array(0,$lang['a_all']),array(1,$lang['new_answer'])),$condition['notice']);
        $deduct_select = OrangeWork::create_select('deduct',array(array(0,$lang['a_work_deduct_0']),array(1,$lang['a_work_deduct_1'])),$condition['deduct'],array(-1,$lang['a_all']));
		$work_select = OrangeWork::create_select( 'wid',OrangeWork::initial_data( C::t('#orange_work#work_item')->get_work_list(),'id','work_name',4 ),$condition['wid'],array(0,$lang['a_all']) );
        $status_select = OrangeWork::create_select('status',array(array(0,$lang['a_status_0']),array(1,$lang['a_status_1']),array(2,$lang['a_status_2']),array(3,$lang['a_status_3'])),$condition['status'],array(-1,$lang['a_all']));

        $url = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_order';
        
        echo <<<SEARCH
            <form method="post" autocomplete="off" id="tb_search" action="$url">
            <table style="padding:10px 0;">
                <tbody>
                    <tr>
                        <th>$lang[a_work_name]</th><td>$work_select</td>
                        <th>&nbsp;$lang[a_work_status]</th><td>$status_select</td>
                        <th>&nbsp;$lang[a_work_deduct]</th><td>$deduct_select</td>
                        <th>&nbsp;$lang[new_answer]</th><td>$answer_select</td>
                        <th>&nbsp;$lang[a_merchant_name]</th><td><input type="text" class="txt" name="title" style="width:400px" value="$condition[title]" placeholder="$lang[a_user_name] / $lang[a_work_option] "></td>
                        <th></th><td><input type="submit" class="btn" value="$lang[a_submit]"></td>
                    </tr>
                </tbody>
            </table>
            </form>
SEARCH;
        
        
        
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_order&act=del', 'enctype');
		showtableheader();
		echo    '<tr class="header"><th></th><th>'.
	                $lang['a_id'].'</th><th>'.
	            	$lang['a_deal_name'].'</th><th>'.
					$lang['a_user_name'].'</th><th>'.
					
					$lang['a_work_option'].'</th><th>'.
					$lang['a_work_deduct'].'</th><th>'.
	            	$lang['a_work_status'].'</th><th>'.
	            	$lang['a_add_time'].'</th><th>'.
	                $lang['a_handle'].
	                '</th></tr>';
		foreach($order_list as $list) {
				$pics = array_filter(explode(',',$list['pics']));
				foreach( $pics as &$pic ){
					$pic = '<img src="'.$pic.'" width="50">';
				}
				$pics = implode('',$pics);
				$nocite = $list['notice'] == 1 ? '<span style="color:red;margin-right:5px;">'.$lang['new_answer'].'</span>' : '';
	            echo'<tr class="hover">'.
	                '<th><input class="checkbox" type="checkbox" name="delete['.$list['id'].']" value="'.$list['id'].'"></th>'.
	                '<th>'.$list['id'].'</th>'.
	                '<th>'.$list['deal_name'].'</th>'.
	                '<th>'.$list['user_name'].'</th>'.
	                
	                '<th width="300">'.OrangeWork::initial_cont($list['content']).'</th>'.
	                '<th>'.$lang['a_work_deduct_'.$list['deduct']].'</th>'.
	                '<th>'.$lang['a_status_'.$list['status']].'</th>'.
	                '<th>'.date('Y-m-d H:i',$list['add_time']).'</th>'.
	                '<th>'.
	                    $nocite.'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_order&act=edit&id='.$list['id'].$public_param.'">'.$lang['a_chuli'].'</a>&nbsp;'.
	                '</th>'.
	                '</tr>';
		}
		showsubmit('submit', lang('plugin/orange_work', 'a_del'),'', '', $multipage);
		showtablefooter(); /*dism _ taobao _ com*/
		showformfooter(); /*dism·taobao·com*/
    }
    else if( $act=='edit' ){
        if(!submitcheck('submit')) {
            $id = intval($_GET['id']);
            $order = C::t('#orange_work#work_order')->get_order_first( $id );
            $order['content'] = unserialize($order['content']);
            $record = C::t('#orange_work#work_record')->get_record_all( array('orderid'=>$id) );
            if( $order['deduct'] ){
            	$deduct_select = OrangeWork::create_select('deduct',array(array(1,$lang['a_work_deduct_1'])),$order['deduct']);
            }else{
            	$deduct_select = OrangeWork::create_select('deduct',array(array(0,$lang['a_deduct_0']),array(1,$lang['a_deduct_1'])),$order['deduct']);
            }
            $manage = array_filter(explode("\r\n",$orange_work['site_manage']));
			$muser = DB::fetch_all("SELECT uid,username FROM %t where uid in (".implode(',',$manage).")",array('common_member'));
			$deal_select =  OrangeWork::create_select( 'deal_uid',OrangeWork::initial_data( $muser,'uid','username',4 ),$order['deal_uid'] );
            $status_select = OrangeWork::create_select('status',array(array(0,$lang['a_status_0']),array(1,$lang['a_status_1']),array(2,$lang['a_status_2']),array(3,$lang['a_status_3'])),$order['status']);
            include template('orange_work:admin_order');
        }else{
        	$pics = $orderdata = array();
	    	$data = OrangeWork::check_array( $_GET,3 );
	    	$condition['wid'] = intval($data['where_wid']);
	        $condition['notice'] = intval($data['where_notice']);
	        $condition['title'] = addslashes($data['where_title']);
	        $condition['status'] = isset($data['where_status'])?intval($data['where_status']):-1;
	        $condition['deduct'] = isset($data['where_deduct'])?intval($data['where_deduct']):-1;
	        $public_param = "&".OrangeWork::param_join($condition);
	        
	    	require_once dirname(__FILE__) . '/work_upload.class.php';
	    	// 获取工单
	    	$order = C::t('#orange_work#work_order')->get_order_first( $data['id'] );
	    	// 上传多张照片
	    	for( $i=0; $i<count($_FILES);$i++ ){
	    		if( $_FILES['pics'.$i]['tmp_name'] ) {
	                $pics[] = OrangeWork::upload('',$_FILES['pics'.$i]);
	            }
	    	}
	    	// 工单回复内容组合
	    	$publish['orderid'] = $data['id'];
	    	$publish['deal_uid'] = $_G['uid'];
	    	$publish['pics'] = implode(',',$pics);
	    	$publish['content'] = $data['content'];
	    	$publish['add_time'] = $_G['timestamp'];
	    	// 修改工单状态
	    	$orderdata['status'] = $data['status'];
	    	// 上传图片或者回复文字时，插入回复记录
	    	if( $publish['pics'] || $publish['content'] ){	 
	    		$orderdata['status'] = 1;
	    		$orderdata['notice'] = 2;
	    		C::t('#orange_work#work_record')->insert( $publish );
	    	}
	    	// 查询工单
	    	$work = C::t('#orange_work#work_item')->get_work_first( $order['wid'] );
	    	if( $data['deduct'] && !$order['deduct'] && $order['status'] == 2 ){
	    		$work = C::t('#orange_work#work_item')->get_work_first( $order['wid'] );
	    		$orderdata['deduct'] = 1;
	    		$orderdata['price'] = $work['work_price'];
	    		$orderdata['extcredits'] = $orange_work['site_money'];
    			updatemembercount($order['uid'],array('extcredits'.$orange_work['site_money']=>-$work['work_price']),true,'WRK',1,1,1,1);
	    	}
	    	// 马甲app推送
	    	if( $orange_work['mag_host'] && $orange_work['mag_secret'] ){
	    		$notice_cont = str_replace('order',$work['work_name'],$lang['h_work_notice_cont']);
	    		file_get_contents($orange_work['mag_host'].'/mag/push/v1/push/sendPush?user_id='.$order['uid'].'&title='.urlencode($lang['h_work_notice']).'&content='.urlencode($notice_cont).'&link='.urlencode($_G['siteurl'].'plugin.php?id=orange_work:order&order_id='.$order['id']).'&secret='.$orange_work['mag_secret']);
	    	}
	    	// 工单状态未进行活进行中时，选择处理人 ，更新处理人信息
	    	if( ($order['status'] == 0 || $order['status'] == 1) && $data['deal_uid'] ){
	    		$manage = C::t('common_member')->fetch($data['deal_uid']);
	    		$orderdata['deal_name'] = $manage['username'];
	    		$orderdata['deal_uid'] = $manage['uid'];
	    	}else{
	    		$orderdata['deal_uid'] = $_G['uid'];
	    		$orderdata['deal_name'] = $_G['username'];	
	    	}
    	 	
	    	C::t('#orange_work#work_order')->update( $orderdata ,array('id'=>$data['id']) );
            cpmsg(lang('plugin/orange_work', 'a_success_info'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_order'.$public_param, 'succeed');
        }
    }
    elseif($act == 'del') {
		if(submitcheck('submit')) {
            foreach($_GET['delete'] as $delete) {
                C::t('#orange_work#work_order')->delete(array('id'=>$delete));
            }
            cpmsg(lang('plugin/orange_work', 'a_success_info'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_order', 'succeed');
        }

    }
?>