<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    loadcache('plugin');
    $act = addslashes($_GET['act']);
    $lang = lang('plugin/orange_work');
    $extcredits = $_G['setting']['extcredits'];
    $orange_work = $_G['cache']['plugin']['orange_work'];
    require_once dirname(__FILE__) . '/orange_work.class.php';
    
    if( !$act ){
        $perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
		$start_limit = ($page - 1) * $perpage;
        $condition['wid'] = intval($_GET['wid']);
        $condition['status'] = isset($_GET['status'])?intval($_GET['status']):-1;
        $condition['deduct'] = isset($_GET['deduct'])?intval($_GET['deduct']):-1;
        $condition['title'] = addslashes($_GET['title']);
        $count = C::t('#orange_work#work_order')->get_order_count($condition);
        $mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=orange_work&pmod=admin_count&".OrangeWork::param_join($condition);
		$multipage = multi($count, $perpage, $page, $mpurl, 0, 3);
        $order_list = C::t('#orange_work#work_order')->get_order_list($start_limit,$perpage,$condition);
        $deduct_select = OrangeWork::create_select('deduct',array(array(0,$lang['a_work_deduct_0']),array(1,$lang['a_work_deduct_1'])),$condition['deduct'],array(-1,$lang['a_all']));
		$work_select = OrangeWork::create_select( 'wid',OrangeWork::initial_data( C::t('#orange_work#work_item')->get_work_list(),'id','work_name',4 ),$condition['wid'],array(0,$lang['a_all']) );
        $status_select = OrangeWork::create_select('status',array(array(0,$lang['a_status_0']),array(1,$lang['a_status_1']),array(2,$lang['a_status_2']),array(3,$lang['a_status_3'])),$condition['status'],array(-1,$lang['a_all']));

        $url = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_count';
        
        $count_price = 0;
        foreach( $order_list as $o ){
        	$count_price += $o['price'];
        }
        
        echo <<<SEARCH
            <form method="post" autocomplete="off" id="tb_search" action="$url">
            <table style="padding:10px 0;">
                <tbody>
                    <tr>
                        <th>$lang[a_work_name]</th><td>$work_select</td>
                        <th>&nbsp;$lang[a_work_status]</th><td>$status_select</td>
                        <th>&nbsp;$lang[a_work_deduct]</th><td>$deduct_select</td>
                        <th>&nbsp;$lang[a_merchant_name]</th><td><input type="text" class="txt" name="title" style="width:400px" value="$condition[title]" placeholder="$lang[a_user_name] / $lang[a_work_option] "></td>
                        <th></th><td><input type="submit" class="btn" value="$lang[a_submit]"></td>
                    </tr>
                </tbody>
            </table>
            </form>
            <div style="margin:10px 0;border:1px solid #ccc;padding:20px 0;overflow:hidden;text-align:center;background:#f9f9f9;">
            	<div style="width:50%;float:left">
            		<div>{$count}</div>
            		<div style="margin-top:8px;font-size:16px;font-weight:bold;">$lang[a_work_count]</div>
            	</div>
            	<div style="width:50%;float:left">
            		<div>{$count_price}</div>
            		<div style="margin-top:8px;font-size:16px;font-weight:bold;">$lang[a_work_money]</div>
            	</div>
            </div>	
SEARCH;
        
        
        
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_count&act=del', 'enctype');
		showtableheader();
		echo    '<tr class="header"><th></th><th>'.
	                $lang['a_id'].'</th><th>'.
	            	$lang['a_deal_name'].'</th><th>'.
					$lang['a_user_name'].'</th><th>'.
					$lang['a_work_deduct'].'</th><th>'.
	            	$lang['a_work_status'].'</th><th>'.
	            	$lang['a_add_time'].'</th><th>'.
	                $lang['a_handle'].
	                '</th></tr>';
		foreach($order_list as $list) {
	            echo'<tr class="hover">'.
	                '<th><input class="checkbox" type="checkbox" name="delete['.$list['id'].']" value="'.$list['id'].'"></th>'.
	                '<th>'.$list['id'].'</th>'.
	                '<th>'.$list['deal_name'].'</th>'.
	                '<th>'.$list['user_name'].'</th>'.
	                '<th>'.$list['price'].$extcredits[$list['extcredits']]['title'].' / '.$lang['a_work_deduct_'.$list['deduct']].'</th>'.
	                '<th>'.$lang['a_status_'.$list['status']].'</th>'.
	                '<th>'.date('Y-m-d H:i',$list['add_time']).'</th>'.
	                '<th>'.
	                    '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_order&act=edit&id='.$list['id'].'">'.$lang['a_look'].'</a>&nbsp;'.
	                '</th>'.
	                '</tr>';
		}
		showsubmit('submit', lang('plugin/orange_work', 'a_del'),'', '', $multipage);
		showtablefooter(); /*dism _ taobao _ com*/
		showformfooter(); /*dism��taobao��com*/
    }
    else if( $act=='edit' ){
        if(!submitcheck('submit')) {
            $id = intval($_GET['id']);
            $order = C::t('#orange_work#work_order')->get_order_first( $id );
            $order['content'] = unserialize($order['content']);
            $record = C::t('#orange_work#work_record')->get_record_all( array('orderid'=>$id) );
            $deduct_select = OrangeWork::create_select('deduct',array(array(0,$lang['a_deduct_0']),array(1,$lang['a_deduct_1'])),$order['deduct']);
            $status_select = OrangeWork::create_select('status',array(array(0,$lang['a_status_0']),array(1,$lang['a_status_1']),array(2,$lang['a_status_2']),array(3,$lang['a_status_3'])),$order['status']);
            include template('orange_work:admin_count');
        }else{
        	$pics = $orderdata = array();
	    	$data = OrangeWork::check_array( $_GET );
	    	require_once dirname(__FILE__) . '/work_upload.class.php';
	    	$order = C::t('#orange_work#work_order')->get_order_first( $data['id'] );
	    	
	    	for( $i=0; $i<count($_FILES);$i++ ){
	    		if( $_FILES['pics'.$i]['tmp_name'] ) {
	                require_once dirname(__FILE__) . '/work_upload.class.php';
	                $pics[] = OrangeWork::upload('',$_FILES['pics'.$i]);
	            }
	    	}
	    	
	    	$publish['orderid'] = $data['id'];
	    	$publish['pics'] = implode(',',$pics);
	    	$publish['content'] = $data['content'];
	    	$publish['add_time'] = $_G['timestamp'];
	    	
	    	if( $publish['pics'] || $publish['content'] ){	 
	    		$orderdata['notice'] = 2;	
	    		C::t('#orange_work#work_record')->insert( $publish );
	    	}
	    	if( $data['deduct'] && !$order['deduct'] && $order['status'] == 2 ){
	    		$orderdata['deduct'] = 1;
	    		$orderdata['price'] = $work['work_price'];
    			$work = C::t('#orange_work#work_item')->get_work_first( $order['wid'] );
    			updatemembercount($order['uid'],array('extcredits'.$orange_work['site_money']=>-$work['work_price']),true,'WRK',1,1,1,1);
	    	}
	    	$orderdata['status'] = $data['status'];
	    	C::t('#orange_work#work_order')->update( $orderdata ,array('id'=>$data['id']) );
            cpmsg(lang('plugin/orange_work', 'a_success_info'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_count', 'succeed');
        }
    }
    elseif($act == 'del') {
		if(submitcheck('submit')) {
            foreach($_GET['delete'] as $delete) {
                C::t('#orange_work#work_order')->delete(array('id'=>$delete));
            }
            cpmsg(lang('plugin/orange_work', 'a_success_info'), 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_work&pmod=admin_count', 'succeed');
        }

    }
//From: Dism��taobao��com
?>