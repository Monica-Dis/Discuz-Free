<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_work_item extends discuz_table{
    public function __construct() {
        $this->_table = 'orange_work_item';
        $this->_pk = 'id';
        parent::__construct(); /*dism - taobao - com*/
    }
    
    
    public function get_work_count($where=array()){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
        
        if( $where['work_status'] ){
            $sql .=" AND work_status = %d ";
            $condition[] = $where['work_status'];
        }
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }
    
    public function get_work_list( $start=0,$size=10,$where=array() ){
        $sql = "SELECT * FROM %t WHERE 1";
        $condition[] = $this->_table;
        if( $where['work_status'] ){
            $sql .=" AND work_status = %d ";
            $condition[] = $where['work_status'];
        }
        $sql .=" ORDER BY work_sort asc";
        if( $size ){
            $sql .=" LIMIT %d ";
            $condition[] = $size;
        }
        return DB::fetch_all($sql,$condition);
    }
    
    
    
    public function get_work_first( $id ){
        return DB::fetch_first("SELECT * FROM %t WHERE id=%d",array($this->_table,$id));
    }
    
    
    public function insert( $data ){
        return DB::insert($this->_table, $data,true);
    }
    
    
    public function update( $data,$condition ){
        return DB::update($this->_table, $data,$condition,true);
    }
    
    
    public function delete( $condition ){
        return DB::delete($this->_table, $condition);
    }
    
	

}
//From: Dism��taobao��com
?>