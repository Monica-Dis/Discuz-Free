<?php
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_work_order extends discuz_table{
    public function __construct() {
        $this->_table = 'orange_work_order';
        $this->_pk = 'id';
        parent::__construct(); /*dism - taobao - com*/
    }
    
    
    public function get_order_count($where=array()){
        $sql = "SELECT count(*) as count FROM %t o,%t i WHERE o.wid=i.id";
        $condition[] = $this->_table;
        $condition[] = 'orange_work_item';
        
        
        if( $where['uid'] ){
            $sql .=" AND o.uid = %d ";
            $condition[] = $where['uid'];
        }
        if( $where['wid'] ){
            $sql .=" AND o.wid = %d ";
            $condition[] = $where['wid'];
        }
        if( $where['notice'] ){
            $sql .=" AND o.notice = %d ";
            $condition[] = $where['notice'];
        }
        if( $where['status'] > -1 ){
            $sql .=" AND o.status = %d ";
            $condition[] = $where['status'];
        }
        if( $where['deduct'] > -1 ){
            $sql .=" AND o.deduct = %d ";
            $condition[] = $where['deduct'];
        }
        if( $where['is_deal'] ){
        	$sql .=" AND o.status < 2 ";
        }
        if( $where['title'] ){
            $sql .=" AND ( o.user_name like %s or o.content like %s )";
            $condition[] = '%'.$where['title'].'%';
            $condition[] = '%'.$where['title'].'%';
        }
        
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }
    
    
    public function get_order_list( $start=0,$size=0,$where=array() ){
        $sql = "SELECT o.*,i.work_name,i.work_icon FROM %t o,%t i WHERE o.wid=i.id";
        $condition[] = $this->_table;
        $condition[] = 'orange_work_item';
        
        if( $where['uid'] ){
            $sql .=" AND o.uid = %d ";
            $condition[] = $where['uid'];
        }
        if( $where['wid'] ){
            $sql .=" AND o.wid = %d ";
            $condition[] = $where['wid'];
        }
        if( $where['notice'] ){
            $sql .=" AND o.notice = %d ";
            $condition[] = $where['notice'];
        }
        if( $where['status'] > -1 ){
            $sql .=" AND o.status = %d ";
            $condition[] = $where['status'];
        }
        if( $where['deduct'] > -1 ){
            $sql .=" AND o.deduct = %d ";
            $condition[] = $where['deduct'];
        }
        if( $where['is_deal'] ){
        	$sql .=" AND o.status < 2 ";
        }
        if( $where['title'] ){
            $sql .=" AND ( o.user_name like %s or o.content like %s )";
            $condition[] = '%'.$where['title'].'%';
            $condition[] = '%'.$where['title'].'%';
        }
        
        $sql .=" ORDER BY o.add_time desc LIMIT %d,%d";
        $condition[] = $start;
        $condition[] = $size;
        
        return DB::fetch_all($sql,$condition);
    }
    
    
    
    public function get_order_first( $id ){
        return DB::fetch_first("SELECT * FROM %t WHERE id=%d",array($this->_table,$id));
    }
    
    
    public function insert( $data ){
        return DB::insert($this->_table, $data,true);
    }
    
    
    public function update( $data,$condition ){
        return DB::update($this->_table, $data,$condition,true);
    }
    
    
    public function delete( $condition ){
        return DB::delete($this->_table, $condition);
    }
    
	

}
?>