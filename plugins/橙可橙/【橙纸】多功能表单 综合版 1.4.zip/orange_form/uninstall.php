<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

DB::query("DROP TABLE IF EXISTS ".DB::table('orange_form_item'));
DB::query("DROP TABLE IF EXISTS ".DB::table('orange_form_record'));

rm_dir(DISCUZ_ROOT.'/source/plugin','/orange_form');

/*
*删除文件夹下所有文件及文件夹
*/
function rm_dir($root_dir,$dir){
	$all_file = scandir($root_dir.$dir);
	foreach( $all_file as $file ){
		if( $file!='.' && $file!='..' ){
			if( strpos($file,'.') ){
				unlink($root_dir.$dir.'/'.$file);	
			}else if( count(scandir($root_dir.$dir.'/'.$file)) >2 ){
				rm_dir($root_dir.$dir,'/'.$file);
			}else{
				rmdir($root_dir.$dir.'/'.$file);	
			}
		}
	}
	rmdir($root_dir.$dir);	
}

$finish = TRUE;

?>