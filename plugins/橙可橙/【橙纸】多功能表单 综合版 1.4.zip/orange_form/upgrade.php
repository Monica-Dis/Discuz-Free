<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is gold plugin
 *
 *      install.php 2016-07-21 20:49 41Z gold 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');
// ALTER TABLE `pre_orange_form_item` ADD `form_header` TEXT NULL DEFAULT NULL AFTER `form_status`, ADD `form_footer` TEXT NULL DEFAULT NULL AFTER `form_header`;
$sql = <<<EOF
  ALTER TABLE `pre_orange_form_item` ADD `form_admin` VARCHAR(255) NOT NULL AFTER `id`;
EOF;

runquery($sql);

$finish = TRUE;

?>