<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
    if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }

    $act = addslashes($_GET['act']);
    $lang = lang('plugin/orange_form');
    
    function merge_cont( $data ){
		$str = "";
		foreach( $data['name'] as $key=>$val ){
			$str .= $val.' : '.$data['value'][$key];
		}
		return $str;
	}
    
    if( $act == 'export' ){
	    	$fid = intval($_GET['fid']);
	    	$condition['fid'] = $fid;
	    	$form = C::t('#orange_form#form_item')->get_form_first($fid);
        $count = C::t('#orange_form#form_record')->get_record_count($condition);
        $record = C::t('#orange_form#form_record')->get_record_list(0,$count,$condition);
	    	$form['form_options'] = unserialize($form['form_options']);
        
        if( !$count ){
        		echo "<script>alert('\u6682\u65e0\u6570\u636e\uff0c\u65e0\u6cd5\u5bfc\u51fa');window.history.back();</script>";exit;
        }
        
        header("Content-type:application/vnd.ms-excel"); 
		header("Content-Disposition:filename=".$form['form_name'].".xls");
		
		echo $lang['a_record_name']."\t";
		echo implode("\t",$form['form_options']['name'])."\t";
		echo $lang['a_add_time']."\t\n";
		foreach( $record as $data ){
			$data['content'] = unserialize($data['content']);
			echo $data['username']."\t";
			foreach($form['form_options']['name'] as $k=>$v ){
				echo html_entity_decode("&nbsp;".$data['content']['value'][$k])."\t";
			}
			echo date('Y-m-d H:i',$data['add_time'])."\t\n"; 
		}
		exit;
    }
//From: Dism_taobao-com
?>