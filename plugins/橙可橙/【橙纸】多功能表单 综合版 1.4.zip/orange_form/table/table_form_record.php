<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_form_record extends discuz_table{
    public function __construct() {
        $this->_table = 'orange_form_record';
        $this->_pk = 'id';
        parent::__construct();
    }
    
    /*
     * 返回用户统计数量
     */
    public function get_record_count($where=array()){
        $sql = "SELECT count(*) as count FROM %t r,%t i WHERE r.fid=i.id";
        $condition[] = $this->_table;
        $condition[] = 'orange_form_item';
        
        if( $where['fid'] ){
            $sql .=" AND r.fid = %d ";
            $condition[] = $where['fid'];
        }
        if( $where['keywords'] ){
            $sql .=" AND ( r.username like %s or r.content like %s )";
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
        }
        
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }
    /*
     * $limit 获取多少条分类 (0为全部)
     * $status 分类状态 (0为全部，1开启)
     * 返回指定数量的分类集合
     */
    public function get_record_list( $start=0,$size=10,$where=array() ){
        $sql = "SELECT r.*,i.form_name FROM %t r,%t i WHERE r.fid=i.id";
        $condition[] = $this->_table;
        $condition[] = 'orange_form_item';
        
        if( $where['fid'] ){
            $sql .=" AND r.fid = %d ";
            $condition[] = $where['fid'];
        }
        if( $where['keywords'] ){
            $sql .=" AND ( r.username like %s or r.content like %s )";
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
        }
        
        $sql .=" ORDER BY add_time desc";
        $sql .= " LIMIT %d,%d";
        $condition[] = $start;
        $condition[] = $size;
        return DB::fetch_all($sql,$condition);
    }
    
    /*
     * $limit 获取多少条分类 (0为全部)
     * $status 分类状态 (0为全部，1开启)
     * 返回指定数量的分类集合
     */
    public function get_record_all( $where=array() ){
        $sql = "SELECT r.*,i.form_name FROM %t r,%t i WHERE r.fid=i.id";
        $condition[] = $this->_table;
        $condition[] = 'orange_form_item';
        
        if( $where['fid'] ){
          $sql .=" AND r.fid = %d ";
          $condition[] = $where['fid'];
        }
        if( $where['uid'] ){
          $sql .=" AND r.uid = %d ";
          $condition[] = $where['uid'];
        }
        if( $where['keywords'] ){
          $sql .=" AND ( r.username like %s or r.content like %s )";
          $condition[] = '%'.$where['keywords'].'%';
          $condition[] = '%'.$where['keywords'].'%';
        }

        $sql .=" ORDER BY add_time desc";
        
        return DB::fetch_all($sql,$condition);
    }
    
    
    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_record_first( $id ){
        return DB::fetch_first("SELECT * FROM %t WHERE id=%d",array($this->_table,$id));
    }
    
    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_record_exist( $fid,$uid ){
        return DB::fetch_first("SELECT * FROM %t WHERE fid=%d AND uid=%d",array($this->_table,$fid,$uid));
    }
    
    /*
     * $data 分类信息数据
     * 返回插入的id
     */
    public function insert( $data ){
        return DB::insert($this->_table, $data,true);
    }
    
    /*
     * $data 分类更新数据
     * $condition 更新条件
     * 返回更新id 
     */
    public function update( $data,$condition ){
        return DB::update($this->_table, $data,$condition,true);
    }
    
    /*
     * $condition删除分类条件
     */
    public function delete( $condition ){
        return DB::delete($this->_table, $condition);
    }
    
	

}
//From: Dism_taobao-com
?>