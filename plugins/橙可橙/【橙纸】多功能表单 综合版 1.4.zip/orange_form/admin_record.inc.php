<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    loadcache('plugin');
    $act = daddslashes($_GET['act']);
    $lang = lang('plugin/orange_form');
    $extcredits = $_G['setting']['extcredits'];
    $orange_form = $_G['cache']['plugin']['orange_form'];
    require_once dirname(__FILE__) . '/orange_form.class.php';
    
    /*列表展示*/
    if( !$act ){
    	$perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
		$start_limit = ($page - 1) * $perpage;
		$condition['fid'] = intval($_GET['fid']);
		$condition['keywords'] = addslashes($_GET['keywords']);
		$count = C::t('#orange_form#form_record')->get_record_count($condition);
        $mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=orange_form&pmod=admin_record";
		$multipage = multi($count, $perpage, $page, $mpurl, 0, 3);
        $record_list = C::t('#orange_form#form_record')->get_record_list($start_limit,$perpage,$condition);
        
        $form_select = OrangeForm::create_select( 'fid',OrangeForm::initial_data( C::t('#orange_form#form_item')->get_form_list(0,0),'id','form_name',4 ),$condition['fid'],array(0,$lang['a_all']) );


        $url = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_record';
        
        echo <<<SEARCH
            <form method="post" autocomplete="off" id="tb_search" action="$url">
            <table style="padding:10px 0;">
                <tbody>
                    <tr>
                        <th>$lang[a_form_name]</th><td>$form_select</td>
                        <th></th><td><input type="text" class="txt" name="keywords" style="width:400px" value="$condition[keywords]" placeholder="$lang[a_record_name] / $lang[a_record_cont] "></td>
                        <th></th><td><input type="submit" class="btn" value="$lang[a_submit]"></td>
                    </tr>
                </tbody>
            </table>
            </form>
SEARCH;
        
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_record&act=del', 'enctype');
		showtableheader();
		echo    '<tr class="header"><th></th><th>'.
                $lang['a_id'].'</th><th>'.
				$lang['a_form_name'].'</th><th>'.
                $lang['a_record_name'].'</th><th>'.
            	$lang['a_add_time'].'</th><th>'.
				$lang['a_handle'].
                '</th></tr>';
		foreach($record_list as $list) {
	            echo'<tr class="hover">'.
	                '<th class="td25"><input class="checkbox" type="checkbox" name="delete['.$list['id'].']" value="'.$list['id'].'"></th>'.
	                '<th>'.$list['id'].'</th>'.
	                '<th>'.$list['form_name'].'</th>'.
	                '<th>'.$list['username'].'</th>'.
	                '<th>'.date('Y-m-d H:i',$list['add_time']).'</th>'.
	                '<th>'.
	                	'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_record&act=edit&id='.$list['id'].'">'.$lang['a_look'].'</a>'.
                	'</th>'.
	                '</tr>';
		}

	    showsubmit('submit',$lang['a_del'], '', '', $multipage);
		showtablefooter();/*Dism·taobao·com*/
		showformfooter();
    }
    /*添加分类*/
    else if( $act=='edit' ){
        if( !submitcheck('submit') ) {
            $id = intval($_GET['id']);
            if( $id ){
                $record = C::t('#orange_form#form_record')->get_record_first($id);
                $record['content'] = unserialize($record['content']);
            }
            include template('orange_form:admin_record');
        }
    }
    /*删除分类*/
    elseif($act == 'del') {
		if(submitcheck('submit')) {
            foreach($_POST['delete'] as $delete) {
                C::t('#orange_form#form_record')->delete(array('id'=>$delete));
            }
            cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_record', 'succeed');
        }

    }
//From: Dism_taobao-com
?>