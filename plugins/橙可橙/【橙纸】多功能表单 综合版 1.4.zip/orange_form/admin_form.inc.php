<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    loadcache('plugin');
    $act = daddslashes($_GET['act']);
    $lang = lang('plugin/orange_form');
    $extcredits = $_G['setting']['extcredits'];
    $orange_form = $_G['cache']['plugin']['orange_form'];
    require_once dirname(__FILE__) . '/orange_form.class.php';

    /*列表展示*/
    if( !$act ){
    		$perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
		$start_limit = ($page - 1) * $perpage;
		$count = C::t('#orange_form#form_item')->get_form_count();
        $mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=orange_form&pmod=admin_form";
		$multipage = multi($count, $perpage, $page, $mpurl, 0, 3);
        $form_list = C::t('#orange_form#form_item')->get_form_list($start_limit,$perpage);
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_form&act=del', 'enctype');
		showtableheader();
		echo    '<tr class="header"><th></th><th>'.
                $lang['a_id'].'</th><th>'.
				$lang['a_share_icon'].'</th><th>'.
				$lang['a_form_name'].'</th><th>'.
				$lang['a_form_price'].'</th><th>'.
                $lang['a_form_sort'].'</th><th>'.
				$lang['a_form_status'].'</th><th>'.
				$lang['a_handle'].
                '</th></tr>';
		foreach($form_list as $list) {
	            $form_status = $list['form_status'] ? $lang['a_open'] : $lang['a_stop'];
	            echo'<tr class="hover">'.
	                '<th class="td25"><input class="checkbox" type="checkbox" name="delete['.$list['id'].']" value="'.$list['id'].'"></th>'.
	                '<th>'.$list['id'].'</th>'.
	                '<th><a href="'.$list['form_icon'].'" target="_blank" title="'.$lang['a_big_image'].'"><img src="'.$list['form_icon'].'" width="30"/></a></th>'.
	                '<th>'.$list['form_name'].'</th>'.
	                '<th>'.$list['form_price'].$extcredits[$orange_form['site_money']]['title'].'</th>'.
	                '<th>'.$list['form_sort'].'</th>'.
	                '<th>'.$form_status.'</th>'.
	                '<th>'.
	                	'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_form&act=edit&id='.$list['id'].'">'.$lang['a_edit'].'</a>&nbsp;|&nbsp;'.
	                	'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_form&act=export&fid='.$list['id'].'">'.$lang['a_export'].'</a>&nbsp;|&nbsp;'.
	                	'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_form&act=link&fid='.$list['id'].'">'.$lang['a_link_url'].'</a>&nbsp;|&nbsp;'.
	                	'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_form&act=admin_link&fid='.$list['id'].'">'.$lang['a_form_link'].'</a>'.		
                	'</th>'.
	                '</tr>';
		}
		$add = '<input type="button" class="btn" onclick="location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_form&act=add\'" value="'.$lang['a_add'].'" />';
	    showsubmit('submit',$lang['a_del'], $add, '', $multipage);
		showtablefooter();/*Dism·taobao·com*/
		showformfooter();
    }
    /*添加分类*/
    else if( $act=='add' || $act=='edit' ){
        if( !submitcheck('submit') ) {
            $id = intval($_GET['id']);
            if( $id ){
                $form = C::t('#orange_form#form_item')->get_form_first($id);
                $form['form_options'] = unserialize($form['form_options']);
            }
            $usergroup = array_map(array_values,DB::fetch_all("SELECT groupid,grouptitle FROM %t",array('common_usergroup')));
            $group = OrangeForm::create_select(
            	'form_group[]',
            	$usergroup,
            	explode(',',$form['form_group']),
            	array(0,$lang['h_select']),
            	true
            );
            $type = OrangeForm::create_select(
            	'type[]',
            	array(
            		array(1,$lang['a_type_1']),
            		array(2,$lang['a_type_2']),
            		array(3,$lang['a_type_3']),
            		array(4,$lang['a_type_4']),
            		array(5,$lang['a_type_5']),
            		array(6,$lang['a_type_6']),
            		array(7,$lang['a_type_7'])
            	)
        	);
        	$fill = OrangeForm::create_select(
            	'fill[]',
            	array(
            		array(1,$lang['a_fill_1']),
            		array(2,$lang['a_fill_2'])
            	)
        	);
        	$repeat = OrangeForm::create_select(
            	'repeat[]',
            	array(
            		array(0,$lang['a_repeat_0']),
            		array(1,$lang['a_repeat_1'])
            	)
        	);
            include template('orange_form:admin_form');
        }else{
            $data = array();
            $id = intval($_GET['id']);
            if( $_FILES['form_icon']['tmp_name'] ) {
                require_once dirname(__FILE__) . '/form_upload.class.php';
                $_FILES['form_icon']['tmp_name'] && $data['form_icon'] = OrangeForm::upload('',$_FILES['form_icon']);
            }
            if( $_FILES['form_ad']['tmp_name'] ) {
                require_once dirname(__FILE__) . '/form_upload.class.php';
                $_FILES['form_ad']['tmp_name'] && $data['form_ad'] = OrangeForm::upload('',$_FILES['form_ad']);
            }
            $data['form_sort'] = intval($_GET['form_sort']);
            $data['form_url'] = addslashes($_GET['form_url']);
            $data['form_price'] = intval($_GET['form_price']);
            $data['form_name'] = addslashes($_GET['form_name']);
            $data['form_link'] = addslashes($_GET['form_link']);
            $data['form_status'] = intval($_GET['form_status']);
            $data['form_repeat'] = intval($_GET['form_repeat']);
            $data['form_admin'] = addslashes($_GET['form_admin']);
            $data['form_intro'] = addslashes($_GET['form_intro']);
            $data['form_color'] = addslashes($_GET['form_color']);
            $data['form_header'] = dhtmlspecialchars($_GET['form_header']);
            $data['form_footer'] = dhtmlspecialchars($_GET['form_footer']);
            $data['form_group'] = implode(',',OrangeForm::check_array($_GET['form_group'],1));
            $data['form_options'] = serialize(array(
            	'icon'=>OrangeForm::check_array($_GET['icon'],0),
            	'type'=>OrangeForm::check_array($_GET['type'],1),
            	'fill'=>OrangeForm::check_array($_GET['fill'],1),
            	'name'=>OrangeForm::check_array($_GET['name'],0),
            	'value'=>OrangeForm::check_array($_GET['value']),
            	'tips'=>OrangeForm::check_array($_GET['tips'],0),
            	'repeat'=>OrangeForm::check_array($_GET['repeat'],1),
            ));
            if( $id ){
                C::t('#orange_form#form_item')->update($data,array('id'=>$id));
            }else{
                C::t('#orange_form#form_item')->insert($data);
            }
            cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_form', 'succeed');
        }
    }
    /*调用连接*/
    elseif( $act == 'link' ){
    	showformheader('');
	    showtableheader();
	    showsetting($lang['a_link_url'], 'link',$_G['siteurl'].'plugin.php?id=orange_form&act=detail&fid='.$_GET['fid'], 'text',0,0,$lang['a_link_url_info']);
	    showtablefooter();/*Dism·taobao·com*/
	    showformfooter();
    }
    elseif( $act == 'admin_link' ){
    	showformheader('');
	    showtableheader();
	    showsetting($lang['a_form_link'], 'link',$_G['siteurl'].'plugin.php?id=orange_form&act=admin&fid='.$_GET['fid'], 'text',0,0,$lang['a_link_url_info']);
	    showtablefooter();/*Dism·taobao·com*/
	    showformfooter();
    }
    else if( $act == 'export' ){
    	$fid = intval($_GET['fid']);
    	dheader('location:plugin.php?id=orange_form:export&act=export&fid='.$fid);
    }
    /*删除分类*/
    elseif($act == 'del') {
		if(submitcheck('submit')) {
            foreach($_POST['delete'] as $delete) {
                C::t('#orange_form#form_item')->delete(array('id'=>$delete));
            }
            cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_form&pmod=admin_form', 'succeed');
        }

    }
//From: Dism_taobao-com
?>