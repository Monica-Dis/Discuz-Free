(function ($, document, Math) {
	function formSelect(){
		var self = this;
        $(document).on('touchstart',function () {
            formSelect.prototype.dis.x = event.changedTouches[0].pageX;
            formSelect.prototype.dis.y = event.changedTouches[0].pageY;
        })
        $(document).on('touchend','.select-main .cancel',function () {
            self.touch() && self.cancel()
		})
		$(document).on('touchend','.select-main .confirm',function () {
            self.touch() && self.confirm()
		})
		$(window).on('resize',function (){
			for( var s in this.swiper ){
				this.swiper[s].refresh();
			}
		})
	}
    formSelect.prototype.swiper = [];
    formSelect.prototype.dis = {};
    // 检测手指移动
    formSelect.prototype.touch = function () {
        return this.dis.x == event.changedTouches[0].pageX && this.dis.y == event.changedTouches[0].pageY;
    }
    // 创建控件
    formSelect.prototype.show = function ( options ) {
        var self = this;
        var _photo_ = self.__proto__;
        _photo_.el = options.el;
        _photo_.type = options.type;
        _photo_.data = options.data;
        _photo_.event = options.event || {};
        var SelectCont =
            '<section class="select-main">' +
				'<div class="select-cont">' +
				'<div class="header box align sb-line">' +
					'<div class="cancel box align">\u53d6\u6d88</div>' +
					'<div class="title flex">\u8bf7\u9009\u62e9</div>' +
					'<div class="confirm box align">\u786e\u5b9a</div>' +
				'</div>' +
				'select-option' +
				'</div>' +
            '</section>';
        var SelectData = "";
        // 控件选项的DOM生成
        // type 1 单选
        // type 2 多选
        // type 3 时间

        if( self.type == 1 || self.type == 2 ){
            SelectData = '<div class="select-swiper"><ul class="select-option">' + self.createOption(self.data,options.selected) + '</ul></div>';
		}else if( self.type == 3 ){
            var oDate = new Date();
            var year = oDate.getFullYear()+10;
            options.selected = options.selected.split('-');
            options.selected[0] = options.selected[0] ? options.selected[0] : oDate.getFullYear();
            options.selected[1] = options.selected[1] ? options.selected[1] : oDate.getMonth()+1;
            options.selected[2] = options.selected[2] ? options.selected[2] : oDate.getDate();
            _photo_.data[0] = self.fillArray(year,year-50);
            _photo_.data[1] = self.fillArray(1,12);
            _photo_.data[2] = self.fillArray(1,31);
            SelectData = '<div class="swiper-main box pack">';
            for( var i=0; i<_photo_.data.length; i++ ){
                SelectData += '<div class="swiper-list d'+(i+1)+'"><ul>' + self.createOption(_photo_.data[i]) + '</ul></div>';
            }
            SelectData += '<div class="swiper-rect"></div></div>';
        }
        // 内容替换
        SelectCont = SelectCont.replace('select-option',SelectData);
		// 生成控件
        $('body').append(SelectCont);
        // 控件事件创建
        if( self.type == 1 || self.type == 2 ) {
            _photo_.swiper[0] = new IScroll('.select-swiper',{
            	bindToWrapper: true
            });
            $(document).on('touchend.select','.select-option li',function () {
                if( !self.touch() ) return false;
                if( self.type == 1 ){
                    $('.select-option li').removeClass('active').eq($(this).index()).addClass('active');
                }else if( self.type == 2 ){
                    $(this).hasClass('active') ? $(this).removeClass('active') : $(this).addClass('active');
                }
            })
        }else if( self.type == 3 ){
            var height = $('.swiper-main li').eq(0).height();
            for( var i=0; i<_photo_.data.length; i++ ){
                _photo_.swiper[i] = new IScroll('.swiper-list.d' + ( i + 1 ),{snap: 'li',bindToWrapper: true});
                _photo_.swiper[i].scrollTo(0,-_photo_.data[i].indexOf(Number(options.selected[i]))*height);
            }
        }
    }
    // 销毁控件
    formSelect.prototype.hide = function () {
        var self = this;
        var _photo_ = self.__proto__;
        // 销毁选择DOM
		$('.select-main').remove();
		// 销毁选择事件
        $(document).off('touchend.select');
		// 销毁iScroll
		for( var i in _photo_.swiper ){
            _photo_.swiper[i].destroy();
        }
        // 清空数据
        _photo_.data = [];
        // 清空iScroll
        _photo_.swiper = [];
    }
    // 控件取消按钮
    formSelect.prototype.cancel = function () {
        this.event.cancel && this.event.cancel();
        this.hide();
    }
    // 控件确认按钮
    formSelect.prototype.confirm = function () {
        var value = this.getValue();
        this.el.val(value);
        this.event.confirm && this.event.confirm.apply(this,[value]);
        this.hide();
    }
    // 获取控件选择值
    formSelect.prototype.getValue = function () {
        var value = [];
        var self = this;
        var _photo_ = self.__proto__;
        
        if( self.type == 1 || self.type == 2 ){
            $.each($('.select-option li.active'),function (i,e){
                 value.push($(e).attr('data-value'));
            });
        }else if( self.type == 3 ){
            var height = $('.swiper-main li').eq(0).height();
            var index = _photo_.swiper.map(function (v) {
                return Math.round(Math.abs(v.y / height));
            });
            value = index.map(function (v,i) {
                return _photo_.coverNumber(_photo_.data[i][v]);
            });
            value = value.join('-');
        }
        return value;
    }
    // 创建选项
    formSelect.prototype.createOption = function (data,selected) {
        var self = this;
        var options = "";
        if( self.type == 1 || self.type == 2 ){
            self.type == 2 && ( selected = selected.split(',') );
            for( var attr in data ){
                var is_active = false;
                if( (self.type == 1 && selected == data[attr]) || (self.type == 2 && selected.indexOf(data[attr]) != -1) ){
                    is_active = true
                }
                options += '<li class="box align ' + ( is_active ? 'active':'') + '" data-value="' + data[attr] + '">' +
                                '<div class="text">' + data[attr] +'</div>' +
                                '<div class="icon fa fa-check"></div>'+
                            '</li>';
            }
        }else if( self.type == 3 ){
            data = data.map(function (v) {
                v = self.coverNumber(v);
                return '<li class="box align" data-value="'+v+'">'+v+'</li>';
            });
            options = data.join('');
        }
        return options;
    }
    // 填充指定范围数组
    formSelect.prototype.fillArray = function (start, end, step) {
        var data = [];
        var step = step ? step : 1;
        var len = (Math.abs(end - start)) / step;
        for( var i=0; i<=len; i++ ){
            if( start > end ){
                data[i] = start--;
            }else{
                data[i] = start++;
            }
        }
        return data;
    }
    // 格式化数字
    formSelect.prototype.coverNumber = function (n) {
        return n >= 10 ? n : '0' + n;
    }

	window.formSelect = formSelect;
})($, document, Math);
