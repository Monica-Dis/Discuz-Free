var page_disY = 0;
$(document).on('touchstart',function (){
	page_disY = event.changedTouches[0].pageY;
});
$(document).on('touchend','.open_page',function (){
	if( page_disY != event.changedTouches[0].pageY ){ return; }
    open_page($(this).attr('href'));
    return false;
});
function open_page( open_url ){
    if( !open_url )return false;
    if( is_xiaoyun ){
        connectSQJavascriptBridge(function(){
        	sq.urlRequest( open_url );
        });
    }else if( is_magappx ){
    	mag.newWin( open_url );
    }else{
        window.location.href = open_url;
    }
    return true;
}
function onLogin(){
	if( is_xiaoyun ){
        connectSQJavascriptBridge(function(){
            sq.login();
        });
    }else if( is_magappx ){
    	mag.toLogin();
    }else{
        document.location = siteurl+"/member.php?mod=logging&action=login"
    }
}

function show_msg( msg,loading,time,end ){
	time = time || 3;
	end = end || function (){};
	loading && layer.close(loading);
	layer.open({
        content: msg,
        skin: 'msg',
        time: time,
        end: end
    });
}

function imagePreview( imageArray,index ){
	if( is_xiaoyun ){
        connectSQJavascriptBridge(function(){
            sq.imagePreview(imageArray,index)
        });
    }else if( is_magappx ){
    	mag.previewImage({
    		current: index,
    		pics: imageArray
    	});
    }
}

function load_data( item_main,iMaxPage,datas,data_url,doc_main,before,after ){
    var page_main = doc_main || {doc_main:document,body_main:document};
    var view_height = $(window).height();
    var iNowPage = 1;
    var onOff = true;
    var time = null;
    var loading_item = null;
    
    $(document).bind('touchmove',move);
    $(window).bind('resize',function (){
        view_height = $(window).height();
    });
    
    function move(ev){
        var ev = ev || window.event;
        var aTouch = ev.changedTouches;
        var scr_top = $(page_main.doc_main).scrollTop();
        
        if( onOff && iNowPage < iMaxPage && scr_top + view_height > $(page_main.body_main).height() - 50){
            ajax_post();
            onOff = false;
            before && before();
        }else{
            var prevScrollTop = scr_top;
            clearInterval(time);
            time = setInterval(function (){
                var thisScrollTop = $(page_main.doc_main).scrollTop();
                if(thisScrollTop==prevScrollTop){
                    clearInterval(time);
                }
                prevScrollTop = $(page_main.doc_main).scrollTop();
            },200);
        }
    }


    function ajax_post(){
        if(!data_url)return;
        $.ajax({
            type:'post',
            url:data_url,
            data:$.extend(datas,{start:iNowPage*10}),
            success:function ( data ){
                if( !data ){
                    onOff = false;
                }else{
                    iNowPage++;
                    onOff = true;
                    after && after();
                    $(item_main).append(data);
                }
            }
        });
    }
}
// 启动APP分享
function onShare( title,intro,icon,link ) {
	if( is_xiaoyun ){
		connectSQJavascriptBridge(function(){
			var json = {
		        button: {
		            value: '',
		            icon: 'more',
		            type: 'action',
		            action: 'nav-right-mwindowenu'
		        },
		        callBack: function(){
	           		sq3.share({
						type: "all",
						title: title,
						content: intro,
						picUrl: icon,
						url: link
				    });
		        }
	    	}
	        sq.customNavBar(json);
	   });
	}else if( is_magappx ){
		mag.setData({
			shareData: {
				des: intro,
		    	title: title,
		    	picurl: icon,
		    	linkurl: link
		    }
		});
	}
}