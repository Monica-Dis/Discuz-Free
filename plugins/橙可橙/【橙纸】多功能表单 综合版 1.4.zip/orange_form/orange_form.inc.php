<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
  exit('Access Denied');
}
$uid = $_G['uid'];
$siteurl = $_G['siteurl'];
$username = $_G['username'];
$act = addslashes($_GET['act']);
$lang = lang('plugin/orange_form');
$orange_form = $_G['cache']['plugin']['orange_form'];
require_once dirname(__FILE__) . '/orange_form.class.php';
$ie = strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'trident');

/*表单*/
if ($act == 'detail') {
  $fid = dintval($_GET['fid']);
  $form = C::t('#orange_form#form_item')->get_form_first($fid);
  $record = C::t('#orange_form#form_record')->get_record_exist($fid, $uid);
  $form['form_options'] = $form_options = unserialize($form['form_options']);
  $form['form_group'] = array_filter(explode(',', $form['form_group']));
  $form['form_header'] = htmlspecialchars_decode($form['form_header']);
  $form['form_footer'] = htmlspecialchars_decode($form['form_footer']);
  include template('orange_form:detail');
} else if ($act == 'upload') {
  if (!$uid || FORMHASH != $_GET['formhash']) {
    OrangeForm::output(0);
  }
  if ($_FILES['upload_image']['tmp_name']) {
    require_once dirname(__FILE__) . '/form_upload.class.php';
    $data['path'] = OrangeForm::upload('', $_FILES['upload_image']);
  }
  OrangeForm::output(0, $data);
} else if ($act == 'publish') {
  $fid = dintval($_GET['fid']);
  $form = C::t('#orange_form#form_item')->get_form_first($fid);
  $exist = C::t('#orange_form#form_record')->get_record_exist($fid, $uid);
  if (!$fid || !$uid || FORMHASH != $_GET['formhash'] || (!$form['form_repeat'] &&  $exist)) {
    OrangeForm::output(0);
  }

  if ($_GET['is_pc']) {
    $repeat = OrangeForm::check_array($_GET['repeat']);
    $name = OrangeForm::check_array(OrangeForm::batch_convert($_G['charset'], $_GET['name']));
    $value = array_map(function ($v) use ($_G) {
      if (is_array($v)) {
        $v = implode(',', OrangeForm::check_array(OrangeForm::batch_convert($_G['charset'], $v), 3));
      } else {
        $v = addslashes($v);
      }
      return $v;
    }, OrangeForm::batch_convert($_G['charset'], $_GET['value']));
  }
  if ($_GET['is_mobile']) {
    $repeat = OrangeForm::check_array($_GET['repeat']);
    $name = OrangeForm::check_array($_GET['name']);
    $value = array_map(function ($v) use ($_G) {
      if (is_array($v)) {
        $v = implode(',', OrangeForm::check_array($v, 3));
      } else {
        $v = addslashes($v);
      }
      return $v;
    }, $_GET['value']);
  }

  $data['fid'] = $fid;
  $data['uid'] = $uid;
  $data['username'] = $username;
  $data['price'] = $form['form_price'];
  $data['add_time'] = $_G['timestamp'];
  $data['price_type'] = $orange_form['site_money'];
  $data['content'] = serialize(array(
    'name' => $name,
    'value' => $value,
    'repeat' => $repeat,
    'type' => OrangeForm::check_array($_GET['type']),
  ));
  $rule = array_filter($repeat);
  foreach ($rule as $k => $v) {
    $check[$k] = $value[$k];
  }
  if ($check) {
    $checks = C::t('#orange_form#form_record')->get_record_all(array('fid' => $fid));
    foreach ($checks as $c) {
      $c['content'] = unserialize($c['content']);
      foreach ($c['content']['value'] as $k => $v) {
        if (isset($check[$k]) && $check[$k] == $v) {
          OrangeForm::output(false, $k);
        }
      }
    }
  }
  $result = C::t('#orange_form#form_record')->insert($data);
  $result && updatemembercount($uid, array('extcredits' . $orange_form['site_money'] => $form['form_price']), true, 'OFR', 1, 1, 1, 1);
  OrangeForm::output($result, $form['form_link']);
} else if ($act == 'admin') {
  $fid = dintval($_GET['fid']);
  $form = C::t('#orange_form#form_item')->get_form_first($fid);
  $form['form_admin'] = array_filter(explode(',',$form['form_admin']));
  if( !in_array($uid,$form['form_admin']) ){
    dheader('location:plugin.php?id=orange_form&act=detail&fid='.$fid);exit;
  }
  $record_list = C::t('#orange_form#form_record')->get_record_all(array('fid' => $fid));
  $record_list = array_map(function ($v) {
    $content = unserialize($v['content']);
    $v['default_title'] = $content['value'][0];
    return $v;
  }, $record_list);
  include template('orange_form:admin');
}else if( $act == 'admin_detail' ){
  $rid = dintval($_GET['rid']);
  $record = C::t('#orange_form#form_record')->get_record_first($rid);
  $form = C::t('#orange_form#form_item')->get_form_first($record['fid']);
  $form['form_admin'] = array_filter(explode(',',$form['form_admin']));
  if( !in_array($uid,$form['form_admin']) ){
    dheader('location:plugin.php?id=orange_form&act=detail&fid='.$form['id']);exit;
  }
  $record['content'] = unserialize($record['content']);
  include template('orange_form:admin_detail');
}
