<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is gold plugin
 *
 *      install.php 2016-07-21 20:49 41Z gold 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql = <<<EOF
	
CREATE TABLE IF NOT EXISTS `pre_orange_form_item` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_admin` varchar(255) NOT NULL,
  `form_ad` varchar(255) NOT NULL,
  `form_url` varchar(255) NOT NULL,
  `form_name` varchar(50) DEFAULT NULL,
  `form_icon` varchar(255) DEFAULT NULL,
  `form_sort` int(11) DEFAULT '99',
  `form_link` text,
  `form_intro` varchar(255) DEFAULT NULL,
  `form_color` varchar(10) NOT NULL,
  `form_price` int(11) DEFAULT '0',
  `form_group` varchar(255) NOT NULL,
  `form_status` int(1) DEFAULT '0',
  `form_header` text,
  `form_footer` text,
  `form_repeat` int(1) DEFAULT '0',
  `form_options` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_orange_form_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `price_type` int(1) DEFAULT NULL,
  `content` text,
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;

?>