<?php
	if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    // 此通知文件仅供参考，函数内逻辑按实际需求开发
	function orange_pay_notify($order){
		// $order['pay_trade'] 交易类型
	    if( $order['pay_trade'] == 'buy' ){
	    		// 交易类型为购买商品时，进行商品订单的逻辑处理
	    }else if( $order['pay_trade'] == 'recharge' ){
	    		// 交易类型为充值时，进行充值订单的逻辑处理
	    }
	}
//From: Dism_taobao_com
?>