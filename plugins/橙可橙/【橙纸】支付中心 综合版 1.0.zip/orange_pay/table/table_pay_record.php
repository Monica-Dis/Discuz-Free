<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 本插件为 Discuz!应用中心 正版采购的应用, DisM.Taobao.Com提供更新支持。
 */
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_pay_record extends discuz_table{
    public function __construct() {
        $this->_table = 'orange_pay';
        $this->_pk = 'id';
        parent::__construct();
    }
    
    /*
     * 返回用户统计数量
     */
    public function get_pay_count($where=array()){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
        
        if( $where['pay_type'] ){
            $sql .=" AND pay_type = %s ";
            $condition[] = $where['pay_type'];
        }
        if( $where['pay_status'] > -1 ){
            $sql .=" AND pay_status = %d ";
            $condition[] = $where['pay_status'];
        }
        if( $where['keywords'] ){
            $sql .=" AND ( order_id like %s or pay_title like %s or pay_intro like %s or pay_source like %s or pay_trade_no like %s )";
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
        }
        
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }
    /*
     * $limit 获取多少条分类 (0为全部)
     * $status 分类状态 (0为全部，1开启)
     * 返回指定数量的分类集合
     */
    public function get_pay_list( $start=0,$size=10,$where=array() ){
        $sql = "SELECT * FROM %t WHERE 1";
        $condition[] = $this->_table;
        
        if( $where['pay_type'] ){
            $sql .=" AND pay_type = %s ";
            $condition[] = $where['pay_type'];
        }
        if( $where['pay_status'] > -1 ){
            $sql .=" AND pay_status = %d ";
            $condition[] = $where['pay_status'];
        }
        if( $where['keywords'] ){
            $sql .=" AND ( order_id like %s or pay_title like %s or pay_intro like %s or pay_source like %s or pay_trade_no like %s )";
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
            $condition[] = '%'.$where['keywords'].'%';
        }
        
        $sql .=" ORDER BY id desc";
        
        if( $size ){
	        $sql .= " LIMIT %d,%d";
	        $condition[] = $start;
	        $condition[] = $size;
        }
        
        return DB::fetch_all($sql,$condition);
    }
    
    
    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_pay_first( $id ){
        return DB::fetch_first("SELECT * FROM %t WHERE id=%d",array($this->_table,$id));
    }
    
    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_pay_exist( $order_id, $pay_trade, $pay_source ){
        return DB::fetch_first("SELECT * FROM %t WHERE order_id=%s AND pay_trade=%s AND pay_source=%s",array($this->_table, $order_id, $pay_trade, $pay_source));
    }
    
    /*
     * $data 分类信息数据
     * 返回插入的id
     */
    public function insert( $data ){
        return DB::insert($this->_table, $data,true);
    }
    
    /*
     * $data 分类更新数据
     * $condition 更新条件
     * 返回更新id 
     */
    public function update( $data,$condition ){
        return DB::update($this->_table, $data,$condition,true);
    }
    
    /*
     * $condition删除分类条件
     */
    public function delete( $condition ){
        return DB::delete($this->_table, $condition);
    }
    
	

}
//From: Dism_taobao_com
?>