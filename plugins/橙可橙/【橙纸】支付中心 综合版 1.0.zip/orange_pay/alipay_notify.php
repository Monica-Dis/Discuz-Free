<?php
    define('DISABLEXSSCHECK', true);
    require '../../../source/class/class_core.php';
    $discuz = C::app();
    $cachelist = array('plugin', 'diytemplatename');
    $discuz->cachelist = $cachelist;
    $discuz->init();
    
    $orange_pay = $_G['cache']['plugin']['orange_pay'];
    require_once dirname(__FILE__) . '/include/alipay/config.php';
    require_once dirname(__FILE__) . '/include/alipay/AopClient.php';
    require_once dirname(__FILE__) . '/include/alipay/AlipayTradeService.php';
    
    $POSTDATA = $_POST;
    $alipaySevice = new AlipayTradeService($AlipayConfig);
	$result = $alipaySevice->check($POSTDATA);
	
	if( $result ){
		$out_trade_no = explode('_',$POSTDATA['out_trade_no']);
		$trade_no = $POSTDATA['trade_no'];
		$PayId = $out_trade_no[0];
		$order = C::t('#orange_pay#pay_record')->get_pay_first($PayId);
		if( $POSTDATA['trade_status'] == 'TRADE_FINISHED' || $POSTDATA['trade_status'] == 'TRADE_SUCCESS' ){
			$res = C::t('#orange_pay#pay_record')->update(array('pay_time'=>$_G['timestamp'], 'pay_trade_no'=>$trade_no, 'pay_status'=>1), array('id'=>$PayId));
			if( $order['pay_source'] ){
				require DISCUZ_ROOT.'source/plugin/'.$order['pay_source'].'/notify.class.php';
				orange_pay_notify($order);
			}
			if( $res ) echo "success";
		}
	}else{
		echo "fail";
	}
    
?>