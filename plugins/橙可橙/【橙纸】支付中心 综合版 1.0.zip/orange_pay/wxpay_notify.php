<?php
    define('DISABLEXSSCHECK', true);
    require '../../../source/class/class_core.php';
    $discuz = C::app();
    $cachelist = array('plugin', 'diytemplatename');
    $discuz->cachelist = $cachelist;
    $discuz->init();
    
    $orange_pay = $_G['cache']['plugin']['orange_pay'];
    require_once dirname(__FILE__) . "/include/wxpay/WxPay.Data.php";
    require_once dirname(__FILE__) . "/include/wxpay/WxPay.Api.php";
	require_once dirname(__FILE__) . "/include/wxpay/WxPay.Config.php";
	require_once dirname(__FILE__) . "/include/wxpay/WxPay.Notify.php";
    
    $config = new WxPayConfig();
	$notify = new WxPayNotify();
	$result = $notify->Handle($config, false);
	if( $result ){
		$result = $result[1];
		$out_trade_no = explode('_',$result['out_trade_no']);
		$trade_no = $result['transaction_id'];
		$PayId = $out_trade_no[0];
		$order = C::t('#orange_pay#pay_record')->get_pay_first($PayId);
		if( $result['result_code'] == 'SUCCESS' || $result['return_code'] == 'SUCCESS' ){
			$res = C::t('#orange_pay#pay_record')->update(array('pay_time'=>$_G['timestamp'], 'pay_trade_no'=>$trade_no, 'pay_status'=>1), array('id'=>$PayId));
			if( $order['pay_source'] ){
				require DISCUZ_ROOT.'source/plugin/'.$order['pay_source'].'/notify.class.php';
				orange_pay_notify($order);
			}	
		}
	}
	
    
?>