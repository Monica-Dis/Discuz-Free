<?php
    if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    $siteurl = $_G['siteurl'];
    $PayId = dintval($_GET['pay_id']);
    $lang = lang('plugin/orange_pay');
    $orange_pay = $_G['cache']['plugin']['orange_pay'];
    require_once dirname(__FILE__) . '/PayApi.class.php';
    require_once dirname(__FILE__) . '/orange_pay.class.php';
    require_once dirname(__FILE__) . '/include/alipay/config.php';
    
    //判断curl是否开启
	if( !function_exists('curl_version') ){
		exit('Please open curl extension');
	}
	$PayOrder = PayApi::CheckPay($PayId);
	$PayOrder['pay_type_lang'] = $lang[PayApi::getPayType($PayOrder['pay_type'])];
	
    if( !$PayOrder ){
    		exit('order not exist');
    }else if( $PayOrder['pay_status'] ){
		$Pay = $PayOrder;
		$pay_status = $Pay['pay_status'] ? 'success' : 'error';
    		include template('orange_pay:return');exit;
    }
    $orderId = $PayOrder['id'] .'_'. time();
    $pay_title = cutstr(trim($PayOrder['pay_title']), 20, '');
    $pay_intro = cutstr(trim($PayOrder['pay_intro']), 20, '');
	if ( $_G['charset'] == 'gbk' ) {
	    $pay_title = diconv($pay_title,'GBK', 'UTF-8');
	    $pay_intro = diconv($pay_intro,'GBK', 'UTF-8');
	}
	
	if( $PayOrder['pay_type'] == 'alipay_pc' ){
		header("Content-type:text/Html;charset=UTF-8");
		require_once dirname(__FILE__) . '/include/alipay/AopClient.php';
		require_once dirname(__FILE__) . '/include/alipay/AlipayTradePayRequest.php';
		require_once dirname(__FILE__) . '/include/alipay/AlipayTradeService.php';
		require_once dirname(__FILE__) . '/include/alipay/AlipayTradePay.php';
		
    		$ApiMethodName = "alipay.trade.page.pay";
    		$ProductCode = "FAST_INSTANT_TRADE_PAY";
		
		$payRequestBuilder = new AlipayTradePay();
	    $payRequestBuilder->setBody($pay_intro);
	    $payRequestBuilder->setTimeExpress('15m');
	    $payRequestBuilder->setSubject($pay_title);
	    $payRequestBuilder->setOutTradeNo($orderId);
	    $payRequestBuilder->setProductCode($ProductCode);
	    $payRequestBuilder->setTotalAmount($PayOrder['pay_money']);
		
	    $payResponse = new AlipayTradeService($AlipayConfig);
	    $html_text = $payResponse->AliPay($payRequestBuilder, $AlipayConfig['return_url'], $AlipayConfig['notify_url'], $ApiMethodName, $ProductCode);
	    echo $html_text;exit;
	}else if( $PayOrder['pay_type'] == 'alipay_wap' ){
		header("Content-type:text/Html;charset=UTF-8");
		require_once dirname(__FILE__) . '/include/alipay/AopClient.php';
		require_once dirname(__FILE__) . '/include/alipay/AlipayTradePayRequest.php';
		require_once dirname(__FILE__) . '/include/alipay/AlipayTradeService.php';
		require_once dirname(__FILE__) . '/include/alipay/AlipayTradePay.php';
		
    		$ApiMethodName = "alipay.trade.wap.pay";
    		$ProductCode = "QUICK_WAP_PAY";
		
		$payRequestBuilder = new AlipayTradePay();
	    $payRequestBuilder->setBody($pay_intro);
	    $payRequestBuilder->setTimeExpress('15m');
	    $payRequestBuilder->setSubject($pay_title);
	    $payRequestBuilder->setOutTradeNo($orderId);
	    $payRequestBuilder->setProductCode($ProductCode);
	    $payRequestBuilder->setTotalAmount($PayOrder['pay_money']);
		
	    $payResponse = new AlipayTradeService($AlipayConfig);
	    $html_text = $payResponse->AliPay($payRequestBuilder, $AlipayConfig['return_url'], $AlipayConfig['notify_url'], $ApiMethodName, $ProductCode);
	    echo $html_text;exit;
	}else if( $PayOrder['pay_type'] == 'weixin_gzh' ){
		require_once dirname(__FILE__) . "/include/wxpay/WxPay.Api.php";
		require_once dirname(__FILE__) . "/include/wxpay/WxPay.Config.php";
		require_once dirname(__FILE__) . "/include/wxpay/WxPay.JsApiPay.php";
		
		$Pay = $PayOrder;
		$tools = new JsApiPay();
		$WxpayConfig = new WxPayConfig();
		
		$openId = $tools->GetOpenid(urlencode($siteurl.'plugin.php?id=orange_pay&pay_id=' . $PayId));
		
		$input = new WxPayUnifiedOrder();
		$input->SetOpenid($openId);
		$input->SetBody($pay_title);
		$input->SetAttach($pay_intro);
		$input->SetTrade_type("JSAPI");
		$input->SetOut_trade_no($orderId);
		$input->SetTime_start(date("YmdHis"));
		$input->SetTotal_fee($PayOrder['pay_money'] * 100);
		$input->SetTime_expire(date("YmdHis", time() + 600));
		$input->SetNotify_url($siteurl . "source/plugin/orange_pay/wxpay_notify.php");
		
		$payParam = WxPayApi::unifiedOrder($WxpayConfig, $input);
		$jsApiParameters = $tools->GetJsApiParameters($payParam);
    		include template('orange_pay:weixin_gzh');
	}else if( $PayOrder['pay_type'] == 'weixin_pc' ){
		require_once dirname(__FILE__) . "/include/wxpay/WxPay.Api.php";
		require_once dirname(__FILE__) . "/include/wxpay/WxPay.Config.php";
		require_once dirname(__FILE__) . "/include/wxpay/WxPay.NativePay.php";
		
		$Pay = $PayOrder;
		$native = new NativePay();
		$WxpayConfig = new WxPayConfig();
		
		$input = new WxPayUnifiedOrder();
		$input->SetBody($pay_title);
		$input->SetAttach($pay_intro);
		$input->SetTrade_type("NATIVE");
		$input->SetProduct_id($orderId);
		$input->SetOut_trade_no($orderId);
		$input->SetTime_start(date("YmdHis"));
		$input->SetTotal_fee($PayOrder['pay_money'] * 100);
		$input->SetTime_expire(date("YmdHis", time() + 600));
		$input->SetNotify_url($siteurl . "source/plugin/orange_pay/wxpay_notify.php");
		
		$result = $native->GetPayUrl($input);
		$scancode = urldecode($result["code_url"]);
    		include template('orange_pay:weixin_pc');
	}else if( $PayOrder['pay_type'] == 'weixin_wap' ){
		require_once dirname(__FILE__) . "/include/wxpay/WxPay.Api.php";
		require_once dirname(__FILE__) . "/include/wxpay/WxPay.Config.php";
		require_once dirname(__FILE__) . "/include/wxpay/WxPay.JsApiPay.php";
		
		$Pay = $PayOrder;
		$tools = new JsApiPay();
		$WxpayConfig = new WxPayConfig();
		
		$input = new WxPayUnifiedOrder();
		$input->SetBody($pay_title);
		$input->SetAttach($pay_intro);
		$input->SetTrade_type("MWEB");
		$input->SetOut_trade_no($orderId);
		$input->SetTime_start(date("YmdHis"));
		$input->SetTotal_fee($PayOrder['pay_money'] * 100);
		$input->SetTime_expire(date("YmdHis", time() + 600));
		$input->SetNotify_url($siteurl . "source/plugin/orange_pay/wxpay_notify.php");
		$input->SetScene_Info(json_encode(array('h5_info'=>array(
			'type'=>'pay',
			'wap_url'=>$siteurl,
			'wap_name'=>'test'
		))));
		
		$payParam = WxPayApi::unifiedOrder($WxpayConfig, $input);
		$payParam['mweb_url'] .= '&redirect_url='.urlencode($Pay['return_url']);
    		include template('orange_pay:weixin_wap');
	}
    
?>