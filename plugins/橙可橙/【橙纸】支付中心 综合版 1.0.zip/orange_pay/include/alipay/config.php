<?php
	$AlipayConfig = array (	
		'sign_type'=>"RSA2",
		'charset' => "UTF-8",
		'app_id' => $orange_pay['alipay_appid'],
		'alipay_public_key' => $orange_pay['alipay_public_key'],
		'gatewayUrl' => "https://openapi.alipay.com/gateway.do",
		'merchant_private_key' => $orange_pay['alipay_private_key'],
		'notify_url' => $siteurl . "source/plugin/orange_pay/alipay_notify.php",
		'return_url' => $siteurl . "plugin.php?id=orange_pay:alipay_return"
	);
?>