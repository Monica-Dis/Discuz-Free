<?php
    if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    $siteurl = $_G['siteurl'];
    $PayId = dintval($_GET['pay_id']);
    $lang = lang('plugin/orange_pay');
    $pay_type = addslashes($_GET['pay_type']);
    $orange_pay = $_G['cache']['plugin']['orange_pay'];
    require_once dirname(__FILE__) . '/PayApi.class.php';
    
   	$payid = PayApi::CreatePay(20,'123','456','pay','orange_pay','weixin_pc',0.01,$siteurl.'plugin.php?id=orange_pay&pay_id=1');
    dheader('location:plugin.php?id=orange_pay&pay_id='.$payid);
    
?>