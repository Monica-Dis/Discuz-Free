<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class OrangePay {
    const PLUGIN_ID = 'orange_pay';
    /*
     * 中文自动转码
     */
    public static function auto_iconv( $lang ){
        global $_G;
        return mb_convert_encoding($lang,$_G['charset'],'UTF-8');
    }
    
    /*
     * 初始化数据，select使用的正确数据格式
     * $data 二维数组
     * $field1 第一个字段名
     * $field2 第二个字段名
     * 返回 二维数组
     */
    public static function initial_data( $data,$field1,$field2,$type ){
        $arr = array();
        foreach( $data as $val ){
            switch( $type ){
                case 1:
                    $arr[$val[$field1]] = $val[$field1];
                    break;
                case 2:
                    $arr[$val[$field1]] = $val[$field2];
                    break;
                case 3:
                    $arr[$val[$field1]][] = $val[$field2];
                    break;
                case 4:
                    $arr[$val[$field1]] = array($val[$field1],$val[$field2]);
                    break;
                case 5:
                    $arr[$val[$field1]][] = $val;
                    break;
                case 6:
                    $arr[$val[$field1]] = $val;
                    break;
                default:
                    break;
            }
        }
        return $arr;
    }
    
    
    /*
     * 数组参数拼接
     * 用于分页时的参数传递
     */
    public static function param_join( $data ){
        $param_data = array();
        foreach( $data as $key=>$val ){
            $param_data[] = $key.'='.$val;
        }
        return implode('&',$param_data);
    }
    
    
    
    /*
     * 数组过滤，过滤非法数据
     * $types 过滤函数（自定义函数先进行声明）
     * array_map 对数组的每一项进行过滤
     * 返回过滤后的数据
     */
    
    public static function check_array( $array,$type=0 ){
        $types = array(
            '0'=>'addslashes',
            '1'=>'intval',
            '2'=>'strtotime',
            '3'=>'dhtmlspecialchars'
            );
        return array_map($types[$type],$array);
    }
    /*
     * 输出json提示信息
     */
    public static function output($success=0, $msg='',$id=0,$status=0) {
        $data['success'] = $success;
        $data['message'] = $msg;
        $data['id'] = $id;
        $data['status'] = $status;
        echo json_encode($data);
        exit;
    }
    /*
	 * httpGet请求
	 */
	public static function httpGet($url,$headers=array()) {
	    $curl = curl_init();
	    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
	    curl_setopt($curl, CURLOPT_URL, $url);
	    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($curl, CURLOPT_FAILONERROR, false);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
	    curl_setopt($curl, CURLOPT_HEADER, false);
	    $res = curl_exec($curl);
	    /*
	    if (!curl_errno($curl)) {
		    print_r(curl_getinfo($curl));
		}
		*/
	    curl_close($curl);
	    $res= json_decode($res, true);
	    return $res;
  	}
  	/*
	 * httpPost请求
	 */
  	public static function httpPost($url, $data) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        $return = curl_exec($ch);
        curl_close($ch);
        $result= json_decode($return, true);
        return $return;
    }
	/*
     * 生成select元素html结构
     * $name select的name属性和id属性值
     * $data select所需要的数据
     * $selected select选中的项
     * $initial 如果存在的时候会创建一个初始化的option
     * 返回生成好的select元素html代码
     */
    public static function create_select($name,$data,$selected,$initial=''){
        $select = "<select name='$name' id='$name'>";
        if( $initial ){
            $select .= "<option value='".$initial[0]."'>".$initial[1]."</option>";
        }
        foreach( $data as $val ){
            $sed = $selected==$val[0]?'selected':'';
            $select .= "<option value='".$val[0]."' $sed>".$val[1]."</option>";
        }
        $select .= "</select>";
        return $select;
    }
}
