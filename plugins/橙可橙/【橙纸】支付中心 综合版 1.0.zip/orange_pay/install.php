<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is gold plugin
 *
 *      install.php 2016-07-21 20:49 41Z gold 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql = <<<EOF
	
CREATE TABLE IF NOT EXISTS `pre_orange_pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` varchar(50) DEFAULT NULL,
  `pay_title` varchar(20) DEFAULT NULL,
  `pay_intro` varchar(50) DEFAULT NULL,
  `pay_type` varchar(10) DEFAULT NULL,
  `pay_time` int(11) DEFAULT NULL,
  `pay_trade` varchar(10) NOT NULL,
  `pay_source` varchar(20) DEFAULT NULL,
  `pay_money` decimal(10,2) DEFAULT NULL,
  `pay_trade_no` varchar(50) DEFAULT NULL,
  `pay_status` int(1) DEFAULT '0',
  `add_time` int(11) NOT NULL,
  `return_url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;

?>