<?php
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    $lang = lang('plugin/orange_pay');
    $payid = '$payid';
    $PayList = '$PayList';
    $order_id = '$order_id';
    $pay_type = '$pay_type';
    $pay_title = '$pay_title';
    $pay_intro = '$pay_intro';
    $pay_trade = '$pay_trade';
    $pay_money = '$pay_money';
    $return_url = '$return_url';
    $pay_source = '$pay_source';
    include template('orange_pay:admin_import');
?>