<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class PayApi {
    const PLUGIN_ID = 'pay_api';
    /**
    * CreatePay 
    * 创建支付记录
    *
    * @access public
    * @param mixed $order_id 		订单ID
    * @param mixed $pay_title 		支付标题
    * @param mixed $pay_intro	 	支付内容
    * @param mixed $pay_trade 		交易类型【一个插件多个支付时用到】
    * @param mixed $pay_source 		支付来源【插件标识】
    * @param mixed $pay_type 		支付类型
    * @param mixed $pay_money 		支付金额
    * @param mixed $return_url 		支付跳转URL【不设则跳转默认页面】
    * @return 创建订单ID
    */
    public static function CreatePay( $order_id, $pay_title, $pay_intro, $pay_trade, $pay_source, $pay_type, $pay_money, $return_url ){
    		global $_G;
    		$Pay = C::t('#orange_pay#pay_record')->get_pay_exist($order_id, $pay_trade, $pay_source);
    		$data = array(
    			'order_id'=>$order_id,
    			'pay_title'=>$pay_title,
    			'pay_intro'=>$pay_intro,
    			'pay_type'=>$pay_type,
    			'pay_trade'=>$pay_trade,
    			'pay_source'=>$pay_source,
    			'pay_money'=>$pay_money,
    			'return_url'=>$return_url,
    		);
    		
    		if( $Pay ){
    			C::t('#orange_pay#pay_record')->update($data, array('id'=>$Pay['id']));
    			$PayId = $Pay['id'];
    		}else{
    			$data['add_time'] = $_G['timestamp'];
    			$PayId = C::t('#orange_pay#pay_record')->insert($data);
    		}
    		return $PayId;
    }
    // 获取支付
    public static function CheckPay( $pay_id ){
    		return C::t('#orange_pay#pay_record')->get_pay_first($pay_id); 
    }
    // 获取支付选项
    public static function getPayList(){
    		global $_G;
    		$PayList = array();
    		$isMobile = checkmobile();
    		$lang = lang('plugin/orange_pay');
	    $orange_pay = $_G['cache']['plugin']['orange_pay'];
	    $isWeixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
	    if( $isWeixin && $orange_pay['weixin_app'] ){
	    		$PayList['weixin_gzh'] = array(
	    			"name" => $lang['weixin'],
	    			"icon" => "source/plugin/orange_pay/static/images/weixin.png"
	    		);
	    }
	    if( !$isWeixin && $isMobile ){
	    		if( $orange_pay['weixin_h5'] ){
		    		$PayList['weixin_wap'] = array(
		    			"name" => $lang['weixin'],
		    			"icon" => "source/plugin/orange_pay/static/images/weixin.png"
		    		);
	    		}
	    		if( $orange_pay['alipay_h5'] ){
		    		$PayList['alipay_wap'] = array(
		    			"name" => $lang['alipay'],
		    			"icon" => "source/plugin/orange_pay/static/images/alipay.png"
		    		);
	    		}
	    }
	    if( !$isWeixin && !$isMobile ){
	    		if( $orange_pay['weixin_pc'] ){
		    		$PayList['weixin_pc'] = array(
		    			"name" => $lang['weixin'],
		    			"icon" => "source/plugin/orange_pay/static/images/weixin.png"
		    		);
	    		}
	    		if( $orange_pay['alipay_pc'] ){
		    		$PayList['alipay_pc'] = array(
		    			"name" => $lang['alipay'],
		    			"icon" => "source/plugin/orange_pay/static/images/alipay.png"
		    		);
	    		}
	    }
	    return $PayList;
    }
    // 获取支付类型
    public static function getPayType( $type ){
    		return current(explode('_',$type));
    }
}
