<?php
    if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
    $uid = $_G['uid'];
    $siteurl = $_G['siteurl'];
    $lang = lang('plugin/orange_pay');
    $orange_pay = $_G['cache']['plugin']['orange_pay'];
    require_once dirname(__FILE__) . '/PayApi.class.php';
    require_once dirname(__FILE__) . '/include/alipay/config.php';
    require_once dirname(__FILE__) . '/include/alipay/AopClient.php';
    require_once dirname(__FILE__) . '/include/alipay/AlipayTradeService.php';
    
    $DATA = $_GET;
    $pay_status = "";
    unset($DATA['id']);
    $alipaySevice = new AlipayTradeService($AlipayConfig);
	$result = $alipaySevice->check($DATA);
	
	$out_trade_no = explode('_',$DATA['out_trade_no']);
	$trade_no = $DATA['trade_no'];
	$PayId = $out_trade_no[0];
	
	$Pay = C::t('#orange_pay#pay_record')->get_pay_first($PayId);
	$Pay['pay_type_lang'] = $lang[PayApi::getPayType($Pay['pay_type'])];
	
	if( $result ){
		$pay_status =  "success";
	}else{
		$pay_status =  "error";
	}
    include template('orange_pay:return');
?>