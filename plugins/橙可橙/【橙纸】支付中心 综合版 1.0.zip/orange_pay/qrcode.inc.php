<?php
	if(!defined('IN_DISCUZ')) {
        exit('Access Denied');
    }
	require_once dirname(__FILE__) . "/include/phpqrcode/phpqrcode.php";
	$url = urldecode($_GET["data"]);
	QRcode::png($url);
