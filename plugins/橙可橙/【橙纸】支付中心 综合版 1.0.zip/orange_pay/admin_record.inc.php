<?php
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    $act = daddslashes($_GET['act']);
    $lang = lang('plugin/orange_pay');
    $orange_pay = $_G['cache']['plugin']['orange_pay'];
    require_once dirname(__FILE__) . '/orange_pay.class.php';
    
    /*列表展示*/
    if( !$act ){
    		$perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
		$start_limit = ($page - 1) * $perpage;
		
		$condition['keywords'] = addslashes($_GET['keywords']);
		$condition['pay_type'] = addslashes($_GET['pay_type']);
		$condition['pay_status'] = isset($_GET['pay_status'])?intval($_GET['pay_status']):-1;
		
		$count = C::t('#orange_pay#pay_record')->get_pay_count($condition);
        $mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=orange_pay&pmod=admin_record&".OrangePay::param_join($condition);
		$multipage = multi($count, $perpage, $page, $mpurl, 0, 3);
        $record_list = C::t('#orange_pay#pay_record')->get_pay_list($start_limit,$perpage,$condition);
        $pay_status_select = OrangePay::create_select('pay_status',array(array(-1,$lang['a_all']),array(0,$lang['h_pay_status_0']),array(1,$lang['h_pay_status_1'])),$condition['pay_status']);
        $pay_type_select = OrangePay::create_select('pay_type',array(array(0,$lang['a_all']),array('weixin_gzh',$lang['weixin_gzh']),array('weixin_wap',$lang['weixin_wap']),array('alipay_wap',$lang['alipay_wap']),array('weixin_pc',$lang['weixin_pc']),array('alipay_pc',$lang['alipay_pc'])),$condition['pay_type']);
		
        $url = ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_pay&pmod=admin_record';
        
        echo <<<SEARCH
            <form method="post" autocomplete="off" id="tb_search" action="$url">
            <table style="padding:10px 0;">
                <tbody>
                    <tr>
                        <th>$lang[a_pay_type]</th><td>$pay_type_select</td>
                        <th>$lang[a_pay_status]</th><td>$pay_status_select</td>
                        <th></th><td><input type="text" class="txt" name="keywords" style="width:400px" value="$condition[keywords]" placeholder="$lang[a_order_id] / $lang[a_pay_title] / $lang[a_pay_intro] / $lang[a_pay_source] / $lang[a_pay_trade_no]"></td>
                        <th></th><td><input type="submit" class="btn" value="$lang[a_submit]"></td>
                    </tr>
                </tbody>
            </table>
            </form>
SEARCH;
        
		showformheader('plugins&operation=config&do='.$pluginid.'&identifier=orange_pay&pmod=admin_record&act=del', 'enctype');
		showtableheader();
		echo    '<tr class="header"><th></th><th>'.
                $lang['a_id'].'</th><th>'.
				$lang['a_order_id'].'</th><th>'.
                $lang['a_pay_title'].'</th><th>'.
            		$lang['a_pay_intro'].'</th><th>'.
            		$lang['a_pay_type'].'</th><th>'.
            		$lang['a_pay_time'].'</th><th>'.
            		$lang['a_pay_source'].'</th><th>'.
            		$lang['a_pay_money'].'</th><th>'.
            		$lang['a_pay_trade_no'].'</th><th>'.
            		$lang['a_pay_status'].'</th><th>'.
				$lang['a_handle'].
                '</th></tr>';
		foreach($record_list as $list) {
	            echo'<tr class="hover">'.
	                '<th class="td25"><input class="checkbox" type="checkbox" name="delete['.$list['id'].']" value="'.$list['id'].'"></th>'.
	                '<th>'.$list['id'].'</th>'.
	                '<th>'.$list['order_id'].'</th>'.
	                '<th>'.$list['pay_title'].'</th>'.
	                '<th>'.$list['pay_intro'].'</th>'.
	                '<th>'.$lang[$list['pay_type']].'</th>'.
	                '<th>'.date('Y-m-d H:i',$list['pay_time']).'</th>'.
	                '<th>'.$list['pay_source'].'</th>'.
	                '<th>'.$list['pay_money'].'</th>'.
	                '<th>'.$list['pay_trade_no'].'</th>'.
	                '<th>'.$lang['h_pay_status_'.$list['pay_status']].'</th>'.
	                '<th>'.
                	'</th>'.
                '</tr>';
		}

	    showsubmit('','', '', '', $multipage);
		showtablefooter();/*Dism-taobao_com*/
		showformfooter();
    }
    /*添加分类*/
    else if( $act=='edit' ){
        if( !submitcheck('submit') ) {
            $id = intval($_GET['id']);
            if( $id ){
                $record = C::t('#orange_pay#pay_record')->get_record_first($id);
                $record['content'] = unserialize($record['content']);
            }
            include template('orange_pay:admin_record');
        }
    }
    /*删除分类*/
    elseif($act == 'del') {
		if(submitcheck('submit')) {
            foreach($_POST['delete'] as $delete) {
                C::t('#orange_pay#pay_record')->delete(array('id'=>$delete));
            }
            cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_pay&pmod=admin_record', 'succeed');
        }

    }
//From: Dism_taobao_com
?>