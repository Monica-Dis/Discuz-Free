<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    $lang = lang('plugin/orange_vote');
    $act = dhtmlspecialchars($_GET['act']);
    require_once dirname(__FILE__) . '/orange_vote.class.php';
    
    /*列表展示*/
    if( !$act ){
    	$perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
      $start_limit = ($page - 1) * $perpage;
      $condition['vote_id'] = intval($_GET['vote_id']);
      $condition['vote_item_id'] = intval($_GET['vote_item_id']);
      $public_param = "&".OrangeVote::param_join($condition);

		  $count = C::t('#orange_vote#vote_record')->get_record_count($condition);
      $mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=orange_vote&pmod=admin_record".$public_param;
		  $multipage = multi($count, $perpage, $page, $mpurl, 0, 3);
      $vote_list = C::t('#orange_vote#vote_record')->get_record_list($start_limit,$perpage,$condition);

		  showformheader('plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_record&act=del', 'enctype');
		  showtableheader();
		  echo    '<tr class="header"><th></th><th>'.
            'ID</th><th>UID</th><th>'.
				    $lang['a_vote_username'].'</th><th>'.
				    $lang['a_vote_number'].'</th><th>'.
				    $lang['a_is_app'].'</th><th>'.
				    $lang['a_is_share'].'</th><th>'.
				    $lang['a_record_ip'].'</th><th>'.
				    $lang['a_add_time'].'</th>'.
                '</tr>';
		        foreach($vote_list as $list) {
	            echo'<tr class="hover">'.
	                '<th class="td25"><input class="checkbox" type="checkbox" name="delete['.$list['id'].']" value="'.$list['id'].'"></th>'.
	                '<th>'.$list['id'].'</th>'.
	                '<th>'.$list['uid'].'</th>'.
	                '<th><img src="'.$_G['setting']['ucenterurl'].'/avatar.php?uid='.$list['uid'].'&size=middle" width="40"/>'.$list['username'].'</th>'.
	                '<th>'.$list['number'].'</th>'.
	                '<th>'.$lang['a_is_app_'.$list['is_app']].'</th>'.
	                '<th>'.$list['share_number'].$lang['h_vote_unit'].'</th>'.
	                '<th>'.$list['ip'].'</th>'.
	                '<th>'.date('Y-m-d H:i:s',$list['add_time']).'</th>'.
	                '</tr>';
		      }
	
	    showsubmit('','', '', '', $multipage);
      showtablefooter();/*Dism_taobao-com*/
      showformfooter();
    }
//From: Dism_taobao-com
?>