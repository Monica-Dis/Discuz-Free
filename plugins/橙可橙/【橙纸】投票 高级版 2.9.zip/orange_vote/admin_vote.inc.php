<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    $lang = lang('plugin/orange_vote');
    $act = dhtmlspecialchars($_GET['act']);
    require_once dirname(__FILE__) . '/orange_vote.class.php';
    
    /*列表展示*/
    if( !$act ){
    	$perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
		  $start_limit = ($page - 1) * $perpage;
		  $count = C::t('#orange_vote#vote')->get_vote_count();
      $mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=orange_vote&pmod=admin_vote";
		  $multipage = multi($count, $perpage, $page, $mpurl, 0, 3);
      $vote_list = C::t('#orange_vote#vote')->get_vote_list($start_limit,$perpage);
		  showformheader('plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_vote&act=del', 'enctype');
		  showtableheader();
		  echo    '<tr class="header"><th></th><th>'.
            'ID</th><th>'.
				    $lang['a_title'].'</th><th>'.
				    $lang['a_attend_user'].'/'.$lang['a_vote_number'].'/'.$lang['a_visit_number'].'</th><th>'.
				    $lang['a_apply_start'].'</th><th>'.
				    $lang['a_apply_end'].'</th><th>'.
				    $lang['a_apply_weixin'].'</th><th>'.
				    $lang['a_vote_start'].'</th><th>'.
				    $lang['a_vote_end'].'</th><th>'.
				    $lang['a_status'].'</th><th>'.
				    $lang['a_handle'].
                '</th><th></th></tr>';
		        foreach($vote_list as $list) {
	            $status = $list['status'] ? $lang['a_open'] : $lang['a_stop'];
	            $apply_weixin = $list['apply_weixin'] ? $lang['a_open'] : $lang['a_stop'];
	            echo'<tr class="hover">'.
	                '<th class="td25"><input class="checkbox" type="checkbox" name="delete['.$list['id'].']" value="'.$list['id'].'"></th>'.
	                '<th>'.$list['id'].'</th>'.
	                '<th>'.$list['title'].'</th>'.
	                '<th style="text-align:center">'.$list['attend_user'].' / '.$list['vote_number'].' / '.$list['visit_number'].'</th>'.
	                '<th>'.date('Y-m-d H:i:s',$list['apply_start']).'</th>'.
	                '<th>'.date('Y-m-d H:i:s',$list['apply_end']).'</th>'.
	                '<th>'.$apply_weixin.'</th>'.
	                '<th>'.date('Y-m-d H:i:s',$list['vote_start']).'</th>'.
	                '<th>'.date('Y-m-d H:i:s',$list['vote_end']).'</th>'.
	                '<th>'.$status.'</th>'.
	                '<th><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_vote&act=edit&id='.$list['id'].'">'.$lang['a_edit'].'</a> | <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_user&vote_id='.$list['id'].'">'.$lang['a_apply_manage'].'</a> | <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_vote&act=link&vote_id='.$list['id'].'">'.$lang['a_link'].'</a> | <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_record&vote_id='.$list['id'].'">'.$lang['a_vote_record'].'</a></th>'.
	                '</tr>';
		      }
		  $add = '<input type="button" class="btn" onclick="location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_vote&act=add\'" value="'.$lang['a_add'].'" />';
	
	    showsubmit('submit',$lang['a_del'], $add, '', $multipage);
	
      showtablefooter();/*Dism_taobao-com*/
      showformfooter();
    }
    /*添加分类*/
    else if( $act=='add' || $act=='edit' ){
        if( !submitcheck('submit') ) {
            $id = intval($_GET['id']);
            if( $id ){
              $vote = C::t('#orange_vote#vote')->get_vote_first($id);
              $vote['vote_rule'] = unserialize($vote['vote_rule']);
              $vote['apply_option'] = unserialize($vote['apply_option']);
              $vote['apply_start'] = date('Y-m-d H:i:s',$vote['apply_start']);
              $vote['apply_end'] = date('Y-m-d H:i:s',$vote['apply_end']);
              $vote['vote_start'] = date('Y-m-d H:i:s',$vote['vote_start']);
              $vote['vote_end'] = date('Y-m-d H:i:s',$vote['vote_end']);
            }
            $type = OrangeVote::create_select(
            	'type[]',
            	array(
            		array(1,$lang['a_type_1']),
            		array(2,$lang['a_type_2']),
            	)
            );
            $show = OrangeVote::create_select(
                'show[]',
                array(
                  array(1,$lang['a_show_1']),
                  array(2,$lang['a_show_2'])
                )
            );
            $fill = OrangeVote::create_select(
              'fill[]',
              array(
                array(1,$lang['a_fill_1']),
                array(2,$lang['a_fill_2'])
              )
          );
            include template('orange_vote:admin_vote');
        }else{
            $data = array();
            $id = intval($_GET['id']);
            if( $_FILES['image']['tmp_name'] ) {
              require_once dirname(__FILE__) . '/vote_upload.class.php';
              $_FILES['image']['tmp_name'] && $data['image'] = OrangeVote::upload('',$_FILES['image']);
            }
            
            $data['title'] = $_GET['title'];
            $data['intro'] = $_GET['intro'];
            $data['slides'] = $_GET['slides'];
            $data['slogan'] = $_GET['slogan'];
            $data['vote_ip'] = $_GET['vote_ip'];
            $data['content'] = $_GET['content'];
            $data['vote_date'] = $_GET['vote_date'];
            $data['wx_content'] = $_GET['wx_content'];
            $data['status'] = intval($_GET['status']);
            $data['apply_help'] = $_GET['apply_help'];
            $data['vote_poster'] = $_GET['vote_poster'];
            $data['theme_color'] = $_GET['theme_color'];
            $data['vote_app'] = intval($_GET['vote_app']);
            $data['vote_rank'] = intval($_GET['vote_rank']);
            $data['vote_end'] = strtotime($_GET['vote_end']);
            $data['vote_share'] = intval($_GET['vote_share']);
            $data['apply_end'] = strtotime($_GET['apply_end']);
            $data['apply_audit'] = intval($_GET['apply_audit']);
            $data['vote_verify'] = intval($_GET['vote_verify']);
            $data['apply_image'] = intval($_GET['apply_image']);
            $data['apply_video'] = intval($_GET['apply_video']);
            $data['vote_number'] = intval($_GET['vote_number']);
            $data['attend_user'] = intval($_GET['attend_user']);
            $data['vote_start'] = strtotime($_GET['vote_start']);
            $data['visit_number'] = intval($_GET['visit_number']);
            $data['apply_weixin'] = intval($_GET['apply_weixin']);
            $data['apply_start'] = strtotime($_GET['apply_start']);
            $data['vote_app_scale'] = intval($_GET['vote_app_scale']);
            $data['apply_option'] = serialize(array(
            	'type' => $_GET['type'],
            	'show' => $_GET['show'],
            	'fill' => $_GET['fill'],
            	'name' => $_GET['name']
            ));
            $data['vote_rule'] = serialize($_GET['vote_rule']);
            
            if( $id ){
              C::t('#orange_vote#vote')->update($data,array('id'=>$id));
            }else{
              $data['add_time'] = $_G['timestamp'];
              C::t('#orange_vote#vote')->insert($data);
            }
            cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_vote', 'succeed');
        }
    }
    elseif($act == 'link') {
      showformheader('');
      showtableheader();
      showsetting(lang('plugin/orange_vote', 'a_link_url'), 'link',$_G['siteurl'].'plugin.php?id=orange_vote&vote_id='.$_GET['vote_id'], 'text',0,0,lang('plugin/orange_vote', 'a_link_url_info'));
      showtablefooter();/*Dism_taobao-com*/
      showformfooter();
    }
    /*删除分类*/
    elseif($act == 'del') {
	    if(submitcheck('submit')) {
          foreach($_POST['delete'] as $delete) {
              C::t('#orange_vote#vote')->delete(array('id'=>$delete));
          }
          cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_vote', 'succeed');
      }

    }
//From: Dism_taobao-com
?>