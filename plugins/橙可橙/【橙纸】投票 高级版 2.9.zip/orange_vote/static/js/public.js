var page_disY = 0;
$(document).on('touchstart', function () {
  page_disY = event.changedTouches[0].pageY;
});
$(document).on('touchend', '.open-page', function () {
  if (page_disY != event.changedTouches[0].pageY) {
    return;
  }
  open_page($(this).attr('href'));
  return false;
});

function open_page(open_url) {
  if (!open_url) return false;
  if (is_xiaoyun) {
    connectSQJavascriptBridge(function () {
      sq.urlRequest(open_url);
    });
  } else if (is_magappx) {
    mag.newWin(open_url);
  } else if (is_qianfan) {
    QFH5.jumpNewWebview(open_url);
  } else {
    window.location.href = open_url;
  }
  return true;
}

function isCheckApp() {
  return is_xiaoyun || is_magappx || is_qianfan;
}

function onLogin() {
  if (is_xiaoyun) {
    connectSQJavascriptBridge(function () {
      sq.login();
    });
  } else if (is_magappx) {
    mag.toLogin();
  } else if (is_qianfan) {
    QFH5.jumpLogin();
  } else {
    document.location = siteurl + "/member.php?mod=logging&action=login&referer=" + escape(window.location.href);
  }
}

function show_msg(msg, loading, time, end) {
  time = time || 3;
  end = end || function () {};
  loading && layer.close(loading);
  layer.open({
    content: msg,
    skin: 'msg',
    time: time,
    end: end
  });
}

function ShowMsg(title, content, button, callback) {
  title = title || "\u6e29\u99a8\u63d0\u793a";
  button = button || "\u786e\u5b9a";
  var msg =
    '<div class="app-alert-msg align pack box">' +
    '<div class="msg-box">' +
    '<div class="icon iconclose" data-type="close"></div>' +
    '<div class="title box align pack">' +
    '<div class="text">' + title + '</div>' +
    '</div>' +
    '<div class="msg-cont theme-text-color">' + content + '</div>' +
    '<div class="box pack"><div class="msg-button box pack align theme-bg-color" style="color: #fff;" data-type="confirm">' + button + '</div></div>' +
    '<div style="height: 0.8rem"></div>' +
    '</div>' +
    '</div>';
  $('body').append(msg);
  $('.app-alert-msg .iconclose,.app-alert-msg .msg-button').on('click', function () {
    $(this).off('click');
    if ($(this).data('type') == 'confirm') {
      callback && callback();
    }
    $('.app-alert-msg').remove();
  })
}

function imagePreview(imageArray, index) {
  if (is_xiaoyun) {
    connectSQJavascriptBridge(function () {
      sq.imagePreview(imageArray, index)
    });
  } else if (is_magappx) {
    mag.previewImage({
      current: index,
      pics: imageArray
    });
  } else if (is_qianfan) {
    QFH5.viewImages(index, imageArray);
  } else if (is_weixin) {
    wx.previewImage({
      urls: imageArray,
      current: imageArray[index]
    });
  }
}

function setShareData(title, desc, icon, url, callback) {
  if (isCheckApp()) {
    url = url.replace(document.location.origin, shareurl.replace(/\/+$/,''));
  }
  if (is_xiaoyun) {
    connectSQJavascriptBridge(function () {
      sq.share({
        url: url,
        type: 'all',
        title: title,
        picUrl: icon,
        content: desc,
        success: callback
      })
    });
  } else if (is_magappx) {
    mag.setData({
      shareData: {
        title: title,
        des: desc,
        picurl: icon,
        linkurl: url
      }
    });
    callback && mag.share('ALL', function () {
      //成功回调
      callback();
    });
  } else if (is_qianfan) {
    QFH5.setShareInfo(title, icon, desc, url,function(state,data){
      if( state == 1 && callback ){
        callback();
      }
    });
  } else if (is_weixin) {
    wx.ready(function () {
      var shareconfig = {
        link: url,
        desc: desc,
        title: title,
        imgUrl: icon
      };
      wx.onMenuShareQQ(shareconfig)
      wx.onMenuShareQZone(shareconfig)
      wx.onMenuShareTimeline(shareconfig)
      wx.onMenuShareAppMessage(shareconfig)
      wx.updateTimelineShareData(shareconfig)
      wx.updateAppMessageShareData(shareconfig)
    });
  }
}

// 加载HTML
function AjaxHtml(el, url, type, data, clear, callback) {
  window.ajax = window.ajax || {};
  if (window.ajax.isLoad) {
    return false;
  }
  window.ajax.isLoad = true;
  $.ajax({
    url: url,
    type: type,
    data: data,
    success: function (data) {
      data = $.trim(data);
      window.ajax.isLoad = false;
      if (data) {
        if (clear) {
          el.html(data);
        } else {
          el.append(data);
        }
      }
      callback && callback(data);
    }
  });
}
window.verifyCoord = [];
window.closeVerify = function () {
  window.verifyCoord = [];
  $('.verification-wrap').remove();
}
window.refreshVerify = function () {
  window.verifyCoord = [];
  $('.verification-wrap .ver-dot').remove();
  $('.verification-wrap .ver-image img').attr('src', 'plugin.php?id=orange_vote&act=verification&v=' + Math.random());
}

// 投票
function VoteUser(vote_item_id, success, error, verify) {
  success = success || function () {}
  error = error || function () {}
  if (is_app_vote && !isCheckApp()) {
    return showAppPanel();
  }else if( !is_login ){
    return onLogin();
  } else if (is_vote_verify && (!verify || !verify.length)) {
    var verifyImg = 'plugin.php?id=orange_vote&act=verification&v=' + Math.random();
    var verifyEl = '<div class="verification-wrap box pack align">' +
      '<div class="verification-box">' +
      '<div class="ver-image">' +
      '<img src="' + verifyImg + '">' +
      '<div class="ver-mark"></div>' +
      '</div>' +
      '<div class="ver-button box pack">' +
      '<div data-type="refresh" class="theme-bg-color">\u5237\u65b0</div>' +
      '<div data-type="close">\u5173\u95ed</div>' +
      '</div>' +
      '</div>' +
      '</div>';
    $('body').append(verifyEl);
    $('.verification-wrap .ver-mark').on('click', function () {
      var verify = window.verifyCoord;
      if (verify.length < 4) {
        verify.push(event.offsetX + "," + event.offsetY);
        $('.ver-image').append('<div class="ver-dot" style="top: ' + event.offsetY + 'px;left: ' + event.offsetX + 'px">' + ($('.ver-dot').length + 1) + '</div>');
      }
      if (verify.length == 4) {
        VoteUser(vote_item_id, success, error, [verify.join("-"), $('.ver-image').width(), $('.ver-image').height()].join(";"));
      }
    })
    $('.verification-wrap .ver-button div').on('click', function () {
      var type = $(this).data('type');
      if (type == 'refresh') {
        window.refreshVerify();
      } else if (type == 'close') {
        window.closeVerify();
      }
    })
  } else {
    var loading = layer.open({
      type: 2,
      shadeClose: false
    });
    $.ajax({
      type: 'post',
      dataType: 'json',
      data: {
        act: 'vote',
        verify: verify,
        formhash: formhash,
        vote_item_id: vote_item_id
      },
      url: 'plugin.php?id=orange_vote',
      success: function (data) {
        var end = null;
        var button = null;
        var msg = '<div class="text">' + votelang[data.success] + '</div>';
        if (data.success != -1) {
          window.closeVerify();
        }
        switch (data.success) {
          case -3:
            var date = data.message.split('-');
            msg = "\u6295\u7968\u65f6\u95f4\u4e3a" + date[0] + "\u70b9 - " + date[1] + "\u70b9";
            break;
          case -2:
            msg = "\u6b64\u0049\u0050\u6bb5\u88ab\u7981\u6b62\u64cd\u4f5c";
            break;
          case -1:
            end = window.refreshVerify;
            break;
          case 0:
            onLogin();
            break;
          case 4:
            end = showAppPanel;
            break;
          case 6:
            msg = msg.replace('N', data.message);
            break;
          case 7:
            window.share_vote_item_id = vote_item_id;
            break;
        }
        if (!isCheckApp() && data.id > 1 && data.success == 7) {
          button = "\u524d\u5f80" + appname + "\u6295\u7968";
          msg += '<div class="tips">' + appname + '\u5185\u4e00\u7968\u9876' + data.id + '\u7968\uff01</div>';
          end = function () {
            $('.down-app').click();
          }
        }else if( isCheckApp() && data.status > 0 && data.success == 7 ){
          button = "\u53bb\u5206\u4eab";
          msg += '<div class="tips">' + votelang.share.replace('N', data.status) + '</div>';
          end = function () {
            setShareData.apply(null,window.ShareInfo);
          }
        }
        success(data);
        layer.close(loading);
        msg && ShowMsg(null, msg, button, end);
      },
      error: error
    });
  }
}

function getTimeCountDown(FutureTime) {
  var ThisTime = Math.round(new Date().getTime() / 1000);
  var DateInfo = {};

  if (ThisTime < FutureTime) {
    DateInfo.status = 1;
    DateInfo.Senconds = (FutureTime - ThisTime) % 60;
    DateInfo.Day = Math.floor((FutureTime - ThisTime) / 86400);
    DateInfo.Hours = Math.floor((FutureTime - ThisTime) / 3600) % 24;
    DateInfo.Minutes = Math.floor((FutureTime - ThisTime) / 60) % 60;
  } else {
    DateInfo.status = 2;
  }
  return DateInfo;
}

function getMagVersion(){
  var ua = navigator.userAgent.split('MAGAPPX');
  var mag = ('MAGAPPX'+ua).split('|');
  var v = mag[1].substr(0,5).split('.').join('');
  return v;
}