<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class OrangeShare {
	
  const PLUGIN_ID = 'orange_share';
  private $appid;
  private $appsecret;

  public function __construct($appid,$appsecret){
    $this->appid = $appid;
    $this->appsecret = $appsecret;
  }

  // 获取AccessToken
  public function getAccessToken($data = array()){
    global $_G;
    if( !$data['id'] ){
      $data = C::t('#orange_vote#share')->get_byappid_share($this->appid);
    }
    $data['access_token'] = unserialize($data['access_token']);

    if( !$data || $data['access_token']['expire_time'] < $_G['timestamp'] ){
      $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$this->appid."&secret=".$this->appsecret;
      $res = $this->HttpGet($url);
      $access_token = $res['access_token'];
      if( $access_token ){
        $share = array(
          'appid' => $this->appid,
          'appsecret' => $this->appsecret,
          'access_token' => serialize(array(
            'content' =>$access_token,
            'expire_time' => $_G['timestamp'] + $res['expires_in']
          ))
        );
        if( $data['id'] ){
          C::t('#orange_vote#share')->update($share,array('id'=>$data['id']));
        }else{
          C::t('#orange_vote#share')->insert($share);
        }
      }
    }else{
      $access_token = $data['access_token']['content'];
    }
    return $access_token;
  }

  // 获取JsApiTicket
  public function getJsApiTicket(){
    global $_G;
    $data = C::t('#orange_vote#share')->get_byappid_share($this->appid);
    $data['jsapi_ticket'] = unserialize($data['jsapi_ticket']);
    $access_token = $this->getAccessToken($data);

    if( !$data || $data['jsapi_ticket']['expire_time'] < $_G['timestamp'] ){
      $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=".$access_token."&type=jsapi";
      $res = $this->HttpGet($url);
      $jsapi_ticket = $res['ticket'];
      if( $jsapi_ticket ){
        $share = array(
          'appid' => $this->appid,
          'appsecret' => $this->appsecret,
          'jsapi_ticket' => serialize(array(
            'content' =>$jsapi_ticket,
            'expire_time' => $_G['timestamp'] + $res['expires_in']
          ))
        );
        C::t('#orange_vote#share')->update($share,array('id'=>$data['id']));
      }
    }else{
      $jsapi_ticket = $data['jsapi_ticket']['content'];
    }
    return $jsapi_ticket;
  }

  // 获取jssdk签名
  public function getSignPackage() {
    global $_G;
    $jsapiTicket = $this->getJsApiTicket(); 
 
    // 注意 URL 一定要动态获取，不能 hardcode. 
    $url = $_G['siteurl'].substr($_SERVER['REQUEST_URI'],1);
 
    $timestamp = $_G['timestamp'];
    $nonceStr = $this->createNonceStr(); 
 
    // 这里参数的顺序要按照 key 值 ASCII 码升序排序 
    $string = "jsapi_ticket=".$jsapiTicket."&noncestr=".$nonceStr."&timestamp=".$timestamp."&url=".$url; 
 
    $signature = sha1($string); 
 
    $signPackage = array( 
      "appId"     => $this->appid, 
      "nonceStr"  => $nonceStr, 
      "timestamp" => $timestamp, 
      "url"       => $url, 
      "signature" => $signature, 
      "rawString" => $string 
    ); 
    return $signPackage;  
  }

  // 创建随机字符串
  private function createNonceStr($length = 16) {
    $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
    $str = "";
    for ($i = 0; $i < $length; $i++) {
      $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
    }
    return $str;
  }

  /*
	 * httpGet请求
	 */
	private function HttpGet($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 500);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, true);
    curl_setopt($curl, CURLOPT_URL, $url);
    $res = curl_exec($curl);
    curl_close($curl);
    $res= json_decode($res, true);
    return $res;
  }
  /*
  * httpPost请求
  */
  private function HttpPost($url, $data) {
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_HEADER, 0);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      $return = curl_exec($ch);
      curl_close($ch);
      $result= json_decode($return, true);
      return $return;
 }

}