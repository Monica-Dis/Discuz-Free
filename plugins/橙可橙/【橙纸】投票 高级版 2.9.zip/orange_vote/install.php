<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is gold plugin
 *
 *      install.php 2016-07-21 20:49 41Z gold 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `cdb_orange_share` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `appid` varchar(50) DEFAULT NULL,
  `appsecret` varchar(50) DEFAULT NULL,
  `access_token` varchar(255) DEFAULT NULL,
  `jsapi_ticket` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `appid` (`appid`,`appsecret`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `cdb_orange_vote` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `intro` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `slides` text NOT NULL,
  `slogan` text NOT NULL,
  `theme_color` varchar(10) DEFAULT NULL,
  `vote_poster` varchar(50) NOT NULL,
  `attend_user` int(11) DEFAULT '0',
  `vote_number` int(11) DEFAULT '0',
  `visit_number` int(11) DEFAULT '0',
  `apply_option` text NOT NULL,
  `apply_start` int(11) DEFAULT NULL,
  `apply_end` int(11) DEFAULT NULL,
  `apply_weixin` int(1) NOT NULL DEFAULT '0',
  `apply_video` int(1) NOT NULL DEFAULT '0',
  `apply_audit` int(1) NOT NULL DEFAULT '0',
  `apply_image` int(1) NOT NULL DEFAULT '3',
  `apply_help` varchar(255) NOT NULL,
  `vote_app` int(1) NOT NULL DEFAULT '0',
  `vote_app_scale` int(11) NOT NULL DEFAULT '0',
  `vote_date` varchar(20) NOT NULL,
  `vote_ip` varchar(255) NOT NULL,
  `vote_rule` varchar(255) NOT NULL,
  `vote_share` int(5) NOT NULL DEFAULT '1',
  `vote_verify` int(1) NOT NULL DEFAULT '0',
  `vote_rank` int(11) NOT NULL DEFAULT '100',
  `vote_start` int(11) DEFAULT NULL,
  `vote_end` int(11) DEFAULT NULL,
  `content` text,
  `wx_content` text,
  `status` int(1) DEFAULT '0',
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `cdb_orange_vote_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(50) NOT NULL,
  `vote_id` int(11) DEFAULT NULL,
  `vote_item_id` int(11) DEFAULT NULL,
  `is_app` int(1) DEFAULT '0',
  `is_share` int(1) NOT NULL DEFAULT '0',
  `number` int(11) DEFAULT NULL,
  `share_number` int(11) NOT NULL DEFAULT '0',
  `ip` varchar(20) NOT NULL,
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`vote_id`,`vote_item_id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `cdb_orange_vote_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) DEFAULT NULL,
  `vote_id` int(11) DEFAULT NULL,
  `title` varchar(50) NOT NULL,
  `serial_number` int(10) DEFAULT '0',
  `image` text,
  `video` varchar(255) NOT NULL,
  `options` text NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  `status` int(1) DEFAULT '0',
  `poll_num` int(11) DEFAULT '0',
  `view_num` int(11) DEFAULT '0',
  `ip` varchar(20) NOT NULL,
  `fail` varchar(255) NOT NULL,
  `add_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`vote_id`)
) ENGINE=MyISAM;


EOF;

runquery($sql);

$finish = TRUE;

?>