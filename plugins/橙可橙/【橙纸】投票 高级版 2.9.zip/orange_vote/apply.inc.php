<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
    if(!defined('IN_DISCUZ')) {
      exit('Access Denied');
    }
    $uid = $_G['uid'];
    $siteurl = $_G['siteurl'];
    $username = $_G['username'];
    $act = addslashes($_GET['act']);
    $lang = lang('plugin/orange_vote');
    $orange_vote = $_G['cache']['plugin']['orange_vote'];
    require_once dirname(__FILE__) . '/orange_vote.class.php';
    $isWeixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;

    $RandShareHost = array_filter(explode("\r\n",$orange_vote['site_share_host']));
    $RandShareHost[] = $siteurl;
    $ShareHost = $RandShareHost[array_rand($RandShareHost)];
    if( $isWeixin && in_array($act,array('')) && $orange_vote['site_appid'] && $orange_vote['site_appsecret']){
      require_once dirname(__FILE__) . '/orange_share.class.php';
      $WxShare = new OrangeShare($orange_vote['site_appid'],$orange_vote['site_appsecret']);
      $ShareConfig = $WxShare->getSignPackage();
    }

    $isMobile = checkmobile();
    if( !$isMobile ){
      include template('orange_vote:index');exit;
    }
    
    /*首页*/
    if( !$act ){
      // 报名页面
      $vote_id = dintval($_GET['vote_id']);
      
      C::t('#orange_vote#vote')->inc_vote_visit_number($vote_id);
      $vote = C::t('#orange_vote#vote')->get_vote_first($vote_id);

      $orange_vote['site_name'] = $vote['title'];
      $vote['slogan'] = implode('","',array_filter(explode("\r\n",$vote['slogan'])));
      $vote['apply_option'] = unserialize($vote['apply_option']);
      $vote['slides'] = explode("\r\n",$vote['slides']);
      $vote['slides'] = array_map(function ($v) {
        $v = explode('|',$v);
        return array('img'=>$v[0],'url'=>$v[1]);
      },$vote['slides']);

      $ThisDate = $_G['timestamp'];
      $startDate = $vote['apply_start'];
      $endDate = $vote['apply_end'];
      
      if( $uid ){
        $is_apply = C::t('#orange_vote#vote_user')->get_user_exist($vote_id,$uid);
        if( $is_apply['status'] ){
          dheader('location:plugin.php?id=orange_vote&act=detail&vote_id='.$vote_id.'&vote_item_id='.$is_apply['id']);
        }
      }

      include template('orange_vote:apply');
    }else if( $act == 'publish' ){
      // 提交报名
      $vote_id = dintval($_GET['vote_id']);
      if( !$uid || !$vote_id || FORMHASH != $_GET['formhash']){
        OrangeVote::output(-1);
      }
      $vote = C::t('#orange_vote#vote')->get_vote_first($vote_id);
      $is_apply = C::t('#orange_vote#vote_user')->get_user_exist($vote_id,$uid);
      
      if( !$vote ){
        OrangeVote::output(-1);
      }else if( OrangeVote::CheckIP($vote['vote_ip']) ){
        OrangeVote::output(-2);
      }
      
      $vote['apply_option'] = unserialize($vote['apply_option']);
      $last_user = C::t('#orange_vote#vote_user')->get_last_user($vote_id);

      $options = array();
      $apply_option = OrangeVote::check_array($_GET['apply_option'],0);
      
      foreach( $vote['apply_option']['name'] as $key=>$name ){
        $options[] = array(
          'name'=>$name,
          'value'=>$apply_option[$key],
          'show'=>$vote['apply_option']['show'][$key]
        );
      }
      
      $data['uid'] = $uid;
      $data['vote_id'] = $vote_id;
      $data['title'] = $apply_option[0];
      $data['content'] = $apply_option[1];
      $data['add_time'] = $_G['timestamp'];
      $data['ip'] = $_SERVER['REMOTE_ADDR'];
      $data['status'] = $vote['apply_audit'];
      $data['options'] = serialize($options);
      $data['image'] = implode(',',$_GET['image']);
      $data['serial_number'] = $last_user['serial_number']+1;
      if( $_GET['video'] ){
        $data['video'] = $_GET['video'];
      }
      if( $is_apply ){
        unset($data['add_time']);
        unset($data['serial_number']);
        $res = C::t('#orange_vote#vote_user')->update($data,array('id'=>$is_apply['id']));
      }else{
        $res = C::t('#orange_vote#vote_user')->insert($data);
        if( $res ){
          C::t('#orange_vote#vote')->inc_vote_attend_user($vote_id);
        }
      }

      OrangeVote::output($res);
    }else if( $act == 'upload' ){
      if( !$uid || FORMHASH != $_GET['formhash']){
        OrangeVote::output(0);
      }
      if( $_FILES['Filedata']['tmp_name'] ) {
        require_once dirname(__FILE__) . '/vote_upload.class.php';
        $path = OrangeVote::upload('',$_FILES['Filedata']);
      }
      OrangeVote::output(0,$path);
  }else if( $act == 'cross-domain' ){
    $url = addslashes($_GET['path']);
    $suffix = array('jpg','jpeg','png','gif','webp');
    $fileSuffix = strtolower(end(explode('.',$url)));
    if( in_array($fileSuffix,$suffix) ){
        $img = file_get_contents($url,true);
        header("Content-Type: image/jpeg;text/html; charset=utf-8");
        echo $img;exit;
    }else{
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $img = curl_exec($ch);
        header("Content-Type: image/jpeg;text/html; charset=utf-8");
        echo $img;exit;
    }
  }
    
?>