<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
    if(!defined('IN_DISCUZ')) {
      exit('Access Denied');
    }
    $pageSize = 20;
    $uid = $_G['uid'];
    $siteurl = $_G['siteurl'];
    $username = $_G['username'];
    $act = addslashes($_GET['act']);
    $lang = lang('plugin/orange_vote');
    $orange_vote = $_G['cache']['plugin']['orange_vote'];
    $isWeixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;

    $RandShareHost = array_filter(explode("\r\n",$orange_vote['site_share_host']));
    $RandShareHost[] = $siteurl;
    $ShareHost = $RandShareHost[array_rand($RandShareHost)];
    if( $isWeixin && in_array($act,array('','detail','info')) && $orange_vote['site_appid'] && $orange_vote['site_appsecret'] ){
      require_once dirname(__FILE__) . '/orange_share.class.php';
      $WxShare = new OrangeShare($orange_vote['site_appid'],$orange_vote['site_appsecret']);
      $ShareConfig = $WxShare->getSignPackage();
    }

    $isMobile = checkmobile();
    if( !$isMobile ){
      include template('orange_vote:index');exit;
    }
    
    if( !$act ){
      // 投票首页
      $vote_id = dintval($_GET['vote_id']);
      $keywords = daddslashes($_GET['keywords']);

      C::t('#orange_vote#vote')->inc_vote_visit_number($vote_id);
      $vote = C::t('#orange_vote#vote')->get_vote_first($vote_id);

      if( !$vote ){
        // 投票不存在时跳转论坛首页
        dheader('location:'.$siteurl);
      }

      $orange_vote['site_name'] = $vote['title'];
      $vote['slides'] = explode("\r\n",$vote['slides']);
      $vote['slides'] = array_map(function ($v) {
        $v = explode('|',$v);
        return array('img'=>$v[0],'url'=>$v[1]);
      },$vote['slides']);

      $vote_user = array_map(function ( $v ){
        $v['image'] = current(explode(',',$v['image']));
        return $v;
      },C::t('#orange_vote#vote_user')->get_user_list(0,$pageSize,array('orderBy'=>1,'vote_id'=>$vote_id,'status'=>1,'keywords'=>$keywords)));

      $ThisDate = $_G['timestamp'];
      $startApplyDate = $vote['apply_start'];
      $endApplyDate = $vote['apply_end'];

      if( $ThisDate < $vote['vote_start'] ){
        $dateText = $lang['h_count_down_1'];
        $dataTime = $vote['vote_start'];
      }else if( $ThisDate < $vote['vote_end'] ){
        $dateText = $lang['h_count_down_2'];
        $dataTime = $vote['vote_end'];
      }

      include template('orange_vote:index');
    }else if( $act == 'detail' ){
      // 选手详情页
      $vote_id = dintval($_GET['vote_id']);
      $vote_item_id = dintval($_GET['vote_item_id']);
      C::t('#orange_vote#vote')->inc_vote_visit_number($vote_id);
      $vote = C::t('#orange_vote#vote')->get_vote_first($vote_id);

      if( !$vote ){
        // 投票不存在时跳转论坛首页
        dheader('location:'.$siteurl);
      }

      $orange_vote['site_name'] = $vote['title'];
      $user = C::t('#orange_vote#vote_user')->get_user_first($vote_item_id);
      C::t('#orange_vote#vote_user')->inc_view_num($vote_item_id);
      $pre_user = C::t('#orange_vote#vote_user')->get_user_distance($vote_id,$user['poll_num']);

      $user['poll_distance'] = max(1,$pre_user['poll_num'] - $user['poll_num']);
      $user['poll_rank'] = C::t('#orange_vote#vote_user')->get_user_rank($vote_id,$user['poll_num']) +1;
      $user['image'] = explode(',',$user['image']);
      $shareDesc = $lang['h_share_temp'];
      $shareDesc = str_replace('name',$user['title'],$shareDesc);
      $shareDesc = str_replace('vote',$vote['title'],$shareDesc);

      $shareImage = $user['image'][0];

      include template('orange_vote:detail');
    }else if( $act == 'ajax_page' ){
      // 分页加载
      $page = dintval($_GET['page']);
      $vote_id = dintval($_GET['vote_id']);
      $keywords = daddslashes($_GET['keywords']);

      $vote_user = array_map(function ( $v ){
        $v['image'] = current(explode(',',$v['image']));
        return $v;
      },C::t('#orange_vote#vote_user')->get_user_list($page * $pageSize,$pageSize,array('orderBy'=>1,'vote_id'=>$vote_id,'status'=>1,'keywords'=>$keywords)));

      include template('orange_vote:ajax');
    }else if( $act == 'info' ){
      $vote_id = dintval($_GET['vote_id']);
      C::t('#orange_vote#vote')->inc_vote_visit_number($vote_id);
      $vote = C::t('#orange_vote#vote')->get_vote_first($vote_id);

      if( !$vote ){
        // 投票不存在时跳转论坛首页
        dheader('location:'.$siteurl);
      }

      $orange_vote['site_name'] = $vote['title'];
      $vote['slides'] = explode("\r\n",$vote['slides']);
      $vote['slides'] = array_map(function ($v) {
        $v = explode('|',$v);
        return array('img'=>$v[0],'url'=>$v[1]);
      },$vote['slides']);
      
      include template('orange_vote:info');
    }else if( $act == 'vote' ){
      // 投票
      require_once dirname(__FILE__) . '/orange_vote.class.php';
      require_once dirname(__FILE__) . '/human_verification.class.php';

      if( !$uid || FORMHASH != $_GET['formhash'] ){
        // 未登录
        OrangeVote::output(0);
      }

      $ThisDate = $_G['timestamp'];
      $isApp = OrangeVote::isApp();
      $vote_item_id = dintval($_GET['vote_item_id']);

      $user = C::t('#orange_vote#vote_user')->get_user_first($vote_item_id);
      $vote = C::t('#orange_vote#vote')->get_vote_first($user['vote_id']);
      $vote['vote_rule'] = unserialize($vote['vote_rule']);

      if( OrangeVote::CheckIP($vote['vote_ip']) ){
        OrangeVote::output(-2);
      }

      // 人机验证
      $HumanVerification = new HumanVerification();
      if( $vote['vote_verify'] && !$HumanVerification->check($_GET['verify']) ){
        // 验证失败
        OrangeVote::output(-1);
      }

      if( !$vote || !$vote['status'] || !$user['status'] ){
        // 投票不存在或已关闭
        OrangeVote::output(1);
      }else if( $ThisDate < $vote['vote_start'] ){
        // 未到投票时间
        OrangeVote::output(2);
      }else if( $ThisDate > $vote['vote_end'] ){
        // 已过投票时间
        OrangeVote::output(3);
      }else if( $vote['vote_app'] && !$isApp ){
        // app内投票
        OrangeVote::output(4);
      }else if( OrangeVote::CheckDate($vote['vote_date']) ){
        // 投票直接需在投票时间段内
        OrangeVote::output(-3,$vote['vote_date']);
      }

      // 当天时间戳
      $start = strtotime(date('Y-m-d',$_G['timestamp']));
      $end = strtotime('+1 day',$start);

      // 组合查询投票数量条件
      $voteWhere = array('vote_id'=>$vote['id'],'uid'=>$uid,'add_time'=>array($start,$end));
      if( $vote['vote_rule']['type'] == 2 ){
        $voteWhere['vote_item_id'] = $vote_item_id;
      }else if( $vote['vote_rule']['type'] == 3 ){
        unset($voteWhere['add_time']);
      }
      // 获取当天投票数量
      $voteNumber = C::t('#orange_vote#vote_record')->get_record_count($voteWhere);
      $vote_rule_number = max(1,(int)$vote['vote_rule']['number']);
      // 验证投票规则
      if( $vote['vote_rule']['type'] == 1 && $voteNumber >= 1 ){
        OrangeVote::output(5);
      }else if( $vote['vote_rule']['type'] == 2 && $voteNumber >= $vote_rule_number ){
        OrangeVote::output(6,$vote_rule_number);
      }else if( $vote['vote_rule']['type'] == 3 && $voteNumber >= 1 ){
        OrangeVote::output(9);
      }
      $incNumber = 1;
      if( $isApp ){
        $incNumber = 1 * max(1,(int)$vote['vote_app_scale']);
      }
      $u = DB::fetch_first("SELECT * FROM %t WHERE uid=%d",array('common_member_status',$uid));
      $data['uid'] = $uid;
      $data['is_app'] = $isApp;
      $data['ip'] = $u['lastip'];
      $data['number'] = $incNumber;
      $data['username'] = $username;
      $data['vote_id'] = $vote['id'];
      $data['add_time'] = $_G['timestamp'];
      $data['vote_item_id'] = $vote_item_id;

      $res = C::t('#orange_vote#vote_record')->insert( $data );
      if( $res ){
        C::t('#orange_vote#vote')->inc_vote_number($vote['id'],$incNumber);
        C::t('#orange_vote#vote_user')->inc_poll_num($vote_item_id,$incNumber);
        OrangeVote::output(7,$incNumber,$vote['vote_app_scale'],$vote['vote_share']);
      }else{
        OrangeVote::output(8);
      }
    }else if( $act == 'verification' ){
      require_once dirname(__FILE__) . '/human_verification.class.php';
      $HumanVerification = new HumanVerification();
      $VerificationImg = $HumanVerification->creat();
      echo $VerificationImg;exit;
    }else if( $act == 'share' ){
       // 分享加票
      require_once dirname(__FILE__) . '/orange_vote.class.php';

      if( !$uid || FORMHASH != $_GET['formhash'] ){
        // 未登录
        OrangeVote::output(0);
      }

      $ThisDate = $_G['timestamp'];
      $isApp = OrangeVote::isApp();
      $vote_item_id = dintval($_GET['vote_item_id']);

      $user = C::t('#orange_vote#vote_user')->get_user_first($vote_item_id);
      $vote = C::t('#orange_vote#vote')->get_vote_first($user['vote_id']);

      if( OrangeVote::CheckIP($vote['vote_ip']) ){
        OrangeVote::output(-2);
      }

      if( !$vote || !$vote['status'] || !$user['status'] ){
        // 投票不存在或已关闭
        OrangeVote::output(1);
      }else if( $ThisDate < $vote['vote_start'] ){
        // 未到投票时间
        OrangeVote::output(2);
      }else if( $ThisDate > $vote['vote_end'] ){
        // 已过投票时间
        OrangeVote::output(3);
      }else if( !$isApp ){
        // 不是在app内分享
        OrangeVote::output(4);
      }else if( OrangeVote::CheckDate($vote['vote_date']) ){
        // 投票直接需在投票时间段内
        OrangeVote::output(-3,$vote['vote_date']);
      }

      // 当天时间戳
      $start = strtotime(date('Y-m-d',$_G['timestamp']));
      $end = strtotime('+1 day',$start);

      // 组合查询投票数量条件
      $voteWhere = array('vote_id'=>$vote['id'],'uid'=>$uid,'add_time'=>array($start,$end),'is_share'=>0,'vote_item_id'=>$vote_item_id);
      // 获取当天投票数量
      $voteRecord = C::t('#orange_vote#vote_record')->get_record_list(0,1,$voteWhere);
      $voteRecord = count($voteRecord) ? $voteRecord[0] : null;
      if( !$voteRecord ){
        OrangeVote::output(6);
      }
      $incNumber = $vote['vote_share'];
      $res = C::t('#orange_vote#vote_record')->update(array('is_share'=>1,'share_number'=>$incNumber),array('id'=>$voteRecord['id']));
      if( $res ){
        C::t('#orange_vote#vote')->inc_vote_number($vote['id'],$incNumber);
        C::t('#orange_vote#vote_user')->inc_poll_num($vote_item_id,$incNumber);
        OrangeVote::output(5,$incNumber);
      }
    }
    
?>