<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_vote_record extends discuz_table{
    public function __construct() {
        $this->_table = 'orange_vote_record';
        $this->_pk = 'id';
        parent::__construct();
    }
    
    /*
     * 返回用户统计数量
     */
    public function get_record_count($where=array()){
        $sql = "SELECT count(*) as count FROM %t WHERE 1";
        $condition[] = $this->_table;
        
        if( $where['uid'] ){
          $sql .=" AND uid = %d ";
          $condition[] = $where['uid'];
        }
        if( $where['vote_id'] ){
          $sql .=" AND vote_id = %d ";
          $condition[] = $where['vote_id'];
        }
        if( $where['vote_item_id'] ){
          $sql .=" AND vote_item_id = %d ";
          $condition[] = $where['vote_item_id'];
        }
        if( $where['is_app'] > -1 ){
          $sql .=" AND is_app = %d ";
          $condition[] = $where['is_app'];
        }
        if( $where['is_share'] > -1 ){
          $sql .=" AND is_share = %d ";
          $condition[] = $where['is_share'];
        }
        if( $where['add_time'] ){
          $sql .=" AND add_time > %d AND add_time < %d ";
          $condition[] = $where['add_time'][0];
          $condition[] = $where['add_time'][1];
        }
        
        $count = DB::fetch_first($sql,$condition);
        return $count['count'];
    }
    
    /*
     * $limit 获取多少条分类 (0为全部)
     * $status 分类状态 (0为全部，1开启)
     * 返回指定数量的分类集合
     */
    public function get_record_list( $start=0,$size=0,$where=array() ){
        $sql = "SELECT * FROM %t WHERE 1";
        $condition[] = $this->_table;
        
        if( $where['uid'] ){
          $sql .=" AND uid = %d ";
          $condition[] = $where['uid'];
        }
        if( $where['vote_id'] ){
          $sql .=" AND vote_id = %d ";
          $condition[] = $where['vote_id'];
        }
        if( $where['vote_item_id'] ){
          $sql .=" AND vote_item_id = %d ";
          $condition[] = $where['vote_item_id'];
        }
        if( $where['is_app'] > -1 ){
          $sql .=" AND is_app = %d ";
          $condition[] = $where['is_app'];
        }
        if( $where['is_share'] > -1 ){
          $sql .=" AND is_share = %d ";
          $condition[] = $where['is_share'];
        }
        if( $where['add_time'] ){
          $sql .=" AND add_time > %d AND add_time < %d ";
          $condition[] = $where['add_time'][0];
          $condition[] = $where['add_time'][1];
        }

        $sql .=" ORDER BY add_time desc LIMIT %d,%d";
        $condition[] = $start;
        $condition[] = $size;
        
        return DB::fetch_all($sql,$condition);
    }
    
    
    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_record_first( $id ){
        return DB::fetch_first("SELECT * FROM %t WHERE id=%d",array($this->_table,$id));
    }

    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_record_rank( $poll_num ){
      return current(DB::fetch_first("SELECT count(*) as count FROM %t WHERE poll_num>=%d order by add_time asc",array($this->_table,$poll_num)));
    }

    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_record_distance( $poll_num ){
      return DB::fetch_first("SELECT * FROM %t WHERE poll_num>%d order by add_time desc",array($this->_table,$poll_num));
    }

    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_last_record( $vote_id ){
      return DB::fetch_first("SELECT * FROM %t WHERE vote_id=%d ORDER BY id desc",array($this->_table,$vote_id));
  }
    
    /*
     * $data 分类信息数据
     * 返回插入的id
     */
    public function insert( $data ){
        return DB::insert($this->_table, $data,true);
    }
    
    /*
     * $data 分类更新数据
     * $condition 更新条件
     * 返回更新id 
     */
    public function update( $data,$condition ){
        return DB::update($this->_table, $data,$condition,true);
    }
    
    /*
     * $condition删除分类条件
     */
    public function delete( $condition ){
        return DB::delete($this->_table, $condition);
    }
    
	

}
//From: Dism_taobao-com
?>