<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Aecsse Denied');
}
class table_share extends discuz_table{
    public function __construct() {
        $this->_table = 'orange_share';
        $this->_pk = 'id';
        parent::__construct();
    }
    
    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_byid_share( $id ){
      return DB::fetch_first("SELECT * FROM %t WHERE id=%d",array($this->_table,$id));
    }

    /*
     * $id 获取指定ID的分类
     * 返回一条分类
     */
    public function get_byappid_share( $appid ){
      return DB::fetch_first("SELECT * FROM %t WHERE appid=%d",array($this->_table,$appid));
    }
    
    /*
     * $data 分类信息数据
     * 返回插入的id
     */
    public function insert( $data ){
        return DB::insert($this->_table, $data,true);
    }
    
    /*
     * $data 分类更新数据
     * $condition 更新条件
     * 返回更新id 
     */
    public function update( $data,$condition ){
        return DB::update($this->_table, $data,$condition,true);
    }
    
    /*
     * $condition删除分类条件
     */
    public function delete( $condition ){
        return DB::delete($this->_table, $condition);
    }
    
	

}
//From: Dism_taobao-com
?>