<?php

/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is gold plugin
 *
 *      install.php 2016-07-21 20:49 41Z gold 
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) exit('Access Denied!');

// ALTER TABLE `pre_orange_vote` ADD `apply_video` INT(1) NOT NULL DEFAULT '0' AFTER `apply_weixin`;
// ALTER TABLE `pre_orange_vote` ADD `apply_help` VARCHAR(255) NOT NULL AFTER `apply_image`;
// ALTER TABLE `pre_orange_vote_user` ADD `fail` VARCHAR(255) NOT NULL AFTER `ip`;

$sql = <<<EOF
  ALTER TABLE `pre_orange_vote` ADD `wx_content` TEXT NOT NULL AFTER `content`;
EOF;

runquery($sql);

$finish = TRUE;

?>