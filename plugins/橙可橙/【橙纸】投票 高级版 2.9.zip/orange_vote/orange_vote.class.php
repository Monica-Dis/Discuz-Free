<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class OrangeVote {
	
    const PLUGIN_ID = 'orange_vote';
    
    /*
     * 初始化数据，select使用的正确数据格式
     * $data 二维数组
     * $field1 第一个字段名
     * $field2 第二个字段名
     * 返回 二维数组
     */
    public static function initial_data( $data=array(),$field1='',$field2='',$type=1 ){
        $arr = array();
        foreach( $data as $val ){
            switch( $type ){
                case 1:
                    $arr[$val[$field1]] = $val[$field1];
                    break;
                case 2:
                    $arr[$val[$field1]] = $val[$field2];
                    break;
                case 3:
                    $arr[$val[$field1]][] = $val[$field2];
                    break;
                case 4:
                    $arr[$val[$field1]] = array($val[$field1],$val[$field2]);
                    break;
                case 5:
                    $arr[$val[$field1]][] = $val;
                    break;
                case 6:
                    $arr[$val[$field1]] = $val;
                    break;
                default:
                    break;
            }
        }
        return $arr;
    }
    
    public static function initial_cont( $data ){
    	$cont = "";
    	$data = unserialize($data);
    	foreach( $data['name'] as $key=>$val ){
    		$cont .= $val." : ".$data['val'][$key]."<br>";
    	}
    	return $cont;
    }
    
    /*
     * 数组参数拼接
     * 用于分页时的参数传递
     */
    public static function param_join( $data ){
        $param_data = array();
        foreach( $data as $key=>$val ){
            $param_data[] = $key.'='.$val;
        }
        return implode('&',$param_data);
    }
    
    
    /*
     * 语言包转换中文编码
     * $charset 编码
     * $lang 中文语言
     * 返回转码后的中文
     */
    public static function convert_lang( $charset,$lang ){
        if( strpos($charset,'g')!==false ){
            $lang = iconv('GB2312','UTF-8',$lang);
        }
        return $lang;
    }
    
    
    /*
     * 中文自动转码
     */
    public static function auto_iconv( $lang ){
        global $_G;
        return mb_convert_encoding($lang,$_G['charset'],'auto');
    }
    
    /*
     * 生成select元素html结构
     * $name select的name属性和id属性值
     * $data select所需要的数据
     * $selected select选中的项
     * $initial 如果存在的时候会创建一个初始化的option
     * 返回生成好的select元素html代码
     */
    public static function create_select($name='',$data=array(),$selected='',$initial=array()){
        $select = '<select name="'.$name.'" id="'.$name.'">';
        if( $initial ){
            $select .= '<option value="'.$initial[0].'">'.$initial[1].'</option>';
        }
        foreach( $data as $val ){
            $sed = $selected==$val[0]?'selected':'';
            $select .= '<option value="'.$val[0].'" '.$sed.'>'.$val[1].'</option>';
        }
        $select .= "</select>";
        return $select;
    }
    
    /*
     * 上传图片
     * $basepath
     * $FILE 传入单个文件
     * 返回上传成功后的文件地址
     */
    public static function upload( $basepath='',$FILE ){
        
        if($FILE['tmp_name']) {
            $upload = new vote_upload();
            if(!$upload->init($FILE, 'orange_vote','vote_upload', random(8)) || !$upload->save()) {
                $pic = '';
            }
            $pic = $basepath.$upload->attach['attachment'];
        } else {
            $pic = '';
        }
        return $pic;
    }
    
    /*
     * 数组过滤，过滤非法数据
     * $types 过滤函数（自定义函数先进行声明）
     * array_map 对数组的每一项进行过滤
     * 返回过滤后的数据
     */
    
    public static function check_array( $array,$type=0 ){
        $types = array(
            '0'=>'addslashes',
            '1'=>'intval',
            '2'=>'strtotime',
            '3'=>'dhtmlspecialchars',
            '4'=>'auto_iconv'
            );
        return array_map($types[$type],$array);
    }
   	/*
     * 输出json提示信息
     */
    public static function output($success=0, $msg='',$id=0,$status=0) {
      $data['success'] = $success;
      $data['message'] = $msg;
      $data['id'] = $id;
      $data['status'] = $status;
      echo json_encode($data);
      exit;
    }

    /*
     * 判断是否为app
     */
    public static function isApp() {
      $isXiaoyun = strpos($_SERVER['HTTP_USER_AGENT'], 'Appbyme') !== false;
      $isMagappx = strpos($_SERVER['HTTP_USER_AGENT'], 'MAGAPPX') !== false;
      $isQianfan = strpos($_SERVER['HTTP_USER_AGENT'], 'QianFan') !== false;
      return $isXiaoyun || $isMagappx || $isQianfan;
    }

    /**
     * 检测IP是否在禁用
     */
    public static function CheckIP( $disables = '' ){
      $ip = $_SERVER['REMOTE_ADDR'];
      $disables = explode("\r\n",$disables);
      return count(array_filter($disables,function ($v) use ($ip){
        return strpos($ip,$v) === 0;
      }));
    }
    /**
     * 检测是否在投票时间段内
     */
    public static function CheckDate( $date ){
      $hours = date('H');
      if( empty($date) ){return false;}
      $date = explode('-',$date);
      return $hours < intval($date[0]) || $hours > intval($date[1]);
    }

    /*
	 * httpGet请求
	 */
	public static function HttpGet($url) {
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_TIMEOUT, 500);
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, true);
    curl_setopt($curl, CURLOPT_URL, $url);
    $res = curl_exec($curl);
    curl_close($curl);
    $res= json_decode($res, true);
    return $res;
  }
  /*
 * httpPost请求
 */
  public static function HttpPost($url, $data) {
      $ch = curl_init();
      curl_setopt($ch, CURLOPT_URL, $url);
      curl_setopt($ch, CURLOPT_POST, 1);
      curl_setopt($ch, CURLOPT_HEADER, 0);
      curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
      curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
      $return = curl_exec($ch);
      curl_close($ch);
      $result= json_decode($return, true);
      return $return;
 }

}