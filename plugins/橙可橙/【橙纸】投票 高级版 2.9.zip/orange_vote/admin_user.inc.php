<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
    if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
        exit('Access Denied');
    }
    $lang = lang('plugin/orange_vote');
    $act = dhtmlspecialchars($_GET['act']);
    require_once dirname(__FILE__) . '/orange_vote.class.php';
    
    /*列表展示*/
    if( !$act ){
    	$perpage = max(20, empty($_GET['perpage']) ? 20 : intval($_GET['perpage']));
      $start_limit = ($page - 1) * $perpage;
      
      $condition['vote_id'] = intval($_GET['vote_id']);
      $condition['keywords'] = addslashes($_GET['keywords']);
      $condition['status'] = isset($_GET['status'])?intval($_GET['status']):-1;
      $public_param = "&".OrangeVote::param_join($condition);

		  $count = C::t('#orange_vote#vote_user')->get_user_count($condition);
      $mpurl = ADMINSCRIPT."?action=plugins&operation=config&do=".$pluginid."&identifier=orange_vote&pmod=admin_user".$public_param;
		  $multipage = multi($count, $perpage, $page, $mpurl, 0, 3);
      $vote_list = C::t('#orange_vote#vote_user')->get_user_list($start_limit,$perpage,$condition);

      $status_select = OrangeVote::create_select('status',array(array(0,$lang['a_cs_status_0']),array(1,$lang['a_cs_status_1'])),$condition['status'],array(-1,$lang['a_all']));

      echo <<<SEARCH
            <form method="post" autocomplete="off" id="tb_search" action="$url">
            <table style="padding:10px 0;">
                <tbody>
                    <tr>
                      <th><input type="hidden" name="vote_id" value="$condition[vote_id]"></th>
                        <th>$lang[a_cs_status]</th><td>$status_select</td>
                        <td><input type="text" class="txt" name="keywords" style="width:200px" value="$condition[keywords]" placeholder="$lang[h_search_user_tips]"></td>
                        <th></th><td><input type="submit" class="btn" value="$lang[a_search]"></td>
                    </tr>
                </tbody>
            </table>
            </form>
SEARCH;

		  showformheader('plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_user&act=del', 'enctype');
		  showtableheader();
		  echo    '<tr class="header"><th></th><th>'.
            'ID</th><th>UID</th><th>'.
				    $lang['a_serial_number'].'</th><th>'.
				    $lang['a_csmc'].'</th><th>'.
				    $lang['a_cs_content'].'</th><th>'.
				    $lang['a_cs_status'].'</th><th>'.
				    $lang['a_cs_poll_num'].'</th><th>'.
				    $lang['a_cs_view_num'].'</th><th>'.
				    $lang['a_cs_add_time'].'</th><th>'.
				    $lang['a_handle'].
                '</th><th></th></tr>';
		        foreach($vote_list as $list) {
	            $status = $list['status'] ? $lang['a_open'] : $lang['a_stop'];
	            echo'<tr class="hover">'.
	                '<th class="td25"><input class="checkbox" type="checkbox" name="delete['.$list['id'].']" value="'.$list['id'].'"></th>'.
	                '<th>'.$list['id'].'</th>'.
	                '<th>'.$list['uid'].'</th>'.
	                '<th>'.$list['serial_number'].'</th>'.
	                '<th>'.$list['title'].'</th>'.
	                '<th>'.$list['content'].'</th>'.
	                '<th>'.$status.'</th>'.
	                '<th>'.$list['poll_num'].'</th>'.
	                '<th>'.$list['view_num'].'</th>'.
	                '<th>'.date('Y-m-d h:i:s',$list['add_time']).'</th>'.
	                '<th><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_user&act=edit&id='.$list['id'].'">'.$lang['a_edit'].'</a> | <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_record&vote_item_id='.$list['id'].'">'.$lang['a_vote_record'].'</a></th>'.
	                '</tr>';
		      }
		  $add = '<input type="button" class="btn" onclick="location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_user&act=add&vote_id='.$condition['vote_id'].'\'" value="'.$lang['a_add'].'" />';
	
	    showsubmit('submit',$lang['a_del'], $condition['vote_id'] ? $add : '', '', $multipage);
	
      showtablefooter();/*Dism_taobao-com*/
      showformfooter();
    }
    /*添加分类*/
    else if( $act=='add' || $act=='edit' ){
        if( !submitcheck('submit') ) {
            $id = intval($_GET['id']);
            if( $id ){
              $user = C::t('#orange_vote#vote_user')->get_user_first($id);
              $vote_id = $user['vote_id'];
              $vote = C::t('#orange_vote#vote')->get_vote_first($vote_id);
              $vote['apply_option'] = unserialize($vote['apply_option']);
              $user['image'] = explode(',',$user['image']);
              $user['add_time'] = date('Y-m-d H:i:s',$user['add_time']);
              $user['options'] = unserialize($user['options']);
            }else{
              $vote_id = intval($_GET['vote_id']);
              $vote = C::t('#orange_vote#vote')->get_vote_first($vote_id);
              $vote['apply_option'] = unserialize($vote['apply_option']);
            }
            include template('orange_vote:admin_user');
        }else{
            $data = array();
            $id = intval($_GET['id']);
            $vote_id = intval($_GET['vote_id']);
            $image_count = intval($_GET['image_count']);
            require_once dirname(__FILE__) . '/vote_upload.class.php';
            $old_image = $_GET['image'] ? OrangeVote::check_array($_GET['image'],0) : array();
            
            $new_image = array();
            for( $i=0; $i< $image_count; $i++){
              $new_image[] =  OrangeVote::upload('',$_FILES['image_'.$i]);
            }
            
            foreach( $_GET['options'] as $val ){
              $options[] = $val;
            }
            
            $data['vote_id'] = $vote_id;
            $data['fail'] = $_GET['fail'];
            $data['title'] = $_GET['title'];
            $data['video'] = $_GET['video'];
            $data['content'] = $_GET['content'];
            $data['options'] = serialize($options);
            $data['status'] = intval($_GET['status']);
            $data['poll_num'] = intval($_GET['poll_num']);
            $data['view_num'] = intval($_GET['view_num']);
            $data['image'] = implode(',',array_merge($new_image,$old_image));
            
            if( $id ){
              C::t('#orange_vote#vote_user')->update($data,array('id'=>$id));
            }else{
              $last_user = C::t('#orange_vote#vote_user')->get_last_user($vote_id);
              $data['add_time'] = $_G['timestamp'];
              $data['serial_number'] = $last_user['serial_number']+1;
              C::t('#orange_vote#vote_user')->insert($data);
              C::t('#orange_vote#vote')->inc_vote_attend_user($vote_id);
            }
            C::t('#orange_vote#vote')->update(array(
              'vote_number'=>C::t('#orange_vote#vote_user')->get_user_vote_count($vote_id)
            ),array('id'=>$vote_id));
            cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_user', 'succeed');
        }
    }
    /*删除分类*/
    elseif($act == 'del') {
	    if(submitcheck('submit')) {
          foreach($_POST['delete'] as $delete) {
            $user = C::t('#orange_vote#vote_user')->get_user_first($delete);
            C::t('#orange_vote#vote_user')->delete(array('id'=>$delete));
            C::t('#orange_vote#vote')->dec_vote_attend_user($user['vote_id']);
          }
          cpmsg($lang['a_success_info'], 'action=plugins&operation=config&do='.$pluginid.'&identifier=orange_vote&pmod=admin_user', 'succeed');
      }

    }
//From: Dism_taobao-com
?>