<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
    if(!defined('IN_DISCUZ')) {
      exit('Access Denied');
    }
    $pageSize = 20;
    $uid = $_G['uid'];
    $siteurl = $_G['siteurl'];
    $username = $_G['username'];
    $act = addslashes($_GET['act']);
    $lang = lang('plugin/orange_vote');
    $orange_vote = $_G['cache']['plugin']['orange_vote'];
    $isWeixin = strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;


    $RandShareHost = array_filter(explode("\r\n",$orange_vote['site_share_host']));
    $RandShareHost[] = $siteurl;
    $ShareHost = $RandShareHost[array_rand($RandShareHost)];
    if( $isWeixin && in_array($act,array('')) && $orange_vote['site_appid'] && $orange_vote['site_appsecret'] ){
      require_once dirname(__FILE__) . '/orange_share.class.php';
      $WxShare = new OrangeShare($orange_vote['site_appid'],$orange_vote['site_appsecret']);
      $ShareConfig = $WxShare->getSignPackage();
    }

    $isMobile = checkmobile();
    if( !$isMobile ){
      include template('orange_vote:index');exit;
    }
    
    /*首页*/
    if( !$act ){

      $vote_id = dintval($_GET['vote_id']);
      $keywords = daddslashes($_GET['keywords']);

      C::t('#orange_vote#vote')->inc_vote_visit_number($vote_id);
      $vote = C::t('#orange_vote#vote')->get_vote_first($vote_id);

      if( !$vote ){
        // 投票不存在时跳转论坛首页
        dheader('location:'.$siteurl);
      }

      $orange_vote['site_name'] = $vote['title'];
      $vote['slides'] = explode("\r\n",$vote['slides']);
      $vote['slides'] = array_map(function ($v) {
        $v = explode('|',$v);
        return array('img'=>$v[0],'url'=>$v[1]);
      },$vote['slides']);

      $vote_user = array_map(function ( $v ){
        $v['image'] = current(explode(',',$v['image']));
        return $v;
      },C::t('#orange_vote#vote_user')->get_user_list(0,$pageSize,array('orderBy'=>1,'poll_num'=>1,'vote_id'=>$vote_id,'status'=>1,'keywords'=>$keywords)));

      $ThisDate = $_G['timestamp'];
      $endApplyDate = $vote['apply_end'];
      $startApplyDate = $vote['apply_start'];

      include template('orange_vote:rank');
    }else if( $act == 'ajax_page' ){
      $page = dintval($_GET['page']);
      $vote_id = dintval($_GET['vote_id']);
      $keywords = daddslashes($_GET['keywords']);
      $vote = C::t('#orange_vote#vote')->get_vote_first($vote_id);

      if( $page * $pageSize < $vote['vote_rank'] ){
        $vote_user = array_map(function ( $v ){
          $v['image'] = current(explode(',',$v['image']));
          return $v;
        },C::t('#orange_vote#vote_user')->get_user_list($page * $pageSize,$pageSize,array('orderBy'=>1,'poll_num'=>1,'vote_id'=>$vote_id,'status'=>1,'keywords'=>$keywords)));
      }

      include template('orange_vote:ajax-rank');
    }
    
?>