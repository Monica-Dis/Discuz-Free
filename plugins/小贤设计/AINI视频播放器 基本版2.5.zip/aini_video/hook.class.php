<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_aini_video {
	function discuzcode($arr) {
		require_once libfile('function/video','plugin/aini_video');
		global $_G;
		$aini = $_G['cache']['plugin']['aini_video'];
		if($arr['caller']=='discuzcode' && in_array($_G['fid'], unserialize($aini['forums']))){
			if (strpos(strtolower($_G['discuzcodemessage']), '[/media]') !== false) {
				$_G['discuzcodemessage'] = preg_replace_callback("/\[media(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/is", 'threadvideo', $_G['discuzcodemessage']);
			}
		}
	}
}
//From: Dism��taobao��com
?>