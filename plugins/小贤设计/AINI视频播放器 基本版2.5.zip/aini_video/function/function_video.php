<?php

 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function threadvideo($url) {
	global $_G;
	$aini = $_G['cache']['plugin']['aini_video'];
	$height = $aini['aini_pcgd'];
	$width = $aini['aini_pckd']?$aini['aini_pckd']:'100%';
	$mpic = $aini['aini_mp4pic'];
	$colour = $aini['aini_mp3bk'];
	$url = $url[2];
	$ifurl = strtolower($url);

	if (strpos($ifurl, 'v.qq.com/x/') !== FALSE) {//
		if (preg_match("/https:\/\/v.qq.com\/x\/page\/([^\/]+)(.html?)/i", $url, $arr)) {
			$src = 'https://v.qq.com/iframe/player.html?vid='.$arr[1].'&tiny=0&auto=0';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	
	if (strpos($ifurl, 'v.qq.com/txp/') !== FALSE) {//
		if (preg_match("/https:\/\/v.qq.com\/txp\/iframe\/([^\/]+)/i", $url, $arr)) {
			$src = 'https://v.qq.com/txp/iframe/'.$arr[1].'';
			return '<iframe frameborder="0" width="'.$width.'" height="'.$height.'" src="'.$src.'" allowFullScreen="true"></iframe>';
		}
	}

	if (strpos($ifurl, 'www.bilibili.com/video/') !== FALSE) {//
		if (preg_match("/https:\/\/www.bilibili.com\/video\/av([^\/]+)\//i", $url, $arr)) {
			$src = 'https://player.bilibili.com/player.html?aid='.$arr[1].'&page=1';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}
	
	if (strpos($ifurl, 'v.youku.com/v_show/') !== FALSE) {//
		if (preg_match("/[https|http]:\/\/v.youku.com\/v_show\/id_([^\/]+)(.html?)/i", $url, $arr)) {
			$src = 'https://player.youku.com/embed/'.$arr[1].'==';
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" frameborder="0" allowfullscreen></iframe>';
		}
	}

	if (strpos($ifurl, 'www.youtube.com/watch') !== FALSE) {//
		if (preg_match("/https:\/\/www.youtube.com\/watch\?v=([^\/]+)/i", $url, $arr)) {
			$src = 'https://www.youtube.com/embed/'.$arr[1];
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" allowfullscreen frameborder="0"></iframe>';
		}
	}

	if (strpos($url, 'www.wasu.cn/Play/show/') !== FALSE) {//		
		if (preg_match("/https:\/\/www.wasu.cn\/Play\/show\/id\/([^\/]+)/i", $url, $arr)) {
			$src = 'http://www.wasu.cn/Play/iframe/id/'.$arr[1];
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$src.'" frameborder=0 allowfullscreen></iframe>';
		}
	}
	
	if (strpos($url, 'tv.sohu.com/s/sohuplayer/') !== FALSE) {//
		return '<iframe frameborder="0" src="'.$url.'" width="'.$width.'" height="'.$height.'" allowFullScreen="true" scrolling="no"></iframe>';

	}
	
	if (strpos($url, 'tv.sohu.com/upload/static/share/') !== FALSE) {// 
		return '<iframe src="'.$url.'" width="'.$width.'" height="'.$height.'" frameborder="0" allowfullscreen=""></iframe>';

	}
	
	if (strpos($url, 'http://open.iqiyi.com/developer/player_js/') !== FALSE) {//
		return '<iframe frameborder="0" src="'.$url.'" width="'.$width.'" height="'.$height.'" allowFullScreen="true" scrolling="no"></iframe>';

	}
	
	if (strpos($url, 'https://v.douyu.com/video/share/') !== FALSE) {//
		return '<iframe src="'.$url.'" frameborder="0" allowfullscreen="true" height="'.$height.'" width="'.$width.'"></iframe>';

	}

	if (strpos($ifurl,'rbv01.ku6.com') !== FALSE) {//
		$videolink = '<link href="./source/plugin/aini_video/video/video-js.min.css" rel="stylesheet" type="text/css">'.'<script src="./source/plugin/aini_video/video/video.min.js"></script>'.'<style>.video-js{width:'.$width.' !important; height:'.$height.' !important;}</style>';
		return $videolink.'<video id="example_video_1" class="video-js vjs-default-skin" controls preload="none" poster="'.$mpic.'" data-setup="{}"><source src="'.$url.'" type="Video/mp4" /></video>';

	}
	
	if (strpos($url, 'www.tudou.com') !== FALSE) {
		$videolink = '<link href="./source/plugin/aini_video/video/video-js.min.css" rel="stylesheet" type="text/css">'.'<script src="./source/plugin/aini_video/video/video.min.js"></script>'.'<style>.video-js{width:'.$width.' !important; height:'.$height.' !important;}</style>';
		return $videolink.'<video id="example_video_1" class="video-js vjs-default-skin" controls preload="none" poster="'.$mpic.'" data-setup="{}"><source src="'.$url.'" type="Video/mp4" /></video>';

	}

	if (strpos($ifurl,'.mp4') || strpos($ifurl,'.webm') || strpos($ifurl,'.ogv') || strpos($ifurl,'.m3u8') !== FALSE) {//
		$videolink = '<link href="./source/plugin/aini_video/video/video-js.min.css" rel="stylesheet" type="text/css">'.'<script src="./source/plugin/aini_video/video/video.min.js"></script>'.'<style>.video-js{width:'.$width.' !important; height:'.$height.' !important;}</style>';
		return $videolink.'<video id="example_video_1" class="video-js vjs-default-skin" controls preload="none" poster="'.$mpic.'" data-setup="{}"><source src="'.$url.'" type="Video/mp4" /></video>';

	}

	if (strpos($ifurl,'.mp3') || strpos($ifurl,'.wav') || strpos($ifurl,'.ogg') || strpos($ifurl,'.m4a') !== FALSE) {//
		$videolink = '<link href="./source/plugin/aini_video/video/audio.css" rel="stylesheet" type="text/css">'.'<script src=" "></script>'.'<style>#aini-pcmp3{ background:'.$colour.';}audio{width:'.$width.' !important;}</style>';
		return $videolink.'<div id="aini-pcmp3"><audio src="'.$ifurl.'" preload="auto" controls></audio></div>';
	}
	if (!$return) {
		if($aini['spms']){
			return '<iframe width="'.$width.'" height="'.$height.'" src="'.$ifurl.'" allowfullscreen frameborder="0"></iframe>';
		}else{
			return '<a href="'.$ifurl.'">'.$ifurl.'</a>';
		}
	}
}
//From: Dism��taobao��com
?>