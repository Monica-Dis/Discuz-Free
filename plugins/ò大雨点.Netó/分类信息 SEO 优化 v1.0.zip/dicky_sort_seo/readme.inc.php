<?php
/*
	Name: 【Dicky】分类信息SEO优化
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
include dirname(__FILE__) . '/./common.func.php';
echo dss_pl('readme');
?>