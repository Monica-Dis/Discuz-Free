<?php
/*
	Name: 【Dicky】分类信息SEO优化
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_dicky_sort_seo {
    function common() {
        include dirname(__FILE__) . '/./common.func.php';
    }
}
class plugin_dicky_sort_seo_forum extends plugin_dicky_sort_seo {
    function forumdisplay_threadtype_extra_output() {
        global $_G, $quicksearchlist, $navtitle, $metakeywords, $metadescription;
        loadcache('plugin');
        $var = $_G['cache']['plugin']['dicky_sort_seo'];
        $position = (int)$var['position'];
        $separator = $var['separator'];
        $fids = (array)unserialize($var['fids']);
        if (in_array($_G['fid'], $fids)) {
            $sortChoices = '';
            foreach ($quicksearchlist as $k => $v) {
                if (isset($_GET[$v['identifier']]) && $_GET[$v['identifier']] !== 'all') {
                    if ($position) {
                        $sortChoices .= $separator . $v['choices'][$_GET[$v['identifier']]];
                    } else {
                        $sortChoices .= $v['choices'][$_GET[$v['identifier']]] . $separator;
                    }
                }
            }
            if ($position) {
                $navtitle .= $sortChoices;
                $metakeywords .= $sortChoices;
                $metadescription .= $sortChoices;
            } else {
                $navtitle = $sortChoices . $navtitle;
                $metakeywords = $sortChoices . $metakeywords;
                $metadescription = $sortChoices . $metadescription;
            }
        }
    }
}
?>