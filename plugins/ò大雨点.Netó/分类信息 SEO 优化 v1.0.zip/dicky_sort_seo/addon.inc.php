<?php
/*
	Name: 【Dicky】分类信息SEO优化
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
?>
<iframe src="http://Dism.Taobao.Com/?@3279.developer" frameborder="0" scrolling="no" style="width:100%;max-height:2000px;min-height:600px;_height:2000px"></iframe> 