<?php
/*
	Name: 【Dicky】分类信息SEO优化
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function dss_pl($str)
{
    return lang('plugin/dicky_sort_seo', $str);
}
?>