<?php
/*
	Name: 【Dicky】担保交易(Guarantee Transaction)
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}
$editorid = 'e';
$_G['setting']['editoroptions'] = str_pad(decbin($_G['setting']['editoroptions']), 2, 0, STR_PAD_LEFT);
$editormode = $_G['setting']['editoroptions']{0};
$allowswitcheditor = $_G['setting']['editoroptions']{1};
$editor = array(
    'editormode' => $editormode,
    'allowswitcheditor' => $allowswitcheditor,
    'allowhtml' => 1,
    'allowhtml' => 1,
    'allowsmilies' => 1,
    'allowbbcode' => 1,
    'allowimgcode' => 1,
    'allowcustombbcode' => 0,
    'allowresize' => 1,
    'textarea' => 'message',
    'simplemode' => !isset($_G['cookie']['editormode_'.$editorid]) ? 1 : $_G['cookie']['editormode_'.$editorid],
    'value' => $theValue['content']
);
loadcache('bbcodes_display');
require_once libfile('function/upload');
$swfconfig = getuploadconfig($_G['uid'], $_G['fid']);
$imgexts = str_replace(array(';', '*.'), array(', ', ''), $swfconfig['imageexts']['ext']);
$allowuploadnum = $allowuploadtoday = TRUE;
if($_G['group']['allowpostattach'] || $_G['group']['allowpostimage']) {
    if($_G['group']['maxattachnum']) {
        $allowuploadnum = $_G['group']['maxattachnum'] - getuserprofile('todayattachs');
        $allowuploadnum = $allowuploadnum < 0 ? 0 : $allowuploadnum;
        if(!$allowuploadnum) {
            $allowuploadtoday = false;
        }
    }
    if($_G['group']['maxsizeperday']) {
        $allowuploadsize = $_G['group']['maxsizeperday'] - getuserprofile('todayattachsize');
        $allowuploadsize = $allowuploadsize < 0 ? 0 : $allowuploadsize;
        if(!$allowuploadsize) {
            $allowuploadtoday = false;
        }
        $allowuploadsize = $allowuploadsize / 1048576 >= 1 ? round(($allowuploadsize / 1048576), 1).'MB' : round(($allowuploadsize / 1024)).'KB';
    }
}
$allowpostimg = $_G['group']['allowpostimage'] && $imgexts;
$enctype = ($_G['group']['allowpostattach'] || $_G['group']['allowpostimage']) ? 'enctype="multipart/form-data"' : '';
$maxattachsize_mb = $_G['group']['maxattachsize'] / 1048576 >= 1 ? round(($_G['group']['maxattachsize'] / 1048576), 1).'MB' : round(($_G['group']['maxattachsize'] / 1024)).'KB';