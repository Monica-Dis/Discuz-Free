<?php
/*
	Name: 【Dicky】担保交易(Guarantee Transaction)
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_plugin_dicky_guarantee_transaction extends discuz_table {
    public function __construct() {
        $this->_table = 'plugin_dicky_guarantee_transaction';
        $this->_pk = 'id';
        parent::__construct();
    }

    public function fetch_all($where, $order = null, $start = 0, $limit = null, $count = 0) {
        $ordersql = $order !== null && !empty($order) ? ' ORDER BY ' . $order : '';
        if ($where) $whereSql = " WHERE $where";
        if ($limit != null) $limitSql = ' ' . DB::limit($start, $limit);
		if($count) {
			return DB::result_first("SELECT COUNT(*) FROM ".DB::table($this->_table)." $whereSql");
		}
		else {
			$sql = 'SELECT * FROM %t ' . $whereSql . $ordersql . $limitSql;
			return DB::fetch_all($sql, array($this->_table));
		}
    }

    public function fetch_by_id($id) {
        if(!empty($id)) {
            return DB::fetch_first('SELECT * FROM %t WHERE '.DB::field('id', $id), array($this->_table));
        }
        return array();
    }
}
//From: Dism·taobao·com
?>