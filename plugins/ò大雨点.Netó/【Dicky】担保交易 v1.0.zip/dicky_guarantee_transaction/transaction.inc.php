<?php
/*
	Name: 【Dicky】担保交易(Guarantee Transaction)
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
require dirname(__FILE__) . '/./common.func.php';
$var = $_G['cache']['plugin']['dicky_guarantee_transaction'];
$submod = $_GET['submod'] ? trim($_GET['submod']) : 'guarantee_apply';
$subop = $_GET['subop'] ? trim($_GET['subop']) : '';
$currentNav = array($submod => ' class="a"');
$creditType = 'extcredits' . $var['integral_type'];
$admin_uid = explode(',', $var['admin_uid']);
$admin_qq = explode(',', $var['admin_qq']);
if ($submod === 'guarantee_apply') {
	if (!$var['integral_type']) {
		showmessage(dgt_pl('not_set_integral_type'));
	}
	if (!$var['deposit_rate']) {
		showmessage(dgt_pl('not_set_deposit_rate'));
	}
	$userGroup = unserialize($var['usergroup']);
	if (!in_array($_G['groupid'], $userGroup)) {
		showmessage(dgt_pl('no_permit'));
	}
	$extCredit = getuserprofile($creditType);
	if (submitcheck('updatesubmit')) {
		$setArr = array(
			'uid' => $_G['uid'],
			'username' => $_G['username'],
			'qq' => dhtmlspecialchars(trim($_GET['qq'])),
			'mobile' => dhtmlspecialchars(trim($_GET['mobile'])),
			'fuid' => 0,
			'fusername' => dhtmlspecialchars(trim($_GET['fusername'])),
			'amount' => (int)$_GET['amount'],
			'deposit' => (int)$_GET['deposit'],
			'memo' => dhtmlspecialchars(trim($_GET['message'])),
			'created_time' => $_G['timestamp'],
			'created_ip' => $_G['clientip']
		);
		if (!$setArr['qq']) {
			showmessage(dgt_pl('excuse_me') . dgt_pl('my_qq'));
		}
		if (!$setArr['mobile']) {
			showmessage(dgt_pl('excuse_me') . dgt_pl('mobile'));
		}
		if (!$setArr['fusername']) {
			showmessage(dgt_pl('excuse_me') . dgt_pl('other_account'));
		}
		if ($setArr['fusername'] === $_G['username']) {
			showmessage(dgt_pl('other_account_is_yourself'));
		}
		$fuser = C::t('common_member')->fetch_by_username($setArr['fusername']);
		if (!$fuser) {
			showmessage(dgt_pl('other_account_not_exist'));
		}
		$setArr['fuid'] = $fuser['uid'];
		if (!$setArr['amount']) {
			showmessage(dgt_pl('excuse_me') . dgt_pl('transaction_amount'));
		}
		if (!$setArr['deposit']) {
			showmessage(dgt_pl('excuse_me') . dgt_pl('apply_deposit'));
		}
		if ($extCredit < $setArr['deposit']) {
			showmessage(dgt_pl('your_balance_is_low'));
		}
		if (!$setArr['memo']) {
			showmessage(dgt_pl('excuse_me') . dgt_pl('memo'));
		}
		$id = C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->insert($setArr, 1);
		if ($id) {
			$url = "home.php?mod=spacecp&ac=plugin&id=dicky_guarantee_transaction:transaction&submod=guarantee_list&subop=view&subid={$id}";
			$note_apply_text = dgt_pl('note_apply_text') . ' <a href="' . $url . '" target="_blank">' . dgt_pl('view') . '</a>';
			updatemembercount($_G['uid'], array($creditType => -$setArr['deposit']), true, '', 0, '', dgt_pl('note_apply_title'), $note_apply_text);
			$note = 'dicky_guarantee_transaction:note_apply';
			$noteArr = array('url' => $url);
			notification_add($setArr['fuid'], 'guarantee_transaction', $note, $noteArr);
			showmessage(dgt_pl('applied_successfully'), 'home.php?mod=spacecp&ac=plugin&id=dicky_guarantee_transaction:transaction&submod=guarantee_list');
		}
	}
	require dirname(__FILE__) . '/./editor.inc.php';
}
elseif ($submod === 'guarantee_list') {
	$subid = (int)$_GET['subid'];
	if (in_array($subop, array('cancel', 'accept', 'refuse', 'confirm', 'view'))) {
		$log = C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->fetch($subid);
		if (!$log) {
			showmessage(dgt_pl('info_not_exist'));
		}
		if (!in_array($subop, array('confirm', 'view')) && $log['status'] > 0) {
			showmessage(dgt_pl('opt_not_allow'));
		}
		$viewUrl = "home.php?mod=spacecp&ac=plugin&id=dicky_guarantee_transaction:transaction&submod=guarantee_list&subop=view&subid={$subid}";
		$backUrl = 'home.php?mod=spacecp&ac=plugin&id=dicky_guarantee_transaction:transaction&submod=guarantee_list';
	}
	if ($subop === 'cancel') {
		$navtitle .= ' - ' . dgt_pl('cancel_apply');
		if ($log['uid'] !== $_G['uid']) {
			showmessage('quickclear_noperm');
		}
		if (submitcheck('updatesubmit')) {
			if ($log['uid'] !== $_G['uid']) {
				showmessage('quickclear_noperm');
			}
			else {
				$setArr = array('status' => 3);
				C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->update($subid, $setArr);
				$note_apply_cancel_text = dgt_pl('note_apply_cancel_text') . ' <a href="' . $viewUrl . '" target="_blank">' . dgt_pl('view') . '</a>';
				updatemembercount($_G['uid'], array($creditType => $log['deposit']), true, '', 0, '', dgt_pl('note_apply_cancel_title'), $note_apply_cancel_text);
				$note = 'dicky_guarantee_transaction:note_apply_cancel';
				$noteArr = array('url' => $viewUrl);
				notification_add($log['fuid'], 'guarantee_transaction', $note, $noteArr);
				showmessage(dgt_pl('apply_cancel_successfully'), $backUrl);
			}
		}
		include template('dicky_guarantee_transaction:subop');
	}
	elseif ($subop === 'accept') {
		$navtitle .= ' - ' . dgt_pl('accept_apply');
		if ($log['fuid'] !== $_G['uid']) {
			showmessage('quickclear_noperm');
		}
		$extCredit = getuserprofile($creditType);
		$acceptNote = str_replace('{credit}', $extCredit, dgt_pl('accept_note'));
		$acceptNote = str_replace('{amount}', $log['amount'], $acceptNote);
		$acceptNote = str_replace('{credit_type}', $_G['setting']['extcredits'][$var['integral_type']]['title'], $acceptNote);
		if (submitcheck('updatesubmit')) {
			$setArr = array(
				'fqq' => dhtmlspecialchars(trim($_GET['qq'])),
				'fmobile' => dhtmlspecialchars(trim($_GET['mobile'])),
				'processed_time' => $_G['timestamp'],
				'status' => 1
			);
			if (!$setArr['fqq']) {
				showmessage(dgt_pl('excuse_me') . dgt_pl('my_qq'));
			}
			if (!$setArr['fmobile']) {
				showmessage(dgt_pl('excuse_me') . dgt_pl('mobile'));
			}
			if ($extCredit < $log['amount']) {
				showmessage(dgt_pl('your_balance_is_low'));
			}
			C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->update($subid, $setArr);
			$note_apply_accept_text = dgt_pl('note_apply_accept_text') . ' <a href="' . $viewUrl . '" target="_blank">' . dgt_pl('view') . '</a>';
			updatemembercount($_G['uid'], array($creditType => -$log['amount']), true, '', 0, '', dgt_pl('note_apply_accept_title'), $note_apply_accept_text);
			$note = 'dicky_guarantee_transaction:note_apply_accept';
			$noteArr = array('url' => $viewUrl);
			notification_add($log['uid'], 'guarantee_transaction', $note, $noteArr);
			showmessage('do_success', $backUrl);
		}
		include template('dicky_guarantee_transaction:subop');
	}
	elseif ($subop === 'refuse') {
		$navtitle .= ' - ' . dgt_pl('refuse_apply');
		if ($log['fuid'] !== $_G['uid']) {
			showmessage('quickclear_noperm');
		}
		if (submitcheck('updatesubmit')) {
			$setArr = array('status' => 2);
			C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->update($subid, $setArr);
			$note_apply_refuse_text = dgt_pl('note_apply_refuse_text') . ' <a href="' . $viewUrl . '" target="_blank">' . dgt_pl('view') . '</a>';
			updatemembercount($log['uid'], array($creditType => $log['deposit']), true, '', 0, '', dgt_pl('note_apply_refuse_title'), $note_apply_refuse_text);
			$note = 'dicky_guarantee_transaction:note_apply_refuse';
			$noteArr = array('url' => $viewUrl);
			notification_add($log['uid'], 'guarantee_transaction', $note, $noteArr);
			showmessage('do_success', $backUrl);
		}
		include template('dicky_guarantee_transaction:subop');
	}
	elseif ($subop === 'confirm') {
		$navtitle .= ' - ' . dgt_pl('confirm_apply');
		if ($log['fuid'] !== $_G['uid']) {
			showmessage('quickclear_noperm');
		}
		if ($log['status'] != 1) {
			showmessage(dgt_pl('admin_opt_not_allow'));
		}
		$confirmNote = str_replace('{amount}', $log['amount'], dgt_pl('confirm_note'));
		$confirmNote = str_replace('{deposit}', $log['deposit'], $confirmNote);
		$confirmNote = str_replace('{credit_type}', $_G['setting']['extcredits'][$var['integral_type']]['title'], $confirmNote);
		if (submitcheck('updatesubmit')) {
			$setArr = array('status' => 4);
			C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->update($subid, $setArr);
			$note_apply_confirm_text = dgt_pl('note_apply_confirm_text') . ' <a href="' . $viewUrl . '" target="_blank">' . dgt_pl('view') . '</a>';
			$note_apply_confirm_text = str_replace('{amount}', $log['amount'], $note_apply_confirm_text);
			$note_apply_confirm_text = str_replace('{deposit}', $log['deposit'], $note_apply_confirm_text);
			updatemembercount($log['uid'], array($creditType => $log['deposit'] + $log['amount']), true, '', 0, '', dgt_pl('note_apply_confirm_title'), $note_apply_confirm_text);
			$note = 'dicky_guarantee_transaction:note_apply_confirm';
			$noteArr = array('url' => $viewUrl);
			notification_add($log['uid'], 'guarantee_transaction', $note, $noteArr);
			showmessage('do_success', $backUrl);
		}
		include template('dicky_guarantee_transaction:subop');
	}
	else {
		require_once libfile('function/discuzcode');
		$myStatus = array(
			0 => dgt_pl('my_status_0'),
			1 => dgt_pl('my_status_1'),
			2 => dgt_pl('my_status_2'),
			3 => dgt_pl('my_status_3'),
			4 => dgt_pl('my_status_4')
		);
		$otherStatus = array(
			0 => dgt_pl('other_status_0'),
			1 => dgt_pl('other_status_1'),
			2 => dgt_pl('other_status_2'),
			3 => dgt_pl('other_status_3'),
			4 => dgt_pl('other_status_4')
		);
		if ($subop === 'view') {
			if (!in_array($_G['uid'], array($log['uid'], $log['fuid']))) {
				showmessage('quickclear_noperm');
			}
			$log['memo'] = discuzcode($log['memo'], 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, $_G['setting']['lazyload'], 1, 0);
		}
		else {
			$where = "uid = '{$_G[uid]}' OR fuid = '{$_G[uid]}'";
			$order = 'created_time DESC, processed_time DESC';
			$count = C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->fetch_all($where, null, 0, null, 1);
			if ($count) {
				$page = intval(getgpc('page')) ? intval($_GET['page']) : 1;
				$perpage = 20;
				$totalPage = ceil($count / $perpage);
				if ($page > $totalPage) $page = $totalPage;
				$start = ($page - 1) * $perpage;
				$list = C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->fetch_all($where, $order, $start, $perpage);
				foreach ($list as $k => $v) {
					$list[$k]['memo'] = discuzcode($v['memo'], 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, $_G['setting']['lazyload'], 1, 0);
				}
				$url = 'home.php?mod=spacecp&ac=plugin&id=dicky_guarantee_transaction:transaction&submod=guarantee_list';
				$multipage = multi($count, $perpage, $page, $url);
			}
		}
	}
}
elseif ($submod === 'admin_center') {
	require_once libfile('function/discuzcode');
	$filter = (int)$_GET['filter'];
	$subid = (int)$_GET['subid'];
	if (!in_array($filter, array(1, 2, 4))) {
		$filter = 1;
	}
	$currentSubNav = array($filter => ' class="a"');
	if (!in_array($_G['uid'], $admin_uid)) {
		showmessage('quickclear_noperm');
	}
	if ($subop === 'view') {
		$log = C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->fetch($subid);
		if (!$log) {
			showmessage(dgt_pl('info_not_exist'));
		}
		$log['memo'] = discuzcode($log['memo'], 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, $_G['setting']['lazyload'], 1, 0);
		$adminStatus = array(
			0 => dgt_pl('my_status_0'),
			1 => dgt_pl('my_status_1'),
			2 => dgt_pl('my_status_2'),
			3 => dgt_pl('my_status_3'),
			4 => dgt_pl('my_status_4')
		);
	}
	else {
		$subop = (int)$_GET['subop'];
		if (in_array($subop, array(1, 2, 3)) && $subid) {
			$viewUrl = "home.php?mod=spacecp&ac=plugin&id=dicky_guarantee_transaction:transaction&submod=guarantee_list&subop=view&subid={$subid}";
			$backUrl = $_GET['referer'];
			$log = C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->fetch($subid);
			if (!$log) {
				showmessage(dgt_pl('info_not_exist'));
			}
			if ($log['status'] != 1) {
				showmessage(dgt_pl('admin_opt_not_allow'));
			}
			if (submitcheck('updatesubmit')) {
				$noteArr = array('url' => $viewUrl);
				$setArr = array('status' => 4, 'admin_status' => $subop);
				C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->update($subid, $setArr);
				if ($subop === 1) {
					$note_admin_arbitrate_text = dgt_pl('note_admin_arbitrate_text_1') . ' <a href="' . $viewUrl . '" target="_blank">' . dgt_pl('view') . '</a>';
					$note_admin_arbitrate_text = str_replace('{amount}', $log['amount'], $note_admin_arbitrate_text);
					$note_admin_arbitrate_text = str_replace('{deposit}', $log['deposit'], $note_admin_arbitrate_text);
					$note = 'dicky_guarantee_transaction:note_admin_arbitrate_1';
					$noteUid = $log['uid'];
					$totalAmount = $log['deposit'] + $log['amount'];
					notification_add($log['fuid'], 'guarantee_transaction', 'dicky_guarantee_transaction:note_admin_arbitrate_5', $noteArr);
				}
				elseif ($subop === 2) {
					$note_admin_arbitrate_text = dgt_pl('note_admin_arbitrate_text_2') . ' <a href="' . $viewUrl . '" target="_blank">' . dgt_pl('view') . '</a>';
					$note_admin_arbitrate_text = str_replace('{amount}', $log['amount'], $note_admin_arbitrate_text);
					$note_admin_arbitrate_text = str_replace('{deposit}', $log['deposit'], $note_admin_arbitrate_text);
					$note = 'dicky_guarantee_transaction:note_admin_arbitrate_2';
					$noteUid = $log['fuid'];
					$totalAmount = $log['deposit'] + $log['amount'];
					notification_add($log['uid'], 'guarantee_transaction', 'dicky_guarantee_transaction:note_admin_arbitrate_6', $noteArr);
				}
				elseif ($subop === 3) {
					$note_admin_arbitrate_text = dgt_pl('note_admin_arbitrate_text_3') . ' <a href="' . $viewUrl . '" target="_blank">' . dgt_pl('view') . '</a>';
					$note_admin_arbitrate_text = str_replace('{deposit}', $log['deposit'], $note_admin_arbitrate_text);
					$note = 'dicky_guarantee_transaction:note_admin_arbitrate_3';
					updatemembercount($log['uid'], array($creditType => $log['deposit']), true, '', 0, '', dgt_pl('note_admin_arbitrate_title'), $note_admin_arbitrate_text);
					notification_add($log['uid'], 'guarantee_transaction', $note, $noteArr);

					$note_admin_arbitrate_text = dgt_pl('note_admin_arbitrate_text_4') . ' <a href="' . $viewUrl . '" target="_blank">' . dgt_pl('view') . '</a>';
					$note_admin_arbitrate_text = str_replace('{amount}', $log['amount'], $note_admin_arbitrate_text);
					$note = 'dicky_guarantee_transaction:note_admin_arbitrate_4';
					$noteUid = $log['fuid'];
					$totalAmount = $log['amount'];
				}
				updatemembercount($noteUid, array($creditType => $totalAmount), true, '', 0, '', dgt_pl('note_admin_arbitrate_title'), $note_admin_arbitrate_text);
				notification_add($noteUid, 'guarantee_transaction', $note, $noteArr);
				showmessage('do_success', $backUrl);
			}
			include template('dicky_guarantee_transaction:subop');
		}
		else {
			if ($var['integral_type']) {
				$sql = "SELECT SUM({$creditType}) total_credit FROM " . DB::table('common_member_count');
				$result = DB::fetch_first($sql);
				$totalCredit = $result['total_credit'];
			}
			if ($filter === 2) {
				$where = "status = '4' AND admin_status > 0";
			}
			else {
				$where = "status = '$filter'";
			}
			if ($subid) {
				$where .= " AND id = '$subid'";
			}
			$order = 'created_time DESC, processed_time DESC';
			$count = C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->fetch_all($where, null, 0, null, 1);
			if ($count) {
				$page = intval(getgpc('page')) ? intval($_GET['page']) : 1;
				$perpage = 20;
				$totalPage = ceil($count / $perpage);
				if ($page > $totalPage) $page = $totalPage;
				$start = ($page - 1) * $perpage;
				$list = C::t('#dicky_guarantee_transaction#plugin_dicky_guarantee_transaction')->fetch_all($where, $order, $start, $perpage);
				foreach ($list as $k => $v) {
					$list[$k]['memo'] = discuzcode($v['memo'], 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1, 1, $_G['setting']['lazyload'], 1, 0);
				}
				$url = "home.php?mod={$mod}&ac={$ac}&id={$_GET['id']}&submod={$submod}&filter={$filter}&subid={$subid}";
				$multipage = multi($count, $perpage, $page, $url);
			}
		}
	}
}
//From: Dism_taobao_com
?>