<?php
/*
	Name: ��Dicky����������(Guarantee Transaction)
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}
function dgt_pl($str) {
    return lang('plugin/dicky_guarantee_transaction', $str);
}
//From: Dism_taobao_com
?>