<?php
/*
	Name: 【Dicky】担保交易(Guarantee Transaction)
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
$charset = CHARSET;
set_time_limit(0);
$sql = <<<EOF
CREATE TABLE `{tablepre}plugin_dicky_guarantee_transaction` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned DEFAULT '0',
  `username` varchar(20) DEFAULT NULL,
  `qq` varchar(20) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `fuid` int(10) unsigned DEFAULT '0',
  `fusername` varchar(255) DEFAULT NULL,
  `fqq` varchar(20) DEFAULT NULL,
  `fmobile` varchar(50) DEFAULT NULL,
  `amount` int(10) unsigned DEFAULT '0',
  `deposit` int(10) unsigned DEFAULT '0',
  `memo` varchar(255) DEFAULT NULL,
  `created_time` int(10) unsigned DEFAULT '0',
  `created_ip` varchar(15) DEFAULT NULL,
  `processed_time` int(10) unsigned DEFAULT '0',
  `status` tinyint(1) DEFAULT '0',
  `admin_status` tinyint(1) DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`),
  KEY `fuid` (`fuid`),
  KEY `status` (`status`),
  KEY `admin_status` (`admin_status`)
) ENGINE=MyISAM DEFAULT CHARSET={$charset};

EOF;
runquery($sql);
$finish = TRUE;
?>