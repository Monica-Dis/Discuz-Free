<?php
/*
	Name: 【Dicky】担保交易(Guarantee Transaction)
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
set_time_limit(0);
$sql = <<<EOF
DROP TABLE IF EXISTS `{tablepre}plugin_dicky_guarantee_transaction`;

EOF;
runquery($sql);
$finish = true;
?>