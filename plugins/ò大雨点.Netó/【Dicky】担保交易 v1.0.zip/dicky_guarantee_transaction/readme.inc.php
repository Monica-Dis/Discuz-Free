<?php
/*
	Name: 【Dicky】担保交易(Guarantee Transaction)
	Author: Dicky
	QQ: 25941/8511978
	Website: http://dz.25941.cn
	Shop: http://webapp.taobao.com
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')){
	exit('Access Denied');
}
include dirname(__FILE__) . '/./common.func.php';
echo dgt_pl('readme');
?>