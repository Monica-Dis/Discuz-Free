
function setCookie(name,value){
    if(window.localStorage){
        localStorage.removeItem(name);
        localStorage.setItem(name,value);
    } else {
        var Days = 1000;
        var exp = new Date();
        exp.setTime(exp.getTime() + Days*24*60*60*1000);
        document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
    };
    return false;
}
function getCookie(name) {
    if(window.localStorage){
        var arr,reg = new RegExp("(^| )"+name+"=([^;]*)(;|$)");
        arr = localStorage.getItem(name);
        return arr;
    } else {
        var arr,reg = new RegExp("(^| )"+name+"=([^;]*)(;|$)");
        if(arr = document.cookie.match(reg)){
            return unescape(arr[2]);
        }else{
            return null;
        }
    };
}
function delcookie(name){
	if(window.localStorage){
		localStorage.removeItem(name);
	} else {
		var exp = new Date();
		exp.setTime(exp.getTime() - 1);
		var cval=getCookie(name);
		if(cval!=null){document.cookie= name + "="+cval+";expires="+exp.toGMTString();}
	};
}
//��ȡ�����Ĳ���(����)
function getParam(key){
	var reg = new RegExp("(^|&)"+key+"=([^&]*)(&|$)");
	var result = window.location.search.substr(1).match(reg);
	return result?decodeURIComponent(result[2]):null;
}
//����cookie�б�
function upDateCookie(){
	var	temHtml = '',
		searchData = getCookie('searchData'),
		num = 0;
	if(searchData){
		searchData = searchData.split('|');
		//��ʾ��������
		for(var i = 0,len = searchData.length;i < len;i++){
			if(i == 5){
				break;
			}
			if(kekejq('.sqt_index').length > 0){
				temHtml += '<li class="border_b"><a href="plugin.php?id=keke_souquan:keke_souquan&search='+encodeURIComponent(searchData[i])+'"><div class="search_item">'+searchData[i]+'</div></a></li>';
			}else{
				temHtml += '<li class="border_b"><a href="javascript:;"><div class="search_item">'+searchData[i]+'</div></a></li>';
			}
		}
		return temHtml;
	}
}
//���˱���
function filter(value){
	var regu = /\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g;
	if(regu.test(value)){
		return 'error';
	}
}
//����������
function filterKey(value){
	value = kekejq.trim(value);
	var len = value.replace(/[^\x00-\xff]/g, "**").length;
	if(value == ''){
		return false;
	}else if(value.indexOf('http://') > -1||value.indexOf('https://') > -1||value.indexOf('www') > -1){
		promptPop({ content:'&#19981;&#25903;&#25345;&#38142;&#25509;&#25628;&#32034;'});
		return false;
	}else if(filter(value) == 'error'||value.indexOf('��') > -1){
		promptPop({ content:'&#25628;&#32034;&#35789;&#26684;&#24335;&#38169;&#35823;'});
		return false;
	}
	return true;
}

//�ж�ios
function isIos(){
	var ua = navigator.userAgent.toLowerCase(); 
	if (/iphone|ipad|ipod/.test(ua)){
		return true;
	}else{
		return false;
	}
}



/* ��ҳ */
var index  = function(){
	var search = kekejq('#search'),
	 	searchData = getCookie('searchData'),
	 	contain = kekejq('.sqt_index'),
	 	ajax,
	 	cookie_list = '',
	 	deleteCookie = kekejq('#delete_cookie'),
	 	searchListBox= kekejq('#search_list_box'),
		searchList = kekejq('#search_list'),
		waiting = false,
		isLoadMore = true,
		load = kekejq('#site_loading'),
		noMoreData = kekejq('#no_data'),
		no_list=kekejq('#no_list'),
		no_list_key=kekejq('#no_list_key'),
		page = 1;
	var funList = {
		/* ��������� */
		showSearch:function(){
			var searchBox = kekejq('.search_box'),
				isFocus = false,
				goSearch = kekejq('#go_search'),
				result = kekejq('#result'),
				setgb = '',
				searchForm = kekejq('#search_form');
				var that = this;
			//��ý���
			
			search.on('focus',function(){
				if(isFocus){
					return false;
				}
				var that = kekejq(this);
				var value = that.val();
				searchData = getCookie('searchData');
				
				if(searchData&&search.val() == ''){
					searchList.html(upDateCookie());
					searchListBox.show();
				}else if(search.val() != ''){
					search.trigger('input');
				}
			});
			//�ж��Ƿ�����ҳ
		
				//������̵�����
				searchForm.on('search',function(){
					var searchValue = search.val();
					searchValue=encodeURIComponent(searchValue);
					if(!filterKey(searchValue)){
						return false;
					}
					window.location.href = 'plugin.php?id=keke_souquan:keke_souquan&search='+searchValue;
				});
				//��� ��ȯ��ť
				goSearch.on('click',function(){
					var searchValue = search.val();
					
					
					
					searchValue=encodeURIComponent(searchValue);
					/*if(!filterKey(searchValue)){
						//return false;
					}*/
					window.location.href = 'plugin.php?id=keke_souquan:keke_souquan&search='+searchValue;
				});
			
			//�����ȯ��¼
			deleteCookie.on('click',function(){
				delcookie('searchData');
				searchList.html('');
				searchListBox.hide();
			});
		},
		/* ����ʲ��� */
		showTerms:function(){
			var clear = kekejq('#clear_text'),
				resultList = kekejq('#result_list'),
				close = kekejq('#close_search');
			search.on('input',function(){
				var inputValue = kekejq(this).val();
				//�����ַ�����ʾ
				if(filter(inputValue) == 'error'||inputValue.indexOf('��') > -1){
					return false;
				}
				var temHtml = '';
				if(inputValue!=''){
					clear.show();
					deleteCookie.hide();
				}else{
					if(getCookie('searchData')){
						deleteCookie.show();
						searchList.html(upDateCookie());
					}
					clear.hide();
					return false;
				}	
				//��ʾ���������	
				
				var searchvals=encodeURIComponent(search.val());
				kekejq.ajax({
		            url: "https://suggest.taobao.com/sug?code=utf-8&q="+searchvals,
		            type: "get",
		            dataType:"jsonp",
		            success: function (data){
						var result = data.result,
							len = result.length;
						if(result.length == 0){
							searchList.html('');
							searchListBox.hide();
							return false;
						}else{
							searchListBox.show();
						}
						if(len > 5){
							len = 5;
						}
						for(var i = 0;i < len;i++){
							var re = new RegExp(inputValue, "g");
							var item = result[i][0].replace(re,'<span>'+inputValue+'</span>');
							temHtml += '<li class="border_b"><a href="plugin.php?id=keke_souquan:keke_souquan&search='+ result[i][0]+'">'+item+'</a></li>';
						}
						searchList.html(temHtml);
		            },
		            error:function(){
		                promptPop({ content: '&#32852;&#24819;&#35789;&#33719;&#21462;&#22833;&#36133;'});
		            }
		        });
			});
			
			search.blur(function(){
				setTimeout(function(){
					searchListBox.hide();
				},3000);
			});
		
			//�������
			$clear.on('click',function(){
				$search.val('');
				$(this).hide();
				$search.focus();
				if(getCookie('searchData')){
					$deleteCookie.show();
					$searchList.html(upDateCookie());
				}
			});
			//�����������
			
			
		},
		
	saveCookie:function(){
			var cookies = getCookie('searchData'),
				showList = '';
			if(cookies){
				listData = cookies.split('|');
				for(var i = 0,len = listData.length;i < len;i++){
					if(i == 5){
						break;
					}
					showList += listData[i];
				}
			}
			//û��cookie����cookie
			if(!cookies&&search.val()){
				cookies = search.val();
				setCookie('searchData',cookies);
			//��cookie����ǰ���cookie���ظ��Ļ�
			}else if(cookies&&showList.indexOf(search.val()) == -1&&search.val()){
				cookies = search.val() + '|' + cookies;
				setCookie('searchData',cookies);
			}
		},
	//������������
	scrollLoad:function(){
		var windowH = kekejq(window).height(),
			showhot=kekejq("#showhot").val();
			that = this;
			searchKeys=kekejq("#search").val();
			if(searchKeys){
				this.saveCookie();
				that.loadData();
			}
			that.loadData();
			
		kekejq(window).scroll(function(){
			if(isLoadMore&&kekejq(this).scrollTop() + windowH > kekejq(document).height() - 300){
				if(waiting){
					return false;
				}
				if(showhot==0 && searchKeys==''){
					return false;
				}
				page++;
				that.loadData();
				//alert(page);
				lazyLoading(kekejq("img.lazyload"));
			}
			
		});
	},
	//��������
	loadData:function(){
		var key = '';
		searchKeys=kekejq("#search").val();
		if(searchKeys){
			key = kekejq.trim(searchKeys);
		}else{
			key = kekejq("#cachekey").val();
		}
		
		if(waiting){
			return false;
		}
		waiting = true;
		load.show();
	
		kekejq.ajax({
            url: "plugin.php?id=keke_souquan:data",
            data: {"key":key,"p": page},
            type: "GET",
            success: function (data){
				
            	waiting = false;
            	load.hide();

				var data =JSON.parse(data);
				var list = data.data,
            		temHtml = '';
					
				//���ظ���û������
				
				if(list== null && page==1){
					no_list.show();
					no_list_key.text(searchKeys);
					isLoadMore = false;
					return false;
				}
				
				if(list.length == 0){
					noMoreData.show();
					isLoadMore = false;
					return false;
            	}
				
            	for(var i = 0,len = list.length;i < len;i++){
            		var price = list[i].price,
            			img = list[i].img,
						icon = 	list[i].usertype;
	            		price = parseFloat(price.toFixed(2));
	            	//����ͼƬ�޷���ʾ��
	     			var imgObj = new Image();
	     			imgObj.src = img;
	     			imgObj.onerror = function(){
	     				img = img.replace('_300x300q90.jpg','');
	     			}
	            	//���� iocn 0λ�Ա� 1Ϊ��è
	            	if(list[i].usertype==0){
						icon = '<div class="fr mall_tb quan_mall"><i></i><span>&#28120;&#23453;</span></div>';

	            	}else if(list[i].usertype==1){
						icon = '<div class="fr mall_tm quan_mall"><i></i><span>&#22825;&#29483;</span></div>';
	            	}
	            	
	            	img = '<img src="'+img+'" alt="">';
	            	
            		temHtml += '<li><div class="quan_item_img"><a href="'+list[i].url+'" target="_blank">'+img+'</a></div><div class="quan_item_con"><p class="quan_item_tit"><a href="'+list[i].url+'" target="_blank">'+list[i].title+'</a></p><div class="quan_item_price cfs"><div class="fl"><span class="pir">&#65509;</span><span class="num">'+price+'</span><span class="pri_font">&#21048;&#21518;&#20215;</span></div><span class="list fr">'+list[i].volume+'&#20154;&#24050;&#39046;&#29992;</span></div><div class="item_btn_box cfs"><div class="quan_number"><span class="quan_tip">&#21048;</span><span class="quan_price">'+list[i].quota+'&#20803;</span></div><a class="fr combtn_n combtn_red" href="'+list[i].url+'" target="_blank">&#39046;&#21048;&#25250;&#36141;</a>'+icon+'</div></div></li>';
            	}
            	kekejq("#goods_list").append(temHtml);
            	lazyLoading(kekejq("img.lazyload"));
            },
            error:function(){
            	waiting = false;
            	load.hide();
                promptPop('&#31995;&#32479;&#32321;&#24537;&#44;&#35831;&#37325;&#35797;');
				
            }
        });
	},
		
		
		/* ���ȴ� */
		changeKey:function(){
			var change = kekejq('#sqt_change'),
			    ctLoading = kekejq('#ct_loading'),
				ticketsList = kekejq('#tickets_list'),
				p = -1,
				waiting = false,
				keyid='';
			change.on('click',function(){
				if(waiting){
					return false;
				}
				waiting = true;
				ctLoading.show();
				p++;
				p = p == 6 ? 0 : p; 
				kekejq.ajax({
		            url: "plugin.php?id=keke_souquan:data",
		            data: {"ac": "tags"},
		            type: "POST",
		            success: function (data){
						var data =JSON.parse(data);
		            	waiting = false;
		            	ctLoading.hide();
		            	var list = data.data,
		            		temHtml = '',
							jg='';
							
		            	for(var i = 0,len = 15;i < len;i++){
							if(i>0){
								jg='<b>|</b>';
							}
		            		temHtml += jg+'<a href="plugin.php?id=keke_souquan:keke_souquan&search='+encodeURIComponent(list[i])+'">'+list[i]+'</a>';
		            	}
		            	ticketsList.html(temHtml);
		            },
		            error:function(){
		            	ctLoading.hide();
		            	waiting = false;
		                promptPop({ content: 'error'});
		            }
		        });
			});
			//��ʼ�� �����ȴ�
			change.trigger('click');
		},
		init:function(){
			this.showSearch();
			this.scrollLoad();this.changeKey();
			this.showTerms();
			
		}
	};
	funList.init();
};