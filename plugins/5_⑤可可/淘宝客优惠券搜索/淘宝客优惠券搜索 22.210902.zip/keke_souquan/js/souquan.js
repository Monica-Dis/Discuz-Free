
function setCookie(name,value){
    if(window.localStorage){
        localStorage.removeItem(name);
        localStorage.setItem(name,value);
    } else {
        var Days = 1000;
        var exp = new Date();
        exp.setTime(exp.getTime() + Days*24*60*60*1000);
        document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
    };
    return false;
}
function getCookie(name) {
    if(window.localStorage){
        var arr,reg = new RegExp("(^| )"+name+"=([^;]*)(;|$)");
        arr = localStorage.getItem(name);
        return arr;
    } else {
        var arr,reg = new RegExp("(^| )"+name+"=([^;]*)(;|$)");
        if(arr = document.cookie.match(reg)){
            return unescape(arr[2]);
        }else{
            return null;
        }
    };
}
function delcookie(name){
	if(window.localStorage){
		localStorage.removeItem(name);
	} else {
		var exp = new Date();
		exp.setTime(exp.getTime() - 1);
		var cval=getCookie(name);
		if(cval!=null){document.cookie= name + "="+cval+";expires="+exp.toGMTString();}
	};
}
//��ȡ�����Ĳ���(����)
function getParam(key){
	var reg = new RegExp("(^|&)"+key+"=([^&]*)(&|$)");
	var result = window.location.search.substr(1).match(reg);
	return result?decodeURIComponent(result[2]):null;
}
//����cookie�б�
function upDateCookie(){
	var	temHtml = '',
		searchData = getCookie('searchData'),
		num = 0;
	if(searchData){
		searchData = searchData.split('|');
		//��ʾ��������
		for(var i = 0,len = searchData.length;i < len;i++){
			if(i == 5){
				break;
			}
			if($('.sqt_index').length > 0){
				temHtml += '<li class="border_b"><a href="plugin.php?id=keke_souquan:list&search='+encodeURIComponent(searchData[i])+'"><div class="search_item">'+searchData[i]+'</div></a></li>';
			}else{
				temHtml += '<li class="border_b"><a href="javascript:;"><div class="search_item">'+searchData[i]+'</div></a></li>';
			}
		}
		return temHtml;
	}
}
//���˱���
function filter(value){
	var regu = /\uD83C[\uDF00-\uDFFF]|\uD83D[\uDC00-\uDE4F]/g;
	if(regu.test(value)){
		return 'error';
	}
}
//����������
function filterKey(value){
	value = $.trim(value);
	var len = value.replace(/[^\x00-\xff]/g, "**").length;
	if(value == ''){
		return false;
	}else if(value.indexOf('http://') > -1||value.indexOf('https://') > -1||value.indexOf('www') > -1){
		promptPop({ content:'&#19981;&#25903;&#25345;&#38142;&#25509;&#25628;&#32034;'});
		return false;
	}else if(filter(value) == 'error'||value.indexOf('��') > -1){
		promptPop({ content:'&#25628;&#32034;&#35789;&#26684;&#24335;&#38169;&#35823;'});
		return false;
	}
	return true;
}

//�ж�ios
function isIos(){
	var ua = navigator.userAgent.toLowerCase(); 
	if (/iphone|ipad|ipod/.test(ua)){
		return true;
	}else{
		return false;
	}
}



/* ��ҳ */
var index  = function(){
	var $search = $('#search'),
	 	searchData = getCookie('searchData'),
	 	$contain = $('.sqt_index'),
	 	ajax,
	 	cookie_list = '',
	 	$deleteCookie = $('#delete_cookie'),
	 	$searchListBox= $('#search_list_box'),
		$getMores = $('#loading_box2'),
		$searchList = $('#search_list'),
		pages=1,
		$noLists = $('.none_list'),
		$noMoreDatas = $('#no_data'),
		isLoadMores = true,
		waitings = false;
	var funList = {
		/* ��������� */
		showSearch:function(){
			var $searchBox = $('.search_box'),
				isFocus = false,
				$goSearch = $('#go_search'),
				$result = $('#result'),
				setgb = '',
				$searchForm = $('#search_form');
				
			//��ý���
			
			$search.on('focus',function(){
				if(isFocus){
					return false;
				}
				var $that = $(this);
				var value = $that.val();
				//�����ios input�Ĺ����ǰ�������
				if(isIos()){
					clearTimeout(setgb);
					setgb = setTimeout(function(){
						$that.val(value);
					},10);
				}
				
				
				searchData = getCookie('searchData');
				if(searchData&&$search.val() == ''){
					$searchList.html(upDateCookie());
					$searchListBox.show();
				}else if($search.val() != ''){
					$search.trigger('input');
				}
			});
			//�ж��Ƿ�����ҳ
			if($('.sqt_index').length > 0){
				//������̵�����
				$searchForm.on('search',function(){
					var searchValue = $search.val();
					searchValue=encodeURIComponent(searchValue);
					if(!filterKey(searchValue)){
						return false;
					}
					window.location.href = 'plugin.php?id=keke_souquan:list&search='+searchValue;
				});
				//��� ��ȯ��ť
				$goSearch.on('click',function(){
					var searchValue = $search.val();
					searchValue=encodeURIComponent(searchValue);
					if(!filterKey(searchValue)){
						//return false;
					}
					window.location.href = 'plugin.php?id=keke_souquan:list&search='+searchValue;
				});
			}
			//�����ȯ��¼
			$deleteCookie.on('click',function(){
				delcookie('searchData');
				$searchList.html('');
				$searchListBox.hide();
			});
		},
		/* ����ʲ��� */
		showTerms:function(){
			var $clear = $('#clear_text'),
				$resultList = $('#result_list'),
				$close = $('#close_search');
			$search.on('input',function(){
				var inputValue = $(this).val();
				//�����ַ�����ʾ
				if(filter(inputValue) == 'error'||inputValue.indexOf('��') > -1){
					return false;
				}
				var temHtml = '';
				if(inputValue!=''){
					$clear.show();
					$deleteCookie.hide();
				}else{
					if(getCookie('searchData')){
						$deleteCookie.show();
						$searchList.html(upDateCookie());
					}
					$clear.hide();
					return false;
				}	
				//��ʾ���������	
				
				var searchvals=encodeURIComponent($search.val());
				$.ajax({
		            url: "https://suggest.taobao.com/sug?code=utf-8&q="+searchvals,
		            type: "get",
		            dataType:"jsonp",
		            success: function (data){
						var result = data.result,
							len = result.length;
						if(result.length == 0){
							$searchList.html('');
							$searchListBox.hide();
							return false;
						}else{
							$searchListBox.show();
						}
						if(len > 5){
							len = 5;
						}
						for(var i = 0;i < len;i++){
							var re = new RegExp(inputValue, "g");
							var item = result[i][0].replace(re,'<span>'+inputValue+'</span>');
							temHtml += '<li class="border_b"><a href="javascript:;">'+item+'</a></li>';
						}
						$searchList.html(temHtml);
		            },
		            error:function(){
		                promptPop({ content: '&#32852;&#24819;&#35789;&#33719;&#21462;&#22833;&#36133;'});
		            }
		        });
			});
			//�ر�������
			$close.on('click',function(){
				if($('.sqt_index').length > 0){
					$contain.css({
						'transform':"translateY(0)",
						'-webkit-transform':"translateY(0)"
					});
				}
				$search.blur();
				$searchListBox.hide();
				$clear.hide();
			});
			//�������
			$clear.on('click',function(){
				$search.val('');
				$(this).hide();
				$search.focus();
				if(getCookie('searchData')){
					$deleteCookie.show();
					$searchList.html(upDateCookie());
				}
			});
			//�����������
			if($('.sqt_index').length > 0){
				$searchList.on('click','a',function(){
					if($(this).attr('href').indexOf('search')==-1){
						window.location.href = 'plugin.php?id=keke_souquan:list&search='+encodeURIComponent($(this).html().replace(/<\/?[^>]*>/g,''));
					}
				});
			}
		},
		/* ���ȴ� */
		changeKey:function(){
			var $change = $('#sqt_change'),
			    $ctLoading = $('#ct_loading'),
				$ticketsList = $('#tickets_list'),
				p = -1,
				waiting = false;
			$change.on('click',function(){
				if(waiting){
					return false;
				}
				waiting = true;
				$ctLoading.show();
				p++;
				p = p == 6 ? 0 : p; 
				$.ajax({
		            url: "plugin.php?id=keke_souquan:data",
		            data: {"ac": "tags"},
		            type: "POST",
		            success: function (data){
						var data =JSON.parse(data);
		            	waiting = false;
		            	$ctLoading.hide();
		            	var list = data.data,
		            		temHtml = '';
		            	for(var i = 0,len = list.length;i < len;i++){
		            		temHtml += '<li><a href="plugin.php?id=keke_souquan:list&search='+encodeURIComponent(list[i])+'">'+list[i]+'</a></li>';
		            	}
		            	$ticketsList.html(temHtml);
		            },
		            error:function(){
		            	$ctLoading.hide();
		            	waiting = false;
		                promptPop({ content: '&#28909;&#35789;&#33719;&#21462;&#22833;&#36133;'});
		            }
		        });
			});
			//��ʼ�� �����ȴ�
			$change.trigger('click');
		},
		
		
		getLists:function(){
			//��ȡ������������
		
			var type=1;
			var showhot=$("#showhot").val();
			if($('.sqt_index').length > 0 && showhot>0){
				
				var that = this;
				var windowH = $(window).height();
				that.getDatas($getMores,'more',type);
				$(window).scroll(function(){
						
						scrollHight = $(this).scrollTop();
						
						if(isLoadMores&&scrollHight + windowH > $(document).height() - 100){
							
							if(waitings){
								return false;
							}
							pages++;
							that.getDatas($getMores,'more',type);
						}
				});
			}

		},
		
		//�������� loadTypeΪ���ط�ʽ moreΪ���ظ��� typeΪɸѡ����
		getDatas:function($load,loadType,type){
			
			
			type = type || 1;
			if(waitings){
				return false;
			}
		
		
			waitings = true;
			$load.show();
			$noLists.hide();
			$noMoreDatas.hide();
			var search="";
			
				$.ajax({
		            url: "plugin.php?id=keke_souquan:data",
		            data: {"key":search,"p": pages,"s":type},
		            type: "GET",
		            success: function (data){
						
		            	waitings = false;
		            	$load.hide();
		            	temHtml = '';
						var data =JSON.parse(data);
						var list=data.data;
		            	//���ظ���û������
		            	if(loadType=='more'&&list.length == 0){
							$noMoreDatas.show();
							isLoadMores= false;
							return false;
		            	}
		            	//�б�������
		            	if(list.length == 0){
		            		$("#goods").html('');
							$noLists.show();
							isLoadMores = false;
		            		return false;
		            	}
						
						
						var www=$(window).width(),
						listimgwidth=(www-30)/2;
						
		            	for(var i = 0,len = list.length;i < len;i++){
		            		var price = list[i].price,
		            			img = list[i].img,
								icon = 	list[i].usertype;
			            	price = parseFloat(price.toFixed(2));
			            	//����ͼƬ�޷���ʾ��
			     			var imgObj = new Image();
			     			imgObj.src = img;
			     			imgObj.onerror = function(){
			     				img = img.replace('_220x10000Q80s80.jpg','');
			     			}
			            	//���� iocn 0λ�Ա� 1Ϊ��è
			            	if(list[i].usertype==0){
								icon = '<div class="result_tb"><i class="icons icons_tb"></i><span>&#28120;&#23453;</span></div>';
			            	}else if(list[i].usertype==1){
								icon = '<div class="result_tm"><i class="icons icons_tm"></i><span>&#22825;&#29483;</span></div>';
			            	}
							
							
			            	//ͼƬ������
			            	//if(i > 5){
								//img = '<img class="lazyload result_img fl" src="source/plugin/keke_souquan/template/images/img_nopic.png" data-original="'+img+'" style="height:'+ listimgwidth +'px"/>';
			            	//}else{
			            		img = '<img class="fl result_img" src="'+img+'" alt=""  style="height:'+ listimgwidth +'px">';
			            	//}
			            								
							
		            		temHtml += '<li><a href="javascript:;" target="_blank" data-tkl="" data-iid="'+list[i].numiid+'" data-img="'+list[i].img+'" data-title="'+list[i].title+'" data-price="'+price+'" data-url="'+list[i].url+'">'+img+'<div class="result_info border_b"><p class="result_title">'+list[i].title+'</p>'+icon+'<p class="result_price">&#65509;<span class="price_value">'+price+'</span><span class="price_other">&#21048;&#21518;&#20215;</span></p><div class="result_bottom cf"><span class="result_ticket fl">&#39046;'+list[i].quota+'&#20803;&#21048;</span><span class="fr ticket_number">'+list[i].volume+'&#20154;&#39046;&#29992;</span></div></div></a></li>';
							
		            	}
						
		            	if(loadType=='more'){
		            		$("#goods").append(temHtml);
		            	}else{
		            		$("#goods").html(temHtml);
		            	}
						
						lazyLoading($("img.lazyload"));
						
		            },
		            error:function(){
						
						alert(666);
		            	//waiting = false;
		            	//$load.hide();
		                //promptPop({ content: 'error'});
		            }
		        });
			
		},
		
		init:function(){
			this.showSearch();
			this.showTerms();
			this.changeKey();
			this.getLists();
			showTkl($("#goods"),'getKtl');

		}
	};
	funList.init();
};



/* ���ҳ */
var result = function(){
	var search = '',
		$resultList = $('#result_list'),
		$loading = $('#loading_box'),
		waiting = false,
		type = '',
		$noList = $('.none_list'),
		$noMoreData = $('#no_data'),
		page = 1,
		isLoadMore = true,
		$searchBox = $('#search_list_box'),
		$getMore = $('#loading_box2');
	var funList = {
		//���滺��
		saveCookie:function(){
			var cookies = getCookie('searchData'),
				showList = '';
			if(cookies){
				listData = cookies.split('|');
				for(var i = 0,len = listData.length;i < len;i++){
					if(i == 5){
						break;
					}
					showList += listData[i];
				}
			}
			//û��cookie����cookie
			if(!cookies&&search){
				cookies = search;
				setCookie('searchData',cookies);
			//��cookie����ǰ���cookie���ظ��Ļ�
			}else if(cookies&&showList.indexOf(search) == -1&&search){
				cookies = search + '|' + cookies;
				setCookie('searchData',cookies);
			}
		},
		//�����б�
		getList:function(){
			//��ȡ������������
			var reg = new RegExp("(^|&)search=([^&]*)(&|$)");
			var result = window.location.search.substr(1).match(reg);
			
			result = result?result[2].replace(/\+/g,' ') : null;
				
				
			search = result?decodeURIComponent(result) : null;
			
			var that = this,
				$search = $('#search'),
				$searchListBox = $('#search_list_box'),
				$select = $('#select_type');
			that.getData($loading);
			if(!getParam('type')){
				this.saveCookie();
			}
			var windowH = $(window).height();
			//���fixed ��ios�Ĵ�λ���� andriod fixed����Ҳ������
			var $lists = $('#sqt_result');
			$gotop = $('#gotop');
			if (isIos()){
				$lists.addClass('fixed_gride');
				$gotop.on('touchend',function (e) {
			        $lists.scrollTop(0);
			        if($('.menu_content').length > 0){
		                $webBottom.removeClass('bottom_show');
		            }else{
		                $webBottom.removeClass('page_bottom_show');
		            }
			        e.preventDefault();
			    });
				$lists.scroll(function(){
					$search.blur();
					$searchListBox.hide();
					scrollHight = $(this).scrollTop();
					if(isLoadMore&&scrollHight + windowH*0.8 > $('#result_list').height() - 100){
						if(waiting){
							return false;
						}
						page++;
						that.getData($getMore,'more',type);
					}
					//��ʾ�ص�����
			        if(scrollHight > windowH) {
			           if($('.menu_content').length > 0){
			                $webBottom.addClass('bottom_show');
			            }else{
			                $webBottom.addClass('page_bottom_show');
			            }
			        } else {
			            if($('.menu_content').length > 0){
			                $webBottom.removeClass('bottom_show');
			            }else{
			                $webBottom.removeClass('page_bottom_show');
			            }
			        }
				});
			}else{
				//��������
				$(window).scroll(function(){
					$search.blur();
					$searchListBox.hide();
					scrollHight = $(this).scrollTop();
					if(isLoadMore&&scrollHight + windowH > $(document).height() - 100){
						if(waiting){
							return false;
						}
						page++;
						that.getData($getMore,'more',type);
					}
				});
				goTop();
			}	
			//ɸѡ�����б�
			$select.on('click','li',function(){
				var $item = $(this);
				if($item.hasClass('active')){
					return false;
				}
				isLoadMore = true;
				$(window).scrollTop(0);
				$item.addClass('active').siblings().removeClass('active');
				type = $item.data('type');
				that.getData($loading,'',type);
			});
		},
		
		//�������� loadTypeΪ���ط�ʽ moreΪ���ظ��� typeΪɸѡ����
		getData:function($load,loadType,type){
			type = type || 1;
			if(waiting){
				return false;
			}
			if(loadType!='more'){
				$resultList.html('');
				page = 1;
			}
			$noList.hide();
			$noMoreData.hide();
			waiting = true;
			$load.show();
			$searchBox.hide();
			
			if(search){
				search = encodeURIComponent(search).replace('%EF%BF%BC','');
				search = decodeURIComponent(search);
				$.ajax({
		            url: "plugin.php?id=keke_souquan:data",
		            data: {"key":search,"p": page,"s":type},
		            type: "GET",
		            success: function (data){
		            	waiting = false;
		            	$load.hide();
		            	temHtml = '';
						var data =JSON.parse(data);
						var list=data.data;
		            	//���ظ���û������
		            	if(loadType=='more'&&list.length == 0){
							$noMoreData.show();
							isLoadMore = false;
							return false;
		            	}
		            	//�б�������
		            	if(list.length == 0){
		            		$resultList.html('');
							$noList.show();
							isLoadMore = false;
		            		return false;
		            	}
						
						
		            	for(var i = 0,len = list.length;i < len;i++){
		            		var price = list[i].price,
		            			img = list[i].img,
								icon = 	list[i].usertype;
			            	price = parseFloat(price.toFixed(2));
			            	//����ͼƬ�޷���ʾ��
			     			var imgObj = new Image();
			     			imgObj.src = img;
			     			imgObj.onerror = function(){
			     				img = img.replace('_220x10000Q80s80.jpg','');
			     			}
			            	//���� iocn 0λ�Ա� 1Ϊ��è
			            	if(list[i].usertype==0){
								icon = '<div class="result_tb"><i class="icons icons_tb"></i><span>&#28120;&#23453;</span></div>';
			            	}else if(list[i].usertype==1){
								icon = '<div class="result_tm"><i class="icons icons_tm"></i><span>&#22825;&#29483;</span></div>';
			            	}
			            	//ͼƬ������
			            	//if(i > 5){
							//	img = '<img class="lazyload result_img fl" src="source/plugin/keke_souquan/template/images/img_nopic.png" data-original="'+img+'"/>';
			            	//}else{
			            		img = '<img class="fl result_img" src="'+img+'" alt="">';
			            	//}
			            	
		            		temHtml += '<li><a href="javascript:;" target="_blank" data-tkl="" data-iid="'+list[i].numiid+'" data-img="'+list[i].img+'" data-title="'+list[i].title+'" data-price="'+price+'" data-url="'+list[i].url+'">'+img+'<div class="result_info border_b"><p class="result_title">'+list[i].title+'</p>'+icon+'<p class="result_price">&#65509;<span class="price_value">'+price+'</span><span class="price_other">&#21048;&#21518;&#20215;</span></p><div class="result_bottom cf"><span class="result_ticket fl">&#39046;'+list[i].quota+'&#20803;&#21048;</span><span class="fr ticket_number">'+list[i].volume+'&#20154;&#39046;&#29992;</span></div></div></a></li>';
							
		            	}
						
		            	if(loadType=='more'){
		            		$resultList.append(temHtml);
		            	}else{
		            		$resultList.html(temHtml);
		            	}
						if (isIos()){
							var _images = $("img.lazyload");
							$('#sqt_result').scroll(function () {
						        for (var i = 0; i < _images.length; i++) {
						            var image = _images.eq(i);
						            if (image.attr("data-original") && (image.offset().top < $(window).scrollTop() + $(window).height())) {
						                image.attr("src", image.attr("data-original"));
						                image.removeAttr("data-original");
						                image.removeClass("lazyload");
						            }
						        }
						    });
						}else{
							lazyLoading($("img.lazyload"));
						}
		            },
		            error:function(){
		            	waiting = false;
		            	$load.hide();
		                promptPop({ content: '&#21830;&#21697;&#33719;&#21462;&#22833;&#36133;'});
		            }
		        });
			}else{
				waiting = false;
				$load.hide();
				$noList.show();
			}
		},
		//��������
		searchInfo:function(){
			var $search = $('#search'),
				that = this,
				$goSearch = $('#go_search'),
				$searchForm = $('#search_form'),
				$searchList = $('#search_list');
			$search.val(search);
			//�����ȯ��ť
			$searchList.on('click','li',function(){
				search = $(this).find('a').html().replace(/<\/?[^>]*>/g,'');
				that.saveCookie();
				$search.val(search);
				that.getData($loading,'',type);
			});
			//������̵�����
			$searchForm.on('search',function(){
				search = $search.val();
				if(!filterKey(search)){
					return false;
				}
				that.saveCookie();
				$search.blur();
				isLoadMore = true;
				that.getData($loading,'',type);
			});
			//�������
			$goSearch.on('click',function(){
				search = $search.val();
				if(!filterKey(search)){
					return false;
				}
				that.saveCookie();
				isLoadMore = true;
				that.getData($loading,'',type);
			});
		},
		init:function(){
			this.getList();
			this.searchInfo();
			//�����Կ���
			showTkl($resultList,'getKtl');
		}
	};
	funList.init();
};