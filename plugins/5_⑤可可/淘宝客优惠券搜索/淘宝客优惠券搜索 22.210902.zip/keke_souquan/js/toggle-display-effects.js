//切换显示效果
$(function(){
	//第二屏导航点击切换效果
	$(".vb2-nav ul li").mouseover(function(){
		$(this).siblings().children("span").removeClass("vb2-cur")
		$(this).children("span").addClass("vb2-cur");
	});
	//金额点击排序效果
	$("#vb2-sort").toggle(function(){
		$(this).children(".vb2-price-sort").attr("src","images/btn_ low_to_high.png");
	},function(){
		$(this).children(".vb2-price-sort").attr("src","images/btn_ hign_to_lowh.png");
	});
	//footer底部点击切换效果
	$("footer ul li").click(function(){
		$(this).addClass("footer-cur").siblings().removeClass("footer-cur");
		
		$(this).children(".ft-nav").css("visibility","hidden");
		$(this).children(".ft-nav-selected").css({"display":"block"});
		$(this).siblings().children(".ft-nav").css({"visibility":"visible"});
		$(this).siblings().children(".ft-nav-selected").css("display","none");
		
	});
	//返回顶部出现+获取屏幕高度
	var clientH = document.body.clientHeight;
	$(window).on('scroll', function(){
		if($(window).scrollTop() >= 100){
			$(".backTop").fadeIn(100);
			if($(window).scrollTop() > clientH){
				$(".view-box2 .vb2-nav").addClass("navShow");
			}else{
				$(".view-box2 .vb2-nav").removeClass("navShow");
			}
		} else {
			$(".backTop").fadeOut(100);
			
		}
	});
	
	//我的--点击退出 弹出dialog
	$(".logout").mouseover(function(){ 
		$(".my-drop-out-box").fadeIn(300);
		$("footer").addClass("zIndexLow");
	});
	$(".dropOut").mouseover(function(){
		top.location = "/index.php?m=home&c=user&a=logout";
    	return false;
	});
	$(".laterOn").mouseover(function(){
		$(".my-drop-out-box").hide();
		$("footer").removeClass("zIndexLow");
	});
	//获取现金总额
	var cashBalance = parseFloat($(".cash-balance span").html());
	//js写入可提取的现金金额
	$(".accext-input span").html(cashBalance);

	//方法1 ：申请提现 确认提取设置
	$(".alipay-focus").blur(function(){
		//支付宝账号输入
		if($('.wechat-focus').val() !=undefined &&  $('.alipay-focus').val() !=undefined && $('.mobile-focus').val() !=undefined && $('.mobile-focus').val() !=null && $('.wechat-focus').val() !=null && $('.alipay-focus').val() !=null){
			//解除禁止更改样式
			$(".submit-btn").removeClass("submit-btn-off").addClass("submit-btn-on");
		}else{
            $(".submit-btn").removeClass("submit-btn-on").addClass("submit-btn-off");
		}
	});

	/*方法2 ：申请提现 确认提取设置
	var btnSwitch = true ;
	$(".alipay-focus").blur(function(){
		var dom = $("[class*='submit-btn-']");
		if($(this).val() !=undefined && $(this).val() !=null && $(this).val()!=""){
			if(btnSwitch){
				dom[0].className = "submit-btn-on" ;
				btnSwitch = false ;
			}
		}else{
			dom[0].className = "submit-btn-off";
			btnSwitch = true ;
		}
	});
	*/
    $("#submitBtn").click(function(){
        if($(this).hasClass("submit-btn-on")){
			var balanceCash = parseFloat($(".cash-balance span").html());
			ali_account = $('.alipay-focus').val();
			wechat = $('.wechat-focus').val();
			mobile = $('.mobile-focus').val();
			if(balanceCash >= apply_limit){
				$.get(url,{ali_account:ali_account,wechat:wechat,mobile:mobile},function(json){
					if(json.state){
						$(".drawTipsBox").show();
                		$(".drawCashSuccess").show();
					}else{
						$('.dcl-desc').html(json.msg);
						$(".drawTipsBox").show();
                		$(".drawCashLose").show();
					}
				})
			}else{
                $(".drawTipsBox").show();
                $(".drawCashLose").show();
			}
        }else{

        }
    });
    //关闭窗口
		//成功
	$(".dcs-ok").click(function(){
        $(".drawTipsBox").hide();
        $(".drawCashSuccess").hide();
        //提交表单
        $("#drawCashForm").submit();
	});
		//失败
    $(".dcl-ok").click(function(){
        $(".drawTipsBox").hide();
        $(".drawCashLose").hide();
    })

});

 //置顶事件
function topBack(){
  $('body,html').animate({scrollTop:0},300);
}
