<?php

/**
 * resultList
 * @author auto create
 */
class MapData
{
	
	/** 
	 * 商品信息-叶子类目id
	 **/
	public $category_id;
	
	/** 
	 * 商品信息-叶子类目名称
	 **/
	public $category_name;
	
	/** 
	 * 链接-宝贝推广链接
	 **/
	public $click_url;
	
	/** 
	 * 商品信息-佣金比率(%)
	 **/
	public $commission_rate;
	
	/** 
	 * 优惠券信息-优惠券面额。如：满299元减20元
	 **/
	public $coupon_amount;
	
	/** 
	 * 链接-宝贝+券二合一页面链接(该字段废弃，请勿再用)
	 **/
	public $coupon_click_url;
	
	/** 
	 * 优惠券信息-优惠券结束时间
	 **/
	public $coupon_end_time;
	
	/** 
	 * 优惠券信息-优惠券满减信息
	 **/
	public $coupon_info;
	
	/** 
	 * 优惠券信息-优惠券剩余量
	 **/
	public $coupon_remain_count;
	
	/** 
	 * 链接-宝贝+券二合一页面链接
	 **/
	public $coupon_share_url;
	
	/** 
	 * 优惠券信息-优惠券起用门槛，满X元可用。如：满299元减20元
	 **/
	public $coupon_start_fee;
	
	/** 
	 * 优惠券信息-优惠券开始时间
	 **/
	public $coupon_start_time;
	
	/** 
	 * 优惠券信息-优惠券总量
	 **/
	public $coupon_total_count;
	
	/** 
	 * 商品信息-宝贝描述（推荐理由,不一定有）
	 **/
	public $item_description;
	
	/** 
	 * 商品信息-宝贝id
	 **/
	public $item_id;
	
	/** 
	 * 拼团专用-拼团几人团
	 **/
	public $jdd_num;
	
	/** 
	 * 拼团专用-拼团拼成价，单位元
	 **/
	public $jdd_price;
	
	/** 
	 * 聚划算信息-聚淘结束时间
	 **/
	public $ju_online_end_time;
	
	/** 
	 * 聚划算信息-聚淘开始时间
	 **/
	public $ju_online_start_time;
	
	/** 
	 * 商品信息-一级类目ID
	 **/
	public $level_one_category_id;
	
	/** 
	 * 商品信息-一级类目名称
	 **/
	public $level_one_category_name;
	
	/** 
	 * 猫超玩法信息-折扣条件，价格百分数存储，件数按数量存储。可以有多个折扣条件，与折扣字段对应，','分割
	 **/
	public $maochao_play_conditions;
	
	/** 
	 * 猫超玩法信息-玩法类型，2:折扣(满n件折扣),5:减钱(满n元减m元)
	 **/
	public $maochao_play_discount_type;
	
	/** 
	 * 猫超玩法信息-折扣，折扣按照百分数存储，其余按照单位分存储。可以有多个折扣，','分割
	 **/
	public $maochao_play_discounts;
	
	/** 
	 * 猫超玩法信息-活动结束时间，精确到毫秒
	 **/
	public $maochao_play_end_time;
	
	/** 
	 * 猫超玩法信息-当前是否包邮，1:是，0:否
	 **/
	public $maochao_play_free_post_fee;
	
	/** 
	 * 猫超玩法信息-活动开始时间，精确到毫秒
	 **/
	public $maochao_play_start_time;
	
	/** 
	 * 多件券单品件数
	 **/
	public $multi_coupon_item_count;
	
	/** 
	 * 多件券优惠比例
	 **/
	public $multi_coupon_zk_rate;
	
	/** 
	 * 商品信息-新人价
	 **/
	public $new_user_price;
	
	/** 
	 * 店铺信息-卖家昵称
	 **/
	public $nick;
	
	/** 
	 * 拼团专用-拼团结束时间
	 **/
	public $oetime;
	
	/** 
	 * 拼团专用-拼团一人价（原价)，单位元
	 **/
	public $orig_price;
	
	/** 
	 * 拼团专用-拼团开始时间
	 **/
	public $ostime;
	
	/** 
	 * 商品信息-商品主图
	 **/
	public $pict_url;
	
	/** 
	 * 多件券件单价
	 **/
	public $price_after_multi_coupon;
	
	/** 
	 * 商品信息-一口价
	 **/
	public $reserve_price;
	
	/** 
	 * 拼团专用-拼团已售数量
	 **/
	public $sell_num;
	
	/** 
	 * 店铺信息-卖家id
	 **/
	public $seller_id;
	
	/** 
	 * 店铺信息-店铺名称
	 **/
	public $shop_title;
	
	/** 
	 * 商品信息-商品短标题
	 **/
	public $short_title;
	
	/** 
	 * 商品信息-商品小图列表
	 **/
	public $small_images;
	
	/** 
	 * 拼团专用-拼团剩余库存
	 **/
	public $stock;
	
	/** 
	 * 商品信息-商品标题
	 **/
	public $title;
	
	/** 
	 * 营销-天猫营销玩法
	 **/
	public $tmall_play_activity_info;
	
	/** 
	 * 拼团专用-拼团库存数量
	 **/
	public $total_stock;
	
	/** 
	 * 店铺信息-卖家类型，0表示集市，1表示商城
	 **/
	public $user_type;
	
	/** 
	 * 商品信息-预售数量
	 **/
	public $uv_sum_pre_sale;
	
	/** 
	 * 商品信息-30天销量
	 **/
	public $volume;
	
	/** 
	 * 商品信息-商品白底图
	 **/
	public $white_image;
	
	/** 
	 * 商品信息-商品关联词
	 **/
	public $word_list;
	
	/** 
	 * 物料块id(测试中请勿使用)
	 **/
	public $x_id;
	
	/** 
	 * 商品信息-商品折扣价格
	 **/
	public $zk_final_price;	
}
?>