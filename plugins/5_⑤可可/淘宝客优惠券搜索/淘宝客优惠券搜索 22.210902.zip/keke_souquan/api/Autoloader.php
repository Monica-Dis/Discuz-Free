<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class Autoloader{
  
  /**
     * 类库自动加载，写死路径，确保不加载其他文件。
     * @param string $class 对象类名
     * @return void
     */
    public static function autoload($class) {
        $name = $class;
        if(false !== strpos($name,'\\')){
          $name = strstr($class, '\\', true);
        }
        
        $filename = DISCUZ_ROOT.'source/plugin/keke_souquan/api'."/top/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/keke_souquan/api'."/top/request/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/keke_souquan/api'."/top/domain/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/keke_souquan/api'."/aliyun/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/keke_souquan/api'."/aliyun/request/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/keke_souquan/api'."/aliyun/domain/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }      

        $filename = DISCUZ_ROOT.'source/plugin/keke_souquan/api'."/dingtalk/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }
        $filename = DISCUZ_ROOT.'source/plugin/keke_souquan/api'."/dingtalk/request/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }

        $filename = DISCUZ_ROOT.'source/plugin/keke_souquan/api'."/dingtalk/domain/".$name.".php";
        if(is_file($filename)) {
            include $filename;
            return;
        }   
    }
	
}

if (version_compare(phpversion(),'5.3.0','>=')) {
    spl_autoload_register('Autoloader::autoload',false,true);
}else{
    Autoloader::autoload("TopClient");
    Autoloader::autoload("TopLogger");
    Autoloader::autoload("TbkItemInfoGetRequest");
	Autoloader::autoload("tbkuatmfavoritesgetrequest");
	Autoloader::autoload("TbkUatmFavoritesItemGetRequest");
    Autoloader::autoload("ResultSet");
    Autoloader::autoload("AliyunClient");
    Autoloader::autoload("HttpdnsGetRequest");
    Autoloader::autoload("RequestCheckUtil");
	Autoloader::autoload("TbkDgItemCouponGetRequest");
	Autoloader::autoload("TbkTpwdCreateRequest");
	
}
//From: Dism·taobao·com
?>