<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

include_once DISCUZ_ROOT."source/plugin/keke_souquan/identity.inc.php";

$iswx='';
if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
	$iswx=1;
}
function get_sett(){
	global $_G;
	$var = $_G['cache']['plugin']['keke_souquan'];
	$pid=dhtmlspecialchars($var['pid']);
	$pidarr=explode("_",$pid);
	$returns['adzoneid']=$pidarr[3];
	$returns['appkey']=trim($var['appkey']);
	$returns['secret']=trim($var['secret']);
	return $returns;
}
function get_haoquan($keyw,$p){
	global $_G;
	$var = $_G['cache']['plugin']['keke_souquan'];
	if($var['px']){
		if($var['px']==1){
			$sort='total_sales_des';
		}elseif($var['px']==2){
			$sort='tk_rate_des';
		}elseif($var['px']==3){
			$sort='tk_total_sales_des';
		}elseif($var['px']==4){
			$sort='tk_total_commi_des';
		}
	}

	$tmall=($var['tmall'])?'true':'false';
	$var=get_sett();
	$adzone_id=$var['adzoneid'];
	$c = new TopClient;
	$c->appkey = trim($var['appkey']);
	$c->secretKey = trim($var['secret']);
	$req = new TbkDgMaterialOptionalRequest;
	$req->setQ(gbk2utf(strval($keyw)));
	$req->setAdzoneId($adzone_id);
	$req->setPageNo(strval($p));
	$req->setSort($sort);
	$req->setIsTmall($tmall);
	$req->setHasCoupon("true");
	$resp = $c->execute($req);
	if($_GET['debug']){
		print_r($resp);
	}
	return json_decode(json_encode($resp),true);
}
function _get_goodsarr($key,$page){
	$data=get_haoquan($key,$page);
	if($data['result_list']['map_data'][0]){
		foreach($data['result_list']['map_data'] as $val){
			$quan=$val['coupon_total_count']-$val['coupon_remain_count'];
			$preice=$val['zk_final_price']-$val['coupon_amount'];
			$title=$type? utf2gbk($val['title']) :$val['title'];
			$img=str_ireplace("http:","https:",$val['pict_url']);
			$goods[]=array (
			  'numiid' => $val['item_id'],
			  'url' => $val['coupon_share_url'],
			  'img' => $img.'_300x300.jpg',
			  'title' => $title,
			  'price' => floatval($preice),
			  'quota' => floatval($val['coupon_amount']),
			  'volume' => intval($quan),
			  'usertype' => intval($val['user_type']),
			);
		}
	}
	return $goods;
}
function _get_hotgoods($page){
	global $_G;
	$keke_souquan = $_G['cache']['plugin']['keke_souquan'];
	$key='';
	$goods=array();
	if($keke_souquan['hotc']){
		$keystr=gbk2utf($keke_souquan['hotc']);
		$keyarr=explode(",",$keke_souquan['hotc']);
		$rand_keys = array_rand ($keyarr,1);
		$key=$keyarr[$rand_keys];
	}
	if(($key && $page<=5) || (!$key && $page<=20)){
		require_once libfile('function/cache');
		loadcache('keke_souquan_cache');
		$jg=intval($keke_souquan['hotj']*60);
		$cachegoods=$_G['cache']['keke_souquan_cache'];
		if(!$cachegoods[$page]['data'] || $cachegoods[$page]['time']+$jg<$_G['timestamp']){
			$goods=_get_goodsarr($key,$page);
			$cachegoods=$cachegoods?$cachegoods:array();
			$info=$cachegoods;
			$info[$page]['data']=$goods;
			$info[$page]['time']=$_G['timestamp'];
			savecache('keke_souquan_cache', $info);
		}else{
			$goods=$cachegoods[$page]['data'];
		}
	}
	return $goods;
}
function get_tkl($text,$url,$logo,$numiid){
	$numiid=daddslashes($numiid);
	C::t('#keke_souquan#keke_souquan')->delete_by_time();
	

	$tklarr=C::t('#keke_souquan#keke_souquan')->fetchfirst_byid($numiid);
	if($tklarr['tkl'] && ($tklarr['time']+86400>TIMESTAMP)){
		$kouling=gbk2utf($tklarr['tkl']);
	}else{
		$var=get_sett();
		$c = new TopClient;
		$c->appkey = trim($var['appkey']);
		$c->secretKey = trim($var['secret']);
		
		$req = new TbkTpwdCreateRequest;
		$req->setText($text);
		$req->setUrl($url);
		$req->setLogo($logo);
		$req->setExt("{}");
		$resp = $c->execute($req);

		
		$dd= json_decode(json_encode($resp),true);
		$kouling=$dd['data']['model'];
		$koulings=$kouling;
		if(strtolower(CHARSET) == 'gbk') {
			$koulings=utf2gbk($kouling);
		}
		$arr=array('num_iid'=>$numiid,'tkl'=>$koulings,'time'=>TIMESTAMP);
		if($tklarr){
			C::t('#keke_souquan#keke_souquan')->update($tklarr['id'],$arr);	
		}else{
			C::t('#keke_souquan#keke_souquan')->insert($arr, true);	
		}
	}
	return $kouling;
}

function _get_couponval($coupon){
	$f02=CHARSET=='gbk'?iconv('gbk','utf-8//IGNORE',lang('plugin/keke_souquan', 'f02')):lang('plugin/keke_souquan', 'f02');
	$f01=CHARSET=='gbk'?iconv('gbk','utf-8//IGNORE',lang('plugin/keke_souquan', 'f01')):lang('plugin/keke_souquan', 'f01');
	$f03=CHARSET=='gbk'?iconv('gbk','utf-8//IGNORE',lang('plugin/keke_souquan', 'f03')):lang('plugin/keke_souquan', 'f03');
	$couponarra=explode($f02,$coupon);
	$carr=explode($f01,$couponarra[1]);
	$ret[0]=str_ireplace($f03,'',$couponarra[0]);
	$ret[1]=$carr[1];
	return $ret;
}


function convertUrlQuery($query){
	$queryParts = explode('&', $query);
	$params = array();
	foreach ($queryParts as $param){
		$item = explode('=', $param);
		$params[$item[0]] = $item[1];
	}
	return $params;
}
	

function utf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return gbk2utf($data);
	}
}
function gbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}
