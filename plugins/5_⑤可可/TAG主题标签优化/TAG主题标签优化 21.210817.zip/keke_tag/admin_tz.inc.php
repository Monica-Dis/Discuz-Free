<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$table = array();
	showtips(lang('plugin/keke_tag', 'f10'));
    showtableheader(lang('plugin/keke_tag', 'f01'));	
    showsubtitle(array(lang('plugin/keke_tag', 'f02'), lang('plugin/keke_tag', 'f03'), lang('plugin/keke_tag', 'f05')));
	$wap=file_exists("source/plugin/keke_tag/keke_settag.php")? '<span class="diffcolor2">'.lang('plugin/keke_tag', 'f08').'</span>' : '<a href="http://addon.discuz.com/?@keke_tag.plugin.78141"><span class="error">'.lang('plugin/keke_tag', 'f09').'</span></a>';		
	$table[0] = lang('plugin/keke_tag', 'f06');
	$table[1] = '<span class="light">'.lang('plugin/keke_tag', 'f07').'</span>';
	$table[2] = $wap;
	showtablerow('', array('width="150"', 'width="380"'), $table);	
    showtablefooter();