<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	if ($_GET['ac']=="forumset") {
		$ppp=5;
		$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_tag&pmod=admin_history';
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$go=0;
		$alltid=DB::fetch_all("select pid,tid,subject from ".DB::table('forum_post')." where first=1 AND tags in ('',0)  ORDER BY tid DESC LIMIT ".$startlimit.",".$ppp);
		if($alltid){
			foreach($alltid as $k=>$v){
				$results=_gettags($v['subject']);
				$newtagclass = new tag();
				$tags = $newtagclass->add_tag($results, $v['tid'], 'tid');
				if($results) {
					loadcache('censor');
					C::t('forum_post')->update('tid:'.$v['tid'], $v['pid'], array(
					'tags' => $tags,
					));
				}
			}
			$go=1;
			$netpage=$page+1;
			$count=$_GET['count']+count($alltid);
		}
		if($go){
			cpmsg(lang('plugin/keke_tag', 'f11').$page.lang('plugin/keke_tag', 'f12'), 'action=plugins&operation=config&identifier=keke_tag&pmod=admin_history&ac=forumset&page='.$netpage.'&count='.$count.'&formhash='.FORMHASH, 'loading', '', FALSE);
		}
		cpmsg(lang('plugin/keke_tag', 'f13'), 'action=plugins&operation=config&identifier=keke_tag&pmod=admin_history', 'succeed');
	}
	
	$notagcount=DB::result_first("select count(1) from ".DB::table('forum_post')." where first=1 AND tags in ('',0)");
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_tag&pmod=admin_history';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$alltid=DB::fetch_all("select pid,tid,subject,dateline from ".DB::table('forum_post')." where first=1 AND tags in ('',0) ORDER BY tid DESC LIMIT ".$startlimit.",".$ppp);
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_history");
	showtips('<li>'.lang('plugin/keke_tag', 'f14').' <font color="#C30"><b>'.$notagcount.'</b></font> '.lang('plugin/keke_tag', 'f21').'</li>'.lang('plugin/keke_tag', 'f20'));
   
   	showtableheader(lang('plugin/keke_tag', 'f15'));
    showtablerow('',array(''), array('<input type="hidden" name="formhash" value="'.FORMHASH.'" /><input type="hidden" name="ac" value="forumset" /><div style="margin:10px 0;"><input type="submit" class="btn" id="submit_forumset" name="forumset" title="" value="'.lang('plugin/keke_tag', 'f16').'"></div>'));
	
    showtableheader(lang('plugin/keke_tag', 'f17'));
    showsubtitle(array(lang('plugin/keke_tag', 'f18'),lang('plugin/keke_tag', 'f19')));

	foreach($alltid as $k=>$v){
		$table = array();
        $table[0] = '<a href="forum.php?mod=viewthread&tid='.$v['tid'].'" target="_blank">'.$v['subject'].'</a>';
        $table[2] = dgmdate($v['dateline'], 'Y/m/d H:i');
        showtablerow('',array(), $table);
	}
	$multipage='';
	$multipage = multi($notagcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
    
    showtablefooter();
    showformfooter();
