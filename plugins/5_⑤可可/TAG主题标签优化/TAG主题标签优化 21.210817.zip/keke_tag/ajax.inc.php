<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
loadcache('plugin');
$keke_tag = $_G['cache']['plugin']['keke_tag'];
include_once DISCUZ_ROOT . 'source/plugin/keke_tag/identity.inc.php';
global $_G;
loadcache('plugin');
$keke_tag = $_G['cache']['plugin']['keke_tag'];
include_once DISCUZ_ROOT . 'source/plugin/keke_tag/identity.inc.php';
if ($_GET['formhash'] != $_G['formhash']) {
	exit('formhasherr');
}
if (!$s) {
	$return = _gettags($_GET['subjectenc']);
	if ($return) {
		$_G['inajax'] = 1;
		include template('forum/relatekw');
	}
}
function _gettags($subject)
{
	global $_G;
	$keke_tag = $_G['cache']['plugin']['keke_tag'];
	$subjectenc = rawurlencode(strip_tags($subject));
	$return = '';
	if ($subject) {
		switch ($keke_tag['mode']) {
			case 1:
				$return = pullwordgetkw($subject);
				break;
			case 2:
				$return = baidugetkws($subjectenc);
				break;
			case 3:
				$return = baidugetkw($subject);
		}
	}
	return $return;
}
function pullwordgetkw($subjectenc)
{
	$subjectenc = CHARSET == 'gbk' ? taggbk2utf($subjectenc) : $subjectenc;
	$sbj = urlencode($subjectenc);
	$url = 'http://api.pullword.com/get.php?source=' . $sbj . '&param1=0.9&param2=0';
	$data = file_get_contents($url);
	$keyword_list = trim(CHARSET == 'gbk' ? tagutf2gbk($data) : $data);
	$keyword_arr = explode("\r\n", $keyword_list);
	$keyw = '';
	if ($keyword_list != 'error') {
		$keyw = implode(',', $keyword_arr);
	}
	return $keyw;
}
function baidugetkw($subjectenc)
{
	$subjectenc = CHARSET == 'gbk' ? taggbk2utf($subjectenc) : $subjectenc;
	$header = array('Accept:text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8', 'Accept-Encoding:gzip, deflate, br', 'Accept-Language:zh-CN,zh;q=0.9', 'Cache-Control:max-age=0', 'Connection:keep-alive', 'Host:www.baidu.com', 'Upgrade-Insecure-Requests:1', 'User-Agent:' . $_SERVER['HTTP_USER_AGENT']);
	$w = kekeTagCurl($header, 'http://www.baidu.com/s?wd=' . urlencode($subjectenc));
	preg_match_all('/<div id=\\"rs\\">(.*)<\\/div>/i', $w, $con);
	$list = $con[1][0];
	preg_match_all('|<a([^\\>]*)?href=(.*)>(.*)</a>|isU', $list, $content);
	$result = tagutf2gbk(implode(',', $content[3]));
	return $result;
}
function kekeTagCurl($header, $url)
{
	if (function_exists('curl_init') && function_exists('curl_exec')) {
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 20);
		curl_setopt($ch, CURLOPT_TIMEOUT, 20);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
		curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
		$ret = curl_exec($ch);
		$status = curl_getinfo($ch);
		$errno = curl_errno($ch);
		curl_close($ch);
		if ($errno || $status['http_code'] != 200) {
			return 'curl_Err' . $errno;
		}
		return $ret;
	}
	return 'curl_Err';
}
function baidugetkws($subjectenc)
{
	$w = file_get_contents('http://zhannei.baidu.com/api/customsearch/keywords?title=' . taggbk2utf($subjectenc));
	$aa = json_decode($w, true);
	$kwss = $aa['result']['res']['wordrank'];
	foreach ($kwss as $k => $v) {
		$b = explode(':', $v);
		if ($b[2] > 0) {
			$tt[] = $b[0];
		}
	}
	$result = tagutf2gbk(implode(',', $tt));
	return $result;
}
function tagutf2gbk($data)
{
	$data = dhtmlspecialchars($data);
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	if (CHARSET == 'gbk') {
		return $tmpstr;
	}
	return taggbk2utf($data);
}
function taggbk2utf($data)
{
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	return diconv($tmpstr, 'gbk', 'utf-8');
}