<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
exit('Access Denied');}

global $_G;
$keke_ds = $_G['cache']['plugin']['keke_ds'];
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
if($keke_ds['zz']){
	showmessage(lang('plugin/keke_ds', 'zsgb'), '');
}
$dssize =  $keke_ds['size'] ? ($keke_ds['size'])*1000 : 100000;
$o=intval($_GET['o']) ? intval($_GET['o']) : 0;
$x='';$x[$o]='class="a"';
if($o==2){$wm='picurla';}else{$wm='picurl';}
$coun=DB::result_first("select count(1) from ".DB::table('keke_ds')." where uid=".$_G['uid']);
if($_GET['pluginop'] == 'update' && submitcheck('submitwater')) {
	$_POST = daddslashes($_POST);
	if($_POST['formhash']!=FORMHASH)return;
	$file = $_POST['file_path'] != 'static/image/common/groupicon.gif' ? trim(substr($_POST['file_path'], strlen('data/keke_ds/'))) : '';
	if ($_FILES['file']['error'] === 0) {
		$upload = new discuz_upload();
		$upload->init($_FILES['file'], 'temp', 101);		
		$basedir = DISCUZ_ROOT.'./data/keke_ds/';
		if(!(is_dir($basedir)))$basedir && discuz_upload::make_dir($basedir);
		
		$upload->attach['target'] = $basedir.'./'.$upload->attach['attachment'];
		
		if($upload->error()) {
			showmessage(lang('plugin/keke_ds', 'scsb'), 'home.php?mod=spacecp&ac=plugin&id=keke_ds:keke_myds&o='.$o);
		}
		if(!$upload->attach['isimage']) {
			showmessage(lang('plugin/keke_ds', 'bstpgs'), 'home.php?mod=spacecp&ac=plugin&id=keke_ds:keke_myds&o='.$o);
		}
		if($upload->attach['size'] > $dssize) {
			showmessage(lang('plugin/keke_ds', 'tpccdx'), 'home.php?mod=spacecp&ac=plugin&id=keke_ds:keke_myds&o='.$o);
		}
		$upload->save();
		if($upload->error()) {
			showmessage(lang('plugin/keke_ds', 'bcsb'), 'home.php?mod=spacecp&ac=plugin&id=keke_ds:keke_myds&o='.$o);
		}
			$file = $upload->attach['attachment'];
	}
	
	if ($_POST['del'] == 'on') {
		$file_path = $_POST['file_path'];
		if ($file_path != 'static/image/common/groupicon.gif') {
			$full_path = DISCUZ_ROOT.$file_path;
			if(!unlink($full_path)) {
				showmessage(lang('plugin/keke_ds', 'sccg'), 'home.php?mod=spacecp&ac=plugin&id=keke_ds:keke_myds&o='.$o);
			}
		}
		$file = '';
	}
	$file=daddslashes($file);
	if($coun){
		DB::query("update ".DB::table('keke_ds')." set ".$wm."='".$file."' where uid=".$_G['uid']);
	}else{
		DB::query("insert into ".DB::table('keke_ds')."(uid , ".$wm.") values ('".$_G['uid']."' , '".$file."')");
	}
	showmessage(lang('plugin/keke_ds', 'szcg'), 'home.php?mod=spacecp&ac=plugin&id=keke_ds:keke_myds&o='.$o);
}

$text=DB::result_first("select text from ".DB::table('keke_ds')." where uid=".$_G['uid']);
if(!$text) $vl='';else $vl=$text;
$dsy=dhtmlspecialchars($_POST['texta']);
$dsy=daddslashes($dsy);

if($_GET['pluginop'] == 'text' && submitcheck('text')) {
	if($_POST['formhash']!=FORMHASH)return;
	if($coun){
		DB::query("update ".DB::table('keke_ds')." set text='".$dsy."' where uid=".$_G['uid']);
	}else{
		DB::query("insert into ".DB::table('keke_ds')."(uid , text) values ('".$_G['uid']."' , '".$dsy."')");
	}
	showmessage(lang('plugin/keke_ds', 'szcg'), 'home.php?mod=spacecp&ac=plugin&id=keke_ds:keke_myds&o='.$o);
}
$user =DB::fetch_first("select * from ".DB::table('keke_ds')." where uid=".$_G['uid']);
if (empty($user[$wm])) {
	$icon_file = "static/image/common/groupicon.gif";
} else {
	$icon_file = "data/keke_ds/".$user[$wm];
}
if(checkmobile()){
    include_once template('keke_ds:keke_myds');
    exit;
}