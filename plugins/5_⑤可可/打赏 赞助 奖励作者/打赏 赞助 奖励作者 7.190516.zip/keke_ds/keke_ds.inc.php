<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$keke_ds = $_G['cache']['plugin']['keke_ds'];

switch ($keke_ds['styles']){
case 2:
	$zsx='#fca222';$qsbg='#fdf9f3';
	break;  
case 3:
	$zsx='#5fbf5f';$qsbg='#edfded';
	break;
case 4:
	$zsx='#60b4e9';$qsbg='#f3f9fd';
	break;
case 5:
	$zsx='#5788aa';$qsbg='#f3f9fd';
	break;
default:
	$zsx='#e74851';$qsbg='#FEF8F5';
}	
	
$authorid=intval($_GET['zzid']);
$ainfo=DB::fetch_first("select * from ".DB::table('keke_ds')." where uid=".$authorid);

$dsy=($ainfo['text'] && !$keke_ds['zz'])?$ainfo['text']:$keke_ds['dsy'];
if($ainfo && !$keke_ds['zz']){
	$alipay=$ainfo['picurl']?"data/keke_ds/".$ainfo['picurl']:$keke_ds['alipay'];
	$wechat=$ainfo['picurla']?"data/keke_ds/".$ainfo['picurla']:$keke_ds['wechat'];
}else{
	$alipay=$keke_ds['alipay'];
	$wechat=$keke_ds['wechat'];
}


$dspid=intval($_GET['dspid']);
$setewm='';
if($_G['uid']){
	$setewm='<p class="setewm"><a href="home.php?mod=spacecp&ac=plugin&id=keke_ds:keke_myds" target="_blank">'.lang('plugin/keke_ds', 'dssz').'</a></p>';
}

	
include template('keke_ds:tis');