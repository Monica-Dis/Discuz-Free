<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_ds/install.php');
?>