<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_ds= DB::table("keke_ds");
$sql = <<<EOF
CREATE TABLE `$keke_ds` (
  `uid` int(11) NOT NULL,
  `picurl` varchar(50) NOT NULL default '',
  `picurla` varchar(50) NOT NULL default '0',
  `text` varchar(50) NOT NULL default '0',
  `bz` varchar(11) NOT NULL default '0',
  PRIMARY KEY  (`uid`),
  KEY `endtime` (`bz`)
) ENGINE=MyISAM;
EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_ds/discuz_plugin_keke_ds_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_ds/install.php');
?>