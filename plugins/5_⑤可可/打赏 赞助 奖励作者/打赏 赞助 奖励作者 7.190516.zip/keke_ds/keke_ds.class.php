<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
exit('Access Denied');}
	
class plugin_keke_ds_forum {
	function viewthread_postbottom_output(){
		global $_G, $postlist;
		$keke_ds = $_G['cache']['plugin']['keke_ds'];
		require_once DISCUZ_ROOT."source/plugin/keke_ds/function.php";
		$section = empty($keke_ds['bk']) ? array() : unserialize($keke_ds['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){
			return array();
		}
		$gro = empty($keke_ds['yhz']) ? array() : unserialize($keke_ds['yhz']);
		if(!is_array($gro)) $gro = array();
		$return_array=array();
		switch ($keke_ds['styles']){
		case 2:
			$bpo='0px -49px';
			$bpoh='-134px -49px';
			$zsx='#fca222';
			break;  
		case 3:
		 	$bpo='0px -98px';
			$bpoh='-134px -98px';
			break;
		case 4:
		 	$bpo='0px -147px';
			$bpoh='-134px -147px';
			break;
		case 5:
		 	$bpo='0px -196px';
			$bpoh='-134px -196px';
			break;
		default:
		  	$bpoh='-134px 0px';
			$bpo='';
		}
		if($keke_ds['htds']==2){
			foreach($postlist as $key=>$val){
				$zzid=$postlist[$key]['authorid'];
				include template('keke_ds:index');
				if($zzid){
					$autgro=getgroupid($zzid);
				}
				if($val['pid']){
					$ainfo=getainfo($val['pid']);
				}
				if(($keke_ds['yhewm']==1 && !$ainfo) || !(empty($gro[0]) || in_array($autgro,$gro))){
					$return='';
				}
				$return_array[]=$return;
			}
		}else{
			$zzid=$_G['thread']['authorid'];
			if(!$_G['forum_firstpid']){
				return array();
			}
			$ainfo=getainfo($_G['forum_firstpid']);
			include template('keke_ds:index');
			$autgro=getgroupid($zzid);
			if(!(empty($gro[0]) || in_array($autgro,$gro))){
				return array();
			}
			if($keke_ds['yhewm']==1 && !$ainfo){
				$return='';
			}	
			if($_G['forum_firstpid']){
				$return_array[0]=$return;
			}
		}		
		return $return_array;
	}
}

class mobileplugin_keke_ds_forum{
	function viewthread_postbottom_mobile_output(){
		global $_G, $postlist;
		$keke_ds = $_G['cache']['plugin']['keke_ds'];
		require_once DISCUZ_ROOT."source/plugin/keke_ds/function.php";	
		$section = empty($keke_ds['bk']) ? array() : unserialize($keke_ds['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section)) || !$keke_ds['mobile']){
			return array();
		}
		
		switch ($keke_ds['styles']){
		case 2:
			$zsx='#fca222';$qsbg='#fdf9f3';
			$topcolor='#f46b45, #eea849';
			break;  
		case 3:
			$zsx='#5fbf5f';$qsbg='#f5fff5';
			$topcolor='#56ab2f, #a8e063';
			break;
		case 4:
			$zsx='#60b4e9';$qsbg='#f3f9fd';
			$topcolor='#1a60a7, #3498db';
			break;
		case 5:
			$zsx='#5788aa';$qsbg='#f3f9fd';
			$topcolor='#2c3e50, #3498db';
			break;
		default:
			$zsx='#e74851';$qsbg='#FEF8F5';
			$topcolor='#cb2d3e, #ef473a';
		}
	
		$return="
		<script>	
		function keke_ds_get(v,pid){	
			var vv = v;
			$('#loadingboxs').show();
			$.ajax({type:'GET',url:'plugin.php?id=keke_ds:keke_ds&dsd=1&zzid=' + vv+'&dspid='+pid,})
			.success(function(s) {document.getElementById('keke_dsb' + pid).innerHTML=s;$('#loadingboxs').hide();})
			.error();return false;
		}
		function kenull(v){	
			var vv = v;	
			document.getElementById('keke_dsb' + vv).innerHTML=null
		}
		function setTab(name,m,n){ 
			for( var i=1;i<=n;i++){ 
				var menu = document.getElementById(name+i); 
				var showDiv = document.getElementById(\"cont_\"+name+\"_\"+i); 
				menu.className = i==m ? \"on\":\"\"; 
				showDiv.style.display = i==m?\"block\":\"none\"; 
			} 	
		}
		</script>";	
		
		$sty=" <div class=boxds id=\"loadingboxs\" style=\"display:none\"><div class=loading><div class=pic><i></i><i></i><i></i><i></i><i></i></div></div></div>
		<style>.loading .pic{width:64px;height:64px;position:absolute;top:0;bottom:0;left:0;right:0;margin:auto}
		.loading .pic i{display:block;float:left;width:6px;height:50px;background:#fff;margin:0 2px;transform:scaleY(.4);animation:load 1.2s infinite}
		.loading .pic i:nth-child(1){animation-delay:.1s}
		.loading .pic i:nth-child(2){animation-delay:.2s}
		.loading .pic i:nth-child(3){animation-delay:.3s}
		.loading .pic i:nth-child(4){animation-delay:.4s}
		.loading .pic i:nth-child(5){animation-delay:.5s}
		@keyframes load{0%,100%,40%{transform:scaleY(.4)}20%{transform:scaleY(1)}}
		.tab ul li.on{ border:".$zsx." 2px solid; color: #000;} 
		.tabList .one img{ padding:15px; border:3px dashed ".$zsx."; border-radius:12px;width: 150px;height: 150px;}
		#ds .dsbox{ background:".$qsbg."}
		#boxds,.boxds{position: fixed; width: 100%;height: 100%;background: rgba(0,0,0,0.33);top:0;left:0;z-index:999;}  
		.dsshow{ width:80px; height:25px; text-align:center; color:".$zsx." !important;box-shadow:0 0 20px 7px ".$qsbg." ; border:1px solid ".$zsx.";  background:".$qsbg."; margin:10px auto; display:block;line-height:25px; border-radius:25px;font-size:14px;text-decoration:none !important; z-index:99999}
		.dsclose{ width:100%; display:block;height:35px;line-height:35px; color:#FFFFFF; background: linear-gradient(to right, ".$topcolor."); text-align:center;font-size:16px}
		 #cont_one_1 img,#cont_one_2 img{width:150px !important; height:150px !important;}
		 .tabss UL LI.on{border:2px solid ".$zsx.";}
		</style>";
		
		$return_array='';
		$n=1;
		foreach($postlist as $key=>$val){
			$return_array='<a href="javascript:;" onClick="keke_ds_get('.$val['authorid'].','.$val['pid'].');"  class="dsshow"> '.lang('plugin/keke_ds', 'ds').'Ta</a>
			<div id="keke_dsb'.$val['pid'].'"></div>';
			$zzid=$postlist[$key]['authorid'];
			if($zzid){
				$autgro=getgroupid($zzid);
			}
			if($val['pid']){
				$ainfo=getainfo($val['pid']);
			}
			$gro = empty($keke_ds['yhz']) ? array() : unserialize($keke_ds['yhz']);
			if(!(empty($gro[0]) || in_array($autgro,$gro)) || ($keke_ds['yhewm']==1 && !$ainfo)){
				$return_array='';
			}
			
			if($_G['forum_firstpid']==$val['pid']){
				$res[]=$return_array;
			}else{
				if($keke_ds['htds']==2){
					$res[]=$return_array;
				}
			}
			$n++;
		}
		$res[0]=$res[0].$return.$sty;
		return $res;
	}
}