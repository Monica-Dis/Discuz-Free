<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function arrtoxml($data)
{
	$xml = '<xml>';
	foreach ($data as $key => $val) {
		if (is_numeric($val)) {
			$xml .= '<' . $key . '>' . $val . '</' . $key . '>';
		} else {
			$xml .= '<' . $key . '><![CDATA[' . $val . ']]></' . $key . '>';
		}
	}
	$xml .= '</xml>';
	return $xml;
}
function _orderid()
{
	global $_G;
	$nowdate = dgmdate($_G['timestamp'], 'YmdHis');
	$random = random(10);
	$orderid = $nowdate . $random;
	return $orderid;
}
function _createjson($jsApiParameters, $orderid)
{
	$arrs = json_decode($jsApiParameters);
	$ret = array('jsapi' => $arrs, 'orderids' => $orderid);
	return json_encode($ret);
}
function _sensms($text, $phone, $alitmpid)
{
	global $_G;
	$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
	if (file_exists(DISCUZ_ROOT . './source/plugin/keke_sms/sendsms.php')) {
		$alisign = dhtmlspecialchars(trim($keke_chongzhi['sign']));
		$alitmpid = dhtmlspecialchars(trim($alitmpid));
		@(include_once DISCUZ_ROOT . './source/plugin/keke_sms/sendsms.php');
		$kekesmsapi = new kekesmsapi();
		$return = $kekesmsapi->kekesendsms($phone, $alisign, $text, $alitmpid, $keke_chongzhi['smschannel']);
	}
	return $return;
}
function _czsms($credit = '', $money = '', $type = '', $name = '', $orderuid = '')
{
	global $_G;
	$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
	$times = dgmdate($_G['timestamp'], 'Y-m-d H:i');
	$moneys = $money / 100;
	$carditname = $_G['setting']['extcredits'][$type]['title'];
	if ($keke_chongzhi['smsa']) {
		$member_profile = C::t('common_member_profile')->fetch($orderuid);
		$phone = trim($member_profile['mobile']);
		if ($phone) {
			$text = array('time' => $times, 'credit' => $credit . $carditname, 'money' => $moneys);
			$ret = _sensms($text, $phone, $keke_chongzhi['tmpa']);
		}
	}
	if ($keke_chongzhi['smsb']) {
		$adminphone = dhtmlspecialchars(trim($keke_chongzhi['adminphone']));
		if ($adminphone) {
			$admintext = array('time' => $times, 'credit' => $credit . $carditname, 'money' => $moneys, 'name' => $name);
			$ret = _sensms($admintext, $adminphone, $keke_chongzhi['tmpb']);
		}
	}
	return $ret;
}
function _uporderdata($zftype, $trade_no, $codetext, $orderdata)
{
	global $_G;
	$orderarr = array('state' => '2', 'zftime' => $_G['timestamp'], 'zftype' => $zftype, 'sn' => $trade_no, 'code' => implode(',', $codetext));
	C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->update($orderdata['orderid'], $orderarr);
}

function _h5pay($money, $out_trade_no, $title)
{
	global $_G;
	$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
	$userip = get_client_ip();
	$appid = trim($keke_chongzhi['wxappid']);
	$mch_id = trim($keke_chongzhi['wxmchid']);
	$key = trim($keke_chongzhi['wxshkey']);
	$nonce_str = createNoncestr();
	$body = $title;
	$total_fee = $money;
	$spbill_create_ip = $userip;
	$notify_url = $_G['siteurl'] . 'source/plugin/keke_chongzhi/paylib/notify_wx.inc.php';
	$trade_type = 'MWEB';
	$scene_info = '{"h5_info":{"type":"Wap","wap_url":"' . $_G['siteurl'] . 'plugin.php?id=keke_chongzhi","wap_name":"$title"}}';
	$signA = 'appid=' . $appid . '&attach=' . $out_trade_no . '&body=' . $body . '&mch_id=' . $mch_id . '&nonce_str=' . $nonce_str . '&notify_url=' . $notify_url . '&out_trade_no=' . $out_trade_no . '&scene_info=' . $scene_info . '&spbill_create_ip=' . $spbill_create_ip . '&total_fee=' . $total_fee . '&trade_type=' . $trade_type;
	$strSignTmp = $signA . ('&key=' . $key);
	$sign = strtoupper(MD5($strSignTmp));
	$post_data = '<xml>
					   <appid>' . $appid . '</appid>
					   <mch_id>' . $mch_id . '</mch_id>
					   <body>' . $body . '</body>
					   <out_trade_no>' . $out_trade_no . '</out_trade_no>
					   <total_fee>' . $total_fee . '</total_fee>
					   <spbill_create_ip>' . $spbill_create_ip . '</spbill_create_ip>
					   <notify_url>' . $notify_url . '</notify_url>
					   <trade_type>' . $trade_type . '</trade_type>
					   <scene_info>' . $scene_info . '</scene_info>
					   <attach>' . $out_trade_no . '</attach>
					   <nonce_str>' . $nonce_str . '</nonce_str>
					   <sign>' . $sign . '</sign>
				   </xml>';
	$url = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
	$dataxml = postXmlCurl($post_data, $url);
	$objectxml = (array) simplexml_load_string($dataxml, 'SimpleXMLElement', LIBXML_NOCDATA);
	$objectxml['mweb_url'] = $objectxml['mweb_url'] . _redurl($out_trade_no);
	return $objectxml;
}
function createNoncestr($length = 32)
{
	$chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
	$str = '';
	for ($i = 0; $i < $length; $i++) {
		$str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
	}
	return $str;
}
function postXmlCurl($xml, $url, $second = 30)
{
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_TIMEOUT, $second);
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
	curl_setopt($ch, CURLOPT_HEADER, false);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
	$data = curl_exec($ch);
	if ($data) {
		curl_close($ch);
		return $data;
	}
	$error = curl_errno($ch);
	curl_close($ch);
	echo 'curl_err:' . $error . '<br>';
}
function get_client_ip($type = 0)
{
	if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$ip = getenv('HTTP_CLIENT_IP');
	} elseif (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
		$ip = getenv('HTTP_X_FORWARDED_FOR');
	} elseif (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
		$ip = getenv('REMOTE_ADDR');
	} elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return preg_match('/[\\d\\.]{7,15}/', $ip, $matches) ? $matches[0] : '';
}
function _redurl($orderid)
{
	global $_G;
	$redirect_url = urlencode($_G['siteurl'] . 'plugin.php?id=keke_chongzhi&p=loading&orderid=' . $orderid);
	$redirect_urls = '&redirect_url=' . $redirect_url;
	return $redirect_urls;
}
function editor_safe_replace($content)
{
	$tags = array('\'<iframe[^>]*?>.*?</iframe>\'is', '\'<frame[^>]*?>.*?</frame>\'is', '\'<script[^>]*?>.*?</script>\'is', '\'<head[^>]*?>.*?</head>\'is', '\'<title[^>]*?>.*?</title>\'is', '\'<meta[^>]*?>\'is', '\'<link[^>]*?>\'is');
	return preg_replace($tags, '', $content);
}
function _getqrcodeurl($urls)
{
	global $_G;
	$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
	$src = $keke_chongzhi['qr'] == 2 ? 'source/plugin/keke_chongzhi/paylib/wechat/example/qrcode.php?data=' . urlencode($urls) : $urls;
	return $src;
}
function _upuserdata($out_trade_no, $sns, $opid = '')
{
	global $_G;
	$orderdata = C::t('#keke_chongzhi#keke_chongzhi_orderlog')->fetch($out_trade_no);
	if (!$orderdata['state']) {
		$orderarr = array('state' => '1', 'zftime' => $_G['timestamp'], 'sn' => $sns, 'opid' => $opid);
		C::t('#keke_chongzhi#keke_chongzhi_orderlog')->update($out_trade_no, $orderarr);
		updatemembercount($orderdata['uid'], array('extcredits' . $orderdata['credittype'] => $orderdata['credit']), true, '', 0, '', lang('plugin/keke_chongzhi', 'lang01'), $orderdata['type'] == 3 ? lang('plugin/keke_chongzhi', 'lang55') : lang('plugin/keke_chongzhi', 'lang01'));
		if ($orderdata['give']) {
			updatemembercount($orderdata['uid'], array('extcredits' . $orderdata['givetype'] => $orderdata['give']), true, '', 0, '', lang('plugin/keke_chongzhi', 'lang01'), lang('plugin/keke_chongzhi', 'lang62'));
		}
		notification_add($orderdata['uid'], 'system', lang('plugin/keke_chongzhi', 'lang63') . ($orderdata['give'] ? lang('plugin/keke_chongzhi', 'lang64') : ''), array('credit' => $orderdata['credit'] . ' ' . $_G['setting']['extcredits'][$orderdata['credittype']]['title'], 'give' => $orderdata['give'] ? $orderdata['give'] . ' ' . $_G['setting']['extcredits'][$orderdata['givetype']]['title'] : ''), 1);
		_czsms($orderdata['credit'], $orderdata['money'], $orderdata['credittype'], $orderdata['usname'], $orderdata['uid']);
	}
}
function _getmycount()
{
	global $_G;
	return C::t('#keke_chongzhi#keke_chongzhi_orderlog')->count_by_all($_G['uid'], 1);
}
function _getmylist($startlimit, $ppp)
{
	global $_G;
	$query = C::t('#keke_chongzhi#keke_chongzhi_orderlog')->fetch_all_by_all($_G['uid'], 1, $startlimit, $ppp);
	foreach ($query as $val) {
		$money = $val['money'] / 100;
		$time = dgmdate($val['zftime'], 'Y/m/d H:i');
		$cradit = intval($val['credit']);
		$creditname = $_G['setting']['extcredits'][$val['credittype']]['title'];
		$icoid = $val['type'] == 1 ? 'z' : ($val['type'] == 2 ? 'w' : 'k');
		$list .= '<li><div class="pup"><span><img src="source/plugin/keke_chongzhi/template/images/' . $icoid . '.png"> ' . ($val['type'] == 3 ? '<cite class="mzb">' . lang('plugin/keke_chongzhi', 'lang56') . '</cite>' : '-') . $money . lang('plugin/keke_chongzhi', 'lang03') . '</span>' . lang('plugin/keke_chongzhi', 'lang06') . ' ' . $cradit . ' ' . $creditname . '</div><div class="dow"><span>' . $time . '</span>' . $val['sn'] . '</div></li>';
	}
	return $list;
}
function _instorder($orderid, $money, $zftype, $credit, $credittype, $give = 0, $givetype = 0)
{
	global $_G;
	$orderarr = array('orderid' => $orderid, 'uid' => $_G['uid'], 'usname' => $_G['username'], 'money' => $money, 'type' => $zftype, 'time' => $_G['timestamp'], 'credit' => $credit, 'credittype' => $credittype, 'give' => $give, 'givetype' => $givetype);
	C::t('#keke_chongzhi#keke_chongzhi_orderlog')->insert($orderarr, true);
}
function compelutf($data)
{
	return diconv($data, CHARSET, 'utf-8');
}
function czutf2gbk($data)
{
	$data = dhtmlspecialchars($data);
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	if (CHARSET == 'gbk') {
		return $tmpstr;
	}
	return czgbk2utf($data);
}
function czgbk2utf($data)
{
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	return diconv($tmpstr, 'gbk', 'utf-8');
}
function _getcreditgive($credittype)
{
	global $_G;
	$retarr = array();
	loadcache('keke_chongzhi_credit');
	$creditdata = $_G['cache']['keke_chongzhi_credit'] ? $_G['cache']['keke_chongzhi_credit'] : C::t('#keke_chongzhi#keke_chongzhi_credit')->fetchall_credit();
	foreach ($creditdata as $k => $v) {
		if ($v['state'] == 1 && $v['creditid'] == $credittype && $v['give']) {
			$arr1 = explode(',', $v['give']);
			foreach ($arr1 as $ks => $vs) {
				$arr2 = explode('=', $vs);
				$retarr[$arr2[0]] = $arr2[1];
			}
		}
	}
	return $retarr;
}
function getCreditOpt($cId)
{
	global $_G;
	$opt = '';
	foreach ($_G['setting']['extcredits'] as $creditId => $item) {
		$opt .= '<option value="' . $creditId . '" ' . ($cId == $creditId ? 'selected="selected"' : '') . '>' . $item['title'] . '</option>';
	}
	return $opt;
}