<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
!$fromversion && $fromversion = $_GET['fromversion'];
$keke_chongzhi_credit= DB::table("keke_chongzhi_credit");
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `$keke_chongzhi_credit` (
  `creditid` int(10) unsigned NOT NULL,
  `bili` int(50) NOT NULL,
  `min` float(50,2) NOT NULL,
  `max` float(50,2) unsigned NOT NULL,
  `state` int(10) NOT NULL,
  `sxf` int(10) NOT NULL,
  `shunxu` int(10) NOT NULL,
  `give` varchar(255) NOT NULL,
  PRIMARY KEY  (`creditid`)
) ENGINE=MyISAM;

EOF;
runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_chongzhi_credit'));
while($row = DB::fetch($query)) {
	$col[]=$row['Field']; 
}

if(!in_array('give', $col)){
	$sql = "Alter table ".DB::table('keke_chongzhi_credit')." add `give` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('givetype', $col)){
    $sql = "Alter table ".DB::table('keke_chongzhi_credit')." add `givetype` int(1) NOT NULL;";
    DB::query($sql);
}

$orderQuery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_chongzhi_orderlog'));
while($orderRow = DB::fetch($orderQuery)) {
    $orderCol[]=$orderRow['Field'];
}

if(!in_array('give', $orderCol)){
    $sql = "Alter table ".DB::table('keke_chongzhi_orderlog')." add `give` int(10) NOT NULL;";
    DB::query($sql);
}
if(!in_array('givetype', $orderCol)){
    $sql = "Alter table ".DB::table('keke_chongzhi_orderlog')." add `givetype` int(1) NOT NULL;";
    DB::query($sql);
}


$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/keke_chongzhi/discuz_plugin_keke_chongzhi.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_chongzhi/discuz_plugin_keke_chongzhi_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_chongzhi/discuz_plugin_keke_chongzhi_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_chongzhi/discuz_plugin_keke_chongzhi_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_chongzhi/discuz_plugin_keke_chongzhi_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_chongzhi/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_chongzhi/upgrade.php');