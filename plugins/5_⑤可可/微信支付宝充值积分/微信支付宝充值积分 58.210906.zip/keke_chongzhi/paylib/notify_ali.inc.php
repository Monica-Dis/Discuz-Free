<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

global $_G;
loadcache('plugin');
$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];

require_once("alipay/alipay.config.php");
require_once DISCUZ_ROOT."source/plugin/keke_chongzhi/common.php";
if($keke_chongzhi['alipaysign']==2){
    @require_once DISCUZ_ROOT . "source/plugin/keke_chongzhi/paylib/alipay/alipay_notify.php";
    $aliPay = new AlipayService;
    $result = $aliPay->rsaCheck($_POST);
    if($result===true){
        _upuserdata($_POST['out_trade_no'],$_POST['trade_no']);
        exit('success');
    }else{
        exit('fail');
    }
}
require_once("alipay/alipay_notify.class.php");
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {
	$out_trade_no = $_POST['out_trade_no'];
	$trade_no = $_POST['trade_no'];
	$trade_status = $_POST['trade_status'];
    if($_POST['trade_status'] == 'TRADE_FINISHED' || $_POST['trade_status'] == 'TRADE_SUCCESS') {
		_upuserdata($out_trade_no,$trade_no);
    }
	echo "success";		
}
else {
    echo "fail";
}