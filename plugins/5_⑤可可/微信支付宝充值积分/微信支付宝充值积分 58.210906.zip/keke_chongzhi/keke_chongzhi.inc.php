<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	global $_G;
	$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
	if(!$_G['uid']) {
		showmessage('not_loggedin', NULL, array(), array('login' => 1));
	}
	include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/common.php";
	$title=$navtitle=dhtmlspecialchars($keke_chongzhi['title']);
    $keke_chongzhi['pcstyle']=dhtmlspecialchars($keke_chongzhi['pcstyle']);
	loadcache('keke_chongzhi_credit');
	$creditdata=$_G['cache']['keke_chongzhi_credit'] ? $_G['cache']['keke_chongzhi_credit'] : C::t('#keke_chongzhi#keke_chongzhi_credit')->fetchall_credit();
    $pcleftbtntxt=explode('|',$keke_chongzhi['pcleft']);

    $keke_tixian = $_G['cache']['plugin']['keke_tixian'];
    if($keke_chongzhi['pcleft']){
        $tixianPcLeftTxt=explode('|',$keke_tixian['pcleft']);
    }
    $keke_group = $_G['cache']['plugin']['keke_group'];
    if($keke_group['pcleft']){
        $groupPcLeftTxt=explode('|',$keke_group['pcleft']);
    }
	if($keke_chongzhi['total']){
		$allmoneys=C::t('#keke_chongzhi#keke_chongzhi_orderlog')->sum_by_uid($_G['uid']);
		$allmoney=$allmoneys/100;
		$allmoney =number_format($allmoney, 2);
	}else{
		$allmoney=C::t('#keke_chongzhi#keke_chongzhi_orderlog')->count_by_all($_G['uid']);
	}
	$alipayoff=empty($keke_chongzhi['alipaypid']) ? 0 : 1;
	$wxpayoff=empty($keke_chongzhi['wxappid']) || empty($keke_chongzhi['wxsecert']) || empty($keke_chongzhi['wxmchid']) || empty($keke_chongzhi['wxshkey']) ? 0 : 1;
	$stys=array('ys'=>'#e14546','lnavcolor'=>'#fc4e53','btncolor'=>'#fc4e53','wapbtncolor'=>'#fc4e53');
	foreach($stys as $stykey=>$styval){
		$keke_chongzhi[$stykey]=$keke_chongzhi[$stykey]?dhtmlspecialchars($keke_chongzhi[$stykey]):$styval;
	}
	if(!K_INMINIPROGRAM && (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && !$_GET['p']) && $wxpayoff && checkmobile()){
		include_once libfile('function/cache');
		include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/inc.php";
		$tools = new JsApiPay();
		$openId = $tools->GetOpenid();
		dsetcookie($uskey, authcode($openId, 'ENCODE', $_G['config']['security']['authkey']), 8640000);
	}
	if($_GET['p']=='my'){
		$ppp=$keke_chongzhi['pgt'] ? intval($keke_chongzhi['pgt']) : 30;
		$tmpurl='plugin.php?id=keke_chongzhi&p=my';
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$allcount = _getmycount();
		if($allcount){
			$list=_getmylist($startlimit,$ppp);
		}
		$multipage='';
		$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
		$n=0;
		foreach($creditdata as $creditid=>$v){
			if($v['state']){
				if(!$n){
					$firstcreditname=$_G['setting']['extcredits'][$creditid]['title'];
					$firstnowcredit = getuserprofile('extcredits'.$creditid);
					$n++;
				}
			}
		}
	}else{
		$orderid = daddslashes(dhtmlspecialchars($_GET['orderid']));
		$preset=array();
		$zuidi=floatval($keke_chongzhi['zuidi']);
		$returnurl=$keke_chongzhi['tz']? $keke_chongzhi['tz'] : 'plugin.php?id=keke_chongzhi&p=my';
		$n=0;$zfbonwx=1;
		$creditdata_desc=$creditdata;
		$flag = array();  
		foreach($creditdata as $v){  
			$flag[] = $v['shunxu'];  
		}  
		array_multisort($flag, SORT_DESC, $creditdata_desc);  
		foreach($creditdata_desc as $creditid=>$v){
			if($v['state']){
				$check='';
				if(!$n){
					$firstcreditid=$v['creditid'];
					$firstcreditname=$_G['setting']['extcredits'][$v['creditid']]['title'];
					$firstnowcredit = getuserprofile('extcredits'.$v['creditid']);
					$check=$keke_chongzhi['mrcredit'] ? 'checked="true"' : '';
				}
				$nowcredit = getuserprofile('extcredits'.$v['creditid']);
				$credittype.='<div class="credittype"><input type="radio" name="credittype" data-now="'.$nowcredit.'" data-bili='.$v['bili'].' data-creditname="'.$_G['setting']['extcredits'][$v['creditid']]['title'].'" value="'.$v['creditid'].'" '.$check.' id="cre'.$v['creditid'].'"><label for="cre'.$v['creditid'].'"><i></i><span class="creditname">'.$_G['setting']['extcredits'][$v['creditid']]['title'].'</span></label></div>';
				$n++;
			}
		}
		$keke_chongzhi['sm']=editor_safe_replace($keke_chongzhi['sm']);
		$bl=floatval($creditdata[$firstcreditid]['bili']);
		$preset=explode(",",$keke_chongzhi['yz']);
		$retarr=_getcreditgive($firstcreditid);
		foreach($preset as $key=>$val){
			$val=floatval($val);
			$viewmoney=number_format($val,2);
			$credit=$bl*$val;
			$sty= $key ? '' : 'class="on"';
			$give='';
			if($retarr[strval($val)]){
				$give='<cite class="giv" id="giv'.$val.'"><b>'.lang('plugin/keke_chongzhi', 'lang43').'<i class="givnum">'.$retarr[strval($val)].'</i> '.($creditdata[$firstcreditid]['givetype']!=$firstcreditid?$_G['setting']['extcredits'][$creditdata[$firstcreditid]['givetype']]['title']:'').'</b></cite>';
			}
			$preval.='<li '.$sty.' money="'.$val.'"><span>'.$credit.$firstcreditname.'</span><h4>&yen;'.$viewmoney.' </h4>'.$give.'</li>';
		}
		if((strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) && !$keke_chongzhi['zfbonwx']){
			$zfbonwx=0;
		}
	}
	include template('keke_chongzhi:index'); 