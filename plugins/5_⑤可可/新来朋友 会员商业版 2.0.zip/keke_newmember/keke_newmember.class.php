<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_keke_newmember { }
class plugin_keke_newmember_forum extends plugin_keke_newmember{
	

	function viewthread_top_output(){
		return $this->getdata('1');	
		
	}
	
	function forumdisplay_top_output(){
		return $this->getdata('2');
	}
	function  index_top(){
		return $this->getdata('3');
	}
	
	function getdata($i){	
		global $_G;
		$keke_newmember=$_G['cache']['plugin']['keke_newmember'];
		$title=dhtmlspecialchars($keke_newmember['title']);
		if(($keke_newmember['index'] && $i==3) || ($keke_newmember['list'] && $i==2) || ($keke_newmember['view'] && $i==1)){

			$section = empty($keke_newmember['section']) ? array() : unserialize($keke_newmember['section']);
			if(!is_array($section)) $section = array();
			if((!(empty($section[0]) || in_array($_G['fid'],$section))) && !($i==3)){
				return;
				}		
	
				$nb=$keke_newmember['dysl'] ? $keke_newmember['dysl'] : 20;
				$query = DB::query("SELECT username, uid, regdate FROM ".DB::table('common_member')." WHERE avatarstatus=1 ORDER BY uid DESC LIMIT 0,".$nb."");
       			while($data = DB::fetch($query)) {
           		$data['regdate'] = gmdate("Y-m-d H:i:s", $data[regdate] + ($_G[setting][timeoffset] * 3600));
           		$data['avatar'] = discuz_uc_avatar($data['uid'],'small');
				$list.='<span class="ava" style="margin-left:3px; float:left;">
				<a href="home.php?mod=space&uid='.$data['uid'].'" target="_blank" title="'.$data[username].'">'.$data['avatar'] .'</a>
				<p>'.$data[username].'</p>
				</span>';
				} 
	include template('keke_newmember:index');
	return $return;
		}
	}
}