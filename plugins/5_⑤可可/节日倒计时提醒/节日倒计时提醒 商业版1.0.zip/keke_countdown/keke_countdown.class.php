
<?
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_keke_countdown{
	function global_cpnav_top(){
		return $this->getdata('3');	
	}
	function global_header(){
		return $this->getdata('5');	
		}
	function global_cpnav_extra1(){
		return $this->getdata('1');	
		}
	function global_cpnav_extra2(){
		return $this->getdata('2');	
	}
		
	function getdata($a){
		global $_G, $postlist;
		$keke_countdown=$_G['cache']['plugin']['keke_countdown'];
		if(($keke_countdown['wz']==$a) || ($a==6 && $keke_countdown['sjb'])){
			$beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));		
			$jr=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_countdown['jz']));
			
			$n=0;$i=0;
			 foreach($jr as $k=>$v){
				  $time=explode('|',$v);
				  $times=strtotime(''.$time[1].' 00:00:00');
				  
				  $tc=$times-$beginToday;
				  
				  if($tc>=0){
					  if($i==0){
						  $mc=$time[0];
						  $sjc=$times;
						  $i++;
						  }
					  else{
						  if(($sjc-$times)>0){
							  $mc=$time[0];
							  $sjc=$times;
							  }
						  }
					  }
				  }
				$tsa=($sjc-$beginToday)/86400;
				
				if($keke_countdown['qjt'] && ($ts>$keke_countdown['qjt'])){return;}
				if($tsa){
					if($a==6 ){$result=$keke_countdown['sjdjs'];}else{
					$result=$keke_countdown['djs'];}
				
				}else{$result=$keke_countdown['jrdt'];}
				$ts=$tsa.lang('plugin/keke_countdown', 't');
				$js='<style>.keke_countdown{ background:url(source/plugin/keke_countdown/ico.png) no-repeat left;margin:0px 0px 0px 15px; padding-left:23px;}.cowp{border:1px dashed #CCC; text-align:center;background:#FDFCEA;}.tfwp{margin:10px auto; padding:5px 0px;}</style>';
				if($keke_countdown['jq']){
					$js.='<script language="javascript" type="text/javascript"> 
					var interval = 50; 
					function ShowCountDown(year,month,day,divname) 
					{ 
					var now = new Date(); 
					var endDate = new Date(year, month-1, day); 
					var leftTime=endDate.getTime()-now.getTime(); 
					var leftsecond = parseInt(leftTime/1000); 
					var day1=Math.floor(leftsecond/(60*60*24)); 
					var hour=Math.floor((leftsecond-day1*24*60*60)/3600); 
					var minute=Math.floor((leftsecond-day1*24*60*60-hour*3600)/60); 
					var second=Math.floor(leftsecond-day1*24*60*60-hour*3600-minute*60); 
					var cc = document.getElementById(divname); 
					var day2=\'\';
					if (day1){ day2=day1+"'.lang('plugin/keke_countdown', 't').'";}
					cc.innerHTML = day2+hour+"'.lang('plugin/keke_countdown', 'xs').'"+minute+"'.lang('plugin/keke_countdown', 'f').'"+second+"'.lang('plugin/keke_countdown', 'm').'"; 
					} 
					window.setInterval(function(){ShowCountDown('.date("Y",$sjc).','.date("m",$sjc).','.date("d",$sjc).',\'divdown1\');}, interval); 
					</script> ';
					$ts='<span id="divdown1"></span>';
					}
				
				
				$result=str_ireplace("[n]","".date(Y)."",$result);
				$result=str_ireplace("[y]","".date(m)."",$result);
				$result=str_ireplace("[r]","".date(d)."",$result);
				$result=str_ireplace("[m]","".$mc."",$result);
				$result=str_ireplace("[j]","".$ts."",$result);
				$dx=$keke_countdown['ct'] ? 'bold' : '500';
				$result=$js.'<span class="keke_countdown"><font color="'.$keke_countdown['ys'].'" style="font-weight:'.$dx.'"">'.$result.'</font></span>';
				if($a==3 || $a==5){ if($a==5){$sty='tfwp';}else{$sty='';}$result='<div class="wp cowp '.$sty.'">'.$result.'</div>';}
				
				
				return $result;
		}

	}
}


class mobileplugin_keke_countdown{
	function global_header_mobile(){
		$Obj=new plugin_keke_countdown;
		return $Obj->getdata('6');
		}
	}