<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-10-20,13:20:06
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_keke_listava {
	
	function __construct() {
		global $_G;
		$this->_keke_listava = $_G['cache']['plugin']['keke_listava'];
	}
	
	function global_header(){
		$h=$this->_keke_listava['gd'];
		$ha=$h+10;
		if($this->_keke_listava['wz']==1)$wz='left';else $wz='right';
		if($this->_keke_listava['sfyx']){$yj='-moz-border-radius: 80%; -webkit-border-radius: 80%; border-radius: 80%;border-radius:30px;';}else{$yj='';}
		$return='<style>
.common a.s,.new a.s{line-height:'.$ha.'px; padding:0px; margin:0px}
.avaboxs{float:'.$wz.';margin-right: 8px;overflow: hidden;padding: 1px; }
.avaboxs img{'.$yj.' padding:2px; border:1px solid '.$this->_keke_listava['bkys'].';-webkit-transition-duration:.8s;-moz-transition-duration:.8s;-ms-transition-duration:.8s;-o-transition-duration:.8s;transition-duration:.8s; width:'.$this->_keke_listava['kd'].'px; height:'.$h.'px}
.avaboxs a:hover{text-decoration:none;border:none}
.avaboxs a:hover img{transform:scale(1.1);-webkit-transform:scale(1.1);}
</style>';
		return $return;
		}
	}
class plugin_keke_listava_forum extends plugin_keke_listava {
	function forumdisplay_thread_output() {	
		global $_G;
		$section = empty($this->_keke_listava['section']) ? array() : unserialize($this->_keke_listava['section']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){return;}
		$return = array();
		if(!$_G['forum_threadlist']) {return array();}
		foreach($_G['forum_threadlist'] as $ava) {
			$return[] = '<div class="avaboxs"><a href="home.php?mod=space&uid='.$ava['authorid'].'" title="'.htmlspecialchars($ava['author']).'" c="1">'.avatar($ava['authorid'],small).'</a></div>';
		}
		return $return;
	}
}