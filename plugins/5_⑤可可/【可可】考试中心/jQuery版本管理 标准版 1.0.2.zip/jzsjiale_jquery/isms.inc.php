<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * dismall: https://dism.taobao.com/developer-32563.html
 * createtime: 202107131036
 * updatetime: 202107131036
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

?>
<iframe src="//dism.taobao.com/?@jzsjiale_isms.plugin" width="1100" height="2000" frameborder="0" scrolling="no" style="margin-left:-3px; background:#F4FAFD" ></iframe>