<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * dismall: https://dism.taobao.com/developer-32563.html
 * createtime: 202107131036
 * updatetime: 202107131036
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class mobileplugin_jzsjiale_jquery {
	function global_header_mobile(){
        global $_G;
        $_config = $_G['cache']['plugin']['jzsjiale_jquery'];

        $g_jqversion = '3.6.0';
        if($_config['g_jqversion']){
            $g_jqversion = $_config['g_jqversion'];
        }
        $header_jscss = '';
        if($_config['g_insertjquery']){
            switch ($_config['g_cdn'])
            {
                default:
                case 0:
                    $header_jscss .= '<script type="text/javascript" src="source/plugin/jzsjiale_jquery/static/js/jquery-'.$g_jqversion.'.min.js"></script>';
                    break;
                case 1:
                    $header_jscss .= '<script type="text/javascript" src="https://cdn.bootcdn.net/ajax/libs/jquery/'.$g_jqversion.'/jquery.min.js"></script>';
                    break;
                case 2:
                    $header_jscss .= '<script type="text/javascript" src="https://unpkg.com/jquery@'.$g_jqversion.'/dist/jquery.min.js"></script>';
                    break;
                case 3:
                    $header_jscss .= '<script type="text/javascript" src="https://libs.cdnjs.net/jquery/'.$g_jqversion.'/jquery.min.js"></script>';
                    break;
                case 4:
                    $header_jscss .= '<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/jquery@'.$g_jqversion.'/dist/jquery.min.js"></script>';
                    break;
            }


            $g_jq = empty($_config['g_jq']) || !preg_match('/^(\w)+$/',$_config['g_jq']) ? 'jQjiale' : $_config['g_jq'];
            if(!$_config['g_noconflicttrue']){
                $header_jscss .= '<script type="text/javascript">let '.$g_jq.' = $.noConflict(); </script>';
            }else{
                $header_jscss .= '<script type="text/javascript">let '.$g_jq.' = $.noConflict(true); </script>';
            }
        }
        if($_config['g_iconfonturl']){
            $header_jscss .= '<script src="'.$_config['g_iconfonturl'].'"></script>';
            $header_jscss .= $_config['g_miconfontstyle'];
        }
        if($_config['g_mcss']){
            $header_jscss .= $_config['g_mcss'];
        }
        return $header_jscss;
	}
}