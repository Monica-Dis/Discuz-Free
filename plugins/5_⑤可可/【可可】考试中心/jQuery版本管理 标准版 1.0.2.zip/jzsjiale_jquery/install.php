<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * dismall: https://dism.taobao.com/developer-32563.html
 * createtime: 202107131036
 * updatetime: 202107131036
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

EOF;
runquery ( $sql );


@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_jquery/discuz_plugin_jzsjiale_jquery.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_jquery/discuz_plugin_jzsjiale_jquery_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_jquery/discuz_plugin_jzsjiale_jquery_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_jquery/discuz_plugin_jzsjiale_jquery_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_jquery/discuz_plugin_jzsjiale_jquery_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_jquery/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/jzsjiale_jquery/upgrade.php');


$finish = TRUE;
?>