jQuery(function() {

    var formhash        = jQuery('#formhash').val(),
        docBoxWidth     = jQuery('.doc_box').width(),
        container = jQuery('#mod_list'),
        checkEmpty=jQuery('#doclist').val();
    if(checkEmpty){
        container.imagesLoaded(function() {
            container.masonry({
                itemSelector: '.doc-mod',
                gutter: 0,
                isAnimated: true,
            });
        });
    }

    jQuery(".follow-btn").on("click",function(){
        var that=jQuery(this);
        jQuery.post('plugin.php?id=keke_doc:ajax',{ac:'addfollow',autohid:that.data('autohid'),formhash:formhash}, function (data) {
            if(data.state===2){
                layer.msg(data.msg);
                return false;
            }
            if(that.hasClass("isfollow")){
                that.removeClass("isfollow").html('��עTA');
            }else{
                that.addClass("isfollow").html('<span class="keke_iconfont">&#xe600;</span> �ѹ�ע');
            }
        }, 'json')
    });

});

