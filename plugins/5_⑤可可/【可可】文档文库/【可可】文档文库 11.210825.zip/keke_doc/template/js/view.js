var did             = jQuery('#did').val(),
    formhash        = jQuery('#formhash').val(),
    docBoxWidth     = jQuery('.doc_box').width(),
    leftDistance    = docBoxWidth-300,
    scrollState     = true
    Obj             = jQuery('body');

Obj.on('click','.bottomviewbtn',function(){
    GetDoc();
});

Obj.on('click','.full-btn',function(){
    jQuery('body > div').addClass('hidediv');
    Obj.prepend('<div id="fullscreen" class="keke_doc_clearfix">'+jQuery('.mainpart').html()+'</div>').fadeIn();
    Obj.addClass('full-bg');
    jQuery('.pay-download-bar,.pageinfo').css('width',jQuery('.docviewbox').width());
    jQuery('.commentbox').hide();

});

Obj.on('click','.full-close',function(){
    jQuery('body > div').removeClass('hidediv');
    jQuery('.mainpart').html(jQuery('#fullscreen').html());
    jQuery('#fullscreen').remove();
    jQuery('body').removeClass('full-bg');
    jQuery('.pay-download-bar,.pageinfo').css('width',jQuery('.viewleft').width());
    jQuery('.commentbox').show();
});

Obj.on('click','.evaluate_list_box .pg a',function(){
    var pageUrl=jQuery(this).data('pageurl');
    jQuery('.evaluate_list_box').html('<div class="loadingbox"><img src="source/plugin/keke_doc/template/images/loading-2.gif"></div>');
    jQuery.post(pageUrl,{}, function (data) {
       jQuery('.loadingbox').fadeOut(200,function (){
            jQuery('.evaluate_list_box').html(data)
        });
    }, 'html')
});

jQuery.post('plugin.php?id=keke_doc:ajax',{'ac':'addview',did:did,formhash:formhash}, function (data) {}, 'json');
jQuery('.pay-download-bar,.pageinfo').css('width',jQuery('.viewleft').width());
GetDoc();
getEvaluate();

function GetDoc(toPage){
    var laseId=jQuery(".viewpage:last").data('pid');
    if(toPage){
        var toObj=jQuery("#pageNo"+toPage);
        if(toPage && toObj.length>0){
            jQuery("html,body").animate({scrollTop:toObj.offset().top+1}, 500);
            return false;
        }
    }
    jQuery.get('plugin.php?id=keke_doc:ajax',{'ac':'getdoc',did:did,last:laseId,topage:toPage,formhash:formhash}, function (data) {
        var output,src;
        jQuery('.loadingpage').remove();
        jQuery(data.data).each(function(i, doc) {
            src=doc.url;
            if(toPage && doc.viewid<toPage){
                src='';
            }
            output = '<div id="pageNo'+doc.viewid+'" class="viewpage" data-pid="'+doc.viewid+'">'+
                '<img src="source/plugin/keke_doc/template/images/loading.gif" class="loadingimg" />'+
                '<img src="'+src+'" data-load="'+doc.url+'" class="docimg" /></div>'+
                (doc.adv?'<div class="hx-warp"> '+ doc.adv + '</div>':'');
            var sT=jQuery(window).scrollTop();
            jQuery('.docviewbox').append(output);
            jQuery(window).scrollTop(sT);
            jQuery("#pageNo"+doc.viewid+" > .docimg").load(function(){
                jQuery(this).fadeIn();
                jQuery("#pageNo"+doc.viewid+" > .loadingimg").remove();
            });
        });
        if( data.surplus===0){
            jQuery('.surplustip').html('已阅读完毕，您还可以下载文档进行保存');
            jQuery('.bottomviewbtn').hide();
        }else{
            if(data.freeend===1){
                jQuery('.surplustip').html('剩余 <span class="surplus">'+ data.surplus +'</span> 页未读，需完整阅读或下载请先购买文档');
                jQuery('.bottomviewbtn').hide();
            }
            jQuery('.surplus').html(data.surplus);
        }

        if(toPage){
            var scroll = jQuery("#pageNo"+toPage).offset().top;
            scrollState=false;
            jQuery("html,body").animate({scrollTop:scroll+1}, 500,function (){
                scrollState=true;
            });
        }
    },'json')
}

jQuery(".follow-btn").on("click",function(){
    var that=jQuery(this);
    jQuery.post('plugin.php?id=keke_doc:ajax',{ac:'addfollow',autohid:that.data('autohid'),formhash:formhash}, function (data) {
        if(data.state===2){
            layer.msg(data.msg);
            return false;
        }
        if(that.hasClass("isfollow")){
            that.removeClass("isfollow").html('<span class="keke_iconfont">&#xe601;</span> 关注');
        }else{
            that.addClass("isfollow").html('<span class="keke_iconfont">&#xe600;</span> 已关注');
        }
    }, 'json')
});

jQuery(".doc_report").on("click",function(){
    if(jQuery('#reportlogin').val() && jQuery('#uid').val()<=0){
        layer.msg('请登录后再进行举报');
        return false;
    }
    var url='plugin.php?id=keke_doc:ajax&ac=report&did='+did+'&formhash='+formhash;
    layer.open({
        type: 2,
        scrollbar: false,
        area: ['530px','410px'],
        title:'',
        fixed: false,
        shadeClose:true,
        content: url
    });
});

jQuery(document).keyup(function(event){
    if(event.keyCode ===13){
        GetDoc(jQuery(".cur-page").val());
    }
});

jQuery('.cur-page').on('keydowm keyup',function () {
    var textLength = jQuery(this).val().length,
        inputWidth = textLength*11;
    jQuery(this).width(inputWidth);
});

jQuery('.doc_favorites').on('click',function () {
    var that=jQuery(this);
    jQuery.post('plugin.php?id=keke_doc:ajax',{ac:'addfavorites',did:that.data('did'),formhash:formhash}, function (data) {
        if(data.state===2){
            layer.msg(data.msg);
            return false;
        }
        if(that.hasClass("isfavorites")){
            that.removeClass("isfavorites").html('<span><i class="keke_iconfont">&#xe7df;</i>收藏文档</span>');
        }else{
            that.addClass("isfavorites").html('<span><i class="keke_iconfont hightline">&#xe617;</i>已收藏</span>');
        }
    }, 'json')
});

jQuery('.star li').hover(function(){
    var indexs=jQuery(this).index();
    jQuery(".starnum").text(indexs);
    jQuery('input[name="star"]').val(indexs);
    for (var i = 0; i < 5; i++) {
        if (i<indexs) {
            jQuery('.star li:eq('+i+')').addClass('light');
        }else{
            jQuery('.star li:eq('+i+')').removeClass('light');
        }
    }
});

jQuery('.doc_share').on("click",function(){
    var share_menu=jQuery('.keke_share_menu');
    if(share_menu.is(':hidden')){
        share_menu.fadeIn();
    }else{
        share_menu.hide();
    }
});

jQuery('.doc_commentd').on("click",function(){
    var commentbox_top=jQuery('.commentbox').offset().top;
    jQuery("html,body").animate({scrollTop:commentbox_top+1}, 1000);
});

jQuery("body").on("click", ".js-social-share", function () {
    var e = jQuery(this),
        a = e.data("share"),
        i = e.parents(".keke_share_menu").data(),
        n = "",
        p = jQuery(".point-share-url");
    switch (p.length > 0 && jQuery.post(p.val(), function () {}), a) {
        case "weibo":
            n = r(i), window.open(n);
            break;
        case "qzone":
            n = t(i), window.open(n);
            break;
        case "qq":
            n = o(i), window.open(n);
            break;
        case "weixin":
            s(e)
    }
})

jQuery('.doc_mobile').on("click",function(){
    s(jQuery('.weixinshare'));
});

jQuery('.evaluate_btn').on("click",function(){
    jQuery.post('plugin.php?id=keke_doc:ajax',{ac:'addevaluate',formhash:formhash,did:did,star:jQuery('#star').val(),evaluate:jQuery('#evaluate_input').val()}, function (data) {
        if(data.state===2) {
            layer.msg(data.msg, {shift: -1, time: 2000}, function () {

            });
        }
        getEvaluate();
    }, 'json')
});

jQuery(window).load(function(){
    var rightBoxHeight      = jQuery('.viewright').height(),
        viewright           = jQuery(".viewright").offset().top,
        viewleft            = jQuery(".viewleft").offset().top;
    jQuery(window).scroll(function() {
        var viewBoxTop      = jQuery(".docviewbox").offset().top,
            viewleftHeight  = jQuery(".viewleft").height(),
            readerbox       = viewleftHeight+viewleft,
            endpage         = jQuery(".endpage").offset().top,
            scroH           = jQuery(window).scrollTop(),
            mainpart        = jQuery('.mainpart'),
            mainboxoffset   = mainpart.offset().top,
            mainboxheight   = mainpart.height(),
            difference      = mainboxheight-(rightBoxHeight+10)+mainboxoffset,
            viewH           = jQuery(window).height(),
            readerboxObj    = jQuery('.readerbox'),
            viewrightObj    = jQuery('.viewright');
        if(scroH>viewBoxTop){
            if(scroH+viewH>endpage){
                readerboxObj.fadeOut(100);
            }else{
                readerboxObj.fadeIn();
            }
        }else{
            readerboxObj.fadeOut(100);
        }
        if(scroH>=viewright && scroH<difference){
            viewrightObj.css({"position":"fixed","top":"0px","margin-left":leftDistance}).fadeIn();
        }else if(scroH>difference){
            viewrightObj.fadeOut(100);
        }else{
            viewrightObj.attr("style","");
        }
        if(scroH>viewleft && scroH<readerbox){
            jQuery('.pageinfo').addClass('fixedtop');
        }else{
            jQuery('.pageinfo').removeClass('fixedtop');
        }
        jQuery('.viewpage').each(function(i,e){
            var of          =jQuery(this).offset().top,
                pageheight  =jQuery(this).height();
            if(scroH>of && scroH<of+pageheight){
                var pid=jQuery(this).data('pid'),
                    textLength = pid.toString().length,
                    inputWidth = textLength*11,
                    docObj=jQuery("#pageNo"+pid+">.docimg"),
                    checkDocUrl=docObj.attr("src"),
                    docUrl=docObj.data('load');
                if((checkDocUrl==='' || checkDocUrl===null) && scrollState){
                    docObj.attr('src',docUrl);
                    docObj.load(function(){
                        jQuery(this).fadeIn();
                        jQuery("#pageNo"+pid+" > .loadingimg").remove();
                    });
                }
                jQuery('.cur-page').val(pid).width(inputWidth);
            }
        });
    });
});

function getEvaluate(){
    jQuery.post('plugin.php?id=keke_doc:ajax',{ac:'getevaluate',formhash:formhash,did:did}, function (data) {
        jQuery('.evaluate_list_box').html(data)
    }, 'html')
}

function s(e) {
    layer.open({
        type: 1,
        title: false,
        closeBtn: 0,
        shadeClose: true,
        content: '<div class="weixinsharebox"><img src="'+e.data('qrcode-url')+'" alt="" width="200"><br>请使用手机扫一扫</div>'
    });
}
function r(e) {
    var a = {};
    return a.url = e.url, a.title = e.message, "" != e.picture && (-1 != e.picture.indexOf("://") ? a.pic = e.picture : a.pic = document.domain + e.picture), "http://service.weibo.com/share/share.php?" + d(a)
}

function t(e) {
    var a = {};
    return a.url = e.url, a.title = e.title, a.summary = e.summary, a.desc = e.message, "" != e.picture && (a.pics = e.picture), "http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?" + d(a)
}

function o(e) {
    var a = {};
    return a.url = e.url, a.title = e.title, a.summary = e.summary, a.desc = e.message, "" != e.picture && (a.pics = e.picture), "http://connect.qq.com/widget/shareqq/index.html?" + d(a)
}

function d(e) {
    var a = [];
    for (var i in e) a.push(i + "=" + encodeURIComponent(e[i] || ""));
    return a.join("&")
}
