function wxshare(type,desc,icon,formhash,shareurl) {
	var wstitle = document.title,urls=location.href.split('#')[0];
	if(type==1){
		$.get('plugin.php?id=keke_doc:ajax&ac=wxshare&formhash='+formhash, {url:urls},function (data){
			wx.config({
				  debug: false,
				  appId: data.appId,
				  timestamp: data.timestamp,
				  nonceStr: data.nonceStr,
				  signature: data.signature,
				  jsApiList: [
					  'onMenuShareTimeline',
					  'onMenuShareAppMessage',
				  ]
			  });
			  if(desc=='' || desc==undefined || desc==null){
				 desc=wstitle;
			  }
			  if(shareurl){
				 sharelink=shareurl;	
			  }else{
				 sharelink=data.url;	
			  }
			  wx.ready(function () {
					wx.onMenuShareTimeline({
						title: wstitle,
						link: sharelink,
						imgUrl: icon,
						success: function () {
						},
						cancel: function () {
						}
					});
					wx.onMenuShareAppMessage({  
						title: wstitle,
						desc: desc,
						link: sharelink,
						imgUrl: icon,
						success: function () {
						},
						cancel: function () {
						}
					});
					if(player){
					  player.play();
					}
				}); 
		}, "json");
	}else if(type==2){
		if(shareurl){
		   sharelink=shareurl;	
		}else{
		   sharelink=urls;	
		}
		mag.setData({
		  shareData: {
			  title: wstitle,
			  des: desc,
			  picurl: icon,
			  linkurl: sharelink,
			}
		});
	} 
} 