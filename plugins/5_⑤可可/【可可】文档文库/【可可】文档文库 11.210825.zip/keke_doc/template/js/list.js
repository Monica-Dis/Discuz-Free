jQuery(function() {
    var container = jQuery('#mod_list'),
        checkEmpty=jQuery('#doclist').val();
    if(checkEmpty){
        container.imagesLoaded(function() {
            container.masonry({
                itemSelector: '.doc-mod',
                gutter: 0,
                isAnimated: true,
            });
        });
    }

});