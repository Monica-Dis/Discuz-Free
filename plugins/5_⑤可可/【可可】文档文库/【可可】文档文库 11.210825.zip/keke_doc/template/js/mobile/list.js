$(function(){
    $('#sidebar ul li').click(function(){
        $(this).addClass('active').siblings('li').removeClass('active');
        var index = $(this).index(),
            sub = $(this).data('sub'),
            cateid = $(this).data('cateid');
        if(sub){
            index--;
            $('.j-content').eq(index).show().siblings('.j-content').hide();
        }else{
            window.location.href = "plugin.php?id=keke_doc&ac=list&cate="+cateid+'-0-0';
        }
    })
    $('.viewlist').click(function(){
        var cateid = $(this).data('cate');
        $(this).addClass('active').siblings('li').removeClass('active');
        window.location.href = "plugin.php?id=keke_doc&ac=list&cate="+cateid;
    })

    $('.setcate').click(function(){
        $('.doc-list').hide();
        $(".wy-content").show().css('left','-500px').animate({"left": "0px"}, "normal");
        $(".menu-left").css('left','-120px').animate({"left": "0px"}, "slow");
    })

    $('.displayorder,.fullbg').click(function(){
       if($('#listsubnav_2').is(":hidden")){
           $(this).addClass("selectnav");
           $(".listnav").addClass("onnav");
           $(".listsubnav").show();
           $(".fullbg").show();
        }else{
           $(".listnav").removeClass('onnav');
           $(this).removeClass("selectnav");
           $(".listsubnav").hide();
           $("#fullbg").hide();
       }
    })



})