var formhash = jQuery('#formhash').val();
$('.tab-box ul li').on("click",function(){
    let index=$(this).data('index');
    $(this).addClass('active').siblings().removeClass('active');
    let w=$(this).width();
    let l=$(this).offset().left;
    let s=$('.tab-box').scrollLeft();
    $('.active-line').attr('style','transform: translateX('+ parseInt(l+s-15)+'px); width: '+w+'px;');
    $.get('plugin.php?id=keke_doc:ajax', {ac:'getdoclist',cateid:index,formhash:formhash}, function (data) {
        if(data.state){
            var item=''
            if(data.list.length>0){
                $.each(data.list,function(i,result){
                    item+='<a href="'+result['url']+'" class="course-mod" target="_blank">\n' +
                    '            <div class="mod_content keke_doc_clearfix">\n' +
                    '                <div class="mod_content_right">\n' +
                    '                    <img src="'+result['thumb']+'">\n' +
                    '                </div>\n' +
                    '                <div class="mod_content_top">\n' +
                                        result['title']+'\n' +
                    '                </div>\n' +
                    '                <div class="mod_bottom keke_doc_clearfix">\n' +
                    '                    <div class="mod_bottom_detail-info">\n' +
                    '                        <span class="type-label mr5">'+result['exttype']+'</span>  '+result['time']+'\n' +
                    '                    </div>\n' +
                    '                </div>\n' +
                    '            </div>\n' +
                    '        </a>';
                });
            }else{
                item='<div class="keke_empty"><img src="source/plugin/keke_doc/template/images/empty.png"><p>&#26242;&#26080;&#20219;&#20309;&#20869;&#23481;</p></div>'
            }
            jQuery('.doc-list').html(item);
        }
    }, 'json')
});
$(".header_iconav").swiper({});
$(".swiper-container").swiper({
    loop: true,
    autoplay: 3000
});


let dopen=$('#down-open');
if(dopen.length) {
    const currentHeight = dopen.height(),
          autoHeight = dopen.css('height', 'auto').height();
    dopen.height(currentHeight );
    $('.down-open-btn').on("click",function(){
        if(dopen.hasClass("opennav")){
            $('#down-open').removeClass('opennav').animate({height:currentHeight}, 500);
            $(this).find('.keke_iconfont').html('&#xe63a;')
        }else{
            $('#down-open').addClass('opennav').animate({height:autoHeight}, 500)
            $(this).find('.keke_iconfont').html('&#xe639;')
        }

    })
}

