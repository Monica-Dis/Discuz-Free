<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);
require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
global $_G;
$returl=str_replace('source/plugin/keke_doc/paylib/', '',$_G['siteurl']);
loadcache('plugin');
if($_GET['out_trade_no']){
    $orderData=C::t('#keke_doc#keke_doc_order')->fetchfirst_byid($_GET['out_trade_no']);
    $url=$returl.'plugin.php?id=keke_doc&ac=down&did='.$orderData['did'];
    dheader('location: '.$url);
}
exit('Error');