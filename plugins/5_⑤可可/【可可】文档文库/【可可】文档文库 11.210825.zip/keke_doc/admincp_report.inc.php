<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;
loadcache('plugin');
include_once DISCUZ_ROOT . "source/plugin/keke_doc/function.php";
if (submitcheck("forumset")) {
    $state = 2;
    if (is_array($_GET['dids'])) {
        if ($_GET['optype'] == 'delete') {
            C::t('#keke_doc#keke_doc_report')->delete($_GET['dids']);
        } elseif ($_GET['optype'] == 'pass') {
            C::t('#keke_doc#keke_doc_report')->update($_GET['dids'], array('state' => 2));
        }
    } else {
        cpmsg(lang('plugin/keke_doc', '54'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_report', 'error');
    }
    if (!$_GET['optype']) {
        cpmsg(lang('plugin/keke_doc', '55'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_report', 'error');
    }
    cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_report', 'succeed');
}

showtableheader(lang('plugin/keke_doc', '91'));
showformheader('plugins&operation=config&do=' . $pluginid . '&pmod=keke_doc&pmod=admincp_report', 'testhd');
showtablerow('', array(),
    array(
        '<input name="uid" type="text" value="' . ($_GET['did'] ? intval($_GET['did']) : '') . '" size="10" placeholder="'.lang('plugin/keke_doc', '92').'" />
                <input name="uid" type="text" value="' . ($_GET['uid'] ? intval($_GET['uid']) : '') . '" size="12" placeholder="'.lang('plugin/keke_doc', '207').'" />
                <select name="state"><option value="0">'.lang('plugin/keke_doc', '79').'</option><option value="1" ' . ($_GET['state'] == 1 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '204').'</option><option value="2" ' . ($_GET['state'] == 2 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '205').'</option></select>
                <input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_doc', '206').'"><input name="inajax" type="hidden" value="1" />'
    )
);
showformfooter(); /*Dism_taobao-com*/
showtablefooter(); /*dism��taobao��com*/
$where = '1';
$param = '';

if ($_GET['did']) {
    $where .= " AND did=" . intval($_GET['did']);
    $param .= '&did=' . intval($_GET['uid']);
}
if ($_GET['uid']) {
    $where .= " AND uid=" . intval($_GET['uid']);
    $param .= '&uid=' . intval($_GET['uid']);
}
if ($_GET['state']) {
    $where .= " AND state=" . intval($_GET['state']);
    $param .= '&state=' . intval($_GET['state']);
}
showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_report");
showtableheader(lang('plugin/keke_doc', '96'));
showsubtitle(array(lang('plugin/keke_doc', '83'), lang('plugin/keke_doc', '202'), lang('plugin/keke_doc', '199'), lang('plugin/keke_doc', '200'),lang('plugin/keke_doc', '100'), lang('plugin/keke_doc', '87')));
$ppp = 20;
$tmpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_report' . $param;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
if ($countAll = C::t('#keke_doc#keke_doc_report')->count_all($where)) {
    $dataArr = C::t('#keke_doc#keke_doc_report')->fetch_all_data($startlimit, $ppp, $where);
    foreach ($dataArr as $key => $val) {
        switch ($val['state']) {
            case 1:
                $state = ['off', lang('plugin/keke_doc', '204')];
                break;
            case 2:
                $state = ['zc',  lang('plugin/keke_doc', '205')];
                break;
        }
        $val['content'] = str_replace('[t]','<span class=\'rtype\'>',$val['content']);
        $val['content'] = str_replace('[/t]','</span>',$val['content']);
        $val['content'] = str_replace('[b]','<div class="typebox">',$val['content']);
        $val['content'] = str_replace('[/b]','</div>',$val['content']);
        $table = array();
        $table[0] = '<input type="checkbox" class="checkbox" name="dids[]" value="' . $val['id'] . '" />';
        $table[1] = ($val['uid']?'<a href="home.php?mod=space&uid=' . $val['uid'] . '" target="_blank" class="teachername">' . $val['username'] . '</a>':lang('plugin/keke_doc', '201'));
        $table[2] = '<a href="plugin.php?id=keke_doc&ac=view&did='.$val['did'].'" target="_blank"> <div class="title">'.$val['doc']['title'].'</div></a>';
        $table[3] = '<div class="text">'.$val['content'].'</div>';
        $table[4] = $val['date'];
        $table[5] = '<span class="' . $state[0] . '">' . $state[1] . '</span>';
        showtablerow('', array('width="50px"','','', 'width="40%" style="max-width: 500px;"','','width="100px"'), $table);
    }
}
$multipage = multi($countAll, $ppp, $page, $_G['siteurl'] . $tmpurl);
if ($multipage) echo '<tr class="hover"><td colspan="9">' . $multipage . '</td></tr>';
echo '<style>.zc,.off{border-radius: 2px; color: #fff; font-size: 12px; padding: 2px 5px;}.zc{ background: #6cb057;}.off{background: #f46c6c;}.star{color: #f46c6c;}.title{color: #999;font-weight: 400;margin: 10px 0;}.text{ background: #fbfdff;border: 1px dashed #d9eeff; padding:10px; line-height:23px;font-weight: 400;margin: 10px 3% 10px 0;}.rtype{ background: #0060ff; color: #fff; font-size: 12px; display: inline-block; padding:0px 7px; line-height:20px;font-weight: 400;margin: 0 10px 10px 0;}.typebox{ width: 100%}</style>';
showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'dids\')"><label for="chkallIuPN">'.lang('plugin/keke_doc', '83').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_doc', '89').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="pass" value="pass" class="radio" /><label for="pass" class="vmiddle">'.lang('plugin/keke_doc', '203').'</label>');
showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*Dism_taobao-com*/