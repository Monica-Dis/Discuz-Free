<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
loadcache('plugin');
$keke_doc = $_G['cache']['plugin']['keke_doc'];
header("Content-type:text/html;charset=utf-8");
if($_GET['formhash'] != $_G['formhash']) {
	exit('Formhash Error');
}
require_once DISCUZ_ROOT."source/plugin/keke_doc/function.php";
$zftype=intval($_GET['zftype']);
if(K_INCMAG){
    $zftype=5;
}elseif(K_INQIANFAN){
    $zftype=6;
}
$did=intval($_GET['did']);

if($_GET['orderid']){
    $orderData=C::t('#keke_doc#keke_doc_order')->fetchfirst_byid($_GET['orderid']);
    $orderid=$_GET['orderid'];
    $doc['price']=$orderData['price'];
    $docData = C::t('#keke_doc#keke_doc')->fetchfirst_byid($orderData['did']);
    $payTitle = lang('plugin/keke_doc', '193').' '.lang('plugin/keke_doc', '186').kekeCutStr($docData['title'],28).'��';
}else{
    if(!$did){
        exit(json_encode(array('err' =>keke_doc_gbk2utf(lang('plugin/keke_doc', '194')))));
    }
    $doc = C::t('#keke_doc#keke_doc')->fetchfirst_byid($did);
    $title  = lang('plugin/keke_doc', '193');
    $crePayTitle = lang('plugin/keke_doc', '193').' <a href="'.urlRoute('plugin.php?id=keke_doc&ac=view&did='.$did,1).'" target="_blank">'.lang('plugin/keke_doc', '186').kekeCutStr($doc['title'],28).lang('plugin/keke_doc', '187').'</a>';
    $payTitle = lang('plugin/keke_doc', '193').' '.lang('plugin/keke_doc', '186').kekeCutStr($doc['title'],28).lang('plugin/keke_doc', '187');
    if($doc['credit']){
        $member = C::t('common_member_count')->fetch($_G['uid']);
        if($member['extcredits'.$doc['credit_type']]<$doc['credit']){
            $msg=keke_doc_gbk2utf(lang('plugin/keke_doc', '195').' '.$_G['setting']['extcredits'][$doc['credit_type']]['title'].' '.lang('plugin/keke_doc', '196'));
            exit(json_encode(array('err' =>$msg,'state'=>4)));
        }
    }
    if($zftype!=1 || $_G['cache']['plugin']['keke_pay']['alipaytype']==2 || $_GET['jump']){
        $orderid= docCreateOrder();
        docInstOrder($orderid,$zftype,$did,$doc);
        if($doc['credit']){
            updatemembercount($_G['uid'], array('extcredits'.$doc['credit_type']=>-$doc['credit']), true, '', 0, '',$title,$crePayTitle);
            if($doc['price']<=0){
                upDateOrder($orderid);
                exit(json_encode(array('ewmurl'=>1,'payEnd'=>1,'orderid'=>$orderid)));
            }
        }

    }
}
if($doc['vip_price'] && in_array($_G['groupid'],unserialize($keke_doc['vip']))){
    $doc['price']=$doc['vip_price'];
}
@require_once("source/plugin/keke_pay/payinc.php");
$kekepay= new keke_pay;
$kekepay->keke_dopay($zftype,$orderid,$doc['price'],keke_doc_gbk2utf($payTitle));