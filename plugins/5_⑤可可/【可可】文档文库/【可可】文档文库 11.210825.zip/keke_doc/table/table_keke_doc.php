<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_doc extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_doc';
		$this->_pk    = 'id';

		parent::__construct();
	}

    public function fetchfirst_byid($did) {
        return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$did));
    }

    public function fetch_all_byids($dids) {
        return DB::fetch_all("SELECT * FROM %t WHERE id in (%n)", array($this->_table,$dids), $this->_pk);
    }

    public function fetchfirst_byjobid($jobId) {
        return DB::fetch_first("SELECT * FROM %t WHERE jobid=%s", array($this->_table,$jobId));
    }

    public function fetch_all_doc($startlimit,$ppp,$where='1',$order='order by id desc') {
        $return= DB::fetch_all("SELECT * FROM %t WHERE 1 AND %i %i LIMIT %d,%d", array($this->_table,$where,$order,$startlimit,$ppp), $this->_pk);
        $username=$this->getUserName($return);
        foreach($return as $key=>$val){
            $return[$key]['time']=dgmdate($val['dateline'], 'Y-m-d H:i:s');
            $return[$key]['date']=dgmdate($val['dateline'], 'm-d');
            $return[$key]['username']=$username[$val['uid']];
        }
        return $return;
    }

    public function count_all($where='1') {
        return DB::result_first("SELECT count(*) FROM %t WHERE 1 AND %i", array($this->_table,$where));
    }

    public function count_all_by_uidgroup() {
        $return=[];
        $data=DB::fetch_all("SELECT uid,count(uid) as count FROM %t GROUP BY uid ORDER BY count DESC LIMIT 7", array($this->_table), 'uid');
        $username=$this->getUserName($data);
        foreach ($data as $key=>$val) {
            $val['username']=$username[$val['uid']];
            $return[$key]=$val;
        }
        return $return;
    }

    public function getUserName($data){
        $uids=[];
        foreach($data as $val){
            $uids[$val['uid']]=$val['uid'];
        }
        return C::t('common_member')->fetch_all_username_by_uid($uids);
    }


    public function fetch_by_catenew($num,$cateData=array()) {
	    if(!$cateData){
            foreach (kekeGetAllCate() as $cateVal) {
                if($cateVal['upid']==0)$cateData[]=$cateVal['cate_id'];
            }
        }
        foreach ($cateData as $cate) {
            $return[$cate]=$this->fetch_all_doc(0,$num,'state=3 AND cate='.$cate);
        }
        return $return;
    }

    public function increase($doc_id, $setarr) {
        $sql = array();
        $allowkey = array('view','down');
        foreach($setarr as $key => $value) {
            if(($value = intval($value)) && in_array($key, $allowkey)) {
                $sql[] = "`$key`=`$key`+'$value'";
            }
        }
        $wheresql = DB::field('id', $doc_id);
        if(!empty($sql)){
            return DB::query('UPDATE %t SET %i WHERE %i', array($this->_table, implode(',', $sql), $wheresql));
        }
    }

}