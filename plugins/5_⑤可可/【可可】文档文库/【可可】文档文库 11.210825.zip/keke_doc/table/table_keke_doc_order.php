<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_doc_order extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_doc_order';
		$this->_pk    = 'id';

		parent::__construct();
	}
	
	
	public function fetchfirst_byid($oid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%s", array($this->_table,$oid));
	}
	
	
	public function fetch_all_by_days($tuid) {
		return DB::fetch_all("select FROM_UNIXTIME(time,'%i') as days,count(id) as count,sum(price) as price from %t where time > UNIX_TIMESTAMP(date_sub(curdate(), interval 7 day)) AND teacher_uid=%d AND state = 1 group by days", array('%Y%m%d',$this->_table,$tuid));
	}


    public function fetch_all_data($startlimit,$ppp,$where='1',$order='order by time desc') {
        $return= DB::fetch_all("SELECT * FROM %t WHERE 1 AND %i %i LIMIT %d,%d", array($this->_table,$where,$order,$startlimit,$ppp), $this->_pk);
        foreach($return as $key=>$val){
            $did[$val['did']]=$val['did'];
            $uids[$val['uid']]=$val['uid'];
        }
        $doc=$this->getDoc($did);
        $username=C::t('common_member')->fetch_all_username_by_uid($uids);
        foreach($return as $key=>$val){
            $return[$key]['date']=dgmdate($val['time'], 'Y-m-d H:i:s');
            $return[$key]['doc']=$doc[$val['did']];
            $return[$key]['username']=$username[$val['uid']];
        }
        return $return;
    }

    public function sum_all_by_uidgroup() {
        $data=DB::fetch_all("SELECT author_uid,sum(price) as sum FROM %t WHERE state=1 GROUP BY author_uid ORDER BY sum DESC LIMIT 7", array($this->_table), 'author_uid');
        foreach($data as $val){
            $uids[$val['author_uid']]=$val['author_uid'];
        }
        $username=C::t('common_member')->fetch_all_username_by_uid($uids);
        foreach ($data as $key=>$val) {
            $data[$key]['username']=$username[$val['author_uid']];
        }
        return $data;
    }


    private function getDoc($did){
        return C::t('#keke_doc#keke_doc')->fetch_all_byids($did);
    }
	
	public function count_all($where='1') {
		return DB::result_first("SELECT count(*) FROM %t WHERE 1 AND %i", array($this->_table,$where));
	}
	
	
	public function count_all_money($tuid) {
		return DB::result_first("SELECT sum(price) FROM %t WHERE teacher_uid=%d AND state=1 AND id NOT LIKE %d", array($this->_table,$tuid,'%ALL%'));
	}

}