<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$table = array();
	showtips(lang('plugin/keke_doc', '137'));
    showtableheader(lang('plugin/keke_doc', '138'));
    showsubtitle(array(lang('plugin/keke_doc', '21'),'', lang('plugin/keke_doc', '139'), lang('plugin/keke_doc', '140')));

    $wap=file_exists("source/plugin/keke_video_base/keke_video_base.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_doc', '141').'</span>' : '<a href="https://dism.taobao.com/plugins/keke_video_base.html"><span class="error">'.lang('plugin/keke_doc', '142').'</span></a>';
    $table[0] = '<img src="source/plugin/keke_doc/template/images/keke_video_base.png" width="40" height="40" />';
    $table[1] = lang('plugin/keke_doc', '143');
    $table[2] = '<span class="light tips2">'.lang('plugin/keke_doc', '144').'</span>';
    $table[3] = $wap;
    showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);


    $wap=file_exists("source/plugin/keke_exam/keke_exam.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_doc', '141').'</span>' : '<a href="https://dism.taobao.com/plugins/keke_exam.html"><span class="error">'.lang('plugin/keke_doc', '142').'</span></a>';
    $table[0] = '<img src="source/plugin/keke_doc/template/images/keke_exam.png" width="40" height="40" />';
    $table[1] = lang('plugin/keke_doc', '145');
    $table[2] = '<span class="light tips2">'.lang('plugin/keke_doc', '146').'</span>';
    $table[3] = $wap;
    showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);

	
	$wap=file_exists("source/plugin/keke_group/keke_group.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_doc', '141').'</span>' : '<a href="https://dism.taobao.com/?@keke_group.plugin"><span class="error">'.lang('plugin/keke_doc', '142').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_doc/template/images/keke_group.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_doc', '147');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_doc', '148').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	$wap=file_exists("source/plugin/keke_chongzhi/keke_chongzhi.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_doc', '141').'</span>' : '<a href="https://dism.taobao.com/?@keke_chongzhi.plugin"><span class="error">'.lang('plugin/keke_doc', '142').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_doc/template/images/keke_chongzhi.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_doc', '149');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_doc', '150').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	
	$wap=file_exists("source/plugin/keke_help/keke_help.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_doc', '141').'</span>' : '<a href="https://dism.taobao.com/?@keke_help.plugin"><span class="error">'.lang('plugin/keke_doc', '142').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_doc/template/images/keke_help.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_doc', '151');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_doc', '152').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);

	
	$wap=file_exists("source/plugin/keke_domain/keke_domain.php")? '<span class="diffcolor2">'.lang('plugin/keke_doc', '141').'</span>' : '<a href="https://dism.taobao.com/plugins/keke_domain.html"><span class="error">'.lang('plugin/keke_doc', '142').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_doc/template/images/keke_domain.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_doc', '153');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_doc', '154').'	</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
    showtablefooter(); /*dism��taobao��com*/