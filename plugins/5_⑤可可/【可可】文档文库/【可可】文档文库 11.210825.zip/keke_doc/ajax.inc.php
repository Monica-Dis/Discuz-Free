<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$keke_doc = $_G['cache']['plugin']['keke_doc'];
if ($_GET['formhash'] != $_G['formhash']) {
    exit('Formhash_Error');
}
require_once libfile('function', 'plugin/keke_doc');
$did = intval($_GET['did']);
$page = max(1, intval($_GET['page']));

switch ($_GET['ac']) {
    case 'updoc':
        //验证是否有权限上传
        $retfile = _upload_file($_FILES['file']);
        $docfile = array(
            'name' => $retfile['name'],
            'ext' => $retfile['ext'],
            'size' => $retfile['size'],
            'url' => $retfile['dir'] . $retfile['attachname'],
        );
        header('Content-type: text/html');
        exit(json_encode($docfile));
    case 'getsubcate':
        $cateid = intval($_GET['cateid']);
        $catedata = kekeGetAllCate();
        $data = array();
        if ($catedata[$cateid]['subcate']) {
            foreach ($catedata[$cateid]['subcate'] as $key => $val) {
                $data[] = array($key, keke_doc_gbk2utf($catedata[$key]['name']));
            }
            $type = 0;
        } else {
            $data[] = array($cateid, keke_doc_gbk2utf($catedata[$cateid]['name']));
            $type = 1;
        }
        exit(json_encode(array('type' => $type, 'datas' => $data)));
    case 'addDoc':
        foreach ($_GET['docfile'] as $key => $doc) {
            if (!$doc['doc_cate'] || !$doc['doc_subcate']) {
                exit(json_encode(array('state' => 2, 'docid' => $key, 'msg' => keke_doc_gbk2utf(lang('plugin/keke_doc', '177')))));
            }
        }
        foreach ($_GET['docfile'] as $doc) {
            $jobArr = CreateJob($doc['docsrc']);
            $arr = array(
                'uid' => $_G['uid'],
                'title' => keke_doc_utf2gbk($doc['title']),
                'intro' => keke_doc_utf2gbk($doc['intro']),
                'cate' => intval($doc['doc_cate']),
                'subcate' => intval($doc['doc_subcate']),
                'thirdcate' => intval($doc['doc_thirdcate']),
                'freepage' => intval($doc['freepage']),
                'price' => floatval($doc['price']),
                'credit' => intval($doc['credit']),
                'credit_type' => intval($doc['credit_type']),
                'docsrc' => $doc['docsrc'],
                'ext' => $doc['ext'],
                'filename' => keke_doc_utf2gbk($doc['filename']),
                'jobid' => $jobArr['JobsDetail']['JobId'],
                'size' => intval($doc['size']),
                'dateline' => TIMESTAMP,
                'state' => in_array($_G['groupid'],unserialize($keke_doc['freegroup']))?2:1
            );
            if($keke_doc['viewbase']){
                $arr['view']=getRangeNum($keke_doc['viewbase']);
            }
            if($keke_doc['downdown']){
                $arr['down']=getRangeNum($keke_doc['downdown']);
            }
            $docId = C::t('#keke_doc#keke_doc')->insert($arr, true, false);
        }
        exit(json_encode(array('state' => $docId)));
    case 'addview':
        C::t('#keke_doc#keke_doc')->increase($did, array(
            'view' => 1
        ));
        if($_G['uid']){
            $checkHistory=C::t('#keke_doc#keke_doc_history')->fetchfirst_bydid($did, $_G['uid']);
            if($checkHistory){
                C::t('#keke_doc#keke_doc_history')->update($did, array('time'=>TIMESTAMP));
            }else{
                C::t('#keke_doc#keke_doc_history')->insert(array(
                    'uid'=>$_G['uid'],
                    'did'=>$did,
                    'time'=>TIMESTAMP
                ));
            }
        }
        exit(json_encode(array('state' => 1)));
    case 'getTempKey':
        include_once DISCUZ_ROOT . './source/plugin/keke_doc/sdk/cos-php-sdk-v5/sample/sts.php';
        $sts = new Sts();
        $config = array(
            'url' => 'https://sts.tencentcloudapi.com/',
            'domain' => 'sts.tencentcloudapi.com',
            'proxy' => '',
            'secretId' => $keke_doc['secretid'],
            'secretKey' => $keke_doc['secretkey'], // secretKey
            'bucket' => $keke_doc['bucket'], //bucket
            'region' => $keke_doc['region'], // region
            'durationSeconds' => 1800, // 密钥有效期
            'allowPrefix' => '*', // 允许的路径前缀，例子：* 或者 a/* 或者 a.jpg
            // 密钥的权限列表。
            'allowActions' => array(
                // 简单上传
                'name/cos:PutObject',
                'name/cos:PostObject',
                // 分片上传
                'name/cos:InitiateMultipartUpload',
                'name/cos:ListMultipartUploads',
                'name/cos:ListParts',
                'name/cos:UploadPart',
                'name/cos:CompleteMultipartUpload',
                'name/cos:DeleteObject'
            )
        );
        $tempKeys = $sts->getTempKeys($config);
        $tempKeys['key'] = 'keke_doc/' . date('Ym') . '/' . date('d') . '/' . date('His') . strtolower(random(16)) . '.' . dhtmlspecialchars($_GET['ext']);
        header('Content-Type: application/json');
        header('Access-Control-Allow-Origin: ' . $_G['siteurl']);
        header('Access-Control-Allow-Headers: origin,accept,content-type');
        exit(json_encode($tempKeys));
    case 'getdoc':
        $docUrl = $PageInfoArr = [];
        $lastPage = $_GET['last'] ? intval($_GET['last']) + 1 : 1;
        $doc = C::t('#keke_doc#keke_doc')->fetchfirst_byid($did);
        $myDoc = C::t('#keke_doc#keke_doc_mydoc')->fetchfirst_by_did($did, $_G['uid']);
        if (!$doc['page']) {
            $doc['page'] = activeGetPage($did);
        }
        $xlsArr=getXlsType();
        if(in_array($doc['ext'],$xlsArr)){
            if($doc['pageinfo']){
                $PageInfoArr=unserialize($doc['pageinfo']);
            }else{
                $xPageInfo=getDocJobs($doc['jobid']);
                foreach($xPageInfo['JobsDetail']['Operation']['DocProcessResult']['PageInfo'] as $PageInfo){
                    $PageInfoArr[$PageInfo['PicIndex']]=$PageInfo['PageNo'].'-'.$PageInfo['PicNum'];
                }
                C::t('#keke_doc#keke_doc')->update($did,array('pageinfo'=>serialize($PageInfoArr)));
            }
        }
        $viewPageNum = 10;
        if ($_GET['topage']) {
            $viewPageNum = intval($_GET['topage']) + 3;
        }
        $freeEnd = 0;
        if(($doc['credit']<=0 && $doc['price']<=0) || $_G['groupid']==1 || in_array($_G['groupid'],unserialize($keke_doc['svip'])) || (in_array($_G['groupid'],unserialize($keke_doc['vip'])) && $doc['vip_price']<=0)){
            $doc['freepage']=0;
        }
        if (!$myDoc && $doc['freepage']) {
            if ($lastPage == 1) {
                if ($viewPageNum > $doc['freepage']) {
                    $viewPageNum = $doc['freepage'];
                    $freeEnd = 1;
                }
            } else {
                if ($lastPage + $viewPageNum > $doc['freepage']) {
                    $viewPageNum = $doc['freepage'] - $lastPage;
                }
                if ($lastPage >= $doc['freepage']) {
                    $viewPageNum = 0;
                    $freeEnd = 1;
                }
            }
        }

        $surplus = $doc['page'] - ($lastPage + $viewPageNum) + 1;
        $surplus = $surplus <= 0 ? 0 : $surplus;
        $endPage = $lastPage + $viewPageNum;
        $range = ($doc['page'] && $endPage > $doc['page'] + 1) ? $doc['page'] + 1 : $endPage;
        $advData=kekeGetCache('adv');
        for ($i = $lastPage; $i < $range; $i++) {
            $advTmp='';
            if(!$keke_doc['advnum'] || ($keke_doc['advnum'] && $keke_doc['advnum']+1>$i)){
                $advId=array_rand($advData);
                if($advData[$advId]['type']=='image'){
                    $advTmp='<a href="'.$advData[$advId]['url'].'" target="_blank"><img src="'.$advData[$advId]['img'].'" class="docaimg"></a>';
                }else{
                    $advTmp=$advData[$advId]['code'];
                }
            }
            $pageNum=in_array($doc['ext'],$xlsArr)?$PageInfoArr[$i]:$i;
            $docUrl[] = array(
                'url' => GetViewImg($doc['docsrc'], $pageNum),
                'viewid' => $i,
                'adv' => $advTmp
            );
        }
        $surplus = $doc['page'] - ($lastPage + $viewPageNum) + 1;
        $surplus = $surplus <= 0 ? 0 : $surplus;
        exit(json_encode(array('state' => 1, 'data' => $docUrl, 'surplus' => $surplus, 'freeend' => $freeEnd)));
    case 'alldocedit':
        $setTmp = '';
        if ($did) {
            $doc = C::t('#keke_doc#keke_doc')->fetchfirst_byid($did);
        }
        $creditTypeArr=getCredit();
        $CateData = kekeGetAllCate();
        include template('keke_doc:block');
        exit($setTmp);
    case 'addfollow':
        checkLogin();
        $author = intval($_GET['autohid']);
        $checkFollow = C::t('#keke_doc#keke_doc_follow')->fetchfirst_byaid($author, $_G['uid']);
        if ($checkFollow) {
            C::t('#keke_doc#keke_doc_follow')->delete($checkFollow['id']);
        } else {
            C::t('#keke_doc#keke_doc_follow')->insert(array(
                'authorid' => $author,
                'uid' => $_G['uid'],
                'time' => TIMESTAMP
            ));
        }
        exit(json_encode(array('state' => 1)));
    case 'delfollow':
        $followarr = C::t('#keke_doc#keke_doc_follow')->fetchfirst_byid($_GET['followid']);
        checkAuthor($followarr['uid']);
        C::t('#keke_doc#keke_doc_follow')->delete($_GET['followid']);
        exit(json_encode(array('state' => 0)));
    case 'addfavorites':
        checkLogin();
        $checkFavorites = C::t('#keke_doc#keke_doc_favorites')->fetchfirst_bydid($did, $_G['uid']);
        if ($checkFavorites) {
            C::t('#keke_doc#keke_doc_favorites')->delete($checkFavorites['id']);
        } else {
            C::t('#keke_doc#keke_doc_favorites')->insert(array(
                'did' => $did,
                'uid' => $_G['uid'],
                'time' => TIMESTAMP
            ));
        }
        exit(json_encode(array('state' => 1)));
    case 'delfavorites':
        $delfavoritesarr = C::t('#keke_doc#keke_doc_favorites')->fetchfirst_byid($_GET['favoritesid']);
        checkAuthor($delfavoritesarr['uid']);
        C::t('#keke_doc#keke_doc_favorites')->delete($_GET['favoritesid']);
        exit(json_encode(array('state' => 0)));
    case 'editdoclist':
        checkLogin();
        $checkDoc = C::t('#keke_doc#keke_doc')->fetch_all_byids($_GET['select']);
        $editArr = [];
        foreach ($checkDoc as $item) {
            checkAuthor($item['uid']);
            if ($_GET['optype'] == 'del' || (($_GET['optype'] == 'up' || $_GET['optype'] == 'down') && ($item['state'] == 2 || $item['state'] == 3))) {
                $editArr[$item['id']] = $item['id'];
            }
        }
        if ($editArr) {
            if ($_GET['optype'] == 'del') {
                C::t('#keke_doc#keke_doc')->delete($editArr);
            } else {
                $state = $_GET['optype'] == 'up' ? 3 : 2;
                C::t('#keke_doc#keke_doc')->update($editArr, array('state' => $state));
            }
        }
        exit(json_encode(array('state' => 0)));
    case 'editdoc':
        C::t('#keke_doc#keke_doc')->update($did, array(
            'title' => keke_doc_utf2gbk($_GET['title']),
            'intro' => keke_doc_utf2gbk($_GET['intro']),
            'cate' => intval($_GET['cate']),
            'subcate' => intval($_GET['subcate']),
            'thirdcate' => intval($_GET['thirdcate']),
            'freepage' => intval($_GET['freepage']),
            'price' => floatval($_GET['price']),
            'credit' => intval($_GET['credit']),
            'credit_type' => intval($_GET['credittype']),
        ));
        exit(json_encode(array('state' => 0)));
    case 'getqrcode':
        error_reporting(E_ERROR);
        require_once 'source/plugin/keke_doc/static/phpqrcode/phpqrcode.php';
        $url = urldecode($_GET["data"]);
        ob_clean();
        QRcode::png($url);
        break;
    case 'getevaluate':
        $evaluateTmp = '';
        $ppp = 6;
        $startlimit = ($page - 1) * $ppp;
        $where = 'did=' . $did.' AND state=1';
        $countAll = C::t('#keke_doc#keke_doc_evaluate')->count_all($where);
        $evaluateList = C::t('#keke_doc#keke_doc_evaluate')->fetch_all_data($startlimit, $ppp, $where);
        $multipage = filterMultiPage(multi($countAll, $ppp, $page, $_G['siteurl'] . 'plugin.php?id=keke_doc:ajax&ac=getevaluate&formhash=' . FORMHASH . '&did=' . $did));
        include template('keke_doc:block');
        exit($evaluateTmp);
    case 'reply_evaluate':
        $eid=intval($_GET['eid']);
        $evaluate = C::t('#keke_doc#keke_doc_evaluate')->fetchfirst_by_id($eid);
        if($_GET['reply']){
            if($evaluate['reply']){
                exit(json_encode(array('state' => 2,'msg'=>keke_doc_gbk2utf(lang('plugin/keke_doc', '178')))));
            }
            $doc = C::t('#keke_doc#keke_doc')->fetchfirst_byid($evaluate['did']);
            checkAuthor($doc['uid']);
            C::t('#keke_doc#keke_doc_evaluate')->update($eid,array(
                'reply' => keke_doc_utf2gbk($_GET['reply']),
                'replytime'=>TIMESTAMP
            ));
            exit(json_encode(array('state' => 1)));
        }
        $replyEvaluate = '';
        include template('keke_doc:block');
        exit($replyEvaluate);
    case 'waitprice':
        $_GET['orderid']=dhtmlspecialchars($_GET['orderid']);
        $orderData=C::t('#keke_doc#keke_doc_order')->fetchfirst_byid($_GET['orderid']);
        if($_GET['modifyprice'] || $_GET['modifycredit']){
            $doc = C::t('#keke_doc#keke_doc')->fetchfirst_byid($orderData['did']);
            checkAuthor($doc['uid']);
            $arr['revision']=1;
            if($_GET['modifyprice']){
                $arr['price']=floatval($_GET['modifyprice']);
            }
            if($_GET['modifycredit']){
                $arr['credit']=intval($_GET['modifycredit']);
            }
            C::t('#keke_doc#keke_doc_order')->update($_GET['orderid'],$arr);
            exit(json_encode(array('state' => 1)));
        }
        $waitprice ='';
        include template('keke_doc:block');
        exit($waitprice);
    case 'addevaluate':
        $myDoc = C::t('#keke_doc#keke_doc_mydoc')->fetchfirst_by_did($did,$_G['uid']);
        if(!$myDoc){
            exit(json_encode(array('state' => 2,'msg'=>keke_doc_gbk2utf(lang('plugin/keke_doc', '179')))));
        }
        $evaluateData = C::t('#keke_doc#keke_doc_evaluate')->fetchfirst_byuid($did,$_G['uid']);
        if($evaluateData['text']){
            exit(json_encode(array('state' => 2,'msg'=>keke_doc_gbk2utf(lang('plugin/keke_doc', '180')))));
        }
        $evaluate = dhtmlspecialchars($_GET['evaluate']);
        $star = intval($_GET['star']);
        if(!$evaluate || !$star){
            exit(json_encode(array('state' => 2,'msg'=>keke_doc_gbk2utf(lang('plugin/keke_doc', '181')))));
        }
        $doc = getDocData($did);
        $arr=array(
            'star' => $star,
            'text' => keke_doc_utf2gbk($evaluate),
            'did' => $did,
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'authorid' => $doc['uid'],
            'state' => in_array($_G['groupid'],unserialize($keke_doc['trust_group']))?1:2,
            'time' => TIMESTAMP,
        );
        $checkPower=in_array($_G['groupid'],unserialize($keke_doc['trust_group']));
        if($checkPower){
            $arr['state']=1;
        }
        C::t('#keke_doc#keke_doc_evaluate')->insert($arr, true, false);
        if(!$checkPower){
            exit(json_encode(array('state' => 2,'msg'=>keke_doc_gbk2utf(lang('plugin/keke_doc', '182')))));
        }
        exit(json_encode(array('state' => 1)));
    case 'userset':
        $arr = array(
            'uid' => $_G['uid'],
            'name' => keke_doc_utf2gbk($_GET['nickname']),
            'rank' => keke_doc_utf2gbk($_GET['rank']),
            'profile' => keke_doc_utf2gbk($_GET['profile']),
            'time' => TIMESTAMP,
        );
        $docUserId = C::t('#keke_doc#keke_doc_user')->insert($arr, true, true);
        exit(json_encode(array('state' => 1)));
    case 'saleoff':
        $checkDoc = C::t('#keke_doc#keke_doc')->fetchfirst_byid($did);
        checkAuthor($checkDoc['uid']);
        C::t('#keke_doc#keke_doc')->update($did, array('state' => ($_GET['saleoff'] ? 3 : 2)));
        exit(json_encode(array('state' => 1)));
    case 'checkorder':
        $state = 0;
        $orderData = C::t('#keke_doc#keke_doc_order')->fetchfirst_byid($_GET['orderid']);
        if ($orderData['state'] == 1) {
            $state = 1;
        }
        exit(json_encode(array('state' => $state)));
    case 'checkapppay':
        $orderData=C::t('#keke_doc#keke_doc_order')->fetchfirst_byid($_GET['orderid']);
        @require_once DISCUZ_ROOT."source/plugin/keke_pay/payinc.php";
        $keke_notify=new keke_notify;
        $result=false;
        if($orderData['pay_type']==5){
            $result=$keke_notify->checkMagAppState();
        }elseif($orderData['pay_type']==6){
            $result=$keke_notify->checkQianFanState();
        }
        if($orderData && $orderData['state']!=1 && $result){
            upDateOrder($_GET['orderid']);
            exit(json_encode(array('state'=>1)));
        }
        exit(json_encode(array('state'=>2)));
    case 'updateqianfansn':
        C::t('#keke_doc#keke_doc_order')->update($_GET['id'],array('sn'=>$_GET['sn']));
        exit(json_encode(array('state'=>1)));
    case 'getdoclist':
        $_GET['cateid']=dhtmlspecialchars($_GET['cateid']);
        switch ($_GET['cateid']){
            case 'recommend':
                $where='recommend=1';
                break;
            case 'new':
                $where='1';
                break;
            default:
                $cateId=intval($_GET['cateid']);
                $where='cate='.$cateId;
        }
        $tmpurl='plugin.php?id=keke_doc:ajax&ac=getdoclist&cateid='.$_GET['cateid'];
        $docList = getDocList($where,$tmpurl,'ORDER BY dateline DESC');
        $docData=[];
        foreach ($docList[0] as $key=>$item) {
            $docData[]=[
                'id'=>$item['id'],
                'title'=>keke_doc_gbk2utf($item['title']),
                'thumb'=>$item['thumb'],
                'url'=>$item['url'],
                'exttype'=>getTypeIcon($item['ext']),
                'time'=>$item['time'],
            ];
        }
        exit(json_encode(array('state'=>1,'list'=>$docData)));
    case 'report':
        $report=$reporttype='';
        $typeData=explode(',',$keke_doc['reporttype']);
        if($_GET['reporttype'] && $_GET['did']){
            $content=keke_doc_utf2gbk($_GET['reporttxt']);
            foreach ($_GET['reporttype'] as $item) {
                $reporttype.='[t]'.$typeData[$item].'[/t]';
            }
            $content='[b]'.$reporttype.'[/b]'.$content;
            $arr = array(
                'uid' => $_G['uid'],
                'content' => $content,
                'did' => $did,
                'ip' => $_SERVER['REMOTE_ADDR'],
                'type'=> dimplode($_GET['reporttype']),
                'state' => 1,
                'time' => TIMESTAMP,
            );
            C::t('#keke_doc#keke_doc_report')->insert($arr, true, false);
            exit(json_encode(array('state'=>1)));
        }
        $doc = getDocData($did);
        include template('keke_doc:block');
        exit($report);

}