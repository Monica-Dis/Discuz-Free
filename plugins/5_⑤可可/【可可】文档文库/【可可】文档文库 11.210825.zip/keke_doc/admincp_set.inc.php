<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;
loadcache('plugin');
require_once libfile('function', 'plugin/keke_doc');
$allcatedata=kekeGetAllCate();
$_GET['op']=$_GET['op']?$_GET['op']:'seo';
kekeShowAdminSubMenu(array(
    array(lang('plugin/keke_doc', '01'), "seo"),
    array('PC'.lang('plugin/keke_doc', '02'), "index_slider"),
    array('PC'.lang('plugin/keke_doc', '05'), "pc_nav"),
    array(lang('plugin/keke_doc', '06'), "mobile_slider"),
    array(lang('plugin/keke_doc', '07'), "mobile_nav"),
    array(lang('plugin/keke_doc', '08'), "mobile_discover"),
    array(lang('plugin/keke_doc', '09'), "mobile_block"),
    array(lang('plugin/keke_doc', '10'), "space_adv"),
),'admincp_set');

if ($_GET['op'] == 'index_slider') {
    $slider=kekeGetCache('slider');
    if (submitcheck("forumset")) {
        if(is_array($_GET['delete'])) {
            C::t('#keke_doc#keke_doc_slider')->delete($_GET['delete']);
            kekeSaveCache('slider');
        }
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=index_slider', 'succeed');
    }
    if($_GET['ac']=='editpic'){
        if (!submitcheck("editsubmit")) {
            if($_GET['keyid']){
                $keyid=intval($_GET['keyid']);
                $dataarr=$slider[$keyid];
            }
            showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=index_slider&ac=editpic", 'enctype');
            showtableheader(lang('plugin/keke_doc', '12'));
            showsetting(lang('plugin/keke_doc', '13'),'spic',$dataarr['img'],'filetext');
            showsetting(lang('plugin/keke_doc', '14'),'url',$dataarr['url'],'text');
            showsetting(lang('plugin/keke_doc', '15'),'displayorder',$dataarr['displayorder'],'text');
            echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
            showsubmit('editsubmit', 'submit', '');
            showtablefooter(); /*dism��taobao��com*/
            showformfooter(); /*Dism_taobao-com*/
            exit;
        }else{
            $picurl=_upload_img($_FILES['spic'],'',300);
            $pic=$picurl ? $picurl : $_GET['spic'];
            if(!$pic){
                cpmsg(lang('plugin/keke_doc', '16'), '', 'error');
            }
            $arr=array(
                'id'=>intval($_GET['keyid']),
                'img'=> $pic,
                'url'=> $_GET['url'],
                'type'=>1,
                'displayorder'=> $_GET['displayorder'],
            );
            C::t('#keke_doc#keke_doc_slider')->insert($arr,false,true);
            kekeSaveCache('slider');
            cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=index_slider', 'succeed');
        }
    }
    showtips(lang('plugin/keke_doc', '17'));
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=index_slider", 'enctype');
    showtableheader(lang('plugin/keke_doc', '18'));
    showsubtitle(array('del',lang('plugin/keke_doc', '13'),lang('plugin/keke_doc', '14'),lang('plugin/keke_doc', '15'),lang('plugin/keke_doc', '19')));

    foreach($slider as $slider_data){
        if($slider_data['type']==1){
            $table = array();
            $table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
            $table[1] = '<img src="'.$slider_data['img'].'" width="180" />';
            $table[2] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
            $table[3] = $slider_data['displayorder'];
            $table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=index_slider&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_doc', '19').'</a>';
            showtablerow('',array(), $table);
        }
    }
    showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=index_slider&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_doc', '20').'</a>');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
} else if ($_GET['op'] == 'mobile_slider') {
    $slider=kekeGetCache('slider');
    if (submitcheck("forumset")) {
        if(is_array($_GET['delete'])) {
            C::t('#keke_doc#keke_doc_slider')->delete($_GET['delete']);
            kekeSaveCache('slider');
        }
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_slider', 'succeed');
    }
    if($_GET['ac']=='editpic'){
        if (!submitcheck("editsubmit")) {
            if($_GET['keyid']){
                $keyid=intval($_GET['keyid']);
                $dataarr=$slider[$keyid];
            }
            showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=mobile_slider&ac=editpic", 'enctype');
            showtableheader(lang('plugin/keke_doc', '12'));
            showsetting(lang('plugin/keke_doc', '13'),'spic',$dataarr['img'],'filetext');
            showsetting(lang('plugin/keke_doc', '14'),'url',$dataarr['url'],'text');
            showsetting(lang('plugin/keke_doc', '15'),'displayorder',$dataarr['displayorder'],'text');
            echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
            showsubmit('editsubmit', 'submit', '');
            showtablefooter(); /*dism��taobao��com*/
            showformfooter(); /*Dism_taobao-com*/
            exit;
        }else{
            $picurl=_upload_img($_FILES['spic'],1200,432);
            $pic=$picurl ? $picurl : $_GET['spic'];
            if(!$pic){
                cpmsg(lang('plugin/keke_doc', '16'), '', 'error');
            }
            $arr=array(
                'id'=>intval($_GET['keyid']),
                'img'=> $pic,
                'url'=> $_GET['url'],
                'type'=>2,
                'displayorder'=> $_GET['displayorder'],
            );
            C::t('#keke_doc#keke_doc_slider')->insert($arr,false,true);
            kekeSaveCache('slider');
            cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_slider', 'succeed');
        }
    }
    showtips(lang('plugin/keke_doc', '17'));
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_slider", 'enctype');
    showtableheader('header');
    showsubtitle(array('del',lang('plugin/keke_doc', '13'),lang('plugin/keke_doc', '14'),lang('plugin/keke_doc', '15'),lang('plugin/keke_doc', '19')));

    foreach($slider as $slider_data){
        if($slider_data['type']==2){
            $table = array();
            $table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
            $table[1] = '<img src="'.$slider_data['img'].'" width="180" />';
            $table[2] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
            $table[3] = $slider_data['displayorder'];
            $table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_slider&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_doc', '19').'</a>';
            showtablerow('',array(), $table);
        }
    }
    showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_slider&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_doc', '20').'</a>');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
}elseif ($_GET['op'] == 'mobile_nav') {
    $slider=kekeGetCache('slider');
    $all_set=kekeGetSet();
    if (submitcheck("forumset")) {
        if(is_array($_GET['delete'])) {
            C::t('#keke_doc#keke_doc_slider')->delete($_GET['delete']);
            kekeSaveCache('slider');
        }
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_nav', 'succeed');
    }
    if (submitcheck("forumsets")) {
        $arr=array(
            'rownum'=>intval($_GET['rownum']),
            'mobilenavrows'=>intval($_GET['mobilenavrows']),
        );
        kekeInsertSet($arr);
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_nav', 'succeed');
    }
    if($_GET['ac']=='editpic'){
        if (!submitcheck("editsubmit")) {
            $dataarr=[];
            if($_GET['keyid']){
                $keyid=intval($_GET['keyid']);
                $dataarr=$slider[$keyid];
            }
            showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=mobile_nav&ac=editpic", 'enctype');
            showtableheader(lang('plugin/keke_doc', '12'));
            showsetting(lang('plugin/keke_doc', '21'),'title',$dataarr['title'],'text');
            showsetting(lang('plugin/keke_doc', '13'),'spic',$dataarr['img'],'filetext');
            showsetting(lang('plugin/keke_doc', '14'),'url',$dataarr['url'],'text');
            showsetting(lang('plugin/keke_doc', '15'),'displayorder',$dataarr['displayorder'],'text');
            echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
            showsubmit('editsubmit', 'submit', '');
            showtablefooter(); /*dism��taobao��com*/
            showformfooter(); /*Dism_taobao-com*/
            exit;
        }else{
            $picurl=_upload_img($_FILES['spic'],220,220);
            $pic=$picurl ?: $_GET['spic'];
            if(!$pic){
                cpmsg(lang('plugin/keke_doc', '16'), '', 'error');
            }
            $arr=array(
                'id'=>intval($_GET['keyid']),
                'title'=> $_GET['title'],
                'img'=> $pic,
                'url'=> $_GET['url'],
                'type'=>3,
                'displayorder'=> $_GET['displayorder'],
            );
            C::t('#keke_doc#keke_doc_slider')->insert($arr,false,true);
            kekeSaveCache('slider');
            cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_nav', 'succeed');
        }
    }
    showtips(lang('plugin/keke_doc', '22'));
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_nav", 'enctype');
    showtableheader(lang('plugin/keke_doc', '23'));
    showsetting(lang('plugin/keke_doc', '24'),array('rownum',array(array('4','4'.lang('plugin/keke_doc', '26')),array('5','5'.lang('plugin/keke_doc', '26')))),($all_set['rownum']?:4),'select');
    showsetting(lang('plugin/keke_doc', '27'),'mobilenavrows',($all_set['mobilenavrows']?:2),'text');
    showsubmit('forumsets');
    showtableheader(lang('plugin/keke_doc', '18'));
    showsubtitle(array('del',lang('plugin/keke_doc', '21'),lang('plugin/keke_doc', '13'),lang('plugin/keke_doc', '14'),lang('plugin/keke_doc', '15'),lang('plugin/keke_doc', '19')));
    foreach($slider as $slider_data){
        if($slider_data['type']==3){
            $table = array();
            $table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
            $table[1] = $slider_data['title'];
            $table[2] = '<img src="'.$slider_data['img'].'" width="50" />';
            $table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
            $table[4] = $slider_data['displayorder'];
            $table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_nav&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_doc', '19').'</a>';
            showtablerow('',array(), $table);
        }
    }
    showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_nav&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_doc', '20').'</a>');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
}elseif ($_GET['op'] == 'pc_nav') {
    $slider=kekeGetCache('slider');
    $all_set=kekeGetSet();
    if (submitcheck("forumset")) {
        if(is_array($_GET['delete'])) {
            C::t('#keke_doc#keke_doc_slider')->delete($_GET['delete']);
            kekeSaveCache('slider');
        }
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=pc_nav', 'succeed');
    }
    if (submitcheck("forumsets")) {
        $arr=array(
            'rownum'=>intval($_GET['rownum']),
            'mobilenavrows'=>intval($_GET['mobilenavrows']),
        );
        kekeInsertSet($arr);
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=pc_nav', 'succeed');
    }
    if($_GET['ac']=='editpic'){
        if (!submitcheck("editsubmit")) {
            if($_GET['keyid']){
                $keyid=intval($_GET['keyid']);
                $dataarr=$slider[$keyid];
            }
            $dataarr['title']=explode('||',$dataarr['title']);
            showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=pc_nav&ac=editpic", 'enctype');
            showtableheader(lang('plugin/keke_doc', '18'));
            showsetting(lang('plugin/keke_doc', '28'),'title',$dataarr['title'][0],'text');
            showsetting(lang('plugin/keke_doc', '29'),'dec',$dataarr['title'][1],'text');
            showsetting(lang('plugin/keke_doc', '13'),'spic',$dataarr['img'],'filetext');
            showsetting(lang('plugin/keke_doc', '14'),'url',$dataarr['url'],'text');
            showsetting(lang('plugin/keke_doc', '15'),'displayorder',$dataarr['displayorder'],'text');
            echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
            showsubmit('editsubmit');
            showtablefooter(); /*dism��taobao��com*/
            showformfooter(); /*Dism_taobao-com*/
            exit;
        }else{
            $picurl=_upload_img($_FILES['spic'],220,220);
            $pic=$picurl ? $picurl : $_GET['spic'];
            if(!$pic){
                cpmsg(lang('plugin/keke_doc', '16'), '', 'error');
            }
            $title=$_GET['title'].'||'.$_GET['dec'];
            $arr=array(
                'id'=>intval($_GET['keyid']),
                'title'=> $title,
                'img'=> $pic,
                'url'=> $_GET['url'],
                'type'=>5,
                'displayorder'=> $_GET['displayorder'],
            );
            C::t('#keke_doc#keke_doc_slider')->insert($arr,false,true);
            kekeSaveCache('slider');
            cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=pc_nav', 'succeed');
        }
    }
    showtips(lang('plugin/keke_doc', '22'));
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=pc_nav", 'enctype');
    showtableheader(lang('plugin/keke_doc', '18'));
    showsubtitle(array('del',lang('plugin/keke_doc', '13'),lang('plugin/keke_doc', '21'),lang('plugin/keke_doc', '14'),lang('plugin/keke_doc', '15'),lang('plugin/keke_doc', '19')));
    foreach($slider as $slider_data){
        if($slider_data['type']==5){
            $table = array();
            $slider_data['title']=explode('||',$slider_data['title']);
            $table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
            $table[1] = '<img src="'.$slider_data['img'].'" width="50" />';
            $table[2] = '<b>'.$slider_data['title'][0].'</b><div class="dectxt">'.$slider_data['title'][1].'</div>';
            $table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
            $table[4] = $slider_data['displayorder'];
            $table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=pc_nav&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_doc', '19').'</a>';
            showtablerow('',array(), $table);
        }
    }
    showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=pc_nav&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_doc', '20').'</a><style>.dectxt{color:#999; margin-top:5px}</style>');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/

}elseif ($_GET['op'] == 'space_adv') {
    if (submitcheck("forumset")) {
        if(is_array($_GET['delete'])) {
            C::t('#keke_doc#keke_doc_adv')->delete($_GET['delete']);
            kekeSaveCache('adv');
        }
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_doc&pmod=admincp_set&op=space_adv', 'succeed');
    }
    if($_GET['ac']=='editpic'){
        if (!submitcheck("editsubmit")) {
            $dataArr=[];
            if($_GET['adid']){
                $adid=intval($_GET['adid']);
                $dataArr=C::t('#keke_doc#keke_doc_adv')->fetch_first_byid($adid);
            }
            showformheader("plugins&operation=config&do=" . $plugin["pluginid"]."&identifier=".$plugin["identifier"]."&pmod=admincp_set&op=space_adv&ac=editpic", 'enctype');
            showtableheader(lang('plugin/keke_doc', '30'));
            $dataArr['type']=$dataArr['type']?:'image';
            $adv['parameters']['style']='image';
            $adtypearray = array();
            $adtypes = array('image','code');
            foreach($adtypes as $adtype) {
                $displayary = array();
                foreach($adtypes as $adtype1) {
                    $displayary['style_'.$adtype1] = $adtype1 == $adtype ? '' : 'none';
                }
                $adtypearray[] = array($adtype, $lang['adv_style_'.$adtype], $displayary);
            }
            showsetting(lang('plugin/keke_doc', '31'), 'title', $dataArr['title'], 'text');
            showsetting('adv_type', array('adv_type', $adtypearray), $dataArr['type'], 'mradio');
            showtagheader('tbody', 'style_image', $dataArr['type'] == 'image');
            showtitle('adv_edit_style_image');
            showsetting('adv_edit_style_image_url', 'spic', $dataArr['img'], 'filetext');
            showsetting('adv_edit_style_image_link', 'url', $dataArr['url'], 'text');
            showtagheader('tbody', 'style_code', $dataArr['type'] == 'code');
            showtitle('adv_edit_style_code');
            showsetting('adv_edit_style_code_html', 'code', $dataArr['code'], 'textarea');
            showtagfooter('tbody');
            echo '<input name="adid" type="hidden" value="'.$adid.'" />';
            showsubmit('editsubmit', 'submit', '');
            showtablefooter(); /*dism��taobao��com*/
            showformfooter(); /*Dism_taobao-com*/
            exit;
        }else{
            $pic='';
            if($_GET['adv_type']=='image'){
                $picurl=_upload_img($_FILES['spic']);
                $pic=$picurl ?: $_GET['spic'];
                if(!$pic){
                    cpmsg(lang('plugin/keke_doc', '16'), '', 'error');
                }
            }
            $arr=array(
                'id'=>intval($_GET['adid']),
                'type'=> $_GET['adv_type']=='image'?'image':'code',
                'img'=> $pic,
                'url'=> $_GET['url'],
                'title'=> $_GET['title'],
                'code'=>kekeEditorSafeReplace($_GET['code'])
            );
            C::t('#keke_doc#keke_doc_adv')->insert($arr,false,true);
            kekeSaveCache('adv');
            cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=space_adv', 'succeed');
        }
    }
    showtips(lang('plugin/keke_doc', '32'));
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=space_adv", 'enctype');
    showtableheader(lang('plugin/keke_doc', '33'));
    showsubtitle(array('del',lang('plugin/keke_doc', '31'),lang('plugin/keke_doc', '34'),lang('plugin/keke_doc', '19')));
    foreach(C::t('#keke_doc#keke_doc_adv')->fetch_all() as $advData){
            $table = array();
            $table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$advData['id'].'" />';
            $table[1] = $advData['title'];
            $table[2] = $advData['type']=='image'?lang('plugin/keke_doc', '35'):lang('plugin/keke_doc', '36');
            $table[3] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=space_adv&adid='.$advData['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_doc', '19').'</a>';
            showtablerow('',array(), $table);
    }
    showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=space_adv&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_doc', '20').'</a>');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/

}elseif ($_GET['op'] == 'mobile_block') {
    $slider=kekeGetCache('slider');
    $all_set=kekeGetSet();
    if (submitcheck("forumset")) {
        if(is_array($_GET['delete'])) {
            C::t('#keke_doc#keke_doc_slider')->delete($_GET['delete']);
            kekeSaveCache('slider');
        }
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_block', 'succeed');
    }
    if($_GET['ac']=='editpic'){
        if (!submitcheck("editsubmit")) {
            if($_GET['keyid']){
                $keyid=intval($_GET['keyid']);
                $dataarr=$slider[$keyid];
            }
            $dataarr['title']=explode('||',$dataarr['title']);
            showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=".$plugin["identifier"]."&pmod=admincp_set&op=mobile_block&ac=editpic", 'enctype');
            showtableheader(lang('plugin/keke_doc', '37'));
            showsetting(lang('plugin/keke_doc', '28'),'title',$dataarr['title'][0],'text');
            showsetting(lang('plugin/keke_doc', '29'),'dec',$dataarr['title'][1],'text');
            showsetting(lang('plugin/keke_doc', '13'),'spic',$dataarr['img'],'filetext');
            showsetting(lang('plugin/keke_doc', '14'),'url',$dataarr['url'],'text');
            showsetting(lang('plugin/keke_doc', '15'),'displayorder',$dataarr['displayorder'],'text');
            echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
            showsubmit('editsubmit');
            showtablefooter(); /*dism��taobao��com*/
            showformfooter(); /*Dism_taobao-com*/
            exit;
        }else{
            $picurl=_upload_img($_FILES['spic'],344,169);
            $pic=$picurl ?: $_GET['spic'];
            $title=$_GET['title'].'||'.$_GET['dec'];
            $arr=array(
                'id'=>intval($_GET['keyid']),
                'title'=> $title,
                'img'=> $pic,
                'url'=> $_GET['url'],
                'type'=>6,
                'displayorder'=> $_GET['displayorder'],
            );
            C::t('#keke_doc#keke_doc_slider')->insert($arr,false,true);
            kekeSaveCache('slider');
            cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_block', 'succeed');

        }
    }
    showtips(lang('plugin/keke_doc', '38'));
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_block", 'enctype');
    showtableheader(lang('plugin/keke_doc', '33'));
    showsubtitle(array('del',lang('plugin/keke_doc', '13'),lang('plugin/keke_doc', '21'),lang('plugin/keke_doc', '14'),lang('plugin/keke_doc', '15'),lang('plugin/keke_doc', '19')));
    foreach($slider as $slider_data){
        if($slider_data['type']==6){
            $table = [];
            $slider_data['title']=explode('||',$slider_data['title']);
            $table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
            $table[1] = '<img src="'.$slider_data['img'].'" width="50" />';
            $table[2] = '<b>'.$slider_data['title'][0].'</b><div class="dectxt">'.$slider_data['title'][1].'</div>';
            $table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
            $table[4] = $slider_data['displayorder'];
            $table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_block&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_doc', '19').'</a>';
            showtablerow('',array(), $table);
        }
    }
    showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_block&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_doc', '20').'</a><style>.dectxt{color:#999; margin-top:5px}</style>');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
}elseif ($_GET['op'] == 'mobile_discover') {
    $slider=kekeGetCache('slider');
    if (submitcheck("forumset")) {
        if(is_array($_GET['delete'])) {
            C::t('#keke_doc#keke_doc_slider')->delete($_GET['delete']);
            kekeSaveCache('slider');
        }
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_discover', 'succeed');
    }
    if($_GET['ac']=='editpic'){
        if (!submitcheck("editsubmit")) {
            if($_GET['keyid']){
                $keyid=intval($_GET['keyid']);
                $dataarr=$slider[$keyid];
            }
            showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=mobile_discover&ac=editpic", 'enctype');
            showtableheader(lang('plugin/keke_doc', '12'));
            showsetting(lang('plugin/keke_doc', '21'),'title',$dataarr['title'],'text');
            showsetting(lang('plugin/keke_doc', '13'),'spic',$dataarr['img'],'filetext');
            showsetting(lang('plugin/keke_doc', '14'),'url',$dataarr['url'],'text');
            showsetting(lang('plugin/keke_doc', '15'),'displayorder',$dataarr['displayorder'],'text');
            echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
            showsubmit('editsubmit', 'submit', '');
            showtablefooter(); /*dism��taobao��com*/
            showformfooter(); /*Dism_taobao-com*/
            exit;
        }else{
            $picurl=_upload_img($_FILES['spic'],120,120);
            $pic=$picurl ?: $_GET['spic'];
            if(!$pic){
                cpmsg(lang('plugin/keke_doc', '16'), '', 'error');
            }
            $arr=array(
                'id'=>intval($_GET['keyid']),
                'title'=> $_GET['title'],
                'img'=> $pic,
                'url'=> $_GET['url'],
                'type'=>4,
                'displayorder'=> $_GET['displayorder'],
            );
            C::t('#keke_doc#keke_doc_slider')->insert($arr,false,true);
            kekeSaveCache('slider');
            cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_discover', 'succeed');

        }
    }
    showtips(lang('plugin/keke_doc', '22'));
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_discover", 'enctype');
    showtableheader('header');
    showsubtitle(array('del',lang('plugin/keke_doc', '28'),lang('plugin/keke_doc', '13'),lang('plugin/keke_doc', '14'),lang('plugin/keke_doc', '15'),lang('plugin/keke_doc', '19')));

    foreach($slider as $slider_data){
        if($slider_data['type']==4){
            $table = array();
            $table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
            $table[1] = $slider_data['title'];
            $table[2] = '<img src="'.$slider_data['img'].'" width="50" />';
            $table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
            $table[4] = $slider_data['displayorder'];
            $table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_discover&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_doc', '19').'</a>';
            showtablerow('',array(), $table);
        }
    }
    showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_discover&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_doc', '20').'</a>');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/

} else if ($_GET['op'] == 'seo') {
    $all_set=kekeGetSet();
    if (!submitcheck("editsubmit")) {
        showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=seo", '');
        showtableheader(lang('plugin/keke_doc', '39').lang('plugin/keke_doc', '01'));
        showsetting('title','index_title',$all_set['index_title'],'text');
        showsetting('keywords','index_keywords',$all_set['index_keywords'],'text');
        showsetting('description','index_description',$all_set['index_description'],'textarea');
        showtableheader(lang('plugin/keke_doc', '40').lang('plugin/keke_doc', '01'));
        showsetting(lang('plugin/keke_doc', '41'),'list_index_title',$all_set['list_index_title'],'text');
        showsetting('title','list_title',$all_set['list_title'],'text','','',lang('plugin/keke_doc', '42'));
        showsetting('keywords','list_keywords',$all_set['list_keywords'],'text','','',lang('plugin/keke_doc', '42'));
        showsetting('description','list_description',$all_set['list_description'],'textarea');
        showtableheader(lang('plugin/keke_doc', '43').lang('plugin/keke_doc', '01'));
        showsetting('title','doc_title',$all_set['doc_title'],'text','','',lang('plugin/keke_doc', '44'));
        showsetting('keywords','doc_keywords',$all_set['doc_keywords'],'text','','',lang('plugin/keke_doc', '44'));
        showsetting('description','doc_description',$all_set['doc_description'],'textarea','','',lang('plugin/keke_doc', '44'));
        showtableheader(lang('plugin/keke_doc', '45').lang('plugin/keke_doc', '01'));
        showsetting('title','user_title',$all_set['user_title'],'text','','',lang('plugin/keke_doc', '46'));
        showsetting('keywords','user_keywords',$all_set['user_keywords'],'text','','',lang('plugin/keke_doc', '46'));
        showsetting('description','user_description',$all_set['user_description'],'textarea','','',lang('plugin/keke_doc', '46'));
        showsubmit('editsubmit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
        exit;
    }else{
        $arr=array(
            'index_title'=>$_GET['index_title'],
            'index_keywords'=>$_GET['index_keywords'],
            'index_description'=>$_GET['index_description'],
            'list_title'=>$_GET['list_title'],
            'list_index_title'=>$_GET['list_index_title'],
            'list_keywords'=>$_GET['list_keywords'],
            'list_description'=>$_GET['list_description'],
            'doc_title'=>$_GET['doc_title'],
            'doc_keywords'=>$_GET['doc_keywords'],
            'doc_description'=>$_GET['doc_description'],
            'user_title'=>$_GET['user_title'],
            'user_keywords'=>$_GET['user_keywords'],
            'user_description'=>$_GET['user_description'],
        );
        kekeInsertSet($arr);
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=seo', 'succeed');
    }
}