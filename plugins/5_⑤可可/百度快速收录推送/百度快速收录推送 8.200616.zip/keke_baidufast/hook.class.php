<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_keke_baidufast{
	public function __construct(){
		global $_G,$article;
		$this->keke_baidufast = $_G['cache']['plugin']['keke_baidufast'];
		$this->perform=1;
		$this->fid=$_G['fid'];
		$this->section = empty($this->keke_baidufast['bk']) ? array() : unserialize($this->keke_baidufast['bk']);
		if(!(empty($this->section[0]) || in_array($this->fid,$this->section))){
			$this->perform=0;
		}
		if(CURSCRIPT=='forum'){
			$this->moda=2;
			$this->atid=$_G['tid'];
			$this->urla=$this->_creurl(2,$this->atid);

		}elseif(CURSCRIPT=='portal'){
			$this->moda=1;
			$this->atid=intval($_GET['aid']);
			$this->urla=$this->_creurl(1,$this->atid);
		}
	}
	
	function _checkzs($message){
		$sppos = strpos($message, chr(0).chr(0).chr(0));
		if($sppos !== false) {
			$message = substr($message, 0, $sppos);
		}
		$posttxt=strip_tags($message);
		$txtcount=mb_strwidth($posttxt);
		if($txtcount<$this->keke_baidufast['zs']){
			return false;
		}
		return true;
	}
	
	function _creurl($mods,$atid){
		global $_G;
		$_GET['page']=$_GET['page']?$_GET['page']:1;
		if($mods==2){
			$urla='forum.php?mod=viewthread&tid='.$atid;
			if($this->keke_baidufast['tformat']){
				$thread = C::t('forum_thread')->fetch($atid);
				$fid = empty($_G['setting']['forumkeys'][$thread['fid']]) ? $thread['fid'] : $_G['setting']['forumkeys'][$thread['fid']];
				$urla=dhtmlspecialchars(str_ireplace(array('{tid}','{fid}','{page}'),array($atid,$fid,intval($_GET['page'])),$this->keke_baidufast['tformat']));
			}else{
				if(in_array('forum_viewthread', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus']==1){
					$urla=rewriteoutput('forum_viewthread', 1, '', $atid,$_GET['page']);
				}
			}
		}elseif($mods==1){
			$urla='portal.php?mod=view&aid='.$atid;
			if($this->keke_baidufast['pformat']){
				$urla=dhtmlspecialchars(str_ireplace(array('{id}','{page}'),array($atid,intval($_GET['page'])),$this->keke_baidufast['pformat']));
			}else{
				if(in_array('portal_article', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus']==1){
					$urla=rewriteoutput('portal_article', 1, '', $atid,$_GET['page']);
				}
			}
		}
		return $urla;
	}
		
	function _getpostdata(){
		return C::t('#keke_baidufast#keke_baidufast')->fetchfirst_byatid(intval($_GET['atid']),intval($_GET['mods']));
	}
	
	function _posttobaidu($atid,$mods,$purl=array()){
		global $_G;
		$var = $_G['cache']['plugin']['keke_baidufast'];
		require_once libfile('function/cache');
		if($purl){
			$urls = $purl;
		}else{
			$siteurls=$var['domain']?dhtmlspecialchars($var['domain']):$_G['siteurl'];
			if($mods==2){
				$urla=$siteurls.$this->_creurl(2,$atid);
				$thread = C::t('forum_thread')->fetch($atid);
				$subject=$thread['subject'];
			}elseif($mods==1){
				$urla=$siteurls.$this->_creurl(1,$atid);
				$article = C::t('portal_article_title')->fetch($atid);
				$subject=$article['title'];
			}
			$urls[] =$urla;
		}
		
		if(function_exists('curl_init') && function_exists('curl_exec')){
			$ch = curl_init();
			$options =  array(
				CURLOPT_URL => $var['api'],
				CURLOPT_POST => true,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_POSTFIELDS => implode("\n", $urls),
				CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
			);
			curl_setopt_array($ch, $options);
			$result = curl_exec($ch);
			$ret=json_decode($result, true);
		}else{
			$ret['error']=9990;
			$ret['message']='curl error';
		}
		$cacearr=array(
			'time'=>TIMESTAMP,
			'remain'=>$ret['remain'],
		);
		savecache('keke_baidufast', $cacearr);
		
		if($ret['error']){
			$state=intval($ret['error']);
			$msg=daddslashes($ret['message']);
		}else{
			if($ret['success'] || $ret['success_batch'] || $ret['success_realtime']){
				$state=1;
			}else{
				if($ret['not_same_site']){
					$state=2;
					$msg='not_same_site';
				}
				if($ret['not_valid']){
					$state=3;
					$msg='not_valid';
				}
			}
		}	
		if($atid){
			$arr=array(
				'subject'=> $subject,
				'url'=>implode("\n", $urls),
				'state'=>$state,
				'msg'=>$msg,
				'time'=>$_G['timestamp'],
				'mods'=>$mods,
				'atid'=>$atid
			);
			C::t('#keke_baidufast#keke_baidufast')->insert($arr);
			return json_encode(array('state'=>$state,'msg'=>$msg));
		}else{
			if($ret['error']){
				$r=$state.'/'.$msg;
			}else{
				$r=lang('plugin/keke_baidufast', '006');
			}
			return $r;
		}
	}
	
	function _portalviews(){
		global $_G,$article,$content;
		$sdarr=unserialize($this->keke_baidufast['sd']);
		if($this->moda==1 && $_GET['aid']){
			if($this->keke_baidufast['wz']){
				include template('keke_baidufast:inc');
			}
		}
		return $tsbtn;
	}
	
	function _forumviews() {
		global $_G,$postlist;
		$tsbtn='';
		$sdarr=unserialize($this->keke_baidufast['sd']);
		if($this->moda==2 && $_G['tid']){
			$isgroup=$_G['thread']['isgroup'];
			if(($isgroup && $this->keke_baidufast['qz']) || (!$isgroup && $this->perform)){
				include template('keke_baidufast:inc');
			}
		}
		return array($tsbtn);
	}
}

class plugin_keke_baidufast_forum extends plugin_keke_baidufast{
	function viewthread_posttop_output() {
		global $_G;
		if($_G['forum_firstpid']){
			return $this->_forumviews();
		}
		return array();
	}
}
class mobileplugin_keke_baidufast_forum extends plugin_keke_baidufast{
	function viewthread_posttop_mobile_output(){
		global $_G;
		if($_G['forum_firstpid']){
			return $this->_forumviews();
		}
		return array();
	}
}
class plugin_keke_baidufast_portal  extends plugin_keke_baidufast{
	function view_article_content_output(){
		return $this->_portalviews();
	}
}
class plugin_keke_baidufast_group  extends plugin_keke_baidufast_forum{	
}
class mobileplugin_keke_baidufast_group  extends mobileplugin_keke_baidufast_forum{	
}
class mobileplugin_keke_baidufast_portal  extends plugin_keke_baidufast_portal{	
}