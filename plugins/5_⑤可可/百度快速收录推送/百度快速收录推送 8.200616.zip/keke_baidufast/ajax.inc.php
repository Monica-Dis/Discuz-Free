<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

global $_G;
include_once libfile('function/discuzcode');

if($_GET['formhash'] != $_G['formhash']){
	exit(json_encode(array('state'=>10,'msg'=>'formhash error')));
}

if(!$_G['uid']){
	exit(json_encode(array('state'=>11,'msg'=>'Please log in')));
}

if(!function_exists('curl_init') || !function_exists('curl_exec')){
	exit(json_encode(array('state'=>12,'msg'=>'curl error')));
}

if(!$_GET['atid']){
	exit(json_encode(array('state'=>13,'msg'=>'atid error')));
}

if(!$_GET['mods'] || !(in_array($_GET['mods'],array('1','2')))){
	exit(json_encode(array('state'=>14,'msg'=>'mods error')));
}

include_once DISCUZ_ROOT."source/plugin/keke_baidufast/hook.class.php";
$postdatas=new plugin_keke_baidufast;
$sdarr=unserialize($postdatas->keke_baidufast['sd']);
if($_GET['ac']=='showpostbtn'){
	if($postdatas->keke_baidufast['zd']){
		$atid=intval($_GET['atid']);
		$check_zs=$surplus=$time_nodes=true;
		loadcache('keke_baidufast');
		$beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
		$endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
		if($_G['cache']['keke_baidufast']['remain'] <=0 && $_G['cache']['keke_baidufast']['time'] && $_G['cache']['keke_baidufast']['time']>$beginToday && $_G['cache']['keke_baidufast']['time']<$endToday){
			$surplus=false;
		}
		if($_GET['mods']==2){
			$threadpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($atid);
			if($threadpost['invisible']<0){
				$surplus=false;
			}
			$userdata=getuserbyuid($threadpost['authorid']);
			if($postdatas->keke_baidufast['sj']){
				$timenodes=strtotime($postdatas->keke_baidufast['sj']);
				if($threadpost['dateline']<$timenodes)$time_nodes=false;
			}
			if(in_array($userdata['groupid'],unserialize($postdatas->keke_baidufast['zd'])) && $time_nodes){
				$postdata=$postdatas->_getpostdata();
				if($postdatas->keke_baidufast['zs']){
					include_once libfile('function/discuzcode');
					$message = discuzcode($threadpost['message']);
					$check_zs=$postdatas->_checkzs($message);
				}
				if($check_zs && !$postdata && $surplus)$postdatas->_posttobaidu($atid,2);
			}
		}elseif($_GET['mods']==1){
			$article = C::t('portal_article_title')->fetch($atid);
			$userdata=getuserbyuid($article['uid']); 
			if($postdatas->keke_baidufast['sj']){
				$timenodes=strtotime($postdatas->keke_baidufast['sj']);
				if($article['dateline']<$timenodes)$time_nodes=false;
			}
			if(in_array($userdata['groupid'],unserialize($postdatas->keke_baidufast['zd'])) && $time_nodes){
				$postdata=$postdatas->_getpostdata();
				if($postdatas->keke_baidufast['zs']){
					$content = C::t('portal_article_content')->fetch_by_aid_page($atid, 1);
					$check_zs=$postdatas->_checkzs($content['content']);
				}
				if($check_zs && !$postdata && $surplus)$postdatas->_posttobaidu($atid,1);
			}
		}
	}
	if(in_array($_G['groupid'],$sdarr)){
		$postdata=$postdatas->_getpostdata();
		if($postdata){
			exit(json_encode(array('state'=>2)));
		}
		exit(json_encode(array('state'=>1)));
	}
	exit(json_encode(array('state'=>3)));
}elseif($_GET['ac']=='postdata'){
	if(in_array($_G['groupid'],$sdarr)){
		$postdata=C::t('#keke_baidufast#keke_baidufast')->fetchfirst_byatid(intval($_GET['atid']),intval($_GET['mods']));
		if($postdata['state']==1){
			$tips=('utf-8' != CHARSET)?diconv(lang('plugin/keke_baidufast', '013'), CHARSET, 'utf-8'):lang('plugin/keke_baidufast', '013');
			exit(json_encode(array('state'=>9,'msg'=>$tips)));
		}
		exit($postdatas->_posttobaidu(intval($_GET['atid']),intval($_GET['mods'])));
	}
	$tips=('utf-8' != CHARSET)?diconv(lang('plugin/keke_baidufast', '014'), CHARSET, 'utf-8'):lang('plugin/keke_baidufast', '014');
	exit(json_encode(array('state'=>10,'msg'=>$tips)));
}