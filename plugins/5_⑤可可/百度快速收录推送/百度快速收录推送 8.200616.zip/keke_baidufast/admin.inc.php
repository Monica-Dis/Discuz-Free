<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	date_default_timezone_set('Asia/Chongqing');
	loadcache('plugin');
	loadcache('keke_baidufast');
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
			C::t('#keke_baidufast#keke_baidufast')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/keke_baidufast', '006'), 'action=plugins&operation=config&identifier=keke_baidufast&pmod=admin', 'succeed');
	}
	$beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
	$endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
	$counttotay=C::t('#keke_baidufast#keke_baidufast')->count_all_bytoday();
	$countallsuccess = C::t('#keke_baidufast#keke_baidufast')->count_all_bysuccess();
	$surplus=lang('plugin/keke_baidufast', '015');
	if($_G['cache']['keke_baidufast']['time'] && $_G['cache']['keke_baidufast']['time']>$beginToday && $_G['cache']['keke_baidufast']['time']<$endToday){
		$surplus=intval($_G['cache']['keke_baidufast']['remain']);
	}
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");	
	showtips('<li>'.lang('plugin/keke_baidufast', '016').' <b style="color:red">'.$counttotay.'</b> '.lang('plugin/keke_baidufast', '017').lang('plugin/keke_baidufast', '018').' <b style="color:red">'.$surplus.'</b> '.(is_numeric($surplus)?lang('plugin/keke_baidufast', '017'):'').lang('plugin/keke_baidufast', '019').' <b style="color:red">'.$countallsuccess.'</b> '.lang('plugin/keke_baidufast', '017').'</li><li>'.lang('plugin/keke_baidufast', '020').'</li>');
	showtableheader(lang('plugin/keke_baidufast', '007'));
    showsubtitle(array(lang('plugin/keke_baidufast', '008'),lang('plugin/keke_baidufast', '009'),lang('plugin/keke_baidufast', '010'),lang('plugin/keke_baidufast', '011'),lang('plugin/keke_baidufast', '012')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_baidufast&pmod=admin';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$count = C::t('#keke_baidufast#keke_baidufast')->count_all();
	if($count){
		$liatdata = C::t('#keke_baidufast#keke_baidufast')->fetch_all_by_limit($startlimit,$ppp);
		foreach($liatdata as $key=>$val){
			$state='';
			switch ($val['state']) {
				case 1:$state=lang('plugin/keke_baidufast', '002');break;
				case 2:$state=lang('plugin/keke_baidufast', '003').lang('plugin/keke_baidufast', '004');break;
				case 3:$state=lang('plugin/keke_baidufast', '003').lang('plugin/keke_baidufast', '005');break;
				default:$state=lang('plugin/keke_baidufast', '003').$val['msg'];
			}
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = '<a href="'.$val['url'].'" target="_blank">'.$val['subject'].'</a>';
			$table[2] = '<a href="'.$val['url'].'" target="_blank">'.$val['url'].'</a>';
			$table[3] = $state;
			$table[4] = dgmdate($val['time'], 'Y/m/d H:i:s');
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter();
	showformfooter();/*Dism��taobao��com*/