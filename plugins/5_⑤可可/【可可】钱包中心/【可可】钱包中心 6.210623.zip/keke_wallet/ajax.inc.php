<?php
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_wallet = $_G['cache']['plugin']['keke_wallet'];
if(!$_G['uid'] && $_GET['ac']!='bindwechat'){
    showmessage('not_loggedin', '', array(), array('login' => true));
}
if($_GET['ac'] && $_GET['formhash'] != $_G['formhash'] && $_GET['ac']!='bindwechat' && $_GET['ac']!='showqrcode'){
	exit(json_encode(array('err' =>'Formhash_Error')));
}
if($_GET['ac']=='upqrimg'){
	$picurl=_upload_img($_FILES['uploaderInput'],400);
	C::t('#keke_wallet#keke_wallet_card')->increase(array('wxqr'=>$picurl));
	exit(json_encode(array('err' =>'','picurl'=>$picurl)));
}elseif($_GET['ac']=='delwxqr'){
	$mycard=C::t('#keke_wallet#keke_wallet_card')->fetchfirst_by_uid($_G['uid']);
	if($mycard['wxqr']){
		C::t('#keke_wallet#keke_wallet_card')->update($_G['uid'],array('wxqr'=>''));
		@unlink(DISCUZ_ROOT .'./'.$mycard['wxqr']);
	}
	exit(json_encode(array('err' =>'','state'=>1)));
}elseif($_GET['ac']=='postcard'){
	$getarr=array('name','bank_types','wx','alipay','alipay','card_number');
	foreach($getarr as $val){
		if($_GET[$val]){
			$arr[$val]=addslashes(dhtmlspecialchars(keke_wallet_utf2gbk($_GET[$val])));
		}
	}
	if(!$arr['name']){
		exit(json_encode(array('err' =>keke_walle_gbk2utf(lang('plugin/keke_wallet', '001')))));
	}
	C::t('#keke_wallet#keke_wallet_card')->increase($arr);
	exit(json_encode(array('err' =>'')));	
}elseif($_GET['ac']=='posttixian'){	
	$cardtype=intval($_GET['txcardtype']);
	if(!in_array($cardtype,array(1,2,3)) || ($cardtype == 1 && !$keke_wallet['wxoff']) || ($cardtype == 2 && !$keke_wallet['zfboff']) || ($cardtype == 3 && !$keke_wallet['bankoff'])){
		exit(json_encode(array('err' =>'Cash account error')));
	}
	$money=floatval($_GET['money']);
	if(!$money){
		exit(json_encode(array('err' =>keke_walle_gbk2utf(lang('plugin/keke_wallet', '009')))));
	}
	include_once DISCUZ_ROOT."source/plugin/keke_wallet/api.php";
	$fp = fopen("source/plugin/keke_wallet/lock.php", "w+");
	if(!flock($fp,LOCK_EX | LOCK_NB)){
		exit(json_encode(array('err' =>lang('plugin/keke_wallet', '087'))));
	}
	$mywallet=C::t('#keke_wallet#keke_wallet')->fetchfirst_by_uid($_G['uid']);
	if($mywallet['state']!=1){
		flock($fp,LOCK_UN);
		exit(json_encode(array('err' =>keke_walle_gbk2utf(lang('plugin/keke_wallet', '010')))));
	}
	$sxf=sprintf("%.2f",$money*$keke_wallet['sxf']/100);
	if($money>$mywallet['money']-$sxf){
		flock($fp,LOCK_UN);
		exit(json_encode(array('err' =>keke_walle_gbk2utf(lang('plugin/keke_wallet', '002')))));
	}
	if($money<$keke_wallet['minmun'] && $keke_wallet['minmun']){
		flock($fp,LOCK_UN);
		exit(json_encode(array('err' =>keke_walle_gbk2utf(lang('plugin/keke_wallet', '003').floatval($keke_wallet['minmun']).lang('plugin/keke_wallet', '004')))));
	}
	$mycard=C::t('#keke_wallet#keke_wallet_card')->fetchfirst_by_uid($_G['uid']);
	switch ($cardtype) {
		case 1:
			$card_number=$mycard['wx'];
			break;
		case 2:
			$card_number=$mycard['alipay'];
			break;
		case 3:
			$card_number=$mycard['bank_types'].' '.$mycard['card_number'];
			break;
	}
	$arr=array(
		'uid'=>$_G['uid'],
		'money'=>$money,
		'type'=>$cardtype,
		'card_number'=>$card_number,
		'realname'=>$mycard['name'],
		'time'=>TIMESTAMP,
		'sxf'=>intval($keke_wallet['sxf']),
		'state'=>3
	);
	$id=C::t('#keke_wallet#keke_wallet_txlog')->insert($arr,true);
	updateuserwallet($_G['uid'],-$money,$id,lang('plugin/keke_wallet', '005').$id.' )',lang('plugin/keke_wallet', '006'));
	if($sxf>0)updateuserwallet($_G['uid'],-$sxf,$id,lang('plugin/keke_wallet', '005').$id.' ) '.lang('plugin/keke_wallet', '007'),lang('plugin/keke_wallet', '006'));
	flock($fp,LOCK_UN);
	fclose($fp);
	if(file_exists('source/plugin/keke_wallet/module/automate_class.php')){
		include_once DISCUZ_ROOT."source/plugin/keke_wallet/module/automate_class.php";
		include_once DISCUZ_ROOT."source/plugin/keke_wallet/module/automate_fun.php";
		$returnset=_getset();
		$todaytotal=C::t('#keke_wallet#keke_wallet_txlog')->count_by_today();
		if($returnset['total']<=0 || ($returnset['total']>0 && $todaytotal>=$returnset['total']) || ($returnset['money']>0 && $money>$returnset['money'])){
			exit(json_encode(array('err' =>'')));
		}
		if($cardtype==1){
			$obj = new WxComPay();
			$data = array(
			  'openid'  => $mycard['openid'],
			  'price'   => $money*100
			);
			$res = $obj->comPay($data);
			if($res['result_code']=='SUCCESS'){
				$arr=array('state'=>1,'isauto'=>1,'info'=>$res['payment_no'],'endtime'=>$_G['timestamp']);
			}else{
				$arr=array('info'=>keke_wallet_utf2gbk($res['err_code_des']));
			}
		}elseif($cardtype==2){
			$obj = new Alipay();
			$data = array(
				 'payee_account'  => $mycard['alipay'],
				 'amount'  => $money,
				 'payer_show_name'=> keke_walle_gbk2utf($returnset['zfbshowname']),
				 'payee_real_name'=> ($returnset['zfbcheckname']?keke_walle_gbk2utf($mycard['name']):''),
			);
			$res = iconv('gbk','utf-8',$obj->transfer($data));
			$res = json_decode($res,true);
			$res['err_code_des']=keke_wallet_utf2gbk($res['err_code_des']);
			if($res['alipay_fund_trans_toaccount_transfer_response']['msg']=='Success' && $res['alipay_fund_trans_toaccount_transfer_response']['code']=='10000'){
				$arr=array('state'=>1,'endtime'=>$_G['timestamp'],'info'=>$res['alipay_fund_trans_toaccount_transfer_response']['order_id']);
			}else{
				$res['alipay_fund_trans_toaccount_transfer_response']['sub_msg']=keke_wallet_utf2gbk($res['alipay_fund_trans_toaccount_transfer_response']['sub_msg']);
				$arr=array('info'=>$res['alipay_fund_trans_toaccount_transfer_response']['sub_msg']);
			}
		}
		$arr['isauto']=1;
		C::t('#keke_wallet#keke_wallet_txlog')->update($id,$arr);
	}
	exit(json_encode(array('err' =>'')));
    
}elseif($_GET['ac']=='getmtx'){
	$ppp=!checkmobile()?6:20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$type=intval($_GET['type']);
	$query = C::t('#keke_wallet#keke_wallet_txlog')->fetch_all_by_page($startlimit,$ppp," AND uid=".$_G['uid'].($type?" AND state=".$type:''));
	foreach($query as $key=>$val){
		$query[$key]['time']=dgmdate($val['time'], 'Y-m-d H:i:s');
		$query[$key]['realname']=keke_walle_gbk2utf($val['realname']);
		$query[$key]['info']=keke_walle_gbk2utf($val['info']);
		$query[$key]['card_number']=keke_walle_gbk2utf($val['card_number']);
		if($val['endtime'])$query[$key]['endtime']=dgmdate($val['endtime'], 'Y-m-d H:i:s');
	}
	if(!checkmobile()){
		$all_log_count = C::t('#keke_wallet#keke_wallet_txlog')->count_by_all(" AND uid=".$_G['uid'].($type?" AND state=".$type:''));
		$multipage = multi($all_log_count, $ppp, $page, $_G['siteurl'].'plugin.php?id=keke_wallet:ajax&ac=getmtx','',3);
		if($multipage){
			$multipage=_replacemultippages($multipage,$type,2);
		}
		exit(json_encode(array(keke_walle_gbk2utf($multipage),$query)));
	}
	exit(json_encode($query));
}elseif($_GET['ac']=='getm'){
	$ppp=!checkmobile()?6:20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$type=intval($_GET['type']);
	$query = C::t('#keke_wallet#keke_wallet_log')->fetch_all_by_page(" AND uid=".$_G['uid'].($type?" AND ".($type==1?"money>0":"money<0"):''),$startlimit,$ppp); 
	foreach($query as $key=>$val){
		$query[$key]['time']=dgmdate($val['time'], 'Y-m-d H:i:s');
		$query[$key]['order']=keke_walle_gbk2utf($val['order']);
		$query[$key]['title']=keke_walle_gbk2utf($val['title']);
		if($val['endtime'])$query[$key]['endtime']=dgmdate($val['endtime'], 'Y-m-d H:i:s');
	}
	if(!checkmobile()){
		$all_log_count = C::t('#keke_wallet#keke_wallet_log')->count_by_all(' AND uid='.$_G['uid'].($type?" AND ".($type==1?"money>0":"money<0"):''));
		$multipage = multi($all_log_count, $ppp, $page, $_G['siteurl'].'plugin.php?id=keke_wallet:ajax&ac=getm&type='.$type.'','',3);
		if($multipage){
			$multipage=_replacemultippages($multipage,$type,1);
		}
		exit(json_encode(array(keke_walle_gbk2utf($multipage),$query)));
	}
	exit(json_encode($query));
}elseif($_GET['ac']=='showwin'){
	$mywallet=C::t('#keke_wallet#keke_wallet')->fetchfirst_by_uid($_G['uid']);
	$mycard=C::t('#keke_wallet#keke_wallet_card')->fetchfirst_by_uid($_G['uid']);
	$bank=_getbanktype();
	$balance=explode('.',$mywallet['money']?$mywallet['money']:'0.00');
	if(file_exists('source/plugin/keke_wallet/module/automate_fun.php')){
		include_once DISCUZ_ROOT."source/plugin/keke_wallet/module/automate_fun.php";
		$returnset=_getset();
		if($_GET['op']=='bindwechatwin'){
			$qr_arr=_Getbindqrcode();
			$qrurl=$qr_arr[0];
		}
	}
	include template('keke_wallet:qb_win');
}elseif($_GET['ac']=='getbindqrcode'){
	if(file_exists('source/plugin/keke_wallet/module/automate_fun.php')){
		include_once DISCUZ_ROOT."source/plugin/keke_wallet/module/automate_fun.php";
		$qrurl=_Getbindqrcode();
		exit(json_encode(array('qrcodeurl' =>$qrurl[0],'token'=>$qrurl[1])));
	}else{
		exit(json_encode(array('msg' =>'Please install the components')));
	}
}elseif($_GET['ac']=='bindwechat'){
	
	if(file_exists('source/plugin/keke_wallet/module/automate_fun.php')){
		include_once DISCUZ_ROOT."source/plugin/keke_wallet/module/automate_fun.php";
		$returnset=_getset();
		$redirect_uri = _GetwxreUri();
		$access_tokenarr=_Getaccesstoken($redirect_uri);
		if($access_tokenarr['openid'] && $access_tokenarr['access_token']){
			$user_data = _GetUserdataApi($access_tokenarr['access_token'],$access_tokenarr['openid']);
			$carddata=C::t('#keke_wallet#keke_wallet_card')->fetchfirst_by_token($_GET['token']);
			$arr=array(
				'wx'=>FilterEmoji($user_data['nickname']),
				'wxqr'=>$user_data['headimgurl'],
				'openid'=>$access_tokenarr['openid'],
				'token'=>''
			);
			C::t('#keke_wallet#keke_wallet_card')->update($carddata['uid'],$arr);
		}
		include template('keke_wallet:qb_win');
	}else{
		exit('Please install the components');
	}
	
}elseif($_GET['ac']=='checkbindwechat'){	
	$carddata=C::t('#keke_wallet#keke_wallet_card')->fetchfirst_by_token($_GET['token']);
	if(!$carddata){
		exit(json_encode(array('state' =>1)));
	}
	exit(json_encode(array('state' =>0)));
	
}elseif($_GET['ac']=='showqrcode'){		
	error_reporting(E_ERROR);
	require_once DISCUZ_ROOT."source/plugin/keke_wallet/phpqrcode/phpqrcode.php";
	$url = urldecode($_GET["data"]);
	QRcode::png($url);
}

function _replacemultippages($multipage,$type,$trpes){
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' name=",$multipage);
	$multipage=preg_replace("/<label>(.*)<\/label>/isU",'',$multipage);
	$multipage=preg_replace('(<a(.+?)page=(.+?)"([^>]*)>(.+?)<\/a>)','<a href="javascript:" data-page="$2" data-type="'.$type.'" onclick="_getlog('.$type.',$2,'.$trpes.')" $3>$4</a>',$multipage);
	$multipage=str_replace("ajaxtarget","alt",$multipage);
	return $multipage;
}


function keke_wallet_utf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return $data;
	}
}
function keke_walle_gbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}

function _getbanktype(){
	global $_G;
	$keke_wallet = $_G['cache']['plugin']['keke_wallet'];
	$bankarr=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_wallet['banktype']));
	foreach($bankarr as $key=>$val){
		$return[$key]=dhtmlspecialchars($val);
	}
	return $return;
}

function _upload_img($file,$width, $height=10000,$max=5024,$thumb='1'){
	global $_G;
	$file['size'] > ($max * 1024) && showmessage('file_size_overflow', '', array('size' => $max * 1024));
	$upload = new discuz_upload();
	$uploadtype = 'keke_wallet';
	if(!is_array($file) || empty($file) || !$upload->is_upload_file($file['tmp_name']) || trim($file['name']) == '' || $file['size'] == 0) {
		$upload->attach = array();
		$upload->errorcode = -1;
		return false;
	} else {
    	$upload->type = discuz_upload::check_dir_type($uploadtype);
		$upload->extid = intval($data['extid']);
		$upload->forcename = '';

		$file['size'] = intval($file['size']);
		$file['name'] =  trim($file['name']);
		$file['thumb'] = '';
		$file['ext'] = $upload->fileext($file['name']);
		$file['name'] =  dhtmlspecialchars($file['name'], ENT_QUOTES);
		if(strlen($file['name']) > 90) {
			$file['name'] = cutstr($file['name'], 80, '').'.'.$file['ext'];
		}
		$file['isimage'] = $upload->is_image_ext($file['ext']);
		if(!$file['isimage']){
			exit(lang('error', 'file_upload_error_-102'));
		}
		$file['extension'] = $upload->get_target_extension($file['ext']);
		$file['attachdir'] = _get_target_dir($upload->type);
		$file['attachment'] = $file['attachdir'].$upload->get_target_filename($upload->type, $upload->extid, $upload->forcename).'.'.$file['extension'];
		$file['target'] = getglobal('setting/attachdir').'./'.$upload->type.'/'.$file['attachment'];
		$upload->attach = & $file;
		$upload->errorcode = 0;
	}
	if(!$upload->save()) {
		exit($upload->errormessage());
	}
	if($thumb && ($upload->attach['imageinfo'][0]>$width || $upload->attach['imageinfo'][1]>$height)){
		if($file['isimage']){
			require_once libfile('class/image');
			$img = new image;
			$thumbpic=$img->Thumb($upload->attach['target'], './'.$uploadtype.'/'.$upload->attach['attachment'].'_thumb.jpg', $width, $height, 'fixwr');
		}		
	}
	if($thumbpic){
		@unlink($img->source);
		return getglobal('setting/attachurl').$uploadtype.'/'.$upload->attach['attachment'].'_thumb.jpg';
	}else{
		return getglobal('setting/attachurl').$upload->type.'/'.$upload->attach['attachment'];
	}
}

function _get_target_dir($type, $check_exists = true) {
	$subdir = $subdir1 = $subdir2 = '';
	$subdir1 = date('Ym');
	$subdir2 = date('d');
	$subdir = $subdir1.'/'.$subdir2.'/';
	$check_exists && discuz_upload::check_dir_exists($type, $subdir1, $subdir2);
	return $subdir;
}

function _wallet_getusname($uid){
	$userdata=getuserbyuid($uid);
	return $userdata['username'];
}

function _wallet_getuswalletcard($uid){
	return C::t('#keke_wallet#keke_wallet_card')->fetchfirst_by_uid($uid);
}

function _GetqrUrl($data){
	return 'plugin.php?id=keke_wallet:ajax&ac=showqrcode&data='.urlencode($data);
}