<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$keke_wallet = $_G['cache']['plugin']['keke_wallet'];
	include_once DISCUZ_ROOT."source/plugin/keke_wallet/ajax.inc.php";
	$orderid=intval($_GET['orderid']);
	if($_GET['ac']=='ok'){
		$arr=array('state'=>1,'isauto'=>0,'endtime'=>$_G['timestamp']);
		C::t('#keke_wallet#keke_wallet_txlog')->update($orderid,$arr);
		cpmsg(lang('plugin/keke_tixian', 'lang01'), 'action=plugins&operation=config&identifier=keke_wallet&pmod=admin_tx&page='.$_GET['page'], 'succeed');
	}elseif($_GET['ac']=='pays'){
		if(!file_exists('source/plugin/keke_wallet/module/automate_fun.php')){
			cpmsg('<b>'.lang('plugin/keke_wallet', '024').'</b>');
		}
		include_once DISCUZ_ROOT."source/plugin/keke_wallet/module/automate_fun.php";
		include_once DISCUZ_ROOT."source/plugin/keke_wallet/module/automate_class.php";
		$orderdata=C::t('#keke_wallet#keke_wallet_txlog')->fetchfirst_by_id($orderid);
		$mycard=C::t('#keke_wallet#keke_wallet_card')->fetchfirst_by_uid($_G['uid']);		
		$moneytotal=$orderdata['money'];
		if($orderdata['state']==3){
			$issuccess=0;
			if($orderdata['type']==1){
				$obj = new WxComPay();
				$data = array(
				  'openid'  => $mycard['openid'],
				  'price'   => $moneytotal*100
				);
				$res = $obj->comPay($data);
				if($res['result_code']=='SUCCESS'){
					$issuccess=1;
					$code_des=$res['payment_no'];
				}else{
					$code_des=$res['err_code_des'];
				}
			}elseif($orderdata['type']==2){
				$obj = new Alipay();
				$data = array(
					 'payee_account'  => $mycard['alipay'],
					 'amount'  => $moneytotal, 
				);
				$res = iconv('gbk','utf-8',$obj->transfer($data));
				$res = json_decode($res,true);
				if($res['alipay_fund_trans_toaccount_transfer_response']['msg']=='Success' && $res['alipay_fund_trans_toaccount_transfer_response']['code']=='10000'){
					$issuccess=1;
					$code_des=$res['alipay_fund_trans_toaccount_transfer_response']['order_id'];
				}else{
					$code_des=$res['alipay_fund_trans_toaccount_transfer_response']['sub_msg'];
				}
			}

			$code_des=keke_wallet_utf2gbk($code_des);
			if($issuccess){
				$arr=array('state'=>1,'endtime'=>$_G['timestamp']);
				$Sta='succeed';
				$tips=lang('plugin/keke_wallet', '025');
			}else{
				$Sta='error';
				$tips=lang('plugin/keke_wallet', '026');
			}
			$arr['isauto']=2;
			$arr['info']=$code_des;
			C::t('#keke_wallet#keke_wallet_txlog')->update($orderid,$arr);
			cpmsg($tips, 'action=plugins&operation=config&identifier=keke_wallet&pmod=admin_tx&page='.$_GET['page'], $Sta);
		}else{
			cpmsg(lang('plugin/keke_wallet', '027'), 'action=plugins&operation=config&identifier=keke_wallet&pmod=admin_tx&page='.$_GET['page'], 'error');
		}
		
	}elseif($_GET['ac']=='tui'){
		if (submitcheck("forumset")) {
			$orderdata=C::t('#keke_wallet#keke_wallet_txlog')->fetchfirst_by_id($orderid);
			$yuanyin=daddslashes($_GET['yuanyin']);
			$arr=array('state'=>2,'endtime'=>$_G['timestamp'],'info'=>$yuanyin);
			C::t('#keke_wallet#keke_wallet_txlog')->update($orderid,$arr);
			include_once DISCUZ_ROOT."source/plugin/keke_wallet/api.php";
			$sxf=sprintf("%.2f",$orderdata['money']*$orderdata['sxf']/100);
			updateuserwallet($orderdata['uid'],$orderdata['money'],$orderid,lang('plugin/keke_wallet', '028').$orderid,lang('plugin/keke_wallet', '006'));
			if($sxf>0)updateuserwallet($orderdata['uid'],$sxf,$orderid,lang('plugin/keke_wallet', '029').$orderid,lang('plugin/keke_wallet', '006'));
			cpmsg(lang('plugin/keke_tixian', 'lang14'), 'action=plugins&operation=config&identifier=keke_wallet&pmod=admin_tx&page='.intval($_GET['page']), 'succeed');
		}
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_tx&ac=tui");
		showtableheader('');
		showsubtitle(array(lang('plugin/keke_wallet', '030')));
		$table = array();
		$table[0] = '<input name="yuanyin" value="" style="width:200px"><input type="hidden" name="orderid" value="'.$orderid.'"><input type="hidden" name="page" value="'.intval($_GET['page']).'"> <font style="color:#666; margin-left:15px">'.lang('plugin/keke_wallet', '031').'</font>';
		showtablerow('',array('width="100"'), $table);
		showsubmit('forumset', 'submit', '', '');
    	showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
		exit();
	}
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_tx");
	showtableheader(lang('plugin/keke_wallet', '032'));
	showtablerow('', array('width="80"', 'width="180"', 'width="80"','width="300"'),
		array(
			'<b>'.lang('plugin/keke_wallet', '014').'</b>',
			'<input name="username" value="'.($_GET['uid']?_wallet_getusname(intval($_GET['uid'])):dhtmlspecialchars($_GET['username'])).'" type="text" />',
			'<b>'.lang('plugin/keke_wallet', '015').'</b>',
			'<input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'"/>',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_wallet', '016').'"><script src="static/js/calendar.js"></script>'
		)
	);
	$where=$param='';
	if($_GET['username']){
		$uid = C::t('common_member')->fetch_uid_by_username($_GET['username']);
		$where.=" AND uid=".$uid;
		$param.='&username='.dhtmlspecialchars($_GET['username']);
	}
	if($_GET['uid']){
		$where.=" AND uid=".intval($_GET['uid']);
		$param.='&username='.dhtmlspecialchars($_GET['username']);
	}
	if($_GET['time']){
		$where.=" AND time>".strtotime($_GET['time']);
		$param.='&time='.dhtmlspecialchars($_GET['time']);
	}
	if($_GET['endtime']){
		$where.=" AND time<".strtotime($_GET['endtime']);
		$param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
	}
    showtableheader(lang('plugin/keke_tixian', 'lang15'));
    showsubtitle(array('ID', lang('plugin/keke_wallet', '033'), lang('plugin/keke_wallet', '034'),lang('plugin/keke_wallet', '035'), lang('plugin/keke_wallet', '036'),lang('plugin/keke_wallet', '037'),lang('plugin/keke_wallet', '038'),lang('plugin/keke_wallet', '039')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_tx'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = C::t('#keke_wallet#keke_wallet_txlog')->count_by_all($where);
	if($allcount){
		$query = C::t('#keke_wallet#keke_wallet_txlog')->fetch_all_by_page($startlimit,$ppp,$where);
		foreach($query as $val){
			$opurl=$bang='';
			$sxf=sprintf("%.2f",$val['money']*$val['sxf']/100);
			$money=sprintf("%.2f",$val['money']);
			if($val['type']==1){
				$cardatas=_wallet_getuswalletcard($val['uid']);
				if($cardatas['openid']){
					$bang='<font color="#999">'. lang('plugin/keke_wallet', '040').'</font>';
				}
				$account='<img style="vertical-align:middle; margin:0 10px; border-radius: 3px;" src="source/plugin/keke_wallet/template/images/pay_05.png" width="16" height="16">'.lang('plugin/keke_wallet', '041').$bang.' ';
				
				if($cardatas['wxqr'] && !$cardatas['openid']){
					$account.= ' <div class="qrcodebox"><a href="'.$cardatas['wxqr'].'" target="_blank"><img style="vertical-align:middle; margin:0 5px; border-radius: 3px;" src="source/plugin/keke_wallet/template/images/ico03.png" width="15" height="15" class="zoom" onmouseover="$(\'icon'.$val['id'].'\').style.display=\'block\'" onmouseout="$(\'icon'.$val['id'].'\').style.display=\'none\'"></a> <div class="qrcodesubbox" id="icon'.$val['id'].'"><img src="'.$cardatas['wxqr'].'"></div></div>';
				}
			}elseif($val['type']==2){
				$account='<img style="vertical-align:middle; margin:0 10px; border-radius: 3px;" src="source/plugin/keke_wallet/template/images/pay_04.png" width="16" height="16">'.lang('plugin/keke_wallet', '042').' ';
			}elseif($val['type']==3){
				$account='<img style="vertical-align:middle; margin:0 10px; border-radius: 3px;" src="source/plugin/keke_wallet/template/images/pay_06.png" width="16" height="16">'.lang('plugin/keke_wallet', '043').' ';
			}
			$account='<font color="#999">'.$account.'</font><div class="card_number">'.$val['card_number'].' / '.$val['realname'].'</div>';
			if($val['state']==1){
				$stat='<font color="#33CC33">'.lang('plugin/keke_wallet', '044').'</font><font color="#999"> / '.dgmdate($val['endtime'], 'Y-m-d H:i:s').'</font>'.(($val['isauto'])?'<p class="psty">'.lang('plugin/keke_wallet', '045').$val['info'].'</p>':'');
				$opurl='<span style="color:#ccc;">'.lang('plugin/keke_wallet', '044').'</span>';
			}elseif($val['state']==2){
				$stat='<font color="#c30">'.lang('plugin/keke_wallet', '046').'</font> <font color="#999"> / '.dgmdate($val['endtime'], 'Y-m-d H:i:s').'</font><p class="psty">'.lang('plugin/keke_wallet', '047').$val['info'].'</p>';
				$opurl='<span style="color:#ccc;">'.lang('plugin/keke_wallet', '046').'</span>';
			}else{
				$stat='<font color="#f90">'.lang('plugin/keke_wallet', '048').'</font> '.($val['isauto']? '<p class="psty">'.($val['isauto']==1?lang('plugin/keke_wallet', '049'):lang('plugin/keke_wallet', '050')).': '.$val['info'].'</p>':'');
				$opurl=( (file_exists('source/plugin/keke_wallet/module/automate_fun.php') && $val['type']!=3)?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_tx&ac=pays&orderid='.$val['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'" onClick="return confirm(\''.lang('plugin/keke_wallet', '051').' \');">'.lang('plugin/keke_wallet', '052').'</a> / ':'').'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_tx&ac=ok&orderid='.$val['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'" onClick="return confirm(\''.lang('plugin/keke_wallet', '053').' \');">'.lang('plugin/keke_wallet', '054').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_tx&ac=tui&orderid='.$val['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_wallet', '056').'</a>';
			}
			$table = array();
			$table[0] = $val['id'];
			$table[1] = '<a href="'.ADMINSCRIPT.'?frames=yes&action=logs&operation=credit&srch_uid='.$val['uid'].'&frame=yes" target="_blank">'._wallet_getusname($val['uid']).'</a><p><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_account&uid='.$val['uid'].'&formhash='.FORMHASH.'" target="_blank" class="psty">'.lang('plugin/keke_wallet', '055').'</a></p>';
			$table[2] = '<b style="color:#c30;">&yen;'.$money.'</b>';
			$table[3] = '<span style="color:#999;">&yen;'.$sxf.'</span>';
			$table[4] = $account;
			$table[5] = dgmdate($val['time'], 'Y/m/d H:i:s');
			$table[6] = $stat;
			$table[7] = $opurl;
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="7">'.$multipage.'</td></tr>';
	echo '<style>.tb td{padding: 10px 5px !important;}.psty{color:#999;line-height:25px} .card_number{margin-left:10px; line-height:25px; color:#586c94}.qrcodebox{ display:inline-block; position:relative;}.qrcodesubbox{position:absolute;z-index:999;border:1px solid #eee;left:0; top:25px; display:none}</style>';
    showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
    showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/