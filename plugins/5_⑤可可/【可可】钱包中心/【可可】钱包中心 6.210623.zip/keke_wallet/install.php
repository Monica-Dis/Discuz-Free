<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_wallet= DB::table("keke_wallet");
$keke_wallet_card= DB::table("keke_wallet_card");
$keke_wallet_set= DB::table("keke_wallet_set");
$keke_wallet_txlog= DB::table("keke_wallet_txlog");
$keke_wallet_log= DB::table("keke_wallet_log");
$sql = <<<EOF
CREATE TABLE `$keke_wallet` (
  `uid` int(10) NOT NULL,
  `money` float(10,2) NOT NULL,
  `state` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_wallet_card` (
  `uid` int(10) NOT NULL,
  `name` varchar(255) NOT NULL,
  `wx` varchar(100) NOT NULL,
  `wxqr` varchar(255) NOT NULL,
  `alipay` varchar(100) NOT NULL,
  `bank_types` varchar(100) NOT NULL,
  `card_number` varchar(25) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `token` varchar(20) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_wallet_set` (
  `id` varchar(255) NOT NULL,
  `val` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_wallet_txlog` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `money` float(10,2) NOT NULL,
  `time` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `orderid` varchar(32) NOT NULL,
  `type` int(2) NOT NULL,
  `realname` varchar(100) NOT NULL,
  `card_number` varchar(100) NOT NULL,
  `state` int(2) NOT NULL,
  `sxf` int(3) NOT NULL,
  `info` varchar(255) NOT NULL,
  `isauto` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


CREATE TABLE `$keke_wallet_log` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `type` int(2) NOT NULL,
  `order` varchar(200) NOT NULL,
  `orderid` varchar(32) NOT NULL,
  `money` float(10,2) NOT NULL,
  `yu` float(10,2) NOT NULL,
  `title` varchar(50) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


EOF;
runquery($sql);
$finish = true;
?>