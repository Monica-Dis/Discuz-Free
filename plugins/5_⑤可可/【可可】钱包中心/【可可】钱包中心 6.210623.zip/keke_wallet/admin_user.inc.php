<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$keke_wallet = $_G['cache']['plugin']['keke_wallet'];
	include_once DISCUZ_ROOT."source/plugin/keke_wallet/ajax.inc.php";
	
	if($_GET['ac']=='edit'){
		$uid=intval($_GET['uid']);
		$userdata=C::t('#keke_wallet#keke_wallet')->fetchfirst_by_uid($uid);
		if (!submitcheck("editsubmit")) {
			showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_user&ac=edit", 'enctype');
			showtableheader(lang('plugin/keke_wallet', '057'));
			showsetting(lang('plugin/keke_wallet', '058'), '', 'state', '<b><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_account&uid='.$uid.'&formhash='.FORMHASH.'" target="_blank">'._wallet_getusname($userdata['uid']). '</a></b> <span style="color:#999;"> | uid:'.$userdata['uid'].'</span>');
			showsetting(lang('plugin/keke_wallet', '059'), '', 'state', '<b style="color:#c30;">&yen;'.$userdata['money'].'</b>');
			showtableheader(lang('plugin/keke_wallet', '060'));
			showsetting(lang('plugin/keke_wallet', '061'), '', 'state', "<select name='state'><option value='1' ".(1==$userdata['state']?'selected':'').">".lang('plugin/keke_wallet', '062')."</option><option value='4' ".(4==$userdata['state']?'selected':'').">".lang('plugin/keke_wallet', '063')."</option></select> ",'','',lang('plugin/keke_wallet', '064'));
			showsetting(lang('plugin/keke_wallet', '065'),'money',$coursedata['original_price'],'text','','',lang('plugin/keke_wallet', '066'));
			showsetting(lang('plugin/keke_wallet', '067'),'remarks','','textarea','','',lang('plugin/keke_wallet', '068'));
			echo '<input name="uid" type="hidden" value="'.$_GET['uid'].'" />';
			showsubmit('editsubmit', 'submit', '');
			showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
			showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/
			exit();
		}else{
			if($_GET['money']){
				if(!$_GET['remarks']){
					cpmsg(lang('plugin/keke_wallet', '068'), '', 'error');
				}
				include_once DISCUZ_ROOT."source/plugin/keke_wallet/api.php";
				updateuserwallet($uid,floatval($_GET['money']),$orderid,lang('plugin/keke_wallet', '069').($_G['username']).lang('plugin/keke_wallet', '070').$_GET['remarks'],lang('plugin/keke_wallet', '071'));
			}
			$arr=array(
				'state'=>intval($_GET['state']),
			);			
			C::t('#keke_wallet#keke_wallet')->update($uid,$arr);
			cpmsg(lang('plugin/keke_wallet', '072'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_wallet&pmod=admin_user&ac=edit&uid='.$uid.'&formhash='.FORMHASH, 'succeed');
		}
	}elseif($_GET['ac']=='editcard'){
		$uid=intval($_GET['uid']);
		$mycard=C::t('#keke_wallet#keke_wallet_card')->fetchfirst_by_uid($uid);
		if(file_exists('source/plugin/keke_wallet/module/automate_fun.php')){
			include_once DISCUZ_ROOT."source/plugin/keke_wallet/module/automate_fun.php";
			$returnset=_getset();
		}
		if (!submitcheck("editsubmit")) {
			$banktype=_getbanktype();
			foreach($banktype as $key=>$val){
				$cardnum.='<option value='.$val.' '.($val==$mycard['bank_types']?'selected':'').'>'.$val.'</option>';
			}
			showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_user&ac=editcard", 'enctype');
			showtableheader(lang('plugin/keke_wallet', '057'));
			showsetting(lang('plugin/keke_wallet', '058'), '', 'state', '<b><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_account&uid='.$uid.'&formhash='.FORMHASH.'" target="_blank">'._wallet_getusname($uid). '</a></b> <span style="color:#999;"> | uid:'.$uid.'</span>');
			showtableheader(lang('plugin/keke_wallet', '036'));
			showsetting(lang('plugin/keke_wallet', '073'),'name',$mycard['name'],'text','','','');
			showsetting(lang('plugin/keke_wallet', '041'),'wx',$mycard['wx'],'text','','','');
			if($returnset['wxauto']){
				showsetting('openid','openid',$mycard['openid'],'text','','',lang('plugin/keke_wallet', '074'));
			}else{
				showsetting(lang('plugin/keke_wallet', '075'),'wxqr',$mycard['wxqr'],'filetext');
			}
			showsetting(lang('plugin/keke_wallet', '042'),'alipay',$mycard['alipay'],'text','','','');
			showsetting(lang('plugin/keke_wallet', '076'), '', 'bank_types', "<select name='bank_types'>$cardnum</select> ",'','','');
			showsetting(lang('plugin/keke_wallet', '043'),'card_number',$mycard['card_number'],'text','','','');
			echo '<input name="uid" type="hidden" value="'.$_GET['uid'].'" />';
			showsubmit('editsubmit', 'submit', '');
			showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
			showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/
			exit();
		}else{
			$arr=array(
				'name'=>$_GET['name'],
				'wx'=>$_GET['wx'],
				'alipay'=>$_GET['alipay'],
				'bank_types'=>intval($_GET['bank_types']),
				'card_number'=>$_GET['card_number'],
				'openid'=>$_GET['openid']
			);
			if(!$returnset['wxauto']){
				$picurl=_upload_img($_FILES['wxqr'],400);
				$arr['wxqr']=$_GET['wxqr']?$_GET['wxqr']:$picurl;
			}
			C::t('#keke_wallet#keke_wallet_card')->update($uid,$arr);
			cpmsg(lang('plugin/keke_wallet', '072'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_wallet&pmod=admin_user&ac=editcard&uid='.$uid.'&formhash='.FORMHASH, 'succeed');
		}
	}
	showtableheader(lang('plugin/keke_wallet', '013'));
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_user");
	showtablerow('', array('width="80"', 'width="180"', 'width="80"','width="100"','width="40"','width="90"'),
		array(
			'<b>'.lang('plugin/keke_wallet', '014').'</b>',
			'<input name="username" value="'.dhtmlspecialchars($_GET['username']).'" type="text" />',
			'<b>'.lang('plugin/keke_wallet', '061').'</b>',
			'<select name="state"><option value="0">'.lang('plugin/keke_wallet', '077').'</option><option value="1" '.($_GET['state']==1?'selected="selected"':'').'>'.lang('plugin/keke_wallet', '062').'</option><option value="4" '.($_GET['state']==4?'selected="selected"':'').'>'.lang('plugin/keke_wallet', '063').'</option></select>',
			'<b>'.lang('plugin/keke_wallet', '078').'</b>',
			'<select name="orderby"><option value="0">'.lang('plugin/keke_wallet', '079').'</option><option value="1" '.($_GET['orderby']==1?'selected="selected"':'').'>'.lang('plugin/keke_wallet', '080').'</option><option value="2" '.($_GET['orderby']==2?'selected="selected"':'').'>'.lang('plugin/keke_wallet', '081').'</option></select>',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_wallet', '016').'">'
		)
	);
	
	$where=$param='';
	if($_GET['state']){
		$where.=" AND state=".intval($_GET['state']);
		$param.='&state='.intval($_GET['state']);
	}
	if($_GET['username']){
		$uid = C::t('common_member')->fetch_uid_by_username($_GET['username']);
		$where.=" AND uid=".$uid;
		$param.='&username='.dhtmlspecialchars($_GET['username']);
	}
	if($_GET['orderby']){
		$where.=" ORDER BY money ".($_GET['orderby']==1?'DESC':'ASC');
		$param.='&orderby='.intval($_GET['orderby']);
	}
	
    showtableheader(lang('plugin/keke_wallet', '082'));
    showsubtitle(array('UID', lang('plugin/keke_wallet', '083'), lang('plugin/keke_wallet', '059'),lang('plugin/keke_wallet', '084'), lang('plugin/keke_wallet', '061'), lang('plugin/keke_wallet', '017'),lang('plugin/keke_wallet', '085')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_user'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = C::t('#keke_wallet#keke_wallet')->count_all($where);
	if($allcount){
		$query = C::t('#keke_wallet#keke_wallet')->fetch_alls($startlimit,$ppp,$where);
		foreach($query as $val){
			$uids[$val['uid']]=$val['uid'];
		}
		$frozen = C::t('#keke_wallet#keke_wallet_txlog')->sum_by_uids($uids);
		foreach($query as $val){
			$table = array();
			$table[0] = $val['uid'];
			$table[1] = '<a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'._wallet_getusname($val['uid']).'</a>';
			$table[2] = '<b style="color:#c30;">&yen;'.$val['money'].'</b>';
			$table[3] = '<span style="color:#999;">&yen;'.$frozen[$val['uid']]['momey'].'</span>';
			$table[5] = $val['state']==1?lang('plugin/keke_wallet', '062'):lang('plugin/keke_wallet', '063');
			$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_account&uid='.$val['uid'].'&formhash='.FORMHASH.'" target="_blank">'.lang('plugin/keke_wallet', '086').'</a>';
			$table[6] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_user&ac=edit&uid='.$val['uid'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_wallet', '060').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_user&ac=editcard&uid='.$val['uid'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_wallet', '036').'</a>';
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="7">'.$multipage.'</td></tr>';
    showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
    showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/