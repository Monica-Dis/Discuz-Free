<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$keke_wallet = $_G['cache']['plugin']['keke_wallet'];
	include_once DISCUZ_ROOT."source/plugin/keke_wallet/ajax.inc.php";
	showtableheader(lang('plugin/keke_wallet', '013'));
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_account");
	showtablerow('', array('width="80"', 'width="180"', 'width="80"','width="300"'),
		array(
			'<b>'.lang('plugin/keke_wallet', '014').'</b>',
			'<input name="username" value="'.($_GET['uid']?_wallet_getusname(intval($_GET['uid'])):dhtmlspecialchars($_GET['username'])).'" type="text" />',
			'<b>'.lang('plugin/keke_wallet', '015').'</b>',
			'<input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'"/>',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_wallet', '016').'"><script src="static/js/calendar.js"></script>'
		)
	);
	$where=$param='';
	if($_GET['username']){
		$uid = C::t('common_member')->fetch_uid_by_username($_GET['username']);
		$where.=" AND uid=".$uid;
		$param.='&username='.dhtmlspecialchars($_GET['username']);
	}
	if($_GET['uid']){
		$where.=" AND uid=".intval($_GET['uid']);
		$param.='&username='.dhtmlspecialchars($_GET['username']);
	}
	if($_GET['time']){
		$where.=" AND time>".strtotime($_GET['time']);
		$param.='&time='.dhtmlspecialchars($_GET['time']);
	}
	if($_GET['endtime']){
		$where.=" AND time<".strtotime($_GET['endtime']);
		$param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
	}
    showtableheader(lang('plugin/keke_wallet', '017'));
    showsubtitle(array('ID', lang('plugin/keke_wallet', '018'), '<div class="moneybox">'.lang('plugin/keke_wallet', '019').'</div>',lang('plugin/keke_wallet', '020'),lang('plugin/keke_wallet', '021'), lang('plugin/keke_wallet', '022'),lang('plugin/keke_wallet', '023')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_account&uid='.intval($_GET['uid']);
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = C::t('#keke_wallet#keke_wallet_log')->count_by_all($where);
	if($allcount){
		$query = C::t('#keke_wallet#keke_wallet_log')->fetch_all_by_page($where,$startlimit,$ppp);
		foreach($query as $val){
			
			$table = array();
			$table[0] = $val['id'];
			$table[1] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_wallet&pmod=admin_account&uid='.$val['uid'].'&formhash='.FORMHASH.'" target="_blank">'._wallet_getusname($val['uid']).'</a>';
			$table[2] = '<div class="moneybox"><b style="color:'.($val['money']>0?'#c30;':'#666;').'">'.($val['money']>0?'+':'').$val['money'].' '.lang('plugin/keke_wallet', '004').'</b></div>';
			$table[3] = '&yen; '.$val['yu'];
			$table[4] = $val['title'];
			$table[5] = $val['order'];
			$table[6] = dgmdate($val['time'], 'Y/m/d H:i:s');
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="7">'.$multipage.'</td></tr>';
	echo '<style>.moneybox{width:110px; text-align:right; margin-right:20px}</style>';
    showtablefooter(); /*dism - taobao - com*/ /*dism��taobao��com*/
    showformfooter(); /*dism . taobao . com*/ /*dis'.'m.tao'.'bao.com*/