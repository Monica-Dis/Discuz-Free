<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$keke_wallet = $_G['cache']['plugin']['keke_wallet'];
if(!$_G['uid']){
    showmessage('not_loggedin', '', array(), array('login' => true));
}

include_once DISCUZ_ROOT . 'source/plugin/keke_wallet/ajax.inc.php';
$mycard=C::t('#keke_wallet#keke_wallet_card')->fetchfirst_by_uid($_G['uid']);
if($_GET['op']=='card'){
	$bank=_getbanktype();
	if(file_exists('source/plugin/keke_wallet/module/automate_fun.php')){
		include_once DISCUZ_ROOT."source/plugin/keke_wallet/module/automate_fun.php";
		$returnset=_getset();
	}
	$ibwechat=(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false)?1:0;
	
}elseif($_GET['op']=='tixian'){
	if(!$mycard['wx'] && !$mycard['alipay'] && !$mycard['card_number']){
		showmessage(lang('plugin/keke_wallet', '008'),'');
	}
	$keke_wallet['sxf']=dhtmlspecialchars($keke_wallet['sxf']);
	$mywallet=C::t('#keke_wallet#keke_wallet')->fetchfirst_by_uid($_G['uid']);
	$balance=explode('.',$mywallet['money']?$mywallet['money']:'0.00');
}elseif($_GET['op']=='m'){
	$ppp=20;
	$tmpurl='plugin.php?id=keke_wallet';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$all_log_count = C::t('#keke_wallet#keke_wallet_log')->count_by_all(' AND uid='.$_G['uid']);
	$query = C::t('#keke_wallet#keke_wallet_log')->fetch_all_by_page(' AND uid='.$_G['uid'],0,$startlimit,$ppp);
	foreach($query as $key=>$val){
		$query[$key]['time']=dgmdate($val['time'], 'Y-m-d H:i:s');
	}
	$multipage = multi($all_log_count, $ppp, $page, $_G['siteurl'].$tmpurl);
}else{
	$mywallet=C::t('#keke_wallet#keke_wallet')->fetchfirst_by_uid($_G['uid']);
	$balance=explode('.',$mywallet['money']?$mywallet['money']:'0.00');
	$cashout=C::t('#keke_wallet#keke_wallet_txlog')->count_by_sum($_G['uid'],3);
}
$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
$keke_group = $_G['cache']['plugin']['keke_group'];
$keke_tixian = $_G['cache']['plugin']['keke_tixian'];
if($keke_chongzhi['pcleft']){
    $chongzhipcleftbtntxt=explode('|',$keke_chongzhi['pcleft']);
}
if($keke_group['pcleft']){
    $groupPcLeftTxt=explode('|',$keke_group['pcleft']);
}
if($keke_chongzhi['pcleft']){
    $tixianPcLeftTxt=explode('|',$keke_tixian['pcleft']);
}
include template('keke_wallet:qb_index');