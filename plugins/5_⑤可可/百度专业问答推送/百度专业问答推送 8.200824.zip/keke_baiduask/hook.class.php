<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_keke_baiduask{
	public function __construct(){
		global $_G,$article;
		$this->keke_baiduask = $_G['cache']['plugin']['keke_baiduask'];
		$this->perform=1;
		$this->fid=$_G['fid'];
		$this->section = empty($this->keke_baiduask['bk']) ? array() : unserialize($this->keke_baiduask['bk']);
		if(!(empty($this->section[0]) || in_array($this->fid,$this->section))){
			$this->perform=0;
		}
		
		if(CURSCRIPT=='forum'){
			$this->moda=2;
			$this->atid=$_G['tid'];
			$this->urla=$this->_creurl(2,$this->atid);

		}elseif(CURSCRIPT=='portal'){
			$this->moda=1;
			$this->atid=intval($_GET['aid']);
			$this->urla=$this->_creurl(1,$this->atid);
		}
	}
	function _creurl($mods,$atid){
		global $_G;
		$_GET['page']=$_GET['page']?$_GET['page']:1;
		if($mods==2){
			$urla='forum.php?mod=viewthread&tid='.$atid;
			if($this->keke_baiduask['tformat']){
				$urla=dhtmlspecialchars(str_ireplace(array('{tid}','{page}'),array($atid,intval($_GET['page'])),$this->keke_baiduask['tformat']));
			}else{
				if(in_array('forum_viewthread', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus']==1){
					$urla=rewriteoutput('forum_viewthread', 1, '', $atid,$_GET['page']);
				}
			}
		}elseif($mods==1){
			$urla='portal.php?mod=view&aid='.$atid;
			if($this->keke_baiduask['pformat']){
				$urla=dhtmlspecialchars(str_ireplace(array('{id}','{page}'),array($atid,intval($_GET['page'])),$this->keke_baiduask['pformat']));
			}else{
				if(in_array('portal_article', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus']==1){
					$urla=rewriteoutput('portal_article', 1, '', $atid,$_GET['page']);
				}
			}
		}
		return $urla;
	}
		
	function _cutmsg($msgs){
		global $_G,$article;
		$smsg=preg_replace('/<script[\s\S]*?<\/script>/is', '', $msgs);
		$smsg=str_replace(array("\r\n", "\r", "\n"), '', cutstr(strip_tags(preg_replace('/(<i class=\"pstatus\">.*<\/i>)/is', '', preg_replace('/(<ignore_js_op>.*<\/ignore_js_op>)/is', '', $smsg)) ), 290,''));
		return $smsg;
	}
	
	function gbktoutf($data){
		return diconv($data, CHARSET, 'utf-8');
	}
	
	function utftogbk($data){
		return diconv($data, 'utf-8', CHARSET);
	}
	
	
	function _posttobaidu($atid,$mods,$json_datas=array(),$type=''){
		global $_G;
		$siteurls=$this->keke_baiduask['site']?dhtmlspecialchars($this->keke_baiduask['site']):$_G['siteurl'];
		$piclist=$ImageObject='';
		$isDeleted=($type==1)?1:0;
		if($mods==2){
			if(!$type)ob_end_clean();
			require_once libfile('function/post');
			$urla=$siteurls.$this->_creurl(2,$atid);
			$threadpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($atid);
			$attachmentarr=C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$atid, 'pid', $threadpost['pid']);
			$attach_count=count($attachmentarr);
			if($attach_count){
				$n=0;
				foreach($attachmentarr as $attach){
					$attachurl = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $siteurls.$_G['setting']['attachurl']).'forum/';
					if(($attach_count==2 && $n==1) || ($attach_count>3  && $n==3)){
						break;
					}
					$piclist.='"'.$attachurl.$attach['attachment'].'"'.',';
					$ImageObject.='{
						"contentUrl": "'.$attachurl.$attach['attachment'].'",
						"scale": "5:2"
					},';
					$n++;
				}
				$ImageObject=substr($ImageObject,0,strlen($ImageObject)-1);
			}else{
				$piclist.='"'.$siteurls.$this->keke_baiduask['contentUrl'].'"'.',';
				$ImageObject.='{
					"contentUrl": "'.$siteurls.$this->keke_baiduask['contentUrl'].'",
					"scale": "5:2"
				}';
			}
			$summary = str_replace(array("\r", "\n"), '', messagecutstr(strip_tags($threadpost['message']), 290,''));
			$data_arr=array(
				'subject'=>$threadpost['subject'],
				'author'=>$threadpost['author'],
				'authorid'=>$threadpost['authorid'],
				'answer'=>$summary,
				'piclist'=>substr($piclist,0,strlen($piclist)-1),
				'ImageObject'=>$ImageObject,
				'pubDate'=>date('Y-m-d\TH:i:s',$threadpost['dateline'])
			);
			
		}elseif($mods==1){
			$urla=$siteurls.$this->_creurl(1,$atid);
			$article = C::t('portal_article_title')->fetch($atid);
			$page = intval($_GET['page']);
			if($page<1) $page = 1;
			$content = C::t('portal_article_content')->fetch_by_aid_page($atid, $page);
			preg_match_all('/<img[^>]*src=[\'"]?([^>\'"\s]*)[\'"]?[^>]*>/i', $content['content'], $out); 
			$attach_count=count($out[1]);
			if($out[1]){
				$n=0;
				foreach($out[1] as $attach){
					if(($attach_count==2 && $n==1) || ($attach_count>3  && $n==3)){
						break;
					}
					$piclist.='"'.$siteurls.$attach.'"'.',';
					$ImageObject.='{
						"contentUrl": "'.$siteurls.$attach.'",
						"scale": "5:2"
					},';
					$n++;
				}
				$ImageObject=substr($ImageObject,0,strlen($ImageObject)-1);
			}else{
				$piclist.='"'.$siteurls.$this->keke_baiduask['contentUrl'].'"'.',';
				$ImageObject.='{
					"contentUrl": "'.$siteurls.$this->keke_baiduask['contentUrl'].'",
					"scale": "5:2"
				}';
			}
			$data_arr=array(
				'subject'=>$article['title'],
				'author'=>$article['username'],
				'authorid'=>$article['uid'],
				'answer'=>$article['summary'],
				'piclist'=>substr($piclist,0,strlen($piclist)-1),
				'ImageObject'=>$ImageObject,
				'pubDate'=>date('Y-m-d\TH:i:s',$article['dateline'])
			);
			$summary = $this->_cutmsg($article['summary']);
		}
		if($this->keke_baiduask['author']){
			$data_arr['author']=$this->keke_baiduask['author'];
		}
		$data_arr['headPortrait']=$this->keke_baiduask['headPortrait']?$this->keke_baiduask['headPortrait']:$_G['setting']['ucenterurl'].'/avatar.php?uid='.$data_arr['authorid'].'&size=big';
		$data_arr['customstatus']=$this->keke_baiduask['jobtitle']?$this->keke_baiduask['jobtitle']:$data_arr['author'];
		if($_GET['title']){
			$data_arr['subject']=dhtmlspecialchars($_GET['title']);
		}
		if($_GET['answer']){
			$summary=dhtmlspecialchars($_GET['answer']);
		}
		$json_data='{
			"@context": "https://ziyuan.baidu.com/contexts/cambrian.jsonld",
			"@id": "'.$urla.'",
			"appid": "'.$this->keke_baiduask['appid'].'",
			"title": "'.$data_arr['subject'].'",
			"images": ['.$data_arr['piclist'].'],
			"pubDate": "'.$data_arr['pubDate'].'",
			"upDate": "'.$data_arr['pubDate'].'",
			"data": {
				"WebPage": {
					"headline": "'.$data_arr['subject'].'",
					"fromSrc": "'.$_G['setting']['bbname'].'",
					"domain": "'.$this->keke_baiduask['domain'].'",
					"category": ["'.$this->keke_baiduask['category'].'"],
					"isDeleted": '.$isDeleted.'
				},
				"Question": [{
					"acceptedAnswer": "'.$summary.'"
				}],
				"ImageObject": ['.$data_arr['ImageObject'].'],
				"Author": [{
					"name": "'.$data_arr['author'].'",
					"jobTitle": ["'.$data_arr['customstatus'].'"],
					"headPortrait": "'.$data_arr['headPortrait'].'"
				}]
			}
		}';
	
		if(function_exists('curl_init') && function_exists('curl_exec')){
			$ch = curl_init();
			$options =  array(
				CURLOPT_URL => $this->gbktoutf($this->keke_baiduask['api']),
				CURLOPT_POST => true,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_POSTFIELDS => $this->gbktoutf($json_data),
				CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
			);
			curl_setopt_array($ch, $options);
			$result = curl_exec($ch);
			$ret=json_decode($result, true);
			
		}else{
			$ret['error']=9990;
			$ret['message']='curl error';
		}	
			
		if($ret['error']){
			$state=intval($ret['error']);
			$msg=daddslashes($ret['message']);
		}else{
			if($ret['success'] || $ret['success_batch'] || $ret['success_realtime']){
				$state=1;
			}else{
				if($ret['not_same_site']){
					$state=2;
					$msg='not_same_site';
				}
				if($ret['not_valid']){
					$state=3;
					$msg='not_valid';
				}
			}
		}
		
		if($atid){
			if($type==1){
				$baiduask=C::t('#keke_baiduask#keke_baiduask')->fetchfirst_byatid($atid,$mods);
				$updataarr=array(
					'state'=>$state==1?5:$state,
					'postdata'=>$json_data,
					'time'=>$_G['timestamp']
				);
				C::t('#keke_baiduask#keke_baiduask')->update($baiduask['id'],$updataarr);
				return;
			}
			$arr=array(
				'subject'=> $data_arr['subject'],
				'url'=>$urla,
				'state'=>$state,
				'msg'=>$this->utftogbk($msg),
				'time'=>$_G['timestamp'],
				'mods'=>$mods,
				'atid'=>$atid,
				'postdata'=>$json_data
			);
			C::t('#keke_baiduask#keke_baiduask')->insert($arr);
			if(!checkmobile()){
				showmessage(($msg?$arr['msg']:lang('plugin/keke_baiduask', '018')), $turl, '', array('showdialog' => true, 'closetime' => 3, 'extrajs' => '<script>'.($msg?'':'$(\'keke_baiduask\').innerHTML = \'<a href="javascript:;" class="updatabtn">'.lang('plugin/keke_baiduask', '019').'</a>\';').'setTimeout(function(){hideWindow(\'keke_baiduask\');}, 2000);</script>'));
			}else{
				return json_encode(array('state'=>$state,'msg'=>$msg));
			}
		}else{
			if($ret['error']){
				$r=$state.'/'.$msg;
			}else{
				$r=lang('plugin/keke_baiduask', '006');
			}
			return $r;
		}
	}
	
	function _portalviews(){
		global $_G,$article,$content;
		$sdarr=unserialize($this->keke_baiduask['sd']);
		if(in_array($_G['groupid'],$sdarr)){
			$sd=1;
		}
		if($this->moda==1 && $_GET['aid'] && $sd){
			if($this->keke_baiduask['wz']){
				include template('keke_baiduask:inc');
			}
		}
		return $tsbtn;
	}
	
	
	function _forumviews() {
		global $_G,$postlist;
		$tsbtn='';
		$sdarr=unserialize($this->keke_baiduask['sd']);
		$sd=(in_array($_G['groupid'],$sdarr))?true:false;
		if($this->moda==2 && $_G['tid'] && $sd){
			$isgroup=$_G['thread']['isgroup'];
			if(($isgroup && $this->keke_baiduask['qz']) || (!$isgroup && $this->perform)){
				include template('keke_baiduask:inc');
			}
		}
		return array($tsbtn);
	}
}

class plugin_keke_baiduask_forum extends plugin_keke_baiduask{
	function viewthread_posttop_output() {
		global $_G;
		if($_G['forum_firstpid']){
			return $this->_forumviews();
		}
		return array();
	}
}
class mobileplugin_keke_baiduask_forum extends plugin_keke_baiduask{
	function viewthread_posttop_mobile_output(){
		global $_G;
		if($_G['forum_firstpid']){
			return $this->_forumviews();
		}
		return array();
	}
}
class plugin_keke_baiduask_portal  extends plugin_keke_baiduask{
	function view_article_content_output(){
		return $this->_portalviews();
	}
}
class plugin_keke_baiduask_group  extends plugin_keke_baiduask_forum{	
}
class mobileplugin_keke_baiduask_group  extends mobileplugin_keke_baiduask_forum{	
}
class mobileplugin_keke_baiduask_portal  extends plugin_keke_baiduask_portal{	
}