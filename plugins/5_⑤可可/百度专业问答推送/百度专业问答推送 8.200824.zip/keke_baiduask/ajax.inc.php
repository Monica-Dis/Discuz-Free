<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

global $_G;

if($_GET['formhash'] != $_G['formhash']){
	exit(json_encode(array('state'=>10,'msg'=>'formhash error')));
}

if(!$_G['uid']){
	exit(json_encode(array('state'=>11,'msg'=>'Please log in')));
}

if(!function_exists('curl_init') || !function_exists('curl_exec')){
	exit(json_encode(array('state'=>12,'msg'=>'curl error')));
}

if(!$_GET['atid']){
	exit(json_encode(array('state'=>13,'msg'=>'atid error')));
}

if(!$_GET['mods'] || !(in_array($_GET['mods'],array('1','2')))){
	exit(json_encode(array('state'=>14,'msg'=>'mods error')));
}


include_once DISCUZ_ROOT."source/plugin/keke_baiduask/hook.class.php";
$postdatas=new plugin_keke_baiduask;
$sdarr=unserialize($postdatas->keke_baiduask['sd']);
if($_GET['ac']=='showpostbtn'){
	if(in_array($_G['groupid'],$sdarr)){
		$postdata=C::t('#keke_baiduask#keke_baiduask')->fetchfirst_byatid(intval($_GET['atid']),intval($_GET['mods']));
		
		
		if($postdata){
			exit(json_encode(array('state'=>2)));
		}
		exit(json_encode(array('state'=>1)));
	}
	exit(json_encode(array('state'=>3)));
}elseif($_GET['ac']=='postdata'){
	if(in_array($_G['groupid'],$sdarr)){
		$postdata=C::t('#keke_baiduask#keke_baiduask')->fetchfirst_byatid(intval($_GET['atid']),intval($_GET['mods']));
		if($postdata['state']==1){
			$tips=diconv(lang('plugin/keke_baiduask', '013'), CHARSET, 'utf-8');
			exit(json_encode(array('state'=>9,'msg'=>$tips)));
		}
		exit($postdatas->_posttobaidu(intval($_GET['atid']),intval($_GET['mods'])));
	}
	$tips=diconv(lang('plugin/keke_baiduask', '014'), CHARSET, 'utf-8');
	exit(json_encode(array('state'=>10,'msg'=>$tips)));
}elseif($_GET['ac']=='postwin'){
	$_GET['atid']=intval($_GET['atid']);
	$_GET['mods']=intval($_GET['mods']);
	if($_GET['mods']==2){
		require_once libfile('function/post');
		$threadpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($_GET['atid']);
		$title=$threadpost['subject'];
		$summary = str_replace(array("\r", "\n"), '', messagecutstr(strip_tags($threadpost['message']), 290,''));
	}elseif($_GET['mods']==1){
		$article = C::t('portal_article_title')->fetch($_GET['atid']);
		$title=$article['title'];
		$summary = $postdatas->_cutmsg($article['summary']);
	}
	include template('keke_baiduask:win');
}




