<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
			C::t('#keke_baiduask#keke_baiduask')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/keke_baiduask', '006'), 'action=plugins&operation=config&identifier=keke_baiduask&pmod=admin', 'succeed');
	}
	if($_GET['ac']=='view'){
		if($_GET['formhash']!=FORMHASH){
			exit('formhash err');
		}
		$baiduask=C::t('#keke_baiduask#keke_baiduask')->fetchfirst_byid(intval($_GET['aid']));
		echo "<pre>".$baiduask['postdata']."<pre>";
		echo '<br><br><a href="javascript:;" onClick="javascript:history.back(-1);">'.lang('plugin/keke_baiduask', '017').'</a>';
		exit();
	}elseif($_GET['ac']=='offline'){
		if($_GET['formhash']!=FORMHASH){
			exit('formhash err');
		}
		$baiduask=C::t('#keke_baiduask#keke_baiduask')->fetchfirst_byid(intval($_GET['aid']));
		include_once DISCUZ_ROOT."source/plugin/keke_baiduask/hook.class.php";
		$postdatas=new plugin_keke_baiduask;
		$postdatas->_posttobaidu(intval($baiduask['atid']),intval($baiduask['mods']),array(),1);
		cpmsg(lang('plugin/keke_baiduask', '026'), 'action=plugins&operation=config&identifier=keke_baiduask&pmod=admin', 'succeed');
		exit();
	}
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");
	showtableheader(lang('plugin/keke_baiduask', '020'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_baiduask&pmod=admin', 'testhd');
	showtablerow('', array(),
		array(
			'<input name="subject" value="'.dhtmlspecialchars($_GET['subject']).'" type="text" placeholder="'.lang('plugin/keke_baiduask', '009').'" />
			<input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15" placeholder="'.lang('plugin/keke_baiduask', '021').'"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'" placeholder="'.lang('plugin/keke_baiduask', '022').'"/>
			<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '065').'"><input name="inajax" type="hidden" value="1" /><script src="static/js/calendar.js"></script>'
		)
    );
	showformfooter();/*DISM-TAOBAO-COM*//*Dism��taobao��com*/
	/*Dism_taobao_com*/showtablefooter();
	$where=1;$param='';
	if($_GET['time']){
		$where.=" AND time>".strtotime($_GET['time']);
		$param.='&time='.dhtmlspecialchars($_GET['time']);
	}
	if($_GET['endtime']){
		$where.=" AND time<".strtotime($_GET['endtime']);
		$param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
	}
	if($_GET['subject']){
		$where.=" AND subject LIKE '%".addcslashes($_GET['subject'],'%_')."%'";
		$param.='&subject='.addcslashes($_GET['subject']);
	}
	showtableheader(lang('plugin/keke_baiduask', '007'));
    showsubtitle(array(lang('plugin/keke_baiduask', '008'),lang('plugin/keke_baiduask', '009'),lang('plugin/keke_baiduask', '010'),lang('plugin/keke_baiduask', '011'),lang('plugin/keke_baiduask', '012'),lang('plugin/keke_baiduask', '015')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_baiduask&pmod=admin'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$count = C::t('#keke_baiduask#keke_baiduask')->count_all($where);
	if($count){
		$liatdata = C::t('#keke_baiduask#keke_baiduask')->fetch_all_by_limit($startlimit,$ppp,$where);
		foreach($liatdata as $key=>$val){
			$state='';
			switch ($val['state']) {
				case 1:$state=lang('plugin/keke_baiduask', '002');break;
				case 2:$state=lang('plugin/keke_baiduask', '003').lang('plugin/keke_baiduask', '004');break;
				case 3:$state=lang('plugin/keke_baiduask', '003').lang('plugin/keke_baiduask', '005');break;
				case 5:$state=lang('plugin/keke_baiduask', '024');break;
				default:$state=lang('plugin/keke_baiduask', '003').$val['msg'];
			}
			$offline=($val['state']==1)?'<span class="sline">|</span><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_baiduask&pmod=admin&ac=offline&aid='.$val['id'].'&formhash='.FORMHASH.'" onClick="return confirm(\''.lang('plugin/keke_baiduask', '025').' \');">'.lang('plugin/keke_baiduask', '023').'</a>':'';
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = '<a href="'.$val['url'].'" target="_blank">'.$val['subject'].'</a>';
			$table[2] = '<a href="'.$val['url'].'" target="_blank">'.$val['url'].'</a>';
			$table[3] = '<div class="msgs" style="max-width:280px;">'.$state.'</div>';
			$table[4] = dgmdate($val['time'], 'Y/m/d H:i');
			$table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_baiduask&pmod=admin&ac=view&aid='.$val['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_baiduask', '016').'</a>'.$offline;
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$tmpurl);
	echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del','<style>.sline{ color:#CCC; margin:0 10px}</style>');
    /*Dism_taobao_com*/showtablefooter();
	showformfooter();/*DISM-TAOBAO-COM*//*Dism��taobao��com*/