<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	global $_G;
	$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
	$yxq=$keke_buyinvitecode['yxq'] ? intval($keke_buyinvitecode['yxq']) : 10;
	$title=$navtitle=dhtmlspecialchars($keke_buyinvitecode['title']);
	include_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/fun.php";
	if($_GET['p']=='ok'){
		$codes = array();
		$orderid = daddslashes(dhtmlspecialchars($_GET['orderid']));
		$order = C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->fetch($orderid);
		if(!$order) {
			showmessage('parameters_error');
		}
		$codes = _getcodes($orderid);
		if(empty($codes)) {
			showmessage('buyinvitecode_no_id');
		}
		$codetext = implode("\r\n", $codes);
		if(count($codes)==1){
			if($keke_buyinvitecode['jump']){
				$keke_buyinvitecode['jump']=str_ireplace("[invitecode]",$codes[0],$keke_buyinvitecode['jump']);
				$url=editor_safe_replace($keke_buyinvitecode['jump']);
			}else{
				if($keke_buyinvitecode['at']){
					$regname=$_G['setting']['regname']?$_G['setting']['regname']:'register';
                    $url=$_G['siteurl'].'member.php?mod='.$regname.'&invitecodes='.$codes[0];
				}
			}
			if($url){
				Header("HTTP/1.1 303 See Other"); 
				Header("Location: $url");
				exit;
			}
		}
	}elseif($_GET['p']=='loading'){
		$orderid = daddslashes(dhtmlspecialchars($_GET['orderid']));
	}elseif($_GET['p']=='query'){
		@include_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/model/query.php";
	}else{
		$yxq=$keke_buyinvitecode['yxq'] ? intval($keke_buyinvitecode['yxq']) : 10;
		$allmoney=$allmoneys/100;
		$allmoney =number_format($allmoney, 2);
		$alipayoff=empty($keke_buyinvitecode['alipaypid']) || empty($keke_buyinvitecode['alipaykey']) ? 0 : 1;
		$wxpayoff=empty($keke_buyinvitecode['wxappid']) || empty($keke_buyinvitecode['wxsecert']) || empty($keke_buyinvitecode['wxmchid']) || empty($keke_buyinvitecode['wxshkey']) ? 0 : 1;
		
		$yxq=dgmdate($_G['timestamp']+86400*$yxq, 'Y-m-d H:i:s');
		$keke_buyinvitecode['sm']=editor_safe_replace($keke_buyinvitecode['sm']);
	}
	include template('keke_buyinvitecode:index'); 