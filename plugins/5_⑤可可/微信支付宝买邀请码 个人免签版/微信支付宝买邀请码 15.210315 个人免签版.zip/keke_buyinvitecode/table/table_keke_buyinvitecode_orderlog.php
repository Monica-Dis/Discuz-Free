<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_buyinvitecode_orderlog extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_buyinvitecode_orderlog';
		$this->_pk    = 'orderid';

		parent::__construct(); /*Dism_taobao_com*/
	}
	
	public function count_by_all($uid=0,$state=0) {
		$where=$uid ? ' AND uid=%d' : '';
		$where.=$state ? ' AND state=1' : '';
		return DB::result_first("SELECT count(1) FROM %t WHERE orderid>0 ".$where, array($this->_table,$uid));
	}
	
	public function fetch_all_by_all($uid=0,$state=0,$startlimit,$ppp) {
		$where=$uid ? ' AND uid='.intval($uid) : '';
		$where.=$state ? ' AND state=1' : '';
		return DB::fetch_all("SELECT * FROM %t WHERE orderid>0 ".$where." order by time desc LIMIT %d,%d", array($this->_table,$startlimit,$ppp));
	}
	
	public function sum_by_uid($uid) {
		return DB::result_first("SELECT sum(money) FROM %t WHERE uid=%d AND state=1", array($this->_table,$uid));
	}
	
	public function del_oder() {
		return DB::delete($this->_table, array('state' => 0));
	}
	
	public function count_by_mobile($mobile) {
		return DB::result_first("SELECT count(1) FROM %t WHERE email=%s ", array($this->_table,$mobile));
	}
	
	public function fetchfirst_byid($oid) {
		return DB::fetch_first("SELECT * FROM %t WHERE sn=%s", array($this->_table,$oid));
	}

    public function fetchalluid_bycodes($codes) {
        return DB::fetch_all("SELECT * FROM %t WHERE code in (%n)", array('common_invite',$codes),'code');
    }
}
//From: Dism��taobao��com
?>