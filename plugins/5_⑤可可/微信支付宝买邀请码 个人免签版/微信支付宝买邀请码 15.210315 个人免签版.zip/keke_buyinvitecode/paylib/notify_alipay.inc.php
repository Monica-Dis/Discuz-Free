<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);
require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
global $_G;
loadcache('plugin');
header('Content-type:text/html; Charset=utf-8');
require_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/paylib/alipay_notify.class.php";
require_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/fun.php";
$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];	
$alipayPublicKey=trim($keke_buyinvitecode['publickey']);
$aliPay = new AlipayService($alipayPublicKey);
$result = $aliPay->rsaCheck($_POST,$_POST['sign_type']);
if($result===true){
	$yxq=$keke_buyinvitecode['yxq'] ? intval($keke_buyinvitecode['yxq']) : 10;
	$orderdata= C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->fetch($_GET['out_trade_no']);
	if($orderdata['state']==1){
		$codetext = array();
		$codetext=_createcode($orderdata,$_GET['out_trade_no'],$yxq);
		_uporderdata($orderdata['zftype'],$_GET['trade_no'],$codetext,$orderdata);
		if($keke_buyinvitecode['smsoff']){
			_sensms($codetext,$orderdata['email'],$yxq);
		}
		echo 'success';exit();
	}
	echo 'error';exit();
}
echo 'error';exit();