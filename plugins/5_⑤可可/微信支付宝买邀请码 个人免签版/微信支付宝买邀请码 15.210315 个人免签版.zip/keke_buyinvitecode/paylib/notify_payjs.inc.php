<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');
require_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/payjs.php";
require_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/fun.php";	


global $_G;
$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
$yxq=$keke_buyinvitecode['yxq'] ? intval($keke_buyinvitecode['yxq']) : 10;


payjscheckSign($_POST);
$orderdata= C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->fetch($_GET['out_trade_no']);
if($orderdata['state']==1){
	$codetext = array();
	
	$codetext=_createcode($orderdata,$_GET['out_trade_no'],$yxq);
	_uporderdata($orderdata['zftype'],$_GET['payjs_order_id'],$codetext,$orderdata);
	if($keke_buyinvitecode['smsoff']){
		_sensms($codetext,$orderdata['email'],$yxq);
	}
}
echo 'success';