<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/identity.inc.php";

require_once libfile('function/cache');

$addonid = 'keke_buyinvitecode.plugin';

function arrtoxml($data){
    $xml = "<xml>";
    foreach ($data as $key=>$val){
        if (is_numeric($val)){
            $xml.="<".$key.">".$val."</".$key.">";
        }else{
            $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
        }
    }
    $xml.="</xml>";
    return $xml;
}


function _getcodes($orderid){
	foreach(C::t('common_invite')->fetch_all_orderid($orderid) as $code) {
		$codes[] = $code['code'];
	}
	return $codes;
}

function _getcounts(){
	return C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->count_by_all();
}

function _getorderbypage($startlimit,$ppp){
	return C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->fetch_all_by_all(0,0,$startlimit,$ppp);
}

function _orderid(){
	global $_G;
	$nowdate=dgmdate($_G['timestamp'], 'YmdHis');
	$random=random(10);
	$orderid=$nowdate.$random;
	return $orderid;
}

function _createjson($jsApiParameters,$orderid){
	$arrs=json_decode($jsApiParameters);
	$ret=array('jsapi'=>$arrs,'orderids'=>$orderid);
	return json_encode($ret);
}

function _createcode($orderdata,$orderids,$yxq){
	global $_G;
	$dateline = TIMESTAMP;
	for($i=0; $i<$orderdata['amount']; $i++) {
		$code = strtolower(random(6));
		$codetext[] = $code;
		$invitedata = array(
					'uid' => 1,
					'code' => $code,
					'dateline' => $dateline,
					'endtime' => $_G['timestamp']+86400*$yxq,
					'email' => $orderdata['email'],
					'inviteip' => $_G['clientip'],
					'orderid' => $orderids
				);
		C::t('common_invite')->insert($invitedata);
	}
	return $codetext;
}

function _sensms($codetext,$phone,$yxq){
	global $_G;
	$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
	$times=dgmdate($_G['timestamp']+86400*$yxq, 'm-d H:i');
	if($keke_buyinvitecode['smschannel']==3){
		$smsapi = "http://api.smsbao.com/";
		$user = trim($keke_buyinvitecode['smsu']);
		$pass = md5(trim($keke_buyinvitecode['smsp']));
		$content=str_ireplace("{code}",implode(',', $codetext),$keke_buyinvitecode['smstmp']);
		$content=str_ireplace("{time}",$times,$content);
		$content=diconv($content, CHARSET, 'UTF-8');
		$sendurl = $smsapi."sms?u=".$user."&p=".$pass."&m=".$phone."&c=".urlencode($content);
		$result =file_get_contents($sendurl) ;
	}else{
		if(file_exists(DISCUZ_ROOT.'./source/plugin/keke_sms/sendsms.php')){
			$alisign=dhtmlspecialchars(trim($keke_buyinvitecode['sign']));
			$alitmpid=dhtmlspecialchars(trim($keke_buyinvitecode['tmpid']));
			@include_once DISCUZ_ROOT.'./source/plugin/keke_sms/sendsms.php';
			$kekesmsapi = new kekesmsapi();
			$return= $kekesmsapi->kekesendsms($phone,$alisign,array('code'=>implode(',', $codetext),'time'=>$times),$alitmpid,$keke_buyinvitecode['smschannel']);
		}
	}
}

function _uporderdata($zftype,$trade_no,$codetext,$orderdata){
	global $_G;
	$orderarr=array(
		'state'=>'2',
		'zftime'=>$_G['timestamp'],
		'zftype'=>$zftype,
		'sn'=>$trade_no,
		'code'=>implode(',', $codetext),
	);
	C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->update($orderdata['orderid'], $orderarr);
}

function _h5pay($money,$out_trade_no,$title){
	global $_G;
	$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
	$userip = get_client_ip();
	$appid  = trim($keke_buyinvitecode['wxappid']); 
	$mch_id = trim($keke_buyinvitecode['wxmchid']); 
	$key    = trim($keke_buyinvitecode['wxshkey']);
	$nonce_str = createNoncestr();
	$body = $title;
	$total_fee = $money; 
	$spbill_create_ip = $userip;
	$notify_url = $_G['siteurl']."source/plugin/keke_buyinvitecode/paylib/notify_wx.inc.php"; 
	$trade_type = 'MWEB';
	$scene_info ='{"h5_info":{"type":"Wap","wap_url":"'.$_G['siteurl'].'plugin.php?id=keke_buyinvitecode","wap_name":"$title"}}';
	$signA ="appid=$appid&attach=$out_trade_no&body=$body&mch_id=$mch_id&nonce_str=$nonce_str&notify_url=$notify_url&out_trade_no=$out_trade_no&scene_info=$scene_info&spbill_create_ip=$spbill_create_ip&total_fee=$total_fee&trade_type=$trade_type";
	$strSignTmp = $signA."&key=$key";
	$sign = strtoupper(MD5($strSignTmp)); // MD5 后转换成大写
	$post_data = "<xml>
					   <appid>$appid</appid>
					   <mch_id>$mch_id</mch_id>
					   <body>$body</body>
					   <out_trade_no>$out_trade_no</out_trade_no>
					   <total_fee>$total_fee</total_fee>
					   <spbill_create_ip>$spbill_create_ip</spbill_create_ip>
					   <notify_url>$notify_url</notify_url>
					   <trade_type>$trade_type</trade_type>
					   <scene_info>$scene_info</scene_info>
					   <attach>$out_trade_no</attach>
					   <nonce_str>$nonce_str</nonce_str>
					   <sign>$sign</sign>
				   </xml>";
	
	$url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
	$dataxml = postXmlCurl($post_data,$url); 
	$objectxml = (array)simplexml_load_string($dataxml, 'SimpleXMLElement', LIBXML_NOCDATA);
	$objectxml['mweb_url']=$objectxml['mweb_url']._redurl($out_trade_no);
	return $objectxml;
}

function createNoncestr( $length = 32 ){
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str ="";
    for ( $i = 0; $i < $length; $i++ )  {
        $str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);
    }
    return $str;
}
function postXmlCurl($xml,$url,$second = 30){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, $second);
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    $data = curl_exec($ch);
    if($data){
        curl_close($ch);
        return $data;
    }else{
        $error = curl_errno($ch);
        curl_close($ch);
        echo "curl_err:$error"."<br>";
    }
}
function get_client_ip($type = 0) {
   if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
        $ip = getenv('HTTP_CLIENT_IP');
    } elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    } elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
        $ip = getenv('REMOTE_ADDR');
    } elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '';
}

function _redurl($orderid){
	global $_G;
	$redirect_url=urlencode($_G['siteurl'].'plugin.php?id=keke_buyinvitecode&p=loading&orderid='.$orderid);
	$redirect_urls='&redirect_url='.$redirect_url;
	return $redirect_urls;
}

function editor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}

function _getqrcodeurl($urls){
	global $_G;
	$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
	$src = $keke_buyinvitecode['qr']==2?'source/plugin/keke_buyinvitecode/paylib/wechat/example/qrcode.php?data='.urlencode($urls):$urls;
	return $src;
}