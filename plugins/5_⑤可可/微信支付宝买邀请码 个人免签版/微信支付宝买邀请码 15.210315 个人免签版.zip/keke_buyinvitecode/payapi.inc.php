<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
header("Content-type:text/html;charset=utf-8"); /*dis'.'m.tao'.'bao.com*/

$costcount=intval($_GET['costcount']);
$moneyQuantity=$costcount*$keke_buyinvitecode['dj'];
$money=$moneyQuantity*100;
$zftype=intval($_GET['zftype']);
$email = dhtmlspecialchars($_GET['buyemail']);
$title= CHARSET=='gbk' ? diconv(lang('plugin/keke_buyinvitecode', 'lang18'), CHARSET, 'UTF-8') : lang('plugin/keke_buyinvitecode', 'lang18');
include_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/fun.php";
include_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/payjs.php";
if(empty($costcount)) {
	$msg=lang('plugin/keke_buyinvitecode', 'lang19');
	$msgs=diconv($msg, CHARSET,'utf-8');
    exit(json_encode(array('err' =>$msgs)));
}elseif($keke_buyinvitecode['maxnum'] && $costcount>$keke_buyinvitecode['maxnum']){
	$msg=lang('plugin/keke_buyinvitecode', 'f11').$keke_buyinvitecode['maxnum'].lang('plugin/keke_buyinvitecode', 'f12');
	$msgs=diconv($msg, CHARSET,'utf-8');
    exit(json_encode(array('err' =>$msgs)));
}

if(!(preg_match("/^1[3456789]{1}\d{9}$/",$email)) && $email){  
   	$msg=lang('plugin/keke_buyinvitecode', 'lang23');
	$msgs=diconv($msg, CHARSET,'utf-8');
    exit(json_encode(array('err' =>$msgs)));
}

$orderid=_orderid();
$orderarr=array(
	'orderid'=>$orderid,
	'uid'=>0,
	'state'=>1,
	'zftype'=>$zftype,
	'price'=>$moneyQuantity,
	'amount'=>$costcount,
	'time'=>$_G['timestamp'],
	'email'=>$email,
	'ip'=>$_G['clientip'],
);
C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->insert($orderarr, true);

if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && $zftype==2 && checkmobile()){
	$data = array(
		'mchid'        => PAYJS_MCHID,
		'body'         => $title,
		'total_fee'    => $money,
		'out_trade_no' => $orderid,
		'notify_url' => trim($_G['siteurl'] . 'source/plugin/keke_buyinvitecode/paylib/notify_payjs.inc.php'),
	);
	$data['sign'] = payjssign($data);
	$url = 'https://payjs.cn/api/cashier?' . http_build_query($data);
	echo json_encode(array('payjsurl' => $url));
	exit;
}
$data= array(
	'mchid'        => PAYJS_MCHID,
	'total_fee'    => $money,
	'body' => $title,
	'out_trade_no' => $orderid,
	'ip'           => $_SERVER['REMOTE_ADDR'],
	'notify_url'   => trim($_G['siteurl'] . 'source/plugin/keke_buyinvitecode/paylib/notify_payjs.inc.php'),
);
if($zftype==1){
	$data['type'] = 'alipay';
	if($keke_buyinvitecode['alipaytype']==2){
		include_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/paylib/alipay.class.php";
		$appid = trim($keke_buyinvitecode['appid']);
		$notifyUrl = trim($_G['siteurl'] . 'source/plugin/keke_buyinvitecode/paylib/notify_alipay.inc.php');
		$outTradeNo = $orderid;
		$payAmount = $moneyQuantity;
		$orderName = $title;
		$signType = 'RSA2';
		$rsaPrivateKey=trim($keke_buyinvitecode['privatekey']);
		$aliPay = new AlipayService();
		$aliPay->setAppid($appid);
		$aliPay->setNotifyUrl($notifyUrl);
		$aliPay->setRsaPrivateKey($rsaPrivateKey);
		$aliPay->setTotalFee($payAmount);
		$aliPay->setOutTradeNo($outTradeNo);
		$aliPay->setOrderName($orderName);
		$result = $aliPay->doPay();
		$result = $result['alipay_trade_precreate_response'];
		if($result['code'] && $result['code']=='10000'){
			$src = 'source/plugin/keke_buyinvitecode/qrcode.php?data='.urlencode($result['qr_code']);
			exit(json_encode(array('ewmurl' => $src,'orderid'=>$orderid)));
		}else{
			exit(json_encode(array('err' => diconv($result['msg'].' : '.$result['sub_msg'],CHARSET,'utf-8'))));
		}
	}

}
$data['sign'] = payjssign($data);
$result = payjshttpPost($data,'https://payjs.cn/api/native');
$ret=json_decode($result, true);
$src = 'source/plugin/keke_buyinvitecode/qrcode.php?data='.urlencode($ret['code_url']);
echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
exit;