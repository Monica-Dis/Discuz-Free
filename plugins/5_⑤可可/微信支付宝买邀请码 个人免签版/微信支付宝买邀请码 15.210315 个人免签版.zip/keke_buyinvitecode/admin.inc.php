<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
	include_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/fun.php";
	if (submitcheck("forumset")) {
		DB::query("delete FROM ".DB::table('keke_buyinvitecode_orderlog')." where state=1");
		cpmsg(lang('plugin/keke_buyinvitecode', 'lang01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_buyinvitecode&pmod=admin', 'succeed');
	}
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");
    showtableheader(lang('plugin/keke_buyinvitecode', 'lang02'));
	showsubmit('forumset', lang('plugin/keke_buyinvitecode', 'lang03'), '', '');
	showtableheader(lang('plugin/keke_buyinvitecode', 'lang05'));
    showsubtitle(array(lang('plugin/keke_buyinvitecode', 'lang06'),lang('plugin/keke_buyinvitecode', 'lang26'),lang('plugin/keke_buyinvitecode', 'lang08'), lang('plugin/keke_buyinvitecode', 'lang09'),lang('plugin/keke_buyinvitecode', 'lang10'),lang('plugin/keke_buyinvitecode', 'lang11'),lang('plugin/keke_buyinvitecode', 'lang12'),lang('plugin/keke_buyinvitecode', 'lang13'),lang('plugin/keke_buyinvitecode', 'lang14'),lang('plugin/keke_buyinvitecode', 'f18')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_buyinvitecode&pmod=admin';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = _getcounts();
	if($allcount){
		$query = _getorderbypage($startlimit,$ppp);
        $codes=array();
        foreach($query as $val){
            if($val['code']){
                $codeArr=explode(',',$val['code']);
                foreach ($codeArr as $codeval){
                    $codes[$codeval]=$codeval;
                }
            }
        }
        $codeData=C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->fetchalluid_bycodes($codes);
		foreach($query as $val){
			$money=$val['money']/100;
			$time=dgmdate($val['zftime'], 'Y/m/d H:i');
			$cradit=intval($money*$keke_chongzhi['bl']);
			$stat=$val['state']==2 ? '<font color="#33CC33">'.lang('plugin/keke_buyinvitecode', 'lang24').'</font>' : '<font color="#FF3333">'.lang('plugin/keke_buyinvitecode', 'lang25').'</font>' ;
			$type=$val['zftype']==1 ? lang('plugin/keke_buyinvitecode', 'lang15') : lang('plugin/keke_buyinvitecode', 'lang16');
            $fuserName='';
            $codeExp=explode(',',$val['code']);
            foreach ($codeExp as $fName){
                if($codeData[$fName]['fusername'])$fuserName.='<a href="home.php?mod=space&uid='.$codeData[$fName]['fuid'].'" target="_blank">'.$codeData[$fName]['fusername'].'</a> ,';
            }
            $fuserName=substr($fuserName,0,strlen($fuserName)-1);
			$table = array();
			$table[0] = $val['orderid'];
			$table[1] = $val['email'];
			$table[2] = $type;
			$table[3] = $val['price'].' '.lang('plugin/keke_buyinvitecode', 'lang17');
			$table[4] = $stat;
			$table[5] = $val['sn'] ? $val['sn'] : '<font color="#CCCCCC">--</font>';
			$table[6] = dgmdate($val['time'], 'Y/m/d H:i');
			$table[7] = $val['zftime'] ? dgmdate($val['zftime'], 'Y/m/d H:i') : '<font color="#CCCCCC">--</font>';
			$table[8] = $val['code'];
            $table[9] = $fuserName;
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dism _ taobao _com*/
