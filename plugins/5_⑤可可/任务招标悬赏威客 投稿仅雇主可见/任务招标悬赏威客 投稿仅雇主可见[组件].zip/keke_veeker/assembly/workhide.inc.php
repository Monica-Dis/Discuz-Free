<?php
$hidediv='<div class="workhide"></div>';