<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_huati_cy extends discuz_table
{
	public function __construct() {
		$this->_table = 'keke_huati_cy';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}
	
	
	public function count_all($where='') {
		return DB::result_first("SELECT count(*) FROM %t %i", array($this->_table,$where));
	}
	
	public function fetch_all_by_limit($startlimit,$ppp,$where='') {
		return DB::fetch_all("SELECT * FROM %t %i order by id desc LIMIT %d,%d", array($this->_table,$where,$startlimit,$ppp));
	}
	
	public function fetchfirst_byid($hbid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$hbid));
	}
	
	public function count_byhtid($htid,$uids) {
		return DB::result_first("SELECT count(*) FROM %t WHERE htid=%d AND uid=%d", array($this->_table,$htid,$uids));
	}
	
	public function fetchfirst_byhtidanduid($htid,$uids) {
		return DB::result_first("SELECT val FROM %t WHERE htid=%d AND uid=%d", array($this->_table,$htid,$uids));
	}
	
	
	
	public function fetchfirst_bytime($time) {
		return DB::fetch_first("SELECT * FROM %t WHERE time<$time AND endtime>$time order by id desc", array($this->_table));
	}
	
	public function fetchfirst_by_next($time) {
		return DB::fetch_first("SELECT * FROM %t WHERE time>$time order by time desc", array($this->_table));
	}
	
	
	
	public function fetchfirst_bylasttime() {
		return DB::fetch_first("SELECT * FROM %t order by endtime desc", array($this->_table));
	}
	

	
	public function delete_by_id($id) {
		return DB::query("delete FROM %t where id=%d", array($this->_table,$id));
	}
	
	
}
//dis'.'m.t'.'ao'.'bao.com
?>