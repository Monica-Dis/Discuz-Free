  <?php
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
global $_G;
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
$keke_huati = $_G['cache']['plugin']['keke_huati'];
$addyhz=unserialize($keke_huati['addyhz']);
if(!in_array($_G['groupid'],$addyhz)){
	showmessage(lang('plugin/keke_huati', 'f0060'), 'plugin.php?id=keke_huati');
}
require_once DISCUZ_ROOT.'./source/plugin/keke_huati/function.inc.php';
$htid=intval($_GET['htid']);
$insufficient=0;

if($keke_huati['creditac']==2){
	$member_count=_getmember_count($_G['uid']);
	if($member_count['extcredits'.$keke_huati['credittype']]<$keke_huati['credit']){
		$insufficient=1;
	}
}

if (submitcheck("editsubmit")) {
	if($insufficient){
		showmessage(lang('plugin/keke_huati', 'f0065').$keke_huati['credit'].$_G['setting']['extcredits'][$keke_huati['credittype']]['title'].lang('plugin/keke_huati', 'f0066'), '', 'error');
	}
	$isvip=1;
	$vipgro = empty($keke_huati['vipgro']) ? array() : unserialize($keke_huati['vipgro']);
	if(in_array($_G['groupid'],$vipgro)){
		$isvip=0;
	}
	if($keke_huati['creditac']==2 && $isvip){
		updatemembercount($_G['uid'], array('extcredits'.$keke_huati['credittype']=>-$keke_huati['credit']), true, '', 0, '',lang('plugin/keke_huati', 'f0064'),lang('plugin/keke_huati', 'f0079').' ['.dhtmlspecialchars($_GET['text']).']'.lang('plugin/keke_huati', 'f0080'));
	}
	
	$picarr=_uploadpics($_FILES['htpic']);
	$pic=$picarr['url'];
	if(!$_GET['text'] || !$pic || !$_GET['beijing'] || ($keke_huati['viewpoint'] && (!$_GET['z_gd'] || !$_GET['f_gd']))){
		showmessage(lang('plugin/keke_huati', 'f0055'), '', 'error');
	}
	
	$arr=array(
		'text'=> daddslashes(dhtmlspecialchars($_GET['text'])),
		'htpic'=> daddslashes($pic),
		'z_gd'=> daddslashes(dhtmlspecialchars($_GET['z_gd'])),
		'f_gd'=> daddslashes(dhtmlspecialchars($_GET['f_gd'])),
		'beijing'=> editor_safe_replace($_GET['beijing']),
		'time'=> $_G['timestamp'],
		'uid'=>$_G['uid'],
		'state'=>2
	);
	if($htdata){
		C::t('#keke_huati#keke_huati')->update($htid,$arr);
	}else{
		C::t('#keke_huati#keke_huati')->insert($arr);
	}
	showmessage(lang('plugin/keke_huati', 'f0061'), 'plugin.php?id=keke_huati', 'succeed');
}
$yesalias=dhtmlspecialchars($keke_huati['yesalias']);
$noalias=dhtmlspecialchars($keke_huati['noalias']);
$keke_huati['tip']=dhtmlspecialchars($keke_huati['tip']);
$wapbanner=dhtmlspecialchars($keke_huati['wapbanner']);
$hotno=intval($keke_huati['hot']);
$hotnum=$keke_huati['hotnum'] ? intval($keke_huati['hotnum']) : 3;
$hothtdata = C::t('#keke_huati#keke_huati')->fetch_hot(0,$hotnum,'WHERE (z_num+f_num)>'.$hotno);
$banners=dhtmlspecialchars($keke_huati['bannerurl']);
$bannerurl=dhtmlspecialchars($keke_huati['bannerurls']);
$navtitle=$htdata['text'] ? $htdata['text'] .'-'. dhtmlspecialchars($keke_huati['title']) : dhtmlspecialchars($keke_huati['title']);
$foottxt=dhtmlspecialchars($keke_huati['foot']);
include template('keke_huati:add');