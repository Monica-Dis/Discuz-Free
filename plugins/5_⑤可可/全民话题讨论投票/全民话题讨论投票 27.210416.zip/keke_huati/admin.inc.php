<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	loadcache('plugin');
	$keke_huati = $_G['cache']['plugin']['keke_huati'];
	require_once DISCUZ_ROOT.'./source/plugin/keke_huati/function.inc.php';
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
		    C::t('#keke_huati#keke_huati')->delete($_GET['delete']);
		}
		foreach ($_GET['displayorder'] as $htid=>$val){
            C::t('#keke_huati#keke_huati')->update($htid,array('displayorder'=>$val));
        }
		cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin', 'succeed');
	}

	if($_GET['ac']){
		if($_GET['formhash'] != $_G['formhash']) {
			exit('Access Denied');
		}
		$htid=intval($_GET['htid']);
		$htdata = gethtdata($htid);;
		if($_GET['ac']=='edit'){
			if (submitcheck("editsubmit")) {
				$up_pic=_uploadpics($_FILES['htpic']);
				$pic=$_FILES['htpic'] ? $up_pic['url'] : $_GET['htpic'];
				if(!$_GET['text'] || !$pic || !$_GET['beijing'] || ($keke_huati['viewpoint'] && (!$_GET['z_gd'] || !$_GET['f_gd']))){
					cpmsg('Input incomplete!', '', 'error');
				}
				$jz = $_GET['jz'] ? strtotime($_GET['jz']) : 0;
				$arr=array(
					'text'=> daddslashes(dhtmlspecialchars($_GET['text'])),
					'htpic'=> daddslashes($pic),
					'z_gd'=> daddslashes(dhtmlspecialchars($_GET['z_gd'])),
					'f_gd'=> daddslashes(dhtmlspecialchars($_GET['f_gd'])),
					'z_num'=> intval($_GET['z_num']),
					'f_num'=> intval($_GET['f_num']),
					'beijing'=> editor_safe_replaces($_GET['beijing']),
					'state'=> $_GET['state']?intval($_GET['state']):1,
					'uid'=> $_G['uid'],
					'time'=> ($htdata['time']?$htdata['time']:$_G['timestamp']),
					'jz'=> $jz,
                    'displayorder'=> intval($_GET['displayorder'])
				);
				if($htdata){
					C::t('#keke_huati#keke_huati')->update($htid,$arr);
				}else{
					C::t('#keke_huati#keke_huati')->insert($arr);
				}
				cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin&ac=edit&htid='.$htid.'&formhash='.FORMHASH, 'succeed');
			}
			showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin&ac=edit", 'enctype');
			showtableheader(lang('plugin/keke_huati', 'f0036'));
			showsetting(lang('plugin/keke_huati', 'f0037'),'text',$htdata['text'],'text');
			showsetting(lang('plugin/keke_huati', 'f0038'),'htpic',$htdata['htpic'],'filetext');
			if($keke_huati['viewpoint']){
				showsetting(lang('plugin/keke_huati', 'f0039'),'z_gd',$htdata['z_gd'],'textarea');
				showsetting(lang('plugin/keke_huati', 'f0040'),'f_gd',$htdata['f_gd'],'textarea');
			}
			showsetting(lang('plugin/keke_huati', 'f0041'),'z_num',$htdata['z_num'],'text');
			showsetting(lang('plugin/keke_huati', 'f0042'),'f_num',$htdata['f_num'],'text');
			showsetting(lang('plugin/keke_huati', 'f0100'),'jz',($htdata['jz']?dgmdate($htdata['jz'], 'Y-n-j H:i'):''),'calendar','','',lang('plugin/keke_huati', 'f0101'),1);
			echo '
			<tr><td colspan="2" class="td27">'.lang('plugin/keke_huati', 'f0043').':</td></tr>
			<tr class="noborder"><td class="vtop rowform"  colspan="2">
			<textarea name="beijing" style="width:700px;height:200px;visibility:hidden;">'.$htdata['beijing'].'</textarea></td></tr>
			';
            showsetting(lang('plugin/keke_huati', 'f0102'),'displayorder',$htdata['displayorder'],'text');
			echo "
			<script type=\"text/javascript\" src=\"static/js/calendar.js\"></script>
			<script charset=\"utf-8\" src=\"./source/plugin/keke_huati/static/kindeditor/kindeditor-min.js\"></script>
			<script charset=\"utf-8\" src=\"./source/plugin/keke_huati/static/kindeditor/lang/zh-CN.js\"></script>
			<script>
			  var itemss = [
				  'source', '|', 'undo', 'redo', '|', 'preview', 'template', 'cut', 'copy', 'paste',
				  'plainpaste', 'wordpaste', '|', 'justifyleft', 'justifycenter', 'justifyright',
				  'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
				  'superscript', 'clearhtml', 'quickformat', 'selectall', '|', 'fullscreen', '/',
				  'formatblock', 'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold',
				  'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'image', 'multiimage', 'table', 'hr', 'emoticons', 'baidumap', 'pagebreak',
				  'anchor', 'link', 'unlink'
			  ];
			  KindEditor.ready(function(K) {
						var editor1 = K.create('textarea[name=\"beijing\"]', {
							uploadJson : './source/plugin/keke_huati/upload_json.php',
							allowFileManager : false,
							filterMode: false,
							items : itemss
						});
					});
			</script>
			";
			
			echo '<input name="htid" type="hidden" value="'.$htdata['id'].'" />';
			echo '<input name="state" type="hidden" value="'.$htdata['state'].'" />';
			showsubmit('editsubmit', 'submit', '');
			showtablefooter(); /*dism-Taobao-com*/
   			showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
			exit();
		}elseif($_GET['ac']=='shtg'){
			if($keke_huati['credittype'] && $keke_huati['creditac']==1){
					updatemembercount($htdata['uid'], array('extcredits'.$keke_huati['credittype']=>$keke_huati['credit']), true, '', 0, '',lang('plugin/keke_huati', 'f0063'),lang('plugin/keke_huati', 'f0057').'<a href="plugin.php?id=keke_huati&htid='.$htdata['id'].'">['.$htdata['text'].']</a>'.lang('plugin/keke_huati', 'f0058'));
			}
			$arr=array('state'=>1);
			C::t('#keke_huati#keke_huati')->update($htid,$arr);
			$htdata=gethtdata($htdata['id']);
			notification_add($htdata['uid'],'system',lang('plugin/keke_huati', 'f0057').'<a href="plugin.php?id=keke_huati&htid='.$htdata['id'].'">['.$htdata['text'].']</a>'.lang('plugin/keke_huati', 'f0058'));
			cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin', 'succeed');
		}elseif($_GET['ac']=='shjj'){
			$arr=array('state'=>3);
			C::t('#keke_huati#keke_huati')->update($htid,$arr);
			$isvip=1;
			$vipgro = empty($keke_huati['vipgro']) ? array() : unserialize($keke_huati['vipgro']);
			if(in_array($_G['groupid'],$vipgro)){
				$isvip=0;
			}
			if($keke_huati['creditac']==2 && $isvip){
				updatemembercount($htdata['uid'], array('extcredits'.$keke_huati['credittype']=>$keke_huati['credit']), true, '', 0, '',lang('plugin/keke_huati', 'f0076'),lang('plugin/keke_huati', 'f0057').'<a href="plugin.php?id=keke_huati&htid='.$htdata['id'].'">['.$htdata['text'].']</a>'.lang('plugin/keke_huati', 'f0059'));
			}
			notification_add($htdata['uid'],'system',lang('plugin/keke_huati', 'f0057').'<a href="plugin.php?id=keke_huati&htid='.$htdata['id'].'">['.$htdata['text'].']</a>'.lang('plugin/keke_huati', 'f0059'));
		}elseif($_GET['ac']=='del'){
			C::t('#keke_huati#keke_huati')->delete($htid);
		}
		cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin', 'succeed');
	}

	showtableheader(lang('plugin/keke_huati', 'f0045'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_huati&pmod=admin', 'testhd');
	showsetting(lang('plugin/keke_huati', 'f0046'),'keyw',$username,'text');
	showsubmit('searchsubmit'); 
	echo '<tr class="hover"><td colspan="9"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin&ac=edit&formhash='.FORMHASH.'"><font color="#FF0000"> + '.lang('plugin/keke_huati', 'f0047').'</font></a></td></tr>';
	showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
	showtablefooter(); /*dism-Taobao-com*/
	$where = 'where id>0';
	if($_GET['keyw']){
		$where .= " and text LIKE '%".daddslashes(addcslashes(dhtmlspecialchars($_GET['keyw']),'%_'))."%'";
	}
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");
	showtableheader(lang('plugin/keke_huati', 'f0048'));
    showsubtitle(array(lang('plugin/keke_huati', 'f0020'),'id',lang('plugin/keke_huati', 'f0022'), lang('plugin/keke_huati', 'f0049'),lang('plugin/keke_huati', 'f0050'),lang('plugin/keke_huati', 'f0062'),lang('plugin/keke_huati', 'f0051'),lang('plugin/keke_huati', 'f0025'),lang('plugin/keke_huati', 'f0102'),lang('plugin/keke_huati', 'f0026')));
	
	$ppp=50;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = _gethtallcount(1,$where);
	if($allcount){
		$query = _gethtall(1,$startlimit,$ppp,$where.' ORDER BY displayorder DESC,id DESC');
		foreach($query as $val){
			$jj='';
			if($val['state']==1){
				$stat='<font color="#33CC33">'.lang('plugin/keke_huati', 'f0027').'</font>';
			}elseif($val['state']==3){
				$stat='<font color="#FF9900">'.lang('plugin/keke_huati', 'f0028').'</font>';
			}else{
				$stat='<font color="#c30">'.lang('plugin/keke_huati', 'f0029').'</font>';
				$jj='/ <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin&ac=shjj&htid='.$val['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_huati', 'f0030').'</a>';
			}
			$editdelurl='<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin&ac=edit&htid='.$val['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_huati', 'f0031').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin&ac=del&htid='.$val['id'].'&formhash='.FORMHASH.'"  onClick="return confirm(\''.lang('plugin/keke_huati', 'f0032').'\');">'.lang('plugin/keke_huati', 'f0033').'</a>';
			$acs=$val['state']==1 ? $editdelurl:'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin&ac=shtg&htid='.$val['id'].'&formhash='.FORMHASH.'" onClick="return confirm(\''.lang('plugin/keke_huati', 'f0034').'\');">'.lang('plugin/keke_huati', 'f0035').'</a> '.$jj.' / '.$editdelurl;
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = $val['id'];
			$table[2] = '<b><a href="plugin.php?id=keke_huati&htid='.$val['id'].'" target="_blank">'.$val['text'].'</a></b>';
			$table[3] = $val['z_num'];
			$table[4] = $val['f_num'];
			$table[5] = '<a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'._getusname($val['uid']).'</a>';
			$table[6] = dgmdate($val['time'], 'Y/m/d H:i');
			$table[7] = $stat;
            $table[8] = '<input type="text" class="txt" name="displayorder['.$val['id'].']" value="'.$val['displayorder'].'" />';
			$table[9] = $acs;
			showtablerow('',array('class="td30"','','','','','','','','class="td25"'), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter(); /*dism-Taobao-com*/
    showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
	function _getusname($uids){
		$p=C::t('common_member')->fetch('1');
		return $p['username'];
	}