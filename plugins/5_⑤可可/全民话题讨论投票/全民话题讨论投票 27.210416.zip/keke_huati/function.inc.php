<?php
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

include_once DISCUZ_ROOT."source/plugin/keke_huati/identity.inc.php";
function _upload_img($file,$width, $height,$max=1024,$thumb='1'){
	global $_G;
	$file['size'] > ($max * 1024) && showmessage('file_size_overflow', '', array('size' => $max * 1024));
	$upload = new discuz_upload();
	$uploadtype = 'common';

	if(!is_array($file) || empty($file) || !$upload->is_upload_file($file['tmp_name']) || trim($file['name']) == '' || $file['size'] == 0) {
		$upload->attach = array();
		$upload->errorcode = -1;
		return false;
	} else {
    	$upload->type = discuz_upload::check_dir_type('common');
		$upload->extid = intval($data['extid']);
		$upload->forcename = '';
	
		$file['size'] = intval($file['size']);
		$file['name'] =  trim($file['name']);
		$file['thumb'] = '';
		$file['ext'] = $upload->fileext($file['name']);
		$file['name'] =  dhtmlspecialchars($file['name'], ENT_QUOTES);
		if(strlen($file['name']) > 90) {
			$file['name'] = cutstr($file['name'], 80, '').'.'.$file['ext'];
		}
		$file['isimage'] = $upload->is_image_ext($file['ext']);
		if(!$file['isimage']) {
			cpmsg(lang('error', 'file_upload_error_-102'), '', 'error');
			exit();
		}
		$file['extension'] = $upload->get_target_extension($file['ext']);
		$file['attachdir'] = _get_target_dir($upload->type);
		$file['attachment'] = $file['attachdir'].$upload->get_target_filename($upload->type, $upload->extid, $upload->forcename).'.'.$file['extension'];
		$file['target'] = getglobal('setting/attachdir').'./'.$upload->type.'/'.$file['attachment'];
		
		$upload->attach = $file;
		$upload->errorcode = 0;
	}
	if(!$upload->save()) {
		cpmsg($upload->errormessage(), '', 'error');
	}
	if($thumb && ($upload->attach['imageinfo'][0]>$width || $upload->attach['imageinfo'][1]>$height)){
		if($file['isimage']){
			require_once libfile('class/image');
			$img = new image;
			$thumbpic=$img->Thumb($upload->attach['target'], './'.$uploadtype.'/'.$upload->attach['attachment'].'_thumb.jpg', $width, $height, 'fixwr');
		}		
	}
	if($thumbpic){
		return getglobal('setting/attachurl').$uploadtype.'/'.$upload->attach['attachment'].'_thumb.jpg';
	}else{
		return getglobal('setting/attachurl').$uploadtype.'/'.$upload->attach['attachment'];
	}
}

function _get_target_dir($type, $check_exists = true) {
	$subdir = $subdir1 = $subdir2 = '';
	$subdir1 = date('Ym');
	$subdir2 = date('d');
	$subdir = $subdir1.'/'.$subdir2.'/';
	$check_exists && discuz_upload::check_dir_exists($type, $subdir1, $subdir2);
	return $subdir;
}

function utf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return gbk2utf($data);
	}
}
function gbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}

function gethtdata($htid){
	$htdata = C::t('#keke_huati#keke_huati')->fetchfirst_byid($htid);
	return $htdata;
}

function _gethtallcount($types,$wheres=''){
	if($types==1){
		return C::t('#keke_huati#keke_huati')->count_all($wheres);
	}else{
		return C::t('#keke_huati#keke_huati_pl')->count_all($wheres);
	}
}


function huati_cutstr_html($string){  
    $string = strip_tags($string);  
    $string = trim($string);  
    $string = ereg_replace("\t","",$string);  
    $string = ereg_replace("\r\n","",$string);  
    $string = ereg_replace("\r","",$string);  
    $string = ereg_replace("\n","",$string);  
    $string = ereg_replace(" ","",$string);  
    return trim($string);  

}

function _gethtall($types,$startlimit,$ppp,$wheres=''){
	if($types==1){
		$htdata= C::t('#keke_huati#keke_huati')->fetch_all_by_limit($startlimit,$ppp,$wheres);
		foreach($htdata as $k=>$v){
			$htdata[$k]['date']=dgmdate($v['time'], 'Y/m/d H:i');
			$total=intval($v['z_num']+$v['f_num']);
			$htdata[$k]['z_pre']=intval(($v['z_num']/$total)*100);
			$htdata[$k]['f_pre']=100-$htdata[$k]['z_pre'];
			$descstr = preg_replace("/<([a-zA-Z]+)[^>]*>/","<\\1>",$v['beijing']);
			$cutnum=checkmobile()?76:140;
			$htdata[$k]['desc']=cutstr(strip_tags($descstr),$cutnum);
		}
		return $htdata;
	}else{
		$pldata=C::t('#keke_huati#keke_huati_pl')->fetch_all_by_limit($startlimit,$ppp,$wheres);
		foreach($pldata as $plkey=>$plval){
			$pldata[$plkey]['cy']=_getcy($plval['htid'],$plval['uid']);
		}
		return $pldata;
	}
}


function _getcy($htid,$uid){
	return C::t('#keke_huati#keke_huati_cy')->fetchfirst_byhtidanduid($htid,$uid);
}

function _uploadpics($filses){
	global $_G;
	require_once libfile('function/forum');
	$data = array('extid' => 1);
	$pic['url']=$_G['setting']['attachurl'].'common/'.upload_icon_banner($data, $filses,'');
	$pic['error'] = 0;
	return $pic;
}

function editor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}

function editor_safe_replaces($content){
    $tags = array(
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}

function _getmember_count($uid){
	return C::t('common_member_count')->fetch($uid);
}

function _cutbeijing($data,$cutnum){
	$descstr= preg_replace('/<\s*img\s+[^>]*?src\s*=\s*(\'|\")(.*?)\\1[^>]*?\/?\s*>/i', '', $data);
	$descstr=cutstr(strip_tags($descstr),$cutnum);
	return $descstr;
}