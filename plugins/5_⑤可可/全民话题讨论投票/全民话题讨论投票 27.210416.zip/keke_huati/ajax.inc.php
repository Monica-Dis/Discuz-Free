<?php
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

loadcache('plugin');
global $_G;
$keke_huati = $_G['cache']['plugin']['keke_huati'];
require_once DISCUZ_ROOT.'./source/plugin/keke_huati/function.inc.php';
if($_GET['ac']=='zc' || $_GET['ac']=='fd'){
	$htid=intval($_GET['htid']);
	if($htid){
		$cycount = C::t('#keke_huati#keke_huati_cy')->count_byhtid($htid,$_G['uid']);
		if($cycount){
			$msg=gbk2utf(lang('plugin/keke_huati', 'f001'));
			exit(json_encode(array('err' =>$msg)));
		}
		$val='';
		$htdata = gethtdata($htid);
		if($htdata['jz'] && $htdata['jz']<TIMESTAMP){
			exit(json_encode(array('err' =>gbk2utf(lang('plugin/keke_huati', 'f0094')))));
		}
		if($_GET['ac']=='zc'){
			$val=1;
			$arr=array(
				'z_num'=>$htdata['z_num']+1
			);
		}elseif($_GET['ac']=='fd'){
			$val=2;
			$arr=array(
				'f_num'=>$htdata['f_num']+1
			);
		}
		$htdata = C::t('#keke_huati#keke_huati')->update($htid,$arr);
		$cyarr=array(
			'uid'=>$_G['uid'],
			'htid'=>$htid,
			'val'=>$val,
			'time'=>$_G['timestamp'],
		);
		C::t('#keke_huati#keke_huati_cy')->insert($cyarr);
		echo json_encode(array('err' =>''));
		exit();
	}
}elseif($_GET['ac']=='pinglun'){
	$htid=intval($_GET['htid']);
	$htdata = gethtdata($htid);
	if($htdata['jz'] && $htdata['jz']<TIMESTAMP){
		exit(json_encode(array('err' =>gbk2utf(lang('plugin/keke_huati', 'f0094')))));
	}
	$pldata = C::t('#keke_huati#keke_huati_pl')->count_byhtid($htid,$_G['uid']);
	$nr=daddslashes($_GET['nr']);
	$yhzarr=unserialize($keke_huati['yhz']);
	$heiarr=explode(",",$keke_huati['plhei']);
	$keke_huati['plcount']=$keke_huati['plcount']?$keke_huati['plcount']:1;
	$state=0;
	if(!$_G['uid']){
		$msg=gbk2utf(lang('plugin/keke_huati', 'f002'));
		$state=1;
	}elseif(in_array($_G['uid'],$heiarr)){
		$msg=gbk2utf(lang('plugin/keke_huati', 'f0053'));
	}elseif(!(in_array($_G['groupid'],$yhzarr))){
		$msg=gbk2utf(lang('plugin/keke_huati', 'f003'));
	}elseif(!$nr){
		$msg=gbk2utf(lang('plugin/keke_huati', 'f004'));
	}elseif($pldata>=$keke_huati['plcount']){
		$msg=gbk2utf(lang('plugin/keke_huati', 'f005').intval($keke_huati['plcount']).lang('plugin/keke_huati', 'f0052'));
	}
	if($msg){
		exit(json_encode(array('err' =>$msg,'state'=>$state)));
	}
	$cydata = C::t('#keke_huati#keke_huati_cy')->fetchfirst_byhtidanduid($htid,$_G['uid']);
	if($keke_huati['btpl']){
		if(!$cydata){
			$msg=gbk2utf(lang('plugin/keke_huati', 'f0091'));
			exit(json_encode(array('err' =>$msg)));
		}
	}
	
	$plnr=utf2gbk($_GET['nr']);
	$state=$keke_huati['exa']? 2 : 1;
	$plarr=array(
		'uid'=>$_G['uid'],
		'usname'=>$_G['username'],
		'htid'=>$htid,
		'pl'=>daddslashes($plnr),
		'state'=>$state,
		'time'=>$_G['timestamp'],
	);
	C::t('#keke_huati#keke_huati_pl')->insert($plarr);
	echo json_encode(array('err' =>'','cytype'=>$cydata));
	exit();
}