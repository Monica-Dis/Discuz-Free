<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$table = array();
	showtips(lang('plugin/keke_huati', 'f0067'));
    showtableheader(lang('plugin/keke_huati', 'f0070'));	
    showsubtitle(array(lang('plugin/keke_huati', 'f0071'),'', lang('plugin/keke_huati', 'f0072'), lang('plugin/keke_huati', 'f0073')));
	
	$wapsa=file_exists("source/plugin/keke_share/get_sdk.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_huati', 'f0068').'</span>' : '<a href="https://dism.taobao.com?/?@keke_share.plugin"><span class="error">'.lang('plugin/keke_huati', 'f0069').'</span></a>';		
	$table[0] = '<img src="source/plugin/keke_huati/template/images/keke_share.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_huati', 'f0074');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_huati', 'f0075').'</span>';
	$table[3] = $wapsa;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	$wapsa=file_exists("source/class/block/huati/block_huati.php")? '<span class="diffcolor2">'.lang('plugin/keke_huati', 'f0068').'</span>' : '<a href="https://dism.taobao.com?/?@keke_huatidiy.pack"><span class="error">'.lang('plugin/keke_huati', 'f0069').'</span></a>';		
	$table[0] = '<img src="source/plugin/keke_huati/template/images/keke_huatidiy.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_huati', 'f0092');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_huati', 'f0093').'</span>';
	$table[3] = $wapsa;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	
    showtablefooter(); /*dism-Taobao-com*/
