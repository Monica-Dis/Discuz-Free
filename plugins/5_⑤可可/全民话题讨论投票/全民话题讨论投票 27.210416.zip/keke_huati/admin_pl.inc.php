<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	$keke_huati = $_G['cache']['plugin']['keke_huati'];
	require_once DISCUZ_ROOT.'./source/plugin/keke_huati/function.inc.php';
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
				C::t('#keke_huati#keke_huati_pl')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&identifier=keke_huati&pmod=admin_pl', 'succeed');
	}
	
	if (submitcheck("setok") || submitcheck("setref")) {
		if(is_array($_GET['delete'])) {
			foreach($_GET['delete'] as $val){
				$plid=intval($val);
				$pldata = C::t('#keke_huati#keke_huati_pl')->fetchfirst_byid($plid);
				$htdata=gethtdata($pldata['htid']);
				if(submitcheck("setok") && ($pldata['state']==2 || $pldata['state']==3)){
					C::t('#keke_huati#keke_huati_pl')->update($plid,array('state'=>1));
					notification_add($pldata['uid'],'system',lang('plugin/keke_huati', 'f009').'<a href="plugin.php?id=keke_huati&htid='.$htdata['id'].'">'.lang('plugin/keke_huati', 'f0077').$htdata['text'].lang('plugin/keke_huati', 'f0078').'</a>'.lang('plugin/keke_huati', 'f0010'));
				}elseif(submitcheck("setref") && $pldata['state']==2){
					C::t('#keke_huati#keke_huati_pl')->update($plid,array('state'=>3));
					notification_add($pldata['uid'],'system',lang('plugin/keke_huati', 'f0011').'<a href="plugin.php?id=keke_huati&htid='.$htdata['id'].'">'.lang('plugin/keke_huati', 'f0077').$htdata['text'].lang('plugin/keke_huati', 'f0078').'</a>'.lang('plugin/keke_huati', 'f0012'));
				}
			}
		}
		cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&identifier=keke_huati&pmod=admin_pl', 'succeed');
	}
	
	if($_GET['ac'] && $_GET['plid']){
		if($_GET['formhash'] != $_G['formhash']) {
			exit('Access Denied');
		}
		$plid=intval($_GET['plid']);
		$pldata = C::t('#keke_huati#keke_huati_pl')->fetchfirst_byid($plid);
		if($_GET['ac']=='edit'){
			if (submitcheck("editsubmit")) {
				$arr=array(
					'pl'=> daddslashes($_GET['pl'])
				);
				C::t('#keke_huiti#keke_huati_pl')->update($plid,$arr);
				cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&identifier=keke_huati&pmod=admin_pl', 'succeed');
			}
			showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_pl&ac=edit");
			showtableheader(lang('plugin/keke_huati', 'f007'));
			showsetting(lang('plugin/keke_huati', 'f008'),'pl',$pldata['pl'],'textarea');
			echo '<input name="plid" type="hidden" value="'.$pldata['id'].'" />';
			showsubmit('editsubmit', 'submit', '');
			showtablefooter(); /*dism-Taobao-com*/
   			showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
			exit();
		}elseif($_GET['ac']=='shtg'){
			$arr=array('state'=>1);
			C::t('#keke_huati#keke_huati_pl')->update($plid,$arr);
			$htdata=gethtdata($pldata['htid']);
			
			notification_add($pldata['uid'],'system',lang('plugin/keke_huati', 'f009').'<a href="plugin.php?id=keke_huati&htid='.$htdata['id'].'">'.lang('plugin/keke_huati', 'f0077').$htdata['text'].lang('plugin/keke_huati', 'f0078').'</a>'.lang('plugin/keke_huati', 'f0010'));
			cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&identifier=keke_huati&pmod=admin_pl', 'succeed');
		}elseif($_GET['ac']=='shjj'){
			$htdata=gethtdata($pldata['htid']);
			$arr=array('state'=>3);
			C::t('#keke_huati#keke_huati_pl')->update($plid,$arr);
			notification_add($pldata['uid'],'system',lang('plugin/keke_huati', 'f0011').'<a href="plugin.php?id=keke_huati&htid='.$htdata['id'].'">'.lang('plugin/keke_huati', 'f0077').$htdata['text'].lang('plugin/keke_huati', 'f0078').'</a>'.lang('plugin/keke_huati', 'f0012'));
		}elseif($_GET['ac']=='del'){
			C::t('#keke_huati#keke_huati_pl')->delete($plid);
		}
		cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&identifier=keke_huati&pmod=admin_pl', 'succeed');
	}
	
	
	showtableheader(lang('plugin/keke_huati', 'f0013'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=admin_pl', 'testhd');
	showsetting(lang('plugin/keke_huati', 'f0014'), array('state', array(
	array(2,lang('plugin/keke_huati', 'f0015')),
	array(1,lang('plugin/keke_huati', 'f0016')),
	array(3, lang('plugin/keke_huati', 'f0017')),
	)), $_GET['state'], 'select');
	showsetting(lang('plugin/keke_huati', 'f0018'),'keyw',$username,'text');
	showsubmit('searchsubmit');
	showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/
	showtablefooter(); /*dism-Taobao-com*/
	
	$where = 'where id>0';
	if($_GET['state']){
		$where .= ' and state='.intval($_GET['state']);
	}
	
	if($_GET['keyw']){
		$where .= " and pl LIKE '%".daddslashes(addcslashes(dhtmlspecialchars($_GET['keyw']),'%_'))."%'";
	}

    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_pl");
	showtableheader(lang('plugin/keke_huati', 'f0019'));
    showsubtitle(array(lang('plugin/keke_huati', 'f0020'),'id',lang('plugin/keke_huati', 'f0021'), lang('plugin/keke_huati', 'f0022'),lang('plugin/keke_huati', 'f0023'),lang('plugin/keke_huati', 'f0024'),lang('plugin/keke_huati', 'f0025'),lang('plugin/keke_huati', 'f0026')));
	$ppp=50;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin_pl';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$uid=1;
	$allcount = _gethtallcount(2,$where);
	if($allcount){
		$query = _gethtall(2,$startlimit,$ppp,$where);
		foreach($query as $val){
			$jj='';
			if($val['state']==1){
				$stat='<font color="#33CC33">'.lang('plugin/keke_huati', 'f0027').'</font>';
			}elseif($val['state']==3){
				$stat='<font color="#FF9900">'.lang('plugin/keke_huati', 'f0028').'</font>';
			}else{
				$stat='<font color="#c30">'.lang('plugin/keke_huati', 'f0029').'</font>';
				$jj='/ <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin_pl&ac=shjj&plid='.$val['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_huati', 'f0030').'</a>';
			}
			$htdata=gethtdata($val['htid']);
			$editdelurl='<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin_pl&ac=edit&plid='.$val['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_huati', 'f0031').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_huati&pmod=admin_pl&ac=del&plid='.$val['id'].'&formhash='.FORMHASH.'"  onClick="return confirm(\''.lang('plugin/keke_huati', 'f0032').'\');">'.lang('plugin/keke_huati', 'f0033').'</a>';
			$acs=$val['state']==1 ? $editdelurl:'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin_pl&ac=shtg&plid='.$val['id'].'&formhash='.FORMHASH.'" onClick="return confirm(\''.lang('plugin/keke_huati', 'f0034').'\');">'.lang('plugin/keke_huati', 'f0035').'</a> '.$jj.' / '.$editdelurl;
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = $val['id'];
			$table[2] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_huati&pmod=admin_pl&ac=edit&plid='.$val['id'].'&formhash='.FORMHASH.'">'.cutstr($val['pl'],70).'</a>';
			$table[3] = '<a href="plugin.php?id=keke_huati&htid='.$val['htid'].'" target="_blank">'.$htdata['text'].'</a>';
			$table[4] = $val['usname'];
			$table[5] = dgmdate($val['time'], 'Y/m/d H:i');
			$table[6] = $stat;
			$table[7] = $acs;
			showtablerow('',array('class="td30"'), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', lang('plugin/keke_huati', 'f0087'), '<input type="checkbox" name="chkall" id="allx" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')"><label for="allx">'.lang('plugin/keke_huati', 'f0088').'</label>','<input type="submit" class="btn" id="submit_forumset" name="setok"  value="'.lang('plugin/keke_huati', 'f0089').'"> &nbsp;<input type="submit" class="btn" id="submit_forumset" name="setref"  value="'.lang('plugin/keke_huati', 'f0090').'">');
    showtablefooter(); /*dism-Taobao-com*/
    showformfooter(); /*di'.'sm.t'.'aoba'.'o.com*/