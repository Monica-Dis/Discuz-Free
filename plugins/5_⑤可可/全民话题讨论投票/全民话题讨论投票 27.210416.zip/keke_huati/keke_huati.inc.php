<?php
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
global $_G;
$keke_huati = $_G['cache']['plugin']['keke_huati'];
require_once DISCUZ_ROOT.'./source/plugin/keke_huati/function.inc.php';
$keke_share=0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/keke_share/get_sdk.inc.php')){
	$keke_share=1;
}
$htid=intval($_GET['htid']);
if($htid){
	$htdata = gethtdata($htid);
	if($htdata['state']==2 || $htdata['state']==3){
		showmessage(lang('plugin/keke_huati', 'f0056'), 'plugin.php?id=keke_huati', 'error');
	}
	$total=intval($htdata['z_num']+$htdata['f_num']);
	if($htdata['z_num']==0 && $htdata['f_num']==0){
		$z_per=$f_per=50;
	}else{
		$z_per=intval(($htdata['z_num']/$total)*100);
		$f_per=100-$z_per;
	}
	$jztime=($htdata['jz']?(($htdata['jz']<TIMESTAMP)?lang('plugin/keke_huati', 'f0097'):lang('plugin/keke_huati', 'f0098').dgmdate($htdata['jz'], 'Y-n-j H:i').' '.lang('plugin/keke_huati', 'f0099')):'');
	
	$cydata = C::t('#keke_huati#keke_huati_cy')->fetchfirst_byhtidanduid($htid,$_G['uid']);
	$descstr=_cutbeijing($htdata['beijing'],100);
	$where='WHERE htid='.$htid.' AND state=1 ';
	$ppp=20;
	$tmpurl='plugin.php?id=keke_huati&htid='.$htid;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = _gethtallcount(2,$where);
	$pldata = $allcount? _gethtall(2,$startlimit,$ppp,$where):'';
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
}else{
	$ppp=$keke_huati['page'] ? intval($keke_huati['page']) : 30;
	$tmpurl='plugin.php?id=keke_huati';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = _gethtallcount(1);
	$htdata = $allcount ? _gethtall(1,$startlimit,$ppp,'WHERE state=1 ORDER BY displayorder DESC,id DESC'):'';
	foreach($htdata as $k=>$v){
		if($v['z_num']==0 && $v['f_num']==0){
			$htdata[$k]['z_pre']=$htdata[$k]['f_pre']=50;
		}
		$htdata[$k]['jzs']=($v['jz']?(($v['jz']<TIMESTAMP)?lang('plugin/keke_huati', 'f0095'):lang('plugin/keke_huati', 'f0096')):lang('plugin/keke_huati', 'f0096'));
	}
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
}
$addyhz=unserialize($keke_huati['addyhz']);
$addqx=in_array($_G['groupid'],$addyhz)?1:0;
$yesalias=dhtmlspecialchars($keke_huati['yesalias']);
$noalias=dhtmlspecialchars($keke_huati['noalias']);
$yesbtntxt=dhtmlspecialchars($keke_huati['yesbtntxt']);
$nobtntxt=dhtmlspecialchars($keke_huati['nobtntxt']);
$wapbanner=dhtmlspecialchars($keke_huati['wapbanner']);
$hotno=intval($keke_huati['hot']);
$hotnum=$keke_huati['hotnum'] ? intval($keke_huati['hotnum']) : 10;
$hothtdata = C::t('#keke_huati#keke_huati')->fetch_hot(0,$hotnum,'WHERE (z_num+f_num)>'.$hotno);
$banners=dhtmlspecialchars($keke_huati['bannerurl']);
$bannerurl=dhtmlspecialchars($keke_huati['bannerurls']);
$navtitle=$htdata['text'] ? $htdata['text'] .'-'. dhtmlspecialchars($keke_huati['title']) : dhtmlspecialchars($keke_huati['title']);
$foottxt=dhtmlspecialchars($keke_huati['foot']);
include template('keke_huati:index');