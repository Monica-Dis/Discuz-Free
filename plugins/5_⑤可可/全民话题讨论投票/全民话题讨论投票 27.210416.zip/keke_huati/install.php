<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_huati= DB::table("keke_huati");
$keke_huati_cy= DB::table("keke_huati_cy");
$keke_huati_pl= DB::table("keke_huati_pl");

$sql = <<<EOF
CREATE TABLE `$keke_huati` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `text` varchar(255) NOT NULL,
  `htpic` varchar(255) NOT NULL,
  `z_gd` varchar(255) NOT NULL,
  `f_gd` varchar(255) NOT NULL,
  `z_num` int(50) NOT NULL,
  `f_num` int(50) NOT NULL,
  `beijing` mediumtext NOT NULL,
  `state` int(10) NOT NULL DEFAULT '0',
  `time` int(10) NOT NULL,
  `hot` int(10) NOT NULL,
  `jz` int(10) NOT NULL,
  `displayorder` int(10) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_huati_cy` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(20) NOT NULL,
  `htid` int(20) NOT NULL,
  `val` int(10) NOT NULL default '0',
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_huati_pl` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(20) NOT NULL,
  `usname` varchar(20) NOT NULL,
  `htid` int(20) NOT NULL,
  `pl` varchar(255) NOT NULL default '0',
  `zan` int(20) NOT NULL,
  `state` int(10) NOT NULL,
  `time` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;
EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_huati/discuz_plugin_keke_huati.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_huati/discuz_plugin_keke_huati_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_huati/discuz_plugin_keke_huati_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_huati/discuz_plugin_keke_huati_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_huati/discuz_plugin_keke_huati_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_huati/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_huati/upgrade.php');