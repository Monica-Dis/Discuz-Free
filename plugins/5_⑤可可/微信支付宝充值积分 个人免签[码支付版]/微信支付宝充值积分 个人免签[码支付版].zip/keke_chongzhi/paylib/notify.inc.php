<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
global $_G;
loadcache('plugin');
require_once("alipay/alipay.config.php");
require_once("alipay/alipay_notify.class.php");
require_once DISCUZ_ROOT."source/plugin/keke_chongzhi/common.php";	

$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {
	$out_trade_no = $_POST['out_trade_no'];
	$trade_no = $_POST['trade_no'];
	$trade_status = $_POST['trade_status'];
    if($_POST['trade_status'] == 'TRADE_FINISHED' || $_POST['trade_status'] == 'TRADE_SUCCESS') {
		_upuserdata($out_trade_no,$trade_no);
    }
	//echo "success";
}
else {
   // echo "fail";
}

ksort($_POST); //排序post参数
reset($_POST); //内部指针指向数组中的第一个元素
loadcache("plugin");
$codepay_key = $_G["cache"]["plugin"]["keke_group"]["codepay_key"]; //这是您的通信密钥
$sign = '';//初始化
foreach ($_POST AS $key => $val) { //遍历POST参数
    if ($val == '' || $key == 'sign') continue; //跳过这些不签名
    if ($sign) $sign .= '&'; //第一个字符串签名不加& 其他加&连接起来参数
    $sign .= "$key=$val"; //拼接为url参数形式
}
if (!$_POST['pay_no'] || md5($sign . $codepay_key) != $_POST['sign']) { //不合法的数据
    exit('fail');  //返回失败 继续补单
} else { //合法的数据
    //业务处理
    $pay_id = $_POST['pay_id']; //需要充值的ID 或订单号 或用户名
    _upuserdata($pay_id,'');
    exit('success'); //返回成功 不要删除哦
}

?>