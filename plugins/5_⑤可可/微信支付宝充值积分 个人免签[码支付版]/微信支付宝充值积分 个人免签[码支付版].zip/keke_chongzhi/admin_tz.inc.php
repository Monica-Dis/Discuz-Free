<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$table = array();
	showtips(lang('plugin/keke_chongzhi', 'lang33'));
    showtableheader(lang('plugin/keke_chongzhi', 'lang35'));	
    showsubtitle(array(lang('plugin/keke_chongzhi', 'lang36'),'', lang('plugin/keke_chongzhi', 'lang37'), lang('plugin/keke_chongzhi', 'lang38')));
	$wap=file_exists("source/plugin/keke_sms/sendsms.php")? '<span class="diffcolor2">'.lang('plugin/keke_chongzhi', 'lang39').'</span>' : '<a href="https://dism.taobao.com/?@keke_sms.plugin"><span class="error">'.lang('plugin/keke_chongzhi', 'lang40').'</span></a>';
	$table[0] = '<img src="https://open.dismall.com/resource/plugin/keke_sms.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_chongzhi', 'lang42');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_chongzhi', 'lang41').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
    /*Dism_taobao-com*/showtablefooter();
