<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$table1 = DB::table("keke_chongzhi_orderlog");
$table2 = DB::table("keke_chongzhi_credit");
$sql = <<<EOF
DROP TABLE IF EXISTS `$table1`;
DROP TABLE IF EXISTS `$table2`;

EOF;

runquery($sql);
$finish = true;