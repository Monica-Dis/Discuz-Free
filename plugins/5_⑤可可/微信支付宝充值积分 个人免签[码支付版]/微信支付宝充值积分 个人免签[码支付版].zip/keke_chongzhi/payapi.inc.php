<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
loadcache('plugin');
$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
header("Content-type:text/html;charset=utf-8");
if(!$_G['uid']){
	exit('Access Denied');
}
if($_GET['formhash'] != $_G['formhash']) {
	exit('Formhash Error');
}
include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/common.php";
loadcache('keke_chongzhi_credit');
$creditdata=$_G['cache']['keke_chongzhi_credit'] ? $_G['cache']['keke_chongzhi_credit'] : C::t('#keke_chongzhi#keke_chongzhi_credit')->fetchall_credit();
$zftype=intval($_GET['zftype']);
$credittype=intval($_GET['credittype']);
$moneyQuantity=floatval($_GET['moneyQuantity']);
$credit=intval($moneyQuantity*$creditdata[$credittype]['bili']);
$money=$moneyQuantity*100;
$retarr=_getcreditgive($credittype);
if($retarr[strval($moneyQuantity)]){
	$credit=$credit+$retarr[strval($moneyQuantity)];
}
$title= czgbk2utf(lang('plugin/keke_chongzhi', 'lang01'));

if($zftype==3){
	$_GET['cardid']=trim($_GET['cardid']);
	if(!$keke_chongzhi['cardid']){
		exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang52')))));
	}
	if(!$_GET['cardid']){
		exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang47')))));
	}
	if($keke_chongzhi['cardnum']){
		$todaycount=C::t('#keke_chongzhi#keke_chongzhi_card')->countall_today($_G['uid']);
		if($todaycount>=$keke_chongzhi['cardnum']){
			exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang57').$keke_chongzhi['cardnum'].lang('plugin/keke_chongzhi','lang58')))));
		}
	}
	$czcardarr = C::t('common_card')->fetch($_GET['cardid']);
	if(!$czcardarr){
		exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang48')))));
	}else{
		if($czcardarr['status'] == 2){
			exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang49')))));
		}
		if($czcardarr['cleardateline'] < TIMESTAMP) {
			exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang50')))));
		}
	}
	$money=$czcardarr['price']*100;
	$credittype=$czcardarr['extcreditskey'];
	$credit=$czcardarr['extcreditsval'];
}else{
	if(($keke_chongzhi['zuidi']>$moneyQuantity)){
		$msg=lang('plugin/keke_chongzhi', 'lang02').floatval($keke_chongzhi['zuidi']).lang('plugin/keke_chongzhi', 'lang03');
		$msgs=diconv($msg, CHARSET,'utf-8');
		if($zftype==1){
			echo '<script>alert("'.$msg.'");window.history.go(-1);</script>';
		}else{
			echo json_encode(array('err' =>$msgs));
		}
		exit();
	}
}

$orderid=_orderid();_instorder($orderid,$money,$zftype,$credit,$credittype);
if($zftype==1){
	//--------------------------------------------------------------------------�Խ���֧�����ֿ�ʼ
	loadcache("plugin");
	$codepay_id = $_G["cache"]["plugin"]["keke_chongzhi"]["codepay_id"];//����ĳ���֧��ID
    $codepay_key = $_G["cache"]["plugin"]["keke_chongzhi"]["codepay_key"]; //��������ͨ����Կ

    $data = array(
        "id" => $codepay_id,//�����֧��ID
        "pay_id" => $orderid, //Ψһ��ʶ �������û�ID,�û���,session_id(),����ID,ip ����󷵻�
        "type" => 1,//1֧����֧�� 3΢��֧�� 2QQǮ��
        "price" => $money/100,//���100Ԫ
        "param" => "",//�Զ������
        "notify_url"=>$_G['siteurl'].'source/plugin/keke_chongzhi/paylib/notify.inc.php',//֪ͨ��ַ
        "return_url"=>$_G['siteurl']."home.php?mod=spacecp&ac=credit&op=log",//��ת��ַ
    ); //������Ҫ���ݵĲ���

    ksort($data); //��������$data����
    reset($data); //�ڲ�ָ��ָ�������еĵ�һ��Ԫ��

    $sign = ''; //��ʼ����Ҫǩ�����ַ�Ϊ��
    $urls = ''; //��ʼ��URL����Ϊ��

    foreach ($data AS $key => $val) { //������Ҫ���ݵĲ���
        if ($val == ''||$key == 'sign') continue; //������Щ������ǩ��
        if ($sign != '') { //����׷��&ƴ��URL
            $sign .= "&";
            $urls .= "&";
        }
        $sign .= "$key=$val"; //ƴ��Ϊurl������ʽ
        $urls .= "$key=" . urlencode($val); //ƴ��Ϊurl������ʽ��URL�������ֵ

    }
    $query = $urls . '&sign=' . md5($sign .$codepay_key); //������������Ĳ���
    $url = "https://api.xiuxiu888.com/creat_order/?{$query}"; //֧��ҳ��

    header("Location:{$url}"); //��ת��֧��ҳ��
	//--------------------------------------------------------------------------�Խ���֧�����ֽ���
	require_once("source/plugin/keke_chongzhi/paylib/alipay/alipay.config.php");
	require_once("source/plugin/keke_chongzhi/paylib/alipay/alipay_submit.class.php");
	$out_trade_no = $orderid;
	$subject = $title;
	$total_fee = $moneyQuantity;
	$show_url = "plugin.php?id=keke_chongzhi";
	$parameter = array(
		"service"       => $alipay_config['service'],
		"partner"       => $alipay_config['partner'],
		"seller_id"  => $alipay_config['seller_id'],
		"payment_type"	=> $alipay_config['payment_type'],
		"notify_url"	=> $alipay_config['notify_url'],
		"return_url"	=> $alipay_config['return_url'],
		"_input_charset"	=> trim(strtolower($alipay_config['input_charset'])),
		"out_trade_no"	=> $out_trade_no,
		"subject"	=> $subject,
		"total_fee"	=> $total_fee,
		"show_url"	=> $show_url,
		"app_pay"   => "Y",
	);
	$alipaypaymethod= unserialize($keke_chongzhi['alipaypaymethod']);
	if($alipaypaymethod[0]!=1){
		$divide=checkmobile()?',':'^';
		$method=implode($divide,$alipaypaymethod);
		if(checkmobile()){
			$method=str_ireplace(array("directPay","cartoon"),array("balance","creditCardCartoon"),$method);
		}
		$parameter['enable_paymethod']=$method;
	}
	$alipaySubmit = new AlipaySubmit($alipay_config);
	$html_text = $alipaySubmit->buildRequestForm($parameter,"get", lang('plugin/keke_chongzhi', 'lang05'));
	echo $html_text;
}elseif($zftype==2){
	include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/inc.php";	
	$tools = new JsApiPay();
	$openIds = $_G['cookie'][$uskey];
	$openId=authcode($openIds, 'DECODE', $_G['config']['security']['authkey']);
	$notify = new NativePay();
	$input = new WxPayUnifiedOrder();
	$input->SetBody($title);
	$input->SetAttach($title);
	$input->SetOut_trade_no($orderid);
	$input->SetTotal_fee($money);
	$input->SetTime_start(date("YmdHis"));
	$input->SetGoods_tag($title);
	$input->SetNotify_url($_G['siteurl'].'source/plugin/keke_chongzhi/paylib/notify_wx.inc.php');
	$input->SetTrade_type($s_type);
	if($iswx){
		$input->SetOpenid($openId);
		$order = WxPayApi::unifiedOrder($input);
		$jsApiParameters = $tools->GetJsApiParameters($order);
		try
        {
            $jsApiParameters = $tools->GetJsApiParameters($order);
        }catch (Exception $e){
            $jsApiParameters = json_encode(array('err' => $e->getMessage()));
            $jsApiParameters = diconv($jsApiParameters, 'utf-8');
        }
        echo $jsApiParameters;
        exit;
	}else{
		if(checkmobile() && $keke_chongzhi['h5']){
			$h5pay=_h5pay($money,$orderid,$title);
			echo json_encode(array('h5payurl' => $h5pay['mweb_url'],'ewmurl' => '','orderid'=>$orderid));
		}else{
			$input->SetProduct_id($orderid);
			$result = $notify->GetPayUrl($input);
			$url2 = $result["code_url"];
			if($url2){
				$src = _getqrcodeurl($url2);
				echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
			}else{
				$err = $result['return_msg'];
				echo json_encode(array('err' => $err));
			}
		}
	}
}elseif($zftype==3){
	C::t('common_card')->update($czcardarr['id'], array('status' => 2, 'uid' => $_G['uid'], 'useddateline' => TIMESTAMP));
	_upuserdata($orderid,lang('plugin/keke_chongzhi', 'lang53').$_GET['cardid']);
	$creditname=$_G['setting']['extcredits'][$czcardarr['extcreditskey']]['title'];
	exit(json_encode(array('cardok' => compelutf(lang('plugin/keke_chongzhi', 'lang51').$czcardarr['extcreditsval'].$creditname))));
}