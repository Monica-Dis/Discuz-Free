<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
	include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/common.php";
	$url=$_G['siteurl'].'plugin.php?id=keke_chongzhi';
	$src = 'source/plugin/keke_chongzhi/paylib/wechat/example/qrcode.php?data='.urlencode($url);
    showtableheader(lang('plugin/keke_chongzhi', 'lang25'));
	echo '<tr class="hover"><td>'.$url.'</td></tr>';
	showtableheader(lang('plugin/keke_chongzhi', 'lang26'));
	echo '<tr class="hover"><td><img src="'.$src.'" width="250" /></td></tr>';
    /*Dism_taobao-com*/showtablefooter();