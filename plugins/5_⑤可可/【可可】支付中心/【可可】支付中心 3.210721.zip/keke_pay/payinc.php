<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class keke_pay{
    private $Var;
    public function __construct(){
        global $_G;
        loadcache('plugin');
        $this->Var['Set'] = $_G['cache']['plugin']['keke_pay'];
        $this->Var['authkey']=$_G['config']['security']['authkey'];
        $this->Var['siteurl']=$_G['siteurl'];
        $this->Var['uid']=$_G['uid'];
        $this->Var['authkey']=$_G['config']['security']['authkey'];
    }
    public function keke_dopay($paytype,$orderid,$money,$title){
        $this->Var['PayType']=$paytype;
        $this->Var['orderid']=$orderid;
        $this->Var['money']=$money;
        $this->Var['title']=$title;
        switch ($this->Var['PayType']){
            case 1:
                $this->AliPay();
                break;
            case 5:
                $this->MagPayTrade();
                break;
            case 6:
                $this->qianFanPay();
                break;
            default:
                $this->WechatPay();
                break;
        }
    }
    public function MagPayTrade(){
        if($this->Var['money']>0){
            $magCallbackSign=md5($this->Var['Set']['magsecret'].$this->Var['orderid'].$this->Var['authkey']);
            $callbackUrl=$this->Var['siteurl'].'source/plugin/'.CURMODULE.'/paylib/notify_mag.inc.php?out_trade_no='.$this->Var['orderid'].'&sign='.$magCallbackSign;
            $url='http://'.$this->Var['Set']['magurl'].'/core/pay/pay/unifiedOrder?trade_no='.$this->Var['orderid'].'&callback='.urlencode($callbackUrl).'&amount='.$this->Var['money'].'&title='.$this->Var['title'].'&user_id='.$this->Var['uid'].'&to_user_id=&des='.$this->Var['title'].'&remark='.$this->Var['title'].'&secret='.$this->Var['Set']['magsecret'];
            $data = dfsockopen($url);
            if(!$data) {
                $data = file_get_contents($url);
            }
            $return=json_decode($data,true);
            if($return['success'] == true){
                $return['data']['trade_no'] = $this->Var['orderid'];
                $return['data']['title'] = $this->Var['title'];
                $return['data']['money'] = $this->Var['money'];
            }
        }else{
            $return['data']['trade_no'] = $this->Var['orderid'];
            $return['data']['money'] = $this->Var['money'];
        }
        return json_encode($return);
    }
    public function qianFanPay(){
        $return=array(
            'title'=>$this->Var['title'],
            'orderid'=>$this->Var['orderid'],
            'total_price'=>$this->Var['money']
        );
        return json_encode($return);
    }
    public function AliPay(){
        if($this->Var['Set']['alipaytype']==3) {
            $this->PayjsdoPay(1);
        }else{
            require_once("source/plugin/keke_pay/paylib/alipay/alipay.config.php");
            $alipay_config['notify_url'] = $this->Var['siteurl'].'source/plugin/'.CURMODULE.'/paylib/notify_ali.inc.php';
            $alipay_config['return_url'] = $this->Var['siteurl'].'source/plugin/'.CURMODULE.'/paylib/return_ali.inc.php';
            if(strlen(ALIPUBKEY)==32 && $this->Var['Set']['alipaytype']==1) {
                if(!$_GET['jump']){
                    exit(json_encode(array('payjump' => 1)));
                }
                require_once("source/plugin/keke_chongzhi/paylib/alipay/alipay_submit.class.php");
                $parameter = array(
                    "service" => $alipay_config['service'],
                    "partner" => $alipay_config['partner'],
                    "seller_id" => $alipay_config['seller_id'],
                    "payment_type" => $alipay_config['payment_type'],
                    "notify_url" => $alipay_config['notify_url'],
                    "return_url" => $alipay_config['return_url'],
                    "_input_charset" => trim(strtolower($alipay_config['input_charset'])),
                    "out_trade_no" => $this->Var['orderid'],
                    "subject" => $this->Var['title'],
                    "total_fee" => $this->Var['money'],
                    "show_url" => $this->Var['siteurl'],
                    "app_pay" => "Y",
                );
                $alipaySubmit = new AlipaySubmit($alipay_config);
                $sHtml = $alipaySubmit->buildRequestForm($parameter, "get", 'gopay');
            }else{
                $paytype=checkmobile()?'wap':'native';
                if($this->Var['Set']['alipaytype']==2) $paytype='trade';
                require_once("source/plugin/keke_pay/paylib/alipay/alipay_".$paytype.".php");
                $aliPay = new AlipayService();
                $aliPay->setAppid(ALIAPPID);
                $aliPay->setReturnUrl($alipay_config['return_url']);
                $aliPay->setNotifyUrl($alipay_config['notify_url']);
                $aliPay->setRsaPrivateKey(ALIPRKEY);
                $aliPay->setTotalFee($this->Var['money']);
                $aliPay->setOutTradeNo($this->Var['orderid']);
                $aliPay->setOrderName($this->Var['title']);
                $sHtml = $aliPay->doPay();
                if($this->Var['Set']['alipaytype']==2){
                    $result = $sHtml['alipay_trade_precreate_response'];
                    if($result['code'] && $result['code']=='10000'){
                        $src = $this->keke_pay_qrcode($result['qr_code']);
                        if(checkmobile()){
                            exit(json_encode(array('h5payurl' => $result['qr_code'],'orderid'=>$this->Var['orderid'])));
                        }
                        exit(json_encode(array('ewmurl' => $src,'orderid'=>$this->Var['orderid'])));
                    }else{
                        exit(json_encode(array('err' => ($result['msg'].' : '.$result['sub_msg']))));
                    }
                }
                if(!$_GET['jump'])exit(json_encode(array('payjump' => 1)));
            }
            exit($sHtml);
        }
    }

    public function WechatPay(){
        $money=intval($this->Var['money']*100);
        $notifyuri=$this->Var['siteurl'].'source/plugin/'.CURMODULE.'/paylib/notify_wx.inc.php';
        if($this->Var['Set']['wechattype']==2){
            $this->PayjsdoPay(2);
        }
        @include_once DISCUZ_ROOT."source/plugin/keke_pay/paylib/wechat/inc.php";
        $tools = new JsApiPay();
        $openIds = getcookie($this->Getuserkey());
        $openId=authcode($openIds, 'DECODE', $this->Var['authkey']);
        $notify = new NativePay();
        $input = new WxPayUnifiedOrder();
        $input->SetBody($this->Var['title']);
        $input->SetAttach($this->Var['title']);
        $input->SetOut_trade_no($this->Var['orderid']);
        $input->SetTotal_fee($money);
        $input->SetTime_start(date("YmdHis"));
        $input->SetGoods_tag($this->Var['title']);
        $input->SetNotify_url($notifyuri);
        $input->SetTrade_type($this->SetWechatPay());
        if($this->CheckInWechat()){
            $input->SetOpenid($openId);
            $order = WxPayApi::unifiedOrder($input);
            try
            {
                $jsApiParameters = $tools->GetJsApiParameters($order);
            }catch (Exception $e){
                $jsApiParameters = json_encode(array('err' => $e->getMessage()));
                $jsApiParameters = diconv($jsApiParameters, 'utf-8');
            }
            exit($jsApiParameters);
        }else{
            if($this->Var['Set']['wxh5'] && checkmobile()){
                $wxPay = new WxpayService();
                $wxPay->setTotalFee($money);
                $wxPay->setOutTradeNo($this->Var['orderid']);
                $wxPay->setOrderName($this->Var['title']);
                $wxPay->setNotifyUrl($notifyuri);
                $mwebUrl= $wxPay->createJsBizPackage();
                exit(json_encode(array('h5payurl' => $mwebUrl)));
            }
            $input->SetProduct_id($this->Var['orderid']);
            $result = $notify->GetPayUrl($input);
            $url2 = $result["code_url"];
            if($url2){
                $src = $this->keke_pay_qrcode($url2);
                exit(json_encode(array('ewmurl' =>$src,'orderid'=>$this->Var['orderid'])));
            }else{
                $err = $result['return_msg'];
                exit(json_encode(array('err' => $err)));
            }
        }
    }

    public function PayjsdoPay($zftype){
        $money=intval($this->Var['money']*100);
        $notifyuri=$this->Var['siteurl'].'source/plugin/'.CURMODULE.'/paylib/notify_wx.inc.php';
        @include_once DISCUZ_ROOT."source/plugin/keke_pay/paylib/order/payjs.class.php";
        $payjs=new payjs;
        $data= array(
            'mchid'        => trim($this->Var['Set']['thirdmchid']),
            'total_fee'    => $money,
            'body'         => $this->Var['title'],
            'out_trade_no' => $this->Var['orderid'],
            'notify_url'   => $notifyuri,
        );
        if($zftype==1)$data['type'] = 'alipay';
        if(checkmobile() && $zftype==2){
            $data['callback_url']=$this->Var['siteurl'].'source/plugin/'.CURMODULE.'/paylib/return_ali.inc.php?out_trade_no='.$this->Var['orderid'];
            $data['sign'] = $payjs->PayjsSign($data);
            $url = 'https://payjs.cn/api/cashier?' . http_build_query($data);
            if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
                exit(json_encode(array('h5payurl' => $url)));
            }else{
                $src = $this->keke_pay_qrcode($url);
                exit(json_encode(array('ewmurl' => $src,'orderid'=>$this->Var['orderid'])));
            }
        }
        $data['ip'] = $_SERVER['REMOTE_ADDR'];
        $data['sign'] = $payjs->PayjsSign($data);
        $result = $payjs->PayjsHttpPost($data,'https://payjs.cn/api/native');
        $ret=json_decode($result, true);
        if($ret['return_msg']!='SUCCESS'){
            exit(json_encode(array('err' => $ret['return_msg'])));
        }
        $src = $this->keke_pay_qrcode($ret['code_url']);
        exit(json_encode(array('ewmurl' => $src,'orderid'=>$this->Var['orderid'])));
    }

    public function GetOpenid(){
        if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && $this->Var['Set']['wxshkey'] && $this->Var['Set']['wechattype']==1){
            include_once DISCUZ_ROOT.'source/plugin/keke_pay/paylib/wechat/inc.php';
            $tools = new JsApiPay();
            $openId = $tools->GetOpenid();
            dsetcookie($this->Getuserkey(), authcode($openId, 'ENCODE', $this->Var['authkey']), 8640000);
        }
        return $openId;
    }

    public function keke_pay_qrcode($data){
        return 'source/plugin/keke_pay/phpqrcode/qrcode.php?data='.dhtmlspecialchars(urlencode($data));
    }

    public function Getuserkey(){
        return substr(md5('keke_pay'.$this->Var['siteurl']['siteurl']), 0, 7);
    }

    public function CheckInWechat(){
        return strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false;
    }

    public function SetWechatPay(){
        return $this->CheckInWechat()?"JSAPI" : "NATIVE";
    }
}

class keke_notify{
    private $VAR;
    public function __construct(){
        global $_G;
        loadcache('plugin');
        $this->VAR['set'] = $_G['cache']['plugin']['keke_pay'];
        $this->Var['authkey']=$_G['config']['security']['authkey'];
    }
    public function CheckWechatNotify(){
        $ret=false;
        if($this->VAR['set']['wechattype']==2){
            $ret=$this->CheckPayjsNotify();
            $returnValues=$_GET;
        }else{
            $returnValues = WxPayApi::notify($msg);
            if(empty($returnValues)){
                $return = array('return_code'=>'FAIL','return_msg'=>$msg);
                WxPayApi::replyNotify($this->arrtoxml($return));
                exit();
            }
            $chcksign = WxPayDataBase::CheckSigns($returnValues);
            if(!$chcksign){
                $return = array('return_code'=>'FAIL','return_msg'=>'signerr');
                WxPayApi::replyNotify($this->arrtoxml($return));
                exit();
            }
            if(!empty($returnValues['result_code']) && $returnValues['result_code'] == 'SUCCESS'){
                $ret=true;
                WxPayApi::replyNotify($this->arrtoxml(array('return_code'=>'SUCCESS','return_msg'=> 'OK')));
            }
        }
        return array($ret,$returnValues);
    }

    public function arrtoxml($data){
        $xml = "<xml>";
        foreach ($data as $key=>$val){
            if (is_numeric($val)){
                $xml.="<".$key.">".$val."</".$key.">";
            }else{
                $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
            }
        }
        $xml.="</xml>";
        return $xml;
    }

    public function CheckMagAppNotify(){
        $MD5sign = md5($this->VAR['set']['magsecret'].$_GET['out_trade_no'].$this->Var['authkey']);
        if($_GET['sign'] == $MD5sign){
            return true;
        }
        return false;
    }

    public function checkMagAppState(){
        $url = 'http://'.$this->VAR['set']['magurl'].'/core/pay/pay/orderStatusQuery?unionOrderNum='.$_GET['unionordernum'].'&secret='.$this->VAR['set']['magsecret'];
        $data = dfsockopen($url);
        if(!$data){
            $data = file_get_contents($url);
        }
        $return= json_decode($data,true);
        if($return['paycode'] == 1){return true;
        }
        return false;
    }

    public function checkQianFanState(){
        require_once DISCUZ_ROOT . './source/plugin/keke_pay/class/qianfan.class.php';
        $client = new QF_HTTP_CLIENT($this->VAR['set']['qfhostname'],$this->VAR['set']['qftoken']);
        $pay_data = $client->get('payments/'.$_GET['sn']);
        if($pay_data['data']['pay'] == 1){
            return true;
        }
        return false;
    }

    public function CheckAlipayNotify(){
        if($this->VAR['set']['alipaytype']==3){
            $result=$this->CheckPayjsNotify();
            $_POST['trade_no']=$_GET['payjs_order_id'];
        }else {
            @require_once DISCUZ_ROOT . "source/plugin/keke_pay/paylib/alipay/alipay.config.php";
            if (strlen(ALIPUBKEY) == 32) {
                @require_once DISCUZ_ROOT . "source/plugin/keke_pay/paylib/alipay/alipay_notify.class.php";
                $result = false;
                $alipayNotify = new AlipayNotify($alipay_config);
                $verify_result = $alipayNotify->verifyNotify();
                if ($verify_result && ($_POST['trade_status'] == 'TRADE_FINISHED' || $_POST['trade_status'] == 'TRADE_SUCCESS')) {
                    $result = true;
                }
            } else {
                @require_once DISCUZ_ROOT . "source/plugin/keke_pay/paylib/alipay/alipay_notify.php";
                $aliPay = new AlipayService;
                $result = $aliPay->rsaCheck($_POST);
            }
        }
        return $result;
    }

    public function CheckPayjsNotify(){
        @include_once DISCUZ_ROOT."source/plugin/keke_pay/paylib/order/payjs.class.php";
        $payjs=new payjs;
        return $payjs->PayjsCheckSign($_POST);

    }
}