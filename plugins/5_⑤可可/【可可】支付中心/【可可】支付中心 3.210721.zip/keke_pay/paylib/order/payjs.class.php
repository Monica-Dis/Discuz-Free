<?php


class payjs
{
    private $VAR;
    public function __construct()
    {
        loadcache('plugin');
        global $_G;
        $this->VAR['set']=$_G['cache']['plugin']['keke_pay'];
        $this->VAR['confg']['mchid']=trim($this->VAR['set']['thirdmchid']);
        $this->VAR['confg']['key']=trim($this->VAR['set']['thirdkey']);
    }

    public function PayjsHttpPost($data, $url) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        $rst = curl_exec($ch);
        curl_close($ch);
        return $rst;
    }

    public function PayjsSign($arr){
        array_filter($arr);
        ksort($arr);
        $sign = strtoupper(md5(urldecode(http_build_query($arr) . '&key=' . $this->VAR['confg']['key'])));
        return $sign;
    }

    public function PayjsCheckSign($arr){
        $user_sign = $arr['sign'];
        unset($arr['sign']);
        array_filter($arr);
        ksort($arr);
        $check_sign = strtoupper(md5(urldecode(http_build_query($arr) . '&key=' . $this->VAR['confg']['key'])));
        if ($user_sign != $check_sign){
            die('Signature Error');
        }
        return true;
    }

}