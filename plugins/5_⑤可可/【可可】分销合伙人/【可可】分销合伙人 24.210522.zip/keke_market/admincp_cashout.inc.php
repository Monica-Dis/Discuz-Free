<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	include_once DISCUZ_ROOT."source/plugin/keke_market/function.php";
	if (submitcheck("forumset")) {
		if($_GET['ids']) {
			C::t('#keke_market#keke_market_order')->delete($_GET['ids']);
		}
		cpmsg(lang('plugin/keke_market', '002'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_cashout', 'succeed');
	}
	if ($_GET['optype']) {
		if($_GET['formhash']!=FORMHASH){
			exit('Formhash Error');
		}
		$cashid=intval($_GET['cashids']);
		$arr=array();
		if($_GET['optype']=='pass'){
			$arr['state']=1;
		}elseif($_GET['optype']=='ref'){
			$arr['state']=2;
			$cash_data=C::t('#keke_market#keke_market_order')->fetchfirst_byid($cashid);
			$memberdata=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($cash_data['uid']);
			C::t('#keke_market#keke_market_member')->update($cash_data['uid'],array('money'=>$memberdata['money']+$cash_data['money']));
			C::t('#keke_market#keke_market_order')->insert(array(
				'uid'=>$cash_data['uid'],
				'molds'=>1,
				'time'=>TIMESTAMP,
				'orderid'=>'999999',
				'money'=>$cash_data['money'],
				'balance'=>$memberdata['money']+$cash_data['money']
			));
		}
		C::t('#keke_market#keke_market_order')->update($cashid,$arr);
		cpmsg(lang('plugin/keke_market', '002'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_cashout&page='.intval($_GET['page']), 'succeed');
	}
	

	$where='1';$param='';
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_cashout");	
	showtableheader(lang('plugin/keke_market', '002'));
    showsubtitle(array('del',lang('plugin/keke_market', '006'),lang('plugin/keke_market', '012'),lang('plugin/keke_market', '013'),lang('plugin/keke_market', '014'),lang('plugin/keke_market', '015'),lang('plugin/keke_market', '016')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_cashout'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$where.=' AND molds=2';
	if($allcount = C::t('#keke_market#keke_market_order')->count_all($where)){
		$cash_data=C::t('#keke_market#keke_market_order')->fetch_alls($startlimit,$ppp,$where,$order);
		foreach($cash_data as $k=>$v){
			$uids[$v['uid']]=$v['uid'];			
		}
		$userdata=C::t('#keke_market#keke_market_member')->fetchall_username($uids);
		$memberdata=C::t('#keke_market#keke_market_member')->fetchall_byuids($uids);
		foreach($cash_data as $key=>$val){
			$op=!$val['state']?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_cashout&optype=pass&cashids='.$val['id'].'&page='.intval($_GET['page']).'&formhash='.FORMHASH.'" onClick="return confirm( \''.lang('plugin/keke_market', '017').'\');">'.lang('plugin/keke_market', '018').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_cashout&optype=ref&cashids='.$val['id'].'&page='.intval($_GET['page']).'&formhash='.FORMHASH.'"  onClick="return confirm( \''.lang('plugin/keke_market', '019').'\');">'.lang('plugin/keke_market', '020').'</a>':lang('plugin/keke_market', '021');
            if($memberdata[$val['uid']]['wxqr'] && $val['cardtype']==1){
                $account= ' <div class="qrcodebox"><a href="'.$memberdata[$val['uid']]['wxqr'].'" target="_blank"><img style="vertical-align:middle; margin:0 5px; border-radius: 3px;" src="source/plugin/keke_wallet/template/images/ico03.png" width="15" height="15" class="zoom" onmouseover="$(\'icon'.$val['id'].'\').style.display=\'block\'" onmouseout="$(\'icon'.$val['id'].'\').style.display=\'none\'"></a> <div class="qrcodesubbox" id="icon'.$val['id'].'"><img src="'.$memberdata[$val['uid']]['wxqr'].'"></div></div>';
            }
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="ids[]" value="'.$val['id'].'" />';
			$table[1] = '<a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'.$userdata[$val['uid']]['username'].'</a>';
			$table[2] = $val['cardtype']==1?lang('plugin/keke_market', '022').' <span class="sl">|</span> '.$memberdata[$val['uid']]['wechatpay'].$account:($val['cardtype']==3?lang('plugin/keke_market', '102'):lang('plugin/keke_market', '023').' <span class="sl">|</span> '.$memberdata[$val['uid']]['alipay']);
			$table[3] = '&yen;'.$val['money'];
			$table[4] = dgmdate($val['time'], 'Y/m/d H:i:s');
			$table[5] = $val['state']==1?lang('plugin/keke_market', '024'):($val['state']==2?lang('plugin/keke_market', '025'):lang('plugin/keke_market', '026').($val['msg']?'<span class="sl"> '.$val['msg'].'</span>':''));
			$table[6] = $op;
			showtablerow('',array(''), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
    echo '<style>.ds{color: #ccc;margin: 0px 5px;}.jj{color: #c30;}.zc{color: #3fd411;}.sl{color: #ccc;margin: 0px 5px;}.psty{color:#999;line-height:25px} .card_number{margin-left:10px; line-height:25px; color:#586c94}.qrcodebox{ display:inline-block; position:relative;}.qrcodesubbox{position:absolute;z-index:999;border:1px solid #eee;left:0; top:25px; display:none}</style>';
	showsubmit('forumset', 'submit', 'del','');
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dism��taobao��com*/