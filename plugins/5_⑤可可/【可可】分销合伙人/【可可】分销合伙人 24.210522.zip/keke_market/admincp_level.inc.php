<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
require_once libfile('function/cache');
if (submitcheck("forumset")) {
	if(is_array($_GET['ids'])) {
			$defaultdata=C::t('#keke_market#keke_market_level')->fetchfirst_default();
			foreach($_GET['ids'] as $ids){
				if($ids == $defaultdata['id']){
					cpmsg(lang('plugin/keke_market', '027'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_level', 'error');
				}
			}
			C::t('#keke_market#keke_market_level')->delete($_GET['ids']);
			savecache('keke_market_level', C::t('#keke_market#keke_market_level')->fetch_all());
	}else{
		cpmsg(lang('plugin/keke_market', '001'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_level', 'error');
	}

	cpmsg(lang('plugin/keke_market', '002'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_level', 'succeed');
}

if($_GET['ac']=='edit'){
	$levelid=intval($_GET['levelid']);
	$level=C::t('#keke_market#keke_market_level')->fetchfirst_byid($levelid);
	if (submitcheck("editsubmit")) {
		if($_GET['defaults']){
			C::t('#keke_market#keke_market_level')->updete_default();
		}
		$arr=array(
			'name' => $_GET['name'],
			'one' => $_GET['one'],
			'sec' => $_GET['sec'],
			'defaults' =>  $_GET['defaults'],
		);
		if($levelid){
			$arr['id']=$levelid;
		}
		C::t('#keke_market#keke_market_level')->insert($arr,true,true);
		savecache('keke_market_level', C::t('#keke_market#keke_market_level')->fetch_all());
		cpmsg(lang('plugin/keke_market', '002'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_level', 'succeed');
	}
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_level&ac=edit", 'enctype');
	showtableheader(lang('plugin/keke_market', '028'));
	showsetting(lang('plugin/keke_market', '029'),'name',$level['name'],'text');
	showsetting(lang('plugin/keke_market', '030'),'one',$level['one'],'text');
	showsetting(lang('plugin/keke_market', '031'),'sec',$level['sec'],'text');
	showsetting(lang('plugin/keke_market', '032'),'defaults',$level['defaults']);
	echo '<input name="levelid" type="hidden" value="'.$levelid.'" />';
	showsubmit('editsubmit', 'submit', '');
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dism��taobao��com*/
	exit;
	
}
showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_level");	
showtableheader(lang('plugin/keke_market', '033'));
showsubtitle(array('del', lang('plugin/keke_market', '029'),lang('plugin/keke_market', '030'),lang('plugin/keke_market', '031'),lang('plugin/keke_market', '032'),lang('plugin/keke_market', '016')));
loadcache('keke_market_level');
$level_data = $_G['cache']['keke_market_level']?$_G['cache']['keke_market_level']:C::t('#keke_market#keke_market_level')->fetch_all();
if($level_data){
	foreach($level_data as $key=>$val){
		$table = array();
		$table[0] = '<input type="checkbox" class="checkbox" name="ids[]" value="'.$val['id'].'" />';
		$table[1] = $val['name'];
		$table[2] = $val['one'].'%';
		$table[3] = $val['sec'].'%';
		$table[4] = ($val['defaults']?lang('plugin/keke_market', '034'):'');
		$table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_level&ac=edit&levelid='.$val['id'].'">'.lang('plugin/keke_market', '035').'</a>';
		showtablerow('',array(''), $table);
	}
}
showsubmit('forumset', 'submit', 'del','&nbsp;&nbsp;&nbsp;&nbsp;<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_level&ac=edit" class="addtr">'.lang('plugin/keke_market', '036').'</a>');
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
showformfooter(); /*dism��taobao��com*/