<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_market_member extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_market_member';
		$this->_pk    = 'uid';

		parent::__construct(); /*dism_ taobao _com*/
	}
	

	public function fetchfirst_byuid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table,$uid));
	}
	
	public function fetchall_byuid($uids) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d", array($this->_table,$uids),$this->_pk);
	}
	
	public function fetchall_username($uids) {
		return  DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
	}
	
	
	public function fetchall_byuids($uids) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid IN (%n)", array($this->_table,$uids),$this->_pk);
	}
	
	
	public function fetch_alls($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by time desc';
		return DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp));
	}
	
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}

}