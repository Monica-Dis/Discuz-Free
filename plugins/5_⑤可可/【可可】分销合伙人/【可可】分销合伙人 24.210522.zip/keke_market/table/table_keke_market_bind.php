<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_market_bind extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_market_bind';
		$this->_pk    = 'id';

		parent::__construct(); /*dism_ taobao _com*/
	}
	
	
	public function fetchfirst_byid($oid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$oid));
	}
	
	public function fetchfirst_bysubuid($uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE subuid=%d", array($this->_table,$uid));
	}
	
	public function delete_by_uid($uid,$subuid) {
		return DB::query("delete FROM %t where uid=%d AND subuid=%d", array($this->_table,$uid,$subuid));
	}
	
	public function fetch_all_by_uid($uids) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d", array($this->_table,$uids));
	}
	
	public function fetch_all_by_subuiu($subuid) {
		return DB::fetch_all("SELECT * FROM %t WHERE subuid in (%n)", array($this->_table,$subuid));
	}

	
	 public function fetchall_subuid_by_uid($uid,$startlimit,$ppp){
		$ret=DB::fetch_all("SELECT a.uid,b.uid as directuid,b.subuid as subuid,b.bindtime as bindtime FROM %t as a inner join %t as b on a.subuid=b.uid WHERE %i %i LIMIT %d,%d", array($this->_table,$this->_table,'a.uid='.intval($uid),$orders,$startlimit,$ppp));
        return $this->analysis($ret);
    }
	
	
	 public function count_all_subuid_by_uid($uid){
		return DB::result_first("SELECT count(*) FROM %t as a inner join %t as b on a.subuid=b.uid WHERE %i", array($this->_table,$this->_table,'a.uid='.intval($uid)));
    }
	
	
	public function fetch_alls($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by id desc';
		$ret=DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp));
		return $this->analysis($ret);
	}
	
	
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}
	
	
	
	public function analysis($ret) {
		foreach($ret as $v){
			$uids[$v['uid']]=$v['uid'];
			$uids[$v['subuid']]=$v['subuid'];
		}
		$userdata=C::t('#keke_market#keke_market_member')->fetchall_username($uids);
		foreach($ret as $key=>$val){
			$ret[$key]['time']=dgmdate($val['bindtime'], 'u');
			$ret[$key]['username']=$userdata[$val['uid']]['username'];
			$ret[$key]['subusername']=$userdata[$val['subuid']]['username'];
		}
		return $ret;
	}
}