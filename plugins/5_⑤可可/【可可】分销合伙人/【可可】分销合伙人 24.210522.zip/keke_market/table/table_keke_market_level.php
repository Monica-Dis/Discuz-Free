<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_market_level extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_market_level';
		$this->_pk    = 'id';

		parent::__construct(); /*dism_ taobao _com*/
	}
	
	
	public function fetchfirst_byid($oid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$oid));
	}
	
	
	public function fetchfirst_default() {
		return DB::fetch_first("SELECT * FROM %t WHERE defaults=1", array($this->_table));
	}
	
	
	public function fetch_all() {
		return DB::fetch_all("SELECT * FROM %t order by id ASC", array($this->_table),$this->_pk);
	}
	
	public function updete_default() {
		return DB::query("UPDATE %t SET `defaults` = ''", array($this->_table));
	}
	
	
	public function fetch_alls($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by id desc';
		return DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp));
	}
	
	
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}
}