<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_market_order extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_market_order';
		$this->_pk    = 'id';

		parent::__construct(); /*dism_ taobao _com*/
	}
	
	
	public function fetchfirst_byid($oid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$oid));
	}
	
	public function fetch_all_order($orderid) {
		$orderdata=DB::fetch_all("SELECT * FROM %t WHERE id in (%n)", array('keke_video_order',$orderid));
		foreach($orderdata as $val){
			$cid=explode(',',$val['cid']);
			$cids[$val['id']]=$cid[0];
			$count[$val['id']]=count($cid);
			$buyuid[$val['id']]=$val['uid'];
		}
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
		$userdata=C::t('#keke_market#keke_market_member')->fetchall_username($buyuid);
		foreach($cids as $key=>$val){
			$rets[$key]='<a href="home.php?mod=space&uid='.$buyuid[$key].'" target="_blank">'.$userdata[$buyuid[$key]]['username'].'</a> '.lang('plugin/keke_market', '077').'  <span class="coursesname"> # '.$courses[$val]['title'].' # </span>  '.($count[$key]>1?' '.lang('plugin/keke_market', '078').$count[$key].lang('plugin/keke_market', '079'):lang('plugin/keke_market', '080'));
		}
		return $rets;
	}
	
	
	public function fetch_all_by_uid($uids) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d", array($this->_table,$uids));
	}
	
	public function fetch_alls($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by id desc';
		$ret= DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp));
		return $this->analysis($ret);
	}
	
	
	public function summoney_all_by_uid($uid) {
		return DB::result_first("SELECT sum(money) as summoney FROM %t WHERE molds=1 AND uid=%d", array($this->_table,$uid));
	}
	
	public function summoney_today_by_uid($uid) {
		$beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
		$endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
		return DB::result_first("SELECT sum(money) as summoney FROM %t WHERE molds=1 AND uid=%d AND time>%d AND time<%d", array($this->_table,$uid,$beginToday,$endToday));
	}
	
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}
	
	
	public function analysis($ret) {
        global $_G;
		foreach($ret as $v){
			$uids[$v['uid']]=$v['uid'];
			if($v['from']=='keke_group'){
				$grouporderids[$v['orderid']]=$v['orderid'];
			}else{
				$orderids[$v['orderid']]=$v['orderid'];
			}
		}
		$orderdata=array();
		$userdata=C::t('#keke_market#keke_market_member')->fetchall_username($uids);
		if($orderids && $_G['cache']['plugin']['keke_video_base']){
			$orderdata=C::t('#keke_market#keke_market_order')->fetch_all_order($orderids);
		}

		if($grouporderids && $_G['cache']['plugin']['keke_group']){
			$grouporderdata=DB::fetch_all("SELECT * FROM %t WHERE orderid in (%n)", array('keke_group_orderlog',$grouporderids));
			foreach($grouporderdata as $gk=>$gv){
				$orderdata[$gv['orderid']]='<a href="home.php?mod=space&uid='.$gv['uid'].'" target="_blank">'._market_getusname($gv['uid']).'</a> '.lang('plugin/keke_market', '077').'  <span class="coursesname"> # '.$gv['groupname'].' # </span>  ';
			}
		}
		foreach($ret as $key=>$val){
			$ret[$key]['times']=dgmdate($val['time'], 'u');
			$ret[$key]['username']=$userdata[$val['uid']]['username'];
			$ret[$key]['order']=$orderdata[$val['orderid']];
		}
		return $ret;
	}
}