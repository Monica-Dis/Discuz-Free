<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function binduser(){
	global $_G;
	$keke_market = $_G['cache']['plugin']['keke_market'];
	if($_GET['iuid']){
		dsetcookie('iuid', intval($_GET['iuid']), 604800);
        if($keke_market['condition']==5){
            dsetcookie('iuid-time', TIMESTAMP, 604800);
        }
		$iuid=intval($_GET['iuid']);
	}else{
		$iuid=getcookie('iuid');
	}
	
	if ($iuid && $_G['uid'] && $iuid!=$_G['uid']){
		$distributor=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($iuid);
		$checkbind=C::t('#keke_market#keke_market_bind')->count_all('uid='.intval($_G['uid'].' ADN subuid='.$iuid));
		if(!$checkbind && (($keke_market['run']==1 && $distributor) || $keke_market['run']==2)){
			$subordinate=C::t('#keke_market#keke_market_bind')->fetchfirst_bysubuid($_G['uid']); 
			$checkmember=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
			$keke_market['special']=empty($keke_market['special']) ? array() : unserialize($keke_market['special']);
            $regDate=0;
            if($keke_market['condition']==5){
                $regDate=$_G['member']['regdate'];
                if(!$regDate){
                    $userData=getuserbyuid($_G['uid']);
                    $regDate=$userData['regdate'];
                }
            }
			if($keke_market['condition']==1 || ($keke_market['condition']==2 && !$checkmember) || ($keke_market['condition']==3 && !$checkmember && !in_array($_G['groupid'],$keke_market['special'])) || ($keke_market['condition']==5 && $regDate>getcookie('iuid-time') && getcookie('iuid-time'))){
				if(!$subordinate){
					$subarr=array(
						'uid'=>$iuid,
						'subuid'=>$_G['uid'],
						'bindtime'=>TIMESTAMP,
					);
					C::t('#keke_market#keke_market_bind')->insert($subarr);
				}else{
					if($keke_market['bindmod']==2){
						C::t('#keke_market#keke_market_bind')->update($subordinate['id'],array('uid'=>$iuid,'bindtime'=>TIMESTAMP));
					}elseif($keke_market['bindmod']==3){
						if(($subordinate['bindtime']+$keke_market['protect']*86400)<TIMESTMP){
							C::t('#keke_market#keke_market_bind')->update($subordinate['id'],array('uid'=>$iuid,'bindtime'=>TIMESTAMP));
						}
					}
				}
			}
			if($keke_market['run']==2 && !$checkmember){
				$level_data = $_G['cache']['keke_market_level']?$_G['cache']['keke_market_level']:C::t('#keke_market#keke_market_level')->fetch_all();
				foreach($level_data as $key=>$val){
					if($val['defaults']){
						$dflevelid=$val['id'];
						break;
					}
				}
				$arr=array(
					'uid'=>$_G['uid'],
					'superior'=>$iuid,
					'time'=>TIMESTAMP,
					'state'=>1,
					'levelid'=>$dflevelid
				);
				C::t('#keke_market#keke_market_member')->insert($arr);
			}
		}
	}
}

function _getmarketupuid($uid){
	global $_G;
	$keke_market = $_G['cache']['plugin']['keke_market'];
	loadcache('keke_market_level');
	$level_data = $_G['cache']['keke_market_level']?$_G['cache']['keke_market_level']:(C::t('#keke_market#keke_market_level')->fetch_all());
	$binddata=C::t('#keke_market#keke_market_bind')->fetchfirst_bysubuid($uid);
	if($binddata['uid']){
		$market_member=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($binddata['uid']);
		$market_member['level_data']=$level_data[$market_member['levelid']];
		$market_upuid['level_one']=$market_member;
		if($keke_market['mod']==2){
			$upbinddata=C::t('#keke_market#keke_market_bind')->fetchfirst_bysubuid($binddata['uid']);
			if($upbinddata){
				$market_sub_member=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($upbinddata['uid']);
				$market_sub_member['level_data']=$level_data[$market_sub_member['levelid']];
				$market_upuid['level_sec']=$market_sub_member;
			}
		}
	}
	return $market_upuid;
}

function market_cach_log($uids,$orderid,$money,$from=''){
	global $_G;
	$keke_market = $_G['cache']['plugin']['keke_market'];
	$arr=$secarr=array(
		'amount'=>$money,
		'time'=>TIMESTAMP,
		'orderid'=>$orderid,
		'molds'=>1,
		'from'=>$from
	);
	$onepro=$uids['level_one']['level_data']['one'];
	$arr['uid']=$uids['level_one']['uid'];
	$arr['money']=$money*$onepro/100;
	$arr['type']=1;
	C::t('#keke_market#keke_market_order')->insert($arr);
	$updatearr=array(
		'money'=>$uids['level_one']['money']+$arr['money'],
		'totalmoney'=>$uids['level_one']['totalmoney']+$arr['money'],
	);
	C::t('#keke_market#keke_market_member')->update($uids['level_one']['uid'],$updatearr);
	if($keke_market['mod']==2 && $uids['level_sec']['uid']){
		$secpro=$uids['level_sec']['level_data']['sec'];
		$secarr['uid']=$uids['level_sec']['uid'];
		$secarr['money']=$money*$secpro/100;
		$secarr['type']=2;
		C::t('#keke_market#keke_market_order')->insert($secarr);
		$updatearrs=array(
			'money'=>$uids['level_sec']['money']+$secarr['money'],
			'totalmoney'=>$uids['level_sec']['totalmoney']+$secarr['money'],
		);
		C::t('#keke_market#keke_market_member')->update($uids['level_sec']['uid'],$updatearrs);
	}
}

function _getlevelselect($type=''){
	global $_G;
	$level_data = $_G['cache']['keke_market_level']?$_G['cache']['keke_market_level']:C::t('#keke_market#keke_market_level')->fetch_all();
	$level .= '<select name="levelid">'.($type?'':'<option value="all" '.($_GET['levelid']=='all'?'selected':'').'>'.lang('plugin/keke_market', '094').'</option>');
		foreach($level_data as $vv){
			$selected = $_GET['levelid']==$vv['id'] ? 'selected="selected"' : '';
			$level.="<option  value=\"".$vv['id']."\" $selected>".$vv['name'].($type?' / '.lang('plugin/keke_market', '075').' '.$vv['one'].'% / '.lang('plugin/keke_market', '076').' '.$vv['sec'].'%':'')."</option>\n";
		}
	$level .= '</select>';
	return $level;
}


function _getdefaultlevel(){
	global $_G;
	$level_data =C::t('#keke_market#keke_market_level')->fetchfirst_default();
	return $level_data;
}

function repmultipage($count_all, $ppp, $page, $tmpurl){
	global $_G;
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl,'',3);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	$multipage=str_replace('href','data-href',$multipage);
	return $multipage;
}

function _getmemberbinddata($uid){
	$bind_data=C::t('#keke_market#keke_market_bind')->fetchfirst_bysubuid($uid);
	return array(
		'upuid'=>$bind_data['uid'],
		'upusername'=>_market_getusname($bind_data['uid']),
		'csrcount'=>C::t('#keke_market#keke_market_bind')->count_all('uid='.intval($uid)),
		'subcsrcount'=>C::t('#keke_market#keke_market_bind')->count_all_subuid_by_uid($uid),
	);
}

function market_utf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return $data;
	}
}
function market_gbk2utf($data){
	if(CHARSET=='gbk'){
		$data1 = diconv($data,'utf-8','gbk');
		$data0 = diconv($data1,'gbk','utf-8');
		if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
		return diconv($tmpstr,'gbk','utf-8');
	}else{
		return $data;
	}
}


function _market_getusname($uid){
	$userdata=getuserbyuid($uid);
	return $userdata['username'];
}

function _market_editor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}

function _market_upload_img($file,$width, $height=10000,$max=5024,$thumb='1'){
    global $_G;
    $file['size'] > ($max * 1024) && showmessage('file_size_overflow', '', array('size' => $max * 1024));
    $upload = new discuz_upload();
    $uploadtype = 'keke_wallet';
    if(!is_array($file) || empty($file) || !$upload->is_upload_file($file['tmp_name']) || trim($file['name']) == '' || $file['size'] == 0) {
        $upload->attach = array();
        $upload->errorcode = -1;
        return false;
    } else {
        $upload->type = discuz_upload::check_dir_type($uploadtype);
        $upload->extid = intval($data['extid']);
        $upload->forcename = '';

        $file['size'] = intval($file['size']);
        $file['name'] =  trim($file['name']);
        $file['thumb'] = '';
        $file['ext'] = $upload->fileext($file['name']);
        $file['name'] =  dhtmlspecialchars($file['name'], ENT_QUOTES);
        if(strlen($file['name']) > 90) {
            $file['name'] = cutstr($file['name'], 80, '').'.'.$file['ext'];
        }
        $file['isimage'] = $upload->is_image_ext($file['ext']);
        if(!$file['isimage']){
            exit(lang('error', 'file_upload_error_-102'));
        }
        $file['extension'] = $upload->get_target_extension($file['ext']);
        $file['attachdir'] = _market_get_target_dir($upload->type);
        $file['attachment'] = $file['attachdir'].$upload->get_target_filename($upload->type, $upload->extid, $upload->forcename).'.'.$file['extension'];
        $file['target'] = getglobal('setting/attachdir').'./'.$upload->type.'/'.$file['attachment'];
        $upload->attach = & $file;
        $upload->errorcode = 0;
    }
    if(!$upload->save()) {
        exit($upload->errormessage());
    }
    if($thumb && ($upload->attach['imageinfo'][0]>$width || $upload->attach['imageinfo'][1]>$height)){
        if($file['isimage']){
            require_once libfile('class/image');
            $img = new image;
            $thumbpic=$img->Thumb($upload->attach['target'], './'.$uploadtype.'/'.$upload->attach['attachment'].'_thumb.jpg', $width, $height, 'fixwr');
        }
    }
    if($thumbpic){
        @unlink($img->source);
        return getglobal('setting/attachurl').$uploadtype.'/'.$upload->attach['attachment'].'_thumb.jpg';
    }else{
        return getglobal('setting/attachurl').$upload->type.'/'.$upload->attach['attachment'];
    }
}

function _market_get_target_dir($type, $check_exists = true) {
    $subdir = $subdir1 = $subdir2 = '';
    $subdir1 = date('Ym');
    $subdir2 = date('d');
    $subdir = $subdir1.'/'.$subdir2.'/';
    $check_exists && discuz_upload::check_dir_exists($type, $subdir1, $subdir2);
    return $subdir;
}


function _market_magapp_account_transfer($Uid,$Amount,$Remark){
    global $_G;
    $keke_market = $_G['cache']['plugin']['keke_market'];
    $Remark = market_gbk2utf($Remark);
    $Url = 'http://'.$keke_market['magurl'].'/core/pay/pay/accountTransfer?secret='.$keke_market['magsecret'].'&user_id='.$Uid.'&amount='.$Amount.'&remark='.$Remark.'&out_trade_code='.random(10);
    $Data = dfsockopen($Url);
    if(!$Data) {
        $Data = file_get_contents($Url);
    }
    $return = json_decode($Data,true);
    $return['msg']=market_utf2gbk($return['msg']);
    if($return['success'] && $return['code'] == 101){
        return array(true);
    }
    return array(false,$return['msg']);
}