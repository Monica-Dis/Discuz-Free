<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$keke_market = $_G['cache']['plugin']['keke_market'];
require_once DISCUZ_ROOT.'./source/plugin/keke_market/function.php';
if($_GET['formhash'] != $_G['formhash']) {
	exit('Formhash_Error');
}
if(!$_G['uid'] && $_GET['ac']!='pc_share') {
	exit(json_encode(array('err'=>1,'msg'=>market_gbk2utf(lang('plugin/keke_market', '066')))));
}
$ppp=30;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

if($_GET['ac']=='delbind'){
	C::t('#keke_market#keke_market_bind')->delete_by_uid($_G['uid'],intval($_GET['uid']));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='upqrimg'){
        $picurl=_market_upload_img($_FILES['uploaderInput'],400);
        C::t('#keke_market#keke_market_member')->update($_G['uid'],array('wxqr'=>$picurl));
        exit(json_encode(array('err' =>'','picurl'=>$picurl)));
}elseif($_GET['ac']=='delwxqr'){
    $mycard=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
    if($mycard['wxqr']){
        C::t('#keke_market#keke_market_member')->update($_G['uid'],array('wxqr'=>''));
        @unlink(DISCUZ_ROOT .'./'.$mycard['wxqr']);
    }
    exit(json_encode(array('err' =>'','state'=>1)));
}elseif($_GET['ac']=='getbindlist'){
	$tmpurl='plugin.php?id=keke_market:ajax&ac=getbindlist&type='.intval($_GET['type']).'&formhash='.FORMHASH;
	if($_GET['type']==1){
		$count_all=C::t('#keke_market#keke_market_bind')->count_all('uid='.$_G['uid']);
		$binddata=C::t('#keke_market#keke_market_bind')->fetch_alls($startlimit,$ppp,'uid='.$_G['uid'],$order);
	}else{
		$count_all=C::t('#keke_market#keke_market_bind')->count_all_subuid_by_uid($_G['uid']);
		$binddata=C::t('#keke_market#keke_market_bind')->fetchall_subuid_by_uid($_G['uid'],$startlimit,$ppp);
	}
	$multipage = repmultipage($count_all, $ppp, $page, $tmpurl);
	include template('keke_market:block');
	exit($getbindlist);
}elseif($_GET['ac']=='getorderlist'){
    $tmpurl='plugin.php?id=keke_market:ajax&ac=getorderlist&listtype='.intval($_GET['listtype']).'&formhash='.FORMHASH;
	$where='uid='.$_G['uid'];
	if($_GET['listtype']){
		$where.=' AND molds='.intval($_GET['listtype']);
	}
	$count_all= C::t('#keke_market#keke_market_order')->count_all($where);
	$orderdata=C::t('#keke_market#keke_market_order')->fetch_alls($startlimit,$ppp,$where,$order);
	$multipage = repmultipage($count_all, $ppp, $page, $tmpurl);
	include template('keke_market:block');
	exit($getorderlist);
}elseif($_GET['ac']=='addmember'){
	
	if(!$_GET['username']){
		exit(json_encode(array('err'=>1,'msg'=>market_gbk2utf(lang('plugin/keke_market', '067')))));
	}
	if(!$_GET['mobile']){
		exit(json_encode(array('err'=>1,'msg'=>market_gbk2utf(lang('plugin/keke_market', '068')))));
	}
	$memberdata=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
	if($memberdata['state']==1 || ($memberdata && !$memberdata['state'])){
		exit(json_encode(array('err'=>1,'msg'=>market_gbk2utf(lang('plugin/keke_market', '069')))));
	}
	$defaultlevel = C::t('#keke_market#keke_market_level')->fetchfirst_default();
	$arr=array(
		'uid'=>$_G['uid'],
		'time'=>TIMESTAMP,
		'levelid'=>$defaultlevel['id'],
		'state'=>0,
		'mobile'=>$_GET['mobile'],
		'username'=>$_GET['username']
	);
	C::t('#keke_market#keke_market_member')->insert($arr,true,true);
	exit(json_encode(array('err'=>0)));
}elseif($_GET['ac']=='setcard'){
	$arr=array(
		'wechatpay'=>$_GET['wechatpay'],
		'alipay'=>$_GET['alipay'],
	);
	C::t('#keke_market#keke_market_member')->update($_G['uid'],$arr);
	exit(json_encode(array('err'=>0)));
}elseif($_GET['ac']=='cashout'){	
	$cashnum=floatval($_GET['cashnum']);
	$cardtype=intval($_GET['cardtype']);
	$fp = fopen(DISCUZ_ROOT."/source/plugin/keke_market/template/lock.htm", "r");
	if(flock($fp,LOCK_EX | LOCK_NB)){
		$memberdata=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
        if($cardtype==1 && !$memberdata['wxqr']){
            flock($fp,LOCK_UN);
            exit(json_encode(array('err'=>2,'msg'=>market_gbk2utf(lang('plugin/keke_market', '100')))));
        }
		if($cashnum<=0){
            flock($fp,LOCK_UN);
			exit(json_encode(array('err'=>1,'msg'=>market_gbk2utf(lang('plugin/keke_market', '070')))));
		}
		if($cashnum<$keke_market['mincash'] && $keke_market['mincash']){
            flock($fp,LOCK_UN);
			exit(json_encode(array('err'=>1,'msg'=>market_gbk2utf(lang('plugin/keke_market', '071').$keke_market['mincash'].lang('plugin/keke_market', '072')))));
		}
		if($cashnum>$memberdata['money']){
            flock($fp,LOCK_UN);
			exit(json_encode(array('err'=>1,'msg'=>market_gbk2utf(lang('plugin/keke_market', '073')))));
		}
		$arr=array(
			'money'=>floatval($memberdata['money']-$cashnum),
		);
		C::t('#keke_market#keke_market_member')->update($_G['uid'],$arr);
		$casharr=array(
			'uid'=>$_G['uid'],
			'time'=>TIMESTAMP,
			'molds'=>2,
			'money'=>$cashnum,
			'balance'=>$arr['money'],
			'cardtype'=>$_GET['cardtype']
		);
        $cashoutid=C::t('#keke_market#keke_market_order')->insert($casharr,true);
        if($cardtype==3){
            $Magapppay=_market_magapp_account_transfer($_G['uid'],$cashnum,lang('plugin/keke_market', '101'));
            if($Magapppay[0]){
                C::t('#keke_market#keke_market_order')->update($cashoutid, array('state' => 1));
            }else{
                C::t('#keke_market#keke_market_order')->update($cashoutid, array('msg' => $Magapppay[1]));
                flock($fp,LOCK_UN);
                exit(json_encode(array('err'=>1,'msg'=>market_gbk2utf($Magapppay[1]))));
            }
        }
		flock($fp,LOCK_UN);
	}else{
		exit(json_encode(array('err'=>1,'msg'=>market_gbk2utf(lang('plugin/keke_market', '074')))));
	}
	exit(json_encode(array('err'=>0)));
	
}elseif($_GET['ac']=='checkmember'){
	$ret=0;
	$distributor=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
	if($distributor){
		$ret=1;
	}
	exit(json_encode(array('member'=>$ret)));
}elseif($_GET['ac']=='pc_share'){
	$cid=intval($_GET['cid']);
	$_GET['op']=dhtmlspecialchars($_GET['op']);
	$_GET['from']=dhtmlspecialchars($_GET['from']);
	$market_member=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
	if($_GET['from']=='group'){
		$keke_group = $_G['cache']['plugin']['keke_group'];
		$sharebtn=$keke_group['sharebtn'];
		$sharearr=array(
			'url'=>urlencode($_G['siteurl'].'plugin.php?id=keke_group&iuid='.$_G['uid']),
			'title'=>urlencode(market_gbk2utf($keke_group['postertitle'])),
			'dec'=>$keke_group['postertitle'],
			'decs'=>urlencode(market_gbk2utf($keke_group['postertitle'])),
		);
	}else{
		$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
		$sharebtn=$keke_video_base['sharebtn'];
		$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
		$sharearr=array(
			'url'=>urlencode($_G['siteurl'].'plugin.php?id=keke_video_base&ac=course&cid='.$cid.'&iuid='.$_G['uid']),
			'title'=>urlencode(market_gbk2utf($course['title'])),
			'dec'=>lang('plugin/keke_market', '090').$course['title'].lang('plugin/keke_market', '091'),
			'decs'=>urlencode(market_gbk2utf(lang('plugin/keke_market', '090').$course['title'].lang('plugin/keke_market', '091'))),
		);
	}
	include template('keke_market:keke_market_win');
}