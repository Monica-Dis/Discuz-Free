<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	include_once DISCUZ_ROOT."source/plugin/keke_market/function.php";
	if (submitcheck("forumset")) {
		if(is_array($_GET['ids'])) {
			if($_GET['optype'] == 'delete') {
				C::t('#keke_market#keke_market_member')->delete($_GET['ids']);
			} elseif($_GET['optype'] == 'pass') {
				C::t('#keke_market#keke_market_member')->update($_GET['ids'], array('state' => 1));
			} elseif($_GET['optype'] == 'refuse') {
				C::t('#keke_market#keke_market_member')->update($_GET['ids'], array('state' => 2));
			}
		}else{
			cpmsg(lang('plugin/keke_market', '001'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_member', 'error');
		}
		
		if(!$_GET['optype']){
			cpmsg(lang('plugin/keke_market', '037'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_member', 'error');
		}
		cpmsg(lang('plugin/keke_market', '002'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_member', 'succeed');
	}
	
	
	if($_GET['ac']=='edit'){
		$uid=intval($_GET['uid']);
		$member=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($uid);
		$bind_data=C::t('#keke_market#keke_market_bind')->fetchfirst_bysubuid($uid);
		if (submitcheck("editsubmit")) {
			$arr=array(
				'levelid' => $_GET['levelid'],
				'state' => $_GET['state'],
			);
			if($uid){
				$arr['uid']=$uid;
			}
			
			if($_GET['upuid']==$uid){
					cpmsg(lang('plugin/keke_market', '093'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_member', 'error');
			}
			
			if($member){
				C::t('#keke_market#keke_market_member')->update($uid,$arr);
			}
			
			if($_GET['upuid']){
				if($bind_data){
					C::t('#keke_market#keke_market_bind')->update($bind_data['id'],array('uid'=>$_GET['upuid']));
				}else{
					C::t('#keke_market#keke_market_bind')->insert(array('uid'=>$_GET['upuid'],'subuid'=>$uid,'bindtime'=>TIMESTAMP));
				}
			}else{
				C::t('#keke_market#keke_market_bind')->delete($bind_data['id']);
			}
			
			cpmsg(lang('plugin/keke_market', '002'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_member&page='.intval($_GET['page']), 'succeed');
		}
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_member&ac=edit", 'enctype');
		showtableheader(lang('plugin/keke_market', '038'));
		$_GET['levelid']=$member['levelid'];
		showsetting(lang('plugin/keke_market', '039'),'','',_getlevelselect(1));
		showsetting(lang('plugin/keke_market', '015'),'','','<select name="state"><option value="0" '.(!$member['state']?'selected="selected"':'').'>'.lang('plugin/keke_market', '040').'</option><option value="1" '.($member['state']==1?'selected="selected"':'').'>'.lang('plugin/keke_market', '041').'</option><option value="2" '.($member['state']==2?'selected="selected"':'').'>'.lang('plugin/keke_market', '042').'</option></select>');
		showsetting(lang('plugin/keke_market', '009').'uid','upuid',$bind_data['uid'],'text','','',lang('plugin/keke_market', '092'));
		echo '<input name="uid" type="hidden" value="'.$uid.'" /><input name="page" type="hidden" value="'.intval($_GET['page']).'" />';
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dis'.'m.tao'.'bao.com*/
		showformfooter(); /*dism��taobao��com*/
		exit;
	}
	
	showtableheader(lang('plugin/keke_market', '044'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_market&pmod=admincp_member', 'testhd');
	showtablerow('', array('width="50"', 'width="120"', 'width="50"','width="150"', 'width="50"','width="180"'),
		array(
			'<b>'.lang('plugin/keke_market', '015').': </b>',
			'<select name="state"><option value="9" '.($_GET['state']==9?'selected':'').'>'.lang('plugin/keke_market', '095').'</option><option value="8" '.($_GET['state']==8?'selected':'').'>'.lang('plugin/keke_market', '040').'</option><option value="1" '.($_GET['state']==1?'selected':'').'>'.lang('plugin/keke_market', '041').'</option><option value="2" '.($_GET['state']==2?'selected':'').'>'.lang('plugin/keke_market', '042').'</option></select>',
			'<b>'.lang('plugin/keke_market', '043').': </b>',
			_getlevelselect(),
			'<b>UID: </b>',
			'<input name="uid" type="text" />',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_market', '004').'">'
		)
    );
	showformfooter(); /*dism��taobao��com*/
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	$where='1';$param='';
	if($_GET['levelid'] && $_GET['levelid']!='all'){
		$where.=" AND levelid=".intval($_GET['levelid']);
		$param.='&levelid='.intval($_GET['levelid']);
	}
	if($_GET['uid']){
		$where.=" AND uid=".intval($_GET['uid']);
		$param.='&uid='.intval($_GET['uid']);
	}
	
	if($_GET['state'] && $_GET['state']!=9){
		$param.='&state='.intval($_GET['state']);
		if($_GET['state']==8){
			$_GET['state']=0;
		}
		$where.=" AND state=".intval($_GET['state']);
	}
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_member");	
	showtableheader(lang('plugin/keke_market', '044'));
    showsubtitle(array(lang('plugin/keke_market', '045').'?', 'UID',lang('plugin/keke_market', '081'),lang('plugin/keke_market', '009'),lang('plugin/keke_market', '082'),lang('plugin/keke_market', '083'),lang('plugin/keke_market', '049'),lang('plugin/keke_market', '015'),lang('plugin/keke_market', '050'),lang('plugin/keke_market', '016')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_member'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$level_data = $_G['cache']['keke_market_level']?$_G['cache']['keke_market_level']:C::t('#keke_market#keke_market_level')->fetch_all();
	if($allcount = C::t('#keke_market#keke_market_member')->count_all($where)){
		$member_data=C::t('#keke_market#keke_market_member')->fetch_alls($startlimit,$ppp,$where,$order);
		foreach($member_data as $k=>$v){
			$uids[$v['uid']]=$v['uid'];
			$uids[$v['superior']]=$v['superior'];
		}
		$userdata=C::t('#keke_market#keke_market_member')->fetchall_username($uids);
		foreach($member_data as $key=>$val){
			$op='<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_member&ac=edit&uid='.$val['uid'].'&page='.intval($_GET['page']).'">'.lang('plugin/keke_market', '035').'</a>';
			$table = array();
			$memberbinddata=_getmemberbinddata($val['uid']);
			$table[0] = '<input type="checkbox" class="checkbox" name="ids[]" value="'.$val['uid'].'" />';
			$table[1] = $val['uid'];
			$table[2] = '<a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'.$userdata[$val['uid']]['username'].'</a><div class="rows">'.lang('plugin/keke_market', '084').$val['username'].'</div><div class="rows">'.lang('plugin/keke_market', '085').$val['mobile'].'</div>';
			$table[3] = ($memberbinddata['upuid']?'<a href="home.php?mod=space&uid='.$memberbinddata['upuid'].'" target="_blank">'.$memberbinddata['upusername'].'</a>':'-');
			$table[4] = '<div class="rows">'.lang('plugin/keke_market', '046').': <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_bind&uid='.$val['uid'].'">'.$memberbinddata['csrcount'].'</a></div><div class="rows">'.lang('plugin/keke_market', '047').': '.$memberbinddata['subcsrcount'].'</div>';
			$table[5] = '<div class="rows">'.lang('plugin/keke_market', '088').':  &yen; '.$val['money'].'</div><div class="rows">'.lang('plugin/keke_market', '089').':  &yen; '.$val['totalmoney'].'</div>';
			$table[6] = dgmdate($val['time'], 'Y/m/d H:i:s');
			$table[7] = $val['state']==1?'<span class="zc">'.lang('plugin/keke_market', '041').'</span>':( $val['state']==2?'<span class="jj">'.lang('plugin/keke_market', '042').'</span>':'<span class="ds">'.lang('plugin/keke_market', '040').'</span>');
			$table[8] = $level_data[$val['levelid']]['name'].' / '.lang('plugin/keke_market', '051').' '.$level_data[$val['levelid']]['one'] .'% / '.lang('plugin/keke_market', '052').' '.$level_data[$val['levelid']]['sec'].'%';
			$table[9] = $op;
			showtablerow('',array('','width=""','width=""'), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	
	
	showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'ids\')"><label for="chkallIuPN">'.lang('plugin/keke_market', '096').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_market', '097').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="pass" value="pass" class="radio" /><label for="pass" class="vmiddle">'.lang('plugin/keke_market', '098').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="refuse" value="refuse" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_market', '099').'</label><style>.rows{margin-top:5px; color:#777}.ds{color: #F90;}.jj{color: #c30;}.zc{color: #3fd411;}</style>','');
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dism��taobao��com*/