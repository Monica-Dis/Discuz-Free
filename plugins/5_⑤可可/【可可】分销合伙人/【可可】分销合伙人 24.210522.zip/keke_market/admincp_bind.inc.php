<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
include_once DISCUZ_ROOT."source/plugin/keke_market/function.php";
if (submitcheck("forumset")) {
	if(is_array($_GET['ids'])) {
		C::t('#keke_market#keke_market_bind')->delete($_GET['ids']);
	}else{
		cpmsg(lang('plugin/keke_market', '001'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_bind', 'error');
	}
	cpmsg(lang('plugin/keke_market', '002'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_bind', 'succeed');
}


showtableheader(lang('plugin/keke_market', '003'));
showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_market&pmod=admincp_bind', 'testhd');
showtablerow('', array('width="70"', 'width="180"','width="70"', 'width="120"'),
	array(
		'<b>'.lang('plugin/keke_market', '009').'UID: </b>',
		'<input name="uid" type="text"  value="'.($_GET['uid']?intval($_GET['uid']):'').'" />',
		'<b>'.lang('plugin/keke_market', '010').'UID: </b>',
		'<input name="subuid" type="text" value="'.($_GET['subuid']?intval($_GET['subuid']):'').'" />',
		'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_market', '004').'">'
	)
);
showformfooter(); /*dism��taobao��com*/
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
$where='1';$param='';
if($_GET['uid']){
	$where.=" AND uid=".intval($_GET['uid']);
	$param.='&uid='.intval($_GET['uid']);
}
if($_GET['subuid']){
	$where.=" AND subuid=".intval($_GET['subuid']);
	$param.='&subuid='.intval($_GET['subuid']);
}

showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_bind");	
showtableheader(lang('plugin/keke_market', '005'));
showsubtitle(array('del',lang('plugin/keke_market', '006'),lang('plugin/keke_market', '007'),lang('plugin/keke_market', '008')));
$ppp=30;
$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_bind'.$param;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

if($allcount = C::t('#keke_market#keke_market_bind')->count_all($where)){
	$bind_data=C::t('#keke_market#keke_market_bind')->fetch_alls($startlimit,$ppp,$where,$order);
	foreach($bind_data as $k=>$v){
		$uids[$v['uid']]=$v['uid'];			
		$uids[$v['subuid']]=$v['subuid'];
	}
	$userdata=C::t('#keke_market#keke_market_member')->fetchall_username($uids);
	foreach($bind_data as $key=>$val){
		$table = array();
		$table[0] = '<input type="checkbox" class="checkbox" name="ids[]" value="'.$val['id'].'" />';
		$table[1] = '<a href="home.php?mod=space&uid='.$val['subuid'].'" target="_blank">'.$userdata[$val['subuid']]['username'].'</a> <span class="ds">[uid '.$val['subuid'].']</span>';
		$table[2] = '<a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'.$userdata[$val['uid']]['username'].'</a> <span class="ds">[uid '.$val['uid'].']</span>';
		$table[3] = dgmdate($val['bindtime'], 'Y/m/d H:i:s');
		showtablerow('',array(), $table);
	}
}
$multipage='';
$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
echo '<style>.ds{color: #c3c3c3;margin-left:5px}</style>';
showsubmit('forumset', 'submit', 'del','');
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
showformfooter(); /*dism��taobao��com*/