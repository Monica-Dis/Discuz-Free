<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	include_once DISCUZ_ROOT."source/plugin/keke_market/function.php";
	if (submitcheck("forumset")) {
		if(is_array($_GET['ids'])) {
			C::t('#keke_market#keke_market_order')->delete($_GET['ids']);
		}else{
			cpmsg(lang('plugin/keke_market', '001'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_order', 'error');
		}
		cpmsg(lang('plugin/keke_market', '002'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_order', 'succeed');
	}
	showtableheader(lang('plugin/keke_market', '053'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_market&pmod=admincp_order', 'testhd');
	showtablerow('', array('width="50"', 'width="120"', 'width="50"','width="180"'),
		array(
			'<b>uid: </b>',
			'<input name="uid" type="text" />',
			'<b>'.lang('plugin/keke_market', '054').': </b>',
			'<input name="orderid" type="text" />',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_market', '004').'">'
		)
    );
	showformfooter(); /*dism��taobao��com*/
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	$where='molds=1';$param='';
	if($_GET['uid']){
		$where.=" AND uid=".intval($_GET['uid']);
		$param.='&uid='.intval($_GET['uid']);
	}
	if($_GET['orderid']){
		$where.=" AND orderid='".daddslashes(dhtmlspecialchars($_GET['orderid'])).'\'';
		$param.='&orderid='.dhtmlspecialchars($_GET['orderid']);
	}
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_order");	
	showtableheader(lang('plugin/keke_market', '055'));
    showsubtitle(array('del', lang('plugin/keke_market', '056').'UID', lang('plugin/keke_market', '057'),lang('plugin/keke_market', '058'),lang('plugin/keke_market', '059'),lang('plugin/keke_market', '060'),lang('plugin/keke_market', '061'),lang('plugin/keke_market', '062'),lang('plugin/keke_market', '063')));
	$ppp=10;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_market&pmod=admincp_order'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	if($allcount = C::t('#keke_market#keke_market_order')->count_all($where)){
		$member_data=C::t('#keke_market#keke_market_order')->fetch_alls($startlimit,$ppp,$where,$order);
		foreach($member_data as $k=>$v){
			$uids[]=$v['uid'];
			if($v['from']=='keke_group'){
				$grouporderids[$v['orderid']]=$v['orderid'];
			}else{
				$orderids[]=$v['orderid'];
			}
		}
		$userdata=C::t('#keke_market#keke_market_member')->fetchall_username($uids);
		
		if($orderids){
			$orderdata=C::t('#keke_market#keke_market_order')->fetch_all_order($orderids);
		}
		if($grouporderids){
			$grouporderdata=DB::fetch_all("SELECT * FROM %t WHERE orderid in (%n)", array('keke_group_orderlog',$grouporderids));
			foreach($grouporderdata as $gk=>$gv){
				$orderdata[$gv['orderid']]='<a href="home.php?mod=space&uid='.$gv['uid'].'" target="_blank">'._market_getusname($gv['uid']).'</a> '.lang('plugin/keke_market', '077').'  <span class="coursesname"> # '.$gv['groupname'].' # </span>  ';
			}
		}
		foreach($member_data as $key=>$val){
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="ids[]" value="'.$val['id'].'" />';
			$table[1] = $val['uid'];
			$table[2] = $userdata[$val['uid']]['username'];
			$table[3] = $val['type']==1?lang('plugin/keke_market', '064'):lang('plugin/keke_market', '065');
			$table[4] = $val['orderid'];
			$table[5] = '<a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'.$orderdata[$val['orderid']].'</a>';
			$table[6] = $val['amount'];
			$table[7] = $val['money'];
			$table[8] = dgmdate($val['time'], 'Y/m/d H:i:s');
			showtablerow('',array('','width=""','width=""'), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dism��taobao��com*/