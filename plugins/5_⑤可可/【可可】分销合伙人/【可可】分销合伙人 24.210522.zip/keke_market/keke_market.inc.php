<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_market = $_G['cache']['plugin']['keke_market'];
require_once DISCUZ_ROOT.'./source/plugin/keke_market/function.php';

if(checkmobile() && !$_G['uid'] && $_GET['ac']){
    $refererurl=$_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"];
    dheader("Location: ".$_G['siteurl']."member.php?mod=logging&action=login&referer=".urlencode($refererurl));
}
$member=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
$level_data = $_G['cache']['keke_market_level']?$_G['cache']['keke_market_level']:C::t('#keke_market#keke_market_level')->fetch_all();
$keke_market['cashchannel']=unserialize($keke_market['cashchannel']);
if($keke_market['run']==2 && !$member && $_G['uid']){
	foreach($level_data as $key=>$val){
		if($val['defaults']){
			$dflevelid=$val['id'];
			break;
		}
	}
	$member=array(
		'uid'=>$_G['uid'],
		'time'=>TIMESTAMP,
		'state'=>1,
		'levelid'=>$dflevelid
	);
	C::t('#keke_market#keke_market_member')->insert($member);
}
if($_GET['ac']=='rule') {
    $keke_market['ruleinfo'] = _market_editor_safe_replace($keke_market['ruleinfo']);
}elseif ($_GET['ac']=='account'){
    $member['wxqr']=$member['wxqr']?((strstr($member['wxqr'], "http")!== false)?$member['wxqr']:$_G['siteurl'].$member['wxqr']):'';
}else{
	$indexcount['mycus']=C::t('#keke_market#keke_market_bind')->count_all('uid='.$_G['uid']);
	$indexcount['moneycount']=C::t('#keke_market#keke_market_order')->summoney_all_by_uid($_G['uid']);
	$indexcount['todaymoneycount']=C::t('#keke_market#keke_market_order')->summoney_today_by_uid($_G['uid']);
	$keke_market['recruitpic']=dhtmlspecialchars($keke_market['recruitpic']);
	$posterurlurl=urlencode(((strstr($keke_market['posterurlurl'], "http")!== false)?'':$_G['siteurl']).$keke_market['posterurlurl'].'&iuid='.$_G['uid']);
}
$_GET['op']=intval($_GET['op']);
$recruitinforow=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',_market_editor_safe_replace($keke_market['recruitinfo'])));
foreach($recruitinforow as $key=>$val){
	$recruitinfo[$key]=explode('##',$val);
}
if((strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX")!== false || strstr($_SERVER['HTTP_USER_AGENT'], "QianFan")!== false  || strstr($_SERVER['HTTP_USER_AGENT'], "MicroMessenger")!== false || strstr($_SERVER['HTTP_USER_AGENT'], "Appbyme")!== false || $ua) && $keke_market['appheader']){
	$inapp=$_GET['app']=1;
	if(K_INCWECHAT){
		$inapp=0;
	}
}
if($_GET['ac']){
	include template('keke_market:market_action');
}else{
	include template('keke_market:market_index');
}