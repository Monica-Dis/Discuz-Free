<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_market_bind= DB::table("keke_market_bind");
$keke_market_cashout= DB::table("keke_market_cashout");
$keke_market_level= DB::table("keke_market_level");
$keke_market_member= DB::table("keke_market_member");
$keke_market_order= DB::table("keke_market_order");

$sql = <<<EOF
CREATE TABLE `$keke_market_bind` (
  `id` int(24) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `subuid` int(10) NOT NULL,
  `bindtime` int(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_market_cashout` (
  `id` int(24) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `subuid` int(10) NOT NULL,
  `bindtime` int(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
)  ENGINE=MyISAM;


CREATE TABLE `$keke_market_level` (
  `id` int(24) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `one` int(10) unsigned NOT NULL,
  `sec` int(10) NOT NULL,
  `defaults` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`one`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_market_member` (
  `uid` int(30) NOT NULL,
  `time` int(30) NOT NULL,
  `directtotal` int(50) NOT NULL,
  `indirecttotal` int(50) NOT NULL,
  `superior` int(20) NOT NULL,
  `money` float(20,2) NOT NULL,
  `totalmoney` float(30,2) NOT NULL,
  `levelid` int(5) NOT NULL,
  `state` int(1) NOT NULL,
  `username` varchar(50) NOT NULL,
  `mobile` varchar(15) NOT NULL,
  `wechatpay` varchar(30) NOT NULL,
  `wxqr` varchar(255) NOT NULL,
  `alipay` varchar(30) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_market_order` (
  `id` int(24) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `orderid` varchar(200) NOT NULL,
  `money` float(20,2) NOT NULL,
  `amount` float(20,2) NOT NULL,
  `time` int(30) NOT NULL,
  `type` int(1) NOT NULL,
  `state` int(1) NOT NULL,
  `balance` float(20,2) NOT NULL,
  `cardtype` int(1) NOT NULL,
  `molds` int(1) NOT NULL,
  `from` varchar(20) NOT NULL,
  `msg` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`orderid`)
) ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_market/upgrade.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_market/install.php');