<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_market_order'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('from', $col_field)){
	$sql = "Alter table ".DB::table('keke_market_order')." add `from` varchar(20) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('msg', $col_field)){
    $sql = "Alter table ".DB::table('keke_market_order')." add `msg` varchar(255) NOT NULL;";
    DB::query($sql);
}

$memberQuery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_market_member'));
while($memberRow = DB::fetch($memberQuery)) {
    $member_col_field[]=$memberRow['Field'];
}

if(!in_array('wxqr', $member_col_field)){
    $sql = "Alter table ".DB::table('keke_market_member')." add `wxqr` varchar(255) NOT NULL;";
    DB::query($sql);
}
$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_market/discuz_plugin_keke_market_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_market/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_market/upgrade.php');