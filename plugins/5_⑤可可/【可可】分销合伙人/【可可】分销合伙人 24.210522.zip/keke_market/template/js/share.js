function wxshare(type,desc,icon,formhash) {
	var wstitle = document.title;
	if(type==1){
		$.get('plugin.php?id=keke_video_base:ajax&ac=wxshare&formhash='+formhash, {url:location.href.split('#')[0]},function (data){
			wx.config({
				  debug: false,
				  appId: data.appId,
				  timestamp: data.timestamp,
				  nonceStr: data.nonceStr,
				  signature: data.signature,
				  jsApiList: [
					  'onMenuShareTimeline',
					  'onMenuShareAppMessage',
				  ]
			  });
			  if(desc=='' || desc==undefined || desc==null){
				 desc=wstitle;
			  }
			  wx.ready(function () {
					wx.onMenuShareTimeline({
						title: wstitle,
						link: data.url,
						imgUrl: icon,
						success: function () {
						},
						cancel: function () {
						}
					});
					wx.onMenuShareAppMessage({  
						title: wstitle,
						desc: desc,
						link: data.url,
						imgUrl: icon,
						success: function () {
						},
						cancel: function () {
						}
					});
				}); 
		}, "json");
	}else if(type==2){
		mag.setData({
		  shareData: {
			  title: wstitle,
			  des: desc,
			  picurl: icon,
			  linkurl: location.href.split('#')[0],
			}
		});
	} 
} 