<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
exit('Access Denied');}
	
class plugin_keke_bg {
	function global_header(){
		global $_G;
		$keke_bg = $_G['cache']['plugin']['keke_bg'];
		$toph=$keke_bg['toph'] ? intval($keke_bg['toph']):100;
		$bgpic=dhtmlspecialchars($keke_bg['bgpic']);
		$bgh=$keke_bg['bgh'] ? intval($keke_bg['bgh']).'px' : 'top';
		$keke_bg['xzq']=dhtmlspecialchars($keke_bg['xzq']);
		$kq=unserialize($keke_bg['kq']);
		if(!(in_array(CURSCRIPT,$kq)) && !empty($kq[0])){return;}
		if($keke_bg['bgpic']){
			$bjxz=$bgpic;
			$op=1;
			$link=$keke_bg['link'];	
		}else{
			if($keke_bg['off']){
				  $auto=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_bg['auto']));
				  $op=0;
				  foreach($auto as $k=>$item){
				  $name=explode('|',$item);
				  if($name){
					 $st=strtotime(''.$name[2].' 00:00:00');
					 $end=strtotime(''.$name[3].' 23:59:59');
					  if($st<$_G['timestamp'] && $end>$_G['timestamp']){
						  $bjxz='source/plugin/keke_bg/template/img/'.$name['1'];
						  $link=$name[4];
						  $op=1;
						}
					}
				  }	
				}else{
					$bjxz='source/plugin/keke_bg/template/img/'.$keke_bg['bgchoice'].'.jpg';
					$link=$keke_bg['link'];	
					$op=1;
				}
		}
		if(!$op){return;}
		$bgsty=$this->bgsty_editor_safe_replace($keke_bg['style']);
		include template('keke_bg:index');
		return $return;
	}
	
	function bgsty_editor_safe_replace($content){
		$tags = array(
			"'<iframe[^>]*?>.*?</iframe>'is",
			"'<frame[^>]*?>.*?</frame>'is",
			"'<script[^>]*?>.*?</script>'is",
			"'<head[^>]*?>.*?</head>'is",
			"'<title[^>]*?>.*?</title>'is",
			"'<meta[^>]*?>'is",
			"'<link[^>]*?>'is",
		);
		return preg_replace($tags, "", $content);
	}
}

