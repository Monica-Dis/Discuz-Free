<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-09-01
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



if($_GET['operation']=='upgrade' && !$_GET['goon']){
	cpmsg('&#12304;&#27880;&#24847;&#12305;&#21319;&#32423;&#21069;&#35831;&#20808;&#33258;&#34892;&#22791;&#20221;&#21407;&#26377;&#29256;&#26412;&#25554;&#20214;&#25991;&#20214;&#65292;&#36335;&#24452;&#32;&#115;&#111;&#117;&#114;&#99;&#101;&#112;&#108;&#117;&#103;&#105;&#110;&#107;&#101;&#107;&#101;&#95;&#98;&#103;&#12290;&#22914;&#22240;&#20010;&#20154;&#21407;&#22240;&#25805;&#20316;&#22833;&#35823;&#19981;&#36127;&#36131;&#20813;&#36153;&#22788;&#29702;&#33;&#26395;&#30693;&#26195;', 'action=plugins&operation=upgrade&pluginid='.$plugin["pluginid"], 'form','','<input type="hidden" name="goon" value="1">');
}
$addonid = $pluginarray['plugin']['identifier'].'.plugin';
$array = cloudaddons_getmd5($addonid);
if(cloudaddons_open('&mod=app&ac=validator&addonid='.$addonid.($array !== false ? '&rid='.$array['RevisionID'].'&sn='.$array['SN'].'&rd='.$array['RevisionDateline'] : '')) === '0') {
	if($pluginarray['plugin']['identifier']){
	}
}