<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . 'source/plugin/keke_mipseo/identity.inc.php';
if (!defined('IN_ADMINCP')) {
	header('Content-Type: text/html;charset=utf-8');
}
function miputf2gbk($data)
{
	$data = dhtmlspecialchars($data);
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	if (CHARSET == 'gbk') {
		return $tmpstr;
	}
	return mipgbk2utf($data);
}
function mipgbk2utf($data)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	if ($keke_mipseo['zhuan'] == 2) {
		return mipcharacetss($data);
	}
	if ($keke_mipseo['zhuan'] == 3) {
		return mipgbk2utfssss($data);
	}
	return mipgbk2utfsss($data);
}
function mipgbk2utfsss($data)
{
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	return diconv($tmpstr, 'gbk', 'utf-8');
}
function mipgbk2utfssss($data)
{
	$data1 = iconv('utf-8', 'gbk//IGNORE', $data);
	$data0 = iconv('gbk', 'utf-8//IGNORE', $data1);
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	return iconv('gbk', 'utf-8//IGNORE', $tmpstr);
}
function mipcharacetss($data)
{
	if (!empty($data)) {
		$fileType = mb_detect_encoding($data, array('UTF-8', 'GBK', 'LATIN1', 'BIG5'));
		if ($fileType != 'UTF-8') {
			$data = mb_convert_encoding($data, 'utf-8', $fileType);
		}
	}
	return $data;
}
function mipattachparse($match)
{
	global $_G;
	global $config;
	$attach = C::t('forum_attachment_n')->fetch('aid:' . $match[1], $match[1], array(1, 0 - 1));
	if (!$attach['isimage']) {
		return NULL;
	}
	if ($attach['thumb']) {
		$attach['attachment'] = getimgthumbname($attach['attachment']);
	}
	return _createmipimg($attach);
}
function _createmipimg($attach)
{
	global $_G;
	if ($attach['remote']) {
		$filename = $_G['setting']['ftp']['attachurl'] . 'forum/' . $attach['attachment'];
	} else {
		$siteurl = !(strpos($_G['setting']['attachurl'], 'http') === false) ? '' : $_G['siteurl'];
		$filename = $siteurl . $_G['setting']['attachurl'] . 'forum/' . $attach['attachment'];
	}
	return '<mip-img class="imgsty" popup src="' . $filename . '"></mip-img>';
}
function _anaimg($match)
{
	global $_G;
	$siteurl = !(strpos($match[1], 'http') === false) ? '' : $_G['siteurl'];
	$picurl = $siteurl . $match[1];
	return '<mip-img class="imgsty" popup src="' . $picurl . '"></mip-img>';
}
function _anaarticleimg($match)
{
	global $_G;
	$siteurl = !(strpos($match[1], 'http') === false) ? '' : $_G['siteurl'];
	$picurl = $siteurl . $match[1];
	return '<mip-img class="imgsty" popup src="' . $picurl . '"></mip-img>';
}
function _filterfont($match)
{
	return '<font>';
}
function _analysis($message)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$sppos = strpos($message, chr(0) . chr(0) . chr(0));
	if ($sppos !== false) {
		$message = substr($message, 0, $sppos);
	}
	preg_match_all('/\\[imgs(.*?)\\](.*?)\\[\\/imgs\\]/', $message, $matches);
	$find = $matches[0];
	$replace = array();
	foreach ($matches[2] as $pval) {
		$replace[] = '<mip-img class="imgsty" popup src="' . $pval . '"></mip-img>';
	}
	$message = str_replace($find, $replace, $message);
	$message = preg_replace_callback('/\\[attach\\](\\d+)\\[\\/attach\\]/i', 'mipattachparse', $message);
	$message = preg_replace_callback('/<img[^>]*src=[\'"]?([^>\'"\\s]*)[\'"]?[^>]*>/i', '_anaarticleimg', $message);
	$message = preg_replace('/style=.+?[\'|"]/i', '', $message);
	if ($keke_mipseo['tag']) {
		$tagarr = explode(',', _mipeditor_safe_replace($keke_mipseo['tag']));
		foreach ($tagarr as $tagkey => $tagval) {
			$message = preg_replace('/\\[' . $tagval . '(.*?)\\]([\\s\\S]*)\\[\\/' . $tagval . '\\]/i', '', $message);
		}
	}
	return $message;
}
function _getmiparticle($aid)
{
	$content = $art = array();
	$article = C::t('portal_article_title')->fetch($aid);
	if (!$aid || !$article) {
		return NULL;
	}
	$page = intval($_GET['page']);
	if ($page < 1) {
		$page = 1;
	}
	if ($article['contents'] > 1) {
		foreach (C::t('portal_article_content')->fetch_all($aid) as $value) {
			$content['content'] .= $value['content'];
		}
	} else {
		$content = C::t('portal_article_content')->fetch_by_aid_page($aid, $page);
	}
	$article_count = C::t('portal_article_count')->fetch($aid);
	$content['content'] = _analysis(mipgbk2utf($content['content']));
	$content['content'] = preg_replace('/<script[\\s\\S]*?<\\/script>/is', '', $content['content']);
	$art['title'] = mipgbk2utf($article['title']);
	$art['content'] = $content['content'];
	$art['dataline'] = dgmdate($article['dateline'], 'Y/m/d H:i:s');
	$art['username'] = mipgbk2utf($article['username']);
	$art['viewnum'] = intval($article_count['viewnum']);
	$art['commentnum'] = intval($artcle_count['commentnum']);
	$art['page'] = mipgbk2utf($multi);
	return $art;
}
function _getmipthreads($tid)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$url = _getmipurls(2, $tid);
	$thread = C::t('forum_thread')->fetch($tid);
	$section = empty($keke_mipseo['forum']) ? array() : unserialize($keke_mipseo['forum']);
	if (!empty($section[0]) && !in_array($thread['fid'], $section) && !$thread['isgroup']) {
		dheader('location: ' . $url);
	}
	$art = array();
	if ($thread['readperm'] && $thread['readperm'] > $_G['group']['readaccess'] && !$_G['forum']['ismoderator'] && $thread['authorid'] != $_G['uid']) {
		$m = lang('message', 'thread_nopermission', array('readperm' => $thread['readperm']));
		$art['content'] = mipgbk2utf($m);
		return $art;
	}
	$firstpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
	include_once libfile('function/discuzcode');
	$allreplies = $thread['replies'] + $thread['comments'];
	$allreplies = intval($allreplies);
	$relatedtype = !$thread['isgroup'] ? 'forum' : 'group';
	$message = str_replace(array('[img', '[/img]'), array('[imgs', '[/imgs]'), $firstpost['message']);
	$message = str_replace(array('[free', '[/free]'), array('[frees', '[/frees]'), $firstpost['message']);
	preg_match_all('/\\[attach(.*?)\\](.*?)\\[\\/attach\\]/', $message, $matchess);
	if ($matchess[2]) {
		foreach ($matchess[2] as $attachval) {
			$attacharr[$attachval] = $attachval;
		}
	}
	if ($contentarr['content']) {
		$msg = $contentarr['content'];
	} else {
		$msg = discuzcode($message, $firstpost['smileyoff'], $firstpost['bbcodeoff'], $firstpost['htmlon'] & 1, 1, 1, 1, 1);
	}
	$msg = parse_related_links($msg, $relatedtype);
	if ($_G['cache']['plugin']['wq_wechatcollecting']) {
		$wqart = C::t('#wq_wechatcollecting#wq_wechatcollecting_article')->fetch_first_by_tid($tid);
		$wqartcontents = C::t('#wq_wechatcollecting#wq_wechatcollecting_article_content')->fetch_first_by_articleid($wqart['articleid']);
		$wqcontent = base64_decode($wqartcontents['content']);
		$wqcontent = str_replace('data_ysrc', 'data_ysr', $wqcontent);
		$wqcontent = str_replace('src="wq_wechatcollecting', 'src="' . $_G[setting][attachurl] . 'wq_wechatcollecting', $wqcontent);
		$msg .= $wqcontent;
	}
	$message = _analysis($msg);
	$message = preg_replace('/\\[hide(.*?)\\]([\\s\\S]*)\\[\\/hide\\]/i', '<span class="hidetip"><a target="_blank" href="' . $url . '">' . lang('plugin/keke_mipseo', '041') . '</a></span>', $message);
	if (!checkmobile()) {
		$message = preg_replace('/<em onclick="(.*?)">(.*?)<\\/em>/i', '', $message);
	}
	if ($thread['sortid']) {
		$info = _getsorinfo($thread['sortid'], $tid);
		include template('keke_mipseo:ajax');
		$message = $infotmp . $message;
	}
	$message = mipgbk2utf($message);
	$themembers = DB::fetch_first('select * from ' . DB::table('common_member') . ' where uid=' . $firstpost['authorid']);
	$forumfield = C::t('forum_forumfield')->fetch($thread['fid']);
	$allattach = C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'pid', $firstpost['pid'], '', true);
	if ($allattach) {
		foreach ($allattach as $valss) {
			if (!$attacharr[$valss['aid']]) {
				$allpic .= _createmipimg($valss);
			}
		}
	}
	$art['title'] = mipgbk2utf($firstpost['subject']);
	$art['content'] = _mipeditor_safe_replace($message) . $allpic;
	$art['dataline'] = dgmdate($firstpost['dateline'], 'Y/m/d H:i:s');
	if ($themembers['groupid'] == 4 || $themembers['groupid'] == 5) {
		$art['title'] = $art['dataline'] = '';
		$art['content'] = mipgbk2utf(lang('plugin/keke_mipseo', '042'));
	}
	if ($thread['price'] && $thread['special'] != 3) {
		$free = '';
		if (strpos($art['content'], '[frees]') !== false) {
			preg_match_all('/\\[frees(.*?)\\](.*?)\\[\\/frees\\]/', $art['content'], $matches);
			$free = $matches[2][0];
		}
		$art['content'] = $free . '<br/><br/>' . mipgbk2utf(lang('plugin/keke_mipseo', '043'));
	}
	if ($forumfield['viewperm']) {
		$allowViewPermGroupIds = explode('	', trim($forumfield['viewperm']));
		if (!in_array($_G['groupid'], $allowViewPermGroupIds)) {
			$art['content'] = mipgbk2utf(lang('plugin/keke_mipseo', '045'));
		}
	}
	$art['username'] = mipgbk2utf($firstpost['author']);
	$art['commentnum'] = $allreplies;
	return $art;
}
function _getsorinfo($sortid, $tid)
{
	$typevararr = C::t('forum_typevar')->fetch_all_by_sortid($sortid, 'ASC');
	$typeoptionarr = C::t('forum_typeoption')->fetch_all(array_keys($typevararr));
	$typeoptionvararr = C::t('forum_typeoptionvar')->fetch_all_by_tid_optionid($tid);
	foreach ($typeoptionvararr as $k => $v) {
		$valarr[$v['optionid']] = $v['value'];
	}
	foreach ($typeoptionarr as $key => $val) {
		$vals = '';
		$protect = array();
		if ($typevararr[$key]['available'] == 1) {
			if ($val['type'] == 'radio' || $val['type'] == 'checkbox' || $val['type'] == 'select') {
				$rules = unserialize($val['rules']);
				$rules_arr = explode("\r\n", $rules['choices']);
				foreach ($rules_arr as $vvv) {
					$dd = explode('=', $vvv);
					$dds[trim($dd[0])] = $dd[1];
				}
				if ($val['type'] == 'checkbox') {
					$checkboxdata = explode('	', $valarr[$key]);
					foreach ($checkboxdata as $checkboxval) {
						$vals .= $dds[$checkboxval] . ' ';
					}
				} else {
					$vals = $dds[$valarr[$key]];
				}
			} else {
				if ($val['type'] == 'image') {
					$ruless = unserialize(stripslashes($valarr[$key]));
					$vals = $ruless['url'] ? '<mip-img class="imgsty" popup src="' . trim($ruless['url']) . '">' : '';
				} else {
					$protect = unserialize($val['protect']);
					$vals = $valarr[$key];
					if ($protect['status'] == 1) {
						require_once libfile('function/forum');
						if (!protectguards($protect, $tid)) {
							$vals = $protect['mode'] == 1 ? '<mip-img class="class="imgsty" popup src="' . $_G['siteurl'] . stringtopic($valarr[$key]) . '"></mip-img>' : $valarr[$key];
						} else {
							if (empty($val['permprompt'])) {
								$vals = lang('forum/misc', 'view_noperm');
							} else {
								$vals = $val['permprompt'];
							}
						}
					}
				}
			}
			$retuan_arr = array('optionid' => $val['optionid'], 'title' => $val['title'], 'identifier' => trim($val['identifier']), 'unit' => $val['unit'], 'value' => $vals);
			$return[$key] = $retuan_arr;
		}
	}
	return $return;
}
function protectguards($protect, $tid)
{
	global $_G;
	global $member_verifys;
	$thread = C::t('forum_thread')->fetch($tid);
	if (!isset($member_verifys) && $_G['setting']['verify']['enabled']) {
		$member_verifys = array();
		getuserprofile('verify1');
		foreach ($_G['setting']['verify'] as $vid => $verify) {
			if ($verify['available'] && $_G['member']['verify' . $vid] == 1) {
				$member_verifys[] = $vid;
			}
		}
	}
	$verifyflag = 0;
	if ($_G['setting']['verify']['enabled'] && $protect['verify']) {
		if (array_intersect(explode('	', $protect['verify']), $member_verifys)) {
			$verifyflag = 1;
		}
	}
	if ($protect['usergroup'] && strstr('	' . $protect['usergroup'] . '	', '	' . $_G['groupid'] . '	') || empty($protect['usergroup']) && empty($protect['verify']) || $verifyflag || $thread['authorid'] == $_G['uid']) {
		return false;
	}
	return true;
}
function parse_related_links($content, $extent)
{
	global $_G;
	loadcache('relatedlink');
	$allextent = array('article' => 0, 'forum' => 1, 'group' => 2, 'blog' => 3);
	if ($_G['cache']['relatedlink'] && isset($allextent[$extent])) {
		$searcharray = $replacearray = array();
		foreach ($_G['cache']['relatedlink'] as $link) {
			$link['extent'] = sprintf('%04b', $link['extent']);
			if ($link['extent'][$allextent[$extent]] && $link['name'] && $link['url']) {
				$searcharray[$link['name']] = '/(' . preg_quote($link['name']) . ')/i';
				$replacearray[$link['name']] = '<a href="' . $link['url'] . '" target="_blank" class="relatedlink">' . $link['name'] . '</a>';
			}
		}
		if ($searcharray && $replacearray) {
			$content = preg_replace($searcharray, $replacearray, $content, 1);
		}
	}
	return $content;
}
function _getmipurls($type = 0, $atid)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	if ($type == 2) {
		$url = 'forum.php?mod=viewthread&tid=' . $atid;
		if (in_array('forum_viewthread', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus'] == 1) {
			$url = rewriteoutput('forum_viewthread', 1, '', $atid, $_GET['page']);
		}
		if (strpos($url, '{fid}') !== false) {
			$thread = C::t('forum_thread')->fetch($atid);
			$forumkeys = C::t('common_setting')->fetch('forumkeys', true);
			$repstr = $forumkeys[$thread['fid']] ? $forumkeys[$thread['fid']] : $thread['fid'];
			$url = str_ireplace('{fid}', $repstr, $url);
		}
	}
	if ($type == 3) {
		$url = 'forum.php?mod=forumdisplay&fid=' . $atid;
		if (in_array('forum_forumdisplay', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus'] == 1) {
			$url = rewriteoutput('forum_forumdisplay', 1, '', $atid, $_GET['page']);
		}
		if (strpos($url, '{fid}') !== false) {
			$thread = C::t('forum_thread')->fetch($atid);
			$forumkeys = C::t('common_setting')->fetch('forumkeys', true);
			$repstr = $forumkeys[$thread['fid']] ? $forumkeys[$thread['fid']] : $thread['fid'];
			$url = str_ireplace('{fid}', $repstr, $url);
		}
	}
	if ($type == 5) {
		loadcache('portalcategory');
		$url = 'portal.php?mod=list&catid=' . $atid;
		$portalcategory = $_G['cache']['portalcategory'];
		$cat = $portalcategory[$atid];
		if ($cat['fullfoldername']) {
			$page = $_GET['page'] > 1 ? 'index.php&page=' . $_GET['page'] : '';
			$url = $cat['fullfoldername'] . '/' . $page;
		}
	}
	if ($type == 6) {
		$url = 'plugin.php?id=keke_mipseo';
		if ($keke_mipseo['on'] && $keke_mipseo['rewriteindex']) {
			$url = $keke_mipseo['rewriteindex'];
		}
	} elseif ($type == 1) {
		$url = 'portal.php?mod=view&aid=' . $atid;
		if (in_array('portal_article', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus'] == 1) {
			$url = rewriteoutput('portal_article', 1, '', $atid, $_GET['page']);
		}
	}
	$siteurl = $keke_mipseo['domain'] ? $keke_mipseo['domain'] : $_G['siteurl'];
	return $siteurl . $url;
}
function _mip_str_rep($urltmp)
{
	if ($urltmp != '') {
		$urltmp = str_replace('.', '\\.', $urltmp);
		$urltmp = str_replace(array('{id}', '{tid}', '{fid}', '{page}', '{catid}'), array('([0-9]+)', '([0-9]+)', '(\\w+)', '([0-9]+)', '(\\w+)'), $urltmp);
		return $urltmp;
	}
}
function _postmip2baidu($atid, $mod)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$siteurl = $keke_mipseo['domain'] ? $keke_mipseo['domain'] : $_G['siteurl'];
	if ($mod == 1) {
		$mipurl = $siteurl . 'portal.php?mod=view&aid=' . $atid . '&mip=1';
		if ($keke_mipseo['rewritep'] && $keke_mipseo['on']) {
			$mipurl = $siteurl . str_ireplace('{id}', '' . $atid . '', $keke_mipseo['rewritep']);
		}
	} elseif ($mod == 2) {
		$mipurl = $siteurl . 'forum.php?mod=viewthread&tid=' . $atid . '&mip=1';
		if ($keke_mipseo['rewrite'] && $keke_mipseo['on']) {
			$mipurl = $siteurl . str_ireplace('{tid}', '' . $atid . '', $keke_mipseo['rewrite']);
		}
	}
	$urls = array($mipurl);
	$uri = 'http://data.zz.baidu.com/urls?site=' . $keke_mipseo['site'] . '&token=' . $keke_mipseo['token'] . '&type=mip';
	$ch = curl_init();
	$options = array(CURLOPT_URL => $uri, CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_POSTFIELDS => implode("\n", $urls), CURLOPT_HTTPHEADER => array('Content-Type: text/plain'));
	curl_setopt_array($ch, $options);
	$result = curl_exec($ch);
	$ret = json_decode($result, true);
	if ($ret['error']) {
		$state = intval($ret['error']);
		$msg = daddslashes($ret['message']);
	} else {
		if ($ret['success'] || $ret['success_mip']) {
			$state = 1;
		} else {
			if ($ret['not_same_site']) {
				$state = 2;
				$msg = 'not_same_site';
			}
			if ($ret['not_valid']) {
				$state = 3;
				$msg = 'not_valid';
			}
			if ($ret['remain_mip'] == 0) {
				$state = 6;
				$msg = 'Quota free';
			}
		}
	}
	$arr = array('url' => implode("\n", $urls), 'state' => $state, 'msg' => $msg, 'time' => $_G['timestamp'], 'mods' => intval($mod), 'atid' => intval($atid), 'reamin' => intval($ret['remain_mip']));
	C::t('#keke_mipseo#keke_mipseo')->insert($arr);
	return $result;
}
function _getpostarrss($modsid, $atidsstr)
{
	return DB::fetch_all('select atid from ' . DB::table('keke_mipseo') . ' where state=1 AND mods=' . $modsid . ' AND atid in (' . $atidsstr . ')');
}
function _batchpostmip2baidu($urls, $instarrs)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$uri = 'http://data.zz.baidu.com/urls?site=' . $keke_mipseo['site'] . '&token=' . $keke_mipseo['token'] . '&type=mip';
	$ch = curl_init();
	$options = array(CURLOPT_URL => $uri, CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_POSTFIELDS => implode("\n", $urls), CURLOPT_HTTPHEADER => array('Content-Type: text/plain'));
	curl_setopt_array($ch, $options);
	$result = curl_exec($ch);
	$ret = json_decode($result, true);
	if ($ret['error']) {
		$state = intval($ret['error']);
		$msg = daddslashes($ret['message']);
	} else {
		if ($ret['success'] || $ret['success_mip']) {
			$state = 1;
		} else {
			if ($ret['not_same_site']) {
				$state = 2;
				$msg = 'not_same_site';
			}
			if ($ret['not_valid']) {
				$state = 3;
				$msg = 'not_valid';
			}
			if ($ret['remain_mip'] == 0) {
				$state = 6;
				$msg = 'Quota free';
			}
		}
	}
	if ($ret['message'] != 'empty content') {
		foreach ($instarrs as $key => $val) {
			$arr = array('url' => $val['url'], 'state' => $state, 'msg' => $msg, 'time' => $_G['timestamp'], 'mods' => $val['mode'], 'atid' => $val['atid'], 'reamin' => intval($ret['remain_mip']));
			C::t('#keke_mipseo#keke_mipseo')->insert($arr);
		}
	}
	return $ret;
}
function _getallids($where, $mods, $ppps = '')
{
	if ($mods == 2) {
		$postdata = C::t('#keke_mipseo#keke_mipseo')->fetchfirst_bytid($atid, $mods);
	} else {
		$postdata = C::t('#keke_mipseo#keke_mipseo')->fetchfirst_byatid($atid, $mods);
	}
	return $postdata;
}
function _getmipsubject($atid, $mods)
{
	if ($mods == 2) {
		$thread = C::t('forum_thread')->fetch($atid);
		$subject = $thread['subject'];
	} else {
		$article = C::t('portal_article_title')->fetch($atid);
		$subject = $article['title'];
	}
	return $subject;
}
function _mipcache($urls)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 2 : 1;
	$api = 'http://c.mipcdn.com/update-ping/c/';
	if ($sys_protocal == 2) {
		$api = 'http://c.mipcdn.com/update-ping/c/s/';
	}
	$postData = 'key=' . $keke_mipseo['authkey'];
	$url = $api . urlencode($urls);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
	$result = curl_exec($ch);
	curl_close($ch);
	$ret = json_decode($result, true);
	$arr = array('url' => daddslashes($urls), 'state' => intval($ret['status']), 'msg' => daddslashes($ret['msg']), 'time' => $_G['timestamp']);
	C::t('#keke_mipseo#keke_mipseo_cache')->insert($arr);
	return $result;
}
function _gettdisplayorder($atid)
{
	return DB::result_first('select displayorder from ' . DB::table('forum_thread') . ' where tid=' . intval($atid));
}
function _getmipstates($atid, $mods)
{
	return DB::result_first('select count(1) from ' . DB::table('keke_mipseo') . ' where atid=' . intval($atid) . ' AND mods=' . intval($mods) . ' AND state=1');
}
function _getmipnav()
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$keke_mipseo['nav'] = _mipeditor_safe_replace($keke_mipseo['nav']);
	$keke_mipseo['nav'] = mipgbk2utf($keke_mipseo['nav']);
	$mipidsss = _getmipsiteinfoss();
	$tmp = file_get_contents('source/plugin/keke_mipseo/template/page.htm');
	if (strpos($tmp, '.kekemipboxs') == false) {
		$pp = authcode($mipidsss, 'ENCODE', 'keke');
		$arr = str_split($pp, 11);
		foreach ($arr as $ckey => $cval) {
			if ($ckey > 0 && $ckey < 3) {
				$arr1[] = $cval;
			} else {
				if ($ckey >= 3) {
					$arr2[] = $cval;
				}
			}
		}
		$df1 = implode(',.', $arr1);
		$df2 = implode(',#', $arr2);
		$con = str_replace(array('.kekemips', 'class="kekemip"', '.kekemipgz'), array('.kekemipboxs,.' . $df1, 'class="' . $arr[0] . '"', '#' . $df2), $tmp);
	}
	$nav = explode('/hhf/', str_replace(array("\r\n", "\n", "\r"), '/hhf/', $keke_mipseo['nav']));
	foreach ($nav as $key => $val) {
		if ($val) {
			$navarr = explode('|', $val);
			$ret[] = $navarr;
		}
	}
	return $ret;
}
function _getbid($block)
{
	$blockid = str_replace(array('<!--{block/', '}-->'), '', $block);
	$bid = intval(trim($blockid));
	return $bid;
}
function _miplysis_block($block)
{
	include_once libfile('function/block');
	$bid = _getbid($block);
	loadcache('blockclass');
	block_get_batch($bid);
	$data = block_fetch_content($bid, true);
	return $data;
}
function _getmiprecmod($diyid)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$diyid = _mipeditor_safe_replace($diyid);
	$rec_txtarr = explode('/hhf/', str_replace(array("\r\n", "\n", "\r"), '/hhf/', $diyid));
	foreach ($rec_txtarr as $k => $v) {
		$return .= mipgbk2utf(_miplysis_block($v));
	}
	return $return;
}
function _getmipurlss($mods, $atid)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$siteurl = $keke_mipseo['domain'] ? $keke_mipseo['domain'] : $_G['siteurl'];
	if ($mods == 2) {
		$mipurl = $siteurl . 'forum.php?mod=viewthread&tid=' . $atid . '&mip=1';
		if ($keke_mipseo['rewrite'] && $keke_mipseo['on']) {
			$mipurl = $siteurl . str_ireplace('{tid}', '' . $atid . '', $keke_mipseo['rewrite']);
		}
	} else {
		$mipurl = $siteurl . 'portal.php?mod=view&aid=' . $atid . '&mip=1';
		if ($keke_mipseo['rewritep'] && $keke_mipseo['on']) {
			$mipurl = $siteurl . str_ireplace('{id}', '' . $atid . '', $keke_mipseo['rewritep']);
		}
	}
	return $mipurl;
}
function _getmodtypearray()
{
	$modtypearray = array();
	$modtypes = array('1', '2', '3');
	$typelang = array(lang('plugin/keke_mipseo', '052'), lang('plugin/keke_mipseo', '053'), lang('plugin/keke_mipseo', '055'));
	foreach ($modtypes as $key => $modtype) {
		$displayary = array();
		foreach ($modtypes as $modtype1) {
			$displayary[$modtype1] = $modtype1 == $modtype ? '' : 'none';
		}
		$modtypearray[] = array($modtype, $typelang[$key], $displayary);
	}
	return $modtypearray;
}
function _getmipsiteinfoss()
{
	$qqids = K_QQID;
	return $qqids;
}
function _getfiswhere()
{
	if ($_GET['fids'] && $_GET['fids'][0] != 'all' && $_GET['come'] == 2) {
		if (!is_array($_GET['fids'])) {
			$_GET['fids'] = unserialize(base64_decode($_GET['fids']));
		}
		$fids = dimplode(daddslashes($_GET['fids']));
		$where .= ' AND fid in (' . $fids . ')';
		$fidstr = '&fids=' . base64_encode(serialize($_GET['fids']));
	}
	if ($_GET['come'] == 3) {
		if ($_GET['selectgroupid'] && $_GET['selectgroupid'][0] != 'all') {
			if (!is_array($_GET['selectgroupid'])) {
				$_GET['selectgroupid'] = unserialize(base64_decode($_GET['selectgroupid']));
			}
			$fids = dimplode(daddslashes($_GET['selectgroupid']));
			$allfid = DB::fetch_all('select fid from ' . DB::table('forum_forum') . ' where fup in (' . $fids . ')');
			foreach ($allfid as $fk => $fv) {
				$fidsa[] = $fv['fid'];
			}
			$fidsb = dimplode(daddslashes($fidsa));
			$where .= ' AND fid in (' . $fidsb . ')';
			$fidstr = '&selectgroupid=' . base64_encode(serialize($_GET['selectgroupid']));
		}
		$where .= ' AND isgroup=1';
	}
	$where .= ' AND displayorder>=0';
	$ret[0] = $where;
	$ret[1] = $fidstr;
	return $ret;
}
function _getallidss($where, $mods, $ppps = '')
{
	$ppp = 100;
	if ($ppps > 0 && $ppps < 100) {
		$ppp = intval($ppps);
	}
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if ($mods == 2) {
		$allid = DB::fetch_all('select tid from ' . DB::table('forum_thread') . ' where ' . $where . '  LIMIT ' . $startlimit . ',' . $ppp);
	} elseif ($mods == 1) {
		$allid = DB::fetch_all('select aid from ' . DB::table('portal_article_title') . ' where ' . $where . '  LIMIT ' . $startlimit . ',' . $ppp);
	}
	return $allid;
}
function _getmiptitle($mods = '', $idnum = '')
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$title = '';
	if ($mods == 2 || $mods == 6) {
		if ($keke_mipseo['title']) {
			if ($mods == 2) {
				$thread = C::t('forum_thread')->fetch($idnum);
				$forum = C::t('forum_forum')->fetch($thread['fid']);
				$forumname = $forum['name'];
				$subject = $thread['subject'];
			} else {
				$article = C::t('portal_article_title')->fetch($idnum);
				$category = C::t('portal_category')->fetch($article['catid']);
				$forumname = $category['catname'];
				$subject = $article['title'];
			}
			$title = str_replace(array('{subject}', '{bbname}', '{forumname}'), array($subject, $_G['setting']['bbname'], $forumname), $keke_mipseo['title']);
		}
	} else {
		if ($mods == 3 || $mods == 5) {
			if ($keke_mipseo['listtitle']) {
				if ($mods == 3) {
					$forum = C::t('forum_forum')->fetch($idnum);
					$forumname = $forum['name'];
				} else {
					$category = C::t('portal_category')->fetch($idnum);
					$forumname = $category['catname'];
				}
				$title = str_replace(array('{bbname}', '{forumname}'), array($_G['setting']['bbname'], $forumname), $keke_mipseo['listtitle']);
			}
		} else {
			$title = $keke_mipseo['indextitle'];
		}
	}
	$title = dhtmlspecialchars($title);
	return $title;
}
function _getmiplist($ppp, $fid)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$ppp = $ppp ? $ppp : 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$forum = C::t('forum_forum')->fetch($fid);
	$orderbyid = bindec($forum['simple'] & 128 ? 1 : 0 . ($forum['simple'] & 64 ? 1 : 0));
	$orders = array('lastpost', 'dateline', 'replies', 'views');
	$forum['orderby'] = $orders[$orderbyid];
	$forum['ascdesc'] = $forum['simple'] & 32 ? 'ASC' : 'DESC';
	$threadlist = array();
	$indexadd = '';
	$_GET['orderby'] = isset($forum['orderby']) ? $forum['orderby'] : 'lastpost';
	$_GET['ascdesc'] = isset($forum['ascdesc']) ? $forum['ascdesc'] : 'DESC';
	$_order = 'displayorder DESC, ' . $_GET['orderby'] . ' ' . $_GET['ascdesc'];
	$filterarr['inforum'] = $fid;
	$filterarr['sticky'] = 4;
	$filterarr['displayorder'] = array(0);
	if ($forum['allowglobalstick'] && $_G['setting']['mobile']['mobiledisplayorder3'] && (!$_GET['page'] || $_GET['page'] == 1)) {
		$quanju = DB::fetch_all('select tid from ' . DB::table('forum_thread') . ' where displayorder=3');
		foreach ($quanju as $qv) {
			$alltidarr[] = $qv['tid'];
		}
		$allfid = DB::fetch_all('select fid from ' . DB::table('forum_forum') . ' where fup=' . $forum['fup']);
		foreach ($allfid as $fv) {
			$allfidarr[] = $fv['fid'];
		}
		$allfidstr = dimplode(daddslashes($allfidarr));
		$alltid = DB::fetch_all('select tid from ' . DB::table('forum_thread') . ' where fid in (' . $allfidstr . ') AND displayorder=2');
		foreach ($alltid as $tv) {
			$alltidarr[] = $tv['tid'];
		}
		$alltids = DB::fetch_all('select tid from ' . DB::table('forum_thread') . ' where fid =' . $fid . ' AND displayorder=1');
		foreach ($alltids as $tva) {
			$alltidarr[] = $tva['tid'];
		}
		if ($alltidarr) {
			$tidss = dimplode($alltidarr);
			$threadlist = DB::fetch_all('select * from ' . DB::table('forum_thread') . ' where tid in (' . $tidss . ') ORDER BY dateline DESC');
		}
	}
	$ooo = C::t('forum_thread')->fetch_all_search($filterarr, $tableid, $startlimit, $ppp, $_order, '', $indexadd);
	$threadlist = array_merge($threadlist, $ooo);
	require_once libfile('function/post');
	foreach ($threadlist as $k => $v) {
		$imagelistkey = array();
		$threadtable = _getforum_attachment($v['tid']);
		$n = 0;
		foreach ($threadtable as $pic) {
			if ($pic['isimage'] && $n < 9) {
				$imagelistkey[] = getforumimg($pic['aid'], 0, 250, 250);
				$n++;
			}
		}
		$post = _getforumposts($v['tid']);
		if ($v['price'] && $v['special'] != 3) {
			if (strpos($post['message'], '[free]') !== false) {
				preg_match_all('/\\[free(.*?)\\](.*?)\\[\\/free\\]/', $post['message'], $matches);
				$post['message'] = $matches[2][0];
			} else {
				$post['message'] = mipgbk2utf(lang('plugin/keke_mipseo', '043'));
			}
		}
		$threadlist[$k]['message'] = mipgbk2utf(trim(messagecutstr($post['message'], 82)));
		$threadlist[$k]['subject'] = mipgbk2utf($v['subject']);
		$threadlist[$k]['img'] = $imagelistkey;
		$threadlist[$k]['imgcount'] = count($imagelistkey);
		$threadlist[$k]['pageurl'] = _getmippageurl(2, $v['tid']);
		$threadlist[$k]['time'] = mipgbk2utf(dgmdate($v['dateline'], 'u'));
		$threadlist[$k]['author'] = mipgbk2utf($v['author']);
	}
	$allcount = DB::result_first('select count(1) from ' . DB::table('forum_thread') . ' where fid=' . $fid . ' AND displayorder=0');
	$tmpurl = 'plugin.php?id=keke_mipseo&fid=' . $fid;
	$page = max(1, intval($_GET['page']));
	$page = $page ? $page : 1;
	$startlimit = ($page - 1) * $ppp;
	$multipage = multi($allcount, $ppp, $page, $tmpurl, '', 3);
	if ($keke_mipseo['rewritelist'] && $keke_mipseo['on']) {
		$multipage = preg_replace_callback('/<a([^\\>]*)?href\\=\\"([^\\>]*)?plugin\\.php\\?id\\=keke_mipseo(&(amp;)?fid\\=(\\w+)(&(amp;)?page=(\\d+))?)?\\"([^\\>]*)?\\>/i', '_rewmultipage', $multipage);
	}
	$multipage = _getlistpage($multipage);
	return $return = array('list' => $threadlist, 'multi' => $multipage);
}
function _rewmultipage($match)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$siteurl = !(strpos($match[1], 'http') === false) ? '' : $_G['siteurl'];
	$mipurl = $siteurl . str_replace(array('{fid}', '{page}'), array($match[5], $match[8]), $keke_mipseo['rewritelist']);
	$mipurls = '<a data-type="mip" href="' . $mipurl . '" ' . $match[9] . '>';
	return $mipurls;
}
function _getindexlistdata($ppp = '')
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$threadtable = array();
	$ppp = $ppp ? $ppp : intval($keke_mipseo['forumnum']);
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$bk = unserialize($keke_mipseo['bk']);
	if ($bk[0]) {
		$fidstr = dimplode(daddslashes($bk));
		$order = $keke_mipseo['px'] == 2 ? 'lastpost' : 'dateline';
		$conditions = $keke_mipseo['px'] == 2 ? ' AND digest>0' : '';
		$threadlist = DB::fetch_all('SELECT authorid,fid,author,tid,subject,dateline,fid FROM ' . DB::table('forum_thread') . ' WHERE fid in (' . $fidstr . ') AND displayorder>=0 ' . $conditions . ' ORDER BY ' . $order . ' DESC LIMIT  ' . $startlimit . ',' . $ppp);
		require_once libfile('function/post');
		foreach ($threadlist as $k => $v) {
			$imagelistkey = array();
			$threadtable = _getforum_attachment($v['tid']);
			$n = 0;
			foreach ($threadtable as $pic) {
				if ($pic['isimage'] && $n < 3) {
					$imagelistkey[] = getforumimg($pic['aid'], 0, 250, 250);
					$n++;
				}
			}
			$url = _getmippageurl(2, $v['tid']);
			$post = _getforumposts($v['tid']);
			$forum = _getforumss($v['fid']);
			$threadlist[$k]['forunmipurl'] = _getmippageurl(5, $v['fid']);
			$threadlist[$k]['message'] = mipgbk2utf(trim(messagecutstr($post['message'], 100)));
			$threadlist[$k]['subject'] = mipgbk2utf($v['subject']);
			$threadlist[$k]['forumname'] = mipgbk2utf($forum['name']);
			$threadlist[$k]['img'] = $imagelistkey;
			$threadlist[$k]['url'] = $url;
			$threadlist[$k]['imgcount'] = count($imagelistkey);
			$threadlist[$k]['time'] = mipgbk2utf(dgmdate($v['dateline'], 'u'));
			$threadlist[$k]['author'] = mipgbk2utf($v['author']);
		}
	}
	return $threadlist;
}
function _getlistpage($multipage)
{
	global $_G;
	$multipage = preg_replace('/\\<label\\>([\\s\\S]*)\\<\\/label\\>/i', '', $multipage);
	$multipage = str_replace('href', 'data-type="mip" href', $multipage);
	$multipage = mipgbk2utf($multipage);
	return $multipage;
}
function mipcategory_get_wheresqls($cat)
{
	$wheresql = '';
	if (is_array($cat)) {
		$catid = $cat['catid'];
		if (!empty($cat['subs'])) {
			include_once libfile('function/portalcp');
			$subcatids = category_get_childids('portal', $catid);
			$subcatids[] = $catid;
			$wheresql = 'at.catid IN (' . dimplode($subcatids) . ')';
		} else {
			$wheresql = 'at.catid=\'' . $catid . '\'';
		}
	}
	$wheresql .= ' AND at.status=\'0\'';
	return $wheresql;
}
function mipcategory_get_lists($ppp, $cid)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$catid = max(0, intval($cid));
	loadcache('portalcategory');
	$category = $_G['cache']['portalcategory'];
	$cat = $category[$catid];
	$cat = mipcategory_remake($catid);
	$wheresql = mipcategory_get_wheresqls($cat);
	$caturl = 'plugin.php?id=keke_mipseo&cid=' . $cid;
	$ppp = $ppp ? $ppp : 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	require_once libfile('function/post');
	$list = array();
	$pricount = 0;
	$multi = '';
	$count = C::t('portal_article_title')->fetch_all_by_sql($wheresql, '', 0, 0, 1, 'at');
	if ($count) {
		$query = C::t('portal_article_title')->fetch_all_by_sql($wheresql, 'ORDER BY at.dateline DESC', $startlimit, $ppp, 0, 'at');
		foreach ($query as $value) {
			$value['catname'] = $value['catid'] == $cat['catid'] ? $cat['catname'] : $_G['cache']['portalcategory'][$value['catid']]['catname'];
			$value['onerror'] = '';
			if ($value['pic']) {
				$value['pic'] = mippic_gets($value['pic'], '', $value['thumb'], $value['remote'], 1, 1);
			}
			$value['time'] = dgmdate($value['dateline']);
			$value['subject'] = mipgbk2utf($value['title']);
			$value['author'] = mipgbk2utf($value['username']);
			$value['imgcount'] = $value['pic'] ? 1 : 0;
			$value['img'] = array($value['pic']);
			$value['pageurl'] = _getmippageurl(1, $value['aid']);
			$value['message'] = mipgbk2utf(trim(messagecutstr($value['summary'], 82)));
			if ($value['status'] == 0 || $value['uid'] == $_G['uid'] || $_G['adminid'] == 1) {
				$list[] = $value;
			} else {
				$pricount++;
			}
		}
		$caturl = $_G['siteurl'] . 'plugin.php?id=keke_mipseo&cid=' . $cid;
		$multi = multi($count, $ppp, $page, $_G['siteurl'] . $caturl, '', 3);
		if ($keke_mipseo['rewriteplist'] && $keke_mipseo['on']) {
			$multi = preg_replace_callback('/<a([^\\>]*)?href\\=\\"([^\\>]*)?plugin\\.php\\?id\\=keke_mipseo(&(amp;)?cid\\=(\\w+)(&(amp;)?page=(\\d+))?)?\\"([^\\>]*)?\\>/i', '_rewmultipages', $multi);
		}
		$multi = _getlistpage($multi);
	}
	return $return = array('list' => $list, 'count' => $count, 'multi' => $multi, 'pricount' => $pricount);
}
function mipcategory_remake($catid)
{
	global $_G;
	$cat = $_G['cache']['portalcategory'][$catid];
	if (empty($cat)) {
		return array();
	}
	foreach ($_G['cache']['portalcategory'] as $value) {
		if ($value['catid'] == $cat['upid']) {
			$cat['ups'][$value['catid']] = $value;
			$upid = $value['catid'];
			while (!empty($upid)) {
				if (!empty($_G['cache']['portalcategory'][$upid]['upid'])) {
					$upid = $_G['cache']['portalcategory'][$upid]['upid'];
					$cat['ups'][$upid] = $_G['cache']['portalcategory'][$upid];
				} else {
					$upid = 0;
				}
			}
		} else {
			if ($value['upid'] == $cat['catid']) {
				$cat['subs'][$value['catid']] = $value;
			} elseif ($value['upid'] == $cat['upid']) {
				$cat['others'][$value['catid']] = $value;
			}
		}
	}
	if (!empty($cat['ups'])) {
		$cat['ups'] = array_reverse($cat['ups'], true);
	}
	return $cat;
}
function _rewmultipages($match)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$siteurl = !(strpos($match[1], 'http') === false) ? '' : $_G['siteurl'];
	$mipurl = $siteurl . str_replace(array('{catid}', '{page}'), array($match[5], $match[8]), $keke_mipseo['rewriteplist']);
	$mipurls = '<a data-type="mip" href="' . $mipurl . '" ' . $match[9] . '>';
	return $mipurls;
}
function mippic_gets($filepath, $type, $thumb, $remote, $return_thumb = 1, $hastype = '')
{
	global $_G;
	$url = $filepath;
	if ($return_thumb && $thumb) {
		$url = getimgthumbname($url);
	}
	if ($remote > 1 && $type == 'album') {
		$remote -= 2;
		$type = 'forum';
	}
	$type = $hastype ? '' : $type . '/';
	return ($remote ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']) . $type . $url;
}
function _getmippageurl($mod, $atid)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	$siteurl = $keke_mipseo['domain'] ? $keke_mipseo['domain'] : $_G['siteurl'];
	if ($mod == 1) {
		$mipurl = $siteurl . 'portal.php?mod=view&aid=' . $atid . '&mip=1';
		if ($keke_mipseo['rewritep'] && $keke_mipseo['on']) {
			$mipurl = $siteurl . str_ireplace('{id}', '' . $atid . '', $keke_mipseo['rewritep']);
		}
	} elseif ($mod == 2) {
		$mipurl = $siteurl . 'forum.php?mod=viewthread&tid=' . $atid . '&mip=1';
		if ($keke_mipseo['rewrite'] && $keke_mipseo['on']) {
			$mipurl = $siteurl . str_ireplace('{tid}', '' . $atid . '', $keke_mipseo['rewrite']);
		}
	} elseif ($mod == 3) {
		$mipurl = $siteurl . 'forum.php?mod=forumdisplay&fid=' . $atid . '&mip=1';
		if ($keke_mipseo['rewritelist'] && $keke_mipseo['on']) {
			$mipurl = $siteurl . str_replace(array('{fid}', '{page}'), array($atid, '{pages}'), $keke_mipseo['rewritelist']);
		}
	} elseif ($mod == 5) {
		$mipurl = $siteurl . 'forum.php?mod=forumdisplay&fid=' . $atid . '&mip=1';
		if ($keke_mipseo['rewritelist'] && $keke_mipseo['on']) {
			$mipurl = $siteurl . str_replace(array('{fid}', '{page}'), array($atid, 1), $keke_mipseo['rewritelist']);
		}
	}
	return $mipurl;
}
function _getforumposts($tid)
{
	$post = C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
	return $post;
}
function _getforumss($fid)
{
	return C::t('forum_forum')->fetch($fid);
}
function _getforum_attachment($tid)
{
	return C::t('forum_attachment_n')->fetch_all_by_id('tid:' . $tid, 'tid', $tid);
}
function _getxzhimglist($article)
{
	preg_match_all('/<mip-img[^>]*src=[\'"]?([^>\'"\\s]*)[\'"]?[^>]*>/i', $article['content'], $out);
	$n = 0;
	foreach ($out[1] as $v) {
		if (strpos($v, 'static/image/smiley') == false) {
			$imgarr[] = $v;
		}
	}
	$mcount = count($imgarr) == 2 ? 1 : 3;
	foreach ($imgarr as $picval) {
		if ($n < $mcount) {
			$img .= $picval . ',';
			$n++;
		}
	}
	$imgs = rtrim($img, ',');
	return $imgs;
}
function _getmipxzhseohead($article)
{
	global $_G;
	$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
	loadcache(array('keke_mipseo', 'plugin'));
	$keke_xzhseo = $_G['cache']['plugin']['keke_xzhseo'];
	$piclist = _getxzhimglist($article);
	$mod = 0;
	$ret = array();
	if ($_GET['tid']) {
		$mod = 2;
		$atid = intval($_GET['tid']);
	} elseif ($_GET['aid']) {
		$mod = 1;
		$atid = intval($_GET['aid']);
	}
	if ($keke_xzhseo && $mod && $keke_mipseo['xzh']) {
		$ret = array('appid' => dhtmlspecialchars($keke_xzhseo['appid']), 'subject' => $article['title'], 'images' => $piclist, 'msg' => _getmsgcutmsg($article['content']), 'dateline' => _getxzhdateline($article['dataline']), 'url' => _getmippageurl($mod, $atid));
	}
	return $ret;
}
function _getxzhdateline($str)
{
	$search = array('/', ' ');
	$replace = array('-', 'T');
	return str_replace($search, $replace, $str);
}
function _getmsgcutmsg($msgs)
{
	global $_G;
	loadcache(array('keke_mipseo', 'plugin'));
	$keke_xzhseo = $_G['cache']['plugin']['keke_xzhseo'];
	$cd = $keke_xzhseo['cd'] ? intval($keke_xzhseo['cd']) : 120;
	if (!$msgs) {
		$msgs = $article['title'];
	}
	$smsg = str_replace(array("\r\n", "\r", "\n"), '', cutstr(strip_tags(preg_replace('/(<i class=\\"pstatus\\">.*<\\/i>)/is', '', preg_replace('/(<ignore_js_op>.*<\\/ignore_js_op>)/is', '', $msgs))), $cd, ''));
	return _mipmb_trim($smsg);
}
function _mipmb_trim($str)
{
	$search = array(' ', '��', "\n", "\r", '	');
	$replace = array('', '', '', '', '');
	return str_replace($search, $replace, $str);
}
function _mipeditor_safe_replace($content)
{
	$tags = array('\'<iframe[^>]*?>.*?</iframe>\'is', '\'<frame[^>]*?>.*?</frame>\'is', '\'<script[^>]*?>.*?</script>\'is', '\'<head[^>]*?>.*?</head>\'is', '\'<title[^>]*?>.*?</title>\'is', '\'<meta[^>]*?>\'is', '\'<link[^>]*?>\'is');
	return preg_replace($tags, '', $content);
}