<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_keke_mipseo{
	function global_header(){
		global $_G,$postlist,$article;
		$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];	
		$mipurl=$return='';
		$siteurl=$keke_mipseo['domain']?$keke_mipseo['domain']:$_G['siteurl'];
		if(CURSCRIPT=='forum' && $_G['tid']){
			$section = empty($keke_mipseo['forum']) ? array() : unserialize($keke_mipseo['forum']);
			if(!(empty($section[0]) || in_array($_G['fid'],$section)) && !$_G['thread']['isgroup']){
				return '';
			}
			$urltmp=$keke_mipseo['rewrite'];
			$mipurls=$siteurl.'plugin.php?id=keke_mipseo&tid='.$_G['tid'];
			$this->_openmip();
			$mipurl=$siteurl.'forum.php?mod=viewthread&tid='.$_G['tid'].'&mip=1';
			if($urltmp && $keke_mipseo['on']){
				$mipurl=$siteurl.str_ireplace("{tid}","".$_G['tid']."",$urltmp);
			}
			$mod=array(2,$_G['tid']);
		}elseif(CURSCRIPT=='portal' && $_GET['aid']){
			$urltmpa=$keke_mipseo['rewritep'];
			$mipurls=$siteurl.'plugin.php?id=keke_mipseo&aid='.$_GET['aid'];
			$this->_openmip();
			$mipurl=$siteurl.'portal.php?mod=view&aid='.$_GET['aid'].'&mip=1';
			if($urltmpa && $keke_mipseo['on']){
				$mipurl=$siteurl.str_ireplace("{id}","".$_GET['aid']."",$urltmpa);
			}
			$mod=array(1,$_GET['aid']);
		}
		if($mipurl){
			$return='<link rel="miphtml" href="'.$mipurl.'">';
		}

		return $return;
	}
	
	function _openmip(){
		if($_GET['mip']){
			include_once DISCUZ_ROOT.'source/plugin/keke_mipseo/keke_mipseo.inc.php';exit;
		}
	}
}

class mobileplugin_keke_mipseo extends plugin_keke_mipseo{
	function global_header_mobile(){
		return $this->global_header();
	}
}