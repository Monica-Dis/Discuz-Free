<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
global $_G;
$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
include_once DISCUZ_ROOT.'source/plugin/keke_mipseo/function.php';
$tid=intval($_GET['tid']);
$aid=intval($_GET['aid']);
$fid=intval($_GET['fid']);
$cid=intval($_GET['cid']);
$bbname=mipgbk2utf(dhtmlspecialchars($keke_mipseo['bbname']));
$btntxt=mipgbk2utf(dhtmlspecialchars($keke_mipseo['btntxt']));
$nav=_getmipnav();
$indexurl=_getmipurls(6,0);
$foottxt=mipgbk2utf(_mipeditor_safe_replace($keke_mipseo['foottxt']));
if($tid){
	$url=_getmipurls(2,$tid);
	$article = _getmipthreads($tid);
	$title=mipgbk2utf(_getmiptitle(2,$tid));
}elseif($aid){
	$url=_getmipurls(1,$aid);
	$article = _getmiparticle($aid);
	$title=mipgbk2utf(_getmiptitle(6,$aid));
}elseif($fid){
	$url=_getmipurls(3,$fid);
	$list = _getmiplist(20,$fid);
	$title=mipgbk2utf(_getmiptitle(3,$fid));
}elseif($cid){
	$url=_getmipurls(5,$cid);
	$list = mipcategory_get_lists(20,$cid);
	$title=mipgbk2utf(_getmiptitle(5,$cid));
}else{
	$url=$_G['siteurl'];
	$indexlist=_getindexlistdata();
	$title=mipgbk2utf(_getmiptitle());
}
$lang07=mipgbk2utf(lang('plugin/keke_mipseo', 'f07'));
$lang08=mipgbk2utf(lang('plugin/keke_mipseo', 'f08'));
$lang066=mipgbk2utf(lang('plugin/keke_mipseo', '066'));
$lang067=mipgbk2utf(lang('plugin/keke_mipseo', '067'));
$forumtitle=mipgbk2utf(dhtmlspecialchars($keke_mipseo['forumtitle']));
$rec_text=mipgbk2utf(_getmiprecmod($keke_mipseo['rectxt']));
$topdiy=mipgbk2utf(_getmiprecmod($keke_mipseo['topdiy']));
$indexdiy=mipgbk2utf(_getmiprecmod($keke_mipseo['indexdiy']));
$ccss=_mipeditor_safe_replace($keke_mipseo['ccss']);
$tjtoken=dhtmlspecialchars($keke_mipseo['tjtoken']);
$topclolur=$keke_mipseo['topcolour']?dhtmlspecialchars($keke_mipseo['topcolour']):'#fff';
$txtclolur=$keke_mipseo['titlecolour']?dhtmlspecialchars($keke_mipseo['titlecolour']):'#b29780';
include template('keke_mipseo:page');