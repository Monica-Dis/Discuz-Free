<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	@include_once DISCUZ_ROOT.'source/plugin/keke_mipseo/function.php';
	loadcache('plugin');
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
				C::t('#keke_mipseo#keke_mipseo')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/keke_mipseo', '013'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_mipseo&pmod=admincp_log', 'succeed');
	}
	$counts = C::t('#keke_mipseo#keke_mipseo')->fetch_pe();
	$counts=$counts?$counts:(($counts==NULL)?lang('plugin/keke_mipseo', '030'):0);
	showtips(lang('plugin/keke_mipseo', '028').' '.$counts.' '.lang('plugin/keke_mipseo', '029'));
	
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_log");	
	showtableheader(lang('plugin/keke_mipseo', '001'));
    showsubtitle(array(lang('plugin/keke_mipseo', '014'),lang('plugin/keke_mipseo', '015'),lang('plugin/keke_mipseo', '016'),lang('plugin/keke_mipseo', '019'),lang('plugin/keke_mipseo', '020')));
	$ppp=20;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_mipseo&pmod=admincp_log';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$count = C::t('#keke_mipseo#keke_mipseo')->count_all();
	if($count){
		$liatdata = C::t('#keke_mipseo#keke_mipseo')->fetch_all_by_limit($startlimit,$ppp);
		foreach($liatdata as $key=>$val){
			$state='';
			switch ($val['state']) {
				case 1:$state=lang('plugin/keke_mipseo', '009');break;
				case 2:$state=lang('plugin/keke_mipseo', '012').lang('plugin/keke_mipseo', '010');break;
				case 3:$state=lang('plugin/keke_mipseo', '011');break;
				default:$state=lang('plugin/keke_mipseo', '012').$val['msg'];
			}
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = '<a href="'.$val['url'].'" target="_blank">'._getmipsubject($val['atid'],$val['mods']).'</a>';
			$table[2] = '<a href="'.$val['url'].'" target="_blank">'.$val['url'].'</a>';
			$table[3] = $state;
			$table[4] = dgmdate($val['time'], 'Y/m/d H:i');
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$tmpurl);
	echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter(); /*dism _ taobao _ com*/
	showformfooter(); /*dism��taobao��com*/