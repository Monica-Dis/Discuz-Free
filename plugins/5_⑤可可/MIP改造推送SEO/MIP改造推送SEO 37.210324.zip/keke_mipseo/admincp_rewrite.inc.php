<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
loadcache("plugin");
$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
include_once DISCUZ_ROOT.'source/plugin/keke_mipseo/function.php';
$indextmp=_mip_str_rep(dhtmlspecialchars($keke_mipseo['rewriteindex']));
$flisttmp=_mip_str_rep(dhtmlspecialchars($keke_mipseo['rewritelist']));
$plisttmp=_mip_str_rep(dhtmlspecialchars($keke_mipseo['rewriteplist']));
$urltmp=_mip_str_rep(dhtmlspecialchars($keke_mipseo['rewrite']));
$urltmpa=_mip_str_rep(dhtmlspecialchars($keke_mipseo['rewritep']));
showtips(lang('plugin/keke_mipseo', 'f06'));
$strtmp= '<br><h1>'.lang('plugin/keke_mipseo', 'f01').'</h1>
<pre class="colorbox">

RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$indextmp.'$ $1/plugin.php?id=keke_mipseo%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$flisttmp.'$ $1/plugin.php?id=keke_mipseo&fid=$2&page=$3%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$plisttmp.'$ $1/plugin.php?id=keke_mipseo&cid=$2&page=$3%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$urltmp.'$ $1/plugin.php?id=keke_mipseo&tid=$2&%1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^(.*)/'.$urltmpa.'$ $1/plugin.php?id=keke_mipseo&aid=$2&%1

</pre>

<h1>'.lang('plugin/keke_mipseo', 'f02').'</h1>
<pre class="colorbox">

RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$indextmp.'$ plugin.php?id=keke_mipseo
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$flisttmp.'$ plugin.php?id=keke_mipseo&fid=$1&page=$2
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$plisttmp.'$ plugin.php?id=keke_mipseo&cid=$1&page=$2
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$urltmp.'$ plugin.php?id=keke_mipseo&tid=$1
RewriteCond %{QUERY_STRING} ^(.*)$
RewriteRule ^'.$urltmpa.'$ plugin.php?id=keke_mipseo&aid=$1
</pre>

<h1>Nginx Web Server</h1>
<pre class="colorbox">

rewrite ^([^\.]*)/'.$indextmp.'$ $1/plugin.php?id=keke_mipseo last;
rewrite ^([^\.]*)/'.$flisttmp.'$ $1/plugin.php?id=keke_mipseo&fid=$2&page=$3 last;
rewrite ^([^\.]*)/'.$plisttmp.'$ $1/plugin.php?id=keke_mipseo&cid=$2&page=$3 last;
rewrite ^([^\.]*)/'.$urltmp.'$ $1/plugin.php?id=keke_mipseo&tid=$2 last;
rewrite ^([^\.]*)/'.$urltmpa.'$ $1/plugin.php?id=keke_mipseo&aid=$2 last;

</pre>

<h1>'.lang('plugin/keke_mipseo', 'f03').'</h1>
<pre class="colorbox">

RewriteRule ^(.*)/'.$indextmp.'(\?(.*))*$ $1/plugin\.php\?id=keke_mipseo
RewriteRule ^(.*)/'.$flisttmp.'(\?(.*))*$ $1/plugin\.php\?id=keke_mipseo&fid=$2&page=$3
RewriteRule ^(.*)/'.$plisttmp.'(\?(.*))*$ $1/plugin\.php\?id=keke_mipseo&cid=$2&page=$3
RewriteRule ^(.*)/'.$urltmp.'(\?(.*))*$ $1/plugin\.php\?id=keke_mipseo&tid=$2
RewriteRule ^(.*)/'.$urltmpa.'(\?(.*))*$ $1/plugin\.php\?id=keke_mipseo&aid=$2

</pre>

<h1>'.lang('plugin/keke_mipseo', 'f05').'</h1>
<pre class="colorbox">

&lt;rule name="mip_forun"&gt;
	&lt;match url="^(.*/)*'.$flisttmp.'\?*(.*)$" /&gt;
	&lt;conditions logicalGrouping="MatchAll" trackAllCaptures="false" /&gt;
	&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_mipseo&amp;amp;fid={R:2}&amp;amp;page={R:3}" /&gt;
&lt;/rule&gt;
&lt;rule name="mip_portal"&gt;
	&lt;match url="^(.*/)*'.$plisttmp.'\?*(.*)$" /&gt;
	&lt;conditions logicalGrouping="MatchAll" trackAllCaptures="false" /&gt;
	&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_mipseo&amp;amp;cid={R:2}&amp;amp;page={R:3}" /&gt;
&lt;/rule&gt;
&lt;rule name="mip_thread"&gt;
	&lt;match url="^(.*/)*'.$urltmp.'\?*(.*)$" /&gt;
	&lt;conditions logicalGrouping="MatchAll" trackAllCaptures="false" /&gt;
	&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_mipseo&amp;amp;tid={R:2}" /&gt;
&lt;/rule&gt;
&lt;rule name="mip_article"&gt;
	&lt;match url="^(.*/)*'.$urltmpa.'\?*(.*)$" /&gt;
	&lt;conditions logicalGrouping="MatchAll" trackAllCaptures="false" /&gt;
	&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_mipseo&amp;amp;aid={R:2}" /&gt;
&lt;/rule&gt;
&lt;rule name="mip_index"&gt;
	&lt;match url="^(.*/)*'.$indextmp.'\?*(.*)$" /&gt;
	&lt;conditions logicalGrouping="MatchAll" trackAllCaptures="false" /&gt;
	&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_mipseo" /&gt;
&lt;/rule&gt;

</pre>

';
echo $strtmp;