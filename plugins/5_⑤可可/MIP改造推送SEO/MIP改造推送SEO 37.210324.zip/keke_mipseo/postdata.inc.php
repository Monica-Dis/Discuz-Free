<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

global $_G;	
$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
@include_once DISCUZ_ROOT.'source/plugin/keke_mipseo/function.php';
$atid=intval($_GET['atid']);
$mods=intval($_GET['mods']);
if($_GET['formhash'] != $_G['formhash']){
	exit(json_encode(array('state'=>10,'msg'=>'formhash error')));
}
if(!$_GET['atid']){
	exit(json_encode(array('state'=>11,'msg'=>'atid error')));
}
if(!$_GET['mods'] || !(in_array($_GET['mods'],array('1','2')))){
	exit(json_encode(array('state'=>12,'msg'=>'mods error')));
}
$checkpost=_getmipstates($atid,$mods);
if($mods==2){
	$thread = C::t('forum_thread')->fetch($atid);
	$section = empty($keke_mipseo['forum']) ? array() : unserialize($keke_mipseo['forum']);
	if(!(empty($section[0]) || in_array($thread['fid'],$section)) && !$thread['isgroup']){
		exit(json_encode(array('state'=>15,'msg'=>'No permission')));
	}
	$dis=_gettdisplayorder($atid);
	if($dis<0){
		exit(json_encode(array('state'=>13,'msg'=>'displayorder<0')));
	}
}
if($checkpost){
	exit(json_encode(array('state'=>9,'msg'=>'exist')));
}
exit(_postmip2baidu($atid,$mods));