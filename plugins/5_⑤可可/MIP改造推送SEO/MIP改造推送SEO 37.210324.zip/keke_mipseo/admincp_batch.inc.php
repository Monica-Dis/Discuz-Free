<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	@include_once DISCUZ_ROOT.'source/plugin/keke_mipseo/function.php';
	$counts = C::t('#keke_mipseo#keke_mipseo')->fetch_pe();
	if ($_GET["ac"]=='t') {
		if($_GET['formhash']!=FORMHASH){
			cpmsg(lang('plugin/keke_mipseo', '047'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_mipseo&pmod=admincp_batch', 'error');
		}
		$allid=array();
		$where='1=1';
		if($_GET['starttime']){
			$where.=' AND dateline>\''.daddslashes(strtotime($_GET['starttime'])).'\'';
		}
		if($_GET['endtime']){
			$where.=' AND dateline<\''.daddslashes(strtotime($_GET['endtime'])).'\'';
		}
		if($_GET['come']==2 || $_GET['come']==3){
			$getwhere=_getfiswhere();
			$where.=$getwhere[0];
			$fidstr=$getwhere[1]?$getwhere[1]:'';
			$allid=_getallidss($where,2,$counts);
		}elseif($_GET['come']==1){
			$allid=_getallidss($where,1,$counts);
		}
		if($allid){
			foreach($allid as $k=>$v){
				if($v['tid']){
					$atidsarr[]=$v['tid'];
					$modsid=2;
				}elseif($v['aid']){
					$atidsarr[]=$v['aid'];
					$modsid=1;
				}
			}
			$atidsstr=dimplode(daddslashes($atidsarr));
			$postarrs=_getpostarrss($modsid,$atidsstr);
			foreach($postarrs as $postk=>$postv){
				$postarrss[]=$postv['atid'];
			}
			$n=0;
			foreach($allid as $ka=>$va){
				$instarr=array();
				if($v['tid']){
					if(in_array($va['tid'],$postarrss)){
						$n++;
					}else{
						$urls[]=$urlx=_getmipurlss(2,$va['tid']);
						$instarr['url']=_getmipurlss(2,$va['tid']);
						$instarr['mode']=2;
						$instarr['atid']=$va['tid'];
					}
				}elseif($v['aid']){
					if(in_array($va['aid'],$postarrss)){
						$n++;
					}else{
						$urls[]=$urlx=_getmipurlss(1,$va['aid']);
						$instarr['url']=_getmipurlss(1,$va['aid']);
						$instarr['mode']=1;
						$instarr['atid']=$va['aid'];
					}
				}
				if($instarr['url'] && $instarr['atid']){
					$instarrs[]=$instarr;
				}
			}
			if(!$instarrs){
				$rets['go']=1;
			}else{
				$rets=_batchpostmip2baidu($urls,$instarrs);
			}
			$rets['filter']=$n;
		}
		$rets['success_mip']=$rets['success_mip']+ $_GET['success_mip'];
		$netpage=$page+1;
		$rets['filter']=$rets['filter']+ $_GET['filter'];
		if(($rets['go'] || $rets['remain_mip']) && $allid){
			cpmsg(lang('plugin/keke_mipseo', '048').$page.lang('plugin/keke_mipseo', '049'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_mipseo&ac=t'.$fidstr.'&filter='.$rets['filter'].'&success_mip='.$rets['success_mip'].'&pmod=admincp_batch&starttime='.$_GET['starttime'].'&endtime='.$_GET['endtime'].'&come='.$_GET['come'].'&page='.$netpage.'&formhash='.FORMHASH, 'loading', '', FALSE);
		}
		cpmsg(lang('plugin/keke_mipseo', '050').''.$rets['success_mip'].lang('plugin/keke_mipseo', '051').' , '.lang('plugin/keke_mipseo', '065').' '.$rets['filter'].' '.lang('plugin/keke_mipseo', '051'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_mipseo&pmod=admincp_log', 'succeed', '', FALSE);
	}
	$come = array(array('1',lang('plugin/keke_mipseo', '052')), array('2', lang('plugin/keke_mipseo', '053')), array('3', lang('plugin/keke_mipseo', '055')));
	$counts=$counts?$counts:(($counts==NULL)?lang('plugin/keke_mipseo', '030'):0);
	
	showtips(lang('plugin/keke_mipseo', '046').' '.$counts.' '.lang('plugin/keke_mipseo', '029'));	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_batch");	
	showtableheader(lang('plugin/keke_mipseo', '056'));
	
	echo '<script src="static/js/calendar.js"></script><input type="hidden" name="formhash" value="'.FORMHASH.'" /><input type="hidden" name="ac" value="t" />';
	include_once libfile('function/forumlist');
	require_once libfile('function/group');
	$forumselect = '<select name="fids[]" multiple="multiple" size="10"><option value="all">'.$lang['all'].'</option>'.forumselect(FALSE, 0, 0, TRUE).'</select>';
	$groupselect = get_groupselect(0, $_GET['selectgroupid'], 0);
	$modtypearray=_getmodtypearray(); 
	showsetting(lang('plugin/keke_mipseo', '057'), array('come', $modtypearray), 2, 'mradio');

	showtagheader('tbody', '1');
	showtitle(lang('plugin/keke_mipseo', '058'));
	showtagfooter('tbody');

	showtagheader('tbody', '2','1');
	showtitle(lang('plugin/keke_mipseo', '059'));
	showsetting(lang('plugin/keke_mipseo', '060'), '', '', $forumselect);
	showtagfooter('tbody');
	
	showtagheader('tbody', '3');
	showtitle(lang('plugin/keke_mipseo', '061'));
	showsetting('groups_editgroup_category', '', '', '<select name="selectgroupid[]" multiple="multiple" size="10"><option value="all"'.(in_array('all', $_GET['selectgroupid']) ? ' selected' : '').'>'.cplang('unlimited').'</option>'.$groupselect.'</select>');
	showtagfooter('tbody');
	showsetting(lang('plugin/keke_mipseo', '062'), 'starttime', '', 'calendar');
	showsetting(lang('plugin/keke_mipseo', '063'), 'endtime', '', 'calendar');
	showsubmit('forumset', 'submit');
    showtablefooter(); /*dism _ taobao _ com*/
	showformfooter(); /*dism��taobao��com*/