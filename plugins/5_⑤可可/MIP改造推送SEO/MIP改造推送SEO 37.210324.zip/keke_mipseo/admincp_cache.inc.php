<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	@include_once DISCUZ_ROOT.'source/plugin/keke_mipseo/function.php';
	loadcache('plugin');
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
				C::t('#keke_mipseo#keke_mipseo_cache')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/keke_mipseo', '013'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_mipseo&pmod=admincp_cache', 'succeed');
	}
	if (submitcheck("cache")) {
		$url=$_GET['url'];
		_mipcache($url);
		cpmsg(lang('plugin/keke_mipseo', '013'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_mipseo&pmod=admincp_cache', 'succeed');
	}
	showtips(lang('plugin/keke_mipseo', '031'));
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_cache");	
	showtableheader(lang('plugin/keke_mipseo', '038'));
	showsetting('MIP_URL','url','','text','','',lang('plugin/keke_mipseo', '039'));
	showsubmit('cache', 'submit');
	showtablefooter(); /*dism _ taobao _ com*/
	showtableheader(lang('plugin/keke_mipseo', '040'));
    showsubtitle(array(lang('plugin/keke_mipseo', '014'),lang('plugin/keke_mipseo', '032'),lang('plugin/keke_mipseo', '033'),lang('plugin/keke_mipseo', '035'),lang('plugin/keke_mipseo', '034')));
	$ppp=20;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_mipseo&pmod=admincp_cache';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$count = C::t('#keke_mipseo#keke_mipseo_cache')->count_all();
	$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
	if($count){
		$liatdata = C::t('#keke_mipseo#keke_mipseo_cache')->fetch_all_by_limit($startlimit,$ppp);
		foreach($liatdata as $key=>$val){
			$state='';
			switch ($val['state']) {
				case 0:$state=lang('plugin/keke_mipseo', '036');break;
				case 1:$state=lang('plugin/keke_mipseo', '037');break;
			}
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$sys_protocal.$val['id'].'" />';
			$table[1] = '<a href="'.$sys_protocal.$val['url'].'" target="_blank">'.$val['url'].'</a>';
			$table[2] = $state;
			$table[3] = $val['msg'];
			$table[4] = dgmdate($val['time'], 'Y/m/d H:i');
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$tmpurl);
	echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter(); /*dism _ taobao _ com*/
	showformfooter(); /*dism��taobao��com*/