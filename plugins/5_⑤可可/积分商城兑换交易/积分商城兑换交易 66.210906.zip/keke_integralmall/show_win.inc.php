<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
$tid=intval($_GET['tid']);
$pid=intval($_GET['pid']);
$ac=$_GET['ac'];
$keke_integralmall['waptcl']=$keke_integralmall['waptcl']? dhtmlspecialchars($keke_integralmall['waptcl']): '#fee101';
include_once DISCUZ_ROOT . './source/plugin/keke_integralmall/function/function_fun.php';
$goodsdata=_get_goodsdata($tid);
$credis=$goodsdata['credit'] ? $goodsdata['credit'] : $keke_integralmall['jf'];
$creditname=$_G['setting']['extcredits'][$credis]['title'];
$autoreplytmp=dhtmlspecialchars($keke_integralmall['replytmp']);
$autoreplyarr=explode('///',trim($autoreplytmp));
$autoreply=$autoreplyarr[mt_rand(0,(count($autoreplyarr))-1)];
$autoreply=str_ireplace("[name]","".$goodsdata['subject']."",$autoreply);
$autoreply=str_ireplace("[price]","".$goodsdata['price'].$creditname."",$autoreply);
$nowcredit = getuserprofile('extcredits'.$credis);
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
if($_GET['formhash'] != $_G['formhash'] && !($_GET['ac']=='buylist')) {
	return;
}
$isauthor=0;
$thread = C::t('forum_thread')->fetch($tid);

$satedata=C::t('#keke_integralmall#keke_integralmall_set')->fetchfirst_by_uid($thread['authorid']);
if($satedata['val']){
	$valarr=explode(',',$satedata['val']);
}
if($goodsdata['uid']==$_G['uid'] || $_G['groupid']==1 || ($satedata['val'] && in_array($_G['uid'],$valarr))){
	$isauthor=1;
}
include_once DISCUZ_ROOT . './source/plugin/keke_integralmall/function/function_fun.php';
if($ac=='xd'){
	$jumpurl=dhtmlspecialchars($keke_integralmall['jumpurl']);
}elseif($ac=='addr'){
	$pos=intval($_GET['position']);
	include_once libfile('function/profile');
	$addrhtml = showdistrict(array(0,0,0), array('province', 'city', 'edist','xiangzhen'),'addrbox', 3, 'reside');
}elseif($ac=='km'){
	$pidandfid=_getfirstpid($tid);
	$pids=intval($pidandfid[1]);
	$fids=intval($pidandfid[0]);
    $ppp=50;
    $tmpurl='plugin.php?id=keke_integralmall:show_win&tid='.$tid.'&fid='.$fids.'&pid='.$pids.'&ac=km&formhash='.FORMHASH;
    $page = max(1, intval($_GET['page']));
    $startlimit = ($page - 1) * $ppp;
	$where='tid='.$tid;
    if(!$isauthor){
        $where.=' AND uid='.$_G['uid'];
    }
    $kmcount=C::t('#keke_integralmall#keke_integralmall_km')->count_all_by_where($where);
	$kmdata=C::t('#keke_integralmall#keke_integralmall_km')->fetch_all_by_where($where,$startlimit,$ppp);
	foreach($kmdata as $val){
		$time=mall_checkmobile()?date('Y-m-d H:i:s',$val['time']):date('y-m-d',$val['time']);
		$himg='';
		$val['km']=preg_replace("/\[url\](.+?)\[\/url\]/i","<a href=\"\\1\" target=\"_blank\">\\1</a>", $val['km']);
		if($isauthor){
			if($val['uid']){
				$usname=getuserbyuid($val['uid']);
				$usname=$usname['username'];
				$state='<span style="color:#3C0"><img src="source/plugin/keke_integralmall/template/images/ico1.png" width="13" height="13" style="margin-right:5px"/>'.lang('plugin/keke_integralmall', 'mall017').'</span>';
				$himg='<img src="source/plugin/keke_integralmall/template/images/noavatar_small.gif" width="16" height="16" />';
			}else{
				$usname=$time=mall_checkmobile()?'':'-';
				$state='<span style="color:#C30"><img src="source/plugin/keke_integralmall/template/images/ico2.png" width="13" height="13" style="margin-right:5px"/>'.lang('plugin/keke_integralmall', 'mall018').'</span>';
			}
			if($goodsdata['cfxs'] && !$val['uid']){
				$cfkm=$val['km'];
				continue;
			}
			if(mall_checkmobile()){
				$bot=$himg?'<span class="bot"><span class="gmusname">'.$himg.$usname.'</span><span class="gmtime">'.$time.'</span></span>':'<span class="bot"><span class="wff">'.lang('plugin/keke_integralmall', 'mall089').'</span></span>';
				$kmlist.='<div class="kmmodes"><span class="kmnr">'.$val['km'].'</span>'.$bot.'<span class="gmstate">'.$state.'</span></div>';
			}else{
				$kmlist.='<div class="kmmodes"><span class="kmnr">'.$val['km'].'</span><span class="gmusname">'.$usname.'</span><span class="gmtime">'.$time.'</span><span class="gmstate">'.$state.'</span></div>';
			}
		}else{
				$bot=mall_checkmobile()?'<span class="bot"><span class="dhsj">'.lang('plugin/keke_integralmall', 'mall090').'</span></span>':'';
				$kmlist.='<div class="kmmodes"><span class="kmnr" id="foo'.$val['id'].'">'.$val['km'].' </span>'.$bot.'<span class="kmtime">'.$time.'</span></div>';
		}
	}
	$multipage = mall_checkmobile()?multi($kmcount, $ppp, $page, $_G['siteurl'].$tmpurl,'',3):multi($kmcount, $ppp, $page, $_G['siteurl'].$tmpurl);
}elseif($ac=='kmedit'){
	if($goodsdata['uid']!=$_G['uid']){
		exit(lang('plugin/keke_integralmall', 'mall091'));
	}
    $ppp=20;
    $tmpurl='plugin.php?id=keke_integralmall:show_win&tid='.$tid.'&ac=kmedit&formhash='.FORMHASH;
    $page = max(1, intval($_GET['page']));
    $startlimit = ($page - 1) * $ppp;
	$where='tid='.$tid;
    $kmcount=C::t('#keke_integralmall#keke_integralmall_km')->count_all_by_where($where);
	$kmdatas=C::t('#keke_integralmall#keke_integralmall_km')->fetch_all_by_where($where,$startlimit,$ppp);
	if($goodsdata['cfxs']){
		$kmdatas=array($kmdatas[0]);
	}
    $multipage = mall_checkmobile()?multi($kmcount, $ppp, $page, $_G['siteurl'].$tmpurl,'',3):multi($kmcount, $ppp, $page, $_G['siteurl'].$tmpurl);
}elseif($ac=='delgoods'){
	if($goodsdata['uid']!=$_G['uid']){
		exit(lang('plugin/keke_integralmall', 'mall091'));
	}
	if(!$keke_integralmall['delgoods']){
		exit('Prohibit deletion');
	}
	C::t('#keke_integralmall#keke_integralmall')->delete($tid);
	C::t('forum_thread')->update($tid,array('displayorder'=>-4));
	showmessage(lang('plugin/keke_integralmall', 'mall092'),$rturl, '', array('showdialog' => true, 'closetime' => 3, 'extrajs' => '<script>setTimeout(function(){location.reload();}, 2000);</script>'));
}elseif($ac=='dd'){
	if($isauthor){
		$ddlist=_get_buylist($tid,5,2,0,0,$_GET['page']);
	}else{
		$ddlist=_get_buylist($tid,5,2,$_G['uid'],0,$_GET['page']);
	}
}elseif($ac=='fahuo'){
	$logid=intval($_GET['logid']);
	$logdata=C::t('#keke_integralmall#keke_integralmall_log')->fetch($logid);
	$gmusnd=getuserbyuid($logdata['uid']);
	$gmusn=$gmusnd['username'];
	$re=intval($_GET['re']);
	$kdinc=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',dhtmlspecialchars($keke_integralmall['kdgs'])));
	foreach($kdinc as $k=>$val){
		if($logdata['kd']==$val) $selected='selected="selected"';else $selected='';
		$op.='<option value="'.$val.'" '.$selected.'>'.$val.'</option>';
	}
	if($logdata['kd']==lang('plugin/keke_integralmall', 'mall093')){
		$ztselected='selected="selected"';
	}elseif($logdata['kd']==lang('plugin/keke_integralmall', 'mall095')){
		$qtselected='selected="selected"';
	}
	$op.='<option value="'.lang('plugin/keke_integralmall', 'mall093').'" '.$ztselected.'>'.lang('plugin/keke_integralmall', 'mall093').'</option><option value="'.lang('plugin/keke_integralmall', 'mall095').'" '.$qtselected.'>'.lang('plugin/keke_integralmall', 'mall095').'</option>';
	
	$members = getuserbyuid($logdata['fhuid']);
	$fhuser=$members['username'];
	
}elseif($ac=='buylist'){
	$tid=$tid?$tid:0;
	$op=intval($_GET['op']);
	$bkarr=unserialize($keke_integralmall['bk']);
	$bkcount=count($bkarr);
	if($_GET['type']==1){
		$mybuylist=_get_buylist($tid,10,3,$_G['uid']);
	}else{
		if($op==1){
			$mybuylist=_get_mygoods($_G['uid']);
		}else{
			$mybuylist=_get_buylist($tid,10,3,$_G['uid'],2);
		}
	}
	
}elseif($ac=='newthread'){
	$bkarr=unserialize($keke_integralmall['bk']);
	foreach($bkarr as $val){
		$bklist.='<div class="bkname"><a href="forum.php?mod=post&action=newthread&fid='.$val.'" target="_blank">'._getbkname($val).'</a></div>';
	}
}elseif($ac=='setadmin'){
	$satedata=C::t('#keke_integralmall#keke_integralmall_set')->fetchfirst_by_uid($_G['uid']);
}

$addrdata=C::t('#keke_integralmall#keke_integralmall_addr')->fetch($_G['uid']);
if($addrdata){
	$addrdata['name']=dhtmlspecialchars($addrdata['name']);
	$addrdata['addr']=dhtmlspecialchars($addrdata['addr']);
	$addrdata['tel']=dhtmlspecialchars($addrdata['tel']);
	$addrdata['kd']=dhtmlspecialcharss($addrdata['kd']);
	$addrhtml=unserialize($addrdata['areabox']);
	$addrhtml=mall_editor_safe_replace($addrhtml);
	if($addrdata['fullarea'] && $addrdata['addr'] && $addrdata['name'] && $addrdata['tel']){
        $fulladdr=$addrdata['fullarea'].$addrdata['addr'].' - '.$addrdata['name'].' - '.$addrdata['tel'];
    }
}
$issj=1;
$fyhz = empty($keke_integralmall['fyhz']) ? array() : unserialize($keke_integralmall['fyhz']);
if(!(empty($fyhz[0]) || in_array($_G['groupid'],$fyhz))){
	$issj=0;
}
include template('keke_integralmall:show_win');