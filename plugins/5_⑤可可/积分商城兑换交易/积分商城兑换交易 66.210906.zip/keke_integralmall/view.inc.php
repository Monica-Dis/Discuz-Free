<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
global $_G;
$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
$tid=intval($_GET['tid']);
$creditname=$_G['setting']['extcredits'][$keke_integralmall['jf']]['title'];
$nowcredit = getuserprofile('extcredits'.$keke_integralmall['jf']);
include_once DISCUZ_ROOT . './source/plugin/keke_integralmall/function/function_fun.php';

$goodsdata=_get_goodsdata($tid);
if(!$goodsdata){
	return;
}
if(!$_G['mobile']){
	$url=_gettidrewriteurl($tid);
	dheader('location: '.$url);
}
$thread = C::t('forum_thread')->fetch($tid);
$thumb = getforumimg($goodsdata['aid'], 0, 500, 500);
$buylist=_get_buylist($tid,5);
$stime=dgmdate($goodsdata['time'], 'Y/m/d H:i:s');
$etime=dgmdate($goodsdata['endtime'], 'Y/m/d H:i:s');
$buycount = C::t('#keke_integralmall#keke_integralmall_log')->countsum_by_tidanduid($tid);
$sycount=$goodsdata['total'];
$per=($sycount/($sycount+$buycount))*100;
$keke_integralmall['gmcl']=dhtmlspecialchars($keke_integralmall['gmcl']);
$keke_integralmall['jdtcl']=dhtmlspecialchars($keke_integralmall['jdtcl']);
$firstpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
$pid = $firstpost['pid'];
include_once libfile('function/discuzcode');
$message=_replaceimg($firstpost['message']);
$message = discuzcode($message);
$sppos = strpos($message, chr(0).chr(0).chr(0));
if($sppos !== false) {
	$message = substr($message, 0, $sppos);
}
$message  = _anaimg($message);
$original_msg=$message;
$message = preg_replace_callback("/\[attach\](\d+)\[\/attach\]/i", '_get_attachpic', $message);
$thread = C::t("forum_thread")->fetch($tid);
$satedata=C::t('#keke_integralmall#keke_integralmall_set')->fetchfirst_by_uid($thread['authorid']);
if($satedata['val']){
	$valarr=explode(',',$satedata['val']);
}
$keke_share=0;
if(file_exists(DISCUZ_ROOT.'./source/plugin/keke_share/get_sdk.inc.php')){
	require_once libfile('function/post');
	$keke_share=1;
	$goodspics=_get_attachpic_attachment($goodsdata['aid']);
	if($goodspics && (strpos($goodspics, 'http') === false)){
		$goodspics=$_G['siteurl'].$goodspics;
	}
	$describe=messagecutstr($original_msg, 100);
	$describe=str_replace(array(" ","　","\t","\n","\r"),'',$describe);
}
$issj=1;
$fyhz = empty($keke_integralmall['fyhz']) ? array() : unserialize($keke_integralmall['fyhz']);
if(!(empty($fyhz[0]) || in_array($_G['groupid'],$fyhz))){
	$issj=0;
}
if($_G['setting']['optimizeviews']) {
	if(($row = C::t('forum_threadaddviews')->fetch($tid))) {
		$addviews = intval($row['addviews']);
		$thread['views'] += $addviews;
	}
}
$archiveid = $thread['threadtableid'];
viewthread_updateviewss($archiveid);
preg_match_all("/\[attach\](\d+)\[\/attach\]/i", $original_msg,$outarr);
$all_attachment=C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$tid, 'pid', $pid);
if($outarr){
	$aids[]=$goodsdata['aid'];
	foreach($outarr[1] as $outval){
		$aids[]=$outval;
	}
}
if($all_attachment){
	foreach($all_attachment as $att){
		if($att['isimage'] && !in_array($att['aid'],$aids)){
			$overaimg[]=($att['remote']?getglobal('setting/ftp/attachurl'):$_G['setting']['attachurl']).'forum/'.$att['attachment'];
		}
	}
}
include template('keke_integralmall:view');