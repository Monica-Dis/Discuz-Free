window.addEventListener('load', function(){
    //人才列表导航
    var childNav = document.querySelectorAll('.child-nav > span'),
        len = childNav.length,
        opBgTalent = document.querySelector('.op-bg-talent'),
        grandNav = document.querySelectorAll('.grand-nav-wrap > div');
    for( var i=0; i<len; i++ ){
        childNav[i].index = i;
        childNav[i].addEventListener('click', function(e){
            var index = this.index;
            for( var i=0; i<len; i++ ){
                if( i == index ) {
                   switchClass(this, 'selected', false, [opBgTalent, grandNav[this.index]]);
                    continue;
                }
                childNav[i].className = '';
                grandNav[i].style.display = 'none';
            }
            e.stopPropagation()
        }, false);
    }

    //筛选条件
    var limit= document.querySelectorAll('.grand-nav-wrap a'),
        sortDetail = document.querySelectorAll('.sort-list .right-side > div'),
        floorNav = document.querySelectorAll('.floor-nav');
    for( var c= 0, limitLen=limit.length; c<limitLen; c++ ){
        limit[c].index = c;
        limit[c].addEventListener('click', function(e){
            var parentEle = this.parentNode,
                parentClass = parentEle.className,
                siblingEle = parentEle.querySelectorAll('a'),
                len = siblingEle.length;

          //  if(  parentClass.indexOf('multipe') >= 0 || (parentClass.indexOf('left-side') >= 0 && this.innerHTML.indexOf('分类')<0) || parentClass.indexOf('floor-nav') >= 0 ) e.preventDefault();

           // if( parentClass.indexOf('left-side') >= 0 && this.className.indexOf('selected') >= 0 ) return;
            switchClass(this, 'selected');
            if( parentClass.indexOf('floor-nav') < 0 ){
                if( parentClass.indexOf('multipe') < 0 || this.innerHTML.indexOf('不限') >= 0 ){
                    for( var i=0; i<len; i++ ){
                        if( siblingEle[i] == this ) continue;
                        if( siblingEle[i].nodeName.toUpperCase() != 'B' ){
                            siblingEle[i].className = siblingEle[i].className.replace(/\s*(selected)*/g, '');
                        }
                    }
                }else if( siblingEle[0].className != '' ){
                    siblingEle[0].className = '';
                }
            }

            /*//三级分类
            if( parentClass.indexOf('floor-nav') >= 0 ){
                 for (var c = 0, floorLen = floorNav.length; c < floorLen; c++) {
                     if( floorNav[c].querySelector('a') == this ) continue;
                     floorNav[c].querySelector('a').className = '';
                 }
             }*/

            //分类筛选
            if( parentClass.indexOf('left-side') >= 0 ) {
                for (var d = 0, sortLen = sortDetail.length; d < sortLen; d++) {
                    sortDetail[d].style.display = 'none';
                    if( this.index != 0 ) sortDetail[this.index - 1].style.display = 'block';
                }
            }
        }, false);
    }


    // 关闭筛选
    var closeLimit = document.querySelectorAll('.grand-nav-wrap .close'),
        grandNav = document.querySelectorAll(".grand-nav-wrap > div");
    for(var idx= 0,closeLen=closeLimit.length; idx<closeLen; idx++){
        closeLimit[idx].index = idx;
        closeLimit[idx].addEventListener('click', function(){
            var index = this.index;
            childNav[index].className = ''
            grandNav[index].style.display = 'none';
            opBgTalent.style.display = 'none';
        }, false);
    }

    opBgTalent.addEventListener('click', function(){
        document.querySelector('.child-nav > span.selected').className = '';
        for(var i= 0, len=grandNav.length; i<len; i++){
            grandNav[i].style.display = 'none';
        }
        opBgTalent.style.display = 'none';
    }, false);
}, false);





$(function(){
    //头部导航
    var $menuBtn = $('.nemu-btn'),
        $nemuWrapper = $('.nemu-wrapper'),
        $opBg = $('.op-bg'),
        $appGuide = $('.app-downlaod-guide a'),
        $guideDownLoadApp = $('.app-downlaod-guide'),
        $wxContent = $('.footer-wx');

    $menuBtn.on('tap, click', function() {
        if ( $menuBtn.hasClass('selected') ) {
            $menuBtn.removeClass('selected');
            $nemuWrapper.addClass('hiden');
            $opBg.hide();
        } else {
            $menuBtn.addClass('selected');
            $nemuWrapper.removeClass('hiden');
            $opBg.show();
        }
    });

    $('header').on('tap, click', function(e) {
        if (e.target.tagName.toLowerCase() != 'a' ) {
            e.preventDefault();
        }
    })

    $opBg.on('tap', function() {
        $menuBtn.removeClass('selected')
        $nemuWrapper.addClass('hiden');
        $opBg.hide();
    })

   

 
});


function switchClass(ele, name, bgShow, showEle){
    if( ele.className.indexOf(name) >= 0 ){
        var reg = eval('/\\s*'+name+'/g')
        //$nav[i].className = $nav[i].className.replace(reg, '');
        ele.className = ele.className.replace(reg, '');
        if( arguments[2] != undefined ) {
            for(var i= 0,len=showEle.length; i< len; i++) {
                var boolShow = bgShow ? 'block' : 'none';
                showEle[i].style.display = boolShow;
            }
        }
    }else{
        ele.className = ele.className + ' ' + name;
        if( arguments[2] != undefined ) {
            for(var i= 0,len=showEle.length; i< len; i++) {
                var boolShow = bgShow ? 'none' : 'block';
                showEle[i].style.display = boolShow;
            }
        }
    }
}

function tab(nav, target, css){
    var $nav = document.querySelectorAll('.' + nav),
        $target = document.querySelectorAll('.' + target),
        len = $nav.length;
    for(var i=0; i<len; i++){
        $nav[i].index = i;
        $nav[i].addEventListener('click', function(){
            var index  = this.index;
            if( this.className.indexOf(css) >= 0 ) return;
            var hasClass = false;
            if( this.className.length > 0 ) hasClass = true;
            for(var i=0; i<len; i++){
                if( i == index ) {
                    this.className  = hasClass ? (' '+css) : css;
                    $target[i].style.display = 'block';
                }else{
                    var reg = eval('/\\s*'+css+'/g')
                    $nav[i].className = $nav[i].className.replace(reg, '');
                    $target[i].style.display = 'none';
                }
            }
        }, false);
    }
}

//文字弹窗
//底部按钮分三种情况
//1.取消和确定按钮同时存在
//2.只有确定按钮
//3.无按钮:只需传入txt参数,该种弹窗会自动消失
$(function(){
    var browerH = $(window).height(),
        browerW = $(window).width();

    function Dialog(opt){
        this.settings = $.extend({
            ok: null,           //函数，点击确定按钮所需执行的函数
            confirmOk: false,   //布尔值，如果该参数为true，则ok的返回值为true时才会自动关闭弹窗
            cancel: false,       //布尔值，是否需要取消按钮
            width: 280,          //弹窗宽度
            txt: '',             //弹窗显示的内容,不同行文字放在p标签内
            time: 2500           //弹窗自动消失的时间
        }, opt);
        this.show();
    }

    Dialog.prototype.show = function(){
        var _this = this;

        _this.dialogEle = $('<div class="dialog-bg"></div>').appendTo('body').on('click', function(){
            _this.remove();
        });
        _this.dialogContent = $('<div></div>').appendTo( _this.dialogEle ).on('click', function(){
            return false;
        });

        _this.dialogContent.width(_this.settings.width).html(this.settings.txt);
        var dialogContentH = _this.dialogContent.css({'display': 'block', 'visibility': 'hidden'}).height();
        _this.dialogContent.css({'top': (browerH - dialogContentH)/2-40+'px', 'left': (browerW - _this.settings.width)/2+'px', 'visibility': 'visible'}).show();

        if( _this.settings.cancel ) this.cancel();
        if( _this.settings.ok && $.isFunction(_this.settings.ok) ) {
            this.ok();
        } else if ( !_this.settings.cancel ) {
            setTimeout(function() {
                _this.remove();
            }, _this.settings.time);
        }
    }

    Dialog.prototype.remove = function(){
        if ( this.btnWrapper ) {
            this.btnWrapper.remove();
        }
        this.dialogEle.remove();
    }

    Dialog.prototype.ok = function(){
        var _this = this;

        if ( !_this.btnWrapper ) {
            _this.btnWrapper = $('<div></div>').appendTo( _this.dialogContent );
        }

        var $btn = $('<button>确定</button>').on('click', function(){
            var result = _this.settings.ok();

            if(_this.settings.confirmOk) {
                if( result ) {
                    _this.remove();
                }
            }else {
                _this.remove();
            }
            return false;
        }).addClass( _this.settings.cancel ? 'ok' : 'ok-one' ).appendTo( $('<div></div>') ).appendTo( _this.btnWrapper );

        if( $btn.hasClass('ok-one') ) {
            _this.btnWrapper.addClass('ok-one-wrapper')
        }
    }

    Dialog.prototype.cancel = function(){
        var _this = this;

        if ( !_this.btnWrapper ) {
            _this.btnWrapper = $('<div></div>').appendTo( _this.dialogContent );
        }

        $('<button>取消</button>').on('click', function(){
            _this.remove();
            return false;
        }).addClass('cancel').appendTo( _this.btnWrapper );
    }

    window.dialog = function(opt){
        return new Dialog(opt);
    }
});

