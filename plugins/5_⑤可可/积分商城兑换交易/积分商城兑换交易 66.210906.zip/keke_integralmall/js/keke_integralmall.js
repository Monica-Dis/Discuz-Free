function buylist(url){
	jQuery.post(url,function (data){
	jQuery("#buylist").html(data);
	}, "html");
}