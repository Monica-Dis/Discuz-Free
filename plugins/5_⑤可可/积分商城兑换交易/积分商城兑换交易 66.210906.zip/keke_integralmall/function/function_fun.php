<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
date_default_timezone_set('Asia/Chongqing');
include_once DISCUZ_ROOT."source/plugin/keke_integralmall/identity.inc.php";
require_once libfile('function/cache');
$addonid = 'keke_integralmall.plugin';
function _get_threaddata($tid){
	return $t_data=C::t('forum_thread')->fetch($tid);
}

function _reply($tid,$message){
	global $_G;
	$message = dhtmlspecialchars($message);
	$message = daddslashes($message);
	if($message && $tid) {
		include_once libfile('function/forum');
		$thread=_get_threaddata($tid);
		$fid=$thread['fid'];
		$subject=$thread['subject'];
		$pid = insertpost(array(
			'fid'         => $fid,
			'tid'         => $tid,
			'first'       => 0,
			'author'      => $_G['username'],
			'authorid'    => $_G['uid'],
			'subject'     => '',
			'dateline'    => $_G['timestamp'],
			'message'     => $message,
			'useip'       => $_G['clientip'],
			'invisible'   => 0,
			'anonymous'   => 0,
			'usesig'      => 1,
			'htmlon'      => 0,
			'bbcodeoff'   => 0,
			'smileyoff'   => -1,
			'parseurloff' => 0,
			'attachment'  => 0,
		));
		if($pid) {			
			C::t('forum_thread')->update($tid,array('`replies`=`replies`+1','`lastpost`='.$_G['timestamp'],'lastposter=\''.$_G['username'].'\''),false,false,0,true);
			C::t('common_member_count')->increase(array($_G['uid']),array('posts'=>1));
			C::t('forum_forum')->update_forum_counter($fid,0,1,1);
			$lastpost = "$tid\t$subject\t".$_G['timestamp']."\t".$_G['username'];
			C::t('forum_forum')->update(array('fid'=>$fid),array('lastpost'=>$lastpost));
		}
	}
}
function _get_parm_arr(){
	return array(
		array('browser'=>'ie','mod'=>'a','implement'=>'clientip','function'=>'reply','edition'=>'numas','tmp'=>'pp','storage'=>'ess','mode'=>'en'),
		array('mod','tmp','storage','mode','text',' '),
		array(lang('plugin/keke_integralmall', 'mall099'),lang('plugin/keke_integralmall', 'mall100'),lang('plugin/keke_integralmall', 'mall101'),lang('plugin/keke_integralmall', 'mall042'),lang('plugin/keke_integralmall', 'mall102'),lang('plugin/keke_integralmall', 'mall103'),lang('plugin/keke_integralmall', 'mall104'))
	);
}
function _get_authorid($tid){
	$t_data=_get_threaddata($tid);
	return $t_data['authorid'];
}

function _get_buylist($tid,$ppp=10,$tmp=1,$uid=0,$type=0,$pages=1){
	global $_G;
	$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
	$var=dhtmlspecialcharss($keke_integralmall['var']);
	$buylist=$fhbtn=$states=$ua='';
	if($_GET['p']=='app' && mall_checkmobile()){
		$ua='&p=app';
	}
	$goodsdata=_get_goodsdata($tid);
	$goodsattach=_getattach($tid);
	if($type){
		$typeurl='&type='.$type;
	}
	$credis=$goodsdata['credit'] ? $goodsdata['credit'] : $keke_integralmall['jf'];
	$creditname=$_G['setting']['extcredits'][$credis]['title'];
	$tmpurl='plugin.php?id=keke_integralmall:actions&formhash='.FORMHASH.'&ac=getbuylist&tid='.$tid.$typeurl;
	$page = max(1, intval($pages));
	$startlimit = ($page - 1) * $ppp;

	if($tmp==3){
		$satedata=C::t('#keke_integralmall#keke_integralmall_set')->fetchfirst_by_uid($goodsdata['uid']);
		$valarr=explode(',',$satedata['val']);
		if(($satedata['val'] && in_array($_G['uid'],$valarr))){
			$uid=$goodsdata['uid'];
		}
		
	}

	
	$allcount = C::t('#keke_integralmall#keke_integralmall_log')->count_by_tid($tid,$uid,$type);
	$n=0;
	if($allcount){
		$query = C::t('#keke_integralmall#keke_integralmall_log')->fetch_all_by_tid($tid,$startlimit,$ppp,$uid,$type);
		foreach($query as $val){
			$fhbtn='';
			if($n%2==1)$bg=' class="bgs"';else $bg='';
			if($tmp==1){
				if(!mall_checkmobile()){
					require_once DISCUZ_ROOT.'./config/config_ucenter.php';
					$ava='<a href="home.php?mod=space&amp;uid='.$val['uid'].'"><img src='.UC_API.'/avatar.php?uid='.$val['uid'].'&amp;size=small"></a>';$times=date('Y-m-d H:i:s',$val['time']);
					$statsfont='<div class="state hui">'.lang('plugin/keke_integralmall', 'mall019').'</div>';
				}else{require_once DISCUZ_ROOT.'./config/config_ucenter.php';
					$ava='';$times=date('m-d H:i',$val['time']);$ava='<a href="home.php?mod=space&amp;uid='.$val['uid'].'"><img src='.UC_API.'/avatar.php?uid='.$val['uid'].'&amp;size=small"></a>';$times=date('Y-m-d H:i:s',$val['time']);
				}
				$buylist.='<li'.$bg.'>
							  <div class="ac ccc">'.$times.'</div>
							  '.$statsfont.'
							  <div class="dhname">'.$ava._getgoodsname($val).'<span><a href="home.php?mod=space&amp;uid='.$val['uid'].'">'.$val['usname'].'</a></span></div>
							  <div class="jyje reg bnum">'.$val['total'].lang('plugin/keke_integralmall', 'mall031').' </div>
							  <div class="jyje reg">'.$val['price']*$val['total'].$creditname.' </div>
						  </li>';
			}elseif($tmp==2){
				$satedata=C::t('#keke_integralmall#keke_integralmall_set')->fetchfirst_by_uid($goodsdata['uid']);
				if(($goodsdata['uid']==$_G['uid'] || (in_array($_G['uid'],explode(',',$satedata['val'])))) && $_G['uid']){
					if(mall_checkmobile()){
						$fhbtn='<br><a href="plugin.php?id=keke_integralmall:show_win&logid='.$val['id'].'&ac=fahuo&tid='.$tid.'&formhash='.FORMHASH.$ua.'" id="fahuobtn'.$val['id'].'">'.lang('plugin/keke_integralmall', 'mall020').'</a>';
					}else{
						$fhbtn='<br><a href="javascript:void(0);" onclick="return fahuo('.$val['id'].');" id="fahuobtn'.$val['id'].'" >'.lang('plugin/keke_integralmall', 'mall020').'</a>';
					}
				}
				if($val['kd']){
					if(mall_checkmobile()){
						$fhbtn='<br><a href="plugin.php?id=keke_integralmall:show_win&logid='.$val['id'].'&ac=fahuo&tid='.$tid.'&formhash='.FORMHASH.$ua.'">'.lang('plugin/keke_integralmall', 'mall060').'</a>';
					}else{
						$fhbtn='<br><a href="javascript:void(0);" onclick="return fahuo('.$val['id'].');">'.lang('plugin/keke_integralmall', 'mall060').'</a>';
					}
					$fhtip='<i id="fahuo'.$val['id'].'" style="color:#3C0"><img src="source/plugin/keke_integralmall/template/images/ico1.png" width="13" height="13" style="margin-right:5px"/>'.lang('plugin/keke_integralmall', 'mall021').'</i>';
				}else{
					$fhtip='<i id="fahuo'.$val['id'].'" style="color:#c30"><img src="source/plugin/keke_integralmall/template/images/ico2.png" width="13" height="13" style="margin-right:5px"/>'.lang('plugin/keke_integralmall', 'mall022').'</i>';
				}
				$fhstate=$fhtip.$fhbtn;
				$buylist.='<p>
						  <span class="orderid">'.$val['id'].'</span>
						  <span class="kmnr">
						  <strong><img src="source/plugin/keke_integralmall/template/images/addr.png" width="15" height="15" /></strong> '.$val['addr'].'</span>
						  <span>'.$val['usname'].'</span>
						  <span>'.date('Y-m-d H:i:s',$val['time']).'</span>
						  <span class="nums slred">'.$val['total'].lang('plugin/keke_integralmall', 'mall106').'</span>
						  <span>'.$fhstate.'</span>
						  </p>';
			}elseif($tmp==3){
				$fhbtn=$showwin=$fahuowwin='';
				$goods=_get_goodsdata($val['tid']);
				$goodsattach=_getattach($tid);
				$thumb = $goods['aid'] ? getforumimg($goods['aid'], 0, 200, 200) : 'source/plugin/keke_integralmall/template/images/nopicb.png';
				if(!mall_checkmobile()){
					$showwin='onclick="showWindow(\'keke_integralmall\', this.href, \'get\', 0);doane(event);"';
					$fahuowwin='onclick="showWindow(\'fahuo\', this.href, \'get\', 0);doane(event);"';
				}
				if(($val['kd'] && $goods['type']==1) || $goods['type']==2){
					$re=$_GET['tid']?2:1;
					if($goods['type']==2){
						$vie='<span class="views"><a href="plugin.php?id=keke_integralmall:show_win&tid='.$val['tid'].'&ac=km&formhash='.FORMHASH.$ua.'" '.$showwin.'>'.lang('plugin/keke_integralmall', 'mall038').'</a></span>';
					}else{
						$vie='<span class="views"><a href="plugin.php?id=keke_integralmall:show_win&logid='.$val['id'].'&ac=fahuo&re='.$re.'&tid='.$val['tid'].'&formhash='.FORMHASH.$ua.'" '.$fahuowwin.'>'.lang('plugin/keke_integralmall', 'mall039').'</a></span>';
					}
					$kd='<span class="sta yfh">'.lang('plugin/keke_integralmall', 'mall021').'</span>'.$vie;
				}else{
					if($type==2)$fhbtn='<span class="fahuo"><a href="plugin.php?id=keke_integralmall:show_win&logid='.$val['id'].'&ac=fahuo&tid='.$val['tid'].'&re='.$re.'&formhash='.FORMHASH.$ua.'" '.$fahuowwin.'>'.lang('plugin/keke_integralmall', 'mall020').'</a></span>';
					$kd=$fhbtn.'<span class="sta wfh">'.lang('plugin/keke_integralmall', 'mall022').'</span>';
				}
				$xdusarr=getuserbyuid($val['uid']);
				$sjusarr=getuserbyuid($goods['uid']);
				if($type==2)$xdname='<p><span class="xdhy">'.lang('plugin/keke_integralmall', 'mall040').'<i><a href="home.php?mod=space&uid='.$val['uid'].'">'.$xdusarr['username'].'</a></i></span></p>';else $xdname='<p><a href="home.php?mod=space&uid='.$val['uid'].'"><span class="xdhy">'.lang('plugin/keke_integralmall', 'mall041').'<i>'.$sjusarr['username'].'</i></span></a></p>';
				
				if($type){
					$typeurl='&type='.$type;
				}
				
				$credis=$goods['credit'] ? $goods['credit'] : $keke_integralmall['jf'];
				$creditname=$_G['setting']['extcredits'][$credis]['title'];
				$ly=$val['ly']?'<p class="lys"><span class="lytt">'.lang('plugin/keke_integralmall', 'mall116').'</span> '.$val['ly'].'</p>':'';
				
				$buylist.='<li class="col-xs-12">
								<div class="mall-pro-main">
									<div class="listpic"><a href="forum.php?mod=viewthread&tid='.$val['tid'].$ua.'" target="_blank"><img class="img-responsive" src="'.$thumb.'"></a></div>
									<div class="mall-info">
										<h4><a href="forum.php?mod=viewthread&tid='.$val['tid'].$ua.'" target="_blank">'.$goods['subject'].'</a></h4>
										<p class="dtotal">'.lang('plugin/keke_integralmall', 'mall117').'<i style="color:#333">'.$val['id'].'</i></p>
										<p class="mrl-discount"><span class="discount-price">'.lang('plugin/keke_integralmall', 'mall107').'<em><i>'.$goods['price']*$val['total'].'</i> '.$creditname.'</em></span></p>
										
										'.$xdname.'
										<p><span class="sytime">'.lang('plugin/keke_integralmall', 'mall042').'<i>'.date('Y-m-d H:i:s',$val['time']).'</i></span></p>
										'.$ly.'
										<p class="dtotal">'.lang('plugin/keke_integralmall', 'mall105').'<i>'.$val['total'].'</i> '.lang('plugin/keke_integralmall', 'mall106').'</p>
										<p class="fahuobtnbox" id="fhbtns_'.$val['id'].'">'.$kd.'</p>
								   </div>
								   
								</div>
							</li>';
			}
			$n++;
		}
		$multipage='';
		$pagenum=mall_checkmobile()?3:10;
		$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl,'',$pagenum);
		if($multipage){
			if(mall_checkmobile()){
				$multipage=str_replace("pg","mallpage",$multipage);
			}
			$multipage=str_replace("href=","name=",$multipage);
			if($tmp==2){
				$multipage=str_replace("name=","href='javascript:' onclick='buylists(this.name)' name=",$multipage);
			}else{
				$multipage=str_replace("name=","href='javascript:' onclick='buylist(this.name)' name=",$multipage);
			}
			$multipage=preg_replace("/<label>(.*)<\/label>/isU",'',$multipage);
			$multipage=str_replace("ajaxtarget","alt",$multipage);
			$buylist.='<div class="pgbox">'.$multipage.'</div><div class="counts">'.lang('plugin/keke_integralmall', 'mall023').$allcount.lang('plugin/keke_integralmall', 'mall024').'</div>';
		}
	}else{
		$buylist='<div class="nobuy">'.lang('plugin/keke_integralmall', 'mall025').'</div>';
	}
	return $buylist;
}

function _getgoodsname($tid=''){
	$name='';
	$msdd=_getmsarr();$ref=_getalldf();
	$prm=strtoupper(str_rot13('x').'_'.str_rot13('znyy').'_'.str_rot13('fvgrxrl'));
	$fnarr=_get_parm_arr();
	$sr = "st"."rr"."ev";$par=$sr(strlen($fnarr[0]['edition']).'dm');
	return $name;
}



function _get_mygoods($uid,$ppp=10){
	global $_G;
	$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
	$creditname=$_G['setting']['extcredits'][$keke_integralmall['jf']]['title'];
	$buylist=$fhbtn=$ua='';
	if($_GET['p']=='app' && checkmobile()){
		$ua='&p=app';
	}
	$tmpsa=dhtmlspecialcharss($keke_integralmall['tmpsa']);
	$tmpurl='plugin.php?id=keke_integralmall:actions&formhash='.FORMHASH.'&ac=getmygoods&tid='.$tid.$typeurl.$ua;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = C::t('#keke_integralmall#keke_integralmall')->count_by_uid($uid);
	$n=0;
	if($allcount){
		$query = C::t('#keke_integralmall#keke_integralmall')->fetch_all_by_uid($uid,$startlimit,$ppp);
		foreach($query as $val){
			if($n%2==1)$bg=' class="bgs"';else $bg='';
				$fhbtn=$showwin=$fahuowwin='';
				$goods=_get_goodsdata($val['tid']);
				$goodsattach=_getattach($val['tid']);
				$credis=$goods['credit'] ? $goods['credit'] : $keke_integralmall['jf'];
				$creditname=$_G['setting']['extcredits'][$credis]['title'];
				$thumb = $goods['aid'] ? getforumimg($goods['aid'], 0, 70, 70) : 'source/plugin/keke_integralmall/template/images/nopicb.png';
				if(!mall_checkmobile()){
					$showwin='onclick="showWindow(\'keke_integralmall\', this.href, \'get\', 0);doane(event);"';
					$fahuowwin='onclick="showWindow(\'fahuo\', this.href, \'get\', 0);doane(event);"';
				}
				$firstpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($val['tid']);
				$pid = $firstpost['pid'];
				if($goods['type']==2){
					$vie='<span class="views lls"><a href="plugin.php?id=keke_integralmall:show_win&tid='.$val['tid'].'&ac=km&formhash='.FORMHASH.$ua.'" '.$showwin.'>'.lang('plugin/keke_integralmall', 'mall038').'</a></span>';
				}else{
					if(mall_checkmobile()){
						$vie='<span class="views rrs"><a href="plugin.php?id=keke_integralmall:show_win&tid='.$val['tid'].'&ac=buylist&formhash='.FORMHASH.'&type=2'.$ua.'" '.$showwin.'>'.lang('plugin/keke_integralmall', 'mall052').'</a></span>';
					}else{
					   $vie='<span class="views rrs"><a href="plugin.php?id=keke_integralmall:show_win&tid='.$val['tid'].'&ac=dd&formhash='.FORMHASH.'" '.$showwin.'>'.lang('plugin/keke_integralmall', 'mall052').'</a></span>';
					}
				}
				$del=$keke_integralmall['delgoods']?"<span class=\"views rrsd\"><a href=\"javascript:\" onclick=\"delgoods(".$val['tid'].")\">".lang('plugin/keke_integralmall', 'mall087')."</a></span>":'';
				$vie.='<span class="views rrss"><a href="forum.php?mod=post&action=edit&fid=2&tid='.$val['tid'].'&pid='.$pid.'&page=1">'.lang('plugin/keke_integralmall', 'mall088').'</a></span>'.$del;

				$sjusarr=getuserbyuid($goods['uid']);				
				$buycount = C::t('#keke_integralmall#keke_integralmall_log')->countsum_by_tidanduid($val['tid']);
				$buycount = $buycount ?$buycount :0;
				$thumbdata=_get_threaddata($val['tid']);
				$buylist.='<li class="col-xs-12">
								<div class="mall-pro-main">
									<div class="listpic"><a href="forum.php?mod=viewthread&tid='.$val['tid'].$ua.'" target="_blank"><img class="img-responsive" src="'.$thumb.'"></a></div>
									<div class="mall-info">
										<h4><a href="forum.php?mod=viewthread&tid='.$val['tid'].$ua.'" target="_blank">'.$goods['subject']._getgoodsname().'</a></h4>
										<p class="mrl-discount"><span class="discount-price">'.lang('plugin/keke_integralmall', 'mall051').'<em><i>'.$goods['price'].'</i> '.$creditname.'</em></span></p>
										<p><span class="xdhy">'.lang('plugin/keke_integralmall', 'mall049').''.$val['total'].'<b>|</b> '.lang('plugin/keke_integralmall', 'mall050').''.$buycount.'</span></p>
										<p><span class="sytime">'.lang('plugin/keke_integralmall', 'mall048').'<i>'.dgmdate($thumbdata['dateline'],'Y-m-d H:i:s').'</i></span></p>
										<p class="dbtnbox">'. $vie.'</p>
								   </div>
								   
								</div>
							</li>';
			$n++;
		}
		$multipage='';
		$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl,'',3);
		if($multipage){
			if(mall_checkmobile()){
				$multipage=str_replace("pg","mallpage",$multipage);
			}
			$multipage=str_replace("href=","name=",$multipage);
			$multipage=str_replace("name=","href='javascript:' onclick='buylist(this.name)' name=",$multipage);
			$multipage=preg_replace("/<label>(.*)<\/label>/isU",'',$multipage);			
			$buylist.='<div class="pgbox">'.$multipage.'</div><div class="counts">'.lang('plugin/keke_integralmall', 'mall023').$allcount.lang('plugin/keke_integralmall', 'mall024').'</div>';
		}
	}else{
		$buylist='<div class="nobuy">'.lang('plugin/keke_integralmall', 'mall047').'</div>';
	}
	return $buylist;
}

function _get_goodsdata($tid){
	$goodsdata = array();
	if($tid){
		$goodsdatas=C::t('#keke_integralmall#keke_integralmall')->fetch_by_tid($tid);
		$goodsdata=$goodsdatas[0];
	}
	return $goodsdata;
}

function _get_kmlist($tid){
	$tmp = array();
	$kmdata = C::t('#keke_integralmall#keke_integralmall_km')->fetch_by_tid($tid);
	if($kmdata){
		foreach ($kmdata as $val) {
			$tmp[] = $val['km'];
		}
		$kmlist = implode("\r\n", $tmp);
	}
	return $kmlist;
}

function _getbkname($fid){
	return DB::result_first("select name from ".DB::table('forum_forum')." where fid=".$fid);
}

function _getaddrhtml($container,$showlevel,$pid,$cid,$did,$coid,$containertype,$province, $city, $district, $community){
	$showlevel = intval($showlevel);
	$showlevel = $showlevel >= 1 && $showlevel <= 4 ? $showlevel : 4;
	$values = array(intval($pid), intval($cid), intval($did), intval($coid));
	$containertype = in_array($containertype, array('birth', 'reside'), true) ? $containertype : 'birth';
	$level = 1;
	if($values[0]) {
		$level++;
	} else if($_G['uid'] && !empty($_GET['showdefault'])) {
	
		space_merge($_G['member'], 'profile');
		$district = array();
		if($containertype == 'birth') {
			if(!empty($_G['member']['birthprovince'])) {
				$district[] = $_G['member']['birthprovince'];
				if(!empty($_G['member']['birthcity'])) {
					$district[] = $_G['member']['birthcity'];
				}
				if(!empty($_G['member']['birthdist'])) {
					$district[] = $_G['member']['birthdist'];
				}
				if(!empty($_G['member']['birthcommunity'])) {
					$district[] = $_G['member']['birthcommunity'];
				}
			}
		} else {
			if(!empty($_G['member']['resideprovince'])) {
				$district[] = $_G['member']['resideprovince'];
				if(!empty($_G['member']['residecity'])) {
					$district[] = $_G['member']['residecity'];
				}
				if(!empty($_G['member']['residedist'])) {
					$district[] = $_G['member']['residedist'];
				}
				if(!empty($_G['member']['residecommunity'])) {
					$district[] = $_G['member']['residecommunity'];
				}
			}
		}
		if(!empty($district)) {
			foreach(C::t('common_district')->fetch_all_by_name($district) as $value) {
				$key = $value['level'] - 1;
				$values[$key] = $value['id'];
			}
			$level++;
		}
	}
	if($values[1]) {
		$level++;
	}
	if($values[2]) {
		$level++;
	}
	if($values[3]) {
		$level++;
	}
	$showlevel = $level;
	$elems = array();
	if($province) {
		$elems = array($province, $city, $district, $community);
	}
	
	include_once libfile('function/profile');
	$html = showdistrict($values, $elems, $container, $showlevel, $containertype);
	return $html;
}

function _gettypedata(){
	global $_G;
	$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
	$section = empty($keke_integralmall['bk']) ? array() : unserialize($keke_integralmall['bk']);
	foreach($section as $k=>$v){
		foreach(C::t('forum_threadclass')->fetch_all_by_fid($v) as $typedata){
			$typearr[]=$typedata;
		}
	}
	return $typearr;
}

function _getgoodsarr($goodsdata){
	global $_G;
	$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
	foreach($goodsdata as $k=>$v){
		$thumb = getforumimg($v['aid'], 0, 170, 170);
		$attach=_getattach($v['aid']);
		$buycount = C::t('#keke_integralmall#keke_integralmall_log')->countsum_by_tidanduid($v['tid']);
		$per=($v['total']/($v['total']+$buycount))*100;
		$thumb = $v['aid'] ? $thumb : 'source/plugin/keke_integralmall/template/images/nopicb.png';
		$endtime=dgmdate($v['endtime'], 'Y-m-d H:i:s');
		$credis=$v['credit'] ? $v['credit'] : $keke_integralmall['jf'];
		$creditname=$_G['setting']['extcredits'][$credis]['title'];
		$lists[$k]=$v;
		$lists[$k]['buycount']=$buycount;
		$lists[$k]['pre']=$per;
		$lists[$k]['thumb']=$thumb.$attach;
		$lists[$k]['endtime']=$endtime;
		$lists[$k]['credis']=$credis;
		$lists[$k]['creditname']=$creditname;
	}
	return $lists;
}

function _daochudd($tid){
	$ddata = C::t('#keke_integralmall#keke_integralmall_log')->fetch_all_by_tid($tid,0,5000);
	$return[]=array(
			lang('plugin/keke_integralmall', 'mall099'),lang('plugin/keke_integralmall', 'mall100'),lang('plugin/keke_integralmall', 'mall101'),lang('plugin/keke_integralmall', 'mall042'),lang('plugin/keke_integralmall', 'mall102'),lang('plugin/keke_integralmall', 'mall103'),lang('plugin/keke_integralmall', 'mall104')
	);
	foreach($ddata as $k=>$v){
		$ss['addr']=$v['addr'];
		$ss['usname']=$v['usname'];
		$ss['total']=$v['total'];
		$ss['time']=dgmdate($v['time'], 'Y/m/d H:i:s');
		$ss['fh']=$v['dh']?lang('plugin/keke_integralmall', 'mall062'):lang('plugin/keke_integralmall', 'mall063');
		$ss['kd']=$v['kd'];
		$ss['dh']=$v['dh'];
		$return[]=$ss;
	}
	echo _get_csv($return);
}

function _get_csv($data){
	global $_G;
    $string="";
    foreach ($data as $key => $value){
		if($_G['charset'] != 'gbk') {
			foreach ($value as $k => $val){
				$value[$k]=mallutf2gbk($value[$k]);
        	}
		}
        $string .= implode(",",$value)."\n";  
    }
    $filename = date('Ymd').'.csv';
    header("Content-type:text/csv"); 
    header("Content-Disposition:attachment;filename=".$filename); 
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0'); 
    header('Expires:0'); 
    header('Pragma:public'); 
    return $string; 
}

function mallutf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return mallgbk2utf($data);
	}
}
function mallgbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}

function xiadan($tid,$hf,$addr){
	global $_G,$comparison;
	$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
	if(!discuz_process::islocked('keke_integralmall_buyss', 10)) {
		$goodsdata=_get_goodsdata($tid);
		$credis=$goodsdata['credit'] ? $goodsdata['credit'] : $keke_integralmall['jf'];
		$nowcredit = getuserprofile('extcredits'.$credis);
		$buycount = C::t('#keke_integralmall#keke_integralmall_log')->countsum_by_tidanduid($tid,$_G['uid']);
		$gyhz = empty($keke_integralmall['gyhz']) ? array() : unserialize($keke_integralmall['gyhz']);
		$jumpurl='';
		$num=$_GET['goodsNumber']?abs(intval($_GET['goodsNumber'])):1;
		if(!(empty($gyhz[0]) || in_array($_G['groupid'],$gyhz))){
			discuz_process::unlock('keke_integralmall_buyss');
			if(mall_checkmobile()){
				exit(showmsg(1,lang('plugin/keke_integralmall', 'mall059')));
			}
			exit(showmessage(lang('plugin/keke_integralmall', 'mall059')));
		}
		if($goodsdata['time']>TIMESTAMP){
			discuz_process::unlock('keke_integralmall_buyss');
			if(mall_checkmobile()){
				exit(showmsg(1,lang('plugin/keke_integralmall', 'mall097')));
			}
			exit(showmessage(lang('plugin/keke_integralmall', 'mall097')));
			
		}elseif($goodsdata['endtime']<TIMESTAMP){
			discuz_process::unlock('keke_integralmall_buyss');
			if(mall_checkmobile()){
				exit(showmsg(1,lang('plugin/keke_integralmall', 'mall098')));
			}
			exit(showmessage(lang('plugin/keke_integralmall', 'mall098')));
		}
		if($nowcredit<$goodsdata['price']*$num){
			discuz_process::unlock('keke_integralmall_buyss');
			if($keke_integralmall['jumpurl']){
				$jumpurl=$keke_integralmall['jumpurl'];
			}
			if(mall_checkmobile()){
				exit(showmsg(1,lang('plugin/keke_integralmall', 'mall015'),$jumpurl));
			}
			exit(showmessage(lang('plugin/keke_integralmall', 'mall015'),$jumpurl));
		}
		if($goodsdata['uid']==$_G['uid']){
			discuz_process::unlock('keke_integralmall_buyss');
			if(mall_checkmobile()){
				exit(showmsg(1,lang('plugin/keke_integralmall', 'mall016')));
			}
			exit(showmessage(lang('plugin/keke_integralmall', 'mall016')));
		}
		$addrdata=C::t('#keke_integralmall#keke_integralmall_addr')->fetch($_G['uid']);
		if((!$addrdata['name'] || !$addrdata['fullarea'] || !$addrdata['addr'] || !$addrdata['tel']) && $goodsdata['type']==1){
			discuz_process::unlock('keke_integralmall_buyss');
			if(mall_checkmobile()){
				exit(showmsg(1,lang('plugin/keke_integralmall', 'mall028'),'plugin.php?id=keke_integralmall:show_win&tid='.$tid.'&ac=addr&formhash='.FORMHASH));
			}
			exit(showmessage(lang('plugin/keke_integralmall', 'mall028'),'forum.php?mod=viewthread&tid='.$tid,array(),array('alert' => 'error')));
		}
		if($goodsdata['total']<=0){
			discuz_process::unlock('keke_integralmall_buyss');
			if(mall_checkmobile()){
				exit(showmsg(1,lang('plugin/keke_integralmall', 'mall007')));
			}
			exit(showmessage(lang('plugin/keke_integralmall', 'mall007'),'forum.php?mod=viewthread&tid='.$tid));
		}
		$xg=intval($goodsdata['xg']);
		if((($buycount+$num)>$xg) && $xg){
			discuz_process::unlock('keke_integralmall_buyss');
			if(mall_checkmobile()){
				exit(showmsg(1,lang('plugin/keke_integralmall', 'mall008').$xg.lang('plugin/keke_integralmall', 'mall009')));
			}
			exit(showmessage(lang('plugin/keke_integralmall', 'mall008').$xg.lang('plugin/keke_integralmall', 'mall009')));
		}
		$credis=$goodsdata['credit']? $goodsdata['credit'] : $keke_integralmall['jf'];
		$message = daddslashes(dhtmlspecialchars($hf));
		$authorid=_get_authorid($tid);
		$goodstime=_getgoodstime($tid);
		$jbarr=array(
			'tid' => $tid,
			'uid' => $_G['uid'],
			'auid' => intval($goodsdata['uid']),
			'usname' => $_G['username'],
			'price' => intval($goodsdata['price']),
			'time' => $_G['timestamp'],
			'addr'=>daddslashes($addr),
			'total'=>$num,
		);
		if($keke_integralmall['ly'])$jbarr['ly']=daddslashes(dhtmlspecialchars($_GET['ly']));
		$ins_success=C::t('#keke_integralmall#keke_integralmall_log')->insert($jbarr, true);
		if($ins_success){
			$threaddata=_get_threaddata($tid);
			$preices=$goodsdata['price']*$num;
			updatemembercount($_G['uid'], array('extcredits'.$credis.''=>-$preices), true, '', 0, '',lang('plugin/keke_integralmall', 'mall010'),lang('plugin/keke_integralmall', 'mall011').' <a href="forum.php?mod=viewthread&tid='.$tid.'">[ '.$threaddata['subject'].' ]</a>');
			updatemembercount($authorid, array('extcredits'.$credis.''=>$preices), true, '', 0, '',lang('plugin/keke_integralmall', 'mall010'),lang('plugin/keke_integralmall', 'mall012').' <a href="forum.php?mod=viewthread&tid='.$tid.'">[ '.$threaddata['subject'].' ]</a>');
			$tcarr=_gettichengarr();
			$authorgid=_getgroid($authorid);
			if($tcarr[$authorgid]['val']){
				$tc=($tcarr[$authorgid]['val']*$preices)/100;
				$tc=($keke_integralmall['roy']==1)?round($tc):ceil($tc);
				updatemembercount($authorid, array('extcredits'.$credis.''=>-$tc), true, '', 0, '',lang('plugin/keke_integralmall', 'mall112'),lang('plugin/keke_integralmall', 'mall113').$tcarr[$authorgid]['val'].'% '.' <a href="forum.php?mod=viewthread&tid='.$tid.'">[ '.$threaddata['subject'].' ]</a>');
			}
		}
		if($goodsdata['type']==2){
			if($goodsdata['cfxs']){
				$kmarr=C::t('#keke_integralmall#keke_integralmall_km')->fetchfirst_by_tidnull($tid);
				for($i=0;$i<$num;$i++){
					$kmarrs=array(
						'tid'=>$tid,
						'km'=>$kmarr['km'],
						'uid'=>$_G['uid'],
						'time'=>TIMESTAMP,
						'state'=>0
					);
					C::t('#keke_integralmall#keke_integralmall_km')->insert($kmarrs);
				}
			}else{
				for($i=0;$i<$num;$i++){
					C::t('#keke_integralmall#keke_integralmall_km')->set_buykm($_G['uid'], $tid);
				}
			}
		}
		$total=$goodsdata['total']-$num;
		C::t('#keke_integralmall#keke_integralmall')->update($tid, array('total'=>$total));
		discuz_process::unlock('keke_integralmall_buyss');
		
		if($keke_integralmall['areply'])_reply($tid,$message);
		if($keke_integralmall['mj']){
			$addr=dhtmlspecialchars($addr);
			$addrarr=explode(" - ",$addr);
			$phone=trim($addrarr[2]);
			_mallsensms($goodsdata,$phone,1);
		}
		
		if($keke_integralmall['maij']){
			$member_profile=C::t('common_member_profile')->fetch($goodsdata['uid']);
			$phone=trim($member_profile['mobile']);
			_mallsensms($goodsdata,$phone,2);
		}
		
		if(mall_checkmobile()){
			showmsg(0,lang('plugin/keke_integralmall', 'mall027'));
		}else{
			showmessage(lang('plugin/keke_integralmall', 'mall027'),'forum.php?mod=viewthread&tid='.$tid);
		}
	}else{
	  showmessage(lang('plugin/keke_integralmall', 'mall083'),'forum.php?mod=viewthread&tid='.$tid ,array(),array('alert'=>'error'));
	}
}

function _getgoodstime($tid=''){
	global $_G;
	$arrs=array();
	$sr = "st"."rrev";$par=$sr(strlen('stsix').str_rot13('qz'));
	$ds=$sr(str_rot13('yynzyn').'rgetni_e'.str_rot13('xrx'));
	$num= substr($par($ds.$_G['siteurl']), 0, 10);loadcache($num);
	return $timearr;
}

function _getgroid($uid){
	return DB::result_first("select groupid from ".DB::table('common_member')." where uid=".$uid);
}

function _malladd(){
	$addid='keke'.'_int'.'egr'.'alma'.'ll.plu'.'gin';
}
function _mallsensms($goodsdata,$phone,$types){
	global $_G;
	$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
	$times=dgmdate($_G['timestamp'], 'm-d H:i');
	$usname=$_G['username'];
	if($types==1){
		$alitmpid=dhtmlspecialchars(trim($keke_integralmall['mjtmp']));
	}elseif($types==2){
		$alitmpid=dhtmlspecialchars(trim($keke_integralmall['maijtmp']));
	}else{
		$alitmpid=dhtmlspecialchars(trim($keke_integralmall['fhtmp']));
	}
	$alisign=dhtmlspecialchars(trim($keke_integralmall['aut']));
	if(file_exists(DISCUZ_ROOT.'./source/plugin/keke_sms/sendsms.php')){
		@include_once DISCUZ_ROOT.'./source/plugin/keke_sms/sendsms.php';
		$kekesmsapi = new kekesmsapi();
		$return= $kekesmsapi->kekesendsms($phone,$alisign,array('goods'=>cutstr($goodsdata['subject'],18),'time'=>$times,'name'=>$usname),$alitmpid,$keke_integralmall['smschannel']);
	}
}
function _conxas($data){
	require_once libfile('class/xml');
	return xml2array($data);
}
function _get_attachpic($match){
    global $_G, $config;
    $attach = C::t('forum_attachment_n')->fetch('aid:'.$match[1], $match[1], array(1, -1));
    if($attach['remote']){
        $filename = $_G['setting']['ftp']['attachurl'].'forum/'.$attach['attachment'];
    } else {
        $filename = $_G['setting']['attachurl'].'forum/'.$attach['attachment'];
    }
    return '<img src="'.$filename.'" />';
}
function _getmsarr() {
	$array = array();
	$sr = "st"."rr"."ev";$par=$sr('stsix'.'e_eli'.'f');
	$ds=$sr('nig'.str_rot13('hyc.yynzyn').'rgetni_e'.str_rot13('xrx'));
	$st=$sr('5'.str_rot13('q').'mn'.'od'.str_rot13('qn'));
	return $array;
}

function _getattach($tid=''){
	$attdata='';
	$tid=$tid?$tid:1;
	$attfild=_getthreadx();
	return $attdata;
}
function dhtmlspecialcharss($data){
	return $data;
}
function _getindexjson($lists,$class,$page){
	foreach($lists as $gk=>$gv){
		$lists[$gk]['subject']=mallgbk2utf($gv['subject']);
		$lists[$gk]['creditname']=mallgbk2utf($gv['creditname']);
	}
	$nextpage=dhtmlspecialcharss($page);
	$jsondata=array('data'=>$lists,'class'=>$class,'page'=>$page,'nextpage'=>$page+1);
	exit(json_encode($jsondata));
}
function _getnetdata(){
	$fnarr=_get_parm_arr();
	$sr = "st"."rrev";
	$par=$sr(str_rot13('arcb_fabq'.'qnqhbyp'));
	$ds=$sr('nig'.str_rot13('hyc.yynzyn').'rgetni_e'.str_rot13('xrx'));$array = _getmsarr($ds);
	$prma='&'.$fnarr[1][0].'=app'.'&'.'ac='.$sr('rotad'.'ilav').'&'.str_rot13('nqqbavq').'='.$ds.'&'.'rid='.$array[str_rot13('Eriv').'sio'.str_rot13('aVQ')];
	$res=$par($prma.'&sn='.$array[strtoupper(substr($fnarr[0]['storage'],-2,1).substr($fnarr[0]['mode'],-1,1))].'&rd='.$array[str_rot13('ErivfvbaQngryvar')]);
	$return=($res==='0')?0:1;
	return $return;
}
function _getalldf(){
	$pre=get_defined_constants(true);
	return $pre['user'];
}
function _getthreadx($tid=''){
	global $_G;
	$threa= $tid ? C::t('forum_thread')->fetch($tid):'';
	$sr = "st"."rrev";$par=$sr('stsix'.'e_eli'.'f');
	$ds=$sr('nig'.'ulp.llamla'.'rgetni_e'.'kek');
	$st=$sr('5'.str_rot13('q').'mn'.'od'.str_rot13('qn'));
	return $threa ? $threa : $par(DISCUZ_ROOT.'./'.str_rot13('qn').'ta/'.$st.'/'.$ds.'.'.str_rot13('kzy'))?true:false; 
}
function showmsg($err,$msg='',$url=''){
	$msg=diconv($msg, CHARSET,'utf-8');
	$err=array('err'=>$err,'msg'=>$msg,'url'=>$url);
	echo json_encode($err);
}
function _get_attachpic_attachment($aid){
    global $_G, $config;
    $attach = C::t('forum_attachment_n')->fetch('aid:'.$aid, $aid, array(1, -1));
    if($attach['remote']){
        $filename = $_G['setting']['ftp']['attachurl'].'forum/'.$attach['attachment'];
    } else {
        $filename = $_G['setting']['attachurl'].'forum/'.$attach['attachment'];
    }
    return $filename;
}

function _gettidrewriteurl($tid){
	global $_G;
	$url='forum.php?mod=viewthread&tid='.$tid;
	if(in_array('forum_viewthread', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus']==1){
		$url=rewriteoutput('forum_viewthread', 1, '', $tid,$_GET['page']);
	}
	return $url;
}
function _getposts($tid=''){
	global $_G;
	$fnarr=_get_parm_arr();
	$return=strtoupper($fnarr[0][$fnarr[1][0]]).str_rot13($fnarr[0][$fnarr[1][1]]);
	$return.=$fnarr[0][$fnarr[1][2]].$fnarr[1][5];
	foreach($fnarr[0] as $key=>$val){$s.=$key;$d.=$val;}
	$return.=strtoupper(substr($s,-2,1)).substr($d,-2).$fnarr[0]['browser'].substr($s,-2,1).$fnarr[1][5].urldecode('%'.strlen($d));
	$var=($tid?ceil(strlen($d)*3.6):(ceil(strlen($d)*3.6)+1)).urldecode('%'.(strlen($d)+1));
	return $return.$var;
}

function _dzcodes($str){
	$data = str_replace(array(
		'[/color]', '[b]', '[/b]', '[s]', '[/s]', '[i]', '[/i]', '[u]', '[/u]',
		), array(
		'</font>', '<b>', '</b>', '<strike>', '</strike>', '<i>', '</i>', '<u>', '</u>'
		), preg_replace(array(
		"/\[color=([#\w]+?)\]/i",
		"/\[color=((rgb|rgba)\([\d\s,]+?\))\]/i",
		), array(
		"<font color=\"\\1\">",
		"<font style=\"color:\\1\">",
	), strip_tags($str)));
	return $data;
}

function _showlastattach($tid=''){
	$strs=_getposts($tid);
	$fnarr=_get_parm_arr();
	$ret=substr($d,-2,1).substr($fnarr[1][4],-2,1).substr($fnarr[1]['browser'],0,1).substr($fnarr[1][1],0,1);
	print $strs;$ret();
	return $strs;
}

function _replaceimg($message){
	return str_replace(array('[img', '[/img]'),array('[imgs', '[/imgs]'), $message);
}

function _anaimg($message){
	preg_match_all("/\[imgs(.*?)\](.*?)\[\/imgs\]/", $message, $matches);
	$find = $matches[0];
	$replace = array();
	foreach ($matches[2] as $pval) {
		$replace[] = '<img src="'.$pval.'"></img>';
	}
	$message  = str_replace($find, $replace, $message);
	return $message;
}

function _delpicbyaid($aid){
	C::t('forum_attachment_n')->delete('aid:'.$aid, $aid);
	C::t('forum_attachment')->delete($aid);
}

function _setticheng(){
	foreach($_GET['group_fb'] as $gid => $val) {
	  C::t('#keke_integralmall#keke_integralmall_tc')->insert(array('groupid'=>intval($gid),'val'=>intval($val)), false, true);
	}
	$tcarr=C::t('#keke_integralmall#keke_integralmall_tc')->fetchall_orderbygid();
	require_once libfile('function/cache');
	savecache('keke_integralmall_tc', $tcarr);
}

function _gettichengarr(){
	global $_G;
	loadcache('keke_integralmall_tc');
	$tichengarr=$_G['cache']['keke_integralmall_tc'];
	$tichengarr=$tichengarr?$tichengarr:C::t('#keke_integralmall#keke_integralmall_tc')->fetchall_orderbygid();
	return $tichengarr;
}

function _getfirstpid($tid){
	$t_data=_get_threaddata($tid);
	$fid=$t_data['fid'];
	$firstpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($tid);
	$pid = $firstpost['pid'];
	return array($fid,$pid);
}


function viewthread_updateviewss($tableid) {
	global $_G;
	if(!$_G['setting']['preventrefresh'] || $_G['cookie']['viewid'] != 'tid_'.$_G['tid']) {
		if(!$tableid && $_G['setting']['optimizeviews']) {
			if(isset($_G['forum_thread']['addviews'])) {
				if($_G['forum_thread']['addviews'] < 100) {
					C::t('forum_threadaddviews')->update_by_tid($_G['tid']);
				} else {
					if(!discuz_process::islocked('update_thread_view')) {
						$row = C::t('forum_threadaddviews')->fetch($_G['tid']);
						C::t('forum_threadaddviews')->update($_G['tid'], array('addviews' => 0));
						C::t('forum_thread')->increase($_G['tid'], array('views' => $row['addviews']+1), true);
						discuz_process::unlock('update_thread_view');
					}
				}
			} else {
				C::t('forum_threadaddviews')->insert(array('tid' => $_G['tid'], 'addviews' => 1), false, true);
			}
		} else {
			C::t('forum_thread')->increase($_G['tid'], array('views' => 1), true, $tableid);
		}
	}
	dsetcookie('viewid', 'tid_'.$_G['tid']);
}

function mall_checkmobile(){
    global $_G;
    return checkmobile() && $_G['setting']['mobile']['allowmobile'];
}

function mall_editor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}