<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$table = array();
	showtips(lang('plugin/keke_integralmall', 'mall065'));
    showtableheader(lang('plugin/keke_integralmall', 'mall070'));	
    showsubtitle(array(lang('plugin/keke_integralmall', 'mall071'),'', lang('plugin/keke_integralmall', 'mall072'), lang('plugin/keke_integralmall', 'mall073')));
	$wap=file_exists("source/plugin/keke_sms/sendsms.php")? '<span class="diffcolor2">'.lang('plugin/keke_integralmall', 'mall066').'</span>' : '<a href="https://dism.taobao.com/?@keke_sms.plugin"><span class="error">'.lang('plugin/keke_integralmall', 'mall067').'</span></a>';	
	$table[0] = '<img src="source/plugin/keke_integralmall/template/images/keke_sms.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_integralmall', 'mall068');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_integralmall', 'mall069').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	$waps=file_exists("source/plugin/keke_chongzhi/keke_chongzhi.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_integralmall', 'mall066').'</span>' : '<a href="https://dism.taobao.com/?@keke_chongzhi.plugin"><span class="error">'.lang('plugin/keke_integralmall', 'mall067').'</span></a>';		
	$table[0] = '<img src="source/plugin/keke_integralmall/template/images/keke_chongzhi.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_integralmall', 'mall074');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_integralmall', 'mall075').'</span>';
	$table[3] = $waps;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	
	$wapsa=file_exists("source/plugin/keke_share/get_sdk.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_integralmall', 'mall066').'</span>' : '<a href="https://dism.taobao.com/?@keke_share.plugin"><span class="error">'.lang('plugin/keke_integralmall', 'mall067').'</span></a>';		
	$table[0] = '<img src="source/plugin/keke_integralmall/template/images/keke_share.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_integralmall', 'mall081');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_integralmall', 'mall082').'</span>';
	$table[3] = $wapsa;
	showtablerow('', array('width="70"','width="180"', 'width="600"'), $table);
	
    showtablefooter(); /*dism _taobao _com*/
