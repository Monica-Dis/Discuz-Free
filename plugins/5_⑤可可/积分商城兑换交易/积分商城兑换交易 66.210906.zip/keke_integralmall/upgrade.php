<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_integralmall'));
while($row = DB::fetch($query)) {
	$col[]=$row['Field']; 
}

if(!in_array('credit', $col)){
	$sql = "Alter table ".DB::table('keke_integralmall')." add `credit` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('cfxs', $col)){
	$sql = "Alter table ".DB::table('keke_integralmall')." add `cfxs` int(2) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}



$querys = DB::query("SHOW COLUMNS FROM ".DB::table('keke_integralmall_log'));
while($rows = DB::fetch($querys)) {
	$cols[]=$rows['Field']; 
}

if(!in_array('total', $cols)){
	$sqls = "Alter table ".DB::table('keke_integralmall_log')." add `total` int(10) unsigned NOT NULL default 1;"; 
	DB::query($sqls); 
}

if(!in_array('ly', $cols)){
	$sqls = "Alter table ".DB::table('keke_integralmall_log')." add `ly` varchar(500) NOT NULL;"; 
	DB::query($sqls); 
}

if(!in_array('fhuid', $cols)){
	$sqls = "Alter table ".DB::table('keke_integralmall_log')." add `fhuid` int(20) NOT NULL;"; 
	DB::query($sqls); 
}

$keke_integralmall_tc= DB::table("keke_integralmall_tc");
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `$keke_integralmall_tc` (
  `groupid` int(10) NOT NULL,
  `val` int(10) NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

$keke_integralmall_set= DB::table("keke_integralmall_set");
$sqlintegralmall_set = <<<EOF
CREATE TABLE IF NOT EXISTS `$keke_integralmall_set` (
  `uid` int(20) NOT NULL,
  `val` varchar(100) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM;
EOF;
runquery($sqlintegralmall_set);

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_integralmall/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_integralmall/upgrade.php');