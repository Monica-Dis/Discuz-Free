<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_integralmall extends discuz_table
{
	public function __construct() {
		$this->_table = 'keke_integralmall';
		$this->_pk = 'tid';
		parent::__construct(); /*dism��taobao��com*/
	}
	
	public function fetch_by_tid($tid) {
		return DB::fetch_all("SELECT a.*,b.replies FROM %t a,%t b WHERE a.tid IN (%n) AND a.tid=b.tid", array($this->_table,'forum_thread',$tid));
	}
	
	public function fetchall_bythread($startlimit,$ppp,$where='',$order='') {
		$orders=$order?'order by '.$order:'order by b.displayorder DESC ,a.tid desc';
		return DB::fetch_all("SELECT a.*,b.subject FROM %t a,%t b WHERE a.tid=b.tid AND b.displayorder>=0 $bks %i %i LIMIT %d,%d", array($this->_table,'forum_thread',$where,$orders,$startlimit,$ppp));
	}
	
	
	public function count_all($where='') {
		global $_G;
		$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
		$bk=dimplode(unserialize($keke_integralmall['bk']));
		$bks=$keke_integralmall['bk']?'AND b.fid in ('.$bk.')':'';
		return DB::result_first("SELECT count(*) FROM %t a,%t b WHERE a.tid=b.tid AND b.displayorder>=0 $bks %i", array($this->_table,'forum_thread',$where));
	}
	
		
	public function count_by_uid($uid) {
		return DB::result_first("SELECT count(1) FROM %t WHERE uid=%d ", array($this->_table,$uid));
	}
	
	public function fetch_all_by_uid($uid,$startlimit,$ppp) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d order by tid desc LIMIT %d,%d", array($this->_table,$uid,$startlimit,$ppp));
	}
	
	
	
	public function delete_by_tid($tid) {
		return DB::query("delete FROM %t where tid=%d", array($this->_table,$tid));
	}
	
	public function fetch_by_state($state,$tid) {
		return DB::result_first("SELECT count(*) FROM %t WHERE state IN (%d) AND tid=%d", array($this->_table,$state,$tid));
	}
	
	public function update_by_tid($tid,$id) {
		return DB::query('update %t set tid=%d where id=%d', array($this->_table,$tid,$id));
	}
	
}
//From: Dism_taobao_com
?>