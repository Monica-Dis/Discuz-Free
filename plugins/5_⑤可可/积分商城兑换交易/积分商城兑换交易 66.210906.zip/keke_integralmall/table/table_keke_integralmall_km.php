<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_integralmall_km extends discuz_table
{
	public function __construct() {
		$this->_table = 'keke_integralmall_km';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}
	
	 public function inserts($tid, $kmdata){
        $data = '';
        foreach($kmdata as $val) {
			if($val){
            	$data .= "(null,'{$tid}','".daddslashes($val)."','0','0','',''),";
			}
        }
        $data = trim($data, ',');
        return DB::query("INSERT INTO %t VALUES %i",array($this->_table,$data));
	}
	
	
	
	public function fetch_by_tid($tid) {
		return DB::fetch_all("SELECT * FROM %t WHERE tid IN ($tid) ORDER by id ASC", array($this->_table,$tid));
	}
	
	public function fetchfirst_by_tid($tid) {
		return DB::fetch_first("SELECT * FROM %t WHERE tid=%d ORDER by id ASC", array($this->_table,$tid));
	}
	
	public function fetchfirst_by_tidnull($tid) {
		return DB::fetch_first("SELECT * FROM %t WHERE tid=%d AND uid=0", array($this->_table,$tid));
	}
	
	public function fetch_by_tidnull($tid) {
		return DB::fetch_all("SELECT * FROM %t WHERE tid=%d AND uid=0", array($this->_table,$tid));
	}
	
	public function count_by_tidnull($tid) {
		return DB::result_first("SELECT count(1) FROM %t WHERE tid=%d AND uid=0", array($this->_table,$tid));
	}
	
	public function set_buykm($uid, $tid){
        return DB::query("UPDATE %t SET uid=%d,time=%d WHERE tid=%d AND uid='0' ORDER by id ASC LIMIT 1", array($this->_table,$uid,time(),$tid));
    }

    public function count_all_by_where($where) {
        return DB::result_first("SELECT count(1) FROM %t WHERE 1 AND %i", array($this->_table,$where));
    }

    public function fetch_all_by_where($where,$startlimit,$ppp) {
        return DB::fetch_all("SELECT * FROM %t WHERE 1 AND %i order by id asc LIMIT %d,%d", array($this->_table,$where,$startlimit,$ppp));
    }
	
	
}
//From: Dism_taobao_com
?>