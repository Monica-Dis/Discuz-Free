<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_integralmall_log extends discuz_table
{
	public function __construct() {
		$this->_table = 'keke_integralmall_log';
		$this->_pk = 'id';
		parent::__construct(); /*dism��taobao��com*/
	}
	
	public function fetch_by_tid($tid) {
		return DB::fetch_all("SELECT a.*,b.replies FROM %t a,%t b WHERE a.tid IN ($tid) AND a.tid=b.tid", array($this->_table,'forum_thread'));
	}
	
	
	public function count_by_tid($tid,$uid=0,$type=0) {
		$where='';
		
		if(!$type && $uid){
			$where=' AND a.uid='.$uid;
		}elseif($type==2 && $uid){
			$where=' AND a.auid='.$uid;
		}
		
		if($tid)$where.=' AND a.tid IN ('.$tid.')';
		
		return DB::result_first("SELECT count(1) FROM %t a,%t b WHERE id>0 AND a.tid=b.tid AND b.displayorder>=0 ".$where, array($this->_table,'forum_thread',$tid));
	}
	
	public function fetch_all_by_tid($tid,$startlimit,$ppp,$uid=0,$type=0) {
		$where='';
		if(!$type && $uid){
			$where=' AND a.uid='.$uid;
		}elseif($type==2 && $uid){
			$where=' AND a.auid='.$uid;
		}
		if($tid)$where.=' AND a.tid IN ('.$tid.')';
		return DB::fetch_all("SELECT a.* FROM %t a,%t b WHERE a.id>0 AND a.tid=b.tid AND b.displayorder>=0 ".$where." order by a.time desc LIMIT %d,%d", array($this->_table,'forum_thread',$startlimit,$ppp));
	}
	
	public function delete_by_tid($tid) {
		return DB::query("delete FROM %t where tid=%d", array($this->_table,$tid));
	}
	
	public function fetchfirst_by_id($ids) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$ids));
	}
	
	public function countsum_by_tidanduid($tid,$uid=0) {
		$where=$uid?' AND uid='.$uid:'';
		$ret=DB::result_first("SELECT sum(total) FROM %t WHERE tid=%d ".$where, array($this->_table,$tid));
		$ret= $ret ? $ret:0;
		return $ret;
	}
	
}
//From: Dism_taobao_com
?>