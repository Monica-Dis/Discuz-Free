<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_keke_integralmall {
	public function __construct(){
		global $_G;
		$this->keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
		$this->perform=1;
		$this->fid=$_G['fid'];
		$this->section = empty($this->keke_integralmall['bk']) ? array() : unserialize($this->keke_integralmall['bk']);
		if(!(empty($this->section[0]) || in_array($this->fid,$this->section))){
			$this->perform=0;
		}
		$this->creditname=$_G['setting']['extcredits'][$this->keke_integralmall['jf']]['title'];
	}
	
	function global_footer() {
		$oper=$_GET['operations'];
		if(submitcheck('modsubmit') && $_GET['moderate'] && $oper[0]=="delete" && $this->perform){
			foreach(dhtmlspecialchars($_GET['moderate']) as $k => $v) {
				$tid=intval($v);
				C::t('#keke_integralmall#keke_integralmall')->delete_by_tid($tid);
				C::t('#keke_integralmall#keke_integralmall_log')->delete_by_tid($tid);
			}
		}
	}
}

class plugin_keke_integralmall_forum extends plugin_keke_integralmall{
	function post_top(){
		global $_G;
		if(!$this->perform)return;
		$actions=$_GET['action'];
		$returns='';
		$fyhz = empty($this->keke_integralmall['fyhz']) ? array() : unserialize($this->keke_integralmall['fyhz']);
		if(!(empty($fyhz[0]) || in_array($_G['groupid'],$fyhz))){
			return;
		}
		include_once DISCUZ_ROOT . './source/plugin/keke_integralmall/function/function_fun.php';
		if(($actions=="newthread" || $actions=="edit")&&$_G['uid']>0){
			if(submitcheck('topicsubmit') && $_GET['tlx']){
				$keke_mall_lx=intval($_GET['keke_mall_lx']);
				$keke_mall_total=intval($_GET['keke_mall_total']);
				$keke_mall_km=$_GET['keke_mall_km'];
				$keke_mall_time=strtotime($_GET['keke_mall_time']);
				$keke_mall_endtime=strtotime($_GET['keke_mall_endtime']);
				$keke_mall_price=intval($_GET['keke_mall_price']);
				if($keke_mall_lx==1 && $keke_mall_total=='')showmessage(lang('plugin/keke_integralmall', 'mall001'),'');
				if($keke_mall_lx==2 && $keke_mall_km=='')showmessage(lang('plugin/keke_integralmall', 'mall002'),'');
				if($keke_mall_price=='')showmessage(lang('plugin/keke_integralmall', 'mall003'),'');
				if($keke_mall_price<0)showmessage(lang('plugin/keke_integralmall', 'mall076'),'');
				if($keke_mall_time=='' || $keke_mall_endtime=='')showmessage(lang('plugin/keke_integralmall', 'mall004'),'');
				if($_GET['cftotal'] && !$keke_mall_total)showmessage(lang('plugin/keke_integralmall', 'mall096'),'');
			}elseif($actions=="edit"){
				$goodsdata=_get_goodsdata($_G['tid']);
				$time=dgmdate($goodsdata['time'], 'Y-m-d H:i:s');
				$endtime=dgmdate($goodsdata['endtime'], 'Y-m-d H:i:s');
				$total=intval($goodsdata['total']);
				$price=intval($goodsdata['price']);
				$mprice=dhtmlspecialchars($goodsdata['mprice']);
				$km=_get_kmlist($_G['tid']);
				$xg=intval($goodsdata['xg']);
				$thumbpic=getforumimg($goodsdata['aid'], 0, 300, 300);
				if($_GET['delete']==1){
					$tid=intval($_GET['tid']);
					C::t('#keke_integralmall#keke_integralmall')->delete_by_tid($tid);
					C::t('#keke_integralmall#keke_integralmall_log')->delete_by_tid($tid);
				}
			}
			$cre=$goodsdata['credit'] ? $goodsdata['credit'] : $this->keke_integralmall['jf'];
			$tcarr=_gettichengarr();
			if($this->keke_integralmall['creditid']){
				$crearrs=explode(",", $this->keke_integralmall['creditid']);
				foreach($crearrs as $zkey=>$zval){
					if($zval){
						$zdcre[$zval]=array('title'=>$_G['setting']['extcredits'][$zval]['title']);
					}
				}
			}
			$credittypes=$zdcre?$zdcre:$_G['setting']['extcredits'];
			foreach($credittypes as $k =>$v){
			if($k==$cre)
				$creop.= '<option value="'.$k.'" selected>'.$v['title'].'</option>';
			else
				$creop.= '<option value="'.$k.'">'.$v['title'].'</option>';
			}
			if($actions=="edit" && $_G['tid']){
				$thread = C::t('forum_thread')->fetch($_G['tid']);
				if(!($thread['authorid']==$_G['uid']) && $_G['groupid']!=1){
					return;
				}
			}
			$hach=md5(substr(md5($_G[config][security][authkey]), 8).$_G['uid']);
			include template('keke_integralmall:input');
			$inputhook=lang('plugin/keke_integralmall', 'mall080').'</span>';
			if($actions=="edit")$lx='';
			if(!$_G['setting']['rewritestatus']){
				$_G['setting']['rewritestatus'] = true;
			}
			$_G['setting']['output']['str']['search']['keke_integralmall_'] = $inputhook;
			$_G['setting']['output']['str']['replace']['keke_integralmall_'] = $inputhook.$lx.'</div></div><div><div>'.$return;
			$_G['setting']['output']['str']['search']['keke_integralmall_a'] = lang('plugin/keke_integralmall', 'mall044');
			$_G['setting']['output']['str']['replace']['keke_integralmall_a'] = lang('plugin/keke_integralmall', 'mall045');
			
			if(mall_checkmobile()){
				$returns=$return;
			}
			return $returns;	
		}
		
	}
	
	function viewthread_posttop_output(){
		global $_G,$postlist;
        $keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
		if(!$this->perform)return array();
		include_once DISCUZ_ROOT . './source/plugin/keke_integralmall/function/function_fun.php';
		$goodsdata=_get_goodsdata($_G['tid']);
		if(!$goodsdata){
			return array();
		}
		if(mall_checkmobile() && $this->keke_integralmall['xq'] && $goodsdata){
			header("location:plugin.php?id=keke_integralmall:view&tid=".$_G['tid']);
		}
		$imglist=$postlist[$_G['forum_firstpid']]['imagelist'];
		if($goodsdata['aid']){
			$kname=array_search($goodsdata['aid'],$imglist);
			$imgval=$postlist[$_G['forum_firstpid']]['imagelist'][$kname];
			if($imgval)unset($postlist[$_G['forum_firstpid']]['imagelist'][$kname]);
		}
		$thumb = getforumimg($goodsdata['aid'], 0, 300, 300);
		if(mall_checkmobile()){
            $thumb = getforumimg($goodsdata['aid'], 0, 500, 500);
        }
		$buylist=_get_buylist($_G['tid'],5);
		$stime=dgmdate($goodsdata['time'], 'Y/m/d H:i:s');
		$etime=dgmdate($goodsdata['endtime'], 'Y/m/d H:i:s');
		$buycount = C::t('#keke_integralmall#keke_integralmall_log')->countsum_by_tidanduid($_G['tid']);
		$sycount=$goodsdata['total'];
		$per=($sycount/($sycount+$buycount))*100;
		$this->keke_integralmall['gmcl']=dhtmlspecialchars($this->keke_integralmall['gmcl']);
		$this->keke_integralmall['jdtcl']=dhtmlspecialchars($this->keke_integralmall['jdtcl']);
		$satedata=C::t('#keke_integralmall#keke_integralmall_set')->fetchfirst_by_uid($_G['thread']['authorid']);
		if($satedata['val']){
			$valarr=explode(',',$satedata['val']);
		}
		include template('keke_integralmall:show');
		$temp=array();
		$temp[0]=$return;
		if($_G['forum_firstpid'] && $this->keke_integralmall['compatible']==2){
			$msg=$postlist[$_G['forum_firstpid']]['message'];
			$postlist[$_G['forum_firstpid']]['message']=$return.$msg;
			return array();
		}elseif($_G['forum_firstpid'] && $this->keke_integralmall['compatible']==1){
			return $temp;	
		}
		
		
		
	}
	
	function post_message($param) {
		global $_G;
		$param = $param['param'];
		if(($param[0]=="post_newthread_succeed" || $param[0]=="post_newthread_mod_succeed" || $param[0]=="post_edit_succeed" || $param[0]==lang('plugin/keke_integralmall', 'mall085')) && $this->perform && $_GET['tlx']){
			include_once DISCUZ_ROOT . './source/plugin/keke_integralmall/function/function_fun.php';
			$tid = intval($param[2]['tid']);
			$pid = intval($param[2]['pid']);
			$aid=intval($_GET['tradeaid']);
			$keke_mall_lx=intval($_GET['keke_mall_lx']);
			$keke_mall_total=intval($_GET['keke_mall_total']);
			$keke_mall_time=strtotime($_GET['keke_mall_time']);
			$keke_mall_endtime=strtotime($_GET['keke_mall_endtime']);
			$keke_mall_price=intval($_GET['keke_mall_price']);
			$keke_mall_mprice=daddslashes($_GET['keke_mall_mprice']);
			$keke_mall_xg=intval($_GET['keke_mall_xg']);
			$subject=daddslashes($_GET['subject']);
			$credit=$_GET['keke_mall_credi'] ? intval($_GET['keke_mall_credi']) : $this->keke_integralmall['jf'];
			$arr = array(
				'uid' => $_G['uid'],
				'tid'=> $tid,
				'aid'=> $aid,
				'mod'=> $keke_mall_mode,
				'type'=> $keke_mall_lx,
				'total'=> $keke_mall_total,
				'time'=> $keke_mall_time,
				'endtime'=> $keke_mall_endtime,
				'price'=> $keke_mall_price,
				'mprice'=> $keke_mall_mprice,
				'jj'=>$keke_mall_jj,
				'xg'=>$keke_mall_xg,
				'credit'=>	$credit,
				'subject'=>$subject,
				'cfxs'=>intval($_GET['cftotal'])
			);
			if($param[0]=="post_edit_succeed"){
				$tdata=_get_threaddata($tid);
				$goodsdata=_get_goodsdata($tid);
				$arr['uid']=$tdata['authorid'];
				if(!($aid==$goodsdata['aid'])){
					_delpicbyaid($goodsdata['aid']);
				}
			}
			if($keke_mall_lx==2){
				$keke_mall_km=daddslashes($_GET['keke_mall_km']);
				$km=$kms=array();
				if($param[0]=="post_edit_succeed"){
					if($goodsdata['cfxs']){
						$sycount=C::t('#keke_integralmall#keke_integralmall_km')->count_by_tidnull($tid);
						$xtotal=$keke_mall_total-$sycount;
						if($xtotal>0){
							$kmdata=C::t('#keke_integralmall#keke_integralmall_km')->fetchfirst_by_tid($tid);
							for($i=0;$i<$xtotal;$i++){
								$kms[$i]=$kmdata['km'];
							}
						}
						$arr['cfxs']=1;
					}
				}else{
					if($_GET['cftotal']){
						$kms[]=$keke_mall_km;
					}else{
						$km=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_mall_km));
						foreach($km as $kmkey=>$kmval){
							 if($kmval){
								$kms[$kmkey]=$kmval;
							 }
						}
						$arr['total']=count($kms);
					}
				}
				if($kms){
					C::t('#keke_integralmall#keke_integralmall_km')->inserts($tid, $kms);
				}
			}
			C::t('#keke_integralmall#keke_integralmall')->insert($arr, false, true);
			convertunusedattach($aid, $tid, $pid);
			C::t('forum_attachment')->update($aid, array('tid' => 0, 'pid' => 0));
		}
	}
	
}

class mobileplugin_keke_integralmall_forum extends plugin_keke_integralmall_forum{
	function viewthread_posttop_mobile_output(){
		if($this->keke_integralmall['compatible']==1){
			return $this->viewthread_posttop_output();
		}else{
			return array();
		}
	}
	function post_bottom_mobile(){
		return $this->post_top();
	}
}