<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_integralmall= DB::table("keke_integralmall");
$keke_integralmall_addr= DB::table("keke_integralmall_addr");
$keke_integralmall_km= DB::table("keke_integralmall_km");
$keke_integralmall_log= DB::table("keke_integralmall_log");
$keke_integralmall_tc= DB::table("keke_integralmall_tc");
$keke_integralmall_set= DB::table("keke_integralmall_set");


$sql = <<<EOF
CREATE TABLE `$keke_integralmall` (
  `tid` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `aid` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `mprice` float(10,2) NOT NULL,
  `jj` int(20) NOT NULL,
  `time` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `mod` int(5) NOT NULL,
  `type` int(10) NOT NULL,
  `state` int(10) NOT NULL default '1',
  `subject` varchar(100) NOT NULL,
  `xg` int(10) NOT NULL,
  `credit` int(20) NOT NULL,
  `cfxs` int(2) NOT NULL,
  PRIMARY KEY  (`tid`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_integralmall_addr` (
  `uid` int(10) NOT NULL,
  `name` varchar(10) NOT NULL,
  `fullarea` varchar(50) NOT NULL,
  `addr` varchar(30) NOT NULL,
  `tel` varchar(20) NOT NULL,
  `areabox` text NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_integralmall_km` (
  `id` int(10) NOT NULL auto_increment,
  `tid` int(10) NOT NULL,
  `km` mediumtext NOT NULL,
  `uid` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  `state` int(10) NOT NULL default '1',
  `type` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_integralmall_log` (
 `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `auid` int(10) NOT NULL,
  `usname` varchar(10) NOT NULL,
  `tid` int(10) NOT NULL,
  `total` int(10) NOT NULL default '1',
  `price` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  `type` int(10) NOT NULL default '1',
  `fhuid` int(20) NOT NULL,
  `kd` varchar(10) NOT NULL,
  `dh` varchar(50) NOT NULL,
  `bz` varchar(50) NOT NULL,
  `addr` varchar(100) NOT NULL,
  `ly` varchar(500) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_integralmall_tc` (
 `groupid` int(10) NOT NULL,
  `val` int(10) NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_integralmall_set` (
  `uid` int(20) NOT NULL,
  `val` varchar(100) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM;


EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_integralmall/discuz_plugin_keke_integralmall_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_integralmall/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_integralmall/upgrade.php');