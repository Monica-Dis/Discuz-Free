<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
global $_G;

$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
include_once DISCUZ_ROOT . './source/plugin/keke_integralmall/function/function_fun.php';
$creditname=$_G['setting']['extcredits'][$keke_integralmall['jf']]['title'];
$navtitle=dhtmlspecialchars($keke_integralmall['pctitle']);
$wapnavtitle=dhtmlspecialchars($keke_integralmall['waptitle']);
$waph=dhtmlspecialchars($keke_integralmall['waph']);
$wapbottom=dhtmlspecialchars($keke_integralmall['wapbottom']);
$about=dhtmlspecialcharss($about);
$section = empty($keke_integralmall['bk']) ? array() : unserialize($keke_integralmall['bk']);
$pages=intval($keke_integralmall['pages']);
$ppp=$pages ? $pages : 10;
$_GET['class']=intval($_GET['class']);
$_GET['order']=intval($_GET['order']);
if($_GET['class']){
	$parameter='&class='.$_GET['class'];
}
if($_GET['order']){
	$parameter.='&order='.$_GET['order'];
}
$tmpurl='plugin.php?id=keke_integralmall'.$parameter;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$type=intval($_GET['type']);
$_Info['sid']='';
$nowcredit = getuserprofile('extcredits'.$keke_integralmall['jf']);
$mobile='';
if(mall_checkmobile()){
	$wappicarr=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_integralmall['wapgdt']));
	foreach($wappicarr as $key=>$vl){
		$wappicdata=explode('|',$vl);
		$wappic.='<div><a href="'.dhtmlspecialchars($wappicdata[1]).'"><img src="'.dhtmlspecialchars($wappicdata[0]).'"></a></div>';
		$lilist.='<li></li>';
	}
}else{
	$picarr=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_integralmall['gdt']));
	foreach($picarr as $k=>$item){
		$picdata=explode('|',$item);
		$picdata[0]=
		$gdpic.='<li><a href="'.dhtmlspecialchars($picdata[1]).'" target="_blank"><div class="gdpic" style=" background:url('.dhtmlspecialchars($picdata[0]).') center;"></div></a></li>';
		$lilist.='<li></li>';
	}
}
$where='';
if($keke_integralmall['total']){
	$where.=' AND a.total>0';
}
if($keke_integralmall['endtime']){
	$where.=' AND a.endtime>'.TIMESTAMP;
}
if($_GET['class']){
	$where.=' AND b.typeid='.$_GET['class'];
}
$order='';
$orders=intval($_GET['order']);
if($orders==1){
	$order='a.price asc';
}elseif($orders==2){
	$order='a.price desc';
}elseif($orders==3){
	$order='a.total desc';
}elseif($orders==5){
	$order='a.endtime desc';
}
$fids = array();
if($keke_integralmall['hide']){
	loadcache('forums');
	$forum_forumfield=C::t('forum_forumfield')->fetch_all_by_fid($section);
	foreach($section as $fid) {
		if($_G['cache']['forums'][$fid]['viewperm'] && !forumperm($_G['cache']['forums'][$fid]['viewperm'],$_G['groupid'])){
			continue;
		}else{
			$formulaperms = dunserialize($forum_forumfield[$fid]['formulaperm']);
			if($formulaperms['users']){
				$permusers = str_replace(array("\r\n", "\r"), array("\n", "\n"), $formulaperms['users']);
				$permusers = explode("\n", trim($permusers));
				if(!in_array($_G['member']['username'], $permusers)) {
					continue;
				}
			}
		}
		$fids[] = $fid;
	}
}else{
	$fids = $section;
}
$where.=' AND b.fid in ('.dimplode($fids).')';
$allcount = C::t('#keke_integralmall#keke_integralmall')->count_all($where);
$goodsdata=C::t('#keke_integralmall#keke_integralmall')->fetchall_bythread($startlimit,$ppp,$where,$order);
$keke_integralmall['gmcl']=dhtmlspecialchars($keke_integralmall['gmcl']);
$keke_integralmall['jdtcl']=dhtmlspecialchars($keke_integralmall['jdtcl']);
$keke_integralmall['waptcl']=dhtmlspecialchars($keke_integralmall['waptcl']);
$keke_integralmall['waptmp']=dhtmlspecialcharss($keke_integralmall['waptmp']);
$lists=_getgoodsarr($goodsdata);

$picsize=explode("*",$keke_integralmall['pcpicsize']);
$picsize[0]=$picsize[0]?intval($picsize[0]):170;
$picsize[1]=$picsize[1]?intval($picsize[1]):170;
$picsize[2]=$picsize[0]+20;

foreach($lists as $listkey=>$listval){
	if(!mall_checkmobile()){
		$thumb = getforumimg($listval['aid'], 0, intval($picsize[0]), intval($picsize[1]));
		$attach=_getattach($listval['aid']);
		$lists[$listkey]['thumb']=$thumb.$attach;
	}
	$lists[$listkey]['pre']=intval($listval['pre'])>0?$listval['pre']:0;
}

if($keke_integralmall['custype']){
	$typeids=explode(',',$keke_integralmall['custype']);
	$typearr=C::t('forum_threadclass')->fetch_all_by_typeid($typeids);
}else{
	$typearr=_gettypedata();
}

if ($_G['setting']['version'] == 'X3.3' || $_G['setting']['version'] == 'X3.4' || $_G['setting']['version'] == 'F1.0' || $_G['setting']['version'] == 'L1.0') {
	foreach($typearr as $tkey=>$tval){
		$typearr[$tkey]['name']=_dzcodes($tval['name']);
	}
}
$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
if($_GET['ajax']){
	_getindexjson($lists,$class,$page);
}
$issj=1;
$fyhz = empty($keke_integralmall['fyhz']) ? array() : unserialize($keke_integralmall['fyhz']);
if(!(empty($fyhz[0]) || in_array($_G['groupid'],$fyhz))){
	$issj=0;
}
include template('keke_integralmall:index');