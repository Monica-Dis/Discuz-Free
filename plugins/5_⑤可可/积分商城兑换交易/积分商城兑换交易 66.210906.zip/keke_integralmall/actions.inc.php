<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_integralmall = $_G['cache']['plugin']['keke_integralmall'];
$_Info['sid']='';
$creditname=$_G['setting']['extcredits'][$keke_integralmall['jf']]['title'];
$tid=intval($_GET['tid']);
$page=intval($_GET['page']);
$ac=$_GET['ac'];
if($ac=='sid')echo $_Info['sid'];
if($_GET['formhash']!=FORMHASH){
    exit('FORMHASH ERROR');
}
if(!$_G['uid'] && !($ac=='getbuylist') && !($ac=='getmygoods')){
    showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
include_once DISCUZ_ROOT . './source/plugin/keke_integralmall/function/function_fun.php';
if($ac=='xd'){
	xiadan($tid,$_GET['keke_integralmall_hf'],$_GET['addr']);
}elseif($ac=='setadmin'){	
	$array=array(
		'uid'=>$_G['uid'],
		'val'=>$_GET['val']
	);
	C::t('#keke_integralmall#keke_integralmall_set')->insert($array,false,true);
	if(mall_checkmobile()){
		exit(showmsg(1,lang('plugin/keke_integralmall', 'mall086'),$rturl));
	}else{
		showmessage(lang('plugin/keke_integralmall','mall046'),'', array(), array('showdialog' => true, 'closetime' => 3));
	}
}elseif($ac=='kmedit'){	
	$goodsdata=_get_goodsdata($tid);
	if($goodsdata['uid']!=$_G['uid']){
		exit(showmsg(1,lang('plugin/keke_integralmall', 'mall064'),$rturl));
	}
	$ns=0;
	if(is_array($_GET['delete'])) {
		C::t('#keke_integralmall#keke_integralmall_km')->delete($_GET['delete']);
		$ns=count($_GET['delete']);
	}
	if($goodsdata['cfxs']){
		$kmarr=DB::fetch_all("select id from ".DB::table('keke_integralmall_km')." where uid=0 AND tid=".$tid);
		foreach($kmarr as $k=>$v){
			$arr=array(
				'km'=>daddslashes(dhtmlspecialchars($_GET['km'])),
			);
			C::t('#keke_integralmall#keke_integralmall_km')->update($v['id'],$arr);
		}
	}else{
		foreach($_GET['km'] as $k=>$v){
			if(!$v){
				C::t('#keke_integralmall#keke_integralmall_km')->delete($k);
				$ns++;
			}else{
				$arr=array(
					'km'=>daddslashes(dhtmlspecialchars($v)),
				);
				C::t('#keke_integralmall#keke_integralmall_km')->update($k,$arr);
			}
		}
	}
	if($ns){
		$totals=C::t('#keke_integralmall#keke_integralmall_km')->count_by_tidnull($tid);
		C::t('#keke_integralmall#keke_integralmall')->update($tid,array('total'=>$totals));
	}
	if(mall_checkmobile()){
		exit(showmsg(0,lang('plugin/keke_integralmall', 'mall086'),$rturl));
	}else{
		showmessage(lang('plugin/keke_integralmall', 'mall086'),$rturl, '', array( 'extrajs' => '<script> '.($totals?'showeditwin('.$page.');document.getElementById("keke_mall_total").value='.$totals:'').';</script>'));
	}
}elseif($ac=='kmzj'){
	$goodsdata=_get_goodsdata($tid);
	if($goodsdata['uid']!=$_G['uid']){
		exit(showmsg(1,lang('plugin/keke_integralmall', 'mall064'),$rturl));
	}
	$keke_mall_km=daddslashes($_GET['kmzj']);
	$km=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_mall_km));
	foreach($km as $kmkey=>$kmval){
		 if($kmval){
			$kms[$kmkey]=$kmval;
		 }
	}
	if($kms){
		C::t('#keke_integralmall#keke_integralmall_km')->inserts($tid, $kms);
		$totals=C::t('#keke_integralmall#keke_integralmall_km')->count_by_tidnull($tid);
		C::t('#keke_integralmall#keke_integralmall')->update($tid,array('total'=>$totals));
	}
	if(mall_checkmobile()){
		exit(showmsg(1,lang('plugin/keke_integralmall', 'mall086'),$rturl));
	}else{
		showmessage(lang('plugin/keke_integralmall', 'mall086'),$rturl, '', array('showdialog' => true, 'closetime' => 3, 'extrajs' => '<script>document.getElementById("keke_mall_total").value='.$totals.';setTimeout(function(){hideWindow(\'keke_kmzj\')}, 2000);</script>'));
	}
}elseif($ac=='addr'){
    $rturl='forum.php?mod=viewthread&tid='.$tid;
    if(!$_GET['tel']){
        $tip=lang('plugin/keke_integralmall', 'mall121');
    }
    if(!$_GET['addr']){
        $tip=lang('plugin/keke_integralmall', 'mall120');
    }
    if(!$_GET['name']){
        $tip=lang('plugin/keke_integralmall', 'mall119');
    }
    if($tip){
        if(mall_checkmobile()){
            exit(showmsg(1,$tip,$rturl));
        }else{
            showmessage($tip,$rturl,array(),array('alert' => 'error'));
        }
    }
	$addrarr=array(
		'uid' => $_G['uid'],
		'name' => daddslashes(dhtmlspecialchars($_GET['name'])),
		'areabox' => serialize(strip_tags(mall_editor_safe_replace($_GET['addrboxvalue']), '<select><option>')),
		'addr' => daddslashes(dhtmlspecialchars($_GET['addr'])),
		'fullarea'=>daddslashes(dhtmlspecialchars($_GET['province'].$_GET['city'].$_GET['edist'].$_GET['xiangzhen'])),
		'tel' => daddslashes(dhtmlspecialchars($_GET['tel'])),
	);
	C::t('#keke_integralmall#keke_integralmall_addr')->insert($addrarr, false, true);
	if($_GET['pos']==1){
		$rturl='plugin.php?id=keke_integralmall:order';
	}elseif($_GET['pos']==2){
		$rturl='plugin.php?id=keke_integralmall:show_win&tid=0&ac=buylist&formhash='.FORMHASH.'&type=1';
	}
	if(mall_checkmobile()){
		exit(showmsg(1,lang('plugin/keke_integralmall', 'mall046'),$rturl));
	}else{
		showmessage(lang('plugin/keke_integralmall', 'mall046'),$rturl);
	}
}elseif($ac=='fahuo'){
	$turl='';
	$logid=intval($_GET['logid']);
	if(!$_GET['dh'] && $_GET['kd']!=lang('plugin/keke_integralmall', 'mall093') && $_GET['kd']!=lang('plugin/keke_integralmall', 'mall095'))showmessage(lang('plugin/keke_integralmall', 'mall118'));
	$fhdata=array(
		'kd'=>daddslashes(dhtmlspecialchars($_GET['kd'])),
		'dh'=>daddslashes(dhtmlspecialchars($_GET['dh'])),
		'bz'=>daddslashes(dhtmlspecialchars($_GET['bz'])),
		'fhuid'=>$_G['uid']
	);
	C::t('#keke_integralmall#keke_integralmall_log')->update($logid, $fhdata);
	if(mall_checkmobile()){
		$turl='plugin.php?id=keke_integralmall:show_win&tid='.$tid.'&ac=buylist&formhash='.FORMHASH.'&type=2';
		if($_GET['re']==2){
			$turl='plugin.php?id=keke_integralmall:show_win&tid='.$tid.'&ac=buylist&formhash='.FORMHASH.'&type=2';
		}
	}
	if($keke_integralmall['fh']){
		$logdata=C::t('#keke_integralmall#keke_integralmall_log')->fetchfirst_by_id($logid);
		$addrarr=explode(" - ",$logdata['addr']);
		$phone=trim($addrarr[2]);
		$goodsdata=_get_goodsdata($logdata['tid']);
		_mallsensms($goodsdata,$phone,3);
	}
	if(mall_checkmobile()){
		exit(showmsg(1,lang('plugin/keke_integralmall', 'mall014'),$turl));
	}else{
		showmessage(lang('plugin/keke_integralmall', 'mall014'), $turl, '',
            array('showdialog' => true, 'closetime' => 3, 'extrajs' =>
                '<script>
setTimeout(function(){hideWindow(\'fahuo\')}, 2000);
editbtn('.$logid.');
$("fahuo'.$logid.'").innerHTML=\''.lang('plugin/keke_integralmall', 'mall061').'\';
$("fahuo'.$logid.'").style.color="#3C0";
$("fahuobtn'.$logid.'").innerHTML="'.lang('plugin/keke_integralmall', 'mall060').'";
</script>'));
	}
}elseif($ac=='getbuylist'){
	if($tid && !$_GET['type']){
		$buydata=_get_buylist($tid,5,1,'0','0',$_GET['page']);
	}else{
		$type='';
		$tid=$tid?$tid:0;
		if($_GET['type']==2){
			$type=2;
		}
		$buydata=_get_buylist($tid,10,3,$_G['uid'],$type,$_GET['page']);
	}
	echo $buydata;
	exit();
}elseif($ac=='getmygoods'){
	echo $goodsdata=_get_mygoods($_G['uid']);
	exit();
}elseif($ac=='daochu'){
	$goodsdata=_get_goodsdata($tid);
	if($goodsdata['uid']==$_G['uid']){
		_daochudd($tid);
	}else{
		showmessage(lang('plugin/keke_integralmall', 'mall064'));
	}exit();
}