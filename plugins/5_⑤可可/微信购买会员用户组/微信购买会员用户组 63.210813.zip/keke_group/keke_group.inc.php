<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('CURSCRIPT', 'forum');
global $_G;
$keke_group = $_G['cache']['plugin']['keke_group'];
include_once DISCUZ_ROOT."source/plugin/keke_group/common.php";
if(strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX")!== false && $keke_group['magsecret']){
    $userdata = groupMagUserInfo();
    if($userdata['user_id']){
        require_once libfile('function/member');
        $member = getuserbyuid($userdata['user_id'],1);
        setloginstatus($member, 2592000);
    }else{
        exit('<script src="source/plugin/keke_group/template/js/magjs-x.js"></script><script>mag.toLogin(function(rs){window.location.reload(true);});</script>');
    }
}else{
    if((!$_G['uid'] && $_GET['p']) || ($keke_group['login'] && !$_G['uid'])) {
        showmessage('not_loggedin', NULL, array(), array('login' => 1));
    }
}

if ($_G['cache']['plugin']['keke_market']) {
	$keke_market = $_G['cache']['plugin']['keke_market'];
	require_once DISCUZ_ROOT.'./source/plugin/keke_market/function.php';
	$market_member=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
	$sharebtn=$keke_group['sharebtn'];
	if($keke_group['wapsharetxt']){
		$keke_market['wapsharetxt']=explode('|',$keke_group['wapsharetxt']);
		$keke_market['wapsharetxt']=$market_member?($keke_market['wapsharetxt'][1]?$keke_market['wapsharetxt'][1]:$keke_market['wapsharetxt'][0]):$keke_market['wapsharetxt'][0];
	}
	if($keke_group['pcsharetxt']){
		$keke_market['pcsharetxt']=explode('|',$keke_group['pcsharetxt']);
		$keke_market['pcsharetxt']=$market_member?($keke_market['pcsharetxt'][1]?$keke_market['pcsharetxt'][1]:$keke_market['pcsharetxt'][0]):$keke_market['pcsharetxt'][0];
	}
	binduser();
}

$title=$navtitle=dhtmlspecialchars($keke_group['title']);
$keke_group['waptopcolour']=dhtmlspecialchars($keke_group['waptopcolour']);
$keke_group['pcleftcolour']=dhtmlspecialchars($keke_group['pcleftcolour']);
$keke_group['pcbtncolour']=dhtmlspecialchars($keke_group['pcbtncolour']);
$pcleftbtntxt=explode('|',$keke_group['pcleft']);
$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
if($keke_chongzhi['pcleft']){
    $chongzhipcleftbtntxt=explode('|',$keke_chongzhi['pcleft']);
}
$keke_tixian = $_G['cache']['plugin']['keke_tixian'];
if($keke_chongzhi['pcleft']){
    $tixianPcLeftTxt=explode('|',$keke_tixian['pcleft']);
}
$alipayoff=empty($keke_group['alipaypid']) || empty($keke_group['alipaykey']) ? 0 : 1;
$wxpayoff=empty($keke_group['wxappid']) || empty($keke_group['wxsecert']) || empty($keke_group['wxmchid']) || empty($keke_group['wxshkey']) ? 0 : 1;
$ys=$keke_group['ys']? dhtmlspecialchars($keke_group['ys']) : '#e14546';
$returnurl=$keke_group['tz']?editor_safe_replace($keke_group['tz']):'plugin.php?id=keke_group&p=my';
if(!K_INMINIPROGRAM && (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && !$_GET['p']) && $wxpayoff && checkmobile()){
	include_once libfile('function/cache');
	include_once DISCUZ_ROOT."source/plugin/keke_group/inc.php";
	$tools = new JsApiPay();
	$openId = $tools->GetOpenid();
	dsetcookie($uskey, authcode($openId, 'ENCODE', $_G['config']['security']['authkey']), 8640000);
}
$nowgroup=_getnowgroup();
if($_GET['p']=='my'){
	$pages=intval($_GET['page']);
	$myorderdata=_getmyorder($pages);
	$list=$myorderdata['list'];
	$multipage=$myorderdata['page'];
}elseif($_GET['p']=='sw'){
	$n=1;
	$expirylist=_getmygrouplist();
}elseif($_GET['p']=='loading'){
	$orderid=daddslashes(dhtmlspecialchars($_GET['orderid']));
	if($_GET['unionordernum'] && K_INCMAG && $keke_group['magsecret']){
        $orderdata=C::t('#keke_group#keke_group_orderlog')->fetchfirst_byid($orderid);
        $url = 'http://'.$keke_group['magurl'].'/core/pay/pay/orderStatusQuery?unionOrderNum='.$_GET['unionordernum'].'&secret='.$keke_group['magsecret'];
        $data = dfsockopen($url);
        if(!$data){
            $data = file_get_contents($url);
        }
        $return= json_decode($data,true);
        if($orderdata && $orderdata['state']!=1 && $return['paycode'] == 1){
            _upuserdata($_GET['orderid'],$_GET['unionordernum']);
            $url=$keke_group['tz']? $keke_group['tz'] : $_G['siteurl'].'plugin.php?id=keke_group&p=my';
        }else{
            $url=$_G['siteurl'].'plugin.php?id=keke_group&payfailed=1';
        }
        Header("HTTP/1.1 303 See Other");
        Header("Location: $url");
        exit;
    }
}elseif($_GET['p']=='id'){
	exit(K_SITEID);
}else{
    $classData = C::t('#keke_group#keke_group_class')->fetchall(1);
    if(count($classData)>1){
        $separate=true;
        $_GET['class']=$_GET['class']?intval($_GET['class']):key($classData);
    }
	$gorupdata = _indexdata();
	$keke_group['sm']=editor_safe_replace($keke_group['sm']);
	if ($_G['cache']['plugin']['keke_market'] && $keke_group['share']){
		$course['title']=$keke_group['postertitle'];	
		$invitationtext=str_ireplace("[name]",$_G['username'],$keke_group['posterdec']);
	}
	$topBg  =  getTopBg();
}
include template('keke_group:index');