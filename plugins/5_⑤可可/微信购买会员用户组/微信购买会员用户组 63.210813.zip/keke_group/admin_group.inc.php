<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
exit('Access Denied');
}
global $_G;
loadcache('plugin');
$keke_group = $_G['cache']['plugin']['keke_group'];
include_once DISCUZ_ROOT."source/plugin/keke_group/common.php";
if (submitcheck("forumset")) {
	if(is_array($_GET['delete'])) {
	    C::t('#keke_group#keke_group')->delete($_GET['delete']);
	}
	cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin_group', 'succeed');
}
$classData = C::t('#keke_group#keke_group_class')->fetchall();
if($_GET['ac']){
	if($_GET['formhash'] != $_G['formhash']) {
		exit('Access Denied');
	}
	$buygorupid=intval($_GET['buygorupid']);
	$buygorupdata = getbuygroupdata($buygorupid);
	
	if($_GET['ac']=='edit'){
		if (submitcheck("editsubmit")) {
			$data = array('extid' => 1);
			$pic=$_FILES['gropic'] ? 'data/attachment/common/'.upload_icon_banner($data, $_FILES['gropic'],'') : $_GET['gropic'];
            $topimg=$_FILES['topimg'] ? 'data/attachment/common/'.upload_icon_banner($data, $_FILES['topimg'],'') : $_GET['topimg'];
			if(!$_GET['moneys'] ||  !$_GET['friend'] ){
				cpmsg('Input incomplete!', '', 'error');
			}
			$arr=array(
				'groupid'=> intval($_GET['friend']),
				'groupname'=> daddslashes(dhtmlspecialchars($_GET['text'])),
				'ico'=> daddslashes($pic),
				'tequan'=> editor_safe_replace($_GET['tequan']),
                'waptequan'=> editor_safe_replace($_GET['waptequan']),
				'money'=> floatval($_GET['moneys'])*100,
				'time'=> intval($_GET['times']),
				'givecradit'=> intval($_GET['givecradit']),
				'givecredittype'=> intval($_GET['givecredittype']),
				'display'=> intval($_GET['displays']),
                'tag'=> daddslashes(editor_safe_replace($_GET['tag'])),
                'topimg'=> $topimg,
                'classid'=> intval($_GET['classid']),
			);
			if($buygorupdata['id']){
				C::t('#keke_group#keke_group')->update($buygorupid,$arr);
			}else{
				C::t('#keke_group#keke_group')->insert($arr);
			}
			cpmsg(lang('plugin/keke_group', 'lang18'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin_group&formhash='.FORMHASH, 'succeed');
		}
        $creditnames='';
        $class='<option>'.lang('plugin/keke_group', 'lang88').'</option>';
		foreach($_G['setting']['extcredits'] as $creditid=>$creditname){
			$creditnames.='<option value="'.$creditid.'" '.($buygorupdata['givecredittype']==$creditid?'selected="selected"':'').'>'.$creditname['title'].'</option>';
		}
        foreach($classData as $v){
            $class.='<option value="'.$v['id'].'" '.($buygorupdata['classid']==$v['id']?'selected="selected"':'').'>'.$v['name'].'</option>';
        }
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_group&ac=edit", 'enctype');
		showtableheader(lang('plugin/keke_group', 'lang34'));
		showsetting(lang('plugin/keke_group', 'lang35'),'text',$buygorupdata['groupname'],'text');
		showsetting(lang('plugin/keke_group', 'lang36'), '', $buygorupdata['groupid'], "<select name='friend'>"._getusergroupopt($buygorupdata)."</select>");
		showsetting(lang('plugin/keke_group', 'lang37'),'gropic',$buygorupdata['ico'],'filetext');
		showsetting(lang('plugin/keke_group', 'lang38'),'moneys',($buygorupdata['money']/100),'text','','',lang('plugin/keke_group', 'lang39'));
		showsetting(lang('plugin/keke_group', 'lang40'),'times',$buygorupdata['time'],'text','','',lang('plugin/keke_group', 'lang41'));
		showsetting(lang('plugin/keke_group', 'lang42'),'tequan',$buygorupdata['tequan'],'textarea','','',lang('plugin/keke_group', 'lang43'));
        showsetting(lang('plugin/keke_group', 'lang74'),'waptequan',$buygorupdata['waptequan'],'textarea','','',lang('plugin/keke_group', 'lang75'));
		showsetting(lang('plugin/keke_group', 'lang67'),'givecradit',$buygorupdata['givecradit'],'text','','',lang('plugin/keke_group', 'lang69'));
		showsetting(lang('plugin/keke_group', 'lang68'), '', $buygorupdata['givecredittype'], "<select name='givecredittype'>".$creditnames."</select>");
        showsetting(lang('plugin/keke_group', 'lang72'),'tag',$buygorupdata['tag'],'text','','',lang('plugin/keke_group', 'lang73'));
        showsetting(lang('plugin/keke_group', 'lang76'),'topimg',$buygorupdata['topimg'],'filetext','','',lang('plugin/keke_group', 'lang77'));
        showsetting(lang('plugin/keke_group', 'lang87'), '', $buygorupdata['classid'], "<select name='classid'>".$class."</select>");
		showsetting(lang('plugin/keke_group', 'lang44'),'displays',$buygorupdata['display'],'text','','',lang('plugin/keke_group', 'lang45'));
		echo '<input name="buygorupid" type="hidden" value="'.$buygorupdata['id'].'" />';
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter();
		exit();
	}
	cpmsg(lang('plugin/keke_group', 'lang18'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin_group', 'succeed');
}


showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_group");
showtableheader(lang('plugin/keke_group', 'lang46'));
showsubtitle(array(lang('plugin/keke_group', 'lang47'),lang('plugin/keke_group', 'lang36'),lang('plugin/keke_group', 'lang38'),lang('plugin/keke_group', 'lang40'),lang('plugin/keke_group', 'lang67'),lang('plugin/keke_group', 'lang42'),lang('plugin/keke_group', 'lang87'),lang('plugin/keke_group', 'lang48'),lang('plugin/keke_group', 'lang49')));
$query = _getallgro();
foreach($query as $k=>$v){
	$table = array();
	$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$v['id'].'" />';
	$table[1] = '<b>'.$v['groupname'].'</b>';
	$table[2] = ($v['money']/100).' '.lang('plugin/keke_group', 'lang50');
	$table[3] = $v['time']?$v['time'].' '.lang('plugin/keke_group', 'lang51'):lang('plugin/keke_group', 'lang07');
	$table[4] = $v['givecradit']>0? ($v['givecradit'].' '.$creditname=$_G['setting']['extcredits'][$v['givecredittype']]['title']):'-';
	$table[5] = '<span style="color:#999; max-width: 600px; height: 40px; line-height: 20px; overflow: hidden; display: inline-block">'.strip_tags($v['tequan']).'</span>';
    $table[6] = ($v['classid']?$classData[$v['classid']]['name']:'-');
	$table[7] = $v['display'];
	$table[8] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin_group&ac=edit&buygorupid='.$v['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_group', 'lang52').'</a>';
	showtablerow('',array(), $table);
}
showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin_group&ac=edit&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_group', 'lang53').'</a>');
showtablefooter(); /*dism��taobao��com*/
showformfooter();