<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


include_once DISCUZ_ROOT."source/plugin/keke_group/identity.inc.php";
require_once libfile('function/cache');
$addonid = 'keke_group.plugin';

function arrtoxml($data){
    $xml = "<xml>";
    foreach ($data as $key=>$val){
        if (is_numeric($val)){
            $xml.="<".$key.">".$val."</".$key.">";
        }else{
            $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
        }
    }
    $xml.="</xml>";
    return $xml;
}

function _orderid(){
	global $_G;
	$nowdate=dgmdate($_G['timestamp'], 'YmdHis');
	$random=random(10);
	$orderid=$nowdate.$random;
	return $orderid;
}

function _getallgro(){
	return C::t('#keke_group#keke_group')->fetchall_group();
}

function getbuygroupdata($buygorupid){
	return C::t('#keke_group#keke_group')->fetchfirst_bybuygorupid($buygorupid);
}

function _getusergroupopt($buygorupdata){
	foreach(C::t('common_usergroup')->fetch_all_by_type(array('special'),0) as $keys=>$value) {
		$selected='';
		if($buygorupdata['groupid']==$value['groupid']){
			$selected='selected';
		}
		$usergroups_options .= "<option value=\"$value[groupid]\" $selected>".$value['grouptitle'];
	}
	return $usergroups_options;
}

function _indexdata(){
	$gorupdata = _getallgro();
	foreach($gorupdata as $tk=>$tv){
		if(checkmobile() && $tv['waptequan']){
            $wapPrivilege=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$tv['waptequan']));
            $tq=array();
            foreach ($wapPrivilege as $key=>$privilegeVal) {
                $tq[]=explode('|',$privilegeVal);
            }
            $gorupdata[$tk]['tequan']=$tq;
        }else{
            if($tv['tequan'])$gorupdata[$tk]['tequan']=explode(",",$tv['tequan']);
        }
		$gorupdata[$tk]['money']=$tv['money']/100;
	}
	return $gorupdata;
}

function getTopBg(){
    global $_G;
    $return='';
    if(checkmobile()){
        $gorupdata = _getallgro();
        foreach($gorupdata as $tv){
            if($tv['topimg'] && $_G['groupid']==$tv['groupid']){
                $return = $tv['topimg'];
                break;
            }
        }
    }
    return $return;
}


function _switchgroup($groupid,$uids){
	$groupid = intval($groupid);
	$extgroupids= $extgroupidsarray = array();
	$themembers = C::t('common_member')->fetch($uids);
	$extgroupids = $themembers['extgroupids'] ? explode("\t", $themembers['extgroupids']) : array();
	$ret=array();
	$ret['state']=1;

    $memberfieldforum = C::t('common_member_field_forum')->fetch($uids);
    $groupterms = dunserialize($memberfieldforum['groupterms']);

    $checkExtgroupids=$extgroupids;
    foreach ($groupterms['ext'] as $groId=>$groItem){
        if($groItem > TIMESTAMP)$checkExtgroupids[]=$groId;
    }

	if(!in_array($groupid, $checkExtgroupids)) {
		$ret['msg']=lang('plugin/keke_group', 'lang05');
		$ret['state']=0;
		return $ret;
	}
	if($themembers['groupid'] == 4 && $themembers['groupexpiry'] > 0 && $themembers['groupexpiry'] > TIMESTAMP) {
		$ret['msg']=lang('plugin/keke_group', 'lang06');
		$ret['state']=0;
		return $ret;
	}
	
	$group = C::t('common_usergroup')->fetch($groupid);
	unset($memberfieldforum);
	$extgroupidsnew = $themembers['groupid'];
	$groupexpirynew = $groupterms['ext'][$groupid];
	
	foreach($extgroupids as $extgroupid) {
		if($extgroupid && $extgroupid != $groupid) {
			$extgroupidsnew .= "\t".$extgroupid;
		}
	}
	if($themembers['adminid'] > 0 && $group['radminid'] > 0) {
		$newadminid = $themembers['adminid'] < $group['radminid'] ? $themembers['adminid'] : $group['radminid'];
	} elseif($themembers['adminid'] > 0) {
		$newadminid = $themembers['adminid'];
	} else {
		$newadminid = $group['radminid'];
	}
	C::t('common_member')->update($uids, array('groupid' => $groupid, 'adminid' => $newadminid, 'groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
	return $ret;
}

function _upuserdata($out_trade_no,$sns,$opid=''){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	$orderdata= C::t('#keke_group#keke_group_orderlog')->fetch($out_trade_no);
	if(!$orderdata['state']){
		$ret=_buygroup($orderdata['groupid'],$orderdata['groupvalidity'],$orderdata['uid']);
		$orderarr=array(
			'state'=>'1',
			'zftime'=>$_G['timestamp'],
			'sn'=>$sns,
			'opid'=>$opid,
			'groupinvalid'=>$ret['tims']
		);
		C::t('#keke_group#keke_group_orderlog')->update($out_trade_no, $orderarr);
		$buygorupdata=C::t('#keke_group#keke_group')->fetchfirst_bybuygorupid($orderdata['tablegroupid']);
		if($buygorupdata['givecradit']){
			updatemembercount($orderdata['uid'], array('extcredits'.$buygorupdata['givecredittype']=>$buygorupdata['givecradit']), true, '', 0, '',lang('plugin/keke_group', 'lang70'),lang('plugin/keke_group', 'lang71').$buygorupdata['groupname'].lang('plugin/keke_group', 'lang70'));
		}
        if($_G['cache']['plugin']['keke_market'] && (($keke_group['cdkey'] && $orderdata['type']==3) || $orderdata['type']!=3)){
			require_once DISCUZ_ROOT.'./source/plugin/keke_market/function.php';
			$market_userdata=_getmarketupuid($orderdata['uid']);
			market_cach_log($market_userdata,$orderdata['orderid'],$orderdata['money']/100,'keke_group');
		}
	}
}

function _buygroup($groupid,$days,$uids){
    global $_G;
    $keke_group = $_G['cache']['plugin']['keke_group'];
    $memberfieldforum = C::t('common_member_field_forum')->fetch($uids);
    $groupterms = dunserialize($memberfieldforum['groupterms']);
    unset($memberfieldforum);
    $extgroupids= $extgroupidsarray = array();
    $themembers = C::t('common_member')->fetch($uids);
    $extgroupids = $themembers['extgroupids'] ? explode("\t", $themembers['extgroupids']) : array();
    require_once libfile('function/forum');
    foreach(array_unique(array_merge($extgroupids, array($groupid))) as $extgroupid) {
        if($extgroupid) {
            $extgroupidsarray[] = $extgroupid;
        }
    }
    $extgroupidsnew = implode("\t", $extgroupidsarray);
    if($days) {
        $groupterms['ext'][$groupid] = ($groupterms['ext'][$groupid] > TIMESTAMP ? $groupterms['ext'][$groupid] : TIMESTAMP) + $days * 86400;
        $groupterms['main'] = array('time' => $groupterms['ext'][$groupid]);
        $groupexpirynew = groupexpiry($groupterms);
        C::t('common_member')->update($uids, array('groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
        C::t('common_member_field_forum')->update($uids, array('groupterms' => serialize($groupterms)));
    } else {
        if($groupterms['ext'][$groupid]){
            unset($groupterms['ext'][$groupid]);
            C::t('common_member_field_forum')->update($uids, array('groupterms' => serialize($groupterms)));
        }
        C::t('common_member')->update($uids, array('extgroupids' => $extgroupidsnew));
    }
    if($keke_group['autogroup']){
        $ret['sw']=_switchgroup($groupid,$uids);
    }
    $ret['tims']=$groupterms['ext'][$groupid];
    return $ret;
}

function _getmygrouplist(){
	global $_G;
	$gorupdata = _getallgro();
	foreach($gorupdata as $tk=>$tv){
		$gorupdata[$tv['groupid']]=$tv;
	}
	$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
	$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	$expgrouparray = $expirylist = $termsarray = array();
	if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
		$termsarray = $groupterms['ext'];
	}
	if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
		$termsarray[$_G['groupid']] = $groupterms['main']['time'];
	}
	foreach($termsarray as $expgroupid => $expiry) {
		if($expiry <= TIMESTAMP) {
			$expgrouparray[] = $expgroupid;
		}
	}
	if(!empty($groupterms['ext'])) {
		foreach($groupterms['ext'] as $extgroupid => $time) {
			$expirylist[$extgroupid] = array('time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
		}
	}
	if(!empty($groupterms['main'])) {
		$expirylist[$_G['groupid']] = array('time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
	}
	$groupids = array();
	foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
		if(!empty($usergroup['pubtype'])) {
			$groupids[] = $groupid;
		}
	}
	$expiryids = array_keys($expirylist);
	if(!$expiryids && $_G['member']['groupexpiry']) {
		C::t('common_member')->update($_G['uid'], array('groupexpiry' => 0));
	}
	$groupids = array_merge($extgroupids, $expiryids, $groupids);
	if($groupids) {
		foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
			$isexp = in_array($group['groupid'], $expgrouparray);
			$expirylist[$group['groupid']]['maingroup'] = $group['type'] != 'special' || $group['system'] == 'private' || $group['radminid'] > 0;
			$expirylist[$group['groupid']]['grouptitle'] = $isexp ? '<s>'.$group['grouptitle'].'</s>' : $group['grouptitle'];
			if($gorupdata[$group['groupid']]){
				$expirylist[$group['groupid']]['ico']=$gorupdata[$group['groupid']]['ico'];
			}
			$expirylist[$group['groupid']]['dateline'] = $groupterms['ext'][$group['groupid']];
		}
	}
	return $expirylist;
}


function _getnowgroup(){
	global $_G;
	$allgroup=C::t('common_usergroup')->range();
	$nowgroup['title']=$allgroup[$_G['groupid']]['grouptitle'];
	$time=lang('plugin/keke_group', 'lang07');
	$overdue=0;
	if($_G['member']['groupexpiry']){
		$time=dgmdate($_G['member']['groupexpiry'], 'd');
		if($_G['member']['groupexpiry']<TIMESTAMP){
			$overdue=1;
		}
	}
	$nowgroup['time']=$time;
	$nowgroup['overdue']=$overdue;
	return $nowgroup;
}


function _sensms($text,$phone,$alitmpid){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	if(file_exists(DISCUZ_ROOT.'./source/plugin/keke_sms/sendsms.php')){
		$alisign=dhtmlspecialchars(trim($keke_group['sign']));
		$alitmpid=dhtmlspecialchars(trim($alitmpid));
		@include_once DISCUZ_ROOT.'./source/plugin/keke_sms/sendsms.php';
		$kekesmsapi = new kekesmsapi();
		$return= $kekesmsapi->kekesendsms($phone,$alisign,$text,$alitmpid,$keke_group['smschannel']);
	}
	return $return;
}

function _grosms($credit='',$money='',$type='',$name='',$orderuid=''){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	$times=dgmdate($_G['timestamp'], 'Y-m-d H:i');
	$moneys=$money/100;
	$carditname=$_G['setting']['extcredits'][$type]['title'];
	if($keke_group['smsa']){
		$member_profile=C::t('common_member_profile')->fetch($orderuid);
		$phone=trim($member_profile['mobile']);
		if($phone){
			$text=array('time'=>$times,'credit'=>$credit.$carditname,'money'=>$moneys);
			$ret=_sensms($text,$phone,$keke_group['tmpa']);
		}
	}
	if($keke_group['smsb']){
		$adminphone=dhtmlspecialchars(trim($keke_group['adminphone']));
		if($adminphone){
			$admintext=array('time'=>$times,'credit'=>$credit.$carditname,'money'=>$moneys,'name'=>$name);
			$ret=_sensms($admintext,$adminphone,$keke_group['tmpb']);
		}
	}
	return $ret;
}



function _h5pay($money,$out_trade_no,$title){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	$userip = group_get_client_ip();
	$appid  = trim($keke_group['wxappid']); 
	$mch_id = trim($keke_group['wxmchid']); 
	$key    = trim($keke_group['wxshkey']);
	$nonce_str = createNoncestr();
	$body = $title;
	$total_fee = $money; 
	$spbill_create_ip = $userip;
	$notify_url = $_G['siteurl']."source/plugin/keke_group/paylib/notify_wx.inc.php"; 
	$trade_type = 'MWEB';
	$scene_info ='{"h5_info":{"type":"Wap","wap_url":"'.$_G['siteurl'].'plugin.php?id=keke_group","wap_name":"$title"}}';
	$signA ="appid=$appid&attach=$out_trade_no&body=$body&mch_id=$mch_id&nonce_str=$nonce_str&notify_url=$notify_url&out_trade_no=$out_trade_no&scene_info=$scene_info&spbill_create_ip=$spbill_create_ip&total_fee=$total_fee&trade_type=$trade_type";
	$strSignTmp = $signA."&key=$key";
	$sign = strtoupper(MD5($strSignTmp));
	$post_data = "<xml>
					   <appid>$appid</appid>
					   <mch_id>$mch_id</mch_id>
					   <body>$body</body>
					   <out_trade_no>$out_trade_no</out_trade_no>
					   <total_fee>$total_fee</total_fee>
					   <spbill_create_ip>$spbill_create_ip</spbill_create_ip>
					   <notify_url>$notify_url</notify_url>
					   <trade_type>$trade_type</trade_type>
					   <scene_info>$scene_info</scene_info>
					   <attach>$out_trade_no</attach>
					   <nonce_str>$nonce_str</nonce_str>
					   <sign>$sign</sign>
				   </xml>";
	
	$url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
	$dataxml = postXmlCurl($post_data,$url); 
	$objectxml = (array)simplexml_load_string($dataxml, 'SimpleXMLElement', LIBXML_NOCDATA);
	$objectxml['mweb_url']=$objectxml['mweb_url']._redurl($out_trade_no);
	return $objectxml;
}

function createNoncestr( $length = 32 ){
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str ="";
    for ( $i = 0; $i < $length; $i++ )  {
        $str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);
    }
    return $str;
}
function postXmlCurl($xml,$url,$second = 30){
	if(function_exists('curl_init') && function_exists('curl_exec')){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		curl_setopt($ch,CURLOPT_URL, $url);
		curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		curl_setopt($ch, CURLOPT_POST, TRUE);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		$data = curl_exec($ch);
		if($data){
			curl_close($ch);
			return $data;
		}else{
			$error = curl_errno($ch);
			curl_close($ch);
			return "curl_err:$error"."<br>";
		}
	}
	$matches = parse_url($url);
	$scheme = $matches['scheme'];
	$host = $matches['host'];
	$path = $matches['path'] ? $matches['path'].($matches['query'] ? '?'.$matches['query'] : '') : '/';
	$contentLength=strlen($xml);
	$port = !empty($matches['port']) ? $matches['port'] : ($scheme == 'http' ? '80' : '');
	$fp = fsockopen($host, $port);
	fputs($fp, "POST $path HTTP/1.0\r\n");
	fputs($fp, "Host: $host:$port\r\n");
	fputs($fp, "Content-Type: text/xml\r\n");
	fputs($fp, "Content-Length: $contentLength\r\n");
	fputs($fp, "Connection: close\r\n");
	fputs($fp, "\r\n"); // all headers sent
	fputs($fp, $xml);
	$result = '';
	while (!feof($fp)) {
		$result .= fgets($fp, 128);
	}
	return $result;
}
function group_get_client_ip($type = 0) {
	if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
        $ip = getenv('HTTP_CLIENT_IP');
    } elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    } elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
        $ip = getenv('REMOTE_ADDR');
    } elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '';
}

function _redurl($orderid){
	global $_G;
	$redirect_url=urlencode($_G['siteurl'].'plugin.php?id=keke_group&p=loading&orderid='.$orderid);
	$redirect_urls='&redirect_url='.$redirect_url;
	return $redirect_urls;
}

function editor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}

function _getqrcodeurl($urls){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	$src = $keke_group['qr']==2?'source/plugin/keke_group/paylib/wechat/example/qrcode.php?data='.urlencode($urls):$urls;
	return $src;
}

function _getmycount(){
	global $_G;
	return C::t('#keke_group#keke_group_orderlog')->count_by_all($_G['uid'],1);
}

function _getmylist($startlimit,$ppp){
	global $_G;
	$query = C::t('#keke_group#keke_group_orderlog')->fetch_all_by_all($_G['uid'],1,$startlimit,$ppp);
	foreach($query as $val){
		$validitys=$time='';
		$money=$val['money']/100;
		$time=dgmdate($val['zftime'], 'Y/m/d H:i');
		$validitys=$val['groupinvalid']?dgmdate($val['groupinvalid'], 'Y-m-d H:i'):lang('plugin/keke_group', 'lang07');
		$icoid=$val['type']==1?'z':'w';
		$dates='';
		$groupvalidity=$val['groupvalidity']?$val['groupvalidity'].lang('plugin/keke_group', 'lang09'):lang('plugin/keke_group', 'lang07');
		$pcdate='<b class="sx">|</b><b class="pcdate">'.lang('plugin/keke_group', 'lang08').' :  <i class="yxz">'.$validitys.'</i></b>';
		$validi='<b style="color:#999; font-size:14px;font-weight:500"> / '.$groupvalidity.' </b>';
		if(checkmobile()){
			$dates='<div class="dow dows"><span>'.$groupvalidity.'&nbsp;&nbsp;</span>  '.lang('plugin/keke_group', 'lang08').' / <i class="yxz">'.$validitys.'</i></div>';
			$pcdate=$validi='';
		}
		$list.='<li><div class="pup"><span><img src="source/plugin/keke_group/template/images/'.$icoid.'.png"> '.$money.lang('plugin/keke_group', 'lang03').'</span> '.$val['groupname'].' '.$validi.'</div><div class="dow"><span>'.$time.'</span>'.$val['sn'].$pcdate.'</div>'.$dates.'</li>';
	}
	return $list;
}
function _getmyorder($pages){
		$ppp=30;
		$tmpurl='plugin.php?id=keke_group&p=my';
		$page = max(1, intval($pages));
		$startlimit = ($page - 1) * $ppp;
		$allcount = _getmycount();
		if($allcount){
			$list=_getmylist($startlimit,$ppp);
		}
		$multipage='';
		$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
		$ret['page']=$multipage;
		$ret['list']=$list;
		return $ret;
}
function _instorder($orderid,$money,$zftype,$buygroupid,$groupname,$groupvalidity,$tablegroupid){
	global $_G;
	$orderarr=array(
		'orderid'=>$orderid,
		'uid'=>$_G['uid'],
		'usname'=>$_G['username'],
		'money'=>$money,
		'type'=>$zftype,
		'time'=>$_G['timestamp'],
		'groupid'=>$buygroupid,
		'groupname'=>$groupname,
		'groupvalidity'=>$groupvalidity,
		'tablegroupid'=>$tablegroupid,
	);
	C::t('#keke_group#keke_group_orderlog')->insert($orderarr, true);
}

function groutf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return grogbk2utf($data);
	}
}

function grogbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}

function groupMagPay($tradeno,$money,$title){
    global $_G;
    $keke_group = $_G['cache']['plugin']['keke_group'];
    if($money>0){
        $magCallbackSign=md5($keke_group['magsecret'].$tradeno.$_G['config']['security']['authkey']);
        $callbackUrl=$_G['siteurl'].'source/plugin/keke_group/paylib/notify_mag.inc.php?out_trade_no='.$tradeno.'&sign='.$magCallbackSign;
        $url='http://'.$keke_group['magurl'].'/core/pay/pay/unifiedOrder?trade_no='.$tradeno.'&callback='.urlencode($callbackUrl).'&amount='.$money.'&title='.$title.'&user_id='.$_G['uid'].'&to_user_id=&des='.$title.'&remark='.$title.'&secret='.$keke_group['magsecret'];
        $data = dfsockopen($url);
        if(!$data) {
            $data = file_get_contents($url);
        }
        $return=json_decode($data,true);
        if($return['success'] == true){
            $return['data']['trade_no'] = $tradeno;
            $return['data']['title'] = $title;
            $return['data']['money'] = $money;
        }
    }else{
        $return['data']['trade_no'] = $tradeno;
        $return['data']['money'] = $money;
    }
    return $return;
}

function groupMagUserInfo(){
    global $_G;
    $keke_group = $_G['cache']['plugin']['keke_group'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $info = strstr($userAgent, "MAGAPPX");
    $info=explode("|",$info);
    $url='http://'.$keke_group['magurl'].'/mag/cloud/cloud/getUserInfo?token='.$info[7].'&secret='.$keke_group['magsecret'];
    $data = dfsockopen($url);
    if(!$data) {
        $data = file_get_contents($url);
    }
    $data=json_decode($data,true);
    return $data['data'];
}