<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_group_orderlog'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('tablegroupid', $col_field)){
	$sql = "Alter table ".DB::table('keke_group_orderlog')." add `tablegroupid` int(20) NOT NULL;"; 
	DB::query($sql); 
}

$querys = DB::query("SHOW COLUMNS FROM ".DB::table('keke_group'));
while($rows = DB::fetch($querys)) {
	$col_fields[]=$rows['Field']; 
}

if(!in_array('givecradit', $col_fields)){
	$sql = "Alter table ".DB::table('keke_group')." add `givecradit` int(10) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('givecredittype', $col_fields)){
	$sql = "Alter table ".DB::table('keke_group')." add `givecredittype` int(10) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('tag', $col_fields)){
    $sql = "Alter table ".DB::table('keke_group')." add `tag` varchar(20) NOT NULL;";
    DB::query($sql);
}

if(!in_array('waptequan', $col_fields)){
    $sql = "Alter table ".DB::table('keke_group')." add `waptequan` varchar(500) NOT NULL;";
    DB::query($sql);
}

if(!in_array('topimg', $col_fields)){
    $sql = "Alter table ".DB::table('keke_group')." add `topimg` varchar(255) NOT NULL;";
    DB::query($sql);
}


if(!in_array('classid', $col_fields)){
    $sql = "Alter table ".DB::table('keke_group')." add `classid` int(2) NOT NULL;";
    DB::query($sql);
}



$keke_group_class= DB::table("keke_group_class");
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `$keke_group_class` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `hide` int(1) NOT NULL,
  `displayorder` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;
runquery($sql);


$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/keke_group/discuz_plugin_keke_group.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_group/discuz_plugin_keke_group_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_group/discuz_plugin_keke_group_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_group/discuz_plugin_keke_group_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_group/discuz_plugin_keke_group_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_group/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_group/upgrade.php');