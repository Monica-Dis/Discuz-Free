<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;
loadcache('plugin');
$keke_group = $_G['cache']['plugin']['keke_group'];
include_once DISCUZ_ROOT."source/plugin/keke_group/common.php";

if (submitcheck("forumset")) {
    if(is_array($_GET['delete'])) {
        C::t('#keke_group#keke_group_class')->delete($_GET['delete']);
    }
    cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_class&pmod=admin_class', 'succeed');
}
if($_GET['ac']){
    if($_GET['formhash'] != $_G['formhash']) {
        exit('Access Denied');
    }
    $classId=intval($_GET['classid']);
    $classData = C::t('#keke_group#keke_group_class')->fetchfirst_bycid($classId);
    if($_GET['ac']=='edit'){
        if (submitcheck("editsubmit")) {
            $data = array('extid' => 1);
            if(!$_GET['name'] ){
                cpmsg(lang('plugin/keke_group', 'lang85'), '', 'error');
            }
            $arr=array(
                'name'=> daddslashes($_GET['name']),
                'hide'=> intval($_GET['hide']),
                'displayorder'=> intval($_GET['displayorder'])
            );
            if($classData['id']){
                C::t('#keke_group#keke_group_class')->update($classId,$arr);
            }else{
                C::t('#keke_group#keke_group_class')->insert($arr);
            }
            cpmsg(lang('plugin/keke_group', 'lang18'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin_class&formhash='.FORMHASH, 'succeed');
        }

        showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_class&ac=edit", 'enctype');
        showtableheader(lang('plugin/keke_group', 'lang34'));
        showsetting(lang('plugin/keke_group', 'lang80'),'name',$classData['name'],'text');
        showsetting(lang('plugin/keke_group', 'lang83'), 'hide', $classData['hide'],'radio','','',lang('plugin/keke_group', 'lang84'));
        showsetting(lang('plugin/keke_group', 'lang48'),'displayorder',$classData['displayorder'],'text','','',lang('plugin/keke_group', 'lang45'));
        echo '<input name="classid" type="hidden" value="'.$classData['id'].'" />';
        showsubmit('editsubmit', 'submit', '');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
        exit();
    }
    cpmsg(lang('plugin/keke_group', 'lang18'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin_class', 'succeed');
}

showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_class");
showtips(lang('plugin/keke_group', 'lang78'));
showtableheader(lang('plugin/keke_group', 'lang79'));
showsubtitle(array(lang('plugin/keke_group', 'lang47'),lang('plugin/keke_group', 'lang80'),lang('plugin/keke_group', 'lang83'),lang('plugin/keke_group', 'lang81'),lang('plugin/keke_group', 'lang48'),lang('plugin/keke_group', 'lang49')));
$query = C::t('#keke_group#keke_group_class')->fetchall();
foreach($query as $k=>$v){
    $table = array();
    $table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$v['id'].'" />';
    $table[1] = '<b>'.$v['name'].'</b>';
    $table[2] = ($v['hide']?lang('plugin/keke_group', 'lang86'):'-');
    $table[3] = '<span style="color:#999">'.($v['hide']?$_G['siteurl'].'plugin.php?id=keke_group&class='.$v['id']:'-').'</span>';
    $table[4] = $v['displayorder'];
    $table[7] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin_class&ac=edit&classid='.$v['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_group', 'lang52').'</a>';
    showtablerow('',array(), $table);
}
showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin_class&ac=edit&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_group', 'lang82').'</a>');
showtablefooter(); /*dism��taobao��com*/
showformfooter();