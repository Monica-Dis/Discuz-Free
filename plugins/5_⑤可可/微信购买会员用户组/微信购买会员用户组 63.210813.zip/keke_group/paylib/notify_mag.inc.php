<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);
require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

global $_G;
$keke_group = $_G['cache']['plugin']['keke_group'];
loadcache('plugin');
require_once("alipay/alipay.config.php");
require_once("alipay/alipay_notify.class.php");
require_once DISCUZ_ROOT."source/plugin/keke_group/common.php";

$MD5sign = md5($keke_group['magsecret'].$_GET['out_trade_no'].$_G['config']['security']['authkey']);
if($_GET['sign'] == $MD5sign){
    _upuserdata($_GET['out_trade_no'],$_GET['out_trade_no']);
}