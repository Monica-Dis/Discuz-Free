<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_keke_veeker {
	function global_header(){
		global $_G ,$list,$tids,$posts;
		$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
		if($_G['mod']=='space' && $_GET['do']=='thread' && $_GET['view']=='me' && $_GET['from']=='space' && $_GET['type']='reply' && file_exists("source/plugin/keke_veeker/assembly/workhide.inc.php")){
			$tidss=array();
			foreach($tids as $tkey=>$tval){
				$tidss[]=$tkey;
			}
			$vkdata=C::t('#keke_veeker#keke_veeker')->fetch_by_tids($tidss);			
			foreach($vkdata as $vkvals){
				if($vkvals['workhide']){
					$hidetid[$vkvals['tid']]=$vkvals['tid'];
				}
			}
			foreach($tids as $tkeys=>$tvals){
				if($hidetid[$tkeys]){
					foreach($tids[$tkeys] as $pid){
						$pids[$pid]=$pid;
					}
				}
			}
			foreach($posts as $postskeys=>$postsvals){
				if($pids[$postskeys] && $postsvals['authorid']!=$_G['uid'] && $list[$postsvals['tid']]['authorid']!=$_G['uid'] && $_G['groupid']!=1){
					$posts[$postskeys]['message']=lang('plugin/keke_veeker', 'kkvklang189');
				}
			}
		}
		return '';
	}
	
}
class plugin_keke_veeker_forum extends plugin_keke_veeker{
	function post_top(){
		global $_G ;
		$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
		$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
		$creditnamea=$_G['setting']['extcredits'][$keke_veeker['pa']]['title'];
		$creditnameb=$_G['setting']['extcredits'][$keke_veeker['pb']]['title'];
		$wkch=dhtmlspecialchars($keke_veeker['wkch']);
		$gzch=dhtmlspecialchars($keke_veeker['gzch']);
		$actions=$_GET['action'];
		$section = empty($keke_veeker['bk']) ? array() : unserialize($keke_veeker['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){return '';}
		include_once DISCUZ_ROOT . './source/plugin/keke_veeker/function/fun.php';
		if(submitcheck('topicsubmit') && $_GET['tlx']){
			$membercount = C::t('common_member_count')->fetch($_G['uid']);					
			$extcredits=$membercount['extcredits'.$keke_veeker['jf']];
			$extcreditsa=$membercount['extcredits'.$keke_veeker['pa']];
			$extcreditsb=$membercount['extcredits'.$keke_veeker['pb']];
			if($extcredits<$keke_veeker['jfxx']){
				showmessage(lang('plugin/keke_veeker', 'kkvklang01').$keke_veeker['jfxx'].$creditname.lang('plugin/keke_veeker', 'kkvklang02').$extcredits.$creditname.lang('plugin/keke_veeker', 'kkvklang03'),'');
			}
			$gocount=C::t('#keke_veeker#keke_veeker')->fetch_by_state('1,2',$_G['uid']);
			if($gocount>=$keke_veeker['qsjsxz']){
				showmessage(lang('plugin/keke_veeker', 'kkvklang04').$gocount.lang('plugin/keke_veeker', 'kkvklang05'),'');
			}
			if(isset($_GET['keke_vk_mode']) && $_GET['keke_vk_mode']>0){
				$uid=$_G['uid'];
				$keke_vk_mode=intval($_GET['keke_vk_mode']);
				$total=intval($_GET['keke_vk_total']);
				$price=intval($_GET['keke_vk_price']);
				$keke_vk_everycount=intval($_GET['keke_vk_everycount']);
				$keke_vk_zd=daddslashes($_GET['keke_vk_zd']);
				$keke_vk_date=dhtmlspecialchars($_GET['keke_vk_date']);
				$keke_vk_date=strtotime($keke_vk_date);
				$pa=intval($_GET['pa']);
				$pb=intval($_GET['pb']);
				
				$result='';
				if($keke_vk_date=='')$result=lang('plugin/keke_veeker', 'kkvklang80');
				if($keke_vk_date<$_G['timestamp'])$result=lang('plugin/keke_veeker', 'kkvklang152');
				if($keke_vk_mode==1){
					if($price=="")$result=lang('plugin/keke_veeker', 'kkvklang81').$creditname.lang('plugin/keke_veeker', 'kkvklang82');
					if(!$total)$result=lang('plugin/keke_veeker', 'kkvklang83');
					if($total<0 || $price<0)$result=lang('plugin/keke_veeker', 'kkvklang84');
					if($price<$keke_veeker['zddj'])$result=lang('plugin/keke_veeker', 'kkvklang85').$keke_veeker['zddj'].$creditname;
					if($pa>0 && ($pa<$keke_veeker['pazd']))$result=lang('plugin/keke_veeker', 'kkvklang85').$keke_veeker['pazd'].$creditnamea;
					if($pb>0 && ($pb<$keke_veeker['pbzd']))$result=lang('plugin/keke_veeker', 'kkvklang85').$keke_veeker['pbzd'].$creditnameb;
					$all=_getfballcredit($total*$price);
					$alla=_getfballcredit($total*$pa);
					$allb=_getfballcredit($total*$pb);
					if($allb>$extcreditsb){$result=lang('plugin/keke_veeker', 'kkvklang106').$extcreditsb.$creditnameb.lang('plugin/keke_veeker', 'kkvklang107');}
					if($alla>$extcreditsa){$result=lang('plugin/keke_veeker', 'kkvklang106').$extcreditsa.$creditnamea.lang('plugin/keke_veeker', 'kkvklang107');}
					if($all>$extcredits){$result=lang('plugin/keke_veeker', 'kkvklang106').$extcredits.$creditname.lang('plugin/keke_veeker', 'kkvklang107');}
					
				}elseif($keke_vk_mode==2){
					if($total<=0){$result=lang('plugin/keke_veeker', 'kkvklang173');}
				}elseif($keke_vk_mode==3){
					if($price=="")$result=lang('plugin/keke_veeker', 'kkvklang87').$creditname.lang('plugin/keke_veeker', 'kkvklang88');
					if($keke_vk_zd=="")$result=lang('plugin/keke_veeker', 'kkvklang89').$wkch."UID";
					$zd =explode('+', $keke_vk_zd);
					foreach($zd as $val){
						$memberdata=C::t('common_member')->fetch($val);
						if(!$memberdata)$result=lang('plugin/keke_veeker', 'kkvklang159');
					}
					$all=_getfballcredit(count($zd)*$price);
					if($all>$extcredits){$result=lang('plugin/keke_veeker', 'kkvklang90');}
				}
				if($result){showmessage($result,'');}
				if(!$keke_vk_mode==2){
					$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch($_G['groupid']);
					$dj=$total*$price;
					$sxf=($dj*$tcfa['fb'])/100;
					if($extcredits<($dj+$sxf)){showmessage(lang('plugin/keke_veeker', 'kkvklang90'),'');}
				}
			}
		}
		if($actions=="reply"){
            $counts=_getvkdatabytid($_G['tid']);
            if(!$counts){
                return '';
            }
			if(!$_G['uid']) {
				showmessage('not_loggedin', NULL, array(), array('login' => 1));
			}
			if(!(in_array($_G['groupid'],unserialize($keke_veeker['cyyhz'])))){
				showmessage(lang('plugin/keke_veeker', 'kkvklang175'), '', array(), array('alert' => 'info'));
			}			
			$vk_cndata=_getcndata($_G['tid']);
			$cnfs=$vk_cndata[0]['sta'] ? $vk_cndata[0]['sta'] : 0;
			$jjfs=$vk_cndata[0]['stb'] ? $vk_cndata[0]['stb'] : 0;
			$tjcs=C::t('forum_post')->count_by_tid_authorid($_G['tid'],$_G['uid']);
			$keke_veeker_data=C::t('#keke_veeker#keke_veeker')->fetch_by_tid($_G['tid']);
			$keke_veeker_data=$keke_veeker_data[0];
			
			if($_G['uid']==$keke_veeker_data['uid']){
				showmessage(lang('plugin/keke_veeker', 'kkvklang188'), '', array(), array('alert' => 'info'));
			}
			
			if($keke_veeker_data['model']==3 && !(in_array($_G['uid'],unserialize($keke_veeker_data['zduid'])))){
				showmessage(lang('plugin/keke_veeker', 'kkvklang11'), '', array(), array('alert' => 'info'));
			}
			if($keke_veeker_data['state']==4){showmessage(lang('plugin/keke_veeker', 'kkvklang12'), '', array(), array('alert' => 'info'));}
			if($keke_veeker_data['deadline']<$_G['timestamp']){showmessage(lang('plugin/keke_veeker', 'kkvklang13'), '', array(), array('alert' => 'info'));}
			if($cnfs>=$keke_veeker_data['total']){showmessage(lang('plugin/keke_veeker', 'kkvklang14'), '', array(), array('alert' => 'info'));}
			//20160513
			if(($keke_veeker_data['model']==1) && $keke_veeker['zlms']){
			$tjfs=$keke_veeker_data['replies'];
			$vk_cndata[0]['coun'] ? $vk_cndata[0]['coun'] : 0;
			if(($tjfs-$jjfs)>=$keke_veeker_data['total']){showmessage(lang('plugin/keke_veeker', 'kkvklang14'), '', array(), array('alert' => 'info'));}					
			}
			$jjfs=DB::result_first("select count(1) from ".DB::table('keke_veeker_cn')." where uid=".$_G['uid']." AND tid=".$_G['tid']." AND state=2");//20180415
			$tjcsa=$tjcs-$jjfs;
			if(($keke_veeker_data['everycount']-$tjcsa)<=0 && !($keke_veeker_data['everycount']==0)){showmessage(lang('plugin/keke_veeker', 'kkvklang15').$keke_veeker_data['everycount'].lang('plugin/keke_veeker', 'kkvklang16'), '', array(), array('alert' => 'info'));}
			if($keke_veeker_data['state']==2){showmessage($gzch.lang('plugin/keke_veeker', 'kkvklang17'), '', array(), array('alert' => 'info'));}
		}
		if($actions=="edit"&&$_G['uid']==$_G['thread']['authorid']&&$keke_veeker['bianji']){
			showmessage(lang('plugin/keke_veeker', 'kkvklang18'), '', array(), array('alert' => 'info'));
		}


		if($actions=="newthread"&&$_G['uid']>0){
			if(!(in_array($_G['groupid'],unserialize($keke_veeker['fbyhz'])))){
				showmessage(lang('plugin/keke_veeker', 'kkvklang174'), '', array(), array('alert' => 'info'));
			}
			
			$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
			$creditnamea=$_G['setting']['extcredits'][$keke_veeker['pa']]['title'];
			$creditnameb=$_G['setting']['extcredits'][$keke_veeker['pb']]['title'];
			
			$wkch=dhtmlspecialchars($keke_veeker['wkch']);
			$gzch=dhtmlspecialchars($keke_veeker['gzch']);
			$membercount = C::t('common_member_count')->fetch($_G['uid']);					
			$extcredits=$membercount['extcredits'.$keke_veeker['jf']];
			$extcreditsa=$membercount['extcredits'.$keke_veeker['pa']];
			$extcreditsb=$membercount['extcredits'.$keke_veeker['pb']];
			
			$fid=intval($_GET['fid']);
			$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch($_G['groupid']);
			$sxf=$tcfa['fb'];
			$yusuan=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_veeker['yusuan']));
			foreach($yusuan as $k=>$item){
				$selects.='<option value="'.$k.'">'.$item.'</option>';
			}
			$vkmod=unserialize($keke_veeker['mod']);
			include template('keke_veeker:input');
			if(checkmobile()){
				return $input;
			}else{
                if(!$_G['setting']['rewritestatus']){
                    $_G['setting']['rewritestatus']=true;
                }
				$_G['setting']['output']['str']['search']['keke_veeker'] = lang('plugin/keke_veeker', 'kkvklang179').'</span>';
				$_G['setting']['output']['str']['replace']['keke_veeker'] = lang('plugin/keke_veeker', 'kkvklang179').'</span>'.$lx.'</div></div>'.$return;
			}
		}
        return '';
	}
	function post_editorctrl_left() {
		global $_G;	
		$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
		$section = empty($keke_veeker['bk']) ? array() : unserialize($keke_veeker['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){return '';}
		if(file_exists("source/plugin/keke_veeker/assembly/bidhide.inc.php") && !checkmobile()){
			include template('keke_veeker:hide');
			return  $return;
		}
	}
	function post_infloat_top(){
			global $_G;	
			$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
			$section = empty($keke_veeker['bk']) ? array() : unserialize($keke_veeker['bk']);
			if(!is_array($section)) $section = array();
			if(!(empty($section[0]) || in_array($_G['fid'],$section))){return '';}
	}
	function viewthread_posttop_output(){
		global $_G, $postlist;
		$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
		$wkch=dhtmlspecialchars($keke_veeker['wkch']);
		$gzch=dhtmlspecialchars($keke_veeker['gzch']);
		$ret=array();
		$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
		$creditnamea=$_G['setting']['extcredits'][$keke_veeker['pa']]['title'];
		$creditnameb=$_G['setting']['extcredits'][$keke_veeker['pb']]['title'];
		$section = empty($keke_veeker['bk']) ? array() : unserialize($keke_veeker['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){
			return $ret;
		}
		include_once DISCUZ_ROOT . './source/plugin/keke_veeker/function/fun.php';
		$counts=_getvkdatabytid($_G['tid']);
		if(!$counts){
			return $ret;
		}
		$vk_cndata=_getcndata($_G['tid']);		
		$cnfs=$vk_cndata[0]['sta'] ? $vk_cndata[0]['sta'] : 0;
		$jjfs=$vk_cndata[0]['stb'] ? $vk_cndata[0]['stb'] : 0;
		$zbfs=$vk_cndata[0]['coun'] ? $vk_cndata[0]['coun'] : 0;
		
		$hfcs=$counts['replies'];
		$deadline=date("Y-m-d H:i:s",$counts['deadline']);
		$memberprp = C::t('common_member_profile')->fetch($_G['thread']['authorid']);
		if($memberprp['qq'] && $keke_veeker['lxfs']==1){
			$lxfs=1;
		}else{
			$lxfs=0;
		}
		if($counts['model']==1){
			$yj=$counts['total']*$counts['price'];
			$yja=$counts['pa']?$counts['total']*$counts['pa']:'';
			$yjb=$counts['pb']?$counts['total']*$counts['pb']:'';
			$xyfs=$counts['total'];
			if($keke_veeker['zlms']){ 
				$syfs=$counts['total']-$hfcs+$jjfs;//20160513
			}else{
				$syfs=$counts['total']-$cnfs;
			}
		}elseif($counts['model']==2){
			$yj=$vk_cndata[0]['je'];
			$yj=$yj ? $yj : 0;
			$xyfs=$counts['total'];
			$syfs=$counts['total']-$zbfs;
			$vie=0;$zj='';
			$yusuan=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_veeker['yusuan']));
			$counts['price']=$yusuan[$counts['price']];
			$cncount=C::t('#keke_veeker#keke_veeker_cn')->count_by_uid($_G['uid']);
			if($cncount || $_G['uid']==$_G['thread']['authorid']){
				$vie=1;
			}
			$zblists=_getzblists($_G['tid']);
		}elseif($counts['model']==3){
			$xyfs=count(unserialize($counts['zduid']));
			$yj=$xyfs*$counts['price'];
			$yja=$counts['pa']?$xyfs*$counts['pa']:'';
			$yjb=$counts['pb']?$xyfs*$counts['pb']:'';
			$zduid=unserialize($counts['zduid']);
			foreach($zduid as $k=>$v){$zdusname.="<a href='home.php?mod=space&uid=".$v."' class='zdusn'>"._getusernames($v)."</a> / ";}
			if ($zdusname) $zdusname = substr($zdusname, 0, -2);
			$syfs=$xyfs-$cnfs;
		}
		$firstpost = C::t('forum_post')->fetch_visiblepost_by_tid('tid:'.$_G['tid'], $_G['tid'], 1);
		$time[1]=date('y.m.d',$_G['thread']['dateline']);
		$t2=$firstpost['dateline'];
		$time[2]=date('y.m.d',$t2);
		$t3=C::t('#keke_veeker#keke_veeker_cn')->fetch_by_dateline($_G['tid']);
		$time[3]=date('y.m.d',$t3);
		$t4=$counts['donetime'];
		$time[4]=date('y.m.d',$t4);
		if(file_exists("source/plugin/keke_veeker/assembly/workhide.inc.php")){
			include_once DISCUZ_ROOT . './source/plugin/keke_veeker/assembly/workhide.inc.php';
			$workhide=1;
		}
		if(file_exists("source/plugin/keke_veeker/assembly/bidhide.inc.php")){
			include_once DISCUZ_ROOT . './source/plugin/keke_veeker/assembly/bidhide.inc.php';
			$bidhide=1;
		}
		
		$sxfs=C::t('#keke_veeker#keke_veeker_tc')->fetch($_G['groupid']);
		$sxf=$sxfs['cj'];
		$zjlist =_getzjlist($_G['tid']);
		include template('keke_veeker:show');
		$num=0;
		foreach($postlist as $key=>$val){	
			if($postlist[$key]['first'] && $bidhide){
				$msg=$postlist[$key]['message'];
				$message=$bidhide?prase($msg,$_G['tid'],$_G['thread']['authorid'],$_G['uid']):$msg;
				$postlist[$key]['message']=$message;
			}
			if(!$postlist[$key]['first'] && $workhide && !($_G['uid']==$_G['thread']['authorid'] || $_G['uid']==$val['uid']) && $counts['workhide'] && !($_G['groupid']==$keke_veeker['sup'])){
				$postlist[$key]['message']=$hidediv;
				$postlist[$key]['attachlist']='';
				$postlist[$key]['imagelist']='';
			}
			$on='';	
			$state=_getstates($val['pid']);
			if($state==1){
				$statetxt=lang('plugin/keke_veeker', 'kkvklang38');
				$on=1;
				$aaa=lang('plugin/keke_veeker', 'kkvklang39');
			}elseif($state==2){
				$statetxt=lang('plugin/keke_veeker', 'kkvklang40');
				$on=2;
			}else{
				$statetxt=lang('plugin/keke_veeker', 'kkvklang41');
			}
			$page=intval($_GET['page']);
			$btns='<span class="shtipsss"></span>';
			if($_G['thread']['authorid']==$_G['uid'] || $_G['groupid']==$keke_veeker['sup']){
				if($counts['pa'])$pa='+'.$counts['pa'].$creditnamea;
				if($counts['pb'])$pb='+'.$counts['pb'].$creditnameb;
				if($state!=2 && $state!=1){
					$btns=checkmobile()?'
					<a href="javascript:;" onclick= "if(confirm( \''.lang('plugin/keke_veeker', 'kkvklang42').''.$counts['price'].$creditname.$pa.$pb.''.lang('plugin/keke_veeker', 'kkvklang43').'\')==false){return false; }fundo('.$val['tid'].','.$val['pid'].',\'cn\');" class="zjda">'.lang('plugin/keke_veeker', 'kkvklang74').'</a>
					<a href="javascript:;" onclick="fundo('.$val['tid'].','.$val['pid'].',\'jj\');" id="keke_answer" class="zjda bcn">'.lang('plugin/keke_veeker', 'kkvklang75').'</a>':'<a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang42').''.$counts['price'].$creditname.$pa.$pb.lang('plugin/keke_veeker', 'kkvklang43').'&#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039fundo('.$val['tid'].','.$val['pid'].',\&#039cn\&#039);&#039,1)" class="zjda">'.lang('plugin/keke_veeker', 'kkvklang44').'</a>
					<a href="javascript:;" onclick="fundo('.$val['tid'].','.$val['pid'].',\'jj\');" id="keke_answer" class="zjda bcn">'.lang('plugin/keke_veeker', 'kkvklang45').'</a>';
				}else{
					$btns='';
				}
				if(!$state && !($counts['state']==4) && !($_G['thread']['authorid']==$val['uid'])){
					$btnxb=checkmobile()?'<a class="zjda" href="plugin.php?id=keke_veeker:w&tid='.$_G['tid'].'&pid='.$val['pid'].'&buid='.$val['uid'].'&auid='.$_G['thread']['authorid'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'&ac=8">'.lang('plugin/keke_veeker', 'kkvklang26').'</a>':'<a class="zjda" href="javascript:" onclick="showWindow(\'keke_veeker\', \'plugin.php?id=keke_veeker:tis&tid='.$_G['tid'].'&pid='.$val['pid'].'&buid='.$val['uid'].'&auid='.$_G['thread']['authorid'].'&page='.$page.'&formhash='.FORMHASH.'&ac=8\');">'.lang('plugin/keke_veeker', 'kkvklang26').'</a>';
				}elseif($state==9){
					$btnxb=checkmobile()?'<a href="javascript:;" onclick= "if(confirm( \''.lang('plugin/keke_veeker', 'kkvklang24').$creditname.lang('plugin/keke_veeker', 'kkvklang25').'\')==false){return false;}fundo('.$val['tid'].','.$val['pid'].',\'hg\'); " class="zjda">'.lang('plugin/keke_veeker', 'kkvklang76').'</a> 
				<a href="javascript:;" onclick= "if(confirm( \''.lang('plugin/keke_veeker', 'kkvklang27').'\')==false){return false; }fundo('.$val['tid'].','.$val['pid'].',\'bhg\');"  class="zjda bcn">'.lang('plugin/keke_veeker', 'kkvklang77').'</a> ':'<a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang24').$creditname.lang('plugin/keke_veeker', 'kkvklang25').'&#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039fundo('.$val['tid'].','.$val['pid'].',\&#039hg\&#039);&#039,1)" class="zjda">'.lang('plugin/keke_veeker', 'kkvklang46').'</a> 
				<a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang27').'&#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039fundo('.$val['tid'].','.$val['pid'].',\&#039bhg\&#039);&#039,1)" class="zjda bcn">'.lang('plugin/keke_veeker', 'kkvklang47').'</a> ';
					$aaa=$wkch.lang('plugin/keke_veeker', 'kkvklang48');
				}else{
					$btnxb='';
				}
					$memberprofile = C::t('common_member_profile')->fetch($val['uid']);
					if($memberprofile['qq'] && $keke_veeker['lxfs']==1){
						$btna='<a class="zjda msg"  href="http://wpa.qq.com/msgrd?v=3&uin='.$memberprofile['qq'].'&site=qq&menu=yes">'.(checkmobile()?lang('plugin/keke_veeker', 'kkvklang226'):lang('plugin/keke_veeker', 'kkvklang49')).'</a>';
					}else{
                        if(!checkmobile()){
                            $btna='<a class="zjda msg"  onclick="showWindow(\'sendpm\', this.href);" href="home.php?mod=spacecp&amp;ac=pm&amp;op=showmsg&amp;handlekey=showmsg_1&amp;touid='.$val['authorid'].'&amp;pmid=0&amp;daterange=2">'.lang('plugin/keke_veeker', 'kkvklang49').'</a>';
                        }else{
                            $btna='<a class="zjda msg" href="home.php?mod=space&do=pm&subop=view&touid='.$val['authorid'].'" target="_blank">'.lang('plugin/keke_veeker', 'kkvklang226').'</a>';
                        }
					}
			}
			if($state==10){
				$aaa=lang('plugin/keke_veeker', 'kkvklang50');
			}elseif($state==8){
				$aaa=lang('plugin/keke_veeker', 'kkvklang22');
			}elseif($state==9){
				$aaa=lang('plugin/keke_veeker', 'kkvklang23');
			}
			$wcrw='';
			if($val['authorid']==$_G['uid']){
				if($state==10){
					$wcrw=checkmobile()?'<a href="javascript:;" class="zjda" onclick= "if(confirm( \''.lang('plugin/keke_veeker', 'kkvklang31').'\')==false){return false;}fundo('.$val['tid'].','.$val['pid'].',\'wc\'); ">'.lang('plugin/keke_veeker', 'kkvklang32').'</a>':'<a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang31').'&#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039fundo('.$val['tid'].','.$val['pid'].',\&#039wc\&#039);&#039,1)" class="zjda">'.lang('plugin/keke_veeker', 'kkvklang32').'</a>';					
				}elseif($state==8){
				$wcrw=checkmobile()?'<a href="javascript:;"  class="zjda" onclick= "if(confirm( \''.lang('plugin/keke_veeker', 'kkvklang19').'\')==false){return false;}fundo('.$val['tid'].','.$val['pid'].',\'wc\'); ">'.lang('plugin/keke_veeker', 'kkvklang21').'</a>':'<a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang19').'&#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039fundo('.$val['tid'].','.$val['pid'].',\&#039wc\&#039);&#039,1)" class="zjda">'.lang('plugin/keke_veeker', 'kkvklang21').'</a>';}
				elseif($state==9){
				$aaa=lang('plugin/keke_veeker', 'kkvklang23');}
				$wcrw='<div id="btnpid_'.$val['pid'].'">'.$wcrw.'</div>';
			}else {
				$wcrw='';
			}
			$zt=$state?'<div id=zbpid_'.$val['pid'].'><div class="zb">'.lang('plugin/keke_veeker', 'kkvklang51').'</div><div class="keke_vk_zbzt">'.$aaa.'</div></div>'.$wcrw:'<div id=zbpid_'.$val['pid'].'></div>';
			if($counts['model']==2){
				$cnbtns=$temp[]='<div class="keke_vk_cn" id="vkpid_'.$val['pid'].'">'.$zt.$btna.'<div id="btnpid_'.$val['pid'].'">'.$btnxb.'</div></div>';
			}else{
				if($on==1)$clas='stacn';elseif($on==2)$clas='stajj';else $clas='keke_vk_zbzt boderr';
				$cnbtns=$temp[]='<div class="keke_vk_cn" id="vkpid_'.$val['pid'].'">
				<div class="'.$clas.'" id="ztpid_'.$val['pid'].'">'.$statetxt.'</div><div id="btnpid_'.$val['pid'].'">'.$btns.'</div>'.$btna.'</div>';
			}
			if(!$postlist[$key]['first']){
				$postlist[$key]['message']=$cnbtns.$postlist[$key]['message'];
			}
			if($num==0){
				$postlist[$key]['message']=$btnstyle.$postlist[$key]['message'];
			}
			$num++;
		}
		if($_G['forum_firstpid']){
			$postlist[$_G['forum_firstpid']]['message']=$rts.$postlist[$_G['forum_firstpid']]['message'].$add;
		}
		$temp=array();
		return $temp;
	}
	
	
	function post_message($param) {
		global $_G;
		$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
		$param = $param['param'];
		if(!$_G['uid']){
			return '';
		}
		$section = empty($keke_veeker['bk']) ? array() : unserialize($keke_veeker['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){
			return '';
		}	
		include_once DISCUZ_ROOT . './source/plugin/keke_veeker/function/fun.php';
		if(($param[0]=="post_newthread_succeed" || $param[0]=="post_newthread_mod_succeed") && $_GET['tlx']){
			$tid = $param[2]['tid'];
			_acaddvk($tid);		
		}
	}
	
	function forumdisplay_thread_output(){
		global $_G, $threadlist;
		$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
		$ret=array();
		if(!$keke_veeker['forumlistv']){
			return $ret;
		}
		$wkch=dhtmlspecialchars($keke_veeker['wkch']);
		$gzch=dhtmlspecialchars($keke_veeker['gzch']);
		$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
		$creditnamea=$_G['setting']['extcredits'][$keke_veeker['pa']]['title'];
		$creditnameb=$_G['setting']['extcredits'][$keke_veeker['pb']]['title'];
		$return = array();
		$section = empty($keke_veeker['bk']) ? array() : unserialize($keke_veeker['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){return $return;}
		foreach ($threadlist as $v) {if (is_numeric($v['tid'])) $tidlist .= $v['tid'].',';}
		if ($tidlist) $tidlist = substr($tidlist, 0, -1);if(!$tidlist){return $return;}
		$vk_data=C::t('#keke_veeker#keke_veeker')->fetch_by_tid($tidlist);
		foreach ($vk_data as $row) {
			$data[$row['tid']] = $row;
		}
		$vk_cndata=C::t('#keke_veeker#keke_veeker_cn')->count_by_state_all($tidlist);
		foreach ($vk_cndata as $vals) {
			$data[$vals['tid']]['sta']=$vals['sta'];
			$data[$vals['tid']]['stb']=$vals['stb'];
			$data[$vals['tid']]['coun']=$vals['coun'];
		}
		$na=$xygj=$tjfs=0;
		include template('keke_veeker:show');
		foreach($threadlist as $k => $v){
			$rets='';
			if($data[$v['tid']]){
				$deadline=$data[$v['tid']]['deadline'];
				$sta=$data[$v['tid']]['state'];
				if($sta==2){
					$tstxt=lang('plugin/keke_veeker', 'kkvklang52');
					$bgsty="vkbgb";
				}elseif($sta==1){
					if($deadline<$_G['timestamp']){
					$tstxt=lang('plugin/keke_veeker', 'kkvklang53');
					$bgsty="vkbgc";
					}else{
						$xy=$data[$v['tid']]['total'];
						$yzrw=$data[$v['tid']]['sta'];
						$yzrwsa=$data[$v['tid']]['coun'];
						if($keke_veeker['zlms']){
							$jjfs=$data[$v['tid']]['stb'];
							$tjfs=$data[$v['tid']]['replies'];
							$xygj=$xy-$tjfs+$jjfs;
						}else{
							$xygj=$xy-$yzrw;
						}
						//20160513
						if($data[$v['tid']]['model']==2){
							$xygj=$xy-$yzrwsa;
						}
						$tsa='';
						if($xygj<=0){
							$tstxt=lang('plugin/keke_veeker', 'kkvklang54');$bgsty="vkbgb";
						}else{
							if(!($data[$v['tid']]['model']==2)){
								if($data[$v['tid']]['pa']){
									$paview='+'.$data[$v['tid']]['pa'].$creditnamea;
								}
								if($data[$v['tid']]['pb']){
									$pbview='+'.$data[$v['tid']]['pb'].$creditnameb;
								}
								$tsa=lang('plugin/keke_veeker', 'kkvklang55').$data[$v['tid']]['price'].$creditname.$paview.$pbview;
							}
							$tstxt=$tsa.' '.lang('plugin/keke_veeker', 'kkvklang56').$xygj.lang('plugin/keke_veeker', 'kkvklang57');
							$bgsty="vkbga";
						}
					}
				}elseif($sta==4){
					$tstxt=lang('plugin/keke_veeker', 'kkvklang58');$bgsty="vkbgd";
				}
				if($data[$v['tid']]['model']==1){
					$vkmodes=lang('plugin/keke_veeker', 'kkvklang59');$msname=lang('plugin/keke_veeker', 'kkvklang60');$bgstys='vkbgg';
				}elseif($data[$v['tid']]['model']==2){
					$vkmodes=lang('plugin/keke_veeker', 'kkvklang61');$msname=lang('plugin/keke_veeker', 'kkvklang62');$bgstys='vkbge';
				}elseif($data[$v['tid']]['model']==3){
					$vkmodes=lang('plugin/keke_veeker', 'kkvklang63');$msname=lang('plugin/keke_veeker', 'kkvklang64');$bgstys='vkbgf';
				}
				$return[]=$style.'<span class="kekevklist '.$bgstys.'" title="'.$msname.'">'.$vkmodes.'</span><span class="kekevklist '.$bgsty.'">'.$tstxt.'</span>';
				$liststy=($na==0)?$vkliststyle:'';
				$rets=$style.$liststy.'<span class="vklistbox"><span class="kekevklist '.$bgstys.'" title="'.$msname.'">'.$vkmodes.'</span><span class="kekevklist '.$bgsty.'">'.$tstxt.'</span></span>';
				if(checkmobile()){
					$_G['forum_threadlist'][$k]['subject']=$style.$liststy.'<span class="vklistbox"><span class="kekevklist '.$bgstys.'" title="'.$msname.'">'.$vkmodes.'</span><span class="kekevklist '.$bgsty.'">'.$tstxt.'</span></span>'.$threadlist[$k]['subject'];
				}
				$na++;
			}else{
				$return[]='';
			}
			$ret[]=$rets;
		}
		if(checkmobile()){
			return array();
		}
		return $ret;
	}
}
if(file_exists("source/plugin/keke_veeker/assembly/mobile.inc.php")){
	include_once DISCUZ_ROOT . './source/plugin/keke_veeker/assembly/mobile.inc.php';
}