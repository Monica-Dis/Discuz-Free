<?php
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

dheader('location: plugin.php?id=keke_veeker:index');