<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	$ppp = 20;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount1=DB::result_first("select count(1) from ".DB::table('keke_veeker_jb')."");
	$multipage = multi($allcount1, $ppp, $page, ADMINSCRIPT."?action=plugins&identifier=$identifier&cp=admin_jubao&pmod=admin_jubao&operation=$operation&do=$do");
	$addonid = 'keke_veeker.plugin';
    showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=".$plugin["identifier"]."&pmod=admin_ticheng");
    showtableheader(lang('plugin/keke_veeker', 'kkvklang160'));	
    showsubtitle(array('ID',lang('plugin/keke_veeker', 'kkvklang138'), lang('plugin/keke_veeker', 'kkvklang139'), lang('plugin/keke_veeker', 'kkvklang140'),lang('plugin/keke_veeker', 'kkvklang141'),lang('plugin/keke_veeker', 'kkvklang142')));
	$query = DB::query("SELECT * FROM ".DB::table('keke_veeker_jb')." order by id desc LIMIT ".$startlimit.",".$ppp);
	while($judata = DB::fetch($query)) {
		$table = array();
		if($judata['cate']==1)$jblb=lang('plugin/keke_veeker', 'kkvklang143');elseif($judata['cate']==2)$jblb=lang('plugin/keke_veeker', 'kkvklang144');elseif($judata['cate']==3)$jblb=lang('plugin/keke_veeker', 'kkvklang145');elseif($judata['cate']==4)$jblb=lang('plugin/keke_veeker', 'kkvklang146');
		$table[0] = $judata['id'];
        $table[1] = getnames($judata['uid']);
		$table[2] = $jblb;
        $table[3] = dhtmlspecialchars($judata['text']);
		$table[4] = '<a target="_blank" href="forum.php?mod=viewthread&tid='.$judata['tid'].'" class="onlineqq">forum.php?mod=viewthread&tid='.$judata['tid'].'</a>';
        $table[5] = date('Y-m-d h:i:s',$judata['date']);
        showtablerow('', '', $table);
		}
	if($multipage)echo '<tr><td align="right" colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', '', '');    
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();

function getnames($uid){
	$memberdata=C::t('common_member')->fetch($uid);
	return $memberdata['username'];
}