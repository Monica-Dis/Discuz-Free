<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
require_once DISCUZ_ROOT . './source/plugin/keke_veeker/function/fun.php';
$wkch=dhtmlspecialchars($keke_veeker['wkch']);
$gzch=dhtmlspecialchars($keke_veeker['gzch']);
$keke_veeker['wapdb']=dhtmlspecialchars($keke_veeker['wapdb']);
$bknames=_getforumdatas();
$picnav=_getpicnav($keke_veeker['picnav']);
$pcpicnav=_getpicnav($keke_veeker['pcpic']);
$wappic=_getpicnav($keke_veeker['wappic']);
$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];

$params=array('o','type','f','m','sta');
foreach($params as $pv){
	$_GET[$pv]=dhtmlspecialchars($_GET[$pv]);
}

$vkmod=unserialize($keke_veeker['mod']);
loadcache('keke_veeker');
$info=$_G['cache']['keke_veeker'];	
$info=unserialize($info);
if($info){
	$navtitle=$info['title']['message'];
	$wapnavtitle=$info['waptitle']['message'];
	$metakeywords=checkmobile()?$info['wapkeywords']['message']:$info['keywords']['message'];
	$metadescription=checkmobile()?$info['wapdescription']['message']:$info['description']['message'];
}


$vkbk=unserialize($keke_veeker['bk']);
$vkbkstr=dimplode($vkbk);
$vkbkcount=count($vkbk);

$wapflists=array();
$wapflists=_getmobilenavarr();

$f=intval($_GET['f']);
if($f){
  $type=_getthreadclassarr($f);
  $catname=$bknames[$f]['name'];
}


$catname=$_GET['type'] ? _getthreadclassname(intval($_GET['type'])) : $catname;

$incsql =_getindexsqls();
$order= _getindexorder();


$ppp = $keke_veeker['page'] ? intval($keke_veeker['page']) : 30;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;

$allcount = _getindexallcount($vkbkstr,$incsql);
$tmpurl='plugin.php?id=keke_veeker:index&m='.$_GET['m'].'&sta='.$_GET['sta'].'&f='.$_GET['f'].'&type='.$_GET['type'].'&o='.$_GET['o'].'';

$vkindexlist=_getindexlist($vkbkstr,$incsql,$order,$startlimit,$ppp);
$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);



$keke_veeker['gfgg']=$keke_veeker['gfgg']? intval($keke_veeker['gfgg']) : 0;
//公告
$queryg = DB::query("SELECT * FROM ".DB::table('forum_thread')." WHERE fid=".$keke_veeker['gfgg']." order by tid desc LIMIT 0,8");
while($ggdata = DB::fetch($queryg)) {
$gglist.=' <li><a href="forum.php?mod=viewthread&tid='.$ggdata['tid'].'">'.$ggdata['subject'].'</a></li>';
}


//威客排行
$n=1;
$queryph = DB::query("SELECT uid,count(1) as vkcn FROM ".DB::table('keke_veeker_cn')." where state in (1,8,9,10) group by uid order by vkcn desc LIMIT 0,10");
while($ggdata = DB::fetch($queryph)) {
	if($n<='3'){$top='top';}else{$top='';}
	$vkph.='	<li>
					<div class="col-rank floatl"><span class="'.$top.' num">'.$n.'</span></div>
					<div class="col-user floatl"><a href="home.php?mod=space&uid='.$ggdata['uid'].'" target="_blank" rel="nofollow">'._getusernames($ggdata['uid']).'</a></div>
					<div class="col-rec floatl cdf3031">'.$ggdata['vkcn'].'</div>
				</li>';
	$n++;
}

$countinfo=_getcountinfo();

if(checkmobile()){
	include template('keke_veeker:vk-index');
}else{
	include template('diy:vk-index', NULL, './source/plugin/keke_veeker/template');
}