<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


global $_G;
loadcache('plugin'); 
include_once DISCUZ_ROOT."source/plugin/keke_veeker/identity.inc.php";


function _getusernames($uid){
	$memberdata=C::t('common_member')->fetch($uid);
	return $memberdata['username'];
}


function _getpicnav($data){
	$picnav=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',dhtmlspecialchars($data)));
	foreach($picnav as $ks=>$item){
		$picnavarr[]=explode('|',$item);
	}
	return $picnavarr;
}

function _getforumdatas(){
	$bkdata=DB::fetch_all("SELECT * FROM ".DB::table('forum_forum')."");// WHERE status=1
	foreach($bkdata as $kd=>$vd){
		$bknames[$vd['fid']]=$vd;
	}
	return $bknames;
}

function _getmobilenavarr(){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$vkbk=unserialize($keke_veeker['bk']);
	foreach($vkbk as $k=>$v){
		$typel = _getthreadclassarr($v);
		$classtype=array();
		foreach($typel as $key=>$vl){
			$classtype[]=$vl;
		}
		$wapflists[$v]['fid']=$v;
		$wapflists[$v]['type']=$classtype;
	}
	return $wapflists;
}
function _getvkforumarr(){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$section = empty($keke_veeker['bk']) ? array() : unserialize($keke_veeker['bk']);
	foreach($section as $k=>$v){
		$bkname=_getfidname($v);
		$flist[]=array(
			'fid'=>$v,
			'name'=>$bkname
		);
	}
	return $flist;
}

function _getthreadclassarr($fid){
	return DB::fetch_all("SELECT * FROM ".DB::table('forum_threadclass')." WHERE fid='".intval($fid)."'");
}
function _getthreadclassname($typeid){
	return DB::result_first("SELECT name FROM ".DB::table('forum_threadclass')." WHERE typeid='".intval($typeid)."'");
}


function _getindexallcount($vkbkstr,$incsql){
	return DB::result_first("SELECT count(1) FROM ".DB::table('keke_veeker')." v,".DB::table('forum_thread')." t WHERE t.tid=v.tid AND t.displayorder>='0' AND t.fid in (".$vkbkstr.") ".$incsql."");
}


function _getindexorder(){
	if($_GET['o']==2){
		$order= "order by v.deadline asc";
	}elseif($_GET['o']==1){
		$order= "order by v.deadline desc";
	}elseif($_GET['o']==3){
		$order= "order by v.price desc";
	}else{
		$order= "order by t.dateline desc";
	}
	return $order;
}

function _getindexsql(){
	global $_G;
	$incsql='';
	$m=intval($_GET['m']);
	if($m){
		$incsql.=" AND v.model=".$m;
	}
	$sta=intval($_GET['sta']);
	if($sta==1){
		$incsql.=" AND v.state=1 AND v.deadline>".$_G['timestamp']."";
	}elseif($sta==2 || $sta==4){
		$incsql.=" AND v.state=".$sta;
	}elseif($sta==6){
		$incsql.=" AND v.deadline<".$_G['timestamp'];
	}
	$f=intval($_GET['f']);
	if($f){
		$incsql.=" AND t.fid=".$f."";
	}
	$types=intval($_GET['type']);
	if($types){
		$incsql.=" AND t.typeid=".$types."";
	}
	if($_GET['key']) {
		$incsql .= " AND t.subject LIKE '%".addcslashes($_GET['key'],'%_')."%'";
	}
	return $incsql;
}


function _getindexlist($vkbkstr,$incsql,$order,$startlimit,$ppp){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
	$creditnamea=$_G['setting']['extcredits'][$keke_veeker['pa']]['title'];
	$creditnameb=$_G['setting']['extcredits'][$keke_veeker['pb']]['title'];
	$query = DB::fetch_all("SELECT t.tid,t.subject,t.replies,t.dateline,v.* FROM ".DB::table('keke_veeker')." v,".DB::table('forum_thread')." t WHERE t.tid=v.tid AND t.displayorder>=0 AND t.fid in (".$vkbkstr.") ".$incsql." ".$order." LIMIT ".$startlimit.",".$ppp);
	$md5file='keke_veeker.plugin';
	foreach($query as $vkdata) {
		$tis=$xytis=$xygj=$pa=$pb=$xq='';
		$cnfs=DB::result_first("select count(1) from ".DB::table('keke_veeker_cn')." where tid=".$vkdata['tid']." AND state=1");
		$g=lang('plugin/keke_veeker', 'kkvklang57');	
		if($vkdata['model']==1){
			$modelname=lang('plugin/keke_veeker', 'kkvklang59');$modelsty='xsrw';
			if($vkdata['pa'])$pa=' + <b class="reds">'.$vkdata['pa'].'</b>'.$creditnamea;
			if($vkdata['pb'])$pb=' + <b class="reds">'.$vkdata['pb'].'</b>'.$creditnameb;
			$tis=lang('plugin/keke_veeker', 'kkvklang55').' <i></i> <b class="reds">'.$vkdata['price'].'</b>'.$creditname.$pa.$pb;
			if($keke_veeker['zlms']){
				$jjfs=C::t('#keke_veeker#keke_veeker_cn')->count_by_state($vkdata['tid'],2);
				$tjfs=DB::result_first("select replies from ".DB::table('forum_thread')." where tid=".$vkdata['tid']);
				$xygj=$vkdata['total']-$tjfs+$jjfs;
			}else{
				$xygj=$vkdata['total']-$cnfs;
			}
		}elseif($vkdata['model']==2){
			$modelname=lang('plugin/keke_veeker', 'kkvklang61');$modelsty='tbrw';
			$yusuandata=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_veeker['yusuan']));
			$yusuan=$yusuandata[$vkdata['price']];
			$cnfs=DB::result_first("select count(1) from ".DB::table('keke_veeker_cn')." where tid=".$vkdata['tid']." AND state in (1,8,9,10)");
			$xygj=$vkdata['total']-$cnfs;
			$tis=lang('plugin/keke_veeker', 'kkvklang131').' <i></i> <b class="reds">'.$yusuan.'</b>'.$creditname;
			$g=lang('plugin/keke_veeker', 'kkvklang61');
            $vkdata['price']=checkmobile()?$cnfs:$vkdata['price'];
		}elseif($vkdata['model']==3){
			$modelname=lang('plugin/keke_veeker', 'kkvklang63');$modelsty='zdrw';
			if($vkdata['pa'])$pa=' + <b class="reds">'.$vkdata['pa'].'</b>'.$creditnamea;
			if($vkdata['pb'])$pb=' + <b class="reds">'.$vkdata['pb'].'</b>'.$creditnameb;
			$tis=lang('plugin/keke_veeker', 'kkvklang55').' <i></i> <b class="reds">'.$vkdata['price'].'</b>'.$creditname.$pa.$pb;
			$xygj=$vkdata['total']-$cnfs;
		}
	
		$jzsc=$vkdata['deadline']-$_G['timestamp'];
		$xytis=lang('plugin/keke_veeker', 'kkvklang130').'<b class="reds">'.$xygj.'</b>'.$g;
		if($jzsc>0){
			$dateline=$d.lang('plugin/keke_veeker', 'kkvklang132').lang('plugin/keke_veeker', 'kkvklang134');
			$datelinearr=_timediff(TIMESTAMP,$vkdata['deadline']);
			$dateline=$datelinearr['day'].lang('plugin/keke_veeker', 'kkvklang132').$datelinearr['hour'].lang('plugin/keke_veeker', 'kkvklang133').lang('plugin/keke_veeker', 'kkvklang134');
		}else{
			$dateline=lang('plugin/keke_veeker', 'kkvklang53');
		}
		if($vkdata['state']==4){
			$dateline=lang('plugin/keke_veeker', 'kkvklang34');
			$xq='<span style="color:#CCC;">'.lang('plugin/keke_veeker', 'kkvklang58').'</span>';
		}elseif($vkdata['state']==2){
			$xq='<span style="color:#CCC;">'.lang('plugin/keke_veeker', 'kkvklang52').'</span>';
		}elseif($vkdata['deadline']<$_G['timestamp']){
			$xq='<span style="color:#CCC;">'.lang('plugin/keke_veeker', 'kkvklang53').'</span>';
		}elseif($xygj<=0){
			$xq='<span style="color:#CCC;">'.lang('plugin/keke_veeker', 'kkvklang54').'</span>';
		}else{
			$xq=$xytis;
		}
		$xq=checkmobile()?$xytis:'<span>'.$tis.' / '.$xq.'</span>';
		
		$memberprofile = C::t('common_member_profile')->fetch($vkdata['uid']);
		$vkmod=array(
			'qq'=>$memberprofile['qq'],
			'uid'=>$vkdata['uid'],
			'usname'=>_getusernames($vkdata['uid']),
			'tid'=>$vkdata['tid'],
			'subject'=>$vkdata['subject'],
			'price'=>$vkdata['price'],
			'tis'=>$tis,
			'modelsty'=>$modelsty,
			'modelname'=>$modelname,
			'xq'=>$xq,
			'replies'=>$vkdata['replies'],
			'dateline'=>$dateline,
			'time'=>date('Y/m/d',$vkdata['dateline']),
		);
		$vkindexlist[]=$vkmod;
	}
	return $vkindexlist;
}

function _timediff( $begin_time, $end_time ){
    if ( $begin_time < $end_time ) {
        $starttime = $begin_time;
        $endtime = $end_time;
    } else {
        $starttime = $end_time;
        $endtime = $begin_time;
    }
    $timediff = $endtime - $starttime;
    $days = intval( $timediff / 86400 );
    $remain = $timediff % 86400;
    $hours = intval( $remain / 3600 );
    $remain = $remain % 3600;
    $mins = intval( $remain / 60 );
    $secs = $remain % 60;
    $res = array( "day" => $days, "hour" => $hours, "min" => $mins, "sec" => $secs );
    return $res;
}

function _getcountinfo(){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$section = empty($keke_veeker['bk']) ? array() : unserialize($keke_veeker['bk']);
	$bk=dimplode($section);
	$fb=$cn='';
	if($_G['uid']){
		$fb=DB::result_first("SELECT count(1) FROM ".DB::table('forum_thread')." a ,".DB::table('keke_veeker')." p WHERE a.fid in (".$bk.") AND a.authorid=".$_G['uid']." AND a.tid=p.tid");
		$cn=count(DB::fetch_all("SELECT a.tid FROM ".DB::table('forum_post')." a,".DB::table('keke_veeker')." b WHERE a.fid in (".$bk.")  AND a.tid=b.tid AND a.authorid=".$_G['uid']." AND first=0 group by a.tid"));
	}
	$mbcount=DB::result_first("select count(1) from ".DB::table('common_member'));
	$rwcount=DB::result_first("select count(1) from ".DB::table('keke_veeker'));
	$jecount=DB::result_first("select sum(je) from ".DB::table('keke_veeker_cn')." where state=1");
	return array($fb,$cn,$mbcount,$rwcount,$jecount);
}


function _getfidname($fid){
	return DB::result_first("select name from ".DB::table('forum_forum')." where fid=".$fid);
}


function _getrwlist($type,$vkbk=0,$vkname='',$timea='',$timeb=''){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$section = empty($keke_veeker['bk']) ? array() : unserialize($keke_veeker['bk']);
	$bk=dimplode($section);
	$uids=$_G['uid'];
	$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
	$creditnamea=$_G['setting']['extcredits'][$keke_veeker['pa']]['title'];
	$creditnameb=$_G['setting']['extcredits'][$keke_veeker['pb']]['title'];
	$ppp=checkmobile()?20:5;
	$tmpurl='plugin.php?id=keke_veeker:actions&formhash='.FORMHASH.'&ac=90&type='.$type;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$where='';
	if($vkbk){
		$where.=" AND a.fid=".$vkbk;
	}else{
		$where.=' AND a.fid in ('.$bk.')';
	}
	if($vkname) {
		$where .= " AND a.subject LIKE '%".addcslashes($vkname,'%_')."%'";
	}
	if($timea) {
		$where.=" AND a.dateline>".$timea;
	}
	if($timeb) {
		$where.=" AND a.dateline<".$timeb;
	}
	if($type==1){
		$allcount=DB::result_first("select count(1) from ".DB::table('forum_thread')." a, ".DB::table('keke_veeker')." b where a.authorid=".$uids." AND a.tid=b.tid".$where);
	}else{
		$allcount=count(DB::fetch_all("SELECT a.tid FROM ".DB::table('forum_thread')." a,".DB::table('forum_post')." b WHERE  a.authorid=".$_G['uid']." AND a.tid=b.tid AND b.first=0 group by b.tid".$where));
	}
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=str_replace("href=","name=",$multipage);
	$multipage=str_replace("name=","href='javascript:' onclick='rwlist(this.name)' name=",$multipage);
	$multipage=str_replace("onclick='list(this.name)' ".'name="custompage"','',$multipage);
	$multipage=str_replace('window.location=','rwlist(',$multipage);
	$multipage=str_replace('; doane(event);','); doane(event);',$multipage);
	$n=0;
	$yusuandata=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_veeker['yusuan']));
	if($type==1){
		$rwarr=DB::fetch_all("select a.*,b.model,b.total,b.price,b.pa,b.pb,b.deadline,b.donetime from ".DB::table('forum_thread')." a,".DB::table('keke_veeker')." b where a.displayorder>=0 AND a.authorid='".$uids."' AND a.tid=b.tid ".$where." order by a.dateline desc LIMIT ".$startlimit.",".$ppp);
	}else{
		$sql="select a.tid,a.dateline,a.subject,a.fid,c.total,c.model,c.price,c.pa,c.pb,c.deadline,c.donetime from ".DB::table('forum_thread')." a,".DB::table('forum_post')." b,".DB::table('keke_veeker')." c where a.displayorder>=0 AND a.tid=b.tid AND b.tid=c.tid AND b.authorid=".$uids." AND b.first=0 ".$where." group by a.tid order by a.dateline desc LIMIT ".$startlimit.",".$ppp;
		$rwarr=DB::fetch_all($sql);
	}
	foreach($rwarr as $val){
		if($n%2==1)$bg='class="bg"';else $bg='';
		$pa=$val['pa']?' + <span class="xx">'.$val['pa'].'</span>'.$creditnamea:'';
		$pb=$val['pb']?' + <span class="xx">'.$val['pb'].'</span>'.$creditnameb:'';
		$forumname=_getfidname($val['fid']);
		if($val['model']==1){
			$modname=lang('plugin/keke_veeker', 'kkvklang59'); $modsty='msta'; $xqdata=lang('plugin/keke_veeker', 'kkvklang55').'<span class="xx">'.$val['price'].'</span>'.$creditname.$pa.$pb.' / '.lang('plugin/keke_veeker', 'kkvklang56').'<span class="xx">'.$val['total'].'</span>'.lang('plugin/keke_veeker', 'kkvklang57');
		}elseif(
			$val['model']==2){$modname=lang('plugin/keke_veeker', 'kkvklang61'); $modsty='mstb';$xqdata=lang('plugin/keke_veeker', 'kkvklang131').'<span class="xx">'.$yusuandata[$val['price']].'</span>'.$creditname.' / '.lang('plugin/keke_veeker', 'kkvklang56').'<span class="xx">'.$val['total'].'</span>'.lang('plugin/keke_veeker', 'kkvklang176');
		}elseif(
			$val['model']==3){$modname=lang('plugin/keke_veeker', 'kkvklang63');$modsty='mstc';  $xqdata=lang('plugin/keke_veeker', 'kkvklang55').'<span class="xx">'.$val['price'].'</span>'.$creditname.$pa.$pb.' / '.lang('plugin/keke_veeker', 'kkvklang56').'<span class="xx">'.$val['total'].'</span>'.lang('plugin/keke_veeker', 'kkvklang57');
		}
		$rwlist.='<a href="forum.php?mod=viewthread&tid='.$val['tid'].'" target="_blank"><li '.$bg.'><div class="leftmod"><span class="mods '.$modsty.'">'.$modname.'</span></div><span class="time">'.date('Y-m-d',$val['dateline']).'</span>'.cutstr($val['subject'],50).'<span class="ms"> '.$xqdata.' </span><span class="zts"> '.$forumname.' </span></li></a>';
		$n++;
	}
	$rwlist.=$multipage;
	return $rwlist;
}


function _getzblists($tid){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
	$query = DB::fetch_all("SELECT * FROM ".DB::table('keke_veeker_cn')." WHERE tid=".$tid." order by id desc");
	foreach($query as $zbdata) {
		if($zbdata['state']==8){
			if($_G['uid']==$zbdata['uid']){
				$zbac='<a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang19').'&#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039fundo('.$zbdata['tid'].','.$zbdata['pid'].',\&#039wc\&#039);&#039,1)">'.lang('plugin/keke_veeker', 'kkvklang21').'</a>';
			}else{
				$zbac=lang('plugin/keke_veeker', 'kkvklang22');
			}
			$zbzt=lang('plugin/keke_veeker', 'kkvklang22');
		}elseif($zbdata['state']==9){
			if($_G['uid']==$zbdata['uid']){
				$zbac=lang('plugin/keke_veeker', 'kkvklang23');
			}else{
				$zbac='<a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang24').$zbdata['je'].$creditname.lang('plugin/keke_veeker', 'kkvklang24').' &#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039fundo('.$zbdata['tid'].','.$zbdata['pid'].',\&#039hg\&#039);&#039,1)">'.lang('plugin/keke_veeker', 'kkvklang28').'</a> / 
		<a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang27').'&#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039fundo('.$zbdata['tid'].','.$zbdata['pid'].',\&#039bhg\&#039);&#039,1)">'.lang('plugin/keke_veeker', 'kkvklang29').'</a>';
			}$zbzt=lang('plugin/keke_veeker', 'kkvklang23');
		}elseif($zbdata['state']==10){
			if($_G['uid']==$zbdata['uid']){
				$zbac='<a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang31').'&#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039fundo('.$zbdata['tid'].','.$zbdata['pid'].',\&#039wc\&#039);&#039,1)">'.lang('plugin/keke_veeker', 'kkvklang32').'</a>';
			}else{
				$zbac=lang('plugin/keke_veeker', 'kkvklang30');
			}
			$zbzt=lang('plugin/keke_veeker', 'kkvklang33');
		}elseif($zbdata['state']==1){
			$zbac=lang('plugin/keke_veeker', 'kkvklang34');$zbzt=lang('plugin/keke_veeker', 'kkvklang34');
		}
		if(!($_G['uid']==$zbdata['uid'] || $_G['uid']==$_G['thread']['authorid'])){
			$zbac=date('Y-m-d h:i:s',$zbdata['dateline']);
		}

		if($_G['groupid']==$keke_veeker['sup'] && !($zbdata['state']==1)){
			$zbac.=' / <a href="javascript:;" onclick="showDialog(&#039'.lang('plugin/keke_veeker', 'kkvklang35').'&#039, &#039confirm&#039, &#039'.lang('plugin/keke_veeker', 'kkvklang20').'&#039, &#039location.href=\&#039plugin.php?id=keke_veeker:actions&tid='.$tid.'&cnid='.$zbdata['id'].'&formhash='.FORMHASH.'&ac=delzb\&#039&#039,1)">'.lang('plugin/keke_veeker', 'kkvklang36').'</a>';
		}
		if($_G['uid']==$_G['thread']['authorid'] || $_G['groupid']==$keke_veeker['sup']){
			if(!($counts['state']==4)){
				$zj='  / <a href="javascript:" onclick="showWindow(\'keke_veeker\', \'plugin.php?id=keke_veeker:tis&tid='.$tid.'&pid='.$zbdata['pid'].'&auid='.$_G['thread']['authorid'].'&formhash='.FORMHASH.'&ac=9\');">'.lang('plugin/keke_veeker', 'kkvklang37').'</a>';
			}
		}
		$zblists[]=array(
			'zbac'=>$zbac,
			'zbzt'=>$zbzt,
			'uid'=>$zbdata['uid'],
			'usname'=>_getusernames($zbdata['uid']),
			'je'=>$zbdata['je'],
			'zj'=>$zj,
			'pid'=>$zbdata['pid']
		);
	}
	return $zblists;
}

function _insertbc($tid){
	global $_G;
	$text=daddslashes($_GET['keke_veeker_bc']);
	$bcarr = array(
		'uid' => $_G['uid'],
		'tid' => $tid,
		'text' => $text,
		'date' => $_G['timestamp']
	);
	C::t('#keke_veeker#keke_veeker_bc')->insert($bcarr, true);
}

function _insertjb($tid){
	global $_G;
	$keke_veeker_jb=daddslashes($_GET['keke_veeker_jb']);
	$cate=intval($_GET['report_cate']);
	$jbarr=array(
		'tid' => $tid,
		'cate' => $cate,
		'text' => $keke_veeker_jb,
		'uid' => $_G['uid'],
		'date' => $_G['timestamp']
	);
	C::t('#keke_veeker#keke_veeker_jb')->insert($jbarr, true);
	showmessage(lang('plugin/keke_veeker', 'kkvklang113'),'forum.php?mod=viewthread&tid='.$tid);
}

function _acqingsuan($tid,$keke_veeker_data){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$wkch=dhtmlspecialchars($keke_veeker['wkch']);
	$ftdate=_gettthreaddata($tid);
	if($_G['timestamp']-$ftdate['dateline']<(3600*$keke_veeker['qs'])){
		showmessage(lang('plugin/keke_veeker', 'kkvklang92').$keke_veeker['qs'].lang('plugin/keke_veeker', 'kkvklang93'));
	}
	$cncount=C::t('#keke_veeker#keke_veeker_cn')->count_by_state_all($tid);
	$cncount=$cncount[0];
	if($keke_veeker_data['model']==2){
		$stacount=$cncount['stc'];
		if($stacount){
			showmessage(lang('plugin/keke_veeker', 'kkvklang94'));
		}	
	}else{
		$cncount=$cncount['coun'] ? $cncount['coun'] : 0;
		$tgcount=$keke_veeker_data['replies'];
		if($tgcount>$cncount){
			showmessage(lang('plugin/keke_veeker', 'kkvklang94'));
		}
		$cnfs=C::t('#keke_veeker#keke_veeker_cn')->count_by_state($tid,1);
		$tuifs=$keke_veeker_data['total']-$cnfs;
		$tuije=$tuifs*$keke_veeker_data['price'];
		$tuijea=$tuifs*$keke_veeker_data['pa'];
		$tuijeb=$tuifs*$keke_veeker_data['pb'];
		if($tuifs){
			updatemembercount(_getauthorids($tid), array('extcredits'.$keke_veeker['jf'].''=>$tuije), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang95')._getsubjectss($tid).lang('plugin/keke_veeker', 'kkvklang96'));
			updatemembercount(_getauthorids($tid), array('extcredits'.$keke_veeker['pa'].''=>$tuijea), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang95')._getsubjectss($tid).lang('plugin/keke_veeker', 'kkvklang96'));
			updatemembercount(_getauthorids($tid), array('extcredits'.$keke_veeker['pb'].''=>$tuijeb), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang95')._getsubjectss($tid).lang('plugin/keke_veeker', 'kkvklang96'));

		}
	}
}


function _aczuijia($tid,$keke_veekerdata){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$wkch=dhtmlspecialchars($keke_veeker['wkch']);
	if($_G['groupid']==1){
	    $_G['uid']=_getauthorids($tid);
    }
	$membercount = C::t('common_member_count')->fetch($_G['uid']);					
	$extcredits=$membercount['extcredits'.$keke_veeker['jf']];
	$extcreditsa=$membercount['extcredits'.$keke_veeker['pa']];
	$extcreditsb=$membercount['extcredits'.$keke_veeker['pb']];
	
	$keke_veeker_zj=intval($_GET['keke_veeker_zj']);
	$keke_veeker_zjts=intval($_GET['keke_veeker_zjts']);
	if($keke_veeker_zj=='' && $keke_veeker_zjts==''){
		showmessage(lang('plugin/keke_veeker', 'kkvklang84'), '', array(),array('showdialog' => true, 'closetime' => 2));
	}
	if($keke_veeker_zjts>$keke_veeker['zjts']){
		showmessage(lang('plugin/keke_veeker', 'kkvklang97').$keke_veeker['zjts'].lang('plugin/keke_veeker', 'kkvklang98'), '', array(),array('showdialog' => true, 'closetime' => 2));
	}
	$keke_veeker_zjdate=$keke_veeker_zjts*3600*24;
	if($keke_veeker_zj<0 || $keke_veeker_zjts<0){
		showmessage(lang('plugin/keke_veeker', 'kkvklang84'), '', array(),array('showdialog' => true, 'closetime' => 2));
	}
	$endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
	$time=$_G['timestamp'];
	if($time>$keke_veekerdata['deadline']){
		$setdeadline=$endToday+$keke_veeker_zjdate;
	}else{
		$setdeadline=$keke_veekerdata['deadline']+$keke_veeker_zjdate;
	}
	if($keke_veeker_zj>0 && !($keke_veekerdata['model']==2)){
		if($keke_veekerdata['model']==3){
			showmessage(lang('plugin/keke_veeker', 'kkvklang99'), '', array(),array('showdialog' => true, 'closetime' => 2));
		}
		$zjje=$keke_veeker_zj*$keke_veekerdata['price'];
		$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch($_G['groupid']);
		$sxf=($zjje*$tcfa['fb'])/100;
		$dja=$keke_veeker_zj*$keke_veekerdata['pa'];
		
		$sxfa=$keke_veeker['fjcc']?($dja*$tcfa['fb'])/100:0;
		$djb=$keke_veeker_zj*$keke_veekerdata['pb'];
		$sxfb=$keke_veeker['fjcc']?($djb*$tcfa['fb'])/100:0;
		if(($extcredits<($zjje+$sxf)) || $extcreditsa<$dja || (($extcreditsa<($dja+$sxfa)) && $keke_veeker['fjcc']) || $extcredits<$djb || (($extcreditsb<($djb+$sxfb)) && $keke_veeker['fjcc'])){
			showmessage(lang('plugin/keke_veeker', 'kkvklang100'), '', array(),array('showdialog' => true, 'closetime' => 2));
		}
		updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['jf'].''=>'-'.$zjje), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang101').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang102').$keke_veeker_zj.lang('plugin/keke_veeker', 'kkvklang103'));
		updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['jf'].''=>'-'.$sxf), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang101').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang102').$keke_veeker_zj.lang('plugin/keke_veeker', 'kkvklang104'));
		
		if($keke_veekerdata['pa']){
			if($keke_veeker['fjcc']){
				updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['pa'].''=>'-'.$sxfa), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang101').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang10'));
			}
			updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['pa'].''=>'-'.$dja), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang101').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang08'));
		}
		if($keke_veekerdata['pb']){
			if($keke_veeker['fjcc']){
				updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['pb'].''=>'-'.$sxfb), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang101').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang10'));
			}
			updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['pb'].''=>'-'.$djb), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang101').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang08'));
		}
	}
	C::t('#keke_veeker#keke_veeker')->update($tid, array('total' => $keke_veekerdata['total']+$keke_veeker_zj,'deadline'=>$setdeadline,));
}

function _aczhongbiao($tid,$keke_veekerdata){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$wkch=dhtmlspecialchars($keke_veeker['wkch']);
    if($_G['groupid']==1){
        $_G['uid']=_getauthorids($tid);
    }
	$membercount = C::t('common_member_count')->fetch($_G['uid']);					
	$extcredits=$membercount['extcredits'.$keke_veeker['jf']];
	$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
	$auid=intval($_GET['auid']);
	$buid=intval($_GET['buid']);
	$pid=intval($_GET['pid']);
	$page=intval($_GET['page']);
	$keke_veeker_zbtg=intval($_GET['keke_veeker_zbtg']);
	if($auid==$buid){
		showmessage(lang('plugin/keke_veeker', 'kkvklang105'),'');
	}
	$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch_by_auid($auid);
	$tcfa=$tcfa['fb'];
	$sxf=($keke_veeker_zbtg*$tcfa)/100;
	if($extcredits<($keke_veeker_zbtg+$sxf)){
		showmessage(lang('plugin/keke_veeker', 'kkvklang106').$extcredits.$creditname.lang('plugin/keke_veeker', 'kkvklang107'), '', array(),array('showdialog' => true, 'closetime' => 2));
	}
	$zbfs=C::t('#keke_veeker#keke_veeker_cn')->count_by_state_all($tid);
	if($keke_veekerdata['total']<=$zbfs[0]['coun']){
		showmessage(lang('plugin/keke_veeker', 'kkvklang158'), '', array(),array('showdialog' => true, 'closetime' => 2));
	}
	$arr = array( 'uid' => $buid,'tid' => $tid, 'pid' => $pid, 'dateline' => $_G['timestamp'], 'state'=>8, 'je'=>$keke_veeker_zbtg);
	$id=C::t('#keke_veeker#keke_veeker_cn')->insert($arr, true);
	//updatemembercount
	updatemembercount($auid, array('extcredits'.$keke_veeker['jf'].''=>'-'.$keke_veeker_zbtg), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang108'));
	updatemembercount($auid, array('extcredits'.$keke_veeker['jf'].''=>'-'.$sxf), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang109'));
}


function _aczhongbiaozj($tid){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
    if($_G['groupid']==1){
        $_G['uid']=_getauthorids($tid);
    }
	$membercount = C::t('common_member_count')->fetch($_G['uid']);					
	$extcredits=$membercount['extcredits'.$keke_veeker['jf']];
	$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
	$wkch=dhtmlspecialchars($keke_veeker['wkch']);
	$auid=intval($_GET['auid']);
	$keke_veeker_zjje=intval($_GET['keke_veeker_zjje']);
	$pid=intval($_GET['pid']);
	$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch_by_auid($auid);
	$tcfa=$tcfa['fb'];
	$sxf=($keke_veeker_zjje*$tcfa)/100;
	if($extcredits<($keke_veeker_zjje+$sxf)){
		showmessage(lang('plugin/keke_veeker', 'kkvklang106').$extcredits.$creditname.lang('plugin/keke_veeker', 'kkvklang107'), '', array(),array('showdialog' => true, 'closetime' => 2));
	}
	DB::query("update ".DB::table('keke_veeker_cn')." set je=(je+$keke_veeker_zjje) where pid=".$pid." AND tid=".$tid."");
	//updatemembercount
	updatemembercount($auid, array('extcredits'.$keke_veeker['jf'].''=>'-'.$keke_veeker_zjje), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang110'));
	updatemembercount($auid, array('extcredits'.$keke_veeker['jf'].''=>'-'.$sxf), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang111'));
}


function _acjj($tid,$pid){
	global $_G;
	$postdatas=C::t('forum_post')->fetch('tid:'.$tid,$pid);
	$auid=$postdatas['authorid'];
	$titlearr = array(
		'uid' => $auid,
		'tid' => $tid,
		'pid' => $pid,
		'dateline' => $_G['timestamp'],
		'state'=>2
	);
	$id = C::t('#keke_veeker#keke_veeker_cn')->insert($titlearr, true);
	notification_add($auid,'system',lang('plugin/keke_veeker', 'kkvklang117').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang122'));
	if(checkmobile()){
		exit(json_encode(array('state'=>0,'type'=>'jj','pid'=>$pid)));
	}else{
		showmessage(lang('plugin/keke_veeker', 'kkvklang123'),'', array(),array('showdialog' => true, 'closetime' => 2, 'extrajs' => '<script>doviews('.$pid.',2);</script>'));
	}
}

function _accaina($tid,$pid,$state){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$wkch=dhtmlspecialchars($keke_veeker['wkch']);
	$pbtis='';
	$vkdata=_getvkdatabytid($tid);
	$postdatas=C::t('forum_post')->fetch('tid:'.$tid,$pid);
	$auid=$postdatas['authorid'];
	$cnfs=C::t('#keke_veeker#keke_veeker_cn')->count_by_state($tid,1);
    $creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
    $creditnamea=$_G['setting']['extcredits'][$keke_veeker['pa']]['title'];
    $creditnameb=$_G['setting']['extcredits'][$keke_veeker['pb']]['title'];
	if($vkdata['model']==3){
		$xyfs=count(unserialize($vkdata['zduid']));
	}else{
		$xyfs=$vkdata['total'];
	}
	if($xyfs<=$cnfs){
		showmessage(lang('plugin/keke_veeker', 'kkvklang114').$cnfs.lang('plugin/keke_veeker', 'kkvklang115'), '', array(),array('showdialog' => true, 'closetime' => 2));
	}	
	if($state==2){
		C::t('#keke_veeker#keke_veeker_cn')->update($pid, array('state'=>1));
	}else{
        $checkState=_getstates($pid);
        if(!$checkState){
            $titlearr = array(
              'uid' => $auid,
              'tid' => $tid,
              'pid' => $pid,
              'dateline' => $_G['timestamp'],
              'je'=> $vkdata['price'],
              'state'=>1
            );
            C::t('#keke_veeker#keke_veeker_cn')->insert($titlearr, true);
            updatemembercount($auid, array('extcredits'.$keke_veeker['jf'].''=>$vkdata['price']), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang116'));
            if($vkdata['pa']){
                updatemembercount($auid, array('extcredits'.$keke_veeker['pa']=>$vkdata['pa']), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang116'));
                $pbtis.=' +'.$vkdata['pa'].$creditnamea;
            }
            if($vkdata['pb']){
                updatemembercount($auid, array('extcredits'.$keke_veeker['pb']=>$vkdata['pb']), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang116'));
                $pbtis.=' +'.$vkdata['pb'].$creditnameb;
            }
            notification_add($auid,'system',lang('plugin/keke_veeker', 'kkvklang117').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang118').$vkdata['price'].$creditname.$pbtis);
            //-----------------------------
            $tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch_by_auid($auid);
            if($tcfa['cj']){
                $sxf=($vkdata['price']*$tcfa['cj'])/100;
                updatemembercount($auid, array('extcredits'.$keke_veeker['jf'].''=>-$sxf), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang10'));
                if($keke_veeker['fjcc']){
                    $pasxf=$vkdata['pa']*$tcfa['cj']/100;
                    $pbsxf=$vkdata['pb']*$tcfa['cj']/100;
                    updatemembercount($auid, array('extcredits'.$keke_veeker['pa'].''=>-$pasxf), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang10'));
                    updatemembercount($auid, array('extcredits'.$keke_veeker['pb'].''=>-$pbsxf), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'._getsubjectss($tid).'</a>'.lang('plugin/keke_veeker', 'kkvklang10'));
                }
            }
        }else{
            showmessage(lang('plugin/keke_veeker', 'kkvklang119'),'', array(),array('showdialog' => true, 'closetime' => 2));
        }
    }
	if(checkmobile()){
		exit(json_encode(array('state'=>0,'type'=>'cn','pid'=>$pid)));
	}else{
		showmessage(lang('plugin/keke_veeker', 'kkvklang120'),'', array(),array('showdialog' => true, 'closetime' => 2, 'extrajs' => '<script>doviews('.$pid.',1);</script>'));
	}
}

function _achege($tid,$pid){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$wkch=dhtmlspecialchars($keke_veeker['wkch']);
	$md5file='keke_veeker.plugin';
	C::t('#keke_veeker#keke_veeker_cn')->update($pid, array('state'=>1));
	$keke_veeker_cn=C::t('#keke_veeker#keke_veeker_cn')->fetch_by_je_p($pid);
	if(!file_exists(DISCUZ_ROOT.'./data/addonmd5/'.$md5file.'.xml'))return;
	updatemembercount($keke_veeker_cn['authorid'], array('extcredits'.$keke_veeker['jf'].''=>$keke_veeker_cn['je']), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09')._getsubjectss($tid).lang('plugin/keke_veeker', 'kkvklang124'));
	notification_add($keke_veeker_cn['authorid'],'system',lang('plugin/keke_veeker', 'kkvklang117')._getsubjectss($tid).lang('plugin/keke_veeker', 'kkvklang125').$keke_veeker_cn['je'].$_G['setting']['extcredits'][$keke_veeker['jf']]['title'].lang('plugin/keke_veeker', 'kkvklang126'));
	$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch_by_auid($keke_veeker_cn['authorid']);
	$tcfa=$tcfa['cj'];
	if($tcfa){
		$sxf=($keke_veeker_cn['je']*$tcfa)/100;
		updatemembercount($keke_veeker_cn['authorid'], array('extcredits'.$keke_veeker['jf'].''=>-$sxf), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09')._getsubjectss($tid).lang('plugin/keke_veeker', 'kkvklang10'));
	}
	if(checkmobile()){
		exit(json_encode(array('state'=>0,'type'=>'hg','pid'=>$pid)));
	}else{
		showmessage(lang('plugin/keke_veeker', 'kkvklang129'),'', array(),array('showdialog' => true, 'closetime' => 2, 'extrajs' => '<script>doviews('.$pid.',1);</script>'));
	}
}

function _acbhg($pid){
	C::t('#keke_veeker#keke_veeker_cn')->update($pid, array('state'=>10));
	
	if(checkmobile()){
		exit(json_encode(array('state'=>0,'type'=>'bhg','pid'=>$pid)));
	}else{
		showmessage(lang('plugin/keke_veeker', 'kkvklang129'),'', array(),array('showdialog' => true, 'closetime' => 2, 'extrajs' => '<script>doviews('.$pid.',10);</script>'));
	}
}

function _acdelzhongbiao(){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$wkch=dhtmlspecialchars($keke_veeker['wkch']);
	$id=intval($_GET['cnid']);
	$keke_veeker_cn=C::t('#keke_veeker#keke_veeker_cn')->fetch_by_je($id);
	$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch_by_auid($keke_veeker_cn['authorid']);
	$tcfa=$tcfa['fb'];
	$sxf=($keke_veeker_cn['je']*$tcfa)/100;
	updatemembercount($keke_veeker_cn['authorid'], array('extcredits'.$keke_veeker['jf'].''=>$keke_veeker_cn['je']), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang127'));
	updatemembercount($keke_veeker_cn['authorid'], array('extcredits'.$keke_veeker['jf'].''=>$sxf), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang128'));
	DB::query("delete FROM ".DB::table('keke_veeker_cn')." WHERE id=".$id);
}

function _acwancheng($pid){
	global $_G;
	$authorid=DB::result_first("select authorid from ".DB::table('forum_post')." where pid=".$pid);
	if(!($_G['uid']==$authorid)){
		return;
	}
	C::t('#keke_veeker#keke_veeker_cn')->update($pid, array('state'=>9));
	if(checkmobile()){
		exit(json_encode(array('state'=>0,'type'=>'wc','pid'=>$pid)));
	}else{
		showmessage(lang('plugin/keke_veeker', 'kkvklang129'),'', array(),array('showdialog' => true, 'closetime' => 2, 'extrajs' => '<script>doviews('.$pid.',9);</script>'));
	}
}


function _acaddvk($tid){
	global $_G;
	$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
	$wkch=dhtmlspecialchars($keke_veeker['wkch']);
	$keke_vk_mode=intval($_GET['keke_vk_mode']);
	$total=intval($_GET['keke_vk_total']);
	$price=intval($_GET['keke_vk_price']);
	$pa=intval($_GET['pa']);
	$pb=intval($_GET['pb']);
	$keke_vk_everycount=intval($_GET['keke_vk_everycount']);
	$keke_vk_zd=daddslashes($_GET['keke_vk_zd']);
	$keke_vk_date=dhtmlspecialchars($_GET['keke_vk_date']);
	$keke_vk_date=strtotime($keke_vk_date);
	if($keke_vk_mode==1){
		$keke_vk_zd='';
	}elseif($keke_vk_mode==2){
		$price=intval($_GET['ysqj']);
	}elseif($keke_vk_mode==3){
		$zduid_arr=explode('+', daddslashes($_GET['keke_vk_zd']));//20180421
		$keke_vk_zd=serialize($zduid_arr);
        foreach ($zduid_arr as $vkUid) {
            notification_add($vkUid,'system',lang('plugin/keke_veeker', 'kkvklang227'),array(
                'title' =>  dhtmlspecialchars($_GET['subject']),
                'tid'   =>  $tid
            ), 1);
        }
		$total=count($zduid_arr);
	}
	$arr = array(
		'uid' => $_G['uid'],
		'tid'=> $tid,
		'total' => $total,
		'price' => $price,
		'pa'=> $pa,
		'pb'=> $pb,
		'model' => $keke_vk_mode,
		'zduid' => $keke_vk_zd,
		'everycount' => $keke_vk_everycount,
		'deadline' => $keke_vk_date,
		'workhide'=> intval($_GET['workhide'])
	);
	C::t('#keke_veeker#keke_veeker')->insert($arr, true);				
	if(!($keke_vk_mode==2)){
		$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch($_G['groupid']);
		$dj=$total*$price;
		$sxf=($dj*$tcfa['fb'])/100;
		updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['jf'].''=>'-'.$sxf), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.dhtmlspecialchars($_GET['subject']).'</a>'.lang('plugin/keke_veeker', 'kkvklang10'));
		updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['jf'].''=>'-'.$dj), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang07').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.dhtmlspecialchars($_GET['subject']).'</a>'.lang('plugin/keke_veeker', 'kkvklang08'));
		if($pa){
			$dja=$total*$pa;
			if($keke_veeker['fjcc'] && $tcfa['fb']){
				$sxfa=($dja*$tcfa['fb'])/100;
				updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['pa'].''=>'-'.$sxfa), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.dhtmlspecialchars($_GET['subject']).'</a>'.lang('plugin/keke_veeker', 'kkvklang10'));
			}
			updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['pa'].''=>'-'.$dja), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang07').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.dhtmlspecialchars($_GET['subject']).'</a>'.lang('plugin/keke_veeker', 'kkvklang08'));
		}
		if($pb){
			$djb=$total*$pb;
			if($keke_veeker['fjcc'] && $tcfa['fb']){
				$sxfb=($djb*$tcfa['fb'])/100;
				updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['pb'].''=>'-'.$sxfb), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang09').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.dhtmlspecialchars($_GET['subject']).'</a>'.lang('plugin/keke_veeker', 'kkvklang10'));
			}
			updatemembercount($_G['uid'], array('extcredits'.$keke_veeker['pb'].''=>'-'.$djb), true, '', 0, '',$wkch.lang('plugin/keke_veeker', 'kkvklang06'),lang('plugin/keke_veeker', 'kkvklang07').'<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.dhtmlspecialchars($_GET['subject']).'</a>'.lang('plugin/keke_veeker', 'kkvklang08'));
		}
	}
}

function _getzjlist($tid){
	$zj=C::t('#keke_veeker#keke_veeker_bc')->fetch_by_id($tid);
	foreach($zj as $value) {
		$value['date'] = dgmdate($value['date']);
		$value['text'] = dhtmlspecialchars($value['text']);
        $value['username'] = _getusernames($value['uid']);
		$zjlist[] = $value;
	}
	return $zjlist;
}


function _getstates($pid){
	return C::t('#keke_veeker#keke_veeker_cn')->fetch_by_state($pid);
}

function _getvkdatabytid($tid){
	return C::t('#keke_veeker#keke_veeker')->fetchfirst_by_tid($tid);
}

function _getcndata($tid){
	return C::t('#keke_veeker#keke_veeker_cn')->count_by_state_all($tid);
}

function _gettthreaddata($tid){
	return $threaddata=C::t('forum_thread')->fetch($tid);
}

function _getsubjectss($tid){
	$threaddata=_gettthreaddata($tid);
	return $threaddata['subject'];
}

function _getauthorids($tid){
	$threaddata=_gettthreaddata($tid);
	return $threaddata['authorid'];
}

function vkutf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return vkgbk2utf($data);
	}
}
function vkgbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}

function _getfballcredit($credit){
	global $_G;
	$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch($_G['groupid']);
	$sxf=($credit*$tcfa['fb'])/100;
	return $credit+$sxf;
}

//20190723
function _getindexsqls(){
    global $_G;
    $incsql='';
    $m=intval($_GET['m']);
    if($m){
        $incsql.=" AND v.model=".$m;
    }
    $sta=intval($_GET['sta']);
    if($sta==1){
        $incsql.=" AND v.state=1 AND v.deadline>".$_G['timestamp']."";
    }elseif($sta==2 || $sta==4){
        $incsql.=" AND v.state=".$sta;
    }elseif($sta==6){
        $incsql.=" AND v.deadline<".$_G['timestamp'];
    }
    $f=intval($_GET['f']);
    if($f){
        $incsql.=" AND t.fid=".$f."";
    }
    $types=intval($_GET['type']);
    if($types){
        $incsql.=" AND t.typeid=".$types."";
    }
    if($_GET['key']) {
        $incsql .= " AND t.subject LIKE '%".addcslashes($_GET['key'],'%_')."%'";
    }
    return $incsql;
}
