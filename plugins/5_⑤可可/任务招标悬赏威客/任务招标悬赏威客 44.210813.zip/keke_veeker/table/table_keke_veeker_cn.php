<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_veeker_cn extends discuz_table
{
	public function __construct() {
		$this->_table = 'keke_veeker_cn';
		$this->_pk = 'pid';
		parent::__construct(); /*dism_ taobao_ com*/
	}
	
	public function count_by_state($tid,$state) {
		return DB::result_first('SELECT COUNT(*) FROM %t where tid=%d AND state=%d', array($this->_table,$tid,$state));
	}

	public function count_by_state_all($tid) {
		return DB::fetch_all("SELECT tid,sum(case state when '1' then 1 else 0 end) as sta,sum(case state when '2' then 1 else 0 end) as stb,count(1) as coun,SUM(je) as je,sum(case when  state<>1 then 1 else 0 end) as stc FROM %t WHERE tid IN ($tid) group by tid", array($this->_table,$tid));
	}
	
	public function count_by_uid($uid) {
		return DB::result_first('SELECT COUNT(*) FROM %t where uid=%d', array($this->_table,$uid));
	}
	
	public function fetch_by_je_p($pid) {
		return DB::fetch_first('select a.je,b.authorid from %t a,%t b where b.pid=%d AND b.pid=a.pid', array($this->_table,'forum_post',$pid));
	}
	
	public function fetch_by_dateline($tid) {
		return DB::result_first('select dateline from %t where tid=%d order by dateline desc', array($this->_table,$tid));
	}
	public function fetch_by_state($pid) {
		return DB::result_first('select state from %t where pid=%d', array($this->_table,$pid));
	}
	public function fetch_by_je($id) {
		return DB::fetch_first('select a.je,b.authorid from %t a,%t b where a.id=%d AND b.tid=a.tid', array($this->_table,'forum_thread',$id));
	}
	
	public function countall_by_state($tids,$state) {
		return DB::fetch_all('SELECT COUNT(*) as count,tid FROM %t where tid in (%n) AND state in (%n) group by tid', array($this->_table,$tids,$state),'tid');
	}
	
	public function count_by_replies($tids) {
		return DB::fetch_all('SELECT replies,tid FROM %t where tid in (%n)', array('forum_thread',$tids),'tid');
	}
	
	
	
	
}
//From: dis'.'m.tao'.'bao.com
?>