<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$table = array();
    showtableheader(lang('plugin/keke_veeker', 'kkvklang161'));	
    showsubtitle(array(lang('plugin/keke_veeker', 'kkvklang162'), lang('plugin/keke_veeker', 'kkvklang163'), lang('plugin/keke_veeker', 'kkvklang164')));
	$wap=file_exists("source/plugin/keke_veeker/assembly/mobile.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_veeker', 'kkvklang166').'</span>' : '<span class="error">'.lang('plugin/keke_veeker', 'kkvklang187').'</span><a href="https://addon.dismall.com/?@keke_veeker.plugin.65899"><span class="diffcolor3">'.lang('plugin/keke_veeker', 'kkvklang167').'</span></a>';		
	$table[0] = lang('plugin/keke_veeker', 'kkvklang165');
	$table[1] = '<span class="light">'.lang('plugin/keke_veeker', 'kkvklang168').'</span>';
	$table[2] = $wap;
	showtablerow('', array('width="180"', 'width="480"'), $table);	
	
	$hide=file_exists("source/plugin/keke_veeker/assembly/bidhide.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_veeker', 'kkvklang166').'</span>' : '<span class="error">'.lang('plugin/keke_veeker', 'kkvklang187').'</span><a href="https://addon.dismall.com/?@keke_veeker.plugin.65900"><span class="diffcolor3">'.lang('plugin/keke_veeker', 'kkvklang167').'</span></a>';		
	$table[0] = lang('plugin/keke_veeker', 'kkvklang169');
	$table[1] = '<span class="light">'.lang('plugin/keke_veeker', 'kkvklang170').'</span>';
	$table[2] = $hide;
	showtablerow('','', $table);	
	
	$hides=file_exists("source/plugin/keke_veeker/assembly/workhide.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_veeker', 'kkvklang166').'</span>' : '<span class="error">'.lang('plugin/keke_veeker', 'kkvklang187').'</span><a href="https://addon.dismall.com/?@keke_veeker.plugin.65902"><span class="diffcolor3">'.lang('plugin/keke_veeker', 'kkvklang167').'</span></a>';		
	$table[0] =lang('plugin/keke_veeker', 'kkvklang171');
	$table[1] = '<span class="light">'.lang('plugin/keke_veeker', 'kkvklang172').'</span>';
	$table[2] = $hides;
	showtablerow('','', $table);	
	
	
	showtableheader(lang('plugin/keke_veeker', 'kkvklang182'));	
    showsubtitle(array(lang('plugin/keke_veeker', 'kkvklang162'), lang('plugin/keke_veeker', 'kkvklang163'), lang('plugin/keke_veeker', 'kkvklang164')));
	$wap=file_exists("source/plugin/keke_chongzhi/keke_chongzhi.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_veeker', 'kkvklang166').'</span>' : '<span class="error">'.lang('plugin/keke_veeker', 'kkvklang187').'</span><a href="https://addon.dismall.com/?@keke_chongzhi.plugin"><span class="diffcolor3">'.lang('plugin/keke_veeker', 'kkvklang167').'</span></a>';		
	$table[0] = lang('plugin/keke_veeker', 'kkvklang183');
	$table[1] = '<span class="light">'.lang('plugin/keke_veeker', 'kkvklang184').'</span>';
	$table[2] = $wap;
	showtablerow('', array('width="180"', 'width="480"'), $table);	
	
	$hide=file_exists("source/plugin/keke_tixian/keke_tixian.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_veeker', 'kkvklang166').'</span>' : '<span class="error">'.lang('plugin/keke_veeker', 'kkvklang187').'</span><a href="https://addon.dismall.com/?@keke_tixian.plugin"><span class="diffcolor3">'.lang('plugin/keke_veeker', 'kkvklang167').'</span></a>';		
	$table[0] = lang('plugin/keke_veeker', 'kkvklang185');
	$table[1] = '<span class="light">'.lang('plugin/keke_veeker', 'kkvklang186').'</span>';
	$table[2] = $hide;
	showtablerow('','', $table);
	
	
	$hide=file_exists("source/class/block/veeker/block_veeker.php")? '<span class="diffcolor2">'.lang('plugin/keke_veeker', 'kkvklang166').'</span>' : '<span class="error">'.lang('plugin/keke_veeker', 'kkvklang187').'</span><a href="https://addon.dismall.com/packs/keke_veekerdiy.html"><span class="diffcolor3">'.lang('plugin/keke_veeker', 'kkvklang167').'</span></a>';		
	$table[0] = lang('plugin/keke_veeker', 'kkvklang221');
	$table[1] = '<span class="light">'.lang('plugin/keke_veeker', 'kkvklang222').'</span>';
	$table[2] = $hide;
	showtablerow('','', $table);
	
	
	$hide=file_exists("source/plugin/keke_help/keke_help.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_veeker', 'kkvklang166').'</span>' : '<span class="error">'.lang('plugin/keke_veeker', 'kkvklang187').'</span><a href="https://addon.dismall.com/?@keke_help.plugin"><span class="diffcolor3">'.lang('plugin/keke_veeker', 'kkvklang167').'</span></a>';		
	$table[0] = lang('plugin/keke_veeker', 'kkvklang223');
	$table[1] = '<span class="light">'.lang('plugin/keke_veeker', 'kkvklang224').'</span>';
	$table[2] = $hide;
	showtablerow('','', $table);
		
	
	
    showtablefooter(); /*dism��taobao��com*/
