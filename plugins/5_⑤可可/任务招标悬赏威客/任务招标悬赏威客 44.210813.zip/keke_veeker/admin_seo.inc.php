<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


	if (submitcheck("forumset")) {
		$data = serialize(daddslashes($_POST['form']));
		require_once libfile('function/cache');
		savecache('keke_veeker', $data);
		cpmsg(lang('plugin/keke_veeker', 'kkvklang112'), 'action=plugins&operation=config&identifier=keke_veeker&pmod=admin_seo', 'succeed');
	}
	
    showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=".$plugin["identifier"]."&pmod=admin_seo");
   		showtableheader(lang('plugin/keke_veeker', 'kkvklang181'));	
		loadcache('keke_veeker');
		$info=$_G['cache']['keke_veeker'];	
		$info=unserialize($info);
		$table = array();
        $table[0] = lang('plugin/keke_veeker', 'kkvklang154');
        $table[1] = '<input type="text" name="form[title][message]" value="'.dhtmlspecialchars($info['title']['message']).'" style="width:400px;" /> ';
        showtablerow('', array('width="100"', 'width="660"'), $table);
		$table[0] = lang('plugin/keke_veeker', 'kkvklang156');
        $table[1] = '<input type="text" name="form[keywords][message]" value="'.dhtmlspecialchars($info['keywords']['message']).'" style="width:400px;" />';
        showtablerow('', '', $table);
		$table[0] = lang('plugin/keke_veeker', 'kkvklang157');
        $table[1] = '<textarea style="width:400px;" name="form[description][message]" rows="5">'.dhtmlspecialchars($info['description']['message']).'</textarea>';
        showtablerow('', '', $table);
		
		
		showtableheader(lang('plugin/keke_veeker', 'kkvklang155'));	
		loadcache('keke_veeker');
		$info=$_G['cache']['keke_veeker'];	
		$info=unserialize($info);
		$table = array();
      
		$table[0] = lang('plugin/keke_veeker', 'kkvklang154');
        $table[1] = '<input type="text" name="form[waptitle][message]" value="'.dhtmlspecialchars($info['waptitle']['message']).'" style="width:400px;" />';
         showtablerow('', array('width="100"', 'width="660"'), $table);
		$table[0] = lang('plugin/keke_veeker', 'kkvklang156');
        $table[1] = '<input type="text" name="form[wapkeywords][message]" value="'.dhtmlspecialchars($info['wapkeywords']['message']).'" style="width:400px;" />';
        showtablerow('', '', $table);
		$table[0] = lang('plugin/keke_veeker', 'kkvklang157');
        $table[1] = '<textarea style="width:400px;" name="form[wapdescription][message]" rows="5">'.dhtmlspecialchars($info['wapdescription']['message']).'</textarea>';
        showtablerow('', '', $table);
		
		
	showsubmit('forumset', 'submit', '', '');    
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
