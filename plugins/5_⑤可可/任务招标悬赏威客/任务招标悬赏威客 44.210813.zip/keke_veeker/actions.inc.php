<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
require_once DISCUZ_ROOT.'./source/plugin/keke_veeker/function/fun.php';
$wkch=dhtmlspecialchars($keke_veeker['wkch']);
$gzch=dhtmlspecialchars($keke_veeker['gzch']);
$tid=intval($_GET['tid']);
$pid=intval($_GET['pid']);
$auid=intval($_GET['auid']);
$page=intval($_GET['page']);
$ac=$_GET['ac'];
if($_GET['formhash']!=FORMHASH)return;
if(!$_G['uid']){
    showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
$creditnamea=$_G['setting']['extcredits'][$keke_veeker['pa']]['title'];
$creditnameb=$_G['setting']['extcredits'][$keke_veeker['pb']]['title'];
/*  state=1 caina   state=2 jujue */
if(submitcheck('vkjubao')){
	_insertjb($tid);
}
$state=_getstates($pid);
$pag=$page?'&page='.$page:'';
$fhurl='forum.php?mod=viewthread&tid='.$tid.$pag.'#pid'.$pid;
if($ac=="cn" && ($_G['uid']==_getauthorids($tid) || $_G['groupid']==$keke_veeker['sup'])){
	_accaina($tid,$pid,$state);
}elseif($ac=="jj"  && ($_G['uid']==_getauthorids($tid) || $_G['groupid']==$keke_veeker['sup'])){
	if($state==1 || $state==2){
		showmessage(lang('plugin/keke_veeker', 'kkvklang121'), '', array(),array('showdialog' => true, 'closetime' => 2));
	}
	_acjj($tid,$pid);
}elseif($ac=="wc"){	
	//20160707 
	_acwancheng($pid);
}elseif($ac=="hg" && ($_G['uid']==_getauthorids($tid) || $_G['groupid']==$keke_veeker['sup'])){
	_achege($tid,$pid);
}elseif($ac=="bhg"  && ($_G['uid']==_getauthorids($tid) || $_G['groupid']==$keke_veeker['sup'])){
	_acbhg($pid);
}elseif($ac=="delzb"  && $_G['groupid']==$keke_veeker['sup']){
	_acdelzhongbiao();
	header("Location: forum.php?mod=viewthread&tid=".$tid); 
	exit();
}elseif($ac=="90"){
	$type=$_GET['type'];
	if($_GET['vkbk']){
		$vkbk=intval($_GET['vkbk']);
	}
	if($_GET['vkname']){
		$vkname=vkutf2gbk($_GET['vkname']);
	}
	if($_GET['vktime1']){
		$timea=strtotime($_GET['vktime1']);	
	}
	if($_GET['vktime2']){
		$timeb=strtotime($_GET['vktime2']);	
	}
	$rwlist=_getrwlist($type,$vkbk,$vkname,$timea,$timeb);
	echo $rwlist;
	exit();
}elseif($ac=='getzblist'){
	$zblists=_getzblists(intval($_GET['tid']));
	include template('keke_veeker:show');
	include template('common/header_ajax');
	echo $zblist;
	include template('common/footer_ajax');
	exit();
}elseif($ac=='delms'){
    if($_G['groupid']==1){
        $msid=intval($_GET['msid']);
        C::t('#keke_veeker#keke_veeker_bc')->delete($msid);
        exit(json_encode(array('state'=>1)));
    }else{
        exit(json_encode(array('state'=>0,'msg'=>vkgbk2utf(lang('plugin/keke_veeker', 'kkvklang225')))));
    }
}
showmessage(lang('plugin/keke_veeker', 'kkvklang129'),$fhurl);