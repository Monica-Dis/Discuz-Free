<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$keke_veeker = $_G['cache']['plugin']['keke_veeker'];
$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
$creditnamea=$_G['setting']['extcredits'][$keke_veeker['pa']]['title'];
$creditnameb=$_G['setting']['extcredits'][$keke_veeker['pb']]['title'];

$wkch=dhtmlspecialchars($keke_veeker['wkch']);
$gzch=dhtmlspecialchars($keke_veeker['gzch']);
$membercount = C::t('common_member_count')->fetch($_G['uid']);					
$extcredits=$membercount['extcredits'.$keke_veeker['jf']];
$extcreditsa=$membercount['extcredits'.$keke_veeker['pa']];
$extcreditsb=$membercount['extcredits'.$keke_veeker['pb']];
$ac=$_GET['ac'];

	if($ac=="vkcheck" && $_GET['tlx']){
		if($_GET['formhash']!=FORMHASH)return;
		$keke_vk_mode=intval($_GET['keke_vk_mode']);
		$keke_vk_total=intval($_GET['keke_vk_total']);
		$keke_vk_zd=dhtmlspecialchars($_GET['keke_vk_zd']);
		$keke_vk_price=intval($_GET['keke_vk_price']);
		$keke_vk_date=dhtmlspecialchars($_GET['keke_vk_date']);
		$result="success";
		$pa=intval($_GET['pa']);
		$pb=intval($_GET['pb']);
		
		if($keke_vk_date=='')$result=lang('plugin/keke_veeker', 'kkvklang80');
		
		$keke_vk_date=strtotime($keke_vk_date);
		if($keke_vk_date<$_G['timestamp'])$result=lang('plugin/keke_veeker', 'kkvklang152');
		if($keke_vk_mode==1){
			
			if($keke_vk_price=="")$result=lang('plugin/keke_veeker', 'kkvklang81').$creditname.lang('plugin/keke_veeker', 'kkvklang82');
			if($keke_vk_total=="")$result=lang('plugin/keke_veeker', 'kkvklang83');
			if($keke_vk_total<0 || $keke_vk_price<0)$result=lang('plugin/keke_veeker', 'kkvklang84');
			if($keke_vk_price<$keke_veeker['zddj'])$result=lang('plugin/keke_veeker', 'kkvklang85').$keke_veeker['zddj'].$creditname;
			
			if($pa>0 && ($pa<$keke_veeker['pazd']))$result=lang('plugin/keke_veeker', 'kkvklang85').$keke_veeker['pazd'].$creditnamea;
			if($pb>0 && ($pb<$keke_veeker['pbzd']))$result=lang('plugin/keke_veeker', 'kkvklang85').$keke_veeker['pbzd'].$creditnameb;
			$all=$keke_vk_total*$keke_vk_price;
			$alla=$keke_vk_total*$pa;
			$allb=$keke_vk_total*$pb;
			
			if($allb>$extcreditsb){$result=lang('plugin/keke_veeker', 'kkvklang106').$extcreditsb.$creditnameb.lang('plugin/keke_veeker', 'kkvklang107');}
			if($alla>$extcreditsa){$result=lang('plugin/keke_veeker', 'kkvklang106').$extcreditsa.$creditnamea.lang('plugin/keke_veeker', 'kkvklang107');}
			if($all>$extcredits){$result=lang('plugin/keke_veeker', 'kkvklang106').$extcredits.$creditname.lang('plugin/keke_veeker', 'kkvklang107');}
			
			
		}elseif($keke_vk_mode==2){
			if($keke_vk_total<=0)$result=lang('plugin/keke_veeker', 'kkvklang173');
		}elseif($keke_vk_mode==3){
			$zd =explode('+', $keke_vk_zd);
			foreach($zd as $val){
				$memberdata=C::t('common_member')->fetch($val);
				if(!$memberdata)$result=lang('plugin/keke_veeker', 'kkvklang159');
			}
			if($keke_vk_price=="")$result=lang('plugin/keke_veeker', 'kkvklang87').$creditname.lang('plugin/keke_veeker', 'kkvklang88');
			if($keke_vk_zd=="")$result=lang('plugin/keke_veeker', 'kkvklang89').$wkch."UID";
			$all=count($zd)*$keke_vk_price;
			if($all>$extcredits){$result=lang('plugin/keke_veeker', 'kkvklang90');}
		}
		echo $result;
	}
echo "success";