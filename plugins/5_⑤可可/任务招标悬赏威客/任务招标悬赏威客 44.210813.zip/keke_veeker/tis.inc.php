<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_veeker = $_G['cache']['plugin']['keke_veeker'];	
require_once DISCUZ_ROOT.'./source/plugin/keke_veeker/function/fun.php';	
$tid=intval($_GET['tid']);
$ac=intval($_GET['ac']);
$auid=intval($_GET['auid']);
$buid=intval($_GET['buid']);
$pid=intval($_GET['pid']);
$page=intval($_GET['page']);
$membercount = C::t('common_member_count')->fetch($_G['uid']);					
$extcredits=$membercount['extcredits'.$keke_veeker['jf']];
$creditname=$_G['setting']['extcredits'][$keke_veeker['jf']]['title'];
$_Info['Url'] = '{ADDONVAR:SiteUrl}';
$wkch=dhtmlspecialchars($keke_veeker['wkch']);
$gzch=dhtmlspecialchars($keke_veeker['gzch']);
$kefu=dhtmlspecialchars($keke_veeker['kefu']);
$tcfa=C::t('#keke_veeker#keke_veeker_tc')->fetch_by_auid($_G['uid']);
$_Info['sid']='{ADDONVAR:SiteID}';
$keke_veeker_data=_getvkdatabytid($tid);
$tcfa=$tcfa['fb'];
if($ac==22){echo $_Info['Url'].'|'.$_Info['sid'];}
if(!($keke_veeker_data['uid']==$_G['uid']) && !$ac==6)return;
if($_GET['formhash']!=FORMHASH)return;
/*  sata=1 going  sata=2 Stop  sata=4 DONE  */
if($ac==3 || $ac==4 || $ac==5){
	if(!$_G['uid']){
		showmessage('not_loggedin', NULL, array(), array('login' => 1));
	}
	if($ac==3){$sata=2;}elseif($ac==4){$sata=1;}elseif($ac==5){$sata=4;$donetime=" ,donetime=".$_G['timestamp']."";}
	$state=$keke_veeker_data['state'];
	if($state==4){
		showmessage(lang('plugin/keke_veeker', 'kkvklang91'),'forum.php?mod=viewthread&tid='.$tid);
	}
	if($ac==5){
		_acqingsuan($tid,$keke_veeker_data);
	}
	if($ac==3 || $ac==4){
		$vkarr=array('state' => $sata);
	}else{
		$vkarr=array('state' => $sata,'donetime' => $_G['timestamp']);
	}
	C::t('#keke_veeker#keke_veeker')->update($tid, $vkarr);
	header("Location: forum.php?mod=viewthread&tid=".$tid); 
	exit;
}elseif($ac==10){
	$flist=_getvkforumarr();
}
if(submitcheck('sub')){
	$ac=intval($_GET['ac']);
	$tid=intval($_GET['tid']);
	$time=$_G['timestamp'];
	$keke_veekerdata=$keke_veeker_data;	
	//20160707
	if(!($keke_veeker_data['uid']==$_G['uid']) && $_G['groupid']!=1){
		return;
	}
	if($ac==2){
		_insertbc($tid);
	}elseif($ac==1){
		_aczuijia($tid,$keke_veekerdata);
	}elseif($ac==8){
		_aczhongbiao($tid,$keke_veekerdata);
	}elseif($ac==9){
		_aczhongbiaozj($tid);
	}
	$funname=($ac==8)?'doviews':'hiedwin';
	if(checkmobile()){
		showmessage(lang('plugin/keke_veeker', 'kkvklang112'), 'forum.php?mod=viewthread&tid='.$tid);
	}else{
		showmessage(lang('plugin/keke_veeker', 'kkvklang112'), '', array(),array('showdialog' => true, 'closetime' => 2, 'extrajs' => '<script>'.$funname.'('.$pid.','.$ac.');</script>'));
	}
}

$_G['mobiletpl'][IN_MOBILE]='/';
include template('keke_veeker:tis');