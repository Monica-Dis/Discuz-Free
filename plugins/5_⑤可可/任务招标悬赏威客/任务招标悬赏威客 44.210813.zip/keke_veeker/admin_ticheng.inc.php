<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	if (submitcheck("forumset")) {
		$group_fb =daddslashes($_GET['group_fb']);
		$group_cj =daddslashes($_GET['group_cj']);
		foreach($group_fb as $gid => $val) {
		  $fb= intval($group_fb[$gid]);
		  $cj= intval($group_cj[$gid]);
		  if(DB::result_first("select count(1) from ".DB::table('keke_veeker_tc')." where gid=".$gid)){
			  DB::query("update ".DB::table('keke_veeker_tc')." set fb=$fb,cj=$cj where gid=".$gid);
		  }else{
			  DB::query("insert into ".DB::table('keke_veeker_tc')." (gid , fb , cj) values ('".$gid."' , '".$fb."' , '".$cj."')");}				
		}	  
	  cpmsg(lang('plugin/keke_veeker', 'kkvklang112'), 'action=plugins&operation=config&identifier=keke_veeker&pmod=admin_ticheng', 'succeed');
	}
	$addonid = 'keke_veeker.plugin';
	showtips(lang('plugin/keke_veeker', 'kkvklang180'));
    showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=".$plugin["identifier"]."&pmod=admin_ticheng");
    showtableheader(lang('plugin/keke_veeker', 'kkvklang137'));	
    showsubtitle(array(lang('plugin/keke_veeker', 'kkvklang147'), lang('plugin/keke_veeker', 'kkvklang148'), lang('plugin/keke_veeker', 'kkvklang149')));
	$query = DB::query("SELECT groupid,grouptitle FROM ".DB::table('common_usergroup'));
	while($group = DB::fetch($query)) {
		$table = array();
		$gdata=DB::fetch_first("select fb,cj from ".DB::table('keke_veeker_tc')." where gid=".$group['groupid']);
        $table[0] = $group['grouptitle'].'<span class="lightfont"> (gid:'.$group['groupid'].') </span>';
        $table[1] = '<input type="text" name="group_fb['.$group['groupid'].']" value="'.$gdata['fb'].'" size="15" /> %';
        $table[2] = '<input type="text" name="group_cj['.$group['groupid'].']" value="'.$gdata['cj'].'" size="15" /> %';
        showtablerow('', '', $table);
		}
	showsubmit('forumset', 'submit', '', '');    
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
