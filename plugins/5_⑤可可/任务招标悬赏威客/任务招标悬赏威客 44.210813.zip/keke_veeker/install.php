<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
$keke_veeker= DB::table("keke_veeker");
$keke_veeker_bc= DB::table("keke_veeker_bc");
$keke_veeker_cn= DB::table("keke_veeker_cn");
$keke_veeker_tid= DB::table("keke_veeker_tid");
$keke_veeker_tc= DB::table("keke_veeker_tc");
$keke_veeker_jb= DB::table("keke_veeker_jb");

$sql = <<<EOF
CREATE TABLE `$keke_veeker` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `tid` int(10) NOT NULL,
  `total` int(10) NOT NULL,
  `price` int(10) NOT NULL,
  `everycount` int(10) NOT NULL,
  `model` int(5) NOT NULL,
  `zduid` mediumtext NOT NULL,
  `deadline` int(10) NOT NULL,
  `donetime` int(10) NOT NULL,
  `state` int(10) NOT NULL default '1',
  `workhide` int(10) NOT NULL,
  `pa` int(10) NOT NULL,
  `pb` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_veeker_bc` (
  `id` int(11) NOT NULL auto_increment,
  `tid` int(10) NOT NULL,
  `text` varchar(100) NOT NULL default '0',
  `uid` int(10) NOT NULL,
  `date` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_veeker_cn` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `tid` int(10) NOT NULL,
  `pid` int(10) unsigned NOT NULL default '0',
  `dateline` int(10) NOT NULL,
  `state` int(10) NOT NULL default '1',
  `je` int(255) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_veeker_tid` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(50) NOT NULL,
  `tid` int(10) NOT NULL,
  `uid` int(10) unsigned NOT NULL default '0',
  `fid` int(10) NOT NULL,
  `ida` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_veeker_tc` (
  `id` int(10) NOT NULL auto_increment,
  `gid` int(10) NOT NULL,
  `fb` int(10) NOT NULL,
  `cj` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_veeker_jb` (
  `id` int(11) NOT NULL auto_increment,
  `tid` int(10) NOT NULL,
  `cate` int(10) NOT NULL,
  `text` varchar(100) NOT NULL default '0',
  `uid` int(10) NOT NULL,
  `date` int(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_veeker/discuz_plugin_keke_veeker.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_veeker/discuz_plugin_keke_veeker_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_veeker/discuz_plugin_keke_veeker_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_veeker/discuz_plugin_keke_veeker_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_veeker/discuz_plugin_keke_veeker_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_veeker/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_veeker/upgrade.php');