<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	loadcache(array('pluginlanguage_template', 'pluginlanguage_script'));
	if($_GET['ac'] == 'edit') {
		$plugin = dhtmlspecialchars($_GET['plugin']);
		if(submitcheck('editlangsubmit')) {
			$_G['cache']['pluginlanguage_'.$_GET['type']][$plugin] = editor_replacess($_GET['lang']);
			savecache('pluginlanguage_'.$_GET['type'], $_G['cache']['pluginlanguage_'.$_GET['type']]);
			$xmltyp=array('SC_GBK','SC_UTF8','TC_BIG5','TC_UTF8');
			foreach($xmltyp as $xmlval){
				@copy(DISCUZ_ROOT.'./source/plugin/'.$plugin.'/discuz_plugin_'.$plugin.'_'.$xmlval.'.xml', DISCUZ_ROOT.'./source/plugin/keke_editlang/xmlbak/discuz_plugin_'.$plugin.'_'.$xmlval.'.xml');
				@unlink(DISCUZ_ROOT.'./source/plugin/'.$plugin.'/discuz_plugin_'.$plugin.'_'.$xmlval.'.xml');
			}
			updatecache(array('plugin'));
			cleartemplatecache();
			cpmsg(lang('plugin/keke_editlang', 'f08'), 'action=plugins&operation=config&identifier=keke_editlang&pmod=keke_lang_admin&ac=edit&plugin='.$plugin.'&type='.$_GET['type'], 'succeed');
		}
		showformheader('plugins&operation=config&identifier=keke_editlang&pmod=keke_lang_admin&ac=edit&plugin='.$plugin.'&type='.$_GET['type']);
		showtableheader();
		foreach($_G['cache']['pluginlanguage_'.$_GET['type']][$plugin] as $key => $value) {
			showsetting($key, '', '', '<textarea rows="3" name="lang['.$key.']" id="lang['.$key.']" cols="50">'.$value.'</textarea>');
		}
		showsubmit('editlangsubmit', 'submit');
		showtablefooter();
		showformfooter();/*Dism��taobao��com*/
	}else{
			$plulist=DB::fetch_all("select identifier,name from ".DB::table('common_plugin')."");
			showformheader('plugins&operation=config&identifier=keke_editlang&pmod=admincp_plugin');
			showtableheader(lang('plugin/keke_editlang', 'f01'));
			showsubtitle(array(lang('plugin/keke_editlang', 'f02'), lang('plugin/keke_editlang', 'f03'), lang('plugin/keke_editlang', 'f05')));
			foreach($plulist as $value) {
				showtablerow('', array(''), array(
					$value['name'],
					$value['identifier'],
					'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_editlang&pmod=keke_lang_admin&ac=edit&plugin='.$value['identifier'].'&type=template">'.lang('plugin/keke_editlang', 'f06').'</a>&nbsp;|&nbsp;
					 <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_editlang&pmod=keke_lang_admin&ac=edit&plugin='.$value['identifier'].'&type=script">'.lang('plugin/keke_editlang', 'f07').'</a>'
				));
			}
			showtablefooter();
			showformfooter();/*Dism��taobao��com*/
	}
	
	function editor_replacess($content){
		$tags = array(
			"'<iframe[^>]*?>.*?</iframe>'is",
			"'<frame[^>]*?>.*?</frame>'is",
			"'<script[^>]*?>.*?</script>'is",
			"'<head[^>]*?>.*?</head>'is",
			"'<title[^>]*?>.*?</title>'is",
			"'<meta[^>]*?>'is",
			"'<link[^>]*?>'is",
		);
		return preg_replace($tags, "", $content);
	}