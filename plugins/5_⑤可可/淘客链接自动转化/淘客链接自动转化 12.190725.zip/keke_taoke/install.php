<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-09-01
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_taoke/discuz_plugin_keke_taoke.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_taoke/discuz_plugin_keke_taoke_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_taoke/discuz_plugin_keke_taoke_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_taoke/discuz_plugin_keke_taoke_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_taoke/discuz_plugin_keke_taoke_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_taoke/install.php');
?>