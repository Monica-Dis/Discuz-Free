<?php
 /*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-09-01,10:51:44
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
  exit('Access Denied');
}
class plugin_keke_taoke{
	public function __construct(){
		global $_G;
		$var = $_G['cache']['plugin']['keke_taoke'];
		$this->perform=1;
		$this->section = empty($var['bk']) ? array() : unserialize($var['bk']);
		if(!(empty($this->section[0]) || in_array($_G['fid'],$this->section))){
			$this->perform=0;
		}
		if(CURSCRIPT=='forum'){
			$this->moda=2;
		}elseif(CURSCRIPT=='portal'){
			$this->moda=1;
		}
		$this->off=0;
		if(($this->moda==2 && ((!$_G['thread']['isgroup'] && $this->perform)||($_G['thread']['isgroup'] && $var['qz']))) || ($this->moda==1 && $var['mh'])){
			$this->off=1;
		}
		
	}
	public function global_header(){
		global $_G,$postlist;
		$var = $_G['cache']['plugin']['keke_taoke'];
		if($this->off){
			$var['pid']=dhtmlspecialchars($var['pid']);
			include template('keke_taoke:inc');
		}
		return $return;
	}


	public function global_footer(){
		global $_G;	
		$var = $_G['cache']['plugin']['keke_taoke'];
		if($this->off){
			if($_G['mobile']) {
				if($var['wapsize']==2){$s='350x100';$tpid='6';
				}elseif($var['wapsize']==3){$s='290x380';$tpid='5';
				}elseif($var['wapsize']==4){$s='230x312';$tpid='4';
				}elseif($var['wapsize']==5){$s='470x190';$tpid='635';
				}elseif($var['wapsize']==7){$s='230x45';$tpid='225';
				}
			}else{
				if($var['size']==1){$s='628x100';$tpid='7';
				}elseif($var['size']==2){$s='350x100';$tpid='6';
				}elseif($var['size']==3){$s='290x380';$tpid='5';
				}elseif($var['size']==4){$s='230x312';$tpid='4';
				}elseif($var['size']==5){$s='470x190';$tpid='635';
				}elseif($var['size']==6){$s='600x25';$tpid='1110';
				}elseif($var['size']==7){$s='230x45';$tpid='225';
				}elseif($var['size']==8){$s='400x25';$tpid='1111';
				}
			}
			$b= $var['boder']==1 ? '1' : '0';
			include template('keke_taoke:inc');
		}
		return $add;
	}

}

class mobileplugin_keke_taoke extends plugin_keke_taoke {
	function global_header_mobile(){
		global $_G;
		$var = $_G['cache']['plugin']['keke_taoke'];
		return $this->global_header();
	}
	function global_footer_mobile(){
		global $_G;
		$var = $_G['cache']['plugin']['keke_taoke'];
		if(!($var['wap']==1))return;
		return $this->global_footer();
	}	
}
class mobileplugin_keke_taoke_forum{
	function post_message($param){
		global $_G;
		$param = $param['param'];
		$pid = intval($param[2]['pid']);
		if($param[0]=='post_newthread_succeed' || $param[0]=='post_newthread_mod_succeed' || $param[0]=='post_reply_succeed'){
			$isurl=$_G['group']['allowposturl'];
			if($isurl==3){
				$k=daddslashes($this->ssurl($_POST['message']));
				if(strlen($k)>strlen($_POST['message'])){
					$code=" ,bbcodeoff=0";
				}
				DB::query("update ".DB::table('forum_post')." set message='".$k."' ".$code." where pid=".$pid);
			}
		}
	}
	function ssurl($message) {
		return preg_replace("/(?<=[^\]a-z0-9-=\"'\\/])((https?|ftp|gopher|news|telnet|mms|rtsp):\/\/)([a-z0-9\/\-_+=.~!%@?#%&;:$\\()|]+)/i", "[url]\\1\\3[/url]", ' '.$message);
	}
}

class plugin_keke_taoke_group extends plugin_keke_taoke{
	
}
class mobileplugin_keke_taoke_group extends plugin_keke_taoke{
	
}
class plugin_keke_taoke_portal extends plugin_keke_taoke{	
}
