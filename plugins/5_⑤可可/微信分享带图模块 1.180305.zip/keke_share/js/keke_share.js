keke_jq=jQuery.noConflict();
function wxjssdk(urls,icon,title,des,formhash) {
	keke_jq.get('plugin.php?id=keke_share:get_sdk', {url:urls,icon:icon,des:des,formhash:formhash},function (data){
		wx.config({
			  debug: data.debug,
			  appId: data.appId,
			  timestamp: data.timestamp,
			  nonceStr: data.nonceStr,
			  signature: data.signature,
			  jsApiList: [
				  'onMenuShareTimeline',
				  'onMenuShareAppMessage',
			  ]
		  });
		
		  var wxtitle = title? title :document.title;
		  var wxdesc = data.dec;
		  var wxlink = urls;
		  var wximg = data.icon;
		  
		  wx.ready(function () {
			  wx.onMenuShareTimeline({
				  title: wxtitle,
				  link: wxlink,
				  imgUrl: wximg,
				  success: function () {},
				  cancel: function () {}
			  });
		  
			  wx.onMenuShareAppMessage({  
				  title: wxtitle,
				  desc: wxdesc,
				  link: wxlink,
				  imgUrl: wximg,
				  success: function () {},
				  cancel: function () {}
			  });
			  wx.error(function(res){  
				  alert("errorMSG:"+obj2string(res));  
			  });  
		  }); 
		  
	}, "json");
}

function obj2string(o){ 
   var r=[]; 
   if(typeof o=="string"){ 
   return "\""+o.replace(/([\'\"\\])/g,"\\$1").replace(/(\n)/g,"\\n").replace(/(\r)/g,"\\r").replace(/(\t)/g,"\\t")+"\""; 
   } 
   if(typeof o=="object"){ 
   if(!o.sort){ 
	for(var i in o){ 
	r.push(i+":"+obj2string(o[i])); 
	} 
	if(!!document.all&&!/^\n?function\s*toString\(\)\s*\{\n?\s*\[native code\]\n?\s*\}\n?\s*$/.test(o.toString)){ 
	r.push("toString:"+o.toString.toString()); 
	} 
	r="{"+r.join()+"}"; 
   }else{ 
	for(var i=0;i<o.length;i++){ 
	r.push(obj2string(o[i])) 
	} 
	r="["+r.join()+"]"; 
   } 
   return r; 
   } 
   return o.toString(); 
}