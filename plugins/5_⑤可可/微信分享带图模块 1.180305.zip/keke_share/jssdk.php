<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class jssdk{
	public function __construct($url,$icon,$dec) {
		global $_G;
		$this->keke_share = $_G['cache']['plugin']['keke_share'];
		$this->appId = trim($this->keke_share['appid']);
		$this->appSecret = trim($this->keke_share['appsecret']);
		$this->url=$url;
		$this->icon=$icon;
		$this->dec=$dec;
	  }
	
	public function getSignPackage() {
		$jsapiTicket = $this->getJsApiTicket();
		$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
		$url = $this->url;
		$timestamp = time();
		$nonceStr = $this->createNonceStr();
		$string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";
		$signature = sha1($string);
		$signPackage = array(
		  "appId"     => $this->appId,
		  "nonceStr"  => $nonceStr,
		  "timestamp" => $timestamp,
		  "url"       => $url,
		  "signature" => $signature,
		  "rawString" => $string,
		  "icon" => $this->icon,
		  "dec" => $this->dec,
		  "debug"=>$this->keke_share['debug']? true : false
		);
		$returns=$signPackage;
		return $returns; 
	}
	private function createNonceStr($length = 16) {
		$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		$str = "";
		for ($i = 0; $i < $length; $i++) {
		  $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
		}
		return $str;
	}
	private function getJsApiTicket() {
		global $_G;
		loadcache('Ticket');
		$ticket_cache=$_G['cache']['Ticket'];
 		$jsapi_ticket = $ticket_cache['jsapi_ticket'];
		$expire_time = $ticket_cache['expire_time'];
		if ($expire_time < time()) {
		  $accessToken = $this->getAccessToken();
		  $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
		  $res = json_decode(dfsockopen($url));
		  $ticket = $res->ticket;
		  if ($ticket) {
			$ticket_cache['expire_time'] = time() + 7000;
			$ticket_cache['jsapi_ticket'] = $ticket;
			require_once libfile('function/cache');
			savecache('Ticket',$ticket_cache);
		  }
		} else {
		  $ticket = $jsapi_ticket;
		}
		return $ticket;
	}
	private function getAccessToken() {
		global $_G;
		loadcache('wxtoken');
		$token_cache=$_G['cache']['wxtoken'];
 		$access_token = $token_cache['access_token'];
		$expire_time = $token_cache['expire_time'];
		if ($expire_time < time()) {
		  $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->appId&secret=$this->appSecret";
		  $res = json_decode(dfsockopen($url));
		  $access_token = $res->access_token;
		  if ($access_token) {
			$token_cache['expire_time'] = time() + 7000;
			$token_cache['access_token'] = $access_token;
			require_once libfile('function/cache');
			savecache('wxtoken', $cachea);
		  }
		} else {
		  $access_token = $access_token;
		}
		return $access_token;
	}
	
	
	
}