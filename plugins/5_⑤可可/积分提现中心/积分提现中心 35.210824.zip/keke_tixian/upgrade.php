<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
!$fromversion && $fromversion = $_GET['fromversion'];
$keke_tixian_auto= DB::table("keke_tixian_auto");
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `$keke_tixian_auto` (
  `id` varchar(255) NOT NULL,
  `val` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_tixian'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('tuiyuanyin', $col_field)){
	$sql = "Alter table ".DB::table('keke_tixian')." add `tuiyuanyin` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}


if(!in_array('cardtypeid', $col_field)){
	$sql = "Alter table ".DB::table('keke_tixian')." add `cardtypeid` int(3) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('isauto', $col_field)){
	$sql = "Alter table ".DB::table('keke_tixian')." add `isauto` int(1) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('err_code_des', $col_field)){
	$sql = "Alter table ".DB::table('keke_tixian')." add `err_code_des` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('cardid', $col_field)){
	$sql = "Alter table ".DB::table('keke_tixian')." add `cardid` int(10) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('qrcodeurl', $col_field)){
	$sql = "Alter table ".DB::table('keke_tixian')." add `qrcodeurl` varchar(100) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('bili', $col_field)){
    $sql = "Alter table ".DB::table('keke_tixian')." add `bili` float(10,2) NOT NULL;";
    DB::query($sql);
}



$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_tixian_card'));
while($rows = DB::fetch($query)) {
	$col_field_card[]=$rows['Field']; 
}

if(!in_array('openid', $col_field_card)){
	$sql = "Alter table ".DB::table('keke_tixian_card')." add `openid` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('headimg', $col_field_card)){
	$sql = "Alter table ".DB::table('keke_tixian_card')." add `headimg` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('qrcodeurl', $col_field_card)){
	$sql = "Alter table ".DB::table('keke_tixian_card')." add `qrcodeurl` varchar(100) NOT NULL;"; 
	DB::query($sql); 
}


$creditQuery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_tixian_credit'));
while($creditRows = DB::fetch($creditQuery)) {
    $col_field_credit[]=$creditRows['Field'];
}
if(!in_array('px', $col_field_credit)){
    $sql = "Alter table ".DB::table('keke_tixian_credit')." add `px` int(5) NOT NULL;";
    DB::query($sql);
}


$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_tixian/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_tixian/upgrade.php');