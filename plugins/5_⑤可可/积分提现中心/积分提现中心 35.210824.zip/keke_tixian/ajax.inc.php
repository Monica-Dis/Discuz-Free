<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied|{ADDONVAR:SiteID}|{ADDONVAR:QQID}');
}
global $_G;
if ($_GET['formhash'] != $_G['formhash'] && !defined('IN_ADMINCP') && !defined('IN_TXINDEX') || !$_G['uid']) {
	exit('Access Denied');
}
$keke_tixian = $_G['cache']['plugin']['keke_tixian'];
include_once DISCUZ_ROOT . 'source/plugin/keke_tixian/identity.inc.php';
$returnset = _getauto();
$_SERVER['SERVER_ADDR'] = $_SERVER['SERVER_ADDR'] ? $_SERVER['SERVER_ADDR'] : get_client_ip();
define('WXAPPID', trim($returnset['appid']));
define('WXSECRET', trim($returnset['secert']));
define('WXMCHID', trim($returnset['mchid']));
define('WXKEY', trim($returnset['shkey']));
define('ZFBAPPID', trim($returnset['zfbappid']));
define('ZFBGY', trim($returnset['zfbgy']));
define('ZFBSY', trim($returnset['zfbsy']));
$cardon = daddslashes(dhtmlspecialchars($_GET['cardon']));
$cardtype = daddslashes(dhtmlspecialchars($_GET['cardtype']));
$moneyQuantity = intval($_GET['moneyQuantity']);
$credittype = intval($_GET['credittype']);
if ($_GET['ac'] == 'uppic') {
	require_once libfile('function/forum');
	$data = array('extid' => 1);
	$picurl = upload_icon_banner($data, $_FILES['photo'], '');
	$pic = $_G['setting']['attachurl'] . 'common/' . $picurl;
	exit(json_encode(array('picurl' => $pic, 'type' => 'success')));
} elseif ($_GET['ac'] == 'addcard') {
	$truename = daddslashes(dhtmlspecialchars($_GET['truename']));
	$bank = intval($_GET['bank']);
	if (!$cardtype) {
		showmsg(1, lang('plugin/keke_tixian', 'lang63'));
		exit(0);
	}
	if ($cardtype == 5) {
		showmsg(1, lang('plugin/keke_tixian', 'lang71'));
		exit(0);
	}
	if (!trim($truename)) {
		showmsg(1, lang('plugin/keke_tixian', 'lang65'));
		exit(0);
	}
	if (!trim($cardon)) {
		showmsg(1, lang('plugin/keke_tixian', 'lang64'));
		exit(0);
	}
	if ($keke_tixian['qrcode'] && !$_GET['qrcodeurl'] && ($cardtype == 1 || $cardtype == 2 && !ZFBGY)) {
		showmsg(1, lang('plugin/keke_tixian', 'lang119'));
		exit(0);
	}
	$arr = array('uid' => $_G['uid'], 'usname' => utf2gbk($truename), 'type' => $cardtype, 'bank' => $bank, 'cardon' => utf2gbk($cardon), 'qrcodeurl' => $_GET['qrcodeurl']);
	$id = C::t('#keke_tixian#keke_tixian_card')->insert($arr);
	if ($id) {
		echo json_encode(array('err' => ''));
	}
} elseif ($_GET['ac'] == 'del') {
	$cardid = intval($_GET['cardid']);
	$carddata = C::t('#keke_tixian#keke_tixian_card')->fetchfirst_by_id($cardid);
	if ($carddata['uid'] == $_G['uid']) {
		C::t('#keke_tixian#keke_tixian_card')->delete($cardid);
		showmsg(0);
	} else {
		showmsg(1, lang('plugin/keke_tixian', 'lang33'));
		exit(0);
	}
} elseif ($_GET['ac'] == 'add') {
	$section = empty($keke_tixian['yhz']) ? array() : unserialize($keke_tixian['yhz']);
	if (!is_array($section)) {
		$section = array();
	}
	if (!empty($section[0]) && !in_array($_G[groupid], $section)) {
		exit(showmsg(1, lang('plugin/keke_tixian', 'lang77')));
	}
	if (!trim($_GET['cardname'])) {
		showmsg(1, lang('plugin/keke_tixian', 'lang118'));
		exit(0);
	}
	if (!discuz_process::islocked('add_tixian_checklocked', 5)) {
		if ($keke_tixian['sjd'] && $keke_tixian['sjdsz'] && $keke_tixian['sjdcs']) {
			$timetiparr = array(lang('plugin/keke_tixian', 'lang111'), lang('plugin/keke_tixian', 'lang112'), lang('plugin/keke_tixian', 'lang113'), lang('plugin/keke_tixian', 'lang114'));
			$timeunitarr = array(60, 3600, 86400, 2592000);
			$timestamp = $timeunitarr[$keke_tixian['sjddw']] * intval($keke_tixian['sjdsz']);
			$time = TIMESTAMP - $timestamp;
			$check = DB::result_first('select count(1) from ' . DB::table('keke_tixian') . ' where uid=' . $_G['uid'] . ' AND time>' . $time);
			if ($check && $check >= $keke_tixian['sjdcs']) {
				discuz_process::unlock('add_tixian_checklocked');
				exit(showmsg(1, lang('plugin/keke_tixian', 'lang108') . $keke_tixian['sjdsz'] . $timetiparr[$keke_tixian['sjddw']] . lang('plugin/keke_tixian', 'lang109') . $keke_tixian['sjdcs'] . lang('plugin/keke_tixian', 'lang110')));
			}
		}
		if ($keke_tixian['cl']) {
			$clsta = DB::result_first('select id from ' . DB::table('keke_tixian') . ' where uid=' . $_G['uid'] . ' AND state=0 ORDER BY time DESC');
			if ($clsta) {
				discuz_process::unlock('add_tixian_checklocked');
				exit(showmsg(1, lang('plugin/keke_tixian', 'lang79')));
			}
		}
		$cardname = daddslashes(dhtmlspecialchars($_GET['cardname']));
		$nowcredit = getuserprofile('extcredits' . $credittype);
		loadcache('keke_tixian');
		$creditdata = $_G['cache']['keke_tixian'] ? $_G['cache']['keke_tixian'] : C::t('#keke_tixian#keke_tixian_credit')->fetchall_credit();
		if (!$moneyQuantity) {
			discuz_process::unlock('add_tixian_checklocked');
			exit(showmsg(1, lang('plugin/keke_tixian', 'lang35')));
		}
		if (!$credittype) {
			discuz_process::unlock('add_tixian_checklocked');
			exit(showmsg(1, lang('plugin/keke_tixian', 'lang36')));
		}
		if ($nowcredit < $moneyQuantity) {
			discuz_process::unlock('add_tixian_checklocked');
			exit(showmsg(1, lang('plugin/keke_tixian', 'lang37')));
		}
		if ($moneyQuantity < $creditdata[$credittype]['min']) {
			discuz_process::unlock('add_tixian_checklocked');
			exit(showmsg(1, lang('plugin/keke_tixian', 'lang38') . $creditdata[$credittype]['min'] . $_G['setting']['extcredits'][$credittype]['title']));
		}
		if ($creditdata[$credittype]['max'] && $moneyQuantity > $creditdata[$credittype]['max']) {
			discuz_process::unlock('add_tixian_checklocked');
			exit(showmsg(1, lang('plugin/keke_tixian', 'lang39') . $creditdata[$credittype]['max'] . $_G['setting']['extcredits'][$credittype]['title']));
		}
		$cardid = intval($_GET['cardid']);
		if ($cardid) {
			$cardata = C::t('#keke_tixian#keke_tixian_card')->fetch($cardid);
		}
		if ($keke_tixian['qrcode'] && !$cardata['qrcodeurl'] && ($cardata['type'] == 1 || $cardata['type'] == 2 && !ZFBGY)) {
			discuz_process::unlock('add_tixian_checklocked');
			exit(showmsg(1, lang('plugin/keke_tixian', 'lang120')));
		}
		$moneytotal = round($moneyQuantity * (1 - $creditdata[$credittype]['sxf'] / 100) * $creditdata[$credittype]['bili'], 2);
		if ($cardata['type'] == 5 && $moneytotal < 1 && $returnset['wxauto']) {
			discuz_process::unlock('add_tixian_checklocked');
			exit(showmsg(1, lang('plugin/keke_tixian', 'lang69')));
		}
		if ($cardata['type'] == 2 && $moneytotal < 0 && $returnset['zfbauto']) {
			discuz_process::unlock('add_tixian_checklocked');
			exit(showmsg(1, lang('plugin/keke_tixian', 'lang72')));
		}
		$arr = array('uid' => $_G['uid'], 'usname' => $_G['username'], 'money' => $moneytotal, 'credit' => $moneyQuantity, 'credittype' => $credittype, 'cardtypeid' => $cardata['type'], 'cardtype' => utf2gbk($cardtype), 'cardon' => $cardon, 'cardname' => utf2gbk($cardname), 'cardid' => $cardid, 'time' => $_G['timestamp'], 'qrcodeurl' => $cardata['qrcodeurl'], 'bili' => $creditdata[$credittype]['bili']);
		$orderid = C::t('#keke_tixian#keke_tixian')->insert($arr, true);
		updatemembercount($_G['uid'], array('extcredits' . $credittype => 0 - $moneyQuantity), true, '', 0, '', lang('plugin/keke_tixian', 'lang12'), lang('plugin/keke_tixian', 'lang40'));
		include libfile('function/mail');
		update_tixiannotification($moneytotal);
		$quota = $intotal = true;
		if ($returnset['money']) {
			$quota = !($moneytotal > $returnset['money']) ? true : false;
		}
		$beginToday = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
		$endToday = mktime(0, 0, 0, date('m'), date('d') + 1, date('Y')) - 1;
		$returnset['total'] = intval($returnset['total']);
		if ($returnset['total']) {
			$totalss = DB::result_first('select count(1) from ' . DB::table('keke_tixian') . ' where isauto=1 AND state=1 AND endtime>' . $beginToday . ' AND endtime<' . $endToday);
			$intotal = !($totalss > $returnset['total']) ? true : false;
		}
		if ($cardata['type'] == 5 && !$quota && $returnset['wxauto'] || $cardata['type'] == 2 && !$quota && $returnset['zfbauto']) {
			$arr = array('isauto' => 1, 'err_code_des' => lang('plugin/keke_tixian', 'lang92'));
			C::t('#keke_tixian#keke_tixian')->update($orderid, $arr);
		} elseif (!$intotal && ($returnset['wxauto'] || $returnset['zfbauto'])) {
			$arr = array('isauto' => 1, 'err_code_des' => lang('plugin/keke_tixian', 'lang93'));
			C::t('#keke_tixian#keke_tixian')->update($orderid, $arr);
		} elseif ($orderid && $cardata['type'] == 5 && $cardata['openid'] && $moneytotal >= 1 && $quota && $intotal && $returnset['wxauto']) {
			if (!discuz_process::islocked('add_tixian', 5)) {
				$orderdata = C::t('#keke_tixian#keke_tixian')->fetchfirst_by_id($orderid);
				if ($orderdata['state'] == 0) {
					$obj = new WxComPay();
					$data = array('openid' => $cardata['openid'], 'price' => $moneytotal * 100);
					$res = $obj->comPay($data);
					if ($res['err_code_des'] && CHARSET == 'gbk') {
						$msgs = $res['err_code_des'] = utf2gbk($res['err_code_des']);
					}
					if ($res['result_code'] == 'SUCCESS') {
						if ($keke_tixian['sxfuid']) {
							$creditdata = $_G['cache']['keke_tixian'] ? $_G['cache']['keke_tixian'] : C::t('#keke_tixian#keke_tixian_credit')->fetchall_credit();
							$sxfcredit = round($orderdata['credit'] * $creditdata[$orderdata['credittype']]['sxf'] / 100);
							updatemembercount($keke_tixian['sxfuid'], array('extcredits' . $orderdata['credittype'] => $sxfcredit), true, '', 0, '', lang('plugin/keke_tixian', 'lang59'), $orderdata['usname'] . lang('plugin/keke_tixian', 'lang60'));
						}
						$arr = array('state' => 1, 'isauto' => 1, 'err_code_des' => $res['payment_no'], 'endtime' => $_G['timestamp']);
						C::t('#keke_tixian#keke_tixian')->update($orderid, $arr);
						notification_add($orderdata['uid'], 'system', lang('plugin/keke_tixian', 'lang67'), array(), 1);
					} else {
						$res['err_code_des'] = CHARSET == 'gbk' ? utf2gbk($res['err_code_des']) : $res['err_code_des'];
						$arr = array('isauto' => 1, 'err_code_des' => $res['err_code_des']);
					}
					C::t('#keke_tixian#keke_tixian')->update($orderid, $arr);
				}
				discuz_process::unlock('add_tixian');
			}
		} elseif ($orderid && $cardata['type'] == 2 && $quota && $intotal && $returnset['zfbauto']) {
			if (!discuz_process::islocked('add_tixian_alipays', 5)) {
				$orderdata = C::t('#keke_tixian#keke_tixian')->fetchfirst_by_id($orderid);
				if ($orderdata['state'] == 0) {
					$cardata['usname'] = $returnset['zfbcheckname'] ? $cardata['usname'] : '';
					$obj = new Alipay();
					$data = array('payee_account' => $cardata['cardon'], 'amount' => $moneytotal, 'payer_show_name' => gbk2utf($returnset['zfbshowname']), 'payee_real_name' => gbk2utf($cardata['usname']));
					$res = iconv('gbk', 'utf-8', $obj->transfer($data));
					$res = json_decode($res, true);
					if ($res['err_code_des'] && CHARSET == 'gbk') {
						$msgs = $res['err_code_des'] = utf2gbk($res['err_code_des']);
					}
					if ($res['alipay_fund_trans_toaccount_transfer_response']['msg'] == 'Success' && $res['alipay_fund_trans_toaccount_transfer_response']['code'] == '10000') {
						if ($keke_tixian['sxfuid']) {
							$creditdata = $_G['cache']['keke_tixian'] ? $_G['cache']['keke_tixian'] : C::t('#keke_tixian#keke_tixian_credit')->fetchall_credit();
							$sxfcredit = round($orderdata['credit'] * $creditdata[$orderdata['credittype']]['sxf'] / 100);
							updatemembercount($keke_tixian['sxfuid'], array('extcredits' . $orderdata['credittype'] => $sxfcredit), true, '', 0, '', lang('plugin/keke_tixian', 'lang59'), $orderdata['usname'] . lang('plugin/keke_tixian', 'lang60'));
						}
						$arr = array('state' => 1, 'isauto' => 1, 'err_code_des' => $res['alipay_fund_trans_toaccount_transfer_response']['order_id'], 'endtime' => $_G['timestamp']);
						C::t('#keke_tixian#keke_tixian')->update($orderid, $arr);
						notification_add($orderdata['uid'], 'system', lang('plugin/keke_tixian', 'lang67'), array(), 1);
					} else {
						$res['alipay_fund_trans_toaccount_transfer_response']['sub_msg'] = CHARSET == 'gbk' ? utf2gbk($res['alipay_fund_trans_toaccount_transfer_response']['sub_msg']) : $res['alipay_fund_trans_toaccount_transfer_response']['sub_msg'];
						$arr = array('isauto' => 1, 'err_code_des' => $res['alipay_fund_trans_toaccount_transfer_response']['sub_msg']);
					}
					C::t('#keke_tixian#keke_tixian')->update($orderid, $arr);
				}
				discuz_process::unlock('add_tixian_alipays');
			}
		}
		discuz_process::unlock('add_tixian_checklocked');
	} else {
		showmsg(1, lang('plugin/keke_tixian', 'lang107'));
	}
	showmsg(0, $msgs);
} elseif ($_GET['ac'] == 'check') {
	$nowcredit = getuserprofile('extcredits' . $credittype);
	loadcache('keke_tixian');
	$creditdata = $_G['cache']['keke_tixian'] ? $_G['cache']['keke_tixian'] : ($creditdata = C::t('#keke_tixian#keke_tixian_credit')->fetchall_credit());
	if ($nowcredit < $moneyQuantity) {
		showmsg(1, '<font color="#CC0000">' . lang('plugin/keke_tixian', 'lang41') . $nowcredit . $_G['setting']['extcredits'][$credittype]['title'] . '</font>');
	} else {
		if ($moneyQuantity < $creditdata[$credittype]['min']) {
			showmsg(1, '<font color="#CC0000">' . lang('plugin/keke_tixian', 'lang42') . $creditdata[$credittype]['min'] . $_G['setting']['extcredits'][$credittype]['title'] . '</font>');
		} else {
			if ($creditdata[$credittype]['max'] && $moneyQuantity > $creditdata[$credittype]['max']) {
				showmsg(1, '<font color="#CC0000">' . lang('plugin/keke_tixian', 'lang43') . $creditdata[$credittype]['max'] . $_G['setting']['extcredits'][$credittype]['title'] . '</font>');
			} else {
				$sxf = $creditdata[$credittype]['sxf'];
				$bili = $creditdata[$credittype]['bili'];
				$sxfs = round($moneyQuantity * ($sxf / 100) * $bili, 2);
				$money = round($moneyQuantity * (1 - $sxf / 100) * $bili, 2);
				showmsg(1, '<font color="#339900">' . lang('plugin/keke_tixian', 'lang45') . $money . lang('plugin/keke_tixian', 'lang03') . ' , ' . lang('plugin/keke_tixian', 'lang46') . $sxfs . lang('plugin/keke_tixian', 'lang03') . '</font>');
			}
		}
	}
	exit(0);
}
class WxComPay
{
	const PAYURL = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/promotion/transfers';
	const SEPAYURL = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/gettransferinfo';
	const PKURL = 'https://fraud.mch.weixin.qq.com/risk/getpublickey';
	const BANKPAY = 'https://api.mch.weixin.qq.com/mmpaysptrans/pay_bank';
	const KEY = WXKEY;
	const MCHID = WXMCHID;
	const RPURL = 'https://api.mch.weixin.qq.com/mmpaymkttransfers/sendredpack';
	const APPID = WXAPPID;
	const CODEURL = 'https://open.weixin.qq.com/connect/oauth2/authorize?';
	const OPENIDURL = 'https://api.weixin.qq.com/sns/oauth2/access_token?';
	const SECRET = WXSECRET;
	private $params;
	private $public_key_resource = '';
	private $private_key_resource = '';
	public function getPuyKey()
	{
		$this->params = array('mch_id' => self::MCHID, 'nonce_str' => md5(time()), 'sign_type' => 'MD5');
		return $this->send(self::PKURL);
	}
	public function comPay($data)
	{
		$desc = CHARSET == 'gbk' ? iconv('GB2312', 'UTF-8', lang('plugin/keke_tixian', 'lang12')) : lang('plugin/keke_tixian', 'lang12');
		$this->params = array('mch_appid' => self::APPID, 'mchid' => self::MCHID, 'nonce_str' => md5(time()), 'partner_trade_no' => date('YmdHis'), 'openid' => $data['openid'], 'check_name' => 'NO_CHECK', 'amount' => $data['price'], 'desc' => $desc, 'spbill_create_ip' => $_SERVER['SERVER_ADDR']);
		return $this->send(self::PAYURL);
	}
	public function bankPay($data)
	{
		$this->params = array('mch_id' => self::MCHID, 'partner_trade_no' => date('YmdHis'), 'nonce_str' => md5(time()), 'enc_bank_no' => $data['enc_bank_no'], 'enc_true_name' => $data['enc_true_name'], 'bank_code' => $data['bank_code'], 'amount' => $data['amount']);
		return $this->send(self::BANKPAY);
	}
	public function searchPay($oid)
	{
		$this->params = array('nonce_str' => md5(time()), 'partner_trade_no' => $oid, 'mch_id' => self::MCHID, 'appid' => self::APPID);
		return $this->send(self::SEPAYURL);
	}
	public function sign()
	{
		return $this->setSign($this->params);
	}
	public function send($url)
	{
		$res = $this->sign();
		$xml = $this->ArrToXml($res);
		$returnData = $this->postData($url, $xml);
		return $this->XmlToArr($returnData);
	}
	public function __construct($public_key = '', $private_key = '')
	{
		$this->public_key_resource = !empty($public_key) ? openssl_pkey_get_public($this->get_public_key($public_key)) : false;
		$this->private_key_resource = !empty($private_key) ? openssl_pkey_get_private($this->get_private_key($private_key)) : false;
	}
	public function get_private_key($private_key)
	{
		$search = array('-----BEGIN RSA PRIVATE KEY-----', '-----END RSA PRIVATE KEY-----', "\n", "\r", "\r\n");
		$private_key = str_replace($search, '', $private_key);
		return $search[0] . PHP_EOL . wordwrap($private_key, 64, "\n", true) . PHP_EOL . $search[1];
	}
	public function get_public_key($public_key)
	{
		$search = array('-----BEGIN PUBLIC KEY-----', '-----END PUBLIC KEY-----', "\n", "\r", "\r\n");
		$public_key = str_replace($search, '', $public_key);
		return $search[0] . PHP_EOL . wordwrap($public_key, 64, "\n", true) . PHP_EOL . $search[1];
	}
	public function create_key()
	{
		$res = openssl_pkey_new();
		if ($res == false) {
			return false;
		}
		openssl_pkey_export($res, $private_key);
		$public_key = openssl_pkey_get_details($res);
		return array('public_key' => $public_key['key'], 'private_key' => $private_key);
	}
	public function private_encrypt($input)
	{
		openssl_private_encrypt($input, $output, $this->private_key_resource);
		return base64_encode($output);
	}
	public function public_decrypt($input)
	{
		openssl_public_decrypt(base64_decode($input), $output, $this->public_key_resource);
		return $output;
	}
	public function public_encrypt($input)
	{
		openssl_public_encrypt($input, $output, $this->public_key_resource);
		return base64_encode($output);
	}
	public function private_decrypt($input)
	{
		openssl_private_decrypt(base64_decode($input), $output, $this->private_key_resource);
		return $output;
	}
	public function getSign($arr)
	{
		$arr = array_filter($arr);
		if (isset($arr['sign'])) {
			unset($arr['sign']);
		}
		ksort($arr);
		$str = $this->arrToUrl($arr) . '&key=' . self::KEY;
		return strtoupper(md5($str));
	}
	public function setSign($arr)
	{
		$arr['sign'] = $this->getSign($arr);
		return $arr;
	}
	public function arrToUrl($arr)
	{
		return urldecode(http_build_query($arr));
	}
	public function ArrToXml($arr)
	{
		if (!is_array($arr) || count($arr) == 0) {
			return '';
		}
		$xml = '<xml>';
		foreach ($arr as $key => $val) {
			if (is_numeric($val)) {
				$xml .= '<' . $key . '>' . $val . '</' . $key . '>';
			} else {
				$xml .= '<' . $key . '><![CDATA[' . $val . ']]></' . $key . '>';
			}
		}
		$xml .= '</xml>';
		return $xml;
	}
	public function XmlToArr($xml)
	{
		if ($xml == '') {
			return '';
		}
		libxml_disable_entity_loader(true);
		$arr = json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
		return $arr;
	}
	public function postData($url, $xml, $useCert = true, $second = 30)
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_TIMEOUT, $second);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		if ($useCert == true) {
			curl_setopt($ch, CURLOPT_SSLCERTTYPE, 'PEM');
			curl_setopt($ch, CURLOPT_SSLCERT, dirname(__FILE__) . '/cert/apiclient_cert.pem');
			curl_setopt($ch, CURLOPT_SSLKEYTYPE, 'PEM');
			curl_setopt($ch, CURLOPT_SSLKEY, dirname(__FILE__) . '/cert/apiclient_key.pem');
		}
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
		$data = curl_exec($ch);
		if ($data) {
			curl_close($ch);
			return $data;
		}
		$error = curl_errno($ch);
		curl_close($ch);
		return '<xml><err_code_des>curl出错，错误码' . $error . '</err_code_des></xml>';
	}
}
class Alipay
{
	const TRANSFER = 'https://openapi.alipay.com/gateway.do';
	const APPPRIKEY = ZFBSY;
	const APPID = ZFBAPPID;
	const NEW_ALIPUBKE = ZFBGY;
	public function rsaSign($data, $private_key, $type = 'RSA')
	{
		$search = array('-----BEGIN RSA PRIVATE KEY-----', '-----END RSA PRIVATE KEY-----', "\n", "\r", "\r\n");
		$private_key = str_replace($search, '', $private_key);
		$private_key = $search[0] . PHP_EOL . wordwrap($private_key, 64, "\n", true) . PHP_EOL . $search[1];
		$res = openssl_get_privatekey($private_key);
		if ($res) {
			if ($type == 'RSA') {
				openssl_sign($data, $sign, $res);
			} elseif ($type == 'RSA2') {
				openssl_sign($data, $sign, $res, OPENSSL_ALGO_SHA256);
			}
			openssl_free_key($res);
		} else {
			exit('私钥格式有误');
		}
		$sign = base64_encode($sign);
		return $sign;
	}
	public function rsaCheck($data, $public_key, $sign, $type = 'RSA')
	{
		$search = array('-----BEGIN PUBLIC KEY-----', '-----END PUBLIC KEY-----', "\n", "\r", "\r\n");
		$public_key = str_replace($search, '', $public_key);
		$public_key = $search[0] . PHP_EOL . wordwrap($public_key, 64, "\n", true) . PHP_EOL . $search[1];
		$res = openssl_get_publickey($public_key);
		if ($res) {
			if ($type == 'RSA') {
				$result = (bool) openssl_verify($data, base64_decode($sign), $res);
			} elseif ($type == 'RSA2') {
				$result = (bool) openssl_verify($data, base64_decode($sign), $res, OPENSSL_ALGO_SHA256);
			}
			openssl_free_key($res);
		} else {
			exit('公钥格式有误!');
		}
		return $result;
	}
	public function getStr($arr, $type = 'RSA')
	{
		if (isset($arr['sign'])) {
			unset($arr['sign']);
		}
		if (isset($arr['sign_type']) && $type == 'RSA') {
			unset($arr['sign_type']);
		}
		ksort($arr);
		return $this->getUrl($arr, false);
	}
	public function getUrl($arr, $encode = true)
	{
		if ($encode) {
			return http_build_query($arr);
		}
		return urldecode(http_build_query($arr));
	}
	public function getRsa2Sign($arr)
	{
		return $this->rsaSign($this->getStr($arr, 'RSA2'), self::APPPRIKEY, 'RSA2');
	}
	public function setRsa2Sign($arr)
	{
		$arr['sign'] = $this->getRsa2Sign($arr);
		return $arr;
	}
	public function checkSign($arr)
	{
		if ($this->getRsa2Sign($arr) == $arr['sign']) {
			return true;
		}
		return false;
	}
	public function curlRequest($url, $data = '')
	{
		$ch = curl_init();
		$params[CURLOPT_URL] = $url;
		$params[CURLOPT_HEADER] = false;
		$params[CURLOPT_RETURNTRANSFER] = true;
		$params[CURLOPT_TIMEOUT] = 30;
		if (!empty($data)) {
			$params[CURLOPT_POST] = true;
			$params[CURLOPT_POSTFIELDS] = $data;
		}
		$params[CURLOPT_SSL_VERIFYPEER] = false;
		$params[CURLOPT_SSL_VERIFYHOST] = false;
		curl_setopt_array($ch, $params);
		$content = curl_exec($ch);
		curl_close($ch);
		return $content;
	}
	public function searchPay()
	{
		$pub_params = array('app_id' => self::APPID, 'method' => 'alipay.fund.trans.order.query', 'format' => 'JSON', 'charset' => 'UTF-8', 'sign_type' => 'RSA2', 'sign' => '', 'timestamp' => date('Y-m-d H:i:s'), 'version' => '1.0', 'biz_content' => '');
		$api_params = array('out_biz_no' => '20180131141717');
		$pub_params['biz_content'] = json_encode($api_params, JSON_UNESCAPED_UNICODE);
		$pub_params = $this->setRsa2Sign($pub_params);
		return $this->curlRequest(self::TRANSFER, $pub_params);
	}
	public function transfer($data)
	{
		$pub_params = array('app_id' => self::APPID, 'method' => 'alipay.fund.trans.toaccount.transfer', 'format' => 'JSON', 'charset' => 'utf-8', 'sign_type' => 'RSA2', 'sign' => '', 'timestamp' => date('Y-m-d H:i:s'), 'version' => '1.0', 'biz_content' => '');
		$api_params = array('out_biz_no' => date('YmdHis'), 'payee_type' => 'ALIPAY_LOGONID', 'payee_account' => $data['payee_account'], 'amount' => $data['amount'], 'payer_show_name' => $data['payer_show_name'], 'payee_real_name' => $data['payee_real_name']);
		$pub_params['biz_content'] = json_encode($api_params);
		$pub_params = $this->setRsa2Sign($pub_params);
		return $this->curlRequest(self::TRANSFER, $pub_params);
	}
}
function showmsg($err, $msg = '')
{
	$msg = diconv($msg, CHARSET, 'utf-8');
	$err = array('err' => $err, 'msg' => $msg);
	echo json_encode($err);
}
function utf2gbk($data)
{
	$data = dhtmlspecialchars($data);
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	if (CHARSET == 'gbk') {
		return $tmpstr;
	}
	return gbk2utf($data);
}
function gbk2utf($data)
{
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	return diconv($tmpstr, 'gbk', 'utf-8');
}
function update_tixiannotification($money)
{
	global $_G;
	$keke_tixian = $_G['cache']['plugin']['keke_tixian'];
	if ($keke_tixian['remind'] && $keke_tixian['remuid']) {
		$remuid = explode(',', $keke_tixian['remuid']);
		foreach ($remuid as $val) {
			notification_add($val, 'system', lang('plugin/keke_tixian', 'lang61'), array('usname' => $_G['username'], 'money' => $money), 1);
		}
	}
	if ($keke_tixian['emailrem'] && $keke_tixian['email']) {
		$email = dhtmlspecialchars($keke_tixian['email']);
		$add_member_subject = lang('plugin/keke_tixian', 'lang62');
		$add_member_message = str_replace(array('{usname}', '{money}'), array($_G['username'], $money), lang('plugin/keke_tixian', 'lang61'));
		if (!sendmail($email, $add_member_subject, $add_member_message)) {
			runlog('sendmail', $orderdata['email'] . ' sendmail failed.');
		}
	}
}
function _getaccesstokenss($redirect_uri)
{
	global $_G;
	$appid = WXAPPID;
	$secret = WXSECRET;
	$redirect_base = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid=' . $appid . '&redirect_uri=' . $redirect_uri . '&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect';
	if (empty($_GET['code'])) {
		header('location: ' . $redirect_base);
	} else {
		$code = $_GET['code'];
		$get_acctokenurl = 'https://api.weixin.qq.com/sns/oauth2/access_token?appid=' . $appid . '&secret=' . $secret . '&code=' . $code . '&grant_type=authorization_code';
		$access_tokendata = dfsockopen($get_acctokenurl);
		if (!$access_tokendata) {
			$access_tokendata = file_get_contents($get_acctokenurl);
		}
		$access_tokenarr = json_decode($access_tokendata, true);
		return $access_tokenarr;
	}
}
function _getwxreuriss()
{
	global $_G;
	$redirect_uri = urlencode($_G['siteurl'] . 'plugin.php?id=keke_tixian:getopenid&formhash=' . FORMHASH);
	return $redirect_uri;
}
function _getusdataapiss($access_tokens, $openid)
{
	$url = 'https://api.weixin.qq.com/sns/userinfo?access_token=' . $access_tokens . '&openid=' . $openid . '&lang=zh_CN';
	$json = dfsockopen($url);
	if (!$json) {
		$json = file_get_contents($url);
	}
	$user_data = json_decode($json, true);
	return $user_data;
}
function _checkcardbyopenid($openid)
{
	return $orderdata = DB::result_first('select count(1) from ' . DB::table('keke_tixian_card') . ' where openid=\'' . $openid . '\'');
}
function _getcarddata($cardid)
{
	return C::t('#keke_tixian#keke_tixian_card')->fetchfirst_by_id($cardid);
}
function _getauto()
{
	$alldata = C::t('#keke_tixian#keke_tixian_auto')->fetch_all_byid();
	foreach ($alldata as $ak => $av) {
		$returnset[$av['id']] = $av['val'];
	}
	return $returnset;
}
function func_substr_replaces($str)
{
	$len = strlen($str);
	$len = intval($len - 60);
	$replacement = '*';
	for ($i = 0; $i < $len; $i++) {
		$new_str .= $replacement;
	}
	return substr_replace($str, $new_str, 30, 0 - 30);
}
function get_client_ip($type = 0)
{
	if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$ip = getenv('HTTP_CLIENT_IP');
	} elseif (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
		$ip = getenv('HTTP_X_FORWARDED_FOR');
	} elseif (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
		$ip = getenv('REMOTE_ADDR');
	} elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
		$ip = $_SERVER['REMOTE_ADDR'];
	}
	return preg_match('/[\\d\\.]{7,15}/', $ip, $matches) ? $matches[0] : '';
}