<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_tixian= DB::table("keke_tixian");
$keke_tixian_card= DB::table("keke_tixian_card");
$keke_tixian_credit= DB::table("keke_tixian_credit");
$keke_tixian_auto= DB::table("keke_tixian_auto");
$sql = <<<EOF
CREATE TABLE `$keke_tixian` (
   `id` int(10) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `usname` varchar(255) NOT NULL,
  `money` float(50,2) NOT NULL,
  `credit` int(50) unsigned NOT NULL,
  `credittype` int(10) NOT NULL,
  `time` int(10) unsigned NOT NULL,
  `endtime` int(10) unsigned NOT NULL,
  `state` int(10) NOT NULL,
  `cardon` varchar(255) NOT NULL,
  `cardtype` varchar(80) NOT NULL,
  `cardname` varchar(255) NOT NULL,
  `tuiyuanyin` varchar(255) NOT NULL,
  `cardtypeid` int(3) NOT NULL,
  `isauto` int(1) NOT NULL,
  `err_code_des` varchar(255) NOT NULL,
  `cardid` int(10) NOT NULL,
  `qrcodeurl` varchar(100) NOT NULL,
  `bili` float(10,2) NOT NULL,
   PRIMARY KEY (`id`),
   KEY `uid` (`uid`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_tixian_card` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `usname` varchar(255) NOT NULL,
  `type` int(10) unsigned NOT NULL,
  `bank` int(10) NOT NULL,
  `cardon` mediumtext NOT NULL,
  `last` int(50) NOT NULL,
  `openid` varchar(255) NOT NULL,
  `headimg` varchar(255) NOT NULL,
  `qrcodeurl` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


CREATE TABLE `$keke_tixian_credit` (
  `creditid` int(10) unsigned NOT NULL,
  `bili` float(50,2) NOT NULL,
  `min` int(50) NOT NULL,
  `max` float(50,2) unsigned NOT NULL,
  `menkan` int(10) NOT NULL,
  `state` int(10) NOT NULL,
  `sxf` int(10) NOT NULL,
  `px` int(10) NOT NULL,
  PRIMARY KEY  (`creditid`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_tixian_auto` (
  `id` varchar(255) NOT NULL,
  `val` varchar(2000) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;


EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_tixian/discuz_plugin_keke_tixian_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_tixian/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_tixian/upgrade.php');