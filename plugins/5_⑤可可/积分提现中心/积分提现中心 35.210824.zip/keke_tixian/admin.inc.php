<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
    global $_G;
	loadcache('plugin');
	$keke_tixian = $_G['cache']['plugin']['keke_tixian'];
	if (submitcheck("forumset")) {
		$data = daddslashes($_GET['form']);
		if($data) {
			foreach($data as $creditid => $val) {
				if($val){
					C::t('#keke_tixian#keke_tixian_credit')->insert(array('creditid' => $creditid,'bili' => $val['bili'],'min' => $val['min'],'max' => $val['max'],'sxf' => $val['sxf'],'px' => $val['px'],'state' => $val['state']), false, true);
				}
			}
		}
		require_once libfile('function/cache');
		savecache('keke_tixian', $data);
		cpmsg(lang('plugin/keke_tixian', 'lang01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin', 'succeed');
	}
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");
    showtableheader(lang('plugin/keke_tixian', 'lang02'));
    showsubtitle(array(lang('plugin/keke_tixian', 'lang05'), lang('plugin/keke_tixian', 'lang06'), lang('plugin/keke_tixian', 'lang07'),lang('plugin/keke_tixian', 'lang08'),lang('plugin/keke_tixian', 'lang09'), lang('plugin/keke_tixian', 'lang122'), lang('plugin/keke_tixian', 'lang10')));
	loadcache('keke_tixian');
	$creditdata=$_G['cache']['keke_tixian'] ?: C::t('#keke_tixian#keke_tixian_credit')->fetchall_credit();
    if(!$creditdata) {
        $creditdata=$_G['setting']['extcredits'];
    }else{
        foreach ($_G['setting']['extcredits'] as $creditid=>$creditval) {
            if(!$creditdata[$creditid]){
                $creditdata[$creditid]=$creditval;
            }
        }
    }
    foreach ($creditdata as $cid=>$time) {
        $ordsArr[$cid] = $time['px'];
    }
    asort($ordsArr);
    foreach ($ordsArr as $key=>$val) {
        if($_G['setting']['extcredits'][$key]){
            $dataArr[$key]=$_G['setting']['extcredits'][$key];
        }
    }
	foreach($dataArr as $k=>$v){
		$checke= $creditdata[$k]['state'] ? 'checked="checked"' : '';
		$table = array();
        $table[0] = $v['title'];
        $table[1] = '1'.$v['title'].'= <input name="form['.$k.'][bili]" value="'.dhtmlspecialchars($creditdata[$k]['bili']).'" style="width:50px"> '.lang('plugin/keke_tixian', 'lang03');
		$table[2] = '<input name="form['.$k.'][min]" value="'.dhtmlspecialchars($creditdata[$k]['min']).'" style="width:50px"> '.$v['title'];
		$table[3] = '<input name="form['.$k.'][max]" value="'.dhtmlspecialchars($creditdata[$k]['max']).'" style="width:50px"> '.$v['title'];
		$table[4] = '<input name="form['.$k.'][sxf]" value="'.dhtmlspecialchars($creditdata[$k]['sxf']).'" style="width:50px"> %';
        $table[5] = '<input name="form['.$k.'][px]" value="'.dhtmlspecialchars($creditdata[$k]['px']).'" style="width:50px">';
		$table[6] = '<input class="checkbox" type="checkbox" name="form['.$k.'][state]" '.$checke.'  value="1">';
        showtablerow('',array(), $table);
	}
	
    showsubmit('forumset');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
