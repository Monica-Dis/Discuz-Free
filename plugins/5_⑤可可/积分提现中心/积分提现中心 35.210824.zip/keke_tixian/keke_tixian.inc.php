<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
define('IN_TXINDEX',1);
$keke_tixian = $_G['cache']['plugin']['keke_tixian'];
if(!$_G['uid']){
    showmessage('not_loggedin', '', array(), array('login' => true));
}
include_once DISCUZ_ROOT."source/plugin/keke_tixian/ajax.inc.php";
$bank=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$keke_tixian['bank']));
$p=$_GET['p'];
$returnset=_getauto();
loadcache('keke_tixian');
$creditdata=$_G['cache']['keke_tixian'] ? $_G['cache']['keke_tixian'] : $creditdata=C::t('#keke_tixian#keke_tixian_credit')->fetchall_credit();
$navtitle=$title=$keke_tixian['title']?dhtmlspecialchars($keke_tixian['title']):lang('plugin/keke_tixian', 'lang12');
if($p=='card'){
	$iswx=strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false?true:false;
	$carddata=C::t('#keke_tixian#keke_tixian_card')->fetch_by_uid($_G['uid']);
	$urls=$_G['siteurl'].'plugin.php?id=keke_tixian&p=card';
	$ewmurl='source/plugin/keke_tixian/qrcode.php?data='.urlencode($urls);
}elseif($p=='my'){
	$ppp=15;
	$tmpurl='plugin.php?id=keke_tixian&p=my';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = C::t('#keke_tixian#keke_tixian')->count_by_all($_G['uid']);
	if($allcount){
		$query = C::t('#keke_tixian#keke_tixian')->fetch_all_by_all($_G['uid'],0,$startlimit,$ppp);
		foreach($query as $val){
			$carddata=_getcarddata($val['cardid']);
			$sxf=$creditdata[$val['credittype']]['sxf'];
			$bili=$val['bili']>0?$val['bili']:$creditdata[$val['credittype']]['bili'];
			$sxfs=round($val['credit']*($sxf/100)*$bili ,2);
			$money=$val['money'];
			$time=dgmdate($val['time'], 'm-d H:i');
			$endtime=dgmdate($val['endtime'], 'm-d H:i');
			$br= checkmobile() ? '<br>' : '<b class="sep">/</b>';
			$tuiyuanyin=$val['tuiyuanyin'] ? $br.'<font color="#c30">'.lang('plugin/keke_tixian', 'lang58').''.dhtmlspecialchars($val['tuiyuanyin']).'</font>' : '';
			if($val['state']==1){$stat='<b class="gl">'.lang('plugin/keke_tixian', 'lang26').'</b> '.$endtime ;}elseif($val['state']==2){$stat='<b class="h">'.lang('plugin/keke_tixian', 'lang27').'</b> <b class="sep">|</b>'.$endtime.$tuiyuanyin  ;}else{$stat='<b class="yl">'.lang('plugin/keke_tixian', 'lang47').'</b>' ;}
			$cardon=$val['cardtypeid']==5?'<i><img class="headimgs" src="'.$carddata['headimg'].'" width="18" height="18"></i>'.$val['cardname'].' / '.$val['cardtype']:$val['cardtype'].' / '.$val['cardon'].' / '.$val['cardname'];
			$mylist.='<li><div class="pup"><span><b class="rred">'.$val['credit'].'</b>'.$_G['setting']['extcredits'][$val['credittype']]['title'].'</span>'.lang('plugin/keke_tixian', 'lang48').'<b class="rred">'.$money.'</b>'.lang('plugin/keke_tixian', 'lang03').'<i> '.lang('plugin/keke_tixian', 'lang49').$sxfs.lang('plugin/keke_tixian', 'lang03').' </i></div><div class="dow">'.$cardon.'</div><div class="dow"><font color="#CCCCCC">'.lang('plugin/keke_tixian', 'lang50').' '.$time.'</font><b class="sep">|</b>'.$stat.'</div></li>';
		}
	}
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
}else{
	$d=0;
	$cardid=intval($_GET['c']);
	loadcache('keke_tixian_card');
	$cachedata=$_G['cache']['keke_tixian_card'];
	$defaultcard=$cachedata[$_G['uid']]['defaultcard'];
	if(!$cardid){
		$cardid=$defaultcard;
	}elseif($cardid && ($cardid!=$defaultcard) && $_G['uid']){
		$cachedata[$_G['uid']]['defaultcard']=$cardid;
		require_once libfile('function/cache');
		savecache('keke_tixian_card', $cachedata);
	}
	$keke_tixian['sm']=txeditor_safe_replace($keke_tixian['sm']);
	$cardata=C::t('#keke_tixian#keke_tixian_card')->fetch($cardid);
	if($cardata['type']==1){$cardtype=lang('plugin/keke_tixian', 'lang51');}elseif($cardata['type']==5){$cardtype=lang('plugin/keke_tixian', 'lang94');}elseif($cardata['type']==2){$cardtype=lang('plugin/keke_tixian', 'lang52');}else{$cardtype=$bank[$cardata['bank']];}
    foreach ($creditdata as $cid=>$time) {
        $ordsArr[$cid] = $time['px'];
    }
    asort($ordsArr);
	foreach($ordsArr as $k=>$val){
	    $v=$creditdata[$k];
		if($v['state']){
			$carditname=$_G['setting']['extcredits'][$k]['title'];
			$class='';
			if($d==0){
				$firstcarditname=$carditname;
				$firstcarditid=$k;
				$class='class="on"';
			}
			$nowcredit = getuserprofile('extcredits'.$k);
			$craditlist.='<li '.$class.' creditid='.$k.' data-bili='.$v['bili'].' data-min='.$v['min'].' data-nowcredit='.$nowcredit.' data-sxf='.$v['sxf'].'>'.$carditname.'</li>';
			$d++;
		}
	}
	$totaltx=C::t('#keke_tixian#keke_tixian')->sum_by_uid($_G['uid']);
	$totaltx=$totaltx?$totaltx:"0.00";
	$nowcredits = getuserprofile('extcredits'.$firstcarditid);
}
$pcleftbtntxt=explode('|',$keke_tixian['pcleft']);
$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
if($keke_chongzhi['pcleft']){
    $chongzhipcleftbtntxt=explode('|',$keke_chongzhi['pcleft']);
}
$keke_group = $_G['cache']['plugin']['keke_group'];
if($keke_group['pcleft']){
    $groupPcLeftTxt=explode('|',$keke_group['pcleft']);
}
include template('keke_tixian:tx_index');
function txeditor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}