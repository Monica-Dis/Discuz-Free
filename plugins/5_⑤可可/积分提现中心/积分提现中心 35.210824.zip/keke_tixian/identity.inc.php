<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


global $_G;
if(!$_G['cache']['plugin']){
    loadcache('plugin');
}
define('K_AUTHKEY', $_G['config']['security']['authkey']);
define('INC_MAGAPP', strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'magapp') !== false);
if(INC_MAGAPP){
	$urls=''; //客户端域名
	$secret='';//马甲app应用secret
	if(!$_G['uid']){
		$urlsa = $urls.'mag/user/v1/wxwap/toWeiXinAuthorLogin?return_url='.$_G['siteurl'].'plugin.php?id=keke_tixian';
		dheader('location: '.$urlsa);
	}else{
		$magapp_token=$_GET['magapp_token'];
		if($magapp_token){
			$url=$urls.'mag/cloud/cloud/getUserInfo?token='.$magapp_token.'&secret='.$secret;
			$open=dfsockopen($url);
			$usarr=json_decode($open,true);
			$uid=$usarr['data']['user_id'];
			if($uid){
				if (!($member = getuserbyuid($uid, 1))) {
					return false;
				}
				if (isset($member['_inarchive'])) {
					C::t('common_member_archive')->move_to_master($member['uid']);
				}
				require_once libfile('function/member');
				$cookietime = 1296000;
				setloginstatus($member, $cookietime);
				dheader('location: '.$_G['siteurl'].'plugin.php?id=keke_tixian');
			}
			
		}
	}
}