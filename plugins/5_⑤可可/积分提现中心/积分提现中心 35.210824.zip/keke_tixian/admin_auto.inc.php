<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
    global $_G;
	loadcache('plugin');
	$keke_tixian = $_G['cache']['plugin']['keke_tixian'];
	include_once DISCUZ_ROOT."source/plugin/keke_tixian/ajax.inc.php";
	$returnset=_getauto();
	$zfbgy=func_substr_replaces($returnset['zfbgy']);
	$zfbsy=func_substr_replaces($returnset['zfbsy']);
	if (submitcheck("forumset")) {
		$data = daddslashes($_GET['datas']);
		if($data) {
			foreach($data as $keyid => $val) {
				if(array_key_exists($keyid,_getauto())){
					if(($keyid=='zfbgy' && $val==$zfbgy) || ($keyid=='zfbsy' && $val==$zfbsy)){continue;}
					C::t('#keke_tixian#keke_tixian_auto')->update($keyid,array('val'=>$val));
				}else{
					C::t('#keke_tixian#keke_tixian_auto')->insert(array('id' => $keyid,'val' => $val), true);
				}
			}
		}
		require_once libfile('function/cache');
		savecache('keke_tixian_auto', _getauto());
		cpmsg(lang('plugin/keke_tixian', 'lang01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_auto', 'succeed');
	}
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_auto");
	
	showtableheader(lang('plugin/keke_tixian', 'lang76'));
	
	showsetting(lang('plugin/keke_tixian', 'lang80'),'datas[money]',$returnset['money'],'text','','',lang('plugin/keke_tixian', 'lang81'));
	showsetting(lang('plugin/keke_tixian', 'lang82'),'datas[total]',$returnset['total'],'text','','',lang('plugin/keke_tixian', 'lang83'));
	
    showtableheader(lang('plugin/keke_tixian', 'lang73'));
    
	showsetting(lang('plugin/keke_tixian', 'lang84'), 'datas[wxauto]', $returnset['wxauto']);
	showsetting(lang('plugin/keke_tixian', 'lang85').'Appid','datas[appid]',$returnset['appid'],'text');
	showsetting(lang('plugin/keke_tixian', 'lang85').'AppSecret','datas[secert]',$returnset['secert'],'text');
	showsetting(lang('plugin/keke_tixian', 'lang86'),'datas[mchid]',$returnset['mchid'],'text');
	showsetting(lang('plugin/keke_tixian', 'lang87'),'datas[shkey]',$returnset['shkey'],'text');
	
	
	showtableheader(lang('plugin/keke_tixian', 'lang75'));
	
	showsetting( lang('plugin/keke_tixian', 'lang88'), 'datas[zfbauto]', $returnset['zfbauto']);
	showsetting(lang('plugin/keke_tixian', 'lang89'),'datas[zfbappid]',$returnset['zfbappid'],'text');
	showsetting(lang('plugin/keke_tixian', 'lang90'),'datas[zfbgy]',$zfbgy,'textarea');
	showsetting(lang('plugin/keke_tixian', 'lang91'),'datas[zfbsy]',$zfbsy,'textarea');
	showsetting(lang('plugin/keke_tixian', 'lang115'),'datas[zfbshowname]',$returnset['zfbshowname'],'text','','',lang('plugin/keke_tixian', 'lang116'));
	showsetting(lang('plugin/keke_tixian','lang117'), 'datas[zfbcheckname]', $returnset['zfbcheckname']);
	echo '<input name="keyid" type="hidden" value="'.$returnset['id'].'" />';
			
    showsubmit('forumset', 'submit', '', '');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/
