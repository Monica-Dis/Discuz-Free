<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	include_once DISCUZ_ROOT."source/plugin/keke_tixian/ajax.inc.php";
	$keke_tixian = $_G['cache']['plugin']['keke_tixian'];
	$orderid=intval($_GET['orderid']);
	if($_GET['ac']=='ok'){
		$orderdata=C::t('#keke_tixian#keke_tixian')->fetchfirst_by_id($orderid);
		if($keke_tixian['sxfuid']){
			$creditdata=$_G['cache']['keke_tixian'] ? $_G['cache']['keke_tixian'] : C::t('#keke_tixian#keke_tixian_credit')->fetchall_credit();	
			$sxfcredit=round($orderdata['credit']*$creditdata[$orderdata['credittype']]['sxf']/100);
			updatemembercount($keke_tixian['sxfuid'], array('extcredits'.$orderdata['credittype']=>$sxfcredit), true, '', 0, '',lang('plugin/keke_tixian', 'lang59'),$orderdata['usname'].lang('plugin/keke_tixian', 'lang60'));
		}
		$arr=array('state'=>1,'endtime'=>$_G['timestamp']);
		C::t('#keke_tixian#keke_tixian')->update($orderid,$arr);
		notification_add($orderdata['uid'],'system',lang('plugin/keke_tixian', 'lang67'),array(), 1);
		cpmsg(lang('plugin/keke_tixian', 'lang01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx&page='.$_GET['page'], 'succeed');
	}elseif($_GET['ac']=='pays'){
		
		$orderdata=C::t('#keke_tixian#keke_tixian')->fetchfirst_by_id($orderid);
		$cardata=C::t('#keke_tixian#keke_tixian_card')->fetch($orderdata['cardid']);
		loadcache('keke_tixian');
		
		$moneytotal=$orderdata['money'];
		if($orderdata['state']==0){
			$issuccess=0;
			if($_GET['cardtype']==5){
				$obj = new WxComPay();
				$data = array(
				  'openid'  => $cardata['openid'],
				  'price'   => $moneytotal*100
				);
				$res = $obj->comPay($data);
				if($res['result_code']=='SUCCESS'){
					$issuccess=1;
				}
				$code_des=$res['err_code_des'];
				$payment_no=$res['payment_no'];
			}elseif($_GET['cardtype']==2){
				$obj = new Alipay();
				$data = array(
					 'payee_account'  => $cardata['cardon'],
					 'amount'  => $moneytotal, 
				);
				$res = iconv('gbk','utf-8',$obj->transfer($data));
				$res = json_decode($res,true);
				if($res['alipay_fund_trans_toaccount_transfer_response']['msg']=='Success' && $res['alipay_fund_trans_toaccount_transfer_response']['code']=='10000'){
					$issuccess=1;
				}
				$code_des=$res['alipay_fund_trans_toaccount_transfer_response']['sub_msg'];
				
				$payment_no=$res['alipay_fund_trans_toaccount_transfer_response']['order_id'];
				
			}
			if($code_des && CHARSET=='gbk'){
					$code_des=utf2gbk($code_des);
			}
			if($issuccess){
				if($keke_tixian['sxfuid']){
					$creditdata=$_G['cache']['keke_tixian'] ? $_G['cache']['keke_tixian'] : C::t('#keke_tixian#keke_tixian_credit')->fetchall_credit();	
					$sxfcredit=round($orderdata['credit']*$creditdata[$orderdata['credittype']]['sxf']/100);
					updatemembercount($keke_tixian['sxfuid'], array('extcredits'.$orderdata['credittype']=>$sxfcredit), true, '', 0, '',lang('plugin/keke_tixian', 'lang59'),$orderdata['usname'].lang('plugin/keke_tixian', 'lang60'));
				}
				$arr=array('state'=>1,'isauto'=>2,'err_code_des'=>$payment_no,'endtime'=>$_G['timestamp']);
				C::t('#keke_tixian#keke_tixian')->update($orderid,$arr);
				notification_add($orderdata['uid'],'system',lang('plugin/keke_tixian', 'lang67'),array(), 1);
				C::t('#keke_tixian#keke_tixian')->update($orderid,$arr);
				$tips=lang('plugin/keke_tixian', 'lang95').$payment_no;
				$sta='succeed';
			}else{
				$tips=lang('plugin/keke_tixian', 'lang96').$code_des;
				$sta='error';
			}
			cpmsg($tips, 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx&page='.$_GET['page'], $sta);
		}else{
			cpmsg(lang('plugin/keke_tixian', 'lang97'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx&page='.$_GET['page'], 'succeed');
		}
		
		
	}elseif($_GET['ac']=='dels'){
		C::t('#keke_tixian#keke_tixian')->delete($orderid);
		cpmsg(lang('plugin/keke_tixian', 'lang11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx&page='.$_GET['page'], 'succeed');
	}elseif($_GET['ac']=='tui'){
		if (submitcheck("forumset")) {
			$orderdata=C::t('#keke_tixian#keke_tixian')->fetchfirst_by_id($orderid);
			$yuanyin=daddslashes($_GET['yuanyin']);
			$arr=array('state'=>2,'endtime'=>$_G['timestamp'],'tuiyuanyin'=>$yuanyin);
			C::t('#keke_tixian#keke_tixian')->update($orderid,$arr);
			updatemembercount($orderdata['uid'], array('extcredits'.$orderdata['credittype']=>$orderdata['credit']), true, '', 0, '',lang('plugin/keke_tixian', 'lang12'),lang('plugin/keke_tixian', 'lang13').$orderid);
			notification_add($orderdata['uid'],'system',lang('plugin/keke_tixian', 'lang68').$yuanyin,array(), 1);
			cpmsg(lang('plugin/keke_tixian', 'lang14'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx&page='.intval($_GET['page']), 'succeed');
		}
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_tx&ac=tui");
		showtableheader('');
		showsubtitle(array(lang('plugin/keke_tixian', 'lang56')));
		$table = array();
		$table[0] = '<input name="yuanyin" value="" style="width:200px"><input type="hidden" name="orderid" value="'.$orderid.'"><input type="hidden" name="page" value="'.intval($_GET['page']).'"> <font style="color:#666; margin-left:15px">'.lang('plugin/keke_tixian', 'lang57').'</font>';
		showtablerow('',array('width="100"'), $table);
		showsubmit('forumset', 'submit', '', '');
    	showtablefooter(); /*dism·taobao·com*/
		exit();
		
	}
    showtableheader(lang('plugin/keke_tixian', 'lang15'));
    showsubtitle(array('ID', lang('plugin/keke_tixian', 'lang16'), lang('plugin/keke_tixian', 'lang17'),lang('plugin/keke_tixian', 'lang18'), lang('plugin/keke_tixian', 'lang19'),lang('plugin/keke_tixian', 'lang20'),lang('plugin/keke_tixian', 'lang21')));
	loadcache('keke_tixian');
	$creditdata=$_G['cache']['keke_tixian'] ? $_G['cache']['keke_tixian'] : $creditdata=C::t('#keke_tixian#keke_tixian_credit')->fetchall_credit();
	$returnset=_getauto();
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = C::t('#keke_tixian#keke_tixian')->count_by_all();
	if($allcount){
		$query = C::t('#keke_tixian#keke_tixian')->fetch_all_by_all(0,0,$startlimit,$ppp);
		foreach($query as $val){
			$carddata=_getcarddata($val['cardid']);
			$sxf=$creditdata[$val['credittype']]['sxf'];
			$bili=$val['bili']>0?$val['bili']:$creditdata[$val['credittype']]['bili'];
			$money='<div style="width:100px;color:#c30;height:30px;line-height:30px;font-family:Microsoft YaHei; font-size:12px; font-weight:bold ">'.$val['money'].' '.lang('plugin/keke_tixian', 'lang03').'</div><font color="#999">'.$val['credit'].$_G['setting']['extcredits'][$val['credittype']]['title'].' * '.(100-$sxf).lang('plugin/keke_tixian', 'lang22').$bili.lang('plugin/keke_tixian', 'lang23').$val['money'].lang('plugin/keke_tixian', 'lang03').'</font>';
			$time=dgmdate($val['time'], 'Y/m/d H:i:s');
			$endtime='<font color="#999">'.dgmdate($val['endtime'], 'Y/m/d H:i:s').'</font>';
			$opurl=$keke_tixian['deldd'] ? '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx&ac=dels&orderid='.$val['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'" onClick="return confirm(\''.lang('plugin/keke_tixian', 'lang24').'\');">'.lang('plugin/keke_tixian', 'lang25').'</a>' : "<font color='#CCCCCC'>".lang('plugin/keke_tixian', 'lang25').'</font>';
			if($val['state']==1){
				$isauto=$payment_no='';
				if($val['isauto']){
					$autotxt=$val['isauto']==1?lang('plugin/keke_tixian', 'lang98'):lang('plugin/keke_tixian', 'lang99');
					$isauto='<span style="color:#090;line-height:30px">'.$autotxt.'</span>  <font color="#ccc"> | </font>   ';
					$payment_no=$val['err_code_des']?'<br><font color=#999>'.lang('plugin/keke_tixian', 'lang100').' '.$val['err_code_des'].'</font>':'';
				}
				$stat='<font color="#33CC33">'.lang('plugin/keke_tixian', 'lang26').'</font>  <font color="#ccc"> | </font>  '.$isauto.$endtime .$payment_no;
			}elseif($val['state']==2){
				$stat='<font color="#666">'.lang('plugin/keke_tixian', 'lang27').'</font>  <font color="#ccc"> | </font>   '.$endtime.'<p style="margin-top:3px; color:#F90;max-width:190px;"> '.$val['tuiyuanyin'].'</p>';
			}else{
				$err_code_des=$val['err_code_des']?' <font color="#ccc"> | </font>  <span style="color:#c30;line-height:23px">'.lang('plugin/keke_tixian', 'lang101').'<br/><span style="color:#999;width: 280px;float: left;">'.lang('plugin/keke_tixian', 'lang102').' '.$val['err_code_des'].'</span></span>':'';
				$stat='<font color="#FF3333">'.lang('plugin/keke_tixian', 'lang28').'</font>'.$err_code_des;
				//一键打款
				
				$paybtns=($carddata['type']==5 && $returnset['appid'] && $returnset['secert'] && $returnset['mchid'] && $returnset['shkey']) || ($carddata['type']==2 && $returnset['zfbgy'] && $returnset['zfbsy'])?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx&cardtype='.$carddata['type'].'&ac=pays&page='.$_GET['page'].'&orderid='.$val['id'].'&formhash='.FORMHASH.'" onClick="return confirm(\''.lang('plugin/keke_tixian', 'lang70').' \');">'.lang('plugin/keke_tixian', 'lang103').'</a> / ':'';
				
				$opurl=$paybtns.'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx&ac=ok&orderid='.$val['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'" onClick="return confirm(\''.lang('plugin/keke_tixian', 'lang29').' \');">'.lang('plugin/keke_tixian', 'lang30').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_tixian&pmod=admin_tx&ac=tui&orderid='.$val['id'].'&page='.$_GET['page'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_tixian', 'lang32').'</a> / '.$opurl;
			}
			
			$qrcode='';
			if(($val['cardtypeid']==1 || $val['cardtypeid']==2 && !$returnset['zfbsy']) && $val['qrcodeurl']){
				$qrcode=' / <span class="imgbox"><a href="'.$val['qrcodeurl'].'" target="_blank" class="imgsize" onmouseover="$(\'icon'.$val['id'].'\').style.display=\'block\'" onmouseout="$(\'icon'.$val['id'].'\').style.display=\'none\'" />'.lang('plugin/keke_tixian', 'lang121').'</a><img id="icon'.$val['id'].'" src="'.$val['qrcodeurl'].'"  class="imgprevew" /></span> ';
			}
			
			$table = array();
			$table[0] = $val['id'];
			$table[1] = '<a href="'.ADMINSCRIPT.'?frames=yes&action=logs&operation=credit&srch_uid='.$val['uid'].'&frame=yes" target="_blank">'.$val['usname'].'</a>';
			$table[2] = $money;
			$table[3] = $val['cardtypeid']==5?$val['cardtype'].'<font color="#999"> / </font><img style="vertical-align:middle; margin:0 5px 0 0; border-radius: 3px;" src="'.$carddata['headimg'].'" width="20" height="20">'.$val['cardname']:$val['cardtype'].' <font color="#999">/</font> '.$val['cardon'] .' <font color="#999">/</font> '.$val['cardname'].$qrcode;
			$table[4] = $time;
			$table[5] = $stat;
			$table[6] = $opurl;
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	echo '<tr class="hover"><td colspan="7">'.$multipage.'</td></tr>';
    showtablefooter(); /*dism·taobao·com*/
?>

<style>
.imgsize{height:25px;vertical-align:middle;cursor:pointer; margin-left:10px;}
.imgprevew{position:absolute;z-index:999;border:1px solid #eee;left:0; bottom:20px; max-width:100px; display:none}
.imgbox{ position:relative; }
</style>