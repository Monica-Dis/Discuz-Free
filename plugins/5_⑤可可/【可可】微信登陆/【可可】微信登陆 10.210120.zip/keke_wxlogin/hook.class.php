<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_keke_wxlogin {
	function global_login_extra(){
		global $_G;
		$retrun= '<div class="fastlg_fm y" style="margin-right: 10px; padding-right: 10px">
				<p><a href="javascript:;" onclick="showWindow(\'keke_wxlogin\', \'plugin.php?id=keke_wxlogin:show_qrcode\');return false;"><img src="source/plugin/keke_wxlogin/template/images/login.png"></a></p>
				<p class="hm xg1" style="padding-top: 2px;">'.lang('plugin/keke_wxlogin', '006').'</p>
				</div>';
		return $retrun;
	}
	
	function logging_method(){
        global $_G;
        return '<a href="javascript:;" onclick="showWindow(\'keke_wxlogin\', \'plugin.php?id=keke_wxlogin:show_qrcode\')"><img src="source/plugin/keke_wxlogin/template/images/login.png" align="absmiddle"></a> ';
    }
	
	function global_login_text(){
        return $this->logging_method();
    }
	
	
	function _checkwx(){
		$inwx= strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false ? true : false ;
		return $inwx;
	}
	
	function register_logging_method(){
        global $_G;
        return '<a href="javascript:;" onclick="showWindow(\'keke_wxlogin\', \'plugin.php?id=keke_wxlogin:show_qrcode\')"><img src="source/plugin/keke_wxlogin/template/images/login.png" align="absmiddle"></a> ';
    }


	function global_usernav_extra1(){
        global $_G;
		$ico=$_G['uid']?'bind.png':'login.png';
		$btn='<span class="pipe">|</span><a href="javascript:;" onclick="showWindow(\'keke_wxlogin\', \'plugin.php?id=keke_wxlogin:show_qrcode\')"><img src="source/plugin/keke_wxlogin/template/images/'.$ico.'" class="qq_bind" align="absmiddle"></a>';
        if($_G['uid']){
            $checkbind = C::t('#keke_wxlogin#keke_wxlogin')->fetch($_G['uid']);
            if($checkbind){
                $btn = '';
            }
        }
        return $btn;
    }
	
	
}


class plugin_keke_wxlogin_member extends plugin_keke_wxlogin{
}

class plugin_keke_wxlogin_connect extends plugin_keke_wxlogin{
}

class mobileplugin_keke_wxlogin extends plugin_keke_wxlogin{
	function global_header_mobile(){
		global $_G;
		$keke_wxlogin = $_G['cache']['plugin']['keke_wxlogin'];
		$brurl = $this->_get_urls();
		$brurl = urlencode($brurl);
		if(strpos($brurl, 'logout') !== false){
			dsetcookie('autologin', 1, 30);
		}
		if(!$_G['uid'] && $this->_checkwx() && $keke_wxlogin['auto'] && !$_G['cookie']['autologin'] && !$_GET['version'] && !$_GET['statfrom'] && strpos($brurl, 'logout') === false &&  !$_G['inajax'] && CURSCRIPT!='plugin' && CURSCRIPT!='member' && CURSCRIPT!='check'){
			$redirect_base='plugin.php?id=keke_wxlogin:login&brurl='.$brurl; 
			dheader('location: '.$redirect_base);
		}
	}
	
	function _get_urls($related = 0) {
        $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
        return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
    }
}


class mobileplugin_keke_wxlogin_member extends plugin_keke_wxlogin{
	function logging_bottom_mobile(){
		global $_G;
		$keke_wxlogin = $_G['cache']['plugin']['keke_wxlogin'];
		$inwx= strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false ? true : false ;
		if($keke_wxlogin['loginpage']){
			if(!(strtolower($_SERVER['REQUEST_METHOD'])=='get')){
				return false;
			}
			if (!($_GET['action']=='login')) {
				return false;
			}
			
			$referer = $_SERVER['HTTP_REFERER'];
			if(strpos($referer, 'http') === false){
				$referer = $_G['siteurl'] . $referer;
			}
			
			$logo = "<img src=\"source/plugin/keke_wxlogin/template/images/logo.png\" width=\"198\" />";
			$loginhash = 'L'.random(4);
			if($_G['uid']) {
				header('Location:'.($referer ? $referer : 'index.php'));
			}
			$inwx=$this->_checkwx();
			$wehaturl = $_G['siteurl'] . "plugin.php?id=keke_wxlogin:login";
			if(function_exists('seccheck')){
				list($seccodecheck) = seccheck('login');
				if(!empty($_GET['auth'])) {
					$dauth = authcode($_GET['auth'], 'DECODE', $_G['config']['security']['authkey']);
					list(,,,$secchecklogin2) = explode("\t", $dauth);
					if($secchecklogin2) {
						$seccodecheck = true;
					}
				}
				$seccodestatus = !empty($_GET['lssubmit']) ? false : $seccodecheck;
				$invite = getinvite();
				if($seccodecheck) {
					$seccode = random(6, 1) + $seccode{0} * 1000000;
				}
			}
			$regname=$_G['setting']['regname']?$_G['setting']['regname']:'register';
			include template('keke_wxlogin:login');
			dexit();
		}
		include template('keke_wxlogin:login_block');
		return $return;
	}
}