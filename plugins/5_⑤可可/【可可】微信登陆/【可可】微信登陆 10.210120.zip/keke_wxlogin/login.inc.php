<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
header("Last-Modified: ".gmdate("D, d M Y H:i:s")." GMT");
header("Cache-Control: no-cache, must-revalidate");
header("Pramga: no-cache");

global $_G;
$keke_wxlogin = $_G['cache']['plugin']['keke_wxlogin'];
$codes=dhtmlspecialchars($_GET['codes']);
include_once DISCUZ_ROOT.'source/plugin/keke_wxlogin/function/function_fun.php';
if(submitcheck('regsubmit')){
	include_once libfile('function/cache');
	include_once libfile('function/member');
	$wx_headimgurl = authcode($_G['cookie']['wx_headimgurl'], 'DECODE', $_G['config']['security']['authkey']);
	$wx_autosid= authcode($_G['cookie']['wx_autosid'], 'DECODE', $_G['config']['security']['authkey']);
	$openid= authcode($_G['cookie'][$usopidkey], 'DECODE', $_G['config']['security']['authkey']);
	if($_GET['regac']==1){
		$usname = trim(addslashes($_GET['username']));
		$pwd=trim(addslashes($_GET['password']));
		if(!$usname){
			showmessage(lang('plugin/keke_wxlogin', '007'));
		}
		if(!$pwd){
			showmessage(lang('plugin/keke_wxlogin', '008'));
		}
		$invite = array();
		if(!$keke_wxlogin['invite'] && $_G['setting']['regstatus'] == 2){
			$invite = getinvite();		
			if(empty($invite) && !$invitestatus) {
				showmessage('not_open_registration_invite');
			}
		}
		$uid = wxregister($usname, $pwd);
		if($invite['id']) {
			$result = C::t('common_invite')->count_by_uid_fuid($invite['uid'], $uid);
			if(!$result) {
				C::t('common_invite')->update($invite['id'], array('fuid'=>$uid, 'fusername'=>$usname, 'regdateline' => $_G['timestamp'], 'status' => 2));
				updatestat('invite');
			} else {
				$invite = array();
			}
		}
		
		setvatar($uid, $wx_headimgurl);
		$isregister=0;
		
	}else{
		if(!($loginperm = logincheck($_GET['username']))) {
			showmessage('login_strike');
		}
		if(!$_GET['password'] || $_GET['password'] != addslashes($_GET['password'])) {
			showmessage('profile_passwd_illegal');
		}
		$result = userlogin($_GET['username'], $_GET['password'], $_GET['questionid'], $_GET['answer'], $_G['setting']['autoidselect'] ? 'auto' : $_GET['loginfield'], $_G['clientip']);
		if($result['status'] <= 0) {
			loginfailed($_GET['username']);
			failedip();
			showmessage('login_invalid', '', array('loginperm' => $loginperm - 1));
		}
		$uid = $result['member']['uid'];
		$isregister=0;
	}
	C::t('#keke_wxlogin#keke_wxlogin')->insert(array('uid'=>$uid,'openid'=>$openid,'isregister'=>$isregister,'time'=>TIMESTAMP),true);
	_acloginstate($uid);
	C::t('#keke_wxlogin#keke_wxlogin_authcode')->update($wx_autosid, array('uid' => $uid, 'status' => 1));
 	$urlsa = $_G['siteurl'];
	dheader('location: '.$urlsa);
}

if(_checkwx()){
	$redirect_uri = _getwxreuri();
	$access_tokenarr=_getaccesstoken($redirect_uri);
	$openid=$access_tokenarr['openid'];
	$access_tokens=$access_tokenarr['access_token'];
	$usdata=_getwxusdatas($openid,1);
	$code=authcode(base64_decode($codes), 'DECODE', $_G['config']['security']['authkey']);
	$authcode = C::t('#keke_wxlogin#keke_wxlogin_authcode')->fetch_by_code($code);
	if($usdata['uid']){
		$uid=$usdata['uid'];  
	}else{		
		if($authcode['uid']){ 
			$uid=$authcode['uid'];
			$isregister=0;
		}elseif(!$authcode['uid'] && $_G['uid']){
			$uid=$_G['uid'];
		}else{
			if(!$openid){
				$redi='plugin.php?id=keke_wxlogin:login&brurl='.urlencode('plugin.php?id=keke_wxlogin:login'); 
				dheader('location: '.$redi);
			}
			$user_data = _getusdataapi($access_tokens,$openid);
			dsetcookie($usopidkey, authcode($openid, 'ENCODE', $_G['config']['security']['authkey']), 7000);
			dsetcookie('wx_headimgurl', authcode($user_data['headimgurl'], 'ENCODE', $_G['config']['security']['authkey']), 7000);
			dsetcookie('wx_autosid', authcode($authcode['sid'], 'ENCODE', $_G['config']['security']['authkey']), 7000);
			if(!$keke_wxlogin['bind']){
				$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
				$regstatus = C::t('common_setting')->fetch_all(array('regstatus'));
				$usnames=lgutf2gbk(KekeFilterEmoji($user_data['nickname']));
				$navtitle=lang('plugin/keke_wxlogin', '009');
				$keke_wxlogin['bottom']=dhtmlspecialchars($keke_wxlogin['bottom']);
				include template('keke_wxlogin:register');
				exit;
			}else{
				$nickname=lgutf2gbk(KekeFilterEmoji($user_data['nickname']));
				$nickuid = C::t('common_member')->fetch_uid_by_username($nickname);
				$usname=$nickuid?$nickname.random(3):$nickname;
				$pwd=md5(random(10));
				$uid = wxregister($usname, $pwd);
				setvatar($uid, $user_data['headimgurl']);
				$isregister=1;
			}
		}
		C::t('#keke_wxlogin#keke_wxlogin')->insert(array('uid'=>$uid,'openid'=>$openid,'isregister'=>$isregister,'time'=>TIMESTAMP),true);
	}
	_acloginstate($uid);
	C::t('#keke_wxlogin#keke_wxlogin_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
 	$urlsa = $_G['siteurl'].'/index.php';
	if($_GET['brurl']){
		$urlsa = $_GET['brurl'];
		if(strpos($_GET['brurl'], 'http') === false){
            $urlsa = $_G['siteurl'] . $_GET['brurl'];
        }
		$urlsa =urldecode($urlsa);
	}
	header("Location: ".$urlsa);
}