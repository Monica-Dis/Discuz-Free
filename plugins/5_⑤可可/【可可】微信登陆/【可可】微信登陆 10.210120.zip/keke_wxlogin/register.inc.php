<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
global $_G;
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
include_once DISCUZ_ROOT.'source/plugin/keke_wxlogin/function/function_fun.php';
$usdata=_getwxusdatas($_G['uid'],2);

if(submitcheck('setpwdsubmit') && $usdata['isregister']) {
    if($_G['setting']['strongpw']) {
        $strongpw_str = array();
        if(in_array(1, $_G['setting']['strongpw']) && !preg_match("/\d+/", $_GET['newpassword1'])) {
            $strongpw_str[] = lang('member/template', 'strongpw_1');
        }
        if(in_array(2, $_G['setting']['strongpw']) && !preg_match("/[a-z]+/", $_GET['newpassword1'])) {
            $strongpw_str[] = lang('member/template', 'strongpw_2');
        }
        if(in_array(3, $_G['setting']['strongpw']) && !preg_match("/[A-Z]+/", $_GET['newpassword1'])) {
            $strongpw_str[] = lang('member/template', 'strongpw_3');
        }
        if(in_array(4, $_G['setting']['strongpw']) && !preg_match("/[^a-zA-z0-9]+/", $_GET['newpassword1'])) {
            $strongpw_str[] = lang('member/template', 'strongpw_4');
        }
        if($strongpw_str) {
            showmessage(lang('member/template', 'password_weak').implode(',', $strongpw_str));
        }
    }
    if($_GET['newpassword1'] !== $_GET['newpassword2']) {
        showmessage('profile_passwd_notmatch');
    }
    if(!$_GET['newpassword1'] || $_GET['newpassword1'] != addslashes($_GET['newpassword1'])) {
        showmessage('profile_passwd_illegal');
    }

    loaducenter();
	uc_user_edit(addslashes($_G['member']['username']), null, addslashes($_GET['newpassword1']), null, 1);
	C::t('common_member')->update($_G['uid'], array('password' => md5(random(10))));
	C::t('#keke_wxlogin#keke_wxlogin')->update($_G['uid'], array('isregister' => 0));
	
	showmessage(lang('plugin/keke_wxlogin', '010'), dreferer());
} elseif(submitcheck('unbindsubmit')) {
	C::t('#keke_wxlogin#keke_wxlogin')->delete($_G['uid']);
	showmessage(lang('plugin/keke_wxlogin', '011'), $_G['siteurl']);
}

