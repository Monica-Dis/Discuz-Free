<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
include_once DISCUZ_ROOT."source/plugin/keke_wxlogin/identity.inc.php";

function _getusallcount($wheres=''){
	return C::t('#keke_wxlogin#keke_wxlogin')->count_all($wheres);
}

function _getusall($startlimit,$ppp,$wheres=''){
	$usdata= C::t('#keke_wxlogin#keke_wxlogin')->fetch_all_by_limit($startlimit,$ppp,$wheres);
	return $usdata;
	
}

function _checkwx(){
	$inwx= strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false ? true : false ;
	return $inwx;
}

function _getwxusdatas($ouid,$type){
	if($type==2){
		$usdata=C::t("#keke_wxlogin#keke_wxlogin")->fetch_by_uid($ouid);
	}else{
		$usdata=C::t("#keke_wxlogin#keke_wxlogin")->fetch_by_openid($ouid);
	}
	return $usdata;
}

function _getusdataapi($access_tokens,$openid){
	$url='https://api.weixin.qq.com/sns/userinfo?access_token='.$access_tokens.'&openid='.$openid.'&lang=zh_CN';
	$json = dfsockopen($url);
	$user_data = json_decode($json, true);
	return $user_data;
}


function _getaccesstoken($redirect_uri){
	global $_G;
	$keke_wxlogin = $_G['cache']['plugin']['keke_wxlogin'];
	$appid=trim($keke_wxlogin['appid']);
	$secret=trim($keke_wxlogin['appsecert']);
	$redirect_base = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$appid.'&redirect_uri='.$redirect_uri.'&response_type=code&scope=snsapi_userinfo&state=1#wechat_redirect';
	if(empty($_GET['code'])) {
		dheader('location: '.$redirect_base);
	}else{
		$code=dhtmlspecialchars($_GET['code']);
		$get_acctokenurl='https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$appid.'&secret='.$secret.'&code='.$code.'&grant_type=authorization_code';
		$access_tokendata=dfsockopen($get_acctokenurl);
		$access_tokenarr=json_decode($access_tokendata, true);
		return $access_tokenarr;
	}
}

function _getwxreuri(){
	global $_G;
	$keke_wxlogin = $_G['cache']['plugin']['keke_wxlogin'];
	$codes=dhtmlspecialchars($_GET['codes']);
	$brurl=urlencode($_GET['brurl']);
	$redirect_uri = urlencode($_G['siteurl'].'plugin.php?id=keke_wxlogin:login&codes='.$codes.'&brurl='.$brurl);
	if($keke_wxlogin['borurl']){
		$bordomain=dhtmlspecialchars($keke_wxlogin['borurl']);
		$borrowuri=$bordomain.'KKOAuth.php?rurl='.$redirect_uri;
		$redirect_uri = urlencode($borrowuri);
	}
	return $redirect_uri;
}

function lgutf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return lggbk2utf($data);
	}
}

function lggbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}

function wxregister($username,$pwd='', $return = 0, $groupid = 0) {
	global $_G;
	$keke_wxlogin = $_G['cache']['plugin']['keke_wxlogin'];
	if(!$username) {
		return;
	}
	loaducenter();
	$groupid = !$groupid ? ($keke_wxlogin['newgroup'] ? $keke_wxlogin['newgroup'] : $_G['setting']['newusergroupid']) : $groupid;
	$password = $pwd?$pwd:md5(random(10));
	$email = 'wechat_'.strtolower(random(10)).'@null.null';

	$usernamelen = dstrlen($username);
	if($usernamelen < 3) {
		$username = $username.'_'.random(5);
	}
	if($usernamelen > 15) {
		$username = cutstr($username, 15, '');
	}
	
	$checkname=C::t('common_member')->fetch_by_username($username);
	if($checkname || !(uc_user_checkname($username)=='1')){
		if(!$keke_wxlogin['bind']){
			showmessage(lang('plugin/keke_wxlogin', '001'));
		}
		$username =  cutstr($username, 12, '').''.random(3);
	}
	
	$censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';
 	$_G['setting']['censoruser'] && @preg_replace($censorexp, '_', $username);

	$uid = uc_user_register(addslashes($username), addslashes($password), $email, '', '', $_G['clientip']);
	if($uid <= 0) {
		if(!$return) {
			if($uid == -1) {
				showmessage('profile_username_illegal');
			} elseif($uid == -2) {
				showmessage('profile_username_protect');
			} elseif($uid == -3) {
				showmessage('profile_username_duplicate');
			} elseif($uid == -4) {
				showmessage('profile_email_illegal');
			} elseif($uid == -5) {
				showmessage('profile_email_domain_illegal');
			} elseif($uid == -6) {
				showmessage('profile_email_duplicate');
			} else {
				showmessage('undefined_action');
			}
		} else {
			return;
		}
	}

	$init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
	C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

	if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
		C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
		if($_G['setting']['regctrl']) {
			C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
		}
	}

	if($_G['setting']['regverify'] == 2) {
		C::t('common_member_validate')->insert(array(
			'uid' => $uid,
			'submitdate' => $_G['timestamp'],
			'moddate' => 0,
			'admin' => '',
			'submittimes' => 1,
			'status' => 0,
			'message' => '',
			'remark' => '',
		), false, true);
		manage_addnotify('verifyuser');
	}


	include_once libfile('function/stat');
	updatestat('register'); 

	return $uid;
}

function _acloginstate($uid){
	include_once libfile('function/member');
	if (!($member = getuserbyuid($uid, 1))) {
        return false;
    }
    if (isset($member['_inarchive'])) {
        C::t('common_member_archive')->move_to_master($member['uid']);
    }
    require_once libfile('function/member');
    $cookietime = 1296000;
    setloginstatus($member, $cookietime);
}




function setvatar($uid, $avatar) {
    if(!$uid || !$avatar) {
        return false;
    }
    if(!$content = dfsockopen($avatar)) {
        return false;
    }
    $tmpFile = DISCUZ_ROOT.'./data/avatar/'.TIMESTAMP.random(6);
    file_put_contents($tmpFile, $content);
    if(!is_file($tmpFile)) {
        return false;
    }
    $result = kkuploadUcAvatar::upload($uid, $tmpFile);
    unlink($tmpFile);

    C::t('common_member')->update($uid, array('avatarstatus'=>'1'));

    return $result;
}


function KekeFilterEmoji($str){
    $str = preg_replace_callback(
        '/./u',
        function (array $match) {
            return strlen($match[0]) >= 4 ? '' : $match[0];
        },
        $str);
    return $str;
}


class kkuploadUcAvatar {
	public static function upload($uid, $localFile) {
		global $_G;
		if(!$uid || !$localFile) {
			return false;
		}

		list($width, $height, $type, $attr) = getimagesize($localFile);
		if(!$width) {
			return false;
		}

		if($width < 10 || $height < 10 || $type == 4) {
			return false;
		}

		$imageType = array(1 => '.gif', 2 => '.jpg', 3 => '.png');
		$fileType = $imgType[$type];
		if(!$fileType) {
			$fileType = '.jpg';
		}
		$avatarPath = $_G['setting']['attachdir'];
		$tmpAvatar = $avatarPath.'./temp/upload'.$uid.$fileType;
		file_exists($tmpAvatar) && @unlink($tmpAvatar);
		file_put_contents($tmpAvatar, file_get_contents($localFile));

		if(!is_file($tmpAvatar)) {
			return false;
		}

		$tmpAvatarBig = './temp/upload'.$uid.'big'.$fileType;
		$tmpAvatarMiddle = './temp/upload'.$uid.'middle'.$fileType;
		$tmpAvatarSmall = './temp/upload'.$uid.'small'.$fileType;

		$image = new image;
		if($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
			return false;
		}
		if($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
			return false;
		}
		if($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
			return false;
		}

		$tmpAvatarBig = $avatarPath.$tmpAvatarBig;
		$tmpAvatarMiddle = $avatarPath.$tmpAvatarMiddle;
		$tmpAvatarSmall = $avatarPath.$tmpAvatarSmall;

		$avatar1 = self::byte2hex(file_get_contents($tmpAvatarBig));
		$avatar2 = self::byte2hex(file_get_contents($tmpAvatarMiddle));
		$avatar3 = self::byte2hex(file_get_contents($tmpAvatarSmall));

		$extra = '&avatar1='.$avatar1.'&avatar2='.$avatar2.'&avatar3='.$avatar3;
		$result = self::uc_api_post_ex('user', 'rectavatar', array('uid' => $uid), $extra);


		@unlink($tmpAvatar);
		@unlink($tmpAvatarBig);
		@unlink($tmpAvatarMiddle);
		@unlink($tmpAvatarSmall);

		return true;
	}

	public static function byte2hex($string) {
		$buffer = '';
		$value = unpack('H*', $string);
		$value = str_split($value[1], 2);
		$b = '';
		foreach($value as $k => $v) {
			$b .= strtoupper($v);
		}

		return $b;
	}

	public static function uc_api_post_ex($module, $action, $arg = array(), $extra = '') {
		$s = $sep = '';
		foreach($arg as $k => $v) {
			$k = urlencode($k);
			if(is_array($v)) {
				$s2 = $sep2 = '';
				foreach($v as $k2 => $v2) {
					$k2 = urlencode($k2);
					$s2 .= "$sep2{$k}[$k2]=".urlencode(uc_stripslashes($v2));
					$sep2 = '&';
				}
				$s .= $sep.$s2;
			} else {
				$s .= "$sep$k=".urlencode(uc_stripslashes($v));
			}
			$sep = '&';
		}
		$postdata = uc_api_requestdata($module, $action, $s, $extra);
		return uc_fopen2(UC_API.'/index.php', 500000, $postdata, '', TRUE, UC_IP, 20);
	}
}

$usopidkey= substr(md5('keke_wxlogin'.$_G['siteurl']), 0, 7);