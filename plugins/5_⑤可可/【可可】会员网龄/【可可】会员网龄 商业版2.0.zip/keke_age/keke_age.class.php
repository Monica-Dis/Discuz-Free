<?
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}



class plugin_keke_age_forum{
	
	
	function viewthread_sidetop_output(){
		return $this->getdata('1');	
		}
	function viewthread_sidebottom_output(){
		return $this->getdata('2');	
		}	
	
	
	 function getdata($i){
		global $_G, $postlist;
		$keke_age=$_G['cache']['plugin']['keke_age'];
		$result=array();
		$pid=array();
		if($keke_age['qrd']==$i){
			$description=empty($keke_age['description'])? lang('plugin/keke_age', 'description') : $keke_age['description'];
			$unit=empty($keke_age['unit'])? lang('plugin/keke_age', 'unit') : $keke_age['unit'];
			
			foreach($postlist as $pids)
			{
				array_push($pid,$pids['pid']);
			}
			if($keke_age['cycle']==1)$cycle=604800;elseif($keke_age['cycle']==2)$cycle=2592000;elseif($keke_age['cycle']==3)$cycle=31104000;
			$group = empty($keke_age['xsyhz']) ? array() : unserialize($keke_age['xsyhz']);
			for($i=0;$i<count($postlist);$i++)
			{
				
				$reg=strtotime($postlist[$pid[$i]]['regdate']);
				$y=number_format(($_G['timestamp']-$reg)/$cycle,$keke_age['xsd']);
				$return='<dl class="pil cl" style=" margin-top:10px; margin-bottom:10px;"> <dt style="color:'.$keke_age['msys'].'">'.dhtmlspecialchars($description).'</dt><dd style="color:'.$keke_age['color'].'">'.$y.dhtmlspecialchars($unit).'</dd></dl>';
				if(!(empty($group[0]) || in_array($postlist[$pid[$i]]['groupid'],$group))){$return='';}
				array_push($result,$return);
			}
			return $result;
			
			
			}
		}
	}