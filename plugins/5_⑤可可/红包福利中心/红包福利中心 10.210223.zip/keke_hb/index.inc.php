<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
global $_G;
$keke_hb = $_G['cache']['plugin']['keke_hb'];
$creditname=$_G['setting']['extcredits'][$keke_hb['jf']]['title'];
$navtitle=dhtmlspecialchars($keke_hb['pctitle']);
$wapnavtitle=dhtmlspecialchars($keke_hb['waptitle']);
/*DisM-taobao��Com*/include_once DISCUZ_ROOT . './source/plugin/keke_hb/function/function_fun.php';
$ac=$_GET['ac'];
if($ac=='my'){
	$myhblist=_get_myhb($_G['uid']);
	$hbcount=_get_countmyhb($_G['uid']);
}else{
	$hbdata=_get_currentdata();
	$iscur=0;
	if($hbdata){
		if($hbdata['total']>0){
			if($hbdata['time']<$_G['timestamp'] && $hbdata['endtime']>$_G['timestamp']){
				$iscur=1;
			}
			$count=C::t('#keke_hb#keke_hb_log')->count_by_uid($_G['uid'],$hbdata['id']);
			$cs=$hbdata['num']-$count;
			$hbdata['total']=intval($hbdata['total']);
		}else{
			$iscur=3;
		}
		
		if($hbdata['xh']){
			$creditnames=$_G['setting']['extcredits'][$hbdata['xhlx']]['title'];
		}
		$stime=dgmdate($hbdata['time'], 'Y/m/d H:i:s');
		$etime=dgmdate($hbdata['endtime'], 'Y/m/d H:i:s');
		$stimes=dgmdate($hbdata['time'], 'Y&#24180;m&#26376;d&#26085; H:i:s');
		$etimes=dgmdate($hbdata['endtime'], 'Y&#24180;m&#26376;d&#26085; H:i:s');
		
	}else{
		$iscur=2;
	}
	$hdgz=nl2br(dhtmlspecialchars($keke_hb['gz']));
	$gzurl=dhtmlspecialchars($keke_hb['gzurl']);
	$sx=$keke_hb['sx'] ? intval($keke_hb['sx']) : 1000;
	
	$hblist=C::t('#keke_hb#keke_hb_log')->fetchall_byid(0,23);
	$n=1;
	$mb2list='<li>';
	foreach($hblist as $k=>$v){
		$time=dgmdate($v['time'],'m/d H:i');
		
		$hbjl.='<li><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td width="85">'.$v['usname'].'</td><td>'.$v['total'].$creditname.'</td><td align="right">'.$time.'</td></tr>
</table></li>';
		$mb2list.='<div class="icon-wp"><span class="hbava"><img src="uc_server/avatar.php?uid='.$v['uid'].'&amp;size=middle"/></span><span><b>'.$v['usname'].'</b></span><span>'.lang('plugin/keke_hb', 'f0020').$v['total'].$creditname.'</span><span>'.$time.'</span></div>';
		if($n%4==0)$mb2list.='</li><li>';
		$n++;
	}
	$mb2list.='</li>';
	

	
	
	$hdygarr=DB::fetch_all("select * from ".DB::table('keke_hb')." where time>".$_G['timestamp']."  ORDER BY time ASC limit 3");
	foreach($hdygarr as $hdval){
		$stimes=dgmdate($hdval['time'], 'Y/m/d H:i:s');
		$etimes=dgmdate($hdval['endtime'], 'Y/m/d H:i:s');
		$waphtml.='<p><strong>'.$hdval['name'].'</strong><br> '.$stimes.' '.lang('plugin/keke_hb', 'f0021').'<br>'.$etimes.' '.lang('plugin/keke_hb', 'f0022').'</p>';
		$yghtm.='<li><h2>'.$hdval['name'].'</h2><p>'.$stimes.' '.lang('plugin/keke_hb', 'f0021').'</p><p>'.$etimes.' '.lang('plugin/keke_hb', 'f0022').'</p></li>';
	}
	$xhcredit=1;
	if($hbdata['xh']){
		$xhlxnowcredit = getuserprofile('extcredits'.$hbdata['xhlx']);
		if($xhlxnowcredit<$hbdata['xh']){$xhcredit=0;}
		$xhtip=lang('plugin/keke_hb', 'f0025').' '.$_G['setting']['extcredits'][$hbdata['xhlx']]['title'].' '.lang('plugin/keke_hb', 'f0026');
	}
}



$isgl=1;
$glz=explode(",",$keke_hb['glz']);
if(!(in_array($_G['uid'],$glz))){
	$isgl=0;
}
$yhz = empty($keke_hb['yhz']) ? array() : unserialize($keke_hb['yhz']);
if(!(empty($yhz[0]) || in_array($_G['groupid'],$yhz))){
	$isqx=0;
}else{
	$isqx=1;
}
$wqx=lang('plugin/keke_hb', 'f0014');
if($keke_hb['ts'] && $isqx && $hbdata['xh']>0){
	$keke_hb['ts']=1;
}else{
	$keke_hb['ts']=0;
}
if($keke_hb['mb']==2){
	include template('keke_hb:index_1');
}
else{
	include template('keke_hb:index');
}
