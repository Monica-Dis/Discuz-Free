<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

global $_G;
$keke_hb = $_G['cache']['plugin']['keke_hb'];
/*DisM-taobao��Com*/include_once DISCUZ_ROOT . './source/plugin/keke_hb/function/function_fun.php';
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}

if($_GET['formhash'] != $_G['formhash']) {
	return;
}
$ac=$_GET['ac'];
$creditname=$_G['setting']['extcredits'][$keke_hb['jf']]['title'];
$nowcredit = getuserprofile('extcredits'.$keke_hb['jf']);
$hbid=intval($_GET['hbid']);
if(!discuz_process::islocked('gethb_checklocked', 5)) {
	$hbdata=C::t('#keke_hb#keke_hb')->fetch_all($hbid);
	discuz_process::unlock('gethb_checklocked');
}else{
	showmessage(lang('plugin/keke_hb', 'f0033'));
}
$hbdata=$hbdata[$hbid];

if($ac=='qiang'){
	if($hbdata['time']>$_G['timestamp'] || $hbdata['endtime']<$_G['timestamp'])showmessage(lang('plugin/keke_hb', 'f0013'));
	$yhz = empty($keke_hb['yhz']) ? array() : unserialize($keke_hb['yhz']);
	if(!(empty($yhz[0]) || in_array($_G['groupid'],$yhz))){
		showmessage(lang('plugin/keke_hb', 'f0014'));
		exit();
	}
	if(!discuz_process::islocked('getuidcount_checklocked', 5)) {
		$count=C::t('#keke_hb#keke_hb_log')->count_by_uid($_G['uid'],$hbid);
		$rt=_get_jgdata($_G['uid'],$hbid);
		discuz_process::unlock('getuidcount_checklocked');
	}else{
		showmessage(lang('plugin/keke_hb', 'f0033'));
	}
	if($hbdata['xh'] && ($count<$hbdata['num']) && $rt['state']){
		$xhlxnowcredit = getuserprofile('extcredits'.$hbdata['xhlx']);
		if($xhlxnowcredit<$hbdata['xh']){
			showmessage(lang('plugin/keke_hb', 'f0025').' <b>'.$_G['setting']['extcredits'][$hbdata['xhlx']]['title'].'</b> '.lang('plugin/keke_hb', 'f0026'));
			exit();
		}else{
			updatemembercount($_G['uid'], array('extcredits'.$hbdata['xhlx'].''=>-$hbdata['xh']), true, '', 0, '',lang('plugin/keke_hb', 'f0015'),lang('plugin/keke_hb', 'f0023'));
		}
	}
	$gl=$hbdata['gl'] ? intval($hbdata['gl']) : 100;
	if($count>=$hbdata['num']){
		$rand = 3;
	}elseif($hbdata['total']<=0){
		$rand = 5;
	}else{
		if(!$rt['state']){
			showmessage($rt['msg']);
			exit();
		}
		if(mt_rand(1,100) <= $gl) {
			$data=array('total'=>$hbdata['total']-1);
			C::t('#keke_hb#keke_hb')->update($hbid,$data);
			$mianzhi=mt_rand($hbdata['min'],$hbdata['max']);
			updatemembercount($_G['uid'], array('extcredits'.$keke_hb['jf'].''=>$mianzhi), true, '', 0, '',lang('plugin/keke_hb', 'f0015'),lang('plugin/keke_hb', 'f0016'));
			$rand = 1;
		} else { 
			$rand = 0;
			$mianzhi=0;
		}
		
		$arr = array(
			'uid' => $_G['uid'],
			'usname'=> $_G['username'],
			'hbid'=> $hbid,
			'total'=> $mianzhi,
			'time'=> $_G['timestamp'],
			);
		C::t('#keke_hb#keke_hb_log')->insert($arr);
	}
}


if(checkmobile()){
	$randdata = array( 'state' => $rand,'mianzhi'=>$mianzhi,);   
	echo json_encode($randdata);
	exit();
}else{
	include template('keke_hb:show_win');
}