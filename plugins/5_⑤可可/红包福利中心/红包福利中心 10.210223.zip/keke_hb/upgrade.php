<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_hb'));
while($row = DB::fetch($query)) {
	$col[]=$row['Field']; 
}

if(!in_array('xh', $col)){
	$sql = "Alter table ".DB::table('keke_hb')." add `xh` int(50) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('xhlx', $col)){
	$sql = "Alter table ".DB::table('keke_hb')." add `xhlx` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

if(!in_array('jg', $col)){
	$sql = "Alter table ".DB::table('keke_hb')." add `jg` float(10,1) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('jglx', $col)){
	$sql = "Alter table ".DB::table('keke_hb')." add `jglx` int(10) unsigned NOT NULL default 0;"; 
	DB::query($sql); 
}

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/keke_hb/discuz_plugin_keke_hb.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_hb/discuz_plugin_keke_hb_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_hb/discuz_plugin_keke_hb_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_hb/discuz_plugin_keke_hb_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_hb/discuz_plugin_keke_hb_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_hb/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_hb/upgrade.php');

?>