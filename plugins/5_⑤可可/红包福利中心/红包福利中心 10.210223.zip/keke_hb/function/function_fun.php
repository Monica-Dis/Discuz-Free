<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*DisM-taobao��Com*/include_once DISCUZ_ROOT . 'source/plugin/keke_hb/identity.inc.php';
function _get_countmyhb($uid)
{
	return C::t('#keke_hb#keke_hb_log')->count_by_uid($uid);
}
function _get_myhb($uid, $ppp = 10)
{
	global $_G;
	$keke_hb = $_G['cache']['plugin']['keke_hb'];
	$creditname = $_G['setting']['extcredits'][$keke_hb['jf']]['title'];
	$hblist = '';
	$tmpurl = 'plugin.php?id=keke_hb:actions&formhash=' . FORMHASH . '&ac=myhblist&';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = _get_countmyhb($uid);
	$n = 0;
	if ($allcount) {
		$query = C::t('#keke_hb#keke_hb_log')->fetch_all_by_uid($uid, $startlimit, $ppp);
		foreach ($query as $val) {
			if ($n % 2 == 1) {
				$bg = ' class="bgs"';
			} else {
				$bg = '';
			}
			$time = dgmdate($val['time'], 'Y/m/d H:i:s');
			if (!checkmobile()) {
				$showwin = 'onclick="showWindow(\'keke_integralmall\', this.href, \'get\', 0);doane(event);"';
				$fahuowwin = 'onclick="showWindow(\'fahuo\', this.href, \'get\', 0);doane(event);"';
			}
			$hblist .= ' <li><span class="usn">' . $val['usname'] . '</span><span class="jb">+ ' . $val['total'] . $creditname . '</span><span class="time">' . $time . '</span></li>';
			$n = $n + 1;
		}
		$multipage = '';
		$multipage = multi($allcount, $ppp, $page, $_G['siteurl'] . $tmpurl);
		if ($multipage) {
			/*http://t.cn/Aiux1Jx1*/if (checkmobile()) {
				$multipage = str_replace('pg', 'mallpage', $multipage);
			}
			$multipage = str_replace('href=', 'name=', $multipage);
			$multipage = str_replace('name=', 'href=\'javascript:\' onclick=\'myhblist(this.name)\' name=', $multipage);
			$multipage = preg_replace('/<label>(.*)<\\/label>/isU', '', $multipage);
			$hblist .= $multipage . '<div class="counts">' . lang('plugin/keke_hb', 'f0017') . $allcount . lang('plugin/keke_hb', 'f0018') . '</div>';
		}
	} else {
		$hblist = '<div class="nobuy">' . lang('plugin/keke_hb', 'f0019') . '</div>';
	}
	return $hblist;
}
function _get_currentdata()
{
	global $_G;
	$hbdata = C::t('#keke_hb#keke_hb')->fetchfirst_bytime($_G['timestamp']);
	if (!$hbdata) {
		$hbdata = C::t('#keke_hb#keke_hb')->fetchfirst_by_next($_G['timestamp']);
	}
	return $hbdata;
}
function _get_hddata($hdid)
{
	return C::t('#keke_hb#keke_hb')->fetchfirst_byid($hdid);
}
function _get_jgdata($uid, $hbid)
{
	$hbdata = _get_hddata($hbid);
	$total_data = 1;
	if ($hbdata['jg']) {
		$lasttime = C::t('#keke_hb#keke_hb_log')->fetchfirst_lasttime($uid, $hbid);
		if ($hbdata['jglx'] == 1) {
			$bli = 60;
			$lxname = lang('plugin/keke_hb', 'f0027');
		} elseif ($hbdata['jglx'] == 2) {
			$bli = 3600;
			$lxname = lang('plugin/keke_hb', 'f0028');
		} elseif ($hbdata['jglx'] == 3) {
			$bli = 86400;
			$lxname = lang('plugin/keke_hb', 'f0029');
		}
		$jgtime = $hbdata['jg'] * $bli;
		if ($lasttime + $jgtime > TIMESTAMP) {
			$xxtime = dgmdate($lasttime + $jgtime, 'Y-m-d H:i:s');
			$msg = lang('plugin/keke_hb', 'f0030') . floatval($hbdata['jg']) . $lxname . lang('plugin/keke_hb', 'f0031') . $xxtime . lang('plugin/keke_hb', 'f0032');
			$total_data = 0;
		}
	}
	$rt = array('state' => $total_data, 'msg' => $msg);
	return $rt;
}
function utf2gbk($data)
{
	$data = dhtmlspecialchars($data);
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	if (CHARSET == 'gbk') {
		return $tmpstr;
	}
	return gbk2utf($data);
}
function gbk2utf($data)
{
	$data1 = diconv($data, 'utf-8', 'gbk');
	$data0 = diconv($data1, 'gbk', 'utf-8');
	if ($data0 == $data) {
		$tmpstr = $data1;
	} else {
		$tmpstr = $data;
	}
	return diconv($tmpstr, 'gbk', 'utf-8');
}
