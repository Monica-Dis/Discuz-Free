<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}

global $_G;
$keke_hb = $_G['cache']['plugin']['keke_hb'];

if(!$_G['uid']){
    showmessage('not_loggedin', NULL, array(), array('login' => 1));
}

$glz=explode(",",$keke_hb['glz']);
if(!(in_array($_G['uid'],$glz))){
	showmessage(lang('plugin/keke_hb', 'f001'));
}
/*DisM-taobao��Com*/include_once DISCUZ_ROOT . './source/plugin/keke_hb/function/function_fun.php';
$creditname=$_G['setting']['extcredits'][$keke_hb['jf']]['title'];
$nowcredit = getuserprofile('extcredits'.$keke_hb['jf']);

$hbid=intval($_GET['hbid']);
$type=intval($_GET['type']);

$ppp=20;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;


$ac=$_GET['ac'];
if($ac=='del'){
	if($_GET['formhash']!=FORMHASH)return;
	C::t('#keke_hb#keke_hb')->delete_by_id($hbid);
	showmessage(lang('plugin/keke_hb', 'f002'), 'plugin.php?id=keke_hb:admin&page='.intval($_GET['page']));
}elseif($ac=='add'){
	$lasthd=C::t('#keke_hb#keke_hb')->fetchfirst_bylasttime();
	if($lasthd){
		$lasthdtime=dgmdate($lasthd['endtime'], 'Y-m-d H:i:s');
	}
	
	
	if(submitcheck('hbsub')){
		$name=daddslashes(dhtmlspecialchars($_GET['name']));
		$time=strtotime($_GET['time'])-8*3600;
		$endtime=strtotime($_GET['endtime'])-8*3600;
		$min=intval($_GET['min']);
		$max=intval($_GET['max']);
		$total=intval($_GET['total']);
		$num=intval($_GET['num']);
		$gl=intval($_GET['gl']);
		$xh=$_GET['xh']? intval($_GET['xh']): '';
		$xhlx=$xh ? intval($_GET['xhlx']):'';
		$jg=$_GET['jg']? floatval($_GET['jg']): '';
		$jglx=$jg ? intval($_GET['jglx']):'';
		
		if(($time<$lasthd['endtime']) && !$hbid)showmessage(lang('plugin/keke_hb', 'f003').$lasthdtime);
		$arr=array(
			'name'=>$name,
			'time'=>$time,
			'endtime'=>$endtime,
			'min'=>$min,
			'max'=>$max,
			'total'=>$total,
			'num'=>$num,
			'gl'=>$gl,
			'xh'=>$xh,
			'xhlx'=>$xhlx,
			'jg'=>$jg,
			'jglx'=>$jglx,
		);
		if($hbid){
			C::t('#keke_hb#keke_hb')->update($hbid,$arr);
			$tistxt=lang('plugin/keke_hb', 'f004');
		}else{
			C::t('#keke_hb#keke_hb')->insert($arr, false);
			$tistxt=lang('plugin/keke_hb', 'f005');
		}
		showmessage($tistxt, 'plugin.php?id=keke_hb:admin&ac=add&hbid='.$hbid.'&page='.intval($_GET['page']));	
	}
	if($hbid){
		$hbdata=C::t('#keke_hb#keke_hb')->fetchfirst_byid($hbid);
		$stime=dgmdate($hbdata['time'], 'Y-m-d H:i:s');
		$etime=dgmdate($hbdata['endtime'], 'Y-m-d H:i:s');
		$jg=floatval($hbdata['jg']);
	}
	
	foreach($_G['setting']['extcredits'] as $k =>$v){
	if($k==$hbid['xhlx'])
			$creop.= '<option value="'.$k.'" selected>'.$v['title'].'</option>';
		else
			$creop.= '<option value="'.$k.'">'.$v['title'].'</option>';
	}
	
}elseif($type==2){
	$tmpurl='plugin.php?id=keke_hb:admin&type=2';
	$allcount=C::t('#keke_hb#keke_hb_log')->count_all();
	if($allcount){
		$hdsty=$hbstate='';
			$query = C::t('#keke_hb#keke_hb_log')->fetch_all_by_limit($startlimit,$ppp);			
			foreach($query as $val){
				$time=dgmdate($val['time'], 'Y-m-d H:i:s');
				$hddatas=_get_hddata($val['hbid']);
				$hddata.='<li>
						<span class="uid">'.$val['uid'].'</span>
                        <span class="usname">'.$val['usname'].'</span>
                        <span class="total">'.$val['total'].'</span>
                        <span class="hdnames">'.$hddatas['name'].'</span>
                        <span class="time">'.$time.'</span>
					</li>';
			}
			
		}
	
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
}else{
	$tmpurl='plugin.php?id=keke_hb:admin';
	$allcount=C::t('#keke_hb#keke_hb')->count_all();
	if($allcount){
		$hdsty=$hbstate='';
		$query = C::t('#keke_hb#keke_hb')->fetch_all_by_limit($startlimit,$ppp);
		foreach($query as $val){
			if($val['time']<$_G['timestamp'] && $val['endtime']>$_G['timestamp']){
				$hbstate=lang('plugin/keke_hb', 'f006');
				$hdsty='hdjxz';
			}elseif($_G['timestamp']>$val['endtime']){
				$hbstate=lang('plugin/keke_hb', 'f007');
				$hdsty='hdjs';
			}elseif($_G['timestamp']<$val['time']){
				$hbstate=lang('plugin/keke_hb', 'f008');
				$hdsty='jjks';
			}
			$hdlist.='<li>
					<span class="caozuo"><a href="plugin.php?id=keke_hb:admin&ac=add&hbid='.$val['id'].'">'.lang('plugin/keke_hb', 'f009').'</a> <b>/</b> <a href="plugin.php?id=keke_hb:admin&formhash='.FORMHASH.'&ac=del&hbid='.$val['id'].'" onclick="if(confirm( \''.lang('plugin/keke_hb', 'f0010').'?\')==false)return   false; ">'.lang('plugin/keke_hb', 'f0011').'</a></span>
					<span class="hdname"><p class="hname">'.$val['name'].'</p><p class="hbstate '.$hdsty.'">'.lang('plugin/keke_hb', 'f0012').''.$hbstate.'</p></span>
					<span class="stime">'.dgmdate($val['time'], 'Y-m-d H:i:s').'</span>
					<span class="endtime">'.dgmdate($val['endtime'], 'Y-m-d H:i:s').'</span>
					<span class="total">'.$val['total'].'</span>
					<span class="minhb">'.$val['min'].'~'.$val['max'].'</span>
					<span class="maxhb">'.$val['num'].'</span>
					<span class="gl">'.$val['gl'].'%</span>
				</li>';
		}
		
	}
	
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
}
include template('keke_hb:admin');