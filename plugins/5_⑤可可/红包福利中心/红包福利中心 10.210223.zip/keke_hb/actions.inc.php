<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_hb = $_G['cache']['plugin']['keke_hb'];
$_Info['sid']='';
$creditname=$_G['setting']['extcredits'][$keke_hb['jf']]['title'];
$page=intval($_GET['page']);
$ac=$_GET['ac'];
if($ac=='sid'){echo $_Info['sid'];}
if($_GET['formhash']!=FORMHASH)return;
if(!$_G['uid'] && !($ac=='getbuylist') && !($ac=='getmygoods')){
    showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
/*DisM-taobao��Com*/include_once DISCUZ_ROOT . './source/plugin/keke_hb/function/function_fun.php';
if($ac=='myhblist'){
	$myhblist=_get_myhb($_G['uid']);
	echo $myhblist;
	exit();
}elseif($ac=='syhb'){
	$hbdata=_get_currentdata();
	$total_data = array( 'n' => $hbdata['total'],);   
	echo json_encode($total_data);
	exit();
}elseif($ac=='checkjg'){
	$hbid=intval($_GET['hbid']);
	$rt=_get_jgdata($_G['uid'],$hbid);
	$rt['msg']=gbk2utf($rt['msg']);
	echo json_encode($rt);
	exit();
}