<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_hb extends discuz_table
{
	public function __construct() {
		$this->_table = 'keke_hb';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	
	public function fetchfirst_bytime($time) {
		return DB::fetch_first("SELECT * FROM %t WHERE time<$time AND endtime>$time order by id desc", array($this->_table));
	}
	
	public function fetchfirst_by_next($time) {
		return DB::fetch_first("SELECT * FROM %t WHERE time>$time order by time asc", array($this->_table));
	}
	
	public function fetchfirst_byid($hbid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$hbid));
	}
	
	public function fetchfirst_bylasttime() {
		return DB::fetch_first("SELECT * FROM %t order by endtime desc", array($this->_table));
	}
	
	public function count_all() {
		return DB::result_first("SELECT count(*) FROM %t", array($this->_table));
	}
	
	public function fetch_all_by_limit($startlimit,$ppp) {
		return DB::fetch_all("SELECT * FROM %t order by time desc LIMIT %d,%d", array($this->_table,$startlimit,$ppp));
	}
	
	public function delete_by_id($id) {
		return DB::query("delete FROM %t where id=%d", array($this->_table,$id));
	}
	
	
}

?>