<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_hb_log extends discuz_table
{
	public function __construct() {
		$this->_table = 'keke_hb_log';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	
	
	public function fetchfirst_lasttime($uid,$hbid) {
		return DB::result_first("SELECT time FROM %t WHERE total>0 AND uid=%d AND hbid=%d order by time desc", array($this->_table,$uid,$hbid));
	}
	
	
	public function count_by_uid($uid,$hbid=0) {
		$where='';
		if($hbid){
			$where=' AND hbid='.$hbid;
		}else{
			$where.=' AND total>0';
		}
		return DB::result_first("SELECT count(1) FROM %t WHERE uid=%d".$where, array($this->_table,$uid));
	}
	
	
	public function fetchall_byid($startlimit,$ppp) {
		return DB::fetch_all("SELECT * FROM %t WHERE total>0 order by id desc LIMIT %d,%d", array($this->_table,$startlimit,$ppp));
	}
	
	
	public function fetch_all_by_uid($uid,$startlimit,$ppp) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d AND total>0 order by id desc LIMIT %d,%d", array($this->_table,$uid,$startlimit,$ppp));
	}
	
	
	public function count_all() {
		return DB::result_first("SELECT count(*) FROM %t WHERE total>0", array($this->_table));
	}
	
	
	public function fetch_all_by_limit($startlimit,$ppp) {
		return DB::fetch_all("SELECT * FROM %t order by id desc LIMIT %d,%d", array($this->_table,$startlimit,$ppp));
	}
	
}

?>