<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2019-10-11
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_keke_xzhseo
{
	public function __construct()
	{
		global $_G;
		global $article;
		$this->keke_xzhseo = $_G['cache']['plugin']['keke_xzhseo'];
		$this->perform = 1;
		$this->fid = $_G['fid'];
		$this->section = empty($this->keke_xzhseo['bk']) ? array() : unserialize($this->keke_xzhseo['bk']);
		if (!empty($this->section[0]) && !in_array($this->fid, $this->section)) {
			$this->perform = 0;
		}
		if (CURSCRIPT == 'forum') {
			$this->moda = 2;
			$this->atid = $_G['tid'];
			$this->urla = $this->_creurl(2, $this->atid);
			$userarr = getuserbyuid($_G['thread']['authorid']);
			$this->authorgid = $userarr['groupid'];
		} elseif (CURSCRIPT == 'portal') {
			$this->moda = 1;
			$this->atid = intval($_GET['aid']);
			$this->urla = $this->_creurl(1, $this->atid);
			$userarr = getuserbyuid($article['uid']);
			$this->authorgid = $userarr['groupid'];
		}
		$this->yhz = 1;
		$this->groups = empty($this->keke_xzhseo['yhz']) ? array() : unserialize($this->keke_xzhseo['yhz']);
		if (!empty($this->groups[0]) && !in_array($this->authorgid, $this->groups)) {
			$this->yhz = 0;
		}
		if ($this->moda == 2 && (!$_G['thread']['isgroup'] && $this->perform || $_G['thread']['isgroup'] && $this->keke_xzhseo['qz']) || $this->moda == 1 && $this->keke_xzhseo['wz']) {
			$this->postdata = C::t('#keke_xzhseo#keke_xzhseo')->fetchfirst_byatid($this->atid, $this->moda);
		}
		$this->backtime = strtotime($this->keke_xzhseo['time']);
		$this->beginToday = mktime(0, 0, 0, date('m'), date('d'), date('Y'));
	}
	public function checkauthorizes()
	{
	}

	public function versioncompatibles($versions)
	{
		global $_G;
		list($currentversion) = explode(' ', trim(strip_tags($_G['setting']['version'])));
		$versions = strip_tags($versions);
		foreach (explode(',', $versions) as $version) {
			list($version) = explode(' ', trim($version));
			if ($version && ($currentversion === $version || $version === 'X3' || $version === 'X3.1')) {
				return true;
			}
		}
		return false;
	}
	public function _postbaidu($atid, $type, $mod)
	{
		global $_G;
		$var = $this->keke_xzhseo;
		include template('keke_xzhseo:ajax');
		return $ajax;
	}
	public function mkpiclist($pidarr)
	{
		global $_G;
		$m = 1;
		$mcount = count($pidarr) == 2 ? 1 : 3;
		foreach ($pidarr as $k => $v) {
			if ($m > $mcount) {
				break;
			}
			if ($this->moda == 2) {
				if (strpos($v['url'], 'http') !== false) {
					$pics .= '"' . $v['url'] . $v['attachment'] . '",';
				} else {
					$pics .= '"' . $_G['siteurl'] . $v['url'] . $v['attachment'] . '",';
				}
			} else {
				if (strpos($v, 'http') !== false) {
					$pics .= '"' . $v . '",';
				} else {
					$pics .= '"' . $_G['siteurl'] . $v . '",';
				}
			}
			$m = $m + 1;
		}
		return substr($pics, 0, strlen($str) - 1);
	}
	public function _ireplacetime($dateline)
	{
		$datetime = str_ireplace('+00:00', '', date('c', $dateline));
		$datetime = str_ireplace('+08:00', '', $datetime);
		return $datetime;
	}
	public function _filter_marks($text)
	{
		if (trim($text) == '') {
			return '';
		}
		$text = preg_replace('/[[:punct:]\\s]/', ' ', $text);
		$text = urlencode($text);
		$text = preg_replace('/(%7E|%60|%21|%40|%23|%24|%25|%5E|%26|%27|%2A|%28|%29|%2B|%7C|%5C|%3D|\\-|_|%5B|%5D|%7D|%7B|%3B|%22|%3A|%3F|%3E|%3C|%2C|\\.|%2F|%A3%BF|%A1%B7|%A1%B6|%A1%A2|%A1%A3|%A3%AC|%7D|%A1%B0|%A3%BA|%A3%BB|%A1%AE|%A1%AF|%A1%B1|%A3%FC|%A3%BD|%A1%AA|%A3%A9|%A3%A8|%A1%AD|%A3%A4|%A1%A4|%A3%A1|%E3%80%82|%EF%BC%81|%EF%BC%8C|%EF%BC%9B|%EF%BC%9F|%EF%BC%9A|%E3%80%81|%E2%80%A6%E2%80%A6|%E2%80%9D|%E2%80%9C|%E2%80%98|%E2%80%99|%EF%BD%9E|%EF%BC%8E|%EF%BC%88)+/', ' ', $text);
		$text = urldecode($text);
		return trim($text);
	}
	public function _postdata($dateline)
	{
		if (!$this->postdata && $this->yhz && $this->keke_xzhseo['zd']) {
			if ($this->moda == 2) {
				if ($this->keke_xzhseo['dsh']) {
					$thread = C::t('forum_thread')->fetch($this->atid);
					if ($thread['displayorder'] < 0) {
						return NULL;
					}
				}
				if ($this->keke_xzhseo['zs']) {
					$firstpost = C::t('forum_post')->fetch_threadpost_by_tid_invisible($this->atid);
					include_once libfile('function/discuzcode');
					$message = discuzcode($firstpost['message']);
					$sppos = strpos($message, chr(0) . chr(0) . chr(0));
					if ($sppos !== false) {
						$message = substr($message, 0, $sppos);
					}
					$posttxt = strip_tags($message);
					$posttxts = $this->_filter_marks($posttxt);
					$txtcount = mb_strwidth($posttxts);
					if ($txtcount < $this->keke_xzhseo['zs']) {
						return NULL;
					}
				}
			}
			if ($dateline > $this->beginToday) {
				if ($this->keke_xzhseo['dlimit']) {
					$todaycount = C::t('#keke_xzhseo#keke_xzhseo')->count_all_bytoday();
					if ($todaycount >= $this->keke_xzhseo['dlimit']) {
						return NULL;
					}
				}
				$ret = $this->_postbaidu($this->atid, 1, $this->moda);
			} else {
				if ($this->keke_xzhseo['ls']) {
					$ret = $this->_postbaidu($this->atid, 2, $this->moda);
				}
			}
		}
		return $ret;
	}
	public function _cutmsg($msgs)
	{
		global $_G;
		global $article;
		$var = $this->keke_xzhseo;
		$cd = $val['cd'] ? intval($val['cd']) : 120;
		if (!$msgs) {
			$msgs = $article['title'];
			if (CURSCRIPT == 'forum') {
				$msgs = $_G['thread']['subject'];
			}
		}
		$smsg = preg_replace('/<script[\\s\\S]*?<\\/script>/is', '', $msgs);
		$smsg = str_replace(array("\r\n", "\r", "\n"), '', cutstr(strip_tags(preg_replace('/(<i class=\\"pstatus\\">.*<\\/i>)/is', '', preg_replace('/(<ignore_js_op>.*<\\/ignore_js_op>)/is', '', $smsg))), $cd, ''));
		return $smsg;
	}
	public function getFullUrl()
	{
		$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
		$php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
		$path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
		$relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : $path_info);
		return $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
	}
	public function _creurl($mods, $atid)
	{
		global $_G;
		$_GET['page'] = $_GET['page'] ? $_GET['page'] : 1;
		if ($mods == 2) {
			$urla = 'forum.php?mod=viewthread&tid=' . $atid;
			if ($this->keke_xzhseo['tformat']) {
				$urla = dhtmlspecialchars(str_ireplace(array('{tid}', '{page}'), array($atid, intval($_GET['page'])), $this->keke_xzhseo['tformat']));
			} else {
				if (in_array('forum_viewthread', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus'] == 1) {
					$urla = rewriteoutput('forum_viewthread', 1, '', $atid, $_GET['page']);
				}
			}
		} elseif ($mods == 1) {
			$urla = 'portal.php?mod=view&aid=' . $atid;
			if ($this->keke_xzhseo['pformat']) {
				$urla = dhtmlspecialchars(str_ireplace(array('{id}', '{page}'), array($atid, intval($_GET['page'])), $this->keke_xzhseo['pformat']));
			} else {
				if (in_array('portal_article', $_G['setting']['rewritestatus']) || $_G['setting']['rewritestatus'] == 1) {
					$urla = rewriteoutput('portal_article', 1, '', $atid, $_GET['page']);
				}
			}
		}
		return $urla;
	}
	public function _posttobaidu($atid, $mods, $type, $purl = array())
	{
		global $_G;
		$var = $_G['cache']['plugin']['keke_xzhseo'];
		loadcache(array('keke_mipseo', 'plugin'));
		$keke_mipseo = $_G['cache']['plugin']['keke_mipseo'];
		if ($purl) {
			$urls = $purl;
		} else {
			$siteurls = $var['domain'] ? dhtmlspecialchars($var['domain']) : $_G['siteurl'];
			if ($mods == 2) {
				if ($var['page'] == 2 && $keke_mipseo) {
					$siteurl = $keke_mipseo['domain'] ? $keke_mipseo['domain'] : $_G['siteurl'];
					$urla = $siteurl . 'forum.php?mod=viewthread&tid=' . $atid . '&mip=1';
					if ($keke_mipseo['rewrite'] && $keke_mipseo['on']) {
						$urla = $siteurl . str_ireplace('{tid}', '' . $atid . '', $keke_mipseo['rewrite']);
					}
				} else {
					$urla = $siteurls . $this->_creurl(2, $atid);
				}
				$thread = C::t('forum_thread')->fetch($atid);
				$subject = $thread['subject'];
			} elseif ($mods == 1) {
				if ($var['page'] == 2 && $keke_mipseo) {
					$siteurl = $keke_mipseo['domain'] ? $keke_mipseo['domain'] : $_G['siteurl'];
					$urla = $siteurl . 'portal.php?mod=view&aid=' . $atid . '&mip=1';
					if ($keke_mipseo['rewritep'] && $keke_mipseo['on']) {
						$urla = $siteurl . str_ireplace('{id}', '' . $atid . '', $keke_mipseo['rewritep']);
					}
				} else {
					$urla = $siteurls . $this->_creurl(1, $atid);
				}
				$article = C::t('portal_article_title')->fetch($atid);
				$subject = $article['title'];
			}
			$urls = array($urla);
		}
		$typename = $type == 2 ? 'batch' : 'realtime';
		if (function_exists('curl_init') && function_exists('curl_exec')) {
			$uri = 'http://data.zz.baidu.com/urls?appid=' . $var['appid'] . '&token=' . $var['token'] . '&type=' . $typename;
			$ch = curl_init();
			$options = array(CURLOPT_URL => $uri, CURLOPT_POST => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_POSTFIELDS => implode("\n", $urls), CURLOPT_HTTPHEADER => array('Content-Type: text/plain'));
			curl_setopt_array($ch, $options);
			$result = curl_exec($ch);
			$ret = json_decode($result, true);
		} else {
			$ret['error'] = 9990;
			$ret['message'] = 'curl error';
		}
		if ($ret['error']) {
			$state = intval($ret['error']);
			$msg = daddslashes($ret['message']);
		} else {
			if ($ret['success'] || $ret['success_batch'] || $ret['success_realtime']) {
				$state = 1;
			} else {
				if ($ret['not_same_site']) {
					$state = 2;
					$msg = 'not_same_site';
				}
				if ($ret['not_valid']) {
					$state = 3;
					$msg = 'not_valid';
				}
			}
		}
		if ($atid) {
			$arr = array('subject' => $subject, 'url' => implode("\n", $urls), 'state' => $state, 'msg' => $msg, 'time' => $_G['timestamp'], 'type' => $type, 'mods' => $mods, 'atid' => $atid);
			C::t('#keke_xzhseo#keke_xzhseo')->insert($arr);
			return json_encode(array('state' => $state, 'msg' => $msg));
		}
		if ($ret['error']) {
			$r = $state . '/' . $msg;
		} else {
			$postnum = $type == 2 ? $ret['success_batch'] : $ret['success_realtime'];
			$postnum = $postnum ? $postnum : 0;
			$r = lang('plugin/keke_xzhseo', '040') . $postnum . lang('plugin/keke_xzhseo', '041');
		}
		return $r;
	}
	public function _portalviews()
	{
		global $_G;
		global $article;
		global $content;
		$sdarr = unserialize($this->keke_xzhseo['sd']);
		if (in_array($_G['groupid'], $sdarr)) {
			$sd = 1;
		}
		if ($this->keke_xzhseo['ykgz'] && !$_G['uid'] || !$this->keke_xzhseo['ykgz']) {
			$ykgz = 1;
		}
		if ($this->moda == 1 && $_GET['aid']) {
			$this->checkauthorizes();
			$dateline = strtotime($article['dateline']);
			$datetime = $this->_ireplacetime($dateline);
			if ($this->keke_xzhseo['wz']) {
				if ($ykgz) {
					preg_match_all('/<img[^>]*src=[\'"]?([^>\'"\\s]*)[\'"]?[^>]*>/i', $content['content'], $out);
					$piclist = $this->mkpiclist($out[1]);
					$messages = $this->_cutmsg($content['content']);
					$messages = trim($messages);
				}
				include template('keke_xzhseo:inc');
				if ($ykgz) {
					$_G['setting']['seohead'] .= $returns;
				}
				$tsbtns = $sd ? $tsbtn : '';
				$ret = $this->_postdata($dateline);
				if (checkmobile()) {
					$returnjs = $gz . $ret;
					if (!$this->keke_xzhseo['bl'] && $ykgz) {
						$returnjs = $returns . $gz . $ret;
					}
					$jqs = '';
				}
			}
		}
		return $jqs . $ret . $returnjs . $tsbtns;
	}
	public function _forumviews()
	{
		global $_G;
		global $postlist;
		$var = $_G['cache']['plugin']['keke_xzhseo'];
		$sdarr = unserialize($this->keke_xzhseo['sd']);
		if (in_array($_G['groupid'], $sdarr)) {
			$sd = 1;
		}
		if ($this->keke_xzhseo['ykgz'] && !$_G['uid'] || !$this->keke_xzhseo['ykgz']) {
			$ykgz = 1;
		}
		$idurl = $this->getFullUrl();
		if ($this->moda == 2 && $_G['tid']) {
			$isgroup = $_G['thread']['isgroup'];
			if ($isgroup && $this->keke_xzhseo['qz'] || !$isgroup && $this->perform) {
				$this->checkauthorizes();
				$dateline = $_G['thread']['dateline'];
				if ($ykgz) {
					$datetime = $this->_ireplacetime($dateline);
					if ($_G['forum_firstpid']) {
						$firstpostdata = $postlist[$_G['forum_firstpid']];
						if (count($postlist) > 1 && $this->keke_xzhseo['sjyz']) {
							$n = 0;
							foreach ($postlist as $kkey => $vval) {
								if ($n == 1) {
									$shafapid = $kkey;
								}
								$n = $n + 1;
							}
							$shafatpostdata = $postlist[$shafapid];
							$fireposttime = date('Y-m-d\\TH:i:s', $shafatpostdata['dbdateline']);
							$threadss = C::t('forum_thread')->fetch($_G['tid']);
							$lastposttime = $threadss['lastpost'];
							$lastposttime = date('Y-m-d\\TH:i:s', $lastposttime);
						}
					}
					if ($firstpostdata['attachments']) {
						foreach ($firstpostdata['attachments'] as $kk => $vv) {
							if ($vv['isimage']) {
								$pids[$kk] = $vv;
							}
						}
					}
					$piclist = $this->mkpiclist($pids);
					$messages = $this->_cutmsg($firstpostdata['message']);
					$messages = trim($messages);
				}
				include template('keke_xzhseo:inc');
				if ($ykgz) {
					$_G['setting']['seohead'] .= $returns;
				}
				$ret = $this->_postdata($dateline);
				if (checkmobile()) {
					$returnjs = $gz . $ret;
					if (!$this->keke_xzhseo['bl'] && $ykgz) {
						$returnjs = $returns . $gz . $ret;
					}
					$jqs = '';
				}
				$tsbtns = $sd ? $tsbtn : '';
			}
		}
		return array($jqs . $ret . $returnjs . $tsbtns);
	}
}
class plugin_keke_xzhseo_forum extends plugin_keke_xzhseo
{
	public function viewthread_posttop_output()
	{
		global $_G;
		if ($_G['forum_firstpid']) {
			return $this->_forumviews();
		}
		return array();
	}
}
class mobileplugin_keke_xzhseo_forum extends plugin_keke_xzhseo
{
	public function viewthread_posttop_mobile_output()
	{
		global $_G;
		if ($_G['forum_firstpid']) {
			return $this->_forumviews();
		}
		return array();
	}
}
class plugin_keke_xzhseo_portal extends plugin_keke_xzhseo
{
	public function view_article_content_output()
	{
		return $this->_portalviews();
	}
}
class plugin_keke_xzhseo_group extends plugin_keke_xzhseo_forum
{
}
class mobileplugin_keke_xzhseo_group extends mobileplugin_keke_xzhseo_forum
{
}
class mobileplugin_keke_xzhseo_portal extends plugin_keke_xzhseo_portal
{
}
class mobileplugin_keke_xzhseo extends plugin_keke_xzhseo
{
	public function global_footer_mobile()
	{
		global $_G;
		$var = $_G['cache']['plugin']['keke_xzhseo'];
		$bottomgz = '';
		if ($var['dgz']) {
			include template('keke_xzhseo:inc');
		}
		return $bottomgz;
	}
}