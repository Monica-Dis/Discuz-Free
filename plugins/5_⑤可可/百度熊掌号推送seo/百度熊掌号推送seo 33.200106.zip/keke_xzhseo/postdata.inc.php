<?php
if (! defined ('IN_DISCUZ')) {
	exit ('Access Denied');
}
if($_GET['formhash'] != $_G['formhash']){
	exit(json_encode(array('state'=>10,'msg'=>'formhash error')));
}
include_once DISCUZ_ROOT."source/plugin/keke_xzhseo/keke_xzhseo.class.php";
$postdata=C::t('#keke_xzhseo#keke_xzhseo')->fetchfirst_byatid(intval($_GET['atid']),intval($_GET['mods']));
if($postdata['state']==1){
	$tips=lang('plugin/keke_xzhseo', '027');
	if('utf-8' != CHARSET) {
		$tips = diconv($tips, CHARSET, 'utf-8');
	}
	exit(json_encode(array('state'=>9,'msg'=>$tips)));
}
$postdatas=new plugin_keke_xzhseo;
exit($postdatas->_posttobaidu(intval($_GET['atid']),intval($_GET['mods']),intval($_GET['type'])));