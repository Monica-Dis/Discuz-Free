<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
$all_set=_get_set();
$_GET['op']=$_GET['op']?$_GET['op']:'rewriteset';
_showadminsubmenu(array(
	array(lang('plugin/keke_video_base', '362'), "rewriteset"),
	array(lang('plugin/keke_video_base', '370'), "rewrite"),
),'admincp_rewrite');
if ($_GET['op'] == 'rewriteset') {
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_rewrite&op=rewriteset", 'enctype');
		showtableheader(lang('plugin/keke_video_base', '362'));
		showsetting(lang('plugin/keke_video_base', '363'),'rewrite[off]',$all_set['rewrite_off']);
		showsetting(lang('plugin/keke_video_base', '364'),'rewrite[suffix]',$all_set['rewrite_suffix'],'text','','',lang('plugin/keke_video_base', '365'));
		showsetting(lang('plugin/keke_video_base', '366'),'rewrite[index]',($all_set['rewrite_index']?$all_set['rewrite_index']:'video'),'text','','','');
		showsetting(lang('plugin/keke_video_base', '367'),'rewrite[list]',($all_set['rewrite_list']?$all_set['rewrite_list']:'video-class'),'text','','','');
		showsetting(lang('plugin/keke_video_base', '368'),'rewrite[course]',($all_set['rewrite_course']?$all_set['rewrite_course']:'course'),'text','','','');
		showsetting(lang('plugin/keke_video_base', '369'),'rewrite[play]',($all_set['rewrite_play']?$all_set['rewrite_play']:'study'),'text','','','');
		showsetting(lang('plugin/keke_video_base', '371'),'rewrite[account]',($all_set['rewrite_account']?$all_set['rewrite_account']:'account'),'text','','','');
		showsetting(lang('plugin/keke_video_base', '373'),'rewrite[teacher]',($all_set['rewrite_teacher']?$all_set['rewrite_teacher']:'teacher'),'text','','','');
		showsetting(lang('plugin/keke_video_base', '495'),'rewrite[teacherlist]',($all_set['rewrite_teacherlist']?$all_set['rewrite_teacherlist']:'teacherlist'),'text','','','');
		showsetting(lang('plugin/keke_video_base', '374'),'rewrite[pay]',($all_set['rewrite_pay']?$all_set['rewrite_pay']:'video-pay'),'text','','','');
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
	}else{
		foreach($_GET['rewrite'] as $key=>$val){
			$arr['rewrite_'.$key]=_video_editor_safe_replace($val);
		}
		_insert_set($arr);
		cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_rewrite', 'succeed');
	}
}else{
	showtips(lang('plugin/keke_video_base', '372'));
	$rewrite=array(
		'index','list','account','course','play','teacher','teacherlist','pay'
	);
	$suffix=str_replace(".","\.",$all_set['rewrite_suffix']);
	foreach($rewrite as $rewritekey=>$rewriteval){
		if($all_set['rewrite_'.$rewriteval]){
			$rewritearr[$rewriteval]=str_replace(".","\.",$all_set['rewrite_'.$rewriteval]);
		}
	}
	$strtmp= '<br><h1>'.lang('plugin/keke_video_base', '375').'</h1>
	<pre class="colorbox">
	
	
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['index'].$suffix.'$ $1/plugin.php?id=keke_video_base%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['list'].$suffix.'$ $1/plugin.php?id=keke_video_base&ac=list%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=list&cid=$2&scid=$3%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=list&cid=$2&scid=$3&o=$4&page=$5%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['account'].$suffix.'$ $1/plugin.php?id=keke_video_base&ac=account%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=account&op=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=account&op=$2&page=$3%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['course'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=course&cid=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['play'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=play&kid=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['teacher'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=teacher&tcid=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['teacherlist'].$suffix.'$ $1/plugin.php?id=keke_video_base&ac=teacherlist%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['pay'].'-(.*?)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=pay&cid=$2%1
	
	</pre>
	<h1>'.lang('plugin/keke_video_base', '376').'</h1>
	<pre class="colorbox">
	
	
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['index'].$suffix.'$ plugin.php?id=keke_video_base%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['list'].$suffix.'$ plugin.php?id=keke_video_base&ac=list%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$suffix.'$ plugin.php?id=keke_video_base&ac=list&cid=$1&scid=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'$ plugin.php?id=keke_video_base&ac=list&cid=$1&scid=$2&o=$3&page=$4%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['account'].$suffix.'$ plugin.php?id=keke_video_base&ac=account%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['account'].'-(\w+)'.$suffix.'$ plugin.php?id=keke_video_base&ac=account&op=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'$ plugin.php?id=keke_video_base&ac=account&op=$1&page=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['course'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_video_base&ac=course&cid=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['play'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_video_base&ac=play&kid=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['teacher'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_video_base&ac=teacher&tcid=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['teacherlist'].$suffix.'$ plugin.php?id=keke_video_base&ac=teacherlist%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['pay'].'-(.*?)'.$suffix.'$ plugin.php?id=keke_video_base&ac=pay&cid=$1%1
	
	</pre>
	<h1>Nginx Web Server</h1>
	<pre class="colorbox">

	
	rewrite ^([^\.]*)/'.$rewritearr['index'].$suffix.'$ $1/plugin.php?id=keke_video_base last;
	rewrite ^([^\.]*)/'.$rewritearr['list'].$suffix.'$ $1/plugin.php?id=keke_video_base&ac=list last;
	rewrite ^([^\.]*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=list&cid=$2&scid=$3 last;
	rewrite ^([^\.]*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=list&cid=$2&scid=$3&o=$4&page=$5 last;
	rewrite ^([^\.]*)/'.$rewritearr['account'].$suffix.'$ $1/plugin.php?id=keke_video_base&ac=account last;
	rewrite ^([^\.]*)/'.$rewritearr['account'].'-(\w+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=account&op=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=account&op=$2&page=$3 last;
	rewrite ^([^\.]*)/'.$rewritearr['course'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=course&cid=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['play'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=play&kid=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['teacher'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=teacher&tcid=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['teacherlist'].$suffix.'$ $1/plugin.php?id=keke_video_base&ac=teacherlist last;
	rewrite ^([^\.]*)/'.$rewritearr['pay'].'-(.*?)'.$suffix.'$ $1/plugin.php?id=keke_video_base&ac=pay&cid=$2 last;
	
	</pre>
	<h1>'.lang('plugin/keke_video_base', '377').'</h1>
	<pre class="colorbox">
	
	
	RewriteRule ^(.*)/'.$rewritearr['index'].$suffix.'*$ $1/plugin.php?id=keke_video_base
	RewriteRule ^(.*)/'.$rewritearr['list'].$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=list
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=list&cid=$2&scid=$3
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=list&cid=$2&scid=$3&o=$4&page=$5
	RewriteRule ^(.*)/'.$rewritearr['account'].$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=account
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)'.$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=account&op=$2
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=account&op=$2&page=$3
	RewriteRule ^(.*)/'.$rewritearr['course'].'-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=course&cid=$2
	RewriteRule ^(.*)/'.$rewritearr['play'].'-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=play&kid=$2
	RewriteRule ^(.*)/'.$rewritearr['teacher'].'-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=teacher&tcid=$2
	RewriteRule ^(.*)/'.$rewritearr['teacherlist'].$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=teacherlist
	RewriteRule ^(.*)/'.$rewritearr['pay'].'-(.*?)'.$suffix.'*$ $1/plugin.php?id=keke_video_base&ac=pay&cid=$2
	
	</pre>
	<h1>'.lang('plugin/keke_video_base', '378').'</h1>
	<pre class="colorbox">
	
	
	&lt;rule name="video_index"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['index'].$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base" /&gt;
	&lt;/rule&gt;
	&lt;rule name="video_list"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['list'].$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=list" /&gt;
	&lt;/rule&gt;
	&lt;rule name="video_list_a"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['list'].'-([0-9]+)-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=list&amp;amp;cid={R:2}&amp;amp;scid={R:3}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="video_list_b"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=list&amp;amp;cid={R:2}&amp;amp;scid={R:3}&amp;amp;o={R:4}&amp;amp;page={R:5}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="account"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['account'].$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=account" /&gt;
	&lt;/rule&gt;
	&lt;rule name="account_a"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['account'].'-(\w+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=account&amp;amp;op={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="account_b"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=account&amp;amp;op={R:2}&amp;amp;page={R:3}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="course"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['course'].'-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=course&amp;amp;cid={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="play"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['play'].'-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=play&amp;amp;kid={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="teacher"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['teacher'].'-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=teacher&amp;amp;tcid={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="teacherlist"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['teacherlist'].$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=teacherlist" /&gt;
	&lt;/rule&gt;
	&lt;rule name="pay"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['pay'].'-([0-9]+)'.$all_set['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_video_base&amp;amp;ac=pay&amp;amp;cid={R:2}" /&gt;
	&lt;/rule&gt;
	
	
	</pre>';
	echo $strtmp;
	showtablefooter(); /*dism��taobao��com*/
}