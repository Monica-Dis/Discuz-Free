<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
$keke_video_wx = $_G['cache']['plugin']['keke_video_wx'];
require_once DISCUZ_ROOT.'./source/plugin/keke_video_base/function.php';
$allcatedata=_get_allcatedata();
$slider=_get_cache('slider');
$all_set=_get_set();
if ($_G['cache']['plugin']['keke_market']) {
	$keke_market = $_G['cache']['plugin']['keke_market'];
	require_once DISCUZ_ROOT.'./source/plugin/keke_market/function.php';
	binduser();
}
if($_GET['ac']=='list'){
	$_GET['cid']=intval($_GET['cid']);
	$_GET['scid']=intval($_GET['scid']);
	$_GET['o']=intval($_GET['o']);
	$ppp=16;
	$tmpurl='plugin.php?id=keke_video_base&ac=list&cid='.$_GET['cid'].'&scid='.$_GET['scid'].'&o='.$_GET['o'].'&keyword='.dhtmlspecialchars($_GET['keyword']);
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$where='state=1 AND hide<=0';
	$order=" ORDER BY displayorder DESC,id DESC";
	if($_GET['cid']){
		$where.=" AND cate=".$_GET['cid'];
	}
	if($_GET['scid']){
		$where.=" AND sub_cate=".$_GET['scid'];
	}
	if($_GET['keyword']){
		$where.=" AND title LIKE '%".$_GET['keyword']."%'";
	}
	if($_GET['o']){
		switch ($_GET['o']){
			case 1:
				$order=" ORDER BY id DESC";
				break;  
			case 2:
				$order=" ORDER BY view DESC";
				break;
			case 3:
				$order=" ORDER BY price DESC";
				break;
		  	case 4:
				$order=" ORDER BY price ASC";
				break;
		}
	}
	$count_all=C::t('#keke_video_base#keke_video_course')->count_all($where);
	$coursearr=C::t('#keke_video_base#keke_video_course')->fetch_all_course($startlimit,$ppp,$where,$order);
	foreach($coursearr as $cou){
		$teacheruids[$cou['uid']]=$cou['uid'];
	}
	$teacheruidsarr=C::t('#keke_video_base#keke_video_teacher')->fetch_all_by_uids($teacheruids);
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	$navtitle=($_GET['cid'] || $_GET['scid'])?str_replace(array('[subcate]','[cate]'),array(($_GET['scid']?$allcatedata[$_GET['scid']]['name']:''),$allcatedata[$_GET['cid']]['name'].($_GET['scid']?'-':'')),$all_set['list_title']):$all_set['list_index_title'];
	$metakeywords=str_replace(array('[subcate]','[cate]'),array(($_GET['scid']?$allcatedata[$_GET['scid']]['name']:''),$allcatedata[$_GET['cid']]['name'].($_GET['scid']?'-':'')),$all_set['list_keywords']);
	$metadescription=str_replace(array('[subcate]','[cate]'),array(($_GET['scid']?$allcatedata[$_GET['scid']]['name']:''),$allcatedata[$_GET['cid']]['name'].($_GET['scid']?'-':'')),$all_set['list_description']);
}elseif($_GET['ac']=='course'){
	$cid=intval($_GET['cid']);
	if($cid){
		$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
		if($course['state']==3 || $course['state']==0){
			if($_G['uid']==$course['uid'] || $_G['groupid']==1){
				$statetips=lang('plugin/keke_video_base', '001');
			}else{
				showmessage(lang('plugin/keke_video_base', '002'), 'plugin.php?id=keke_video_base', array(), array('alert' => 'error'));
			}
		}
		$chapterarr=C::t('#keke_video_base#keke_video_chapter')->fetch_all_by_displayorder($course['uid'],$cid);
		$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_all_by_cid($course['uid'],$cid,1);
		foreach($kearr as $key=>$val){
			$val['concent']=unserialize($val['concent']);
			if($val['type']==3){
				$val['concent']['liveendtime']=$val['concent']['dete']+$val['concent']['lasttime']*60;
				$val['concent']['starttime']=dgmdate($val['concent']['dete'],'Y-m-d H:i');
			}
			$kearrs[$val['cpid']][]=$val;
			if($val['price']>0)$keids[]=$val['id'];
            if($val['cpid']==0)$emptyChapter=1;
		}
        if($_G['uid']){
            $validtime=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bycid($cid,$_G['uid']);
            if($validtime && $validtime['exp_time']==0){
                $course['timediff']=lang('plugin/keke_video_base', '016');
            }elseif($validtime['exp_time']>TIMESTAMP){
                $course['timediff']=_gettimediffs(TIMESTAMP,$validtime['exp_time'],1);
            }
            if(!$course['timediff']){
                foreach($chapterarr as $cpval){
                    if($cpval['price']>0)$cpids[]=$cpval['id'];
                }
                if($cpids){
                    $cpvalidtime=C::t('#keke_video_base#keke_video_validtime')->fetchall_bycpids($cpids,$_G['uid']);
                }
                if($keids){
                    $kevalidtime=C::t('#keke_video_base#keke_video_validtime')->fetchall_bykeids($keids,$_G['uid']);
                }
            }
        }
        if($emptyChapter){
            $chapterarr[]['id']=0;
        }
        $course['content']=html_entity_decode($course['content']);
		$teacher_data=C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($course['uid']);
		$follow_data=C::t('#keke_video_base#keke_video_follow')->fetchfirst_byteacherid($course['uid'],$_G['uid']);
		$evaluate_data=C::t('#keke_video_base#keke_video_evaluate')->fetchall_by_cid($cid);
		foreach($evaluate_data as $ek=>$ev){
			for($i=0; $i<$ev['star'];$i++){
				$evaluate_data[$ek]['stars'][]=1;
			}
			$evaluate_data[$ek]['time']=dgmdate($ev['time'], 'Y-m-d H:i:s');
            if($keke_video_base['hidefullname'])$evaluate_data[$ek]['username']=_video_substr_cut($ev['username']);
		}
		$creditname=$_G['setting']['extcredits'][$course['credit_type']]['title'];
		$favoritesarr=C::t('#keke_video_base#keke_video_favorites')->fetchfirst_bycid($cid,$_G['uid']);
		$evaluatearr=C::t('#keke_video_base#keke_video_evaluate')->fetchfirst_byuid($cid,$_G['uid']);
		$stcount=C::t('#keke_video_base#keke_video_validtime')->count_all('cid='.$cid);
		$keke_video_base['buyaddnum']=explode('/',str_replace('[view]',$course['view'],$keke_video_base['buyaddnum']));
		$stcount+=count($keke_video_base['buyaddnum'])>1?intval($keke_video_base['buyaddnum'][0]/$keke_video_base['buyaddnum'][1]):$keke_video_base['buyaddnum'][0];
		$filelist=C::t('#keke_video_base#keke_video_file')->fetch_all_by_displayorder($course['uid'],$cid);
		if ($_G['cache']['plugin']['keke_market']) {
			$market_member=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
			if($market_member['levelid']){
				$level_data = $_G['cache']['keke_market_level']?$_G['cache']['keke_market_level']:C::t('#keke_market#keke_market_level')->fetch_all();
				$proportion=$level_data[$market_member['levelid']]['one'];
			}else{
				$default_level_data =C::t('#keke_market#keke_market_level')->fetchfirst_default();
				$proportion=$default_level_data['one'];
			}
			$sharemoney=$course['price']*$proportion/100;
			$sharebtn=$keke_video_base['sharebtn'];
			if($keke_video_base['wapsharetxt']){
				$keke_market['wapsharetxt']=explode('|',$keke_video_base['wapsharetxt']);
				$keke_market['wapsharetxt']=$market_member?($keke_market['wapsharetxt'][1]?$keke_market['wapsharetxt'][1]:$keke_market['wapsharetxt'][0]):$keke_market['wapsharetxt'][0];
			}
			if($keke_video_base['pcsharetxt']){
				$keke_market['pcsharetxt']=explode('|',$keke_video_base['pcsharetxt']);
				$keke_market['pcsharetxt']=$market_member?($keke_market['pcsharetxt'][1]?$keke_market['pcsharetxt'][1]:$keke_market['pcsharetxt'][0]):$keke_market['pcsharetxt'][0];
			}
			$keke_market['wapsharetxt']=$sharemoney>0?str_replace('[money]',' &yen;'.$sharemoney,dhtmlspecialchars($keke_market['wapsharetxt'])):lang('plugin/keke_video_base', '410');
			$keke_market['pcsharetxt']=str_replace('[money]',' &yen;'.$sharemoney,dhtmlspecialchars($keke_market['pcsharetxt']));
			
		}
		$supergroup=unserialize($keke_video_base['supergroup']);
		$appoint=unserialize($keke_video_base['appoint']);
        $cateGroupArr=unserialize($allcatedata[$course['sub_cate']]['vip_groupids']);
        if($cateGroupArr && $appoint) {
            $course['vip']=1;
            $appoint=array_keys(array_flip($appoint)+array_flip($cateGroupArr));
        }

        if($keke_video_base['groupnosw']){
            foreach (getUserAllGroup() as $groupId) {
                if(in_array($groupId,$appoint)){
                    $isVipUser=1;
                    break;
                }
            }
        }else{
            $isVipUser=in_array($_G['groupid'],$appoint);
        }

		if($course['password'] && !$_G['cookie']['coursepassword_'.$cid])$ispasswordcourse=1;
        if($keke_video_base['othercourses']){
            $otherCourse=C::t('#keke_video_base#keke_video_course')->fetch_all_course(0,intval($keke_video_base['othercourses']),'uid='.$course['uid'].' AND type<>3 AND state=1 AND hide=0','ORDER BY RAND()');
        }
        if($keke_video_base['similar']){
            $valid=C::t('#keke_video_base#keke_video_validtime')->fetchall_bycid($cid);
            $n=0;
            foreach ($valid as $user){
                $similarUsers[$user['uid']]=$user['uid'];
                if($n>10)break;
                $n++;
            }
            $validData=C::t('#keke_video_base#keke_video_validtime')->fetchall_byuids($similarUsers);
            $k=0;
            foreach ($validData as $it) {
                $similar[$it['cid']]=$it['cid'];
                if($n>10)break;
                $k++;
            }
            $similarCourse=C::t('#keke_video_base#keke_video_course')->fetch_all_course(0,4,'id in ('.dimplode($similar).') AND type<>3 AND state=1 AND hide=0','ORDER BY RAND()');
            if(!$similarCourse){
                $similarCourse=C::t('#keke_video_base#keke_video_course')->fetch_all_course(0,4,'id<>'.$cid.' AND cate='.$course['cate']. ' AND type<>3 AND state=1 AND hide=0');
            }
        }
	}
	if($course['type']==3){
        $courseIds=str_replace("'","",explode(',',$course['courseids']));
        $course['packageCourseNum']=$course['courseids']?count($courseIds):0;
        $packageCourseDt=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($courseIds);
        foreach ($courseIds as $packageItem) {
            if($packageCourseDt[$packageItem])$packageCourse[]=$packageCourseDt[$packageItem];
        }
        foreach ($packageCourse as $ck=>$cv){
            if($cv['learning_time']){
                $packageLearningTime=true;
                break;
            }
        }
        if($_G['uid']){
            $packageValidtime=C::t('#keke_video_base#keke_video_validtime')->fetch_all_by_cids($courseIds,$_G['uid']);
            if($packageValidtime){
                foreach ($packageValidtime as $vval){
                    if($vval['exp_time']===0 || ($vval['exp_time'] && $vval['exp_time']>TIMESTAMP)){
                        $learning=true;
                        break;
                    }
                }
            }
        }
        $packageFilelist=C::t('#keke_video_base#keke_video_file')->fetch_all_by_cids($courseIds);
    }
    $packageCourseData=C::t('#keke_video_base#keke_video_course')->fetch_all_course(0,15,"courseids LIKE '%\'".$cid."\'%'");
	if($packageCourseData){
        foreach ($packageCourseData as $pCKey=>$pCVal){
            $cidArrs=explode(',',str_replace("'","",$pCVal['courseids']));
            foreach ($cidArrs as $k=>$v){
                $packageCid[$v]=$v;
            }
            $packageCid[$pCKey]=$pCKey;
            $packageCourseId[$pCKey]=$cidArrs;
            $hdli.='<li></li>';
        }
        $packageCourseS=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($packageCid);
    }

	$courseurl=urlencode($_G['siteurl'].'plugin.php?id=keke_video_base&ac=course&cid='.$cid);
	$navtitle=str_replace(array('[course]','[subcate]','[cate]'),array($course['title'],'-'.$allcatedata[$course['sub_cate']]['name'],$allcatedata[$course['cate']]['name']),$all_set['course_title']);
	$metakeywords=str_replace(array('[course]','[subcate]','[cate]'),array($course['title'],'-'.$allcatedata[$course['sub_cate']]['name'],$allcatedata[$course['cate']]['name']),$all_set['course_keywords']);
	$metadescription=str_replace(array('[description]','[course]','[subcate]','[cate]'),array(cutstr($course['dec'],60),$course['title'],$allcatedata[$course['sub_cate']]['name'],$allcatedata[$course['cate']]['name']),  $all_set['course_description']);
	$course['img']=(strstr($course['img'], "http")!== false)?$course['img']:$_G['siteurl'].$course['img'];
}elseif($_GET['ac']=='play'){
	$all_set=_get_set();
	$kid=intval($_GET['kid']);
    $vids=intval($vids);
	$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($kid);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($kearr['cid']);
	if($course['state']==3 || $course['state']==0){
		if($_G['uid']==$course['uid'] || in_array($_G['groupid'],unserialize($keke_video_base['supergroup']))){
			$statetips=lang('plugin/keke_video_base', '001');
		}else{
			showmessage(lang('plugin/keke_video_base', '002'), 'plugin.php?id=keke_video_base', array(), array('alert' => 'error'));
		}
	}
	$supergroup=unserialize($keke_video_base['supergroup']);
	$appoint=unserialize($keke_video_base['appoint']);
	$chapterarr=C::t('#keke_video_base#keke_video_chapter')->fetch_all_by_displayorder($course['uid'],$kearr['cid']);
	$kearrs=C::t('#keke_video_base#keke_video_ke')->fetch_all_by_cid($course['uid'],$kearr['cid'],1);
	foreach($kearrs as $key=>$val){
		$val['concent']=unserialize($val['concent']);
		$kearrss[$val['cpid']][]=$val;
        if($val['cpid']==0)$emptyChapter=1;
	}
    if($emptyChapter){
        $chapterarr[]['id']=0;
    }
    $n=0;
	foreach($kearrss as $cpkey=>$cpval){
		foreach($cpval as $k=>$v){
			$kea[]=$v;
			if($kid==$v['id']){
				$nowkey=$n;
			}
			$n++;
		}
	}
	$upkey=$nowkey-1;
	$nextkey=$nowkey+1;
	$note_data=C::t('#keke_video_base#keke_video_note')->fetchfirst_byuid($kid,$_G['uid']);
	$answer_data=C::t('#keke_video_base#keke_video_answers')->fetchall_by_kid($kid);
	$isstudent=1;
	if($course['password'] && !$_G['cookie']['coursepassword_'.$kearr['cid']]){
		$ispassword=1;
		$isstudent=0;
	}else{	
		if($kearr['permissions']==1 || $kearr['permissions']==2){
			$validtime=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bycid($kearr['cid'],$_G['uid']);
			if(!$validtime || ($validtime['exp_time'] && $validtime['exp_time']<TIMESTAMP) || !$_G['uid']){
				$isstudent=0;
                $cpvalidtime=[];
				if($kearr['cpid']>0)$cpvalidtime=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bychapterid($kearr['cpid'],$_G['uid']);
				if($cpvalidtime && ($cpvalidtime['exp_time']==0 || $cpvalidtime['exp_time']>TIMESTAMP)){
					$isstudent=1;
				}else{
					$kevalidtime=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bykeid($kearr['id'],$_G['uid']);
					if($kevalidtime && ($kevalidtime['exp_time']==0 || $kevalidtime['exp_time']>TIMESTAMP)){
						$isstudent=1;
					}
				}
			}
			if($kearr['permissions']==2 && !$isstudent){
				$isstudent=$issk=1;
				$preview_time=$course['preview_time']?$course['preview_time']*60:180;
			}
		}elseif(($kearr['permissions']==3 || $kearr['permissions']==5) && !$_G['uid'] && $keke_video_base['uslogin']){
			$isstudent=0;
			$operationtip=1;
		}
	}
	if($_G['uid']==$course['uid'] || in_array($_G['groupid'],unserialize($keke_video_base['supergroup']))){
		$isstudent=$isVip=1;$issk=0;
		if(in_array($_G['groupid'],unserialize($keke_video_base['supergroup']))){
			$statetips=lang('plugin/keke_video_base', '261');
		}
	}else{
        $cateGroupArr=unserialize($allcatedata[$course['sub_cate']]['vip_groupids']);
        if($cateGroupArr && $appoint) {
            $course['vip']=1;
            $appoint=array_keys(array_flip($appoint)+array_flip($cateGroupArr));
        }
        if($keke_video_base['groupnosw']){
            foreach (getUserAllGroup() as $groupId) {
                if(in_array($groupId,$appoint)){
                    $isVipUser=1;
                    break;
                }
            }
        }else{
            $isVipUser=in_array($_G['groupid'],$appoint);
        }
		if($course['vip'] && $course['vipprice']<=0 && $isVipUser){
			$isstudent=1;$issk=0;
			$statetips=lang('plugin/keke_video_base', '312');
		}
	}
	$openchat= file_exists('source/plugin/keke_chat/keke_chat.inc.php') && $_G['cache']['plugin']['keke_chat'];
	if($openchat){
		$keke_chat = $_G['cache']['plugin']['keke_chat'];
		$cid=intval($_GET['kid']);
		$keke_chat['subkey']=dhtmlspecialchars($keke_chat['subkey']);
		include_once DISCUZ_ROOT."source/plugin/keke_chat/function.php";
		$facedata=_getface();
		$chatadminuids=C::t('#keke_chat#keke_chat_admin')->fetchfirst_byid($kid);
		if($_G['uid'] && in_array($_G['uid'],explode(',',$chatadminuids['adminuid']))){
			$ischatadmin=1;
		};
	}
	if($kearr['type']==1){
		$kedata=unserialize($kearr['concent']);
		if($kedata['videotype']==1){
			$mediadata=C::t('#keke_video_base#keke_video_media')->fetchfirst_byid($kedata['videoid']);
			$enc=$mediadata['enc'];
			if($enc==2){
				$playAuths=_getplayAuth($kedata['videoid']);
			}
			$videoinfo=_getplayinfo($kedata['videoid']);
			if(!$enc){
				$enc=1;
				foreach($videoinfo['PlayInfoList']['PlayInfo'] as $vkey=>$vval){
					if($vval['Encrypt']){
						$enc=($vval['EncryptType']=='HLSEncryption')?'3':'2';
					}
				}
				C::t('#keke_video_base#keke_video_media')->update($kedata['videoid'],array('enc'=>$enc));
			}
			if($enc!=2){
				$videourl=$videoinfo['PlayInfoList']['PlayInfo'][0]['PlayURL'];
				$kedata['videotype']=2;
			}
			if($enc==3){
				_insertkmstoken($kedata['videoid'],1);
			}
		}else{
			if(strpos($kedata['videodata'], '<iframe') !== false){
				$isiframe=1;
				preg_match('/<iframe.*?src\=[\'"](.*?)[\'"][^>]*>/i',$kedata['videodata'],$match);
				$videourl=$match[1];
				$videourl=str_ireplace("http://","https://",$videourl);
			}else{
				$ss=explode('.',$kedata['videodata']);
				$videourl=urlencode($kedata['videodata']);
			}
		}
	}elseif($kearr['type']==3){
		$kedata=unserialize($kearr['concent']);
		$live_endtime=$kedata['dete']+$kedata['lasttime']*60;
		$appname='uid_'.$kearr['uid'];
		$streamname=$appname.'_'.$kearr['id'];
		$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($course['uid']);
		$teacherpower=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
		if(TIMESTAMP>$live_endtime){
			if($kedata['rec']==2 && $kedata['livemode']!=2){
				if(!$kedata['videoid']){
					$livevidoe=searchMedia($streamname);
					if($livevidoe['Total']>1){
						foreach($livevidoe['MediaList'] as $vvvv){
							$video_lists[]['MediaId']=$vvvv['Video']['VideoId'];
						}
						$synvideodata=_getsynvideo($video_lists);
						$videoid=$synvideodata['MediaId'];
						$syning=1;
					}else{
						$videoid=$livevidoe['MediaList'][0]['Video']['VideoId'];
					}
					if($videoid){
						createAudit(array($videoid),1);
						if($teacherpower['permission_enc']==3 && $teacherpower['permission_tmp']){
							_transcodings($videoid,$teacherpower['permission_tmp'],1);
						}
						//delliverec($appname,$streamname);
						$kedata['videoid']=$videoid;
						C::t('#keke_video_base#keke_video_ke')->update($kid,array('concent'=>serialize($kedata),'rec'=>2));
						C::t('#keke_video_base#keke_video_media')->insert(array(
								'vid' => $videoid,
								'uid' => $kearr['uid'],
								'type'=> 3,
								'time'=> TIMESTAMP,
								'enc' => $teacherpower['permission_enc'],
								'subject'=>$kearr['title'].lang('plugin/keke_video_base', '003'),
								'state' => 1,
						), true);
						$kedata['videoid']=$videoid;
					}else{
						$novideo=1;
					}
				}
				$mediadata=C::t('#keke_video_base#keke_video_media')->fetchfirst_byid($kedata['videoid']);
				if($mediadata['enc']==2){
					$playAuths=_getplayAuth($kedata['videoid']);
				}else{
					$videoinfo=_getplayinfo($kedata['videoid']);
					$videourl=$videoinfo['PlayInfoList']['PlayInfo'][0]['PlayURL'];
					$kedata['videotype']=2;
				}
				$isrec=1;
				$kedata['cover']='cover';
			}else{
				$isliveend=1;
			}
		}else{
			if($kedata['livemode']==2){
				$videourl=urlencode($kedata['liveurls']);
			}else{
				$live_date=array(dgmdate($kedata['dete'], 'Y-m-d H:i'),dgmdate($live_endtime, 'Y-m-d H:i'));
				$live_code=_getkekelive($appname,$streamname);
				$videourl=$keke_video_base['h5live']?urlencode($live_code[1]['m3u8url']):urlencode((checkmobile() || strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'ipad'))?$live_code[1]['m3u8url']:$live_code[1]['rtmpurl']);
				if($kearr['rts']){
                   $videourl=$live_code[1]['rsturl'];
                }
			}
		}
		if($kearr['enc']==3){
			_insertkmstoken($videoid,3);
		}
	}elseif($kearr['type']==2){
		$kedatas=unserialize($kearr['concent']);
		$kedata['concent']=htmlspecialchars_decode($kedatas['concent']);
		$kedata['freeconcent']=htmlspecialchars_decode($kedatas['freeconcent']);
		if($kedatas['audio']){
			$kedata['videotype']=$kedatas['audio_type']?$kedatas['audio_type']:1;
			$videourl=$kedata['videoid']=$kedatas['audio'];
			$mediadata=C::t('#keke_video_base#keke_video_media')->fetchfirst_byid($kedatas['audio']);
			$enc=$mediadata['enc'];
			if(!$enc || checkmobile()){
				$videoinfo=_getplayinfo($kedata['videoid']);
				if(!$enc){
					$enc=1;
					foreach($videoinfo['PlayInfoList']['PlayInfo'] as $vkey=>$vval){
						if($vval['Encrypt']){
							$enc=($vval['EncryptType']=='HLSEncryption')?'3':'2';
						}
					}
					C::t('#keke_video_base#keke_video_media')->update($kedata['videoid'],array('enc'=>$enc));
				}
				if($enc!=2 && checkmobile()){
					$videourl=$videoinfo['PlayInfoList']['PlayInfo'][0]['PlayURL'];
					$CoverURL=($videoinfo['VideoBase']['CoverURL'])?$videoinfo['VideoBase']['CoverURL']:$course['img'];
					$audiotitle=kekevideo_utf2gbk($videoinfo['VideoBase']['Title']);
					$kedata['videotype']=2;
				}
			}
			if($kedata['videotype']==1 && !checkmobile()){
				$playAuths=_getplayAuth($kedatas['audio']);
			}
			if($enc==3){
				_insertkmstoken($kedata['videoid'],2);
			}
			$all_set['before_play_ad_time']=0;
			$keke_video_base['slideadtxt']='';
		}
		$keke_video_base['watermarktxt']=str_ireplace(array('[name]','[date]'),array($_G['username'],dgmdate(TIMESTAMP, 'Y-m-d')),dhtmlspecialchars($keke_video_base['watermarktxt']));
	}
	if($vids){
        $Video_result = getVideoInfos($vids);
    }
	if(!$isstudent){
		$videourl='';
	}
    if($all_set['before_play_ad_videoad']){
        $before_play_video_arr=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',$all_set['before_play_ad_videoad']));
        $before_play_video=explode('|',$before_play_video_arr[array_rand($before_play_video_arr)]);
    }
	if(in_array($kid,explode(',',$all_set['before_play_ad_exemptcid'])) || in_array($_G['groupid'],explode(',',$all_set['before_play_ad_exemptgid']))){
		$all_set['before_play_ad_time']=0;
        $before_play_video=[];
	}
	if(in_array($kid,explode(',',$all_set['ban_video_ad_exemptcid'])) || in_array($_G['groupid'],explode(',',$all_set['ban_video_ad_exemptgid']))){
		$all_set['ban_video_on']=0;
	}
	$keke_video_base['slideadtxt']=str_ireplace(array('{username}','{uid}'),array($_G['username'],$_G['uid']),dhtmlspecialchars($keke_video_base['slideadtxt']));
	$keke_video_base['buyvipurl']=dhtmlspecialchars($keke_video_base['buyvipurl']);
	$keke_video_base['fontsize']=$keke_video_base['fontsize']?intval($keke_video_base['fontsize']):'';
	$keke_video_base['lineheight']=$keke_video_base['lineheight']?intval($keke_video_base['lineheight']):'';
	$course['img']=(strstr($course['img'], "http")!== false)?$course['img']:$_G['siteurl'].$course['img'];
	$inipad=(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'ipad'))?true:false;
	if($keke_video_base['keviewdfnum']){
		$keviewdfnum=explode('|',$keke_video_base['keviewdfnum']);
		$dfnum=mt_rand($keviewdfnum[0], $keviewdfnum[1]);
		if($kearr['view']<=1){
			$kearr['view']=$dfnum;
		}
		C::t('#keke_video_base#keke_video_ke')->update($kearr['id'],array('view'=>$kearr['view']));
	}
}elseif($_GET['ac']=='pay'){
	if(!$_G['uid']) {
		_tologin();
	}
    $appoint=unserialize($keke_video_base['appoint']);
    $keke_video_base['getcrediturl']=_video_editor_safe_replace($keke_video_base['getcrediturl']);
	if(!K_INMINIPROGRAM && (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false) && $keke_video_base['wxappid'] && $keke_video_base['wxsecert']){
		include_once libfile('function/cache');
		include_once DISCUZ_ROOT."source/plugin/keke_video_base/inc.php";
		$tools = new JsApiPay();
		$openId = $tools->GetOpenid();
		if(!$openId && $_GET['code']){
			$url = $_G['siteurl'].'plugin.php?id=keke_video_base&ac=pay&cid='.$_GET['cid'];
			Header("Location: $url");
		}
        dsetcookie($uskey, authcode($openId, 'ENCODE', $_G['config']['security']['authkey']), 8640000);
	}
	$member = C::t('common_member_count')->fetch($_G['uid']);
	for($i=1;$i<=8;$i++){
		$membercre[]=$member['extcredits'.$i];
	}
	$membercredit=dimplode($membercre);
	$currentcredit=$member['extcredits'.$keke_video_base['integraltype']];
	$creditname=$_G['setting']['extcredits'][$keke_video_base['integraltype']]['title'];
	$cid=dhtmlspecialchars($_GET['cid']);
	$orderid=dhtmlspecialchars($_GET['orderid']);
	$_GET['chapterid']=intval($_GET['chapterid']);
	$_GET['keid']=intval($_GET['keid']);
	$cids=explode(',',$cid);
	$total_price=0;
	if($orderid){
		$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($orderid);
		if($orderdata['state']==1){
			showmessage(lang('plugin/keke_video_base', '004'), '', array(), array('alert' => 'error'));
		}
		$ordercids=explode(',',$orderdata['cid']);
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($ordercids);
		$courarr_unit[]=$courses;
	}elseif($cid){
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
		foreach($courses as $pk=>$pv){
            $cateGroupArr=unserialize($allcatedata[$pv['sub_cate']]['vip_groupids']);
            if($cateGroupArr) {
                $pv['vip'] = 1;
            }
			$courarr_unit[$pv['uid']][]=$pv;
			$teacher_uids[]=$pv['uid'];
		}
		$teachers_data=C::t('#keke_video_base#keke_video_teacher')->fetch_all_by_uids($teacher_uids);
		$count_teacher=count($courarr_unit);
	}elseif($_GET['chapterid']){
		$chapterid=intval($_GET['chapterid']);
		$chapter=C::t('#keke_video_base#keke_video_chapter')->fetch_first_by_cpid($chapterid);
		$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($chapter['cid']);
		$course['price']=$chapter['price'];
		$course['subname']=$chapter['title'];
		$courarr_unit[$courses['uid']][]=$course;
		$courses[]=$course;
	}elseif($_GET['keid']){
		$keid=intval($_GET['keid']);
		$ke=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($keid);
		$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($ke['cid']);
		$course['price']=$ke['price'];
		$course['subname']=$ke['title'];
		$courarr_unit[$courses['uid']][]=$course;
		$courses[]=$course;
	}
	$i=0;
    $total_credit=array();
	foreach($courses as $key=>$val){
        $cateGroupArr=unserialize($allcatedata[$val['sub_cate']]['vip_groupids']);
        if($cateGroupArr && $appoint) {
            $val['vip']=1;
            $appoint=array_keys(array_flip($appoint)+array_flip($cateGroupArr));
        }
        if($keke_video_base['groupnosw']){
            foreach (getUserAllGroup() as $groupId) {
                if(in_array($groupId,$appoint)){
                    $isVipUser=1;
                    break;
                }
            }
        }else{
            $isVipUser=in_array($_G['groupid'],$appoint);
        }

		if($val['vip'] && $val['vipprice']>0 && $isVipUser && $_GET['cid']){
			$val['price']=$val['vipprice'];
		}
		$total_price+=$val['price'];
		if($val['credit']){
			$total_credit[$val['credit_type']]+=$val['credit'];
		}
	}
	if($orderid && $orderdata){
		$total_price=$orderdata['price'];
	}
	if($keke_video_base['deductionlimit']){
		$deductionlimit=($total_price*$keke_video_base['deductionlimit']/100)/$keke_video_base['proportion'];
	}
	$keke_video_base['buyclause']=_video_editor_safe_replace($keke_video_base['buyclause']);
	$pay=array('total'=>count($courses),'total_price'=>number_format($total_price,2),'total_prices'=>$total_price,'total_credit'=>$total_credit);
	$navtitle=lang('plugin/keke_video_base', '519');
}elseif($_GET['ac']=='setin'){
	if(!$_G['uid']) {
		_tologin();
	}
	$keke_video_base['setin']=_video_editor_safe_replace($keke_video_base['setin']);
	$teacher_data=C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
	$defaultgroid=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_bydefault();
	if($teacher_data['state']==1){
		dheader('location: plugin.php?id=keke_video_base:t');
	}
	if(!submitcheck('Submit_btn')) {
		$time=dgmdate($teacher_data['time'], 'Y-m-d H:i:s');
		$keke_video_base['entryclause']=_video_editor_safe_replace($keke_video_base['entryclause']);
	}else{
		if($teacher_data['state']==4){
			showmessage(lang('plugin/keke_video_base', '005'), NULL);
		}
		$profile=$_GET['profile'];
		if(!$profile['name']){
			showmessage(lang('plugin/keke_video_base', '006'), NULL);
		}
		if($keke_video_base['setinmust']){
            if(!$profile['tel']){
                showmessage(lang('plugin/keke_video_base', '007'), NULL);
            }

            if(!$profile['wechat']){
                showmessage(lang('plugin/keke_video_base', '008'), NULL);
            }

            if(!$profile['profile']){
                showmessage(lang('plugin/keke_video_base', '009'), NULL);
            }
        }
		$all_set=_get_set();
		$arr=array(
			'uid'=>$_G['uid'],
			'username'=>$_G['username'],
			'name'=>dhtmlspecialchars($profile['name']),
			'tel'=>dhtmlspecialchars($profile['tel']),
			'wechat'=>dhtmlspecialchars($profile['wechat']),
			'profile'=>dhtmlspecialchars($profile['profile']),
			'teachergroupid'=>$defaultgroid['id'],
			'state'=>0,
			'time'=>TIMESTAMP,
		);
		C::t('#keke_video_base#keke_video_teacher')->insert($arr,true,true);
		$all_set=_get_set();
		_video_send_notice(explode(',',$all_set['msg_adminuids']),'msg_admin_setin',array('tname'=>$_G['username']));
		showmessage(lang('plugin/keke_video_base', '010'), 'plugin.php?id=keke_video_base&ac=setin');
	}
}elseif($_GET['ac']=='teacher'){
	$tcid=intval($_GET['tcid']);
	$teacher_data=C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($tcid);
	$ppp=16;
	$tmpurl='plugin.php?id=keke_video_base&ac=teacher&tcid='.$tcid;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$where='uid='.$tcid.' AND state=1 AND hide=0';
	$order=" ORDER BY displayorder DESC,id DESC";
	$count_all=C::t('#keke_video_base#keke_video_course')->count_all($where);
	$coursearr=C::t('#keke_video_base#keke_video_course')->fetch_all_course($startlimit,$ppp,$where,$order);
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	$follow_data=C::t('#keke_video_base#keke_video_follow')->fetchfirst_byteacherid($tcid,$_G['uid']);
	$count['fl']=C::t('#keke_video_base#keke_video_follow')->count_all('tid='.$tcid);
	$count['st']=C::t('#keke_video_base#keke_video_validtime')->count_all('teacher_uid='.$tcid);
	$teacher_data['info']=html_entity_decode($teacher_data['info']);
	$shareurl=urlencode($_G['siteurl'].'plugin.php?id=keke_video_base&ac=teacher&tcid='.$tcid);
	$navtitle=str_replace('[teacher]',$teacher_data['name'],$all_set['teacher_title']);
	$metakeywords=str_replace('[teacher]',$teacher_data['name'],$all_set['teacher_keywords']);
	$metadescription=str_replace('[teacher]',$teacher_data['name'],$all_set['teacher_description']);
}elseif($_GET['ac']=='teacherlist'){
	$ppp=20;
	$tmpurl='plugin.php?id=keke_video_base&ac=teacherlist&tcid='.$tcid;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$where='state=1';
	$count_all=C::t('#keke_video_base#keke_video_teacher')->count_all($where);
	$teacherlist=C::t('#keke_video_base#keke_video_teacher')->fetch_all_teacher($startlimit,$ppp,$where,$order);
	foreach($teacherlist as $key=>$val){
		$teacheruids[$val['uid']]=$val['uid'];
	}
	$course_count=C::t('#keke_video_base#keke_video_course')->count_all_by_uids($teacheruids);
	$follow_count=C::t('#keke_video_base#keke_video_follow')->count_all_by_uids($teacheruids);
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
}elseif($_GET['ac']=='account'){
	if(!$_G['uid']) {
		_tologin();
	}
	$oparr=array('mycourse','order','favorites','records','cart','follow','msg','studylog');
	$_GET['op']=in_array($_GET['op'],$oparr)?$_GET['op']:(checkmobile()?'index':'mycourse');
	if($_GET['op']=='mycourse'){
		$where=' uid='.intval($_G['uid']);
		$mycoursearr=_getvalidtime(20,$where);
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($mycoursearr[3]);
		$multipage = $mycoursearr[1];
	}elseif($_GET['op']=='studylog'){
		$ppp=15;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$where=' uid='.intval($_G['uid']);
		$count_all=C::t('#keke_video_base#keke_video_studylog')->count_all($where);
		$dataarr=C::t('#keke_video_base#keke_video_studylog')->fetch_all_limit($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$coursearr[$val['cid']]=$val['cid'];
			$dataarr[$key]['times']=dgmdate($val['time'], 'Y-m-d H:i');
			$dataarr[$key]['percentage']=$val['learningtime']/$val['mediatime']*100;
			$dataarr[$key]['mediatime']=second2duration($val['mediatime']);
			$dataarr[$key]['learningtime']=second2duration($val['learningtime']);
			$kids[$val['keid']]=$val['keid'];
		}
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($coursearr);
		$kidsarr=C::t('#keke_video_base#keke_video_ke')->fetch_all($kids);
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].'plugin.php?id=keke_video_base&ac=account&op=studylog');
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	}elseif($_GET['op']=='order'){
		$where=" uid=".intval($_G['uid'])." AND id NOT LIKE '%ALL%'";
		$pageurl='plugin.php?id=keke_video_base&ac=account&op=order';
		$orderarr=_getorder(20,$where,$pageurl);
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($orderarr[2]);
		$multipage = $orderarr[1];
	}elseif($_GET['op']=='favorites'){
		$where=' uid='.intval($_G['uid']);
		$favoritesarr=_getfavorites(20,$where);
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($favoritesarr[2]);
		$multipage = $favoritesarr[1];
	}elseif($_GET['op']=='follow'){
		$follow_data=C::t('#keke_video_base#keke_video_follow')->fetch_byuid($_G['uid']);
	}elseif($_GET['op']=='cart'){
		$cartarr=C::t('#keke_video_base#keke_video_cart')->fetch_all_by_uid($_G['uid']);
		foreach($cartarr as $key=>$val){
			$cids[]=$val['cid'];
		}
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
		foreach($courses as $cval){
			$total_price+=$cval['price'];
			$total_credit[$cval['credit_type']]+=$cval['credit'];
		}
		
		$i=1;
		foreach($total_credit as $ctypes=>$cvals){
			$total_credits.=($cvals>0)?((($i==1)?'':' + ').$cvals.$_G['setting']['extcredits'][$ctypes]['title']):'';
			$i++;
		}
		$total_price=number_format($total_price,2);
	}elseif($_GET['op']=='msg'){
		
		$check=C::t('#keke_video_base#keke_video_openid')->fetch_first_byid($_G['uid']);
		if($check['openid']){
			$subscribe = _video_getwechatuserinfo($check['openid']);
		}
		
		
	}elseif($_GET['op']=='index'){
		$count[1]=C::t('#keke_video_base#keke_video_validtime')->count_all("uid=".$_G['uid']);
		$count[2]=C::t('#keke_video_base#keke_video_favorites')->count_all("uid=".$_G['uid']);
		$count[3]=C::t('#keke_video_base#keke_video_follow')->count_all("uid=".$_G['uid']);
	}
	if($_G['cache']['plugin']['keke_market']){
		$gomarket=1;
		if($keke_video_base['distribution']){
			$marketmember=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
			$gomarket=$marketmember?1:0;
		}
	}
	$teacher_data=C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
}elseif($_GET['ac']=='loading'){
	dheader('location: '.$_G['siteurl'].'plugin.php?id=keke_video_base&ac=account&op=order');
	
}elseif($_GET['ac']=='callmedia'){
	$i=1;
	$vid=dhtmlspecialchars($_GET['vid']);
	$mediadata=C::t('#keke_video_base#keke_video_media')->fetchfirst_byid($vid);
	$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($mediadata['uid']);
	$teacherpower=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
	if($teacherpower['permission_callmedia']){
		if($mediadata['enc']==2){
			$playAuths=_getplayAuth($vid);
		}else{
			if($mediadata['enc']==3){
				_insertkmstoken($vid,$mediadata['type']);
			}
			$videoinfo=_getplayinfo($vid);
			$videourl=$videoinfo['PlayInfoList']['PlayInfo'][0]['PlayURL'];
		}
		$size=array('100%','100%');
		if($_GET['w'] && $_GET['h']){
			$size=array(intval($_GET['w']),intval($_GET['h']));
		}
	}
	include template('keke_video_base:block');
	exit($callmedia);
}else{
	$teacheruids=array();
	$listnum=$keke_video_base['listnum']?intval($keke_video_base['listnum']):4;
	foreach($allcatedata as $cate){
		if($cate['upid']==0){
			$subcat=$cate['subcate']? $cate['subcate']:$cate['cate_id'];
			$video_list[$cate['cate_id']]=C::t('#keke_video_base#keke_video_course')->fetch_by_new($subcat,$listnum);
			foreach($video_list[$cate['cate_id']] as $key=>$cou){
                if($allcatedata[$cou['sub_cate']]['vip_groupids'])$video_list[$cate['cate_id']][$key]['vip']=1;
				$teacheruids[$cou['uid']]=$cou['uid'];
			}
		}
	}
	$teacher_data=C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
	$recommend['cate']=explode(',',$keke_video_base['hotcate']);
	$hotcourse_arr=explode(',',$keke_video_base['hot']);
	$hotcourse_data=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($hotcourse_arr);
	foreach($hotcourse_arr as $hk=>$hv){
		$recommend['course'][]=$hotcourse_data[$hv];
	}
	foreach($hotcourse_data as $hotv){
		$teacheruids[$hotv['uid']]=$hotv['uid'];
	}
	if($keke_video_base['recentlive']){
		$newlivecourse=C::t('#keke_video_base#keke_video_ke')->fetch_by_newlive(0,8);
		foreach($newlivecourse as $livekey=>$liveval){
			$newlivecourse[$livekey]['livestar']=dgmdate($liveval['mintime'], 'Y-m-d H:i:s');
			if($liveval['mintime']<TIMESTAMP && $liveval['liveend']>TIMESTAMP){
				$newlivecourse[$livekey]['livenow']=1;
			}
		}
		$conuntnewlive=ceil(count($newlivecourse)/2);
		for($i=0;$i<$conuntnewlive;$i++){
			$livehd.='<li></li>';
		}
	}
	$teacheruidsarr=C::t('#keke_video_base#keke_video_teacher')->fetch_all_by_uids($teacheruids);
	$navtitle=$all_set['index_title'];
	$metakeywords=$all_set['index_keywords'];
	$metadescription=$all_set['index_description'];
	
}
$keke_video_base['shareico']=(strstr($keke_video_base['shareico'], "http")!== false)?$keke_video_base['shareico']:$_G['siteurl'].$keke_video_base['shareico'];
$ua=0;
if($keke_video_base['appua']){
	$ua=(strstr($_SERVER['HTTP_USER_AGENT'], dhtmlspecialchars($keke_video_base['appua']))!== false)?1:0;
}

if((strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX")!== false || strstr($_SERVER['HTTP_USER_AGENT'], "QianFan")!== false  || strstr($_SERVER['HTTP_USER_AGENT'], "MicroMessenger")!== false || strstr($_SERVER['HTTP_USER_AGENT'], "Appbyme")!== false || $ua) && $keke_video_base['appheader']){
	$inapp=$_GET['app']=1;
	if(K_INCWECHAT){
		$inapp=0;
	}
}
$keke_video_base['appdowninfo']=explode('##',dhtmlspecialchars($keke_video_base['appdowninfo']));
$keke_video_base['followcode']=$keke_video_base['followcode']?explode('|',dhtmlspecialchars($keke_video_base['followcode'])):'';

if(checkmobile()){
	if($_GET['ac']){
		include template('keke_video_base:video_'.$_GET['ac']);
	}else{
		include template('keke_video_base:video_index');
	}
}else{
	if($_GET['ac']){
		include template('diy:video_'.$_GET['ac'], NULL, './source/plugin/keke_video_base/template');
	}else{
		include template('diy:video_index', NULL, './source/plugin/keke_video_base/template');
	}
}