<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
	if (submitcheck("forumset")) {
        $page = max(1, intval($_GET['page']));
        $jumpUrl='action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_live&page='.$page;
		if(is_array($_GET['keids'])) {
			if($_GET['optype'] == 'delete') {
				C::t('#keke_video_base#keke_video_ke')->delete($_GET['keids']);
			} elseif($_GET['optype'] == 'pass') {
				C::t('#keke_video_base#keke_video_ke')->update($_GET['keids'], array('state' => 0));
			} elseif($_GET['optype'] == 'refuse') {
				C::t('#keke_video_base#keke_video_ke')->update($_GET['keids'], array('state' => 2));
            } elseif($_GET['optype'] == 'cancelrts') {
                C::t('#keke_video_base#keke_video_ke')->update($_GET['keids'], array('rts' => 0));
            } elseif($_GET['optype'] == 'rts') {
                $uids=array();
                $allData=C::t('#keke_video_base#keke_video_ke')->fetch_all_by_keids($_GET['keids']);
                foreach ($allData as $val) {
                    $uids[$val['uid']]=$val['uid'];
                }
                foreach ($uids as $uid) {
                    setRtsSt($uid);
                }
                C::t('#keke_video_base#keke_video_ke')->update($_GET['keids'], array('rts' => 1));
			}
		}else{
			cpmsg(lang('plugin/keke_video_base', '161'), $jumpUrl, 'error');
		}
		if(!$_GET['optype']){
			cpmsg(lang('plugin/keke_video_base', '057'), $jumpUrl, 'error');
		}
		cpmsg(lang('plugin/keke_video_base', '058'), $jumpUrl, 'succeed');
	}
	
	$allcatedata=_get_allcatedata();
	if($_GET['ac']=='edit'){
		$kid=intval($_GET['kid']);
		$kedata=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($kid);
		$keconcent=unserialize($kedata['concent']);
		if (submitcheck("editsubmit")) {
			$starttime= strtotime($_GET['livetime']);
			$endtime= strtotime($_GET['liveendtime']);
			if($endtime<$starttime){
				cpmsg(lang('plugin/keke_video_base', '409'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_live&ac=edit&kid='.$kid, 'error');
			}
			$keconcent['dete']=$starttime;
			$keconcent['lasttime']=($endtime-$starttime)/60;
			$keconcent['introduction']=daddslashes($_GET['introduction']);
			$arr=array(
				'title'=>$_GET['title'],
				'livetime'=>$starttime,
				'liveendtime'=>$endtime,
				'concent'=>serialize($keconcent),
			);
			C::t('#keke_video_base#keke_video_ke')->update($kid,$arr);
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_live&page='.intval($_GET['page']), 'succeed');
		}
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_live&ac=edit");
		showtableheader(lang('plugin/keke_video_base', '177'));
		showsetting(lang('plugin/keke_video_base', '405'),'title',$kedata['title'],'text');
		showsetting(lang('plugin/keke_video_base', '406'),'introduction',$keconcent['introduction'],'textarea');
		showsetting(lang('plugin/keke_video_base', '407'),'livetime',dgmdate($kedata['livetime'], 'Y/m/d H:i:s'),'calendar','', 0, '', 1);
		showsetting(lang('plugin/keke_video_base', '408'),'liveendtime',dgmdate($kedata['liveendtime'], 'Y/m/d H:i:s'),'calendar','', 0, '', 1);
		echo '<input name="kid" type="hidden" value="'.$kid.'" /><input name="page" type="hidden" value="'.intval($_GET['page']).'" /><script type="text/javascript" src="static/js/calendar.js"></script>';
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
  }
    showtips('<li>'.lang('plugin/keke_video_base', '571').'</li><li>'.lang('plugin/keke_video_base', '572').'</li>');
	showtableheader(lang('plugin/keke_video_base', '163'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_live', 'testhd');
	showtablerow('', array('width="50"', 'width="100"'),
		array(
			'<b>'.lang('plugin/keke_video_base', '164').': </b>',
			'<input name="helpkw" type="text" />',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '065').'">'
		)
    );
	showformfooter(); /*Dism_taobao-com*/
	showtablefooter(); /*dism��taobao��com*/
	$where='type=3';$param='';
	if($_GET['helpkw']){
		$where.=" AND subject LIKE '%".addcslashes($_GET['helpkw'],'%_')."%'";
		$param.='&helpkw='.addcslashes($_GET['helpkw']);
	}
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_live");	
	showtableheader(lang('plugin/keke_video_base', '291'));
    showsubtitle(array(lang('plugin/keke_video_base', '067'), lang('plugin/keke_video_base', '165'),lang('plugin/keke_video_base', '166'),lang('plugin/keke_video_base', '167'),lang('plugin/keke_video_base', '168'),lang('plugin/keke_video_base', '169'),lang('plugin/keke_video_base', '072'),lang('plugin/keke_video_base', '118')));
	$ppp=20;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_live'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($allcount = C::t('#keke_video_base#keke_video_ke')->count_all($where)){
		$video_data=C::t('#keke_video_base#keke_video_ke')->fetch_all_ke($startlimit,$ppp,$where,$order);
		foreach($video_data as $k=>$v){
			$cids[]=$v['cid'];
		}
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
		foreach($video_data as $key=>$val){
			$op='<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_live&ac=edit&kid='.$val['id'].'&page='.intval($_GET['page']).'" class="locking">'.lang('plugin/keke_video_base', '170').'</a>';
			$val['concent']=unserialize($val['concent']);
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="keids[]" value="'.$val['id'].'" />';
			$table[1] = '<a href="plugin.php?id=keke_video_base&ac=play&kid='.$val['id'].'" target="_blank">'.$val['title'].'</a>'.($val['rts']?'<span class="rtsico">'.lang('plugin/keke_video_base', '570').'</span>':'').'<br><div class="livedec">'.cutstr($val['concent']['introduction'],130).'</div>';
			$table[2] = '<a href="plugin.php?id=keke_video_base&ac=course&cid='.$val['cid'].'" target="_blank" class="teachername">'.$courses[$val['cid']]['username'].'</a><br><a href="plugin.php?id=keke_video_base&ac=course&cid='.$val['cid'].'" target="_blank">'.$courses[$val['cid']]['title'].'</a>';
			$table[3] = dgmdate($val['concent']['dete'], 'Y/m/d H:i').'<br>'.dgmdate($val['concent']['dete']+($val['concent']['lasttime']*60), 'Y/m/d H:i');
			$table[4] = $val['concent']['rec']?lang('plugin/keke_video_base', '171'):lang('plugin/keke_video_base', '172');
			$table[5] = $val['permissions']==1?lang('plugin/keke_video_base', '173'):lang('plugin/keke_video_base', '174');
			$table[6] = $val['state']==0?'<span class="zc">'.lang('plugin/keke_video_base', '175').'</span>':($val['state']==1?'<span class="ds">'.lang('plugin/keke_video_base', '105').'</span>':'<span class="jj">'.lang('plugin/keke_video_base', '077').'</span>');
			$table[7] = $op;
			showtablerow('',array('','width=""','width=""'), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	echo '<style>.rtsico{ margin-left: 10px; background: #ff930d; padding: 1px 5px; color: #fff}.ds{color: #F60;}.jj{color: #c30;}.zc{color: #3fd411;}.teachername{color: #999;margin: 0px 0px 7px 0;display: inline-block;}.livedec{ color:#999; margin:7px 10px 3px 0; line-height:20px; width:450px}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}.locking{ color:#c30}.sline{color:#e3e3e3;margin:0 5px;}</style>';
	showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'keids\')"><label for="chkallIuPN">'.lang('plugin/keke_video_base', '067').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_video_base', '135').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="pass" value="pass" class="radio" /><label for="pass" class="vmiddle">'.lang('plugin/keke_video_base', '106').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="refuse" value="refuse" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_video_base', '107').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="rts" value="rts" class="radio" /><label for="rts" class="vmiddle" style="color: #f38701">'.lang('plugin/keke_video_base', '570').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="cancelrts" value="cancelrts" class="radio" /><label for="cancelrts" class="vmiddle">'.lang('plugin/keke_video_base', '573').'</label>','<input type="hidden" name="page" value="'.$page.'">');
    showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/