<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

	$table = array();
	showtips(lang('plugin/keke_video_base', '298'));
    showtableheader(lang('plugin/keke_video_base', '299'));	
    showsubtitle(array(lang('plugin/keke_video_base', '300'),'', lang('plugin/keke_video_base', '301'), lang('plugin/keke_video_base', '302')));
	
	
	$wap=file_exists("source/plugin/keke_market/keke_market.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_video_base', '304').'</span>' : '<a href="https://dism.taobao.com/?@keke_market.plugin"><span class="error">'.lang('plugin/keke_video_base', '305').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_video_base/template/images/keke_market.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_video_base', '413');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_video_base', '414').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	
	$wap=file_exists("source/plugin/keke_chat/keke_chat.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_video_base', '304').'</span>' : '<a href="https://dism.taobao.com/?@keke_chat.plugin"><span class="error">'.lang('plugin/keke_video_base', '305').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_video_base/template/images/keke_chat.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_video_base', '303');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_video_base', '306').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	$wap=file_exists("source/class/block/course/blockclass.php")? '<span class="diffcolor2">'.lang('plugin/keke_video_base', '304').'</span>' : '<a href="https://dism.taobao.com/?@keke_videodiy.pack"><span class="error">'.lang('plugin/keke_video_base', '305').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_video_base/template/images/keke_videodiy.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_video_base', '355');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_video_base', '356').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	$wap=file_exists("source/plugin/keke_group/keke_group.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_video_base', '304').'</span>' : '<a href="https://dism.taobao.com/?@keke_group.plugin"><span class="error">'.lang('plugin/keke_video_base', '305').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_video_base/template/images/keke_group.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_video_base', '307');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_video_base', '308').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	$wap=file_exists("source/plugin/keke_chongzhi/keke_chongzhi.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_video_base', '304').'</span>' : '<a href="https://dism.taobao.com/?@keke_chongzhi.plugin"><span class="error">'.lang('plugin/keke_video_base', '305').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_video_base/template/images/keke_chongzhi.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_video_base', '309');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_video_base', '310').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	
	$wap=file_exists("source/plugin/keke_help/keke_help.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_video_base', '304').'</span>' : '<a href="https://dism.taobao.com/?@keke_help.plugin"><span class="error">'.lang('plugin/keke_video_base', '305').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_video_base/template/images/keke_help.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_video_base', '411');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_video_base', '412').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	
	$wap=file_exists("source/plugin/keke_exam/keke_exam.inc.php")? '<span class="diffcolor2">'.lang('plugin/keke_video_base', '304').'</span>' : '<a href="https://dism.taobao.com/plugins/keke_exam.html"><span class="error">'.lang('plugin/keke_video_base', '305').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_video_base/template/images/keke_exam.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_video_base', '538');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_video_base', '537').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
	
	$wap=file_exists("source/plugin/keke_domain/keke_domain.php")? '<span class="diffcolor2">'.lang('plugin/keke_video_base', '304').'</span>' : '<a href="https://dism.taobao.com/plugins/keke_domain.html"><span class="error">'.lang('plugin/keke_video_base', '305').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_video_base/template/images/keke_domain.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_video_base', '535');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_video_base', '536').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="50"','width="180"', 'width="600"'), $table);
	
    showtablefooter(); /*dism��taobao��com*/
