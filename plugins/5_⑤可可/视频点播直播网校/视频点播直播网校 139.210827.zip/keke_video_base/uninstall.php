<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_video_answers= DB::table("keke_video_answers");
$keke_video_cart= DB::table("keke_video_cart");
$keke_video_cash= DB::table("keke_video_cash");
$keke_video_cashout= DB::table("keke_video_cashout");
$keke_video_cate= DB::table("keke_video_cate");
$keke_video_chapter= DB::table("keke_video_chapter");
$keke_video_course= DB::table("keke_video_course");
$keke_video_evaluate= DB::table("keke_video_evaluate");
$keke_video_favorites= DB::table("keke_video_favorites");
$keke_video_follow= DB::table("keke_video_follow");
$keke_video_ke= DB::table("keke_video_ke");
$keke_video_media= DB::table("keke_video_media");
$keke_video_note= DB::table("keke_video_note");
$keke_video_order= DB::table("keke_video_order");
$keke_video_set= DB::table("keke_video_set");
$keke_video_slider= DB::table("keke_video_slider");
$keke_video_teacher= DB::table("keke_video_teacher");
$keke_video_teachergroup= DB::table("keke_video_teachergroup");
$keke_video_token= DB::table("keke_video_token");
$keke_video_validtime= DB::table("keke_video_validtime");
$keke_video_file= DB::table("keke_video_file");
$keke_video_openid= DB::table("keke_video_openid");
$keke_video_studylog= DB::table("keke_video_studylog");
$sql = <<<EOF
DROP TABLE IF EXISTS `$keke_video_answers`;
DROP TABLE IF EXISTS `$keke_video_cart`;
DROP TABLE IF EXISTS `$keke_video_cash`;
DROP TABLE IF EXISTS `$keke_video_cashout`;
DROP TABLE IF EXISTS `$keke_video_cate`;
DROP TABLE IF EXISTS `$keke_video_chapter`;
DROP TABLE IF EXISTS `$keke_video_course`;
DROP TABLE IF EXISTS `$keke_video_evaluate`;
DROP TABLE IF EXISTS `$keke_video_favorites`;
DROP TABLE IF EXISTS `$keke_video_follow`;
DROP TABLE IF EXISTS `$keke_video_ke`;
DROP TABLE IF EXISTS `$keke_video_media`;
DROP TABLE IF EXISTS `$keke_video_note`;
DROP TABLE IF EXISTS `$keke_video_order`;
DROP TABLE IF EXISTS `$keke_video_set`;
DROP TABLE IF EXISTS `$keke_video_slider`;
DROP TABLE IF EXISTS `$keke_video_teacher`;
DROP TABLE IF EXISTS `$keke_video_teachergroup`;
DROP TABLE IF EXISTS `$keke_video_token`;
DROP TABLE IF EXISTS `$keke_video_validtime`;
DROP TABLE IF EXISTS `$keke_video_file`;
DROP TABLE IF EXISTS `$keke_video_openid`;
DROP TABLE IF EXISTS `$keke_video_studylog`;
EOF;

runquery($sql);
$finish = true;