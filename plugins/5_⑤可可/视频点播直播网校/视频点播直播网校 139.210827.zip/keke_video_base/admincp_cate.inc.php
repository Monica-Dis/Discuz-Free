<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
		loadcache('plugin');
		require_once DISCUZ_ROOT.'./source/plugin/keke_video_base/function.php';
		if(submitcheck('catesubmit')) {
			_save_cat();
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_cate', 'succeed');
		}

		if($_GET['ac']=='editvipgroup'){
		    $cateid=intval($_GET['cateid']);
            if (submitcheck("editsubmit")) {
                C::t('#keke_video_base#keke_video_cate')->update($cateid,array(
                    'vip_groupids'=>($_GET['groupid'][0]?serialize($_GET['groupid']):''),
                ));
                _save_cat();
                cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_cate', 'succeed');
            }
            $allcatedata=_get_allcatedata();
            $vipGroupArr=unserialize($allcatedata[$cateid]['vip_groupids']);
            $query = C::t('common_usergroup')->fetch_all_not(array(6, 7), true);
            foreach($query as $group) {
                $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
                $groupselect[$group['type']] .= "<option value=\"$group[groupid]\" ".(in_array($group['groupid'], $vipGroupArr) ? 'selected' : '').">$group[grouptitle]</option>\n";
            }
            $groupselect = '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
                ($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
                ($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
                '<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup>';
            showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_cate&ac=editvipgroup");
            showtips('<li>'.lang('plugin/keke_video_base', '552').'</li>');
            showtableheader($allcatedata[$cateid]['name'].' - '.lang('plugin/keke_video_base', '551'));
            showsetting('members_search_group', '', '', '<select name="groupid[]" multiple="multiple" size="10">'."<option value='' ".(!$allcatedata[$cateid]['vip_groupids'] ? 'selected' : '').">".lang('plugin/keke_video_base', '554')."</option>\n".$groupselect.'</select>');
            echo '<input name="cateid" type="hidden" value="'.$cateid.'" />';
            showsubmit('editsubmit', 'submit', '','');
            showtablefooter(); /*dism��taobao��com*/
            showformfooter(); /*Dism_taobao-com*/
            exit;
        }
        showtips('<li>'.lang('plugin/keke_video_base', '552').'</li>');
		showformheader('plugins&operation=config&do=' . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . '&pmod=admincp_cate','testhd');
        showtableheader(lang('plugin/keke_video_base', '553'));
		showsubtitle(array('del', '', 'VIP',lang('plugin/keke_video_base', '087')));
		$allcatedata=_get_allcatedata();
		foreach($allcatedata as $key => $value) {
			$style = $value['upid'] ? '' : 'parent';
			if(!$value['upid'] && $reckey) {
				$upid = $allcatedata[$reckey]['upid'] ? $allcatedata[$reckey]['upid'] : $reckey;
				echo '<tr><td></td><td colspan="20"><div class="lastboard"><a href="###" onclick="addrow(this, 1, '.$upid.')" class="addtr">'.lang('plugin/keke_video_base', '085').'</a></div></td></tr>';
			}
			$ico=!$value['upid'] ? '<input type="text" class="txt" name="icon_id['.$value['cate_id'].']" value="'.$value['icon_id'].'" />':'';
            $groupArr=$value['vip_groupids']?unserialize($value['vip_groupids']):array();
            $groupNum=count($groupArr);
			showtablerow('', array('class="td25"', '','class="td24"','class="td25"'), array(
				'<input type="checkbox" class="checkbox" name="delete[]" value="'.$value['cate_id'].'" />',
				'<div class="'.$style.'board"><input type="text" class="txt" name="name['.$value['cate_id'].']" value="'.$value['name'].'" /><span class="lightfont"> id: '.$value['cate_id'].'</span></div>',
                ($value['upid'] || !$value['subcate']?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_cate&ac=editvipgroup&cateid='.$value['cate_id'].'">'.lang('plugin/keke_video_base', '551').'</a> ('.$groupNum.')':''),
                '<input type="text" class="txt" name="displayorder['.$value['cate_id'].']" value="'.$value['displayorder'].'" />',
			));
			$reckey = $key;
		}
		if($reckey) {
			$upid = $allcatedata[$reckey]['upid'] ? $allcatedata[$reckey]['upid'] : $reckey;
		}
		if($upid) {
			echo '<tr><td></td><td colspan="20"><div class="lastboard"><a href="#" onclick="addrow(this, 1, '.$upid.')" class="addtr">'.lang('plugin/keke_video_base', '085').'</a></div></td></tr>';
		}
		echo '<tr><td></td><td><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/keke_video_base', '086').'</a></div></td><td colspan="20"></td></tr>';
		showsubmit('catesubmit', 'submit', 'del');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		echo '<script type="text/javascript">
		var rowtypedata = [
			[[1, \'<input type="checkbox" class="checkbox" name="newhot[]" />\', \'td25\'], [1, \'<input type="text" class="txt" name="newname[]" />\', \'\'], [1, \'\', \'\'],[1, \'<input type="text" class="txt" name="newdisplayorder[]" />\', \'td25\'], [1, \'<input type="hidden" name="upid[]" value="0" />\']],
			[[1, \'<input type="checkbox" class="checkbox" name="newhot[]" />\', \'td25\'], [1, \'<div class="board"><input type="text" class="txt" name="newname[]" /></div>\', \'\'], [1, \'\', \'\'],[1, \'<input type="text" class="txt" name="newdisplayorder[]" />\', \'td25\'],  [1, \'<input type="hidden" name="upid[]" value="{1}" />\']],
		];
		</script><style>.imgsize{height:25px;vertical-align:middle;cursor:pointer; margin-left:10px;}
.imgprevew{position:absolute;z-index:999;border:1px solid #eee;left:0; top:40px; display:none}
.imgbox{ position:relative; }</style>';