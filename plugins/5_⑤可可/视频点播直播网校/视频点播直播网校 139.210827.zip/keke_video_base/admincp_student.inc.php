<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
	
	$_GET['op']=$_GET['op']?$_GET['op']:'stulog';
	_showadminsubmenu(array(
		array(lang('plugin/keke_video_base', '483'), "stulog"),
		array(lang('plugin/keke_video_base', '328'), "student"),
	),'admincp_student');
	if ($_GET['op'] == 'stulog') {
		showtableheader(lang('plugin/keke_video_base', '487'));
		showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_student&op=stulog', 'testhd');
		showtablerow('', array(),
			array(
				'<input name="byuid" type="text" value="'.($_GET['byuid']?intval($_GET['byuid']):'').'" size="10" placeholder="'.lang('plugin/keke_video_base', '296').'UID" />
				<input name="teacherid" type="text" size="10" value="'.($_GET['teacherid']?intval($_GET['teacherid']):'').'" placeholder="'.lang('plugin/keke_video_base', '092').'UID"/>
				<input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15" placeholder="'.lang('plugin/keke_video_base', '466').'"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'" placeholder="'.lang('plugin/keke_video_base', '467').'"/>
				<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '065').'"><input name="inajax" type="hidden" value="1" /><script src="static/js/calendar.js"></script>'
			)
		);
		showformfooter(); /*Dism_taobao-com*/
		showtablefooter(); /*dism��taobao��com*/
		$where="1";$param='';
		if($_GET['teacherid']){
			$coursearr=C::t('#keke_video_base#keke_video_course')->fetch_all_course(0,100,'uid='.intval($_GET['teacherid']));
			foreach($coursearr as $val){
				 $cids[$val['id']]=$val['id'];
			}
			$where.=" AND cid in (".dimplode ($cids).")";
			$param.='&teacherid='.intval($_GET['teacherid']);
		}
		if($_GET['byuid']){
			$where.=" AND uid=".intval($_GET['byuid']);
			$param.='&byuid='.intval($_GET['byuid']);
		}
		if($_GET['time']){
			$where.=" AND time>".strtotime($_GET['time']);
			$param.='&time='.dhtmlspecialchars($_GET['time']);
		}
		if($_GET['endtime']){
			$where.=" AND time<".strtotime($_GET['endtime']);
			$param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
		}
		showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_student&op=stulog");	
		showtableheader(lang('plugin/keke_video_base', '483'));
		showsubtitle(array(lang('plugin/keke_video_base', '477'),lang('plugin/keke_video_base', '294'),lang('plugin/keke_video_base', '478'),lang('plugin/keke_video_base', '479'),lang('plugin/keke_video_base', '480'),lang('plugin/keke_video_base', '481'),lang('plugin/keke_video_base', '482')));
		$ppp=30;
		$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_student&op=stulog'.$param;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		require_once libfile('function/misc');
		if($count_all=C::t('#keke_video_base#keke_video_studylog')->count_all($where)){
			$dataarr=C::t('#keke_video_base#keke_video_studylog')->fetch_all_limit($startlimit,$ppp,$where,$order);
			foreach($dataarr as $key=>$val){
				$coursearr[2][$val['uid']]=$val['uid'];
				$coursearr[3][$val['cid']]=$val['cid'];
				$kids[$val['keid']]=$val['keid'];
			}
			$kidsarr=C::t('#keke_video_base#keke_video_ke')->fetch_all($kids);
			$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($coursearr[3]);
			$members = C::t('common_member')->fetch_all_username_by_uid($coursearr[2]);
			foreach($dataarr as $key=>$val){
				$historyip='';
				$historyiparr=array();
				$historyiparr=explode(',',$val['historyip']);
				foreach($historyiparr as $v){
					if($v)$historyip.=$v.' '.convertip($v).'<br/>';
				}
				$table = array();
				$table[1] = '<a href="plugin.php?id=keke_video_base&ac=course&cid='.$val['cid'].'" target="_blank">'.$courses[$val['cid']]['title'].'</a><br><div class="livedec"><a href="plugin.php?id=keke_video_base&ac=play&kid='.$val['keid'].'" target="_blank" class="teachername">'.$kidsarr[$val['keid']]['title'].'</a></div>';
				$table[2] = '<a href="plugin.php?id=keke_video_base&ac=course&cid='.$val['cid'].'" target="_blank">'.$members[$val['uid']].'</a> <span class="teachername"> / uid:'.$val['uid'].'</a>';
				$table[3] = dgmdate($val['time'], 'Y/m/d H:i:s');
				$table[4] = second2duration($val['learningtime']).' / '.second2duration($val['mediatime']).'<br><div class="layui-progress" style="margin-top:10px; width:150px">
			  <div class="layui-progress-bar layui-bg-red" lay-percent="'.($val['learningtime']/$val['mediatime']*100).'%"></div>
			</div>';
				$table[5] = $val['type']=='pc'?'<span class="jj">'.$val['type'].'</span>':'<span class="zc">'.$val['type'].'</span>';
				$table[6] = $val['ip'].' '.convertip($val['ip']);;
				$table[7] = '<div class="historyip">'.$historyip.'</div>';
				showtablerow('',array('','width=""','width=""'), $table);
			}
		}
		$multipage='';
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
		echo '<script src="source/plugin/keke_video_base/template/layui/layui.js"></script><script>layui.use(\'element\', function(){var element = layui.element;});</script><style>.layui-progress-bar{position:absolute;left:0;top:0;width:0;max-width:100%;height:6px;border-radius:20px;text-align:right;background-color:#5fb878;transition:all .3s;-webkit-transition:all .3s}.layui-progress{position:relative;height:6px;border-radius:20px;background-color:#e2e2e2}.layui-bg-red{background-color:#ff5722!important}.historyip{width:220px; height:60px; overflow-y:scroll; word-wrap:break-word}.ds{color: #F60;}.jj{color: #c30;}.zc{color: #3fd411;}.teachername{color: #999;margin: 0px 0px 7px 0;display: inline-block;}.livedec{ color:#999; margin:7px 10px 3px 0; line-height:20px; width:450px}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}.locking{ color:#c30}.sline{color:#e3e3e3;margin:0 5px;}</style>';
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
	
	}elseif($_GET['op'] == 'student') {
		
		
		$where="1";$param='';
		
		if($_GET['uid']){
			$where.=" AND uid=".intval($_GET['uid']);
			$param.='&uid='.intval($_GET['uid']);
		}
		if($_GET['time']){
			$where.=" AND latest_change_time>".strtotime($_GET['time']);
			$param.='&time='.dhtmlspecialchars($_GET['time']);
		}
		if($_GET['endtime']){
			$where.=" AND latest_change_time<".strtotime($_GET['endtime']);
			$param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
		}
		
		if (submitcheck("forumset") || $_GET['ac']=='delstu') {
			if($_GET['optype'] == 'delete') {
				$validid=$_GET['delete'];
			}else{
				$validid=intval($_GET['validid']);
			}
			C::t('#keke_video_base#keke_video_validtime')->delete($validid);
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].$param.'&identifier=keke_video_base&pmod=admincp_student&op=student', 'succeed');
		}
		showtips(lang('plugin/keke_video_base', '530'));
		showtableheader(lang('plugin/keke_video_base', '487'));
		showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_student&op=student', 'testhd');
		showtablerow('', array(),
			array(
				'<input name="uid" type="text" value="'.($_GET['uid']?intval($_GET['uid']):'').'" size="10" placeholder="'.lang('plugin/keke_video_base', '296').'UID" />
				<input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15" placeholder="'.lang('plugin/keke_video_base', '528').'"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'" placeholder="'.lang('plugin/keke_video_base', '529').'"/>
				<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '065').'"><input name="inajax" type="hidden" value="1" /><script src="static/js/calendar.js"></script>'
			)
		);
		showformfooter(); /*Dism_taobao-com*/
		showtablefooter(); /*dism��taobao��com*/
		
		showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_student&op=student");
		showtableheader(lang('plugin/keke_video_base', '483'));
		showsubtitle(array('del',lang('plugin/keke_video_base', '294'),lang('plugin/keke_video_base', '169'),lang('plugin/keke_video_base', '524'),lang('plugin/keke_video_base', '525'),lang('plugin/keke_video_base', '468'),lang('plugin/keke_video_base', '118')));
		$ppp=30;
		$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_student&op=student'.$param;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
	
		$order='ORDER BY latest_change_time DESC,exp_time DESC';
		if($count_all=C::t('#keke_video_base#keke_video_validtime')->count_all($where)){
			$dataarr=C::t('#keke_video_base#keke_video_validtime')->fetch_all_validtime($startlimit,$ppp,$where,$order);
			foreach($dataarr as $key=>$val){
				$keids[$val['keid']]=$val['keid'];
				$cids[$val['cid']]=$val['cid'];
				$chapterids[$val['chapterid']]=$val['chapterid'];
				$uids[$val['uid']]=$val['uid'];
			}
			$kedsarr=C::t('#keke_video_base#keke_video_ke')->fetch_all($keids);
			$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
			$chapters=C::t('#keke_video_base#keke_video_chapter')->fetch_all_by_cpids($chapterids);
			$members = C::t('common_member')->fetch_all_username_by_uid($uids);
			$member_profile = C::t('common_member_profile')->fetch_all($uids);
			foreach($dataarr as $key=>$val){
				$title=$courses[$val['cid']]['title'];
				if($val['chapterid']){
					$title=$chapters[$val['chapterid']]['title'].'<span class="chapterstag">'.lang('plugin/keke_video_base', '526').'</span>';
					$val['cid']=$chapters[$val['chapterid']]['cid'];
				}elseif($val['keid']){
					$title=$kedsarr[$val['keid']]['title'].'<span class="ketag">'.lang('plugin/keke_video_base', '527').'</span>';
					$val['cid']=$kedsarr[$val['keid']]['cid'];
				}
				$table = array();
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
				$table[1] = '<a href="plugin.php?id=keke_video_base&ac=course&cid='.$val['cid'].'" target="_blank">'.$members[$val['uid']].'</a> <br><span class="dec"> '.$member_profile[$val['uid']]['mobile'].'</span>';
				$table[2] = '<a href="plugin.php?id=keke_video_base&ac=course&cid='.$val['cid'].'" target="_blank">'.$title.'</a>';
				$table[3] = ($val['exp_time']==0)?lang('plugin/keke_video_base', '016'):dgmdate($val['exp_time'], 'Y/m/d H:i:s');
				$table[4] = $val['latest_change_time']?dgmdate($val['latest_change_time'], 'Y/m/d H:i:s'):'-';
				$table[5] = $val['title'];
				$table[7] = '<a href="javascript:if(confirm(\''.lang('plugin/keke_video_base', '392').'\'))location=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_student&op=student&ac=delstu&validid='.$val['id'].'\'" class="addstubtn">'.lang('plugin/keke_video_base', '135').'</a>';
				showtablerow('',array(), $table);
			}
		}
		$multipage='';
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
		echo '<style>.ketag{ border:1px solid #F00; padding:0 5px; margin-left:10px; color:#F33}.layui-progress-bar{position:absolute;left:0;top:0;width:0;max-width:100%;height:6px;border-radius:20px;text-align:right;background-color:#5fb878;transition:all .3s;-webkit-transition:all .3s}.layui-progress{position:relative;height:6px;border-radius:20px;background-color:#e2e2e2}.layui-bg-red{background-color:#ff5722!important}.historyip{width:220px; height:60px; overflow-y:scroll; word-wrap:break-word}.ds{color: #F60;}.jj{color: #c30;}.zc{color: #3fd411;}.teachername{color: #999;margin: 0px 0px 7px 0;display: inline-block;}.dec{ color:#999; margin:7px 10px 3px 0; line-height:20px;}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}.locking{ color:#c30}.sline{color:#e3e3e3;margin:0 5px;}</style>';
		
		showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'uids\')"><label for="chkallIuPN">'.lang('plugin/keke_video_base', '067').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_video_base', '135').'</label><input name="uid" type="hidden" value="'.intval($_GET['uid']).'" /><input name="time" type="hidden" value="'.dhtmlspecialchars($_GET['time']).'" /><input name="endtime" type="hidden" value="'.dhtmlspecialchars($_GET['endtime']).'" />','');
		
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
	}