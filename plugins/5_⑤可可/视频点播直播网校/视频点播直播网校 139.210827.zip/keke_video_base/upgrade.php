<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_order'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('deduction', $col_field)){
	$sql = "Alter table ".DB::table('keke_video_order')." add `deduction` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('take', $col_field)){
	$sql = "Alter table ".DB::table('keke_video_order')." add `take` varchar(10) NOT NULL;"; 
	DB::query($sql); 
}

if(!in_array('buymod', $col_field)){
	$sql = "Alter table ".DB::table('keke_video_order')." add `buymod` int(1) NOT NULL;"; 
	DB::query($sql);
}

if(!in_array('vipprice', $col_field)){
    $sql = "Alter table ".DB::table('keke_video_order')." add `vipprice` float(20,2) NOT NULL;";
    DB::query($sql);
}


$teacherquery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_teacher'));
while($teacherrow = DB::fetch($teacherquery)) {
	$teacher_col_field[]=$teacherrow['Field']; 
}

if(!in_array('wechatqrcode', $teacher_col_field)){
	$teacher_sql = "Alter table ".DB::table('keke_video_teacher')." add `wechatqrcode` varchar(255) NOT NULL;";
	DB::query($teacher_sql); 
}

$mediaquery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_media'));
while($mediarow = DB::fetch($mediaquery)) {
	$media_col_field[]=$mediarow['Field']; 
}

if(!in_array('enc', $media_col_field)){
	$media_sql = "Alter table ".DB::table('keke_video_media')." add `enc` int(1) NOT NULL;"; 
	DB::query($media_sql); 
}


$tokenquery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_token'));
while($tokenrow = DB::fetch($tokenquery)) {
	$token_col_field[]=$tokenrow['Field']; 
}

if(!in_array('vid', $token_col_field)){
	$token_sql = "Alter table ".DB::table('keke_video_token')." add `vid` varchar(50) NOT NULL;";
	DB::query($token_sql); 
}

if(!in_array('mediatype', $token_col_field)){
	$token_sqls = "Alter table ".DB::table('keke_video_token')." add `mediatype` int(1) NOT NULL;"; 
	DB::query($token_sqls); 
}


$coursequery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_course'));
while($courserow = DB::fetch($coursequery)) {
	$course_col_field[]=$courserow['Field']; 
}

if(!in_array('vip', $course_col_field)){
	$course_sql = "Alter table ".DB::table('keke_video_course')." add `vip` int(1) NOT NULL;"; 
	DB::query($course_sql); 
}


if(!in_array('vipprice', $course_col_field)){
	$course_sqls = "Alter table ".DB::table('keke_video_course')." add `vipprice` float(20,2) NOT NULL;"; 
	DB::query($course_sqls); 
}

if(!in_array('onlyvip', $course_col_field)){
	$course_sql = "Alter table ".DB::table('keke_video_course')." add `onlyvip` int(1) NOT NULL;"; 
	DB::query($course_sql); 
}


if(!in_array('password', $course_col_field)){
	$course_sqls = "Alter table ".DB::table('keke_video_course')." add `password` varchar(200) NOT NULL;"; 
	DB::query($course_sqls); 
}

if(!in_array('hide', $course_col_field)){
	$course_sqls = "Alter table ".DB::table('keke_video_course')." add `hide` int(1) NOT NULL;";
	DB::query($course_sqls); 
}

if(!in_array('courseids', $course_col_field)){
    $course_sqls = "Alter table ".DB::table('keke_video_course')." add `courseids` varchar(255) NOT NULL;";
    DB::query($course_sqls);
}

$kequery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_ke'));
while($kerow = DB::fetch($kequery)) {
	$ke_col_field[]=$kerow['Field']; 
}

if(!in_array('liveendtime', $ke_col_field)){
	$ke_sql = "Alter table ".DB::table('keke_video_ke')." add `liveendtime` int(10) NOT NULL;"; 
	DB::query($ke_sql);
}

if(!in_array('price', $ke_col_field)){
	$ke_sql = "Alter table ".DB::table('keke_video_ke')." add `price` float(20,2) NOT NULL;"; 
	DB::query($ke_sql);
}

if(!in_array('view', $ke_col_field)){
	$ke_sql = "Alter table ".DB::table('keke_video_ke')." add `view` int(100) NOT NULL;";
	DB::query($ke_sql);
}

if(!in_array('rts', $ke_col_field)){
    $ke_sql = "Alter table ".DB::table('keke_video_ke')." add `rts` int(1) NOT NULL;";
    DB::query($ke_sql);
}

$chapterquery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_chapter'));
while($chapterrow = DB::fetch($chapterquery)) {
	$chapter_col_field[]=$chapterrow['Field']; 
}

if(!in_array('price', $chapter_col_field)){
	$chapter_sql = "Alter table ".DB::table('keke_video_chapter')." add `price` float(20,2) NOT NULL;"; 
	DB::query($chapter_sql);
}


$validtimequery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_validtime'));
while($validtimerow = DB::fetch($validtimequery)) {
	$validtime_col_field[]=$validtimerow['Field']; 
}

if(!in_array('chapterid', $validtime_col_field)){
	$validtime_sql = "Alter table ".DB::table('keke_video_validtime')." add `chapterid` int(50) NOT NULL;"; 
	DB::query($validtime_sql);
}

if(!in_array('keid', $validtime_col_field)){
	$validtime_sql = "Alter table ".DB::table('keke_video_validtime')." add `keid` int(80) NOT NULL;"; 
	DB::query($validtime_sql);
}


if(!in_array('latest_change_time', $validtime_col_field)){
	$validtime_sql = "Alter table ".DB::table('keke_video_validtime')." add `latest_change_time` int(10) NOT NULL;"; 
	DB::query($validtime_sql);
}

$teachergroupquery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_teachergroup'));
while($teachergrouprow = DB::fetch($teachergroupquery)) {
	$teachergroup_col_field[]=$teachergrouprow['Field']; 
}

if(!in_array('permission_give_credit', $teachergroup_col_field)){
	$teachergroup_sql = "Alter table ".DB::table('keke_video_teachergroup')." add `permission_give_credit` int(50) NOT NULL;"; 
	DB::query($teachergroup_sql);
}

if(!in_array('permission_give_credit_type', $teachergroup_col_field)){
	$teachergroup_sql = "Alter table ".DB::table('keke_video_teachergroup')." add `permission_give_credit_type` int(1) NOT NULL;"; 
	DB::query($teachergroup_sql);
}

if(!in_array('permission_callmedia', $teachergroup_col_field)){
	$teachergroup_sql = "Alter table ".DB::table('keke_video_teachergroup')." add `permission_callmedia` int(1) NOT NULL;"; 
	DB::query($teachergroup_sql);
}


$catequery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_cate'));
while($caterow = DB::fetch($catequery)) {
    $cate_col_field[]=$caterow['Field'];
}
if(!in_array('vip_groupids', $cate_col_field)){
    $cate_sql = "Alter table ".DB::table('keke_video_cate')." add `vip_groupids` varchar(255) NOT NULL;";
    DB::query($cate_sql);
}


$teachergroupquery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_teachergroup'));
while($teachergroupqueryrow = DB::fetch($teachergroupquery)) {
    $teachergroupqueryrow_col_field[]=$teachergroupqueryrow['Field'];
}
if(!in_array('permission_viptake', $teachergroupqueryrow_col_field)){
    $teachergroup_sql = "Alter table ".DB::table('keke_video_teachergroup')." add `permission_viptake` int(5) NOT NULL;";
    DB::query($teachergroup_sql);
}



$keke_video_file= DB::table("keke_video_file");
$sqlss = <<<EOF
CREATE TABLE IF NOT EXISTS `$keke_video_file` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `cid` int(50) NOT NULL,
  `chid` int(50) NOT NULL,
  `uid` int(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `displayorder` int(20) NOT NULL,
  `state` int(1) NOT NULL,
  `power` int(1) NOT NULL,
  `time` int(10) NOT NULL,
  `size` varchar(100) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filetype` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;
EOF;
runquery($sqlss);

$filequery = DB::query("SHOW COLUMNS FROM ".DB::table('keke_video_file'));
while($filerow = DB::fetch($filequery)) {
	$file_col_field[]=$filerow['Field']; 
}

if(!in_array('filename', $file_col_field)){
	$file_sql = "Alter table ".DB::table('keke_video_file')." add `filename` varchar(255) NOT NULL;"; 
	DB::query($file_sql);
}

if(!in_array('filetype', $file_col_field)){
	$file_sql = "Alter table ".DB::table('keke_video_file')." add `filetype` int(1) NOT NULL;"; 
	DB::query($file_sql);
}


$keke_video_openid= DB::table("keke_video_openid");
$sqlopenid = <<<EOF
CREATE TABLE IF NOT EXISTS `$keke_video_openid` (
  `uid` int(20) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `code` varchar(50) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  PRIMARY KEY (`uid`)
)ENGINE=MyISAM;
EOF;
runquery($sqlopenid);



$keke_video_studylog= DB::table("keke_video_studylog");
$sqlstudylog = <<<EOF
CREATE TABLE IF NOT EXISTS `$keke_video_studylog` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `cid` int(20) NOT NULL,
  `keid` int(20) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `mediatime` varchar(20) NOT NULL,
  `learningtime` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `time` int(10) NOT NULL,
  `historyip` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;
EOF;
runquery($sqlstudylog);
$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_video_base/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_video_base/upgrade.php');
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2tla2VfdmlkZW9fYmFzZS90ZW1wbGF0ZS9pbWFnZXMvV2VpeGluLmpwZw=='));