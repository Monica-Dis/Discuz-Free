<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
require_once DISCUZ_ROOT.'./source/plugin/keke_video_base/function.php';

if($_GET['formhash'] != $_G['formhash'] && $_GET['ac']!='kms' && !$_GET['downcode'] && $_GET['ac']!='tologin' && $_GET['ac']!='maglogin' && $_GET['ac']!='bindwechat') {
	exit('Formhash_Error');
}
if($_GET['ac']=='getUploadAuth'){
	try {
		$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
		$uploadInfo = createUploadVideo($client);
		exit(json_encode($uploadInfo));
	} catch (Exception $e) {
		print $e->getMessage()."\n";
	}
}elseif($_GET['ac']=='refreshUploadVideo'){
	try {
		$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
		$refresh = refreshUploadVideo($client);
		exit(json_encode($refresh));
	} catch (Exception $e) {
		print $e->getMessage()."\n";
	}
}elseif($_GET['ac']=='Uploadok'){
	$types=explode('/',$_GET['type']);
	$type=$types[0]=='video'?1:($types[0]=='audio'?2:3);
	$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
	$teacherpower=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
	$state=0;
	if($teacherpower['permission_media']==2){
		$state=1;
		$cre=createAudit(array($_GET['vid']),1);
		if(!$cre['RequestId']){
			createAudit(array($_GET['vid']),1);
		}
		if($teacherpower['permission_enc']==3){
			_transcodings($_GET['vid'],$teacherpower['permission_tmp'],1);
		}
	}
	C::t('#keke_video_base#keke_video_media')->insert(array(
			'vid' => $_GET['vid'],
			'uid' => $_G['uid'],
			'type'=> $type,
			'time'=> TIMESTAMP,
			'subject'=>kekevideo_utf2gbk($_GET['subject']),
			'state' => $state,
			'enc'=>$teacherpower['permission_enc'],
	), true);
}elseif($_GET['ac']=='addfile'){
	$all_set=_get_set();
	if($all_set['oss_on'] && $_GET['filetype']==1){
		$_GET['filetype']=3;
	}
	$arr=array(
		'uid' => $_G['uid'],
		'file' => ($_GET['filetype']==1 || $_GET['filetype']==3)?$_GET['file']:$_GET['fileurl'],
		'cid'=> intval($_GET['cid']),
		'power'=> intval($_GET['power']),
		'time'=> TIMESTAMP,
		'title'=>kekevideo_utf2gbk($_GET['title']),
		'size' => $_GET['size'],
		'state' => 1,
		'filetype' => intval($_GET['filetype']),
		'displayorder'=>$_GET['displayorder'],
		'filename'=>kekevideo_utf2gbk($_GET['filename'])
	 );
	if($_GET['fileid']){
		$arr['id']=intval($_GET['fileid']);
	}
	C::t('#keke_video_base#keke_video_file')->insert($arr, true, true);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delfile'){
	$fileid=intval($_GET['fileid']);
	$filedata=C::t('#keke_video_base#keke_video_file')->fetch_first_by_cpid($fileid);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($filedata['cid']);
	if($course['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	C::t('#keke_video_base#keke_video_file')->delete($fileid);
	@unlink(DISCUZ_ROOT . './'.$filedata['file']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='downfile'){
	if($_GET['downcode']){
		$code=authcode($_GET['downcode'], 'DECODE', $_G['config']['security']['authkey']);
		$codearr=explode('|',$code);
		$_G['uid']=intval($codearr[0]);
		$_G['groupid']=intval($codearr[1]);
		$_GET['courseid']=$codearr[2];
		$_GET['fileid']=$codearr[3];
	}
	$fileid=intval($_GET['fileid']);
	$cid=intval($_GET['courseid']);
	$filedata=C::t('#keke_video_base#keke_video_file')->fetch_first_by_cpid($fileid);
	if(!$filedata){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '319')))));
	}
	if($filedata['power']==1){
        $isVipUser=0;
        $allcatedata=_get_allcatedata();
		$appoint=unserialize($keke_video_base['appoint']);
        $course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
        $cateGroupArr=unserialize($allcatedata[$course['sub_cate']]['vip_groupids']);
        if($cateGroupArr && $appoint) {
            $appoint=array_keys(array_flip($appoint)+array_flip($cateGroupArr));
        }
		$supergroup=unserialize($keke_video_base['supergroup']);
		$validtime=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bycid($cid,$_G['uid']);
        if($keke_video_base['groupnosw']){
            foreach (getUserAllGroup() as $groupId) {
                if(in_array($groupId,$appoint)){
                    $isVipUser=1;
                    break;
                }
            }
        }else{
            $isVipUser=in_array($_G['groupid'],$appoint);
        }
		if((!$validtime || ($validtime['exp_time']>0 && $validtime['exp_time']<TIMESTAMP) || !$_G['uid']) && $_G['groupid']!=1 && !$isVipUser && !(in_array($_G['groupid'],$supergroup))){
			exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '320')))));
		}
	}elseif($filedata['power']==2 && !$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '321')))));
	}
	if($_GET['downcode']){
		if($filedata['file']){
			$all_set=_get_set();
			$temp=$all_set['oss_on']?'':DISCUZ_ROOT;
			if($filedata['filetype']==3 || strpos($filedata['file'], 'http') !== false){
				if($filedata['filetype']==3 && strpos($filedata['file'], 'http') === false)$filedata['file']=OSSSignatureurl($filedata['file'],$filedata['filename']);
				dheader("Location: ".$filedata['file']);
			}
			$file=$temp.$filedata['file'];
			$filename=$filedata['filename']?$filedata['filename']:basename($file);
			$filename = '"'.(strtolower(CHARSET) == 'utf-8' && strexists($_SERVER['HTTP_USER_AGENT'], 'MSIE') ? urlencode($filename) :$filename).'"';
			$filesize=filesize($file)?filesize($file):_keke_convertToBytes($filedata['size']);
            dheader('Date: '.gmdate('D, d M Y H:i:s', $filedata['time']).' GMT');
            dheader('Last-Modified: '.gmdate('D, d M Y H:i:s', $filedata['time']).' GMT');
            dheader('Content-Encoding: none');
            dheader('Content-Disposition: attachment; filename='.$filename);
            dheader('Content-Type: application/octet-stream');
            dheader('Content-Length: '.$filesize);
            @readfile($file);
            @flush();
            @ob_flush();
            exit ();
		}
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '319')))));
	}
	$downcode=urlencode(authcode($_G['uid'].'|'.$_G['groupid'].'|'.$cid.'|'.$fileid, 'ENCODE', $_G['config']['security']['authkey']));
	$downlink=$filedata['filetype']==2?$filedata['file']:'plugin.php?id=keke_video_base:ajax&ac=downfile&downcode='.$downcode;
	exit(json_encode(array('state'=>0,'downlink'=>$downlink)));
}elseif($_GET['ac']=='setossacl'){
	$all_set=_get_set();
	require_once DISCUZ_ROOT.'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-oss/aliyun-oss-php-sdk-2.3.1.phar';
	$endpoint = "//".$all_set['oss_endPoint'];
	$bucket= $all_set['oss_bucket'];
	$object = $_GET['filess'];
	try{
		$ossClient = new OSS\OssClient($all_set['oss_keyid'], $all_set['oss_keysecret'], $endpoint);
		$ossClient->putObjectAcl($bucket, $object, 'private');
	} catch(OssException $e) {
		printf(__FUNCTION__ . ": FAILED\n");
		printf($e->getMessage() . "\n");
		return;
	}
}elseif($_GET['ac']=='getosstoken'){	
	$all_set=_get_set();
	$expiretime = TIMESTAMP + 360;
	$filepath = 'keke_video_base/file/'.dgmdate($_G['timestamp'], 'Ymd').'/';
	$file_name = random(20);
	$condition = array(0=>'content-length-range', 1=>0, 2=>1048576000);
	$conditions[] = $condition;
	$policyarr = array('expiration'=>_keke_gmt_iso8601($expiretime),'conditions'=>$conditions);
	$policy=base64_encode(json_encode($policyarr));
    $data = array(
		'OSSAccessKeyId'=>$all_set['oss_keyid'],
		'policy'=>$policy,
		'expire'=>$expiretime,
		'filepath'=>$filepath,
		'target_filename'=>$file_name,
		'host'=>$all_set['oss_url']?$all_set['oss_url']:"https://".$all_set['oss_bucket'].".".$all_set['oss_endPoint'],
		'key' =>$filepath.$file_name.'.'.daddslashes($_GET['ext']),
		'signature'=>base64_encode(hash_hmac('sha1', $policy, $all_set['oss_keysecret'] , true))
	);
    exit(json_encode($data));
}elseif($_GET['ac']=='teacher'){
	$teacherarr=array(
		'uid'=>$_G['uid'],
		'username'=>kekevideo_utf2gbk($_GET['nickname']),
		'name'=>kekevideo_utf2gbk($_GET['name']),
		'img'=>$_GET['coveimg'],
		'profile'=>kekevideo_utf2gbk($_GET['profile']),
		'rank'=>kekevideo_utf2gbk($_GET['rank']),
		'wechatqrcode'=>$_GET['wechatqrcode'],
		'wechat'=>kekevideo_utf2gbk($_GET['wechat']),
	);
	foreach($teacherarr as $k=>$v){
		$teacherarr[$k]=dhtmlspecialchars($v);
	}
	$teacherarr['info']=kekevideo_utf2gbk($_GET['info']);
	$id=C::t('#keke_video_base#keke_video_teacher')->update($_G['uid'],$teacherarr);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addcourse'){
	$msg='';
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($_GET['courseid']);
	$course_uid=$course['uid']?$course['uid']:$_G['uid'];
	$teacher_data=C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($course_uid);
	$teachergroup = C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacher_data['teachergroupid']);
	$msgarr=array('titles'=>lang('plugin/keke_video_base', '034'),'course_subcate'=>lang('plugin/keke_video_base', '035'),'coveimg'=>lang('plugin/keke_video_base', '036'),'course_contents'=>lang('plugin/keke_video_base', '037'));
	foreach($msgarr as $mk=>$mv){
		if(!$_GET[$mk]){
			$msg=kekevideo_gbk2utf($mv);
			exit(json_encode(array('state'=>1,'msg'=>$msg)));
		}
	}
	if($_GET['course_types']==3 && (!$_GET['courseList'] || count($_GET['courseList'])<2)){
        exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '555')))));
    }
	$addarr=array(
		'id'=>$_GET['courseid'],
		'title' => kekevideo_utf2gbk($_GET['titles']),
		'dec' => kekevideo_utf2gbk($_GET['dec']),
		'content'=>kekevideo_utf2gbk($_GET['course_contents']),
		'cate'=>intval($_GET['course_cate']),
		'sub_cate'=>intval($_GET['course_subcate']),
		'img'=>$_GET['coveimg'],
		'price'=>$_GET['price'],
		'original_price'=>$_GET['original_price'],
		'credit'=>$_GET['credit'],
		'credit_type'=>$_GET['select_credit'],
		'uid'=> $course_uid,
		'type'=>$_GET['course_types'],
		'status'=>$_GET['status'],
		'learning_time'=>intval($_GET['learning_time']),
		'preview_time'=>intval($_GET['preview_time']),
		'username'=>$teacher_data['name'],
		'state'=>$course['state'],
		'chapter_count'=>$course['chapter_count'],
		'ke_count'=>$course['ke_count'],
		'password'=>$_GET['password'],
		'hide'=>$_GET['hide'],
        'courseids'=>($_GET['course_types']==3?dimplode($_GET['courseList']):'')
	);
	if($course){
		C::t('#keke_video_base#keke_video_course')->update($course['id'],$addarr);
	}else{
		$rannum=explode(',',$keke_video_base['viewrange']);
		$addarr['view']=rand($rannum[0],$rannum[1]?$rannum[1]:0);
		$addarr['time']=TIMESTAMP;
		$id=C::t('#keke_video_base#keke_video_course')->insert($addarr, true);
		if($teachergroup['permission_give_credit']){
			updatemembercount($_G['uid'], array('extcredits'.$teachergroup['permission_give_credit_type']=>$teachergroup['permission_give_credit']), true, '', 0, '',lang('plugin/keke_video_base', '518'),lang('plugin/keke_video_base', '518'));
		}
	}
	exit(json_encode(array('state'=>0,'cid'=>$id)));
}elseif($_GET['ac']=='addchapter'){
	C::t('#keke_video_base#keke_video_chapter')->insert(array(
			'id'=>intval($_GET['cpid']),
			'title' => kekevideo_utf2gbk($_GET['name']),
			'uid'=> $_G['uid'],
			'cid'=> intval($_GET['cid']),
			'displayorder'=> intval($_GET['order']),
			'price'=>floatval($_GET['chapterprice']),
	), true, true);
	_updatachaptercount($_GET['cid']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='getmedia'){
	$ppp=10;
	$param=($_GET['op'])?'op='.dhtmlspecialchars($_GET['op']):($_GET['catid']?'catid='.dhtmlspecialchars($_GET['catid']):'');
	$param=$param?'&'.$param:'';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$where='uid='.$_G['uid'].' AND state=1';
	if($_GET['mediatypes']=='audio'){
		$where.=" AND type=2";
		$param.="&mediatypes=audio";
	}else{
		$where.=" AND type=1";
		$param.="&mediatypes=video";
	}
	
	if($_GET['type']){
		$where.=" AND type=".intval($_GET['type']);
	}
	if($_GET['keyword']){
		$where.=" AND subject LIKE '%".addcslashes(kekevideo_utf2gbk($_GET['keyword']),'%_')."%'";
		$param.="&keyword=".urlencode(kekevideo_utf2gbk($_GET['keyword']));
	}
	$tmpurl='plugin.php?id=keke_video_base:ajax&ac=getmedia&formhash='.FORMHASH.$param;
	$count_all=C::t('#keke_video_base#keke_video_media')->count_all($where);
	$medioarr=C::t('#keke_video_base#keke_video_media')->fetch_all_media($startlimit,$ppp,$where,$order);
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	$multipage=str_replace('href','data-href',$multipage);
	foreach($medioarr as $media){
		$vids.=$media['vid'].',';
		$mediaarrs[$media['vid']]=$media;
	}
	$videoids=substr($vids,0,strlen($vids)-1);
	$result = getVideoInfos($videoids);
	include template('keke_video_base:block');
	exit($returns);
}elseif($_GET['ac']=='getmycourse'){
    $ppp=8;
    $param=($_GET['op'])?'op='.dhtmlspecialchars($_GET['op']):($_GET['catid']?'catid='.dhtmlspecialchars($_GET['catid']):'');
    $param=$param?'&'.$param:'';
    $page = max(1, intval($_GET['page']));
    $startlimit = ($page - 1) * $ppp;
    $where='uid='.$_G['uid'].' AND state=1 AND type!=3';
    if($_GET['type']){
        $where.=" AND type=".intval($_GET['type']);
    }
    if($_GET['keyword']){
        $where.=" AND subject LIKE '%".addcslashes(kekevideo_utf2gbk($_GET['keyword']),'%_')."%'";
        $param.="&keyword=".urlencode(kekevideo_utf2gbk($_GET['keyword']));
    }

    $courseId=explode('-',$_GET['courseIds']);

    $tmpurl='plugin.php?id=keke_video_base:ajax&ac=getmycourse&formhash='.FORMHASH.$param;
    $count_all=C::t('#keke_video_base#keke_video_course')->count_all($where);
    $coursearr=C::t('#keke_video_base#keke_video_course')->fetch_all_course($startlimit,$ppp,$where,$order);

    $multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
    $multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
    $multipage=str_replace('href','data-href',$multipage);
    include template('keke_video_base:block');
    exit($mycourse);
}elseif($_GET['ac']=='addke'){
	$type=intval($_GET['type']);
	$arr=array(
		'id' => $_GET['keid'],
		'title' => kekevideo_utf2gbk($_GET['videoname']),
		'uid'=> $_G['uid'],
		'type'=> $type,
		'cid'=> intval($_GET['cid']),
		'cpid'=> intval($_GET['cpid']),
		'displayorder'=> intval($_GET['displayorder']),
		'permissions'=>intval($_GET['permissions']),
		'price'=>floatval($_GET['keprice'])
	);
	if($type==1 || $type==3){
		$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
		$teachergroup = C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
	}
	if($type==1){
		$videotype=intval($_GET['videotype']);
		if($videotype==1){
			$videoarr=array(
				'videoid'=>$_GET['videoids'],
			);
		}else{
			$videoarr=array(
				'videodata'=>$_GET['videodata'],
			);
		}
		$videoarr['hour']=$_GET['hours'];
		$videoarr['min']=$_GET['min'];
		$videoarr['sec']=$_GET['sec'];
		$videoarr['videotype']=$videotype;
		$arr['concent']=serialize($videoarr);
	}elseif($type==2){
		if($_GET['permissions']==1 && $_GET['freeconcent']){
			$parr['freeconcent']=kekevideo_utf2gbk($_GET['freeconcent']);
		}
		if(!trim($_GET['concent']) && !$_GET['videoids']){
			exit(json_encode(array('msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '474')))));
		}
		$parr['concent']=kekevideo_utf2gbk($_GET['concent']);
		$parr['audio']=kekevideo_utf2gbk($_GET['videoids']);
		$parr['audio_info']=kekevideo_utf2gbk($_GET['audio_info']);
		$parr['audio_type']=intval($_GET['audio_type']);
		$arr['concent']=serialize($parr);
	}elseif($type==3){
		$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id(intval($_GET['keid']));
		$videodata=unserialize($kearr['concent']);
		$videoarr=array(
			'introduction'=>kekevideo_utf2gbk($_GET['introduction']),
			'rec'=>$videodata['rec']?$videodata['rec']:intval($_GET['rec']),
			'livemode'=>$videodata['livemode']?$videodata['livemode']:intval($_GET['livemode']),
			'liveurls'=>_video_editor_safe_replace($_GET['liveurls']),
			'dete'=>$videodata['dete']?$videodata['dete']:strtotime($_GET['date']),
			'lasttime'=>$videodata['lasttime']?$videodata['lasttime']:intval($_GET['lasttime'])
		);
		$arr['rec']=($videoarr['rec']==2)?1:0;
		$arr['livetime']=$videoarr['dete'];
		$arr['liveendtime']=($videoarr['dete']+$videoarr['lasttime']*60);
		$arr['concent']=serialize($videoarr);
		$arr['state']=0;
		if($teachergroup['permission_live']==2){
			$arr['state']=1;
		}elseif($teachergroup['permission_live']==1){
			exit(json_encode(array('msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '038')))));
		}
		if($teachergroup['permission_liverec']==1 && $_GET['rec']==2){
			exit(json_encode(array('msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '039')))));
		}
	}
	$arr['enc']=$teachergroup['permission_enc'];
	C::t('#keke_video_base#keke_video_ke')->insert($arr, false, true);
	_updatakecount($_GET['cid']);
	if(!$_GET['keid']){
		$all_set=_get_set();
		if($all_set['msg_stu_updata_id']){
			$allfavorites=C::t('#keke_video_base#keke_video_favorites')->fetch_all_by_cid(intval($_GET['cid']));
			foreach($allfavorites as $fkey=>$fval){
				$senduids[$fval['uid']]=$fval['uid'];
			}
			$validtimearrs=C::t('#keke_video_base#keke_video_validtime')->fetch_all_validtime(0,1000,'cid='.intval($_GET['cid']));
			foreach($validtimearrs as $fkeys=>$fvals){
				$senduids[$fvals['uid']]=$fvals['uid'];
			}
			if($senduids)_video_send_notice($senduids,'msg_stu_updata',array('cid'=>intval($_GET['cid'])));
		}
	}
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='updatapic'){
	$width=$_GET['width']?intval($_GET['width']):'';
	$hight=$_GET['hight']?intval($_GET['hight']):'';
	$pic['url']=_upload_img($_FILES['imgFile'],$width,$hight);
	$pic['error'] = 0;
	header('Content-type: text/html');
	exit(json_encode($pic));
}elseif($_GET['ac']=='updatafile'){
	$retfile=_upload_file($_FILES['file']);
	$file['url']=$retfile[0];
	$file['error'] = 0;
	$file['name'] = $retfile[1]['name'];
	$file['size'] = videoformatBytes($retfile[1]['size']);
	header('Content-type: text/html');
	exit(json_encode($file));
}elseif($_GET['ac']=='getsubcate'){
	$cateid=intval($_GET['cateid']);
	$catedata=_get_allcatedata();
	$data=array();
	if($catedata[$cateid]['subcate']){
		foreach($catedata[$cateid]['subcate'] as $key=>$val){
			$data[]=array($val,kekevideo_gbk2utf($catedata[$val]['name']));
		}
		$type=0;
	}else{
		$data[]=array($cateid,kekevideo_gbk2utf($catedata[$cateid]['name']));
		$type=1;
	}
	exit(json_encode(array('type'=>$type,'datas'=>$data)));
	
}elseif($_GET['ac']=='closorder'){	
	$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($_GET['orderid']);
	if($orderdata['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '393')))));
	}
	C::t('#keke_video_base#keke_video_order')->update($_GET['orderid'],array('state'=>4));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='saleoff'){
	$courseid=intval($_GET['courseid']);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($courseid);
	if($course['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	if($course['state']==3){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '040')))));
	}
    if($course['state']==5){
        exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '569')))));
    }
	if($course['type']==3){
        if(!$course['courseids']){
            exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '041')))));
        }
    }else{
        $kearr=C::t('#keke_video_base#keke_video_ke')->count_all('cid='.$courseid);
        if(!$kearr){
            exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '041')))));
        }
    }

	C::t('#keke_video_base#keke_video_course')->update($courseid,array('state'=>$_GET['saleoff']));
	exit(json_encode(array('state'=>0)));
	
}elseif($_GET['ac']=='delcourse'){
	$courseid=intval($_GET['courseid']);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($courseid);
	if($course['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	C::t('#keke_video_base#keke_video_course')->delete($courseid);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delchapter'){
	$cpid=intval($_GET['cpid']);
	$chapterarr=C::t('#keke_video_base#keke_video_chapter')->fetch_first_by_cpid($cpid);
	if($chapterarr['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	$kecount=C::t('#keke_video_base#keke_video_ke')->count_by_cpid($cpid);
	if($kecount){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '042')))));
	}
	C::t('#keke_video_base#keke_video_chapter')->delete($cpid);
	_updatachaptercount($chapterarr['cid']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delke'){
	$keid=intval($_GET['keid']);
	$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($keid);
	if($kearr['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	C::t('#keke_video_base#keke_video_ke')->delete($keid);
	_updatakecount($kearr['cid']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delanswers'){
	$answersid=intval($_GET['aid']);
	$ansarr=C::t('#keke_video_base#keke_video_answers')->fetchfirst_byaid($answersid);
	if($ansarr['teacher_uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	C::t('#keke_video_base#keke_video_answers')->delete($answersid);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='answersreply'){
	$answersid=intval($_GET['aid']);
	$ansarr=C::t('#keke_video_base#keke_video_answers')->fetchfirst_byaid($answersid);
	if($ansarr['teacher_uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	$arr=array(
		'reply'=>kekevideo_utf2gbk($_GET['text'])
	);
	C::t('#keke_video_base#keke_video_answers')->update($answersid,$arr);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($ansarr['cid']);
	$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($course['uid']);
	_video_send_notice(array($course['uid']),'msg_stu_ans',array('tname'=>$teacherdata['username'],'cname'=>$course['title'],'cid'=>$ansarr['cid']));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addcart'){
	if(!$_G['uid']){
		exit(json_encode(array('state'=>2,'msg'=>'Please login')));
	}
	$courseid=intval($_GET['courseid']);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($courseid);
	if($course['password'] && !$_G['cookie']['coursepassword_'.$courseid]){
		exit(json_encode(array('state'=>2,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '489')))));
	}
	$cart_arr=C::t('#keke_video_base#keke_video_cart')->fetchfirst_bycid($courseid,$_G['uid']);
	if(!$cart_arr){
		$arr=array(
			'cid'=>$courseid,
			'uid'=>$_G['uid'],
		);
		C::t('#keke_video_base#keke_video_cart')->insert($arr);
	}else{
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '490')))));
	}
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addview'){
	$cid=intval($_GET['cid']);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
	C::t('#keke_video_base#keke_video_course')->update($cid,array('view'=>$course['view']+1));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addkeview' || $_GET['ac']=='getkeview'){
	$keid=intval($_GET['keid']);
	$kedata=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($keid);
	if($_GET['ac']=='getkeview'){
		exit(json_encode(array('view'=>$kedata['view'])));
	}
	C::t('#keke_video_base#keke_video_ke')->update($keid,array('view'=>$kedata['view']+1));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addfollow'){
	$follow_data=C::t('#keke_video_base#keke_video_follow')->fetchfirst_byteacherid($_GET['teacherid'],$_G['uid']);
	if($follow_data){
		C::t('#keke_video_base#keke_video_follow')->delete($follow_data['id']);
	}else{
		C::t('#keke_video_base#keke_video_follow')->insert(array('uid'=>$_G['uid'],'tid'=>$_GET['teacherid'],'time'=>TIMESTAMP));
		$bindurl=_checkwechatbind();
	}
	exit(json_encode(array('state'=>0,'bindurl'=>$bindurl)));
}elseif($_GET['ac']=='kekeaddnoet'){
	$keid=intval($_GET['keid']);
	if(!$_GET['text']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '388')))));
	}
	if(!$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '389')))));
	}
	$notedata=C::t('#keke_video_base#keke_video_note')->fetchfirst_byuid($keid,$_G['uid']);
	C::t('#keke_video_base#keke_video_note')->insert(array('id'=>$notedata['id'],'uid'=>$_G['uid'],'keid'=>$keid,'text'=>kekevideo_utf2gbk($_GET['text'])),true,true);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='kekeaddanswer'){
	$keid=intval($_GET['keid']);
	$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($keid);
	if(!$kearr){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '387')))));
	}
	$validtime=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bycid($kearr['cid'],$_G['uid']);
	if(!$validtime){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '386')))));
	}
	if(!$_GET['text']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '043')))));
	}
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($kearr['cid']);
	C::t('#keke_video_base#keke_video_answers')->insert(array('id'=>$notedata['id'],'uid'=>$_G['uid'],'username'=>$_G['username'],'teacher_uid'=>$course['uid'],'keid'=>$keid,'cid'=>$kearr['cid'],'text'=>kekevideo_utf2gbk($_GET['text']),'time'=>TIMESTAMP),true);
	_video_send_notice(array($course['uid']),'msg_teacher_ans',array('username'=>$_G['username'],'cname'=>$course['title'],'kname'=>$kearr['title']));
	exit(json_encode(array('state'=>0,'time'=>dgmdate(TIMESTAMP, 'Y-m-d H:i:s'),'text'=>kekevideo_gbk2utf(_video_editor_safe_replace($_GET['text'])))));
}elseif($_GET['ac']=='kekeaddevaluate'){
	$cid=intval($_GET['cid']);
	$notedata=C::t('#keke_video_base#keke_video_evaluate')->fetchfirst_byuid($cid,$_G['uid']);
	$validtime=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bycid($cid,$_G['uid']);
	if(!$validtime){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '044')))));
	}
	if($notedata){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '045')))));
	}
	C::t('#keke_video_base#keke_video_evaluate')->insert(array('uid'=>$_G['uid'],'username'=>$_G['username'],'star'=>intval($_GET['star']),'cid'=>$cid,'text'=>kekevideo_utf2gbk($_GET['text']),'time'=>TIMESTAMP),true);
	exit(json_encode(array('state'=>0,'star'=>intval($_GET['star']),'time'=>dgmdate(TIMESTAMP, 'Y-m-d H:i:s'),'text'=>kekevideo_gbk2utf(dhtmlspecialchars($_GET['text'])))));
}elseif($_GET['ac']=='waitprice'){
	$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($_GET['orderid']);
	if($orderdata['teacher_uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1)));
	}
	if($orderdata['state']!=0){
		exit(json_encode(array('state'=>2)));
	}
    $_GET['orderprice']=floatval($_GET['orderprice']);
    $updata=array(
        'price'=>$_GET['orderprice'],
        'revision'=>TIMESTAMP
    );
	if($orderdata['vipprice']>0){
        $newVipPrice=$orderdata['vipprice']/$orderdata['price']*$_GET['orderprice'];
        $updata['vipprice']=floatval($newVipPrice);
    }
	C::t('#keke_video_base#keke_video_order')->update($_GET['orderid'],$updata);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='add_card'){
	$card=$_GET['card'];
	$arr=array(
		'alipay_name'=>kekevideo_utf2gbk($card['alipayname']),
		'alipay'=>$card['alipay'],
		'wechatpay_name'=>kekevideo_utf2gbk($card['wechatpayname']),
		'wechatpay'=>$card['wechatpay'],
		'bank_name'=>kekevideo_utf2gbk($card['bankname']),
		'bank'=>$card['bank'],
		'bank_type'=>kekevideo_utf2gbk($card['banktype']),
	);
	C::t('#keke_video_base#keke_video_teacher')->update($_G['uid'],$arr);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='cashout'){
	$acc_type=intval($_GET['acc_type']);
    $keke_video_base['tixian_type']=unserialize($keke_video_base['tixian_type']);
    $acc_type=in_array($acc_type,$keke_video_base['tixian_type'])?$acc_type:0;
    if (!$acc_type){
        exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '544')))));
    }
	$money=floatval($_GET['money']);
	if(!discuz_process::islocked('cashout_checklocked', 60)) {
		$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
		if($acc_type==1){
			if(!$teacherdata['alipay']){
				discuz_process::unlock('cashout_checklocked');
				exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '251')))));
			}
			$card=lang('plugin/keke_video_base', '049').' / '.$teacherdata['alipay'].' / '.$teacherdata['alipay_name'];
		}elseif($acc_type==2){
			if(!$teacherdata['wechatpay']){
				discuz_process::unlock('cashout_checklocked');
				exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '252')))));
			}
			$card=lang('plugin/keke_video_base', '050').' / '.$teacherdata['wechatpay'].' / '.$teacherdata['wechatpay_name'];
        }elseif($acc_type==4){
            if(!$keke_video_base['magsecret']){
                discuz_process::unlock('cashout_checklocked');
                exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '543')))));
            }
            $card=lang('plugin/keke_video_base', '542');
		}else{
			if(!$teacherdata['bank']){
				discuz_process::unlock('cashout_checklocked');
				exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '253')))));
			}
			$card=lang('plugin/keke_video_base', '051').' / '.$teacherdata['bank_type'].' - '.$teacherdata['bank'].' / '.$teacherdata['bank_name'];
		}
		
		if($keke_video_base['tixian_min']>$money){
			discuz_process::unlock('cashout_checklocked');
			exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '046').$keke_video_base['tixian_min'].lang('plugin/keke_video_base', '047')))));
		}
		if($money>$teacherdata['money']){
			discuz_process::unlock('cashout_checklocked');
			exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '048')))));
		}
		$cachout_arr=array(
			'uid'=>$_G['uid'],
			'money'=>$money,
			'card_type'=>$acc_type,
			'card'=>$card,
			'time'=>TIMESTAMP
		);
		$cashoutid = C::t('#keke_video_base#keke_video_cashout')->insert($cachout_arr,true);
		cach_log(-$money,lang('plugin/keke_video_base', '052'),$_G['uid']);
		if($acc_type==4){
            $Magapppay=MagappAccountTransfer($_G['uid'],$money,lang('plugin/keke_video_base', '541'));
            if($Magapppay[0]){
                $retArr=array('state' => 1,'htime'=>TIMESTAMP);
            }else{
                $retArr=array('msg' => $Magapppay[1]);
            }
            C::t('#keke_video_base#keke_video_cashout')->update($cashoutid, $retArr);
        }
		discuz_process::unlock('cashout_checklocked');
	}else{
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '033')))));
	}
	$all_set=_get_set();
	_video_send_notice(explode(',',$all_set['msg_adminuids']),'msg_admin_cashout',array('tname'=>$_G['username'],'money'=>$money));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='checkorder'){
	$orderdata= C::t('#keke_video_base#keke_video_order')->fetch($_GET['orderid']);
	exit(json_encode(array('state' =>$orderdata['state'])));
}elseif($_GET['ac']=='delcart'){
	$cartarr=C::t('#keke_video_base#keke_video_cart')->fetchfirst_byid($_GET['cartid']);
	if($cartarr['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	C::t('#keke_video_base#keke_video_cart')->delete($_GET['cartid']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delfollow'){
	$followarr=C::t('#keke_video_base#keke_video_follow')->fetchfirst_byid($_GET['followid']);
	if($followarr['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	C::t('#keke_video_base#keke_video_follow')->delete($_GET['followid']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='delfavorites'){
	$delfavoritesarr=C::t('#keke_video_base#keke_video_favorites')->fetchfirst_byid($_GET['favoritesid']);
	if($delfavoritesarr['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	C::t('#keke_video_base#keke_video_favorites')->delete($_GET['favoritesid']);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='addfavorites'){
	if(!$_G['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '029')))));
	}
	$favoritesarr=C::t('#keke_video_base#keke_video_favorites')->fetchfirst_bycid($_GET['courseid'],$_G['uid']);
	if($favoritesarr){
		C::t('#keke_video_base#keke_video_favorites')->delete($favoritesarr['id']);
		exit(json_encode(array('state'=>2,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '053')))));
	}
	C::t('#keke_video_base#keke_video_favorites')->insert(array('cid'=>$_GET['courseid'],'uid'=>$_G['uid'],'time'=>TIMESTAMP));
	$bindurl=_checkwechatbind();
	exit(json_encode(array('state'=>0,'bindurl'=>$bindurl)));
	
}elseif($_GET['ac']=='checkbindwechats'){
	if(checkmobile()){
		dheader('location: '._checkwechatbind());
	}
	$bindurl=_checkwechatbind();
	exit(json_encode(array('state'=>0,'bindurl'=>$bindurl)));
}elseif($_GET['ac']=='bindwechat'){
	$_GET['ref']=_video_safe_replace($_GET['ref']);
	$_GET['hash']=dhtmlspecialchars($_GET['hash']);
	$all_set=_get_set();
	if($_GET['op']=='getopenid'){
		$authcodes=C::t('#keke_video_base#keke_video_openid')->fetch_first_bycode($_GET['hash']);
		$redirect_uris = urlencode($_G['siteurl'].'plugin.php?id=keke_video_base:ajax&ac=bindwechat&op=getopenid&ref='.urlencode(_video_urlsafe_b64decode($_GET['ref'])).'&hash='.$_GET['hash']);
		$access_tokenarr=_video_getaccesstokens($redirect_uris);
		if($authcodes['uid'] && $access_tokenarr['openid']){
			C::t('#keke_video_base#keke_video_openid')->insert(array('uid'=>intval($authcodes['uid']),'code'=>$_GET['hash'],'openid'=>$access_tokenarr['openid']),true,true);
			if(K_INCWECHAT){
				dheader('location: plugin.php?id=keke_video_base:ajax&ac=bindwechat&hash='.$_GET['hash'].'&op=follow&ref='.urlencode($_GET['ref']).'&formhash='.FORMHASH);
			}
		}
	}elseif($_GET['op']=='checkopenid'){
		$check=C::t('#keke_video_base#keke_video_openid')->fetch_first_byid($_G['uid']);
		$state=$check['openid']?1:2;
		$bindurl='';
		if($state==1){
			$subscribe = _video_getwechatuserinfo($check['openid']);
			if(!($subscribe['subscribe']==1)){
				$bindurl='plugin.php?id=keke_video_base:ajax&ac=bindwechat&uid='.$_G['uid'].'&op=follow&ref='.urlencode($_GET['ref']).'&formhash='.FORMHASH;
			}else{
				$bindurl=$_GET['ref'];
			}
		}
		exit(json_encode(array('state'=>$state,'bindurl'=>$bindurl)));
	}elseif($_GET['op']=='checkfollow'){
		if($all_set['msg_tablename'] && $all_set['msg_uidfield'] && $all_set['msg_openidfield']){
			$openid_arr=C::t('#keke_video_base#keke_video_openid')->fetch_first_byid($_G['uid']);
		}else{
			$openid_arr=C::t('#keke_video_base#keke_video_openid')->fetch_first_bycode($_GET['hash']);
		}
		$subscribe = _video_getwechatuserinfo($openid_arr['openid']);
		exit(json_encode(array('state'=>$subscribe['subscribe'],'bindurl'=>$_GET['ref'])));
	}elseif($_GET['op']=='follow'){
		if($all_set['msg_tablename'] && $all_set['msg_uidfield'] && $all_set['msg_openidfield']){
			$openid_arr=C::t('#keke_video_base#keke_video_openid')->fetch_first_byid($_G['uid']);
		}else{
			$openid_arr=C::t('#keke_video_base#keke_video_openid')->fetch_first_bycode($_GET['hash']);
		}
		$subscribe = _video_getwechatuserinfo($openid_arr['openid']);
		$qccode=$all_set['msg_qrcode'];
		if ($subscribe['subscribe']==1)header("refresh:2;url=".$_GET['ref']);
		include template('keke_video_base:video_win');
	}else{
		$openid_arr=C::t('#keke_video_base#keke_video_openid')->fetch_first_byid($_G['uid']);
		if($openid_arr['openid']){
			dheader('location: plugin.php?id=keke_video_base:ajax&ac=bindwechat&uid='.$_G['uid'].'&op=follow&ref='.urlencode($_GET['ref']).'&formhash='.FORMHASH);
		}
		if($all_set['msg_tablename'] && $all_set['msg_uidfield'] && $all_set['msg_openidfield']){
			$qccode=_getqrcodeurl($all_set['msg_bindurl']);
			include template('keke_video_base:video_win');
		}else{
			$authcodes=random(30);
			C::t('#keke_video_base#keke_video_openid')->insert(array('uid'=>$_G['uid'],'openid'=>$openid_arr['openid'],'code'=>$authcodes),true,true);
			if(K_INCWECHAT){
				dheader('location: plugin.php?id=keke_video_base:ajax&ac=bindwechat&op=getopenid&ref='._video_urlsafe_b64encode($_GET['ref']).'&hash='.$authcodes);
			}else{
				$qccode=_getqrcodeurl($_G['siteurl'].'plugin.php?id=keke_video_base:ajax&ac=bindwechat&op=getopenid&ref='._video_urlsafe_b64encode($_GET['ref']).'&hash='.$authcodes);
				include template('keke_video_base:video_win');
			}
		}
	}
	exit();
}elseif($_GET['ac']=='showpaswordbox'){
	$cid=intval($_GET['cid']);
	include template('keke_video_base:video_win');
	exit();
}elseif($_GET['ac']=='checkcoursepassword'){	
	$cid=intval($_GET['cid']);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
	if($course['password']){
		if($course['password']!=$_GET['password']){
			exit(json_encode(array('state'=>2,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '488')))));
		}
		dsetcookie('coursepassword_'.$cid, 1, '604800');
	}
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='editmeia'){
	$mediadata=C::t('#keke_video_base#keke_video_media')->fetchfirst_byid($_GET['vid']);
	if($mediadata['uid']!=$_G['uid']){
		exit(json_encode(array('state'=>2,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '026')))));
	}
	if(!$_GET['subject']){
		exit(json_encode(array('state'=>2,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '054')))));
	}
	C::t('#keke_video_base#keke_video_media')->update($_GET['vid'],array('subject'=>kekevideo_utf2gbk($_GET['subject'])));
	if(!(strpos($_GET['media_coveimg'], 'http') !== false)){
		$_GET['media_coveimg']=$_G['siteurl'].$_GET['media_coveimg'];
	}
	updateVideoInfo($_GET['vid'],array('title'=>$_GET['subject'],'cover'=>$_GET['media_coveimg']));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='setlineoff'){
	$cookieopenline=intval($_GET['cookieopenline']);
	dsetcookie('cookieopenline', $cookieopenline, '604800');
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='checkmagorder'){
	$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($_GET['orderid']);
	$url = 'http://'.$keke_video_base['magurl'].'/core/pay/pay/orderStatusQuery?unionOrderNum='.$_GET['unionordernum'].'&secret='.$keke_video_base['magsecret'];
	$data = dfsockopen($url);
	if(!$data){
		$data = file_get_contents($url);
	}
	$return= json_decode($data,true);
	if($orderdata && $orderdata['state']!=1 && $return['paycode'] == 1){
		uporderstate($_GET['orderid'],5);
		exit(json_encode(array('state'=>0)));
	}
	exit(json_encode(array('state'=>1)));
}elseif($_GET['ac']=='wxshare'){
	$url=($_GET['url']);
	require_once "source/plugin/keke_video_base/jssdk.php";
	$jssdk = new jssdk($url);
	$signPackage = $jssdk->getSignPackage();
	exit(json_encode($signPackage));
}elseif($_GET['ac']=='tologin'){	
	if(!$_G['uid']){
		_tologin();
	}
	exit();
}elseif($_GET['ac']=='maglogin'){	
	if(!$_G['uid']){
		$url='http://'.$keke_video_base['magurl'].'/mag/cloud/cloud/getUserInfo?token='.$_GET['tokenss'].'&secret='.$keke_video_base['magsecret'];
		$data = dfsockopen($url);
		if(!$data) {
			$data = file_get_contents($url);
		}
		$data=json_decode($data,true);
		if($data['data']['user_id']){
			require_once libfile('function/member');
			$member = getuserbyuid($data['data']['user_id'],1);
			setloginstatus($member, 2592000);
			exit(json_encode(array('state'=>1)));
		}
	}
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='setappdowncookie'){
	$keke_video_base['appdowninfo']=explode('##',dhtmlspecialchars($keke_video_base['appdowninfo']));
	dsetcookie('appdowncookie', 1, intval($keke_video_base['appdowninfo'][5]*60));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='setfollowcodecookie'){
	dsetcookie('setfollowcodecookie', 1, 86400);
	exit(json_encode(array('state'=>0)));	
}elseif($_GET['ac']=='updateqianfansn'){
	C::t('#keke_video_base#keke_video_order')->update($_GET['orderid'],array('sn'=>$_GET['sn']));
	exit(json_encode(array('state'=>1)));
}elseif($_GET['ac']=='checkqianfanpay'){
	require_once DISCUZ_ROOT . './source/plugin/keke_video_base/class/qianfan.class.php';
	$client = new QF_HTTP_CLIENT($keke_video_base['qfhostname'],$keke_video_base['qftoken']);
	$pay_data = $client->get('payments/'.$_GET['sn']);
	if($orderdata && $orderdata['state']!=1 && $pay_data['data']['pay'] == 1){
		uporderstate($_GET['orderid'],6);
		exit(json_encode(array('state'=>1)));
	}
	exit(json_encode(array('state'=>2)));
}elseif($_GET['ac']=='getbuyuser'){
	$courseid=intval($_GET['courseid']);
	$orderdata=C::t('#keke_video_base#keke_video_order')->fetch_all_order(0,1000,'cid='.$courseid.' AND state=1 group by uid');
	foreach($orderdata as $val){
		$reture[]=array(
			'uid'=>$val['uid'],
			'username'=>kekevideo_gbk2utf($val['username']),
		);
	}
	$ret=video_shuffle_assoca($reture);
	foreach($ret as $k=>$v){
		$retures[]=$v;
	}
	exit(json_encode($retures));
}elseif($_GET['ac']=='liveend'){
	
	$kid=intval($_GET['kid']);
	$kedata=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($kid);
	if($_G['uid']!=$kedata['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '393')))));
	}
	$keconcent=unserialize($kedata['concent']);
	$endtime= TIMESTAMP;
	if($endtime<$keconcent['dete']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '496')))));
	}
	$keconcent['lasttime']=($endtime-$keconcent['dete'])/60;
	$arr=array(
		'liveendtime'=>$endtime,
		'concent'=>serialize($keconcent),
	);
	C::t('#keke_video_base#keke_video_ke')->update($kid,$arr);
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='getorderprice'){
    $allcatedata=_get_allcatedata();
	$cid=dhtmlspecialchars($_GET['cid']);
	$orderid=dhtmlspecialchars($_GET['orderid']);
	$_GET['chapterid']=intval($_GET['chapterid']);
	$_GET['keid']=intval($_GET['keid']);
	$appoint=unserialize($keke_video_base['appoint']);
	$deductionnum=intval($_GET['deductionnum']);
	$cids=explode(',',$cid);
	$total_price=0;
    $member_credit =array();
	if($orderid){
		$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($orderid);
		if($orderdata['credit']){
			$creditarr=unserialize($orderdata['credit']);
			foreach($creditarr as $type=>$creditval){
				$member_credit[$type]=$creditval;
			  }
		}
		$tt_price=$orderdata['price'];
	}elseif($cid){
		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
		foreach($courses as $pk=>$pv){
			if($pv['credit']){
                $member_credit[$pv['credit_type']]+=$pv['credit'];
			}
            $cateGroupArr=unserialize($allcatedata[$pv['sub_cate']]['vip_groupids']);
            if($cateGroupArr && $appoint) {
                $pv['vip']=1;
                $appoint=array_keys(array_flip($appoint)+array_flip($cateGroupArr));
            }
            $isVipUser=0;
            if($keke_video_base['groupnosw']){
                foreach (getUserAllGroup() as $groupId) {
                    if(in_array($groupId,$appoint)){
                        $isVipUser=1;
                        break;
                    }
                }
            }else{
                $isVipUser=in_array($_G['groupid'],$appoint);
            }
			if($pv['vip'] && $pv['vipprice']>0 && $isVipUser){
				$pv['price']=$pv['vipprice'];
			}
			$tt_price+=$pv['price'];
		}
	}elseif($_GET['chapterid']){
		$chapterid=intval($_GET['chapterid']);
		$chapter=C::t('#keke_video_base#keke_video_chapter')->fetch_first_by_cpid($chapterid);
		$tt_price=$chapter['price'];
	}elseif($_GET['keid']){
		$keid=intval($_GET['keid']);
		$ke=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($keid);
		$tt_price=$ke['price'];
	}
	if($deductionnum){
		$max=ceil((1/$keke_video_base['proportion'])*$tt_price);
		$deductionnum=$deductionnum>$max?$max:$deductionnum;
		$member_credit[$keke_video_base['integraltype']]+=$deductionnum;
		$tt_price-=$keke_video_base['proportion']*$deductionnum;
	}
	if($_GET['source']==3){
		$member_credit[$keke_video_base['creditpaytype']]+=ceil((1/$keke_video_base['creditpayproportion'])*$tt_price);
		$tt_price=0;
	}
	$member_credit=array_reverse($member_credit,true);
	$tt_price=number_format($tt_price,'2');
	include template('keke_video_base:block');
	exit($orderprice);
}elseif($_GET['ac']=='studylog'){
	if($_G['uid']){
		$_GET['keid']=intval($_GET['keid']);
		$_GET['cid']=intval($_GET['cid']);
		$newip=getClientIps();
		$check=C::t('#keke_video_base#keke_video_studylog')->count_by_uidkeid($_G['uid'],$_GET['keid']);
		$arr=array(
			'mediatime'=>$_GET['getDuration'],
			'learningtime'=>$_GET['CurrentTime'],
			'ip'=>$newip,
			'type'=>checkmobile()?'mobile':'pc',
			'time'=>TIMESTAMP
		);
		if($check['id']){
			if($check['historyip']){
				$iparr=explode(',',$check['historyip']);
				if(!in_array($newip,$iparr)){
					array_unshift($iparr,$newip);
					$historyip=array_slice($iparr,0,10);
					$arr['historyip']=implode(',',$historyip);
				}
			}else{
				$arr['historyip']=$newip;
			}
			C::t('#keke_video_base#keke_video_studylog')->update($check['id'],$arr);
		}else{
			$arr['uid']=$_G['uid'];
			$arr['cid']=$_GET['cid'];
			$arr['keid']=$_GET['keid'];
			C::t('#keke_video_base#keke_video_studylog')->insert($arr);
		}
		exit(json_encode(array('state'=>0)));
	}
}elseif($_GET['ac']=='updataset'){
	$set=dhtmlspecialchars($_GET['set']);
	$res=C::t('#keke_video_base#keke_video_set')->updataset($set);
	exit(json_encode(array('state'=>$res)));
}elseif($_GET['ac']=='editketitle'){
	$keid=intval($_GET['keid']);
	$ke=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($keid);
	if($_G['uid']!=$ke['uid']){
		exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '393')))));
	}
	C::t('#keke_video_base#keke_video_ke')->update($keid,array('title'=>kekevideo_utf2gbk($_GET['title'])));
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='editkeorder'){
	$cpid=intval($_GET['cpid']);
	$keids=is_array($_GET['keids'])?$_GET['keids']:array();
	$kes=C::t('#keke_video_base#keke_video_ke')->fetch_all_by_keids($keids);
	$displayorderarr=array_flip($keids);
	foreach($kes as $keval){
		if($_G['uid']!=$keval['uid']){
			exit(json_encode(array('state'=>1,'msg'=>kekevideo_gbk2utf(lang('plugin/keke_video_base', '393')))));
		}
		C::t('#keke_video_base#keke_video_ke')->update($keval['id'],array('cpid'=>$cpid,'displayorder'=>$displayorderarr[$keval['id']]));
	}
	exit(json_encode(array('state'=>0)));
}elseif($_GET['ac']=='kms'){
	if($keke_video_base['originurl']){
		header('Access-Control-Allow-Origin: '.$keke_video_base['originurl']);
	}
	$uskey= getuskey();
	$ua = strtolower($_SERVER['HTTP_USER_AGENT']);
	$tokendata=C::t('#keke_video_base#keke_video_token')->fetch_first_byid($uskey);
	$usformhash=md5(getClientIps());
	if($tokendata['mediatype']==2 && checkmobile()){
		C::t('#keke_video_base#keke_video_token')->deltimeout();
	}else{
		C::t('#keke_video_base#keke_video_token')->delete($uskey);
	}
	if($tokendata && $tokendata['time']>TIMESTAMP/* && $usformhash==$tokendata['val']*/){
		exit(dDecrypt());
	}else{
		exit(md5($_G['formhash']));
	}
}