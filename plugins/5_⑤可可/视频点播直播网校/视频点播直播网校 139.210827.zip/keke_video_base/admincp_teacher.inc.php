<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
	$_GET['op']=$_GET['op']?$_GET['op']:'teacher';
	_showadminsubmenu(array(
		array(lang('plugin/keke_video_base', '088'), "teacher"),
		array(lang('plugin/keke_video_base', '089'), "permission"),
	),'admincp_teacher');
	
if ($_GET['op'] == 'teacher') {	
	if(!$_G['uid']) {
		cpmsg('Please Login');
	}
	if (submitcheck("forumset")) {
		if(is_array($_GET['uids'])) {
			if($_GET['optype'] == 'delete') {
				C::t('#keke_video_base#keke_video_teacher')->delete($_GET['uids']);
			} elseif($_GET['optype'] == 'pass') {
				C::t('#keke_video_base#keke_video_teacher')->update($_GET['uids'], array('state' => 1,'op_time' =>TIMESTAMP));
			} elseif($_GET['optype'] == 'refuse') {
				C::t('#keke_video_base#keke_video_teacher')->update($_GET['uids'], array('state' => 2,'op_time' =>TIMESTAMP));
			}elseif($_GET['optype'] == 'sd') {
				C::t('#keke_video_base#keke_video_teacher')->update($_GET['uids'], array('state' => 4,'op_time' =>TIMESTAMP));
			}
		}else{
			cpmsg(lang('plugin/keke_video_base', '090'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher', 'error');
		}
		if(!$_GET['optype']){
			cpmsg(lang('plugin/keke_video_base', '091'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher', 'error');
		}
		cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher', 'succeed');
	}
	$allgrodata=C::t('#keke_video_base#keke_video_teachergroup')->fetch_all_teacher();
	if($_GET['ac']=='edit'){
		$tcid=intval($_GET['tcid']);
		$formhash=substr(md5(substr($_G['timestamp'], 0, -7).$_G['username'].$_G['uid'].$_G['authkey']), 8, 8);
		if (submitcheck("editsubmit")) {
				$img=$_FILES['img'] ? _upload_img($_FILES['img'],250,380): $_GET['img'];
				$wechatqrcode=$_FILES['wechatqrcode'] ? _upload_img($_FILES['wechatqrcode'],250,380): $_GET['wechatqrcode'];
				$arr=array(
					'name' => $_GET['name'],
					'username' => $_GET['username'],
					'info' => $_GET['teacher_content'],
					'img' => $img,
					'tel' =>  $_GET['tel'],
					'wechat'=>$_GET['wechat'],
					'profile'=>$_GET['profile'],
					'rank'=>$_GET['rank'],
					'teachergroupid'=>$_GET['teachergroupid'],
					'wechatqrcode'=>$wechatqrcode
				);			
			if($tcid){
				C::t('#keke_video_base#keke_video_teacher')->update($tcid,$arr);
			}else{
				$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_GET['useruid']);
				if($teacherdata){
					cpmsg(lang('plugin/keke_video_base', '382'), '', 'error');
				}
				$arr['uid']=intval($_GET['useruid']);
				$arr['state']=1;
				$arr['op_time']=TIMESTAMP;
				C::t('#keke_video_base#keke_video_teacher')->insert($arr);
			}
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&op=teacher&ac=edit&tcid='.$tcid.'&o='.$_GET['o'], 'succeed');
		}
		if(!$allgrodata){
			cpmsg(lang('plugin/keke_video_base', '384'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&op=permission', 'error');
		}
		$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($tcid);
		foreach($allgrodata as $gk=>$gv){
			$teachergro.='<option value="'.$gv['id'].'" '.($teacherdata['teachergroupid']==$gv['id']?'selected':'').'>'.$gv['title'].'</option>';
		}
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_teacher&ac=edit&op=teacher", 'enctype');
		showtableheader(lang('plugin/keke_video_base', '092').' '.$teacherdata['name'].' '.lang('plugin/keke_video_base', '093'));
		if(!$tcid){
			showsetting(lang('plugin/keke_video_base', '381'),'useruid',$teacherdata['useruid'],'text');
		}
		showsetting(lang('plugin/keke_video_base', '094'),'name',$teacherdata['name'],'text');
		showsetting(lang('plugin/keke_video_base', '297'),'username',$teacherdata['username'],'text');
		showsetting(lang('plugin/keke_video_base', '095'), '', 'teachergroupid', "<select name='teachergroupid'>".$teachergro."</select> ");
		showsetting(lang('plugin/keke_video_base', '096'),'rank',$teacherdata['rank'],'text');
		showsetting(lang('plugin/keke_video_base', '097'),'tel',$teacherdata['tel'],'text');
		showsetting(lang('plugin/keke_video_base', '098'),'wechat',$teacherdata['wechat'],'text');
		showsetting(lang('plugin/keke_video_base', '099'),'profile',$teacherdata['profile'],'textarea');
		showsetting(lang('plugin/keke_video_base', '100'),'img',$teacherdata['img'],'filetext');
		if($keke_video_base['teacherqrcode']){
			showsetting(lang('plugin/keke_video_base', '520'),'wechatqrcode',$teacherdata['wechatqrcode'],'filetext');
		}
		$edit= "
			<textarea name=\"teacher_content\" style=\"width:700px;height:400px;visibility:hidden;\">".$teacherdata['info']."</textarea>
			<script charset=\"utf-8\" src=\"./source/plugin/keke_video_base/static/kindeditor/kindeditor-min.js\"></script>
			<script charset=\"utf-8\" src=\"./source/plugin/keke_video_base/static/kindeditor/lang/zh_CN.js\"></script>
			<script>
			  var itemss = [
				  'source', '|', 'undo', 'redo', '|', 'preview', 'template', 'cut', 'copy', 'paste',
				  'plainpaste', 'wordpaste', '|', 'justifyleft', 'justifycenter', 'justifyright',
				  'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
				  'superscript', 'clearhtml', 'quickformat', 'selectall', '|', 'fullscreen', '/',
				  'formatblock', 'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold',
				  'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'image', 'multiimage', 'table', 'hr', 'emoticons', 'baidumap', 'pagebreak',
				  'anchor', 'link', 'unlink'
			  ];
			  KindEditor.ready(function(K) {
						var editor1 = K.create('textarea[name=\"teacher_content\"]', {
							uploadJson : 'plugin.php?id=keke_video_base:ajax&ac=updatapic&formhash=".$formhash."',
							allowFileManager : false,
							items : itemss
						});
					});
			</script>";
		showsetting(lang('plugin/keke_video_base', '101'), '','',$edit);
		echo '<input name="tcid" type="hidden" value="'.$tcid.'" />';
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
        exit();
	}elseif($_GET['ac']=='log'){
        $tcid=intval($_GET['tcid']);
        $teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($tcid);
        $ppp=15;
        $page = max(1, intval($_GET['page']));
        $startlimit = ($page - 1) * $ppp;
        $where='uid='.$tcid;
        $tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=log&tcid='.$tcid;
        showtableheader(lang('plugin/keke_video_base', '092').' '.$teacherdata['name'].' '.lang('plugin/keke_video_base', '550'));
        showsetting(lang('plugin/keke_video_base', '550'), '', 'state', '<b style="color:#c30;">&yen;'.$teacherdata['money'].'</b>');
        showtableheader(lang('plugin/keke_video_base', '092').' '.$teacherdata['name'].' '.lang('plugin/keke_video_base', '545'));
        showsubtitle(array('id',lang('plugin/keke_video_base', '546'), lang('plugin/keke_video_base', '548'), lang('plugin/keke_video_base', '547')));
        $count_all=C::t('#keke_video_base#keke_video_cash')->count_all($where);
        $dataarr=C::t('#keke_video_base#keke_video_cash')->fetch_alls($startlimit,$ppp,$where,$order);
        foreach($dataarr as $key=>$val){
            $times=dgmdate($val['time'], 'Y-m-d H:i');
            $table = array();
            $table[0] = $val['id'];
            $table[1] = $val['text'];
            $table[2] = $val['money'].' '.lang('plugin/keke_video_base', '549');
            $table[3] = $times;
            showtablerow('',array(), $table);
        }
        $multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
        $multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
        if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
        showtablefooter(); /*dism��taobao��com*/
        exit();
    }
	showtableheader(lang('plugin/keke_video_base', '102'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_teacher&op=teacher', 'testhd');
	showtablerow('', array('width="70"', 'width="120"', 'width="70"','width="180"'),
		array(
			'<b>'.lang('plugin/keke_video_base', '103').'</b>',
			"<select name='teacherstate'><option value='0' ".(!$_GET['teacherstate']?'selected':'').">".lang('plugin/keke_video_base', '104')."</option><option value='9' ".($_GET['teacherstate']==9?'selected':'').">".lang('plugin/keke_video_base', '105')."</option><option value='1' ".($_GET['teacherstate']==1?'selected':'').">".lang('plugin/keke_video_base', '106')."</option><option value='2' ".($_GET['teacherstate']==2?'selected':'').">".lang('plugin/keke_video_base', '107')."</option><option value='4' ".($_GET['teacherstate']==4?'selected':'').">".lang('plugin/keke_video_base', '108')."</option></select>",
			'<b>'.lang('plugin/keke_video_base', '109').'</b>',
			'<input name="teachername" type="text" />',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '110').'">'
		)
    );
	showformfooter(); /*Dism_taobao-com*/
	showtablefooter(); /*dism��taobao��com*/
	$where='1';$param='';
	if($_GET['teacherstate']){
		if($_GET['teacherstate']==9){
			$_GET['teacherstate']=0;
		}
		$where.=" AND state=".intval($_GET['teacherstate']);
		$param.='&state='.intval($_GET['teacherstate']);
	}
	if($_GET['teachername']){
		$where.=" AND name LIKE '%".addcslashes($_GET['teachername'],'%_')."%'";
		$param.='&name='.addcslashes($_GET['teachername']);
	}
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_teacher&op=teacher");	
	showtableheader(lang('plugin/keke_video_base', '111'));
    showsubtitle(array(lang('plugin/keke_video_base', '067'), lang('plugin/keke_video_base', '112'), lang('plugin/keke_video_base', '113'),lang('plugin/keke_video_base', '114'),lang('plugin/keke_video_base', '115'),lang('plugin/keke_video_base', '116'),lang('plugin/keke_video_base', '117'),lang('plugin/keke_video_base', '118')));
    $teacherUid=array();
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($allcount = C::t('#keke_video_base#keke_video_teacher')->count_all($where)){
		$teacher_data=C::t('#keke_video_base#keke_video_teacher')->fetch_all_teacher($startlimit,$ppp,$where,$order);
        foreach ($teacher_data as $item) {
            $teacherUid[$item['uid']]=$item['uid'];
        }
        $moneySum=C::t('#keke_video_base#keke_video_cash')->sum_all_by_uid($teacherUid);
		foreach($teacher_data as $key=>$val){
			$op='<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=edit&tcid='.$val['uid'].'&o=1">'.lang('plugin/keke_video_base', '120').'</a><br/><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_order&teacherid='.$val['uid'].'" class="mgt10">'.lang('plugin/keke_video_base', '279').'</a>';
			$state='<span class="wait">'.lang('plugin/keke_video_base', '119').'</span><br><div class="coursedec">'.lang('plugin/keke_video_base', '121').' '.dgmdate($val['time'], 'Y/m/d H:i').'</div>';
			if($val['state']==1){
				$state='<span class="pass">'.lang('plugin/keke_video_base', '123').'</span><br><div class="coursedec">'.lang('plugin/keke_video_base', '122').' '.dgmdate($val['op_time'], 'Y/m/d H:i').'</div>';
			}elseif($val['state']==2){
				$state='<span class="refuse">'.lang('plugin/keke_video_base', '124').'</span><br><div class="coursedec">'.lang('plugin/keke_video_base', '122').' '.dgmdate($val['op_time'], 'Y/m/d H:i').'</div>';
			}elseif($val['state']==4){
				$state='<span class="refuse">'.lang('plugin/keke_video_base', '125').'</span><br><div class="coursedec">'.lang('plugin/keke_video_base', '122').' '.dgmdate($val['op_time'], 'Y/m/d H:i').'</div>';
			}
			$qx='<div class="coursedec">'.($allgrodata[$val['teachergroupid']]['permission_media']==1?'<img src="source/plugin/keke_video_base/template/images/ico017.png" width="11" height="11" />'.lang('plugin/keke_video_base', '126'):'<img src="source/plugin/keke_video_base/template/images/ico016.png" width="11" height="11" />'.lang('plugin/keke_video_base', '127')).'<br/>'.($allgrodata[$val['teachergroupid']]['permission_live']==1?'<img src="source/plugin/keke_video_base/template/images/ico011.png" width="11" height="11" />'.lang('plugin/keke_video_base', '128'):($allgrodata[$val['teachergroupid']]['permission_live']==2?'<img src="source/plugin/keke_video_base/template/images/ico017.png" width="11" height="11" />'.lang('plugin/keke_video_base', '129'):'<img src="source/plugin/keke_video_base/template/images/ico016.png" width="11" height="11" />'.lang('plugin/keke_video_base', '130'))).'<br/>'.($allgrodata[$val['teachergroupid']]['permission_liverec']==1?'<img src="source/plugin/keke_video_base/template/images/ico011.png" width="11" height="11" />'.lang('plugin/keke_video_base', '131'):'<img src="source/plugin/keke_video_base/template/images/ico016.png" width="11" height="11" />'.lang('plugin/keke_video_base', '132')).'</div>';
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="uids[]" value="'.$val['uid'].'" />';
			$table[1] = '<img src="'.($val['img']?:$_G['setting']['ucenterurl'].'/avatar.php?uid='.$val['uid']).'" width="85" height="85" class="teacherimg"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=edit&tcid='.$val['uid'].'&o=1"><b>'.$val['name'].'</b></a> <span class="sline">|</span> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=edit&tcid='.$val['uid'].'&o=1">'.$val['username'].'</a><span class="sline">|</span>  <span class="uidnum">uid:'.$val['uid'].'</span> <span class="sline">|</span> <span class="uidnum">'.lang('plugin/keke_video_base', '540').':</span> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=log&tcid='.$val['uid'].'"> <span class="refuse"> &yen; '.$val['money'].'</a></span> <span class="sline">|</span> <span class="uidnum">'.lang('plugin/keke_video_base', '578').':</span> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=log&tcid='.$val['uid'].'"> <span class="refuse"> &yen; '.($moneySum[$val['uid']]['tmoney']>0?$moneySum[$val['uid']]['tmoney']:'0.00').'</a></span> <br><div class="coursedec width">'.cutstr($val['profile'],'130').' '.((strlen($val['profile'])>130)?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=edit&tcid='.$val['uid'].'&o=1">'.lang('plugin/keke_video_base', '019'):'').'</a></div>';
			$table[2] = '<div class="tels">'.lang('plugin/keke_video_base', '133').$val['tel'].'<br>'.lang('plugin/keke_video_base', '134').$val['wechat'].'</div>';
			$table[3] ='<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=edit&op=permission&gid='.$val['teachergroupid'].'">[ '.$allgrodata[$val['teachergroupid']]['title'].' ]</a>';
			$table[4] = $qx;
			$table[5] = $allgrodata[$val['teachergroupid']]['permission_take'].'%';
			$table[6] = $state;
			$table[7] = $op;
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	echo '<style>.mgt10{margin:5px 0 0 0;display: inline-block; }.uidnum{color:#999;  }.coursedec img{vertical-align:middle; margin-right:7px;}.width{max-width:450px;margin-right:7px;}.tels{color:#999; margin:7px 10px 3px 0; line-height:20px;}.teacherimg{ float:left; margin-right:10px}.sline{color:#e3e3e3; margin:10px 5px; line-height:20px;}.pass{color:#3C3}.refuse{color:#c30}.wait{color:#F90}.coursedec{float: left;color:#999; margin:7px 10px 3px 0; line-height:20px;}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}</style>';
	showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'uids\')"><label for="chkallIuPN">'.lang('plugin/keke_video_base', '067').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_video_base', '135').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="pass" value="pass" class="radio" /><label for="pass" class="vmiddle">'.lang('plugin/keke_video_base', '106').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="refuse" value="refuse" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_video_base', '124').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="refuse" value="sd" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_video_base', '136').'</label>',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=edit&o=1" class="addtr">'.lang('plugin/keke_video_base', '383').'</a>');
    showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/
} elseif ($_GET['op'] == 'permission') {
		if (submitcheck("editsubmit")) {
			$grodata=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid(intval($_GET['gid']));
			$parameter=$_GET['permission'];
			if($parameter['defaults']){
				C::t('#keke_video_base#keke_video_teachergroup')->update_all('defaults=0');
			}
			$arr=array(
				'title' => $parameter['title'],
				'permission_media' => $parameter['media'],
				'permission_live' => $parameter['live'],
				'permission_liverec' => $parameter['liverec'],
				'permission_take'=>$parameter['take'],
                'permission_viptake'=>$parameter['viptake'],
				'permission_mediasize'=>$parameter['mediasize'],
				'permission_tmp'=>$parameter['permission_tmp'],
				'permission_enc'=>$parameter['permission_enc'],
				'permission_give_credit'=>$parameter['give_credit'],
				'permission_give_credit_type'=>$parameter['give_credit_type'],
				'permission_callmedia'=>$parameter['callmedia'],
				'defaults' => $parameter['defaults'],
				'time' => TIMESTAMP,
			);
			if($grodata['id']){
				C::t('#keke_video_base#keke_video_teachergroup')->update($grodata['id'],$arr);
			}else{
				C::t('#keke_video_base#keke_video_teachergroup')->insert($arr);
			}
			cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&op=permission', 'succeed');
		}elseif(submitcheck("forumset")){
			C::t('#keke_video_base#keke_video_teachergroup')->delete($_GET['ids']);
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&op=permission', 'succeed');
		}else{
			if($_GET['ac']=='edit'){
				if($_GET['gid']){
					$grodata=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid(intval($_GET['gid']));
				}
				
				foreach($_G['setting']['extcredits'] as $credit_type=>$credit){
					$credit_opt.="<option value=".$credit_type." ".($grodata['permission_give_credit_type']==$credit_type?'selected':'').">".$credit['title']."</option>";
				}
				
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_teacher&op=permission");
				showtableheader(lang('plugin/keke_video_base', '138'));
				showsetting(lang('plugin/keke_video_base', '139'),'permission[title]',$grodata['title'],'text');
				showsetting(lang('plugin/keke_video_base', '140'), '', 'permission[media]', "<select name='permission[media]'><option value='1' ".($grodata['permission_media']==1?'selected':'').">".lang('plugin/keke_video_base', '126')."</option><option value='2' ".($grodata['permission_media']==2?'selected':'').">".lang('plugin/keke_video_base', '127')."</option></select> ");
				showsetting(lang('plugin/keke_video_base', '141'), '', 'permission[live]', "<select name='permission[live]'><option value='1' ".($grodata['permission_live']==1?'selected':'').">".lang('plugin/keke_video_base', '128')."</option><option value='2' ".($grodata['permission_live']==2?'selected':'').">".lang('plugin/keke_video_base', '129')."</option><option value='3' ".($grodata['permission_live']==3?'selected':'').">".lang('plugin/keke_video_base', '130')."</option></select> ");		
				showsetting(lang('plugin/keke_video_base', '142'), '', 'permission[liverec]', "<select name='permission[liverec]'><option value='1' ".($grodata['permission_liverec']==1?'selected':'').">".lang('plugin/keke_video_base', '143')."</option><option value='2' ".($grodata['permission_liverec']==2?'selected':'').">".lang('plugin/keke_video_base', '144')."</option></select> ");
				showsetting(lang('plugin/keke_video_base', '145'),'permission[permission_tmp]',$grodata['permission_tmp'],'text');
				showsetting(lang('plugin/keke_video_base', '146'), '', 'permission[permission_enc]', "<select name='permission[permission_enc]'><option value='1' ".($grodata['permission_enc']==1?'selected':'').">".lang('plugin/keke_video_base', '147')."</option><option value='2' ".($grodata['permission_enc']==2?'selected':'').">".lang('plugin/keke_video_base', '148')."</option><option value='3' ".($grodata['permission_enc']==3?'selected':'').">".lang('plugin/keke_video_base', '149')."</option></select> ");
				showsetting(lang('plugin/keke_video_base', '116'),'permission[take]',$grodata['permission_take'],'text','','','% &nbsp;&nbsp; '.lang('plugin/keke_video_base', '150'));

                showsetting(lang('plugin/keke_video_base', '574'),'permission[viptake]',$grodata['permission_viptake'],'text','','','% &nbsp;&nbsp; '.lang('plugin/keke_video_base', '575'));

				showsetting(lang('plugin/keke_video_base', '151'),'permission[mediasize]',$grodata['permission_mediasize'],'text','','','M &nbsp;&nbsp;'.lang('plugin/keke_video_base', '152'));
				
				showsetting(lang('plugin/keke_video_base', '533'), 'permission[callmedia]', $grodata['permission_callmedia'], 'radio');
				showsetting(lang('plugin/keke_video_base', '153'), 'permission[defaults]', $grodata['defaults'], 'radio');
				showsubmit('editsubmit', 'submit', '');
				
				showtableheader(lang('plugin/keke_video_base', '516'));
				showsetting(lang('plugin/keke_video_base', '514'),'permission[give_credit]',$grodata['permission_give_credit'],'text','','',lang('plugin/keke_video_base', '517'));
				showsetting(lang('plugin/keke_video_base', '515'), '', 'permission[give_credit_type]', "<select name='permission[give_credit_type]'>".$credit_opt."</select> ");
				
				echo '<input type="hidden" name="gid" value="'.intval($_GET['gid']).'">';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); /*dism��taobao��com*/
				showformfooter(); /*Dism_taobao-com*/
			}else{
				$ppp=30;
				$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&op=permission';
				$page = max(1, intval($_GET['page']));
				$startlimit = ($page - 1) * $ppp;
				showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_teacher&op=teacher&op=permission");	
				showtableheader(lang('plugin/keke_video_base', '088'));
				showsubtitle(array(lang('plugin/keke_video_base', '067'), lang('plugin/keke_video_base', '139'),lang('plugin/keke_video_base', '115'),lang('plugin/keke_video_base', '116'),lang('plugin/keke_video_base', '154'),lang('plugin/keke_video_base', '155'),lang('plugin/keke_video_base', '156'),lang('plugin/keke_video_base', '157'),lang('plugin/keke_video_base', '118')));
				if($allcount = C::t('#keke_video_base#keke_video_teachergroup')->count_all($where)){
					$teachergroup_data=C::t('#keke_video_base#keke_video_teachergroup')->fetch_all_teacher($startlimit,$ppp,$where,'ORDER BY id ASC');
					foreach($teachergroup_data as $key=>$val){
						$op='<div class="coursedec"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=edit&op=permission&gid='.$val['id'].'">'.lang('plugin/keke_video_base', '158').'</a></div>';
						
						$qx='<div class="coursedec">'.($val['permission_media']==1?'<img src="source/plugin/keke_video_base/template/images/ico017.png" width="11" height="11" />'.lang('plugin/keke_video_base', '126'):'<img src="source/plugin/keke_video_base/template/images/ico016.png" width="11" height="11" />'.lang('plugin/keke_video_base', '127')).'<br/>'.($val['permission_live']==1?'<img src="source/plugin/keke_video_base/template/images/ico011.png" width="11" height="11" />'.lang('plugin/keke_video_base', '128'):($val['permission_live']==2?'<img src="source/plugin/keke_video_base/template/images/ico017.png" width="11" height="11" />'.lang('plugin/keke_video_base', '129'):'<img src="source/plugin/keke_video_base/template/images/ico016.png" width="11" height="11" />'.lang('plugin/keke_video_base', '130'))).'<br/>'.($val['permission_liverec']==1?'<img src="source/plugin/keke_video_base/template/images/ico011.png" width="11" height="11" />'.lang('plugin/keke_video_base', '131'):'<img src="source/plugin/keke_video_base/template/images/ico016.png" width="11" height="11" />'.lang('plugin/keke_video_base', '132')).'</div>';
						
						$table = array();
						$table[0] = '<input type="checkbox" class="checkbox" name="ids[]" value="'.$val['id'].'" />';
						$table[1] = '<a href="#"><b>'.$val['title'].'</b></a>';
						$table[2] = $qx;
						$table[3] = $val['permission_take']? ($val['permission_viptake']?'<span class="uidnum">'.lang('plugin/keke_video_base', '576').'</span> ':''). $val['permission_take'].'%'.($val['permission_viptake']?' <div class="rowbox"></div><span class="uidnum">'.lang('plugin/keke_video_base', '577').' </span> '.$val['permission_viptake'].'%</div>':''):'<span class="uidnum">'.lang('plugin/keke_video_base', '159').'</span>';
						$table[4] = $val['permission_mediasize']?$val['permission_mediasize'].'M':'<span class="uidnum">'.lang('plugin/keke_video_base', '160').'</span>';
						$table[5] = ($val['permission_enc']==2)?lang('plugin/keke_video_base', '148'):(($val['permission_enc']==3)?lang('plugin/keke_video_base', '149'):lang('plugin/keke_video_base', '147'));
						$table[6] = $val['permission_tmp'];
						$table[7] = $val['defaults']?lang('plugin/keke_video_base', '157'):'';
						$table[8] = $op;
						showtablerow('',array(), $table);
					}
				}
				$multipage='';
				$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
				if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
				echo '<style>.uidnum{color:#999;  }.coursedec img{vertical-align:middle; margin-right:7px;}.width{width:450px}.tels{color:#999; margin:7px 10px 3px 0; line-height:20px;}.pass{color:#3C3}.refuse{color:#c30}.wait{color:#F90}.coursedec{color:#999; margin:7px 10px 3px 0; line-height:20px;}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}.rowbox{margin:5px 0px 0px 0;}</style>';
				showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_teacher&ac=edit&op=permission" class="addtr">'.lang('plugin/keke_video_base', '260').'</a>');
				showtablefooter(); /*dism��taobao��com*/
				showformfooter(); /*Dism_taobao-com*/
			}
		}
}