<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
			if($_GET['optype'] == 'delete') {
				C::t('#keke_video_base#keke_video_media')->delete($_GET['delete']);
				
			} elseif($_GET['optype'] == 'pass') {
				C::t('#keke_video_base#keke_video_media')->update($_GET['delete'], array('state' => 1));
				createAudit($_GET['delete'],1);
				_admintranscoding($_GET['delete']);
			} elseif($_GET['optype'] == 'refuse') {
				C::t('#keke_video_base#keke_video_media')->update($_GET['delete'], array('state' => 2));
				createAudit($_GET['delete'],2);
			}
			
			$allmediadata=C::t('#keke_video_base#keke_video_media')->fetch_all($_GET['delete']);
			foreach($allmediadata as $val){
				$uids[$val['uid']]=$val['uid'];
			}
			_video_send_notice($uids,'msg_teacher_media',array('state'=>($start?lang('plugin/keke_video_base', '422'):lang('plugin/keke_video_base', '423'))));
		}else{
			cpmsg(lang('plugin/keke_video_base', '176'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_media', 'error');
		}
		
		if(!$_GET['optype']){
			cpmsg(lang('plugin/keke_video_base', '057'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_media', 'error');
		}
		cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_media&page='.$_GET['page'], 'succeed');
	}
	if($_GET['ac']=='edit'){
		if (submitcheck("editsubmit")) {
			C::t('#keke_video_base#keke_video_media')->update($_GET['vid'],array('subject'=>$_GET['subject'],'uid'=>$_GET['uid']));
			$img=$_FILES['media_coveimg'] ? _upload_img($_FILES['media_coveimg'],250,250): $_GET['media_coveimg'];
			updateVideoInfo($_GET['vid'],array('title'=>$_GET['subject'],'cover'=>$img));
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_media&page='.intval($_GET['page']), 'succeed');
		}
		
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_media&ac=edit");
		$vid=dhtmlspecialchars($_GET['vid']);
		$videoinfo=_getplayinfo($vid);
		$mediadata=C::t('#keke_video_base#keke_video_media')->fetchfirst_byid($_GET['vid']);
		$mediadatas['title']=kekevideo_utf2gbk($videoinfo['VideoBase']['Title']);
		$mediadatas['cover']=$videoinfo['VideoBase']['CoverURL'];
		
		showtableheader(lang('plugin/keke_video_base', '177'));
		showsetting(lang('plugin/keke_video_base', '178'),'subject',$mediadatas['title'],'text');
		showsetting(lang('plugin/keke_video_base', '523'),'media_coveimg',$mediadatas['cover'],'filetext');
		showsetting(lang('plugin/keke_video_base', '401').'UID','uid',$mediadata['uid'],'text');
		
		echo '<input name="vid" type="hidden" value="'.$vid.'" /><input name="page" type="hidden" value="'.intval($_GET['page']).'" />';
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
		
	}

	showtableheader(lang('plugin/keke_video_base', '179'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_media', 'testhd');
	showtablerow('', array('width="70"', 'width="120"', 'width="70"','width="180"','width="80"','width="180"'),
		array(
			'<b>'.lang('plugin/keke_video_base', '180').'</b>',
			'<select name="state"><option value="0">'.lang('plugin/keke_video_base', '011').'</option><option value="9">'.lang('plugin/keke_video_base', '105').'</option><option value="1">'.lang('plugin/keke_video_base', '175').'</option><option value="2">'.lang('plugin/keke_video_base', '183').'</option></select>',
			'<b>'.lang('plugin/keke_video_base', '181').'</b>',
			'<input name="medianame" type="text" />',
			'<b>'.lang('plugin/keke_video_base', '182').'</b>',
			'<input name="teacherid" type="text" />',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '065').'">'
		)
    );
	
	
	showformfooter(); /*Dism_taobao-com*/
	showtablefooter(); /*dism��taobao��com*/
	$where='1';$param='';
	if($_GET['state']){
		if($_GET['state']==9)$_GET['state']=0;
		$where.=" AND state=".intval($_GET['state']);
		$param.='&state='.intval($_GET['state']);
	}
	
	if($_GET['teacherid']){
		$where.=" AND uid=".intval($_GET['teacherid']);
		$param.='&teacherid='.intval($_GET['teacherid']);
	}
	
	
	if($_GET['medianame']){
		$where.=" AND subject LIKE '%".addcslashes($_GET['medianame'],'%_')."%'";
		$param.='&medianame='.addcslashes($_GET['medianame']);
	}
	
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_media");	
	showtableheader(lang('plugin/keke_video_base', '184'));
    showsubtitle(array(lang('plugin/keke_video_base', '067'), lang('plugin/keke_video_base', '185'),'',lang('plugin/keke_video_base', '401'),lang('plugin/keke_video_base', '187'),lang('plugin/keke_video_base', '188'),lang('plugin/keke_video_base', '189'),lang('plugin/keke_video_base', '072'),lang('plugin/keke_video_base', '118')));
	
	$ppp=20;
	$param=($_GET['op'])?'op='.dhtmlspecialchars($_GET['op']):($_GET['catid']?'catid='.dhtmlspecialchars($_GET['catid']):'');
	$param=$param?'&'.$param:'';
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_media'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$count_all=C::t('#keke_video_base#keke_video_media')->count_all($where);
	if($count_all){
		$video_data=C::t('#keke_video_base#keke_video_media')->fetch_all_media($startlimit,$ppp,$where,$order);
		foreach($video_data as $media){
			$vids.=$media['vid'].',';
			$mediaarrs[$media['vid']]=$media;
		}
		$videoids=substr($vids,0,strlen($vids)-1);
		$Video_result = getVideoInfos($videoids);
		foreach($Video_result['VideoList'] as $key=>$val){
			$op='<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_media&ac=edit&vid='.$val['VideoId'].'&page='.intval($_GET['page']).'">'.lang('plugin/keke_video_base', '170').'</a>';
			$state=$val['Status']=='Normal'?'<img src="source/plugin/keke_video_base/template/images/ico016.png" width="11" height="11" />'.lang('plugin/keke_video_base', '175'):($val['Status']=='Blocked'?'<img src="source/plugin/keke_video_base/template/images/ico011.png" width="11" height="11" />'.lang('plugin/keke_video_base', '183'):($val['Status']=='Transcoding'?'<img src="source/plugin/keke_video_base/template/images/ico017.png" width="11" height="11" />'.lang('plugin/keke_video_base', '190'):'<img src="source/plugin/keke_video_base/template/images/ico017.png" width="11" height="11" />'.lang('plugin/keke_video_base', '105')));
			$cate=$allcatedata[$val['sub_cate']]['upid']?$allcatedata[$allcatedata[$val['sub_cate']]['upid']]['name'].' > '.$allcatedata[$val['sub_cate']]['name']:$allcatedata[$val['subcate']]['name'];
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['VideoId'].'" />';
			$table[1] = '<a href="#" class="video-image"><div class="video-image-background" style="background-image: url('.$val['CoverURL'].');"></div></a>';
			$table[2] = '<a href="#">'.$val['Title'].'</a><br><div class="coursedec">'.$val['VideoId'].'</div>';
			$table[3] = '<a href="plugin.php?id=keke_video_base&ac=teacher&tcid='.$mediaarrs[$val['VideoId']]['uid'].'" target="_blank"><b>'._getusname($mediaarrs[$val['VideoId']]['uid']).'</b></a> <span class="sline">|</span> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_media&ac=edit&vid='.$val['VideoId'].'&page='.intval($_GET['page']).'" class="locking">'.lang('plugin/keke_video_base', '402').'</a>';
			$table[4] = $val['Size'] .' / '. $val['Duration'];
			$table[5] = $val['ModificationTime'];
			$table[6] = ($mediaarrs[$val['VideoId']]['type']==1?lang('plugin/keke_video_base', '191'):(($mediaarrs[$val['VideoId']]['type']==3)?lang('plugin/keke_video_base', '192'):lang('plugin/keke_video_base', '193')));
			$table[7] = '<div class="states">'.$state.'</div>';
			$table[8] = $op;
			showtablerow('',array('','width="130"','width="500"'), $table);
		}
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	}
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	echo '<input type="hidden" name="page" value="'.intval($_GET['page']).'"><style>.states img{vertical-align:middle; margin-right:7px;}.video-image {width: 120px;height: 68px;background: #d5d5d5 url(https://img.alicdn.com/tfs/TB1ZHkyh9zqK1RjSZPcXXbTepXa-136-32.png) no-repeat 50%;display: inline-block;float: left;position: relative;cursor: pointer;background-size: 60px;}.video-image .video-image-background {background-position: 50%;background-repeat: no-repeat;background-size: contain;width: 100%;height: 100%;}.coursedec{ color:#999; margin:7px 10px 10px 0; line-height:20px;}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}.locking{ color:#c30}.sline{color:#e3e3e3;margin:0 5px;}</style>';
	showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')"><label for="chkallIuPN">'.lang('plugin/keke_video_base', '067').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_video_base', '135').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="pass" value="pass" class="radio" /><label for="pass" class="vmiddle">'.lang('plugin/keke_video_base', '106').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="refuse" value="refuse" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_video_base', '183').'</label>','');
    showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/