<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
require_once DISCUZ_ROOT.'./source/plugin/keke_video_base/function.php';
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
$position='teacheradmin';
$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
if($teacherdata['state']!=1){
	showmessage(lang('plugin/keke_video_base', '018'),'plugin.php?id=keke_video_base');
}
$ali_id=$keke_video_base['alyid'];
$ac=$_GET['ac'];
$slider=_get_cache('slider');
$teacher_data=C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
$teacher_data['stucount']=C::t('#keke_video_base#keke_video_validtime')->count_all('teacher_uid='.$_G['uid']);
$teacher_data['coursecount']=C::t('#keke_video_base#keke_video_course')->count_all('uid='.$_G['uid']);

if($ac=='media'){
	$ppp=10;
	$_GET['page']=intval($_GET['page']);
	$param=($_GET['op'])?'op='.dhtmlspecialchars($_GET['op']):($_GET['catid']?'catid='.dhtmlspecialchars($_GET['catid']):'');
	$param=$param?'&'.$param:'';
	$tmpurl='plugin.php?id=keke_video_base:t&ac=media'.$param;
	$page = max(1, $_GET['page']);
	$startlimit = ($page - 1) * $ppp;
	$where='uid='.$_G['uid'];
	if($_GET['type']){
		$where.=" AND type='".intval($_GET['type'])."'";
	}
	if($_GET['videoid']){
		$where.=" AND vid='".addcslashes($_GET['videoid'])."'";
	}
	if($_GET['keyword']){
		$_GET['keyword']=dhtmlspecialchars($_GET['keyword']);
		$where.=" AND subject LIKE '%".addcslashes($_GET['keyword'],'%_')."%'";
	}
	if($_GET['state']){
		if($_GET['state']==9){
			$_GET['state']=0;
		}
		$where.=" AND state=".intval($_GET['state']);
		$_GET['state']=9;
	}
	$count_all=C::t('#keke_video_base#keke_video_media')->count_all($where);
	$medioarr=C::t('#keke_video_base#keke_video_media')->fetch_all_media($startlimit,$ppp,$where,$order);
	$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
	$teacherpower=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	foreach($medioarr as $media){
		$vids.=$media['vid'].',';
		$mediaarrs[$media['vid']]=$media;
	}
	$videoids=substr($vids,0,strlen($vids)-1);
	$result = getVideoInfos($videoids);
	$checkingvideo=$transcodingvideo=array();
	foreach($result['VideoList'] as $videoinfoss){
		if($videoinfoss['Status']=='Checking'){
			$checkingvideo[]=$videoinfoss['VideoId'];
		}elseif($videoinfoss['Status']=='Transcoding'){
			$transcodingvideo[]=$videoinfoss['VideoId'];
		}
	}
	$transcodingcount=count($transcodingvideo);
	if($checkingvideo && $teacherpower['permission_media']==2){
		createAudit($checkingvideo,1);
	}
}elseif($ac=='index'){
	$order_all=C::t('#keke_video_base#keke_video_order')->fetch_all_by_days($_G['uid']);
	$day = 7 ;
	for ($i = $day - 1; 0 <= $i; $i--) {
		$result[] = date('Ymd', strtotime('-' . $i . ' day'));
		$nums[] = $price[] = 0;
	}
	array_walk($order_all, function ($value, $key) use ($result, &$nums, &$price) {
		$index = array_search($value['days'],$result);
		$nums[$index] = $value['count'];
		$price[$index] = $value['price'];
	});
	$data = array(
		'day' => $result,
		'nums' => $nums,
		'price' => $price
	);
	$beginToday=mktime(0,0,0,date('m'),date('d'),date('Y'));
	$endToday=mktime(0,0,0,date('m'),date('d')+1,date('Y'))-1;
	$datacount=count($data['nums']);
	$index_count=array(
		$data['nums'][$datacount-1],
		$data['nums'][$datacount-2],
		$data['price'][$datacount-1],
		$data['price'][$datacount-2],
		C::t('#keke_video_base#keke_video_follow')->count_all('time>'.$beginToday.' AND time<'.$endToday.' AND tid='.$_G['uid']),
		C::t('#keke_video_base#keke_video_follow')->count_all('tid='.$_G['uid']),
		C::t('#keke_video_base#keke_video_answers')->count_all('teacher_uid='.$_G['uid']),
		C::t('#keke_video_base#keke_video_answers')->count_all('teacher_uid='.$_G['uid'].' AND reply=\'\''),
		$teacher_data['coursecount'],
		C::t('#keke_video_base#keke_video_ke')->count_all('uid='.$_G['uid']),
		C::t('#keke_video_base#keke_video_order')->count_all_money($_G['uid']),
		$teacher_data['money']
	);
}elseif($ac=='upmedia'){
	$isAndroid=(strpos($_SERVER['HTTP_USER_AGENT'], 'Android'))?1:0;
	$teacherpower=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
}elseif($ac=='course'){
	$ppp=15;
	$param=($_GET['op'])?'op='.dhtmlspecialchars($_GET['op']):($_GET['catid']?'catid='.dhtmlspecialchars($_GET['catid']):'');
	$param=$param?'&'.$param:'';
	$tmpurl='plugin.php?id=keke_video_base:t&ac=course'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$where='uid='.$_G['uid'];
	if($_GET['op']=='package'){
        $where.=" AND type=3";
    }else{
        $where.=" AND type!=3";
    }
	if($_GET['keyword']){
		$where.=" AND subject LIKE '%".addcslashes($_GET['keyword'],'%_')."%'";
	}
	if($_GET['state']){
		$where.=" AND state=".intval($_GET['state']);
	}
	$count_all=C::t('#keke_video_base#keke_video_course')->count_all($where);
	$coursearr=C::t('#keke_video_base#keke_video_course')->fetch_all_course($startlimit,$ppp,$where,$order);
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
}elseif($ac=='addcourse' || $ac=='addpackage'){
	$courseid=intval($_GET['courseid']);
	if($courseid){
		$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($courseid);
	}
	$catedata=_get_allcatedata();
	if($ac=='addpackage' && $course['courseids']){
        $courseIds=explode(',',str_replace('\'','',$course['courseids']));
        $packageCourseData=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($courseIds);
        foreach ($courseIds as $packageItem) {
            $packageCourse[]=$packageCourseData[$packageItem];
        }
    }
}elseif($ac=='chapter'){
	$courseid=intval($_GET['courseid']);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($courseid);
	$chapterarr=C::t('#keke_video_base#keke_video_chapter')->fetch_all_by_displayorder($_G['uid'],$courseid);
	$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_all_by_cid($_G['uid'],$courseid);
    $emptyChapter=0;
	foreach($kearr as $key=>$val){
		$val['concent']=unserialize($val['concent']);
		$val['concent']['detes']=dgmdate($val['concent']['dete'], 'Y-m-d H:i');
		$liveendtime=$val['concent']['dete']+$val['concent']['lasttime']*60;
		$val['concent']['livestate']=($liveendtime<TIMESTAMP)?1:0;
		$kearrs[$val['cpid']][]=$val;
		if($val['cpid']==0)$emptyChapter=1;
	}
	$keke_video['get_push_time']=intval($keke_video_base['get_push_time']);

    $chapterarr[]['id']=0;
	foreach($chapterarr as $chapterval){
		$chapterids.='#sortable'.$chapterval['id'].',';
	}
	$chapterids=substr($chapterids,0,strlen($chapterids)-1);
}elseif($ac=='file'){
	$courseid=intval($_GET['courseid']);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($courseid);
	$filelist=C::t('#keke_video_base#keke_video_file')->fetch_all_by_displayorder($_G['uid'],$courseid);
	foreach($filelist as $filekey=>$fileval){
		$filelist[$filekey]['time']=dgmdate($fileval['time'], 'Y-m-d H:i');
	}
}elseif($ac=='order'){
	$where=" teacher_uid=".intval($_G['uid'])." AND id NOT LIKE '%ALL%'";;
	$orderarr=_getorder(20,$where);
	$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($orderarr[2]);
	$multipage = $orderarr[1];
}elseif($ac=='user'){
	$where=' teacher_uid='.intval($_G['uid']);
	$ppp=15;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($_GET['op']=='answers'){
		$tmpurl='plugin.php?id=keke_video_base:t&ac=user&op=answers';
		$count_all=C::t('#keke_video_base#keke_video_answers')->count_all($where);
		$dataarr=C::t('#keke_video_base#keke_video_answers')->fetch_alls($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$coursearr[2][$val['uid']]=$val['uid'];
			$coursearr[3][$val['cid']]=$val['cid'];
			$dataarr[$key]['times']=dgmdate($val['time'], 'Y-m-d H:i');
			$dataarr[$key]['text']=cutstr(strip_tags(htmlspecialchars_decode($val['text']), '<img>'), 200).(strlen($val['text'])>200?' '.lang('plugin/keke_video_base', '019'):'');
			$dataarr[$key]['reply']=cutstr(strip_tags(htmlspecialchars_decode($val['reply']), '<img>'), 200).(strlen($val['reply'])>200?' '.lang('plugin/keke_video_base', '019'):'');
			$kids[$val['keid']]=$val['keid'];
		}
		$kidsarr=C::t('#keke_video_base#keke_video_ke')->fetch_all($kids);
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	}elseif($_GET['op']=='studylog'){	
		require_once libfile('function/misc');

		$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_uid($_G['uid']);
		foreach($courses as $key=>$val){
			$cids[]=$val['id'];
		}
		$where='1';
        if($_GET['stuid']){
            $where.=" AND uid=".intval($_GET['stuid']);
            $parameter.='&stuid='.intval($_GET['stuid']);
        }
        if($_GET['courseid'] && in_array($_GET['courseid'],$cids)){
            $where.=" AND cid=".intval($_GET['courseid']);
            $parameter.='&courseid='.intval($_GET['courseid']);
        }else{
            $where.=' AND cid in ('.dimplode($cids).')';
        }
        if($_GET['keid']){
            $where.=" AND keid=".intval($_GET['keid']);
            $parameter.='&keid='.intval($_GET['keid']);
        }
        if($_GET['historyip']){
            $where.=" AND historyip LIKE '%".addcslashes($_GET['historyip'],'%_')."%'";
            $parameter.='&keid='.dhtmlspecialchars($_GET['historyip']);
        }
        $tmpurl='plugin.php?id=keke_video_base:t&ac=user&op=studylog'.$parameter;
		$count_all=C::t('#keke_video_base#keke_video_studylog')->count_all($where);
		$dataarr=C::t('#keke_video_base#keke_video_studylog')->fetch_all_limit($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$coursearr[2][$val['uid']]=$val['uid'];
			$coursearr[3][$val['cid']]=$val['cid'];
			$dataarr[$key]['times']=dgmdate($val['time'], 'Y-m-d H:i');
			$dataarr[$key]['percentage']=$val['learningtime']/$val['mediatime']*100;
			$dataarr[$key]['mediatime']=second2duration($val['mediatime']);
			$dataarr[$key]['learningtime']=second2duration($val['learningtime']);
			$dataarr[$key]['ip']=$val['ip'].' '.convertip($val['ip']);
			
			$historyiparr=explode(',',$val['historyip']);
			foreach($historyiparr as $v){
				if($v)$dataarr[$key]['historyips'].=$v.' '.convertip($v).'<br/>';
			}
			$kids[$val['keid']]=$val['keid'];
		}
		$kidsarr=C::t('#keke_video_base#keke_video_ke')->fetch_all($kids);
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
		
	}elseif($_GET['op']=='fans'){
		$where=' tid='.intval($_G['uid']);
		$tmpurl='plugin.php?id=keke_video_base:t&ac=user&op=fans';
		$count_all=C::t('#keke_video_base#keke_video_follow')->count_all($where);
		$dataarr=C::t('#keke_video_base#keke_video_follow')->fetch_all_favorites($startlimit,$ppp,$where,$order);
		foreach($dataarr as $key=>$val){
			$coursearr[2][$val['uid']]=$val['uid'];
			$dataarr[$key]['times']=dgmdate($val['time'], 'Y-m-d H:i');
		}
	}else{
		$coursearr=_getvalidtime(20,$where);
		$multipage = $coursearr[1];
	}
	$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($coursearr[3]);
	$members = C::t('common_member')->fetch_all_username_by_uid($coursearr[2]);

}elseif($ac=='finance'){
	$keke_video_base['tixian_type']=unserialize($keke_video_base['tixian_type']);
	if($_GET['o']=='set'){
		
	}else{
		$ppp=15;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$where='uid='.$_G['uid'];
		$tmpurl='plugin.php?id=keke_video_base:t&ac=finance';
		if($_GET['type']==2){
			$tmpurl=$tmpurl.'&type=2';
			$count_all=C::t('#keke_video_base#keke_video_cashout')->count_all($where);
			$dataarr=C::t('#keke_video_base#keke_video_cashout')->fetch_alls($startlimit,$ppp,$where,$order);
		}else{
			$count_all=C::t('#keke_video_base#keke_video_cash')->count_all($where);
			$dataarr=C::t('#keke_video_base#keke_video_cash')->fetch_alls($startlimit,$ppp,$where,$order);
		}
		
		foreach($dataarr as $key=>$val){
			$dataarr[$key]['times']=dgmdate($val['time'], 'Y-m-d H:i');
		}
		
		
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
		$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	}
	
}elseif($ac=='win'){
	$cid=intval($_GET['cid']);
	$cpid=intval($_GET['cpid']);
	if($_GET['o']=='addz'){
		$chapterarr=C::t('#keke_video_base#keke_video_chapter')->fetch_first_by_cpid($cpid);
	}elseif($_GET['o']=='addke'){
		$keid=intval($_GET['keid']);
		$chapterarr=C::t('#keke_video_base#keke_video_chapter')->fetch_all_by_displayorder($_G['uid'],$cid);
		$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
		$teachergroup = C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
		if($keid){
			$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($keid);
			$videodata=unserialize($kearr['concent']);
			if($videodata['videotype']==1){
				$videoresult = getVideoInfos($videodata['videoid']);
			}
			if($kearr['type']==3){
				$videodata['dete']=dgmdate($videodata['dete'], 'Y-m-d H:i:s');
			}elseif($kearr['type']==2 && $videodata['audio']){
				$videodata['audio_info']=htmlspecialchars_decode($videodata['audio_info']);
			}
		}
		if(!$chapterarr && $_GET['op']!='insertaudio'){
			//exit(lang('plugin/keke_video_base', '020'));
		}
	}elseif($_GET['o']=='addfile'){
		$all_set=_get_set();
		$ishttps=($_SERVER['SERVER_PORT'] == 443 || $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off') ? 'https' : 'http';
		$fileid=intval($_GET['fileid']);
		if($fileid){
			$filedata=C::t('#keke_video_base#keke_video_file')->fetch_first_by_cpid($fileid);
			$cid=$filedata['cid'];
		}
		
		$ishttps=($_SERVER['SERVER_PORT'] == 443 || $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off') ? 'https' : 'http';
		$posturl=$all_set['oss_on']?$ishttps.'://'.$all_set['oss_bucket'].'.'.$all_set['oss_endPoint']:$_G['siteurl'].'plugin.php?id=keke_video_base:ajax&ac=updatafile&formhash='.FORMHASH;
		if($keke_video_base['filetype']){
			$arr=explode('|',$keke_video_base['filetype']);
			foreach($arr as $key=>$val){
				$dot=($key!=(count($arr)-1))?',':'';
				$accept[0].=$val.$dot;
				$accept[1].='.'.$val.$dot;
			}
		}
	}elseif($_GET['o']=='kekegetpushcode'){
		$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($_GET['keid']);
		if($kearr['state']){
			exit(lang('plugin/keke_video_base', '021'));
		}
		$kearr['concent']=unserialize($kearr['concent']);
		if($kearr['concent']['livemode']==2){
			exit(lang('plugin/keke_video_base', '021'));
		}
		if($kearr['concent']['dete']-TIMESTAMP>$keke_video_base['get_push_time']*60){
			exit(lang('plugin/keke_video_base', '023').intval($keke_video_base['get_push_time']).lang('plugin/keke_video_base', '024'));
		}
		
		$live_endtime=$kearr['concent']['dete']+intval($kearr['concent']['lasttime'])*60;
		if($live_endtime<TIMESTAMP){
			exit(lang('plugin/keke_video_base', '025'));
		}
		
		$appname='uid_'.$_G['uid'];
		$streamname=$appname.'_'.$_GET['keid'];
		$live_code=_getkekelive($appname,$streamname);
		$live_url=array('url'=>$live_code[0][1],'key'=>$live_code[0][2]);
		
		if($kearr['concent']['rec']){
			setliverec($appname,$streamname,$duration);
		}
	}elseif($_GET['o']=='answersreply'){
		$aid=intval($_GET['aid']);
		$ansarr=C::t('#keke_video_base#keke_video_answers')->fetchfirst_byaid($aid);
		$ansarr['text']=htmlspecialchars_decode($ansarr['text']);
		if($ansarr['teacher_uid']!=$_G['uid']){
			exit(lang('plugin/keke_video_base', '026'));
		}
	}elseif($_GET['o']=='waitprice'){
		$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($_GET['orderid']);
		if($orderdata['teacher_uid']!=$_G['uid']){
			exit(lang('plugin/keke_video_base', '026'));
		}
		if($orderdata['state']!=0){
			exit(lang('plugin/keke_video_base', '027'));
		}
	}elseif($_GET['o']=='editmeia'){
		$vid=dhtmlspecialchars($_GET['vid']);
		$videoinfo=_getplayinfo($vid);
		$mediadata['title']=kekevideo_utf2gbk($videoinfo['VideoBase']['Title']);
		$mediadata['cover']=$videoinfo['VideoBase']['CoverURL'];
	}elseif($_GET['o']=='callmeia'){
		$vid=dhtmlspecialchars($_GET['vid']);
		$mediadata=C::t('#keke_video_base#keke_video_media')->fetchfirst_byid($vid);
		$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($mediadata['uid']);
		$teachergroup = C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
		if(!$teachergroup['permission_callmedia']){
			exit(lang('plugin/keke_video_base', '534'));
		}
		$sizearr=explode('|',$keke_video_base['callwin']);
		$sizearr[0]=$sizearr[0]?$sizearr[0]:'700';
		$sizearr[1]=($mediadata['type']==2)?'80':$sizearr[1];
		$size='width="'.$sizearr[0].'" height="'.$sizearr[1].'"';
		$keke_video_base['internalcallname']=$keke_video_base['internalcallname']?$keke_video_base['internalcallname']:'videoid';
	}
}
if((strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX")!== false || strstr($_SERVER['HTTP_USER_AGENT'], "QianFan")!== false || strstr($_SERVER['HTTP_USER_AGENT'], "Appbyme")!== false) && $keke_video_base['appheader']){
	$_GET['app']=1;
}
include template('keke_video_base:t'.($ac?'_'.$ac:''));