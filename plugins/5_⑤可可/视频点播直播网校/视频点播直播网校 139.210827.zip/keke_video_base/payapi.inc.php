<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
header("Content-type:text/html;charset=utf-8");
include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
$title= CHARSET=='gbk' ? diconv(lang('plugin/keke_video_base', '028'), CHARSET, 'UTF-8') : lang('plugin/keke_video_base', '028');
$cid=dhtmlspecialchars($_GET['cid']);
$post_orderid=dhtmlspecialchars($_GET['orderid']);
$dcreditname=$_G['setting']['extcredits'][$keke_video_base['integraltype']]['title'];
if(!$_G['uid']){
	$msg=lang('plugin/keke_video_base', '029');
	$msgs=kekevideo_gbk2utf($msg);
	if($zftype==1){
		exit( '<script>alert("'.$msgs.'");</script>');
	}else{
		exit( json_encode(array('err' =>$msgs)));
	}
}
$allcatedata=_get_allcatedata();
$total_price=0;
if($post_orderid){
	$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($post_orderid);
	if($orderdata['state']==1){
		showmessage(lang('plugin/keke_video_base', '030'), '', array(), array('alert' => 'error'));
	}
	$ordercids=explode(',',$orderdata['cid']);
	$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($ordercids);
	$orderid=$post_orderid;
	$total_price=$orderdata['price'];
	if($orderdata['revision']){
		if($_GET['zftype']==2){
			$orderid=$orderid.'_re'.random(2);
		}
	}
	if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']){
		$_GET['deductionnum']=intval(abs($_GET['deductionnum']));
		if(!discuz_process::islocked('getuidcount_checklocked', 60)) {
			$member = C::t('common_member_count')->fetch($_G['uid']);
			if($member['extcredits'.$keke_video_base['integraltype']]<$_GET['deductionnum']){
				$msg=kekevideo_gbk2utf($_G['setting']['extcredits'][$keke_video_base['integraltype']]['title'].lang('plugin/keke_video_base', '031'));
				discuz_process::unlock('getuidcount_checklocked');
				exit(json_encode(array('err' =>$msg)));
			}elseif($_GET['zftype']==1 && $_GET['cherckapi']){
				discuz_process::unlock('getuidcount_checklocked');
				exit( json_encode(array('err' =>0)));
			}
			$uptitle=lang('plugin/keke_video_base', '255').lang('plugin/keke_video_base', '258').$buytitlenames.lang('plugin/keke_video_base', '259').lang('plugin/keke_video_base', '257');
			updatemembercount($_G['uid'], array('extcredits'.$keke_video_base['integraltype']=>-$_GET['deductionnum']), true, '', 0, '',lang('plugin/keke_video_base', '032'),$uptitle);
			discuz_process::unlock('getuidcount_checklocked');
		}else{
			exit( json_encode(array('err' =>kekevideo_gbk2utf(lang('plugin/keke_video_base', '033')))));
		}
		$total_price-=intval(abs($_GET['deductionnum']))*$keke_video_base['proportion'];
		$deduction['money']=sprintf("%.2f",(intval(abs($_GET['deductionnum']))*$keke_video_base['proportion']));
		$deduction['info']=intval(abs($_GET['deductionnum'])).$dcreditname.lang('plugin/keke_video_base', '254').$deduction['money'].lang('plugin/keke_video_base', '047');
		
		$updateorderarr=array(
			'price'=>$total_price,
			'deduction'=>($deduction?serialize($deduction):''),
		);
		C::t('#keke_video_base#keke_video_order')->update($post_orderid,$updateorderarr);
	}elseif($_GET['zftype']==1 && $_GET['cherckapi']){
		exit( json_encode(array('err' =>0)));
	}
	if($total_price<=0){
		uporderstate($orderid,3);
		$_GET['zftype']=3;
	}
	if(K_INCMAG){
		$_GET['zftype']=5;
	}elseif(K_INQIANFAN){
		$_GET['zftype']=6;
	}
}elseif($cid){
	$odids=array();
	$total_price=$k=0;
	$appoint=unserialize($keke_video_base['appoint']);
	$cids=explode(',',$cid);	
	$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
	foreach($courses as $pk=>$pv){
	    if($pv['state']==5){
            continue;
        }
		$courarr_unit[$pv['uid']][]=$pv;
		if($pv['credit']){
			$member_credit[$pv['credit_type']]+=$pv['credit'];
		}

        $cateGroupArr=unserialize($allcatedata[$pv['sub_cate']]['vip_groupids']);
        if($cateGroupArr && $appoint) {
            $pv['vip']=1;
            $appoint=array_keys(array_flip($appoint)+array_flip($cateGroupArr));
        }
        if($keke_video_base['groupnosw']){
            foreach (getUserAllGroup() as $groupId) {
                if(in_array($groupId,$appoint)){
                    $isVipUser=1;
                    break;
                }
            }
        }else{
            $isVipUser=in_array($_G['groupid'],$appoint);
        }
		if($pv['vip'] && $pv['vipprice']>0 && $isVipUser){
			$pv['price']=$pv['vipprice'];
		}
		$tt_price+=$pv['price'];
		if($k==0){
			$coursnames='<a href="plugin.php?id=keke_video_base&ac=course&cid='.$pk.'">'.$pv['title'].'</a>';
		}
		$k++;
	}
	if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']){
		if($keke_video_base['deductionlimit']){
			$deductionlimit=($tt_price*$keke_video_base['deductionlimit']/100)/$keke_video_base['proportion'];
			if($_GET['deductionnum']>$deductionlimit){
				$msg=lang('plugin/keke_video_base', '510').$deductionlimit.$_G['setting']['extcredits'][$keke_video_base['integraltype']]['title'].lang('plugin/keke_video_base', '511');
				exit(json_encode(array('err' =>kekevideo_gbk2utf($msg))));
			}
		}
		$member_credit[$keke_video_base['integraltype']]+=intval(abs($_GET['deductionnum']));
	}
	if($_GET['zftype']==3 && $keke_video_base['creditpay']){
		if($_GET['deductionnum']){
			$deductionmoney=sprintf("%.2f",(intval(abs($_GET['deductionnum']))*$keke_video_base['proportion']));
			$needmoneyn=$tt_price-$deductionmoney;
		}else{
			$needmoneyn=$tt_price;
		}
		$needcredit=ceil((1/$keke_video_base['creditpayproportion'])*$needmoneyn);
		$member_credit[$keke_video_base['creditpaytype']]+=intval($needcredit);
	}
	$err=0;
	if(!discuz_process::islocked('getuidcount_checklocked', 60)) {
		$member = C::t('common_member_count')->fetch($_G['uid']);
		foreach($member_credit as $check_c_k =>$check_c_v){
			if($member['extcredits'.$check_c_k]<$check_c_v){
				$err=$check_c_k;
			}
		}
		if($err){
			$msg=kekevideo_gbk2utf($_G['setting']['extcredits'][$err]['title'].lang('plugin/keke_video_base', '031'));
			discuz_process::unlock('getuidcount_checklocked');
			exit(json_encode(array('err' =>$msg,'state'=>4)));
		}elseif($_GET['zftype']==1 && $_GET['cherckapi']){
			discuz_process::unlock('getuidcount_checklocked');
			exit( json_encode(array('err' =>0)));
		}
		$uptitle=lang('plugin/keke_video_base', '255').lang('plugin/keke_video_base', '258').$coursnames.lang('plugin/keke_video_base', '259').(count($cids)>1?lang('plugin/keke_video_base', '256'):'').lang('plugin/keke_video_base', '257');
		foreach($member_credit as $pay_c_k =>$pay_c_v){
			updatemembercount($_G['uid'], array('extcredits'.$pay_c_k=>-$pay_c_v), true, '', 0, '',lang('plugin/keke_video_base', '032'),$uptitle);
		}
		
		discuz_process::unlock('getuidcount_checklocked');
	}else{
		exit( json_encode(array('err' =>kekevideo_gbk2utf(lang('plugin/keke_video_base', '033')))));
	}
	C::t('#keke_video_base#keke_video_cart')->delete_by_uidandcid($_G['uid'],$cids);

	foreach($courarr_unit as $uk=>$uv){
		$cidsa=array();
		$unit_price=$vipprice=0;
		$unitcredit=array();
		foreach($uv as $vv){
			$cidsa[]=$vv['id'];
			if($vv['credit']){
				$unitcredit[$vv['credit_type']]+=$vv['credit'];
			}
            $cateGroupArr=unserialize($allcatedata[$vv['sub_cate']]['vip_groupids']);
            if($cateGroupArr && $appoint) {
                $vv['vip']=1;
                $appoint=array_keys(array_flip($appoint)+array_flip($cateGroupArr));
            }
            $isVipUser=0;
            if($keke_video_base['groupnosw']){
                foreach (getUserAllGroup() as $groupId) {
                    if(in_array($groupId,$appoint)){
                        $isVipUser=1;
                        break;
                    }
                }
            }else{
                $isVipUser=in_array($_G['groupid'],$appoint);
            }
			if($vv['vip'] && $vv['vipprice']>0 && $isVipUser){
				$isvipprice[$vv['id']]=$vv['price']=$vv['vipprice'];
                $vipprice+=$vv['vipprice'];
			}
			$unit_price+=$vv['price'];
		}
		$unit_orderid=_orderid();
		$odids[]=$unit_orderid;
		
		if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']>0){
			$deduction['money']=sprintf("%.2f",(intval(abs($_GET['deductionnum']))*$keke_video_base['proportion'])/$tt_price*$unit_price);
			$deduction['info']=' '.intval(abs($_GET['deductionnum'])).' '.$dcreditname.' '.lang('plugin/keke_video_base', '254').$deduction['money'].lang('plugin/keke_video_base', '047');
		}
		if($_GET['zftype']==3 && $keke_video_base['creditpay']){
			$deduction['info'].=($_GET['deductionnum']?'<br/>'.lang('plugin/keke_video_base', '287'):'').' '.intval($needcredit).' '.$_G['setting']['extcredits'][$keke_video_base['creditpaytype']]['title'].' '.lang('plugin/keke_video_base', '509').sprintf("%.2f",$needmoneyn).lang('plugin/keke_video_base', '047');
		}
		if($isvipprice){
			$deduction['vipprice']=$isvipprice;
		}		
		_instorder($unit_orderid,$unit_price,$uk,implode(",",$cidsa),$unitcredit,$deduction,'',$vipprice);
		$total_price+=$unit_price;
	}
	if(count($courarr_unit)>1){
		$orderid='ALL'._orderid();
		_instorder($orderid,$total_price,0,implode(",",$odids),$member_credit);
	}else{
		$orderid=$unit_orderid;
	}
	if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']){
		$total_price-=intval(abs($_GET['deductionnum']))*$keke_video_base['proportion'];
	}
	
	if($_GET['zftype']==3 && $keke_video_base['creditpay']){
		$total_price-=$needmoneyn;
	}
	
	if($total_price<=0){
		uporderstate($orderid,3);
		$_GET['zftype']=3;
	}
	$total_price=round($total_price,2);
	if(K_INCMAG){
		$_GET['zftype']=5;
	}elseif(K_INQIANFAN){
		$_GET['zftype']=6;
	}
}elseif($_GET['keid'] || $_GET['chapterid']){
	$keid=intval($_GET['keid']);
	$chapterid=intval($_GET['chapterid']);
	if($chapterid){
		$chapter=C::t('#keke_video_base#keke_video_chapter')->fetch_first_by_cpid($chapterid);
		$cid=$chapter['cid'];
		$total_price=$total_prices=$chapter['price'];
		$buytitlenames=lang('plugin/keke_video_base', '415').lang('plugin/keke_video_base', '219').':'.$chapter['title'];
		$teacher_uid=$chapter['uid'];
		$buymodid=2;
		$kcid=$chapterid;
	}elseif($keid){
		$ke=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($keid);
		$cid=$ke['cid'];
		$total_price=$total_prices=$ke['price'];
		$buytitlenames=lang('plugin/keke_video_base', '415').lang('plugin/keke_video_base', '220').':'.$ke['title'];
		$teacher_uid=$ke['uid'];
		$buymodid=3;
		$kcid=$keid;
	}
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($ke['cid']);
    $member_credit=array();

    if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']){
        if($keke_video_base['deductionlimit']){
            $deductionlimit=($total_price*$keke_video_base['deductionlimit']/100)/$keke_video_base['proportion'];
            if($_GET['deductionnum']>$deductionlimit){
                $msg=lang('plugin/keke_video_base', '510').$deductionlimit.$_G['setting']['extcredits'][$keke_video_base['integraltype']]['title'].lang('plugin/keke_video_base', '511');
                exit(json_encode(array('err' =>kekevideo_gbk2utf($msg))));
            }
        }
        $member_credit[$keke_video_base['integraltype']]+=intval(abs($_GET['deductionnum']));
    }
    if($_GET['zftype']==3 && $keke_video_base['creditpay']){
        if($_GET['deductionnum']){
            $deductionmoney=sprintf("%.2f",(intval(abs($_GET['deductionnum']))*$keke_video_base['proportion']));
            $needmoneyn=$total_price-$deductionmoney;
        }else{
            $needmoneyn=$total_price;
        }
        $needcredit=ceil((1/$keke_video_base['creditpayproportion'])*$needmoneyn);
        $member_credit[$keke_video_base['creditpaytype']]+=intval($needcredit);
    }

    if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']>0){
        $deduction['money']=sprintf("%.2f",intval(abs($_GET['deductionnum']))*$keke_video_base['proportion']);
        $deduction['info']=' '.intval(abs($_GET['deductionnum'])).' '.$dcreditname.' '.lang('plugin/keke_video_base', '254').$deduction['money'].lang('plugin/keke_video_base', '047');
    }
    if($_GET['zftype']==3 && $keke_video_base['creditpay']){
        $deduction['info'].=($_GET['deductionnum']?'<br/>'.lang('plugin/keke_video_base', '287'):'').' '.intval($needcredit).' '.$_G['setting']['extcredits'][$keke_video_base['creditpaytype']]['title'].' '.lang('plugin/keke_video_base', '509').sprintf("%.2f",$needmoneyn).lang('plugin/keke_video_base', '047');
    }
    if(!discuz_process::islocked('getuidcount_checklocked', 60)) {
        $member = C::t('common_member_count')->fetch($_G['uid']);
        foreach($member_credit as $check_c_k =>$check_c_v){
            if($member['extcredits'.$check_c_k]<$check_c_v){
                $err=$check_c_k;
            }
        }
        if($err){
            $msg=kekevideo_gbk2utf($_G['setting']['extcredits'][$err]['title'].lang('plugin/keke_video_base', '031'));
            discuz_process::unlock('getuidcount_checklocked');
            exit(json_encode(array('err' =>$msg,'state'=>4)));
        }elseif($_GET['zftype']==1 && $_GET['cherckapi']){
            discuz_process::unlock('getuidcount_checklocked');
            exit( json_encode(array('err' =>0)));
        }
        $uptitle=lang('plugin/keke_video_base', '255').lang('plugin/keke_video_base', '258').$buytitlenames.lang('plugin/keke_video_base', '259').(count($cids)>1?lang('plugin/keke_video_base', '256'):'').lang('plugin/keke_video_base', '257');
        foreach($member_credit as $pay_c_k =>$pay_c_v){
            updatemembercount($_G['uid'], array('extcredits'.$pay_c_k=>-$pay_c_v), true, '', 0, '',lang('plugin/keke_video_base', '032'),$uptitle);
        }

        discuz_process::unlock('getuidcount_checklocked');
    }else{
        exit( json_encode(array('err' =>kekevideo_gbk2utf(lang('plugin/keke_video_base', '033')))));
    }

	$orderid=_orderid();
	_instorder($orderid,$total_prices,$teacher_uid,$kcid,'',$deduction,$buymodid);

    if($_GET['deduction'] && $keke_video_base['deduction'] && $_GET['deductionnum']){
        $total_price-=intval(abs($_GET['deductionnum']))*$keke_video_base['proportion'];
    }
    if($_GET['zftype']==3 && $keke_video_base['creditpay']){
        $total_price-=$needmoneyn;
    }
	if($total_price<=0){
		uporderstate($orderid,3);
		$_GET['zftype']=3;
	}
	if(K_INCMAG){
		$_GET['zftype']=5;
	}elseif(K_INQIANFAN){
		$_GET['zftype']=6;
	}
}

if($_GET['zftype']==1){
	if($keke_video_base['payapi']==2){
		include_once DISCUZ_ROOT."source/plugin/keke_video_base/paylib/payjs/payjs.php";
		dopay($title,$total_price,$orderid,1);
	}else{
		require_once("source/plugin/keke_video_base/paylib/alipay/alipay.config.php");
		require_once("source/plugin/keke_video_base/paylib/alipay/alipay_submit.class.php");
		$show_url = $_G['siteurl']."plugin.php?id=keke_video_base";
		$parameter = array(
			"service"       => $alipay_config['service'],
			"partner"       => $alipay_config['partner'],
			"seller_id"  => $alipay_config['seller_id'],
			"payment_type"	=> $alipay_config['payment_type'],
			"notify_url"	=> $alipay_config['notify_url'],
			"return_url"	=> $alipay_config['return_url'],
			"_input_charset"	=> trim(strtolower($alipay_config['input_charset'])),
			"out_trade_no"	=> $orderid,
			"subject"	=> $title,
			"total_fee"	=> $total_price,
			"show_url"	=> $show_url,
			"app_pay"   => "Y",
		);
		$alipaySubmit = new AlipaySubmit($alipay_config);
		$html_text = $alipaySubmit->buildRequestForm($parameter,"get", 'go-pay');
		exit($html_text);
	}
}elseif($_GET['zftype']==2){
	if($keke_video_base['payapi']==2){
		include_once DISCUZ_ROOT."source/plugin/keke_video_base/paylib/payjs/payjs.php";
		dopay($title,$total_price,$orderid,2);
	}else{
		if($_GET['inwxmini']){
			exit(json_encode(array('orderid' => $orderid)));
		}
		include_once DISCUZ_ROOT."source/plugin/keke_video_base/inc.php";	
		$tools = new JsApiPay();
		$openIds = $_G['cookie'][$uskey];
		$openId=authcode($openIds, 'DECODE', $_G['config']['security']['authkey']);
		$notify = new NativePay();
		$input = new WxPayUnifiedOrder();
		$input->SetBody($title);
		$input->SetAttach($title);
		$input->SetOut_trade_no($orderid);
		$input->SetTotal_fee($total_price*100);
		$input->SetTime_start(date("YmdHis"));
		$input->SetGoods_tag($title);
		$input->SetNotify_url($_G['siteurl'].'source/plugin/keke_video_base/paylib/notify_wx.inc.php');
		$input->SetTrade_type($s_type);
		if($iswx){
			$input->SetOpenid($openId);
			$order = WxPayApi::unifiedOrder($input);
			$jsApiParameters = $tools->GetJsApiParameters($order);
			try
			{
				$jsApiParameters = $tools->GetJsApiParameters($order);
			}catch (Exception $e){
				$jsApiParameters = json_encode(array('err' => $e->getMessage()));
				$jsApiParameters = diconv($jsApiParameters, 'utf-8');
			}
			echo $jsApiParameters;
			exit;
		}else{
			if(checkmobile() && 1){
				$h5pay=_h5pay($total_price*100,$orderid,$title);
				echo json_encode(array('h5payurl' => $h5pay['mweb_url'],'ewmurl' => '','orderid'=>$orderid));
			}else{
				$input->SetProduct_id($orderid);
				$result = $notify->GetPayUrl($input);
				$url2 = $result["code_url"];
				if($url2){
					$src = _getqrcodeurl($url2);
					if(strpos($orderid, '_re') !== false){
						$exporderid=explode('_re',$orderid);
						$orderid=$exporderid[0];
					}
					echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
				}else{
					$err = $result['return_msg'];
					echo json_encode(array('err' => $err));
				}
			}
		}
	
	}
}elseif($_GET['zftype']==3){
	exit(json_encode(array('err' => 0,'ewmurl'=>1,'orderid'=>$orderid)));
}elseif($_GET['zftype']==5){
	$magreturn=_magpaytrade($orderid,$total_price,$title);
	exit(json_encode($magreturn));
}elseif($_GET['zftype']==6){
	$return=array(
		'title'=>$title,
		'orderid'=>$orderid,
		'total_price'=>$total_price
	);
	exit(json_encode($return));
}