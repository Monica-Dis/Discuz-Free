<?php
/**
 * Copyright 2001-2099 DisM!应用中心.
 * This is NOT a freeware, use is subject to license terms
 * 应用更新支持：https://dism.taobao.com
 * 最新插件：http://t.cn/Aiux1Jx1
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


date_default_timezone_set('Asia/Chongqing');
include_once DISCUZ_ROOT."source/plugin/keke_video_base/identity.inc.php";
require_once libfile('function/cache');


function _uploadpics($filses){
	global $_G;
	require_once libfile('function/forum');
	$data = array('extid' => 1);
	$pic['url']=$_G['setting']['attachurl'].'common/'.upload_icon_banner($data, $filses,'');
	$pic['error'] = 0;
	return $pic;
}

function _uploadpicss($filses){
	global $_G;
	require_once libfile('function/forum');
	$datas = array('extid' => 1);
	foreach ($filses['error'] as $key => $val) {
		$data[$key]['name'] = $filses['name'][$key];
		$data[$key]['type'] = $filses['type'][$key];
		$data[$key]['tmp_name'] = $filses['tmp_name'][$key];
		$data[$key]['error'] = $filses['error'][$key];
		$data[$key]['size'] = $filses['size'][$key];
	}
	
	foreach ($data as $ks => $vs) {
		$return[$ks] = upload_icon_banner($datas, $vs,'');
	}
	return $return;
}


function _upload_file($file,$max=502400){
	global $_G;
	$file['size'] > ($max * 5024) && showmessage('file_size_overflow', '', array('size' => $max * 5024));
	$file['size'] = intval($file['size']);
	$file['name'] =  trim($file['name']);
	$all_set=_get_set();
	

	if($all_set['oss_on']){
		require_once DISCUZ_ROOT.'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-oss/aliyun-oss-php-sdk-2.3.1.phar';
		$ishttps=($_SERVER['SERVER_PORT'] == 443 || $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off') ? 'https' : 'http';
		$endpoint = "//".$all_set['oss_endPoint'];
		$bucket= $all_set['oss_bucket'];
		$file_pathinfo = pathinfo($file['name']);
		$filepath=$file['tmp_name'];
		$filetype=$file['type'];
		$file_name = 'keke_video_base/file/'.dgmdate($_G['timestamp'], 'Ymd').'/'.random(20).'.'.$file_pathinfo['extension'];
		try{
			$ossClient = new OSS\OssClient($all_set['oss_keyid'], $all_set['oss_keysecret'], $endpoint);
			$ossClient->uploadFile($bucket, $file_name, $filepath);
			$ossurl=$all_set['oss_url']?$all_set['oss_url']:$ishttps."://".$bucket.".".$all_set['oss_endPoint'];
			$ret=$ossurl."/".$file_name;
		} catch(OssException $e) {
			printf(__FUNCTION__ . ": FAILED\n");
			printf($e->getMessage() . "\n");
			return;
		}
		return array($ret,$file);
	}else{
		$upload = new discuz_upload();
		$uploadtype = 'temp';
		if(!is_array($file) || empty($file) || !$upload->is_upload_file($file['tmp_name']) || trim($file['name']) == '' || $file['size'] == 0) {
			$upload->attach = array();
			$upload->errorcode = -1;
			return false;
		} else {
			$upload->type = discuz_upload::check_dir_type('temp');
			$upload->extid = intval($data['extid']);
			$upload->forcename = '';
			$file['size'] = intval($file['size']);
			$file['name'] =  trim($file['name']);
			$file['thumb'] = '';
			$file['ext'] = $upload->fileext($file['name']);
			$file['name'] =  dhtmlspecialchars($file['name'], ENT_QUOTES);
			$file['isimage'] = $upload->is_image_ext($file['ext']);
			$file['extension'] = $upload->get_target_extension($file['ext']);
			$file['attachdir'] = _get_target_dir($upload->type);
			$file['attachment'] = $file['attachdir'].$upload->get_target_filename($upload->type, $upload->extid, $upload->forcename).'.'.$file['extension'];
			$file['target'] = getglobal('setting/attachdir').'./'.$upload->type.'/'.$file['attachment'];
			$upload->attach = $file;
			$upload->errorcode = 0;
		}
		if(!$upload->save()) {
			cpmsg($upload->errormessage(), '', 'error');
		}
		$upload->attach['attachment']=$remote?getglobal('setting/ftp/attachurl').$upload->type.'/'.$upload->attach['attachment']:$_G['setting']['attachurl'].$upload->type.'/'.$upload->attach['attachment'];
		return array($upload->attach['attachment'],$file);
	}
}

function _upload_img($file,$width='', $height='',$max=5024,$thumb='1'){
	global $_G;
	
	$file['size'] > ($max * 5024) && showmessage('file_size_overflow', '', array('size' => $max * 5024));
	$upload = new discuz_upload();
	$uploadtype = 'temp';

	if(!is_array($file) || empty($file) || !$upload->is_upload_file($file['tmp_name']) || trim($file['name']) == '' || $file['size'] == 0) {
		$upload->attach = array();
		$upload->errorcode = -1;
		return false;
	} else {
    	$upload->type = discuz_upload::check_dir_type('temp');
		$upload->extid = intval($data['extid']);
		$upload->forcename = '';

		$file['size'] = intval($file['size']);
		$file['name'] =  trim($file['name']);
		$file['thumb'] = '';
		$file['ext'] = $upload->fileext($file['name']);

		$file['name'] =  dhtmlspecialchars($file['name'], ENT_QUOTES);
		if(strlen($file['name']) > 90) {
			$file['name'] = cutstr($file['name'], 80, '').'.'.$file['ext'];
		}
		$file['isimage'] = $upload->is_image_ext($file['ext']);
		$file['extension'] = $upload->get_target_extension($file['ext']);
		$file['attachdir'] = _get_target_dir($upload->type);
		$file['attachment'] = $file['attachdir'].$upload->get_target_filename($upload->type, $upload->extid, $upload->forcename).'.'.$file['extension'];
		$file['target'] = getglobal('setting/attachdir').'./'.$upload->type.'/'.$file['attachment'];
		if(!$file['isimage']){
			showmessage(lang('plugin/keke_gallerys', 'f0017'), 'plugin.php?id=keke_gallerys:up', array(), array('alert' => 'error'));
		}
		$upload->attach = $file;
		$upload->errorcode = 0;
	}
	if(!$upload->save()) {
		cpmsg($upload->errormessage(), '', 'error');
	}

	if($thumb && ($upload->attach['imageinfo'][0]>$width || $upload->attach['imageinfo'][1]>$height) && $width){
		if($file['isimage']){
			require_once libfile('class/image');
			$img = new image;
			$thumbpic=$img->Thumb($upload->attach['target'], './'.$uploadtype.'/'.$upload->attach['attachment'].'_thumb.jpg', $width, $height, 'fixwr');
		}		
	}
	$upload->attach['attachment']=$remote?getglobal('setting/ftp/attachurl').$upload->type.'/'.$upload->attach['attachment']:$_G['setting']['attachurl'].$upload->type.'/'.$upload->attach['attachment'];	
	if($thumbpic){
		$ret= $upload->attach['attachment'].'_thumb.jpg';
		$file['target']=$file['target'].'_thumb.jpg';
	}else{
		$ret= $upload->attach['attachment'];
	}
	
	$all_set=_get_set();
	if($all_set['oss_on']){
		require_once DISCUZ_ROOT.'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-oss/aliyun-oss-php-sdk-2.3.1.phar';
		$ishttps=($_SERVER['SERVER_PORT'] == 443 || $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off') ? 'https' : 'http';
		$endpoint = "//".$all_set['oss_endPoint'];
		$bucket= $all_set['oss_bucket'];
		$filepath = (strpos(str_replace("\\",'/',$file['target']),str_replace("\\",'/',substr(DISCUZ_ROOT, 0, -1)) ) !== false)? $file['target']:DISCUZ_ROOT.$file['target'];
		$file_name = 'keke_video_base/image/'.dgmdate($_G['timestamp'], 'Ymd').'/'.random(20).'.'.$file['ext'];
		try{
			$ossClient = new OSS\OssClient($all_set['oss_keyid'], $all_set['oss_keysecret'], $endpoint);
			$ossClient->multiuploadFile($bucket, $file_name, $filepath);
			if(file_exists($filepath)){
				@unlink($filepath);
			}
			$ossurl=$all_set['oss_url']?$all_set['oss_url']:$ishttps."://".$bucket.".".$all_set['oss_endPoint'];
			$ret=$ossurl."/".$file_name;
		} catch(OssException $e) {
			printf(__FUNCTION__ . ": FAILED\n");
			printf($e->getMessage() . "\n");
			return;
		}
	}
	return $ret;
	
}
function _get_target_dir($type, $check_exists = true) {
	$subdir = $subdir1 = $subdir2 = '';
	$subdir1 = date('Ym');
	$subdir2 = date('d');
	$subdir = $subdir1.'/'.$subdir2.'/';
	$check_exists && discuz_upload::check_dir_exists($type, $subdir1, $subdir2);
	return $subdir;
}
function _getcateselect($cateid='',$type=''){
	$allcatedata=_get_allcatedata();
	$t=$type?'multiple="multiple" size="10"':'';
	$cats .= '<select name="cateid" '.$t.'><option value=\"0\">'.lang('plugin/keke_video_base', '011').'</option>';
		foreach($allcatedata as $vv){
			if(!$vv['upid']){
				$selected = $cateid==$vv['cate_id'] ? 'selected="selected"' : '';
				$cats.=$vv['subcate']?'<optgroup label="'.$vv['name'].'"></optgroup>':"<option style=\"font-weight :bold;\" value=\"".$vv['cate_id']."\" $selected>".$vv['name']."</option>\n";
				if($vv['subcate']){
					foreach($vv['subcate'] as $subcat){
						$selected = $cateid==$subcat ? 'selected="selected"' : '';
						$cats.="<option value=\"".$subcat."\" $selected>&nbsp;&nbsp;|--".$allcatedata[$subcat]['name']."</option>\n";
					}
				}
			}
		}
	$cats .= '</select>';
	return $cats;
}
function _get_allcatedata(){
	global $_G;
	loadcache('keke_video_cate');
	return $_G['cache']['keke_video_cate']?$_G['cache']['keke_video_cate']:C::t('#keke_video_base#keke_video_cate')->fetch_all_by_displayorder();
}
function _save_cat(){
	if(is_array($_GET['newname'])) {
		foreach($_GET['newname'] as $key => $value) {
			if($value){
				$newarr=array(
					'displayorder' => $_GET['newdisplayorder'][$key],
					'name' => $_GET['newname'][$key],
					'upid' => intval($_GET['upid'][$key]),
				);
				C::t('#keke_video_base#keke_video_cate')->insert($newarr);
			}
		}
	}
	if(is_array($_GET['delete'])) {
		C::t('#keke_video_base#keke_video_cate')->delete($_GET['delete']);
	}
	
	if(is_array($_GET['name'])) {
		$pic=_uploadpicss($_FILES['icon']);
		foreach($_GET['name'] as $keys => $value) {
			$updatearr=array(
				'displayorder' => $_GET['displayorder'][$keys],
				'name' => $_GET['name'][$keys],
				);
			if($pic[$keys])$updatearr['icon']=$pic[$keys];
			C::t('#keke_video_base#keke_video_cate')->update($keys, $updatearr);
		}
	}
	$allcatedata=C::t('#keke_video_base#keke_video_cate')->fetch_all_by_displayorder();
	require_once libfile('function/cache');
	savecache('keke_video_cate', $allcatedata);
}
function _gethotsearch(){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$hotsearch=explode(',',$keke_video_base['hotsearch']);
	foreach($hotsearch as $skey=>$sval){
		$hotsearcharr[]=dhtmlspecialchars($sval);
	}
	return $hotsearcharr;

}
function hightlight($helparr){
	if($_GET['op']=='searech' && $_GET['searechkw']){
		$search=dhtmlspecialchars($_GET['searechkw']);
		foreach($helparr as $k=>$v){
			$arr[$k]['subject']=str_replace($search,'<font color="#CC3300">'.$search.'</font>',$v['subject']);;
		}
	}
	return $arr;
}
function initVodClient($accessKeyId, $accessKeySecret,$inittype='') {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
	$regionId = $keke_video_base['vodregion']?:'cn-shanghai';
	if($inittype && $keke_video_base['area']==2){
		$regionId = 'cn-beijing';
	}
    $profile = DefaultProfile::getProfile($regionId, $accessKeyId, $accessKeySecret);
    return new DefaultAcsClient($profile);
}
function buildAuditContent($vids,$state) {
	$states=$state==1?'Normal':'Blocked';
	foreach($vids as $key=>$val){
		$auditContent[$key]["VideoId"] = $val;
		$auditContent[$key]["Status"] = $states;
	}
	return json_encode($auditContent);
}
function createAudit($vids,$state) {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
	$request = new vod\Request\V20170321\CreateAuditRequest();
	$request->setAuditContent(buildAuditContent($vids,$state));
	$result = $client->getAcsResponse($request);
	$result = json_decode(json_encode($result),true);
	try {
		return $result;
	} catch (Exception $e) {
		print $e->getMessage()."\n";
	}
}

function transcoding($vids){
	$video_data=C::t('#keke_video_base#keke_video_media')->fetch_all($vids);
}


function updateVideoInfo($videoId,$VideoInfo) {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
    $request = new vod\Request\V20170321\UpdateVideoInfoRequest();
    $request->setVideoId($videoId);
    $request->setTitle(kekevideo_gbk2utf($VideoInfo['title']));
	$request->setCoverURL($VideoInfo['cover']);
    $request->setAcceptFormat('JSON');
	try {
		$videoInfo =$client->getAcsResponse($request);
		return $videoInfo;
	} catch (Exception $e) {
		print $e->getMessage()."\n";
	}
}


function createUploadVideo($client) {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
	$teacherpower=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
	
	$tmp=$keke_video_base['packagetmp'];
	if($teacherpower['permission_media']==2 && $teacherpower['permission_tmp'] && $teacherpower['permission_enc']!=3){
		$tmp=$teacherpower['permission_tmp'];
	}
	$filename=_getfilename(dhtmlspecialchars($_GET['filename']));
	$filename=kekevideo_gbk2utf($filename);
	$_GET['filename']=kekevideo_gbk2utf($_GET['filename']);
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
    $request = new vod\Request\V20170321\CreateUploadVideoRequest();
    $request->setTitle($filename);        
    $request->setFileName($_GET['filename']); 
	$request->FileSize("2");
    $request->setDescription("Video Description");
    $request->setCoverURL(""); 
	$request->setTemplateGroupId($tmp); 
    $request->setTags("tag1,tag2");
    $request->setAcceptFormat('JSON');
    return $client->getAcsResponse($request);
}


function refreshUploadVideo($client) {
	$videoId=dhtmlspecialchars($_GET['vid']);
    $request = new vod\Request\V20170321\RefreshUploadVideoRequest();
    $request->setVideoId($videoId);
    $request->setAcceptFormat('JSON');
    return $client->getAcsResponse($request);
}


function getVideoInfos($VideoIds) {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	date_default_timezone_set('Asia/Chongqing');
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
	$request = new vod\Request\V20170321\GetVideoInfosRequest();
	$request->setVideoIds($VideoIds);
	$result = $client->getAcsResponse($request);
	try {
		$result = json_decode(json_encode($result),true);
		foreach($result['VideoList'] as $k=>$v){
			$result['VideoList'][$k]['title']=kekevideo_utf2gbk($v['Title']);
			$result['VideoList'][$k]['Size']=videoformatBytes($v['Size']);
			$result['VideoList'][$k]['Title']=kekevideo_utf2gbk($v['Title']);
			$result['VideoList'][$k]['Duration']=second2duration($v['Duration']);
			$result['VideoList'][$k]['ModificationTime']=str_replace(array('T','Z'),array(' ',''),$v['ModificationTime']);
			$result['VideoList'][$k]['CreationTime']=str_replace(array('T','Z'),array(' ',''),$v['CreationTime']);
		}
		return $result;
	} catch (Exception $e) {
		print $e->getMessage()."\n";
	}
}


function getPlayInfo($videoId,$time=0) {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
	$time=intval($time);
	$Configjson=$time?$Configjson='{"PreviewTime":"'.$time.'"}':'';
    $request = new vod\Request\V20170321\GetPlayInfoRequest();
    $request->setVideoId($videoId);
    $request->setAuthTimeout(3600*24);
	$request->setPlayConfig($Configjson);
    $request->setAcceptFormat('JSON');
	$request->setResultType('Multiple');////////////////////////////
    $ret=$client->getAcsResponse($request);
	return json_decode(json_encode($ret),true);
}




function _getplayinfo($vid){
	try {
		return getPlayInfo($vid);
	} catch (Exception $e) {
		echo $e->getMessage()."\n";
	}
}


function getPlayAuth($client, $videoId) {
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
    $request = new vod\Request\V20170321\GetVideoPlayAuthRequest();
    $request->setVideoId($videoId);
    $request->setAuthInfoTimeout(3000);
    $request->setAcceptFormat('JSON');
    $response = $client->getAcsResponse($request);
    return $response;
}


function _admintranscoding($vids){
	$video_data=C::t('#keke_video_base#keke_video_media')->fetch_all($vids);
	foreach($video_data as $vval){
		$uids[$vval['uid']]=$vval['uid'];
	}
	$teacher_data=C::t('#keke_video_base#keke_video_teacher')->fetch_all_by_uids($uids);
	$allgrodata=C::t('#keke_video_base#keke_video_teachergroup')->fetch_all_teacher();
	foreach($teacher_data as $tval){
		$groups[$tval['uid']]=$allgrodata[$tval['teachergroupid']];
	}
	
	foreach($video_data as $media){
		if($groups[$media['uid']]['permission_enc']==3){
			_transcodings($media['vid'],$groups[$media['uid']]['permission_tmp'],1);
		}else{
			if($groups[$media['uid']]['permission_tmp']){
				_transcodings($media['vid'],$groups[$media['uid']]['permission_tmp']);
			}
			
		}
	}
}
function buildEncryptConfig() {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']),1);
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
    try {
        $request = new Kms\Request\V20160120\GenerateDataKeyRequest();
        $request->setKeyId($keke_video_base['servicekey']);
        $request->setKeySpec("AES_128");
        $response = $client->getAcsResponse($request);
		$result = json_decode(json_encode($response),true);
        $encryptConfig = array();
        $encryptConfig["DecryptKeyUri"] = $_G['siteurl'].'plugin.php?id=keke_video_base:ajax&ac=kms&Ciphertext='.$result['CiphertextBlob'];
        $encryptConfig["KeyServiceType"] = "KMS";
        $encryptConfig["CipherText"] = $result['CiphertextBlob'];
        return json_encode($encryptConfig);
    } catch (Exception $e) {
        print $e->getMessage()."\n";
        return null;
    }
}
function submitTranscodeJobs($client,$vid,$tmp,$buildEncrypt='') {
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
    $request = new vod\Request\V20170321\SubmitTranscodeJobsRequest();
    $request->setVideoId($vid);
    $request->setTemplateGroupId($tmp);
    //构建需要替换的水印参数(只有需要替换水印相关信息才需要构建)
    $request->setOverrideParams('');
	if($buildEncrypt)(
		$buildEncryptConfig=buildEncryptConfig()
	);
    $request->setEncryptConfig($buildEncryptConfig);
    return $client->getAcsResponse($request);
}
function _transcodings($vid,$tmp,$buildEncrypt=''){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	try {
		$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
		$result = submitTranscodeJobs($client,$vid,$tmp,$buildEncrypt);
		if($keke_video_base['debug']){
			print_r($result);
		}
	} catch (Exception $e) {
		print $e->getMessage()."\n";
	}
}
function getuskey(){
	global $_G;
	$ua = strtolower($_SERVER['HTTP_USER_AGENT']);
	return substr(md5('keke'.getClientIps()), 0, 10);
}
function getClientIps() {
    $ip = 'unknown';
    $unknown = 'unknown';
    if (isset($_SERVER['HTTP_X_FORWARDED_FOR']) && $_SERVER['HTTP_X_FORWARDED_FOR'] && strcasecmp($_SERVER['HTTP_X_FORWARDED_FOR'], $unknown)) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], $unknown)) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    if (strpos($ip, ',') !== false) {
        $ip = reset(explode(',', $ip));
    }
    return $ip;
}

function _getfilename($file){
	return str_replace(strrchr($file, "."),"",$file);
}

function kekevideo_utf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return $data;//kekevideo_gbk2utf($data);
	}
}
function kekevideo_gbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}


function second2duration($seconds){
    $duration = '';
    $seconds  = (int) $seconds;
    if ($seconds <= 0) {
        return $duration;
    }
    list($day, $hour, $minute, $second) = explode(' ', gmstrftime('%j %H %M %S', $seconds));
    $day -= 1;
    if ($day > 0) {
        $duration .= (int) $day.lang('plugin/keke_video_base', '012');
    }
    if ($hour > 0) {
        $duration .= '<span class="hour">'.intval($hour).'</span>'.lang('plugin/keke_video_base', '013');
    }
    if ($minute > 0) {
        $duration .= '<span class="fen">'.intval($minute).'</span>'.lang('plugin/keke_video_base', '014');
    }
    if ($second > 0) {
        $duration .= '<span class="miao">'.intval($second).'</span>'.lang('plugin/keke_video_base', '015');
    }
    return $duration;
}


function videoformatBytes($size) { 
    $units = array(' B', ' KB', ' MB', ' GB', ' TB'); 
    for ($i = 0; $size >= 1024 && $i < 4; $i++) $size /= 1024; 
    return round($size, 2).$units[$i]; 
}



function _showadminsubmenu($par,$pmod){
	global $plugin;
	foreach($par as $key=>$val){
		$class=$_GET['op']==$val[1]?'class="current"':'';
		$li.='<li '.$class.'><a href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$pmod.'&op='.$val[1].'\'><span>'.$val[0].'</span></a></li>';
	}
	$html='<div class="itemtitle"><div class="floatsub"><div style="margin-top:5px;"><ul class="tab1">'.$li.'</ul></div></div></div>';
	echo $html;
}


function _save_cache($name){
	$name=_video_editor_safe_replace($name);
	$content = C::t('#keke_video_base#keke_video_'.$name)->fetch_all();
	foreach($content as $key=>$val){
		$ret[$val['id']]=$val;
	}
	require_once libfile('function/cache');
	savecache('keke_video_'.$name, $ret);
}


function _get_cache($name){
	global $_G;
	$name=_video_editor_safe_replace($name);
	loadcache('keke_video_'.$name);
	$data=$_G['cache']['keke_video_'.$name]?$_G['cache']['keke_video_'.$name]:C::t('#keke_video_base#keke_video_'.$name)->fetch_all();
	return $data;
}


function _get_set(){
	$all_set=_get_cache('set');
	foreach($all_set as $v){
		$set[$v['id']]=$v['val'];
	}
	return $set;
}

function _insert_set($arr){
	$set=_get_set();
	foreach($arr as $key=>$val){
		if(isset($set[$key])){
			C::t('#keke_video_base#keke_video_set')->update($key,array('val'=>$val));
		}else{
			C::t('#keke_video_base#keke_video_set')->insert(array('id'=>$key,'val'=>$val));
		}
	}
	_save_cache('set');
}



function _orderid(){
	global $_G;
	$nowdate=dgmdate($_G['timestamp'], 'YmdHis');
	$random=random(10);
	$orderid=$nowdate.$random;
	return $orderid;
}


function _instorder($orderid,$money,$teacher_uid,$cids,$credits=array(),$deduction=array(),$buymodid='',$vipprice=''){
	global $_G;
	if($teacher_uid){
		$teacherdata=C::t('#keke_video_base#keke_video_teacher')->fetch_all_by_uids($teacher_uid);
		$teachergroup=C::t('#keke_video_base#keke_video_teachergroup')->fetch_alls();
		$take=$teachergroup[$teacherdata[$teacher_uid]['teachergroupid']]['permission_take'];
	}
	$orderarr=array(
		'id'=>$orderid,
		'uid'=>$_G['uid'],
		'username'=>$_G['username'],
		'price'=>$money,
		'pay_type'=>$_GET['zftype'],
		'time'=>$_G['timestamp'],
		'cid'=>$cids,
		'teacher_uid'=>$teacher_uid,
		'credit'=>($credits?serialize($credits):''),
		'deduction'=>($deduction?serialize($deduction):''),
		'take'=>$take,
        'vipprice'=>$vipprice,
		'buymod'=>$buymodid,
	);
	return C::t('#keke_video_base#keke_video_order')->insert($orderarr, true);
}

function _getqrcodeurl($urls){
	$src = 'source/plugin/keke_video_base/paylib/wechat/example/qrcode.php?data='.urlencode($urls);
	return $src;
}



function _getvalidtime($ppp,$where){
	$ppp=$ppp?$ppp:20;
	$tmpurl='plugin.php?id=keke_video_base:t&ac=user'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$count_all=C::t('#keke_video_base#keke_video_validtime')->count_all($where);
	$validtimearr=C::t('#keke_video_base#keke_video_validtime')->fetch_all_validtime($startlimit,$ppp,$where,$order);
	foreach($validtimearr as $key=>$val){
		$validtimearr[$key]['time']=$val['exp_time']==0?lang('plugin/keke_video_base', '016'):dgmdate($val['exp_time'], 'Y-m-d H:i');
		$validtimearr[$key]['dftime']=$val['exp_time']==0?lang('plugin/keke_video_base', '016'):((TIMESTAMP<$val['exp_time'])?_gettimediffs($val['exp_time'],TIMESTAMP,2):lang('plugin/keke_video_base', '017'));
		$uids[]=$val['uid'];
		$cids[$val['cid']]=$val['cid'];
		$chapterids[]=$val['chapterid'];
		$keids[]=$val['keid'];
	}
	
	
	if($chapterids){
		$chapterdatas=C::t('#keke_video_base#keke_video_chapter')->fetch_all_by_cpids($chapterids);
		foreach($chapterdatas as $chapterval){
			$cids[$chapterval['cid']]=$chapterval['cid'];
		}
	}
	
	if($keids){
		$kedatas=C::t('#keke_video_base#keke_video_ke')->fetch_all_by_keids($keids);
		foreach($kedatas as $keval){
			$cids[$keval['cid']]=$keval['cid'];
		}
	}
	
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	return array($validtimearr,$multipage,$uids,$cids,$chapterdatas,$kedatas);
}



function _getorder($ppp,$where,$tmpurl=''){
	global $_G;
	$ppp=$ppp?$ppp:20;
	$tmpurl=$tmpurl?$tmpurl:'plugin.php?id=keke_video_base:t&ac=order'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$count_all=C::t('#keke_video_base#keke_video_order')->count_all($where);
	$orderarr=C::t('#keke_video_base#keke_video_order')->fetch_all_order($startlimit,$ppp,$where,$order);
	
	foreach($orderarr as $k=>$v){
		if($v['buymod']){
			if($v['buymod']==2){
				$chapterids[$v['cid']]=$v['cid'];
			}else{
				$keids[$v['cid']]=$v['cid'];
			}
		}else{
			$cids=explode(',',$v['cid']);
			foreach($cids as $vs){
				$cidarr[$vs]=$vs;
			}
		}
	}
	
	if($chapterids){
		$chapterdatas=C::t('#keke_video_base#keke_video_chapter')->fetch_all_by_cpids($chapterids);
		foreach($chapterdatas as $chapterval){
			$cidarr[$chapterval['cid']]=$chapterval['cid'];
		}
	}
	
	if($keids){
		$kedatas=C::t('#keke_video_base#keke_video_ke')->fetch_all_by_keids($keids);
		foreach($kedatas as $keval){
			$cidarr[$keval['cid']]=$keval['cid'];
		}
	}
	
	
	foreach($orderarr as $key=>$val){
		$orderarr[$key]['time']=dgmdate($val['time'], 'Y-m-d H:i:s');
		if($val['credit']){
			$ordercredit='';
			foreach(unserialize($val['credit']) as $credittype=>$creditnum){
				$ordercredit.=($val['price']>0?' + ':'').$creditnum.' '.$_G['setting']['extcredits'][$credittype]['title'].(checkmobile()?'':'<br/>');
			}
			$orderarr[$key]['credits']=$ordercredit;
		}
		$orderarr[$key]['deduction']=unserialize($val['deduction']);
		$cidexp=explode(',',$val['cid']);
		$orderarr[$key]['cid']=$cidexp;
		$orderarr[$key]['cid_total']=count($cidexp);
	}
	
	
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	
	return array($orderarr,$multipage,$cidarr,$chapterdatas,$kedatas);
	
}

function _getfavorites($ppp,$where){
	$ppp=$ppp?$ppp:20;
	$tmpurl='plugin.php?id=keke_video_base:t&ac=user'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	
	$count_all=C::t('#keke_video_base#keke_video_favorites')->count_all($where);
	$favoritesarr=C::t('#keke_video_base#keke_video_favorites')->fetch_all_favorites($startlimit,$ppp,$where,$order);
	
	foreach($favoritesarr as $key=>$val){
		$favoritesarr[$key]['time']=dgmdate($val['time'], 'Y-m-d H:i:s');
		$cids[]=$val['cid'];
	}
	
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	return array($favoritesarr,$multipage,$cids);
}

function _gettimediffs($unixTime_1, $unixTime_2,$type='') {
    $timediff = abs($unixTime_2 - $unixTime_1);
    $days = intval($timediff / 86400);
    $remain = $timediff % 86400;
    $hours = intval($remain / 3600);
    $remain = $remain % 3600;
    $mins = intval($remain / 60);
    $secs = $remain % 60;
	if($type==1){
		return ($days?$days.lang('plugin/keke_video_base', '012'):'').($hours?$hours.lang('plugin/keke_video_base', '013'):'').$mins.lang('plugin/keke_video_base', '014').$secs.lang('plugin/keke_video_base', '015');
	}elseif($type==2){
		return ($days?$days.lang('plugin/keke_video_base', '012'):'').($hours?$hours.lang('plugin/keke_video_base', '013'):'').$mins.lang('plugin/keke_video_base', '014');
	}
    return $days.lang('plugin/keke_video_base', '012').$hours.lang('plugin/keke_video_base', '013').$mins.lang('plugin/keke_video_base', '014').$secs.lang('plugin/keke_video_base', '015');
}


function _updatachaptercount($cid){
	$chapter_count=C::t('#keke_video_base#keke_video_chapter')->count_all('cid='.intval($cid));
	C::t('#keke_video_base#keke_video_course')->update(intval($cid),array('chapter_count'=>$chapter_count));
}

function _updatakecount($cid){
	$ke_count=C::t('#keke_video_base#keke_video_ke')->count_all('cid='.intval($cid));
	C::t('#keke_video_base#keke_video_course')->update(intval($cid),array('ke_count'=>$ke_count));
}


function _getkekelive($AppName = 'AppName',$StreamName  = 'StreamName'){
	  global $_G;
	  $keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	  $https= $keke_video_base['livehttps']?'https':'http';
	  $now =TIMESTAMP;

	  $pull_key = $keke_video_base['pull_key'];
	  $push_key = $keke_video_base['push_key'];
	  $time     = $now + 60;

	  $strpush = "/{$AppName}/{$StreamName}-{$time}-0-0-{$push_key}";

	  $push_cdn = $keke_video_base['push_cdn'];
	  $pull_cdn = $keke_video_base['pull_cdn'];

	  $pushurl[0] = "rtmp://{$push_cdn}/{$AppName}/{$StreamName}?auth_key={$time}-0-0-".md5($strpush);
	  $pushurl[1]   = "rtmp://{$push_cdn}/{$AppName}/";
	  $pushurl[2]   = "{$StreamName}?auth_key={$time}-0-0-".md5($strpush);

	  $strviewrtmp  = "/{$AppName}/{$StreamName}-{$time}-0-0-{$pull_key}";
	  $strviewflv   = "/{$AppName}/{$StreamName}.flv-{$time}-0-0-{$pull_key}";
	  $strviewm3u8  = "/{$AppName}/{$StreamName}.m3u8-{$time}-0-0-{$pull_key}";
      $strviewrst  = "/{$AppName}/{$StreamName}_uid-".(explode('_',$AppName)[1])."-RTS-{$time}-0-0-{$pull_key}";

	  $pull['rtmpurl']  = "rtmp://{$pull_cdn}/{$AppName}/{$StreamName}?auth_key={$time}-0-0-".md5($strviewrtmp);
	  $pull['flvurl']  =  $https. "://{$pull_cdn}/{$AppName}/{$StreamName}.flv?auth_key={$time}-0-0-".md5($strviewflv);
	  $pull['m3u8url']  = $https."://{$pull_cdn}/{$AppName}/{$StreamName}.m3u8?auth_key={$time}-0-0-".md5($strviewm3u8);
      $pull['rsturl']  = "artc://{$pull_cdn}/{$AppName}/{$StreamName}_uid-".(explode('_',$AppName)[1])."-RTS?auth_key={$time}-0-0-".md5($strviewrst);
	  return array($pushurl,$pull);
	  
}
function setliverec($appname,$stream_name='',$duration=''){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	
	$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($_G['uid']);
	$teacherpower=C::t('#keke_video_base#keke_video_teachergroup')->fetchfirst_byid($teacherdata['teachergroupid']);
	
	$tmp=$keke_video_base['packagetmp'];
	if($teacherpower['permission_enc']!=3 && $teacherpower['permission_tmp']){
		$tmp=$teacherpower['permission_tmp'];
	}
	
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']),1);
	$request = new live\Request\V20161101\AddLiveRecordVodConfigRequest();
	$request ->setAppName($appname);
	$request ->setStreamName($stream_name);
	$request ->setDomainName($keke_video_base['pull_cdn']);
	$request ->setVodTranscodeGroupId($tmp);
	$durations=$duration?intval($duration+10)*60:21600;
	$request ->setCycleDuration($durations);
/*	$request ->setAutoCompose('ON');
	$request ->setComposeVodTranscodeGroupId($keke_video_base['live_zmgid']);
*/	$response = $client->getAcsResponse($request);
	$response = json_decode(json_encode($response,true),true);
	return $response;
}
function listLiveRecordVideo($appname,$streamname) {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
    $request = new vod\Request\V20170321\ListLiveRecordVideoRequest();
    $request->setStreamName($streamname);
    $request->setDomainName($keke_video_base['pull_cdn']);
    $request->setAppName($appname);
    $result=$client->getAcsResponse($request);
	try {
		return json_decode(json_encode($result,true),true);
	} catch (Exception $e) {
		print $e->getMessage()."\n";
	}
}
function searchMedia($streamname) {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
    $request = new vod\Request\V20170321\SearchMediaRequest();
    $request->setFields("Title,CoverURL,Status");
    $request->setMatch("Title in ('".$streamname."')");
    $request->setPageNo(1);
    $request->setPageSize(100);
    $request->setSearchType("video");
    $request->setSortBy("CreationTime:Asc");
    $result=$client->getAcsResponse($request);
	try {
		return json_decode(json_encode($result,true),true);
	} catch (Exception $e) {
		print $e->getMessage()."\n";
	}


}
function _getplayAuth($videoid){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	try {
		$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
		$playAuth = getPlayAuth($client, $videoid);
		return $playAuths= $playAuth->PlayAuth;
	} catch (Exception $e) {
		print "<!--".$e->getMessage()."-->\n";
	}
}
function buildMediaMetadata() {
    $mediaMetadata = array();
    $mediaMetadata['Title'] = 'Title';
    $mediaMetadata['Description'] = 'Description';
    return json_encode($mediaMetadata);
}


function buildProduceConfig() {
    $produceConfig = array();
    $produceConfig['TemplateGroupId'] = null;
	
    return json_encode($produceConfig);
}
function buildTimeline($videoTrackClips) {
    $timeline = array();
    $videoTracks = array();
    $videoTrack = array();
    $videoTrack['VideoTrackClips'] = $videoTrackClips;
    $videoTracks[] = $videoTrack;
    $timeline['VideoTracks'] = $videoTracks;
    return json_encode($timeline);
}


function _getsynvideo($video_lists) {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	try {
		$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
		$request = new vod\Request\V20170321\ProduceEditingProjectVideoRequest();
		$request->setMediaMetadata(buildMediaMetadata());
		$request->setProduceConfig(buildProduceConfig());
		$request->setTimeline(buildTimeline($video_lists));
		$result = $client->getAcsResponse($request);
		return json_decode(json_encode($result,true),true);
	} catch (Exception $e) {
		print $e->getMessage()."\n";
	}
}

function delliverec($appname,$stream_name=''){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']),1);
	$request = new live\Request\V20161101\DeleteLiveRecordVodConfigRequest();
	$request ->setAppName($appname); 
	$request ->setStreamName($stream_name);
	$request ->setDomainName($keke_video_base['pull_cdn']);
	$response = $client->getAcsResponse($request);
	$response = json_decode(json_encode($response,true),true);
	return $response;
}

function addliveDomain(){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']),1);
	$request = new live\Request\V20161101\AddLiveDomainRequest();
	$request ->setDomainName('tui.com'); 
	$request ->setLiveDomainType('liveEdge');
	$request ->setRegion('cn-shanghai');
	$response = $client->getAcsResponse($request);
	$response = json_decode(json_encode($response,true),true);
	return $response;
}

function _insertkmstoken($videoid='',$mediatype=''){
	$arr=array(
		'id'=>getuskey(),
		'val'=>md5(getClientIps()),
		'vid'=>$videoid,
		'time'=>(TIMESTAMP+3600),
		'mediatype'=>$mediatype
		);
	C::t('#keke_video_base#keke_video_token')->insert($arr,true,true);
}

function _getusname($uid){
	$userdata=getuserbyuid($uid);
	return $userdata['username'];
}

function cach_log($money,$text,$uid){
	global $_G;
	$processname = 'cash_log_cache';
	if(discuz_process::islocked($processname, 600)) {
		return false;
	}
	$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($uid);
	$nowmoney=$teacherdata['money']+$money;
	C::t('#keke_video_base#keke_video_teacher')->update($uid,
		array(
			'money'=>$nowmoney
		)
	);
	$cacharr=array(
		'uid'=>$uid,
		'money'=>$money,
		'finalmoney'=>$nowmoney,
		'text'=>$text,
		'time'=>TIMESTAMP
	);
	C::t('#keke_video_base#keke_video_cash')->insert($cacharr);
	discuz_process::unlock($processname);
	return true;
}

function MagappAccountTransfer($Uid,$Amount,$Remark){
    global $_G;
    $keke_video_base = $_G['cache']['plugin']['keke_video_base'];
    $Remark = kekevideo_gbk2utf($Remark);
    $Url = 'http://'.$keke_video_base['magurl'].'/core/pay/pay/accountTransfer?secret='.$keke_video_base['magsecret'].'&user_id='.$Uid.'&amount='.$Amount.'&remark='.$Remark.'&out_trade_code='._orderid();
    $Data = dfsockopen($Url);
    if(!$Data) {
        $Data = file_get_contents($Url);
    }
    $return = json_decode($Data,true);
    $return['msg']=kekevideo_utf2gbk($return['msg']);
    if($return['success'] && $return['code'] == 101){
        return array(true);
    }
    return array(false,$return['msg']);
}

function uporderstate($orderid,$pay_type,$sn=''){
	global $_G;
	if(strpos($orderid, '_re') !== false){
		$exporderid=explode('_re',$orderid);
		$orderid=$exporderid[0];
	}
	$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($orderid);
	if($orderdata['state']!=1){
		if(strpos($orderid, 'ALL') !== false){
			$uporderids=explode(',',$orderdata['cid']);
			$allorderdata= C::t('#keke_video_base#keke_video_order')->fetch_all($uporderids);
		}else{
			$allorderdata[]=$orderdata;
		}
		$uporderids[]=$orderid;
		$cids=$unitmoney=array();
		foreach($allorderdata as $ok=>$ov){
			$cids=array_merge(explode(',',$ov['cid']),$cids);
			$unitmoney[$ov['teacher_uid']]['money']=floatval($ov['price']);
            $unitmoney[$ov['teacher_uid']]['vipmoney']=floatval($ov['vipprice']);
			$unitmoney[$ov['teacher_uid']]['credit']=unserialize($ov['credit']);
			$unitmoney[$ov['teacher_uid']]['orderid']=$ov['id'];
			$teacheruids[$ov['teacher_uid']]=$ov['teacher_uid'];
		}
		if(!$orderdata['buymod']){
			$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
            $packageCidArr=array();
            foreach ($courses as $coursId=>$coursItem) {
                if($coursItem['type']==3 && $coursItem['courseids']){
                    $packageCidArr=array_merge(explode(',',str_replace("'","",$coursItem['courseids'])),$packageCidArr);
                    unset($courses[$coursId]);
                    foreach ($cids as $cidKey=>$cidVal){
                        if($cidVal==$coursId){
                            unset($cids[$cidKey]);
                            break;
                        }
                    }
                }
            }
            if($packageCidArr){
                $cids=array_merge($packageCidArr,$cids);
                $packageCourses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($packageCidArr);
                $courses=$packageCourses+$courses;
            }
			$allvalidtime=C::t('#keke_video_base#keke_video_validtime')->fetchall_byuid($orderdata['uid']);
			foreach($allvalidtime as $validkey=>$validval){
				$valids[$validval['cid']]=$validval;
			}

		}

		$teacherdata=C::t('#keke_video_base#keke_video_teacher')->fetch_all_by_uids($teacheruids);
		$teachergroup=C::t('#keke_video_base#keke_video_teachergroup')->fetch_alls();
        $chouyong=array();
		foreach($teacherdata as $tvals){
			$chouyong[$tvals['uid']]=$teachergroup[$tvals['teachergroupid']]['permission_take'];
            $vipchouyong[$tvals['uid']]=$teachergroup[$tvals['teachergroupid']]['permission_viptake'];
		}
		//20200310
		if($_G['cache']['plugin']['keke_market']){
			require_once DISCUZ_ROOT.'./source/plugin/keke_market/function.php';
			$market_userdata=_getmarketupuid($orderdata['uid']);
		}
		foreach($unitmoney as $tuid=>$cachval){
			$takemoney=$isVipTake=0;
			if($cachval['money']){
			    if($cachval['vipmoney']>0 && $vipchouyong[$tuid]){
			        $isVipTake=1;
			        $viptake=$cachval['vipmoney']*$vipchouyong[$tuid]/100;
                    $takemoney=$viptake+(($cachval['money']-$cachval['vipmoney'])*$chouyong[$tuid]/100);
                }else{
                    $takemoney=$cachval['money']*$chouyong[$tuid]/100;
                }
				cach_log($cachval['money'],lang('plugin/keke_video_base', '246').$cachval['orderid'],$tuid);
				if($takemoney>0){
					cach_log(-$takemoney,lang('plugin/keke_video_base', '247').$chouyong[$tuid].'%'.($isVipTake ?' / VIP '.$vipchouyong[$tuid].'%':'').lang('plugin/keke_video_base', '248').$cachval['orderid'],$tuid);
				}
				//20200310
				if($_G['cache']['plugin']['keke_market'] && $market_userdata){
					$market_cach=market_cach_log($market_userdata,$cachval['orderid'],$cachval['money']);
				}
			}
			if($cachval['credit']){
				foreach($cachval['credit'] as $cretype=>$crenum){
					$takecredit=0;
					updatemembercount($tuid, array('extcredits'.$cretype=>$crenum), true, '', 0, '',lang('plugin/keke_video_base', '249'),lang('plugin/keke_video_base', '246').$cachval['orderid']);
					$takecredit=$crenum*$chouyong[$tuid]/100;
					if($takecredit>0){
						updatemembercount($tuid, array('extcredits'.$cretype=>-$takecredit), true, '', 0, '',lang('plugin/keke_video_base', '250'),lang('plugin/keke_video_base', '247').$chouyong[$tuid].'%'.lang('plugin/keke_video_base', '248').$cachval['orderid']);
					}
				}
			}
		}
		
		if($orderdata['buymod']){
			$insterarr=array(
				'uid'=>$orderdata['uid'],
				'teacher_uid'=>$orderdata['teacher_uid'],
			);
			if($orderdata['buymod']==2){
				$validdata=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bychapterid($orderdata['cid'],$orderdata['uid']);
				$chapter=C::t('#keke_video_base#keke_video_chapter')->fetch_first_by_cpid($orderdata['cid']);
				$insterarr['chapterid']=$orderdata['cid'];
				$cida=$chapter['cid'];
			}elseif($orderdata['buymod']==3){
				$validdata=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bykeid($orderdata['cid'],$orderdata['uid']);
				$ke=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($orderdata['cid']);
				$insterarr['keid']=$orderdata['cid'];
				$cida=$ke['cid'];
			}
			$coursesa=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cida);
			$learning_time=$coursesa['learning_time']*86400;
			if($validdata){
				$exptime=$validdata['exp_time']>TIMESTAMP?($learning_time?$validdata['exp_time']+$learning_time:0):($learning_time?TIMESTAMP+$learning_time:0);
				C::t('#keke_video_base#keke_video_validtime')->update($validdata['id'],array('exp_time'=>$exptime,'latest_change_time'=>TIMESTAMP,'title'=>''));
			}else{
				$insterarr['exp_time']=($learning_time?TIMESTAMP+$learning_time:0);
				$insterarr['latest_change_time']=TIMESTAMP;
				C::t('#keke_video_base#keke_video_validtime')->insert($insterarr);
			}
		}else{
            if (count($cids) != count(array_unique($cids))) {
                $keyarr=array();
                $repeatKey=array();
                foreach ($cids as $k => $v) {
                    if(in_array($v, $keyarr)) {
                        $repeatKey[] = $k;
                    }else{
                        $keyarr[] = $v;
                    }
                }
            }
			foreach($cids as $cidKey=>$cid){
				$learning_time=$courses[$cid]['learning_time']*86400;
				if($valids[$cid] || in_array($cidKey,$repeatKey)){
					$exptime=$valids[$cid]['exp_time']>TIMESTAMP?($learning_time?$valids[$cid]['exp_time']+$learning_time:0):($learning_time?TIMESTAMP+$learning_time:0);
					C::t('#keke_video_base#keke_video_validtime')->update($valids[$cid]['id'],array('exp_time'=>$exptime,'latest_change_time'=>TIMESTAMP,'title'=>''));
				}else{
					$insterarr=array(
						'uid'=>$orderdata['uid'],
						'teacher_uid'=>$courses[$cid]['uid'],
						'cid'=>$cid,
						'exp_time'=>($learning_time?TIMESTAMP+$learning_time:0),
						'latest_change_time'=>TIMESTAMP,
					);
					C::t('#keke_video_base#keke_video_validtime')->insert($insterarr);
				}
			}
		}
		
		$updatearray=array(
			'state'=>1,
			'paytime'=>TIMESTAMP,
			'pay_type'=>$pay_type,
			'sn'=>$sn
		);
		C::t('#keke_video_base#keke_video_order')->update($uporderids,$updatearray);
		
		$all_set=_get_set();
		if($all_set['msg_stu_buy_id'] || $all_set['msg_teacher_sell'] || $all_set['msg_admin_sell'] ){
			foreach($allorderdata as $allorderdatav){
				if($all_set['msg_stu_buy_id'])_video_send_notice(array($allorderdatav['uid']),'msg_stu_buy',$allorderdatav);
				if($all_set['msg_teacher_sell'])_video_send_notice(array($allorderdatav['teacher_uid']),'msg_teacher_sell',$allorderdatav);
				if($all_set['msg_admin_sell'])_video_send_notice(explode(',',$all_set['msg_adminuids']),'msg_admin_sell',$allorderdatav);
			}
		}
		
	}
}

function dDecrypt() {
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']),1);
	include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
    try {
        $request = new Kms\Request\V20160120\DecryptRequest();
        $request->setCiphertextBlob($_GET['Ciphertext']);
        $response = $client->getAcsResponse($request);
		$result = json_decode(json_encode($response),true);
        return base64_decode($result['Plaintext']);
    } catch (Exception $e) {
        print $e->getMessage()."\n";
        return null;
    }
}


function setRtsSt($uid){
    global $_G;
    $keke_video_base = $_G['cache']['plugin']['keke_video_base'];
    include_once 'source/plugin/keke_video_base/vodlib/aliyun-php-sdk-core/Config.php';
    $client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']),1);
    $request = new live\Request\V20161101\AddRtsLiveStreamTranscodeRequest();
    $request ->setApp('uid_'.$uid);
    $request ->setDomain($keke_video_base['pull_cdn']);
    $request ->setTemplate('uid-'.$uid.'-RTS');
    $request ->setTemplateType('h264-origin');
    $request ->setDeleteBframes('true');
    $request ->setOpus('true');
    try {
        $response = $client->getAcsResponse($request);
    } catch (ServerException $e) {
    } catch (ClientException $e) {
    }
    return json_decode(json_encode($response,true),true);
}


function _h5pay($money,$out_trade_no,$title){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$userip = _keke_video_get_client_ip();
	$appid  = trim($keke_video_base['wxappid']); 
	$mch_id = trim($keke_video_base['wxmchid']); 
	$key    = trim($keke_video_base['wxshkey']);
	$nonce_str = createNoncestr();
	$body = $title;
	$total_fee = $money; 
	$spbill_create_ip = $userip;
	$notify_url = $_G['siteurl']."source/plugin/keke_video_base/paylib/notify_wx.inc.php"; 
	$trade_type = 'MWEB';
	$scene_info ='{"h5_info":{"type":"Wap","wap_url":"'.$_G['siteurl'].'plugin.php?id=keke_video_base","wap_name":"$title"}}';
	$signA ="appid=$appid&attach=$out_trade_no&body=$body&mch_id=$mch_id&nonce_str=$nonce_str&notify_url=$notify_url&out_trade_no=$out_trade_no&scene_info=$scene_info&spbill_create_ip=$spbill_create_ip&total_fee=$total_fee&trade_type=$trade_type";
	$strSignTmp = $signA."&key=$key";
	$sign = strtoupper(MD5($strSignTmp));
	$post_data = "<xml>
					   <appid>$appid</appid>
					   <mch_id>$mch_id</mch_id>
					   <body>$body</body>
					   <out_trade_no>$out_trade_no</out_trade_no>
					   <total_fee>$total_fee</total_fee>
					   <spbill_create_ip>$spbill_create_ip</spbill_create_ip>
					   <notify_url>$notify_url</notify_url>
					   <trade_type>$trade_type</trade_type>
					   <scene_info>$scene_info</scene_info>
					   <attach>$out_trade_no</attach>
					   <nonce_str>$nonce_str</nonce_str>
					   <sign>$sign</sign>
				   </xml>";
	
	$url = "https://api.mch.weixin.qq.com/pay/unifiedorder";
	$dataxml = postXmlCurl($post_data,$url); 
	$objectxml = (array)simplexml_load_string($dataxml, 'SimpleXMLElement', LIBXML_NOCDATA);
	$objectxml['mweb_url']=$objectxml['mweb_url']._redurl($out_trade_no);
	return $objectxml;
}

function createNoncestr( $length = 32 ){
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
    $str ="";
    for ( $i = 0; $i < $length; $i++ )  {
        $str.= substr($chars, mt_rand(0, strlen($chars)-1), 1);
    }
    return $str;
}
function postXmlCurl($xml,$url,$second = 30){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, $second);
    curl_setopt($ch,CURLOPT_URL, $url);
    curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
    curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
    curl_setopt($ch, CURLOPT_HEADER, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    curl_setopt($ch, CURLOPT_POST, TRUE);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    $data = curl_exec($ch);
    if($data){
        curl_close($ch);
        return $data;
    }else{
        $error = curl_errno($ch);
        curl_close($ch);
        echo "curl_err:$error"."<br>";
    }
}
function _keke_video_get_client_ip($type = 0) {
	if(getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
        $ip = getenv('HTTP_CLIENT_IP');
    } elseif(getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    } elseif(getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
        $ip = getenv('REMOTE_ADDR');
    } elseif(isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return preg_match ( '/[\d\.]{7,15}/', $ip, $matches ) ? $matches [0] : '';
}

function _redurl($orderid){
	global $_G;
	$redirect_url=urlencode($_G['siteurl'].'plugin.php?id=keke_video_base&ac=loading&orderid='.$orderid);
	$redirect_urls='&redirect_url='.$redirect_url;
	return $redirect_urls;
}

function convertUrlQuery($query){
    $queryParts = explode('&', $query);
    $params = array();
    foreach ($queryParts as $param) {
        $item = explode('=', $param);
        $params[$item[0]] = $item[1];
    }
    return $params;
}

function url_route($url){
	$all_set=_get_set();
	if($all_set['rewrite_off']){
		$arr = parse_url($url);
		$urlarr=convertUrlQuery($arr['query']);
		$url=$all_set['rewrite_index'];
		if($urlarr['ac']=='list'){
			if($urlarr['cid']){
				if(!$urlarr['page'] && !$urlarr['o']){
					$url=$all_set['rewrite_list'].'-'.$urlarr['cid'].'-'.($urlarr['scid']?$urlarr['scid']:0);
				}else{
					$url=$all_set['rewrite_list'].'-'.$urlarr['cid'].'-'.($urlarr['scid']?$urlarr['scid']:0).'-'.$urlarr['o'].'-'.($urlarr['page']?$urlarr['page']:0);
				}
			}elseif(!$urlarr['cid'] && ($urlarr['o'] || $urlarr['page'])){
				$url=$all_set['rewrite_list'].'-'.$urlarr['cid'].'-'.($urlarr['scid']?$urlarr['scid']:0).'-'.($urlarr['o']?$urlarr['o']:0).'-'.($urlarr['page']?$urlarr['page']:0);
			}else{
				$url=$all_set['rewrite_list'];
			}
		}elseif($urlarr['ac']=='course'){
			$url=$all_set['rewrite_course'].'-'.$urlarr['cid'];
		}elseif($urlarr['ac']=='play'){
			$url=$all_set['rewrite_play'].'-'.$urlarr['kid'];
		}elseif($urlarr['ac']=='account'){
			$url=$all_set['rewrite_account'];
			if($urlarr['op']){
				$url=$all_set['rewrite_account'].'-'.$urlarr['op'];
				if($urlarr['page']){
					$url=$all_set['rewrite_account'].'-'.$urlarr['op'].'-'.$urlarr['page'];
				}
			}
		}elseif($urlarr['ac']=='teacher'){
			$url=$all_set['rewrite_teacher'].'-'.$urlarr['tcid'];
		}elseif($urlarr['ac']=='pay'){
			$url=$all_set['rewrite_pay'].'-'.$urlarr['cid'];
		}elseif($urlarr['ac']=='teacherlist'){
			$url=$all_set['rewrite_teacherlist'];
		}
		$url.=$all_set['rewrite_suffix'];
	}
	echo $url;
}

function _getuserinfofrommag(){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$userAgent = $_SERVER['HTTP_USER_AGENT'];
	$info = strstr($userAgent, "MAGAPPX");
    $info=explode("|",$info);
	$url='http://'.$keke_video_base['magurl'].'/mag/cloud/cloud/getUserInfo?token='.$info[7].'&secret='.$keke_video_base['magsecret'];
	$data = dfsockopen($url);
	if(!$data) {
		$data = file_get_contents($url);
	}
	$data=json_decode($data,true);
	return $data['data'];
}

function _tologin(){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	if(strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX")!== false){
		$userdata = _getuserinfofrommag();
		if($userdata['user_id']){
			require_once libfile('function/member');
			$member = getuserbyuid($userdata['user_id'],1);
			setloginstatus($member, 2592000);
		}else{
			exit('<script src="source/plugin/keke_video_base/template/js/magjs-x.js"></script><script>mag.toLogin(function(rs){window.location.reload(true);});</script>');
		}
	}elseif(strstr($_SERVER['HTTP_USER_AGENT'], "QianFan")!== false){
		require_once DISCUZ_ROOT . './source/plugin/keke_video_base/class/qianfan.class.php';
		$client = new QF_HTTP_CLIENT($keke_video_base['qfhostname'],$keke_video_base['qftoken']);
        $wap_token_data = $client->post('users/parse-wap-token', array('wap_token' => $_COOKIE['wap_token']));
		if ($wap_token_data['data']['uid'] > 0) {
			require_once libfile('function/member');
			$member = getuserbyuid($wap_token_data['data']['uid'],1);
			setloginstatus($member, 2592000);
		}else{
			exit('<script>function QFH5ready(){QFH5.jumpLogin(function(state,data){if(state==1){QFH5.refresh(1);}else{alert(data.error);}});}</script>');
		}
	}else{
		if(checkmobile()){
			$refererurl=$_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"];
			dheader("Location: ".$_G['siteurl']."member.php?mod=logging&action=login&referer=".urlencode($refererurl));
		}else{
			showmessage('not_loggedin', NULL, array(), array('login' => 1));
		}
	}
}

function _magpaytrade($tradeno,$money,$title){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	if($money>0){
		$url='http://'.$keke_video_base['magurl'].'/core/pay/pay/unifiedOrder?trade_no='.$tradeno.'&callback='.urlencode($_G['siteurl']).'&amount='.$money.'&title='.$title.'&user_id='.$_G['uid'].'&to_user_id=&des='.$title.'&remark='.$title.'&secret='.$keke_video_base['magsecret'];
		$data = dfsockopen($url);
		if(!$data) {
			$data = file_get_contents($url);
		}
		$return=json_decode($data,true);
		if($return['success'] == true){
			$return['data']['trade_no'] = $tradeno;
			$return['data']['title'] = $title;
			$return['data']['money'] = $money;
		}		
	}else{
		$return['data']['trade_no'] = $tradeno;
		$return['data']['money'] = $money;
	}
	return $return;
}

function _get_wechataccesstoken($para=array()){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	loadcache('wechat_access_token');
	require_once libfile('function/cache');
	if(!$_G['cache']['wechat_access_token'][0] || ($_G['cache']['wechat_access_token'][1]+60)<$_G['timestamp']){
		$json_token=_video_curl_post("https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".trim($keke_video_base['wxappid'])."&secret=".trim($keke_video_base['wxsecert']));
		$access_token1=json_decode($json_token,true);
		$access_token2=$access_token1['access_token'];
		if($para['tset']==1 && $access_token1['errcode']>0){
			print_r($access_token1);
		}
		savecache('wechat_access_token', array($access_token2,TIMESTAMP));
	}else{
		$access_token2=$_G['cache']['wechat_access_token'][0];
	}
	return $access_token2;
}


function _video_send_notice($senduids,$sendtype,$para=array()){
	global $_G;
	$all_set=_get_set();
	if(!$all_set['msg_off']){
		return;
	}
	$access_token2=_get_wechataccesstoken($para);
	$openid_arr=C::t('#keke_video_base#keke_video_openid')->getopenid_by_uids($senduids);
	if($sendtype=='msg_stu_updata'){
		$coursearr=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($para['cid']);
		$teacherdata = C::t('#keke_video_base#keke_video_teacher')->fetchfirst_byid($coursearr['uid']);
		$preg=array(
			'search'=>array('{cname}','{tname}'),
			'replace'=>array($coursearr['title'],$teacherdata['username']),
		);
		$jumpurl='plugin.php?id=keke_video_base&ac=course&cid='.$para['cid'];
	}elseif($sendtype=='msg_stu_buy' || $sendtype=='msg_teacher_sell' || $sendtype=='msg_admin_sell'){
		$cids=explode(',',$para['cid']);
		$coursearr=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cids[0]);
		$preg=array(
			'search'=>array('{username}','{price}','{order}','{orderid}'),
			'replace'=>array($para['username'],$para['price'],$coursearr['title'].(count($cids)>1?lang('plugin/keke_video_base', '421'):''),$para['id']),
		);
		if($sendtype=='msg_stu_buy'){
            $jumpurl='plugin.php?id=keke_video_base&ac=account&op=order';
		    if(count($cids)==1){
                $jumpurl='plugin.php?id=keke_video_base&ac=course&cid='.$para['cid'];
            }
		}elseif($sendtype=='msg_teacher_sell'){
			$jumpurl='plugin.php?id=keke_video_base:t&ac=order';
		}
	}elseif($sendtype=='msg_teacher_ans'){
		$preg=array(
			'search'=>array('{cname}','{username}','{kname}'),
			'replace'=>array($para['cname'],$para['username'],$para['kname']),
		);
		$jumpurl='plugin.php?id=keke_video_base:t&ac=user&op=answers';
	}elseif($sendtype=='msg_stu_ans'){
		$preg=array(
			'search'=>array('{tname}','{cname}'),
			'replace'=>array($para['tname'],$para['cname']),
		);
		$jumpurl='plugin.php?id=keke_video_base&ac=course&cid='.$para['cid'];
	}elseif($sendtype=='msg_teacher_cashout' || $sendtype=='msg_teacher_media'){
		$preg=array(
			'search'=>array('{state}'),
			'replace'=>array($para['state']),
		);
		if($sendtype=='msg_teacher_cashout'){
			$jumpurl='plugin.php?id=keke_video_base:t&ac=finance&type=2';
		}elseif($sendtype=='msg_teacher_media'){
			$jumpurl='plugin.php?id=keke_video_base:t&ac=media';
		}
		$jumpurl='';
	}elseif($sendtype=='msg_admin_cashout'){
		$preg=array(
			'search'=>array('{tname}','{money}'),
			'replace'=>array($para['tname'],$para['money']),
		);
		$jumpurl='';
	}elseif($sendtype=='msg_admin_setin'){
		$preg=array(
			'search'=>array('{tname}'),
			'replace'=>array($para['tname']),
		);
		$jumpurl='';
	}
    $siteUrl=str_replace('source/plugin/keke_video_base/paylib/', '',$_G['siteurl']);
	$jumpurl=$siteUrl.$jumpurl;
	foreach($senduids as $senuid){
		$json_template = _video_json_tempalte($openid_arr[$senuid]['openid'],$sendtype,$preg,$jumpurl);
		$url="https://api.weixin.qq.com/cgi-bin/message/template/send?access_token=".$access_token2;
		$res=_video_curl_post($url,urldecode($json_template));
		if($para['tset']==1){
			print_r($res);
		}
		if ($res['errcode']==0){
			//return true;
		}else{
			//return false;
		}
	}
	
}

function _video_json_tempalte($openid,$sendtype,$preg,$jumpurl){
	$all_set=_get_set();
	$tmpmod=explode('@',$all_set[$sendtype]);
	foreach($tmpmod as $tmp){
		$valarr=explode('|',$tmp);
		$valarr[1]=str_replace($preg['search'],$preg['replace'],$valarr[1]);
		$tmpdata[$valarr[0]]=array('value'=>urlencode(kekevideo_gbk2utf($valarr[1])));
	}
    $template=array(
      'touser'=>$openid,
      'template_id'=>$all_set[$sendtype.'_id'],
      'url'=>$jumpurl,
      'data'=>$tmpdata
    );
    $json_template=json_encode($template);
    return $json_template;
}

function _video_curl_post($url , $data=array()){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    $output = curl_exec($ch);
    curl_close($ch);
    return $output;
}

function _keke_gmt_iso8601($time) {
	date_default_timezone_set('PRC');
	$dtStr = date("c", $time);
	$mydatetime = new DateTime($dtStr);
	$expiration = $mydatetime->format(DateTime::ISO8601);
	$pos = strpos($expiration, '+');
	$expiration = substr($expiration, 0, $pos);
	return $expiration."Z";
}

function OSSSignatureurl($file,$new_file_name){
	$all_set=_get_set();
	$ak=$all_set['oss_keyid'];
	$sk=$all_set['oss_keysecret'];
	$domain=$all_set['oss_url']?$all_set['oss_url'].'/':"https://".$all_set['oss_bucket'].".".$all_set['oss_endPoint'].'/';
	$expire=time()+3600;
	$bucketname=$all_set['oss_bucket'];
	$new_file_name=kekevideo_gbk2utf($new_file_name);
	$StringToSign="GET\n\n\n".$expire."\n/".$bucketname."/".$file.'?response-content-disposition=attachment;filename='.$new_file_name;
	$StringToSign=kekevideo_gbk2utf($StringToSign);
	$Sign=base64_encode(hash_hmac("sha1",$StringToSign,$sk,true));
	$url=$domain.urlencode($file)."?response-content-disposition=attachment;filename=".$new_file_name."&OSSAccessKeyId=".$ak."&Expires=".$expire."&Signature=".urlencode($Sign);
	return $url;
}

function _keke_convertToBytes($from){
    $number=substr($from,0,-2);
    switch(strtoupper(substr($from,-2))){
        case "KB":
            return $number*1024;
        case "MB":
            return $number*pow(1024,2);
        case "GB":
            return $number*pow(1024,3);
        case "TB":
            return $number*pow(1024,4);
        case "PB":
            return $number*pow(1024,5);
        default:
            return $from;
    }
}

function _video_getaccesstokens($redirect_uri){
	global $_G;
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	$redirect_base = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$keke_video_base['wxappid'].'&redirect_uri='.$redirect_uri.'&response_type=code&scope=snsapi_base&state=1#wechat_redirect';
	if(empty($_GET['code'])) {
		header('location: '.$redirect_base);
	}else{
		$code=$_GET['code'];
		$get_acctokenurl='https://api.weixin.qq.com/sns/oauth2/access_token?appid='.$keke_video_base['wxappid'].'&secret='.$keke_video_base['wxsecert'].'&code='.$code.'&grant_type=authorization_code';
		$access_tokendata=dfsockopen($get_acctokenurl);
		if(!$access_tokendata){
			$access_tokendata=file_get_contents($get_acctokenurl);
		}
		$access_tokenarr=json_decode($access_tokendata, true);
		return $access_tokenarr;
	}
}

function _video_getwechatuserinfo($openid){
	$access_token=_get_wechataccesstoken();
	$infourl = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=$access_token&openid=$openid";
	$infodata= dfsockopen($infourl);
	if(!$infodata){
		$infodata=file_get_contents($infourl);
	}
	$info = json_decode($infodata,true);
	return $info;
}

function _checkwechatbind(){
	global $_G;
	$bindurl='';
	$all_set=_get_set();
	if($all_set['msg_off']){
		$openid_arr=C::t('#keke_video_base#keke_video_openid')->fetch_first_byid($_G['uid']);
		if(!$openid_arr['openid']){
			$bindurl='plugin.php?id=keke_video_base:ajax&ac=bindwechat&hash='.$openid_arr['code'].'&ref='.urlencode($_SERVER["HTTP_REFERER"]).'&formhash='.FORMHASH;
		}else{
			$subscribe = _video_getwechatuserinfo($openid_arr['openid']);
			if(!($subscribe['subscribe']==1)){
				$bindurl='plugin.php?id=keke_video_base:ajax&ac=bindwechat&hash='.$openid_arr['code'].'&ref='.urlencode($_SERVER["HTTP_REFERER"]).'&op=follow&formhash='.FORMHASH;
			}
		}
	}
	return $bindurl;
}


function _video_urlsafe_b64encode($string) {
    $data = base64_encode($string);
    $data = str_replace(array('+','/','='),array('-','_',''),$data);
    return $data;
}

function _video_urlsafe_b64decode($string) {
    $data = str_replace(array('-','_'),array('+','/'),$string);
    $mod4 = strlen($data) % 4;
    if ($mod4) {
        $data .= substr('====', $mod4);
    }
    return base64_decode($data);
}


function _video_get_csv($data){
	global $_G;
    $string="";
    foreach ($data as $key => $value){
		if($_G['charset'] != 'gbk') {
			foreach ($value as $k => $val){
				$value[$k]=kekevideo_utf2gbk($value[$k]);
        	}
		}
        $string .= implode(",",$value)."\n";  
    }
	$string=($_G['charset'] != 'gbk')?"\xEF\xBB\xBF".$string:$string;
	@ob_end_clean();
    $filename = date('Ymd').'.csv';
    header("Content-type:text/csv"); 
    header("Content-Disposition:attachment;filename=".$filename); 
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0'); 
    header('Expires:0'); 
    header('Pragma:public');
    exit($string);
}


function video_shuffle_assoca($list){
	if (!is_array($list)) {
		return $list;
	}
	$keys = array_keys($list);
	shuffle($keys);
	$random = array();
	foreach ($keys as $key) {
		$random[$key] = $list[$key];
	}
	return $random;
}


function _video_substr_cut($user_name){
    $strlen = mb_strlen($user_name, 'utf-8');
    $firstStr   = mb_substr($user_name, 0, 1, 'utf-8');
    $lastStr    = mb_substr($user_name, -1, 1, 'utf-8');
    return $strlen == 2 ? $firstStr . str_repeat('*', mb_strlen($user_name, 'utf-8') - 1) : $firstStr . str_repeat("*", $strlen - 2) . $lastStr;
}

function getUserAllGroup(){
    global $_G;
    $groupterms = dunserialize(getuserprofile('groupterms'));
    foreach(explode("\t", $_G['member']['extgroupids']) as $extgroupid) {
        if($extgroupid = intval(trim($extgroupid))) {
            if($groupterms['ext'][$extgroupid] && $groupterms['ext'][$extgroupid] < TIMESTAMP){
                continue;
            }
            $groupidarray[] = $extgroupid;
        }
    }
    return $groupidarray;
}

function  _video_safe_replace($string) {
	$string = str_replace('%20','',$string);
	$string = str_replace('%27','',$string);
	$string = str_replace('%2527','',$string);
	$string = str_replace('*','',$string);
	$string = str_replace('"','&quot;',$string);
	$string = str_replace("'",'',$string);
	$string = str_replace('"','',$string);
	$string = str_replace(';','',$string);
	$string = str_replace('<','&lt;',$string);
	$string = str_replace('>','&gt;',$string);
	$string = str_replace("{",'',$string);
	$string = str_replace('}','',$string);
	$string = str_replace('\\','',$string);
	return $string;
}
function _video_editor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}