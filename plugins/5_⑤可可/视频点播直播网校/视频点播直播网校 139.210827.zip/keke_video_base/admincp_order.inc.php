<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
    global $_G;
    loadcache('plugin');
    $keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
	if($_GET['ac']=='replenish'){
		$orderid=dhtmlspecialchars($_GET['orderid']);
		$orderdata=C::t('#keke_video_base#keke_video_order')->fetchfirst_byid($orderid);
		if (submitcheck("submit_replenish")) {
			if($orderdata['state']){
				cpmsg(lang('plugin/keke_video_base', '399'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_order&page='.intval($_GET['page']), 'error');
			}
			uporderstate($orderid,6,$_GET['sn'].' '.lang('plugin/keke_video_base', '400'));
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_order&page='.intval($_GET['page']), 'succeed');
		}
		showtableheader(lang('plugin/keke_video_base', '394'));
		showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_order&ac=replenish', 'testhd');
		showtablerow('', array('width="70"'),
			array(
				'<b>'.lang('plugin/keke_video_base', '395').'</b>',
				'<a href="home.php?mod=space&uid='.$orderdata['uid'].'" target="_blank">'.$orderdata['username'].'</a>'
			)
		);
		showtablerow('', array('width="70"'),
			array(
				'<b>'.lang('plugin/keke_video_base', '396').'</b>',
				$orderdata['id']
			)
		);
		if($orderdata['credit']){
			$credit=unserialize($orderdata['credit']);
			$n=0;
			foreach($credit as $credit_type=>$credit_num){
				$creditnum.=($n==0 && $val['price']<=0?'':'<b>/</b>').$credit_num.' '.$_G['setting']['extcredits'][$credit_type]['title'];
				$n++;
			}
			$creditnum=' + '.$creditnum;
		}
		showtablerow('', array('width="70"'),
			array(
				'<b>'.lang('plugin/keke_video_base', '281').'</b>',
				($orderdata['price']>0?'&yen; '.$orderdata['price'].($orderdata['revision']?'<span class="revision"> '.lang('plugin/keke_video_base', '288').' </span>':''):'').$creditnum
			)
		);
		showtablerow('', array('width="70"'),
			array(
				'<b>'.lang('plugin/keke_video_base', '286').'</b>',
				date('Y-m-d H:i:s',$orderdata['time'])
			)
		);
		showsubtitle(array(''));
		showsetting(lang('plugin/keke_video_base', '397'),'sn','','text','','',lang('plugin/keke_video_base', '398'));
		echo '<input name="orderid" type="hidden" value="'.$orderid.'" />';
		showsubmit('submit_replenish', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit();
	}
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
			if($_GET['optype'] == 'delete') {
				C::t('#keke_video_base#keke_video_order')->delete($_GET['delete']);
			}
		}else{
			cpmsg(lang('plugin/keke_video_base', '176'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_order', 'error');
		}
		
		if(!$_GET['optype']){
			cpmsg(lang('plugin/keke_video_base', '057'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_order', 'error');
		}
		cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_order&page='.$_GET['page'], 'succeed');
	}
    $client = initVodClient(trim($keke_video_base['access_key_id']), trim($keke_video_base['access_key_secret']));
	$where="id NOT LIKE '%ALL%'";$param='';
	if($_GET['orderid']){
		$where="id='".daddslashes(dhtmlspecialchars($_GET['orderid'])).'\'';
		$param.='&orderid='.dhtmlspecialchars($_GET['orderid']);
	}
	if($_GET['state']){
		if($_GET['state']==9)$_GET['state']=0;
		$where.=" AND state=".intval($_GET['state']);
		$param.='&state='.intval($_GET['state']);
	}
	if($_GET['teacherid']){
		$where.=" AND teacher_uid=".intval($_GET['teacherid']);
		$param.='&teacherid='.intval($_GET['teacherid']);
	}
	if($_GET['byuid']){
		$where.=" AND uid=".intval($_GET['byuid']);
		$param.='&byuid='.intval($_GET['byuid']);
	}
	if($_GET['time']){
		$where.=" AND time>".strtotime($_GET['time']);
		$param.='&time='.dhtmlspecialchars($_GET['time']);
	}
	if($_GET['endtime']){
		$where.=" AND time<".strtotime($_GET['endtime']);
		$param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
	}
	if($_GET['types']){
		$where.=" AND price>0";
		$param.='&types='.intval($_GET['types']);
	}
	if($_GET['pagenum']){
		$param.='&pagenum='.intval($_GET['pagenum']);
	}
	
	$ppp=$_GET['pagenum']?intval($_GET['pagenum']):20;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_order'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if (submitcheck("exportsubmit")) {
		$order_data=C::t('#keke_video_base#keke_video_order')->fetch_all_order($startlimit,$ppp,$where,$order);
		$return[]=array(lang('plugin/keke_video_base', '395'),lang('plugin/keke_video_base', '396'),lang('plugin/keke_video_base', '281'),lang('plugin/keke_video_base', '282'),lang('plugin/keke_video_base', '283'),lang('plugin/keke_video_base', '284'),lang('plugin/keke_video_base', '273'),lang('plugin/keke_video_base', '469'),lang('plugin/keke_video_base', '286'),lang('plugin/keke_video_base', '468'));
		foreach($order_data as $k=>$v){
			$ss['usname']=$v['username'];
			$ss['orderid']=$v['id'];
			$ss['price']=$v['price'];
			$course='';
			if($v['buymod']==2){
				$chapters=C::t('#keke_video_base#keke_video_chapter')->fetch_first_by_cpid($v['cid']);
				$course='[ '.$chapters['title'].'] '.lang('plugin/keke_video_base', '419');
			}elseif($val['buymod']==3){
				$kes=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($v['cid']);
				$course='[ '.$kes['title'].'] '.lang('plugin/keke_video_base', '420');
			}else{
				$cids=explode(',',$v['cid']);	
				$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
				$num=1;
				foreach($courses as $ck=>$cv){
					$course.='[ '.$cv['title'].' ] ';
				}
			}
			if($v['credit']){
				$credit=unserialize($v['credit']);
				$n=0;
				foreach($credit as $credit_type=>$credit_num){
					$creditnum.=($n==0 && $v['price']<=0?'':'<b>/</b>').$credit_num.' '.$_G['setting']['extcredits'][$credit_type]['title'];
					$creditnums.=($n==0 && $v['price']<=0?'':(intval($credit_num*$val['take']/100)?'<b>/</b>':'')).(intval($credit_num*$val['take']/100)?intval($credit_num*$v['take']/100).' '.$_G['setting']['extcredits'][$credit_type]['title']:'');
					$n++;
				}
			}
			$ss['course']=$course;
			$ss['teacher_uid']=_getusname($v['teacher_uid']);
			$ss['cprice']=($v['state']==1)?(number_format($v['price']*$v['take']/100,2)>0?number_format($v['price']*$v['take']/100,2):'').$creditnums:'';
			$ss['state']=$v['state']==1?lang('plugin/keke_video_base', '270'):($v['state']==0?lang('plugin/keke_video_base', '271'):lang('plugin/keke_video_base', '272'));
			$ss['sn']=$v['sn'];
			$ss['time']=dgmdate($v['time'], 'Y/m/d H:i:s');
			if($v['deduction']){
				$deduction=unserialize($v['deduction']);
				$deductiontxt=lang('plugin/keke_video_base', '287').$deduction['info'];
			}
			$ss['deductiontxt']=$deductiontxt;
			$return[]=$ss;
		}
		exit(_video_get_csv($return));
	}
	

	showtableheader(lang('plugin/keke_video_base', '279'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_order', 'testhd');
	showtablerow('', array(),
		array(
			'<select name="state"><option value="0">'.lang('plugin/keke_video_base', '011').'</option><option value="1" '.($_GET['state']==1?'selected':'').'>'.lang('plugin/keke_video_base', '276').'</option><option value="9" '.($_GET['state']==9?'selected':'').'>'.lang('plugin/keke_video_base', '277').'</option><option value="3" '.($_GET['state']==3?'selected':'').'>'.lang('plugin/keke_video_base', '278').'</option></select>
			<input name="orderid" value="'.dhtmlspecialchars($_GET['orderid']).'" type="text" placeholder="'.lang('plugin/keke_video_base', '396').'" />
			<input name="byuid" type="text" value="'.($_GET['byuid']?intval($_GET['byuid']):'').'" size="10" placeholder="'.lang('plugin/keke_video_base', '296').'UID" />
			<input name="teacherid" type="text" size="10" value="'.($_GET['teacherid']?intval($_GET['teacherid']):'').'" placeholder="'.lang('plugin/keke_video_base', '092').'UID"/>
			<input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15" placeholder="'.lang('plugin/keke_video_base', '466').'"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'" placeholder="'.lang('plugin/keke_video_base', '467').'"/>
			<select name="types"><option value="0">'.lang('plugin/keke_video_base', '464').'</option><option value="1" '.($_GET['types']==1?'selected':'').'>'.lang('plugin/keke_video_base', '465').'</option></select>
			<select name="pagenum"><option value="20" '.($_GET['pagenum']==20?'selected':'').'>20</option><option value="50" '.($_GET['pagenum']==50?'selected':'').'>50</option><option value="100" '.($_GET['pagenum']==100?'selected':'').'>100</option><option value="500" '.($_GET['pagenum']==500?'selected':'').'>500</option><option value="1000" '.($_GET['pagenum']==1000?'selected':'').'>1000</option></select>
			<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '065').'">&nbsp;&nbsp;<input type="submit" class="btn" id="exportsubmit" name="exportsubmit" value="'.lang('plugin/keke_video_base', '461').'"><input name="inajax" type="hidden" value="1" /><script src="static/js/calendar.js"></script>'
		)
    );
	showformfooter(); /*Dism_taobao-com*/
	showtablefooter(); /*dism��taobao��com*/
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_order");	
	showtableheader(lang('plugin/keke_video_base', '279'));
    showsubtitle(array(lang('plugin/keke_video_base', '067'), lang('plugin/keke_video_base', '280'),lang('plugin/keke_video_base', '281'),lang('plugin/keke_video_base', '282'),lang('plugin/keke_video_base', '283'),lang('plugin/keke_video_base', '284'),lang('plugin/keke_video_base', '285'),lang('plugin/keke_video_base', '286'),lang('plugin/keke_video_base', '118')));
	
	$count_all=C::t('#keke_video_base#keke_video_order')->count_all($where);
	if($count_all){
		$order_data=C::t('#keke_video_base#keke_video_order')->fetch_all_order($startlimit,$ppp,$where,$order);
		foreach($order_data as $key=>$val){
			$state=$val['state']==1?'<img src="source/plugin/keke_video_base/template/images/ico016.png" width="11" height="11" />'.lang('plugin/keke_video_base', '270'):($val['state']==0?'<img src="source/plugin/keke_video_base/template/images/ico017.png" width="11" height="11" />'.lang('plugin/keke_video_base', '271'):'<img src="source/plugin/keke_video_base/template/images/ico011.png" width="11" height="11" />'.lang('plugin/keke_video_base', '272'));
			$cids=$course=$creditnum=$creditnums=$deductiontxt='';
			if($val['buymod']==2){
				$chapters=C::t('#keke_video_base#keke_video_chapter')->fetch_first_by_cpid($val['cid']);
				$course='<a href="plugin.php?id=keke_video_base&ac=course&cid='.$chapters['cid'].'" target="_blank">[ '.$chapters['title'].' ]</a><span class="modtip">'.lang('plugin/keke_video_base', '419').'</span><br/>';
			}elseif($val['buymod']==3){
				$kes=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($val['cid']);
				$course='<a href="plugin.php?id=keke_video_base&ac=course&cid='.$kes['cid'].'" target="_blank">[ '.$kes['title'].' ]</a><span class="modtip">'.lang('plugin/keke_video_base', '420').'</span><br/>';
			}else{
				$cids=explode(',',$val['cid']);	
				$courses=C::t('#keke_video_base#keke_video_course')->fetch_all_by_cids($cids);
				$num=1;
				foreach($courses as $ck=>$cv){
					$course.='<a href="plugin.php?id=keke_video_base&ac=course&cid='.$cv['id'].'" target="_blank"><!--<span class="numbox">'.$num.'</span> - -->[ '.$cv['title'].' ]</a><br/>';
					$num++;
				}
			}
			if($val['credit']){
				$credit=unserialize($val['credit']);
				$n=0;
				foreach($credit as $credit_type=>$credit_num){
					$creditnum.=($n==0 && $val['price']<=0?'':'<b>/</b>').$credit_num.' '.$_G['setting']['extcredits'][$credit_type]['title'];
					$creditnums.=($n==0 && $val['price']<=0?'':(intval($credit_num*$val['take']/100)?'<b>/</b>':'')).(intval($credit_num*$val['take']/100)?intval($credit_num*$val['take']/100).' '.$_G['setting']['extcredits'][$credit_type]['title']:'');
					$n++;
				}
			}
			if($val['deduction']){
				$deduction=unserialize($val['deduction']);
				$deductiontxt='<span class="deduction">'.lang('plugin/keke_video_base', '287').$deduction['info'].'</span>';
			}
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = '<div class="payusername"><a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'.$val['username'].'</a></div>'.$val['id'];
			$table[2] = '<div class="pricebox">'.($val['price']>0?'&yen; '.$val['price'].($val['revision']?'<span class="revision">'.lang('plugin/keke_video_base', '288').'</span>':''):'').$creditnum.'</div>'.$deductiontxt;
			$table[3] = '<div class="course">'.$course.'</div>';
			$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_order&teacherid='.$val['teacher_uid'].'">'._getusname($val['teacher_uid']).'</a>';
			$table[5] = ($val['state']==1)?'<div class="pricebox">'.(number_format($val['price']*$val['take']/100,2)>0?'&yen; '.number_format($val['price']*$val['take']/100,2):'').$creditnums.'</div>':'';
			$table[6] = '<div class="states">'.$state.'</div>'.($val['sn']?'<span class="snbox">'.$val['sn'].'</span>':'');
			$table[7] = dgmdate($val['time'], 'Y/m/d H:i');
			
			$table[8] = ($val['state']==0)?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_order&ac=replenish&orderid='.$val['id'].'&page='.intval($_GET['page']).'">'.lang('plugin/keke_video_base', '394').'</a>':'-';
			showtablerow('',array(''), $table);
		}
		$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	}
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	echo '<input type="hidden" name="page" value="'.intval($_GET['page']).'"><style>.states img{vertical-align:middle; margin-right:7px;}.video-image .video-image-background {background-position: 50%;background-repeat: no-repeat;background-size: contain;width: 100%;height: 100%;}.course a{ color:#666; margin:7px 10px 10px 0; line-height:28px;}.pricebox{ color:#c30; margin:7px 10px 0px 0; line-height:20px;}.pricebox b{ color:#CCC; margin:0 5px; font-weight:400}.revision{ margin:0 5px; background:#ff5959;display:inline-block; color:#FFF;padding:0px 2px;font-size:12px; line-height: 16px;}.deduction{line-height: 23px; margin-top: 2px;color: #666;margin-bottom: 10px;display: inline-block;}.snbox{ margin-top: 8px;color: #999;margin-bottom: 10px;display: inline-block;}.payusername{ margin-bottom: 5px;}.numbox{border: 1px solid #ababab;background: #fff;color: #585858;padding: 0 2px;}.modtip{    background: #fff;font-size: 12px !important;margin: 0px;border: 1px solid #ff7272;display: inline-block;color: #ff7272;height: 15px;line-height: 15px;padding: 0 5px;}</style>';
	showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'delete\')"><label for="chkallIuPN">'.lang('plugin/keke_video_base', '067').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_video_base', '135').'</label>&nbsp;&nbsp;','');
    showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/