<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
    global $_G;
	loadcache('plugin');
	include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
	if(!$_G['uid']) {
		cpmsg('Please Login');
	}
	$allcatedata=_get_allcatedata();
$_GET['op']=$_GET['op']?$_GET['op']:'seo';
_showadminsubmenu(array(
	array(lang('plugin/keke_video_base', '262'), "seo"),
	array('PC'.lang('plugin/keke_video_base', '221'), "index_slider"),
    array(lang('plugin/keke_video_base', '416'), "pc_nav"),
    array(lang('plugin/keke_video_base', '226'), "pc_listbanner"),
	array(lang('plugin/keke_video_base', '222'), "mobile_slider"),
	array(lang('plugin/keke_video_base', '223'), "before_play_ad"),
	array(lang('plugin/keke_video_base', '224'), "mobile_nav"),
	array(lang('plugin/keke_video_base', '225'), "mobile_discover"),
	array(lang('plugin/keke_video_base', '313'), "ban_video"),
	array(lang('plugin/keke_video_base', '418'), "bigshot_teacher"),
	array(lang('plugin/keke_video_base', '424'), "msg"),
	array(lang('plugin/keke_video_base', '470'), "oss"),
),'admincp_set');
if ($_GET['op'] == 'index_slider') {
	$slider=_get_cache('slider');
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
			C::t('#keke_video_base#keke_video_slider')->delete($_GET['delete']);
			_save_cache('slider');
		}
		cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_set&op=index_slider', 'succeed');
	}
	if($_GET['ac']=='editpic'){
		if (!submitcheck("editsubmit")) {
			if($_GET['keyid']){
				$keyid=intval($_GET['keyid']);
				$dataarr=$slider[$keyid];
			}
			showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=index_slider&ac=editpic", 'enctype');
			showtableheader(lang('plugin/keke_video_base', '227'));
			showsetting(lang('plugin/keke_video_base', '228'),'spic',$dataarr['img'],'filetext');
			showsetting(lang('plugin/keke_video_base', '229'),'url',$dataarr['url'],'text');
			showsetting(lang('plugin/keke_video_base', '087'),'displayorder',$dataarr['displayorder'],'text');
			echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
			showsubmit('editsubmit', 'submit', '');
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			exit;
		}else{
			$picurl=_upload_img($_FILES['spic'],'',300);
			$pic=$picurl ? $picurl : $_GET['spic'];
			if(!$pic){
				cpmsg(lang('plugin/keke_video_base', '230'), '', 'error');
			}
			$arr=array(
				'id'=>intval($_GET['keyid']),
				'img'=> $pic,
				'url'=> $_GET['url'],
				'type'=>1,
				'displayorder'=> $_GET['displayorder'],
			);
			C::t('#keke_video_base#keke_video_slider')->insert($arr,false,true);
			_save_cache('slider');
			cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=index_slider', 'succeed');
		
		}
	}
	showtips('<li>'.lang('plugin/keke_video_base', '231').'</li><li>'.lang('plugin/keke_video_base', '232').'</li>');
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=index_slider", 'enctype');
	showtableheader('header');
	showsubtitle(array('del',lang('plugin/keke_video_base', '228'),lang('plugin/keke_video_base', '229'),lang('plugin/keke_video_base', '209'),lang('plugin/keke_video_base', '118')));
	
	foreach($slider as $slider_data){
		if($slider_data['type']==1){
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
			$table[1] = '<img src="'.$slider_data['img'].'" width="180" />';
			$table[2] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
			$table[3] = $slider_data['displayorder'];
			$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=index_slider&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_video_base', '170').'</a>';
			showtablerow('',array(), $table);
		}
	}
	showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=index_slider&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_video_base', '233').'</a>');
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/
} else if ($_GET['op'] == 'mobile_slider') {
		$slider=_get_cache('slider');
		if (submitcheck("forumset")) {
			if(is_array($_GET['delete'])) {
					C::t('#keke_video_base#keke_video_slider')->delete($_GET['delete']);
					_save_cache('slider');
			}
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_set&op=mobile_slider', 'succeed');
		}
		if($_GET['ac']=='editpic'){
			if (!submitcheck("editsubmit")) {
				if($_GET['keyid']){
					$keyid=intval($_GET['keyid']);
					$dataarr=$slider[$keyid];
				}
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=mobile_slider&ac=editpic", 'enctype');
				showtableheader(lang('plugin/keke_video_base', '227'));
				showsetting(lang('plugin/keke_video_base', '228'),'spic',$dataarr['img'],'filetext');
				showsetting(lang('plugin/keke_video_base', '229'),'url',$dataarr['url'],'text');
				showsetting(lang('plugin/keke_video_base', '209'),'displayorder',$dataarr['displayorder'],'text');
				echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); /*dism��taobao��com*/
				showformfooter(); /*Dism_taobao-com*/
				exit;
			}else{
				$picurl=_upload_img($_FILES['spic'],1200,432);
				$pic=$picurl ? $picurl : $_GET['spic'];
				if(!$pic){
					cpmsg(lang('plugin/keke_video_base', '230'), '', 'error');
				}
				$arr=array(
					'id'=>intval($_GET['keyid']),
					'img'=> $pic,
					'url'=> $_GET['url'],
					'type'=>2,
					'displayorder'=> $_GET['displayorder'],
				);
				C::t('#keke_video_base#keke_video_slider')->insert($arr,false,true);
				_save_cache('slider');
				cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_slider', 'succeed');
			
			}
		}
		showtips('<li>'.lang('plugin/keke_video_base', '231').'</li><li>'.lang('plugin/keke_video_base', '234').'</li>');
	
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_slider", 'enctype');
		showtableheader('header');
		showsubtitle(array('del',lang('plugin/keke_video_base', '228'),lang('plugin/keke_video_base', '229'),lang('plugin/keke_video_base', '209'),lang('plugin/keke_video_base', '118')));
		
		foreach($slider as $slider_data){
			if($slider_data['type']==2){
				$table = array();
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
				$table[1] = '<img src="'.$slider_data['img'].'" width="180" />';
				$table[2] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
				$table[3] = $slider_data['displayorder'];
				$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_slider&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_video_base', '170').'</a>';
				showtablerow('',array(), $table);
			}
		}
		showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_slider&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_video_base', '233').'</a>');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
}elseif ($_GET['op'] == 'mobile_nav') {
		$slider=_get_cache('slider');
		$all_set=_get_set();
		if (submitcheck("forumset")) {
			if(is_array($_GET['delete'])) {
					C::t('#keke_video_base#keke_video_slider')->delete($_GET['delete']);
					_save_cache('slider');
			}
			cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_set&op=mobile_nav', 'succeed');
		}
		if (submitcheck("forumsets")) {
			$arr=array(
				'rownum'=>intval($_GET['rownum']),
				'mobilenavrows'=>intval($_GET['mobilenavrows']),
			);
			_insert_set($arr);
			cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_set&op=mobile_nav', 'succeed');
		}
		if($_GET['ac']=='editpic'){
			if (!submitcheck("editsubmit")) {
				if($_GET['keyid']){
					$keyid=intval($_GET['keyid']);
					$dataarr=$slider[$keyid];
				}
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=mobile_nav&ac=editpic", 'enctype');
				showtableheader(lang('plugin/keke_video_base', '235'));
				showsetting(lang('plugin/keke_video_base', '162'),'title',$dataarr['title'],'text');
				showsetting(lang('plugin/keke_video_base', '228'),'spic',$dataarr['img'],'filetext');
				showsetting(lang('plugin/keke_video_base', '229'),'url',$dataarr['url'],'text');
				showsetting(lang('plugin/keke_video_base', '209'),'displayorder',$dataarr['displayorder'],'text');
				echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); /*dism��taobao��com*/
				showformfooter(); /*Dism_taobao-com*/
				exit;
			}else{
				$picurl=_upload_img($_FILES['spic'],220,220);
				$pic=$picurl ? $picurl : $_GET['spic'];
				if(!$pic){
					cpmsg(lang('plugin/keke_video_base', '230'), '', 'error');
				}
				$arr=array(
					'id'=>intval($_GET['keyid']),
					'title'=> $_GET['title'],
					'img'=> $pic,
					'url'=> $_GET['url'],
					'type'=>3,
					'displayorder'=> $_GET['displayorder'],
				);
				C::t('#keke_video_base#keke_video_slider')->insert($arr,false,true);
				_save_cache('slider');
				cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_nav', 'succeed');
			
			}
		}
		showtips('<li>'.lang('plugin/keke_video_base', '236').'</li>');
	
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_nav", 'enctype');
		showtableheader(lang('plugin/keke_video_base', '358'));
		showsetting(lang('plugin/keke_video_base', '359'),array('rownum',array(array('4','4'.lang('plugin/keke_video_base', '360')),array('5','5'.lang('plugin/keke_video_base', '360')))),($all_set['rownum']?$all_set['rownum']:4),'select');
		showsetting(lang('plugin/keke_video_base', '361'),'mobilenavrows',($all_set['mobilenavrows']?$all_set['mobilenavrows']:2),'text');
		showsubmit('forumsets', 'submit');
		showtableheader(lang('plugin/keke_video_base', '357'));
		showsubtitle(array('del',lang('plugin/keke_video_base', '237'),lang('plugin/keke_video_base', '228'),lang('plugin/keke_video_base', '229'),lang('plugin/keke_video_base', '209'),lang('plugin/keke_video_base', '118')));
		
		foreach($slider as $slider_data){
			if($slider_data['type']==3){
				$table = array();
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
				$table[1] = $slider_data['title'];
				$table[2] = '<img src="'.$slider_data['img'].'" width="50" />';
				$table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
				$table[4] = $slider_data['displayorder'];
				$table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_nav&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_video_base', '170').'</a>';
				showtablerow('',array(), $table);
			}
		}
		showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_nav&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_video_base', '233').'</a>');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		
		
}elseif ($_GET['op'] == 'pc_nav') {
		$slider=_get_cache('slider');
		$all_set=_get_set();
		if (submitcheck("forumset")) {
			if(is_array($_GET['delete'])) {
					C::t('#keke_video_base#keke_video_slider')->delete($_GET['delete']);
					_save_cache('slider');
			}
			cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_set&op=pc_nav', 'succeed');
		}
		if (submitcheck("forumsets")) {
			$arr=array(
				'rownum'=>intval($_GET['rownum']),
				'mobilenavrows'=>intval($_GET['mobilenavrows']),
			);
			_insert_set($arr);
			cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_set&op=pc_nav', 'succeed');
		}
		if($_GET['ac']=='editpic'){
			if (!submitcheck("editsubmit")) {
				if($_GET['keyid']){
					$keyid=intval($_GET['keyid']);
					$dataarr=$slider[$keyid];
				}
				$dataarr['title']=explode('||',$dataarr['title']);
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=pc_nav&ac=editpic", 'enctype');
				showtableheader(lang('plugin/keke_video_base', '235'));
				showsetting(lang('plugin/keke_video_base', '185'),'title',$dataarr['title'][0],'text');
				showsetting(lang('plugin/keke_video_base', '417'),'dec',$dataarr['title'][1],'text');
				showsetting(lang('plugin/keke_video_base', '228'),'spic',$dataarr['img'],'filetext');
				showsetting(lang('plugin/keke_video_base', '229'),'url',$dataarr['url'],'text');
				showsetting(lang('plugin/keke_video_base', '209'),'displayorder',$dataarr['displayorder'],'text');
				echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); /*dism��taobao��com*/
				showformfooter(); /*Dism_taobao-com*/
				exit;
			}else{
				$picurl=_upload_img($_FILES['spic'],220,220);
				$pic=$picurl ? $picurl : $_GET['spic'];
				if(!$pic){
					cpmsg(lang('plugin/keke_video_base', '230'), '', 'error');
				}
				$title=$_GET['title'].'||'.$_GET['dec'];
				$arr=array(
					'id'=>intval($_GET['keyid']),
					'title'=> $title,
					'img'=> $pic,
					'url'=> $_GET['url'],
					'type'=>5,
					'displayorder'=> $_GET['displayorder'],
				);
				C::t('#keke_video_base#keke_video_slider')->insert($arr,false,true);
				_save_cache('slider');
				cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=pc_nav', 'succeed');
			
			}
		}
		showtips('<li>'.lang('plugin/keke_video_base', '236').'</li>');
	
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=pc_nav", 'enctype');
	
		showtableheader(lang('plugin/keke_video_base', '357'));
		showsubtitle(array('del',lang('plugin/keke_video_base', '228'),lang('plugin/keke_video_base', '237'),lang('plugin/keke_video_base', '229'),lang('plugin/keke_video_base', '209'),lang('plugin/keke_video_base', '118')));
		
		foreach($slider as $slider_data){
			if($slider_data['type']==5){
				$table = array();
				$slider_data['title']=explode('||',$slider_data['title']);
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
				$table[1] = '<img src="'.$slider_data['img'].'" width="50" />';
				$table[2] = '<b>'.$slider_data['title'][0].'</b><div class="dectxt">'.$slider_data['title'][1].'</div>';
				$table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
				$table[4] = $slider_data['displayorder'];
				$table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=pc_nav&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_video_base', '170').'</a>';
				showtablerow('',array(), $table);
			}
		}
		showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=pc_nav&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_video_base', '233').'</a><style>.dectxt{color:#999; margin-top:5px}</style>');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
				

}elseif ($_GET['op'] == 'bigshot_teacher') {
		$slider=_get_cache('slider');
		$all_set=_get_set();
		if (submitcheck("forumset")) {
			if(is_array($_GET['delete'])) {
					C::t('#keke_video_base#keke_video_slider')->delete($_GET['delete']);
					_save_cache('slider');
			}
			cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_set&op=bigshot_teacher', 'succeed');
		}
		if (submitcheck("forumsets")) {
			$arr=array(
				'rownum'=>intval($_GET['rownum']),
				'mobilenavrows'=>intval($_GET['mobilenavrows']),
			);
			_insert_set($arr);
			cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_set&op=bigshot_teacher', 'succeed');
		}
		if($_GET['ac']=='editpic'){
			if (!submitcheck("editsubmit")) {
				if($_GET['keyid']){
					$keyid=intval($_GET['keyid']);
					$dataarr=$slider[$keyid];
				}
				$dataarr['title']=explode('||',$dataarr['title']);
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=bigshot_teacher&ac=editpic", 'enctype');
				showtableheader(lang('plugin/keke_video_base', '235'));
				showsetting(lang('plugin/keke_video_base', '185'),'title',$dataarr['title'][0],'text');
				showsetting(lang('plugin/keke_video_base', '417'),'dec',$dataarr['title'][1],'text');
				showsetting(lang('plugin/keke_video_base', '228'),'spic',$dataarr['img'],'filetext');
				showsetting(lang('plugin/keke_video_base', '229'),'url',$dataarr['url'],'text');
				showsetting(lang('plugin/keke_video_base', '209'),'displayorder',$dataarr['displayorder'],'text');
				echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); /*dism��taobao��com*/
				showformfooter(); /*Dism_taobao-com*/
				exit;
			}else{
				$picurl=_upload_img($_FILES['spic'],183,183);
				$pic=$picurl ? $picurl : $_GET['spic'];
				if(!$pic){
					cpmsg(lang('plugin/keke_video_base', '230'), '', 'error');
				}
				$title=$_GET['title'].'||'.$_GET['dec'];
				$arr=array(
					'id'=>intval($_GET['keyid']),
					'title'=> $title,
					'img'=> $pic,
					'url'=> $_GET['url'],
					'type'=>6,
					'displayorder'=> $_GET['displayorder'],
				);
				C::t('#keke_video_base#keke_video_slider')->insert($arr,false,true);
				_save_cache('slider');
				cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=bigshot_teacher', 'succeed');
			
			}
		}
		showtips('<li>'.lang('plugin/keke_video_base', '236').'</li>');
	
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=bigshot_teacher", 'enctype');
	
		showtableheader(lang('plugin/keke_video_base', '357'));
		showsubtitle(array('del',lang('plugin/keke_video_base', '228'),lang('plugin/keke_video_base', '237'),lang('plugin/keke_video_base', '229'),lang('plugin/keke_video_base', '209'),lang('plugin/keke_video_base', '118')));
		
		foreach($slider as $slider_data){
			if($slider_data['type']==6){
				$table = array();
				$slider_data['title']=explode('||',$slider_data['title']);
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
				$table[1] = '<img src="'.$slider_data['img'].'" width="50" />';
				$table[2] = '<b>'.$slider_data['title'][0].'</b><div class="dectxt">'.$slider_data['title'][1].'</div>';
				$table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
				$table[4] = $slider_data['displayorder'];
				$table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=bigshot_teacher&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_video_base', '170').'</a>';
				showtablerow('',array(), $table);
			}
		}
		showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=bigshot_teacher&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_video_base', '233').'</a><style>.dectxt{color:#999; margin-top:5px}</style>');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		
}elseif ($_GET['op'] == 'mobile_discover') {
		$slider=_get_cache('slider');
		if (submitcheck("forumset")) {
			if(is_array($_GET['delete'])) {
					C::t('#keke_video_base#keke_video_slider')->delete($_GET['delete']);
					_save_cache('slider');
			}
			cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_set&op=mobile_discover', 'succeed');
		}
		if($_GET['ac']=='editpic'){
			if (!submitcheck("editsubmit")) {
				if($_GET['keyid']){
					$keyid=intval($_GET['keyid']);
					$dataarr=$slider[$keyid];
				}
				showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=mobile_discover&ac=editpic", 'enctype');
				showtableheader(lang('plugin/keke_video_base', '235'));
				showsetting(lang('plugin/keke_video_base', '162'),'title',$dataarr['title'],'text');
				showsetting(lang('plugin/keke_video_base', '228'),'spic',$dataarr['img'],'filetext');
				showsetting(lang('plugin/keke_video_base', '229'),'url',$dataarr['url'],'text');
				showsetting(lang('plugin/keke_video_base', '209'),'displayorder',$dataarr['displayorder'],'text');
				echo '<input name="keyid" type="hidden" value="'.$keyid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); /*dism��taobao��com*/
				showformfooter(); /*Dism_taobao-com*/
				exit;
			}else{
				$picurl=_upload_img($_FILES['spic'],120,120);
				$pic=$picurl ? $picurl : $_GET['spic'];
				if(!$pic){
					cpmsg(lang('plugin/keke_video_base', '230'), '', 'error');
				}
				$arr=array(
					'id'=>intval($_GET['keyid']),
					'title'=> $_GET['title'],
					'img'=> $pic,
					'url'=> $_GET['url'],
					'type'=>4,
					'displayorder'=> $_GET['displayorder'],
				);
				C::t('#keke_video_base#keke_video_slider')->insert($arr,false,true);
				_save_cache('slider');
				cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=mobile_discover', 'succeed');
			
			}
		}
		showtips('<li>'.lang('plugin/keke_video_base', '236').'</li>');
	
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&ac=editpic&op=mobile_discover", 'enctype');
		showtableheader('header');
		showsubtitle(array('del',lang('plugin/keke_video_base', '237'),lang('plugin/keke_video_base', '228'),lang('plugin/keke_video_base', '229'),lang('plugin/keke_video_base', '209'),lang('plugin/keke_video_base', '118')));
		
		foreach($slider as $slider_data){
			if($slider_data['type']==4){
				$table = array();
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$slider_data['id'].'" />';
				$table[1] = $slider_data['title'];
				$table[2] = '<img src="'.$slider_data['img'].'" width="50" />';
				$table[3] = '<a href="'.$slider_data['url'].'"/>'.$slider_data['url'].'</a>';
				$table[4] = $slider_data['displayorder'];
				$table[5] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_discover&keyid='.$slider_data['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_video_base', '170').'</a>';
				showtablerow('',array(), $table);
			}
		}
		showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier='.$plugin["identifier"].'&pmod=admincp_set&ac=editpic&op=mobile_discover&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_video_base', '233').'</a>');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		
}elseif ($_GET['op'] == 'before_play_ad') {
	$all_set=_get_set();
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=before_play_ad&ac=editpic", 'enctype');
        showtips(lang('plugin/keke_video_base', '561'));
		showtableheader(lang('plugin/keke_video_base', '560'));
		showsetting(lang('plugin/keke_video_base', '562'),'videoad',$all_set['before_play_ad_videoad'],'textarea','','',lang('plugin/keke_video_base', '563'));
        showsetting(lang('plugin/keke_video_base', '565'),array('ad_close',array(array('1',lang('plugin/keke_video_base', '566')),array('2',lang('plugin/keke_video_base', '567')))),$all_set['before_play_ad_close'],'select');
        showtableheader(lang('plugin/keke_video_base', '238'));
        showsetting(lang('plugin/keke_video_base', '228'),'spic',$all_set['before_play_ad'],'filetext');
        showsetting(lang('plugin/keke_video_base', '229'),'url',$all_set['before_play_ad_url'],'text');
        showsetting(lang('plugin/keke_video_base', '239'),'time',$all_set['before_play_ad_time'],'text','','',lang('plugin/keke_video_base', '240'));
        showtableheader(lang('plugin/keke_video_base', '559'));
        showsetting(lang('plugin/keke_video_base', '564'),array('ad_type',array(array('1',lang('plugin/keke_video_base', '560')),array('2',lang('plugin/keke_video_base', '238')))),$all_set['before_play_ad_type'],'select');
		showsetting(lang('plugin/keke_video_base', '241'),'exemptcid',$all_set['before_play_ad_exemptcid'],'text','','',lang('plugin/keke_video_base', '243'));
		showsetting(lang('plugin/keke_video_base', '242'),'exemptgid',$all_set['before_play_ad_exemptgid'],'text','','',lang('plugin/keke_video_base', '244'));
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
	}else{
		$picurl=_upload_img($_FILES['spic'],1920,1080);
		$pic=$picurl ? $picurl : $_GET['spic'];
		$arr=array(
			'before_play_ad'=>$pic,
			'before_play_ad_url'=> $_GET['url'],
			'before_play_ad_time'=>$_GET['time'],
			'before_play_ad_exemptcid'=>$_GET['exemptcid'],
			'before_play_ad_exemptgid'=>$_GET['exemptgid'],
            'before_play_ad_videoad'=>$_GET['videoad'],
            'before_play_ad_type'=>$_GET['ad_type'],
            'before_play_ad_close'=>$_GET['ad_close']
		);
		_insert_set($arr);
		cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=before_play_ad', 'succeed');
	
	}

}elseif ($_GET['op'] == 'pc_listbanner') {
	
	$all_set=_get_set();
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=pc_listbanner", 'enctype');
		showtableheader(lang('plugin/keke_video_base', '245'));
		showsetting(lang('plugin/keke_video_base', '228'),'spic',$all_set['pc_listbanner'],'filetext');
		showsetting(lang('plugin/keke_video_base', '229'),'url',$all_set['pc_listbanner_url'],'text');
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
	}else{
		$picurl=_upload_img($_FILES['spic'],1920,100);
		$pic=$picurl ? $picurl : $_GET['spic'];
		if(!$pic){
			cpmsg(lang('plugin/keke_video_base', '230'), '', 'error');
		}
		$arr=array(
			'pc_listbanner'=>$pic,
			'pc_listbanner_url'=> $_GET['url'],
			
		);
		_insert_set($arr);
		cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=pc_listbanner', 'succeed');
	
	}
} else if ($_GET['op'] == 'seo') {
	$all_set=_get_set();
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=seo", '');
		showtableheader(lang('plugin/keke_video_base', '263'));
		showsetting('title','index_title',$all_set['index_title'],'text');
		showsetting('keywords','index_keywords',$all_set['index_keywords'],'text');
		showsetting('description','index_description',$all_set['index_description'],'textarea');
		showtableheader(lang('plugin/keke_video_base', '264'));
		showsetting(lang('plugin/keke_video_base', '269'),'list_index_title',$all_set['list_index_title'],'text');
		showsetting('title','list_title',$all_set['list_title'],'text','','',lang('plugin/keke_video_base', '266'));
		showsetting('keywords','list_keywords',$all_set['list_keywords'],'text','','',lang('plugin/keke_video_base', '266'));
		showsetting('description','list_description',$all_set['list_description'],'textarea');
		showtableheader(lang('plugin/keke_video_base', '265'));
		showsetting('title','course_title',$all_set['course_title'],'text','','',lang('plugin/keke_video_base', '267'));
		showsetting('keywords','course_keywords',$all_set['course_keywords'],'text','','',lang('plugin/keke_video_base', '267'));
		showsetting('description','course_description',$all_set['course_description'],'textarea','','',lang('plugin/keke_video_base', '268'));
		showtableheader(lang('plugin/keke_video_base', '289'));
		showsetting('title','teacher_title',$all_set['teacher_title'],'text','','',lang('plugin/keke_video_base', '290'));
		showsetting('keywords','teacher_keywords',$all_set['teacher_keywords'],'text','','',lang('plugin/keke_video_base', '290'));
		showsetting('description','teacher_description',$all_set['teacher_description'],'textarea','','',lang('plugin/keke_video_base', '290'));
		
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
	}else{
		$arr=array(
			'index_title'=>$_GET['index_title'],
			'index_keywords'=>$_GET['index_keywords'],
			'index_description'=>$_GET['index_description'],
			'list_title'=>$_GET['list_title'],
			'list_index_title'=>$_GET['list_index_title'],
			'list_keywords'=>$_GET['list_keywords'],
			'list_description'=>$_GET['list_description'],
			'course_title'=>$_GET['course_title'],
			'course_keywords'=>$_GET['course_keywords'],
			'course_description'=>$_GET['course_description'],
			'teacher_title'=>$_GET['teacher_title'],
			'teacher_keywords'=>$_GET['teacher_keywords'],
			'teacher_description'=>$_GET['teacher_description'],
		);
		_insert_set($arr);
		cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=seo', 'succeed');
	
	}
}elseif ($_GET['op'] == 'ban_video') {
	$all_set=_get_set();
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=ban_video&ac=editpic", 'enctype');
		showtableheader(lang('plugin/keke_video_base', '314'));
		showsetting(lang('plugin/keke_video_base', '316'),'banwinon',$all_set['ban_video_on']);
		showsetting(lang('plugin/keke_video_base', '228'),'ssspic',$all_set['ban_video_ad'],'filetext');
		showsetting(lang('plugin/keke_video_base', '229'),'url',$all_set['ban_video_ad_url'],'text','','',lang('plugin/keke_video_base', '318'));
		showsetting(lang('plugin/keke_video_base', '315'),'time',$all_set['ban_video_ad_time'],'text','','',lang('plugin/keke_video_base', '317'));
		showsetting(lang('plugin/keke_video_base', '241'),'exemptcid',$all_set['ban_video_ad_exemptcid'],'text','','',lang('plugin/keke_video_base', '243'));
		showsetting(lang('plugin/keke_video_base', '242'),'exemptgid',$all_set['ban_video_ad_exemptgid'],'text','','',lang('plugin/keke_video_base', '244'));
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
	}else{
		$picurl=_upload_img($_FILES['ssspic'],1300,800);
		$pic=$picurl ? $picurl : $_GET['ssspic'];
		$arr=array(
			'ban_video_on'=>$_GET['banwinon'],
			'ban_video_ad'=>$pic,
			'ban_video_ad_url'=> $_GET['url'],
			'ban_video_ad_time'=>$_GET['time'],
			'ban_video_ad_exemptcid'=>$_GET['exemptcid'],
			'ban_video_ad_exemptgid'=>$_GET['exemptgid']
		);
		_insert_set($arr);
		cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=ban_video', 'succeed');
	
	}
}elseif ($_GET['op'] == 'oss') {	
	$all_set=_get_set();
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=oss", 'enctype');
		showtips(lang('plugin/keke_video_base', '471'));
		showtableheader(lang('plugin/keke_video_base', '472'));
		showsetting(lang('plugin/keke_video_base', '473'),'oss_on',$all_set['oss_on']);
		showsetting('Access Key ID','oss_keyid',$all_set['oss_keyid'],'text');
		showsetting('Access Key Secret','oss_keysecret',$all_set['oss_keysecret'],'text');
		showsetting('Bucket'.lang('plugin/keke_video_base', '237'),'oss_bucket',$all_set['oss_bucket'],'text');
		showsetting('EndPoint','oss_endPoint',$all_set['oss_endPoint'],'text');
		showsetting(lang('plugin/keke_video_base', '475'),'oss_url',$all_set['oss_url'],'text','','',lang('plugin/keke_video_base', '476'));
		showsetting(lang('plugin/keke_video_base', '521'),'oss_alc',$all_set['oss_alc'],'radio','','',lang('plugin/keke_video_base', '522'));
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
	}else{
		$arr=array(
			'oss_on'=>$_GET['oss_on'],
			'oss_keyid'=>$_GET['oss_keyid'],
			'oss_keysecret'=> $_GET['oss_keysecret'],
			'oss_bucket'=>$_GET['oss_bucket'],
			'oss_endPoint'=>$_GET['oss_endPoint'],
			'oss_url'=>$_GET['oss_url'],
			'oss_alc'=>$_GET['oss_alc'],
		);
		_insert_set($arr);
		cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=oss', 'succeed');
	}
}elseif ($_GET['op'] == 'msg') {
	$all_set=_get_set();
	if (submitcheck("editsubmit")) {
		foreach($_GET as $key=>$val){
			if(strpos($key, "msg_") !== false)$insertarr[$key]=$val;
		} 
		_insert_set($insertarr);
		cpmsg(lang('plugin/keke_video_base', '137'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_set&op=msg', 'succeed');	
	}elseif (submitcheck("testsubmit")) {
		_video_send_notice(array(1),'msg_admin_setin',$para=array('tset'=>1));
		exit;	
	}
		
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_set&op=msg&ac=editpic", 'enctype');
	showtableheader(lang('plugin/keke_video_base', '424'));
	showsetting(lang('plugin/keke_video_base', '425'),'msg_off',$all_set['msg_off'],'radio','','',lang('plugin/keke_video_base', '426'));
	showsetting(lang('plugin/keke_video_base', '427').'UID','msg_adminuids',$all_set['msg_adminuids'],'text','','',lang('plugin/keke_video_base', '428'));
	showsetting(lang('plugin/keke_video_base', '429'),'msg_qrcode',$all_set['msg_qrcode'],'text','','',lang('plugin/keke_video_base', '430'));
	showsubmit('editsubmit', 'submit', '');
	
	showtableheader(lang('plugin/keke_video_base', '431'));
	
	showsubtitle(array('<span class="coloura">'.lang('plugin/keke_video_base', '432').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_stu_updata',$all_set['msg_stu_updata'],'textarea','','',lang('plugin/keke_video_base', '433'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_stu_updata_id',$all_set['msg_stu_updata_id'],'text','','','');
	
	showsubtitle(array('<span class="coloura">'.lang('plugin/keke_video_base', '436').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_stu_buy',$all_set['msg_stu_buy'],'textarea','','',lang('plugin/keke_video_base', '437'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_stu_buy_id',$all_set['msg_stu_buy_id'],'text','','','');
	
	showsubtitle(array('<span class="coloura">'.lang('plugin/keke_video_base', '438').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_stu_ans',$all_set['msg_stu_ans'],'textarea','','',lang('plugin/keke_video_base', '439'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_stu_ans_id',$all_set['msg_stu_ans_id'],'text','','','');
	
	showsubtitle(array('<span class="colourb">'.lang('plugin/keke_video_base', '440').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_teacher_sell',$all_set['msg_teacher_sell'],'textarea','','',lang('plugin/keke_video_base', '441'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_teacher_sell_id',$all_set['msg_teacher_sell_id'],'text','','','');
	
	showsubtitle(array('<span class="colourb">'.lang('plugin/keke_video_base', '442').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_teacher_cashout',$all_set['msg_teacher_cashout'],'textarea','','',lang('plugin/keke_video_base', '443'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_teacher_cashout_id',$all_set['msg_teacher_cashout_id'],'text','','','');
	
	showsubtitle(array('<span class="colourb">'.lang('plugin/keke_video_base', '444').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_teacher_ans',$all_set['msg_teacher_ans'],'textarea','','',lang('plugin/keke_video_base', '445'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_teacher_ans_id',$all_set['msg_teacher_ans_id'],'text','','','');
	
	showsubtitle(array('<span class="colourb">'.lang('plugin/keke_video_base', '446').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_teacher_media',$all_set['msg_teacher_media'],'textarea','','',lang('plugin/keke_video_base', '443'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_teacher_media_id',$all_set['msg_teacher_media_id'],'text','','','');
	
	showsubtitle(array('<span class="colourc">'.lang('plugin/keke_video_base', '447').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_admin_sell',$all_set['msg_admin_sell'],'textarea','','',lang('plugin/keke_video_base', '448'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_admin_sell_id',$all_set['msg_admin_sell_id'],'text','','','');
	
	showsubtitle(array('<span class="colourc">'.lang('plugin/keke_video_base', '449').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_admin_cashout',$all_set['msg_admin_cashout'],'textarea','','',lang('plugin/keke_video_base', '451'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_admin_cashout_id',$all_set['msg_admin_cashout_id'],'text','','','');
	
	showsubtitle(array('<span class="colourc">'.lang('plugin/keke_video_base', '450').'</span>'));
	showsetting(lang('plugin/keke_video_base', '434'),'msg_admin_setin',$all_set['msg_admin_setin'],'textarea','','',lang('plugin/keke_video_base', '452'));
	showsetting(lang('plugin/keke_video_base', '435'),'msg_admin_setin_id',$all_set['msg_admin_setin_id'],'text','','','');
	
	showsubmit('editsubmit', 'submit', '','<input type="submit" class="btn" id="submit_testsubmit" name="testsubmit" title="" value="'.lang('plugin/keke_video_base', '453').'">');

	showtips(lang('plugin/keke_video_base', '454'));
	showtableheader(lang('plugin/keke_video_base', '455'));
	showsetting(lang('plugin/keke_video_base', '456'),'msg_tablename',$all_set['msg_tablename'],'text','','',lang('plugin/keke_video_base', '457'));
	showsetting('openid'.lang('plugin/keke_video_base', '458'),'msg_openidfield',$all_set['msg_openidfield'],'text','','','openid'.lang('plugin/keke_video_base', '458'));
	showsetting('uid'.lang('plugin/keke_video_base', '458'),'msg_uidfield',$all_set['msg_uidfield'],'text','','','uid'.lang('plugin/keke_video_base', '458'));
	showsetting(lang('plugin/keke_video_base', '459'),'msg_bindurl',$all_set['msg_bindurl'],'text','','',lang('plugin/keke_video_base', '460'));
	showsubmit('editsubmit', 'submit', '','<style>.coloura{ color:#F30}.colourb{ color:#9c27b0}.colourc{ color:#090}</span>');
	
	showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/

	
}