<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_video_ke extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_video_ke';
		$this->_pk    = 'id';

		parent::__construct();
	}
	
	public function fetch_first_by_id($keid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$keid));
	}

    public function fetch_first_by_title($title) {
        return DB::fetch_first("SELECT * FROM %t WHERE title=%s", array($this->_table,$title));
    }

	public function fetch_all_by_cid($uid,$cid,$state='') {
		$status=$state?' AND '.DB::field('state', 0):'';
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d AND cid=%d %i ORDER BY displayorder ASC, id ASC", array($this->_table,$uid,$cid,$status));
	}
	
	public function fetch_all_by_keids($keids) {
		return DB::fetch_all("SELECT * FROM %t WHERE id in (%n)", array($this->_table,$keids), $this->_pk);
		
	}
	public function fetch_first_by_where($where) {
		return DB::fetch_first("SELECT * FROM %t WHERE %i", array($this->_table,$where));
	}
	
	public function fetch_all_by_cidandtype($cid,$types) {
		return DB::fetch_all("SELECT * FROM %t WHERE cid=%d AND type in (%n) ORDER BY displayorder ASC, id ASC", array($this->_table,$cid,$types));
	}
	
	public function count_by_cpid($cpid='') {
		return DB::result_first("SELECT count(*) FROM %t WHERE cpid=%d", array($this->_table,$cpid));
	}

	public function fetch_all_ke($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by id desc';
		return DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp));
	}

	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}

	public function count_by_search($param) {
		return DB::result_first('SELECT COUNT(*) FROM %t %i', array($this->_table, $this->wheresql($param)));
	}
		
	public function fetch_by_newlive($startlimit,$ppp) {
		return DB::fetch_all("SELECT a.livetime as livestar,a.liveendtime as liveend,MIN(a.livetime)as mintime,a.id as keid,b.* FROM %t a,%t b WHERE a.cid=b.id AND b.state=1 AND a.state=0 AND a.type=3 AND ((a.livetime<".TIMESTAMP." AND a.liveendtime>".TIMESTAMP.") OR (a.livetime>".TIMESTAMP.")) group by a.cid  order by MIN(a.livetime) LIMIT %d,%d", array($this->_table,'keke_video_course',$startlimit,$ppp));
	}
}