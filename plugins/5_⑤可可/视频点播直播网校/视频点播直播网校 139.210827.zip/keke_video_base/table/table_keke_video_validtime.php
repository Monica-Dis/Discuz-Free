<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_video_validtime extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_video_validtime';
		$this->_pk    = 'id';

		parent::__construct();
	}
	
	
	public function fetchfirst_byid($oid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$oid));
	}
	
	public function fetchfirst_bycid($cid,$uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE cid=%d AND uid=%d", array($this->_table,$cid,$uid));
	}
	
	
	public function fetchfirst_bykeid($keid,$uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE keid=%d AND uid=%d", array($this->_table,$keid,$uid));
	}
	
	public function fetchfirst_bychapterid($chapterid,$uid) {
		return DB::fetch_first("SELECT * FROM %t WHERE chapterid=%d AND uid=%d", array($this->_table,$chapterid,$uid));
	}


    public function fetchall_bykeids($keids,$uid) {
        return DB::fetch_all("SELECT * FROM %t WHERE keid in (%n) AND uid=%d", array($this->_table,$keids,$uid),'keid');
    }

    public function fetchall_bycpids($cpids,$uid) {
        return DB::fetch_all("SELECT * FROM %t WHERE chapterid in (%n) AND uid=%d", array($this->_table,$cpids,$uid),'chapterid');
    }

	public function fetchall_byuid($uid) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d", array($this->_table,$uid));
	}

    public function fetchall_byuids($uids) {
        return DB::fetch_all("SELECT * FROM %t WHERE uid in (%n)", array($this->_table,$uids));
    }

    public function fetchall_bycid($cid) {
        return DB::fetch_all("SELECT * FROM %t WHERE cid=%d", array($this->_table,$cid));
    }
	
	public function fetch_all_validtime($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by id desc';
		return DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp));
	}
	
	
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}

    public function fetch_all_by_cids($cids,$uid) {
        return $query=DB::fetch_all("SELECT * FROM %t WHERE cid in (%n) AND uid=%d", array($this->_table,$cids,$uid), 'cid');
    }

	public function fetch_all_grobycid($ppp,$cids=array()) {
		$where='b.state=1 AND a.cid=b.id';
		if($cids){
			$where.=' AND a.cid IN ('.dimplode($cids).')';
		}
		$count=DB::fetch_all("SELECT count(1) as studyscount,a.cid,b.* FROM %t a,%t b WHERE %i GROUP BY a.cid ORDER BY studyscount DESC LIMIT 0,%d", array($this->_table,'keke_video_course',$where,$ppp));
		$counts=array();
		foreach($count as $val){
			$counts[$val['cid']]=$val;
		}
		return $counts;
	}

	public function del_byuidcid($uids,$cids) {
		return DB::query("delete FROM %t where uid=%d AND cid=%d", array($this->_table,$uids,$cids));
	}
	
	
}
//From: dis'.'m.tao'.'bao.com
?>