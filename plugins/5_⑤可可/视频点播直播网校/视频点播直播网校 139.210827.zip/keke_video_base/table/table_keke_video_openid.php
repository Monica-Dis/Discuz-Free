<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_video_openid extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_video_openid';
		$this->_pk    = 'uid';

		parent::__construct();
	}
	
	public function fetch_first_byid($sid) {
		global $_G;
		require_once DISCUZ_ROOT.'./source/plugin/keke_video_base/function.php';
		$all_set=_get_set();
		if($all_set['msg_tablename'] && $all_set['msg_uidfield'] && $all_set['msg_openidfield']){
			$return=DB::fetch_first("SELECT * FROM %t WHERE %i=%s", array($all_set['msg_tablename'],$all_set['msg_uidfield'],$sid),$all_set['msg_uidfield']);
			$ret['openid']=$return[$all_set['msg_openidfield']];
			$ret['uid']=$return[$all_set['msg_uidfield']];
			return $ret;
		}else{
			return DB::fetch_first('SELECT * FROM %t WHERE uid=%s', array($this->_table, $sid));
		}
	}
	
	public function fetch_first_bycode($code) {
		return DB::fetch_first('SELECT * FROM %t WHERE code=%s', array($this->_table, $code));
	}
	
	public function fetch_all() {
		return DB::fetch_all('SELECT * FROM %t ORDER BY displayorder ASC', array($this->_table));
	}
	
	public function getopenid_by_external() {
		global $_G;
		require_once DISCUZ_ROOT.'./source/plugin/keke_video_base/function.php';
		$all_set=_get_set();
		$ret=array();
		if($all_set['msg_tablename'] && $all_set['msg_uidfield']){
			$ret=DB::fetch_first("SELECT * FROM %t WHERE %i=%d", array($all_set['msg_tablename'],$all_set['msg_uidfield'],$_G['uid']));
		}
		return $ret;
	}
	
	public function getopenid_by_uids($uids) {
		require_once DISCUZ_ROOT.'./source/plugin/keke_video_base/function.php';
		$all_set=_get_set();
		$ret=array();
		if($all_set['msg_tablename'] && $all_set['msg_uidfield'] && $all_set['msg_openidfield']){
			$return=DB::fetch_all("SELECT * FROM %t WHERE %i in (%n)", array($all_set['msg_tablename'],$all_set['msg_uidfield'],$uids),$all_set['msg_uidfield']);
			foreach($return as $key=>$val){
				$ret[$key]['openid']=$val[$all_set['msg_openidfield']];
				$ret[$key]['uid']=$val[$all_set['msg_uidfield']];
			}
			return $ret;
			
		}else{
			return DB::fetch_all("SELECT * FROM %t WHERE uid in (%n)", array($this->_table,$uids),$this->_pk);
		}
		
		
	}
	
	public function getusername_by_uids($uids) {
		$rets=DB::fetch_all("SELECT * FROM %t WHERE %i in (%n)", array('common_member',$all_set['msg_uidfield'],$uids),$all_set['msg_uidfield']);
	}
	
}
//From: dis'.'m.tao'.'bao.com
?>