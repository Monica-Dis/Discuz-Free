<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_video_course extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_video_course';
		$this->_pk    = 'id';

		parent::__construct();
	}
	
	
	public function fetchfirst_byid($cid) {
		return DB::fetch_first("SELECT * FROM %t WHERE id=%d", array($this->_table,$cid));
	}

	public function fetch_by_new($par,$num) {
		$where=$par?'':1;
		return DB::fetch_all("SELECT * FROM %t WHERE sub_cate in (%n) AND state=1 AND hide<=0 ORDER BY displayorder DESC,id DESC LIMIT 0,%d", array($this->_table,$par,$num));
	}

	public function fetch_all_course($startlimit,$ppp,$where='',$order='') {
		$where=$where?$where:1;
		$orders=$order?$order:'order by time desc';
		return DB::fetch_all("SELECT * FROM %t WHERE %i %i LIMIT %d,%d", array($this->_table,$where,$orders,$startlimit,$ppp),$this->_pk);
	}
	
	
	public function count_all($where='') {
		$where=$where?$where:1;
		return DB::result_first("SELECT count(*) FROM %t WHERE %i", array($this->_table,$where));
	}
	
	
	public function count_by_search($param) {
		return DB::result_first('SELECT COUNT(*) FROM %t %i', array($this->_table, $this->wheresql($param)));
	}
		
	public function fetch_all_by_displayorder() {
		$query=DB::fetch_all("SELECT * FROM %t ORDER BY displayorder", array($this->_table), $this->_pk);
		return $this->_allcatedata($query);
	}

	public function fetch_all_by_cids($cids) {
		return $query=DB::fetch_all("SELECT * FROM %t WHERE id in (%n)", array($this->_table,$cids), $this->_pk);
	}
	
	public function fetch_all_by_uid($uid) {
		return DB::fetch_all("SELECT * FROM %t WHERE uid=%d", array($this->_table,$uid), $this->_pk);
	}
	
	public function fetch_uid_by_profile($mobile) {
		return $profile=DB::fetch_first("SELECT * FROM %t WHERE mobile='%i'", array('common_member_profile',$mobile));
		
	}
	
	public function count_all_by_uids($uids) {
		 $return=DB::fetch_all("SELECT count(*) as count,uid FROM %t WHERE uid in (%n) group by uid", array($this->_table,$uids));
		 foreach($return as $key=>$val){
		 	$conuntdata[$val['uid']]=$val['count'];
		 }
		 return $conuntdata;
	}
}