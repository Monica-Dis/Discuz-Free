<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
    global $_G;
    loadcache('plugin');
    $keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
    $_GET['op']=$_GET['op']?:'course';
    _showadminsubmenu(array(
        array(lang('plugin/keke_video_base', '557'), "course"),
        array(lang('plugin/keke_video_base', '556'), "package"),
    ),'admincp_course');
	if (submitcheck("forumset")) {
		if($_GET['optype'] == 'delete') {
			C::t('#keke_video_base#keke_video_course')->delete($_GET['delete']);
		} else{
		    switch ($_GET['optype']){
                case 'pass':
                    $state['state']=1;
                    break;
                case 'refuse':
                    $state['state']=0;
                    break;
                case 'locking':
                    $state['state']=3;
                    break;
                case 'stop':
                    $state['state']=5;
                    break;
            }
            C::t('#keke_video_base#keke_video_course')->update($_GET['delete'], $state);
        }
		cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course', 'succeed');
	}
	$allcatedata=_get_allcatedata();
	$formhash=substr(md5(substr($_G['timestamp'], 0, -7).$_G['username'].$_G['uid'].$_G['authkey']), 8, 8);
	$cid=intval($_GET['cid']);
	if($_GET['ac']=='edit'){
		if (submitcheck("editsubmit")) {
			$cates=$_GET['cateid'];
			if($allcatedata[$_GET['cateid']]['upid']){
				$cates=$allcatedata[$_GET['cateid']]['upid'];
			}
			$img=$_FILES['img'] ? _upload_img($_FILES['img'],500,272): $_GET['img'];
			
			if($_GET['vipprice']>$_GET['price']){
				cpmsg(lang('plugin/keke_video_base', '486'), '', 'error');
			}
			$arr=array(
				'title' => $_GET['title'],
				'price'=> $_GET['price'],
				'credit'=> $_GET['credit'],
				'credit_type'=> $_GET['credit_type'],
				'original_price'=> $_GET['original_price'],
				'learning_time'=> $_GET['learning_time'],
				'cate'=> $cates,
				'img'=> $img,
				'sub_cate'=> $_GET['cateid'],
				'content' => _video_editor_safe_replace($_GET['content']),
				'dec' => _video_editor_safe_replace($_GET['dec']),
				'view'=>intval($_GET['view']),
				'state'=>intval($_GET['state']),
				'displayorder'=>intval($_GET['displayorder']),
				'vip'=>intval($_GET['vip']),
				'vipprice'=>floatval($_GET['vipprice']),
				'onlyvip'=>intval($_GET['onlyvip']),
				'time' => TIMESTAMP,
				'password' => $_GET['password'],
				'hide'=>intval($_GET['hide']),
			);			
			C::t('#keke_video_base#keke_video_course')->update($cid,$arr);
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course', 'succeed');
		}
		$coursedata = C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_course&ac=edit", 'enctype');
		showtableheader(lang('plugin/keke_video_base', '194'));
		foreach($_G['setting']['extcredits'] as $extcreditsid=>$extcredits){
			$opt.="<option value='".$extcreditsid."' ".($extcreditsid==$coursedata['credit_type']?'selected':'').">".$extcredits['title']."</option>";
		}
		showsetting(lang('plugin/keke_video_base', '195'),'title',$coursedata['title'],'text');
		showsetting(lang('plugin/keke_video_base', '196'),'price',$coursedata['price'],'text');
		showsetting(lang('plugin/keke_video_base', '197'),'credit',$coursedata['credit'],'text');
		showsetting(lang('plugin/keke_video_base', '198'), '', 'credit_type', "<select name='credit_type'>".$opt."</select> ");
		showsetting(lang('plugin/keke_video_base', '199'),'original_price',$coursedata['original_price'],'text');
		showsetting(lang('plugin/keke_video_base', '200'),'img',$coursedata['img'],'filetext');
		showsetting(lang('plugin/keke_video_base', '201'),'learning_time',$coursedata['learning_time'],'text');
		$edit= "
			<textarea name=\"content\" style=\"width:700px;height:400px;visibility:hidden;\">".$coursedata['content']."</textarea>
			<script charset=\"utf-8\" src=\"./source/plugin/keke_video_base/static/kindeditor/kindeditor-min.js\"></script>
			<script charset=\"utf-8\" src=\"./source/plugin/keke_video_base/static/kindeditor/lang/zh_CN.js\"></script>
			<script>
			  var itemss = [
				  'source', '|', 'undo', 'redo', '|', 'preview', 'template', 'cut', 'copy', 'paste',
				  'plainpaste', 'wordpaste', '|', 'justifyleft', 'justifycenter', 'justifyright',
				  'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
				  'superscript', 'clearhtml', 'quickformat', 'selectall', '|', 'fullscreen', '/',
				  'formatblock', 'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold',
				  'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'image', 'multiimage', 'table', 'hr', 'emoticons', 'baidumap', 'pagebreak',
				  'anchor', 'link', 'unlink'
			  ];
			  KindEditor.ready(function(K) {
						var editor1 = K.create('textarea[name=\"content\"]', {
							uploadJson : 'plugin.php?id=keke_video_base:ajax&ac=updatapic&formhash=".$formhash."',
							allowFileManager : false,
							items : itemss
						});
					});
			</script>";
		showsetting(lang('plugin/keke_video_base', '202'), '','',_getcateselect($coursedata['sub_cate']));
		showsetting(lang('plugin/keke_video_base', '203'),'dec',$coursedata['dec'],'textarea');
		showsetting(lang('plugin/keke_video_base', '204'), '','',$edit);
		showsetting(lang('plugin/keke_video_base', '205'),'view',$coursedata['view'],'text');
		showsetting(lang('plugin/keke_video_base', '072'), '', 'state', "<select name='state'><option value='0' ".($coursedata['state']==0?'selected':'').">".lang('plugin/keke_video_base', '206')."</option><option value='1' ".($coursedata['state']==1?'selected':'').">".lang('plugin/keke_video_base', '207')."</option><option value='3' ".($coursedata['state']==3?'selected':'').">".lang('plugin/keke_video_base', '208')."</option></select> ");
		showsetting(lang('plugin/keke_video_base', '209'),'displayorder',$coursedata['displayorder'],'text');
		showsetting(lang('plugin/keke_video_base', '311'),'vip',$coursedata['vip']);
		showsetting(lang('plugin/keke_video_base', '484'),'vipprice',$coursedata['vipprice'],'text','','',lang('plugin/keke_video_base', '485'));
		showsetting(lang('plugin/keke_video_base', '512'),'onlyvip',$coursedata['onlyvip'],'radio','','',lang('plugin/keke_video_base', '513'));
		showsetting(lang('plugin/keke_video_base', '491'),'password',$coursedata['password'],'text','','','');
		showsetting(lang('plugin/keke_video_base', '492').lang('plugin/keke_video_base', '493'),'hide',$coursedata['hide']);
		echo '<input name="cid" type="hidden" value="'.$cid.'" />';
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
	
	}elseif($_GET['ac']=='delstu'){
		$stuuid=intval($_GET['stuuid']);
		C::t('#keke_video_base#keke_video_validtime')->del_byuidcid($stuuid,$cid);
		cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=stu&cid='.$cid, 'succeed');
	}elseif($_GET['ac']=='stu'){
			showtableheader(lang('plugin/keke_video_base', '292'));
			showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_course&ac=stu&cid='.$cid, 'testhd');
			showtablerow('', array('width="80"', 'width="180"', 'width="100"'),
				array(
					'<b>'.lang('plugin/keke_video_base', '275').'</b>',
					'<input name="username" type="text" />',
					'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '065').'">',
					'<span class="tips2">'. lang('plugin/keke_video_base', '539').'</span>'
				)
			);
			showformfooter(); /*Dism_taobao-com*/
			showtablefooter(); /*dism��taobao��com*/
			$where='cid='.$cid;
			$param='';
			if($_GET['username']){
                $uidarr[]=intval($_GET['username']);
                $uid = C::t('common_member')->fetch_uid_by_username($_GET['username']);
                if($uid && $uid!=$_GET['uid'])$uidarr[]=$uid;
				$where.=" AND uid in (".dimplode($uidarr).")";
				$param.='&uid='.intval($_GET['uid']);
			}
			showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_course");	
			showtableheader(lang('plugin/keke_video_base', '293').' <cite class="sline">|</cite><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=addstu&cid='.$cid.'" class="addtr addstubtn">'.lang('plugin/keke_video_base', '322').'</a>');
			showsubtitle(array(lang('plugin/keke_video_base', '294'),lang('plugin/keke_video_base', '295'),'del',''));
			$ppp=30;
			$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=stu&cid='.$cid.$param;
			$page = max(1, intval($_GET['page']));
			$startlimit = ($page - 1) * $ppp;
			$order='ORDER BY id DESC';
			if($allcount = C::t('#keke_video_base#keke_video_validtime')->count_all($where)){
				$video_data=C::t('#keke_video_base#keke_video_validtime')->fetch_all_validtime($startlimit,$ppp,$where,$order);
				foreach($video_data as $key=>$val){
					$table = array();
					$table[0] = '<a href="home.php?mod=space&uid='.$val['uid'].'"  target="_blank">'._getusname($val['uid']).'</a>';
					$table[1] = $val['exp_time']>0?dgmdate($val['exp_time'], 'Y/m/d H:i:s'):lang('plugin/keke_video_base', '016');
					$table[2] = '<a href="javascript:if(confirm(\''.lang('plugin/keke_video_base', '392').'\'))location=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=delstu&cid='.$cid.'&stuuid='.$val['uid'].'\'" class="addstubtn">'.lang('plugin/keke_video_base', '135').'</a>';
					showtablerow('',array('width="150"','width="400"'), $table);
				}
			}
			$multipage='';
			$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
			if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
			echo '<style>.sline{color:#e3e3e3;margin:0 15px 0 10px;}.opbtn{margin-top:5px;display: inline-block;}.coursetitle{margin-right:10px; width:450px;}.coursedec{ color:#999; margin:7px 10px 10px 0; line-height:20px;}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}.locking{ color:#c30}.pass{ color:#12b500}.refuse{color:#efa800}.locking img,.pass img,.refuse img{ vertical-align:middle}</style>';
			showtablefooter(); /*dism��taobao��com*/
			showformfooter(); /*Dism_taobao-com*/
			exit;
	}elseif($_GET['ac']=='addstu'){
		$coursedata = C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
		if (submitcheck("editsubmit")) {
			if($_GET['username']){
				$uid=C::t('common_member')->fetch_uid_by_username($_GET['username']);
			}elseif($_GET['uids']){
				$uid=intval($_GET['uids']);
			}elseif($_GET['mobile']){
				$memberprofile = C::t('#keke_video_base#keke_video_course')->fetch_uid_by_profile($_GET['mobile']);
				$uid=$memberprofile['uid'];
			}
			if(!$uid){
				cpmsg(lang('plugin/keke_video_base', '326'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=addstu&cid='.$cid, 'error');
			}
			$vtimedata=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bycid($cid,$uid);
			$exptime= strtotime($_GET['exptime']);
			$arr=array(
				'uid'=>$uid,
				'cid'=>$cid,
				'teacher_uid'=>$coursedata['uid'],
				'exp_time'=>$exptime,
				'latest_change_time'=>TIMESTAMP,
				'title'=>lang('plugin/keke_video_base', '531'),
			);
			if($vtimedata){
				$arr['id']=$vtimedata['id'];
			}
			C::t('#keke_video_base#keke_video_validtime')->insert($arr,true,true);
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=stu&cid='.$cid, 'succeed');
		}
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_course&ac=addstu", 'enctype');
		showtips('<li>'.lang('plugin/keke_video_base', '390').'</li>');
		showtableheader('['.$coursedata['title'].'] '.lang('plugin/keke_video_base', '323').' <cite class="sline">|</cite><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=stu&cid='.$cid.'" class="opbtn">'.lang('plugin/keke_video_base', '391').'</a>');
		showsetting(lang('plugin/keke_video_base', '324'),'username','','text');
		showsetting('UID','uids','','text');
		showsetting('mobile','mobile','','text');
		showsetting(lang('plugin/keke_video_base', '325'),'exptime','','calendar','', 0, '', 1);
		echo '<input name="cid" type="hidden" value="'.$cid.'" />';
		showsubmit('editsubmit', 'submit', '','');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		echo '<style>.sline{color:#e3e3e3;margin:0 15px 0 10px;}#hour,#minute{width: 20px;}</style><script type="text/javascript" src="static/js/calendar.js"></script>';
		exit;
	}elseif($_GET['ac']=='changeuid'){
		$coursedata = C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
		if (submitcheck("editsubmit")) {
			$uid=intval($_GET['uids']);
			if(!$uid){
				cpmsg(lang('plugin/keke_video_base', '326'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=addstu&cid='.$cid, 'error');
			}
			$allke=C::t('#keke_video_base#keke_video_ke')->fetch_all_by_cidandtype($cid,array(1,2,3));
			foreach($allke as $kekey=>$keval){
				$concent=unserialize($keval['concent']);
				if($concent['videoid']){
					$vidarr[$concent['videoid']]=$concent['videoid'];
				}
				$keidsarr[]=$keval['id'];
			}
			$vidarr=array_values($vidarr);
			C::t('#keke_video_base#keke_video_chapter')->update_bycid($cid,$uid);
			C::t('#keke_video_base#keke_video_ke')->update($keidsarr,array('uid'=>$uid));
			C::t('#keke_video_base#keke_video_media')->update($vidarr,array('uid'=>$uid));
			C::t('#keke_video_base#keke_video_course')->update($cid,array('uid'=>$uid));
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course', 'succeed');
		}
		
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_course&ac=changeuid", 'enctype');
		showtips(lang('plugin/keke_video_base', '403'));
		showtableheader(lang('plugin/keke_video_base', '402').'['.$coursedata['title'].'] '.lang('plugin/keke_video_base', '401').' <cite class="sline">|</cite><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course" class="opbtn">'.lang('plugin/keke_video_base', '404').'</a>');
		showsetting('UID','uids','','text');
		echo '<input name="cid" type="hidden" value="'.$cid.'" />';
		showsubmit('editsubmit', 'submit', '','');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		echo '<style>.sline{color:#e3e3e3;margin:0 15px 0 10px;}</style>';
		exit();
	}elseif($_GET['ac']=='editevaluate'){
		$coursedata = C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
		if($_GET['op']=='editeditevaluate'){
			if (submitcheck("editsubmit")) {
				$arr=array(
					'uid'=>intval($_GET['uid']),
					'username'=>_getusname($_GET['uid']),
					'cid'=>$cid,
					'star'=>intval($_GET['star']),
					'text'=>$_GET['text'],
					'time'=> strtotime($_GET['pusttime']),
				);
				C::t('#keke_video_base#keke_video_evaluate')->insert($arr);
				cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=editevaluate&cid='.$cid, 'succeed');
			
			}else{
				showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_course&ac=editevaluate&op=editeditevaluate", 'enctype');
				showtableheader(lang('plugin/keke_video_base', '503').' [ '.$coursedata['title'].' ] '.lang('plugin/keke_video_base', '497'));
				showsetting(lang('plugin/keke_video_base', '499').'UID','uid','','text');
				showsetting(lang('plugin/keke_video_base', '500'), '', 'star', "<select name='star'><option value='1'>1".lang('plugin/keke_video_base', '502')."</option><option value='2'>2".lang('plugin/keke_video_base', '502')."</option><option value='3' >3".lang('plugin/keke_video_base', '502')."</option><option value='4' >4".lang('plugin/keke_video_base', '502')."</option><option value='5' >5".lang('plugin/keke_video_base', '502')."</option></select> ");
				showsetting(lang('plugin/keke_video_base', '501'),'text','','textarea');
				showsetting(lang('plugin/keke_video_base', '504'),'pusttime','','calendar','', 0, '', 1);
				echo '<script type="text/javascript" src="static/js/calendar.js"></script>';
				echo '<input name="cid" type="hidden" value="'.$cid.'" />';
				showsubmit('editsubmit', 'submit', '');
				showtablefooter(); /*dism��taobao��com*/
				showformfooter(); /*Dism_taobao-com*/
				exit();
			}
		}
		if (submitcheck("delevaluate")) {
			C::t('#keke_video_base#keke_video_evaluate')->delete($_GET['delete']);
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=editevaluate&cid='.$cid.'&page='.intval($_GET['page']), 'succeed');
		}
		showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_course&ac=editevaluate");	
		showtableheader(lang('plugin/keke_video_base', '503').' [ '.$coursedata['title'].' ] '.lang('plugin/keke_video_base', '497'));
		showsubtitle(array('del',lang('plugin/keke_video_base', '499'),lang('plugin/keke_video_base', '500'),lang('plugin/keke_video_base', '501'),lang('plugin/keke_video_base', '504')));
		$ppp=30;
		$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=editevaluate&cid='.$cid.$param;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$where='cid='.$cid;
		$order='ORDER BY id DESC';
		if($allcount = C::t('#keke_video_base#keke_video_evaluate')->count_all($where)){
			$evaluate_data=C::t('#keke_video_base#keke_video_evaluate')->fetch_all_evaluate($startlimit,$ppp,$where,$order);
			foreach($evaluate_data as $key=>$val){
				$table = array();
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
				$table[1] = '<a href="home.php?mod=space&uid='.$val['uid'].'"  target="_blank">'._getusname($val['uid']).'</a>';
				$table[2] = $val['star'].' '.lang('plugin/keke_video_base', '502');
				$table[3] = $val['text'];
				$table[4] = dgmdate($val['time'], 'Y/m/d H:i');
				showtablerow('',array('width="50"','width="400"'), $table);
			}
		}
		$multipage='';
		$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
		if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
		echo '<style>.sline{color:#e3e3e3;margin:0 15px 0 10px;}.opbtn{margin-top:5px;display: inline-block;}.coursetitle{margin-right:10px; width:450px;}.coursedec{ color:#999; margin:7px 10px 10px 0; line-height:20px;}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}.locking{ color:#c30}.pass{ color:#12b500}.refuse{color:#efa800}.locking img,.pass img,.refuse img{ vertical-align:middle}</style><input name="cid" type="hidden" value="'.$cid.'" /><input name="page" type="hidden" value="'.intval($_GET['page']).'" />';
		showsubmit('delevaluate', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=editevaluate&op=editeditevaluate&cid='.$cid.'" class="addtr">'.lang('plugin/keke_video_base', '532').'</a>');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
	}elseif($_GET['ac']=='editqa'){
		$coursedata = C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($cid);
		if (submitcheck("delqa")) {
			C::t('#keke_video_base#keke_video_answers')->delete($_GET['delete']);
			cpmsg(lang('plugin/keke_video_base', '058'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=editqa&cid='.$cid.'&page='.intval($_GET['page']), 'succeed');
		}
		showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_course&ac=editqa");	
		showtableheader(lang('plugin/keke_video_base', '503').' <a href="plugin.php?id=keke_video_base&ac=course&cid='.$cid.'">[ '.$coursedata['title'].' ]</a> '.lang('plugin/keke_video_base', '498'));
		showsubtitle(array('del',lang('plugin/keke_video_base', '505'),lang('plugin/keke_video_base', '506'),lang('plugin/keke_video_base', '507'),lang('plugin/keke_video_base', '508')));
		$ppp=30;
		$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=editqa&cid='.$cid;
		$page = max(1, intval($_GET['page']));
		$startlimit = ($page - 1) * $ppp;
		$where='cid='.$cid;
		$order='ORDER BY id DESC';
		if($allcount = C::t('#keke_video_base#keke_video_answers')->count_all($where)){
			$answers_data=C::t('#keke_video_base#keke_video_answers')->fetch_alls($startlimit,$ppp,$where,$order);
			foreach($answers_data as $key=>$val){
				$table = array();
				$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
				$table[1] = '<a href="home.php?mod=space&uid='.$val['uid'].'"  target="_blank">'._getusname($val['uid']).'</a>';
				$table[2] = '<div class="textbox">'._video_editor_safe_replace(htmlspecialchars_decode($val['text'])).'</div>';
				$table[3] = '<div class="textbox">'._video_editor_safe_replace(htmlspecialchars_decode($val['reply'])).'</div>';
				$table[4] = dgmdate($val['time'], 'Y/m/d H:i');
				showtablerow('',array('width="50"','width=""','width="400"','width="400"'), $table);
			}
		}
		$multipage='';
		$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
		if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
		echo '<style>.textbox{line-height:20px;padding: 10px 10px 10px 0;color: #848484;}.sline{color:#e3e3e3;margin:0 15px 0 10px;}.opbtn{margin-top:5px;display: inline-block;}.coursetitle{margin-right:10px; width:450px;}.coursedec{ color:#999; margin:7px 10px 10px 0; line-height:20px;}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}.locking{ color:#c30}.pass{ color:#12b500}.refuse{color:#efa800}.locking img,.pass img,.refuse img{ vertical-align:middle}</style><input name="cid" type="hidden" value="'.$cid.'" /><input name="page" type="hidden" value="'.intval($_GET['page']).'" />';
		showsubmit('delqa', 'submit', 'del');
		showtablefooter(); /*dism��taobao��com*/
		showformfooter(); /*Dism_taobao-com*/
		exit;
	}
	showtableheader(lang('plugin/keke_video_base', '210'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_course', 'testhd');
	showtablerow('', array('width="50"', 'width="120"', 'width="50"','width="80"', 'width="50"','width="180"'),
		array(
			'<b>'.lang('plugin/keke_video_base', '162').': </b>',
			_getcateselect($helpdata['cateid']),
            '<b>'.lang('plugin/keke_video_base', '072').': </b>',
            '<select name="cstate"><option>'.lang('plugin/keke_video_base', '011').'</option><option value="1" '.($_GET['cstate']==1?'selected':'').'>'.lang('plugin/keke_video_base', '207').'</option><option value="9" '.($_GET['cstate']==9?'selected':'').'>'.lang('plugin/keke_video_base', '206').'</option><option value="3" '.($_GET['cstate']==3?'selected':'').'>'.lang('plugin/keke_video_base', '208').'</option><option value="5" '.($_GET['cstate']==5?'selected':'').'>'.lang('plugin/keke_video_base', '568').'</option></select>',
			'<b>'.lang('plugin/keke_video_base', '211').': </b>',
			'<input name="helpkw" type="text" /><input type="hidden" name="op" value="'.($_GET['op']).'"/>',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '065').'">'
		)
    );
	showformfooter(); /*Dism_taobao-com*/
	showtablefooter(); /*dism��taobao��com*/
	$where='1';$param='';
	if($_GET['cateid']>0){
		$where.=" AND sub_cate=".intval($_GET['cateid']);
		$param.='&cateid='.intval($_GET['cateid']);
	}
	if($_GET['helpkw']){
		$where.=" AND title LIKE '%".addcslashes($_GET['helpkw'],'%_')."%'";
		$param.='&helpkw='.addcslashes($_GET['helpkw']);
	}
    if($_GET['cstate']){
        $original=0;
        if($_GET['cstate']==9){
            $original=$_GET['cstate'];
            $_GET['cstate']=0;
        }
        $where.=" AND state=".intval($_GET['cstate']);
        $_GET['cstate']=$original==9?9:$_GET['cstate'];
        $param.='&cstate='.intval($_GET['cstate']);
    }
	if($_GET['op']=='package'){
        $where.=" AND type=3";
        $param.='&op=package';
    }else{
        $where.=" AND type!=3";
        $param.='&op=course';
    }

	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_course");	
	showtips('<li>'.lang('plugin/keke_video_base', '212').'</li>');
	showtableheader(lang('plugin/keke_video_base', '213'));
    showsubtitle(array(lang('plugin/keke_video_base', '067'), lang('plugin/keke_video_base', '185'),'', lang('plugin/keke_video_base', '202'),lang('plugin/keke_video_base', '214'),lang('plugin/keke_video_base', '215'),lang('plugin/keke_video_base', '087'),lang('plugin/keke_video_base', '216'),lang('plugin/keke_video_base', '118')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$order='ORDER BY displayorder DESC,id DESC';
	if($allcount = C::t('#keke_video_base#keke_video_course')->count_all($where)){
		$video_data=C::t('#keke_video_base#keke_video_course')->fetch_all_course($startlimit,$ppp,$where,$order);
		foreach($video_data as $key=>$val){
			$op='<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=edit&cid='.$val['id'].'" >'.lang('plugin/keke_video_base', '170').'</a>'.($_GET['op']=='course'?' / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=stu&cid='.$val['id'].'" class="opbtn">'.lang('plugin/keke_video_base', '296').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=addstu&cid='.$val['id'].'" class="opbtn">'.lang('plugin/keke_video_base', '322').'</a><div class="rowtow"><a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=editevaluate&cid='.$val['id'].'" class="opbtn">'.lang('plugin/keke_video_base', '497').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=editqa&cid='.$val['id'].'" class="opbtn">'.lang('plugin/keke_video_base', '498').'</a>':'').'</div>';

			switch ($val['state']){
                case 1:
                    $stateArr=array('16',lang('plugin/keke_video_base', '207'),'pass');
                    break;
                case 0:
                    $stateArr=array('17',lang('plugin/keke_video_base', '206'),'refuse');
                    break;
                case 3:
                    $stateArr=array('11',lang('plugin/keke_video_base', '208'),'locking');
                    break;
                case 5:
                    $stateArr=array('11',lang('plugin/keke_video_base', '568'),'locking');
                    break;
            }
            $state='<span class="'.$stateArr[2].'"><img src="source/plugin/keke_video_base/template/images/ico0'.$stateArr[0].'.png" width="11" height="11" /> '.$stateArr[1].'</span>';
			$cate=$allcatedata[$val['sub_cate']]['upid']?$allcatedata[$allcatedata[$val['sub_cate']]['upid']]['name'].' <span class="sline">/</span> '.$allcatedata[$val['sub_cate']]['name']:$allcatedata[$val['subcate']]['name'];
			$courseinfo='<b>'.lang('plugin/keke_video_base', '217').'<a href="plugin.php?id=keke_video_base&ac=teacher&tcid='.$val['uid'].'" target="_blank">'._getusname($val['uid']).'</a></b> <span class="sline">|</span> <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=changeuid&cid='.$val['id'].'" class="locking" >'.lang('plugin/keke_video_base', '402').'</a><div class="coursedec">'.lang('plugin/keke_video_base', '218').($_GET['op']=='course'?$val['chapter_count'].lang('plugin/keke_video_base', '219').' '.$val['ke_count'].lang('plugin/keke_video_base', '220'):count(explode(',',$val['courseids'])).lang('plugin/keke_video_base', '503')).'</div>';
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />'.$val['id'];
			$table[1] = '<a href="plugin.php?id=keke_video_base&ac=course&cid='.$val['id'].'"  target="_blank"><img src="'.$val['img'].'" width="130"></a>';
			$table[2] = '<a href="plugin.php?id=keke_video_base&ac=course&cid='.$val['id'].'"  target="_blank">'.$val['title'].'</a>'.($val['vip']?'<span class="vipbox">vip</span>':'').($val['hide']?'<span class="hidebox">'.lang('plugin/keke_video_base', '492').'</span>':'').'<br><div class="coursedec">'.cutstr($val['dec'],'130').' '.((strlen($val['dec'])>130)?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_course&ac=edit&cid='.$val['id'].'"">'.lang('plugin/keke_video_base', '019'):'').'</a></div>';
			$table[3] = $cate;
			$table[4] = $courseinfo;
			$table[5] = dgmdate($val['time'], 'Y/m/d H:i');
			$table[6] = $val['displayorder'];
			$table[7] = $state;
			$table[8] = $op;
			showtablerow('',array('','width="150"','class="coursetitle"'), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	echo '<style>.rowtow{margin-top: 5px;} .vipbox{background: #ea5050;color: #fff;padding: 0 5px;margin-left: 10px;border-radius: 1px;font-size: 12px;}.hidebox{background: #585858;color: #fff;padding: 0 5px;margin-left: 10px;border-radius: 1px;font-size: 12px;}.opbtn{margin-top:5px;display: inline-block;}.coursetitle{margin-right:10px; width:450px;}.coursedec{ color:#999; margin:7px 10px 10px 0; line-height:20px;}#imgzoom{  margin:15px 0;}#imgzoom p { display:none}.locking{ color:#c30}.pass{ color:#12b500}.refuse{color:#efa800}.locking img,.pass img,.refuse img{ vertical-align:middle}.sline{color:#e3e3e3;margin:0 3px;}</style>';
	showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'uids\')"><label for="chkallIuPN">'.lang('plugin/keke_video_base', '067').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_video_base', '135').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="pass" value="pass" class="radio" /><label for="pass" class="vmiddle">'.lang('plugin/keke_video_base', '207').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="refuse" value="refuse" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_video_base', '206').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="locking" value="locking" class="radio" /><label for="locking" class="vmiddle">'.lang('plugin/keke_video_base', '208').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="stop" value="stop" class="radio" /><label for="stop" class="vmiddle">'.lang('plugin/keke_video_base', '568').'</label>','');
    showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/