<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
	$allowget=$_GET['allowget']?true:false;
	if (submitcheck("forumset",$allowget)) {
		if($_GET['cashids']) {
			$cashoutdata=C::t('#keke_video_base#keke_video_cashout')->fetch_all($_GET['cashids']);
            $ErrCount=0;
            $cashids=array();
            foreach($cashoutdata as $val){
                if(!$val['state']){
                    $newcashids[$val['id']]=$val['id'];
                    if($_GET['optype'] == 'ref'){
                        cach_log($val['money'],lang('plugin/keke_video_base', '055'),$val['uid']);
                    }
                }else{
                    $ErrCount++;
                }
            }
            $cashids=$newcashids;
			$start=$_GET['optype'] == 'pass'?1:2;
			if($cashids){
				foreach($cashids as $cashid){
					$tuids[$cashoutdata[$cashid]['uid']]=$cashoutdata[$cashid]['uid'];
                    if($cashoutdata[$cashid]['card_type']==4 && $start==1){
                        $Magapppay=MagappAccountTransfer($cashoutdata[$cashid]['uid'],$cashoutdata[$cashid]['money'],lang('plugin/keke_video_base', '541'));
                        if(!$Magapppay[0]){
                            unset($cashids[$cashid]);
                            $errid[$cashid]=$cashid;
                            $errMsg=$Magapppay[1];
                        }
                    }
				}
				if($errid){
                    C::t('#keke_video_base#keke_video_cashout')->update($errid, array('msg'=>$errMsg));
                }
                C::t('#keke_video_base#keke_video_cashout')->update($cashids, array('state' => $start,'htime'=>TIMESTAMP));
				_video_send_notice($tuids,'msg_teacher_cashout',array('state'=>($start?lang('plugin/keke_video_base', '422'):lang('plugin/keke_video_base', '423'))));
			}
		}else{
			cpmsg(lang('plugin/keke_video_base', '056'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_cashout', 'error');
		}
		
		if(!$_GET['optype']){
			cpmsg(lang('plugin/keke_video_base', '057'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_cashout', 'error');
		}
		cpmsg(lang('plugin/keke_video_base', '058').count($cashids).lang('plugin/keke_video_base', '059').', '.lang('plugin/keke_video_base', '423').(count($errid)+$ErrCount).lang('plugin/keke_video_base', '059'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_cashout', 'succeed');
	}
	showtableheader(lang('plugin/keke_video_base', '060'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_video_base&pmod=admincp_cashout', 'testhd');
	showtablerow('', array('width="50"', 'width="90"'),
		array(
			'<b>'.lang('plugin/keke_video_base', '061').'</b>',
			'<select name="state"><option value="0">'.lang('plugin/keke_video_base', '011').'</option><option value="9" '.($_GET['state']==9?'selected':'').'>'.lang('plugin/keke_video_base', '062').'</option><option value="1" '.($_GET['state']==1?'selected':'').'>'.lang('plugin/keke_video_base', '063').'</option><option value="2" '.($_GET['state']==2?'selected':'').'>'.lang('plugin/keke_video_base', '064').'</option></select>',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_video_base', '065').'">'
		)
    );
	showformfooter(); /*Dism_taobao-com*/
	showtablefooter(); /*dism��taobao��com*/
	
	$where='1';$param='';
	if($_GET['state']){
		$_GET['state']=$_GET['state']==9?0:$_GET['state'];
		$where.=" AND state=".intval($_GET['state']);
		$_GET['state']=!$_GET['state']?9:$_GET['state'];
		$param.='&state='.intval($_GET['state']);
	}
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_cashout");	
	showtableheader(lang('plugin/keke_video_base', '066'));
    showsubtitle(array(lang('plugin/keke_video_base', '067'), lang('plugin/keke_video_base', '068'),lang('plugin/keke_video_base', '069'),lang('plugin/keke_video_base', '070'),lang('plugin/keke_video_base', '071'),lang('plugin/keke_video_base', '072'),lang('plugin/keke_video_base', '073')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_cashout'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($allcount = C::t('#keke_video_base#keke_video_cashout')->count_all($where)){
		$cashout_data=C::t('#keke_video_base#keke_video_cashout')->fetch_alls($startlimit,$ppp,$where,$order);
		foreach($cashout_data as $key=>$val){
			$op=!$val['state']?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_cashout&optype=pass&cashids='.$val['id'].'&forumset=TRUE&allowget=1&formhash='.FORMHASH.'" onClick="return confirm( \''.lang('plugin/keke_video_base', '074').'\');">'.lang('plugin/keke_video_base', '075').'</a> / <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_video_base&pmod=admincp_cashout&optype=ref&cashids='.$val['id'].'&forumset=TRUE&allowget=1&formhash='.FORMHASH.'"  onClick="return confirm( \''.lang('plugin/keke_video_base', '076').'\');">'.lang('plugin/keke_video_base', '077').'</a>':dgmdate($val['htime'], 'Y/m/d H:i');
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox"  name="cashids[]" value="'.$val['id'].'" />';
			$table[1] = '<a href="#">'._getusname($val['uid']).'</a>';
			$table[2] = $val['card'].($val['msg'] && $val['state']==0 ?'<br><span class="cashoutmsg">'.$val['msg'].'</span>':'');
			$table[3] = '<b class="money">&yen; '.$val['money'].'</b>';
			$table[4] = dgmdate($val['time'], 'Y/m/d H:i:s');
			$table[5] = $val['state']==0?'<span class="ds">'.lang('plugin/keke_video_base', '078').'</span>':($val['state']==1?'<span class="zc">'.lang('plugin/keke_video_base', '079').'</span>':'<span class="jj">'.lang('plugin/keke_video_base', '080').'</span>');
			$table[6] = $op;
			showtablerow('',array('','width=""','width=""'), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	echo '<style>.ds{color: #F90;}.jj{color: #c30;}.zc{color: #3fd411;}.money{color: #c30;}.cashoutmsg{ display:inline-block;color: #ccc; margin: 5px 0;}</style>';
	showsubmit('', '', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'cashids\')"><label for="chkallIuPN">'.lang('plugin/keke_video_base', '067').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="pass" value="pass" class="radio" /><label for="pass" class="vmiddle">'.lang('plugin/keke_video_base', '081').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="ref" value="ref" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_video_base', '082').'</label>','<input type="submit" class="btn" id="submit_forumset" name="forumset" onClick="return confirm( \''.lang('plugin/keke_video_base', '083').'\');" value="'.lang('plugin/keke_video_base', '084').'">');
    showtablefooter(); /*dism��taobao��com*/
	showformfooter(); /*Dism_taobao-com*/
