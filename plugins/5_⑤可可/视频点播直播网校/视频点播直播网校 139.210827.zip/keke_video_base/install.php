<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_video_answers= DB::table("keke_video_answers");
$keke_video_cart= DB::table("keke_video_cart");
$keke_video_cash= DB::table("keke_video_cash");
$keke_video_cashout= DB::table("keke_video_cashout");
$keke_video_cate= DB::table("keke_video_cate");
$keke_video_chapter= DB::table("keke_video_chapter");
$keke_video_course= DB::table("keke_video_course");
$keke_video_evaluate= DB::table("keke_video_evaluate");
$keke_video_favorites= DB::table("keke_video_favorites");
$keke_video_follow= DB::table("keke_video_follow");
$keke_video_ke= DB::table("keke_video_ke");
$keke_video_media= DB::table("keke_video_media");
$keke_video_note= DB::table("keke_video_note");
$keke_video_order= DB::table("keke_video_order");
$keke_video_set= DB::table("keke_video_set");
$keke_video_slider= DB::table("keke_video_slider");
$keke_video_teacher= DB::table("keke_video_teacher");
$keke_video_teachergroup= DB::table("keke_video_teachergroup");
$keke_video_token= DB::table("keke_video_token");
$keke_video_validtime= DB::table("keke_video_validtime");
$keke_video_file= DB::table("keke_video_file");
$keke_video_openid= DB::table("keke_video_openid");
$keke_video_studylog= DB::table("keke_video_studylog");

$sql = <<<EOF
CREATE TABLE `$keke_video_answers` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `teacher_uid` int(20) NOT NULL,
  `cid` int(20) NOT NULL,
  `keid` int(20) NOT NULL,
  `text` mediumtext NOT NULL,
  `time` int(10) NOT NULL,
  `reply` mediumtext NOT NULL,
  `replytime` int(10) NOT NULL,
   PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_cart` (
   `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `cid` varchar(255) NOT NULL,
  `total` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
) ENGINE=MyISAM;


CREATE TABLE `$keke_video_cash` (
   `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `money` float(20,2) NOT NULL,
  `finalmoney` float(20,2) NOT NULL,
  `text` varchar(255) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_cashout` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `money` float(20,2) NOT NULL,
  `state` int(1) NOT NULL,
  `card_type` int(1) NOT NULL,
  `card` varchar(255) NOT NULL,
  `time` int(10) NOT NULL,
  `htime` int(10) NOT NULL,
  `msg` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_cate` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `upid` int(10) unsigned NOT NULL DEFAULT '0',
  `displayorder` int(6) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `num` int(8) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `recommend` int(1) NOT NULL,
  `vip_groupids` varchar(255) NOT NULL,
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM;


CREATE TABLE `$keke_video_chapter` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `cid` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dec` varchar(255) NOT NULL,
  `displayorder` int(20) NOT NULL,
  `price` float(20,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `chapter` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_course` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL,
  `username` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `dec` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `type` varchar(20) NOT NULL,
  `cate` int(10) NOT NULL,
  `sub_cate` int(5) NOT NULL,
  `price` float(20,2) NOT NULL,
  `original_price` float(20,2) NOT NULL,
  `credit` int(100) NOT NULL,
  `credit_type` int(1) NOT NULL,
  `state` int(1) NOT NULL,
  `time` int(20) NOT NULL,
  `status` int(1) NOT NULL,
  `displayorder` int(50) NOT NULL,
  `hot` int(1) NOT NULL,
  `learning_time` varchar(200) NOT NULL,
  `preview_time` int(10) NOT NULL,
  `chapter_count` int(50) NOT NULL,
  `ke_count` int(50) NOT NULL,
  `view` int(100) DEFAULT NULL,
  `vip` int(1) NOT NULL,
  `vipprice` float(20,2) NOT NULL,
  `onlyvip` int(1) NOT NULL,
  `password` varchar(200) NOT NULL,
  `hide` int(1) NOT NULL,
  `courseids` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `courseid` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_evaluate` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `cid` int(20) NOT NULL,
  `star` int(1) NOT NULL,
  `text` mediumtext NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_favorites` (
   `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(50) NOT NULL,
  `cid` varchar(255) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_follow` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `tid` int(20) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_ke` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `cid` int(100) NOT NULL,
  `cpid` int(100) NOT NULL,
  `uid` int(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `dec` varchar(255) NOT NULL,
  `displayorder` int(20) NOT NULL,
  `type` int(1) NOT NULL,
  `concent` mediumtext NOT NULL,
  `permissions` int(2) NOT NULL,
  `state` int(1) NOT NULL,
  `rec` int(1) NOT NULL,
  `enc` int(1) NOT NULL,
  `livetime` int(10) NOT NULL,
  `liveendtime` int(10) NOT NULL,
  `price` float(20,2) NOT NULL,
  `view` int(100) NOT NULL,
  `rts` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_media` (
  `vid` varchar(50) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `state` varchar(50) NOT NULL,
  `uid` int(100) NOT NULL,
  `time` int(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `enc` int(1) NOT NULL,
  PRIMARY KEY (`vid`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_note` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `keid` int(20) NOT NULL,
  `text` mediumtext NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_order` (
  `id` char(50) NOT NULL,
  `uid` int(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `pay_type` varchar(20) NOT NULL,
  `price` float(20,2) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `cid` varchar(500) NOT NULL,
  `teacher_uid` int(50) NOT NULL,
  `state` int(1) NOT NULL,
  `time` int(13) NOT NULL,
  `paytime` int(13) NOT NULL,
  `sn` varchar(50) NOT NULL,
  `revision` int(1) NOT NULL,
  `deduction` varchar(255) NOT NULL,
  `take` varchar(10) NOT NULL,
  `vipprice` float(20,2) NOT NULL,
  `buymod` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_set` (
  `id` varchar(50) NOT NULL,
  `val` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;


CREATE TABLE `$keke_video_slider` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(200) NOT NULL,
  `displayorder` int(20) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_teacher` (
  `uid` int(100) NOT NULL,
  `username` varchar(255) NOT NULL,
  `name` varchar(100) NOT NULL,
  `rank` varchar(20) NOT NULL,
  `tel` varchar(18) NOT NULL,
  `wechat` varchar(20) NOT NULL,
  `profile` varchar(500) NOT NULL,
  `exp_time` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  `op_time` int(10) NOT NULL,
  `img` varchar(255) NOT NULL,
  `info` mediumtext NOT NULL,
  `bank_name` varchar(100) NOT NULL,
  `bank_type` varchar(100) NOT NULL,
  `bank` varchar(50) NOT NULL,
  `alipay_name` varchar(100) NOT NULL,
  `alipay` varchar(50) NOT NULL,
  `wechatpay_name` varchar(100) NOT NULL,
  `wechatpay` varchar(50) NOT NULL,
  `money` float(20,2) NOT NULL,
  `teachergroupid` int(10) NOT NULL,
  `wechatqrcode` varchar(255) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `teacherid` (`uid`) USING BTREE
) ENGINE=MyISAM;


CREATE TABLE `$keke_video_teachergroup` (
  `id` int(100) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `permission_media` int(1) NOT NULL,
  `permission_live` int(1) NOT NULL,
  `permission_liverec` int(1) NOT NULL,
  `permission_take` int(5) NOT NULL,
  `permission_viptake` int(5) NOT NULL,
  `permission_mediasize` int(10) NOT NULL,
  `permission_tmp` varchar(100) NOT NULL,
  `permission_enc` int(1) NOT NULL,
  `permission_give_credit` int(50) NOT NULL,
  `permission_give_credit_type` int(1) NOT NULL,
  `permission_callmedia` int(1) NOT NULL,
  `defaults` int(1) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `teachergroup` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_token` (
  `id` varchar(20) NOT NULL,
  `val` varchar(100) NOT NULL,
  `time` varchar(20) NOT NULL,
  `vid` varchar(50) NOT NULL,
  `mediatype` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_validtime` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `cid` int(100) NOT NULL,
  `chapterid` int(50) NOT NULL,
  `keid` int(100) NOT NULL,
  `teacher_uid` int(50) NOT NULL,
  `exp_time` int(10) NOT NULL,
  `latest_change_time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `validtime` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_file` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `cid` int(50) NOT NULL,
  `chid` int(50) NOT NULL,
  `uid` int(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `file` varchar(255) NOT NULL,
  `displayorder` int(20) NOT NULL,
  `state` int(1) NOT NULL,
  `power` int(1) NOT NULL,
  `time` int(10) NOT NULL,
  `size` varchar(100) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `filetype` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_openid` (
  `uid` int(20) NOT NULL,
  `openid` varchar(50) NOT NULL,
  `code` varchar(50) NOT NULL,
  `nickname` varchar(50) NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_video_studylog` (
  `id` int(20) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `cid` int(20) NOT NULL,
  `keid` int(20) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `mediatime` varchar(20) NOT NULL,
  `learningtime` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  `time` int(10) NOT NULL,
  `historyip` varchar(500) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = true;

@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_video_base/discuz_plugin_keke_video_base_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_video_base/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_video_base/upgrade.php');
@unlink(DISCUZ_ROOT . base64_decode('Li9zb3VyY2UvcGx1Z2luL2tla2VfdmlkZW9fYmFzZS90ZW1wbGF0ZS9pbWFnZXMvV2VpeGluLmpwZw=='));