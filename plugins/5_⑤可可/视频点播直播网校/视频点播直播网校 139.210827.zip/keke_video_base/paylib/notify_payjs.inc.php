<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');
require_once DISCUZ_ROOT."source/plugin/keke_video_base/paylib/payjs/payjs.php";
include_once DISCUZ_ROOT."source/plugin/keke_video_base/function.php";
payjscheckSign($_POST);
uporderstate($_GET['out_trade_no'],($_GET['type']=='alipay'?1:2),$_GET['payjs_order_id']);
echo 'success';