<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
if(!function_exists('curl_init')){
	echo 'not function curl_init';
}
define('PAYJS_MCHID', trim($keke_video_base['wxmchid']));
define('PAYJS_KEY',trim($keke_video_base['wxshkey']));
function payjshttpPost($data, $url) {
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
	$rst = curl_exec($ch);
	curl_close($ch);
	return $rst;
}
function payjssign($arr){
	array_filter($arr);
	ksort($arr);
	$sign = strtoupper(md5(urldecode(http_build_query($arr) . '&key=' . PAYJS_KEY)));
	return $sign;
}

function payjscheckSign($arr){
    $user_sign = $arr['sign'];
    unset($arr['sign']);
    array_filter($arr);
    ksort($arr);
    $check_sign = strtoupper(md5(urldecode(http_build_query($arr) . '&key=' . PAYJS_KEY)));
    if ($user_sign != $check_sign){
        die('Signature error');
	}
}
function dopay($title,$total_price,$orderid,$zftype){
	global $_G;
	$data= array(
		'mchid'        => PAYJS_MCHID,
		'total_fee'    => $total_price*100,
		'body' => $title,
		'out_trade_no' => $orderid,
		'notify_url'   => trim($_G['siteurl'] . 'source/plugin/keke_video_base/paylib/notify_payjs.inc.php'),
	);
	if($zftype==1)$data['type'] = 'alipay';
	if(checkmobile() && $zftype==2){
		$data['sign'] = payjssign($data);
		$url = 'https://payjs.cn/api/cashier?' . http_build_query($data);
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
			echo json_encode(array('payjsurl' => $url));
		}else{
			$src = _getqrcodeurl($url);
			echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
		}
		exit;
	}
	$data['ip'] = $_SERVER['REMOTE_ADDR'];
	$data['sign'] = payjssign($data);
	$result = payjshttpPost($data,'https://payjs.cn/api/native');
	$ret=json_decode($result, true);
	if($ret['return_msg']!='SUCCESS'){
		exit(json_encode(array('err' => kekevideo_gbk2utf($ret['return_msg']))));
	}
	$src = _getqrcodeurl($ret['code_url']);
	echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
	exit;
}