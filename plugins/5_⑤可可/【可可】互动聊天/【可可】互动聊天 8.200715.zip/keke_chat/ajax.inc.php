<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_chat = $_G['cache']['plugin']['keke_chat'];
require_once DISCUZ_ROOT.'./source/plugin/keke_chat/function.php';
if($_GET['formhash'] != $_G['formhash']) {
	exit('Formhash_Error');
}
if($_GET['ac']=='sendMsg'){
	if(!$_GET['type'] || !$_GET['cid']){
		exit(json_encode(array('FlagString' => kekechat_gbk2utf(lang('plugin/keke_chat', '008')))));
	}
	if($_GET['type']=='video'){
		$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
		$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($_GET['cid']);
		$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($kearr['cid']);
		$validtime=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bycid($kearr['cid'],$_G['uid']);
		$checkallban=C::t('#keke_chat#keke_chat_ban')->fetchfirst_byid($_GET['cid'],-1,'video');
		$adminuids=C::t('#keke_chat#keke_chat_admin')->fetchfirst_byid($_GET['cid']);
		
		if($keke_video_base['inappchat']){
			$ua=$inapp=0;
			if($keke_video_base['appua']){
				$ua=(strstr($_SERVER['HTTP_USER_AGENT'], dhtmlspecialchars($keke_video_base['appua']))!== false)?1:0;
			}
			if((strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX")!== false || strstr($_SERVER['HTTP_USER_AGENT'], "QianFan")!== false  || strstr($_SERVER['HTTP_USER_AGENT'], "Appbyme")!== false || $ua) && $keke_video_base['appheader']){
				$inapp=1;
			}
			
			if(!$inapp && $_G['groupid']!=1 && !(in_array($_G['uid'],explode(',',$adminuids['adminuid']))) && $_G['uid']!=$course['uid']){
				exit(json_encode(array('Flag'=>109,'FlagString' => kekechat_gbk2utf(lang('plugin/keke_chat', '026')))));
			}
			
		}
		
		if($checkallban && $_G['groupid']!=1 && !(in_array($_G['uid'],explode(',',$adminuids['adminuid']))) && $_G['uid']!=$course['uid']){
			exit(json_encode(array('FlagString' => kekechat_gbk2utf(lang('plugin/keke_chat', '025')))));
		}
		$isfreecourse=1;
		if($keke_video_base['freechat'] && !($course['price']>0) && !($course['credit']>0)){
			$isfreecourse=0;
		}
		if((!$validtime || ($validtime['exp_time'] && $validtime['exp_time']<TIMESTAMP)) && $_G['groupid']!=1 && $course['uid']!=$_G['uid']){
			if($isfreecourse){
				exit(json_encode(array('FlagString' => kekechat_gbk2utf(lang('plugin/keke_chat', '009')))));
			}
		}
	}
	$bandata=C::t('#keke_chat#keke_chat_ban')->fetchfirst_byid($_GET['cid'],$_G['uid'],$_GET['type']);
	if($bandata && $bandata['exptime']>TIMESTAMP || $bandata['exptime']==-1){
		exit(json_encode(array('FlagString' => kekechat_gbk2utf(lang('plugin/keke_chat', '010').(checkmobile()?'':lang('plugin/keke_chat', '011'))))));
	}
	$rst = sendMsg();
	exit(json_encode($rst));
}elseif($_GET['ac']=='history'){
	$rst = history();
	exit(json_encode($rst));
}elseif($_GET['ac']=='loginchatsend'){
	$checkallban=C::t('#keke_chat#keke_chat_ban')->fetchfirst_byid($_GET['cid'],-1,'video');
	$keke_video_base = $_G['cache']['plugin']['keke_video_base'];
	if(!$checkallban && $keke_video_base['wlcstu']){
		loginchatsend();
	}
}elseif($_GET['ac']=='addban'){
	if($_GET['type']=='video'){
		$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($_GET['cid']);
		$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($kearr['cid']);
		$adminuids=C::t('#keke_chat#keke_chat_admin')->fetchfirst_byid($_GET['cid']);
		if($course['uid']!=$_G['uid'] && $_G['groupid']!=1 && !(in_array($_G['uid'],explode(',',$adminuids['adminuid'])))){
			exit(json_encode(array('err' => kekechat_gbk2utf(lang('plugin/keke_chat', '013')))));
		}
	}else{
		if($_G['groupid']!=1){
			exit(json_encode(array('err' => kekechat_gbk2utf(lang('plugin/keke_chat', '015')))));
		}
	}
	
	$_GET['topic']='chat_'.$_GET['cid'];
	if($_GET['op']=='all'){
		$checkallban=C::t('#keke_chat#keke_chat_ban')->fetchfirst_byid($_GET['cid'],-1,'video');
		if($_GET['allbancheckbox']=='on'){
			if(!$checkallban){
				$arr=array(
					'cid'=>$_GET['cid'],
					'uid'=>-1,
					'opuid'=>$_G['uid'],
					'type'=>'video',
					'time'=>TIMESTAMP
				);
				C::t('#keke_chat#keke_chat_ban')->insert($arr, false);
			}
			loginchatsend(lang('plugin/keke_chat', '023'));
		}else{
			C::t('#keke_chat#keke_chat_ban')->delete($checkallban['id']);
			loginchatsend(lang('plugin/keke_chat', '024'));
		}
		exit(json_encode(array('state' => 0)));
	}
	$uid = C::t('common_member')->fetch_uid_by_username(kekechat_utf2gbk($_GET['usernames']));
	if(!$uid){
		exit(json_encode(array('err' => kekechat_gbk2utf(lang('plugin/keke_chat', '012')))));
	}	
	if($_GET['type']=='video'){
		$validtime=C::t('#keke_video_base#keke_video_validtime')->fetchfirst_bycid($kearr['cid'],$uid);
		if(!$validtime && !($validtime['exp_time']==-1) && $validtime['exp_time']<TIMESTAMP){
			exit(json_encode(array('err' => kekechat_gbk2utf(lang('plugin/keke_chat', '014')))));
		}
	}
	$bandata=C::t('#keke_chat#keke_chat_ban')->fetchfirst_byid($_GET['cid'],$uid,$_GET['type']);
	switch ($_GET['forbiddentime']){
		case 2:
			$exptime=3600;
			$long=' 1 '.lang('plugin/keke_chat', '018');
			break;
		case 3:
		 	$exptime=43200;
			$long=' 12 '.lang('plugin/keke_chat', '018');
			break;
		case 4:
		  	$exptime=86400;
			$long=' 1 '.lang('plugin/keke_chat', '019');
			break;
		case 5:
			$exptime=-1;
			$long=lang('plugin/keke_chat', '020');
			break;
		default:
			$exptime=600;
			$long=' 10 '.lang('plugin/keke_chat', '021');
	}
	$exptimes=$exptime<0?$exptime:TIMESTAMP+$exptime;
	if($bandata['exptime'] && $bandata['exptime']!=-1 && $bandata['exptime']>TIMESTAMP){
		$exptimes=$bandata['exptime']+$exptime;
	}
	$arr=array(
		'cid'=>intval($_GET['cid']),
		'uid'=>$uid,
		'opuid'=>$_G['uid'],
		'exptime'=>$exptimes,
		'type'=>$_GET['type'],
		'time'=>TIMESTAMP,
	);
	if($bandata['id']){
		$arr['id']=$bandata['id'];
	}
	C::t('#keke_chat#keke_chat_ban')->insert($arr, false, true);
	loginchatsend($_GET['usernames'].' '.lang('plugin/keke_chat', '016').$long);
	exit(json_encode(array('state' => 0)));
}elseif($_GET['ac']=='getbanlist'){
	$ppp=8;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$tmpurl='plugin.php?id=keke_chat:ajax&ac=getbanlist&cid='.intval($_GET['cid']).'&type='.dhtmlspecialchars($_GET['type']).'&formhash='.FORMHASH;
	$where='type=\''.dhtmlspecialchars($_GET['type']).'\' AND cid='.intval($_GET['cid']).' AND (exptime>'.TIMESTAMP.' OR exptime<0)';
	$count_all=C::t('#keke_chat#keke_chat_ban')->count_all($where);
	$data=C::t('#keke_chat#keke_chat_ban')->fetch_all_ban($startlimit, $ppp, $where);
	foreach($data as $key=>$val){
		$data[$key]['username']=chatgetusname($val['uid']);
		$data[$key]['exptime']=$val['exptime']==-1?lang('plugin/keke_chat', '017'):dgmdate($val['exptime'], 'Y-m-d H:i:s');
	}
	$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
	$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
	$multipage=str_replace('href','data-href',$multipage);
	include template('keke_chat:block');
	exit($returns);
}elseif($_GET['ac']=='lift_ban'){	
	if($_GET['type']=='video'){
		$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($_GET['cid']);
		$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($kearr['cid']);
		if($course['uid']!=$_G['uid'] && $_G['groupid']!=1){
			exit(json_encode(array('err' => kekechat_gbk2utf(lang('plugin/keke_chat', '015')))));
		}
	}else{
		if($_G['groupid']!=1){
			exit(json_encode(array('err' => kekechat_gbk2utf(lang('plugin/keke_chat', '015')))));
		}
	}
	foreach($_GET['checkbox'] as $key=>$val){
		$arr[]=$key;
	}
	C::t('#keke_chat#keke_chat_ban')->delete($arr);
	exit(json_encode(array('state' => 0)));
}elseif($_GET['ac']=='chatadmin'){
	$cid=intval($_GET['cid']);
	$_GET['type']=dhtmlspecialchars($_GET['type']);
	include template('keke_chat:chat_win');
}elseif($_GET['ac']=='getchatadmin'){
	$cid=intval($_GET['cid']);
	$uids=C::t('#keke_chat#keke_chat_admin')->fetchfirst_byid($cid);
	if($uids['adminuid']){
		$chatadmindata=explode(',',$uids['adminuid']);
		foreach($chatadmindata as $val){
			$cadmins[]=array(
				'uid'=>$val,
				'username'=>chatgetusname($val)
			);
		}
	}
	include template('keke_chat:block');
	exit($chatadminlist);
}elseif($_GET['ac']=='setchatadmin'){
	$cid=intval($_GET['cid']);
	$kearr=C::t('#keke_video_base#keke_video_ke')->fetch_first_by_id($cid);
	$course=C::t('#keke_video_base#keke_video_course')->fetchfirst_byid($kearr['cid']);
	if($course['uid']!=$_G['uid'] && $_G['groupid']!=1){
		exit(json_encode(array('err' => kekechat_gbk2utf(lang('plugin/keke_chat', '015')))));
	}
	$adminuid=intval($_GET['adminuid']);
	if($_GET['op']=='add'){
		$userdata=getuserbyuid($adminuid);
		if(!$userdata){
			exit(json_encode(array('err' => kekechat_gbk2utf(lang('plugin/keke_chat', '012')))));
		}
	}
	$uids=C::t('#keke_chat#keke_chat_admin')->fetchfirst_byid($cid);
	if($uids['adminuid']){
		$chatadmindata=explode(',',$uids['adminuid']);
		foreach($chatadmindata as $key=>$val){
			if($adminuid==$val){
				if($_GET['op']=='add'){
					$iscf=1;
				}else{
					unset($chatadmindata[$key]);
				}
			}
		}
	}
	if($_GET['op']=='add'){
		if(!$iscf){
			$chatadmindata[]=$adminuid;
		}else{
			exit(json_encode(array('err' => kekechat_gbk2utf(lang('plugin/keke_chat', '022')))));
		}
	}
	if(!$chatadmindata){
		C::t('#keke_chat#keke_chat_admin')->delete($uids['cid']);
		exit(json_encode(array('state' => 0)));
	}
	$newuids=implode(",", $chatadmindata);
	$array=array(
		'cid'=>$cid,
		'adminuid'=>$newuids
	);
	C::t('#keke_chat#keke_chat_admin')->insert($array,true,true);
	exit(json_encode(array('state' => 0)));
}elseif($_GET['ac']=='checkallban'){
	$checkallban=C::t('#keke_chat#keke_chat_ban')->fetchfirst_byid($_GET['cid'],-1,'video');
	$return=$checkallban?1:0;
	exit(json_encode(array('state' => 0,'ret'=>$return)));
}