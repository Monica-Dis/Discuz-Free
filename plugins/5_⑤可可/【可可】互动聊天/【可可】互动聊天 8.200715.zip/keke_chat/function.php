<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function _getface(){
	global $_G;
	$keke_chat = $_G['cache']['plugin']['keke_chat'];
	$facegroup=explode(',',$keke_chat['facegroup']);
	$face[0]=C::t('#keke_chat#keke_chat_face')->fetch_all_by_fids($facegroup);
	$face[1]=C::t('#keke_chat#keke_chat_face')->fetch_allface_by_fids($facegroup);
	return $face;
}

function history(){
	global $_G;
	$keke_chat = $_G['cache']['plugin']['keke_chat'];
	if(empty($_GET['topic'])){
		return array(
			'Flag'=>101,
			'FlagString'=>lang('plugin/keke_chat', '001')
		);
	}
	$skip = 0;
	$num = $keke_chat['historynum']?intval($keke_chat['historynum']):30;
	if(!empty($_GET['skip'])){
		$skip=$_GET['skip'];
	}
	if(!empty($_GET['num'])){
		$num=$_GET['num'];
	}
	$ret=dmscurl("/v1/historys/".$_GET['topic']."/".$skip."/".$num);
	if($ret['FlagString']){
		return $ret;
	}
	$ret=array_reverse($ret);
	return array('Flag'=>100,'list'=>$ret);
}


function loginchatsend($msgs='',$topics=''){
	global $_G;
	if(!$msgs && !$_G['uid']){
		return;
	}
	$msg=$msgs?$msgs:$_G['username'].' '.lang('plugin/keke_chat', '004');
	$content=json_encode(array(
		'uid'=>'0',
		'username'=>kekechat_gbk2utf(lang('plugin/keke_chat', '002')),
		'topic'=>$_GET['topic'],
		'body'=>kekechat_gbk2utf($msg),
		'time'=>TIMESTAMP,
		'type'=>2,
	),true);
	
	$senret=dmscurl("/v1/messages/".$_GET['topic'],"POST",
		json_encode(array('body' => $content)));
	if(!$msgs){
		sleep(1);
		$delsen=dmscurl("/v1/historys/".$_GET['topic']."/uuid/".$senret['uuid'],"DELETE");
	}
}

function sendMsg(){
	global $_G;
	$username=kekechat_gbk2utf($_G['username']);
	if(empty($_GET['content'])){
		return array(
			'Flag'=>101,
			'FlagString'=>kekechat_gbk2utf(lang('plugin/keke_chat', '005'))
		);
	}
	if(!$_G['uid']){
		return array(
			'Flag'=>102,
			'FlagString'=>kekechat_gbk2utf(lang('plugin/keke_chat', '007'))
		);
	}
	$_GET['content']=chat_editor_safe_replace(kekechat_gbk2utf($_GET['content']));
	$_GET['content']=_chat_censor($_GET['content']);
	$content=json_encode(array(
		'uid'=>$_G['uid'],
		'username'=>$username,
		'topic'=>$_GET['topic'],
		'body'=>parsesmiles($_GET['content']),
		'time'=>TIMESTAMP,
		'to'=>$_GET['to']
	),true);
	$ret=dmscurl("/v1/messages/".$_GET['topic'],"POST",
		json_encode(array('body' => $content)));	
	if($ret['uuid']){
		$ret=array('Flag' =>100,'FlagString'=>'send msg success');
	}
	return $ret;
}

function parsesmiles($message) {
	global $_G;
	$message=dhtmlspecialchars($message);
	loadcache(array('smilies', 'smileytypes'));
	static $enablesmiles;
	if($enablesmiles === null) {
		$enablesmiles = false;
		if(!empty($_G['cache']['smilies']) && is_array($_G['cache']['smilies'])) {
			foreach($_G['cache']['smilies']['replacearray'] AS $key => $smiley) {
				$_G['cache']['smilies']['replacearray'][$key] = '<img src="'.STATICURL.'image/smiley/'.$_G['cache']['smileytypes'][$_G['cache']['smilies']['typearray'][$key]]['directory'].'/'.$smiley.'" smilieid="'.$key.'" border="0" alt="" />';
			}
			$enablesmiles = true;
		}
	}
	$enablesmiles && $message = preg_replace($_G['cache']['smilies']['searcharray'], $_G['cache']['smilies']['replacearray'], $message, $_G['setting']['maxsmilies']);
	return $message;
}



function dmscurl($path,$method="GET",$content="",$timeout=60){
	global $_G;
	$keke_chat = $_G['cache']['plugin']['keke_chat'];
	$host = "http://api.dms.aodianyun.com:80";
	if(function_exists('curl_init') && function_exists('curl_exec')){
		$ch = curl_init();
		$query_url = $host.$path;
		curl_setopt($ch,CURLOPT_URL,$query_url);
		curl_setopt($ch,CURLOPT_HEADER,false);
		curl_setopt($ch,CURLOPT_AUTOREFERER,true);
		curl_setopt($ch,CURLOPT_FOLLOWLOCATION,true);
		curl_setopt($ch,CURLOPT_FRESH_CONNECT,true);
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,$timeout);
		curl_setopt($ch,CURLOPT_TIMEOUT,$timeout);
		//	curl_setopt($ch,CURLOPT_USERAGENT,$useragent);
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
		curl_setopt($ch,CURLOPT_BINARYTRANSFER,true);
		curl_setopt($ch,CURLOPT_CUSTOMREQUEST,$method);
		   // curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
		if($method == 'POST') {
			curl_setopt($ch,CURLOPT_POST,true);
			curl_setopt($ch,CURLOPT_POSTFIELDS,$content);
		} else if($method == 'PUT') {
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "PUT");   
			curl_setopt($ch, CURLOPT_POSTFIELDS,$content);
		} else if($method == 'DELETE') {
			curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
			curl_setopt($ch, CURLOPT_POSTFIELDS,$content);
		}
		$authorization = 'Authorization: dms '.$keke_chat['s_key'];
		$header = array($authorization,'Content-Type: application/json');
		curl_setopt($ch,CURLOPT_HTTPHEADER, $header);
		$response = curl_exec($ch);
		$response_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
		curl_close($ch);
		if($response_code == 200 || $response_code == 201 || $response_code == 204) {
			$rst = json_decode(trim($response),true);
		} else {
			$rr = json_decode(trim($response),true);
			if($rr) {
				$rst = $rr;
			} else {
				$rst = array(
					'Flag'=>$response_code,
					'FlagString'=>trim($response)
				);
			}
		}
	}else{
		$rst = array(
				'Flag'=>999,
				'FlagString'=>'curl_err'
		);
	}
	return $rst;
}

function _chat_censor($msg){
	global $_G;
	$keke_chat = $_G['cache']['plugin']['keke_chat'];
	$censorarr=explode(',',kekechat_gbk2utf($keke_chat['censor']));
	$retmsg=str_replace($censorarr, "***", $msg);
	return $retmsg;
}

function chat_editor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}

function kekechat_utf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return kekevideo_gbk2utf($data);
	}
}
function kekechat_gbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}

function chatgetusname($uid){
	
	$userdata=getuserbyuid($uid);

	return $userdata['username'];
}