<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
exit('Access Denied');
}
global $_G;
loadcache('plugin');
$keke_domain = $_G['cache']['plugin']['keke_domain'];
include_once DISCUZ_ROOT."source/plugin/keke_domain/function.php";
if (submitcheck("forumset")) {
	if(is_array($_GET['delete'])) {
		C::t('#keke_domain#keke_domain')->delete($_GET['delete']);
	}
	_keke_updatecache();
	cpmsg(lang('plugin/keke_domain', '008'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_domain&pmod=admin_domain', 'succeed');
}
if($_GET['ac']){
	if($_GET['formhash'] != $_G['formhash']) {
		exit('Access Denied');
	}
	$domainid=intval($_GET['domainid']);
	$domain_data = C::t('#keke_domain#keke_domain')->fetch_domain_data($domainid);
	if($_GET['ac']=='edit'){
		if (submitcheck("editsubmit")) {
			if(!$_GET['domain']){
				cpmsg(lang('plugin/keke_domain', '009'), '', 'error');
			}
			$arr=array(
				'identifier'=> $_GET['identifiers'],
				'domain'=> $_GET['domain'],
				'entrance'=> $_GET['entrance'],
			);
			if($domainid){
				C::t('#keke_domain#keke_domain')->update($domainid,$arr);
			}else{
				C::t('#keke_domain#keke_domain')->insert($arr);
			}
			_keke_updatecache();
			cpmsg(lang('plugin/keke_domain', '008'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_domain&pmod=admin_domain&formhash='.FORMHASH, 'succeed');
		}
		
		$where=$keke_domain['onlykeke']?" AND identifier LIKE '%".daddslashes('keke_','%_')."%'":'';
		
		$alldomain=C::t('#keke_domain#keke_domain')->fetch_alldomain();
		foreach($alldomain as $v){
			$identifier_arr[$v['identifier']]=$v['identifier'];
		}
		if($identifier_arr && !$domainid)$where.=' AND identifier NOT IN ('.dimplode($identifier_arr).')';
		$plugin_data=C::t('#keke_domain#keke_domain')->fetch_all_by_allplugin(0,200,$where,'common_plugin');
		foreach($plugin_data as $pluginval){
			$pluginopt.='<option value="'.$pluginval['identifier'].'" '.($domain_data['identifier']==$pluginval['identifier']?'selected="selected"':'').'>'.$pluginval['name'].'</option>';
		}
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_domain&ac=edit");
		showtableheader(lang('plugin/keke_domain', '002'));
		showsetting(lang('plugin/keke_domain', '007'), '','', "<select name='identifiers'>".$pluginopt."</select>");
		showsetting(lang('plugin/keke_domain', '005'),'domain',$domain_data['domain'],'text','','',lang('plugin/keke_domain', '006'));
		showsetting(lang('plugin/keke_domain', '003'),'entrance',$domain_data['entrance'],'text','','',lang('plugin/keke_domain', '004'));
		echo '<input name="domainid" type="hidden" value="'.$domain_data['id'].'" />';
		showsubmit('editsubmit');
		showtablefooter(); //Dism��taobao��com
		showformfooter(); //Dism_taobao_com
		exit();
	}
	cpmsg(lang('plugin/keke_domain', '008'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_domain&pmod=admin_domain', 'succeed');
}
showtips(lang('plugin/keke_domain', '015'));
showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_domain");
showtableheader(lang('plugin/keke_domain', '010'));

showsubtitle(array('del',lang('plugin/keke_domain', '001'),lang('plugin/keke_domain', '005'),lang('plugin/keke_domain', '011'),lang('plugin/keke_domain', '012')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_domain&pmod=admin_domain';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
    $where='';
	$allcount = C::t('#keke_domain#keke_domain')->count_by_allplugin($where);
	if($allcount){
        $pluginids=array();
		$plugin_data=C::t('#keke_domain#keke_domain')->fetch_all_by_allplugin($startlimit,$ppp,$where);
		foreach($plugin_data as $key=>$val){
			$pluginids[]=$val['identifier'];
		}
		$plugininfo=C::t('#keke_domain#keke_domain')->fetch_all_by_pluginids($pluginids);
		foreach($plugin_data as $k=>$v){
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$v['id'].'" />';
			$table[1] = $plugininfo[$v['identifier']]['name'];
			$table[2] = $v['domain'];
			$table[3] = $v['entrance']?$v['entrance']:$v['identifier'];
			$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_domain&pmod=admin_domain&ac=edit&domainid='.$v['id'].'&formhash='.FORMHASH.'">'.lang('plugin/keke_domain', '013').'</a>';
			showtablerow('',array(), $table);
		}
	}
showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_domain&pmod=admin_domain&ac=edit&formhash='.FORMHASH.'" class="addtr">'.lang('plugin/keke_domain', '014').'</a>');
showtablefooter(); //Dism��taobao��com
showformfooter(); //Dism_taobao_com