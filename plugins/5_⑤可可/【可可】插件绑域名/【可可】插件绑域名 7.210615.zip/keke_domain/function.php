<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}
function _keke_updatecache($type=0){
    $data=C::t('common_setting')->fetch('domain', true);
	$data['defaultindex'] = isset($data['defaultindex']) && $data['defaultindex'] != '#' ? $data['defaultindex'] : '';
	$data['holddomain'] = isset($data['holddomain']) ? $data['holddomain'] : '';
	$data['list'] = array();
	foreach(C::t('common_domain')->fetch_all_by_idtype(array('plugin')) as $value) {
		if($value['idtype'] == 'plugin') {
			$plugin = C::t('common_plugin')->fetch($value['id']);
			if(!$plugin || !$plugin['available']) {
				continue;
			}
			$value['id'] = $plugin['identifier'];
		}
		$data['list'][$value['domain'].'.'.$value['domainroot']] = array('id' => $value['id'], 'idtype' => $value['idtype']);
	}
	_keke_writetocache('domain', (!$type?"@include_once 'source/plugin/keke_domain/keke_domain.php';\n":'').getcachevars(array('domain' => $data)));
    $type?Cleaninclude():Writeinclude();
	$domaindata=C::t('#keke_domain#keke_domain')->fetch_alldomain();
	if($domaindata){
		$jump_code='';
		foreach($domaindata as $val){
			foreach(explode(',',$val['domain']) as $domain){
				$jump_code.='
			if($_SERVER [\'HTTP_HOST\']==\''.$domain.'\'){
				$_GET[\'id\']=\''.($val['entrance']?$val['entrance']:$val['identifier']).'\';
			}';
			}
		}
		$jump_code.='
			if($_GET[\'id\']){
				require_once \'plugin.php\';
				exit;
			}';
		_keke_writetocache('domain', $jump_code."\n",'keke_',1);
	}	
}

function _keke_writetocache($script, $cachedata, $prefix = 'cache_',$type=0) {
	global $_G;
	if($type){
		$dir = DISCUZ_ROOT.'./source/plugin/keke_domain/';
	}else{
		$dir = DISCUZ_ROOT.'./data/sysdata/';
		if(!is_dir($dir)) {
			dmkdir($dir, 0777);
		}
	}
	if($fp = @fopen("$dir$prefix$script.php", 'wb')) {
		fwrite($fp, "<?php\n".(!$type?"//Discuz! cache file, DO NOT modify me!\n//Identify: ".md5($prefix.$script.'.php'.$cachedata.$_G['config']['security']['authkey'])."\n\n":'')."$cachedata?>");
		fclose($fp);
	} else {
		exit('Can not write to cache files, please check directory ./data/ and ./data/sysdata/ .');
	}
}

function KekeGetindexcode(){
    return KekeReadFile('./index.php');
}

function Writeinclude(){
    if(!(strpos(KekeGetindexcode(), 'keke_domain.php') !== false)){
        $NewIndexFile = str_ireplace('<?php', "<?php\n@include_once 'source/plugin/keke_domain/keke_domain.php';\n", KekeGetindexcode());
        KekeWriteFile('./index.php', $NewIndexFile);
    }
}

function Cleaninclude(){
    if(strpos(KekeGetindexcode(), 'keke_domain.php') !== false) {
        $NewIndexFile = str_ireplace("\n@include_once 'source/plugin/keke_domain/keke_domain.php';\n", "", KekeGetindexcode());
        KekeWriteFile('./index.php', $NewIndexFile);
    }
}

function KekeReadFile($file) {
    if (file_exists($file) === false) {
        return '';
    }
    $fp = fopen($file,'r');
    $return = '';
    while (!feof($fp)) {
        $return .= fgets($fp, 4096);
    }
    fclose($fp);
    return $return;
}

function KekeWriteFile($file, $writecode) {
    $fp = fopen($file, 'w');
    fwrite($fp, $writecode);
    fclose($fp);
}