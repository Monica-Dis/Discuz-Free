<?php
if (! defined ('IN_DISCUZ')) {
	exit('Access Denied');
}

function _get_threaddata($tid){
	return $t_data=C::t('forum_thread')->fetch($tid);
}