<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_klhb= DB::table("keke_klhb");
$keke_klhb_log= DB::table("keke_klhb_log");

$sql = <<<EOF
CREATE TABLE `$keke_klhb` (
  `id` int(10) NOT NULL auto_increment,
  `uid` int(10) NOT NULL,
  `tid` int(50) NOT NULL,
  `credit` int(10) NOT NULL,
  `totalmoney` int(10) NOT NULL,
  `num` int(10) NOT NULL,
  `mod` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  `endtime` int(10) NOT NULL,
  `code` mediumtext NOT NULL,
  `state` int(10) NOT NULL default '1',
  `hash` int(50) NOT NULL,
  `donemoney` int(10) NOT NULL,
  `donenum` int(10) NOT NULL,
  `hide` int(10) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `tid_total_num` (`tid`,`totalmoney`,`num`)
)ENGINE=MyISAM;

CREATE TABLE `$keke_klhb_log` (
  `id` int(10) NOT NULL auto_increment,
  `usname` varchar(50) NOT NULL,
  `uid` int(10) NOT NULL,
  `tid` int(50) NOT NULL,
  `money` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM;


EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_klhb/install.php');