<?php
if (! defined ('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

echo "<script language='javascript'>";
echo "window.location.href='http://dism.taobao.com/?ac=developer&id=50735'";
echo "</script>";
exit;


?>
