<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_klhb'));
while($row = DB::fetch($query)) {
	$col_field[]=$row['Field']; 
}

if(!in_array('hide', $col_field)){
	$sql = "Alter table ".DB::table('keke_klhb')." add `hide` int(10) NOT NULL;"; 
	DB::query($sql); 
}

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_klhb/discuz_plugin_keke_klhb_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_klhb/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_klhb/upgrade.php');

?>