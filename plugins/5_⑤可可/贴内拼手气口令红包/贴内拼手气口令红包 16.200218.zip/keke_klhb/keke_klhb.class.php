<?php
if (! defined ('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_keke_klhb_forum{
	function post_top(){	
		global $_G ;
		$keke_klhb = $_G['cache']['plugin']['keke_klhb'];
		$actions=$_GET['action'];
		$forumFields = C::t('forum_forumfield')->fetch($_G['fid']);
		$isgroup=$forumFields['founderuid'] ? 1 : 0;
		$section = empty($keke_klhb['bk']) ? array() : unserialize($keke_klhb['bk']);
		if(!is_array($section)) $section = array();
		if((!$isgroup && !(empty($section[0]) || in_array($_G['fid'],$section))) || ($isgroup && !$keke_klhb['qz'])){
			return;
		}
		$mod=intval($_GET['keke_klhb_lx']);
		$num=intval($_GET['keke_klhb_num']);
		$totalmoney=intval($_GET['keke_klhb_totalmoney']);
		$endtime=checkmobile() ? intval($_G['timestamp']) : strtotime($_GET['keke_klhb_time']);
		$crtdit=intval($_GET['keke_klhb_credit']);
		$creditname=$_G['setting']['extcredits'][$crtdit]['title'];
		$off=intval($_GET['fhb']);
		if(submitcheck('topicsubmit')){
			$membercount = C::t('common_member_count')->fetch($_G['uid']);					
			$extcredits=$membercount['extcredits'.$crtdit];
			if($off){
				if($extcredits<$totalmoney){
					showmessage(lang('plugin/keke_klhb', 'f01').$creditname.lang('plugin/keke_klhb', 'f02'),'');
				}elseif(!$num){
					showmessage(lang('plugin/keke_klhb', 'f03'),'');
				}elseif(!$totalmoney){
					showmessage(lang('plugin/keke_klhb', 'f05'),'');
				}elseif(!$endtime){
					showmessage(lang('plugin/keke_klhb', 'f06'),'');
				}
				if($totalmoney<$num){
					showmessage(lang('plugin/keke_klhb', 'f12'),'');
				}
			}
		}
		
		if($actions=="newthread"&&$_G['uid']>0){
			$fbyhz = empty($keke_klhb['fbyhz']) ? array() : unserialize($keke_klhb['fbyhz']);
			if(!(empty($fbyhz[0]) || in_array($_G['groupid'],$fbyhz))){
				return;
			}	
			$cre=$keke_klhb['jf'];
			foreach($_G['setting']['extcredits'] as $k =>$v){
			if($k==$cre)
				$creop.= '<option value="'.$k.'" selected>'.$v['title'].'</option>';
			else
				$creop.= '<option value="'.$k.'">'.$v['title'].'</option>';
			}
			$time=dgmdate(($_G['timestamp']+(intval($keke_klhb['sx'])*3600)), 'Y-m-d H:i:s');
			include template('keke_klhb:input');
			$inputhook=lang('plugin/keke_klhb', 'f07').'</span>';
			if($actions=="edit")$lx='';
			if(!$_G['setting']['rewritestatus']){
				$_G['setting']['rewritestatus'] = true;
			}
			$_G['setting']['output']['str']['search']['keke_integralmall_'] = $inputhook;
			$_G['setting']['output']['str']['replace']['keke_integralmall_'] = $inputhook.''.$lx.'</div></div>'.$return;
			if(checkmobile()){
				return $lx.$return;
			}else{
				return '';
			}
			
		}
		
		
	}
	
	
	function viewthread_postbottom_output(){
		return $this->_showhb(2);
	}
	
	function viewthread_posttop_output(){
		return $this->_showhb(1);
	}
	
	function _showhb($type){
		global $_G;
		$keke_klhb = $_G['cache']['plugin']['keke_klhb'];
		if($type!=$keke_klhb['wz']){
			return array();
		}
		$isgroup=$_G['thread']['isgroup'];
		$section = empty($keke_klhb['bk']) ? array() : unserialize($keke_klhb['bk']);
		if(!is_array($section)) $section = array();
		if((!$isgroup && !(empty($section[0]) || in_array($_G['fid'],$section))) || ($isgroup && !$keke_klhb['qz'])){
			return array();
		}
		$return=array();
		$hbdata=C::t('#keke_klhb#keke_klhb')->fetchfirst_bytid($_G['tid']);
		if(!$hbdata['id'] && !checkmobile()){
			return array();
		}
		$sur_count=$hbdata['num']-$hbdata['donenum'];
		$sur_money=$hbdata['totalmoney']-$hbdata['donemoney'];
		if(($hbdata['endtime']<$_G['timestamp']) && $sur_count && $sur_money){
			if($sur_count && $sur_money){
				updatemembercount($hbdata['uid'], array('extcredits'.$hbdata['credit'].''=>$sur_money), true, '', 0, '',lang('plugin/keke_klhb', 'f18'),lang('plugin/keke_klhb', 'f19'));
				$newnum=$hbdata['num']-$sur_count;
				$newmoney=$hbdata['totalmoney']-$sur_money;
				C::t('#keke_klhb#keke_klhb')->update($hbdata["id"],array('totalmoney' =>$newmoney,'num'=>$newnum));
			}
		}
		$creditname=$_G['setting']['extcredits'][$hbdata['credit']]['title'];
		include template('keke_klhb:show');
		if($_G['forum_firstpid']){
			if(checkmobile() && !$hbdata['id']){
				$fbyhz = empty($keke_klhb['fbyhz']) ? array() : unserialize($keke_klhb['fbyhz']);
				if(!(empty($fbyhz[0]) || in_array($_G['groupid'],$fbyhz))){
					return array();
				}
				if($_G['thread']['authorid']==$_G['uid']){
					$return[0]=$addhb;
				}
			}else{
				$return[0]=$rts;
			}
			
		}
		return $return;
	}
	
	
	
	function viewthread_postheader_output(){
		global $_G, $postlist;
		$keke_klhb = $_G['cache']['plugin']['keke_klhb'];
		$section = empty($keke_klhb['bk']) ? array() : unserialize($keke_klhb['bk']);
		$isgroup=$_G['thread']['isgroup'];
		if(!is_array($section)) $section = array();
		if((!$isgroup && !(empty($section[0]) || in_array($_G['fid'],$section))) || ($isgroup && !$keke_klhb['qz'])){
			return;
		}
		$fbyhz = empty($keke_klhb['fbyhz']) ? array() : unserialize($keke_klhb['fbyhz']);
		if(!(empty($fbyhz[0]) || in_array($_G['groupid'],$fbyhz))){
			return;
		}	
		$hbdata=C::t('#keke_klhb#keke_klhb')->fetchfirst_bytid($_G['tid']);
		$code_count = C::t('forum_post')->count_by_search('tid:'.$_G['tid'], $_G['tid'], $hbdata['code'], null, null, $_G['uid']);
		if(empty($code_count)){
			foreach($postlist as $key=>$val){
				$result=str_ireplace($hbdata['code'],lang('plugin/keke_klhb', 'f23'),$val['message']);
				$postlist[$key]['message']=$result;
			}
		}
		
		if(!($_G['thread']['authorid']==$_G['uid'])){
			return;
		}
		
		include template('keke_klhb:show');
		if($_G['forum_firstpid']){
			$return[0]=$edithb;
		}
		return $return;
	}
	function post_message($param) {
		global $_G;
		$keke_klhb = $_G['cache']['plugin']['keke_klhb'];
		$param = $param['param'];
		if(!$_G['uid'])return;	
		$forumFields = C::t('forum_forumfield')->fetch($param[2]['fid']);
		$isgroup=$forumFields['founderuid'] ? 1 : 0;
		$section = empty($keke_klhb['bk']) ? array() : unserialize($keke_klhb['bk']);
		if(!is_array($section)) $section = array();
		if((!$isgroup && !(empty($section[0]) || in_array($_G['fid'],$section))) || ($isgroup && !$keke_klhb['qz'])){
			return;
		}
		$off=intval($_GET['fhb']);
		if(!$off){
			return;
		}
		if($param[0]=="post_newthread_succeed" || $param[0]=="post_newthread_mod_succeed"){
			$tid = intval($param[2]['tid']);
			$mod=intval($_GET['keke_klhb_lx']);
			$num=abs(intval($_GET['keke_klhb_num']));
			$totalmoney=abs(intval($_GET['keke_klhb_totalmoney']));
			$endtime=strtotime($_GET['keke_klhb_time']);
			$code=daddslashes(dhtmlspecialchars($_GET['keke_klhb_code']));
			$crtdit=intval($_GET['keke_klhb_credit']);
			$arr = array(
				'uid' => $_G['uid'],
				'tid'=> $tid,
				'credit'=> $crtdit,
				'totalmoney' => $totalmoney,
				'num' => $num,
				'mod' => $mod,
				'code' => $code,
				'time'=> $_G['timestamp'],
				'endtime'=>$endtime,
				'hash'=>random(6,1),
				'hide'=>intval($_GET['hidekl']),
			);
			$id=C::t('#keke_klhb#keke_klhb')->insert($arr, true);
			if($id){
				updatemembercount($_G['uid'], array('extcredits'.$crtdit.''=>-$totalmoney), true, '', 0, '',lang('plugin/keke_klhb', 'f08'),lang('plugin/keke_klhb', 'f09'));
			}
		}
	}
	
	function forumdisplay_thread_output(){
		return $this->_listhb(1);
	}
	
	
	function forumdisplay_thread_subject_output(){
		return $this->_listhb(2);
	}
	
	
	
	function _listhb($n){
		global $_G, $threadlist;
		$keke_klhb = $_G['cache']['plugin']['keke_klhb'];
		if((empty($_G['forum']['picstyle']) || $_G['cookie']['forumdefstyle']) && $n==1){
			return array();
		}
		$forumFields = C::t('forum_forumfield')->fetch($_G['fid']);
		$isgroup=$forumFields['founderuid'] ? 1 : 0;
		$section = empty($keke_klhb['bk']) ? array() : unserialize($keke_klhb['bk']);
		if(!is_array($section)) $section = array();
		if((!$isgroup && !(empty($section[0]) || in_array($_G['fid'],$section))) || ($isgroup && !$keke_klhb['qz'])){
			return;
		}
		foreach ($threadlist as $v) {if (is_numeric($v['tid'])) $tidlist .= $v['tid'].',';}
		if ($tidlist){$tidlist = substr($tidlist, 0, -1);}else{return;}
		$hbdata=C::t('#keke_klhb#keke_klhb')->fetch_all_by_tid($tidlist);
		foreach($hbdata as $ks=>$vs){
			$hbarr[$vs['tid']]=$vs;
		}
		include template('keke_klhb:show');
		$n=0;
		$ret=array();
		$liststy=$keke_klhb['stys']?'<style>'.dhtmlspecialchars($keke_klhb['stys']).'</style>':$liststys;
		foreach($threadlist as $k => $v){
			$hbstr='';
			if($hbarr[$v['tid']]){
				$sur_count=$hbarr[$v['tid']]['num']-$hbarr[$v['tid']]['donenum'];
				$sur_money=$hbarr[$v['tid']]['totalmoney']-$hbarr[$v['tid']]['donemoney'];
				if($sur_count>0 && $hbarr[$v['tid']]['endtime']>$_G['timestamp']){
					$listwz=str_replace('[num]', $sur_count,$keke_klhb['listwz']);
					$listwz=str_replace('[money]', $sur_money,$listwz);
					$lists=str_replace('[wz]', $listwz,$list);
					$endtimehtm='<span class="sytime end_time"><SPAN class="time" endTime="'.dgmdate($hbarr[$v['tid']]['endtime'], 'Y-m-d H:i:s').'">...</SPAN></span>';	
					$lists=str_replace('[endtime]', $endtimehtm,$lists);
					$js=($n==0)?$timejs.$liststy:$liststy;
					$hbstr=$js.$lists;
					//$_G['forum_threadlist'][$k]['subject']=$hbstr;
				}
				$n++;	
			}
			$ret[]=$hbstr;
			
		}
		return $ret;
	}
	
	
}

class plugin_keke_klhb_group extends plugin_keke_klhb_forum{
}


class mobileplugin_keke_klhb_forum extends plugin_keke_klhb_forum{
	function viewthread_posttop_mobile_output(){
		return $this->_showhb(1);
	}
	
	function viewthread_postbottom_mobile_output(){
		return $this->_showhb(2);
	}
	
	function post_bottom_mobile(){
		return $this->post_top();
	}

}
