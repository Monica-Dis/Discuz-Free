<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_klhb= DB::table("keke_klhb");
$keke_klhb_log= DB::table("keke_klhb_log");
$sql = <<<EOF
DROP TABLE IF EXISTS `$keke_klhb`;
DROP TABLE IF EXISTS `$keke_klhb_log`;
EOF;
runquery($sql);
$finish = true;
?>