<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_klhb extends discuz_table
{
	public function __construct() {
		$this->_table = 'keke_klhb';
		$this->_pk = 'id';
		parent::__construct();
	}
	
	
	public function fetchfirst_bytid($tids) {
		return DB::fetch_first("SELECT * FROM %t WHERE tid=%d", array($this->_table,$tids));
	}
	
	
	public function fetch_all_by_tid($tid) {
		return DB::fetch_all("SELECT * FROM %t where tid in ($tid)", array($this->_table,$tid));
	}
	
	
	public function delete_by_tid($tid) {
		return DB::query("delete FROM %t where tid=%d", array($this->_table,$tid));
	}
	
	
}
//From: Dism_taobao_com
?>