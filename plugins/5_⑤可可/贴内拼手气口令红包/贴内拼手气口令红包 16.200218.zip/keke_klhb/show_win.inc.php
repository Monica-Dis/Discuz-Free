<?php
/**
 * 
 * DisM!��Ʒ ������Ʒ
 * DisM!Ӧ���������� https://dism.Taobao.Com
 * רҵDiscuz!Ӧ�ò����ģ������ɹ��ṩ�����ط��񡢼���֧�ֵ�ȫ��λ����...
 * ����������Ϊվ���ṩ����Discuz!Ӧ�ö�Ŭ��
 * E-mail: dism.taobao@qq.com
 * ����ʱ��: ��һ����������09:00-12:00, ����13:00-18:00, ����19:30-23:30(����������Ϣ)
 * DisM!�û�����Ⱥ: ��Ⱥ778390776
 * 
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_klhb = $_G['cache']['plugin']['keke_klhb'];
include_once DISCUZ_ROOT . 'source/plugin/keke_klhb/identity.inc.php';
if (!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
if ($_GET['formhash'] != $_G['formhash']) {
	return;
}
$hash = $_GET['hash'];
$ac = $_GET['ac'];
$tid = intval($_GET['tid']);
$hbdata = C::t('#keke_klhb#keke_klhb')->fetchfirst_bytid($tid);
$creditname = $_G['setting']['extcredits'][$hbdata['credit']]['title'];
$units = $_G['setting']['extcredits'][$hbdata['credit']]['unit'];
$sur_count = $hbdata['num'] - $hbdata['donenum'];
$sur_money = $hbdata['totalmoney'] - $hbdata['donemoney'];
$time = dgmdate($hbdata['endtime'], 'Y-m-d H:i:s');
if ($ac == 'qiang') {
	if ($hash != $hbdata['hash']) {
		return;
	}
	$yhz = empty($keke_klhb['yhz']) ? array() : unserialize($keke_klhb['yhz']);
	$hbdata['code'] = dhtmlspecialchars($hbdata['code']);
	$uidhbcount = C::t('#keke_klhb#keke_klhb_log')->count_by_uid($_G['uid'], $tid);
	if ($_GET['op']) {
		$t_data = C::t('forum_thread')->fetch($tid);
		include_once libfile('function/forum');
		$fid = $t_data['fid'];
		$subject = $t_data['subject'];
		$pid = insertpost(array('fid' => $fid, 'tid' => $tid, 'first' => 0, 'author' => $_G['username'], 'authorid' => $_G['uid'], 'subject' => '', 'dateline' => $_G['timestamp'], 'message' => $hbdata['code'], 'useip' => $_G['clientip'], 'invisible' => 0, 'anonymous' => 0, 'usesig' => 1, 'htmlon' => 0, 'bbcodeoff' => 0, 'smileyoff' => 0 - 1, 'parseurloff' => 0, 'attachment' => 0));
		if ($pid) {
			C::t('forum_thread')->update($tid, array('`replies`=`replies`+1', '`lastpost`=' . $_G['timestamp'], 'lastposter=\'' . $_G['username'] . '\''), false, false, 0, true);
			C::t('common_member_count')->increase(array($_G['uid']), array('posts' => 1));
			C::t('forum_forum')->update_forum_counter($fid, 0, 1, 1);
			$lastpost = $tid . '	' . $subject . '	' . $_G['timestamp'] . '	' . $_G['username'];
			C::t('forum_forum')->update(array('fid' => $fid), array('lastpost' => $lastpost));
		}
	}
	$state = 1;
	if (!empty($yhz[0]) && !in_array($_G['groupid'], $yhz)) {
		$state = 6;
	} elseif ($sur_count < 1) {
		$state = 0;
	} elseif ($hbdata['endtime'] < $_G['timestamp']) {
		$state = 2;
	} elseif ($hbdata['endtime'] < $_G['timestamp']) {
		$state = 2;
	} elseif ($hbdata['code']) {
		$code_count = DB::result_first('select count(1) from ' . DB::table('forum_post') . ' where tid=' . $tid . ' AND authorid=' . $_G['uid'] . ' AND message LIKE \'%' . addcslashes($hbdata['code'], '%_') . '%\' limit 1');
		if (!$code_count) {
			$state = 3;
		}
	}
	if ($keke_klhb['jg']) {
		$lasttime = DB::result_first('select time from ' . DB::table('keke_klhb_log') . ' where uid=' . $_G['uid'] . ' ORDER BY TIME DESC');
		$jgsc = intval($keke_klhb['jg']) * 60;
		if ($lasttime + $jgsc > TIMESTAMP) {
			$state = 8;
			$ctime = date('m-d H:i', $lasttime + $jgsc);
		}
	}
	if ($uidhbcount > 0) {
		$state = 5;
	}
	if ($state == 1) {
		$hbmoney = intval($sur_money / $sur_count);
		if ($hbdata['mod'] == 2) {
			if ($sur_count > 1) {
				$difference = $keke_klhb['sf'] == 1 ? ($sur_money - $sur_count) / ($sur_count / 2) : $sur_money - $sur_count;
				$difference = $difference ? $difference : 1;
				$hbmoney = intval(mt_rand(1, $difference));
			} else {
				if ($sur_count == 1) {
					$hbmoney = intval($sur_money);
				}
			}
		}
		$arr = array('uid' => $_G['uid'], 'usname' => $_G['username'], 'tid' => $tid, 'money' => $hbmoney, 'time' => $_G['timestamp']);
		$id = C::t('#keke_klhb#keke_klhb_log')->insert($arr);
		if ($id) {
			updatemembercount($_G['uid'], array('extcredits' . $hbdata['credit'] . '' => $hbmoney), true, '', 0, '', lang('plugin/keke_klhb', 'f11'), lang('plugin/keke_klhb', 'f10'));
		}
		$donemoney = $hbdata['donemoney'] + $hbmoney;
		$donenum = $hbdata['donenum'] + 1;
		C::t('#keke_klhb#keke_klhb')->update($hbdata['id'], array('donemoney' => $donemoney, 'donenum' => $donenum));
		if ($keke_klhb['ht'] && !$hbdata['code'] || $keke_klhb['ht'] && $hbdata['code'] && !$keke_klhb['ban']) {
			$autoreplytmp = dhtmlspecialchars($keke_klhb['htnr']);
			$autoreplyarr = explode('===', trim($autoreplytmp));
			$autoreply = $autoreplyarr[mt_rand(0, count($autoreplyarr) - 1)];
			$autoreply = str_ireplace('[money]', '' . $hbmoney . $creditname . '', $autoreply);
			$t_data = C::t('forum_thread')->fetch($tid);
			include_once libfile('function/forum');
			$fid = $t_data['fid'];
			$subject = $t_data['subject'];
			$pid = insertpost(array('fid' => $fid, 'tid' => $tid, 'first' => 0, 'author' => $_G['username'], 'authorid' => $_G['uid'], 'subject' => '', 'dateline' => $_G['timestamp'], 'message' => $autoreply, 'useip' => $_G['clientip'], 'invisible' => 0, 'anonymous' => 0, 'usesig' => 1, 'htmlon' => 0, 'bbcodeoff' => 0, 'smileyoff' => 0 - 1, 'parseurloff' => 0, 'attachment' => 0));
			if ($pid) {
				C::t('forum_thread')->update($tid, array('`replies`=`replies`+1', '`lastpost`=' . $_G['timestamp'], 'lastposter=\'' . $_G['username'] . '\''), false, false, 0, true);
				C::t('common_member_count')->increase(array($_G['uid']), array('posts' => 1));
				C::t('forum_forum')->update_forum_counter($fid, 0, 1, 1);
				$lastpost = $tid . '	' . $subject . '	' . $_G['timestamp'] . '	' . $_G['username'];
				C::t('forum_forum')->update(array('fid' => $fid), array('lastpost' => $lastpost));
			}
		}
	}
} elseif ($ac == 'list') {
	$list = C::t('#keke_klhb#keke_klhb_log')->fetchall_bytid($tid);
	if (checkmobile()) {
		include template('keke_klhb:list');
		exit(0);
	}
} elseif ($ac == 'del') {
	if ($hbdata['uid'] = $_G['uid'] && $keke_klhb['hbdel']) {
		$del_time = $keke_klhb['deltime'] ? intval($keke_klhb['deltime']) : 0;
		$stamp = $del_time * 3600;
		$space = $_G['timestamp'] - $hbdata['time'];
		if ($stamp > 0 && $space < $stamp) {
			showmessage(lang('plugin/keke_klhb', 'f17') . $del_time . lang('plugin/keke_klhb', 'f22'), 'forum.php?mod=viewthread&tid=' . $tid);
		}
		C::t('#keke_klhb#keke_klhb')->delete_by_tid($tid);
		if ($sur_money) {
			updatemembercount($hbdata['uid'], array('extcredits' . $hbdata['credit'] . '' => $sur_money), true, '', 0, '', lang('plugin/keke_klhb', 'f20'), lang('plugin/keke_klhb', 'f21'));
		}
		showmessage(lang('plugin/keke_klhb', 'f13'), 'forum.php?mod=viewthread&tid=' . $tid, '', array('alert' => 'right'));
	} else {
		showmessage(lang('plugin/keke_klhb', 'f15'), 'forum.php?mod=viewthread&tid=' . $tid);
	}
} elseif ($ac == 'edit') {
	$threaddata = C::t('forum_thread')->fetch($tid);
	if ($threaddata['authorid'] != $_G['uid']) {
		showmessage(lang('plugin/keke_klhb', 'f15'));
	}
	if (submitcheck('sub')) {
		$hbid = intval($_GET['hbid']);
		$mod = intval($_GET['keke_klhb_lx']);
		$num = intval($_GET['keke_klhb_num']);
		$totalmoney = intval($_GET['keke_klhb_totalmoney']);
		$endtime = strtotime($_GET['keke_klhb_time']);
		$code = daddslashes(dhtmlspecialchars($_GET['keke_klhb_code']));
		$crtdit = intval($_GET['keke_klhb_credit']);
		$membercount = C::t('common_member_count')->fetch($_G['uid']);
		$extcredits = $membercount['extcredits' . $crtdit];
		$creditname = $_G['setting']['extcredits'][$crtdit]['title'];
		if ($extcredits < $totalmoney) {
			showmessage(lang('plugin/keke_klhb', 'f01') . $creditname . lang('plugin/keke_klhb', 'f02'), '');
		} elseif (!$num && $_GET['editid'] != 1) {
			showmessage(lang('plugin/keke_klhb', 'f03'), '');
		} elseif (!$totalmoney && $_GET['editid'] != 1) {
			showmessage(lang('plugin/keke_klhb', 'f05'), '');
		} elseif (!$endtime) {
			showmessage(lang('plugin/keke_klhb', 'f06'), '');
		}
		if ($totalmoney < $num) {
			showmessage(lang('plugin/keke_klhb', 'f12'), '');
		}
		if ($_GET['editid'] == 1) {
			$langs = lang('plugin/keke_klhb', 'f16');
			$nums = $hbdata['num'] + $num;
			$totalmoneys = $hbdata['totalmoney'] + $totalmoney;
			$arr = array('totalmoney' => $totalmoneys, 'num' => $nums, 'code' => $code, 'endtime' => $endtime);
			$id = C::t('#keke_klhb#keke_klhb')->update($hbdata['id'], $arr);
		} elseif ($_GET['editid'] == 2) {
			$langs = lang('plugin/keke_klhb', 'f17');
			$arr = array('uid' => $_G['uid'], 'tid' => intval($_GET['tids']), 'credit' => $crtdit, 'totalmoney' => $totalmoney, 'num' => $num, 'mod' => $mod, 'code' => $code, 'time' => $_G['timestamp'], 'endtime' => $endtime, 'hash' => random(6, 1));
			$id = C::t('#keke_klhb#keke_klhb')->insert($arr, true);
		}
		if ($id) {
			updatemembercount($_G['uid'], array('extcredits' . $crtdit . '' => 0 - $totalmoney), true, '', 0, '', lang('plugin/keke_klhb', 'f08'), lang('plugin/keke_klhb', 'f09'));
		}
		showmessage($langs, 'forum.php?mod=viewthread&tid=' . $tid);
	} else {
		$edit = intval($_GET['edit']);
		if ($edit == 1) {
			$creop = '<option value="' . $hbdata['credit'] . '">' . $_G['setting']['extcredits'][$hbdata['credit']]['title'] . '</option>';
			if ($hbdata['endtime'] < $_G['timestamp']) {
				$time = dgmdate($_G['timestamp'] + intval($keke_klhb['sx']) * 3600, 'Y-m-d H:i:s');
			}
		} else {
			$cre = $keke_klhb['jf'];
			$time = dgmdate($_G['timestamp'] + intval($keke_klhb['sx']) * 3600, 'Y-m-d H:i:s');
			foreach ($_G['setting']['extcredits'] as $k => $v) {
				if ($k == $cre) {
					$creop .= '<option value="' . $k . '" selected>' . $v['title'] . '</option>';
				} else {
					$creop .= '<option value="' . $k . '">' . $v['title'] . '</option>';
				}
			}
		}
		include template('keke_klhb:input');
	}
}
include template('keke_klhb:show_win');
