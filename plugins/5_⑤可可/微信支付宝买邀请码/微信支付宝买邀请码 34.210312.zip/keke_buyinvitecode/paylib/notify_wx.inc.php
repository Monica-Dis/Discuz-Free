<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');
require_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/inc.php";	

global $_G;
$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
$yxq=$keke_buyinvitecode['yxq'] ? intval($keke_buyinvitecode['yxq']) : 10;


$return=array();
$msg = '';
$returnValues = WxPayApi::notify($msg);

if(empty($returnValues)){
	$return = array('return_code'=>'FAIL','return_msg'=>$msg,);
	WxPayApi::replyNotify(arrtoxml($return));
	exit();
}

$chcksign = WxPayDataBase::CheckSigns($returnValues);
if(!$chcksign){
	$return = array('return_code'=>'FAIL','return_msg'=>'signerr',);
	WxPayApi::replyNotify(arrtoxml($return));
	exit();
	
}
if(!empty($returnValues['result_code']) && $returnValues['result_code'] == 'SUCCESS'){
	$orderdata= C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->fetch($returnValues['out_trade_no']);
	if($orderdata['state']==1){
		$codetext = array();
		$codetext=_createcode($orderdata,$returnValues['out_trade_no'],$yxq);
		_uporderdata(2,$returnValues['transaction_id'],$codetext,$orderdata);
		if($keke_buyinvitecode['smsoff']){
			_sensms($codetext,$orderdata['email'],$yxq);
		}
	}
	$return = array(
		'return_code'=>'SUCCESS',
		'return_msg'=> 'OK',
	);
	WxPayApi::replyNotify(arrtoxml($return));
}