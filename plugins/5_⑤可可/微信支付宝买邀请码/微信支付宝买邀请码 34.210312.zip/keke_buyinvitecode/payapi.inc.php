<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$keke_buyinvitecode = $_G['cache']['plugin']['keke_buyinvitecode'];
header("Content-type:text/html;charset=utf-8");

$costcount=intval($_GET['costcount']);
$moneyQuantity=$costcount*$keke_buyinvitecode['dj'];
$money=$moneyQuantity*100;
$zftype=intval($_GET['zftype']);
$email = dhtmlspecialchars($_GET['buyemail']);
$title= CHARSET=='gbk' ? diconv(lang('plugin/keke_buyinvitecode', 'lang18'), CHARSET, 'UTF-8') : lang('plugin/keke_buyinvitecode', 'lang18');
include_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/fun.php";
if(empty($costcount)) {
	$msg=lang('plugin/keke_buyinvitecode', 'lang19');
	$msgs=diconv($msg, CHARSET,'utf-8');
	if($zftype==1){
		echo '<script>alert("'.$msgs.'");window.history.go(-1);</script>';
	}else{
		echo json_encode(array('err' =>$msgs));
	}
	exit();
}elseif($keke_buyinvitecode['maxnum'] && $costcount>$keke_buyinvitecode['maxnum']){
	$msg=lang('plugin/keke_buyinvitecode', 'f11').$keke_buyinvitecode['maxnum'].lang('plugin/keke_buyinvitecode', 'f12');
	$msgs=diconv($msg, CHARSET,'utf-8');
	if($zftype==1){
		echo '<script>alert("'.$msgs.'");window.history.go(-1);</script>';
	}else{
		echo json_encode(array('err' =>$msgs));
	}
	exit();
}

if(!(preg_match("/^1[3456789]{1}\d{9}$/",$email)) && $email){  
   	$msg=lang('plugin/keke_buyinvitecode', 'lang23');
	$msgs=diconv($msg, CHARSET,'utf-8');
	if($zftype==1){
		echo '<script>alert("'.$msgs.'");window.history.go(-1);</script>';
	}else{
		echo json_encode(array('err' =>$msgs));
	}
	exit();
}

$orderid=_orderid();
$orderarr=array(
	'orderid'=>$orderid,
	'uid'=>0,
	'state'=>1,
	'zftype'=>$zftype,
	'price'=>$moneyQuantity,
	'amount'=>$costcount,
	'time'=>$_G['timestamp'],
	'email'=>$email,
	'ip'=>$_G['clientip'],
);
C::t('#keke_buyinvitecode#keke_buyinvitecode_orderlog')->insert($orderarr, true);

if($zftype==1){
	require_once("source/plugin/keke_buyinvitecode/paylib/alipay/alipay.config.php");
	require_once("source/plugin/keke_buyinvitecode/paylib/alipay/alipay_submit.class.php");
	$out_trade_no = $orderid;
	$subject = $title;
	$total_fee = $moneyQuantity;
	$show_url = "plugin.php?id=keke_buyinvitecode";
	$parameter = array(
		"service"       => $alipay_config['service'],
		"partner"       => $alipay_config['partner'],
		"seller_id"  => $alipay_config['seller_id'],
		"payment_type"	=> $alipay_config['payment_type'],
		"notify_url"	=> $alipay_config['notify_url'],
		"return_url"	=> $alipay_config['return_url'],
		"_input_charset"	=> trim(strtolower($alipay_config['input_charset'])),
		"out_trade_no"	=> $out_trade_no,
		"subject"	=> $subject,
		"total_fee"	=> $total_fee,
		"show_url"	=> $show_url,
		"app_pay"   => "Y",
	);
	$alipaySubmit = new AlipaySubmit($alipay_config);
	$html_text = $alipaySubmit->buildRequestForm($parameter,"get", lang('plugin/keke_buyinvitecode', 'lang21'));
	echo $html_text;
}elseif($zftype==2){
	include_once DISCUZ_ROOT."source/plugin/keke_buyinvitecode/inc.php";
	$tools = new JsApiPay();
	$openIds = $_G['cookie'][$uskey];
	$openId=authcode($openIds, 'DECODE', $_G['config']['security']['authkey']);
	
	$notify = new NativePay();
	$input = new WxPayUnifiedOrder();
	$input->SetBody($title);
	$input->SetAttach($title);
	$input->SetOut_trade_no($orderid);
	$input->SetTotal_fee($money);
	$input->SetTime_start(date("YmdHis"));
	$input->SetGoods_tag($title);
	$input->SetNotify_url($_G['siteurl']. 'source/plugin/keke_buyinvitecode/paylib/notify_wx.inc.php');
	$input->SetTrade_type($s_type);
	
	if($iswx){
		$input->SetOpenid($openId);
		$order = WxPayApi::unifiedOrder($input);
		$jsApiParameters = $tools->GetJsApiParameters($order);
		
		try
        {
            $jsApiParameters = $tools->GetJsApiParameters($order);
        }catch (Exception $e){
            $jsApiParameters = json_encode(array('err' => $e->getMessage()));
            $jsApiParameters = diconv($jsApiParameters, 'utf-8');
        }
		$jsApiParameters=_createjson($jsApiParameters,$orderid);
		echo $jsApiParameters;
        exit;
		
	}else{
		if(checkmobile() && $keke_buyinvitecode['h5']){
			$h5pay=_h5pay($money,$orderid,$title);
			echo json_encode(array('h5payurl' => $h5pay['mweb_url'],'ewmurl' => '','orderid'=>$orderid));
		}else{
			$input->SetProduct_id($orderid);
			$result = $notify->GetPayUrl($input);
			$url2 = $result["code_url"];
			if($url2){
				$src =_getqrcodeurl($url2);
				echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
			}else{
				$err = $result['return_msg'];
				echo json_encode(array('err' => $err));
			}
		}
		
	}

}