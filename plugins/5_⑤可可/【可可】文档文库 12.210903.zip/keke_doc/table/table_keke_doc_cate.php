<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_doc_cate extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_doc_cate';
		$this->_pk    = 'cate_id';

		parent::__construct(); /*dism��taobao��com*/
	}
	
	public function count_by_search($param) {
		return DB::result_first('SELECT COUNT(*) FROM %t %i', array($this->_table, $this->wheresql($param)));
	}
		
	public function fetch_all_by_displayorder() {
		$query=DB::fetch_all("SELECT * FROM %t ORDER BY displayorder", array($this->_table), $this->_pk);
		return $this->_allcatedata($query);
	}

	public function _allcatedata($query) {
        $scIds=$subids=$subid=$displayorder=array();
		foreach($query as $key => $value) {
			if($value['upid']) {
			    foreach ($query as $k=>$v){
                    if($value['cate_id']==$v['upid'])$scIds[$value['cate_id']][$v['cate_id']]=$v['cate_id'];
                    if($value['upid']==$v['cate_id'] && !$v['upid'])$subids[$value['cate_id']]=array();
                }
			}
		}
		$thirdcate=$scIds+$subids;
		foreach ($thirdcate as $sk=>$sv){
            $subid[$query[$sk]['upid']][$sk]=$sv;
            $displayorder[$query[$sk]['upid']][$sk]=$query[$sk]['displayorder'];
        }

        foreach ($displayorder as $fkey=>$ret) {
            asort( $ret );
            $displayorder[$fkey]=$ret;
        }
        foreach ($subid as $subkey=>$subval) {
            unset($subid[$subkey]);
            foreach ($displayorder[$subkey] as $cId=>$item){
                $subid[$subkey][$cId]=$subval[$cId];
            }
        }

		foreach($query as $key => $value) {
            if($subid[$value['cate_id']]){
                $query[$key]['subcate']=$subid[$value['cate_id']];
            }
            if($thirdcate[$value['cate_id']]){
                $query[$key]['subcate']=$thirdcate[$value['cate_id']];
            }
		}
		return $query;
	}
}