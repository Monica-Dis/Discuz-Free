<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_doc = $_G['cache']['plugin']['keke_doc'];
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
if(!in_array($_G['groupid'],unserialize($keke_doc['allow_group']))){
    showmessage(lang('plugin/keke_doc', '197'), NULL, array());
}
$userdata = C::t('#keke_doc#keke_doc_user')->fetchfirst_byuid($_G['uid']);
if($userdata){
    if($userdata['state']==2)showmessage(lang('plugin/keke_doc', '198'),'plugin.php?id=keke_doc');
}else{
    C::t('#keke_doc#keke_doc_user')->insert(array(
        'uid'=>$_G['uid'],
        'time'=>TIMESTAMP
    ), true, true);
}
$ac=$_GET['ac']=$_GET['ac']?dhtmlspecialchars($_GET['ac']):'doc';
$ppp=20;
$_GET['page']=intval($_GET['page']);
$page = max(1, $_GET['page']);
$startlimit = ($page - 1) * $ppp;
require_once DISCUZ_ROOT.'./source/plugin/keke_doc/function.php';
$cateData=kekeGetAllCate();
$tmpUrl='plugin.php?id=keke_doc:t&ac='.$ac;
$dataArr=[];
switch ($ac) {
    case 'doc':
        $where='uid='.$_G['uid'];
        $countAll=$dataArr[0]=C::t('#keke_doc#keke_doc')->count_all($where);
        $docArr=C::t('#keke_doc#keke_doc')->fetch_all_doc($startlimit,$ppp,$where);
        break;
    case 'updoc':
        $creditTypeArr=getCredit();
        //$posturl='plugin.php?id=keke_doc:ajax&ac=updoc&formhash='.FORMHASH;
        $posturl='https://'.$keke_doc['bucket'].'.cos.'.$keke_doc['region'].'.myqcloud.com';
        break;
    case 'order':
    case 'follow':
    case 'evaluate':
        $dataArr=getListData($startlimit,$ppp,($ac=='order'?'author_uid=':'state=1 AND authorid=').$_G['uid']);
        break;
    case 'user':
        $userArr=C::t('#keke_doc#keke_doc_user')->fetchfirst_byuid($_G['uid']);
        break;
    case 'win':

        break;
}

if($dataArr[0]){
    $multipage = filterMultiPage(multi($dataArr[0], $ppp, $page, $_G['siteurl'].$tmpUrl),0);
}
include template('keke_doc:t');