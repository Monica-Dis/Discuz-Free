<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;
loadcache('plugin');
include_once DISCUZ_ROOT . "source/plugin/keke_doc/function.php";
if (submitcheck("forumset")) {
    $state = 2;
    if (is_array($_GET['dids'])) {
        if ($_GET['optype'] == 'delete') {
            C::t('#keke_doc#keke_doc_evaluate')->delete($_GET['dids']);
        } else {
            switch ($_GET['optype']) {
                case 'pass':
                    $state = 1;
                    break;
                case 'hide':
                    $state = 3;
                    break;
            }
            C::t('#keke_doc#keke_doc_evaluate')->update($_GET['dids'], array('state' => $state));
        }
    } else {
        cpmsg(lang('plugin/keke_doc', '54'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_evaluate', 'error');
    }
    if (!$_GET['optype']) {
        cpmsg(lang('plugin/keke_doc', '55'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_evaluate', 'error');
    }
    cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_evaluate', 'succeed');
}

showtableheader(lang('plugin/keke_doc', '91'));
showformheader('plugins&operation=config&do=' . $pluginid . '&pmod=keke_doc&pmod=admincp_evaluate', 'testhd');
showtablerow('', array(),
    array(
        '<input name="uid" type="text" value="' . ($_GET['did'] ? intval($_GET['did']) : '') . '" size="10" placeholder="'.lang('plugin/keke_doc', '92').'" />
                <input name="uid" type="text" value="' . ($_GET['uid'] ? intval($_GET['uid']) : '') . '" size="10" placeholder="'.lang('plugin/keke_doc', '78').'UID" />
                <select name="state"><option value="0">'.lang('plugin/keke_doc', '79').'</option><option value="1" ' . ($_GET['state'] == 1 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '93').'</option><option value="2" ' . ($_GET['state'] == 2 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '71').'</option><option value="3" ' . ($_GET['state'] == 3 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '94').'</option></select>
                <input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_doc', '95').'"><input name="inajax" type="hidden" value="1" />'
    )
);
showformfooter(); /*dism_taobao_com*/
showtablefooter(); /*dism _taobao _com*/
$where = '1';
$param = '';

if ($_GET['did']) {
    $where .= " AND did=" . intval($_GET['did']);
    $param .= '&did=' . intval($_GET['uid']);
}
if ($_GET['uid']) {
    $where .= " AND uid=" . intval($_GET['uid']);
    $param .= '&uid=' . intval($_GET['uid']);
}
if ($_GET['state']) {
    $where .= " AND state=" . intval($_GET['state']);
    $param .= '&state=' . intval($_GET['state']);
}
showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_evaluate");
showtableheader(lang('plugin/keke_doc', '96'));
showsubtitle(array(lang('plugin/keke_doc', '83'), lang('plugin/keke_doc', '97'), lang('plugin/keke_doc', '98'), lang('plugin/keke_doc', '99'),lang('plugin/keke_doc', '100'), lang('plugin/keke_doc', '87')));
$ppp = 20;
$tmpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_evaluate' . $param;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
if ($countAll = C::t('#keke_doc#keke_doc_evaluate')->count_all($where)) {
    $dataArr = C::t('#keke_doc#keke_doc_evaluate')->fetch_all_data($startlimit, $ppp, $where);
    foreach ($dataArr as $key => $val) {
        switch ($val['state']) {
            case 1:
                $state = ['zc', lang('plugin/keke_doc', '93')];
                break;
            case 2:
                $state = ['off',  lang('plugin/keke_doc', '71')];
                break;
            case 3:
                $state = ['hide',  lang('plugin/keke_doc', '94')];
                break;
        }
        $table = array();
        $table[0] = '<input type="checkbox" class="checkbox" name="dids[]" value="' . $val['id'] . '" />';
        $table[1] = '<a href="home.php?mod=space&uid=' . $val['uid'] . '" target="_blank" class="teachername">' . $val['name'] . '</a>';
        $table[2] = '<span class="star">'.$val['star'].lang('plugin/keke_doc', '101').'</span>';
        $table[3] = '<a href="plugin.php?id=keke_doc&ac=view&did='.$val['did'].'" target="_blank"> <div class="title">'.$val['title'].'</div></a><div class="text">'.$val['text'].'</div>';
        $table[4] = $val['date'];
        $table[5] = '<span class="' . $state[0] . '">' . $state[1] . '</span>';
        showtablerow('', array('width="50px"','','', 'width="40%" style="max-width: 500px;"','','width="100px"'), $table);
    }
}
$multipage = multi($countAll, $ppp, $page, $_G['siteurl'] . $tmpurl);
if ($multipage) echo '<tr class="hover"><td colspan="9">' . $multipage . '</td></tr>';
echo '<style>.hide,.zc,.off{border-radius: 2px; color: #fff; font-size: 12px; padding: 2px 5px;}.hide{ background: #b9b9b9;}.zc{ background: #6cb057;}.off{background: #f46c6c;}.star{color: #f46c6c;}.title{color: #999;font-weight: 400;margin: 10px 0;}.text{ background: #fbfdff;border: 1px dashed #d9eeff; padding:10px; line-height:23px;font-weight: 400;margin: 10px 3% 10px 0;}</style>';
showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'dids\')"><label for="chkallIuPN">'.lang('plugin/keke_doc', '83').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_doc', '89').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="pass" value="pass" class="radio" /><label for="pass" class="vmiddle">'.lang('plugin/keke_doc', '102').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="hide" value="hide" class="radio" /><label for="hide" class="vmiddle">'.lang('plugin/keke_doc', '94').'</label>');
showtablefooter(); /*dism _taobao _com*/
showformfooter(); /*dism_taobao_com*/