<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
include_once DISCUZ_ROOT."source/plugin/keke_doc/function.php";
$allSet=kekeGetSet();
$_GET['op']=$_GET['op']?:'rewriteset';
kekeShowAdminSubMenu(array(
	array(lang('plugin/keke_doc', '120'), "rewriteset"),
	array(lang('plugin/keke_doc', '121'), "rewrite"),
),'admincp_rewrite');
if ($_GET['op'] == 'rewriteset') {
	if (!submitcheck("editsubmit")) {
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_rewrite&op=rewriteset", 'enctype');
		showtableheader(lang('plugin/keke_doc', '122'));
		showsetting(lang('plugin/keke_doc', '123'),'rewrite[off]',$allSet['rewrite_off']);
		showsetting(lang('plugin/keke_doc', '124'),'rewrite[suffix]',$allSet['rewrite_suffix'],'text','','',lang('plugin/keke_doc', '131'));
		showsetting(lang('plugin/keke_doc', '125'),'rewrite[index]',($allSet['rewrite_index']?:'doc'),'text','','','');
		showsetting(lang('plugin/keke_doc', '126'),'rewrite[list]',($allSet['rewrite_list']?:'doc-class'),'text','','','');
		showsetting(lang('plugin/keke_doc', '127'),'rewrite[view]',($allSet['rewrite_view']?:'doc-view'),'text','','','');
		showsetting(lang('plugin/keke_doc', '128'),'rewrite[account]',($allSet['rewrite_account']?:'doc-account'),'text','','','');
        showsetting(lang('plugin/keke_doc', '129'),'rewrite[user]',($allSet['rewrite_user']?:'doc-user'),'text','','','');
		showsetting(lang('plugin/keke_doc', '130'),'rewrite[pay]',($allSet['rewrite_pay']?:'doc-pay'),'text','','','');
		showsubmit('editsubmit');
		showtablefooter(); /*dism _taobao _com*/
		showformfooter(); /*dism_taobao_com*/
		exit;
	}else{
        $arr=[];
		foreach($_GET['rewrite'] as $key=>$val){
			$arr['rewrite_'.$key]=kekeEditorSafeReplace($val);
		}
        kekeInsertSet($arr);
		cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_rewrite', 'succeed');
	}
}else{
	showtips(lang('plugin/keke_doc', '132'));
	$rewrite=array(
		'index','list','account','view','user','pay'
	);
	$suffix=str_replace(".","\.",$allSet['rewrite_suffix']);
	foreach($rewrite as $rewritekey=>$rewriteval){
		if($allSet['rewrite_'.$rewriteval]){
			$rewritearr[$rewriteval]=str_replace(".","\.",$allSet['rewrite_'.$rewriteval]);
		}
	}

	$strtmp= '<br><h1>'.lang('plugin/keke_doc', '133').'</h1>
	<pre class="colorbox">
	
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['index'].$suffix.'$ $1/plugin.php?id=keke_doc%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['list'].$suffix.'$ $1/plugin.php?id=keke_doc&ac=list%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=list&cate=$2-$3-$4%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['list'].'-(.*?)-o-([0-9]+)-p-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=list&cate=$2&o=$3&page=$4%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['account'].$suffix.'$ $1/plugin.php?id=keke_doc&ac=account%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=account&op=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=account&op=$2&page=$3%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['view'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=view&did=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['user'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=user&uid=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['user'].'-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=user&uid=$2&o=$3%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^(.*)/'.$rewritearr['pay'].'-(.*?)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=pay&did=$2%1
	
	</pre>
	<h1>'.lang('plugin/keke_doc', '134').'</h1>
	<pre class="colorbox">
	
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['index'].$suffix.'$ plugin.php?id=keke_doc%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['list'].$suffix.'$ plugin.php?id=keke_doc&ac=list%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'$ plugin.php?id=keke_doc&ac=list&cate=$1-$2-$3%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['list'].'-(.*?)-o-([0-9]+)-p-([0-9]+)'.$suffix.'$ plugin.php?id=keke_doc&ac=list&cate=$1&o=$2&page=$3%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['account'].$suffix.'$ plugin.php?id=keke_doc&ac=account%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['account'].'-(\w+)'.$suffix.'$ plugin.php?id=keke_doc&ac=account&op=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'$ plugin.php?id=keke_doc&ac=account&op=$1&page=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['view'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_doc&ac=view&did=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['user'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_doc&ac=user&uid=$1%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['user'].'-([0-9]+)-([0-9]+)'.$suffix.'$ plugin.php?id=keke_doc&ac=user&uid=$1&o=$2%1
	RewriteCond %{QUERY_STRING} ^(.*)$
	RewriteRule ^'.$rewritearr['pay'].'-([0-9]+)'.$suffix.'$ plugin.php?id=keke_doc&ac=pay&did=$1%1
	
	</pre>
	<h1>Nginx Web Server</h1>
	<pre class="colorbox">

	
	rewrite ^([^\.]*)/'.$rewritearr['index'].$suffix.'$ $1/plugin.php?id=keke_doc last;
	rewrite ^([^\.]*)/'.$rewritearr['list'].$suffix.'$ $1/plugin.php?id=keke_doc&ac=list last;
	rewrite ^([^\.]*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=list&cate=$2-$3-$4 last;
	rewrite ^([^\.]*)/'.$rewritearr['list'].'-(.*?)-o-([0-9]+)-p-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=list&cate=$2&o=$3&page=$4 last;
	rewrite ^([^\.]*)/'.$rewritearr['account'].$suffix.'$ $1/plugin.php?id=keke_doc&ac=account last;
	rewrite ^([^\.]*)/'.$rewritearr['account'].'-(\w+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=account&op=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=account&op=$2&page=$3 last;
	rewrite ^([^\.]*)/'.$rewritearr['view'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=view&did=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['user'].'-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=user&uid=$2 last;
	rewrite ^([^\.]*)/'.$rewritearr['user'].'-([0-9]+)-([0-9]+)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=user&uid=$2&o=$3 last;
	rewrite ^([^\.]*)/'.$rewritearr['pay'].'-(.*?)'.$suffix.'$ $1/plugin.php?id=keke_doc&ac=pay&priceid=$2 last;
	
	</pre>
	<h1>'.lang('plugin/keke_doc', '135').'</h1>
	<pre class="colorbox">
	

	RewriteRule ^(.*)/'.$rewritearr['index'].$suffix.'*$ $1/plugin.php?id=keke_doc
	RewriteRule ^(.*)/'.$rewritearr['list'].$suffix.'*$ $1/plugin.php?id=keke_doc&ac=list
	RewriteRule ^(.*)/'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_doc&ac=list&cate=$2-$3-$4
	RewriteRule ^(.*)/'.$rewritearr['list'].'-(.*?)-o-([0-9]+)-p-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_doc&ac=list&cate=$2&o=$3&page=$4
	RewriteRule ^(.*)/'.$rewritearr['account'].$suffix.'*$ $1/plugin.php?id=keke_doc&ac=account
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)'.$suffix.'*$ $1/plugin.php?id=keke_doc&ac=account&op=$2
	RewriteRule ^(.*)/'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_doc&ac=account&op=$2&page=$3
	RewriteRule ^(.*)/'.$rewritearr['view'].'-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_doc&ac=view&did=$2
	RewriteRule ^(.*)/'.$rewritearr['user'].'-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_doc&ac=user&uid=$2
	RewriteRule ^(.*)/'.$rewritearr['user'].'-([0-9]+)-([0-9]+)'.$suffix.'*$ $1/plugin.php?id=keke_doc&ac=user&uid=$2&o=$3
	RewriteRule ^(.*)/'.$rewritearr['pay'].'-(.*?)'.$suffix.'*$ $1/plugin.php?id=keke_doc&ac=pay&did=$2
	
	</pre>
	<h1>'.lang('plugin/keke_doc', '136').'</h1>
	<pre class="colorbox">
	
	
	&lt;rule name="doc_index"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['index'].$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_list"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['list'].$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=list" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_list_a"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['list'].'-([0-9]+)-([0-9]+)-([0-9]+)'.$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=list&amp;amp;cate={R:2}-{R:3}-{R:4}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_list_b"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['list'].'-(.*?)-o-([0-9]+)-p-([0-9]+)'.$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=list&amp;amp;cate={R:2}&amp;amp;o={R:3}&amp;amp;page={R:4}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_account"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['account'].$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=account" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_account_a"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['account'].'-(\w+)'.$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=account&amp;amp;op={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_account_b"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['account'].'-(\w+)-([0-9]+)'.$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=account&amp;amp;op={R:2}&amp;amp;page={R:3}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_view"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['view'].'-([0-9]+)'.$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=view&amp;amp;did={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_user"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['user'].'-([0-9]+)'.$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=user&amp;amp;uid={R:2}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_user"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['user'].'-([0-9]+)-([0-9]+)'.$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=user&amp;amp;uid={R:2}&amp;amp;o={R:3}" /&gt;
	&lt;/rule&gt;
	&lt;rule name="doc_pay"&gt;
		&lt;match url="^(.*/)*'.$rewritearr['pay'].'-([0-9]+)'.$allSet['rewrite_suffix'].'\?*(.*)$" /&gt;
		&lt;action type="Rewrite" url="{R:1}/plugin.php\?id=keke_doc&amp;amp;ac=pay&amp;amp;did={R:2}" /&gt;
	&lt;/rule&gt;
	
	
	</pre>';
	echo $strtmp;
	showtablefooter(); /*dism _taobao _com*/
}