<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;
loadcache('plugin');
include_once DISCUZ_ROOT . "source/plugin/keke_doc/function.php";
$CateData = kekeGetAllCate();
if (submitcheck("forumset")) {
    $state = 1;
    if (is_array($_GET['dids'])) {
        if ($_GET['optype'] == 'delete') {
            C::t('#keke_doc#keke_doc')->delete($_GET['dids']);
        } else {
            if($_GET['optype']=='recommend' || $_GET['optype']=='unrecommend'){
                $upDataArr=['recommend' => ($_GET['optype']=='recommend'?1:0)];
            }else{
                switch ($_GET['optype']) {
                    case 'pass':
                    case 'up':
                        $state = 3;
                        break;
                    case 'refuse':
                        $state = 4;
                        break;
                    case 'down':
                        $state = 2;
                        break;
                }
                $upDataArr=['state' => $state];
            }
            C::t('#keke_doc#keke_doc')->update($_GET['dids'], $upDataArr);
        }
    } else {
        cpmsg(lang('plugin/keke_doc', '54'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier='.$plugin["identifier"].'&pmod=admincp_live', 'error');
    }
    if (!$_GET['optype']) {
        cpmsg(lang('plugin/keke_doc', '55'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier='.$plugin["identifier"].'&pmod=admincp_doc', 'error');
    }
    cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_doc', 'succeed');
}

if ($_GET['ac'] == 'edit') {
    $did = intval($_GET['did']);
    $docData = C::t('#keke_doc#keke_doc')->fetchfirst_byid($did);
    $_GET['cateid'] = intval($_GET['cateid']);
    if (!submitcheck("editsubmit")) {
        $_GET['cateid'] = $docData['thirdcate'] ?: $docData['subcate'];
        showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_doc&ac=edit");
        showtableheader(lang('plugin/keke_doc', '56'));
        showsetting(lang('plugin/keke_doc', '57'), 'title', $docData['title'], 'text');
        showsetting(lang('plugin/keke_doc', '58'), 'intro', $docData['intro'], 'textarea');
        showsetting(lang('plugin/keke_doc', '50'), '', '', '<select name="cateid"><option value="0">'.lang('plugin/keke_doc', '66').'</option>' . getCateSelect() . '</select>');
        showsetting(lang('plugin/keke_doc', '59'), 'price', $docData['price'], 'text', '', '', lang('plugin/keke_doc', '67'));
        showsetting(lang('plugin/keke_doc', '60'), 'credit', $docData['credit'], 'text');
        showsetting(lang('plugin/keke_doc', '61'), '', '', '<select name="credit_type"><option value="0">'.lang('plugin/keke_doc', '61').'</option>' . getCreditOpt($docData['credit_type']) . '</select>');
        showsetting(lang('plugin/keke_doc', '62'), 'freepage', $docData['freepage'], 'text', '', '', lang('plugin/keke_doc', '68'));
        showsetting(lang('plugin/keke_doc', '210'), 'view', $docData['view'], 'text', '', '', lang('plugin/keke_doc', '211'));
        showsetting(lang('plugin/keke_doc', '209'), 'down', $docData['down'], 'text', '', '', lang('plugin/keke_doc', '211'));

        showsetting(lang('plugin/keke_doc', '63'), 'vip', $docData['vip']);
        showsetting(lang('plugin/keke_doc', '64'), 'vip_price', $docData['vip_price'], 'text', '', '', lang('plugin/keke_doc', '67').' / '.lang('plugin/keke_doc', '69'));
        showsetting(lang('plugin/keke_doc', '65'), '', '', '<select name="state"><option value="0">'.lang('plugin/keke_doc', '70').'</option><option value="1" ' . ($docData['state'] == 1 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '71').'</option><option value="2" ' . ($docData['state'] == 2 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '72').'</option><option value="3" ' . ($docData['state'] == 3 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '73').'</option><option value="4" ' . ($docData['state'] == 4 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '74').'</option></select>');
        showsetting(lang('plugin/keke_doc', '15'), 'displayorder', $docData['displayorder'], 'text');
        echo '<input name="did" type="hidden" value="' . $did . '" /><input name="page" type="hidden" value="' . intval($_GET['page']) . '" />';
        showsubmit('editsubmit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism_taobao_com*/
        exit();
    }else{
        $arr = array(
            'title' => $_GET['title'],
            'intro' => $_GET['intro'],
            'price' => floatval($_GET['price']),
            'credit' => intval($_GET['credit']),
            'credit_type' => intval($_GET['credit_type']),
            'freepage' => intval($_GET['freepage']),
            'view' => intval($_GET['view']),
            'down' => intval($_GET['down']),
            'state' => intval($_GET['state']),
            'vip' => intval($_GET['vip']),
            'vip_price' => floatval($_GET['vip_price']),
            'displayorder' => intval($_GET['displayorder']),
        );
        if ($CateData[$_GET['cateid']]['upid'] == 0) {
            $cateArr['cate'] = $cateArr['subcate'] = $cateArr['thirdcate'] = $_GET['cateid'];
        } else {
            if ($CateData[$_GET['cateid']]['subcate'] || $CateData[$CateData[$_GET['cateid']]['upid']]['upid'] == 0) {
                $cateArr = array(
                    'cate' => $CateData[$_GET['cateid']]['upid'],
                    'subcate' => $_GET['cateid'],
                    'thirdcate' => $_GET['cateid'],
                );
            } else {
                $cateArr = array(
                    'cate' => $CateData[$CateData[$_GET['cateid']]['upid']]['upid'],
                    'subcate' => $CateData[$_GET['cateid']]['upid'],
                    'thirdcate' => $_GET['cateid'],
                );
            }
        }
        $arr += $cateArr;
        C::t('#keke_doc#keke_doc')->update($did, $arr);
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_doc&page=' . intval($_GET['page']), 'succeed');
    }
}

$_GET['keyword'] = dhtmlspecialchars($_GET['keyword']);
showtableheader(lang('plugin/keke_doc', '75'));
showformheader('plugins&operation=config&do=' . $pluginid . '&pmod=keke_doc&pmod=admincp_doc', 'testhd');
showtablerow('', array(),
    array(
        '<select name="cateid"><option value="0">'.lang('plugin/keke_doc', '76').'</option>' . getCateSelect() . '</select>
                <input name="keyword" value="' . $_GET['keyword'] . '" type="text" size="30" placeholder="'.lang('plugin/keke_doc', '77').'" />
                <input name="uid" type="text" value="' . ($_GET['uid'] ? intval($_GET['uid']) : '') . '" size="10" placeholder="'.lang('plugin/keke_doc', '78').'UID" />
                <select name="state"><option value="0">'.lang('plugin/keke_doc', '79').'</option><option value="1" ' . ($_GET['state'] == 1 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '71').'</option><option value="2" ' . ($_GET['state'] == 2 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '72').'</option><option value="3" ' . ($_GET['state'] == 3 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '73').'</option><option value="4" ' . ($_GET['state'] == 4 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '74').'</option></select>
                <select name="recommend"><option value="0">'.lang('plugin/keke_doc', '80').'</option><option value="1" ' . ($_GET['recommend'] ? 'selected' : '') . '>'.lang('plugin/keke_doc', '81').'</option></select>
                <input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_doc', '75').'"><input name="inajax" type="hidden" value="1" />'
    )
);
showformfooter(); /*dism_taobao_com*/
showtablefooter(); /*dism _taobao _com*/
$where = '1';
$param = '';
if ($_GET['cateid']) {
    $_GET['cateid'] = intval($_GET['cateid']);
    if ($CateData[$_GET['cateid']]['upid'] == 0) {
        $where .= " AND cate=" . $_GET['cateid'];
    } else {
        if ($CateData[$_GET['cateid']]['subcate']) {
            $where .= " AND subcate=" . $_GET['cateid'];
        } else {
            $where .= " AND (subcate=" . $_GET['cateid'] . " OR thirdcate=" . $_GET['cateid'] . ")";
        }
    }
    $param .= '&cateid=' . $_GET['cateid'];
}
if ($_GET['keyword']) {
    $where .= " AND title LIKE '%" . addcslashes($_GET['keyword'], '%_') . "%'";
    $param .= '&keyword=' . $_GET['keyword'];
}
if ($_GET['uid']) {
    $where .= " AND uid=" . intval($_GET['uid']);
    $param .= '&uid=' . intval($_GET['uid']);
}
if ($_GET['state']) {
    $where .= " AND state=" . intval($_GET['state']);
    $param .= '&state=' . intval($_GET['state']);
}
if ($_GET['recommend']) {
    $where .= " AND recommend=1";
    $param .= '&recommend=1';
}
showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_doc");
showtableheader(lang('plugin/keke_doc', '82'));
showsubtitle(array(lang('plugin/keke_doc', '83'), lang('plugin/keke_doc', '84'), lang('plugin/keke_doc', '85'), lang('plugin/keke_doc', '59'), lang('plugin/keke_doc', '86'), lang('plugin/keke_doc', '87'), lang('plugin/keke_doc', '19')));
$ppp = 20;
$tmpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_doc' . $param;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
if ($countAll = C::t('#keke_doc#keke_doc')->count_all($where)) {
    $docArr = C::t('#keke_doc#keke_doc')->fetch_all_doc($startlimit, $ppp, $where);
    foreach ($docArr as $key => $val) {
        $op = '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_doc&ac=edit&did=' . $val['id'] . '&page=' . intval($_GET['page']) . '" class="">'.lang('plugin/keke_doc', '19').'</a>';
        $price = '';
        if ($val['price'] > 0 || $val['credit']) {
            if ($val['price'] > 0) {
                $price .= '<span class="f12"> &yen;</span>' . $val['price'];
            }
            if ($val['credit'] && $val['price'] > 0) {
                $price .= '+';
            }
            if ($val['credit']) {
                $price .= $val['credit'] . '<span class="f12"> ' . $_G['setting']['extcredits'][$val['credit_type']]['title'] . '</span>';
            }
        } else {
            $price = '<span class="freetitle">'.lang('plugin/keke_doc', '88').'</span>';
        }
        switch ($val['state']) {
            case 1:
                $state = ['ds', lang('plugin/keke_doc', '71')];
                break;
            case 2:
                $state = ['off', lang('plugin/keke_doc', '72')];
                break;
            case 3:
                $state = ['zc', lang('plugin/keke_doc', '73')];
                break;
            default:
                $state = ['jj', lang('plugin/keke_doc', '74')];
                break;
        }
        $table = array();
        $table[0] = '<input type="checkbox" class="checkbox" name="dids[]" value="' . $val['id'] . '" />';
        $table[1] = '<a href="plugin.php?id=keke_doc&ac=view&did=' . $val['id'] . '" target="_blank">' . $val['title'] . '</a>'.($val['recommend']?'<span class="recommend">'.lang('plugin/keke_doc', '81').'</span>':'');
        $table[2] = '<a href="home.php?mod=space&uid=' . $val['uid'] . '" target="_blank" class="teachername">' . $val['username'] . '</a>';
        $table[3] = $price;
        $table[4] = dgmdate($val['dateline'], 'Y/m/d H:i');
        $table[5] = '<span class="' . $state[0] . '">' . $state[1] . '</span>';
        $table[6] = $op;
        showtablerow('', array('', 'width=""'), $table);
    }
}
$multipage = multi($countAll, $ppp, $page, $_G['siteurl'] . $tmpurl);
if ($multipage) echo '<tr class="hover"><td colspan="9">' . $multipage . '</td></tr>';
echo '<style>.ds{color: #ff8e42;}.jj{color: #999;}.zc{color: #3fd411;}.off{color: #f46c6c;}.locking{ color:#c30}.sline{color:#e3e3e3;margin:0 5px;}.recommend{ background: #ff826b; color: #fff; font-size: 12px; padding: 0 3px; margin-left: 10px}</style>';
showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'dids\')"><label for="chkallIuPN">'.lang('plugin/keke_doc', '83').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="delete" value="delete" class="radio" /><label for="delete" class="vmiddle">'.lang('plugin/keke_doc', '89').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="refuse" value="refuse" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_doc', '74').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="up" value="up" class="radio" /><label for="up" class="vmiddle">'.lang('plugin/keke_doc', '73').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="down" value="down" class="radio" /><label for="down" class="vmiddle">'.lang('plugin/keke_doc', '72').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="recommend" value="recommend" class="radio" /><label for="recommend" class="vmiddle">'.lang('plugin/keke_doc', '81').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="unrecommend" value="unrecommend" class="radio" /><label for="unrecommend" class="vmiddle">'.lang('plugin/keke_doc', '90').'</label>');
showtablefooter(); /*dism _taobao _com*/
showformfooter(); /*dism_taobao_com*/