<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	//exit('Access Denied');
}
$keke_doc = DB::table("keke_doc");
$keke_doc_adv = DB::table("keke_doc_adv");
$keke_doc_cate = DB::table("keke_doc_cate");
$keke_doc_evaluate = DB::table("keke_doc_evaluate");
$keke_doc_favorites = DB::table("keke_doc_favorites");
$keke_doc_follow = DB::table("keke_doc_follow");
$keke_doc_history = DB::table("keke_doc_history");
$keke_doc_mydoc = DB::table("keke_doc_mydoc");
$keke_doc_order = DB::table("keke_doc_order");
$keke_doc_set = DB::table("keke_doc_set");
$keke_doc_slider = DB::table("keke_doc_slider");
$keke_doc_user = DB::table("keke_doc_user");
$keke_doc_report = DB::table("keke_doc_report");
$sql = <<<EOF
CREATE TABLE `$keke_doc` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `intro` varchar(1000) NOT NULL,
  `cate` int(3) NOT NULL,
  `subcate` int(3) NOT NULL,
  `thirdcate` int(3) NOT NULL,
  `page` int(10) NOT NULL,
  `freepage` int(3) NOT NULL,
  `price` float(5,2) NOT NULL,
  `credit` int(5) NOT NULL,
  `credit_type` int(1) NOT NULL,
  `docsrc` varchar(255) NOT NULL,
  `ext` varchar(10) NOT NULL,
  `filename` varchar(200) NOT NULL,
  `jobid` varchar(38) NOT NULL,
  `displayorder` int(6) NOT NULL DEFAULT '0',
  `down` int(10) NOT NULL,
  `dateline` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  `view` int(50) NOT NULL,
  `pageinfo` varchar(1000) NOT NULL,
  `vip` int(1) NOT NULL,
  `vip_price` float(10,2) NOT NULL,
  `recommend` int(1) NOT NULL,
  `size` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_adv` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(200) NOT NULL,
  `displayorder` int(20) NOT NULL,
  `type` char(5) NOT NULL,
  `code` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_cate` (
  `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `upid` int(10) unsigned NOT NULL DEFAULT '0',
  `displayorder` int(6) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `num` int(8) NOT NULL,
  `icon` varchar(255) NOT NULL,
  `recommend` int(1) NOT NULL,
  `vip_groupids` varchar(255) NOT NULL,
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_evaluate` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `did` int(20) NOT NULL,
  `authorid` int(10) NOT NULL,
  `star` int(1) NOT NULL,
  `text` mediumtext NOT NULL,
  `time` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  `reply` mediumtext NOT NULL,
  `replytime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_favorites` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `did` int(20) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_follow` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `authorid` int(20) NOT NULL,
  `time` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_history` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(20) NOT NULL,
  `did` int(20) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_mydoc` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `did` int(10) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_order` (
  `id` char(50) NOT NULL,
  `uid` int(100) NOT NULL,
  `pay_type` varchar(20) NOT NULL,
  `price` float(20,2) NOT NULL,
  `credit` int(10) NOT NULL,
  `credit_type` int(1) NOT NULL,
  `did` varchar(500) NOT NULL,
  `author_uid` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  `time` int(13) NOT NULL,
  `paytime` int(13) NOT NULL,
  `sn` varchar(50) NOT NULL,
  `revision` int(1) NOT NULL,
  `deduction` varchar(255) NOT NULL,
  `take` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_set` (
  `id` varchar(50) NOT NULL,
  `val` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_slider` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `img` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `title` varchar(200) NOT NULL,
  `displayorder` int(20) NOT NULL,
  `type` int(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
) ENGINE=MyISAM;

CREATE TABLE `$keke_doc_user` (
  `uid` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `rank` varchar(20) NOT NULL,
  `profile` varchar(500) NOT NULL,
  `time` int(10) NOT NULL,
  `state` int(1) NOT NULL,
  `img` varchar(255) NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `atid` (`uid`) USING BTREE
) ENGINE=MyISAM;


CREATE TABLE `$keke_doc_report` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `did` int(10) NOT NULL,
  `content` varchar(1000) NOT NULL,
  `ip` varchar(20) NOT NULL,
  `type` varchar(50) NOT NULL,
  `state` int(1) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `atid` (`id`) USING BTREE
)ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_doc/discuz_plugin_keke_doc.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_doc/discuz_plugin_keke_doc_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_doc/discuz_plugin_keke_doc_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_doc/discuz_plugin_keke_doc_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_doc/discuz_plugin_keke_doc_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_doc/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_doc/upgrade.php');