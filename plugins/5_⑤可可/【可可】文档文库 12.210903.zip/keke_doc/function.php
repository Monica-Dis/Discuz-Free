<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once libfile('identity', 'plugin/keke_doc');

global $_G;
$keke_doc = $_G['cache']['plugin']['keke_doc'];

function cosClient(){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    require_once DISCUZ_ROOT.'./source/plugin/keke_doc/sdk/cos-php-sdk-v5/vendor/autoload.php';
    $Client = new Qcloud\Cos\Client(
        array(
            'region' => $keke_doc['region'],
            'credentials'=> array(
                'secretId'    => $keke_doc['secretid'],
                'secretKey' => $keke_doc['secretkey']
            )
        )
    );
    return $Client;
}

function check_dir_existss( $sub1 = '', $sub2 = '') {
    $typedir = 'keke_doc';
    $subdir1  = $sub1 !== '' ?  ($typedir.'/'.$sub1) : '';
    $subdir2  = $sub1 && $sub2 !== '' ?  ($subdir1.'/'.$sub2) : '';
    $res = $subdir2 ? is_dir(getglobal('setting/attachdir').$subdir2) : ($subdir1 ? is_dir(getglobal('setting/attachdir').$subdir1) : is_dir(getglobal('setting/attachdir').$typedir));
    if(!$res) {
        $res = $typedir && discuz_upload::make_dir(getglobal('setting/attachdir').$typedir);
        $res && $subdir1 && ($res = discuz_upload::make_dir(getglobal('setting/attachdir').$subdir1));
        $res && $subdir1 && $subdir2 && ($res = discuz_upload::make_dir(getglobal('setting/attachdir').$subdir2));
    }
    return $subdir2;
}

function keke_doc_target_ext($ext){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    return strtolower(!in_array(strtolower($ext), explode(',',$keke_doc['doctype'])) ? 'attach' : $ext);
}

function _upload_file($file,$max=502400){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    require_once DISCUZ_ROOT.'./source/plugin/keke_doc/sdk/cos-php-sdk-v5/vendor/autoload.php';

    $file['size'] > ($max * 5024) && showmessage('file_size_overflow', '', array('size' => $max * 5024));
    $file['size'] = intval($file['size']);
    $file['name'] =  trim($file['name']);
    $upload = new discuz_upload();

    if(!is_array($file) || empty($file) || !$upload->is_upload_file($file['tmp_name']) || trim($file['name']) == '' || $file['size'] == 0) {
        $upload->attach = array();
        $upload->errorcode = -1;
        return false;
    } else {
        $dir=check_dir_existss(date('Ym'),date('d')).'/';
        $upload->type = getglobal('setting/attachdir').$dir;
        $upload->forcename = '';
        $file['name'] =  trim($file['name']);
        $file['ext'] = $upload->fileext($file['name']);
        if(!in_array(strtolower($file['ext']), explode(',',$keke_doc['doctype']))){
            //?????????
        }
        $file['dir'] = $dir;
        $file['thumb'] = '';
        $file['size'] = intval($file['size']);
        $file['name'] =  dhtmlspecialchars($file['name'], ENT_QUOTES);
        $file['extension'] = keke_doc_target_ext($file['ext']);
        $file['attachdir'] = $upload->type;
        $newFileName=$upload->get_target_filename($upload->type, $upload->extid, $upload->forcename).'.'.$file['extension'];
        $file['attachname'] = $newFileName;
        $file['attachment'] = $file['attachdir'].$newFileName;
        $file['target'] = $file['attachment'];
        $upload->attach = $file;
        $upload->errorcode = 0;
    }
    if(!$upload->save()) {
        exit(json_encode(array('error'=>$upload->errormessage())));
    }
    $cosClient=cosClient();
     try {
        $file = fopen($upload->attach['attachment'], 'rb');
        if ($file) {
            $result = $cosClient->Upload(
                $bucket = $keke_doc['bucket'],
                $key = $dir.$newFileName,
                $body = $file
            );
        }
    } catch (\Exception $e) {
        return False;
    }
    return $upload->attach;
}



function _upload_img($file,$width='', $height='',$max=5024,$thumb='1'){
    global $_G;

    $file['size'] > ($max * 5024) && showmessage('file_size_overflow', '', array('size' => $max * 5024));
    $upload = new discuz_upload();
    $uploadtype = 'temp';

    if(!is_array($file) || empty($file) || !$upload->is_upload_file($file['tmp_name']) || trim($file['name']) == '' || $file['size'] == 0) {
        $upload->attach = array();
        $upload->errorcode = -1;
        return false;
    } else {
        $upload->type = discuz_upload::check_dir_type('temp');
        $upload->extid = intval($data['extid']);
        $upload->forcename = '';

        $file['size'] = intval($file['size']);
        $file['name'] =  trim($file['name']);
        $file['thumb'] = '';
        $file['ext'] = $upload->fileext($file['name']);

        $file['name'] =  dhtmlspecialchars($file['name'], ENT_QUOTES);
        if(strlen($file['name']) > 90) {
            $file['name'] = cutstr($file['name'], 80, '').'.'.$file['ext'];
        }
        $file['isimage'] = $upload->is_image_ext($file['ext']);
        $file['extension'] = $upload->get_target_extension($file['ext']);
        $file['attachdir'] = _get_target_dir($upload->type);
        $file['attachment'] = $file['attachdir'].$upload->get_target_filename($upload->type, $upload->extid, $upload->forcename).'.'.$file['extension'];
        $file['target'] = getglobal('setting/attachdir').'./'.$upload->type.'/'.$file['attachment'];
        if(!$file['isimage']){
            showmessage(lang('plugin/keke_gallerys', 'f0017'), 'plugin.php?id=keke_gallerys:up', array(), array('alert' => 'error'));
        }
        $upload->attach = $file;
        $upload->errorcode = 0;
    }
    if(!$upload->save()) {
        cpmsg($upload->errormessage(), '', 'error');
    }

    if($thumb && ($upload->attach['imageinfo'][0]>$width || $upload->attach['imageinfo'][1]>$height) && $width){
        if($file['isimage']){
            require_once libfile('class/image');
            $img = new image;
            $thumbpic=$img->Thumb($upload->attach['target'], './'.$uploadtype.'/'.$upload->attach['attachment'].'_thumb.jpg', $width, $height, 'fixwr');
        }
    }

    $remote=0;
    $upload->attach['attachment']=$remote?getglobal('setting/ftp/attachurl').$upload->type.'/'.$upload->attach['attachment']:$_G['setting']['attachurl'].$upload->type.'/'.$upload->attach['attachment'];
    if($thumbpic){
        $ret= $upload->attach['attachment'].'_thumb.jpg';
    }else{
        $ret= $upload->attach['attachment'];
    }

    return $ret;

}

function _get_target_dir($type, $check_exists = true) {
    $subdir = $subdir1 = $subdir2 = '';
    $subdir1 = date('Ym');
    $subdir2 = date('d');
    $subdir = $subdir1.'/'.$subdir2.'/';
    $check_exists && discuz_upload::check_dir_exists($type, $subdir1, $subdir2);
    return $subdir;
}


function _save_cat(){
    if(is_array($_GET['newname'])) {
        foreach($_GET['newname'] as $key => $value) {
            if($value){
                $newarr=array(
                    'displayorder' => $_GET['newdisplayorder'][$key],
                    'name' => $_GET['newname'][$key],
                    'upid' => intval($_GET['upid'][$key]),
                );
                C::t('#keke_doc#keke_doc_cate')->insert($newarr);
            }
        }
    }
    if(is_array($_GET['delete'])) {
        C::t('#keke_doc#keke_doc_cate')->delete($_GET['delete']);
    }
    if(is_array($_GET['name'])) {
        foreach($_GET['name'] as $keys => $value) {
            $updatearr=array(
                'displayorder' => $_GET['displayorder'][$keys],
                'name' => $_GET['name'][$keys],
            );
            C::t('#keke_doc#keke_doc_cate')->update($keys, $updatearr);
        }
    }
    $allcatedata=C::t('#keke_doc#keke_doc_cate')->fetch_all_by_displayorder();
    require_once libfile('function/cache');
    savecache('keke_doc_cate', $allcatedata);
}

function urlRoute($url,$type=0){
    $allSet=kekeGetSet();
    if($allSet['rewrite_off']){
        $arr = parse_url($url);
        $urlarr=convertUrlQuery($arr['query']);
        $url=$allSet['rewrite_index'];
        if($urlarr['ac']=='list'){
            if($urlarr['cate']){
                if(!$urlarr['page'] && !$urlarr['o']){
                    $url=$allSet['rewrite_list'].'-'.$urlarr['cate'];
                }else{
                    $url=$allSet['rewrite_list'].'-'.$urlarr['cate'].'-o-'.($urlarr['o']?:0).'-p-'.($urlarr['page']?:1);
                }
            }else{
                $url=$allSet['rewrite_list'];
            }
        }elseif($urlarr['ac']=='view'){
            $url=$allSet['rewrite_view'].'-'.$urlarr['did'];
        }elseif($urlarr['ac']=='account'){
            $url=$allSet['rewrite_account'];
            if($urlarr['op']){
                $url=$allSet['rewrite_account'].'-'.$urlarr['op'];
                if($urlarr['page']){
                    $url=$allSet['rewrite_account'].'-'.$urlarr['op'].'-'.$urlarr['page'];
                }
            }
        }elseif($urlarr['ac']=='user'){
            $url=$allSet['rewrite_user'].'-'.$urlarr['uid'].($urlarr['o']?'-'.$urlarr['o']:'');
        }elseif($urlarr['ac']=='pay'){
            $url=$allSet['rewrite_pay'].'-'.$urlarr['cid'];
        }elseif($urlarr['ac']=='user-list'){
            $url=$allSet['rewrite_user-list'];
        }
        $url.=$allSet['rewrite_suffix'];
    }
    if($type){
        return $url;
    }else{
        echo $url;
    }

}

function convertUrlQuery($query){
    $queryParts = explode('&', $query);
    $params = array();
    foreach ($queryParts as $param) {
        $item = explode('=', $param);
        $params[$item[0]] = $item[1];
    }
    return $params;
}

function kekeGetAllCate(){
    global $_G;
    loadcache('keke_doc_cate');
    return $_G['cache']['keke_doc_cate']?:C::t('#keke_doc#keke_doc_cate')->fetch_all_by_displayorder();
}

function keke_doc_utf2gbk($data){
    $data1 = diconv($data,'utf-8','gbk');
    $data0 = diconv($data1,'gbk','utf-8');
    if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
    return CHARSET=='gbk'?$tmpstr:$data;
}

function keke_doc_gbk2utf($data){
    $data1 = diconv($data,'utf-8','gbk');
    $data0 = diconv($data1,'gbk','utf-8');
    if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
    return diconv($tmpstr,'gbk','utf-8');
}

function getXlsType(){
    return['xls','xlt','et','ett','xlsx','xltx','csv','xlsb','xlsm','xltm','ets'];
}

function CreateJob($docfile=''){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    require_once DISCUZ_ROOT . './source/plugin/keke_doc/class/auth.class.php';
    $docPosition=explode('.',$docfile);
    $xlsArr=getXlsType();
    $sheet='';
    if(in_array($docPosition[1],$xlsArr)){
        $sheet='${SheetID}-';
    }
    $postArr=array(
        'Request'=>array(
            'Tag'=>'DocProcess',
            'Input'=>array(
                'Object'=>$docfile
            ),
            'Operation'=>array(
                'Output'=>array(
                    'Region'=>$keke_doc['region'],
                    'Object'=>$docPosition[0].'/'.$sheet.'${Number}.jpg',
                    'Bucket'=>$keke_doc['bucket']
                ),
                'DocProcess'=>array(
                    'StartPage'=>1,
                    'ImageParams'=>($keke_doc['watermark']?'watermark/2/text/'.keke_UrlSafe_b64Encode(keke_doc_gbk2utf($keke_doc['watermark'])).'/fill/IzNEM0QzRA/fontsize/18/dissolve/5/gravity/northeast/dx/0/dy/0/batch/1/degree/45':'')
                )
            ),
            'QueueId'=>$keke_doc['queueId']
        )
    );
    $query=array();
    $hostUrl=$keke_doc['bucket'].'.ci.'.$keke_doc['region'].'.myqcloud.com';
    $contentType='application/xml';
    $Client=new CosAuth();
    $headers=array(
        'host'=>$hostUrl,
        'content-type'=> $contentType
    );
    $auth=$Client->getAuthorization('post', 'doc_jobs', $query, $headers);
    $header = array(
        "Authorization: ".$auth,
        "Content-type: ".$contentType
    );
    $rUrl='https://'.$hostUrl.'/doc_jobs';
    $ret=kekeDocRequest($header,'POST',$rUrl,arr2xml($postArr));
    $thumbArr=$postArr;
    $thumbArr['Request']['Operation']['DocProcess']['ImageParams']='imageMogr2/thumbnail/200x';
    $thumbArr['Request']['Operation']['DocProcess']['EndPage']='1';
    $thumbArr['Request']['Operation']['Output']['Object']=$docPosition[0].'/thumb'.$sheet.'${Number}.jpg';
    kekeDocRequest($header,'POST',$rUrl,arr2xml($thumbArr));
    return xml2arr($ret);
}

function GetViewImg($docurl,$pageId=1){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    require_once DISCUZ_ROOT . './source/plugin/keke_doc/class/auth.class.php';
    $Client=new CosAuth();
    $query=$headers=[];
    $auth=$Client->getAuthorization('get', removeSuffix($docurl).'/'.$pageId.'.jpg', $query, $headers);
    $hostUrl=$keke_doc['domain']?:'https://'.$keke_doc['bucket'].'.cos.'.$keke_doc['region'].'.myqcloud.com';
    return $hostUrl.'/'.removeSuffix($docurl).'/'.$pageId.'.jpg?'.$auth;
}

function removeSuffix($docName){
    return str_replace(strrchr($docName, "."),"",$docName);;
}


function getUsNames($uids){
    return C::t('common_member')->fetch_all_username_by_uid($uids);
}

function getDocData($did){
    return C::t('#keke_doc#keke_doc')->fetchfirst_byid($did);
}

function checkMyDoc($did){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    $doc=getDocData($did);
    return C::t('#keke_doc#keke_doc_mydoc')->count_all('did='.$did.' AND uid='.$_G['uid']) || ($doc['price']==0 && !$doc['credit']) || in_array($_G['groupid'],unserialize($keke_doc['svip']));
}

function activeGetPage($did){
    $doc=C::t('#keke_doc#keke_doc')->fetchfirst_byid($did);
    $jobData=getDocJobs($doc['jobid']);
    $totalPage=$jobData['JobsDetail']['Operation']['DocProcessResult']['TotalPageCount'];
    if($totalPage){
        C::t('#keke_doc#keke_doc')->update($did,array('page'=>$totalPage));
    }
    return $totalPage;
}

function kekeSaveCache($name){
    $name=kekeEditorSafeReplace($name);
    $content = C::t('#keke_doc#keke_doc_'.$name)->fetch_all();
    foreach($content as $key=>$val){
        $ret[$val['id']]=$val;
    }
    require_once libfile('function/cache');
    savecache('keke_doc_'.$name, $ret);
}

function kekeGetCache($name){
    global $_G;
    $name=kekeEditorSafeReplace($name);
    loadcache('keke_doc_'.$name);
    $data=$_G['cache']['keke_doc_'.$name]?:C::t('#keke_doc#keke_doc_'.$name)->fetch_all();
    return $data;
}

function kekeGetSet(){
    $allSet=kekeGetCache('set');
    foreach($allSet as $v){
        $set[$v['id']]=$v['val'];
    }
    return $set;
}

function kekeInsertSet($arr){
    $set=kekeGetSet();
    foreach($arr as $key=>$val){
        if(isset($set[$key])){
            C::t('#keke_doc#keke_doc_set')->update($key,array('val'=>$val));
        }else{
            C::t('#keke_doc#keke_doc_set')->insert(array('id'=>$key,'val'=>$val));
        }
    }
    kekeSaveCache('set');
}

function arr2xml($data, $root = true){
    $str="";
    if($root)$str .= '<?xml version="1.0" encoding="UTF-8"?>';
    foreach($data as $key => $val){
        if(is_array($val)){
            $child = arr2xml($val, false);
            $str .= "<$key>$child</$key>";
        }else{
            $str.= "<$key>$val</$key>";
        }
    }
    return $str;
}

function xml2arr($data){
    $jsonxml = json_encode(simplexml_load_string($data, 'SimpleXMLElement', LIBXML_NOCDATA));
    return json_decode($jsonxml, true);
}

function keke_UrlSafe_b64Encode($string) {
    $data = base64_encode($string);
    return str_replace(array('+','/','='),array('-','_',''),$data);
}

function kekeDocRequest($header,$method,$url,$requestBody,$retHeader=0){
    $curlHandle = curl_init();
    curl_setopt($curlHandle, CURLOPT_URL, $url);
    curl_setopt($curlHandle, CURLOPT_HEADER, 0);
    curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($curlHandle, CURLOPT_HTTPHEADER, $header);
    curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($curlHandle, CURLOPT_CUSTOMREQUEST, $method);
    if($retHeader) {
        curl_setopt($curlHandle, CURLOPT_HEADER, true);
        curl_setopt($curlHandle, CURLOPT_NOBODY, $retHeader==2);
    }
    if ($requestBody) {
        curl_setopt($curlHandle, CURLOPT_POST, 1);
        curl_setopt($curlHandle, CURLOPT_POSTFIELDS, $requestBody);
    }
    curl_setopt($curlHandle, CURLOPT_CONNECTTIMEOUT, 2);
    curl_setopt($curlHandle, CURLOPT_TIMEOUT, 2);
    $response = curl_exec($curlHandle);
    $error = curl_error($curlHandle);
    $errno = curl_errno($curlHandle);
    if ($error) {
        throw new Exception("cURL Error #{$errno}. $error", 1);
    }
    if($retHeader){
        $headerSize = curl_getinfo($curlHandle, CURLINFO_HEADER_SIZE);
        $header = substr($response, 0, $headerSize);
        $responses= substr($response, $headerSize);
        return [$responses,$header];
    }
    return $response;
}

function kekeEditorSafeReplace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}


function filterMultiPage($multipage,$type=1){
    $multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
    if($type){
        $multipage=str_replace('href=', 'href="javascript:" data-pageurl=', $multipage);
    }
    return $multipage;
}

function kekeShowAdminSubMenu($par,$pmod){
    global $plugin;
    foreach($par as $key=>$val){
        $class=$_GET['op']==$val[1]?'class="current"':'';
        $li.='<li '.$class.'><a href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin['pluginid'].'&identifier='.$plugin['identifier'].'&pmod='.$pmod.'&op='.$val[1].'\'><span>'.$val[0].'</span></a></li>';
    }
    $html='<div class="itemtitle"><div class="floatsub"><div style="margin-top:5px;"><ul class="tab1">'.$li.'</ul></div></div></div>';
    echo $html;
}

function kekeGetFileType($ext){
    $docArr=array('doc','doc','dot','wps','wpt','docx','dotx','docm','dotm');
    $xlsArr=array('xls','et','xlsx');
    $pptArr=array('pptx','ppt','pot','potx','pps','ppsx','dps','dpt','pptm','potm','ppsm');
    switch (true) {
        case in_array($ext,$docArr):
            $ret='doc';
            break;
        case in_array($ext,$xlsArr):
            $ret='xls';
            break;
        case in_array($ext,$pptArr):
            $ret='ppt';
            break;
        case $ext=='pdf':
            $ret='pdf';
            break;
        case $ext=='txt':
            $ret='txt';
            break;
        default:
            $ret='file';
            break;
    }
    return $ret;
}

function getTypeIcon($ext){
    switch (kekeGetFileType($ext)) {
        case 'doc':
            $type=['doc','&#xe7bb;'];
            break;
        case 'pdf':
            $type=['pdf','&#xe7b8;'];
            break;
        case 'xls':
            $type=['xls','&#xe7b7;'];
            break;
        case 'ppt':
            $type=['ppt','&#xe7ba;'];
            break;
        default:
            $type=['file','&#xe7bc;'];
            break;
    }
    return '<i class="keke_iconfont '.$type[0].'">'.$type[1].'</i>';
}


function getAuthorInfo($uid){
    global $_G;
    $authorInfo = array(
        'count'=>C::t('#keke_doc#keke_doc')->count_all('uid='.$uid),
        'follow'=>C::t('#keke_doc#keke_doc_follow')->count_all('authorid='.$uid),
        'checkfollow'=>C::t('#keke_doc#keke_doc_follow')->count_all('uid='.$_G['uid'].' AND authorid='.$uid),
        'checkfavorites'=>C::t('#keke_doc#keke_doc_favorites')->fetchfirst_bydid(intval($_GET['did']),$_G['uid']),
        'userInfo'=>C::t('#keke_doc#keke_doc_user')->fetchfirst_byuid($uid),
        'praise'=>C::t('#keke_doc#keke_doc_evaluate')->count_all('authorid='.$uid.' AND star>=4'),
    );
    $authorInfo['userInfo']['name']=$authorInfo['userInfo']['name']?:getuserbyuid($uid)['username'];
    return $authorInfo;
}

function checkLogin(){
    global $_G;
    if(!$_G['uid']){
        exit(json_encode(array('state'=>2,'msg'=>keke_doc_gbk2utf(lang('plugin/keke_doc', '156')))));
    }
}

function checkAuthor($uid){
    global $_G;
    if($uid!=$_G['uid']){
        exit(json_encode(array('state'=>1,'msg'=>keke_doc_gbk2utf(lang('plugin/keke_doc', '184')))));
    }
}

function getIndexDocList(){
    $doc_list = C::t('#keke_doc#keke_doc')->fetch_by_catenew(12);
    $xlsArr=getXlsType();
    foreach ($doc_list as $key=>$item) {
        foreach ($item as $cate=>$val) {
            $pageId='1';
            if(in_array($val['ext'],$xlsArr)){
                $pageId='1-1';
            }
            $doc_list[$key][$cate]['thumb']=GetViewImg($val['docsrc'],'thumb'.$pageId);
        }
    }
    return $doc_list;
}

function getDocListThumb($list){
    $xlsArr=getXlsType();
    foreach ($list as $key=>$val) {
        $pageId='1';
        if(in_array($val['ext'],$xlsArr)){
            $pageId='1-1';
        }
        $list[$key]['thumb']=GetViewImg($val['docsrc'],$pageId);
    }
    return $list;
}


function getListData($startlimit,$ppp,$where){
    $ac=dhtmlspecialchars($_GET['ac']);
    return array(
        C::t('#keke_doc#keke_doc_'.$ac)->count_all($where),
        C::t('#keke_doc#keke_doc_'.$ac)->fetch_all_data($startlimit,$ppp,$where)
    );
}

function getCateSelect(){
    $opt='';
    $CateData = kekeGetAllCate();
    $getCateId=intval($_GET['cateid']);
    foreach ($CateData as $cate) {
        if($cate['upid']==0){
            $selected = ($getCateId==$cate['cate_id']) ? 'selected="selected"' : '';
            $opt.='<option value="'.$cate['cate_id'].'" '.$selected.' style="font-weight :bold;">'.$cate['name'].'</option>';
            if($cate['subcate']){
                foreach ($cate['subcate'] as $subCateId=>$subCate) {
                    $selected = ($getCateId==$subCateId) ? 'selected="selected"' : '';
                    $opt.='<option value="'.$subCateId.'" '.$selected.' >&nbsp;&nbsp;|--'.$CateData[$subCateId]['name'].'</option>';
                    if(is_array($subCate)){
                        foreach ($subCate as $tCateId) {
                            $selected = ($getCateId==$tCateId) ? 'selected="selected"' : '';
                            $opt.='<option value="'.$tCateId.'" '.$selected.' >&nbsp;&nbsp;|&nbsp;&nbsp;|--'.$CateData[$tCateId]['name'].'</option>';
                        }
                    }
                }
            }
        }
    }
    return $opt;
}

function getCreditOpt($select){
    global $_G;
    $opt='';
    foreach ($_G['setting']['extcredits'] as $creditId=>$credit) {
        $opt.='<option value="'.$creditId.'" '.($select==$creditId?'selected="selected"':'').'>'.$credit['title'].'</option>';
    }
    return $opt;
}

function docCreateOrder(){
    global $_G;
    $nowdate=dgmdate($_G['timestamp'], 'YmdHis');
    $random=random(10);
    return $nowdate.$random;
}
function docInstOrder($orderid,$zftype,$did,$doc){
    global $_G;
    $orderArr=array(
        'id'=>$orderid,
        'uid'=>$_G['uid'],
        'pay_type'=>$zftype,
        'price'=>$doc['price'],
        'credit'=>$doc['credit'],
        'credit_type'=>$doc['credit_type'],
        'did'=>$did,
        'author_uid'=>$doc['uid'],
        'time'=>TIMESTAMP,
    );
    C::t('#keke_doc#keke_doc_order')->insert($orderArr, true);
}

function upDateOrder($orderId,$sn=''){
    global $_G;
    $allSet=kekeGetSet();
    $orderData=C::t('#keke_doc#keke_doc_order')->fetchfirst_byid($orderId);
    if($orderData['state']==1){
        return;
    }
    $doc = getDocData($orderData['did']);
    $commissionArr=unserialize($allSet['commission']);
    $orderMoney=$orderData['price'];
    $oedercredit=$orderData['credit'];
    $commission=[];
    if($proportion=$commissionArr[getuserbyuid($doc['uid'])['groupid']]){
        $commission=['money'=>$orderMoney*$proportion/100,'credit'=>intval($oedercredit*$proportion/100)];
        $orderMoney-=$commission['money'];
        $oedercredit-=$commission['credit'];
    }
    $payTitle=lang('plugin/keke_doc', '185').' <a href="'.urlRoute('plugin.php?id=keke_doc&ac=view&did='.$orderData['did'],1).'" target="_blank">'.lang('plugin/keke_doc', '186').$doc['title'].lang('plugin/keke_doc', '187').'</a> '.lang('plugin/keke_doc', '188');
    if($orderData['price']>0){
        @include_once DISCUZ_ROOT."source/plugin/keke_wallet/api.php";
        updateuserwallet($doc['uid'],$orderMoney,$sn,$payTitle.($commission['money']>0?lang('plugin/keke_doc', '189').' '.$commission['money'].' '.lang('plugin/keke_doc', '67').lang('plugin/keke_doc', '190'):''),lang('plugin/keke_doc', '191'));
    }
    if($orderData['credit']){
        updatemembercount($doc['uid'], array('extcredits'.$orderData['credit_type']=>$oedercredit), true, '', 0, '','�Ŀ�����',$payTitle.($commission['credit']?lang('plugin/keke_doc', '189').' '.$commission['credit'].' '.$_G['setting']['extcredits'][$orderData['credit_type']]['title'].lang('plugin/keke_doc', '190'):''));
    }

    C::t('#keke_doc#keke_doc_mydoc')->insert(array(
        'uid'=>$orderData['uid'],
        'did'=>$orderData['did'],
        'time'=>TIMESTAMP
    ));
    C::t('#keke_doc#keke_doc_order')->update($orderId, array(
        'state'=>1,
        'sn'=>$sn,
        'paytime'=>TIMESTAMP,
    ));
}

function getDocDownUrl($did){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    require_once DISCUZ_ROOT . './source/plugin/keke_doc/class/auth.class.php';
    $Client = new CosAuth();
    $query = $headers=[];
    $doc = getDocData($did);
    $auth=$Client->getAuthorization('get', $doc['docsrc'], $query, $headers);
    $hostUrl=$keke_doc['domain']?:'https://'.$keke_doc['bucket'].'.cos.'.$keke_doc['region'].'.myqcloud.com';
    $filename = $keke_doc['orgfilename']?urlencode(';filename='.$doc['filename']):'';
    return $hostUrl.'/'.$doc['docsrc'].'?'.$auth.'&response-content-type=application%2Foctet-stream&response-content-disposition=attachment'.$filename;
}

function replaceVariable($str,$variable){
    $search=$replace=[];
    foreach ($variable as $key=>$item) {
        $search[]='['.$key.']';
        $replace[]=$item;
    }
    return str_replace($search,$replace,$str);
}

function getRanking(){
    return [
        C::t('#keke_doc#keke_doc')->count_all_by_uidgroup(),
        C::t('#keke_doc#keke_doc_order')->sum_all_by_uidgroup(),
        C::t('#keke_doc#keke_doc_order')->sum_all_credit_by_uidgroup(),
    ];
}

function getDocJobs($jobId){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    require_once DISCUZ_ROOT . './source/plugin/keke_doc/class/auth.class.php';
    $Client=new CosAuth();
    $hostUrl=$keke_doc['bucket'].'.ci.'.$keke_doc['region'].'.myqcloud.com';
    $headers=array(
        'host'=>$hostUrl
    );
    $pathname='doc_jobs/'.$jobId;
    $query=[];
    $auth=$Client->getAuthorization('get', $pathname, $query, $headers);
    $header = array(
        "Authorization: ".$auth,
    );
    $rUrl='https://'.$hostUrl.'/'.$pathname;
    try {
        return xml2arr(kekeDocRequest($header, 'GET', $rUrl, []));
    } catch (Exception $e) {
    }
}

function kekeToLogin(){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    if(!$_G['uid']){
        if(K_INCMAG){
            $userdata = getUserByMag();
            if($userdata['user_id']){
                setMemberlogin($userdata['user_id']);
            }else{
                exit('<script src="source/plugin/keke_doc/template/js/magjs-x.js"></script><script>mag.toLogin(function(rs){window.location.reload(true);});</script>');
            }
        }elseif(K_INQIANFAN){
            require_once DISCUZ_ROOT . './source/plugin/keke_doc/class/qianfan.class.php';
            $client = new QF_HTTP_CLIENT($keke_doc['qfhostname'],$keke_doc['qftoken']);
            $wap_token_data = $client->post('users/parse-wap-token', array('wap_token' => $_COOKIE['wap_token']));
            if ($wap_token_data['data']['uid'] > 0) {
                setMemberlogin($wap_token_data['data']['uid']);
            }else{
                exit('<script>function QFH5ready(){QFH5.jumpLogin(function(state,data){if(state==1){QFH5.refresh(1);}else{alert(data.error);}});}</script>');
            }
        }else{
            if(checkmobile()){
                $refererurl=$_G['siteurl'].'plugin.php?'.$_SERVER["QUERY_STRING"];
                dheader("Location: ".$_G['siteurl']."member.php?mod=logging&action=login&referer=".urlencode($refererurl));
            }else{
                showmessage('not_loggedin', NULL, array(), array('login' => 1));
            }
        }
    }
}

function setMemberlogin($uid){
    require_once libfile('function/member');
    $member = getuserbyuid($uid,1);
    setloginstatus($member, 2592000);
}

function getUserByMag(){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    $userAgent = $_SERVER['HTTP_USER_AGENT'];
    $info = strstr($userAgent, "MAGAPPX");
    $info=explode("|",$info);
    $url='http://'.$keke_doc['magurl'].'/mag/cloud/cloud/getUserInfo?token='.$info[7].'&secret='.$keke_doc['magsecret'];
    $data = dfsockopen($url);
    if(!$data) {
        $data = file_get_contents($url);
    }
    $data=json_decode($data,true);
    return $data['data'];
}

function getRecommend(){
    return getDocListThumb(C::t('#keke_doc#keke_doc')->fetch_all_doc(0, 12, 'recommend=1 AND state=3'));
}

function getNewDoc(){
    return getDocListThumb(C::t('#keke_doc#keke_doc')->fetch_all_doc(0, 12, 'state=3'));
}

function getDocList($where,$tmpurl,$order='',$ppp=15){
    global $_G;
    $page = max(1, intval($_GET['page']));
    $startlimit = ($page - 1) * $ppp;
    $countAll = C::t('#keke_doc#keke_doc')->count_all($where);
    $docListData = C::t('#keke_doc#keke_doc')->fetch_all_doc($startlimit, $ppp, $where,$order);
    foreach ($docListData as $key => $item) {
        $pageId='1';
        if(in_array($item['ext'],getXlsType())){
            $pageId='1-1';
        }
        $docListData[$key]['thumb'] = GetViewImg($item['docsrc'],'thumb'.$pageId);
        $docListData[$key]['url'] = urlRoute('plugin.php?id=keke_doc&ac=view&did='.$item['id'],1);;
    }
    return [$docListData,filterMultiPage(multi($countAll, $ppp, $page, $_G['siteurl'] . $tmpurl), 0),$countAll];
}

function formatBytes($size){
    $units = array('B','K','M','G','T');
    $i = 0;
    for( ; $size>=1024 && $i<count($units); $i++){
        $size /= 1024;
    }
    return round($size,2).$units[$i];
}

function getCredit(){
    global $_G;
    $keke_doc = $_G['cache']['plugin']['keke_doc'];
    $creditTypeArr=[];
    if($keke_doc['credittype']){
        $creditType=explode(',',$keke_doc['credittype']);
        foreach ($creditType as $type) {
            $creditTypeArr[$type]=$_G['setting']['extcredits'][$type];
        }
    }else{
        $creditTypeArr=$_G['setting']['extcredits'];
    }
    return $creditTypeArr;
}

function kekeCutStr($sourcestr,$cutlength){
    $returnstr='';
    $i=0;
    $n=0;
    $str_length=strlen($sourcestr);
    while (($n<$cutlength) and ($i<=$str_length)) {
        $temp_str=substr($sourcestr,$i,1);
        $ascnum=Ord($temp_str);
        if ($ascnum>=224) {
            $returnstr=$returnstr.substr($sourcestr,$i,3);
            $i=$i+3;
            $n++;
        }
        elseif ($ascnum>=192) {
            $returnstr=$returnstr.substr($sourcestr,$i,2);
            $i=$i+2;
            $n++;
        }
        elseif ($ascnum>=65 && $ascnum<=90) {
            $returnstr=$returnstr.substr($sourcestr,$i,1);
            $i=$i+1;
            $n++;
        }
        else {
            $returnstr=$returnstr.substr($sourcestr,$i,1);
            $i=$i+1;
            $n=$n+0.5;
        }
    }
    if ($str_length>$i){
        $returnstr = $returnstr . "��";
    }
    return $returnstr;
}

function getRangeNum($range){
    $BaseNum=explode('~',$range);
    return mt_rand($BaseNum[0], $BaseNum[1]);
}

function wanNum($num){
    if($num > 1000 && $num < 10000){
        return round(($num / 1000),1).'k';
    }
    if($num > 10000 ){
        return round(($num / 10000),1).'w';
    }
    return $num;
}