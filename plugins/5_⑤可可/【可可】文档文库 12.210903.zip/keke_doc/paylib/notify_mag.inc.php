<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);
require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

loadcache('plugin');
require_once DISCUZ_ROOT."source/plugin/keke_doc/function.php";
@require_once DISCUZ_ROOT."source/plugin/keke_pay/payinc.php";
$keke_notify=new keke_notify;
$result=$keke_notify->CheckMagAppNotify();
if($result===true){
    upDateOrder($_GET['out_trade_no'],5);
    exit('success');
}
exit('error');