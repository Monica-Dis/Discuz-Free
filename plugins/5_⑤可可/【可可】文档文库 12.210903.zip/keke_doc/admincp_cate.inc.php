<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
loadcache('plugin');
require_once DISCUZ_ROOT.'./source/plugin/keke_doc/function.php';
if(submitcheck('catesubmit')) {
    _save_cat();
    cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_cate', 'succeed');
}
if($_GET['ac']=='editvipgroup'){
    $cateid=intval($_GET['cateid']);
    if (submitcheck("editsubmit")) {
        C::t('#keke_doc#keke_doc_cate')->update($cateid,array(
            'vip_groupids'=>($_GET['groupid'][0]?serialize($_GET['groupid']):''),
        ));
        _save_cat();
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_cate', 'succeed');
    }
    $allcatedata=kekeGetAllCate();
    $vipGroupArr=unserialize($allcatedata[$cateid]['vip_groupids']);
    $query = C::t('common_usergroup')->fetch_all_not(array(6, 7), true);
    foreach($query as $group) {
        $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
        $groupselect[$group['type']] .= "<option value=\"$group[groupid]\" ".(in_array($group['groupid'], $vipGroupArr) ? 'selected' : '').">$group[grouptitle]</option>\n";
    }
    $groupselect = '<optgroup label="'.$lang['usergroups_member'].'">'.$groupselect['member'].'</optgroup>'.
        ($groupselect['special'] ? '<optgroup label="'.$lang['usergroups_special'].'">'.$groupselect['special'].'</optgroup>' : '').
        ($groupselect['specialadmin'] ? '<optgroup label="'.$lang['usergroups_specialadmin'].'">'.$groupselect['specialadmin'].'</optgroup>' : '').
        '<optgroup label="'.$lang['usergroups_system'].'">'.$groupselect['system'].'</optgroup>';
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_cate&ac=editvipgroup");
    showtips(lang('plugin/keke_doc', '47'));
    showtableheader($allcatedata[$cateid]['name'].' - '.lang('plugin/keke_doc', '48'));
    showsetting('members_search_group', '', '', '<select name="groupid[]" multiple="multiple" size="10">'."<option value='' ".(!$allcatedata[$cateid]['vip_groupids'] ? 'selected' : '').">'.lang('plugin/keke_doc', '49').'</option>\n".$groupselect.'</select>');
    echo '<input name="cateid" type="hidden" value="'.$cateid.'" />';
    showsubmit('editsubmit', 'submit', '','');
    showtablefooter(); /*dism _taobao _com*/
    showformfooter(); /*dism_taobao_com*/
    exit;
}
showformheader('plugins&operation=config&do=' . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . '&pmod=admincp_cate','testhd');
showtableheader(lang('plugin/keke_doc', '50'));
showsubtitle(array('del', '', '',lang('plugin/keke_doc', '15')));
$allcatedata=kekeGetAllCate();
foreach($allcatedata as $key => $value) {
    if(!$value['upid']){
        if(!$value['upid'] && $reckey) {
            $upid = $allcatedata[$reckey]['upid'] ? $allcatedata[$reckey]['upid'] : $reckey;
            echo '<tr><td></td><td colspan="20"><div class="lastboard"><a href="###" onclick="addrow(this, 1, '.$upid.')" class="addtr">'.lang('plugin/keke_doc', '52').'</a></div></td></tr>';
        }
        $groupArr=$value['vip_groupids']?unserialize($value['vip_groupids']):array();
        $groupNum=count($groupArr);

        showtablerow('', array('class="td25"', '','class="td24"','class="td25"'), array(
            '<input type="checkbox" class="checkbox" name="delete[]" value="'.$value['cate_id'].'" />',
            '<div class="parentboard"><input type="text" class="txt" name="name['.$value['cate_id'].']" value="'.$value['name'].'" /><span class="lightfont"> id: '.$value['cate_id'].'</span></div>',
            ($value['upid'] || !$value['subcate']?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_doc&pmod=admincp_cate&ac=editvipgroup&cateid='.$value['cate_id'].'">'.lang('plugin/keke_doc', '48').'</a> ('.$groupNum.')':''),
            '<input type="text" class="txt" name="displayorder['.$value['cate_id'].']" value="'.$value['displayorder'].'" />',
        ));
        if($value['subcate']){
            foreach ($value['subcate'] as $secondCateId=>$secondCateVal){
                showtablerow('', array('class="td25"', '','class="td24"','class="td25"'), array(
                    '<input type="checkbox" class="checkbox" name="delete[]" value="'.$secondCateId.'" />',
                    '<div class="board"><input type="text" class="txt" name="name['.$secondCateId.']" value="'.$allcatedata[$secondCateId]['name'].'" /><a class="addchildboard" onclick="addrowdirect = 1;addrow(this, 2, '.$secondCateId.')" href="###">'.lang('plugin/keke_doc', '51').'</a> <span class="lightfont"> id: '.$secondCateId.'</span></div>',
                    ($value['upid'] || !$value['subcate']?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_doc&pmod=admincp_cate&ac=editvipgroup&cateid='.$secondCateId.'">'.lang('plugin/keke_doc', '48').'</a> ('.$groupNum.')':''),
                    '<input type="text" class="txt" name="displayorder['.$secondCateId.']" value="'.$allcatedata[$secondCateId]['displayorder'].'" />',
                ));
                if($secondCateVal){
                    foreach ($secondCateVal as $thirdCateId){
                        showtablerow('', array('class="td25"', '','class="td24"','class="td25"'), array(
                            '<input type="checkbox" class="checkbox" name="delete[]" value="'.$thirdCateId.'" />',
                            '<div class="childboard"><input type="text" class="txt" name="name['.$thirdCateId.']" value="'.$allcatedata[$thirdCateId]['name'].'" /><span class="lightfont"> id: '.$thirdCateId.'</span></div>',
                            ($value['upid'] || !$value['subcate']?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_doc&pmod=admincp_cate&ac=editvipgroup&cateid='.$thirdCateId.'">'.lang('plugin/keke_doc', '48').'</a> ('.$groupNum.')':''),
                            '<input type="text" class="txt" name="displayorder['.$thirdCateId.']" value="'.$allcatedata[$thirdCateId]['displayorder'].'" />',
                        ));
                    }
                }
            }
        }
        $reckey = $key;
    }
}
if($reckey) {
    $upid = $allcatedata[$reckey]['upid'] ? $allcatedata[$reckey]['upid'] : $reckey;
}
if($upid) {
    echo '<tr><td></td><td colspan="20"><div class="lastboard"><a href="#" onclick="addrow(this, 1, '.$upid.')" class="addtr">'.lang('plugin/keke_doc', '52').'</a></div></td></tr>';
}
echo '<tr><td></td><td><div><a href="###" onclick="addrow(this, 0)" class="addtr">'.lang('plugin/keke_doc', '53').'</a></div></td><td colspan="20"></td></tr>';
showsubmit('catesubmit', 'submit', 'del');
showtablefooter(); /*dism _taobao _com*/
showformfooter(); /*dism_taobao_com*/
?>
<script type="text/javascript">
var rowtypedata = [
    [[1, '<input type="checkbox" class="checkbox" name="newhot[]" />', 'td25'], [1, '<input type="text" class="txt" name="newname[]" />', ''], [1, '', ''],[1, '<input type="text" class="txt" name="newdisplayorder[]" />', 'td25'], [1, '<input type="hidden" name="upid[]" value="0" />']],
    [[1, '<input type="checkbox" class="checkbox" name="newhot[]" />', 'td25'], [1, '<div class="board"><input type="text" class="txt" name="newname[]" /></div>', ''], [1, '', ''],[1, '<input type="text" class="txt" name="newdisplayorder[]" />', 'td25'],  [1, '<input type="hidden" name="upid[]" value="{1}" />']],
    [[1, '<input type="checkbox" class="checkbox" name="newhot[]" />', 'td25'], [1, '<div class="childboard"><input type="text" class="txt" name="newname[]" /></div>', ''], [1, '', ''],[1, '<input type="text" class="txt" name="newdisplayorder[]" />', 'td25'],  [1, '<input type="hidden" name="upid[]" value="{1}" />']],
];
</script>