<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}




class QF_HTTP_CLIENT
{
   

	public function __construct($hostname='',$token = '') {
        $this->hostname = $hostname;
        $this->token = $token;
    }

    /**
     * @param string $method 请求方式
     * @param string $path 请求路径
     * @param array $requestBody 请求体参数
     * @return array
     * @throws Exception
     */
    private function _request($method, $path, $requestBody)
    {
        $header = array(
            "Authorization: Bearer {$this->token}",
            "Content-Type: application/x-www-form-urlencoded",
            "Cache-Control: no-cache",
            "Accept: application/json",
            "User-Agent: QianFanHttpClient/1.0.0"
        );
        $url = "https://{$this->hostname}.qianfanapi.com/openapi/{$path}";
        $curlHandle = curl_init();
        curl_setopt($curlHandle, CURLOPT_URL, $url);
        curl_setopt($curlHandle, CURLOPT_HEADER, 0);
        curl_setopt($curlHandle, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curlHandle, CURLOPT_HTTPHEADER, $header);
        curl_setopt($curlHandle, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curlHandle, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curlHandle, CURLOPT_CUSTOMREQUEST, $method);
        if (count($requestBody)) {
            curl_setopt($curlHandle, CURLOPT_POST, 1);
            curl_setopt($curlHandle, CURLOPT_POSTFIELDS, http_build_query($requestBody));
        }
        curl_setopt($curlHandle, CURLOPT_CONNECTTIMEOUT, 2); // 连接超时
        curl_setopt($curlHandle, CURLOPT_TIMEOUT, 2); // 响应超时

        $response = curl_exec($curlHandle);
        $error = curl_error($curlHandle);
        $errno = curl_errno($curlHandle);
        // $status = curl_getinfo($curlHandle, CURLINFO_HTTP_CODE);
        curl_close($curlHandle);

        if ($error) {
            throw new Exception("cURL Error #{$errno}. $error", 1);
        }

        $data = json_decode($response, true);
        if (json_last_error() != JSON_ERROR_NONE) {
            $error = json_last_error_msg();
            $errno = json_last_error();
            throw new Exception("Json Parsing Error #{$errno}. $error", 1);
        }
        return $data;
    }

    public function get($path)
    {
        return $this->_request('GET', $path, []);
    }

    public function put($path, $data)
    {
        return $this->_request('PUT', $path, $data);
    }

    public function post($path, $data)
    {
        return $this->_request('POST', $path, $data);
    }

    public function delete($path, $data)
    {
        return $this->_request('DELETE', $path, $data);
    }
}