<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;
loadcache('plugin');
$keke_doc = $_G['cache']['plugin']['keke_doc'];
include_once DISCUZ_ROOT . "source/plugin/keke_doc/function.php";
$CateData = kekeGetAllCate();
$_GET['op']=$_GET['op']?:'user';
kekeShowAdminSubMenu(array(
    array(lang('plugin/keke_doc', '155'), "user"),
    array(lang('plugin/keke_doc', '156'), "commission"),
),'admincp_user');

if ($_GET['op'] == 'commission') {
    if (!submitcheck("forumset")) {
        $allSet=kekeGetSet();
        $commissionArr=unserialize($allSet['commission']);
        $groupIds = unserialize($keke_doc['allow_group']);
        showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_user&op=commission");
        showtips(lang('plugin/keke_doc', '157'));
        showtableheader(lang('plugin/keke_doc', '82'));
        showsubtitle(array(lang('plugin/keke_doc', '158'), lang('plugin/keke_doc', '159')));
        $userGroupData = C::t('common_usergroup')->fetch_all($groupIds);
        foreach ($groupIds as $group) {
            $table = array();
            $table[0] = $userGroupData[$group]['grouptitle'];
            $table[1] = '<input name="commission['.$group.']" value="'.$commissionArr[$group].'" style="width:100px"> %';
            showtablerow('', array('width="300"', 'width=""'), $table);
        }
        showsubmit('forumset');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism_taobao_com*/
    }else{
        $postArr['commission']=serialize($_GET['commission']);
        kekeInsertSet($postArr);
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier='.$plugin["identifier"].'&pmod=admincp_user&op=commission', 'succeed');
    }
}else{
    if (submitcheck("forumset")) {
        if (is_array($_GET['dids'])) {
            switch ($_GET['optype']) {
                case 'normal':
                    $state = 1;
                    break;
                case 'refuse':
                    $state = 2;
                    break;
            }
            C::t('#keke_doc#keke_doc_user')->update($_GET['dids'], array('state' => $state));
        } else {
            cpmsg(lang('plugin/keke_doc', '160'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_live', 'error');
        }
        if (!$_GET['optype']) {
            cpmsg(lang('plugin/keke_doc', '55'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_doc', 'error');
        }
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_user', 'succeed');
    }
    if ($_GET['ac'] == 'edit') {
        $uid = intval($_GET['uid']);
        $Data = C::t('#keke_doc#keke_doc_user')->fetchfirst_byuid($uid);
        if (submitcheck("editsubmit")) {
            $arr = array(
                'name' => $_GET['name'],
                'rank' => $_GET['rank'],
                'profile' => $_GET['rank'],
                'state' => intval($_GET['state']),
            );
            C::t('#keke_doc#keke_doc_user')->update($uid, $arr);
            cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_user&page=' . intval($_GET['page']), 'succeed');
        }
        showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_user&ac=edit");
        showtableheader(lang('plugin/keke_doc', '161'));
        showsetting(lang('plugin/keke_doc', '162'), 'name', $Data['name'], 'text');
        showsetting(lang('plugin/keke_doc', '163'), 'rank', $Data['rank'], 'text');
        showsetting(lang('plugin/keke_doc', '164'), 'profile', $Data['profile'], 'textarea');
        showsetting(lang('plugin/keke_doc', '165'), '', '', '<select name="state"><option value="0">'.lang('plugin/keke_doc', '70').'</option><option value="1" ' . ($Data['state'] == 1 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '93').'</option><option value="2" ' . ($docData['state'] == 2 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '166').'</option></select>');
        echo '<input name="uid" type="hidden" value="' . $uid . '" /><input name="page" type="hidden" value="' . intval($_GET['page']) . '" />';
        showsubmit('editsubmit');
        showtablefooter(); /*dism _taobao _com*/
        showformfooter(); /*dism_taobao_com*/
        exit();
    }

    $_GET['keyword'] = dhtmlspecialchars($_GET['keyword']);
    showtableheader(lang('plugin/keke_doc', '167'));
    showformheader('plugins&operation=config&do=' . $pluginid . '&pmod=keke_doc&pmod=admincp_user', 'testhd');
    showtablerow('', array(),
        array(
            '
                <input name="uid" type="text" value="' . ($_GET['uid'] ? intval($_GET['uid']) : '') . '" size="10" placeholder="'.lang('plugin/keke_doc', '168').'" />
                <select name="state"><option value="0">'.lang('plugin/keke_doc', '79').'</option><option value="1" ' . ($_GET['state'] == 1 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '93').'</option><option value="2" ' . ($_GET['state'] == 2 ? 'selected' : '') . '>'.lang('plugin/keke_doc', '169').'</option></select>
                <input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_doc', '170').'"><input name="inajax" type="hidden" value="1" />'
        )
    );
    showformfooter(); /*dism_taobao_com*/
    showtablefooter(); /*dism _taobao _com*/
    $where = '1';
    $param = '';
    if ($_GET['uid']) {
        $where .= " AND uid=" . intval($_GET['uid']);
        $param .= '&uid=' . intval($_GET['uid']);
    }
    if ($_GET['state']) {
        $where .= " AND state=" . intval($_GET['state']);
        $param .= '&state=' . intval($_GET['state']);
    }
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_user");
    showtableheader(lang('plugin/keke_doc', '171'));
    showsubtitle(array(lang('plugin/keke_doc', '83'), lang('plugin/keke_doc', '172'), lang('plugin/keke_doc', '173'), lang('plugin/keke_doc', '174'), lang('plugin/keke_doc', '175'), lang('plugin/keke_doc', '176'), lang('plugin/keke_doc', '87'), lang('plugin/keke_doc', '19')));
    $ppp = 20;
    $tmpurl = ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_user' . $param;
    $page = max(1, intval($_GET['page']));
    $startlimit = ($page - 1) * $ppp;
    if ($countAll = C::t('#keke_doc#keke_doc_user')->count_all($where)) {
        $docArr = C::t('#keke_doc#keke_doc_user')->fetch_all_data($startlimit, $ppp, $where);
        foreach ($docArr as $key => $val) {
            $op = '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_doc&pmod=admincp_user&ac=edit&uid=' . $val['uid'] . '&page=' . intval($_GET['page']) . '" class="">'.lang('plugin/keke_doc', '19').'</a>';
            switch ($val['state']) {
                case 1:
                    $state = ['zc', lang('plugin/keke_doc', '93')];
                    break;
                case 2:
                    $state = ['off', lang('plugin/keke_doc', '169')];
                    break;
            }
            $table = array();
            $table[0] = '<input type="checkbox" class="checkbox" name="dids[]" value="' . $val['uid'] . '" />';
            $table[1] = '<a href="home.php?mod=space&uid=' . $val['uid'] . '" target="_blank" class="teachername">' . $val['username'] . '</a>';
            $table[2] = $val['name'];
            $table[3] = $val['rank'];
            $table[4] = $val['date'];
            $table[5] = $val['total'];
            $table[6] = '<span class="' . $state[0] . '">' . $state[1] . '</span>';
            $table[7] = $op;
            showtablerow('', array('', 'width=""'), $table);
        }
    }
    $multipage = multi($countAll, $ppp, $page, $_G['siteurl'] . $tmpurl);
    if ($multipage) echo '<tr class="hover"><td colspan="9">' . $multipage . '</td></tr>';
    echo '<style>.ds{color: #ff8e42;}.jj{color: #999;}.zc{color: #3fd411;}.off{color: #f46c6c;}.locking{ color:#c30}.sline{color:#e3e3e3;margin:0 5px;}</style>';
    showsubmit('forumset', 'submit', '<input type="checkbox" name="chkall" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'dids\')"><label for="chkallIuPN">'.lang('plugin/keke_doc', '83').'</label>&nbsp;&nbsp;&nbsp;&nbsp;<input type="radio" name="optype" id="normal" value="normal" class="radio" /><label for="normal" class="vmiddle">'.lang('plugin/keke_doc', '93').'</label>&nbsp;&nbsp;<input type="radio" name="optype" id="refuse" value="refuse" class="radio" /><label for="refuse" class="vmiddle">'.lang('plugin/keke_doc', '169').'</label>');
    showtablefooter(); /*dism _taobao _com*/
    showformfooter(); /*dism_taobao_com*/
}