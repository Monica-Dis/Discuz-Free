var formhash=jQuery('#formhash').val();
jQuery(".delkekefavorites").on("click", function() {
    var favoritesid=jQuery(this).data("favoritesid");
    layer.msg('取消收藏该文档？', {
        area: ['250px'],
        shade:0.3,
        icon: 3,
        time: 0
        ,btn: ['确定', '取消']
        ,yes: function(index){
            layer.load(2);
            jQuery.post('plugin.php?id=keke_doc:ajax', {"ac":"delfavorites","favoritesid":favoritesid,"formhash":formhash},function (datas){
                layer.closeAll('loading');
                if(datas.msg){
                    layer.msg(datas.msg);
                    return false;
                }else{
                    jQuery("#"+favoritesid).remove();
                    layer.msg('操作成功');
                }
            }, "json");
        }
    });
});

jQuery(".delkekefollow").on("click", function() {
    var followid=jQuery(this).data("followid");
    layer.msg('确认取消关注？', {
        area: ['250px'],
        shade:0.3,
        icon: 3,
        time: 0
        ,btn: ['确定', '取消']
        ,yes: function(index){
            layer.load(2);
            jQuery.post('plugin.php?id=keke_doc:ajax', {"ac":"delfollow","followid":followid,"formhash":formhash},function (datas){
                layer.closeAll('loading');
                if(datas.msg){
                    layer.msg(datas.msg);
                    return false;
                }else{
                    jQuery("#"+followid).remove();
                    layer.msg('操作成功');
                }
            }, "json");
        }
    });
});

$(".delorder").on("click", function() {
    var orderid=$(this).data('orderid');
    $.confirm("确认取消订单？",function() {
        layer.load(2);
        $.post('plugin.php?id=keke_doc:ajax', {"ac":"closorder","orderid":orderid,"formhash":"{FORMHASH}"},function (datas){
            layer.closeAll('loading');
            if(datas.msg){
                layer.msg(datas.msg);
                return false;
            }else{
                $('.btnbox_'+orderid).remove();
                $('.orderstate_'+orderid).html('<span>已关闭</span>');
                layer.msg('操作成功');
            }
        }, "json");

    }, function() {

    });

});


layui.use('element', function(){
    var element = layui.element;
});