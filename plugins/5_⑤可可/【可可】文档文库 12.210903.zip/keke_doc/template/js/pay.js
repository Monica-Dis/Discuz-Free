var did             = jQuery('#did').val(),
    getcrediturl    = jQuery('#getcrediturl').val(),
    siteurl         = jQuery('#siteurl').val(),
    formhash        = jQuery('#formhash').val();
window.onload=function(){
    jQuery("#charge-source-list li").on("click", function() {
        jQuery(this).addClass("active").siblings().removeClass("active");
        var source=jQuery(this).attr("source");
        jQuery('#zftype').val(source);
        jQuery('#ewm').html('').hide();
        jQuery("#Submit").html('提交订单');
    });
}
jQuery("#Submit").on("click", function() {
    var payType=jQuery('#zftype').val();
    if(!payType){
        return false;
    }
    layer.load(2);
    jQuery.get('plugin.php', jQuery("#alipayment").serialize(),function (data){
        if(data.err){
            layer.closeAll('loading');
            if(data.state===4){
                layer.confirm(data.err, {
                    btn: ['去充值', '取消']
                }, function(index, layero){
                    var w = window.open('about:blank');
                    w.location.replace(getcrediturl);
                });
            }else{
                layer.msg(data.err);
            }
        }else if(data.ewmurl){
            if(data.ewmurl!==1){
                jQuery('#ewm').show().html('<img src="'+data.ewmurl+'"><div class="wxpaytip">'+(payType==2?'请打开微信APP扫码支付':'请打开支付宝APP扫码支付')+'</div>');
                layer.closeAll('loading');
                jQuery("#Submit").html('完成支付');
            }
            var orderid=data.orderid;
            var ping =setInterval(function(){
                jQuery.get(siteurl+'plugin.php?id=keke_doc:ajax&ac=checkorder', {orderid:orderid,time:new Date().getTime(),formhash:formhash},function (datas){
                    if(datas.state==1){
                        clearInterval(ping);
                        layer.closeAll('loading');
                        showDialog('支付成功', 'right', '', 'window.location.href = \'plugin.php?id=keke_doc&ac=down&did='+did+'\'',true,'','','','','',2);
                        return false;
                    }else{return false;}
                }, "json");
            },2000);
        }else if(data.payjump){
            location.href=siteurl+'plugin.php?id=keke_doc:payapi&zftype=1&did='+did+'&time='+new Date().getTime()+'&formhash='+formhash+'&jump=1';
        }
    }, "json");
});