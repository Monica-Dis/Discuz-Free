<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
    global $_G;
	loadcache('plugin');
    require_once libfile('function', 'plugin/keke_doc');
    $CateData = kekeGetAllCate();
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
		    C::t('#keke_doc#keke_doc_order')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_doc&pmod=admincp_order', 'succeed');
	}
	if($_GET['ac']=='supplement' && ($_GET['formhash'] == FORMHASH)){
        upDateOrder($_GET['orderid'],lang('plugin/keke_doc', '103').' '.$_G['username'].' '.lang('plugin/keke_doc', '104'));
        cpmsg(lang('plugin/keke_doc', '11'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_doc&pmod=admincp_order', 'succeed');
    }
    showtableheader(lang('plugin/keke_doc', '105'));
    showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_doc&pmod=admincp_order', 'testhd');
    showtablerow('', array(),
        array(
            '   <input name="orderid" value="'.$_GET['orderid'].'" type="text" size="25" placeholder="'.lang('plugin/keke_doc', '106').'" />
                <input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15" placeholder="'.lang('plugin/keke_doc', '107').'"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'" placeholder="'.lang('plugin/keke_doc', '108').'"/>
                <input name="uid" type="text" value="'.($_GET['uid']?intval($_GET['uid']):'').'" size="10" placeholder="'.lang('plugin/keke_doc', '109').'" />
                <select name="state"><option value="0">'.lang('plugin/keke_doc', '79').'</option><option value="1" '.($_GET['state']==1?'selected':'').'>'.lang('plugin/keke_doc', '110').'</option><option value="2" '.($_GET['state']==2?'selected':'').'>'.lang('plugin/keke_doc', '111').'</option><option value="4" '.($_GET['state']==4?'selected':'').'>'.lang('plugin/keke_doc', '112').'</option></select>
                <input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_doc', '112').'"><input name="inajax" type="hidden" value="1" /><script src="static/js/calendar.js"></script>'
        )
    );
    showformfooter(); /*dism_taobao_com*/
    showtablefooter(); /*dism _taobao _com*/
	$where='1';$param='';

    if($_GET['orderid']){
        $where.=" AND id='".dhtmlspecialchars($_GET['orderid'])."'";
        $param.='&orderid='.dhtmlspecialchars($_GET['orderid']);
    }
    if($_GET['time']){
        $where.=" AND time>".strtotime($_GET['time']);
        $param.='&time='.dhtmlspecialchars($_GET['time']);
    }
    if($_GET['endtime']){
        $where.=" AND time<".strtotime($_GET['endtime']);
        $param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
    }
    if($_GET['uid']){
        $where.=" AND uid=".intval($_GET['uid']);
        $param.='&uid='.intval($_GET['uid']);
    }
    if($_GET['state']){
        $where.=" AND state=".($_GET['state']==2?0:intval($_GET['state']));
        $param.='&state='.intval($_GET['state']);
    }
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_order");
	showtableheader(lang('plugin/keke_doc', '113'));
    showsubtitle(array(lang('plugin/keke_doc', '83'), lang('plugin/keke_doc', '114'),lang('plugin/keke_doc', '115'),lang('plugin/keke_doc', '59'),lang('plugin/keke_doc', '116'),lang('plugin/keke_doc', '117'),lang('plugin/keke_doc', '118')));
	$ppp=20;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_doc&pmod=admincp_order'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($countAll=C::t('#keke_doc#keke_doc_order')->count_all($where)){
        $orderArr=C::t('#keke_doc#keke_doc_order')->fetch_all_data($startlimit,$ppp,$where);
		foreach($orderArr as $key=>$val){
			$op=$val['state']==0?'<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_doc&pmod=admincp_order&ac=supplement&orderid='.$val['id'].'&page='.intval($_GET['page']).'&formhash='.FORMHASH.'">'.lang('plugin/keke_doc', '104').'</a>':'-';
            $price='';
            if($val['doc']['price']>0 || $val['doc']['credit']){
                if($val['doc']['price']>0){
                    $price.='<span class="f12"> &yen;</span>'.$val['doc']['price'];
                }
                if($val['doc']['credit'] && $val['doc']['price']>0) {
                    $price.= '+';
                }
                if( $val['doc']['credit']){
                    $price.= $val['doc']['credit'].'<span class="f12"> '.$_G['setting']['extcredits'][$val['doc']['credit_type']]['title'].'</span>';
                }
            }
            switch($val['state']){
                case 1:
                    $state=['zc',lang('plugin/keke_doc', '110')];
                    break;
                case 4:
                    $state=['jj',lang('plugin/keke_doc', '119')];
                    break;
                default:
                    $state=['ds',lang('plugin/keke_doc', '111')];
                    break;
            }
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
            $table[1] = '<a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank" class="teachername">'.$val['username'].'</a><br/><span class="sline"> '.$val['id'].'</span>';
			$table[2] = '<a href="plugin.php?id=keke_doc&ac=view&did='.$val['doc']['id'].'" target="_blank">'.$val['doc']['title'].'</a>';
			$table[3] = $price;
			$table[4] = $val['date'];
			$table[5] = '<span class="'.$state[0].'">'.$state[1].'</span>'.($val['sn']?'<br/><span class="sline">'.$val['sn'].'</span>':'');
			$table[6] = $op;
			showtablerow('',array('','width=""'), $table);
		}
	}
	$multipage = multi($countAll, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	echo '<style>.ds{color: #ff8e42;}.jj{color: #999;}.zc{color: #3fd411;}.off{color: #f46c6c;}.locking{ color:#c30}.sline{color:#999;margin:5px 0; display: inline-block}</style>';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter(); /*dism _taobao _com*/
	showformfooter(); /*dism_taobao_com*/