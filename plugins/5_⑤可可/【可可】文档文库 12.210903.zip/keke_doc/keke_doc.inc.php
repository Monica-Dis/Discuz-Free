<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$keke_doc = $_G['cache']['plugin']['keke_doc'];
require_once libfile('function', 'plugin/keke_doc');
$CateData = kekeGetAllCate();
$allSetting = kekeGetSet();
$slider = kekeGetCache('slider');
$_GET['ac'] = in_array($_GET['ac'], ['list', 'view', 'account', 'index', 'pay', 'down','user']) ? $_GET['ac'] : 'index';
$page = max(1, intval($_GET['page']));
$did = intval($_GET['did']);
switch ($_GET['ac']) {
    case 'list':
    case 'user':
        $_GET['keyword'] = dhtmlspecialchars($_GET['keyword']);
        $getCate = explode('-', $_GET['cate']);
        $parameterArr = array(
            'did' => intval($getCate[0]),
            'sdid' => intval($getCate[1]),
            'tdid' => intval($getCate[2]),
        );
        if (!$parameterArr['did']) {
            $subCateArr = [];
            $subCount = 1;
            foreach ($CateData as $cate) {
                if ($cate['upid'] == 0) {
                    foreach ($cate['subcate'] as $subcateid => $subcate) {
                        $subCateArr[$subcateid] = $subcateid;
                        $subCount++;
                        if ($subCount > 10) break;
                    }
                }
            }
        }
        $ppp = 15;
        $tmpurl = 'plugin.php?id=keke_doc&ac=list&cate=' . $parameterArr['did'] . '-' . $parameterArr['sdid'] . '-' . $parameterArr['tdid'] . '&o=' . intval($_GET['o']) . '&keyword=' . dhtmlspecialchars($_GET['keyword']);
        $startlimit = ($page - 1) * $ppp;
        $where = 'state=3';
        $order = " ORDER BY displayorder DESC,id DESC";
        if ($parameterArr['did']) {
            $where .= " AND cate=" . $parameterArr['did'];
        }
        if ($parameterArr['sdid']) {
            $where .= " AND subcate=" . $parameterArr['sdid'];
        }
        if ($parameterArr['tdid']) {
            $where .= " AND thirdcate=" . $parameterArr['tdid'];
        }
        if ($_GET['keyword']) {
            $where .= " AND title LIKE '%" . daddslashes($_GET['keyword']) . "%'";
        }
        if($_GET['ac']=='user'){
            $userId=$_GET['uid']?intval($_GET['uid']):intval($_GET['did']);
            $where = 'state=3 AND uid='.$userId;
            $tmpurl = 'plugin.php?id=keke_doc&ac=user&uid='.$userId.'&o='.intval($_GET['o']);
            $authorInfo = getAuthorInfo($userId);
        }
        if ($_GET['o']) {
            switch ($_GET['o']) {
                case 1:
                    $order = " ORDER BY id DESC";
                    break;
                case 2:
                    $order = " ORDER BY view DESC";
                    break;
                case 3:
                    $order = " ORDER BY price DESC";
                    break;
                case 4:
                    $order = " ORDER BY price ASC";
                    break;
            }
        }
        $docList = getDocList($where,$tmpurl,$order);
        $docListData = $docList[0];
        $multipage = $docList[1];
        if($_GET['ac']=='user'){
            $variable=array(
                'user'=>getUsNames($_GET['uid'])[$_GET['uid']],
            );
            $navtitle = replaceVariable($allSetting['user_title'],$variable);
            $metakeywords = replaceVariable($allSetting['user_keywords'],$variable);
            $metadescription = replaceVariable($allSetting['user_description'],$variable);
        }else{
            $variable=array(
                'cate'=>$CateData[$parameterArr['did']]['name'],
                'subcate'=>$CateData[$parameterArr['sdid']]['name'],
                'threecate'=>$CateData[$parameterArr['tdid']]['name']
            );
            $navtitle = (!$parameterArr['did'] && !$parameterArr['sdid'] && !$parameterArr['tdid']) ? $allSetting['list_index_title'] : replaceVariable($allSetting['list_title'],$variable);
            $metakeywords = replaceVariable($allSetting['list_keywords'],$variable);
            $metadescription = replaceVariable($allSetting['list_description'],$variable);
        }
        break;
    case 'view':
        $doc = getDocData($did);
        if(!$doc){
            header('HTTP/1.1 404 Not Found');
            include template('keke_doc:block');
            exit($notFound);
        }
        if($doc['state']!=3 && $_G['uid']!=$doc['uid'] && $_G['groupid']!=1){
            showmessage(lang('plugin/keke_doc', '192'));
        }
        $doc['docsize']=formatBytes($doc['size']);
        $authorInfo = getAuthorInfo($doc['uid']);
        $hotDoc = C::t('#keke_doc#keke_doc')->fetch_all_doc(0, 12, 1, 'order by view desc');
        $checkMyDoc = checkMyDoc($did);
        $variable=array(
            'title'=>$doc['title'],
            'cate'=>$CateData[$doc['cate']]['name'],
            'subcate'=>$CateData[$doc['subcate']]['name'],
            'threecate'=>$CateData[$doc['thirdcate']]['name'],
            'thumb'=>GetViewImg($doc['docsrc'],(in_array($doc['ext'],getXlsType())?'1-1':'1')),
        );
        $navtitle = replaceVariable($allSetting['doc_title'],$variable);
        $metakeywords = replaceVariable($allSetting['doc_keywords'],$variable);
        $metadescription = replaceVariable($allSetting['doc_description'],$variable);
        break;
    case 'pay':
        $orderData=[];
        kekeToLogin();
        $keke_pay = $_G['cache']['plugin']['keke_pay'];
        if($_GET['orderid']){
            $_GET['orderid']=dhtmlspecialchars($_GET['orderid']);
            $orderData=C::t('#keke_doc#keke_doc_order')->fetchfirst_byid($_GET['orderid']);
            $did=$orderData['did'];
        }
        $doc = getDocData($did);
        if($_GET['orderid']){
            $doc['price']=$orderData['price'];
            $doc['credit']=$orderData['credit'];
        }else{
            if($doc['vip_price'] && in_array($_G['groupid'],unserialize($keke_doc['vip']))){
                $doc['price']=$doc['vip_price'];
            }
        }
        break;
    case 'account':
        kekeToLogin();
        $opArr = ['mydoc', 'order', 'favorites', 'follow','history'];
        $_GET['op'] = in_array($_GET['op'], $opArr) ? $_GET['op'] : (checkmobile()?'index':'mydoc');
        $ppp = 15;
        $startlimit = ($page - 1) * $ppp;
        $where = 'uid=' . $_G['uid'];
        if(($_GET['op']!='index' && checkmobile()) || !checkmobile()){
            $countAll = C::t('#keke_doc#keke_doc_' . $_GET['op'])->count_all($where);
            $dataArr = C::t('#keke_doc#keke_doc_' . $_GET['op'])->fetch_all_data($startlimit, $ppp, $where);
            $multipage = filterMultiPage(multi($countAll, $ppp, $page, $_G['siteurl'] . 'plugin.php?id=keke_doc&ac=account&op=' . $_GET['op']), 0);
        }
        if($_GET['op']=='index' && checkmobile()){
            $userData=[
                'down'=>C::t('#keke_doc#keke_doc_mydoc')->count_all('uid='.$_G['uid']),
                'favorites'=>C::t('#keke_doc#keke_doc_favorites')->count_all('uid='.$_G['uid']),
                'follow'=>C::t('#keke_doc#keke_doc_follow')->count_all('uid='.$_G['uid'])
            ];
        }
        break;
    case 'down':
        kekeToLogin();
        $doc = getDocData($did);
        if($doc['price']==0 && !$doc['credit']){
            C::t('#keke_doc#keke_doc_mydoc')->insert(array(
                'uid'=>$_G['uid'],
                'did'=>$did,
            ));
        }
        $checkMyDoc = checkMyDoc($did);
        if ($checkMyDoc || $_G['groupid']==1) {
            $url = getDocDownUrl($did);
            C::t('#keke_doc#keke_doc')->increase($did, array('down' => 1));
        }else{
            $url = 'plugin.php?id=keke_doc&ac=pay&did='.$did;
        }
        dheader('location: ' . $url);
        break;
    default:
        $indexData = array(
            'allcatedata' => kekeGetAllCate(),
            'indexDocList' => getIndexDocList(),
            'newDoc' => getNewDoc(),
            'docCount' => C::t('#keke_doc#keke_doc')->count_all() + $keke_doc['alldocnum'],
            'ranking' => getRanking(),
            'hotKeywoed' => explode(',',$keke_doc['hotsearch']),
            'checkShare'=>in_array($_G['groupid'],unserialize($keke_doc['allow_group'])),
            'recommend'=>getRecommend()
        );



        $navtitle = $allSetting['index_title'];
        $metakeywords = $allSetting['index_keywords'];
        $metadescription = $allSetting['index_description'];
}
if (checkmobile()) {
    if((K_INCMAG || K_INQIANFAN) && $keke_doc['hideheader']){
        $_GET['app']=1;
    }
    include template('keke_doc:doc_' . $_GET['ac']);
} else {
    include template('diy:doc_' . $_GET['ac'], NULL, './source/plugin/keke_doc/template');
}