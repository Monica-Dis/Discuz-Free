<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_keke_reply_forum {
	function forumdisplay_thread_subject_output(){
        global $_G, $threadlist;
        $keke_reply = $_G['cache']['plugin']['keke_reply'];
        $section = empty($keke_reply['bk']) ? array() : unserialize($keke_reply['bk']);
        if(!is_array($section)) $section = array();
        if(!(empty($section[0]) || in_array($_G['fid'],$section))){
            return array();
        }
        foreach ($threadlist as $v) {if (is_numeric($v['tid'])) $tidlist .= $v['tid'].',';}
        if ($tidlist) $tidlist = substr($tidlist, 0, -1);
        $mod=explode("|", $keke_reply['gf']);
        foreach ($mod as $va) {if (is_numeric($va)) $uslist .= $va.',';}
        if ($uslist) $uslist = substr($uslist, 0, -1);
        if(!$tidlist){
            return array();
        }
        $query = DB::query("SELECT tid,dateline,author FROM ".DB::table('forum_post')." WHERE tid IN ($tidlist) AND authorid IN ($uslist) AND first=0 ORDER BY dateline ASC");
        while ($row = DB::fetch($query)){$data[$row['tid']] = $row;}
        $days=$keke_reply['sx'] ? $keke_reply['sx'] : 7;
        $return = array();
        $na=0;
        foreach($threadlist as $k => $v){
            if($data[$v['tid']] && ($_G['timestamp']-(3600 * 24 * $days))<$data[$v['tid']]['dateline'] && $v['displayorder']==0){
                $style='';
                if($na==0)$style='<style>.kekereply{background:url(source/plugin/keke_reply/template/img/Re_O.png) no-repeat #fefae0;margin-left:5px;padding:1px 0px 1px 18px;line-height:17px;height:17px; color:#C30}</style>';
                $reply='';
                $reply=str_replace('[name]',' '.$data[$v['tid']]['author'].' ',$keke_reply['wz']);
                $return[]=$style.'<span class="kekereply">'.$reply.'</span>';
            }else{
                $return[]='';
            }
        }
        return $return;
	}	
	
	function viewthread_postbottom_output(){
		global $_G;
		$keke_reply = $_G['cache']['plugin']['keke_reply'];	
		if(!$keke_reply['sy']){return array();}
		$section = empty($keke_reply['bk']) ? array() : unserialize($keke_reply['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){return array();}
		$mod=explode("|", $keke_reply['gf']);
		foreach ($mod as $va) {if (is_numeric($va)) $uslist .= $va.',';}
		if ($uslist) {
		    $uslist = substr($uslist, 0, -1);
        }
		$co=$keke_reply['co'] ? $keke_reply['co'] : 300;
		$n=0;
		$query = DB::query("SELECT message,authorid,dateline,pid FROM ".DB::table('forum_post')." WHERE tid=".$_G['tid']." AND authorid IN ($uslist) AND first=0 AND invisible=0 ORDER BY dateline ASC limit ".$keke_reply['syts']);
		while ($data = DB::fetch($query)){
			if($data){$on=1;}else{$on=0;}
			if($n==0){$times=date('Y-m-d H:i:s',$data['dateline']);}
			$list.='<li>
        <div class="name"><img alt="admin" src="uc_server/avatar.php?uid='.$data['authorid'].'&amp;size=small" title="'.getus($data['authorid']).'">  <a href="home.php?mod=space&amp;uid='.$data['authorid'].'" title="'.getus($data['authorid']).'" target="_blank">'.getus($data['authorid']).'</a> <span class=times>'.date('Y-m-d H:i:s',$data['dateline']).'</span><div class="clearb"></div></div>
        <a href="forum.php?mod=redirect&goto=findpost&ptid='.$_G['tid'].'&pid='.$data['pid'].'&fromuid='.$_G['fid'].'" class="messagecutstrtext" style="color:{$keke_reply[wzcl]}">'.messagecutstr($data['message'],$co).'</a></li>';
		$n++;}
		if(!$on){
		    return array();
		}
		include template('keke_reply:index');
		if($_G['forum_firstpid']) return array($return,'');
        return array();
	}

}

class mobileplugin_keke_reply_forum{
	function viewthread_postbottom_mobile(){
		global $_G;
		$keke_reply = $_G['cache']['plugin']['keke_reply'];	
		if(!$keke_reply['sy']){return array();}
		$section = empty($keke_reply['bk']) ? array() : unserialize($keke_reply['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){return array();}
		$mod=explode("|", $keke_reply['gf']);
		foreach ($mod as $va) {if (is_numeric($va)) $uslist .= $va.',';}
		if ($uslist) $uslist = substr($uslist, 0, -1);
		$co=100;
		$query = DB::query("SELECT message,authorid,dateline,pid FROM ".DB::table('forum_post')." WHERE tid=".$_G['tid']." AND authorid IN ($uslist) AND first=0 ORDER BY dateline ASC limit ".$keke_reply['syts']);
		$n=0;
        if(!function_exists('messagecutstr')){
            require_once libfile('function/post');
        }
		while ($data = DB::fetch($query)){
			if($data){$on=1;}else{$on=0;}
			$list.='<li>
        <div class="name"><span class=times>'.date('Y-m-d H:i:s',$data['dateline']).'</span><img alt="admin" src="uc_server/avatar.php?uid='.$data['authorid'].'&amp;size=small" title="'.getus($data['authorid']).'">  <a href="home.php?mod=space&amp;uid='.$data['authorid'].'" title="'.getus($data['authorid']).'" target="_blank">'.getus($data['authorid']).'</a> </div>
        <a href="forum.php?mod=redirect&goto=findpost&ptid='.$_G['tid'].'&pid='.$data['pid'].'&fromuid='.$_G['fid'].'">'.messagecutstr($data['message'],$co).'</a></li>';
		$n++;}
		$return='<style>
.keke_reply .hd{ height:38px; margin-bottom:5px; font-size:14px; line-height:38px; background: url(source/plugin/keke_reply/template/img/ico.png) no-repeat 12px '.$keke_reply[cl].'; padding-left:50px; color:#01316b;}
.keke_reply .hd span{ float:right; color:#999; font-size:12px; font-weight:500;margin-right:15px;}
.keke_reply ul li .name{ width:100%; margin-bottom:8px;line-height:16px; float:left; margin-right:10px;  padding-right:8px;margin-top:5px;border-radius:20px}
.keke_reply ul li .name a{ line-height:16px; color:#c30; float:left}
.keke_reply ul li .name img{ width:16px; height:16px; float:left; margin-right:5px; border-radius:20px}
.keke_reply ul{ padding:10px;}
.keke_reply ul li{ border-bottom:1px dashed #eee; line-height:23px; margin-bottom:8px; font-size:13px; padding-bottom:8px;} 
.keke_reply ul li .times{ margin-left:10px; color:#999; font-size:12px; float: right}
</style>
<div class="keke_reply">
	<div class="hd">'.$keke_reply['title'].'</div>
    <ul>
    	'.$list.'
    </ul>
</div>';
		if(!$on){return array();}
		$returna=array($return);
		return $returna;
		}
	
	function forumdisplay_thread_mobile_output(){
		global $_G;
		$keke_reply = $_G['cache']['plugin']['keke_reply'];	
		$section = empty($keke_reply['bk']) ? array() : unserialize($keke_reply['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){return array();}
		foreach ($_G['forum_threadlist'] as $v) {if (is_numeric($v['tid'])) $tidlist .= $v['tid'].',';}
		if ($tidlist) $tidlist = substr($tidlist, 0, -1);
		$mod=explode("|", $keke_reply['gf']);
		foreach ($mod as $va) {if (is_numeric($va)) $uslist .= $va.',';}
		if ($uslist) $uslist = substr($uslist, 0, -1);
        if(!$tidlist){
            return array();
        }
		$query = DB::query("SELECT tid,dateline FROM ".DB::table('forum_post')." WHERE tid IN ($tidlist) AND authorid IN ($uslist) AND first=0 ORDER BY dateline ASC");
		while ($row = DB::fetch($query)){$data[$row['tid']] = $row;}
		$days=$keke_reply['sx'] ? $keke_reply['sx'] : 7;
		$return = array();
		$na=0;
		foreach($_G['forum_threadlist'] as $v){
			if($data[$v['tid']] && ($_G['timestamp']-(3600 * 24 * $days))<$data[$v['tid']]['dateline']){
				if($na==1)$style='<style>.kekereply{background:url(source/plugin/keke_reply/template/img/Re_O.png) no-repeat #fefae0;margin-left:5px;padding:1px 0px 1px 18px;line-height:17px;height:17px; font-size:12px;color:#C30;}</style>';else $style='';
				$return[]=$style.'<span class="kekereply">'.$keke_reply['wz'].'</span>';}
				else{$return[]='';}
			$na++;
		}
		return $return;
		}
}

function getus($uida){
	return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uida);
}
function substr_cut($str_cut,$length){
    if (strlen($str_cut) > $length){
        for($i=0; $i < $length; $i++)
        if (ord($str_cut[$i]) > 128)	$i++;
        $str_cut = substr($str_cut,0,$i)."...";
    }
    return $str_cut;
}