<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT . 'source/plugin/keke_buyforum/identity.inc.php';
require_once libfile('function/cache');

function _h5pay($money, $out_trade_no, $title)
{
    global $_G;
    $keke_buyforum = $_G['cache']['plugin']['keke_buyforum'];
    $userip = get_client_ip();
    $appid = trim($keke_buyforum['wxappid']);
    $mch_id = trim($keke_buyforum['wxmchid']);
    $key = trim($keke_buyforum['wxshkey']);
    $nonce_str = createNoncestr();
    $body = $title;
    $total_fee = $money;
    $spbill_create_ip = $userip;
    $notify_url = $_G['siteurl'] . 'source/plugin/keke_buyforum/paylib/notify_wx.inc.php';
    $trade_type = 'MWEB';
    $scene_info = '{"h5_info":{"type":"Wap","wap_url":"' . $_G['siteurl'] . 'plugin.php?id=keke_buyforum","wap_name":"$title"}}';
    $signA = 'appid=' . $appid . '&attach=' . $out_trade_no . '&body=' . $body . '&mch_id=' . $mch_id . '&nonce_str=' . $nonce_str . '&notify_url=' . $notify_url . '&out_trade_no=' . $out_trade_no . '&scene_info=' . $scene_info . '&spbill_create_ip=' . $spbill_create_ip . '&total_fee=' . $total_fee . '&trade_type=' . $trade_type;
    $strSignTmp = $signA . ('&key=' . $key);
    $sign = strtoupper(MD5($strSignTmp));
    $post_data = "<xml>\r\n\t\t\t\t\t   <appid>" . $appid . "</appid>\r\n\t\t\t\t\t   <mch_id>" . $mch_id . "</mch_id>\r\n\t\t\t\t\t   <body>" . $body . "</body>\r\n\t\t\t\t\t   <out_trade_no>" . $out_trade_no . "</out_trade_no>\r\n\t\t\t\t\t   <total_fee>" . $total_fee . "</total_fee>\r\n\t\t\t\t\t   <spbill_create_ip>" . $spbill_create_ip . "</spbill_create_ip>\r\n\t\t\t\t\t   <notify_url>" . $notify_url . "</notify_url>\r\n\t\t\t\t\t   <trade_type>" . $trade_type . "</trade_type>\r\n\t\t\t\t\t   <scene_info>" . $scene_info . "</scene_info>\r\n\t\t\t\t\t   <attach>" . $out_trade_no . "</attach>\r\n\t\t\t\t\t   <nonce_str>" . $nonce_str . "</nonce_str>\r\n\t\t\t\t\t   <sign>" . $sign . "</sign>\r\n\t\t\t\t   </xml>";
    $url = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
    $dataxml = postXmlCurl($post_data, $url);
    $objectxml = (array) simplexml_load_string($dataxml, 'SimpleXMLElement', LIBXML_NOCDATA);
    $objectxml['mweb_url'] = $objectxml['mweb_url'] . _redurl($out_trade_no);
    return $objectxml;
}
function _redurl($orderid)
{
    global $_G;
    $redirect_url = urlencode($_G['siteurl'] . 'plugin.php?id=keke_buyforum&p=loading&orderid=' . $orderid);
    $redirect_urls = '&redirect_url=' . $redirect_url;
    return $redirect_urls;
}
function createNoncestr($length = 32)
{
    $chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    $str = '';
    $i = 0;
    while (true) {
        if ($i >= $length) {
            return $str;
        }
        $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        ($i += 1) + -1;
    }
}
function postXmlCurl($xml, $url, $second = 30)
{
    if (!(function_exists('curl_init') && function_exists('curl_exec'))) {
        return null;
    }
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_TIMEOUT, $second);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_HEADER, false);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $xml);
    $data = curl_exec($ch);
    if ($data) {
        curl_close($ch);
        return $data;
    }
    $error = curl_errno($ch);
    curl_close($ch);
    return 'curl_err:' . $error . '<br>';
}
function get_client_ip($type = 0)
{
    if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
        $ip = getenv('HTTP_CLIENT_IP');
    } elseif (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
        $ip = getenv('HTTP_X_FORWARDED_FOR');
    } elseif (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
        $ip = getenv('REMOTE_ADDR');
    } elseif (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return preg_match('/[\\d\\.]{7,15}/', $ip, $matches) ? $matches[0] : '';
}
function arrtoxml($data)
{
    $xml = '<xml>';
    foreach ($data as $key => $val) {
        if (is_numeric($val)) {
            $xml .= '<' . $key . '>' . $val . '</' . $key . '>';
        } else {
            $xml .= '<' . $key . '><![CDATA[' . $val . ']]></' . $key . '>';
        }
    }
    $xml .= '</xml>';
    return $xml;
}
function _sevrset($data)
{
    require_once libfile('function/cache');
    savecache('keke_buyforum_set', $data);
    if (C::t('#keke_buyforum#keke_buyforum_set')->result_set(1)) {
        C::t('#keke_buyforum#keke_buyforum_set')->update(1, array('val' => $data));
    } else {
        C::t('#keke_buyforum#keke_buyforum_set')->insert(array('id' => 1, 'val' => $data), false, true);
    }
    return null;
}
function _getset()
{
    global $_G;
    loadcache('keke_buyforum_set');
    $info = $_G['cache']['keke_buyforum_set'] ? $_G['cache']['keke_buyforum_set'] : C::t('#keke_buyforum#keke_buyforum_set')->result_set(1);
    $info = unserialize($info);
    return $info;
}
function _setforumorder($forumsetarr)
{
    foreach ($forumsetarr as $key => $val) {
        $dos[] = $val['order'];
    }
    array_multisort($dos, SORT_ASC, $forumsetarr);
    return $forumsetarr;
}
function _getforuminfo($type = '')
{
    global $_G;
    $keke_buyforum = $_G['cache']['plugin']['keke_buyforum'];
    $section = unserialize($keke_buyforum['forum']);
    $foruminfo = C::t('forum_forum')->fetch_all_info_by_fids($section);
    $forumset = _getset();
    foreach ($foruminfo as $key => $val) {
        $longarr = array();
        $longstr = $forumset[$val['fid']]['long'] ? $forumset[$val['fid']]['long'] : $keke_buyforum['day'];
        $longarr = explode(',', $longstr);
        $foruminfo[$val['fid']]['mintime'] = min($longarr);
        $foruminfo[$val['fid']]['order'] = $forumset[$val['fid']]['order'];
        $foruminfo[$val['fid']]['long'] = $forumset[$val['fid']]['long'];
        $foruminfo[$val['fid']]['prices'] = number_format($forumset[$val['fid']]['price'], 2);
        $foruminfo[$val['fid']]['icons'] = $val['icon'] ? $_G['setting']['attachurl'] . 'common/' . $val['icon'] : '';
    }
    $forumarr = $foruminfo;
    if (!$type) {
        $forumarr = _setforumorder($foruminfo);
    }
    return $forumarr;
}
function _getmyforum()
{
    global $_G;
    $mymyforum = C::t('#keke_buyforum#keke_buyforum')->fetch_by_uid($_G['uid']);
    $foruminfo = _getforuminfo(1);
    foreach ($mymyforum as $k => $v) {
        $mymyforum[$k]['icon'] = $foruminfo[$v['fid']]['icon'] ? $_G['setting']['attachurl'] . 'common/' . $foruminfo[$v['fid']]['icon'] : '';
        $mymyforum[$k]['name'] = $foruminfo[$v['fid']]['name'];
        $mymyforum[$k]['time'] = dgmdate($v['endtime'], 'Y-m-d H:i');
    }
    return $mymyforum;
}
function _getmyorder()
{
    global $_G;
    $ppp = 30;
    $tmpurl = 'plugin.php?id=keke_buyforum&p=order';
    $page = max(1, intval($_GET['page']));
    $startlimit = ($page - 1) * $ppp;
    $foruminfo = _getforuminfo(1);
    $myordercount = C::t('#keke_buyforum#keke_buyforum_orderlog')->count_by_all($_G['uid'], 1);
    $myorderdata = C::t('#keke_buyforum#keke_buyforum_orderlog')->fetch_all_by_all($_G['uid'], 1, $startlimit, $ppp);
    foreach ($myorderdata as $key => $val) {
        $myorderdata[$key]['name'] = $foruminfo[$val['buyfid']]['name'];
        $myorderdata[$key]['time'] = dgmdate($val['time'], 'Y/m/d H:i');
        $myorderdata[$key]['endtime'] = dgmdate($val['endtime'], 'Y/m/d H:i');
    }
    $multipage = multi($myordercount, $ppp, $page, $_G['siteurl'] . $tmpurl);
    $return[0] = $myorderdata;
    $return[1] = $multipage;
    return $return;
}
function _orderid()
{
    global $_G;
    $nowdate = dgmdate($_G['timestamp'], 'YmdHis');
    $random = random(10);
    $orderid = $nowdate . $random;
    return $orderid;
}
function _createjson($jsApiParameters, $orderid)
{
    $arrs = json_decode($jsApiParameters);
    $ret = array('jsapi' => $arrs, 'orderids' => $orderid);
    return json_encode($ret);
}
function _getcounts()
{
    return C::t('#keke_buyforum#keke_buyforum_orderlog')->count_by_all();
}
function _getorderbypage($startlimit, $ppp)
{
    return C::t('#keke_buyforum#keke_buyforum_orderlog')->fetch_all_by_all(0, 0, $startlimit, $ppp);
}
function _uporderdata($zftype, $trade_no, $orderdata)
{
    global $_G;
    $uidbuyforum = C::t('#keke_buyforum#keke_buyforum')->fetch_by_fidanduid($orderdata['buyfid'], $orderdata['uid']);
    if ($uidbuyforum) {
        $endtime = $uidbuyforum['endtime'] > TIMESTAMP ? $uidbuyforum['endtime'] + $orderdata['buytime'] * 86400 : TIMESTAMP + $orderdata['buytime'] * 86400;
        C::t('#keke_buyforum#keke_buyforum')->update($uidbuyforum['id'], array('endtime' => $endtime));
    } else {
        $endtime = TIMESTAMP + $orderdata['buytime'] * 86400;
        C::t('#keke_buyforum#keke_buyforum')->insert(array('uid' => $orderdata['uid'], 'fid' => $orderdata['buyfid'], 'endtime' => $endtime), false, true);
    }
    $orderarr = array('state' => '2', 'zftime' => $_G['timestamp'], 'zftype' => $zftype, 'sn' => $trade_no, 'endtime' => $endtime);
    C::t('#keke_buyforum#keke_buyforum_orderlog')->update($orderdata['orderid'], $orderarr);
    return null;
}
function editor_safe_replace($content)
{
    $tags = array('\'<iframe[^>]*?>.*?</iframe>\'is', '\'<frame[^>]*?>.*?</frame>\'is', '\'<script[^>]*?>.*?</script>\'is', '\'<head[^>]*?>.*?</head>\'is', '\'<title[^>]*?>.*?</title>\'is', '\'<meta[^>]*?>\'is', '\'<link[^>]*?>\'is');
    return preg_replace($tags, '', $content);
}
function _getqrcodeurl($urls)
{
    global $_G;
    $keke_buyforum = $_G['cache']['plugin']['keke_buyforum'];
    $src = $keke_buyforum['qr'] == 2 ? 'source/plugin/keke_buyforum/paylib/wechat/example/qrcode.php?data=' . urlencode($urls) : $urls;
    return $src;
}
function futf2gbk($data)
{
    $data = dhtmlspecialchars($data);
    $data1 = diconv($data, 'utf-8', 'gbk');
    $data0 = diconv($data1, 'gbk', 'utf-8');
    if ($data0 == $data) {
        $tmpstr = $data1;
    } else {
        $tmpstr = $data;
    }
    if (CHARSET == 'gbk') {
        return $tmpstr;
    }
    return fgbk2utf($data);
}
function fgbk2utf($data)
{
    $data1 = diconv($data, 'utf-8', 'gbk');
    $data0 = diconv($data1, 'gbk', 'utf-8');
    if ($data0 == $data) {
        $tmpstr = $data1;
    } else {
        $tmpstr = $data;
    }
    return diconv($tmpstr, 'gbk', 'utf-8');
}
function _uploadpics($filses)
{
    global $_G;
    require_once libfile('function/forum');
    $data = array('extid' => 1);
    $pic['url'] = $_G['setting']['attachurl'] . 'common/' . upload_icon_banner($data, $filses);
    $pic['error'] = 0;
    return $pic;
}
function _getfidnames($fid)
{
    return DB::result_first('select name from ' . DB::table('forum_forum') . ' where fid=' . $fid);
}
function insertdesc()
{
    $arr = array('fid' => intval($_GET['forumid']), 'desc' => editor_safe_replace($_GET['bkdesc']));
    C::t('#keke_buyforum#keke_buyforum_desc')->insert($arr, false, true);
    return null;
}