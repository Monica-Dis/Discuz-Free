<?php

define('APPTYPEID', 139);
define('CURSCRIPT', 'bfupload');
require_once '../../class/class_core.php';
$discuz = C::app();
$discuz->init();
require_once DISCUZ_ROOT.'./source/plugin/keke_buyforum/fun.php';
$pic=_uploadpics($_FILES['imgFile']);
header('Content-type: text/html');
exit(json_encode($pic));