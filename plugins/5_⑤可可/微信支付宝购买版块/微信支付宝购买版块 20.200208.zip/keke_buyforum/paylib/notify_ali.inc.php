<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

global $_G;
loadcache('plugin');
require_once("alipay/alipay.config.php");
require_once("alipay/alipay_notify.class.php");
$keke_buyforum = $_G['cache']['plugin']['keke_buyforum'];

include_once DISCUZ_ROOT."source/plugin/keke_buyforum/fun.php";
//计算得出通知验证结果
$alipayNotify = new AlipayNotify($alipay_config);
$verify_result = $alipayNotify->verifyNotify();

if($verify_result) {
	$out_trade_no = $_POST['out_trade_no'];
	$trade_no = $_POST['trade_no'];
	$trade_status = $_POST['trade_status'];
    if($_POST['trade_status'] == 'TRADE_FINISHED' || $_POST['trade_status'] == 'TRADE_SUCCESS') {
		$orderdata= C::t('#keke_buyforum#keke_buyforum_orderlog')->fetch($out_trade_no);
		if($orderdata['state']==1){
			_uporderdata(1,$trade_no,$orderdata);
		}
    }
	echo "success";		
}
else {
    //验证失败
    echo "fail";
}
//From: Dism_taobao-com
?>