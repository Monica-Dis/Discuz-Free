<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_keke_buyforum`;
CREATE TABLE `pre_keke_buyforum` (
  `id` int(24) NOT NULL AUTO_INCREMENT,
  `uid` int(10) unsigned NOT NULL,
  `fid` int(10) NOT NULL,
  `endtime` int(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_keke_buyforum_desc`;
CREATE TABLE `pre_keke_buyforum_desc` (
  `fid` int(10) NOT NULL,
  `desc` mediumtext NOT NULL,
  `title` varchar(255) NOT NULL,
  `keywords` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`fid`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_keke_buyforum_orderlog`;
CREATE TABLE `pre_keke_buyforum_orderlog` (
  `orderid` char(24) NOT NULL,
  `state` int(10) NOT NULL,
  `uid` int(10) unsigned NOT NULL,
  `buyfid` int(10) NOT NULL,
  `buytime` int(32) NOT NULL,
  `price` float(50,2) unsigned NOT NULL,
  `time` int(20) unsigned NOT NULL,
  `zftime` int(20) NOT NULL,
  `tel` varchar(50) NOT NULL,
  `ip` varchar(50) NOT NULL,
  `sn` char(50) NOT NULL,
  `code` char(50) NOT NULL,
  `zftype` int(10) NOT NULL,
  `endtime` int(20) NOT NULL,
  PRIMARY KEY (`orderid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM;

DROP TABLE IF EXISTS `pre_keke_buyforum_set`;
CREATE TABLE `pre_keke_buyforum_set` (
  `id` int(10) NOT NULL,
  `val` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_buyforum/discuz_plugin_keke_buyforum.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_buyforum/discuz_plugin_keke_buyforum_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_buyforum/discuz_plugin_keke_buyforum_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_buyforum/discuz_plugin_keke_buyforum_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_buyforum/discuz_plugin_keke_buyforum_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_buyforum/upgrade.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_buyforum/install.php');
?>