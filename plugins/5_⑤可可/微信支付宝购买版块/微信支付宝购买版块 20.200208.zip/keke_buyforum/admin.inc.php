<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	$keke_buyforum = $_G['cache']['plugin']['keke_buyforum'];
	include_once DISCUZ_ROOT."source/plugin/keke_buyforum/fun.php";
	if (submitcheck("forumset")) {
		DB::query("delete FROM ".DB::table('keke_buyforum_orderlog')." where state=1");
		cpmsg(lang('plugin/keke_buyforum', 'f01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_buyforum&pmod=admin', 'succeed');
	}
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");
    showtableheader(lang('plugin/keke_buyforum', 'f02'));
	showsubmit('forumset', lang('plugin/keke_buyforum', 'f03'), '', '');
	showtableheader(lang('plugin/keke_buyforum', 'f05'));
    showsubtitle(array(lang('plugin/keke_buyforum', 'f06'),'UID',lang('plugin/keke_buyforum', 'f18'),lang('plugin/keke_buyforum', 'f39'),lang('plugin/keke_buyforum', 'f07'), lang('plugin/keke_buyforum', 'f08'),lang('plugin/keke_buyforum', 'f09'),lang('plugin/keke_buyforum', 'f10'),lang('plugin/keke_buyforum', 'f11'),lang('plugin/keke_buyforum', 'f12')));
	$section = unserialize($keke_buyforum['forum']);
	$foruminfo = C::t('forum_forum')->fetch_all_name_by_fid($section);
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_buyforum&pmod=admin';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$allcount = _getcounts();
	if($allcount){
		$query = _getorderbypage($startlimit,$ppp);
		foreach($query as $val){
			$money=$val['money']/100;
			$time=dgmdate($val['zftime'], 'Y/m/d H:i');
			$cradit=intval($money*$keke_chongzhi['bl']);
			$stat=$val['state']==2 ? '<font color="#33CC33">'.lang('plugin/keke_buyforum', 'f13').'</font>' : '<font color="#FF3333">'.lang('plugin/keke_buyforum', 'f14').'</font>' ;
			$type=$val['zftype']==1 ? lang('plugin/keke_buyforum', 'f15') : lang('plugin/keke_buyforum', 'f16');
			$table = array();
			$table[0] = $val['orderid'];
			$table[1] = $val['uid'];
			$table[2] = '<a href="forum.php?mod=forumdisplay&fid='.$val['buyfid'].'" target="_blank">'.$foruminfo[$val['buyfid']]['name'].'</a>';
			$table[3] = $val['buytime'];
			$table[4] = $type;
			$table[5] = $val['price'].' '.lang('plugin/keke_buyforum', 'f38');
			$table[6] = $stat;
			$table[7] = $val['sn'] ? $val['sn'] : '<font color="#CCCCCC">--</font>';
			$table[8] = dgmdate($val['time'], 'Y/m/d H:i');
			$table[9] = $val['zftime'] ? dgmdate($val['zftime'], 'Y/m/d H:i') : '<font color="#CCCCCC">--</font>';
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
    showtablefooter();
    showformfooter();
