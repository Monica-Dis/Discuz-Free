<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
$keke_buyforum = $_G['cache']['plugin']['keke_buyforum'];
header("Content-type:text/html;charset=utf-8");
include_once DISCUZ_ROOT."source/plugin/keke_buyforum/fun.php";

$buyfid=intval($_GET['buyfid']);
$buytime=intval($_GET['buytime']);
$zftype=intval($_GET['zftype']);

$setdata=_getset();
$longstr=$setdata[$buyfid]['long']?$setdata[$buyfid]['long']:$keke_buyforum['day'];
$dayarr=explode(',',$longstr);
$mintime=min($dayarr);

$title= fgbk2utf(lang('plugin/keke_buyforum', 'f28'));

if(empty($buyfid)) {
	$msg=lang('plugin/keke_buyforum', 'f29');
	$msgs=fgbk2utf($msg);
	if($zftype==1){
		echo '<script>alert("'.$msgs.'");window.history.go(-1);</script>';
	}else{
		echo json_encode(array('err' =>$msgs));
	}
	exit();
}

if(empty($buytime)) {
	$msg=lang('plugin/keke_buyforum', 'f30');
	$msgs=fgbk2utf($msg);
	if($zftype==1){
		echo '<script>alert("'.$msgs.'");window.history.go(-1);</script>';
	}else{
		echo json_encode(array('err' =>$msgs));
	}
	exit();
}

if($buytime<$mintime) {
	$msg=lang('plugin/keke_buyforum', 'f31').$mintime.lang('plugin/keke_buyforum', 'f32');
	$msgs=fgbk2utf($msg);
	if($zftype==1){
		echo '<script>alert("'.$msgs.'");window.history.go(-1);</script>';
	}else{
		echo json_encode(array('err' =>$msgs));
	}
	exit();
}

$moneyQuantity=$setdata[$buyfid]['price']*$buytime;
$money=$moneyQuantity*100;

$orderid=_orderid();
$orderarr=array(
	'orderid'=>$orderid,
	'uid'=>$_G['uid'],
	'state'=>1,
	'zftype'=>$zftype,
	'price'=>$moneyQuantity,
	'buyfid'=>$buyfid,
	'buytime'=>$buytime,
	'time'=>$_G['timestamp'],
	'ip'=>$_G['clientip'],
);
C::t('#keke_buyforum#keke_buyforum_orderlog')->insert($orderarr, true);

if($zftype==1){
	require_once("source/plugin/keke_buyforum/paylib/alipay/alipay.config.php");
	require_once("source/plugin/keke_buyforum/paylib/alipay/alipay_submit.class.php");
	
	//�̻������ţ��̻���վ����ϵͳ��Ψһ�����ţ�����
	$out_trade_no = $orderid;
	//�������ƣ�����
	$subject = $title;
	//���������
	$total_fee = $moneyQuantity;
	//����̨ҳ���ϣ���Ʒչʾ�ĳ����ӣ�����
	$show_url = "plugin.php?id=keke_buyforum";
	//����Ҫ����Ĳ������飬����Ķ�
	$parameter = array(
		"service"       => $alipay_config['service'],
		"partner"       => $alipay_config['partner'],
		"seller_id"  => $alipay_config['seller_id'],
		"payment_type"	=> $alipay_config['payment_type'],
		"notify_url"	=> $alipay_config['notify_url'],
		"return_url"	=> $alipay_config['return_url'],
		"_input_charset"	=> trim(strtolower($alipay_config['input_charset'])),
		"out_trade_no"	=> $out_trade_no,
		"subject"	=> $subject,
		"total_fee"	=> $total_fee,
		"show_url"	=> $show_url,
	);
	//��������
	$alipaySubmit = new AlipaySubmit($alipay_config);
	$html_text = $alipaySubmit->buildRequestForm($parameter,"get", lang('plugin/keke_buyforum', 'f33'));
	echo $html_text;
}elseif($zftype==2){
	include_once DISCUZ_ROOT."source/plugin/keke_buyforum/inc.php";
	$tools = new JsApiPay();
	$openIds = $_G['cookie'][$uskey];
	$openId=authcode($openIds, 'DECODE', $_G['config']['security']['authkey']);
	
	$notify = new NativePay();
	$input = new WxPayUnifiedOrder();
	$input->SetBody($title);
	$input->SetAttach($title);
	$input->SetOut_trade_no($orderid);
	$input->SetTotal_fee($money);
	$input->SetTime_start(date("YmdHis"));
	$input->SetGoods_tag($title);
	$input->SetNotify_url($_G['siteurl']. 'source/plugin/keke_buyforum/paylib/notify_wx.inc.php');
	$input->SetTrade_type($s_type);
	
	if($iswx){
		$input->SetOpenid($openId);
		$order = WxPayApi::unifiedOrder($input);
		$jsApiParameters = $tools->GetJsApiParameters($order);
		
		try
        {
            $jsApiParameters = $tools->GetJsApiParameters($order);
        }catch (Exception $e){
            $jsApiParameters = json_encode(array('err' => $e->getMessage()));
            $jsApiParameters = diconv($jsApiParameters, 'utf-8');
        }
		$jsApiParameters=_createjson($jsApiParameters,$orderid);
		echo $jsApiParameters;
        exit;
		
	}else{
		if(checkmobile() && $keke_buyforum['h5']){
			$h5pay=_h5pay($money,$orderid,$title);
			echo json_encode(array('h5payurl' => $h5pay['mweb_url'],'ewmurl' => '','orderid'=>$orderid));
		}else{
			$input->SetProduct_id($orderid);
			$result = $notify->GetPayUrl($input);
			$url2 = $result["code_url"];
			if($url2){
				$src = _getqrcodeurl($url2);
				echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
			}else{
				$err = $result['return_msg'];
				echo json_encode(array('err' => $err));
			}
		}
		
	}
}