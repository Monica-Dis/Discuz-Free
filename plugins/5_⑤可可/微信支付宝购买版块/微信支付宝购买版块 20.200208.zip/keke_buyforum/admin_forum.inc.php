<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$keke_buyforum = $_G['cache']['plugin']['keke_buyforum'];
	include_once DISCUZ_ROOT."source/plugin/keke_buyforum/fun.php";
	if (submitcheck("forumset")) {
		$data = serialize(daddslashes($_GET['form']));
		if($data) {
			_sevrset($data);
		}
		cpmsg(lang('plugin/keke_buyforum', 'f01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_buyforum&pmod=admin_forum', 'succeed');
	}
	if($_GET['ac']){
		if($_GET['formhash'] != $_G['formhash']) {
			exit('Access Denied');
		}
		$forumid=intval($_GET['forumid']);
		$descdata=C::t('#keke_buyforum#keke_buyforum_desc')->fetch_by_fid($forumid);
		if($_GET['ac']=='edit'){
			if (submitcheck("editsubmit")) {
				$arr=array(
					'fid'=>intval($_GET['forumid']),
					'desc'=> editor_safe_replace($_GET['bkdesc']),
					'title'=>$_GET['title'],
					'keywords'=>$_GET['keywords'],
					'description'=>$_GET['description'],
				);
				C::t('#keke_buyforum#keke_buyforum_desc')->insert($arr, false, true);
				cpmsg(lang('plugin/keke_huati', 'f006'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_buyforum&pmod=admin_forum&ac=edit&forumid='.$forumid.'&formhash='.FORMHASH, 'succeed');
			}
			showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_forum&ac=edit", 'enctype');
			showtableheader();
			showsetting('title','title',$descdata['title'],'text','','',lang('plugin/keke_buyforum', 'f37'));
			showsetting('keywords','keywords',$descdata['keywords'],'text','','',lang('plugin/keke_buyforum', 'f37'));
			showsetting('description','description',$descdata['description'],'textarea','','',lang('plugin/keke_buyforum', 'f37'));
			echo '
			<tr><td colspan="2" class="td27">'.lang('plugin/keke_buyforum', 'f35').'</td></tr>
			<tr class="noborder"><td class="vtop rowform"  colspan="2">
			<textarea name="bkdesc" style="width:700px;height:400px;visibility:hidden;">'.$descdata['desc'].'</textarea></td></tr>
			';
			echo "
			<script charset=\"utf-8\" src=\"./source/plugin/keke_buyforum/static/kindeditor/kindeditor-min.js\"></script>
			<script charset=\"utf-8\" src=\"./source/plugin/keke_buyforum/static/kindeditor/lang/zh-CN.js\"></script>
			<script>
			  var itemss = [
				  'source', '|', 'undo', 'redo', '|', 'preview', 'template', 'cut', 'copy', 'paste',
				  'plainpaste', 'wordpaste', '|', 'justifyleft', 'justifycenter', 'justifyright',
				  'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
				  'superscript', 'clearhtml', 'quickformat', 'selectall', '|', 'fullscreen', '/',
				  'formatblock', 'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold',
				  'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'image', 'multiimage', 'table', 'hr', 'emoticons', 'baidumap', 'pagebreak',
				  'anchor', 'link', 'unlink'
			  ];
			  KindEditor.ready(function(K) {
						var editor1 = K.create('textarea[name=\"bkdesc\"]', {
							uploadJson : './source/plugin/keke_buyforum/upload_json.php',
							allowFileManager : false,
							items : itemss
						});
					});
			</script>
			";
			
			echo '<input name="forumid" type="hidden" value="'.$forumid.'" />';
			showsubmit('editsubmit', 'submit', '');
			showtablefooter();
   			showformfooter();
			exit();
		}
	}
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_forum");
    showtableheader(lang('plugin/keke_buyforum', 'f17'));
    showsubtitle(array(lang('plugin/keke_buyforum', 'f18'),lang('plugin/keke_buyforum', 'f19'),lang('plugin/keke_buyforum', 'f20'),lang('plugin/keke_buyforum', 'f21'),lang('plugin/keke_buyforum', 'f36')));
	$section = unserialize($keke_buyforum['forum']);
	if(!$section){
		cpmsg(lang('plugin/keke_buyforum', 'f22'), ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"], 'succeed');
	}
	$fids=dimplode($section);
	$foruminfo = C::t('forum_forum')->fetch_all_name_by_fid($section);
	$info=_getset();
	foreach($section as $k=>$v){
		$checke= $creditdata[$k]['state'] ? 'checked="checked"' : '';
	  	$table = array();
        $table[0] = $foruminfo[$v]['name'].'<span class="lightfont"> [fid:'.$foruminfo[$v]['fid'].']</span><input name="form['.$v.'][fid]" value="'.intval($foruminfo[$v]['fid']).'"  type="hidden">';
        $table[1] = '<input name="form['.$v.'][price]" value="'.dhtmlspecialchars($info[$v]['price']).'" style="width:50px"> '.lang('plugin/keke_buyforum', 'f23');
		$table[2] = '<input name="form['.$v.'][long]" value="'.dhtmlspecialchars($info[$v]['long']).'" style="width:150px" placeholder="'.lang('plugin/keke_buyforum', 'f24').' 30,90,120,365">';
		$table[3] = '<input name="form['.$v.'][order]" value="'.dhtmlspecialchars($info[$v]['order']).'" style="width:50px"> ';
		$table[4] = '<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_buyforum&pmod=admin_forum&ac=edit&forumid='.$v.'&formhash='.FORMHASH.'"">'.lang('plugin/keke_buyforum', 'f35').'</a>';
        showtablerow('',array('width="200"', 'width="200"','width="250"','width="250"'), $table);
	}
    showsubmit('forumset', 'submit', '', '');
    showtablefooter();
    showformfooter();