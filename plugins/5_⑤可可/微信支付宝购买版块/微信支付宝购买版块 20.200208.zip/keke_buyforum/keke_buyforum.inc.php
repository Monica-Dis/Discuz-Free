<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$keke_buyforum = $_G['cache']['plugin']['keke_buyforum'];
$title=dhtmlspecialchars($keke_buyforum['title']);
if(!$_G['uid']) {
	if(checkmobile()){
		header('location: member.php?mod=logging&action=login&mobile=2');
	}
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
include_once DISCUZ_ROOT."source/plugin/keke_buyforum/fun.php";
if($_GET['p']=='forum'){
	$forumsetarr=_getforuminfo();
}elseif($_GET['p']=='myforum'){
	$mymyforum=_getmyforum();
}elseif($_GET['p']=='order'){
	$myorderarr=_getmyorder();
}elseif($_GET['p']=='loading'){
	$orderid = daddslashes(dhtmlspecialchars($_GET['orderid']));
	$jump='plugin.php?id=keke_buyforum&p=order';
	if($keke_buyforum['jump']==1){
		$orderdata= C::t('#keke_buyforum#keke_buyforum_orderlog')->fetch($out_trade_no);
		$jump='forum.php?mod=forumdisplay&fid='.$orderdata['buyfid'];
	}elseif($keke_buyforum['jump']==3){
		$jump='plugin.php?id=keke_buyforum&p=myforum';
	}
}else{
	$alipayoff=empty($keke_buyforum['alipaypid']) || empty($keke_buyforum['alipaykey']) ? 0 : 1;
	$wxpayoff=empty($keke_buyforum['wxappid']) || empty($keke_buyforum['wxsecert']) || empty($keke_buyforum['wxmchid']) || empty($keke_buyforum['wxshkey']) ? 0 : 1;
	if((strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && !$_GET['p']) && $wxpayoff){
		include_once libfile('function/cache');
		include_once DISCUZ_ROOT."source/plugin/keke_buyforum/inc.php";
		$tools = new JsApiPay();
		$openId = $tools->GetOpenid();
		dsetcookie($uskey, authcode($openId, 'ENCODE', $_G['config']['security']['authkey']), 8640000);
	}
	$f=intval($_GET['f']);
	if($f){
		$forumsetarr=_getforuminfo(1);
		$forumdata=$forumsetarr[$f];
		$buyfid=$f;
	}else{
		$forumsetarr=_getforuminfo();
		$forumdata=$forumsetarr[0];
		$buyfid=$forumdata['fid'];
	}
	$jump=$keke_buyforum['jump']==1?'forum.php?mod=forumdisplay&fid='.$buyfid:($keke_buyforum['jump']==2?'plugin.php?id=keke_buyforum&p=order':'plugin.php?id=keke_buyforum&p=myforum');
	$longstr=$forumdata['long']?$forumdata['long']:$keke_buyforum['day'];
	$dayarr=explode(',',$longstr);
	$mintime=min($dayarr);
	$defaulttotal= number_format($mintime*$forumdata['prices'],2);
	$keke_buyforum['sm']=editor_safe_replace($keke_buyforum['sm']);
}
include template('keke_buyforum:index');