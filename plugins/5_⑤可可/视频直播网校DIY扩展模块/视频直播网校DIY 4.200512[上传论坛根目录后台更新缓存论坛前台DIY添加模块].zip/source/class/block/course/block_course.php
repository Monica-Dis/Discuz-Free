<?php
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class block_course extends discuz_block {
	var $setting = array();
	function block_course() {
		$this->setting = array(
			'catid' => array(
				'title' => lang('plugin/keke_video_base', '202'),
				'type' => 'mselect',
				'value' => array(
				),
				
			),
			'orderby' => array(
				'title' => lang('plugin/keke_video_base', '332'),
				'type' => 'mradio',
				'value' => array(
					array('dateline', lang('plugin/keke_video_base', '333')),
					array('view', lang('plugin/keke_video_base', '334')),
					array('price', lang('plugin/keke_video_base', '335')),
					array('prices', lang('plugin/keke_video_base', '336')),
					array('buy', lang('plugin/keke_video_base', '337'))
				),
				'default' => 'dateline'
			),
			'cids' => array(
				'title' => lang('plugin/keke_video_base', '338'),
				'type' => 'text'
			),
			'uids'	=> array(
				'title' => lang('plugin/keke_video_base', '339'),
				'type' => 'text',
				'value' => ''
			),
			'vip' => array(
				'title' => lang('plugin/keke_video_base', '340'),
				'type' => 'mradio',
				'value' => array(
					array('0', lang('plugin/keke_video_base', '341')),
					array('1', lang('plugin/keke_video_base', '342')),
					array('2', lang('plugin/keke_video_base', '343')),
				),
				'default' => '0'
			),
		);
	}
	function name() {
		return lang('plugin/keke_video_base', '330');
	}
	function blockclass() {
		return array('course', lang('plugin/keke_video_base', '331'));
	}
	function fields() {
		return array(
			'id' => array('name' => lang('plugin/keke_video_base', '344'), 'formtype' => 'text', 'datatype' => 'int'),
			'url' => array('name' => lang('plugin/keke_video_base', '345'), 'formtype' => 'text', 'datatype' => 'string'),
			'title' => array('name' => lang('plugin/keke_video_base', '195'), 'formtype' => 'title', 'datatype' => 'title'),
			'cate' => array('name' => lang('plugin/keke_video_base', '353'), 'formtype' => 'text', 'datatype' => 'string'),
			'cateurl' => array('name' => lang('plugin/keke_video_base', '354'), 'formtype' => 'text', 'datatype' => 'string'),
			'dec' => array('name' => lang('plugin/keke_video_base', '203'), 'formtype' => 'title', 'datatype' => 'string'),
			'pic' => array('name' => lang('plugin/keke_video_base', '200'), 'formtype' => 'pic', 'datatype' => 'pic'),
			'price' => array('name' => lang('plugin/keke_video_base', '346'), 'formtype' => 'text', 'datatype' => 'string'),
			'oprice' => array('name' => lang('plugin/keke_video_base', '347'), 'formtype' => 'text', 'datatype' => 'string'),
			'view' => array('name' => lang('plugin/keke_video_base', '348'), 'formtype' => 'text', 'datatype' => 'string'),
			'buycount' => array('name' =>lang('plugin/keke_video_base', '349'), 'formtype' => 'text', 'datatype' => 'int'),
			'chapter' => array('name' =>lang('plugin/keke_video_base', '219'), 'formtype' => 'text', 'datatype' => 'int'),
			'ke' => array('name' =>lang('plugin/keke_video_base', '220'), 'formtype' => 'text', 'datatype' => 'int'),
			'vip' => array('name' =>'vip', 'formtype' => 'text', 'datatype' => 'int'),
			'teacher' => array('name' => lang('plugin/keke_video_base', '350'), 'formtype' => 'text', 'datatype' => 'string'),
			'dateline' => array('name' => lang('plugin/keke_video_base', '351'), 'formtype' => 'date', 'datatype' => 'date'),
		);
	}
	function getsetting() {
		global $_G;
		$settings = $this->setting;
		if($settings['catid']) {
			$settings['catid']['value'][] = array(0, lang('portalcp', 'block_all_category'));
			loadcache('keke_video_cate');
			$allcatedata=$_G['cache']['keke_video_cate']?$_G['cache']['keke_video_cate']:C::t('#keke_video_base#keke_video_cate')->fetch_all_by_displayorder();
			foreach($allcatedata as $vv){
				if(!$vv['upid']){
					$settings['catid']['value'][] = array($vv['cate_id'], $vv['name']);
					if($vv['subcate']){
						foreach($vv['subcate'] as $subcat){
							$settings['catid']['value'][] = array($subcat, '&nbsp;&nbsp;|-- '.$allcatedata[$subcat]['name']);
						}
					}
				}
			}
		}
		return $settings;
	}
	function getdata($style, $parameter) {
		global $_G;
		loadcache('keke_video_cate');
		$cids = !empty($parameter['cids']) ? explode(',', $parameter['cids']) : array();
		$teacherids = !empty($parameter['uids']) ? explode(',', $parameter['uids']) : array();
		$items		= isset($parameter['items']) ? intval($parameter['items']) : 10;
		$titlelength = isset($parameter['titlelength']) ? intval($parameter['titlelength']) : 40;
		$summarylength = isset($parameter['summarylength']) ? intval($parameter['summarylength']) : 80;
		$allcatedata=$_G['cache']['keke_video_cate']?$_G['cache']['keke_video_cate']:C::t('#keke_video_base#keke_video_cate')->fetch_all_by_displayorder();
		$catid = array();
		if(!empty($parameter['catid'])) {
			if($parameter['catid'][0] == '0') {
				unset($parameter['catid'][0]);
			}
			$catid = $parameter['catid'];
		}
		
		$wheres=array('state=1');
		if($cids) {
			$wheres[] = 'id IN ('.dimplode($cids).')';
		}
		if($teacherids) {
			$wheres[] = 'uid IN ('.dimplode($teacherids).')';
		}		
		if($catid) {
			$wheres[] = 'sub_cate IN ('.dimplode($catid).')';
		}
		if($parameter['vip']==1){
			$wheres[] = 'vip=1';
		}
		$order	= 'ORDER BY time DESC';
		if($parameter['orderby']=='view'){
			$order	= 'ORDER BY view DESC';
		}elseif($parameter['orderby']=='price'){
			$order	= 'ORDER BY price ASC';
		}elseif($parameter['orderby']=='prices'){
			$order	= 'ORDER BY price DESC';
		}
		$wheresql = $wheres ? implode(' AND ', $wheres) : '1';
		if($parameter['orderby']=='buy'){
			$coursearr=C::t('#keke_video_base#keke_video_validtime')->fetch_all_grobycid($items);
		}else{
			$coursearr=C::t('#keke_video_base#keke_video_course')->fetch_all_course(0,$items,$wheresql,$order);
			$studyscount=$this->_getstudyscount($coursearr);
		}
		$list = array();
		$teacherdata=$this->_getteachername($coursearr);
		foreach($coursearr as $data) {
			$descstr= preg_replace('/<\s*img\s+[^>]*?src\s*=\s*(\'|\")(.*?)\\1[^>]*?\/?\s*>/i', '', $data['dec']);
			$list[] = array(
				'id' => $data['id'],
				'title' => cutstr($data['title'], $titlelength, ''),
				'url' => 'plugin.php?id=keke_video_base&ac=course&cid='.$data['id'],
				'pic' => $data['img'] ? $data['img'] : $_G['style']['imgdir'].'/nophoto.gif',
				'fields' => array(
					'dec' => cutstr(strip_tags($descstr),$summarylength),
					'price' => ($data['price']>0 || $data['credit']?($data['price']>0?'&yen; '.$data['price']:'').($data['credit']?($data['price']>0?'+':'').$data['credit'].$_G['setting']['extcredits'][$data['credit_type']]['title']:''):lang('plugin/keke_video_base', '352')),
					'oprice' => $data['original_price'],
					'view' => $data['view'],
					'teacher' => $teacherdata[$data['uid']]['username'],
					'chapter' => $data['chapter_count'],
					'ke' => $data['ke_count'],
					'vip' => ($data['vip']?'vip':''),
					'cate' => $allcatedata[$data['sub_cate']]['name'],
					'cateurl' => ($allcatedata[$data['sub_cate']]['upid']?'plugin.php?id=keke_video_base&ac=list&cid='.$allcatedata[$data['sub_cate']]['upid'].'&scid='.$data['sub_cate']:'plugin.php?id=keke_video_base&ac=list&cid='.$data['sub_cate']),
					'dateline' => $data['time'],
					'buycount'=> ($parameter['orderby']=='buy'?$data['studyscount']:$studyscount[$data['id']]['studyscount'])
				)
			);
		}
		return array('html' => '', 'data' => $list);
	}
	function _getteachername($coursearr){
		foreach($coursearr as $key=>$val){
			$uids[]=$val['uid'];
		}
		$teacherdata=C::t('#keke_video_base#keke_video_teacher')->fetch_all_by_uids($uids);
		return $teacherdata;
	}
	function _getstudyscount($coursearr){
		foreach($coursearr as $key=>$val){
			$cours[]=$val['id'];
		}
		$items=count($cours);
		$validata=C::t('#keke_video_base#keke_video_validtime')->fetch_all_grobycid($items,$cours);
		return $validata;
	}
}