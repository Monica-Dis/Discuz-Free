<?php
$blockclass = array(
	'name' => lang('plugin/keke_video_base', '329'),
);
?>