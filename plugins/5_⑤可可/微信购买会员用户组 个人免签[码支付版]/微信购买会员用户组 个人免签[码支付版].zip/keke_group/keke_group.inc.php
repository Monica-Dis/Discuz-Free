<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

define('CURSCRIPT', 'forum');
global $_G;
$keke_group = $_G['cache']['plugin']['keke_group'];
if((!$_G['uid'] && $_GET['p']) || ($keke_group['login'] && !$_G['uid'])) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}

if ($_G['cache']['plugin']['keke_market']) {
	$keke_market = $_G['cache']['plugin']['keke_market'];
	require_once DISCUZ_ROOT.'./source/plugin/keke_market/function.php';
	$market_member=C::t('#keke_market#keke_market_member')->fetchfirst_byuid($_G['uid']);
	$sharebtn=$keke_group['sharebtn'];
	if($keke_group['wapsharetxt']){
		$keke_market['wapsharetxt']=explode('|',$keke_group['wapsharetxt']);
		$keke_market['wapsharetxt']=$market_member?($keke_market['wapsharetxt'][1]?$keke_market['wapsharetxt'][1]:$keke_market['wapsharetxt'][0]):$keke_market['wapsharetxt'][0];
	}
	if($keke_group['pcsharetxt']){
		$keke_market['pcsharetxt']=explode('|',$keke_group['pcsharetxt']);
		$keke_market['pcsharetxt']=$market_member?($keke_market['pcsharetxt'][1]?$keke_market['pcsharetxt'][1]:$keke_market['pcsharetxt'][0]):$keke_market['pcsharetxt'][0];
	}
	
	binduser();
}

include_once DISCUZ_ROOT."source/plugin/keke_group/common.php";

$title=$navtitle=dhtmlspecialchars($keke_group['title']);
$keke_group['waptopcolour']=dhtmlspecialchars($keke_group['waptopcolour']);
$keke_group['pcleftcolour']=dhtmlspecialchars($keke_group['pcleftcolour']);
$keke_group['pcbtncolour']=dhtmlspecialchars($keke_group['pcbtncolour']);
$alipayoff=empty($keke_group['alipaypid']) || empty($keke_group['alipaykey']) ? 0 : 1;
$wxpayoff=empty($keke_group['wxappid']) || empty($keke_group['wxsecert']) || empty($keke_group['wxmchid']) || empty($keke_group['wxshkey']) ? 0 : 1;
$ys=$keke_group['ys']? dhtmlspecialchars($keke_group['ys']) : '#e14546';
$returnurl=$keke_group['tz']?editor_safe_replace($keke_group['tz']):'plugin.php?id=keke_group&p=my';
if((strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false && !$_GET['p']) && $wxpayoff){
	include_once libfile('function/cache');
	include_once DISCUZ_ROOT."source/plugin/keke_group/inc.php";
	$tools = new JsApiPay();
	$openId = $tools->GetOpenid();
	dsetcookie($uskey, authcode($openId, 'ENCODE', $_G['config']['security']['authkey']), 8640000);
}
$nowgroup=_getnowgroup();
if($_GET['p']=='my'){
	$pages=intval($_GET['page']);
	$myorderdata=_getmyorder($pages);
	$list=$myorderdata['list'];
	$multipage=$myorderdata['page'];
}elseif($_GET['p']=='sw'){
	$n=1;
	$expirylist=_getmygrouplist();
}elseif($_GET['p']=='loading'){
	$orderid=daddslashes(dhtmlspecialchars($_GET['orderid']));
}elseif($_GET['p']=='id'){
	exit(K_SITEID);
}else{
	$gorupdata = _indexdata();
	$keke_group['sm']=editor_safe_replace($keke_group['sm']);
	if ($_G['cache']['plugin']['keke_market'] && $keke_group['share']){
		$course['title']=$keke_group['postertitle'];	
		$invitationtext=str_ireplace("[name]",$_G['username'],$keke_group['posterdec']);
	}
}
include template('keke_group:index');