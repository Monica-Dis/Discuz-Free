<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
global $_G;
loadcache('plugin');
$keke_group = $_G['cache']['plugin']['keke_group'];
include_once DISCUZ_ROOT."source/plugin/keke_group/common.php";
if (submitcheck("forumsets")) {
	if(is_array($_GET['delete'])) {
			C::t('#keke_group#keke_group_orderlog')->delete($_GET['delete']);
	}
	cpmsg(lang('plugin/keke_group', 'lang18'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin', 'succeed');
}
if (submitcheck("forumset")) {
	C::t('#keke_group#keke_group_orderlog')->del_oder();
	cpmsg(lang('plugin/keke_group', 'lang18'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin', 'succeed');
}
showtableheader(lang('plugin/keke_group', 'lang19'));
showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");
showtablerow('', array('width="60"', 'width="100"', 'width="40"','width="180"','width="60"','width="180"','width="70"','width="280"'),
	array(
		'<b>'.lang('plugin/keke_group', 'lang29').'</b>',
		'<select name="state"><option value="0">'.lang('plugin/keke_group', 'lang62').'</option><option value="9">'.lang('plugin/keke_group', 'lang63').'</option><option value="1">'.lang('plugin/keke_group', 'lang64').'</option></select>',
		'<b>'.lang('plugin/keke_group', 'lang65').'</b>',
		'<input name="orderid" value="'.dhtmlspecialchars($_GET['orderid']).'" type="text" />',
		'<b>'.lang('plugin/keke_group', 'lang24').'</b>',
		'<input name="username" value="'.dhtmlspecialchars($_GET['username']).'" type="text" />',
		'<b>'.lang('plugin/keke_group', 'lang30').'</b>',
		'<input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'"/>',
		'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_group', 'lang66').'">&nbsp;&nbsp;&nbsp;<input type="submit" class="btn" id="forumset" name="forumset" value="'.lang('plugin/keke_group', 'lang20').'"><script src="static/js/calendar.js"></script>'
	)
);

$where=$param='';
if($_GET['orderid']){
	$where=" AND orderid='".daddslashes(dhtmlspecialchars($_GET['orderid'])).'\'';
	$param.='&orderid='.dhtmlspecialchars($_GET['orderid']);
}
if($_GET['state']){
	if($_GET['state']==9)$_GET['state']=0;
	$where.=" AND state=".intval($_GET['state']);
	$param.='&state='.intval($_GET['state']);
}
if($_GET['username']){
	$where=" AND usname='".daddslashes(dhtmlspecialchars($_GET['username'])).'\'';
	$param.='&username='.dhtmlspecialchars($_GET['username']);
	
}
if($_GET['time']){
	$where.=" AND time>".strtotime($_GET['time']);
	$param.='&time='.dhtmlspecialchars($_GET['time']);
}
if($_GET['endtime']){
	$where.=" AND time<".strtotime($_GET['endtime']);
	$param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
}
showtableheader(lang('plugin/keke_group', 'lang21'));
showsubtitle(array(lang('plugin/keke_group', 'lang22'),lang('plugin/keke_group', 'lang23'),lang('plugin/keke_group', 'lang24'), lang('plugin/keke_group', 'lang25'), lang('plugin/keke_group', 'lang26'),lang('plugin/keke_group', 'lang27'),lang('plugin/keke_group', 'lang28'),lang('plugin/keke_group', 'lang29'),lang('plugin/keke_group', 'lang30'),lang('plugin/keke_group', 'lang31'),lang('plugin/keke_group', 'lang32')));

$ppp=50;



$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_group&pmod=admin'.$param;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$allcount = C::t('#keke_group#keke_group_orderlog')->count_by_all(0,0,$where);
if($allcount){
	$query = C::t('#keke_group#keke_group_orderlog')->fetch_all_by_all(0,0,$startlimit,$ppp,$where);
	foreach($query as $val){
		$money=$val['money']/100;
		$time=dgmdate($val['zftime'], 'Y/m/d H:i');
		$stat=$val['state'] ? '<font color="#33CC33">'.lang('plugin/keke_group', 'lang10').'</font>' : '<font color="#c30">'.lang('plugin/keke_group', 'lang11').'</font>' ;
		$type=$val['type']==1 ? lang('plugin/keke_group', 'lang12') : ($val['type']==3?lang('plugin/keke_group', 'lang54'):lang('plugin/keke_group', 'lang13')) ;
		$groupvalidity=$val['groupvalidity']?$val['groupvalidity'].' '.lang('plugin/keke_group', 'lang09'):lang('plugin/keke_group', 'lang07');
		$table = array();
		$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['orderid'].'" />';
		$table[1] = $val['orderid'];
		$table[2] = '<a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'.$val['usname'].'</a>';
		$table[3] = $val['groupname'];
		$table[4] = $groupvalidity;
		$table[5] = $money.' '.lang('plugin/keke_group', 'lang03');
		$table[6] = $type;
		$table[7] = $stat;
		$table[8] = dgmdate($val['time'], 'Y/m/d H:i');
		$table[9] = $val['zftime'] ? dgmdate($val['zftime'], 'Y/m/d H:i') : '<font color="#CCCCCC">--</font>';
		$table[10] = $val['sn'] ? $val['sn'] : '<font color="#CCCCCC">--</font>';
		showtablerow('',array(), $table);
	}
}
$multipage='';
$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
if($multipage){
	echo '<tr class="hover"><td colspan="10">'.$multipage.'</td></tr>';
}
showsubmit('forumsets', 'submit', 'del');
/*Dism_taobao-com*/showtablefooter();
showformfooter();/*Dism_taobao_com*/
