<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
	
class plugin_keke_reward_forum {
	function viewthread_postbottom_output(){
		global $_G, $postlist;
		$keke_reward = $_G['cache']['plugin']['keke_reward'];
		$section = empty($keke_reward['section']) ? array() : unserialize($keke_reward['section']);
		if(!is_array($section)) $section = array();
		if(!(in_array($_G['fid'],$section)) && !$_G['thread']['isgroup']){
			return array();
		}
		$group = empty($keke_reward['group']) ? array() : unserialize($keke_reward['group']);
		$atid=intval($_G['tid']);
		$type=1;
		$n=0;
        $btnsty=$btntmp='';
		if(!is_array($group)) $gro = array();
		$rewarddata=C::t('#keke_reward#keke_reward')->fetchall_byatid($atid);
		if($keke_reward['reply']){
			foreach($postlist as $key=>$val){
				$uids[$val['authorid']]=$val['authorid'];
			}
			$members = C::t('common_member')->fetch_all($uids);
			$keke_reward_userset=C::t('#keke_reward#keke_reward_userset')->fetch_all_by_uid($uids);
			foreach($postlist as $key=>$val){
				$zzid=$postlist[$key]['authorid'];
				$pid=$val['pid'];
				$userlist=array_slice(array_unique(explode(',',$rewarddata[$pid]['uids'])),0,10);
				$usercount=count($userlist);
				include template('keke_reward:block');
				if(!(empty($group[0]) || in_array($members[$zzid]['groupid'],$group))){
					$btntmp='';
				}
				$return_array[]=(!$n?$btnsty:'').$btntmp;
				$n++;
			}
		}else{
			$zzid=$_G['thread']['authorid'];
            $members=getuserbyuid($zzid);
			if(!in_array($members['groupid'],$group) || !$_G['forum_firstpid']){
				return array();
			}
			$keke_reward_userset=C::t('#keke_reward#keke_reward_userset')->fetch_all_by_uid($zzid);
			$pid=$postlist[$_G['forum_firstpid']]['pid'];
			$userlist=array_slice(array_unique(explode(',',$rewarddata[$pid]['uids'])),0,10);
			$usercount=count($userlist);
			include template('keke_reward:block');
			$return_array[]=$btntmp.$btnsty;
		}
		return $return_array;
	}
}

class plugin_keke_reward_portal{
	function view_article_content_output(){
		global $_G,$article;
		$type=2;$pid=0;
		$atid=intval($_GET['aid']);
		$keke_reward = $_G['cache']['plugin']['keke_reward'];
		$article=!$article?C::t('portal_article_title')->fetch($atid):$article;
		$zzid=$article['uid'];
		$group = empty($keke_reward['group']) ? array() : unserialize($keke_reward['group']);
		$members = C::t('common_member')->fetch_all($zzid);
		$keke_reward_userset=C::t('#keke_reward#keke_reward_userset')->fetch_all_by_uid($zzid);
		if(!in_array($members[$zzid]['groupid'],$group)){
			return '';
		}
        $btnsty=$btntmp='';
		$rewarddata=C::t('#keke_reward#keke_reward')->fetchall_byatid($atid);
		$userlist=array_slice(array_unique(explode(',',$rewarddata[$pid]['uids'])),0,10);
		$usercount=count($userlist);
		include template('keke_reward:block');
		$ret=$btntmp.$btnsty;
		return $ret;
	}
	
}

class plugin_keke_reward_group extends plugin_keke_reward_forum{
}
class mobileplugin_keke_reward_group extends plugin_keke_reward_forum{
}

class mobileplugin_keke_reward_forum extends plugin_keke_reward_forum{
	function viewthread_postbottom_mobile_output(){
		return $this->viewthread_postbottom_output();
	}
}