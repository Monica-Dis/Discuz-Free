<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_reward = $_G['cache']['plugin']['keke_reward'];
if(!$_G['uid']) {
	showmessage('not_loggedin', NULL, array(), array('login' => 1));
}
$group = empty($keke_reward['group']) ? array() : unserialize($keke_reward['group']);
if(!in_array($_G['groupid'],$group)){
	showmessage(lang('plugin/keke_reward', '012'));
}

$ops=$_GET['ops']?intval($_GET['ops']):1;
$where='';
switch ($ops) {
	case 1:
		$where='state=1 AND touid='.$_G['uid'];
	break;
	case 2:
		$where='state=1 AND uid='.$_G['uid'];
	break;
	case 3:
		if (!submitcheck("forumset")) {
			$setdata=C::t('#keke_reward#keke_reward_userset')->fetch_by_uid($_G['uid']);
		}else{
			C::t('#keke_reward#keke_reward_userset')->insert(array('uid' => $_G['uid'],'slogan' => $_GET['slogan']), false, true);
			showmessage(lang('plugin/keke_reward', '011'), 'home.php?mod=spacecp&ac=plugin&id=keke_reward:keke_myreward&ops=3');
		}
	break;
}
if($where){
	$ppp=10;
	$tmpurl='home.php?mod=spacecp&ac=plugin&id=keke_reward:keke_myreward&ops='.$ops;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($count = C::t('#keke_reward#keke_reward')->count_by_all($where)){
		$_data=C::t('#keke_reward#keke_reward')->fetch_all_by_all($where.' ORDER by time DESC',$startlimit,$ppp);
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].$tmpurl);
	}
}
if(checkmobile()){
    include_once template('keke_reward:keke_myreward');
    exit();
}