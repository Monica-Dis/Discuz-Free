<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);
require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');

include_once DISCUZ_ROOT."source/plugin/keke_reward/function.php";
@require_once DISCUZ_ROOT."source/plugin/keke_pay/payinc.php";

$keke_notify=new keke_notify;
$result=$keke_notify->CheckAlipayNotify();
if($result===true){
    _upuserdata($_POST['out_trade_no'],$_POST['trade_no']);
    exit('success');
}
exit('error');