<?php
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);
require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
global $_G;
loadcache('plugin');
$returl=str_replace('source/plugin/keke_reward/paylib/', '',$_G['siteurl']);
if($_GET['out_trade_no']){
    $orderdata= C::t('#keke_reward#keke_reward')->fetch($_GET['out_trade_no']);
    if($orderdata['type']==1){
        $url='forum.php?mod=viewthread&tid='.$orderdata['atid'];
    }else{
        $url='portal.php?mod=view&aid='.$orderdata['atid'];
    }
    dheader('location: '.$returl.$url);
}
exit('Error');