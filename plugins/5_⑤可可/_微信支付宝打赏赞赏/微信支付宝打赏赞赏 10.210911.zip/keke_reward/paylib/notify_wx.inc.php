<?php

header('Content-type:text/html; Charset=utf-8');
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');
header('Content-type:text/html; Charset=utf-8');
@include_once DISCUZ_ROOT."source/plugin/keke_pay/paylib/wechat/inc.php";
@require_once DISCUZ_ROOT."source/plugin/keke_pay/payinc.php";
include_once DISCUZ_ROOT."source/plugin/keke_reward/function.php";
$keke_notify=new keke_notify;
$result=$keke_notify->CheckWechatNotify();
if($result[0]===true){
    _upuserdata($result[1]['out_trade_no'],$result[1]['transaction_id'],$result[1]['openid']);
}
exit();