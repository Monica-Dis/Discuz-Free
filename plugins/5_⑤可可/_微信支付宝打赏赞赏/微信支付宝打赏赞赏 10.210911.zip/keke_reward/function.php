<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function _createorder(){
	global $_G;
	$nowdate=dgmdate($_G['timestamp'], 'YmdHis');
	$random=random(10);
	$orderid=$nowdate.$random;
	return $orderid;
}
function _instorder($orderid,$money,$zftype,$atid,$type,$touid,$pid){
	global $_G;
	$orderarr=array(
		'orderid'=>$orderid,
		'uid'=>$_G['uid'],
		'touid'=>$touid,
		'money'=>$money,
		'zftype'=>$zftype,
		'atid'=>$atid,
		'pid'=>$pid,
		'type'=>$type,
		'time'=>$_G['timestamp'],
	);
	C::t('#keke_reward#keke_reward')->insert($orderarr, true);
}
function keke_reward_utf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return $data;
	}
}
function keke_reward_gbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}

function _upuserdata($out_trade_no,$sns,$opid=''){
	global $_G;
	$orderdata= C::t('#keke_reward#keke_reward')->fetch($out_trade_no);
	if($orderdata && !$orderdata['state']){
		$orderarr=array(
			'state'=>'1',
			'paytime'=>$_G['timestamp'],
			'sn'=>$sns,
		);
		C::t('#keke_reward#keke_reward')->update($out_trade_no, $orderarr);
		@include_once DISCUZ_ROOT."source/plugin/keke_wallet/api.php";
		$url=($orderdata['type']==1)?'forum.php?mod=redirect&goto=findpost&ptid='.$orderdata['atid'].'&pid='.$orderdata['pid']:'portal.php?mod=view&aid='.$orderdata['atid'];
		$typetitlle=($orderdata['type']==1)?lang('plugin/keke_reward', '003'):lang('plugin/keke_reward', '004');
		updateuserwallet($orderdata['touid'],$orderdata['money'],$out_trade_no,$typetitlle.lang('plugin/keke_reward', '005').' <a href="'.$url.'" target="_blank">'.lang('plugin/keke_reward', '006').'</a>',lang('plugin/keke_reward', '002'));
	}
}

function _getpreval(){
	global $_G;
	$keke_reward = $_G['cache']['plugin']['keke_reward'];
	$preset=explode(',',$keke_reward['money']);
	foreach($preset as $key=>$val){
		$val=floatval($val);
		$viewmoney=number_format($val,2);
		$y=explode(".",$viewmoney);
		$sty= $key ? '' : 'class="on"';
		$give='<cite>.'.$y[1].' '.lang('plugin/keke_reward', '008').'</cite>';
		$preval.='<li '.$sty.' money="'.$val.'"><h4>'.$y[0].$give.'</h4></li>';
	}
	return $preval;
}

function _getusernamebyuid($uid){
    $user=getuserbyuid($uid);
    return $user['username'];

}