<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

global $_G;
$keke_reward = $_G['cache']['plugin']['keke_reward'];
if($_GET['formhash'] != $_G['formhash']) {
	exit('Formhash_Error');
}
include_once DISCUZ_ROOT."source/plugin/keke_reward/function.php";
$filter=array('zzid','type','atid','pid');
foreach($filter as $val){
	if($_GET[$val])$_GET[$val]=intval($_GET[$val]);
}
if($_GET['ac']=='showwin'){
	include template('common/header_ajax');
	include template('keke_reward:block');
    echo $wintmp;
	include template('common/footer_ajax');
}elseif($_GET['ac']=='showreward'){
    $preset=explode(',',$keke_reward['money']);
	$preval=_getpreval();
    $index['username']=_getusernamebyuid($_GET['zzid']);
	include template('keke_reward:index');
}elseif($_GET['ac']=='rewardlist'){
	$where='touid='.$_GET['zzid'].' AND state=1';
	if($_GET['type']==1 && $_GET['pid']){
		$where.=' AND pid='.$_GET['pid'];
	}else{
		$where.=' AND atid='.$_GET['atid'];
	}
    $top_data=C::t('#keke_reward#keke_reward')->fetch_all_by_all($where.' order by money desc',0,3);
	$ppp=5;
	$tmpurl='plugin.php?id=keke_reward:ajax&zzid='.$_GET['zzid'].'&ac=rewardlist&type='.$_GET['type'].'&atid='.$_GET['atid'].'&pid='.$_GET['pid'].'&formhash='.FORMHASH;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($count = C::t('#keke_reward#keke_reward')->count_by_all($where)){
		$_data=C::t('#keke_reward#keke_reward')->fetch_all_by_all($where.' order by time desc',$startlimit,$ppp);
		$multipage = multi($count, $ppp, $page, $_G['siteurl'].$tmpurl);
	}
	if(checkmobile()){
		if($_GET['type']==1){
			$thread = C::t('forum_thread')->fetch($_GET['atid']);
			$subject=$thread['subject'];
		}else{
			$article=C::t('portal_article_title')->fetch($_GET['atid']);
			$subject=$article['title'];
		}
		include template('keke_reward:list');
	}else{
		include template('common/header_ajax');
		include template('keke_reward:block');
		echo $rewardlist;
		include template('common/footer_ajax');
	}
}elseif($_GET['ac']=='CheckOrder'){
    $state=0;
    if(C::t('#keke_reward#keke_reward')->fetchstate_by_orderid($_GET['orderid'])){
        $state=1;
    }
    exit(json_encode(array('state' =>$state)));
}