<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_reward extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_reward';
		$this->_pk    = 'orderid';

		parent::__construct(); /*dism �� taobao �� com*/
	}
	
	public function count_by_all($where) {
		return DB::result_first("SELECT count(1) FROM %t WHERE 1 AND %i", array($this->_table,$where));
	}
	
	public function fetch_all_by_all($where,$startlimit,$ppp) {
		$data=DB::fetch_all("SELECT * FROM %t WHERE 1 AND %i LIMIT %d,%d", array($this->_table,$where,$startlimit,$ppp));
		foreach($data as $val){
			$uids[$val['uid']]=$val['uid'];
			$uids[$val['touid']]=$val['touid'];
			if($val['type']==1){
				$tids[]=$val['atid'];
			}else{
				$aids[]=$val['atid'];
			}
		}
		$thread  = $tids ? C::t('forum_thread')->fetch_all($tids):array();
		$article = $aids ? C::t('portal_article_title')->fetch_all($aids):array();
		$members = C::t('common_member')->fetch_all($uids);
		foreach($data as $k=>$v){
			$data[$k]['username']=$members[$v['uid']]['username'];
			$data[$k]['tousername']=$members[$v['touid']]['username'];
			$data[$k]['time']=dgmdate($v['time'],'Y/m/d H:i');
			$data[$k]['times']=dgmdate($v['time'],'u');
			$data[$k]['subject']=($v['type']==1)?$thread[$v['atid']]['subject']:$article[$v['atid']]['title'];
		}		
		return $data;
	}
	
	
	public function fetchall_byatid($tid) {
		return DB::fetch_all("SELECT pid ,count(1) as count,group_concat(uid) as uids FROM %t WHERE 1 AND atid=%d AND state=1 group by pid", array($this->_table,$tid),'pid');
	}
	
	
	public function del_oder() {
		return DB::query("delete FROM %t where state=0",array($this->_table));
	}
	
	public function sum_by_uid($uid) {
		return DB::result_first("SELECT sum(money) FROM %t WHERE uid=%d AND state=1", array($this->_table,$uid));
	}


    public function fetchstate_by_orderid($orderid) {
        return DB::result_first("SELECT state FROM %t WHERE orderid=%s", array($this->_table,$orderid));
    }
	
}

?>