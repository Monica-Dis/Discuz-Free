<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class kekesmsapi {
	
	public function __construct($cofig = array()) {
		global $_G;
		$keke_sms = $_G['cache']['plugin']['keke_sms'];
		$this->appkey=dhtmlspecialchars(trim($keke_sms['appkey']));
		$this->secretKey=dhtmlspecialchars(trim($keke_sms['secretKey']));
		$this->acckeyid=dhtmlspecialchars(trim($keke_sms['acckeyid']));
		$this->accsecretKey=dhtmlspecialchars(trim($keke_sms['accsecretKey']));
	}
	
	public function kekesendsms($phone,$sign,$text,$smstemp,$sendmod=1){
		foreach ( $text as $key => $value ) {
			$value=$this->gbk2utf($value);
			$value=$sendmod==2? urlencode($value):$value;
			$text[$key] = $value;  
		}
		$sign=$this->gbk2utf($sign);
		$phone=trim($phone);
		if($sendmod==2){
			$sendtxt=urldecode(json_encode($text));
			$return=$this->dayusendsms($phone,$sign,$sendtxt,$smstemp);
		}elseif($sendmod==1){
			$return=$this->aliyunsendsms($phone,$sign,$text,$smstemp);
		}
		return $return;
	}
	
	private function dayusendsms($phone,$sign,$text,$smstemp){
		require_once DISCUZ_ROOT.'./source/plugin/keke_sms/inc/Autoloader.php';
		$c = new TopClient;
		$c->appkey = $this->appkey;
		$c->secretKey = $this->secretKey;
		$req = new AlibabaAliqinFcSmsNumSendRequest;
		$req->setExtend($phone);
		$req->setSmsType("normal");
		$req->setSmsFreeSignName($sign);
		$req->setSmsParam($text);
		$req->setRecNum($phone);
		$req->setSmsTemplateCode($smstemp);
		$resp = $c->execute($req);
		return $resp;
	}
	
	private function aliyunsendsms($phone,$sign,$text=array(),$smstemp) {
		require_once DISCUZ_ROOT.'./source/plugin/keke_sms/inc/aliyun/SignatureHelper.php';
		$params = array ();
		$accessKeyId = $this->acckeyid;
		$accessKeySecret = $this->accsecretKey;
		$params["PhoneNumbers"] = $phone;
		$params["SignName"] = $sign;
    	$params["TemplateCode"] = $smstemp;
    	$params['TemplateParam'] = $text;
		$params['OutId'] = "12345";
		$params['SmsUpExtendCode'] = "1234567";
		if(!empty($params["TemplateParam"]) && is_array($params["TemplateParam"])) {
			$params["TemplateParam"] = json_encode($params["TemplateParam"]);
		}
		$helper = new SignatureHelper();
		$content = $helper->request(
			$accessKeyId,
			$accessKeySecret,
			"dysmsapi.aliyuncs.com",
			array_merge($params, array(
				"RegionId" => "cn-hangzhou",
				"Action" => "SendSms",
				"Version" => "2017-05-25",
			))
		);
		return $content;
	}

	private function utf2gbk($data){
		$data=dhtmlspecialchars($data);
		$data1 = diconv($data,'utf-8','gbk');
		$data0 = diconv($data1,'gbk','utf-8');
		if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
		if(CHARSET=='gbk'){
			return $tmpstr;
		}else{
			return gbk2utf($data);
		}
	}
	
	private function gbk2utf($data){
		$data1 = diconv($data,'utf-8','gbk');
		$data0 = diconv($data1,'gbk','utf-8');
		if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
		return diconv($tmpstr,'gbk','utf-8');
	}
}