<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


include_once DISCUZ_ROOT."source/plugin/keke_group/identity.inc.php";
include_once DISCUZ_ROOT."source/plugin/keke_group/function.php";


function arrtoxml($data){
    $xml = "<xml>";
    foreach ($data as $key=>$val){
        if (is_numeric($val)){
            $xml.="<".$key.">".$val."</".$key.">";
        }else{
            $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
        }
    }
    $xml.="</xml>";
    return $xml;
}
function _orderid(){
	global $_G;
	$nowdate=dgmdate($_G['timestamp'], 'YmdHis');
	$random=random(10);
	$orderid=$nowdate.$random;
	return $orderid;
}
function _getallgro(){
	return C::t('#keke_group#keke_group')->fetchall_group();
}
function getbuygroupdata($buygorupid){
	return C::t('#keke_group#keke_group')->fetchfirst_bybuygorupid($buygorupid);
}
function _getusergroupopt($buygorupdata){
	foreach(C::t('common_usergroup')->fetch_all_by_type(array('special'),0) as $keys=>$value) {
		$selected='';
		if($buygorupdata['groupid']==$value['groupid']){
			$selected='selected';
		}
		$usergroups_options .= "<option value=\"$value[groupid]\" $selected>".$value['grouptitle'];
	}
	return $usergroups_options;
}
function _indexdata(){
	$gorupdata = _getallgro();
	foreach($gorupdata as $tk=>$tv){
		$gorupdata[$tk]['tequan']=explode(",",$tv['tequan']);
		$gorupdata[$tk]['money']=$tv['money']/100;
	}
	return $gorupdata;
}
function _switchgroup($groupid,$uids){
	$groupid = intval($groupid);
	$extgroupids= $extgroupidsarray = array();
	$themembers = C::t('common_member')->fetch($uids);
	$extgroupids = $themembers['extgroupids'] ? explode("\t", $themembers['extgroupids']) : array();
	
	$ret=array();
	$ret['state']=1;
	if(!in_array($groupid, $extgroupids)) {
		$ret['msg']=lang('plugin/keke_group', 'lang05');
		$ret['state']=0;
		return $ret;
	}
	if($themembers['groupid'] == 4 && $themembers['groupexpiry'] > 0 && $themembers['groupexpiry'] > TIMESTAMP) {
		$ret['msg']=lang('plugin/keke_group', 'lang06');
		$ret['state']=0;
		return $ret;
	}
	
	$group = C::t('common_usergroup')->fetch($groupid);
	$memberfieldforum = C::t('common_member_field_forum')->fetch($uids);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	
	$extgroupidsnew = $themembers['groupid'];
	$groupexpirynew = $groupterms['ext'][$groupid];
	
	foreach($extgroupids as $extgroupid) {
		if($extgroupid && $extgroupid != $groupid) {
			$extgroupidsnew .= "\t".$extgroupid;
		}
	}
	if($themembers['adminid'] > 0 && $group['radminid'] > 0) {
		$newadminid = $themembers['adminid'] < $group['radminid'] ? $themembers['adminid'] : $group['radminid'];
	} elseif($themembers['adminid'] > 0) {
		$newadminid = $themembers['adminid'];
	} else {
		$newadminid = $group['radminid'];
	}
	C::t('common_member')->update($uids, array('groupid' => $groupid, 'adminid' => $newadminid, 'groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
	return $ret;
}

function _upuserdata($out_trade_no,$sns,$opid=''){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	$orderdata= C::t('#keke_group#keke_group_orderlog')->fetch($out_trade_no);
	if(!$orderdata['state']){
		$ret=_buygroup($orderdata['groupid'],$orderdata['groupvalidity'],$orderdata['uid']);
		$orderarr=array(
			'state'=>'1',
			'zftime'=>$_G['timestamp'],
			'sn'=>$sns,
			'opid'=>$opid,
			'groupinvalid'=>$ret['tims']
		);
		C::t('#keke_group#keke_group_orderlog')->update($out_trade_no, $orderarr);
		
		$buygorupdata=C::t('#keke_group#keke_group')->fetchfirst_bybuygorupid($orderdata['tablegroupid']);
		if($buygorupdata['givecradit']){
			updatemembercount($orderdata['uid'], array('extcredits'.$buygorupdata['givecredittype']=>$buygorupdata['givecradit']), true, '', 0, '',lang('plugin/keke_group', 'lang70'),lang('plugin/keke_group', 'lang71').$buygorupdata['groupname'].lang('plugin/keke_group', 'lang70'));
		}
		
		if($_G['cache']['plugin']['keke_market'] && (($keke_group['cdkey'] && $orderdata['type']==3) || $orderdata['type']!=3)){
			require_once DISCUZ_ROOT.'./source/plugin/keke_market/function.php';
			$market_userdata=_getmarketupuid($orderdata['uid']);
			market_cach_log($market_userdata,$orderdata['orderid'],$orderdata['money']/100,'keke_group');
		}
	}
}

function _getmygrouplist(){
	global $_G;
	$gorupdata = _getallgro();
	foreach($gorupdata as $tk=>$tv){
		$gorupdata[$tv['groupid']]=$tv;
	}
	$extgroupids = $_G['member']['extgroupids'] ? explode("\t", $_G['member']['extgroupids']) : array();
	$memberfieldforum = C::t('common_member_field_forum')->fetch($_G['uid']);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	$expgrouparray = $expirylist = $termsarray = array();
	if(!empty($groupterms['ext']) && is_array($groupterms['ext'])) {
		$termsarray = $groupterms['ext'];
	}
	if(!empty($groupterms['main']['time']) && (empty($termsarray[$_G['groupid']]) || $termsarray[$_G['groupid']] > $groupterm['main']['time'])) {
		$termsarray[$_G['groupid']] = $groupterms['main']['time'];
	}
	foreach($termsarray as $expgroupid => $expiry) {
		if($expiry <= TIMESTAMP) {
			$expgrouparray[] = $expgroupid;
		}
	}
	if(!empty($groupterms['ext'])) {
		foreach($groupterms['ext'] as $extgroupid => $time) {
			$expirylist[$extgroupid] = array('time' => dgmdate($time, 'd'), 'type' => 'ext', 'noswitch' => $time < TIMESTAMP);
		}
	}
	if(!empty($groupterms['main'])) {
		$expirylist[$_G['groupid']] = array('time' => dgmdate($groupterms['main']['time'], 'd'), 'type' => 'main');
	}
	$groupids = array();
	foreach($_G['cache']['usergroups'] as $groupid => $usergroup) {
		if(!empty($usergroup['pubtype'])) {
			$groupids[] = $groupid;
		}
	}
	$expiryids = array_keys($expirylist);
	if(!$expiryids && $_G['member']['groupexpiry']) {
		C::t('common_member')->update($_G['uid'], array('groupexpiry' => 0));
	}
	$groupids = array_merge($extgroupids, $expiryids, $groupids);
	if($groupids) {
		foreach(C::t('common_usergroup')->fetch_all($groupids) as $group) {
			$isexp = in_array($group['groupid'], $expgrouparray);
			$expirylist[$group['groupid']]['maingroup'] = $group['type'] != 'special' || $group['system'] == 'private' || $group['radminid'] > 0;
			$expirylist[$group['groupid']]['grouptitle'] = $isexp ? '<s>'.$group['grouptitle'].'</s>' : $group['grouptitle'];
			if($gorupdata[$group['groupid']]){
				$expirylist[$group['groupid']]['ico']=$gorupdata[$group['groupid']]['ico'];
			}
			$expirylist[$group['groupid']]['dateline'] = $groupterms['ext'][$group['groupid']];
		}
	}
	return $expirylist;
}


function _getnowgroup(){
	global $_G;
	$allgroup=C::t('common_usergroup')->range();
	$nowgroup['title']=$allgroup[$_G['groupid']]['grouptitle'];
	$time=lang('plugin/keke_group', 'lang07');
	$overdue=0;
	if($_G['member']['groupexpiry']){
		$time=dgmdate($_G['member']['groupexpiry'], 'd');
		if($_G['member']['groupexpiry']<TIMESTAMP){
			$overdue=1;
		}
			
	}
	$nowgroup['time']=$time;
	$nowgroup['overdue']=$overdue;
	return $nowgroup;
}


function _sensms($text,$phone,$alitmpid){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	if(file_exists(DISCUZ_ROOT.'./source/plugin/keke_sms/sendsms.php')){
		$alisign=dhtmlspecialchars(trim($keke_group['sign']));
		$alitmpid=dhtmlspecialchars(trim($alitmpid));
		@include_once DISCUZ_ROOT.'./source/plugin/keke_sms/sendsms.php';
		$kekesmsapi = new kekesmsapi();
		$return= $kekesmsapi->kekesendsms($phone,$alisign,$text,$alitmpid,$keke_group['smschannel']);
	}
	return $return;
}

function _grosms($credit='',$money='',$type='',$name='',$orderuid=''){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	$times=dgmdate($_G['timestamp'], 'Y-m-d H:i');
	$moneys=$money/100;
	$carditname=$_G['setting']['extcredits'][$type]['title'];
	if($keke_group['smsa']){
		$member_profile=C::t('common_member_profile')->fetch($orderuid);
		$phone=trim($member_profile['mobile']);
		if($phone){
			$text=array('time'=>$times,'credit'=>$credit.$carditname,'money'=>$moneys);
			$ret=_sensms($text,$phone,$keke_group['tmpa']);
		}
	}
	if($keke_group['smsb']){
		$adminphone=dhtmlspecialchars(trim($keke_group['adminphone']));
		if($adminphone){
			$admintext=array('time'=>$times,'credit'=>$credit.$carditname,'money'=>$moneys,'name'=>$name);
			$ret=_sensms($admintext,$adminphone,$keke_group['tmpb']);
		}
	}
	return $ret;
}

function _redurl($orderid){
	global $_G;
	$redirect_url=urlencode($_G['siteurl'].'plugin.php?id=keke_group&p=loading&orderid='.$orderid);
	$redirect_urls='&redirect_url='.$redirect_url;
	return $redirect_urls;
}

function editor_safe_replace($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}

function _getqrcodeurl($urls){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	$src = $keke_group['qr']==2?'source/plugin/keke_group/qrcode.php?data='.urlencode($urls):$urls;
	return $src;
}

function _getmycount(){
	global $_G;
	return C::t('#keke_group#keke_group_orderlog')->count_by_all($_G['uid'],1);
}

function _getmylist($startlimit,$ppp){
	global $_G;
	$query = C::t('#keke_group#keke_group_orderlog')->fetch_all_by_all($_G['uid'],1,$startlimit,$ppp);
	foreach($query as $val){
		$validitys=$time='';
		$money=$val['money']/100;
		$time=dgmdate($val['zftime'], 'Y/m/d H:i');
		$validitys=$val['groupinvalid']?dgmdate($val['groupinvalid'], 'Y-m-d H:i'):lang('plugin/keke_group', 'lang07');
		$icoid=$val['type']==1?'z':'w';
		$dates='';
		$groupvalidity=$val['groupvalidity']?$val['groupvalidity'].lang('plugin/keke_group', 'lang09'):lang('plugin/keke_group', 'lang07');
		$pcdate='<b class="sx">|</b><b class="pcdate">'.lang('plugin/keke_group', 'lang08').' :  <i class="yxz">'.$validitys.'</i></b>';
		$validi='<b style="color:#999; font-size:14px;font-weight:500"> / '.$groupvalidity.' </b>';
		if(checkmobile()){
			$dates='<div class="dow dows"><span>'.$groupvalidity.'&nbsp;&nbsp;</span>  '.lang('plugin/keke_group', 'lang08').' / <i class="yxz">'.$validitys.'</i></div>';
			$pcdate=$validi='';
		}
		$list.='<li><div class="pup"><span><img src="source/plugin/keke_group/template/images/'.$icoid.'.png"> '.$money.lang('plugin/keke_group', 'lang03').'</span> '.$val['groupname'].' '.$validi.'</div><div class="dow"><span>'.$time.'</span>'.$val['sn'].$pcdate.'</div>'.$dates.'</li>';
	}
	return $list;
}
function _getmyorder($pages){
		$ppp=30;
		$tmpurl='plugin.php?id=keke_group&p=my';
		$page = max(1, intval($pages));
		$startlimit = ($page - 1) * $ppp;
		$allcount = _getmycount();
		if($allcount){
			$list=_getmylist($startlimit,$ppp);
		}
		$multipage='';
		$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
		$ret['page']=$multipage;
		$ret['list']=$list;
		return $ret;
}
function _instorder($orderid,$money,$zftype,$buygroupid,$groupname,$groupvalidity,$tablegroupid){
	global $_G;
	$orderarr=array(
		'orderid'=>$orderid,
		'uid'=>$_G['uid'],
		'usname'=>$_G['username'],
		'money'=>$money,
		'type'=>$zftype,
		'time'=>$_G['timestamp'],
		'groupid'=>$buygroupid,
		'groupname'=>$groupname,
		'groupvalidity'=>$groupvalidity,
		'tablegroupid'=>$tablegroupid,
	);
	C::t('#keke_group#keke_group_orderlog')->insert($orderarr, true);
}

function groutf2gbk($data){
	$data=dhtmlspecialchars($data);
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	if(CHARSET=='gbk'){
		return $tmpstr;
	}else{
		return grogbk2utf($data);
	}
}

function grogbk2utf($data){
	$data1 = diconv($data,'utf-8','gbk');
	$data0 = diconv($data1,'gbk','utf-8');
	if($data0 == $data){$tmpstr = $data1;}else{$tmpstr = $data;}
	return diconv($tmpstr,'gbk','utf-8');
}