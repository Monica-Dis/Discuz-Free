<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$keke_group = $_G['cache']['plugin']['keke_group'];
header("Content-type:text/html;charset=utf-8");
include_once DISCUZ_ROOT."source/plugin/keke_group/common.php";
include_once DISCUZ_ROOT."source/plugin/keke_group/payjs.php";

$buygroupid=intval($_GET['buygroupid']);
$gorupdata=getbuygroupdata($buygroupid);
$money=floatval($gorupdata['money']/100);
$zftype=intval($_GET['zftype']);
$title= CHARSET=='gbk' ? diconv(lang('plugin/keke_group', 'lang02'), CHARSET, 'UTF-8') : lang('plugin/keke_group', 'lang02');
if(!$_G['uid']){
	$msg=lang('plugin/keke_group', 'lang33');
	$msgs=grogbk2utf($msg);
	if($zftype==1){
		exit( '<script>alert("'.$msgs.'");</script>');
	}else{
		exit( json_encode(array('err' =>$msgs)));
	}
}
$orderid=_orderid();_instorder($orderid,$gorupdata['money'],$zftype,$gorupdata['groupid'],$gorupdata['groupname'],$gorupdata['time'],$buygroupid);
if($zftype==3){
	$_GET['cardid']=trim($_GET['cardid']);
	if(!$keke_group['cardid']){
		exit(json_encode(array('err' => grogbk2utf(lang('plugin/keke_group', 'lang55')))));
	}
	if(!$_GET['cardid']){
		exit(json_encode(array('err' => grogbk2utf(lang('plugin/keke_group', 'lang56')))));
	}
	$cardarr = C::t('common_card')->fetch($_GET['cardid']);
	if(!$cardarr){
		exit(json_encode(array('err' => grogbk2utf(lang('plugin/keke_group', 'lang57')))));
	}else{
		if($cardarr['status'] == 2){
			exit(json_encode(array('err' => grogbk2utf(lang('plugin/keke_group', 'lang58')))));
		}
		if($cardarr['cleardateline'] < TIMESTAMP) {
			exit(json_encode(array('err' => grogbk2utf(lang('plugin/keke_group', 'lang59')))));
		}
	}
	if($cardarr['price']<$money){
		exit(json_encode(array('err' => grogbk2utf(lang('plugin/keke_group', 'lang60')))));
	}
	C::t('common_card')->update($cardarr['id'], array('status' => 2, 'uid' => $_G['uid'], 'useddateline' => TIMESTAMP));
	_upuserdata($orderid,lang('plugin/keke_group', 'lang54').' / '.dhtmlspecialchars($_GET['cardid']));
	$creditname=$_G['setting']['extcredits'][$czcardarr['extcreditskey']]['title'];
	exit(json_encode(array('cardok' => grogbk2utf(lang('plugin/keke_group', 'lang61')))));
}else{
	if(checkmobile() && $zftype==2){
		$data = array(
			'mchid'        => PAYJS_MCHID,
			'body'         => $title,
			'total_fee'    => $money * 100,
			'out_trade_no' => $orderid,
			'notify_url' => trim($_G['siteurl'] . 'source/plugin/keke_group/paylib/notify_payjs.inc.php'),
		);
        $data['sign'] = payjssign($data);
		$url = 'https://payjs.cn/api/cashier?' . http_build_query($data);
		
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
			echo json_encode(array('payjsurl' => $url));
		}else{
			$src = 'source/plugin/keke_group/qrcode.php?data='.urlencode($url);
			echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
		}
		exit;
	}
	$data= array(
		'mchid'        => PAYJS_MCHID,
		'total_fee'    => $money * 100,
		'body' => $title,
		'out_trade_no' => $orderid,
		'ip'           => $_SERVER['REMOTE_ADDR'],
		'notify_url'   => trim($_G['siteurl'] . 'source/plugin/keke_group/paylib/notify_payjs.inc.php'),
	);
	if($zftype==1){
		$data['type'] = 'alipay';
		if($zftype==1){
			$data['type'] = 'alipay';
			if($keke_group['alipaytype']==2){
				include_once DISCUZ_ROOT."source/plugin/keke_group/paylib/alipay.class.php";
				$appid = trim($keke_group['appid']);
				$notifyUrl = trim($_G['siteurl'] . 'source/plugin/keke_group/paylib/notify_alipay.inc.php');
				$outTradeNo = $orderid;
				$payAmount = $money;
				$orderName = $title;
				$signType = 'RSA2';
				$rsaPrivateKey=trim($keke_group['privatekey']);
				$aliPay = new AlipayService();
				$aliPay->setAppid($appid);
				$aliPay->setNotifyUrl($notifyUrl);
				$aliPay->setRsaPrivateKey($rsaPrivateKey);
				$aliPay->setTotalFee($payAmount);
				$aliPay->setOutTradeNo($outTradeNo);
				$aliPay->setOrderName($orderName);
				$result = $aliPay->doPay();
				$result = $result['alipay_trade_precreate_response'];
				if($result['code'] && $result['code']=='10000'){
					$src = 'source/plugin/keke_group/qrcode.php?data='.urlencode($result['qr_code']);
					exit(json_encode(array('ewmurl' => $src,'orderid'=>$orderid)));
				}else{
					exit(json_encode(array('err' => grogbk2utf($result['msg'].' : '.$result['sub_msg']))));
				}
			}
		}
	}
	$data['sign'] = payjssign($data);
	$result = payjshttpPost($data,'https://payjs.cn/api/native');
	$ret=json_decode($result, true);
	
	if($ret['return_msg']!='SUCCESS'){
		exit(json_encode(array('err' => grogbk2utf($ret['return_msg']))));
	}
	
	$src = _getqrcodeurl($ret['code_url']);
	echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
	exit;
}