<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function _buygroup($groupid,$days,$uids){
	global $_G;
	$keke_group = $_G['cache']['plugin']['keke_group'];
	$memberfieldforum = C::t('common_member_field_forum')->fetch($uids);
	$groupterms = dunserialize($memberfieldforum['groupterms']);
	unset($memberfieldforum);
	$extgroupids= $extgroupidsarray = array();	
	$themembers = C::t('common_member')->fetch($uids);
	$extgroupids = $themembers['extgroupids'] ? explode("\t", $themembers['extgroupids']) : array();
	require_once libfile('function/forum');
	foreach(array_unique(array_merge($extgroupids, array($groupid))) as $extgroupid) {
		if($extgroupid) {
			$extgroupidsarray[] = $extgroupid;
		}
	}
	$extgroupidsnew = implode("\t", $extgroupidsarray);
	if($days) {
		$groupterms['ext'][$groupid] = ($groupterms['ext'][$groupid] > TIMESTAMP ? $groupterms['ext'][$groupid] : TIMESTAMP) + $days * 86400;
		$groupexpirynew = groupexpiry($groupterms);
		C::t('common_member')->update($uids, array('groupexpiry' => $groupexpirynew, 'extgroupids' => $extgroupidsnew));
		C::t('common_member_field_forum')->update($uids, array('groupterms' => serialize($groupterms)));
	} else {
		C::t('common_member')->update($uids, array('extgroupids' => $extgroupidsnew));
	}
	if($keke_group['autogroup']){
		$ret['sw']=_switchgroup($groupid,$uids);
	}
	$ret['tims']=$groupterms['ext'][$groupid];
	return $ret;
}
