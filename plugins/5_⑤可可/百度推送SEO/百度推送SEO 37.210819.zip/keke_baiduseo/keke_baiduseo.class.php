<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_keke_baiduseo{
	public function __construct(){
		global $_G;
		$this->keke_baiduseo = $_G['cache']['plugin']['keke_baiduseo'];
		$this->perform=1;
		$this->fid=$_G['fid'];
		$this->section = empty($this->keke_baiduseo['bk']) ? array() : unserialize($this->keke_baiduseo['bk']);
		if(!(empty($this->section[0]) || in_array($this->fid,$this->section))){
			$this->perform=0;
		}
		if(CURSCRIPT=='forum'){
			$this->moda=2;
			$this->atid=$_G['tid'];
		}elseif(CURSCRIPT=='portal'){
			$this->moda=1;
			$this->atid=intval($_GET['aid']);
		}
		if(($this->moda==2 && ((!$_G['thread']['isgroup'] && $this->perform)||($_G['thread']['isgroup'] && $this->keke_baiduseo['qz']))) || ($this->moda==1 && $this->keke_baiduseo['wz'])){
			$this->postdata=C::t('#keke_baiduseo#keke_baiduseo')->fetchfirst_byatid($this->atid,$this->moda);
		}
		$this->backtime=strtotime($this->keke_baiduseo['time']);
	}
	function global_header(){
		$var = $this->keke_baiduseo;
		$returns='';
		if($var['auto'] && $_GET['mod']!='spacecp' && $_GET['mod']!='portalcp'){                                  
			include template('keke_baiduseo:inc');
		}
		return $returns;
	}
	
	
	function _getsitehost(){
		$sisturlarr=explode(":",$_SERVER['HTTP_HOST']);
		return $sisturlarr[0];
	}
	
	function _postbaidu($atid,$type,$mod,$subject){
		global $_G;
		$var =  $this->keke_baiduseo;
		date_default_timezone_set('Asia/Chongqing');
		if(!$var['site'] || !$var['token']){
			return '';
		}
		$_GET['page']=$_GET['page']?intval($_GET['page']):1;
        $urla='';
		if($mod==1){
			$urla='portal.php?mod=view&aid='.$atid;
			if(in_array('portal_article', $_G['setting']['rewritestatus'])){
				$urla=rewriteoutput('portal_article', 1, '', $atid,$_GET['page']);
			}
		}elseif($mod==2){
			$urla='forum.php?mod=viewthread&tid='.$atid;
			if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])){
				$urla=rewriteoutput('forum_viewthread', 1, '', $atid,$_GET['page']);
			}
		}
		$sys_protocal = $this->check_is_https() ? 'https://' : 'http://';
		$siteurls=$var['site'];
		$tuiurl=$sys_protocal.$var['site'].'/'.$urla;
		$urls = array(
			$tuiurl
		);
		if($type==2){
			$typename='update';
		}else{
			$typename='urls';
		}
		$uri = 'http://data.zz.baidu.com/'.$typename.'?site='.$siteurls.'&token='.$var['token'];
		$ch = curl_init();
		$options =  array(
			CURLOPT_URL => $uri,
			CURLOPT_POST => true,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_POSTFIELDS => implode("\n", $urls),
			CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
		);
		curl_setopt_array($ch, $options);
		$result = curl_exec($ch);
		
		$ret=json_decode($result, true);
		if($ret['error']){
			$state=intval($ret['error']);
			$msg=daddslashes($ret['message']);
		}else{
			if($ret['success'] || $ret['success_original']){
				$state=1;
			}else{
				if($ret['not_same_site']){
					$state=2;
					$msg='not_same_site';
				}
				if($ret['not_valid']){
					$state=3;
					$msg='not_valid';
				}
			}
		}
		$arr=array(
			'subject'=> daddslashes(dhtmlspecialchars($subject)),
			'url'=>implode("\n", $urls),
			'state'=>$state,
			'msg'=>$msg,
			'time'=>TIMESTAMP,
			'type'=>intval($type),
			'mods'=>intval($mod),
			'atid'=>intval($atid)
		);
		C::t('#keke_baiduseo#keke_baiduseo')->insert($arr);
		return $result;
	}
	
	function check_is_https() {
		global $_G;
		$ishttps=($_SERVER['SERVER_PORT'] == 443 || $_SERVER['HTTPS'] && strtolower($_SERVER['HTTPS']) != 'off') ? true : false;
		if(strpos($_G['siteurl'], 'https://') !== false){
			$ishttps=true;
		}
		return $ishttps;
	}
}


class plugin_keke_baiduseo_forum extends plugin_keke_baiduseo{
	function post_message($param) {
		global $_G;
		$var =  $this->keke_baiduseo;
		$param = $param['param'];
		$subject=dhtmlspecialchars($_GET['subject']);
		$section = unserialize($var['bk']);
		if(in_array($_G['fid'],$section)){
			$tid = intval($param[2]['tid']);
			if($param[0]=="post_edit_succeed" && $var['gengxin']){
				$this->_postbaidu($tid,2,2,$subject);
			}
		}
	}
	
	function viewthread_posttop(){
		global $_G;
		$dateline=$_G['thread']['dateline'];
		$isgroup=$_G['thread']['isgroup'];
		$ret=array();
		if($_G['thread']['displayorder']>=0){
			if(!($this->postdata) && $dateline>$this->backtime && (($isgroup && $this->keke_baiduseo['qz']) || (!$isgroup && $this->perform))){
				if($this->keke_baiduseo['first'] && $_GET['page']>=2){
					return $ret;
				}
				$this->_postbaidu($this->atid,1,2,$_G['thread']['subject']);
			}
		}
		return $ret;
	}
}

class plugin_keke_baiduseo_portal extends plugin_keke_baiduseo{
	function view_article_content(){
		$var =  $this->keke_baiduseo;
		$ret='';
		$article = C::t('portal_article_title')->fetch($this->atid);
		$dateline=$article['dateline'];
		if(!($this->postdata) && $dateline>$this->backtime && $var['wz']){
			$this->_postbaidu($this->atid,1,1,$article['title']);
		}
		return $ret;
	}
	
}
class plugin_keke_baiduseo_group extends plugin_keke_baiduseo_forum{
}
class mobileplugin_keke_baiduseo_group extends plugin_keke_baiduseo_forum{
}
class mobileplugin_keke_baiduseo_forum extends plugin_keke_baiduseo_forum{
}
class mobileplugin_keke_baiduseo_portal extends plugin_keke_baiduseo_portal{
}