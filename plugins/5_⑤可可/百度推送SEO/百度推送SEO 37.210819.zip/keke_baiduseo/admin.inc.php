<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
    global $_G;
	loadcache('plugin');
	date_default_timezone_set('Asia/Chongqing');
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
			C::t('#keke_baiduseo#keke_baiduseo')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/keke_baiduseo', '013'), 'action=plugins&operation=config&do=' . $plugin["pluginid"] . '&identifier=keke_baiduseo&pmod=admin', 'succeed');
	}
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");	
	showtableheader(lang('plugin/keke_baiduseo', '001'));
    showsubtitle(array(lang('plugin/keke_baiduseo', '014'),lang('plugin/keke_baiduseo', '015'),lang('plugin/keke_baiduseo', '016'),lang('plugin/keke_baiduseo', '017'), lang('plugin/keke_baiduseo', '019'),lang('plugin/keke_baiduseo', '020')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_baiduseo&pmod=admin';
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$count = C::t('#keke_baiduseo#keke_baiduseo')->count_all();
	if($count){
		$liatdata = C::t('#keke_baiduseo#keke_baiduseo')->fetch_all_by_limit($startlimit,$ppp);
		foreach($liatdata as $key=>$val){
			$type=$state='';
			switch ($val['type']) {
				case 1:$type=$val['mods']==2 ? lang('plugin/keke_baiduseo', '006') :lang('plugin/keke_baiduseo', '021');break;
				case 2:$type=lang('plugin/keke_baiduseo', '007');break;
				case 3:$type=lang('plugin/keke_baiduseo', '008');break;
			}
			switch ($val['state']) {
				case 1:$state=lang('plugin/keke_baiduseo', '009');break;
				case 2:$state=lang('plugin/keke_baiduseo', '012').lang('plugin/keke_baiduseo', '010');break;
				case 3:$state=lang('plugin/keke_baiduseo', '011');break;
				case 4:$state=lang('plugin/keke_baiduseo', '012').lang('plugin/keke_baiduseo', '022');break;
				default:$state=lang('plugin/keke_baiduseo', '012').$val['msg'];
			}
			$yuanc=$val['yuanc']? lang('plugin/keke_baiduseo', '023'):lang('plugin/keke_baiduseo', '024');
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = '<a href="'.$val['url'].'" target="_blank">'.$val['subject'].'</a>';
			$table[2] = '<a href="'.$val['url'].'" target="_blank">'.$val['url'].'</a>';
			$table[3] = $type;
			$table[4] = $state;
			$table[5] = dgmdate($val['time'], 'Y/m/d H:i:s');
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($count, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter();
	showformfooter();