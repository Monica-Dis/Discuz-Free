<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G;
loadcache('plugin');
$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
header("Content-type:text/html;charset=utf-8");
if(!$_G['uid']){
	exit('Access Denied');
}
if($_GET['formhash'] != $_G['formhash']) {
	exit('Formhash Error');
}
include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/common.php";
include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/payjs.php";

loadcache('keke_chongzhi_credit');
$creditdata=$_G['cache']['keke_chongzhi_credit'] ? $_G['cache']['keke_chongzhi_credit'] : C::t('#keke_chongzhi#keke_chongzhi_credit')->fetchall_credit();
$zftype=intval($_GET['zftype']);
$credittype=intval($_GET['credittype']);
$moneyQuantity=floatval($_GET['moneyQuantity']);
$credit=intval($moneyQuantity*$creditdata[$credittype]['bili']);
$money=$moneyQuantity*100;
$retarr=_getcreditgive($credittype);
if($retarr[strval($moneyQuantity)]){
	$credit=$credit+$retarr[strval($moneyQuantity)];
}
$title= czgbk2utf(lang('plugin/keke_chongzhi', 'lang01'));

if($zftype==3){
	$_GET['cardid']=trim($_GET['cardid']);
	if(!$keke_chongzhi['cardid']){
		exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang52')))));
	}
	if(!$_GET['cardid']){
		exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang47')))));
	}
	if($keke_chongzhi['cardnum']){
		$todaycount=C::t('#keke_chongzhi#keke_chongzhi_card')->countall_today($_G['uid']);
		if($todaycount>=$keke_chongzhi['cardnum']){
			exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang57').$keke_chongzhi['cardnum'].lang('plugin/keke_chongzhi','lang58')))));
		}
	}
	$czcardarr = C::t('common_card')->fetch($_GET['cardid']);
	if(!$czcardarr){
		exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang48')))));
	}else{
		if($czcardarr['status'] == 2){
			exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang49')))));
		}
		if($czcardarr['cleardateline'] < TIMESTAMP) {
			exit(json_encode(array('err' => compelutf(lang('plugin/keke_chongzhi', 'lang50')))));
		}
	}
	$money=$czcardarr['price']*100;
	$credittype=$czcardarr['extcreditskey'];
	$credit=$czcardarr['extcreditsval'];
}else{
	if(($keke_chongzhi['zuidi']>$moneyQuantity)){
		$msg=lang('plugin/keke_chongzhi', 'lang02').floatval($keke_chongzhi['zuidi']).lang('plugin/keke_chongzhi', 'lang03');
		$msgs=diconv($msg, CHARSET,'utf-8');
		if($zftype==1){
			echo '<script>alert("'.$msg.'");window.history.go(-1);</script>';
		}else{
			echo json_encode(array('err' =>$msgs));
		}
		exit();
	}
}

$orderid=_orderid();_instorder($orderid,$money,$zftype,$credit,$credittype);

if($zftype==3){
	C::t('common_card')->update($czcardarr['id'], array('status' => 2, 'uid' => $_G['uid'], 'useddateline' => TIMESTAMP));
	_upuserdata($orderid,lang('plugin/keke_chongzhi', 'lang53').$_GET['cardid']);
	$creditname=$_G['setting']['extcredits'][$czcardarr['extcreditskey']]['title'];
	exit(json_encode(array('cardok' => compelutf(lang('plugin/keke_chongzhi', 'lang51').$czcardarr['extcreditsval'].$creditname))));
}else{
	if(checkmobile() && $zftype==2){
		$data = array(
			'mchid'        => PAYJS_MCHID,
			'body'         => $title,
			'total_fee'    => $money,
			'out_trade_no' => $orderid,
			'notify_url' => trim($_G['siteurl'] . 'source/plugin/keke_chongzhi/paylib/notify_payjs.inc.php'),
		);
        $data['sign'] = payjssign($data);
		$url = 'https://payjs.cn/api/cashier?' . http_build_query($data);
		if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){
			echo json_encode(array('payjsurl' => $url));
		}else{
			$src = 'source/plugin/keke_chongzhi/qrcode.php?data='.urlencode($url);
			echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
		}
		exit;
	}
	$data= array(
		'mchid'        => PAYJS_MCHID,
		'total_fee'    => $money,
		'body' => $title,
		'out_trade_no' => $orderid,
		'ip'           => $_SERVER['REMOTE_ADDR'],
		'notify_url'   => trim($_G['siteurl'] . 'source/plugin/keke_chongzhi/paylib/notify_payjs.inc.php'),
	);
	if($zftype==1){
		$data['type'] = 'alipay';
		if($keke_chongzhi['alipaytype']==2){
			include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/paylib/alipay.class.php";
			$appid = trim($keke_chongzhi['appid']);
			$notifyUrl = trim($_G['siteurl'] . 'source/plugin/keke_chongzhi/paylib/notify_alipay.inc.php');
			$outTradeNo = $orderid;
			$payAmount = $moneyQuantity;
			$orderName = $title;
			$signType = 'RSA2';
			$rsaPrivateKey=trim($keke_chongzhi['privatekey']);
			$aliPay = new AlipayService();
			$aliPay->setAppid($appid);
			$aliPay->setNotifyUrl($notifyUrl);
			$aliPay->setRsaPrivateKey($rsaPrivateKey);
			$aliPay->setTotalFee($payAmount);
			$aliPay->setOutTradeNo($outTradeNo);
			$aliPay->setOrderName($orderName);
			$result = $aliPay->doPay();
			$result = $result['alipay_trade_precreate_response'];
			if($result['code'] && $result['code']=='10000'){
				$src = 'source/plugin/keke_chongzhi/qrcode.php?data='.urlencode($result['qr_code']);
				exit(json_encode(array('ewmurl' => $src,'orderid'=>$orderid)));
			}else{
				exit(json_encode(array('err' => czgbk2utf($result['msg'].' : '.$result['sub_msg']))));
			}
		}
		
	}
	$data['sign'] = payjssign($data);
	$result = payjshttpPost($data,'https://payjs.cn/api/native');
	$ret=json_decode($result, true);

	
	if($ret['return_msg']!='SUCCESS'){
		exit(json_encode(array('err' => czgbk2utf($ret['return_msg']))));
	}
	
	$src = 'source/plugin/keke_chongzhi/qrcode.php?data='.urlencode($ret['code_url']);
	echo json_encode(array('ewmurl' => $src,'orderid'=>$orderid));
	exit;
}