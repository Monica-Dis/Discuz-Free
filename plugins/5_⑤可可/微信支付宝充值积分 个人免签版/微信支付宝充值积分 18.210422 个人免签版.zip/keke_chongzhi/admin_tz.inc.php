<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	$table = array();
	showtips(lang('plugin/keke_chongzhi', 'lang33'));
    showtableheader(lang('plugin/keke_chongzhi', 'lang35'));	
    showsubtitle(array(lang('plugin/keke_chongzhi', 'lang36'),'', lang('plugin/keke_chongzhi', 'lang37'), lang('plugin/keke_chongzhi', 'lang38')));
	$wap=file_exists("source/plugin/keke_sms/sendsms.php")? '<span class="diffcolor2">'.lang('plugin/keke_chongzhi', 'lang39').'</span>' : '<a href="https://dism.taobao.com/?@keke_sms.plugin"><span class="error">'.lang('plugin/keke_chongzhi', 'lang40').'</span></a>';
	$table[0] = '<img src="source/plugin/keke_chongzhi/template/images/keke_sms.png" width="40" height="40" />';
	$table[1] = lang('plugin/keke_chongzhi', 'lang42');
	$table[2] = '<span class="light tips2">'.lang('plugin/keke_chongzhi', 'lang41').'</span>';
	$table[3] = $wap;
	showtablerow('', array('width="80"','width="180"', 'width="600"'), $table);
    showtablefooter(); /*dism��taobao��com*/
