<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();
loadcache('plugin');
require_once DISCUZ_ROOT."source/plugin/keke_chongzhi/payjs.php";
require_once DISCUZ_ROOT."source/plugin/keke_chongzhi/common.php";	

payjscheckSign($_POST);
_upuserdata($_GET['out_trade_no'],$_GET['payjs_order_id'],$_GET['openid']);
echo 'success';