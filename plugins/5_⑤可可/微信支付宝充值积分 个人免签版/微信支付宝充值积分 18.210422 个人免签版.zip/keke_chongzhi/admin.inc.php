<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
	include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/common.php";
	if (submitcheck("forumset")) {
		C::t('#keke_chongzhi#keke_chongzhi_orderlog')->del_oder();
		cpmsg(lang('plugin/keke_chongzhi', 'lang07'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_chongzhi&pmod=admin', 'succeed');
	}
    
	
	showtableheader(lang('plugin/keke_chongzhi', 'lang59'));
	showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");
	showtablerow('', array('width="60"', 'width="100"', 'width="60"','width="180"','width="60"','width="180"','width="70"','width="280"'),
		array(
			'<b>'.lang('plugin/keke_chongzhi', 'lang16').'</b>',
			'<select name="state"><option value="0">'.lang('plugin/keke_chongzhi', 'lang60').'</option><option value="9">'.lang('plugin/keke_chongzhi', 'lang21').'</option><option value="1">'.lang('plugin/keke_chongzhi', 'lang20').'</option></select>',
			'<b>'.lang('plugin/keke_chongzhi', 'lang11').'</b>',
			'<input name="orderid" value="'.dhtmlspecialchars($_GET['orderid']).'" type="text" />',
			'<b>'.lang('plugin/keke_chongzhi', 'lang12').'</b>',
			'<input name="username" value="'.dhtmlspecialchars($_GET['username']).'" type="text" />',
			
			'<b>'.lang('plugin/keke_chongzhi', 'lang18').'</b>',
			'<input name="time" type="text" value="'.dhtmlspecialchars($_GET['time']).'" onclick="showcalendar(event, this)" size="15"/> - <input name="endtime" type="text" onclick="showcalendar(event, this)" size="15" value="'.dhtmlspecialchars($_GET['endtime']).'"/>',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_chongzhi', 'lang05').'">&nbsp;&nbsp;&nbsp;<input type="submit" class="btn" id="forumset" name="forumset" value="'.lang('plugin/keke_chongzhi', 'lang09').'"><script src="static/js/calendar.js"></script>'
		)
	);
	
	$where=$param='';
	if($_GET['orderid']){
		$where.=" AND orderid='".daddslashes(dhtmlspecialchars($_GET['orderid'])).'\'';
		$param.='&orderid='.dhtmlspecialchars($_GET['orderid']);
	}
	if($_GET['state']){
		if($_GET['state']==9)$_GET['state']=0;
		$where.=" AND state=".intval($_GET['state']);
		$param.='&state='.intval($_GET['state']);
	}
	if($_GET['username']){
		$where.=" AND usname='".daddslashes(dhtmlspecialchars($_GET['username'])).'\'';
		$param.='&username='.dhtmlspecialchars($_GET['username']);
		
	}
	if($_GET['time']){
		$where.=" AND time>".strtotime($_GET['time']);
		$param.='&time='.dhtmlspecialchars($_GET['time']);
	}
	if($_GET['endtime']){
		$where.=" AND time<".strtotime($_GET['endtime']);
		$param.='&endtime='.dhtmlspecialchars($_GET['endtime']);
	}
  
	showtableheader(lang('plugin/keke_chongzhi', 'lang10'));
    showsubtitle(array(lang('plugin/keke_chongzhi', 'lang11'),lang('plugin/keke_chongzhi', 'lang12'), lang('plugin/keke_chongzhi', 'lang13'), lang('plugin/keke_chongzhi', 'lang14'),lang('plugin/keke_chongzhi', 'lang15'),lang('plugin/keke_chongzhi', 'lang16'),lang('plugin/keke_chongzhi', 'lang17'),lang('plugin/keke_chongzhi', 'lang18'),lang('plugin/keke_chongzhi', 'lang19')));
	$creditdata=$_G['cache']['keke_chongzhi_credit'] ? $_G['cache']['keke_chongzhi_credit'] : C::t('#keke_chongzhi#keke_chongzhi_credit')->fetchall_credit();
	$ppp=$keke_chongzhi['pgt'] ? intval($keke_chongzhi['pgt']) : 2;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_chongzhi&pmod=admin'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	$uid=1;
	$allcount = C::t('#keke_chongzhi#keke_chongzhi_orderlog')->count_by_all('','',$where);
	if($allcount){
		$query = C::t('#keke_chongzhi#keke_chongzhi_orderlog')->fetch_all_by_all(0,0,$startlimit,$ppp,$where);
		foreach($query as $val){
			$money=$val['money']/100;
			$time=dgmdate($val['zftime'], 'Y/m/d H:i');
			$cradit='<font color="#c30"><b>'.intval($val['credit']).'</b></font> '.$_G['setting']['extcredits'][$val['credittype']]['title'];
			$stat=$val['state'] ? '<font color="#33CC33">'.lang('plugin/keke_chongzhi', 'lang20').'</font>' : '<font color="#c30">'.lang('plugin/keke_chongzhi', 'lang21').'</font>' ;
			$type=$val['type']==1 ? lang('plugin/keke_chongzhi', 'lang22') : ($val['type']==2?lang('plugin/keke_chongzhi', 'lang23'):lang('plugin/keke_chongzhi', 'lang54')) ;
			$table = array();
			$table[0] = $val['orderid'];
			$table[1] = $val['usname'];
			$table[2] = $cradit;
			$table[3] = $money.' '.lang('plugin/keke_chongzhi', 'lang03');
			$table[4] = $type;
			$table[5] = $stat;
			$table[6] = $val['sn'] ? $val['sn'] : '<font color="#CCCCCC">--</font>';
			$table[7] = dgmdate($val['time'], 'Y/m/d H:i');
			$table[8] = $val['zftime'] ? dgmdate($val['zftime'], 'Y/m/d H:i') : '<font color="#CCCCCC">--</font>';
			showtablerow('',array(), $table);
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dism _ taobao _ com*/
