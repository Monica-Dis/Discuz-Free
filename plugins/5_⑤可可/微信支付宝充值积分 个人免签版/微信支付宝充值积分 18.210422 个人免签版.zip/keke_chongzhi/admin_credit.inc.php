<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	global $_G;
	loadcache('plugin');
	$keke_chongzhi = $_G['cache']['plugin']['keke_chongzhi'];
	include_once DISCUZ_ROOT."source/plugin/keke_chongzhi/common.php";
	if (submitcheck("forumset")) {
		$data = daddslashes($_GET['form']);
		if($data) {
			foreach($data as $creditid => $val) {
				if($data[$creditid]){
					C::t('#keke_chongzhi#keke_chongzhi_credit')->insert(array('creditid' => $creditid,'bili' => $val['bili'],'state' => $val['state'],'shunxu' => $val['shunxu'],'give' => $val['give']), false, true);
				}
			}
		}
		require_once libfile('function/cache');
		savecache('keke_chongzhi_credit', $data);
		cpmsg(lang('plugin/keke_chongzhi', 'lang27'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_chongzhi&pmod=admin_credit', 'succeed');
	}
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin_credit");
	showtips(lang('plugin/keke_chongzhi', 'lang46'));
    showtableheader(lang('plugin/keke_chongzhi', 'lang28'));
    showsubtitle(array(lang('plugin/keke_chongzhi', 'lang29'),lang('plugin/keke_chongzhi', 'lang30'),lang('plugin/keke_chongzhi', 'lang45'),lang('plugin/keke_chongzhi', 'lang31'),lang('plugin/keke_chongzhi', 'lang32')));
	loadcache('keke_chongzhi_credit');
	$creditdata=$_G['cache']['keke_chongzhi_credit'] ? $_G['cache']['keke_chongzhi_credit'] : C::t('#keke_chongzhi#keke_chongzhi_credit')->fetchall_credit();	
	foreach($_G['setting']['extcredits'] as $k=>$v){
		$checke= $creditdata[$k]['state'] ? 'checked="checked"' : '';
		$table = array();
        $table[0] = $v['title'].'<input name="form['.$k.'][creditid]" type="hidden" value="'.$k.'" />';
        $table[1] = '1'.lang('plugin/keke_chongzhi', 'lang03').'= <input name="form['.$k.'][bili]" value="'.dhtmlspecialchars($creditdata[$k]['bili']).'" style="width:50px"> '.$v['title'];
		$table[2] = '<input name="form['.$k.'][give]" value="'.dhtmlspecialchars($creditdata[$k]['give']).'" style="width:300px"> ';
		$table[3] = '<input class="checkbox" type="checkbox" name="form['.$k.'][state]" '.$checke.'  value="1">';
		$table[4] = '<input name="form['.$k.'][shunxu]" value="'.dhtmlspecialchars($creditdata[$k]['shunxu']).'" style="width:50px"> ';
        showtablerow('',array('width="200"', 'width="250"','width="400"'), $table);
	}
	
    showsubmit('forumset', 'submit', '', '');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*dism _ taobao _ com*/
