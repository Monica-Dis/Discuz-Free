<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!应用中心 dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}




include_once DISCUZ_ROOT."source/plugin/keke_answer/identity.inc.php";


function _getansarr_bytid($tid){
	return DB::fetch_first("select * from ".DB::table('keke_answer')." where tid=".intval($tid));
}

function ans_editor_safe_replaces($content){
    $tags = array(
        "'<iframe[^>]*?>.*?</iframe>'is",
        "'<frame[^>]*?>.*?</frame>'is",
        "'<script[^>]*?>.*?</script>'is",
        "'<head[^>]*?>.*?</head>'is",
        "'<title[^>]*?>.*?</title>'is",
        "'<meta[^>]*?>'is",
        "'<link[^>]*?>'is",
    );
    return preg_replace($tags, "", $content);
}

function getusn($uid){
	return DB::result_first("select username from ".DB::table('common_member')." where uid=".$uid);
}

function zjdabytid($tid){
    $tdata=DB::result_first("select posttableid from ".DB::table('forum_thread')." where tid=".$tid);
    $table=$tdata?'forum_post_'.$tdata:'forum_post';
    $answerData=DB::fetch_first("select pid from ".DB::table('keke_answer')." where tid=".$tid);
    if($answerData['pid']){
        $postData=DB::fetch_first("SELECT message,authorid,dateline,pid FROM ".DB::table($table)." WHERE pid=".$answerData['pid']);
        return $postData;
    }
    return false;
}

function _cutstr($msg){
	global $_G;
	$keke_answer = $_G['cache']['plugin']['keke_answer'];	
	$message=dhtmlspecialchars($msg);
	require_once libfile('function/post');
	$jq=checkmobile()?$keke_answer['jqa']:$keke_answer['jq'];
	$message=messagecutstr($message,intval($jq));
	return $message;
}
function _instdate($param=array(),$credit_num){
	global $_G;
	$param = $param['param'];
	$keke_answer = $_G['cache']['plugin']['keke_answer'];
	$tid = intval($param[2]['tid']);
	$pid = intval($param[2]['pid']);
	if($param[0]=="post_newthread_succeed" || $param[0]=="post_newthread_mod_succeed"){
		  DB::query("insert into ".DB::table('keke_answer')."(uid , tid , credit_type , credit_num , time) values ('".$_G['uid']."' , '".$tid."' , '".$keke_answer['yhxs']."' , '".$credit_num."' , '".$_G['timestamp']."')");
		  updatemembercount($_G['uid'], array('extcredits'.$keke_answer['yhxs']=>-$credit_num), true, '', 0, '',lang('plugin/keke_answer', 'f011'),lang('plugin/keke_answer', 'f012').' , <a href="forum.php?mod=viewthread&tid='.$tid.'">'.lang('plugin/keke_answer', 'f005').'</a>');
		  if($keke_answer['sxf']){
			  $sxfs=round(($keke_answer['sxf']/100)*$credit_num);
			  updatemembercount($_G['uid'], array('extcredits'.$keke_answer['yhxs']=>-$sxfs), true, '', 0, '',lang('plugin/keke_answer', 'f011'),lang('plugin/keke_answer', 'f016').', <a href="forum.php?mod=viewthread&tid='.$tid.'">'.lang('plugin/keke_answer', 'f005').'</a>');
		  }
	}elseif($param[0]=="post_edit_succeed"){
		  $ansarr=_getansarr_bytid($tid);
		  $postdatas=_getpostdata($tid,$pid);
		  if(!$postdatas['first']){
		  	return; 
		  }
		  $nowpr=$ansarr['credit_num'];
		  $credit_nums=$credit_num-$nowpr;
		  if($credit_nums>0){
			  updatemembercount($_G['uid'], array('extcredits'.$keke_answer['yhxs']=>-$credit_nums), true, '', 0, '',lang('plugin/keke_answer', 'f011'),lang('plugin/keke_answer', 'f013').'，<a href="forum.php?mod=viewthread&tid='.$tid.'">'.lang('plugin/keke_answer', 'f005').'</a>');
			  $sxfss=round(($keke_answer['sxf']/100)*$credit_nums);
			  updatemembercount($_G['uid'], array('extcredits'.$keke_answer['yhxs']=>-$sxfss), true, '', 0, '',lang('plugin/keke_answer', 'f019'),lang('plugin/keke_answer', 'f020').', <a href="forum.php?mod=viewthread&tid='.$tid.'">'.lang('plugin/keke_answer', 'f005').'</a>');
		  }
		  if(!$ansarr){
			  _updataans($ansarr,$tid);
		  }
		  DB::query("update ".DB::table('keke_answer')." set credit_type=".$keke_answer['yhxs'].",credit_num=".$credit_num." where tid=".$tid);
	}
}

function _sevrset($data){
	require_once libfile('function/cache');
	savecache('keke_answer', $data);
	if(DB::result_first("select val from ".DB::table('keke_answer_set'))){
		DB::query("update ".DB::table('keke_answer_set')." set val='".$data."'");
	}else{
		$data = array('val' => $data);
		DB::insert('keke_answer_set', $data,true,true);
	}
}

function _getpostdata($tid,$pid){
	$tdata=DB::result_first("select posttableid from ".DB::table('forum_thread')." where tid=".$tid);
	if($tdata){$table='forum_post_'.$tdata;} else {$table='forum_post';}
	$postdata=DB::fetch_first("select authorid,tid,fid,first from ".DB::table($table)." where pid=".$pid);
	return $postdata;
}

function _updataans($ansarr,$tid,$pid=0){
	global $_G;
	if($ansarr){
		DB::query("update ".DB::table('keke_answer')." set pid=".$pid." where tid=".$tid);
	}else{
		DB::query("insert into ".DB::table('keke_answer')."(uid , tid , pid, time) values ('".$_G['uid']."' , '".$tid."' ,'".$pid."' , '".$_G['timestamp']."')");
	}
	return;
}

function _getanslistarr($threadlist){
	foreach ($threadlist as $v) {if (is_numeric($v['tid'])) $tidlist .= $v['tid'].',';}
	if ($tidlist){$tidlist = substr($tidlist, 0, -1);}else{
		return array();
	}
	$ansdata=DB::fetch_all("select * from ".DB::table('keke_answer')." where tid in (".$tidlist.")");
	foreach($ansdata as $ks=>$vs){
		$ansarr[$vs['tid']]=$vs;
	}
	return $ansarr;
}

function _getansset(){
	global $_G;
	loadcache('keke_answer');
	$info=$_G['cache']['keke_answer']?$_G['cache']['keke_answer']:DB::result_first("select val from ".DB::table('keke_answer_set'));
	$info=unserialize($info);
	return $info;
}