<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_answer = $_G['cache']['plugin']['keke_answer'];
if($_GET['formhash']!=FORMHASH)return;
$pid=intval($_GET['pid']);
$tid=intval($_GET['tid']);
if(!$_G['uid']){
    showmessage('not_loggedin', NULL, array(), array('login' => 1));
}



include_once DISCUZ_ROOT . './source/plugin/keke_answer/function.php';
$pid=intval($_GET['pid']);
$tid=intval($_GET['tid']);
$time=$_G['timestamp'];
$ansarr=_getansarr_bytid($tid);
if(submitcheck('sub')){
	global $_G;
	$keke_answer = $_G['cache']['plugin']['keke_answer'];
	if($ansarr['pid']){
		showmessage(lang('plugin/keke_beiz', lang('plugin/keke_answer', 'cfcn')),'forum.php?mod=viewthread&tid='.$tid);
	}
	
	$authorid=DB::result_first("select authorid from ".DB::table('forum_thread')." where tid=".$tid);
	$mastgroup=unserialize($keke_answer['glz']);
	if(!($_G['uid']==$authorid) && !(in_array($_G['groupid'],$mastgroup)))return;
	$jiangli=intval($keke_answer['jlsl']);
	$postdata=_getpostdata($tid,$pid);
	if($postdata['authorid']==$_G['uid'] && !(in_array($_G['groupid'],$mastgroup))){showmessage(lang('plugin/keke_answer', 'bncnzj'));}
	if(!($postdata['tid']==$tid))return;//20160704
	_updataans($ansarr,$tid,$pid);
	loadcache('keke_answer');
	$info=$_G['cache']['keke_answer']?$_G['cache']['keke_answer']:DB::result_first("select val from ".DB::table('keke_answer_set'));
	$info=unserialize($info);
	if($info[$postdata['fid']] && $keke_answer['gl']){
		DB::query("update ".DB::table('forum_thread')." set typeid=".intval($info[$postdata['fid']]['message'])." where tid=".$tid);
	}
	if($ansarr['credit_num'] && $keke_answer['yhxson']){
		updatemembercount($postdata['authorid'], array('extcredits'.$ansarr['credit_type'].''=>$ansarr['credit_num']), true, '', 0, '',lang('plugin/keke_answer', 'zjda'),lang('plugin/keke_answer', 'f001').' , '.lang('plugin/keke_answer', 'f002').'��<a href="forum.php?mod=viewthread&tid='.$tid.'">'.lang('plugin/keke_answer', 'f005').'</a>');
	}
	if($keke_answer['xtxson']){
		updatemembercount($postdata['authorid'], array('extcredits'.$keke_answer['jflx'].''=>$jiangli), true, '', 0, '',lang('plugin/keke_answer', 'zjda'),lang('plugin/keke_answer', 'f001').' , '.lang('plugin/keke_answer', 'f003').'��<a href="forum.php?mod=viewthread&tid='.$tid.'">'.lang('plugin/keke_answer', 'f005').'</a>');
	}
	$subject=DB::result_first("select subject from ".DB::table('forum_thread')." where tid=".$tid);
	notification_add($postdata['authorid'],'system',lang('plugin/keke_answer', 'ybcn').'&nbsp;&nbsp;<a href="forum.php?mod=viewthread&tid='.$tid.'" target="_blank">'.lang('plugin/keke_answer', 'f017').$subject.lang('plugin/keke_answer', 'f018').'</a>');
	showmessage(lang('plugin/keke_beiz', lang('plugin/keke_answer', 'cncg')),'forum.php?mod=viewthread&tid='.$tid);
}elseif($_GET['ac']=='del'){
	$jiangli=intval($keke_answer['jlsl']);
	$mastgroup=unserialize($keke_answer['glz']);
	if(!($_G['uid']==$authorid) && !(in_array($_G['groupid'],$mastgroup)))return;
	$postdata=_getpostdata($tid,$pid);
	DB::query("update ".DB::table('keke_answer')." set pid='0' where tid=".$tid);
	if($ansarr['credit_num']){
		updatemembercount($postdata['authorid'], array('extcredits'.$ansarr['credit_type'].''=>'-'.$ansarr['credit_num']), true, '', 0, '',lang('plugin/keke_answer', 'zjda'),lang('plugin/keke_answer', 'glydel'));
	}
	updatemembercount($postdata['authorid'], array('extcredits'.$keke_answer['jflx'].''=>'-'.$jiangli), true, '', 0, '',lang('plugin/keke_answer', 'zjda'),lang('plugin/keke_answer', 'glydel'));
	showmessage(lang('plugin/keke_answer', 'delscc'),'forum.php?mod=viewthread&tid='.$tid);
}else{
	$jfname=$keke_answer['xtxson']?" <font color='#CC3300'>".intval($keke_answer['jlsl']).$_G['setting']['extcredits'][$keke_answer['jflx']]['title']."</font> ":'';
	if($ansarr['credit_num'] && $keke_answer['yhxson']){
		$yhxs=" <font color='#CC3300'>".$ansarr['credit_num'].$_G['setting']['extcredits'][$ansarr['credit_type']]['title']."</font> ";
	}
	$tswz=ans_editor_safe_replaces($keke_answer['tis']);
	$tswz=str_ireplace("[sysrew]",$jfname,$tswz);
	$tswz=str_ireplace("[userrew]",$yhxs,$tswz);
	include template('keke_answer:tis');
}