<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


class plugin_keke_answer{

}

class plugin_keke_answer_forum {
	function viewthread_postbottom_output(){
		global $_G, $postlist;
		$keke_answer = $_G['cache']['plugin']['keke_answer'];	
		
		$section = empty($keke_answer['bk']) ? array() : unserialize($keke_answer['bk']);
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){
			return array();
		}
		include_once DISCUZ_ROOT . './source/plugin/keke_answer/function.php';
		$ansarr=_getansarr_bytid(intval($_G['tid']));
		if(!$ansarr['tid']){
			return array();
		}
		$postcount=$_G['thread']['replies'];
		$jiangli=intval($keke_answer['jlsl']);
		$creditname=$_G['setting']['extcredits'][$keke_answer['jflx']]['title'];
		$iszjhd = zjdabytid($_G['tid']);
		$mastgroup=unserialize($keke_answer['glz']);
		$ismast=1;
		if(!(in_array($_G['groupid'],$mastgroup))){$ismast=0;}
		$ava='<a href="home.php?mod=space&uid='.$iszjhd['authorid'].'" c="1" class="ans_ava">'.avatar($iszjhd['authorid'],small).'</a>';
		if($iszjhd){
			$usname=dhtmlspecialchars(getusn($iszjhd['authorid']));
			$dateline=date('Y-m-d',$iszjhd['dateline']);
			$message=_cutstr($iszjhd['message']);
			
		}
		include template('keke_answer:btn');
		$info=_getansset();
		$temp=array();
		$temps='';
		$mobile=checkmobile();
		$n=1;
		$anspid=$ansarr['pid'];
		foreach($postlist as $key=>$val){
			if($val['first']){
				$temps=$iszjhd ? $return : $rts;
			}else{
				$temps=$rpo='';
				if(!$anspid && (($_G['thread']['authorid']==$_G['uid']) || $ismast)){
					if(!$mobile){
						$temps="<div class=\"asnbtn\"><a href=\"javascript:\" id=\"keke_answer".$val['pid']."\" onclick=\"showWindow(this.id, 'plugin.php?id=keke_answer:tis&pid=".$val['pid']."&tid=".$val['tid']."&formhash=".FORMHASH."');\" class=\"zjda\">".lang('plugin/keke_answer', 'setzjda')."</a></div>";
					}else{
						$temps="<div class=\"asnbtn\"><a href=\"plugin.php?id=keke_answer:tis&pid=".$val['pid']."&tid=".$val['tid']."&formhash=".FORMHASH."\" class=\"zjda\">".lang('plugin/keke_answer', 'setzjda')."</a></div>";
					}
				}elseif($ansarr['pid']==$key && $info[$val['fid']]['ansico']){
					$rpo="<div class=\"kkstampbox\"><div class=\"kkstamp\"><img src=\"source/plugin/keke_answer/template/images/".$info[$val['fid']]['ansico']."\" /></div></div>";
				}
			}
			if($n==1){
				if(!$mobile){
					$temps.=$styss;
				}else{
					$temps.=$wapsty;
				}
			}
			$postlist[$key]['message']=$rpo.$postlist[$key]['message'].$temps;
			$n++;
		}
		return $temp;
	}
	function __construct() {
	}
	function post_top(){
		global $_G; 
		$keke_answer = $_G['cache']['plugin']['keke_answer'];
		$section = empty($keke_answer['bk']) ? array() : unserialize($keke_answer['bk']);
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){return;}
		include_once DISCUZ_ROOT . './source/plugin/keke_answer/function.php';
		$creditname=$_G['setting']['extcredits'][$keke_answer['yhxs']]['title'];
		$iszjhd = zjdabytid($_G['tid']);
		if($_GET['action']=="reply" && $iszjhd && !$keke_answer['ht']){
			showmessage(lang('plugin/keke_answer', 'byxhf'), '', array(), array('alert' => 'info'));
		}
		$languages = lang('forum/template');
		$nowcredit = getuserprofile('extcredits'.$keke_answer['yhxs']);
		$credit_num = intval($_GET['rewardprice']);
		$ansarr=_getansarr_bytid(intval($_GET['tid']));
		$tid=intval($_GET['tid']);
		$pid=intval($_GET['pid']);
		if($_GET['action']=="edit" && $pid){
			$postdatas=_getpostdata($tid,$pid);
		}
		if(($_GET['action']=="newthread" || $_GET['action']=="edit")){
			if($_GET['action']=="edit" && $ansarr['pid'] && $keke_answer['bj'] && $postdatas['first'] && $_G['groupid']!=1){
				showmessage(lang('plugin/keke_answer', 'f021'));
			}
			if(submitcheck('topicsubmit') && $keke_answer['yhxson'] && $_GET['tlx']){
				if(!$credit_num && $keke_answer['yhxszd']){
					showmessage(lang('plugin/keke_answer', 'f007'));
				}
				
				$sxfs=0;
				if($keke_answer['sxf']){
					$sxfs=round(($keke_answer['sxf']/100)*$credit_num);
				}
				if($credit_num < $keke_answer['yhxszd']){
					showmessage(lang('plugin/keke_answer', 'f015'));
				}
				
				if(($credit_num > $keke_answer['yhxszg']) && $keke_answer['yhxszg']){
					showmessage(lang('plugin/keke_answer', 'f022').$keke_answer['yhxszg'].$creditname);
				}
			
				if(($credit_num+$sxfs)>$nowcredit){
					showmessage(lang('plugin/keke_answer', 'f008'));
				}
			}
			if(submitcheck('editsubmit') && $keke_answer['yhxson'] && !$ansarr['pid'] && $postdatas['first'] && $_GET['tlx']){
				if(($credit_num<$ansarr['credit_num']) && $_GET['action']=="edit" && $_GET['tid']){
					showmessage(lang('plugin/keke_answer', 'f009').$ansarr['credit_num'].$_G['setting']['extcredits'][$keke_answer['yhxs']]['title']);
				}
				if($credit_num-$ansarr['credit_num'] > $nowcredit){
					showmessage(lang('plugin/keke_answer', 'f008'));
				}
			}
		}

		if(($keke_answer['yhxson'] || $keke_answer['xtxson']) && $_GET['action']=="newthread" || ($_GET['action']=="edit" && !$ansarr['pid'])){
			if($_GET['action']=="edit" && $_GET['tid'] && $_GET['pid']){				
				if(!$postdatas['first']){
					return;
				}
				$pre=$ansarr['credit_num'];
			}
			$minpre=intval($keke_answer['yhxszd']);
			$maxpre=intval($keke_answer['yhxszg']);
			include template('keke_answer:btn');
			$inputhook=($languages['comment_message2']?$languages['comment_message2']:lang('plugin/keke_answer', 'f010')).'</span>';
			if(!$_G['setting']['rewritestatus']){
				$_G['setting']['rewritestatus'] = true;
			}
			$_G['setting']['output']['str']['search']['keke_answer_'] = $inputhook;
			$_G['setting']['output']['str']['replace']['keke_answer_'] = $inputhook.$lx.'</div></div><div><div>'.$xsreturn;
		}
		return;
	
	}
	function forumdisplay_thread_output(){
		global $_G, $threadlist;
		$keke_answer = $_G['cache']['plugin']['keke_answer'];
		if(!$keke_answer['listtis']){
			return array();
		}
		$section = empty($keke_answer['bk']) ? array() : unserialize($keke_answer['bk']);
		if(!is_array($section)) $section = array();
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){
			return array();
		}
		include_once DISCUZ_ROOT . './source/plugin/keke_answer/function.php';
		$ansarr=_getanslistarr($threadlist);
		include template('keke_answer:btn');
		foreach($threadlist as $k => $v){
			if($ansarr[$v['tid']]['credit_num'] && !$ansarr[$v['tid']]['pid']){
				$anstis=$ansarr[$v['tid']]['credit_num'].$_G['setting']['extcredits'][$ansarr[$v['tid']]['credit_type']]['title'];
				$lists=str_replace('[tis]', $anstis,$list);
				$_G['forum_threadlist'][$k]['subject']=$_G['forum_threadlist'][$k]['subject'].$lists;
			}
		}
		return array();
		
	}
	function post_message($param) {
		global $_G;
		$keke_answer = $_G['cache']['plugin']['keke_answer'];
		$section = empty($keke_answer['bk']) ? array() : unserialize($keke_answer['bk']);
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){
			return;
		}
		include_once DISCUZ_ROOT . './source/plugin/keke_answer/function.php';
		$credit_num = intval($_GET['rewardprice']);
		if($_GET['tlx']){
			_instdate($param,$credit_num);
		}
		return;
	}
}

class mobileplugin_keke_answer_forum extends plugin_keke_answer_forum{
	function post_bottom_mobile(){
		global $_G;
		$keke_answer = $_G['cache']['plugin']['keke_answer'];
		$section = empty($keke_answer['bk']) ? array() : unserialize($keke_answer['bk']);
		if(!(empty($section[0]) || in_array($_G['fid'],$section))){
			return;
		}
		include_once DISCUZ_ROOT . './source/plugin/keke_answer/function.php';
		$nowcredit = getuserprofile('extcredits'.$keke_answer['yhxs']);
		$tid=intval($_GET['tid']);
		$pid=intval($_GET['pid']);
		if($_GET['action']=="edit" && $pid){
			$postdatas=_getpostdata($tid,$pid);
			if(!$postdatas['first']){
				return;
			}
		}
		if(($keke_answer['yhxson'] || $keke_answer['xtxson']) && $_GET['action']=="newthread" || ($_GET['action']=="edit")){
			$ansarr=_getansarr_bytid(intval($_GET['tid']));
			if($_GET['action']=="edit" && $_GET['tid']){
				$pre=$ansarr['credit_num'];
			}
			$minpre=intval($keke_answer['yhxszd']);
			$maxpre=intval($keke_answer['yhxszg']);
			$creditname=$_G['setting']['extcredits'][$keke_answer['yhxs']]['title'];
			include template('keke_answer:btn');
		}
		return $xsreturn;
		
	}
}