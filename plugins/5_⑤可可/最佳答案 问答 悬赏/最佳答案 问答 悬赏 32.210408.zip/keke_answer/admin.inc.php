<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	$keke_answer = $_G['cache']['plugin']['keke_answer'];
	include_once DISCUZ_ROOT . './source/plugin/keke_answer/function.php';
	if (submitcheck("forumset")) {
		$data = serialize(daddslashes($_POST['form']));
		_sevrset($data);
		cpmsg(lang('plugin/keke_answer', 'szcg'), 'action=plugins&operation=config&identifier=keke_answer&pmod=admin', 'succeed');
	}

	$section = empty($keke_answer['bk']) ? array() : unserialize($keke_answer['bk']);
	foreach ($section as $k=>$v) {if (is_numeric($v)) $fidlist .= $v.',';}
	if ($fidlist){$fidlist = substr($fidlist, 0, -1);}else{return;}
	showtips(lang('plugin/keke_answer', 'jqts'));
    showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admin");
    showtableheader(lang('plugin/keke_answer', 'zdgl'));
    showsubtitle(array(lang('plugin/keke_answer', 'bkmc'), lang('plugin/keke_answer', 'grid'), lang('plugin/keke_answer', 'f006'), ''));
	loadcache('keke_answer');
	$info=$_G['cache']['keke_answer']?$_G['cache']['keke_answer']:DB::result_first("select val from ".DB::table('keke_answer_set'));
	$info=unserialize($info);
	$classarr=DB::fetch_all("select fid,typeid,name,displayorder from ".DB::table('forum_threadclass')." where fid in (".$fidlist.") ORDER BY displayorder ASC");
	foreach($classarr as $ck=>$cv){
		$classarrs[$cv['fid']][$cv['typeid']]=$cv;
	}
	$query = DB::query("SELECT * FROM ".DB::table('forum_forum')." WHERE fid in (".$fidlist.")");
	while($forum = DB::fetch($query)) {
		$table = array();
		foreach($classarrs[$forum['fid']] as $kk=>$vv){
			$selected='';
			if($info[$forum['fid']]['message']==$kk){
				$selected='selected';
			}
			$ops.='<option value="'.$kk.'" '.$selected.'>'.$vv['name'].'</option>';
		}
        $table[0] = $forum['name'].'<span class="lightfont"> [fid:'.$forum['fid'].']</span>';
        $table[1] = '<select name="form['.$forum['fid'].'][message]">'.$ops.'</select>';
		$table[2] = '<input name="form['.$forum['fid'].'][ansico]" value="'.dhtmlspecialchars($info[$forum['fid']]['ansico']).'">';
        showtablerow('',array('width="200"', 'width="250"'), $table);
	}
    showsubmit('forumset', 'submit', '', '');
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
