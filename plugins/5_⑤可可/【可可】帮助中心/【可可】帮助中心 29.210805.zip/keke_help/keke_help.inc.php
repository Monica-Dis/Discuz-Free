<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
$keke_help = $_G['cache']['plugin']['keke_help'];
require_once DISCUZ_ROOT.'./source/plugin/keke_help/function.php';
$filterarr=array('title','header_text','pcbanner_txt','pcbanner_dec');
foreach($filterarr as $val){
	$keke_help[$val]=dhtmlspecialchars($keke_help[$val]);
}
$navtitle=$keke_help['title'];
$allcatedata=_get_allcatedata();
$hotsearcharr=_gethotsearch();
$ordercon=_getordercon();
$ppp=checkmobile()?30:15;
$param=($_GET['op'])?'op='.dhtmlspecialchars($_GET['op']):($_GET['catid']?'catid='.dhtmlspecialchars($_GET['catid']):'');
$param=$param?'&'.$param:'';
$tmpurl='plugin.php?id=keke_help'.$param;
$page = max(1, intval($_GET['page']));
$startlimit = ($page - 1) * $ppp;
$where='common=1';
$order='ORDER by displayorder ASC,id ASC';
if($_GET['hid']){
	$hid=intval($_GET['hid']);
	$helpdata=C::t('#keke_help#keke_help')->fetchfirst_by_id($hid);
	if($helpdata){
		$_GET['catid']=$helpdata['cateid'];
	}
	$tmpurl='plugin.php?id=keke_help&catid='.$helpdata['cateid'];
}
if($_GET['catid']){
	$catid=intval($_GET['catid']);
	$where=($allcatedata[$catid]['subcate'])?'cateid in ( '.dimplode($allcatedata[$catid]['subcate']).' )':'cateid='.$catid;
}else{
	if($_GET['op']=='all'){
		$where='';
	}elseif($_GET['op']=='searech'){
		$_GET['searechkw']=daddslashes(dhtmlspecialchars($_GET['searechkw']));
		$where = " subject LIKE '%".$_GET['searechkw']."%' OR  content LIKE '%".$_GET['searechkw']."%'";
    }elseif($_GET['op']=='feedback'){
        $feedbackType=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',dhtmlspecialchars($keke_help['feedbacktype'])));
	}
}
if((strstr($_SERVER['HTTP_USER_AGENT'], "MAGAPPX")!== false || strstr($_SERVER['HTTP_USER_AGENT'], "QianFan")!== false || strstr($_SERVER['HTTP_USER_AGENT'], "Appbyme")!== false) && $keke_help['appheader']){
	$_GET['app']=1;
}
$count_all=C::t('#keke_help#keke_help')->count_all($where);
$helparr=C::t('#keke_help#keke_help')->fetch_all_helps($startlimit,$ppp,$where,$order);

if($_GET['hid']){
	foreach($helparr as $cv){
		$hidarr[]=$cv['id'];
	}
	$showhelp=in_array($hid,$hidarr)?1:0;
}
$keke_help['style']=_help_editor_safe_replace($keke_help['style']);
$helparr=hightlights($helparr);//20191024
$multipage = multi($count_all, $ppp, $page, $_G['siteurl'].$tmpurl);
$multipage=preg_replace("/\<label\>([\s\S]*)\<\/label\>/i", '', $multipage);
include template('keke_help:help_index');