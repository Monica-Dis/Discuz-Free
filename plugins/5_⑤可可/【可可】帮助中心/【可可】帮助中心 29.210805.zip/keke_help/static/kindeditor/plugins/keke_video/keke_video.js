KindEditor.plugin('keke_video', function (K) {
    var self = this, name = 'keke_video';
    self.clickToolbar(name, function () {
        var lang = self.lang(name + '.'),
            html = ['<div style="padding:10px 20px;">',
                '<p style="color:red;padding:10px 0">\u8bf7\u590d\u5236\u3010\u901a\u7528\u4ee3\u7801\u3011\u5230\u4ee5\u4e0b\u6846\u5185\uff0c\u652f\u6301b\u7ad9\uff0c\u4f18\u9177\uff0c\u817e\u8baf\u7b49\u7b49\u89c6\u9891\u63d2\u5165</p>',
                '<textarea class="ke-textarea" style="width:408px;height:260px;padding:10px ; box-sizing: border-box;" placeholder="\u4ee3\u7801\u683c\u5f0f\u5982\u4e0b\uff1a\r<iframe height=498 width=510 src=http://player.youku.com/embed/XMzE4ODg3MjgyOA== frameborder=0 allowfullscreen></iframe>"></textarea>',
                '</div>'].join(''),
            dialog = self.createDialog({
                name: name,
                width: 450,
                title: self.lang(name),
                body: html,
                yesBtn: {
                    name: self.lang('yes'),
                    click: function (e) {
                        var code = textarea.val(),
                            html = '<div class="keke-videobox">' + code + '</div>';
                        if (K.trim(code) === '') {
                            alert("\u8bf7\u8f93\u5165\u89c6\u9891\u4ee3\u7801\uff01");
                            textarea[0].focus();
                            return;
                        }
                        self.insertHtml(html).hideDialog().focus();
                    }
                }
            }),
            textarea = K('textarea', dialog.div);
        textarea[0].focus();
    });
});