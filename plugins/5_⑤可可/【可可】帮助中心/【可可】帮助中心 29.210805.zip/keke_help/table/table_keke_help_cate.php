<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_keke_help_cate extends discuz_table {

	public function __construct() {
		$this->_table = 'keke_help_cate';
		$this->_pk    = 'cate_id';

		parent::__construct(); /*dism_ taobao _com*/
	}
	
	public function count_by_search($param) {
		return DB::result_first('SELECT COUNT(*) FROM %t %i', array($this->_table, $this->wheresql($param)));
	}
		
	public function fetch_all_by_displayorder() {
		$query=DB::fetch_all("SELECT * FROM %t ORDER BY displayorder", array($this->_table), $this->_pk);
		return $this->_allcatedata($query);
	}

	public function _allcatedata($query) {
		foreach($query as $key => $value) {
			if($value['upid']) {
				$query[$value['upid']]['subcate'][] = $key;
			}
		}
		foreach($query as $key => $value) {
			if($value['upid'] == 0) {
				$catedata[$key] = $value;
				foreach($value['subcate'] as $subcate) {
					$catedata[$subcate] = $query[$subcate];
				}
			}
		}
		return $catedata;
	}
	
}

?>