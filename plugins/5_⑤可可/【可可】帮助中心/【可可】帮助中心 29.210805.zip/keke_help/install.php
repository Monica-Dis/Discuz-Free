<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$keke_help= DB::table("keke_help");
$keke_help_cate= DB::table("keke_help_cate");
$keke_help_feedback= DB::table("keke_help_feedback");
$sql = <<<EOF
CREATE TABLE `$keke_help` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cateid` int(10) unsigned NOT NULL DEFAULT '0',
  `subcateid` int(10) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `content` mediumtext NOT NULL,
  `time` int(50) NOT NULL,
  `common` int(1) NOT NULL,
  `view` int(50) NOT NULL,
  `jump` varchar(255) NOT NULL,
  `displayorder` int(6) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_help_cate` (
 `cate_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `upid` int(10) unsigned NOT NULL DEFAULT '0',
  `displayorder` int(6) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `num` int(8) NOT NULL,
  `icon` varchar(255) NOT NULL,
  PRIMARY KEY (`cate_id`)
) ENGINE=MyISAM;

CREATE TABLE `$keke_help_feedback` (
 `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `tel` varchar(100) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `state` int(1) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;
runquery($sql);
$finish = true;
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_help/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_help/upgrade.php');