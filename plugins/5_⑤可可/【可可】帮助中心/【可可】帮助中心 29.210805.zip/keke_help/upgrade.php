<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$query = DB::query("SHOW COLUMNS FROM ".DB::table('keke_help'));
while($row = DB::fetch($query)) {
	$col[]=$row['Field']; 
}

if(!in_array('jump', $col)){
	$sql = "Alter table ".DB::table('keke_help')." add `jump` varchar(255) NOT NULL;"; 
	DB::query($sql); 
}


$keke_help_feedback= DB::table("keke_help_feedback");
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `$keke_help_feedback` (
  `id` int(20) unsigned NOT NULL AUTO_INCREMENT,
  `uid` int(10) NOT NULL,
  `typeid` int(10) unsigned NOT NULL DEFAULT '0',
  `content` mediumtext NOT NULL,
  `tel` varchar(100) NOT NULL,
  `pic` varchar(255) NOT NULL,
  `state` int(1) NOT NULL,
  `time` int(10) NOT NULL,
  PRIMARY KEY (`id`)
)ENGINE=MyISAM;
EOF;
runquery($sql);

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/keke_help/discuz_plugin_keke_help_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_help/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/keke_help/upgrade.php');