<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!应用中心
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   警告：资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
if($_GET['formhash'] != $_G['formhash']) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT.'./source/plugin/keke_help/function.php';
if($_GET['ac']=='updataview'){
	$hid=intval($_GET['hid']);
	C::t('#keke_help#keke_help')->updateview_by_id($hid);
}elseif($_GET['ac']=='updatapic'  && $_G['adminid']){
	$pic=_uploadpics($_FILES['imgFile']);
	header('Content-type: text/html');
	exit(json_encode($pic));
}elseif($_GET['ac']=='keke_help_link'){
	$_GET['hid']=intval($_GET['hid']);
	$helpdata=C::t('#keke_help#keke_help')->fetchfirst_by_id($_GET['hid']);
	include template('keke_help:help_win');
}elseif($_GET['ac']=='postFeedback'){
    if(!$_GET['ftext']){
        exit(json_encode(array(
            'state'=>4,
            'msg'=>help_gbk2utf('请输入反馈内容'),
        )));
    }
    if(!$_GET['ftel']){
        exit(json_encode(array(
            'state'=>4,
            'msg'=>help_gbk2utf('请输入联系方式'),
        )));
    }
    $arr=array(
        'uid'=>$_G['uid'],
        'typeid'=>intval($_GET['ftype']),
        'content'=>$_GET['ftext'],
        'tel'=>$_GET['ftel'],
        'time'=>TIMESTAMP
    );
    C::t('#keke_help#keke_help_feedback')->insert($arr);
    exit(json_encode(array('state'=>1)));
}