<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT . 'source/plugin/keke_help/identity.inc.php';
function _uploadpics($filses)
{
	global $_G;
	require_once libfile('function/forum');
	$data = array('extid' => 1);
	$pic['url'] = $_G['setting']['attachurl'] . 'common/' . upload_icon_banner($data, $filses, '');
	$pic['error'] = 0;
	return $pic;
}
function _uploadpicss($filses)
{
	global $_G;
	require_once libfile('function/forum');
	$datas = array('extid' => 1);
	foreach ($filses['error'] as $key => $val) {
		$data[$key]['name'] = $filses['name'][$key];
		$data[$key]['type'] = $filses['type'][$key];
		$data[$key]['tmp_name'] = $filses['tmp_name'][$key];
		$data[$key]['error'] = $filses['error'][$key];
		$data[$key]['size'] = $filses['size'][$key];
	}
	foreach ($data as $ks => $vs) {
		$return[$ks] = upload_icon_banner($datas, $vs, '');
	}
	return $return;
}
function _help_increase($arr, $helpid = '')
{
	global $_G;
	if ($helpid) {
		C::t('#keke_help#keke_help')->update($helpid, $arr);
	} else {
		C::t('#keke_help#keke_help')->insert($arr);
	}
}
function _getcateselect($cateid = '', $type = '')
{
	$allcatedata = C::t('#keke_help#keke_help_cate')->fetch_all_by_displayorder();
	$t = $type ? 'multiple="multiple" size="10"' : '';
	$cats .= '<select name="cateid" ' . $t . '><option value=\\"0\\">' . lang('plugin/keke_help', 'lang23') . '</option>';
	foreach ($allcatedata as $vv) {
		if (!$vv['upid']) {
			$selected = $cateid == $vv['cate_id'] ? 'selected="selected"' : '';
			$cats .= $vv['subcate'] ? '<optgroup label="' . $vv['name'] . '"></optgroup>' : '<option style="font-weight :bold;" value="' . $vv['cate_id'] . ('" ' . $selected . '>') . $vv['name'] . '</option>
';
			if ($vv['subcate']) {
				foreach ($vv['subcate'] as $subcat) {
					$selected = $cateid == $subcat ? 'selected="selected"' : '';
					$cats .= '<option value="' . $subcat . ('" ' . $selected . '>&nbsp;&nbsp;|--') . $allcatedata[$subcat]['name'] . '</option>
';
				}
			}
		}
	}
	$cats .= '</select>';
	return $cats;
}
function _get_allcatedata()
{
	global $_G;
	loadcache('keke_help_cat');
	return $_G['cache']['keke_help_cat'] ? $_G['cache']['keke_help_cat'] : C::t('#keke_help#keke_help_cate')->fetch_all_by_displayorder();
}
function _save_cat()
{
	if (is_array($_GET['newname'])) {
		foreach ($_GET['newname'] as $key => $value) {
			if ($value) {
				$newarr = array('displayorder' => $_GET['newdisplayorder'][$key], 'name' => $_GET['newname'][$key], 'upid' => intval($_GET['upid'][$key]));
				C::t('#keke_help#keke_help_cate')->insert($newarr);
			}
		}
	}
	if (is_array($_GET['delete'])) {
		C::t('#keke_help#keke_help_cate')->delete($_GET['delete']);
	}
	if (is_array($_GET['name'])) {
		$pic = _uploadpicss($_FILES['icon']);
		foreach ($_GET['name'] as $keys => $value) {
			$updatearr = array('displayorder' => $_GET['displayorder'][$keys], 'name' => $_GET['name'][$keys]);
			if ($pic[$keys]) {
				$updatearr['icon'] = $pic[$keys];
			}
			C::t('#keke_help#keke_help_cate')->update($keys, $updatearr);
		}
	}
	$allcatedata = C::t('#keke_help#keke_help_cate')->fetch_all_by_displayorder();
	require_once libfile('function/cache');
	savecache('keke_help_cat', $allcatedata);
}
function _gethotsearch()
{
	global $_G;
	$keke_help = $_G['cache']['plugin']['keke_help'];
	$hotsearch = explode(',', $keke_help['hotsearch']);
	foreach ($hotsearch as $skey => $sval) {
		$hotsearcharr[] = dhtmlspecialchars($sval);
	}
	return $hotsearcharr;
}
function _getordercon()
{
	global $_G;
	$keke_help = $_G['cache']['plugin']['keke_help'];
	$orderconarr = explode('/hhf/', str_replace(array("\r\n", "\n", "\r"), '/hhf/', dhtmlspecialchars($keke_help['ordercon'])));
	foreach ($orderconarr as $orderconarrk => $orderconarrv) {
		$orderco = explode('|', $orderconarrv);
		$ordercon[] = $orderco;
	}
	$ordercon = array_reverse($ordercon);
	return $ordercon;
}
function getFeedType()
{
	global $_G;
	$keke_help = $_G['cache']['plugin']['keke_help'];
	$feedbackType = explode('/hhf/', str_replace(array("\r\n", "\n", "\r"), '/hhf/', dhtmlspecialchars($keke_help['feedbacktype'])));
	$html = '<select name="typeid">';
	foreach ($feedbackType as $typeid => $item) {
		$selected = $_GET['typeid'] && $_GET['typeid'] == $typeid ? 'selected="selected"' : '';
		$html .= '<option value="' . $typeid . ('" ' . $selected . '>') . $item . '</option>
';
	}
	$html .= '</select>';
	return $html;
}
function hightlights($helparr)
{
	if ($_GET['op'] == 'searech' && $_GET['searechkw']) {
		$search = dhtmlspecialchars($_GET['searechkw']);
		foreach ($helparr as $k => $v) {
			$helparr[$k]['subject'] = str_replace($search, '<font color="#CC3300">' . $search . '</font>', $v['subject']);
			$helparr[$k]['content'] = str_replace($search, '<font color="#CC3300">' . $search . '</font>', $v['content']);
		}
	}
	return $helparr;
}
function help_gbk2utf($data)
{
	if (CHARSET == 'gbk') {
		$data1 = diconv($data, 'utf-8', 'gbk');
		$data0 = diconv($data1, 'gbk', 'utf-8');
		if ($data0 == $data) {
			$tmpstr = $data1;
		} else {
			$tmpstr = $data;
		}
		return diconv($tmpstr, 'gbk', 'utf-8');
	}
	return $data;
}
function getUsname($uid)
{
	$userdata = getuserbyuid($uid);
	return $userdata['username'];
}
function _help_editor_safe_replace($content)
{
	$tags = array('\'<iframe[^>]*?>.*?</iframe>\'is', '\'<frame[^>]*?>.*?</frame>\'is', '\'<script[^>]*?>.*?</script>\'is', '\'<head[^>]*?>.*?</head>\'is', '\'<title[^>]*?>.*?</title>\'is', '\'<meta[^>]*?>\'is', '\'<link[^>]*?>\'is');
	return preg_replace($tags, '', $content);
}