<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
	loadcache('plugin');
	$keke_help = $_G['cache']['plugin']['keke_help'];
	include_once DISCUZ_ROOT."source/plugin/keke_help/function.php";
	if(!$_G['uid']) {
		cpmsg('Please Login');
	}
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
				C::t('#keke_help#keke_help')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/keke_help', 'lang01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_help&pmod=admincp_help', 'succeed');
	}
	$allcatedata=C::t('#keke_help#keke_help_cate')->fetch_all_by_displayorder();
	$formhash=substr(md5(substr($_G['timestamp'], 0, -7).$_G['username'].$_G['uid'].$_G['authkey']), 8, 8);
	if($_GET['ac']=='edit'){
		$helpid=intval($_GET['helpid']);
		if (submitcheck("editsubmit")) {
			$arr=array(
				'subject' => $_GET['text'],
				'content' => $_GET['help_content'],
				'cateid' => intval($_GET['cateid']),
				'common'=>intval($_GET['common']),
				'jump' => $_GET['jump'],
				'displayorder'=>intval($_GET['displayorder']),
				'time' => TIMESTAMP,
			);
			_help_increase($arr,$helpid);
			cpmsg(lang('plugin/keke_help', 'lang01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_help&pmod=admincp_help', 'succeed');
		}
		$helpdata = C::t('#keke_help#keke_help')->fetchfirst_by_id($helpid);
		showformheader("plugins&operation=config&do=" . $plugin["pluginid"] . "&identifier=" . $plugin["identifier"] . "&pmod=admincp_help&ac=edit", 'enctype');
		showtableheader(lang('plugin/keke_help', 'lang07'));
		$common=$helpdata['common']?1:0;
		showsetting(lang('plugin/keke_help', 'lang08'),'text',$helpdata['subject'],'text');
		$edit= "
			<textarea name=\"help_content\" style=\"width:700px;height:400px;visibility:hidden;\">".$helpdata['content']."</textarea>
			<script charset=\"utf-8\" src=\"./source/plugin/keke_help/static/kindeditor/kindeditor-min.js\"></script>
			<script charset=\"utf-8\" src=\"./source/plugin/keke_help/static/kindeditor/lang/zh_CN.js\"></script>
			<script>
			  var itemss = [
				  'source', '|', 'undo', 'redo', '|', 'preview', 'template', 'cut', 'copy', 'paste',
				  'plainpaste', 'wordpaste', '|', 'justifyleft', 'justifycenter', 'justifyright',
				  'justifyfull', 'insertorderedlist', 'insertunorderedlist', 'indent', 'outdent', 'subscript',
				  'superscript', 'clearhtml', 'quickformat', 'selectall', '|', 'fullscreen', '/',
				  'formatblock', 'fontname', 'fontsize', '|', 'forecolor', 'hilitecolor', 'bold',
				  'italic', 'underline', 'strikethrough', 'lineheight', 'removeformat', '|', 'image', 'multiimage','keke_video', 'table', 'hr', 'emoticons', 'baidumap', 'pagebreak',
				  'anchor', 'link', 'unlink'
			  ];
			  KindEditor.ready(function(K) {
						var editor1 = K.create('textarea[name=\"help_content\"]', {
							".($keke_help['filtermod']?"":"filterMode: false,")."
							uploadJson : 'plugin.php?id=keke_help:upload_json&ac=updatapic&formhash=".$formhash."',
							allowFileManager : false,
							items : itemss
						});
					});
			</script>
		";
		showsetting(lang('plugin/keke_help', 'lang09'), '','',_getcateselect($helpdata['cateid']));
		showsetting(lang('plugin/keke_help', 'lang10'), '','',$edit);
		showsetting(lang('plugin/keke_help', 'lang11'),'common',$common, 'radio');
		showsetting(lang('plugin/keke_help', 'lang25'),'jump',$helpdata['jump'],'text','','',lang('plugin/keke_help', 'lang26'));
		showsetting(lang('plugin/keke_help', 'lang12'),'displayorder',$helpdata['displayorder'],'text');
		echo '<input name="helpid" type="hidden" value="'.$helpid.'" />';
		showsubmit('editsubmit', 'submit', '');
		showtablefooter(); /*dis'.'m.tao'.'bao.com*/
		showformfooter(); /*dism��taobao��com*/
		exit;
	}elseif($_GET['ac']=='pic'){
		echo 1;exit;
	}
	showtableheader(lang('plugin/keke_help', 'lang13'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_help&pmod=admincp_help', 'testhd');
	showtablerow('', array('width="50"', 'width="120"', 'width="50"','width="180"'),
		array(
			'<b>'.lang('plugin/keke_help', 'lang14').': </b>',
			_getcateselect($helpdata['cateid']),
			'<b>'.lang('plugin/keke_help', 'lang15').': </b>',
			'<input name="helpkw" type="text" />',
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_help', 'lang16').'">'
		)
    );
	showformfooter(); /*dism��taobao��com*/
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	$where='1';$param='';
	if($_GET['cateid']){
		$where.=" AND cateid=".intval($_GET['cateid']);
		$param.='&cateid='.intval($_GET['cateid']);
	}
	if($_GET['helpkw']){
		$where.=" AND subject LIKE '%".addcslashes($_GET['helpkw'],'%_')."%'";
		$param.='&helpkw='.addcslashes($_GET['helpkw']);
	}
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_help");	
	showtableheader(lang('plugin/keke_help', 'lang17'));
    showsubtitle(array('del', lang('plugin/keke_help', 'lang08'),lang('plugin/keke_help', 'lang09'),lang('plugin/keke_help', 'lang18'),lang('plugin/keke_help', 'lang19'),lang('plugin/keke_help', 'lang12'),lang('plugin/keke_help', 'lang20')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_help&pmod=admincp_help'.$param;
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($allcount = C::t('#keke_help#keke_help')->count_all($where)){
		$help_data=C::t('#keke_help#keke_help')->fetch_all_helps($startlimit,$ppp,$where,$order);
		foreach($help_data as $key=>$val){
			$state='<a href="'.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_help&pmod=admincp_help&ac=edit&helpid='.$val['id'].'">'.lang('plugin/keke_help', 'lang21').'</a>';
			$cate=$allcatedata[$val['cateid']]['upid']?$allcatedata[$allcatedata[$val['cateid']]['upid']]['name'].' > '.$allcatedata[$val['cateid']]['name']:$allcatedata[$val['cateid']]['name'];
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = $val['subject'];
			$table[2] = $cate;
			$table[3] = dgmdate($val['time'], 'Y/m/d H:i');
			$table[4] = $val['common']?'&radic;':'';
			$table[5] = $val['displayorder'];
			$table[6] = $state;
			showtablerow('',array('',''), $table);
			
		}
	}
	$multipage='';
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<style>#imgzoom{  margin:15px 0;}#imgzoom p { display:none}</style><tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del',' <a href="'.ADMINSCRIPT.'?action=plugins&operation=config&identifier=keke_help&pmod=admincp_help&ac=edit&do='. $plugin["pluginid"].'" class="addtr">'.lang('plugin/keke_help', 'lang22').'</a>');
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dism��taobao��com*/