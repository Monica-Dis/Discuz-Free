<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
    global $_G,$pluginid,$plugin;
	loadcache('plugin');
	$keke_help = $_G['cache']['plugin']['keke_help'];
	include_once DISCUZ_ROOT."source/plugin/keke_help/function.php";
	if (submitcheck("forumset")) {
		if(is_array($_GET['delete'])) {
				C::t('#keke_help#keke_help_feedback')->delete($_GET['delete']);
		}
		cpmsg(lang('plugin/keke_help', 'lang01'), 'action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_help&pmod=admincp_feedback', 'succeed');
	}
	showtableheader(lang('plugin/keke_help', 'lang13'));
	showformheader('plugins&operation=config&do='.$pluginid.'&pmod=keke_help&pmod=admincp_feedback', 'testhd');
	showtablerow('', array('width="50"', 'width="100"'),
		array(
			'<b>'.lang('plugin/keke_help', 'lang14').': </b>',
            getFeedType(),
			'<input type="submit" class="btn" id="submit_searchsubmit" name="searchsubmit" value="'.lang('plugin/keke_help', 'lang16').'">'
		)
    );
	showformfooter(); /*dism��taobao��com*/
	showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	$where='1';$param='';
	if($_GET['typeid']){
		$where.=" AND typeid=".intval($_GET['typeid']);
		$param.='&typeid='.intval($_GET['typeid']);
	}
	showformheader("plugins&operation=config&do=".$plugin["pluginid"]."&identifier=" . $plugin["identifier"] . "&pmod=admincp_feedback");
	showtableheader(lang('plugin/keke_help', 'lang17'));
    showsubtitle(array('del', lang('plugin/keke_help', 'lang27'),lang('plugin/keke_help', 'lang28'),lang('plugin/keke_help', 'lang29'),lang('plugin/keke_help', 'lang30'),lang('plugin/keke_help', 'lang31')));
	$ppp=30;
	$tmpurl=ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin["pluginid"].'&identifier=keke_help&pmod=admincp_feedback'.$param;
    $feedbackType=explode("/hhf/",str_replace(array("\r\n", "\n", "\r"), '/hhf/',dhtmlspecialchars($keke_help['feedbacktype'])));
	$page = max(1, intval($_GET['page']));
	$startlimit = ($page - 1) * $ppp;
	if($allcount = C::t('#keke_help#keke_help_feedback')->count_all($where)){
		$help_data=C::t('#keke_help#keke_help_feedback')->fetch_alls($startlimit,$ppp,$where);
		foreach($help_data as $key=>$val){
			$cate=$allcatedata[$val['cateid']]['upid']?$allcatedata[$allcatedata[$val['cateid']]['upid']]['name'].' > '.$allcatedata[$val['cateid']]['name']:$allcatedata[$val['cateid']]['name'];
			$table = array();
			$table[0] = '<input type="checkbox" class="checkbox" name="delete[]" value="'.$val['id'].'" />';
			$table[1] = $feedbackType[$val['typeid']];
			$table[2] = $val['content'];
			$table[3] = '<a href="home.php?mod=space&uid='.$val['uid'].'" target="_blank">'.getUsname($val['uid']).'</a>';
			$table[4] = $val['tel'];
			$table[5] = dgmdate($val['time'], 'Y/m/d H:i');
			showtablerow('',array('',''), $table);
		}
	}
	$multipage = multi($allcount, $ppp, $page, $_G['siteurl'].$tmpurl);
	if($multipage)echo '<tr class="hover"><td colspan="9">'.$multipage.'</td></tr>';
	showsubmit('forumset', 'submit', 'del');
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
	showformfooter(); /*dism��taobao��com*/