<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G,$strongh5upaset;  
$strongh5upaset = $_G['cache']['plugin']['strong_h5_upload_avatar'];          
define('UC_AVATARDIR', DISCUZ_ROOT . 'uc_server/data');
if($_GET['showtokeninfo']=='yes'){
    require_once DISCUZ_ROOT . '/source/plugin/strong_h5_upload_avatar/function/function_common.php';
}
if(!$_G[uid]) {
    showmessage('&#35831;&#30331;&#24405;&#21518;&#20877;&#36827;&#34892;&#25805;&#20316;', 'member.php?mod=logging&action=login&mobile=2', array('timeout' => '1500'));
}

$uid = $_G['uid'];
if($_POST[formhash] == FORMHASH && $_POST[image] && $_POST[image2] && $_POST[image3]) {

    $upload_avatar = new SH5UPLOADAVATAR();

    $home = $upload_avatar->get_home($uid);

    if(!is_dir(UC_AVATARDIR . '/avatar/' . $home)) {
        $upload_avatar->set_home($uid, UC_AVATARDIR . '/avatar/');
    }

    $avatartype = 'virtual';
    $bigavatarfile = UC_AVATARDIR . '/avatar/' . $upload_avatar->get_avatar($uid, 'big', $avatartype);
    $middleavatarfile = UC_AVATARDIR . '/avatar/' . $upload_avatar->get_avatar($uid, 'middle', $avatartype);
    $smallavatarfile = UC_AVATARDIR . '/avatar/' . $upload_avatar->get_avatar($uid, 'small', $avatartype);
    $bigavatar = file_get_contents($_POST[image]);
    $middleavatar = file_get_contents($_POST[image2]);
    $smallavatar = file_get_contents($_POST[image3]);


    file_put_contents($bigavatarfile, $bigavatar);
    file_put_contents($middleavatarfile, $middleavatar);
    file_put_contents($smallavatarfile, $smallavatar);


    $biginfo = @getimagesize($bigavatarfile);
    $middleinfo = @getimagesize($middleavatarfile);
    $smallinfo = @getimagesize($smallavatarfile);

    $success = 1;

    if(!$biginfo || !$middleinfo || !$smallinfo) { 
        file_exists($bigavatarfile) && unlink($bigavatarfile);
        file_exists($middleavatarfile) && unlink($middleavatarfile);
        file_exists($smallavatarfile) && unlink($smallavatarfile);
        $success = 0;
    }

    dsetcookie('a1avatar_updaterand', mt_rand(10, 500), 604800);

    $url = defined('IN_MOBILE') && $strongh5upaset['lurl'] ? $strongh5upaset['lurl'] : 'home.php?mod=spacecp&ac=avatar&sx='.mt_rand(10,500); 
    if($success) {
        showmessage('&#19978;&#20256;&#25104;&#21151;', $url, array('timeout' => '1800'));
    } else {
        showmessage('&#19978;&#20256;&#22833;&#36133;');

    }


}


class SH5UPLOADAVATAR {

    function set_home($uid, $dir = '.') {
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        !is_dir($dir . '/' . $dir1) && mkdir($dir . '/' . $dir1, 0777);
        !is_dir($dir . '/' . $dir1 . '/' . $dir2) && mkdir($dir . '/' . $dir1 . '/' . $dir2, 0777);
        !is_dir($dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3) && mkdir($dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3, 0777);
    }


    function get_home($uid) {
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        return $dir1 . '/' . $dir2 . '/' . $dir3;
    }

    function get_avatar($uid, $size = 'big', $type = '') {
        $size = in_array($size, array(
            'big',
            'middle',
            'small')) ? $size : 'big';
        $uid = abs(intval($uid));
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        $typeadd = $type == 'real' ? '_real' : '';
        return $dir1 . '/' . $dir2 . '/' . $dir3 . '/' . substr($uid, -2) . $typeadd . "_avatar_$size.jpg";
    }


}

if(defined('IN_MOBILE') and $strongh5upaset['on_mobile']){
    $strongh5upaset['avatarsize']['bigsize'] = $strongh5upaset['bigsize'] ? $strongh5upaset['bigsize'] : 300;
    $strongh5upaset['avatarsize']['middlesize'] = $strongh5upaset['middlesize'] ? $strongh5upaset['middlesize'] : 180;
    $strongh5upaset['avatarsize']['small'] = $strongh5upaset['small'] ? $strongh5upaset['small'] : 100;
    $defaultavatarimg = $strongh5upaset['mdimg'] ? $strongh5upaset['mdimg'] : $_G['siteurl'].'source/plugin/strong_h5_upload_avatar/template/img/mdefault.jpg';   
    
    $navtitle = lang('plugin/strong_h5_upload_avatar', 'text1');  
    
    $img = avatar($_G[uid],'big',1,0,1).'?upcache='.$_G['cookie']['a1avatar_updaterand'];

    include_once template('strong_h5_upload_avatar:index');
}
//From: Dism��taobao��com
?>