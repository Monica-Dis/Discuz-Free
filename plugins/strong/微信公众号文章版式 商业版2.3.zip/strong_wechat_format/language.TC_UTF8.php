<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}




function swf_echolang($text = '') {

    $lang = array(
        'ptext1' => '原文閱讀',
        'ptext2' => '微信掃壹掃<br>關註該公眾號',
        'ptext3' => '微信號',
        'ptext4' => '功能介紹',
        
        'mtext1' => '在看',
        'mtext2' => '關註',
        'mtext3' => '長按二維碼，關註公眾號',
        'mtext4' => '歷史消息',
        'mtext5' => '關閉',
        'mtext6' => '寫留言',
        'mtext7' => '留言將由公眾號篩選展示，對所有人可見',
        
        'ctext1' => '今天',
        'ctext2' => '昨天',
        'ctext3' => '前天',
        'ctext4' => '三天前',
        'ctext5' => '壹周前',
        'ctext6' => '萬',
        'ctext7' => '{0}年{1}月{2}日'
       
            
            
            );
    return $lang[$text];
}

function swf_lang($text = null, $vars = array()) {
    $return = swf_echolang($text);
    if ($vars && is_array($vars)) {
        foreach ($vars as $k => $v) {
            $searchs[] = '{' . $k . '}';
            $replaces[] = $v;
        }
    }

    $return = str_replace($searchs, $replaces, $return);
    return $return;
}
//From: Dism_taobao-com
?>