<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function swf_showattach($post, $type = 0) {
    global $_G;
	$type = !$type ? 'attachlist' : 'imagelist';
  
	$return = '';
	if(!empty($post[$type]) && is_array($post[$type])) {
		foreach($post[$type] as $aid) {
			if(!empty($post['attachments'][$aid])) {
			    $attach = $post['attachments'][$aid];
			    $attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
                $aidencode = packaids($attach);
                $is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G['forum_thread']['archiveid'] : '';
                $img = $attach['refcheck'] ? "forum.php?mod=attachment".$is_archive."&aid=".$aidencode."&noupdate=yes" : $attach['url'].$attach['attachment'];  
                $return .= '<img id="aimg_'.$aid.'" src="'.$img.'">';
			}
		}
	}

	return $return;
}

function swf_messageimg($message,$post){
    global $_G;    
    $search = '/<a href=".*?><img id="aimg_(\d+?)" src=".*?><\/a>/';        
     
    preg_match_all($search,$message,$matches);
    if($matches[1]){
        foreach($matches[1] as $match){
            $attach = $post['attachments'][$match];
            if($attach){
                $attach['refcheck'] = (!$attach['remote'] && $_G['setting']['attachrefcheck']) || ($attach['remote'] && ($_G['setting']['ftp']['hideurl'] || ($attach['isimage'] && $_G['setting']['attachimgpost'] && strtolower(substr($_G['setting']['ftp']['attachurl'], 0, 3)) == 'ftp')));
                $aidencode = packaids($attach);
                $is_archive = $_G['forum_thread']['is_archived'] ? "&fid=".$_G['fid']."&archiveid=".$_G['forum_thread']['archiveid'] : '';
                $img = $attach['refcheck'] ? "forum.php?mod=attachment".$is_archive."&aid=".$aidencode."&noupdate=yes" : $attach['url'].$attach['attachment'];                
                
                $search = '/<a href=".*?><img id="aimg_'.$match.'" src=".*?><\/a>/';
                $replace = '<img id="aimg_'.$match.'" src="'.$img.'">';
                $message = preg_replace($search,$replace,$message); 
            }
        }
    }

    return $message;
}

function swf_getthreadimg($tid){
    if(intval($tid)){
        $attachtable = getattachtablebytid($tid); 
        $attach = DB::fetch_first("SELECT * FROM %t WHERE tid = %d and width>=180 and isimage=1",array($attachtable,$tid));
        if($attach){
            return getforumimg($attach['aid'],0,180,130);
        }
    }
    return '';
}


function swf_filtration($str){    
    $search = '/<a href=".*?>([\s|\S]*?)<\/a>/';
    $replace = '$1';    
    $str = preg_replace($search,$replace,$str);    
    return $str;    
}

function swf_date($time){

    if($time>strtotime(date('Y-m-d'))){
        return swf_lang('ctext1');
    }elseif($time>strtotime(date('Y-m-d',strtotime("-1 day")))){
        return swf_lang('ctext2');
    }elseif($time>strtotime(date('Y-m-d',strtotime("-2 day")))){
        return swf_lang('ctext3');
    }elseif($time>strtotime(date('Y-m-d',strtotime("-3 day")))){ 
        return swf_lang('ctext4');
    }elseif($time>strtotime(date('Y-m-d',strtotime("-15 day")))){    
        return swf_lang('ctext5');
    }
    return date('m-d',$time);
    
}

function swf_view($num){
    $num = intval($num);
    $count = $num/10000;
    if($count>1){
        return round($count,1).swf_lang('ctext6');
    }else{
        return $num;
    }
}


function swf_loadlang() {
    $language = 'language.' . currentlang() . '.php';
    require_once DISCUZ_ROOT . '/source/plugin/strong_wechat_format/' . $language;
}

function swf_wxshare() {
    global $wechat_client, $_G;
    if(!$_G['cache']['plugin']['strong_yq']['iswxshare']){return '';}
    

    if($_G['cache']['plugin']['strong_wxlogin']['wxshare']){
        $yqsignPackage = $wechat_client->getSignPackage();
    }else{
        $jssdk = new JSSDK($_G['cache']['plugin']['strong_yq']['appID'], $_G['cache']['plugin']['strong_yq']['appsecret']);
        $yqsignPackage = $jssdk->GetSignPackage();
    }
  
    
    $shareid = intval($_G['uid'] . TIMESTAMP);
    $wxdata = array(
        'title' => preg_replace("/\s/", '', $_G['cache']['plugin']['strong_yq']['sharetitle']),
        'link' => $_G['siteurl'] . 'plugin.php?id=strong_yq&sid=' . $shareid,
        'imgUrl' => $_G['siteurl'] . $_G['cache']['plugin']['strong_yq']['shareimg'],
        'desc' => dhtmlspecialchars(preg_replace("/\s/", '', $_G['cache']['plugin']['strong_yq']['sharedesc'])));

    return array($yqsignPackage,$shareid,$wxdata);
}


class SWF_JSSDK {
    private $appId;
    private $appSecret;

    public function __construct($appId, $appSecret) {
        $this->appId = $appId;
        $this->appSecret = $appSecret;
    }

    public function getSignPackage() {
        $jsapiTicket = $this->getJsApiTicket();


        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

        $timestamp = time();
        $nonceStr = $this->createNonceStr();

        $string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";

        $signature = sha1($string);

        $signPackage = array(
            "appId" => $this->appId,
            "nonceStr" => $nonceStr,
            "timestamp" => $timestamp,
            "url" => $url,
            "signature" => $signature,
            "rawString" => $string);
        return $signPackage;
    }

    private function createNonceStr($length = 16) {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $str = "";
        for($i = 0; $i < $length; $i++) {
            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        return $str;
    }


    private function getJsApiTicket() {
        global $_G;


        $cachename = 'wechatformatjt_'.$_G['cache']['plugin']['strong_wechat_format']['appID'];
        loadcache($cachename);
        $data = $_G['cache'][$cachename];


        if($data['expire_time'] < time()) {
            $accessToken = $this->getAccessToken();


            $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
            $res = json_decode($this->httpGet($url));
            $ticket = $res->ticket;
            if($ticket) {


                $myticket = array('expire_time' => time() + 7000, 'jsapi_ticket' => $ticket);
                savecache($cachename, $myticket);
            }
        } else {
            $ticket = $data['jsapi_ticket'];
        }

        return $ticket;
    }

    private function getAccessToken() {
        global $_G;

        $cachename = 'wechatformatat_'.$_G['cache']['plugin']['strong_wechat_format']['appID'];
        loadcache($cachename);
        $data = $_G['cache'][$cachename];

        if($data['expire_time'] < time()) {


            $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->appId&secret=$this->appSecret";
            $res = json_decode($this->httpGet($url));
            $access_token = $res->access_token;


            if($access_token) {
                $myTokenInfo = array('expire_time' => time() + 7000, 'access_token' => $access_token);
                savecache($cachename, $myTokenInfo);
            }


        } else {
            $access_token = $data['access_token'];

        }

        return $access_token;
    }

    private function httpGet($url){
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        # curl_setopt($ch, CURLOPT_HEADER, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 90); 
        curl_setopt($ch, CURLOPT_TIMEOUT, 90);  

        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);

        if(!curl_exec($ch)) {
            error_log(curl_error($ch));
            $data = '';
        } else {
            $data = curl_multi_getcontent($ch);
        }
        curl_close($ch);
        return $data;
    }

}
//From: Dism_taobao-com
?>