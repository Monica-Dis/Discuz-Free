<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}




function swf_echolang($text = '') {

    $lang = array(
        'ptext1' => '原文阅读',
        'ptext2' => '微信扫一扫<br>关注该公众号',
        'ptext3' => '微信号',
        'ptext4' => '功能介绍',
        
        'mtext1' => '在看',
        'mtext2' => '关注',
        'mtext3' => '长按二维码，关注公众号',
        'mtext4' => '历史消息',
        'mtext5' => '关闭',
        'mtext6' => '写留言',
        'mtext7' => '留言将由公众号筛选展示，对所有人可见',
        
        'ctext1' => '今天',
        'ctext2' => '昨天',
        'ctext3' => '前天',
        'ctext4' => '三天前',
        'ctext5' => '一周前',
        'ctext6' => '万',
        'ctext7' => '{0}年{1}月{2}日'
       
            
            
            );
    return $lang[$text];
}

function swf_lang($text = null, $vars = array()) {
    $return = swf_echolang($text);
    if ($vars && is_array($vars)) {
        foreach ($vars as $k => $v) {
            $searchs[] = '{' . $k . '}';
            $replaces[] = $v;
        }
    }

    $return = str_replace($searchs, $replaces, $return);
    return $return;
}
//From: Dism_taobao-com
?>