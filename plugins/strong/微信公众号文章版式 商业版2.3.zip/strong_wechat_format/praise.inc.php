<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$wechatformatset = $_G['cache']['plugin']['strong_wechat_format'];

$_G['tid'] = $_GET['tid'];

if (empty($_G['uid']) and !$wechatformatset['ontourist3']) {
    showmessage('to_login', 'member.php?mod=logging&action=login&mobile=2', array('status' =>
            18));
}

if (empty($_GET['hash']) || $_GET['hash'] != formhash()) {
    showmessage('submit_invalid');
}

if ($_GET['action'] == 'recommend') {
    $fieldarr = array();

    if (!C::t('forum_thread')->fetch($_G['tid'])) {
        showmessage(lang('plugin/strong_wechat_format', 'text4'));
    }

    if (!$_G['uid'] and $wechatformatset['ontourist3']) {
        if ($_G["cookie"]["strong_recommend_tid_" . $_G['tid']]) {
            dsetcookie('strong_recommend_tid_' . $_G['tid'], 0);
            $fieldarr['recommend_add'] = -1;
            $fieldarr['recommends'] = -1;
            C::t('forum_thread')->increase($_G['tid'], $fieldarr);
            showmessage('recommend_succeed', 'href="forum.php?mod=viewthread&tid=' . $_G['tid'],
                array(
                'praise' => 'recommend',
                'tid' => $_G['tid'],
                'status' => 1));
        } else {
            dsetcookie('strong_recommend_tid_' . $_G['tid'], 1, 31536000);
            $fieldarr['recommend_add'] = 1;
            $fieldarr['recommends'] = 1;
            C::t('forum_thread')->increase($_G['tid'], $fieldarr);
            showmessage('recommend_succeed', 'href="forum.php?mod=viewthread&tid=' . $_G['tid'],
                array(
                'praise' => 'recommend',
                'tid' => $_G['tid'],
                'status' => 2));
        }

    } elseif ($_G['uid']) {
        if (C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $_G['tid'])) {
            $fieldarr['recommend_add'] = -1;
            $fieldarr['recommends'] = -1;
            C::t('forum_thread')->increase($_G['tid'], $fieldarr);

            if ($_G['uid']) {
                DB::delete('forum_memberrecommend', array('tid' => $_G['tid'], 'recommenduid' =>
                        $_G['uid']));
            }

            showmessage('recommend_succeed', 'href="forum.php?mod=viewthread&tid=' . $_G['tid'],
                array(
                'praise' => 'recommend',
                'tid' => $_G['tid'],
                'status' => 1));

        } else {
            $fieldarr['recommend_add'] = 1;
            $fieldarr['recommends'] = 1;
            C::t('forum_thread')->increase($_G['tid'], $fieldarr);
            C::t('forum_memberrecommend')->insert(array(
                'tid' => $_G['tid'],
                'recommenduid' => $_G['uid'],
                'dateline' => $_G['timestamp']));

            showmessage('recommend_succeed', 'href="forum.php?mod=viewthread&tid=' . $_G['tid'],
                array(
                'praise' => 'recommend',
                'tid' => $_G['tid'],
                'status' => 2));

        }
    }


} elseif ($_GET['action'] == 'support') {

    $typeid = 1;    
    $post = C::t('forum_post')->fetch('tid:' . $_GET['tid'], $_GET['pid'], false);


    if (empty($post) || $post['first'] == 1) {
        showmessage('undefined_action', null);
    }

    $hotreply = C::t('forum_hotreply_number')->fetch_by_pid($post['pid']);


    if (empty($hotreply)) {
        $hotreply['pid'] = C::t('forum_hotreply_number')->insert(array(
            'pid' => $post['pid'],
            'tid' => $post['tid'],
            'support' => 0,
            'against' => 0,
            'total' => 0,
            ), true);
    }

    if ($_G['uid']) {
        if(C::t('forum_hotreply_member')->fetch($post['pid'], $_G['uid']) ){            
            DB::query('UPDATE %t SET support = support-1, total=total-1 WHERE pid=%d', array('forum_hotreply_number', $post['pid']));
            DB::delete('forum_hotreply_member', array('tid' => $post['tid'], 'pid' => $post['pid'],'uid'=>$_G['uid']));
            showmessage('grouprecommend_succeed', 'href="forum.php?mod=viewthread&tid=' . $_G['tid'],
                array(
                'praise' => 'support',
                'tid' => $_G['tid'],
                'pid' => $post['pid'],
                'status' => 1));
        }else{
            DB::query('UPDATE %t SET support = support+1, total=total+1 WHERE pid=%d', array('forum_hotreply_number', $post['pid']));
            C::t('forum_hotreply_member')->insert(array(
            'tid' => $post['tid'],
            'pid' => $post['pid'],
            'uid' => $_G['uid'],
            'attitude' => $typeid,
            ));
            showmessage('grouprecommend_succeed', 'href="forum.php?mod=viewthread&tid=' . $_G['tid'],
                array(
                'praise' => 'support',
                'tid' => $_G['tid'],
                'pid' => $post['pid'],
                'status' => 2));
        }
  
    }else{
        if($_G["cookie"]["strong_support_pid_" .$post['pid']]){
            DB::query('UPDATE %t SET support = support-1, total=total-1 WHERE pid=%d', array('forum_hotreply_number', $post['pid']));
            dsetcookie('strong_support_pid_' . $post['pid'], 0);
            showmessage('grouprecommend_succeed', 'href="forum.php?mod=viewthread&tid=' . $_G['tid'],
                array(
                'praise' => 'support',
                'tid' => $_G['tid'],
                'pid' => $post['pid'],
                'status' => 1));
        
        }else{
            DB::query('UPDATE %t SET support = support+1, total=total+1 WHERE pid=%d', array('forum_hotreply_number', $post['pid']));
            dsetcookie('strong_support_pid_' . $post['pid'], 1, 31536000);
            showmessage('grouprecommend_succeed', 'href="forum.php?mod=viewthread&tid=' . $_G['tid'],
                array(
                'praise' => 'support',
                'tid' => $_G['tid'],
                'pid' => $post['pid'],
                'status' => 2));
        }
    }
    


} elseif ($_GET['action'] == 'add') {
    global $_G;
    $aid = $_GET['aid'];
    $item = C::t('portal_article_title')->fetch($aid);
    $tablename = 'portal_article_title';
    if (!$item) {
        showmessage('click_item_error');
    }


    if (C::t('home_clickuser')->count_by_uid_id_idtype($_G['uid'], $aid, 'aid') and
        $_G['uid']) {
        showmessage('click_have');
    } elseif (!$_G['uid'] and $wechatformatset['ontourist3'] and $_G["cookie"]["strong_add_aid_" .
    $aid]) {
        showmessage('click_have');
    }
    if ($_G['uid']) {
        $setarr = array(
            'uid' => $_G['uid'],
            'username' => $_G['username'],
            'id' => $aid,
            'idtype' => 'aid',
            'clickid' => '1',
            'dateline' => $_G['timestamp']);
        C::t('home_clickuser')->insert($setarr);
    }

    C::t($tablename)->update_click($aid, '1', 1);
    if ($wechatformatset['ontourist3'] and !$_G['uid']) {
        dsetcookie('strong_add_aid_' . $aid, 1, 31536000);
    }


    showmessage('click_success', 'portal.php?mod=view&aid=' . $aid, array('praise' =>
            'add', 'aid' => $aid));
}
//From: Dism_taobao-com
?>