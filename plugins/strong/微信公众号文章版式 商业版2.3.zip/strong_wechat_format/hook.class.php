<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
require_once DISCUZ_ROOT . '/source/plugin/strong_wechat_format/function/function_base.php';
swf_loadlang();
class mobileplugin_strong_wechat_format {
    

    function common() {
        global $_G,$wechatformatset,$swfinwechat,$swfonforum,$swfonportal;
        $wechatformatset = $_G['cache']['plugin']['strong_wechat_format'];

        $forums = unserialize($wechatformatset['forums']);
        $groups = unserialize($wechatformatset['groups']);        
        $swfinwechat = 1;
        if(strpos($_SERVER["HTTP_USER_AGENT"], "MicroMessenger") !== false) {
            define("SWFINWECHAT",1);
        }
        foreach($groups as $key => $val) {
            $ongroups .= $val . '	';
        }
        $portals = $wechatformatset['portals'];

        
        if($_G['basescript'] == 'forum' and ($_G['mod'] == 'viewthread' || $_GET['action'] == 'reply')) {
      
            $swfonforum = in_array('', $forums) ? false : (in_array($_G['fid'], $forums) ? true : false);
        }


        if($_G['basescript'] == 'portal' and ($_G['gp_mod'] == 'view' || $_G['gp_mod'] == 'comment' || $_GET['mod'] == 'portalcp')) {
            if($_G['gp_mod'] == 'view') {
                $articleid = $_G['gp_aid'];
            } elseif($_G['gp_mod'] == 'comment') {
                $articleid = $_G['gp_id'];
            } elseif($_GET['mod'] == 'portalcp') {
                $articleid = $_POST['aid'];
            } else {
                $articleid = 0;
            }

            $article = DB::fetch_first("SELECT * FROM " . DB::table('portal_article_title') . " WHERE aid=" . intval($articleid));
            if($article) {
                $swfonportal = in_array($article['catid'], explode(',', $portals)) ? true : false;
            }
        }
     
        if($wechatformatset['onweixin']) {
            if(!defined("SWFINWECHAT")) {
                $swfinwechat = 0;
            }
        }
        
        
        if(($swfonforum || $swfonportal) and $swfinwechat) {
            
            if(!$_G['uid']) {
                $_G['setting']['need_avatar'] = 0;
                $_G['setting']['need_email'] = 0;
                $_G['forum']['allowreply'] = $wechatformatset['ontourist'] ? $ongroups : $_G['forum']['replyperm'];
                $_G['forum']['replyperm'] = $wechatformatset['ontourist'] ? $ongroups : $_G['forum']['replyperm'];
                $_G['group']['allowcommentarticle'] = $wechatformatset['ontourist'] ? 1000 : $_G['forum']['allowcommentarticle'];
                $_G['forum']['getattachperm'] = $wechatformatset['ontourist2'] ? $ongroups : $_G['forum']['getattachperm'];

            }

            if(($wechatformatset['onaudit1'] and $_G['uid']) || ($wechatformatset['onaudit2'] and !$_G['uid'])) {
                $_G['group']['allowdirectpost'] = 0;
                $_G['forum']['modnewposts'] = 2;
            }

        }
            
        
       
        if($wechatformatset['virtualpraise']) {
            $praisearr = explode(',', $wechatformatset['virtualpraise']);
            $_G['forum_thread']['recommend_add'] = ceil(($_G['forum_thread']['recommend_add'] + $praisearr[0]) * $praisearr[1]);

        }
        if($wechatformatset['virtualview']) {
            $praisearr = explode(',', $wechatformatset['virtualview']);
            $_G['forum_thread']['views'] = ceil(($_G['forum_thread']['views'] + $praisearr[0]) * $praisearr[1]);

        }
        $oncomment = 0;
        if($wechatformatset['ordertype']){
            $_GET['ordertype']=1;            
        }
     


    }


    function global_header_mobile() {
        global $_G, $signPackage, $wxdata, $article, $metadescription,$navtitle;
        $wechatformatset = $_G['cache']['plugin']['strong_wechat_format'];
        $forums = unserialize($wechatformatset['forums']);

        
        if(strpos($_SERVER["HTTP_USER_AGENT"], "MicroMessenger") === false) {
            return '';
        }

        if($_G['fid'] and !in_array($_G['fid'], $forums)) {
            return '';
        }

        $portals = $wechatformatset['portals'];
        if($article['catid'] and !in_array($article['catid'], explode(',', $portals))) {
            return '';
        }

    

        if($wechatformatset['wxshare']) {
            if($_G['cache']['plugin']['strong_wxlogin']['wxshare']){
                global $wechat_client;
                $signPackage = $wechat_client->getSignPackage();
            }else{
                $jssdk = new SWF_JSSDK($wechatformatset['appID'], $wechatformatset['appsecret']);
                $signPackage = $jssdk->GetSignPackage();
            }

            include_once template('strong_wechat_format:module');

            if(CURSCRIPT == 'forum' && CURMODULE == 'viewthread') {

                $attachtableid = getattachtablebytid(intval($_G['tid']));
                $attach = DB::fetch_first("SELECT * FROM " . DB::table($attachtableid) . " WHERE tid = ".intval($_G['tid'])." and (isimage=1 or isimage='-1')");          
           

                $imgurl = $attach['attachment'] ? $_G['siteurl'].getforumimg($attach['aid'], 0, 180, 180) : $wechatformatset['wxsharepic'];

                $wxdata = array(
                    'title' => $_G['forum_thread']['subject'],
                    'link' => $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $_G['tid'],
                    'imgUrl' => $imgurl,
                    'desc' => dhtmlspecialchars($metadescription));
                return tpl_swf_jssdk_share();
                
            }elseif(CURSCRIPT == 'forum' && CURMODULE == 'forumdisplay') {

                $wxdata = array(
                    'title' => $wechatformatset['mpname'],
                    'link' => $_G['siteurl'] . 'forum.php?mod=forumdisplay&fid=' . $_G['fid'],
                    'imgUrl' => $wechatformatset['wxsharepic'],
                    'desc' => dhtmlspecialchars($wechatformatset['mpdesc']));
                return tpl_swf_jssdk_share();    
                
            } elseif(CURSCRIPT == 'portal' && CURMODULE == 'view') {
                    $wxdata = array(
                        'title' => $article['title'],
                        'link' => $_G['siteurl'] . 'portal.php?mod=view&aid=' . $article['aid'],
                        'imgUrl' =>  $article['pic'] ? $_G['siteurl'] . $article['pic'] : $wechatformatset['wxsharepic'],
                        'desc' => dhtmlspecialchars(preg_replace("/\s/", '', $article['summary'])));
                    return tpl_swf_jssdk_share();
                }


        }
        return '';
    }

    function global_footer_mobile() {
        global $_G,$wechatformatset,$swfinwechat,$swfonforum,$swfonportal,$article,$content,$commentlist,$clicks,$navtitle;
        if(!$wechatformatset['onmobile']){
            return '';
        }
        if(!$swfonportal or !$swfinwechat){
            return '';
        }
        if(defined("SWFINWECHAT")){
            $navtitle = $wechatformatset['mpname'];
        }
        $article['dateline'] = strtotime($article['dateline']);
        $article['datetext'] = swf_date($article['dateline']);
        $article['dateline'] = date('Y-m-d',$article['dateline']); 
        $content['content']=swf_filtration($content['content']);
        include_once template('strong_wechat_format:portal/view');exit(); 
    }


}


class mobileplugin_strong_wechat_format_forum extends mobileplugin_strong_wechat_format {

    function viewthread_bottom_mobile_output() {
        global $_G,$wechatformatset,$postlist,$aimgs,$recommendv_add,$swfinwechat,$swfonforum,$swfonportal,$totalpage,$navtitle,$secqaacheck,$seccodecheck;
        $recommendv_add = 0;
        if(!$wechatformatset['onmobile']){
            return '';
        }
        if(!$swfonforum or !$swfinwechat){
            return '';
        }
        
        if(defined("SWFINWECHAT")){
            $navtitle = $wechatformatset['mpname'];
        }
        
        $_G['forum_thread']['datetext'] = swf_date($_G['forum_thread']['dateline']);
        $_G['forum_thread']['dateline'] = date('Y-m-d',$_G['forum_thread']['dateline']);        
        $_G['forum_thread']['views'] = swf_view($_G['forum_thread']['views']);
        $_G['cache']['plugin']['strong_wechat_format']['onoriginallink'] = $wechatformatset['onoriginallinkforum'] ? $_G['siteurl'].'forum.php?mod=forumdisplay&fid='.$_G['fid'] : $wechatformatset['onoriginallink'];
        
        
        if($wechatformatset['onshowpraise']){
            if(!$_G['uid'] and $wechatformatset['ontourist3'] and $_G["cookie"]["strong_recommend_tid_" . $_G['tid']]){
                $recommendv_add = 1;
            }elseif($_G['uid'] and C::t('forum_memberrecommend')->fetch_by_recommenduid_tid($_G['uid'], $_G['tid'])){
                $recommendv_add = 1;
            }
            
            foreach($postlist as $postk=>$postv){
                
                $postlist[$postk]['message'] = swf_messageimg($postlist[$postk]['message'],$postv);
                
                if($_G['uid']){
                    $hotreply = DB::fetch_first('SELECT * FROM %t WHERE pid=%d AND uid=%d AND attitude=1', array('forum_hotreply_member', $postv['pid'], $_G['uid']));
                    if($hotreply){                        
                        $postlist[$postk]['spraise']=1;
                    }
                }else{
                    if($_G["cookie"]["strong_support_pid_" .$postv['pid']]){
                        $postlist[$postk]['spraise']=1;
                    }
                }
                
            }
        
        }
        

        include_once template('strong_wechat_format:forum/viewthread');
        exit();
       
    }

    function forumdisplay_bottom_mobile_output(){
        global $_G,$wechatformatset,$realpages,$navtitle,$swfonforum,$swfinwechat;
        if(!$wechatformatset['onmobile']){
            return '';
        }
        
        $forums = unserialize($wechatformatset['forums']);
        $swfonforum = in_array('', $forums) ? false : (in_array($_G['fid'], $forums) ? true : false);
        
        if(defined("SWFINWECHAT") and $wechatformatset['listtitlename']){
            $navtitle = $wechatformatset['mpname'];
        }

        if(!$swfonforum or !$swfinwechat){
            return '';
        }
        
        if(!$wechatformatset['onthreadlist']){
            return '';
        }
        
        foreach($_G['forum_threadlist'] as $k=>$thread){
            $_G['forum_threadlist'][$k]['threadimg'] = swf_getthreadimg($thread['tid']); 
            $dateline = strtotime($thread['dateline']);
            if(intval($dateline)){
                $_G['forum_threadlist'][$k]['dateline'] = swf_lang('ctext7',array(date('Y',$dateline),date('m',$dateline),date('d',$dateline)));
            }
            
            
        }

        include_once template('strong_wechat_format:forum/forumdisplay');
        exit();
    }

}


//From: dis'.'m.tao'.'bao.com
?>