<?php
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql = <<<EOF
    DROP TABLE IF EXISTS `pre_strong_wxnotice_setting`;
    DROP TABLE IF EXISTS `pre_strong_wxnotice_tmplmsg`;
EOF;
runquery($sql);
    
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/function/function_base.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/function/function_common.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/template/spacecp.htm');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/template/touch/index.htm');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/template/touch/footer.htm');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/template/touch/header.htm');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/hook.class.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/admincp_tmplmsg.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/spacecp.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/more.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/newplugin.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/customization.inc.php');
$finish = TRUE;


?>