<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . '/source/plugin/strong_wxnotice/function/function_common.php';
$sql = <<<EOF
CREATE TABLE `pre_strong_wxnotice_setting` (
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `svalue` text CHARACTER SET gbk NOT NULL,
  `stime` text CHARACTER SET gbk NOT NULL,
  PRIMARY KEY (`uid`)
) ENGINE=MyISAM;

CREATE TABLE `pre_strong_wxnotice_tmplmsg` (
  `id` bigint(255) unsigned NOT NULL AUTO_INCREMENT,
  `msgid` bigint(255) unsigned NOT NULL,
  `openid` char(32) NOT NULL DEFAULT '',
  `template` varchar(64) NOT NULL DEFAULT '',
  `url` varchar(128) NOT NULL DEFAULT '',
  `topcolor` char(6) NOT NULL DEFAULT '',
  `data` text NOT NULL,
  `returncode` text NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT '',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `type` varchar(64) NOT NULL DEFAULT '',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`,`msgid`)
) ENGINE=MyISAM AUTO_INCREMENT=6;

EOF;
runquery($sql);
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxnotice/discuz_plugin_strong_wxnotice_TC_UTF8.xml');
$finish = TRUE;


?>