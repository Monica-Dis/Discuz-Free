<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function swxn_anyone($post) {
    global $_G,$thread;
    if ($post) {
        $atlist = $atlist_tmp = array();
        preg_match_all("/@([^\r\n]*?)\s/i", $post['message'] . ' ', $atlist_tmp);
        $atlist_tmp = array_slice(array_unique($atlist_tmp[1]), 0, $_G['group']['allowat']);
        foreach ($atlist_tmp as $listk => $listv) {
            $atlist_tmp[$listk] = preg_replace('/\[\/url\]/', '', $listv);
        }
        if (!empty($atlist_tmp)) {
            if (!$_G['setting']['at_anyone']) {
                foreach (C::t('home_follow')->fetch_all_by_uid_fusername($post['authorid'], $atlist_tmp) as $row) {
                    $atlist[$row['followuid']] = $row['fusername'];
                }

                if (count($atlist) < $_G['group']['allowat']) {
                    $query = C::t('home_friend')->fetch_all_by_uid_username($post['authorid'], $atlist_tmp);
                    foreach ($query as $row) {
                        $atlist[$row['fuid']] = $row['fusername'];
                    }
                }
            } else {
                foreach (C::t('common_member')->fetch_all_by_username($atlist_tmp) as $row) {
                    $atlist[$row['uid']] = $row['username'];
                }
            }
        }
        $messagecutstr = messagecutstr(dhtmlspecialchars($post['message']), 100);
        $find = array(
            '{bbname}',
            '{username}',
            '{subject}',
            '{message}');
        $replace = array(
            $_G['setting']['bbname'],
            $post['author'],
            $thread['subject'],
            $messagecutstr);

        $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=mypost&type=at';

        $data = swxn_tmpldata('at', $find, $replace);
        foreach ($atlist as $uid=>$list) {
            if($_G['uid']!=$uid){
                swxn_sendnotification('at', $uid, $detail_url, $data);
            }
        }
        return $atlist;

    }
}

function swxn_keyword($num = 2) {
    if ($num == 5) {
        $return = array(
            'first',
            'keyword1',
            'keyword2',
            'keyword3',
            'keyword4',
            'keyword5',
            'remark');
    } elseif ($num == 4) {
        $return = array(
            'first',
            'keyword1',
            'keyword2',
            'keyword3',
            'keyword4',
            'remark');
    } elseif ($num == 3) {
        $return = array(
            'first',
            'keyword1',
            'keyword2',
            'keyword3',
            'remark');
    } else {
        $return = array(
            'first',
            'keyword1',
            'keyword2',
            'remark');
    }
    return $return;
}

function swxn_tmpldata($type, $find, $replace) {
    global $_G;
    loadcache('setting');
    $setting = (array )unserialize($_G['setting']['strong_wxnotice']);
    $return = array();
    if ($setting['wxnotice_tmpl'][$type]['data']) {
        foreach (swxn_keyword($setting['wxnotice_tmpl'][$type]['data']['keynum']) as $val) {
            $keyname = $setting['wxnotice_tmpl'][$type]['data'][$val . '_name'] ? $setting['wxnotice_tmpl'][$type]['data'][$val . '_name'] : $val;
            $return[$keyname]['value'] = str_replace($find, swxn_replace($replace), swxn_replace($setting['wxnotice_tmpl'][$type]['data'][$val]));
            $return[$keyname]['color'] = swxn_tmpldatacolor($type, $setting['wxnotice_tmpl'][$type]['data'][$val . '_color']);
        }
    } else {
        foreach (swxn_keyword() as $val) {
            $return[$val]['value'] = str_replace($find, swxn_replace($replace), swxn_replace(swxn_lang('admincp_config_' . $type . '_tmpldata_' . $val)));
            $return[$val]['color'] = swxn_tmpldatacolor($type, $val);

        }


    }

    return $return;
}

function swxn_replace($str) {
    if (is_array($str)) {
        foreach ($str as $k => $v) {
            $str[$k] = diconv(trim($v), CHARSET, 'UTF-8');
        }
    } else {
        $str = str_replace(array('{date}'), array(dgmdate(TIMESTAMP)), diconv(trim($str), CHARSET, 'UTF-8'));
    }
    return $str;
}


function swxn_tmpldatacolor($type, $data) {
    global $_G;
    loadcache('setting');
    $setting = (array )unserialize($_G['setting']['strong_wxnotice']);
    if ($setting['wxnotice_tmpl'][$type]['data'][$data . "_color"]) {
        return $setting['wxnotice_tmpl'][$type]['data'][$data . "_color"];
    } else {
        return "#000000";
    }
}

function swxn_showsetting($setname, $varname, $value, $type = 'text',$des=''){    
    
    switch($type){
        case 'text':
            $s = '<input type="text" name="'.$varname.'" value="'.$value.'">';
            break;
        case 'radio':
      		$value ? $check['true'] = "checked" : $check['false'] = "checked";
    		$value ? $check['false'] = '' : $check['true'] = '';
    		$check['hidden1'] = $hidden ? ' onclick="$(\'hidden_'.$setname.'\').style.display = \'\';"' : '';
    		$check['hidden0'] = $hidden ? ' onclick="$(\'hidden_'.$setname.'\').style.display = \'none\';"' : '';
    		$onclick = $disabled && $disabled == 'readonly' ? ' onclick="return false"' : ($extra ? $extra : '');
    		$s .= '<ul onmouseover="altStyle(this'.$check['disabledaltstyle'].');">'.
    			'<li'.($check['true'] ? ' class="checked"' : '').'><input class="radio" type="radio"'.($varnameid ? ' id="_v1_'.$varnameid.'"' : '').' name="'.$varname.'" value="1" '.$check['true'].$check['hidden1'].$check['disabled'].$onclick.'>&nbsp;'.cplang('yes').'</li>'.
    			'<li'.($check['false'] ? ' class="checked"' : '').'><input class="radio" type="radio"'.($varnameid ? ' id="_v0_'.$varnameid.'"' : '').' name="'.$varname.'" value="0" '.$check['false'].$check['hidden0'].$check['disabled'].$onclick.'>&nbsp;'.cplang('no').'</li>'.
    			'</ul>';
            break;    
        default:
            return '';
            break;
    }  
    
    $return  = showtablerow('',array('','class="rowform"'),array(
            $setname,
            $s,
            $des
            )); 
    return $return;
}

function showcolorsetting($id, $name, $value) {

    return '<input id="c' . $id . '_v" type="text" class="txt" style="float:left; width:80px;" value="' . $value . '" name="' . $name .
        '" onchange="updatecolorpreview(\'c' . $id . '\')">
<input id="c' . $id . '" onclick="c' . $id . '_frame.location=\'static/image/admincp/getcolor.htm?c' . $id . '|c' . $id . '_v\';showMenu({\'ctrlid\':\'c' .
        $id . '\'})" type="button" class="colorwd" value="" style="background:' . $value . '">
<span id="c' . $id . '_menu" style="display: none"><iframe name="c' . $id .
        '_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe></span>
';
}


function swxn_loadlang() {
    $language = 'language.' . currentlang() . '.php';
    require_once DISCUZ_ROOT . '/source/plugin/strong_wxnotice/' . $language;
}

function sxwn_type() {
    $types = array(
        'login',
        'post',
        'dianping',
        'at',
        'reward',
        'activity_completion',
        'activity_auditing1',
        'activity_auditing2',
        'activity_delete',
        'activity_notification',
        'activity_invite',
        'votepoll',
        'pm',
        'friendsend',
        'friendadd',
        'follow',
        'poke',
        'comment',
        'report',
        'announcement'
        );

    return $types;
}

function swxn_sendnotification($type, $uid, $detail_url, $data) {
    global $_G;
    $swxnoticeset = unserialize($_G['setting']['strong_wxnotice']);
    loadcache('plugin');

    if (!$swxnoticeset['wxnotice_tmpl'][$type]['enable']) {
        return '';
    }
    $wxnotice_setting = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('strong_wxnotice_setting', intval($uid)));
    if ($wxnotice_setting) {
        $wxnotice_datasetting = unserialize($wxnotice_setting['svalue']);
        if ($wxnotice_datasetting and !$wxnotice_datasetting[$type]) {
            return '';
        }
        $wxnotice_timesetting = (array )unserialize($wxnotice_setting['stime']);

    } else {
        DB::insert('strong_wxnotice_setting', array('uid' => $uid), true);
    }


    $strongwxsetting = unserialize($_G['setting']['strong_wxlogin']);
    $swxloginset = $_G['cache']['plugin']['strong_wxlogin'];
    $wechat_client = new WeChatClient($_G['strong_wxlogin']['setting']['wechat_appId'], $_G['strong_wxlogin']['setting']['wechat_appsecret']);

    $tmpl_id = $swxnoticeset['wxnotice_tmpl'][$type]['id'];

    $wxbindinfo = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array('strong_wxlogin_bind', intval($uid)));

    if (!$wxbindinfo) {
        return '';
    }
    $topcolor = '#f00';

    if ((intval($wxnotice_timesetting[$type]) + intval($swxnoticeset['wxnotice_tmpl'][$type]['sendflood'])) < TIMESTAMP) {
        $wxnotice_timesetting[$type] = TIMESTAMP;
        $wxnotice_timesetting = serialize($wxnotice_timesetting);

        DB::update('strong_wxnotice_setting', array('stime' => $wxnotice_timesetting), array('uid' => $uid));

    } else {
        return '';
    }

    $result = $wechat_client->sendTemplateMsg($tmpl_id, $wxbindinfo['openid'], $uid, $type, $detail_url, $topcolor, $data);


    foreach ($data as $k => $v) {
        $data[$k]['value'] = diconv($v['value'], 'UTF-8', CHARSET);
    }


    DB::insert('strong_wxnotice_tmplmsg', array(
        'uid' => $uid,
        'msgid' => intval($result['msgid']),
        'type' => $type,
        'openid' => $wxbindinfo['openid'],
        'template' => $tmpl_id,
        'url' => $detail_url,
        'data' => serialize($data),
        'topcolor' => $topcolor,
        'returncode' => $result['errcode'] . '-' . $result['errmsg'],
        'status' => 0,
        'dateline' => TIMESTAMP), true);


}
//From: Dism_taobao-com
?>