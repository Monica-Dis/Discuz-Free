<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function swxn_echolang($text) {
    $lang = array(    
        'text_1'=>'[表情]',
        'spacecp_text_1'=>'修改',
        'spacecp_text_2'=>'是',
        'spacecp_text_3'=>'否',
        'spacecp_text_4'=>'类型',
        'spacecp_text_5'=>'是否提醒',
        'spacecp_text_6'=>'修改成功',
        'spacecp_text_7'=>'修改',
    
        'admincp_base_title_1' => '
        <li>本插件必须配合<a href="https://dism.taobao.com/?@strong_wxlogin.plugin" style="color:#f60" target="_blank">【strong微信登陆】</a>使用！</li>
        <li>进入<a href="http://mp.weixin.qq.com" target="_blank">微信公众平台</a>后台，模板消息 添加行业: IT科技/互联网|电子商务, 
        在模板库中添加适用的模板，请下载<a href="https://dism.taobao.com/?@strong_wxnotice.plugin.87154" style="color:red;" target="_blank">说明文档</a></li>
        <li>选择开启后有效，用户可以在微信通知设置页面根据需求自行选择开启或关闭通知。</li>
        <li>模板ID必须填入对应编码分类的模板</li>
        <li>间隔时间请根据需求设置，在间隔时间内的通知将会被忽略。</li>
    ',
        'admincp_base_title_2' => '配置',
        'admincp_base_title_3' => '编辑',
        'admincp_base_title_4' => '重置',
        'admincp_base_title_5' => '保存',     
        'admincp_base_title_6' => '
            <li>消息推送记录仅供参考，便于管理员查看消息推送状态：接口返回状态(成功/失败)、接口错误信息等等。</li>
            <li>消息接收者必须关注公众号、未屏蔽接收消息才能正常收到消息提醒。</li>
            <li>状态：接收成功表示用户成功接收到消息。failed:user block表示消息送达由于用户拒收（用户设置拒绝接收公众号消息）而失败。failed: system failed表示消息送达由于其他原因导致失败</li>
            <li>消息内容：{first}{keyword1}{keyword2}{remark}为消息模板关键字</li>
        ',
        'admincp_base_title_7' => '消息列表',
        'admincp_base_title_8' => '<span style="color:#090;">接收成功</span>',
        'admincp_base_title_9' => '
            <li style="color:#f00; font-weight:700;">群发功能容易引起用户反感，多次举报可能被封停账号，请谨慎使用。</li>
            <li>群发执行速度缓慢，请合理筛选用户。执行过程中请勿打断或关闭本页面</li>
            <li>群发公告所执行的模板为【模板消息配置】中的【公告提醒】，请先编辑好需要发送的内容，先发送到指定账号测试效果，再进行群发。</li>
            <li>【公告提醒】前的【启用】建议勾上，用户可以自行选择接收、拒收公告，如果【启用】为关闭，所有发送列表的用户都会强制接收到提醒消息。</li>  
            <li>如果用户没有关注公众号则无法接收到消息</li>  
        ',
        'admincp_base_title_10'=>'群发用户',
        'admincp_base_title_11'=>'指定用户',
        'admincp_base_title_11_d'=>'对指定的用户进行群发',
        'admincp_base_title_12'=>'用户UID',
        'admincp_base_title_12_d'=>'填写用户UID，以英文逗号间隔，例如：1,2,3,4,5',
        'admincp_base_title_13'=>'指定用户组',
        'admincp_base_title_13_d'=>'对指定用户组进行群发',
        'admincp_base_title_14'=>'跳转URL',
        'admincp_base_title_14_d'=>'跳转URL为空则跳转到网站首页',
        'admincp_base_title_15'=>'本次共推送 {0} 条数据, 请确定是否开始群发操作?',
        'admincp_base_title_16'=>'全部用户',
        'admincp_base_title_16_d'=>'对所有用户进行群发', 
        'admincp_base_title_17'=>'一共有{0}条数据，当前正在推送第{1}-{2}条数据', 
        'admincp_base_title_18'=>'推送完成',
        'admincp_base_title_19'=>'选择用户组',
        
        


        'admincp_config_title1' => '启用',
        'admincp_config_title2' => '模板类型',
        'admincp_config_title3' => '模板编号',
        'admincp_config_title4' => '模板标题',
        'admincp_config_title5' => '模板ID',
        'admincp_config_title6' => '间隔时间(秒)',
        'admincp_config_title7' => '操作',
        'admincp_config_title8' => '参数',
        'admincp_config_title9' => '消息模板',
        'admincp_config_title10' => '字体颜色',
        'admincp_config_title11' => '时间',
        'admincp_config_title12' => '消息内容',
        'admincp_config_title13' => '状态',
        'admincp_config_title14' => '返回码',
        'admincp_config_title15' => '接收者',
        'admincp_config_title16' => '关键字名',
        'admincp_config_title17' =>'个关键字',
        
        
        
        'admincp_config_first_title' => '标题',
        'admincp_config_keyword1_title' => '关键字1',
        'admincp_config_keyword2_title' => '关键字2',
        'admincp_config_keyword3_title' => '关键字3',
        'admincp_config_keyword4_title' => '关键字4',
        'admincp_config_keyword5_title' => '关键字5',
        'admincp_config_remark_title' => '备注',
        
        
        
        
        'admincp_config_global_hint' => '
            <li>通用标识列表:</li>
            <li>{date}标记：时间</li>
        ',
        
        'admincp_config_login_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:用户名</li>
            <li>{time}标记:登录时间</li>
        ',
        'admincp_config_login_type' => '登录成功',
        'admincp_config_login_code' => 'OPENTM201673425',
        'admincp_config_login_title' => '登录成功提醒',
        'admincp_config_login_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_login_tmpldata_keyword1' => '{username} ',
        'admincp_config_login_tmpldata_keyword2' => '{time}',
        'admincp_config_login_tmpldata_remark' => '您的账号{username}在{time}登录了{bbname},如果是您本人操作请忽略本提醒',




        'admincp_config_post_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:回帖者用户名</li>
            <li>{author}标记：楼主用户名</li>
            <li>{subject}标记:帖子标题</li>
            <li>{message}标记:回帖内容</li>            
            <li>回复内容长度:设置100字符，则最多显示100字符，溢出的将会被截取。</li>
        ',
        'admincp_config_post_type' => '回帖提醒',
        'admincp_config_post_code' => 'OPENTM200605630',
        'admincp_config_post_title' => '任务处理通知',
        'admincp_config_post_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_post_tmpldata_keyword1' => '{username}  回复了您的帖子: {subject}',
        'admincp_config_post_tmpldata_keyword2' => '回帖提醒',
        'admincp_config_post_tmpldata_remark' => '回复内容:{message}',
        'admincp_config_post_title1' => '回复内容长度',
        'admincp_config_post_title2' => '跳转到提醒页',
        'admincp_config_post_title2_des'=>'默认跳转到帖子页，选择是则跳转到提醒页',
        

        'admincp_config_dianping_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:点评者用户名</li>
            <li>{author}标记：楼主用户名</li>
            <li>{subject}标记:帖子标题</li>
            <li>{message}标记:回帖内容</li>            
            <li>回复内容长度:设置100字符，则最多显示100字符，溢出的将会被截取。</li>
        ',
        'admincp_config_dianping_type' => '点评提醒',
        'admincp_config_dianping_code' => 'OPENTM200605630',
        'admincp_config_dianping_title' => '任务处理通知',
        'admincp_config_dianping_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_dianping_tmpldata_keyword1' => '{username}  点评了您的帖子: {subject}',
        'admincp_config_dianping_tmpldata_keyword2' => '点评提醒',
        'admincp_config_dianping_tmpldata_remark' => '点评内容:{message}',
        'admincp_config_dianping_title1' => '点评内容长度',
        'admincp_config_dianping_title2' => '跳转到提醒页',
        'admincp_config_dianping_title2_des'=>'默认跳转到帖子页，选择是则跳转到提醒页',


        'admincp_config_reward_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:帖子作者用户名</li>
            <li>{subject}标记:帖子标题</li>
        ',
        'admincp_config_reward_type' => '悬赏提醒',
        'admincp_config_reward_code' => 'OPENTM200605630',
        'admincp_config_reward_title' => '任务处理通知',        
        'admincp_config_reward_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_reward_tmpldata_keyword1' => '您的回复被选为最佳答案',
        'admincp_config_reward_tmpldata_keyword2' => '悬赏提醒',
        'admincp_config_reward_tmpldata_remark' => '您在[{subject}]的回复被帖子作者：{username} 选为最佳答案',

        'admincp_config_votepoll_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{subject}标记:帖子标题</li>
        ',
        'admincp_config_votepoll_type' => '投票提醒',
        'admincp_config_votepoll_code' => 'OPENTM200605630',
        'admincp_config_votepoll_title' => '任务处理通知',
        'admincp_config_votepoll_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_votepoll_tmpldata_keyword1' => '用户对您的主题进行了投票',
        'admincp_config_votepoll_tmpldata_keyword2' => '投票提醒',
        'admincp_config_votepoll_tmpldata_remark' => '用户在[{subject}]中进行了投票',
        

        'admincp_config_activity_auditing1_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{subject}标记:活动标题</li>
            <li>{username}标记:活动发起人用户名</li>
            <li>{message}标记:附言</li>
        ',
        'admincp_config_activity_auditing1_type' => '活动审核通过',
        'admincp_config_activity_auditing1_code' => 'OPENTM200605630',
        'admincp_config_activity_auditing1_title' => '任务处理通知',
        'admincp_config_activity_auditing1_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_activity_auditing1_tmpldata_keyword1' => '活动{subject} 的发起人{username}批准了您的活动申请',
        'admincp_config_activity_auditing1_tmpldata_keyword2' => '活动审核通过提醒',
        'admincp_config_activity_auditing1_tmpldata_remark' => '附言:{message}',

        'admincp_config_activity_auditing2_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{subject}标记:活动标题</li>
            <li>{username}标记:活动发起人用户名</li>
            <li>{message}标记:附言</li>
        ',
        'admincp_config_activity_auditing2_type' => '活动申请需完善',
        'admincp_config_activity_auditing2_code' => 'OPENTM200605630',
        'admincp_config_activity_auditing2_title' => '任务处理通知',
        'admincp_config_activity_auditing2_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_activity_auditing2_tmpldata_keyword1' => '活动{subject} 的发起人{username}通知您需要完善活动报名信息',
        'admincp_config_activity_auditing2_tmpldata_keyword2' => '活动申请需完善提醒',
        'admincp_config_activity_auditing2_tmpldata_remark' => '附言:{message}',

        'admincp_config_activity_completion_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{subject}标记:活动标题</li>
            <li>{username}标记:申请者用户名</li>
            <li>{message}标记:留言内容</li>
        ',
        'admincp_config_activity_completion_type' => '活动申请提醒',
        'admincp_config_activity_completion_code' => 'OPENTM200605630',
        'admincp_config_activity_completion_title' => '任务处理通知',
        'admincp_config_activity_completion_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_activity_completion_tmpldata_keyword1' => '{username}申请参加活动：{subject}，请上线审核处理。',
        'admincp_config_activity_completion_tmpldata_keyword2' => '活动申请提醒',
        'admincp_config_activity_completion_tmpldata_remark' => '留言内容:{message}',

        'admincp_config_activity_delete_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{subject}标记:活动标题</li>
            <li>{username}标记:发消息者用户名</li>
            <li>{message}标记:附言</li>
        ',
        'admincp_config_activity_delete_type' => '活动拒绝提醒',
        'admincp_config_activity_delete_code' => 'OPENTM200605630',
        'admincp_config_activity_delete_title' => '任务处理通知',
        'admincp_config_activity_delete_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_activity_delete_tmpldata_keyword1' => '活动 {subject} 的发起人{username}拒绝您参加此活动',
        'admincp_config_activity_delete_tmpldata_keyword2' => '活动拒绝提醒',
        'admincp_config_activity_delete_tmpldata_remark' => '附言:{message}',


        'admincp_config_activity_notification_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{subject}标记:活动标题</li>
            <li>{username}标记:活动发起者用户名</li>
            <li>{message}标记:通知内容</li>
        ',
        'admincp_config_activity_notification_type' => '活动通知提醒',
        'admincp_config_activity_notification_code' => 'OPENTM200605630',
        'admincp_config_activity_notification_title' => '任务处理通知',
        'admincp_config_activity_notification_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_activity_notification_tmpldata_keyword1' => '活动 {subject} 的发起人{username}发来通知',
        'admincp_config_activity_notification_tmpldata_keyword2' => '活动通知提醒',
        'admincp_config_activity_notification_tmpldata_remark' => '通知内容:{message}',


        'admincp_config_activity_invite_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{subject}标记:活动标题</li>
            <li>{username}标记:活动发起者用户名</li>
        ',
        'admincp_config_activity_invite_type' => '活动邀请提醒',
        'admincp_config_activity_invite_code' => 'OPENTM200605630',
        'admincp_config_activity_invite_title' => '任务处理通知',
        'admincp_config_activity_invite_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_activity_invite_tmpldata_keyword1' => '{username} 邀请您参与活动 {subject}',
        'admincp_config_activity_invite_tmpldata_keyword2' => '活动邀请提醒',
        'admincp_config_activity_invite_tmpldata_remark' => '点击查看详情',


        'admincp_config_pm_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:发消息者用户名</li>
            <li>{message}标记:短消息</li>
        ',
        'admincp_config_pm_type' => '短消息提醒',
        'admincp_config_pm_code' => 'OPENTM200605630',
        'admincp_config_pm_title' => '任务处理通知',
        'admincp_config_pm_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_pm_tmpldata_keyword1' => '{username}发来了一条短消息',
        'admincp_config_pm_tmpldata_keyword2' => '短消息提醒',
        'admincp_config_pm_tmpldata_remark' => '消息内容:{message}',
        'admincp_config_pm_title1' => '短消息内容长度',


        'admincp_config_friendsend_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:请求者用户名</li>
            <li>{message}标记:附言内容</li>
        ',
        'admincp_config_friendsend_type' => '好友请求提醒',
        'admincp_config_friendsend_code' => 'OPENTM200605630',
        'admincp_config_friendsend_title' => '任务处理通知',        
        'admincp_config_friendsend_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_friendsend_tmpldata_keyword1' => '{username}请求添加您为好友',
        'admincp_config_friendsend_tmpldata_keyword2' => '好友请求提醒',
        'admincp_config_friendsend_tmpldata_remark' => '附言内容:{message}',
        
        
        
        'admincp_config_friendadd_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:好友用户名</li>
        ',
        'admincp_config_friendadd_type' => '好友通过提醒',
        'admincp_config_friendadd_code' => 'OPENTM200605630',
        'admincp_config_friendadd_title' => '任务处理通知',      
        'admincp_config_friendadd_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_friendadd_tmpldata_keyword1' => '{username}和您成为了好友',
        'admincp_config_friendadd_tmpldata_keyword2' => '好友通过提醒',
        'admincp_config_friendadd_tmpldata_remark' => '',
        
        
        
        
        'admincp_config_follow_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:收听者用户名</li>
        ',
        'admincp_config_follow_type' => '收听提醒',
        'admincp_config_follow_code' => 'OPENTM200605630',
        'admincp_config_follow_title' => '任务处理通知',        
        'admincp_config_follow_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_follow_tmpldata_keyword1' => '有用户收听了您',
        'admincp_config_follow_tmpldata_keyword2' => '收听提醒',
        'admincp_config_follow_tmpldata_remark' => '{username} 收听了您',
        
        
        'admincp_config_poke_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:打招呼者用户名</li>
            <li>{message}标记:打招呼内容</li>
        ',
        'admincp_config_poke_type' => '打招呼提醒',
        'admincp_config_poke_code' => 'OPENTM200605630',
        'admincp_config_poke_title' => '任务处理通知',
        'admincp_config_poke_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_poke_tmpldata_keyword1' => '{username}向您打招呼',
        'admincp_config_poke_tmpldata_keyword2' => '打招呼提醒',
        'admincp_config_poke_tmpldata_remark' => '内容：{message}',



        'admincp_config_comment_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:留言者用户名</li>
            <li>{message}标记:留言内容</li>
        ',
        'admincp_config_comment_type' => '留言提醒',
        'admincp_config_comment_code' => 'OPENTM200605630',
        'admincp_config_comment_title' => '任务处理通知',        
        'admincp_config_comment_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_comment_tmpldata_keyword1' => '{username}给您留言了',
        'admincp_config_comment_tmpldata_keyword2' => '留言提醒',
        'admincp_config_comment_tmpldata_remark' => '留言内容：{message}',
        'admincp_config_comment_title1' => '留言内容长度',
        

        'admincp_config_report_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:举报者用户名</li>
            <li>{message}标记:举报理由</li>
            <li>{url}标记:举报页面URL</li>
            <li>指定管理员：填写用户ID，用英文逗号分隔，当有用户举报时，系统会给指定的管理员发送提醒通知。示例：1,2,3,4,5</li>
        ',
        'admincp_config_report_type' => '举报处理提醒',
        'admincp_config_report_code' => 'OPENTM200605630',
        'admincp_config_report_title' => '任务处理通知',
        'admincp_config_report_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_report_tmpldata_keyword1' => '{username}举报了页面，请尽快处理。',
        'admincp_config_report_tmpldata_keyword2' => '举报处理提醒',
        'admincp_config_report_tmpldata_remark' => '举报页面:{url}。举报理由：{message}。',
        'admincp_config_report_title1' => '指定管理员',        
        
        
        'admincp_config_at_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:回帖者用户名</li>
            <li>{subject}标记:帖子标题</li>
            <li>{message}标记:回帖内容</li>
        ',
        'admincp_config_at_type' => '有人@提醒',
        'admincp_config_at_code' => 'OPENTM200605630',
        'admincp_config_at_title' => '任务处理通知',
        'admincp_config_at_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_at_tmpldata_keyword1' => '{username}在主题 {subject} 中提到了您',
        'admincp_config_at_tmpldata_keyword2' => '有人@提醒',
        'admincp_config_at_tmpldata_remark' => '回复内容:{message}',
        
        
        'admincp_config_announcement_hint' => '
            <li>可以自由的修改消息模板格式，必须保证标记代码的完整性</li>
            <li>{bbname}标记:网站名称</li>
            <li>{username}标记:接受者用户名</li>
        ',
        'admincp_config_announcement_type' => '公告提醒',
        'admincp_config_announcement_code' => 'OPENTM200605630',
        'admincp_config_announcement_title' => '任务处理通知',
        'admincp_config_announcement_tmpldata_first' => '您收到一条{bbname}的提醒消息',
        'admincp_config_announcement_tmpldata_keyword1' => '2019年度积分清零公告',
        'admincp_config_announcement_tmpldata_keyword2' => '公告提醒',
        'admincp_config_announcement_tmpldata_remark' => '尊敬的 {username} 您好，为感谢您长期对本站的支持，保障您的积分权益，特此通知：2020-03-1将进行常规清零,请尽快到本站积分商城兑换商品，以免积分清零给您造成不必要的损失。',
        );

    return $lang[$text];
}

function swxn_lang($text = null, $vars = array()) {
    $return = swxn_echolang($text);
    if ($vars && is_array($vars)) {
        foreach ($vars as $k => $v) {
            $searchs[] = '{' . $k . '}';
            $replaces[] = $v;
        }
    }

    $return = str_replace($searchs, $replaces, $return);
    return $return;
}
//From: Dism_taobao-com
?>