<?php

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT . '/source/plugin/strong_wxnotice/function/function_base.php';
swxn_loadlang();
class plugin_strong_wxnotice {

    function common() {
        global $_G, $swxnoticeset;
        $swxnoticeset = unserialize($_G['setting']['strong_wxnotice']);
        if ($_GET['showtokeninfo'] == 'yes' and $_GET['pid'] == 'strong_wxnotice') {
            require_once DISCUZ_ROOT . '/source/plugin/strong_wxnotice/function/function_common.php';
        }


    }

}


class plugin_strong_wxnotice_forum extends plugin_strong_wxnotice {

    function post_success_message($params) {
        global $_G, $swxnoticeset, $thread, $pid, $nauthorid;
        list($ac, $nauthorid) = explode('|', authcode($_GET['noticeauthor'], 'DECODE'));
        $nauthorid = $nauthorid ? $nauthorid : $thread['authorid'];
        $post = C::t('forum_post')->fetch('tid:' . $params['param'][2]['tid'], $params['param'][2]['pid']);
        require_once libfile('function/post');

        if($params['param'][0] == 'post_newthread_succeed' or $params['param'][0] == 'post_reply_succeed'){
            $atlist = swxn_anyone($post);
        }

        if ($params['param'][0] == 'post_reply_succeed' && $nauthorid != $_G['uid'] && !$atlist[$nauthorid]) {
            $pid = intval($params['param'][2]['pid']);

            $cutlength = $swxnoticeset['wxnotice_tmpl']['post']['data']['length'] ? intval($swxnoticeset['wxnotice_tmpl']['post']['data']['length']) :
                100;

            $messagecutstr = messagecutstr(dhtmlspecialchars($post['message']), $cutlength);
            $find = array(
                '{bbname}',
                '{username}',
                '{subject}',
                '{message}',
                '{author}');
            $replace = array(
                $_G['setting']['bbname'],
                $post['author'],
                $thread['subject'],
                $messagecutstr,
                $thread['author']);
            if($swxnoticeset['wxnotice_tmpl']['post']['data']['url']){
                $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=mypost&type=post';
            }else{
                $detail_url = $_G['siteurl'] .'forum.php?mod=viewthread&tid='.$post['tid'];
            }
           
            
            $data = swxn_tmpldata('post', $find, $replace);
            
            swxn_sendnotification('post', $nauthorid, $detail_url, $data);
        }elseif($params['param'][0] == 'comment_add_succeed' && $nauthorid != $_G['uid']){
            global $comment;
            $pid = intval($params['param'][2]['pid']);

            $cutlength = $swxnoticeset['wxnotice_tmpl']['dianping']['data']['length'] ? intval($swxnoticeset['wxnotice_tmpl']['dianping']['data']['length']) :
                100;

            $messagecutstr = messagecutstr(dhtmlspecialchars($comment), $cutlength);
            $find = array(
                '{bbname}',
                '{username}',
                '{subject}',
                '{message}',
                '{author}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $thread['subject'],
                $messagecutstr,
                $thread['author']);
            if($swxnoticeset['wxnotice_tmpl']['dianping']['data']['url']){
                $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=mypost&type=pcomment';
            }else{
                $detail_url = $_G['siteurl'] .'forum.php?mod=viewthread&tid='.$post['tid'];
            }
           
            
            $data = swxn_tmpldata('dianping', $find, $replace);
            
            swxn_sendnotification('dianping', $nauthorid, $detail_url, $data);
            
            
        }


    }

    function misc_bestanswer_message($params) {
        global $_G, $post, $thread;
        $uid = intval($post['authorid']);

        if ($params['param'][0] == 'reward_completion' and $_G['uid'] != $uid) {
            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=mypost&type=reward';

            $find = array(
                '{bbname}',
                '{username}',
                '{subject}');
            $replace = array(
                $_G['setting']['bbname'],
                $thread['author'],
                $thread['subject']);

            $data = swxn_tmpldata('reward', $find, $replace);
            swxn_sendnotification('reward', $uid, $detail_url, $data);
        }

    }

    function misc_votepoll_message($params) {
        global $_G, $thread;

        if ($params['param'][0] == 'thread_poll_succeed' and $thread['authorid'] != $_G['uid']) {
            $detail_url = $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $thread['tid'];
            $find = array('{bbname}', '{subject}');
            $replace = array($_G['setting']['bbname'], $thread['subject']);


            $data = swxn_tmpldata('votepoll', $find, $replace);
            swxn_sendnotification('votepoll', $thread['authorid'], $detail_url, $data);
        }

    }

    function misc_activity_message($params) {
        global $_G, $thread, $activity, $uidarray, $activity_subject, $reason;

        $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=mypost';
        switch ($params['param'][0]) {

            case 'activity_completion':
                global $message;

                $find = array(
                    '{bbname}',
                    '{username}',
                    '{subject}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $thread['subject'],
                    $message);

                $data = swxn_tmpldata('activity_completion', $find, $replace);

                if ($thread['authorid'] != $_G['uid']) {
                    swxn_sendnotification('activity_completion', $thread['authorid'], $detail_url, $data);
                }
                break;

            case 'activity_auditing_completion':

                global $unverified, $verified;
                $verified = !$verified ? 1 : $verified;
                $find = array(
                    '{bbname}',
                    '{username}',
                    '{subject}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $activity_subject,
                    $reason);

                $data = swxn_tmpldata('activity_auditing' . $verified, $find, $replace);
                foreach ($unverified as $uid) {
                    if ($uid != $_G['uid']) {
                        swxn_sendnotification('activity_auditing' . $verified, $uid, $detail_url, $data);
                    }
                }
                break;
            case 'activity_delete_completion':

                $find = array(
                    '{bbname}',
                    '{username}',
                    '{subject}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $activity_subject,
                    $reason);

                $data = swxn_tmpldata('activity_delete', $find, $replace);
                foreach ($uidarray as $uid) {
                    if ($uid != $_G['uid']) {
                        swxn_sendnotification('activity_delete', $uid, $detail_url, $data);
                    }
                }
                break;
            case 'activity_notification_success':


                $find = array(
                    '{bbname}',
                    '{username}',
                    '{subject}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $activity_subject,
                    $reason);
                $data = swxn_tmpldata('activity_notification', $find, $replace);

                foreach ($uidarray as $uid) {
                    if ($uid != $_G['uid']) {
                        swxn_sendnotification('activity_notification', $uid, $detail_url, $data);
                    }
                }
                break;
            default:
                return '';

        }

    }


}

class plugin_strong_wxnotice_misc extends plugin_strong_wxnotice {

    function report_message($params) {
        global $_G, $swxnoticeset, $url;
        $users = $swxnoticeset['wxnotice_tmpl']['report']['data']['users'] ? $swxnoticeset['wxnotice_tmpl']['report']['data']['users'] : 1;
        $users = explode(",", $users);
        if ($params['param'][0] == 'report_succeed') {

            $message = $_GET['report_select'] ? $_GET['report_select'] : censor(cutstr(dhtmlspecialchars(trim($_GET['message'])), 200, ''));

            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=manage';

            $find = array(
                '{bbname}',
                '{username}',
                '{message}',
                '{url}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $message,
                $url);

            $data = swxn_tmpldata('report', $find, $replace);

            foreach ($users as $uid) {
                if ($uid != $_G['uid']) {
                    swxn_sendnotification('report', $uid, $detail_url, $data);
                }
            }
        }
    }


    function invite_message($params) {
        global $_G, $uids, $thread;
        if ($params['param'][0] == 'group_invite_succeed' and $_GET['action'] == 'thread') {
            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=manage';

            $find = array(
                '{bbname}',
                '{username}',
                '{subject}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $thread['subject']);

            $data = swxn_tmpldata('activity_invite', $find, $replace);

            foreach ($uids as $uid) {
                if ($uid != $_G['uid']) {
                    swxn_sendnotification('activity_invite', $uid, $detail_url, $data);
                }
            }

        }
    }
}

class plugin_strong_wxnotice_home extends plugin_strong_wxnotice {

    function spacecp_pm_message($params) {
        global $_G, $swxnoticeset, $touid, $newusers, $users, $message;

        if ($_GET['op'] == 'send' && ($params['param'][0] == 'do_success' || $params['param'][0] == 'message_send_result')) {
            $touid = $touid ? $touid : $_GET['topmuid'];
            $newusers = !empty($newusers) ? $newusers : array($touid => $touid);


            foreach ($newusers as $uid => $username) {
                $uid = intval($uid);
                $cutlength = $swxnoticeset['wxnotice_tmpl']['pm']['data']['length'] ? intval($swxnoticeset['wxnotice_tmpl']['pm']['data']['length']) : 100;
                require_once libfile('function/post');
                $messagecutstr = messagecutstr(dhtmlspecialchars($message), $cutlength);

                $find = array(
                    '{bbname}',
                    '{username}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $messagecutstr);

                $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=pm&authorization=1';
                $data = swxn_tmpldata('pm', $find, $replace);

                swxn_sendnotification('pm', $uid, $detail_url, $data);
            }
        }

    }

    function spacecp_friend_message($params) {
        global $_G, $swxnoticeset, $uid;

        if ($_G['uid'] == $uid) {
            return '';
        }

        $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=interactive&type=friend';


        if ($params['param'][0] == 'request_has_been_sent') {

            $find = array(
                '{bbname}',
                '{username}',
                '{message}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $_GET['note']);


            $data = swxn_tmpldata('friendsend', $find, $replace);
            swxn_sendnotification('friendsend', $uid, $detail_url, $data);

        } else
            if ($params['param'][0] == 'friends_add') {
                $find = array(
                    '{bbname}',
                    '{username}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $messagecutstr);


                $data = swxn_tmpldata('friendadd', $find, $replace);
                swxn_sendnotification('friendadd', $uid, $detail_url, $data);
            }
    }


    function spacecp_follow_message($params) {
        global $_G, $followuid;
        if ($params['param'][0] == 'follow_add_succeed') {

            $detail_url = $_G['siteurl'] . 'home.php?mod=follow&do=follower';
            $find = array('{bbname}', '{username}');
            $replace = array($_G['setting']['bbname'], $_G['username']);
            $data = swxn_tmpldata('follow', $find, $replace);

            swxn_sendnotification('follow', $followuid, $detail_url, $data);
        }
    }

    function spacecp_poke_message($params) {
        global $_G, $pokemsg, $uid, $setarr;
        if ($params['param'][0] == 'poke_success') {
            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=interactive&type=poke';

            $notetext = $setarr['iconid'] ? lang('home/template', 'poke_' . $setarr['iconid']) : $_POST['note'];
            $find = array(
                '{bbname}',
                '{username}',
                '{message}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $notetext);

            $data = swxn_tmpldata('poke', $find, $replace);

            swxn_sendnotification('poke', $uid, $detail_url, $data);
        }
    }

    function spacecp_comment_message($params) {
        global $_G, $swxnoticeset, $id, $message;

        if ($params['param'][0] == 'do_success' and getgpc('commentsubmit') and $_G['uid'] != $id) {


            $cutlength = $swxnoticeset['wxnotice_tmpl']['comment']['data']['length'] ? intval($swxnoticeset['wxnotice_tmpl']['comment']['data']['length']) :
                100;
            require_once libfile('function/post');
            $message = preg_replace(array('/\&nbsp;/', '/\<img .*?>/'), array('', swxn_lang('text_1')), $message);
            $message = messagecutstr(dhtmlspecialchars($message), $cutlength);

            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=interactive&type=wall';
            $find = array(
                '{bbname}',
                '{username}',
                '{message}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $message);

            $data = swxn_tmpldata('comment', $find, $replace);

            swxn_sendnotification('comment', $id, $detail_url, $data);
        }

    }
}

class plugin_strong_wxnotice_member extends plugin_strong_wxnotice {
    function logging_login_message($params) {
        global $_G;


        if ($params['param'][0] == 'login_succeed') {
            $detail_url = $_G['siteurl'];
            $find = array(
                '{bbname}',
                '{username}',
                '{time}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                dgmdate(TIMESTAMP));

            $data = swxn_tmpldata('login', $find, $replace);

            swxn_sendnotification('login', $_G['uid'], $detail_url, $data);

        }
    }

}


class mobileplugin_strong_wxnotice {
    function common() {
        global $_G, $swxnoticeset;
        $swxnoticeset = unserialize($_G['setting']['strong_wxnotice']);
    }
}

class mobileplugin_strong_wxnotice_forum extends mobileplugin_strong_wxnotice {

    function post_success_message($params) {
        global $_G, $swxnoticeset, $thread, $pid, $nauthorid;
        list($ac, $nauthorid) = explode('|', authcode($_GET['noticeauthor'], 'DECODE'));
        $nauthorid = $nauthorid ? $nauthorid : $thread['authorid'];


        if ($params['param'][0] == 'post_reply_succeed' && $nauthorid != $_G['uid']) {
            require_once libfile('function/post');
            $pid = intval($params['param'][2]['pid']);
            $post = DB::fetch_first('SELECT * FROM %t WHERE pid=%d', array('forum_post', $pid));

            $cutlength = $swxnoticeset['wxnotice_tmpl']['post']['data']['length'] ? intval($swxnoticeset['wxnotice_tmpl']['post']['data']['length']) :
                100;

            $messagecutstr = messagecutstr(dhtmlspecialchars($post[message]), $cutlength);
            $find = array(
                '{bbname}',
                '{username}',
                '{subject}',
                '{message}',
                '{author}');
            $replace = array(
                $_G['setting']['bbname'],
                $post['author'],
                $thread['subject'],
                $messagecutstr,
                $thread['author']);

            if($swxnoticeset['wxnotice_tmpl']['post']['data']['url']){
                $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=mypost&type=post';
            }else{
                $detail_url = $_G['siteurl'] .'forum.php?mod=viewthread&tid='.$post['tid'];
            }
            $data = swxn_tmpldata('post', $find, $replace);


            swxn_sendnotification('post', $nauthorid, $detail_url, $data);
        }elseif($params['param'][0] == 'comment_add_succeed' && $nauthorid != $_G['uid']){
            global $comment;
            $pid = intval($params['param'][2]['pid']);

            $cutlength = $swxnoticeset['wxnotice_tmpl']['dianping']['data']['length'] ? intval($swxnoticeset['wxnotice_tmpl']['dianping']['data']['length']) :
                100;

            $messagecutstr = messagecutstr(dhtmlspecialchars($comment), $cutlength);
            $find = array(
                '{bbname}',
                '{username}',
                '{subject}',
                '{message}',
                '{author}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $thread['subject'],
                $messagecutstr,
                $thread['author']);
            if($swxnoticeset['wxnotice_tmpl']['dianping']['data']['url']){
                $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=mypost&type=pcomment';
            }else{
                $detail_url = $_G['siteurl'] .'forum.php?mod=viewthread&tid='.$post['tid'];
            }
           
            
            $data = swxn_tmpldata('dianping', $find, $replace);
            
            swxn_sendnotification('dianping', $nauthorid, $detail_url, $data);
            
            
        }


    }

    function misc_bestanswer_message($params) {
        global $_G, $post, $thread;
        $uid = intval($post['authorid']);

        if ($params['param'][0] == 'reward_completion' and $_G['uid'] != $uid) {
            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=mypost&type=reward';

            $find = array(
                '{bbname}',
                '{username}',
                '{subject}');
            $replace = array(
                $_G['setting']['bbname'],
                $thread['author'],
                $thread['subject']);


            $data = swxn_tmpldata('reward', $find, $replace);
            swxn_sendnotification('reward', $uid, $detail_url, $data);
        }

    }

    function misc_votepoll_message($params) {
        global $_G, $thread;

        if ($params['param'][0] == 'thread_poll_succeed' and $thread['authorid'] != $_G['uid']) {
            $detail_url = $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $thread['tid'];
            $find = array('{bbname}', '{subject}');
            $replace = array($_G['setting']['bbname'], $thread['subject']);

            $data = swxn_tmpldata('votepoll', $find, $replace);
            swxn_sendnotification('votepoll', $thread['authorid'], $detail_url, $data);
        }

    }

    function misc_activity_message($params) {
        global $_G, $thread, $activity, $uidarray, $activity_subject, $reason;

        $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=mypost';
        switch ($params['param'][0]) {

            case 'activity_completion':
                global $message;

                $find = array(
                    '{bbname}',
                    '{username}',
                    '{subject}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $thread['subject'],
                    $message);

                $data = swxn_tmpldata('activity_completion', $find, $replace);
                if ($thread['authorid'] != $_G['uid']) {
                    swxn_sendnotification('activity_completion', $thread['authorid'], $detail_url, $data);
                }
                break;

            case 'activity_auditing_completion':
                global $unverified, $verified;
                $verified = !$verified ? 1 : $verified;
                $find = array(
                    '{bbname}',
                    '{username}',
                    '{subject}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $activity_subject,
                    $reason);
                $data = swxn_tmpldata('activity_auditing', $find, $replace);

                foreach ($unverified as $uid) {
                    if ($uid != $_G['uid']) {
                        swxn_sendnotification('activity_auditing' . $verified, $uid, $detail_url, $data);
                    }
                }
                break;
            case 'activity_delete_completion':

                $find = array(
                    '{bbname}',
                    '{username}',
                    '{subject}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $activity_subject,
                    $reason);
                $data = swxn_tmpldata('activity_delete', $find, $replace);

                foreach ($uidarray as $uid) {
                    if ($uid != $_G['uid']) {
                        swxn_sendnotification('activity_delete', $uid, $detail_url, $data);
                    }
                }
                break;
            case 'activity_notification_success':


                $find = array(
                    '{bbname}',
                    '{username}',
                    '{subject}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $activity_subject,
                    $reason);
                $data = swxn_tmpldata('activity_notification', $find, $replace);

                foreach ($uidarray as $uid) {
                    if ($uid != $_G['uid']) {
                        swxn_sendnotification('activity_notification', $uid, $detail_url, $data);
                    }
                }
                break;
            default:
                return '';

        }

    }


}

class mobileplugin_strong_wxnotice_misc extends mobileplugin_strong_wxnotice {

    function report_message($params) {
        global $_G, $swxnoticeset, $url;
        $users = $swxnoticeset['wxnotice_tmpl']['report']['data']['users'] ? $swxnoticeset['wxnotice_tmpl']['report']['data']['users'] : 1;
        $users = explode(",", $users);
        if ($params['param'][0] == 'report_succeed') {

            $message = $_GET['report_select'] ? $_GET['report_select'] : censor(cutstr(dhtmlspecialchars(trim($_GET['message'])), 200, ''));

            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=manage';

            $find = array(
                '{bbname}',
                '{username}',
                '{message}',
                '{url}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $message,
                $url);

            $data = swxn_tmpldata('report', $find, $replace);

            foreach ($users as $uid) {
                if ($uid != $_G['uid']) {
                    swxn_sendnotification('report', $uid, $detail_url, $data);
                }
            }
        }
    }


    function invite_message($params) {
        global $_G, $uids, $thread;
        if ($params['param'][0] == 'group_invite_succeed' and $_GET['action'] == 'thread') {
            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=manage';

            $find = array(
                '{bbname}',
                '{username}',
                '{subject}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $thread['subject']);

            $data = swxn_tmpldata('activity_invite', $find, $replace);
            foreach ($uids as $uid) {
                if ($uid != $_G['uid']) {
                    swxn_sendnotification('activity_invite', $uid, $detail_url, $data);
                }
            }

        }
    }
}

class mobileplugin_strong_wxnotice_home extends mobileplugin_strong_wxnotice {

    function spacecp_pm_message($params) {
        global $_G, $swxnoticeset, $touid, $newusers, $users, $message;

        if ($_GET['op'] == 'send' && ($params['param'][0] == 'do_success' || $params['param'][0] == 'message_send_result')) {
            $touid = $touid ? $touid : $_GET['topmuid'];
            $newusers = !empty($newusers) ? $newusers : array($touid => $touid);


            foreach ($newusers as $uid => $username) {
                $uid = intval($uid);
                $cutlength = $swxnoticeset['wxnotice_tmpl']['pm']['data']['length'] ? intval($swxnoticeset['wxnotice_tmpl']['pm']['data']['length']) : 100;
                require_once libfile('function/post');
                $messagecutstr = messagecutstr(dhtmlspecialchars($message), $cutlength);

                $find = array(
                    '{bbname}',
                    '{username}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $messagecutstr);

                $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=pm&authorization=1';


                $data = swxn_tmpldata('pm', $find, $replace);
                swxn_sendnotification('pm', $uid, $detail_url, $data);
            }
        }

    }

    function spacecp_friend_message($params) {
        global $_G, $swxnoticeset, $uid;

        if ($_G['uid'] == $uid) {
            return '';
        }

        $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=interactive&type=friend';


        if ($params['param'][0] == 'request_has_been_sent') {

            $find = array(
                '{bbname}',
                '{username}',
                '{message}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $_GET['note']);

            $data = swxn_tmpldata('friendsend', $find, $replace);
            swxn_sendnotification('friendsend', $uid, $detail_url, $data);

        } else
            if ($params['param'][0] == 'friends_add') {
                $find = array(
                    '{bbname}',
                    '{username}',
                    '{message}');
                $replace = array(
                    $_G['setting']['bbname'],
                    $_G['username'],
                    $messagecutstr);
                $data = swxn_tmpldata('friendadd', $find, $replace);

                swxn_sendnotification('friendadd', $uid, $detail_url, $data);
            }
    }


    function spacecp_follow_message($params) {
        global $_G, $followuid;
        if ($params['param'][0] == 'follow_add_succeed') {

            $detail_url = $_G['siteurl'] . 'home.php?mod=follow&do=follower';
            $find = array('{bbname}', '{username}');
            $replace = array($_G['setting']['bbname'], $_G['username']);
            $data = swxn_tmpldata('follow', $find, $replace);

            swxn_sendnotification('follow', $followuid, $detail_url, $data);
        }
    }

    function spacecp_poke_message($params) {
        global $_G, $pokemsg, $uid, $setarr;
        if ($params['param'][0] == 'poke_success') {
            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=interactive&type=poke';

            $notetext = $setarr['iconid'] ? lang('home/template', 'poke_' . $setarr['iconid']) : $_POST['note'];
            $find = array(
                '{bbname}',
                '{username}',
                '{message}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $notetext);

            $data = swxn_tmpldata('poke', $find, $replace);
            swxn_sendnotification('poke', $uid, $detail_url, $data);
        }
    }

    function spacecp_comment_message($params) {
        global $_G, $swxnoticeset, $id, $message;

        if ($params['param'][0] == 'do_success' and getgpc('commentsubmit') and $_G['uid'] != $id) {


            $cutlength = $swxnoticeset['wxnotice_tmpl']['comment']['data']['length'] ? intval($swxnoticeset['wxnotice_tmpl']['comment']['data']['length']) :
                100;
            require_once libfile('function/post');
            $message = preg_replace(array('/\&nbsp;/', '/\<img .*?>/'), array('', swxn_lang('text_1')), $message);
            $message = messagecutstr(dhtmlspecialchars($message), $cutlength);

            $detail_url = $_G['siteurl'] . 'home.php?mod=space&do=notice&view=interactive&type=wall';
            $find = array(
                '{bbname}',
                '{username}',
                '{message}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                $message);

            $data = swxn_tmpldata('comment', $find, $replace);
            swxn_sendnotification('comment', $id, $detail_url, $data);
        }

    }
}

class mobileplugin_strong_wxnotice_member extends mobileplugin_strong_wxnotice {
    function logging_login_message($params) {
        global $_G;


        if ($params['param'][0] == 'login_succeed') {
            $detail_url = $_G['siteurl'];
            $find = array(
                '{bbname}',
                '{username}',
                '{time}');
            $replace = array(
                $_G['setting']['bbname'],
                $_G['username'],
                dgmdate(TIMESTAMP));

            $data = swxn_tmpldata('login', $find, $replace);
            swxn_sendnotification('login', $_G['uid'], $detail_url, $data);

        }
    }

}
//From: Dism_taobao-com
?>