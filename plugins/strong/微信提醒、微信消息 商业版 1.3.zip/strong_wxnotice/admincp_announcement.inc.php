<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;
loadcache('setting');
$setting = (array )unserialize($_G['setting']['strong_wxnotice']);
$tmpltype = $_GET['tmpltype'];


require_once DISCUZ_ROOT . '/source/plugin/strong_wxnotice/function/function_base.php';
include_once DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/wechat.lib.class.php';
$templatetype = sxwn_type();
swxn_loadlang();
$_G['strong_wxlogin']['setting'] = unserialize($_G['setting']['strong_wxlogin']);
$_G['strong_wxlogin']['setting']['wechat_appsecret'] = authcode($_G['strong_wxlogin']['setting']['wechat_appsecret'], 'DECODE', $_G['config']['security']['authkey']);



if (submitcheck('sendsubmit', 1)) {

    if ($_POST['setting']['send']) {
        $setting['wxnotice_send'] = $_POST['setting'];
        $settings = array('strong_wxnotice' => serialize($setting));
        C::t('common_setting')->update_batch($settings);
        updatecache('setting');
    }

    if ($setting['wxnotice_send']['uids_available']) {
        $uids = explode(',', $setting['wxnotice_send']['uids']);
        foreach($uids as $uid){
            if(intval($uid)){
                $wuids[]=$uid;
            }
        }     
        if(!$wuids){$wuids=array('0');}   
        $where = ' w.uid IN('.implode(",",array_unique((array)$wuids)).') ';

    } elseif ($setting['wxnotice_send']['groups_available']) {
        $setting['wxnotice_send']['groups'] = (array)array_unique($setting['wxnotice_send']['groups']);
        if(!$setting['wxnotice_send']['groups']){
            $setting['wxnotice_send']['groups'] = array('0');
        }
                
        $where = ' c.groupid IN('.implode(",",$setting['wxnotice_send']['groups']).') ';
        
    } else {
        $where = '';
    }

    $where .= ($where ? ' AND ' : '') . DB::field('subscribe', 1) . ' and w.uid=c.uid';

    $pertask = isset($_GET['pertask']) ? intval($_GET['pertask']) : 10;
    $start = isset($_GET['start']) && $_GET['start'] > 0 ? intval($_GET['start']) : 0;
    $next = $start + $pertask;
    $loading = 0;

    $count = DB::result_first('SELECT COUNT(*) FROM %t w,%t c WHERE %i', array('strong_wxlogin_bind','common_member', $where));
    $postusers = DB::fetch_all('SELECT * FROM %t w,%t c WHERE %i ORDER BY dateline DESC' . DB::limit($start, $next), array('strong_wxlogin_bind','common_member', $where),
        'uid');


    if (!$_GET['confirmed']) {
        cpmsg(swxn_lang('admincp_base_title_15', array($count)), "action=plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]&op=send&sendsubmit=yes",
            'form');
    }

    if ($postusers) {
        $loading = 1;
        $detail_url = $setting['wxnotice_send']['url'] ? $setting['wxnotice_send']['url'] : $_G['siteurl'];
        $find = array('{bbname}', '{username}');

        foreach($postusers as $user){
        $replace = array($_G['setting']['bbname'], $user['username']);
        $data = swxn_tmpldata('announcement', $find, $replace);
        swxn_sendnotification('announcement',$user['uid'], $detail_url, $data);

        }
        sleep(2);
    }


    $next = $next > $count ? $count : $next;
    if ($loading) {
        cpmsg(swxn_lang('admincp_base_title_17', array(
            $count,
            $start,
            $next)), "action=plugins&operation=$operation&identifier=$plugin[identifier]&pmod=$module[name]&start=$next&pertask=$pertask&sendsubmit=yes&op=send&confirmed=true",
            'loading');
    } else {
        cpmsg(swxn_lang('admincp_base_title_18'), 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] .
            '&pmod=' . $module['name'], 'succeed');
    }
} else {
    $groupselect = array();
    $usergroup = C::t('common_usergroup')->fetch_all_not(array(
        5,
        6,
        7));
    foreach ($usergroup as $group) {
        $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
        if (in_array($group['groupid'], $groups)) {
            $groupselect[$group['type']] .= "<option value=\"$group[groupid]\" selected>$group[grouptitle]</option>\n";
        } else {
            $groupselect[$group['type']] .= "<option value=\"$group[groupid]\">$group[grouptitle]</option>\n";
        }
    }
    $groupselect = '<optgroup label="' . $lang['usergroups_member'] . '">' . $groupselect['member'] . '</optgroup>' . ($groupselect['special'] ?
        '<optgroup label="' . $lang['usergroups_special'] . '">' . $groupselect['special'] . '</optgroup>' : '') . ($groupselect['specialadmin'] ?
        '<optgroup label="' . $lang['usergroups_specialadmin'] . '">' . $groupselect['specialadmin'] . '</optgroup>' : '') . '<optgroup label="' . $lang['usergroups_system'] .
        '">' . $groupselect['system'] . '</optgroup>';

    showtips(swxn_lang('admincp_base_title_9'));

    showformheader("plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]");
    showtableheader(swxn_lang('admincp_base_title_10'));
    showsetting(swxn_lang('admincp_base_title_11'), 'setting[uids_available]', 0, 'radio', '', 1, swxn_lang('admincp_base_title_11_d'));
    showsetting(swxn_lang('admincp_base_title_12'), 'setting[uids]', '', 'textarea', '', '', swxn_lang('admincp_base_title_12_d'));
    showtablefooter();/*Dism��taobao��com*/

    
    showtableheader();
    showsetting(swxn_lang('admincp_base_title_13'), 'setting[groups_available]', 0, 'radio', '', 1, swxn_lang('admincp_base_title_13_d'));
    showsetting(swxn_lang('admincp_base_title_19'), '', '', '<select name="setting[groups][]" multiple="multiple" size="10">' . $groupselect . '</select>', '',
        0);
    showtablefooter();/*Dism��taobao��com*/
    

    showtableheader();
    showsetting(swxn_lang('admincp_base_title_16'), 'setting[alluser]', 0, 'radio', '', '', swxn_lang('admincp_base_title_16_d'));
    showsetting(swxn_lang('admincp_base_title_14'), 'setting[url]', '', 'text', '', '', swxn_lang('admincp_base_title_14_d'));
    showhiddenfields(array('setting[send]' => 1));
    showtablefooter();/*Dism��taobao��com*/

    showsubmit('sendsubmit', 'config');
    showformfooter();
}
//From: Dism_taobao-com
?>