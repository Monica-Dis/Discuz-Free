<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
loadcache('setting');
$setting = (array)unserialize($_G['setting']['strong_wxnotice']);
$tmpltype = $_GET['tmpltype'];


require_once DISCUZ_ROOT . '/source/plugin/strong_wxnotice/function/function_base.php';
$templatetype = sxwn_type();
swxn_loadlang();




if(submitcheck('tmplsubmit')) {
    foreach($_POST['setting']['wxnotice_tmpl'] as $key => $type) {        
        if($type['id']) {
            $type['enable'] = $type['enable'] == 1 ? 1 : 0;
            if(!$setting['wxnotice_tmpl'][$key]){
                $setting['wxnotice_tmpl'][$key] = $type;
            }else{
                $setting['wxnotice_tmpl'][$key] = array_merge($setting['wxnotice_tmpl'][$key], $type);
            }
        }
    }

    $settings = array('strong_wxnotice' => serialize($setting));
    C::t('common_setting')->update_batch($settings);
    updatecache('setting');
    cpmsg('setting_update_succeed', 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module[name] . '&op=setting', 'succeed');
}else if(submitcheck('editsubmit') and in_array($tmpltype,$templatetype)){
    
    $keynum = intval($_POST['setting']['wxnotice_tmpl'][$tmpltype]['data']['keynum']) ? intval($_POST['setting']['wxnotice_tmpl'][$tmpltype]['data']['keynum']) : 2;
    $datatype = swxn_keyword($keynum);

    $setting['wxnotice_tmpl'][$tmpltype]['data'] = $_POST['setting']['wxnotice_tmpl'][$tmpltype]['data'];
    $setting['wxnotice_tmpl'][$tmpltype]['data']['keynum'] = $_POST['setting']['wxnotice_tmpl'][$tmpltype]['data']['keynum'];

    $settings = array('strong_wxnotice' => serialize($setting));
    C::t('common_setting')->update_batch($settings);
    updatecache('setting');

    cpmsg('setting_update_succeed', 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module[name] . '&tmpltype='.$tmpltype, 'succeed');


}else if(submitcheck('resetsubmit') and in_array($tmpltype,$templatetype)){ 
    
    
    unset($setting['wxnotice_tmpl'][$tmpltype]['data']);
    $settings = array('strong_wxnotice' => serialize($setting));
    C::t('common_setting')->update_batch($settings);
    updatecache('setting');

    cpmsg('setting_update_succeed', 'action=plugins&operation=config&do=' . $pluginid . '&identifier=' . $plugin['identifier'] . '&pmod=' . $module[name] . '&tmpltype='.$tmpltype, 'succeed');

}




if(in_array($tmpltype,$templatetype)){
    
    $optionstr = '';
    
    $keynum = intval($_GET['keynum']) ? intval($_GET['keynum']) : ($setting['wxnotice_tmpl'][$tmpltype]['data']['keynum'] ? $setting['wxnotice_tmpl'][$tmpltype]['data']['keynum'] : 2);
    $datatype = swxn_keyword($keynum);
    
    for($o=2;$o<=5;$o++){
        $optionstr.= '<option value="'.$o.'" '.($keynum==$o ? 'selected="selected"' : '').'>'.$o.swxn_lang('admincp_config_title17').'</option>';
    }
    
    showtips(swxn_lang('admincp_config_'.$tmpltype.'_hint').swxn_lang('admincp_config_global_hint'));
    showformheader("plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]&tmpltype=$tmpltype");
 

    echo '<input type="hidden" name="setting[wxnotice_tmpl]['.$tmpltype.'][data][keynum]" value="'.$keynum.'">';
    showtableheader(swxn_lang('admincp_base_title_3').'-'.swxn_lang('admincp_config_' . $tmpltype . '_type').'
        <select style="margin-left:10px;" onchange="window.location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&do='.$plugin[pluginid].'&identifier='.$plugin[identifier].'&tmpltype='.$tmpltype.'&pmod='.$module[name].'&keynum=\'+this.value;">
          '.$optionstr.'
        </select>
    ');
    
     echo '<tr class="header">
         <th class="td24">' . swxn_lang('admincp_config_title8') . '</th>
         <th style="width:400px;">' . swxn_lang('admincp_config_title9') . '</th>
         <th class="">'.swxn_lang('admincp_config_title10').'</th><th class="">'.swxn_lang('admincp_config_title16').'</th></tr>';


    foreach($datatype as $data){
        $datastr = $setting['wxnotice_tmpl'][$tmpltype]['data'][$data] ? $setting['wxnotice_tmpl'][$tmpltype]['data'][$data] : swxn_lang('admincp_config_'.$tmpltype.'_tmpldata_'.$data);
        $datacolor =  $setting['wxnotice_tmpl'][$tmpltype]['data'][$data.'_color'] ? $setting['wxnotice_tmpl'][$tmpltype]['data'][$data.'_color'] : '#000000';
        $dataname = $setting['wxnotice_tmpl'][$tmpltype]['data'][$data.'_name'] ? $setting['wxnotice_tmpl'][$tmpltype]['data'][$data.'_name'] : $data;
        showtablerow('','',array(
        swxn_lang('admincp_config_'.$data.'_title'),
        '<textarea rows="6"  name="setting[wxnotice_tmpl]['.$tmpltype.'][data]['.$data.']" id="'.$data.'" cols="50" class="tarea">'.$datastr.'</textarea>',
        showcolorsetting($data,"setting[wxnotice_tmpl][$tmpltype][data][".$data."_color]",$datacolor),
        '<input type="text" name="setting[wxnotice_tmpl]['.$tmpltype.'][data]['.$data.'_name]" value="'.$dataname.'">'
        ));
    }

    switch($tmpltype){
        case 'post':
            $postlength = $setting['wxnotice_tmpl'][$tmpltype]['data']['length'] ? $setting['wxnotice_tmpl'][$tmpltype]['data']['length'] : 100; 
            swxn_showsetting(swxn_lang('admincp_config_post_title1'),'setting[wxnotice_tmpl]['.$tmpltype.'][data][length]',$postlength,'text'); 
            
            $posturl = $setting['wxnotice_tmpl'][$tmpltype]['data']['url'] ? $setting['wxnotice_tmpl'][$tmpltype]['data']['url'] : 0;
            swxn_showsetting(swxn_lang('admincp_config_post_title2'),'setting[wxnotice_tmpl]['.$tmpltype.'][data][url]',$posturl,'radio',swxn_lang('admincp_config_post_title2_des')); 
            
            break;
            
        case 'dianping':
            $postlength = $setting['wxnotice_tmpl'][$tmpltype]['data']['length'] ? $setting['wxnotice_tmpl'][$tmpltype]['data']['length'] : 100; 
            swxn_showsetting(swxn_lang('admincp_config_post_title1'),'setting[wxnotice_tmpl]['.$tmpltype.'][data][length]',$postlength,'text'); 
            
            $posturl = $setting['wxnotice_tmpl'][$tmpltype]['data']['url'] ? $setting['wxnotice_tmpl'][$tmpltype]['data']['url'] : 0;
            swxn_showsetting(swxn_lang('admincp_config_post_title2'),'setting[wxnotice_tmpl]['.$tmpltype.'][data][url]',$posturl,'radio',swxn_lang('admincp_config_post_title2_des')); 
            
            break;            
            
        case 'pm':
            $messagelength = $setting['wxnotice_tmpl'][$tmpltype]['data']['length'] ? $setting['wxnotice_tmpl'][$tmpltype]['data']['length'] : 100;
        
            showtablerow('','',array(
            swxn_lang('admincp_config_pm_title1'),
            '<input type="text" name="setting[wxnotice_tmpl]['.$tmpltype.'][data][length]" value="'.$messagelength.'">'
            ));            
            break;   
            
        case 'comment':
            $messagelength = $setting['wxnotice_tmpl'][$tmpltype]['data']['length'] ? $setting['wxnotice_tmpl'][$tmpltype]['data']['length'] : 100;
        
            showtablerow('','',array(
            swxn_lang('admincp_config_comment_title1'),
            '<input type="text" name="setting[wxnotice_tmpl]['.$tmpltype.'][data][length]" value="'.$messagelength.'">'
            ));            
            break; 
            
        case 'report':
            $messagelength = $setting['wxnotice_tmpl'][$tmpltype]['data']['users'] ? $setting['wxnotice_tmpl'][$tmpltype]['data']['users'] : 1;
        
            showtablerow('','',array(
            swxn_lang('admincp_config_report_title1'),
            '<input type="text" style="width:400px" name="setting[wxnotice_tmpl]['.$tmpltype.'][data][users]" value="'.$messagelength.'">'
            ));            
            break;            
    }
    
    
    
    
    
    
    
    
    
    
    showsubmit('editsubmit', 'config','','<input type="submit" class="btn" name="resetsubmit" value="'.swxn_lang('admincp_base_title_4').'">');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();
}else{

    showtips(swxn_lang('admincp_base_title_1'));
    showformheader("plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]");
    showtableheader(swxn_lang('admincp_base_title_2'));
    
    echo '<tr class="header"><th class="td25">' . swxn_lang('admincp_config_title1') . '</th><th class="td23">' . swxn_lang('admincp_config_title2') . '</th><th class="td24">' . swxn_lang('admincp_config_title3') . '</th><th class="td24">' . swxn_lang('admincp_config_title4') . '</th><th class="td31">' .
        swxn_lang('admincp_config_title5') . '</th><th class="td21">' . swxn_lang('admincp_config_title6') . '</th><th>' . swxn_lang('admincp_config_title7') . '</th></tr>';
    
    foreach($templatetype as $key => $type) {
        $checked1 = $setting['wxnotice_tmpl'][$type]['enable'] ? 'checked="checked"' : '';
        $setting[wxnotice_tmpl][$type][sendflood] = $setting[wxnotice_tmpl][$type][sendflood] ? $setting[wxnotice_tmpl][$type][sendflood] : 180;
        showtablerow('', array(), array(
            "<input type='checkbox' value='1' name='setting[wxnotice_tmpl][$type][enable]' $checked1>",
            swxn_lang('admincp_config_' . $type . '_type'),
            swxn_lang('admincp_config_' . $type . '_code'),
            swxn_lang('admincp_config_' . $type . '_title'),
            "<input type='text' value='{$setting[wxnotice_tmpl][$type][id]}' size='60' name='setting[wxnotice_tmpl][$type][id]'>",
            "<input type='text' value='{$setting[wxnotice_tmpl][$type][sendflood]}' name='setting[wxnotice_tmpl][$type][sendflood]'>",
            "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=" . $pluginid . "&identifier=" . $plugin['identifier'] . "&pmod=" . $module[name] . "&tmpltype=".$type."'>" . swxn_lang('admincp_base_title_3') . "</a>"));
    }
    showsubmit('tmplsubmit', 'config');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();
    }
//From: Dism_taobao-com
?>
