<?php

if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
loadcache('setting');
$setting = (array )unserialize($_G['setting']['strong_wxnotice']);
$tmpltype = $_GET['tmpltype'];
$datatype = array(
    'first',
    'keyword1',
    'keyword2',
    'remark');


require_once DISCUZ_ROOT .
    '/source/plugin/strong_wxnotice/function/function_base.php';
$templatetype = sxwn_type();
swxn_loadlang();



$perpage = 50;
$start = $perpage * ($_G['page'] - 1);
$where = '1';
$order = ' dateline desc';
$numcount = DB::result_first("SELECT COUNT(*) FROM %t WHERE $where", array('strong_wxnotice_tmplmsg'));
$logdata = DB::fetch_all("SELECT * FROM %t WHERE $where order by $order LIMIT $start,$perpage",
    array('strong_wxnotice_tmplmsg'));



$multipage = multi($numcount, $perpage, $_G['page'],
    ADMINSCRIPT."?action=plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]");


showtips(swxn_lang('admincp_base_title_6'));
showformheader("plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]");
showtableheader(swxn_lang('admincp_base_title_7'));

echo '<tr class="header"><th class="td25">ID</th><th class="td23">' . swxn_lang('admincp_config_title2') .
    '</th><th class="td23">' . swxn_lang('admincp_config_title15') .
    '</th><th class="td24">' . swxn_lang('admincp_config_title11') .
    '</th><th class="td31">' . swxn_lang('admincp_config_title12') .
    '</th><th class="td24">' . swxn_lang('admincp_config_title13') .
    '</th><th class="td21">' . swxn_lang('admincp_config_title14') . '</th></tr>';


foreach ($logdata as $data) {
    $message = unserialize($data['data']);
    $userinfo = getuserbyuid($data['uid']);

    showtablerow('', array(), array(
        $data['id'],
        swxn_lang('admincp_config_' . $data['type'] . '_type'),
        '<a href="home.php?mod=space&uid=' . $data['uid'] . '" target="_black">' . $userinfo['username'] .
            '</a>',
        dgmdate($data['dateline']),
        '{first}:' . $message['first']['value'] . '{keyword1}:' . $message['keyword1']['value'] .
            '{keyword2}:' . $message['keyword2']['value'] . '{remark}:' . $message['remark']['value'],
        $data['status'] == 'success' ? swxn_lang('admincp_base_title_8') : $data['status'],
        $data['returncode']));

}


//showsubmit('tmplsubmit', 'config');
showtablefooter();/*Dism��taobao��com*/
showformfooter();
echo $multipage;
?>
