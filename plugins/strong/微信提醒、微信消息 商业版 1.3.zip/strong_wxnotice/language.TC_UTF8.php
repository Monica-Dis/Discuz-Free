<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function swxn_echolang($text) {
    $lang = array(    
        'text_1'=>'[表情]',
        'spacecp_text_1'=>'修改',
        'spacecp_text_2'=>'是',
        'spacecp_text_3'=>'否',
        'spacecp_text_4'=>'類型',
        'spacecp_text_5'=>'是否提醒',
        'spacecp_text_6'=>'修改成功',
        'spacecp_text_7'=>'修改',
    
        'admincp_base_title_1' => '
        <li>本插件必須配合<a href="https://dism.taobao.com/?@strong_wxlogin.plugin" style="color:#f60" target="_blank">【strong微信登陸】</a>使用！</li>
        <li>進入<a href="http://mp.weixin.qq.com" target="_blank">微信公眾平臺</a>後臺，模板消息 添加行業: IT科技/互聯網|電子商務, 
        在模板庫中添加適用的模板，請下載<a href="https://dism.taobao.com/?@strong_wxnotice.plugin.87154" style="color:red;" target="_blank">說明文檔</a></li>
        <li>選擇開啟後有效，用戶可以在微信通知設置頁面根據需求自行選擇開啟或關閉通知。</li>
        <li>模板ID必須填入對應編碼分類的模板</li>
        <li>間隔時間請根據需求設置，在間隔時間內的通知將會被忽略。</li>
    ',
        'admincp_base_title_2' => '配置',
        'admincp_base_title_3' => '編輯',
        'admincp_base_title_4' => '重置',
        'admincp_base_title_5' => '保存',     
        'admincp_base_title_6' => '
            <li>消息推送記錄僅供參考，便於管理員查看消息推送狀態：接口返回狀態(成功/失敗)、接口錯誤信息等等。</li>
            <li>消息接收者必須關註公眾號、未屏蔽接收消息才能正常收到消息提醒。</li>
            <li>狀態：接收成功表示用戶成功接收到消息。failed:user block表示消息送達由於用戶拒收（用戶設置拒絕接收公眾號消息）而失敗。failed: system failed表示消息送達由於其他原因導致失敗</li>
            <li>消息內容：{first}{keyword1}{keyword2}{remark}為消息模板關鍵字</li>
        ',
        'admincp_base_title_7' => '消息列表',
        'admincp_base_title_8' => '<span style="color:#090;">接收成功</span>',
        'admincp_base_title_9' => '
            <li style="color:#f00; font-weight:700;">群發功能容易引起用戶反感，多次舉報可能被封停賬號，請謹慎使用。</li>
            <li>群發執行速度緩慢，請合理篩選用戶。執行過程中請勿打斷或關閉本頁面</li>
            <li>群發公告所執行的模板為【模板消息配置】中的【公告提醒】，請先編輯好需要發送的內容，先發送到指定賬號測試效果，再進行群發。</li>
            <li>【公告提醒】前的【啟用】建議勾上，用戶可以自行選擇接收、拒收公告，如果【啟用】為關閉，所有發送列表的用戶都會強制接收到提醒消息。</li>  
            <li>如果用戶沒有關註公眾號則無法接收到消息</li>  
        ',
        'admincp_base_title_10'=>'群發用戶',
        'admincp_base_title_11'=>'指定用戶',
        'admincp_base_title_11_d'=>'對指定的用戶進行群發',
        'admincp_base_title_12'=>'用戶UID',
        'admincp_base_title_12_d'=>'填寫用戶UID，以英文逗號間隔，例如：1,2,3,4,5',
        'admincp_base_title_13'=>'指定用戶組',
        'admincp_base_title_13_d'=>'對指定用戶組進行群發',
        'admincp_base_title_14'=>'跳轉URL',
        'admincp_base_title_14_d'=>'跳轉URL為空則跳轉到網站首頁',
        'admincp_base_title_15'=>'本次共推送 {0} 條數據, 請確定是否開始群發操作?',
        'admincp_base_title_16'=>'全部用戶',
        'admincp_base_title_16_d'=>'對所有用戶進行群發', 
        'admincp_base_title_17'=>'壹共有{0}條數據，當前正在推送第{1}-{2}條數據', 
        'admincp_base_title_18'=>'推送完成',
        'admincp_base_title_19'=>'選擇用戶組',
        
        


        'admincp_config_title1' => '啟用',
        'admincp_config_title2' => '模板類型',
        'admincp_config_title3' => '模板編號',
        'admincp_config_title4' => '模板標題',
        'admincp_config_title5' => '模板ID',
        'admincp_config_title6' => '間隔時間(秒)',
        'admincp_config_title7' => '操作',
        'admincp_config_title8' => '參數',
        'admincp_config_title9' => '消息模板',
        'admincp_config_title10' => '字體顏色',
        'admincp_config_title11' => '時間',
        'admincp_config_title12' => '消息內容',
        'admincp_config_title13' => '狀態',
        'admincp_config_title14' => '返回碼',
        'admincp_config_title15' => '接收者',
        'admincp_config_title16' => '關鍵字名',
        'admincp_config_title17' =>'個關鍵字',
        
        
        
        'admincp_config_first_title' => '標題',
        'admincp_config_keyword1_title' => '關鍵字1',
        'admincp_config_keyword2_title' => '關鍵字2',
        'admincp_config_keyword3_title' => '關鍵字3',
        'admincp_config_keyword4_title' => '關鍵字4',
        'admincp_config_keyword5_title' => '關鍵字5',
        'admincp_config_remark_title' => '備註',
        
        
        
        
        'admincp_config_global_hint' => '
            <li>通用標識列表:</li>
            <li>{date}標記：時間</li>
        ',
        
        'admincp_config_login_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:用戶名</li>
            <li>{time}標記:登錄時間</li>
        ',
        'admincp_config_login_type' => '登錄成功',
        'admincp_config_login_code' => 'OPENTM201673425',
        'admincp_config_login_title' => '登錄成功提醒',
        'admincp_config_login_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_login_tmpldata_keyword1' => '{username} ',
        'admincp_config_login_tmpldata_keyword2' => '{time}',
        'admincp_config_login_tmpldata_remark' => '您的賬號{username}在{time}登錄了{bbname},如果是您本人操作請忽略本提醒',




        'admincp_config_post_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:回帖者用戶名</li>
            <li>{author}標記：樓主用戶名</li>
            <li>{subject}標記:帖子標題</li>
            <li>{message}標記:回帖內容</li>            
            <li>回復內容長度:設置100字符，則最多顯示100字符，溢出的將會被截取。</li>
        ',
        'admincp_config_post_type' => '回帖提醒',
        'admincp_config_post_code' => 'OPENTM200605630',
        'admincp_config_post_title' => '任務處理通知',
        'admincp_config_post_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_post_tmpldata_keyword1' => '{username}  回復了您的帖子: {subject}',
        'admincp_config_post_tmpldata_keyword2' => '回帖提醒',
        'admincp_config_post_tmpldata_remark' => '回復內容:{message}',
        'admincp_config_post_title1' => '回復內容長度',
        'admincp_config_post_title2' => '跳轉到提醒頁',
        'admincp_config_post_title2_des'=>'默認跳轉到帖子頁，選擇是則跳轉到提醒頁',
        

        'admincp_config_dianping_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:點評者用戶名</li>
            <li>{author}標記：樓主用戶名</li>
            <li>{subject}標記:帖子標題</li>
            <li>{message}標記:回帖內容</li>            
            <li>回復內容長度:設置100字符，則最多顯示100字符，溢出的將會被截取。</li>
        ',
        'admincp_config_dianping_type' => '點評提醒',
        'admincp_config_dianping_code' => 'OPENTM200605630',
        'admincp_config_dianping_title' => '任務處理通知',
        'admincp_config_dianping_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_dianping_tmpldata_keyword1' => '{username}  點評了您的帖子: {subject}',
        'admincp_config_dianping_tmpldata_keyword2' => '點評提醒',
        'admincp_config_dianping_tmpldata_remark' => '點評內容:{message}',
        'admincp_config_dianping_title1' => '點評內容長度',
        'admincp_config_dianping_title2' => '跳轉到提醒頁',
        'admincp_config_dianping_title2_des'=>'默認跳轉到帖子頁，選擇是則跳轉到提醒頁',


        'admincp_config_reward_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:帖子作者用戶名</li>
            <li>{subject}標記:帖子標題</li>
        ',
        'admincp_config_reward_type' => '懸賞提醒',
        'admincp_config_reward_code' => 'OPENTM200605630',
        'admincp_config_reward_title' => '任務處理通知',        
        'admincp_config_reward_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_reward_tmpldata_keyword1' => '您的回復被選為最佳答案',
        'admincp_config_reward_tmpldata_keyword2' => '懸賞提醒',
        'admincp_config_reward_tmpldata_remark' => '您在[{subject}]的回復被帖子作者：{username} 選為最佳答案',

        'admincp_config_votepoll_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{subject}標記:帖子標題</li>
        ',
        'admincp_config_votepoll_type' => '投票提醒',
        'admincp_config_votepoll_code' => 'OPENTM200605630',
        'admincp_config_votepoll_title' => '任務處理通知',
        'admincp_config_votepoll_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_votepoll_tmpldata_keyword1' => '用戶對您的主題進行了投票',
        'admincp_config_votepoll_tmpldata_keyword2' => '投票提醒',
        'admincp_config_votepoll_tmpldata_remark' => '用戶在[{subject}]中進行了投票',
        

        'admincp_config_activity_auditing1_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{subject}標記:活動標題</li>
            <li>{username}標記:活動發起人用戶名</li>
            <li>{message}標記:附言</li>
        ',
        'admincp_config_activity_auditing1_type' => '活動審核通過',
        'admincp_config_activity_auditing1_code' => 'OPENTM200605630',
        'admincp_config_activity_auditing1_title' => '任務處理通知',
        'admincp_config_activity_auditing1_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_activity_auditing1_tmpldata_keyword1' => '活動{subject} 的發起人{username}批準了您的活動申請',
        'admincp_config_activity_auditing1_tmpldata_keyword2' => '活動審核通過提醒',
        'admincp_config_activity_auditing1_tmpldata_remark' => '附言:{message}',

        'admincp_config_activity_auditing2_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{subject}標記:活動標題</li>
            <li>{username}標記:活動發起人用戶名</li>
            <li>{message}標記:附言</li>
        ',
        'admincp_config_activity_auditing2_type' => '活動申請需完善',
        'admincp_config_activity_auditing2_code' => 'OPENTM200605630',
        'admincp_config_activity_auditing2_title' => '任務處理通知',
        'admincp_config_activity_auditing2_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_activity_auditing2_tmpldata_keyword1' => '活動{subject} 的發起人{username}通知您需要完善活動報名信息',
        'admincp_config_activity_auditing2_tmpldata_keyword2' => '活動申請需完善提醒',
        'admincp_config_activity_auditing2_tmpldata_remark' => '附言:{message}',

        'admincp_config_activity_completion_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{subject}標記:活動標題</li>
            <li>{username}標記:申請者用戶名</li>
            <li>{message}標記:留言內容</li>
        ',
        'admincp_config_activity_completion_type' => '活動申請提醒',
        'admincp_config_activity_completion_code' => 'OPENTM200605630',
        'admincp_config_activity_completion_title' => '任務處理通知',
        'admincp_config_activity_completion_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_activity_completion_tmpldata_keyword1' => '{username}申請參加活動：{subject}，請上線審核處理。',
        'admincp_config_activity_completion_tmpldata_keyword2' => '活動申請提醒',
        'admincp_config_activity_completion_tmpldata_remark' => '留言內容:{message}',

        'admincp_config_activity_delete_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{subject}標記:活動標題</li>
            <li>{username}標記:發消息者用戶名</li>
            <li>{message}標記:附言</li>
        ',
        'admincp_config_activity_delete_type' => '活動拒絕提醒',
        'admincp_config_activity_delete_code' => 'OPENTM200605630',
        'admincp_config_activity_delete_title' => '任務處理通知',
        'admincp_config_activity_delete_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_activity_delete_tmpldata_keyword1' => '活動 {subject} 的發起人{username}拒絕您參加此活動',
        'admincp_config_activity_delete_tmpldata_keyword2' => '活動拒絕提醒',
        'admincp_config_activity_delete_tmpldata_remark' => '附言:{message}',


        'admincp_config_activity_notification_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{subject}標記:活動標題</li>
            <li>{username}標記:活動發起者用戶名</li>
            <li>{message}標記:通知內容</li>
        ',
        'admincp_config_activity_notification_type' => '活動通知提醒',
        'admincp_config_activity_notification_code' => 'OPENTM200605630',
        'admincp_config_activity_notification_title' => '任務處理通知',
        'admincp_config_activity_notification_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_activity_notification_tmpldata_keyword1' => '活動 {subject} 的發起人{username}發來通知',
        'admincp_config_activity_notification_tmpldata_keyword2' => '活動通知提醒',
        'admincp_config_activity_notification_tmpldata_remark' => '通知內容:{message}',


        'admincp_config_activity_invite_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{subject}標記:活動標題</li>
            <li>{username}標記:活動發起者用戶名</li>
        ',
        'admincp_config_activity_invite_type' => '活動邀請提醒',
        'admincp_config_activity_invite_code' => 'OPENTM200605630',
        'admincp_config_activity_invite_title' => '任務處理通知',
        'admincp_config_activity_invite_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_activity_invite_tmpldata_keyword1' => '{username} 邀請您參與活動 {subject}',
        'admincp_config_activity_invite_tmpldata_keyword2' => '活動邀請提醒',
        'admincp_config_activity_invite_tmpldata_remark' => '點擊查看詳情',


        'admincp_config_pm_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:發消息者用戶名</li>
            <li>{message}標記:短消息</li>
        ',
        'admincp_config_pm_type' => '短消息提醒',
        'admincp_config_pm_code' => 'OPENTM200605630',
        'admincp_config_pm_title' => '任務處理通知',
        'admincp_config_pm_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_pm_tmpldata_keyword1' => '{username}發來了壹條短消息',
        'admincp_config_pm_tmpldata_keyword2' => '短消息提醒',
        'admincp_config_pm_tmpldata_remark' => '消息內容:{message}',
        'admincp_config_pm_title1' => '短消息內容長度',


        'admincp_config_friendsend_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:請求者用戶名</li>
            <li>{message}標記:附言內容</li>
        ',
        'admincp_config_friendsend_type' => '好友請求提醒',
        'admincp_config_friendsend_code' => 'OPENTM200605630',
        'admincp_config_friendsend_title' => '任務處理通知',        
        'admincp_config_friendsend_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_friendsend_tmpldata_keyword1' => '{username}請求添加您為好友',
        'admincp_config_friendsend_tmpldata_keyword2' => '好友請求提醒',
        'admincp_config_friendsend_tmpldata_remark' => '附言內容:{message}',
        
        
        
        'admincp_config_friendadd_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:好友用戶名</li>
        ',
        'admincp_config_friendadd_type' => '好友通過提醒',
        'admincp_config_friendadd_code' => 'OPENTM200605630',
        'admincp_config_friendadd_title' => '任務處理通知',      
        'admincp_config_friendadd_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_friendadd_tmpldata_keyword1' => '{username}和您成為了好友',
        'admincp_config_friendadd_tmpldata_keyword2' => '好友通過提醒',
        'admincp_config_friendadd_tmpldata_remark' => '',
        
        
        
        
        'admincp_config_follow_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:收聽者用戶名</li>
        ',
        'admincp_config_follow_type' => '收聽提醒',
        'admincp_config_follow_code' => 'OPENTM200605630',
        'admincp_config_follow_title' => '任務處理通知',        
        'admincp_config_follow_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_follow_tmpldata_keyword1' => '有用戶收聽了您',
        'admincp_config_follow_tmpldata_keyword2' => '收聽提醒',
        'admincp_config_follow_tmpldata_remark' => '{username} 收聽了您',
        
        
        'admincp_config_poke_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:打招呼者用戶名</li>
            <li>{message}標記:打招呼內容</li>
        ',
        'admincp_config_poke_type' => '打招呼提醒',
        'admincp_config_poke_code' => 'OPENTM200605630',
        'admincp_config_poke_title' => '任務處理通知',
        'admincp_config_poke_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_poke_tmpldata_keyword1' => '{username}向您打招呼',
        'admincp_config_poke_tmpldata_keyword2' => '打招呼提醒',
        'admincp_config_poke_tmpldata_remark' => '內容：{message}',



        'admincp_config_comment_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:留言者用戶名</li>
            <li>{message}標記:留言內容</li>
        ',
        'admincp_config_comment_type' => '留言提醒',
        'admincp_config_comment_code' => 'OPENTM200605630',
        'admincp_config_comment_title' => '任務處理通知',        
        'admincp_config_comment_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_comment_tmpldata_keyword1' => '{username}給您留言了',
        'admincp_config_comment_tmpldata_keyword2' => '留言提醒',
        'admincp_config_comment_tmpldata_remark' => '留言內容：{message}',
        'admincp_config_comment_title1' => '留言內容長度',
        

        'admincp_config_report_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:舉報者用戶名</li>
            <li>{message}標記:舉報理由</li>
            <li>{url}標記:舉報頁面URL</li>
            <li>指定管理員：填寫用戶ID，用英文逗號分隔，當有用戶舉報時，系統會給指定的管理員發送提醒通知。示例：1,2,3,4,5</li>
        ',
        'admincp_config_report_type' => '舉報處理提醒',
        'admincp_config_report_code' => 'OPENTM200605630',
        'admincp_config_report_title' => '任務處理通知',
        'admincp_config_report_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_report_tmpldata_keyword1' => '{username}舉報了頁面，請盡快處理。',
        'admincp_config_report_tmpldata_keyword2' => '舉報處理提醒',
        'admincp_config_report_tmpldata_remark' => '舉報頁面:{url}。舉報理由：{message}。',
        'admincp_config_report_title1' => '指定管理員',        
        
        
        'admincp_config_at_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:回帖者用戶名</li>
            <li>{subject}標記:帖子標題</li>
            <li>{message}標記:回帖內容</li>
        ',
        'admincp_config_at_type' => '有人@提醒',
        'admincp_config_at_code' => 'OPENTM200605630',
        'admincp_config_at_title' => '任務處理通知',
        'admincp_config_at_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_at_tmpldata_keyword1' => '{username}在主題 {subject} 中提到了您',
        'admincp_config_at_tmpldata_keyword2' => '有人@提醒',
        'admincp_config_at_tmpldata_remark' => '回復內容:{message}',
        
        
        'admincp_config_announcement_hint' => '
            <li>可以自由的修改消息模板格式，必須保證標記代碼的完整性</li>
            <li>{bbname}標記:網站名稱</li>
            <li>{username}標記:接受者用戶名</li>
        ',
        'admincp_config_announcement_type' => '公告提醒',
        'admincp_config_announcement_code' => 'OPENTM200605630',
        'admincp_config_announcement_title' => '任務處理通知',
        'admincp_config_announcement_tmpldata_first' => '您收到壹條{bbname}的提醒消息',
        'admincp_config_announcement_tmpldata_keyword1' => '2019年度積分清零公告',
        'admincp_config_announcement_tmpldata_keyword2' => '公告提醒',
        'admincp_config_announcement_tmpldata_remark' => '尊敬的 {username} 您好，為感謝您長期對本站的支持，保障您的積分權益，特此通知：2020-03-1將進行常規清零,請盡快到本站積分商城兌換商品，以免積分清零給您造成不必要的損失。',
        );

    return $lang[$text];
}

function swxn_lang($text = null, $vars = array()) {
    $return = swxn_echolang($text);
    if ($vars && is_array($vars)) {
        foreach ($vars as $k => $v) {
            $searchs[] = '{' . $k . '}';
            $replaces[] = $v;
        }
    }

    $return = str_replace($searchs, $replaces, $return);
    return $return;
}
//From: Dism_taobao-com
?>