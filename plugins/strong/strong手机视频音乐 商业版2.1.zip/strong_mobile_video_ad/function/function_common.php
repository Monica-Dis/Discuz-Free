<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class SMVIDEOCK {

    public function checkaddon($ac = 0) {
        global $_G;
        $addonid = 'strong_mobile_video_ad.plugin';
        $pluginid = 'strong_mobile_video_ad';
        $tokenstr='XXX_XXX_XXX_';

        if($getaddontoken) {
            $parameter = self::createauthstr(array(
                $getaddontoken['RevisionID'],
                $getaddontoken['SN'],
                $_G['siteurl']));

        } else {
            $parameter = $tokenstr;
        }

        $opencheckurl = urldecode(strrev($checkurl)) . $parameter . '&a=' . $addonid . '&t=' . TIMESTAMP . '&l=' . urlencode($_G['siteurl']) . ($getaddontoken ? '&sn=yes' : '');

        if($getaddontoken) {
            $f1 = DISCUZ_ROOT.'source/plugin/'.$pluginid.'/function/function_common.php';
            $code = self::readFileCode($f1);
            $find = "/[\$]tokenstr[\w|\%|\.|\s|\=|\"|\']*\';/";
            $replace = "\$tokenstr='" . $parameter . "';";
            ;
            $code = preg_replace($find, $replace, $code);
            self::writeFileCode($f1, $code);
        }

      
        echo dfsockopen($opencheckurl);
    }

    public function readFileCode($f) {
        if(file_exists($f) === false) {
            return '';
        }

        $fp = fopen($f, 'r');
        $code = '';
        while(!feof($fp)) {
            $code .= fgets($fp, 4096);
        }
        fclose($fp);

        return $code;
    }

    public function writeFileCode($f, $code) {
        $fp = fopen($f, 'w');
        fwrite($fp, $code);
        fclose($fp);
    }

    public function createauthstr($arr) {
        $return = '';
        foreach($arr as $k => $s) {
            $return .= urlencode(strrev($s)) . '_';

        }
        return $return;
    }

    public function resolveauthstr($str) {
        $return = $str;
        $return = explode("_", $str);
        foreach($return as $k => $v) {
            $return[$k] = strrev(urldecode($v));
        }
        return $return;
    }

    public function echositetokeninfo($v1, $v2) {
        global $_G;

        $info = self::resolveauthstr($v2);

        echo $v1 . '|';
        foreach($info as $k => $i) {
            echo $i . ($k <= 1 ? '|' : '');
        }

    }
}

//From: Dism��taobao��com
?>