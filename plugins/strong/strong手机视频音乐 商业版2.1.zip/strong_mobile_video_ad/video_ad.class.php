<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function istype($k, $str) {
    return preg_match("/" . $k . "/i", $str, $match);
}


function get_type($str) {

    $type = array(
        "taobao" => "video.taobao.com",
        "youtube" => "youtu.be",
        "youku" => "player.youku.com",
        "youku2" => "v.youku.com",
        "tudou" => "tudou.com\/v",
        "tudou2" => "tudou.com\/programs",
        "ku6" => "ku6.com",
        "56" => "56.com",
        "ifeng" => "ifeng.com",
        "qq" => "v.qq.com\/x\/page",
        "qq2" => "v.qq.com\/txp\/iframe\/player\.html\?vid",
        "qq3" => "imgcache.qq.com",
        "qq4" => "v.qq.com\/iframe\/player\.html\?vid",
        "qq5" => "v\.qq\.com\/x\/cover",
        "qq6" => "video\.qq\.com\/TPout\.swf",
        "qq7" => "video\.qq\.com\/TencentPlayer\.swf",        
        "iqiyi" => "open.iqiyi.com",
        "sina" => "sina.com",
        "sohu" => "sohu.com",
        "people" => "people.com",
        "letv" => "letv.com",
        "xiami" => "xiami.com",
        "acfun" => "acfun\.cn\/v\/",
        "acfun2" => "acfun\.cn\/player\/",
        "bilibili" => "bilibili\.com\/video\/",
        "bilibili2" => "bilibili\.com\/player\.html\?",
        "mp3" => "mp3");

    foreach($type as $k => $v) {
        if(istype($v, $str)) return $k;
    }
    return 0;
}

function get_embed($type, $str, $w, $h, $cover) {

    switch($type) {
        case 'mp4':


            return returndata($str, $w, $h, $cover);

            break;
        case 'bilibili':
            $strid = explode('/video/av', $str);  
            $strid = explode('/', $strid[1]);  
            return '<iframe src="https://player.bilibili.com/player.html?aid='.$strid[0].'" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>';
            break;    
        case 'bilibili2':
            $strid = explode('player.html?aid=', $str);  
            $strid = explode('&', $strid[1]);  
            return '<iframe src="https://player.bilibili.com/player.html?aid='.$strid[0].'" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"> </iframe>';
            break;     
        case 'acfun':
            $strid = explode('/v/', $str);
            return '<div class="strong-videobox"><iframe src="https://www.acfun.cn/player/'.$strid[1].'" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"></iframe></div>';
        
            break;
        case 'acfun2':
            $strid = explode('/player/', $str);     
            return '<div class="strong-videobox"><iframe src="https://www.acfun.cn/player/'.$strid[1].'" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" scrolling="no" border="0" frameborder="no" framespacing="0" allowfullscreen="true"></iframe></div>';
        
            break;  
        case 'youku':
            $strid = explode('sid/', $str);
            $strid = explode('/v.swf', $strid[1]);
            $strid = $strid[0];

            return '<div class="strong-videobox"><iframe src="http://player.youku.com/embed/' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" frameborder=0 allowfullscreen></iframe></div>';
  
            break;

        case 'youku2':
            $strid = explode('v_show/id_', $str);
            $strid = explode('.html', $strid[1]);
            $strid = $strid[0];
            //$file = 'http://api.flvxz.com/site/'.$type.'/vid/'.$strid;
            //$returnurl = xmldata($file);
            //if($returnurl){return returndata($returnurl,$w,$h,$cover);
            //}else{
            return '<div class="strong-videobox"><iframe src="http://player.youku.com/embed/' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video"  frameborder=0 allowfullscreen></iframe></div>';
            //}
            break;

        case 'tudou':
            $strid = explode('/v/', $str);
            $strid = explode('==', $strid[1]);
            $strid = $strid[0];
            return '<div class="strong-videobox"><iframe src="http://player.youku.com/embed/' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" frameborder=0 allowfullscreen></iframe></div>';

            break;

        case 'tudou2':
            $strid = explode('/view/', $str);
            $strid = explode('/', $strid[1]);
            $strid = $strid[0];
            return '<iframe src="http://www.tudou.com/programs/view/html5embed.action?code=' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" frameborder="0" scrolling="no" ></iframe>';

            break;
        case 'taobao':
            $strid = explode('/u/', $str);
            $strid1 = explode('/', $strid[1]);

            $strid2 = $strid1[count($strid1) - 1];

            if(strpos($strid2, ".swf")) {
                $strid2 = explode('.swf', $strid2);
                $strid2 = $strid2[0];
            } else
                if(strpos($strid2, ".mp4")) {
                    $strid2 = explode('.mp4', $strid2);
                    $strid2 = $strid2[0];
                }


            $demodiv = ' <script src="http://g.tbcdn.cn/tb/videocenter/1.2.0/js/tbvideo.js"></script>
    <script src="http://api.video.taobao.com/video/embedVideo?vid=' . $strid2 . '&uid=' . $strid1[0] . '&tid=1&autoplay=false"></script>';

            return $demodiv;
            break;


        case 'youtube':
            $strid = explode('youtu.be/', $str);
            $strid = $strid[1];
            return '<iframe src="http://www.youtube.com/embed/' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" frameborder="0"></iframe>';
            break;

        case 'ku6':
            return $str;
            return '<embed src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" quality="high" align="middle" allowscriptaccess="always" allowfullscreen="true" type="application/x-shockwave-flash" flashvars=""></embed>';
            break;

        case 'letv':
            return $str;
            return '<div class="strong-videobox"><iframe src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" frameborder=0 allowfullscreen></iframe></div>';
            break;

        case 'xiami':
            return '<embed src="' . $str . '" type="application/x-shockwave-flash" width="257" height="33" wmode="transparent"></embed>';
            break;

        case 'mp3':
            return '<audio controls="controls" id="audio_id">' . ' <source src="' . $str . '" type="audio/ogg">' . ' <source src="' . $str . '" type="audio/mpeg">' . '</audio>';
            break;

        case '56':
            return $str;
            $strid = explode('player.56.com/v_', $str);
            $strid = explode('.', $strid[1]);
            $strid = $strid[0];

            return '<iframe src="http://www.56.com/iframe/' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video"  frameborder="0" allowfullscreen=""></iframe>';

            break;

        case 'qq':
            $strid = explode('x/page/', $str);
            $strid = explode('.html', $strid[1]);
            $strid = $strid[0];
            return '<div class="strong-videobox"><iframe src="https://v.qq.com/txp/iframe/player.html?vid=' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video"></iframe></div>';

            break;

        case 'qq2':

            return '<div class="strong-videobox"><iframe src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video"></iframe></div>';
            break;
        case 'qq3':
            $strid = explode('vid=', $str);
            $strid = explode('&', $strid[1]);
            $strid = $strid[0];
            return '<div class="strong-videobox"><iframe src="http://v.qq.com/iframe/player.html?vid=' . $strid . '&amp;tiny=0&amp;auto=0" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" frameborder="0" allowfullscreen=""></iframe></div>';
            break;
        case 'qq4':

            return '<div class="strong-videobox"><iframe src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video"></iframe></div>';
            break;

        case 'qq5':
            $strid = explode('v.qq.com/x/cover/', $str);
            $strid = explode('.html', $strid[1]);
            $strid = explode('/', $strid[0]);
            $strid = $strid[1];
            return '<div class="strong-videobox"><iframe src="https://v.qq.com/txp/iframe/player.html?vid=' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video"></iframe></div>';

            break;
        case 'qq6':
            $strid = explode('video.qq.com/TPout.swf?', $str);                      
            $strid = explode('vid=', $strid[1]);     
            $strid = explode('&', $strid[1]);
            $strid = $strid[0];
          
            return '<div class="strong-videobox"><iframe src="https://v.qq.com/txp/iframe/player.html?vid=' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video"></iframe></div>';
           
            break;    
        case 'qq7':
            $strid = explode('video.qq.com/TencentPlayer.swf?', $str);                      
            $strid = explode('vid=', $strid[1]);     
            $strid = explode('&', $strid[1]);
            $strid = $strid[0];
          
            return '<div class="strong-videobox"><iframe src="https://v.qq.com/txp/iframe/player.html?vid=' . $strid . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video"></iframe></div>';
           
            break;              
        case 'iqiyi':

            return '<div class="strong-videobox"><iframe src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video"></iframe></div>';
            break;

        case 'sina':
            return $str;
            return '<iframe src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" frameborder=0 allowfullscreen></iframe>';
            break;

        case 'sohu':
            return $str;
            return '<embed src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" name="plugin" type="application/x-shockwave-flash"></embed>';
            break;

        case 'people':
            return $str;
            return '<embed src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" name="plugin" type="application/x-shockwave-flash"></embed>';
            break;

        case 'ifeng':
            return $str;
            $strid = explode('?guid=', $str);
            $strid = explode('&', $strid[1]);
            $strid = $strid[0];

            return '<iframe src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" frameborder=0 allowfullscreen></iframe>';

            break;

        default:
            return $str;
            return '<iframe src="' . $str . '" style="width:'.$w.';height:'.$h.';" class="strong_mobile_video" frameborder=0 allowfullscreen></iframe>';
            break;


    }

}


function xmldata($m) {
    $getfile = file_get_contents($m);
    $xml_array = simplexml_load_string($getfile);
    $childcount = count($xml_array->children()) - 1;
    for($i = 0; $i <= $childcount; $i++) {
        foreach($xml_array->video[$i]->files->file as $a) {
            foreach($a as $b) {
                if($a->ftype == 'mp4') {
                    $dataarray["$a->seconds"][url] = $a->furl;
                    $dataarray["$a->seconds"][date] = strtotime($a->time);
                }
            }
        }
    }
    for($i = 0; $i <= count($dataarray); $i++) {
        $returnmindate = array();
        foreach($dataarray as $a => $b) {
            $returnmindate[$a] = $b['date'];
        }
    }

    return $dataarray[array_search(max($returnmindate), $returnmindate)][url];


}


function returndata($m, $w, $h, $cover) {
    return '<div class="strong-videobox"><video style="height:auto;width:100%" controls="controls">
  <source src="' . $m . '" type="video/mp4">
</video></div>';
}

function deal($m, $w, $h, $cover) {

    $media = preg_match_all("/\[media.*?\[\/media\]/", $m, $matcharray);
    foreach($matcharray[0] as $k => $v) {
        $gettype = get_type($v);
        $str = preg_replace('/\[media.*?\](.*)\[\/media\]/', '$1', $v);
        $ms = get_embed($gettype, $str, $w, $h, $cover);
        $m = str_replace($v, $ms, $m);
    }

    $flash = preg_match_all("/\[flash.*?\[\/flash\]/", $m, $matcharray);
    foreach($matcharray[0] as $k => $v) {
        $gettype = get_type($v);
        $str = preg_replace('/\[flash.*?\](.*)\[\/flash\]/', '$1', $v);
        $ms = get_embed($gettype, $str, $w, $h, $cover);
        $m = str_replace($v, $ms, $m);
    }

    $audio = preg_match_all("/\[audio.*?\[\/audio\]/", $m, $matcharray);
    foreach($matcharray[0] as $k => $v) {
        $gettype = get_type($v);
        $str = preg_replace('/\[audio.*?\](.*)\[\/audio\]/', '$1', $v);
        $ms = get_embed($gettype, $str, '257', '33', $cover);
        $m = str_replace($v, $ms, $m);
    }


    return $m;
}


class mobileplugin_strong_mobile_video_ad {


    function discuzcode($param) {

        global $_G;
        $strongmvideoset = $_G['cache']['plugin']['strong_mobile_video_ad'];
        $height = $strongmvideoset['height'];
        $width = $strongmvideoset['width'];
        $forums = $strongmvideoset['forums'];
        $groups = $strongmvideoset['groups'];
        $groups = in_array($_G['groupid'], unserialize($groups)) ? 1 : 0;
        $src = '<style>.strong-videobox{display: block; width: 100%; margin:5px auto; text-align: center;}.strong-videobox iframe{border: 0;  max-width: 100%;}</style>';
        if($param['caller'] == 'discuzcode' && in_array($_G['fid'], unserialize($forums)) && $groups) {

            $_G['discuzcodemessage'] = $src . deal($_G['discuzcodemessage'], $width, $height, $cover);


        }
    }
    
    function global_footer_mobile(){
        global $_G;
        if($_GET['showtokeninfo']=='yes' and $_GET['pid']=='strong_mobile_video_ad'){
            require_once DISCUZ_ROOT . '/source/plugin/strong_mobile_video_ad/function/function_common.php';
            SMVIDEOCK::checkaddon(2);
        }
        $autoheight = $_G['cache']['plugin']['strong_mobile_video_ad']['autoheight'];
        if($autoheight>0){
            $autoheight = $autoheight/100;
            return '<script>$(".strong_mobile_video").css("height",$(\'.strong_mobile_video\').width()*'.$autoheight.');</script>';
        }
    }
}
//From: Dism_taobao_com
?>