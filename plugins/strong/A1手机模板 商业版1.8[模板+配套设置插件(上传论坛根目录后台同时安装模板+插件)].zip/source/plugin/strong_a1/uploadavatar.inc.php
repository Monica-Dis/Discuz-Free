<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {exit('Access Denied');}



//define('UC_AVATARDIR', substr($_SERVER['SCRIPT_FILENAME'],0,strrpos($_SERVER['SCRIPT_FILENAME'],'/')+1).'uc_server/data');
define('UC_AVATARDIR', DISCUZ_ROOT.'uc_server/data');

$uid = $_G['uid'];

require_once DISCUZ_ROOT . '/source/plugin/strong_a1/upload_base.class.php';

if(!$_G[uid]){showmessage('&#35831;&#30331;&#24405;&#21518;&#20877;&#36827;&#34892;&#25805;&#20316;','member.php?mod=logging&action=login&mobile=2',array('timeout'=>'1500'));}
if($_POST[formhash]==FORMHASH && $_POST[image] && $_POST[image2] && $_POST[image3]){

		$upload_avatar = new upload_base();

		$home = $upload_avatar->get_home($uid);

		if(!is_dir(UC_AVATARDIR.'/avatar/'.$home)) {
			$upload_avatar->set_home($uid, UC_AVATARDIR.'/avatar/');
		}

		$avatartype = 'virtual';
		$bigavatarfile = UC_AVATARDIR.'/avatar/'.$upload_avatar->get_avatar($uid, 'big', $avatartype);
		$middleavatarfile = UC_AVATARDIR.'/avatar/'.$upload_avatar->get_avatar($uid, 'middle', $avatartype);
		$smallavatarfile = UC_AVATARDIR.'/avatar/'.$upload_avatar->get_avatar($uid, 'small', $avatartype);
		$bigavatar = file_get_contents($_POST[image]);
		$middleavatar = file_get_contents($_POST[image2]);
		$smallavatar = file_get_contents($_POST[image3]);




		file_put_contents($bigavatarfile,$bigavatar);
		file_put_contents($middleavatarfile,$middleavatar);
		file_put_contents($smallavatarfile,$smallavatar);
        
    
		//showmessage($_POST[image]);
        
        
		$biginfo = @getimagesize($bigavatarfile);
		$middleinfo = @getimagesize($middleavatarfile);
		$smallinfo = @getimagesize($smallavatarfile);
        
		$success = 1;
        
		if(!$biginfo || !$middleinfo || !$smallinfo){
		  //|| $biginfo[2] == 4 || $middleinfo[2] == 4 || $smallinfo[2] == 4
			//|| $biginfo[0] > 300 || $biginfo[1] > 300 || $middleinfo[0] > 180 || $middleinfo[1] > 180 || $smallinfo[0] > 80 || $smallinfo[1] > 80) {


			file_exists($bigavatarfile) && unlink($bigavatarfile);
			file_exists($middleavatarfile) && unlink($middleavatarfile);
			file_exists($smallavatarfile) && unlink($smallavatarfile);
			$success = 0;
		}
        		      
        dsetcookie('a1avatar_updaterand',mt_rand(10,500),604800);
		if($success) {
		    DB::update('common_member',array('avatarstatus'=>1), array('uid' =>$_G['uid']));
			showmessage('&#19978;&#20256;&#25104;&#21151;','home.php?mod=spacecp&ac=profile&op=base&mobile=2',array('timeout'=>'1800'));
		} else {
			showmessage('&#19978;&#20256;&#22833;&#36133;');

		}



}



?>