<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class mobileplugin_strong_a1 {

    public function common() {
        global $_G;
        $strongset = $_G['cache']['plugin']['strong_a1'];


        if($_G['basescript'] == 'forum' and $_G['gp_mod'] == 'guide') {

            $_GET['view'] = !$_GET['view'] ? 'newthread' : $_GET['view'];
        }

        if($_G['basescript'] == 'forum' and $_GET['mod'] == 'viewthread' and $_GET['page'] > '1' and !$_GET['ajax']) {

            if(in_array($_G['fid'], dunserialize($strongset['threadajaxpage']))) {

                dheader("Location: forum.php?mod=viewthread&tid=$_G[tid]");
            }

        }


    }

    function discuzcode($value) {
        global $_G;

        if($value['caller'] == 'discuzcode') {
            $message = $value['param'][0];
            preg_match_all("/\[img(.*?)\](.*?)\[\/img\]/", $message, $matches);
            if(!count($matches[0])) return '';
            $find = $matches[0];
            $replace = array();
            foreach($matches[2] as $pval) {
                $replace[] = "<img src=" . $pval . " />";
            }

            $_G['discuzcodemessage'] = str_replace($find, $replace, $message);
        }
    }

    function global_header_mobile() {
        global $_G, $signPackage, $wxdata, $article, $postarr;
        $strongset = $_G['cache']['plugin']['strong_a1'];
        $forums = unserialize($strongset[forums]);
        if($_GET['showtokeninfo']=='yes' and $_GET['pid']=='strong_a1'){
            require_once DISCUZ_ROOT . '/source/plugin/strong_a1/function/function_common.php';
        }

        if(strpos($_SERVER["HTTP_USER_AGENT"], "MicroMessenger") === false) {
            return '';
        }

        if($strongset['wxshare']) {
            $jssdk = new JSSDK($strongset['appID'], $strongset['appsecret']);
            $signPackage = $jssdk->GetSignPackage();

            include_once template('strong_a1:module');

            if($_G['basescript'] == 'forum' && CURMODULE == 'viewthread') {

                foreach($postarr as $post) {
                    if($post['first']) {
                        $metadescription = str_replace(array("\r", "\n"), '', messagecutstr(strip_tags($post['message']), 160));
                    }
                }

                $attachtableid = getattachtablebytid(intval($_G['tid']));
                $attach = DB::fetch_first("SELECT * FROM " . DB::table($attachtableid) . " WHERE tid = $_G[tid] and (isimage=1 or isimage='-1')");
                $sattach = $attach[attachment] ? $_G['siteurl'] . getforumimg($attach['aid'], 0, 180, 180) : $strongset['wxsharepic'];


                $wxdata = array(
                    'title' => $_G['forum_thread']['subject'],
                    'link' => $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $_G['tid'],
                    'imgUrl' => $sattach,
                    'desc' => dhtmlspecialchars($metadescription));
                return tpl_jssdk_share();
            } else
                if($_G['basescript'] == 'portal' && CURMODULE == 'view') {
                    $wxdata = array(
                        'title' => $article['title'],
                        'link' => $_G['siteurl'] . 'portal.php?mod=view&aid=' . $article['aid'],
                        'imgUrl' => $article['pic'] ? $_G['siteurl'] . $article['pic'] : $strongset['wxsharepic'],
                        'desc' => dhtmlspecialchars(preg_replace("/\s/", '', $article['summary'])));
                    return tpl_jssdk_share();
                }


        }
        return '';
    }

}


class mobileplugin_strong_a1_forum extends mobileplugin_strong_a1 {

    public function viewthread_top_mobile_output() {
        global $_G;
        $strongset = $_G['cache']['plugin']['strong_a1'];

        if($strongset['grade_bg']) {
            $return = '<style>';
            foreach(explode("\n", $strongset['grade_bg']) as $key => $val) {
                $valarr = explode(',', $val);
                $return .= '.lv_bg_' . $valarr[0] . '{background:' . $valarr[1] . ' !important;}';


            }
            $return .= '</style>';
            return $return;
        }

    }


}

class JSSDK {
    private $appId;
    private $appSecret;

    public function __construct($appId, $appSecret) {
        $this->appId = $appId;
        $this->appSecret = $appSecret;
    }

    public function getSignPackage() {
        $jsapiTicket = $this->getJsApiTicket();

        // ע�� URL һ��Ҫ��̬��ȡ������ hardcode.
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
        $url = "$protocol$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

        $timestamp = time();
        $nonceStr = $this->createNonceStr();

        // ���������˳��Ҫ���� key ֵ ASCII ����������
        $string = "jsapi_ticket=$jsapiTicket&noncestr=$nonceStr&timestamp=$timestamp&url=$url";

        $signature = sha1($string);

        $signPackage = array(
            "appId" => $this->appId,
            "nonceStr" => $nonceStr,
            "timestamp" => $timestamp,
            "url" => $url,
            "signature" => $signature,
            "rawString" => $string);
        return $signPackage;
    }

    private function createNonceStr($length = 16) {
        $chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        $str = "";
        for($i = 0; $i < $length; $i++) {
            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        return $str;
    }


    private function getJsApiTicket() {
        global $_G;
        // jsapi_ticket Ӧ��ȫ�ִ洢����£����´�����д�뵽�ļ�����ʾ��
        //$data = json_decode($this->get_php_file("jsapi_tickets.php"));
        $cachename = 'stronga1_JsApiTicket_'.$_G['cache']['plugin']['strong_a1']['appID'];
        loadcache($cachename);
        $data = $_G['cache'][$cachename];


        if($data['expire_time'] < time()) {
            $accessToken = $this->getAccessToken();

            // �������ҵ�������� URL ��ȡ ticket
            // $url = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=$accessToken";
            $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?type=jsapi&access_token=$accessToken";
            $res = json_decode($this->httpGet($url));
            $ticket = $res->ticket;
            if($ticket) {

                //$data->expire_time = time() + 7000;
                //$data->jsapi_ticket = $ticket;
                //$this->set_php_file("jsapi_ticket.php", json_encode($data));
                $myticket = array('expire_time' => time() + 7000, 'jsapi_ticket' => $ticket);
                savecache($cachename, $myticket);
            }
        } else {
            $ticket = $data['jsapi_ticket'];
        }

        return $ticket;
    }

    private function getAccessToken() {
        global $_G;
        // access_token Ӧ��ȫ�ִ洢����£����´�����д�뵽�ļ�����ʾ��
        //$data = json_decode($this->get_php_file("access_tokens.php"));
        $cachename = 'stronga1_AccessToken_'.$_G['cache']['plugin']['strong_a1']['appID'];
        loadcache($cachename);
        $data = $_G['cache'][$cachename];

        if($data['expire_time'] < time()) {

            // �������ҵ��������URL��ȡaccess_token
            // $url = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=$this->appId&corpsecret=$this->appSecret";
            $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$this->appId&secret=$this->appSecret";
            $res = json_decode($this->httpGet($url));
            $access_token = $res->access_token;
            if($access_token) {
                //$data->expire_time = time() + 7000;
                //$data->access_token = $access_token;
                //$this->set_php_file("access_token.php", json_encode($data));
                $myTokenInfo = array('expire_time' => time() + 7000, 'access_token' => $access_token);
                savecache($cachename, $myTokenInfo);
            }
        } else {
            $access_token = $data['access_token'];
        }

        return $access_token;
    }

    private function httpGet($url) {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($curl, CURLOPT_TIMEOUT, 500);
        // Ϊ��֤��������������΢�ŷ�����֮�����ݴ���İ�ȫ�ԣ�����΢�Žӿڲ���https��ʽ���ã�����ʹ������2�д����ssl��ȫУ�顣
        // ����ڲ�������д����ڴ˴���֤ʧ�ܣ��뵽 http://curl.haxx.se/ca/cacert.pem �����µ�֤���б��ļ���
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, true);
        curl_setopt($curl, CURLOPT_URL, $url);

        $res = curl_exec($curl);
        curl_close($curl);

        return $res;
    }

    private function get_php_file($filename) {
        return trim(substr(file_get_contents($filename), 15));
    }
    private function set_php_file($filename, $content) {
        $fp = fopen($filename, "w");
        fwrite($fp, "<?php exit();?>" . $content);
        fclose($fp);
    }
}
//From: Dism_taobao-com
?>