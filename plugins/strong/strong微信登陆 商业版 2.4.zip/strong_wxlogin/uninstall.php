<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}


$sql = <<<EOF
    DROP TABLE IF EXISTS `pre_strong_wxlogin_authcode`;
    DROP TABLE IF EXISTS `pre_strong_wxlogin_bind`;
    DROP TABLE IF EXISTS `pre_strong_wxlogin_cmd`;
    DROP TABLE IF EXISTS `pre_strong_wxlogin_richresponse`;
    DROP TABLE IF EXISTS `pre_strong_wxlogint_fact`;
EOF;
    runquery($sql);



@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/discuz_plugin_strong_wxlogin.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/discuz_plugin_strong_wxlogin_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/discuz_plugin_strong_wxlogin_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/discuz_plugin_strong_wxlogin_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/discuz_plugin_strong_wxlogin_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/admincp_autoreply.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/admincp_base.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/admincp_menu.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/api.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/bind.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/login.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/more.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/spacecp.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/wechat.class.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/response.class.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/wechat.lib.class.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/function/function_common.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/table/table_strong_wxlogin_authcode.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/table/table_strong_wxlogin_bind.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/table/table_strong_wxlogin_cmd.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/table/table_strong_wxlogin_fact.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/table/table_strong_wxlogin_richresponse.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/uninstall.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/clearcache.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/newplugin.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/customization.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_wxlogin/function/function_common.php');
$finish = TRUE;

?>