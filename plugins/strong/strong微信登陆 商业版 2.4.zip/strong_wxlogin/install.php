<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . '/source/plugin/strong_wxlogin/function/function_common.php';
$sql = <<<EOF

CREATE TABLE `pre_strong_wxlogin_authcode` (
  `sid` char(6) NOT NULL,
  `code` int(10) unsigned NOT NULL,
  `uid` mediumint(8) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sid`),
  UNIQUE KEY `code` (`code`),
  KEY `createtime` (`createtime`)
) ENGINE=MyISAM;

CREATE TABLE `pre_strong_wxlogin_bind` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `openid` char(32) NOT NULL DEFAULT '',
  `unionid` char(32) NOT NULL DEFAULT '',
  `uid` mediumint(8) NOT NULL DEFAULT '0',
  `username` char(15) NOT NULL DEFAULT '',
  `status` smallint(6) NOT NULL DEFAULT '0',
  `dateline` int(10) NOT NULL DEFAULT '0',
  `nickname` varchar(32) NOT NULL DEFAULT '',
  `sex` tinyint(1) NOT NULL DEFAULT '0',
  `counts` smallint(6) NOT NULL DEFAULT '0',
  `lastauth` int(10) NOT NULL DEFAULT '0',
  `subscribe` tinyint(1) NOT NULL DEFAULT '-1',
  `isregister` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `lat` float(10,6) NOT NULL,
  `lng` float(10,6) NOT NULL,
  `setting` blob NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `openid` (`openid`),
  KEY `uid` (`uid`)
) ENGINE=MyISAM AUTO_INCREMENT=49;

CREATE TABLE `pre_strong_wxlogin_cmd` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cmdname` varchar(32) NOT NULL DEFAULT '',
  `alias` varchar(128) NOT NULL DEFAULT '',
  `cmdrtn` varchar(255) NOT NULL DEFAULT '',
  `helptext` varchar(255) NOT NULL DEFAULT '',
  `pattern` varchar(255) NOT NULL DEFAULT '',
  `displayorder` tinyint(2) NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `type` varchar(10) NOT NULL DEFAULT '',
  `responsetype` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25;

CREATE TABLE `pre_strong_wxlogin_richresponse` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `cmdid` int(11) NOT NULL DEFAULT '0',
  `title` varchar(32) NOT NULL DEFAULT '',
  `imgurl` varchar(128) NOT NULL DEFAULT '',
  `link` varchar(128) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8;

CREATE TABLE `pre_strong_wxlogint_fact` (
  `factid` int(10) NOT NULL AUTO_INCREMENT,
  `openid` char(32) NOT NULL DEFAULT '',
  `uid` mediumint(8) NOT NULL DEFAULT '0',
  `username` char(15) NOT NULL DEFAULT '',
  `subject` char(80) NOT NULL DEFAULT '',
  `message` mediumtext NOT NULL,
  `attachment` blob NOT NULL,
  `anonymous` tinyint(1) NOT NULL DEFAULT '0',
  `mobile` varchar(255) NOT NULL DEFAULT '',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `return` varchar(255) NOT NULL DEFAULT '0',
  `tid` mediumint(8) NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`factid`)
) ENGINE=MyISAM;


EOF;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/strong_qqconnect/discuz_plugin_strong_wxlogin.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_qqconnect/discuz_plugin_strong_wxlogin_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_qqconnect/discuz_plugin_strong_wxlogin_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_qqconnect/discuz_plugin_strong_wxlogin_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_qqconnect/discuz_plugin_strong_wxlogin_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_qqconnect/install.php');
$finish = TRUE;
?>
