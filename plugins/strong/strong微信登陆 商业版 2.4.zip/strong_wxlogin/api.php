<?php
define('DISABLEXSSCHECK', true);

chdir('../../../');

require './source/class/class_core.php';

$discuz = C::app();

$cachelist = array('plugin');

$discuz->cachelist = $cachelist;
$discuz->init();




require_once DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/wechat.lib.class.php';
require_once DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/response.class.php';
global $_G; 
$_G['strong_wxlogin']['setting'] = unserialize($_G['setting']['strong_wxlogin']);


new WeChatServer($_G['strong_wxlogin']['setting']['wechat_token'], array(
    'receiveAllStart' => 'receiveallstart',
	'receiveEvent::subscribe' => 'subscribe',
	'receiveEvent::scan' => 'scan',
	'receiveEvent::unsubscribe' => 'unsubscribe',
	'receiveEvent::click' => 'click',
    'receiveEvent::location' => 'location',
    'receiveEvent::templatesendjobfinish' => 'templatesendjobfinish',
	'receiveMsg::text' => 'text',
    'receiveMsg::image' => 'image',
    'receiveAllEnd' => 'receiveallend',
));










?>