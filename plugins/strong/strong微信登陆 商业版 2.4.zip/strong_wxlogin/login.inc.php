<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

global $_G,$swxloginset;
$appid = $_G['strong_wxlogin']['setting']['wechat_appId'];
$secret = $_G['strong_wxlogin']['setting']['wechat_appsecret'];
$referer = $_GET['dreferers'] ? urldecode($_GET['dreferers']) : dreferer();


include_once DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/wechat.lib.class.php';
$wechat_client = new WeChatClient($_G['strong_wxlogin']['setting']['wechat_appId'], $_G['strong_wxlogin']['setting']['wechat_appsecret']);


if($_GET['code']) {
    echo  $swxloginset['newusergroupid'];

    $token = $wechat_client->getAccessTokenByCode($_GET['code']);
    if(!$token['openid']) {
        showmessage(lang('plugin/strong_wxlogin', 'oauth_grant_error'), $referer);
    }

    require_once libfile('function/member');
    $bind_member = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_openid($token['openid']);


    $userinfo = $wechat_client->getUserInfoByAuth($token['access_token'], $token['openid']);


    if($userinfo) {
        $bind_member = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_openid($token['openid']);

        if($_G['uid']) {
            $exist_bind_member = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_uid($_G['uid']);
            if($exist_bind_member){            
           
                C::t('#strong_wxlogin#strong_wxlogin_bind')->update($exist_bind_member['id'], array(
                    'openid' => $userinfo['openid'],
                    'unionid' => $userinfo['unionid'],
                    'nickname' => dhtmlspecialchars(diconv($userinfo['nickname'], 'utf-8', CHARSET)),
                    'sex' => intval($userinfo['sex'])));
                    $member = getuserbyuid($exist_bind_member['uid']);
            }else{
                C::t('#strong_wxlogin#strong_wxlogin_bind')->insert(array(
                    'openid' => $token['openid'],
                    'uid' => $_G['uid'],
                    'username' => $_G['username'],
                    'nickname' => dhtmlspecialchars(diconv($userinfo['nickname'], 'utf-8', CHARSET)),
                    'sex' => intval($userinfo['sex']),
                    'dateline' => TIMESTAMP,
                    'unionid' => $userinfo['unionid'],
                    'lastauth' => TIMESTAMP,
                    'counts' => 1,
                    'subscribe' => $info['subscribe'],
                    'isregister' => 1,
                    ));
                    $member = getuserbyuid($_G['uid']);
                
            }
            
        } elseif($bind_member) {

            $member = getuserbyuid($bind_member['uid']);
            if(empty($member)) {
                C::t('#strong_wxlogin#strong_wxlogin_bind')->delete($bind_member['id']);
                unset($bind_member);
            }

        } else {

            $regname = WeChat::getnewname($userinfo['nickname']);
            $uid = WeChat::register($regname, 1, $swxloginset['newusergroupid'], $userinfo['sex']);
            if($uid) {
                WeChat::syncAvatar($uid, $userinfo['headimgurl']);
                C::t('#strong_wxlogin#strong_wxlogin_bind')->insert(array(
                    'openid' => $token['openid'],
                    'uid' => $uid,
                    'username' => $_G['username'],
                    'nickname' => dhtmlspecialchars(diconv($userinfo['nickname'], 'utf-8', CHARSET)),
                    'sex' => intval($userinfo['sex']),
                    'dateline' => TIMESTAMP,
                    'unionid' => $userinfo['unionid'],
                    'lastauth' => TIMESTAMP,
                    'counts' => 1,
                    'subscribe' => $info['subscribe'],
                    'isregister' => 1,
                    ));


                $member = getuserbyuid($uid);


            }

        }

        setloginstatus($member, 1296000);
        dheader('Location:' . $referer);


    }


}
//From: Dism_taobao-com
?>