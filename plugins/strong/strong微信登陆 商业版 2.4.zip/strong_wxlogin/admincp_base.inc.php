<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$stronglang = $scriptlang['strong_wxlogin'];
$setting = (array)unserialize($_G['setting']['strong_wxlogin']);
$setting['wechat_appsecret'] = authcode($setting['wechat_appsecret'], 'DECODE', $_G['config']['security']['authkey']);
$appsecret_mask = $setting['wechat_appsecret'] ? substr($setting['wechat_appsecret'], 0, 3).'************************'.substr($setting['wechat_appsecret'], -3) : '';
$apiurl = $_G['siteurl'].'source/plugin/strong_wxlogin/api.php';


//var_dump($setting);

if(!submitcheck('basesubmit')) {
	showformheader('plugins&operation=config&do='.$pluginid.'&identifier='.$plugin[identifier].'&pmod=admincp_base', 'enctype');
	
	showtableheader($stronglang['admincp_base_title_1']);
	showsetting($stronglang['admincp_base_apiurl'], '', '', '<span style="white-space:nowrap">'.$apiurl.'</span>');
	showsetting($stronglang['admincp_base_token'], 'setting[wechat_token]', $setting['wechat_token'], 'text', '', 0, $stronglang['admincp_base_token_tips']);
	showsetting($stronglang['admincp_base_encodingkey'], 'setting[wechat_aeskey]', $setting['wechat_aeskey'], 'text', '', 0, $stronglang['admincp_base_encodingkey_tips']);
	showtablefooter();/*Dism��taobao��com*/
	
	
	showtableheader($stronglang['admincp_base_title_2']);
	showsetting(lang('plugin/wechat', 'wechat_appId'), 'setting[wechat_appId]', $setting['wechat_appId'], 'text', '', 0, $stronglang['admincp_base_appid']);
	showsetting(lang('plugin/wechat', 'wechat_appsecret'), 'setting[wechat_appsecret]', $appsecret_mask, 'text', '', 0, $stronglang['base_secret']);
	showtablefooter();/*Dism��taobao��com*/

/*	
	showtableheader($stronglang['admincp_base_title_5']);
	showsetting($stronglang['admincp_base_wechatname'], 'setting[wechat_name]', $setting['wechat_name'], 'text');
	showsetting($stronglang['admincp_base_qrcode'], 'wechat_qrcode', '', 'file', '', 0, imglable($setting['wechat_qrcode']));
	showsetting($stronglang['admincp_base_shareicon'], 'wechat_shareicon', '', 'file', '', 0, imglable($setting['wechat_shareicon']));
	showsetting($stronglang['admincp_base_subscribe_url'], 'setting[wechat_subscribe_url]', $setting['wechat_subscribe_url'], 'text');
	showtablefooter();
*/	
	showtableheader();
	showsubmit('basesubmit');
	showtablefooter();/*Dism��taobao��com*/
	
	showformfooter();
} else {
    

   
	if($_GET['setting']['wechat_appId'] && $_GET['setting']['wechat_appsecret']) {
	
	    $_GET['setting']['wechat_appsecret'] = $_GET['setting']['wechat_appsecret'] == $appsecret_mask ? $setting['wechat_appsecret'] : $_GET['setting']['wechat_appsecret'];
	    	
		require_once DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/wechat.lib.class.php';
		$wechat_client = new WeChatClient($_GET['setting']['wechat_appId'], $_GET['setting']['wechat_appsecret']);
		if(!$wechat_client->getAccessToken(1, 1)) {
		 
			cpmsg(lang('plugin/strong_wxlogin', 'admincp_base_conn_geterror'), '', 'error');
		}
		
		$_GET['setting']['wechat_appsecret'] = authcode($_GET['setting']['wechat_appsecret'], 'ENCODE', $_G['config']['security']['authkey']);

		$option = array(
			'scene_id' => 100000,
			'expire' => 30,
			'ticketOnly' => 1
		);
		$ticket = $wechat_client->getQrcodeTicket($option);
		if(!$wechat_client->getQrcodeImgUrlByTicket($ticket)) {
			cpmsg(lang('plugin/wechat', 'wechat_at_qrgeterror'), '', 'error');
		}
	}
    	$settings = array('strong_wxlogin' => serialize($_GET['setting'] + $setting));
	C::t('common_setting')->update_batch($settings);
	updatecache('setting');
	
	cpmsg('setting_update_succeed', 'action=plugins&operation=config&do='.$pluginid.'&identifier='.$plugin['identifier'].'&pmod=admincp_base', 'succeed');
    
}

function imglable($src, $comment = '') {
    global $_G;
    return $src ? "<img width='80' height='80' src='{$_G[setting][attachurl]}$src' /><label>".$comment.'</label>' : ''; 
}



?>