<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$langs = &$scriptlang['strong_wxlogin'];
$operation = in_array($_GET['operation'], array(
    'cus',
    'del',
    'install')) ? $_GET['operation'] : 'cus';

echo <<< EOT
    <script type="text/JavaScript">
        var rowtypedata = [
        [[1,'<input type="text" class="s-td-50" name="newdisplayorder[]" value="0" />', ''], [1,'<input type="text" class="td31" name="newalias[]" value="" />', ''],
        [5, '<div><span class="lightfont">{$langs[admincp_add]}</span> <a href="javascript:;" class="deleterow" onClick="deleterow(this)">{$langs[admincp_del]}</a></div>']],

        [[1,'', ''], [1,'{$langs[admincp_title]}<input type="text" class="td31" name="newresponsetitle[{1}][]" value="" />', ''], [1,'<span class="">{$langs[admincp_des]}</span><textarea type="text"  name="newresponsedescription[{1}][]" class="txt" style="height:15px;"></textarea>', 'longtxt'], [1,'{$langs[admincp_imgurl]}<input type="text" class="td31" name="newresponseimgurl[{1}][]" value="" />', ''], [1,'{$langs[admincp_url]}<input type="text" class="td31" name="newresponselink[{1}][]" value="" />', ''],
        [5, '<div><span class="lightfont">{$langs[admincp_del]} </span> <a href="javascript:;" class="deleterow" onClick="deleterow(this)">{$langs[admincp_del]}</a></div>']],
        ];
    </script>
    <style>
        span.dtitle {width:30px;display:block; float:left;line-height: 40px;}
        
    </style>

EOT;


if($operation == 'cus') {

    if(submitcheck('editsubmit')) {


        if(is_array($_GET['newalias'])) {
            foreach($_GET['newalias'] as $key => $value) {
                $newaliasvalue = trim($value);
                if(empty($newaliasvalue)) {
                    continue;
                }
                C::t('#strong_wxlogin#strong_wxlogin_cmd')->insert(array(
                    'displayorder' => $_GET['newdisplayorder'][$key],
                    'alias' => $newaliasvalue,
                    'cmdrtn' => $_GET['newcmdrtn'][$key],
                    'helptext' => $_GET['newhelptext'][$key],
                    'type' => 'custom',
                    'responsetype' => '1'));
            }
        }
        if(is_array($_GET['alias'])) {
            foreach($_GET['alias'] as $key => $value) {
                $aliasvalue = trim($value);
                if(empty($aliasvalue)) {
                    continue;
                }
                C::t('#strong_wxlogin#strong_wxlogin_cmd')->update($key, array(
                    'displayorder' => $_GET['displayorder'][$key],
                    'alias' => $aliasvalue,
                    'cmdrtn' => $_GET['cmdrtn'][$key],
                    'helptext' => $_GET['helptext'][$key],
                    'type' => 'custom',
                    'responsetype' => $_GET['responsetype'][$key],
                    'status' => empty($_GET['status'][$key]) ? 0 : 1));
            }
        }
        if(is_array($_GET['newresponsetitle'])) {
            foreach($_GET['newresponsetitle'] as $cmdid => $response) {
                foreach($response as $key => $title) {
                    if(empty($title)) {
                        continue;
                    }
                    C::t('#strong_wxlogin#strong_wxlogin_richresponse')->insert(array(
                        'cmdid' => $cmdid,
                        'title' => $_GET['newresponsetitle'][$cmdid][$key],
                        'imgurl' => $_GET['newresponseimgurl'][$cmdid][$key],
                        'link' => $_GET['newresponselink'][$cmdid][$key],
                        'description' => $_GET['newresponsedescription'][$cmdid][$key]));
                }
            }
        }
        if(is_array($_GET['responsetitle'])) {
            foreach($_GET['responsetitle'] as $cmdid => $response) {
                foreach($response as $key => $title) {
                    if(empty($title)) {
                        continue;
                    }
                    C::t('#strong_wxlogin#strong_wxlogin_richresponse')->update($key, array(
                        'cmdid' => $cmdid,
                        'title' => $_GET['responsetitle'][$cmdid][$key],
                        'imgurl' => $_GET['responseimgurl'][$cmdid][$key],
                        'link' => $_GET['responselink'][$cmdid][$key],
                        'description' => $_GET['responsedescription'][$cmdid][$key]));
                }
            }
        }
        cpmsg('setting_update_succeed', "action=plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]&operation=cus", 'succeed');
    } else {
        showtips($langs['admincp_subscribedes']);


        showformheader("plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]&operation=cus", 'editsubmit');
        showtableheader('');
        showsubtitle(array(
            $langs['admincp_subtitle1'],
            $langs['admincp_subtitle2'],
            $langs['admincp_subtitle3'],
            $langs['admincp_subtitle4'],
            $langs['admincp_subtitle5'],
            $langs['admincp_subtitle6']), 'header', array());
        $cuscmd = C::t('#strong_wxlogin#strong_wxlogin_cmd')->fetch_all_by_type('custom', -1, '>=', '');
        foreach($cuscmd as $cmd) {
            showtablerow('', array(
                'class="td28"',
                'class="td31"',
                'class="longtxt" style="width:400px"',
                'class="td31"',
                'class="td31"',
                ''), array(
                '<input type="text" value="' . $cmd['displayorder'] . '" name="displayorder[' . $cmd['id'] . ']" class="txt">',
                '<input type="text" value="' . $cmd['alias'] . '" name="alias[' . $cmd['id'] . ']" class="td31"> ',
                '<textarea type="text" name="cmdrtn[' . $cmd['id'] . ']" class="txt" onblur="this.style.height=\'15px\'" onfocus="this.style.height=\'100px\';" style="height:15px;">' . $cmd['cmdrtn'] . '</textarea>',
                '<input type="radio" value="1" name="responsetype[' . $cmd['id'] . ']" ' . ($cmd['responsetype'] == 1 ? 'checked' : '') . '>' . $langs['admincp_subtitle7'] . '<input type="radio" value="2" name="responsetype[' . $cmd['id'] . ']" ' . ($cmd['responsetype'] == 2 ? 'checked' : '') . '>' . $langs['admincp_subtitle8'] .
                    '',
                '<input type="checkbox"' . ($cmd['status'] > 0 ? 'checked' : '') . ' name="status[' . $cmd['id'] . ']">',
                '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]&operation=del&type=cmd&id=$cmd[id]&formhash=" . FORMHASH .'">' . cplang('delete') . '<a>'));
            $responsearray = C::t('#strong_wxlogin#strong_wxlogin_richresponse')->fetch_all_by_cmdid($cmd['id']);
            foreach($responsearray as $response) {
                showtablerow("class='rich_row_$response[cmdid] richmsg' style='background:#FAFAFA;'", array(
                    '',
                    '',
                    'class="longtxt"'), array(
                    '',
                    $langs['admincp_autoreply_title'] . "<input type='text' class='td31' value='$response[title]' name='responsetitle[$response[cmdid]][$response[id]]'>",
                    "<span class=''>$langs[admincp_autoreply_desc]</span>" . "<textarea type='text' name='responsedescription[$response[cmdid]][$response[id]]' class='txt'>$response[description]</textarea>",
                    "$langs[admincp_autoreply_picurl]<input type='text' class='td31' value='$response[imgurl]' name='responseimgurl[$response[cmdid]][$response[id]]'>",
                    "$langs[admincp_autoreply_link]<input type='text' class='td31' value='$response[link]' name='responselink[$response[cmdid]][$response[id]]'>",
                    '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]&operation=del&type=response&id=$response[id]" . '">' . cplang('delete') . '<a>'));
            }

            showtablerow("class='rich_row_$cmd[id]'", array('colspan="15"'), array('<div class="lastboard"><a href="###" onclick="addrow(this, 1, ' . $cmd['id'] . ')" class="addtr">' . $langs['admincp_subtitle9'] . '</a><span></span></div>'));
        }
        showtablerow('', array('colspan="15"'), array("<div><a href=\"###\" onclick=\"addrow(this, 0)\" class=\"addtr\">" . $langs['admincp_subtitle10'] . "</a></div>"));
        showsubmit('editsubmit', 'submit', "");
        showtablefooter();/*Dism��taobao��com*/
        showformfooter();
    }

} else
    if($operation == 'del' and $_GET['formhash'] == FORMHASH) {
        if($_GET['type'] == 'cmd') {
            C::t('#strong_wxlogin#strong_wxlogin_cmd')->delete(array('id' => $_GET['id']));
        } else
            if($_GET['type'] == 'response') {
                C::t('#strong_wxlogin#strong_wxlogin_richresponse')->delete(array('id' => $_GET['id']));
            }
        cpmsg($langs['admincp_cpmsg_deletesuccess'], "action=plugins&operation=config&identifier=$plugin[identifier]&pmod=$module[name]&operation=cus", 'succeed');
    } else if($operation == 'install' and $_GET['formhash'] == FORMHASH) {
            $extname = trim($_GET['extname']);
            if(C::t('#strong_wxlogin#strong_wxlogin_cmd')->exist_by_cmdname($extname)) {
                cpmsg($langs['admincp_cpmsg_extinstalled'], 'action=plugins&operation=config&identifier=strong_wxlogin&pmod=admincp_cmd&operation=ext', 'error');
            } else {
                $dir = DISCUZ_ROOT . './source/plugin/strong_wxlogin/extension';
                $content = file_get_contents($dir . '/extension_' . $_GET['extname'] . '.php');
                if($content) {
                    $content = diconv($content, 'UTF-8', CHARSET);
                    preg_match("/alias\:(.+?)\n/", $content, $r);
                    $alias = trim($r[1]);
                    preg_match("/helptext\:(.+?)\n/", $content, $r);
                    $helptext = trim($r[1]);
                    preg_match("/pattern\:(.+?)\n/", $content, $r);
                    $pattern = trim($r[1]);
                    $data = array(
                        'cmdname' => dhtmlspecialchars($_GET['extname']),
                        'alias' => dhtmlspecialchars($alias),
                        'helptext' => dhtmlspecialchars($helptext),
                        'pattern' => dhtmlspecialchars($pattern),
                        'type' => 'extension',
                        );
                    C::t('#strong_wxlogin#strong_wxlogin_cmd')->insert($data);
                    cpmsg($langs['admincp_cpmsg_extinstallsuccess'], 'action=plugins&operation=config&identifier=strong_wxlogin&pmod=admincp_cmd&operation=ext', 'succeed');
                } else {
                    cpmsg($langs['admincp_cpmsg_extnotexist'], 'action=plugins&operation=config&identifier=strong_wxlogin&pmod=admincp_cmd&operation=ext', 'error');
                }
            }

        }
//From: Dism_taobao-com
?>