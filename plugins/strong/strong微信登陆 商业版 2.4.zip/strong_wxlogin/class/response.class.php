<?php
/*
 *DisM!应用中心：dism.taobao.com
 *更多商业插件/模版下载 就在DisM!应用中心
 *本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 *如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class WxMpResponse {
    private static $expire = 1296000;
    private static $systemcmd;
    private static $customcmd;
    private static $extensioncmd;
    private static $cmdlist;

    function __construct() {
        global $_G;

        if(!$_G['strong_wxlogin']) {
            $_G['strong_wxlogin']['setting'] = unserialize($_G['setting']['strong_wxlogin']);
            $_G['strong_wxlogin']['setting']['wechat_appsecret'] = authcode($_G['strong_wxlogin']['setting']['wechat_appsecret'], 'DECODE', $_G['config']['security']['authkey']);
        }

        $cmdlist = C::t('#strong_wxlogin#strong_wxlogin_cmd')->fetch_all_by_status(0, '<>');
        foreach($cmdlist as &$cmd) {
            $cmd['alias'] = empty($cmd['alias']) ? $cmd['cmdname'] : $cmd['alias'];
            if($cmd['type'] == 'system') {
                self::$systemcmd[$cmd['cmdname']] = $cmd;
            } else
                if($cmd['type'] == 'extension') {
                    self::$extensioncmd[$cmd['cmdname']] = $cmd;
                }
        }
        
       
        $this->_cmdsort($cmdlist);
        self::$cmdlist = $cmdlist;
        
    }


    function receiveallstart($param) {
        global $_G;

        list($data) = $param;

        if(!is_writable(session_save_path())) {
            if(!is_dir(DISCUZ_ROOT . 'data/tmp')) mkdir(DISCUZ_ROOT . 'data/tmp', 0700);
            session_save_path(DISCUZ_ROOT . 'data/tmp');
        }
        session_id(md5($data['from'] . $_G['config']['security']['authkey']));
        if(!session_start()) {
            echo WeChatServer::getXml4Txt('session initiate failed');
            exit;
        }
    }

    function receiveallend($param) {

    }

    function subscribe($param) {
        list($data) = $param;
        global $_G;
        
        $bindmember = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_openid($data['from']);
        if($bindmember) {
            C::t('#strong_wxlogin#strong_wxlogin_bind')->update($bindmember['id'], array('subscribe' => 1, ));
        }
        
        if($data['key']) { // 未关注, 扫描
            $data['content'] = $data['key'];
            if(is_numeric($data['key']) && strlen($data['key']) == 6) {
                $this->_sendnum($data);
            } else {
                $this->_query($data);
            }
            exit;
        } else {
            $data['content'] = 'subscribe';
        }


        
        $this->_query($data);
    }

    function scan($param) {
        list($data) = $param;


        if($data['key']) { // 已关注, 扫描
            $data['content'] = $data['key'];
            if(is_numeric($data['key']) && strlen($data['key']) == 6) {
                $this->_sendnum($data);
            } else {
                $this->_query($data);
            }
            exit;
        }
    }

    function unsubscribe($param) {
        list($data) = $param;
        $bindmember = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_openid($data['from']);
        if($bindmember) {
            C::t('#strong_wxlogin#strong_wxlogin_bind')->update($bindmember['id'], array('subscribe' => 0, ));
        }
    }

    function image($param) {
        global $_G;
        list($data) = $param;
        if($_SESSION['wx']['fact_receive']) {
            $factlang = array();
            foreach(explode("\n", $_G['strong_wxlogin']['setting']['fact_lang']) as $langsetting) {
                list($langkey, $langval) = explode('=', $langsetting);
                $langkey && $langval && $factlang[$langkey] = trim($langval);
            }

            $fact = C::t('#strong_wxlogin#strong_wxlogin_fact')->fetch_unused_by_openid($data['from']);
            $fact['attachment'] = unserialize($fact['attachment']);
            $fact['attachment'][$data['mid']] = $data['url'];
            C::t('#strong_wxlogin#strong_wxlogin_fact')->update_unused_by_openid($data['from'], array('attachment' => serialize($fact['attachment'])));
            echo WeChatServer::getXml4Txt($factlang['fact_receive_continue'] ? $factlang['fact_receive_continue'] : lang('plugin/strong_wxlogin', 'fact_receive_continue'));
            exit;
        }
    }

    function location($param) {
        list($data) = $param;
        if($data['type'] == 'event') { // 上报分支
            $json = WeChatClient::get("http://apis.map.qq.com/ws/coord/v1/translate?locations={$data[la]},{$data[lo]}&type=1&key=EC5BZ-XRV3G-5PZQD-IXEXW-CGA56-NHFXI");
            $json = json_decode($json, true);
            if($json['status'] == 0) {
                C::t('#strong_wxlogin#strong_wxlogin_bind')->update_by_openid($data['from'], array('lat' => $json['locations'][0]['lat'], 'lng' => $json['locations'][0]['lng']));
            }
        }
        exit("");
    }

    function click($param) {
        global $_G;

        $param[0]['content'] = $param[0]['key'];
        $this->text($param);
    }

    function templatesendjobfinish($param) {
        list($data) = $param;
        if($data['msg_id']) {            
            DB::update('strong_wxnotice_tmplmsg',array('status' =>  $data['status']), array('msgid' =>$data['msg_id']));
        }
    }

    function text($param) {
        global $_G;

        list($data) = $param;
        $data['content'] = diconv($data['content'], 'UTF-8');


        if(is_numeric($data['content']) && strlen($data['content']) == 6) { // 登录/绑定分支
            unset($_SESSION['wx']);
            $this->_sendnum($data);
        } else
            if($_G['strong_wxlogin']['setting']['dkf_allowservice'] && (($data['type'] == 'text' && trim($_G['strong_wxlogin']['setting']['dkf_keyword']) === '*') || in_array($data['content'], explode(',', $_G['strong_wxlogin']['setting']['dkf_keyword'])))) {
                unset($_SESSION['wx']);
                $this->_transferCustomerService($data);
            } else
                if(in_array($data['content'], explode(',', $_G['strong_wxlogin']['setting']['fact_keyword'])) || $_SESSION['wx']['fact_receive']) { // 爆料分支
                    $factlang = array();
                    foreach(explode("\n", $_G['strong_wxlogin']['setting']['fact_lang']) as $langsetting) {
                        list($langkey, $langval) = explode('=', $langsetting);
                        $langkey && $langval && $factlang[$langkey] = trim($langval);
                    }

                    $data['content'] = trim(strtolower($data['content']));


                    if($_SESSION['wx']['fact_receive'] && $data['content'] != 'ok') {
                        unset($_SESSION['wx']);
                        echo WeChatServer::getXml4Txt($factlang['fact_receive_error'] ? $factlang['fact_receive_error'] : lang('plugin/strong_wxlogin', 'fact_receive_error'));
                        exit;
                    }

                    if($data['content'] == 'ok' && $_SESSION['wx']['fact_receive']) {
                        unset($_SESSION['wx']);
                        $fact = C::t('#strong_wxlogin#strong_wxlogin_fact')->fetch_unused_by_openid($data['from']);
                        echo WeChatServer::getXml4Txt($factlang['fact_receive_end'] ? "<a href=\"$_G[siteurl]plugin.php?id=strong_wxlogin:fact&factid=$fact[factid]\">$factlang[fact_receive_end]</a>" : lang('plugin/strong_wxlogin', 'fact_receive_end', array('url' => $_G['siteurl'] . 'plugin.php?id=strong_wxlogin:fact&factid=' .
                                $fact['factid'])));
                        exit;
                    } else {
                        C::t('#strong_wxlogin#strong_wxlogin_fact')->delete_unused_by_openid($data['from']);
                        C::t('#strong_wxlogin#strong_wxlogin_fact')->insert(array(
                            'openid' => $data['from'],
                            'status' => 0,
                            'dateline' => TIMESTAMP));
                        $_SESSION['wx']['fact_receive'] = true;
                        echo WeChatServer::getXml4Txt($factlang['fact_receive_welcome'] ? $factlang['fact_receive_welcome'] : lang('plugin/strong_wxlogin', 'fact_receive_welcome'));
                        exit;
                    }
                } else {

                    $this->_query($data);
                }
    }

    function _sendnum($data) {
        global $_G;


        $authcode = C::t('#strong_wxlogin#strong_wxlogin_authcode')->fetch_by_code($data['content']);
        if($authcode && !$authcode['status']) {

            require_once libfile('function/member');
            require_once DISCUZ_ROOT . './source/plugin/strong_wxlogin/wechat.class.php';
            $wechat_client = new WeChatClient($_G['strong_wxlogin']['setting']['wechat_appId'], $_G['strong_wxlogin']['setting']['wechat_appsecret']);

            $bindmember = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_openid($data['from']);
            if(empty($bindmember)) {
                $info = $wechat_client->getUserInfoById($data['from']);
                if($info['unionid']) {
                    $bindmember = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_unionid($info['unionid']);
                }
            }

            if(!$authcode['uid'] && $bindmember) { // 登录微信已绑定的账号
                C::t('#strong_wxlogin#strong_wxlogin_authcode')->update($authcode['sid'], array('uid' => $bindmember['uid'], 'status' => 1));
            } else
                if(!$authcode['uid'] && empty($bindmember)) { // 注册新账号
                    // 此处用户已关注, 直接使用info接口


                    $regname = WeChat::getnewname($info['nickname']);

                    $uid = WeChat::register($regname, 1, 0, $info['sex']);

                    if($uid) {
                        WeChat::syncAvatar($uid, $info['headimgurl']);
                        C::t('#strong_wxlogin#strong_wxlogin_bind')->insert(array(
                            'openid' => $info['openid'],
                            'uid' => $uid,
                            'username' => $regname,
                            'nickname' => dhtmlspecialchars(diconv($info['nickname'], 'utf-8', CHARSET)),
                            'sex' => intval($info['sex']),
                            'dateline' => TIMESTAMP,
                            'unionid' => $info['unionid'],
                            'lastauth' => TIMESTAMP,
                            'counts' => 1,
                            'subscribe' => $info['subscribe'],
                            'isregister' => 1,
                            ));
                        C::t('#strong_wxlogin#strong_wxlogin_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));

       
                    } else {
                        echo WeChatServer::getXml4Txt(lang('plugin/strong_wxlogin', 'swx_register_error'));
                    }
                } else
                    if($authcode['uid']) {
                        $member = getuserbyuid($authcode['uid'], 1);
                        $current_bind_member = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_uid($authcode['uid']);
                        if($bindmember && $bindmember['uid'] != $authcode['uid']) { // 绑定账号不一致
                            C::t('#strong_wxlogin#strong_wxlogin_bind')->delete($current_bind_member['id']);
                            C::t('#strong_wxlogin#strong_wxlogin_bind')->update($bindmember['id'], array(
                                'uid' => $member['uid'],
                                'username' => $member['username'],
                                'isregister' => $current_bind_member['isregister']), true);
                        } else
                            if(empty($bindmember)) {
                                if(empty($current_bind_member)) {
                                    C::t('#strong_wxlogin#strong_wxlogin_bind')->insert(array(
                                        'openid' => $info['openid'],
                                        'uid' => $member['uid'],
                                        'username' => $member['username'],
                                        'nickname' => dhtmlspecialchars(diconv($info['nickname'], 'utf-8', CHARSET)),
                                        'sex' => intval($info['sex']),
                                        'dateline' => TIMESTAMP,
                                        'unionid' => $info['unionid'],
                                        'lastauth' => TIMESTAMP,
                                        'counts' => 1,
                                        'subscribe' => $info['subscribe']));
                                } else {
                                    C::t('#strong_wxlogin#strong_wxlogin_bind')->update($current_bind_member['id'], array(
                                        'openid' => $info['openid'],
                                        'unionid' => $info['unionid'],
                                        'nickname' => dhtmlspecialchars(diconv($info['nickname'], 'utf-8', CHARSET)),
                                        'sex' => intval($info['sex']),
                                        'subscribe' => $info['subscribe']));
                                }
                            }
                        C::t('#strong_wxlogin#strong_wxlogin_authcode')->update($authcode['sid'], array('status' => 1));
                    }


            echo WeChatServer::getXml4Txt(lang('plugin/strong_wxlogin', 'swx_success_text'));


        }
    }

    function _transferCustomerService($data) {
        global $_G;

        $inworktime = true;
        if($_G['strong_wxlogin']['setting']['dkf_worktimelimit']) {
            $inworktime = false;
            $todayts = strtotime(dgmdate(TIMESTAMP, 'Ymd'));
            foreach($_G['strong_wxlogin']['setting']['dkf_worktime'] as $time) {
                if(TIMESTAMP > $todayts + $time && TIMESTAMP < $todayts + $time + 1800) {
                    $inworktime = true;
                    break;
                }
            }
        }

        // 工作时间优先, 非工作时间直接拒绝
        if(!$_G['strong_wxlogin']['setting']['dkf_priority'] && !$inworktime) {
            echo WeChatServer::getXml4Txt($_G['strong_wxlogin']['setting']['dkf_notworktime']);
            exit;
        }

        $wechat_client = new WeChatClient($_G['strong_wxlogin']['setting']['wechat_appId'], $_G['strong_wxlogin']['setting']['wechat_appsecret']);
        $info = $wechat_client->getCustomerServiceList();

        if(count($info['kf_online_list']) == 0) {
            echo WeChatServer::getXml4Txt(!$inworktime ? $_G['strong_wxlogin']['setting']['dkf_notworktime'] : $_G['strong_wxlogin']['setting']['dkf_offline']);
            exit;
        }

        echo WeChatServer::getXml4CustomerService();
        $wechat_client = new WeChatClient($_G['strong_wxlogin']['setting']['wechat_appId'], $_G['strong_wxlogin']['setting']['wechat_appsecret']);
        $wechat_client->sendTextMsg($data['from'], $_G['strong_wxlogin']['setting']['dkf_greet']);
    }

    function _query($data) {
        global $_G;

        $key = preg_replace("/ +/", " ", $data['content']);
        list($cmdname, $actionstr) = explode(' ', $key, 2);
        $match = '';

        // full match
        foreach(self::$cmdlist as $cmd) {
            if($cmd['type'] == 'custom' && in_array($cmdname, explode(',', $cmd['alias']))) {
                $match = $cmd;
                unset($_SESSION['wx']);
                break;
            }
        }


        if($match) {
            if($match['responsetype'] == 1) {
                echo WeChatServer::getXml4Txt($match['cmdrtn']);
            } else {
                foreach(C::t('#strong_wxlogin#strong_wxlogin_richresponse')->fetch_all_by_cmdid($match['id']) as $id => $richitem) {
                    $list[] = array(
                        'title' => $richitem['title'],
                        'desc' => $richitem['description'],
                        'pic' => $richitem['imgurl'],
                        'url' => $richitem['link'],
                        );
                }
                echo WeChatServer::getXml4RichMsgByArray($list);
            }

            exit;
        }

        // session match
        if(isset($_SESSION['wx']['extend'])) {
            @include_once DISCUZ_ROOT . './source/plugin/' . $_SESSION['wx']['extend'] . '/wechat_module.class.php';
            if(class_exists('wechat_module')) {
                $extmodule = new wechat_module($data);
                $extmodule->doResponse();
            } else {
                echo WeChatServer::getXml4Txt('No found the module in ' . $_SESSION['wx']['extend']);
                unset($_SESSION['wx']);
            }
            exit;
        }

        // extension match
        foreach(self::$cmdlist as $cmd) {
            if($cmd['type'] != 'extension') continue;
            if(preg_match($cmd['pattern'], $key)) {
                @include_once DISCUZ_ROOT . './source/plugin/' . $cmd['cmdname'] . '/wechat_module.class.php';
                if(class_exists('wechat_module')) {
                    $extmodule = new wechat_module($data);
                    $extmodule->doResponse();
                } else {
                    echo WeChatServer::getXml4Txt('No found module in ' . $cmd['cmdname']);
                }
                exit;
            }
        }
        unset($_SESSION['wx']);
    }

    function _push($cmd, $actionstr) {
        global $wechat;
        switch($cmd['type']) {
            case 'system':
                return $this->{$cmd['cmdname']}($actionstr);
            case 'extension':
                return '';

            case 'plugin':
                return '';
            case 'custom':
                if($cmd['responsetype'] == 1) {
                    return $this->output($cmd['cmdrtn']);
                } else {
                    return '';
                }
        }
    }

    function _custom($type, $keyword = '') {
        global $_G;
        loadcache('wechat_response');
        $response = &$_G['cache']['wechat_response'];
        $query = $type == 'text' ? $response['query']['text'][$keyword] : $response['query']['subscribe'];
        if($query) {
            if(preg_match("/^\[resource=(\d+)\]/", $query, $r)) {
                $resource = C::t('#wechat#mobile_wechat_resource')->fetch($r[1]);
                if(!$resource['type']) {
                    $list = array(array(
                            'title' => $resource['data']['title'],
                            'desc' => $resource['data']['desc'],
                            'pic' => $resource['data']['pic'],
                            'url' => $resource['data']['url'],
                            ));
                } else {
                    $mergeids = array_keys($resource['data']['mergeids']);
                    $sresource = C::t('#wechat#mobile_wechat_resource')->fetch_all($mergeids);
                    $list = array();
                    foreach($resource['data']['mergeids'] as $id => $order) {
                        $list[] = array(
                            'title' => $sresource[$id]['data']['title'],
                            'desc' => $sresource[$id]['data']['desc'],
                            'pic' => $sresource[$id]['data']['pic'],
                            'url' => $sresource[$id]['data']['url'],
                            );
                    }
                }
                echo WeChatServer::getXml4RichMsgByArray($list);
                exit;
            } else {
                echo WeChatServer::getXml4Txt($query);
            }
            exit;
        }
        return 0;
    }

    function _cmdsort(&$cmdlist) {
        $orderarray = $typearray = array();
        $type = array(
            'system' => 1,
            'extension' => 2,
            'custom' => 3);
        foreach($cmdlist as $key => $cmd) {
            $orderarray[$key] = $cmd['displayorder'];
            $typearray[$key] = $type[$cmd['type']];
        }
        array_multisort($typearray, SORT_ASC, $orderarray, SORT_DESC, $cmdlist);
    }

}
