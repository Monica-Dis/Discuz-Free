<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/wechat.lib.class.php';
global $_G;
$_G['strong_wxlogin']['setting'] = unserialize($_G['setting']['strong_wxlogin']);
$_G['strong_wxlogin']['setting']['wechat_appsecret'] = authcode($_G['strong_wxlogin']['setting']['wechat_appsecret'], 'DECODE', $_G['config']['security']['authkey']);
$wechat_client = new WeChatClient($_G['strong_wxlogin']['setting']['wechat_appId'], $_G['strong_wxlogin']['setting']['wechat_appsecret']);
$langs = &$scriptlang['strong_wxlogin'];

if(submitcheck('postmenusubmit')) {    
  
    $postdata = array();
    
    foreach($_POST['button'] as $key=>$val){//����ԭ����
        
        $postdata['button'][$key]['type']='view'; 
        $postdata['button'][$key]['name']=convertname($val['name']); 
        $postdata['button'][$key]['url']=$val['url']; 
        $postdata['button'][$key]['displayorder']=$val['displayorder'];
        if($val['delete']){$postdata['button'][$key]['delete']=$val['delete'];}
        if($val['sub_button']){
            foreach($val['sub_button'] as $k=>$v){
               
                $postdata['button'][$key]['sub_button'][$k]['type']='view';    
                $postdata['button'][$key]['sub_button'][$k]['name']=convertname($v['name']); 
                $postdata['button'][$key]['sub_button'][$k]['url']=$v['url']; 
                $postdata['button'][$key]['sub_button'][$k]['displayorder']=$v['displayorder'];
                if($v['delete']){$postdata['button'][$key]['sub_button'][$k]['delete']=$v['delete'];}    
            }
        }
        
    }

    if($_POST['newsub_button']){
    foreach($_POST['newsub_button'] as $nskey=>$nsval){ //���������Ӳ˵�
        
        foreach($nsval['name'] as $nsk=>$nsv){       
            $postdata['button'][$nskey]['newsub_button'][$nsk]['type'] = 'view';
            $postdata['button'][$nskey]['newsub_button'][$nsk]['name'] = convertname($nsv);
            $postdata['button'][$nskey]['newsub_button'][$nsk]['url'] = $nsval['url'][$nsk];
            $postdata['button'][$nskey]['newsub_button'][$nsk]['displayorder'] = $nsval['displayorder'][$nsk];
        } 
        if(empty($postdata['button'][$nskey]['sub_button'])){$postdata['button'][$nskey]['sub_button'] = array();}
        if(!empty($postdata['button'][$nskey]['newsub_button'])){
            $postdata['button'][$nskey]['sub_button'] = array_merge_recursive($postdata['button'][$nskey]['sub_button'],$postdata['button'][$nskey]['newsub_button']);
        }
        
        unset($postdata['button'][$nskey]['newsub_button']);
    }
    }
   
   
     
     foreach($_POST['newbutton']['name'] as $nk=>$nv){//���������˵�
        $newbutton['button'][$nk]['type'] = 'view';
        $newbutton['button'][$nk]['name'] = convertname($nv);
        $newbutton['button'][$nk]['url'] = $_POST['newbutton']['url'][$nk];
        $newbutton['button'][$nk]['displayorder'] = $_POST['newbutton']['displayorder'][$nk];
        
    }

    if(empty($newbutton)){$newbutton = array();}
    $postdata = array_merge_recursive($newbutton,$postdata);
    usort($postdata['button'], 'buttoncmp');

    
    foreach($postdata['button'] as $ckey=>$cval){
        usort($postdata['button'][$ckey]['sub_button'], 'buttoncmp');
        unset($postdata['button'][$ckey]['displayorder']);
        
        if($cval['sub_button']){
            unset($postdata['button'][$ckey]['type']);  
            unset($postdata['button'][$ckey]['url']);
            
            foreach($cval['sub_button'] as $ck=>$cv){
               unset($postdata['button'][$ckey]['sub_button'][$ck]['displayorder']);  
               if($postdata['button'][$ckey]['sub_button'][$ck]['delete']){unset($postdata['button'][$ckey]['sub_button'][$ck]);} 
            } 
             
        }
        if($postdata['button'][$ckey]['delete']){unset($postdata['button'][$ckey]);}
        
        
    }
    
    foreach($postdata['button'] as $ckey=>$cval){//��������������Ӳ˵�ȫ��ɾ���� ɾ�����ϼ��˵� 
        if(!$cval['sub_button'] and !$cval['url']){
            unset($postdata['button'][$ckey]);             
        }else{
            $postdata['button'][$ckey]['sub_button'] = array_values($postdata['button'][$ckey]['sub_button']);
        }     
               
    }    
       
    
    $postdata['button'] = array_values($postdata['button']);

    if(empty($postdata['button'])){        
        if($wechat_client->deleteMenu()){  
             cpmsg($langs['admincp_menutext1'], "action=plugins&operation=config&do=$pluginid&identifier=$plugin[identifier]&pmod=$module[name]", 'succeed');
     
        }        
    }

    
    
    if(count($postdata['button'])>3){
        cpmsg($langs['admincp_menutext2'], "action=plugins&operation=config&do=$pluginid&identifier=$plugin[identifier]&pmod=$module[name]", 'error');
    
    }
   
    if($wechat_client->setMenu($postdata)){  
         cpmsg($langs['admincp_menutext3'], "action=plugins&operation=config&do=$pluginid&identifier=$plugin[identifier]&pmod=$module[name]", 'succeed');
 
    }else{
         cpmsg($langs['admincp_menutext4'], "action=plugins&operation=config&do=$pluginid&identifier=$plugin[identifier]&pmod=$module[name]", 'error');
   }
    
}else if(submitcheck('pubsubmit')){
    
    if($wechat_client->deleteMenu()){  
         cpmsg($langs['admincp_menutext1'], "action=plugins&operation=config&do=$pluginid&identifier=$plugin[identifier]&pmod=$module[name]", 'succeed');
 
    }else{
        cpmsg($langs['admincp_menutext5'], "action=plugins&operation=config&do=$pluginid&identifier=$plugin[identifier]&pmod=$module[name]", 'error');
    }
    
    
    
}else{
    
    showformheader("plugins&operation=config&do=$plugin[pluginid]&identifier=$plugin[identifier]&pmod=$module[name]");
    showtableheader($langs['admincp_selfmenu_menusetting']);
    echo '<tr class="header"><th class="td25"></th><th>'.$langs['admincp_menutext6'].'</th><th style="width:350px">'.$langs['admincp_menutext7'].'</th><th>'.$langs['admincp_menutext8'].'</th></tr>';
    
    
        $menudata = $wechat_client->getMenu(); 
        

        
       
        foreach(siconv($menudata['menu']['button']) as $k => $button) {
            $button[displayorder] = $k;
        $disabled = !empty($button['sub_button']) ? 'disabled' : '';
        showtablerow('', array('', 'class="td23 td28"', '', 'class=""'), array(
            "<input class=\"checkbox\" type=\"checkbox\" name=\"button[$k][delete]\" value=\"yes\" $disabled>",
            "<input type=\"text\" class=\"txt\" size=\"3\" name=\"button[$k][displayorder]\" value=\"$button[displayorder]\">",
            "<div class=\"parentnode\"><input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][name]\" value=\"".dhtmlspecialchars($button['name'])."\"></div>",
            "<input type=\"text\" class=\"\" size=\"80\" name=\"button[$k][url]\" value=\"".dhtmlspecialchars($button['url'])."\">",
        ));
        
        if(!empty($button['sub_button'])) {
          
            foreach($button['sub_button'] as $sk => $sub_button) {
                $sub_button[displayorder] = $sk;
                showtablerow('', array('', 'class="td23 td28"', '', 'class=""'), array(
                    "<input class=\"checkbox\" type=\"checkbox\" name=\"button[$k][sub_button][$sk][delete]\" value=\"yes\">",
                    "<input type=\"text\" class=\"txt\" size=\"3\" name=\"button[$k][sub_button][$sk][displayorder]\" value=\"$sub_button[displayorder]\">",
                    "<div class=\"node\"><input type=\"text\" class=\"txt\" size=\"30\" name=\"button[$k][sub_button][$sk][name]\" value=\"".dhtmlspecialchars($sub_button['name'])."\"></div>",
                    "<input type=\"text\" class=\"\" size=\"80\" name=\"button[$k][sub_button][$sk][url]\" value=\"".dhtmlspecialchars($sub_button['url'])."\">",
                ));
            }
        }
        echo '<tr><td></td><td></td><td colspan="2"><div class="lastnode"><a href="###" onclick="addrow(this, 1, '.$k.')" class="addtr">'.$langs['admincp_menutext9'].'</a></div></td></tr>';
    }
    echo '<tr><td></td><td class="td23 td28"></td><td colspan="2"><div><a href="###" onclick="addrow(this, 0, 0)" class="addtr">'.$langs['admincp_menutext10'].'</a></div></td></tr>';
    echo <<<EOT
<script type="text/JavaScript">
var rowtypedata = [
[[1,''], [1,'<input name="newbutton[displayorder][]" value="0" size="3" type="text" class="txt">', 'td23 td28'], [1, '<input name="newbutton[name][]" value="" size="30" type="text" class="txt">'], [1, '<input name="newbutton[url][]" value="" size="30" type="text" class="txt">', 'td29']],
[[1,''], [1,'<input name="newsub_button[{1}][displayorder][]" value="0" size="3" type="text" class="txt">', 'td23 td28'], [1, '<div class=\"node\"><input name="newsub_button[{1}][name][]" value="" size="30" type="text" class="txt"></div>'], [1, '<input name="newsub_button[{1}][url][]" value="" size="30" type="text" class="txt">', 'td29']],
];
</script>    
EOT;
    showsubmit('postmenusubmit', $langs['admincp_menutext11'], 'del','&nbsp;&nbsp;&nbsp;&nbsp;<input type="submit" class="btn" name="pubsubmit" value="'.$langs['admincp_menutext12'].'" />');
    showtablefooter();/*Dism��taobao��com*/
    showformfooter();    
    
    
}


















function buttoncmp($a, $b) {
	return $a['displayorder'] > $b['displayorder'] ? 1 : -1;
}

function convertname($str) {    
	return urlencode(diconv($str, CHARSET, 'UTF-8'));
}

function siconv($str, $in_charset = 'utf-8', $out_charset = CHARSET) {
    if (strtolower($in_charset) != strtolower($out_charset)) {
        return eval('return ' . diconv(var_export($str, true) . ';', $in_charset, $out_charset));
    }
    return $str;
}
//From: Dism_taobao-com
?>