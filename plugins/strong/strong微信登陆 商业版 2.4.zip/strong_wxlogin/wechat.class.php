<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


class WeChat {

    static $QRCODE_EXPIRE = 1800;


    static public function getqrcode() {
        global $_G;
        $code = 0;
        $i = 0;
        do {
            $code = rand(100000, 999999);
            $codeexists = C::t('#strong_wxlogin#strong_wxlogin_authcode')->fetch_by_code($code);
            $i++;
        } while($codeexists && $i < 10);

        if($codeexists) {
            showmessage('strong_wxlogin:qrcode_create_error');
        }

        $codeenc = urlencode(base64_encode(authcode($code, 'ENCODE', $_G['config']['security']['authkey'])));
        C::t('#strong_wxlogin#strong_wxlogin_authcode')->insert(array(
            'sid' => $_G['cookie']['saltkey'],
            'uid' => $_G['uid'],
            'code' => $code,
            'createtime' => TIMESTAMP), 0, 1);

        if(!discuz_process::islocked('clear_strong_wxlogin_authcode')) {
            C::t('#strong_wxlogin#strong_wxlogin_authcode')->delete_history();
            discuz_process::unlock('clear_strong_wxlogin_authcode');
        }
        return array($codeenc, $code);


        global $_G;


    }

    static public function redirect($type) {
        global $_G;
        $hook = unserialize($_G['setting']['wechatredirect']);
        if(!$hook || !in_array($hook['plugin'], $_G['setting']['plugins']['available'])) {
            return;
        }
        if(!preg_match("/^[\w\_]+$/i", $hook['plugin']) || !preg_match('/^[\w\_\.]+\.php$/i', $hook['include'])) {
            return;
        }
        include_once DISCUZ_ROOT . 'source/plugin/' . $hook['plugin'] . '/' . $hook['include'];
        if(!class_exists($hook['class'], false)) {
            return;
        }
        $class = new $hook['class'];
        if(!method_exists($class, $hook['method'])) {
            return;
        }
        $return = $class->$hook['method']($type);
        if($return) {
            return $return;
        }
    }

    static public function register($username, $return = 0, $groupid = 0) {
        global $_G;
        if(!$username) {
            return;
        }
        if(!$_G['wechat']['setting']) {
            $_G['wechat']['setting'] = unserialize($_G['setting']['mobilewechat']);
        }

        loaducenter();
        $groupid = !$groupid ? ($_G['cache']['plugin']['strong_wxlogin']['newusergroupid'] ? $_G['cache']['plugin']['strong_wxlogin']['newusergroupid'] : $_G['setting']['newusergroupid']) : $groupid;

        $password = md5(random(10));
        $email = 'wechat_' . strtolower(random(10)) . '@null.null';

        $usernamelen = dstrlen($username);
        if($usernamelen < 3) {
            $username = $username . '_' . random(5);
        }
        if($usernamelen > 15) {
            if(!$return) {
                showmessage('profile_username_toolong');
            } else {
                return;
            }
        }

        $censorexp = '/^(' . str_replace(array(
            '\\*',
            "\r\n",
            ' '), array(
            '.*',
            '|',
            ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';

        if($_G['setting']['censoruser'] && @preg_match($censorexp, $username)) {
            if(!$return) {
                showmessage('profile_username_protect');
            } else {
                return;
            }
        }

        if(!$_G['wechat']['setting']['wechat_disableregrule']) {
            loadcache('ipctrl');
            if($_G['cache']['ipctrl']['ipregctrl']) {
                foreach(explode("\n", $_G['cache']['ipctrl']['ipregctrl']) as $ctrlip) {
                    if(preg_match("/^(" . preg_quote(($ctrlip = trim($ctrlip)), '/') . ")/", $_G['clientip'])) {
                        $ctrlip = $ctrlip . '%';
                        $_G['setting']['regctrl'] = $_G['setting']['ipregctrltime'];
                        break;
                    } else {
                        $ctrlip = $_G['clientip'];
                    }
                }
            } else {
                $ctrlip = $_G['clientip'];
            }

            if($_G['setting']['regctrl']) {
                if(C::t('common_regip')->count_by_ip_dateline($ctrlip, $_G['timestamp'] - $_G['setting']['regctrl'] * 3600)) {
                    if(!$return) {
                        showmessage('register_ctrl', null, array('regctrl' => $_G['setting']['regctrl']));
                    } else {
                        return;
                    }
                }
            }

            $setregip = null;
            if($_G['setting']['regfloodctrl']) {
                $regip = C::t('common_regip')->fetch_by_ip_dateline($_G['clientip'], $_G['timestamp'] - 86400);
                if($regip) {
                    if($regip['count'] >= $_G['setting']['regfloodctrl']) {
                        if(!$return) {
                            showmessage('register_flood_ctrl', null, array('regfloodctrl' => $_G['setting']['regfloodctrl']));
                        } else {
                            return;
                        }
                    } else {
                        $setregip = 1;
                    }
                } else {
                    $setregip = 2;
                }
            }

            if($setregip !== null) {
                if($setregip == 1) {
                    C::t('common_regip')->update_count_by_ip($_G['clientip']);
                } else {
                    C::t('common_regip')->insert(array(
                        'ip' => $_G['clientip'],
                        'count' => 1,
                        'dateline' => $_G['timestamp']));
                }
            }
        }

        $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
        if($uid <= 0) {
            if(!$return) {
                if($uid == -1) {
                    showmessage('profile_username_illegal');
                } elseif($uid == -2) {
                    showmessage('profile_username_protect');
                } elseif($uid == -3) {
                    showmessage('profile_username_duplicate');
                } elseif($uid == -4) {
                    showmessage('profile_email_illegal');
                } elseif($uid == -5) {
                    showmessage('profile_email_domain_illegal');
                } elseif($uid == -6) {
                    showmessage('profile_email_duplicate');
                } else {
                    showmessage('undefined_action');
                }
            } else {
                return;
            }
        }

        $init_arr = array('credits' => explode(',', $_G['setting']['initcredits']));
        C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

        if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
            C::t('common_regip')->delete_by_dateline($_G['timestamp'] - ($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72) * 3600);
            if($_G['setting']['regctrl']) {
                C::t('common_regip')->insert(array(
                    'ip' => $_G['clientip'],
                    'count' => -1,
                    'dateline' => $_G['timestamp']));
            }
        }

        if($_G['setting']['regverify'] == 2) {
            C::t('common_member_validate')->insert(array(
                'uid' => $uid,
                'submitdate' => $_G['timestamp'],
                'moddate' => 0,
                'admin' => '',
                'submittimes' => 1,
                'status' => 0,
                'message' => '',
                'remark' => '',
                ), false, true);
            manage_addnotify('verifyuser');
        }

        setloginstatus(array(
            'uid' => $uid,
            'username' => $username,
            'password' => $password,
            'groupid' => $groupid,
            ), 0);

        if($_G['cache']['plugin']['strong_wxlogin']['addcreditclass']) {
            $addcreditnum = $_G['cache']['plugin']['strong_wxlogin']['addcreditnum'] ? $_G['cache']['plugin']['strong_wxlogin']['addcreditnum'] : 0;
            updatemembercount($uid, array('extcredits' . $_G['cache']['plugin']['strong_wxlogin']['addcreditclass'] => $addcreditnum), true, '', 0, '', lang('plugin/strong_wxlogin', 'wechatregistertext1'), lang('plugin/strong_wxlogin', 'wechatregistertext1'));
        }
        include_once libfile('function/stat');
        updatestat('register');

        return $uid;
    }


    static public function syncAvatar($uid, $avatar) {

        $ucavatardir = substr($_SERVER['SCRIPT_FILENAME'], 0, strrpos($_SERVER['SCRIPT_FILENAME'], '/') + 1) . 'uc_server/data';
        if(strpos($ucavatardir, "source/plugin/strong_wxlogin/")) {
            $ucavatardir = str_replace('source/plugin/strong_wxlogin/', '', $ucavatardir);
        }

        $ucavatardir = DISCUZ_ROOT . 'uc_server/data/avatar/';
        $home = uploadUcAvatar::get_home($uid);
        if(!is_dir($ucavatardir . '/avatar/' . $home)) {
            uploadUcAvatar::set_home($uid, $ucavatardir);
        }
        
        
        $avatartype = 'virtual';
        $bigavatarfile = $ucavatardir . uploadUcAvatar::get_avatar($uid, 'big', $avatartype);
        $middleavatarfile = $ucavatardir . uploadUcAvatar::get_avatar($uid, 'middle', $avatartype);
        $smallavatarfile = $ucavatardir . uploadUcAvatar::get_avatar($uid, 'small', $avatartype);

        uploadUcAvatar::swxgetImage($avatar, $bigavatarfile, '1');
        uploadUcAvatar::swxgetImage($avatar, $middleavatarfile, '1');
        uploadUcAvatar::swxgetImage($avatar, $smallavatarfile, '1');
        C::t('common_member')->update($uid, array('avatarstatus' => '1'));
        return true;


    }

    static public function getnewname($username) {
        global $_G;
        $newname = cutstr(WeChatEmoji::clear($username), 15, '');

        if($newname) {
            $censorexp = '/^(' . str_replace(array(
                '\\*',
                "\r\n",
                ' '), array(
                '.*',
                '|',
                ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')) . ')$/i';
            $newname = preg_replace($censorexp, '', $newname);

            $guestexp = '\xA1\xA1|\xAC\xA3|^Guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8';
            $newname = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&]|$guestexp/is", '', $newname);
        }

        if(dstrlen($newname) >= 3) {
            loaducenter();
            if(uc_get_user($newname)) {
                $newname = cutstr($newname, 6, '');
                $newname = 'wx_' . $newname . '_' . random(5);
            }
        } else
            if($newname) {
                $newname = 'wx_' . $newname . '_' . random(5);
            } else {
                $newname = 'wx_' . random(5);
            }

            return $newname;
    }


}

class uploadUcAvatar {
    public static function swxgetImage($url, $filename = '', $type = 0) {
        if(trim($url) == '') {
            return '';
        }
        if(strpos($url, '//') == 0) {
            $url = 'http:' . $url;
        }

        if($type) {
            $ch = curl_init();
            $timeout = 5;
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
            $img = curl_exec($ch);
            curl_close($ch);
        } else {
            ob_start();
            readfile($url);
            $img = ob_get_contents();
            ob_end_clean();
        }

        file_put_contents($filename, $img);


        unset($img, $url);

    }
    public static function set_home($uid, $dir = '.') {
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        !is_dir($dir . '/' . $dir1) && mkdir($dir . '/' . $dir1, 0777);
        !is_dir($dir . '/' . $dir1 . '/' . $dir2) && mkdir($dir . '/' . $dir1 . '/' . $dir2, 0777);
        !is_dir($dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3) && mkdir($dir . '/' . $dir1 . '/' . $dir2 . '/' . $dir3, 0777);
    }


    public static function get_home($uid) {
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        return $dir1 . '/' . $dir2 . '/' . $dir3;
    }

    public static function get_avatar($uid, $size = 'big', $type = '') {
        $size = in_array($size, array(
            'big',
            'middle',
            'small')) ? $size : 'big';
        $uid = abs(intval($uid));
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        $typeadd = $type == 'real' ? '_real' : '';
        return $dir1 . '/' . $dir2 . '/' . $dir3 . '/' . substr($uid, -2) . $typeadd . "_avatar_$size.jpg";
    }

    public static function upload($uid, $localFile) {

        global $_G;
        if(!$uid || !$localFile) {
            return false;
        }

        list($width, $height, $type, $attr) = getimagesize($localFile);
        if(!$width) {
            return false;
        }

        if($width < 10 || $height < 10 || $type == 4) {
            return false;
        }

        $imageType = array(
            1 => '.gif',
            2 => '.jpg',
            3 => '.png');
        $fileType = $imgType[$type];
        if(!$fileType) {
            $fileType = '.jpg';
        }
        $avatarPath = $_G['setting']['attachdir'];
        $tmpAvatar = $avatarPath . './temp/upload' . $uid . $fileType;
        file_exists($tmpAvatar) && @unlink($tmpAvatar);
        file_put_contents($tmpAvatar, file_get_contents($localFile));

        if(!is_file($tmpAvatar)) {
            return false;
        }

        $tmpAvatarBig = './temp/upload' . $uid . 'big' . $fileType;
        $tmpAvatarMiddle = './temp/upload' . $uid . 'middle' . $fileType;
        $tmpAvatarSmall = './temp/upload' . $uid . 'small' . $fileType;

        $image = new image;
        if($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
            return false;
        }
        if($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
            return false;
        }
        if($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
            return false;
        }


        $tmpAvatarBig = $avatarPath . $tmpAvatarBig;
        $tmpAvatarMiddle = $avatarPath . $tmpAvatarMiddle;
        $tmpAvatarSmall = $avatarPath . $tmpAvatarSmall;

        $avatar1 = self::byte2hex(file_get_contents($tmpAvatarBig));
        $avatar2 = self::byte2hex(file_get_contents($tmpAvatarMiddle));
        $avatar3 = self::byte2hex(file_get_contents($tmpAvatarSmall));

        $extra = '&avatar1=' . $avatar1 . '&avatar2=' . $avatar2 . '&avatar3=' . $avatar3;
        $result = self::uc_api_post_ex('user', 'rectavatar', array('uid' => $uid), $extra);


        @unlink($tmpAvatar);
        @unlink($tmpAvatarBig);
        @unlink($tmpAvatarMiddle);
        @unlink($tmpAvatarSmall);

        return true;
    }


    public static function byte2hex($string) {
        $buffer = '';
        $value = unpack('H*', $string);
        $value = str_split($value[1], 2);
        $b = '';
        foreach($value as $k => $v) {
            $b .= strtoupper($v);
        }

        return $b;
    }

    public static function uc_api_post_ex($module, $action, $arg = array(), $extra = '') {
        $s = $sep = '';
        foreach($arg as $k => $v) {
            $k = urlencode($k);
            if(is_array($v)) {
                $s2 = $sep2 = '';
                foreach($v as $k2 => $v2) {
                    $k2 = urlencode($k2);
                    $s2 .= "$sep2{$k}[$k2]=" . urlencode(uc_stripslashes($v2));
                    $sep2 = '&';
                }
                $s .= $sep . $s2;
            } else {
                $s .= "$sep$k=" . urlencode(uc_stripslashes($v));
            }
            $sep = '&';
        }
        $postdata = uc_api_requestdata($module, $action, $s, $extra);
        return uc_fopen2(UC_API . '/index.php', 500000, $postdata, '', true, UC_IP, 20);
    }
}


class plugin_strong_wxlogin_base {

    function plugin_strong_wxlogin_base() {
        global $_G, $wechat_client;
        include_once template('strong_wxlogin:module');
    }

    function common_base() {
        global $_G, $swxloginset, $wechat_client;
        $swxloginset = $_G['cache']['plugin']['strong_wxlogin'];

        define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);


        if(!isset($_G['strong_wxlogin'])) {
            $redirect_uri = $_G['siteurl'] . "plugin.php?id=strong_wxlogin:login&dreferers=" . urlencode(dreferer());
            $_G['strong_wxlogin']['setting'] = unserialize($_G['setting']['strong_wxlogin']);
            $_G['strong_wxlogin']['setting']['wechat_appsecret'] = authcode($_G['strong_wxlogin']['setting']['wechat_appsecret'], 'DECODE', $_G['config']['security']['authkey']);
            $_G['strong_wxlogin']['setting']['wechat_mchkey'] = authcode($_G['strong_wxlogin']['setting']['wechat_mchkey'], 'DECODE', $_G['config']['security']['authkey']);
            include_once DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/wechat.lib.class.php';
            $wechat_client = new WeChatClient($_G['strong_wxlogin']['setting']['wechat_appId'], $_G['strong_wxlogin']['setting']['wechat_appsecret']);

            $_G['strong_wxlogin']['abs_attachurl'] = strpos($_G['setting']['attachurl'], 'http://') === false ? $_G['siteurl'] . $_G['setting']['attachurl'] : $_G['setting']['attachurl'];
            $_G['strong_wxlogin']['referer'] = !$_G['inajax'] && CURSCRIPT != 'member' ? $_G['basefilename'] . ($_SERVER['QUERY_STRING'] ? '?' . $_SERVER['QUERY_STRING'] : '') : dreferer();

            $_G['strong_wxlogin']['login_url'] = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" . $_G['strong_wxlogin']['setting']['wechat_appId'] . "&redirect_uri=" . urlencode($redirect_uri) . "&response_type=
code&scope=" . ($swxloginset['mobileloginwg'] ? 'snsapi_base' : 'snsapi_userinfo') . "&state=STATE#wechat_redirect ";
            $_G['strong_wxlogin']['login_url2'] = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=" . $_G['strong_wxlogin']['setting']['wechat_appId'] . "&redirect_uri=" . urlencode($redirect_uri) . "&response_type=
code&scope=snsapi_base&state=STATE#wechat_redirect ";

            $_G['strong_wxlogin']['setting']['wechat_shareicon'] = $_G['strong_wxlogin']['setting']['wechat_shareicon'] ? $_G['strong_wxlogin']['abs_attachurl'] . $_G['strong_wxlogin']['setting']['wechat_shareicon'] : $_G['siteurl'] . 'source/plugin/strong_wxlogin/static/img/share-logo.png';


        }


        // Openid may be invalid or does not match with APPID
        if($_G['uid']) {
            if($bindmember = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_uid($_G['uid'])) {
                $_G['member']['openid'] = $bindmember['openid'];
                $_G['member']['unionid'] = $bindmember['unionid'];
                $_G['member']['subscribe'] = $bindmember['subscribe'] == 1 ? 1 : 0;

                CURSCRIPT == 'home' && $_G['member']['isregister'] = $bindmember['isregister'];
                unset($bindmember);
            }
        }

        include_once libfile('function/common', 'plugin/strong_wxlogin');
    }


}


class plugin_strong_wxlogin extends plugin_strong_wxlogin_base {

    function common() {
        $this->common_base();
        if($_GET['showtokeninfo'] == 'yes') {
            require_once DISCUZ_ROOT . '/source/plugin/strong_wxlogin/function/function_common.php';
        }
    }

    function global_login_extra() {
        global $_G, $swxloginset;
        if(!$swxloginset['pctopbutton']) {
            return '';
        }
        return swxlogin_tpl_login_extra_bar();
    }

    function global_usernav_extra1() {
        global $_G, $swxloginset;
        if(!$_G['uid'] or !$swxloginset['pctopbutton']) {
            return '';
        }
        $bindmember = C::t('#strong_wxlogin#strong_wxlogin_bind')->fetch_by_uid($_G['uid']);
        if($bindmember) {
            return '';
        }

        return swxlogin_wechat_tpl_user_bar();
    }

}

class plugin_strong_wxlogin_member extends plugin_strong_wxlogin {
    function logging_method() {
        global $_G, $swxloginset;
        if(!$swxloginset['pcloginbutton']) {
            return '';
        }
        return swxlogin_tpl_login_extra_bar(1);
    }

    function register_logging_method() {
        global $_G, $swxloginset;
        if(!$swxloginset['pcregisterbutton']) {
            return '';
        }
        return swxlogin_tpl_login_extra_bar(1);

    }

}


class mobileplugin_strong_wxlogin extends plugin_strong_wxlogin_base {

    function common() {
        $this->common_base();
        global $_G, $swxloginset, $wechat_client;


    }

    function global_header_mobile() {
        global $_G, $swxloginset, $wechat_client, $signPackage, $wxdata, $postarr,$navtitle;

        
        if(!$_G['uid'] and $swxloginset['mobilelogin'] and IN_WECHAT and !$_G['cookie']['swx_mobilelogout'] and $_G['basescript'] == 'forum') {

            dheader('location: ' . $_G['strong_wxlogin']['login_url']);

        }


        if(IN_WECHAT and $swxloginset['wxshare']) {
            $signPackage = $wechat_client->getSignPackage();


            if($_G['basescript'] == 'forum' && CURMODULE == 'viewthread') {

                foreach($postarr as $post) {
                    if($post['first']) {
                        $metadescription = str_replace(array("\r", "\n"), '', messagecutstr(strip_tags($post['message']), 160));
                    }
                }

                $attachtableid = getattachtablebytid(intval($_G['tid']));
                $attach = DB::fetch_first("SELECT * FROM " . DB::table($attachtableid) . " WHERE tid = $_G[tid] and (isimage=1 or isimage='-1')");


                $imgurl = $attach[attachment] ? $_G['siteurl'] . getforumimg($attach['aid'], 0, 180, 180) : $_G['strong_wxlogin']['setting']['wechat_shareicon'];

              
                $wxdata = array(
                    'title' => $_G['forum_thread']['subject'],
                    'link' => $_G['siteurl'] . 'forum.php?mod=viewthread&tid=' . $_G['tid'],
                    'imgUrl' => $imgurl,
                    'desc' => dhtmlspecialchars($metadescription)); 
                    
                return swx_tpl_jssdk_share();
            } else if($_G['basescript'] == 'portal' && CURMODULE == 'view') {
                    $wxdata = array(
                        'title' => $article['title'],
                        'link' => $_G['siteurl'] . 'portal.php?mod=view&aid=' . $article['aid'],
                        'imgUrl' => $article['pic'] ? $_G['siteurl'] . $article['pic'] : $_G['strong_wxlogin']['setting']['wechat_shareicon'],
                        'desc' => dhtmlspecialchars(preg_replace("/\s/", '', $article['summary'])));
                    return swx_tpl_jssdk_share();
            }else{
                $wxdata = array(
                        'title' => $swxloginset['wxsharetitle'] ? trim($swxloginset['wxsharetitle']) : $_G['setting']['bbname'],
                        'link' => $_G['siteurl'],
                        'imgUrl' => $_G['strong_wxlogin']['setting']['wechat_shareicon'],
                        'desc' => dhtmlspecialchars(preg_replace("/\s/", '', $swxloginset['wxsharedes'])));
                    return swx_tpl_jssdk_share();
            }
        }
    }


    function global_footer_mobile() {
        global $_G, $swxloginset;
        if(!$swxloginset['mobilebindset'] or !IN_WECHAT) {
            return '';
        }

        return swx_tpl_mobile_profilemenu();

    }

}


class mobileplugin_strong_wxlogin_member extends mobileplugin_strong_wxlogin {
    function logging_bottom_mobile() {
        global $_G, $swxloginset;
        loadcache('plugin');
        if(!$swxloginset['mobileloginbutton']) {
            return '';
        }

        if(!IN_WECHAT and $swxloginset['jxwxshowlogin']) {
            return '';
        }

        $_G['setting']['strong_wxlogin']['redirect_uri'] = $_G['siteurl'] . "plugin.php?id=strong_wxlogin:login";


        return tpl_login_bottom_wechat();

    }


    function logging_message($params) {
        global $_G, $swxloginset;

        if($params['param'][0] == 'location_logout_succeed_mobile' and $swxloginset['mobilelogin'] and IN_WECHAT) {
            
            dsetcookie('swx_mobilelogout', '1', 300);            
        }

    }
}
