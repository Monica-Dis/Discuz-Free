<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

loadcache('plugin');
$strongwxsetting = unserialize($_G['setting']['strong_wxlogin']);




if($_G['uid'] && submitcheck('confirmsubmit')) {
    loaducenter();
    list($result) = uc_user_login($_G['uid'], $_GET['passwordconfirm'], 1, 0);
    if($result >= 0) {
        dsetcookie('qrauth', base64_encode(authcode($result, 'ENCODE', $_G['config']['security']['authkey'], 300)));  
        if(defined('IN_MOBILE')) {
            dheader('Location:'.$_G['strong_wxlogin']['login_url']);
        }else{
            showmessage('', dreferer());
        }
        
    }
    showmessage('login_password_invalid');
}

if(isset($_GET['check'])) {
    $code = authcode(base64_decode($_GET['check']), 'DECODE', $_G['config']['security']['authkey']);
    if($code) {
        $authcode = C::t('#strong_wxlogin#strong_wxlogin_authcode')->fetch_by_code($code);
        if($authcode['status']) {
            require_once libfile('function/member');
            $member = getuserbyuid($authcode['uid'], 1);
            setloginstatus($member, 1296000);
            $echostr = 'done';
        } else {
            $echostr = '1';//json_encode($authcode);
        }
    } else {
        $echostr = '-1';
    }

    if(!ob_start($_G['gzipcompress'] ? 'ob_gzhandler' : null)) {
        ob_start();
    }

    if($echostr === 'done'){
        C::t('#strong_wxlogin#strong_wxlogin_authcode')->delete($authcode['sid']);
    }
   
    include template('common/header_ajax');
    echo $echostr;
    include template('common/footer_ajax');
    exit;
}

if($_G['cookie']['qrauth']) {
	$qrauth = authcode(base64_decode($_G['cookie']['qrauth']), 'DECODE', $_G['config']['security']['authkey']);
	
}

list($codeenc, $code) = WeChat::getqrcode();
include_once DISCUZ_ROOT . './source/plugin/strong_wxlogin/class/wechat.lib.class.php';

$wechat_client = new WeChatClient($_G['strong_wxlogin']['setting']['wechat_appId'], $_G['strong_wxlogin']['setting']['wechat_appsecret']);
$ticket = $wechat_client->getQrcodeTicket(array('scene_id' => $code, 'expire' => 600, 'ticketOnly' => 1));



$qrcodeurl = $ticket ? 'https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket='.urlencode($ticket) : $_G['setting']['attachurl'].$_G['strong_wxlogin']['setting']['wechat_qrcode'];


if($_G['cache']['plugin']['strong_wxlogin']['debug']){
    var_dump($wechat_client->error());
}
include_once template('strong_wxlogin:qrcode');
