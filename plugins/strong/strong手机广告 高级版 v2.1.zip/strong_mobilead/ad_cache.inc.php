<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!strstr($_G[PHP_SELF], 'admin')) {
    exit();
}

if($_GET['mmm']=='update'){
	require_once DISCUZ_ROOT . 'source/plugin/strong_mobilead/include/ad_func.php';  
    update_avd_cache();
    
    cpmsg(lang('plugin/strong_mobilead','adv_update_succeed'),'action=plugins&identifier=strong_mobilead&pmod=ad_cache','succeed','','');  
}else{
    cpmsg(lang('plugin/strong_mobilead','adv_update_affirm'),'action=plugins&identifier=strong_mobilead&pmod=ad_cache&mmm=update','form','',lang('plugin/strong_mobilead','adv_update_affirm_extra'));
}





?>