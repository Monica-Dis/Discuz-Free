<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!strstr($_G[PHP_SELF], 'admin')) {
    exit();
}

global $_G;
require_once DISCUZ_ROOT . 'source/plugin/strong_mobilead/include/ad_func.php';

if ($_GET['mmm'] == 'edit' or $_GET['mmm'] == 'add') {

    if(!submitcheck('settingsubmit')) {    
    echocalendarjs(); 
    $ifshowdefault = 1;
       
    if($_GET['mmm'] == 'edit'){        
        $advid = $_GET['advid']=='' ? 0 : $_GET['advid'];      
        $addata = DB::fetch_first("SELECT * FROM " . DB::table('strong_advertisement')." WHERE advid = $advid");
        if(empty($addata)){cpmsg(lang('plugin/strong_mobilead', 'notdata'),'','error');}        
        $addata[parameters] = unserialize($addata['parameters']);
        $addata['starttime'] = $addata['starttime'] ? dgmdate($addata['starttime'], 'Y-n-j') : '';
		$addata['endtime'] = $addata['endtime'] ? dgmdate($addata['endtime'], 'Y-n-j') : '';       
        $type = $addata['type'];    
        
       
    }else {
        $type = $_GET['type'];
		$addata['parameters']['style'] = 'code';
        $addata['parameters']['align'] = 'center';
        $addata['parameters']['extra']['position'] = ($type == 'globalfloat' ? 'popup' : '');
        $addata['parameters']['againshowtime'] = '36000';
        $addata['parameters']['extra']['portalposition']=0;
        ($type=='globalfloat') ? '' : $addata['parameters']['css'] = 'margin:10px 0 10px 0;';
        ($type=='globalfloat') ? $addata['parameters']['style'] = 'image' : '';
        
     }
    ($type=='globalfloat') ? $ifshowdefault=0 : '';

    
    $getadvtypes = gettarget($type);
    foreach($getadvtypes[targetarr] as $target){        
        $targets[] = array($target,lang('plugin/strong_mobilead','targets_'.$target));
    }
    $getselect = getselect($getadvtypes['selecttypes']);


 
 
    showformheader('plugins&operation=config&identifier=strong_mobilead&pmod=ad_list&mmm='.$_GET['mmm'],'enctype');
    showtableheader();
    showhiddenfields(array('settingnew[advid]'=>$_GET[advid],'settingnew[type]'=>$type));
    showtitle(($_GET['mmm'] == 'edit' ? lang('plugin/strong_mobilead','editadv') : lang('plugin/strong_mobilead','addadv')).' - '.lang('plugin/strong_mobilead',$type));
    shownav('extended', 'adv_admin');
    showsetting(lang('plugin/strong_mobilead','advtitle'), 'settingnew[title]', $addata['title'], 'text', '', '',
        lang('plugin/strong_mobilead','advtitle_comment'), '', '', true);    
    showsetting(lang('plugin/strong_mobilead','adv_edit_targets'), array('settingnew[targets]', $targets), explode(',',$addata['targets']),
        'mcheckbox');    
    
    if(strstr($type,'portalindex')){    
    for($p=0;$p<=9;$p++){
        $portalad[] = array($p,lang('plugin/strong_mobilead','portalindex_'.$p)); 
    }
    
    showsetting(lang('plugin/strong_mobilead','portalposition'), array('parameters[extra][portalposition]', $portalad), $addata['parameters']['extra']['portalposition'],
        'mradio','','',lang('plugin/strong_mobilead','portalposition_comment'));     
    }      
    showsetting(lang('plugin/strong_mobilead','adv_onweixin'), 'parameters[extra][onweixin]', $addata[parameters][extra][onweixin],
        'radio','','',lang('plugin/strong_mobilead','adv_onweixin_comment'));    
    if($getselect[forums]){
    showsetting(lang('plugin/strong_mobilead','throw_forums'), array('parameters[extra][fids][]', $getselect[forums]),$addata[parameters][extra][fids],
        'mselect', '', 0, lang('plugin/strong_mobilead','forums_select_comment'), '', '', true);
    }
    if($getselect[grouptype]){
    showsetting(lang('plugin/strong_mobilead','throw_grouptype'), array('parameters[extra][groups][]', $getselect[grouptype]), $addata[parameters][extra][groups],
        'mselect', '', 0, lang('plugin/strong_mobilead','grouptype_select_comment'), '', '', true);
    }
    

    
    if($getselect[portalcategory]){
    showsetting(lang('plugin/strong_mobilead','throw_portalcategory'), array('parameters[extra][category][]', $getselect[portalcategory]),$addata[parameters][extra][category],
         'mselect', '', 0, lang('plugin/strong_mobilead','portalcategory_select_comment'), '', '', true);
    }
    

    
    if($type=="forumdisplaythread" or $type == 'viewthreadfloortop' or $type == 'viewthreadfloorbottom'){
        $ifshowdefault = 0;
        $fixationshowarr[]=array(0,'');
        $randomshowarr[]=array(0,'');
        for($n=1;$n<=100;$n++){
            $fixationshowarr[]=array($n,$n);
        }
        for($n=1;$n<=10;$n++){
            $randomshowarr[]=array($n,$n);
        }
        for($r=1;$r<=10;$r++){
            $randomshowodds[]=array($r,ceil(100/$r).'%');
        }
    showsetting(lang('plugin/strong_mobilead','adv_fixationshow'), array('parameters[extra][fixationshow][]',$fixationshowarr), $addata[parameters][extra][fixationshow], 'mselect','','',lang('plugin/strong_mobilead','adv_fixationshow_comment'));
    showsetting(lang('plugin/strong_mobilead','adv_randomshownum'), array('parameters[extra][randomshownum]',$randomshowarr), $addata[parameters][extra][randomshownum], 'select','','',lang('plugin/strong_mobilead','adv_randomshownum_comment'));
    showsetting(lang('plugin/strong_mobilead','adv_randomshowodds'), array('parameters[extra][randomshowodds]',$randomshowodds), $addata[parameters][extra][randomshowodds], 'select','','',lang('plugin/strong_mobilead','adv_randomshowodds_comment'));
    }
    
    showsetting('adv_edit_starttime', 'settingnew[starttime]', $addata[starttime], 'calendar');
    showsetting('adv_edit_endtime', 'settingnew[endtime]', $addata[endtime], 'calendar');
    
  
    
    if($ifshowdefault){
    showsetting(lang('plugin/strong_mobilead','adv_defaultcode'), 'settingnew[defaultcode]', $addata[defaultcode], 'radio','','',lang('plugin/strong_mobilead','adv_defaultcode_comment'));
    }
    $adtypearray = array();
       
  
    $adtypes = array('text','image');   
    $addata['parameters']['style']=='code' ? $adtypes['code'] : ''; 
    if($addata['parameters']['extra']['position']!="popup"){$adtypes[]='code'; }   
    
   
         
    foreach ($adtypes as $adtype) {
        $displayary = array();
        foreach ($adtypes as $adtype1) {
            $displayary['style_' . $adtype1] = $adtype1 == $adtype ? '' : 'none';
        }
        $adtypearray[] = array(
            $adtype,
            $lang['adv_style_' . $adtype],
            $displayary);
    }

    $adimagealignarr = array();
    $adimagealigns = array(
        'left',
        'center',
        'right');
    foreach ($adimagealigns as $adimagealign) {
        $adimagealignarr[] = array(
            $adimagealign,
            lang('plugin/strong_mobilead','align_'.$adimagealign),
            '');
    }  
  
    if($type=='globalfloat'){
    $adpositionarr = array();
    $adpositions = array('top','popup','bottom');
    foreach ($adpositions as $adposition) {
        $adpositionarr[] = array(
            $adposition,
            lang('plugin/strong_mobilead','position_'.$adposition),
            '');
    }   
    showsetting(lang('plugin/strong_mobilead','position'), array('parameters[extra][position]',$adpositionarr), $addata['parameters']['extra']['position'],
        'mradio');   
    }
    
    if($type!='forumdisplaythread' and $type!='viewthreadfloortop' and $type!='viewthreadfloorbottom'){
    showsetting(lang('plugin/strong_mobilead', 'adv_circulation_time'), 'parameters[extra][againshowtime]', $addata[parameters][extra][againshowtime], 'text','','',lang('plugin/strong_mobilead', 'adv_circulation_time_comment'));     
    }
    
    showsetting('adv_edit_style', array('settingnew[style]', $adtypearray), $addata['parameters']['style'],
        'mradio');
    
    if($addata['parameters']['extra']['position']!="popup"){    
    showtagheader('tbody', 'style_code', $addata['parameters']['style'] == 'code');
    showtitle('adv_edit_style_code');
    showsetting('adv_edit_style_code_html', 'settingnew[code][html]', $addata['parameters']['html'],
          'textarea');
    showtagfooter('tbody');
    }

    showtagheader('tbody', 'style_text', $addata['parameters']['style'] == 'text');
    showtitle('adv_edit_style_text');
    showsetting('adv_edit_style_text_title', 'settingnew[text][title]', $addata['parameters']['title'],
        'htmltext');
  
    showsetting('adv_edit_style_text_link', 'settingnew[text][link]', $addata['parameters']['link'],
        'text');
    showsetting('adv_edit_style_text_size', 'settingnew[text][size]', $addata['parameters']['size'],
        'text');
    showsetting(lang('plugin/strong_mobilead','adv_bg'), 'settingnew[text][background]', $addata['parameters']['background'],
        'color');    
    showsetting(lang('plugin/strong_mobilead','text_align'), array('settingnew[text][align]',$adimagealignarr), $addata['parameters']['align'],
        'mradio');  
          
    showsetting(lang('plugin/strong_mobilead','adv_css'), 'settingnew[text][css]', $addata['parameters']['css'],
        'textarea','','',lang('plugin/strong_mobilead','adv_css_comment'));        
    showtagfooter('tbody');


    showtagheader('tbody', 'style_image', $addata['parameters']['style'] == 'image');
    showtitle('adv_edit_style_image');

    showsetting('adv_edit_style_image_url', 'advnewimage', $addata['parameters']['url'],
        'filetext');
    showsetting('adv_edit_style_image_link', 'settingnew[image][link]', $addata['parameters']['link'],'text');


    showsetting('adv_edit_style_image_width', 'settingnew[image][width]', $addata['parameters']['width'],
        'text', '', 0, lang('plugin/strong_mobilead','adv_image_width'), 'id="imagewidth" onchange="setpreview(\'image\')"');
    showsetting('adv_edit_style_image_height', 'settingnew[image][height]', $addata['parameters']['height'],
        'text', '', 0, lang('plugin/strong_mobilead','adv_image_height'), 'id="imageheight" onchange="setpreview(\'image\')"');
  
    showsetting(lang('plugin/strong_mobilead','image_align'), array('settingnew[image][align]',$adimagealignarr), $addata['parameters']['align'],
        'mradio');  
                                
    showsetting(lang('plugin/strong_mobilead','adv_css'), 'settingnew[image][css]', $addata['parameters']['css'],
        'textarea','','',lang('plugin/strong_mobilead','adv_css_comment'));      
    showtagfooter('tbody');
    



    showsubmit('settingsubmit', 'submit');
    showtablefooter();
    showformfooter();/*Dism_taobao-com*/

    }else{
        
        $advnew = $_GET['settingnew'];        
        $advnew['starttime'] = $advnew['starttime'] ? strtotime($advnew['starttime']) : 0;
		$advnew['endtime'] = $advnew['endtime'] ? strtotime($advnew['endtime']) : 0;
        $parameters = !empty($_GET['parameters']) ? setselect($_GET['parameters']) : array();       

        $advnew['targets'] = !empty($advnew['targets']) ? implode(',',$advnew['targets']) : '';
        
      
        if($advnew['style'] == 'image') {
			if($_FILES['advnew'.$advnew['style']]) {
				$upload = new discuz_upload();
				if($upload->init($_FILES['advnew'.$advnew['style']], 'common') && $upload->save(1)) {
					$advnew[$advnew['style']]['url'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '').$_G['setting']['attachurl'].'common/'.$upload->attach['attachment'];
				}
			} else {
				$advnew[$advnew['style']]['url'] = $_GET['advnew'.$advnew['style']];
			}
		}
        

        $advnew['code'] = encodeadvcodes($advnew,$parameters);
        $advnew['parameters'] = serialize(array_merge(is_array($parameters) ? $parameters : array(), array('style' => $advnew['style']), $advnew['style'] == 'code' ? array() : $advnew[$advnew['style']], array('html' => $advnew['code']), array('displayorder' => $advnew['displayorder'])));
	
        if(!$advnew['title']) {
			cpmsg('adv_title_invalid', '', 'error');
		} elseif(strlen($advnew['title']) > 50) {
			cpmsg('adv_title_more', '', 'error');
		} elseif($advnew['endtime'] && ($advnew['endtime'] <= TIMESTAMP || $advnew['endtime'] <= $advnew['starttime'])) {
			cpmsg('adv_endtime_invalid', '', 'error');
		} elseif(($advnew['style'] == 'code' && !$advnew['code']['html'])
			|| ($advnew['style'] == 'text' && (!$advnew['text']['title'] || !$advnew['text']['link']))
			|| ($advnew['style'] == 'image' && (!$_FILES['advnewimage'] && !$_GET['advnewimage'] || !$advnew['image']['link']))
			|| ($advnew['style'] == 'flash' && (!$_FILES['advnewflash'] && !$_GET['advnewflash'] || !$advnew['flash']['width'] || !$advnew['flash']['height']))) {
			cpmsg('adv_parameter_invalid', '', 'error');
		}
        if(strstr($advnew['type'],'portalindex')){$advnew['type']='portalindex_'.$parameters[extra][portalposition];}  
        if($_GET['mmm'] == 'add') {
		    	
            DB::insert('strong_advertisement', array('available' => 1, 'type' => $advnew['type']), TRUE);	
            $advnew['advid'] = DB::insert_id();
		}
        if($_G['cookie']['strongadid_'.$advnew['advid']]==1){dsetcookie('strongadid_'.$advnew['advid']);}
    
        
        DB::update('strong_advertisement',array(
            'title' => $advnew['title'],
            'type'=>$advnew['type'],            
			'targets' => $advnew['targets'],
			'parameters' => $advnew['parameters'],
			'code' => $advnew['code'],
			'starttime' => $advnew['starttime'],
			'endtime' => $advnew['endtime'],
            'defaultcode'=>$advnew['defaultcode']            
            ), array('advid' => $advnew['advid']));
        update_avd_cache(); 
        
        
        cpmsg(lang('plugin/strong_mobilead', 'update_success'),'action=plugins&operation=config&identifier=strong_mobilead&pmod=ad_list'.($_GET[mmm]=='edit' ? '&mmm=edit&advid='.$advnew[advid] : ''),'succeed');
        
       
        
        
    }

} else {
    
    if(!submitcheck('settingsubmit')) {
    
    $type = $_GET['type'];  
    if($type=="portalindex"){        
        $where = " and `type` LIKE  '%portalindex%'";
        $type = 'portalindex';
    }else{
       $where = $type ? " and type='".$type."'" : ""; 
     
    }
  
    $addatalist = DB::fetch_all("SELECT * FROM " . DB::table('strong_advertisement') . " where 1 $where ORDER BY  `displayorder` ASC" );

    showformheader('plugins&operation=config&identifier=strong_mobilead&pmod=ad_list');
    showtableheader('', 'fixpadding');    
    
    showtitle($type ? lang('plugin/strong_mobilead',$type) : lang('plugin/strong_mobilead','alladv'));
    showsubtitle(array(
        '',
        'display_order',
        'available',
        'subject',
        !$type ? 'type' : '',
        'adv_style',
        'start_time',
        'end_time',
        'adv_targets',
        ''));


    foreach ($addatalist as $key => $val) {
        $val['parameters'] = dunserialize($val['parameters']);
        $targets='';
        if($val['targets']){
        $implodetarget = explode(',',$val['targets']);
        foreach($implodetarget as $targetsval){
            $targets .= lang('plugin/strong_mobilead','targets_'.$targetsval).',';
        }
        $targets = substr($targets,0,-1);
        }
        showtablerow('', array('class="td25"', 'class="td25"', 'class="td25"'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$val[advid]\">",
				"<input type=\"text\" class=\"txt\" size=\"2\" name=\"displayordernew[$val[advid]]\" value=\"$val[displayorder]\">",
				"<input class=\"checkbox\" type=\"checkbox\" name=\"availablenew[$val[advid]]\" value=\"1\" ".($val['available'] ? 'checked' : '').">",
				"<input type=\"text\" class=\"txt\" size=\"15\" name=\"titlenew[$val[advid]]\" value=\"".dhtmlspecialchars($val['title'])."\">",
				$val['type'] ? "<a href=\"admin.php?action=plugins&identifier=strong_mobilead&pmod=ad_list&type=".$val['type']."\">".lang('plugin/strong_mobilead', $val['type'])."</a>" : '',
				lang('plugin/strong_mobilead','styles_'.$val['parameters']['style']),
				$val['starttime'] ? dgmdate($val['starttime'], 'd') : $lang['unlimited'],
				$val['endtime'] ? dgmdate($val['endtime'], 'd') : $lang['unlimited'],
				$targets,
				"<a href=\"admin.php?action=plugins&identifier=strong_mobilead&pmod=ad_list&mmm=edit&advid=".$val['advid']."\" class=\"act\">$lang[edit]</a>"
			));
        $implodetarget = $targets = '';
    }


    showsubmit('settingsubmit', 'submit', 'del',
        $type!='' ? '<input type="button" class="btn" onclick="location.href=\'admin.php?action=plugins&identifier=strong_mobilead&pmod=ad_list&type='.$type.'&mmm=add\'" value="' .
        cplang('add') . '" />' : '', '', '');
    showtablefooter();
    showformfooter();/*Dism_taobao-com*/
    }else{
        
        
        if($_GET['delete']) {
            foreach($_GET['delete'] as $val){
		      	DB::delete('strong_advertisement',array('advid'=>$val));
            }
		}
        
        if(is_array($_GET['titlenew'])){
            
            foreach($_GET['titlenew'] as $advid=>$title){
                DB::update('strong_advertisement',array(
                    'available' => $_GET['availablenew'][$advid],
					'displayorder' => $_GET['displayordernew'][$advid],
					'title' => cutstr($_GET['titlenew'][$advid], 50)
                    ), array('advid' => $advid));    
                
            }           
            update_avd_cache();
        }
        
        
        cpmsg(lang('plugin/strong_mobilead', 'Successful_operation'),'action=plugins&operation=config&identifier=strong_mobilead&pmod=ad_list','succeed');
        
    }
}
//From: dis'.'m.tao'.'bao.com
?>

