<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!strstr($_G[PHP_SELF], 'admin')) {
    exit();
}
require_once DISCUZ_ROOT . 'source/plugin/strong_mobilead/include/ad_func.php';

$adtypearr = getadvtypearr();
$advdata = DB::fetch_all("SELECT * FROM " . DB::table('strong_advertisement'));
$datanum = 0;
foreach($adtypearr as $key=>$val){
    echo "<h2 style=\"margin-bottom: 10px; margin-top:20px;\">".lang('plugin/strong_mobilead','targets_'.$key)."</h2>";
    foreach($val as $k=>$v){
        foreach($advdata as $i){
            if(strstr($i['type'],'portalindex')){$i['type']='portalindex';}
            if($i['type']==$k){
                $datanum ++;
            }
        }
        $datanum = $datanum !=0 ? '('.$datanum.')' : '';
        echo "<a href=\"admin.php?action=plugins&operation=config&do=20&identifier=strong_mobilead&pmod=ad_list&type=$k\" style=\"margin: 0 25px 10px 0;\">$v<span style=\"margin-left:2px;\">$datanum</span></a>";
        $datanum = 0;
    }
}
//From: Dism_taobao_com
?>