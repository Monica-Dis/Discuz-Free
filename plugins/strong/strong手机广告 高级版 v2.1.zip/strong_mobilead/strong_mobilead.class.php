<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once DISCUZ_ROOT . 'source/plugin/strong_mobilead/include/ad_func.php';

 
class mobileplugin_strong_mobilead {
		public function global_header_mobile() {
			global $_G;  
            $cache_dir = DISCUZ_ROOT.'./data/sysdata/cache_';
            if(!file_exists($cache_dir.'strong_mobilead.php')){
                require_once libfile('function/cache');
            	update_avd_cache();
                require_once $cache_dir.'strong_mobilead.php';
            }else{
            	require_once $cache_dir.'strong_mobilead.php';            
            }
                        
            foreach($strong_adv_cache as $key=>$adval){
                $_G['strong_advertisement'][$adval[type]][$key] = $adval;                
            }
         
            
			
			$style = '<style>
            .strong_ad_globalfloat_image_top{padding: 0 0 0 0;position: fixed;left: 0;top:0; z-index: 999999; background: rgba(0, 0, 0, 0.5); width: 100%;    clear: both;}
            .strong_ad_globalfloat_image_popup,.strong_ad_globalfloat_text_popup{padding: 0 0 0 0;position: fixed;left: 0;bottom:0; top:0; right:0; overflow: auto; z-index: 999999; background: rgba(0, 0, 0, 0.5); width: 100%; height:100%; text-align: center; clear: both;}
            .strong_ad_globalfloat_image_bottom{padding: 0 0 0 0;position: fixed;left: 0;bottom:0; z-index: 999999; background: rgba(0, 0, 0, 0.5); width: 100%; clear: both;}
            
            .strong_ad_globalfloat_text_popup a{background: #fff; padding: 20px; width:200px; height:100px; border-radius: 20px;position: fixed;
    left: 0;color: #333; overflow: hidden;}
            .strong_ad_globalfloat_text_bottom{padding: 0 0 0 0;position: fixed;left: 0; z-index: 999999; background: rgba(0, 0, 0, 0.5); width: 100%;bottom:0;}
            .strong_ad_globalfloat_text_top{padding: 0 0 0 0;position: fixed;left: 0; z-index: 999999; background: rgba(0, 0, 0, 0.5); width: 100%;top:0;}
            
            
            
            .strong_ad_globalfloat_image_popup a img{z-index: 9999991;position: fixed; width:215px; height:250px;    border-radius: 15px;}
            .strong_ad_globalfloat_image_popup em.colse{position: absolute;right: 30px; width: 20px; height: 20px; top: 30px; display: block; z-index: 999999999; background: url(\''.$_G['siteurl'].'source/plugin/strong_mobilead/img/icon/x.png\');
    background-size: 20px 20px; background-repeat: no-repeat; background-position: center;}
            
            
            .strong_ad_text{position: relative; clear: both;}
            .strong_ad_image{position: relative; clear: both;} 
            .strong_ad_code{position: relative; clear: both;} 
            .strong_ad_colse{position: absolute;right: 10px; width: 20px; height: 20px; top: 10px; display: block; z-index: 999999999; background: url(\''.$_G['siteurl'].'source/plugin/strong_mobilead/img/icon/x.png\');
    background-size: 20px 20px; background-repeat: no-repeat; background-position: center;}
    .strong_ad_globalfloatt_text a{min-height: 40px; line-height: 40px; padding: 0 10px;}
            .strong_ad_globalfloat_image_popup em.colse,.strong_ad_globalfloat_text_popup em.colse{top:30px; right:30px;}
    
    		</style>';
       
            $return = $style.getshowad('globaltop').getshowad('globalfloat');       
		    return $return;
	}
    
    public function global_footer_mobile(){
                
       return getshowad('globalbottom');
    }
    public function ad_portal_index_0_mobile() {
        
       return getshowad('portalindex_0');    
    }
    public function ad_portal_index_1_mobile() {
       return getshowad('portalindex_1');    
    }
    public function ad_portal_index_2_mobile() {
       return getshowad('portalindex_2');    
    }
    public function ad_portal_index_3_mobile() {
       return getshowad('portalindex_3');    
    }
    public function ad_portal_index_4_mobile() {
       return getshowad('portalindex_4');    
    }
    public function ad_portal_index_5_mobile() {
       return getshowad('portalindex_5');    
    }
    public function ad_portal_index_6_mobile() {
       return getshowad('portalindex_6');    
    }
    public function ad_portal_index_7_mobile() {
       return getshowad('portalindex_7');    
    }
    public function ad_portal_index_8_mobile() {
       return getshowad('portalindex_8');    
    }
    public function ad_portal_index_9_mobile() {
       return getshowad('portalindex_9');    
    }
    
    public function ad_portal_list_top_mobile() {
        return getshowad('portallisttop');    
    }
    public function ad_portal_list_bottom_mobile() {
        return getshowad('portallistbottom');    
    }
    
//    public function ad_portal_list_rand_mobile(){
//        return getshowad('portallistrand');   
//    }
    public function ad_portal_content_top_mobile() {
        return getshowad('portalcontenttop');    
    }    
    public function ad_portal_content_bottom_mobile() {
        return getshowad('portalcontentbottom');    
    }   
    public function ad_portal_content_page_mobile() {
        return getshowad('portalcontentpage');    
    }   
    public function ad_portal_content_correlation_mobile() {
        return getshowad('portalcontentcorrelation');    
    }   
    
}



class mobileplugin_strong_mobilead_forum extends mobileplugin_strong_mobilead{
		public function index_top_mobile_output() {
			return getshowad('forumtop');
	}

	
		public function index_middle_mobile_output() {
			return getshowad('forumbottom');
	}



	public function forumdisplay_thread_mobile_output() { 	  
	  
			return getshowad('forumdisplaythread');
	}
	


		public function forumdisplay_top_mobile_output() {
		  
			return getshowad('forumdisplaytop');
	}

		public function forumdisplay_bottom_mobile_output() {
			return getshowad('forumdisplaybottom');
	}


		public function viewthread_top_mobile_output() {
		      
			return getshowad('viewthreadtop');
	}

		public function viewthread_bottom_mobile_output() {
			return getshowad('viewthreadbottom');
	}
    
    public function viewthread_posttop_mobile_output(){
        
        return getshowad('viewthreadfloortop');
    }
    public function viewthread_postbottom_mobile_output(){
        return getshowad('viewthreadfloorbottom');
    }
}

class mobileplugin_strong_mobilead_member extends mobileplugin_strong_mobilead{
    
    public function logging_bottom_mobile_output() {    
          
			return getshowad('login');
	}
    public function register_bottom_output() {           
			return getshowad('register');
	}
}


class mobileplugin_strong_mobilead_group extends mobileplugin_strong_mobilead{


    public function forumdisplay_thread_mobile_output() {           
			return getshowad('forumdisplaythread');
	}
    
	public function forumdisplay_top_mobile_output() {
			return getshowad('forumdisplaytop');
	}
    
	public function forumdisplay_bottom_mobile_output() {
			return getshowad('forumdisplaybottom');
	}
    
  
	public function viewthread_top_mobile_output() {
	       
			return getshowad('viewthreadtop');
	}

    public function viewthread_bottom_mobile_output() {
			return getshowad('viewthreadbottom');
	}
    public function viewthread_posttop_mobile_output(){
        return getshowad('viewthreadfloortop');
    }
    public function viewthread_postbottom_mobile_output(){
        return getshowad('viewthreadfloorbottom');
    }


}


//From: Dism_taobao_com
?>
