<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_strong_advertisement` (
  `advid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `available` tinyint(1) NOT NULL DEFAULT '0',
  `type` varchar(50) NOT NULL DEFAULT '0',
  `displayorder` tinyint(3) NOT NULL DEFAULT '0',
  `title` varchar(255) NOT NULL DEFAULT '',
  `targets` text NOT NULL,
  `parameters` text NOT NULL,
  `code` text NOT NULL,
  `starttime` int(10) unsigned NOT NULL DEFAULT '0',
  `endtime` int(10) unsigned NOT NULL DEFAULT '0',
  `defaultcode` tinyint(1) NOT NULL,
  PRIMARY KEY (`advid`)
) ENGINE=MyISAM;

EOF;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead_TC_UTF8.xml');
$finish = TRUE;
?>
