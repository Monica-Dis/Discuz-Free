<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `pre_strong_advertisement`;

EOF;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/discuz_plugin_strong_mobilead_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/ad_cache.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/ad_list.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/ad_type.inc.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/strong_mobilead.class.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/include/ad_func.php');
@unlink(DISCUZ_ROOT . './source/plugin/strong_mobilead/install.php');
$finish = TRUE;

?>