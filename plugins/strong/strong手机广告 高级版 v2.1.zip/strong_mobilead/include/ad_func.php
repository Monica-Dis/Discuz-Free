<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


function getselect($keyarr) {
    global $_G;
    loadcache($keyarr);
    if(in_array('forums', $keyarr)) {
        $forumselect = array();
        $forumselect[] = array(0, lang('plugin/strong_mobilead', 'empty'));
        foreach ($_G['cache']['forums'] as $value) {
            $forumselect[] = array(
                $value['fid'],
                ($value['type'] == 'group' ? str_repeat('-', 2) : ($value['type'] == 'forum' ?
                    str_repeat('&nbsp;', 4) : ($value['type'] == 'sub' ? str_repeat('&nbsp;', 10) :
                    ''))) . $value['name'],
                ($value['type'] == 'group' ? true : ''));
        }
    }

    if(in_array('grouptype', $keyarr)) {
        $groupselect = array();
        $groupselect[] = array(0, lang('plugin/strong_mobilead', 'empty'));
        foreach ($_G['cache']['grouptype']['first'] as $key => $value) {
            $groupselect[] = array($key, $value[name]);
            foreach ($_G['cache']['grouptype']['second'] as $k => $v) {
                if($v[fup] == $key) {
                    $groupselect[] = array($k, str_repeat('&nbsp;', 5) . $v[name]);
                }
            }
        }

    }

    if(in_array('portalcategory', $keyarr)) {
        $portalselect[] = array(0, lang('plugin/strong_mobilead', 'empty'));
        foreach ($_G['cache']['portalcategory'] as $key => $value) {
            if($value[upid] == 0) {
                $portalselect[] = array($value[catid], ($value[upid] != 0 ? str_repeat('&nbsp;',
                        5) . $value[catname] : $value[catname]));
                foreach ($_G['cache']['portalcategory'] as $sk => $sv) {
                    if($sv[upid] == $value[catid]) {
                        $portalselect[] = array($sv[catid], ($sv[upid] == $value[catid] ? str_repeat('&nbsp;',
                                5) . $sv[catname] : $sv[catname]));

                        foreach ($_G['cache']['portalcategory'] as $tk => $tv) {
                            if($tv[upid] == $sv[catid]) {
                                $portalselect[] = array($tv[catid], ($tv[upid] == $sv[catid] ? str_repeat('&nbsp;',
                                        10) . $tv[catname] : $tv[catname]));
                            }
                        }
                    }
                }
            }
        }

    }


    return array(
        'forums' => $forumselect,
        'grouptype' => $groupselect,
        'portalcategory' => $portalselect);
}

function setselect($parameters) {
    $parameters[extra][fids][0] == 0 ? $parameters[extra][fids] = '' : '';
    $parameters[extra][groups][0] == 0 ? $parameters[extra][groups] = '' : '';
    $parameters[extra][category][0] == 0 ? $parameters[extra][category] = '' : '';
    $parameters[extra][fixationshow][0] == 0 ? $parameters[extra][fixationshow] = '' :
        '';
    return $parameters;
}


function gettarget($type = '') {

    switch ($type) {
        case 'forumtop':
            $targets = array('forum');
            $selecttypes = array();
            break;

        case 'forumbottom':
            $targets = array('forum');
            $selecttypes = array();
            break;

        case 'forumdisplaytop':
            $targets = array('forum', 'groups');
            $selecttypes = array('forums', 'grouptype');
            break;

        case 'forumdisplaybottom':
            $targets = array('forum', 'groups');
            $selecttypes = array('forums', 'grouptype');
            break;

        case 'forumdisplaythread':
            $targets = array('forum', 'groups');
            $selecttypes = array('forums', 'grouptype');
            break;

        case 'viewthreadtop':
            $targets = array('forum', 'groups');
            $selecttypes = array('forums', 'grouptype');
            break;

        case 'viewthreadbottom':
            $targets = array('forum', 'groups');
            $selecttypes = array('forums', 'grouptype');
            break;

        case 'viewthreadfloortop':
            $targets = array('forum', 'groups');
            $selecttypes = array('forums', 'grouptype');
            break;

        case 'viewthreadfloorbottom':
            $targets = array('forum', 'groups');
            $selecttypes = array('forums', 'grouptype');
            break;

        case 'portalindex':
            $targets = array('portal');
            break;
        case 'portalindex_0':
            $targets = array('portal');
            break;
        case 'portalindex_1':
            $targets = array('portal');
            break;  
        case 'portalindex_2':
            $targets = array('portal');
            break; 
        case 'portalindex_3':
            $targets = array('portal');
            break;     
        case 'portalindex_4':
            $targets = array('portal');
            break;     
        case 'portalindex_5':
            $targets = array('portal');
            break;     
        case 'portalindex_6':
            $targets = array('portal');
            break;               
        case 'portalindex_7':
            $targets = array('portal');
            break; 
        case 'portalindex_8':
            $targets = array('portal');
            break; 
        case 'portalindex_9':
            $targets = array('portal');
            break; 
                    
        case 'portallisttop':
            $targets = array('portal');
            $selecttypes = array('portalcategory');
            break;

        case 'portallistbottom':
            $targets = array('portal');
            $selecttypes = array('portalcategory');
            break;

        case 'portallistrand':
            $targets = array('portal');
            $selecttypes = array('portalcategory');
            break;

        case 'portalcontenttop':
            $targets = array('portal');
            $selecttypes = array('portalcategory');
            break;

        case 'portalcontentbottom':
            $targets = array('portal');
            $selecttypes = array('portalcategory');
            break;

        case 'portalcontentpage':
            $targets = array('portal');
            $selecttypes = array('portalcategory');
            break;

        case 'portalcontentcorrelation':
            $targets = array('portal');
            $selecttypes = array('portalcategory');
            break;

        case 'register':
            $targets = array('loginregister');
            break;

        case 'login':
            $targets = array('loginregister');
            break;

        case 'globalfloat':
            $targets = array(
                'forum',
                'portal',
                'groups',
                'home',
                'search',
                'loginregister');
            $selecttypes = array(
                'forums',
                'portalcategory',
                'grouptype');
            break;

        case 'globaltop':
            $targets = array(
                'forum',
                'portal',
                'groups',
                'home',
                'search',
                'loginregister');
            $selecttypes = array(
                'forums',
                'portalcategory',
                'grouptype');
            break;

        case 'globalbottom':
            $targets = array(
                'forum',
                'portal',
                'groups',
                'home',
                'search',
                'loginregister');
            $selecttypes = array(
                'forums',
                'portalcategory',
                'grouptype');
            break;

        default:
            $targets = array('forum');

    }
    return array('targetarr' => $targets, 'selecttypes' => $selecttypes);

}

function getadvtypearr() {
    $adtypearr = array(
        'forum' => array(
            'forumtop' => lang('plugin/strong_mobilead', 'forumtop'),
            'forumbottom' => lang('plugin/strong_mobilead', 'forumbottom'),
            'forumdisplaytop' => lang('plugin/strong_mobilead', 'forumdisplaytop'),
            'forumdisplaybottom' => lang('plugin/strong_mobilead', 'forumdisplaybottom'),
            'forumdisplaythread' => lang('plugin/strong_mobilead', 'forumdisplaythread'),
            'viewthreadtop' => lang('plugin/strong_mobilead', 'viewthreadtop'),
            'viewthreadbottom' => lang('plugin/strong_mobilead', 'viewthreadbottom'),
            'viewthreadfloortop' => lang('plugin/strong_mobilead', 'viewthreadfloortop'),
            'viewthreadfloorbottom' => lang('plugin/strong_mobilead',
                'viewthreadfloorbottom')),
        'portal' => array(
            'portalindex' => lang('plugin/strong_mobilead', 'portalindex'),
            'portallisttop' => lang('plugin/strong_mobilead', 'portallisttop'),
            'portallistbottom' => lang('plugin/strong_mobilead', 'portallistbottom'),
            //'portallistrand' => lang('plugin/strong_mobilead', 'portallistrand'),
            'portalcontenttop' => lang('plugin/strong_mobilead', 'portalcontenttop'),
            'portalcontentbottom' => lang('plugin/strong_mobilead', 'portalcontentbottom'),
            'portalcontentpage' => lang('plugin/strong_mobilead', 'portalcontentpage'),
            'portalcontentcorrelation' => lang('plugin/strong_mobilead',
                'portalcontentcorrelation')),
        'loginregister' => array('register' => lang('plugin/strong_mobilead', 'register'),
                'login' => lang('plugin/strong_mobilead', 'login')),
        'global' => array(
            'globalfloat' => lang('plugin/strong_mobilead', 'globalfloat'),
            'globaltop' => lang('plugin/strong_mobilead', 'globaltop'),
            'globalbottom' => lang('plugin/strong_mobilead', 'globalbottom')));

    return $adtypearr;
}

function echocalendarjs() {

    echo '<script type="text/javascript" src="static/js/calendar.js"></script>';

}

function encodeadvcodes($advnew,$parameters) {
  
   


    switch ($advnew['style']) {
        case 'code':
            $advnew['code'] = $advnew['code']['html'];
            break;
        case 'text':
              
             
            $advnew['code'] = '
               <a href="' . $advnew['text']['link'] .
                '" class="strongadid_' . $advnew['advid'].'_a" target="_blank" style="padding: 10px;display: block; clear: both;text-align:' . $advnew['text']['align'] .
                ';font-size:' . $advnew['text']['size'] . ';background:' . $advnew['text']['background'] .
                ';' . $advnew['text']['css'] . ';">' . $advnew['text']['title'] . '</a>';
                
 
            
            break;            
        case 'image':
       
                
                $advnew['code'] = '        
            <a href="' . $advnew['image']['link'] .
                    '" style="display:'.($parameters['extra']['position']=='popup' ? 'inline-block' : 'block').'; clear: both;text-align:' . $advnew['image']['align'] .
                    ';' . $advnew['image']['css'] . '" target="_blank"><img src="' . $advnew['image']['url'] .
                    '" style="display: inline; visibility: visible;vertical-align: middle;max-width:100%;' . ($advnew['image']['height'] ?
                    ' height:' . $advnew['image']['height'] . ';' : '') . ($advnew['image']['width'] ?
                    ' width:' . $advnew['image']['width'] . ';' : '') . '" ' . ($advnew['image']['alt'] ?
                    ' alt="' . $advnew['image']['alt'] . '"' : '') . ' border="0"></a>';

            

            break;

    }
    return $advnew['code'];
}



function getreturndata($type, $code, $parameters) {
    global $_G;
   
    if($type == 'forumdisplaythread') {
        $num = $_G[tpp];
    } elseif ($type == 'viewthreadfloortop' or $type == 'viewthreadfloorbottom') {
        $num = $_G[ppp];

    } else {
        return '';
    }
   
    if(!empty($parameters[extra][fixationshow])) {
        foreach ($parameters[extra][fixationshow] as $fixationval) {
            
            $return[($fixationval - 1 - ($_G[page]-1)*$num)] = $code;
        }
        return $return;
    }

    if(empty($parameters[extra][fixationshow]) and $parameters[extra][randomshownum] >=
        1) {

        for ($r = 1; $r <= $parameters[extra][randomshownum]; $r++) {
            $parameters[extra][randomshowodds] == 1 ? $return[rand(0, ($num - 1))] = $code : (rand
                (0, $parameters[extra][randomshowodds]) == 0 ? $return[rand(0, ($num - 1))] = $code :
                '');
        }

        return $return;
    }

    for ($n = 0; $n <= $num; $n++) {

        $return[$n] = $code;

    }

    return $return;


}


function getshowad($type) {   
    global $_G;
    if(empty($type)) {
        return '';
    }
    $groupidarr = unserialize($_G['cache']['plugin']['strong_mobilead']['groupid']);
    $ifshowadv = in_array($_G['groupid'], $groupidarr);
    $defaultcode = $_G['cache']['plugin']['strong_mobilead']['defaultcode'];
    $basescript = $_G['basescript'] == 'member' ? 'login' : $_G['basescript'];
    $getadvselect = gettarget($type);
    
   
    foreach ($_G['strong_advertisement'][$type] as $val) {
        $parameters = unserialize($val['parameters']);
        $targets = strstr($val['targets'], $basescript);       
     
        if($targets) {
            $has = 1;

            if(in_array('forums', $getadvselect['selecttypes']) and $basescript == 'forum') {
                empty($parameters[extra][fids]) ? '' : (in_array($_G['fid'], $parameters[extra][fids]) ?
                    '' : $has = 0);
            }

            if(in_array('portalcategory', $getadvselect['selecttypes']) and $basescript ==
                'portal') {

                empty($parameters[extra][category]) ? '' : (in_array($_G['catid'], $parameters[extra][category]) ?
                    '' : $has = 0);
            }
            if(in_array('grouptype', $getadvselect['selecttypes']) and $basescript ==
                'group') {

                empty($parameters[extra][groups]) ? '' : (in_array($_G['forum']['fup'], $parameters[extra][groups]) ?
                    '' : $has = 0);
            }
            
            
            
            if($parameters[extra][onweixin]){
                $has = 0;
                if(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false){$has=1;}  
                
            }      
            
                 
            if($_G['cookie']['strongadid_'.$val['advid']]==1){$has = 0;}            
         
           
            if((empty($val['starttime']) or $val['starttime'] <= time()) and (empty($val['endtime']) or
                $val['endtime'] >= time()) and $has) {

                if($type=='forumdisplaythread' or $type=='viewthreadfloortop' or $type=='viewthreadfloorbottom'){
                    
                    $return[] = getreturndata($type, $val[code], $parameters);          
                  
                }else{
                    
                    $return .= getadvcode($val[code],$val,$parameters);
                }
            } elseif ($val['endtime'] <= time() and $val['defaultcode'] and $has) {

                $return .= $defaultcode;
            }
        }
    }
    if($type=='forumdisplaythread' or $type=='viewthreadfloortop' or $type=='viewthreadfloorbottom'){
      
        foreach($return as $k=>$v){
            foreach($v as $kk=>$vv){
                if(empty($returns[$kk])){
                    $returns[$kk] = $vv;
                }else{
                    $returns[$kk] = $returns[$kk].$vv;
                }
              
            }    
            
        }
        $return = '';
        $return = $returns;
        
    }
    
    return $return;
}

function getadvcode($code,$val,$parameters){
    
    $clickcolsestr = 'onclick="$(\'.strongadid_'.$val['advid'] . '\').hide();setcookie(\'strongadid_'.$val['advid'].'\',1,'.($parameters[extra][againshowtime]+1).');"';
    $clickscrncolsestr = $clickcolsestr;
    $colseemstr = '<em '.$clickcolsestr.' class="strong_ad_colse"></em>';
    ($parameters['extra']['position']!='popup') ? ($clickscrncolsestr='') : '';    
    ($val[type] != 'globalfloat') ? (($parameters[extra][againshowtime] == '' or $parameters[extra][againshowtime] <= 5) ? ($clickcolsestr=$colseemstr='') : '') : '';
    $adv_class=($val[type] == 'globalfloat') ? ('strong_ad_globalfloat_'.$parameters['style'].'_'.$parameters['extra']['position']) : ('strong_ad_'.$parameters['style']);
    
    if($parameters['extra']['position']=='popup'){
        if($parameters['style']=='text'){
           $adv_script='<script>$(".strongadid_'.$val['advid'].'_a").css({"top":($(window).height()-$(".strongadid_'.$val['advid'].'_a").outerHeight())/2+"px","left":($(window).width()-$(".strongadid_'.$val['advid'].'_a").outerWidth())/2+"px"});</script>'; 
        }elseif($parameters['style']=='image'){
           $adv_script='<script>$(".strongadid_'.$val['advid'].' img").css({"top":($(window).height()-$(".strongadid_'.$val['advid'].' img").height())/2+"px","left":($(window).width()-$(".strongadid_'.$val['advid'].' img").width())/2+"px"});</script>';  
        }
        
    }
   
    
    $return = '<div '. $clickscrncolsestr.' class="'.$adv_class.' strongadid_' . $val['advid'] .
                    '">'.$colseemstr.$code.'</div>'.$adv_script;
              
    return $return;
}


function update_avd_cache(){
    $strong_adv_cache = DB::fetch_all("SELECT * FROM " . DB::table('strong_advertisement') ." where available = 1 ORDER BY  `displayorder` ASC");
    $strong_adv_cache = "\$strong_adv_cache = ".arrayeval($strong_adv_cache).";\n";
    writetocache('strong_mobilead', $strong_adv_cache);
}

//From: Dism��taobao��com
?>