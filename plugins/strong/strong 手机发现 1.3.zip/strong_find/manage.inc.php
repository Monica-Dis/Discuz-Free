<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
global $_G;


if($_GET['mmm'] != 'del') {
    if(submitcheck('editsubmit')) {


        $updates = $_POST['updatefind'];
        $newfind = $_POST['newfind'];
        $filedata = $_FILES;
        //var_dump($filedata);
        //echo count($filedata['icon']['tmp_name']);
        //exit();

        if($newfind['type']) {

            foreach($newfind['type']['name'] as $ntkey => $ntval) {

                DB::insert('strong_find_type', array(
                    'title' => $ntval,
                    'displayorder' => $newfind['type']['displayorder'][$ntkey],
                    'styleid' => $newfind['type']['styleid'][$ntkey]), true);
            }


        }


        if($newfind['menu']) {

            foreach($newfind['menu']['sid'] as $nmkey => $nmval) {
                $newmenuarr = array();

                if($filedata['newicon']['name'][$nmkey]) {
                    $upload = new discuz_upload();

                    $attach = array(
                        'name' => $filedata['newicon']['name'][$nmkey],
                        'type' => $filedata['newicon']['type'][$nmkey],
                        'tmp_name' => $filedata['newicon']['tmp_name'][$nmkey],
                        'error' => $filedata['newicon']['error'][$nmkey],
                        'size' => $filedata['newicon']['size'][$nmkey]);

                    if($upload->init($attach, 'temp') && $upload->save(1)) {
                        $newmenuarr['icon'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '') . $_G['setting']['attachurl'] . 'temp/' . $upload->attach['attachment'];

                    }


                }


                $newmenuarr['title'] = $newfind['menu']['name'][$nmkey];
                $newmenuarr['displayorder'] = $newfind['menu']['displayorder'][$nmkey];
                $newmenuarr['url'] = $newfind['menu']['url'][$nmkey];
                $newmenuarr['sid'] = $nmval;
                $newmenuarr['describe'] = $newfind['menu']['describe'][$nmkey];


                DB::insert('strong_find_menu', $newmenuarr, true);
            }

        }


        foreach($updates['type']['title'] as $key => $val) {

            DB::update('strong_find_type', array(
                'title' => $updates['type']['title'][$key],
                'displayorder' => $updates['type']['displayorder'][$key],
                'styleid' => $updates['type']['styleid'][$key]), array('id' => $key));

        }


        foreach($updates['menu']['title'] as $menuk => $menuv) {
            $updatearr = array();
            if($filedata['icon']['name'][$menuk]) {

                $upload = new discuz_upload();

                $attach = array(
                    'name' => $filedata['icon']['name'][$menuk],
                    'type' => $filedata['icon']['type'][$menuk],
                    'tmp_name' => $filedata['icon']['tmp_name'][$menuk],
                    'error' => $filedata['icon']['error'][$menuk],
                    'size' => $filedata['icon']['size'][$menuk]);

                if($upload->init($attach, 'temp') && $upload->save(1)) {
                    $updatearr['icon'] = (!strstr($_G['setting']['attachurl'], '://') ? $_G['siteurl'] : '') . $_G['setting']['attachurl'] . 'temp/' . $upload->attach['attachment'];

                }


            }

            $updatearr['title'] = $updates['menu']['title'][$menuk];
            $updatearr['displayorder'] = $updates['menu']['displayorder'][$menuk];
            $updatearr['url'] = $updates['menu']['url'][$menuk];
            $updatearr['describe'] = $updates['menu']['describe'][$menuk];


            DB::update('strong_find_menu', $updatearr, array('id' => $menuk));

        }


        cpmsg(lang('plugin/strong_find', 'succeed'), 'action=plugins&operation=config&identifier=strong_find&pmod=manage', 'succeed');


    } else {

       	showtips(lang('plugin/strong_find', 'hint'));
        showformheader('plugins&operation=config&identifier=strong_find&pmod=manage', 'enctype');
        showtableheader('');
        showsubtitle(array(
            '',
            'display_order',
            lang('plugin/strong_find', 'subtitle1'),
            lang('plugin/strong_find', 'subtitle2'),
            lang('plugin/strong_find', 'subtitle3'),
            lang('plugin/strong_find', 'subtitle4'),
            lang('plugin/strong_find', 'subtitle5')));


        $finddata = DB::fetch_all("select * from " . DB::table('strong_find_type') . " WHERE 1 ORDER BY displayorder asc");

        foreach($finddata as $key => $val) {

            $finddata[$key]['menu'] = DB::fetch_all("select * from " . DB::table('strong_find_menu') . " where sid=$val[id] ORDER by displayorder asc");

        }


        foreach($finddata as $key => $val) {

            showtagheader('tbody', '', 'true');
            showfind($val, 'type');
            showtagfooter('tbody');
            showtagheader('tbody', 'group_' . $val['id'], 'true');
            foreach($val['menu'] as $id => $menu) {

                showfind($menu, 'menu');

            }
            showtagfooter('tbody');

            showaddmenu($val['id']);

        }


        showaddtype();


        showsubmit('editsubmit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); //Dism_taobao_com


    }


} elseif($_GET['mmm'] == 'del') {

    $type = $_GET['type'];
    $dataid = intval($_GET['id']);
    if($type == 'menu') {
        DB::delete('strong_find_menu', array('id' => $dataid));
    } elseif($type == 'type') {
        DB::delete('strong_find_type', array('id' => $dataid));

        DB::delete('strong_find_menu', array('sid' => $dataid));

    }
    cpmsg(lang('plugin/strong_find', 'succeed'), 'action=plugins&operation=config&identifier=strong_find&pmod=manage', 'succeed');
}

echo '
<script type="text/JavaScript">
function returnaddmenu(fid){
    return \'<tr class="hover"><td class="td25"></td><td class="td25"><input type="hidden" name="newfind[menu][sid][]" value=\'+fid+\'><input type="text" name="newfind[menu][displayorder][]" value="0" class="txt"></td><td class="td24"><div class="board"><input type="text" name="newfind[menu][name][]" value="'.lang("plugin/strong_find", "menuname").'" class="txt"></div></td><td align="left" class="td24 "><input type="text" name="newfind[menu][describe][]" value="'.lang("plugin/strong_find", "not").'" class="txt"></td><td class="td24"><input type="text" name="newfind[menu][url][]" value="" class="txt"></td><td><input name="newicon[]" value="" type="file" class="uploadbtn" style="margin:6px 0 0 15px;"><img src="source/plugin/strong_find/template/img/default.png" style="height:40px;width:40px;float:left;"></td><td width="160"></td></tr>\';
}

    var rowtypedata =\'<tr class="hover"><td class="td25"></td><td class="td25"><input type="text" name="newfind[type][displayorder][]" value="0" class="txt"></td><td class="td24" style="width:195px;"><div><input type="text" name="newfind[type][name][]" value="'.lang("plugin/strong_find", "typename").'" class="txt" style="width:70px;float:left;"><select name="newfind[type][styleid][]"><option value="0" selected="">'.lang("plugin/strong_find", "styleid0").'</option><option value="1" >'.lang("plugin/strong_find", "styleid1").'</option><option value="2" >'.lang("plugin/strong_find", "styleid2").'</option><option value="3" >'.lang("plugin/strong_find", "styleid3").'</option></select></div></td><td align="left" class="td24 "></td><td class="td24"></td><td></td><td width="160"></td></tr>\';
	   
</script>
';


echo '
<script>


function addfind(obj,fid,type){
    	var table = obj.parentNode.parentNode.parentNode.parentNode.parentNode;
		var row = table.insertRow(obj.parentNode.parentNode.parentNode.rowIndex);
        
        if(type =="menu"){   
           var rowmenudata = returnaddmenu(fid);
	       row.innerHTML = rowmenudata;
        }else if(type == "type"){
           row.innerHTML = rowtypedata; 
        }
        
       
        
    };
</script>
';


function showfind($data, $type) {
    if($type != 'type' and $type != 'menu') {
        return '';
    }
    $return .= '<tr class="hover">
            <td class="td25" ' . ($type == 'type' ? 'onclick="toggle_group(\'group_' . $data['id'] . '\', $(\'a_group_' . $data['id'] . '\'))"' : '') . '>
                ' . ($type == 'type' ? '<a href="javascript:;" id="a_group_' . $data['id'] . '">[-] ' : '') . '</a>
            </td>
			<td class="td25">
                <input type="text" name="updatefind[' . $type . '][displayorder][' . $data['id'] . ']" value="' . $data['displayorder'] . '" class="txt">
                
            </td>
            <td class="td24">
                <div class="' . ($type == 'menu' ? 'board' : '') . '" ' . ($type == 'menu' ? 'style="width:140px;"' : 'style="width:195px;"') . '>
                <input type="text" name="updatefind[' . $type . '][title][' . $data['id'] . ']" value="' . $data['title'] . '" class="txt" ' . ($type == 'type' ? 'style="width:70px;float:left;"' : '') . '>
                ' . ($type == 'type' ? '
                    <select name="updatefind[' . $type . '][styleid][' . $data['id'] . ']">
                        <option value="1" ' . ($data['styleid'] == 1 ? 'selected' : '') . '>'.lang('plugin/strong_find', 'styleid1').'</option>                                               
                        <option value="2" ' . ($data['styleid'] == 2 ? 'selected' : '') . '>'.lang('plugin/strong_find', 'styleid2').'</option>
                        <option value="3" ' . ($data['styleid'] == 3 ? 'selected' : '') . '>'.lang('plugin/strong_find', 'styleid3').'</option>
                        <option value="0" ' . ($data['styleid'] == 0 ? 'selected' : '') . '>'.lang('plugin/strong_find', 'styleid0').'</option> 
                    </select>
                ' : '') . '    
                </div>
            </td>
            <td align="left" class="td24 ">
                ' . ($type == 'menu' ? ' <input type="text" name="updatefind[' . $type . '][describe][' . $data['id'] . ']" value="' . $data['describe'] . '" class="txt"> ' : '') . '
            </td>
			<td class="td24">
                ' . ($type == 'menu' ? ' <input type="text" name="updatefind[' . $type . '][url][' . $data['id'] . ']" value="' . $data['url'] . '" class="txt"> ' : '') . '
            </td>
            <td>
                ' . ($type == 'menu' ? '<input  name="icon[' . $data['id'] . ']" value="$data[icon]" type="file" class="uploadbtn" style="margin:6px 0 0 15px;"><img src="' . ($data['icon'] ? $data['icon'] : 'source/plugin/strong_find/template/img/default.png') . '" style="height:40px;width:40px;float:left;">' : '') .
        '
            </td>
            <td width="160">
            <a href="javascript:;" onclick=\'showDialog("' . ($type == 'type' ? ''.lang('plugin/strong_find', 'dialog1').'' : ''.lang('plugin/strong_find', 'dialog3').'') . '","right","'.lang('plugin/strong_find', 'dialog2').'","window.location.href=\"?action=plugins&operation=config&identifier=strong_find&pmod=manage&mmm=del&type=' . $type . '&id=' . $data['id'] . '\"","ss")\' class="act">'.lang('plugin/strong_find', 'del').'</a>
            </td>
        </tr>';


    echo $return;

}

function showaddmenu($id) {
    $return .= '
        <tr>
            <td></td>
            <td colspan="4"><div class="lastboard"><a href="###" onclick="addfind(this,' . $id . ',\'menu\')" class="addtr">'.lang('plugin/strong_find', 'addmenu').'</a></div></td>
            <td></td>        
        </tr>
    ';

    echo $return;

}

function showaddtype() {
    $return .= '
        <tr>
            <td></td>
            <td colspan="4"><div><a href="###" onclick="addfind(this, 0,\'type\')" class="addtr">'.lang('plugin/strong_find', 'addtype').'</a></div></td>
            <td></td>
        </tr>   ';
    echo $return;

}
//dis'.'m.t'.'ao'.'bao.com
?>

