<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: tel.class.php  2019-07  DisM.Taobao.Com  $
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class mobileplugin_apoyl_telbigimg
{

    private $smileys;

    public function discuzcode($value)
    {
        global $_G;
        
        $opensmiley = $_G['cache']['plugin']['apoyl_telbigimg']['smiley'];
        $wurl = unserialize($_G['cache']['plugin']['apoyl_telbigimg']['wurl']);
        
        $message = $_G['discuzcodemessage'];
        
        if ($opensmiley && $message) {
            $message = $this->_parses($message);
        }
        
        if (in_array($_G['fid'], $wurl)) {
            
            $message = $this->_img($message);
        }
        $_G['discuzcodemessage'] = $message;
    }

    private function _parses($message)
    {
        global $_G;
        static $enablesmiles;
        if ($enablesmiles === null) {
            $enablesmiles = false;
            if (! empty($_G['cache']['smilies']) && is_array($_G['cache']['smilies'])) {
                $this->smileys = $_G['cache']['smilies']['replacearray'];
                foreach ($this->smileys as $key => $smiley) {
                    $this->smileys[$key] = '<img style="width:' . $_G['cache']['plugin']['apoyl_telbigimg']['smwidth'] . 'px" src="' . STATICURL . 'image/smiley/' . $_G['cache']['smileytypes'][$_G['cache']['smilies']['typearray'][$key]]['directory'] . '/' . $smiley . '" smilieid="' . $key . '" border="0" alt="" />';
                }
                $enablesmiles = true;
            }
        }
        
        $enablesmiles && $message = preg_replace($_G['cache']['smilies']['searcharray'], $this->smileys, $message, $_G['setting']['maxsmilies']);
        
        return $message;
    }

    private function _img($message)
    {
        if (strpos($message, '[/img]') !== FALSE) {
            $message = preg_replace_callback("/\[img\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is", array(
                $this,
                "_callback_imgapoyl1"
            ), $message);
            $message = preg_replace_callback("/\[img=(\d{1,4})[x|\,](\d{1,4})\]\s*([^\[\<\r\n]+?)\s*\[\/img\]/is", array(
                $this,
                "_callback_imgapoyl2"
            ), $message);
        }
        return $message;
    }

    private function _callback_imgapoyl1($match)
    {
        return parseimg(0, 0, $match[1], '', 0);
    }

    private function _callback_imgapoyl2($match)
    {
        return parseimg($match[1], $match[2], $match[3], '', 0);
    }
}

class mobileplugin_apoyl_telbigimg_forum extends mobileplugin_apoyl_telbigimg
{

    private $list;

    public function viewthread_top_mobile()
    {
        global $_G;
        if (! $_G['setting']['mobile']['allowmobile'])
            return '';
        if (! $this->_isfm())
            return '';
        $cache = $_G['cache']['plugin']['apoyl_telbigimg'];
        $css = '';
        $borderradius = $this->_radius();
        $bordersolid = $this->_solid();
        if ($cache['isrew'] && ($cache['ismimg'] || $cache['isimg'])) {
            $css = '<style>.pbody img{max-width:100%; max-height:100%;width:100%;height:auto;' . $borderradius . $bordersolid . '}.box .vm{width:32px;height:32px;max-width:32px;max-height:32px;}
                .plc .pi .img_one img,.plc .pi .img_list img,.plc .pi .message img,.plc .pi .img_list li{max-width:100%; max-height:100%;width:100%;height:auto;' . $borderradius . $bordersolid . '}.plc .pi .message .box img{width:32px;height:32px;max-width:32px;max-height:32px;' . $borderradius . $bordersolid . '}
                </style>';
        } else {
            $m = intval($_GET['mobile']);
            if ($m == 2 && $cache['ismimg']) {
                $css = '<style>.plc .pi .img_one img,.plc .pi .img_list img,.plc .pi .message img,.plc .pi .img_list li{max-width:100%; max-height:100%;width:100%;height:auto;' . $borderradius . $bordersolid . '}.plc .pi .message .box img{width:32px;height:32px;max-width:32px;max-height:32px;' . $borderradius . $bordersolid . '}</style>';
            } elseif ($cache['isimg']) {
                $css = '<style>.pbody img{max-width:100%; max-height:100%;width:100%;height:auto;' . $borderradius . $bordersolid . '}.box .vm{width:32px;height:32px;max-width:32px;max-height:32px;}</style>';
            }
        }
        
        return $css;
    }

    public function viewthread_t_output($a)
    {
        global $postlist, $_G, $open_apoyl_telbigimg;
        if ($_G['setting']['mobile']['allowmobile'] && $this->_isfm()) {
            $m = intval($_GET['mobile']);
            $cache = $_G['cache']['plugin']['apoyl_telbigimg'];
            $issrc = $cache['issrc'];
            $open_apoyl_telbigimg = $cache['issilde'];
            
            if ($m == 2) {
                if (! $issrc)
                    $this->_repimg($postlist, $cache['mwidth'], $cache['mheight']);
                else
                    $this->_srcimg($postlist);
            } else {
                if (! $issrc)
                    $this->_repimg($postlist, $cache['width'], $cache['height']);
                else
                    $this->_srcimg($postlist);
            }
        }
    }

    private function _isfm()
    {
        global $_G;
        $forums = unserialize($_G['cache']['plugin']['apoyl_telbigimg']['forums']);
        if (in_array($_G['fid'], $forums)) {
            return true;
        }
        return false;
    }

    private function _srcimg(&$postlist)
    {
        foreach ($postlist as $k => $v) {
            if ($v['message'] = $this->_unpic($v)) {
                $postlist[$k]['imagelist'] = array();
            }
            $sp = '<img';
            $arr = explode($sp, $v['message']);
            $comm = '';
            $newmsg = '';
            $imgs = array();
            foreach ($arr as $vv) {
                if (preg_match('/&aid=(\d+)&/i', $vv, $match)) {
                    if (! $match[1])
                        continue;
                    $c = $postlist[$k]['attachments'][$match[1]];
                    $imgsrc = $c['url'] . $c['attachment'];
                    $vv = preg_replace('/src="forum(.*)"/i', 'src="' . $imgsrc . '"', $vv);
                }
                $newmsg .= $comm . $vv;
                $comm = $sp;
            }
            
            $postlist[$k]['message'] = $newmsg;
            
            $this->_imagelist($postlist[$k]['imagelist'], $postlist[$k]['attachments']);
        }
    }

    private function _repimg(&$postlist, $w, $h)
    {
        foreach ($postlist as $k => $v) {
            if ($v['message'] = $this->_unpic($v)) {
                $postlist[$k]['imagelist'] = array();
            }
            $sp = '<img';
            $str = preg_replace('/size=(\d)+x(\d)+/i', 'size=' . $w . 'x' . $h, $v['message']);
            $arr = explode($sp, $str);
            $comm = '';
            $newmsg = '';
            foreach ($arr as $vv) {
                if (preg_match('/&aid=(\d+)&/i', $vv, $match)) {
                    if (! $match[1])
                        continue;
                    $key = rawurlencode(dsign($match[1] . '|' . $w . '|' . $h));
                    $vv = preg_replace('/&key=(.*)&/i', '&key=' . $key . '&', $vv);
                }
                $newmsg .= $comm . $vv;
                $comm = $sp;
            }
            
            $postlist[$k]['message'] = $newmsg;
            $this->_imagelist($postlist[$k]['imagelist'], $postlist[$k]['attachments']);
        }
    }

    public function viewthread_bottom_mobile_output($a)
    {
        global $_G;
        if (! $_G['setting']['mobile']['allowmobile'])
            return '';
        if (! $this->list)
            return '';
        return '<script type="text/javascript">function apoyl(id){return document.getElementById(id);}' . $this->list . '</script>';
    }

    private function _imagelist($keys, $values)
    {
        foreach ($keys as $v) {
            $str .= 'apoyl("aimg_' . $v . '").src="' . $values[$v]['url'] . $values[$v]['attachment'] . '";';
        }
        $this->list .= $str;
    }

    private function _radius()
    {
        global $_G;
        $value = $_G['cache']['plugin']['apoyl_telbigimg']['radius'];
        if ($value)
            return 'border-radius:' . $value . 'px;';
        return '';
    }

    private function _solid()
    {
        global $_G;
        $value = $_G['cache']['plugin']['apoyl_telbigimg']['bsolid'];
        if ($value)
            return 'border:1px solid #ccc;';
        return '';
    }

    private function _unpic($v)
    {
        global $_G;
        $message = $v['message'];
        $value = $_G['cache']['plugin']['apoyl_telbigimg']['unpic'];
        if ($value && $v['imagelist']) {
            $message .= showattach($v, 1);
        }
        return $message;
    }
}
//From: Dism_taobao-com
?>