<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php  2018-07 DISM.TAOBAO.COM  $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `pre_plugin_apoyl_limit` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `gid` smallint(6) unsigned NOT NULL,
  `fid` mediumint(8) unsigned NOT NULL,
  `limittime` int(8) unsigned NOT NULL,
  `limitnum` int(8) unsigned NOT NULL,
  `tips` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gid` (`gid`,`fid`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

$finish = TRUE;
?>