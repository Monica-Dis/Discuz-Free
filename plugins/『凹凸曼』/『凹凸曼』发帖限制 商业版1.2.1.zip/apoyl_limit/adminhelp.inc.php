<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: adminhelp.inc.php  2018-07 DISM.TAOBAO.COM  $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
showtableheader();
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_interest')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_rewrite')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_html5upload')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_service')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_facebook')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_google')));

showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_weixinshare')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_prize')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_auth')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_teladv')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_vest')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_index')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_wmark')));

showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_googleping')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_twitter')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_listbigimg')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_hidesection')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_money')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_salary')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_moderator')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_mtime')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_picessence')));
showtablerow('','',array(lang('plugin/apoyl_limit','apoyl_picdivision')));



showtablerow('','',array(lang('plugin/apoyl_limit','addr')));
showtablerow('','',array(lang('plugin/apoyl_limit','blog')));
showtablerow('','',array(lang('plugin/apoyl_limit','qqapoyl')));
showtablefooter();/*Dism��taobao��com*/

?>