<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: limit.class.php  2018-08 DISM.TAOBAO.COM  $
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_apoyl_limit
{
}

class plugin_apoyl_limit_forum extends plugin_apoyl_limit
{

    public function post_apoyl()
    {
        global $_G;
        $cache = $_G['cache']['plugin']['apoyl_limit'];
        if ($_GET['action'] == 'newthread' && $_G['uid']) {
            
            if (! $cache['openpc'])
                return false;
            $row = C::t('#apoyl_limit#apoyl_limit')->fetchG($_G['fid'], $_G['groupid']);
            
            if (! $row) {
                if ($this->_globalApoyl($cache)) {
                    $this->_showMsg($cache['gtime'], $cache['gnum'], $cache['gmsgs']);
                } else {
                    return false;
                }
            } else {
                $this->_showMsg($row['limittime'], $row['limitnum'], $row['tips']);
            }
        }
        if ($_GET['action'] == 'reply' && $_G['uid']) {
            if (! $cache['openpc'])
                return false;
            if ($this->_globalApoylPost($cache)) {
                $this->_showMsgPost($cache['posttime'], $cache['postnum'], $cache['postmsgs']);
            } else {
                return false;
            }
        }
    }

    private function _globalApoyl($cache)
    {
        global $_G;
        if ($cache['openglobal'] && in_array($_G['fid'], unserialize($cache['gforums'])) && in_array($_G['groupid'], unserialize($cache['ggroup'])))
            return true;
        return false;
    }

    private function _globalApoylPost($cache)
    {
        global $_G;
        if ($cache['postglobal'] && in_array($_G['fid'], unserialize($cache['gforums'])) && in_array($_G['groupid'], unserialize($cache['ggroup'])))
            return true;
        return false;
    }

    private function _showMsg($limittime, $limitnum, $tips)
    {
        global $_G;
        $time = time() - $limittime;
        $num = C::t('#apoyl_limit#forum_thread_ext')->getNum($_G['uid'], $_G['fid'], $time);
        if ($num >= $limitnum) {
            showmessage($tips);
        }
    }

    private function _showMsgPost($limittime, $limitnum, $tips)
    {
        global $_G;
        $time = time() - $limittime;
        $num = C::t('#apoyl_limit#forum_post_ext')->getNum($_G['uid'], $_G['fid'], $time);
        if ($num >= $limitnum) {
            showmessage($tips);
        }
    }
}
//From: Dism_taobao_com
?>