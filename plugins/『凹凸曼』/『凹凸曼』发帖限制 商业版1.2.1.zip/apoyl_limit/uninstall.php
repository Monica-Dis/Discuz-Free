<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: uninstall.php  2018-07 DISM.TAOBAO.COM  $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
    DROP TABLE IF EXISTS `pre_plugin_apoyl_limit`;
EOF;
	runquery($sql);


$finish = TRUE;
?>