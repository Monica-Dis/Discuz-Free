<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_apoyl_limit.php  2018-07 DISM.TAOBAO.COM  $
 */
if(!defined('IN_DISCUZ')){
exit('Acccess Denied');
} 
class table_apoyl_limit extends discuz_table{
	public function __construct(){
		$this->_table = 'plugin_apoyl_limit';
		$this->_pk    = 'id';
		parent::__construct();
	}
	public function insert($data){
	    return DB::insert($this->_table, $data);
	}
	public function update($data,$id){
	    return DB::update($this->_table, $data, 'id='.$id);
	}
	
	public function fetchG($fid,$gid){
	    return DB::fetch_first('SELECT limittime,limitnum,tips FROM %t WHERE fid=%d AND gid=%d order by id desc',array($this->_table,$fid,$gid)); 
	}
	public function fetcharr($start,$limit,$orderby='id desc'){
	    if($start==-1){
	        $limit='limit '.$limit;
	    }else{
	        $start=empty($start)?0:$start;
	        $limit=empty($limit)?10:$limit;
	        $limit='limit '.$start.','.$limit;
	    }
	   	    return DB::fetch_all('SELECT * FROM %t  order by %i %i',array($this->_table,$orderby,$limit));
	}	

	public function count(){
	    return DB::result_first('SELECT COUNT(*) FROM %t  ',array($this->_table));
	}

}
//From: Dism_taobao-com
?>