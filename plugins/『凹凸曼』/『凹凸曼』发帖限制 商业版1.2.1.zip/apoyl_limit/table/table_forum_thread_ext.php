<?php
/**
 *      Copyright (c) 2020 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_forum_thread_ext.php  2018-07 DISM.TAOBAO.COM  $
 */
if (! defined('IN_DISCUZ')) {
    exit('Acccess Denied');
}

class table_forum_thread_ext extends table_forum_thread
{

    public function __construct()
    {
        $this->_table = 'forum_thread';
        $this->_pk = 'tid';
        parent::__construct();
    }

    public function getNum($uid, $fid, $time)
    {
        return DB::result_first('SELECT COUNT(tid) FROM %t WHERE authorid=%d AND fid=%d AND dateline>=%d', array(
            $this->_table,
            $uid,
            $fid,
            $time
        ));
    }
}
//From: Dism_taobao-com
?>