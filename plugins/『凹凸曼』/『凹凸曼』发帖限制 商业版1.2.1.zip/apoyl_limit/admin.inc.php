<?php
/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: admin.inc.php  2018-07 DISM.TAOBAO.COM  $
 */
if (! defined('IN_DISCUZ') || ! defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$go = $_GET['go'];
$formhash = $_GET['formhash'];
if ($go == 'del' && $formhash && FORMHASH == $formhash) {
    $vid = intval($_GET['vid']);
    $re = C::t('#apoyl_limit#apoyl_limit')->delete($vid);
} elseif ($go == 'edit') {
    $vid = intval($_GET['vid']);
    if (! submitcheck('editsubmit')) {
        $row = C::t('#apoyl_limit#apoyl_limit')->fetch($vid);
        @list ($forumselect, $groupselect) = getGroupForumId($row['fid'], $row['gid']);
        showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=apoyl_limit&pmod=admin&go=edit&page=' . $page . '&vid=' . $vid);
        
        showtableheader('');
        showtitle(lang('plugin/apoyl_limit', 'titlemod'));
        
        showsetting(lang('plugin/apoyl_limit', 'forumname'), '', $row['fid'], sprintf($forumselect, 'fid'), '', 0, lang('plugin/apoyl_limit', 'forumname_msg'));
        showsetting(lang('plugin/apoyl_limit', 'groupname'), '', $row['gid'], sprintf($groupselect, 'gid'), '', 0, lang('plugin/apoyl_limit', 'groupname_msg'));
        
        showsetting(lang('plugin/apoyl_limit', 'limittime'), 'limittime', $row['limittime'], 'text', '', 0, lang('plugin/apoyl_limit', 'limittime_msg'));
        showsetting(lang('plugin/apoyl_limit', 'limitnum'), 'limitnum', $row['limitnum'], 'text', '', 0, lang('plugin/apoyl_limit', 'limitnum_msg'));
        showsetting(lang('plugin/apoyl_limit', 'tips'), 'tips', $row['tips'], 'text', '', 0, lang('plugin/apoyl_limit', 'tips_msg'));
        showsubmit('editsubmit', 'submit', '', '', $multipage);
        showtablefooter();/*Dism��taobao��com*/
    } else {
        $tips = dhtmlspecialchars($_GET['tips']);
        $gid = intval($_GET['gid']);
        $fid = intval($_GET['fid']);
        $limittime = intval($_GET['limittime']);
        $limitnum = intval($_GET['limitnum']);
        if ($fid && $gid && $tips && $limittime && $limitnum) {
            $data = array(
                'fid' => $fid,
                'gid' => $gid,
                'limittime' => $limittime,
                'limitnum' => $limitnum,
                'tips' => $tips
            );
            C::t('#apoyl_limit#apoyl_limit')->update($data, $vid);
        }
    }
} elseif ($go == 'add' && submitcheck('addsubmit')) {
    $tips = dhtmlspecialchars($_GET['tips']);
    $gid = intval($_GET['gid']);
    $fid = intval($_GET['fid']);
    $limittime = intval($_GET['limittime']);
    $limitnum = intval($_GET['limitnum']);
    
    if ($fid && $gid && $tips && $limittime && $limitnum) {
        $data = array(
            'fid' => $fid,
            'gid' => $gid,
            'limittime' => $limittime,
            'limitnum' => $limitnum,
            'tips' => $tips
        );
        
        C::t('#apoyl_limit#apoyl_limit')->insert($data);
    }
}
if ($go != 'edit') {
    
    @list ($forumselect, $groupselect) = getGroupForumId();
    showformheader('plugins&operation=config&do=' . $pluginid . '&identifier=apoyl_limit&pmod=admin&go=add&page=' . $page . '&vid=' . $vid);
    showtableheader('');
    showtitle(lang('plugin/apoyl_limit', 'titleadd'));
    showsetting(lang('plugin/apoyl_limit', 'forumname'), '', '', sprintf($forumselect, 'fid'), '', 0, lang('plugin/apoyl_limit', 'forumname_msg'));
    showsetting(lang('plugin/apoyl_limit', 'groupname'), '', '', sprintf($groupselect, 'gid'), '', 0, lang('plugin/apoyl_limit', 'groupname_msg'));
    
    showsetting(lang('plugin/apoyl_limit', 'limittime'), 'limittime', '', 'text', '', 0, lang('plugin/apoyl_limit', 'limittime_msg'));
    showsetting(lang('plugin/apoyl_limit', 'limitnum'), 'limitnum', '', 'text', '', 0, lang('plugin/apoyl_limit', 'limitnum_msg'));
    showsetting(lang('plugin/apoyl_limit', 'tips'), 'tips', '', 'text', '', 0, lang('plugin/apoyl_limit', 'tips_msg'));
    showsubmit('addsubmit', 'submit', '', '', $multipage);
    showtablefooter();/*Dism��taobao��com*/
}

showtableheader();
$prepage = 15;
$start = ($page - 1) * $prepage;
$num = C::t('#apoyl_limit#apoyl_limit')->count();
$multipage = multi($num, $prepage, $page, ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=apoyl_limit&pmod=admin');
$arr = C::t('#apoyl_limit#apoyl_limit')->fetcharr($start, $prepage);
showsubtitle(array(
    lang('plugin/apoyl_limit', 'idname'),
    lang('plugin/apoyl_limit', 'groupname'),
    lang('plugin/apoyl_limit', 'forumname'),
    lang('plugin/apoyl_limit', 'limittime'),
    lang('plugin/apoyl_limit', 'limitnum'),
    lang('plugin/apoyl_limit', 'tips'),
    lang('plugin/apoyl_limit', 'acname')
));
foreach ($arr as $v) {
    loadforum($v['fid']);
    $grow = C::t('common_usergroup')->fetch($v['gid']);
    $edit = '<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=apoyl_limit&pmod=admin&go=edit&page=' . $page . '&vid=' . $v['id'] . '">' . lang('plugin/apoyl_limit', 'edit') . '</a> &nbsp;&nbsp;&nbsp;&nbsp;<a href="' . ADMINSCRIPT . '?action=plugins&operation=config&do=' . $pluginid . '&identifier=apoyl_limit&pmod=admin&go=del&page=' . $page . '&vid=' . $v['id'] . '&formhash=' . formhash() . '" onclick=\'javascript:if(!confirm("' . lang('plugin/apoyl_limit', 'delmsg') . '")){return false}\' >' . lang('plugin/apoyl_limit', 'del') . '</a>';
    showtablerow('', '', array(
        $v['id'],
        $grow['grouptitle'],
        $_G['forum']['name'],
        $v['limittime'],
        $v['limitnum'],
        $v['tips'],
        $edit
    ));
}
showtablefooter();/*Dism��taobao��com*/
echo '<div class="cuspages right">' . $multipage . '</div>';

function getGroupForumId($selectedfid = 0, $selectedgid = 0)
{
    require_once libfile('function/forumlist');
    loadcache('forums');
    $forumselect = "<select name=\"%s\">\n<option value=\"\">&nbsp;&nbsp;> " . cplang('select') . "</option><option value=\"\">&nbsp;</option>" . str_replace('%', '%%', forumselect(FALSE, 0, $selectedfid, TRUE)) . '</select>';
    
    $query = C::t('common_usergroup')->fetch_all_not(array(
        6,
        7
    ), true);
    $groupselect = array();
    foreach ($query as $group) {
        $selected = '';
        $group['type'] = $group['type'] == 'special' && $group['radminid'] ? 'specialadmin' : $group['type'];
        if ($selectedgid == $group['groupid'])
            $selected = 'selected';
        $groupselect[$group['type']] .= "<option value=\"$group[groupid]\" $selected >$group[grouptitle]</option>\n";
    }
    $groupselect = '<optgroup label="' . lang('plugin/apoyl_limit', 'usergroups_member') . '">' . $groupselect['member'] . '</optgroup>' . ($groupselect['special'] ? '<optgroup label="' . lang('plugin/apoyl_limit', 'usergroups_special') . '">' . $groupselect['special'] . '</optgroup>' : '') . ($groupselect['specialadmin'] ? '<optgroup label="' . lang('plugin/apoyl_limit', 'usergroups_specialadmin') . '">' . $groupselect['specialadmin'] . '</optgroup>' : '') . '<optgroup label="' . lang('plugin/apoyl_limit', 'usergroups_system') . '">' . $groupselect['system'] . '</optgroup>';
    $groupselect = "<select name=\"%s\">\n<option value=\"\">&nbsp;&nbsp;> " . cplang('select') . "</option><option value=\"\">&nbsp;</option>" . str_replace('%', '%%', $groupselect) . '</select>';
    
    return array(
        $forumselect,
        $groupselect
    );
}
//From: Dism_taobao-com
?>