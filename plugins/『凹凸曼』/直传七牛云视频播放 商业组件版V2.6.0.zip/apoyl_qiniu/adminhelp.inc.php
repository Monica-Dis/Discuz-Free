<?php
/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: adminhelp.inc.php  2019-09  DisM.Taobao.Com $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
showtableheader();
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_teladv')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_video')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_videolist')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_baidumip')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_rewrite')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_baiduxiong')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_picverify')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_interest')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_limit')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_html5upload')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_service')));

showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_googleping')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_auth')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_weixinshare')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_prize')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_telfunc')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_like')));

showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_facebook')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_google')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_yahoo')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_twitter')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_index')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_vest')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_wmark')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_pushpub')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_hidesection')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_money')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_salary')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_moderator')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_picessence')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','apoyl_picdivision')));

showtablerow('','',array(lang('plugin/apoyl_qiniu','addr')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','blog')));
showtablerow('','',array(lang('plugin/apoyl_qiniu','qq')));
showtablefooter(); /*dism �� taobao �� com*/

?>