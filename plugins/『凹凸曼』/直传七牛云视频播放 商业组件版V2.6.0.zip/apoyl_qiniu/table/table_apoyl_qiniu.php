<?php
/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_apoyl_qiniu.php  2019-09  DisM.Taobao.Com $
 */
if (! defined('IN_DISCUZ')) {
    exit('Acccess Denied');
}

class table_apoyl_qiniu extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'plugin_apoyl_qiniu';
        $this->_pk = 'id';
        parent::__construct(); /*dism��taobao��com*/
    }

    public function fetcharr($start, $limit, $uid = 0,$tid=0, $orderby = 'id desc')
    {
        if ($start == - 1) {
            $limit = 'limit ' . $limit;
        } else {
            $start = empty($start) ? 0 : $start;
            $limit = empty($limit) ? 10 : $limit;
            $limit = 'limit ' . $start . ',' . $limit;
        }
        if ($uid)
            $w = 'WHERE  uid=' . $uid.' AND tid='.$tid;
        
        return DB::fetch_all('SELECT * FROM %t %i order by %i %i', array(
            $this->_table,
            $w,
            $orderby,
            $limit
        ));
    }
    
    public function fetchmusicorvideo($start, $limit, $uid = 0,$tid=0,$mediatype=0, $orderby = 'id desc')
    {
        if ($start == - 1) {
            $limit = 'limit ' . $limit;
        } else {
            $start = empty($start) ? 0 : $start;
            $limit = empty($limit) ? 10 : $limit;
            $limit = 'limit ' . $start . ',' . $limit;
        }
        if ($uid)
            $w = 'WHERE  uid=' . $uid.' AND tid='.$tid.' AND mediatype='.$mediatype;
    
            return DB::fetch_all('SELECT * FROM %t %i order by %i %i', array(
                $this->_table,
                $w,
                $orderby,
                $limit
            ));
    }
    public function deletem($arr){
        
        return DB::delete($this->_table, $arr,0,false);
    }
    public function updatemd5id($val, $data) {
        if(isset($val) && !empty($data) && is_array($data)) {
            $this->checkpk();
            $ret = DB::update($this->_table, $data, DB::field('md5id', $val), $unbuffered, $low_priority);
            foreach((array)$val as $id) {
                $this->update_cache($id, $data);
            }
            return $ret;
        }
        return !$unbuffered ? 0 : false;
    }
}
//From: Dism��taobao��com
?>