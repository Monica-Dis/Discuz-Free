<?php
/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: mbqiniu.class.php  2021-05  DisM.Taobao.Com $
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class mobileplugin_apoyl_qiniu
{
    protected function _fileapoylv2($filename)
    {
        $fileapoyl = DISCUZ_ROOT . './source/plugin/apoyl_qiniu/components/' . $filename . '.php';
        if (file_exists($fileapoyl))
            return $fileapoyl;
            return '';
    }
    protected function _forums()
    {
        global $_G;
        $sforums = unserialize($_G['cache']['plugin']['apoyl_qiniu']['forumlyopas']);
        if (in_array($_G['fid'], $sforums)) {
            return true;
        }
        return false;
    }
    
    protected function _groups()
    {
        global $_G;
        $sgroups = unserialize($_G['cache']['plugin']['apoyl_qiniu']['grouplyopas']);
        if (in_array($_G['groupid'], $sgroups)) {
            return true;
        }
        return false;
    }
    public function discuzcode($value)
    {
       global $_G;
       $cache = $_G['cache']['plugin']['apoyl_qiniu'];
        if ($this->_forums()&&$value['caller'] == 'discuzcode') {
         
            $_G['discuzcodemessage'] = preg_replace_callback('/\[apoyl_qiniu\](\d+)\[\/apoyl_qiniu\]/is', array(
                $this,
                '_callback_apoylvideo'
            ), $_G['discuzcodemessage']);
            include $this->_fileapoylv2('magappshowapoyl');
            include $this->_fileapoylv2('qfappshowapoyl');
            include $this->_fileapoylv2('xyappshowapoyl');
        }
    }

    private function _callback_apoylvideo($match)
    {
        global $_G;
        $return='';
        $cache = $_G['cache']['plugin']['apoyl_qiniu'];
        $row=C::t('#apoyl_qiniu#apoyl_qiniu')->fetch(intval($match[1]));
        if($row['key']){    
            if($row['mediatype']){
                include $this->_fileapoylv2('musicplayapoyl');
                return $return;
            }else{
                $width = $cache['mbwidth'] ? $cache['mbwidth'] : '100%';
                $height = $cache['mbheight'] ? $cache['mbheight'] : 200;
                $httppro=$cache['openhttps']?'https://':'http://';
                $key=$row['key'];
                $tkey=$row['transkey'];
                if($tkey){
                    $key=$tkey;
                }elseif($cache['wmarkname']&&$cache['wmarkpos']){
                    $qiniuid=$row['id'];
                    include $this->_fileapoylv2('wmarkplayapoyl');
                }elseif($cache['opentranscode']){
                    $qiniuid=$row['id'];
                    include $this->_fileapoylv2('transcodeplayapoyl');
                }
                
                $url=$httppro.trim($cache['domain']).'/'.$key;
                $poster=$url.'?vframe/jpg/offset/1';
                if($cache['privatestore']){
                    include $this->_fileapoylv2('privateapoyl');
                }
                if($cache['openmbposter']){
                    include $this->_fileapoylv2('advpostermbapoyl');
                }
                return '<video controls="controls" width="' . $width . '" height="' . $height . '" poster="'.$poster.'"> <source src="' . $url . '">Your browser does not support the video tag</video>';
        
            }
        }
    }
}

class mobileplugin_apoyl_qiniu_forum extends mobileplugin_apoyl_qiniu{
    private function _styleapoyl()
    {
        return '<style>.apoyl_qiniu_video video{margin-left: 2px;}.apoyl_qiniu_clear {clear: both;}</style>';
    }
    

    public function forumdisplay_bottom_mobile_output($a)
    {
        global $_G;
        $cache = $_G['cache']['plugin']['apoyl_qiniu'];
        if (! in_array($_G['fid'], unserialize($cache['forumlyopas'])))
            return '';
        if ($cache['mbforumlist'])
            return $this->_styleapoyl();
        return '';
    }
    public function forumdisplay_thread_mobile_output($a)
    {
        global $_G;
        $data = array();
        $cache = $_G['cache']['plugin']['apoyl_qiniu'];
        if (! in_array($_G['fid'], unserialize($cache['forumlyopas'])))
            return '';
        include $this->_fileapoylv2('mbforumlistapoyl');
    }
    public function post_bottom_mobile_output($a){
        global $_G;
        $return='';
        $cache = $_G['cache']['plugin']['apoyl_qiniu'];
        if($cache['muploadlyopa']&&$this->_forums()&&$this->_groups()){
            $compatibility_one=$cache['compatibility_one'];
            $compatibility_two=$cache['compatibility_two'];
            include template('apoyl_qiniu:mbuploadshow');
        }
        return $return;
    }
    
    public function post_message(){
        global $_G,$tid,$pid;
        $cache = $_G['cache']['plugin']['apoyl_qiniu'];
        if($this->_forums()&&$_G['uid']){
             
            if(($_GET['topicsubmit']&&$_GET['action']=='newthread')||($_GET['editsubmit']&&$_GET['action']=='edit')||($_GET['replysubmit']&&$_GET['action']=='reply')){
                if ($cache['magapply']){
                    include $this->_fileapoylv2('magapppostapoyl');
                }elseif ($cache['qfapply']){
                    include $this->_fileapoylv2('qfapppostapoyl');
                }elseif($cache['xiaoyunply']){
                    include $this->_fileapoylv2('xyapppostapoyl');
                }else{
                    $message=$_GET['message'];
                    $tid=empty($tid)?intval($_GET['tid']):$tid;
                    preg_match_all('/\[apoyl_qiniu\](\d+)\[\/apoyl_qiniu\]/is', $message,$match);
      
                    if(isset($match[1])){
                        C::t('#apoyl_qiniu#apoyl_qiniu')->update($match[1],array('tid'=>$tid,'pid'=>$pid));
                    }
                }
            }
        }
         
    }
}
//From: Dism��taobao��com
?>