<?php
/**
 *      [liyuanchao] (C)2019-2020 http://dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: upgrade.php  2020-03  DisM.Taobao.Com $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$field = C::t('#apoyl_qiniu#apoyl_qiniu')->fetch_all_field();
$table = DB::table('plugin_apoyl_qiniu');
$sql='';


if(!$field['pid']){
    $sql.= <<<EOF
ALTER TABLE $table ADD `pid` mediumint(8) NOT NULL AFTER `tid`;
    
EOF;
}
if(!$field['bucket']){
    $sql.= <<<EOF
ALTER TABLE $table ADD `bucket` varchar(64) NOT NULL AFTER `fsize`;

EOF;
}
if(!$field['transurl']){
    $sql.= <<<EOF
    ALTER TABLE  $table  ADD  `transurl` VARCHAR( 255 ) NOT NULL AFTER  `bucket`;
EOF;
}
if(!$field['coverurl']){
    $sql.= <<<EOF
    ALTER TABLE  $table  ADD  `coverurl` VARCHAR( 255 ) NOT NULL AFTER  `transurl`;
EOF;
}
if(!$field['md5id']){
    $sql.= <<<EOF
    ALTER TABLE  $table  ADD  `md5id` VARCHAR( 64 ) NOT NULL AFTER  `coverurl`;
EOF;
}
if(!$field['transkey']){
    $sql.= <<<EOF
    ALTER TABLE  $table  ADD  `transkey` VARCHAR( 255 ) NOT NULL AFTER  `md5id`;
EOF;
}
if(!$field['insertbeforeplay']){
    $sql.= <<<EOF
ALTER TABLE $table ADD `insertbeforeplay` tinyint(1) NOT NULL DEFAULT '0' AFTER `transkey`;
EOF;
}   
    
if(!$field['mediatype']){
    $sql.= <<<EOF
    ALTER TABLE  $table  ADD  `mediatype` tinyint(1) NOT NULL AFTER  `key`;
EOF;
}
if($sql) runquery($sql);
$finish = TRUE;
?>