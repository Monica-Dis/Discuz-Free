<?php
/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: uninstall.php  2019-09  DisM.Taobao.Com $
 */
 
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
$sql = <<<EOF
    DROP TABLE IF EXISTS `pre_plugin_apoyl_qiniu`;
EOF;
	runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/apoyl_qiniu/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/apoyl_qiniu/discuz_plugin_apoyl_qiniu.xml');
@unlink(DISCUZ_ROOT . './source/plugin/apoyl_qiniu/discuz_plugin_apoyl_qiniu_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/apoyl_qiniu/discuz_plugin_apoyl_qiniu_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/apoyl_qiniu/discuz_plugin_apoyl_qiniu_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/apoyl_qiniu/discuz_plugin_apoyl_qiniu_TC_UTF8.xml');
$finish = TRUE;
?>