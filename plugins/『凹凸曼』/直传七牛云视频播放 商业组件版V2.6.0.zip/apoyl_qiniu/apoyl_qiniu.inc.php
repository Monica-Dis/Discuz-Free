<?php
/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: apoyl_qiniu.inc.php  2021-07  DisM.Taobao.Com $
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;

$cache = $_G['cache']['plugin']['apoyl_qiniu'];
if (! $_G['uid']) {
    echo 'login error!';
    exit();
}
if ($_GET['formhash'] != FORMHASH) {
    echo 'formhash error!';
    exit();
}
if (!in_array($_G['groupid'], unserialize($cache['grouplyopas']))) {

    echo 'group error!';
    exit();
}
$ac = $_GET['ac'];
if ($ac == 'show') {
    $autoinsertimg=$cache['autoinsertimg'];
    $charset=$_G['charset'];
    $limitup = $cache['limitup'] ? ($cache['limitup']<1024?$cache['limitup']:1024): 1024;
    $qiniulimit=str_replace('{limit}',$limitup,lang('plugin/apoyl_qiniu','qiniulimit'));
    
    $url = 'plugin.php?id=apoyl_qiniu&ac=uptoken&formhash=' . FORMHASH;
    
    $region = regionapoyl($cache['storelist']);
    
    $gurl = 'plugin.php?id=apoyl_qiniu&ac=pullvideo&formhash=' . FORMHASH;
    $iurl = 'plugin.php?id=apoyl_qiniu&ac=add&formhash=' . FORMHASH;
    $delurl= 'plugin.php?id=apoyl_qiniu&ac=del&formhash=' . FORMHASH;
    $arr=C::t('#apoyl_qiniu#apoyl_qiniu')->fetcharr(0, 50, $_G['uid']);
    if($cache['opentranscode']){
        $videotype='.mp4,.webm,.flv,.mov,.3gp,.avi,.mpg,.mkv,.wmv';
        $videotypetips='MP4,MOV,WebM,3GP,AVI,FLV,MPG,WMV,MKV';
    }else{
        $videotype='video/mp4,video/webm';
        $videotypetips='MP4,WEBM';
    }

    include _fileapoylv2('musicincapoyl');
    if(_fileapoylv2('magappshowapoyl')&&$cache['magapply']){
        $transflag=false;
        if($cache['wmarkname']&&$cache['wmarkpos']&&!$cache['insertbeforeplay'])
            $transflag=true;
            include template('apoyl_qiniu:magappshowlyopa');
    }elseif(_fileapoylv2('qfappshowapoyl')&&$cache['qfapply']){ 
        $transflag=false;
        if($cache['wmarkname']&&$cache['wmarkpos'])
            $transflag=true;
        include template('apoyl_qiniu:qfappshowlyopa');
    }elseif($cache['xiaoyunply']&&_fileapoylv2('xyappshowapoyl')){ 
        $transflag=false;
        if($cache['wmarkname']&&$cache['wmarkpos'])
            $transflag=true;
        include template('apoyl_qiniu:xyappshowlyopa');
    }else{
        include template('apoyl_qiniu:showlyopa');
    }
} elseif ($ac == 'uptoken') {
    require_once dirname(__FILE__) . '/api/qiniu/uptoken.php';
} elseif ($ac == 'add') {
    $hash = dhtmlspecialchars($_GET['hash']);
    $name = dhtmlspecialchars($_GET['name']);
    $key = dhtmlspecialchars($_GET['key']);
    $bucket=dhtmlspecialchars($_GET['bucket']);
    $fsize=intval($_GET['fsize']);
    $type = dhtmlspecialchars($_GET['type']);
    $mediatype=0;
    $transkey='';
    if(strpos($type,'audio')!==false){
        $mediatype=1;
        if(stripos($key,'mp3')===false)
            $transkey='wm'.str_replace(array('aac','wav','wma'),'mp3',$key);
 
    }
    if ($hash && $name) {
        $data = array(
            'uid' => $_G['uid'],
            'name' => $name,
            'key' => $key,
            'mediatype'=>$mediatype,
            'hash' => $hash,
            'fsize' => $fsize,
            'bucket'=>$bucket,
            'transkey'=>$transkey,
            'addtime' => TIMESTAMP
        )
        ;
        $re = C::t('#apoyl_qiniu#apoyl_qiniu')->insert($data, true);
        if ($re) {
            if($mediatype&&$cache['openmusic']){
                include _fileapoylv2('musicavthumb');
            }
            if ($cache['wmarkname']&&$cache['wmarkpos']){
                include _fileapoylv2('wmarkapoyl');
            }elseif($cache['opentranscode']){
                include _fileapoylv2('transcodeapoyl');
            }
            echo $re;
            exit();
        } else {
            echo 'fail';
            exit();
        }
    }
}elseif ($ac=='del'){
    $qiniuid=intval($_GET['qiniuid']);
    $row=C::t('#apoyl_qiniu#apoyl_qiniu')->fetch($qiniuid);
    if(!$row){
        echo 'delfail';exit;
    }
    $delf=C::t('#apoyl_qiniu#apoyl_qiniu')->deletem(array('id'=>$qiniuid,'uid'=>$_G['uid']));
    if($delf){
        if($row['key']){
            require_once dirname(__FILE__) . '/api/qiniu/LyopaCom.php';
            $lyopa=new LyopaCom($cache);
            $lyopa->delVideo($row['bucket'],$row['key']);
            if($row['transkey']){
                $lyopa->delVideo($row['bucket'],$row['transkey']);
            }
        }
        echo 'delsuccess';exit;
    }else{
        echo 'delfail';exit;
    }
        
}elseif($ac=='mbupload'){

    include _fileapoylv2('mbuploadapoyl');
}elseif($ac=='pullvideo'){
    if($cache['magapply']){
        include _fileapoylv2('magappincapoyl');
    }elseif($cache['qfapply']){
        include _fileapoylv2('qfappincapoyl');
    }elseif($cache['xiaoyunply']){
        include _fileapoylv2('xyappincapoyl');
    }elseif($cache['autoinsertimg']){
        include _fileapoylv2('autoinsertimgincapoyl');
    }elseif($cache['mbautoinsertimg']){
        include _fileapoylv2('autoinsertimgincmbapoyl');
    }
}

function _fileapoylv2($filename)
{
    $fileapoyl = DISCUZ_ROOT . './source/plugin/apoyl_qiniu/components/' . $filename . '.php';
    if (file_exists($fileapoyl))
        return $fileapoyl;
        return '';
}

function regionapoyl($region)
{
    switch ($region) {
        case 1:
            $re = 'qiniu.region.z0';break;
        case 2:
            $re = 'qiniu.region.z1';break;
        case 3:
            $re = 'qiniu.region.z2';break;
        case 4:
            $re = 'qiniu.region.na0';break;
        case 5:
            $re = 'qiniu.region.as0';break;
    }
    return $re;
}
//From: Dism��taobao��com
?>