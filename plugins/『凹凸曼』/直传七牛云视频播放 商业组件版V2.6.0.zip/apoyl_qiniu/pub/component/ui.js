(function() {
  var initapoylqiniu = function(obj) {
    var li_children =
      "<div id='childBar' style='width:10px;height:20px;border:1px solid;border-radius:3px'>" +
      "<div id='childBarColor' style='width:0;border:0;background-color:rgba(250,59,127,0.8);height:18px;'>" +
      "</div>" +
      "</div>";
    var li = document.createElement("li");
    apoyl_qiniu_jq(li).addClass("fragment");
    apoyl_qiniu_jq(li).html(li_children);
    obj.node.append(li);
  };
  widgetapoylqiniu.register("li", {
    init: initapoylqiniu
  });
})();

(function() {
  var initapoylqiniu = function(obj) {
    var data = obj.data;
    var name = data.name;
    var size = data.size;
    var parent =
      "<td><a href='javascript:;' class='apoyl_qiniu_name' title='"+name+"'><img src='static/image/common/attachmediacode.gif' width='21' style='vertical-align: middle;'/>" +
      name +
      "</a><div class='wraper'><a class='linkWrapper'></a></div>" +
      "</td>" +
      "<td>" +
      size +
      " MB</td>" +
      "<td style='padding-top:5px;padding-bottom:5px;width:35%'><div><div id='totalBar' style='float:left;width:98%;height:30px;border:1px solid;border-radius:3px'>" +
      "<div id='totalBarColor' style='width:0;border:0;background-color:rgba(232,152,39,0.8);height:28px;'></div>" +
      "<p class='apoyl_qiniu_speed'></p>" +
      "</div>" +
      "<div class='control-container'>" +
      ' <button class="btn btn-default control-upload">开始上传</button>' +
      "</div></div>" +

      "</td>"+
      '<td class="attc"><a href="javascript:;" class="d apoyl_qiniu_qiniudel"  title="删除">删除</a></td>';
    var tr = document.createElement("tr");
    apoyl_qiniu_jq(tr).html(parent);
    obj.node.append(tr);
    for (var i = 0; i < data.num; i++) {
      widgetapoylqiniu.add("li", {
        data: "",
        node: apoyl_qiniu_jq(tr).find(".fragment-group")
      });
    }
    apoyl_qiniu_jq(tr)
    .find(".apoyl_qiniu_qiniudel")
    .on("click", function(e) {
    	apoyl_qiniu_jq(tr).remove();
  	  
    });

    
    return tr;
  };
  widgetapoylqiniu.register("tr", {
    init: initapoylqiniu
  });
})();
