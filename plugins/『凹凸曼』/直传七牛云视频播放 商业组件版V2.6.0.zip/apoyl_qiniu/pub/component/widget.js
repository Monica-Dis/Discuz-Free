(function(global) {
  function widgetapoylqiniu() {
    this.widget = {};
  }

  widgetapoylqiniu.prototype.register = function(name, component) {
    this.widget[name] = component;
  };
  widgetapoylqiniu.prototype.add = function(name, obj) {
    if (this.widget[name]) {
      this.widget[name].node = obj.node;
      return this.widget[name].init(obj);
    }
    return false;
  };
  global.widgetapoylqiniu = new widgetapoylqiniu();
})(window);
