
function qiniu_insertlyopa(id) {

	var txt = '[apoyl_qiniu]' + id + '[/apoyl_qiniu]';
	if(wysiwyg) {
		insertText(txt, false);
	} else {
		insertText(txt, strlen(txt), 0);
	}
}	
function qiniu_status_err(code) {
	var msg = '';
	switch (code) {
	case 298:
		msg = '部分操作执行成功。';
		break;
	case 400:
		msg = '请求报文格式错误。包括上传时，上传表单格式错误；URL 触发图片处理时，处理参数错误；[资源管理][rsHref] 或 持久化数据处理 (pfop) 操作请求格式错误。';
		break;
	case 401:
		msg = '认证授权失败。 包括密钥信息不正确；数字签名错误；授权已超时。';
		break;
	case 403:
		msg = 'token中的key和put方法的key不一致;mimelimit类型限制;fsizelimit大小限制';
		break;
	case 404:
		msg = '资源不存在。 包括空间资源不存在；镜像源资源不存在。';
		break;
	case 405:
		msg = '请求方式错误。 主要指非预期的请求方式。';
		break;
	case 406:
		msg = '上传的数据 CRC32 校验错误。';
		break;
	case 419:
		msg = '用户账号被冻结。';
		break;
	case 478:
		msg = '镜像回源失败。 主要指镜像源服务器出现异常。';
		break;
	case 503:
		msg = '服务端不可用。';
		break;
	case 504:
		msg = '服务端操作超时。';
		break;
	case 573:
		msg = '单个资源访问频率过高';
		break;
	case 579:
		msg = '上传成功但是回调失败。 包括业务服务器异常；七牛服务器异常；服务器间网络异常。';
		break;
	case 599:
		msg = '服务端操作失败。';
		break;
	case 608:
		msg = '资源内容被修改。';
		break;
	case 612:
		msg = '指定资源不存在或已被删除。';
		break;
	case 614:
		msg = '目标资源已存在。';
		break;
	case 630:
		msg = '已创建的空间数量达到上限，无法创建新空间。';
		break;
	case 631:
		msg = '指定空间不存在。';
		break;
	case 640:
		msg = '调用列举资源 (list) 接口时，指定非法的marker参数。';
		break;
	case 701:
		msg = '在断点续上传过程中，后续上传接收地址不正确或ctx信息已过期。';
		break;
	
	}
	return msg;
}