<?php
/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php  2020-03  DisM.Taobao.Com $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE `pre_plugin_apoyl_qiniu` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `tid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `pid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `uid` mediumint(8) unsigned NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `key` varchar(255) NOT NULL DEFAULT '',
  `mediatype` tinyint(1) NOT NULL DEFAULT '0',
  `hash` varchar(32) NOT NULL DEFAULT '',
  `fsize` bigint(20) unsigned NOT NULL DEFAULT '0',
  `bucket` varchar(64) NOT NULL DEFAULT '',
  `transurl` varchar(255) NOT NULL DEFAULT '',       
  `coverurl` varchar(255) NOT NULL DEFAULT '',     
  `md5id` varchar(64) NOT NULL DEFAULT '',
  `transkey` varchar(255) NOT NULL DEFAULT '',
  `insertbeforeplay` tinyint(1) NOT NULL DEFAULT '0',
  `addtime` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `uid` (`uid`,`tid`),
  KEY `md5id` (`md5id`)
) ENGINE=MyISAM;

EOF;
runquery($sql);

$finish = TRUE;
?>