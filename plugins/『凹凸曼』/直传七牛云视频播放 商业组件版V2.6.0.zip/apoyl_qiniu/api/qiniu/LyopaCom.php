<?php
/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: LyopaCom.php  2019-12  DisM.Taobao.Com $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once  'autoload.php';
use Qiniu\Auth;
class LyopaCom{
    public function __construct($cache){
        $this->cache=$cache;
    }
    public function delVideo($bucket,$key){
        $accessKey = $this->cache['accesskey'];
        $secretKey = $this->cache['secretkey'];

        try{
            $auth = new Auth($accessKey, $secretKey);
            $config = new \Qiniu\Config();
            $bucketManager = new \Qiniu\Storage\BucketManager($auth, $config);
            $bucketManager->delete($bucket, $key);
        }catch (Exception $e){
            return '';
        }
    }
}
//From: Dism��taobao��com
?>