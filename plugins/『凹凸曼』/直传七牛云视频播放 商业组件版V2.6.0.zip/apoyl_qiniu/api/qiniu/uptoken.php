<?php
/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: qiniu.class.php  2019-09  DisM.Taobao.Com $
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
require_once  'autoload.php';
use Qiniu\Auth;
header('Access-Control-Allow-Origin:*');
$cache = $_G['cache']['plugin']['apoyl_qiniu'];
$bucket = trim($cache['spacelyopa']);
$accessKey = trim($cache['accesskey']);
$secretKey = trim($cache['secretkey']);
$auth = new Auth($accessKey, $secretKey);
$policy = array(
    'returnUrl' => '',
    'returnBody' => '{"fname": $(fname),"key":$(key),"fsize":$(fsize),"bucket":"$(bucket)","hash":$(etag),"w":$(imageInfo.width),"h":$(imageInfo.height)}',
);
$upToken = $auth->uploadToken($bucket, null, 3600, $policy);
$httppro=$cache['openhttps']?'https://':'http://';
$upToken_arr = array('uptoken'=>$upToken,'domain'=>$httppro.$cache['domain']);
$upToken_arr = json_encode($upToken_arr);
echo $upToken_arr;
?>