<?php
/**
 *      Copyright (c) 2021 by dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: autoload.php  2019-09  DisM.Taobao.Com $
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (version_compare(PHP_VERSION, '5.3.0', '<')) {
    throw new Exception('The Qiniu SDK requires PHP version 5.3 or higher.');
}

function classLoader($class)
{
    $path = str_replace('\\', DIRECTORY_SEPARATOR, $class);
    $file = __DIR__ . '/src/' . $path . '.php';

    if (file_exists($file)) {
        require_once $file;
    }
}
spl_autoload_register('classLoader',false,true);

require_once  __DIR__ . '/src/Qiniu/functions.php';
?>