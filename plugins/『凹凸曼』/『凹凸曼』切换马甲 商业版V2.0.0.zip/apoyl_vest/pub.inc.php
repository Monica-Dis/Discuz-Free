<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: pub.inc.php  2020-06  DISM-TAOBAO-COM $
 */
if (! defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$apoylc = $_GET['c'];
$ac = $_GET['ac'];
$curuid = $_G['uid'];

$config = changeC($_GET['c']);

if ($config) {
    $apoylconfig = $_G['cache']['plugin']['apoyl_vest'][$config];
    $list = explapoyl($apoylconfig, $_G['uid']);
}
if ($ac == 'index') {
    $dcheck = $_G['cache']['plugin']['apoyl_vest']['dcheck'];
    $opencstr = $_G['cache']['plugin']['apoyl_vest']['opencstr'];
    $opensearch = $_G['cache']['plugin']['apoyl_vest']['opensearch'];
    if ($list && in_array($curuid, $list))
        $mlist = C::t('common_member')->fetch_all($list);
    unset($mlist[$curuid]);
    include template('apoyl_vest:pub');
} elseif ($ac == 'mod' && submitcheck('ac')) {
    $uid = intval($_GET['uid']);
    if (! in_array($curuid, $list))
        showmessage(lang('plugin/apoyl_vest', 'nop'));
    if ($uid == $curuid)
        showmessage(lang('plugin/apoyl_vest', 'curuser'));
    if (! in_array($uid, $list))
        showmessage(lang('plugin/apoyl_vest', 'norange'));
    
    $member = C::t('common_member')->fetch($uid);
    if (! $member)
        showmessage(lang('plugin/apoyl_vest', 'nouser'));
    
    require_once libfile('function/member');
    setloginstatus($member, 2592000);
    
    loaducenter();
    $ucsynlogin = $_G['setting']['allowsynlogin'] ? uc_user_synlogin($uid) : '';
    C::t('common_member_status')->update($uid, array(
        'lastip' => $_G['clientip'],
        'lastvisit' => $_G['timestamp'],
        'lastactivity' => $_G['timestamp']
    ));
    $refere = dreferer();
    dheader("location:$refere");
} else {
    showmessage(lang('plugin/apoyl_vest', 'error'));
}

function explapoyl($str, $uid)
{
    $list = array();
    $arr = explode(',', $str);
    if (! $arr)
        return $list;
    foreach ($arr as $v) {
        $a = intval($v);
        if ($a > 0)
            $list[$a] = $a;
    }
    return $list;
}

function changeC($c)
{
    switch ($c) {
        case 'a':
            return 'apoylconfiga';
        case 'b':
            return 'apoylconfigb';
        case 'c':
            return 'apoylconfigc';
        case 'd':
            return 'apoylconfigd';
        case 'e':
            return 'apoylconfige';
        case 'f':
            return 'apoylconfigf';
        case 'g':
            return 'apoylconfigg';
        case 'h':
            return 'apoylconfigh';
        case 'y':
            return 'apoylconfigy';
        case 'j':
            return 'apoylconfigj';
    }
    return '';
}
?>