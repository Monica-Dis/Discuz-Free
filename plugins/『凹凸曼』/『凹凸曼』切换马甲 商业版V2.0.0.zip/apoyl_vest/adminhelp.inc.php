<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: adminhelp.inc.php  2020-02  DISM-TAOBAO-COM $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
showtableheader();
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_fullwmark')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_aliyunvideo')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_qiniu')));

showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_videolist')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_baidumip')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_baiduxiong')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_limit')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_html5upload')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_service')));

showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_rewrite')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_pushpub')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_facebook')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_yahoo')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_twitter')));

showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_teladv')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_index')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_listbigimg')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_wmark')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_hidesection')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_money')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_telbigimg')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_salary')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_moderator')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_mtime')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_picessence')));
showtablerow('','',array(lang('plugin/apoyl_vest','apoyl_picdivision')));

showtablerow('','',array(lang('plugin/apoyl_vest','addr')));
showtablerow('','',array(lang('plugin/apoyl_vest','blog')));
showtablerow('','',array(lang('plugin/apoyl_vest','qq')));
showtablefooter(); /*Dism��taobao��com*/

?>