<?php
/**
 *      [DisM!] (C)2019-2020 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: vest.class.php  2020-02  DISM-TAOBAO-COM $
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}

class plugin_apoyl_vest {

    private function _display($n){
        global $_G;
        $re='';
        $apoylconfig=$_G['cache']['plugin']['apoyl_vest'];
        if(!$apoylconfig['pcopen']) return $re;
        if(!in_array($n,unserialize($apoylconfig['pcdisp'])))
            return $re;
        $uid=$_G['uid'];
        if(!$uid) return $re;
        $ismy=$this->_e($apoylconfig, $uid);
      
        if($ismy)
            $re=$this->_outtip($ismy,$n);
        return $re;
    }
    public function global_footer(){
        return $this->_display(2);
    }
    public function global_usernav_extra1(){
		return $this->_display(1);
	}

    private function _outtip($c,$n=1){
	    $s=' <a id="apoylvestwin"  href="plugin.php?id=apoyl_vest:pub&ac=index&c='.$c.'" onclick="showWindow(\'apoylvestwin\',this.href);">'.lang('plugin/apoyl_vest','title').'</a> ';
	    if($n==2){
	        $s='<div style="text-align:center;margin-bottom:10px;">'.$s.'</div>';
	    }
	    return $s;
	}
    private function _e($apoylconfig,$uid){
        for($i=96;$i<=106;$i++){
            if($this->_exp($apoylconfig,$uid,chr($i))){
                return chr($i);
            }
        }
            
        return false;
    }
    private  function _exp($apoylconfig,$uid,$f){
        $arr=explode(",",$apoylconfig['apoylconfig'.$f]);
        if(in_array($uid, $arr)){
            return true;
        }
        return false;
    }

}

?>