<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: ApoylSitemap.class.php  2019-11 liyuanchao $
 */
if (! defined('IN_DISCUZ')) {
    exit("Access Denied");
}
require DISCUZ_ROOT . './source/plugin/apoyl_sitemap/class/ApoylDataSet.class.php';
class ApoylSitemap
{

    private $cache = null;

    private $data = null;

    private $siteurl = '';

    private $order = array(
        1 => 'index',
        2 => 'forum',
        3 => 'thread',
        4 => 'category',
        5 => 'article',
        6 => 'group',
        7 => 'gthread'
    );

    private $urls = array();

    public function __construct($cache, $siteurl)
    {
        $this->cache = $cache;
        $this->siteurl = $this->https($siteurl);
        $this->data = new ApoylDataSet();
    }

    private function getOrder()
    {
        $arr = explode(',', $this->cache['openorder']);
        if (count($arr) != 7)
            return $this->order;
        $re = array();
        foreach ($arr as $v) {
            $re[] = $this->order[$v];
        }
        return $re;
    }

    private function getThreadOrder()
    {
        $n = $this->cache['threadsorder'];
        switch ($n) {
            case 1:
                return array(
                    'lastpost',
                    'DESC'
                );
                break;
            case 2:
                return array(
                    'lastpost',
                    'ASC'
                );
                break;
            case 3:
                return array(
                    'dateline',
                    'DESC'
                );
                break;
            case 4:
                return array(
                    'dateline',
                    'ASC'
                );
                break;
            case 5:
                return array(
                    'replies',
                    'DESC'
                );
                break;
            case 6:
                return array(
                    'replies',
                    'ASC'
                );
                break;
            case 7:
                return array(
                    'views',
                    'DESC'
                );
                break;
            case 8:
                return array(
                    'views',
                    'ASC'
                );
                break;
        }
    }

    private function total()
    {
        $arr = unserialize($this->cache['urls']);
        $totalarray = array();
        
        if ($arr) {
            foreach ($arr as $v) {
                switch ($v) {
                    case 1:
                        $totalarray['indextotal'] = 1;
                        $total += 1;
                        break;
                    case 2:
                        $forumtotal = $this->data->forumTotal();
                        $totalarray['forumtotal'] = $forumtotal;
                        $total += $forumtotal;
                        break;
                    case 3:
                        $threadtotal = $this->data->threadTotal();
                        $totalarray['threadtotal'] = $threadtotal;
                        $total += $threadtotal;
                        break;
                    case 4:
                        $categorytotal = $this->data->categoryTotal();
                        $totalarray['categorytotal'] = $categorytotal;
                        $total += $categorytotal;
                        break;
                    case 5:
                        $articletotal = $this->data->articleTotal();
                        $totalarray['articletotal'] = $articletotal;
                        $total += $articletotal;
                        break;
                    case 6:
                        $grouptotal = $this->data->groupTotal();
                        $totalarray['grouptotal'] = $grouptotal;
                        $total += $grouptotal;
                        break;
                    case 7:
                        $gthreadtotal = $this->data->gthreadTotal();
                        $totalarray['gthreadtotal'] = $gthreadtotal;
                        $total += $gthreadtotal;
                        break;
                }
                $totalarray['total'] = $total;
            }
        }
        return $totalarray;
    }

    private function priRand($num)
    {
        if (strpos($num, '~') === FALSE)
            return $num;
        $a = explode('~', $num);
        
        return rand($a[0] * 10, $a[1] * 10) / 10;
    }

    private function index($start, $count, &$num)
    {
        $num ++;
        return $this->urlStr($this->siteurl, date('Y-m-d', time()), $this->priRand($this->cache['indexlevel']));
    }

    private function https($url)
    {
        if ($this->cache['openhttps']) {
            return str_replace('http://', 'https://', $url);
        }
        return $url;
    }

    private function rewrite($type, $id, $foldername = '')
    {
        if ($this->cache['openrewrite']) {
            if ($type == 'portal_category') {
                if($foldername)
                    $url = $this->siteurl . $foldername . '/';
                else 
                    $url = $this->siteurl . 'portal.php?mod=list&catid=' . $id;
            } else {
                $url = rewriteoutput($type, 1, $this->siteurl, $id);
            }
        } else {
            if ($type == 'forum_forumdisplay') {
                $url = $this->siteurl . 'forum.php?mod=forumdisplay&fid=' . $id;
            } elseif ($type == 'forum_viewthread') {
                $url = $this->siteurl . 'forum.php?mod=viewthread&tid=' . $id;
            } elseif ($type == 'group_group') {
                $url = $this->siteurl . 'forum.php?mod=group&fid=' . $id;
            } elseif ($type == 'portal_category') {
                $url = $this->siteurl . 'portal.php?mod=list&catid=' . $id;
            } elseif ($type == 'portal_article') {
                $url = $this->siteurl . 'portal.php?mod=view&aid=' . $id;
            }
        }
        return $url;
    }

    private function forum($start, $count, &$num)
    {
        $str = '';
        $arr = $this->data->forumData($start, $count);
        if (! $arr)
            return $str;
        $num = $num + count($arr);
        foreach ($arr as $v) {
            $str .= $this->urlStr($this->rewrite('forum_forumdisplay', $v['fid']), date('Y-m-d', time()), $this->priRand($this->cache['forumlevel']));
        }
        
        return $str;
    }

    private function thread($start, $count, &$num)
    {
        $str = '';
        @list ($field, $order) = $this->getThreadOrder();
        $arr = $this->data->threadData($field, $order, $start, $count);
        if (! $arr)
            return $str;
        $num = $num + count($arr);
        foreach ($arr as $v) {
            $str .= $this->urlStr($this->rewrite('forum_viewthread', $v['tid']), date('Y-m-d', $v['dateline']), $this->priRand($this->cache['threadlevel']));
        }
        
        return $str;
    }

    private function category($start, $count, &$num)
    {
        $str = '';
        $arr = $this->data->categoryData($start, $count);
        if (! $arr)
            return $str;
        $num = $num + count($arr);
        foreach ($arr as $v) {
            $str .= $this->urlStr($this->rewrite('portal_category', $v['catid'], $v['foldername']), date('Y-m-d', $v['dateline']), $this->priRand($this->cache['categorylevel']));
        }
        
        return $str;
    }

    private function article($start, $count, &$num)
    {
        $str = '';
        $arr = $this->data->articleData($start, $count);
        if (! $arr)
            return $str;
        $num = $num + count($arr);
        foreach ($arr as $v) {
            $str .= $this->urlStr($this->rewrite('portal_article', $v['aid']), date('Y-m-d', $v['dateline']), $this->priRand($this->cache['artclelevel']));
        }
        return $str;
    }

    private function group($start, $count, &$num)
    {
        $str = '';
        $arr = $this->data->groupData($start, $count);
        if (! $arr)
            return $str;
        $num = $num + count($arr);
        foreach ($arr as $v) {
            $str .= $this->urlStr($this->rewrite('group_group', $v['fid']), date('Y-m-d', time()), $this->priRand($this->cache['grouplevel']));
        }
        return $str;
    }

    private function gthread($start, $count, &$num)
    {
        $str = '';
        @list ($field, $order) = $this->getThreadOrder();
        $arr = $this->data->gthreadData($field, $order, $start, $count);
        if (! $arr)
            return $str;
        $num = $num + count($arr);
        foreach ($arr as $v) {
            $str .= $this->urlStr($this->rewrite('forum_viewthread', $v['tid']), date('Y-m-d', $v['dateline']), $this->priRand($this->cache['grouplevel']));
        }
        
        return $str;
    }

    private function writeXml($content, $filename)
    {
        $fp = fopen(DISCUZ_ROOT . '/' . $filename . '.xml', 'w');
        fwrite($fp, $content);
        fclose($fp);
    }
    private function writeTxt($content, $filename)
    {
        $fp = fopen(DISCUZ_ROOT . '/' . $filename . '.txt', 'w');
        fwrite($fp, $content);
        fclose($fp);
    }
    private function writeFile($content,$filename){
        $this->writeXml($content, $filename);
        if($this->cache['addtxt']){
            preg_match_all('/\<loc\>([^\<]+?)\<\/loc\>/is',$content,$arr);
            if(isset($arr[1])){
                $urls='';
                foreach ($arr[1] as $v){
                    $urls .= $v . chr(13) . chr(10);
                }
            $this->writeTxt($urls, $filename);
            }
        }
    }
    public function saveXml()
    {
        $totalarr = $this->total();
        if (! $totalarr)
            return false;
        $o = $this->getOrder();
        $neworderarr = array();
        foreach ($o as $v) {
            if (isset($totalarr[$v . 'total']))
                $neworderarr[$v] = $totalarr[$v . 'total'];
        }
        
        $limit = intval($this->cache['urlnums']);
        if ($limit <= 0)
            $limit = 50000;
        $c = ceil($totalarr['total'] / $limit);
        $tstart = 0;
        
        for ($j = 1; $j <= $c; $j ++) {
            $num = 0;
            $start = $tstart;
            $str = '';
            foreach ($neworderarr as $k => $count) {
                
                $newnum = $num;
                $newcount = $count;
                if ($limit - $num - $count < 0) {
                    $newcount = $limit - $num;
                }
                
                $str .= call_user_func_array(array(
                    $this,
                    $k
                ), array(
                    $start,
                    $newcount,
                    &$num
                ));
                if (($count <= $newcount || $count - $start <= $limit) && $num < $limit) {
                    unset($neworderarr[$k]);
                    $tstart = $start = 0;
                }
                if ($num == $limit) {
                    $num = 0;
                    $filename = 'sitemap_' . $j;
              
                    $this->writeFile($this->compStructure($str), $filename);
                    if ($count - $start > 0) {
                        $tstart = $tstart + ($limit - $newnum);
                    }
                    break;
                }
            }
        }
        $j = $j - 1;
        if ($num > 0) {
            $filename = 'sitemap_' . $j;
            $this->writeFile($this->compStructure($str), $filename);
        }
        $this->saveIndexXml($j);
    }

    private function compStructure($s)
    {
        $str = '<?xml version="1.0" encoding="UTF-8"?>' . chr(13) . chr(10);
        $str .= '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . chr(13) . chr(10);
        $str .= $s;
        $str .= '</urlset>' . chr(13) . chr(10);
        return $str;
    }

    private function urlStr($url, $dateline, $pri)
    {
        $str .= '<url>' . chr(13) . chr(10);
        $str .= '<loc>' . dhtmlspecialchars($url) . '</loc>' . chr(13) . chr(10);
        $str .= '<lastmod>' . $dateline . '</lastmod>' . chr(13) . chr(10);
        $str .= '<changefreq>always</changefreq>' . chr(13) . chr(10);
        $str .= '<priority>' . $pri . '</priority>' . chr(13) . chr(10);
        $str .= '</url>' . chr(13) . chr(10);
        return $str;
    }

    private function saveIndexXml($j)
    {
        if (! $this->cache['sitemapindex'])
            return false;
        $str = '<?xml version="1.0" encoding="UTF-8"?>' . chr(13) . chr(10);
        $str .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">' . chr(13) . chr(10);
        for ($i = 1; $i <= $j; $i ++) {
            $str .= '<sitemap>' . chr(13) . chr(10);
            $str .= '<loc>'.$this->siteurl . 'sitemap_' . $i . '.xml</loc>' . chr(13) . chr(10);
            $str .= '<lastmod>' . date('Y-m-d', time()) . '</lastmod>' . chr(13) . chr(10);
            $str .= '</sitemap>' . chr(13) . chr(10);
        }
        $str .= '</sitemapindex>' . chr(13) . chr(10);
        $this->writeXml($str, 'sitemap_index');
    }
}
//From: Dism��taobao��com
?>