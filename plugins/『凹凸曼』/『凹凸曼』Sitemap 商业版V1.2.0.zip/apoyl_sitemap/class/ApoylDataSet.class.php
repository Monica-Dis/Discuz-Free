<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: ApoylSitemap.class.php  2019-04 liyuanchao $
 */
if (! defined('IN_DISCUZ')) {
    exit("Access Denied");
}
class ApoylDataSet
{

    public function forumData($start, $limit)
    {
        $arr = DB::fetch_all("SELECT fid FROM " . DB::table('forum_forum') . " WHERE type in('sub','forum') and status=1 order by fid asc " . DB::limit($start, $limit));
        return $arr;
    }

    public function forumTotal()
    {
        $total = DB::result_first("SELECT count(fid) FROM " . DB::table('forum_forum') . " WHERE type in('forum','sub') and status=1");
        return $total;
    }

    public function threadData($field, $order = 'ASC', $start, $limit)
    {
        $arr = DB::fetch_all('SELECT tid,dateline FROM ' . DB::table('forum_thread') . ' WHERE displayorder>=0  and isgroup=0  ORDER BY ' . DB::order($field, $order) . DB::limit($start, $limit));
        return $arr;
    }

    public function threadTotal()
    {
        $total = DB::result_first('SELECT COUNT(tid) FROM ' . DB::table('forum_thread') . ' WHERE displayorder>=0 and isgroup=0');
        return $total;
    }

    public function groupData($start, $limit)
    {
        $arr = DB::fetch_all("SELECT fid FROM " . DB::table('forum_forum') . " WHERE type in('sub') and status=3 order by fid asc " . DB::limit($start, $limit));
    }

    public function groupTotal()
    {
        $total = DB::result_first("SELECT count(fid) FROM " . DB::table('forum_forum') . " WHERE type in('sub') and status=3");
        return $total;
    }

    public function gthreadData($field, $order = 'ASC', $start, $limit)
    {
        $arr = DB::fetch_all('SELECT tid,dateline FROM ' . DB::table('forum_thread') . ' WHERE displayorder>=0  and isgroup=1 ORDER BY ' . DB::order($field, $order) . DB::limit($start, $limit));
        return $arr;
    }

    public function gthreadTotal()
    {
        $total = DB::result_first('SELECT COUNT(tid) FROM ' . DB::table('forum_thread') . ' WHERE displayorder>=0 and isgroup=1');
        return $total;
    }

    public function articleData($start, $limit)
    {
        $arr = DB::fetch_all('SELECT aid,dateline FROM ' . DB::table('portal_article_title') . ' WHERE status=0 ' . DB::limit($start, $limit));
        return $arr;
    }

    public function articleTotal()
    {
        $total = DB::result_first('SELECT COUNT(aid) FROM ' . DB::table('portal_article_title') . ' WHERE status=0');
        return $total;
    }

    public function categoryData($start, $limit)
    {
        $arr = DB::fetch_all('SELECT catid,foldername,dateline FROM ' . DB::table('portal_category') . ' WHERE closed=0 ' . DB::limit($start, $limit));
        return $arr;
    }

    public function categoryTotal()
    {
        $total = DB::result_first('SELECT COUNT(catid) FROM ' . DB::table('portal_category') . ' WHERE closed=0');
        return $total;
    }
}
//From: Dism��taobao��com
?>