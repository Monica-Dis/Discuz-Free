<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: adminhelp.inc.php  2019-11 liyuanchao $
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
showtableheader();
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_rewrite')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_baidumip')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_baiduxiong')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_aliyunvideo')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_qiniu')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_video')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_videolist')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_videocover')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_service')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_html5upload')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_limit')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_picverify')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_interest')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_weixinshare')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_telfunc')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_like')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_teladv')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_index')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_vest')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_wmark')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_facebook')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_google')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_yahoo')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_twitter')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_pushpub')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_hidesection')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_money')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_salary')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_moderator')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_picessence')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','apoyl_picdivision')));

showtablerow('','',array(lang('plugin/apoyl_sitemap','addr')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','blog')));
showtablerow('','',array(lang('plugin/apoyl_sitemap','qq')));
showtablefooter();

?>