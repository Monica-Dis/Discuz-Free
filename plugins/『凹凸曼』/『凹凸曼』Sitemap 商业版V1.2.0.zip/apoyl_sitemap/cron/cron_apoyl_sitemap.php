<?php
/**
 *      DisM!Ӧ�����ģ�dism.taobao.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: cron_apoyl_sitemap.php  2019-04 liyuanchao $
 */
//cronname:apoyl_sitemap
//hour:00
//minute:10

if(!defined('IN_DISCUZ')){
exit('Acccess Denied');
} 
loadcache('plugin');
$cache=$_G['cache']['plugin']['apoyl_sitemap'];
if($cache['urls']&&$cache['opencron']){
    $fileapoyl=DISCUZ_ROOT . './source/plugin/apoyl_sitemap/class/ApoylSitemap.class.php';
   if(file_exists($fileapoyl)){
        require_once $fileapoyl;
        $siteurl=$_G['siteurl'];
        $obj=new ApoylSitemap($cache,$siteurl);
        $obj->saveXml();
   }
} 


?>