<?php
/**
 *      [liyuanchao] (C)2015-2016 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: pcthreadlist.php  2016-07 liyuanchao $ 
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}
$apoyl=$_G['cache']['plugin']['apoyl_listbigimg'];
$forums=unserialize($apoyl['forums']);
if(!in_array($_G['fid'],$forums)) return array();
 
$list=$_G['forum_threadlist'];
$width=$apoyl['listwidth'];
$height=$apoyl['listheight'];
$num=$apoyl['listnums'];
$isa=$apoyl['openurl'];
if(!$num) return '';
$cssstyle='style="width:'.$width.'px;height:'.$height.'px;"';
require_once libfile('function/post');
foreach ($list as $v){          
   if($v['attachment']==2){
     $attachs=C::t('forum_attachment_n')->fetch_all_by_id(getattachtableid($v['tid']), 'tid', $v['tid'], '', true);
     $imgs='';
     $i=0;
     
     foreach ($attachs as $img){
         if($i==$num) break;
         $url=getforumimg($img['aid'],0,$width,$height);
         if($isa)
             $imgs.='<a href="forum.php?mod=viewthread&tid='.$v['tid'].'"><img src="'.$url.'" '.$cssstyle.' /></a>';
         else
            $imgs.='<img src="'.$url.'" '.$cssstyle.' />';
         $i++;                 
     }

     $data[]='<div class="apoyl_listbigimg_img">'.$imgs.'</div>';
   }else{
       $data[]='';
   }
}



?>