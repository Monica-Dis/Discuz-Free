<?php
/**
 *      [liyuanchao] (C)2019-2019 http://www.apoyl.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: mobilelistimg.class.php  2019-06  liyuanchao（凹凸曼）$
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}
class mobileplugin_apoyl_listbigimg{
  public function global_footer_mobile(){
      global $_G;
      
        if($_G['basescript']=='search'&&$_GET['mod']=='forum'){
            $style=$this->_styleapoyl();
        }
      return $style;
  }
  protected function _styleapoyl(){
      $raduis=$this->_radius();
      return '<style>.apoyl_listbigimg_img{float: left;'.$raduis.'}.apoyl_listbigimg_img img {margin-left:2px;width:97%;'.$raduis.'}.apoyl_listbigimg_clear{clear:both;} .threadlist .by{padding:0 7px;} .threadlist .num{bottom:0px;}</style>';
  }
  protected function _fileapoyl($filename){
      $fileapoyl=DISCUZ_ROOT.'./source/plugin/apoyl_listbigimg/'.$filename.'.php';
      if(file_exists($fileapoyl))
          return $fileapoyl;
      return '';
  }
    protected function _radius(){
        include $this->_fileapoyl('radius');
        return $re;
    }
    protected function _fileapoylv2($filename){
        $fileapoyl=DISCUZ_ROOT.'./source/plugin/apoyl_listbigimg/components/'.$filename.'.php';
        if(file_exists($fileapoyl))
            return $fileapoyl;
            return '';
    }
}
class mobileplugin_apoyl_listbigimg_search extends mobileplugin_apoyl_listbigimg{
    public function forum_apoylsearch_output($a){
        global $_G,$threadlist;
        include $this->_fileapoyl('mbsearchlist');

    }

}
class mobileplugin_apoyl_listbigimg_forum extends mobileplugin_apoyl_listbigimg{
    public function forumdisplay_thread_mobile_output($a){
        global $_G;
        $return='';
        include $this->_fileapoylv2('mbchangelist');
        if(!$apoyl['openchange'])
            include $this->_fileapoyl('mbthreadlist');
        include $this->_fileapoylv2('mbthreadlistlink');
        return $return;
    }
    
    public function forumdisplay_bottom_mobile_output($a){
        global $_G;
        $forums=unserialize($_G['cache']['plugin']['apoyl_listbigimg']['mobileforums']);
        if(!in_array($_G['fid'],$forums)) return '';
        $style=$this->_styleapoyl();
        return $style;
    }
}


?>