<?php
/**
 *      [liyuanchao] (C)2015-2016 apoyl.com.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: mbthreadlist.php  2016-07 liyuanchao $ 
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}
$apoyl=$_G['cache']['plugin']['apoyl_listbigimg'];
$forums=unserialize($apoyl['mobileforums']);
if(!in_array($_G['fid'],$forums)) return array();
$list=$_G['forum_threadlist'];
$width=$apoyl['mobilewidth'];
$height=$apoyl['mobileheight'];
$cols=$apoyl['mobilecols'];
$rows=$apoyl['mobilerows'];
$num=$rows*$cols;
$isa=$apoyl['openurl'];
if(!$num) return '';
if($cols==1)
   $widthstyle="100%";
elseif($cols==2){
   $widthstyle="50%";
}elseif($cols==3){
   $widthstyle="33.33%";
 }
require_once libfile('function/post');
foreach ($list as $k=>$v){          
   if($v['attachment']==2){
     $attachs=C::t('forum_attachment_n')->fetch_all_by_id(getattachtableid($v['tid']), 'tid', $v['tid'], '', true);
     $imgs='';
     $i=0;
     foreach ($attachs as $img){
         if($i==$num) break;
         $url=getforumimg($img['aid'],0,$width,$height); 
         $mobile=intval($_GET['mobile']);
         if($isa&&$mobile==1){
             $imgs.='<div class="apoyl_listbigimg_img" style="width:'.$widthstyle.';" ><a href="forum.php?mod=viewthread&tid='.$v['tid'].'" ><img src="'.$url.'"  style="margin-top:3px;" /></a></div>';
         }elseif($isa)
             $imgs.='<a href="forum.php?mod=viewthread&tid='.$v['tid'].'" style="padding:0px 7px;" ><div class="apoyl_listbigimg_img" style="width:'.$widthstyle.';margin-top:-3px;" ><img src="'.$url.'"  /></div></a>';
         else
            $imgs.='<div class="apoyl_listbigimg_img" style="width:'.$widthstyle.';" ><img src="'.$url.'" /></div>';
         $i++;                 
     }
  
     $_G['forum_threadlist'][$k]['subject']=$v['subject'].'<br>'.$imgs.'<div class="apoyl_listbigimg_clear"></div>';


   
   }
}


?>