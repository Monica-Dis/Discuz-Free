<?php
/**
 *      [liyuanchao] (C)2019-2019 http://www.apoyl.com
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: listimg.class.php  2019-06  liyuanchao（凹凸曼）$
 */
if(!defined('IN_DISCUZ')){
    exit('Access Denied');
}
class plugin_apoyl_listbigimg{
    protected function _fileapoyl($filename){
        $fileapoyl=DISCUZ_ROOT.'./source/plugin/apoyl_listbigimg/'.$filename.'.php';
        if(file_exists($fileapoyl))
            return $fileapoyl;
        return '';
    }
    protected function _fileapoylv2($filename){
        $fileapoyl=DISCUZ_ROOT.'./source/plugin/apoyl_listbigimg/components/'.$filename.'.php';
        if(file_exists($fileapoyl))
            return $fileapoyl;
        return '';
    }
    protected function _radius(){
        include $this->_fileapoyl('radius');
        return $re;
    }
    protected function _styleapoyl(){
          $raduis=$this->_radius();
          return '<style>.apoyl_listbigimg_img img{margin-top:3px;margin-right:3px;'.$raduis.'}</style>';
      }
    public function global_footer(){
        global $_G;
        if($_G['basefilename']=='misc.php'&&$_G['mod']=='tag')
            return $this->_styleapoyl();
      }
}
class plugin_apoyl_listbigimg_search extends plugin_apoyl_listbigimg{
    public function forum_top_output($a){
        global $_G,$threadlist;
        include $this->_fileapoyl('pcsearchlist');
        if($isattach)
            return $this->_styleapoyl();

    }
    public function portal_top_output($a){
        global $_G,$articlelist;
        include $this->_fileapoyl('pcartclesearchlist');
        if($isattach)
            return $this->_styleapoyl();
    }

}
class plugin_apoyl_listbigimg_forum extends plugin_apoyl_listbigimg{
   public function forumdisplay_thread_subject_output($a){
       global $_G;
       include $this->_fileapoyl('pcthreadlist');
       include $this->_fileapoylv2('pcthreadlistlink');
       return $data;
   }
   public function forumdisplay_threadlist_bottom_output($a){
       global $_G;
       $forums=unserialize($_G['cache']['plugin']['apoyl_listbigimg']['forums']);
       if(!in_array($_G['fid'],$forums)) return '';
       $style=$this->_styleapoyl();
       return $style;
   }
   public function collection_view_top_output($a){
       global $_G,$collectiontids;
        include $this->_fileapoylv2('pctaolist');
        if($isattach)
            return $this->_styleapoyl();
   }


}
class plugin_apoyl_listbigimg_misc extends  plugin_apoyl_listbigimg{
    public function tag_go_output($a){
        global $_G,$threadlist;
        include $this->_fileapoylv2('pctaglist');
    }
}
//From: dis'.'m.tao'.'bao.com
?>