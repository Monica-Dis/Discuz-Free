<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_pcasl_m3u8 {
	function discuzcode() {
		global $_G;
		$var = $_G['cache']['plugin']['pcasl_m3u8']['kplate'];
			include_once DISCUZ_ROOT.'./source/plugin/pcasl_m3u8/computer.php';
			if (strstr($_G['discuzcodemessage'],'[/pcasl_m3u8]')){
					$_G['discuzcodemessage'] = preg_replace_callback("/\[pcasl_m3u8(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/pcasl_m3u8\]/i","computer",$_G['discuzcodemessage']);
			}
	}
}

class plugin_pcasl_m3u8_forum extends plugin_pcasl_m3u8 {
	
	function post_editorctrl_left(){
		global $_G;
		$kg = $_G['cache']['plugin']['pcasl_m3u8']['switch'];
		$var = $_G['cache']['plugin']['pcasl_m3u8']['kplate'];
		if($kg){
			if(in_array($_G['fid'],unserialize($var))){
				return '<a id="e_pcasl" style="background:url(source/plugin/pcasl_m3u8/template/icon.png) no-repeat center top" title="'.lang('plugin/pcasl_m3u8', 'm3u8').'">'.lang('plugin/pcasl_m3u8', 'm3u8').'</a>';
			}
		}
	}
	
	function post_middle_output(){
		global $_G;
		$kg = $_G['cache']['plugin']['pcasl_m3u8']['switch'];
		$var = $_G['cache']['plugin']['pcasl_m3u8']['kplate'];
		$ship = lang('plugin/pcasl_m3u8', 'shipindizhi');
		$tijiao = lang('plugin/pcasl_m3u8', 'tijiao');
		$guanbi = lang('plugin/pcasl_m3u8', 'guanbi');
		$zhuyi = lang('plugin/pcasl_m3u8', 'zhuyi');
		if($kg){
			if(in_array($_G['fid'],unserialize($var))){
				include template('pcasl_m3u8:code');
				return $return;
			}
		}
	}
}
//From: Dism��taobao��com
?>