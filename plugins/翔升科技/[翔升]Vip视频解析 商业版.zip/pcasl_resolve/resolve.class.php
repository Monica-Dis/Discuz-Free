<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class plugin_pcasl_resolve {
	function discuzcode() {
		global $_G;
		$var = $_G['cache']['plugin']['pcasl_resolve']['pcaslkuai'];
		if(in_array($_G['fid'],unserialize($var))){
			include_once DISCUZ_ROOT.'./source/plugin/pcasl_resolve/computerj.php';
			if (strstr($_G['discuzcodemessage'],'[/pcasl_jiexi]')){
					$_G['discuzcodemessage'] = preg_replace_callback("/\[pcasl_jiexi=(.*?)\]\s*([^\[\<\r\n]+?)\s*\[\/pcasl_jiexi\]/i","computerj",$_G['discuzcodemessage']);
			}
		}
	}
}

class plugin_pcasl_resolve_forum extends plugin_pcasl_resolve {
	
	function post_editorctrl_left(){
		global $_G;
		$var = $_G['cache']['plugin']['pcasl_resolve']['pcaslkuai'];
		if(in_array($_G['fid'],unserialize($var))){
			return '<a id="e_pcaslj" style="background:url(source/plugin/pcasl_resolve/template/icon.png) no-repeat center top" title="'.lang('plugin/pcasl_resolve', 'xuanze').'">'.lang('plugin/pcasl_resolve', 'jiexi').'</a>';;
		}
	}
	
	function post_middle_output(){
		global $_G;
		$var = $_G['cache']['plugin']['pcasl_resolve']['pcaslkuai'];
		$titledizhi = lang('plugin/pcasl_resolve', 'jiexidizhi');
		$titleruxia = lang('plugin/pcasl_resolve', 'shipindizhiruxia');
		$titleguanbi = lang('plugin/pcasl_resolve', 'guanbi');
		$titletijiao = lang('plugin/pcasl_resolve', 'tijiao');
		if(in_array($_G['fid'],unserialize($var))){
			include template('pcasl_resolve:code');
			return $return;
		}
	}
}
//From: Dism_taobao-com
?>