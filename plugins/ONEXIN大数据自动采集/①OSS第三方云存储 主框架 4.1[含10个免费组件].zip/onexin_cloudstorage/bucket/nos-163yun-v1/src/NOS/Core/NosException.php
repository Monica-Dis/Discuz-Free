<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-21
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
//namespace NOS\Core;

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

/**
 * Class NOSException
 *
 * NOSClient在使用的时候，所抛出的异常，用户在使用NOSClient的时候，要Try住相关代码，
 * try的Exception应该是NOSException，其中会得到相关异常原因
 *
 * @package NOS\Core
 */
class NosException extends \Exception
{
    private $details = array();

    function __construct($details)
    {
        if (is_array($details)) {
            $message = $details['code'] . ': ' . $details['message']
                     . ' RequestId: ' . $details['request-id'];
            parent::__construct($message);
            $this->details = $details;
        } else {
            $message = $details;
            parent::__construct($message);
        }
    }

    public function getHTTPStatus()
    {
        return isset($this->details['status']) ? $this->details['status'] : '';
    }

    public function getRequestId()
    {
        return isset($this->details['request-id']) ? $this->details['request-id'] : '';
    }

    public function getErrorCode()
    {
        return isset($this->details['code']) ? $this->details['code'] : '';
    }

    public function getErrorMessage()
    {
        return isset($this->details['message']) ? $this->details['message'] : '';
    }

    public function getDetails()
    {
        return isset($this->details['body']) ? $this->details['body'] : '';
    }
}
