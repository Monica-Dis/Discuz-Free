<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-21
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
//namespace NOS\Result;

//use NOS\Core\NosException;
//use NOS\Model\DeleteFailedInfo;

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

class MultiDeleteResult extends Result
{

    protected function parseDataFromResponse()
    {
        $content = $this->rawResponse->body;
        if (! isset($content) || empty($content)) {
            throw new NosException("invalid response,empty response body");
        }
        try {
            $xml = simplexml_load_string($content);
        } catch (\Exception $e) {
            throw new NosException("invalid response,response body invalid xml");
        }
        if(!isset($xml->Error) && !isset($xml->Deleted)){
            return null;
        }
        $succ = array();
        foreach ($xml->Deleted as $deleted){
            $succ[] = strval($deleted->Key);
        }
        $fails = array();
        foreach ($xml->Error as $err){
           $failInfo = new DeleteFailedInfo(strval($err->Key),strval($err->Code),strval($err->Message));
           $fails[] = $failInfo;
        }
        $result = array();
        if(count($succ)){
            $result['succeed'] = $succ;
        }
        if(count($fails)){
            $result['failed'] = $fails;
        }
        return $result;
    }
}

