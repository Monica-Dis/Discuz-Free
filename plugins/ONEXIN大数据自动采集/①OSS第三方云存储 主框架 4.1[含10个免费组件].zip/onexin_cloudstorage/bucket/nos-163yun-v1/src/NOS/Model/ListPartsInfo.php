<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-21
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
//namespace NOS\Model;

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

class ListPartsInfo
{

    public function __construct($bucket, $key, $uploadId, $storageClass, $partNumberMarker, $nextPartNumberMarker, $maxParts, $isTruncated, array $listPart)
    {
        $this->bucket = $bucket;
        $this->key = $key;
        $this->uploadId = $uploadId;
        $this->storageClass = $storageClass;
        $this->partNumberMarker = $partNumberMarker;
        $this->nextPartNumberMarker = $nextPartNumberMarker;
        $this->maxParts = $maxParts;
        $this->isTruncated = $isTruncated;
        $this->listPart = $listPart;
    }

    /**
     * @return the $bucket
     */
    public function getBucket()
    {
        return $this->bucket;
    }

    /**
     * @return the $key
     */
    public function getKey()
    {
        return $this->key;
    }

    /**
     * @return the $uploadId
     */
    public function getUploadId()
    {
        return $this->uploadId;
    }

    /**
     * @return the $storageClass
     */
    public function getStorageClass()
    {
        return $this->storageClass;
    }

    /**
     * @return the $partNumberMarker
     */
    public function getPartNumberMarker()
    {
        return $this->partNumberMarker;
    }

    /**
     * @return the $nextPartNumberMarker
     */
    public function getNextPartNumberMarker()
    {
        return $this->nextPartNumberMarker;
    }

    /**
     * @return the $maxParts
     */
    public function getMaxParts()
    {
        return $this->maxParts;
    }

    /**
     * @return the $isTruncated
     */
    public function getIsTruncated()
    {
        return $this->isTruncated;
    }

    /**
     * @return the $listPart
     */
    public function getListPart()
    {
        return $this->listPart;
    }


    private $bucket = '';
    private $key = '';
    private $uploadId = '';
    private $storageClass = '';
    private $partNumberMarker = 0;
    private $nextPartNumberMarker = 0;
    private $maxParts = 0;
    private $isTruncated = NULL;
    private $listPart =array();
}

