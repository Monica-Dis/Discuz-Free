<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-21
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
//namespace NOS\Model;

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

class PartInfo
{

    public function __construct($partNumber,$lastModified,$eTag,$size)
    {
        $this->partNumber = $partNumber;
        $this->lastModified = $lastModified;
        $this->eTag = $eTag;
        $this->size = $size;
    }

    /**
     * @return the $partNumber
     */
    public function getPartNumber()
    {
        return $this->partNumber;
    }

    /**
     * @return the $lastModified
     */
    public function getLastModified()
    {
        return $this->lastModified;
    }

    /**
     * @return the $eTag
     */
    public function getETag()
    {
        return $this->eTag;
    }

    /**
     * @return the $size
     */
    public function getSize()
    {
        return $this->size;
    }

    private $partNumber = 0;
    private $lastModified ='';
    private $eTag = '';
    private $size = 0;
}

