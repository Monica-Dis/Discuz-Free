<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-21
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

require_once(__DIR__ . '/cos-qcloud-v4/src/qcloud/cos/Auth.php');
require_once(__DIR__ . '/cos-qcloud-v4/src/qcloud/cos/Helper.php');
require_once(__DIR__ . '/cos-qcloud-v4/src/qcloud/cos/HttpClient.php');
require_once(__DIR__ . '/cos-qcloud-v4/src/qcloud/cos/Api.php');
require_once(__DIR__ . '/cos-qcloud-v4/src/qcloud/cos/HttpRequest.php');
require_once(__DIR__ . '/cos-qcloud-v4/src/qcloud/cos/HttpResponse.php');
require_once(__DIR__ . '/cos-qcloud-v4/src/qcloud/cos/LibcurlWrapper.php');
require_once(__DIR__ . '/cos-qcloud-v4/src/qcloud/cos/SliceUploading.php');

	
//--------------------------------------------------------------

	function _bucket_put($object, $content, $mode = 'file', $options = NULL){
		if(empty($object)) return false;
		$object = _bucket_clear($object);
		
		$config = _bucket_config();
		$bucket = $config['bucket'];
		$cosApi = new Api($config);
		$result = $cosApi->upload($bucket, $content, $object);
		return empty($result['code']) ? true : false;
	}
	
	function _bucket_get($local_path, $object, $options = NULL){
	}
	
	function _bucket_size($object){
	}
	
	function _bucket_delete($object){
		if(empty($object)) return false;
		$object = _bucket_clear($object);

		$config = _bucket_config();
		$bucket = $config['bucket'];
		$cosApi = new Api($config);
		$result = $cosApi->delFile($bucket, $object);
		return empty($result['code']) ? true : false;
	}
	
	function _bucket_is($keyFile){
	}
	
	function _bucket_clear($str){ 
		// Local  ~ /www/dx3/;
		$str = str_replace('./', '/', $str);
		$str = str_replace('//', '/', $str); 
		// Bucket ~ /bucket.jpg
		if($str{0} == '/') $str = ltrim($str, '/');
		return str_replace('..', '', $str);
	}
	
	function _bucket_config(){
		global $_G;

		$_bucket_conf     = $_G['cache']['plugin']['onexin_cloudstorage'];
		//config your information
		$config = array(
			'bucket' => $_bucket_conf['bucket'], // <name>-<id>
			'secret_id' => $_bucket_conf['access_key'],
			'secret_key' => $_bucket_conf['secret_key'],
			'region' => $_bucket_conf['region'],   // bucket所属地域：华北 'tj' 华东 'sh' 华南 'gz'
			'timeout' => 60
		);
		
		// app_id
		$config['app_id'] = preg_replace("/^.*?-(\d+)$/", "\\1", $config['bucket']);
		
		// bucket onexin
		$config['bucket'] = preg_replace("/-(\d+)$/", "", $config['bucket']);
		
		// region 
		$region = $config['region'];

		$regionmap = array(
            'sg'=>'ap-singapore',
            'tj'=>'ap-beijing-1',
            'bj'=>'ap-beijing',
            'sh'=>'ap-shanghai',
            'gz'=>'ap-guangzhou',
            'cd'=>'ap-chengdu',
            'sgp'=>'ap-singapore',);
		$regionmap = array_flip($regionmap);	
        $region =  !empty($regionmap[$region]) ? $regionmap[$region] : $region;
		$config['region'] = $region;
		
		return $config;
	}

