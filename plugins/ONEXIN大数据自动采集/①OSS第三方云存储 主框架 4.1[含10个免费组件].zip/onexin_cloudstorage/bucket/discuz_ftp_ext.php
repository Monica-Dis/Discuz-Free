<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2018-02-01
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

class discuz_ftp{
	var $enabled = false;
	var $config = array();
	var $func;
	var $connectid;
	var $_error;
	var $mode = 'file';
	
	function &instance($config = array()) {
		static $object;
		if(empty($object)) {
			$object = new discuz_ftp($config);
		}
		return $object;
	}

	function __construct($config = array()) {
		global $_G;
		$this->set_error(0);
		$this->config = !$config ? getglobal('setting/ftp') : $config;
		$this->enabled = true;
		//echo "BUCKET;";
		include_once DISCUZ_ROOT.'./source/plugin/onexin_cloudstorage/function_bucket.php';
	}

	function upload($source, $target){
		return $this->ftp_put($target, $source);
	}

	function connect() {
		$this->connectid = true;
		return true;
	}
	
	function ftp_connect($ftphost, $username, $password, $ftppath, $ftpport = 21, $timeout = 30, $ftpssl = 0, $ftppasv = 0) {
		$this->connectid = true;
		return true;

	}

	function set_error($code = 0) {
		$this->_error = $code;
	}

	function error() {
		return $this->_error;
	}

	function clear($str) {
		return str_replace('..', '', $str);
	}

	function set_option($cmd, $value) {
		return;
	}
	function ftp_mkdir($directory) {
		return true;
	}
	
	function ftp_rmdir($directory) {
		return true;
	}
	
	function ftp_put($remote_file, $local_file, $mode = "file") {
		return _bucket_put($remote_file, $local_file, $mode);
	}
	
	function ftp_size($remote_file) {
		return _bucket_size($remote_file);
	}

	function ftp_close() {
		return true;
	}

	function ftp_delete($path){
		return _bucket_delete($path);
	}

	function ftp_get($local_file, $remote_file, $mode, $options = null) {
		return _bucket_get($local_file, $remote_file, $options);
	}
	
	function ftp_login($username, $password) {
		return true;
	}

	function ftp_pasv($pasv) {
		return true;
	}
}
