<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-21
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

define("NO_AUTH_CHECK", 0);
define("HEAD_FIELD_CHECK", 1);
define("QUERY_STRING_CHECK", 2);

// ----------------------------------------------------------
function CanonicalizedResource($bucket, $key)
{
    return "/" . $bucket . "/" . $key;
}

function CanonicalizedUCloudHeaders($headers)
{

    $keys = array();
    foreach($headers as $header) {
        $header = trim($header);
        $arr = explode(':', $header);
        if (count($arr) < 2) continue;
        list($k, $v) = $arr;
        $k = strtolower($k);
        if (strncasecmp($k, "x-ucloud") === 0) {
            $keys[] = $k;
        }
    }

    $c = '';
    sort($keys, SORT_STRING);
    foreach($keys as $k) {
        $c .= $k . ":" . trim($headers[$v], " ") . "\n";
    }
    return $c;
}

class UCLOUD_API {

    public static $PUBLIC_KEY;
    public static $PRIVATE_KEY;
    public static $PROXY_SUFFIX;

    public function __construct($publicKey, $privateKey, $proxySuffix)
    {
        self::$PUBLIC_KEY = $publicKey;
        self::$PRIVATE_KEY = $privateKey;
        self::$PROXY_SUFFIX = $proxySuffix;
    }
}

class UCloud_Auth {

    public $PublicKey;
    public $PrivateKey;

    public function __construct($publicKey, $privateKey)
    {
        $this->PublicKey = $publicKey;
        $this->PrivateKey = $privateKey;
    }

    public function Sign($data)
    {
        $sign = base64_encode(hash_hmac('sha1', $data, $this->PrivateKey, true));
        return "UCloud " . $this->PublicKey . ":" . $sign;
    }

    //@results: $token
    public function SignRequest($req, $mimetype = null, $type = HEAD_FIELD_CHECK)
    {
        $url = $req->URL;
        $url = parse_url($url['path']);
        $data = '';
        $data .= strtoupper($req->METHOD) . "\n";
        $data .= UCloud_Header_Get($req->Header, 'Content-MD5') . "\n";
        if ($mimetype)
            $data .=  $mimetype . "\n";
        else
            $data .= UCloud_Header_Get($req->Header, 'Content-Type') . "\n";
        if ($type === HEAD_FIELD_CHECK)
            $data .= UCloud_Header_Get($req->Header, 'Date') . "\n";
        else
            $data .= UCloud_Header_Get($req->Header, 'Expires') . "\n";
        $data .= CanonicalizedUCloudHeaders($req->Header);
        $data .= CanonicalizedResource($req->Bucket, $req->Key);
        return $this->Sign($data);
    }
}

function UCloud_MakeAuth($auth)
{
    if (isset($auth)) {
        return $auth;
    }

    return new UCloud_Auth(UCLOUD_API::$PUBLIC_KEY, UCLOUD_API::$PRIVATE_KEY);
}

//@results: token
function UCloud_SignRequest($auth, $req, $type = HEAD_FIELD_CHECK)
{
    return UCloud_MakeAuth($auth)->SignRequest($req, $type);
}

// ----------------------------------------------------------


