<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-03-10
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

区域region代码
华东z0
华南z2
华北z1
北美na0
新加坡as0

*/

require_once __DIR__ . '/qos-qiniu/src/Qiniu/Qiniu.php';
require_once __DIR__ . '/qos-qiniu/src/Qiniu/Auth.php';
require_once __DIR__ . '/qos-qiniu/src/Qiniu/MimeTypes.php';
require_once __DIR__ . '/qos-qiniu/src/Qiniu/Http.php';

	
//--------------------------------------------------------------

	function _bucket_put($key, $filePath, $mode = 'file', $options = null){
		$key = _bucket_clear($key);
		
		$config = _bucket_config();
		$bucket = $config['bucket'];
		$qiniu = new Qiniu($config);
		$res = $qiniu->put($bucket, $key, $filePath);
		return $res['code'] == 200 ? true : false;
	}
	
	function _bucket_get($local_file, $key, $options = null){
	}
	
	function _bucket_size($key){
	}
	
	function _bucket_delete($key){
		$key = _bucket_clear($key);
		
		$config = _bucket_config();
		$bucket = $config['bucket'];
		$qiniu = new Qiniu($config);		
    	$res = $qiniu->delete($bucket, $key);
		return $res['code'] == 200 ? true : false;
	}
	
	function _bucket_is($keyFile){
	}
	
	function _bucket_clear($str){ 
		// Local  ~ /www/dx3/;
		$str = str_replace('./', '/', $str);
		$str = str_replace('//', '/', $str); 
		// Bucket ~ /bucket.jpg
		if($str{0} == '/') $str = ltrim($str, '/');
		return str_replace('..', '', $str);
	}
	
	function _bucket_config(){
		global $_G;

		$_bucket_conf     = $_G['cache']['plugin']['onexin_cloudstorage'];
		//config your information	
		$_conf =
			array(
				'access_key' => $_bucket_conf['access_key'],
				'secret_key' => $_bucket_conf['secret_key'],
				'region' => $_bucket_conf['region'],//z0
				'endpoint' => $_bucket_conf['host'],
				'protocol' => 'http',
				'bucket' => $_bucket_conf['bucket'],
			);
		
		return $_conf;
	}
	