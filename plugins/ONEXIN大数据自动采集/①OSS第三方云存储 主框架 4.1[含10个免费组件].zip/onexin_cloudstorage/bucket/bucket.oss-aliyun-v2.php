<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-04-21
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

//set_time_limit(60);
//ignore_user_abort();

//-------------------------------------------------------------------------


//require_once __DIR__ . '/oss-aliyun-v2.phar';

//if (is_file(__DIR__ . '/autoload.php')) {
//    require_once __DIR__ . '/autoload.php';
//}

//if (is_file(__DIR__ . '/oss-aliyun-v2/autoload.php')) {
//    require_once __DIR__ . '/oss-aliyun-v2/autoload.php';
//}


require_once __DIR__ . '/oss-aliyun-v2/src/OSS/OssClient.php';
require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Core/OssUtil.php';
require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/XmlConfig.php';
require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/Result.php';
require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/PutSetDeleteResult.php';
require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Core/MimeTypes.php';
require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Core/OssException.php';
require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Http/RequestCore.php';
require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Http/RequestCore_Exception.php';
require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Http/ResponseCore.php';

//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/BucketInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/BucketListInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/CnameConfig.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/CorsConfig.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/CorsRule.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/GetLiveChannelHistory.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/GetLiveChannelInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/GetLiveChannelStatus.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/LifecycleAction.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/LifecycleConfig.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/LifecycleRule.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/ListMultipartUploadInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/ListPartsInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/LiveChannelConfig.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/LiveChannelHistory.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/LiveChannelInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/LiveChannelListInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/LoggingConfig.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/ObjectInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/ObjectListInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/PartInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/PrefixInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/RefererConfig.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/StorageCapacityConfig.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/UploadInfo.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Model/WebsiteConfig.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/AclResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/AppendResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/BodyResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/CallbackResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/CopyObjectResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/DeleteObjectsResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/ExistResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetCnameResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetCorsResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetLifecycleResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetLiveChannelHistoryResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetLiveChannelInfoResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetLiveChannelStatusResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetLocationResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetLoggingResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetRefererResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetStorageCapacityResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/GetWebsiteResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/HeaderResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/InitiateMultipartUploadResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/ListBucketsResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/ListLiveChannelResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/ListMultipartUploadResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/ListObjectsResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/ListPartsResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/PutLiveChannelResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/SymlinkResult.php';
//require_once __DIR__ . '/oss-aliyun-v2/src/OSS/Result/UploadPartResult.php';

	
//--------------------------------------------------------------

	function _bucket_put($object, $content, $mode = 'file', $options = null){
		global $_G;
		if(empty($object)) return true;
		$object = _bucket_clear($object);
		
		$_conf     = _bucket_config();
		$bucket    = $_conf['bucket'];
		$ossClient = new OssClient($_conf['access_key'], $_conf['secret_key'], $_conf['endpoint']);
		$result = $ossClient->uploadFile($bucket, $object, $content);
		return $result['info']['http_code'] == 200 ? true : false;
	}
	
	function _bucket_get($local_file, $object, $options = null){
		global $_G;
		if(empty($object)) return true;
		$object = _bucket_clear($object);
		
		$_conf     = _bucket_config();
		$bucket    = $_conf['bucket'];
		$ossClient = new OssClient($_conf['access_key'], $_conf['secret_key'], $_conf['endpoint']);
		$timeout = '3600';
		$signedUrl = $ossClient->signUrl($bucket, $object, $timeout);		
		if(empty($local_file)){
			dheader('location:'.$signedUrl);
		}else{
			echo dfsockopen($signedUrl);
		}
		return true;
	}
	
	function _bucket_size($object){
	}
	
	function _bucket_delete($object){
		global $_G;
		if(empty($object)) return true;
		$object = _bucket_clear($object);
		
		$_conf     = _bucket_config();
		$bucket    = $_conf['bucket'];
		$ossClient = new OssClient($_conf['access_key'], $_conf['secret_key'], $_conf['endpoint']);
		$result = $ossClient->deleteObject($bucket, $object);
		return $result['info']['http_code'] == 204 ? true : false;
	}
	
	function _bucket_is($keyFile){
	}
	
	function _bucket_clear($str){ 
		// Local  ~ /www/dx3/;
		$str = str_replace('./', '/', $str);
		$str = str_replace('//', '/', $str); 
		//$str = str_replace('..', '', $str);
		// Bucket ~ /bucket.jpg
		if($str{0} == '/') $str = ltrim($str, '/');
		return $str;
	}
	
	function _bucket_config(){
		global $_G;

		$_bucket_conf     = $_G['cache']['plugin']['onexin_cloudstorage'];
		//config your information	
		$_conf =
			array(
				'access_key' => $_bucket_conf['access_key'],
				'secret_key' => $_bucket_conf['secret_key'],
				'endpoint' => 'http://'.$_bucket_conf['host'],
				'protocol' => 'http',
				'bucket' => $_bucket_conf['bucket'],
			);
		
		return $_conf;
	}
