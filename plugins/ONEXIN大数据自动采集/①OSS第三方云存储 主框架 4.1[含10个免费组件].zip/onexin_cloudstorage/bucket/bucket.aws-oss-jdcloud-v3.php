<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

download phar：
http://docs.aws.amazon.com/aws-sdk-php/v3/download/aws.phar
*/

// 声明命名空间
use Aws\S3\S3Client;

// 引入依赖库
//require __DIR__ . '/aws-oss-jdcloud-v3.phar';
require __DIR__.'/aws-oss-jdcloud-v3/autoload.php';
	
//--------------------------------------------------------------

	function _bucket_put($object, $content, $mode = 'file', $options = NULL){
		if(empty($object)) return false;
		$object = _bucket_clear($object);

		$_conf = _bucket_config();
		$bucket = $_conf['bucket'];	
		$s3Client = new S3Client([    
			'version'=>'latest',    
			'region'=> $_conf['region'],    
			'endpoint' => $_conf['endpoint'],    
			'signature_version' => 'v4',    
			 'credentials' => [    
			   'key'    => $_conf['access_key'],    
			   'secret' => $_conf['secret_key'],    
				  ],    
			 ]);  
			 
		$result = $s3Client->upload($bucket, $object, fopen($content, 'r'), 'public-read');
		$result = $result->get("@metadata");
		return $result['statusCode'] == 200 ? true : false;
	}
	
	function _bucket_get($local_path, $object, $options = NULL){
		if(empty($object)) return true;
		$object = _bucket_clear($object);
		
		$_conf     = _bucket_config();
		$bucket    = $_conf['bucket'];
		$s3Client = new S3Client([    
			'version'=>'latest',    
			'region'=> $_conf['region'],    
			'endpoint' => $_conf['endpoint'],    
			'signature_version' => 'v4',    
			 'credentials' => [    
			   'key'    => $_conf['access_key'],    
			   'secret' => $_conf['secret_key'],    
				  ],    
			 ]); 
		
		$timeout = '+1 hours';// minutes,hours
		$cmd = $s3Client->getCommand('GetObject', [
			'Bucket' => $bucket,
			'Key'    => $object
		]);	
		$request = $s3Client->createPresignedRequest($cmd, $timeout);
		$signedUrl = (string) $request->getUri();	
		
		if(empty($local_file)){
			dheader('location:'.$signedUrl);
		}else{
			echo dfsockopen($signedUrl);
		}
		return true;
	}
	
	function _bucket_size($object){
	}
	
	function _bucket_delete($object){
		if(empty($object)) return false;
		$object = _bucket_clear($object);

		$_conf = _bucket_config();
		$bucket = $_conf['bucket'];
		$s3Client = new S3Client([    
			'version'=>'latest',    
			'region'=> $_conf['region'],    
			'endpoint' => $_conf['endpoint'],    
			'signature_version' => 'v4',    
			 'credentials' => [    
			   'key'    => $_conf['access_key'],    
			   'secret' => $_conf['secret_key'],    
				  ],    
			 ]); 
		
		$result = $s3Client->deleteObject(['Bucket'=>$bucket, 'Key'=>$object]);
		return true;$result['statusCode'] == 200 ? true : false;
	}
	
	function _bucket_is($keyFile){
	}
	
	function _bucket_clear($str){ 
		// Local  ~ /www/dx3/;
		$str = str_replace('./', '/', $str);
		$str = str_replace('//', '/', $str); 
		// Bucket ~ /bucket.jpg
		if($str[0] == '/') $str = ltrim($str, '/');
		return str_replace('..', '', $str);
	}
	
	function _bucket_config(){
		global $_G;

		$_bucket_conf     = $_G['cache']['plugin']['onexin_cloudstorage'];
		//config your information	
		$_conf =
			array(
				'access_key' => $_bucket_conf['access_key'],
				'secret_key' => $_bucket_conf['secret_key'],
				'region' => $_bucket_conf['region'],
				'endpoint' => 'http://'.$_bucket_conf['host'],
				'protocol' => 'http',
				'bucket' => $_bucket_conf['bucket'],
			);
		
		return $_conf;
	}