<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-21
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

class Http
{
    public function Request($url, $headers = [], $body = null)
    {
        $request = array();
		$request['url'] = $url;
        $request['headers'] = $headers;
        $request['body'] = $body;
		return $request;
    }

    public function sendRequest($request)
    {
        $ch = curl_init();
        $options = array(
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_CUSTOMREQUEST  => 'POST',
            CURLOPT_ENCODING => '',
            CURLOPT_URL => $request['url']
        );
        if (!empty($request['headers'])) {
            foreach($request['headers'] as $key => $value) {
                $options[CURLOPT_HTTPHEADER][] = sprintf('%s: %s', $key, $value);
            }
        }
        if (!empty($request['body'])) {
            $options[CURLOPT_POSTFIELDS] = $request['body'];
        }
        curl_setopt_array($ch, $options);
        $result = curl_exec($ch);		
        $statusCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
		
		$result = json_decode($result, true);
		$result['code'] = $statusCode;

        return $result;
    }

    public function callMultiRequest($url, $token, $file, array $params = [])
    {
        if (isset($params['key']) && empty($params['key'])) {
            unset($params['key']);
        }

        $fields = array_merge(['token' => $token], $params);
			
		//$content =  file_get_contents($file); 
		//$content = '@'.realpath($file);
		// php 5.5+
		//$content = new CURLFile(realpath($file)); 

        $fileInfo = pathinfo($file);
        $fname = isset($fields['key']) ? $fields['key'] : $fileInfo['basename'];
        $files = [
            [
                'file', 
                $fname, 
                file_get_contents($file)
            ],
        ];

        list($contentType, $body) = $this->buildMultipartForm($fields, $files);
        $headers = ['Content-Type' => $contentType];
        $request = $this->Request($url, $headers, $body);

        return $this->sendRequest($request);
    }
	
    /**
    * Build custom post fields for safe multipart POST request for php before 5.5.
    * @param $fields array of key -> value fields to post.
    * @return $boundary and encoded post fields.
    */
    public static function buildMultipartForm($fields, $files)
    {
        // invalid characters for "name" and "filename"
        static $disallow = array("\0", "\"", "\r", "\n");
        $data = [];
        $mimeBoundary = md5(microtime());

        foreach ($fields as $name => $value) {
            array_push($data, '--' . $mimeBoundary);
            array_push($data, sprintf(
                'Content-Disposition: form-data; name="%s"', 
                $name
            ));
            array_push($data, '');
            array_push($data, $value);
        }

        foreach ($files as $file) {
            array_push($data, '--' . $mimeBoundary);
            list($name, $fileName, $fileBody) = $file;
            $fileName = str_replace($disallow, "_", $fileName);
            array_push($data, sprintf(
                'Content-Disposition: form-data; name="%s"; filename="%s"', 
                $name, 
                $fileName)
            );
            array_push($data, 'Content-Type: '.MimeTypes::getMimetype($fileName));
            array_push($data, '');
            array_push($data, $fileBody);
        }

        array_push($data, '--' . $mimeBoundary . '--');
        array_push($data, '');

        $body = implode("\r\n", $data);
        $contentType = 'multipart/form-data; boundary=' . $mimeBoundary;

        return [$contentType, $body];
    }
	
}


