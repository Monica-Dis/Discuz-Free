<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-21
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

/**
 *上传策略，参数规格详见
 *http://developer.qiniu.com/docs/v6/api/reference/security/put-policy.html
 */	 
class Auth
{
    protected $accessKey;
    protected $secretKey;
    protected $expires = 3600;
    
	public $policyFields = array(
        'scope' => true, 
        'deadline' => true, 
    );
	
    public $items = [];
	
    public function __construct($accessKey, $secretKey)
    {
        $this->accessKey = $accessKey;
        $this->secretKey = $secretKey;
    }

    public function scope(array $scopes)
    {
        $scopes['deadline'] = time() + $this->expires;
        return $scopes;
    }
	
    public function sign($data)
    {
        $sign = hash_hmac('sha1', $data, $this->secretKey, true);
        return sprintf('%s:%s', $this->accessKey, $this->encode($sign));
    }

    public function signData($data)
    {
        $data = $this->encode($data);
        return sprintf('%s:%s', $this->sign($data), $data);
    }

    public function signRequest($request)
    {
		$url = parse_url($request['url']);
        $data = '';
        if (isset($url['path'])) {
            $data = $url['path'];
        }
        if (isset($url['query'])) {
            $data .= '?' . $url['query'];
        }
        $data .= "\n";

        if (isset($request['body']) && $request['headers']['Content-Type'] === 'application/x-www-form-urlencoded') {
            $data .= $request['body'];
        }
        return $this->sign($data);
    }

    public function encode($string)
    {
        $find = ['+', '/'];
        $replace = ['-', '_'];
        return str_replace($find, $replace, base64_encode($string));
    }
	
}
