<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-27
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

require_once __DIR__ . '/uss-upyun-v2/src/UpYun/upyun.class.php';

/*
onexin.test.upcdn.net
*/
	
//--------------------------------------------------------------

	function _bucket_put($target, $source, $mode = 'file', $options = null){
		$target = _bucket_clear($target);
		
		$upyun_config = _bucket_config();
        $file = new UpyunMultiPartFile($source);
        if($file->getSize() > 1024 * 1024 && $upyun_config['form_api_key']) {
            $sign = new UpyunMultipartSignature($upyun_config['form_api_key']);
            $upload = new UpyunMultipartUpload($sign);
            $upload->setBucketName($upyun_config['bucket_name']);
            $upload->setBlockSize($upload->getBlockSizeAdaptive($file));
            try {
                $result = $upload->upload($file, array(
                    'path' => '/' . ltrim($target, '/')
                ));
                return 1;
            } catch(Exception $e) {
                return 0;
            }
        } else {
            $fh = fopen($source, 'rb');
            if(!$fh) {
                return 0;
            }
            $upyun = new UpYun(
                $upyun_config['bucket_name'],
                $upyun_config['operator_name'],
                $upyun_config['operator_pwd']
            );
			try{
            	$rsp = $upyun->writeFile('/'. ltrim($target, '/'), $fh, true);
				return 1;
			} catch(Exception $e){
				return 0;
			}
        }
	}
	
	function _bucket_get($local_file, $target, $options = null){
	}
	
	function _bucket_size($target){
	}
	
	function _bucket_delete($target){
		$target = _bucket_clear($target);
		
		$upyun_config = _bucket_config();
        $upyun = new UpYun(
            $upyun_config['bucket_name'],
            $upyun_config['operator_name'],
            $upyun_config['operator_pwd']
		);
        try{
            $rsp = $upyun->delete('/' . ltrim($target, '/'));
            return 1;
        } catch(Exception $e){
            return 0;
        }
	}
	
	function _bucket_is($keyFile){
	}
	
	function _bucket_clear($str){ 
		// Local  ~ /www/dx3/;
		$str = str_replace('./', '/', $str);
		$str = str_replace('//', '/', $str); 
		// Bucket ~ /bucket.jpg
		if($str{0} == '/') $str = ltrim($str, '/');
		return str_replace('..', '', $str);
	}
	
	function _bucket_config(){
		global $_G;

		$_bucket_conf     = $_G['cache']['plugin']['onexin_cloudstorage'];
		//config your information	
		$_conf =
			array(
				'operator_name' => $_bucket_conf['access_key'],
				'operator_pwd' => $_bucket_conf['secret_key'],
				'form_api_key' => $_bucket_conf['region'],
				'protocol' => 'http',
				'bucket_name' => $_bucket_conf['bucket'],
			);
		
		return $_conf;
	}
	