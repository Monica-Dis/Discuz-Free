<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/


require_once __DIR__ . '/Psr/Http/Message/MessageInterface.php';
require_once __DIR__ . '/Psr/Http/Message/RequestInterface.php';
require_once __DIR__ . '/Psr/Http/Message/ResponseInterface.php';
require_once __DIR__ . '/Psr/Http/Message/ServerRequestInterface.php';
require_once __DIR__ . '/Psr/Http/Message/StreamInterface.php';
require_once __DIR__ . '/Psr/Http/Message/UploadedFileInterface.php';
require_once __DIR__ . '/Psr/Http/Message/UriInterface.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/StreamDecoratorTrait.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/AppendStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/BufferStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/Stream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/CachingStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/DroppingStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/FnStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/functions.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/functions_include.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/InflateStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/LazyOpenStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/LimitStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/MessageTrait.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/MultipartStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/NoSeekStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/PumpStream.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/Request.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/Response.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/Rfc7230.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/ServerRequest.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/StreamWrapper.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/UploadedFile.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/Uri.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/UriNormalizer.php';
require_once __DIR__ . '/GuzzleHttp/Psr7/UriResolver.php';

require_once __DIR__ . '/GuzzleHttp/ClientInterface.php';
require_once __DIR__ . '/GuzzleHttp/Cookie/CookieJarInterface.php';
require_once __DIR__ . '/GuzzleHttp/Cookie/CookieJar.php';
require_once __DIR__ . '/GuzzleHttp/Cookie/FileCookieJar.php';
require_once __DIR__ . '/GuzzleHttp/Cookie/SessionCookieJar.php';
require_once __DIR__ . '/GuzzleHttp/Cookie/SetCookie.php';
require_once __DIR__ . '/GuzzleHttp/Exception/GuzzleException.php';
require_once __DIR__ . '/GuzzleHttp/Exception/TransferException.php';
require_once __DIR__ . '/GuzzleHttp/Exception/RequestException.php';
require_once __DIR__ . '/GuzzleHttp/Exception/BadResponseException.php';
require_once __DIR__ . '/GuzzleHttp/Exception/ClientException.php';
require_once __DIR__ . '/GuzzleHttp/Exception/ConnectException.php';
require_once __DIR__ . '/GuzzleHttp/Exception/SeekException.php';
require_once __DIR__ . '/GuzzleHttp/Exception/ServerException.php';
require_once __DIR__ . '/GuzzleHttp/Exception/TooManyRedirectsException.php';
require_once __DIR__ . '/GuzzleHttp/functions.php';
require_once __DIR__ . '/GuzzleHttp/functions_include.php';
require_once __DIR__ . '/GuzzleHttp/Handler/CurlFactoryInterface.php';
require_once __DIR__ . '/GuzzleHttp/Handler/CurlFactory.php';
require_once __DIR__ . '/GuzzleHttp/Handler/CurlHandler.php';
require_once __DIR__ . '/GuzzleHttp/Handler/CurlMultiHandler.php';
require_once __DIR__ . '/GuzzleHttp/Handler/EasyHandle.php';
require_once __DIR__ . '/GuzzleHttp/Handler/MockHandler.php';
require_once __DIR__ . '/GuzzleHttp/Handler/Proxy.php';
require_once __DIR__ . '/GuzzleHttp/Handler/StreamHandler.php';
require_once __DIR__ . '/GuzzleHttp/HandlerStack.php';
require_once __DIR__ . '/GuzzleHttp/MessageFormatter.php';
require_once __DIR__ . '/GuzzleHttp/Middleware.php';
require_once __DIR__ . '/GuzzleHttp/PrepareBodyMiddleware.php';
require_once __DIR__ . '/GuzzleHttp/Promise/RejectionException.php';
require_once __DIR__ . '/GuzzleHttp/Promise/AggregateException.php';
require_once __DIR__ . '/GuzzleHttp/Promise/CancellationException.php';
require_once __DIR__ . '/GuzzleHttp/Promise/PromiseInterface.php';
require_once __DIR__ . '/GuzzleHttp/Promise/Promise.php';
require_once __DIR__ . '/GuzzleHttp/Promise/Coroutine.php';
require_once __DIR__ . '/GuzzleHttp/Promise/PromisorInterface.php';
require_once __DIR__ . '/GuzzleHttp/Promise/EachPromise.php';
require_once __DIR__ . '/GuzzleHttp/Promise/FulfilledPromise.php';
require_once __DIR__ . '/GuzzleHttp/Promise/functions.php';
require_once __DIR__ . '/GuzzleHttp/Promise/functions_include.php';
require_once __DIR__ . '/GuzzleHttp/Promise/RejectedPromise.php';
require_once __DIR__ . '/GuzzleHttp/Promise/TaskQueueInterface.php';
require_once __DIR__ . '/GuzzleHttp/Promise/TaskQueue.php';
require_once __DIR__ . '/GuzzleHttp/Pool.php';

require_once __DIR__ . '/GuzzleHttp/RedirectMiddleware.php';
require_once __DIR__ . '/GuzzleHttp/RequestOptions.php';
require_once __DIR__ . '/GuzzleHttp/RetryMiddleware.php';
require_once __DIR__ . '/GuzzleHttp/TransferStats.php';
require_once __DIR__ . '/GuzzleHttp/UriTemplate.php';

require_once __DIR__ . '/GuzzleHttp/Client.php';

require_once __DIR__ . '/JmesPath/AstRuntime.php';
require_once __DIR__ . '/JmesPath/CompilerRuntime.php';
require_once __DIR__ . '/JmesPath/DebugRuntime.php';
require_once __DIR__ . '/JmesPath/Env.php';
require_once __DIR__ . '/JmesPath/FnDispatcher.php';
require_once __DIR__ . '/JmesPath/JmesPath.php';
require_once __DIR__ . '/JmesPath/Lexer.php';
require_once __DIR__ . '/JmesPath/Parser.php';
require_once __DIR__ . '/JmesPath/SyntaxErrorException.php';
require_once __DIR__ . '/JmesPath/TreeCompiler.php';
require_once __DIR__ . '/JmesPath/TreeInterpreter.php';
require_once __DIR__ . '/JmesPath/Utils.php';


require_once __DIR__ . '/GuzzleHttp/Promise/PromiseInterface.php';

require_once __DIR__ . '/Aws/HasDataTrait.php';


require_once __DIR__ . '/Aws/HashingStream.php';
require_once __DIR__ . '/Aws/HashInterface.php';
require_once __DIR__ . '/Aws/HasMonitoringEventsTrait.php';
require_once __DIR__ . '/Aws/MonitoringEventsInterface.php';
require_once __DIR__ . '/Aws/ConfigurationProviderInterface.php';
require_once __DIR__ . '/Aws/AbstractConfigurationProvider.php';
require_once __DIR__ . '/Aws/Endpoint/EndpointProvider.php';
require_once __DIR__ . '/Aws/Endpoint/PartitionInterface.php';
require_once __DIR__ . '/Aws/Endpoint/Partition.php';
require_once __DIR__ . '/Aws/Endpoint/PartitionEndpointProvider.php';
require_once __DIR__ . '/Aws/Endpoint/PatternEndpointProvider.php';
require_once __DIR__ . '/Aws/EndpointDiscovery/ConfigurationInterface.php';
require_once __DIR__ . '/Aws/EndpointDiscovery/ConfigurationProvider.php';
require_once __DIR__ . '/Aws/EndpointDiscovery/Configuration.php';
require_once __DIR__ . '/Aws/EndpointDiscovery/EndpointDiscoveryMiddleware.php';
require_once __DIR__ . '/Aws/EndpointDiscovery/EndpointList.php';
require_once __DIR__ . '/Aws/EndpointDiscovery/Exception/ConfigurationException.php';
require_once __DIR__ . '/Aws/EndpointParameterMiddleware.php';

require_once __DIR__ . '/Aws/WrappedHttpHandler.php';
require_once __DIR__ . '/Aws/Sdk.php';
require_once __DIR__ . '/Aws/IdempotencyTokenMiddleware.php';

require_once __DIR__ . '/Aws/ClientSideMonitoring/MonitoringMiddlewareInterface.php';
require_once __DIR__ . '/Aws/ClientResolver.php';
require_once __DIR__ . '/Aws/ClientSideMonitoring/AbstractMonitoringMiddleware.php';
require_once __DIR__ . '/Aws/ClientSideMonitoring/ApiCallAttemptMonitoringMiddleware.php';
require_once __DIR__ . '/Aws/ClientSideMonitoring/ApiCallMonitoringMiddleware.php';
require_once __DIR__ . '/Aws/ClientSideMonitoring/ConfigurationInterface.php';
require_once __DIR__ . '/Aws/ClientSideMonitoring/Configuration.php';
require_once __DIR__ . '/Aws/ClientSideMonitoring/ConfigurationProvider.php';
require_once __DIR__ . '/Aws/ClientSideMonitoring/Exception/ConfigurationException.php';

require_once __DIR__ . '/Aws/Retry/ConfigurationInterface.php';
require_once __DIR__ . '/Aws/Retry/Configuration.php';
require_once __DIR__ . '/Aws/Retry/ConfigurationProvider.php';
require_once __DIR__ . '/Aws/Retry/Exception/ConfigurationException.php';
require_once __DIR__ . '/Aws/Retry/QuotaManager.php';
require_once __DIR__ . '/Aws/Retry/RateLimiter.php';
require_once __DIR__ . '/Aws/Retry/RetryHelperTrait.php';
require_once __DIR__ . '/Aws/RetryMiddleware.php';
require_once __DIR__ . '/Aws/RetryMiddlewareV2.php';

require_once __DIR__ . '/Aws/Credentials/AssumeRoleCredentialProvider.php';
require_once __DIR__ . '/Aws/Credentials/AssumeRoleWithWebIdentityCredentialProvider.php';
require_once __DIR__ . '/Aws/Credentials/CredentialProvider.php';
require_once __DIR__ . '/Aws/Credentials/CredentialsInterface.php';
require_once __DIR__ . '/Aws/Credentials/Credentials.php';
require_once __DIR__ . '/Aws/Credentials/EcsCredentialProvider.php';
require_once __DIR__ . '/Aws/Credentials/InstanceProfileProvider.php';

require_once __DIR__ . '/Aws/StreamRequestPayloadMiddleware.php';
require_once __DIR__ . '/Aws/CommandInterface.php';
require_once __DIR__ . '/Aws/CommandPool.php';
require_once __DIR__ . '/Aws/Command.php';

require_once __DIR__ . '/Aws/Middleware.php';
require_once __DIR__ . '/Aws/ClientResolver.php';
require_once __DIR__ . '/Aws/HandlerList.php';
require_once __DIR__ . '/Aws/AwsClientTrait.php';
require_once __DIR__ . '/Aws/AwsClientInterface.php';
require_once __DIR__ . '/Aws/AwsClient.php';

require_once __DIR__ . '/Aws/Api/Parser/PayloadParserTrait.php';

require_once __DIR__ . '/Aws/ResponseContainerInterface.php';
require_once __DIR__ . '/Aws/Exception/AwsException.php';
require_once __DIR__ . '/Aws/Exception/CouldNotCreateChecksumException.php';
require_once __DIR__ . '/Aws/Exception/CredentialsException.php';
require_once __DIR__ . '/Aws/Exception/EventStreamDataException.php';
require_once __DIR__ . '/Aws/Exception/IncalculablePayloadException.php';
require_once __DIR__ . '/Aws/Exception/InvalidJsonException.php';
require_once __DIR__ . '/Aws/Exception/InvalidRegionException.php';
require_once __DIR__ . '/Aws/Exception/MultipartUploadException.php';
require_once __DIR__ . '/Aws/Exception/UnresolvedApiException.php';
require_once __DIR__ . '/Aws/Exception/UnresolvedEndpointException.php';
require_once __DIR__ . '/Aws/Exception/UnresolvedSignatureException.php';

require_once __DIR__ . '/Aws/ResourceGroups/Exception/ResourceGroupsException.php';
require_once __DIR__ . '/Aws/ResourceGroups/ResourceGroupsClient.php';
require_once __DIR__ . '/Aws/ResourceGroupsTaggingAPI/Exception/ResourceGroupsTaggingAPIException.php';
require_once __DIR__ . '/Aws/ResourceGroupsTaggingAPI/ResourceGroupsTaggingAPIClient.php';

require_once __DIR__ . '/Aws/ResultInterface.php';
require_once __DIR__ . '/Aws/Result.php';
require_once __DIR__ . '/Aws/ResultPaginator.php';


require_once __DIR__ . '/Aws/Sts/Exception/StsException.php';
require_once __DIR__ . '/Aws/Sts/RegionalEndpoints/ConfigurationInterface.php';
require_once __DIR__ . '/Aws/Sts/RegionalEndpoints/Configuration.php';
require_once __DIR__ . '/Aws/Sts/RegionalEndpoints/ConfigurationProvider.php';
require_once __DIR__ . '/Aws/Sts/RegionalEndpoints/Exception/ConfigurationException.php';
require_once __DIR__ . '/Aws/Sts/StsClient.php';


require_once __DIR__ . '/Aws/Crypto/AesStreamInterface.php';
require_once __DIR__ . '/Aws/Crypto/MetadataStrategyInterface.php';
require_once __DIR__ . '/Aws/Crypto/AbstractCryptoClient.php';
require_once __DIR__ . '/Aws/Crypto/AesDecryptingStream.php';
require_once __DIR__ . '/Aws/Crypto/AesEncryptingStream.php';
require_once __DIR__ . '/Aws/Crypto/AesGcmDecryptingStream.php';
require_once __DIR__ . '/Aws/Crypto/AesGcmEncryptingStream.php';
require_once __DIR__ . '/Aws/Crypto/Cipher/CipherMethod.php';
require_once __DIR__ . '/Aws/Crypto/Cipher/Cbc.php';
require_once __DIR__ . '/Aws/Crypto/Cipher/CipherBuilderTrait.php';
require_once __DIR__ . '/Aws/Crypto/DecryptionTrait.php';
require_once __DIR__ . '/Aws/Crypto/EncryptionTrait.php';
require_once __DIR__ . '/Aws/Crypto/MaterialsProvider.php';
require_once __DIR__ . '/Aws/Crypto/KmsMaterialsProvider.php';
require_once __DIR__ . '/Aws/Crypto/MetadataEnvelope.php';

require_once __DIR__ . '/Aws/Api/AbstractModel.php';
require_once __DIR__ . '/Aws/Api/ApiProvider.php';
require_once __DIR__ . '/Aws/Api/DateTimeResult.php';
require_once __DIR__ . '/Aws/Api/DocModel.php';
require_once __DIR__ . '/Aws/Api/Parser/MetadataParserTrait.php';
require_once __DIR__ . '/Aws/Api/ErrorParser/AbstractErrorParser.php';
require_once __DIR__ . '/Aws/Api/ErrorParser/JsonParserTrait.php';
require_once __DIR__ . '/Aws/Api/ErrorParser/JsonRpcErrorParser.php';
require_once __DIR__ . '/Aws/Api/ErrorParser/RestJsonErrorParser.php';
require_once __DIR__ . '/Aws/Api/ErrorParser/XmlErrorParser.php';
require_once __DIR__ . '/Aws/Api/ShapeMap.php';
require_once __DIR__ . '/Aws/Api/Shape.php';
require_once __DIR__ . '/Aws/Api/ListShape.php';
require_once __DIR__ . '/Aws/Api/MapShape.php';
require_once __DIR__ . '/Aws/Api/Operation.php';
require_once __DIR__ . '/Aws/Api/Parser/AbstractParser.php';
require_once __DIR__ . '/Aws/Api/Parser/AbstractRestParser.php';
require_once __DIR__ . '/Aws/Api/Parser/Crc32ValidatingParser.php';
require_once __DIR__ . '/Aws/Api/Parser/DecodingEventStreamIterator.php';
require_once __DIR__ . '/Aws/Api/Parser/EventParsingIterator.php';
require_once __DIR__ . '/Aws/Api/Parser/Exception/ParserException.php';
require_once __DIR__ . '/Aws/Api/Parser/JsonParser.php';
require_once __DIR__ . '/Aws/Api/Parser/JsonRpcParser.php';
require_once __DIR__ . '/Aws/Api/Parser/PayloadParserTrait.php';
require_once __DIR__ . '/Aws/Api/Parser/QueryParser.php';
require_once __DIR__ . '/Aws/Api/Parser/RestJsonParser.php';
require_once __DIR__ . '/Aws/Api/Parser/RestXmlParser.php';
require_once __DIR__ . '/Aws/Api/Parser/XmlParser.php';
require_once __DIR__ . '/Aws/Api/Serializer/QueryParamBuilder.php';
require_once __DIR__ . '/Aws/Api/Serializer/Ec2ParamBuilder.php';
require_once __DIR__ . '/Aws/Api/Serializer/JsonBody.php';
require_once __DIR__ . '/Aws/Api/Serializer/JsonRpcSerializer.php';
require_once __DIR__ . '/Aws/Api/Serializer/QuerySerializer.php';
require_once __DIR__ . '/Aws/Api/Serializer/RestSerializer.php';
require_once __DIR__ . '/Aws/Api/Serializer/RestJsonSerializer.php';
require_once __DIR__ . '/Aws/Api/Serializer/RestXmlSerializer.php';
require_once __DIR__ . '/Aws/Api/Serializer/XmlBody.php';
require_once __DIR__ . '/Aws/Api/Service.php';
require_once __DIR__ . '/Aws/Api/StructureShape.php';
require_once __DIR__ . '/Aws/Api/TimestampShape.php';
require_once __DIR__ . '/Aws/Api/Validator.php';
require_once __DIR__ . '/Aws/ApiGateway/ApiGatewayClient.php';
require_once __DIR__ . '/Aws/ApiGateway/Exception/ApiGatewayException.php';
require_once __DIR__ . '/Aws/ApiGatewayManagementApi/ApiGatewayManagementApiClient.php';
require_once __DIR__ . '/Aws/ApiGatewayManagementApi/Exception/ApiGatewayManagementApiException.php';
require_once __DIR__ . '/Aws/ApiGatewayV2/ApiGatewayV2Client.php';
require_once __DIR__ . '/Aws/ApiGatewayV2/Exception/ApiGatewayV2Exception.php';

require_once __DIR__ . '/Aws/Multipart/AbstractUploadManager.php';
require_once __DIR__ . '/Aws/Multipart/AbstractUploader.php';
require_once __DIR__ . '/Aws/Multipart/UploadState.php';
require_once __DIR__ . '/Aws/MultiRegionClient.php';

require_once __DIR__ . '/Aws/Signature/SignatureInterface.php';
require_once __DIR__ . '/Aws/Signature/AnonymousSignature.php';
require_once __DIR__ . '/Aws/Signature/SignatureTrait.php';
require_once __DIR__ . '/Aws/Signature/SignatureV4.php';
require_once __DIR__ . '/Aws/Signature/S3SignatureV4.php';
require_once __DIR__ . '/Aws/Signature/SignatureProvider.php';
require_once __DIR__ . '/Aws/signer/Exception/signerException.php';
require_once __DIR__ . '/Aws/signer/signerClient.php';

require_once __DIR__ . '/Aws/Arn/ArnInterface.php';
require_once __DIR__ . '/Aws/Arn/Arn.php';
require_once __DIR__ . '/Aws/Arn/ResourceTypeAndIdTrait.php';
require_once __DIR__ . '/Aws/Arn/AccessPointArn.php';
require_once __DIR__ . '/Aws/Arn/S3/AccessPointArn.php';
require_once __DIR__ . '/Aws/Arn/ArnParser.php';
require_once __DIR__ . '/Aws/Arn/Exception/InvalidArnException.php';

require_once __DIR__ . '/Aws/S3/AmbiguousSuccessParser.php';
require_once __DIR__ . '/Aws/S3/ApplyChecksumMiddleware.php';
require_once __DIR__ . '/Aws/S3/BatchDelete.php';
require_once __DIR__ . '/Aws/S3/BucketEndpointArnMiddleware.php';
require_once __DIR__ . '/Aws/S3/BucketEndpointMiddleware.php';
require_once __DIR__ . '/Aws/S3/MultipartUploadingTrait.php';
require_once __DIR__ . '/Aws/S3/MultipartUploader.php';
require_once __DIR__ . '/Aws/S3/MultipartCopy.php';
require_once __DIR__ . '/Aws/S3/Exception/S3MultipartUploadException.php';
require_once __DIR__ . '/Aws/S3/Exception/S3Exception.php';
require_once __DIR__ . '/Aws/S3/Exception/DeleteMultipleObjectsException.php';
require_once __DIR__ . '/Aws/S3/Exception/PermanentRedirectException.php';
require_once __DIR__ . '/Aws/S3/GetBucketLocationParser.php';
require_once __DIR__ . '/Aws/S3/ObjectCopier.php';
require_once __DIR__ . '/Aws/S3/ObjectUploader.php';
require_once __DIR__ . '/Aws/S3/PermanentRedirectMiddleware.php';
require_once __DIR__ . '/Aws/S3/PostObject.php';
require_once __DIR__ . '/Aws/S3/PostObjectV4.php';
require_once __DIR__ . '/Aws/S3/PutObjectUrlMiddleware.php';
require_once __DIR__ . '/Aws/S3/Crypto/CryptoParamsTrait.php';
require_once __DIR__ . '/Aws/S3/Crypto/HeadersMetadataStrategy.php';
require_once __DIR__ . '/Aws/S3/Crypto/InstructionFileMetadataStrategy.php';
require_once __DIR__ . '/Aws/S3/Crypto/S3EncryptionClient.php';
require_once __DIR__ . '/Aws/S3/Crypto/S3EncryptionMultipartUploader.php';
require_once __DIR__ . '/Aws/S3/RegionalEndpoint/ConfigurationInterface.php';
require_once __DIR__ . '/Aws/S3/RegionalEndpoint/Configuration.php';
require_once __DIR__ . '/Aws/S3/RegionalEndpoint/ConfigurationProvider.php';
require_once __DIR__ . '/Aws/S3/RegionalEndpoint/Exception/ConfigurationException.php';
require_once __DIR__ . '/Aws/S3/RetryableMalformedResponseParser.php';

require_once __DIR__ . '/Aws/S3/S3ClientTrait.php';
require_once __DIR__ . '/Aws/S3/S3ClientInterface.php';
require_once __DIR__ . '/Aws/S3/S3EndpointMiddleware.php';
require_once __DIR__ . '/Aws/S3/S3MultiRegionClient.php';
require_once __DIR__ . '/Aws/S3/S3UriParser.php';
require_once __DIR__ . '/Aws/S3/SSECMiddleware.php';
require_once __DIR__ . '/Aws/S3/StreamWrapper.php';
require_once __DIR__ . '/Aws/S3/Transfer.php';
require_once __DIR__ . '/Aws/S3/UseArnRegion/ConfigurationInterface.php';
require_once __DIR__ . '/Aws/S3/UseArnRegion/Configuration.php';
require_once __DIR__ . '/Aws/S3/UseArnRegion/ConfigurationProvider.php';
require_once __DIR__ . '/Aws/S3/UseArnRegion/Exception/ConfigurationException.php';
require_once __DIR__ . '/Aws/S3Control/Exception/S3ControlException.php';
require_once __DIR__ . '/Aws/S3Control/S3ControlClient.php';
require_once __DIR__ . '/Aws/S3Control/S3ControlEndpointMiddleware.php';

require_once __DIR__ . '/Aws/S3/S3Client.php';

require_once __DIR__ . '/Aws/Handler/GuzzleV6/GuzzleHandler.php';
//require_once __DIR__ . '/Aws/Handler/GuzzleV5/PsrStream.php';
//require_once __DIR__ . '/Aws/Handler/GuzzleV5/GuzzleStream.php';
//require_once __DIR__ . '/Aws/Handler/GuzzleV5/GuzzleHandler.php';

require_once __DIR__ . '/Aws/functions.php';