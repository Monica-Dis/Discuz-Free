<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
namespace Aws\Retry;

use Aws\Retry\Exception\ConfigurationException;
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

class Configuration implements ConfigurationInterface
{
    private $mode;
    private $maxAttempts;
    private $validModes = [
        'legacy',
        'standard',
        'adaptive'
    ];

    public function __construct($mode = 'legacy', $maxAttempts = 3)
    {
        $mode = strtolower($mode);
        if (!in_array($mode, $this->validModes)) {
            throw new ConfigurationException("'{$mode}' is not a valid mode."
                . " The mode has to be 'legacy', 'standard', or 'adaptive'.");
        }
        if (!is_numeric($maxAttempts)
            || intval($maxAttempts) != $maxAttempts
            || $maxAttempts < 1
        ) {
            throw new ConfigurationException("The 'maxAttempts' parameter has"
                . " to be an integer >= 1.");
        }

        $this->mode = $mode;
        $this->maxAttempts = intval($maxAttempts);
    }

    /**
     * {@inheritdoc}
     */
    public function getMode()
    {
        return $this->mode;
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxAttempts()
    {
        return $this->maxAttempts;
    }

    /**
     * {@inheritdoc}
     */
    public function toArray()
    {
        return [
            'mode' => $this->getMode(),
            'max_attempts' => $this->getMaxAttempts(),
        ];
    }
}
