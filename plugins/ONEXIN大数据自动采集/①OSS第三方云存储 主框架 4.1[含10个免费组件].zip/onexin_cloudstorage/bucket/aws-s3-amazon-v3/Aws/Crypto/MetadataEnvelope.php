<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
namespace Aws\Crypto;

use Aws\HasDataTrait;
use \ArrayAccess;
use \IteratorAggregate;
use \InvalidArgumentException;
use \JsonSerializable;
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

/**
 * Stores encryption metadata for reading and writing.
 *
 * @internal
 */
class MetadataEnvelope implements ArrayAccess, IteratorAggregate, JsonSerializable
{
    use HasDataTrait;

    const CONTENT_KEY_V2_HEADER = 'x-amz-key-v2';
    const IV_HEADER = 'x-amz-iv';
    const MATERIALS_DESCRIPTION_HEADER = 'x-amz-matdesc';
    const KEY_WRAP_ALGORITHM_HEADER = 'x-amz-wrap-alg';
    const CONTENT_CRYPTO_SCHEME_HEADER = 'x-amz-cek-alg';
    const CRYPTO_TAG_LENGTH_HEADER = 'x-amz-tag-len';
    const UNENCRYPTED_CONTENT_MD5_HEADER = 'x-amz-unencrypted-content-md5';
    const UNENCRYPTED_CONTENT_LENGTH_HEADER = 'x-amz-unencrypted-content-length';

    private static $constants = [];

    public static function getConstantValues()
    {
        if (empty(self::$constants)) {
            $reflection = new \ReflectionClass(static::class);
            foreach (array_values($reflection->getConstants()) as $constant) {
                self::$constants[$constant] = true;
            }
        }

        return array_keys(self::$constants);
    }

    public function offsetSet($name, $value)
    {
        $constants = self::getConstantValues();
        if (is_null($name) || !in_array($name, $constants)) {
            throw new InvalidArgumentException('MetadataEnvelope fields must'
                . ' must match a predefined offset; use the header constants.');
        }

        $this->data[$name] = $value;
    }

    public function jsonSerialize()
    {
        return $this->data;
    }
}
