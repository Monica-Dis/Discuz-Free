<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
namespace Aws;
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

/**
 * A command object encapsulates the input parameters used to control the
 * creation of a HTTP request and processing of a HTTP response.
 *
 * Using the toArray() method will return the input parameters of the command
 * as an associative array.
 */
interface CommandInterface extends \ArrayAccess, \Countable, \IteratorAggregate
{
    /**
     * Converts the command parameters to an array
     *
     * @return array
     */
    public function toArray();

    /**
     * Get the name of the command
     *
     * @return string
     */
    public function getName();

    /**
     * Check if the command has a parameter by name.
     *
     * @param string $name Name of the parameter to check
     *
     * @return bool
     */
    public function hasParam($name);

    /**
     * Get the handler list used to transfer the command.
     *
     * @return HandlerList
     */
    public function getHandlerList();
}
