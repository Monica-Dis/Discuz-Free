<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
namespace Aws\S3\Crypto;

use Aws\Crypto\MaterialsProvider;
use Aws\Crypto\MetadataEnvelope;
use Aws\Crypto\MetadataStrategyInterface;
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

trait CryptoParamsTrait
{
    protected function getMaterialsProvider(array $args)
    {
        if ($args['@MaterialsProvider'] instanceof MaterialsProvider) {
            return $args['@MaterialsProvider'];
        }

        throw new \InvalidArgumentException('An instance of MaterialsProvider'
            . ' must be passed in the "MaterialsProvider" field.');
    }

    protected function getInstructionFileSuffix(array $args)
    {
        return !empty($args['@InstructionFileSuffix'])
            ? $args['@InstructionFileSuffix']
            : $this->instructionFileSuffix;
    }

    protected function determineGetObjectStrategy(
        $result,
        $instructionFileSuffix
    ) {
        if (isset($result['Metadata'][MetadataEnvelope::CONTENT_KEY_V2_HEADER])) {
            return new HeadersMetadataStrategy();
        }

        return new InstructionFileMetadataStrategy(
            $this->client,
            $instructionFileSuffix
        );
    }

    protected function getMetadataStrategy(array $args, $instructionFileSuffix)
    {
        if (!empty($args['@MetadataStrategy'])) {
            if ($args['@MetadataStrategy'] instanceof MetadataStrategyInterface) {
                return $args['@MetadataStrategy'];
            }

            if (is_string($args['@MetadataStrategy'])) {
                switch ($args['@MetadataStrategy']) {
                    case HeadersMetadataStrategy::class:
                        return new HeadersMetadataStrategy();
                    case InstructionFileMetadataStrategy::class:
                        return new InstructionFileMetadataStrategy(
                            $this->client,
                            $instructionFileSuffix
                        );
                    default:
                        throw new \InvalidArgumentException('Could not match the'
                            . ' specified string in "MetadataStrategy" to a'
                            . ' predefined strategy.');
                }
            } else {
                throw new \InvalidArgumentException('The metadata strategy that'
                    . ' was passed to "MetadataStrategy" was unrecognized.');
            }
        } elseif ($instructionFileSuffix) {
            return new InstructionFileMetadataStrategy(
                $this->client,
                $instructionFileSuffix
            );
        }

        return null;
    }
}
