<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
namespace Aws\S3;

use Aws\CommandInterface;
use Psr\Http\Message\RequestInterface;
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

/**
 * Simplifies the SSE-C process by encoding and hashing the key.
 * @internal
 */
class SSECMiddleware
{
    private $endpointScheme;
    private $nextHandler;

    /**
     * Provide the URI scheme of the client sending requests.
     *
     * @param string $endpointScheme URI scheme (http/https).
     *
     * @return callable
     */
    public static function wrap($endpointScheme)
    {
        return function (callable $handler) use ($endpointScheme) {
            return new self($endpointScheme, $handler);
        };
    }

    public function __construct($endpointScheme, callable $nextHandler)
    {
        $this->nextHandler = $nextHandler;
        $this->endpointScheme = $endpointScheme;
    }

    public function __invoke(
        CommandInterface $command,
        RequestInterface $request = null
    ) {
        // Allows only HTTPS connections when using SSE-C
        if (($command['SSECustomerKey'] || $command['CopySourceSSECustomerKey'])
            && $this->endpointScheme !== 'https'
        ) {
            throw new \RuntimeException('You must configure your S3 client to '
                . 'use HTTPS in order to use the SSE-C features.');
        }

        // Prepare the normal SSE-CPK headers
        if ($command['SSECustomerKey']) {
            $this->prepareSseParams($command);
        }

        // If it's a copy operation, prepare the SSE-CPK headers for the source.
        if ($command['CopySourceSSECustomerKey']) {
            $this->prepareSseParams($command, 'CopySource');
        }

        $f = $this->nextHandler;
        return $f($command, $request);
    }

    private function prepareSseParams(CommandInterface $command, $prefix = '')
    {
        // Base64 encode the provided key
        $key = $command[$prefix . 'SSECustomerKey'];
        $command[$prefix . 'SSECustomerKey'] = base64_encode($key);

        // Base64 the provided MD5 or, generate an MD5 if not provided
        if ($md5 = $command[$prefix . 'SSECustomerKeyMD5']) {
            $command[$prefix . 'SSECustomerKeyMD5'] = base64_encode($md5);
        } else {
            $command[$prefix . 'SSECustomerKeyMD5'] = base64_encode(md5($key, true));
        }
    }
}
