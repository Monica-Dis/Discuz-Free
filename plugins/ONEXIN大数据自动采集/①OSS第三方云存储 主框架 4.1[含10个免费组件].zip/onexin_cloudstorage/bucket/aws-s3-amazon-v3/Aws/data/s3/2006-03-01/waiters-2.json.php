<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/
 
// This file was auto-generated from sdk-root/src/data/s3/2006-03-01/waiters-2.json
return [ 'version' => 2, 'waiters' => [ 'BucketExists' => [ 'delay' => 5, 'operation' => 'HeadBucket', 'maxAttempts' => 20, 'acceptors' => [ [ 'expected' => 200, 'matcher' => 'status', 'state' => 'success', ], [ 'expected' => 301, 'matcher' => 'status', 'state' => 'success', ], [ 'expected' => 403, 'matcher' => 'status', 'state' => 'success', ], [ 'expected' => 404, 'matcher' => 'status', 'state' => 'retry', ], ], ], 'BucketNotExists' => [ 'delay' => 5, 'operation' => 'HeadBucket', 'maxAttempts' => 20, 'acceptors' => [ [ 'expected' => 404, 'matcher' => 'status', 'state' => 'success', ], ], ], 'ObjectExists' => [ 'delay' => 5, 'operation' => 'HeadObject', 'maxAttempts' => 20, 'acceptors' => [ [ 'expected' => 200, 'matcher' => 'status', 'state' => 'success', ], [ 'expected' => 404, 'matcher' => 'status', 'state' => 'retry', ], ], ], 'ObjectNotExists' => [ 'delay' => 5, 'operation' => 'HeadObject', 'maxAttempts' => 20, 'acceptors' => [ [ 'expected' => 404, 'matcher' => 'status', 'state' => 'success', ], ], ], ],];
