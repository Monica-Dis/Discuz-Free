<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
namespace Aws;

use Aws\Api\Service;
use Psr\Http\Message\RequestInterface;
use Psr\Log\InvalidArgumentException;
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

/**
 * Used to update the host based on a modeled endpoint trait
 *
 * IMPORTANT: this middleware must be added after the "build" step.
 *
 * @internal
 */
class EndpointParameterMiddleware
{
    /** @var callable */
    private $nextHandler;

    /** @var Service */
    private $service;

    /**
     * Create a middleware wrapper function
     *
     * @param Service $service
     * @param array $args
     * @return \Closure
     */
    public static function wrap(Service $service)
    {
        return function (callable $handler) use ($service) {
            return new self($handler, $service);
        };
    }

    public function __construct(callable $nextHandler, Service $service)
    {
        $this->nextHandler = $nextHandler;
        $this->service = $service;
    }

    public function __invoke(CommandInterface $command, RequestInterface $request)
    {
        $nextHandler = $this->nextHandler;

        $operation = $this->service->getOperation($command->getName());

        if (!empty($operation['endpoint']['hostPrefix'])) {
            $prefix = $operation['endpoint']['hostPrefix'];

            // Captures endpoint parameters stored in the modeled host.
            // These are denoted by enclosure in braces, i.e. '{param}'
            preg_match_all("/\{([a-zA-Z0-9]+)}/", $prefix, $parameters);

            if (!empty($parameters[1])) {

                // Captured parameters without braces stored in $parameters[1],
                // which should correspond to members in the Command object
                foreach ($parameters[1] as $index => $parameter) {
                    if (empty($command[$parameter])) {
                        throw new \InvalidArgumentException(
                            "The parameter '{$parameter}' must be set and not empty."
                        );
                    }

                    // Captured parameters with braces stored in $parameters[0],
                    // which are replaced by their corresponding Command value
                    $prefix = str_replace(
                        $parameters[0][$index],
                        $command[$parameter],
                        $prefix
                    );
                }
            }

            $uri = $request->getUri();
            $host = $prefix . $uri->getHost();
            if (!\Aws\is_valid_hostname($host)) {
                throw new \InvalidArgumentException(
                    "The supplied parameters result in an invalid hostname: '{$host}'."
                );
            }
            $request = $request->withUri($uri->withHost($host));
        }

        return $nextHandler($command, $request);
    }
}
