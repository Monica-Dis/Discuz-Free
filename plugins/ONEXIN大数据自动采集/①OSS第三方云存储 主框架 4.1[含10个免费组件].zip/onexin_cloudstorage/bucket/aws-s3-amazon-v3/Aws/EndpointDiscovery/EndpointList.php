<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
namespace Aws\EndpointDiscovery;
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

class EndpointList
{
    private $active;
    private $expired = [];

    public function __construct(array $endpoints)
    {
        $this->active = $endpoints;
        reset($this->active);
    }

    /**
     * Gets an active (unexpired) endpoint. Returns null if none found.
     *
     * @return null|string
     */
    public function getActive()
    {
        if (count($this->active) < 1) {
            return null;
        }
        while (time() > current($this->active)) {
            $key = key($this->active);
            $this->expired[$key] = current($this->active);
            $this->increment($this->active);
            unset($this->active[$key]);
            if (count($this->active) < 1) {
                return null;
            }
        }
        $active = key($this->active);
        $this->increment($this->active);
        return $active;
    }

    /**
     * Gets an active endpoint if possible, then an expired endpoint if possible.
     * Returns null if no endpoints found.
     *
     * @return null|string
     */
    public function getEndpoint()
    {
        if (!empty($active = $this->getActive())) {
            return $active;
        }
        return $this->getExpired();
    }

    /**
     * Removes an endpoint from both lists.
     *
     * @param string $key
     */
    public function remove($key)
    {
        unset($this->active[$key]);
        unset($this->expired[$key]);
    }

    /**
     * Get an expired endpoint. Returns null if none found.
     *
     * @return null|string
     */
    private function getExpired()
    {
        if (count($this->expired) < 1) {
            return null;
        }
        $expired = key($this->expired);
        $this->increment($this->expired);
        return $expired;
    }

    private function increment(&$array)
    {
        if (next($array) === false) {
            reset($array);
        }
    }
}
