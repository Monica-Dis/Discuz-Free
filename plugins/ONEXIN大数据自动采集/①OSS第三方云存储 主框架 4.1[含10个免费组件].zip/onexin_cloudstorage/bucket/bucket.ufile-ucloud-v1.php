<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-27
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

//空间域名后缀,请查看控制台上空间域名再配置此处
https://docs.ucloud.cn/storage_cdn/ufile/tools/introduction

*/

include_once __DIR__ . '/ufile-ucloud-v1/src/UCloud/proxy.php';
	
//--------------------------------------------------------------

	function _bucket_put($object, $content, $mode = 'file', $options = null){
		if(empty($object)) return true;
		$object = _bucket_clear($object);
		
		$_conf     = _bucket_config();
		$bucket    = $_conf['bucket'];
	
		new UCLOUD_API($_conf['access_key'], $_conf['secret_key'], '.'.$_conf['host']);
		//该接口适用于0-10MB小文件,更大的文件建议使用分片上传接口
		list($data, $code) = UCloud_PutFile($bucket, $object, $content);
		return $code == 200 ? true : false;
	}
	
	function _bucket_get($local_file, $object, $options = null){
	}
	
	function _bucket_size($object){
	}
	
	function _bucket_delete($object){
		if(empty($object)) return true;
		$object = _bucket_clear($object);
		
		$_conf     = _bucket_config();
		$bucket    = $_conf['bucket'];
		
		new UCLOUD_API($_conf['access_key'], $_conf['secret_key'], '.'.$_conf['host']);
		list($data, $code) = UCloud_Delete($bucket, $object);
		return $code == 204 ? true : false;
	}
	
	function _bucket_is($keyFile){
	}
	
	function _bucket_clear($str){ 
		// Local  ~ /www/dx3/;
		$str = str_replace('./', '/', $str);
		$str = str_replace('//', '/', $str); 
		//$str = str_replace('..', '', $str);
		// Bucket ~ /bucket.jpg
		if($str{0} == '/') $str = ltrim($str, '/');
		return $str;
	}
	
	function _bucket_config(){
		global $_G;

		$_bucket_conf     = $_G['cache']['plugin']['onexin_cloudstorage'];
		//config your information	
		$_conf =
			array(
				'access_key' => $_bucket_conf['access_key'],
				'secret_key' => $_bucket_conf['secret_key'],
				'endpoint' => 'http://'.$_bucket_conf['host'],
				'host' => $_bucket_conf['host'],
				'protocol' => 'http',
				'bucket' => $_bucket_conf['bucket'],
			);
		
		return $_conf;
	}
