<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
============================================================================
 * 
 * @package onexin_cloudstorage
 * @date 2018-02-01
 * @author King 
 * @copyright Copyright (c) 2018 Onexin Platform Inc. (http://www.onexin.com)
 */

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

/**
 * //--------------Tall us what you think!----------------------------------
 */


	function _bucket_put($target, $source, $mode = 'file', $options = null){
		return _bos_request("PUT", $source, $target);
	}
	
	function _bucket_get($local_file, $target, $options = null){
	}
	
	function _bucket_size($target){
	}
	
	function _bucket_delete($target){
		return _bos_request("DELETE", '', $target);
	}
	
	function _bucket_is($keyFile){
	}
	
	function _bucket_clear($str){ 
		// Local  ~ /www/dx3/;
		$str = str_replace('./', '/', $str);
		$str = str_replace('//', '/', $str); 
		// Bucket ~ /bucket.jpg
		if($str{0} != '/') $str = '/' . $str;
		return str_replace('..', '', $str);
	}
	
//--------------------------------------------------------------

function _bos_request($method = "PUT", $localpath, $path){
	global $_G;

	if(empty($path)) return true;
	$path = _bucket_clear($path);
	//echo $path;

	date_default_timezone_set('UTC');
	$timestamp = date("Y-m-d") . "T" . date("H:i:s") . "Z";
	
	$_bucket_conf = $_G['cache']['plugin']['onexin_cloudstorage'];	
	$bucket      = $_bucket_conf['bucket'];
	$host        = $_bucket_conf['host'];
	$access_key  = $_bucket_conf['access_key'];
	$secret_key  = $_bucket_conf['secret_key'];
	
	$expiration_in_seconds = "3600";

	$raw_session_key = "bce-auth-v1" . "/" . $access_key . "/" . $timestamp . "/" . $expiration_in_seconds;
	$session_key = hash_hmac('SHA256', $raw_session_key, $secret_key);
	$canonical_uri = '/' . $bucket . $path;
	$canonical_query_string = "";
	$canonical_headers = "host:" . $host . "\n" . "x-bce-date:" . urlencode($timestamp);
	$raw_signature = $method . "\n" . $canonical_uri . "\n" . $canonical_query_string . "\n" . $canonical_headers;
	 
	// $raw_signature 
	$signature = hash_hmac('SHA256', $raw_signature, $session_key);
	$signed_headers = "host;" . "x-bce-date";
	$Authorization = "{$raw_session_key}/{$signed_headers}/{$signature}";
	$headers = array("Authorization:{$Authorization}", "x-bce-date:{$timestamp}"); 
	
	$url = 'http://' . $host . $canonical_uri;
	$ch = curl_init($url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
	curl_setopt($ch, CURLOPT_POST, 1);
	if(!empty($localpath)){
		$length = filesize($localpath);
		$resource = fopen($localpath, 'r');
		curl_setopt($ch, CURLOPT_INFILE, $resource);
		curl_setopt($ch, CURLOPT_INFILESIZE, $length);
		curl_setopt($ch, CURLOPT_UPLOAD, 1);
	}
	curl_setopt($ch, CURLOPT_TIMEOUT, 30);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 0);
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
	$response = curl_exec($ch);
	$status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	curl_close($ch);
	if(!empty($localpath)){
		fclose($resource);
	} 
	
	// PUT ~ 200 OK
	// DELETE ~ 204 No Content
	// print_r($status);
	// print $response;
	
	if ($status == 200 || $status == 204){
		return true;
	}else{
		return false;
	}
}
