<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-08
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/Result.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Core/MimeTypes.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Core/NosException.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Http/RequestCore.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Http/RequestCore_Exception.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Http/ResponseCore.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/BucketInfo.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/BucketListInfo.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/DeleteFailedInfo.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/ListMultipartUploadInfo.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/ListPartsInfo.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/ObjectInfo.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/ObjectListInfo.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/PartInfo.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/UploadInfo.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Model/XmlConfig.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/aclResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/BodyResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/ExistResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/GetLocationResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/GetObjectMetaResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/InitiateMultipartUploadResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/ListBucketsResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/ListMultipartUploadResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/ListObjectsResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/ListPartsResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/MultiDeleteResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/ObjDeduplicateResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/PutSetDeleteResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/statusResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Result/UploadPartResult.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/Core/NosUtil.php';
require_once __DIR__ . '/nos-163yun-v1/src/NOS/NosClient.php';

	
//--------------------------------------------------------------

	function _bucket_put($object, $content, $mode = 'file', $options = NULL){
		if(empty($object)) return false;
		$object = _bucket_clear($object);

		$_conf = _bucket_config();
		$bucket = $_conf['bucket'];
		$nosClient = new NosClient($_conf['access_key'], $_conf['secret_key'], $_conf['endpoint']);
		$result = $nosClient->uploadFile($bucket, $object, $content);
		return $result['status'] == 200 && empty($result['code']) ? true : false;
	}
	
	function _bucket_get($local_path, $object, $options = NULL){
		if(empty($object)) return true;
		$object = _bucket_clear($object);
		
		$_conf     = _bucket_config();
		$bucket    = $_conf['bucket'];
		$nosClient = new NosClient($_conf['access_key'], $_conf['secret_key'], $_conf['endpoint']);
		$timeout = '3600';
		$signedUrl = $nosClient->signUrl($bucket, $object, $timeout);		
		if(empty($local_file)){
			dheader('location:'.$signedUrl);
		}else{
			echo dfsockopen($signedUrl);
		}
		return true;
	}
	
	function _bucket_size($object){
	}
	
	function _bucket_delete($object){
		if(empty($object)) return false;
		$object = _bucket_clear($object);

		$_conf = _bucket_config();
		$bucket = $_conf['bucket'];
		$nosClient = new NosClient($_conf['access_key'], $_conf['secret_key'], $_conf['endpoint']);
		$result = $nosClient->deleteObject($bucket, $object);
		return $result['status'] == 200 && empty($result['code']) ? true : false;
	}
	
	function _bucket_is($keyFile){
	}
	
	function _bucket_clear($str){ 
		// Local  ~ /www/dx3/;
		$str = str_replace('./', '/', $str);
		$str = str_replace('//', '/', $str); 
		// Bucket ~ /bucket.jpg
		if($str[0] == '/') $str = ltrim($str, '/');
		return str_replace('..', '', $str);
	}
	
	function _bucket_config(){
		global $_G;

		$_bucket_conf     = $_G['cache']['plugin']['onexin_cloudstorage'];
		//config your information	
		$_conf =
			array(
				'access_key' => $_bucket_conf['access_key'],
				'secret_key' => $_bucket_conf['secret_key'],
				'region' => $_bucket_conf['region'],
				'endpoint' => $_bucket_conf['host'],
				'protocol' => 'http',
				'bucket' => $_bucket_conf['bucket'],
			);
		
		return $_conf;
	}

