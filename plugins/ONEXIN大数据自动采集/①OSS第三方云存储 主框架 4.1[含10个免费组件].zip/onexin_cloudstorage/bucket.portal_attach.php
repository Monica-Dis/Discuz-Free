<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2018-02-01
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/
	
	if(!empty($_GET['optid'])){
		$result = _onexin_cloudstroage_portal_attach(intval($_GET['optid']), 10, '=');
	}
	
	function _onexin_cloudstroage_portal_attach($id, $perpage = 10, $den = '>='){
		global $_G;
		
		if(empty($id)) return array();
		
		$limit = $perpage; $nextid = ''; $list = array();
		
		// first='1' AND 
		$result = DB::fetch_all("SELECT * FROM ".DB::table("portal_attachment")." WHERE attachid{$den}'$id' ORDER BY attachid ASC LIMIT $limit");
		foreach($result as $attach){
			$nextid = $attach['attachid'];
			$id = $attach['aid'];
			$aid = $attach['attachid'];
			
			// attach getglobal('setting/attachdir').'/'.$arg1;
			$file = $_G['setting']['attachdir'].'portal/'.$attach['attachment'];
			$target = $_G['setting']['ftp']['attachdir'].'/portal/'.$attach['attachment'];
				$url = $_G['setting']['ftp']['attachurl']._bucket_clear($target);
			
			if($attach['remote']) {
	
				// article pic
				DB::query("UPDATE ".DB::table('portal_article_title')." SET remote='1' WHERE aid='$id' AND pic='portal/$attach[attachment]'");
				
				// article content
				DB::query("UPDATE ".DB::table('portal_article_content')." SET `content` = replace (`content`, '\"data/attachment/portal/$attach[attachment]', '\"$url')");
				continue;
			}
			
			if(!empty($_GET['operation'])) {
				echo "AID: ".$attach['attachid']." ID: ".$attach['aid']."<BR>";
			}
			
			if(!file_exists($file)){
				continue;
			}
			
			if (_bucket_put($target, $file)) {
				if(!empty($_GET['operation'])) {
					echo "IMG: ".$url."<BR>";
				}
				//@unlink( $_G['setting']['attachdir'].'/portal/'.$attach['attachment'] );
				
				DB::query("UPDATE ".DB::table("portal_attachment")." SET remote='1' WHERE attachid='$aid'");
				
				$minutes = 3000;
				$list[$aid] = $url;
			}	
					
		}
		$result = array();
		$result['oss'] = $list;
		$result['nextid'] = $nextid;
	
		return $result;
	}