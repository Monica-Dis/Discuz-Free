<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-05-07
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

// Local  ~ /www/dx3/test/abc.jpg;
$source = '/www/dx3/test/abc.jpg';

// Bucket ~ /bucket.jpg
$target = '/bucket.jpg';

_bucket_put($target, $source);

_bucket_delete($target);

//------------------------------

//echo "BUCKET;";
include_once DISCUZ_ROOT.'./source/plugin/onexin_cloudstorage/function_bucket.php';

*/

//------------------------------------------

		global $_G;
		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		//print "BUCKET;".$_G['cache']['plugin']['onexin_cloudstorage']['sdk'];exit;
		include_once DISCUZ_ROOT.'./source/plugin/onexin_cloudstorage/bucket/bucket.'.$_G['cache']['plugin']['onexin_cloudstorage']['sdk'].'.php';

//------------------------------------------

function _bucket_ftpcmd($cmd, $arg1 = '') {
	if(preg_match("/\/\/pan.baidu.com\//", $arg1)) return false;
	$ftpon = getglobal('setting/ftp/on');
	if(!$ftpon) {
		return $cmd == 'error' ? -101 : 0;
	}
	switch ($cmd) {
		case 'upload' : return _bucket_put($arg1, getglobal('setting/attachdir').'/'.$arg1); break;
		case 'delete' : return _bucket_delete($arg1); break;
		//case 'close'  : return _bucket_close(); break;
		//case 'error'  : return _bucket_error(); break;
		//case 'object' : return $ftp; break;
		default       : return false;
	}
}

