<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-03-30
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/
include DISCUZ_ROOT.'./source/plugin/onexin_cloudstorage/function_bucket.php';

cpheader();

$arr = explode(',', $_GET['pertask']);
if(!empty($arr[1])) {
	$_GET['current'] = trim($arr[0]);	
	$_GET['pertask'] = trim($arr[1]);	
}

$pertask = isset($_GET['pertask']) ? intval($_GET['pertask']) : 100;
$current = isset($_GET['current']) && $_GET['current'] > 0 ? intval($_GET['current']) : 0;
$next = $current + $pertask;

$identifier = $plugin['identifier'];
$dourl = "operation=config&do=$pluginid&identifier=$identifier&pmod=onexin_counter&";

if(submitcheck('threadsubmit', 1)) {

	$nextlink = $dourl."action=plugins&current=$next&pertask=$pertask&threadsubmit=yes";
	$processed = 0;
	
	_onexin_counter_include('forum', $dourl);
	
	// thread
	$result = DB::fetch_all("SELECT tid FROM ".DB::table('forum_thread')." WHERE tid>='$current' ORDER BY tid ASC LIMIT $pertask");
	foreach($result as $attach){
		$nextid = $attach['tid'];
		$result = _onexin_cloudstroage_forum($current, $pertask);
		if(!empty($nextid)) {
			$processed = 1;
		}
	}

	if($processed) {
		cpmsg("$lang[counter_thread]: ".cplang('counter_processing', array('current' => $current, 'next' => $next)), $nextlink, 'loading');
	} else {
		cpmsg('counter_thread_succeed', $dourl."action=plugins", 'succeed');
	}
	
} elseif(submitcheck('threadcover', 1)) {

	$nextlink = $dourl."action=plugins&current=$next&pertask=$pertask&threadcover=yes";
	$processed = 0;
	
	_onexin_counter_include('forum_attach', $dourl);

		$result = _onexin_cloudstroage_forum_attach($current, $pertask);
		if(!empty($result['nextid'])) {
			$processed = 1;
		}

	if($processed) {
		cpmsg("$lang[counter_thread_cover]: ".cplang('counter_processing', array('current' => $current, 'next' => $next)), $nextlink, 'loading');
	} else {
		cpmsg('counter_thread_cover_succeed', $dourl."action=plugins", 'succeed');
	}

} elseif(submitcheck('articlesubmit', 1)) {

	$nextlink = $dourl."action=plugins&current=$next&pertask=$pertask&articlesubmit=yes";
	$processed = 0;
	
	_onexin_counter_include('portal', $dourl);
	
		$result = _onexin_cloudstroage_portal($current, $pertask);
		if(!empty($result['nextid'])) {
			$processed = 1;
		}

	if($processed) {
		cpmsg("$lang[counter_thread]: ".cplang('counter_processing', array('current' => $current, 'next' => $next)), $nextlink, 'loading');
	} else {
		cpmsg('counter_thread_succeed', $dourl."action=plugins", 'succeed');
	}
	
} elseif(submitcheck('articlecover', 1)) {

	$nextlink = $dourl."action=plugins&current=$next&pertask=$pertask&articlecover=yes";
	$processed = 0;
	
	_onexin_counter_include('portal_attach', $dourl);
	
		$result = _onexin_cloudstroage_portal_attach($current, $pertask);
		if(!empty($result['nextid'])) {
			$processed = 1;
		}

	if($processed) {
		cpmsg("$lang[counter_thread_cover]: ".cplang('counter_processing', array('current' => $current, 'next' => $next)), $nextlink, 'loading');
	} else {
		cpmsg('counter_thread_cover_succeed', $dourl."action=plugins", 'succeed');
	}

} elseif(submitcheck('albumpicnum', 1)) {

	$nextlink = $dourl."action=plugins&current=$next&pertask=$pertask&albumpicnum=yes";
	$processed = 0;
	
	_onexin_counter_include('album', $dourl);
	
		$result = _onexin_cloudstroage_album($current, $pertask);
		if(!empty($result['nextid'])) {
			$processed = 1;
		}

	if($processed) {
		cpmsg("$lang[counter_album_picnum]: ".cplang('counter_processing', array('current' => $current, 'next' => $next)), $nextlink, 'loading');
	} else {
		cpmsg('counter_album_picnum_succeed', $dourl."action=plugins", 'succeed');
	}

} elseif(submitcheck('blogreplynum', 1)) {

	$nextlink = $dourl."action=plugins&current=$next&pertask=$pertask&blogreplynum=yes";
	$processed = 0;
	
	_onexin_counter_include('blog', $dourl);
	
		$result = _onexin_cloudstroage_blog($current, $pertask);
		if(!empty($result['nextid'])) {
			$processed = 1;
		}

	if($processed) {
		cpmsg("$lang[counter_blog_replynum]: ".cplang('counter_processing', array('current' => $current, 'next' => $next)), $nextlink, 'loading');
	} else {
		cpmsg('counter_blog_replynum_succeed', $dourl."action=plugins", 'succeed');
	}
	
} else {

	shownav('tools', 'nav_updatecounters');
	//showsubmenu('nav_updatecounters');
	showtips("$lang[counter_tips]<li>&#36755;&#20837;5,10&#65292;&#34920;&#31034;&#24320;&#22987;id&#20026;5&#65292;&#27599;&#27425;&#22788;&#29702;10&#26465;</li>");
	showformheader("plugins&".$dourl);
	showtableheader();/*Dism_taobao-com*//*Dism_taobao-com*/
	//showsubtitle(array('', 'counter_amount'));
	showhiddenfields(array('pertask' => ''));
	
	if(_onexin_counter_include('forum_attach')){
		// forum_attach
		showtablerow('', array('class="td21"'), array(
			"$lang[setting_seo_viewthread]$lang[attachment] ID:",
			'<input name="pertask14" type="text" class="txt" value="1, 100" /><input type="submit" class="btn" name="threadcover" onclick="this.form.pertask.value=this.form.pertask14.value" value="'.$lang['submit'].'" />'
		));
	}
	
	
	if(_onexin_counter_include('portal_attach')){
		// portal_attach	
		showtablerow('', array('class="td21"'), array(
			"$lang[setting_seo_article]$lang[attachment] ID:",
			'<input name="pertask15" type="text" class="txt" value="1, 100" /><input type="submit" class="btn" name="articlecover" onclick="this.form.pertask.value=this.form.pertask15.value" value="'.$lang['submit'].'" />'
		));
	}
		
	if(_onexin_counter_include('forum')){
		// forum
		showtablerow('', array('class="td21"'), array(
			"$lang[setting_seo_viewthread] ID:",
			'<input name="pertask4" type="text" class="txt" value="1, 10" /><input type="submit" class="btn" name="threadsubmit" onclick="this.form.pertask.value=this.form.pertask4.value" value="'.$lang['submit'].'" />'
		));
	}
		
	if(_onexin_counter_include('portal')){
		// portal
		showtablerow('', array('class="td21"'), array(
			"$lang[setting_seo_article] ID:",
			'<input name="pertask8" type="text" class="txt" value="1, 10" /><input type="submit" class="btn" name="articlesubmit" onclick="this.form.pertask.value=this.form.pertask8.value" value="'.$lang['submit'].'" />'
		));
	}
		
	if(_onexin_counter_include('album')){
		// album
		showtablerow('', array('class="td21"'), array(
			"$lang[setting_seo_album] ID:",
			'<input name="pertask13" type="text" class="txt" value="1, 5" /><input type="submit" class="btn" name="albumpicnum" onclick="this.form.pertask.value=this.form.pertask13.value" value="'.$lang['submit'].'" />'
		));
	}
	
	if(_onexin_counter_include('blog')){
		// blog
		showtablerow('', array('class="td21"'), array(
			"$lang[counter_blog_replynum]:",
			'<input name="pertask11" type="text" class="txt" value="100" /><input type="submit" class="btn" name="blogreplynum" onclick="this.form.pertask.value=this.form.pertask11.value" value="'.$lang['submit'].'" />'
		));
	}
	
	showtablefooter();
	showformfooter();

}

//---------------------------------------
function _onexin_counter_include($do, $dourl = ''){
	include_once DISCUZ_ROOT.'./source/plugin/onexin_cloudstorage/bucket.'.$do.'.php';
	if(!function_exists('_onexin_cloudstroage_'.$do)){
		if(empty($dourl)) return false;
		cpmsg($do.' file does not exist', $dourl."action=plugins", 'succeed');		
	}		
	return true;
}