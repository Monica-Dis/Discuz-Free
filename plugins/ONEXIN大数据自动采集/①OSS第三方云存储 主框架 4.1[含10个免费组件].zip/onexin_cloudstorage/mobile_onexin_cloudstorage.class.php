<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2015-05-01
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  应用更新支持：https://dism.taobao.com
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------


*/

// for Mobile
class mobileplugin_onexin_cloudstorage {

	protected static $conf = array();
	
	public function __construct() {
        global $_G;
		
		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		if($_G['cache']['plugin']['onexin_cloudstorage']['isopen']) {
			self::$conf = $_G['cache']['plugin']['onexin_cloudstorage'];
		}
    }
	
	public function common(){
		if(!self::$conf['isopen']) return '';	
		
		include_once DISCUZ_ROOT.'./source/plugin/onexin_cloudstorage/bucket/discuz_ftp_ext.php';
	}
	
//	public function global_footer_mobile(){
//		global $_G;
//        
//		if(!self::$conf['isopen']) return '';	
//                  
//		return $return;	
//	}
	
}

