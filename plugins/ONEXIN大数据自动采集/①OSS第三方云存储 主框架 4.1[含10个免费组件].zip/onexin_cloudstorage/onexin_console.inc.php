<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2018-02-01
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/
    if(!function_exists('curl_init')) exit('Need to open the curl extension');

$anchor = in_array($anchor, array('console', 'ftpcheck')) ? $anchor : 'console';
$current = array($operation => 1);

$identifier = $plugin['identifier'];

//------------------------------------------

echo '<input type="button" class="btn" onclick="location.href=\''.ADMINSCRIPT.'?action=plugins&operation='.$operation.'&anchor=ftpcheck&frame=no'."&do=$pluginid&identifier=$identifier&pmod=onexin_console&_=".time().'\'" value="TEST">';

if($anchor == 'ftpcheck') {
	echo "<pre>Start...</pre>";

	$alertmsg = '';
	$testcontent = md5('Discuz!' + time());
	$testfile = '/forum/discuztest.txt';
	$attach_dir = $_G['setting']['attachdir'];
	$sourcefile = $attach_dir.$testfile;
	file_put_contents($sourcefile, $testcontent);

	if(!$alertmsg) {
//		$settingnew = $_GET['settingnew'];
//		$settings['ftp'] = C::t('common_setting')->fetch('ftp', true);
//		$settings['ftp']['password'] = authcode($settings['ftp']['password'], 'DECODE', md5($_G['config']['security']['authkey']));
//		$pwlen = strlen($settingnew['ftp']['password']);
//		if($settingnew['ftp']['password']{0} == $settings['ftp']['password']{0} && $settingnew['ftp']['password']{$pwlen - 1} == $settings['ftp']['password']{strlen($settings['ftp']['password']) - 1} && substr($settingnew['ftp']['password'], 1, $pwlen - 2) == '********') {
//			$settingnew['ftp']['password'] = $settings['ftp']['password'];
//		}
//		$settingnew['ftp']['password'] = authcode($settingnew['ftp']['password'], 'ENCODE', md5($_G['config']['security']['authkey']));
//		$settingnew['ftp']['attachurl'] .= substr($settingnew['ftp']['attachurl'], -1, 1) != '/' ? '/' : '';
//		$_G['setting']['ftp'] = $settingnew['ftp'];

		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		echo "BUCKET ~ /";
		include_once DISCUZ_ROOT.'./source/plugin/onexin_cloudstorage/function_bucket.php';
		
		if(_bucket_put($testfile, $sourcefile)) {
			echo "<pre>PUT ~ 200</pre>";
		}
		if(_bucket_delete($testfile)) {
			echo "<pre>DEL ~ 204</pre>";
			@unlink($sourcefile);
		}
	}
	if(!$alertmsg) {
		$alertmsg = cplang('setting_attach_remote_ok');
	}

	echo "<pre>$alertmsg</pre>";

}
