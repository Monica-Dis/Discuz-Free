<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2020-03-30
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/
	
	if(!empty($_GET['optid'])){
		$result = _onexin_cloudstroage_forum(intval($_GET['optid']), 100, '=');
	}
	
	function _onexin_cloudstroage_forum($tid, $perpage = 10, $den = '>='){
		global $_G;
		
		if(empty($tid)) return array();
		
		$limit = $perpage; $nextid = ''; $list = array();
		
				// cover
				$coverdir = 'threadcover/'.substr(md5($tid), 0, 2).'/'.substr(md5($tid), 2, 2).'/'.$tid.'.jpg';
				
				// cover 1
				$file = $_G['setting']['attachdir'].'/forum/'.$coverdir;
				$target = $_G['setting']['ftp']['attachdir'].'/forum/'.$coverdir;
				if(file_exists($file)){
					if (_bucket_put($target, $file)) {
						// cover -1
						DB::query("UPDATE ".DB::table('forum_thread')." SET cover='-1' WHERE tid='$tid'");
						@unlink($file);
					}
				}
				
				// threadimage
				$threadimage = DB::result_first("SELECT attachment FROM ".DB::table('forum_threadimage')." WHERE tid='$tid'");
				$file = $_G['setting']['attachdir'].'/forum/'.$threadimage;
				$target = $_G['setting']['ftp']['attachdir'].'/forum/'.$threadimage;
				if(file_exists($file)){
					if (_bucket_put($target, $file)) {
						// remote 1
						DB::query("UPDATE ".DB::table('forum_threadimage')." SET remote='1' WHERE tid='$tid' AND attachment='$threadimage'");
						@unlink($file);
					}
				}
				
		
		// first='1' AND 
		$result = DB::fetch_all("SELECT * FROM ".DB::table(getattachtablebytid($tid))." WHERE tid{$den}'$tid' AND remote='0' ORDER BY tid ASC LIMIT $limit");
		foreach($result as $attach){
			$nextid = $attach['tid'];
			$tid = $attach['tid'];
			$aid = $attach['aid'];
			
			if($attach['remote']) {
				// threadimage
				DB::query("UPDATE ".DB::table('forum_threadimage')." SET remote='1' WHERE tid='$tid' AND attachment='$attach[attachment]'");
				//continue;
			}
			
			if(!empty($_GET['operation'])) {
				echo "AID: ".$attach['aid']." ID: ".$attach['tid']."<BR>";	
			}
			
			// attach getglobal('setting/attachdir').'/'.$arg1;
			$file = $_G['setting']['attachdir'].'/forum/'.$attach['attachment'];
			$target = $_G['setting']['ftp']['attachdir'].'/forum/'.$attach['attachment'];
			if(file_exists($file)){
				if (_bucket_put($target, $file)) {
					// http://onexin.cdn.bcebos.com/forum/201709/21/153056ebipjll6qx888snd.jpg
					$url = $_G['setting']['ftp']['attachurl']._bucket_clear($target);
					if(!empty($_GET['operation'])) {
						echo "IMG: ".$url."<BR>";
					}
					@unlink( $file );
					
					DB::query("UPDATE ".DB::table(getattachtablebytid($attach['tid']))." SET remote='1' WHERE aid='$aid'");
					
					$minutes = 3000;
					$attach['remote'] = 1;
				}
			}
			$list[$file] = $attach['remote'];
			
			// thumb attach 
			$file = $_G['setting']['attachdir'].'/forum/'.getimgthumbname($attach['attachment']);
			$target = $_G['setting']['ftp']['attachdir'].'/forum/'.getimgthumbname($attach['attachment']);
			if(!$attach['thumb']) {
				@unlink( $file );
			}
			if(file_exists($file)){
				if (_bucket_put($target, $file)) {
					// http://onexin.cdn.bcebos.com/forum/201709/21/153056ebipjll6qx888snd.jpg
					$url = $_G['setting']['ftp']['attachurl']._bucket_clear($target);
					if(!empty($_GET['operation'])) {
						echo "IMG: ".$url."<BR>";
					}
					@unlink( $file );
				}	
			}
					
		}
		
		// typeoptionvar 
		if(!empty($list)){
			$result = DB::fetch_all("SELECT * FROM ".DB::table('forum_typeoptionvar')." WHERE tid='$tid'");
			foreach($result as $key => $value){
				// data/attachment/forum/20
				if(!preg_match("/data\/attachment\//", $value['value'])) {
					continue;
				}
				
				$value['value'] = unserialize(stripslashes($value['value']));
				if(!empty($value['value']['url'])) {
					$file = str_replace('data/attachment/forum/', $_G['setting']['attachdir'].'/forum/', $value['value']['url']);
					if($list[$file]) {
						$value['value']['url'] = str_replace('data/attachment/forum/', $_G['setting']['ftp']['attachdir'].'/forum/', $value['value']['url']);
						$value['value']['url'] = $_G['setting']['ftp']['attachurl']._bucket_clear($value['value']['url']);
						$value['value'] = addslashes(serialize($value['value']));
						DB::query("UPDATE ".DB::table('forum_typeoptionvar')." SET value='$value[value]' WHERE tid='$value[tid]' AND optionid='$value[optionid]'");
					}
				}	
			}
		}
		
		$result = array();
		$result['oss'] = $list;
		$result['nextid'] = $nextid;
	
		return $result;
	}
	