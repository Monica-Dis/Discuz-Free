<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2018-02-01
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/
$setting = C::t('common_setting')->fetch_all(null);

if(!$isfounder) {
	unset($setting['ftp']);
}

$identifier = $plugin['identifier'];
$dourl = "operation=config&do=$pluginid&identifier=$identifier&pmod=onexin_remote&";

if(submitcheck('settingsubmit', 1)) {
	$settingnew = $_GET['settingnew'];

	if($isfounder && isset($settingnew['ftp'])) {
		$setting['ftp'] = dunserialize($setting['ftp']);
		$setting['ftp']['password'] = authcode($setting['ftp']['password'], 'DECODE', md5($_G['config']['security']['authkey']));
		if(!empty($settingnew['ftp']['password'])) {
			$pwlen = strlen($settingnew['ftp']['password']);
			if($pwlen < 3) {
				cpmsg('ftp_password_short', '', 'error');
			}
			if($settingnew['ftp']['password']{0} == $setting['ftp']['password']{0} && $settingnew['ftp']['password']{$pwlen - 1} == $setting['ftp']['password']{strlen($setting['ftp']['password']) - 1} && substr($settingnew['ftp']['password'], 1, $pwlen - 2) == '********') {
				$settingnew['ftp']['password'] = $setting['ftp']['password'];
			}
			$settingnew['ftp']['password'] = authcode($settingnew['ftp']['password'], 'ENCODE', md5($_G['config']['security']['authkey']));
		}
	}


	$updatecache = FALSE;
	$settings = array();
	foreach($settingnew as $key => $val) {
		if(in_array($key, array('siteuniqueid', 'my_sitekey', 'my_siteid')))  {
			continue;
		}
		if($setting[$key] != $val) {
			$updatecache = TRUE;

			$settings[$key] = $val;
		}
	}
	//print_r($settings);exit;

	if($settings) {
		C::t('common_setting')->update_batch($settings);
	}
	if($updatecache) {
		updatecache('setting');
	}

	cpmsg('setting_update_succeed', $dourl.'action=plugins'.(!empty($_GET['anchor']) ? '&anchor='.$_GET['anchor'] : '').(!empty($from) ? '&from='.$from : ''), 'succeed');

}else{

//if 
	showformheader("plugins&".$dourl);

	if($isfounder) {

		$setting['ftp'] = dunserialize($setting['ftp']);
		$setting['ftp'] = is_array($setting['ftp']) ? $setting['ftp'] : array();
		$setting['ftp']['password'] = authcode($setting['ftp']['password'], 'DECODE', md5($_G['config']['security']['authkey']));
		$setting['ftp']['password'] = $setting['ftp']['password'] ? $setting['ftp']['password']{0}.'********'.$setting['ftp']['password']{strlen($setting['ftp']['password']) - 1} : '';

		require_once libfile('function/cache');

		showtableheader('', '', 'id="remote"'.($_GET['anchor'] != 'remote' ? ' style=""' : ''));
		showsetting('setting_attach_remote_enabled', array('settingnew[ftp][on]', array(
			array(1, $lang['yes'], array('ftpext' => '', 'ftpcheckbutton' => '')),
			array(0, $lang['no'], array('ftpext' => 'none', 'ftpcheckbutton' => 'none'))
		), TRUE), $setting['ftp']['on'], 'mradio');
		showtagheader('tbody', 'ftpext', $setting['ftp']['on'], 'sub');
		showsetting('setting_attach_remote_enabled_ssl', 'settingnew[ftp][ssl]', $setting['ftp']['ssl'], 'radio');
		showsetting('setting_attach_remote_ftp_host', 'settingnew[ftp][host]', $setting['ftp']['host'], 'text');
		showsetting('setting_attach_remote_ftp_port', 'settingnew[ftp][port]', $setting['ftp']['port'], 'text');
		showsetting('setting_attach_remote_ftp_user', 'settingnew[ftp][username]', $setting['ftp']['username'], 'text');
		showsetting('setting_attach_remote_ftp_pass', 'settingnew[ftp][password]', $setting['ftp']['password'], 'text');
		showsetting('setting_attach_remote_ftp_pasv', 'settingnew[ftp][pasv]', $setting['ftp']['pasv'], 'radio');
		showsetting('setting_attach_remote_dir', 'settingnew[ftp][attachdir]', $setting['ftp']['attachdir'], 'text');
		showsetting('setting_attach_remote_url', 'settingnew[ftp][attachurl]', $setting['ftp']['attachurl'], 'text');
		showsetting('setting_attach_remote_timeout', 'settingnew[ftp][timeout]', $setting['ftp']['timeout'], 'text');
		showsetting('setting_attach_remote_preview', '', '', '<input type="button" class="btn" onclick="location.href=\''.ADMINSCRIPT.'?action=plugins&operation=config&anchor=ftpcheck&frame=no'."&do=$pluginid&identifier=$identifier&pmod=onexin_console".'\'" value="TEST">');
		showtagfooter('tbody');
		showsetting('setting_attach_remote_allowedexts', 'settingnew[ftp][allowedexts]', $setting['ftp']['allowedexts'], 'textarea');
		showsetting('setting_attach_remote_disallowedexts', 'settingnew[ftp][disallowedexts]', $setting['ftp']['disallowedexts'], 'textarea');
		showsetting('setting_attach_remote_minsize', 'settingnew[ftp][minsize]', $setting['ftp']['minsize'], 'text');
		showsetting('setting_attach_antileech_remote_hide_dir', 'settingnew[ftp][hideurl]', $setting['ftp']['hideurl'], 'radio');

		showsubmit('settingsubmit');
		showtablefooter();
	}

	showformfooter();
	exit;
//end

}