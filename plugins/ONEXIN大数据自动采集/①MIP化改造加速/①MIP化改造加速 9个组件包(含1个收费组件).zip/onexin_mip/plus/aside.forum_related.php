<?php
/**
 * ONEXIN AMP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2020-03-16
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2020 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	
	//tags
	$tagarr = explode("\t", trim($thread['tags']));
	foreach($tagarr as $key => $var) {
		if($var) {
			$array_temp = is_string($var) ? explode(',', $var) : $var;
			if($_G['cache']['plugin']['onexin_tags']['isopen']){
				$article['tags'][$key]['url'] = $_G['siteurl']."tag-".$array_temp['0'].".html";
			}else{
				$article['tags'][$key]['url'] = $_G['siteurl']."misc.php?mod=tag&id=".$array_temp['0'];				
			}
			$article['tags'][$key]['tagid'] = $array_temp['0'];
			$article['tags'][$key]['tagname'] = $array_temp['1'];
		}
	}
	
	//related 
	$result = DB::fetch_all("SELECT * FROM ".DB::table("forum_thread")." 
		WHERE fid='$thread[fid]' AND displayorder='0' ORDER BY tid DESC LIMIT 5");
	$thread = $threadids = array();
	foreach($result as $val) {
		$val['dateline'] = dgmdate($val['dateline'], 'Y-m-d H:i:s');
		$val['title'] = $val['subject'];
		
		// canonical
		if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$canonical = $_G['siteurl'].rewriteoutput('forum_viewthread', 1, '', $val['tid'], 1, '', '');
		} else {
			$canonical = $_G['siteurl'].'forum.php?mod=viewthread&tid='.$val['tid'];
		}
		$val['url'] = $canonical;
		unset($val['subject']);
		$article['realted'][$val['tid']] = $val;
		$threadids[] = $val['tid'];
	}

    //message	
	$result = DB::fetch_all("SELECT tid, message FROM ".DB::table('forum_post')." WHERE first='1' AND tid IN (".dimplode($threadids).")");
	foreach($result as $val) {
		$index = $val['tid'];
			$val['summary'] = preg_replace("/\[attach\]\d+\[\/attach\]|\[img.*?\].*?\[\/img\]|\[.*?\]/", '', $val['message']);
			$val['summary'] = cutstr($val['summary'], 120);
			
		$val['div'] = '0';
		if(preg_match("/\[(video|media).*?\](.*?)\[\/\\1\]/", $val['message'], $matches)) {
			$val['message'] = $matches[0];
			$val['div'] = '5';
		}elseif(preg_match_all("/\[attach\](\d+)\[\/attach\]/", $val['message'], $matches)) {
			$pics = array_unique($matches[1]);
        	$num = 3;
			$val['div'] = (count($pics) > 1) ? '3' : '1';
			$image_list = array();
			$image_list = ( count($pics) > $num ) ? array_slice($pics, 0, $num) : $pics;        
			if(count($pics) == 2) $image_list = array_slice($pics, 0, 1);
			$images = array();
			foreach($image_list as $v){
				//$imgurl = $_G['siteurl'].getforumimg($matches[1], 0, 232, 154, 'fixwr');
				$imgurl = _onexin_mip_getforumimg($v, 0, 232, 154, 'fixwr');
				$images[] = '<img src="'.$imgurl.'" width="232" height="154">';
			}
			$val['message'] = implode('', $images);
		}else{
			$val['message'] = $val['summary'];
		}
		
		$article['realted'][$index]['content'] = _onexin_mip($val['message']);
		$article['realted'][$index]['summary'] = _onexin_mip($val['summary']);
		$article['realted'][$index]['div'] = $val['div'];
	}
	

