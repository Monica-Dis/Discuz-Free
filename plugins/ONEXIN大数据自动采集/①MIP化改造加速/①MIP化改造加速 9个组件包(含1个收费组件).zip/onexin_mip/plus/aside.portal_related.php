<?php
/**
 * ONEXIN AMP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2018-05-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2018 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	
	//tags		
	if($_G['cache']['plugin']['onexin_tags']['isopen']){
		$thread['tags'] = DB::result_first("SELECT tags FROM ".DB::table('plugin_onexin_tags')." WHERE itemid='$_G[aid]' AND idtype = 'articleid'");
	}
				
	$tagarr = explode("\t", trim($thread['tags']));
	foreach($tagarr as $key => $var) {
		if($var) {
			$array_temp = is_string($var) ? explode(',', $var) : $var;
			if($_G['cache']['plugin']['onexin_tags']['isopen']){
				$article['tags'][$key]['url'] = $_G['siteurl']."tag-".$array_temp['0'].".html";
			}else{
				$article['tags'][$key]['url'] = $_G['siteurl']."misc.php?mod=tag&id=".$array_temp['0'];				
			}
			$article['tags'][$key]['tagid'] = $array_temp['0'];
			$article['tags'][$key]['tagname'] = $array_temp['1'];
		}
	}
	
	//related 
	$result = DB::fetch_all("SELECT * FROM ".DB::table("portal_article_title")." 
		WHERE catid='$thread[catid]' ORDER BY aid DESC LIMIT 5");
	$thread = $threadids = array();
	foreach($result as $val) {
		$val['dateline'] = dgmdate($val['dateline'], 'Y-m-d H:i:s');
		$val['author'] = $val['username'];
		
		// canonical
		if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
			$canonical = $_G['siteurl'].rewriteoutput('portal_article', 1, '', $val['aid'], 1, '');
		} else {
			$canonical = $_G['siteurl'].'portal.php?mod=view&aid='.$val['aid'];
		}
		$val['url'] = $canonical;
		unset($val['username']);
		$article['realted'][$val['aid']] = $val;
		$threadids[] = $val['aid'];
	}
	
    //message
	$result = DB::fetch_all("SELECT aid, content FROM ".DB::table('portal_article_content')." WHERE pageorder = '1' AND aid IN (".dimplode($threadids).")");
	foreach($result as $val) {
		$index = $val['aid'];
        	$val['content'] = str_replace(' src="data/attachment', ' src="'.$_G['siteurl'].'data/attachment', $val['content']);
			$val['summary'] = preg_replace("/\[attach\]\d+\[\/attach\]|\[img.*?\].*?\[\/img\]|\[.*?\]/", '', strip_tags($val['content']));
			$val['summary'] = cutstr($val['summary'], 120);		
			
		$val['div'] = '0';
		$attach = $article['realted'][$val['aid']];
		if(preg_match("/\[(video|media).*?\](.*?)\[\/\\1\]/", $val['content'], $matches)) {
			$val['div'] = '5';
			$val['content'] = $matches[0];
		}elseif($attach['pic']) {
			$val['div'] = '1';
			if($attach['pic']){
				$filename = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachdir']).$attach['pic'];
			}elseif(preg_match("/(<img [^>]*src=\"(.*?)\".*?>)/", $val['content'], $matches)){
				$filename = $matches[1];
			}
			$imgurl = _onexin_mip_getportalimg($val['aid'], $filename, 232, 154, 'fixwr');
			$val['content'] = '<img src="'.$imgurl.'" width="232" height="154">';	
		}elseif(preg_match_all("/\[attach\](\d+)\[\/attach\]/", $val['content'], $matches)) {
			$pics = array_unique($matches[1]);
        	$num = 3;
			$image_list = array();
			$image_list = ( count($pics) > $num ) ? array_slice($pics, 0, $num) : $pics;        
			if(count($pics) == 2) $image_list = array_slice($pics, 0, 1);
			$val['div'] = (count($image_list) > 1) ? '3' : '1';
			$images = array();
			foreach($image_list as $v){
				//$imgurl = $_G['siteurl'].getforumimg($matches[1], 0, 232, 154, 'fixwr');
				$imgurl = _onexin_mip_getforumimg($v, 0, 232, 154, 'fixwr');
				$images[] = '<img src="'.$imgurl.'" width="232" height="154">';
			}
			$val['content'] = implode('', $images);
		}else{
			$val['content'] = $val['summary'];
		}
		
		$article['realted'][$index]['content'] = _onexin_mip($val['content']);
		$article['realted'][$index]['summary'] = _onexin_mip($val['summary']);
		$article['realted'][$index]['div'] = $val['div'];
	}
	

