<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2018-05-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2018 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

		// cagegory name
		if(!isset($_G['cache']['portalcategory'])) {
			loadcache('portalcategory');
		}
		$category = $_G['cache']['portalcategory'];
		foreach($category as $val){
			if($val['foldername'] == $_GET['catid']){
				$_GET['catid'] = $val['catid'];		
			}
		}

if(empty($_G['catid'])) $_G['catid'] = is_numeric($_GET['catid']) ? abs(intval($_GET['catid'])) : 0;
		
if($_G['catid']) {
	if(!isset($_G['cache']['plugin'])){
		loadcache('plugin');
	}	
	
	$page = max(1, intval($_GET['page']));	
	$perpage = 15;
	$page = empty($page) ? 1 : min($page, 5000);
	$start = ($page-1)*$perpage;
		
		// cagegory name
		if(!isset($_G['cache']['portalcategory'])) {
			loadcache('portalcategory');
		}
		$category = $_G['cache']['portalcategory'][$_G['catid']];
	
	$wheresql = '';
	if(is_array($category)) {
		$catid = $category['catid'];
		if(!empty($category['children'])) {
			include_once libfile('function/portalcp');
			$subcatids = category_get_childids('portal', $catid);
			$subcatids[] = $catid;

			$wheresql = "catid IN (".dimplode($subcatids).")";
		} else {
			$wheresql = "catid='$catid'";
		}
	}
	$wheresql .= " AND status='0'";
	
	// list
	$result = DB::fetch_all("SELECT * FROM ".DB::table("portal_article_title")." 
		WHERE $wheresql ORDER BY aid DESC LIMIT $start, $perpage");
	$thread = $threadids = array();
	foreach($result as $val) {
		$val['dateline'] = dgmdate($val['dateline'], 'Y-m-d H:i:s');
		$val['author'] = $val['username'];
		
		// canonical
		if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
			$canonical = $_G['siteurl'].rewriteoutput('portal_article', 1, '', $val['aid'], 1, '');
		} else {
			$canonical = $_G['siteurl'].'portal.php?mod=view&aid='.$val['aid'];
		}
		$val['url'] = $canonical;
		$thread['content'][$val['aid']] = $val;
		$threadids[] = $val['aid'];
	}
	
}else{
	dheader("location: $_G[siteurl]");	
}

///////////////////////////////////////////////////////////////
	
		// site logo
		$_G['cache']['plugin']['onexin_mip']['sitelogo'] = str_replace('{siteurl}', $_G['siteurl'], $_G['cache']['plugin']['onexin_mip']['sitelogo']);
		
		// canonical
		if(!empty($category['foldername'])) {
			$canonical = $category['caturl'].($page> 1 ? 'index.php?page='.$page : '');
		} else {
			$canonical = $_G['siteurl'].'portal.php?mod=list&catid='.$_G['catid'].($page> 1 ? '&page='.$page : "");;
		}
				
		// mipurl
		if(!empty($category['foldername'])) {
			$mipurl = $_G['siteurl'].$_G['cache']['plugin']['onexin_mip']['slash'].$category['fullfoldername'].'/'.($page> 1 ? 'index.php?page='.$page : '');			
		} else {
			$mipurl = $_G['siteurl'].'portal.php?mod=list&catid='.$_G['catid'].($page> 1 ? '&page='.$page : "").'&mip=1';
		} 
		
	//article
	$article = array();
	$article['title']         = $category['catname'];
	$article['content']       = !empty($thread['content']) ? $thread['content'] : $thread['subject'];
	$article['dateline']      = dgmdate($_G['timestamp'], 'Y-m-d H:i:s');//dgmdate($thread['dateline'], 'u');
	$article['datetime']      = str_replace(' ', 'T', $article['dateline']);
	$article['images']        = '';//
	$article['url']           = $canonical;
	$article['mipurl']        = _onexin_mip_domain($mipurl);
	$article['caturl']        = $canonical;
	$article['catname']       = $category['catname'];	
	$article['author']        = '';//$thread['author'];	
	
	$_G['cache']['plugin']['onexin_mip']['htmlcss'] = _onexin_mip_xzh($article).$_G['cache']['plugin']['onexin_mip']['htmlcss'];
		
	$article['aside'] = '';
	include_once DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/aside.portal_list_related.php';
	
	//callback
	if(isset($_GET['callback'])){
		_onexin_mip_ajax($article['content']);				
	}
	
	//charset
//	if(CHARSET != 'utf-8'){
//		@header('Content-Type: text/html; charset=utf-8');
//		$_G['cache']['plugin']['onexin_mip'] = _onexin_mip_charset($_G['cache']['plugin']['onexin_mip'], 1);
//		$article = _onexin_mip_charset($article, 1);
//	}
	//print_r($article);
	
	// 1.0
	$miplangarr = explode("\r", $_G['cache']['plugin']['onexin_mip']['miplang']);
	$miplang = array();
	foreach($miplangarr as $key => $val) {
		$data = explode('=', trim($val));
		if($data[1]) {			
			$miplang[trim($data[0])] = trim($data[1]);
		}
	}
	//print_r($miplang);exit;

//SEO
$_theme = 'onexin_mip_portal_list';

//include_once template('onexin_mip:'.$_theme);
include_once _onexin_mip_template($_theme);	
exit;