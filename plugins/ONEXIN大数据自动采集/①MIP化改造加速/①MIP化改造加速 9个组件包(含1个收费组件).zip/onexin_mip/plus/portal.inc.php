<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2020-03-29
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2021 by dism.taobao.com (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$_G['aid']	= is_numeric($_GET['aid']) ? abs(intval($_GET['aid'])) : 0;
		
if($_G['aid']) {
	if(!isset($_G['cache']['plugin'])){
		loadcache('plugin');
	}	
	
	//message
	$thread = DB::fetch_first("SELECT * FROM ".DB::table("portal_article_title")." 
		WHERE aid='$_G[aid]'");
	
	// Does not exist
	if(empty($thread)){
		// 404
		dheader('location: ' . $_G['siteurl']);
	}
		
	$result = DB::fetch_all("SELECT content FROM ".DB::table("portal_article_content")." 
		WHERE aid='$_G[aid]' AND pageorder = '1' ORDER BY cid ASC");
	$_temp_message = '';
	foreach($result as $val) {
		$_temp_message .= $val['content'];
	}
	$val['content'] = $_temp_message;
	$val['content'] = str_replace(array("\n", "\r"), "", $val['content']);
	
	// idtype tid 1900
	if($thread['idtype'] == 'tid') {
		$parse = parse_url($_G['setting']['attachurl']);
		$attachurl = !isset($parse['host']) ? $_G['siteurl'].$_G['setting']['attachurl'] : $_G['setting']['attachurl'];
	
		//attachment
		$i= '1';
		$query = DB::fetch_all("SELECT p.aid,p.pid,p.remote,p.thumb,p.attachment 
			FROM ".DB::table(getattachtablebytid($thread['id']))." p
			WHERE p.tid='$thread[id]' AND p.isimage IN (1) ORDER BY p.aid ASC");	
		$photo_list = $photo_pid = $serchurl = $replaceurl = array();
		foreach($query as $result) {
			$result['attachment'] = ($result['remote'] ? $_G['setting']['ftp']['attachurl'] : $attachurl).'forum/'.$result['attachment'];
			if($result['thumb']) $result['attachment'] = $result['attachment'].'.thumb.jpg';
			$photo_list[$i] = $result;
			$photo_pid[] = $result['pid'];
			$serchurl[$i] = '[attach]'.$result['aid'].'[/attach]';
			$replaceurl[$i] = '<img src="'.$result['attachment'].'" width="300" height="211">';
			$i++;
		}
	}
	//print_r($thread);exit;
		
    //message
	if($val['content']){				
		$val['content'] = str_replace($serchurl, $replaceurl, $val['content']);
		$val['content'] = preg_replace("/\<script.*?\<\/script\>|\<style.*?\<\/style\>/is", "", $val['content']);
        $val['content'] = preg_replace("/\[img.*?\](.*?)\[\/img\]/", '<img src="\\1">', trim($val['content']));
		//src="data/attachment 
        $val['content'] = str_replace(' src="data/attachment', ' src="'.$_G['siteurl'].'data/attachment', $val['content']);
	}
	//print_r($val['content']);exit();
	$thread['content'] = _onexin_mip($val['content']);
	
}else{
	dheader("location: $_G[siteurl]");
}

///////////////////////////////////////////////////////////////
	
		// site logo
		$_G['cache']['plugin']['onexin_mip']['sitelogo'] = str_replace('{siteurl}', $_G['siteurl'], $_G['cache']['plugin']['onexin_mip']['sitelogo']);
		
		// canonical
		if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
			$canonical = $_G['siteurl'].rewriteoutput('portal_article', 1, '', $_G['aid'], 1, '');
		} else {
			$canonical = $_G['siteurl'].'portal.php?mod=view&aid='.$_G['aid'];
		}
				
		// mipurl
		if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
			$mipurl = $_G['siteurl'].$_G['cache']['plugin']['onexin_mip']['slash'].rewriteoutput('portal_article', 1, '', $_G['aid'], 1, '');			
		} else {
			$mipurl = $_G['siteurl'].'portal.php?mod=view&aid='.$_G['aid'].'&mip=1';
		} 
		
		// cagegory name
		if(!isset($_G['cache']['portalcategory'])) {
			loadcache('portalcategory');
		}
		$category = $_G['cache']['portalcategory'][$thread['catid']];		
	
	//article
	$article = array();
	$article['title']         = $thread['title'];
	$article['content']       = !empty($thread['content']) ? $thread['content'] : $thread['title'];
	$article['dateline']      = dgmdate($thread['dateline'], 'Y-m-d H:i:s');//dgmdate($thread['dateline'], 'u');
	$article['datetime']      = str_replace(' ', 'T', $article['dateline']);
	$article['images']        = _onexin_mip_images($val['content']);	
	$article['url']           = $canonical;
	$article['mipurl']        = _onexin_mip_domain($mipurl);
	$article['caturl']        = $category['caturl'];
	$article['catname']       = $category['catname'];	
	$article['author']        = $thread['username'];	
	
	$_G['cache']['plugin']['onexin_mip']['htmlcss'] = _onexin_mip_xzh($article).$_G['cache']['plugin']['onexin_mip']['htmlcss'];
		
	$article['aside'] = '';
	include_once DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/aside.portal_related.php';

	//charset
//	if(CHARSET != 'utf-8' && $_GET['diy'] != 'yes'){
//		@header('Content-Type: text/html; charset=utf-8');
//		$_G['cache']['plugin']['onexin_mip'] = _onexin_mip_charset($_G['cache']['plugin']['onexin_mip'], 1);
//		$article = _onexin_mip_charset($article, 1);
//	}
	//print_r($article);
		
	// 1.0
	$miplangarr = explode("\r", $_G['cache']['plugin']['onexin_mip']['miplang']);
	$miplang = array();
	foreach($miplangarr as $key => $val) {
		$data = explode('=', trim($val));
		if($data[1]) {			
			$miplang[trim($data[0])] = trim($data[1]);
		}
	}
	//print_r($miplang);exit;

//SEO
$_theme = 'onexin_mip_portal_view';

//include_once template('onexin_mip:'.$_theme);
include_once _onexin_mip_template($_theme);	
exit;