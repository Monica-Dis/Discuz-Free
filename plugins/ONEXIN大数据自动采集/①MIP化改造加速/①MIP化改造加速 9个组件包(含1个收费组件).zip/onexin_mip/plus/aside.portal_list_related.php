<?php
/**
 * ONEXIN AMP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2018-05-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2018 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	
    //message
	$result = DB::fetch_all("SELECT aid, content FROM ".DB::table('portal_article_content')." WHERE pageorder = '1' AND aid IN (".dimplode($threadids).")");
	foreach($result as $val) {
		$index = $val['aid'];
        	$val['content'] = str_replace(' src="data/attachment', ' src="'.$_G['siteurl'].'data/attachment', $val['content']);
			$val['summary'] = preg_replace("/\[attach\]\d+\[\/attach\]|\[img.*?\].*?\[\/img\]|\[.*?\]/", '', strip_tags($val['content']));
			$val['summary'] = cutstr($val['summary'], 120);		
			
		$val['div'] = '0';
		$attach = $thread['content'][$val['aid']];
		if(preg_match("/\[(video|media).*?\](.*?)\[\/\\1\]/", $val['content'], $matches)) {
			$val['div'] = '5';
			$val['content'] = $matches[0];
		}elseif($attach['pic']) {
			$val['div'] = '1';
			if($attach['pic']){
				$filename = ($attach['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachdir']).$attach['pic'];
			}elseif(preg_match("/(<img [^>]*src=\"(.*?)\".*?>)/", $val['content'], $matches)){
				$filename = $matches[1];
			}
			$imgurl = _onexin_mip_getportalimg($val['aid'], $filename, 232, 154, 'fixwr');
			$val['content'] = '<img src="'.$imgurl.'" width="232" height="154">';	
		}else{
			$val['content'] = $val['summary'];
		}
		
		$article['content'][$index]['content'] = _onexin_mip($val['content']);
		$article['content'][$index]['summary'] = _onexin_mip($val['summary']);
		$article['content'][$index]['div'] = $val['div'];
	}

