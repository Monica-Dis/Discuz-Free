<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2018-10-03
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2018 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------
*/

            _forum_viewthread_onexin_mip_output();
//        if(CURMODULE == 'viewthread'){
//        }
		
	function _forum_viewthread_onexin_mip_output() {
		global $_G, $postlist;
			
			$conf = $_G['cache']['plugin']['onexin_mip'];
			$conf['usefids'] = (array)unserialize($conf['usefids']);	
			if(empty($conf['usefids'][0]) || in_array($_GET['fid'], $conf['usefids'])){
				$conf['isfid'] = TRUE;
			}
			
		if(!$conf['isfid']) return '';
			
		$yourfile = DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/forum.inc.php';
		if(!file_exists($yourfile)){
			return '';
		}

		if(isset($_GET['mip']) || $_G['siteurl'] == $conf['mipdomain']) {
			include DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/forum.inc.php';
		}	
		
		// page
		$page = intval($_GET['page']);

		// canonical
		if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$canonical = $_G['siteurl'].$conf['slash'].rewriteoutput('forum_viewthread', 1, '', $_G['tid'], ($page> 1 ? $page : ''), '', '');
		} else {
			$canonical = $_G['siteurl'].'forum.php?mod=viewthread&tid='.$_G['tid'].($page> 1 ? '&page='.$page : "").'&mip=1';
		}
		
		// mip domain
		$canonical = _onexin_mip_domain($canonical);
		
		// fix "{fid}"
		$canonical = str_replace('{fid}', ($_G['setting']['forumkeys'][$_G['fid']] ? $_G['setting']['forumkeys'][$_G['fid']] : $_G['fid']), $canonical);
						  
		$_G['setting']['seohead'] = "<link rel=\"miphtml\" href=\"".$canonical."\" />" . $_G['setting']['seohead'];
		
		// head
        $data = array(
            'url' => $canonical,
            'dateline' => $postlist[$_G['forum_firstpid']]['dbdateline']
        );
		$_G['setting']['seohead'] .= _onexin_mip_autopush($data);
		
		return '';
	}
