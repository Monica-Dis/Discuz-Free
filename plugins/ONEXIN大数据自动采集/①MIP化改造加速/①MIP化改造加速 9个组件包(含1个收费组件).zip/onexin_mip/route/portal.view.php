<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2017-10-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2017 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------
*/

            _portal_view_onexin_mip_output();
//        if(CURSCRIPT == 'portal' && CURMODULE == 'view'){
//        }
		
	function _portal_view_onexin_mip_output() {
		global $_G, $article;
		
			$conf = $_G['cache']['plugin']['onexin_mip'];
			
			loadcache('onexin_mip');
			$conf = array_merge($conf, (array)unserialize(stripslashes($_G['cache']['onexin_mip'])));			
			if(empty($conf['usecatids'][0]) || in_array($_GET['catid'], $conf['usecatids'])){
				$conf['iscatid'] = TRUE;
			}	
			
		if(!$conf['isopen'] || !$conf['iscatid']) return '';

		$yourfile = DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/portal.inc.php';
		if(!file_exists($yourfile)){
			return '';
		}
		
		if(isset($_GET['mip']) || $_G['siteurl'] == $conf['mipdomain']) {
			include DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/portal.inc.php';
		}	
				
		// canonical
		if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
			$canonical = $_G['siteurl'].$conf['slash'].rewriteoutput('portal_article', 1, '', $article['aid'], 1, '');			
		} else {
			$canonical = $_G['siteurl'].'portal.php?mod=view&aid='.$article['aid'].'&mip=1';
		}  
		
		// mip domain
		$canonical = _onexin_mip_domain($canonical);
		  
		$_G['setting']['seohead'] = "<link rel=\"miphtml\" href=\"".$canonical."\" />" . $_G['setting']['seohead'];
			
		// head
        $data = array(
            'url' => $canonical,
            'dateline' => $article['timestamp']
        );
		$_G['setting']['seohead'] .= _onexin_mip_autopush($data);
					
		return '';
	}	
