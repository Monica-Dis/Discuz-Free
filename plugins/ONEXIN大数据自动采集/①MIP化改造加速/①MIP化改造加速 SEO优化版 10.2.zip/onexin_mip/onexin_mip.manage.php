<?php
/**
 * ONEXIN BAIDU MIP For Discuz!X 3.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @date	   2018-06-20
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2018 Onexin Platform Inc. (http://dism.taobao.com)
 */

/*
//--------------Tall us what you think!----------------------------------
*/

//
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!isset($_G['cache']['plugin'])){
    loadcache('plugin');
}
$conf = $_G['cache']['plugin']['onexin_mip'];
$mipapi = trim($conf['mipapi']);
$today = strtotime('today');

// 允许提交的用户组
$conf['usergroups'] = (array)unserialize($conf['usergroups']);
$conf['isgroupid'] = FALSE;
if(empty($conf['usergroups'][0]) || in_array($_G['groupid'], $conf['usergroups'])){
    $conf['isgroupid'] = TRUE;
}

// 允许批量管理的用户组
$conf['batchgroups'] = (array)unserialize($conf['batchgroups']);
$conf['ismanage'] = FALSE;
if(empty($conf['batchgroups'][0]) || in_array($_G['groupid'], $conf['batchgroups'])){
    $conf['ismanage'] = TRUE;
}


$langtxt = array();
$langtxt['forum'] = '&#35770;&#22363;&#21015;&#34920;&#39029;';//论坛列表页
$langtxt['thread'] = '&#35770;&#22363;&#20869;&#23481;&#39029;';//论坛内容页
$langtxt['article'] = '&#38376;&#25143;&#25991;&#31456;&#39029;';//门户文章页
$langtxt['unknow'] = '&#26410;&#30693;&#39029;';//未知内容页

//------------------------------------------------------------     

// check permission
if(!$conf['isgroupid']){
    $output = array("status" => '500', 'content'=> 'No Group permission');
    _mip_output($output);        
}
        
$view = !empty($_GET['view']) ? $_GET['view'] : 'manage';

if($view == 'authkey') {	

	// check admin
	if(!$conf['ismanage']) {
		showmessage('no_privilege');
	}
	
	$mipurls = !empty($_GET['mipurls']) ? trim($_GET['mipurls']) : ''; 
	
	$mipurls = str_replace(array('http://', 'https://'), '', $mipurls);

	if(preg_match("/https:\/\//i", $_G['siteurl'])){
		$api = 'http://c.mipcdn.com/update-ping/c/s/url';		
	}else{
		$api = 'http://c.mipcdn.com/update-ping/c/';		
	}
	
	$postData = 'key='.$conf['authkey'];
	$url = $api.urlencode($mipurls);
	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
	curl_setopt($ch, CURLOPT_TIMEOUT, 5);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 5);
	$result = curl_exec($ch);
	curl_close($ch);
	
	$result = preg_replace("/^.*?\"msg\":\"(.*?)\".*?$/is", "\\1", $result);
	// {"status":1,"msg":"auth check fail"}
	
    if(preg_match("/success/", $result)){
        $code = '200';
    }else{
        $code = '400';
    }
	    
    $output = array(
        'status' => $code, 
        'content' => $result
    );
    //_mip_setcache('history', $output);
    _mip_output($output);
    
}elseif($view == 'manage') {	

	// check admin
	if(!$conf['ismanage']) {
		showmessage('no_privilege');
	}
    
    $mipapi_batch = str_replace('realtime', 'batch', $mipapi);

    // check cache
	$dir = dirname(__FILE__);
    if (!is_dir($dir.'/cache') && is_writeable($dir)){
        mkdir($dir.'/cache');
    }
    if (is_dir($dir.'/cache') && is_writeable($dir.'/cache')){
        $min_cachePath = $dir.'/cache';
    }else{
        // 日志文件写入失败，请检查文件夹权限
        $writeable = '<h3 class=\"edited\">&#26085;&#24535;&#25991;&#20214;&#20889;&#20837;&#22833;&#36133;&#65292;&#35831;&#26816;&#26597;&#25991;&#20214;&#22841;&#26435;&#38480; source/plugin/onexin_mip/cache</h3>';
        echo $writeable;exit;
    }	
    
    $data = _mip_getcache_statslist();
    $count = count($data);
//    if($count > $conf['daylimit']) {
//        echo "<h3 class=\"edited\">&#24050;&#36229;&#20986;&#26032;&#22686;&#20869;&#23481;&#37197;&#39069;</h3>";
//    }
    $html = implode("", $data);
    
	include template('onexin_mip:manage');
	exit;
    
}elseif($view == 'statslist'){

	// check admin
	if(!$conf['ismanage']) {
		showmessage('no_privilege');
	}
    
    // check status
    $data = _mip_getcache_statslist();
    $html = implode("", $data);
	echo $html;
    exit;
    
}elseif($view == 'todaylist'){

	// check admin
	if(!$conf['ismanage']) {
		showmessage('no_privilege');
	}
    
    // check today  
    $todaylist = _mip_getcache();
    $data = array();
	
	$siteurl = !empty($_GET['siteurl']) ? $_GET['siteurl'] : $_G['siteurl'];
	$siteurl .= 'mip/';
    
    // thread
    $result = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." WHERE displayorder!='-1' ORDER BY tid DESC LIMIT 50");
    foreach($result as $val){
            // canonical
            if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
                $canonical = rewriteoutput('forum_viewthread', 1, '', $val['tid'], 1, '', '');
            } else {
                $canonical = 'forum.php?mod=viewthread&tid='.$val['tid'];
            }
		
		// fix "{fid}"
		$canonical = str_replace('{fid}', ($_G['setting']['forumkeys'][$val['fid']] ? $_G['setting']['forumkeys'][$val['fid']] : $val['fid']), $canonical);
		
        $url = $siteurl.$canonical;
        $k = md5($url.$mipapi);
        $data[$k] = array(
            'id' => $val['tid'],
            'url' => $url,
            'title' => "[".dgmdate($val['dateline'], 'm-d H:i:s')."] ".$val['subject'],
            'type' => $langtxt['thread'],
            'code' => !empty($todaylist[$k]['code']) ? $todaylist[$k]['code'] : '0',
            'mode' => !empty($todaylist[$k]['mode']) ? $todaylist[$k]['mode'] : '0',
            'time' => !empty($todaylist[$k]['time']) ? $todaylist[$k]['time'] : '0',
            'num' => !empty($todaylist[$k]['num']) ? $todaylist[$k]['num'] : '0'
        );       
    }
    
    // thread
    $result = DB::fetch_all("SELECT * FROM ".DB::table('portal_article_title')." WHERE 1=1 ORDER BY aid DESC LIMIT 50");
    foreach($result as $val){
            // canonical
            if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
                $canonical = rewriteoutput('portal_article', 1, '', $val['aid'], 1, '');
            } else {
                $canonical = 'portal.php?mod=view&aid='.$val['aid'];
            }
        $url = $siteurl.$canonical;
        $k = md5($url.$mipapi);
        $data[$k] = array(
            'id' => $val['aid'],
            'url' => $url,
            'title' => "[".dgmdate($val['dateline'], 'm-d H:i:s')."] ".$val['title'],
            'type' => $langtxt['article'],
            'code' => !empty($todaylist[$k]['code']) ? $todaylist[$k]['code'] : '0',
            'mode' => !empty($todaylist[$k]['mode']) ? $todaylist[$k]['mode'] : '0',
            'time' => !empty($todaylist[$k]['time']) ? $todaylist[$k]['time'] : '0',
            'num' => !empty($todaylist[$k]['num']) ? $todaylist[$k]['num'] : '0'
        );       
    }
    
    //_mip_setcache('', $data);
    
    $list = $data;//_mip_getcache();
    $html = '';
    foreach($list as $val){
        if(!empty($val['url'])) {
//            if($val['code']=='200') {
//                $input = "<input type=\"checkbox\" disabled />";
//            }else{
                $input = "<input class=\"checkbox\" type=\"checkbox\" name=\"tidarray[]\" value=\"{$val[id]}\" data-url=\"{$val[url]}\" />";    
//            }
            $html .= "<tr class=\"log-{$val[id]} hover\"><td class=\"td25\">{$input}</td><td class=\"td25\">{$val[code]}</td><td><a href=\"{$val[url]}\" target=\"_blank\">{$val[title]}</a></td><td>{$val[type]}</td><td>{$val[num]}</td><td class=\"td25\">{$val[mode]}</td><td>{$val[time]}</td></tr>";
        }
    }
	echo $html;
    exit;
}elseif($view == 'historylist'){

	// 批量提交历史信息，只能管理员组使用
	if($_G['groupid']!='1') {
		showmessage('no_privilege');
	}

$nextid = 0;

$start = !empty($_GET['start']) ? (int)$_GET['start'] : '0';
$limit = !empty($_GET['limit']) ? (int)$_GET['limit'] : '200';
$count = !empty($_GET['count']) ? (int)$_GET['count'] : '200';
$type = !empty($_GET['type']) ? $_GET['type'] : '1';
$api = $mipapi;
$siteurl = !empty($_GET['siteurl']) ? $_GET['siteurl'] : $_G['siteurl'];

//$api = 'http://data.zz.baidu.com/urls?appid=1582855495060472&token=xctl7GBtgZnRa7Ta&type=batch';

            if(preg_match("/type=mip/", $api)){
				$siteurl = $siteurl.'mip/';
			}
// ------------------

	if($type == '3'){
        $query = DB::query("SELECT * FROM ".DB::table('home_blog')." WHERE blogid>'$start' ORDER BY blogid ASC LIMIT $limit");
        $urls = array();
        while($value = DB::fetch($query)) {
            $nextid = $value['blogid'];
            
            // canonical
			if(in_array('home_blog', $_G['setting']['rewritestatus'])) {
				$canonical = rewriteoutput('home_blog', 1, '', $value['uid'], $nextid, '');
			} else {
				$canonical = 'home.php?mod=space&uid='.$value['uid'].'&do=blog&id='.$nextid;
			}
            $urls[] = $siteurl.$canonical;
        }
    }elseif($type == '2'){
        $query = DB::query("SELECT * FROM ".DB::table('portal_article_title')." WHERE aid>'$start' ORDER BY aid ASC LIMIT $limit");
        $urls = array();
        while($value = DB::fetch($query)) {
            $nextid = $value['aid'];
            
            // canonical
            if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
                $canonical = rewriteoutput('portal_article', 1, '', $nextid, 1, '');
            } else {
                $canonical = 'portal.php?mod=view&aid='.$nextid;
            }
            $urls[] = $siteurl.$canonical;
        }
    }else{
        $query = DB::query("SELECT * FROM ".DB::table('forum_thread')." WHERE tid>'$start' ORDER BY tid ASC LIMIT $limit");
        $urls = array();
        while($value = DB::fetch($query)) {
            $nextid = $value['tid'];
            
            // canonical
            if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
                $canonical = rewriteoutput('forum_viewthread', 1, '', $nextid, 1, '', '');
            } else {
                $canonical = 'forum.php?mod=viewthread&tid='.$nextid;
            }
		
		// fix "{fid}"
		$canonical = str_replace('{fid}', ($_G['setting']['forumkeys'][$value['fid']] ? $_G['setting']['forumkeys'][$value['fid']] : $value['fid']), $canonical);
            
            $urls[] = $siteurl.$canonical;		
        }        
    }
    $result = _mip_push($urls, $api);
    
    $output = array(
        'status' => '200', 
        'content' => $result, 
        'start' => $nextid, 
        'count' => $nextid ? $count - $limit : 0, 
        'num' => $limit
    );
    //_mip_setcache('history', $output);
    _mip_output($output);
}elseif($view == 'todaysubmit'){
    
    // check today  
    $todaylist = _mip_getcache();
    $data = array();
    
    $api = $mipapi;
    $mipurls = !empty($_GET['mipurls']) ? trim($_GET['mipurls']) : ''; 
    $mode = !empty($_GET['mode']) ? intval($_GET['mode']) : 1; 
       
    $mipurls = explode("\n", $mipurls);
    $urls = $tids = $aids = array();
    foreach($mipurls as $val){
        $k = md5($val.$mipapi);
        if($todaylist[$k]['code'] == 200) {
            continue;
        }
        if(!empty($val)) {
            $urls[$k] = trim($val);
        }
    }
    
    $result = _mip_push($urls, $api);
    
    //{"error":400,"message":"empty content"}
    if(preg_match("/success/", $result)){
        $code = '200';
    }else{
        $code = '400';
    }
    foreach($urls as $val){       
            $vval['title'] = $val;
            $vval['dateline'] = TIMESTAMP;
            $vval['type'] = 'unknow'; 
        if(preg_match("/(\/thread-|viewthread&tid=)(\d+)/", $val, $match)){
            //$vval = DB::fetch_first("SELECT subject,dateline FROM ".DB::table('forum_thread')." WHERE tid='$match[2]'");
            $vval['type'] = 'thread';
            //$vval['title'] = $vval['subject'];
        }elseif(preg_match("/(\/article-|mod=view&aid=)(\d+)/", $val, $match)){
            //$vval = DB::fetch_first("SELECT title,dateline FROM ".DB::table('portal_article_title')." WHERE aid='$match[2]'");
            $vval['type'] = 'article';
        }elseif(preg_match("/(\/forum-|mod=forumdisplay&fid=)(\d+)/", $val, $match)){
            //$vval = DB::fetch_first("SELECT title,dateline FROM ".DB::table('portal_article_title')." WHERE aid='$match[2]'");
            $vval['type'] = 'forum';
        }
            
        $url = $val;
        $k = md5($url.$mipapi);
        $todaylist[$k]['url'] = $url;
        $todaylist[$k]['time'] = dgmdate(TIMESTAMP, 'Y-m-d H:i:s');
        $todaylist[$k]['title'] = "[".dgmdate($vval['dateline'], 'm-d H:i:s')."] ".$vval['title'];
        $todaylist[$k]['type'] = $vval['type'];
        $todaylist[$k]['mode'] = $mode;
        $todaylist[$k]['code'] = $code;
        $todaylist[$k]['num'] = !empty($todaylist[$k]['num']) ? $todaylist[$k]['num'] + 1 : 1;               
    }
    
    _mip_setcache('', $todaylist);
    
    $output = array(
        'status' => '200', 
        'urls' => implode("\n", $urls), 
        'content' => $result
    );
    _mip_output($output);
}

