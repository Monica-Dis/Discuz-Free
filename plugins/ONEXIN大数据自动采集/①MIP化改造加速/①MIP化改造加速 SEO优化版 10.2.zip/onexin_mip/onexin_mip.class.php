<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2017-10-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2017 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------

https://mip.example.com/123.html

https://www.example.com/mip/123.html

https://www.example.com/mip-123.html

*/

require_once DISCUZ_ROOT . './source/plugin/onexin_mip/function_mip.php';

class plugin_onexin_mip {

	protected static $conf = array();
	protected static $isopen = FALSE;

	public function __construct() {
		global $_G;
		
		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		self::$isopen = $_G['cache']['plugin']['onexin_mip']['isopen'] ? TRUE : FALSE;
	}

	public function global_header() {
		global $_G;		
		if(!self::$isopen) return '';
		
		// CURSCRIPT . CURMODULE 
        $yourself_file = DISCUZ_ROOT.'./source/plugin/onexin_mip/route/'.CURSCRIPT.'.'.CURMODULE.'.php';        
		if(file_exists($yourself_file)){
		    include_once $yourself_file;
        }else{
		    //include_once DISCUZ_ROOT.'./source/plugin/onexin_mip/route/index.php';
        }
        
        return '';
	}
	
}
