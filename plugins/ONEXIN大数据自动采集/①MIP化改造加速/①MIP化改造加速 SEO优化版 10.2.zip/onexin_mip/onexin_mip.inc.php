<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2019-08-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2021 by dism.taobao.com (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

require_once DISCUZ_ROOT . './source/plugin/onexin_mip/function_mip.php';

/*
//--------------Tall us what you think!----------------------------------

https://mip.example.com/123.html

https://www.example.com/mip/123.html

/mip/thread-1975-1-1.html

portal.php?mod=view&aid=182


图片清晰度高，长宽比为3:2，图片大小不得低于300*200px；

static/image/common/logo.png

*/

if(defined('IN_ADMINCP')) {
	?>
    <a href="<?PHP echo $_G['siteurl'] ?>plugin.php?id=onexin_mip&op=manage" target="_blank"> <?PHP echo $_G['siteurl'] ?>plugin.php?id=onexin_mip&op=manage </a>
	<?php
	exit();
}

if($_GET['op'] == 'manage'){
	
	include_once DISCUZ_ROOT . './source/plugin/onexin_mip/onexin_mip.manage.php';
	
}else{
	
	//$_GET['rewrite'] = 'thread-1900-1-1.html';
	
	// 2.0
	$arr = explode("\r", $_G['cache']['plugin']['onexin_mip']['confkey']);
	foreach($arr as $key => $val) {
		// key#name#slug
		$data = explode('.', trim($val));
		if($data[1]) {
				$mod = trim($data[1], '/');
			$yourself_file = DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/'.$mod.'.inc.php';
			if(!file_exists($yourself_file)){
				continue;
			}
			if(preg_match("/".$data[2]."/", $_GET['rewrite'], $match)){
				$_GET[$data[0]] = $match[1];
				$_GET['page'] = max(1, intval(!empty($_GET['page']) ? $_GET['page'] : $match[2]));
				include DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/'.$mod.'.inc.php';
			}				
		}
	}
	
	// portal /ent/
	if(preg_match("/\/(\w+)\/(index\.php.*?|\d+)?$/", $_GET['rewrite'], $match)){
		$_GET['catid'] = $match[1];	
	}elseif(preg_match("/(thread[-|\/|_])(\d+)/", $_GET['rewrite'], $match)){
		$_GET['tid'] = $match[2];
	}elseif(preg_match("/(article[-|\/|_])(\d+)/", $_GET['rewrite'], $match)){
		$_GET['aid'] = $match[2];
	}
	//print_r($_GET);exit;

$rule = $_G['setting']['rewriterule'];
if(preg_match("/".current(explode('{tid}', $rule['forum_viewthread']))."(\d+)/", $_GET['rewrite'], $match)){
	$_GET['tid'] = $match[1];
}elseif(preg_match("/".current(explode('{fid}', $rule['forum_forumdisplay']))."(\w+)([-|\/](\d+))?/", $_GET['rewrite'], $match)){
	$_GET['fid'] = $match[1];
	$_GET['page'] = $match[3];
}elseif(preg_match("/".current(explode('{id}', $rule['portal_article']))."(\d+)/", $_GET['rewrite'], $match)){
	$_GET['aid'] = $match[1];
}
unset($rule);
			
	if(isset($_GET['aid'])){
		include DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/portal.inc.php';
	}elseif(isset($_GET['catid'])){
		include DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/portal_list.inc.php';
	}elseif(isset($_GET['tid'])){
		include DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/forum.inc.php';
	}elseif(isset($_GET['fid'])){
		include DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/forum_list.inc.php';
	}
	
	// index
	if(empty($_GET['rewrite']) || $_GET['rewrite'] == '/'){
		$index = $_G['cache']['plugin']['onexin_mip']['mipindex'];
		if($index) include DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/'.$index.'_index.inc.php';		
	}
		
	dheader("location: $_G[siteurl]");
	exit;
}