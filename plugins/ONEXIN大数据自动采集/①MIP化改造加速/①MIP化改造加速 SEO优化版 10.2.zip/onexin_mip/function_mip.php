<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   engine 
 * @date	   2019-08-06
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2021 by dism.taobao.com (http://dism.taobao.com)
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------

HTML Specification

Prohibited 
base|frame|frameset|object|param|applet|embed

https://www.mipengine.org/doc/01-mip-demo.html

video
audio
iframe

    <mip-youtube
      data-videoid="y6kA3u3GIws"
      layout="responsive"
      width="480" height="270">
    </mip-youtube>
	
*/

function _onexin_miplang($tag = '') {
	global $_G;
		
}

function _onexin_mip($html = '', $vtag = 'mip') {
	global $_G;
		
		//video	
		if($_G['cache']['plugin']['onexin_html5player']['video']['isopen']){
			include_once DISCUZ_ROOT . './source/plugin/onexin_html5player/function_html5player.php';
			$html = _onexin_html5player($html, $_G['cache']['plugin']['onexin_html5player']['video']);
		}
	
	$search = $replace = array();
	
	$search[] = "/<iframe[^>]* src=\"\"[^>]*>\s*<\/iframe>/is";
	$replace[] = "";
	
	$search[] = "/ style=\"[^\"]*\"|\[.*?\]|<o:p>|<\/o:p>/i";
	$replace[] = "";
	
	$search[] = "/\<img[^>]* src=\"(.*?)\"[^>]*\>/i";
	$replace[] = "<div class=\"mip-wp-img\"><mip-img src=\"\\1\" width=\"300\" height=\"211\" layout=\"container\"></mip-img></div>";
	
	$search[] = "/\<video[^>]* src=\"(.*?)\"[^>]*\>\s*<\/video>/is";
	$replace[] = "<div class=\"mip-wp-video\"><mip-video src=\"\\1\" width=\"300\" height=\"211\" layout=\"container\"></mip-video></div>";
	
	$search[] = "/\<iframe[^>]* src=\"(.*?)\"[^>]*\>\s*<\/iframe>/is";
	$replace[] = "<div class=\"mip-wp-iframe\"><mip-iframe allowfullscreen src=\"\\1\" width=\"640\" height=\"375\" layout=\"responsive\" allowtransparency=\"true\"></mip-iframe></div>";
			    
	$html = preg_replace($search, $replace, $html);	
	
	return $html;
}

function _onexin_mip_images($message = '') {
	global $_G;
	
		$search = $replace = array();
        $search[] = "/<img[^>]* file=\"/";
        $replace[] = '<img src="';    
        $search[] = "/\<img [^>]*src=\"[^\"]*(image\/smiley|images\/bgimg|static\/image)[^>]*\>/";
        $replace[] = '';            
        $search[] = '/<img [^>]*="forum.php/';
        $replace[] = '<img src="'. $_G['siteurl'] .'forum.php';        
        $search[] = '/src="(\.\/)?data\/attachment\//';
        $replace[] = 'src="'. $_G['siteurl'] .'data/attachment/';        
        $message = preg_replace($search, $replace, $message);
        
		preg_match_all("/\<img\s+[^>]*src=[\'\"]([^'\"]+)[\'\"\s\>]+/i", $message, $mathes);
		$pics = array_unique($mathes[1]);
        $num = 3;
		$image_list = array();
		$image_list = ( count($pics) > $num ) ? array_slice($pics, 0, $num) : $pics;        
        if(count($pics) == 2) $image_list = array_slice($pics, 0, 1);        
        $images = array();
		foreach($image_list as $val){
            $images[] = "\r\n        \"$val\"";
		}
        $images = implode(',', $images);
		
	return $images;
}

function _onexin_mip_getforumimg($daid = 0, $nocache = 0, $dw = 360, $dh = 240, $type = 'fixwr') {
	global $_G;
	$thumbfile = 'image/'.helper_attach::makethumbpath($daid, $dw, $dh);
	if(file_exists($_G['setting']['attachdir'].$thumbfile)) {
		return helper_attach::attachpreurl().$thumbfile;
	}
	return $_G['siteurl'].getforumimg($daid, $nocache, $dw, $dh, $type);	
}

function _onexin_mip_getportalimg($daid = 0, $filename = '', $dw = 360, $dh = 240, $type = 'fixwr') {
	global $_G;
	
	$thumbfile = 'image/0'.helper_attach::makethumbpath($daid, $dw, $dh);
	if(file_exists($_G['setting']['attachdir'].$thumbfile)) {
		return helper_attach::attachpreurl().$thumbfile;
	}
	
	require_once libfile('class/image');
	$img = new image;
	if($img->Thumb($filename, $thumbfile, $dw, $dh, $type)) {
		return helper_attach::attachpreurl().$thumbfile;
	}
	return $_G['siteurl'].$filename;
}

// CHARSET
function _onexin_mip_charset($contents = '', $reverse = false){
	if(CHARSET == 'utf-8') return $contents;
	if(is_array($contents)) {
		foreach($contents as $key => $val) {
			$contents[$key] = _onexin_mip_charset($val, $reverse);
		}
	} else {
		if($reverse){
			$from = CHARSET;
			$to = 'utf-8';
		}else{
			$from = 'utf-8';
			$to = CHARSET;
		}
		
		if(function_exists('mb_convert_encoding')) {
			$contents = mb_convert_encoding($contents, $to, $from);
		}else{
			$contents = diconv($contents, $from, $to);						
		}
	}		
	return $contents;
}
	
// mip xzh
function _onexin_mip_xzh($article = array()){
	global $_G;  
	
	if(empty($_G['cache']['plugin']['onexin_mip']['appid'])) return;  

// xzh
$xzh = '<script type="application/ld+json">
{
    "@context": "https://ziyuan.baidu.com/contexts/cambrian.jsonld",
    "@id": "'.$article['mipurl'].'",
    "appid": "'.$_G['cache']['plugin']['onexin_mip']['appid'].'",
    "title": "'.$article['title'].'",
    "images": ['.$article['images'].'],
    "pubDate": "'.$article['datetime'].'"
}
</script>';

	return $xzh."\r\n";
}
	
// mip template
function _onexin_mip_template($_theme = '', $id = 0, $dir = 'source/plugin/onexin_mip/template'){	
	global $_G; 

	//Fix
	$pc_file = DISCUZ_ROOT.'./data/diy/'.$dir.'/'.$_theme.'.htm';
	$touch_file = DISCUZ_ROOT.'./data/diy/'.$dir.'/touch/'.$_theme.'.htm';					
	if(file_exists($pc_file) && !file_exists($touch_file)){
		dmkdir(DISCUZ_ROOT.'./data/diy/'.$dir.'/touch/', 0777, false);
		@copy($pc_file, $touch_file);						
	}else{
		if(filemtime($touch_file) < filemtime($pc_file)) {
			unlink($touch_file);
		}
	}

	return template('diy:'.$_theme, $id, $dir);	   
	
}
	
// mip domain
function _onexin_mip_domain($canonical = ''){
	global $_G;    
	
	$conf = $_G['cache']['plugin']['onexin_mip']; 	
	if($conf['mipdomain']){
		$search = $replace = array();
		$search[] = $_G['siteurl'].$conf['slash'];
		$replace[] = $conf['mipdomain'];
		
		$search[] = $_G['siteurl'];
		$replace[] = $conf['mipdomain'];
		
		$search[] = '&mip=1';
		$replace[] = '';
		
		$canonical = str_replace($search, $replace, $canonical);
	}
	return $canonical;
}

// autopush script
function _onexin_mip_autopush($data = array()){
	global $_G;     
	return '';
	
	$conf = $_G['cache']['plugin']['onexin_mip'];
	
	if(!$conf['autopush']) return;
	
	$latest = TIMESTAMP - intval($conf['latest']) * 8 *3600;
	if($data['dateline'] < $latest){
		return '<!--onexin.mip.autopush-->';
	}
	
	// check today 
	$todaylist = _mip_getcache();
	
	$url = $data['url'];
	$mipapi = trim($conf['mipapi']);
	$k = md5($url.$mipapi);
	if($todaylist[$k]['code'] == 200) {
		return '<!--onexin.mip.success-->';
	}
	
	$url = urlencode($url);
			
	return 	"<script src=\"{$_G[siteurl]}plugin.php?id=onexin_mip&op=manage&view=todaysubmit&mipurls={$url}&_={$data['dateline']}\"></script>";
}

// MIP OUTPUT
function _onexin_mip_output() {
	global $_G;
	
	$content = ob_get_contents();
	
	$havedomain = implode('', $_G['setting']['domain']['app']);
	if($_G['setting']['rewritestatus'] || !empty($havedomain)) {
		$content = output_replace($content);
	}
	//$content = str_replace('{siteurl}', $_G['siteurl'], $content);

	ob_end_clean();
	$_G['gzipcompress'] ? ob_start('ob_gzhandler') : ob_start();
		
	if(CHARSET != 'utf-8' && $_GET['diy'] != 'yes'){
		@header('Content-Type: text/html; charset=utf-8');
		$content = _onexin_mip_charset($content, 1);
	}
	echo $content;
}

// AJAX OUTPUT
function _onexin_mip_ajax($output = array()){
	$items = array();
	foreach($output as $val){
		$items[] = $val;
	}
	$output = array(
		"status" => 0, 
		"data" => array("items" => $items)
	);
	if(CHARSET != 'utf-8' && $_GET['diy'] != 'yes'){
		@header('Content-Type: text/html; charset=utf-8');
		$output = _onexin_mip_charset($output, 1);
	}	
	$output = !empty($output) ? $output : array("result" => '404', "content" => 'NOT FOUND');
	echo (isset($_GET['callback'])) ? htmlspecialchars($_GET['callback']).'('.json_encode($output).')' : json_encode($output);	
    exit;
}

// OUTPUT
function _mip_output($output = array()){
	if(empty($output['status'])){
	  $items = array();
	  foreach($output as $val){
		  $items[] = $val;
	  }
	  $output = array(
		  "status" => 0, 
		  "data" => array("items" => $items)
	  );
	  if(CHARSET != 'utf-8' && $_GET['diy'] != 'yes'){
		  @header('Content-Type: text/html; charset=utf-8');
		  $output = _onexin_mip_charset($output, 1);
	  }	
	}
	$output = !empty($output) ? $output : array("result" => '404', "content" => 'NOT FOUND');
	echo (isset($_GET['callback'])) ? htmlspecialchars($_GET['callback']).'('.json_encode($output).')' : json_encode($output);	
    exit;
}

function _mip_push($urls = array(), $api = '') {
    if(empty($urls)) return;
$ch = curl_init();
$options =  array(
    CURLOPT_URL => $api,
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => implode("\n", $urls),
    CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
    CURLOPT_TIMEOUT => 5,
    CURLOPT_CONNECTTIMEOUT => 5,
);
curl_setopt_array($ch, $options);
$result = curl_exec($ch);

	return $result;
}

function _mip_getcache_statslist(){

    $list = _mip_getcache();
	
$langtxt = array();
$langtxt['thread'] = '&#35770;&#22363;&#20869;&#23481;&#39029;';//论坛内容页
$langtxt['article'] = '&#38376;&#25143;&#25991;&#31456;&#39029;';//门户文章页
$langtxt['unknow'] = '&#26410;&#30693;&#39029;';//未知内容页
    
    $data = array();
    foreach($list as $val){
        if(!empty($val['url'])) {
            if(empty($val['title'])) {$val['title'] = $val['url'];}
            if($val['code']=='200') {
                $input = "<input type=\"checkbox\" disabled />";
            }else{
                $input = "<input class=\"checkbox\" type=\"checkbox\" name=\"tidarray[]\" value=\"{$val[id]}\" data-url=\"{$val[url]}\" />";    
            }
			$val['type'] = isset($langtxt[$val['type']]) ? $langtxt[$val['type']] : $val['type'];
			$val['mode'] = ($val['mode'] == '2') ? '&#33258;&#21160;' : $val['mode'];
			$val['mode'] = ($val['mode'] == '1') ? '&#25163;&#21160;' : $val['mode'];
			
			$MIPCache = "<a href=\"javascript:;\" id=\"mipcache\" data-url=\"{$val[url]}\" target=\"_blank\">(MIP-Cache)</a>";
            $data[strtotime($val['time']).$val['url']] = "<tr class=\"log-{$val[id]} hover\"><td class=\"td25\">{$input}</td><td class=\"td25\">{$val[code]}</td><td>{$MIPCache} <a href=\"{$val[url]}\" target=\"_blank\">{$val[title]}</a></td><td>{$val[type]}</td><td>{$val[num]}</td><td class=\"td25\">{$val[mode]}</td><td>{$val[time]}</td></tr>";
        }   
    }
    krsort($data);
    
    return $data;
}

function _mip_getcache($key = ''){    
    $today = strtotime('today');
    $key = !empty($key) ? $key : date('d', $today); 
    $dir = DISCUZ_ROOT.'./source/plugin/onexin_mip';//dirname(__FILE__);
	$list = array();
    $file = $dir.'/cache/'.$key.'.js';
	if(file_exists($file)){
		$_OBD_SET = array();
		$_OBD_SET = json_decode(file_get_contents($file), true);
		//include_once $file;
        $list = $_OBD_SET[$key];
    }   
	
	// 3 days ago
    $file = $dir.'/cache/'.date('d', $today - 3*24*3600).'.js';
	if(file_exists($file)){
		@unlink($file);
    }
	
    return $list;
}

function _mip_setcache($key = '', $data = array(), $expire = 300){
	if(empty($data)) return;
    $today = strtotime('today');
    $key = !empty($key) ? $key : date('d', $today); 
    $dir = DISCUZ_ROOT.'./source/plugin/onexin_mip';//dirname(__FILE__);
    $val = array();
    $val[$key] = $data;
    $file = $dir.'/cache/'.$key.'.js';
    //$val[$key]['expire'] = time();
/*	
	$code = "<?php\n\rif(!defined('IN_DISCUZ')) { exit('Access Denied'); }\n\r//". date('Y-m-d H:i:s')." Created\n\r\$_OBD_SET = ". var_export($val, true). ";?>";
*/	
	$code = "". json_encode($val). "";
	file_put_contents($file, $code);    
}
