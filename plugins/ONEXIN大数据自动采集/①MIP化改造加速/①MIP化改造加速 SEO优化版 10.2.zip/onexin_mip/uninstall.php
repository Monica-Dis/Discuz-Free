<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2019-08-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2021 by dism.taobao.com (http://dism.taobao.com)
 */

/*
//--------------Tall us what you think!----------------------------------
*/
 
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

// common_syscache
DB::query("DELETE FROM ".DB::table('common_syscache')." WHERE cname='onexin_mip'");	

$finish = true;
