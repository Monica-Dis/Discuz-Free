<?php
/**
 * ONEXIN AMP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2018-05-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2018 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*	//carousel
	$i = 0;
	foreach($article['content'] as $key => $val){
		if($i >= 3) continue;
		if(preg_match("/<mip-img src=\"(.*?)\".*?>/", $val['content'], $match)){
			$val['content'] = $match[1];
			$article['carousel'][$i] = $val;
			$i++;
		}
	}
	//print_r($article['carousel']);exit;*/

    //message	
	$result = DB::fetch_all("SELECT tid, message FROM ".DB::table('forum_post')." WHERE first='1' AND tid IN (".dimplode($threadids).")");
	foreach($result as $val) {
		$index = $val['tid'];
			$val['summary'] = preg_replace("/\[attach\]\d+\[\/attach\]|\[img.*?\].*?\[\/img\]|\[.*?\]/", '', $val['message']);
			$val['summary'] = cutstr($val['summary'], 120);
			
		$val['div'] = '0';
		if(preg_match("/\[(video|media).*?\](.*?)\[\/\\1\]/", $val['message'], $matches)) {
			$val['message'] = $matches[0];
			$val['div'] = '5';
		}elseif(preg_match_all("/\[attach\](\d+)\[\/attach\]/", $val['message'], $matches)) {
			$pics = array_unique($matches[1]);
        	$num = 3;
			$image_list = array();
			$image_list = ( count($pics) > $num ) ? array_slice($pics, 0, $num) : $pics;        
			if(count($pics) == 2) $image_list = array_slice($pics, 0, 1);
			$val['div'] = (count($image_list) > 1) ? '3' : '1';
			$images = array();
			foreach($image_list as $v){
				//$imgurl = $_G['siteurl'].getforumimg($matches[1], 0, 232, 154, 'fixwr');
				$imgurl = _onexin_mip_getforumimg($v, 0, 232, 154, 'fixwr');
				$images[] = '<img src="'.$imgurl.'" width="232" height="154">';
			}
			$val['message'] = implode('', $images);
		}else{
			$val['message'] = $val['summary'];
		}
		
		$article['content'][$index]['content'] = _onexin_mip($val['message']);
		$article['content'][$index]['summary'] = _onexin_mip($val['summary']);
		$article['content'][$index]['div'] = $val['div'];
	}
	

