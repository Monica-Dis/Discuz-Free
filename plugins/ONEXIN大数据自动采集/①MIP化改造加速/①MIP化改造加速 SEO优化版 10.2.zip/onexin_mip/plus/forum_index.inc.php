<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2018-05-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2018 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}	
		
// cagegory name
if(!isset($_G['cache']['forums'])) {
    loadcache('forums');
}
$forumcache = &$_G['cache']['forums'];
$catlist=array();
foreach($forumcache as $forum) { 
    if($forum['status'] && $forum['type'] == 'forum'){
        $catlist[] = $forum['fid']; 
    }
}
$_G['fid'] = $catlist[array_rand($catlist)];
		
if(empty($_G['fid'])) $_G['fid']	= is_numeric($_GET['fid']) ? abs(intval($_GET['fid'])) : 0;
		
if($_G['fid']) {
	if(!isset($_G['cache']['plugin'])){
		loadcache('plugin');
	}		
	
	// page
	$page = max(1, intval($_GET['page']));	
	$perpage = 20;
	$page = empty($page) ? 1 : min($page, 5000);
	$start = ($page-1)*$perpage;
	
	// list fid='$_G[fid]' AND 
	$result = DB::fetch_all("SELECT * FROM ".DB::table("forum_thread")." 
		WHERE displayorder!='-1' ORDER BY tid DESC LIMIT $start, $perpage");
	$thread = $threadids = array();
	foreach($result as $val) {
		$val['dateline'] = dgmdate($val['dateline'], 'Y-m-d H:i:s');
		$val['title'] = $val['subject'];
		
		// canonical
		if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$canonical = $_G['siteurl'].rewriteoutput('forum_viewthread', 1, '', $val['tid'], 1, '', '');
		} else {
			$canonical = $_G['siteurl'].'forum.php?mod=viewthread&tid='.$val['tid'];
		}
		$val['url'] = $canonical;
		unset($val['subject']);
		$thread['content'][$val['tid']] = $val;
		$threadids[] = $val['tid'];
	}	
	
}else{
	dheader("location: $_G[siteurl]");	
}

///////////////////////////////////////////////////////////////
	
		// site logo
		$_G['cache']['plugin']['onexin_mip']['sitelogo'] = str_replace('{siteurl}', $_G['siteurl'], $_G['cache']['plugin']['onexin_mip']['sitelogo']);
		
		// canonical
		if(!empty($_G['cache']['plugin']['onexin_mip']['mipindex'])) {
			$canonical = $_G['siteurl'];
		} else {
			$canonical = $_G['siteurl'];
		}

		// mipurl
		if(!empty($_G['cache']['plugin']['onexin_mip']['mipindex'])) {
			$mipurl = $_G['siteurl'].$_G['cache']['plugin']['onexin_mip']['slash'];
		} else {
			$mipurl = $_G['siteurl'].'?mip=1';
		}
		
		// cagegory name
		if(!isset($_G['cache']['forums'])) {
			loadcache('forums');
		}
		$category = $_G['cache']['forums'][$_G['fid']];
		
	//article
	$article = array();
	$article['title']         = $_G['cache']['plugin']['onexin_mip']['sitename'];
	$article['content']       = !empty($thread['content']) ? $thread['content'] : $thread['subject'];
	$article['dateline']      = dgmdate($_G['timestamp'], 'Y-m-d H:i:s');//dgmdate($thread['dateline'], 'u');
	$article['datetime']      = str_replace(' ', 'T', $article['dateline']);
	$article['images']        = '';//
	$article['url']           = $_G['siteurl'];
	$article['mipurl']        = _onexin_mip_domain($mipurl);
	$article['caturl']        = $canonical;
	$article['catname']       = $category['name'];	
	$article['author']        = '';//$thread['author'];	
	
	$_G['cache']['plugin']['onexin_mip']['htmlcss'] = _onexin_mip_xzh($article).$_G['cache']['plugin']['onexin_mip']['htmlcss'];
			
	$article['aside'] = '';
	include_once DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/aside.forum_index_related.php';
	
	//callback
	if(isset($_GET['callback'])){
		_onexin_mip_ajax($article['content']);				
	}
	
	//charset
//	if(CHARSET != 'utf-8'){
//		@header('Content-Type: text/html; charset=utf-8');
//		$_G['cache']['plugin']['onexin_mip'] = _onexin_mip_charset($_G['cache']['plugin']['onexin_mip'], 1);
//		$article = _onexin_mip_charset($article, 1);
//	}
	//print_r($article);
	
	// 1.0
	$miplangarr = explode("\r", $_G['cache']['plugin']['onexin_mip']['miplang']);
	$miplang = array();
	foreach($miplangarr as $key => $val) {
		$data = explode('=', trim($val));
		if($data[1]) {			
			$miplang[trim($data[0])] = trim($data[1]);
		}
	}
	//print_r($miplang);exit;

//SEO
$_theme = 'onexin_mip_forum_index';

//include_once template('onexin_mip:'.$_theme);
include_once _onexin_mip_template($_theme);	
exit;