<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2019-11-15
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2021 by dism.taobao.com (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$_G['tid']	= is_numeric($_GET['tid']) ? abs(intval($_GET['tid'])) : 0;
		
if($_G['tid']) {
	if(!isset($_G['cache']['plugin'])){
		loadcache('plugin');
	}		
	
	//message
	$thread = DB::fetch_first("SELECT * FROM ".DB::table("forum_post")." 
		WHERE tid='$_G[tid]' AND first = '1'");
	
	//invisible
	if($thread['invisible'] == '-1'){
		// 404
		dheader('location: ' . $_G['siteurl']);
	}	
	
	if($thread['htmlon'] == '1'){
		require_once libfile('function/editor');
		$thread['message'] = html2bbcode($thread['message']);	
	}	
	
	$thread['message'] = dhtmlspecialchars(str_replace('\\"', '"', $thread['message']));
	
	$val = array();
	$val['content'] = nl2br($thread['message']);
	
		$parse = parse_url($_G['setting']['attachurl']);
		$attachurl = !isset($parse['host']) ? $_G['siteurl'].$_G['setting']['attachurl'] : $_G['setting']['attachurl'];
	
	//attachment
	$i= '1';
	$query = DB::fetch_all("SELECT p.aid,p.pid,p.remote,p.thumb,p.attachment 
		FROM ".DB::table(getattachtablebytid($_G['tid']))." p
		WHERE p.tid='$_G[tid]' AND p.isimage IN (1,-1) ORDER BY p.aid ASC");	
	$photo_list = $photo_pid = $serchurl = $replaceurl = array();
    foreach($query as $result) {
		$result['attachment'] = ($result['remote'] ? $_G['setting']['ftp']['attachurl'] : $attachurl).'forum/'.$result['attachment'];
		if($result['thumb']) $result['attachment'] = $result['attachment'].'.thumb.jpg';
		$photo_list[$i] = $result;
		$photo_pid[] = $result['pid'];
		$serchurl[$i] = '[attach]'.$result['aid'].'[/attach]';
		$replaceurl[$i] = '<img src="'.$result['attachment'].'" width="300" height="211">';
        $i++;
	}
	
    //message
	if($val['content']){	
        $val['content'] = str_replace($serchurl, $replaceurl, $val['content']);
        foreach($photo_list as $key => $result){
            //if(!preg_match("/".$replaceurl[$key]."/", $val['content'])) $val['content'] .= $replaceurl[$key];
        }
	
		$search = $replace = array();
		if(!empty($_G['cache']['plugin']['onexin_mip']['hidecode'])){
			$hide = trim($_G['cache']['plugin']['onexin_mip']['hidecode']);
			$val['content'] = preg_replace("/\[(".$hide.")\].*?\[\/\\1\]/is", '', $val['content']);
		}
	
        $val['content'] = preg_replace("/\<script.*?\<\/script\>|\<style.*?\<\/style\>/is", "", $val['content']);
        $val['content'] = preg_replace("/\[img.*?\](.*?)\[\/img\]/", '<img src="\\1" width="300" height="211">', trim($val['content']));
        $val['content'] = preg_replace("/\[url=(.*?)\](.*?)\[\/url\]/", '<a href="\\1" target="_blank">\\2</a>', $val['content']);
        //$val['content'] = preg_replace("/\[.*?\]/", "", $val['content']);
		
		//src="data/attachment 
        $val['content'] = str_replace(' src="data/attachment', ' src="'.$_G['siteurl'].'data/attachment', $val['content']);
        /*$val['content'] = preg_replace("/<img .*?>/", '<p align="center">\\0</p>', trim($val['content'])); */
        
		$val['content'] = preg_replace($search, $replace, $val['content']);
	}
	//print_r($val['content']);exit();
	$thread['content'] = _onexin_mip($val['content']);
	
}else{
	dheader("location: $_G[siteurl]");	
}

///////////////////////////////////////////////////////////////
	
		// site logo
		$_G['cache']['plugin']['onexin_mip']['sitelogo'] = str_replace('{siteurl}', $_G['siteurl'], $_G['cache']['plugin']['onexin_mip']['sitelogo']);
		
		// page
		$page = intval($_GET['page']);
		
		// canonical
		if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$canonical = $_G['siteurl'].rewriteoutput('forum_viewthread', 1, '', $_G['tid'], ($page> 1 ? $page : ''), '', '');
		} else {
			$canonical = $_G['siteurl'].'forum.php?mod=viewthread&tid='.$_G['tid'].($page> 1 ? '&page='.$page : "");
		}
		
		// fix "{fid}"
		$canonical = str_replace('{fid}', ($_G['setting']['forumkeys'][$_G['fid']] ? $_G['setting']['forumkeys'][$_G['fid']] : $_G['fid']), $canonical);
		
		// category url
		if(in_array('forum_forumdisplay', $_G['setting']['rewritestatus'])) {
			$caturl = $_G['siteurl'].rewriteoutput('forum_forumdisplay', 1, '', $thread['fid'], 1, '');
		} else {
			$caturl = $_G['siteurl'].'forum.php?mod=forumdisplay&fid='.$thread['fid'];
		}

		// mipurl
		if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$mipurl = $_G['siteurl'].$_G['cache']['plugin']['onexin_mip']['slash'].rewriteoutput('forum_viewthread', 1, '', $_G['tid'], ($page> 1 ? $page : ''), '', '');
		} else {
			$mipurl = $_G['siteurl'].'forum.php?mod=viewthread&tid='.$_G['tid'].($page> 1 ? '&page='.$page : "").'&mip=1';
		}
		
		// fix "{fid}"
		$mipurl = str_replace('{fid}', ($_G['setting']['forumkeys'][$_G['fid']] ? $_G['setting']['forumkeys'][$_G['fid']] : $_G['fid']), $mipurl);
		
		// cagegory name
		if(!isset($_G['cache']['forums'])) {
			loadcache('forums');
		}
		$category = $_G['cache']['forums'][$thread['fid']];
		
	//article
	$article = array();
	$article['title']         = $thread['subject'];
	$article['content']       = !empty($thread['content']) ? trim($thread['content']) : $thread['subject'];
	$article['dateline']      = dgmdate($thread['dateline'], 'Y-m-d H:i:s');//dgmdate($thread['dateline'], 'u');
	$article['datetime']      = str_replace(' ', 'T', $article['dateline']);
	$article['images']        = _onexin_mip_images($val['content']);	
	$article['url']           = $canonical;
	$article['mipurl']        = _onexin_mip_domain($mipurl);
	$article['caturl']        = $caturl;
	$article['catname']       = $category['name'];	
	$article['author']        = $thread['author'];
	
	$_G['cache']['plugin']['onexin_mip']['htmlcss'] = _onexin_mip_xzh($article).$_G['cache']['plugin']['onexin_mip']['htmlcss'];
			
	$article['aside'] = '';
	include_once DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/aside.forum_related.php';
	
	//charset
//	if(CHARSET != 'utf-8' && $_GET['diy'] != 'yes'){
//		@header('Content-Type: text/html; charset=utf-8');
//		$_G['cache']['plugin']['onexin_mip'] = _onexin_mip_charset($_G['cache']['plugin']['onexin_mip'], 1);
//		$article = _onexin_mip_charset($article, 1);
//	}
	//print_r($article);
	
	// 1.0
	$miplangarr = explode("\r", $_G['cache']['plugin']['onexin_mip']['miplang']);
	$miplang = array();
	foreach($miplangarr as $key => $val) {
		$data = explode('=', trim($val));
		if($data[1]) {			
			$miplang[trim($data[0])] = trim($data[1]);
		}
	}
	//print_r($miplang);exit;

//SEO
$_theme = 'onexin_mip_forum_view';

//include_once template('onexin_mip:'.$_theme);
include_once _onexin_mip_template($_theme);	
exit;
