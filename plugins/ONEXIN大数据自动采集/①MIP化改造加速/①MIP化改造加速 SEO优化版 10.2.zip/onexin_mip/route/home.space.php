<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2017-10-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2017 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------
*/

/*

home.php?mod=space&uid=1&do=profile

home.php?mod=space&uid=1&do=blog&id=23

*/


		$yourfile = DISCUZ_ROOT.'./source/plugin/onexin_mip/route/home.space.'.trim($_GET['do'], '/').'.php';
		if(file_exists($yourfile)){
			include $yourfile;
		}

