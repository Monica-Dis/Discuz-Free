<?php
/**
 * ONEXIN MIP For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_mip
 * @module	   mip 
 * @date	   2017-10-07
 * @author	   https://dism.taobao.com
 * @copyright  Copyright (c) 2017 Onexin Platform Inc. (http://dism.taobao.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------
*/

            _forum_index_onexin_mip_output();
//        if(CURMODULE == 'viewthread'){
//        }
		
	function _forum_index_onexin_mip_output() {
		global $_G, $postlist;
			
			$conf = $_G['cache']['plugin']['onexin_mip'];
			
		$yourfile = DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/forum_index.inc.php';
		if(!file_exists($yourfile)){
			return '';
		}

		if(isset($_GET['mip']) || $_G['siteurl'] == $conf['mipdomain']) {
			include DISCUZ_ROOT.'./source/plugin/onexin_mip/plus/forum_index.inc.php';
		}	

		// url
		if(!empty($conf['mipindex'])) {
			$url = $_G['siteurl'];
		} else {
			$url = $_G['siteurl'];
		}

		// canonical
		if(!empty($conf['mipindex'])) {
			$canonical = $_G['siteurl'].$conf['slash'];
		} else {
			$canonical = $_G['siteurl'].'?mip=1';
		}
		
		// mip domain
		$canonical = _onexin_mip_domain($canonical);
									
		$_G['setting']['seohead'] = "<link rel=\"canonical\" href=\"".$url."\" />\r" . 
			preg_replace("/<link[^>]*rel=\"canonical\"[^>]*>/i", "", $_G['setting']['seohead']) ."\r\n";
				  
		$_G['setting']['seohead'] .= "<link rel=\"miphtml\" href=\"".$canonical."\" />";
		
		// head
        $data = array(
            'url' => $canonical,
            'dateline' => $_G['timestamp']
        );
		$_G['setting']['seohead'] .= _onexin_mip_autopush($data);
		
		return '';
	}
