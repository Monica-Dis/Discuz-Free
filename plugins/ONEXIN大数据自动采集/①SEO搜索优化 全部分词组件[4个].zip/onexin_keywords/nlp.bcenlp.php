<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module	   keywords
 * @date	   2020-01-06
 * @author	   应用更新支持：https://dism.taobao.com
 * @copyright  Copyright 2001-2099 DisM!应用中心.
 */

//---------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

开通百度NLP词法分析，打开下面网址，创建应用并获取key
https://console.bce.baidu.com/ai/#/ai/nlp/overview/index

*/

$words = _onexin_keywords_nlp($keyword, $conf);

function _onexin_keywords_nlp($keyword, $conf){	
	global $_G;	

	if(empty($conf['nlpapi'])) {
		return '';
	}
	
	// bcenlp
	$app_key = "G8lGyvu1vxxxxxxxxx";#你的 Api Key
	$secret  = "8A4M68s4Cxxxxxxxxxxxxxxxx";#你的 Secret Key
	
		// [引擎名]#api key#secret key#
		$arr = explode("[".$conf['nlp']."]", $conf['nlpapi']);
			$data = explode('#', trim($arr[1]));
			if(!empty($data[2])) {
				$app_key = $data[1];
				$secret = $data[2];
			}else{
				return '';
			}
	
	if(CHARSET != 'utf-8'){
		$keyword = diconv(trim($keyword), CHARSET, 'utf-8');
	}

//-----------------------------------------------
	
	// 获取token
	$url = 'https://aip.baidubce.com/oauth/2.0/token';
    $post_data = array();
    $post_data['grant_type']      = 'client_credentials';
    $post_data['client_id']       = $app_key;
    $post_data['client_secret']   = $secret;
    $o = "";
    foreach ( $post_data as $k => $v ) {
    	$o.= "$k=" . urlencode( $v ). "&" ;
    }
    $post_data = substr($o,0,-1);	
    $res = onexin_keywords_request($url, $post_data);	
	
	$access_token = $res['access_token'];
	
	// 词法分析
	$url = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/lexer?charset=UTF-8&access_token='.$access_token;	
	$post_data = json_encode(array(
		"text"=>$keyword// 20000
	));
	$contents = onexin_keywords_request($url, $post_data);	
	//print_r($contents);
	
	$wordrank = array();	
	foreach($contents['items'] as $key => $val){		
		if(!preg_match("/\w+/", $val['item']) && strlen($val['item']) <= 3) continue;
		$wordrank[] = $val['item'];
	}
	
	$contents = implode(' ', array_slice(array_unique($wordrank), 0, 10));
	
//-----------------------------------------------
		
	if(CHARSET != 'utf-8'){
		$contents = diconv(trim($contents), 'utf-8', CHARSET);
	}
	
	$return = str_replace(",", " ", $contents);
	
	return dhtmlspecialchars($return);	
}

function onexin_keywords_request($url = '', $post_data = '', $headers = array()) {
	if (empty($url) || empty($post_data)) {
		return false;
	}

	$ch= curl_init($url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	if(!empty($headers)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	}
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);	
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2); // 从证书中检查SSL加密算法是否存在
	if(!empty($post_data)) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	}
	curl_setopt($ch, CURLOPT_TIMEOUT, 3);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
	$contents = curl_exec($ch);   
	curl_close($ch);		
	$contents = json_decode($contents, true);	
	
	return $contents;
}

