<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module	   keywords
 * @date	   2020-01-12
 * @author	   应用更新支持：https://dism.taobao.com
 * @copyright  Copyright 2001-2099 DisM!应用中心.
 */

//---------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

开通NLP自然语言处理
https://common-buy.aliyun.com/?commodityCode=nlp#/open

打开下面网址，创建应用并获取key
https://usercenter.console.aliyun.com/#/manage/ak

*/

$words = _onexin_keywords_nlp($keyword, $conf);

function _onexin_keywords_nlp($keyword, $conf){	
	global $_G;	

	if(empty($conf['nlpapi'])) {
		return '';
	}
	
	// ak
	$ak_id = "G8lGyvu1vxxxxxxxxx";#你的 Api Key
	$ak_secret  = "8A4M68s4Cxxxxxxxxxxxxxxxx";#你的 Secret Key
	
		// [引擎名]#api key#secret key#
		$arr = explode("[".$conf['nlp']."]", $conf['nlpapi']);
			$data = explode('#', trim($arr[1]));
			if(!empty($data[2])) {
				$ak_id = $data[1];
				$ak_secret = $data[2];
			}else{
				return '';
			}
	
	if(CHARSET != 'utf-8'){
		$keyword = diconv(trim($keyword), CHARSET, 'utf-8');
	}

//-----------------------------------------------
	
	// nlp
	$url = 'http://nlp.cn-shanghai.aliyuncs.com/nlp/api/wordsegment/general?Version=2018-04-08';
	$post_data = json_encode(array(
		"lang"=>"ZH", 
		"text"=>$keyword
	));	
	
			$version = "1.0";
			$user_agent = 'AlibabaCloud (WINNT 10.0; i586) Client/1.5.19 PHP/5.6.27';
			$method = "POST";
            $accept = "application/json";
            $content_type = "application/json;chrset=utf-8";
            $path = "/nlp/api/wordsegment/general?Version=2018-04-08";
			$date = gmdate('D, d M Y H:i:s \G\M\T');//toGMTString(new Date());
            $host = "nlp.cn-shanghai.aliyuncs.com";
            $region = "cn-shanghai";
			// 1.对body做MD5+BASE64加密
            $bodyMd5 = "";//base64_encode(md5($post_data));
            $uuid = md5(uniqid(rand(), TRUE));
			$stringToSign = $method . "\n" . $accept . "\n" . $bodyMd5 . "\n" . $content_type . "\n" . $date . "\n" 
                    . "x-acs-region-id:" . $region . "\n"                                                  
                    . "x-acs-signature-method:HMAC-SHA1\n"
                    . "x-acs-signature-nonce:" . $uuid . "\n"                                  
                    . "x-acs-signature-version:" . $version . "\n"                           
                    . "x-acs-version:2018-04-08\n"
                    . $path;
			// 2.计算 HMAC-SHA1
			$signature = base64_encode(hash_hmac('sha1', $stringToSign, $ak_secret, true));
            // 3.得到 authorization header
            $authHeader = "acs " . $ak_id . ":" . $signature;    
			
			// 设置通用的请求属性
			$headers =  array();
			$headers[] =  'User-Agent: '.$user_agent;
			$headers[] =  'x-acs-version: 2018-04-08'; 
			$headers[] =  'x-acs-region-id: cn-shanghai'; 
			$headers[] =  'Date: '.$date;
			$headers[] =  'x-acs-signature-method: HMAC-SHA1';
			$headers[] =  'x-acs-signature-nonce: '.$uuid;
			$headers[] =  'x-acs-signature-version: '.$version;
			$headers[] =  'Accept: '.$accept;
			$headers[] =  'Content-Type: '.$content_type;
			$headers[] =  'Authorization: '.$authHeader;
			//$headers[] =  'Content-MD5: '.$bodyMd5;
	
	$contents = onexin_keywords_request($url, $post_data, $headers);
	
	$wordrank = array();	
	foreach($contents['data'] as $key => $val){
		if(!preg_match("/\w+/", $val['word']) && strlen($val['word']) <= 3) continue;
		$wordrank[] = $val['word'];
	}
	
	$contents = implode(' ', array_slice(array_unique($wordrank), 0, 10));
	
//-----------------------------------------------
		
	if(CHARSET != 'utf-8'){
		$contents = diconv(trim($contents), 'utf-8', CHARSET);
	}
	
	$return = str_replace(",", " ", $contents);
	
	return dhtmlspecialchars($return);	
}

function onexin_keywords_request($url = '', $post_data = '', $headers = array()) {
	if (empty($url) || empty($post_data)) {
		return false;
	}

	$ch= curl_init($url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	if(!empty($headers)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	}
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);	
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
//    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
//    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2); // 从证书中检查SSL加密算法是否存在
	if(!empty($post_data)) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	}
	curl_setopt($ch, CURLOPT_TIMEOUT, 3);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
	$contents = curl_exec($ch);   
	curl_close($ch);		
	$contents = json_decode($contents, true);	
	
	return $contents;
}

