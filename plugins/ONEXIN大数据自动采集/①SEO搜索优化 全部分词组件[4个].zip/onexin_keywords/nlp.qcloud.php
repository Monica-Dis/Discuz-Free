<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module	   keywords
 * @date	   2020-03-06
 * @author	   应用更新支持：https://dism.taobao.com
 * @copyright  Copyright 2001-2099 DisM!应用中心.
 */

//---------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

创建腾讯云API密钥
https://console.cloud.tencent.com/cam/capi

句法分析，可用于提取句子主干、提取句子核心词等

参考文档：
https://cloud.tencent.com/document/product/271/35510

仅支持UTF-8格式，不超过200字

*/

$words = _onexin_keywords_nlp($keyword, $conf);

function _onexin_keywords_nlp($keyword, $conf){	
	global $_G;	

	if(empty($conf['nlpapi'])) {
		return '';
	}
	
		// [引擎名]#api key#secret key#
		$arr = explode("[".$conf['nlp']."]", $conf['nlpapi']);
			$data = explode('#', trim($arr[1]));
			if(empty($data[2])) {
				return '';
			}
				$secretId = $data[1];#你的 Api Key
				$secretKey = $data[2];#你的 Secret Key
	
	if(CHARSET != 'utf-8'){
		$keyword = diconv(trim($keyword), CHARSET, 'utf-8');
	}

//-----------------------------------------------
			$host = "nlp.tencentcloudapi.com";
			$service = "nlp";
			$version = "2019-04-08";
			$action = "LexicalAnalysis";
			$region = "ap-guangzhou";
			$timestamp = time();
			$algorithm = "TC3-HMAC-SHA256";
			
			// step 1: build canonical request string
			$httpRequestMethod = "POST";
			$canonicalUri = "/";
			$canonicalQueryString = "";
			$canonicalHeaders = "content-type:application/json; charset=utf-8\n"."host:".$host."\n";
			$signedHeaders = "content-type;host";
			$payload = '{"Text": "'.$keyword.'"}';
			$hashedRequestPayload = hash("SHA256", $payload);
			$canonicalRequest = $httpRequestMethod."\n"
				.$canonicalUri."\n"
				.$canonicalQueryString."\n"
				.$canonicalHeaders."\n"
				.$signedHeaders."\n"
				.$hashedRequestPayload;
			
			// step 2: build string to sign
			$date = gmdate("Y-m-d", $timestamp);
			$credentialScope = $date."/".$service."/tc3_request";
			$hashedCanonicalRequest = hash("SHA256", $canonicalRequest);
			$stringToSign = $algorithm."\n"
				.$timestamp."\n"
				.$credentialScope."\n"
				.$hashedCanonicalRequest;
			
			// step 3: sign string
			$secretDate = hash_hmac("SHA256", $date, "TC3".$secretKey, true);
			$secretService = hash_hmac("SHA256", $service, $secretDate, true);
			$secretSigning = hash_hmac("SHA256", "tc3_request", $secretService, true);
			$signature = hash_hmac("SHA256", $stringToSign, $secretSigning);
			
			// step 4: build authorization
			$authorization = $algorithm
				." Credential=".$secretId."/".$credentialScope
				.", SignedHeaders=content-type;host, Signature=".$signature;
			
			$url = "https://".$host;
			$post_data = $payload;
			
			// 设置通用的请求属性
			$headers =  array();
			$headers[] =  'Authorization: '.$authorization;
			$headers[] =  'Content-Type: application/json; charset=utf-8';
			$headers[] =  'Host: '.$host;
			$headers[] =  'X-TC-Action: '.$action;
			$headers[] =  'X-TC-Timestamp: '.$timestamp;
			$headers[] =  'X-TC-Version: '.$version;
			$headers[] =  'X-TC-Region: '.$region;
	
	$contents = onexin_aliyun_nlp_request($url, $post_data, $headers);
	//print_r($contents);
	
	$wordrank = array();	
	foreach($contents['Response']['PosTokens'] as $key => $val){		
		if(!preg_match("/\w+/", $val['Word']) && strlen($val['Word']) <= 3) continue;
		$wordrank[] = $val['Word'];
	}
	
	$contents = implode(' ', array_slice(array_unique($wordrank), 0, 10));
	
//-----------------------------------------------
		
	if(CHARSET != 'utf-8'){
		$contents = diconv(trim($contents), 'utf-8', CHARSET);
	}
	
	$return = str_replace(",", " ", $contents);
	
	return dhtmlspecialchars($return);	
}

function onexin_keywords_request($url = '', $post_data = '', $headers = array()) {
	if (empty($url) || empty($post_data)) {
		return false;
	}

	$ch= curl_init($url);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	if(!empty($headers)) {
		curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	}
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);	
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2); // 从证书中检查SSL加密算法是否存在
	if(!empty($post_data)) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	}
	curl_setopt($ch, CURLOPT_TIMEOUT, 3);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
	$contents = curl_exec($ch);   
	curl_close($ch);		
	$contents = json_decode($contents, true);	
	
	return $contents;
}

