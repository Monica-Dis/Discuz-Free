<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module	  di'.'sm.t'.'aoba'.'o.com
 * @date	   2020-04-24
 * 官方淘宝店铺：DisM.Taobao.Com
 * [DisM!] (C)2019-2021 DISM.Taobao.COM.
 */

/*
//--------------Tall us what you think!----------------------------------
*/

//
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		include_once DISCUZ_ROOT.'./source/plugin/onexin_keywords/function_keywords.php';

$operation = in_array($operation, array('admin')) ? $operation : 'admin';
$current = array($operation => 1);
$identifier = $plugin['identifier'];

if($operation == 'admin') {
	$tagarray = array();
	if(submitcheck('submit', 1) && !empty($_GET['tagidarray']) && is_array($_GET['tagidarray']) && !empty($_GET['operate_type'])) {
		$tagidarray = array();
		$operate_type = $newtag = $thread =  '';
		$tagidarray = $_GET['tagidarray'];
		$operate_type = $_GET['operate_type'];
		if($operate_type == 'delete') {
			$query = DB::fetch_all("SELECT * FROM ".DB::table('plugin_onexin_keywords')." WHERE id IN (".dimplode($tagidarray).")");
			foreach($query as $value) {
				onexin_keywords_delcache('search/all/'.$value['title']);
			}			
			DB::query("DELETE FROM ".DB::table('plugin_onexin_keywords')." WHERE id IN (".dimplode($tagidarray).")");
		} elseif($operate_type == 'open') {
			DB::query("UPDATE ".DB::table('plugin_onexin_keywords')." SET status = '0' WHERE id IN (".dimplode($tagidarray).")");
		} elseif($operate_type == 'close') {
			DB::query("UPDATE ".DB::table('plugin_onexin_keywords')." SET status = '1' WHERE id IN (".dimplode($tagidarray).")");
		}
		cpmsg('setting_update_succeed', 'action=plugins&operation=admin&tagname='.$_GET['tagname'].'&perpage='.$_GET['perpage'].'&status='.$_GET['status'].'&page='.$_GET['page']."&do=$pluginid&identifier=$identifier&pmod=onexin_advance", 'succeed');
	}elseif(submitcheck('searchsubmit', 1)) {   
		// 搜索，不存在时新建
		$tagname = addslashes(trim($_GET['tagname']));
		$description = addslashes(trim($_GET['description']));
		$keywords = addslashes(trim($_GET['keywords']));
		$words = addslashes(trim($_GET['words']));
		$keywords = !empty($keywords) ? $keywords : $tagname;
		
		if(!empty($description) || !empty($words)){
			// description		
			$tagid = DB::result_first("SELECT id FROM ".DB::table('plugin_onexin_keywords')." WHERE title='$tagname'");
			if($tagid > 0) {
				DB::query("UPDATE ".DB::table('plugin_onexin_keywords')." SET words = '$words', keywords = '$keywords', description = '$description', dateline='$_G[timestamp]' WHERE id='$tagid'");
			}else{				
				if(!empty($tagname)) DB::query("INSERT INTO ".DB::table('plugin_onexin_keywords')." (title, keywords, description) VALUES ('$tagname', '$keywords', '$description')");
			}
				// update
				$articlelist = onexin_keywords_getcache('search/all/'.$tagname);
				$articlelist['seo']['keywords'] = $keywords;
				$articlelist['seo']['description'] = $description;
				onexin_keywords_setcache('search/all/'.$tagname, $articlelist);
			
			cpmsg('setting_update_succeed', "action=plugins&operation=admin&do=$pluginid&identifier=$identifier&pmod=onexin_advance", 'succeed');
		}
	}
	
			// empty
			DB::query("DELETE FROM ".DB::table('plugin_onexin_keywords')." WHERE title=''");
		
			// keywords, description
			$tagname = addslashes(trim($_GET['tagname']));
			$result = DB::fetch_first("SELECT * FROM ".DB::table('plugin_onexin_keywords')." WHERE title='$tagname'");
			$description = !empty($result['description']) ? $result['description'] : "";
			$keywords = !empty($result['keywords']) ? $result['keywords'] : $tagname;
			$words = !empty($result['words']) ? $result['words'] : "";
			
			if($_GET['op'] == 'update') {
				onexin_keywords_delcache('search/all/'.$tagname);
				cpmsg('setting_update_succeed', 'action=plugins&operation=admin&perpage='.$_GET['perpage'].'&status='.$_GET['status'].'&page='.$_GET['page']."&do=$pluginid&identifier=$identifier&pmod=onexin_advance", 'succeed');
			}
    
	//if 
		showformheader("plugins&operation=admin&do=$pluginid&identifier=$identifier&pmod=onexin_advance");
		//showformheader('tag&operation=admin');
		showtableheader(); /*dism _ taobao _ com*/
		showsetting('search', 'tagname', $tagname, 'text');
		showsetting('SEO '.cplang('keywords'), 'keywords', $keywords, 'text');
		showsetting('SEO '.cplang('description'), 'description', $description, 'textarea');
		showsetting('SQL '.cplang('keywords'), 'words', $words, 'text');
		showsetting('feed_search_perpage', '', $_GET['perpage'], "<select name='perpage'><option value='100'>$lang[perpage_100]</option><option value='500'>500</option><option value='1000'>1000</option></select>");
//		showsetting('misc_tag_status', array('status', array(
//			array('', cplang('unlimited')),
//			array(0, cplang('misc_tag_status_0')),
//			array(1, cplang('misc_tag_status_1')),
//		), TRUE), '', 'mradio');
		showsubmit('searchsubmit');
		showtablefooter(); /*dis'.'m.t'.'ao'.'bao.com*/
		showformfooter();
	//} else {
		$tagname = trim($_GET['tagname']);
		$status = $_GET['status'];
		if(!$status) {
			$table_status = NULL;
		} else {
			$table_status = $status;
		}
		$ppp = !empty($_GET['perpage']) ? $_GET['perpage']: '100';;
		$startlimit = ($page - 1) * $ppp;
		
		//$totalcount  = C::t('common_tag')->fetch_all_by_status($table_status, $tagname, 0, 0, 1);
		//$query = C::t('common_tag')->fetch_all_by_status($table_status, $tagname, $startlimit, $ppp, 0, 'DESC');
		
		$wheresql = '1=1';
		if($tagname){
			$wheresql .= " AND title LIKE '%$tagname%'";
		}
		
        $totalcount = DB::result_first("SELECT count(*) FROM ".DB::table('plugin_onexin_keywords')." WHERE $wheresql ORDER BY dateline DESC");        
        $query = DB::fetch_all("SELECT * FROM ".DB::table('plugin_onexin_keywords')." WHERE $wheresql ORDER BY dateline DESC LIMIT $startlimit, $ppp");
		
		$multipage = '';
		$multipage = multi($totalcount, $ppp, $page, ADMINSCRIPT."?action=plugins&operation=admin&tagname=$tagname&perpage=$ppp&status=$status"."&do=$pluginid&identifier=$identifier&pmod=onexin_advance");
		
		
		showformheader("plugins&operation=admin&do=$pluginid&identifier=$identifier&pmod=onexin_advance");
		//showformheader('tag&operation=admin');
		showtableheader(cplang('search').' '.$totalcount.' ', 'nobottom');
		showhiddenfields(array('page' => $_GET['page'], 'tagname' => $tagname, 'status' => $status, 'perpage' => $ppp));
		showsubtitle(array('', 'search', 'SEO '.cplang('keywords'), 'SEO '.cplang('description'), 'num', 'misc_tag_status'));
		$onexin_keywords_conf = $_G['cache']['plugin']['onexin_keywords'];
		foreach($query as $result) {
			if($result['status'] == 0) {
				$tagstatus = cplang('misc_tag_status_0');
			} elseif($result['status'] == 1) {
				$tagstatus = cplang('misc_tag_status_1');
			}
					if(!$onexin_keywords_conf['ischinese']){
						$urltagname = $result['id'];
					}else{
						$urltagname = urlencode(CHARSET != 'utf-8' ? diconv($result['title'], CHARSET, 'utf-8') : $result['title']);
					}
				if($onexin_keywords_conf['isrewrite']){
					$result['url'] = $onexin_keywords_conf['prefix'].$urltagname.$onexin_keywords_conf['suffix'];
				}else{
					$result['url'] = 'plugin.php?id=onexin_keywords&q='.$urltagname;
				}
			showtablerow('', array('class="td25"', 'width=100', 'width=200', '', 'width=30', 'width=30'), array(
				"<input class=\"checkbox\" type=\"checkbox\" name=\"tagidarray[]\" value=\"$result[id]\" />",
				"<a href=\"".$result['url']."\" target=\"_blank\">".$result['title']."</a>",
				($result['keywords'] ? $result['keywords'] : $result['title']),
				$result['description'] . 
					" <a href=\"".ADMINSCRIPT."?action=plugins&operation=admin&tagname=".$result['title']."&perpage=$ppp&status=$status"."&do=$pluginid&identifier=$identifier&pmod=onexin_advance"."\">".cplang('edit')."</a>" . 
					" <a href=\"".ADMINSCRIPT."?action=plugins&operation=admin&tagname=".$result['title']."&perpage=$ppp&status=$status"."&do=$pluginid&identifier=$identifier&pmod=onexin_advance&op=update"."\">".cplang('nav_updatecache')."</a>",
				$result['num'],
				$tagstatus
			));
		}
		showtablerow('', array('class="td25" colspan="6"'), array('<input name="chkall" id="chkall" type="checkbox" class="checkbox" onclick="checkAll(\'prefix\', this.form, \'tagidarray\', \'chkall\')" /><label for="chkall">'.cplang('select_all').'</label>'));
		showtablerow('', array('class="td25"', 'colspan="5"'), array(
				cplang('operation'),
				'<input class="radio" type="radio" name="operate_type" value="open" checked> '.cplang('misc_tag_status_0').' &nbsp; &nbsp;<input class="radio" type="radio" name="operate_type" value="close"> '.cplang('misc_tag_status_1').' &nbsp; &nbsp;<input class="radio" type="radio" name="operate_type" value="delete"> '.cplang('delete').''
				// &nbsp; &nbsp;<input class="radio" type="radio" name="operate_type" value="merge"> '.cplang('mergeto').' <input name="newtag" value="" class="txt" type="text">
			));
		showsubmit('submit', 'submit', '', '', $multipage);
		showtablefooter(); /*dis'.'m.t'.'ao'.'bao.com*/
		showformfooter();
		showtagfooter('div');
	//}
}
