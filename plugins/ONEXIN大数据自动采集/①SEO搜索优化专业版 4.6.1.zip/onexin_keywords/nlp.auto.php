<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module	  di'.'sm.t'.'aoba'.'o.com
 * @date	   2019-12-06
 * 官方淘宝店铺：DisM.Taobao.Com
 * 最新插件：http://t.cn/Aiux1Jx1
 */

//---------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

这是一个示例的nlp引擎，可根据接口进行功能扩展。

*/

$words = _onexin_keywords_nlp($keyword, $conf);

function _onexin_keywords_nlp($keyword, $conf = array()){	
	global $_G;	

	if(empty($conf['nlpapi'])) {
		return "";
	}
	
		// [引擎名]#api key#secret key#
		$arr = explode("[".$conf['nlp']."]", $conf['nlpapi']);
			$data = explode('#', trim($arr[1]));
			if(!empty($data[2])) {
				$app_key = $data[1];#你的 Api Key
				$secret = $data[2];#你的 Secret Key
			}
	
	if(CHARSET != 'utf-8'){
		$keyword = diconv(trim($keyword), CHARSET, 'utf-8');
	}

//-----------------------------------------------
	$contents = $keyword;	
//-----------------------------------------------
		
	if(CHARSET != 'utf-8'){
		$contents = diconv(trim($contents), 'utf-8', CHARSET);
	}
	
	$return = str_replace(",", " ", $contents);
	
	return dhtmlspecialchars($return);	
}
