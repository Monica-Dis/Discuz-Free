<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module	  di'.'sm.t'.'aoba'.'o.com
 * @date	   2020-07-20
 * 官方淘宝店铺：DisM.Taobao.Com
 * [DisM!] (C)2019-2021 DISM.Taobao.COM.
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------

#srchmod
1 portal
2 forum
5 group
3 blog 
4 album

/search.php?mod=forum&srchtxt=%C1%AC%D2%C2%C8%B9

*/

include_once DISCUZ_ROOT.'./source/plugin/onexin_keywords/function_keywords.php';

function onexin_keywords_censor($keyword){
	//$keyword = str_replace('.', '+', $keyword);
	//$keyword = str_replace('-', '+', $keyword);
	
	// 关键词过滤，censor函数由系统source/function/function_core.php引入
	$keyword = addslashes(censor($keyword));
	return $keyword;
}

$conf = $_G['cache']['plugin']['onexin_keywords'];
//$conf['ischinese'] = 0;

if(CURSCRIPT == 'search' && !empty($_GET['kw']) && !empty($_GET['mod'])){
	// 存在缓存文件加载
	$keyword = trim($_GET['kw']);
	
	$keyword = onexin_keywords_censor($keyword);
	
	// 加载缓存
	$articlelist = onexin_keywords_getcache('search/all/'.$keyword);	
	  
	//if(empty($articlelist['seo']['expire'][$_GET['mod']]) || ($_G['timestamp'] < $articlelist['expire']) ){	  
		//不同的模块设置不同的缓存时间	  
		$articlelist['seo']['expire'][$_GET['mod']] = 0;
		if(empty($articlelist['seo']['expire'][$_GET['mod']])) {
			onexin_keywords_setcache('search/all/'.$keyword, $articlelist);
		}
	
		// 网址关键词变数字
		$urltagname = stripslashes($keyword);
			$seo = DB::fetch_first("SELECT * FROM ".DB::table('plugin_onexin_keywords')." WHERE title='$keyword'");			
			$tagid = $seo['id'];
						
			// 是否记录搜索关键词
			if(empty($tagid) && $conf['iskw']) {
				DB::query("INSERT INTO ".DB::table('plugin_onexin_keywords')." (title,dateline) VALUES ('$keyword','$_G[timestamp]')");
				$tagid = DB::insert_id();
			}
			
			$words = $seo['words'];
			// 搜索预分词，如果搜索结果大于目标数，则跳过分词
			if(empty($words)) {
				$count = getcount('plugin_onexin_keywords', "title like '%$keyword%'");
				if($count > $conf['max']){
					$words = $keyword;
				}
			}
			
			// 搜索空格分词
			$wordarr = explode(' ', trim($keyword));
			if(empty($words) && count($wordarr) > 1) $words = implode(' ', $wordarr);
						
			// 搜索分词
			if(empty($words) && $conf['iswords']) {
				// nlp words
				$yourself_file = DISCUZ_ROOT . './source/plugin/onexin_keywords/nlp.'.$conf['nlp'].'.php';
				if(file_exists($yourself_file)){
					include_once $yourself_file;
				}else{
					include_once DISCUZ_ROOT . './source/plugin/onexin_keywords/nlp.auto.php';
				}					
					if(empty($words)) {
						$words = $keyword;
					}
			}							
				if(!empty($words)) {
					$words = addslashes($words);
					DB::query("UPDATE ".DB::table('plugin_onexin_keywords')." SET words = '$words' WHERE id='$tagid'");
				}
			
		if(!$conf['ischinese']){
			$urltagname = $tagid;
		}
	  
		// 转换为显示中文的网址
		$urltagname = urlencode(CHARSET != 'utf-8' ? diconv($urltagname, CHARSET, 'utf-8') : $urltagname);
				  
		$theurl = $conf['isrewrite'] ? $conf['prefix'].$urltagname.$conf['suffix'] : "plugin.php?id=onexin_keywords&q=".$urltagname;
		dheader("location: ".$theurl);
	//}
	
}
//-------------------------------------------------------------------------

if(isset($_GET['rewrite'])){
	if(preg_match("/^([^\/\.-]+)([-|\/]+(\d+))?(\/|\.html)?/", $_GET['rewrite'], $match)){
		$_GET['q'] = $match[1];
		$_GET['page'] = $match[3];
	}else{
		// 未知的
		dheader("location: ".$conf['url']);
	}
}

if(!empty($_GET['q'])) {
	  
	// 自动识别编码
	$fileType = mb_detect_encoding($_GET['q'] , array('UTF-8', 'GBK', 'BIG5')) ;   
	if( $fileType != 'UTF-8' ){   
		$_GET['q'] = mb_convert_encoding($_GET['q'] , 'UTF-8' , $fileType);   
	}
	
	// q的中文为utf8
	$keyword = CHARSET != 'utf-8' ? diconv($_GET['q'], 'utf-8') : $_GET['q'];
	$keyword = trim($keyword);
	  
	  // 关键词过滤
	  $keyword = onexin_keywords_censor($keyword);
	  
		// 反转网址关键词变数字
		$urltagname = stripslashes($keyword);
		if(!$conf['ischinese']){			
			$res = DB::fetch_first("SELECT * FROM ".DB::table('plugin_onexin_keywords')." WHERE id='$keyword'");
			if(!empty($res['status'])) {
				// 锁定的
				dheader("location: ".$conf['url']);				
			}
			$tagname = $res['title'];
			if(!empty($tagname)) {
				$keyword = $tagname;
			
				// 搜索分词
				$words = $res['words'];;
				
			// 搜索预分词
			if(empty($words)) {
				$count = getcount('plugin_onexin_keywords', "title like '%$keyword%'");
				if($count > $conf['max']){
					$words = $keyword;
				}
			}
			
				if(empty($words) && $conf['iswords']) {
					// nlp words
					$yourself_file = DISCUZ_ROOT . './source/plugin/onexin_keywords/nlp.'.$conf['nlp'].'.php';
					if(file_exists($yourself_file)){
						include_once $yourself_file;
					}else{
						include_once DISCUZ_ROOT . './source/plugin/onexin_keywords/nlp.auto.php';
					}						
					if(empty($words)) {
						$words = $keyword;
					}
					DB::query("UPDATE ".DB::table('plugin_onexin_keywords')." SET words = '$words' WHERE title='$keyword'");
				}	
			
			}
			
			if(empty($tagname) && is_numeric($keyword)) {
				// 未知的
				dheader("location: ".$conf['url']);				
			}
		}else{

			$seo = DB::fetch_first("SELECT * FROM ".DB::table('plugin_onexin_keywords')." WHERE title='$keyword'");		
			if(!empty($seo['status'])) {
				// 锁定的
				dheader("location: ".$conf['url']);				
			}	
			$tagid = $seo['id'];
						
			// 是否记录搜索关键词
			if(empty($tagid) && $conf['iskw']) {
				DB::query("INSERT INTO ".DB::table('plugin_onexin_keywords')." (title,dateline) VALUES ('$keyword','$_G[timestamp]')");
				$tagid = DB::insert_id();
			}
			
			$words = $seo['words'];
			// 搜索预分词，如果搜索结果大于目标数，则跳过分词
			if(empty($words)) {
				$count = getcount('plugin_onexin_keywords', "title like '%$keyword%'");
				if($count > $conf['max']){
					$words = $keyword;
				}
			}
			
			// 搜索空格分词
			$wordarr = explode(' ', trim($keyword));
			if(empty($words) && count($wordarr) > 1) $words = implode(' ', $wordarr);
						
			// 搜索分词
			if(empty($words) && $conf['iswords']) {
				// nlp words
				$yourself_file = DISCUZ_ROOT . './source/plugin/onexin_keywords/nlp.'.$conf['nlp'].'.php';
				if(file_exists($yourself_file)){
					include_once $yourself_file;
				}else{
					include_once DISCUZ_ROOT . './source/plugin/onexin_keywords/nlp.auto.php';
				}					
					if(empty($words)) {
						$words = $keyword;
					}
			}	
									
				if(!empty($words)) {
					$words = addslashes($words);
					DB::query("UPDATE ".DB::table('plugin_onexin_keywords')." SET words = '$words' WHERE id='$tagid'");
				}


		}
		//print_r($keyword);exit;
	
	// 初始化
	$page = intval($_GET['page']);
	$page = max(1, intval($page));
	$tpp = !empty($conf['tpp']) ? intval($conf['tpp']) : 20;
	//$tpp = 3;
	$start_limit = ($page - 1) * $tpp;
        
        // max
		if($page*$tpp > $conf['max']){
			// 超出最大页数
			dheader("location: ".$conf['url']);			
		}
	
		$query = array();
		$articlelist = $articleidarray = $tidarray = $blogidarray = array();
			
		$articlelist = onexin_keywords_getcache('search/all/'.$keyword);		
		$tagname = $keyword;
		$highlight = array();
		$highlight[] = $tagname;
	  	
		// 不同模块缓存时间
		foreach($articlelist['seo']['expire'] as $key => $val){
			if($_G['timestamp'] > $val) {
				unset($articlelist['count']);
				$articlelist['seo']['expire'][$key] = $_G['timestamp'] + $conf['expire']*60;
			}
		}
				//unset($articlelist['count']);
		
		// 判断是否满足访问静态文件条件：搜索有无结果、缓存是否过期	
		if(empty($articlelist['count']) || ($_G['timestamp'] > $articlelist['expire'])){
			//echo '<!--search-->';
			// 第一次搜索，还未缓存
			$query = DB::fetch_all("SELECT keywords,srchmod,ids FROM ".DB::table('common_searchindex')." WHERE keywords='$tagname'");
			foreach($query as $result) {
				if($result['srchmod'] == '2') {
                    $tidarray[] = $result['ids'];
                }elseif($result['srchmod'] == '3') {
                    $blogidarray[] = $result['ids'];
                }elseif($result['srchmod'] == '1') {
                    $articleidarray[] = $result['ids'];
                }
			}
			
			$tidarray = explode(',', implode(',', $tidarray));
			$blogidarray = explode(',', implode(',', $blogidarray));
			$articleidarray = explode(',', implode(',', $articleidarray));
			
            $list = array_merge((array)getthreadsbytids($tidarray), (array)getblogbyid($blogidarray));
            $articleidarray = array_merge((array)$list, (array)getarticlebyid($articleidarray));
            $articlelist = array_merge($articlelist, $articleidarray);
			
			// max
			unset($articlelist['seo']);	
			unset($articlelist['count']);
			unset($articlelist['expire']);
			
			// SEO
			$seo = DB::fetch_first("SELECT * FROM ".DB::table('plugin_onexin_keywords')." WHERE title='$tagname'");		
			
			// 模糊匹配，补充文章	
			if($conf['iswords']){
				// words 模糊匹配 （主词 and (副词 or 副词 or 副词 ... )）
				if(!empty($seo['words'])){
					//$seo['words'] = str_replace(',', ' ', $seo['words']);
					$seo_sqlarr = explode(' ', $seo['words']);
					foreach($seo_sqlarr as $val){
						if(empty($val) || $val == $tagname) continue;
						$highlight[] = $val;
					}
						$templist = onexin_keywords_getwords($seo['words'], $conf['max']);
						if(!empty($templist)) $articlelist = array_merge($articlelist, $templist);
					unset($articlelist['seo']);	
					unset($articlelist['count']);
					unset($articlelist['expire']);
				}
			}		
			
			// 关键词匹配，补充文章
			if(count($articlelist) < $conf['max'] && $conf['iskeywords']){
				// keywords 关键词匹配 (同义词 or 近义词 or ... )
				if(!empty($seo['keywords'])){
					$seo_keyarr = explode(',', $seo['keywords']);
					foreach($seo_keyarr as $val){
						if(empty($val) || $val == $tagname) continue;
						$highlight[] = $val;
						$templist = onexin_keywords_getcache('search/all/'.trim($val));
						if(!empty($templist)) $articlelist = array_merge($articlelist, $templist);
					}
					unset($articlelist['seo']);	
					unset($articlelist['count']);
					unset($articlelist['expire']);
				}
			}
			
		    krsort($articlelist);
			$articlelist = array_slice($articlelist, 0, $conf['max']);			
			$articlelist['count'] = count($articlelist);
			$articlelist['expire'] = $_G['timestamp'] + $conf['expire']*60;
			
			$articlelist['seo']['keywords'] = $seo['keywords'];
			$articlelist['seo']['description'] = $seo['description'];	
			$articlelist['seo']['words'] = $seo['words'];	
			$articlelist['seo']['relation'] = $seo['relation'];	
			
			foreach($articlelist as $key => $val){
				if(empty($val['tags'])) continue;
				$tagarray_all = explode("\t", $val['tags']);
				foreach($tagarray_all as $var) {
					if($var) {
						$tag = explode(',', $var);
						$articlelist['seo']['tags'][$tag[0]] = $tag;
					}
				}
			}	
			
			if($keyword) onexin_keywords_setcache('search/all/'.$keyword, $articlelist);
		}	
			
				// highlight
				if(!empty($articlelist['seo']['words'])){
					$seo_sqlarr = explode(' ', $articlelist['seo']['words']);
					foreach($seo_sqlarr as $val){
						if(empty($val) || $val == $tagname) continue;
						$highlight[] = $val;
					}
				}			
		
		// PAGE SEO
		$tagname = stripslashes(dhtmlspecialchars($keyword));
		$seo = $articlelist['seo'];
		$taglist = !empty($seo['tags']) ? array_slice($seo['tags'], 0, 30) : array();	
		$taglang = dhtmlspecialchars($conf['title']);//lang('core', 'search');	
		$metakeywords = !empty($seo['keywords']) ? dhtmlspecialchars($seo['keywords']).', '.$tagname : $tagname;
		$metadescription = !empty($seo['description']) ? dhtmlspecialchars($seo['description']) : $tagname;
		$seo_page = ' - ' . ($page > 1 ? lang('core', 'page', array('page' => $page)) . ' - ' : '') . $taglang . ' - ';
		$seo_page = str_replace(' - ', '_', $seo_page);
		$navtitle = $tagname ? $tagname . $seo_page : $taglang;
	  
			unset($articlelist['seo']);	
			unset($articlelist['count']);
			unset($articlelist['expire']);
			$count = count($articlelist);
		
			// update
			DB::query("UPDATE ".DB::table('plugin_onexin_keywords')." SET views = views + 1, num='$count', dateline='$_G[timestamp]' WHERE title='$keyword'");

			$articlelist = array_slice($articlelist, ($page - 1)*$tpp, $tpp);
			
			// description
			if(empty($seo['description'])){
				$temparr = reset($articlelist);
				$metadescription = $temparr['message'];
			}
			
			// highlight
			$summary_length = !empty($conf['summary_length']) ? $conf['summary_length'] : 300;
			foreach($articlelist as $key => $val){
				$val['message'] = cutstr($val['message'], $summary_length);
				if($conf['ishighlight']){
					$articlelist[$key]['subject'] = onexin_keywords_highlight($val['subject'], implode(',', $highlight));
					$articlelist[$key]['message'] = onexin_keywords_highlight($val['message'], implode(',', $highlight));
				}else{
					$articlelist[$key]['message'] = $val['message'];
				}
			}
			
		  	// url	
            $urltagname = urlencode(CHARSET != 'utf-8' ? diconv($urltagname, CHARSET, 'utf-8') : $urltagname);
			$theurl = $conf['isrewrite'] ? $conf['prefix'].$urltagname.$conf['suffix'] : "plugin.php?id=onexin_keywords&q=".$urltagname;
			//$multipage = multi($count, $tpp, $page, "plugin.php?id=onexin_keywords&q=".$urltagname);	
		  
	// /q/apple-2.html
		$_G['onexin.rewrite.page'] = '-{page}';
		include_once DISCUZ_ROOT.'./source/plugin/onexin_keywords/onexin_keywords.page.php';
	$thepage = $conf['isrewrite'] ? $conf['prefix'].$urltagname.'-{page}'.$conf['suffix'] : "plugin.php?id=onexin_keywords&q=".$urltagname;
	$multipage = onexin_keywords_page::multi($count, $tpp, $page, $thepage);
	
					
	// WEEK HOT
	$hotlist = DB::fetch_all("SELECT * FROM ".DB::table('plugin_onexin_keywords')." WHERE dateline>".($_G['timestamp'] - 7*24*3600)." ORDER BY views DESC LIMIT 0, 10");
	foreach($hotlist as $key => $val){
		$hotlist[$key]['title'] = dhtmlspecialchars($val['title']);
		$hotlist[$key]['key'] = $key + 1;
	}	
			
	// NEW HOT
	$newlist = DB::fetch_all("SELECT * FROM ".DB::table('plugin_onexin_keywords')." WHERE dateline>".($_G['timestamp'] - 7*24*3600)." ORDER BY dateline DESC LIMIT 0, 10");
	foreach($newlist as $key => $val){
		$newlist[$key]['title'] = dhtmlspecialchars($val['title']);
		$newlist[$key]['key'] = $key + 1;
	}
	//print_r($hotlist);
			
			$_G['setting']['output']['preg']['search']['keywords_61'] = "/\"plugin\.php\?id\=onexin_(keyword)s&(amp;)?(q)\=([^&\"\.]+)(&(amp;)?page\=(\d+))?\"/";
			$_G['setting']['output']['preg']['replace']['keywords_61'] = "_rewrite_callback_keywords(\"\$matches[1]\", \"\$matches[4]\", \"-\", \"\$matches[7]\")";


		// [theme]#onexin_keywords_list#
		$theme_name = !empty($conf['theme_name']) ? $conf['theme_name'] : 'onexin_keywords_listname';
			
	include_once template('onexin_keywords:'.$theme_name);
	exit;
			
}

//------------------------------------------------------------------------------------------

function onexin_keywords_highlight($message, $words, $color = '#ff0000') {
	if(!empty($words)) {
		$words = str_replace(',', ' ', $words);
		$highlightarray = explode(' ', $words);
		$sppos = strrpos($message, chr(0).chr(0).chr(0));
		if($sppos !== FALSE) {
			$specialextra = substr($message, $sppos + 3);
			$message = substr($message, 0, $sppos);
		}
		$message = str_replace('\"', '"', $message);
		foreach($highlightarray as $key => $replaceword) {
			$message = str_replace($replaceword, "<strong><font color=\"$color\">".$replaceword."</font></strong>", $message);
		}
		if($sppos !== FALSE) {
			$message = $message.chr(0).chr(0).chr(0).$specialextra;
		}
	}
	return $message;
}

function onexin_keywords_getwords($words = '', $limit = 200){
	$articleidarray = $tidarray = $blogidarray = array();
	
	// forum
	$title_wheresql = onexin_keywords_wheresql($words, 't.subject');
	$ctitle_wheresql = onexin_keywords_wheresql($words, 'c.subject');
	$content_wheresql = onexin_keywords_wheresql($words, 'c.message');
	$query = DB::query("SELECT * FROM ".DB::table('forum_thread')." t WHERE $title_wheresql ORDER BY t.tid DESC LIMIT $limit");
//	$query = DB::query("SELECT * FROM ".DB::table('forum_post')." c WHERE c.first='1' AND ($ctitle_wheresql OR $content_wheresql) ORDER BY c.tid DESC LIMIT $limit");
//	$query = DB::query("SELECT * FROM ".DB::table('forum_post')." c, ".DB::table('forum_thread')." t
//				WHERE c.tid=t.tid AND c.first='1' AND ($title_wheresql OR $content_wheresql) 
//				ORDER BY c.tid DESC LIMIT $limit");
	while($value = DB::fetch($query)) {
		$tidarray[$value['tid']] = $value['tid'];
	}
	//print_r($tidarray);

	// portal
	$title_wheresql = onexin_keywords_wheresql($words, 't.title');
	$content_wheresql = onexin_keywords_wheresql($words, 'c.content');
	$query = DB::query("SELECT * FROM ".DB::table('portal_article_title')." t WHERE $title_wheresql ORDER BY t.aid DESC LIMIT $limit");
//	$query = DB::query("SELECT * FROM ".DB::table('portal_article_content')." c WHERE c.pageorder='1' AND $content_wheresql ORDER BY t.aid DESC LIMIT $limit");
//	$query = DB::query("SELECT * FROM ".DB::table('portal_article_content')." c, ".DB::table('portal_article_title')." t
//				WHERE c.aid=t.aid AND c.pageorder='1' AND ($title_wheresql OR $content_wheresql) 
//				ORDER BY c.aid DESC LIMIT $limit");
	while($value = DB::fetch($query)) {
		$articleidarray[$value['aid']] = $value['aid'];
	}
	//print_r($articleidarray);
	
	$list = array_merge((array)getthreadsbytids($tidarray), (array)getblogbyid($blogidarray));
	$articleidarray = array_merge((array)$list, (array)getarticlebyid($articleidarray));
		
	return $articleidarray;
}

function onexin_keywords_wheresql($title = '', $key = 1, $or = 'OR'){
	$wheresql = "(";
	if(!empty($title)) {
		$s = explode(' ', $title);
		$n = count($s);	
		if($n > 1){
			$wheresql .= "$key LIKE '%$s[0]%' AND ";
			unset($s[0]);		
		}
		if($n == 2){
			$wheresql .= "$key LIKE '%$s[1]%'";
			unset($s[1]);		
		}
		if(!empty($s)) {
			if($n > 1) $wheresql .= "(";
			$ss = array();
			foreach($s as $v){
				if(!empty($v)) $ss[] = "$key LIKE '%$v%'";
			}
			$wheresql .= implode(" $or ", $ss);
			if($n > 1) $wheresql .= ")";
		}
	}else{
		$wheresql .= " 1=1 ";		
	}
	$wheresql .= ")";
	return $wheresql;	
}

function getthreadsbytids($tidarray) {
	global $_G;

	$threadlist = array();
	if(!empty($tidarray)) {
		loadcache('forums');
		include_once libfile('function_misc', 'function');
		require_once libfile('function/home');
		$post = $res = $classarr = array();
		$query = DB::fetch_all("SELECT * FROM ".DB::table('forum_threadimage')." WHERE tid IN (".dimplode($tidarray).")");
		foreach($query as $result){
			$images[$result['tid']] = ($result['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/'.$result['attachment'];
		}			
		$query = DB::fetch_all("SELECT tid,message,tags FROM ".DB::table('forum_post')." WHERE first='1' AND tid IN (".dimplode($tidarray).") ORDER BY dateline DESC");
		foreach($query as $result){
			$result['message'] = preg_replace("/\[video\].*?\[\/video\]/", '', $result['message']);
			$result['message'] = preg_replace("/\[attach\]\d+\[\/attach\]/", '', $result['message']);
			$result['message'] = preg_replace("/\[img.*?\].*?\[\/img\]/", "", trim($result['message']));
			$result['message'] = preg_replace("/\[hide\].*?\[\/hide\]/s", '', $result['message']);
			$result['message'] = preg_replace("/\[.*?\]/", "", $result['message']);
			
			$post[$result['tid']]['message'] = $result['message'];		
			$post[$result['tid']]['tags'] = $result['tags'];		
		}
		$query = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." WHERE displayorder>='0' AND tid IN (".dimplode($tidarray).") ORDER BY dateline DESC");
		foreach($query as $result) {						
			$res['blogid'] = $result['tid'];
			$res['type'] = 'thread';
			$res['username'] = $result['author'];
			$res['uid'] = $result['authorid'];
			$res['views'] = $result['views'];
			$res['subject'] = $result['subject'];
			$res['message'] = getstr($post[$result['tid']]['message'], 300, 0, 0, 0, -1);
			$res['tags'] = $post[$result['tid']]['tags'];
			$res['dateline'] = dgmdate($result['dateline']);
				if(@in_array('forum_viewthread', $_G['setting']['rewritestatus'])){
					$res['url'] = rewriteoutput('forum_viewthread', 1, '', $result['tid'], '', '');
					//$res['url'] = str_replace('_1.', '.', $res['url']);
				}else{
					$res['url'] = 'forum.php?mod=viewthread&tid='.$result['tid'];
				}

			$res['classname'] = $_G['cache']['forums'][$result['fid']]['name'];
			$res['classid'] = $result['fid'];
			$res['classurl'] = "forum.php?mod=forumdisplay&fid=$result[fid]";
			$res['pic'] = $images[$result['tid']] ? $images[$result['tid']] : "";
			$res['k'] = $result['dateline'].'_b_'.$result['tid'];
			//unset($result);
			$threadlist[$res['k']] = $res;//array_merge($res, procthread($result));;//
		}
	}
	return $threadlist;
}

function getblogbyid($blogidarray) {
	global $_G;

	$bloglist = array();
	if(!empty($blogidarray)) {
		$data_blog = C::t('home_blog')->fetch_all($blogidarray, 'dateline', 'DESC');
		$data_blogfield = C::t('home_blogfield')->fetch_all($blogidarray);

		require_once libfile('function/home');		
		$res = $classarr = array();
		foreach($data_blog as $curblogid => $result) {
			$result = array_merge($result, (array)$data_blogfield[$curblogid]);
			
			$res['blogid'] = $result['blogid'];
			$res['type'] = 'blog';
			$res['username'] = $result['username'];
			$res['uid'] = $result['uid'];
			$res['views'] = $result['viewnum'];
			$res['subject'] = $result['subject'];
			$res['message'] = $result['message'];
			$res['dateline'] = dgmdate($result['dateline']);
			$res['url'] = "home.php?mod=space&uid=$res[uid]&do=blog&id=$res[blogid]";
			
			$res['classname'] = $classarr[$result['classid']]['classname'];
			$res['classid'] = $result['classid'];
			$res['classurl'] = "home.php?mod=space&uid=$res[uid]&do=blog&classid=$res[classid]&view=me";
			
			if($result['friend'] == 4) {
				$result['message'] = $result['pic'] = '';
			} else {
				$result['message'] = getstr($result['message'], 300, 0, 0, 0, -1);
			}
			$res['message'] = preg_replace("/&[a-z]+\;/i", '', $result['message']);
			$res['pic'] = $result['pic'] ? pic_cover_get($result['pic'], $result['picflag']) : "";
			$res['k'] = $result['dateline'].'_c_'.$result['blogid'];			
			unset($result);
			$bloglist[$res['k']] = $res;
		}
	}
	return $bloglist;
}

function getarticlebyid($articleidarray) {
	global $_G;

	$articlelist = array();
	if(!empty($articleidarray)) {
		loadcache('portalcategory');
		$where = DB::field('aid', $articleidarray);
		$data_article = C::t('portal_article_title')->fetch_all_by_sql($where, ' ORDER BY dateline DESC');
		
		require_once libfile('function/home');
		$res = $classarr = $post = $viewarr = array();			
		if($_G['cache']['plugin']['onexin_tags']['isopen']){
			$query = DB::fetch_all("SELECT * FROM ".DB::table('plugin_onexin_tags')." WHERE idtype='articleid' AND itemid IN (".dimplode($articleidarray).")");
			foreach($query as $result){				
				$post[$result['itemid']]['tags'] = $result['tags'];		
			}
		}
			// views
			$query = DB::fetch_all("SELECT * FROM ".DB::table('portal_article_count')." WHERE aid IN (".dimplode($articleidarray).")");
			foreach($query as $result){				
				$viewarr[$result['aid']]['views'] = $result['viewnum'];		
			}
		foreach($data_article as $curarticleid => $result) {			
			$res['blogid'] = $result['aid'];
			$res['type'] = 'article';
			$res['username'] = $result['username'];
			$res['uid'] = $result['uid'];
			$res['views'] = $viewarr[$result['aid']]['views'];
			$res['subject'] = $result['title'];
			$res['message'] = $result['summary'];
			$res['tags'] = $post[$result['aid']]['tags'];
			$res['dateline'] = dgmdate($result['dateline']);
			$res['url'] = "portal.php?mod=view&aid=$res[blogid]";
			
			$res['classname'] = $_G['cache']['portalcategory'][$result['catid']]['catname'];
			$res['classid'] = $result['catid'];
			$res['classurl'] = $_G['cache']['portalcategory'][$result['catid']]['caturl'];
			
//			if($result['friend'] == 4) {
//				$result['message'] = $result['pic'] = '';
//			} else {
//				$result['message'] = getstr($result['message'], 300, 0, 0, 0, -1);
//			}
//			$res['message'] = preg_replace("/&[a-z]+\;/i", '', $result['message']);
			$res['pic'] = $result['pic'] ? pic_get($result['pic'], '', $result['thumb'], $result['remote'], 1, 1) : "";
			$res['k'] = $result['dateline'].'_a_'.$result['aid'];
			unset($result);
			$articlelist[$res['k']] = $res;
		}
	}
	return $articlelist;
}
