<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module	   onexin_occ
 * @date	   2019-12-19
 * 官方淘宝店铺：DisM.Taobao.Com
 * @copyright  Copyright (c) 2014 Onexin Platform Inc. (http://www.onexin.com)
 */
 
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

/*
ALTER TABLE  `pre_plugin_onexin_keywords` CHANGE  `description`  `description` VARCHAR( 255 ) NOT NULL;
ALTER TABLE  `pre_plugin_onexin_keywords` CHANGE  `var1`  `words` VARCHAR( 100 ) NOT NULL DEFAULT  '';
ALTER TABLE  `pre_plugin_onexin_keywords` CHANGE  `var2`  `relation` VARCHAR( 255 ) NOT NULL DEFAULT  '';
ALTER TABLE  `pre_plugin_onexin_keywords` CHANGE  `var3`  `num` VARCHAR( 100 ) NOT NULL DEFAULT  '';
*/

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_plugin_onexin_keywords` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL DEFAULT '',
  `keywords` varchar(200) NOT NULL DEFAULT '',
  `description` varchar(255) NOT NULL DEFAULT '',
  `views` int(8) unsigned NOT NULL DEFAULT '0',
  `dateline` int(10) unsigned NOT NULL DEFAULT '0',
  `words` varchar(100) NOT NULL DEFAULT '',
  `relation` varchar(255) NOT NULL DEFAULT '',
  `num` int(10) unsigned NOT NULL DEFAULT '0',
  `status` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM;

EOF;

runquery($sql);

$finish = TRUE;
