<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module    d'.'is'.'m.ta'.'obao.com
 * @date       2019-12-18
 * Discuz! x3.4 By DisM.taobao.COM
 * 最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------	
*/

function _rewrite_callback_keywords($matches1, $matches4 = '', $s = '', $matches6 = '') {
	global $_G;
	if(empty($s)){
		return "\"{$matches1}{$_G['cache']['plugin']['onexin_keywords']['suffix']}\"";	
	}else{	
		return "\"{$_G['cache']['plugin']['onexin_keywords']['prefix']}{$matches4}".($matches6 ? "{$s}{$matches6}" : "")."{$_G['cache']['plugin']['onexin_keywords']['suffix']}\"";
	}
}

function onexin_keywords_keycache($key){
	$arr = explode('/', $key);
	$arr[2] = md5($arr[2]);
	// 缓存文件按年、月分目录修改这里
	$key = $arr[0].'/'.$arr[1].'/'.$arr[2]{0}.$arr[2]{1}.'/'.trim($arr[2]);
    //$key = !empty($key) ? $key : date('d', strtotime('today')); 
	return $key;
}
	
function onexin_keywords_delcache($key = '', $dir = 'data/search_2b223f'){  
	global $_G;
	if(empty($key)) return array();
    if(!empty($_G['cache']['plugin']['onexin_keywords']['dir'])) {
		$dir = $_G['cache']['plugin']['onexin_keywords']['dir'];  
	}
    $file = DISCUZ_ROOT.'./'.$dir.'/'.onexin_keywords_keycache($key).'.php';
		
	if(file_exists($file)){
		unlink($file);
    }   
	
    return true;
}
	
function onexin_keywords_getcache($key = '', $dir = 'data/search_2b223f'){  
	global $_G;
	if(empty($key)) return array();
    if(!empty($_G['cache']['plugin']['onexin_keywords']['dir'])) {
		$dir = $_G['cache']['plugin']['onexin_keywords']['dir'];  
	}
    $file = DISCUZ_ROOT.'./'.$dir.'/'.onexin_keywords_keycache($key).'.php';
	
	$list = array();	
	if(file_exists($file)){
		$_OBD_SET = array();
		# m1
		include_once $file;
		
		# m2
		//$_OBD_SET = json_decode(file_get_contents($file), true);
		
		# m3
		//$_OBD_SET = explode('[-1-1-1-1-1-]', file_get_contents($file));
		//$_OBD_SET[0] = trim(strip_tags($_OBD_SET[0]));
        
		$list = $_OBD_SET[$key];
    }   
	
    return $list;
}

function onexin_keywords_setcache($key = '', $data = array(), $dir = 'data/search_2b223f', $expire = 300){
	global $_G;
	if(empty($data) || empty($key)) return;
    if(!empty($_G['cache']['plugin']['onexin_keywords']['dir'])) {
		$dir = $_G['cache']['plugin']['onexin_keywords']['dir'];  
	}
    $file = DISCUZ_ROOT.'./'.$dir.'/'.onexin_keywords_keycache($key).'.php';
	
	dmkdir(dirname($file), 0777, 0);
	
    $val = array();
    $val[$key] = $data;
	
	# m1
    //$val[$key]['expire'] = $_G['timestamp'];
	$code = "<?php\n\rif(!defined('IN_DISCUZ')) { exit('Access Denied'); }\n\r//". date('Y-m-d H:i:s')." Created\n\r\$_OBD_SET = ". var_export($val, true). ";?>";

	# m2
	//$code = "". json_encode($val). "";
	
	# m3
	//$code = "". trim($data['content']). "";
	
	file_put_contents($file, $code);    
}
