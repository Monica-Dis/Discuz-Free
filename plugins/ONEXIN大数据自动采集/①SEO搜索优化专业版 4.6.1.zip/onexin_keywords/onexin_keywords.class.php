<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module	   onexin_occ
 * @date	   2019-12-04
 * 官方淘宝店铺：DisM.Taobao.Com
 * 最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------

#srchmod
1 portal
2 forum
5 group
3 blog 
4 album

/search.php?mod=forum&searchid=1&orderby=lastpost&ascdesc=desc&searchsubmit=yes&kw=%D6%D0%B9%FA

/q/apple.html

/plugin.php?id=onexin_keywords&mod=forum&kw=%D6%D0%B9%FA

*/

include_once DISCUZ_ROOT.'./source/plugin/onexin_keywords/function_keywords.php';

class plugin_onexin_keywords {

	protected static $conf = array();
	protected static $isopen = FALSE;

	public function __construct() {
		global $_G;
		
		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		self::$isopen = $_G['cache']['plugin']['onexin_keywords']['isopen'] ? TRUE : FALSE;
		if(self::$isopen){
			self::$conf = $_G['cache']['plugin']['onexin_keywords'];
			self::$conf['usergroups'] = (array)unserialize(self::$conf['usergroups']);
			if(empty(self::$conf['usergroups'][0]) || in_array($_G['groupid'], self::$conf['usergroups'])){
				self::$conf['isgroupid'] = TRUE;
			}
			
			$_G['setting']['output']['preg']['search']['keywords_61'] = "/\"plugin\.php\?id\=onexin_(keyword)s&(amp;)?(q)\=([^&\"\.]+)(&(amp;)?page\=(\d+))?\"/";
			$_G['setting']['output']['preg']['replace']['keywords_61'] = "_rewrite_callback_keywords(\"\$matches[1]\", \"\$matches[4]\", \"-\", \"\$matches[7]\")";
		}
	}
	
	public function keywords(){
		global $_G;
		
		// 仅使用于search模块下，且必须有关键字及模块为portal,forum,blog
		if(!self::$isopen || CURSCRIPT != 'search' || empty($_GET['kw']) || empty($_GET['mod'])) return '';
				
				// 文章、贴子、日志
				if(!empty($_GET['mod']) && !in_array($_GET['mod'], array('portal', 'forum', 'blog'))) return '';
				
				// 贴子高级搜索
				if(preg_match("/adv=yes/", $_SERVER['HTTP_REFERER']) && !self::$conf['isadv']) return '';
				
				include_once DISCUZ_ROOT.'./source/plugin/onexin_keywords/onexin_keywords.inc.php';	
		
		return '';
	}	

}

// mod search 
class plugin_onexin_keywords_search extends plugin_onexin_keywords {

	public function forum_top() {
		global $_G;		
			
		self::keywords();				
			
		return '';
	}

	public function portal_top() {
		global $_G;		
			
		self::keywords();				
			
		return '';
	}

	public function blog_top() {
		global $_G;		
			
		self::keywords();				
			
		return '';
	}

}

// Mobile 
class mobileplugin_onexin_keywords_search extends plugin_onexin_keywords_search {

	/*有待优化*/

}
