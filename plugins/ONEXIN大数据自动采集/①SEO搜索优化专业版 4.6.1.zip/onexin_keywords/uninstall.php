<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module    d'.'is'.'m.ta'.'obao.com
 * @date       2019-12-02
 * Discuz! x3.4 By DisM.taobao.COM
 * 最新插件：http://t.cn/Aiux1Jx1
 */
 
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

// 删除缓存文件，cloudaddons_cleardir函数由系统source/function/function_plugin.php引入
cloudaddons_cleardir($_G['cache']['plugin']['onexin_keywords']['dir']);

$sql = <<<EOF
DROP TABLE pre_plugin_onexin_keywords;
EOF;

runquery($sql);

$finish = true;

