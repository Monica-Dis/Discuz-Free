<?php
/**
 * ONEXIN TAGS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_tags
 * @module	   tag
 * @date	   2020-11-08
 * 官方淘宝店铺：DisM.Taobao.Com
 * [DisM!] (C)2019-2021 DISM.Taobao.COM.
 */

//---------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

开通NLP自然语言处理
https://common-buy.aliyun.com/?commodityCode=nlp#/open

打开下面网址，创建应用并获取key
https://usercenter.console.aliyun.com/#/manage/ak

*/

function _onexin_autotag_relatekw(){
	$_GET['subjectenc'] = strip_tags(str_replace(array('&nbsp;', '&', '#', '*', "\r", "\n"), array(), $_GET['subjectenc']));
	$_GET['messageenc'] = str_replace(array('&nbsp;', '&', '#', '*', "\r", "\n"), array(), $_GET['messageenc']);
	$_GET['messageenc'] = preg_replace("/<ignore_js_op>.*?<\/ignore_js_op>/is", '', $_GET['messageenc']);
	$_GET['messageenc'] = strip_tags(preg_replace("/\[.+?\]/U", '', $_GET['messageenc']));
				
$title = trim(strip_tags($_GET['subjectenc']));
$content = trim(strip_tags(preg_replace("/\[.+?\]/U", '', $_GET['messageenc'])));
	
	if(CHARSET != 'utf-8'){
		$title = diconv(trim($title), CHARSET, 'utf-8');
		$content = diconv(trim($content), CHARSET, 'utf-8');
	}
	
	$keyword = $title.' '.$content;
	
	// aliyun
	$ak_id = "G8lGyvu1vxxxxxxxxx";#你的 Api Key
	$ak_secret  = "8A4M68s4Cxxxxxxxxxxxxxxxx";#你的 Secret Key

	global $_G;	
	if(!empty($_G['cache']['plugin']['onexin_autotag']['filter'])) {
		// [引擎名]#api key#secret key#
		$arr = explode("[aliyun]", $_G['cache']['plugin']['onexin_autotag']['filter']);
		foreach($arr as $key => $val) {
			$data = explode('#', trim($val));
			if(!empty($data[2])) {
				$ak_id = $data[1];
				$ak_secret = $data[2];
			}
		}
	}

//-----------------------------------------------
	
	// 获取标签
	$url = 'http://nlp.cn-shanghai.aliyuncs.com/nlp/api/textstructure/news';
	$post_data = json_encode(array(
		//"lang"=>"ZH", 
		"tag_flag"=>"true", 
		"text"=>$keyword
	));	
	
			$version = "1.0";
			$user_agent = 'AlibabaCloud (WINNT 10.0; i586) Client/1.5.19 PHP/5.6.27';
			$method = "POST";
            $accept = "application/json";
            $content_type = "application/json;chrset=utf-8";
            $path = "/nlp/api/textstructure/news";
			$date = gmdate('D, d M Y H:i:s \G\M\T');//toGMTString(new Date());
            $host = "nlp.cn-shanghai.aliyuncs.com";
            $region = "cn-shanghai";
			// 1.对body做MD5+BASE64加密
            $bodyMd5 = "";//base64_encode(md5($post_data));
            $uuid = md5(uniqid(rand(), TRUE));
			$stringToSign = $method . "\n" . $accept . "\n" . $bodyMd5 . "\n" . $content_type . "\n" . $date . "\n" 
                    . "x-acs-region-id:" . $region . "\n"                                                  
                    . "x-acs-signature-method:HMAC-SHA1\n"
                    . "x-acs-signature-nonce:" . $uuid . "\n"                                  
                    . "x-acs-signature-version:" . $version . "\n"                           
                    . "x-acs-version:2018-04-08\n"
                    . $path;
			// 2.计算 HMAC-SHA1
			$signature = base64_encode(hash_hmac('sha1', $stringToSign, $ak_secret, true));
            // 3.得到 authorization header
            $authHeader = "acs " . $ak_id . ":" . $signature;    
			
			// 设置通用的请求属性
			$headers =  array();
			$headers[] =  'User-Agent: '.$user_agent;
			$headers[] =  'x-acs-version: 2018-04-08'; 
			$headers[] =  'x-acs-region-id: cn-shanghai'; 
			$headers[] =  'Date: '.$date;
			$headers[] =  'x-acs-signature-method: HMAC-SHA1';
			$headers[] =  'x-acs-signature-nonce: '.$uuid;
			$headers[] =  'x-acs-signature-version: '.$version;
			$headers[] =  'Accept: '.$accept;
			$headers[] =  'Content-Type: '.$content_type;
			$headers[] =  'Authorization: '.$authHeader;
			//$headers[] =  'Content-MD5: '.$bodyMd5;
				
	
	$contents = onexin_aliyun_nlp_request($url, $post_data, $headers);
	
	
	$wordrank = array();	
	$arr = explode(';', $contents['data']['tags']);
	foreach($arr as $key => $val){
		$v = explode(':', $val);
		// 过滤单个汉字
		if(strlen($v[0]) > 3) $wordrank[] = $v[0];
	}
	
	$contents = implode(',', array_slice(array_unique($wordrank), 0, 10));

//-----------------------------------------------
		
	if(CHARSET != 'utf-8'){
		$contents = diconv(trim($contents), 'utf-8', CHARSET);
	}
	
	$return = str_replace(" ", ",", $contents);
	
	return dhtmlspecialchars($return);	
}


function onexin_aliyun_nlp_request($url = '', $post_data = '', $headers = array()) {
	if (empty($url) || empty($post_data)) {
		return false;
	}

	$ch= curl_init($url);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	//curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
	//curl_setopt($ch, CURLOPT_REFERER, $url);
	//curl_setopt($ch, CURLOPT_COOKIESESSION, true);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);	
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
//    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
//    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2); // 从证书中检查SSL加密算法是否存在
	if(!empty($post_data)) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	}
	curl_setopt($ch, CURLOPT_TIMEOUT, 3);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
	$contents = curl_exec($ch);   
	curl_close($ch);		
	$contents = json_decode($contents, true);	
	
	return $contents;
}


	function _onexin_autotag_forum($tags, $itemid, $idtype = 'tid', $returnarray = 0, $tagcountmax = 5) {
		// || !in_array($idtype, array('', 'tid', 'blogid', 'uid')
		if($tags == '') return;

		$langcore = lang('core');
		$tags = str_replace(array(chr(0xa3).chr(0xac), chr(0xa1).chr(0x41), chr(0xef).chr(0xbc).chr(0x8c),
				$langcore['fullblankspace'], ','), ' ', censor(trim($tags)));
		$tagarray = array_unique(explode(' ', $tags));

						
		// 数据库找出旧TAG 如果新TAG中不包括 则删除关系
		$tagarrayold = $tagidarray = array();
		$results = C::t('common_tagitem')->select(0, $itemid, $idtype);
		foreach($results as $result) {
			$tagidarray[] = $result['tagid'];
		}
		
		if($tagidarray) {
			$results = C::t('common_tag')->get_byids($tagidarray);
			foreach($results as $result) {
				if(!in_array($result['tagname'], $tagarray)) {
					$tagarrayold[$result['tagid']] = $result['tagid'];
				}
			}			
			C::t('common_tagitem')->delete($tagarrayold, $itemid, $idtype);
		}		
		
		$tagcount = 1;
		foreach($tagarray as $tagname) {
			$tagname = trim($tagname);
			if(preg_match('/^([\x7f-\xff_-]|\w|\s){3,20}$/', $tagname) && $tagcountmax) {
				$status = $idtype != 'uid' ? 0 : 3;
				$result = C::t('common_tag')->get_bytagname($tagname, $idtype);
				if($result['tagid']) {
					if($result['status'] == $status) {
						$tagid = $result['tagid'];
					}
				} else {
					$tagid = C::t('common_tag')->insert($tagname,$status);
				}
				if($tagid) {
					if($itemid) {
						C::t('common_tagitem')->replace($tagid,$itemid,$idtype);
					}
					$tagcount++;
					if(!$returnarray) {
						$return .= $tagid.','.$tagname."\t";
					} else {
						$return[$tagid] = $tagname;
					}

				}
				if($tagcount > $tagcountmax) {
					unset($tagarray);
					break;
				}
			}
		}
		
		return $return;
	}

