<?php
 /**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * 如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 * Time: 2021-01-02
 */

//---------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
tag
*/

	function _onexin_autotag_forum($tags, $itemid, $idtype = 'tid', $returnarray = 0, $tagcountmax = 5) {
		// || !in_array($idtype, array('', 'tid', 'blogid', 'uid')
		if($tags == '') return;

		$langcore = lang('core');
		$tags = str_replace(array(chr(0xa3).chr(0xac), chr(0xa1).chr(0x41), chr(0xef).chr(0xbc).chr(0x8c),
				$langcore['fullblankspace'], ','), ' ', censor(trim($tags)));
		$tagarray = array_unique(explode(' ', $tags));

						
		// 数据库找出旧TAG 如果新TAG中不包括 则删除关系
		$tagarrayold = $tagidarray = array();
		$results = C::t('common_tagitem')->select(0, $itemid, $idtype);
		foreach($results as $result) {
			$tagidarray[] = $result['tagid'];
		}
		
		if($tagidarray) {
			$results = C::t('common_tag')->get_byids($tagidarray);
			foreach($results as $result) {
				if(!in_array($result['tagname'], $tagarray)) {
					$tagarrayold[$result['tagid']] = $result['tagid'];
				}
			}			
			C::t('common_tagitem')->delete($tagarrayold, $itemid, $idtype);
		}		
		
		$tagcount = 1;
		foreach($tagarray as $tagname) {
			$tagname = trim($tagname);
			if(preg_match('/^([\x7f-\xff_-]|\w|\s){3,20}$/', $tagname) && $tagcountmax) {
				$status = $idtype != 'uid' ? 0 : 3;
				$result = C::t('common_tag')->get_bytagname($tagname, $idtype);
				if($result['tagid']) {
					if($result['status'] == $status) {
						$tagid = $result['tagid'];
					}
				} else {
					$tagid = C::t('common_tag')->insert($tagname,$status);
				}
				if($tagid) {
					if($itemid) {
						C::t('common_tagitem')->replace($tagid,$itemid,$idtype);
					}
					$tagcount++;
					if(!$returnarray) {
						$return .= $tagid.','.$tagname."\t";
					} else {
						$return[$tagid] = $tagname;
					}

				}
				if($tagcount > $tagcountmax) {
					unset($tagarray);
					break;
				}
			}
		}
		
		return $return;
	}


function _onexin_autotag_relatekw(){
	$_GET['subjectenc'] = strip_tags(str_replace(array('&nbsp;', '&', '#', '*', "\r", "\n"), array(), $_GET['subjectenc']));
	$_GET['messageenc'] = str_replace(array('&nbsp;', '&', '#', '*', "\r", "\n"), array(), $_GET['messageenc']);
	$_GET['messageenc'] = preg_replace("/<ignore_js_op>.*?<\/ignore_js_op>/is", '', $_GET['messageenc']);
	$_GET['messageenc'] = strip_tags(preg_replace("/\[.+?\]/U", '', $_GET['messageenc']));
				
$subjectenc = trim(strip_tags($_GET['subjectenc']));
$messageenc = trim(strip_tags(preg_replace("/\[.+?\]/U", '', $_GET['messageenc'])));

	$keyword = cutstr($subjectenc.$messageenc, 860);

//-----------------------------------------------
	
	if(CHARSET != 'utf-8'){
		$keyword = diconv(trim($keyword), CHARSET, 'utf-8');
	}

	$url = 'http://zhannei.baidu.com/api/customsearch/keywords?title='.urlencode($keyword);	
	$contents = dfsockopen($url);   	
	$contents = json_decode($contents, true);	
	
	$wordpos = $wordrank = array();
	foreach($contents['result']['res']['wordpos'] as $key => $val){
		$v = explode(':', $val);
		$wordpos[$v[0]] = $v[1];		
	}
	
	foreach($contents['result']['res']['wordrank'] as $key => $val){
			$v = explode(':', $val);
		if(!empty($wordpos[$v[0]]) && in_array($wordpos[$v[0]], array('n', 'ns', 'a')) ){
			$wordrank[$v[1].$v[2].rand(10, 99)] = $v[0];		
		}
	}
	krsort($wordrank);
	
	$contents = implode(',', array_slice(array_unique($wordrank), 0, 10));
		
	if(CHARSET != 'utf-8'){
		$contents = diconv(trim($contents), 'utf-8', CHARSET);
	}

//-----------------------------------------------
	
	$return = str_replace(" ", ",", $contents);
	
	return dhtmlspecialchars($return);	
}
