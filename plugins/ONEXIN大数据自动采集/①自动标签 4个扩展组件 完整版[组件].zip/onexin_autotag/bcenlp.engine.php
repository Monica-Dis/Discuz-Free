<?php
/**
 * ONEXIN TAGS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_tags
 * @module	   tag
 * @date	   2020-11-22
 * 官方淘宝店铺：DisM.Taobao.Com
 * [DisM!] (C)2019-2021 DISM.Taobao.COM.
 */

//---------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

打开下面网址，创建应用并获取key
https://console.bce.baidu.com/ai/#/ai/nlp/overview/index

开发文档：
https://cloud.baidu.com/doc/NLP/s/ljwvylk5z/#文章标签

*/

function _onexin_autotag_relatekw(){
	$_GET['subjectenc'] = strip_tags(str_replace(array('&nbsp;', '&', '#', '*', "\r", "\n"), array(), $_GET['subjectenc']));
	$_GET['messageenc'] = str_replace(array('&nbsp;', '&', '#', '*', "\r", "\n"), array(), $_GET['messageenc']);
	$_GET['messageenc'] = preg_replace("/<ignore_js_op>.*?<\/ignore_js_op>/is", '', $_GET['messageenc']);
	$_GET['messageenc'] = strip_tags(preg_replace("/\[.+?\]/U", '', $_GET['messageenc']));
				
$title = trim(strip_tags($_GET['subjectenc']));
$content = trim(strip_tags(preg_replace("/\[.+?\]/U", '', $_GET['messageenc'])));
	
	if(CHARSET != 'utf-8'){
		$title = diconv(trim($title), CHARSET, 'utf-8');
		$content = diconv(trim($content), CHARSET, 'utf-8');
	}
	
	// bcenlp
	$app_key = "G8lGyvu1vxxxxxxxxx";#你的 Api Key
	$secret  = "8A4M68s4Cxxxxxxxxxxxxxxxx";#你的 Secret Key

	global $_G;	
	if(!empty($_G['cache']['plugin']['onexin_autotag']['filter'])) {
		// [引擎名]#api key#secret key#
		$arr = explode("[bcenlp]", $_G['cache']['plugin']['onexin_autotag']['filter']);
		foreach($arr as $key => $val) {
			$data = explode('#', trim($val));
			if(!empty($data[2])) {
				$app_key = $data[1];
				$secret = $data[2];
			}
		}
	}

//-----------------------------------------------
	
	// 获取token
	$url = 'https://aip.baidubce.com/oauth/2.0/token';
    $post_data = array();
	$post_data['grant_type']      = 'client_credentials';
    $post_data['client_id']       = $app_key;
    $post_data['client_secret']   = $secret;
    $o = "";
    foreach ( $post_data as $k => $v ) {
    	$o.= "$k=" . urlencode( $v ). "&" ;
    }
    $post_data = substr($o,0,-1);	
    $res = onexin_baidubce_request($url, $post_data);	
	
	$access_token = $res['access_token'];
	
	// 获取标签
	$url = 'https://aip.baidubce.com/rpc/2.0/nlp/v1/keyword?charset=UTF-8&access_token='.$access_token;	
	$post_data = json_encode(array(
		"title"=>cutstr($title, 80, ''), 
		"content"=>cutstr($content, 65500, ''))
	);	
	$contents = onexin_baidubce_request($url, $post_data);
	
	$wordrank = array();	
	foreach($contents['items'] as $key => $val){
			$wordrank[] = $val['tag'];
	}
	
	$contents = implode(',', array_slice(array_unique($wordrank), 0, 10));

	$contents = trim(strip_tags($contents), ',');
		
	if(CHARSET != 'utf-8'){
		$contents = diconv(trim($contents), 'utf-8', CHARSET);
	}

//-----------------------------------------------
	
	$return = str_replace(" ", ",", $contents);
	
	return dhtmlspecialchars($return);	
}


function onexin_baidubce_request($url = '', $post_data = '') {
	if (empty($url) || empty($post_data)) {
		return false;
	}
	
	$user_agent = 'Mozilla/5.0 (Windows NT 6.2; rv:16.0) Gecko/20100101 Firefox/16.0';

	$ch= curl_init($url);
	curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
	curl_setopt($ch, CURLOPT_REFERER, $url);
	curl_setopt($ch, CURLOPT_COOKIESESSION, true);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);	
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0); // 对认证证书来源的检查
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2); // 从证书中检查SSL加密算法是否存在
	if(!empty($post_data)) {
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
	}
	curl_setopt($ch, CURLOPT_TIMEOUT, 3);
	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 3);
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
	$contents = curl_exec($ch);   
	curl_close($ch);		
	$contents = json_decode($contents, true);	
	
	return $contents;
}


	function _onexin_autotag_forum($tags, $itemid, $idtype = 'tid', $returnarray = 0, $tagcountmax = 5) {
		// || !in_array($idtype, array('', 'tid', 'blogid', 'uid')
		if($tags == '') return;

		$langcore = lang('core');
		$tags = str_replace(array(chr(0xa3).chr(0xac), chr(0xa1).chr(0x41), chr(0xef).chr(0xbc).chr(0x8c),
				$langcore['fullblankspace'], ','), ' ', censor(trim($tags)));
		$tagarray = array_unique(explode(' ', $tags));

						
		// 数据库找出旧TAG 如果新TAG中不包括 则删除关系
		$tagarrayold = $tagidarray = array();
		$results = C::t('common_tagitem')->select(0, $itemid, $idtype);
		foreach($results as $result) {
			$tagidarray[] = $result['tagid'];
		}
		
		if($tagidarray) {
			$results = C::t('common_tag')->get_byids($tagidarray);
			foreach($results as $result) {
				if(!in_array($result['tagname'], $tagarray)) {
					$tagarrayold[$result['tagid']] = $result['tagid'];
				}
			}			
			C::t('common_tagitem')->delete($tagarrayold, $itemid, $idtype);
		}		
		
		$tagcount = 1;
		foreach($tagarray as $tagname) {
			$tagname = trim($tagname);
			if(preg_match('/^([\x7f-\xff_-]|\w|\s){3,20}$/', $tagname) && $tagcountmax) {
				$status = $idtype != 'uid' ? 0 : 3;
				$result = C::t('common_tag')->get_bytagname($tagname, $idtype);
				if($result['tagid']) {
					if($result['status'] == $status) {
						$tagid = $result['tagid'];
					}
				} else {
					$tagid = C::t('common_tag')->insert($tagname,$status);
				}
				if($tagid) {
					if($itemid) {
						C::t('common_tagitem')->replace($tagid,$itemid,$idtype);
					}
					$tagcount++;
					if(!$returnarray) {
						$return .= $tagid.','.$tagname."\t";
					} else {
						$return[$tagid] = $tagname;
					}

				}
				if($tagcount > $tagcountmax) {
					unset($tagarray);
					break;
				}
			}
		}
		
		return $return;
	}

