<?php
/**
 * ONEXIN KEYWORDS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_keywords
 * @module	  di'.'sm.t'.'aoba'.'o.com
 * @date	   2019-12-06
 * 官方淘宝店铺：DisM.Taobao.Com
 * 最新插件：http://t.cn/Aiux1Jx1
 */

//---------------------------------------------------------------

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

自建标签引擎
https://dism.taobao.com/?@onexin_tfidf.plugin

*/
	// tfidf words
	$yourself_file = DISCUZ_ROOT . './source/plugin/onexin_tfidf/function_tfidf.php';
	if(file_exists($yourself_file)){
		include_once $yourself_file;
		$words = _onexin_tfidf_tags($keyword, 5);
		$words = str_replace(', ', ' ', $words);
	}
				