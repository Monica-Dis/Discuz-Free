<?php
/**
 * ONEXIN BAIDU XZH For Discuz!X 3.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_baiduxzh
 * @date	   2018-07-20
 * @author	   King
 * [DisM!] (C)2019-2020 DISM.Taobao.COM.
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
	
/*

//--------------Tall us what you think!----------------------------------

添加canonical标签，要求href的内容为MIP页或H5页对应的PC页地址；如果没有PC页，则填写当前页面地址。
    <link rel="canonical" href="http(s)://xxx"/>
                
添加JSON_LD数据，下方代码为JSON-LD示例：
<script type="application/ld+json">
{
    "@context": "https://ziyuan.baidu.com/contexts/cambrian.jsonld",
    "@id": "https://ziyuan.baidu.com/college/articleinfo?id=1464",
    "appid": "1582855495060472",
    "title": "百度移动搜索落地页体验白皮书——广告篇2.0",
    "images": [
        "https://ss0.bdstatic.com/5aV1bjqh_Q23odCf/static/superman/img/logo/bd_logo1_31bdc765.png",
        "https://ss0.bdstatic.com/5aV1bjqh_Q23odCf/static/superman/img/logo_top_ca79a146.png",
        "https://m.baidu.com/static/index/plus/plus_logo.png"
        ],
    "description": "优质合理的广告作为信息的补充，广受用户喜欢。2017年初百度用户体验部针对用户进行了满意度调研，发现很多恶意低质的广告严重破坏着用户的搜索体验。",
    "pubDate": "2017-06-15T08:00:01",
    "upDate": "2017-06-15T08:00:01",
    "lrDate": "2017-06-15T08:00:01"
}
</script>
                
@context：	必选字段，	请保留 “https://ziyuan.baidu.com/contexts/cambrian.jsonld”，若需要校验数据的schema，则可替换为schema地址
@id：	必选字段，	当前网页的url
appid：	必选字段，	熊掌号ID
title：	必选字段，	标题，建议长度：20个字符以内
images：	可选字段，	搜索结果结构化信息展示，仅允许提供0张，1张图或3张图
description：	可选字段，	内容摘要：120个字符以内
pubDate：	必选字段，	内容发布时间
	
// 百度搜索落地页时间因子规范	
https://ziyuan.baidu.com/college/articleinfo?id=2210

# 论坛详情页面
提供帖子发布时间（pubdate）
第一个用户可看到的回帖时间（update）
最新回帖时间（lrDate）

#文章详情页
优先提供内容的发布时间（pubdate）
如果内容有更新，需补充内容更新时间（update）

*/

include_once DISCUZ_ROOT . './source/plugin/onexin_baiduxzh/function_baiduxzh.php';

class mobileplugin_onexin_baiduxzh {

	var $conf = array();
	var $isopen = FALSE;

	function mobileplugin_onexin_baiduxzh() {
		global $_G;		
		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');/*dism-Taobao-com*/
		}
		$this->isopen = $_G['cache']['plugin']['onexin_baiduxzh']['isopen'] ? TRUE : FALSE;
		if($this->isopen) {
			$this->conf = $_G['cache']['plugin']['onexin_baiduxzh'];
			$this->conf['usebtns'] = (array)unserialize($this->conf['usebtns']);
			$this->conf['usefids'] = (array)unserialize($this->conf['usefids']);
			$this->conf['usefans'] = (array)unserialize($this->conf['usefans']);
			$this->conf['usergroups'] = (array)unserialize($this->conf['usergroups']);
            	
			$this->conf['isgroupid'] = FALSE;
            if(empty($this->conf['usergroups'][0]) || in_array($_G['groupid'], $this->conf['usergroups'])){
				$this->conf['isgroupid'] = TRUE;
			}
            
            // batch groups
            $this->conf['batchgroups'] = (array)unserialize($this->conf['batchgroups']);
            $this->conf['ismanage'] = FALSE;
            if(empty($this->conf['batchgroups'][0]) || in_array($_G['groupid'], $this->conf['batchgroups'])){
                $this->conf['ismanage'] = TRUE;
            }
        
            // fids
			$this->conf['isfid'] = FALSE;
            if(empty($this->conf['usefids'][0]) || in_array($_G['forum_thread']['fid'], $this->conf['usefids'])){
                $this->conf['isfid'] = TRUE;
            }
            
            // CURMODULE == 'viewthread'
            if(CURSCRIPT == 'group') {
                $this->conf['isfid'] = TRUE;
            }
            
		}
	}
    
	function global_header_mobile(){
		global $_G;
		if(!$this->isopen) return '';
		$fans = '';
		if(in_array('1', $this->conf['usefans'])){
			$fans = '<div class="p16"><script>cambrian.render(\'head\')</script></div>';
		}
		return $fans.$this->conf['onexin_baiduxzh_style_mobile'];
	}
    
	function global_footer_mobile(){
		global $_G;
		if(!$this->isopen) return '';
		$fans = '';
		if(in_array('3', $this->conf['usefans'])){
			$fans = '<div class="p16"><script>cambrian.render(\'tail\')</script></div>';
		}
		include template('onexin_baiduxzh:global_footer');
        return $fans.$return;
	}
	
	// head
	function head($data){
		global $_G;
        
		if(!$this->isopen) return '';
		$search = $replace = array();     
        $search[] = "/<img[^>]* file=\"/";
        $replace[] = '<img src="';      
        $search[] = "/\<img [^>]*src=\"[^\"]*(image\/smiley|images\/bgimg|static\/image)[^>]*\>/";
        $replace[] = '';       
        $search[] = '/<img [^>]*="forum.php/';
        $replace[] = '<img src="'. $_G['siteurl'] .'forum.php';        
        $search[] = '/src="(\.\/)?data\/attachment\//';
        $replace[] = 'src="'. $_G['siteurl'] .'data/attachment/';        
        $message = preg_replace($search, $replace, $data['content']);
        
		preg_match_all("/\<img\s+[^>]*src=[\'\"]([^'\"]+)[\'\"\s\>]+/i", $message, $mathes);
		$pics = array_unique($mathes[1]);
        $num = 3;
		$image_list = array();
		$image_list = ( count($pics) > $num ) ? array_slice($pics, 0, $num) : $pics;        
        if(count($pics) == 2) $image_list = array_slice($pics, 0, 1);        
        $images = array();
		foreach($image_list as $val){
            $images[] = "\r\n        \"$val\"";
		}
        $images = implode(',', $images);
        
		$langcore = lang('core');;
        $data['description'] = str_replace(array($langcore['fullblankspace'], '&nbsp;', ' ','　', "\t", "\r", "\n", '\'', '"'), '', strip_tags($data['description']));
               
$code = '<script type="application/ld+json">
{
    "@context": "https://ziyuan.baidu.com/contexts/cambrian.jsonld",
    "@id": "'.$data['url'].'",
    "appid": "'.$this->conf['appid'].'",
    "title": "'.dhtmlspecialchars(cutstr($data['title'], $this->conf['tit_length'])).'",
    "images": ['.$images.'],
    "description": "'.dhtmlspecialchars(!empty($data['description']) ? $data['description'] : $data['title']).'",
    "pubDate": "'.dgmdate($data['dateline'], 'Y-m-d\TH:i:s').'"'.(!empty($data['update']) ? ',
    "upDate": "'.dgmdate($data['update'], 'Y-m-d\TH:i:s').'"' : '').(!empty($data['lrdate']) ? ',
    "lrDate": "'.dgmdate($data['lrdate'], 'Y-m-d\TH:i:s').'"' : '').'
}
</script>
<script src="//msite.baidu.com/sdk/c.js?appid='.$this->conf['appid'].'"></script>
';
        
        $_G['setting']['seohead'] = preg_replace("/<link[^>]*rel=\"canonical\"[^>]*>/i", "", $_G['setting']['seohead']);                
        $_G['setting']['seohead'] = "<link rel=\"canonical\" href=\"".$data['url']."\" />\n" . $code . $_G['setting']['seohead'];

	}
	
	// show link
	function link($data){
		global $_G;
        
        // 禁止空短文章提交
        if(strlen($data['description']) < $this->conf['msg_limit']) return;        
        
        $latest = TIMESTAMP - intval($this->conf['latest']) * 8 *3600;
        if($data['dateline'] < $latest){
            return;
        }
        
		$autopush = $this->conf['autopush'];
        $response = '&#29066;&#25484;&#21495;&#25991;&#31456;&#65292;';//熊掌号文章，
        $txt = $this->conf['viewclick'];
        $url = $data['url'];
        // check today 
            $todaylist = _baiduxzh_getcache();
            if(count($todaylist) > $this->conf['daylimit']) {
                return '';
            }
        // check yestoday
    		$yestoday = date('Ymd', strtotime('1 day ago'));  
            $yestodaylist = _baiduxzh_getcache($yestoday);
			$todaylist = array_merge((array)$yestodaylist, (array)$todaylist);   
        $k = md5($url);
        if($todaylist[$k]['code'] == 200) {
            //$url = "";
            $autopush = $todaylist[$k]['mode'];
        }
        $txt_batch = $this->conf['ismanage'] && !empty($this->conf['batchclick']) ? "<a href=\"plugin.php?id=onexin_baiduxzh\"><span class=\"onexin_baiduxzh_batchtxt\">{$this->conf['batchclick']}</script></span></a>" : "";  
		
		$sdata = explode("\n", $this->conf['confkey']);
		
		$select = "<select id=\"fromxzh\" name=\"fromxzh\" class=\"onexin_baiduxzh_fromxzh\" data-url=\"{$url}\">";
		$selectarr = array();
		foreach($sdata as $key => $val) {
            // key#name
            $data = explode('#', trim($val));
            if(preg_match("/type=mip/", $data[0])){
				$iurl = str_replace($_G['siteurl'], $_G['siteurl'].'mip/', $url);
			}else{
				$iurl = $url;
			}
			$k = md5($iurl.($data[0] ? $data[0] : ""));
            if($data[1] && $todaylist[$k]['code'] != 200) {
				$selectarr[] = "<option value=\"".$key."\" ".($key==0 ? "selected" : "").">".$data[1]."</option>";				
			}
		}
		$select .= implode("", $selectarr);
		$select .= "</select>";	
		if(count($selectarr)==0) {
			$select = "";
			$txt = '&#25552;&#20132;&#25104;&#21151;';//提交成功			
		}
		
		return 	"<div id=\"onexin_baiduxzh\" data-autopush=\"{$autopush}\" data-url=\"{$url}\">".$select."<a id=\"onexin_baiduxzh_push\" href=\"javascript:;\"><span class=\"onexin_baiduxzh_btntxt ".($autopush != "0" ? "onexin_baiduxzh_ok" : "")."\">{$txt}</span></a> {$txt_batch}</div>";
	}
			
}

// forum
class mobileplugin_onexin_baiduxzh_forum extends mobileplugin_onexin_baiduxzh {
	
	function viewthread_onexin_baiduxzh_output(){
		global $_G, $postlist, $thread;
		
		if(!$this->isopen) return '';
		$title = strip_tags($_G['forum_thread']['subject']);
        $msg = $postlist[$_G['forum_firstpid']]['message'];
		$dateline = $postlist[$_G['forum_firstpid']]['dbdateline'];
		$tid = $_G['tid'];
        		
		// SUMMARY
		$desc = preg_replace("/<div class=\"(locked|showhide)\">.*?<\/div>|<span style=\"display:none\">.*?<\/span>|<font class=\"jammer\">.*?<\/font>|<i class=\"pstatus\">.*?<\/i>|\<script.*?\<\/script\>|\<style.*?\<\/style\>|<ignore_js_op>.*?<\/ignore_js_op>/is", '', $msg);		
		$langcore = lang('core');;
        $desc = str_replace(array($langcore['fullblankspace'], '&nbsp;', ' ','　', "\t", "\r", "\n", '\'', '"'), '', strip_tags($desc));
				
		// canonical
		if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
			$canonical = rewriteoutput('forum_viewthread', 1, '', $_G['tid'], 1, '', '');
		} else {
			$canonical = 'forum.php?mod=viewthread&tid='.$_G['tid'];
		}
		
		// fix "{fid}"
		$canonical = str_replace('{fid}', ($_G['setting']['forumkeys'][$_G['fid']] ? $_G['setting']['forumkeys'][$_G['fid']] : $_G['fid']), $canonical);
        		
		// head
        $data = array(
            'url' => $_G['siteurl'].$canonical,
            'title' => $title,
            'content' => $msg,
            'description' => cutstr($desc, $this->conf['msg_length']),
            'dateline' => $dateline
        );
		
        // button
		$update = $dateline;
		$i = 0;
		foreach($postlist as $pid => $post) {
			if($i==1) $update = $post['dbdateline'];
        	if($post['first'] && $this->conf['isgroupid'] && $this->conf['isfid']){
				$postlist[$pid]['message'] = (in_array('2', $this->conf['usefans']) ? '<div class="p16"><script>cambrian.render("body")</script></div>' : "").(in_array('1', $this->conf['usebtns']) ? $this->link($data) : "").$postlist[$pid]['message'].(in_array('2', $this->conf['usebtns']) ? $this->link($data) : "").(in_array('4', $this->conf['usefans']) ? '<div class="p16"><script>cambrian.render("body")</script></div>' : "");
        	}
			$i++;
		}
		$data['update'] = $update;
		$data['lrdate'] = $thread['lastpost'];
		$this->head($data);	
	}

}

// group
class mobileplugin_onexin_baiduxzh_group extends mobileplugin_onexin_baiduxzh_forum{
	
}

// portal
class mobileplugin_onexin_baiduxzh_portal extends mobileplugin_onexin_baiduxzh {
	
	function view_onexin_baiduxzh_output(){
		global $_G, $article, $content;
		
		if(!$this->isopen) return '';
        
		$title = strip_tags($article['title']);
		$msg = $content['content'];
		$dateline = $article['timestamp'];
            
		// SUMMARY
		$desc = str_replace(array('&nbsp;', ' ', '　', "\t", "\r", "\n", '\'', '"'), '', strip_tags($msg));
               
		// page
		$page = intval($_GET['page']);
		
		// canonical
		if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
			$canonical = rewriteoutput('portal_article', 1, '', $article['aid'], 1, '');
		} else {
			$canonical = 'portal.php?mod=view&aid='.$article['aid'];
		}
		
		// head
        $data = array(
            'url' => $_G['siteurl'].$canonical,
            'title' => $title,
            'content' => $msg,
            'description' => cutstr($desc, $this->conf['msg_length']),
            'dateline' => $dateline
        );
		$this->head($data);	
        
        // button
        if($this->conf['isgroupid']){
            $content['content'] = (in_array('2', $this->conf['usefans']) ? '<div class="p16"><script>cambrian.render("body")</script></div>' : "").(in_array('1', $this->conf['usebtns']) ? $this->link($data) : "").$content['content'].(in_array('2', $this->conf['usebtns']) ? $this->link($data) : "").(in_array('4', $this->conf['usefans']) ? '<div class="p16"><script>cambrian.render("body")</script></div>' : "");
        }
	}	
	
}
