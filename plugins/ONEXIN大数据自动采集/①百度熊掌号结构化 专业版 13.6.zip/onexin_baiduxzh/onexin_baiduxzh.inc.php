<?php
/**
 * ONEXIN BAIDU XZH For Discuz!X 3.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_baiduxzh
 * @date	   2018-06-19
 * @author	   King
 * [DisM!] (C)2019-2020 DISM.Taobao.COM.
 */

/*
//--------------Tall us what you think!----------------------------------
*/

//
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(defined('IN_ADMINCP')) {
	?>
    <a href="<?PHP echo $_G['siteurl'] ?>plugin.php?id=onexin_baiduxzh" target="_blank"> <?PHP echo $_G['siteurl'] ?>plugin.php?id=onexin_baiduxzh </a>
	<?php
	exit();
}

include_once DISCUZ_ROOT . './source/plugin/onexin_baiduxzh/function_baiduxzh.php';

if(!isset($_G['cache']['plugin'])){
    loadcache('plugin');/*dism-Taobao-com*/
}
$conf = $_G['cache']['plugin']['onexin_baiduxzh'];
$xzhapi = trim($conf['xzhapi']);
$today = strtotime('today');

// 允许提交的用户组
$conf['usergroups'] = (array)unserialize($conf['usergroups']);
$conf['isgroupid'] = FALSE;
if(empty($conf['usergroups'][0]) || in_array($_G['groupid'], $conf['usergroups'])){
    $conf['isgroupid'] = TRUE;
}

// 允许批量管理的用户组
$conf['batchgroups'] = (array)unserialize($conf['batchgroups']);
$conf['ismanage'] = FALSE;
if(empty($conf['batchgroups'][0]) || in_array($_G['groupid'], $conf['batchgroups'])){
    $conf['ismanage'] = TRUE;
}


$langtxt = array();
$langtxt['thread'] = '&#35770;&#22363;&#20869;&#23481;&#39029;';//论坛内容页
$langtxt['article'] = '&#38376;&#25143;&#25991;&#31456;&#39029;';//门户文章页
$langtxt['unknow'] = '&#26410;&#30693;&#20869;&#23481;&#39029;';//未知内容页

//------------------------------------------------------------     

// check permission
if(!$conf['isgroupid']){
    $output = array("status" => '500', 'content'=> 'No Group permission');
    _baiduxzh_output($output);        
}
        
$view = !empty($_GET['view']) ? $_GET['view'] : 'manage';

if($view == 'manage') {	

	// check admin
	if(!$conf['ismanage']) {
		showmessage('no_privilege');
	}
    
    $xzhapi_batch = str_replace('realtime', 'batch', $xzhapi);

    $dir = dirname(__FILE__);
    if (!is_dir($dir.'/cache') && is_writeable($dir)){
        mkdir($dir.'/cache');
    }
    if (is_dir($dir.'/cache') && is_writeable($dir.'/cache')){
        $min_cachePath = $dir.'/cache';
    }else{
        // 日志文件写入失败，请检查文件夹权限
        $writeable = '<h3 class=\"edited\">&#26085;&#24535;&#25991;&#20214;&#20889;&#20837;&#22833;&#36133;&#65292;&#35831;&#26816;&#26597;&#25991;&#20214;&#22841;&#26435;&#38480; source/plugin/onexin_baiduxzh/cache</h3>';
        echo $writeable;exit;
    }
	
		$sdata = explode("\n", $conf['confkey']);
		$select = "<select id=\"fromxzh\" name=\"fromxzh\" class=\"onexin_baiduxzh_fromxzh\" data-url=\"{$url}\">";
		foreach($sdata as $key => $val) {
            // key#name
            $data = explode('#', trim($val));
            if($data[1]) {
				$select .= "<option value=\"".$data[0]."\" ".($key==0 ? "selected" : "").">".$data[1]."</option>";				
			}
		}
		$select .= "</select>";	
    
    $data = _baiduxzh_getcache_statslist();
    $count = count($data);
    if($count > $conf['daylimit']) {
        echo "<h3 class=\"edited\">&#24050;&#36229;&#20986;&#26032;&#22686;&#20869;&#23481;&#37197;&#39069;</h3>";
    }
    $html = implode("", $data);
    
	include template('onexin_baiduxzh:manage');
	exit;
    
}elseif($view == 'statslist'){

	// check admin
	if(!$conf['ismanage']) {
		showmessage('no_privilege');
	}
    
    // check status
    $data = _baiduxzh_getcache_statslist();
    $html = implode("", $data);
	echo $html;
    exit;
    
}elseif($view == 'todaylist'){

	// check admin
	if(!$conf['ismanage']) {
		showmessage('no_privilege');
	}
    
    // check today  
    $todaylist = _baiduxzh_getcache();
    $data = array();
	
    // thread
    $result = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." WHERE displayorder!='-1' ORDER BY dateline DESC LIMIT 50");
    foreach($result as $val){
            // canonical
            if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
                $canonical = rewriteoutput('forum_viewthread', 1, '', $val['tid'], 1, '', '');
            } else {
                $canonical = 'forum.php?mod=viewthread&tid='.$val['tid'];
            }
		
		// fix "{fid}"
		$canonical = str_replace('{fid}', ($_G['setting']['forumkeys'][$val['fid']] ? $_G['setting']['forumkeys'][$val['fid']] : $val['fid']), $canonical);
		
        $url = $_G['siteurl'].$canonical;
        $k = md5($url.$xzhapi);
        $data[$k] = array(
            'id' => $val['tid'],
            'url' => $url,
            'title' => "[".dgmdate($val['dateline'], 'm-d H:i:s')."] ".$val['subject'],
            'type' => $langtxt['thread'],
            'code' => !empty($todaylist[$k]['code']) ? $todaylist[$k]['code'] : '0',
            'mode' => !empty($todaylist[$k]['mode']) ? $todaylist[$k]['mode'] : '0',
            'time' => !empty($todaylist[$k]['time']) ? $todaylist[$k]['time'] : '0',
            'num' => !empty($todaylist[$k]['num']) ? $todaylist[$k]['num'] : '0'
        );       
    }
    
    // thread
    $result = DB::fetch_all("SELECT * FROM ".DB::table('portal_article_title')." WHERE 1=1 ORDER BY aid DESC LIMIT 50");
    foreach($result as $val){
            // canonical
            if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
                $canonical = rewriteoutput('portal_article', 1, '', $val['aid'], 1, '');
            } else {
                $canonical = 'portal.php?mod=view&aid='.$val['aid'];
            }
        $url = $_G['siteurl'].$canonical;
        $k = md5($url.$xzhapi);
        $data[$k] = array(
            'id' => $val['aid'],
            'url' => $url,
            'title' => "[".dgmdate($val['dateline'], 'm-d H:i:s')."] ".$val['title'],
            'type' => $langtxt['article'],
            'code' => !empty($todaylist[$k]['code']) ? $todaylist[$k]['code'] : '0',
            'mode' => !empty($todaylist[$k]['mode']) ? $todaylist[$k]['mode'] : '0',
            'time' => !empty($todaylist[$k]['time']) ? $todaylist[$k]['time'] : '0',
            'num' => !empty($todaylist[$k]['num']) ? $todaylist[$k]['num'] : '0'
        );       
    }
    
    //_baiduxzh_setcache('', $data);
    
    $list = $data;//_baiduxzh_getcache();
    $html = '';
    foreach($list as $val){
        if(!empty($val['url'])) {
//            if($val['code']=='200') {
//                $input = "<input type=\"checkbox\" disabled />";
//            }else{
                $input = "<input class=\"checkbox\" type=\"checkbox\" name=\"tidarray[]\" value=\"{$val[id]}\" data-url=\"{$val[url]}\" />";    
//            }
            $html .= "<tr class=\"log-{$val[id]} hover\"><td class=\"td25\">{$input}</td><td class=\"td25\">{$val[code]}</td><td><a href=\"{$val[url]}\" target=\"_blank\">{$val[title]}</a></td><td>{$val[type]}</td><td>{$val[num]}</td><td class=\"td25\">{$val[mode]}</td><td>{$val[time]}</td></tr>";
        }
    }
	echo $html;
    exit;
}elseif($view == 'historylist'){

	// 批量提交历史信息，只能管理员组使用
	if($_G['groupid']!='1') {
		showmessage('no_privilege');
	}

$nextid = 0;

$start = !empty($_GET['start']) ? (int)$_GET['start'] : '0';
$limit = !empty($_GET['limit']) ? (int)$_GET['limit'] : '200';
$count = !empty($_GET['count']) ? (int)$_GET['count'] : '200';
$type = !empty($_GET['type']) ? $_GET['type'] : '1';
$api = !empty($_GET['xzhapi']) ? $_GET['xzhapi'] : '';
$siteurl = !empty($_GET['siteurl']) ? $_GET['siteurl'] : $_G['siteurl'];

//$api = 'http://data.zz.baidu.com/urls?appid=1582855495060472&token=xctl7GBtgZnRa7Ta&type=batch';

            if(preg_match("/type=mip/", $api)){
				$siteurl = $siteurl.'mip/';
			}
// ------------------

	if($type == '3'){
        $query = DB::query("SELECT * FROM ".DB::table('home_blog')." WHERE blogid>'$start' ORDER BY blogid ASC LIMIT $limit");
        $urls = array();
        while($value = DB::fetch($query)) {
            $nextid = $value['blogid'];
            
            // canonical
			if(in_array('home_blog', $_G['setting']['rewritestatus'])) {
				$canonical = rewriteoutput('home_blog', 1, '', $value['uid'], $nextid, '');
			} else {
				$canonical = 'home.php?mod=space&uid='.$value['uid'].'&do=blog&id='.$nextid;
			}
            $urls[] = $siteurl.$canonical;
        }
    }elseif($type == '2'){
        $query = DB::query("SELECT * FROM ".DB::table('portal_article_title')." WHERE aid>'$start' ORDER BY aid ASC LIMIT $limit");
        $urls = array();
        while($value = DB::fetch($query)) {
            $nextid = $value['aid'];
            
            // canonical
            if(in_array('portal_article', $_G['setting']['rewritestatus'])) {
                $canonical = rewriteoutput('portal_article', 1, '', $nextid, 1, '');
            } else {
                $canonical = 'portal.php?mod=view&aid='.$nextid;
            }
            $urls[] = $siteurl.$canonical;
        }
    }else{
        $query = DB::query("SELECT * FROM ".DB::table('forum_thread')." WHERE tid>'$start' ORDER BY tid ASC LIMIT $limit");
        $urls = array();
        while($value = DB::fetch($query)) {
            $nextid = $value['tid'];
            
            // canonical
            if(in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
                $canonical = rewriteoutput('forum_viewthread', 1, '', $nextid, 1, '', '');
            } else {
                $canonical = 'forum.php?mod=viewthread&tid='.$nextid;
            }
		
		// fix "{fid}"
		$canonical = str_replace('{fid}', ($_G['setting']['forumkeys'][$value['fid']] ? $_G['setting']['forumkeys'][$value['fid']] : $value['fid']), $canonical);
            
            $urls[] = $siteurl.$canonical;		
        }        
    }
    $result = _baiduxzh_push($urls, $api);
    
    $output = array(
        'status' => '200', 
        'content' => $result, 
        'start' => $nextid, 
        'count' => $nextid ? $count - $limit : 0, 
        'num' => $limit
    );
    //_baiduxzh_setcache('history', $output);
    _baiduxzh_output($output);
}elseif($view == 'todaysubmit'){
    
    // check today  
    $todaylist = _baiduxzh_getcache();
    $data = array();
    
    $api = !empty($_GET['xzhapi']) ? trim($_GET['xzhapi']) : $xzhapi;
    $xzhurls = !empty($_GET['xzhurls']) ? trim($_GET['xzhurls']) : ''; 
    $mode = !empty($_GET['mode']) ? intval($_GET['mode']) : 1; 
	$siteurl = !empty($_GET['siteurl']) ? $_GET['siteurl'] : $_G['siteurl'];
    $fromapi = !empty($_GET['fromapi']) ? intval($_GET['fromapi']) : 0; 
	
		$sdata = explode("\n", $conf['confkey']);
		foreach($sdata as $key => $val) {
            // key#name
            $data = explode('#', trim($val));
            if($data[1] && $key == $fromapi) {
				$api = $data[0];	
				$apitxt = $data[1];							
			}
		}
    
    $xzhurls = explode("\n", $xzhurls);
    $urls = $tids = $aids = array();
    foreach($xzhurls as $val){
            if(preg_match("/type=mip/", $api)){
				$val = str_replace($siteurl, $siteurl.'mip/', $val);
			}
        $k = md5($val.($api ? $api : ""));
        if($todaylist[$k]['code'] == 200) {
            continue;
        }
        if(!empty($val)) {
			$urls[$k] = trim($val);
        }
    }
    
    $result = !empty($urls) ? _baiduxzh_push($urls, $api) : '';
    
    //{"error":400,"message":"empty content"}
    if(preg_match("/success/", $result)){
        $code = '200';
    }else{
        $code = '400';
    }
    foreach($urls as $val){        
        if(preg_match("/(\/thread-|viewthread&tid=)(\d+)/", $val, $match)){
            $vval = DB::fetch_first("SELECT subject,dateline FROM ".DB::table('forum_thread')." WHERE tid='$match[2]'");
            $vval['type'] = 'thread';
            $vval['title'] = $vval['subject'];
        }elseif(preg_match("/(\/article-|mod=view&aid=)(\d+)/", $val, $match)){
            $vval = DB::fetch_first("SELECT title,dateline FROM ".DB::table('portal_article_title')." WHERE aid='$match[2]'");
            $vval['type'] = 'article';
        }else{
            $vval['title'] = $val;
            $vval['dateline'] = TIMESTAMP;
            $vval['type'] = 'unknow';
        }
            
        $url = $val;
        $k = md5($url.($api ? $api : ""));
        $todaylist[$k]['url'] = $url;
        $todaylist[$k]['title'] = "[".dgmdate($vval['dateline'], 'm-d H:i:s')."] ".$vval['title'];
        $todaylist[$k]['type'] = $vval['type'];
        $todaylist[$k]['code'] = $code;
        $todaylist[$k]['mode'] = $mode;
        $todaylist[$k]['api'] = $apitxt;
        $todaylist[$k]['time'] = dgmdate(TIMESTAMP, 'Y-m-d H:i:s');
        $todaylist[$k]['num'] = !empty($todaylist[$k]['num']) ? $todaylist[$k]['num'] + 1 : 1;               
    } 
    
    _baiduxzh_setcache('', $todaylist);
    
    $output = array(
        'status' => '200', 
        'urls' => implode("\n", $urls), 
        'content' => $result
    );
    _baiduxzh_output($output);
}

