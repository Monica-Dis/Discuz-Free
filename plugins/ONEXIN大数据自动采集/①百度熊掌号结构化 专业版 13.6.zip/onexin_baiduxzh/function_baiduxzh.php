<?php
/**
 * 
 * DisM!出品 必属精品
 * DisM!应用中心所有 https://dism.Taobao.Com
 * 专业Discuz!应用插件、模板正版采购提供代下载服务、技术支持等全方位服务...
 * 我们致力于为站长提供正版Discuz!应用而努力
 * E-mail: dism.taobao@qq.com
 * 工作时间: 周一到周五早上09:00-12:00, 下午13:00-18:00, 晚上19:30-23:30(周六、日休息)
 * DisM!用户交流群: ①群778390776
 * 
 */

//
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

// OUTPUT
function _baiduxzh_output($output = ''){
	$output = !empty($output) ? $output : array("result" => '404', "content" => 'NOT FOUND');
	echo json_encode($output);
    exit;
}

function _baiduxzh_push($urls = array(), $api = '') {
    if(empty($urls)) return;
$ch = curl_init();
$options =  array(
    CURLOPT_URL => $api,
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => implode("\n", $urls),
    CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
    CURLOPT_TIMEOUT => 5,
    CURLOPT_CONNECTTIMEOUT => 5,
);
curl_setopt_array($ch, $options);
$result = curl_exec($ch);

	return $result;
}

function _baiduxzh_getcache_statslist(){

    $list = _baiduxzh_getcache();
	
$langtxt = array();
$langtxt['thread'] = '&#35770;&#22363;&#20869;&#23481;&#39029;';//论坛内容页
$langtxt['article'] = '&#38376;&#25143;&#25991;&#31456;&#39029;';//门户文章页
$langtxt['unknow'] = '&#26410;&#30693;&#20869;&#23481;&#39029;';//未知内容页
    
    $data = array();
    foreach($list as $val){
        if(!empty($val['url'])) {
            if(empty($val['title'])) {$val['title'] = $val['url'];}
            if($val['code']=='200') {
                $input = "<input type=\"checkbox\" disabled />";
            }else{
                $input = "<input class=\"checkbox\" type=\"checkbox\" name=\"tidarray[]\" value=\"{$val[id]}\" data-url=\"{$val[url]}\" />";    
            }
			$val['type'] = isset($langtxt[$val['type']]) ? $langtxt[$val['type']] : $val['type'];
			$val['mode'] = ($val['mode'] == '2') ? '&#33258;&#21160;' : $val['mode'];
			$val['mode'] = ($val['mode'] == '1') ? '&#25163;&#21160;' : $val['mode'];			
			if(!empty($val['api'])) $val['api']= preg_replace("/^.*?&(type=\w+)$/", "\\1", $val['api']);
            $data[strtotime($val['time']).$val['url']] = "<tr class=\"log-{$val[id]} hover\"><td class=\"td25\">{$input}</td><td class=\"td25\">{$val[code]}</td><td><a href=\"{$val[url]}\" target=\"_blank\">{$val[title]}</a><br>{$val[api]}</td><td>{$val[type]}</td><td>{$val[num]}</td><td class=\"td25\">{$val[mode]}</td><td>{$val[time]}</td></tr>";
        }   
    }
    krsort($data);
    
    return $data;
}

function _baiduxzh_getcache($key = ''){    
    $today = strtotime('today');
    $key = !empty($key) ? $key : date('Ymd', $today); 
    $dir = DISCUZ_ROOT.'./source/plugin/onexin_baiduxzh';//dirname(__FILE__);
	$list = array();
    $file = $dir.'/cache/'.$key.'.php';
	if(file_exists($file)){
		$_OBD_SET = array();
		include_once $file;
        $list = $_OBD_SET[$key];
    }   
    return $list;
}

function _baiduxzh_setcache($key = '', $data = array(), $expire = 300){
	if(empty($data)) return;
    $today = strtotime('today');
    $key = !empty($key) ? $key : date('Ymd', $today); 
    $dir = DISCUZ_ROOT.'./source/plugin/onexin_baiduxzh';//dirname(__FILE__);
    $val = array();
    $val[$key] = $data;
    $file = $dir.'/cache/'.$key.'.php';
    $val[$key]['expire'] = time();
	$code = "<?php\n\rif(!defined('IN_DISCUZ')) { exit('Access Denied'); }\n\r//". date('Y-m-d H:i:s')." Created\n\r\$_OBD_SET = ". var_export($val, true). ";";
	file_put_contents($file, $code);    
}