<?php
/**
 * ONEXIN CLOUD STORAGE For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_cloudstorage
 * @date	   2019-07-21
 * @author	   dism.taobao.com
 * @copyright  Copyright (c) 2019 Onexin Platform Inc. (http://www.onexin.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

class Qiniu
{
    protected $auth;
    protected $http;
    protected $upHost;
    protected $rsHost;
    protected $rsfHost;
    protected $apiHost;

    public function __construct($config = array())
    {
		$this->auth = new Auth($config['access_key'], $config['secret_key']);
        $this->http = new Http;
        $config['region'] = !empty($config['region']) ? $config['region'] : 'z0'; 
		       
		// set specific hosts
        $this->upHost = "http://up".($config['region'] !='z0' ? "-".$config['region'] : '').".qiniu.com";
        $this->rsHost = "http://rs".($config['region'] !='z0' ? "-".$config['region'] : '').".qbox.me";
        $this->rsfHost = "http://rsf".($config['region'] !='z0' ? "-".$config['region'] : '').".qbox.me";
        $this->apiHost = "http://api".($config['region'] !='z0' ? "-".$config['region'] : '').".qiniu.com";
    }
	
    public function put($bucket, $key, $file)
    {
        $scope = sprintf('%s:%s', $bucket, $key);
		$scope = ['scope' => $scope];
        $scopes = $this->auth->scope($scope);
		
        $encodePolicies = json_encode($scopes);
        $token = $this->auth->signData($encodePolicies);
		
		$url = $this->upHost;
        $params = array('key' => $key);
        $response = $this->http->callMultiRequest($url, $token, $file, $params);
		
        return $response;
    }

    public function delete($bucket, $key)
    {
        $scope = sprintf('%s:%s', $bucket, $key);
		
        $url = $this->rsHost . $this->option('delete', $scope);
        $request = $this->createSignedRequest($url);
        $response = $this->http->sendRequest($request);
		
        return $response;
    }  

    public function option($op = '', $scope = '') 
    {
        return sprintf('/%s/%s', $op, $this->encode($scope));
    }

    public function createSignedRequest($url, $headers = [], $body = null)
    {
        $request = $this->http->Request($url, $headers, $body);
        $request['headers']['Content-Type'] = 'application/x-www-form-urlencoded';		
        $request['headers']['Authorization'] = 'QBox ' . $this->auth->signRequest($request);	
        return $request;
    }

    public function encode($string)
    {
        $find = ['+', '/'];
        $replace = ['-', '_'];
        return str_replace($find, $replace, base64_encode($string));
    }
	
}
