<?php
/**
 * ONEXIN MAIL FIX For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_email_fix
 * @module	   email_fix 
 * @date	   2020-04-28
 * @author	   DisM!应用中心 dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


/*
//--------------Tall us what you think!----------------------------------

home.php?mod=spacecp&ac=profile&op=password

*/

class plugin_onexin_email_fix_base {

	protected static $conf = array();
	protected static $isopen = FALSE;

	public function __construct() {
		global $_G;
		
		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		self::$isopen = $_G['cache']['plugin']['onexin_email_fix']['isopen'] ? TRUE : FALSE;
		if(self::$isopen){
			self::$conf = $_G['cache']['plugin']['onexin_email_fix'];
			self::$conf['emailfix'] = !empty(self::$conf['emailfix']) ? self::$conf['emailfix'] : 'null.nullnull';	
			self::$conf['usergroups'] = (array)unserialize(self::$conf['usergroups']);
			
			self::$conf['isgroupid'] = FALSE;
			if(empty(self::$conf['usergroups'][0]) || in_array($_G['groupid'], self::$conf['usergroups'])){
				self::$conf['isgroupid'] = TRUE;
			}	
		}
	}
	
//	public function email_fix() {
//		global $_G;
//		
//		if(!self::$isopen) return '';
//		
//		return '';
//	}

}

//// PC
//class plugin_onexin_email_fix extends plugin_onexin_email_fix_base {
//	
//	public function global_footer() {
//		global $_G;
//		
//		if(!self::$isopen) return '';
//
//		self::email_fix();
//		
//		return '';
//	}
//
//}

// home
class plugin_onexin_email_fix_home extends plugin_onexin_email_fix_base {
	
	public function spacecp_profile_top_output() {
		global $_G, $space;
		
		// home.php?mod=spacecp&ac=profile&op=password
		if(!self::$isopen || $_GET['op']!='password' || empty(self::$conf['isgroupid'])) return '';
		
		// $space['email'], [emailstatus]
		
		if(!preg_match("~@(".self::$conf['emailfix'].")$~", $space['email'])) return '';
		
		dheader("Location: ".$_G['siteurl']."plugin.php?id=onexin_email_fix");
		
	}	
	
}

//// Mobile
//class mobileplugin_onexin_email_fix extends plugin_onexin_email_fix_base {
//	
//	public function global_header_mobile() {
//		global $_G;
//		
//		if(!self::$isopen) return '';
//
//		self::email_fix();
//		
//		return '';
//	}
//
//}

// home
class mobileplugin_onexin_email_fix_home extends plugin_onexin_email_fix_home {}


