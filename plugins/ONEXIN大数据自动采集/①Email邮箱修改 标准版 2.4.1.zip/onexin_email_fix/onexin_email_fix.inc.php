<?php
/**
 * ONEXIN MAIL FIX For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_email_fix
 * @module	   email_fix 
 * @date	   2020-04-15
 * @author	   DisM!应用中心 dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

//--------------Tall us what you think!----------------------------------

*/

if(!isset($_G['cache']['plugin'])){
	loadcache('plugin');
}

			$conf = $_G['cache']['plugin']['onexin_email_fix'];
			$conf['usergroups'] = (array)unserialize($conf['usergroups']);
			$conf['isgroupid'] = 0;
			if(empty($conf['usergroups'][0]) || in_array($_G['groupid'], $conf['usergroups'])){
				$conf['isgroupid'] = 1;
			}
			$conf['emailfix'] = !empty($conf['emailfix']) ? $conf['emailfix'] : 'null.nullnull';	

//-------------------------------------------------------------------------
if($_GET['op'] == 'manage') {
	
		// check
		if(empty($_G['uid']) || empty($conf['isgroupid'])) {
			showmessage('no_privilege');
		}
	
	// formhash
	if(submitcheck('managesubmit')) {
		
		// check again
		$space_email = DB::result_first("SELECT email FROM ".DB::table('common_member')." WHERE uid ='$_G[uid]';");
		if(!preg_match("~@(".$conf['emailfix'].")$~", $space_email)){
			showmessage('no_privilege');		
		}
	
		$email = strtolower(trim($_GET['email']));
		if(strlen($email) > 32) {
			showmessage('profile_email_illegal', '', array(), array('handle' => false));
		}
		if($_G['setting']['regmaildomain']) {
			$maildomainexp = '/('.str_replace("\r\n", '|', preg_quote(trim($_G['setting']['maildomainlist']), '/')).')$/i';
			if($_G['setting']['regmaildomain'] == 1 && !preg_match($maildomainexp, $email)) {
				showmessage('profile_email_domain_illegal', '', array(), array('handle' => false));
			} elseif($_G['setting']['regmaildomain'] == 2 && preg_match($maildomainexp, $email)) {
				showmessage('profile_email_domain_illegal', '', array(), array('handle' => false));
			}
		}
	
		loaducenter();
		$ucresult = uc_user_checkemail($email);
	
		if($ucresult == -4) {
			showmessage('profile_email_illegal', '', array(), array('handle' => false));
		} elseif($ucresult == -5) {
			showmessage('profile_email_domain_illegal', '', array(), array('handle' => false));
		} elseif($ucresult == -6) {
			showmessage('profile_email_duplicate', '', array(), array('handle' => false));
		}
		
			// @oauth.null
			DB::query("UPDATE ".DB::table('common_member')." SET `email` = '$email' WHERE uid ='$_G[uid]';");
			
			// uc
			loaducenter();
			DB::query("UPDATE ".UC_DBTABLEPRE.'members'." SET `email` = '$email' WHERE uid ='$_G[uid]';");	
		//showmessage('register_email_verify_location');

		$url_forward = "home.php?mod=spacecp&ac=profile&op=password";//dreferer();		

			$refreshtime = 3000;
			$message = 'register_succeed';
			$locationmessage = 'register_succeed_location';
			
			// 新用户注册验证
//			switch($_G['setting']['regverify']) {
//				case 1:
//					$idstring = random(6);
//					$authstr = $_G['setting']['regverify'] == 1 ? "$_G[timestamp]\t2\t$idstring" : '';
//					C::t('common_member_field_forum')->update($_G['uid'], array('authstr' => $authstr));
//					$verifyurl = "{$_G[siteurl]}member.php?mod=activate&amp;uid={$_G[uid]}&amp;id=$idstring";
//					$email_verify_message = lang('email', 'email_verify_message', array(
//						'username' => $_G['member']['username'],
//						'bbname' => $_G['setting']['bbname'],
//						'siteurl' => $_G['siteurl'],
//						'url' => $verifyurl
//					));
//					if(!sendmail("$username <$email>", lang('email', 'email_verify_subject'), $email_verify_message)) {
//						runlog('sendmail', "$email sendmail failed.");
//					}
//					$message = 'register_email_verify';
//					$locationmessage = 'register_email_verify_location';
//					$refreshtime = 10000;
//					break;
//				case 2:
//					$message = 'register_manual_verify';
//					$locationmessage = 'register_manual_verify_location';
//					break;
//				default:
//					$message = 'register_succeed';
//					$locationmessage = 'register_succeed_location';
//					break;
//			}			
			
		$param = array('bbname' => $_G['setting']['bbname'], 'username' => $_G['username'], 'usergroup' => $_G['group']['grouptitle'], 'uid' => $_G['uid']);

		showmessage($message, $url_forward, $param);	
					
/*		$href = str_replace("'", "\'", $url_forward);
		$extra = array(
			'showid' => 'succeedmessage',
			'extrajs' => '<script type="text/javascript">'.
				'setTimeout("window.location.href =\''.$href.'\';", '.$refreshtime.');'.
				'$(\'succeedmessage_href\').href = \''.$href.'\';'.
				'$(\'main_message\').style.display = \'none\';'.
				'$(\'main_succeed\').style.display = \'\';'.
				'$(\'succeedlocation\').innerHTML = \''.lang('message', $locationmessage).'\';'.
			'</script>',
			'striptags' => false,
		);
		showmessage($message, $url_forward, $param, $extra);*/
		// new
		
	}
	
}else{
    
	$sendurl = $showregisterform = 1;
	
	$_lang_mail = lang('member/template');
	$_lang_register_email_tips = $_lang_mail['register_email_tips'];
	$_lang_register_validate_email_tips = $_lang_mail['register_validate_email_tips'];//lang('member/template', 'register_validate_email_tips');
	
	$email_check_id = 'email-'.random(5);
	
	include template('onexin_email_fix:onexin_email_fix');
	exit();	
		
}

