<?php
/**
 * ONEXIN TAGS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_tags
 * @module	   onexin_tags
 * @date	   2021-05-16
 * @author	   dism-Taobao-com
 * @copyright  Copyright (c) 2021 by dism.taobao.com
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
开启中文标签
$conf['ischinese']

UTF8
/tag/江门市.html
/tag/%B5%D8%C7%F8.html

GBK
plugin.php?id=onexin_tags&tagname=%B5%D8%C7%F8
*/

$conf = $_G['cache']['plugin']['onexin_tags'];

$id = intval($_GET['tagid']);
$type = trim($_GET['type']);
//$_GET['tagname'] = isset($_GET['_u_t_f_8_']) ? diconv($_GET['tagname'], 'utf-8') : $_GET['tagname'];
//$_GET['tagname'] = diconv($_GET['tagname'], 'utf-8');
	  
	// 自动识别编码
	$fileType = mb_detect_encoding($_GET['tagname'] , array('UTF-8', 'GBK', 'BIG5')) ;   
	if( $fileType != 'UTF-8' ){   
		$_GET['tagname'] = mb_convert_encoding($_GET['tagname'] , 'UTF-8' , $fileType);   
	}
	
	// q的中文为utf8
	$_GET['tagname'] = CHARSET != 'utf-8' ? diconv($_GET['tagname'], 'utf-8') : $_GET['tagname'];
	
$name = trim($_GET['tagname']);
$page = intval($_GET['page']);
if($type == 'countitem') {
	$num = 0;
	if($id) {
		$num = C::t('common_tagitem')->count_by_tagid($id);
	}
	include_once template('onexin_tags:onexin_tag');
	exit();
}

	$taglang = $conf['itags_name'];
	$taglang = lang('tag/template', 'tag');	

if($id || $name) {
	
	$tpp = empty($conf['tpp']) ? 20 : intval($conf['tpp']);
	//$tpp = 2;
	$page = max(1, intval($page));
	$start_limit = ($page - 1) * $tpp;
	if($id) {
		$tag = C::t('common_tag')->fetch_info($id);
	} else {
		if(!preg_match('/^([\x7f-\xff_-]|\w|\s)+$/', $name) || strlen($name) > 20) {
			//showmessage('parameters_error');
		}
		$name = addslashes($name);
		$tag = C::t('common_tag')->fetch_info(0, $name);
	}
	
	if($tag['status'] == 1) {
		showmessage('tag_closed');
	}
    
	// chinese tag
	$tagurl = "plugin.php?id=onexin_tags&".($conf['ischinese'] ? "tagname=".$tag['tagname'] : "tagid=$tag[tagid]");
	$tagname = $tag['tagname'];
	$id = $tag['tagid'];
	$searchtagname = $name;
	$metakeywords = $tagname ? $tagname : $taglang;
	$metadescription = $tagname ? $tagname : $taglang;
	$navtitle = $tagname ? $tagname.' - '.helper_seo::get_title_page($taglang, $page) : $taglang;

	$showtype = '';
	$count = '';
	
	if($type == 'thread') {
		$showtype = 'thread';
		$tidarray = $threadlist = array();
		$count = C::t('common_tagitem')->select($id, 0, 'tid', '', '', 0, 0, 0, 1);
		if($count) {
			// BUG 一处
			//$query = C::t('common_tagitem')->select($id, 0, 'tid', '', '', $start_limit, $tpp);
			$idtype = 'tid';
			$query = DB::fetch_all("SELECT * FROM ".DB::table('common_tagitem')." WHERE tagid = '$id' AND idtype = '$idtype' ORDER BY itemid DESC LIMIT $start_limit, $tpp");
			foreach($query as $result) {
				$tidarray[$result['itemid']] = $result['itemid'];
			}
			$threadlist = getthreadsbytids($tidarray);
			$multipage = multi($count, $tpp, $page, $tagurl."&type=thread");
		}
	} elseif($type == 'blog') {
		$showtype = 'blog';
		$blogidarray = $bloglist = array();
		$count = C::t('common_tagitem')->select($id, 0, 'blogid', '', '', 0, 0, 0, 1);
		if($count) {
			// BUG 一处
			//$query = C::t('common_tagitem')->select($id, 0, 'blogid', '', '', $start_limit, $tpp);
			$idtype = 'blogid';
			$query = DB::fetch_all("SELECT * FROM ".DB::table('common_tagitem')." WHERE tagid = '$id' AND idtype = '$idtype' ORDER BY itemid DESC LIMIT $start_limit, $tpp");
			foreach($query as $result) {
				$blogidarray[$result['itemid']] = $result['itemid'];
			}
			$bloglist = getblogbyid($blogidarray);

			$multipage = multi($count, $tpp, $page, $tagurl."&type=blog");
		}
	} elseif($type == 'article') {
		$showtype = 'article';
		$articleidarray = $articlelist = array();
		$count = C::t('common_tagitem')->select($id, 0, 'articleid', '', '', 0, 0, 0, 1);
		if($count) {
			// BUG 一处
			//$query = C::t('common_tagitem')->select($id, 0, 'articleid', '', '', $start_limit, $tpp);
			$idtype = 'articleid';
			$query = DB::fetch_all("SELECT * FROM ".DB::table('common_tagitem')." WHERE tagid = '$id' AND idtype = '$idtype' ORDER BY itemid DESC LIMIT $start_limit, $tpp");
			foreach($query as $result) {
				$articleidarray[$result['itemid']] = $result['itemid'];
			}
			$articlelist = getarticlebyid($articleidarray);

			$multipage = multi($count, $tpp, $page, $tagurl."&type=article");
		}
	} else {
//		$shownum = empty($conf['shownum']) ? 10 : intval($conf['shownum']);
//		$shownum = 2;
//		$tpp = $shownum;

		$articlelist = $articleidarray = $tidarray = $blogidarray = array();
        
        $showtype = 'article';
        
        $page = max(1, intval($page));
        $start_limit = ($page - 1) * $tpp;		
        $count = DB::result_first("SELECT count(*) FROM ".DB::table('common_tagitem')." WHERE tagid='$id' ORDER BY tagid DESC");
        if($count) {
            $query = DB::fetch_all("SELECT * FROM ".DB::table('common_tagitem')." WHERE tagid='$id' ORDER BY tagid DESC LIMIT $start_limit, $tpp");
            foreach($query as $result) {
				if($result['idtype'] == 'tid') {
                    $tidarray[$result['itemid']] = $result['itemid'];
                }elseif($result['idtype'] == 'blogid') {
                    $blogidarray[$result['itemid']] = $result['itemid'];
                }elseif($result['idtype'] == 'articleid') {
                    $articleidarray[$result['itemid']] = $result['itemid'];                    
                }
			}
            $list = array_merge((array)getthreadsbytids($tidarray), (array)getblogbyid($blogidarray));
            $articlelist = array_merge((array)$list, (array)getarticlebyid($articleidarray));
		    krsort($articlelist);
            
            $multipage = multi($count, $tpp, $page, $tagurl);
        }
	}
		
	// description
	if(!empty($articlelist)){
		$temparr = reset($articlelist);
		$metadescription = $temparr['message'];
	}

	include_once template('onexin_tags:onexin_tagitem');

} else {
	$navtitle = $metakeywords = $metadescription = $taglang;
	$navtitle = helper_seo::get_title_page($taglang, $page);	
	
	$tagarray = array();	
	$tpp = empty($conf['showtags']) ? 200 : intval($conf['showtags']);
	$page = max(1, intval($page));
	$start_limit = ($page - 1) * $tpp;		
	$count = DB::result_first("SELECT count(*) FROM ".DB::table('common_tag')." WHERE status=0 ORDER BY tagid DESC");
	if($count) {
		$query = DB::query("SELECT tagid,tagname FROM ".DB::table('common_tag')." WHERE status=0 ORDER BY tagid DESC LIMIT $start_limit, $tpp");
		while($result = DB::fetch($query)) {
			$tagarray[] = $result;
		}
		$multipage = multi($count, $tpp, $page, "plugin.php?id=onexin_tags");
	}
	
	include_once template('onexin_tags:onexin_tag');
}

function getthreadsbytids($tidarray) {
	global $_G;

	$threadlist = array();
	if(!empty($tidarray)) {
		loadcache('forums');
		include_once libfile('function_misc', 'function');
		require_once libfile('function/home');
		$res = $classarr = array();
		$query = DB::fetch_all("SELECT * FROM ".DB::table('forum_threadimage')." WHERE tid IN (".dimplode($tidarray).")");
		foreach($query as $result){
			$images[$result['tid']] = ($result['remote'] ? $_G['setting']['ftp']['attachurl'] : $_G['setting']['attachurl']).'forum/'.$result['attachment'];
		}			
		$query = DB::fetch_all("SELECT tid,message FROM ".DB::table('forum_post')." WHERE first='1' AND tid IN (".dimplode($tidarray).") ORDER BY dateline DESC");
		foreach($query as $result){
			$result['message'] = preg_replace("/\[attach\]\d+\[\/attach\]/", '', $result['message']);
			$result['message'] = preg_replace("/\[img.*?\].*?\[\/img\]/", "", trim($result['message']));
			$result['message'] = preg_replace("/\[hide\].*?\[\/hide\]/s", '', $result['message']);
			$result['message'] = preg_replace("/\[.*?\]/", "", $result['message']);
			
			$post[$result['tid']]['message'] = $result['message'];			
		}
		$query = DB::fetch_all("SELECT * FROM ".DB::table('forum_thread')." WHERE displayorder>='0' AND tid IN (".dimplode($tidarray).") ORDER BY dateline DESC");
		//$query = C::t('forum_thread')->fetch_all_by_tid($tidarray);
		foreach($query as $result) {
						
			$res['blogid'] = $result['tid'];
			$res['type'] = 'thread';
			$res['username'] = $result['author'];
			$res['uid'] = $result['authorid'];
			$res['subject'] = $result['subject'];
			$res['message'] = getstr($post[$result['tid']]['message'], 300, 0, 0, 0, -1);
			$res['dateline'] = dgmdate($result['dateline']);
				if(@in_array('forum_viewthread', $_G['setting']['rewritestatus'])){
					$res['url'] = rewriteoutput('forum_viewthread', 1, '', $result['tid'], '', '');
					//$res['url'] = str_replace('_1.', '.', $res['url']);
				}else{
					$res['url'] = 'forum.php?mod=viewthread&tid='.$result['tid'];
				}
			
			if(!isset($_G['cache']['forums'][$result['fid']]['name'])) {
				$classarr[$result['fid']] = $result['tid'];
				$result['name'] = $classarr[$result['fid']]['name'];
			} else {
				$result['name'] = $_G['cache']['forums'][$result['fid']]['name'];
			}

			$res['classname'] = $result['name'];
			$res['classid'] = $result['fid'];
			$res['classurl'] = "forum.php?mod=forumdisplay&fid=$result[fid]";
			$res['pic'] = $images[$result['tid']] ? $images[$result['tid']] : "";
			$res['k'] = $result['dateline'].'_b_'.$result['tid'];
			//unset($result);
			$threadlist[$res['k']] = $res;//array_merge($res, procthread($result));;//
		}
//		if(!empty($classarr)) {
//			foreach(C::t('forum_forum')->fetch_all_by_fid(array_keys($classarr)) as $fid => $forum) {
//				$_G['cache']['forums'][$fid]['forumname'] = $forum['name'];
//				$threadlist[$classarr[$fid]]['forumname'] = $forum['name'];
//			}
//		}
	}
	return $threadlist;
}

function getblogbyid($blogidarray) {
	global $_G;

	$bloglist = array();
	if(!empty($blogidarray)) {
		$data_blog = C::t('home_blog')->fetch_all($blogidarray, 'dateline', 'DESC');
		$data_blogfield = C::t('home_blogfield')->fetch_all($blogidarray);

		require_once libfile('function/home');		
		$res = $classarr = array();
		foreach($data_blog as $curblogid => $result) {
			$result = array_merge($result, (array)$data_blogfield[$curblogid]);
			
			$res['blogid'] = $result['blogid'];
			$res['type'] = 'blog';
			$res['username'] = $result['username'];
			$res['uid'] = $result['uid'];
			$res['subject'] = $result['subject'];
			$res['message'] = $result['message'];
			$res['dateline'] = dgmdate($result['dateline']);
			$res['url'] = "home.php?mod=space&uid=$res[uid]&do=blog&id=$res[blogid]";
			
//			$query = C::t('home_class')->fetch_all_by_uid($result['uid']);
//			foreach($query as $value) {
//				$classarr[$value['classid']] = $value;
//			}
			
			$res['classname'] = $classarr[$result['classid']]['classname'];
			$res['classid'] = $result['classid'];
			$res['classurl'] = "home.php?mod=space&uid=$res[uid]&do=blog&classid=$res[classid]&view=me";
			
			if($result['friend'] == 4) {
				$result['message'] = $result['pic'] = '';
			} else {
				$result['message'] = getstr($result['message'], 300, 0, 0, 0, -1);
			}
			$res['message'] = preg_replace("/&[a-z]+\;/i", '', $result['message']);
			$res['pic'] = $result['pic'] ? pic_cover_get($result['pic'], $result['picflag']) : "";
			$res['k'] = $result['dateline'].'_c_'.$result['blogid'];			
			unset($result);
			$bloglist[$res['k']] = $res;
		}
	}
	return $bloglist;
}

function getarticlebyid($articleidarray) {
	global $_G;

	$articlelist = array();
	if(!empty($articleidarray)) {
		loadcache('portalcategory');
		$where = DB::field('aid', $articleidarray);
		$data_article = C::t('portal_article_title')->fetch_all_by_sql($where, ' ORDER BY dateline DESC');
		
		require_once libfile('function/home');
		$res = $classarr = array();
		foreach($data_article as $curarticleid => $result) {
			$res['blogid'] = $result['aid'];
			$res['type'] = 'article';
			$res['username'] = $result['username'];
			$res['uid'] = $result['uid'];
			$res['subject'] = $result['title'];
			$res['message'] = $result['summary'];
			$res['dateline'] = dgmdate($result['dateline']);
			$res['url'] = "portal.php?mod=view&aid=$res[blogid]";
			
			$res['classname'] = $_G['cache']['portalcategory'][$result['catid']]['catname'];
			$res['classid'] = $result['catid'];
			$res['classurl'] = $_G['cache']['portalcategory'][$result['catid']]['caturl'];
			
//			if($result['friend'] == 4) {
//				$result['message'] = $result['pic'] = '';
//			} else {
//				$result['message'] = getstr($result['message'], 300, 0, 0, 0, -1);
//			}
//			$res['message'] = preg_replace("/&[a-z]+\;/i", '', $result['message']);
			$res['pic'] = $result['pic'] ? pic_get($result['pic'], '', $result['thumb'], $result['remote'], 1, 1) : "";
			$res['k'] = $result['dateline'].'_a_'.$result['aid'];
			unset($result);
			$articlelist[$res['k']] = $res;
		}
	}
	return $articlelist;
}
