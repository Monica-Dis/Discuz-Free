<?php
/**
 * ONEXIN TAGS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_tags
 * @module	   onexin_tags
 * @date	   2019-11-19
 * @author	   dism-Taobao-com
 * @copyright  Copyright (c) 2019 Onexin Platform Inc. (http://www.onexin.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if(!$_G['setting']['headercharset']) {
	@header('Content-Type: text/html; charset='.CHARSET);
}
$_G['inajax'] = 1;
				
			// tag
			$tfidf_file = DISCUZ_ROOT . './source/plugin/onexin_tfidf/function_tfidf.php';
			$yourself_file = DISCUZ_ROOT . './source/plugin/onexin_autotag/'.$_G['cache']['plugin']['onexin_autotag']['engine'].'.engine.php';
			if($_G['cache']['plugin']['onexin_tfidf']['isopen'] && file_exists($tfidf_file)){
				# 自建标签引擎
				include $tfidf_file;
				$return = _onexin_tfidf_relatekw();
			}elseif($_G['cache']['plugin']['onexin_autotag']['isopen'] && file_exists($yourself_file)){
				# 自动标签插件
				include $yourself_file;
				$return = _onexin_autotag_relatekw();
			}else{
				# 默认百度搜索
				$return = _onexin_tags_relatekw();
			}
				

if($return) {
	showmessage($return, '', array(), array('msgtype' => 3, 'handle' => false));
} else {
	showmessage(' ', '', array(), array('msgtype' => 3, 'handle' => false));
}

//---------------------------------------------------------------------

function _onexin_tags_relatekw(){
	$_GET['subjectenc'] = strip_tags(str_replace(array('&nbsp;', '&', '#', '*', "\r", "\n"), array(), $_GET['subjectenc']));
	$keyword = cutstr(trim(strip_tags($_GET['subjectenc'])), 30, '');
	
	if(CHARSET != 'utf-8'){
		$keyword = diconv(trim($keyword), CHARSET, 'utf-8');
	}

//-----------------------------------------------	
	$url = 'https://www.baidu.com/s?wd='.urlencode($keyword);	
	$user_agent = 'Mozilla/5.0 (Windows NT 6.2; rv:16.0) Gecko/20100101 Firefox/16.0';
	$ch= curl_init($url);
	curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
	curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
	curl_setopt($ch, CURLOPT_HEADER, 0);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt($ch, CURLOPT_ENCODING, 'gzip');
	$contents = curl_exec($ch);   
	curl_close($ch);
	preg_match('/<div id="rs">.*?<table[^>]*>(.*?)<\/table>/is', $contents, $matchs);
	$contents = str_replace('</a>', ',', $matchs[1]);
	$contents = trim(strip_tags($contents), ',');
//-----------------------------------------------
	
	if(CHARSET != 'utf-8'){
		$contents = diconv(trim($contents), 'utf-8', CHARSET);
	}
	
	$return = str_replace(" ", ",", $contents);	
	return dhtmlspecialchars($return);	
}
