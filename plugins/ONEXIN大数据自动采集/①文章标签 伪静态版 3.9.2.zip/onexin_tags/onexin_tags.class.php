<?php
/**
 * ONEXIN TAGS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_tags
 * @module	   onexin_tags
 * @date	   2020-05-27
 * @author	   dism-Taobao-com
 * @copyright  Copyright (c) 2020 Onexin Platform Inc. (http://www.onexin.com)
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------
1,套餐    2,腾讯图片    3,选择服务器    4,新浪    5,网易

/misc.php?mod=tag&id=123
/misc.php?mod=tag&name=rcc    

/misc.php?mod=tag&id=144
/plugin.php?id=onexin_tags&tagid=195

*/

function _rewrite_callback_tag($matches1, $matches4 = '', $s = '', $matches6 = '') {
	global $_G;
	if(empty($s)){
		return "\"{$matches1}{$_G['cache']['plugin']['onexin_tags']['suffix']}\"";	
	}else{	
		return "\"{$matches1}{$s}{$matches4}".($matches6 ? "{$s}{$matches6}" : "")."{$_G['cache']['plugin']['onexin_tags']['suffix']}\"";
	}
}

class plugin_onexin_tags {

	protected static $conf = array();

	public function __construct() {
		global $_G;
		
		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		if($_G['cache']['plugin']['onexin_tags']['isopen']){
			self::$conf = $_G['cache']['plugin']['onexin_tags'];
		}		
	}	
	
	public function global_header() {
		global $_G;
		
		if(!self::$conf['isopen'] || !self::$conf['isrewrite']) return '';		
			
		$_G['setting']['output']['preg']['search']['tags_11'] = "/\"misc\.php\?mod\=(tag)&(amp;)?(id)\=(\d+)\"/";
		$_G['setting']['output']['preg']['replace']['tags_11'] = "_rewrite_callback_tag(\"\$matches[1]\", \"\$matches[4]\", \"-\")";
        
		$_G['setting']['output']['preg']['search']['tags_12'] = "/\"misc\.php\?mod\=(tag)&(amp;)?(name)\=([^\"\.]+)\"/";
		$_G['setting']['output']['preg']['replace']['tags_12'] = "_rewrite_callback_tag(\"\$matches[1]\", \"\$matches[4]\", \"/\")";
        
		$_G['setting']['output']['preg']['search']['tags_10'] = "/\"misc\.php\?mod\=(tag)\"/";
		$_G['setting']['output']['preg']['replace']['tags_10'] = "_rewrite_callback_tag(\"\$matches[1]\")";
        		
		$_G['setting']['output']['preg']['search']['tags_61'] = "/\"plugin\.php\?id\=onexin_(tag)s&(amp;)?tag(id)\=(\d+)(&(amp;)?page\=(\d+))?\"/";
		$_G['setting']['output']['preg']['replace']['tags_61'] = "_rewrite_callback_tag(\"\$matches[1]\", \"\$matches[4]\", \"-\", \"\$matches[7]\")";
        
		$_G['setting']['output']['preg']['search']['tags_62'] = "/\"plugin\.php\?id\=onexin_(tag)s&(amp;)?tag(name)\=([^&\"\.]+)(&(amp;)?page\=(\d+))?\"/";
		$_G['setting']['output']['preg']['replace']['tags_62'] = "_rewrite_callback_tag(\"\$matches[1]\", \"\$matches[4]\", \"/\", \"\$matches[7]\")";
        		
		$_G['setting']['output']['preg']['search']['tags_0_page'] = "/\"plugin\.php\?id\=onexin_(tag)s&(amp;)?page\=(\d+)\"/";
		$_G['setting']['output']['preg']['replace']['tags_0_page'] = "_rewrite_callback_tag(\"\$matches[1]\", \"\$matches[3]\", \"_\")";
        
		$_G['setting']['output']['preg']['search']['tags_0'] = "/\"plugin\.php\?id\=onexin_(tag)s\"/";
		$_G['setting']['output']['preg']['replace']['tags_0'] = "_rewrite_callback_tag(\"\$matches[1]\")";
		
	}
	
	public function add_tag($tags, $itemid, $idtype = 'tid', $returnarray = 0) {
		// || !in_array($idtype, array('', 'tid', 'blogid', 'uid')
		if($tags == '') return;

		$langcore = lang('core');
		$tags = str_replace('ffffff', '', $tags);
		$tags = str_replace(array(chr(0xa3).chr(0xac), chr(0xa1).chr(0x41), chr(0xef).chr(0xbc).chr(0x8c),
				$langcore['fullblankspace'], ','), ' ', censor($tags));
		$tagarray = array_unique(explode(' ', $tags));
				
		// 数据库找出旧TAG 如果新TAG中不包括 则删除关系
		$tagarrayold = $tagidarray = array();
		$results = C::t('common_tagitem')->select(0, $itemid, $idtype);
		foreach($results as $result) {
			$tagidarray[] = $result['tagid'];
		}
		
		if($tagidarray) {
			$results = C::t('common_tag')->get_byids($tagidarray);
			foreach($results as $result) {
				if(!in_array($result['tagname'], $tagarray)) {
					$tagarrayold[$result['tagid']] = $result['tagid'];
				}
			}			
			C::t('common_tagitem')->delete($tagarrayold, $itemid, $idtype);
		}
		
		$tagcount = 0;
		foreach($tagarray as $tagname) {
			$tagname = trim($tagname);
			//if(preg_match('/^([\x7f-\xff_-]|\w|\s){3,100}$/', $tagname)) {
				$status = $idtype != 'uid' ? 0 : 3;
				$result = C::t('common_tag')->get_bytagname($tagname, $idtype);
				if($result['tagid']) {
					if($result['status'] == $status) {
						$tagid = $result['tagid'];
					}
				} else {
					$tagid = C::t('common_tag')->insert($tagname,$status);
				}
				if($tagid) {
					if($itemid) {
						C::t('common_tagitem')->replace($tagid,$itemid,$idtype);
					}
					$tagcount++;
					if(!$returnarray) {
						$return .= $tagid.','.$tagname."\t";
					} else {
						$return[$tagid] = $tagname;
					}

				}
				if($tagcount >= self::$conf['tagcount']) {
					unset($tagarray);
					break;
				}
			//}
		}
		
		return $return;
	}
	
	public function get_tag($tags, $itemid = 0){
		global $_G;
		$tagarray = $tagarray_data = array();
		foreach($tags as $key => $var) {
			if($var) {
				$array_temp = is_string($var) ? explode(',', $var) : $var;
				$tagarray[$array_temp['0']] = $array_temp['1'];
				$tagarray_data[$key]['tagid'] = $array_temp['0'];
				$tagarray_data[$key]['tagname'] = $array_temp['1'];
			}
		}
		return array($tagarray_data, implode(',', $tagarray), implode(' ', $tagarray));		
	}
	
	// get tags
	public function get($idtype, $itemid = 0){
		global $_G;
		
		if(!self::$conf['isopen']) return '';
		
		$tagstring = DB::result_first("SELECT tags FROM ".DB::table('plugin_onexin_tags')." WHERE itemid='$itemid' AND idtype = '$idtype'");
		
		$tags = explode("\t", $tagstring);
		
		return self::get_tag($tags);
	}
	
	// set tags
	public function set($tags, $idtype, $itemid = 0){
		global $_G;
		
		if(!self::$conf['isopen']) return '';
				
		$tags = self::add_tag($tags, $itemid, $idtype, 0);
		if($tags == '') return;
		
		$tagid = DB::result_first("SELECT tagid FROM ".DB::table('plugin_onexin_tags')." WHERE itemid='$itemid' AND idtype = '$idtype'");		
		if($tagid > 0) {
			DB::query("UPDATE ".DB::table('plugin_onexin_tags')." SET tags = '$tags', idtype = '$idtype' WHERE tagid='$tagid'");			
		}else{
			DB::query("INSERT INTO ".DB::table('plugin_onexin_tags')." (tags, idtype, itemid) VALUES ('$tags', '$idtype', '$itemid')");
		}
		
		return "";	
	}
	
}

// portal
class plugin_onexin_tags_portal extends plugin_onexin_tags  {
	
	public function portalcp_bottom_output(){
		global $_G;
		
		if(!self::$conf['isopen']) return '';
		
		$aid = !empty($_GET['aid']) ? intval($_GET['aid']) : '0';
		$tagarraydata = !empty($_GET['aid']) ? self::get('articleid', $aid) : array();
		$itags = $tagarraydata[2];
		include template('onexin_tags:itags_article');
		return $return;
	}
	
	public function portalcp_article_tags_aftersubmit_output(){
		global $_G;
		
		if(!self::$conf['isopen']) return '';
		
		if( $_G['uid'] && submitcheck('articlesubmit') && !empty($_POST['itags']) ){
			$aid = isset($GLOBALS['aid']) ? $GLOBALS['aid'] : 0;
			$aid = (int)(!empty($_POST['aid']) ? $_POST['aid'] : $aid);
			$result = DB::fetch_first("SELECT aid,uid FROM ".DB::table('portal_article_title')." WHERE aid='$aid'");
			if($_G['uid'] == $result['uid'] || $_G['groupid']=='1'){
				if($result['aid']) self::set($_POST['itags'], 'articleid', $result['aid']);
			}
		}
		return '';
	}
	
	public function view_article_summary_output() {
		global $_G, $metakeywords;
		
		if(!self::$conf['isopen'] || self::$conf['position'] != '21') return array();
		
		$aid = !empty($_GET['aid']) ? intval($_GET['aid']) : '0';
		$tagarraydata = !empty($_GET['aid']) ? self::get('articleid', $aid) : array();
		$tagarray = $tagarraydata[0];
		if(self::$conf['ismeta']) $metakeywords = (!empty($tagarraydata[1]) ? $tagarraydata[1].',' : "").$metakeywords;
		include template('onexin_tags:itags');
		return $return;
	}	
	
	public function view_article_content_output() {
		global $_G, $metakeywords, $article, $content;
		
		if(!self::$conf['isopen'] || '22' != self::$conf['position'] ) return array();
		
		$aid = !empty($_GET['aid']) ? intval($_GET['aid']) : '0';
		$tagarraydata = !empty($_GET['aid']) ? self::get('articleid', $aid) : array();
		$tagarray = $tagarraydata[0];
		
		if(empty($tagarraydata[1]) && $_G['cache']['plugin']['onexin_autotag']['isportal']){
		// day check
		if(TIMESTAMP - intval($_G['cache']['plugin']['onexin_autotag']['day'])*24*3600 < $content['dateline']) {
			// do something...	need tags.
			
					$itemid = $article['aid'];
					$idtype = 'articleid';// tid blogid articleid
	
			$value = DB::fetch_first("SELECT tagid,tags FROM ".DB::table('plugin_onexin_tags')." WHERE itemid='$itemid' AND idtype = '$idtype'");	
			$tagid = $value['tagid'];	
		
			if(empty($value['tags'])) { //
			
				$_GET['subjectenc'] = $article['title'];
				$plus = '';
				$count = $_G['cache']['plugin']['onexin_autotag']['num'] > 10 ? 10 : $_G['cache']['plugin']['onexin_autotag']['num'];
				for($i=1;$i<$count;$i++){
					$plus .= $_GET['subjectenc'];
				}
				$_GET['messageenc'] = $plus.strip_tags($content['content']);
				
				// tag
				$yourself_file = DISCUZ_ROOT . './source/plugin/onexin_autotag/'.$_G['cache']['plugin']['onexin_autotag']['engine'].'.engine.php';
				if(file_exists($yourself_file)){
					include_once $yourself_file;
				}else{
					include_once DISCUZ_ROOT . './source/plugin/onexin_autotag/auto.engine.php';
				}
				
				$tags = _onexin_autotag_relatekw();
				if(empty($tags)) $tags = $_G['cache']['plugin']['onexin_autotag']['name'];
				$tags = _onexin_autotag_forum($tags, $itemid, $idtype, 0, $_G['cache']['plugin']['onexin_autotag']['tagcount']);
			
				if($tagid > 0) {
					DB::query("UPDATE ".DB::table('plugin_onexin_tags')." SET tags = '".addslashes($tags)."', idtype = '$idtype' WHERE tagid='$tagid'");			
				}else{
					DB::query("INSERT INTO ".DB::table('plugin_onexin_tags')." (tags, idtype, itemid) VALUES ('".addslashes($tags)."', '$idtype', '$itemid')");
				}
												
			}
		}						
		}
			
		if(self::$conf['ismeta']) $metakeywords = (!empty($tagarraydata[1]) ? $tagarraydata[1].',' : "").$metakeywords;
		include template('onexin_tags:itags');
		return $return;
	}		
	
}

// forum
class plugin_onexin_tags_forum extends plugin_onexin_tags {

	public function post_bottom_output() {
		global $_G;
		
		if(!self::$conf['isopen']) return '';
		
		include template('onexin_tags:itags_thread');		
		
		return $return;
	}
	
	public function viewthread_title_extra_output() {
		global $_G, $metakeywords;
		
		if(!self::$conf['isopen'] || !self::$conf['ismeta']) return '';
		$tagarraydata = self::get_tag($GLOBALS['posttag_array']);
		$metakeywords = (!empty($tagarraydata[1]) ? $tagarraydata[1].',' : "").$metakeywords;
		
		return '';		
	}

}
