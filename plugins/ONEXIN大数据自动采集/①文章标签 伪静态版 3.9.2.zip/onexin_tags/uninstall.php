<?php
/**
 * ONEXIN TAGS For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_tags
 * @module	   onexin_tags
 * @date	   2014-05-06
 * @author	   dism-Taobao-com
 * @copyright  Copyright (c) 2014 Onexin Platform Inc. (http://www.onexin.com)
 */
 
if(!defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE pre_plugin_onexin_tags;
EOF;

runquery($sql);

$finish = true;
