<?php
/**
 * ONEXIN HTML5 PLAYER For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_html5player
 * @module	   html5player 
 * @date	   2020-03-30
 * @author	   by dism.taobao.com
 * @copyright  资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */
 
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


require_once DISCUZ_ROOT . './source/plugin/onexin_html5player/function_html5player.php';

/*
//--------------Tall us what you think!----------------------------------
*/

class plugin_onexin_html5player {

	protected static $conf = array();
	protected static $isopen = FALSE;

	public function __construct() {
		global $_G;
		
		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		self::$isopen = $_G['cache']['plugin']['onexin_html5player']['isopen'] ? TRUE : FALSE;
		if(self::$isopen){
			self::$conf = $_G['cache']['plugin']['onexin_html5player'];
			self::$conf['usefids'] = (array)unserialize(self::$conf['usefids']);
			if(empty(self::$conf['usefids'][0]) || in_array($_G['fid'], self::$conf['usefids'])){
				self::$conf['isfid'] = TRUE;
			}
		}
	}
    
	public function global_header(){
		global $_G;
				
		if(!self::$conf['isopen'] || !in_array(CURMODULE, array('space', 'view', 'viewthread'))) return '';
		return self::$conf['html5code'];
	}
	
	public function discuzcode() {
		global $_G;
		
		if(!self::$conf['isopen'] || !self::$conf['isfid']) return '';
		
		$_G['discuzcodemessage'] = _onexin_html5player_tips($_G['discuzcodemessage'], $_G['cache']['plugin']['onexin_html5player']['video']);		
		
	}

}

// forum
class plugin_onexin_html5player_forum extends plugin_onexin_html5player {
	
	public function viewthread_onexin_html5player_output() {
		global $_G, $postlist;
		
		if(!self::$conf['isopen'] || !self::$conf['isfid']) return '';
		
			foreach($postlist as $pid => $value) {
				//$postlist[$pid]['message'] = _onexin_html5player_tips($postlist[$pid]['message'], $_G['cache']['plugin']['onexin_html5player']['video']);
			}

		return '';
	}	
	
}

// portal
class plugin_onexin_html5player_portal extends plugin_onexin_html5player {
	
	public function view_article_content_output() {
		global $_G, $content;
		
		if(!self::$conf['isopen']) return '';
		
		$content['content'] = preg_replace("/<span id=\"swf_.*?, 'src', encodeURI\('(.*?)'\).*?<\/script>/i", "[video]\\1[/video]", $content['content']); 
		$content['content'] = _onexin_html5player_tips($content['content'], $_G['cache']['plugin']['onexin_html5player']['video']);	
						
		return '';
	}	
	
}

// home
class plugin_onexin_html5player_home extends plugin_onexin_html5player {
	
	public function space_blog_title_output() {
		global $_G, $blog;
		
		if(!self::$conf['isopen']) return '';
		
		$blog['message'] = preg_replace("/<span id=\"swf_.*?, 'src', encodeURI\('(.*?)'\).*?<\/script>/i", "[video]\\1[/video]", $blog['message']); 
		$blog['message'] = _onexin_html5player_tips($blog['message'], $_G['cache']['plugin']['onexin_html5player']['video']);	
						
		return '';
	}	
	
}


