<?php
/**
 * ONEXIN README For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_readme
 * @module	   readme 
 * @date	   2019-12-27
 * @author	   by dism.taobao.com
 * @copyright  如果侵犯了您的权益,请及时告知我们,我们即刻删除!
 */

/*
//--------------Tall us what you think!----------------------------------
*/

//
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$url = 'https://dism.taobao.com/?@onexin';

if(!empty($plugin['identifier'])){
	$url = 'https://dism.taobao.com/?@'.$plugin['identifier'].'.plugin.doc/faq';
}

dheader("location: ".$url);