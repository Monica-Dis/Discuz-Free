<?php
/**
 * ONEXIN HTML5 PLAYER For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_html5player
 * @module     html5player 
 * @date       2020-02-30
 * @author     King
 * @copyright  资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*
//--------------Tall us what you think!----------------------------------

告别FLASH，拥抱HTML5，MP4，M3U8
*/

function _onexin_html5player($html, $vtag = 'html5video') {
	global $_G;
	$search = $replace = array();
	
	$tag = 'video';
	$openapi = $_G['siteurl'].'source/plugin/onexin_html5player/open/';
    $html5mp4 = $_G['cache']['plugin']['onexin_html5player']['html5mp4'];
    $html5m3u8 = $_G['cache']['plugin']['onexin_html5player']['html5m3u8'];
    if(preg_match("/\*/", $_G['cache']['plugin']['onexin_html5player']['safedomain'])) {
        $safedomain = ".*?";
    }else{
        $safedomain = str_replace("\n", "|", trim($_G['cache']['plugin']['onexin_html5player']['safedomain']));        
    }
	$search[] = "/\[html5video\]\s*([^\[\<\r\n]+?)\s*\[\/html5video\]/i";
	$replace[] = "[".$tag."]\\1[/".$tag."]";
	$search[] = "/\[".$vtag."(=(.*?))?\]\s*([^\[\<\r\n]+?)\s*\[\/".$vtag."\]/i";
	$replace[] = "[".$tag."]\\3[/".$tag."]";
		
	$tag_s = "\[".$tag."\]";
	$tag_e = ".*?\[\/".$tag."\]";//[&|\?]?
//	$video_s = '<video class="html5video video-js" src="';
//	$video_e = '" controls="" preload="auto" poster=""></video>';
       
	$iframe_s = '<iframe class="html5video" src="';
	$iframe_e = '" frameborder="0" scrolling="no" allowfullscreen></iframe>';
	$video_s = $iframe_s.$openapi.$html5mp4.'/html5player.html?mp4=';
	$video_e = $iframe_e; 
	
		$search[] = "/\[media(=([\w,]+))?\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i";
		$replace[] = "[".$tag."]\\3[/".$tag."]";
		if($_G['cache']['plugin']['onexin_html5player']['flashconvert']) {
			$search[] = "/\[flash(=(\w+|\d+,\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/i";
			$replace[] = "[".$tag."]\\3[/".$tag."]";
		}
		
		$search[] = "/\[".$tag."\]\s*([^\[\<\r\n]+?\.mp4.*?)\s*\[\/".$tag."\]/i";
		$replace[] = $video_s."\\1".$video_e;
		$search[] = "/\[".$tag."\]\s*([^\[\<\r\n]+?\.m3u8.*?)\s*\[\/".$tag."\]/i";
		$replace[] = $iframe_s.$openapi.$html5m3u8.'/html5player.html?m3u8='."\\1".$iframe_e;
    
	// video	---------------------- 
    
	// miaopai
	$search[] = "/".$tag_s."https?:\/\/www.miaopai.com\/show\/([^\/]+)\.htm".$tag_e."/i";
	$replace[] = $video_s.'https://gslb.miaopai.com/stream/\\1.mp4'.$video_e;
	
	// sina
	$search[] = "/".$tag_s."https?:\/\/video.sina.com.cn\/share\/video\/\d+\.swf.*?ipad_vid=([^\/&]+)".$tag_e."/i";
	$replace[] = $video_s.'https://ask.ivideo.sina.com.cn/v_play_ipad.php?vid=\\1&tags=h5_jsplay'.$video_e;	
	
	// iframe	----------------------
    
	// youtube
	$search[] = "/".$tag_s."https?:\/\/youtu.be\/([^\/&]+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://www.youtube.com/embed/\\1'.$iframe_e;	
	$search[] = "/".$tag_s."https?:\/\/www.youtube.com\/v\/([^\/&]+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://www.youtube.com/embed/\\1'.$iframe_e;	
	$search[] = "/".$tag_s."https?:\/\/www.youtube.com\/.*?[\?|&amp;]v=([^\/&]+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://www.youtube.com/embed/\\1'.$iframe_e;	
	$search[] = "/".$tag_s."https?:\/\/www.youtube.com\/embed\/([^\/&]+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://www.youtube.com/embed/\\1'.$iframe_e;	
    
	// vimeo 
	$search[] = "/".$tag_s."https?:\/\/vimeo.com\/(\d+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://player.vimeo.com/video/\\1?autoplay=0'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/player.vimeo.com\/video\/(\d+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://player.vimeo.com/video/\\1?autoplay=0'.$iframe_e;
	
	// acfun
	$search[] = "/".$tag_s."https?:\/\/www.acfun.cn\/v\/(\w+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://www.acfun.cn/player/\\1?autoplay=0'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/m.acfun.cn\/v\/\?ac=(\d+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://www.acfun.cn/player/ac\\1?autoplay=0'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/www.aixifan.com\/v\/(\w+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://www.acfun.cn/player/\\1?autoplay=0'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/cdn.aixifan.com\/player\/[^\?]+\.swf\?vid=(\d+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://www.acfun.cn/player/ac\\1?autoplay=0'.$iframe_e;
	
	// tudou
	$search[] = "/\[".$tag."\](https?:\/\/www.tudou.com\/.*?)\[\/".$tag."\]/i";
	$replace[] = '\\1';
	//$search[] = "/".$tag_s."http:\/\/www.tudou.com\/programs\/view\/([^\/\?]+)\/".$tag_e."/i";
	//$replace[] = $iframe_s.'http://www.tudou.com/programs/view/html5embed.action?type=0&code=\\1&lcode=&resourceId=119693922_06_05_99'.$iframe_e;
	//$search[] = "/".$tag_s."http:\/\/www.tudou.com\/(listplay|albumplay)\/([^\/]+)\/([^\/\?\.]+)".$tag_e."/i";
	//$replace[] = $iframe_s.'http://www.tudou.com/programs/view/html5embed.action?type=0&code=\\3&lcode=\\2&resourceId=119693922_06_05_99'.$iframe_e;
	//$search[] = "/".$tag_s."http:\/\/www.tudou.com\/[v|a]\/([^\/]+)\/([^\/]+)\/v.swf".$tag_e."/i";
	//$replace[] = $iframe_s.'http://www.tudou.com/programs/view/html5embed.action?type=0&code=\\1&lcode=\\2'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/video.tudou.com\/v\/([^\/]+).html".$tag_e."/i";
	//$replace[] = $iframe_s.'https://player.youku.com/embed/\\1?autoplay=false'.$iframe_e;	
	$replace[] = $iframe_s.$openapi.'youku/html5player.html?vid=\\1&autoplay=false'.$iframe_e;	
	
	// youku
	//$openapi_youku = $openapi.'youku/html5player.html?vid=';
	$search[] = "/".$tag_s."https?:\/\/v.youku.com\/v_show\/id_([^\[\.\/\?]+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'youku/html5player.html?vid=\\1&autoplay=false'.$iframe_e;	
	$search[] = "/".$tag_s."https?:\/\/player.youku.com\/player.*?\/sid\/([^\/]+)\/v.swf".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'youku/html5player.html?vid=\\1&autoplay=false'.$iframe_e;	
	$search[] = "/".$tag_s."https?:\/\/player.youku.com\/embed\/([^\[\.\/\?]+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'youku/html5player.html?vid=\\1&autoplay=false'.$iframe_e;	
	//$replace[] = $iframe_s.'https://player.youku.com/embed/\\1?autoplay=false'.$iframe_e;	
	
	// qq
	//$openapi_qq = 'https://v.qq.com/txp/iframe/player.html';
	$openapi_qq = $openapi.'qq/html5player.html';
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.qq.com\/x\/.*?\/(\w+)\.html".$tag_e."/i";
	$replace[] = $iframe_s.$openapi_qq.'?vid=\\1&auto=0'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.qq.com\/.*?vid=(\w+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi_qq.'?vid=\\1&auto=0'.$iframe_e;
	//$replace[] = $iframe_s.'https://v.qq.com/iframe/player.html?vid=\\1&auto=0'.$iframe_e;
    
	// qcloud 
	$search[] = "/".$tag_s."https?:\/\/[^\/]+video.qcloud.com\/.*?\?([^\[]+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'qcloud/html5player.html?\\1'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.qq.com\/open\/qcloud\/.*?\?([^\[]+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'qcloud/html5player.html?\\1'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.myqcloud.com\/vod-player\/(\d+)\/(\d+)\/".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'qcloud/html5player.html?appid=\\1&fileid=\\2&autoplay=0'.$iframe_e;
	
	// SOHU
	$search[] = "/".$tag_s."https?:\/\/share.vrs.sohu.com\/(\d+)\/v.swf".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'sohu/html5player.html#\\1'.$iframe_e;//vid
	$search[] = "/".$tag_s."https?:\/\/share.vrs.sohu.com\/my\/v.swf.*?id=(\d+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'sohu/html5player.html#\\1'.$iframe_e;//bid
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.tv.sohu.com\/(pl|us)\/\d+\/(\d+).shtml".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'sohu/html5player.html#\\2'.$iframe_e;//bid
	$search[] = "/".$tag_s."https?:\/\/tv.sohu.com\/[^\[]+share_play.html#(\d+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'sohu/html5player.html#\\1'.$iframe_e;//vid || bid
	
	// iqiyi
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.iqiyi.com\/.*?vid=([^\/\"\[]+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://m.iqiyi.com/openplay.html?vid=\\1'.$iframe_e;
	
	// douyu 
	$search[] = "/".$tag_s."https?:\/\/v.douyu.com\/show\/(\w+)".$tag_e."/i";
	$replace[] = $iframe_s.'https://v.douyu.com/video/share/index?vid=\\1'.$iframe_e;
	
	// bilibili
	/*
	https://www.bilibili.com/video/BV1ox411i7Hz?p=2
	https://www.bilibili.com/bangumi/play/ep316919   --- no
	*/
	$openapi_bl = $openapi.'bilibili/html5player.html';
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.bilibili.com\/video\/(BV\w+)(\?p=(\d+))?".$tag_e."/i";
	$replace[] = $iframe_s.$openapi_bl.'?bvid=\\1&page=\\3'.$iframe_e; 
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.bilibili.com\/video\/av(\d+)\/\?p=(\d+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi_bl.'?aid=\\1&page=\\2'.$iframe_e; 
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.bilibili.com\/video\/av(\d+)\/.*?#page=(\d+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi_bl.'?aid=\\1&page=\\2'.$iframe_e; 
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.bilibili.com\/video\/av(\d+)(\/index_(\d+).html)?".$tag_e."/i";
	$replace[] = $iframe_s.$openapi_bl.'?aid=\\1&page=\\3'.$iframe_e; 
	$search[] = "/".$tag_s."https?:\/\/static.hdslb.com\/\w+\.swf\?([^\/\"\[]+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi_bl.'?\\1'.$iframe_e; 
	$search[] = "/".$tag_s."https?:\/\/share.acg.tv\/\w+\.swf\?([^\/\"\[]+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi_bl.'?\\1'.$iframe_e; 
	$search[] = "/".$tag_s."https?:\/\/[^\/]+.bilibili.com\/blackboard\/html5player.html\?([^\/\"\[]+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi_bl.'?\\1'.$iframe_e; 
	
	// leyuntv 
	$search[] = "/".$tag_s."https?:\/\/yuntv.letv.com\/bcloud.html\?uu=([^\/\"\[]+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'yuntv/html5player.html?uu=\\1'.$iframe_e;
	
	// letv
	$search[] = "/".$tag_s."https?:\/\/[^\/]*.le.com\/player\/swfPlayer.swf.*?id=([^\/&]+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'le/html5player.html?vid=\\1&isPlayerAd=0&autoplay=0'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/www.le.com\/ptv\/vplay\/(\d+)\.html".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'le/html5player.html?vid=\\1&isPlayerAd=0&autoplay=0'.$iframe_e;
	
	// cntv
	$search[] = "/".$tag_s."https?:\/\/[^\/]*.cntv.cn\/.*?videoCenterId=(\w+.*?)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'cntv/html5player.html?videoCenterId=\\1'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/[^\/]*.cctv.com\/.*?(VIDE\w+.*?)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'cntv/html5player.html?videoId=\\1'.$iframe_e;
	$search[] = "/".$tag_s."https?:\/\/[^\/]*.cctv.com\/.*?videoCenterId=(\w+)".$tag_e."/i";
	$replace[] = $iframe_s.$openapi.'cntv/html5player.html?videoCenterId=\\1'.$iframe_e;
    
        if(!empty($_G['cache']['plugin']['onexin_html5player']['html5api'])){
    	    $iframe_s_api = '<script>document.write(\'<iframe class="html5video" src="'.$_G['cache']['plugin']['onexin_html5player']['html5api'].'\'+ encodeURIComponent("';
		    $iframe_e_api = '") + \'" frameborder="0" scrolling="no" allowfullscreen></iframe>\')</script>';  
            $search[] = "/\[".$tag."\](https?:\/\/[^\/]+\.($safedomain)\/.*?)\[\/".$tag."\]/i";
            $replace[] = $iframe_s_api.'\\1'.$iframe_e_api;    
        }
    
        if(!empty($_G['cache']['plugin']['onexin_html5player']['safedomain'])){
            $search[] = "/\[".$tag."\](https?:\/\/[^\/]+\.($safedomain)\/.*?)\[\/".$tag."\]/i";
            $replace[] = $iframe_s.'\\1'.$iframe_e;    
        }
    
	// Fix
	$search[] = "/\[".$tag."\]\s*([^\[\<\r\n]+?\.swf.*?)\s*\[\/".$tag."\]/i";
	$replace[] = '[flash]\\1[/flash]';
	$search[] = "/<!--html5player-->.*?<!--\/html5player-->/is";
	$replace[] = "";
	$search[] = "/\[".$tag."\]\s*([^\[\<\r\n]+?.*?)\s*\[\/".$tag."\]/i";
	$replace[] = '\\1';
			    
	$html = preg_replace($search, $replace, $html);	
	
	return $html;
}

function _onexin_html5player_tips($html, $vtag = 'html5video') {
	global $_G;
	
		$conf = $_G['cache']['plugin']['onexin_html5player'];
		$conf['usergroups'] = (array)unserialize($conf['usergroups']);
		$conf['isgroupid'] = FALSE;
		if(empty($conf['usergroups'][0]) || in_array($_G['groupid'], $conf['usergroups'])){
			$conf['isgroupid'] = TRUE;
		}
			
		if($conf['isgroupid']) {	
			return _onexin_html5player($html, $vtag);
		}
	
	
	$search = $replace = array();	
	$tag = 'video';	
    $html5tips = $_G['cache']['plugin']['onexin_html5player']['html5tips'];

	$search[] = "/\[html5video\]\s*([^\[\<\r\n]+?)\s*\[\/html5video\]/i";
	$replace[] = "[".$tag."]\\1[/".$tag."]";
	$search[] = "/\[".$vtag."(=(.*?))?\]\s*([^\[\<\r\n]+?)\s*\[\/".$vtag."\]/i";
	$replace[] = "[".$tag."]\\3[/".$tag."]";
	
		$search[] = "/\[media(=([\w,]+))?\]\s*([^\[\<\r\n]+?)\s*\[\/media\]/i";
		$replace[] = "[".$tag."]\\3[/".$tag."]";
		if($_G['cache']['plugin']['onexin_html5player']['flashconvert']) {
			$search[] = "/\[flash(=(\w+|\d+,\d+))?\]\s*([^\[\<\r\n]+?)\s*\[\/flash\]/i";
			$replace[] = "[".$tag."]\\3[/".$tag."]";
		}
    
	// Fix
//	$search[] = "/\[".$tag."\]\s*([^\[\<\r\n]+?\.swf.*?)\s*\[\/".$tag."\]/i";
//	$replace[] = '[flash]\\1[/flash]';
	$search[] = "/<!--html5player-->.*?<!--\/html5player-->/is";
	$replace[] = "";
	$search[] = "/\[".$tag."\]\s*([^\[\<\r\n]+?.*?)\s*\[\/".$tag."\]/i";
	$replace[] = "$html5tips";
			    
	$html = preg_replace($search, $replace, $html);	
	
	return $html;
}
		