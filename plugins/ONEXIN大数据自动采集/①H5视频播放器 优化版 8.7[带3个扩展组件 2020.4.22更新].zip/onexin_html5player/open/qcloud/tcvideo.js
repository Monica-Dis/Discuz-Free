!function (e, t) {
    if ("object" == typeof exports && "object" == typeof module) module.exports = t();
    else if ("function" == typeof define && define.amd) define([], t);
    else {
        var n = t();
        for (var i in n)("object" == typeof exports ? exports : e)[i] = n[i]
    }
}(this, function () {
    return function (e) {
        function t(i) {
            if (n[i]) return n[i].exports;
            var o = n[i] = {
                exports: {},
                id: i,
                loaded: !1
            };
            return e[i].call(o.exports, o, o.exports, t), o.loaded = !0, o.exports
        }
        var n = {};
        return t.m = e, t.c = n, t.p = "//imgcache.qq.com/open/qcloud/video/vcplayer/", t(0)
    }([function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        n(1);
        var r = n(2),
            s = o(r),
            a = n(5),
            l = i(a),
            u = n(6);
        e.exports.$ = s.
    default;
        var c = new Date,
            p = ["tcplayer-", c.getTime()].join(""),
            d = "",
            f = {},
            h = !1,
            y = !1,
            v = ["tcvideo", c.getTime()].join(""),
            m = ["//res.wx.qq.com/open/js/jweixin-1.0.0.js?t=", (new Date).getDay()].join(""),
            g = ["//www.qcloud.com/weixin/jsapi.js?debug&t=", (new Date).getDay()].join("");
        window[v] = {};
        var b = function () {
            var e = [],
                t = {
                    11: /(MSIE)\s.+rv:(\d+)?/i,
                    other: /(msie)\s(\d+)/i
                };
            if (l.IS_IE) for (var n in t) if (e = navigator.userAgent.match(t[n]), null !== e) return [e[1], parseInt(e[2])];
            if (l.IS_SAFARI) return e = navigator.userAgent.match(/(safari)\/([\d.]+)/i), e ? [e[1], parseInt(e[2])] : ["other", 0];
            var i = /(Chrome|MSIE|Firefox)[\/ ]?([\d]+)/;
            return e = navigator.userAgent.match(i), e ? [e[1], parseInt(e[2])] : ["other", 0]
        }();
        s.
    default.fn.tcplayer = function (e) {
            var t = this;
            void 0 === this.attr("id") ? (console.log(this.attr("id")), d = p, this.attr("id", p)) : d = this.attr("id");
            var n = 0,
                i = "",
                o = 0,
                r = "",
                s = {};
            t.player = {}, t.ready = !1, f = w(), "MSIE" === b[0] && b[1] <= 9 && (f.flash = !0);
            var a = "为了更好的播放体验，建议您把浏览器升级到最新版本!";
            "chrome" === b[0].toLowerCase() && Number(b[1]) <= 50 && (_.show(a), f.flash = !0), "firefox" === b[0].toLowerCase() && Number(b[1]) <= 40 && (_.show(a), f.flash = !0), this.css("height", [f.height, "px"].join("")), this.css("width", [f.width, "px"].join("")), f.live === !0 ? (n = k("bizid"), i = k("streamid"), s = M(n, i, "m3u8", f.live)) : (o = k("appid"), r = k("fileid"), 
			s = E(o, r, f, function (e) { S(e, t) })), 
			O()			
        };
        var w = function () {
            h = 1 === parseInt(k("loop")), y = 1 === parseInt(k("coverpic_error"));
            var e = {
                owner: d,
                width: k("sw"),
                height: k("sh"),
                live: !! k("live"),
                flash: 1 === k("flash") || "true" === k("flash"),
                h5_flv: 1 === k("h5_flv") || "true" === k("h5_flv"),
                clarity: ["od", "hd", "sd"].indexOf(k("clarity")) >= 0 ? k("clarity") : "sd",
                url: k("url") || !1,
                type: k("type") || !1,
                hls: k("hls") || "0.7.1",
                showLoading: k("showLoading") || !1,
                fuScrnEnabled: "false" !== k("fuScrnEnabled") && "0" !== k("fuScrnEnabled"),
                autoplay: "true" === k("autoplay") || "1" === k("autoplay"),
                coverpic: k("coverpic") ? {
                    style: "cover",
                    src: k("coverpic")
                } : null,
                controls: k("ctr") || "default",
                coverpic_pause: "true" === k("coverpic_pause") || "1" === k("coverpic_pause"),
                coverpic_error: "true" === k("coverpic_error") || "1" === k("coverpic_error")
            };
            return e
        },
            _ = function () {
                return;
				var e = new Object,
                    t = "width: 100%; position: absolute;background-color: rgba(255, 255, 200, 0.5);top: 0px;padding: 6px 20px;text-align: center;display: none;font-size:0.7em;";
                return e.dom = (0, s.
            default)(['<div id="tcerrtips0001" style="', t, '">', "</div>"].join("")), (0, s.
            default)("body").append(e.dom), e.show = function (t) {
                    e.dom.text(t), e.dom.slideDown(500, function () {
                        setTimeout(function () {
                            e.dom.slideUp(500)
                        }, 5e3)
                    })
                }, e
            }(),
            x = function () {
                return function (e) {
                    var t = ["on_", e.type].join(""),
                        n = null;
                    ["timeupdate", "timelabel"].indexOf(e.type) >= 0, this.hasOwnProperty(t) && this[t](e), this.on_fullscreen = function (e) {
                        e.detail.isFullscreen !== !1 && "MSIE" == b[0] && b[1] <= 9 && window != top && _.show("您的浏览器无法进行全屏播放")
                    }, this.on_ended = function (e) {
                        h === !0 && setTimeout(function () {
                            try {
                                window[v].togglePlay()
                            } catch (e) {
                                console.log("Err : %s", e)
                            }
                        }, 200)
                    }, this.on_error = function (e) {
                        y === !0 && (n = setTimeout(function () {
                            try {
                                window[v].poster.show()
                            } catch (e) {
                                console.log("Err : %s", e)
                            }
                        }, 2e3))
                    }, this.on_playing = function () {
                        null !== n && (clearTimeout(n), n = null), window[v].errortips.hide(), y === !0 && setTimeout(function () {
                            try {
                                window[v].poster.hide()
                            } catch (e) {
                                console.log("Err : %s", e)
                            }
                        })
                    }
                }
            },
            S = function (e, t) {
				e.listener = x(), t.player = new u.TcPlayer(e.owner, e), window[v] = t.player, t.ready = !0
            },
            E = function (e, t, n, i) {
                console.log(n);
				var o = [window.location.protocol, "//playvideo.qcloud.com/index.php"].join("");
                s.
            default.ajax({
                    url: o,
                    type: "get",
                    dataType: "jsonp",
                    jsonp: "callback",
                    timeout: 1e3,
                    data: {
                        app_id: e,
                        file_id: t,
                        refer: window.location.hostname,
                        interface: "Vod_Api_GetPlayInfo"
                    },
                    success: function (e) {
						try {
                            var t = C(e.data.file_info.image_video.videoUrls),
                                o = s.
                            default.extend(n, t);
                            null === n.coverpic && e.data.file_info.image_url && (n.coverpic = {
                                style: "stretch",
                                src: T(e.data.file_info.image_url)
                            }), !i || i(o)
                        } catch (e) {
                            "NOT_M3U8_CAN_BEE_USED" === e ? _.show("无可用的hls文件， 请确认是否启用了转码") : console.log(e)
                        }
                    }
                })
            },
            T = function (e) {
                var t = window.location.protocol,
                    n = (new RegExp(t), e.match(/(http(s?):)/)[0]);
                return t === n ? e : e.replace(n, t)
            },
            C = function (e) {
                for (var t = {}, n = /f240\.m3u8/, i = /f230\.m3u8/, o = /f220\.m3u8/, r = null, s = 0, a = 0; a < e.length && !(s >= 3); a++) null === (r = e[a].url.match(n)) ? null === (r = e[a].url.match(i)) ? null === (r = e[a].url.match(o)) || (t.m3u8_sd = T(e[a].url), s++) : (t.m3u8_hd = T(e[a].url), s++) : (t.m3u8 = T(e[a].url), s++);
                if (0 === s) throw "NOT_M3U8_CAN_BEE_USED";
                return t
            },
            k = function (e) {
                var t = new RegExp("(^|&)" + e + "=([^&]*)(&|$)", "i"),
                    n = window.location.search.substr(1).match(t);
				return null !== n ? decodeURIComponent(n[2]) : null
            },
            M = function (e, t, n) {
                if (void 0 == e || void 0 == t) throw "直播场景下需要参数 b (bizid)和 s (直播源ID)";
                var i = {
                    PNAME: {
                        m3u8: {
                            od: "m3u8",
                            hd: "m3u8_hd",
                            sd: "m3u8_hd"
                        },
                        hls: {
                            od: "m3u8",
                            hd: "m3u8_hd",
                            sd: "m3u8_hd"
                        },
                        rtmp: {
                            od: "rtmp",
                            hd: "rtmp_hd",
                            sd: "rtmp_hd"
                        },
                        flv: {
                            od: "flv",
                            hd: "flv_hd",
                            sd: "flv_hd"
                        }
                    },
                    EXT: {
                        m3u8: {
                            od: ".m3u8",
                            hd: "_550.m3u8",
                            sd: "_900.m3u8"
                        },
                        hls: {
                            od: ".m3u8",
                            hd: "_550.m3u8",
                            sd: "_900.m3u8"
                        },
                        rtmp: {
                            od: "",
                            hd: "_550",
                            sd: "_900"
                        },
                        flv: {
                            od: ".flv",
                            hd: "_550.flv",
                            sd: "_900.flv"
                        }
                    },
                    PROTOCOL: {
                        m3u8: "http://",
                        hls: "http://",
                        rtmp: "rtmp://",
                        flv: "flv://"
                    }
                },
                    o = i.PROTOCOL.hasOwnProperty(n) ? n : "m3u8",
                    r = ".liveplay.myqcloud.com/live/",
                    s = {
                        od: [i.PROTOCOL[o], e, r, t, i.EXT[o].od].join(""),
                        hd: [i.PROTOCOL[o], e, r, t, i.EXT[o].hd].join(""),
                        sd: [i.PROTOCOL[o], e, r, t, i.EXT[o].sd].join("")
                    };
                return s
            },
            O = function () {
                if (1 !== parseInt(k("share"))) return "";//void console.log("disable share");
                var e = top.document.title,
                    t = top.window.location.href,
                    n = {

                        title: e,
                        desc: e,
                        link: t,
                        type: "link"
                    };
                N(m, function () {
                    N(g, function () {
                        wx.ready(function () {
                            wx.onMenuShareTimeline(n), wx.onMenuShareAppMessage(n), wx.onMenuShareQQ(n), wx.onMenuShareWeibo(n), wx.onMenuShareQZone(n)
                        })
                    })
                })
            },
            N = function (e, t) {
                var n = document.createElement("script");
                n.type = "text/javascript", n.onload = function () {
                    t()
                }, n.src = e, document.getElementsByTagName("head")[0].appendChild(n)
            }
    }, function (e, t) {
        "use strict";
        !
        function () {
            window.console || (window.console = function () {
                var e = {};
                return e.log = e.warn = e.debug = e.info = e.error = e.time = e.dir = e.profile = e.clear = e.exception = e.trace = e.assert = function () {}, e
            }()), "classList" in document.documentElement || Object.defineProperty(HTMLElement.prototype, "classList", {
                get: function () {
                    function e(e) {
                        return function (n) {
                            var i = t.className.split(/\s+/g),
                                o = i.indexOf(n);
                            e(i, o, n), t.className = i.join(" ")
                        }
                    }
                    var t = this;
                    return {
                        add: e(function (e, t, n) {~t || e.push(n)
                        }),
                        remove: e(function (e, t) {~t && e.splice(t, 1)
                        }),
                        toggle: e(function (e, t, n) {~t ? e.splice(t, 1) : e.push(n)
                        }),
                        contains: function (e) {
                            return !!~t.className.split(/\s+/g).indexOf(e)
                        },
                        item: function (e) {
                            return t.className.split(/\s+/g)[e] || null
                        }
                    }
                }
            })
        }()
    }, function (e, t, n) {
        var i, o;
        (function (e) {
            "use strict";
            var r = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
            function (e) {
                return typeof e
            } : function (e) {
                return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
            };
            !
            function (t, n) {
                "object" == r(e) && "object" == r(e.exports) ? e.exports = t.document ? n(t, !0) : function (e) {
                    if (!e.document) throw new Error("jQuery requires a window with a document");
                    return n(e)
                } : n(t)
            }("undefined" != typeof window ? window : void 0, function (s, a) {
                function l(e) {
                    var t = !! e && "length" in e && e.length,
                        n = be.type(e);
                    return "function" !== n && !be.isWindow(e) && ("array" === n || 0 === t || "number" == typeof t && t > 0 && t - 1 in e)
                }
                function u(e, t, n) {
                    if (be.isFunction(t)) return be.grep(e, function (e, i) {
                        return !!t.call(e, i, e) !== n
                    });
                    if (t.nodeType) return be.grep(e, function (e) {
                        return e === t !== n
                    });
                    if ("string" == typeof t) {
                        if (Oe.test(t)) return be.filter(t, e, n);
                        t = be.filter(t, e)
                    }
                    return be.grep(e, function (e) {
                        return be.inArray(e, t) > -1 !== n
                    })
                }
                function c(e, t) {
                    do e = e[t];
                    while (e && 1 !== e.nodeType);
                    return e
                }
                function p(e) {
                    var t = {};
                    return be.each(e.match(De) || [], function (e, n) {
                        t[n] = !0
                    }), t
                }
                function d() {
                    ue.addEventListener ? (ue.removeEventListener("DOMContentLoaded", f), s.removeEventListener("load", f)) : (ue.detachEvent("onreadystatechange", f), s.detachEvent("onload", f))
                }
                function f() {
                    (ue.addEventListener || "load" === s.event.type || "complete" === ue.readyState) && (d(), be.ready())
                }
                function h(e, t, n) {
                    if (void 0 === n && 1 === e.nodeType) {
                        var i = "data-" + t.replace(qe, "-$1").toLowerCase();
                        if (n = e.getAttribute(i), "string" == typeof n) {
                            try {
                                n = "true" === n || "false" !== n && ("null" === n ? null : +n + "" === n ? +n : He.test(n) ? be.parseJSON(n) : n)
                            } catch (e) {}
                            be.data(e, t, n)
                        } else n = void 0
                    }
                    return n
                }
                function y(e) {
                    var t;
                    for (t in e) if (("data" !== t || !be.isEmptyObject(e[t])) && "toJSON" !== t) return !1;
                    return !0
                }
                function v(e, t, n, i) {
                    if (Fe(e)) {
                        var o, s, a = be.expando,
                            l = e.nodeType,
                            u = l ? be.cache : e,
                            c = l ? e[a] : e[a] && a;
                        if (c && u[c] && (i || u[c].data) || void 0 !== n || "string" != typeof t) return c || (c = l ? e[a] = le.pop() || be.guid++ : a), u[c] || (u[c] = l ? {} : {
                            toJSON: be.noop
                        }), "object" != ("undefined" == typeof t ? "undefined" : r(t)) && "function" != typeof t || (i ? u[c] = be.extend(u[c], t) : u[c].data = be.extend(u[c].data, t)), s = u[c], i || (s.data || (s.data = {}), s = s.data), void 0 !== n && (s[be.camelCase(t)] = n), "string" == typeof t ? (o = s[t], null == o && (o = s[be.camelCase(t)])) : o = s, o
                    }
                }
                function m(e, t, n) {
                    if (Fe(e)) {
                        var i, o, r = e.nodeType,
                            s = r ? be.cache : e,
                            a = r ? e[be.expando] : be.expando;
                        if (s[a]) {
                            if (t && (i = n ? s[a] : s[a].data)) {
                                be.isArray(t) ? t = t.concat(be.map(t, be.camelCase)) : t in i ? t = [t] : (t = be.camelCase(t), t = t in i ? [t] : t.split(" ")), o = t.length;
                                for (; o--;) delete i[t[o]];
                                if (n ? !y(i) : !be.isEmptyObject(i)) return
                            }(n || (delete s[a].data, y(s[a]))) && (r ? be.cleanData([e], !0) : me.deleteExpando || s != s.window ? delete s[a] : s[a] = void 0)
                        }
                    }
                }
                function g(e, t, n, i) {
                    var o, r = 1,
                        s = 20,
                        a = i ?
                        function () {
                            return i.cur()
                        } : function () {
                            return be.css(e, t, "")
                        },
                        l = a(),
                        u = n && n[3] || (be.cssNumber[t] ? "" : "px"),
                        c = (be.cssNumber[t] || "px" !== u && +l) && Ge.exec(be.css(e, t));
                    if (c && c[3] !== u) {
                        u = u || c[3], n = n || [], c = +l || 1;
                        do r = r || ".5", c /= r, be.style(e, t, c + u);
                        while (r !== (r = a() / l) && 1 !== r && --s)
                    }
                    return n && (c = +c || +l || 0, o = n[1] ? c + (n[1] + 1) * n[2] : +n[2], i && (i.unit = u, i.start = c, i.end = o)), o
                }
                function b(e) {
                    var t = Ke.split("|"),
                        n = e.createDocumentFragment();
                    if (n.createElement) for (; t.length;) n.createElement(t.pop());
                    return n
                }
                function w(e, t) {
                    var n, i, o = 0,
                        r = "undefined" != typeof e.getElementsByTagName ? e.getElementsByTagName(t || "*") : "undefined" != typeof e.querySelectorAll ? e.querySelectorAll(t || "*") : void 0;
                    if (!r) for (r = [], n = e.childNodes || e; null != (i = n[o]); o++)!t || be.nodeName(i, t) ? r.push(i) : be.merge(r, w(i, t));
                    return void 0 === t || t && be.nodeName(e, t) ? be.merge([e], r) : r
                }
                function _(e, t) {
                    for (var n, i = 0; null != (n = e[i]); i++) be._data(n, "globalEval", !t || be._data(t[i], "globalEval"))
                }
                function x(e) {
                    Ue.test(e.type) && (e.defaultChecked = e.checked)
                }
                function S(e, t, n, i, o) {
                    for (var r, s, a, l, u, c, p, d = e.length, f = b(t), h = [], y = 0; d > y; y++) if (s = e[y], s || 0 === s) if ("object" === be.type(s)) be.merge(h, s.nodeType ? [s] : s);
                    else if (Je.test(s)) {
                        for (l = l || f.appendChild(t.createElement("div")), u = ($e.exec(s) || ["", ""])[1].toLowerCase(), p = Qe[u] || Qe._default, l.innerHTML = p[1] + be.htmlPrefilter(s) + p[2], r = p[0]; r--;) l = l.lastChild;
                        if (!me.leadingWhitespace && Ye.test(s) && h.push(t.createTextNode(Ye.exec(s)[0])), !me.tbody) for (s = "table" !== u || Ze.test(s) ? "<table>" !== p[1] || Ze.test(s) ? 0 : l : l.firstChild, r = s && s.childNodes.length; r--;) be.nodeName(c = s.childNodes[r], "tbody") && !c.childNodes.length && s.removeChild(c);
                        for (be.merge(h, l.childNodes), l.textContent = ""; l.firstChild;) l.removeChild(l.firstChild);
                        l = f.lastChild
                    } else h.push(t.createTextNode(s));
                    for (l && f.removeChild(l), me.appendChecked || be.grep(w(h, "input"), x), y = 0; s = h[y++];) if (i && be.inArray(s, i) > -1) o && o.push(s);
                    else if (a = be.contains(s.ownerDocument, s), l = w(f.appendChild(s), "script"), a && _(l), n) for (r = 0; s = l[r++];) Xe.test(s.type || "") && n.push(s);
                    return l = null, f
                }
                function E() {
                    return !0
                }
                function T() {
                    return !1
                }
                function C() {
                    try {
                        return ue.activeElement
                    } catch (e) {}
                }
                function k(e, t, n, i, o, s) {
                    var a, l;
                    if ("object" == ("undefined" == typeof t ? "undefined" : r(t))) {
                        "string" != typeof n && (i = i || n, n = void 0);
                        for (l in t) k(e, l, n, i, t[l], s);
                        return e
                    }
                    if (null == i && null == o ? (o = n, i = n = void 0) : null == o && ("string" == typeof n ? (o = i, i = void 0) : (o = i, i = n, n = void 0)), o === !1) o = T;
                    else if (!o) return e;
                    return 1 === s && (a = o, o = function (e) {
                        return be().off(e), a.apply(this, arguments)
                    }, o.guid = a.guid || (a.guid = be.guid++)), e.each(function () {
                        be.event.add(this, t, o, i, n)
                    })
                }
                function M(e, t) {
                    return be.nodeName(e, "table") && be.nodeName(11 !== t.nodeType ? t : t.firstChild, "tr") ? e.getElementsByTagName("tbody")[0] || e.appendChild(e.ownerDocument.createElement("tbody")) : e
                }
                function O(e) {
                    return e.type = (null !== be.find.attr(e, "type")) + "/" + e.type, e
                }
                function N(e) {
                    var t = ct.exec(e.type);
                    return t ? e.type = t[1] : e.removeAttribute("type"), e
                }
                function L(e, t) {
                    if (1 === t.nodeType && be.hasData(e)) {
                        var n, i, o, r = be._data(e),
                            s = be._data(t, r),
                            a = r.events;
                        if (a) {
                            delete s.handle, s.events = {};
                            for (n in a) for (i = 0, o = a[n].length; o > i; i++) be.event.add(t, n, a[n][i])
                        }
                        s.data && (s.data = be.extend({}, s.data))
                    }
                }
                function j(e, t) {
                    var n, i, o;
                    if (1 === t.nodeType) {
                        if (n = t.nodeName.toLowerCase(), !me.noCloneEvent && t[be.expando]) {
                            o = be._data(t);
                            for (i in o.events) be.removeEvent(t, i, o.handle);
                            t.removeAttribute(be.expando)
                        }
                        "script" === n && t.text !== e.text ? (O(t).text = e.text, N(t)) : "object" === n ? (t.parentNode && (t.outerHTML = e.outerHTML), me.html5Clone && e.innerHTML && !be.trim(t.innerHTML) && (t.innerHTML = e.innerHTML)) : "input" === n && Ue.test(e.type) ? (t.defaultChecked = t.checked = e.checked, t.value !== e.value && (t.value = e.value)) : "option" === n ? t.defaultSelected = t.selected = e.defaultSelected : "input" !== n && "textarea" !== n || (t.defaultValue = e.defaultValue)
                    }
                }
                function A(e, t, n, i) {
                    t = pe.apply([], t);
                    var o, r, s, a, l, u, c = 0,
                        p = e.length,
                        d = p - 1,
                        f = t[0],
                        h = be.isFunction(f);
                    if (h || p > 1 && "string" == typeof f && !me.checkClone && ut.test(f)) return e.each(function (o) {
                        var r = e.eq(o);
                        h && (t[0] = f.call(this, o, r.html())), A(r, t, n, i)
                    });
                    if (p && (u = S(t, e[0].ownerDocument, !1, e, i), o = u.firstChild, 1 === u.childNodes.length && (u = o), o || i)) {
                        for (a = be.map(w(u, "script"), O), s = a.length; p > c; c++) r = u, c !== d && (r = be.clone(r, !0, !0), s && be.merge(a, w(r, "script"))), n.call(e[c], r, c);
                        if (s) for (l = a[a.length - 1].ownerDocument, be.map(a, N), c = 0; s > c; c++) r = a[c], Xe.test(r.type || "") && !be._data(r, "globalEval") && be.contains(l, r) && (r.src ? be._evalUrl && be._evalUrl(r.src) : be.globalEval((r.text || r.textContent || r.innerHTML || "").replace(pt, "")));
                        u = o = null
                    }
                    return e
                }
                function P(e, t, n) {
                    for (var i, o = t ? be.filter(t, e) : e, r = 0; null != (i = o[r]); r++) n || 1 !== i.nodeType || be.cleanData(w(i)), i.parentNode && (n && be.contains(i.ownerDocument, i) && _(w(i, "script")), i.parentNode.removeChild(i));
                    return e
                }
                function D(e, t) {
                    var n = be(t.createElement(e)).appendTo(t.body),
                        i = be.css(n[0], "display");
                    return n.detach(), i
                }
                function I(e) {
                    var t = ue,
                        n = yt[e];
                    return n || (n = D(e, t), "none" !== n && n || (ht = (ht || be("<iframe frameborder='0' width='0' height='0'/>")).appendTo(t.documentElement), t = (ht[0].contentWindow || ht[0].contentDocument).document, t.write(), t.close(), n = D(e, t), ht.detach()), yt[e] = n), n
                }
                function R(e, t) {
                    return {
                        get: function () {
                            return e() ? void delete this.get : (this.get = t).apply(this, arguments)
                        }
                    }
                }
                function F(e) {
                    if (e in Nt) return e;
                    for (var t = e.charAt(0).toUpperCase() + e.slice(1), n = Ot.length; n--;) if (e = Ot[n] + t, e in Nt) return e
                }
                function H(e, t) {
                    for (var n, i, o, r = [], s = 0, a = e.length; a > s; s++) i = e[s], i.style && (r[s] = be._data(i, "olddisplay"), n = i.style.display, t ? (r[s] || "none" !== n || (i.style.display = ""), "" === i.style.display && We(i) && (r[s] = be._data(i, "olddisplay", I(i.nodeName)))) : (o = We(i), (n && "none" !== n || !o) && be._data(i, "olddisplay", o ? n : be.css(i, "display"))));
                    for (s = 0; a > s; s++) i = e[s], i.style && (t && "none" !== i.style.display && "" !== i.style.display || (i.style.display = t ? r[s] || "" : "none"));
                    return e
                }
                function q(e, t, n) {
                    var i = Ct.exec(t);
                    return i ? Math.max(0, i[1] - (n || 0)) + (i[2] || "px") : t
                }
                function B(e, t, n, i, o) {
                    for (var r = n === (i ? "border" : "content") ? 4 : "width" === t ? 1 : 0, s = 0; 4 > r; r += 2)"margin" === n && (s += be.css(e, n + ze[r], !0, o)), i ? ("content" === n && (s -= be.css(e, "padding" + ze[r], !0, o)), "margin" !== n && (s -= be.css(e, "border" + ze[r] + "Width", !0, o))) : (s += be.css(e, "padding" + ze[r], !0, o), "padding" !== n && (s += be.css(e, "border" + ze[r] + "Width", !0, o)));
                    return s
                }
                function G(e, t, n) {
                    var i = !0,
                        o = "width" === t ? e.offsetWidth : e.offsetHeight,
                        r = wt(e),
                        s = me.boxSizing && "border-box" === be.css(e, "boxSizing", !1, r);
                    if (0 >= o || null == o) {
                        if (o = _t(e, t, r), (0 > o || null == o) && (o = e.style[t]), mt.test(o)) return o;
                        i = s && (me.boxSizingReliable() || o === e.style[t]), o = parseFloat(o) || 0
                    }
                    return o + B(e, t, n || (s ? "border" : "content"), i, r) + "px"
                }
                function z(e, t, n, i, o) {
                    return new z.prototype.init(e, t, n, i, o)
                }
                function W() {
                    return s.setTimeout(function () {
                        Lt = void 0
                    }), Lt = be.now()
                }
                function V(e, t) {
                    var n, i = {
                        height: e
                    },
                        o = 0;
                    for (t = t ? 1 : 0; 4 > o; o += 2 - t) n = ze[o], i["margin" + n] = i["padding" + n] = e;
                    return t && (i.opacity = i.width = e), i
                }
                function U(e, t, n) {
                    for (var i, o = (Y.tweeners[t] || []).concat(Y.tweeners["*"]), r = 0, s = o.length; s > r; r++) if (i = o[r].call(n, t, e)) return i
                }
                function $(e, t, n) {
                    var i, o, r, s, a, l, u, c, p = this,
                        d = {},
                        f = e.style,
                        h = e.nodeType && We(e),
                        y = be._data(e, "fxshow");
                    n.queue || (a = be._queueHooks(e, "fx"), null == a.unqueued && (a.unqueued = 0, l = a.empty.fire, a.empty.fire = function () {
                        a.unqueued || l()
                    }), a.unqueued++, p.always(function () {
                        p.always(function () {
                            a.unqueued--, be.queue(e, "fx").length || a.empty.fire()
                        })
                    })), 1 === e.nodeType && ("height" in t || "width" in t) && (n.overflow = [f.overflow, f.overflowX, f.overflowY], u = be.css(e, "display"), c = "none" === u ? be._data(e, "olddisplay") || I(e.nodeName) : u, "inline" === c && "none" === be.css(e, "float") && (me.inlineBlockNeedsLayout && "inline" !== I(e.nodeName) ? f.zoom = 1 : f.display = "inline-block")), n.overflow && (f.overflow = "hidden", me.shrinkWrapBlocks() || p.always(function () {
                        f.overflow = n.overflow[0], f.overflowX = n.overflow[1], f.overflowY = n.overflow[2]
                    }));
                    for (i in t) if (o = t[i], At.exec(o)) {
                        if (delete t[i], r = r || "toggle" === o, o === (h ? "hide" : "show")) {
                            if ("show" !== o || !y || void 0 === y[i]) continue;
                            h = !0
                        }
                        d[i] = y && y[i] || be.style(e, i)
                    } else u = void 0;
                    if (be.isEmptyObject(d))"inline" === ("none" === u ? I(e.nodeName) : u) && (f.display = u);
                    else {
                        y ? "hidden" in y && (h = y.hidden) : y = be._data(e, "fxshow", {}), r && (y.hidden = !h), h ? be(e).show() : p.done(function () {
                            be(e).hide()
                        }), p.done(function () {
                            var t;
                            be._removeData(e, "fxshow");
                            for (t in d) be.style(e, t, d[t])
                        });
                        for (i in d) s = U(h ? y[i] : 0, i, p), i in y || (y[i] = s.start, h && (s.end = s.start, s.start = "width" === i || "height" === i ? 1 : 0))
                    }
                }
                function X(e, t) {
                    var n, i, o, r, s;
                    for (n in e) if (i = be.camelCase(n), o = t[i], r = e[n], be.isArray(r) && (o = r[1], r = e[n] = r[0]), n !== i && (e[i] = r, delete e[n]), s = be.cssHooks[i], s && "expand" in s) {
                        r = s.expand(r), delete e[i];
                        for (n in r) n in e || (e[n] = r[n], t[n] = o)
                    } else t[i] = o
                }
                function Y(e, t, n) {
                    var i, o, r = 0,
                        s = Y.prefilters.length,
                        a = be.Deferred().always(function () {
                            delete l.elem
                        }),
                        l = function t() {
                            if (o) return !1;
                            for (var n = Lt || W(), i = Math.max(0, u.startTime + u.duration - n), r = i / u.duration || 0, s = 1 - r, l = 0, t = u.tweens.length; t > l; l++) u.tweens[l].run(s);
                            return a.notifyWith(e, [u, s, i]), 1 > s && t ? i : (a.resolveWith(e, [u]), !1)
                        },
                        u = a.promise({
                            elem: e,
                            props: be.extend({}, t),
                            opts: be.extend(!0, {
                                specialEasing: {},
                                easing: be.easing._default
                            }, n),
                            originalProperties: t,
                            originalOptions: n,
                            startTime: Lt || W(),
                            duration: n.duration,
                            tweens: [],
                            createTween: function (t, n) {
                                var i = be.Tween(e, u.opts, t, n, u.opts.specialEasing[t] || u.opts.easing);
                                return u.tweens.push(i), i
                            },
                            stop: function (t) {
                                var n = 0,
                                    i = t ? u.tweens.length : 0;
                                if (o) return this;
                                for (o = !0; i > n; n++) u.tweens[n].run(1);
                                return t ? (a.notifyWith(e, [u, 1, 0]), a.resolveWith(e, [u, t])) : a.rejectWith(e, [u, t]), this
                            }
                        }),
                        c = u.props;
                    for (X(c, u.opts.specialEasing); s > r; r++) if (i = Y.prefilters[r].call(u, e, c, u.opts)) return be.isFunction(i.stop) && (be._queueHooks(u.elem, u.opts.queue).stop = be.proxy(i.stop, i)), i;
                    return be.map(c, U, u), be.isFunction(u.opts.start) && u.opts.start.call(e, u), be.fx.timer(be.extend(l, {
                        elem: e,
                        anim: u,
                        queue: u.opts.queue
                    })), u.progress(u.opts.progress).done(u.opts.done, u.opts.complete).fail(u.opts.fail).always(u.opts.always)
                }
                function K(e) {
                    return be.attr(e, "class") || ""
                }
                function Q(e) {
                    return function (t, n) {
                        "string" != typeof t && (n = t, t = "*");
                        var i, o = 0,
                            r = t.toLowerCase().match(De) || [];
                        if (be.isFunction(n)) for (; i = r[o++];)"+" === i.charAt(0) ? (i = i.slice(1) || "*", (e[i] = e[i] || []).unshift(n)) : (e[i] = e[i] || []).push(n)
                    }
                }
                function J(e, t, n, i) {
                    function o(a) {
                        var l;
                        return r[a] = !0, be.each(e[a] || [], function (e, a) {
                            var u = a(t, n, i);
                            return "string" != typeof u || s || r[u] ? s ? !(l = u) : void 0 : (t.dataTypes.unshift(u), o(u), !1)
                        }), l
                    }
                    var r = {},
                        s = e === rn;
                    return o(t.dataTypes[0]) || !r["*"] && o("*")
                }
                function Z(e, t) {
                    var n, i, o = be.ajaxSettings.flatOptions || {};
                    for (i in t) void 0 !== t[i] && ((o[i] ? e : n || (n = {}))[i] = t[i]);
                    return n && be.extend(!0, e, n), e
                }
                function ee(e, t, n) {
                    for (var i, o, r, s, a = e.contents, l = e.dataTypes;
                    "*" === l[0];) l.shift(), void 0 === o && (o = e.mimeType || t.getResponseHeader("Content-Type"));
                    if (o) for (s in a) if (a[s] && a[s].test(o)) {
                        l.unshift(s);
                        break
                    }
                    if (l[0] in n) r = l[0];
                    else {
                        for (s in n) {
                            if (!l[0] || e.converters[s + " " + l[0]]) {
                                r = s;
                                break
                            }
                            i || (i = s)
                        }
                        r = r || i
                    }
                    return r ? (r !== l[0] && l.unshift(r), n[r]) : void 0
                }
                function te(e, t, n, i) {
                    var o, r, s, a, l, u = {},
                        c = e.dataTypes.slice();
                    if (c[1]) for (s in e.converters) u[s.toLowerCase()] = e.converters[s];
                    for (r = c.shift(); r;) if (e.responseFields[r] && (n[e.responseFields[r]] = t), !l && i && e.dataFilter && (t = e.dataFilter(t, e.dataType)), l = r, r = c.shift()) if ("*" === r) r = l;
                    else if ("*" !== l && l !== r) {
                        if (s = u[l + " " + r] || u["* " + r], !s) for (o in u) if (a = o.split(" "), a[1] === r && (s = u[l + " " + a[0]] || u["* " + a[0]])) {
                            s === !0 ? s = u[o] : u[o] !== !0 && (r = a[0], c.unshift(a[1]));
                            break
                        }
                        if (s !== !0) if (s && e.throws) t = s(t);
                        else try {
                            t = s(t)
                        } catch (e) {
                            return {
                                state: "parsererror",
                                error: s ? e : "No conversion from " + l + " to " + r
                            }
                        }
                    }
                    return {
                        state: "success",
                        data: t
                    }
                }
                function ne(e) {
                    return e.style && e.style.display || be.css(e, "display")
                }
                function ie(e) {
                    if (!be.contains(e.ownerDocument || ue, e)) return !0;
                    for (; e && 1 === e.nodeType;) {
                        if ("none" === ne(e) || "hidden" === e.type) return !0;
                        e = e.parentNode
                    }
                    return !1
                }
                function oe(e, t, n, i) {
                    var o;
                    if (be.isArray(t)) be.each(t, function (t, o) {
                        n || cn.test(e) ? i(e, o) : oe(e + "[" + ("object" == ("undefined" == typeof o ? "undefined" : r(o)) && null != o ? t : "") + "]", o, n, i)
                    });
                    else if (n || "object" !== be.type(t)) i(e, t);
                    else for (o in t) oe(e + "[" + o + "]", t[o], n, i)
                }
                function re() {
                    try {
                        return new s.XMLHttpRequest
                    } catch (e) {}
                }
                function se() {
                    try {
                        return new s.ActiveXObject("Microsoft.XMLHTTP")
                    } catch (e) {}
                }
                function ae(e) {
                    return be.isWindow(e) ? e : 9 === e.nodeType && (e.defaultView || e.parentWindow)
                }
                var le = [],
                    ue = s.document,
                    ce = le.slice,
                    pe = le.concat,
                    de = le.push,
                    fe = le.indexOf,
                    he = {},
                    ye = he.toString,
                    ve = he.hasOwnProperty,
                    me = {},
                    ge = "1.12.4",
                    be = function e(t, n) {
                        return new e.fn.init(t, n)
                    },
                    we = /^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g,
                    _e = /^-ms-/,
                    xe = /-([\da-z])/gi,
                    Se = function (e, t) {
                        return t.toUpperCase()
                    };
                be.fn = be.prototype = {
                    jquery: ge,
                    constructor: be,
                    selector: "",
                    length: 0,
                    toArray: function () {
                        return ce.call(this)
                    },
                    get: function (e) {
                        return null != e ? 0 > e ? this[e + this.length] : this[e] : ce.call(this)
                    },
                    pushStack: function (e) {
                        var t = be.merge(this.constructor(), e);
                        return t.prevObject = this, t.context = this.context, t
                    },
                    each: function (e) {
                        return be.each(this, e)
                    },
                    map: function (e) {
                        return this.pushStack(be.map(this, function (t, n) {
                            return e.call(t, n, t)
                        }))
                    },
                    slice: function () {
                        return this.pushStack(ce.apply(this, arguments))
                    },
                    first: function () {
                        return this.eq(0)
                    },
                    last: function () {
                        return this.eq(-1)
                    },
                    eq: function (e) {
                        var t = this.length,
                            n = +e + (0 > e ? t : 0);
                        return this.pushStack(n >= 0 && t > n ? [this[n]] : [])
                    },
                    end: function () {
                        return this.prevObject || this.constructor()
                    },
                    push: de,
                    sort: le.sort,
                    splice: le.splice
                }, be.extend = be.fn.extend = function () {
                    var e, t, n, i, o, s, a = arguments[0] || {},
                        l = 1,
                        u = arguments.length,
                        c = !1;
                    for ("boolean" == typeof a && (c = a, a = arguments[l] || {}, l++), "object" == ("undefined" == typeof a ? "undefined" : r(a)) || be.isFunction(a) || (a = {}), l === u && (a = this, l--); u > l; l++) if (null != (o = arguments[l])) for (i in o) e = a[i], n = o[i], a !== n && (c && n && (be.isPlainObject(n) || (t = be.isArray(n))) ? (t ? (t = !1, s = e && be.isArray(e) ? e : []) : s = e && be.isPlainObject(e) ? e : {}, a[i] = be.extend(c, s, n)) : void 0 !== n && (a[i] = n));
                    return a
                }, be.extend({
                    expando: "jQuery" + (ge + Math.random()).replace(/\D/g, ""),
                    isReady: !0,
                    error: function (e) {
                        throw new Error(e)
                    },
                    noop: function () {},
                    isFunction: function (e) {
                        return "function" === be.type(e)
                    },
                    isArray: Array.isArray ||
                    function (e) {
                        return "array" === be.type(e)
                    },
                    isWindow: function (e) {
                        return null != e && e == e.window
                    },
                    isNumeric: function (e) {
                        var t = e && e.toString();
                        return !be.isArray(e) && t - parseFloat(t) + 1 >= 0
                    },
                    isEmptyObject: function (e) {
                        var t;
                        for (t in e) return !1;
                        return !0
                    },
                    isPlainObject: function (e) {
                        var t;
                        if (!e || "object" !== be.type(e) || e.nodeType || be.isWindow(e)) return !1;
                        try {
                            if (e.constructor && !ve.call(e, "constructor") && !ve.call(e.constructor.prototype, "isPrototypeOf")) return !1
                        } catch (e) {
                            return !1
                        }
                        if (!me.ownFirst) for (t in e) return ve.call(e, t);
                        for (t in e);
                        return void 0 === t || ve.call(e, t)
                    },
                    type: function (e) {
                        return null == e ? e + "" : "object" == ("undefined" == typeof e ? "undefined" : r(e)) || "function" == typeof e ? he[ye.call(e)] || "object" : "undefined" == typeof e ? "undefined" : r(e)
                    },
                    globalEval: function (e) {
                        e && be.trim(e) && (s.execScript ||
                        function (e) {
                            s.eval.call(s, e)
                        })(e)
                    },
                    camelCase: function (e) {
                        return e.replace(_e, "ms-").replace(xe, Se)
                    },
                    nodeName: function (e, t) {
                        return e.nodeName && e.nodeName.toLowerCase() === t.toLowerCase()
                    },
                    each: function (e, t) {
                        var n, i = 0;
                        if (l(e)) for (n = e.length; n > i && t.call(e[i], i, e[i]) !== !1; i++);
                        else for (i in e) if (t.call(e[i], i, e[i]) === !1) break;
                        return e
                    },
                    trim: function (e) {
                        return null == e ? "" : (e + "").replace(we, "")
                    },
                    makeArray: function (e, t) {
                        var n = t || [];
                        return null != e && (l(Object(e)) ? be.merge(n, "string" == typeof e ? [e] : e) : de.call(n, e)), n
                    },
                    inArray: function (e, t, n) {
                        var i;
                        if (t) {
                            if (fe) return fe.call(t, e, n);
                            for (i = t.length, n = n ? 0 > n ? Math.max(0, i + n) : n : 0; i > n; n++) if (n in t && t[n] === e) return n
                        }
                        return -1
                    },
                    merge: function (e, t) {
                        for (var n = +t.length, i = 0, o = e.length; n > i;) e[o++] = t[i++];
                        if (n !== n) for (; void 0 !== t[i];) e[o++] = t[i++];
                        return e.length = o, e
                    },
                    grep: function (e, t, n) {
                        for (var i, o = [], r = 0, s = e.length, a = !n; s > r; r++) i = !t(e[r], r), i !== a && o.push(e[r]);
                        return o
                    },
                    map: function (e, t, n) {
                        var i, o, r = 0,
                            s = [];
                        if (l(e)) for (i = e.length; i > r; r++) o = t(e[r], r, n), null != o && s.push(o);
                        else for (r in e) o = t(e[r], r, n), null != o && s.push(o);
                        return pe.apply([], s)
                    },
                    guid: 1,
                    proxy: function (e, t) {
                        var n, i, o;
                        return "string" == typeof t && (o = e[t], t = e, e = o), be.isFunction(e) ? (n = ce.call(arguments, 2), i = function () {
                            return e.apply(t || this, n.concat(ce.call(arguments)))
                        }, i.guid = e.guid = e.guid || be.guid++, i) : void 0
                    },
                    now: function () {
                        return +new Date
                    },
                    support: me
                }), "function" == typeof Symbol && (be.fn[Symbol.iterator] = le[Symbol.iterator]), be.each("Boolean Number String Function Array Date RegExp Object Error Symbol".split(" "), function (e, t) {
                    he["[object " + t + "]"] = t.toLowerCase()
                });
                var Ee = function (e) {
                    function t(e, t, n, i) {
                        var o, r, s, a, l, u, p, f, h = t && t.ownerDocument,
                            y = t ? t.nodeType : 9;
                        if (n = n || [], "string" != typeof e || !e || 1 !== y && 9 !== y && 11 !== y) return n;
                        if (!i && ((t ? t.ownerDocument || t : q) !== j && L(t), t = t || j, P)) {
                            if (11 !== y && (u = me.exec(e))) if (o = u[1]) {
                                if (9 === y) {
                                    if (!(s = t.getElementById(o))) return n;
                                    if (s.id === o) return n.push(s), n
                                } else if (h && (s = h.getElementById(o)) && F(t, s) && s.id === o) return n.push(s), n
                            } else {
                                if (u[2]) return J.apply(n, t.getElementsByTagName(e)), n;
                                if ((o = u[3]) && _.getElementsByClassName && t.getElementsByClassName) return J.apply(n, t.getElementsByClassName(o)), n
                            }
                            if (_.qsa && !V[e + " "] && (!D || !D.test(e))) {
                                if (1 !== y) h = t, f = e;
                                else if ("object" !== t.nodeName.toLowerCase()) {
                                    for ((a = t.getAttribute("id")) ? a = a.replace(be, "\\$&") : t.setAttribute("id", a = H), p = T(e), r = p.length, l = de.test(a) ? "#" + a : "[id='" + a + "']"; r--;) p[r] = l + " " + d(p[r]);
                                    f = p.join(","), h = ge.test(e) && c(t.parentNode) || t
                                }
                                if (f) try {
                                    return J.apply(n, h.querySelectorAll(f)), n
                                } catch (e) {} finally {
                                    a === H && t.removeAttribute("id")
                                }
                            }
                        }
                        return k(e.replace(ae, "$1"), t, n, i)
                    }
                    function n() {
                        function e(n, i) {
                            return t.push(n + " ") > x.cacheLength && delete e[t.shift()], e[n + " "] = i
                        }
                        var t = [];
                        return e
                    }
                    function i(e) {
                        return e[H] = !0, e
                    }
                    function o(e) {
                        var t = j.createElement("div");
                        try {
                            return !!e(t)
                        } catch (e) {
                            return !1
                        } finally {
                            t.parentNode && t.parentNode.removeChild(t), t = null
                        }
                    }
                    function r(e, t) {
                        for (var n = e.split("|"), i = n.length; i--;) x.attrHandle[n[i]] = t
                    }
                    function s(e, t) {
                        var n = t && e,
                            i = n && 1 === e.nodeType && 1 === t.nodeType && (~t.sourceIndex || $) - (~e.sourceIndex || $);
                        if (i) return i;
                        if (n) for (; n = n.nextSibling;) if (n === t) return -1;
                        return e ? 1 : -1
                    }
                    function a(e) {
                        return function (t) {
                            var n = t.nodeName.toLowerCase();
                            return "input" === n && t.type === e
                        }
                    }
                    function l(e) {
                        return function (t) {
                            var n = t.nodeName.toLowerCase();
                            return ("input" === n || "button" === n) && t.type === e
                        }
                    }
                    function u(e) {
                        return i(function (t) {
                            return t = +t, i(function (n, i) {
                                for (var o, r = e([], n.length, t), s = r.length; s--;) n[o = r[s]] && (n[o] = !(i[o] = n[o]))
                            })
                        })
                    }
                    function c(e) {
                        return e && "undefined" != typeof e.getElementsByTagName && e
                    }
                    function p() {}
                    function d(e) {
                        for (var t = 0, n = e.length, i = ""; n > t; t++) i += e[t].value;
                        return i
                    }
                    function f(e, t, n) {
                        var i = t.dir,
                            o = n && "parentNode" === i,
                            r = G++;
                        return t.first ?
                        function (t, n, r) {
                            for (; t = t[i];) if (1 === t.nodeType || o) return e(t, n, r)
                        } : function (t, n, s) {
                            var a, l, u, c = [B, r];
                            if (s) {
                                for (; t = t[i];) if ((1 === t.nodeType || o) && e(t, n, s)) return !0
                            } else for (; t = t[i];) if (1 === t.nodeType || o) {
                                if (u = t[H] || (t[H] = {}), l = u[t.uniqueID] || (u[t.uniqueID] = {}), (a = l[i]) && a[0] === B && a[1] === r) return c[2] = a[2];
                                if (l[i] = c, c[2] = e(t, n, s)) return !0
                            }
                        }
                    }
                    function h(e) {
                        return e.length > 1 ?
                        function (t, n, i) {
                            for (var o = e.length; o--;) if (!e[o](t, n, i)) return !1;
                            return !0
                        } : e[0]
                    }
                    function y(e, n, i) {
                        for (var o = 0, r = n.length; r > o; o++) t(e, n[o], i);
                        return i
                    }
                    function v(e, t, n, i, o) {
                        for (var r, s = [], a = 0, l = e.length, u = null != t; l > a; a++)(r = e[a]) && (n && !n(r, i, o) || (s.push(r), u && t.push(a)));
                        return s
                    }
                    function m(e, t, n, o, r, s) {
                        return o && !o[H] && (o = m(o)), r && !r[H] && (r = m(r, s)), i(function (i, s, a, l) {
                            var u, c, p, d = [],
                                f = [],
                                h = s.length,
                                m = i || y(t || "*", a.nodeType ? [a] : a, []),
                                g = !e || !i && t ? m : v(m, d, e, a, l),
                                b = n ? r || (i ? e : h || o) ? [] : s : g;
                            if (n && n(g, b, a, l), o) for (u = v(b, f), o(u, [], a, l), c = u.length; c--;)(p = u[c]) && (b[f[c]] = !(g[f[c]] = p));
                            if (i) {
                                if (r || e) {
                                    if (r) {
                                        for (u = [], c = b.length; c--;)(p = b[c]) && u.push(g[c] = p);
                                        r(null, b = [], u, l)
                                    }
                                    for (c = b.length; c--;)(p = b[c]) && (u = r ? ee(i, p) : d[c]) > -1 && (i[u] = !(s[u] = p))
                                }
                            } else b = v(b === s ? b.splice(h, b.length) : b), r ? r(null, s, b, l) : J.apply(s, b)
                        })
                    }
                    function g(e) {
                        for (var t, n, i, o = e.length, r = x.relative[e[0].type], s = r || x.relative[" "], a = r ? 1 : 0, l = f(function (e) {
                            return e === t
                        }, s, !0), u = f(function (e) {
                            return ee(t, e) > -1
                        }, s, !0), c = [function (e, n, i) {
                            var o = !r && (i || n !== M) || ((t = n).nodeType ? l(e, n, i) : u(e, n, i));
                            return t = null, o
                        }]; o > a; a++) if (n = x.relative[e[a].type]) c = [f(h(c), n)];
                        else {
                            if (n = x.filter[e[a].type].apply(null, e[a].matches), n[H]) {
                                for (i = ++a; o > i && !x.relative[e[i].type]; i++);
                                return m(a > 1 && h(c), a > 1 && d(e.slice(0, a - 1).concat({
                                    value: " " === e[a - 2].type ? "*" : ""
                                })).replace(ae, "$1"), n, i > a && g(e.slice(a, i)), o > i && g(e = e.slice(i)), o > i && d(e))
                            }
                            c.push(n)
                        }
                        return h(c)
                    }
                    function b(e, n) {
                        var o = n.length > 0,
                            r = e.length > 0,
                            s = function (i, s, a, l, u) {
                                var c, p, d, f = 0,
                                    h = "0",
                                    y = i && [],
                                    m = [],
                                    g = M,
                                    b = i || r && x.find.TAG("*", u),
                                    w = B += null == g ? 1 : Math.random() || .1,
                                    _ = b.length;
                                for (u && (M = s === j || s || u); h !== _ && null != (c = b[h]); h++) {
                                    if (r && c) {
                                        for (p = 0, s || c.ownerDocument === j || (L(c), a = !P); d = e[p++];) if (d(c, s || j, a)) {
                                            l.push(c);
                                            break
                                        }
                                        u && (B = w)
                                    }
                                    o && ((c = !d && c) && f--, i && y.push(c))
                                }
                                if (f += h, o && h !== f) {
                                    for (p = 0; d = n[p++];) d(y, m, s, a);
                                    if (i) {
                                        if (f > 0) for (; h--;) y[h] || m[h] || (m[h] = K.call(l));
                                        m = v(m)
                                    }
                                    J.apply(l, m), u && !i && m.length > 0 && f + n.length > 1 && t.uniqueSort(l)
                                }
                                return u && (B = w, M = g), y
                            };
                        return o ? i(s) : s
                    }
                    var w, _, x, S, E, T, C, k, M, O, N, L, j, A, P, D, I, R, F, H = "sizzle" + 1 * new Date,
                        q = e.document,
                        B = 0,
                        G = 0,
                        z = n(),
                        W = n(),
                        V = n(),
                        U = function (e, t) {
                            return e === t && (N = !0), 0
                        },
                        $ = 1 << 31,
                        X = {}.hasOwnProperty,
                        Y = [],
                        K = Y.pop,
                        Q = Y.push,
                        J = Y.push,
                        Z = Y.slice,
                        ee = function (e, t) {
                            for (var n = 0, i = e.length; i > n; n++) if (e[n] === t) return n;
                            return -1
                        },
                        te = "checked|selected|async|autofocus|autoplay|controls|defer|disabled|hidden|ismap|loop|multiple|open|readonly|required|scoped",
                        ne = "[\\x20\\t\\r\\n\\f]",
                        ie = "(?:\\\\.|[\\w-]|[^\\x00-\\xa0])+",
                        oe = "\\[" + ne + "*(" + ie + ")(?:" + ne + "*([*^$|!~]?=)" + ne + "*(?:'((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\"|(" + ie + "))|)" + ne + "*\\]",
                        re = ":(" + ie + ")(?:\\((('((?:\\\\.|[^\\\\'])*)'|\"((?:\\\\.|[^\\\\\"])*)\")|((?:\\\\.|[^\\\\()[\\]]|" + oe + ")*)|.*)\\)|)",
                        se = new RegExp(ne + "+", "g"),
                        ae = new RegExp("^" + ne + "+|((?:^|[^\\\\])(?:\\\\.)*)" + ne + "+$", "g"),
                        le = new RegExp("^" + ne + "*," + ne + "*"),
                        ue = new RegExp("^" + ne + "*([>+~]|" + ne + ")" + ne + "*"),
                        ce = new RegExp("=" + ne + "*([^\\]'\"]*?)" + ne + "*\\]", "g"),
                        pe = new RegExp(re),
                        de = new RegExp("^" + ie + "$"),
                        fe = {
                            ID: new RegExp("^#(" + ie + ")"),
                            CLASS: new RegExp("^\\.(" + ie + ")"),
                            TAG: new RegExp("^(" + ie + "|[*])"),
                            ATTR: new RegExp("^" + oe),
                            PSEUDO: new RegExp("^" + re),
                            CHILD: new RegExp("^:(only|first|last|nth|nth-last)-(child|of-type)(?:\\(" + ne + "*(even|odd|(([+-]|)(\\d*)n|)" + ne + "*(?:([+-]|)" + ne + "*(\\d+)|))" + ne + "*\\)|)", "i"),
                            bool: new RegExp("^(?:" + te + ")$", "i"),
                            needsContext: new RegExp("^" + ne + "*[>+~]|:(even|odd|eq|gt|lt|nth|first|last)(?:\\(" + ne + "*((?:-\\d)?\\d*)" + ne + "*\\)|)(?=[^-]|$)", "i")
                        },
                        he = /^(?:input|select|textarea|button)$/i,
                        ye = /^h\d$/i,
                        ve = /^[^{]+\{\s*\[native \w/,
                        me = /^(?:#([\w-]+)|(\w+)|\.([\w-]+))$/,
                        ge = /[+~]/,
                        be = /'|\\/g,
                        we = new RegExp("\\\\([\\da-f]{1,6}" + ne + "?|(" + ne + ")|.)", "ig"),
                        _e = function (e, t, n) {
                            var i = "0x" + t - 65536;
                            return i !== i || n ? t : 0 > i ? String.fromCharCode(i + 65536) : String.fromCharCode(i >> 10 | 55296, 1023 & i | 56320)
                        },
                        xe = function () {
                            L()
                        };
                    try {
                        J.apply(Y = Z.call(q.childNodes), q.childNodes), Y[q.childNodes.length].nodeType
                    } catch (e) {
                        J = {
                            apply: Y.length ?
                            function (e, t) {
                                Q.apply(e, Z.call(t))
                            } : function (e, t) {
                                for (var n = e.length, i = 0; e[n++] = t[i++];);
                                e.length = n - 1
                            }
                        }
                    }
                    _ = t.support = {}, E = t.isXML = function (e) {
                        var t = e && (e.ownerDocument || e).documentElement;
                        return !!t && "HTML" !== t.nodeName
                    }, L = t.setDocument = function (e) {
                        var t, n, i = e ? e.ownerDocument || e : q;
                        return i !== j && 9 === i.nodeType && i.documentElement ? (j = i, A = j.documentElement, P = !E(j), (n = j.defaultView) && n.top !== n && (n.addEventListener ? n.addEventListener("unload", xe, !1) : n.attachEvent && n.attachEvent("onunload", xe)), _.attributes = o(function (e) {
                            return e.className = "i", !e.getAttribute("className")
                        }), _.getElementsByTagName = o(function (e) {
                            return e.appendChild(j.createComment("")), !e.getElementsByTagName("*").length
                        }), _.getElementsByClassName = ve.test(j.getElementsByClassName), _.getById = o(function (e) {
                            return A.appendChild(e).id = H, !j.getElementsByName || !j.getElementsByName(H).length
                        }), _.getById ? (x.find.ID = function (e, t) {
                            if ("undefined" != typeof t.getElementById && P) {
                                var n = t.getElementById(e);
                                return n ? [n] : []
                            }
                        }, x.filter.ID = function (e) {
                            var t = e.replace(we, _e);
                            return function (e) {
                                return e.getAttribute("id") === t
                            }
                        }) : (delete x.find.ID, x.filter.ID = function (e) {
                            var t = e.replace(we, _e);
                            return function (e) {
                                var n = "undefined" != typeof e.getAttributeNode && e.getAttributeNode("id");
                                return n && n.value === t
                            }
                        }), x.find.TAG = _.getElementsByTagName ?
                        function (e, t) {
                            return "undefined" != typeof t.getElementsByTagName ? t.getElementsByTagName(e) : _.qsa ? t.querySelectorAll(e) : void 0
                        } : function (e, t) {
                            var n, i = [],
                                o = 0,
                                r = t.getElementsByTagName(e);
                            if ("*" === e) {
                                for (; n = r[o++];) 1 === n.nodeType && i.push(n);
                                return i
                            }
                            return r
                        }, x.find.CLASS = _.getElementsByClassName &&
                        function (e, t) {
                            return "undefined" != typeof t.getElementsByClassName && P ? t.getElementsByClassName(e) : void 0
                        }, I = [], D = [], (_.qsa = ve.test(j.querySelectorAll)) && (o(function (e) {
                            A.appendChild(e).innerHTML = "<a id='" + H + "'></a><select id='" + H + "-\r\\' msallowcapture=''><option selected=''></option></select>", e.querySelectorAll("[msallowcapture^='']").length && D.push("[*^$]=" + ne + "*(?:''|\"\")"), e.querySelectorAll("[selected]").length || D.push("\\[" + ne + "*(?:value|" + te + ")"), e.querySelectorAll("[id~=" + H + "-]").length || D.push("~="), e.querySelectorAll(":checked").length || D.push(":checked"), e.querySelectorAll("a#" + H + "+*").length || D.push(".#.+[+~]")
                        }), o(function (e) {
                            var t = j.createElement("input");
                            t.setAttribute("type", "hidden"), e.appendChild(t).setAttribute("name", "D"), e.querySelectorAll("[name=d]").length && D.push("name" + ne + "*[*^$|!~]?="), e.querySelectorAll(":enabled").length || D.push(":enabled", ":disabled"), e.querySelectorAll("*,:x"), D.push(",.*:")
                        })), (_.matchesSelector = ve.test(R = A.matches || A.webkitMatchesSelector || A.mozMatchesSelector || A.oMatchesSelector || A.msMatchesSelector)) && o(function (e) {
                            _.disconnectedMatch = R.call(e, "div"), R.call(e, "[s!='']:x"), I.push("!=", re)
                        }), D = D.length && new RegExp(D.join("|")), I = I.length && new RegExp(I.join("|")), t = ve.test(A.compareDocumentPosition), F = t || ve.test(A.contains) ?
                        function (e, t) {
                            var n = 9 === e.nodeType ? e.documentElement : e,
                                i = t && t.parentNode;
                            return e === i || !(!i || 1 !== i.nodeType || !(n.contains ? n.contains(i) : e.compareDocumentPosition && 16 & e.compareDocumentPosition(i)))
                        } : function (e, t) {
                            if (t) for (; t = t.parentNode;) if (t === e) return !0;
                            return !1
                        }, U = t ?
                        function (e, t) {
                            if (e === t) return N = !0, 0;
                            var n = !e.compareDocumentPosition - !t.compareDocumentPosition;
                            return n ? n : (n = (e.ownerDocument || e) === (t.ownerDocument || t) ? e.compareDocumentPosition(t) : 1, 1 & n || !_.sortDetached && t.compareDocumentPosition(e) === n ? e === j || e.ownerDocument === q && F(q, e) ? -1 : t === j || t.ownerDocument === q && F(q, t) ? 1 : O ? ee(O, e) - ee(O, t) : 0 : 4 & n ? -1 : 1)
                        } : function (e, t) {
                            if (e === t) return N = !0, 0;
                            var n, i = 0,
                                o = e.parentNode,
                                r = t.parentNode,
                                a = [e],
                                l = [t];
                            if (!o || !r) return e === j ? -1 : t === j ? 1 : o ? -1 : r ? 1 : O ? ee(O, e) - ee(O, t) : 0;
                            if (o === r) return s(e, t);
                            for (n = e; n = n.parentNode;) a.unshift(n);
                            for (n = t; n = n.parentNode;) l.unshift(n);
                            for (; a[i] === l[i];) i++;
                            return i ? s(a[i], l[i]) : a[i] === q ? -1 : l[i] === q ? 1 : 0
                        }, j) : j
                    }, t.matches = function (e, n) {
                        return t(e, null, null, n)
                    }, t.matchesSelector = function (e, n) {
                        if ((e.ownerDocument || e) !== j && L(e), n = n.replace(ce, "='$1']"), _.matchesSelector && P && !V[n + " "] && (!I || !I.test(n)) && (!D || !D.test(n))) try {
                            var i = R.call(e, n);
                            if (i || _.disconnectedMatch || e.document && 11 !== e.document.nodeType) return i
                        } catch (e) {}
                        return t(n, j, null, [e]).length > 0
                    }, t.contains = function (e, t) {
                        return (e.ownerDocument || e) !== j && L(e), F(e, t)
                    }, t.attr = function (e, t) {
                        (e.ownerDocument || e) !== j && L(e);
                        var n = x.attrHandle[t.toLowerCase()],
                            i = n && X.call(x.attrHandle, t.toLowerCase()) ? n(e, t, !P) : void 0;
                        return void 0 !== i ? i : _.attributes || !P ? e.getAttribute(t) : (i = e.getAttributeNode(t)) && i.specified ? i.value : null
                    }, t.error = function (e) {
                        throw new Error("Syntax error, unrecognized expression: " + e)
                    }, t.uniqueSort = function (e) {
                        var t, n = [],
                            i = 0,
                            o = 0;
                        if (N = !_.detectDuplicates, O = !_.sortStable && e.slice(0), e.sort(U), N) {
                            for (; t = e[o++];) t === e[o] && (i = n.push(o));
                            for (; i--;) e.splice(n[i], 1)
                        }
                        return O = null, e
                    }, S = t.getText = function (e) {
                        var t, n = "",
                            i = 0,
                            o = e.nodeType;
                        if (o) {
                            if (1 === o || 9 === o || 11 === o) {
                                if ("string" == typeof e.textContent) return e.textContent;
                                for (e = e.firstChild; e; e = e.nextSibling) n += S(e)
                            } else if (3 === o || 4 === o) return e.nodeValue
                        } else for (; t = e[i++];) n += S(t);
                        return n
                    }, x = t.selectors = {
                        cacheLength: 50,
                        createPseudo: i,
                        match: fe,
                        attrHandle: {},
                        find: {},
                        relative: {
                            ">": {
                                dir: "parentNode",
                                first: !0
                            },
                            " ": {
                                dir: "parentNode"
                            },
                            "+": {
                                dir: "previousSibling",
                                first: !0
                            },
                            "~": {
                                dir: "previousSibling"
                            }
                        },
                        preFilter: {
                            ATTR: function (e) {
                                return e[1] = e[1].replace(we, _e), e[3] = (e[3] || e[4] || e[5] || "").replace(we, _e), "~=" === e[2] && (e[3] = " " + e[3] + " "), e.slice(0, 4)
                            },
                            CHILD: function (e) {
                                return e[1] = e[1].toLowerCase(), "nth" === e[1].slice(0, 3) ? (e[3] || t.error(e[0]), e[4] = +(e[4] ? e[5] + (e[6] || 1) : 2 * ("even" === e[3] || "odd" === e[3])), e[5] = +(e[7] + e[8] || "odd" === e[3])) : e[3] && t.error(e[0]), e
                            },
                            PSEUDO: function (e) {
                                var t, n = !e[6] && e[2];
                                return fe.CHILD.test(e[0]) ? null : (e[3] ? e[2] = e[4] || e[5] || "" : n && pe.test(n) && (t = T(n, !0)) && (t = n.indexOf(")", n.length - t) - n.length) && (e[0] = e[0].slice(0, t), e[2] = n.slice(0, t)), e.slice(0, 3))
                            }
                        },
                        filter: {
                            TAG: function (e) {
                                var t = e.replace(we, _e).toLowerCase();
                                return "*" === e ?
                                function () {
                                    return !0
                                } : function (e) {
                                    return e.nodeName && e.nodeName.toLowerCase() === t
                                }
                            },
                            CLASS: function (e) {
                                var t = z[e + " "];
                                return t || (t = new RegExp("(^|" + ne + ")" + e + "(" + ne + "|$)")) && z(e, function (e) {
                                    return t.test("string" == typeof e.className && e.className || "undefined" != typeof e.getAttribute && e.getAttribute("class") || "")
                                })
                            },
                            ATTR: function (e, n, i) {
                                return function (o) {
                                    var r = t.attr(o, e);
                                    return null == r ? "!=" === n : !n || (r += "", "=" === n ? r === i : "!=" === n ? r !== i : "^=" === n ? i && 0 === r.indexOf(i) : "*=" === n ? i && r.indexOf(i) > -1 : "$=" === n ? i && r.slice(-i.length) === i : "~=" === n ? (" " + r.replace(se, " ") + " ").indexOf(i) > -1 : "|=" === n && (r === i || r.slice(0, i.length + 1) === i + "-"))
                                }
                            },
                            CHILD: function (e, t, n, i, o) {
                                var r = "nth" !== e.slice(0, 3),
                                    s = "last" !== e.slice(-4),
                                    a = "of-type" === t;
                                return 1 === i && 0 === o ?
                                function (e) {
                                    return !!e.parentNode
                                } : function (t, n, l) {
                                    var u, c, p, d, f, h, y = r !== s ? "nextSibling" : "previousSibling",
                                        v = t.parentNode,
                                        m = a && t.nodeName.toLowerCase(),
                                        g = !l && !a,
                                        b = !1;
                                    if (v) {
                                        if (r) {
                                            for (; y;) {
                                                for (d = t; d = d[y];) if (a ? d.nodeName.toLowerCase() === m : 1 === d.nodeType) return !1;
                                                h = y = "only" === e && !h && "nextSibling"
                                            }
                                            return !0
                                        }
                                        if (h = [s ? v.firstChild : v.lastChild], s && g) {
                                            for (d = v, p = d[H] || (d[H] = {}), c = p[d.uniqueID] || (p[d.uniqueID] = {}), u = c[e] || [], f = u[0] === B && u[1], b = f && u[2], d = f && v.childNodes[f]; d = ++f && d && d[y] || (b = f = 0) || h.pop();) if (1 === d.nodeType && ++b && d === t) {
                                                c[e] = [B, f, b];
                                                break
                                            }
                                        } else if (g && (d = t, p = d[H] || (d[H] = {}), c = p[d.uniqueID] || (p[d.uniqueID] = {}), u = c[e] || [], f = u[0] === B && u[1], b = f), b === !1) for (;
                                        (d = ++f && d && d[y] || (b = f = 0) || h.pop()) && ((a ? d.nodeName.toLowerCase() !== m : 1 !== d.nodeType) || !++b || (g && (p = d[H] || (d[H] = {}), c = p[d.uniqueID] || (p[d.uniqueID] = {}), c[e] = [B, b]), d !== t)););
                                        return b -= o, b === i || b % i === 0 && b / i >= 0
                                    }
                                }
                            },
                            PSEUDO: function (e, n) {
                                var o, r = x.pseudos[e] || x.setFilters[e.toLowerCase()] || t.error("unsupported pseudo: " + e);
                                return r[H] ? r(n) : r.length > 1 ? (o = [e, e, "", n], x.setFilters.hasOwnProperty(e.toLowerCase()) ? i(function (e, t) {
                                    for (var i, o = r(e, n), s = o.length; s--;) i = ee(e, o[s]), e[i] = !(t[i] = o[s])
                                }) : function (e) {
                                    return r(e, 0, o)
                                }) : r
                            }
                        },
                        pseudos: {
                            not: i(function (e) {
                                var t = [],
                                    n = [],
                                    o = C(e.replace(ae, "$1"));
                                return o[H] ? i(function (e, t, n, i) {
                                    for (var r, s = o(e, null, i, []), a = e.length; a--;)(r = s[a]) && (e[a] = !(t[a] = r))
                                }) : function (e, i, r) {
                                    return t[0] = e, o(t, null, r, n), t[0] = null, !n.pop()
                                }
                            }),
                            has: i(function (e) {
                                return function (n) {
                                    return t(e, n).length > 0
                                }
                            }),
                            contains: i(function (e) {
                                return e = e.replace(we, _e), function (t) {
                                    return (t.textContent || t.innerText || S(t)).indexOf(e) > -1
                                }
                            }),
                            lang: i(function (e) {
                                return de.test(e || "") || t.error("unsupported lang: " + e), e = e.replace(we, _e).toLowerCase(), function (t) {
                                    var n;
                                    do
                                    if (n = P ? t.lang : t.getAttribute("xml:lang") || t.getAttribute("lang")) return n = n.toLowerCase(), n === e || 0 === n.indexOf(e + "-");
                                    while ((t = t.parentNode) && 1 === t.nodeType);
                                    return !1
                                }
                            }),
                            target: function (t) {
                                var n = e.location && e.location.hash;
                                return n && n.slice(1) === t.id
                            },
                            root: function (e) {
                                return e === A
                            },
                            focus: function (e) {
                                return e === j.activeElement && (!j.hasFocus || j.hasFocus()) && !! (e.type || e.href || ~e.tabIndex)
                            },
                            enabled: function (e) {
                                return e.disabled === !1
                            },
                            disabled: function (e) {
                                return e.disabled === !0
                            },
                            checked: function (e) {
                                var t = e.nodeName.toLowerCase();
                                return "input" === t && !! e.checked || "option" === t && !! e.selected
                            },
                            selected: function (e) {
                                return e.parentNode && e.parentNode.selectedIndex, e.selected === !0
                            },
                            empty: function (e) {
                                for (e = e.firstChild; e; e = e.nextSibling) if (e.nodeType < 6) return !1;
                                return !0
                            },
                            parent: function (e) {
                                return !x.pseudos.empty(e)
                            },
                            header: function (e) {
                                return ye.test(e.nodeName)
                            },
                            input: function (e) {
                                return he.test(e.nodeName)
                            },
                            button: function (e) {
                                var t = e.nodeName.toLowerCase();
                                return "input" === t && "button" === e.type || "button" === t
                            },
                            text: function (e) {
                                var t;
                                return "input" === e.nodeName.toLowerCase() && "text" === e.type && (null == (t = e.getAttribute("type")) || "text" === t.toLowerCase())
                            },
                            first: u(function () {
                                return [0]
                            }),
                            last: u(function (e, t) {
                                return [t - 1]
                            }),
                            eq: u(function (e, t, n) {
                                return [0 > n ? n + t : n]
                            }),
                            even: u(function (e, t) {
                                for (var n = 0; t > n; n += 2) e.push(n);
                                return e
                            }),
                            odd: u(function (e, t) {
                                for (var n = 1; t > n; n += 2) e.push(n);
                                return e
                            }),
                            lt: u(function (e, t, n) {
                                for (var i = 0 > n ? n + t : n; --i >= 0;) e.push(i);
                                return e
                            }),
                            gt: u(function (e, t, n) {
                                for (var i = 0 > n ? n + t : n; ++i < t;) e.push(i);
                                return e
                            })
                        }
                    }, x.pseudos.nth = x.pseudos.eq;
                    for (w in {
                        radio: !0,
                        checkbox: !0,
                        file: !0,
                        password: !0,
                        image: !0
                    }) x.pseudos[w] = a(w);
                    for (w in {
                        submit: !0,
                        reset: !0
                    }) x.pseudos[w] = l(w);
                    return p.prototype = x.filters = x.pseudos, x.setFilters = new p, T = t.tokenize = function (e, n) {
                        var i, o, r, s, a, l, u, c = W[e + " "];
                        if (c) return n ? 0 : c.slice(0);
                        for (a = e, l = [], u = x.preFilter; a;) {
                            i && !(o = le.exec(a)) || (o && (a = a.slice(o[0].length) || a), l.push(r = [])), i = !1, (o = ue.exec(a)) && (i = o.shift(), r.push({
                                value: i,
                                type: o[0].replace(ae, " ")
                            }), a = a.slice(i.length));
                            for (s in x.filter)!(o = fe[s].exec(a)) || u[s] && !(o = u[s](o)) || (i = o.shift(), r.push({
                                value: i,
                                type: s,
                                matches: o
                            }), a = a.slice(i.length));
                            if (!i) break
                        }
                        return n ? a.length : a ? t.error(e) : W(e, l).slice(0)
                    }, C = t.compile = function (e, t) {
                        var n, i = [],
                            o = [],
                            r = V[e + " "];
                        if (!r) {
                            for (t || (t = T(e)), n = t.length; n--;) r = g(t[n]), r[H] ? i.push(r) : o.push(r);
                            r = V(e, b(o, i)), r.selector = e
                        }
                        return r
                    }, k = t.select = function (e, t, n, i) {
                        var o, r, s, a, l, u = "function" == typeof e && e,
                            p = !i && T(e = u.selector || e);
                        if (n = n || [], 1 === p.length) {
                            if (r = p[0] = p[0].slice(0), r.length > 2 && "ID" === (s = r[0]).type && _.getById && 9 === t.nodeType && P && x.relative[r[1].type]) {
                                if (t = (x.find.ID(s.matches[0].replace(we, _e), t) || [])[0], !t) return n;
                                u && (t = t.parentNode), e = e.slice(r.shift().value.length)
                            }
                            for (o = fe.needsContext.test(e) ? 0 : r.length; o-- && (s = r[o], !x.relative[a = s.type]);) if ((l = x.find[a]) && (i = l(s.matches[0].replace(we, _e), ge.test(r[0].type) && c(t.parentNode) || t))) {
                                if (r.splice(o, 1), e = i.length && d(r), !e) return J.apply(n, i), n;
                                break
                            }
                        }
                        return (u || C(e, p))(i, t, !P, n, !t || ge.test(e) && c(t.parentNode) || t), n
                    }, _.sortStable = H.split("").sort(U).join("") === H, _.detectDuplicates = !! N, L(), _.sortDetached = o(function (e) {
                        return 1 & e.compareDocumentPosition(j.createElement("div"))
                    }), o(function (e) {
                        return e.innerHTML = "<a href='#'></a>", "#" === e.firstChild.getAttribute("href")
                    }) || r("type|href|height|width", function (e, t, n) {
                        return n ? void 0 : e.getAttribute(t, "type" === t.toLowerCase() ? 1 : 2)
                    }), _.attributes && o(function (e) {
                        return e.innerHTML = "<input/>", e.firstChild.setAttribute("value", ""), "" === e.firstChild.getAttribute("value")
                    }) || r("value", function (e, t, n) {
                        return n || "input" !== e.nodeName.toLowerCase() ? void 0 : e.defaultValue
                    }), o(function (e) {
                        return null == e.getAttribute("disabled")
                    }) || r(te, function (e, t, n) {
                        var i;
                        return n ? void 0 : e[t] === !0 ? t.toLowerCase() : (i = e.getAttributeNode(t)) && i.specified ? i.value : null
                    }), t
                }(s);
                be.find = Ee, be.expr = Ee.selectors, be.expr[":"] = be.expr.pseudos, be.uniqueSort = be.unique = Ee.uniqueSort, be.text = Ee.getText, be.isXMLDoc = Ee.isXML, be.contains = Ee.contains;
                var Te = function (e, t, n) {
                    for (var i = [], o = void 0 !== n;
                    (e = e[t]) && 9 !== e.nodeType;) if (1 === e.nodeType) {
                        if (o && be(e).is(n)) break;
                        i.push(e)
                    }
                    return i
                },
                    Ce = function (e, t) {
                        for (var n = []; e; e = e.nextSibling) 1 === e.nodeType && e !== t && n.push(e);
                        return n
                    },
                    ke = be.expr.match.needsContext,
                    Me = /^<([\w-]+)\s*\/?>(?:<\/\1>|)$/,
                    Oe = /^.[^:#\[\.,]*$/;
                be.filter = function (e, t, n) {
                    var i = t[0];
                    return n && (e = ":not(" + e + ")"), 1 === t.length && 1 === i.nodeType ? be.find.matchesSelector(i, e) ? [i] : [] : be.find.matches(e, be.grep(t, function (e) {
                        return 1 === e.nodeType
                    }))
                }, be.fn.extend({
                    find: function (e) {
                        var t, n = [],
                            i = this,
                            o = i.length;
                        if ("string" != typeof e) return this.pushStack(be(e).filter(function () {
                            for (t = 0; o > t; t++) if (be.contains(i[t], this)) return !0
                        }));
                        for (t = 0; o > t; t++) be.find(e, i[t], n);
                        return n = this.pushStack(o > 1 ? be.unique(n) : n), n.selector = this.selector ? this.selector + " " + e : e, n
                    },
                    filter: function (e) {
                        return this.pushStack(u(this, e || [], !1))
                    },
                    not: function (e) {
                        return this.pushStack(u(this, e || [], !0))
                    },
                    is: function (e) {
                        return !!u(this, "string" == typeof e && ke.test(e) ? be(e) : e || [], !1).length
                    }
                });
                var Ne, Le = /^(?:\s*(<[\w\W]+>)[^>]*|#([\w-]*))$/,
                    je = be.fn.init = function (e, t, n) {
                        var i, o;
                        if (!e) return this;
                        if (n = n || Ne, "string" == typeof e) {
                            if (i = "<" === e.charAt(0) && ">" === e.charAt(e.length - 1) && e.length >= 3 ? [null, e, null] : Le.exec(e), !i || !i[1] && t) return !t || t.jquery ? (t || n).find(e) : this.constructor(t).find(e);
                            if (i[1]) {
                                if (t = t instanceof be ? t[0] : t, be.merge(this, be.parseHTML(i[1], t && t.nodeType ? t.ownerDocument || t : ue, !0)), Me.test(i[1]) && be.isPlainObject(t)) for (i in t) be.isFunction(this[i]) ? this[i](t[i]) : this.attr(i, t[i]);
                                return this
                            }
                            if (o = ue.getElementById(i[2]), o && o.parentNode) {
                                if (o.id !== i[2]) return Ne.find(e);
                                this.length = 1, this[0] = o
                            }
                            return this.context = ue, this.selector = e, this
                        }
                        return e.nodeType ? (this.context = this[0] = e, this.length = 1, this) : be.isFunction(e) ? "undefined" != typeof n.ready ? n.ready(e) : e(be) : (void 0 !== e.selector && (this.selector = e.selector, this.context = e.context), be.makeArray(e, this))
                    };
                je.prototype = be.fn, Ne = be(ue);
                var Ae = /^(?:parents|prev(?:Until|All))/,
                    Pe = {
                        children: !0,
                        contents: !0,
                        next: !0,
                        prev: !0
                    };
                be.fn.extend({
                    has: function (e) {
                        var t, n = be(e, this),
                            i = n.length;
                        return this.filter(function () {
                            for (t = 0; i > t; t++) if (be.contains(this, n[t])) return !0
                        })
                    },
                    closest: function (e, t) {
                        for (var n, i = 0, o = this.length, r = [], s = ke.test(e) || "string" != typeof e ? be(e, t || this.context) : 0; o > i; i++) for (n = this[i]; n && n !== t; n = n.parentNode) if (n.nodeType < 11 && (s ? s.index(n) > -1 : 1 === n.nodeType && be.find.matchesSelector(n, e))) {
                            r.push(n);
                            break
                        }
                        return this.pushStack(r.length > 1 ? be.uniqueSort(r) : r)
                    },
                    index: function (e) {
                        return e ? "string" == typeof e ? be.inArray(this[0], be(e)) : be.inArray(e.jquery ? e[0] : e, this) : this[0] && this[0].parentNode ? this.first().prevAll().length : -1
                    },
                    add: function (e, t) {
                        return this.pushStack(be.uniqueSort(be.merge(this.get(), be(e, t))))
                    },
                    addBack: function (e) {
                        return this.add(null == e ? this.prevObject : this.prevObject.filter(e))
                    }
                }), be.each({
                    parent: function (e) {
                        var t = e.parentNode;
                        return t && 11 !== t.nodeType ? t : null
                    },
                    parents: function (e) {
                        return Te(e, "parentNode")
                    },
                    parentsUntil: function (e, t, n) {
                        return Te(e, "parentNode", n)
                    },
                    next: function (e) {
                        return c(e, "nextSibling")
                    },
                    prev: function (e) {
                        return c(e, "previousSibling")
                    },
                    nextAll: function (e) {
                        return Te(e, "nextSibling")
                    },
                    prevAll: function (e) {
                        return Te(e, "previousSibling")
                    },
                    nextUntil: function (e, t, n) {
                        return Te(e, "nextSibling", n)
                    },
                    prevUntil: function (e, t, n) {
                        return Te(e, "previousSibling", n)
                    },
                    siblings: function (e) {
                        return Ce((e.parentNode || {}).firstChild, e)
                    },
                    children: function (e) {
                        return Ce(e.firstChild)
                    },
                    contents: function (e) {
                        return be.nodeName(e, "iframe") ? e.contentDocument || e.contentWindow.document : be.merge([], e.childNodes)
                    }
                }, function (e, t) {
                    be.fn[e] = function (n, i) {
                        var o = be.map(this, t, n);
                        return "Until" !== e.slice(-5) && (i = n), i && "string" == typeof i && (o = be.filter(i, o)), this.length > 1 && (Pe[e] || (o = be.uniqueSort(o)), Ae.test(e) && (o = o.reverse())), this.pushStack(o)
                    }
                });
                var De = /\S+/g;
                be.Callbacks = function (e) {
                    e = "string" == typeof e ? p(e) : be.extend({}, e);
                    var t, n, i, o, r = [],
                        s = [],
                        a = -1,
                        l = function () {
                            for (o = e.once, i = t = !0; s.length; a = -1) for (n = s.shift(); ++a < r.length;) r[a].apply(n[0], n[1]) === !1 && e.stopOnFalse && (a = r.length, n = !1);
                            e.memory || (n = !1), t = !1, o && (r = n ? [] : "")
                        },
                        u = {
                            add: function () {
                                return r && (n && !t && (a = r.length - 1, s.push(n)), function t(n) {
                                    be.each(n, function (n, i) {
                                        be.isFunction(i) ? e.unique && u.has(i) || r.push(i) : i && i.length && "string" !== be.type(i) && t(i)
                                    })
                                }(arguments), n && !t && l()), this
                            },
                            remove: function () {
                                return be.each(arguments, function (e, t) {
                                    for (var n;
                                    (n = be.inArray(t, r, n)) > -1;) r.splice(n, 1), a >= n && a--
                                }), this
                            },
                            has: function (e) {
                                return e ? be.inArray(e, r) > -1 : r.length > 0
                            },
                            empty: function () {
                                return r && (r = []), this
                            },
                            disable: function () {
                                return o = s = [], r = n = "", this
                            },
                            disabled: function () {
                                return !r
                            },
                            lock: function () {
                                return o = !0, n || u.disable(), this
                            },
                            locked: function () {
                                return !!o
                            },
                            fireWith: function (e, n) {
                                return o || (n = n || [], n = [e, n.slice ? n.slice() : n], s.push(n), t || l()), this
                            },
                            fire: function () {
                                return u.fireWith(this, arguments), this
                            },
                            fired: function () {
                                return !!i
                            }
                        };
                    return u
                }, be.extend({
                    Deferred: function (e) {
                        var t = [
                            ["resolve", "done", be.Callbacks("once memory"), "resolved"],
                            ["reject", "fail", be.Callbacks("once memory"), "rejected"],
                            ["notify", "progress", be.Callbacks("memory")]
                        ],
                            n = "pending",
                            i = {
                                state: function () {
                                    return n
                                },
                                always: function () {
                                    return o.done(arguments).fail(arguments), this
                                },
                                then: function () {
                                    var e = arguments;
                                    return be.Deferred(function (n) {
                                        be.each(t, function (t, r) {
                                            var s = be.isFunction(e[t]) && e[t];
                                            o[r[1]](function () {
                                                var e = s && s.apply(this, arguments);
                                                e && be.isFunction(e.promise) ? e.promise().progress(n.notify).done(n.resolve).fail(n.reject) : n[r[0] + "With"](this === i ? n.promise() : this, s ? [e] : arguments)
                                            })
                                        }), e = null
                                    }).promise()
                                },
                                promise: function (e) {
                                    return null != e ? be.extend(e, i) : i
                                }
                            },
                            o = {};
                        return i.pipe = i.then, be.each(t, function (e, r) {
                            var s = r[2],
                                a = r[3];
                            i[r[1]] = s.add, a && s.add(function () {
                                n = a
                            }, t[1 ^ e][2].disable, t[2][2].lock), o[r[0]] = function () {
                                return o[r[0] + "With"](this === o ? i : this, arguments), this
                            }, o[r[0] + "With"] = s.fireWith
                        }), i.promise(o), e && e.call(o, o), o
                    },
                    when: function (e) {
                        var t, n, i, o = 0,
                            r = ce.call(arguments),
                            s = r.length,
                            a = 1 !== s || e && be.isFunction(e.promise) ? s : 0,
                            l = 1 === a ? e : be.Deferred(),
                            u = function (e, n, i) {
                                return function (o) {
                                    n[e] = this, i[e] = arguments.length > 1 ? ce.call(arguments) : o, i === t ? l.notifyWith(n, i) : --a || l.resolveWith(n, i)
                                }
                            };
                        if (s > 1) for (t = new Array(s), n = new Array(s), i = new Array(s); s > o; o++) r[o] && be.isFunction(r[o].promise) ? r[o].promise().progress(u(o, n, t)).done(u(o, i, r)).fail(l.reject) : --a;
                        return a || l.resolveWith(i, r), l.promise()
                    }
                });
                var Ie;
                be.fn.ready = function (e) {
                    return be.ready.promise().done(e), this
                }, be.extend({
                    isReady: !1,
                    readyWait: 1,
                    holdReady: function (e) {
                        e ? be.readyWait++ : be.ready(!0)
                    },
                    ready: function (e) {
                        (e === !0 ? --be.readyWait : be.isReady) || (be.isReady = !0, e !== !0 && --be.readyWait > 0 || (Ie.resolveWith(ue, [be]), be.fn.triggerHandler && (be(ue).triggerHandler("ready"), be(ue).off("ready"))))
                    }
                }), be.ready.promise = function (e) {
                    if (!Ie) if (Ie = be.Deferred(), "complete" === ue.readyState || "loading" !== ue.readyState && !ue.documentElement.doScroll) s.setTimeout(be.ready);
                    else if (ue.addEventListener) ue.addEventListener("DOMContentLoaded", f), s.addEventListener("load", f);
                    else {
                        ue.attachEvent("onreadystatechange", f), s.attachEvent("onload", f);
                        var t = !1;
                        try {
                            t = null == s.frameElement && ue.documentElement
                        } catch (e) {}
                        t && t.doScroll && !
                        function e() {
                            if (!be.isReady) {
                                try {
                                    t.doScroll("left")
                                } catch (t) {
                                    return s.setTimeout(e, 50)
                                }
                                d(), be.ready()
                            }
                        }()
                    }
                    return Ie.promise(e)
                }, be.ready.promise();
                var Re;
                for (Re in be(me)) break;
                me.ownFirst = "0" === Re, me.inlineBlockNeedsLayout = !1, be(function () {
                    var e, t, n, i;
                    n = ue.getElementsByTagName("body")[0], n && n.style && (t = ue.createElement("div"), i = ue.createElement("div"), i.style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", n.appendChild(i).appendChild(t), "undefined" != typeof t.style.zoom && (t.style.cssText = "display:inline;margin:0;border:0;padding:1px;width:1px;zoom:1", me.inlineBlockNeedsLayout = e = 3 === t.offsetWidth, e && (n.style.zoom = 1)), n.removeChild(i))
                }), function () {
                    var e = ue.createElement("div");
                    me.deleteExpando = !0;
                    try {
                        delete e.test
                    } catch (e) {
                        me.deleteExpando = !1
                    }
                    e = null
                }();
                var Fe = function (e) {
                    var t = be.noData[(e.nodeName + " ").toLowerCase()],
                        n = +e.nodeType || 1;
                    return (1 === n || 9 === n) && (!t || t !== !0 && e.getAttribute("classid") === t)
                },
                    He = /^(?:\{[\w\W]*\}|\[[\w\W]*\])$/,
                    qe = /([A-Z])/g;
                be.extend({
                    cache: {},
                    noData: {
                        "applet ": !0,
                        "embed ": !0,
                        "object ": "clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"
                    },
                    hasData: function (e) {
                        return e = e.nodeType ? be.cache[e[be.expando]] : e[be.expando], !! e && !y(e)
                    },
                    data: function (e, t, n) {
                        return v(e, t, n)
                    },
                    removeData: function (e, t) {
                        return m(e, t)
                    },
                    _data: function (e, t, n) {
                        return v(e, t, n, !0)
                    },
                    _removeData: function (e, t) {
                        return m(e, t, !0)
                    }
                }), be.fn.extend({
                    data: function (e, t) {
                        var n, i, o, s = this[0],
                            a = s && s.attributes;
                        if (void 0 === e) {
                            if (this.length && (o = be.data(s), 1 === s.nodeType && !be._data(s, "parsedAttrs"))) {
                                for (n = a.length; n--;) a[n] && (i = a[n].name, 0 === i.indexOf("data-") && (i = be.camelCase(i.slice(5)), h(s, i, o[i])));
                                be._data(s, "parsedAttrs", !0)
                            }
                            return o
                        }
                        return "object" == ("undefined" == typeof e ? "undefined" : r(e)) ? this.each(function () {
                            be.data(this, e)
                        }) : arguments.length > 1 ? this.each(function () {
                            be.data(this, e, t)
                        }) : s ? h(s, e, be.data(s, e)) : void 0
                    },
                    removeData: function (e) {
                        return this.each(function () {
                            be.removeData(this, e)
                        })
                    }
                }), be.extend({
                    queue: function (e, t, n) {
                        var i;
                        return e ? (t = (t || "fx") + "queue", i = be._data(e, t), n && (!i || be.isArray(n) ? i = be._data(e, t, be.makeArray(n)) : i.push(n)), i || []) : void 0
                    },
                    dequeue: function (e, t) {
                        t = t || "fx";
                        var n = be.queue(e, t),
                            i = n.length,
                            o = n.shift(),
                            r = be._queueHooks(e, t),
                            s = function () {
                                be.dequeue(e, t)
                            };
                        "inprogress" === o && (o = n.shift(), i--), o && ("fx" === t && n.unshift("inprogress"), delete r.stop, o.call(e, s, r)), !i && r && r.empty.fire()
                    },
                    _queueHooks: function (e, t) {
                        var n = t + "queueHooks";
                        return be._data(e, n) || be._data(e, n, {
                            empty: be.Callbacks("once memory").add(function () {
                                be._removeData(e, t + "queue"), be._removeData(e, n)
                            })
                        })
                    }
                }), be.fn.extend({
                    queue: function (e, t) {
                        var n = 2;
                        return "string" != typeof e && (t = e, e = "fx", n--), arguments.length < n ? be.queue(this[0], e) : void 0 === t ? this : this.each(function () {
                            var n = be.queue(this, e, t);
                            be._queueHooks(this, e), "fx" === e && "inprogress" !== n[0] && be.dequeue(this, e)
                        })
                    },
                    dequeue: function (e) {
                        return this.each(function () {
                            be.dequeue(this, e)
                        })
                    },
                    clearQueue: function (e) {
                        return this.queue(e || "fx", [])
                    },
                    promise: function (e, t) {
                        var n, i = 1,
                            o = be.Deferred(),
                            r = this,
                            s = this.length,
                            a = function () {
                                --i || o.resolveWith(r, [r])
                            };
                        for ("string" != typeof e && (t = e, e = void 0), e = e || "fx"; s--;) n = be._data(r[s], e + "queueHooks"), n && n.empty && (i++, n.empty.add(a));
                        return a(), o.promise(t)
                    }
                }), function () {
                    var e;
                    me.shrinkWrapBlocks = function () {
                        if (null != e) return e;
                        e = !1;
                        var t, n, i;
                        return n = ue.getElementsByTagName("body")[0], n && n.style ? (t = ue.createElement("div"), i = ue.createElement("div"), i.style.cssText = "position:absolute;border:0;width:0;height:0;top:0;left:-9999px", n.appendChild(i).appendChild(t), "undefined" != typeof t.style.zoom && (t.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:1px;width:1px;zoom:1", t.appendChild(ue.createElement("div")).style.width = "5px", e = 3 !== t.offsetWidth), n.removeChild(i), e) : void 0
                    }
                }();
                var Be = /[+-]?(?:\d*\.|)\d+(?:[eE][+-]?\d+|)/.source,
                    Ge = new RegExp("^(?:([+-])=|)(" + Be + ")([a-z%]*)$", "i"),
                    ze = ["Top", "Right", "Bottom", "Left"],
                    We = function (e, t) {
                        return e = t || e, "none" === be.css(e, "display") || !be.contains(e.ownerDocument, e)
                    },
                    Ve = function e(t, n, i, o, r, s, a) {
                        var l = 0,
                            u = t.length,
                            c = null == i;
                        if ("object" === be.type(i)) {
                            r = !0;
                            for (l in i) e(t, n, l, i[l], !0, s, a)
                        } else if (void 0 !== o && (r = !0, be.isFunction(o) || (a = !0), c && (a ? (n.call(t, o), n = null) : (c = n, n = function (e, t, n) {
                            return c.call(be(e), n)
                        })), n)) for (; u > l; l++) n(t[l], i, a ? o : o.call(t[l], l, n(t[l], i)));
                        return r ? t : c ? n.call(t) : u ? n(t[0], i) : s
                    },
                    Ue = /^(?:checkbox|radio)$/i,
                    $e = /<([\w:-]+)/,
                    Xe = /^$|\/(?:java|ecma)script/i,
                    Ye = /^\s+/,
                    Ke = "abbr|article|aside|audio|bdi|canvas|data|datalist|details|dialog|figcaption|figure|footer|header|hgroup|main|mark|meter|nav|output|picture|progress|section|summary|template|time|video";
                !
                function () {
                    var e = ue.createElement("div"),
                        t = ue.createDocumentFragment(),
                        n = ue.createElement("input");
                    e.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", me.leadingWhitespace = 3 === e.firstChild.nodeType, me.tbody = !e.getElementsByTagName("tbody").length, me.htmlSerialize = !! e.getElementsByTagName("link").length, me.html5Clone = "<:nav></:nav>" !== ue.createElement("nav").cloneNode(!0).outerHTML, n.type = "checkbox", n.checked = !0, t.appendChild(n), me.appendChecked = n.checked, e.innerHTML = "<textarea>x</textarea>", me.noCloneChecked = !! e.cloneNode(!0).lastChild.defaultValue, t.appendChild(e), n = ue.createElement("input"), n.setAttribute("type", "radio"), n.setAttribute("checked", "checked"), n.setAttribute("name", "t"), e.appendChild(n), me.checkClone = e.cloneNode(!0).cloneNode(!0).lastChild.checked, me.noCloneEvent = !! e.addEventListener, e[be.expando] = 1, me.attributes = !e.getAttribute(be.expando)
                }();
                var Qe = {
                    option: [1, "<select multiple='multiple'>", "</select>"],
                    legend: [1, "<fieldset>", "</fieldset>"],
                    area: [1, "<map>", "</map>"],
                    param: [1, "<object>", "</object>"],
                    thead: [1, "<table>", "</table>"],
                    tr: [2, "<table><tbody>", "</tbody></table>"],
                    col: [2, "<table><tbody></tbody><colgroup>", "</colgroup></table>"],
                    td: [3, "<table><tbody><tr>", "</tr></tbody></table>"],
                    _default: me.htmlSerialize ? [0, "", ""] : [1, "X<div>", "</div>"]
                };
                Qe.optgroup = Qe.option, Qe.tbody = Qe.tfoot = Qe.colgroup = Qe.caption = Qe.thead, Qe.th = Qe.td;
                var Je = /<|&#?\w+;/,
                    Ze = /<tbody/i;
                !
                function () {
                    var e, t, n = ue.createElement("div");
                    for (e in {
                        submit: !0,
                        change: !0,
                        focusin: !0
                    }) t = "on" + e, (me[e] = t in s) || (n.setAttribute(t, "t"), me[e] = n.attributes[t].expando === !1);
                    n = null
                }();
                var et = /^(?:input|select|textarea)$/i,
                    tt = /^key/,
                    nt = /^(?:mouse|pointer|contextmenu|drag|drop)|click/,
                    it = /^(?:focusinfocus|focusoutblur)$/,
                    ot = /^([^.]*)(?:\.(.+)|)/;
                be.event = {
                    global: {},
                    add: function (e, t, n, i, o) {
                        var r, s, a, l, u, c, p, d, f, h, y, v = be._data(e);
                        if (v) {
                            for (n.handler && (l = n, n = l.handler, o = l.selector), n.guid || (n.guid = be.guid++), (s = v.events) || (s = v.events = {}), (c = v.handle) || (c = v.handle = function (e) {
                                return "undefined" == typeof be || e && be.event.triggered === e.type ? void 0 : be.event.dispatch.apply(c.elem, arguments)
                            }, c.elem = e), t = (t || "").match(De) || [""], a = t.length; a--;) r = ot.exec(t[a]) || [], f = y = r[1], h = (r[2] || "").split(".").sort(), f && (u = be.event.special[f] || {}, f = (o ? u.delegateType : u.bindType) || f, u = be.event.special[f] || {}, p = be.extend({
                                type: f,
                                origType: y,
                                data: i,
                                handler: n,
                                guid: n.guid,
                                selector: o,
                                needsContext: o && be.expr.match.needsContext.test(o),
                                namespace: h.join(".")
                            }, l), (d = s[f]) || (d = s[f] = [], d.delegateCount = 0, u.setup && u.setup.call(e, i, h, c) !== !1 || (e.addEventListener ? e.addEventListener(f, c, !1) : e.attachEvent && e.attachEvent("on" + f, c))), u.add && (u.add.call(e, p), p.handler.guid || (p.handler.guid = n.guid)), o ? d.splice(d.delegateCount++, 0, p) : d.push(p), be.event.global[f] = !0);
                            e = null
                        }
                    },
                    remove: function (e, t, n, i, o) {
                        var r, s, a, l, u, c, p, d, f, h, y, v = be.hasData(e) && be._data(e);
                        if (v && (c = v.events)) {
                            for (t = (t || "").match(De) || [""], u = t.length; u--;) if (a = ot.exec(t[u]) || [], f = y = a[1], h = (a[2] || "").split(".").sort(), f) {
                                for (p = be.event.special[f] || {}, f = (i ? p.delegateType : p.bindType) || f, d = c[f] || [], a = a[2] && new RegExp("(^|\\.)" + h.join("\\.(?:.*\\.|)") + "(\\.|$)"), l = r = d.length; r--;) s = d[r], !o && y !== s.origType || n && n.guid !== s.guid || a && !a.test(s.namespace) || i && i !== s.selector && ("**" !== i || !s.selector) || (d.splice(r, 1), s.selector && d.delegateCount--, p.remove && p.remove.call(e, s));
                                l && !d.length && (p.teardown && p.teardown.call(e, h, v.handle) !== !1 || be.removeEvent(e, f, v.handle), delete c[f])
                            } else for (f in c) be.event.remove(e, f + t[u], n, i, !0);
                            be.isEmptyObject(c) && (delete v.handle, be._removeData(e, "events"))
                        }
                    },
                    trigger: function (e, t, n, i) {
                        var o, a, l, u, c, p, d, f = [n || ue],
                            h = ve.call(e, "type") ? e.type : e,
                            y = ve.call(e, "namespace") ? e.namespace.split(".") : [];
                        if (l = p = n = n || ue, 3 !== n.nodeType && 8 !== n.nodeType && !it.test(h + be.event.triggered) && (h.indexOf(".") > -1 && (y = h.split("."), h = y.shift(), y.sort()), a = h.indexOf(":") < 0 && "on" + h, e = e[be.expando] ? e : new be.Event(h, "object" == ("undefined" == typeof e ? "undefined" : r(e)) && e), e.isTrigger = i ? 2 : 3, e.namespace = y.join("."), e.rnamespace = e.namespace ? new RegExp("(^|\\.)" + y.join("\\.(?:.*\\.|)") + "(\\.|$)") : null, e.result = void 0, e.target || (e.target = n), t = null == t ? [e] : be.makeArray(t, [e]), c = be.event.special[h] || {}, i || !c.trigger || c.trigger.apply(n, t) !== !1)) {
                            if (!i && !c.noBubble && !be.isWindow(n)) {
                                for (u = c.delegateType || h, it.test(u + h) || (l = l.parentNode); l; l = l.parentNode) f.push(l), p = l;
                                p === (n.ownerDocument || ue) && f.push(p.defaultView || p.parentWindow || s)
                            }
                            for (d = 0;
                            (l = f[d++]) && !e.isPropagationStopped();) e.type = d > 1 ? u : c.bindType || h, o = (be._data(l, "events") || {})[e.type] && be._data(l, "handle"), o && o.apply(l, t), o = a && l[a], o && o.apply && Fe(l) && (e.result = o.apply(l, t), e.result === !1 && e.preventDefault());
                            if (e.type = h, !i && !e.isDefaultPrevented() && (!c._default || c._default.apply(f.pop(), t) === !1) && Fe(n) && a && n[h] && !be.isWindow(n)) {
                                p = n[a], p && (n[a] = null), be.event.triggered = h;
                                try {
                                    n[h]()
                                } catch (e) {}
                                be.event.triggered = void 0, p && (n[a] = p)
                            }
                            return e.result
                        }
                    },
                    dispatch: function (e) {
                        e = be.event.fix(e);
                        var t, n, i, o, r, s = [],
                            a = ce.call(arguments),
                            l = (be._data(this, "events") || {})[e.type] || [],
                            u = be.event.special[e.type] || {};
                        if (a[0] = e, e.delegateTarget = this, !u.preDispatch || u.preDispatch.call(this, e) !== !1) {
                            for (s = be.event.handlers.call(this, e, l), t = 0;
                            (o = s[t++]) && !e.isPropagationStopped();) for (e.currentTarget = o.elem, n = 0;
                            (r = o.handlers[n++]) && !e.isImmediatePropagationStopped();) e.rnamespace && !e.rnamespace.test(r.namespace) || (e.handleObj = r, e.data = r.data, i = ((be.event.special[r.origType] || {}).handle || r.handler).apply(o.elem, a), void 0 !== i && (e.result = i) === !1 && (e.preventDefault(), e.stopPropagation()));
                            return u.postDispatch && u.postDispatch.call(this, e), e.result
                        }
                    },
                    handlers: function (e, t) {
                        var n, i, o, r, s = [],
                            a = t.delegateCount,
                            l = e.target;
                        if (a && l.nodeType && ("click" !== e.type || isNaN(e.button) || e.button < 1)) for (; l != this; l = l.parentNode || this) if (1 === l.nodeType && (l.disabled !== !0 || "click" !== e.type)) {
                            for (i = [], n = 0; a > n; n++) r = t[n], o = r.selector + " ", void 0 === i[o] && (i[o] = r.needsContext ? be(o, this).index(l) > -1 : be.find(o, this, null, [l]).length), i[o] && i.push(r);
                            i.length && s.push({
                                elem: l,
                                handlers: i
                            })
                        }
                        return a < t.length && s.push({
                            elem: this,
                            handlers: t.slice(a)
                        }), s
                    },
                    fix: function (e) {
                        if (e[be.expando]) return e;
                        var t, n, i, o = e.type,
                            r = e,
                            s = this.fixHooks[o];
                        for (s || (this.fixHooks[o] = s = nt.test(o) ? this.mouseHooks : tt.test(o) ? this.keyHooks : {}), i = s.props ? this.props.concat(s.props) : this.props, e = new be.Event(r), t = i.length; t--;) n = i[t], e[n] = r[n];
                        return e.target || (e.target = r.srcElement || ue), 3 === e.target.nodeType && (e.target = e.target.parentNode), e.metaKey = !! e.metaKey, s.filter ? s.filter(e, r) : e
                    },
                    props: "altKey bubbles cancelable ctrlKey currentTarget detail eventPhase metaKey relatedTarget shiftKey target timeStamp view which".split(" "),
                    fixHooks: {},
                    keyHooks: {
                        props: "char charCode key keyCode".split(" "),
                        filter: function (e, t) {
                            return null == e.which && (e.which = null != t.charCode ? t.charCode : t.keyCode), e
                        }
                    },
                    mouseHooks: {
                        props: "button buttons clientX clientY fromElement offsetX offsetY pageX pageY screenX screenY toElement".split(" "),
                        filter: function (e, t) {
                            var n, i, o, r = t.button,
                                s = t.fromElement;
                            return null == e.pageX && null != t.clientX && (i = e.target.ownerDocument || ue, o = i.documentElement, n = i.body, e.pageX = t.clientX + (o && o.scrollLeft || n && n.scrollLeft || 0) - (o && o.clientLeft || n && n.clientLeft || 0), e.pageY = t.clientY + (o && o.scrollTop || n && n.scrollTop || 0) - (o && o.clientTop || n && n.clientTop || 0)), !e.relatedTarget && s && (e.relatedTarget = s === e.target ? t.toElement : s), e.which || void 0 === r || (e.which = 1 & r ? 1 : 2 & r ? 3 : 4 & r ? 2 : 0), e
                        }
                    },
                    special: {
                        load: {
                            noBubble: !0
                        },
                        focus: {
                            trigger: function () {
                                if (this !== C() && this.focus) try {
                                    return this.focus(), !1
                                } catch (e) {}
                            },
                            delegateType: "focusin"
                        },
                        blur: {
                            trigger: function () {
                                return this === C() && this.blur ? (this.blur(), !1) : void 0
                            },
                            delegateType: "focusout"
                        },
                        click: {
                            trigger: function () {
                                return be.nodeName(this, "input") && "checkbox" === this.type && this.click ? (this.click(), !1) : void 0
                            },
                            _default: function (e) {
                                return be.nodeName(e.target, "a")
                            }
                        },
                        beforeunload: {
                            postDispatch: function (e) {
                                void 0 !== e.result && e.originalEvent && (e.originalEvent.returnValue = e.result)
                            }
                        }
                    },
                    simulate: function (e, t, n) {
                        var i = be.extend(new be.Event, n, {
                            type: e,
                            isSimulated: !0
                        });
                        be.event.trigger(i, null, t), i.isDefaultPrevented() && n.preventDefault()
                    }
                }, be.removeEvent = ue.removeEventListener ?
                function (e, t, n) {
                    e.removeEventListener && e.removeEventListener(t, n)
                } : function (e, t, n) {
                    var i = "on" + t;
                    e.detachEvent && ("undefined" == typeof e[i] && (e[i] = null), e.detachEvent(i, n))
                }, be.Event = function (e, t) {
                    return this instanceof be.Event ? (e && e.type ? (this.originalEvent = e, this.type = e.type, this.isDefaultPrevented = e.defaultPrevented || void 0 === e.defaultPrevented && e.returnValue === !1 ? E : T) : this.type = e, t && be.extend(this, t), this.timeStamp = e && e.timeStamp || be.now(), void(this[be.expando] = !0)) : new be.Event(e, t)
                }, be.Event.prototype = {
                    constructor: be.Event,
                    isDefaultPrevented: T,
                    isPropagationStopped: T,
                    isImmediatePropagationStopped: T,
                    preventDefault: function () {
                        var e = this.originalEvent;
                        this.isDefaultPrevented = E, e && (e.preventDefault ? e.preventDefault() : e.returnValue = !1)
                    },
                    stopPropagation: function () {
                        var e = this.originalEvent;
                        this.isPropagationStopped = E, e && !this.isSimulated && (e.stopPropagation && e.stopPropagation(), e.cancelBubble = !0)
                    },
                    stopImmediatePropagation: function () {
                        var e = this.originalEvent;
                        this.isImmediatePropagationStopped = E, e && e.stopImmediatePropagation && e.stopImmediatePropagation(), this.stopPropagation()
                    }
                }, be.each({
                    mouseenter: "mouseover",
                    mouseleave: "mouseout",
                    pointerenter: "pointerover",
                    pointerleave: "pointerout"
                }, function (e, t) {
                    be.event.special[e] = {
                        delegateType: t,
                        bindType: t,
                        handle: function (e) {
                            var n, i = this,
                                o = e.relatedTarget,
                                r = e.handleObj;
                            return o && (o === i || be.contains(i, o)) || (e.type = r.origType, n = r.handler.apply(this, arguments), e.type = t), n
                        }
                    }
                }), me.submit || (be.event.special.submit = {
                    setup: function () {
                        return !be.nodeName(this, "form") && void be.event.add(this, "click._submit keypress._submit", function (e) {
                            var t = e.target,
                                n = be.nodeName(t, "input") || be.nodeName(t, "button") ? be.prop(t, "form") : void 0;
                            n && !be._data(n, "submit") && (be.event.add(n, "submit._submit", function (e) {
                                e._submitBubble = !0
                            }), be._data(n, "submit", !0))
                        })
                    },
                    postDispatch: function (e) {
                        e._submitBubble && (delete e._submitBubble, this.parentNode && !e.isTrigger && be.event.simulate("submit", this.parentNode, e))
                    },
                    teardown: function () {
                        return !be.nodeName(this, "form") && void be.event.remove(this, "._submit")
                    }
                }), me.change || (be.event.special.change = {
                    setup: function () {
                        return et.test(this.nodeName) ? ("checkbox" !== this.type && "radio" !== this.type || (be.event.add(this, "propertychange._change", function (e) {
                            "checked" === e.originalEvent.propertyName && (this._justChanged = !0)
                        }), be.event.add(this, "click._change", function (e) {
                            this._justChanged && !e.isTrigger && (this._justChanged = !1), be.event.simulate("change", this, e)
                        })), !1) : void be.event.add(this, "beforeactivate._change", function (e) {
                            var t = e.target;
                            et.test(t.nodeName) && !be._data(t, "change") && (be.event.add(t, "change._change", function (e) {
                                !this.parentNode || e.isSimulated || e.isTrigger || be.event.simulate("change", this.parentNode, e)
                            }), be._data(t, "change", !0))
                        })
                    },
                    handle: function (e) {
                        var t = e.target;
                        return this !== t || e.isSimulated || e.isTrigger || "radio" !== t.type && "checkbox" !== t.type ? e.handleObj.handler.apply(this, arguments) : void 0
                    },
                    teardown: function () {
                        return be.event.remove(this, "._change"), !et.test(this.nodeName)
                    }
                }), me.focusin || be.each({
                    focus: "focusin",
                    blur: "focusout"
                }, function (e, t) {
                    var n = function (e) {
                        be.event.simulate(t, e.target, be.event.fix(e))
                    };
                    be.event.special[t] = {
                        setup: function () {
                            var i = this.ownerDocument || this,
                                o = be._data(i, t);
                            o || i.addEventListener(e, n, !0), be._data(i, t, (o || 0) + 1)
                        },
                        teardown: function () {
                            var i = this.ownerDocument || this,
                                o = be._data(i, t) - 1;
                            o ? be._data(i, t, o) : (i.removeEventListener(e, n, !0), be._removeData(i, t))
                        }
                    }
                }), be.fn.extend({
                    on: function (e, t, n, i) {
                        return k(this, e, t, n, i)
                    },
                    one: function (e, t, n, i) {
                        return k(this, e, t, n, i, 1)
                    },
                    off: function (e, t, n) {
                        var i, o;
                        if (e && e.preventDefault && e.handleObj) return i = e.handleObj, be(e.delegateTarget).off(i.namespace ? i.origType + "." + i.namespace : i.origType, i.selector, i.handler), this;
                        if ("object" == ("undefined" == typeof e ? "undefined" : r(e))) {
                            for (o in e) this.off(o, t, e[o]);
                            return this
                        }
                        return t !== !1 && "function" != typeof t || (n = t, t = void 0), n === !1 && (n = T), this.each(function () {
                            be.event.remove(this, e, n, t)
                        })
                    },
                    trigger: function (e, t) {
                        return this.each(function () {
                            be.event.trigger(e, t, this)
                        })
                    },
                    triggerHandler: function (e, t) {
                        var n = this[0];
                        return n ? be.event.trigger(e, t, n, !0) : void 0
                    }
                });
                var rt = / jQuery\d+="(?:null|\d+)"/g,
                    st = new RegExp("<(?:" + Ke + ")[\\s/>]", "i"),
                    at = /<(?!area|br|col|embed|hr|img|input|link|meta|param)(([\w:-]+)[^>]*)\/>/gi,
                    lt = /<script|<style|<link/i,
                    ut = /checked\s*(?:[^=]|=\s*.checked.)/i,
                    ct = /^true\/(.*)/,
                    pt = /^\s*<!(?:\[CDATA\[|--)|(?:\]\]|--)>\s*$/g,
                    dt = b(ue),
                    ft = dt.appendChild(ue.createElement("div"));
                be.extend({
                    htmlPrefilter: function (e) {
                        return e.replace(at, "<$1></$2>")
                    },
                    clone: function (e, t, n) {
                        var i, o, r, s, a, l = be.contains(e.ownerDocument, e);
                        if (me.html5Clone || be.isXMLDoc(e) || !st.test("<" + e.nodeName + ">") ? r = e.cloneNode(!0) : (ft.innerHTML = e.outerHTML, ft.removeChild(r = ft.firstChild)), !(me.noCloneEvent && me.noCloneChecked || 1 !== e.nodeType && 11 !== e.nodeType || be.isXMLDoc(e))) for (i = w(r), a = w(e), s = 0; null != (o = a[s]); ++s) i[s] && j(o, i[s]);
                        if (t) if (n) for (a = a || w(e), i = i || w(r), s = 0; null != (o = a[s]); s++) L(o, i[s]);
                        else L(e, r);
                        return i = w(r, "script"), i.length > 0 && _(i, !l && w(e, "script")), i = a = o = null, r
                    },
                    cleanData: function (e, t) {
                        for (var n, i, o, r, s = 0, a = be.expando, l = be.cache, u = me.attributes, c = be.event.special; null != (n = e[s]); s++) if ((t || Fe(n)) && (o = n[a], r = o && l[o])) {
                            if (r.events) for (i in r.events) c[i] ? be.event.remove(n, i) : be.removeEvent(n, i, r.handle);
                            l[o] && (delete l[o], u || "undefined" == typeof n.removeAttribute ? n[a] = void 0 : n.removeAttribute(a), le.push(o))
                        }
                    }
                }), be.fn.extend({
                    domManip: A,
                    detach: function (e) {
                        return P(this, e, !0)
                    },
                    remove: function (e) {
                        return P(this, e)
                    },
                    text: function (e) {
                        return Ve(this, function (e) {
                            return void 0 === e ? be.text(this) : this.empty().append((this[0] && this[0].ownerDocument || ue).createTextNode(e))
                        }, null, e, arguments.length)
                    },
                    append: function () {
                        return A(this, arguments, function (e) {
                            if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                                var t = M(this, e);
                                t.appendChild(e)
                            }
                        })
                    },
                    prepend: function () {
                        return A(this, arguments, function (e) {
                            if (1 === this.nodeType || 11 === this.nodeType || 9 === this.nodeType) {
                                var t = M(this, e);
                                t.insertBefore(e, t.firstChild)
                            }
                        })
                    },
                    before: function () {
                        return A(this, arguments, function (e) {
                            this.parentNode && this.parentNode.insertBefore(e, this)
                        })
                    },
                    after: function () {
                        return A(this, arguments, function (e) {
                            this.parentNode && this.parentNode.insertBefore(e, this.nextSibling)
                        })
                    },
                    empty: function () {
                        for (var e, t = 0; null != (e = this[t]); t++) {
                            for (1 === e.nodeType && be.cleanData(w(e, !1)); e.firstChild;) e.removeChild(e.firstChild);
                            e.options && be.nodeName(e, "select") && (e.options.length = 0)
                        }
                        return this
                    },
                    clone: function (e, t) {
                        return e = null != e && e, t = null == t ? e : t, this.map(function () {
                            return be.clone(this, e, t)
                        })
                    },
                    html: function (e) {
                        return Ve(this, function (e) {
                            var t = this[0] || {},
                                n = 0,
                                i = this.length;
                            if (void 0 === e) return 1 === t.nodeType ? t.innerHTML.replace(rt, "") : void 0;
                            if ("string" == typeof e && !lt.test(e) && (me.htmlSerialize || !st.test(e)) && (me.leadingWhitespace || !Ye.test(e)) && !Qe[($e.exec(e) || ["", ""])[1].toLowerCase()]) {
                                e = be.htmlPrefilter(e);
                                try {
                                    for (; i > n; n++) t = this[n] || {}, 1 === t.nodeType && (be.cleanData(w(t, !1)), t.innerHTML = e);
                                    t = 0
                                } catch (e) {}
                            }
                            t && this.empty().append(e)
                        }, null, e, arguments.length)
                    },
                    replaceWith: function () {
                        var e = [];
                        return A(this, arguments, function (t) {
                            var n = this.parentNode;
                            be.inArray(this, e) < 0 && (be.cleanData(w(this)), n && n.replaceChild(t, this))
                        }, e)
                    }
                }), be.each({
                    appendTo: "append",
                    prependTo: "prepend",
                    insertBefore: "before",
                    insertAfter: "after",
                    replaceAll: "replaceWith"
                }, function (e, t) {
                    be.fn[e] = function (e) {
                        for (var n, i = 0, o = [], r = be(e), s = r.length - 1; s >= i; i++) n = i === s ? this : this.clone(!0), be(r[i])[t](n), de.apply(o, n.get());
                        return this.pushStack(o)
                    }
                });
                var ht, yt = {
                    HTML: "block",
                    BODY: "block"
                },
                    vt = /^margin/,
                    mt = new RegExp("^(" + Be + ")(?!px)[a-z%]+$", "i"),
                    gt = function (e, t, n, i) {
                        var o, r, s = {};
                        for (r in t) s[r] = e.style[r], e.style[r] = t[r];
                        o = n.apply(e, i || []);
                        for (r in t) e.style[r] = s[r];
                        return o
                    },
                    bt = ue.documentElement;
                !
                function () {
                    var e, t, n, i, o, r, a = ue.createElement("div"),
                        l = ue.createElement("div");
                    if (l.style) {
                        var u = function () {
                            var u, c, p = ue.documentElement;
                            p.appendChild(a), l.style.cssText = "-webkit-box-sizing:border-box;box-sizing:border-box;position:relative;display:block;margin:auto;border:1px;padding:1px;top:1%;width:50%", e = n = r = !1, t = o = !0, s.getComputedStyle && (c = s.getComputedStyle(l), e = "1%" !== (c || {}).top, r = "2px" === (c || {}).marginLeft, n = "4px" === (c || {
                                width: "4px"
                            }).width, l.style.marginRight = "50%", t = "4px" === (c || {
                                marginRight: "4px"
                            }).marginRight, u = l.appendChild(ue.createElement("div")), u.style.cssText = l.style.cssText = "-webkit-box-sizing:content-box;-moz-box-sizing:content-box;box-sizing:content-box;display:block;margin:0;border:0;padding:0", u.style.marginRight = u.style.width = "0", l.style.width = "1px", o = !parseFloat((s.getComputedStyle(u) || {}).marginRight), l.removeChild(u)), l.style.display = "none", i = 0 === l.getClientRects().length, i && (l.style.display = "", l.innerHTML = "<table><tr><td></td><td>t</td></tr></table>", l.childNodes[0].style.borderCollapse = "separate", u = l.getElementsByTagName("td"), u[0].style.cssText = "margin:0;border:0;padding:0;display:none", i = 0 === u[0].offsetHeight, i && (u[0].style.display = "", u[1].style.display = "none", i = 0 === u[0].offsetHeight)), p.removeChild(a)
                        };
                        l.style.cssText = "float:left;opacity:.5", me.opacity = "0.5" === l.style.opacity, me.cssFloat = !! l.style.cssFloat, l.style.backgroundClip = "content-box", l.cloneNode(!0).style.backgroundClip = "", me.clearCloneStyle = "content-box" === l.style.backgroundClip, a = ue.createElement("div"), a.style.cssText = "border:0;width:8px;height:0;top:0;left:-9999px;padding:0;margin-top:1px;position:absolute", l.innerHTML = "", a.appendChild(l), me.boxSizing = "" === l.style.boxSizing || "" === l.style.MozBoxSizing || "" === l.style.WebkitBoxSizing, be.extend(me, {
                            reliableHiddenOffsets: function () {
                                return null == e && u(), i
                            },
                            boxSizingReliable: function () {
                                return null == e && u(), n
                            },
                            pixelMarginRight: function () {
                                return null == e && u(), t
                            },
                            pixelPosition: function () {
                                return null == e && u(), e
                            },
                            reliableMarginRight: function () {
                                return null == e && u(), o
                            },
                            reliableMarginLeft: function () {
                                return null == e && u(), r
                            }
                        })
                    }
                }();
                var wt, _t, xt = /^(top|right|bottom|left)$/;
                s.getComputedStyle ? (wt = function (e) {
                    var t = e.ownerDocument.defaultView;
                    return t && t.opener || (t = s), t.getComputedStyle(e)
                }, _t = function (e, t, n) {
                    var i, o, r, s, a = e.style;
                    return n = n || wt(e), s = n ? n.getPropertyValue(t) || n[t] : void 0, "" !== s && void 0 !== s || be.contains(e.ownerDocument, e) || (s = be.style(e, t)), n && !me.pixelMarginRight() && mt.test(s) && vt.test(t) && (i = a.width, o = a.minWidth, r = a.maxWidth, a.minWidth = a.maxWidth = a.width = s, s = n.width, a.width = i, a.minWidth = o, a.maxWidth = r), void 0 === s ? s : s + ""
                }) : bt.currentStyle && (wt = function (e) {
                    return e.currentStyle
                }, _t = function (e, t, n) {
                    var i, o, r, s, a = e.style;
                    return n = n || wt(e), s = n ? n[t] : void 0, null == s && a && a[t] && (s = a[t]), mt.test(s) && !xt.test(t) && (i = a.left, o = e.runtimeStyle, r = o && o.left, r && (o.left = e.currentStyle.left), a.left = "fontSize" === t ? "1em" : s, s = a.pixelLeft + "px", a.left = i, r && (o.left = r)), void 0 === s ? s : s + "" || "auto"
                });
                var St = /alpha\([^)]*\)/i,
                    Et = /opacity\s*=\s*([^)]*)/i,
                    Tt = /^(none|table(?!-c[ea]).+)/,
                    Ct = new RegExp("^(" + Be + ")(.*)$", "i"),
                    kt = {
                        position: "absolute",
                        visibility: "hidden",
                        display: "block"
                    },
                    Mt = {
                        letterSpacing: "0",
                        fontWeight: "400"
                    },
                    Ot = ["Webkit", "O", "Moz", "ms"],
                    Nt = ue.createElement("div").style;
                be.extend({
                    cssHooks: {
                        opacity: {
                            get: function (e, t) {
                                if (t) {
                                    var n = _t(e, "opacity");
                                    return "" === n ? "1" : n
                                }
                            }
                        }
                    },
                    cssNumber: {
                        animationIterationCount: !0,
                        columnCount: !0,
                        fillOpacity: !0,
                        flexGrow: !0,
                        flexShrink: !0,
                        fontWeight: !0,
                        lineHeight: !0,
                        opacity: !0,
                        order: !0,
                        orphans: !0,
                        widows: !0,
                        zIndex: !0,
                        zoom: !0
                    },
                    cssProps: {
                        float: me.cssFloat ? "cssFloat" : "styleFloat"
                    },
                    style: function (e, t, n, i) {
                        if (e && 3 !== e.nodeType && 8 !== e.nodeType && e.style) {
                            var o, s, a, l = be.camelCase(t),
                                u = e.style;
                            if (t = be.cssProps[l] || (be.cssProps[l] = F(l) || l), a = be.cssHooks[t] || be.cssHooks[l], void 0 === n) return a && "get" in a && void 0 !== (o = a.get(e, !1, i)) ? o : u[t];
                            if (s = "undefined" == typeof n ? "undefined" : r(n), "string" === s && (o = Ge.exec(n)) && o[1] && (n = g(e, t, o), s = "number"), null != n && n === n && ("number" === s && (n += o && o[3] || (be.cssNumber[l] ? "" : "px")), me.clearCloneStyle || "" !== n || 0 !== t.indexOf("background") || (u[t] = "inherit"), !(a && "set" in a && void 0 === (n = a.set(e, n, i))))) try {
                                u[t] = n
                            } catch (e) {}
                        }
                    },
                    css: function (e, t, n, i) {
                        var o, r, s, a = be.camelCase(t);
                        return t = be.cssProps[a] || (be.cssProps[a] = F(a) || a), s = be.cssHooks[t] || be.cssHooks[a], s && "get" in s && (r = s.get(e, !0, n)), void 0 === r && (r = _t(e, t, i)), "normal" === r && t in Mt && (r = Mt[t]), "" === n || n ? (o = parseFloat(r), n === !0 || isFinite(o) ? o || 0 : r) : r
                    }
                }), be.each(["height", "width"], function (e, t) {
                    be.cssHooks[t] = {
                        get: function (e, n, i) {
                            return n ? Tt.test(be.css(e, "display")) && 0 === e.offsetWidth ? gt(e, kt, function () {
                                return G(e, t, i)
                            }) : G(e, t, i) : void 0
                        },
                        set: function (e, n, i) {
                            var o = i && wt(e);
                            return q(e, n, i ? B(e, t, i, me.boxSizing && "border-box" === be.css(e, "boxSizing", !1, o), o) : 0)
                        }
                    }
                }), me.opacity || (be.cssHooks.opacity = {
                    get: function (e, t) {
                        return Et.test((t && e.currentStyle ? e.currentStyle.filter : e.style.filter) || "") ? .01 * parseFloat(RegExp.$1) + "" : t ? "1" : ""
                    },
                    set: function (e, t) {
                        var n = e.style,
                            i = e.currentStyle,
                            o = be.isNumeric(t) ? "alpha(opacity=" + 100 * t + ")" : "",
                            r = i && i.filter || n.filter || "";
                        n.zoom = 1, (t >= 1 || "" === t) && "" === be.trim(r.replace(St, "")) && n.removeAttribute && (n.removeAttribute("filter"), "" === t || i && !i.filter) || (n.filter = St.test(r) ? r.replace(St, o) : r + " " + o)
                    }
                }), be.cssHooks.marginRight = R(me.reliableMarginRight, function (e, t) {
                    return t ? gt(e, {
                        display: "inline-block"
                    }, _t, [e, "marginRight"]) : void 0
                }), be.cssHooks.marginLeft = R(me.reliableMarginLeft, function (e, t) {
                    return t ? (parseFloat(_t(e, "marginLeft")) || (be.contains(e.ownerDocument, e) ? e.getBoundingClientRect().left - gt(e, {
                        marginLeft: 0
                    }, function () {
                        return e.getBoundingClientRect().left
                    }) : 0)) + "px" : void 0
                }), be.each({
                    margin: "",
                    padding: "",
                    border: "Width"
                }, function (e, t) {
                    be.cssHooks[e + t] = {
                        expand: function (n) {
                            for (var i = 0, o = {}, r = "string" == typeof n ? n.split(" ") : [n]; 4 > i; i++) o[e + ze[i] + t] = r[i] || r[i - 2] || r[0];
                            return o
                        }
                    }, vt.test(e) || (be.cssHooks[e + t].set = q)
                }), be.fn.extend({
                    css: function (e, t) {
                        return Ve(this, function (e, t, n) {
                            var i, o, r = {},
                                s = 0;
                            if (be.isArray(t)) {
                                for (i = wt(e), o = t.length; o > s; s++) r[t[s]] = be.css(e, t[s], !1, i);
                                return r
                            }
                            return void 0 !== n ? be.style(e, t, n) : be.css(e, t)
                        }, e, t, arguments.length > 1)
                    },
                    show: function () {
                        return H(this, !0)
                    },
                    hide: function () {
                        return H(this)
                    },
                    toggle: function (e) {
                        return "boolean" == typeof e ? e ? this.show() : this.hide() : this.each(function () {
                            We(this) ? be(this).show() : be(this).hide()
                        })
                    }
                }), be.Tween = z, z.prototype = {
                    constructor: z,
                    init: function (e, t, n, i, o, r) {
                        this.elem = e, this.prop = n, this.easing = o || be.easing._default, this.options = t, this.start = this.now = this.cur(), this.end = i, this.unit = r || (be.cssNumber[n] ? "" : "px")
                    },
                    cur: function () {
                        var e = z.propHooks[this.prop];
                        return e && e.get ? e.get(this) : z.propHooks._default.get(this)
                    },
                    run: function (e) {
                        var t, n = z.propHooks[this.prop];
                        return this.options.duration ? this.pos = t = be.easing[this.easing](e, this.options.duration * e, 0, 1, this.options.duration) : this.pos = t = e, this.now = (this.end - this.start) * t + this.start, this.options.step && this.options.step.call(this.elem, this.now, this), n && n.set ? n.set(this) : z.propHooks._default.set(this), this
                    }
                }, z.prototype.init.prototype = z.prototype, z.propHooks = {
                    _default: {
                        get: function (e) {
                            var t;
                            return 1 !== e.elem.nodeType || null != e.elem[e.prop] && null == e.elem.style[e.prop] ? e.elem[e.prop] : (t = be.css(e.elem, e.prop, ""), t && "auto" !== t ? t : 0)
                        },
                        set: function (e) {
                            be.fx.step[e.prop] ? be.fx.step[e.prop](e) : 1 !== e.elem.nodeType || null == e.elem.style[be.cssProps[e.prop]] && !be.cssHooks[e.prop] ? e.elem[e.prop] = e.now : be.style(e.elem, e.prop, e.now + e.unit)
                        }
                    }
                }, z.propHooks.scrollTop = z.propHooks.scrollLeft = {
                    set: function (e) {
                        e.elem.nodeType && e.elem.parentNode && (e.elem[e.prop] = e.now)
                    }
                }, be.easing = {
                    linear: function (e) {
                        return e
                    },
                    swing: function (e) {
                        return .5 - Math.cos(e * Math.PI) / 2
                    },
                    _default: "swing"
                }, be.fx = z.prototype.init, be.fx.step = {};
                var Lt, jt, At = /^(?:toggle|show|hide)$/,
                    Pt = /queueHooks$/;
                be.Animation = be.extend(Y, {
                    tweeners: {
                        "*": [function (e, t) {
                            var n = this.createTween(e, t);
                            return g(n.elem, e, Ge.exec(t), n), n
                        }]
                    },
                    tweener: function (e, t) {
                        be.isFunction(e) ? (t = e, e = ["*"]) : e = e.match(De);
                        for (var n, i = 0, o = e.length; o > i; i++) n = e[i], Y.tweeners[n] = Y.tweeners[n] || [], Y.tweeners[n].unshift(t)
                    },
                    prefilters: [$],
                    prefilter: function (e, t) {
                        t ? Y.prefilters.unshift(e) : Y.prefilters.push(e)
                    }
                }), be.speed = function (e, t, n) {
                    var i = e && "object" == ("undefined" == typeof e ? "undefined" : r(e)) ? be.extend({}, e) : {
                        complete: n || !n && t || be.isFunction(e) && e,
                        duration: e,
                        easing: n && t || t && !be.isFunction(t) && t
                    };
                    return i.duration = be.fx.off ? 0 : "number" == typeof i.duration ? i.duration : i.duration in be.fx.speeds ? be.fx.speeds[i.duration] : be.fx.speeds._default, null != i.queue && i.queue !== !0 || (i.queue = "fx"), i.old = i.complete, i.complete = function () {
                        be.isFunction(i.old) && i.old.call(this), i.queue && be.dequeue(this, i.queue)
                    }, i
                }, be.fn.extend({
                    fadeTo: function (e, t, n, i) {
                        return this.filter(We).css("opacity", 0).show().end().animate({
                            opacity: t
                        }, e, n, i)
                    },
                    animate: function (e, t, n, i) {
                        var o = be.isEmptyObject(e),
                            r = be.speed(t, n, i),
                            s = function () {
                                var t = Y(this, be.extend({}, e), r);
                                (o || be._data(this, "finish")) && t.stop(!0)
                            };
                        return s.finish = s, o || r.queue === !1 ? this.each(s) : this.queue(r.queue, s)
                    },
                    stop: function (e, t, n) {
                        var i = function (e) {
                            var t = e.stop;
                            delete e.stop, t(n)
                        };
                        return "string" != typeof e && (n = t, t = e, e = void 0), t && e !== !1 && this.queue(e || "fx", []), this.each(function () {
                            var t = !0,
                                o = null != e && e + "queueHooks",
                                r = be.timers,
                                s = be._data(this);
                            if (o) s[o] && s[o].stop && i(s[o]);
                            else for (o in s) s[o] && s[o].stop && Pt.test(o) && i(s[o]);
                            for (o = r.length; o--;) r[o].elem !== this || null != e && r[o].queue !== e || (r[o].anim.stop(n), t = !1, r.splice(o, 1));
                            !t && n || be.dequeue(this, e)
                        })
                    },
                    finish: function (e) {
                        return e !== !1 && (e = e || "fx"), this.each(function () {
                            var t, n = be._data(this),
                                i = n[e + "queue"],
                                o = n[e + "queueHooks"],
                                r = be.timers,
                                s = i ? i.length : 0;
                            for (n.finish = !0, be.queue(this, e, []), o && o.stop && o.stop.call(this, !0), t = r.length; t--;) r[t].elem === this && r[t].queue === e && (r[t].anim.stop(!0), r.splice(t, 1));
                            for (t = 0; s > t; t++) i[t] && i[t].finish && i[t].finish.call(this);
                            delete n.finish
                        })
                    }
                }), be.each(["toggle", "show", "hide"], function (e, t) {
                    var n = be.fn[t];
                    be.fn[t] = function (e, i, o) {
                        return null == e || "boolean" == typeof e ? n.apply(this, arguments) : this.animate(V(t, !0), e, i, o)
                    }
                }), be.each({
                    slideDown: V("show"),
                    slideUp: V("hide"),
                    slideToggle: V("toggle"),
                    fadeIn: {
                        opacity: "show"
                    },
                    fadeOut: {
                        opacity: "hide"
                    },
                    fadeToggle: {
                        opacity: "toggle"
                    }
                }, function (e, t) {
                    be.fn[e] = function (e, n, i) {
                        return this.animate(t, e, n, i)
                    }
                }), be.timers = [], be.fx.tick = function () {
                    var e, t = be.timers,
                        n = 0;
                    for (Lt = be.now(); n < t.length; n++) e = t[n], e() || t[n] !== e || t.splice(n--, 1);
                    t.length || be.fx.stop(), Lt = void 0
                }, be.fx.timer = function (e) {
                    be.timers.push(e), e() ? be.fx.start() : be.timers.pop()
                }, be.fx.interval = 13, be.fx.start = function () {
                    jt || (jt = s.setInterval(be.fx.tick, be.fx.interval))
                }, be.fx.stop = function () {
                    s.clearInterval(jt), jt = null
                }, be.fx.speeds = {
                    slow: 600,
                    fast: 200,
                    _default: 400
                }, be.fn.delay = function (e, t) {
                    return e = be.fx ? be.fx.speeds[e] || e : e, t = t || "fx", this.queue(t, function (t, n) {
                        var i = s.setTimeout(t, e);
                        n.stop = function () {
                            s.clearTimeout(i)
                        }
                    })
                }, function () {
                    var e, t = ue.createElement("input"),
                        n = ue.createElement("div"),
                        i = ue.createElement("select"),
                        o = i.appendChild(ue.createElement("option"));
                    n = ue.createElement("div"), n.setAttribute("className", "t"), n.innerHTML = "  <link/><table></table><a href='/a'>a</a><input type='checkbox'/>", e = n.getElementsByTagName("a")[0], t.setAttribute("type", "checkbox"), n.appendChild(t), e = n.getElementsByTagName("a")[0], e.style.cssText = "top:1px", me.getSetAttribute = "t" !== n.className, me.style = /top/.test(e.getAttribute("style")), me.hrefNormalized = "/a" === e.getAttribute("href"), me.checkOn = !! t.value, me.optSelected = o.selected, me.enctype = !! ue.createElement("form").enctype, i.disabled = !0, me.optDisabled = !o.disabled, t = ue.createElement("input"), t.setAttribute("value", ""), me.input = "" === t.getAttribute("value"), t.value = "t", t.setAttribute("type", "radio"), me.radioValue = "t" === t.value
                }();
                var Dt = /\r/g,
                    It = /[\x20\t\r\n\f]+/g;
                be.fn.extend({
                    val: function (e) {
                        var t, n, i, o = this[0];
                        return arguments.length ? (i = be.isFunction(e), this.each(function (n) {
                            var o;
                            1 === this.nodeType && (o = i ? e.call(this, n, be(this).val()) : e, null == o ? o = "" : "number" == typeof o ? o += "" : be.isArray(o) && (o = be.map(o, function (e) {
                                return null == e ? "" : e + ""
                            })), t = be.valHooks[this.type] || be.valHooks[this.nodeName.toLowerCase()], t && "set" in t && void 0 !== t.set(this, o, "value") || (this.value = o))
                        })) : o ? (t = be.valHooks[o.type] || be.valHooks[o.nodeName.toLowerCase()], t && "get" in t && void 0 !== (n = t.get(o, "value")) ? n : (n = o.value, "string" == typeof n ? n.replace(Dt, "") : null == n ? "" : n)) : void 0
                    }
                }), be.extend({
                    valHooks: {
                        option: {
                            get: function (e) {
                                var t = be.find.attr(e, "value");
                                return null != t ? t : be.trim(be.text(e)).replace(It, " ")
                            }
                        },
                        select: {
                            get: function (e) {
                                for (var t, n, i = e.options, o = e.selectedIndex, r = "select-one" === e.type || 0 > o, s = r ? null : [], a = r ? o + 1 : i.length, l = 0 > o ? a : r ? o : 0; a > l; l++) if (n = i[l], (n.selected || l === o) && (me.optDisabled ? !n.disabled : null === n.getAttribute("disabled")) && (!n.parentNode.disabled || !be.nodeName(n.parentNode, "optgroup"))) {
                                    if (t = be(n).val(), r) return t;
                                    s.push(t)
                                }
                                return s
                            },
                            set: function (e, t) {
                                for (var n, i, o = e.options, r = be.makeArray(t), s = o.length; s--;) if (i = o[s], be.inArray(be.valHooks.option.get(i), r) > -1) try {
                                    i.selected = n = !0
                                } catch (e) {
                                    i.scrollHeight
                                } else i.selected = !1;
                                return n || (e.selectedIndex = -1), o
                            }
                        }
                    }
                }), be.each(["radio", "checkbox"], function () {
                    be.valHooks[this] = {
                        set: function (e, t) {
                            return be.isArray(t) ? e.checked = be.inArray(be(e).val(), t) > -1 : void 0
                        }
                    }, me.checkOn || (be.valHooks[this].get = function (e) {
                        return null === e.getAttribute("value") ? "on" : e.value
                    })
                });
                var Rt, Ft, Ht = be.expr.attrHandle,
                    qt = /^(?:checked|selected)$/i,
                    Bt = me.getSetAttribute,
                    Gt = me.input;
                be.fn.extend({
                    attr: function (e, t) {
                        return Ve(this, be.attr, e, t, arguments.length > 1)
                    },
                    removeAttr: function (e) {
                        return this.each(function () {
                            be.removeAttr(this, e)
                        })
                    }
                }), be.extend({
                    attr: function (e, t, n) {
                        var i, o, r = e.nodeType;
                        if (3 !== r && 8 !== r && 2 !== r) return "undefined" == typeof e.getAttribute ? be.prop(e, t, n) : (1 === r && be.isXMLDoc(e) || (t = t.toLowerCase(), o = be.attrHooks[t] || (be.expr.match.bool.test(t) ? Ft : Rt)), void 0 !== n ? null === n ? void be.removeAttr(e, t) : o && "set" in o && void 0 !== (i = o.set(e, n, t)) ? i : (e.setAttribute(t, n + ""), n) : o && "get" in o && null !== (i = o.get(e, t)) ? i : (i = be.find.attr(e, t), null == i ? void 0 : i))
                    },
                    attrHooks: {
                        type: {
                            set: function (e, t) {
                                if (!me.radioValue && "radio" === t && be.nodeName(e, "input")) {
                                    var n = e.value;
                                    return e.setAttribute("type", t), n && (e.value = n), t
                                }
                            }
                        }
                    },
                    removeAttr: function (e, t) {
                        var n, i, o = 0,
                            r = t && t.match(De);
                        if (r && 1 === e.nodeType) for (; n = r[o++];) i = be.propFix[n] || n, be.expr.match.bool.test(n) ? Gt && Bt || !qt.test(n) ? e[i] = !1 : e[be.camelCase("default-" + n)] = e[i] = !1 : be.attr(e, n, ""), e.removeAttribute(Bt ? n : i)
                    }
                }), Ft = {
                    set: function (e, t, n) {
                        return t === !1 ? be.removeAttr(e, n) : Gt && Bt || !qt.test(n) ? e.setAttribute(!Bt && be.propFix[n] || n, n) : e[be.camelCase("default-" + n)] = e[n] = !0, n
                    }
                }, be.each(be.expr.match.bool.source.match(/\w+/g), function (e, t) {
                    var n = Ht[t] || be.find.attr;
                    Gt && Bt || !qt.test(t) ? Ht[t] = function (e, t, i) {
                        var o, r;
                        return i || (r = Ht[t], Ht[t] = o, o = null != n(e, t, i) ? t.toLowerCase() : null, Ht[t] = r), o
                    } : Ht[t] = function (e, t, n) {
                        return n ? void 0 : e[be.camelCase("default-" + t)] ? t.toLowerCase() : null
                    }
                }), Gt && Bt || (be.attrHooks.value = {
                    set: function (e, t, n) {
                        return be.nodeName(e, "input") ? void(e.defaultValue = t) : Rt && Rt.set(e, t, n)
                    }
                }), Bt || (Rt = {
                    set: function (e, t, n) {
                        var i = e.getAttributeNode(n);
                        return i || e.setAttributeNode(i = e.ownerDocument.createAttribute(n)), i.value = t += "", "value" === n || t === e.getAttribute(n) ? t : void 0
                    }
                }, Ht.id = Ht.name = Ht.coords = function (e, t, n) {
                    var i;
                    return n ? void 0 : (i = e.getAttributeNode(t)) && "" !== i.value ? i.value : null
                }, be.valHooks.button = {
                    get: function (e, t) {
                        var n = e.getAttributeNode(t);
                        return n && n.specified ? n.value : void 0
                    },
                    set: Rt.set
                }, be.attrHooks.contenteditable = {
                    set: function (e, t, n) {
                        Rt.set(e, "" !== t && t, n)
                    }
                }, be.each(["width", "height"], function (e, t) {
                    be.attrHooks[t] = {
                        set: function (e, n) {
                            return "" === n ? (e.setAttribute(t, "auto"), n) : void 0
                        }
                    }
                })), me.style || (be.attrHooks.style = {
                    get: function (e) {
                        return e.style.cssText || void 0
                    },
                    set: function (e, t) {
                        return e.style.cssText = t + ""
                    }
                });
                var zt = /^(?:input|select|textarea|button|object)$/i,
                    Wt = /^(?:a|area)$/i;
                be.fn.extend({
                    prop: function (e, t) {
                        return Ve(this, be.prop, e, t, arguments.length > 1)
                    },
                    removeProp: function (e) {
                        return e = be.propFix[e] || e, this.each(function () {
                            try {
                                this[e] = void 0, delete this[e]
                            } catch (e) {}
                        })
                    }
                }), be.extend({
                    prop: function (e, t, n) {
                        var i, o, r = e.nodeType;
                        if (3 !== r && 8 !== r && 2 !== r) return 1 === r && be.isXMLDoc(e) || (t = be.propFix[t] || t, o = be.propHooks[t]), void 0 !== n ? o && "set" in o && void 0 !== (i = o.set(e, n, t)) ? i : e[t] = n : o && "get" in o && null !== (i = o.get(e, t)) ? i : e[t]
                    },
                    propHooks: {
                        tabIndex: {
                            get: function (e) {
                                var t = be.find.attr(e, "tabindex");
                                return t ? parseInt(t, 10) : zt.test(e.nodeName) || Wt.test(e.nodeName) && e.href ? 0 : -1
                            }
                        }
                    },
                    propFix: {
                        for: "htmlFor",
                        class: "className"
                    }
                }), me.hrefNormalized || be.each(["href", "src"], function (e, t) {
                    be.propHooks[t] = {
                        get: function (e) {
                            return e.getAttribute(t, 4)
                        }
                    }
                }), me.optSelected || (be.propHooks.selected = {
                    get: function (e) {
                        var t = e.parentNode;
                        return t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex), null
                    },
                    set: function (e) {
                        var t = e.parentNode;
                        t && (t.selectedIndex, t.parentNode && t.parentNode.selectedIndex)
                    }
                }), be.each(["tabIndex", "readOnly", "maxLength", "cellSpacing", "cellPadding", "rowSpan", "colSpan", "useMap", "frameBorder", "contentEditable"], function () {
                    be.propFix[this.toLowerCase()] = this
                }), me.enctype || (be.propFix.enctype = "encoding");
                var Vt = /[\t\r\n\f]/g;
                be.fn.extend({
                    addClass: function (e) {
                        var t, n, i, o, r, s, a, l = 0;
                        if (be.isFunction(e)) return this.each(function (t) {
                            be(this).addClass(e.call(this, t, K(this)))
                        });
                        if ("string" == typeof e && e) for (t = e.match(De) || []; n = this[l++];) if (o = K(n), i = 1 === n.nodeType && (" " + o + " ").replace(Vt, " ")) {
                            for (s = 0; r = t[s++];) i.indexOf(" " + r + " ") < 0 && (i += r + " ");
                            a = be.trim(i), o !== a && be.attr(n, "class", a)
                        }
                        return this
                    },
                    removeClass: function (e) {
                        var t, n, i, o, r, s, a, l = 0;
                        if (be.isFunction(e)) return this.each(function (t) {
                            be(this).removeClass(e.call(this, t, K(this)))
                        });
                        if (!arguments.length) return this.attr("class", "");
                        if ("string" == typeof e && e) for (t = e.match(De) || []; n = this[l++];) if (o = K(n), i = 1 === n.nodeType && (" " + o + " ").replace(Vt, " ")) {
                            for (s = 0; r = t[s++];) for (; i.indexOf(" " + r + " ") > -1;) i = i.replace(" " + r + " ", " ");
                            a = be.trim(i), o !== a && be.attr(n, "class", a)
                        }
                        return this
                    },
                    toggleClass: function (e, t) {
                        var n = "undefined" == typeof e ? "undefined" : r(e);
                        return "boolean" == typeof t && "string" === n ? t ? this.addClass(e) : this.removeClass(e) : be.isFunction(e) ? this.each(function (n) {
                            be(this).toggleClass(e.call(this, n, K(this), t), t)
                        }) : this.each(function () {
                            var t, i, o, r;
                            if ("string" === n) for (i = 0, o = be(this), r = e.match(De) || []; t = r[i++];) o.hasClass(t) ? o.removeClass(t) : o.addClass(t);
                            else void 0 !== e && "boolean" !== n || (t = K(this), t && be._data(this, "__className__", t), be.attr(this, "class", t || e === !1 ? "" : be._data(this, "__className__") || ""))
                        })
                    },
                    hasClass: function (e) {
                        var t, n, i = 0;
                        for (t = " " + e + " "; n = this[i++];) if (1 === n.nodeType && (" " + K(n) + " ").replace(Vt, " ").indexOf(t) > -1) return !0;
                        return !1
                    }
                }), be.each("blur focus focusin focusout load resize scroll unload click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup error contextmenu".split(" "), function (e, t) {
                    be.fn[t] = function (e, n) {
                        return arguments.length > 0 ? this.on(t, null, e, n) : this.trigger(t)
                    }
                }), be.fn.extend({
                    hover: function (e, t) {
                        return this.mouseenter(e).mouseleave(t || e)
                    }
                });
                var Ut = s.location,
                    $t = be.now(),
                    Xt = /\?/,
                    Yt = /(,)|(\[|{)|(}|])|"(?:[^"\\\r\n]|\\["\\\/bfnrt]|\\u[\da-fA-F]{4})*"\s*:?|true|false|null|-?(?!0\d)\d+(?:\.\d+|)(?:[eE][+-]?\d+|)/g;
                be.parseJSON = function (e) {
                    if (s.JSON && s.JSON.parse) return s.JSON.parse(e + "");
                    var t, n = null,
                        i = be.trim(e + "");
                    return i && !be.trim(i.replace(Yt, function (e, i, o, r) {
                        return t && i && (n = 0), 0 === n ? e : (t = o || i, n += !r - !o, "")
                    })) ? Function("return " + i)() : be.error("Invalid JSON: " + e)
                }, be.parseXML = function (e) {
                    var t, n;
                    if (!e || "string" != typeof e) return null;
                    try {
                        s.DOMParser ? (n = new s.DOMParser, t = n.parseFromString(e, "text/xml")) : (t = new s.ActiveXObject("Microsoft.XMLDOM"), t.async = "false", t.loadXML(e))
                    } catch (e) {
                        t = void 0
                    }
                    return t && t.documentElement && !t.getElementsByTagName("parsererror").length || be.error("Invalid XML: " + e), t
                };
                var Kt = /#.*$/,
                    Qt = /([?&])_=[^&]*/,
                    Jt = /^(.*?):[ \t]*([^\r\n]*)\r?$/gm,
                    Zt = /^(?:about|app|app-storage|.+-extension|file|res|widget):$/,
                    en = /^(?:GET|HEAD)$/,
                    tn = /^\/\//,
                    nn = /^([\w.+-]+:)(?:\/\/(?:[^\/?#]*@|)([^\/?#:]*)(?::(\d+)|)|)/,
                    on = {},
                    rn = {},
                    sn = "*/".concat("*"),
                    an = Ut.href,
                    ln = nn.exec(an.toLowerCase()) || [];
                be.extend({
                    active: 0,
                    lastModified: {},
                    etag: {},
                    ajaxSettings: {
                        url: an,
                        type: "GET",
                        isLocal: Zt.test(ln[1]),
                        global: !0,
                        processData: !0,
                        async: !0,
                        contentType: "application/x-www-form-urlencoded; charset=UTF-8",
                        accepts: {
                            "*": sn,
                            text: "text/plain",
                            html: "text/html",
                            xml: "application/xml, text/xml",
                            json: "application/json, text/javascript"
                        },
                        contents: {
                            xml: /\bxml\b/,
                            html: /\bhtml/,
                            json: /\bjson\b/
                        },
                        responseFields: {
                            xml: "responseXML",
                            text: "responseText",
                            json: "responseJSON"
                        },
                        converters: {
                            "* text": String,
                            "text html": !0,
                            "text json": be.parseJSON,
                            "text xml": be.parseXML
                        },
                        flatOptions: {
                            url: !0,
                            context: !0
                        }
                    },
                    ajaxSetup: function (e, t) {
                        return t ? Z(Z(e, be.ajaxSettings), t) : Z(be.ajaxSettings, e)
                    },
                    ajaxPrefilter: Q(on),
                    ajaxTransport: Q(rn),
                    ajax: function (e, t) {
                        function n(e, t, n, i) {
                            var o, r, d, b, w, x = t;
                            2 !== _ && (_ = 2, u && s.clearTimeout(u), p = void 0, l = i || "", S.readyState = e > 0 ? 4 : 0, o = e >= 200 && 300 > e || 304 === e, n && (b = ee(f, S, n)), b = te(f, b, S, o), o ? (f.ifModified && (w = S.getResponseHeader("Last-Modified"), w && (be.lastModified[a] = w), w = S.getResponseHeader("etag"), w && (be.etag[a] = w)), 204 === e || "HEAD" === f.type ? x = "nocontent" : 304 === e ? x = "notmodified" : (x = b.state, r = b.data, d = b.error, o = !d)) : (d = x, !e && x || (x = "error", 0 > e && (e = 0))), S.status = e, S.statusText = (t || x) + "", o ? v.resolveWith(h, [r, x, S]) : v.rejectWith(h, [S, x, d]), S.statusCode(g), g = void 0, c && y.trigger(o ? "ajaxSuccess" : "ajaxError", [S, f, o ? r : d]), m.fireWith(h, [S, x]), c && (y.trigger("ajaxComplete", [S, f]), --be.active || be.event.trigger("ajaxStop")))
                        }
                        "object" == ("undefined" == typeof e ? "undefined" : r(e)) && (t = e, e = void 0), t = t || {};
                        var i, o, a, l, u, c, p, d, f = be.ajaxSetup({}, t),
                            h = f.context || f,
                            y = f.context && (h.nodeType || h.jquery) ? be(h) : be.event,
                            v = be.Deferred(),
                            m = be.Callbacks("once memory"),
                            g = f.statusCode || {},
                            b = {},
                            w = {},
                            _ = 0,
                            x = "canceled",
                            S = {
                                readyState: 0,
                                getResponseHeader: function (e) {
                                    var t;
                                    if (2 === _) {
                                        if (!d) for (d = {}; t = Jt.exec(l);) d[t[1].toLowerCase()] = t[2];
                                        t = d[e.toLowerCase()]
                                    }
                                    return null == t ? null : t
                                },
                                getAllResponseHeaders: function () {
                                    return 2 === _ ? l : null
                                },
                                setRequestHeader: function (e, t) {
                                    var n = e.toLowerCase();
                                    return _ || (e = w[n] = w[n] || e, b[e] = t), this
                                },
                                overrideMimeType: function (e) {
                                    return _ || (f.mimeType = e), this
                                },
                                statusCode: function (e) {
                                    var t;
                                    if (e) if (2 > _) for (t in e) g[t] = [g[t], e[t]];
                                    else S.always(e[S.status]);
                                    return this
                                },
                                abort: function (e) {
                                    var t = e || x;
                                    return p && p.abort(t), n(0, t), this
                                }
                            };
                        if (v.promise(S).complete = m.add, S.success = S.done, S.error = S.fail, f.url = ((e || f.url || an) + "").replace(Kt, "").replace(tn, ln[1] + "//"), f.type = t.method || t.type || f.method || f.type, f.dataTypes = be.trim(f.dataType || "*").toLowerCase().match(De) || [""], null == f.crossDomain && (i = nn.exec(f.url.toLowerCase()), f.crossDomain = !(!i || i[1] === ln[1] && i[2] === ln[2] && (i[3] || ("http:" === i[1] ? "80" : "443")) === (ln[3] || ("http:" === ln[1] ? "80" : "443")))), f.data && f.processData && "string" != typeof f.data && (f.data = be.param(f.data, f.traditional)), J(on, f, t, S), 2 === _) return S;
                        c = be.event && f.global, c && 0 === be.active++ && be.event.trigger("ajaxStart"), f.type = f.type.toUpperCase(), f.hasContent = !en.test(f.type), a = f.url, f.hasContent || (f.data && (a = f.url += (Xt.test(a) ? "&" : "?") + f.data, delete f.data), f.cache === !1 && (f.url = Qt.test(a) ? a.replace(Qt, "$1_=" + $t++) : a + (Xt.test(a) ? "&" : "?") + "_=" + $t++)), f.ifModified && (be.lastModified[a] && S.setRequestHeader("If-Modified-Since", be.lastModified[a]), be.etag[a] && S.setRequestHeader("If-None-Match", be.etag[a])), (f.data && f.hasContent && f.contentType !== !1 || t.contentType) && S.setRequestHeader("Content-Type", f.contentType), S.setRequestHeader("Accept", f.dataTypes[0] && f.accepts[f.dataTypes[0]] ? f.accepts[f.dataTypes[0]] + ("*" !== f.dataTypes[0] ? ", " + sn + "; q=0.01" : "") : f.accepts["*"]);
                        for (o in f.headers) S.setRequestHeader(o, f.headers[o]);
                        if (f.beforeSend && (f.beforeSend.call(h, S, f) === !1 || 2 === _)) return S.abort();
                        x = "abort";
                        for (o in {
                            success: 1,
                            error: 1,
                            complete: 1
                        }) S[o](f[o]);
                        if (p = J(rn, f, t, S)) {
                            if (S.readyState = 1, c && y.trigger("ajaxSend", [S, f]), 2 === _) return S;
                            f.async && f.timeout > 0 && (u = s.setTimeout(function () {
                                S.abort("timeout")
                            }, f.timeout));
                            try {
                                _ = 1, p.send(b, n)
                            } catch (e) {
                                if (!(2 > _)) throw e;
                                n(-1, e)
                            }
                        } else n(-1, "No Transport");
                        return S
                    },
                    getJSON: function (e, t, n) {
                        return be.get(e, t, n, "json")
                    },
                    getScript: function (e, t) {
                        return be.get(e, void 0, t, "script")
                    }
                }), be.each(["get", "post"], function (e, t) {
                    be[t] = function (e, n, i, o) {
                        return be.isFunction(n) && (o = o || i, i = n, n = void 0), be.ajax(be.extend({
                            url: e,
                            type: t,
                            dataType: o,
                            data: n,
                            success: i
                        }, be.isPlainObject(e) && e))
                    }
                }), be._evalUrl = function (e) {
                    return be.ajax({
                        url: e,
                        type: "GET",
                        dataType: "script",
                        cache: !0,
                        async: !1,
                        global: !1,
                        throws: !0
                    })
                }, be.fn.extend({
                    wrapAll: function (e) {
                        if (be.isFunction(e)) return this.each(function (t) {
                            be(this).wrapAll(e.call(this, t))
                        });
                        if (this[0]) {
                            var t = be(e, this[0].ownerDocument).eq(0).clone(!0);
                            this[0].parentNode && t.insertBefore(this[0]), t.map(function () {
                                for (var e = this; e.firstChild && 1 === e.firstChild.nodeType;) e = e.firstChild;
                                return e
                            }).append(this)
                        }
                        return this
                    },
                    wrapInner: function (e) {
                        return be.isFunction(e) ? this.each(function (t) {
                            be(this).wrapInner(e.call(this, t))
                        }) : this.each(function () {
                            var t = be(this),
                                n = t.contents();
                            n.length ? n.wrapAll(e) : t.append(e)
                        })
                    },
                    wrap: function (e) {
                        var t = be.isFunction(e);
                        return this.each(function (n) {
                            be(this).wrapAll(t ? e.call(this, n) : e)
                        })
                    },
                    unwrap: function () {
                        return this.parent().each(function () {
                            be.nodeName(this, "body") || be(this).replaceWith(this.childNodes)
                        }).end()
                    }
                }), be.expr.filters.hidden = function (e) {
                    return me.reliableHiddenOffsets() ? e.offsetWidth <= 0 && e.offsetHeight <= 0 && !e.getClientRects().length : ie(e)
                }, be.expr.filters.visible = function (e) {
                    return !be.expr.filters.hidden(e)
                };
                var un = /%20/g,
                    cn = /\[\]$/,
                    pn = /\r?\n/g,
                    dn = /^(?:submit|button|image|reset|file)$/i,
                    fn = /^(?:input|select|textarea|keygen)/i;
                be.param = function (e, t) {
                    var n, i = [],
                        o = function (e, t) {
                            t = be.isFunction(t) ? t() : null == t ? "" : t, i[i.length] = encodeURIComponent(e) + "=" + encodeURIComponent(t)
                        };
                    if (void 0 === t && (t = be.ajaxSettings && be.ajaxSettings.traditional), be.isArray(e) || e.jquery && !be.isPlainObject(e)) be.each(e, function () {
                        o(this.name, this.value)
                    });
                    else for (n in e) oe(n, e[n], t, o);
                    return i.join("&").replace(un, "+")
                }, be.fn.extend({
                    serialize: function () {
                        return be.param(this.serializeArray())
                    },
                    serializeArray: function () {
                        return this.map(function () {
                            var e = be.prop(this, "elements");
                            return e ? be.makeArray(e) : this
                        }).filter(function () {
                            var e = this.type;
                            return this.name && !be(this).is(":disabled") && fn.test(this.nodeName) && !dn.test(e) && (this.checked || !Ue.test(e))
                        }).map(function (e, t) {
                            var n = be(this).val();
                            return null == n ? null : be.isArray(n) ? be.map(n, function (e) {
                                return {
                                    name: t.name,
                                    value: e.replace(pn, "\r\n")
                                }
                            }) : {
                                name: t.name,
                                value: n.replace(pn, "\r\n")
                            }
                        }).get()
                    }
                }), be.ajaxSettings.xhr = void 0 !== s.ActiveXObject ?
                function () {
                    return this.isLocal ? se() : ue.documentMode > 8 ? re() : /^(get|post|head|put|delete|options)$/i.test(this.type) && re() || se()
                } : re;
                var hn = 0,
                    yn = {},
                    vn = be.ajaxSettings.xhr();
                s.attachEvent && s.attachEvent("onunload", function () {
                    for (var e in yn) yn[e](void 0, !0)
                }), me.cors = !! vn && "withCredentials" in vn, vn = me.ajax = !! vn, vn && be.ajaxTransport(function (e) {
                    if (!e.crossDomain || me.cors) {
                        var t;
                        return {
                            send: function (n, i) {
                                var o, r = e.xhr(),
                                    a = ++hn;
                                if (r.open(e.type, e.url, e.async, e.username, e.password), e.xhrFields) for (o in e.xhrFields) r[o] = e.xhrFields[o];
                                e.mimeType && r.overrideMimeType && r.overrideMimeType(e.mimeType), e.crossDomain || n["X-Requested-With"] || (n["X-Requested-With"] = "XMLHttpRequest");
                                for (o in n) void 0 !== n[o] && r.setRequestHeader(o, n[o] + "");
                                r.send(e.hasContent && e.data || null), t = function (n, o) {
                                    var s, l, u;
                                    if (t && (o || 4 === r.readyState)) if (delete yn[a], t = void 0, r.onreadystatechange = be.noop, o) 4 !== r.readyState && r.abort();
                                    else {
                                        u = {}, s = r.status, "string" == typeof r.responseText && (u.text = r.responseText);
                                        try {
                                            l = r.statusText
                                        } catch (e) {
                                            l = ""
                                        }
                                        s || !e.isLocal || e.crossDomain ? 1223 === s && (s = 204) : s = u.text ? 200 : 404
                                    }
                                    u && i(s, l, u, r.getAllResponseHeaders())
                                }, e.async ? 4 === r.readyState ? s.setTimeout(t) : r.onreadystatechange = yn[a] = t : t()
                            },
                            abort: function () {
                                t && t(void 0, !0)
                            }
                        }
                    }
                }), be.ajaxSetup({
                    accepts: {
                        script: "text/javascript, application/javascript, application/ecmascript, application/x-ecmascript"
                    },
                    contents: {
                        script: /\b(?:java|ecma)script\b/
                    },
                    converters: {
                        "text script": function (e) {
                            return be.globalEval(e), e
                        }
                    }
                }), be.ajaxPrefilter("script", function (e) {
                    void 0 === e.cache && (e.cache = !1), e.crossDomain && (e.type = "GET", e.global = !1)
                }), be.ajaxTransport("script", function (e) {
                    if (e.crossDomain) {
                        var t, n = ue.head || be("head")[0] || ue.documentElement;
                        return {
                            send: function (i, o) {
                                t = ue.createElement("script"), t.async = !0, e.scriptCharset && (t.charset = e.scriptCharset), t.src = e.url, t.onload = t.onreadystatechange = function (e, n) {
                                    (n || !t.readyState || /loaded|complete/.test(t.readyState)) && (t.onload = t.onreadystatechange = null, t.parentNode && t.parentNode.removeChild(t), t = null, n || o(200, "success"))
                                }, n.insertBefore(t, n.firstChild)
                            },
                            abort: function () {
                                t && t.onload(void 0, !0)
                            }
                        }
                    }
                });
                var mn = [],
                    gn = /(=)\?(?=&|$)|\?\?/;
                be.ajaxSetup({
                    jsonp: "callback",
                    jsonpCallback: function () {
                        var e = mn.pop() || be.expando + "_" + $t++;
                        return this[e] = !0, e
                    }
                }), be.ajaxPrefilter("json jsonp", function (e, t, n) {
                    var i, o, r, a = e.jsonp !== !1 && (gn.test(e.url) ? "url" : "string" == typeof e.data && 0 === (e.contentType || "").indexOf("application/x-www-form-urlencoded") && gn.test(e.data) && "data");
                    return a || "jsonp" === e.dataTypes[0] ? (i = e.jsonpCallback = be.isFunction(e.jsonpCallback) ? e.jsonpCallback() : e.jsonpCallback, a ? e[a] = e[a].replace(gn, "$1" + i) : e.jsonp !== !1 && (e.url += (Xt.test(e.url) ? "&" : "?") + e.jsonp + "=" + i), e.converters["script json"] = function () {
                        return r || be.error(i + " was not called"), r[0]
                    }, e.dataTypes[0] = "json", o = s[i], s[i] = function () {
                        r = arguments
                    }, n.always(function () {
                        void 0 === o ? be(s).removeProp(i) : s[i] = o, e[i] && (e.jsonpCallback = t.jsonpCallback, mn.push(i)), r && be.isFunction(o) && o(r[0]), r = o = void 0
                    }), "script") : void 0
                }), be.parseHTML = function (e, t, n) {
                    if (!e || "string" != typeof e) return null;
                    "boolean" == typeof t && (n = t, t = !1), t = t || ue;
                    var i = Me.exec(e),
                        o = !n && [];
                    return i ? [t.createElement(i[1])] : (i = S([e], t, o), o && o.length && be(o).remove(), be.merge([], i.childNodes))
                };
                var bn = be.fn.load;
                be.fn.load = function (e, t, n) {
                    if ("string" != typeof e && bn) return bn.apply(this, arguments);
                    var i, o, s, a = this,
                        l = e.indexOf(" ");
                    return l > -1 && (i = be.trim(e.slice(l, e.length)), e = e.slice(0, l)), be.isFunction(t) ? (n = t, t = void 0) : t && "object" == ("undefined" == typeof t ? "undefined" : r(t)) && (o = "POST"), a.length > 0 && be.ajax({
                        url: e,
                        type: o || "GET",
                        dataType: "html",
                        data: t
                    }).done(function (e) {
                        s = arguments, a.html(i ? be("<div>").append(be.parseHTML(e)).find(i) : e)
                    }).always(n &&
                    function (e, t) {
                        a.each(function () {
                            n.apply(this, s || [e.responseText, t, e])
                        })
                    }), this
                }, be.each(["ajaxStart", "ajaxStop", "ajaxComplete", "ajaxError", "ajaxSuccess", "ajaxSend"], function (e, t) {
                    be.fn[t] = function (e) {
                        return this.on(t, e)
                    }
                }), be.expr.filters.animated = function (e) {
                    return be.grep(be.timers, function (t) {
                        return e === t.elem
                    }).length
                }, be.offset = {
                    setOffset: function (e, t, n) {
                        var i, o, r, s, a, l, u, c = be.css(e, "position"),
                            p = be(e),
                            d = {};
                        "static" === c && (e.style.position = "relative"), a = p.offset(), r = be.css(e, "top"), l = be.css(e, "left"), u = ("absolute" === c || "fixed" === c) && be.inArray("auto", [r, l]) > -1, u ? (i = p.position(), s = i.top, o = i.left) : (s = parseFloat(r) || 0, o = parseFloat(l) || 0), be.isFunction(t) && (t = t.call(e, n, be.extend({}, a))), null != t.top && (d.top = t.top - a.top + s), null != t.left && (d.left = t.left - a.left + o), "using" in t ? t.using.call(e, d) : p.css(d)
                    }
                }, be.fn.extend({
                    offset: function (e) {
                        if (arguments.length) return void 0 === e ? this : this.each(function (t) {
                            be.offset.setOffset(this, e, t)
                        });
                        var t, n, i = {
                            top: 0,
                            left: 0
                        },
                            o = this[0],
                            r = o && o.ownerDocument;
                        return r ? (t = r.documentElement, be.contains(t, o) ? ("undefined" != typeof o.getBoundingClientRect && (i = o.getBoundingClientRect()), n = ae(r), {
                            top: i.top + (n.pageYOffset || t.scrollTop) - (t.clientTop || 0),
                            left: i.left + (n.pageXOffset || t.scrollLeft) - (t.clientLeft || 0)
                        }) : i) : void 0
                    },
                    position: function () {
                        if (this[0]) {
                            var e, t, n = {
                                top: 0,
                                left: 0
                            },
                                i = this[0];
                            return "fixed" === be.css(i, "position") ? t = i.getBoundingClientRect() : (e = this.offsetParent(), t = this.offset(), be.nodeName(e[0], "html") || (n = e.offset()), n.top += be.css(e[0], "borderTopWidth", !0), n.left += be.css(e[0], "borderLeftWidth", !0)), {
                                top: t.top - n.top - be.css(i, "marginTop", !0),
                                left: t.left - n.left - be.css(i, "marginLeft", !0)
                            }
                        }
                    },
                    offsetParent: function () {
                        return this.map(function () {
                            for (var e = this.offsetParent; e && !be.nodeName(e, "html") && "static" === be.css(e, "position");) e = e.offsetParent;
                            return e || bt
                        })
                    }
                }), be.each({
                    scrollLeft: "pageXOffset",
                    scrollTop: "pageYOffset"
                }, function (e, t) {
                    var n = /Y/.test(t);
                    be.fn[e] = function (i) {
                        return Ve(this, function (e, i, o) {
                            var r = ae(e);
                            return void 0 === o ? r ? t in r ? r[t] : r.document.documentElement[i] : e[i] : void(r ? r.scrollTo(n ? be(r).scrollLeft() : o, n ? o : be(r).scrollTop()) : e[i] = o)
                        }, e, i, arguments.length, null)
                    }
                }), be.each(["top", "left"], function (e, t) {
                    be.cssHooks[t] = R(me.pixelPosition, function (e, n) {
                        return n ? (n = _t(e, t), mt.test(n) ? be(e).position()[t] + "px" : n) : void 0
                    })
                }), be.each({
                    Height: "height",
                    Width: "width"
                }, function (e, t) {
                    be.each({
                        padding: "inner" + e,
                        content: t,
                        "": "outer" + e
                    }, function (n, i) {
                        be.fn[i] = function (i, o) {
                            var r = arguments.length && (n || "boolean" != typeof i),
                                s = n || (i === !0 || o === !0 ? "margin" : "border");
                            return Ve(this, function (t, n, i) {
                                var o;
                                return be.isWindow(t) ? t.document.documentElement["client" + e] : 9 === t.nodeType ? (o = t.documentElement, Math.max(t.body["scroll" + e], o["scroll" + e], t.body["offset" + e], o["offset" + e], o["client" + e])) : void 0 === i ? be.css(t, n, s) : be.style(t, n, i, s)
                            }, t, r ? i : void 0, r, null)
                        }
                    })
                }), be.fn.extend({
                    bind: function (e, t, n) {
                        return this.on(e, null, t, n)
                    },
                    unbind: function (e, t) {
                        return this.off(e, null, t)
                    },
                    delegate: function (e, t, n, i) {
                        return this.on(t, e, n, i)
                    },
                    undelegate: function (e, t, n) {
                        return 1 === arguments.length ? this.off(e, "**") : this.off(t, e || "**", n)
                    }
                }), be.fn.size = function () {
                    return this.length
                }, be.fn.andSelf = be.fn.addBack, n(4) && (i = [], o = function () {
                    return be
                }.apply(t, i), !(void 0 !== o && (e.exports = o)));
                var wn = s.jQuery,
                    _n = s.$;
                return be.noConflict = function (e) {
                    return s.$ === be && (s.$ = _n), e && s.jQuery === be && (s.jQuery = wn), be
                }, a || (s.jQuery = s.$ = be), be
            })
        }).call(t, n(3)(e))
    }, function (e, t) {
        e.exports = function (e) {
            return e.webpackPolyfill || (e.deprecate = function () {}, e.paths = [], e.children = [], e.webpackPolyfill = 1), e
        }
    }, function (e, t) {
        (function (t) {
            e.exports = t
        }).call(t, {})
    }, function (e, t) {
        "use strict";
        t.__esModule = !0;
        var n = window.navigator.userAgent,
            i = /AppleWebKit\/([\d.]+)/i.exec(n),
            o = i ? parseFloat(i.pop()) : null,
            r = t.IS_IPAD = /iPad/i.test(n),
            s = t.IS_IPHONE = /iPhone/i.test(n) && !r,
            a = t.IS_IPOD = /iPod/i.test(n),
            l = t.IS_IOS = s || r || a,
            u = (t.IOS_VERSION = function () {
                var e = n.match(/OS (\d+)_/i);
                if (e && e[1]) return e[1]
            }(), t.IS_MAC = /Mac/i.test(n), t.IS_ANDROID = /Android/i.test(n)),
            c = t.ANDROID_VERSION = function () {
                var e, t, i = n.match(/Android (\d+)(?:\.(\d+))?(?:\.(\d+))*/i);
                return i ? (e = i[1] && parseFloat(i[1]), t = i[2] && parseFloat(i[2]), e && t ? parseFloat(i[1] + "." + i[2]) : e ? e : null) : null
            }(),
            p = (t.IS_OLD_ANDROID = u && /webkit/i.test(n) && c < 2.3, t.IS_NATIVE_ANDROID = u && c < 5 && o < 537, t.IS_FIREFOX = /Firefox/i.test(n), t.IS_EDGE = /Edge/i.test(n)),
            d = t.IS_CHROME = !p && /Chrome/i.test(n),
            f = t.IS_SAFARI = !d && /Safari/i.test(n),
            h = (t.SAFARI_VERSION = function () {
                if (!f) return null;
                var e = /version\/([\d.]+)/i,
                    t = n.match(e);
                return t ? t[1] : void 0
            }(), t.IS_IE8 = /MSIE\s8\.0/.test(n), t.IS_IE9 = /MSIE\s9\.0/.test(n), t.IS_IE = /(msie\s|trident.*rv:)([\w.]+)/i.test(n)),
            y = (t.IE_VERSION = function () {
                var e = /(msie\s|trident.*rv:)([\w.]+)/i,
                    t = n.match(e);
                return t ? t[2] : null
            }(), t.TOUCH_ENABLED = !! ("ontouchstart" in window || window.DocumentTouch && document instanceof window.DocumentTouch), t.BACKGROUND_SIZE_SUPPORTED = "backgroundSize" in document.createElement("video").style, t.HASVIDEO = !! document.createElement("video").canPlayType, t.IS_X5TBS = /TBS\/\d+/i.test(n)),
            v = (t.TBS_VERSION = function () {
                var e = n.match(/TBS\/(\d+)/i);
                if (e && e[1]) return e[1]
            }(), t.IS_MQQB = !y && /MQQBrowser\/\d+/i.test(n), t.IS_MOBILE = u || l, t.IS_FILE_PROTOCOL = /file:/.test(location.protocol), t.FLASH_VERSION = null);
        t.IS_ENABLED_FLASH = function () {
            var e;
            if (document.all || h) try {
                if (e = new ActiveXObject("ShockwaveFlash.ShockwaveFlash")) return t.FLASH_VERSION = v = e.GetVariable("$version").split(" ")[1].replace(/,/g, "."), window.console && console.log("FLASH_VERSION", v), !0
            } catch (e) {
                return !1
            } else try {
                if (navigator.plugins && navigator.plugins.length > 0 && (e = navigator.plugins["Shockwave Flash"])) {
                    for (var n = e.description.split(" "), i = 0; i < n.length; ++i) isNaN(parseInt(n[i])) || (t.FLASH_VERSION = v = n[i], window.console && console.log("FLASH_VERSION", parseInt(n[i])));
                    return !0
                }
            } catch (e) {
                return !1
            }
            return !1
        }(), t.IS_ENABLED_MSE = function () {
            return window.MediaSource = window.MediaSource || window.WebKitMediaSource, window.MediaSource && "function" == typeof window.MediaSource.isTypeSupported && window.MediaSource.isTypeSupported('video/mp4; codecs="avc1.42E01E,mp4a.40.2"')
        }()
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function r(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function s(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        function a(e, t) {
            f.IS_MOBILE ? (e.flash = !1, f.IS_X5TBS && e.x5_player ? _.mobile = ["flv", "m3u8", "mp4"] : f.IS_ENABLED_MSE && e.h5_flv && (_.mobile = ["flv", "m3u8", "mp4"])) : (e.flash = !(void 0 != e.flash && !t.isFormat("rtmp")) || e.flash, e.flash ? (!f.IS_ENABLED_FLASH || f.IS_MAC && f.IS_SAFARI) && (e.flash = !1, f.IS_ENABLED_MSE ? e.h5_flv && (f.IS_SAFARI && v.compareVersion(f.SAFARI_VERSION, "10.1") > -1 || !f.IS_SAFARI) ? _.pc = ["flv", "m3u8", "mp4"] : _.pc = ["m3u8", "mp4"] : _.pc = ["mp4"]) : f.IS_ENABLED_MSE ? e.h5_flv && (f.IS_SAFARI && v.compareVersion(f.SAFARI_VERSION, "10.1") > -1 || !f.IS_SAFARI) ? _.pc = ["flv", "m3u8", "mp4"] : _.pc = ["m3u8", "mp4"] : !f.IS_ENABLED_FLASH || f.IS_MAC && f.IS_SAFARI ? _.pc = ["mp4"] : e.flash = !0)
        }
        function l(e) {
            var t = {
                urls: {
                    m3u8: {
                        od: e.m3u8 || "",
                        hd: e.m3u8_hd || "",
                        sd: e.m3u8_sd || ""
                    },
                    flv: {
                        od: e.flv || "",
                        hd: e.flv_hd || "",
                        sd: e.flv_sd || ""
                    },
                    mp4: {
                        od: e.mp4 || "",
                        hd: e.mp4_hd || "",
                        sd: e.mp4_sd || ""
                    },
                    rtmp: {
                        od: e.rtmp || "",
                        hd: e.rtmp_hd || "",
                        sd: e.rtmp_sd || ""
                    }
                },
                isClarity: function (e) {
                    var n = t.urls;
                    return !!(n.m3u8[e] || n.flv[e] || n.mp4[e] || n.rtmp[e])
                },
                isFormat: function (e) {
                    var n = t.urls;
                    return !!n[e].od || !! n[e].hd || !! n[e].sd
                },
                hasUrl: function () {
                    return this.isFormat("rtmp") || this.isFormat("flv") || this.isFormat("m3u8") || this.isFormat("mp4")
                }
            };
            t.definitions = [];
            for (var n = 0; n < x.length; n++) t.isClarity(x[n]) && t.definitions.push(x[n]);
            a(e, t);
            var i = p(t);
            return i && (t.curUrl = i.url, t.curDef = t.definitions.indexOf(e.clarity) ? e.clarity : i.definition, t.curFormat = i.format), t
        }
        function u(e, t, n) {
            var i = arguments.length > 3 && void 0 !== arguments[3] ? arguments[3] : _,
                o = "",
                r = void 0;
            n = n || (f.IS_MOBILE ? i.mobile : i.pc);
            for (var s = 0; s < n.length; s++) if (o = n[s], e[o][t]) {
                r = {
                    definition: t,
                    url: e[o][t],
                    format: o
                };
                break
            }
            return r
        }
        function c(e, t) {
            for (var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : x, i = "", o = 0; o < n.length; o++) if (i = n[o], e[t][i]) return {
                definition: i,
                url: e[t][i]
            }
        }
        function p(e) {
            for (var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : _, n = void 0, i = "", o = e.urls, r = f.IS_MOBILE ? t.mobile : t.pc, s = 0; s < r.length; s++) if (i = r[s], e.isFormat(i)) {
                n = c(o, i), n.format = i;
                break
            }
            return n
        }
        t.__esModule = !0, t.TcPlayer = void 0;
        var d = n(5),
            f = i(d),
            h = n(7),
            y = (i(h), n(8)),
            v = i(y),
            m = n(9),
            g = i(m),
            b = n(10),
            w = g.MSG,
            _ = {
                mobile: ["m3u8", "mp4"],
                pc: ["rtmp", "flv", "m3u8", "mp4"]
            },
            x = ["od", "hd", "sd"];
        t.TcPlayer = function (e) {
            function t(n, i) {
                o(this, t);
                var s = l(i),
                    a = {
                        owner: n,
                        videoSource: s,
                        src: s.curUrl,
                        autoplay: i.autoplay,
                        live: i.live,
                        flash: i.flash,
                        poster: i.coverpic,
                        width: i.width,
                        height: i.height,
                        volume: i.volume,
                        listener: i.listener,
                        wording: i.wording,
                        controls: i.controls,
                        clarity: i.clarity,
                        showLoading: i.showLoading || !0,
                        coverpic_pause: null === i.coverpic_pause || i.coverpic_pause,
                        fullscreenEnabled: null === i.fuScrnEnabled || i.fuScrnEnabled,
                        hls: i.hls || "0.7.1",
                        h5_flv: i.h5_flv,
                        x5_player: i.x5_player,
                        x5_type: i.x5_type,
                        x5_fullscreen: i.x5_fullscreen,
                        x5_orientation: i.x5_orientation
                    };
                return r(this, e.call(this, a))
            }
            return s(t, e), t.prototype.switchClarity = function (e) {
                e = e || "od";
                var t = this.currentTime(),
                    n = this.options.videoSource,
                    i = u(n.urls, e),
                    o = this.playing();
                this.load(i.url), n.curUrl = i.url, n.curDef = i.definition, n.curFormat = i.format;
                var r = v.bind(this, function () {
                    parseInt(this.duration() - t) > 0 && !this.options.live && this.currentTime(t), o && this.play(), g.unsub(w.MetaLoaded, "*", r, this)
                });
                g.sub(w.MetaLoaded, "*", r, this)
            }, t.prototype.handleMsg = function (t) {
                e.prototype.handleMsg.call(this, t)
            }, t
        }(b.Player)
    }, function (e, t) {
        "use strict";

        function n(e, t, n) {
            return e ? (e.addEventListener ? e.addEventListener(t, n, !1) : e.attachEvent && e.attachEvent("on" + t, n), n) : console.warn("element not exists")
        }
        function i(e, t, n) {
            return e ? void(e.removeEventListener ? e.removeEventListener(t, n, !1) : e.detachEvent && e.detachEvent("on" + t, n)) : console.warn("element not exists")
        }
        function o() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "div",
                t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : {},
                i = document.createElement(e);
            for (var o in t) if (t.hasOwnProperty(o)) {
                var r = t[o];
                null === r ? i.removeAttribute(r) : i.setAttribute(o, r)
            }
            for (var s in n) n.hasOwnProperty(s) && (i[s] = n[s]);
            return i
        }
        function r(e) {
            return document.getElementById(e)
        }
        function s(e, t) {
            e.classList ? e.classList.add(t) : u(e, t) || (e.className = e.className + " " + t)
        }
        function a(e, t) {
            e.classList ? e.classList.remove(t) : e.className = e.className.replace(c(t), " ")
        }
        function l(e, t, n) {
            n ? s(e, t) : a(e, t)
        }
        function u(e, t) {
            return e.classList ? e.classList.contains(t) : c(t).test(e.className)
        }
        function c(e) {
            return new RegExp("(^|\\s)" + e + "($|\\s)")
        }
        function p(e) {
            var t = void 0;
            if (e.getBoundingClientRect && e.parentNode && (t = e.getBoundingClientRect()), !t) return {
                left: 0,
                top: 0
            };
            var n = document.documentElement,
                i = document.body,
                o = n.clientLeft || i.clientLeft || 0,
                r = window.pageXOffset || i.scrollLeft,
                s = t.left + r - o,
                a = n.clientTop || i.clientTop || 0,
                l = window.pageYOffset || i.scrollTop,
                u = t.top + l - a;
            return {
                left: Math.round(s),
                top: Math.round(u)
            }
        }
        function d(e, t, n) {
            var i = {},
                o = n || p(e),
                r = e.offsetWidth,
                s = e.offsetHeight,
                a = o.top,
                l = o.left,
                u = t.pageY || t.clientY,
                c = t.pageX || t.clientX;
            return t.changedTouches && (c = t.changedTouches[0].pageX, u = t.changedTouches[0].pageY), i.y = Math.max(0, Math.min(1, (a - u + s) / s)), i.x = Math.max(0, Math.min(1, (c - l) / r)), i
        }
        function f(e, t, n) {
            var i = arguments.length > 3 && void 0 !== arguments[3] && arguments[3],
                o = document.createElement("script");
            if (o.onload = o.onreadystatechange = function () {
                this.readyState && "loaded" !== this.readyState && "complete" !== this.readyState || ("function" == typeof t && t(), o.onload = o.onreadystatechange = null, o.parentNode && !i && o.parentNode.removeChild(o))
            }, n) for (var r in n) if (n.hasOwnProperty(r)) {
                var s = n[r];
                null === s ? o.removeAttribute(s) : o.setAttribute(r, s)
            }
            o.src = e, document.getElementsByTagName("head")[0].appendChild(o)
        }
        function h() {
            var e = document,
                t = e.documentElement,
                n = e.body;
            return {
                width: t && t.clientWidth || n && n.offsetWidth || window.innerWidth || 0,
                height: t && t.clientHeight || n && n.offsetHeight || window.innerHeight || 0
            }
        }
        t.__esModule = !0, t.on = n, t.off = i, t.createEl = o, t.get = r, t.addClass = s, t.removeClass = a, t.toggleClass = l, t.hasClass = u, t.findElPosition = p, t.getPointerPosition = d, t.loadScript = f, t.getViewportSize = h
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o() {
            return w++
        }
        function r(e, t, n) {
            t.guid || (t.guid = o());
            var i = function () {
                t.apply(e, arguments)
            };
            return i.guid = n ? n + "_" + t.guid : t.guid, i
        }
        function s(e) {
            if (e instanceof Array) return 0 === e.length;
            for (var t in e) if (e.hasOwnProperty(t)) return !1;
            return !0
        }
        function a(e) {
            e |= 0;
            var t = 3600,
                n = 60,
                i = e / t | 0,
                o = (e - i * t) / n | 0,
                r = e - i * t - o * n;
            return i = i > 0 ? i + ":" : "", o = o > 0 ? o + ":" : "00:", r = r > 0 ? r + "" : i.length > 0 || o.length > 0 ? "00" : "00:00", i = 2 == i.length ? "0" + i : i, o = 2 == o.length ? "0" + o : o, r = 1 == r.length ? "0" + r : r, i + o + r
        }
        function l(e) {
            c.__isFullscreen = !! document[_.fullscreenElement], c.__isFullscreen || v.off(document, _.fullscreenchange, l), g.pub({
                type: m.MSG.FullScreen,
                src: "util",
                ts: e.timestamp,
                detail: {
                    isFullscreen: c.__isFullscreen
                }
            }, c.player)
        }
        function u(e) {
            27 === e.keyCode && c(c.player, !1)
        }
        function c(e, t, n) {
            return "undefined" == typeof t ? c.__isFullscreen || !1 : (c.player = e, void(_.requestFullscreen ? t ? (v.on(document, _.fullscreenchange, l), n && n[_.requestFullscreen]()) : document[_.exitFullscreen]() : (c.__isFullscreen = t, c.__isFullscreen ? (c.__origOverflow = document.documentElement.style.overflow, document.documentElement.style.overflow = "hidden", v.on(document, "keydown", u)) : (document.documentElement.style.overflow = c.__origOverflow, v.off(document, "keydown", u)), v.toggleClass(document.body, "vcp-full-window", t), g.pub({
                type: m.MSG.FullScreen,
                src: "util",
                detail: {
                    isFullscreen: c.__isFullscreen
                }
            }, c.player))))
        }
        function p(e) {
            for (var t = arguments.length, n = Array(t > 1 ? t - 1 : 0), i = 1; i < t; i++) n[i - 1] = arguments[i];
            for (var o = 0; o < n.length; o++) {
                var r = n[o];
                for (var s in r) r.hasOwnProperty(s) && (e[s] = e[s] || r[s])
            }
            return e
        }
        function d(e, t) {
            return "undefined" == typeof t ? JSON.parse(localStorage[e] || "null") : void(localStorage[e] = JSON.stringify(t))
        }
        function f(e, t) {
            if (e = e || "0.0.0", t = t || "0.0.0", e == t) return 0;
            for (var n = e.split("."), i = t.split("."), o = Math.max(n.length, i.length), r = 0; r < o; r++) {
                var s = ~~i[r],
                    a = ~~n[r];
                if (s < a) return 1;
                if (s > a) return -1
            }
            return -1
        }
        function h(e) {
            return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/\"/g, "&quot;").replace(/\'/g, "&#39;").replace(/\//g, "&#x2F;")
        }
        t.__esModule = !0, t.supportStyle = t.console = t.VideoType = t.CDNPath = t.FullscreenApi = void 0, t.guid = o, t.bind = r, t.isEmpty = s, t.convertTime = a, t.doFullscreen = c, t.extend = p, t.store = d, t.compareVersion = f, t.escapeHTML = h;
        for (var y = n(7), v = i(y), m = n(9), g = i(m), b = n(5), w = (i(b), 1), _ = t.FullscreenApi = {
            requestFullscreen: null,
            exitFullscreen: null,
            fullscreenElement: null,
            fullscreenEnabled: null,
            fullscreenchange: null,
            fullscreenerror: null
        }, x = [
            ["requestFullscreen", "exitFullscreen", "fullscreenElement", "fullscreenEnabled", "fullscreenchange", "fullscreenerror"],
            ["webkitRequestFullscreen", "webkitExitFullscreen", "webkitFullscreenElement", "webkitFullscreenEnabled", "webkitfullscreenchange", "webkitfullscreenerror"],
            ["webkitRequestFullScreen", "webkitCancelFullScreen", "webkitCurrentFullScreenElement", "webkitCancelFullScreen", "webkitfullscreenchange", "webkitfullscreenerror"],
            ["mozRequestFullScreen", "mozCancelFullScreen", "mozFullScreenElement", "mozFullScreenEnabled", "mozfullscreenchange", "mozfullscreenerror"],
            ["msRequestFullscreen", "msExitFullscreen", "msFullscreenElement", "msFullscreenEnabled", "MSFullscreenChange", "MSFullscreenError"]
        ], S = x[0], E = void 0, T = 0; T < x.length; T++) x[T][1] in document && (E = x[T]);
        if (E) for (var C = 0; C < E.length; C++) _[S[C]] = E[C];
        t.CDNPath = "//imgcache.qq.com/open/qcloud/video/vcplayer/", t.VideoType = {
            RTMP: "rtmp",
            FLV: "flv",
            M3U8: "m3u8"
        }, t.console = {
            log: function () {
                window.console && window.console.log.apply(window.console, arguments)
            },
            warn: function () {
                window.console && window.console.warn.apply(window.console, arguments)
            },
            error: function () {
                window.console && window.console.error.apply(window.console, arguments)
            }
        }, t.supportStyle = function () {
            var e = document.createElement("div"),
                t = "Khtml O Moz Webkit".split(" "),
                n = t.length;
            return function (i) {
                if (i in e.style) return !0;
                if ("-ms-" + i in e.style) return !0;
                for (i = i.replace(/^[a-z]/, function (e) {
                    return e.toUpperCase()
                }); n--;) if (t[n] + i in e.style) return !0;
                return !1
            }
        }()
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            var t = e.guid;
            return t ? (d[t] = d[t] || {}, d[t]) : (console.error(e, " has no guid."), {})
        }
        function r(e) {
            var t = e.guid;
            return t ? (f[t] = f[t] || {}, f[t]) : (console.error(e, " has no guid."), {})
        }
        function s(e, t) {
            a(e.type, e, t), a("*", e, t)
        }
        function a(e, t, n) {
            try {
                var i = o(n),
                    s = r(n);
                if (!i[e]) return;
                var a = i[e];
                for (var l in a) if (a.hasOwnProperty(l)) {
                    var u = a[l],
                        c = s[l];
                    if ("function" != typeof c) return !1;
                    for (var p = 0; p < u.length; p++) {
                        var d = u[p];
                        "*" !== d && d !== t.src || c(t)
                    }
                }
            } catch (e) {
                window.console && console.error && console.error(e.stack || e)
            }
        }
        function l(e, t, n, i) {
            var s = o(i),
                a = r(i);
            return n.guid ? (a[n.guid] = n, s[e] = s[e] || {}, s[e][n.guid] = s[e][n.guid] || [], s[e][n.guid].push(t), n) : console.error("callback function need guid")
        }
        function u(e, t, n, i) {
            var s = o(i),
                a = r(i);
            if (("*" == e || s[e]) && ("*" == e || s[e][n.guid])) for (var l in s) if (("*" === e || l == e) && s.hasOwnProperty(l)) if ("*" !== n) {
                var u = s[l][n.guid];
                "*" === t && (u = []);
                for (var c = 0; c < u.length;) u[c] === t ? u.splice(c, 1) : c++;
                0 == u.length && delete s[l][n.guid], p.isEmpty(s[l]) && delete s[l]
            } else {
                for (var d in s[l]) delete a[d];
                delete s[l]
            }
        }
        t.__esModule = !0, t.MSG = void 0, t.pub = s, t.sub = l, t.unsub = u;
        var c = n(8),
            p = i(c),
            d = (t.MSG = {
                Error: "error",
                TimeUpdate: "timeupdate",
                Load: "load",
                MetaLoaded: "loadedmetadata",
                Loaded: "loadeddata",
                Progress: "progress",
                FullScreen: "fullscreen",
                Play: "play",
                Playing: "playing",
                Pause: "pause",
                Ended: "ended",
                Seeking: "seeking",
                Seeked: "seeked",
                Resize: "resize",
                VolumeChange: "volumechange"
            }, {}),
            f = {}
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function o(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        t.__esModule = !0, t.Player = t.dom = t.util = t.browser = t.MSG = void 0, n(11);
        var s = n(5),
            a = o(s),
            l = n(7),
            u = o(l),
            c = n(8),
            p = o(c),
            d = n(9),
            f = o(d),
            h = n(15),
            y = i(h),
            v = n(18),
            m = i(v),
            g = n(19),
            b = i(g),
            w = n(27),
            _ = i(w),
            x = n(28),
            S = i(x),
            E = n(29),
            T = i(E),
            C = n(30),
            k = i(C);
        /*window.console || (window.console = {
            log: function () {},
            error: function () {},
            debug: function () {},
            info: function () {}
        });*/
        var M = t.MSG = f.MSG,
            O = t.browser = a,
            N = t.util = p,
            L = t.dom = u;
        t.Player = function () {
            function e(t) {
                r(this, e), this.options = t, this.ready = !1;
                var n = t.owner;
                return n ? (this.guid = N.guid(), this.listener = this.options.listener, f.sub("*", "*", N.bind(this, this.handleMsg), this), n = L.get(n), void this.render(n)) : console.error("Player need a container")
            }
            return e.prototype.render = function (e) {
                var t = "vcp-player";
                if (O.TOUCH_ENABLED && (t += " touchable"), this.el = L.createEl("div", {
                    class: t
                }), e.appendChild(this.el), this.errortips = new k.
            default (this), this.errortips.render(this.el), this.loading = new T.
            default (this), this.loading.render(this.el), this.options.width = this.options.width || e.offsetWidth, this.options.height = this.options.height || e.offsetHeight, this.size(this.options.width, this.options.height), !this.verifyOptions()) return N.console.error("create failed");
                if (!this.options.flash && O.HASVIDEO) {
                    var n = new y.
                default (this);
                    n.render(this.el), this.video = n
                } else {
                    var i = new m.
                default (this);
                    i.render(this.el), this.video = i
                }
                if (!this.video) return N.console.error("create video failed");
                this.poster = new S.
            default (this), this.poster.render(this.el), this.bigplay = new _.
            default (this), this.bigplay.render(this.el);
                var o = void 0;
                o = !(this.options.controls && "default" != this.options.controls && (!this.options.flash || "system" != this.options.controls)), o && (this.panel = new b.
            default (this), this.panel.render(this.el)), this.setup()
            }, e.prototype.verifyOptions = function () {
                return O.IE_VERSION && N.compareVersion(O.IE_VERSION, "8.0") == -1 ? (this.errortips.show({
                    code: 5
                }), !1) : O.IS_FILE_PROTOCOL ? (this.errortips.show({
                    code: 10
                }), !1) : !! this.options.src || (this.options.videoSource.hasUrl() ? O.IS_IE || !O.IS_ENABLED_FLASH ? this.errortips.show({
                    code: 5
                }) : this.errortips.show({
                    code: 5
                }) : this.errortips.show({
                    code: 12
                }), !1)
            }, e.prototype.size = function (e, t, n) {
                n = n || "cover";
                var i = /^\d+\.?\d{0,2}%$/,
                    o = void 0,
                    r = void 0;
                if (i.test(e) || i.test(t)) o = e, r = t;
                else {
                    var s = this.video ? this.video.videoWidth() : this.options.width,
                        a = this.video ? this.video.videoHeight() : this.options.height;
                    if (o = e, r = t, s && a) {
                        var l = s / a;
                        "fit" == n && (o = e, r = o / l, r > t && (o *= t / r, r = t))
                    }
                    var u = L.getViewportSize();
                    u.width > 0 && o > u.width && (o = u.width)
                }
                o += i.test(o) ? "" : "px", r += i.test(r) ? "" : "px", this.el.style.width = o, this.el.style.height = r, this.video && (this.video.width(o), this.video.height(r)), this.width = o, this.height = r
            }, e.prototype.setup = function () {
                if (this.__handleEvent = N.bind(this, this.handleEvent), O.IS_MOBILE) {
                    if (this.options.autoplay) {
                        var e = this;
                        document.addEventListener("WeixinJSBridgeReady", function () {
                            e.play()
                        })
                    }
                } else this.loading.show();
//                L.loadScript("//pingjs.qq.com/h5/stats.js?v2.0.4", null, {
//                    name: "MTAH5",
//                    sid: "500376528",
//                    cid: "500383222"
//                }, !0)
            }, e.prototype.destroy = function () {
                this.video && this.video.destroy(), this.panel && this.panel.destroy(), this.bigplay && this.bigplay.destroy(), this.loading && this.loading.destroy(), f.unsub("*", "*", this.handleMsg, this), this.video = this.panel = this.bigplay = this.loading = null
            }, e.prototype.setListener = function (e) {
                this.listener = e
            }, e.prototype.handleEvent = function (e) {
                switch (e.type) {
                case "mousemove":
                    if (this.__lastmove && new Date - this.__lastmove < 100) break;
                    var t = this;
                    if (this.__movecnt = this.__movecnt || 0, this.__movecnt++, this.__movecnt < 5) {
                        setTimeout(function () {
                            t.__movecnt = 0
                        }, 500);
                        break
                    }
                    this.__movecnt = 0, this.__lastmove = +new Date, clearTimeout(this.__moveid), t.panel && t.panel.show(), this.__moveid = setTimeout(function () {
                        t.playing() && t.panel && t.panel.hide()
                    }, 3e3)
                }
            }, e.prototype.handleMsg = function (e) {
                switch (e.type) {
                case M.Play:
                    if (!this.playing()) break;
                    L.addClass(this.el, "vcp-playing"), this.video.type() == N.VideoType.RTMP && (this.__wait = !0, this.loading.show()), L.on(this.el, "mousemove", this.__handleEvent);
                    break;
                case M.Playing:
                    this.loading.hide();
                    break;
                case M.TimeUpdate:
                    this.__wait && (this.__wait = !1, this.loading.hide());
                    break;
                case M.Pause:
                    L.off(this.el, "mousemove", this.__handleEvent), L.removeClass(this.el, "vcp-playing");
                    break;
                case M.Ended:
                    L.off(this.el, "mousemove", this.__handleEvent), this.panel && this.panel.show(), L.removeClass(this.el, "vcp-playing");
                    break;
                case M.MetaLoaded:
                    this.loading.hide(), this.size(this.options.width, this.options.height);
                    break;
                case M.Seeking:
                    this.loading.show();
                    break;
                case M.Seeked:
                    this.loading.hide();
                    break;
                case M.FullScreen:
                    var t = this;
                    setTimeout(function () {
                        L.toggleClass(t.el, "vcp-fullscreen", e.detail.isFullscreen)
                    }, 0);
                    break;
                case M.Error:
                    this.loading.hide(), this.errortips.show(e.detail), this.panel && this.panel.show();
                    try {
                        MtaH5.clickStat("error", {
                            error: "true"
                        })
                    } catch (e) {}
                }!e.private && this.listener && this.listener(e)
            }, e.prototype.currentTime = function (e) {
                return this.video.currentTime(e)
            }, e.prototype.duration = function () {
                return this.video.duration()
            }, e.prototype.percent = function (e) {
                return this.video.duration() ? "undefined" == typeof e ? this.video.currentTime() / this.video.duration() : void this.video.currentTime(this.video.duration() * e) : 0
            }, e.prototype.buffered = function () {
                return this.video.duration() ? this.video.buffered() / this.video.duration() : 0
            }, e.prototype.pause = function () {
                this.video.pause()
            }, e.prototype.play = function () {
                this.errortips.clear(), this.video.play()
            }, e.prototype.togglePlay = function () {
                this.errortips.clear(), this.video.togglePlay()
            }, e.prototype.stop = function () {
                this.video.stop()
            }, e.prototype.mute = function (e) {
                return this.video.mute(e)
            }, e.prototype.volume = function (e) {
                return this.video.volume(e)
            }, e.prototype.fullscreen = function (e) {
                return this.video.fullscreen(e)
            }, e.prototype.load = function (e, t) {
                this.errortips.clear(), this.loading.show(), this.video.load(e || this.options.src, t)
            }, e.prototype.playing = function () {
                return this.video.playing()
            }, e.prototype.paused = function () {
                return this.video.paused()
            }, e
        }()
    }, function (e, t, n) {
        var i = n(12);
        "string" == typeof i && (i = [
            [e.id, i, ""]
        ]);
        n(14)(i, {});
        i.locals && (e.exports = i.locals)
    }, function (e, t, n) {
        t = e.exports = n(13)(), t.push([e.id, ".vcp-player{position:relative;z-index:0;font-family:Tahoma,\\\\5FAE\\8F6F\\96C5\\9ED1,\\u5b8b\\u4f53,Verdana,Arial,sans-serif;background-color:#000}.vcp-player video{display:block;overflow:hidden}.vcp-fullscreen.vcp-player,.vcp-fullscreen video,body.vcp-full-window{width:100%!important;height:100%!important}body.vcp-full-window{overflow-y:auto}.vcp-full-window .vcp-player{position:fixed;left:0;top:0}.vcp-pre-flash,.vcp-video{width:100%;height:100%}.vcp-pre-flash{z-index:999;background:#000;position:absolute;top:0;left:0}.vcp-controls-panel{position:absolute;bottom:0;width:100%;font-size:16px;height:3em;z-index:1000}.vcp-controls-panel.show{-webkit-animation:fadeIn ease .8s;animation:fadeIn ease .8s;animation-fill-mode:forwards;-webkit-animation-fill-mode:forwards}.vcp-controls-panel.hide{-webkit-animation:fadeOut ease .8s;animation:fadeOut ease .8s;animation-fill-mode:forwards;-webkit-animation-fill-mode:forwards}.vcp-panel-bg{width:100%;height:100%;position:absolute;left:0;top:0;background-color:#242424;opacity:.8;filter:alpha(opacity=80);z-index:1000}.vcp-playtoggle{cursor:pointer;position:relative;z-index:1001;width:3em;height:100%;float:left;background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/play_btn.png);background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/play_btn.svg),none}.vcp-playtoggle:focus,.vcp-playtoggle:hover{background-color:#708090;opacity:.9;filter:alpha(opacity=90)}.touchable .vcp-playtoggle:hover{background-color:transparent;opacity:1}.vcp-playing .vcp-playtoggle{background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/stop_btn.png);background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/stop_btn.svg),none}.vcp-bigplay{width:100%;height:80%;position:absolute;background-color:white\\0;filter:alpha(opacity=0);opacity:0;z-index:1000;top:0;left:0}.vcp-slider{position:relative;z-index:1001;float:left;background:#c4c4c4;height:10px;opacity:.8;filter:alpha(opacity=80);cursor:pointer}.vcp-slider .vcp-slider-track{width:0;height:100%;margin-top:0;opacity:1;filter:alpha(opacity=100);background-color:#1e90ff}.vcp-slider .vcp-slider-thumb{cursor:pointer;background-color:#fff;position:absolute;top:0;left:0;border-radius:1em!important;height:10px;margin-left:-5px;width:10px}.vcp-slider-vertical{position:relative;width:.5em;height:8em;top:-5.6em;z-index:1001;background-color:#1c1c1c;opacity:.9;filter:alpha(opacity=90);cursor:pointer}.vcp-slider-vertical .vcp-slider-track{background-color:#1275cf;width:.5em;height:100%;opacity:.8;filter:alpha(opacity=80)}.vcp-slider-vertical .vcp-slider-thumb{cursor:pointer;position:absolute;background-color:#f0f8ff;width:.8em;height:.8em;border-radius:.8em!important;margin-top:-.4em;top:0;left:-.15em}.vcp-timeline{top:-10px;left:0;height:10px;position:absolute;z-index:1001;width:100%}.vcp-timeline .vcp-slider-thumb{top:-4px}.vcp-timeline .vcp-slider{margin-top:8px;height:2px;width:100%}.vcp-timeline:hover .vcp-slider{margin-top:0;height:10px}.vcp-timeline:hover .vcp-slider-thumb{display:block;width:16px;height:16px;top:-3px;margin-left:-8px}.vcp-timelabel{display:inline-block;line-height:3em;float:left;color:#fff;padding:0 9px}.vcp-timelabel,.vcp-volume{height:3em;z-index:1001;position:relative}.vcp-volume{width:3em;cursor:pointer;float:right;background-color:transparent;opacity:.9;filter:alpha(opacity=90)}.vcp-volume-icon{background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/volume.png);background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/volume.svg),none;display:inline-block;width:3em;height:3em;position:absolute;left:0;top:0}.vcp-volume-muted .vcp-volume-icon{background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/muted.png);background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/muted.svg),none}.vcp-volume .vcp-slider-vertical{top:-8.4em;left:1em;display:none}.vcp-volume .vcp-slider-track{position:absolute;bottom:0}.vcp-volume:hover .vcp-slider-vertical{display:block}.vcp-volume .vcp-volume-bg{height:8.8em;width:2em;position:absolute;left:.25em;top:-8.8em;background:#242424;display:none}.vcp-volume:hover .vcp-slider-vertical,.vcp-volume:hover .vcp-volume-bg{display:block}.vcp-fullscreen-toggle{position:relative;width:3em;height:3em;float:right;cursor:pointer;z-index:1001;background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/fullscreen.png);background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/fullscreen.svg),none}.vcp-fullscreen .vcp-fullscreen-toggle{background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/fullscreen_exit.png);background-image:url(//imgcache.qq.com/open/qcloud/video/vcplayer/img/fullscreen_exit.svg),none}.vcp-loading{left:50%;top:50%;margin-top:-3em}.vcp-loading,.vcp-poster{position:absolute;display:none}.vcp-poster{left:0;top:0;overflow:hidden;z-index:1000;width:100%;height:100%}.vcp-poster-pic{position:relative}.vcp-poster-pic.cover,.vcp-poster-pic.default{left:50%;top:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%)}.vcp-poster-pic.cover{width:100%}.vcp-poster-pic.stretch{width:100%;height:100%}.vcp-error-tips{position:absolute;z-index:1001;width:100%;height:4.5em;left:0;top:50%;color:#ff4500;margin-top:-5.25em;text-align:center;display:none}.vcp-clarityswitcher{height:3em;width:3em;cursor:pointer;position:relative;z-index:1001;float:right;background-color:transparent;opacity:.9}.vcp-vertical-switcher-container{width:3em;position:absolute;left:0;bottom:2.4em;background:#242424;display:none}.vcp-vertical-switcher-current{display:block;color:#fff;text-align:center;line-height:3em}.vcp-vertical-switcher-item{display:block;color:#fff;text-align:center;line-height:2em}.vcp-vertical-switcher-item.current{color:#888}@-webkit-keyframes fadeOut{0%{opacity:1}to{opacity:0}}@keyframes fadeOut{0%{opacity:1}to{opacity:0}}.fadeOut{-webkit-animation:fadeOut ease .8s;animation:fadeOut ease .8s;animation-fill-mode:forwards;-webkit-animation-fill-mode:forwards}@-webkit-keyframes fadeIn{0%{opacity:0}to{opacity:1}}@keyframes fadeIn{0%{opacity:0}to{opacity:1}}.fadeIn{-webkit-animation:fadeIn ease .8s;animation:fadeIn ease .8s;animation-fill-mode:forwards;-webkit-animation-fill-mode:forwards}", ""]);
    }, function (e, t) {
        e.exports = function () {
            var e = [];
            return e.toString = function () {
                for (var e = [], t = 0; t < this.length; t++) {
                    var n = this[t];
                    n[2] ? e.push("@media " + n[2] + "{" + n[1] + "}") : e.push(n[1])
                }
                return e.join("")
            }, e.i = function (t, n) {
                "string" == typeof t && (t = [
                    [null, t, ""]
                ]);
                for (var i = {}, o = 0; o < this.length; o++) {
                    var r = this[o][0];
                    "number" == typeof r && (i[r] = !0)
                }
                for (o = 0; o < t.length; o++) {
                    var s = t[o];
                    "number" == typeof s[0] && i[s[0]] || (n && !s[2] ? s[2] = n : n && (s[2] = "(" + s[2] + ") and (" + n + ")"), e.push(s))
                }
            }, e
        }
    }, function (e, t, n) {
        function i(e, t) {
            for (var n = 0; n < e.length; n++) {
                var i = e[n],
                    o = f[i.id];
                if (o) {
                    o.refs++;
                    for (var r = 0; r < o.parts.length; r++) o.parts[r](i.parts[r]);
                    for (; r < i.parts.length; r++) o.parts.push(u(i.parts[r], t))
                } else {
                    for (var s = [], r = 0; r < i.parts.length; r++) s.push(u(i.parts[r], t));
                    f[i.id] = {
                        id: i.id,
                        refs: 1,
                        parts: s
                    }
                }
            }
        }
        function o(e) {
            for (var t = [], n = {}, i = 0; i < e.length; i++) {
                var o = e[i],
                    r = o[0],
                    s = o[1],
                    a = o[2],
                    l = o[3],
                    u = {
                        css: s,
                        media: a,
                        sourceMap: l
                    };
                n[r] ? n[r].parts.push(u) : t.push(n[r] = {
                    id: r,
                    parts: [u]
                })
            }
            return t
        }
        function r(e, t) {
            var n = v(),
                i = b[b.length - 1];
            if ("top" === e.insertAt) i ? i.nextSibling ? n.insertBefore(t, i.nextSibling) : n.appendChild(t) : n.insertBefore(t, n.firstChild), b.push(t);
            else {
                if ("bottom" !== e.insertAt) throw new Error("Invalid value for parameter 'insertAt'. Must be 'top' or 'bottom'.");
                n.appendChild(t)
            }
        }
        function s(e) {
            e.parentNode.removeChild(e);
            var t = b.indexOf(e);
            t >= 0 && b.splice(t, 1)
        }
        function a(e) {
            var t = document.createElement("style");
            return t.type = "text/css", r(e, t), t
        }
        function l(e) {
            var t = document.createElement("link");
            return t.rel = "stylesheet", r(e, t), t
        }
        function u(e, t) {
            var n, i, o;
            if (t.singleton) {
                var r = g++;
                n = m || (m = a(t)), i = c.bind(null, n, r, !1), o = c.bind(null, n, r, !0)
            } else e.sourceMap && "function" == typeof URL && "function" == typeof URL.createObjectURL && "function" == typeof URL.revokeObjectURL && "function" == typeof Blob && "function" == typeof btoa ? (n = l(t), i = d.bind(null, n), o = function () {
                s(n), n.href && URL.revokeObjectURL(n.href)
            }) : (n = a(t), i = p.bind(null, n), o = function () {
                s(n)
            });
            return i(e), function (t) {
                if (t) {
                    if (t.css === e.css && t.media === e.media && t.sourceMap === e.sourceMap) return;
                    i(e = t)
                } else o()
            }
        }
        function c(e, t, n, i) {
            var o = n ? "" : i.css;
            if (e.styleSheet) e.styleSheet.cssText = w(t, o);
            else {
                var r = document.createTextNode(o),
                    s = e.childNodes;
                s[t] && e.removeChild(s[t]), s.length ? e.insertBefore(r, s[t]) : e.appendChild(r)
            }
        }
        function p(e, t) {
            var n = t.css,
                i = t.media;
            if (i && e.setAttribute("media", i), e.styleSheet) e.styleSheet.cssText = n;
            else {
                for (; e.firstChild;) e.removeChild(e.firstChild);
                e.appendChild(document.createTextNode(n))
            }
        }
        function d(e, t) {
            var n = t.css,
                i = t.sourceMap;
            i && (n += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(i)))) + " */");
            var o = new Blob([n], {
                type: "text/css"
            }),
                r = e.href;
            e.href = URL.createObjectURL(o), r && URL.revokeObjectURL(r)
        }
        var f = {},
            h = function (e) {
                var t;
                return function () {
                    return "undefined" == typeof t && (t = e.apply(this, arguments)), t
                }
            },
            y = h(function () {
                return /msie [6-9]\b/.test(self.navigator.userAgent.toLowerCase())
            }),
            v = h(function () {
                return document.head || document.getElementsByTagName("head")[0]
            }),
            m = null,
            g = 0,
            b = [];
        e.exports = function (e, t) {
            t = t || {}, "undefined" == typeof t.singleton && (t.singleton = y()), "undefined" == typeof t.insertAt && (t.insertAt = "bottom");
            var n = o(e);
            return i(n, t), function (e) {
                for (var r = [], s = 0; s < n.length; s++) {
                    var a = n[s],
                        l = f[a.id];
                    l.refs--, r.push(l)
                }
                if (e) {
                    var u = o(e);
                    i(u, t)
                }
                for (var s = 0; s < r.length; s++) {
                    var l = r[s];
                    if (0 === l.refs) {
                        for (var c = 0; c < l.parts.length; c++) l.parts[c]();
                        delete f[l.id]
                    }
                }
            }
        };
        var w = function () {
            var e = [];
            return function (t, n) {
                return e[t] = n, e.filter(Boolean).join("\n")
            }
        }()
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function (e) {
            return typeof e
        } : function (e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        },
            u = n(16),
            c = o(u),
            p = n(7),
            d = i(p),
            f = n(8),
            h = i(f),
            y = n(9),
            v = n(17),
            m = i(v),
            g = n(5),
            b = i(g),
            w = (h.FullscreenApi, {
                "0.7.1": "libs/hls.js",
                "0.7min": "libs/hls.min.js",
                "0.8.1": "libs/hls0.8.js"
            }),
            _ = function (e) {
                function t(n) {
                    return r(this, t), s(this, e.call(this, n, "H5Video"))
                }
                return a(t, e), t.prototype.render = function (t) {
                    var n, i = this.player.options,
                        o = "system" == i.controls ? "" : null,
                        r = !! i.autoplay || null;
                    return n = i.poster && "object" == l(i.poster) ? i.poster.src : "string" == typeof i.poster ? i.poster : null, this.createEl("video", {
                        controls: o,
                        preload: "auto",
                        autoplay: r,
                        "webkit-playsinline": "",
                        playsinline: "",
                        "x-webkit-airplay": "allow",
                        "x5-video-player-type": "h5" == i.x5_type ? "h5" : null,
                        "x5-video-player-fullscreen": !! i.x5_fullscreen || null,
                        "x5-video-orientation": ["landscape", "portrait", "landscape|portrait"][i.x5_orientation] || null
                    }), e.prototype.render.call(this, t)
                }, t.prototype.__hlsLoaded = function (e) {
                    if (!Hls.isSupported()) return this.notify({
                        type: "error",
                        code: 5,
                        timeStamp: +new Date
                    });
                    var t = new Hls;
                    t.loadSource(e), t.attachMedia(this.el), t.on(Hls.Events.MANIFEST_PARSED, function (e, t) {}), t.on(Hls.Events.MEDIA_DETACHED, function () {}), t.on(Hls.Events.ERROR, h.bind(this, this.__hlsOnError)), this.hls = t
                }, t.prototype.__hlsOnManifestParsed = function (e, t) {
                    this.metaDataLoaded = !0
                }, t.prototype.__hlsOnError = function (e, t) {
                    var n = t.type,
                        i = t.details,
                        o = t.fatal,
                        r = this.hls;
                    if (o) switch (n) {
                    case Hls.ErrorTypes.NETWORK_ERROR:
                        i.indexOf("TimeOut") > 0 ? h.console.error("加载视频文件超时") : h.console.error("无法加载视频文件，请检查网络，以及视频文件是否允许跨域请求访问，m3u8文件是否存在 " + (t.response && t.response.status ? "netstatus:" + t.response.status : "")), this.notify({
                            type: "error",
                            code: 2,
                            timeStamp: +new Date
                        }), r.startLoad();
                        break;
                    case Hls.ErrorTypes.MEDIA_ERROR:
                        r.recoverMediaError();
                        break;
                    default:
                        r.destroy()
                    }
                }, t.prototype.__flvLoaded = function (e) {
                    if (!flvjs.isSupported()) return this.notify({
                        type: "error",
                        code: 5,
                        timeStamp: +new Date
                    });
                    var t = flvjs.createPlayer({
                        type: "flv",
                        isLive: this.player.options.live,
                        url: e
                    });
                    t.attachMediaElement(this.el), t.on(flvjs.Events.ERROR, h.bind(this, function (e, t, n) {
                        var i = {
                            type: "error"
                        };
                        e == flvjs.ErrorTypes.NETWORK_ERROR && (i.code = 2), e == flvjs.ErrorTypes.MEDIA_ERROR && (i.code = 1002), e == flvjs.ErrorTypes.OTHER_ERROR, i.timeStamp = +new Date, this.notify(i)
                    })), t.on(flvjs.Events.MEDIA_INFO, h.bind(this, function (e, t) {
                        console.log("flv MEDIA_INFO", e, t)
                    })), t.on(flvjs.Events.STATISTICS_INFO, h.bind(this, function (e, t) {})), this.flv = t, t.load()
                }, t.prototype.setup = function () {
                    this.playState = m.PlayStates.IDLE, this.seekState = m.SeekStates.IDLE, this.metaDataLoaded = !1, this.__timebase = +new Date, this.on(y.MSG.MetaLoaded, this.notify), this.on(y.MSG.Loaded, this.notify), this.on(y.MSG.Progress, this.notify), this.on(y.MSG.Play, this.notify), this.on(y.MSG.Playing, this.notify), this.on(y.MSG.Pause, this.notify), this.on(y.MSG.Error, this.notify), this.on(y.MSG.TimeUpdate, this.notify), this.on(y.MSG.Ended, this.notify), this.on(y.MSG.Seeking, this.notify), this.on(y.MSG.Seeked, this.notify), this.on(y.MSG.VolumeChange, this.notify), this.on("durationchange", this.notify), this.load(this.options.src, this.options.m3u8 ? h.VideoType.M3U8 : "")
                }, t.prototype.notify = function (e) {
                    var t = {
                        type: e.type,
                        src: this,
                        ts: +new Date,
                        timeStamp: e.timeStamp
                    };
                    switch (e.type) {
                    case y.MSG.MetaLoaded:
                        this.metaDataLoaded = !0;
                        break;
                    case y.MSG.Error:
                        var n = {
                            1: "MEDIA_ERR_ABORTED",
                            2: "MEDIA_ERR_NETWORK",
                            3: "MEDIA_ERR_DECODE",
                            4: "MEDIA_ERR_SRC_NOT_SUPPORTED"
                        };
                        t.detail = this.el && this.el.error || {
                            code: e.code
                        }, t.detail.reason = n[t.detail.code];
                        break;
                    case y.MSG.Ended:
                        this.pause(), this.playState = m.PlayStates.STOP;
                        break;
                    case "durationchange":
                        0 != this.videoHeight() && (t.type = y.MSG.Resize);
                        break;
                    case y.MSG.Playing:
                        this.playState = e.type.toUpperCase();
                        break;
                    case y.MSG.Pause:
                        this.playState = m.PlayStates.PAUSED;
                        break;
                    case y.MSG.Seeking:
                    case y.MSG.Seeked:
                        this.seekState = e.type.toUpperCase()
                    }
                    "timeupdate" != e.type, this.pub(t)
                }, t.prototype.videoWidth = function () {
                    return this.el.videoWidth
                }, t.prototype.videoHeight = function () {
                    return this.el.videoHeight
                }, t.prototype.width = function (e) {
                    return e ? void(this.el.style.width = e) : this.el.width
                }, t.prototype.height = function (e) {
                    return e ? void(this.el.style.height = e) : this.el.height
                }, t.prototype.play = function () {
                    this.el.play()
                }, t.prototype.togglePlay = function () {
                    var e = this.options.src.indexOf(".m3u8") > -1;
                    this.options.live && e && this.playState == m.PlayStates.IDLE && !this.metaDataLoaded && 10 != b.IOS_VERSION ? this.player.load() : this.paused() ? this.play() : this.pause()
                }, t.prototype.pause = function () {
                    this.el.pause()
                }, t.prototype.stop = function () {
                    this.el.pause(), this.el.currentTime = 0
                }, t.prototype.paused = function () {
                    return this.el.paused
                }, t.prototype.buffered = function () {
                    return this.el.buffered.length >= 1 ? this.el.buffered.end(this.el.buffered.length - 1) : 0
                }, t.prototype.currentTime = function (e) {
                    return "undefined" == typeof e ? this.el.currentTime : this.el.currentTime = e
                }, t.prototype.duration = function () {
                    return this.el.duration || 0
                }, t.prototype.mute = function (e) {
                    return "undefined" == typeof e ? this.el.muted : (this.volume(e ? 0 : this.__lastVol), this.el.muted = e)
                }, t.prototype.volume = function (e) {
                    return "undefined" == typeof e ? this.el.volume : (e < 0 && (e = 0), e > 1 && (e = 1), 0 != e && (this.__lastVol = e), this.el.muted = 0 == e, this.options.volume = e, this.el.volume = e)
                }, t.prototype.fullscreen = function (e) {
                    return h.doFullscreen(this.player, e, this.owner)
                }, t.prototype.load = function (e, t) {
                    this.pub({
                        type: y.MSG.Load,
                        src: this,
                        ts: +new Date,
                        detail: {
                            src: e,
                            type: t
                        }
                    });
                    var n = e.indexOf(".m3u8") > -1 || t == h.VideoType.M3U8,
                        i = e.indexOf(".flv") > -1;
                    if (!b.IS_ENABLED_MSE || !n && !i || b.IS_X5TBS && this.player.options.x5_player || n && b.IS_MAC && b.IS_SAFARI && !b.IS_IOS) this.__type = t, this.el.src = e;
                    else {
                        var o = this,
                            r = w[this.options.hls] || w["0.7.1"];
                        n ? (this.__type = h.VideoType.M3U8, "undefined" == typeof window.Hls ? d.loadScript(h.CDNPath + r, function () {
                            o.__hlsLoaded.call(o, e)
                        }) : this.__hlsLoaded(e)) : i && (this.__type = h.VideoType.FLV, "undefined" == typeof window.flvjs ? d.loadScript(h.CDNPath + "libs/flv.js", function () {
                            o.__flvLoaded.call(o, e)
                        }) : this.__flvLoaded(e))
                    }
                }, t.prototype.playing = function () {
                    return !this.el.paused
                }, t.prototype.type = function () {
                    return this.__type
                }, t
            }(c.
        default);
        t.
    default = _
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function r(e, t) {
            return t + "_" + e
        }
        function s(e, t) {
            return t.guid && String(t.guid).indexOf("_") == -1 ? e + "_" + t.guid : t.guid
        }
        t.__esModule = !0;
        var a = n(7),
            l = i(a),
            u = n(8),
            c = i(u),
            p = n(9),
            d = i(p),
            f = n(5),
            h = i(f),
            y = function () {
                function e(t, n) {
                    o(this, e), this.name = n, this.player = t, this.options = t.options, this.fnCache = {}, this.guid = c.guid()
                }
                return e.prototype.createEl = function (e, t, n) {
                    return this.el = l.createEl(e, t, n)
                }, e.prototype.render = function (e) {
                    return e && this.el && (this.owner = e, e.appendChild(this.el), this.setup()), this.el
                }, e.prototype.on = function (e, t, n) {
                    "string" == typeof e && (n = t, t = e, e = this.el), h.IS_MOBILE && "click" == t && (t = "touchend"), this.cbs = this.cbs || {};
                    var i = s(this.guid, n),
                        o = !i,
                        a = i && !this.fnCache[i];
                    return o || a ? (n = c.bind(this, n, this.guid), this.fnCache[n.guid] = n, i = n.guid) : n = this.fnCache[i], l.on(e, t, n), this.cbs[r(i, t)] = {
                        guid: i,
                        el: e,
                        type: t
                    }, n
                }, e.prototype.off = function (e, t, n) {
                    "string" == typeof e && (n = t, t = e, e = this.el), h.IS_MOBILE && "click" == t && (t = "touchend");
                    var i = s(this.guid, n);
                    this.fnCache[i] && (n = this.fnCache[i]), l.off(e, t, n), delete this.cbs[r(i, t)]
                }, e.prototype.pub = function (e) {
                    var t = this;
                    setTimeout(function () {
                        d.pub(e, t.player)
                    }, 0)
                }, e.prototype.sub = function (e, t, n) {
                    d.sub(e, t, n, this.player)
                }, e.prototype.unsub = function (e, t, n) {
                    d.unsub(e, t, n, this.player)
                }, e.prototype.handleMsg = function () {}, e.prototype.setup = function () {}, e.prototype.destroy = function () {
                    if (this.handleMsg && this.unsub("*", "*", this.handleMsg), this.cbs) {
                        for (var e in this.cbs) if (this.cbs.hasOwnProperty(e)) {
                            var t = this.cbs[e];
                            l.off(t.el, t.type, this.fnCache[t.guid]), delete this.cbs[e]
                        }
                        this.fnCache = null, this.cbs = null;
                        try {
                            this.el.parentNode.removeChild(this.el)
                        } catch (e) {}
                    }
                }, e
            }();
        t.
    default = y
    }, function (e, t) {
        "use strict";
        t.__esModule = !0;
        t.PlayStates = {
            IDLE: "IDLE",
            PLAYING: "PLAYING",
            PAUSED: "PAUSED",
            STOP: "STOP"
        }, t.SeekStates = {
            IDLE: "IDLE",
            SEEKING: "SEEKING",
            SEEKED: "SEEKED"
        }, t.ControlsStates = {
            DEFAULT: "default",
            NONE: "none",
            SYSTEM: ""
        }
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        function l(e) {
            return window.document[e] ? window.document[e] : navigator.appName.indexOf("Microsoft Internet") != -1 ? document.getElementById(e) : document.embeds && document.embeds[e] ? document.embeds[e] : void 0
        }
        t.__esModule = !0;
        var u = n(16),
            c = o(u),
            p = n(9),
            d = n(7),
            f = i(d),
            h = n(8),
            y = i(h),
            v = n(17),
            m = i(v),
            g = n(5),
            b = i(g),
            w = function (e) {
                function t(n) {
                    r(this, t);
                    var i = s(this, e.call(this, n, "FlashVideo")),
                        o = "vcpFlashCB_" + i.guid;
                    return i.__flashCB = o, window[o] || (window[o] = function (e, t) {
                        t = t && t[0];
                        var n = window[o].fnObj && window[o].fnObj[t.objectID];
                        n && n(e, t)
                    }, window[o].fnObj = {}), i
                }
                return a(t, e), t.prototype.render = function (e) {
                    this.__timebase = +new Date;
                    var t = "//imgcache.qq.com/open/qcloud/video/player/release/QCPlayer.swf",
                        n = (this.player.options, "opaque"),
                        i = "obj_vcplayer_" + this.player.guid,
                        o = this.__flashCB;
                    this.__id = i;
                    var r = f.createEl("div", {
                        class: "vcp-video"
                    });
                    r.innerHTML = '\n\t\t<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="" id="' + i + '" width="100%" height="100%">\n            <param name="movie"  value="' + t + '" />\n            <param name="quality" value="autohigh" />\n            <param name="swliveconnect" value="true" />\n            <param name="allowScriptAccess" value="always" />\n            <param name="bgcolor" value="#000" />\n            <param name="allowFullScreen" value="true" />\n            <param name="wmode" value="' + n + '" />\n            <param name="FlashVars" value="cbName=' + o + '" />\n\n            <embed src="' + t + '" width="100%" height="100%" name="' + i + '"\n                   quality="autohigh"\n                   bgcolor="#000"\n                   align="middle" allowFullScreen="true"\n                   allowScriptAccess="always"\n                   type="application/x-shockwave-flash"\n                   swliveconnect="true"\n                   wmode="' + n + '"\n                   FlashVars="cbName=' + o + '"\n                   pluginspage="http://www.macromedia.com/go/getflashplayer" >\n            </embed>\n        </object>\n\t\t', this.container = r, this.owner = e, this.owner.appendChild(r), this.cover = f.createEl("div", {
                        class: "vcp-pre-flash"
                    }), this.owner.appendChild(this.cover), window[this.__flashCB].fnObj[this.__id] = y.bind(this, this.notify)
                }, t.prototype.setup = function () {
                    this.on("error", this.notify), this.playState = m.PlayStates.IDLE, this.seekState = m.SeekStates.IDLE, this.metaDataLoaded = !1
                }, t.prototype.doPolling = function () {
                    this.options.live || (clearInterval(this.__timer), this.__timer = setInterval(this.interval.bind(this), 1e3))
                }, t.prototype.endPolling = function () {
                    clearInterval(this.__timer)
                }, t.prototype.interval = function () {
                    var e;
                    try {
                        e = this.el.getState()
                    } catch (e) {
                        return void this.endPolling()
                    }
                    if (this.__m3u8) {
                        var t = this.currentTime() + e.bufferLength;
                        this.__buffered !== t && (this.__buffered = t, this.pub({
                            type: p.MSG.Progress,
                            src: this,
                            ts: +new Date
                        })), this.__buffered >= this.duration() && this.endPolling()
                    } else this.__rtmp || (this.__bytesloaded != e.bytesLoaded && (this.__bytesloaded = e.bytesLoaded, this.pub({
                        type: p.MSG.Progress,
                        src: this,
                        ts: +new Date
                    })), this.__bytesloaded >= this.__bytesTotal && this.endPolling())
                }, t.prototype.destroy = function () {
                    delete window[this.__flashCB].fnObj[this.__id], this.endPolling(), e.prototype.destroy.call(this)
                }, t.prototype.notify = function (e, t) {
                    var n = {
                        type: e,
                        ts: +new Date
                    };
                    try {
                        switch (this.options.debug && this.pub({
                            type: n.type,
                            src: this,
                            ts: n.ts,
                            detail: y.extend({
                                debug: !0
                            }, t)
                        }), n.type) {
                        case "ready":
                            if (this.el = l(this.__id), this.setup(), b.IS_FIREFOX) {
                                var i = this;
                                setTimeout(function () {
                                    i.el.setAutoPlay( !! i.options.autoplay), i.__timebase = new Date - t.time, i.load(i.options.src)
                                }, 0)
                            } else this.el.setAutoPlay( !! this.options.autoplay), this.__timebase = new Date - t.time, this.load(this.options.src);
                            return;
                        case "metaData":
                            n.type = p.MSG.MetaLoaded, this.__videoWidth = t.videoWidth, this.__videoHeight = t.videoHeight, this.__duration = t.duration, this.__bytesTotal = t.bytesTotal, this.__prevPlayState = null, this.__m3u8 = t.type === y.VideoType.M3U8, this.__rtmp = t.type === y.VideoType.RTMP, this.__type = t.type,
                            //!this.options.autoplay && this.pause();//这一步已经在flash中实现，只需要初始化的时候给flash传递 autoplay参数
                            this.__metaloaded = !0, this.metaDataLoaded = !0, this.doPolling();
                            var i = this;
                            if (!i.cover) break;
                            setTimeout(function () {
                                i.cover && (i.owner.removeChild(i.cover), i.cover = null)
                            }, 500);
                            break;
                        case "playState":
                            this.playState = t.playState, t.playState == m.PlayStates.PLAYING ? (this.__playing = !0, this.__stopped = !1, n.type = p.MSG.Play) : t.playState == m.PlayStates.PAUSED ? (this.__playing = !1, this.__stopped = !1, n.type = p.MSG.Pause) : t.playState == m.PlayStates.STOP ? (this.__playing = !1, this.__stopped = !0, n.type = p.MSG.Ended, this.__prevPlayState = null, this.options.live && (this.metaDataLoaded = !1)) : t.playState == m.PlayStates.IDLE && (this.__playing = !1, this.__stopped = !0, n.type = p.MSG.Ended);
                            break;
                        case "seekState":
                            if (this.seekState = t.seekState, !this.__metaloaded) return;
                            if (t.seekState == m.SeekStates.SEEKING) n.type = p.MSG.Seeking;
                            else {
                                if (t.seekState != m.SeekStates.SEEKED) return;
                                this.__m3u8 || this.options.live || t.playState != m.PlayStates.STOP || (this.play(), this.__prevPlayState = t.playState), n.type = p.MSG.Seeked
                            }
                            break;
                        case "netStatus":
                            this.options.live || ("NetStream.Buffer.Full" == t.code ? (this.__prevPlayState == m.PlayStates.PAUSED || this.__prevPlayState == m.PlayStates.STOP, this.__prevPlayState = null) : "NetStream.Seek.Complete" == t.code), "NetConnection.Connect.Closed" == t.code && this.options.src.indexOf("rtmp://") > -1 && (this.playState == m.PlayStates.STOP ? (n.type = "error", t = {
                                code: 13,
                                reason: t.code
                            }) : (n.type = "error", t = {
                                code: 1002,
                                reason: t.code
                            })), "NetStream.Play.Stop" == t.code;
                            break;
                        case "mediaTime":
                            this.__videoWidth = t.videoWidth, this.__videoHeight = t.videoHeight, n.type = p.MSG.TimeUpdate;
                            break;
                        case "error":
                            if ("NetStream.Seek.InvalidTime" == t.code) return this.currentTime(t.details), !1;
                            "NetStream.Play.StreamNotFound" == t.code && this.pub({
                                type: "netStatus",
                                src: this,
                                ts: n.ts,
                                detail: t
                            });
                            var o = isNaN(parseInt(t.code)) ? 1002 : t.code,
                                r = isNaN(parseInt(t.code)) ? t.code : t.msg,
                                s = r.match(/#(\d+)/);
                            s && s[1] && (o = s[1]), t = {
                                code: o,
                                reason: r || ""
                            }, this.metaDataLoaded = !1
                        }
                        var a = "printLog" == e || "canPlay" == e;
                        !a && this.pub({
                            type: n.type,
                            src: this,
                            ts: n.ts,
                            detail: t
                        })
                    } catch (t) {
                        y.console.error(e + " " + n.type, t)
                    }
                }, t.prototype.handleMsg = function (e) {}, t.prototype.videoWidth = function () {
                    return this.__videoWidth
                }, t.prototype.videoHeight = function () {
                    return this.__videoHeight
                }, t.prototype.width = function (e) {
                    return "undefined" == typeof e ? this.el && this.el.width : (e = "100%", this.el && (this.el.width = e))
                }, t.prototype.height = function (e) {
                    return "undefined" == typeof e ? this.el && this.el.height : (e = "100%", this.el && (this.el.height = e))
                }, t.prototype.play = function () {
                    this.el.playerResume()
                }, t.prototype.togglePlay = function () {
                    this.metaDataLoaded ? this.playState == m.PlayStates.PAUSED ? this.el.playerResume() : this.playState == m.PlayStates.PLAYING ? this.el.playerPause() : this.playState == m.PlayStates.STOP ? (this.currentTime(0), this.el.playerResume()) : this.el.playerPlay() : this.player.load()
                }, t.prototype.pause = function () {
                    this.el.playerPause()
                }, t.prototype.stop = function () {
                    this.el.playerStop()
                }, t.prototype.paused = function () {
                    return !this.__playing
                }, t.prototype.buffered = function () {
                    var e;
                    return this.__m3u8 ? this.__buffered || 0 : (e = (this.__bytesloaded || 0) / (this.__bytesTotal || 1), this.duration() * e)
                }, t.prototype.currentTime = function (e) {
                    return "undefined" == typeof e ? this.el.getPosition() : void this.el.playerSeek(e)
                }, t.prototype.duration = function () {
                    return this.__duration
                }, t.prototype.mute = function (e) {
                    return "undefined" == typeof e ? 0 == this.volume() : void this.volume(e ? 0 : this.__lastVol)
                }, t.prototype.volume = function (e) {
                    return "undefined" == typeof e ? this.el && this.el.getState().volume : (this.el && this.el.playerVolume(e), 0 != e && (this.__lastVol = e), this.options.volume = e, void this.pub({
                        type: p.MSG.VolumeChange,
                        src: this,
                        ts: +new Date
                    }))
                }, t.prototype.fullscreen = function (e) {
                    return y.doFullscreen(this.player, e, this.owner)
                }, t.prototype.load = function (e, t) {
                    this.pub({
                        type: p.MSG.Load,
                        src: this,
                        ts: +new Date,
                        detail: {
                            src: e,
                            type: t
                        }
                    }), this.el && this.el.playerLoad(e)
                }, t.prototype.playing = function () {
                    return this.el && this.el.getState && this.el.getState().playState === m.PlayStates.PLAYING
                }, t.prototype.type = function () {
                    return this.__type
                }, t.prototype.state = function () {
                    return this.playState
                }, t
            }(c.
        default);
        t.
    default = w
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(16),
            u = o(l),
            c = n(20),
            p = o(c),
            d = n(21),
            f = o(d),
            h = n(22),
            y = n(23),
            v = o(y),
            m = n(24),
            g = o(m),
            b = n(25),
            w = o(b),
            _ = n(26),
            x = o(_),
            S = n(9),
            E = n(7),
            T = i(E),
            C = n(8),
            k = i(C),
            M = n(5),
            O = i(M),
            N = function (e) {
                function t(n) {
                    return r(this, t), s(this, e.call(this, n, "Panel"))
                }
                return a(t, e), t.prototype.render = function (t) {
                    return this.createEl("div", {
                        class: "vcp-controls-panel"
                    }), this.el.appendChild(T.createEl("div", {
                        class: "vcp-panel-bg"
                    })), this.playToggle = new p.
                default (this.player), this.playToggle.render(this.el), this.timelabel = new g.
                default (this.player), this.timelabel.render(this.el), this.timeline = new v.
                default (this.player), this.timeline.render(this.el), this.options.fullscreenEnabled === !0 && (this.fullscreen = new f.
                default (this.player), this.fullscreen.render(this.el)), O.IS_MOBILE || (this.volume = new w.
                default (this.player), this.volume.render(this.el)), this.options.videoSource && this.options.videoSource.definitions.length > 1 && !O.IS_MOBILE && (this.claritySwitcher = new x.
                default (this.player), this.claritySwitcher.render(this.el)), e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    var e = k.bind(this, this.handleMsg);
                    this.sub(h.MSG.Changing, this.volume, e), this.sub(h.MSG.Changed, this.timeline.progress, e), this.sub(S.MSG.TimeUpdate, this.player.video, e), this.sub(S.MSG.Progress, this.player.video, e), this.sub(S.MSG.MetaLoaded, this.player.video, e), this.sub(S.MSG.Pause, this.player.video, e), this.sub(S.MSG.Play, this.player.video, e), this.sub(S.MSG.Ended, this.player.video, e)
                }, t.prototype.handleMsg = function (e) {
                    switch (e.type) {
                    case S.MSG.MetaLoaded:
                        this.timeline.percent(this.player.percent()), this.timeline.buffered(this.player.buffered()), this.player.volume("undefined" == typeof this.options.volume ? .5 : this.options.volume), !this.options.autoplay && this.show();
                        break;
                    case S.MSG.TimeUpdate:
                        this.timeline.scrubbing || this.timeline.percent(this.player.percent());
                        break;
                    case S.MSG.Pause:
                        this.show();
                        break;
                    case S.MSG.Play:
                        this.hide();
                        break;
                    case S.MSG.Progress:
                        this.timeline.buffered(this.player.buffered());
                        break;
                    case h.MSG.Changed:
                        e.src === this.timeline.progress && this.player.percent(this.timeline.percent());
                        break;
                    case S.MSG.Ended:
                        this.show()
                    }
                }, t.prototype.toggle = function () {
                    T.hasClass(this.el, "show") ? this.hide() : this.show()
                }, t.prototype.show = function () {
                    T.hasClass(this.el, "hide") && (T.removeClass(this.el, "hide"), T.addClass(this.el, "show"))
                }, t.prototype.hide = function () {
                    T.removeClass(this.el, "show"), T.addClass(this.el, "hide")
                }, t
            }(u.
        default);
        t.
    default = N
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(16),
            u = o(l),
            c = n(7),
            p = (i(c), n(9)),
            d = (i(p), n(8)),
            f = (i(d), n(17)),
            h = (i(f), function (e) {
                function t(n) {
                    return r(this, t), s(this, e.call(this, n, "PlayToggle"))
                }
                return a(t, e), t.prototype.render = function (t) {
                    return this.createEl("div", {
                        class: "vcp-playtoggle"
                    }), e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    this.on("click", this.onClick)
                }, t.prototype.onClick = function () {
                    this.player.togglePlay()
                }, t.prototype.handleMsg = function (e) {
                    console.log("@" + this.name, e)
                }, t
            }(u.
        default));
        t.
    default = h
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(16),
            u = o(l),
            c = n(7),
            p = (i(c), n(9)),
            d = (i(p), n(8)),
            f = i(d),
            h = function (e) {
                function t(n) {
                    return r(this, t), s(this, e.call(this, n, "FullscreenToggle"))
                }
                return a(t, e), t.prototype.render = function (t) {
                    return this.createEl("div", {
                        class: "vcp-fullscreen-toggle"
                    }), window.fsApi = f.FullscreenApi, e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    this.on("click", this.onClick)
                }, t.prototype.onClick = function () {
                    this.player.fullscreen(!this.player.fullscreen())
                }, t.prototype.handleMsg = function (e) {
                    console.log(t.name, e)
                }, t
            }(u.
        default);
        t.
    default = h
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0, t.MSG = void 0;
        var l = n(16),
            u = o(l),
            c = n(7),
            p = i(c),
            d = n(9),
            f = (i(d), n(8)),
            h = (i(f), t.MSG = {
                Changing: "sliderchanging",
                Changed: "sliderchanged"
            }),
            y = function (e) {
                function t(n, i) {
                    r(this, t);
                    var o = s(this, e.call(this, n, "Slider"));
                    return o.vertical = i || !1, o
                }
                return a(t, e), t.prototype.render = function (t, n) {
                    var i = this.vertical ? "vcp-slider-vertical" : "vcp-slider";
                    return this.createEl("div", {
                        class: i
                    }), this.track = p.createEl("div", {
                        class: "vcp-slider-track"
                    }), this.thumb = p.createEl("div", {
                        class: "vcp-slider-thumb"
                    }), this.el.appendChild(this.track), this.el.appendChild(this.thumb), this.enabled = "undefined" == typeof n || n, e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    this.enabled && (this.ownerDoc = document.body.ownerDocument, this.on("mousedown", this.mousedown), this.on("touchstart", this.mousedown))
                }, t.prototype.handleMsg = function (e) {}, t.prototype.mousedown = function (e) {
                    return e.preventDefault && e.preventDefault(), this.pos = p.findElPosition(this.el), this.on(this.ownerDoc, "mouseup", this.mouseup), this.on(this.ownerDoc, "mousemove", this.mousemove), this.on(this.ownerDoc, "touchend", this.mouseup), this.on(this.ownerDoc, "touchmove", this.mousemove), this.mousemove(e), !1
                }, t.prototype.mouseup = function (e) {
                    e.target || e.srcElement;
                    this.off(this.ownerDoc, "mouseup", this.mouseup), this.off(this.ownerDoc, "mousemove", this.mousemove), this.off(this.ownerDoc, "touchend", this.mouseup), this.off(this.ownerDoc, "touchmove", this.mousemove), this.pub({
                        type: h.Changed,
                        src: this,
                        private: !0
                    })
                }, t.prototype.mousemove = function (e) {
                    var t = p.getPointerPosition(this.el, e, this.pos);
                    this.vertical ? (this.__percent = 1 - t.y, this.thumb.style.top = 100 * this.__percent + "%") : (this.__percent = t.x, this.thumb.style.left = 100 * this.__percent + "%"), this.__percent = Number(this.__percent.toFixed(3)), this.pub({
                        type: h.Changing,
                        src: this,
                        private: !0
                    })
                }, t.prototype.percent = function (e) {
                    return e ? (this.__percent = e, void(this.vertical ? this.thumb.style.top = 100 * this.__percent + "%" : this.thumb.style.left = 100 * this.__percent + "%")) : this.__percent
                }, t
            }(u.
        default);
        t.
    default = y
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(22),
            u = o(l),
            c = n(16),
            p = o(c),
            d = n(7),
            f = (i(d), n(8)),
            h = i(f),
            y = function (e) {
                function t(n) {
                    return r(this, t), s(this, e.call(this, n, "Timeline"))
                }
                return a(t, e), t.prototype.render = function (t) {
                    return this.enabled = !this.options.live, this.createEl("div", {
                        class: "vcp-timeline"
                    }), this.progress = new u.
                default (this.player, !1), this.progress.render(this.el, this.enabled), this.track = this.progress.track, this.enabled || (this.el.style.display = "none"), e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    this.enabled && (this.sub(l.MSG.Changing, this.progress, h.bind(this, this.handleMsg)), this.sub(l.MSG.Changed, this.progress, h.bind(this, this.handleMsg)))
                }, t.prototype.handleMsg = function (e) {
                    e.type === l.MSG.Changing ? (this.scrubbing = !0, this.syncLabel(this.percent())) : e.type === l.MSG.Changed && (this.scrubbing = !1)
                }, t.prototype.syncLabel = function (e) {
                    var t = this.player.duration();
                    e = Math.min(e, 1);
                    var n = "";
                    t && (n = h.convertTime(e * t) + " / " + h.convertTime(t)), this.pub({
                        type: "timelabel",
                        src: "timeline",
                        label: n,
                        private: !0
                    })
                }, t.prototype.buffered = function (e) {
                    this.enabled && (e = Math.min(e, 1), this.__buffered = e, this.track.style.width = 100 * e + "%")
                }, t.prototype.percent = function (e) {
                    if (this.enabled) return "undefined" == typeof e ? this.progress.percent() || 0 : (e = Math.min(e, 1), this.syncLabel(e), this.__buffered < e && this.buffered(this.player.buffered()), this.progress.percent(e))
                }, t
            }(p.
        default);
        t.
    default = y
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(22),
            u = (o(l), n(16)),
            c = o(u),
            p = n(7),
            d = (i(p), n(8)),
            f = i(d),
            h = function (e) {
                function t(n) {
                    return r(this, t), s(this, e.call(this, n, "Timelabel"))
                }
                return a(t, e), t.prototype.render = function (t) {
                    return this.createEl("span", {
                        class: "vcp-timelabel"
                    }), e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    this.sub("timelabel", "timeline", f.bind(this, this.handleMsg))
                }, t.prototype.handleMsg = function (e) {
                    this.el.innerHTML = e.label
                }, t
            }(c.
        default);
        t.
    default = h
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(22),
            u = o(l),
            c = n(16),
            p = o(c),
            d = n(7),
            f = i(d),
            h = n(8),
            y = i(h),
            v = n(9),
            m = function (e) {
                function t(n) {
                    return r(this, t), s(this, e.call(this, n, "Volume"))
                }
                return a(t, e), t.prototype.render = function (t) {
                    return this.createEl("div", {
                        class: "vcp-volume"
                    }), this.bg = f.createEl("div", {
                        class: "vcp-volume-bg"
                    }), this.el.appendChild(this.bg), this.volume = new u.
                default (this.player, !0), this.volume.render(this.el), this.track = this.volume.track, this.icon = f.createEl("span", {
                        class: "vcp-volume-icon"
                    }), this.el.appendChild(this.icon), e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    this.sub(l.MSG.Changing, this.volume, y.bind(this, this.handleMsg)), this.sub(l.MSG.Changed, this.volume, y.bind(this, this.handleMsg)), this.sub(v.MSG.VolumeChange, this.player.video, y.bind(this, this.handleMsg)), this.on(this.icon, "click", this.toggleMute)
                }, t.prototype.handleMsg = function (e) {
                    switch (e.type) {
                    case l.MSG.Changing:
                        this.syncTrack(this.percent());
                        break;
                    case l.MSG.Changed:
                        this.percent(this.percent());
                        break;
                    case v.MSG.VolumeChange:
                        var t = this.player.volume();
                        this.syncTrack(t), 0 == t ? this.syncMute(!0) : t > 0 && this.__muted && this.syncMute(!1)
                    }
                }, t.prototype.toggleMute = function (e) {
                    var t = !this.player.mute();
                    this.player.mute(t)
                }, t.prototype.syncMute = function (e) {
                    e ? f.addClass(this.el, "vcp-volume-muted") : f.removeClass(this.el, "vcp-volume-muted"), this.__muted = e
                }, t.prototype.syncTrack = function (e) {
                    this.track.style.height = 100 * e + "%", this.volume.percent(1 - e)
                }, t.prototype.percent = function (e) {
                    return "undefined" == typeof e ? 1 - this.volume.percent() || 0 : (this.player.volume(e), e)
                }, t
            }(p.
        default);
        t.
    default = m
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(16),
            u = o(l),
            c = n(7),
            p = i(c),
            d = n(8),
            f = (i(d), {
                od: "超清",
                hd: "高清",
                sd: "标清"
            }),
            h = function (e) {
                function t(n) {
                    return r(this, t), s(this, e.call(this, n, "ClaritySwitcher"))
                }
                return a(t, e), t.prototype.render = function (t) {
                    this.show = !1, this.createEl("div", {
                        class: "vcp-clarityswitcher"
                    }), this.current = p.createEl("a", {
                        class: "vcp-vertical-switcher-current"
                    }), this.container = p.createEl("div", {
                        class: "vcp-vertical-switcher-container"
                    }), this.items = [], this.currentItem = "";
                    var n = this.options.videoSource;
                    this.current.innerHTML = f[n.curDef], this.el.appendChild(this.current);
                    for (var i = 0; i < n.definitions.length; i++) {
                        var o = p.createEl("a", {
                            class: "vcp-vertical-switcher-item"
                        });
                        o.innerHTML = f[n.definitions[i]], n.definitions[i] == n.curDef && (o.classList.add("current"), this.currentItem = o), o.setAttribute("data-def", n.definitions[i]), this.items.push(o), this.container.appendChild(o)
                    }
                    return this.el.appendChild(this.container), e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    this.on("click", this.onClick), this.on("mouseenter", this.onMouseEnter), this.on("mouseleave", this.onMouseLeave)
                }, t.prototype.onClick = function (e) {
                    var t = e.target.getAttribute("data-def");
                    t ? (this.current.innerHTML = f[t], this.currentItem.classList.remove("current"), e.target.classList.add("current"), this.currentItem = e.target, this.player.switchClarity(t)) : !this.show
                }, t.prototype.onMouseLeave = function () {
                    this.container.style.display = "none", this.show = !1
                }, t.prototype.onMouseEnter = function () {
                    this.container.style.display = "block", this.show = !0
                }, t
            }(u.
        default);
        t.
    default = h
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(16),
            u = o(l),
            c = n(5),
            p = i(c),
            d = function (e) {
                function t(n) {
                    return r(this, t), s(this, e.call(this, n, "BigPlay"))
                }
                return a(t, e), t.prototype.render = function (t) {
                    return this.createEl("div", {
                        class: "vcp-bigplay"
                    }), e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    this.on("click", this.onClick)
                }, t.prototype.onClick = function () {
                    var e = this.player.video;
                    return p.IS_MOBILE && !e.paused() ? this.player.panel && this.player.panel.toggle() : void this.player.togglePlay()
                }, t.prototype.handleMsg = function (e) {
                    console.log("@" + this.name, e)
                }, t
            }(u.
        default);
        t.
    default = d
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ?
        function (e) {
            return typeof e
        } : function (e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        },
            u = n(16),
            c = o(u),
            p = n(7),
            d = i(p),
            f = n(8),
            h = i(f),
            y = n(5),
            v = (i(y), n(9)),
            m = function (e) {
                function t(n) {
                    r(this, t);
                    var i = s(this, e.call(this, n, "Poster"));
                    return i.options.poster && "object" == l(i.options.poster) ? i.poster = i.options.poster : "string" == typeof i.options.poster ? i.poster = {
                        src: i.options.poster
                    } : i.poster = {}, i
                }
                return a(t, e), t.prototype.render = function (t) {
                    this.createEl("div", {
                        class: "vcp-poster"
                    }), this.hide();
                    var n = this.poster;
                    if (n) {
                        this.pic = d.createEl("img", {
                            class: "vcp-poster-pic"
                        });
                        var i = this.poster.style;
                        switch (i) {
                        case "stretch":
                            d.addClass(this.pic, "stretch");
                            break;
                        case "cover":
                            d.addClass(this.pic, "cover");
                            break;
                        default:
                            d.addClass(this.pic, "default")
                        }
                        this.el.appendChild(this.pic)
                    }
                    return e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {
                    this.on("click", this.onClick), this.sub(v.MSG.Load, this.player.video, h.bind(this, this.handleMsg)), this.sub(v.MSG.MetaLoaded, this.player.video, h.bind(this, this.handleMsg)), this.sub(v.MSG.Play, this.player.video, h.bind(this, this.handleMsg)), this.sub(v.MSG.Pause, this.player.video, h.bind(this, this.handleMsg)), this.sub(v.MSG.Ended, this.player.video, h.bind(this, this.handleMsg)), this.sub(v.MSG.Error, this.player.video, h.bind(this, this.handleMsg))
                }, t.prototype.onClick = function () {
                    this.pub({
                        type: "click",
                        src: this
                    })
                }, t.prototype.handleMsg = function (e) {
                    switch (e.type) {
                    case v.MSG.Load:
                        this.__loaded = !1, this.setPoster(this.poster.start);
                        break;
                    case v.MSG.MetaLoaded:
                        if (this.__loaded = !0, !this.player.playing()) break;
                        this.hide();
                    case v.MSG.Play:
                        if (!this.__loaded) break;
                        this.hide();
                        break;
                    case v.MSG.Pause:
                        if (!this.__loaded) break;
                        this.options.coverpic_pause === !0 && this.setPoster(this.poster.pause);
                        break;
                    case v.MSG.Ended:
                        if (!this.__loaded) break;
                        break;
                    case v.MSG.Error:
                        if (!this.__loaded) break
                    }
                }, t.prototype.setPoster = function (e) {
                    if (e = e || this.poster.src) {
                        this.__preload && (this.__preload.onload = null), this.__preload = new Image;
                        var t = this.__preload;
                        this.hide();
                        var n = this;
                        t.onload = function () {
                            if (n.pic.src = t.src, n.show(), !h.supportStyle("transform")) {
                                var e = "stretch" == n.poster.style;
                                if (e) return;
                                var i = "cover" == n.poster.style ? n.options.width / (t.width / t.height) : t.height,
                                    o = "-" + n.options.width / 2 + "px",
                                    r = "-" + i / 2 + "px";
                                n.pic.style.cssText = "left: 50%; top: 50%; margin-left: " + o + "; margin-top: " + r + ";"
                            }
                        }, t.src = e
                    }
                }, t.prototype.toggle = function (e) {
                    clearTimeout(this.__tid);
                    var t = this;
                    this.__tid = setTimeout(function () {
                        t.el.style.display = e
                    }, 100)
                }, t.prototype.hide = function () {
                    this.__preload && (this.__preload.onload = null), this.toggle("none")
                }, t.prototype.show = function () {
                    this.toggle("block")
                }, t
            }(c.
        default);
        t.
    default = m
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(16),
            u = o(l),
            c = n(7),
            p = (i(c), n(9)),
            d = (i(p), n(8)),
            f = (i(d), {});
        !
        function (e, t) {
            e.Spinner = t()
        }(f, function () {
            function e(e, t) {
                var n, i = document.createElement(e || "div");
                for (n in t) i[n] = t[n];
                return i
            }
            function t(e) {
                for (var t = 1, n = arguments.length; n > t; t++) e.appendChild(arguments[t]);
                return e
            }
            function n(e, t, n, i) {
                var o = ["opacity", t, ~~ (100 * e), n, i].join("-"),
                    r = .01 + n / i * 100,
                    s = Math.max(1 - (1 - e) / t * (100 - r), e),
                    a = u.substring(0, u.indexOf("Animation")).toLowerCase(),
                    l = a && "-" + a + "-" || "";
                return d[o] || (c.insertRule("@" + l + "keyframes " + o + "{0%{opacity:" + s + "}" + r + "%{opacity:" + e + "}" + (r + .01) + "%{opacity:1}" + (r + t) % 100 + "%{opacity:" + e + "}100%{opacity:" + s + "}}", c.cssRules.length), d[o] = 1), o
            }
            function i(e, t) {
                var n, i, o = e.style;
                if (t = t.charAt(0).toUpperCase() + t.slice(1), void 0 !== o[t]) return t;
                for (i = 0; i < p.length; i++) if (n = p[i] + t, void 0 !== o[n]) return n
            }
            function o(e, t) {
                for (var n in t) e.style[i(e, n) || n] = t[n];
                return e
            }
            function r(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var n = arguments[t];
                    for (var i in n) void 0 === e[i] && (e[i] = n[i])
                }
                return e
            }
            function s(e, t) {
                return "string" == typeof e ? e : e[t % e.length]
            }
            function a(e) {
                this.opts = r(e || {}, a.defaults, f)
            }
            function l() {
                function n(t, n) {
                    return e("<" + t + ' xmlns="urn:schemas-microsoft.com:vml" class="spin-vml">', n)
                }
                c.addRule(".spin-vml", "behavior:url(#default#VML)"), a.prototype.lines = function (e, i) {
                    function r() {
                        return o(n("group", {
                            coordsize: c + " " + c,
                            coordorigin: -u + " " + -u
                        }), {
                            width: c,
                            height: c
                        })
                    }
                    function a(e, a, l) {
                        t(d, t(o(r(), {
                            rotation: 360 / i.lines * e + "deg",
                            left: ~~a
                        }), t(o(n("roundrect", {
                            arcsize: i.corners
                        }), {
                            width: u,
                            height: i.scale * i.width,
                            left: i.scale * i.radius,
                            top: -i.scale * i.width >> 1,
                            filter: l
                        }), n("fill", {
                            color: s(i.color, e),
                            opacity: i.opacity
                        }), n("stroke", {
                            opacity: 0
                        }))))
                    }
                    var l, u = i.scale * (i.length + i.width),
                        c = 2 * i.scale * u,
                        p = -(i.width + i.length) * i.scale * 2 + "px",
                        d = o(r(), {
                            position: "absolute",
                            top: p,
                            left: p
                        });
                    if (i.shadow) for (l = 1; l <= i.lines; l++) a(l, -2, "progid:DXImageTransform.Microsoft.Blur(pixelradius=2,makeshadow=1,shadowopacity=.3)");
                    for (l = 1; l <= i.lines; l++) a(l);
                    return t(e, d)
                }, a.prototype.opacity = function (e, t, n, i) {
                    var o = e.firstChild;
                    i = i.shadow && i.lines || 0, o && t + i < o.childNodes.length && (o = o.childNodes[t + i], o = o && o.firstChild, o = o && o.firstChild, o && (o.opacity = n))
                }
            }
            var u, c, p = ["webkit", "Moz", "ms", "O"],
                d = {},
                f = {
                    lines: 12,
                    length: 7,
                    width: 5,
                    radius: 10,
                    scale: 1,
                    corners: 1,
                    color: "#000",
                    opacity: .25,
                    rotate: 0,
                    direction: 1,
                    speed: 1,
                    trail: 100,
                    fps: 20,
                    zIndex: 2e9,
                    className: "spinner",
                    top: "50%",
                    left: "50%",
                    shadow: !1,
                    hwaccel: !1,
                    position: "absolute"
                };
            if (a.defaults = {}, r(a.prototype, {
                spin: function (t) {
                    this.stop();
                    var n = this,
                        i = n.opts,
                        r = n.el = e(null, {
                            className: i.className
                        });
                    if (o(r, {
                        position: i.position,
                        width: 0,
                        zIndex: i.zIndex,
                        left: i.left,
                        top: i.top
                    }), t && t.insertBefore(r, t.firstChild || null), r.setAttribute("role", "progressbar"), n.lines(r, n.opts), !u) {
                        var s, a = 0,
                            l = (i.lines - 1) * (1 - i.direction) / 2,
                            c = i.fps,
                            p = c / i.speed,
                            d = (1 - i.opacity) / (p * i.trail / 100),
                            f = p / i.lines;
                        !
                        function e() {
                            a++;
                            for (var t = 0; t < i.lines; t++) s = Math.max(1 - (a + (i.lines - t) * f) % p * d, i.opacity), n.opacity(r, t * i.direction + l, s, i);
                            n.timeout = n.el && setTimeout(e, ~~ (1e3 / c))
                        }()
                    }
                    return n
                },
                stop: function () {
                    var e = this.el;
                    return e && (clearTimeout(this.timeout), e.parentNode && e.parentNode.removeChild(e), this.el = void 0), this
                },
                lines: function (i, r) {
                    function a(t, n) {
                        return o(e(), {
                            position: "absolute",
                            width: r.scale * (r.length + r.width) + "px",
                            height: r.scale * r.width + "px",
                            background: t,
                            boxShadow: n,
                            transformOrigin: "left",
                            transform: "rotate(" + ~~ (360 / r.lines * c + r.rotate) + "deg) translate(" + r.scale * r.radius + "px,0)",
                            borderRadius: (r.corners * r.scale * r.width >> 1) + "px"
                        })
                    }
                    for (var l, c = 0, p = (r.lines - 1) * (1 - r.direction) / 2; c < r.lines; c++) l = o(e(), {
                        position: "absolute",
                        top: 1 + ~ (r.scale * r.width / 2) + "px",
                        transform: r.hwaccel ? "translate3d(0,0,0)" : "",
                        opacity: r.opacity,
                        animation: u && n(r.opacity, r.trail, p + c * r.direction, r.lines) + " " + 1 / r.speed + "s linear infinite"
                    }), r.shadow && t(l, o(a("#000", "0 0 4px #000"), {
                        top: "2px"
                    })), t(i, t(l, a(s(r.color, c), "0 0 1px rgba(0,0,0,.1)")));
                    return i
                },
                opacity: function (e, t, n) {
                    t < e.childNodes.length && (e.childNodes[t].style.opacity = n)
                }
            }), "undefined" != typeof document) {
                c = function () {
                    var n = e("style", {
                        type: "text/css"
                    });
                    return t(document.getElementsByTagName("head")[0], n), n.sheet || n.styleSheet
                }();
                var h = o(e("group"), {
                    behavior: "url(#default#VML)"
                });
                !i(h, "transform") && h.adj ? l() : u = i(h, "animation")
            }
            return a
        });
        var h = function (e) {
            function t(n) {
                r(this, t);
                var i = s(this, e.call(this, n, "Loading"));
                return i.timeSeed = null, i
            }
            return a(t, e), t.prototype.render = function (t) {
                this.createEl("div", {
                    class: "vcp-loading"
                });
                var n = {
                    lines: 11,
                    length: 12,
                    width: 4,
                    radius: 16,
                    scale: 1,
                    corners: 1,
                    color: "#fff",
                    opacity: .25,
                    rotate: 0,
                    direction: 1,
                    speed: 1,
                    trail: 60,
                    fps: 20,
                    zIndex: 2e9,
                    className: "vcp-spinner",
                    top: "50%",
                    left: "50%",
                    shadow: !1,
                    hwaccel: !0,
                    position: "absolute"
                };
                new f.Spinner(n).spin(this.el);
                return e.prototype.render.call(this, t)
            }, t.prototype.setup = function () {}, t.prototype.handleMsg = function (e) {}, t.prototype.show = function () {
                if (this.options.showLoading !== !1) {
                    var e = 1e3,
                        t = this;
                    this.timeSeed = setTimeout(function () {
                        t.el.style.display = "block"
                    }, e)
                }
            }, t.prototype.hide = function () {
                this.timeSeed && (clearTimeout(this.timeSeed), this.timeSeed = null), this.el.style.display = "none"
            }, t
        }(u.
    default);
        t.
    default = h
    }, function (e, t, n) {
        "use strict";

        function i(e) {
            if (e && e.__esModule) return e;
            var t = {};
            if (null != e) for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
            return t.
        default = e, t
        }
        function o(e) {
            return e && e.__esModule ? e : {
            default:
                e
            }
        }
        function r(e, t) {
            if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function");
        }
        function s(e, t) {
            if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
            return !t || "object" != typeof t && "function" != typeof t ? e : t
        }
        function a(e, t) {
            if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
            e.prototype = Object.create(t && t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
        }
        t.__esModule = !0;
        var l = n(16),
            u = o(l),
            c = n(7),
            p = (i(c), n(9)),
            d = (i(p), n(8)),
            f = i(d),
            h = {
                EnvError: "当前系统环境不支持播放该视频格式",
                EnvFlashError: "当前系统环境不支持播放该视频格式",
                VideoSourceError: "获取视频失败，请检查播放链接是否有效",
                NetworkError: "网络错误，请检查网络配置或者播放链接是否正确",
                VideoDecodeError: "视频解码错误",
                ArgumentError: "使用参数有误，请检查播放器调用代码",
                UrlEmpty: "请填写视频播放地址",
                FileProtocol: "请勿在file协议下使用播放器，可能会导致视频无法播放",
                LiveFinish: "直播已结束,请稍后再来",
                CrossDomainError: "无法加载视频文件，跨域访问被拒绝",
                Ie9IframeFullscreenError: "在IE9中用iframe引用的实例无法支持全屏"
            },
            y = {
                FileProtocol: [10],
                ArgumentError: [11],
                UrlEmpty: [12],
                LiveFinish: [13],
                VideoSourceError: [1002, 2032],
                EnvError: [4, 5],
                NetworkError: [1001, 1, 2],
                VideoDecodeError: [3],
                CrossDomainError: [2048],
                Ie9IframeFullscreenError: [10001]
            },
            v = function (e) {
                function t(n) {
                    r(this, t);
                    var i = s(this, e.call(this, n, "ErrorTips"));
                    i.customTips = f.extend({}, h, i.options.wording);
                    for (var o in y) for (var a = 0; a < y[o].length; a++) {
                        var l = y[o][a];
                        i.customTips[l] = i.customTips[l] || i.customTips[o]
                    }
                    return i
                }
                return a(t, e), t.prototype.render = function (t) {
                    return this.createEl("div", {
                        class: "vcp-error-tips"
                    }), e.prototype.render.call(this, t)
                }, t.prototype.setup = function () {}, t.prototype.handleMsg = function (e) {}, t.prototype.show = function (e) {
                    this.el.style.display = "block";
                    var t = void 0;
                    if ("string" == typeof e) t = e;
                    else {
                        var n = this.customTips[e.code] || e.reason;
                        t = "[" + e.code + "]" + n
                    }
                    this.el.innerHTML = f.escapeHTML(t)
                }, t.prototype.hide = function () {
                    this.el.style.display = "none"
                }, t.prototype.clear = function () {
                    this.el.innerHTML = "", this.hide()
                }, t
            }(u.
        default);
        t.
    default = v
    }])
}); /*  |xGv00|f556545a1231f03903adb8a27f2b5096 */