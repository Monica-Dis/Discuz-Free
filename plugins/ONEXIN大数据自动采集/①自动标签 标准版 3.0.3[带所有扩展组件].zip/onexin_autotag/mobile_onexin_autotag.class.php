<?php
/**
 * ONEXIN AUTOTAG For Discuz!X 2.0+
 * ============================================================================
 * 这不是一个自由软件！您只能在不用于商业目的的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布。
 * ============================================================================
 * @package    onexin_autotag
 * @module	   onexin_autotag
 * @date	   2019-07-15
 * @author	   DisM!应用中心：dism.taobao.com
 * @copyright  本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

/*

$(".tags a[href^='http://']");

*/

class mobileplugin_onexin_autotag {

	protected static $conf = array();

	public function mobileplugin_onexin_autotag() {
		global $_G;
		
		if(!isset($_G['cache']['plugin'])){
			loadcache('plugin');
		}
		
	}
		
	public function load_tag_engine($engine = "auto") {
		global $_G;
		
		if(!$_G['cache']['plugin']['onexin_autotag']['isopen']) return '';
		
		$yourself_file = DISCUZ_ROOT . './source/plugin/onexin_autotag/'.$engine.'.engine.php';
		if(file_exists($yourself_file)){
			include_once $yourself_file;
		}else{
			include_once DISCUZ_ROOT . './source/plugin/onexin_autotag/auto.engine.php';
		}
		
	}
		
}

// forum
class mobileplugin_onexin_autotag_forum extends mobileplugin_onexin_autotag {
	
	public function viewthread_onexin_autotag_output() {
		global $_G, $postlist;
		
		/*
		[tag]
		*/
		if(!$_G['cache']['plugin']['onexin_autotag']['isopen'] || !$_G['cache']['plugin']['onexin_autotag']['isforum']) return '';
		
		// day check
		if(TIMESTAMP - intval($_G['cache']['plugin']['onexin_autotag']['day'])*24*3600 < $_G['thread']['dateline']) {
	
			foreach($postlist as $pid => $value) {
				if($value['first'] && empty($value['tags'])) { //
						
					$pid = $value['pid'];
					$itemid = $value['tid'];
					$idtype = 'tid';// tid blogid articleid
					$_GET['subjectenc'] = $value['subject'];
					$plus = '';
					$count = $_G['cache']['plugin']['onexin_autotag']['num'] > 10 ? 10 : $_G['cache']['plugin']['onexin_autotag']['num'];
					for($i=1;$i<$count;$i++){
						$plus .= $_GET['subjectenc'];
					}
					$_GET['messageenc'] = $plus.$value['message'];
					if(!empty($_G['cache']['plugin']['onexin_autotag']['filter'])) {
						$_GET['messageenc'] = str_replace(explode('|', $_G['cache']['plugin']['onexin_autotag']['filter']), array(), $_GET['messageenc']);	
					}
					
					// tag
					self::load_tag_engine($_G['cache']['plugin']['onexin_autotag']['engine']);
					
					$tags = _onexin_autotag_relatekw();
					if(empty($tags)) $tags = $_G['cache']['plugin']['onexin_autotag']['name'];
					$tags = _onexin_autotag_forum($tags, $itemid, $idtype, 0, $_G['cache']['plugin']['onexin_autotag']['tagcount']);
					
					DB::query("UPDATE ".DB::table('forum_post')." SET tags = '".addslashes($tags)."' WHERE pid='$pid'");
									
				}
			}
		
		}
		
		return '';
		
	}
	
	public function viewthread_postbottom_mobile_output() {
		global $_G, $postlist;
		
		if(!$_G['cache']['plugin']['onexin_autotag']['isopen'] || !$_G['cache']['plugin']['onexin_autotag']['isforum']) return '';
				
		$result = array();
		foreach($postlist as $pid => $post) {
			if($post['first'] && $post['tags']) {
				$tagcode = '<div class="ptg" style="padding-left: 20px;background: url('.$_G['siteurl'].'static/image/common/tag.gif) no-repeat 0 5px;">';				
					$tagi = 0;
					foreach($post['tags'] as $var) {
						$tagcode .= ($tagi ? ", " : "")."<a title=\"$var[1]\" href=\"plugin.php?id=onexin_tags&".($_G['cache']['plugin']['onexin_tags']['ischinese'] ? "tagname=$var[1]" : "tagid=$var[0]")."\">$var[1]</a>";				
						$tagi++;
					}
				$tagcode .= '</div>';	
				$result[] = $tagcode;
			}
		}
				
		return $result;
	}
	
}

// portal
class mobileplugin_onexin_autotag_portal extends mobileplugin_onexin_autotag {
	
	public function view_article_content_output() {
		global $_G, $article, $content;
			
		if(!$_G['cache']['plugin']['onexin_autotag']['isopen'] || !$_G['cache']['plugin']['onexin_autotag']['isportal']) return '';
				
		$result = '';
					
			$post = DB::fetch_first("SELECT tagid,tags FROM ".DB::table('plugin_onexin_tags')." WHERE itemid='$article[aid]' AND idtype = 'articleid'");	
			//$tagid = $post['tagid'];	
		
			if($post['tags']) {
				$post['tags'] = explode("\t", trim($post['tags']));
				$tagcode = '<div class="ptg" style="padding-left: 20px;background: url('.$_G['siteurl'].'static/image/common/tag.gif) no-repeat 0 5px;">';				
					$tagi = 0;
					foreach($post['tags'] as $var) {
						$var = explode(',', $var);
						$tagcode .= ($tagi ? ", " : "")."<a title=\"$var[1]\" href=\"plugin.php?id=onexin_tags&".($_G['cache']['plugin']['onexin_tags']['ischinese'] ? "tagname=$var[1]" : "tagid=$var[0]")."\">$var[1]</a>";				
						$tagi++;
					}
				$tagcode .= '</div>';	
				$result = $tagcode;
			}
				
		return $result;
	}	
	
}
