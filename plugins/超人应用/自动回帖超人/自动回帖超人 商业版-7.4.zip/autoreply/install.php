<?php
/**
 *	[�Զ���������(autoreply.{modulename})] From: DisM.taobao.Com
 *	Version: $VERSION  ���²����http://t.cn/Aiux1Jx1
 *	Date: $DATE
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

if (file_exists(DISCUZ_ROOT.'./source/plugin/autoreply/include/functions.inc.php')) {
require_once DISCUZ_ROOT.'./source/plugin/autoreply/include/functions.inc.php';
} else {
require_once DISCUZ_ROOT.'./source/plugin/autoreply/include/function.inc.php';
}

$sql =<<<EOF
CREATE TABLE IF NOT EXISTS `cdb_plugin_autoreply_kv` (
  `key` VARCHAR(64) NOT NULL ,
  `value` TEXT NOT NULL DEFAULT '' ,
  `insert_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  PRIMARY KEY (`key`) )
ENGINE = MyISAM;
EOF;
runquery($sql);

$sql =<<<EOF
CREATE TABLE IF NOT EXISTS `cdb_plugin_autoreply_ref` (
  `tid` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT 0 ,
  `uid` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT 0 ,
  `insert_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  UNIQUE INDEX `tid_uid_UNIQUE` (`tid` ASC, `uid` ASC) )
ENGINE = MyISAM;
EOF;
runquery($sql);

$sql =<<<EOF
CREATE TABLE IF NOT EXISTS `cdb_plugin_autoreply_member` (
  `uid` MEDIUMINT(8) UNSIGNED NOT NULL DEFAULT 0 ,
  `username` VARCHAR(45) NOT NULL DEFAULT '' ,
  `status` TINYINT UNSIGNED NOT NULL DEFAULT 1 ,
  `insert_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  PRIMARY KEY (`uid`) ,
  UNIQUE INDEX `username_UNIQUE` (`username` ASC) )
ENGINE = MyISAM;
EOF;
runquery($sql);

$sql =<<<EOF
CREATE TABLE IF NOT EXISTS `cdb_plugin_autoreply_thread` (
  `tid` INT UNSIGNED NOT NULL ,
  `insert_time` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
  PRIMARY KEY (`tid`) )
ENGINE = MyISAM;
EOF;
runquery($sql);

$membernum = _autoreply_get_member_count();
if ($membernum <= 0) {
	_autoreply_import_member();
}
$finish = TRUE;
//////////////////////////////////////////////
function _autoreply_import_member()
{
	global $_G;
	$groupid = 10;
	$arr = _autoreply_generate_member();
	$newpassword = 'sc-autoreply';
	loaducenter();
	$profile = $verifyarr = array();
	loadcache('fields_register');
	$init_arr = explode(',', $_G['setting']['initcredits']);
	if (count($arr)) {
		foreach ($arr as $newusername) {
			$newusername = trim($newusername);
			if ($newusername == '') {
				continue;
			}
			if(C::t('common_member')->fetch_uid_by_username($newusername) || C::t('common_member_archive')->fetch_uid_by_username($newusername)) {
				continue;
			}
			
			$newemail = md5($newusername).'@163.com';
			$uid = uc_user_register(addslashes($newusername), $newpassword, $newemail);
			if($uid <= 0) {
				continue;
			}

			C::t('common_member')->insert($uid, $newusername, md5($newpassword), $newemail, _autoreply_get_random_ip(), $groupid, $init_arr);

			DB::insert('plugin_autoreply_member', array(
				'uid' => $uid,
				'username' => $newusername,
			));
		}
		updatecache('setting');
	}
}

function _autoreply_generate_member($num = 30)
{
	global $installlang;

	$ret = array();
	$username = explode("\n", $installlang['username']);
	if ($username) {
		$username = array_filter($username);
		shuffle($username);
		for ($i=0; $i<$num; $i++) {
			array_push($ret, $username[$i]);
		}
	}
	return $ret;
}

function _autoreply_get_member_count()
{
	return DB::result_first('SELECT COUNT(*) FROM %t', array('plugin_autoreply_member'));
}
