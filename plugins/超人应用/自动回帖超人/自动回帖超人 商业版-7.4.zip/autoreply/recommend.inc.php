<?php
/**
 *	[�Զ���������(autoreply.{modulename})] From: DisM.taobao.Com
 *	Version: $VERSION  ���²����http://t.cn/Aiux1Jx1
 *	Date: $DATE
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$url ='http://dism.taobao.com/?ac=developer&id=51152';
$content = dfsockopen($url, 0, $post, '', FALSE, '', 120);
if ($content) {
	$content = iconv('gbk', CHARSET, $content);
	$content = str_replace('resource/developer', 'http://dism.taobao.com/resource/developer', $content);
	$content = str_replace('resource/plugin', 'http://dism.taobao.com/resource/plugin', $content);
	$content = str_replace('image/scrolltop.png', 'http://dism.taobao.com/image/scrolltop.png', $content);
	$content = preg_replace('/<div class="a_wp mbm cl">.*<div class="a_wp cl">/s', '<div class="a_wp cl">', $content);
	$content = preg_replace('/<ul class="a_tb cl">.*<div id="appdiv">/s', '<div id="appdiv">', $content);
	$content = preg_replace('/<div class="mtm type">.*<div id="appdiv">/s', '<div id="appdiv">', $content);
	$content = preg_replace('/<div id="footer">.*<\/div>/s', '', $content);
	echo $content;
}
