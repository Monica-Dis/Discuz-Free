<?php
/**
 *	[�Զ���������(autoreply.{modulename})] From: DisM.taobao.Com
 *	Version: $VERSION  ���²����http://t.cn/Aiux1Jx1
 *	Date: $DATE
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_plugin_autoreply_kv extends discuz_table
{
	public function __construct()
	{
		$this->_table = 'plugin_autoreply_kv';
		$this->_pk = 'key';
		$this->_pre_cache_key = $this->_table.'_';	

		parent::__construct(); /*dism��taobao��com*/
	}

	public function fetch_by_key($key)
	{
		return DB::fetch_first('SELECT * FROM %t WHERE '.DB::field('key', $key).' '.DB::limit(0, 1), array($this->_table), $this->_pk);
	}
}
