<?php
/**
 *	[�Զ���������(autoreply.{modulename})] From: DisM.taobao.Com
 *	Version: $VERSION  ���²����http://t.cn/Aiux1Jx1
 *	Date: $DATE
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_plugin_autoreply_thread extends discuz_table
{
	public function __construct()
	{
		$this->_table = 'plugin_autoreply_thread';
		$this->_pk = 'tid';
		$this->_pre_cache_key = $this->_table.'_';	

		parent::__construct(); /*dism��taobao��com*/
	}
}
