<?php
/**
 *	[�Զ���������(autoreply.{modulename})] From: DisM.taobao.Com
 *	Version: $VERSION  ���²����http://t.cn/Aiux1Jx1
 *	Date: $DATE
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

class table_plugin_autoreply_member extends discuz_table
{
	public function __construct()
	{
		$this->_table = 'plugin_autoreply_member';
		$this->_pk = 'uid';
		$this->_pre_cache_key = $this->_table.'_';	

		parent::__construct(); /*dism��taobao��com*/
	}

	public function delete_by_uid($uid)
	{
		return $uid ? DB::delete($this->_table, DB::field('uid', $uid)) : false;
	}

	public function fetch_all_uid($no_admin = false)
	{
		$uids = array();
		if ($no_admin) {
			$query = DB::query("SELECT `uid` FROM ".DB::table($this->_table)." WHERE uid!=1 ORDER BY uid DESC");
		} else {
			$query = DB::query("SELECT `uid` FROM ".DB::table($this->_table)." ORDER BY uid DESC");
		}
		while($value = DB::fetch($query)) {
			$uids[] = intval($value['uid']);
		}
		return $uids;
	}
}
