<?php
/**
 *	[�Զ���������(autoreply.{modulename})] From: DisM.taobao.Com
 *	Version: $VERSION  ���²����http://t.cn/Aiux1Jx1
 *	Date: $DATE
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE `cdb_plugin_autoreply_kv`;
DROP TABLE `cdb_plugin_autoreply_member`;
DROP TABLE `cdb_plugin_autoreply_ref`;
DROP TABLE `cdb_plugin_autoreply_thread`;
EOF;
runquery($sql);

$finish = FALSE;
