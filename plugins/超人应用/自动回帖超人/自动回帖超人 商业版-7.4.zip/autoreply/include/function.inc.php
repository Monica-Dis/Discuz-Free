<?php
/**
 *	[自动回帖超人(autoreply.{modulename})] From: DisM.taobao.Com
 *	Version: $VERSION  最新插件：http://t.cn/Aiux1Jx1
 *	Date: $DATE
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

function _autoreply_get_random_ip()
{
    return 'Manual Acting';
}
