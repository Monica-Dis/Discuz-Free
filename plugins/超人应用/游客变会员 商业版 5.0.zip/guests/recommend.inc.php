<?php
/**
 *	[游客变会员(guests.{modulename})] Copyright 2001-2099 DisM!应用中心.
 *  Version: 5.0  dism-Taobao-com
 *  Date: 2015-09-06 14:06:26
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

if (!$_G['adminid']) {
	return false;
}
echo "<iframe src='http://t.cn/Aiux1Qh0' width='100%' height='1000' frameborder='0'></iframe>";
?>
