<?php
/**
 *	[游客变会员(guests.{modulename})] Copyright 2001-2099 DisM!应用中心.
 *  Version: 5.0  dism-Taobao-com
 *  Date: 2015-09-06 14:06:26
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

$sql = <<<EOF
DROP TABLE IF EXISTS `{tablepre}plugin_guests_info`;
CREATE TABLE IF NOT EXISTS `{tablepre}plugin_guests_info` (
  `name` varchar(32) NOT NULL DEFAULT '',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `welcome_path` varchar(256) DEFAULT 'source/plugin/guests/template/image/welcome.png'
) ENGINE=MyISAM;
REPLACE INTO `{tablepre}plugin_guests_info`(`name`) VALUES('guests');
EOF;
runquery($sql);

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `{tablepre}plugin_guests` (
  `ip` varchar(32) NOT NULL DEFAULT '0.0.0.0',
  `count` int(10) unsigned NOT NULL DEFAULT '1',
  `month_count` int(10) unsigned NOT NULL DEFAULT '1',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `uptime` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `reg_count` int(10) unsigned NOT NULL DEFAULT '0',
  `reg_time` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  UNIQUE KEY `ip` (`ip`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

$sql = <<<EOF
CREATE TABLE IF NOT EXISTS `{tablepre}plugin_guests_members` (
  `uid` int(10) unsigned NOT NULL DEFAULT '0',
  `ip` varchar(32) NOT NULL DEFAULT '0.0.0.0',
  `ctime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `referer` varchar(2048) NOT NULL DEFAULT '',
  UNIQUE KEY `uid` (`uid`)
) ENGINE=MyISAM;
EOF;
runquery($sql);

$finish = true;
?>
