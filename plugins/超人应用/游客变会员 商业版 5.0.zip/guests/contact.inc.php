<?php
/**
 *	[�οͱ��Ա(guests.{modulename})] Copyright 2001-2099 DisM!Ӧ������.
 *  Version: 5.0  dism-Taobao-com
 *  Date: 2015-09-06 14:06:26
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

include_once template('guests:contact');
