<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
defined('IN_DISCUZ') && defined('IN_ADMINCP') or exit('Access Denied');
$addonid = 'seourlrewrite.plugin';
$array = cloudaddons_getmd5($addonid);
if(empty($array) || cloudaddons_open('&mod=app&ac=validator&addonid='.$addonid.'&rid='.$array['RevisionID'].'&sn='.$array['SN'].'&rd='.$array['RevisionDateline']) === '0'){
}