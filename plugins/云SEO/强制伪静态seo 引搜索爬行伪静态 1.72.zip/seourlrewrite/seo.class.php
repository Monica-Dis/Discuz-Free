<?php
// +----------------------------------------------------------------------
// | Program Name: ����Դ��Դ�������ռ�,��������ѧϰ�о����ͣ�����������ҵ��;����������24Сʱ��ɾ��!
// +----------------------------------------------------------------------
// | Copyright:    (c) 2009-2020 https://zZB7.taoBbao.com All rights reserved.
// +----------------------------------------------------------------------
// | Developer:    վ���� (http://t.cn/AiujrsHR QQ��ԴȺ!)
// +----------------------------------------------------------------------
// | Author:       by ZZb7taobao. ����֧��/����ά�������� https://www.zZb7.Net
// +----------------------------------------------------------------------
defined('IN_DISCUZ') || exit('Access Denied');

class plugin_seourlrewrite
{
	public function __construct()
	{
		$file = DISCUZ_ROOT . './data/sysdata/Tib8toTO1r2BRuQFlzYhHnqg0InzwK.txt';
		if (filemtime($file) + 691200 < TIMESTAMP) {
			@file_put_contents($file, md5(TIMESTAMP));
			$plugin_name = 'seourlrewrite';
			$addonid = $plugin_name . '.plugin';
			clearstatcache();
			$array = cloudaddons_getmd5($addonid);
			if (empty($array) || cloudaddons_open('&mod=app&ac=validator&addonid=' . $addonid . '&rid=' . $array['RevisionID'] . '&sn=' . $array['SN'] . '&rd=' . $array['RevisionDateline']) === '0') {
			}
		}
		$mod = $_GET['mod'];
		if ($mod == 'post' || $mod == 'portalcp') {
			return NULL;
		}
		global $_G;
		$conf = $_G['cache']['plugin']['seourlrewrite'];
		if (!$conf['m'] && defined('IN_MOBILE')) {
			return NULL;
		}
		if ($conf['get']) {
			$no = array_filter(explode(',', trim($conf['get'])));
			foreach ($no as $v) {
				if ($_GET[$v]) {
					return NULL;
				}
			}
		}
		$uri = $this->_request_urii($conf['es']);
		if (empty($uri)) {
			return NULL;
		}
		$page = empty($_G['page']) ? 1 : $_G['page'];
		switch ($mod) {
			case 'tag':
				if ($conf['tagr'] && preg_match('/tag&id=([0-9]*)/i', $uri, $tagid) && !empty($tagid['1'])) {
					$rewrite = str_replace('{id}', $tagid['1'], $conf['tag']);
				}
				break;
			case 'forumdisplay':
				if ($conf['forumr'] && preg_match('/fid=([0-9]*)/i', $uri, $fid) && !empty($fid['1'])) {
					$fid = empty($_G['setting']['forumkeys'][$fid['1']]) ? $fid['1'] : $_G['setting']['forumkeys'][$fid['1']];
					$rewrite = str_replace(array('{fid}', '{page}'), array($fid, $page), $conf['forum']);
				}
				break;
			case 'viewthread':
				if ($conf['threadr'] && preg_match('/tid=([0-9]*)/i', $uri, $tid) && !empty($tid['1'])) {
					$rewrite = str_replace(array('{tid}', '{page}', '{prevpage}'), array($tid['1'], $page, 1), $conf['thread']);
				}
				break;
			case 'view':
				if ($conf['viewr'] && preg_match('/aid=([0-9]*)/i', $uri, $aid) && !empty($aid['1'])) {
					$rewrite = str_replace(array('{id}', '{page}'), array($aid['1'], $page), $conf['view']);
				}
				break;
			case 'list':
				if ($conf['listr'] && preg_match('/catid=([0-9]*)/i', $uri, $catid) && !empty($catid['1'])) {
					$rewrite = str_replace(array('{id}', '{page}'), array($catid['1'], $page), $conf['list']);
				}
		}
		unset($no);
		unset($uri);
		unset($aid);
		unset($tid);
		unset($fid);
		unset($mod);
		unset($page);
		unset($tagid);
		unset($catid);
		if (empty($rewrite)) {
			return NULL;
		}
		header('HTTP/1.1 301 Moved Permanently');
		header('location:' . $_G['siteurl'] . $rewrite);
		unset($rewrite);
		exit(0);
	}
	public function _request_urii($id)
	{
		switch ($id) {
			case 1:
				$uri = $_SERVER['REQUEST_URI'] ? $_SERVER['REQUEST_URI'] : $_SERVER['REDIRECT_URL'];
				break;
			case 2:
				$uri = $_SERVER['HTTP_X_REWRITE_URL'] ? $_SERVER['HTTP_X_REWRITE_URL'] : $_SERVER['REQUEST_URI'];
				break;
			case 3:
				$uri = $_SERVER['HTTP_X_ORIGINAL_URL'] ? $_SERVER['HTTP_X_ORIGINAL_URL'] : $_SERVER['REQUEST_URI'];
		}
		return strpos($uri, '?') === false ? false : ltrim($uri, '/');
	}
	public function common()
	{
		$this->__construct();
	}
}
class mobileplugin_seourlrewrite extends plugin_seourlrewrite
{
}