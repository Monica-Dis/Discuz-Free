<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-10-11,10:34:42
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
defined('IN_DISCUZ') && defined('IN_ADMINCP') or exit('Access Denied');
$file = DISCUZ_ROOT.'./source/plugin/seourlrewrite/fun.php';
if(is_file($file)) @unlink($file);
$finish = TRUE;
?>