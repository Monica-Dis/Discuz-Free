<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if ($reallanddirecton == '1'){
	exit;
}
if($_GET['do'] == 'pet'){
	$petall = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_pet')." ORDER BY jpid ASC");
	foreach($petall as $pet){
		$pet['jpdata'] = json_decode($pet['jpdata'],true);
		if(in_array($pet['jpid'],$userinfo['udata']['petdata']['activepet'])){//�߼����Ҫ��foreach��
			$pet['useractive'] = 1;
			//�����кͿɼ����ڸ߼������������
			if($pet['jpid'] == $userinfo['udata']['petdata']['nowpet']){
				$pet['nowpet'] = 1;
			}
		}
		$petlist[] = $pet;
	}
	$petlist = array_column($petlist,null,'jpid');
	
	if($_GET['deactive'] == 'true'){
		if($_GET['formhash'] == $_G['formhash']){
			$userinfo['udata']['petdata']['nowpet'] = 0;
			$userinfo['udata']['petdata']['petexpired'] = $_G['timestamp'];
			$userinfo['udata']['petdata']['petbs'] = 0;
			$json = json_encode($userinfo['udata']);
			C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],array('udata'=>$json,'lastsituation'=>$_G['timestamp']));
			
			$newlang = lang("plugin/$jn","s144");
			nlog($_G['uid'],8,$_G['timestamp'],$newlang);//�������
			
			$linkgen = lang("plugin/$jn","s144");
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updatefarmpet&timestamp='.$_G['timestamp'].'\',\'farmpet\');layer.msg(\''.$linkgen.'\');</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
	}
	if($_GET['active'] == 'true'){
		$petid = dintval($_GET['petid']);
		if(!in_array($petid,$userinfo['udata']['petdata']['activepet'])){
			showmessage('error');
		}
		if($_GET['formhash'] == $_G['formhash']){
			$userinfo['udata']['petdata']['nowpet'] = $petid;
			$udata = json_encode($userinfo['udata'],true);
			C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],array('udata'=>$udata,'lastsituation'=>$_G['timestamp']));
			
			$newlang = lang("plugin/$jn","s145");
			nlog($_G['uid'],8,$_G['timestamp'],$newlang);//�������
			
			$linkgen = lang("plugin/$jn","s145");
			$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updatefarmpet&timestamp='.$_G['timestamp'].'\',\'farmpet\');layer.msg(\''.$linkgen.'\');</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
	}
	//generate
	foreach($wslist as $ws){
		$wsarray[$x] = $ws['jsid'];
		$x++;
	}
	//����û��ı���
	$cprod = count($userinfo['udata']['prod']);
	for($cp=1;$cp<=$cprod;$cp++){
		if(in_array($userinfo['udata']['prod'][$cp][0],$wsarray)){
			$wslist[$userinfo['udata']['prod'][$cp][0]]['qtyleft'] = $userinfo['udata']['prod'][$cp][1];
		}
	}
	$cfert = count($userinfo['udata']['fertilize']);
	for($cf=1;$cf<=$cfert;$cf++){
		if(in_array($userinfo['udata']['fertilize'][$cf][0],$wsarray)){
			$wslist[$userinfo['udata']['fertilize'][$cf][0]]['qtyleft'] = $userinfo['udata']['fertilize'][$cf][1];
		}
	}
	$cnite = count($userinfo['udata']['nitem']);
	for($cn=1;$cn<=$cnite;$cn++){
		if(in_array($userinfo['udata']['nitem'][$cn][0],$wsarray)){
			$wslist[$userinfo['udata']['nitem'][$cn][0]]['qtyleft'] = $userinfo['udata']['nitem'][$cn][1];
		}
	}
	//��鵱ǰ�Ƿ��Ѿ�ӵ�д˳���
	foreach($petall as $pet){
		if(in_array($pet['jpid'],$userinfo['udata']['petdata']['activepet'])){//�߼����Ҫ��foreach��
			$pet['useractive'] = 1;
			//�����кͿɼ����ڸ߼������������
			if($petinfo['jpid'] == $userinfo['udata']['petdata']['nowpet']){
				$nowpet = 1;
			}
		}
	}
	
	if($userinfo['udata']['petdata']['nowpet'] > 0){
		$petexpired = date("Y-m-d H:i:s",$userinfo['udata']['petdata']['petexpired']);
	}
	if($_GET['buy'] == 'true' && $_GET['petid'] > 0){
		if($_GET['formhash'] == $_G['formhash']){
			$petid = dintval($_GET['petid']);
			$petinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_pet')." WHERE jpid = '$petid'");
			$petinfo['jpdata'] = json_decode($petinfo['jpdata'],true);
			if($userinfo['udata']['data']['money'] >= $petinfo['jpdata']['buyprice']){
				$beforedd = $userinfo['udata']['data']['money'];
				if($directextcreditson == '1'){
					$cdd['extcredits'.$jnc['buyext']] = '-'.$petinfo['jpdata']['buyprice'];
					updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s172"));
					$cdd = array();
				}else{
					$userinfo['udata']['data']['money'] = $userinfo['udata']['data']['money']-$petinfo['jpdata']['buyprice'];
				}
				$moneydd = $userinfo['udata']['data']['money']-$petinfo['jpdata']['buyprice'];
				$cpet = count($userinfo['udata']['petdata']['activepet']);
				for($x=0;$x<$cpet;$x++){
					$petarray[$x] = $userinfo['udata']['petdata']['activepet'][$x];
				}
				if(in_array($petid,$petarray)){
					lang("plugin/$jn","s146");
					$linkgen = '<script>layer.msg(\''.$linkgen.'\');'.$_G['timestamp'].'</script>';
					include template($jn.':'.$jn.'_normal_plain');
					exit;
				}
				$userinfo['udata']['petdata']['activepet'][$cpet] = $petid;
				$userinfo['udata']['petdata']['nowpet'] = $petid;
				if(!$userinfo['udata']['petdata']['petbs']){
					$userinfo['udata']['petdata']['petbs'] = 0;
				}
				
				$newlang = lang("plugin/$jn","s147").' ('.$plist[$petid]['jptitle'].') '.$jnc['mt'].$beforedd.'->'.$moneydd;
				nlog($_G['uid'],8,$_G['timestamp'],$newlang);//�������
				
				$userinfo['udata']['petdata']['petexpired'] = $_G['timestamp']+($petinfo['jpdata']['hungrytime']*86400);
				if($directextcreditson == '1'){
					$userinfo['udata']['data']['money'] = 0;
				}
				$userinfo['udata'] = json_encode($userinfo['udata'],true);
				C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
				
				$linkgen = lang("plugin/$jn","s147");
				$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updatefarmpet&timestamp='.$_G['timestamp'].'\',\'farmpet\');layer.msg(\''.$linkgen.'\');</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}
		}
	}
	if($_GET['feedid'] > 0 && $_GET['feedqty'] > 0){
		if($_GET['formhash'] == $_G['formhash']){
			$feedid = dintval($_GET['feedid']);
			$feedqty = fushu($_GET['feedqty']);
			//����û���quantity
			if($allist[$feedid]['type'] == 'seed'){//ũ����
				for($cp=1;$cp<=$cprod;$cp++){
					if($userinfo['udata']['prod'][$cp][0] == $feedid){
						if($userinfo['udata']['prod'][$cp][1] >= $feedqty){
							$qtyb4 = $userinfo['udata']['prod'][$cp][1];
							$userinfo['udata']['prod'][$cp][1] = $userinfo['udata']['prod'][$cp][1]-$feedqty;
							$qtyaf = $userinfo['udata']['prod'][$cp][1];
							$feedsuccess = 1;
							break;
						}
					}
				}
			}
			if($allist[$feedid]['type'] == 'fertilize'){//ũ����
				for($cf=1;$cf<=$cfert;$cf++){
					if($userinfo['udata']['fertilize'][$cf][0] == $feedid){
						if($userinfo['udata']['fertilize'][$cf][1] >= $feedqty){
							$qtyb4 = $userinfo['udata']['fertilize'][$cp][1];
							$userinfo['udata']['fertilize'][$cf][1] = $userinfo['udata']['fertilize'][$cf][1]-$feedqty;
							$qtyaf = $userinfo['udata']['fertilize'][$cp][1];
							$feedsuccess = 1;
							break;
						}
					}
				}
			}
			if($allist[$feedid]['type'] == 'nitem'){//��Ʒ
				for($cn=1;$cn<=$cnite;$cn++){
					if($userinfo['udata']['nitem'][$cn][0] == $feedid){
						if($userinfo['udata']['nitem'][$cn][1] >= $feedqty){
							$qtyb4 = $userinfo['udata']['nitem'][$cp][1];
							$userinfo['udata']['nitem'][$cn][1] = $userinfo['udata']['nitem'][$cn][1]-$feedqty;
							$qtyaf = $userinfo['udata']['nitem'][$cp][1];
							$feedsuccess = 1;
							break;
						}
					}
				}
			}
			if(!$feedsuccess){
				$linkgen = lang("plugin/$jn","s148");
			}else{
				$petinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_pet')." WHERE jpid = '".$userinfo['udata']['petdata']['nowpet']."'");
				$petinfo['jpdata'] = json_decode($petinfo['jpdata'],true);
				
				$petbsb4 = $userinfo['udata']['petdata']['petbs'];
				$bsadd = $wslist[$feedid]['sdata']['feedadd']*$feedqty;
				$userinfo['udata']['petdata']['petbs'] = $userinfo['udata']['petdata']['petbs']+($wslist[$feedid]['sdata']['feedadd']*$feedqty);
				
				if($userinfo['udata']['petdata']['petbs'] >= $petinfo['jpdata']['hungry']){
					//���������Ӷ���ʱ��
					$addhungrytime = floor($userinfo['udata']['petdata']['petbs']/$petinfo['jpdata']['hungry']);
					if($userinfo['udata']['petdata']['petexpired'] < $_G['timestamp']){//�ѹ���
						$userinfo['udata']['petdata']['petexpired'] = $_G['timestamp']+(86400*$petinfo['jpdata']['hungrytime']*$addhungrytime);
					}else{ //δ����
						$userinfo['udata']['petdata']['petexpired'] = $userinfo['udata']['petdata']['petexpired']+(86400*$petinfo['jpdata']['hungrytime']*$addhungrytime);
					};
					$userinfo['udata']['petdata']['petbs'] = $userinfo['udata']['petdata']['petbs']-($petinfo['jpdata']['hungry']*$addhungrytime);
				}
				$linkgen = lang("plugin/$jn","s149");
				
				$timeend = date("Y-m-d H:i:s",$userinfo['udata']['petdata']['petexpired']);
				
				$newlang = lang("plugin/$jn","s150",array('feedqty'=>$feedqty,'stitle'=>$allist[$feedid]['stitle'],'petbsb4'=>$petbsb4,'bsadd'=>$userinfo['udata']['petdata']['petbs'],'timeend'=>$timeend)).$qtyb4.'->'.$qtyaf;
				nlog($_G['uid'],8,$_G['timestamp'],$newlang);//�������
			}
			$userinfo['udata'] = json_encode($userinfo['udata'],true);
			C::t('#jnfarm#jnfarm_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata'],'lastsituation'=>$_G['timestamp']));
			$linkgen = '<script>layer.msg(\''.$linkgen.'\');ajaxget(\'plugin.php?id='.$jn.'&do=normal&ac=updatepetinfo&timestamp='.$_G['timestamp'].'\',\'mypetinfo\');</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}else{
			showmessage('error');
		}
		
	}
	include template($jn.':'.$jn.'_normal');
	exit;
}
//From: Dism��taobao��com
?>