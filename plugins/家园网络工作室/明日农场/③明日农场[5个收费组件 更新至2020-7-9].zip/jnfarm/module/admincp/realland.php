<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
global $_G;
$jn = 'jnfarm';
$jnc = $_G['cache']['plugin'][$jn];
$g_adminids = explode('|',$jnc['adminids']);//����ԱȨ��
if(!in_array($_G['uid'],$g_adminids)){
	showmessage("$jn:s002");
}
if($_GET['do'] == 'realland'){
	if($_GET['ac'] == 'challenge'){
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/challenge.php')){
			require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/admincp/challenge.php';
		}
	}
	$cpending = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_realland_record')." WHERE rstatus = 1");
	if($_GET['ac'] == 'topset'){
		$fset = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_fset')." WHERE jfset = '1'");
		$fset['setdata'] = json_decode($fset['setdata'],true);
		$fset['cword'] = stripslashes(htmlspecialchars_decode($fset['cword']));
		$fset['cword'] = explode('|',$fset['cword']);
		$fset['reallandword'] = stripslashes(htmlspecialchars_decode($fset['reallandword']));
		$fset['setdata']['rlwatertext'] = iconv('UTF-8',$_G['charset'],$fset['setdata']['rlwatertext']);
		$fset['setdata']['rlferttext'] = iconv('UTF-8',$_G['charset'],$fset['setdata']['rlferttext']);
		$fset['setdata']['rlwaternotice'] = iconv('UTF-8',$_G['charset'],$fset['setdata']['rlwaternotice']);
		$fset['setdata']['rlfertnotice'] = iconv('UTF-8',$_G['charset'],$fset['setdata']['rlfertnotice']);
		for($x=1;$x<=2;$x++){
			$fset['setdata']['xbtnname'.$x] = iconv('UTF-8',$_G['charset'],$fset['setdata']['xbtnname'.$x]);
		}
		if(submitcheck('editsubmit')){
			$fset['cword'][0] = dhtmlspecialchars(daddslashes($_GET['cword1'])); 
			$fset['cword'][1] = dhtmlspecialchars(daddslashes($_GET['cword2']));
			$fset['cword'] = implode('|',$fset['cword']);
			$fset['reallandword'] = dhtmlspecialchars(daddslashes($_GET['reallandword'])); 
			
			$fset['setdata']['rlwaterext'] = dintval($_GET['rlwaterext']);
			$fset['setdata']['rlwaterrate'] = dintval($_GET['rlwaterrate']);
			$fset['setdata']['rlwateruse'] = dintval($_GET['rlwateruse']);
			$fset['setdata']['rlwaternotice'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['rlwaternotice']));
			$fset['setdata']['rlfertext'] = dintval($_GET['rlfertext']);
			$fset['setdata']['rlfertrate'] = dintval($_GET['rlfertrate']);
			$fset['setdata']['rlfertuse'] = dintval($_GET['rlfertuse']);
			$fset['setdata']['rlfertnotice'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['rlfertnotice']));
			
			for($x=1;$x<=2;$x++){
				$fset['setdata']['qiyong'.$x] = dintval($_GET['qiyong'.$x]);
				$fset['setdata']['xbtntype'.$x] = dintval($_GET['xbtntype'.$x]);
				$fset['setdata']['xbtnname'.$x] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['xbtnname'.$x]));
				$fset['setdata']['xbtnimg'.$x] = daddslashes($_GET['xbtnimg'.$x]);
				$fset['setdata']['xbtnurl'.$x] = daddslashes($_GET['xbtnurl'.$x]);
				$fset['setdata']['xbtncol'.$x] = daddslashes($_GET['xbtncol'.$x]);
			}
			$fset['setdata'] = json_encode($fset['setdata']);
			//showmessage($fset['setdata']);
			C::t('#'.$jn.'#'.$jn.'_fset')->update(1,array('setdata'=>$fset['setdata'],'cword'=>$fset['cword'],'reallandword'=>$fset['reallandword']));
			//DB::query("UPDATE ".DB::table('game_jnfarm_fset')." SET setdata = '".$fset['setdata']."' WHERE jfset = '1'");
			showmessage("$jn:o006","plugin.php?id=$jn:admincp$jn&do=realland&ac=topset");
		}
	}
	if($_GET['ac'] == 'exchange'){
		$jrrid = dintval($_GET['jrrid']);
		if($_GET['delete'] == 'true'){
			if($_GET['formhash'] == $_G['formhash']){
				DB::query("DELETE FROM ".DB::table('game_jnfarm_realland_record')." WHERE jrrid = '$jrrid'");
				showmessage("$jn:o008","plugin.php?id=$jn:admincp$jn&do=realland&ac=exchange",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
			}
		}
		if(submitcheck('editsubmit')){
			$jrrinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland_record')." WHERE jrrid = '$jrrid'");
			$jrrinfo['rinfo'] = json_decode($jrrinfo['rinfo'],true);
			
			if($_GET['receiveradd']){
				$receivedadd = iconv($_G['charset'],'UTF-8',addslashes($_GET['receiveradd']));
				$jrrinfo['rinfo']['receiver'] = $jrrinfo['rinfo']['receiver'].'|'.$receivedadd;
			}
			
			//$jupdate = json_encode($jrrinfo['rinfo']);
			if($_GET['addressadd']){
				$addressadd = iconv($_G['charset'],'UTF-8',addslashes($_GET['addressadd']));
				$jrrinfo['rinfo']['address'] = $jrrinfo['rinfo']['address'].'|'.$addressadd;
			}
			
			if($_GET['telephoneadd']){
				$telephoneadd = addslashes($_GET['telephoneadd']);
				$jrrinfo['rinfo']['telephone'] = $jrrinfo['rinfo']['telephone'].'|'.$telephoneadd;
			}
			
			if($_GET['courieradd']){
				$courieradd = iconv($_G['charset'],'UTF-8',addslashes($_GET['courieradd']));
				if(!$jrrinfo['rinfo']['courier']){
					$jrrinfo['rinfo']['courier'] = $courieradd;
				}else{
					$jrrinfo['rinfo']['courier'] = $jrrinfo['rinfo']['courier'].'|'.$courieradd;
				}
			}
			$rstatus = dintval($_GET['status']);
			$jupdate = json_encode($jrrinfo['rinfo']);

			C::t('#'.$jn.'#'.$jn.'_realland_record')->update($jrrid,array('rinfo'=>$jupdate,'rstatus'=>$rstatus));
			showmessage($jupdate,'plugin.php?id=jnfarm:admincpjnfarm&do=realland&ac=exchange');
		}
		if($jrrid > 0){
			$jrrinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland_record')." WHERE jrrid = '$jrrid'");
			$jrrinfo['rinfo'] = json_decode($jrrinfo['rinfo'],true);
			$jrrinfo['rinfo']['address'] = iconv('UTF-8',$_G['charset'],$jrrinfo['rinfo']['address']);
			$jrrinfo['rinfo']['receiver'] = iconv('UTF-8',$_G['charset'],$jrrinfo['rinfo']['receiver']);
			$jrrinfo['rinfo']['courier'] = iconv('UTF-8',$_G['charset'],$jrrinfo['rinfo']['courier']);
			$jrinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland')." WHERE jrid = '".$jrrinfo['rinfo']['jrid']."'");
			$jrinfo['jrdata'] = json_decode($jrinfo['jrdata'],true);
			$jrinfo['jrdata']['qty'] = iconv('UTF-8',$_G['charset'],$jrinfo['jrdata']['qty']);
		}else{
			$page = $_G['page'];
			$tpp = 100;
			$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_realland_record'));
			if(@ceil($total/$tpp) < $page) 	$page = 1;
			$start_limit = ($page - 1) * $tpp;
			
			$jrr = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_realland_record')." ORDER BY jrrid DESC limit {$start_limit},{$tpp} ");
			foreach($jrr as $jr){
				$jr['rinfo'] = json_decode($jr['rinfo'],true);
				$jr['rinfo']['address'] = iconv('UTF-8',$_G['charset'],$jr['rinfo']['address']);
				$jr['rinfo']['receiver'] = iconv('UTF-8',$_G['charset'],$jr['rinfo']['receiver']);
				$jrrlist[] = $jr;
			}
			$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=realland&ac=exchange", $_G['setting']['threadmaxpages']);
		}
	}
	if($_GET['ac'] == 'treeset'){
		$real = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_realland')." ORDER BY jrid");
		foreach($real as $re){
			$re['jrdata'] = json_decode($re['jrdata'],true);
			$relist[] = $re;
		}
		$jrid = dintval($_GET['jrid']);
		if($jrid > 0){
			$jrinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland')." WHERE jrid = '$jrid'");
			$jrinfo['jrdata'] = json_decode($jrinfo['jrdata'],true);
			$jrinfo['jrdata']['qty'] = iconv('UTF-8',$_G['charset'],$jrinfo['jrdata']['qty']);
			$jrinfo['jrdata']['jword1'] = iconv('UTF-8',$_G['charset'],$jrinfo['jrdata']['jword1']);
			$jrinfo['jrdata']['jword2'] = iconv('UTF-8',$_G['charset'],$jrinfo['jrdata']['jword2']);
			$jrinfo['jrdata']['jword3'] = iconv('UTF-8',$_G['charset'],$jrinfo['jrdata']['jword3']);
			$jrinfo['jrdata']['jword4'] = iconv('UTF-8',$_G['charset'],$jrinfo['jrdata']['jword4']);
			$jrinfo['jrdata']['jdesc'] = iconv('UTF-8',$_G['charset'],$jrinfo['jrdata']['jdesc']);
		}
		if(submitcheck('newsubmit')){
			$data['jrtitle'] = daddslashes($_GET['jrtitle']);
			$jr['jrdata']['small'] = daddslashes($_GET['small']);
			$jr['jrdata']['jimg1'] = daddslashes($_GET['jimg1']);
			$jr['jrdata']['jimg2'] = daddslashes($_GET['jimg2']);
			$jr['jrdata']['jimg3'] = daddslashes($_GET['jimg3']);
			$jr['jrdata']['jimg4'] = daddslashes($_GET['jimg4']);
			$jr['jrdata']['jword1'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jword1']));
			$jr['jrdata']['jword2'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jword2']));
			$jr['jrdata']['jword3'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jword3']));
			$jr['jrdata']['jword4'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jword4']));
			for($x=1;$x<=4;$x++){
				$jr['jrdata']['jrsd'.$x] = dintval($_GET['jrsd'.$x]);
				$jr['jrdata']['jrfl'.$x] = dintval($_GET['jrfl'.$x]);
			}
			$jr['jrdata']['jdesc'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jdesc']));
			$data['canplant'] = dintval($_GET['canplant']);
			$jr['jrdata']['qty'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['qty']));
			if(!$data['jrtitle'] || !$jr['jrdata']['small'] || !$jr['jrdata']['jimg1'] || !$jr['jrdata']['jimg2'] || !$jr['jrdata']['jimg3'] || !$jr['jrdata']['jimg4'] || !$jr['jrdata']['jrsd1'] || !$jr['jrdata']['jrsd2'] || !$jr['jrdata']['jrsd3'] || !$jr['jrdata']['jrsd4'] || !$jr['jrdata']['qty'] || !$jr['jrdata']['jrsd2'] || !$jr['jrdata']['jrsd3'] || !$jr['jrdata']['jrsd4'] || !$jr['jrdata']['qty']){
				showmessage("$jn:o007");
			}
			$data['jrdata'] = json_encode($jr['jrdata']);
			C::t('#'.$jn.'#'.$jn.'_realland')->insert($data);
			showmessage("$jn:o004","plugin.php?id=$jn:admincp$jn&do=realland&ac=treeset");
		}
		if(submitcheck('editsubmit')){
			$jrid = dintval($_GET['jrid']);
			$jrinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland')." WHERE jrid = '$jrid'");
			$data['jrtitle'] = daddslashes($_GET['jrtitle']);
			$jr['jrdata']['small'] = daddslashes($_GET['small']);
			$jr['jrdata']['jimg1'] = daddslashes($_GET['jimg1']);
			$jr['jrdata']['jimg2'] = daddslashes($_GET['jimg2']);
			$jr['jrdata']['jimg3'] = daddslashes($_GET['jimg3']);
			$jr['jrdata']['jimg4'] = daddslashes($_GET['jimg4']);
			$jr['jrdata']['jword1'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jword1']));
			$jr['jrdata']['jword2'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jword2']));
			$jr['jrdata']['jword3'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jword3']));
			$jr['jrdata']['jword4'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jword4']));
			for($x=1;$x<=4;$x++){
				$jr['jrdata']['jrsd'.$x] = dintval($_GET['jrsd'.$x]);
				$jr['jrdata']['jrfl'.$x] = dintval($_GET['jrfl'.$x]);
			}
			$data['canplant'] = dintval($_GET['canplant']);
			$jr['jrdata']['jdesc'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['jdesc']));
			$jr['jrdata']['qty'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['qty']));
			if(!$data['jrtitle'] || !$jr['jrdata']['small'] || !$jr['jrdata']['jimg1'] || !$jr['jrdata']['jimg2'] || !$jr['jrdata']['jimg3'] || !$jr['jrdata']['jimg4'] || !$jr['jrdata']['jrsd1'] || !$jr['jrdata']['jrsd2'] || !$jr['jrdata']['jrsd3'] || !$jr['jrdata']['jrsd4'] || !$jr['jrdata']['qty'] || !$jrinfo['jrid']){
				showmessage("$jn:o007");
			}
			$data['jrdata'] = json_encode($jr['jrdata']);
			C::t('#'.$jn.'#'.$jn.'_realland')->update($jrinfo['jrid'],array('jrtitle'=>$data['jrtitle'],'jrdata'=>$data['jrdata'],'canplant'=>$data['canplant']));
			showmessage("$jn:o006","plugin.php?id=$jn:admincp$jn&do=realland&ac=treeset");
		}
	}
	include template($jn.':admincp'.$jn);
	exit;
}
//From: Dism��taobao��com
?>