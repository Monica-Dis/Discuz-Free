<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
$jn = 'jnfarm';
$jnc = $_G['cache']['plugin'][$jn];
$g_adminids = explode('|',$jnc['adminids']);//����ԱȨ��
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
//require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/func.php';
if(!in_array($_G['uid'],$g_adminids)){
	showmessage("$jn:s002");
}
$page = $_G['page'];
$tpp = 100;
$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_cashout')."");
if(@ceil($total/$tpp) < $page) 	$page = 1;
$start_limit = ($page - 1) * $tpp;

if($_GET['do'] == 'pet'){
	$petall = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_pet')." ORDER BY jpid DESC ");
	foreach($petall as $pet){
		$pet['jpdata'] = json_decode($pet['jpdata'],true);
		$petlist[] = $pet;
	}
	$petid = dintval($_GET['petid']);
	if($petid > 0){
		$petinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_pet')." WHERE jpid = '$petid'");
		$petinfo['jpdata'] = json_decode($petinfo['jpdata'],true);
	}

	if(submitcheck('editsubmit')){
		$jpid = dintval($_GET['jpid']);
		if($jpid > 0){
			$jptitle = daddslashes($_GET['jptitle']);
			$jp['jpdata']['pimg'] = daddslashes($_GET['pimg']);
			$jp['jpdata']['attack'] = dintval($_GET['attack']);
			$jp['jpdata']['hungry'] = dintval($_GET['hungry']);
			$jp['jpdata']['hungrytime'] = dintval($_GET['hungrytime']);
			$jp['jpdata']['buyprice'] = dintval($_GET['buyprice']);
			$jp['jpdata']['lostcoin'] = dintval($_GET['lostcoin']);
			$jp['jpdata']['buytype'] = 1;
			$jpdata = json_encode($jp['jpdata'],true);
			C::t("#jnfarm#jnfarm_pet")->update($jpid,array('jptitle'=>$jptitle,'jpdata'=>$jpdata));
			showmessage("$jn:o006",'plugin.php?id='.$jn.':admincp'.$jn.'&do=pet');
		}
	}
	if(submitcheck('newsubmit')){
		$data = array();
		$data['title'] = daddslashes($_GET['jptitle']);
		$jpdata['jpdata']['pimg'] = daddslashes($_GET['pimg']);
		$jpdata['jpdata']['attack'] = dintval($_GET['attack']);
		$jpdata['jpdata']['hungry'] = dintval($_GET['hungry']);
		$jpdata['jpdata']['hungrytime'] = dintval($_GET['hungrytime']);
		$jpdata['jpdata']['buyprice'] = dintval($_GET['buyprice']);
		$jpdata['jpdata']['lostcoin'] = dintval($_GET['lostcoin']);
		$jpdata['jpdata']['buytype'] = 1;
		if(!$data['title'] || $jpdata['jpdata']['pimg'] || $jpdata['jpdata']['attack'] || $jpdata['jpdata']['hungry'] || $jpdata['jpdata']['hungrytime'] || $jpdata['jpdata']['buyprice'] || $jpdata['jpdata']['lostcoin']){
			showmessage("$jn:o001");
		}
		$data['jpdata'] = json_encode($jpdata['jpdata'],true);
		C::t("#jnfarm#jnfarm_pet")->insert($data);
		showmessage("$jn:o004",'plugin.php?id='.$jn.':admincp'.$jn.'&do=pet');
	}
	if($_GET['delete'] == 'true'){
		if($_GET['formhash'] == $_G['formhash']){
			$petid = dintval($_GET['petid']);
			$alluser = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_user')."");
			foreach($alluser as $all){
				$all['udata'] = json_decode($all['udata'],true);
				if($all['udata']['petdata']['nowpet'] == $petid){
					$all['udata']['petdata']['nowpet'] = 0;
					$json = json_encode($all['udata']);
					C::t('#jnfarm#jnfarm_user')->update($all['juid'],array('udata'=>$json));
				}
			}
			DB::query("DELETE FROM ".DB::table('game_jnfarm_pet')." WHERE jpid = '$petid'");
			showmessage("$jn:s008","plugin.php?id=jnfarm:admincp&do=pet");
		}
	}
}
//From: Dism��taobao��com
?>