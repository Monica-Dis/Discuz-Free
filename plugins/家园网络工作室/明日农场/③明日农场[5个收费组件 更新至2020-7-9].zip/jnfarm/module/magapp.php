<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if(!$jnc['mgappsec']){
	showmessage("$jn:s153");
}
$jn = 'jnfarm';
if(!$jnc['mgappurl']){
	$jnc['mgappurl'] = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
}
$jnc['oriurl'] = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
function MagPushfarm($uid){
	global $jnc; global $jn; global $_G;
	$newjson['tag'] = iconv($_G['charset'],'UTF-8',$jnc['title']);
	$newjson['title'] = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s154"));
	$newjson['extra_info']['key'] = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s155"));
	$newjson['extra_info']['val'] = iconv($_G['charset'],'UTF-8',lang("plugin/$jn","s156"));

	//$newjson['cover_url'] = 'http://lxh.magcloud.cc/source/plugin/jnfarm/template/images/360px.png';
	$newjson['pic_url'] = $jnc['oriurl'].'source/plugin/jnfarm/template/images/360px.png';
	$newjson['link'] = $jnc['oriurl'].'/plugin.php?id=jnfarm';
	
	//$newjson['des'] = 'pictemp';
	//$newjson['des_themecolor'] = 'red'; //���ܴ�#, �������ϢΪ�յ���ʾ
	$type = 'pictemp';
	$operjson = json_encode($newjson);
	$link = $jnc['mgappurl'].'/mag/operative/v1/assistant/sendAssistantMsg?user_id='.$uid.'&content='.$operjson.'&secret='.$jnc['mgappsec'].'&is_push=1&type='.$type;

	$handle = curl_init();
	curl_setopt($handle, CURLOPT_URL, $link);
	curl_exec($handle);
	//$output = curl_exec($handle);
	curl_close($handle);
}
function MagPushthief($uid,$thiefusername,$type,$lostcoin,$jncmt){
	global $jnc; global $jn; global $_G;
	$uid = dintval($uid);
	$thiefusername = daddslashes($thiefusername);
	$lostcoin = dintval($lostcoin);
	$jncmt = daddslashes($jncmt);
	if($type == '1'){
		$wording = lang("plugin/$jn","s157",array('thiefusername'=>$thiefusername)).'...';
	}
	if($type == '2'){
		$wording = lang("plugin/$jn","s158",array('thiefusername'=>$thiefusername)).$lostcoin.$jncmt;
	}
	$newjson['tag'] = $jnc['title'];
	$newjson['title'] = $wording;
	$newjson['extra_info']['key'] = lang("plugin/$jn","s155");
	$newjson['extra_info']['val'] = lang("plugin/$jn","s159").'..';

	//$newjson['cover_url'] = 'http://lxh.magcloud.cc/data/attachment/album/202005/07/175611o77fjleuibbf7ju7.png';
	$newjson['pic_url'] = $jnc['oriurl'].'source/plugin/jnfarm/template/images/360px.png';
	$newjson['link'] = $jnc['oriurl'].'/plugin.php?id=jnfarm';
	
	//$newjson['des'] = 'pictemp';
	//$newjson['des_themecolor'] = 'red'; //���ܴ�#, �������ϢΪ�յ���ʾ
	$type = 'pictemp';
	$operjson = json_encode($newjson);
	$link = $jnc['mgappurl'].'/mag/operative/v1/assistant/sendAssistantMsg?user_id='.$uid.'&content='.$operjson.'&secret='.$jnc['mgappsec'].'&is_push=1&type='.$type;

	$handle = curl_init();
	curl_setopt($handle, CURLOPT_URL, $link);
	curl_exec($handle);
	//$output = curl_exec($handle);
	curl_close($handle);
}
//From: Dism��taobao��com
?>