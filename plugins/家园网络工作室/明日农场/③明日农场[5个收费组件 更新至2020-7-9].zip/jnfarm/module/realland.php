<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
$pass = substr(md5(uniqid(mt_rand(), true)) , 0, 8);
$sysinfo['cword'] = htmlspecialchars_decode($sysinfo['cword']);
$sysinfo['cword'] = explode('|',$sysinfo['cword']);
if($_GET['do'] == 'realland'){
	if($_GET['ac'] == 'challenge'){
		if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/challenge.php')){
			require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/challenge.php';
		}
	}
	if($_GET['ac'] == 'delivery'){
		$dinfo = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_realland_record')." WHERE uid = '".$_G['uid']."' ORDER BY jrrid DESC");
		$rinfo = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_realland')."");
		foreach($rinfo as $ri){
			$ri['jrdata'] = json_decode($ri['jrdata'],true);
			$ri['jrdata']['qty'] = iconv('UTF-8',$_G['charset'],$ri['jrdata']['qty']);
			$rilist[] = $ri;
		}
		$rilist = array_column($rilist,null,'jrid');
		foreach($dinfo as $di){
			$di['rinfo'] = json_decode($di['rinfo'],true);
			$di['rinfo']['receiver'] = iconv('UTF-8',$_G['charset'],$di['rinfo']['receiver']);
			$di['rinfo']['address'] = iconv('UTF-8',$_G['charset'],$di['rinfo']['address']);
			$di['rinfo']['telehone'] = iconv('UTF-8',$_G['charset'],$di['rinfo']['telehone']);
			$di['rinfo']['courier'] = iconv('UTF-8',$_G['charset'],$di['rinfo']['courier']);
			$dilist[] = $di;
		}
	}
	if($_GET['ac'] == 'realplant'){
		$real = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_realland')." WHERE canplant = 1 ORDER BY jrid ASC ");
		foreach($real as $re){
			$re['jrdata'] = json_decode($re['jrdata'],true);
			$re['jrdata']['qty'] = iconv('UTF-8',$_G['charset'],$re['jrdata']['qty']);
			$re['jrdata']['jdesc'] = iconv('UTF-8',$_G['charset'],$re['jrdata']['jdesc']);
			$relist[] = $re;
		}
	}
	if(!$sysinfo['setdata']['rlfertuse'] || $sysinfo['setdata']['rlfertuse'] <= 0){
		$sysinfo['setdata']['rlfertuse'] = 1;
	}
	if(!$sysinfo['setdata']['rlwateruse'] || $sysinfo['setdata']['rlwateruse'] <= 0){
		$sysinfo['setdata']['rlwateruse'] = 1;
	}
	if($_GET['ac'] == 'fertilize'){
		if($_GET['formhash'] == $_G['formhash']){
			$userinfo['realland'] = json_decode($userinfo['realland'],true);
			$treeinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland')." WHERE jrid = '".$userinfo['realland']['jrid']."'");
			if($treeinfo['jrid'] > 0){
				$treeinfo['jrdata'] = json_decode($treeinfo['jrdata'],true);
				if($userinfo['realland']['nowsd'] >= 0 && $userinfo['realland']['nowlvl'] <= 4){
					//�����ǰ��ˮ��û��
					if($userinfo['realland']['nowsd'] >= $treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]){//����
						$jifen = getuserprofile('extcredits'.$sysinfo['setdata']['rlfertext']);
						if($jifen >= $sysinfo['setdata']['rlfertuse']){
							//$paymount = 1;
							$cdd['extcredits'.$sysinfo['setdata']['rlfertext']] = '-'.$sysinfo['setdata']['rlwateruse'];
							updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s181"));
							$userinfo['realland']['nowfl'] = $userinfo['realland']['nowfl']+$sysinfo['setdata']['rlfertrate'];
							if($userinfo['realland']['nowfl'] >= $treeinfo['jrdata']['jrfl'.$userinfo['realland']['nowlvl']]){//��������
								$userinfo['realland']['nowlvl'] = $userinfo['realland']['nowlvl']+1;
								$userinfo['realland']['nowsd'] = 0;
								$userinfo['realland']['nowfl'] = 0;
								$linkgen = lang("plugin/$jn","s182");//'��ϲ������������';
							}else{
								$linkgen = lang("plugin/$jn","s183");//'ʩ�ʳɹ���';
							}

							$linkgen = '<script>layer.msg(\''.$linkgen.'\');ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=realplantinfo&timestamp='.$_G['timestamp'].$pass.'\',\'realplantinfo\');'.$_G['timestamp'].'</script>';
							$userinfo['realland'] = json_encode($userinfo['realland']);
							C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('realland'=>$userinfo['realland'],'lastsituation'=>$_G['timestamp']));
							
						}else{
							if($sysinfo['cword'][1]){
								$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=loadnotice&timestamp='.$_G['timestamp'].$pass.'\');'.$_G['timestamp'].'</script>';
								include template($jn.':'.$jn.'_normal_plain');
								exit;
							}else{
								$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=loaddaily&timestamp='.$_G['timestamp'].$pass.'\');'.$_G['timestamp'].'</script>';
								include template($jn.':'.$jn.'_normal_plain');
								exit;
							}
							/*$linkgen = lang("plugin/$jn","s184");
							if($sysinfo['setdata']['rlfertnotice']){
								$linkgen = $sysinfo['setdata']['rlfertnotice'];//lang("plugin/$jn","s184");//'���ϲ���';
							}
							$linkgen = '<script>layer.msg(\''.$linkgen.'\');ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=realplantinfo&timestamp='.$_G['timestamp'].$pass.'\',\'realplantinfo\');'.$_G['timestamp'].'</script>';*/
						}
					}else{
						
						$linkgen = lang("plugin/$jn","s185");//'ˮ�ݲ���';
						$linkgen = '<script>layer.msg(\''.$linkgen.'\');ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=realplantinfo&timestamp='.$_G['timestamp'].$pass.'\',\'realplantinfo\');'.$_G['timestamp'].'</script>';
					}
					include template($jn.':'.$jn.'_normal_plain');
					exit;
				}
			}else{
				//$linkgen = lang("plugin/$jn","s185");//'ˮ�ݲ���';
				$linkgen = '<script>showTips('.$_G['timestamp'].');</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}
		}
	}
	if($_GET['ac'] == 'watering'){
		if($_GET['formhash'] == $_G['formhash']){
			$userinfo['realland'] = json_decode($userinfo['realland'],true);
			$treeinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland')." WHERE jrid = '".$userinfo['realland']['jrid']."'");
			if($treeinfo['jrid'] > 0){
				$treeinfo['jrdata'] = json_decode($treeinfo['jrdata'],true);
				if($userinfo['realland']['nowsd'] >= 0 && $userinfo['realland']['nowlvl'] <= 4){
					//�����ǰ��ˮ��û��
					if($userinfo['realland']['nowsd'] >= $treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]){//����
						$linkgen = lang("plugin/$jn","s186");//'ˮ�����㹻, ��ʩ����������';
						$linkgen = '<script>layer.msg(\''.$linkgen.'\');ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=realplantinfo&timestamp='.$_G['timestamp'].$pass.'\',\'realplantinfo\');'.$_G['timestamp'].'</script>';
						$userinfo['realland'] = json_encode($userinfo['realland']);
						C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('realland'=>$userinfo['realland'],'lastsituation'=>$_G['timestamp']));
						include template($jn.':'.$jn.'_normal_plain');
						exit;
					}else{
						$jifen = getuserprofile('extcredits'.$sysinfo['setdata']['rlwaterext']);
						if($jifen >= $sysinfo['setdata']['rlwateruse']){
							if($challengeon == '1'){
								$userinfo['dayquest'] = json_decode($userinfo['dayquest'],true);
								$userinfo['dayquest']['realland']['todaychallengewater'] = $userinfo['dayquest']['realland']['todaychallengewater']+1;
								$userinfo['dayquest'] = json_encode($userinfo['dayquest']);
								C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('dayquest'=>$userinfo['dayquest']));
							}
							//$paymount = 1;
							$cdd['extcredits'.$sysinfo['setdata']['rlwaterext']] = '-'.$sysinfo['setdata']['rlwateruse'];
							updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s187"));
							$userinfo['realland']['nowsd'] = $userinfo['realland']['nowsd']+$sysinfo['setdata']['rlwaterrate'];
							$linkgen = lang("plugin/$jn","s188");//'��ˮ�ɹ���';
							if($userinfo['realland']['nowsd'] >= $treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']] && $treeinfo['jrdata']['jrfl'.$userinfo['realland']['nowlvl']] <= '0'){//����������
								$userinfo['realland']['nowlvl'] = $userinfo['realland']['nowlvl']+1;
								$userinfo['realland']['nowsd'] = 0;

								$linkgen = lang("plugin/$jn","s182");
							}
							$linkgen = '<script>layer.msg(\''.$linkgen.'\');ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=realplantinfo&timestamp='.$_G['timestamp'].$pass.'\',\'realplantinfo\');'.$_G['timestamp'].'</script>';
							$userinfo['realland'] = json_encode($userinfo['realland']);
							C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('realland'=>$userinfo['realland'],'lastsituation'=>$_G['timestamp']));
							include template($jn.':'.$jn.'_normal_plain');
							exit;
						}else{
							$linkgen = lang("plugin/$jn","s199");
							if($sysinfo['setdata']['rlwaternotice']){
								$linkgen = $sysinfo['setdata']['rlwaternotice'];//lang("plugin/$jn","s184");//'���ϲ���';
							}
							if($sysinfo['cword'][0]){
								$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=loadnotice&timestamp='.$_G['timestamp'].$pass.'\');'.$_G['timestamp'].'</script>';
								include template($jn.':'.$jn.'_normal_plain');
								exit;
							}else{
								$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=loaddaily&timestamp='.$_G['timestamp'].$pass.'\');'.$_G['timestamp'].'</script>';
								include template($jn.':'.$jn.'_normal_plain');
								exit;
							}
						}
					}
				}
			}else{
				$linkgen = '<script>showTips('.$linkgen.');'.$_G['timestamp'].'</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}
		}
	}
	if($_GET['ac'] == 'plant'){
		if($_GET['formhash'] == $_G['formhash']){
			$jrid = dintval($_GET['jrid']);
			$jinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland')." WHERE jrid = '$jrid' AND canplant = '1'");
			if(!$jinfo['jrid']){
				$linkgen = lang("plugin/$jn","s189");//'����״̬����, ��ѡ������';
				$linkgen = '<script>layer.msg(\''.$linkgen.'\');</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}else{
				if($userinfo['juid'] > 0){
					$userinfo['realland'] = json_decode($userinfo['realland'],true);
					if($userinfo['realland']['jrid'] > 0){
						$linkgen = lang("plugin/$jn","s190");//'�Ѵ���';
					}
					$userinfo['realland']['jrid'] = $jrid;
					$userinfo['realland']['nowlvl'] = 1;
					$userinfo['realland']['nowsd'] = 0;
					$userinfo['realland']['md5'] = md5($_G['timestamp'].$pass.$_G['uid'].$jrid);
					$userinfo['realland'] = json_encode($userinfo['realland']);
					C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('realland'=>$userinfo['realland'],'lastsituation'=>$_G['timestamp']));
				}else{
					$data = array();
					$data['uid'] = $_G['uid'];
					$data['createtime'] = $_G['timestamp'];
					$data['udata'] = '{"data":{"money":0,"farmlvl":1,"sales":0,"income":0,"exp":0,"tili":['.$sysinfo['setdata']['newtili'].','.$sysinfo['setdata']['newtili'].','.$_G['timestamp'].']},"seed":{"1":[1,5]}}';
					
					$realland['realland']['jrid'] = $jrid;
					$realland['realland']['nowlvl'] = 1;
					$realland['realland']['nowsd'] = 0;
					$realland['realland']['md5'] = md5($_G['timestamp'].$pass.$_G['uid'].$jrid);
					$data['realland'] = json_encode($realland['realland']);
					
					C::t('#'.$jn.'#'.$jn.'_user')->insert($data);

					$data = array();
					$data['uid'] = $_G['uid'];
					$data['createtime'] = $_G['timestamp'];
					for($x=1;$x<=$sysinfo['setdata']['freeland'];$x++){
						$landdata[$x]['seed'] = 0;
						$landdata[$x]['prodstart'] = 0;
						$landdata[$x]['prodfinish'] = 0;
						$landdata[$x]['type'] = 1;
						$landdata[$x]['weed'] = 0;
						$landdata[$x]['worm'] = 0;
						$landdata[$x]['water'] = 0;
						$landdata[$x]['expired'] = 0;
						$landdata[$x]['oriqty'] = 0;
					}
					$data['fdata'] = json_encode($landdata);
					C::t('#'.$jn.'#'.$jn.'_land')->insert($data);
				}
				
				$linkgen = lang("plugin/$jn","s191");//'ѡ��ɹ�, �Ͻ�ȥ��ˮ�ɣ�';
				$linkgen = '<script>ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=realplantinfo&timestamp='.$_G['timestamp'].'\',\'realplantinfo\');layer.close(layer.index);layer.msg(\''.$linkgen.'\');</script>';
				include template($jn.':'.$jn.'_normal_plain');
				exit;
			}
		}
	}
	if($_GET['deliverysubmit']){
		if($_GET['formhash'] == $_G['formhash']){
			$md5 = daddslashes($_GET['verify']);
			$jr['address'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['address']));
			$jr['receiver'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['receiver']));
			$jr['postcode'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['postcode']));
			$jr['telephone'] = iconv($_G['charset'],'UTF-8',daddslashes($_GET['telephone']));
			$userinfo['realland'] = json_decode($userinfo['realland'],true);
			if($userinfo['realland']['nowlvl'] >= 5){
				if($userinfo['realland']['md5'] != $md5){
					$wording = lang("plugin/$jn","s192");//'�һ�ʧ��';
				}else{
					$jr['jrid'] = $userinfo['realland']['jrid'];
					$data['rstatus'] = 1;
					$userinfo['realland'] = '';
					C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('realland'=>$userinfo['realland']));
					$jr['md5'] = $md5;
					$data['rinfo'] = json_encode($jr);
					$data['uid'] = dintval($_G['uid']);
					$data['createtime'] = dintval($_G['timestamp']);
					C::t('#'.$jn.'#'.$jn.'_realland_record')->insert($data);
					$wording = lang("plugin/$jn","s193");//'�һ��ɹ�';
				}
			}else{
				$wording = lang("plugin/$jn","s194");//'�����ܶһ�';
			}
			$linkgen = lang("plugin/$jn","s195").'.<script>layer.msg(\''.$wording.'\');ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=realplantinfo&timestamp='.$_G['timestamp'].'\',\'realplantinfo\');</script>';
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
	}
	$userinfo['realland'] = json_decode($userinfo['realland'],true);
	if($userinfo['realland']['jrid'] == '0' || !$userinfo['realland']['jrid']){
		$imgnow = 'source/plugin/'.$jn.'/template/images/youngTree.png';
		$percentnow = 0;
	}else{
		$treeinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland')." WHERE jrid = '".$userinfo['realland']['jrid']."'");
		$treeinfo['jrdata'] = json_decode($treeinfo['jrdata'],true);
		$imgnow = $treeinfo['jrdata']['jimg'.$userinfo['realland']['nowlvl']];
		$maxheight = array('0','60','130','150','200','68');
		$treeinfo['jrdata']['jword'.$userinfo['realland']['nowlvl']] = iconv('UTF-8',$_G['charset'],$treeinfo['jrdata']['jword'.$userinfo['realland']['nowlvl']]);
		$nowsd = $treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]-$userinfo['realland']['nowsd'];
		$wordingnow = str_replace('{xxx}', $nowsd, $treeinfo['jrdata']['jword'.$userinfo['realland']['nowlvl']]);
		
		if($userinfo['realland']['nowlvl'] == '4'){
			$daoshu = $nowsd/$treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]*100;
			$per = number_format($daoshu,2,'.','').'%';
			$wordingnow = str_replace('{xxx}', $per, $treeinfo['jrdata']['jword'.$userinfo['realland']['nowlvl']]);
		}
		if($userinfo['realland']['nowsd'] >= $treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]){
			$nowfl = $treeinfo['jrdata']['jrfl'.$userinfo['realland']['nowlvl']]-$userinfo['realland']['nowfl'];
			$wordingnow = lang("plugin/$jn","s196",array('nowfl'=>$nowfl));//'ˮ�����㹻, ����ʩ��'.$nowfl.'�ν��й�������';
		}
		$percentnow = floor($userinfo['realland']['nowsd']/$treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]*100);
		if($userinfo['realland']['nowlvl'] >= '5'){
			$wordingnow = lang("plugin/$jn","s197");
			$imgnow = 'source/plugin/jnfarm/template/images/box.png';
			$delivery = 1;
		}
	}
	$sysinfo['setdata']['xbtnname1'] = iconv('UTF-8',$_G['charset'],$sysinfo['setdata']['xbtnname1']);
	$sysinfo['setdata']['xbtnname2'] = iconv('UTF-8',$_G['charset'],$sysinfo['setdata']['xbtnname2']);
	$jifen = getuserprofile('extcredits'.$sysinfo['setdata']['rlwaterext']);
	$feiliaojifen = getuserprofile('extcredits'.$sysinfo['setdata']['rlfertext']);
	if($jifen <= 0){
		if($sysinfo['cword'][0]){
			$showcword = $sysinfo['cword'][0];
			$showwater = 1;
		}else{
			$showwater = 2;
		}
	}
	if($feiliaojifen <= 0){
		if($sysinfo['cword'][1]){
			$showcword = $sysinfo['cword'][1];
			$showfertilize = 1;
		}else{
			$showfertilize = 2;
		}
	}
	if($sysinfo['reallandword']){
		$sysinfo['reallandword'] = explode('|',$sysinfo['reallandword']);
		$rand_keys = array_rand($sysinfo['reallandword'], 1);
		$showword = stripslashes(htmlspecialchars_decode($sysinfo['reallandword'][$rand_keys]));
	}
	
	include template($jn.':'.$jn.'_realland');
	exit;
}
//From: Dism��taobao��com
?>