<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
$pass = substr(md5(uniqid(mt_rand(), true)) , 0, 8);
$userinfo['realland'] = json_decode($userinfo['realland'],true);
$sysinfo['cword'] = htmlspecialchars_decode($sysinfo['cword']);
$sysinfo['cword'] = explode('|',$sysinfo['cword']);
if($userinfo['realland']['jrid'] == '0' || !$userinfo['realland']['jrid']){
	$imgnow = 'source/plugin/'.$jn.'/template/images/youngTree.png';
	$percentnow = 0;
}else{
	$treeinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_realland')." WHERE jrid = '".$userinfo['realland']['jrid']."'");
	$treeinfo['jrdata'] = json_decode($treeinfo['jrdata'],true);
	$imgnow = $treeinfo['jrdata']['jimg'.$userinfo['realland']['nowlvl']];
	$maxheight = array('0','60','130','150','200','68');
	$treeinfo['jrdata']['jword'.$userinfo['realland']['nowlvl']] = iconv('UTF-8',$_G['charset'],$treeinfo['jrdata']['jword'.$userinfo['realland']['nowlvl']]);
	$nowsd = $treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]-$userinfo['realland']['nowsd'];
	$wordingnow = str_replace('{xxx}', $nowsd, $treeinfo['jrdata']['jword'.$userinfo['realland']['nowlvl']]);
	
	if($userinfo['realland']['nowlvl'] == '4'){
		$daoshu = $nowsd/$treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]*100;
		$per = number_format($daoshu,2,'.','').'%';
		$wordingnow = str_replace('{xxx}', $per, $treeinfo['jrdata']['jword'.$userinfo['realland']['nowlvl']]);
	}
	if($userinfo['realland']['nowsd'] >= $treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]){
		$nowfl = $treeinfo['jrdata']['jrfl'.$userinfo['realland']['nowlvl']]-$userinfo['realland']['nowfl'];
		$wordingnow = lang("plugin/$jn","s196",array('nowfl'=>$nowfl));//'ˮ�����㹻, ����ʩ��'.$nowfl.'�ν��й�������';
	}
	$percentnow = floor($userinfo['realland']['nowsd']/$treeinfo['jrdata']['jrsd'.$userinfo['realland']['nowlvl']]*100);
	if($userinfo['realland']['nowlvl'] >= '5'){
		$wordingnow = lang("plugin/$jn","s197");
		$imgnow = 'source/plugin/jnfarm/template/images/box.png';
		$delivery = 1;
	}
}
$jifen = getuserprofile('extcredits'.$sysinfo['setdata']['rlwaterext']);
$feiliaojifen = getuserprofile('extcredits'.$sysinfo['setdata']['rlfertext']);
if($jifen <= 0){
	if($sysinfo['cword'][0]){
		$showwater = 1;
	}else{
		$showwater = 2;
	}
}
if($feiliaojifen <= 0){
	if($sysinfo['cword'][1]){
		$showfertilize = 1;
	}else{
		$showfertilize = 2;
	}
}
$sysinfo['setdata']['xbtnname1'] = iconv('UTF-8',$_G['charset'],$sysinfo['setdata']['xbtnname1']);
$sysinfo['setdata']['xbtnname2'] = iconv('UTF-8',$_G['charset'],$sysinfo['setdata']['xbtnname2']);
?>