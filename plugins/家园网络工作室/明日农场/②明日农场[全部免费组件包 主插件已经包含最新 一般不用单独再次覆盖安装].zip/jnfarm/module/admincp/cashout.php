<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
$jn = 'jnfarm';
$jnc = $_G['cache']['plugin'][$jn];
$g_adminids = explode('|',$jnc['adminids']);//����ԱȨ��
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
//require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/func.php';
if(!in_array($_G['uid'],$g_adminids)){
	showmessage("$jn:s002");
}
$page = $_G['page'];
$tpp = 100;
$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnfarm_cashout')."");
if(@ceil($total/$tpp) < $page) 	$page = 1;
$start_limit = ($page - 1) * $tpp;

$cashoutlist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_cashout')." ORDER BY jcid DESC LIMIT {$start_limit},{$tpp}");
foreach($cashoutlist as $cl){
	$cl['createtime'] = date("Y-m-d H:i:s",$cl['createtime']);
	$cl['updatetime'] = date("Y-m-d H:i:s",$cl['updatetime']);
	$cllist[] = $cl;
}
if($_GET['approved'] == 'true'){
	if($_GET['formhash'] == $_G['formhash']){
		$jcid = dintval($_GET['jcid']);
		$cinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_cashout')." WHERE jcid = '$jcid'");
		if($cinfo['jstatus'] == '1'){
			DB::query("UPDATE ".DB::table('game_jnfarm_cashout')." SET jstatus = '2', updatetime = '".$_G['timestamp']."', verifyuid = '".$_G['uid']."' WHERE jcid = '$jcid'");
			$cdd['extcredits'.$cinfo['extcredits']] = '+'.$cinfo['getext'];
			updatemembercount($cinfo['submituid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s119"));
			$linkgen = lang("plugin/$jn","s021");
			$thislang = lang("plugin/$jn","s118",array('cinfogetext'=>$cinfo['getext'],'cinfocashexttitle'=>$_G['setting']['extcredits'][$cinfo['cashext']]['title']));//'�ҳ�'.$cinfo['getext'].$_G['setting']['extcredits'][$cinfo['cashext']]['title'].'�ɹ�';
			nlog($_G['uid'],6,$_G['timestamp'],$thislang);
			showmessage("$jn:s117",'plugin.php?id='.$jn.':admincp'.$jn.'&do=cashout');
		}else{
			showmessage("$jn:s116");
		}
	}
}
if($_GET['reject'] == 'true'){
	if($_GET['formhash'] == $_G['formhash']){
		$jcid = dintval($_GET['jcid']);
		$cinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_cashout')." WHERE jcid = '$jcid'");
		if($cinfo['jstatus'] == '1'){
			DB::query("UPDATE ".DB::table('game_jnfarm_cashout')." SET jstatus = '3', updatetime = '".$_G['timestamp']."', verifyuid = '".$_G['uid']."' WHERE jcid = '$jcid'");

			$tjinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnfarm_user')." WHERE uid = '".$cinfo['submituid']."'");

			$tjinfo['udata'] = json_decode($tjinfo['udata'],true);
			$tjinfo['udata']['data']['money'] = $tjinfo['udata']['data']['money']+$cinfo['allamount'];
			$tjinfo['udata'] = json_encode($tjinfo['udata']);
			C::t('#'.$jn.'#'.$jn.'_user')->update($tjinfo['uid'],array('udata'=>$tjinfo['udata']));

			$linkgen = lang("plugin/$jn","s021");
			$thislang = lang("plugin/$jn","s120",array('cinfogetext'=>$cinfo['getext'],'cinfocashexttitle'=>$_G['setting']['extcredits'][$cinfo['cashext']]['title'])).$cinfo['allamount'].$jnc['mt'];//'�ҳ�'.$cinfo['getext'].$_G['setting']['extcredits'][$cinfo['cashext']]['title'].'ʧ��, ���˻�'.$cinfo['allamount'].$jnc['mt'].'';
			nlog($_G['uid'],6,$_G['timestamp'],$thislang);
			showmessage("$jn:s117",'plugin.php?id='.$jn.':admincp'.$jn.'&do=cashout');
		}else{
			showmessage("$jn:s116");
		}
	}
}
//From: Dism��taobao��com
?>