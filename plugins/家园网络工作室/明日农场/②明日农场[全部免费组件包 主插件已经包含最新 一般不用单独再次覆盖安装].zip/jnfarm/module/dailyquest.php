<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if(!$dailyqueston){
	showmessage("$jn:s001");
}
if($_GET['do'] == 'dailyquest'){
	$userinfo['dailyquest'] = json_decode($userinfo['dailyquest'],true);
	$quest = DB::fetch_all("SELECT * FROM ".DB::table('game_jnfarm_dailyquest')." WHERE minlvl <= '".$userinfo['udata']['data']['farmlvl']."' ORDER BY jdorder ASC");
	$usergroup = DB::fetch_all("SELECT * FROM ".DB::table('common_usergroup')." ORDER BY groupid ASC ");
	$usergroup = array_column($usergroup,null,'groupid');
	foreach($quest as $qu){
		$qu['jddata'] = json_decode($qu['jddata'],true);
		$qu['jddata']['groupid'] = explode(',',$qu['jddata']['groupid']);
		if($qu['jddata']['groupid'][0] >= 1){
			$c = count($qu['jddata']['groupid']);
			for($x=0;$x<$c;$x++){
				$qu['groupword'][$x] = $usergroup[$qu['jddata']['groupid'][$x]]['grouptitle'];
			}
			$qu['groupword'] = implode(',',$qu['groupword']);
		}
		if(in_array($qu['jdid'],$userinfo['dailyquest']['questid'])){
			$qu['complete'] = 1;
		}
		if(!$qu['jddata']['groupid'] || $qu['jddata']['groupid'][0] == '0' || in_array($_G['groupid'],$qu['jddata']['groupid'])){
			if(!in_array($qu['jdid'],$userinfo['dailyquest']['questid'])){
				if($qu['jddata']['type'] == '1'){//���
					$qu['canget'] = 1;
				}
				//��ʼ���
				if($qu['jddata']['rules'] == '1'){//��ֲ����
					if($userinfo['dailyquest']['zhongzhi'] >= $qu['jddata']['rulesqty']){
						$qu['canget'] = 1;
					}
				}
				if($qu['jddata']['rules'] == '2'){//��ֲ����
					if($userinfo['dailyquest']['shoucheng'] >= $qu['jddata']['rulesqty']){
						$qu['canget'] = 1;
					}
				}
				if($qu['jddata']['rules'] == '3'){//��ֲ����
					if($userinfo['dailyquest']['toucai'] >= $qu['jddata']['rulesqty']){
						$qu['canget'] = 1;
					}
				}
				if($qu['jddata']['rules'] == '4'){
					$todaytime = strtotime(date("Y-m-d",$_G['timestamp']));
					$count = DB::result_first("SELECT count(*) cnt FROM ".DB::table('forum_thread')." WHERE authorid = '".$_G['uid']."' AND dateline >= '".$todaytime."'");
					if($count >= $qu['jddata']['rulesqty']){
						$qu['canget'] = 1;
					}
				}
				if($qu['jddata']['rules'] == '5'){
					$todaytime = strtotime(date("Y-m-d",$_G['timestamp']));
					$count = DB::result_first("SELECT count(*) cnt FROM ".DB::table('forum_post')." WHERE authorid = '".$_G['uid']."' AND dateline >= '".$todaytime."'");
					if($count >= $qu['jddata']['rulesqty']){
						$qu['canget'] = 1;
					}
				}
			}
		}
		$qu['jddata']['jdesc'] = iconv('UTF-8',strtoupper($_G['charset']),$qu['jddata']['jdesc']);
		$qulist[] = $qu;
	}
	if($_GET['ac'] == 'updatequestinfo'){
		include template($jn.':'.$jn.'_normal');
		exit;
	}
	$questid = dintval($_GET['questid']);
	if($questid > 0){
		if($_GET['formhash'] == $_G['formhash']){
			$wording = dailyquest($_G['uid'],$questid);
			if(file_exists(DISCUZ_ROOT.'source/plugin/'.$jn.'/module/realland.php')){
				$linkgen = '<script>layer.msg(\''.$wording.'\');ajaxget(\'plugin.php?id='.$jn.'&do=dailyquest&ac=updatequestinfo&timestamp='.$_G['timestamp'].'\',\'dailyquestcon\');ajaxget(\'plugin.php?id='.$jn.'&do=realland&ac=realplantinfo&timestamp='.$_G[timestamp].$pass.'\',\'realplantinfo\');</script>';
			}else{
				$linkgen = '<script>layer.msg(\''.$wording.'\');ajaxget(\'plugin.php?id='.$jn.'&do=dailyquest&ac=updatequestinfo&timestamp='.$_G['timestamp'].'\',\'dailyquestcon\');</script>';
			}
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
	}
	include template($jn.':'.$jn.'_dailyquest');
	exit;
}
//From: Dism��taobao��com
?>