<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
//��鵱ǰ��ˮ��ս
for($x=1;$x<8;$x++){
	if($userinfo['udata']['challenge']['d'.$x] == '1'){
		$d[$x] = 1;
		$dword[$x] = '<div class="sdayaf" align="center">&#10004;</div>';
		$add = $add+1;
	}else{
		$dword[$x] = '<div class="sdayb4" align="center"><b>'.$x.'</b></div>';
	}
}
$dword = implode(' ',$dword);
$userinfo['dayquest'] = json_decode($userinfo['dayquest'],true);
$timeleft = $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][0]-$userinfo['dayquest']['realland']['todaychallengewater'];
if($timeleft <= 0){
	$timeleft = 0;
}
if($_GET['gift'] == 'true'){
	if($_GET['formhash'] == $_G['formhash']){
		//����
		if($userinfo['dayquest']['realland']['todaychallengewatercomplete'] == '1'){
			$linkgen = "<script>layer.msg('".lang("plugin/$jn","s201")."');".$_G['timestamp']."</script>";
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
		if($timeleft > 0){
			$linkgen = "<script>layer.msg('".lang("plugin/$jn","s202")."');</script>";
		}else{
			$userinfo['udata']['challenge']['d'.($add+1)] = 1;//���
			$userinfo['dayquest']['realland']['todaychallengewatercomplete'] = 1;
			$userinfo['dayquest'] = json_encode($userinfo['dayquest']);
			C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('dayquest'=>$userinfo['dayquest']));
			$rand = mt_rand($sysinfo['setdata']['realland']['challenge']['day'.($add+1)][3],$sysinfo['setdata']['realland']['challenge']['day'.($add+1)][4]);
			if($sysinfo['setdata']['realland']['challenge']['day'.($add+1)][1] == '1'){//����
				$cdd['extcredits'.$sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]] = '+'.$rand;
				updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s203"));
			}
			if($sysinfo['setdata']['realland']['challenge']['day'.($add+1)][1] == '2'){//����
				$cseed = count($userinfo['udata']['seed']);
				for($y = 1;$y <= $cseed; $y++){
					if($userinfo['udata']['seed'][$y][0] == $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]){
						$userinfo['udata']['seed'][$y][1] = $userinfo['udata']['seed'][$y][1]+$rand;
						$ok = '1';
					}
				}
				if(!$ok){
					$userinfo['udata']['seed'][$y][0] = $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2];
					$userinfo['udata']['seed'][$y][1] = $rand;
					$ok = '';
				}
			}
			if($sysinfo['setdata']['realland']['challenge']['day'.($add+1)][1] == '3'){//��Ʒ
				if($allist[$sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]]['type'] == 'seed'){
					$cseed = count($userinfo['udata']['prod']);
					for($y = 1;$y <= $cseed; $y++){
						if($userinfo['udata']['prod'][$y][0] == $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]){
							$userinfo['udata']['prod'][$y][1] = $userinfo['udata']['prod'][$y][1]+$rand;
							$ok = '1';
						}
					}
					if(!$ok){
						$userinfo['udata']['prod'][$y][0] = $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2];
						$userinfo['udata']['prod'][$y][1] = $rand;
						$ok = '';
					}
				}
				if($allist[$sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]]['type'] == 'fertilize'){
					$cseed = count($userinfo['udata']['fertilize']);
					for($y = 1;$y <= $cseed; $y++){
						if($userinfo['udata']['fertilize'][$y][0] == $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]){
							$userinfo['udata']['fertilize'][$y][1] = $userinfo['udata']['fertilize'][$y][1]+$rand;
							$ok = '1';
						}
					}
					if(!$ok){
						$userinfo['udata']['fertilize'][$y][0] = $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2];
						$userinfo['udata']['fertilize'][$y][1] = $rand;
						$ok = '';
					}
				}
				if($allist[$sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]]['type'] == 'nitem'){
					$cseed = count($userinfo['udata']['nitem']);
					for($y = 1;$y <= $cseed; $y++){
						if($userinfo['udata']['nitem'][$y][0] == $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]){
							$userinfo['udata']['nitem'][$y][1] = $userinfo['udata']['nitem'][$y][1]+$rand;
							$ok = '1';
						}
					}
					if(!$ok){
						$userinfo['udata']['nitem'][$y][0] = $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2];
						$userinfo['udata']['nitem'][$y][1] = $rand;
						$ok = '';
					}
				}
			}
			if($add+1 == '7'){
				//�ڰ���ﵽ��
				if($sysinfo['setdata']['realland']['challenge']['fday'][0] == '1'){//����
					$cdd['extcredits'.$sysinfo['setdata']['realland']['challenge']['fday'][1]] = '+'.$sysinfo['setdata']['realland']['challenge']['fday'][2];
					updatemembercount($_G['uid'], $cdd, true, '', 0, '',$jnc['title'],lang("plugin/$jn","s204"));
				}
				if($sysinfo['setdata']['realland']['challenge']['fday'][0] == '2'){//����
					$cseed = count($userinfo['udata']['seed']);
					for($y = 1;$y <= $cseed; $y++){
						if($userinfo['udata']['seed'][$y][0] == $sysinfo['setdata']['realland']['challenge']['fday'][1]){
							$userinfo['udata']['seed'][$y][1] = $userinfo['udata']['seed'][$y][1]+$sysinfo['setdata']['realland']['challenge']['fday'][2];
							$addok = '1';
						}
					}
					if(!$addok){
						$userinfo['udata']['seed'][$y][0] = $sysinfo['setdata']['realland']['challenge']['fday'][1];
						$userinfo['udata']['seed'][$y][1] = $sysinfo['setdata']['realland']['challenge']['fday'][2];
						$addok = '';
					}
				}
				if($sysinfo['setdata']['realland']['challenge']['fday'][0] == '3'){//����
					if($allist[$sysinfo['setdata']['realland']['challenge']['fday'][2]]['type'] == 'seed'){
						$cseed = count($userinfo['udata']['prod']);
						for($y = 1;$y <= $cseed; $y++){
							if($userinfo['udata']['prod'][$y][0] == $sysinfo['setdata']['realland']['challenge']['fday'][1]){
								$userinfo['udata']['prod'][$y][1] = $userinfo['udata']['prod'][$y][1]+$sysinfo['setdata']['realland']['challenge']['fday'][2];
								$addok = '1';
							}
						}
						if(!$addok){
							$userinfo['udata']['prod'][$y][0] = $sysinfo['setdata']['realland']['challenge']['fday'][1];
							$userinfo['udata']['prod'][$y][1] = $sysinfo['setdata']['realland']['challenge']['fday'][2];
							$addok = '';
						}
					}
					if($allist[$sysinfo['setdata']['realland']['challenge']['fday'][2]]['type'] == 'fertilize'){
						$cseed = count($userinfo['udata']['fertilize']);
						for($y = 1;$y <= $cseed; $y++){
							if($userinfo['udata']['fertilize'][$y][0] == $sysinfo['setdata']['realland']['challenge']['fday'][1]){
								$userinfo['udata']['fertilize'][$y][1] = $userinfo['udata']['fertilize'][$y][1]+$sysinfo['setdata']['realland']['challenge']['fday'][2];
								$addok = '1';
							}
						}
						if(!$addok){
							$userinfo['udata']['fertilize'][$y][0] = $sysinfo['setdata']['realland']['challenge']['fday'][1];
							$userinfo['udata']['fertilize'][$y][1] = $sysinfo['setdata']['realland']['challenge']['fday'][2];
							$addok = '';
						}
					}
					if($allist[$sysinfo['setdata']['realland']['challenge']['fday'][2]]['type'] == 'nitem'){
						$cseed = count($userinfo['udata']['nitem']);
						for($y = 1;$y <= $cseed; $y++){
							if($userinfo['udata']['nitem'][$y][0] == $sysinfo['setdata']['realland']['challenge']['fday'][1]){
								$userinfo['udata']['nitem'][$y][1] = $userinfo['udata']['nitem'][$y][1]+$sysinfo['setdata']['realland']['challenge']['fday'][2];
								$addok = '1';
							}
						}
						if(!$addok){
							$userinfo['udata']['nitem'][$y][0] = $sysinfo['setdata']['realland']['challenge']['fday'][1];
							$userinfo['udata']['nitem'][$y][1] = $sysinfo['setdata']['realland']['challenge']['fday'][2];
							$addok = '';
						}
					}
				}
				
				
				for($x=1;$x<8;$x++){
					$userinfo['udata']['challenge']['d'.$x] = 0;
				} 
			}
			$userinfo['udata'] = json_encode($userinfo['udata'],true);
			C::t('#'.$jn.'#'.$jn.'_user')->update($userinfo['juid'],array('udata'=>$userinfo['udata']));
			$linkgen = "<script>layer.msg('".lang("plugin/$jn","s205")."');ajaxget('plugin.php?id=$jn&do=realland&ac=realplantinfo&timestamp=".$_G['timestamp'].$pass."','realplantinfo');".$_G['timestamp']."</script>";
			include template($jn.':'.$jn.'_normal_plain');
			exit;
		}
	}
}
if($sysinfo['setdata']['realland']['challenge']['day'.($add+1)][1] == '1'){//����
	$itemtitle = $_G['setting']['extcredits'][$sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]]['title'];
}
if($sysinfo['setdata']['realland']['challenge']['day'.($add+1)][1] == '2'){//����
	$itemtitle = $allist[$sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]]['stitle'].lang("plugin/$jn","s038");
}
if($sysinfo['setdata']['realland']['challenge']['day'.($add+1)][1] == '3'){//����
	$itemtitle = $allist[$sysinfo['setdata']['realland']['challenge']['day'.($add+1)][2]]['stitle'];
}
$getmax = $sysinfo['setdata']['realland']['challenge']['day'.($add+1)][4];

if($sysinfo['setdata']['realland']['challenge']['fday'][0] == '1'){//����
	$fitemtitle = $_G['setting']['extcredits'][$sysinfo['setdata']['realland']['challenge']['fday'][1]]['title'];
}
if($sysinfo['setdata']['realland']['challenge']['fday'][0] == '2'){//����
	$fitemtitle = $allist[$sysinfo['setdata']['realland']['challenge']['fday'][1]]['stitle'].lang("plugin/$jn","s038");
}
if($sysinfo['setdata']['realland']['challenge']['fday'][0] == '3'){//����
	$fitemtitle = $allist[$sysinfo['setdata']['realland']['challenge']['fday'][1]]['stitle'];
}
$fqty = $sysinfo['setdata']['realland']['challenge']['fday'][2];
//�����ǵڼ�������
include template($jn.':'.$jn.'_challenge');
exit;
?>