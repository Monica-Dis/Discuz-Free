<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
$config = $_G['cache']['plugin']['jninvest'];
$g_adminids = explode('|',$config['adminuid']);//����ԱȨ��
$g_buyext = $config['buyext'];
$g_sellext = $config['sellext'];
$g_sellfee = $config['sellfee'] * 0.01; //Fees
$g_sellfeeori = $config['sellfee'];
$extcreditsbuy = 'extcredits'.$g_buyext;
$extcreditssell = 'extcredits'.$g_sellext;
/*$queryJNextc = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$_G[uid]'");
while($rowqJNextc = DB::fetch($queryJNextc)){
	$extcredits1 = getuserprofile('extcredits'.$g_buyext);$rowqJNextc[$extcreditsbuy];
	$extcredits2 = getuserprofile('extcredits'.$g_sellext)[$extcreditssell];
}*/
$extcredits1 = getuserprofile('extcredits'.$g_buyext);
$extcredits2 = getuserprofile('extcredits'.$g_sellext);
$navtitle = lang('plugin/jninvest','JNIN');
$metakeywords = lang('plugin/jninvest','JNIN');
$metadescription = lang('plugin/jninvest','metaJNIN');
$g_buyextname = $_G['setting']['extcredits'][$g_buyext]['title'];
$g_sellextname = $_G['setting']['extcredits'][$g_sellext]['title'];
if($_GET['mobile']){
	$mobilelink = '&mobile='.dintval($_GET['mobile']);
}
if (!$g_buyext || !$g_sellext){
	showmessage('jninvest:pleasechoosewang','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
}
if (in_array($_G['uid'],$g_adminids)){
	$admincpbtn = "<font color=\"#FFFFFF\"> | </font><a href=\"plugin.php?id=jninvest:admincp\"><b><font color=\"#FF0000\">".lang('plugin/jninvest','admincp_m0')."</font></b></a>";
}
foreach($_G['setting']['extcredits'] as $key => $value){
	$ext = 'extcredits'.$key;
	getuserprofile($ext);
	$person['extcredits'][$key]['title'] = $value['title'];
	$person['extcredits'][$key]['value'] = $_G['member'][$ext];
	$person['extcredits'][$key]['unit'] = $value['unit'];
}
$userinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest_user')." WHERE uid = '$_G[uid]'");

if($_GET['do'] == 'openaccount'){
	if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
	if($_GET['formhash'] == $_G['formhash']){
		if (!$userinfo['id']){
			DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_user')." (uid,level,exp,inhand,status) VALUES ('".$_G['uid']."', '1', '0', '0', '0')");
			showmessage('jninvest:openACSuccess','plugin.php?id=jninvest'.$mobilelink,array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime' => true));
		}
	}else{
		showmessage('jninvest:FormhashIncorrect','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
	}
}
$investlevel = $userinfo['level'];
$investexp = $userinfo['exp'];
$investnext = $investlevel * 100;
$investshow = $investlevel * 10;
$investexpplus = $investexp + $keyinmount;
$investinhandplus = $userinfo['inhand'] + $keyinmount;
$investinhand = ($investlevel * 20) - $userinfo['inhand'];

$dbc = DB::fetch_all("SELECT t1.*,t2.username,t3.investname FROM ".DB::table('game_jninvest_invest_ulog')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid = t2.uid) LEFT JOIN ".DB::table('game_jninvest_invest')." t3 ON (t1.investid = t3.id) ORDER BY t1.id desc limit 30");
foreach($dbc as $rowInvestUlog){
	$rowInvestUlog['timestamp'] = date("Y-m-d H:i",($rowInvestUlog['timestamp']));
	$InvestUlog_list[] = $rowInvestUlog;
}

//Ͷ�ʿ�ʼ
if (!$_GET['do']){
	$investid = dintval($_GET['investid']);
	$queryInvestBuy = DB::fetch_all("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE id = '$investid'");
	foreach($queryInvestBuy as $rowInvestBuy){
		$rowInvestBuy['times'] = date("Y-m-d H:i",($rowInvestBuy['timestamp']));
		if ($rowInvestBuy['current'] > $rowInvestBuy['last']){
			$rowInvestBuy['beza'] = '<font color="red">+'.number_format($rowInvestBuy['current'] - $rowInvestBuy['last'],'3','.',',').'</font>';
		}elseif ($rowInvestBuy['current'] < $rowInvestBuy['last']){
			$rowInvestBuy['beza'] = '<font color="#00CC00">-'.number_format($rowInvestBuy['last']-$rowInvestBuy['current'],'3','.',',').'</font>';
		}else{
			$rowInvestBuy['beza'] = '+0.000';
		}
		if ($rowInvestBuy['current'] > $rowInvestBuy['yesterday']){
			$rowInvestBuy['bezaallday'] = '<font color="red">+'.number_format($rowInvestBuy['current']-$rowInvestBuy['yesterday'],'3','.',',').'</font>';
		}elseif ($rowInvestBuy['current'] < $rowInvestBuy['yesterday']){
			$rowInvestBuy['bezaallday'] = '<font color="#00CC00">-'.number_format($rowInvestBuy['yesterday']-$rowInvestBuy['current'],'3','.',',').'</font>';
		}else{
			$rowInvestBuy['bezaallday'] = '+0.000';
		}
		$user_invest_selectlist[] = $rowInvestBuy;
	}
	$queryInvestTime = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest_log')." ORDER BY timestamp desc LIMIT 1"); //Query topup record
	$rowInvestTimeLast = $queryInvestTime['timestamp'];
	$rowInvestTimeNext = $rowInvestTimeLast + 300;
	$rowInvestTimeLast = date("Y-m-d H:i:s",($rowInvestTimeLast));
	$rowInvestTimeNext = date("Y-m-d H:i:s",($rowInvestTimeNext));
	/*while($rowInvestTime = DB::fetch($queryInvestTime)) {
		$rowInvestTimeLast = $rowInvestTime['timestamp'];
		$rowInvestTimeNext = $rowInvestTimeLast + 300;
		$rowInvestTimeLast = date("Y-m-d H:i:s",($rowInvestTimeLast));
		$rowInvestTimeNext = date("Y-m-d H:i:s",($rowInvestTimeNext));
	}*/
	
	$page = $_G['page'];
	$tpp = 100;
	$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jninvest_invest')." WHERE status = 1");
	if(@ceil($total/$tpp) < $page) 	$page = 1;
	$start_limit = ($page - 1) * $tpp;
		
	$queryInvest = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jninvest_invest')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid = t2.uid) WHERE t1.status = 1 ORDER BY t1.id desc limit {$start_limit},{$tpp} "); //Query topup record
	foreach($queryInvest as $rowInvest){
		$id[] = $rowTopup['id'];
		$rowInvest['times'] = date("Y-m-d H:i",($rowInvest['timestamp']));
		if ($rowInvest['current'] > $rowInvest['last']){
			$rowInvest['beza'] = '<font color="red">+'.number_format($rowInvest['current']-$rowInvest['last'],'3','.',',').'</font>';
		}elseif ($rowInvest['current'] < $rowInvest['last']){
			$rowInvest['beza'] = '<font color="#00CC00">-'.number_format($rowInvest['last']-$rowInvest['current'],'3','.',',').'</font>';
		}else{
			$rowInvest['beza'] = '+0.000';
		}
		if ($rowInvest['current'] > $rowInvest['yesterday']){
			$rowInvest['bezaallday'] = '<font color="red">+'.number_format($rowInvest['current']-$rowInvest['yesterday'],'3','.',',').'</font>';
		}elseif ($rowInvest['current'] < $rowInvest['yesterday']){
			$rowInvest['bezaallday'] = '<font color="#00CC00">-'.number_format($rowInvest['yesterday']-$rowInvest['current'],'3','.',',').'</font>';
		}else{
			$rowInvest['bezaallday'] = '+0.000';
		}
		$user_invest_list[] = $rowInvest;
	}
	/*while($rowInvest = DB::fetch($queryInvest)) {
		$id[] = $rowTopup['id'];
		$rowInvest['times'] = date("Y-m-d H:i",($rowInvest['timestamp']));
		if ($rowInvest['current'] > $rowInvest['last']){
			$rowInvest['beza'] = '<font color="red">+'.number_format($rowInvest['current']-$rowInvest['last'],'3','.',',').'</font>';
		}elseif ($rowInvest['current'] < $rowInvest['last']){
			$rowInvest['beza'] = '<font color="#00CC00">-'.number_format($rowInvest['last']-$rowInvest['current'],'3','.',',').'</font>';
		}else{
			$rowInvest['beza'] = '+0.000';
		}
		if ($rowInvest['current'] > $rowInvest['yesterday']){
			$rowInvest['bezaallday'] = '<font color="red">+'.number_format($rowInvest['current']-$rowInvest['yesterday'],'3','.',',').'</font>';
		}elseif ($rowInvest['current'] < $rowInvest['yesterday']){
			$rowInvest['bezaallday'] = '<font color="#00CC00">-'.number_format($rowInvest['yesterday']-$rowInvest['current'],'3','.',',').'</font>';
		}else{
			$rowInvest['bezaallday'] = '+0.000';
		}
		$user_invest_list[] = $rowInvest;
	};*/
	array_multisort($id, SORT_DESC, $user_invest_list);
			
	$queryInvestBuy = DB::fetch_all("SELECT t1.*,t2.* FROM ".DB::table('game_jninvest_invest')." t1 JOIN ".DB::table('game_jninvest_invest_s')." t2 ON (t1.investcode = t2.investcode) WHERE t2.uid = '$_G[uid]' AND t2.status = 1"); //Query topup record
	
	$inhand = 0;
	$inhandvalue = 0;
	
	$queryInvestBuyExt = count($queryInvestBuy);
	foreach($queryInvestBuy as $rowInvestBuy){
		$rowInvestBuy['extraBT'] = $AllinBT * 0.001;
		$rowEXTRABT = $rowInvestBuy['extraBT'];
		$inhand = $inhand+$rowInvestBuy['unit'];
		$inhandvalue = $inhandvalue+$rowInvestBuy['unit']*$rowInvestBuy['current'];
		$user_invest_buylist[] = $rowInvestBuy;
	}
	
	$inhandvalue = number_format($inhandvalue,1,'.',',');
	
	//��ȥ�ĸ���
	$dbi = DB::fetch_all("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE status = '1'");
	foreach($dbi as $dbl){
		$dbr = DB::fetch_all("SELECT * FROM ".DB::table('game_jninvest_invest_log')." WHERE investcode = '".$dbl['investcode']."' ORDER BY timestamp DESC LIMIT 20");
		$dbr = array_reverse($dbr);
		$rrr = array();
		foreach($dbr as $dbrl){
			$ddd[] = number_format($dbrl['current'],3,'.',',');
			$rrr[] = '"'.date("H:i",$dbrl['timestamp']).'"';
		}
		$dbl['ddd'] = implode(',',$ddd);
		$okk = implode(',',$rrr);
		//$ddd = '';
		$ddd = array();
		$dbe[] = "{name: '".$dbl['investname']."', data: [ $dbl[ddd] ]}";
		$dbk[] = 
		$dblist[] = $dbl;
	}
	$ok = implode(', ',$dbe);
	include template('diy:invest', 0, 'source/plugin/jninvest/template');
}
if ($_GET['do'] == 'invest'){
	if (($_GET['do'] == 'invest') && ($_G['mod'] == 'uplvl')){
		if($_GET['formhash'] == $_G['formhash']){
		if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
			if ($investexp < $investnext){
				showmessage('jninvest:upLvlFailed','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
			}else{
				$expdeduct = $investexp - $investnext;
				$levelup = $investlevel + 1;
				DB::query("UPDATE ".DB::table('game_jninvest_invest_user')." SET level = '".daddslashes($levelup)."', exp = '".daddslashes($expdeduct)."' WHERE uid = '$_G[uid]'");
				showmessage('jninvest:upLvlSuccess','plugin.php?id=jninvest:jninvest'.$mobilelink,array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime' => true));
			}
		}else{
			showmessage('jninvest:FormhashIncorrect','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
		}
	}
	$investid = dintval($_GET['investid']);
	if (($_GET['do'] == 'invest') && ($_G['mod'] == 'invest') && $investid > 0){
		if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
		$g_buyextHAHA = $_G['member']['extcredits'.$g_buyext]; //BUY EXTCREDITs
		$jifen = $_G['member']['extcredits2'];
		if ($investid == '0'){
			showmessage('jninvest:IDerror','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
		}
		if(submitcheck('submitinvestbuy')) {
			if(dintval($_GET['paymount']) == '999'){
				showmessage(lang('plugin/jninvest','invest_QTY999'),'',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
			}
			if (!$userinfo['id']){
				showmessage('jninvest:havenopenac','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
			}
			if($_GET['formhash'] == $_G['formhash']){
				$keyinmount = dintval($_GET['paymount']); //���ִ���
				$unitQTY = $keyinmount * 1000;
				$investcode = daddslashes($_GET['investcode']); //invest����
				$investid = dintval($_GET['investid']); //invest ID
				//$current = number_format($_GET['current'],3,'.',''); //��Ʊ��ǰ�۸�
				$qinbuy = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE investcode = '$investcode' AND id = '$investid'");
				$qinbuys = count($qinbuy);
				
				$current = number_format($qinbuy['current'],3,'.','');
				if ($qinbuy['status'] == '1'){
					if (!$userinfo['id']){
						showmessage('jninvest:havenopenac','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
					}
					if (preg_match ("/^([0-9]+)$/", $keyinmount)) { //if keyinamountΪ����
						$credits = $current * $keyinmount * 1000; //���򵥼�+���ִ���
						if($extcredits1 >= $credits){ //������ִ��ڵ�ǰ���򵥼�+���ִ���
							//investmentBUY($credits, $paycredit);
							$userinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest_user')." WHERE uid = '$_G[uid]'");
								
							$investlevel = $userinfo['level'];
							$investexp = $userinfo['exp'];
							$investnext = $investlevel * 100;
							$investshow = $investlevel * 10;
							$investexpplus = $investexp + $keyinmount;
							$investinhandplus = $userinfo['inhand'] + $keyinmount;
							$investinhand = ($investlevel * 20) - $userinfo['inhand'];

							//���� paymount = 100, ainhand = 10, plus = 100+10, inhand = 1*20-100.
							if ($keyinmount > $investinhand){
								showmessage('jninvest:invest_buyTnoEnough','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
							}
								
							//$queryInvestBuy = DB::query("SELECT * FROM ".DB::table('game_jninvest_invest_s')." WHERE investcode = '$investcode' AND uid = $_G[uid]"); //Query topup record
							$queryInvestBuy = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest_s')." WHERE investcode = '$investcode' AND uid = '".$_G['uid']."'");
							//$queryInvestBuyExt = count($queryInvestBuy);
							/*while($rowUserBuy = DB::fetch($queryInvestBuy)) {
								$investstatus = $rowUserBuy['status']; 
								$previousbuy =  $rowUserBuy['buymoney'];
								$previousunit = $rowUserBuy['unit'];
							}*/
							$investstatus = $queryInvestBuy['status']; 
							$previousbuy =  $queryInvestBuy['buymoney'];
							$previousunit = $queryInvestBuy['unit'];
								
							$queryInvestlist = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE investcode = '$investcode'");//Query invest list record
							
							$rowunitid = $queryInvestlist['id'];
							$rowunitforsales = $queryInvestlist['unit4sales'];

							if ($queryInvestlist['status'] == '0'){
								showmessage("jninvest:invest_noopen",'',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
							}
							if (!$queryInvestBuy['id']){ //if not exist buy
								$deductunit = $rowunitforsales - $unitQTY;
								if ($deductunit < 0){
									showmessage("jninvest:invest_habis",'',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
								}else{
									$extcredits = "extcredits".$g_buyext; //�������
									$extown = array();
									$extown[$extcredits] = '-'.$credits;
									updatecreditbyaction('', $_G['uid'], $extown);
									DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_ulog')." (uid,investid,action,unit,timestamp) VALUES ('$_G[uid]', '".daddslashes($rowunitid)."', '1', '".daddslashes($unitQTY)."', '$_G[timestamp]')");
									DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET unit4sales = '".daddslashes($deductunit)."'  WHERE investcode = '$investcode'");
									DB::query("UPDATE ".DB::table('game_jninvest_invest_user')." SET exp = '".daddslashes($investexpplus)."', inhand ='".daddslashes($investinhandplus)."'  WHERE uid = '$_G[uid]'");
									DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_s')." (uid,investcode,unit,buymoney,timestamp,status) VALUES ( '$_G[uid]', '".daddslashes($investcode)."', '".daddslashes($unitQTY)."', '".daddslashes($current)."', '$_G[timestamp]', '1')");
									showmessage('jninvest:ShopBuySuccess','plugin.php?id=jninvest:jninvest'.$mobilelink,array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime' => true));
								}
							}else{ //if exist buy 
								if ($investstatus == '1'){  //if exist buy and valid then borata buy price
									$currentbuy = $current;
									$currentunit = $unitQTY;
									$deductunit = $rowunitforsales - $unitQTY;
									$totalunit = $previousunit + $unitQTY; //���е�����
									$boratabuy = (($previousbuy * $previousunit) + ($current * $unitQTY)) / $totalunit ;
									if ($deductunit < 0){
										showmessage("jninvest:invest_habis",'',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
									}
									
									$extcredits = "extcredits".$g_buyext; //�������
									$extown = array();
									$extown[$extcredits] = '-'.$credits;
									updatecreditbyaction('', $_G['uid'], $extown);
									DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_ulog')." (uid,investid,action,unit,timestamp) VALUES ('".$_G['uid']."', '".daddslashes($rowunitid)."', '1', '".daddslashes($unitQTY)."', '".$_G['timestamp']."')");
									DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET unit4sales = '".daddslashes($deductunit)."'  WHERE investcode = '$investcode'");
									DB::query("UPDATE ".DB::table('game_jninvest_invest_user')." SET exp = '".daddslashes($investexpplus)."', inhand ='".daddslashes($investinhandplus)."'  WHERE uid = '".$_G['uid']."'");
									DB::query("UPDATE ".DB::table('game_jninvest_invest_s')." SET unit = '".daddslashes($totalunit)."', buymoney = '".daddslashes($boratabuy)."', timestamp = '".$_G['timestamp']."' WHERE uid = '".$_G['uid']."' AND investcode = '$investcode'");
									showmessage('jninvest:ShopBuySuccess','plugin.php?id=jninvest:jninvest'.$mobilelink,array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime' => true));
								}elseif ($investstatus == '0'){  //if exist buy but no valid, add current buy price
									$currentbuy = $current;
									$currentunit = $unitQTY;
									$deductunit = $rowunitforsales - $unitQTY;
									if ($deductunit < 0){
										showmessage("jninvest:invest_habis",'',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
									}else{
										$extcredits = "extcredits".$g_buyext; //�������
										$extown = array();
										$extown[$extcredits] = '-'.$credits;
										updatecreditbyaction('', $_G['uid'], $extown);
										DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_ulog')." (uid,investid,action,unit,timestamp) VALUES ('$_G[uid]', '".daddslashes($rowunitid)."', '1', '".daddslashes($unitQTY)."', '$_G[timestamp]')");
										DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET unit4sales = '".daddslashes($deductunit)."'  WHERE investcode = '$investcode'");
										DB::query("UPDATE ".DB::table('game_jninvest_invest_user')." SET exp = '".daddslashes($investexpplus)."', inhand ='".daddslashes($investinhandplus)."'  WHERE uid = '$_G[uid]'");
										DB::query("UPDATE ".DB::table('game_jninvest_invest_s')." SET unit = '".daddslashes($unitQTY)."', buymoney = '".daddslashes($current)."', timestamp = '$_G[timestamp]', status = '1'  WHERE uid = '$_G[uid]' AND investcode = '$investcode'");
										showmessage('jninvest:ShopBuySuccess','plugin.php?id=jninvest:jninvest'.$mobilelink,array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime' => true));
									}
								}else{
									showmessage("error",'',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
								};
							}//END if not exist buy
						}else{
							showmessage('jninvest:ShopMoneyNoEnough','',array('moneytitle'=>$g_buyextname),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
						};
					}else{
						showmessage('jninvest:AmountIncorrect','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
					}
				}else{
					showmessage('jninvest:invest_noopen','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
				}
			}else{
				showmessage('jninvest:FormhashIncorrect','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
			}
		}else{
			showmessage('jninvest:FormhashIncorrect','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
		}
	}elseif (($_GET['do'] == 'invest') && dintval($_GET['investid'] > 0)){
		if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
		$investid = dintval($_GET['investid']);
		$rowInvestBuy = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE id = ".$investid.""); //Query invest record

		$rowInvestBuy['times'] = date("Y-m-d H:i",($rowInvestBuy['timestamp']));
		if ($rowInvestBuy['current'] > $rowInvestBuy['last']){
			$rowInvestBuy['beza'] = '<font color="red">+'.number_format($rowInvestBuy['current'] - $rowInvestBuy['last'],'3','.',',').'</font>';
		}elseif ($rowInvestBuy['current'] < $rowInvestBuy['last']){
			$rowInvestBuy['beza'] = '<font color="#00CC00">-'.number_format($rowInvestBuy['last']-$rowInvestBuy['current'],'3','.',',').'</font>';
		}else{
			$rowInvestBuy['beza'] = '+0.000';
		}
		if ($rowInvestBuy['current'] > $rowInvestBuy['yesterday']){
			$rowInvestBuy['bezaallday'] = '<font color="red">+'.number_format($rowInvestBuy['current']-$rowInvestBuy['yesterday'],'3','.',',').'</font>';
		}elseif ($rowInvestBuy['current'] < $rowInvestBuy['yesterday']){
			$rowInvestBuy['bezaallday'] = '<font color="#00CC00">-'.number_format($rowInvestBuy['yesterday']-$rowInvestBuy['current'],'3','.',',').'</font>';
		}else{
			$rowInvestBuy['bezaallday'] = '+0.000';
		}
		$user_invest_selectlist[] = $rowInvestBuy;

		include template('jninvest:invest_buy');
	}elseif (($_GET['do'] == 'invest') && ($_G['mod'] == 'sell')){
		if (!$_GET['sellinvestid']){
			showmessage('jninvest:IDerror','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
		}else{
			if ($_GET['formhash'] == $_G['formhash']){
				//����Ǯ��status 0, ����unit4sales
				$investcode = daddslashes($_GET['sellinvestid']);
				$queryInvestlist = DB::query("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE investcode = '$investcode'");//Query invest list record
				while($rowInvestlist = DB::fetch($queryInvestlist)) {
					$rowunitid = $rowInvestlist['id'];
					$rowunitforsales = $rowInvestlist['unit4sales'];
					$rowcurrent = $rowInvestlist['current'];
				};
				$rowUserBuy = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest_s')." WHERE investcode = '$investcode' AND uid = '".$_G['uid']."' AND status = 1"); //Query topup record
				//$queryInvestBuyExt = count($rowUserBuy);
				
				$investstatus = $rowUserBuy['status']; 
				$previousbuy =  $rowUserBuy['buymoney'];
				$previousunit = $rowUserBuy['unit'];

				//�ǵ��ж�statusҪ����1
				$moneyadd = $moneyN + ($rowcurrent * $previousunit);
				$total4sales = $rowunitforsales + $previousunit;
				if (!$userinfo['id']){
					showmessage('jninvest:havenopenac','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
				}
				if(!$rowUserBuy['id']){
					showmessage('jninvest:invest_nosuch',array(),array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
				}else{
					$credits1 = $rowcurrent * $previousunit;
					$fees = $credits1 * $g_sellfee;
					$credits = $credits1 - dintval($fees);
					$extcreditssell = 'extcredits'.$g_sellext;
					$extown = array();
					$extown[$extcreditssell] = '+'.$credits;
					updatecreditbyaction('', $_G['uid'], $extown);
					DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_ulog')." (uid,investid,action,unit,timestamp) VALUES ('$_G[uid]', '".daddslashes($rowunitid)."', '2', '".daddslashes($previousunit)."', '$_G[timestamp]')");
					DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET unit4sales = '".daddslashes($total4sales)."'  WHERE investcode = '$investcode'");
					DB::query("UPDATE ".DB::table('game_jninvest_invest_s')." SET status = '0' WHERE investcode = '$investcode' AND uid = '$_G[uid]'");
					showmessage('jninvest:sellsuccess','plugin.php?id=jninvest:jninvest'.$mobilelink,array('previousunit'=>$previousunit,'credits'=>$credits,'selltitle'=>$g_sellextname),array('showdialog' => 1, 'showmsg' => true, 'locationtime' => true));
				}
			}else{
				showmessage('jninvest:FormhashIncorrect','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
			}
		}
	}else{
		showmessage('jninvest:unknowerror','',array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'error'));
	}
};
//Ͷ�ʽ���
?>