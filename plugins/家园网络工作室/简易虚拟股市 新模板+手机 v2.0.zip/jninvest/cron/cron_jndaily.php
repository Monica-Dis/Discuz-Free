<?php
//cronname:JNinvest
//week:
//day:
//hour:
//minute:0,5,10,15,20,25,30,35,40,45,50,55

if(!defined('IN_DISCUZ')){
	exit('Access Denied');
}

$queryInvestDaily = DB::query("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE status = '1'");
while($rowInvestDaily = DB::fetch($queryInvestDaily)) {
	$aditudtime = date("Y-m-d",($_G['timestamp']));
	$aditudtime1 = strtotime($aditudtime);
	$updatetime['udtime'] = $rowInvestDaily['udtime'] + 86400;
	if($rowInvestDaily['udtime'] == '0'){
		DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET udtime ='$aditudtime1' WHERE id = '$rowInvestDaily[id]'");
	}elseif($rowInvestDaily['udtime'] > '1'){
		if($_G['timestamp'] > $updatetime['udtime']){
			DB::query("UPDATE ".DB::table('game_jninvest_invest_user')." SET inhand = '0'");
			$queryInvest = DB::query("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE status = '1'");
			while($rowInvest = DB::fetch($queryInvest)) {
				DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET yesterday = '$rowInvest[current]', udtime = '$updatetime[udtime]' WHERE id = '$rowInvest[id]'");
			}
		};
	}else{
		$queryInvestDaily1 = DB::query("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE status = '1'");
	};
}

$queryInvest = DB::query("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE status = '1'");
while($rowInvest = DB::fetch($queryInvest)) {
	$rowInvest['last'] = $rowInvest['current'];
	$random['chances'] = mt_rand(0,$rowInvest['chances']*1000) / 1000; 
	$jiajian = rand(1,2);
	if ($rowInvest['udstatus'] == '1'){
		$rowInvest['current'] = $rowInvest['current'] + $random['chances'];
		if ($rowInvest['max'] == '0.000'){ 
			DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[current]' WHERE id = '$rowInvest[id]'");
			DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[current]','$random[chances]',$_G[timestamp],'1')");
		}elseif ($rowInvest['current'] > $rowInvest['max']){
			DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[max]' WHERE id = '$rowInvest[id]'");
			DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[max]','$random[chances]',$_G[timestamp],'1')");
		}else{ 
			DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[current]' WHERE id = '$rowInvest[id]'");
			DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[current]','$random[chances]',$_G[timestamp],'1')");
		}
	}elseif ($rowInvest['udstatus'] == '2'){
		$rowInvest['current'] = $rowInvest['current'] - $random['chances'];
		if ($rowInvest['min'] == '0.000'){ 
			if ($rowInvest['current'] < 0){ 
				DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '0.000' WHERE id = '$rowInvest[id]'");
				DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','0.000','$random[chances]',$_G[timestamp],'2')");
			}else{
				DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[current]' WHERE id = '$rowInvest[id]'");
				DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[current]','$random[chances]',$_G[timestamp],'2')");
			}
		}elseif ($rowInvest['current'] < $rowInvest['min']){ 
			DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[min]' WHERE id = '$rowInvest[id]'");
			DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[min]','$random[chances]',$_G[timestamp],'2')");
		}else{ 
			DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[current]' WHERE id = '$rowInvest[id]'");
			DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[current]','$random[chances]',$_G[timestamp],'2')");
		}
	}else{
		if ($rowInvest['udstatus'] == '3'){
			if ($jiajian == 1){
				$rowInvest['current'] = $rowInvest['current'] + $random['chances'];
				if ($rowInvest['max'] == '0.000'){ 
					DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[current]' WHERE id = '$rowInvest[id]'");
					DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[current]','$random[chances]',$_G[timestamp],'1')");
				}elseif ($rowInvest['current'] > $rowInvest['max']){ 
					DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[max]' WHERE id = '$rowInvest[id]'");
					DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[max]','$random[chances]',$_G[timestamp],'1')");
				}else{ 
					DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[current]' WHERE id = '$rowInvest[id]'");
					DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[current]','$random[chances]',$_G[timestamp],'1')");
				}
			}elseif ($jiajian == 2){
				$rowInvest['current'] = $rowInvest['current'] - $random['chances'];
				if ($rowInvest['min'] == '0.000'){ 
					if ($rowInvest['current'] < 0){ 
						DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '0.000' WHERE id = '$rowInvest[id]'");
						DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','0.000','$random[chances]',$_G[timestamp],'2')");
					}else{
						DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[current]' WHERE id = '$rowInvest[id]'");
						DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[current]','$random[chances]',$_G[timestamp],'2')");
					}
				}elseif ($rowInvest['current'] < $rowInvest['min']){ 
					DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[min]' WHERE id = '$rowInvest[id]'");
					DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[min]','$random[chances]',$_G[timestamp],'2')");
				}else{ 
					DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET last = '$rowInvest[last]', current = '$rowInvest[current]' WHERE id = '$rowInvest[id]'");
					DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$rowInvest[investcode]','$rowInvest[current]','$random[chances]',$_G[timestamp],'2')");
				}
			}else{
				echo "error";
			}
		}
	}
}
//From: dis'.'m.tao'.'bao.com
?>