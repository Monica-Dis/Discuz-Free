<?php
/*
 *	Author: Goldwar
 *	Last modified: 2015-12-08 17:42
 *	Filename: upgrade.php
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}
/**V1.10* */
/*
runquery($sql);
 */
$finish = TRUE; /*dism��taobao��com*/
?>