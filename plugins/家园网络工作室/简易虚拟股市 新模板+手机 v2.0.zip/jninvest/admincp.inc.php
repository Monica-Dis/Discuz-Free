<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
global $_G;
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
$config=$_G['cache']['plugin']['jninvest'];
$g_adminids=explode('|',$config['adminuid']);//����ԱȨ��
$g_buyext = $config['buyext'];
$g_sellext = $config['sellext'];
if (!in_array($_G['uid'],$g_adminids)){
	showmessage('jninvest:NotAdmin');
}
if($_G['mod'] == 'updateinvest'){
	if(submitcheck('submitinvestupdate')) {
		if($_GET['formhash'] == $_G['formhash']){
			$uditname = daddslashes($_GET['investname']);
			$uditcurrent = number_format($_GET['investcurrent'],3,'.','');
			$uditunit4sales = dintval($_GET['unit4sales']);
			$udityesterday = number_format($_GET['yesterday'],3,'.','');
			$uditchances = number_format($_GET['chances'],3,'.','');
			$uditmax = number_format($_GET['max'],3,'.','');
			$uditmin = number_format($_GET['min'],3,'.','');
			$uditid = dintval($_GET['investonlyid']);
			$uditudstatus = dintval($_GET['udstatus']);
			$uditstatus = dintval($_GET['investstatus']);
			if ((!$uditname) || (!$uditcurrent) || (!$udityesterday) || (!$uditmax) || (!$uditchances) || (!$uditmin) || (!$uditudstatus) || (!$uditstatus)){
				showmessage('jninvest:cpinputerror');
			}
			if ($uditid > 0){
				DB::query("UPDATE ".DB::table('game_jninvest_invest')." SET investname = '".daddslashes($uditname)."', current = '".daddslashes($uditcurrent)."', unit4sales = '".daddslashes($uditunit4sales)."', yesterday = '".daddslashes($udityesterday)."', max = '".daddslashes($uditmax)."', min = '".daddslashes($uditmin)."', chances = '".daddslashes($uditchances)."', udstatus = '".daddslashes($uditudstatus)."', status = '".daddslashes($uditstatus)."' WHERE id = '$uditid'");
				showmessage('jninvest:BankSettingSuccess','plugin.php?id=jninvest:admincp');
			}else{
				showmessage('jninvest:FormhashIncorrect');
			}
			showmessage('jninvest:FormhashIncorrect');
		}else{
			showmessage('jninvest:FormhashIncorrect');
		}	
	}else{
		showmessage('jninvest:FormhashIncorrect');
	};
};
if(!$_GET['do']){
	$page = $_G['page'];
	$tpp = 100;
	$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jninvest_invest'));
	if(@ceil($total/$tpp) < $page) 	$page = 1;
	$start_limit = ($page - 1) * $tpp;
	
	$query = DB::query("SELECT pl.*, cm.username FROM ".DB::table('game_jninvest_invest')." pl LEFT JOIN ".DB::table('common_member')." cm ON pl.uid=cm.uid ORDER BY id desc limit {$start_limit},{$tpp}");
	while($row = DB::fetch($query)) {
		$tid[] = $row['tid'];
		$row['times'] = date("Y-m-d H:i",($row['firstlogin']));
		$user_invest_list[] = $row;
	}
	array_multisort($tid, SORT_ASC, $user_invest_list);
	//multipage
	$multipage = multi($total, $tpp, $page, "plugin.php?id=jninvest:admincp", $_G['setting']['threadmaxpages']);
	include template('jninvest:admincp');
	exit;
}
if($_GET['do'] == 'invest'){
	$investIDQ = dintval($_GET['investid']);
	if(isset($investIDQ)){
		$query = DB::fetch_all("SELECT pl.*, cm.username FROM ".DB::table('game_jninvest_invest')." pl LEFT JOIN ".DB::table('common_member')." cm ON pl.uid=cm.uid WHERE pl.id = '$investIDQ'");
		foreach($query as $row) {
			$Qinvestid = $row['id'];
			$Qinvestuid = $row['uid'];
			$Qinvestname = $row['investname'];
			$Qinvestcode = $row['investcode'];
			$Qinvestowner = $row['username'];
			$Qinvestcurrent = $row['current'];
			$Qinvestyesterday = $row['yesterday'];
			$Qinvestchances = $row['chances'];
			$Qinvestunit4sales = $row['unit4sales'];
			$Qinvestmax = $row['max'];
			$Qinvestmin = $row['min'];
			$Qinvestudstatus = $row['udstatus'];
			$Qinveststatus = $row['status'];
		}
		$cq = count($query);
		if($cq == '0') {
			showmessage('jninvest:IDerror');
		}else{
			include template('jninvest:admincp_investupdate');
			exit;
		}
	}
	exit;
};
if (($_GET['do'] == 'investholder') && isset($_GET['investcode'])){
	$investcode = daddslashes($_GET['investcode']);
	$page = $_G['page'];
	$tpp = 100;
	$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jninvest_invest_s')." WHERE investcode = '$investcode' AND status = '1'");
	if(@ceil($total/$tpp) < $page) 	$page = 1;
	$start_limit = ($page - 1) * $tpp;
	
	$query = DB::fetch_all("SELECT pl.*, cm.username FROM ".DB::table('game_jninvest_invest_s')." pl LEFT JOIN ".DB::table('common_member')." cm ON pl.uid=cm.uid WHERE pl.investcode = '$investcode' AND pl.status = 1 ORDER BY id desc limit {$start_limit},{$tpp}");
	foreach($query as $row){
		$row['timestamp'] = date("Y-m-d H:i:s",($row['timestamp']));
		$user_invest_holder[] = $row;
	}
	$qinvestor = count($query);
	array_multisort($tid, SORT_ASC, $user_invest_holder);
	//multipage
	$multipage = multi($total, $tpp, $page, "plugin.php?id=jninvest:admincp&do=investholder", $_G['setting']['threadmaxpages']);
	include template('jninvest:admincp_investholder');
	exit;
}
if (($_G['mod'] == 'investadd') && ($_GET['do'] == 'investadd')) {
	if(submitcheck('submitinvestadd')) {
		if($_GET['formhash'] == $_G['formhash']){
			$aditname = daddslashes($_GET['investname']);
			$aditcode = daddslashes($_GET['investcode']);
			$aditprice = number_format($_GET['investprice'],3,'.','');
			$adchances = number_format($_GET['investchances'],3,'.','');
			$aditunit4sales = dintval($_GET['investunit4sales']);
			$aditmax = number_format($_GET['investmax'],3,'.','');
			$aditmin = number_format($_GET['investmin'],3,'.','');
			$aditudtime = date("Y-m-d",($_G['timestamp']));
			$aditudtime1 = strtotime($aditudtime);
			if ((!$aditname) || (!$aditcode) || (!$aditprice) || (!$aditunit4sales) || (!$aditmax) || (!$adchances) || (!$aditmin)){
				showmessage('jninvest:cpinputerror');
			}
			$query = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE investcode = '$aditcode'");
			//$qcount = count($query);
			if(!$query['id']){
				//��������������
				$dbk = DB::fetch_first("SELECT * FROM ".DB::table('game_jninvest_invest')." WHERE status = '1' ORDER BY id ASC LIMIT 1 ");
				$dbc = DB::fetch_all("SELECT * FROM ".DB::table('game_jninvest_invest_log')." WHERE investcode = '$dbk[investcode]' ORDER BY timestamp DESC LIMIT 20 ");
				foreach($dbc as $dd){
					DB::query("REPLACE INTO ".DB::table('game_jninvest_invest_log')." (investcode,current,chances,timestamp,status) VALUES ('$aditcode','$aditprice','$adchances','$dd[timestamp]','1') ");
				}
				DB::query("REPLACE INTO ".DB::table('game_jninvest_invest')." (timestamp,investname,investcode,current,last,yesterday,chances,min,max,unit4sales,status,uid,udstatus,udtime) VALUES ('$_G[timestamp]','".daddslashes($aditname)."','".daddslashes($aditcode)."','".daddslashes($aditprice)."','".daddslashes($aditprice)."','".daddslashes($aditprice)."','".daddslashes($adchances)."','".daddslashes($aditmin)."','".daddslashes($aditmax)."','".daddslashes($aditunit4sales)."','1','0','3','".daddslashes($aditudtime1)."')");
				showmessage('jninvest:invest_addsuccess','plugin.php?id=jninvest:admincp',array(),array('showdialog' => 1, 'showmsg' => true, 'locationtime' => true, 'alert' => 'right'));
			}else{
				showmessage('jninvest:invest_codeexist','',array(),array('showdialog' => 1, 'showmsg' => true, 'locationtime' => true, 'alert' => 'error'));
			}
		}else{
			showmessage('jninvest:FormhashIncorrect');
		}
	}else{
		showmessage('jninvest:FormhashIncorrect');
	};
}
if($_GET['do'] == 'add'){
	include template('jninvest:admincp_investadd');
	exit;
}
include template('jninvest:admincp');
?>