<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_game_jninvest_invest` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` int(11) NOT NULL,
  `investname` text NOT NULL,
  `investcode` text NOT NULL,
  `current` decimal(10,3) NOT NULL,
  `last` decimal(10,3) NOT NULL,
  `yesterday` decimal(10,3) NOT NULL,
  `chances` decimal(8,3) NOT NULL,
  `min` decimal(11,3) NOT NULL,
  `max` decimal(11,3) NOT NULL,
  `unit4sales` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `udstatus` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `udtime` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jninvest_invest_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `investcode` text NOT NULL,
  `current` decimal(10,3) NOT NULL,
  `chances` decimal(10,3) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jninvest_invest_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `exp` int(11) NOT NULL,
  `inhand` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jninvest_invest_s` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `investcode` text NOT NULL,
  `unit` int(11) NOT NULL,
  `buymoney` decimal(11,3) NOT NULL,
  `timestamp` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

CREATE TABLE IF NOT EXISTS `pre_game_jninvest_invest_ulog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `investid` int(11) NOT NULL,
  `action` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  `timestamp` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1;

EOF;

runquery($sql);

$finish = TRUE; /*dism��taobao��com*/
?>