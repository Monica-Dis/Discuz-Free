<?php
//cronname:Jnmorning
//week:
//day:
//hour:00
//minute:00

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
loadcache('plugin');
$jnconfig = $_G['cache']['plugin']['jnmorning'];

DB::query("TRUNCATE TABLE ".DB::table('game_jnmorning_tlog')."");
DB::query("UPDATE ".DB::table('game_jnmorning_land')." SET yesjoin = todayjoin, todayjoin = '', yesdaybuy = todaybuy, todaybuy = ''");
?>