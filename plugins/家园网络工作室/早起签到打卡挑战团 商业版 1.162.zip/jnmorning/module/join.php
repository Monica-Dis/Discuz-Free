<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if($_GET['do'] == 'join'){
	$lid = dintval($_GET['lid']);
	if($lid>0){
		$clinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_land')." WHERE lid = '$lid'");
		if($clinfo['lid']>0){
			if($_GET['formhash'] == $_G['formhash']){
				require DISCUZ_ROOT.'source/plugin/'.$jn.'/tlog.inc.php';
				$convert = '0.01';
				$jnc['opentime'] = $clinfo['opentime'];
				$jnc['closetime'] = $clinfo['closetime'];
				$todayopen = date("Y-m-d",$_G['timestamp']);
				$todaytime = strtotime($todayopen);
				$tdopen = strtotime($todayopen.' '.$jnc['opentime']);
				$tdclose = strtotime($todayopen.' '.$jnc['closetime']);
				$jnc['paymount'] = $clinfo['lamount'];
				if(!$clinfo['refundjf']){
					$clinfo['refundjf'] = $clinfo['buyjf'];
				}
				$ctitle = $_G['setting']['extcredits'][$clinfo['refundjf']]['title'];
				$btitle = $_G['setting']['extcredits'][$clinfo['bonusjf']]['title'];
				if($_G['timestamp'] > $tdclose){ //����Ǹ�lid��ʱ��3����ʼˢ�£�����Ҫ�Ȳ���lid��ʱ��3
					//�����ܲ�������
					$check = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_linfo')." WHERE opendate = '$tdopen' AND lid = '$lid'");
					if(!$check['rid']){
						$joinall = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_join')." WHERE createdate = '$tdopen' AND bot = 0"); //�ܲ�������
						$qdall = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_join')." WHERE createdate = '$tdopen' AND bot = 0 AND qdtime > 0"); //��ǩ������
						$beza = $joinall-$qdall;
						$thistime = $beza*$clinfo['lamount'];
						if($clinfo['ltype'] == '1'){ //���
							if($clinfo['sitecharge']>0){
								$totalprice = $beza*$clinfo['lamount'] - ($beza*$clinfo['lamount']*$clinfo['sitecharge']*$convert);
								$sitecharge = $beza*$clinfo['lamount']*$clinfo['sitecharge']*$convert;
							}else{
								$totalprice = $beza*$clinfo['lamount'];
							}
							if($clinfo['xtrabonus']>0){
								$totalprice = $totalprice+$clinfo['xtrabonus']; //����;
							}
							$rand = array();
							for($x=0;$x<$qdall;$x++){
								$rand[$x] = mt_rand(1,100);
								$total = $total+$rand[$x];
							}
						}else{ //����
							if($clinfo['sitecharge']>0){//ϵͳ���
								$prize = floor(((($beza*$clinfo['lamount']) - ($beza * $clinfo['lamount'] * $clinfo['sitecharge'] * $convert)) + $clinfo['xtrabonus'])/$qdall); //sitecharge amount
								$sitecharge = $beza*$clinfo['lamount']*$clinfo['sitecharge']*$convert;
								$totalprice = ((($beza*$clinfo['lamount']) - ($beza * $clinfo['lamount'] * $clinfo['sitecharge'] * $convert)) + $clinfo['xtrabonus']);
								//$prize = $prize+$clinfo['xtrabonus'];//����
							}else{
								$prize = floor((($beza*$clinfo['lamount'])+$clinfo['xtrabonus'])/$qdall); //���ָ������û�
								$totalprice = floor((($beza*$clinfo['lamount'])+$clinfo['xtrabonus']));
							}
						}
						if(!$sitecharge){
							$sitecharge = 0;
						}
						/*
						Ҫ���� ȫվ�˴Σ��ܻ��ּ�¼���ͻ��ּ�¼��
						
						*/
						$amountadd = DB::fetch_all("SELECT * FROM ".DB::table('game_jnmorning_join')." WHERE lid = '$lid' AND createdate = '$tdopen' AND bot = 0");
						$x = 0;
						foreach($amountadd as $amt){
							if($amt['qdtime'] > 0){ //��ǩ������
								$landinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_land')." WHERE lid = '$lid'");
								if($landinfo['ltype'] == '1'){
									$prize = floor(($rand[$x]/$total)*$totalprice); //���ת��percent
								}
								if(!$landinfo['refundjf']){
									$landinfo['refundjf'] = $landinfo['buyjf'];
									
								}
									
								$searchuser = DB::fetch_first("SELECT * FROM ".DB::table('common_member_count')." WHERE uid = '$amt[uid]'");
								$cjifen = $searchuser['extcredits'.$landinfo['refundjf']]; //getuserprofile('extcredits'.$landinfo['buyjf']);
								$bjifen = $searchuser['extcredits'.$landinfo['bonusjf']]; //getuserprofile('extcredits'.$landinfo['bonusjf']);
								
								$tdopenlog = date("Y-m-d",$tdopen);
								if($landinfo['refundjf'] == $landinfo['bonusjf']){
									$add = ($amt['amount']*$landinfo['lamount'])+$prize;
									$creditsarray['extcredits'.$landinfo['refundjf']] = '+'.$add;
									$bonusadd = $cjifen+$add;
									
									updatemembercount($amt['uid'], $creditsarray, true, '', 0, '',$jnc['title'],lang("plugin/$jn","a010").date("Y-m-d",($tdopen)).lang("plugin/$jn","a011").$landinfo['ltitle'].lang("plugin/$jn","a012").$prize.$ctitle.lang("plugin/$jn","a013"));
									$creditsarray = array();
									
									$logdata['logdesc'] = lang("plugin/$jn","a013")." $landinfo[ltitle] ($tdopenlog), ".lang("plugin/$jn","a035")." $ctitle (+$prize) $cjifen -> $bonusadd";
								}else{
									$add = $cjifen+($amt['amount']*$landinfo['lamount']);
									$bonusadd = $bjifen+$prize;

									$creditsarray['extcredits'.$landinfo['refundjf']] = '+'.($amt['amount']*$jnc['paymount']);
									updatemembercount($amt['uid'], $creditsarray, true, '', 0, '',$jnc['title'],lang("plugin/$jn","a010").date("Y-m-d",($tdopen)).lang("plugin/$jn","a011").$landinfo['ltitle'].lang("plugin/$jn","a018").$landinfo['lamount'].$ctitle);
									
									$creditsarrayb['extcredits'.$landinfo['bonusjf']] = '+'.($prize);
									updatemembercount($amt['uid'], $creditsarrayb, true, '', 0, '',$jnc['title'],lang("plugin/$jn","a010").date("Y-m-d",($tdopen)).lang("plugin/$jn","a011").$landinfo['ltitle'].lang("plugin/$jn","a019").$prize.$btitle.lang("plugin/$jn","a013"));
									
									$creditsarray = array();
									$creditsarrayb = array();
									
									$logdata['logdesc'] = lang("plugin/$jn","a013")." $landinfo[ltitle] ($tdopenlog), ".lang("plugin/$jn","a035")." $ctitle (+$jnc[paymount]) $cjifen -> $add , $btitle (+$prize) $bjifen -> $bonusadd ";
								}
								
								$earnttadd = $amt['earntt']+$prize; //���ӻ�ý��

								$amtuserinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_user')." WHERE uid = '$amt[uid]'");
								C::t('#jnmorning#jnmorning_user')->update($amtuserinfo['mid'],array('earntt'=>$earnttadd)); //���Ӹ����ܼ�¼

								$lidamtuserinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_userlid')." WHERE uid = '$amt[uid]' AND lid = '$lid'");
								C::t('#jnmorning#jnmorning_userlid')->update($lidamtuserinfo['mid'],array('earntt'=>$earnttadd)); //���Ӹ��˸�lid�ܼ�¼

								C::t('#jnmorning#jnmorning_join')->update($amt['jid'],array('lucky'=>$prize));
								
								$amtbtitle = $_G['setting']['extcredits'][$amt['bonusjf']]['title']; //�ֺ�
								$logdata['uid'] = $amt['uid'];
								$logdata['createtime'] = $_G['timestamp'];
								//$logdata['logdesc'] = lang("plugin/$jn","a013")." $landinfo[ltitle] ($tdopenlog), ".lang("plugin/$jn","a035")." $ctitle (+$jnc[paymount]) $cjifen -> $add , $btitle (+$prize) $bjifen -> $bonusadd ";
								$logdata['acdo'] = 2;
								C::t('#jnmorning#jnmorning_logsys')->insert($logdata);
								$x++;
							}
						}
						$countbot = 0;//DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_join')." WHERE lid = '$lid' AND bot = '1'"); BOT SETTING
						$sysinfo['totalearnppl'] = $sysinfo['totalearnppl']+$thistime+$countbot;
						DB::query("UPDATE ".DB::table('game_jnmorning_sysinfo')." SET totalearnppl = '$sysinfo[totalearnppl]' WHERE sid = '1'");
						DB::query("REPLACE INTO ".DB::table('game_jnmorning_linfo')." (lid,opendate) VALUES ('$lid','$tdopen') ");
						
						//��̨����ϵͳlog, չʾ��վ�ܷ���
						$logdata['uid'] = 0; //0��ϵͳ
						$logdata['createtime'] = $_G['timestamp'];
						$logdata['logdesc'] = lang("plugin/$jn","a013")." $landinfo[ltitle] ($tdopenlog), ".lang("plugin/$jn","a036")." $x ".lang("plugin/$jn","a037")." $sitecharge $btitle , ".lang("plugin/$jn","a038")." $totalprice $btitle ".lang("plugin/$jn","a013");
						$logdata['acdo'] = 2;
						C::t('#jnmorning#jnmorning_logsys')->insert($logdata);
					}
				}
				$copen = $tdopen+86400; //����ǩ����ʼʱ��
				$cclose = $tdclose+86400; //����ǩ������ʱ��
				$cuser = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_join')." WHERE uid = '$_G[uid]' AND createdate = '$copen' AND closedate = '$cclose' AND lid = '$lid'"); //�Ƿ���������ʱ��
				//showmessage('aaa');
				if(!$cuser['jid']){ //û�н���Ĳ����¼, ���Բ���
					$tjifen = getuserprofile('extcredits'.$clinfo['buyjf']);
					if($tjifen>$jnc['paymount']){
						$creditsarray['extcredits'.$clinfo['buyjf']] = '-'.$jnc['paymount'];
						updatemembercount($_G[uid], $creditsarray, true, '', 0, '',$jnc['title'],lang("plugin/$jn","a010").date("Y-m-d",($_G['timestamp']+86400)).lang("plugin/$jn","a011").$clinfo['ltitle']);
						$jfdd = $tjifen-$jnc['paymount'];
						
						$userinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_user')." WHERE uid = '$_G[uid]'");
						
						$joinadd = $userinfo['ttjoin']+($jnc['paymount']);
						//����Ƿ��в�������ҷ������߽���
						$bonuslid = explode(',',$userinfo['bonuslid']);
						if(!in_array($lid,$bonuslid)){
							$creditsarray = array();
							$countbonuslid = count($bonuslid);
							//showmessage($countbonuslid);
							$downlinebonus = explode(',',$clinfo['downlinebonus']);
							if($userinfo['upline'] > 0 && $downlinebonus[0]>0 && $downlinebonus[1]>0){//1������
								$creditsarray['extcredits'.$downlinebonus[1]] = '+'.$downlinebonus[0];
								updatemembercount($userinfo['upline'], $creditsarray, true, '', 0, '',$jnc['title'],'1'.lang("plugin/$jn","a041").$_G['username'].lang("plugin/$jn","a042").$clinfo['ltitle'].lang("plugin/$jn","a043"));
								$creditsarray = array();
							}
							if($userinfo['upline2'] > 0 && $downlinebonus[2]>0 && $downlinebonus[3]>0){//2������
								$creditsarray['extcredits'.$downlinebonus[3]] = '+'.$downlinebonus[2];
								updatemembercount($userinfo['upline2'], $creditsarray, true, '', 0, '',$jnc['title'],'2'.lang("plugin/$jn","a041").$_G['username'].lang("plugin/$jn","a042").$clinfo['ltitle'].lang("plugin/$jn","a043"));
								$creditsarray = array();
							}
							if($userinfo['upline3'] > 0 && $downlinebonus[4]>0 && $downlinebonus[5]>0){//3������
								$creditsarray['extcredits'.$downlinebonus[5]] = '+'.$downlinebonus[4];
								updatemembercount($userinfo['upline3'], $creditsarray, true, '', 0, '',$jnc['title'],'3'.lang("plugin/$jn","a041").$_G['username'].lang("plugin/$jn","a042").$clinfo['ltitle'].lang("plugin/$jn","a043"));
								$creditsarray = array();
							}
							$bonuslid[($countbonuslid+1)] = $lid;
						}
						$finalbonuslid = implode(',',$bonuslid);
						C::t('#jnmorning#jnmorning_user')->update($userinfo['mid'],array('ttjoin'=>$joinadd,'bonuslid'=>$finalbonuslid)); //���¸����ܼ�¼
						
						$liduserinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_userlid')." WHERE uid = '$amt[uid]' AND lid = '$lid'");
						if($liduserinfo['mid'] > 0){
							$joinadd = $liduserinfo['ttjoin']+($jnc['paymount']);
							C::t('#jnmorning#jnmorning_userlid')->update($liduserinfo['mid'],array('ttjoin'=>$joinadd)); //���Ӹ��˸�lid�ܼ�¼
						}else{
							$datai['ttjoin'] = $jnc['paymount'];
							$datai['uid'] = $_G['uid'];
							$datai['createtime'] = $_G['timestamp'];
							$datai['ljqd'] = 0;
							$datai['ttqd'] = 0;
							$datai['earntt'] = 0;
							$datai['lastqd'] = 0;
							$datai['lid'] = dintval($lid);
							C::t('#jnmorning#jnmorning_userlid')->insert($datai); //���Ӹ��˸�lid�ܼ�¼
						}
						
						$tdopenlog = date("Y-m-d",$tdopen);
						$logdata['uid'] = $_G['uid'];
						$logdata['createtime'] = $_G['timestamp'];
						$logdata['logdesc'] = lang("plugin/$jn","a039").$clinfo['ltitle']."($tdopenlog)��".lang("plugin/$jn","a035")." $ctitle $tjifen -> $jfdd";
						$logdata['acdo'] = 1;
						C::t('#jnmorning#jnmorning_logsys')->insert($logdata);
						
						DB::query("REPLACE INTO ".DB::table('game_jnmorning_join')." (uid,amount,createtime,createdate,lid,closedate,jstatus,buydate) VALUES ('$_G[uid]','1','$_G[timestamp]','$copen','$lid','$cclose','0','$todaytime') "); //jstatus, 0 = default, 1 = gameover
						
						DB::query("UPDATE ".DB::table('game_jnmorning_land')." SET todayjoin = todayjoin+1, todaybuy = todaybuy+$clinfo[lamount] WHERE lid = '$clinfo[lid]'");
						//ȫվ��¼
						$sysinfo['totaljoinppl'] = $sysinfo['totaljoinppl']+1;
						DB::query("UPDATE ".DB::table('game_jnmorning_sysinfo')." SET totaljoinppl = '$sysinfo[totaljoinppl]' WHERE sid = '1'");
						
						$taskuser = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_taskjoin')." WHERE uid = '$_G[uid]' AND ttype = '3' AND tstatus = '0' AND lid = '$lid'"); //����ǩ��
						if($taskuser['tjid'] > 0){
							DB::query("UPDATE ".DB::table('game_jnmorning_taskjoin')." SET tqty = tqty + 1 WHERE tjid = '$taskuser[tjid]'");
						}
						showmessage("$jn:a014",'plugin.php?id='.$jn.'&do=view&lid='.$lid.$mobilelink.$uplinelink);
					}else{
						showmessage("$jn:a017",'',array('ctitle'=>$ctitle));
					}
				}else{
					showmessage("$jn:a015");
				}
			}else{
				showmessage("$jn:a016");
			}
		}else{
			showmessage("$jn:a016");
		}
	}
}
//From: Dism_taobao-com
?>