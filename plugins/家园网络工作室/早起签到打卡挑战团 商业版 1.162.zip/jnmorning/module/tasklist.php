<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
if($_GET['do'] == 'tasklist'){
	if($_GET['join'] == 'true'){
		if($_GET['formhash'] == $_G['formhash']){	
			$tid = dintval($_GET['tid']);
			$tinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_tasklist')." WHERE tid = '$tid'");
			if($tinfo['tid']>0){
				if($tinfo['joinlimit']>0 && $tinfo['joinnow'] > $tinfo['joinlimit']){
					showmessage("$jn:a044");
				}
				$tcheck = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_taskjoin')." WHERE uid = '$_G[uid]' AND tstatus = '0' AND tid = '$tid'");//tstatus = 0 ����δ���κν�����Ϣ
				if(!$tcheck['tjid']){
					if($tcheck['ptask']>0){ //�������ǰ������
						$tjcheck = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_taskjoin')." WHERE uid = '$_G[uid]' AND status = '1' AND tid = '$tcheck[ptask]'");
						if($tjcheck['tjid']>0){
							DB::query("REPLACE INTO ".DB::table('game_jnmorning_taskjoin')." (uid,tid,createtime,ftqty,ttype,lid) VALUES ('$_G[uid]','$tid','$_G[timestamp]','$tinfo[nqty]','$tinfo[ttype]','$tinfo[qd]')");
							DB::query("UPDATE ".DB::table('game_jnmorning_tasklist')." SET joinnow = joinnow + 1 WHERE tid = '$tid'");
							showmessage("$jn:a045","plugin.php?id=$jn&do=tasklist");
						}else{
							showmessage("$jn:a046");
						}
					}
					DB::query("REPLACE INTO ".DB::table('game_jnmorning_taskjoin')." (uid,tid,createtime,ftqty,ttype,lid) VALUES ('$_G[uid]','$tid','$_G[timestamp]','$tinfo[nqty]','$tinfo[ttype]','$tinfo[qd]')");
					showmessage("$jn:a045","plugin.php?id=$jn&do=tasklist");
				}else{
					showmessage("$jn:a049");
				}
			}else{
				showmessage("$jn:a016");
			}
		}
	}
	if($_GET['finish'] == 'true'){
		if($_GET['formhash'] == $_G['formhash']){	
			$tid = dintval($_GET['tid']);
			$cuser = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_taskjoin')." WHERE uid = '$_G[uid]' AND tid = '$tid' AND tstatus = '0'");
			if($cuser['tjid']>0 && $cuser['tqty'] >= $cuser['ftqty']){ //��̨���µ�ʱ��ҲҪ�� taskjoin��limit����һ�����.
				$ctinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_tasklist')." WHERE tid = '$tid'");
				if($ctinfo['tid']>0){
					if($cuser['trepeatnow'] >= $ctinfo['trepeat']){
						DB::query("UPDATE ".DB::table('game_jnmorning_taskjoin')." SET tstatus = '1', finishtime = '$_G[timestamp]' WHERE tjid = '$cuser[tjid]'");
					}else{
						DB::query("UPDATE ".DB::table('game_jnmorning_taskjoin')." SET treapeat = treapeat + 1, tqty = 0 WHERE tjid = '$cuser[tjid]'"); //��0���ظ�
					}
					
					$jfnow = getuserprofile('extcredits'.$ctinfo['tbonus']);
					$jfadd = $jfnow+$ctinfo['tbonusqty'];
					$creditsarray['extcredits'.$ctinfo['tbonus']] = '+'.$ctinfo['tbonusqty'];
									
					updatemembercount($_G['uid'], $creditsarray, true, '', 0, '',$jnc['title'],lang("plugin/$jn","a047").$ctinfo['ttitle'].lang("plugin/$jn","a043"));
					$creditsarray = array();
					showmessage("$jn:a047","plugin.php?id=$jn&do=tasklist");
				}
			}else{
				showmessage("$jn:a048","plugin.php?id=$jn&do=tasklist");
			}
		}else{
			showmessage("$jn:a016");
		}
	}
	//�����
	$userftj = DB::fetch_all("SELECT t1.*,t2.* FROM ".DB::table('game_jnmorning_taskjoin')." t1 LEFT JOIN ".DB::table('game_jnmorning_tasklist')." t2 ON (t1.tid = t2.tid) WHERE t1.uid = '".$_G['uid']."' AND tstatus = 1");
	foreach($userftj as $uftj){
		$uftlist[] = $uftj['tid'];
		$ownftask[] = $uftj;
	}
	//�����Ѿ������id
	$usertj = DB::fetch_all("SELECT t1.*,t2.* FROM ".DB::table('game_jnmorning_taskjoin')." t1 LEFT JOIN ".DB::table('game_jnmorning_tasklist')." t2 ON (t1.tid = t2.tid) WHERE t1.uid = '".$_G['uid']."' AND tstatus = 0");
	foreach($usertj as $utj){
		$utlist[] = $utj['tid'];
		$owntask[] = $utj;
	}
	if(!$utlist[0]['tid']){
		$ipuser = 0;
	}else{
		$ipuser = implode(',',$utlist);
	}

	$tinfo = DB::fetch_all("SELECT t1.*,t2.ttitle AS ptitle FROM ".DB::table('game_jnmorning_tasklist')." t1 LEFT JOIN ".DB::table('game_jnmorning_tasklist')." t2 ON (t1.ptask = t2.tid) WHERE t1.tid NOT IN ($ipuser) ORDER BY t1.tid ASC");
	foreach($tinfo as $tall){
		if($tall['topentime']>0){
			$tall['topentime'] = date("Y-m-d H:i:s",$tall['topentime']);
		}
		if($tall['tclosetime']>0){
			$tall['tclosetime'] = date("Y-m-d H:i:s",$tall['tclosetime']);
		}
		$tallist[] = $tall;
	}
}
//From: Dism_taobao-com
?>