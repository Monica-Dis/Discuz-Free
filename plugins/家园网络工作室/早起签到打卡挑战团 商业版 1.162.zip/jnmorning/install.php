<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_join` (
  `jid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `createdate` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  `closedate` int(11) NOT NULL,
  `jstatus` int(11) NOT NULL,
  `lucky` int(11) NOT NULL,
  `buydate` int(11) NOT NULL,
  `qdtime` int(11) NOT NULL,
  `bot` int(11) NOT NULL,
  PRIMARY KEY (`jid`),
  KEY `createdate` (`createdate`)
) ENGINE=MyISAM  AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_land` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `ltitle` text CHARACTER SET gbk NOT NULL,
  `opentime` text NOT NULL,
  `closetime` text NOT NULL,
  `lamount` int(11) NOT NULL,
  `buyjf` int(11) NOT NULL,
  `refundjf` int(11) NOT NULL,
  `bonusjf` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `ltype` int(11) NOT NULL COMMENT '1=suiji,2=junfen',
  `todayjoin` int(11) NOT NULL,
  `yesjoin` int(11) NOT NULL,
  `lstatus` int(11) NOT NULL,
  `totalbuy` text NOT NULL,
  `todaybuy` int(11) NOT NULL,
  `yesdaybuy` int(11) NOT NULL,
  `buyqty` text NOT NULL,
  `xtrabonus` int(11) NOT NULL,
  `sitecharge` int(11) NOT NULL,
  `downlinebonus` text NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2 ;

INSERT INTO `pre_game_jnmorning_land` (`lid`, `ltitle`, `opentime`, `closetime`, `lamount`, `buyjf`, `refundjf`, `bonusjf`, `createtime`, `ltype`, `todayjoin`, `yesjoin`, `lstatus`, `totalbuy`, `todaybuy`, `yesdaybuy`, `buyqty`, `xtrabonus`, `sitecharge`) VALUES
(1, '$installlang[u001]', '05:00:00', '08:00:00', 1, 1, 0, 1, 1517805982, 1, 0, 0, 0, '0', 0, 0, '1,10,20,40', 0, 0);

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_linfo` (
  `rid` int(11) NOT NULL AUTO_INCREMENT,
  `lid` int(11) NOT NULL,
  `opendate` int(11) NOT NULL,
  PRIMARY KEY (`rid`),
  KEY `dateopen` (`opendate`),
  KEY `rid` (`rid`)
) ENGINE=MyISAM  DEFAULT CHARSET=gbk AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_logsys` (
  `lsid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `logdesc` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `acdo` int(11) NOT NULL,
  PRIMARY KEY (`lsid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_sysinfo` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `totaljoinppl` text NOT NULL,
  `totalearnppl` text NOT NULL,
  `buyqty` text NOT NULL,
  `binfo` text NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2 ;

INSERT INTO `pre_game_jnmorning_sysinfo` (`sid`, `totaljoinppl`, `totalearnppl`, `buyqty`, `binfo`) VALUES
(1, '0', '0', '0,0,0,0','5-20,206,209|1|1');

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_tlog` (
  `tlid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`tlid`),
  KEY `tlid` (`tlid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_user` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `ljqd` int(11) NOT NULL,
  `ttqd` int(11) NOT NULL,
  `earntt` int(11) NOT NULL,
  `lastqd` int(11) NOT NULL,
  `ttjoin` int(11) NOT NULL,
  `upline` int(11) NOT NULL,
  `upline2` int(11) NOT NULL,
  `upline3` int(11) NOT NULL,
  `bonuslid` text NOT NULL,
  PRIMARY KEY (`mid`),
  KEY `mid` (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_userlid` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `ljqd` int(11) NOT NULL,
  `ttqd` int(11) NOT NULL,
  `earntt` int(11) NOT NULL,
  `lastqd` int(11) NOT NULL,
  `ttjoin` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  PRIMARY KEY (`mid`),
  KEY `mid` (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_tasklist` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `ttitle` text NOT NULL,
  `tdesc` text NOT NULL,
  `ttype` int(11) NOT NULL,
  `topentime` int(11) NOT NULL,
  `tclosetime` int(11) NOT NULL,
  `tbonus` int(11) NOT NULL,
  `tbonusqty` int(11) NOT NULL,
  `trepeat` int(11) NOT NULL,
  `ptask` int(11) NOT NULL,
  `nqty` int(11) NOT NULL,
  `qd` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `joinnow` int(11) NOT NULL,
  `joinlimit` int(11) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_taskjoin` (
  `tjid` int(11) NOT NULL AUTO_INCREMENT,
  `ttype` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `finishtime` int(11) NOT NULL,
  `tqty` int(11) NOT NULL,
  `tstatus` int(11) NOT NULL,
  `ftqty` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  `trepeatnow` int(11) NOT NULL,
  PRIMARY KEY (`tjid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

ALTER TABLE  `pre_game_jnmorning_tlog` ENGINE = INNODB;

EOF;

runquery($sql);

$finish = TRUE;
?>