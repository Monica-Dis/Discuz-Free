<?php
/*
 *	Author: Jnhill
 *	Last modified: 2017-01-01 17:42
 *	Filename: upgrade.php
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_land` (
  `lid` int(11) NOT NULL AUTO_INCREMENT,
  `ltitle` text CHARACTER SET gbk NOT NULL,
  `opentime` text NOT NULL,
  `closetime` text NOT NULL,
  `lamount` int(11) NOT NULL,
  `buyjf` int(11) NOT NULL,
  `refundjf` int(11) NOT NULL,
  `bonusjf` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `ltype` int(11) NOT NULL COMMENT '1=suiji,2=junfen',
  `todayjoin` int(11) NOT NULL,
  `yesjoin` int(11) NOT NULL,
  `lstatus` int(11) NOT NULL,
  `totalbuy` text NOT NULL,
  `todaybuy` int(11) NOT NULL,
  `yesdaybuy` int(11) NOT NULL,
  `buyqty` text NOT NULL,
  `xtrabonus` int(11) NOT NULL,
  `sitecharge` int(11) NOT NULL,
  `downlinebonus` text NOT NULL,
  PRIMARY KEY (`lid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_logsys` (
  `lsid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `logdesc` text NOT NULL,
  `createtime` int(11) NOT NULL,
  `acdo` int(11) NOT NULL,
  PRIMARY KEY (`lsid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_sysinfo` (
  `sid` int(11) NOT NULL AUTO_INCREMENT,
  `totaljoinppl` text NOT NULL,
  `totalearnppl` text NOT NULL,
  `buyqty` text NOT NULL,
  PRIMARY KEY (`sid`)
) ENGINE=MyISAM  AUTO_INCREMENT=2 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_tlog` (
  `tlid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  PRIMARY KEY (`tlid`),
  KEY `tlid` (`tlid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_userlid` (
  `mid` int(11) NOT NULL AUTO_INCREMENT,
  `uid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `ljqd` int(11) NOT NULL,
  `ttqd` int(11) NOT NULL,
  `earntt` int(11) NOT NULL,
  `lastqd` int(11) NOT NULL,
  `ttjoin` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  PRIMARY KEY (`mid`),
  KEY `mid` (`mid`)
) ENGINE=MyISAM AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_tasklist` (
  `tid` int(11) NOT NULL AUTO_INCREMENT,
  `ttitle` text NOT NULL,
  `tdesc` text NOT NULL,
  `ttype` int(11) NOT NULL,
  `topentime` int(11) NOT NULL,
  `tclosetime` int(11) NOT NULL,
  `tbonus` int(11) NOT NULL,
  `tbonusqty` int(11) NOT NULL,
  `trepeat` int(11) NOT NULL,
  `ptask` int(11) NOT NULL,
  `nqty` int(11) NOT NULL,
  `qd` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `joinnow` int(11) NOT NULL,
  `joinlimit` int(11) NOT NULL,
  PRIMARY KEY (`tid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `pre_game_jnmorning_taskjoin` (
  `tjid` int(11) NOT NULL AUTO_INCREMENT,
  `ttype` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `tid` int(11) NOT NULL,
  `createtime` int(11) NOT NULL,
  `finishtime` int(11) NOT NULL,
  `tqty` int(11) NOT NULL,
  `tstatus` int(11) NOT NULL,
  `ftqty` int(11) NOT NULL,
  `lid` int(11) NOT NULL,
  `trepeatnow` int(11) NOT NULL,
  PRIMARY KEY (`tjid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

ALTER TABLE  `pre_game_jnmorning_tlog` ENGINE = INNODB;

EOF;

runquery($sql);

DB::query("INSERT INTO ".DB::table('game_jnmorning_sysinfo')." (sid,totaljoinppl,totalearnppl,buyqty) VALUES (1, 0, 0, '0,0,0,0')",'SILENT');
DB::query("ALTER TABLE ".DB::table('game_jnmorning_land')." ADD `downlinebonus` TEXT NOT NULL",'SILENT'); //1.15
DB::query("INSERT INTO ".DB::table('game_jnmorning_land')." (lid,ltitle,opentime,closetime,lamount,buyjf,refundjf,bonusjf,createtime,ltype,todayjoin,yesjoin,lstatus,totalbuy,todaybuy, yesdaybuy,buyqty,xtrabonus,sitecharge,downlinebonus) VALUES (1, '$installlang[u001]', '05:00:00', '08:00:00', 1, 1, 0, 1, 1517805982, 1, 0, 0, 0, '800000', 5000, 1000, '1,10,20,40','0','0','0,0,0')",'SILENT');

DB::query("ALTER TABLE ".DB::table('game_jnmorning_user')." ADD `upline` INT NOT NULL, ADD `upline2` INT NOT NULL, ADD `upline3` INT NOT NULL, ADD `bonuslid` TEXT NOT NULL",'SILENT'); //1.15
DB::query("ALTER TABLE ".DB::table('game_jnmorning_join')." ADD  `bot` INT NOT NULL",'SILENT'); //1.15
DB::query("ALTER TABLE ".DB::table('pre_game_jnmorning_sysinfo')." ADD  `binfo` TEXT NOT NULL",'SILENT'); //1.15

//v1.15
//Ҫ������� morning_land �� downlinebonus = '0,0,0'
//ALTER TABLE  `pre_game_jnmorning_land` ADD  `downlinebonus` TEXT NOT NULL ok
//ALTER TABLE  `pre_game_jnmorning_user` ADD  `upline` INT NOT NULL , ok
//ADD  `upline2` INT NOT NULL , ok
//ADD  `upline3` INT NOT NULL , ok
//ADD  `bonuslid` TEXT NOT NULL ok
//ALTER TABLE  `pre_game_jnmorning_join` ADD  `bot` INT NOT NULL
//ALTER TABLE  `pre_game_jnmorning_sysinfo` ADD  `binfo` TEXT NOT NULL
//BOT


/*DB::query("ALTER TABLE ".DB::table('game_jncoin_sysinfo')." ADD gh TEXT NOT NULL",'SILENT');
DB::query("UPDATE ".DB::table('game_jncoin_sysinfo')." SET gh = '1,1,0.1' WHERE sid = 1",'SILENT');
DB::query("ALTER TABLE ".DB::table('game_jncoin_user')." ADD uplinelagi INT NOT NULL AFTER upline",'SILENT');

$checkuser = DB::fetch_all("SELECT cid,upline FROM ".DB::table('game_jncoin_user')." WHERE upline > 0");
foreach($checkuser as $cuser){
	$cupline = DB::fetch_first("SELECT upline FROM ".DB::table('game_jncoin_user')." WHERE uid = '$cuser[upline]'");
	DB::query("UPDATE ".DB::table('game_jncoin_user')." SET uplinelagi = '$cupline[upline]' WHERE cid = '$cuser[cid]'");
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_game_jncoin_gonghui` (
	`gid` INT NOT NULL AUTO_INCREMENT PRIMARY KEY ,
	`uid` INT NOT NULL ,
	`gmount` TEXT NOT NULL ,
	`createtime` INT NOT NULL ,
	`lastupdate` INT NOT NULL
) ENGINE = MYISAM;

EOF;

runquery($sql);

//ALTER TABLE  `pre_game_jncoin_sysinfo` ADD  `gh` TEXT NOT NULL;
UPDATE `pre_game_jncoin_sysinfo` SET  `gh` =  '1,1,0.1' WHERE  `pre_game_jncoin_sysinfo`.`sid` =1 LIMIT 1 ;
ALTER TABLE  `pre_game_jncoin_user` ADD  `uplinelagi` INT NOT NULL AFTER  `upline`;
*/
$finish = true;
?>