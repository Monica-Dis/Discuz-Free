<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
class plugin_jnmorning {
	function __construct() {
		global $_G;
	}
}
class plugin_jnmorning_forum extends plugin_jnmorning {
		function viewthread_sidebottom_output() {
			global $_G,$postlist;
			$config=$_G['cache']['plugin']['jnmorning'];
			if($config['forumon'] == 0){
				$return[] = '';
				return $return;
			}
			//$g_adminids=explode('/',$config['adminids']);
			$return = $uids = array();
			foreach($postlist as $p){
				$uids[$p['uid']] = $p['uid'];
			}
			$alluids = implode(',',$uids);
			$sign = C::t('#jnmorning#jnmorning_user')->fetch_inid($alluids);// $this_pk have to as uid;
			$signs = array_column($sign,null,'uid');
			foreach($postlist as $p){
				$a++;
				if($signs[$p['uid']]){
					$qdstr='';
					$qdstr='<a href="plugin.php?id=jnmorning" target="_blank" style="text-decoration:none;"><div style="font-size:18px; font-weight:bold;margin:10px 10px 0px 10px; border:1px solid gray; padding:5px; border-top-left-radius:5px; border-top-right-radius:5px; background:white" align="center">'.$signs[$p['uid']]['earntt'].'</div><div style="margin:0px 10px 10px 10px;border-bottom-left-radius:5px; border-bottom-right-radius:5px; border-left:1px solid gray;border-right:1px solid gray;border-bottom:1px solid gray; padding:5px;" align="center">'.$config[title].lang("plugin/jnmorning","a050").'</div></a>';
					$return[] = $qdstr;
				}else{
					if($forumleft == 1){
						$return[]= '<a href="plugin.php?id=jnmorning" target="_blank" style="text-decoration:none;"><div style="font-size:18px; font-weight:bold;margin:10px 10px 0px 10px; border:1px solid gray; padding:5px; border-top-left-radius:5px; border-top-right-radius:5px; background:white" align="center"> - </div><div style="margin:0px 10px 10px 10px;border-bottom-left-radius:5px; border-bottom-right-radius:5px; border-left:1px solid gray;border-right:1px solid gray;border-bottom:1px solid gray; padding:5px;" align="center">'.$config[title].lang("plugin/jnmorning","a050").'</div></a>';
					}else{
						$return[] = '';
					}
				}
				
			}
			return $return;
		}
	}
//dis'.'m.t'.'ao'.'bao.com
?>