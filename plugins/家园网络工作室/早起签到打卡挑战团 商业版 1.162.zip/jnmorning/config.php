<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
$jn = 'jnmorning';
$jnc = $_G['cache']['plugin'][$jn];
$g_adminids = explode('|',$jnc['adminids']);//����ԱȨ��
$navtitle = $jnc['title'];
$metakeywords = $jnc['title'];
$metadescription = $jnc['title'];
$groupin = unserialize($jnc['groupin']);
/* ���� */
$dgm = dgmdate($_G['timestamp'], 'Y-m-d H:i:s');
$_G['timestamp'] = strtotime($dgm);
/* ���� */
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if(!in_array($_G['uid'],$g_adminids)){
	if($jnc['onoff'] == '0' || !$jnc['onoff']){
		showmessage($jnc['notice']);
	}
	if(!in_array($_G['group']['groupid'],$groupin)){
		showmessage("$jn:a001");
	}	
}
if(in_array($_G['uid'],$g_adminids)){
	$adminbtn = "<a href=plugin.php?id=".$jn.":admincp".$jn.">".lang("plugin/$jn","a002")."</a>";
}
$imgurl = 'source/plugin/'.$jn.'/template/images/';

if(!$jnc['signmd5']){
	showmessage("$jn:a003");
}
$ctitle = $_G['setting']['extcredits'][$jnc['cashout']]['title'];
//$ttitle = $_G['setting']['extcredits'][$jnc['topup']]['title'];

$userinfo = C::t('#jnmorning#jnmorning_user')->userinfo($_G['uid']);
$sysinfo = C::t('#jnmorning#jnmorning_sysinfo')->sysinfo(1);
$systtj = number_format($sysinfo['totaljoinppl'],0,'.',',');
$systte = number_format($sysinfo['totalearnppl'],0,'.',',');
if($_GET['r']>0){
	$upline = dintval($_GET['r']);
	$upline = DB::fetch_first("SELECT uid FROM ".DB::table('game_jnmorning_user')." WHERE uid = '$upline'");
	if($upline['uid']>0){
		$uplinelink = '&r='.$upline['uid'];
	}
}
if(!$userinfo['mid']){
	if($_GET['formhash'] == $_G['formhash']){
		if($_GET['r']>0){
			$upline = dintval($_GET['r']);
			$uupline = C::t('#jnmorning#jnmorning_user')->userinfo($upline); //һ������
			if($uupline['uid']>0){
				$uupupline = C::t('#jnmorning#jnmorning_user')->userinfo($uupline['uid']);
			}
		}
		$data['uid'] = $_G['uid'];
		$data['createtime'] = $_G['timestamp'];
		$data['ljqd'] = 0;
		$data['ttqd'] = 0;
		$data['earntt'] = 0;
		$data['lastqd'] = 0;
		$data['upline'] = dintval($upline);
		$data['upline2'] = dintval($uupline['uid']);
		$data['upline3'] = dintval($uupupline['uid']);
		C::t('#jnmorning#jnmorning_user')->insert($data);
	}
}
if($_GET['mobile']>0){
	$mbl = dintval($_GET['mobile']);
	$mobilelink = '&mobile='.$mbl;
}
if($_GET['formhash'] == $_G['formhash']){ //maybe ���ڼƻ���������?,ÿ�ո���һ��?
	/*$botinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_sysinfo')." WHERE sid = '1'");
	$botinfo['binfo'] = explode('|',$botinfo['binfo']);
	if($botinfo['binfo'][2]=='1'){ //����״̬��
		if($botinfo['binfo'][1]){
			$alllid = explode(',',$botinfo['binfo'][1]);
			$countlid = count($alllid);
			//��ʼexplode �����û�
			$botuser = explode(',',$botinfo['binfo'][0]);
			$cbotuser = count($botuser);

			for($aa=0;$aa<$countlid;$aa++){
				$lainfo[$aa] = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_land')." WHERE lid = '$alllid[$aa]'");
				$todayopen = date("Y-m-d",$_G['timestamp']);
				$todaytime = strtotime($todayopen);
				$tdopen[$aa] = strtotime($todayopen.' '.$lainfo[$aa]['opentime']);
				$tdclose[$aa] = strtotime($todayopen.' '.$lainfo[$aa]['closetime']);
				$copen[$aa] = $tdopen[$aa]+86400; //����ǩ����ʼʱ��
				$cclose[$aa] = $tdclose[$aa]+86400; //����ǩ������ʱ��
			}

			$ttjoinadd = 0;
			for($h=0;$h<$cbotuser;$h++){
				$botuserlarge[$h] = explode('-',$botuser[$h]);
				if($botuserlarge[$h][1]>0){
					for($botppl = $botuserlarge[$h][0]; $botppl < $botuserlarge[$h][1]; $botppl++){
						//��Ҫ�޸�lid??
						for($k=0;$k<$countlid;$k++){
							$suijishu = mt_rand(1,2);
							if($suijishu == '1'){
								DB::query("REPLACE INTO ".DB::table('game_jnmorning_join')." (uid,amount,createtime,createdate,lid,closedate,jstatus,buydate,bot) VALUES ('".$botppl."','1','$_G[timestamp]','$copen[$k]','$alllid[$k]','$cclose[$k]','0','$todaytime','1') ");
								//$haha++; //Ҫterbalik����õ�
								$changci[$k]++;
								$ttjoinadd++;
							}
						}
					}
				}else{
					for($k=0;$k<$countlid;$k++){
						DB::query("REPLACE INTO ".DB::table('game_jnmorning_join')." (uid,amount,createtime,createdate,lid,closedate,jstatus,buydate,bot) VALUES ('".$botuserlarge[$h][0]."','1','$_G[timestamp]','$copen[$k]','$alllid[$k]','$cclose[$k]','0','$todaytime','1') ");
						//$haha++; //Ҫterbalik����õ�
						$changci[$k]++;
						$ttjoinadd++; //�������?
					}
				}
			}

			for($ll=0;$ll<$countlid;$ll++){
				$llinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_land')." WHERE lid = '$alllid[$ll]'");
				$ttttbuy = $llinfo['todaybuy']+($llinfo['lamount']*$changci[$ll]); //����Ҫ���£��ſ��Ը��������~
				DB::query("UPDATE ".DB::table('game_jnmorning_land')." SET todayjoin = todayjoin+'$changci[$ll]', todaybuy = '$ttttbuy' WHERE lid = '$alllid[$ll]'");
			}

			//ȫվ��¼
			$sysinfo['totaljoinppl'] = $sysinfo['totaljoinppl']+$ttjoinadd;
			DB::query("UPDATE ".DB::table('game_jnmorning_sysinfo')." SET totaljoinppl = '$sysinfo[totaljoinppl]' WHERE sid = '1'");
		}
	}*/
}
//$sysinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jncoin_sysinfo')." WHERE sid = '1'");
/*if($_GET['ajax']){
	require DISCUZ_ROOT.'source/plugin/'.$jn.'/module/ajax.php';
}
if(file_exists("source/plugin/jncoin/module/market.php")){
	$marketfile = 1;
}*/
?>