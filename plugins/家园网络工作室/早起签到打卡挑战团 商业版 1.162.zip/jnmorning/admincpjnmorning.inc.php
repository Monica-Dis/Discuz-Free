<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-01-02
 */
if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
};
global $_G;
$jn = 'jnmorning';
$jnc = $_G['cache']['plugin'][$jn];
$g_adminids = explode('|',$jnc['adminids']);//����ԱȨ��
if (!$_G['uid']) showmessage('not_loggedin','',array(), array('login' => true));
if(!in_array($_G['uid'],$g_adminids)){
	showmessage("$jn:a021"); //�ǹ���Ա
}
foreach($_G['setting']['extcredits'] as $key => $value){
	$ext = 'extcredits'.$key;
	$systemc['extcredits'][$key]['title'] = $value['title'];
	$systemc['extcredits'][$key]['value'] = $_G['member'][$ext];
	$systemc['extcredits'][$key]['key'] = $key;
}
if(!$_GET['do']){ //ϵͳ����
	$sinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_sysinfo')." WHERE sid = '1'");
	$sinfo['binfo'] = explode('|',$sinfo['binfo']);
}
if($_GET['do'] == 'userlist' && !$_GET['userid']){
	$ulist = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnmorning_user')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid = t2.uid) ORDER BY t1.mid ASC");
	foreach($ulist as $ul){
		$ul['createtime'] = date("Y-m-d H:i:s",$ul['createtime']);
		$uslist[] = $ul;
	}
}
if($_GET['do'] == 'userlist' && $_GET['userid'] > 0){
	$userid = dintval($_GET['userid']);
	$uinfo = DB::fetch_first("SELECT t1.*,t2.username FROM ".DB::table('game_jnmorning_user')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid = t2.uid) WHERE t1.mid = '$userid'");
	$uinfo['createtime'] = date('Y-m-d H:i:s',$uinfo['createtime']);
	//�����¼
	$joinlist = DB::fetch_all("SELECT t1.*,t2.ltitle,t2.buyjf FROM ".DB::table('game_jnmorning_join')." t1 LEFT JOIN ".DB::table('game_jnmorning_land')." t2 ON (t1.lid = t2.lid) WHERE t1.uid = '$userid' ORDER BY t1.jid DESC LIMIT 200");
	foreach($joinlist as $jl){
		if($_G['timestamp'] > $jl['closedate'] && $jl['jstatus'] == '0'){
			$jl['jsword'] = lang("plugin/$jn","a022");//'<font color=red>ǩ��ʧ��</font>';
		}else if($_G['timestamp'] > $jl['createdate'] && $jl['jstatus'] == '1'){
			$jl['jsword'] = lang("plugin/$jn","a023").$jl['lucky'].$_G['setting']['extcredits'][$jl['buyjf']]['title'];//'<font color=green>ǩ���ɹ�</font>, ���';
		}else{
			$jl['jsword'] = lang("plugin/$jn","a027");
		}
		$jl['createtime'] = date("Y-m-d H:i:s",$jl['createtime']);
		$jlist[] = $jl;
	}
}
if($_GET['do'] == 'updatesys'){
	if(submitcheck('svaluesubmit')){
		//$ra = dintval($_GET['ra']);
		$totaljoinppl = daddslashes($_GET['totaljoinppl']);
		$totalearnppl = daddslashes($_GET['totalearnppl']);
		$binfo = daddslashes($_GET['binfo1'].'|'.$_GET['binfo2'].'|'.$_GET['binfo3']);
		DB::query("UPDATE ".DB::table('game_jnmorning_sysinfo')." SET totalearnppl = '$totalearnppl', totaljoinppl = '$totaljoinppl', binfo = '$binfo' WHERE sid = 1");
		showmessage("$jn:a024","plugin.php?id=$jn:admincp$jn",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
	}
}
if($_GET['do'] == 'joinlist'){
	$lid = dintval($_GET['lid']);
	$joinland = DB::fetch_all("SELECT * FROM ".DB::table('game_jnmorning_land')." ORDER BY lid ASC");
	if(!$lid){
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_join')."");
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT t1.*,t2.username,t3.ltitle FROM ".DB::table('game_jnmorning_join')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) LEFT JOIN ".DB::table('game_jnmorning_land')." t3 ON (t1.lid = t3.lid) ORDER BY t1.jid desc limit {$start_limit},{$tpp}");
		foreach ($quserinfo as $qu => $qc) {
			//
			$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
			$qc['createdate'] = date("Y-m-d H:i:s",$qc['createdate']);
			$qc['closedate'] = date("Y-m-d H:i:s",$qc['closedate']);
			$joinall[] = $qc;
		};
		$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=joinlist", $_G['setting']['threadmaxpages']);
	}else{
		$lidinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_land')." WHERE lid = $lid ");
		if($lidinfo['lid']>0){
			$page = $_G['page'];
			$tpp = 100;
			$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_join')." WHERE lid = $lid");
			if(@ceil($total/$tpp) < $page) 	$page = 1;
			$start_limit = ($page - 1) * $tpp;
			$quserinfo = DB::fetch_all("SELECT t1.*,t2.username,t3.ltitle FROM ".DB::table('game_jnmorning_join')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) LEFT JOIN ".DB::table('game_jnmorning_land')." t3 ON (t1.lid = t3.lid) WHERE t1.lid = $lid ORDER BY t1.jid desc limit {$start_limit},{$tpp}");
			foreach ($quserinfo as $qu => $qc) {
				//
				$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
				$qc['createdate'] = date("Y-m-d H:i:s",$qc['createdate']);
				$qc['closedate'] = date("Y-m-d H:i:s",$qc['closedate']);
				$joinall[] = $qc;
			};
			
			$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=joinlist&lid=$lid", $_G['setting']['threadmaxpages']);
		}
	}
}
if($_GET['do'] == 'tasklist'){
	$tid = dintval($_GET['tid']);
	$llist = DB::fetch_all("SELECT lid,ltitle FROM ".DB::table('game_jnmorning_land')." ORDER BY lid ASC");
	$tlist = DB::fetch_all("SELECT * FROM ".DB::table('game_jnmorning_tasklist')." ORDER BY tid ASC");
	if($tid>0){
		$tinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_tasklist')." WHERE tid = '$tid'");
		if($tinfo['ttype'] == '1'){
			$tinfo['wording'] = lang("plugin/$jn","a051");
			//$tl['qd'] = $llist[$tl['qd']]['ltitle'];
		}elseif($tinfo['ttype'] == '2'){
			$tinfo['wording'] = lang("plugin/$jn","a052");
			//$tl['qd'] = $llist[$tl['qd']]['ltitle'];
		}elseif($tinfo['ttype'] == '3'){
			$tinfo['wording'] = lang("plugin/$jn","a054");
			//$tl['qd'] = $llist[$tl['qd']]['ltitle'];
		}else{
			$tinfo['wording'] = lang("plugin/$jn","a053");
 		}
		$tinfo['topentime']>0 ? $tinfo['topentime'] = date("Y-m-d H:i:s",$tinfo['topentime']) : $tinfo['topentime'] = '';
		$tinfo['tclosetime']>0 ? $tinfo['tclosetime'] = date("Y-m-d H:i:s",$tinfo['tclosetime']) : $tinfo['tclosetime'] = '';
	}
	foreach($tlist as $tl){
		$tl['topentime'] > 0 ? $tl['topentime'] = date("Y-m-d H:i:s",$tl['topentime']) : $tl['topentime'] = date("Y-m-d H:i:s",$tl['createtime']);
		$tl['tclosetime'] > 0 ? $tl['tclosetime'] = date("Y-m-d H:i:s",$tl['tclosetime']) : $tl['tclosetime'] = '����';
		if($tl['ttype'] == '1'){
			$tl['wording'] = lang("plugin/$jn","a051");
			$tl['qd'] = $llist[$tl['qd']]['ltitle'];
		}elseif($tl['ttype'] == '2'){
			$tl['wording'] = lang("plugin/$jn","a052");
			$tl['qd'] = $llist[$tl['qd']]['ltitle'];
		}elseif($tinfo['ttype'] == '3'){
			$tinfo['wording'] = lang("plugin/$jn","a054");
			//$tl['qd'] = $llist[$tl['qd']]['ltitle'];
		}else{
			$tl['wording'] = lang("plugin/$jn","a053");
 		}
		$tllist[] = $tl;
	}
	if(submitcheck('updatetasksubmit')){
		$ttitle = daddslashes($_GET['ttitle']);
		$tdesc = daddslashes($_GET['tdesc']);
		$qd = dintval($_GET['qd']);
		$nqty = dintval($_GET['nqty']);
		$ptask = dintval($_GET['ptask']);
		$topentime = strtotime($_GET['topentime']);
		$tclosetime = strtotime($_GET['tclosetime']);
		$tbonusqty = dintval($_GET['tbonusqty']);
		$tbonus = dintval($_GET['tbonus']);
		$trepeat = dintval($_GET['trepeat']);
		$joinlimit = dintval($_GET['joinlimit']);
		if($ptask == $tinfo['tid']){
			showmessage("$jn:a040");
		}
		if($tinfo['ttype'] == '1' || $tinfo['ttype'] == '2'){
			if(!$qd){
				showmessage("$jn:a025");
			}
		}
		if($ttitle && $nqty > 0 && $tbonusqty > 0 && $tbonus > 0){
			DB::query("UPDATE ".DB::table('game_jnmorning_tasklist')." SET ttitle = '$ttitle', tdesc = '$tdesc', topentime = '$topentime', tclosetime = '$tclosetime', tbonus = '$tbonus', tbonusqty = '$tbonusqty', trepeat = '$trepeat', ptask = '$ptask', nqty = '$nqty', qd = '$qd', joinlimit = '$joinlimit' WHERE tid = '$tinfo[tid]'");
			if($nqty != $tinfo['nqty']){
				DB::query("UPDATE ".DB::table('game_jnmorning_taskjoin')." SET ftqty = '$nqty' WHERE tid = '$tinfo[tid]' AND tstatus = '0'");
			}
			showmessage("$jn:a024","plugin.php?id=$jn:admincp$jn&do=tasklist&tid=".$tinfo['tid']);
		}else{
			showmessage("$jn:a025");
		}
	}
	if(submitcheck('newtasksubmit')){
		$ttype = dintval($_GET['ttype']);
		$ttitle = daddslashes($_GET['ttitle']);
		$tdesc = daddslashes($_GET['tdesc']);
		$qd = dintval($_GET['qd'.$ttype]);
		$nqty = dintval($_GET['nqty'.$ttype]);
		$ptask = dintval($_GET['ptask'.$ttype]);
		$topentime = strtotime($_GET['topentime']);
		$tclosetime = strtotime($_GET['tclosetime']);
		$tbonusqty = dintval($_GET['tbonusqty']);
		$tbonus = dintval($_GET['tbonus']);
		$trepeat = dintval($_GET['trepeat'.$ttype]);
		$joinlimit = dintval($_GET['joinlimit']);
		$createtime = $_G['timestamp'];
		if($ttype == '1' || $ttype == '2'){
			if(!$qd){
				showmessage("$jn:a025");
			}
		}
		if($ttitle && $nqty > 0 && $tbonusqty > 0 && $tbonus > 0){
			DB::query("REPLACE INTO ".DB::table('game_jnmorning_tasklist')." (ttitle,tdesc,ttype,topentime,tclosetime,tbonus,tbonusqty,trepeat,ptask,nqty,qd,createtime) VALUES ('$ttitle','$tdesc','$ttype','$topentime','$tclosetime','$tbonus','$tbonusqty','$trepeat','$ptask','$nqty','$qd','$createtime') ");
			showmessage("$jn:a026","plugin.php?id=$jn:admincp$jn&do=tasklist");
		}else{
			showmessage($nqty);
			showmessage("$jn:a025");
		}
	}
}
if($_GET['do'] == 'landlist'){
	if(submitcheck('newlandsubmit')){
		$ltitle = daddslashes($_GET['ltitle']);
		$lamount = dintval($_GET['lamount']);
		$opentime = daddslashes($_GET['opentime']);
		$closetime = daddslashes($_GET['closetime']);
		$buyjf = dintval($_GET['buyjf']);
		$bonusjf = dintval($_GET['bonusjf']);
		$refundjf = dintval($_GET['refundjf']);
		$ltype = dintval($_GET['ltype']);
		$todaybuy = dintval($_GET['todaybuy']);
		$todayjoin = dintval($_GET['todayjoin']);
		$xtrabonus = dintval($_GET['xtrabonus']);
		$sitecharge = dintval($_GET['sitecharge']);
		if(!$ltitle || !$lamount || !$opentime || !$closetime || !$buyjf || !$bonusjf || !$refundjf || !$ltype){
			showmessage("$jn:a025");
		}
		$downlinebonus = array();
		for($x=1;$x<7;$x++){
			$downlinebonus[$x] = dintval($_GET['downlinebonus'.$x]);
		}
		$downlinebonus = implode(',',$downlinebonus);
		DB::query("REPLACE INTO ".DB::table('game_jnmorning_land')." (ltitle,lamount,opentime,closetime,buyjf,bonusjf,ltype,todaybuy,todayjoin,xtrabonus,sitecharge,refundjf,downlinebonus) VALUES ('$ltitle','$lamount','$opentime','$closetime','$buyjf','$bonusjf','$ltype','$todaybuy','$todayjoin','$xtrabonus','$sitecharge','$refundjf','$downlinebonus')");
		showmessage("$jn:a024","plugin.php?id=$jn:admincp$jn&do=landlist",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
	}
	$lid = dintval($_GET['lid']);
	if(submitcheck('landsubmit')){
		$linfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_land')." WHERE lid = '$lid'");
		if(!$linfo['lid']){
			showmessage("$jn:a016");
		}
		$ltitle = daddslashes($_GET['ltitle']);
		$lamount = dintval($_GET['lamount']);
		$opentime = daddslashes($_GET['opentime']);
		$closetime = daddslashes($_GET['closetime']);
		$buyjf = dintval($_GET['buyjf']);
		$bonusjf = dintval($_GET['bonusjf']);
		$refundjf = dintval($_GET['refundjf']);
		$ltype = dintval($_GET['ltype']);
		$todaybuy = dintval($_GET['todaybuy']);
		$todayjoin = dintval($_GET['todayjoin']);
		$xtrabonus = dintval($_GET['xtrabonus']);
		$sitecharge = dintval($_GET['sitecharge']);
		if(!$ltitle || !$lamount || !$opentime || !$closetime || !$buyjf || !$bonusjf || !$refundjf || !$ltype){
			showmessage("$jn:a025");
		}
		$downlinebonus = array();
		for($x=1;$x<7;$x++){
			$downlinebonus[$x] = dintval($_GET['downlinebonus'.$x]);
		}
		$downlinebonus = implode(',',$downlinebonus);
		DB::query("UPDATE ".DB::table('game_jnmorning_land')." SET ltitle = '$ltitle', lamount = '$lamount', opentime = '$opentime', closetime = '$closetime', buyjf = '$buyjf', bonusjf = '$bonusjf', ltype = '$ltype', todaybuy = '$todaybuy', todayjoin = '$todayjoin', xtrabonus = '$xtrabonus', sitecharge = '$sitecharge', refundjf = '$refundjf', downlinebonus = '$downlinebonus' WHERE lid = '$lid' ");
		showmessage("$jn:a024","plugin.php?id=$jn:admincp$jn&do=landlist",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
	}
	if($lid > 0){
		$landinfo = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_land')." WHERE lid = '$lid'");
		$landinfo['downlinebonus'] = explode(',',$landinfo['downlinebonus']);
		$landinfo['buyqty'] = explode(',',$landinfo['buyqty']);
	}
	$list = DB::fetch_all("SELECT * FROM ".DB::table('game_jnmorning_land')." ORDER BY lid ASC");
	foreach($list as $li){
		$li['ctitle'] = $_G['setting']['extcredits'][$li['buyjf']]['title'];
		$li['btitle'] = $_G['setting']['extcredits'][$li['bonusjf']]['title'];
		if($li['buytime']>0){
			$li['buytime'] = date("Y-m-d H:i:s",$li['buytime']);
		}
		$li['createtime'] = date("Y-m-d H:i:s",$li['createtime']);
		$li['title'] = $itemarr[$li['itemid']];
		$llist[] = $li;
	}
}
if($_GET['do'] == 'searchuser'){
	$userid = dintval($_GET['userid']);
	$usernamecp = daddslashes($_GET['usernamecp']);
	if(submitcheck('searchusersubmit')){
		if(!$userid && !$usernamecp){
			showmessage("$jn:a012");
		}
		if($userid <= 0){
			$searchuid = DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE username = '$usernamecp'");
			$searchuserid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_user')." WHERE uid = '$searchuid[uid]'");
		}else{
			$searchuserid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_user')." WHERE uid = '$userid'");	
		}
		if(!$searchuserid['uid']){
			showmessage("$jn:a029");
		}
		showmessage("$jn:a030",'plugin.php?id='.$jn.':admincp'.$jn.'&do=userlist&userid='.$searchuserid['cid'],array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
	}
}
if($_GET['do'] == 'updateuser'){
	$uid = dintval($_GET['uid']);
	$userinfo = C::t('#jnmorning#jnmorning_user')->userinfo($uid);
	if(!$userinfo['mid']){
		showmessage("$jn:a029");
	}
	if(submitcheck('usersubmit')){
		$createtime = strtotime($_GET['createtime']);
		$ttjoin = dintval($_GET['ttjoin']);
		$earntt = dintval($_GET['earntt']);
		$ljqd = dintval($_GET['ljqd']);
		$ttqd = dintval($_GET['ttqd']);
		$upline = dintval($_GET['upline']);
		$upline2 = dintval($_GET['upline2']);
		$upline3 = dintval($_GET['upline3']);
		C::t('#jnmorning#jnmorning_user')->update($userinfo['mid'],array('createtime'=>$createtime,'ttjoin'=>$ttjoin,'earntt'=>$earntt,'ljqd'=>$ljqd,'ttqd'=>$ttqd,'upline'=>$upline,'upline2'=>$upline2,'upline3'=>$upline3));
	}
	showmessage("$jn:a024","plugin.php?id=$jn:admincp$jn&do=userlist&userid=$userinfo[mid]",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
}
if($_GET['do'] == 'delete'){
	if($_GET['formhash'] == $_G['formhash']){
		$jid = dintval($_GET['jid']);
		if($jid>0){
			$userid = $_GET['mid'];
			DB::query("DELETE FROM ".DB::table('game_jnmorning_join')." WHERE jid = '$jid'");
			showmessage("$jn:a031","plugin.php?id=$jn:admincp$jn&do=userlist&userid=".$userid,array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
		}
		$lid = dintval($_GET['lid']);
		if($lid >0){
			DB::query("DELETE FROM ".DB::table('game_jnmorning_land')." WHERE lid = '$lid'");
			DB::query("DELETE FROM ".DB::table('game_jnmorning_join')." WHERE lid = '$lid'");
			showmessage("$jn:a031","plugin.php?id=$jn:admincp$jn&do=landlist",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
		}
		$tid = dintval($_GET['tid']);
		if($tid > 0){
			DB::query("DELETE FROM ".DB::table('game_jnmorning_taskjoin')." WHERE tid = '".$tid."' ");
			DB::query("DELETE FROM ".DB::table('game_jnmorning_tasklist')." WHERE tid = '".$tid."' ");
			showmessage("$jn:a031","plugin.php?id=$jn:admincp$jn&do=tasklist",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
		}
	}else{
		showmessage("$jn:a016");
	}
}
if($_GET['do'] == 'viewlog'){ //��ʾ�б�
	$userid = dintval($_GET['userid']);
	$typeid = dintval($_GET['typeid']);
	if($userid > 0 && $typeid > 0){ //�����ѯ�û���ĳ���ض�����
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_logsys')." WHERE uid = '$userid' AND acdo = '$typeid'");
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnmorning_logsys')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) WHERE t1.uid = '$userid' AND t1.acdo = '$typeid' ORDER BY t1.lsid desc limit {$start_limit},{$tpp}");
		foreach ($quserinfo as $qu => $qc) {
			//
			$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
			$viewlog[] = $qc;
		};
		$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=viewlog&userid".$userid."&typeid=".$typeid, $_G['setting']['threadmaxpages']);
	}elseif($userid == 0 && $typeid > 0){ //�����ѯȫվĳ����������
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_logsys')." WHERE acdo = '$typeid'");
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnmorning_logsys')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) WHERE t1.acdo = '$typeid' ORDER BY t1.lsid desc limit {$start_limit},{$tpp}");
			foreach ($quserinfo as $qu => $qc) {
				//
				$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
				$viewlog[] = $qc;
			};
			$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=viewlog&userid".$userid."&typeid=".$typeid, $_G['setting']['threadmaxpages']);
	}elseif($userid > 0 && $typeid == 0){ //�����ѯĳ����Ա��ȫվ��������
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_logsys')." WHERE uid = '$userid'");
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnmorning_logsys')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) WHERE t1.uid = '$userid' ORDER BY t1.lsid desc limit {$start_limit},{$tpp}");
		foreach ($quserinfo as $qu => $qc) {
			//
			$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
			$viewlog[] = $qc;
		};
		$multipage = multi($total, $tpp, $page, "plugin.php?id=".$jn.":admincp$jn&do=viewlog&userid".$userid."&typeid=".$typeid, $_G['setting']['threadmaxpages']);
	}else{ //ȫվ��־
		$page = $_G['page'];
		$tpp = 100;
		$total = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_logsys'));
		if(@ceil($total/$tpp) < $page) 	$page = 1;
		$start_limit = ($page - 1) * $tpp;
		$quserinfo = DB::fetch_all("SELECT t1.*,t2.username FROM ".DB::table('game_jnmorning_logsys')." t1 LEFT JOIN ".DB::table('common_member')." t2 ON (t1.uid=t2.uid) ORDER BY t1.lsid desc limit {$start_limit},{$tpp}");
		foreach ($quserinfo as $qu => $qc) {
			$qc['createtime'] = date("Y-m-d H:i:s",$qc['createtime']);
			$viewlog[] = $qc;
		};
		$multipage = multi($total, $tpp, $page, "plugin.php?id=$jn:admincp$jn&do=viewlog", $_G['setting']['threadmaxpages']);
	}
}
if($_GET['do'] == 'searchlog'){
	$userid = dintval($_GET['userid']);
	$usernamecp = daddslashes($_GET['usernamecp']);
	if(submitcheck('searchlogsubmit')){
		$typeid = dintval($_GET['selecttype']);
		if(!$userid && !$usernamecp){
			showmessage("$jn:a030","plugin.php?id=$jn:admincp$jn&do=viewlog&userid=0&typeid=$typeid",array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
		}
		if(!$userid){
			$searchuid = DB::fetch_first("SELECT * FROM ".DB::table('common_member')." WHERE username = '$usernamecp'");
			$searchuserid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_user')." WHERE uid = '$searchuid[uid]'");
		}else{
			$searchuserid = DB::fetch_first("SELECT * FROM ".DB::table('game_jnmorning_user')." WHERE uid = '$userid'");	
		}
		if(!$searchuserid['uid']){
			showmessage("$jn:a029");
		}
		
		if(!$typeid){
			$nviewlog = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_logsys')." WHERE uid = '".$searchuserid['uid']."'");
		}else{
			$nviewlog = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_logsys')." WHERE uid = '".$searchuserid['uid']."' AND acdo = '$typeid'");
		}
		if($nviewlog > 0){
			showmessage("$jn:a030",'plugin.php?id='.$jn.':admincp'.$jn.'&do=viewlog&userid='.$searchuserid['uid']."&typeid=".$typeid,array(),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
		}else{
			showmessage("$jn:a029");
		}
	}
}
if($_GET['do'] == 'deletelog'){
	if(submitcheck('deletelogsubmit')){
		$deletedate = dintval($_GET['deletedate']);
		if(!$deletedate || $deletedate <= 0){
			showmessage("$jn:a014");
		}else{
			if($_GET['formhash'] == $_G['formhash']){
				$todaytime = strtotime(date("Y-m-d",$_G['timestamp']));
				$deletedatestr = $deletedate * 86400;
				$deletetime = $todaytime - $deletedatestr;
				$nrecord = DB::result_first("SELECT count(*) cnt FROM ".DB::table('game_jnmorning_logsys')." WHERE createtime < '$deletetime'");
				DB::query("DELETE FROM ".DB::table('game_jnmorning_logsys')." WHERE createtime < '$deletetime'");
				showmessage("$jn:a028",'plugin.php?id='.$jn.':admincp'.$jn.'&do=viewlog',array('nrecord'=>$nrecord),array('showdialog' => 1, 'showmsg' => true, 'alert' => 'right', 'locationtime'=>true));
			}else{
				showmessage("$jn:a016");
			}
		}
	}else{
		showmessage("$jn:a016");
	}
}
include template('diy:admincp'.$jn, 0, 'source/plugin/'.$jn.'/template');
?>