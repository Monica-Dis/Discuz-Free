<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/4/25
 * Time: 17:57
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_c/common.php';
$creditype = $_G['setting']['extcredits'][$config['ctype']]['title'];

$amount = abs($_GET['addfundamount']) ? abs($_GET['addfundamount']) :  abs($_GET['checkamount']);

if(!$_GET['cardid'] && $amount<=0){
    $over0 = lang('plugin/xigua_c', 'over0');
    $errmsg = diconv($over0, CHARSET, 'UTF-8');

    if($_GET['checkbox1'] == 'wxpay') {
        echo json_encode(array('error' => $errmsg));
    }else{
        echo '<script>alert("'.$over0.'");window.history.go(-1);</script>';
    }
    exit;
}

$price = $amount*100;
$credit = $config['bilv']*$amount;

if(!$_GET['cardid'] && $config['min'] && $credit<$config['min']){
    $over0 = lang('plugin/xigua_c', 'min1').' '.$config['min'].$creditype;
    $errmsg = diconv($over0, CHARSET, 'UTF-8');

    if($_GET['checkbox1'] == 'wxpay') {
        echo json_encode(array('error' => $errmsg));
    }else{
        echo '<script>alert("'.$over0.'");window.history.go(-1);</script>';
    }
    exit;
}

$subject = $_G['username'].'-'.$creditype.lang('plugin/xigua_c', 'cd');
if(!$_GET['cardid']){
$order_id = C::t('#xigua_c#xigua_c_order')->get_order_id(
    $_G['uid'], $openid, $price, $credit, $config['ctype'], $_GET['checkbox1'], $subject
);

}
$subject = str_replace(array(' ', "\t"), '', $subject);
$subject = $body = diconv($subject, CHARSET, 'UTF-8');


function getSign($Obj){
    $apikey = SF_WXPAY_KEY;
    foreach ($Obj as $k => $v)
    {
        $Parameters[$k] = $v;
    }
    ksort($Parameters);
    $String = formatBizQueryParaMap($Parameters, false);
    $String = $String."&key=$apikey";
    $String = md5($String);
    $result_ = strtoupper($String);
    return $result_;
}
function formatBizQueryParaMap($paraMap, $urlencode)
{
    $buff = "";
    ksort($paraMap);
    foreach ($paraMap as $k => $v)
    {
        if($urlencode)
        {
            $v = urlencode($v);
        }
        $buff .= $k . "=" . $v . "&";
    }
    $reqPar = '';
    if (strlen($buff) > 0)
    {
        $reqPar = substr($buff, 0, strlen($buff)-1);
    }
    return $reqPar;
}

if($_GET['checkbox1'] == 'wxpay'){
    $tools = new JsApiPaySF();

    $notify = new NativePaySF();
    $input = new WxPayUnifiedOrderSF();
    $input->SetBody($body);
    $input->SetAttach($body);
    $input->SetOut_trade_no($order_id);
    $input->SetTotal_fee($price);
    $input->SetTime_start(date("YmdHis"));
//    $input->SetTime_expire(date("YmdHis", time() + 3600));
    $input->SetGoods_tag($body);
    $input->SetNotify_url($_G['siteurl']. 'source/plugin/xigua_c/notify.inc.php');
    $input->SetTrade_type(INC_WECHAT ? "JSAPI" : "NATIVE");

    if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false){

        $input->SetTrade_type("APP");
        $postObj = WxPayApiSF::unifiedOrder($input);
        $noncestr = WxPayApiSF::getNonceStr();

        $timestamp = $_G['timestamp'];
        $apppay = array();
        $apppay['appid'] = SF_APPID;
        $apppay['partnerid'] = SF_MCHID;
        $apppay['prepayid'] = $postObj['prepay_id'];
        $apppay['noncestr'] = $noncestr;
        $apppay['timestamp'] = $timestamp;
        $apppay['package'] = "Sign=WXPay";
        $apppay['sign'] = getSign($apppay);
        echo json_encode($apppay);
        exit;
    }

    if(INC_WECHAT){

        $openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
        $input->SetOpenid($openid);
        $order = WxPayApiSF::unifiedOrder($input);
        try
        {
            $jsApiParameters = $tools->GetJsApiParameters($order);
        }catch (Exception $e){
            $jsApiParameters = json_encode(array('error' => $e->getMessage()));
            $jsApiParameters = diconv($jsApiParameters, 'utf-8');
        }
        echo $jsApiParameters;
        exit;
    }else{
//        $errmsg = diconv(lang('plugin/xigua_c', 'inchat'), CHARSET, 'UTF-8');
//        echo json_encode(array('error' => $errmsg));
        $input->SetProduct_id($order_id);
        $result = $notify->GetPayUrl($input);
        $url2 = $result["code_url"];

        if(!$url2){
            $errmsg = $result['return_msg'];
            echo json_encode(array('error' => $errmsg));
        }else{
            $src = 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text='.urlencode($url2);
            echo json_encode(array('error' => '', 'qrurl' => $src, 'order_id' => $order_id));
        }

        exit;
    }
}else if($_GET['checkbox1'] == 'cardid'){
    if(submitcheck('cardid')){
        if(!$_GET['cardid']) {
            echo json_encode(array('error' => diconv(lang('message','memcp_credits_card_msg_cardid_incorrect'), CHARSET,'utf-8') ));exit;
        }
        if(!($card = C::t('common_card')->fetch($_GET['cardid']))) {
            echo json_encode(array('error' => diconv(lang('message','memcp_credits_card_msg_card_unfined'), CHARSET,'utf-8') ));exit;
        } else {
            if($card['status'] == 2) {
                echo json_encode(array('error' => diconv(lang('message','memcp_credits_card_msg_used'), CHARSET,'utf-8') ));exit;
            }
            if($card['cleardateline'] < TIMESTAMP) {
                echo json_encode(array('error' => diconv(lang('message','memcp_credits_card_msg_cleardateline_early'), CHARSET,'utf-8') ));exit;
            }
            C::t('common_card')->update($card['id'], array('status' => 2, 'uid' => $_G['uid'], 'useddateline' => $_G['timestamp']));
            updatemembercount($_G[uid], array($card['extcreditskey'] => $card['extcreditsval']), true, 'CDC', 1);

            echo json_encode(array('error' => diconv(lang('plugin/xigua_c', 'csucceed'), CHARSET,'utf-8') ));exit;
        }
    }else{
        echo json_encode(array('error' => diconv(lang('message','memcp_credits_card_msg_cardid_incorrect'), CHARSET,'utf-8') ));exit;
    }
}else{

    require_once DISCUZ_ROOT.'./api/trade/api_alipay.php';
    $notify_url = $_G['siteurl']. 'source/plugin/xigua_c/notify_ali.inc.php';        //�������첽֪ͨҳ��·��

    if(checkmobile()){

        $alipay_config['partner']       = DISCUZ_PARTNER;
        $alipay_config['key']           = DISCUZ_SECURITYCODE;
        $alipay_config['sign_type']     = strtoupper('MD5');;
        $alipay_config['input_charset'] = strtolower('utf-8');
        $alipay_config['cacert']        = DISCUZ_ROOT.'source/plugin/xigua_c/lib/alipay_m/cacert.pem';
        $alipay_config['transport']     = 'http';
        $seller_email                   = $_G['setting']['ec_account'];
        $format                         = "xml";  //���ظ�ʽ
        $v                              = "2.0";   //���ظ�ʽ
        $req_id                         = date('Ymdhis'); //�����
        $call_back_url = $notify_url; //ҳ����תͬ��֪ͨҳ��·��
        $merchant_url =  $notify_url.'?back='.urlencode($_G['siteurl']."plugin.php?id=xigua_c");//�����жϷ��ص�ַ

        //����ҵ�������ϸ
        $req_data = '<direct_trade_create_req><notify_url>' . $notify_url . '</notify_url><call_back_url>' . $call_back_url . '</call_back_url><seller_account_name>' . $seller_email . '</seller_account_name><out_trade_no>' . $order_id . '</out_trade_no><subject>' . $subject . '</subject><total_fee>' . ($price/100) . '</total_fee><merchant_url>' . $merchant_url . '</merchant_url></direct_trade_create_req>';

//����Ҫ����Ĳ������飬����Ķ�
        $para_token = array(
            "service" => "alipay.wap.trade.create.direct",
            "partner" => trim($alipay_config['partner']),
            "sec_id"    => trim($alipay_config['sign_type']),
            "format"	=> $format,
            "v"	=> $v,
            "req_id"	=> $req_id,
            "req_data"	=> $req_data,
            "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
        );
        include_once DISCUZ_ROOT.'source/plugin/xigua_c/lib/alipay_m/AlipaySubmit.php';
        //��������
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestHttp($para_token);
        //URLDECODE���ص���Ϣ
        $html_text = urldecode($html_text);
        //����Զ��ģ���ύ�󷵻ص���Ϣ
        $para_html_text = $alipaySubmit->parseResponse($html_text);

        //��ȡrequest_token
        $request_token = $para_html_text['request_token'];

        //ҵ����ϸ
        $req_data = '<auth_and_execute_req><request_token>' . $request_token . '</request_token></auth_and_execute_req>';


        //����Ҫ����Ĳ������飬����Ķ�
        $parameter = array(
            "service" => "alipay.wap.auth.authAndExecute",
            "partner" => trim($alipay_config['partner']),
            "sec_id" => trim($alipay_config['sign_type']),
            "format"	=> $format,
            "v"	=> $v,
            "req_id"	=> $req_id,
            "req_data"	=> $req_data,
            "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
        );


        //��������
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestForm($parameter, 'get', lang('plugin/xigua_c', 'qr'));
        echo $html_text;

    }else{

        $args = array(
            'subject'           => $body,
            'body'              => $body,
            'service'           => 'trade_create_by_buyer',
            'partner'           => DISCUZ_PARTNER,
            'notify_url'        => $notify_url,
            'return_url'        => $notify_url,
            'show_url'          => $_G['siteurl'],
            '_input_charset'    => 'UTF-8',
            'out_trade_no'      => $order_id,
            'price'             => $price/100,
            'quantity'          => 1,
            'seller_email'      => $_G['setting']['ec_account'],
            'extend_param'      => 'isv^dz11'
        );
        if(DISCUZ_DIRECTPAY) {
            $args['service'] = 'create_direct_pay_by_user';
            $args['payment_type'] = '1';
        } else {
            $args['logistics_type'] = 'EXPRESS';
            $args['logistics_fee'] = 0;
            $args['logistics_payment'] = 'SELLER_PAY';
            $args['payment_type'] = 1;
        }
        $link = trade_returnurl($args);
        dheader('location: ' . $link);
        exit;
    }
}