<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/7/30
 * Time: 19:44
 */

include_once DISCUZ_ROOT .'source/plugin/xigua_c/common.php';

if(!$_G['uid']){
    $loginurl = $_G['siteurl'].'member.php?mod=logging&action=login&mobile=2';
    if(INC_WECHAT){
        if($_G['cache']['plugin']['xigua_login']){
            $loginurl = $_G['siteurl'].'plugin.php?id=xigua_login:login&backreferer='.urlencode(current_url());
        }
    }
    dheader('Location: '.$loginurl);
}

$wxpay = $config['appid'] && $config['appsecert'] && $config['key'];


if(INC_WECHAT && $wxpay){
    $openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
    if(! $openid){
        $tools = new JsApiPaySF();
        $opendata = $tools->GetFollowOpenid();
        if($openid = $opendata['openid']){
            dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 8640000);
        }else{
            $url = str_replace('oauth=yes', '', current_url());
            dheader('Location:'.$url);
        }
    }
}
//loadcache('creditrule');
//print_r($_G['cache']['creditrule']);
$creditsformulaexp = str_replace('*', 'X', $_G['setting']['creditsformulaexp']);
$creditype = $_G['setting']['extcredits'][$config['ctype']]['title'];
$creditunit = $_G['setting']['extcredits'][$config['ctype']]['unit'];

$showct = explode('|', trim($config['showct']));


if($_GET['ac'] == 'order'){

    
    $res = C::t('#xigua_c#xigua_c_order')->fetch_all_paid_bypage($_G['uid'], 0, 200);
    $icount = C::t('#xigua_c#xigua_c_order')->fetch_count_paid_bypage($_G['uid']);
    
    
    $navtitle = lang('plugin/xigua_c', 'myorder_title');
    include template('xigua_c:my_order');
}else{
    $navtitle = $config['title'] ? $config['title']: lang('plugin/xigua_c', 'jifen');
    if($_REQUEST['op']=='credit') {
    }else{
        include template('xigua_c:credit_buy');
    }
}