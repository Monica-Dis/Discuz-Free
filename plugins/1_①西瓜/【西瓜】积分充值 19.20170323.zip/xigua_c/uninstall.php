<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/8/3
 * Time: 0:21
 */

$sql = <<<EOT
  DROP TABLE pre_xigua_c_order;
EOT;

if($sql){
    runquery($sql);
}


$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_c/discuz_plugin_xigua_c.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_c/discuz_plugin_xigua_c_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_c/discuz_plugin_xigua_c_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_c/discuz_plugin_xigua_c_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_c/discuz_plugin_xigua_c_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_c/install.php');

xwb_delall(DISCUZ_ROOT . "./source/plugin/xigua_c");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_c");


function xwb_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwb_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}