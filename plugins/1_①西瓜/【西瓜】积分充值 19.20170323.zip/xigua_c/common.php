<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/22
 * Time: 16:38
 */

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!function_exists('curl_init')){
    exit('Missing curl extension! QQ: DisM.Taobao.Com');
}
if(!function_exists('openssl_csr_export')){
    exit('Missing openssl extension! QQ: DisM.Taobao.Com');
}

$pluginversion = '20160201';

global $_G;
if(!$_G['cache']['plugin']){
    loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_c'];
$authkey = $_G['config']['security']['authkey'];

include_once libfile('function/cache');

if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false) {
    define('SF_APPID', trim($config['appappid']));
    define('SF_MCHID', trim($config['appshanghuid']));
    define('SF_APPSECRET', trim($config['appappsecert']));
    define('SF_WXPAY_KEY', trim($config['appkey']));
}else{
define('SF_APPID', trim($config['appid']));
define('SF_MCHID', trim($config['shanghuid']));
define('SF_APPSECRET', trim($config['appsecert']));
define('SF_WXPAY_KEY', trim($config['key']));
}
define('SF_NOTIFY_URL', $_G['siteurl'].'source/plugin/xigua_c/notify.inc.php');
define('INC_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
define('INC_XIAOYUN', strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false);
$repath = './source/plugin/xigua_c/cache/';


include_once DISCUZ_ROOT."source/plugin/xigua_c/lib/wxpay/lib/WxPay.Config.php";
include_once DISCUZ_ROOT."source/plugin/xigua_c/lib/wxpay/lib/WxPay.Api.php";
include_once DISCUZ_ROOT."source/plugin/xigua_c/lib/wxpay/example/WxPay.JsApiPay.php";
include_once DISCUZ_ROOT.'source/plugin/xigua_c/lib/wxpay/example/WxPay.NativePay.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_c/lib/wxpay/example/log.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_c/lib/wxpay/lib/WxPay.Data.php';
$ckey  = substr(md5('cwechatopenid5'.$_G['siteurl'].SF_APPID.SF_MCHID.SF_APPSECRET), 0, 8);

if(!function_exists('current_url')) {
    function current_url() {
        $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
        $php_self = $_SERVER['PHP_SELF'] ? safe_replace($_SERVER['PHP_SELF']) : safe_replace($_SERVER['SCRIPT_NAME']);
        $path_info = isset($_SERVER['PATH_INFO']) ? safe_replace($_SERVER['PATH_INFO']) : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? safe_replace($_SERVER['REQUEST_URI']) : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.safe_replace($_SERVER['QUERY_STRING']) : $path_info);
        return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
    }
}

/**
 * @param $string
 * @return mixed
 */
if(!function_exists('safe_replace')) {
    function safe_replace($string) {
        $string = str_replace('%20','',$string);
        $string = str_replace('%27','',$string);
        $string = str_replace('%2527','',$string);
        $string = str_replace('*','',$string);
        $string = str_replace('"','&quot;',$string);
        $string = str_replace("'",'',$string);
        $string = str_replace('"','',$string);
        $string = str_replace(';','',$string);
        $string = str_replace('<','&lt;',$string);
        $string = str_replace('>','&gt;',$string);
        $string = str_replace("{",'',$string);
        $string = str_replace('}','',$string);
        $string = str_replace('\\','',$string);
        return $string;
    }
}
if(!function_exists('js_reajaxget')) {
    function js_reajaxget($link, $ext)
    {
        return '<a href="' . $link . '" onclick="ajaxget(\'' . $link . '\', \'gridtable\');return false;"' . $ext . '>';
    }
}

if(!function_exists('ToUrlParams')){
    function ToUrlParams($urlObj)
    {
        $buff = "";
        foreach ($urlObj as $k => $v)
        {
            $buff .= $k . "=" . $v . "&";
        }

        $buff = trim($buff, "&");
        return $buff;
    }
}

$apple = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPad')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPod')){
    $apple = 1;
}

$config['defaultje'] = explode(',', trim($config['defaultje']));
foreach ($config['defaultje'] as $item) {
    if ($item > 0) {
        $configary[] = $item;
    }
}