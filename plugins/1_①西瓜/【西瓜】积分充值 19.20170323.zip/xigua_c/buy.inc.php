<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/7/21
 * Time: 19:43
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$amount = intval($_GET['addfundamount']);
if(!$amount) {
    showmessage('memcp_credits_addfunds_msg_incorrect', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}
$language = lang('forum/misc');

if(($_G['setting']['ec_mincredits'] && $amount < $_G['setting']['ec_mincredits']) || ($_G['setting']['ec_maxcredits'] && $amount > $_G['setting']['ec_maxcredits'])) {
    showmessage('credits_addfunds_amount_invalid', '', array('ec_maxcredits' => $_G['setting']['ec_maxcredits'], 'ec_mincredits' => $_G['setting']['ec_mincredits']), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}

if($_G['setting']['ec_maxcreditspermonth']) {
    if(C::t('forum_order')->sum_amount_by_uid_submitdate_status($_G['uid'], $_G['timestamp'] - 2592000, array(2, 3)) + $amount > $_G['setting']['ec_maxcreditspermonth']) {
        showmessage('credits_addfunds_toomuch', '', array('ec_maxcreditspermonth' => $_G['setting']['ec_maxcreditspermonth']), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
    }
}

$price = round(($amount / $_G['setting']['ec_ratio'] * 100) / 100, 2);
$orderid = '';

require_once libfile('function/trade');
$requesturl = credit_payurl($price, $orderid, $_GET['bank_type']);

if(C::t('forum_order')->fetch($orderid)) {
    showmessage('credits_addfunds_order_invalid', '', array(), array('showdialog' => 1, 'showmsg' => true, 'closetime' => true));
}

C::t('forum_order')->insert(array(
    'orderid' => $orderid,
    'status' => '1',
    'uid' => $_G['uid'],
    'amount' => $amount,
    'price' => $price,
    'submitdate' => $_G['timestamp'],
));

if($_GET['bank_type'] == 'wxpay'){
    include template('common/header_ajax');
    echo '<script type="text/javascript">showWindow(\'wxpay_qrcode_box\',\'home.php?mod=spacecp&ac=credit&op=wxqrcode&url='.urlencode(authcode($requesturl."\t".$orderid, 'ENCODE')).'\',\'get\',0);</script>';
    include template('common/footer_ajax');
}else{
    include template('common/header_ajax');
    echo '<form id="payform" action="'.$requesturl.'" method="post"></form><script type="text/javascript" reload="1">$(\'payform\').submit();</script>';
    include template('common/footer_ajax');
}
dexit();