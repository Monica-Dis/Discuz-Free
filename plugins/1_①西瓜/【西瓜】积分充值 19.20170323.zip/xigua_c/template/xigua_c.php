<?php exit('hehehe!') ?>

<style>
    .exfm .pn strong{line-height:inherit}
</style>
    <form id="formc" method="get" action="plugin.php">
        <input type="hidden" name="id" value="xigua_c:pay" >
        <input type="hidden" name="formhash" value="{FORMHASH}" >

<div class="exfm">
    <table cellspacing="0" cellpadding="0">
        <tbody><tr>
            <td>
                <input type="number" size="50" class="px form-control customform" onkeyup="changebtnval(this.value);" onafterpaste="changebtnval(this.value);" id="addfundamount" name="addfundamount" value="" placeholder="{$config[yuzhi]}"> {lang xigua_c:yuan}
            </td>
        </tr>
        <tr>
            <td>

                <input type="radio" class="weui_check" name="checkbox1" id="s12" checked="checked" value="wxpay">
                <img src="source/plugin/xigua_c/static/wec.png" style="vertical-align:middle" />

            </td>
        </tr>

        <tr>

            <td><button type="button" class="btn-orange btn pn" id="submitc" value="true"><strong>{lang xigua_c:chongzhi}{$creditype}</strong></button></td>
        </tr>
        <tr>

            <td>

                <div id="qr"></div>
            </td>
        </tr>
        </tbody></table>

    <input type="hidden" name="checkamount" id="checkamount" value="0" />
</div>
    </form>



<script src="source/plugin/xigua_c/static/jquery.min.js?{VERHASH}"></script>
<script>
jQuery.noConflict();
var cz = '{lang xigua_c:chongzhi}';
var tp = '$creditype';
function changebtnval(v){
    jQuery('#submitc strong').html(cz+(v*{$config['bilv']})+tp);
}

jQuery('#submitc').on('click', function(){
    var paytype = jQuery('input[name="checkbox1"]:checked').val();
    if(paytype != 'cardid' && jQuery('#addfundamount').val()<=0 && jQuery('#checkamount').val()<=0){
        alert('{lang xigua_c:pleasenotice}');
        return false;
    }
    if(paytype=='cardid'){
        if(!jQuery('#cardid').val()){
            alert("{echo lang('message','memcp_credits_card_msg_cardid_incorrect')}");
            return false;
        }
    }
    if(paytype == 'alipay'){
        jQuery('#formc').submit();
    }else{
        jQuery.ajax({
            url: 'plugin.php?id=xigua_c:pay',
            cache: false,
            dataType: "json",
            data: jQuery('#formc').serialize(),
            type: (paytype=='cardid' ?'POST' : "GET"),
            success:function(data){
                if(data.error){
                    alert(data.error);
                }else if(data.qrurl){
                    jQuery('#qr').html('<img src="'+data.qrurl+'" /><br>{lang xigua_c:sao}');
                    setInterval(function () {
                        jQuery.get('plugin.php?id=xigua_c:check&order_id='+data.order_id, function (data) {
                            if(data==1){
                                alert('{lang xigua_c:gongxi}');
                                window.location.href = 'home.php?mod=spacecp&ac=credit&op=log';
                            }
                        });
                    }, 3000);
                }
            }
        });
    }
    return false;
});
</script>
</body>
</html>