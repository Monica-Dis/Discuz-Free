<?php exit('hehehe!') ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport"
          content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <link href="source/plugin/xigua_c/static/common.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_c/static/iconfont.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_c/static/weui.css?{VERHASH}" rel="stylesheet"/>
    <script src="source/plugin/xigua_c/static/jquery.min.js?{VERHASH}"></script>
    <script src="source/plugin/xigua_c/static/custom.js?{VERHASH}"></script>
    <!--{if $config[bgcolor]}-->
    <style>
        .topavatar{background:{$config[bgcolor]}}
        .ullist li p span{color:{$config[bgcolor]}}
        .btn-orange{background-color:{$config[bgcolor]}}
    </style>
    <!--{/if}-->
</head>
<body>
<div id="page-loading-overlay">
    <div class="ajxloading"></div>
</div>
<div class="topnav cl">
    <!--{if INC_WECHAT && $apple}-->
    <!--{else}-->
    <!--{if !INC_XIAOYUN}-->
    <a class="home-return" href="javascript:window.history.go(-1);">{lang xigua_c:back}</a>
    <!--{/if}-->
    <!--{/if}-->
    <a class="myorder" href="plugin.php?id=xigua_c">{lang xigua_c:jifen}</a>
</div>
<div class="container_map_ami container_map">
    <div class="topavatar">
        <div class="pa">
            <div class="avatarimg">
                <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><img src="{avatar($_G[uid], 'middle', 1)}"></a>
            </div>
            <span class="username">{$_G[username]}</span>


            <div class="creditid "><ul class="cl">
                    <!--{eval $creditid=0;}-->
                    <!--{if $_G['setting']['creditstrans']}-->
                    <!--{eval $creditid=$_G['setting']['creditstrans'];}-->
                    <!--{if $_G['setting']['extcredits'][$creditid]}-->
                    <!--{eval $credit=$_G['setting']['extcredits'][$creditid]; }-->
                    <!--{if $showct && in_array($credit[title] ,$showct) }-->
                    <li class="cl"><em><!--{if $credit[img]}-->{$credit[img]}<!--{/if}-->{$credit[title]}</em> <!--{echo getuserprofile('extcredits'.$creditid);}-->{$credit[unit]}</li>
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{loop $_G['setting']['extcredits'] $id $credit}-->
                    <!--{if $id!=$creditid}-->
                    <!--{if $showct && in_array($credit[title] ,$showct) }-->
                    <li><em><!--{if $credit[img]}-->{$credit[img]}<!--{/if}-->{$credit[title]}</em> <!--{echo getuserprofile('extcredits'.$id);}-->{$credit[unit]}</li>
                    <!--{/if}-->
                    <!--{/if}-->
                    <!--{/loop}-->
                    <li style="display:none"><em>{lang credits}</em>$_G['member']['credits']<!--<span class="xg1">( $creditsformulaexp )</span>--></li>
                </ul>
            </div>
        </div>
    </div>


    <ul class="weui_cells ullist">
        <!--{if $res}-->
        <!--{loop $res $k $v}-->
        <li class="weui_cell cl">
<!--            <p>{$v[order_id]}</p>-->
            <p>{$v[crts]}</p>
            <p> <span>{$v[price]}</span><span>{$v[credit]}</span></p>
        </li>
        <!--{/loop}-->
        <!--{else}-->
        <li class="weui_cell cl" style="text-align:center">
            <p style="width:100%">{lang xigua_c:none}</p>
        </li>
        <!--{/if}-->
    </ul>

</div>
<div id="backtotop" class="backtotop"><span class="icon-vertical-align-top"></span></div>
</body>
</html>