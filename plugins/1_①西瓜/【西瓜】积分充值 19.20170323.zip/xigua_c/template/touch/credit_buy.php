<?php exit('hehehe!') ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport"
          content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <link href="source/plugin/xigua_c/static/common.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_c/static/iconfont.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_c/static/weui.css?{VERHASH}" rel="stylesheet"/>
    <script src="source/plugin/xigua_c/static/jquery.min.js?{VERHASH}"></script>
    <script src="source/plugin/xigua_c/static/custom.js?{VERHASH}"></script>
    <!--{if $config[bgcolor]}-->
    <style>
        .topavatar{background:{$config[bgcolor]}}
        .ullist li p span{color:{$config[bgcolor]}}
        .btn-orange{background-color:{$config[bgcolor]}}
    </style>
    <!--{/if}-->
</head>
<body>
<div id="page-loading-overlay">
    <div class="ajxloading"></div>
</div>
<div class="topnav cl">
    <!--{if INC_WECHAT && $apple}-->
    <!--{else}-->
    <!--{if !INC_XIAOYUN}-->
    <a class="home-return" href="javascript:window.history.go(-1);">{lang xigua_c:back}</a>
    <!--{/if}-->
    <!--{/if}-->
    <a class="myorder" href="plugin.php?id=xigua_c&ac=order">{lang xigua_c:myorder}</a>
</div>
<div class="container_map_ami container_map">
    <div class="topavatar">
        <div class="pa">
            <div class="avatarimg">
                <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><img src="{avatar($_G[uid], 'middle', 1)}"></a>
            </div>
            <span class="username">{$_G[username]}</span>

            <div class="creditid "><ul class="cl">
            <!--{eval $creditid=0;}-->
            <!--{if $_G['setting']['creditstrans']}-->
            <!--{eval $creditid=$_G['setting']['creditstrans'];}-->
            <!--{if $_G['setting']['extcredits'][$creditid]}-->
            <!--{eval $credit=$_G['setting']['extcredits'][$creditid]; }-->
                    <!--{if $showct && in_array($credit[title] ,$showct) }-->
            <li class="cl"><em><!--{if $credit[img]}-->{$credit[img]}<!--{/if}-->{$credit[title]}</em> <!--{echo getuserprofile('extcredits'.$creditid);}-->{$credit[unit]}</li>
                    <!--{/if}-->
            <!--{/if}-->
            <!--{/if}-->
            <!--{loop $_G['setting']['extcredits'] $id $credit}-->
            <!--{if $id!=$creditid}-->
                    <!--{if $showct && in_array($credit[title] ,$showct) }-->
            <li><em><!--{if $credit[img]}-->{$credit[img]}<!--{/if}-->{$credit[title]}</em> <!--{echo getuserprofile('extcredits'.$id);}-->{$credit[unit]}</li>
                    <!--{/if}-->
            <!--{/if}-->
            <!--{/loop}-->
            <li style="display:none"><em>{lang credits}</em>$_G['member']['credits']<!--<span class="xg1">( $creditsformulaexp )</span>--></li>
                </ul>
            </div>
        </div>
    </div>

    <form id="formc" method="get" action="plugin.php">
        <input type="hidden" name="id" value="xigua_c:pay" >
        <input type="hidden" name="formhash" value="{FORMHASH}" >
    <div class="zlistwrap">
        <div class="zlistbox">
            <div class="zlist">
                <!--{eval $count=1;}-->
                <!--{loop $configary $k $v}-->
                <div class="zitem" data-p="{$v}"><em>$v</em> <span>{lang xigua_c:yuan}</span></div>
                <!--{if $count%3==0}-->
            </div>
            <div class="zlist">
                <!--{/if}-->
                <!--{eval $count++}-->
                <!--{/loop}-->
            </div>
            <div class="zlist cl">
                <a class="centera">{lang xigua_c:other}</a>
            </div>
            <div class="zlist cl" id="centerarea" style="display:none">
                <p class="customtxt">{lang xigua_c:jine}</p>
                <input type="number" size="5" class="form-control customform" onkeyup="if(this.value.length==1){this.value=this.value.replace(/[^1-9]/g,'')}else{this.value=this.value.replace(/\D/g,'')};changebtnval(this.value);" onafterpaste="if(this.value.length==1){this.value=this.value.replace(/[^1-9]/g,'')}else{this.value=this.value.replace(/\D/g,'')}" id="addfundamount" name="addfundamount" value="" placeholder="{$config[yuzhi]}">
            </div>


            <div class="weui_cells weui_cells_checkbox">
                <!--{if $config[openalipay]}-->
                <label class="weui_cell weui_check_label" for="s11">
                    <div class="weui_cell_bd weui_cell_primary">
                        <p><i class="icon iconfont icon-zhifubao"></i> <span>{lang xigua_c:alipay}</span></p>
                    </div>
                    <div class="weui_cell_hd">
                        <input type="radio" class="weui_check" name="checkbox1" id="s11" <!--{if !INC_WECHAT}-->checked="checked"<!--{/if}--> value="alipay">
                        <i class="weui_icon_checked"></i>
                    </div>
                </label>
                <!--{/if}-->
                <!--{if $wxpay}-->
                <label class="weui_cell weui_check_label" for="s12">
                    <div class="weui_cell_bd weui_cell_primary">
                        <p><i class="icon iconfont icon-weixinzhifu2"></i> <span>{lang xigua_c:wxpay}</span></p>
                    </div>
                    <div class="weui_cell_hd">
                        <input type="radio" class="weui_check" name="checkbox1" id="s12" <!--{if INC_WECHAT}-->checked="checked"<!--{/if}--> value="wxpay">
                        <i class="weui_icon_checked"></i>
                    </div>
                </label>
                <!--{/if}-->
                <!--{if $config[opencard]}-->
                <label class="weui_cell weui_check_label" for="s13">
                    <div class="weui_cell_bd weui_cell_primary">
                        <p><i class="icon iconfont icon-duihao"></i> <span>{lang xigua_c:card_credit}</span></p>
                    </div>
                    <div class="weui_cell_hd">
                        <input type="radio" class="weui_check" name="checkbox1" id="s13" value="cardid">
                        <i class="weui_icon_checked"></i>
                    </div>
                </label>
                <!--{/if}-->
            </div>

            <div class="zlist cl" id="cardidarea" style="display:none">
<!--                <p class="customtxt">{lang xigua_c:chongzhika}</p>-->
                <input type="text" size="5" class="form-control customform" style="padding-left:10px!important;"  id="cardid" name="cardid" value="" placeholder="{lang xigua_c:card_credit}">
            </div>

            <div id="qr" style="text-align:center"></div>
            <input type="hidden" name="checkamount" id="checkamount" value="0" />
            <input type="button" class="btn-orange btn" id="submitc" value="{lang xigua_c:chongzhi}{$creditype}"/>
        </div>
    </div>
    </form>

</div>
<div id="backtotop" class="backtotop"><span class="icon-vertical-align-top"></span></div>
<script>
var cz = '{lang xigua_c:chongzhi}';
var tp = '$creditype';
function changebtnval(v){
    $('#submitc').val(cz+(v*{$config['bilv']})+tp);
}
<!--{if $config[opencard]}-->
setInterval(function () {
    if($('input[name="checkbox1"]:checked').val()=='cardid'){
        $('#cardidarea').show();
    }else{
        $('#cardidarea').hide();
    }
}, 100);
<!--{/if}-->

$('#submitc').on('click', function(){
    var paytype = $('input[name="checkbox1"]:checked').val();
    if(paytype != 'cardid' && $('#addfundamount').val()<=0 && $('#checkamount').val()<=0){
        alert('{lang xigua_c:pleasenotice}');
        return false;
    }
    if(paytype=='cardid'){
        if(!$('#cardid').val()){
            alert("{echo lang('message','memcp_credits_card_msg_cardid_incorrect')}");
            return false;
        }
    }
    if(paytype == 'alipay'){
        $('#formc').submit();
    }else{
        $.ajax({
            url: 'plugin.php?id=xigua_c:pay',
            cache: false,
            dataType: "json",
            data: $('#formc').serialize(),
            type: (paytype=='cardid' ?'POST' : "GET"),
            success:function(data){
                if(data.error){
                    alert(data.error);
                }else if(data.qrurl){
                    $('#qr').html('<img src="'+data.qrurl+'" />');
                }else{
                    callpay(data);
                }
            }
        });
    }
    return false;
});
function callpay(kapi){
    <!--{if strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false}-->
    payWechat(kapi);
    connectAppbymeJavascriptBridge(function(bridge){
        payWechat(kapi);
    });
    <!--{else}-->
    if (typeof WeixinJSBridge == "undefined"){
        if( document.addEventListener ){
            document.addEventListener('WeixinJSBridgeReady', function(kapi){jsApiCall(kapi);}, false);
        }else if (document.attachEvent){
            document.attachEvent('WeixinJSBridgeReady', function(kapi){jsApiCall(kapi);});
            document.attachEvent('onWeixinJSBridgeReady', function(kapi){jsApiCall(kapi);});
        }
    }else{
        jsApiCall(kapi);
    }
    <!--{/if}-->
}
function jsApiCall(apiKey) {
    WeixinJSBridge.invoke(
        'getBrandWCPayRequest',
        apiKey,
        function(res){
            if(res.err_msg == 'get_brand_wcpay_request:ok'){
                window.location.href = <!--{if $config[autolink]}-->'$config[autolink]'<!--{else}-->'plugin.php?id=xigua_c&ac=order'<!--{/if}-->;
            }else{}
        }
    );
}
</script>

<script src="https://market-cdn.app.xiaoyun.com/release/sq-2.3.js"></script>
<script type="text/javascript">
    function payWechat(kapi){
        var payParam ={
            appid:kapi.appid,
            partnerid:kapi.partnerid,
            prepayid:kapi.prepayid,
            attach:'Sign=WXPay',
            noncestr:kapi.noncestr,
            timestamp:kapi.timestamp,
            sign:kapi.sign
        };
        AppbymeJavascriptBridge.payRequest(function(data){
            //�ص�  type:֧��ƽ̨  1��΢��
            if(data.errCode == '0'){
                //alert(data.errInfo);

                top.location.href='{$_G[siteurl]}plugin.php?id=xigua_c&ac=order';

            }else{

                alert(data.errInfo);

                top.location.href='{$_G[siteurl]}plugin.php?id=xigua_c&ac=order';

            }

        },1,JSON.stringify(payParam));
        wxpay();
    }
</script>
</body>
</html>