<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2015/11/3
 * Time: 15:09
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_c_order extends discuz_table
{
    CONST PAYWAIT = 0;
    CONST PAYSUCCESS = 1;
    CONST PAYFAUIL = 2;
    CONST WXPAY = 'wxpay';
    CONST ALIPAY = 'alipay';

    public function __construct()
    {
        $this->_table = 'xigua_c_order';
        $this->_pk = 'order_id';

        parent::__construct();
    }

    public function get_order_id($uid, $openid, $baseprice, $credit, $creditype, $paymethod, $subject)
    {
        $order = array(
            'order_id' => date('YmdHis') . mt_rand(1000000, 9999999),
            'uid'      => $uid,
            'openid'   => $openid,
            'price'    => $baseprice,
            'credit'   => $credit,
            'creditype' => $creditype,
            'crts'      => TIMESTAMP,
            'payupts'   => 0,
            'paystatus' => self::PAYWAIT,
            'paymethod' => $paymethod,
            'subject'   => $subject,

        );
        if ($this->insert($order)) {
            return $order['order_id'];
        }
    }

    public function fetch_by_order_id($order_id)
    {
        return $this->fetch($order_id);
    }

    public function finish_order_pay($order_id, $fromopenid, $order_sn, $paymethod = self::WXPAY)
    {
        return $this->update($order_id, array(
            'paystatus' => self::PAYSUCCESS,
            'openid'    => $fromopenid,
            'payupts'   => TIMESTAMP,
            'paymethod' => $paymethod,
            'order_sn'  => $order_sn,
        ));
    }


    public function clear_order()
    {
        return DB::delete($this->_table, array('paystatus' => self::PAYWAIT));
    }

    public function delete_order($ids)
    {
        return DB::query('DELETE FROM %t WHERE order_id IN (%n)', array($this->_table, $ids));
    }


    public function fetch_all_bypage($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_count_bypage()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }


    public function fetch_all_paid_bypage($uid, $start_limit, $lpp)
    {
        global $_G;
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE uid=$uid AND paystatus=".self::PAYSUCCESS." ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $k => $v) {
            $result[$k]['crts'] = date('Y-m-d H:i', $v['crts']);
            $v['price'] = sprintf('%.2f', $v['price']/100);
            $result[$k]['price'] = '-' . $v['price'] . ''. lang('plugin/xigua_c','yuan');
            $creditype = $_G['setting']['extcredits'][$v['creditype']]['title'];
            $creditunit = $_G['setting']['extcredits'][$v['creditype']]['unit'];

            $result[$k]['credit'] = '+'.$creditype.' '. $v['credit'] . ' '. $creditunit;
        }
        return $result;
    }

    public function fetch_count_paid_bypage($uid)
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table). " WHERE uid=$uid AND paystatus=".self::PAYSUCCESS);
        return $result;
    }

}