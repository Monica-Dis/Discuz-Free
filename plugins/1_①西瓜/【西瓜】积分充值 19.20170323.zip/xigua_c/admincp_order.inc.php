<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(submitcheck('clear')){
    $r = C::t('#xigua_c#xigua_c_order')->clear_order();
    if($r){
        cpmsg(lang('plugin/xigua_c', 'clear_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_c&pmod=admincp_order&page=".$_GET['page'], 'succeed');
    }
}
if(submitcheck('permsubmit')){
    $r = C::t('#xigua_c#xigua_c_order')->delete_order($_GET['delete']);
    if($r){
        cpmsg(lang('plugin/xigua_c', 'delete_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_c&pmod=admincp_order&page=".$_GET['page'], 'succeed');
    }
}
showtips(str_replace('{siteurl}', $_G['siteurl'], lang('plugin/xigua_c','help')));

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_c&pmod=admincp_order&page=".$_GET['page']);
showtableheader(lang('plugin/xigua_c','dorder'));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_c','del'),
    lang('plugin/xigua_c','orderid'),
    lang('plugin/xigua_c','wenzhangming'),
    lang('plugin/xigua_c','orderprice'),
    lang('plugin/xigua_c','crtype'),
    lang('plugin/xigua_c','shouru'),
    lang('plugin/xigua_c','status'),
    lang('plugin/xigua_c', 'method'),
    lang('plugin/xigua_c', 'ordersn'),
    lang('plugin/xigua_c','crts'),
    lang('plugin/xigua_c','upts'),
));
$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;
$res = C::t('#xigua_c#xigua_c_order')->fetch_all_bypage($start_limit, $lpp);
$icount = C::t('#xigua_c#xigua_c_order')->fetch_count_bypage();

foreach ($res as $v) {
    if($v['uid']){
        $uids[$v['uid']] = $v['uid'];
    }
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}


foreach ($res as $re) {
    $re['price'] = sprintf('%.2f', $re['price']/100);

    $paymethod = '';
    $paymethods = array(
        table_xigua_c_order::WXPAY => 'wec.png',
        table_xigua_c_order::ALIPAY => 'alp.png',
    );
    if($paymethods[$re['paymethod']]){
        $paymethod = $_G['siteurl'].'source/plugin/xigua_c/static/'.$paymethods[$re['paymethod']];
        $paymethod =  "<img style='height:20px' src='$paymethod' />";
    }
    $creditype = $_G['setting']['extcredits'][$re['creditype']]['title'];
    $creditunit = $_G['setting']['extcredits'][$re['creditype']]['unit'];

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='{$re['order_id']}' />",
        $re['order_id'],
        $re['subject'],
        $re['price'],
        $creditype.' ' .$re['credit'] . ' '.$creditunit ,
        $users[$re['uid']] ?$users[$re['uid']]['username'] : '-',
        $re['paystatus'] ? '<strong style="color:forestgreen;">'.(lang('plugin/xigua_c','yi')) .'</strong>' : '<strong style="color:orangered;">'.(lang('plugin/xigua_c','wei')) .'</strong>',
        $paymethod,
        $re['order_sn'],
        date('m-d H:i:s', $re['crts']),
        $re['payupts'] ? date('m-d H:i:s', $re['payupts']) : '-',
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_c&pmod=admincp_order&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '<input type="hidden" name="clear" id="clear" value="0" /><input type="button" class="btn" onclick="$(\'clear\').value=1;$(\'cpform\').submit();" value="'.(lang('plugin/xigua_c','qingli')) .'">',$multipage);
showtablefooter();/*Dism��taobao-com*/
showformfooter();