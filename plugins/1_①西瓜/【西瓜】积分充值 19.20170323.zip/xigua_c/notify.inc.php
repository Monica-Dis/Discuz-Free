<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/27
 * Time: 21:56
 */


define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/xigua_c/', '',$_G['siteurl'] );
require_once 'common.php';


global $_G;
if(!$_G['cache']['plugin']){
    loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_c'];

$notifydata = sf_notifycheck();
if($notifydata['validator']) {

    $order_id  = $notifydata['order_no'];
    $postprice = $notifydata['price'];
    $order     = C::t('#xigua_c#xigua_c_order')->fetch_by_order_id($order_id);
    $creditype = $_G['setting']['extcredits'][$order['creditype']]['title'];
    $creditunit = $_G['setting']['extcredits'][$order['creditype']]['unit'];

    if(
        $order &&
        $order['paystatus'] == table_xigua_c_order::PAYWAIT
    ) {

        C::t('#xigua_c#xigua_c_order')->finish_order_pay($order_id, $notifydata['fromopenid'], $notifydata['trade_no'], table_xigua_c_order::WXPAY);

        updatemembercount($order['uid'], array($order['creditype'] => $order['credit']), 1, 'AFD', $order['uid']);
        updatecreditbyaction('tradefinished', $uid = 0, $extrasql = array(), $needle = '', $coef = 1, $update = 1, $fid = 0);

        notification_add(
            $order['uid'],
            'system',
            lang('plugin/xigua_c', 'czjl'),
            array(
                'orderid' => $order_id,
                'price'   => $postprice/100,
                'value'   => $creditype.' '.$order['credit'].' '.$creditunit,
            ),
            1
        );
    }

}
function sf_notifycheck() {
    global $_G;

    $msg = '';

    $notify = WxPayApiSF::notify($msg);

    if(empty($notify)){
        $return = array(
            'return_code'=>'FAIL',
            'return_msg'=>$msg,
        );
        WxPayApiSF::replyNotify(arr2xml($return));
        exit;
    }

    //checksign
    $sign = $notify['sign'];
    unset($notify['sign']);

    ksort($notify);
    $paramstring = ToUrlParams($notify);

    if(!$_G['cache']['plugin']){
        loadcache('plugin');
    }
    $config = $_G['cache']['plugin']['xigua_c'];

    if(strtoupper(md5($paramstring . "&key=".$config['appkey'])) != $sign){
        if(strtoupper(md5($paramstring . "&key=".$config['key'])) != $sign) {
            $return = array(
                'return_code' => 'FAIL',
                'return_msg' => 'sign error!',
            );
            WxPayApiSF::replyNotify(arr2xml($return));
            exit;
        }
    }
    if($notify['result_code'] == 'SUCCESS') {
        return array(
            'validator'  => isset($notify['result_code']) && $notify['result_code'] == 'SUCCESS' ? 1 : 0,
            'order_no'   => $notify['out_trade_no'],
            'trade_no'   => isset($notify['transaction_id']) ? $notify['transaction_id'] : '',
            'price'      => $notify['total_fee'],
            'appid'      => $notify['appid'],
            'notify'     => arr2xml(array('return_code'=>'SUCCESS')),
            'location'   => false,
            'fromopenid' => $notify['openid'],
        );
    }
}


function arr2xml($data){
    $xml = "<xml>";
    foreach ($data as $key=>$val)
    {
        if (is_numeric($val)){
            $xml.="<".$key.">".$val."</".$key.">";
        }else{
            $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
        }
    }
    $xml.="</xml>";
    return $xml;
}