<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2017/11/19
 * Time: 16:38
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hm/function.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";

$stypes = array('youhui' => lang_hm('youhui',0),'daijin'=>lang_hm('daijin',0),'zhekou'=>lang_hm('zhekou',0),'seckill' => lang_hm('seckill',0));
$statuss = array(
    '0' => lang_hm('shwg',0),
    '1' => lang_hm('ddsh',0),
    '2' => lang_hm('ysj',0),
    '3' => lang_hm('yxj',0)
);

function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}

$page = max(1, intval(getgpc('page')));
$lpp = $_GET['lpp'] ? $_GET['lpp'] : 20;
$start_limit = ($page - 1) * $lpp;


if (submitcheck('permsubmit')) {
    if ($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hm#xigua_hm_seckill_log')->deletes($delete);
    }

    if($r = $_GET['r']){
        foreach ($r as $cid => $ro) {
            $data = array(
                'code' => $ro['code'],
                'endts' => strtotime($r[$cid]['endts']),
            );
            /*$old_data = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch($cid);
            if($old_data['hxstatus'] == 0 && $old_data['hxstatus']!=$ro['hxstatus']){
               $data['hxstatus'] = $ro['hxstatus'];
               $data['hxcrts'] = TIMESTAMP;
               $data['hxuid'] = $_G['uid'];
            }*/
            if($ro['code']){
                C::t('#xigua_hm#xigua_hm_seckill_log')->update($cid, $data);
            }
        }
    }
    cpmsg(lang_hm('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckilllog&page=$page", 'succeed');
}

$wherearr = array();
$keyword = $_GET['keyword'];
if ($keyword = stripsearchkey($keyword)) {
    if(is_numeric($keyword) && strlen($keyword) == 11){
        $uid = DB::result_first('SELECT uid FROM %t WHERE mobile=%s ', array('xigua_hb_user', $keyword));
        $wherearr[] = "uid='$uid'";
    }else{
        $secids1 = array();
        foreach (DB::fetch_all("select id from ".DB::table('xigua_hm_seckill')." where title like '%$keyword%'") as $index => $_v) {
            $secids1[] = intval($_v['id']);
        }
        $oror = '';
        if($secids1){
            $oror = ' OR secid IN('.implode(',', $secids1).')';
        }
        $wherearr[] = " (uid='$keyword' OR shid='$keyword' OR order_id LIKE '%$keyword%' OR code LIKE '%$keyword%' OR ggname LIKE '%$keyword%' OR postinfo LIKE '%$keyword%' $oror) ";
    }
}
if(isset($_GET['status'])){
    $STA = $wherearr[] = 'status=' . intval($_GET['status']);

}
if(isset($_GET['stype']) && $stypes[$_GET['stype']]){
    $wherearr[] = 'stype=\'' . ($_GET['stype']).'\'';
}
if($secid = intval($_GET['secid'])){
    $wherearr[] = "secid='$secid'";
}
if($shid = intval($_GET['shid'])){
    $wherearr[] = "shid='$shid'";
}
$ob = 'id DESC';
if(isset($_GET['hxstatus'])){
    $hxstatus = intval($_GET['hxstatus']);
    $wherearr[] = "hxstatus='$hxstatus'";
    if($hxstatus == 1){
        $ob = 'hxcrts DESC';
    }
}

$ob = 'id DESC';

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckilllog&secid={$_GET['secid']}");

$hxs = array(
    0=>lang_hm('weihexiaofa',0),
        1=>lang_hm('yihexiaofa',0),
    /*'4' => lang_hm('ysh',0),
    '5' => lang_hm('tkz',0),*/
    '6' => lang_hm('ytk',0),
    '7' => lang_hm('zfcs',0),
);
echo '<div style="margin-top:3px"><input type="text" id="keyword" placeholder="'.lang_hm('search_log',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
foreach ($hxs as $index => $_v) {
    echo '<input type="radio" name="hxstatus" value="'.$index.'" ' . (isset($_GET['hxstatus'])&&$_GET['hxstatus']==$index&&$_GET['hxstatus']!=='' ? 'checked' : '') . ' />' . $_v;
}
echo '&nbsp;';
foreach ($stypes as $index => $_v) {
    echo '<input type="radio" name="stype" value="'.$index.'" ' . (isset($_GET['stype'])&&$_GET['stype']==$index ? 'checked' : '') . ' />' . $_v;
}
echo '&nbsp;&nbsp;&nbsp;';
$lpp_se = "<select name=\"lpp\">";
foreach (array(20, 50, 100, 200, 500, 1000, 2000, 3000, 4000, 5000, 8000, 10000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;
echo ' <br> '.lang_hb('shid',0).': <input type="text" class="txt" name="shid" value="' . $_GET['shid'] . '" /> ';


if($_GET['starttime1'] && $_GET['starttime2']){
    $stime1 = strtotime($_GET['starttime1']);
    $stime2 = strtotime($_GET['starttime2']);

    $wherearr[] = " (crts BETWEEN $stime1 AND $stime2 ) ";
}elseif ($_GET['starttime1'] ){
    $stime1 = strtotime($_GET['starttime1']);
    $wherearr[] = " (crts >= $stime1 ) ";
}elseif ($_GET['starttime2'] ){
    $stime2 = strtotime($_GET['starttime2']);
    $wherearr[] = " (crts <= $stime2 ) ";
}
$q1 = lang_hb('qssj',0);
$q2 = lang_hb('jssj',0);
echo  <<<HTML
$q1: <input type="text" id="starttime1" name="starttime1" placeholder="2011-01-01 00:00" value="{$_GET['starttime1']}" onclick="showcalendar(event, this, true)" class="txt" />
$q2: <input type="text" id="starttime2" name="starttime2" placeholder="2037-01-01 23:59" value="{$_GET['starttime2']}" onclick="showcalendar(event, this, true)" class="txt" />
HTML;

echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';

echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckilllog&doexport=1&keyword={$_GET['keyword']}".(isset($_GET['hxstatus']) ? "&hxstatus={$_GET['hxstatus']}":'')."&page=$page&lpp=$lpp&$STA&formhash=".formhash()."&lpp=$lpp&secid={$_GET['secid']}&stype={$_GET['stype']}&secid={$_GET['secid']}".' class="btn" >'.lang_hm('dc', 0).'</a> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckilllog&secid={$_GET['secid']}".' class="btn" >'.cplang('reset').'</a> ';



$res = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
$icount = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_count_by_page($wherearr);


$wherearr_tmp = $wherearr;
$wherearr_tmp[] = 'status=2';
$wheresql = !empty($wherearr_tmp) && is_array($wherearr_tmp) ? ' WHERE '.implode(' AND ', $wherearr_tmp) : '';
$allpaied = DB::result_first('SELECT  count(*) as c FROM ' . DB::table('xigua_hm_seckill_log').' '.$wheresql);
$wei = $icount - $allpaied;

$wherearr_tmp = $wherearr;
$wherearr_tmp[] = 'hxstatus=1';
$wheresql = !empty($wherearr_tmp) && is_array($wherearr_tmp) ? ' WHERE '.implode(' AND ', $wherearr_tmp) : '';
$allhx = DB::result_first('SELECT  count(*) as c FROM ' . DB::table('xigua_hm_seckill_log').' '.$wheresql);

$ddzs = lang_hm('ddzs', 0);
$ddzs1 = lang_hm('wfk', 0);
$ddzs2 = lang_hm('yfk', 0);
$ddzs3 = lang_hm('yhx', 0);

echo <<<HTML
<br>
<style>
 span.tj{color:orangered;font-weight:bold}
</style>

$ddzs: <span class="tj">$icount</span>

$ddzs1: <span class="tj">$wei</span>

$ddzs2: <span class="tj">$allpaied</span>

$ddzs3: <span class="tj">$allhx</span>

HTML;

echo '</div>';

showtableheader(lang_hm('fabuguanli', 0));
showtablerow('class="header"', array(), array(
    lang_hm('ID', 0),
    lang_hm('order_id', 0).'/'. lang_hm('crts', 0),
    lang_hm('mendian', 0).'<br>'.
    lang_hm('order_type', 0).'/'.lang_hm('ggname', 0),
    lang_hm('order_price', 0),
    lang_hm('order_recive', 0),
    lang_hm('num', 0),
    lang_hm('user', 0).'/'. lang_hm('mobile', 0),
    lang_hm('outdate', 0),
    lang_hm('hxstatus_danhao', 0),
    lang_hm('hxcrts', 0),
    lang_hm('hxuid', 0),
    lang_hm('tk', 0),
));

$secids = $shids = array();
foreach ($res as $v) {
    if ($v['uid']) {
        $uids[$v['uid']] = $v['uid'];
        $uids[$v['hxuid']] = $v['hxuid'];
    }
    $shids[$v['shid']] = $v['shid'];
    $secids[$v['secid']] = $v['secid'];
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $mobiles = DB::fetch_all('SELECT uid,mobile FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}

if($shids){
    $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
}
if($secids){
    $secinfos = DB::fetch_all('SELECT * FROM %t where id in(%n)', array('xigua_hm_seckill', $secids), 'id');
}

$order_ids = array();
foreach ($res as $re) {
    $order_ids[$re['order_id']] =$re['order_id'];
}
$orders = DB::fetch_all('SELECT * FROM %t WHERE order_id IN(%n)', array(
    'xigua_hb_order',$order_ids
), 'order_id');
foreach ($res as $k=> $v) {
    $id = $v['id'];

    if($orders[$v['order_id']]['paystatus']>0 && $v['hxstatus']==7) {
        DB::query("UPDATE %t SET status=2,tkts=0,hxstatus=0 WHERE id=%d AND status!=2 limit 1", array(
            'xigua_hm_seckill_log',
            $id
        ));
        DB::query("update %t set stock=stock-%d,hasqiang=hasqiang+%d WHERE {$this->_pk}=%d", array(
            $this->_table,
            1, 1,
            $v['secid'],
        ));
    }

    $hxstat = $v['hxstatus']==1?lang_hm('hashx',0):lang_hm('beenhx',0);

    $status_u = "<select name=\"r[$id][hxstatus]\">";
    foreach ($hxs as $kk => $vv) {
        if($v['hxstatus']== $kk){
            $s = 'selected';
        }else{
            $s = '';
        }
        $status_u .= "<option $s value=\"$kk\">$vv</option>";
    }
    $status_u .= '</select>';
//    $hxstat = $status_u;

    $dft = '';
    if($v['addrid']){
        $dft = C::t('#xigua_hb#xigua_hb_user_addr')->fetch($v['addrid']);

        if($potinfo = unserialize($v['postinfo'])){
            $hxstat = $potinfo['compnay'].'<br>'.lang_hm('danhao',0).':'.$potinfo['danhao'];
        }else{
            $hxstat = lang_hm('beenweifh',0);
        }
    }

    $red = '';
    if($v['hxstatus'] == 6){
        $red = '<em style="color:red">'.lang_hm('ytk',0).' '.date('Y-m-d H:i:s', $v['tkts']).'</em>'.
            ($v['refund'] ? '<br>'.lang_hm('zdtkxq',0).":".$v['refund']:'');
    }elseif ($v['hxstatus']==7){
        $red = '<em style="color:red">'.lang_hm('zfcs',0).' '.date('Y-m-d H:i:s', $v['tkts']).'</em>';
    }
    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
        ($status = ($v['order_id']? $v['order_id'] . '<br>'. ($orders[$v['order_id']]['order_sn'] ? $orders[$v['order_id']]['order_sn'].'<br>' :'') . ($orders[$v['order_id']]['paystatus']?'<strong style="color:forestgreen;">'.(lang('plugin/xigua_hb','yi')) .'</strong>' : '<strong style="color:orangered;">'.(lang('plugin/xigua_hb','wei')) .'</strong>'):'')) .'<br>'. (
            $v['crts']? date('Y-m-d H:i:s', $v['crts']) : ''),
        "[ID: {$v['shid']}] ".$shinfos[$v['shid']]['name'].'<br>'.
        $stypes[$v['stype']]."<br> <a href='".ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckilllog&secid={$v['secid']}"."'>{$secinfos[$v['secid']]['title']}</a><br>".
        $v['ggname'],
        $v['price'].lang_hm('yuan',0),
        $v['addrid'] ? lang_hm('shoujianren',0).":{$dft[realname]} {$dft[mobile]}<br>".lang_hm('shouhuodizhi',0).": {$dft[dist1]}{$dft[dist2]}{$dft[dist3]}{$dft[address]}<br>{$v['formggs']}<br>{$v['note']}" : (
            "<input style='width:100px' class=\"txt\" name=\"r[$id][code]\" value='{$v['code']}' />"
        ),
        $v['num'].lang_hm('fen', 0),
        ($res[$k]['user'] = "[UID:{$v['uid']}]". $users[$v['uid']]['username']).'<br>'.
        $mobiles[$v['uid']]['mobile'],
        ($v['endts']? "<input style='width:140px' class=\"txt\" name=\"r[$id][endts]\" value='".date('Y-m-d H:i:s', $v['endts'])."' />" : ''),
        $res[$k]['hxstatus'] = $hxstat,
        $res[$k]['hxcrts']  = $v['hxcrts']? date('Y-m-d H:i:s', $v['hxcrts']) : '',
        $res[$k]['hxuid']  = $v['hxuid'] ? "[UID:{$v['hxuid']}]". $users[$v['hxuid']]['username'] : '',
        $res[$k]['ytk']    = $red,
    ));

    $res[$k]['crts_u'] = date('Y-m-d H:i:s', $res[$k]['crts']);
    $res[$k]['status'] = strip_tags($status);
    $res[$k]['secid'] = $res[$k]['secid']  . " ". $secinfos[$v['secid']]['title'];
    $res[$k]['order_id'] = '['.$orders[$v['order_id']]['order_sn'].']';
    $res[$k]['mobile'] = $mobiles[$v['uid']]['mobile'];
    $res[$k]['stype'] = strip_tags($stypes[$v['stype']]);
    $res[$k]['ytk'] = strip_tags($res[$k]['ytk']);
    $res[$k]['postinfo'] = implode(' ', unserialize($res[$k]['postinfo'])) ." " . ($v['addrid'] ? lang_hm('shoujianren',0).":{$dft[realname]} {$dft[mobile]} ".lang_hm('shouhuodizhi',0).": {$dft[dist1]}{$dft[dist2]}{$dft[dist3]}{$dft[address]} {$v['formggs']} {$v['note']}" :'');
    unset($res[$k]['crts']);
    unset($res[$k]['endts']);
    unset($res[$k]['addrid']);
    unset($res[$k]['pay_endts']);
    unset($res[$k]['pay_endts_u']);
}

if(submitcheck('formhash', 1) && $_GET['doexport']==1 && $_GET['formhash'] == FORMHASH){
    $title_arr= array();
    foreach ($res[0] as $index => $item) {
        $title_arr[] = lang_hm($index, 0);
    }
    export_csv($res, $title_arr);
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckilllog&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', '', "", $multipage);
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/
?>
<script type="text/javascript" src="static/js/calendar.js"></script>
