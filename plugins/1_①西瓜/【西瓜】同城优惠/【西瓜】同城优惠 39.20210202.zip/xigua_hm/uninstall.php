<?php
/**
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
DROP TABLE pre_xigua_hm_seckill;
DROP TABLE pre_xigua_hm_seckill_log;
DROP TABLE pre_xigua_hm_income;
EOT;
runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/install.php');

xwb_delall(DISCUZ_ROOT . "./source/plugin/xigua_hm");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_hm");

$finish = TRUE;

function xwb_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwb_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}