<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=seckill" class="weui-navbar__item <!--{if !$_GET[status]&&!$_GET[hx]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hb:quanbu}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=seckill&status=-1" class="weui-navbar__item <!--{if $_GET[status]==-1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:wzf}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=seckill&status=2&hx=-1" class="weui-navbar__item <!--{if $_GET[hx]==-1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:wsy}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=seckill&status=2&hx=1" class="weui-navbar__item <!--{if $_GET[hx]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:ysy}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=seckill&status=1&hx=6" class="weui-navbar__item <!--{if $_GET[hx]==6}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:ytk}</span>
        </a>
    </div>

    <div  id="list" class="weui-cells p0 mt0 before_none"></div>
    <!--{template xigua_hb:loading}-->
    <!--{if $_GET[hx]==-1 && $hm_config[allowdhm]}-->
    <div class="fix-bottom" style="z-index:501">
        <a class="  weui-btn weui-btn_primary" href="javascript:;" onclick="return show_confirm('{lang xigua_hm:qsrdhm}', '', '', '');">{lang xigua_hm:sydhm}</a>
    </div>
    <!--{/if}-->
</div>

<script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>
<script>
var loadingurl = window.location.href+'&do=seckill_li&inajax=1&page=';
var noTit = true;
var loadingCallback = function () {
    $('.payctrl').each(function () {
        var that = $(this);
        hm_GetRunTime('', that.data('end'), that);
    });
}
</script>
<!--{eval $tabbar=1;}-->
<!--{template xigua_hb:common_footer}-->
<script>
    function show_confirm (title, code, time_u, num){
        $.prompt(title, "{lang xigua_hm:qrxf}", function(text) {
            $.showLoading();
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hm&ac=hx&inajax=1',
                data:{formhash:'{FORMHASH}', code : $('#weui-prompt-input').val()},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }, function() {
        });

        $('#weui-prompt-input').parent().before('<div style="margin-bottom:10px"><p>'+title+'</p>' +
            (time_u ? '<p>{lang xigua_hm:usetime}: <em style="color:#f60">'+time_u+'</em></p>':'') +
            (num ? '<p>{lang xigua_hm:hmsl}: <em style="color:#f60">'+num+'</em></p>' : '') +
            (code ? '<p>{lang xigua_hm:dhm}: <em style="color:#f60">'+code+'</em></p>' : '') +
            '</div>');
        $('#weui-prompt-input').replaceWith('<input class="weui-prompt-input needsclick weui-input needsclick_input" type="text" id="weui-prompt-input" placeholder="" value="'+code+'" />');
        document.getElementById('weui-prompt-input').focus();
    }

    $(document).on('click','.tkbtn', function () {
        var that = $(this);

        $.confirm({
            title: '{lang xigua_hm:qdtk}',
            text: '{lang xigua_hm:qdtk_tip}',
            onOK: function () {$.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_hm&ac=tk&inajax=1',
                    data:{formhash:'{FORMHASH}', logid : that.data('id')},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });

    });
</script>