<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}--><!--{if in_array($_GET['stype'],$kaquan_stype)}--><!--{eval $pub0 = "$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=quan&auto=1$urlext";}--><!--{else}--><!--{eval $pub0 = "$SCRITPTNAME?id=xigua_hm&ac=my_seckill&auto=1$urlext";}--><!--{/if}--><div class="page__bd">

<!--{if getcookie('miniprogram') && $ac=='index'}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if $ac=='index' && $config[showheader]}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if !$hide_nav}-->
<header class="x_header bgcolor_11 cl  weui-flex f15" <!--{if $config[intopindex]}-->style="background:transparent!important;position:absolute"<!--{/if}-->>
    <!--{if $_G['cache']['plugin']['xigua_st']['showfz']}-->
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_hm&mobile=2");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
    <!--{else}-->
    <a class="z x_logo" href="$SCRITPTNAME?id=xigua_hb"><!--{if strpos($config['logo'],'/')!==false}--><img src="$config[logo]" /> <!--{else}--><span style="margin:0 15px">$config[logo]</span><!--{/if}--></a><!--{/if}-->
    <form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
        <input type="hidden" name="id" value="xigua_hm">
        <input type="hidden" name="ac" value="index">
        <!--{loop $_GET $lk $loopin}-->
        <input type="hidden" name="$lk" value="$_GET[$lk]">
        <!--{/loop}-->
        <input type="hidden" name="st" value="$_GET[st]">
        <input type="hidden" name="idu" value="$_GET[idu]">
        <input name="keyword" class="x_logo_input" type="text" value="{$_GET['keyword']}" placeholder="$hm_config[indexkey]" x-webkit-speech="" <!--{if $config[intopindex]}-->style="background: rgba(255,255,255,.8)"<!--{/if}-->>
        <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
    </form>
</header>
<!--{if !$no_header_fix}-->
<div class="x_header_fix" <!--{if $config[intopindex]&&$ac=='index'}-->style="display:none"<!--{/if}-->></div>
<!--{/if}-->
<!--{/if}-->

<div class="hm_index_header">

    <!--{if $topnavslider}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $topnavslider $_lv}-->
            <div><a href="{$_lv[href]}"><img src="{$_lv[src]}" class="main-img"></a></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $topnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->


    <div class="weui-cells mt0 before_none">
        <div class="chip-row">
            <div class="toutiao"><i class="color-sec iconfont icon-hot-02"></i></div>
            <div class="toutiao-slider swiper-container swiper-container-vertical ml3" id="newsSlider" style="margin-right:0">
                <ul class="swiper-wrapper">
                    <!--{loop $toutiao $v}-->
                    <li class="swiper-slide"> <a href="$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid={$v[secid]}"><em class="main_color">{$v[user][username]}</em> <!--{if $secs[$v[secid]][stype]=='seckill'}-->{lang xigua_hm:gml}<!--{else}-->{lang xigua_hm:lql}<!--{/if}--> {$secs[$v[secid]][title]}</a> </li>
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="toutiao"><a class="f15" href="$SCRITPTNAME?id=xigua_hm&ac=my_order">{lang xigua_hm:wddd}</a></div>
        </div>
    </div>

    <!--{if $indexstype}-->
    <!--{eval
    $subkp = count($indexstype)==4?4:10;
    if($subkp==5||$subkp==10):
        $sty_li = "style='width:20%!important'";
    endif;
    }-->
    <nav class=" nav-list cl swipe transparent hm_nav mt3">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $indexstype $k $n}-->
                    <!--{if $k && $k%$subkp==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li {$sty_li}>
                        <a href="{$n[href]}">
                        <span><img src="{$n[src]}"/></span>
                        <em class="m-piclist-title <!--{if strpos($n['href'], $_GET['stype'])!==FALSE||($_GET['stype']=='seckill'&&strpos($n['href'],'good')===false&&strpos($n['href'],'stype')===false)}-->main_color<!--{/if}-->" >{$n[name]}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
    </nav>
    <!--{/if}-->
</div>

<!--{if $hm_config['fansqr']}-->
<div class="weui-cells before_none after_none">
    <div class="weui-cell h45">
        <div class="weui-cell__hd">
            <img class="h45" src="{$hm_config[fansicon]}" />
        </div>
        <div class="weui-cell__bd">
            <p class="f14 c3">{$hm_config[fanstitle]}</p>
            <p class="f12 c9">{$hm_config[fansdesc]}</p>
        </div>
        <div class="weui-cell__ft">
            <a href="javascript:;" class="weui-btn f14 main_bg indexguid" onclick='$.alert("<img class=\"w180\" src={$hm_config[fansqr]} />", "{$hm_config[fansqrtitle]}");'>{lang xigua_hm:wyjq}</a>
        </div>
    </div>
</div>
<!--{/if}-->

    <div class="weui-cells fixbanner before_none">
        <!--{if $hm_config['indexnavtype']==2}-->
        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="javascript:;" class="weui-navbar__item ajaxhmcat" data-id="0">
                <span>{lang xigua_hm:qb}{lang xigua_hm:hd}</span>
            </a>
            <a href="javascript:;" class="weui-navbar__item weui_bar__item_on ajaxhmcat" data-id="0&dtp=ing">
                <span>{lang xigua_hm:zzjx}</span>
            </a>
            <a href="javascript:;" class="weui-navbar__item ajaxhmcat" data-id="0&dtp=wangqi">
                <span>{lang xigua_hm:wqhg}</span>
            </a>
        </div>
        <!--{else}-->
        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="javascript:;" class="weui-navbar__item weui_bar__item_on ajaxhmcat" data-id="0">
                <span>{lang xigua_hm:qb}</span>
            </a>
            <!--{loop $cat_list $cat}-->
            <!--{if $cat[id]}-->
            <a href="javascript:;" class="weui-navbar__item ajaxhmcat" data-id="$cat[id]">
                <span>$cat[name]</span>
            </a>
            <!--{/if}-->
            <!--{/loop}-->
        </div><!--{/if}-->
    </div>

    <div class="mt0">
        <div id="list" class="mod-post x-postlist p0">

        </div>

        <!--{template xigua_hb:loading}-->
    </div>
</div>
<script>
    scrollto = 1;
    <!--{if $hm_config['indexnavtype']==2}-->
    var loadingurl = window.location.href+'&ac=seckill_li&inajax=1&dtp=ing&page=';
    <!--{else}-->
    var loadingurl = window.location.href+'&ac=seckill_li&inajax=1&page=';
    <!--{/if}-->
    var loadingCallback = function () {
        $('.hmt').each(function () {
            var that = $(this);
            hm_GetRunTime(that.data('start'),that.data('end'), that);
        });
    }
</script>

<!--{eval $config[setbuttom] = $config[setbuttom] ?$config[setbuttom] : lang_hm('yh',0)."|shijian|$SCRITPTNAME?id=xigua_hm|index";}-->
<!--{eval $tabbar=1;$hs_tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>
<!--{if $_G['cache']['plugin']['xigua_st']['showfz']}-->
<!--{if $_G['cache']['plugin']['xigua_hs']}-->
<!--{if $_G['cache']['plugin']['xigua_st']['dingwei'] && !getcookie('setcitygeo')}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script>
    function autolbshs(){
        hs_getlocation(function (position) {
            var citylat = (position.latitude||position.lat);
            var citylng = (position.longitude||position.lng);
            $.ajax({
                type: 'GET',
                url: _APPNAME + '?id=xigua_hs&ac=getloc&checkst=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
                dataType: 'xml',
                success: function (data) {
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    console.log(s);
                    var m = s.split('|');
                    if('success' == m[0]){
                        var _t = m[1].split(',');
                        console.log(_t);
                        if(_t[0]>0 && _t[0]!='{$_GET[st]}'){
                            $.confirm("{lang xigua_hb:dqdws}"+_t[1]+'{lang xigua_hb:setcitygeo2}', function() {
                                window.location.href = _APPNAME+"?id=xigua_hm&st="+_t[0];
                                hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                            }, function() {
                                hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                            });
                        }else{
                            hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                        }
                    }else{
                    }
                }
            });
        });
    }
    if(typeof wx!='undefined'){
        wx.ready(function () { autolbshs(); });
    }else{
        setTimeout(function(){ autolbshs(); }, 300);
    }
</script><!--{/if}--><!--{/if}-->
<!--{/if}-->