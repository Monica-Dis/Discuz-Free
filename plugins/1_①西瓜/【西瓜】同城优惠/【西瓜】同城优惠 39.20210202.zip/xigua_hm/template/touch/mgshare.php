<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if IN_MAGAPP}-->
<script>
    $(document).on('click','.mag_share', function () {
        var that = $(this);
        if(that.data('url')){
            var SHAREIMG = that.data('url');
            mag.setData({shareData: {
                    type: 1, imageurl:SHAREIMG, picurl:  SHAREIMG
                }});
            mag.share('ALL', function(res){},function(){ });
        }else{
            $.showLoading();
            html2canvas(document.querySelector(".shot_in")).then(canvas => {
                var dataURL = canvas.toDataURL();
                COMCLAS = 'shot_outer';
                hpp_doupload(dataURL);
                COMCLAS = '';
            });
        }
        return false;
    });

    function hpp_doupload(cmp_photo){
        var img = cmp_photo.split(',')[1];
        img = window.atob(img);
        var ia = new Uint8Array(img.length);
        for (var i = 0; i < img.length; i++) {
            ia[i] = img.charCodeAt(i);
        }
        var blob = new Blob([ia], {type:"image/jpeg"});
        var formdata=new FormData();
        formdata.append('file',blob);

        $.ajax({
            type: 'post',
            url: _APPNAME+'?id=xigua_hb&ac=uploader&do=tmp&inajax=1&formhash='+FORMHASH,
            data :  formdata,
            processData : false,
            contentType : false,
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    var SHAREIMG = s.split('|')[1];
                    mag.setData({shareData: {
                            type: 1, imageurl:SHAREIMG, picurl:  SHAREIMG
                        }});
                    mag.share('ALL', function(res){},function(){ });
                } else {
                    tip_common(s);
                }
            }
        });
    }
</script>
<!--{/if}-->