<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
$hbword = lang_hm('hb',0) ."<em class='iconfont icon-jinrujiantou f12'></em>";
if($v[hhr_ticheng]>0 && $hhrname):
    $v[hhr_ticheng] = floatval($v[hhr_ticheng]);
    $hbword = "<em class='iconfont icon-shouru f13'></em> ".lang_hm('zhuan',0).$v[hhr_ticheng].lang_hm('yuan',0)."<em class='iconfont icon-jinrujiantou f12'></em>";
    $bword = "<div style='margin:10px 0;font-size:12px'>".lang_hm("fxcgz", 0)."<em class=main_color>".$v[hhr_ticheng].lang_hm("yuan", 0)."</em></div>";
endif;
}-->
<!--{if 0}-->
    <!--{if $v[custom_pic]}-->
        <a href="javascript:;" class="custom_pic hbzd" data-url="$SCRITPTNAME?id=xigua_hm:qrcode&secid={$v[id]}">$hbword</a>
    <!--{elseif $hm_config[haitype]==2}-->
        <a href="javascript:;" class="mag_share hbzd" data-url="">$hbword</a>
    <!--{else}-->
        <a href="javascript:;" class="mag_share hbzd" data-url="{$_G[siteurl]}$SCRITPTNAME?id=xigua_hm:qrcode&secid={$v[id]}">$hbword</a>
    <!--{/if}-->
<!--{else}-->
<!--{if $v[custom_pic]}-->
<a href="javascript:;" class="custom_pic hbzd" data-url="$SCRITPTNAME?id=xigua_hm:qrcode&secid={$v[id]}">$hbword</a>
<!--{else}-->
<a href="javascript:;" <!--{if $hm_config[haitype]==2}-->class="sec_newewm hbzd"<!--{else}-->  class="sec_ewm hbzd" data-id="$v[id]" data-ext="<!--{if $bword}-->{$bword}<!--{elseif $hhrname}--><div style='margin-top:10px'><p class='f12'>{lang xigua_hm:hhrdj} : <em class=main_color>$hhrname</em></p><!--{if $hhrpercent}--><p class='f12'>{lang xigua_hm:bl} : <em class=main_color>{$hhrpercent}</em></p><!--{/if}--></div><!--{/if}-->"<!--{/if}-->>$hbword</a>
<!--{/if}-->
<!--{/if}-->
