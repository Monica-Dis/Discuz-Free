<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
$keyword = stripsearchkey($_GET['keyword']);
include_once DISCUZ_ROOT.'source/plugin/xigua_hm/include/c_tongji.php';
}-->
<!--{template xigua_hm:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
<style>
.weui-search-bar__cancel-btn{font-size:16px}
.search_bar_btn{margin-left: 10px;line-height: 28px;white-space: nowrap;display:none;font-size:16px}
.weui-search-bar.weui-search-bar_focusing .search_bar_btn { display: block}
.weui-search-bar__form{background: transparent}
.weui-search-bar__box{background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABZ0RVh0Q3JlYXRpb24gVGltZQAwOS8wNi8xOLnuRBwAAAAcdEVYdFNvZnR3YXJlAEFkb2JlIEZpcmV3b3JrcyBDUzbovLKMAAAH4klEQVR4nO2d+W8SQRTH38xCkaMpFmyKJcb+VrSt0tQD4hHU1CP+uR4VDzxCrZV0KyFpfzCaKK3a2wpWLHT8oaHpNW8PZnYX5PvrDjs7Hx4zs++9eRDGGFitXC7HyuUybG5uQrVaBd4zEELA5XKB1+sFv98Po6OjxOJHFSZiBej379+zlZUV2NraEnI/t9sNoVAILly40DTgpYFWVZV9//4dqtWqlPvX5XK5oLe3F+LxuKOhCwc9OTnJlpeXudOBLBFCIBwOw+XLlx0JXBhoVVXZwsICbG9vC7mfWVFK4eTJk46zcCGgx8fHmaj5V5RcLhfcvXvXMbAbAp3NZtnq6qrAxxGvYDAIV69etR24adBPnjxhf//+NfVZt9sNgUAAgsEgDA4OohAKhQJbX1+HUqlketfidrvhzp07tsI2BfrRo0esVqvp74QQ8Pv9kEqlhAw2k8mwcrlsaMGllEJ/fz+cOXPGFuCGQOfzefblyxfdA6SUQiQSgZGRESmDU1WVffv2DfR+6YQQ6Ovrs2Wh1A16ZmaGFYtFXZCtXvnz+TwrFou6gUciEcvfMnWBNgK5q6sLrl27ZsvP08gePhqNWmrZukA/ePCAabVTFAXu3btn++oOoG+7SQiB+/fvOwe0noXP6/XCrVu3HAG5rkwmw0qlEtrGSuNAQT99+pT9+fMHvcHx48fhypUrjoJc18TEBFtZWUHbeDweGBsbk/78lHfh7du3mpBDoZBjIQMAJJNJEg6H0TaVSgWy2ax0xwwXtJYlhEIhSCaTjoVcVyKRIKFQCG2zuroKs7OzUmEfCfr58+fo4hcIBJoCcl3JZJIEAgG0zdevX6U+wyHQqqqy379/cz/gdruFveFZqVQqRTweD/d6pVKBXC4nzaoPgf7x4we3MSEETp8+LetZpGtsbIwQwreRpaUlaX3vA53L5dD9Z1dXFwwMDDSdNe8VNl9Xq1V49+6dFKveBxpzebpcLke4GxtVIpEgHR0d3Otra2tS+t0FXSgUWKVS4TY8ceKElAewQ5FIhHtta2sL8vm8cKveBb28vMxt5Ha7mzrUf1DDw8PowoixMKtd0NhOQ2vT34zq7u7mXtvc3BTeHwXY2dLx/BmKorSUNdc1OjpKFEU58tr29jaoqip0+qAAABsbG9wGfr9fZH+OEvYSgzExIwqA/1S0Xl+bWdgCj02lZkQBgJtNpCiKZvC0mRWLxbjTh5GYqB7RQqHA9Wtg+81WEW+MjDH48OGDsHmaYs7xY8eOierHscLGWC6XhfVDsdwMn88nrCOnChujyARNit3M6/UK68ipwlIhLAMdi8VadiHUI6GgeQshpdzgS8uJN1aRqcdcmpjfttVkxVj/H7O1WVzQdhwisktWjJVijpX/Rbyx8tiYEcUWvUKh0PJmjaUZiNwQUOw1W4Zf1mnCxijSBUGxSMP/ABpzQWBsjIpiPlmtlLBWEDZGraQbI6KxWIzw5iKnnbSSId7bH6VU6JsxBdhJJThKMkI6TlI+n+eG8HhMzIoC4M4jWXkOThCWxyLaoUYBrI8IO0VYuApjYkYUAGBwcJBg08fk5GTLTR+5XA6dNkSH8HZXQSza3YrTB5YkIyPyvwu6p6eH20hm8p8d0krmxFiY1S7ogYEBgoV1tE4ANJMwa/Z4PFIyZvdtoLFvslarwatXr5reqrPZLGrNvb29UvrdB3poaIhgUeGNjQ2YmZlpWthzc3MMW288Hg8MDw9LiQIceiWMRqPoBxYWFmQ8hyX69OkT6nvG0nkb1SHQsVgMPVhTq9UgnU43nVWn02n0YKrP54OhoSFpMa0jnRypVIqbKgWwc7Amk8k0DexMJoMm2RNC4ObNm1IDh1zPttbPqFQqNQXsN2/eaB5VtuI0Axd0PB7XPJtXKpXgxYsXjoX98uVLtr6+jrbx+/1w6dIl+44oA2ifzQPYyU8bHx93HOx0Os1+/fqFtlEUBW7cuGH/ofu69FQ4oJRCNBqFc+fO2ZoQMjs7yz5//qw77TYcDkMikZD+zLor0Oip2QGws3rLXlh4ev36Nfv586fhz1kBWzfoubk59vHjR105EIQQCIVCllgKAMDU1BRbWlpqKEVCNmzDVcIePnzI9A6IEALBYFBaqYlsNsvW1taEJcDIrNhgqhzb48ePmdFMS1EVcqenp9ni4qLheCYhRNcXIgu26QKDz549Y2ajL4SQ3SKDPp+PW0SqXmmhXlzQ7LPWSxHpLcIlA3ZDJTOnpqbY4uKiY/P0CCHQ09MDFy9e3IVmF2whRWAbKZ8pSx0dHXD79u0jQdkBW1hZY6P7V1lSFAX6+/s1czKshi28UHc+n2fz8/PSK6EflMvlglOnTsHZs2d1Q7ESttQa/2aKtRoRIQQ6Ozvh+vXrpiFYBduSP1MA2HHwlMvlhvOuFUWBzs5OoUVarIBtGeiDqm/d9sKvz+91X7iiKOD3+8Hr9UqvIyobtm2gnShVVVmxWNRsZwZ2+7DQHsXjcaIVMwXYSb2YmJgwZKFt0AckC3Yb9BGSAbsNmiPRsNugEYmE3QatIVGw26B1SATsNmidahR2G7QBNQK7Ddqg4vE46evr02x3EHYbtAmNjIwYht32dTSg6elpNj8/r9muu7u7bdGNSI9l1/+QrQ26QWGwCSEQjUbh/PnzpA1agI6CvRcyQHsxFKa9sA9CBmgvhsKlqiqjlB7Kqv0HrBwj5VaL/jMAAAAASUVORK5CYII=) 10px center no-repeat;background-size: 16px}
</style>
    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">

            <input name="id" value="xigua_hm" type="hidden">
            <input name="ac" value="my_order" type="hidden">
            <input name="do" value="manage" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">

            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_hm:search}" data-hold="{lang xigua_hm:qtx}{lang xigua_hm:search}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_hm:search}</span>
            </label>
        </form>
        <a href="javascript:" class="search_bar_btn main_color" id="dosearch">{lang xigua_hb:sousuo}</a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage{$mang}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_hb:quxiao}</a>
    </div>

    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage" class="weui-navbar__item <!--{if !$_GET[stype]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:qggl}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage&stype=quan" class="weui-navbar__item <!--{if $_GET[stype]=='quan'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:kqgl}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=income" class="weui-navbar__item">
            <span>{lang xigua_hm:rzjl}</span>
        </a>
    </div>

    <div class="banner_fix cl">
        <div class="banner">
            <nav class="weui-flex tag_list">
                <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage&stype=$_GET[stype]" class="<!--{if !$_GET[status]&&!$_GET[hx]}-->main_color<!--{/if}-->">
                    <span>{lang xigua_hb:quanbu}</span>
                </a>
                <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage&stype=$_GET[stype]&status=-1" class="<!--{if $_GET[status]==-1}-->main_color<!--{/if}-->">
                    <span>{lang xigua_hm:wzf}</span>
                </a>
                <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage&stype=$_GET[stype]&status=2&hx=-1" class="<!--{if $_GET[hx]==-1}-->main_color<!--{/if}-->">
                    <span>{lang xigua_hm:wsy}</span>
                </a>
                <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage&stype=$_GET[stype]&status=2&hx=1" class="<!--{if $_GET[hx]==1}-->main_color<!--{/if}-->">
                    <span>{lang xigua_hm:ysy}</span>
                </a>
                <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage&stype=$_GET[stype]&status=1&hx=6" class="<!--{if $_GET[hx]==6}-->main_color<!--{/if}-->">
                    <span>{lang xigua_hm:ytk}</span>
                </a>

            </nav>
        </div>
    </div>

    <div class="weui-cells__title" style="margin-bottom: .77em;margin-top: .3em;">
        {lang xigua_hm:ddzs}: <span class="main_color">$icount</span>
        {lang xigua_hm:wfk}: <span class="main_color">$wei</span>
        {lang xigua_hm:yfk}: <span class="main_color">$allpaied</span>
        {lang xigua_hm:yhx}: <span class="main_color">$allhx</span>
    </div>

    <div  id="list" class="weui-cells p0 mt0"></div>



    <!--{template xigua_hb:loading}-->
</div>

<script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>
<script>
    var loadingurl = window.location.href+'&do=seckill_li&inajax=1&manage=1&page=';
    var noTit = true;

    $(document).on('click','#dosearch', function () {
        if($('#searchInput').val()){
            $('#dosearchform').submit();
        }else{
            $.alert($('#searchInput').data('hold'));
        }
    });
</script>
<!--{eval $tabbar=1;}-->
<!--{template xigua_hb:common_footer}-->