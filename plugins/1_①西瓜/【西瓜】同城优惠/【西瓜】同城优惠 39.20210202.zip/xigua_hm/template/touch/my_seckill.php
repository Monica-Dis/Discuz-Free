<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval $pub0 = 'javascript:full_input(this, 0);';}--><!--{template xigua_hm:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<style>#new_popup.weui-popup__container{ display: none;position: relative;height:auto}#new_popup.weui-popup__container .weui-popup__modal,#new_popup.weui-popup__container .weui-popup__modal .fixpopuper{position: relative;height:auto!important;}</style>
<div class="page__bd" <!--{if $ac == 'seckilledit'}-->style="display:none"<!--{/if}-->>
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <!--{if $kaquan}-->
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=quan" class="weui-navbar__item <!--{if !$_GET[kucun]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:all}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=quan&kucun=1" class="weui-navbar__item <!--{if $_GET[kucun]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:lqz}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=quan&kucun=3" class="weui-navbar__item <!--{if $_GET[kucun]==3}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:dsh}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=quan&kucun=2" class="weui-navbar__item <!--{if $_GET[kucun]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:yjs}</span>
        </a>
        <!--{else}-->
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill" class="weui-navbar__item <!--{if !$_GET[offline]&&!$_GET[shen]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:jxz}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&shen=1" class="weui-navbar__item <!--{if $_GET[shen]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:dsh}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&offline=1" class="weui-navbar__item <!--{if $_GET[offline]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:yjs}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&offline=2" class="weui-navbar__item <!--{if $_GET[offline]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:yxj}</span>
        </a>
        <!--{/if}-->
    </div>
    <div>
        <div id="list" class="mod-post x-postlist p0"></div>
        <!--{template xigua_hb:loading}-->
    </div>
<!--<div class="footer_fix"></div>-->
    <!--{if $hide_nav}-->
    <div class="bottom_fix"></div>
    <div class="fix-bottom" style="z-index:501">
        <a class="weui-btn weui-btn_primary" onclick="return full_input(this, 0);">{lang xigua_hm:new_pub}</a>
        <input id="auto" class="blind" style="opacity:0">
    </div>
    <!--{/if}-->
</div>

<form  action="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=add&st={$_GET['st']}" method="post" id="form">
<div id="new_popup" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__modal">
            <div class="fixpopuper">
                <input name="formhash" value="{FORMHASH}" type="hidden">
                <input name="form[id]" value="{$old_data[id]}" type="hidden">
                <!--{if !$kaquan}-->
                <input name="form[stype]" value="seckill" type="hidden">
                <!--{/if}-->

                <div class="weui-cells__title"><!--{if !$kaquan}-->{lang xigua_hm:new_seckill}<!--{else}-->{lang xigua_hm:fbkq}<!--{/if}--></div>
                <div class="weui-cells ">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hm:spbt}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[title]" placeholder="{lang xigua_hm:qtxspbt}" value="{$old_data[title]}">
                        </div>
                    </div>
                    <!--{if $sh}-->
                    <div class="weui-cell weui-cell_access">
                        <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hm:sydp}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input choose_ctrl" name="form[shname]" type="text" value="{echo $old_data?$old_data['shname']:$sh[0]['name']}" placeholder="{lang xigua_hm:qxzsydp}">
                        </div>
                        <div class="weui-cell__ft"></div>
                    </div>
                    <!--{/if}-->
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hm:starttime}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input time_ctrl" name="form[starttime]" type="text" placeholder="{lang xigua_hm:qxzstarttime}" value="{echo $old_data ? $old_data[start_u] : date('Y-m-d H:i');}">
                        </div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:endtime}</label></div>
                        <div class="weui-cell__bd">
                            <!--{if !$kaquan}-->
                            <input class="weui-input time_ctrl" name="form[endtime]" type="text" placeholder="{lang xigua_hm:plzyxq}" value="{echo $old_data ? $old_data[end_u] : ''}">
                            <!--{else}-->
                            <input class="weui-input time_ctrl" name="form[endtime]" type="text" placeholder="{lang xigua_hm:qxzendtime}" value="{echo $old_data ? $old_data[end_u] : date('Y-m-d H:i', TIMESTAMP+2592000);}">
                            <!--{/if}-->
                        </div>
                    </div>

                    <div class="weui-cell weui-cell_switch">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:sfyy}</label></div><div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hm:plzsfyy}</span></div>
                        <div class="weui-cell__ft">
                            <input class="weui-switch" type="checkbox" name="form[yuyue]" value="1" <!--{if $old_data[yuyue]}-->checked="checked"<!--{/if}-->>
                        </div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:hxyc}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="form[usetime_start]" type="tel" placeholder="{lang xigua_hm:hxyc1}" value="{echo intval($old_data[usetime_start]/60)}">
                        </div>
                        <div class="weui-cell__ft">{lang xigua_hm:miao}
                        </div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:yxq}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input time_ctrl" name="form[usetime]" type="text" placeholder="{lang xigua_hm:plzyxq}" value="{$old_data[usetime_u]}">
                        </div>
                    </div>

                    <div class="weui-cell weui-cell_switch" id="zxbtn" style="display:none">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:fensizhuanxiang}</label></div><div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hm:kqhfsgm}</span></div>
                        <div class="weui-cell__ft">
                            <input class="weui-switch" type="checkbox" name="form[fszx]" value="1" <!--{if $old_data[fszx]}-->checked="checked"<!--{/if}-->>
                        </div>
                    </div>

                </div>

                <div class="weui-cells__title">{lang xigua_hm:jgsl}</div>
                <!--{if !$kaquan}-->
                <div class="weui-cells">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:qgjg}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="form[price]" type="text" placeholder="{lang xigua_hm:qtxqgjg}" value="{$old_data[yuanprice]}">
                        </div>
                        <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
                    </div>

                    <!--{if $hm_config[allowjfzf]}-->
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_hm:jfzfbl}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[jifenrate]" placeholder="{lang xigua_hm:qtx}{lang xigua_hm:jfzfbl}" value="{$old_data[jifenrate]}">
                        </div>
                        <div class="well-cell__ft">%</div>
                    </div>
                    <!--{/if}-->
                    <!--{if $hm_config[showapppr]}-->
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:appprice}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="form[appprice]" type="text" placeholder="{lang xigua_hm:plzappprice}" value="{$old_data[appprice]}">
                        </div>
                        <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
                    </div>
                    <!--{/if}-->

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:spyj}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="form[marketprice]" type="text" placeholder="{lang xigua_hm:qtxspyj}" value="{$old_data[marketprice]}">
                        </div>
                        <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
                    </div>
                    <!--{if $hm_config[djmode]}-->
                    <div class="weui-cell weui-cell_switch">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:djms}</label></div>
                        <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hm:plzdjms}</span></div>
                        <div class="weui-cell__ft">
                            <input id="digmode" onclick="return hm_digmode();" class="weui-switch" type="checkbox" <!--{if $old_data[dingprice]>0}-->checked<!--{/if}-->>
                        </div>
                    </div>
                    <div class="weui-cell digmode" style="display:none">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:djje}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="form[dingprice]" type="text" placeholder="{lang xigua_hm:qtxdjje}" value="{$old_data[dingprice]}">
                        </div>
                        <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
                    </div>
                    <!--{/if}-->
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:spzs}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="form[allnum]" type="tel" placeholder="{lang xigua_hm:qtxspzs}" value="{$old_data[allnum]}">
                        </div>
                        <div class="weui-cell__ft"></div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:xgfs}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="form[maxnum]" type="tel" placeholder="{lang xigua_hm:qtxxgfs}" value="{$old_data[maxnum]}">
                        </div>
                        <div class="weui-cell__ft">{lang xigua_hm:fen}</div>
                    </div>

                    <div class="weui-cell weui-cell_select weui-cell_select-after">
                        <div class="weui-cell__hd">
                            <label for="" class="weui-label">{lang xigua_hm:psfs}</label>
                        </div>
                        <div class="weui-cell__bd">
                            <select class="weui-select" name="form[fee_type]" onchange="if(this.value==1){$('#feee').hide();}else{$('#feee').show();}" >
                                <option value="1" <!--{if $old_data[fee_type]==1}-->selected<!--{/if}-->>{lang xigua_hm:ddhx}</option>
                                <option value="2" <!--{if $old_data[fee_type]==2}-->selected<!--{/if}-->>{lang xigua_hm:kdfy}</option>
                            </select>
                        </div>
                    </div>

                    <div class="weui-cell" id="feee" <!--{if $old_data}--><!--{if $old_data[fee_type]==1}-->style="display:none"<!--{/if}--> <!--{else}-->style="display:none"<!--{/if}-->>
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:psf}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="form[fee]" type="text" placeholder="{lang xigua_hm:plzpsf}" value="{$old_data[fee]}">
                        </div>
                    <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
                    </div>
                </div>
        <!--{else}-->
        <!--quan-->
    <div class="weui-cells">
        <div class="weui-cell weui-cell_select weui-cell_select-after">
            <div class="weui-cell__hd">
                <label for="" class="weui-label">{lang xigua_hm:kqlx}</label>
            </div>
            <div class="weui-cell__bd">
                <select class="weui-select" id="stype" name="form[stype]">
                    <!--{loop $kaquan_stype $__s}-->
                    <option value="$__s" <!--{if $__s==$old_data[stype]}-->selected<!--{/if}-->>{echo lang_hm($__s, 0);}</option>
                    <!--{/loop}-->
                </select>
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:qdjg}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[price]" type="text" placeholder="{lang xigua_hm:plzqdjg}" value="{$old_data[yuanprice]}">
            </div>
            <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
        </div>

        <!--{if $hm_config[allowjfzf]}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_hm:jfzfbl}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[jifenrate]" placeholder="{lang xigua_hm:qtx}{lang xigua_hm:jfzfbl}" value="{$old_data[jifenrate]}">
            </div>
            <div class="well-cell__ft">%</div>
        </div>
        <!--{/if}-->

        <!--{if $hm_config[showapppr]}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:appprice}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[appprice]" type="text" placeholder="{lang xigua_hm:plzappprice}" value="{$old_data[appprice]}">
            </div>
            <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
        </div>
        <!--{/if}-->

        <div class="border_top" id="y__" <!--{if $old_data[stype]!='zhekou'}-->style="display:block"<!--{else}-->style="display:none"<!--{/if}-->>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:qdme}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[marketprice]" type="text" placeholder="{lang xigua_hm:qtxqdme}" value="{$old_data[marketprice]}">
                </div>
                <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
            </div>
        </div>
        <div class="border_top" id="z__" <!--{if $old_data[stype]=='zhekou'}-->style="display:block"<!--{else}-->style="display:none"<!--{/if}-->>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:zkbl}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[zhekourate]" type="tel" placeholder="{lang xigua_hm:qtxzkbl}" value="{$old_data[zhekourate]}">
                </div>
                <div class="weui-cell__ft">{lang xigua_hm:zhe}</div>
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:sytj}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[underline]" type="text" placeholder="{lang xigua_hm:qtxsytj}" value="{$old_data[underline]}">
            </div>
            <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:kcsl}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[allnum]" type="tel" placeholder="{lang xigua_hm:qtxkcsl}" value="{$old_data[allnum]}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:xlfs}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[maxnum]" type="tel" placeholder="{lang xigua_hm:qtxxlfs}" value="{$old_data[maxnum]}">
            </div>
            <div class="weui-cell__ft">{lang xigua_hm:fen}</div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:wxts}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[fanwei]" type="text" placeholder="{lang xigua_hm:qtxwxts}" value="{$old_data[fanwei]}">
            </div>
        </div>
    </div>
        <!--{/if}-->

                <div class="weui-cells__title">{lang xigua_hm:spxq}</div>
                <div class="weui-cells  ">

                    <div class="weui-cell">
                        <div class="weui-cell__bd">
                            <div class="weui-uploader">
                                <div class="weui-uploader__hd">
                                    <p class="weui-uploader__title">{lang xigua_hm:splbt}</p>
                                    <div class="weui-uploader__info">{echo str_replace('n', $hs_config['maximg'], lang_hs('zuiduozhao',0))}</div>
                                </div>
                                <div class="weui-uploader__bd">
                                    <ul class="weui-uploader__files" data-max="{$hs_config['maximg']}" data-maxtip="{echo str_replace('n', $hs_config['maximg'], lang_hs('zuiduozhao',0))}">
                                        <!--{loop $old_data[album] $img}-->
                                        <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                        <!--{/loop}-->
                                    </ul>
                                    <div class="weui-uploader__input-box">
                                        <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                        <a  class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1"></a>
                                        <!--{else}-->
                                        <input  class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                        <!--{/if}-->
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>

                    <div class="weui-cell weui-cell_access" onclick='$("#edit_jieshao").popup();'>
                        <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hm:spxq}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" readonly placeholder="{lang xigua_hm:djspxq}">
                        </div>
                        <div class="weui-cell__ft"></div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:spts}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input"name="form[biaoqian]" type="text" placeholder="{lang xigua_hm:qtxspts}" value="{$old_data[biaoqian]}">
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hm:fxwa}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[tuijian]" placeholder="{lang xigua_hm:qtxfxwa}" value="{$old_data[tuijian]}">
                        </div>
                    </div>
                </div>
        <div class="weui-cells__title">{lang xigua_hm:fjgn}</div>
        <div class="weui-cells ">
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:zdpxs}</label></div>
                <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hm:qtxzdpxs}</span></div>
                <div class="weui-cell__ft">
                    <input class="weui-switch" type="checkbox" name="form[gongkai]" value="1" <!--{if !$old_data}-->checked<!--{/if}--> <!--{if $old_data[gongkai]}-->checked<!--{/if}-->>
                </div>
            </div>
            <!--{if $hm_config[allowhk] && $_G['cache']['plugin']['xigua_hk']}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hk:heikajia}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[hkprice]" type="text" placeholder="{lang xigua_hk:plzheikajia}" value="{$old_data[hkprice]}">
                </div>
                <div class="weui-cell__ft">{lang xigua_hm:yuan}</div>
            </div>
            <!--{/if}-->
            <!--{if $hm_config[allowtk]}-->
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hm:yxtk}</label></div>
                <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hm:yxtk_tip}</span></div>
                <div class="weui-cell__ft">
                    <input class="weui-switch" type="checkbox" name="form[allowtk]" value="1" <!--{if $old_data[allowtk]}-->checked<!--{/if}-->>
                </div>
            </div>
            <!--{/if}-->
            <!--{if $hm_config[allowshfans]}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_hm:fansqr}</p>
                            <div class="weui-uploader__info">{lang xigua_hm:qgfansqr}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[fansqr]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[fansqr])"><input type="hidden" name="form[fansqr][]" value="$old_data[fansqr]"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[fansqr]" type="file"></a>
                                <!--{else}-->
                                <input  class="weui-uploader__input" data-name="form[fansqr]" type="file">
                                <!--{/if}-->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!--{/if}-->
        </div>

        <!--{if $svicerange}-->
        <div class="weui-cells__title">{lang xigua_hm:fwfw}</div>
        <div class="weui-cells ">
            <div class="weui-cell" style="padding-bottom:6px;">
                <div class="weui-cell__bd">
                    <div class="post-tags cl" id="post-typeid">
                        <!--{loop $svicerange $_rangk $_rangv}-->
                        <a class="weui-btn weui-btn_mini weui-btn_default <!--{if in_array($_rangv, $old_data[srange_ary])}-->tag-on<!--{/if}-->" href="javascript:;" onclick="return setTypeid('{$_rangk}', this);">$_rangv</a>
                        <input name="form[tagid][{$_rangk}]" type="hidden" value="<!--{if in_array($_rangv, $old_data[srange_ary])}-->1<!--{else}-->0<!--{/if}-->">
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
        </div>
        <label for="weuiAgree" class="weui-agree">
            <span class="weui-agree__text">{lang xigua_hm:yju}</span>
        </label>
        <!--{/if}-->
        <div class="fix-bottom mt10" style="position:relative">
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}" />
            <!--{if $ac != 'seckilledit'}-->
            <a class="weui-btn weui-btn_default close-newpopup" >{lang xigua_hb:quxiao}</a>
            <!--{else}-->
            <a class="weui-btn weui-btn_default" href="javascript:window.history.go(-1);">{lang xigua_hm:gb}</a>
            <!--{/if}-->
        </div>
    </div>
    </div>
</div>
<div id="edit_jieshao" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__modal bgf8">
        <div class="fixpopuper">
            <div class="weui-cells__title">{lang xigua_hm:bjsp}</div>
            <div class="weui-cells ">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <textarea class="weui-textarea" name="form[jieshao]" placeholder="{lang xigua_hm:txspxq}" rows="3">{$old_data[jieshao]}</textarea>
                    </div>
                </div>
            </div>

            <div class="weui-cells before_none nobg center_upload">
                <div class="weui-cell" id="first_append_img">
                    <div class="weui-cell__bd">
                        <div class="weui-uploader">
                            <div class="weui-uploader__bd">
                                <div class="weui-uploader__input-box">
                                    <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                    <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                    <!--{else}-->
                                    <input class="center_upload__input" data-name="form[append_img]" type="file">
                                    <!--{/if}-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--{loop $old_data[append_text_ary] $__k $__v}-->
                <div class="weui-cell bgf" id="arear_{$__k}">
                    <ul id="cimg_{$__k}" data-only="1">
                        <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url({$old_data['append_img_ary'][$__k]})">
                            <input type="hidden" name="form[append_img][{$__k}]" value="{$old_data['append_img_ary'][$__k]}">
                            <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                        </li>
                    </ul>
                    <div class="weui-cell__bd">
                        <textarea class="weui-textarea" placeholder="{lang xigua_hs:inputtext}" rows="3" name="form[append_text][{$__k}]">{$__v}</textarea>
                    </div>
                    <a class="iconfont icon-guanbijiantou closeHt" data-index="{$__k}"></a>
                </div>
                <div class="weui-cell" id="cell_{$__k}">
                    <div class="weui-cell__bd">
                        <div class="weui-uploader">
                            <div class="weui-uploader__bd">
                                <div class="weui-uploader__input-box">
                                    <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                    <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                    <!--{else}-->
                                    <input class="center_upload__input" data-name="form[append_img]" type="file">
                                    <!--{/if}-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--{/loop}-->
            </div>

            <div class="fix-bottom" id="center_upload_btn" style="position:relative">
                <a class="mt0 weui-btn weui-btn_default" onclick='$.closePopup();return cropCallback();' href="javascript:;">{lang xigua_hm:wcbj}</a>
            </div>
        </div>
    </div>
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
</form>
<div class="masker" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);display:none;z-index:1000" onclick='$(".choose_ctrl").select("close")'></div>

<script>
var loadingCallback = function () {
    $('.hmt').each(function () {
        var that = $(this);
        hm_GetRunTime(that.data('start'),that.data('end'), that);
    });
};
var itar = [];
<!--{loop $sh $_sh}-->
<!--{if $_sh[name]}-->
itar.push({title:'{$_sh[name]}'});
<!--{/if}-->
<!--{/loop}-->
$(".choose_ctrl").select({
    title: "{lang xigua_hm:qxzsydp}",
    items: itar,
    onOpen:function () {
        $('.masker').fadeIn();
    },
    beforeClose:function () {
        $('.masker').fadeOut(300);
        return true;
    }
});
$(document).on('change','.choose_ctrl', function () {
    var shnameval = $(this).val();
    checkfszx(shnameval);
});
function checkfszx(shnameval) {
    $.ajax({
        type: 'POST',
        url: '$SCRITPTNAME?id=xigua_hs&ac=getloc&do=getshvip&checkif=zhuanxiang&inajax=1',
        data:{shname:shnameval},
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s.split('|')[1]==1){
                $('#zxbtn').show();
            }else{
                $('#zxbtn').hide();
            }
        },
        error: function () { }
    });
}
checkfszx($('.choose_ctrl').val());

function cropCallback(){
    showadd();
    return false;
}
$(document).on('click','.stock-edit', function () {
    var that = $(this);
    $.prompt(that.data('tit'),that.data('tit'), function(num) {
        $.showLoading();
        $.ajax({
            type: 'post',
            url: '$SCRITPTNAME?id=xigua_hm&ac=stock_edit&inajax=1',
            data:{formhash:'{FORMHASH}', allnum:num, secid: that.data('id')},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {
                $.hideLoading();
            }
        });
    }, function() {
    });
    $('#weui-prompt-input').replaceWith('<input class="weui-prompt-input needsclick weui-input needsclick_input" type="tel" id="weui-prompt-input" placeholder="{lang xigua_hm:qtxkcsl}" value="'+that.data('stock')+'" />');
    document.getElementById('auto').focus();
    document.getElementById('weui-prompt-input').focus();
});
$(document).on('change','#stype', function () {
    var that = $(this);
    if(that.val() === 'zhekou'){
        $('#z__').show();
        $('#y__').hide();
    }else{
        $('#z__').hide();
        $('#y__').show();
    }
});
$(document).on('click','.stock-del', function () {
    var that = $(this);
    $.confirm({
        title: '{lang xigua_hm:qrxj}',
        text: '{lang xigua_hm:qrxjtip}',
        onOK: function () {$.showLoading();
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hm&ac=stock_edit&do=del&inajax=1',
                data:{formhash:'{FORMHASH}', secid: that.data('id')},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }
    });
});
$(document).on('click','.stock-shangjia', function () {
    var that = $(this);
    $.confirm({
        title: '{lang xigua_hm:qrsj}',
        text: '',
        onOK: function () {$.showLoading();
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hm&ac=stock_edit&do=shangjia&inajax=1',
                data:{formhash:'{FORMHASH}', secid: that.data('id')},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }
    });
});
function showadd() {
    $('#new_popup').popup().show();
    $('.page__bd').hide();
    $('.weui-tabbar').hide();
}
function hideadd(){
    $.closePopup('#new_popup');
    $('.page__bd').show();
    $('.weui-tabbar').show();
}
$(document).on('click','.close-newpopup', function () {
    hideadd();
});
<!--{if $ac == 'seckilledit' || $_GET[auto]}-->
showadd();
<!--{else}-->
var loadingurl = window.location.href+'&ac=seckill_li&is_my=1&inajax=1&stype=$stype&page=';
<!--{/if}-->
</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.min.js" charset="utf-8"></script>
<script type="text/javascript" src="source/plugin/xigua_hm/static/up.js?{VERHASH}" charset="utf-8"></script>
<script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>
<!--{eval $tabbar=1;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->
<!--{template xigua_hs:enter_up}-->
<!--{if !$sh[0][name]}--><script>$.alert("{lang xigua_hm:bnfb}", function() {hb_jump("$SCRITPTNAME?id=xigua_hs&ac=shcenter&mobile=2{$urlext}");});</script><!--{/if}-->