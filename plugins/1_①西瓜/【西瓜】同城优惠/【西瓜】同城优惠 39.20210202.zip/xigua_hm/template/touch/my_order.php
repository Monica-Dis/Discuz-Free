<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-cells mt0">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=myorder">
            <div class="weui-cell__hd"><i class="iconfont icon-dingdan color-paypal"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hm:tcdd}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=seckill">
            <div class="weui-cell__hd"><i class="iconfont icon-qianggou color-red2"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hm:wdyh}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
        <!--{if $_G['cache']['plugin']['xigua_hd']}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=evt">
            <div class="weui-cell__hd"><i class="iconfont icon-huojian color-orange"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hd:wdjj}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
        <!--{/if}-->
    </div>

    <div class="weui-cells">

        <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
            <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:kefu}</p>
            </div>
            <div class="weui-cell__ft">{lang xigua_hb:zhwo}</div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=about">
            <div class="weui-cell__hd"><i class="iconfont icon-guize color-forest"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:bangzhu}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
    </div>
</div>

<!--{eval $tabbar=1;}-->
<!--{template xigua_hb:common_footer}-->