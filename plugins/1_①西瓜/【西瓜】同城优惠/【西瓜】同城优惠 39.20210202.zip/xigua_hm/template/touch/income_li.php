<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<!--{eval $linfo = unserialize($v['info']['info']);}-->
<a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid={$linfo['data'][1]['log_id']}">
    <div class="weui-cell__hd weui-head_fix">
        <img class="weui-head_img" src="{avatar($v[orderuser][uid], 'big', true)}" />
        <span class="weui-desc f10">{$v[orderuser][username]}</span>
    </div>
    <div class="weui-cell__bd">
        <p class="main_color f16">+{$v[money]} {lang xigua_hb:yuan}</p>
        <p class="weui-desc"><span class="color-tumblr">{lang xigua_hm:oinfo2}{$v[info][baseprice]}{lang xigua_hb:yuan}</span> <br>{$v[info][subject]}</p>
        <p class="weui-desc color-red">{lang xigua_hm:ddrq}: {$v[indate]}</p>
    </div>
    <div class="weui-cell__ft"></div>
</a>
<!--{/loop}-->
