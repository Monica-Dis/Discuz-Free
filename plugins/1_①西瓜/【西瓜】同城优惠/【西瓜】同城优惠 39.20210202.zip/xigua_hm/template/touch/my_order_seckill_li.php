<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<!--{if !$seclist[$v[secid]]}-->
<!--{eval continue;}-->
<!--{/if}-->
<!--{if $seclist[$v[secid]][fee_type]==1}-->
<!--{eval $v[postinfo] = '';$v[addrid]=0;}-->
<!--{/if}-->
<!--{eval $isend = $v['endts']>0&&$v['endts']<TIMESTAMP;}-->
<div class="sp_item sec_item <!--{if $v[hxstatus]==1||$v[postinfo]||$isend||$v[tkts]}-->hasend<!--{/if}-->" >
    <div class="sp_thumb m_jump" data-id="{$v['secid']}"><img src="{echo $seclist[$v[secid]]['album'][0] ?$seclist[$v[secid]]['album'][0]: $seclist[$v[secid]]['append_img_ary'][0]}"></div>
    <div class="sp_main">
        <div class="sp_content">
            <div class="weui-flex">
                <h3 class="weui-flex__item"><a href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]">{$seclist[$v[secid]][title]} (id:$v[id])</a></h3>
            </div>
<!--{if $v[order_id]}--><div class="f12 c9">{lang xigua_hm:order_id}: $v[order_id]</div><!--{/if}-->
<!--{if $manage}-->
            <!--{eval $mob = DB::result_first('SELECT mobile FROM %t WHERE uid=%d ', array('xigua_hb_user', $v[uid]));}-->
            <p class="sp_desc c9">{lang xigua_hm:yhm}: $v[user][username]</p>
            <p class="sp_desc c9">{lang xigua_hm:mobile}: {echo $mob ? $mob : '-'}</p>
            <p class="sp_desc c9">{lang xigua_hm:dhm}: {eval echo substr($v[code], 0, 3).'***'.substr($v[code], 6)}</p>
        <!--{if $v[status]==0}-->
            <p class="sp_desc c9" >{lang xigua_hm:fkdjs}: <span class="payctrl" data-end="{$v[pay_endts_u]}"> <span class="timer">$v[pay_endts_u]</span></span></p>
            <p class="sp_desc c9">{lang xigua_hm:gmsl}: $v[num]</p>
            <p class="sp_desc mt10">
                <span><em class="color-sec f18">{echo $v[price]}{lang xigua_hm:yuan}</em></span>
                <span><s class="f12 c9 ">{$seclist[$v[secid]][marketprice]}{lang xigua_hm:yuan}</s></span>
            </p>
            <a class="weui-btn percent-btn">{lang xigua_hm:zzfk}</a>
        <!--{else}-->
            <p class="sp_desc c9">{lang xigua_hm:gmsj}: $v[crts_u]</p>
            <p class="sp_desc c9">{lang xigua_hm:hmsl}: $v[num]</p>
            <p class="sp_desc mt10">
                <!--{if $seclist[$v[secid]][stype]=='seckill'}-->
                <span><em class="color-sec f18">{echo $v[price]}{lang xigua_hm:yuan}</em></span>
                <span><s class="f12 c9 ">{$seclist[$v[secid]][marketprice]}{lang xigua_hm:yuan}</s></span>
                <!--{else}-->
                <span><em class="color-sec f18"><!--{if $seclist[$v[secid]][stype]=='zhekou'}-->{$seclist[$v[secid]][show_zhekourate]}{lang xigua_hm:zhe}<!--{else}-->{$seclist[$v[secid]][marketprice]}{lang xigua_hm:yuan}<!--{/if}--></em></span>
                <span class="s_quan_tag b-color" style="position:relative;bottom:1px">{$stypes[$seclist[$v[secid]][stype]]}</span>
                <!--{/if}-->
            </p>

            <!--{if $v[tkts]>0}-->

                <!--{if $v[hxstatus]==7}-->
                <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]">{lang xigua_hm:zfcs}</a>
                <!--{else}-->
                <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]">{lang xigua_hm:ytk}</a>
                <!--{/if}-->

            <!--{else}-->
            <!--{if 1}-->
                <!--{if $v[addrid]>0}-->
                <!--{if !$v[postinfo]}-->
                <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]&fahuo=1">{lang xigua_hm:djfh}</a>
                <!--{else}-->
                <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]">{lang xigua_hm:yfh}</a>
                <!--{/if}-->
                <!--{else}-->
                <!--{if $v[hxstatus]==1}-->
<!--{if $v[hxcrts]>0}-->
    <p class="sp_desc c9">{$v[hxuser][username]} {echo dgmdate($v[hxcrts],'Y-m-d H:i')} <!--{if !$v[addrid]}-->{lang xigua_hm:hx}<!--{else}-->{lang xigua_hm:fh}<!--{/if}--></p>
<!--{/if}-->
                <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]">{lang xigua_hm:yhx}</a>
                <!--{else}-->
                <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=scan&logid=$v[id]&back=manage">{lang xigua_hm:djhx}</a>
                <!--{/if}-->
                <!--{/if}-->
            <!--{else}-->
                <a class="weui-btn percent-btn" href="javascript:;">{lang xigua_hm:ygq}</a>
            <!--{/if}-->
        <!--{/if}-->

        <!--{/if}-->
<!--{else}-->
        <!--{if $v[status]==0}-->
            <p class="sp_desc c9" >{lang xigua_hm:fkdjs}: <span class="payctrl" data-end="{$v[pay_endts_u]}"> <span class="timer">$v[pay_endts_u]</span></span></p>
            <p class="sp_desc c9">{lang xigua_hm:hmsl}: $v[num]</p>
            <p class="sp_desc mt10">
                <span><em class="color-sec f18">{echo $v[price]}{lang xigua_hm:yuan}</em></span>
                <span><s class="f12 c9 ">{$seclist[$v[secid]][marketprice]}{lang xigua_hm:yuan}</s></span>
            </p>
            <a class="weui-btn percent-btn" href="$v[jumpurl]">{lang xigua_hm:ljfk}</a>
        <!--{else}-->
            <p class="sp_desc c9">{lang xigua_hm:usetime}: $v[usetime_u]</p>
            <p class="sp_desc c9">{lang xigua_hm:hmsl}: $v[num]</p>
            <!--{if !$v[addrid] &&$v[hxstatus]!=7}-->
            <p class="sp_desc c9">{lang xigua_hm:dhm}: $v[code]</p>
            <!--{if $v[hxcrts]>0}-->
            <p class="sp_desc c9">{$v[hxuser][username]} {echo dgmdate($v[hxcrts],'Y-m-d H:i')} <!--{if !$v[addrid]}-->{lang xigua_hm:hx}<!--{else}-->{lang xigua_hm:fh}<!--{/if}--></p>
            <!--{/if}-->
            <!--{/if}-->
            <p class="sp_desc mt10">
                <!--{if $seclist[$v[secid]][stype]=='seckill'}-->
                <span><em class="color-sec f18">{echo $v[price]}{lang xigua_hm:yuan}</em></span>
                <span><s class="f12 c9 ">{$seclist[$v[secid]][marketprice]}{lang xigua_hm:yuan}</s></span>
                <!--{else}-->
                <span><em class="color-sec f18"><!--{if $seclist[$v[secid]][stype]=='zhekou'}-->{$seclist[$v[secid]][show_zhekourate]}{lang xigua_hm:zhe}<!--{else}-->{$seclist[$v[secid]][marketprice]}{lang xigua_hm:yuan}<!--{/if}--></em></span>
                <span class="s_quan_tag b-color" style="position:relative;bottom:1px">{$stypes[$seclist[$v[secid]][stype]]}</span>
                <!--{/if}-->
            </p>


            <!--{if $v[tkts]>0}-->
            <!--{if $v[hxstatus]==7}-->
            <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]">{lang xigua_hm:zfcs}</a>
            <!--{else}-->
            <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]">{lang xigua_hm:ytk}</a>
            <!--{/if}-->
            <!--{else}-->
            <!--{if !$isend}-->
            <!--{if $v[price]>0 && $hm_config[allowtk] && $seclist[$v[secid]][allowtk]}-->
                <!--{if $v[hxstatus]==0&&!$v[postinfo]}-->
                    <a class="weui-btn weui-btn_default percent-btn tkbtn" data-id="$v[id]" style="bottom:35px;background-color:#F8F8F8!important;">{lang xigua_hm:tk}</a>
                <!--{/if}-->
            <!--{/if}-->


                <!--{if $v[addrid]>0}-->
                    <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]"><!--{if !$v[postinfo]}-->{lang xigua_hm:dfh}<!--{else}-->{lang xigua_hm:yfh}<!--{/if}--></a>
                <!--{else}-->

                    <!--{if $_GET[notaddr]}-->
                        <a class="weui-btn percent-btn" onclick="show_confirm('{$seclist[$v[secid]][title]}','$v[code]', '$v[usetime_u]', '$v[num]');" href="javascript:;">{lang xigua_hm:djljsy}</a>
                    <!--{else}-->
                        <!--{if $v[hxstatus]==1}-->
                            <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]">{lang xigua_hm:ysy}</a>
                        <!--{elseif $v[hxstatus]==6}-->
                            <a class="weui-btn percent-btn weui-btn_default" style="background-color:#F8F8F8!important;" href="javascript:;">{lang xigua_hm:ytk}</a>
                        <!--{elseif $_GET['confirm']}-->
            <div class="cl weui-cells_radio" style="position: absolute;right: 0;top: 1.8rem;z-index:99">
                <input type="checkbox" class=" weuicheck1" name="form[confirm_quan]" value="$v[code]">
            </div>
                        <!--{else}-->
                            <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[id]">{lang xigua_hm:qxf}</a>
                        <!--{/if}-->
                    <!--{/if}-->

                <!--{/if}-->

            <!--{else}-->
            <a class="weui-btn percent-btn" href="javascript:;">{lang xigua_hm:ygq}</a>
            <!--{/if}-->
        <!--{/if}-->
        <!--{/if}-->
<!--{/if}-->
        </div>
    </div>
    <!--{if $_GET[is_my]}-->
    <a class="a set_option" href="javascript:;" onclick="return managesp(this);">{lang xigua_hs:caozuo}</a>
    <!--{/if}-->
</div>
<!--{/loop}-->