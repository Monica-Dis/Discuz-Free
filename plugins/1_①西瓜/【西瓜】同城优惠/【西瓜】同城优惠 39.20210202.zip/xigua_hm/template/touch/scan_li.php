<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid={$v[id]}">
    <div class="weui-cell__hd weui-head_fix">
        <img class="hm_order_avatar" src="{avatar($v[hxuid], 'middle', true)}" />
    </div>
    <div class="weui-cell__bd">
        <div class="weui-desc">{$v[hxuser][username]} {echo dgmdate($v[hxcrts],'Y-m-d H:i')} <!--{if !$v[addrid]}-->{lang xigua_hm:hx}<!--{else}-->{lang xigua_hm:fh}<!--{/if}--></div>
        <!--{if $v[order_id]}--><div class="f12 c9">{lang xigua_hm:order_id}: $v[order_id]</div><!--{/if}-->
        <!--{if !$v[addrid]}--><div class="f12 c9">{lang xigua_hm:hxm}: $v[code]</div><!--{/if}-->
    </div>
    <div class="weui-cell__ft"></div>
</a>
<!--{/loop}-->
