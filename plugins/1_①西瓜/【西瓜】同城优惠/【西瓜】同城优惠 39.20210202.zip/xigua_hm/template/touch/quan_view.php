<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<!--{eval $back_to = "$SCRITPTNAME?id=xigua_hm";}-->
<!--{if $_SERVER[HTTP_REFERER]}-->
<!--{eval $back_to = "javascript:window.history.go(-1);";}-->
<!--{/if}-->

<!--{eval
if($_G['cache']['plugin']['xigua_hh'] && $hm_config[allowhhr]):
$hu = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G['uid']);
if(!$hu['end'] && $hu['display']):
    $hhrname = $hu[joininfo][name];
    $hhrpercent = $hu[joininfo][percentage];
endif;
endif;
}-->
<!--{if $v[shen]}-->
<script>
    alert('{lang xigua_hm:shz}');
    window.history.go(-1);
</script>
<!--{/if}-->
<div class="hm_view_nav" style="top:0">
    <a href="$back_to"><i class="iconfont icon-fanhui"></i></a>
    <a href="$SCRITPTNAME?id=xigua_hm"><i class="iconfont icon-index"></i></a>
    <!--{template xigua_hm:hbbutton}-->
</div>
<!--{template xigua_hm:qrcode}-->
<div class="page__bd hong">
    <!--{template xigua_hb:common_nav}-->
    <div class="seckill_bg">
        <img src="{echo $v[album][0]?$v[album][0]:$v[append_img_ary][0]}">
        <em style="background:linear-gradient(to bottom,rgba(,0),rgba(,1));"></em>
    </div>

    <div class="seckill-view-c">
        <div class="seckill-head">
            <div class="seckill-card radius10">
                <p>{$v[fanwei]}</p>
                <h1 class="s_quan_tit"><!--{if $v[stype]=='zhekou'}-->{$v[show_zhekourate]}{lang xigua_hm:zhe}<!--{else}-->{$v[marketprice]}{lang xigua_hm:yuan}{$stypes[$v[stype]]}<!--{/if}--></h1>
                <div class="s_quan_btn_view">

                <!--{if $v[stock]<=0}-->
                <a class="weui-btn weui-btn_primary bg_end" href="javascript:">{lang xigua_hm:ylw}</a>
                <!--{elseif $v[end]}-->
                <a class="weui-btn weui-btn_primary bg_end" href="javascript:">{lang xigua_hm:yjs}</a>
                <!--{else}-->
                <!--{if $v[fszx]&&!$followed}-->
                <a href="javascript:;" class="weui-btn weui-btn_primary bg_sec do_follow2" data-wei="1" data-id="$v[shid]">{lang xigua_hm:djgzlq}</a>
                <!--{else}-->
                    <!--{if !$get}-->
                    <a href="<!--{if isset($checkmobile[2]) && !$user[mobile]}-->$SCRITPTNAME?id=xigua_hb&ac=myzl&referer={echo urlencode(hb_currenturl());}{$urlext}<!--{else}-->javascript:;<!--{/if}-->" class="weui-btn weui-btn_primary bg_sec <!--{if $user&&isset($checkmobile[2]) && !$user[mobile]}--><!--{else}-->doseckill<!--{/if}-->" data-id="$secid" <!--{if $v[old_maxnum]>1 || $v[old_maxnum]==0}-->data-needpopup="1"<!--{/if}-->><!--{if $v[price]>0}-->
                    $v[price]{lang xigua_hm:yuan}{lang xigua_hm:lq}
                    <!--{else}-->
                    {lang xigua_hm:mflq}
                    <!--{/if}-->
                    </a>
                    <!--{else}-->
                    <a href="{$jumpurl}" class="weui-btn weui-btn_primary bg_sec">{lang xigua_hm:qfk}</a>
                    <!--{/if}-->
                <!--{/if}-->
                <!--{/if}-->


                </div>
                <p class="tc color-sec f14"><i class="iconfont icon-hot-02 f14"></i> <!--{if $v[hasqiang]}-->{$v[hasqiang]}{lang xigua_hm:ryl}<!--{else}-->{lang xigua_hm:yhsx}<!--{/if}--></p>

                <!--{if $hm_config[showapppr] && $v[appprice]>0 && !(IN_MAGAPP || IN_QIANFAN || IN_APPBYME)}-->
                <p class="tc color-sec main_color f14"><a href="{$hm_config[guidelink]}">{$hm_config[guideapp]}</a></p>
                <!--{/if}-->

                <ul class="s_quan_li">
                    <li><!--{if $v[underline]}-->{lang xigua_hm:m}{$v[underline]}{lang xigua_hm:ky}<!--{else}-->{lang xigua_hm:wzd}<!--{/if}--></li>
                    <li>{lang xigua_hm:yxqd}:{echo $v[usetime_u] ? $v[usetime_u] : lang_hm('cqyx');}</li>
                    <!--{if $v[old_maxnum]>0}--><li>{lang xigua_hm:lqxz} {$v[old_maxnum]} {lang xigua_hm:zhang}</li><!--{/if}-->

                    <!--{if $v[srange_ary]}-->
                    <!--{loop $v[srange_ary] $_v}-->
                    <li><!--{$_v}--></li>
                    <!--{/loop}-->
                    <!--{/if}-->

                </ul>
            </div>
        </div>
        <div class="seckill-rule seckill-card ">
            <div class="seckill-title-h">{lang xigua_hm:sylc}</div>
            <div class="seckill-rule-c">
                <div class="hm_process weui-flex">
                    <em class="process-line"></em>
                    <div class="weui-flex__item">
                        <i class="iconfont icon-qianggou"></i>
                        <p>{lang xigua_hm:cylq}</p>
                    </div>
                    <div class="weui-flex__item">
                        <i class="iconfont icon-duigou1"></i>
                        <p>{lang xigua_hm:lqcg}</p>
                    </div>
                    <div class="weui-flex__item">
                        <i class="iconfont icon-yanzheng"></i>
                        <p>{lang xigua_hm:ddxf}</p>
                    </div>
                </div>
            </div>
        </div>
        <!--{if $sh}-->
        <div class="seckill-rule seckill-card ">
            <div class="seckill-title-h">{lang xigua_hm:symd}</div>
            <div class="weui-cells seckill_dianjia after_none before_none">
                <div class="weui-cell">
                    <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]"><img src="$sh[logo]" /></a></div>
                    <div class="weui-cell__bd">
                        <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]">{$sh[name]}</a></p>
                        <p class="f13 c9">{lang xigua_hm:yysj}: <em>$sh[opentime]</em></p>
                    </div>
                    <div class="weui-cell__ft"><a class="shtel" href="tel:$sh[tel]"><i class="iconfont icon-unie607 main_color f30"></i></a></div>
                </div>

                <a class="weui-cell weui-cell_access" href="javascript:;" id="v_openLocation" data-lat="$sh[lat]" data-lng="$sh[lng]" data-name="$sh[name]" data-addr="$sh[addr]">
                    <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
                    <div class="weui-cell__bd">
                        <p class="f14">$sh[addr]</p>
                        <p class="f13 c9" id="driving" data-id="$sh[shid]">{lang xigua_hs:jisuan}</p>
                    </div>
                    <div class="weui-cell__ft">
                    </div>
                </a>

            </div>
        </div>
        <!--{/if}-->

<!--{if $_G['cache']['plugin']['xigua_dp'] && in_array('hm', unserialize($_G['cache']['plugin']['xigua_dp']['opens']))}-->
<style>.gzbtn{background-color:$config[maincolor]}.dp_jx_title,.dp_jx_title .weui_title{margin-top:0}</style>
<div id="ptdiv2" class="seckill-rule seckill-card " style="display:none;padding: 0; "></div>
<script>
    $.ajax({type: 'get',dataType: 'xml',
        url: '$SCRITPTNAME?id=xigua_dp&ac=jingxuan&inajax=1&type=hm&typeid=$secid&shid={$sh[shid]}&pagesize=5&page=1',
        success: function (data) {
            if(null==data){ $('#ptdiv2').remove(); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(!s){ $('#ptdiv2').remove(); return false;}
            $('head').append('<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?{VERHASH}" />');
            $('body').append('<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"><\/script>');
            $('#ptdiv2').html(s).show();
        },
        error: function () {$('#ptdiv2').remove();}
    });
</script>
<!--{/if}-->

        <div class="seckill-rule seckill-card seckill-card_last">
            <div class="seckill-title-h">{lang xigua_hm:yhxq}</div>
            <div class="seckill-rule-c">
                <p>{echo hs_nl2br($v['jieshao']);}</p>
                <!--{loop $v[append_img_ary] $__k $__v}-->
                <p><img src="{$__v}" /></p>
                <p>{echo hs_nl2br($v[append_text_ary][$__k]);}</p>
                <!--{/loop}-->
            </div>
        </div>
    </div>

<div class="sec_btn_fix_outer">
<!--{if $had[alnum]!=$v[old_maxnum]}-->
    <!--{if $v[stock]<=0}-->
    <a class="weui-btn weui-btn_primary bg_end sec_btn_fix" href="javascript:">{lang xigua_hm:ylw}</a>
    <!--{elseif $v[end]}-->
    <a class="weui-btn weui-btn_primary bg_end sec_btn_fix" href="javascript:">{lang xigua_hm:yjs}</a>
    <!--{else}-->
    <!--{if !$get}-->
    <a href="<!--{if isset($checkmobile[2]) && !$user[mobile]}-->$SCRITPTNAME?id=xigua_hb&ac=myzl&referer={echo urlencode(hb_currenturl());}{$urlext}<!--{else}-->javascript:;<!--{/if}-->" class="weui-btn weui-btn_primary bg_sec doseckill sec_btn_fix" data-id="$secid" <!--{if $v[old_maxnum]>1 || $v[old_maxnum]==0}-->data-needpopup="1"<!--{/if}-->><!--{if $v[price]>0}-->$v[price]{lang xigua_hm:yuan}{lang xigua_hm:lq}<!--{else}-->{lang xigua_hm:mflq}<!--{/if}--></a>
    <!--{else}-->
    <a href="{$jumpurl}" class="weui-btn weui-btn_primary bg_sec sec_btn_fix">{lang xigua_hm:qfk}</a>
    <!--{/if}-->
    <!--{/if}-->
<!--{else}-->
    <!--{if ($had['endts'] && $had['endts']<TIMESTAMP)}-->
    <a href="javascript:;" class="weui-btn weui-btn_primary bg_sec sec_btn_fix">{lang xigua_hm:dhqygq}</a>
    <!--{else}-->
    <a href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$had[id]" class="weui-btn weui-btn_primary bg_sec sec_btn_fix">{lang xigua_hm:ljsy}</a>
    <!--{/if}-->
<!--{/if}-->
</div>

</div>
<!--{eval include_once DISCUZ_ROOT.'source/plugin/xigua_hm/common_ext.php';}-->
<!--{if hm_get_shids_by_uid1($sh[shid])||IS_ADMINID}-->
<a href="javascript:;" style="bottom:30%;" class=" hbzd quan_zs">{lang xigua_hm:zsong}<em class="iconfont icon-jinrujiantou f12"></em></a>
<!--{/if}-->
<div id="zspop" style="z-index:999" class="weui-popup__container popup-bottom">
    <form  action="$SCRITPTNAME?id=xigua_hm&ac=tk&do=zs" method="post" id="form">
        <input name="formhash" value="{FORMHASH}" type="hidden">
        <input name="inajax" value="1" type="hidden">
        <input name="st" value="{$_GET['st']}" type="hidden">
        <input name="secid" value="{$secid}" type="hidden">

        <div class="weui-popup__overlay"></div>
        <div class="weui-popup__modal">
            <div class="toolbar">
                <div class="toolbar-inner">
                    <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:quxiao}</a>
                    <h1 class="title">{lang xigua_hm:zsyhk}</h1>
                </div>
            </div>
            <div class="modal-content">
                <div class="weui-cells before_none after_none">
                    <div class="weui-cell f14">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hm:zssl}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="num" type="tel" placeholder="{lang xigua_hm:qtxzssl}">
                        </div>
                    </div>
                    <div class="weui-cell f14">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hm:zsyhuid}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="touid" type="text" placeholder="{lang xigua_hm:qtxzsyhuid}">
                        </div>
                    </div>
                    <div class="weui-cell f14">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hm:lybz}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" name="note" type="text" placeholder="{lang xigua_hm:qtxlybz}">
                        </div>
                    </div>
                </div>
                <div class="fix-bottom" style="position: relative">
                    <input type="submit" id="dosubmit" href="javascript:;" class="weui-btn weui-btn_primary" value="{lang xigua_hs:queding}">
                </div>
            </div>
        </div>
    </form>
</div>

<!--{if $hm_config[showreal]&&$v[logs]}-->
<!--{template xigua_hm:slider}-->
<!--{/if}-->
<!--{eval $tabbar=0;}-->
<!--{template xigua_hm:pay_item}-->
<!--{template xigua_hb:common_footer}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>
<script>
$(function () {
    var isPageHide = false;
    window.addEventListener('pageshow', function () {
        if (isPageHide) {
            window.location.reload();
        }
    });
    window.addEventListener('pagehide', function () {
        isPageHide = true;
    });
});
$(document).on('click','.quan_zs', function () {
    $("#zspop").popup();
});
<!--{if $hm_config[haitype]==2}-->
    $(document).on('click','.sec_newewm', function () {
$.showLoading();
        html2canvas(document.querySelector(".shot_in")).then(canvas => {
            var dataURL = canvas.toDataURL();
            COMCLAS = 'shot_outer';
$.hideLoading();
            $.alert("<img src='"+dataURL+"' />  <!--{if $bword}-->{$bword}<!--{elseif $hhrname}--><div style='margin-bottom:10px'><p class='f12'>{lang xigua_hm:hhrdj} : <em class=main_color>$hhrname</em></p><p class='f12'>{lang xigua_hm:bl} : <em class=main_color>{$hhrpercent}</em></p></div><!--{/if}-->",fxqg);
            $('.weui-dialog__title').css('font-size', '14px');
            COMCLAS = '';
        });
        return false;
    });
<!--{/if}-->
setTimeout(function () {$('.hbzd').addClass('r-21');}, 800);
</script>
<!--{template xigua_hm:mgshare}-->