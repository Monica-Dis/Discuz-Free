<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<!--{if $error==lang_hs('qsrhxmm',0)}-->
<script>
    function input_hx_mm(shid) {
        $.prompt("{lang xigua_hs:qsrhxmm}", function(text) {
            $.showLoading();
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hs&ac=setpwd&type=check&inajax=1&shid='+shid,
                data:{formhash:'{FORMHASH}',  hxpwd:text},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    var sar = s.split('|');
                    tip_common(s);
                    setTimeout(function () {
                        window.location.href = location.href+'&time='+((new Date()).getTime());
                    }, 2000);
                },
                error: function () {
                    $.hideLoading();
                }
            });

        }, function() {
            window.history.go(-1);
        });
    }
    input_hx_mm({$secinfo['shid']});
</script>
<!--{elseif $error==lang_hm('queren', 0)}-->
<!--{eval

$sec = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_ids(array($loginfo['secid']));
$sec = $sec[$loginfo['secid']];
    }-->
<script>
    function input_qr(user, mobile, order, num, ti, price, note, tti) {
        $.confirm({
            title: '{lang xigua_hm:qrhx}',
            text: '<p style="text-align:left">{lang xigua_hm:gmyh}: <b class="main_color">' + user + '</b></p>'+
            '<p style="text-align:left">{lang xigua_hb:bind_mobile}: <b class="main_color">' + mobile + '</b></p>'+
            '<p style="text-align:left">{lang xigua_hm:ddbh}: <b class="main_color">' + order + '</b></p>'+
            '<p style="text-align:left">{lang xigua_hm:title}: <b class="main_color">' + tti + '</b></p>'+
            '<p style="text-align:left">{lang xigua_hm:gmsl}: <b class="main_color">' + num + '</b></p>'+
            '<p style="text-align:left">{lang xigua_hm:xdsj}: <b class="main_color">' + ti + '</b></p>'+
            '<p style="text-align:left">{lang xigua_hm:order_price}: <b class="main_color">' + price + '</b></p>'+
            '<p style="text-align:left">{lang xigua_hm:bz}: <b class="main_color">' + note + '</b></p>'
            ,
            onOK: function () {$.showLoading();
                setTimeout(function () {
                    window.location.href = location.href+'&quren=1&time='+((new Date()).getTime());
                }, 500);
            },
            onCancel:function () {
                window.location.href = _APPNAME+'?id=xigua_hb&ac=my&mobile=2';
            }
        });
    }
    input_qr('{$loginfo[user][username]}', '{$__profile[mobile]}', '{$loginfo[order_id]}',  '{$loginfo[num]}',  '{$loginfo[crts_u]}', '{$loginfo[price]}{lang xigua_hm:yuan}', '{$loginfo[note]}', '{$sec[title]}{$loginfo[ggname]}');
</script>
<!--{else}-->
<script>
    $.alert('$error', function () {
        window.location.href = _APPNAME+'?id=xigua_hm&ac=scan'+_URLEXT;
    });
</script>
<!--{/if}-->
<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
