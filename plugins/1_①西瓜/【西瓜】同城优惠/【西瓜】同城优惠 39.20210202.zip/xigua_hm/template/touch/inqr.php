<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-cells__title">{lang xigua_hm:schxmrgksmhx}</div>
    <div class="fix-bottom" style="position:relative">
        <a class="mt0 qrbtn weui-btn weui-btn_primary" href="$SCRITPTNAME?id=xigua_hm&ac=hx&do=showqr">
            <i class="qri iconfont icon-erweima"></i> {lang xigua_hm:skm} </a>
    </div>
    <div class="weui-cells__title">{lang xigua_hm:smgkdewm}</div>
    <div class="fix-bottom" style="position:relative">
        <a class="qrbtn weui-btn weui-btn_default" onclick="<!--{if IN_MAGAPP}-->mag.scanQR(function(text){window.location.href=text});<!--{elseif IN_QIANFAN}-->qianfanScan();<!--{elseif IN_APPBYME}-->appbymeScan();<!--{else}-->comscan();<!--{/if}-->" href="javascript:;">
            <i class="qri iconfont icon-saoyisao"></i> {lang xigua_hm:sys} </a>
    </div>
    <div class="weui-cells__title">{lang xigua_hm:srdhmjxhx}</div>
    <div class="fix-bottom" style="position:relative">
        <a class="mt0 qrbtn weui-btn weui-btn_default" href="$SCRITPTNAME?id=xigua_hm&ac=scan">
            <i class="qri iconfont icon-hexiao"></i> {lang xigua_hm:dhm} </a>
    </div>
</div>
<!--{eval $tabbar=1;$hs_tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<script>
function comscan() {
    if(typeof wx!='undefined'){
        wx.scanQRCode();
    }else if(navigator.userAgent.indexOf('bsl') >=0 && typeof BSL!='undefined'){
        BSL.Qcode('1', 'bslsetqr')
    }
}
function bslsetqr(result){
    window.location.href = result;
}
function appbymeScan() {
    sq.scan(function(result){
        window.location.href=result.url;
    });
}
function qianfanScan(){
    QFH5.jumpScan(function(state,data){
        if(state==1){
            window.location.href=data.content;
        }else{
        }
    })
}
</script>