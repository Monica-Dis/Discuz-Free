<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="pay_ctrl" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hm:qx}</a>
                <h1 class="title">{lang xigua_hm:xzsl}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <!--{if $v[fee_type]==2}-->
                <div class="weui-cell weui-cell_access after_none f14" id="pay_address">
                    <div class="weui-cell__bd">
                        <p style="min-width: 120px;">{lang xigua_hm:shouhuodizhi}</p>
                    </div>
                    <div class="weui-cell__ft">
                        <!--{if $dft}-->
                        <span class="f12 ">{lang xigua_hm:shoujianren}: {$dft[realname]} {$dft[mobile]}</span>
                        <div class="f12">{lang xigua_hm:shouhuodizhi}: {$dft[dist1]}{$dft[dist2]}{$dft[dist3]}{$dft[address]}</div>
                        <!--{/if}-->
                    </div>
                    <div class="addrbx"></div>
                </div>
                <!--{/if}-->

                <div class="weui-cell before_none mt10 f14">
                    <div class="weui-cell__bd" style="min-width:80px">
                        <p>{lang xigua_hm:spmc} </p>
                    </div>
                    <div class="weui-cell__ft main_color">
                        <span class="c9">{$v[title]}</span>
                    </div>
                </div>

                <!--{if $v[ggary]}-->
                <div class="weui-cell f14">
                    <div class="weui-cell__bd">
                        <p class="c3 mb8">{$v[ggname]}</p>
                        <div class="post-tags buy-tags cl">
<!--{if $_G['cache']['plugin']['xigua_hk']}-->
<!--{eval
$card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G['uid']);
}-->
<!--{/if}-->
<!--{loop $v[ggary] $_ggt}-->
    <a class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;" onclick="return setSpgg('{$_ggt[0]}', this, '{echo $card&&$_ggt[3] ? $_ggt[3] :$_ggt[2]}');">{$_ggt[0]}</a>
<!--{/loop}-->
                            <input class="gginput" id="gginput" type="hidden" value="">
                        </div>
                    </div>
                </div>
                <!--{/if}-->

                <div class="weui-cell f14" style="padding:8px 15px"><!--{eval
                $pagemax = $v[maxnum]?$v[maxnum]:$v[allnum];
                if($hm_config[danci]>0):
                    $pagemax= min($pagemax, $hm_config[danci]);
                endif;
                }-->
                    <div class="weui-cell__bd">
                        <p>{lang xigua_hm:gmsl}</p>
                        <!--{if $v[maxnum]}--><span class="c9 f12">{lang xigua_hm:mrxg}{$v[maxnum]}{lang xigua_hm:jian} </span><!--{/if}-->
                        <!--{if $hm_config[danci]}--><span class="c9 f12"> {lang xigua_hm:dcxl}$hm_config[danci]{lang xigua_hm:jian}</span><!--{/if}-->
                    </div>
                    <div class="weui-cell__ft main_color">
                        <i class="iconfont icon-jianshao2 inc-num" data-step="-1"></i>
                        <input class="inc-input" type="tel" name="item_num" id="item_num" value="1" data-fee="{$v[fee]}" data-price="{$v[price]}" data-max="$pagemax" readonly="readonly" />
                        <i class="iconfont icon-tianjia1 inc-num" data-step="1"></i>
                    </div>
                </div>

                <!--{if $v[fee_type]==2}-->
                <div class="weui-cell f14">
                    <div class="weui-cell__bd">
                        <p>{lang xigua_hm:psfs}</p>
                    </div>

                    <div class="weui-cell__ft">
                        <span class="">{lang xigua_hm:fee} {$v[fee]}{lang xigua_hm:yuan}</span>
                    </div>
                </div>
                <!--{/if}-->
<!--{eval $formgg = explode("\n", trim($v[formgg]));}-->
<!--{loop $formgg $_k $_v}-->
<!--{eval $_v = trim($_v);}-->
<!--{if $_v}-->
    <div class="weui-cell f14">
        <div class="weui-cell__hd"><label class="weui-label">{$_v}</label></div>
        <div class="weui-cell__bd">
            <input class="weui-input formggdiv" name="formgg[$_k]" type="text" placeholder="{lang xigua_hm:qtx}{$_v}">
        </div>
    </div>
<!--{/if}-->
<!--{/loop}-->
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hm:mjly}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="item_note" id="item_note" type="text" placeholder="{lang xigua_hm:mjlytip}">
                    </div>
                </div>

                <div class="weui-cell f14">
                    <div class="weui-cell__bd"> </div>
                    <div class="weui-cell__ft main_color">
                        <span class="">{lang xigua_hm:g}<em id="num_display">1</em>{lang xigua_hm:fen} {lang xigua_hm:xj}<em id="num_price">{eval echo ($v[price]+$v[fee]);}</em>{lang xigua_hm:yuan}</span>
                    </div>
                </div>

                <!--{if $v[fee_type]==1 && $v[usetime_u]}-->
                <div class="weui-cell f14">
                    <div class="weui-cell__bd">{lang xigua_hm:gmh}{$v[usetime_u]}{lang xigua_hm:zsj}</div>
                </div>
                <!--{/if}-->
            </div>

            <div class="fix-bottom" style="position: relative">
            <!--{if $user && isset($checkmobile[2]) && !$user[mobile]}-->
                    <!--{if $v['stype']!='seckill'}-->
                    <a class="weui-btn weui-btn_primary" href="$SCRITPTNAME?id=xigua_hb&ac=myzl&referer={echo urlencode(hb_currenturl());}{$urlext}"><!--{if $v[price]>0}-->{lang xigua_hm:ljlq}<!--{else}-->{lang xigua_hm:mflq}<!--{/if}--></a>
                    <!--{else}-->
                    <a class="weui-btn weui-btn_primary" href="$SCRITPTNAME?id=xigua_hb&ac=myzl&referer={echo urlencode(hb_currenturl());}{$urlext}">{lang xigua_hm:ljgm}</a>
                    <!--{/if}-->
            <!--{else}-->
                <!--{if $v['stype']!='seckill'}-->
                <input type="submit" href="javascript:;" class="weui-btn weui-btn_primary doseckill" data-id="$secid" value="<!--{if $v[price]>0}-->{lang xigua_hm:ljlq}<!--{else}-->{lang xigua_hm:mflq}<!--{/if}-->">
                <!--{else}-->
                <input type="submit" href="javascript:;" class="weui-btn weui-btn_primary doseckill" data-addrid="{eval echo $v[fee_type]==2 ? $dft[id] : 0;}" data-id="$secid" value="{lang xigua_hm:ljgm}">
                <!--{/if}-->
            <!--{/if}-->
            </div>
        </div>
    </div>
</div>
<script>
$(function () {
    var isPageHide = false;
    window.addEventListener('pageshow', function () {
        if (isPageHide) {
            window.location.reload();
        }
    });
    window.addEventListener('pagehide', function () {
        isPageHide = true;
    });
});
function setSpgg(id, obj, price) {
    var par = $(obj).parent();
    var tgo = par.find('.tag-on');
    if(tgo.length> 0){
        tgo.removeClass('tag-on');
        par.find('input').val('0');
    }

    if ($(obj).hasClass('tag-on')) {
        $(obj).removeClass('tag-on');
        $('#gginput').val('');
    } else {
        $(obj).addClass('tag-on');
        $('#gginput').val(id);
        var  num = parseInt($('#num_display').text());
        var ptmp = num*price;
        console.log(ptmp);
        $('#item_num').attr('data-price', price);
        $('#num_price').html(ptmp);
    }
}
</script>