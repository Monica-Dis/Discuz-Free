<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<!--{eval
$showkf = 1;
$bg = $v['sec'][album][0]?$v['sec'][album][0]:$v['sec'][append_img_ary][0];
}-->
<!--{if $v[sec][fee_type]==1}-->
<!--{eval $v[postinfo] = '';$v[addrid]=0;}-->
<!--{/if}-->
<style>.seckill-head {margin-top: calc(100vw - 300px);}<!--{if !$bg}-->.navtitle{display:none}.seckill-head{margin-top:0}<!--{/if}--></style>
<div class="page__bd hong">
    <!--{template xigua_hb:common_nav}-->
    <div class="seckill_bg">
        <img src="{$bg}">
        <em style="background:linear-gradient(to bottom,rgba(,0),rgba(,1));"></em>
    </div>

    <div class="seckill-view-c">
        <!--{if $v[addrid]>0}-->
        <div class="seckill-head">
            <div class="seckill-card radius10">
            <div class="seckill-title-h tl">{lang xigua_hm:ddxq}</div>
                <div class="weui-cells seckill_dianjia after_none before_none">
                    <!--{if $admin_show}-->
                    <div class="weui-cell  tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:gmyh}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <p><img src="{avatar($v[uid], 'middle', true)}" class="hm_order_avatar"> {$v[user][username]}</p>
                        </div>
                    </div>
                    <!--{eval
                    $__profile = C::t('#xigua_hb#xigua_hb_user')->fetch($v['uid']);
                    if(!$__profile[mobile]):
                        $__profile = C::t('common_member_profile')->fetch($v['uid']);
                    endif;
                    }-->
                    <div class="weui-cell  tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hb:bind_mobile}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <p>{$__profile[mobile]}</p>
                        </div>
                    </div>
                    <!--{/if}-->
                    <div class="weui-cell <!--{if !$admin_show}-->pt0<!--{/if}--> tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:ddbh}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <p>{$v[order_id]}</p>
                        </div>
                    </div>
                    <div class="weui-cell tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:gmsl}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <p>$v[num]</p>
                        </div>
                    </div>
                    <div class="weui-cell tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:xdsj}</p>
                        </div>
                        <div class="weui-cell__ft">{echo dgmdate($v['crts'], 'Y-m-d H:i:s');}</div>
                    </div>
                    <!--{if $v[price]>0}-->
                    <div class="weui-cell tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:order_price}</p>
                        </div>
                        <div class="weui-cell__ft"><em class="f18 color-sec">{$v[price]}{lang xigua_hm:yuan}</em></div>
                    </div>
                    <!--{/if}-->
                    <div class="weui-cell">
                        <div class="weui-cell__bd tl">
                            <p>{lang xigua_hm:shouhuodizhi}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <!--{if $dft}-->
                            <span class="f12 ">{lang xigua_hm:shoujianren}: {$dft[realname]} {$dft[mobile]}</span>
                            <div class="f12">{$dft[dist1]}{$dft[dist2]}{$dft[dist3]}{$dft[address]}</div>
                            <!--{/if}-->
                            <!--{if $v[note]}--><div class="f12">{lang xigua_hm:bz}:{$v[note]}</div><!--{/if}-->
                            <!--{if $v[formggs]}--><div class="f12">{$v[formggs]}</div><!--{/if}-->
                        </div>
                    </div>


                    <!--{if $v[tkts]>0}-->
                    <div class="weui-cell tl after_none">
                        <div class="weui-cell__bd">
                            <p><!--{if $v[hxstatus]==6}-->{lang xigua_hm:ytk}<!--{else}-->{lang xigua_hm:zfcs}<!--{/if}--></p>
                        </div>
                        <div class="weui-cell__ft f14">{echo date("Y-m-d H:i:s", $v[tkts]);}</div>
                    </div>
                    <!--{else}-->

                    <!--{if $order[$v[order_id]][paystatus] || !$v[order_id]}-->
                    <!--{eval $shids = check_hm_manage();}-->
                    <!--{if $v[addrid] && !$v[postinfo] && in_array($v[shid], $shids)}-->
                    <div class="weui-cell tl after_none">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:fhzt}</p>
                        </div>
                        <div class="weui-cell__ft"><a class="hm_fahuo" href="javascript:void(0);" data-id="$v[id]">{lang xigua_hm:djfh}</a></div>
                    </div>
                    <!--{else}-->
                    <a class="weui-cell weui-cell_access after_none tl main_color" <!--{if $v[postinfo][danhao]}-->href="https://m.kuaidi100.com/result.jsp?nu={$v[postinfo][danhao]}"<!--{else}-->href="javascript:$.alert('{lang xigua_hm:dfh}');"<!--{/if}-->>
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:fhzt}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <!--{if $v[postinfo]}-->
                            <div class="f12 main_color">{lang xigua_hm:yfh}</div>
                            <span class="f12 main_color ">{$v[postinfo][company]}&nbsp;&nbsp;{lang xigua_hm:dh}:{$v[postinfo][danhao]}</span>
                            <!--{else}-->
                            <div class="f12 main_color">{lang xigua_hm:dfh}</div>
                            <!--{/if}-->
                        </div>
                    </a>
                    <!--{/if}-->
                    <!--{else}-->
                    <a class="weui-cell weui-cell_access after_none tl main_color" href="$v[jumpurl]">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:ljfk}</p>
                        </div>
                        <div class="weui-cell__ft">
                        </div>
                    </a>
                    <!--{/if}-->
                <!--{/if}-->


                </div>
            </div>
        </div>
        <!--{else}-->
        <div class="seckill-head">
            <li class="seckill-card radius10">
                <p>{$v[sec][fanwei]}</p>
                <h1 class="s_quan_tit">
                <!--{if $v[sec][stype]=='seckill'}-->
            {$v[sec][title]} {$v[ggname]}
                <!--{else}-->
            <!--{if $v[sec][stype]=='zhekou'}-->{$v[sec][show_zhekourate]}{lang xigua_hm:zhe}<!--{else}-->{$v[sec][marketprice]}{lang xigua_hm:yuan}{$stypes[$v[sec][stype]]}<!--{/if}-->
                <!--{/if}-->
                </h1>
<!--{if $v[tkts]<=0}-->
                <!--{if $order[$v[order_id]][paystatus] || !$v[order_id]}-->
                    <!--{if $v['uid']==$_G[uid]}-->
                                <div>
<!--{if $hm_config[yuk] &&  $v[sec][dingprice]>0}-->
<!--{if $yukuan = round(($v[sec][old_price]-$v[sec][old_dingprice])*$v[num], 2) > 0}-->
    <!--{if DB::fetch_first('SELECT * FROM %t WHERE gtype=%s AND gid=%d AND shid=%d and pay_ts>1 LIMIT 1', array('xigua_hs_fukuan', 'sec', $v[id], $v[shid]))}-->
    <a href="javascript:;" class="mt0 weui-btn weui-btn_default">{lang xigua_hm:yzfyk}</a>
    <!--{else}-->
    <a href="javascript:;" id="fyk" class="mt0 weui-btn weui-btn_primary">{lang xigua_hm:fyk}</a>
    <!--{/if}-->
<!--{/if}-->
<!--{/if}-->
                                    <img src="{$codeurl}" style="display:block" />
                                </div>
                                <div>{lang xigua_hm:dhm}: <em class="main_color">{echo hm_space_number($v[code])}</em> </div>
                    <!--{/if}-->
                <!--{/if}-->
                <!--{if $v[hxstatus]==1}-->
                    <div>
                        <em class="main_color">{lang xigua_hm:yy}{$v[hxcrts_u]}{lang xigua_hm:xf}</em>
                    </div>
                <!--{/if}-->
<!--{/if}-->
<!--{eval
$start_time = date('Y-m-d H:i:s', $v[startts]);
}-->
                <ul class="s_quan_li mt10">
                    <!--{if $v[sec][usetime_u] || $v[startts]>0}-->
                    <li> {lang xigua_hm:syxuz}
                            <!--{if $v[sec][usetime_u]&&$v[startts]}-->
                        <span class="main_color">$start_time - $v[sec][usetime_u]</span>
                            <!--{elseif $v[sec][usetime_u]}-->
                        <span  class="main_color">$v[sec][usetime_u] {lang xigua_hm:zq}</span>
                            <!--{elseif $v[startts]}-->
                        <span   class="main_color">{$start_time}{lang xigua_hm:wxz}</span>
                            <!--{/if}-->
                    </li>
                    <!--{/if}-->
                    <li><!--{if $v[sec][underline]}-->{lang xigua_hm:man}{$v[sec][underline]}{lang xigua_hm:ky}<!--{else}-->{lang xigua_hm:wzd}<!--{/if}--></li>
                    <!--{if $v[sec][usetime_u]}-->
                    <li>{lang xigua_hm:yxqd}:{$v[sec][usetime_u]}</li>
                    <!--{/if}-->
                    <!--{if $v[sec][srange_ary]}-->
                    <!--{loop $v[sec][srange_ary] $_v}-->
                    <li><!--{$_v}--></li>
                    <!--{/loop}-->
                    <!--{/if}-->
                </ul>

                <!--{if $admin_show}-->
                <div class="weui-cells seckill_dianjia after_none before_none">
                    <div class="weui-cell  tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:gmyh}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <p><img src="{avatar($v[uid], 'middle', true)}" class="hm_order_avatar"> {$v[user][username]}</p>
                        </div>
                    </div>

                    <!--{eval
                    $__profile = C::t('#xigua_hb#xigua_hb_user')->fetch($v['uid']);
                    if(!$__profile[mobile]):
                        $__profile = C::t('common_member_profile')->fetch($v['uid']);
                    endif;
                    }-->
                    <div class="weui-cell  tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hb:bind_mobile}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <p>{$__profile[mobile]}</p>
                        </div>
                    </div>

                    <!--{if $v[order_id]}-->
                    <div class="weui-cell  tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:ddbh}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <p>{$v[order_id]}</p>
                        </div>
                    </div>
                    <!--{/if}-->
                    <div class="weui-cell tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:gmsl}</p>
                        </div>
                        <div class="weui-cell__ft">
                            <p>$v[num]</p>
                        </div>
                    </div>
                    <div class="weui-cell tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:xdsj}</p>
                        </div>
                        <div class="weui-cell__ft">{echo dgmdate($v['crts'], 'Y-m-d H:i:s');}</div>
                    </div>
                    <!--{if $v[price]>0}-->
                    <div class="weui-cell tl">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_hm:order_price}
                                <!--{if $v[sec][dingprice]>0}-->
                                <em class="s_quan_tag b-color" style="position:relative;bottom:auto">{lang xigua_hm:dingprice}</em>
                                <!--{/if}-->
                            </p>
                        </div>
                        <div class="weui-cell__ft"><em class="f18 color-sec">{$v[price]}{lang xigua_hm:yuan}</em></div>
                    </div>
                    <!--{/if}-->
                    <!--{if $v[note]}-->
                    <div class="weui-cell">
                        <div class="weui-cell__bd tl">
                            <p>{lang xigua_hm:bz}</p>
                        </div>
                        <div class="weui-cell__ft">
                            {$v[note]}
                        </div>
                    </div>
                    <!--{/if}-->
                    <!--{if $v[formggs]}-->
                    <div class="weui-cell">
                        <div class="weui-cell__bd tl">
                            <p>{lang xigua_hm:bz}</p>
                        </div>
                        <div class="weui-cell__ft">
                            {$v[formggs]}
                        </div>
                    </div>
                    <!--{/if}-->

                    <!--{if $v[tkts]>0}-->
                    <div class="weui-cell tl">
                        <div class="weui-cell__bd tl">
                            <p><!--{if $v[hxstatus]==6}-->{lang xigua_hm:ytk}<!--{else}-->{lang xigua_hm:zfcs}<!--{/if}--></p>
                        </div>
                        <div class="weui-cell__ft f14">{echo date("Y-m-d H:i:s", $v[tkts]);}</div>
                    </div>
                    <!--{/if}-->

                </div>
                <!--{/if}-->
            </div>
        </div>
        <!--{/if}-->
        <!--{if $v[sec][fee_type]==1}-->
        <div class="seckill-rule seckill-card ">
            <div class="seckill-title-h">{lang xigua_hm:sylc}</div>
            <div class="seckill-rule-c">
                <div class="hm_process weui-flex">
                    <em class="process-line"></em>
                    <div class="weui-flex__item">
                        <i class="iconfont icon-qianggou"></i>
                        <p>{lang xigua_hm:cyqg}</p>
                    </div>
                    <div class="weui-flex__item">
                        <i class="iconfont icon-duigou1"></i>
                        <p>{lang xigua_hm:fkcg}</p>
                    </div>
                    <div class="weui-flex__item">
                        <i class="iconfont icon-yanzheng"></i>
                        <p>{lang xigua_hm:ddyzxf}</p>
                    </div>
                </div>
            </div>
        </div>
        <!--{/if}-->

        <div class="seckill-rule seckill-card ">
            <div class="seckill-title-h">{lang xigua_hm:symd}</div>
            <div class="weui-cells seckill_dianjia after_none before_none">
                <div class="weui-cell">
                    <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]"><img src="$sh[logo]" /></a></div>
                    <div class="weui-cell__bd">
                        <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]">{$sh[name]}</a></p>
                        <p class="f13 c9">{lang xigua_hm:yysj}: <em>$sh[opentime]</em></p>
                    </div>
                    <div class="weui-cell__ft"><a class="shtel" href="tel:$sh[tel]"><i class="iconfont icon-unie607 main_color f30"></i></a></div>
                </div>

                <a class="weui-cell weui-cell_access" href="javascript:;" id="v_openLocation" data-lat="$sh[lat]" data-lng="$sh[lng]" data-name="$sh[name]" data-addr="$sh[addr]">
                    <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
                    <div class="weui-cell__bd">
                        <p class="f14">$sh[addr]</p>
                        <p class="f13 c9" id="driving" data-id="$sh[shid]">{lang xigua_hs:jisuan}</p>
                    </div>
                    <div class="weui-cell__ft">
                    </div>
                </a>

            </div>
        </div>
        <div class="seckill-rule seckill-card ">
            <div class="seckill-title-h">{lang xigua_hm:jieshao}</div>

            <div class="weui-cells seckill_dianjia after_none before_none">
                <a class="weui-cell weui-cell_access pt0" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid={$v[sec][id]}">
                    <div class="weui-cell__bd">
                        <p>{$v[sec][title]}</p>
                    </div>
                    <div class="weui-cell__ft">
                    </div>
                </a>
            </div>

            <div class="seckill-rule-c">
                <p>{echo hs_nl2br(strpos($v[sec]['jieshao'], '&lt;')!==false?htmlspecialchars_decode($v[sec]['jieshao']):$v[sec]['jieshao']);}</p>
                <!--{loop $v[sec][append_img_ary] $__k $__v}-->
                <p><img src="{$__v}" /></p>
                <p>{echo hs_nl2br(strpos($v[sec][append_text_ary][$__k], '&lt;')!==false?htmlspecialchars_decode($v[sec][append_text_ary][$__k]):$v[sec][append_text_ary][$__k]);}</p>
                <!--{/loop}-->
            </div>
        </div>
    </div>

</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>
<script>
    $(document).on('click','.hm_fahuo', function () {
        var that = $(this);
        $.prompt("{lang xigua_hm:fh}", function(text) {
            $.showLoading();
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hm&ac=my_order&do=fahuo&inajax=1',
                data:{formhash:'{FORMHASH}', lid : that.data('id'), company:$('#company').val(),danhao:$('#danhao').val() },
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }, function() {
        });
        $('#weui-prompt-input').replaceWith('<input class="weui-prompt-input needsclick weui-input needsclick_input" type="text" id="company" placeholder="{lang xigua_hm:kdgs}" />');
        setTimeout(function(){
            $('.weui-dialog__bd').after('<div class="dialog_custom"><div><input id="danhao" class="weui-input needsclick_input" type="text" placeholder="{lang xigua_hm:danhao}"></div></div>');
        }, 150);
    });
    <!--{if $_GET['fahuo']}-->
    $('.hm_fahuo').trigger('click');
    <!--{/if}-->
<!--{if $hm_config[yuk] && $v[sec][dingprice]>0}-->
    <!--{eval $yukuan = round(($v[sec][old_price]-$v[sec][old_dingprice])*$v[num], 2);}-->
    $(document).on('click','#fyk', function () {
        var inputval = '{lang xigua_hs:x}{$v[sec][shname]}{lang xigua_hs:fk} {$v[sec][title]}{lang xigua_hm:yk} $yukuan {lang xigua_hs:yuan}';
        $.prompt({
            title: '{$v[sec][title]}',
            empty: false,
            text: inputval,
            onOK: function (input) {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME +'?id=xigua_hs&ac=help&do=fuk&inajax=1&gtype=sec&gid={$v[id]}',
                    data: {'formhash':FORMHASH, 'money' : '$yukuan','note' : input, shid: '$v[shid]'},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            },
            onCancel: function () {
                $.hideLoading();
            }
        });
        setTimeout(function(){
            $('#weui-prompt-input').text(inputval).val(inputval);
            $('.weui-dialog__bd').before('<div class="dialog_custom"><p class="main_color">{lang xigua_hm:hxzf} {$yukuan} {lang xigua_hs:yuan}</p></div>');
        }, 150);
    });
<!--{/if}-->
</script>