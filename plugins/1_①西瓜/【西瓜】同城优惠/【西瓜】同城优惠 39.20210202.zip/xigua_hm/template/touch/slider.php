<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $v[logs]}-->
<script>
    var TOUTIAOS = [];
    <!--{loop $v[logs] $vvv}-->
    TOUTIAOS.push("<a href=\"javascript:;\" class='f12'> <img src=\"{avatar($vvv[uid], 'middle', true)}\" class='avt' /> <em>{$vvv[user][username]}</em> {$vvv[crts_u]} <!--{if $vvv[stype]=='seckill'}-->{lang xigua_hm:gmcg}<!--{else}-->{lang xigua_hm:lqcg}<!--{/if}--></a>");
    <!--{/loop}-->
</script>
<!--{/if}-->
<div class="noti"></div>