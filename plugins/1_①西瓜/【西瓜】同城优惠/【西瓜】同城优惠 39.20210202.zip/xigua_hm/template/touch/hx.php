<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
<!--{if $qrfile}-->
    <div style="background: #fff;position: absolute;width: 100vw;bottom: 0;top: 0;left: 0;">
        <div style="padding: 100px 40px 0 40px;width: 100%;height: 100%;position: relative;-moz-box-sizing: border-box;box-sizing: border-box;-webkit-user-select: none;text-align: center">
            <img src="$qrfile" />
            <div class="about-panel-name f18">{lang xigua_hm:wxsmhx}</div>
            <div class="about-panel-desc c9 f14" style="line-height:2.5">{lang xigua_hm:tgewmgkhsm}</div>
        </div>
    </div>
<!--{/if}-->

</div>

<!--{eval $tabbar=0;$hs_tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->