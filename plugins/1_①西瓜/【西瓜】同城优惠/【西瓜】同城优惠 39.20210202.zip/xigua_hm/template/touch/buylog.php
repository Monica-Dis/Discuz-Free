<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div  id="list" class="weui-cells p0"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>var loadingurl = window.location.href+'&ac=buylog_li&inajax=1&pagesize=30&page=';</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->