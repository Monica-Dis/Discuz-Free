<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<div class="page__bd">

    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hm&ac=income" class="weui-navbar__item <!--{if !$do}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:weiru}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hm&ac=income&do=reach" class="weui-navbar__item <!--{if $do=='reach'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hm:yiru}</span>
        </a>
    </div>
    <div class="weui-cells__title">
        <!--{if $do}-->
        <b class="main_color">{lang xigua_hm:yiru}</b> {lang xigua_hm:wrtip1}<a <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jumpDownload();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao&mobile=2"<!--{/if}--><!--{/if}-->  class="a">{lang xigua_hm:qianbao}</a>{lang xigua_hm:wrtip2}
        <!--{else}-->
        <b class="main_color">{lang xigua_hm:weiru}</b> {lang xigua_hm:yirutip1}<a <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jumpDownload();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao&mobile=2"<!--{/if}--><!--{/if}-->  class="a">{lang xigua_hm:qianbao}</a>{lang xigua_hm:wrtip2}
        <!--{/if}-->
    </div>

    <div  id="list" class="weui-cells p0 mt0 before_none"></div>

    <script>
        var loadingurl = window.location.href+'&ac=income_li&inajax=1&do=$do&pagesize=20&page=';
    </script>

    <!--{template xigua_hb:loading}-->

</div>

<!--{eval $tabbar=1;$hs_tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->