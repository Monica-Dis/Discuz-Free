<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<a href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]" class="weui-cell">
    <div class="weui-cell__hd" style="position: relative;margin-right: 10px;">
        <img src="{avatar($v[uid], 'middle', true)}" style="width:30px;height:30px;margin-right:5px;display:block;border-radius:50%" />
    </div>
    <div class="weui-cell__bd">
        <p>{$v[user][username]}</p>
    </div>
    <div class="weui-cell__ft">
        $v[crts_u]
        $v[num]{lang xigua_hm:fen}
    </div>
</a>
<!--{/loop}-->
