<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<link rel="stylesheet" href="source/plugin/xigua_hm/static/hm.css?{VERHASH}" />
<link rel="stylesheet" href="source/plugin/xigua_hs/static/hs.css?{VERHASH}" />
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}
<!--{if $ac=='index'}-->.position1 li.current{background-color:rgba(255,255,255,.5)!important}<!--{/if}-->
<!--{if $hm_config[clr]}-->.color-sec,.percent-word,.timedown .percent-line,.seckill_price,.color-red,.seckill-card h2,.hong .x_header a,.timer i{color:{$hm_config[clr]}!important}
.bgcolor_sec,.runing .seckill_field,.sec_item .percent-btn,.sec_item .percent-fill,.sp_bubble,.hm_process .weui-flex__item>i,.bg_sec.weui-btn, .bg_sec.weui-btn:active {background-color:{$hm_config[clr]}!important}
.sp_bubble:before {border-right-color:{$hm_config[clr]}}
li.coupon-blue .coupon-left .pro-content .pro-price,li.coupon-freeCarriage .coupon-left .pro-content .pro-price,li.coupon-red .coupon-left .pro-content .pro-price, li.coupon-red .coupon-btn,li.coupon-red .coupon-btn-go-look,li.coupon-red .coupon-btn-yellow,li.coupon-red .coupon-left .pro-content .pro-price,.ding_price_btn{color:{$hm_config[clr]}}
li.coupon-red .coupon-right,.seckill_field,.qr_tag,.qr_pr .qr_time{background-color:{$hm_config[clr]}}
li.coupon-freeCarriage .coupon-left .triangle-border-left i,li.coupon-red .coupon-left .triangle-border-left i{border-right:3px solid {$hm_config[clr]}}
li.coupon-red .coupon-left .triangle-border-left{border-right:3px solid {$hm_config[clr]}}.wide_border{border-color:{$hm_config[clr]}}
<!--{/if}--></style>
<script>var HB_INWECHAT = '{HB_INWECHAT}', PLZALLOW = '{lang xigua_hs:plzallow}', gengduodongtai = '{lang xigua_hs:gengduodongtai}', guanzhu_sj = '{lang xigua_hs:guanzhu_sj}', yiguanzhu = '{lang xigua_hs:yiguanzhu}', jiaguanzhu='{lang xigua_hs:jiaguanzhu}', mkey = '$hs_config[mkey]', GOOGLE = '{$hs_config[google]}', HS_MULTIUPLOAD = '{$config[multiupload]}', HM_JJS = '{lang xigua_hm:jjs}',fxqg = '{lang xigua_hm:fxqg}',qws = '{lang xigua_hm:qws}',
h_t = '{lang xigua_hm:t}', h_h = '{lang xigua_hm:h}', h_f = '{lang xigua_hm:f}',h_sec = '{lang xigua_hm:sec}',
HM_JKS = '{lang xigua_hm:jks}',HM_YJS = '{lang xigua_hm:yjs}',HM_JS = '{lang xigua_hm:jshu}', HM_YY='{lang xigua_hm:yy}', CQYX = '{lang xigua_hm:cqyx}', COMCLAS = '', HM_QZGZ ={echo intval($hm_config[qzgz]);} , HM_QRCODE = '$SCRITPTNAME?id=xigua_hb:qrauto&ode=hm_{$secid}{$urlext}', HM_QZG = '{$hm_config[guideword2]}', HM_GZQCHANGAN = '{$hm_config[guideword1]}';var HMGZCG='{lang xigua_hb:gzcg}';</script>
<!--{if $ac!='seckill_view' && $do!='good'}-->
<!--{if $hm_config['pindaopic']}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$hm_config['pindaopic']" /></div><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_f']['defaultlogo']}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$_G['cache']['plugin']['xigua_f']['defaultlogo']" /></div><!--{/if}-->
<!--{/if}-->