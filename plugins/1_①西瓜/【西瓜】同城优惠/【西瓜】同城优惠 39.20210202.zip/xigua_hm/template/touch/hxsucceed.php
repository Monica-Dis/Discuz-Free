<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<div class="page__bd">
    <style>.wbtn{background-color: #fff!important;color:#666;width:17.65%;float: left;padding: 0;margin-right: 2.5%;}.wicon{font-size: 50px}.p15{padding:15px }
    .showcode{text-align: center;color: #353535;margin-top: 80px}
    .showcode h2{font-size:18px}
    .showcode p{font-size:36px} </style>
    <div class="tc p15">
        <i class="icon-duigou iconfont wicon main_color"></i>
        <p class="main_color f18" style="margin:8px">{lang xigua_hm:sycg}</p>
    </div>


    <div class="showcode">
        <h2>{$secinfo[title]}</h2>
        <p>{$code}</p>
    </div>

    <div style="background:transparent!important;margin-top:150px;width:100%">
        <a class=" half weui-btn weui-btn_default main_color" href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=seckill&status=2&hx=1">{lang xigua_hm:wc}</a>
    </div>
</div>

<!--{eval $tabbar=0;$hs_tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->