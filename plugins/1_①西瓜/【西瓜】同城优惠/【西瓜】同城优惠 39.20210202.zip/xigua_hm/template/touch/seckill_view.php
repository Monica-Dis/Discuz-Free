<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}-->
<!--{if $v[fee_type]==1}-->
<!--{eval $v[postinfo] = '';$v[addrid]=0;}-->
<!--{/if}-->
<!--{eval $back_to = "$SCRITPTNAME?id=xigua_hm";}-->
<!--{if $_SERVER[HTTP_REFERER]}-->
<!--{eval $back_to = "javascript:window.history.go(-1);";}-->
<!--{/if}-->

<!--{eval
if($_G['cache']['plugin']['xigua_hh'] && $hm_config[allowhhr]):
$hu = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G['uid']);
if(!$hu['end'] && $hu['display']):
    $hhrname = $hu[joininfo][name];
    $hhrpercent = $hu[joininfo][percentage];
endif;
endif;
}-->
<!--{if $v[shen]}--><script>    alert('{lang xigua_hm:shz}');    window.history.go(-1);</script><!--{/if}-->
<div class="hm_view_nav">
    <a href="$back_to"><i class="iconfont icon-fanhui"></i></a>
    <a href="$SCRITPTNAME?id=xigua_hm"><i class="iconfont icon-index"></i></a>
    <!--{template xigua_hm:hbbutton}-->
</div>
<div id="page__bd" class="page__bd <!--{if $v[end]}-->hasend<!--{/if}-->">
    <!--{if !$v[album]}-->
    <!--{eval $v[album] = $v[append_img_ary];}-->
    <!--{/if}-->
    <!--{if $v[album]}-->
    <div class="swipe cl" data-speed="5000">
        <div class="swipe-wrap">
            <!--{loop $v[album] $_lk $_lv}-->
            <div><a href="javascript:;"><img src="{$_lv}" ></a></div>
            <!--{/loop}-->
        </div>
        <div class="hm_cont weui-flex">
            <div class="weui-flex__item"><p>$v[title]</p></div>
        </div>
    </div>
    <!--{/if}-->

    <div class="seckill_field weui-flex">
        <div class="f14 weui-flex__item">
            <a class="seckill_pricebtn"><!--{if $v[dingprice]>0}-->{lang xigua_hm:dingprice}<!--{else}-->{lang xigua_hm:xsth}<!--{/if}--></a>
            <span><!--{if $geting}-->{$geting}{lang xigua_hm:rfk}<!--{else}--><!--{if $v[stock] ==0}-->{lang xigua_hm:qgl}<!--{elseif $v[end]}-->{lang xigua_hm:yjs}<!--{else}-->{lang xigua_hm:qgz}<!--{/if}--><!--{/if}--></span>
        </div>
        <div class="timedown">
            <p class="sp_desc sp_tag hmt" data-start="{$v[start_u]}" data-end="{$v[end_u]}">{lang xigua_hm:jjs}<span class="timer"></span></p>
            <div class="seckill-percent" style="height:14px">
            <div class="percent-line" style="background:#fff">
                <div class="percent-fill" style="width:{echo 100-$v[percent]}%;background:#fee100"></div>
                <span class="percent-line-word"><!--{if $v[stock]<=0}-->{lang xigua_hm:qgl}<!--{elseif $v[end]}-->{lang xigua_hm:yjs}<!--{else}-->{lang xigua_hm:js}{echo $v[allnum]-$v[hasqiang]}{lang xigua_hm:fen},{lang xigua_hm:zong}$v[allnum]{lang xigua_hm:fen}<!--{/if}--></span>
            </div>
            <div class="percent-cover"></div>
            </div>
        </div>
    </div>

    <div class="weui-cells before_none mt0 after_none">
        <article class="seckill_price_tit weui-article">

            <p class="mb0 pr">
                <span class="seckill_price"><i class="f14">{lang xigua_hm:yen}</i><!--{if $v[dingprice]>0}-->$v[price]
                    <em class="sp_bubble vm">{lang xigua_hm:ddf}{echo $v[yuanprice]-$v[dingprice];}{lang xigua_hm:yuan}</em>
                    <!--{elseif $v[yuanprice]>0 && $v[hkprice]>0 }-->$v[yuanprice]<!--{else}-->$v[price]<!--{/if}--></span>
                <span class="c9 f14"><s>$v[marketprice]</s>{lang xigua_hm:yuan}   <!--{if $v[jifenprice]}-->
                    <em class="f12 main_color">$v[jifenprice]</em>
                    <!--{/if}--></span>
                <span class="c9 f14 hm_hots"><i class="iconfont icon-hot-02 color-sec"></i>{$v[views]}{lang xigua_hm:rgz}</span>
            </p>
            <!--{if $hm_config[showapppr] && $v[appprice]>0 && !(IN_MAGAPP || IN_QIANFAN || IN_APPBYME)}-->
            <p class="main_color f14 appth"><a class="seckill_pricebtn">{lang xigua_hm:appth}</a> <a class="appthtext" href="{$hm_config[guidelink]}">{$hm_config[guideapp]}</a><a href="{$hm_config[guidelink]}" class="appthbtn">{$v[appprice]}{lang xigua_hm:yuan}{lang xigua_hm:gm}</a></p>
            <!--{/if}-->
            <p class="mb0 f14">$v[tuijian]</p>
        </article>
        <!--{if $hm_config[allowhk] && $_G['cache']['plugin']['xigua_hk'] && $v[hkprice]>0}-->
        <!--{eval $card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G[uid]); }-->
        <div class="main_lok">
            <span class="spanbtn">
                <img src="source/plugin/xigua_hm/static/images/card.png" style="width: 16px;vertical-align: middle;position: relative;top:-2px;" />{eval echo str_replace(lang('plugin/xigua_hk', 'heika'), $_G['cache']['plugin']['xigua_hk']['cardname'], lang('plugin/xigua_hk', 'heikazhuanxiang'))}</span>
            <!--{if !$card}-->
            <span>{eval echo str_replace(lang('plugin/xigua_hk', 'heika'), $_G['cache']['plugin']['xigua_hk']['cardname'], lang('plugin/xigua_hk', 'kthkky'))} {$v[hkprice]}{lang xigua_hk:ygm}</span>
            <span class="spanbtn2"><a href="$SCRITPTNAME?id=xigua_hk&ac=join{$urlext}">{lang xigua_hk:ljkt}</a></span>
            <!--{else}-->
            <span>{eval echo str_replace(lang('plugin/xigua_hk', 'heika'), $_G['cache']['plugin']['xigua_hk']['cardname'], lang('plugin/xigua_hk', 'yjshk'))} {$v[hkprice]}{lang xigua_hk:ygm}</span>
            <span class="spanbtn2"><a href="$SCRITPTNAME?id=xigua_hk{$urlext}">{lang xigua_hk:gdyh}</a></span>
            <!--{/if}-->
        </div>
        <!--{eval $before = 'before_none';}-->
        <!--{/if}-->

        <!--{if !$v[yuyue]}-->
<!--{eval array_unshift($v[srange_ary],lang_hm('myy',0)); }-->
<!--{/if}-->
<!--{if $v[srange_ary]}-->
        <div class="weui-cell $before">
            <div class="weui-cell__bd">
                <ul class="arguments-treatment main_color">
                    <!--{loop $v[srange_ary] $_v}--><li style="float:left;"><i class="iconfont icon-duigou2"></i>{$_v}</li><!--{/loop}-->
                </ul>
            </div>
        </div>
<!--{/if}-->
        <!--{if $v[end_u]}-->
        <div class="weui-cell">
            <div class="weui-cell__bd f14">
                <p>{lang xigua_hm:spyxq}</p>
            </div>
            <div class="weui-cell__ft f14">
                <!--{if $v[end_u]}-->
                <em><!--{$v[start_u]}--></em><i>{lang xigua_hm:zhi}</i><em><!--{$v[end_u]}--></em>
                <!--{else}-->
                <em>{lang xigua_hm:cqyx}</em>
                <!--{/if}-->
            </div>
        </div>
        <!--{/if}-->
<!--{if $hm_config[showreal]&&$v[logs]}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hm&ac=buylog&secid=$secid">
            <div class="weui-cell__bd f14">
                <ul class="seckill_logs">
                    <!--{loop $v[logs] $_u}-->
                    <li><img src="{avatar($_u[uid], 'middle', true)}" /></li>
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="weui-cell__ft f14">
                {lang xigua_hm:yyou}{$v[logs_count]}{lang xigua_hm:rgm}
            </div>
        </a>
<!--{/if}-->
    </div>
<!--{if $v[fansqr]}-->
<!--{eval $hm_config['fansqr']=$v[fansqr];}-->
<!--{/if}-->
    <!--{if $hm_config['fansqr']}-->
    <div class="weui-cells before_none after_none">
        <div class="weui-cell h45">
            <div class="weui-cell__hd">
                <img class="h45" src="{$hm_config[fansicon]}" />
            </div>
            <div class="weui-cell__bd">
                <p class="f14 c3">{$hm_config[fanstitle]}</p>
                <p class="f12 c9">{$hm_config[fansdesc]}</p>
            </div>
            <div class="weui-cell__ft">
                <a href="javascript:;" class="weui-btn f14 main_bg indexguid" onclick='$.alert("<img class=\"w180\" src={$hm_config[fansqr]} />", "{$hm_config[fansqrtitle]}");'>{lang xigua_hm:wyjq}</a>
            </div>
        </div>
    </div>
    <!--{/if}-->

    <!--{if $sh}-->
    <div class="weui-cells f15 before_none after_none">
        <div class="weui-cell none">
            <div class="weui-cell__bd">
                <p>{lang xigua_hm:sydp}</p>
            </div>
        </div>
        <div class="weui-cell before_none">
            <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]"><img src="$sh[logo]" /></a></div>
            <div class="weui-cell__bd">
                <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]">{$sh[name]}</a></p>
                <p class="f14 c9">{lang xigua_hm:yysj}: <em>$sh[opentime]</em></p>
            </div>
            <div class="weui-cell__ft">
                <a href="javascript:;" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_hm:smj}", "{lang xigua_hm:wxzca}");'><i class="iconfont icon-sixin2 mr15 main_color f24"></i></a>
                <a href="tel:$sh[tel]"><i class="iconfont icon-unie607 main_color f24"></i></a>
            </div>
        </div>

        <a class="weui-cell weui-cell_access" href="javascript:;" id="v_openLocation" data-lat="$sh[lat]" data-lng="$sh[lng]" data-name="$sh[name]" data-addr="$sh[addr]">
            <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
            <div class="weui-cell__bd">
                <p class="f14">$sh[addr]</p>
                <p class="f14 c9" id="driving" data-id="$v[shid]">{lang xigua_hs:jisuan}</p>
            </div>
            <div class="weui-cell__ft">
            </div>
        </a>
    </div>
    <!--{/if}-->

    <!--{if $v[fee_type]==2}-->
    <div class="weui-cells f15 before_none after_none">
        <div class="hm_process weui-flex">
            <em class="process-line"></em>
            <div class="weui-flex__item">
                <i class="iconfont icon-qianggou"></i>
                <p>{lang xigua_hm:cyqg}</p>
            </div>
            <div class="weui-flex__item">
                <i class="iconfont icon-duigou1"></i>
                <p>{lang xigua_hm:fkcg}</p>
            </div>
            <div class="weui-flex__item">
                <i class="iconfont icon-yanzheng"></i>
                <!--{if $v[fee_type]==2}-->
                <p>{lang xigua_hm:sjfh}</p>
                <!--{else}-->
                <p>{lang xigua_hm:ddyzxf}</p>
                <!--{/if}-->
            </div>
        </div>
    </div>
    <!--{/if}-->

    <div class="weui-cells f15 before_none after_none">

        <div class="weui-cell">
            <div class="weui-cell__bd c3">
                <p>{lang xigua_hm:gmxz}</p>
            </div>
        </div>

        <!--{if $v[fee_type]==1 && $v[usetime_u] || $v[usetime_start]>0}-->
        <div class="weui-cell">
            <div class="weui-cell__hd mr15 main_color">{lang xigua_hm:syxuz}</div>
            <div class="weui-cell__bd">
                <!--{if $v[usetime_u]&&$v[usetime_start]}-->
                <p>{lang xigua_hm:gm1}{echo intval($v[usetime_start]/60)}{lang xigua_hm:fzzh}</p>
                <p>{lang xigua_hm:syjzsj} : <span class="main_color">$v[usetime_u]</span></p>
                <!--{elseif $v[usetime_u]}-->
                <p>{lang xigua_hm:syjzsj} : <span class="main_color">$v[usetime_u]</span></p>
                <!--{elseif $v[usetime_start]}-->
                <p>{lang xigua_hm:gm1}{echo intval($v[usetime_start]/60)}{lang xigua_hm:fzzh}</p>
                <!--{/if}-->
            </div>
        </div>
        <!--{/if}-->

        <div class="weui-cell">
            <div class="weui-cell__hd mr15 main_color">{lang xigua_hm:spxg}</div>
            <div class="weui-cell__bd">
                <p><!--{if $v[old_maxnum]}-->{lang xigua_hm:mrxg}{$v[old_maxnum]}{lang xigua_hm:fen}<!--{else}-->{lang xigua_hm:bxfs}<!--{/if}--></p>
            </div>
        </div>
        <!--{if $v[fee_type]==2}-->
        <div class="weui-cell">
            <div class="weui-cell__hd mr15 main_color">{lang xigua_hm:psfy}</div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hm:fee}{$v[fee]}{lang xigua_hm:yuan}</p>
            </div>
        </div>
        <!--{/if}-->
        <!--{eval $biaoqian = array_filter(explode(" ", trim($v[biaoqian])));}-->
        <!--{if $biaoqian}-->
        <div class="weui-cell">
            <div class="weui-cell__hd mr15 main_color">{lang xigua_hm:spts}</div>
            <div class="weui-cell__bd">
                <!--{loop $biaoqian $_b}-->
                <ul>
                    <li><span>{$_b}</span></li>
                </ul>
                <!--{/loop}-->
            </div>
        </div>
        <!--{/if}-->

    </div>

    <div class="weui-cells f15  before_none after_none">
        <div class="weui-cell">
            <div class="weui-cell__bd c3">
                <p>{lang xigua_hm:jieshao}</p>
            </div>
        </div>
        <!--{eval
        if(strpos($v['jieshao'], '&lt;') !== false  && strpos($v['jieshao'], '&gt;') !== false) :
            $v['jieshao'] = htmlspecialchars_decode($v['jieshao']);
            $v['jieshao'] = preg_replace(array("/<script(.*?)<\/script>/is",'/on(mousewheel|mouseover|click|load|onload|submit|focus|blur)="[^"]*"/i'), array('',''), $v['jieshao']);
        endif;
        }-->
        <article class="weui-cell weui-article f14">
            <section>
                <p>{echo hs_nl2br($v['jieshao']);}</p>
                <!--{loop $v[append_img_ary] $__k $__v}-->
                <p><img src="{$__v}" /></p>
                <p>{echo hs_nl2br($v[append_text_ary][$__k]);}</p>
                <!--{/loop}-->
            </section>
        </article>
    </div>

<!--{if $_G['cache']['plugin']['xigua_dp'] && in_array('hm', unserialize($_G['cache']['plugin']['xigua_dp']['opens']))}-->
<style>.gzbtn{background-color:$config[maincolor]}</style><div id="ptdiv2" style="display:none"></div>
<script>
    $.ajax({type: 'get',dataType: 'xml',
        url: '$SCRITPTNAME?id=xigua_dp&ac=jingxuan&inajax=1&type=hm&typeid=$secid&shid={$sh[shid]}&pagesize=5&page=1',
        success: function (data) {
            if(null==data){ $('#ptdiv2').remove(); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(!s){ $('#ptdiv2').remove(); return false;}
            $('head').append('<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?{VERHASH}" />');
            $('body').append('<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"><\/script>');
            $('#ptdiv2').html(s).show();
        },
        error: function () {$('#ptdiv2').remove();}
    });
</script>
<!--{/if}-->

    <div class="page__ft mt10">
        <p class="">{lang xigua_hm:jsq}</p>
    </div>

    <div class="view_bottom weui-flex border_top">
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid={$sh[shid]}" class="weui-tabbar__item weui-bar__item_on">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-shoplight weui-tabbar__icon"></i>
                </span>
                <p class="weui-tabbar__label">{lang xigua_hm:dp}</p>
            </a>
        </div>
    <div class="view_bottom_z">
<!--{eval include DISCUZ_ROOT.'source/plugin/xigua_hm/include/c_seckillview.php';}-->
        <a href="$kflnk" class="weui-tabbar__item">
            <span style="display:inline-block;position:relative">
                <i class="iconfont icon-kefu1 weui-tabbar__icon f22"></i>
            </span>
            <p class="weui-tabbar__label">{lang xigua_hm:zxkf}</p>
        </a>
    </div>
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=seckill" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-wode weui-tabbar__icon f28"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_hm:dd}</p>
            </a>
        </div>
        <div class="weui-flex__item view_bottom_y">
            <!--{if $v[end] || $v[allnum]-$v[hasqiang]<=0 || $v[stock]<=0}-->
            <a href="javascript:;" class="bgcolor_sec mc_bg">{lang xigua_hm:yjs}</a>
            <!--{else}-->
<!--{if $v[fszx]&&!$followed}-->
    <a href="javascript:;" class="bgcolor_sec mc_bg do_follow2" data-wei="1" data-id="$v[shid]">{lang xigua_hm:djgzqg}</a>
<!--{else}-->
    <!--{if !$get}-->
    <a href="<!--{if $user&&isset($checkmobile[2]) && !$user[mobile]}-->$SCRITPTNAME?id=xigua_hb&ac=myzl&referer={echo urlencode(hb_currenturl());}{$urlext}<!--{else}-->javascript:;<!--{/if}-->" class="bgcolor_sec mc_bg <!--{if $user&&isset($checkmobile[2]) && !$user[mobile]}--><!--{else}-->doseckill<!--{/if}-->" data-id="$secid" <!--{if $v[old_maxnum]>1||$v[fee_type]==2 || $v[old_maxnum]==0||$v[ggary]}-->data-needpopup="1"<!--{/if}-->>{lang xigua_hm:ljqg}</a>
    <!--{else}-->
    <a href="{$jumpurl}" class="bgcolor_sec mc_bg">{lang xigua_hm:qfk}</a>
    <!--{/if}-->
<!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{template xigua_hm:qrcode}-->

<!--{if $hm_config[showreal]&&$v[logs]}-->
<!--{template xigua_hm:slider}-->
<!--{/if}-->
<!--{eval $tabbar=0;$hs_tabbar=1;}-->
<!--{template xigua_hm:pay_item}-->
<!--{template xigua_hb:common_footer}-->
<!--{if $v[fee_type]==2 && !$dft}-->
<script>  var needaddr = 1;</script>
<!--{/if}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>
<script>
    <!--{if $_GET[paynew]}-->
    panew_popup();
    <!--{/if}-->
    hm_GetRunTime('{$v[start_u]}', '{$v[end_u]}', $('.hmt'), 10);
    $(function () {
        var isPageHide = false;
        window.addEventListener('pageshow', function () {
            if (isPageHide) {
                window.location.reload();
            }
        });
        window.addEventListener('pagehide', function () {
            isPageHide = true;
        });
    });
<!--{if $hm_config[haitype]==2}-->
    $(document).on('click','.sec_newewm', function () {
        $.showLoading();
        html2canvas(document.querySelector(".shot_in")).then(canvas => {
            var dataURL = canvas.toDataURL();
            COMCLAS = 'shot_outer';
        $.hideLoading();
            $.alert("<img src='"+dataURL+"' /> <!--{if $bword}-->{$bword}<!--{elseif $hhrname}--><div style='margin-bottom:10px'><p class='f12'>{lang xigua_hm:hhrdj} : <em class=main_color>$hhrname</em></p><p class='f12'>{lang xigua_hm:bl} : <em class=main_color>{$hhrpercent}</em></p></div><!--{/if}-->",fxqg);
            $('.weui-dialog__title').css('font-size', '14px');
            COMCLAS = '';
        });
        return false;
    });
<!--{/if}-->
setTimeout(function () {$('.hbzd').addClass('r-21');}, 800);
</script>
<!--{template xigua_hm:mgshare}-->
<script>var loadingurl = window.location.href+'&ac=seckill_li&inajax=1&qgys=3&manage=1&page=';</script>