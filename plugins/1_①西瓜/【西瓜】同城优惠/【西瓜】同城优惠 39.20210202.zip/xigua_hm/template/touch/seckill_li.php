<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<!--{if !$v[quan]}-->
<!--{if 1||$do!='good'}-->
<!--{if $_GET[is_my]}-->
<!--{eval $hm_config[qgys] = 0;}-->
<!--{/if}-->
<!--{if $_GET[qgys]}-->
<!--{eval $hm_config[qgys]=$_GET[qgys];}-->
<!--{/if}-->
<div class="sp_item sec_item <!--{if $hm_config[qgys]==2}-->twowel<!--{elseif $hm_config[qgys]==3}-->twowel twowel1<!--{/if}--> <!--{if $v[not_start]}-->comingsoon<!--{elseif $v[end]||$v[stock]==0}-->hasend<!--{/if}-->" id="li_{$v['id']}" data-id="{$v['id']}" >
    <div class="sp_thumb m_jump" data-id="{$v['id']}"><img onerror="this.error=null;this.src='{$hs_config[dftshlogo]}'" src="{echo $v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0]}">
        <!--{if $v[fszx]}--><em class="mian_">{lang xigua_hm:fensizhuanxiang}</em><!--{else}--><!--{if !$v[yuyue]}--><em class="mian_">{lang xigua_hm:myy}</em><!--{/if}--><!--{/if}--></div>
    <div class="sp_main m_jump" data-id="{$v['id']}">
        <div class="sp_content">
            <div class="weui-flex">
                <h3 class="weui-flex__item">
                    {$v[title]}<!--{if $_GET[is_my]&&$v[xiajia]}--><span class="c9 f14"> {lang xigua_hm:yxj}</span><!--{/if}-->
                    <span class="c9 f12 hm_hots_li"><i class="iconfont icon-hot-02 color-sec"></i>{echo hb_trans($v[views])}{lang xigua_hm:gz}</span>
                </h3>
            </div>
            <p class="sp_desc c9 tuijian">{$v[tuijian]}</p>
            <p class="sp_desc mt5">
                <span><em class="color-sec f18">{$v[price]}</em><em class="color-sec f12">{lang xigua_hm:yuan}</em>
                <!--{if $v[dingprice]>0}-->
                    <em class="sp_bubble">{lang xigua_hm:dingprice}</em>
                <!--{elseif $v[hkprice]>0}-->
                    <em class="sp_bubble">{eval echo str_replace(lang('plugin/xigua_hk', 'heika'), $_G['cache']['plugin']['xigua_hk']['cardname'], lang('plugin/xigua_hk', 'heika'))}{echo str_replace('.00','',$v[hkprice])}</em>
                <!--{/if}-->
                </span>
                <span><s class="f12 c9 ">{$v[marketprice]}{lang xigua_hm:yuan}</s></span>
            </p>
            <div class="pr pr_">
                <div class="seckill-percent">
                    <div class="percent-line">
                        <div class="percent-fill" style="<!--{if $v[percent]>0}-->min-width:13px;<!--{/if}-->width:{$v[percent]}%"></div>
                        <span class="percent-line-word">{lang xigua_hm:yq}{$v[hasqiang]}{lang xigua_hm:fen}</span>
                        <span class="percent-line-word" style="right:5px">{$v[percent]}%</span>
                    </div>
                    <div class="percent-cover"></div>
                </div>
            <!--{if !$v[shen]}-->
                <!--{if $v[stock]==0}-->
                <a class="weui-btn percent-btn">{lang xigua_hm:yqw}</a>
                <!--{else}-->
                <a class="weui-btn percent-btn"><!--{if $v[not_start]}-->{lang xigua_hm:wks}<!--{elseif $v[end]}-->{lang xigua_hm:yjs}<!--{else}-->{lang xigua_hm:ljqg}<!--{/if}--></a>
                <!--{/if}-->
            <!--{else}-->
                <a class="weui-btn percent-btn">{lang xigua_hm:shz}</a>
            <!--{/if}-->
            </div>

<!--{if $_GET[is_my]}-->
<p class="sp_desc sp_tag c9 h20">{$v[start_u]} - {echo $v[end_u] ? $v[end_u] : lang_hm('cqyx', 0)}</p>
<p>{lang xigua_hm:hxnum}: {$v[hxnum]}</p>
<!--{else}-->
            <!--{if $v[not_start]}-->
            <p class="sp_desc sp_tag c9 h20"><span class="timer">{$v[start_u]}{lang xigua_hm:zskq}</span></p>
            <!--{else}-->
            <p class="sp_desc sp_tag hmt c9 h20" data-start="{$v[start_u]}" data-end="{$v[end_u]}">{lang xigua_hm:jjs}<span class="timer"></span></p>
            <!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
</div>
    <!--{else}-->
    <!--{/if}-->
<!--{else}-->

<!--{if $hm_config[quanstyle]==1}-->
<ul class="coupon-list sec_item" id="li_{$v['id']}" data-id="{$v['id']}" >
    <li class="<!--{if $v[end]||$v[stock]==0}-->coupon-blue<!--{else}-->coupon-red<!--{/if}-->"><a class="coupon-a">
            <div class="coupon-left">
                <div class="triangle-border-left">
                    <i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>
                </div>
                <div class="img-div-backg">
                    <div class="img-div"><img src="{echo $v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0]}" ><!--{if $v[fszx]}--><em class="mian_">{lang xigua_hm:fensizhuanxiang}</em><!--{else}--><!--{if !$v[yuyue]}--><em class="mian_">{lang xigua_hm:myy}</em><!--{/if}--><!--{/if}--></div>
                </div>
                <div class="pro-content">
                    <span class="pro-info"><em class="pr s_quan_tag b-color" style="bottom:0;">{$stypes[$v[stype]]}</em> {$v[title]} <!--{if $_GET[is_my]&&$v[xiajia]}--> <em class="c9 f14">{lang xigua_hm:yxj}</em><!--{/if}--> </span>

                    <div class="pro-info pr">
                        <span class="c9">{$v[tuijian]} {$v[fanwei]}</span>
                    </div>

                    <div class="pro-price"><span class="big-price"><!--{if $v[stype]=='zhekou'}-->{$v[show_zhekourate]}{lang xigua_hm:zhe}<!--{else}-->{$v[marketprice]}{lang xigua_hm:yuan}<!--{/if}--></span>
                        <span class="price-info"><!--{if $v[underline]}-->{lang xigua_hm:m}{$v[underline]}{lang xigua_hm:ky}<!--{else}-->{lang xigua_hm:wzd}<!--{/if}--></span>
                    </div>
                </div>
            </div>
            <div class="coupon-right">
                <div class="triangle-border-right"><em class="circular0"></em><em class="circular1"></em><em class="circular2"></em><em class="circular3"></em>
                    <i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i><i></i>
                </div>
                <div class="change-block<!--{if $hads[$v[id]]}--> had<!--{/if}-->">
                    <div class="progress-bar-block">
                        <div class="progress-bar"><span style="width:{$v[percent]}%"></span></div>
                    </div>
                    <span class="progress-text"><!--{if $v[percent]==100}-->{lang xigua_hm:qbqw}<!--{else}-->{lang xigua_hm:yq} {$v[percent]}%<!--{/if}--></span><span class="coupon-btn"><!--{if !$v[shen]}--><!--{if $v[stock]<=0}-->{lang xigua_hm:ylw}<!--{else}--><!--{if $v[end]}-->{lang xigua_hm:yjs}<!--{else}-->

                        <!--{if $v[price]>0}-->
                        $v[price]{lang xigua_hm:yuan}{lang xigua_hm:lq}
                        <!--{else}-->
                        {lang xigua_hm:ljlq}
                        <!--{/if}-->

                        <!--{/if}--><!--{/if}--> <!--{else}-->{lang xigua_hm:shz}<!--{/if}--></span></div>
            </div>
        </a>
    </li>
</ul>
<!--{else}-->
<div class="sp_item sec_item <!--{if $v[not_start]}-->comingsoon<!--{elseif $v[end]||$v[stock]==0}-->hasend<!--{/if}-->" id="li_{$v['id']}" data-id="{$v['id']}" >
    <div class="sp_thumb m_jump s_quan_img" data-id="{$v['id']}"><img onerror="this.error=null;this.src='{$hs_config[dftshlogo]}'" src="{echo $v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0]}">
        <!--{if $v[fszx]}--><em class="mian_">{lang xigua_hm:fensizhuanxiang}</em><!--{else}--><!--{if !$v[yuyue]}--><em class="mian_">{lang xigua_hm:myy}</em><!--{/if}--><!--{/if}--></div>
    <div class="sp_main m_jump s_quan" data-id="{$v['id']}" style="margin-left: 80px;margin-top: 5px;">
        <div class="sp_content">
            <div class="weui-flex">
                <h3 class="weui-flex__item s_quan_h">{$v[title]}<!--{if $_GET[is_my]&&$v[xiajia]}--> <span class="c9 f14">{lang xigua_hm:yxj}</span><!--{/if}--></h3>
            </div>
            <p class="sp_desc s_quan_h">
                <span class="color-sec ">
                    <!--{if $v[stype]=='zhekou'}-->
                    <em class="f18">{$v[show_zhekourate]}</em>{lang xigua_hm:zhe}
                    <!--{else}-->
                    <em class="f18">{$v[marketprice]}</em>{lang xigua_hm:yuan}{$stypes[$v[stype]]}
                    <!--{/if}-->
                </span>
                <!--{if $v[underline]}-->
                <span class="f12 c9 "><!--{if $v[underline]}-->{lang xigua_hm:m}{$v[underline]}{lang xigua_hm:ky}<!--{else}-->{lang xigua_hm:wzd}<!--{/if}--></span>
                <!--{/if}-->

                <span class="s_quan_num"><!--{if $v[hasqiang]}-->{$v[hasqiang]}{lang xigua_hm:fyl}<!--{else}-->{lang xigua_hm:yhsx}<!--{/if}--></span>
            </p>
            <a class="weui-btn percent-btn" style="top:8px"><!--{if !$v[shen]}--><!--{if $v[stock]<=0}-->{lang xigua_hm:ylw}<!--{else}--><!--{if $v[end]}-->{lang xigua_hm:yjs}<!--{else}-->
                <!--{if $v[price]>0}-->
                $v[price]{lang xigua_hm:yuan}{lang xigua_hm:ling}
                <!--{else}-->
                {lang xigua_hm:ljl}
                <!--{/if}-->
                <!--{/if}--><!--{/if}--> <!--{else}-->{lang xigua_hm:shz}<!--{/if}--></a>

            <p class="sp_desc sp_tag c9 s_quan_h s_quan_line" style="padding-left:50px">{$v[tuijian]} {$v[fanwei]}</p>

            <span class="s_quan_tag b-color">{$stypes[$v[stype]]}</span>
        </div>
    </div>
</div>
<!--{/if}-->

<!--{/if}-->

<!--{if $_GET[is_my]}-->
<div class="button-sp-area" <!--{if $v[quan]}-->style="background:transparent;margin-top:10px"<!--{/if}-->>
    <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn main_color stock-edit" data-id="{$v[id]}" data-tit="{$v[title]}" data-stock="{$v[stock]}">{lang xigua_hm:kc1}</a>
    <a href="$SCRITPTNAME?id=xigua_hm&ac=seckilledit&secid=$v[id]" class="weui-btn weui-btn_mini hm_c_btn color-gray">{lang xigua_hm:xg}</a>
    <!--{if $v[xiajia]}-->
    <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn color-gray stock-shangjia" data-id="{$v[id]}">{lang xigua_hm:s}</a>
    <!--{elseif !$v[end] && !$v[shen]}-->
    <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn color-gray stock-del" data-id="{$v[id]}">{lang xigua_hm:x}</a>
    <!--{/if}-->
</div>
<!--{/if}-->
<!--{/loop}-->