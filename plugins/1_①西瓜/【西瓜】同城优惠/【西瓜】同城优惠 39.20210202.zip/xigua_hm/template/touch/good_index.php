<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hm:header}--><!--{if in_array($_GET['stype'],$kaquan_stype)}--><!--{eval $pub0 = "$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=quan&auto=1$urlext";}--><!--{else}--><!--{eval $pub0 = "$SCRITPTNAME?id=xigua_hm&ac=my_seckill&auto=1$urlext";}--><!--{/if}-->
<style>.ajaxhmcat.weui_bar__item_on span:after{display:none!important}.position1 li.current{background:{$config[maincolor]}!important}</style>
<!--{if $hm_config['good_pic']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$hm_config['good_pic']" /></div><!--{/if}-->
<link href="source/plugin/xigua_hm/static/coupon.css?{VERHASH}" rel="stylesheet">
<div class="page__bd">

    <div class="hm_index_header">

        <!--{if $topnavslider}-->
        <div class="swipe cl">
            <div class="swipe-wrap">
                <!--{loop $topnavslider $_lv}-->
                <div><a href="{$_lv[href]}"><img src="{$_lv[src]}" class="main-img"></a></div>
                <!--{/loop}-->
            </div>
            <nav class="cl bullets bullets1">
                <ul class="position">
                    <!--{loop $topnavslider $k $slider}-->
                    <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                    <!--{/loop}-->
                </ul>
            </nav>
        </div>
        <!--{/if}-->

        <div class="weui-cells mt0 before_none">
            <div class="chip-row">
                <div class="toutiao"><i class="color-sec iconfont icon-hot-02"></i></div>
                <div class="toutiao-slider swiper-container swiper-container-vertical ml3" id="newsSlider" style="margin-right:0">
                    <ul class="swiper-wrapper">
                        <!--{loop $toutiao $v}-->
                        <li class="swiper-slide"> <a href="$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid={$v[secid]}"><em class="main_color">{$v[user][username]}</em> {$v[crts_u]} <!--{if $secs[$v[secid]][stype]=='seckill'}-->{lang xigua_hm:gml}<!--{else}-->{lang xigua_hm:lql}<!--{/if}--> {$secs[$v[secid]][title]}</a> </li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="toutiao"><a class="f15" href="$SCRITPTNAME?id=xigua_hm&ac=my_order">{lang xigua_hm:wddd}</a></div>
            </div>
        </div>

        <!--{if $cat_list}-->
        <!--{eval $jing_list = array_values($cat_list);$jing_count = range(0, ceil(count($cat_list)/5)-1);}-->
        <nav class=" nav-list cl swipe">
            <div class="swipe-wrap">
                <div>
                    <ul class="cl">
                        <!--{loop $jing_list $k $n}-->
                        <!--{if $k && $k%5==0}-->
                    </ul>
                </div>
                <div>
                    <ul class="cl">
                        <!--{/if}-->
                        <li>
                            <a href="<!--{if $n[id]==-1}-->$SCRITPTNAME?id=xigua_hm<!--{else}-->$SCRITPTNAME?id=xigua_hm&ac=index&do=good&hyid=$n[id]<!--{/if}-->" class="ajaxhmcat" data-id="$n[id]">
                            <span>
                                <img src="$n['icon']"/>
                            </span>
                                <em class="m-piclist-title <!--{if $_GET[hyid]==$n[id]}-->main_color<!--{/if}-->">{$n['name']}</em>
                            </a>
                        </li>
                        <!--{/loop}-->
                    </ul>
                </div>
            </div>
            <nav class="cl bullets bullets1">
                <ul class="position position1">
                    <!--{loop $jing_count $k $v}-->
                    <li {if $k==0} class="current" {/if}></li>
                    <!--{/loop}-->
                </ul>
            </nav>
        </nav>
        <!--{/if}-->
    </div>

<!--{if $sec_group}-->
    <div>
        <!--{loop $sec_group $_sk $_sv}-->
        <!--{if $_sv}-->
        <div class="weui-cells f15 before_none after_none">
        <div class="weui-cells__title weui_title mt0 f15">{$cat_group[$_sk][name]} <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_hm&ac=index&do=good&hyid=$_sk">{lang xigua_hb:more}<i class="f13 iconfont icon-jinrujiantou"></i></a>
        </div>
        <div class="swiper-container coupon_swiper">
            <div class="swiper-wrapper">
                <!--{loop $_sv $k $qv}-->
                <div class="swiper-slide seclight_box seclight_good">
                    <a href="$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid={$qv[id]}">
                        <div class="pr">
                            <!--{if $qv[fszx]}--><em class="mian_">{lang xigua_hm:fensizhuanxiang}</em><!--{else}--><!--{if !$qv[yuyue]}--><em class="mian_">{lang xigua_hs:mian}</em><!--{/if}--><!--{/if}--><img class="seclight_img" src="{echo $qv[album][0]?$qv[album][0]:$qv[append_img_ary][0]}">
                        </div>
                        <div class="p3">{$qv[title]}</div>
                        <div class="p2">
                            <span class="color-sec"><em class="f18">{$qv[price]}</em><em class="f12">{lang xigua_hs:yuan}</em><!--{if $qv[dingprice]>0}--> <em class="sp_bubble">{lang xigua_hs:dj}</em><!--{/if}--></span>
                            <span><s class="f12 c9 ">{$qv[marketprice]}{lang xigua_hs:yuan}</s></span>
                        </div>
                    </a>
                </div>
                <!--{/loop}-->
            </div>
        </div></div>
        <!--{/if}-->
        <!--{/loop}-->
    </div>
<!--{else}-->
    <div class="mt10">
        <div id="list" class="mod-post x-postlist p0">

        </div>
        <!--{template xigua_hb:loading}-->
    </div>
<!--{/if}-->

</div>
<script>
    scrollto = 1;
    <!--{if !$sec_group}-->
    var loadingurl = window.location.href+'&ac=seckill_li&do=good&inajax=1&page=';
    <!--{/if}-->
    var loadingCallback = function () {
        $('.hmt').each(function () {
            var that = $(this);
            hm_GetRunTime(that.data('start'),that.data('end'), that);
        });
    }
</script>

<!--{eval $config[setbuttom] = $config[setbuttom] ?$config[setbuttom] : lang_hm('yh',0)."|shijian|$SCRITPTNAME?id=xigua_hm|index";}-->
<!--{eval $tabbar=1;$hs_tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>