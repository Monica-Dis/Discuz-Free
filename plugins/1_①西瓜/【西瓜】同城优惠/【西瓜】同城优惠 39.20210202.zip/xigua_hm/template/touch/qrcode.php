<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<script src="source/plugin/xigua_hm/static/html2canvas.min.js"></script>
<!--{eval $shot_img = $v[album][0]?$v[album][0]:$v[append_img_ary][0];}-->
<!--{eval
$shot_file = 'source/plugin/xigua_hm/cache/'.md5($shot_img).'.png';
if(strpos($shot_img, $_G[siteurl])===false):
    if(!is_file(DISCUZ_ROOT.$shot_file)):
        file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($shot_img));
    endif;
    $shot_img = $shot_file;
endif;
}-->
<style>.shot_outer .weui-dialog__bd{padding:10px}</style>
<div id="shot" style="position:absolute;top:-100000px">
    <div class="shot_in" style="border-radius:10px;overflow: hidden;">
    <div class="qr_pr main_bg" style="padding: 10px 10px 0">
        <img style=" border-radius: 5px;
    border-bottom-right-radius: 0;
    border-bottom-left-radius: 0;" src="{$shot_img}" crossOrigin="anonymous" class="qr_img_src"/>
        <div style="left:10px" class="qr_time"><!--{if $v[end_u]}-->{lang xigua_hm:jzrq}:<em><!--{$v[end_u]}--></em><!--{else}--><em>{lang xigua_hm:cqyx}</em><!--{/if}--></div>
    </div>
    <div class="qr_outer cl main_bg" style="padding:10px;
    padding-top: 0;">
        <div class="info_field cl tl" style="
    background: #fff;
    position: relative;
    overflow: hidden;
    padding: 10px 5px;
    border-radius: 5px;margin-right:0;
    border-top-right-radius: 0;
    border-top-left-radius: 0;">
        <div class="cl y qrfield">
            <div class="wide_border"></div>
<!--{if $config[qraut]}-->
    <img src="$SCRITPTNAME?id=xigua_hb:qrauto&ode=hm_{$secid}{$urlext}" />
<!--{else}-->
    <img src="$SCRITPTNAME?id=xigua_hm:qrcode&secid=$secid&qrcode=1" />
<!--{/if}-->
            <div class="qrfield_c qrfield_c1">{lang xigua_hm:casbewm}</div>
            <div class="qrfield_c qrfield_c2"></div>
            <div class="qrfield_c qrfield_c3"></div>
            <div class="qrfield_c qrfield_c4"></div>
        </div>
        <!--{if $v['stype']=='seckill'}-->
            <p class="ca2 f14"><em class="qr_tag"><!--{if $v[end_u]}-->{lang xigua_hm:xsms}<!--{else}-->{lang xigua_hm:ms}<!--{/if}--></em> {echo $_G[uid]?$_G[username].lang_hm('xntj', 0):''}$v[title]</p>
            <!--{if $v[dingprice]>0}-->
            <p class="c9 f14">
                <em>{lang xigua_hm:yuanjia}<s>$v[marketprice]{lang xigua_hm:yuan}</s></em>
                <em class="c9 f14 ml3">{lang xigua_hm:hdj}</em><em class="seckill_price">{$v[yuanprice]}{lang xigua_hm:yuan}</em>
            </p>
            <p class="c9 f14">
                <span class="qr_tag">{lang xigua_hm:dingprice}<em class="ding_price_btn">$v[dingprice]</em></span>
                <span>{lang xigua_hm:ddf}{echo $v[yuanprice]-$v[dingprice];}{lang xigua_hm:yuan}</span>
            </p>
            <!--{else}-->
            <p class="c9 f14">{lang xigua_hm:yuanjia} <s>$v[marketprice]</s>{lang xigua_hm:yuan}</p>
            <p class="seckill_price">
                <em class="c9 f14">{lang xigua_hm:hdj}</em> <i class="f14">{lang xigua_hm:yen}</i>{$v[price]}
            </p>

            <p class="c9 f14">
                <!--{if $v[price]>0}-->
                <span class="qr_tag">{lang xigua_hm:zf}<em class="ding_price_btn">{$v[price]}{lang xigua_hm:yuan}</em></span>
                <span>{lang xigua_hm:gm}</span>
                <!--{else}-->
                <span class="qr_tag">{lang xigua_hm:mflq}</span>
                <!--{/if}-->
            </p>

            <!--{/if}-->
        <!--{else}-->
            <p class="ca2 f14"><em class="qr_tag">{$stypes[$v[stype]]}</em> $v[title]</p>
            <p class="c9 f14">
                <!--{if $v[stype]=='zhekou'}-->
                <em class="seckill_price">{$v[show_zhekourate]}{lang xigua_hm:zhe}</em>
                <!--{else}-->
                <em class="c9 f14 color-sec">{lang xigua_hm:yen}</em><em class="seckill_price">{$v[marketprice]}</em>
                <!--{/if}-->
                <em><!--{if $v[underline]}-->{lang xigua_hm:m}{$v[underline]}{lang xigua_hm:ky}<!--{else}-->{lang xigua_hm:wzd}<!--{/if}--></em>
            </p>
            <p class="c9 f14">
                <!--{if $v[price]>0}-->
                <span class="qr_tag">{lang xigua_hm:zf}<em class="ding_price_btn">{$v[price]}{lang xigua_hm:yuan}</em></span>
                <span>{lang xigua_hm:lq}</span>
                <!--{else}-->
                <span class="qr_tag">{lang xigua_hm:mflq}</span>
                <!--{/if}-->
            </p>
        <!--{/if}-->
        </div>
    </div>
    </div>
</div>


<!--{if $hm_config[qzgz] && !getcookie('miniprogram') && ($config['secert']||$config['magapp_secret'])&& HB_INWECHAT}-->
<!--{eval
$wxpay = $config['appid'] && $config['appsecert'] && $config['key'];
if(HB_INWECHAT && $wxpay):
$openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
    if(!$openid):
      $tools = new JsApiPaySF();
      $opendata = $tools->GetFollowOpenid(hb_currenturl().'&oauth=yes');
      if($openid = $opendata['openid']):
        dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 86400);
      endif;
    endif;
endif;
}-->
<!--{if $openid}-->
<script>var OPENID='$openid';</script>
<!--{/if}-->
<!--{/if}-->