<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2015/4/15
 * Time: 11:15
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
include_once DISCUZ_ROOT.'source/plugin/xigua_hm/function.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$page = max(1, intval(getgpc('page')));
$lpp = 5;
$start_limit = ($page - 1) * $lpp;
$cat__id = intval($_GET['cat__id']);
if($cat__id){
    $cat_indo = C::t('#xigua_hs#xigua_hs_hangye')->fetch_by_catid($cat__id);
}
$GLOBALS['needchild'] = 1;
if(submitcheck('dosubmit')){

    if($r = $_GET['r']){
        foreach ($r['id'] as $cid => $name) {
            $data = array(
                'miao' => ($r['miao'][$cid] ? 1 : 0),
                'goodindex' => ($r['goodindex'][$cid] ? 1 : 0),
                'o' => intval($r['o'][$cid]),
            );
            C::t('#xigua_hs#xigua_hs_hangye')->update($cid, $data);
        }
        cpmsg(
            lang_hm('succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_hangye&page=$page",
            'succeed'
        );
    }
}

$result = DB::fetch_all("SELECT * FROM %t  WHERE pid=0  ORDER BY o ASC,id ASC " . DB::limit($start_limit, $lpp),array('xigua_hs_hangye',),'id');
$sub_result = DB::fetch_all("SELECT * FROM %t  WHERE pid in(%n)  ORDER BY o ASC,id ASC ",array('xigua_hs_hangye', array_keys($result),),'id');
$listinfo =  array_merge($result, $sub_result);

C::t('#xigua_hs#xigua_hs_hangye')->init($listinfo);
$list = C::t('#xigua_hs#xigua_hs_hangye')->get_tree_array(0);

$totalcount = C::t('#xigua_hs#xigua_hs_hangye')->count_by_page();
$multipage = multi(
    $totalcount, $lpp, $page,
    ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_hangye&page=$page"
);

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_hangye&page=$page", 'enctype');
$alink = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_pub&catadd";

$hb_cats = C::t('#xigua_hb#xigua_hb_cat')->list_all(1);

$hb_catsting = '';
foreach ($hb_cats as $index => $hb_cat) {
    $hb_catsting.= "[{$hb_cat['name']}: <b>{$hb_cat['id']}</b>] ";
}
showtips(lang_hm('category_tip', 0));
?>
<style>
    .imgi{height:20px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
    .short{width:150px}
    .td23 input{width:120px!important;}
</style>
<div style="height:30px;line-height:30px;padding-left:25px">
    <a href="javascript:;" onclick="show_all()"><?php echo cplang('show_all')?></a> | <a href="javascript:;" onclick="hide_all()"><?php echo cplang('hide_all')?></a>
</div>
<table class="tb tb2 ">
    <tbody>
    <tr class="header">
        <th>&nbsp;</th>
        <th><?php lang_hm('hangye_id')?></th>
        <th><?php lang_hm('displayorder')?></th>
        <th><?php lang_hm('cat_name')?></th>
        <th><?php lang_hm('caozuo')?></th>
    </tr>
    </tbody>
    <?php foreach ($list as $v) { ?>
        <tbody>
        <tr class="hover">
            <td class="td25" onclick="toggle_group('group_<?php echo $v['id']?>', $('a_group_<?php echo $v['id']?>'))"><a href="javascript:;" id="a_group_<?php echo $v['id']?>">[-]</a></td>
            <td class="td25"><input type="hidden"  name="r[id][<?php echo $v['id']?>]" value="<?php echo $v['id']?>"><?php echo $v['id']?></td>
            <td class="td23"><input type="text" style="width:90px" name="r[o][<?php echo $v['id']?>]" value="<?php echo intval($v['o'])?>" /> </td>
            <td class="td23"><b><?php echo $v['name']?></b></td>

            <td>
                <label><input type="checkbox" name="r[miao][<?php echo $v['id'] ?>]" value="1" <?php echo $v['miao'] ? 'checked' : ''; ?> /> <?php lang_hm('kqmsyh')?></label>
                <label><input type="checkbox" name="r[goodindex][<?php echo $v['id'] ?>]" value="1" <?php echo $v['goodindex'] ? 'checked' : ''; ?> /> <?php lang_hm('kqspsy')?></label>
            </td>
        </tr>
        </tbody>
        <tbody id="group_<?php echo $v['id']?>">
        <?php foreach ($v['child'] as $c) { ?>
            <tr class="hover">
                <td class="td25"></td>
                <td class="td25"><input type="hidden"  name="r[id][<?php echo $c['id']?>]" value="<?php echo $c['id']?>"><?php echo $c['id']?></td>
                <td class="td23"><input type="text" style="width:90px" name="r[o][<?php echo $c['id']?>]" value="<?php echo intval($c['o'])?>" /> </td>
                <td class="td23">&nbsp;&nbsp;<?php echo $c['name']?></td>
                <td>
                    <label><input type="checkbox" name="r[miao][<?php echo $c['id'] ?>]" value="1" <?php echo $c['miao'] ? 'checked' : ''; ?> /> <?php lang_hm('kqmsyh')?></label>
                    <label><input type="checkbox" name="r[goodindex][<?php echo $c['id'] ?>]" value="1" <?php echo $c['goodindex'] ? 'checked' : ''; ?> /> <?php lang_hm('kqspsy')?></label>
                </td>
            </tr>
            <?php
        }
        ?>
        </tbody>
    <?php }?>

    <tbody>
    <?php
    if($multipage){
        showtablerow('', 'colspan="99"', $multipage);
    }
    showsubmit('dosubmit', 'submit', 'td');
    ?>
    </tbody>
</table>
</form>