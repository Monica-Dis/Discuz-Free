<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function hm_get_shids_by_uid1($shid){
    global $_G;
    $shids = array();
    if(!$_G['uid'] || !$_G['cache']['plugin']['xigua_hs']){
        return $shids;
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array_keys($shids1), array_keys($shids2));
    return in_array($shid, $shids);
}