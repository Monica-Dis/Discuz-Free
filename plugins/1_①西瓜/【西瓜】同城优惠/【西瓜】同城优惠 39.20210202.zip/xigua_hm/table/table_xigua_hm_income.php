<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2015/11/3
 * Time: 15:09
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hm_income extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hm_income';
        $this->_pk = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }

    public function fetch_u_order($wherearr,  $start_limit , $lpp){
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $uids = $ouids = array();
        $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table)." $wheresql ORDER BY crts DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $uids[] = $item['fansuid'];
            $result[$index] = self::prepare($item);
            $ouids[] = $result[$index]['info']['fromuid'];
        }

        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }
        if($ouids){
            $ousers = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $ouids), 'uid');
        }
        foreach ($result as $index => $item) {
            $result[$index]['fans'] = $users[$item['fansuid']];
            $result[$index]['orderuser'] = $ousers[$item['info']['fromuid']];
        }
        return $result;
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = dgmdate($v['crts'], 'u');
            $v['info'] = unserialize($v['info']);
        }
        return $v;
    }

    public function doreach($uid){
        global $_G, $SCRITPTNAME;
        $hm_config = $_G['cache']['plugin']['xigua_hm'];
        $today = date('Y-m-d', TIMESTAMP);

        if(0){
        }else{
            $reach = 1;
            $processname = 'hm_income_lock_uid1';
            if(discuz_process::islocked($processname, 60)) {
                return false;
            }
            $rz = lang('plugin/xigua_hm', 'rz');
            $shouxufei = lang('plugin/xigua_hm', 'shouxufei');
            foreach (DB::fetch_all("select * from %t WHERE indate<=%s AND reach=0 LIMIT 10", array( $this->_table, $today)) as $k => $v) {
                parent::update($v['id'], array('reach'=>$reach));
                if(DB::affected_rows()>0){
                    $v = self::prepare($v);
                    $user = DB::fetch_first('SELECT uid,username FROM %t WHERE uid=%d', array('common_member', $v['info']['fromuid']));
                    $ratio = str_replace('.00', '', $v['ratio_money']);

                    $logid = DB::result_first('SELECT id FROM %t WHERE order_id=%s', array('xigua_hm_seckill_log', $v['info']['order_id']));

                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['uid'], 'money', $v['money']);
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid'  => $v['uid'],
                        'crts' => TIMESTAMP,
                        'size' => $v['money'],
                        'note' => $user['username'].$v['info']['subject']."<br>{$shouxufei}&yen;{$ratio},{$rz}&yen;{$v['money']}",
                        'link' => "$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$logid",
                    ));
                    notification_add($v['uid'],'system', lang('plugin/xigua_hm', 'note_3'),array('url' => "$SCRITPTNAME?id=xigua_hb&ac=qianbao", 'money'=>$v['money']),1);
                }
            }
            return true;
        }
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY crts DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = self::prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function initincome($order_info)
    {
        global $_G;
        $info = $order_info['info'];
        if(!is_array($info)){
            $info = unserialize($info);
        }
        $base_price = $order_info['baseprice'];

        $shid = intval($info['data'][0]['shid']);
        $secid = intval($info['data'][0]['id']);
        $income_uid = intval( $info['data'][0]['income_uid']);
        if($shid){
            include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
            $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
            $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
            $zhangqi = intval(abs($vipinfo['zhangqi']));
            $insxf   = intval(abs($vipinfo['insxf']))/100;
            if($shdata['shzhangqi']){
                $zhangqi = intval(abs($shdata['shzhangqi']));
            }
            if($shdata['shinsxf']){
                $insxf   = intval(abs($shdata['shinsxf']))/100;
            }

            $secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch($secid);
            if($secinfo['shrate']> 0){
                $insxf = $secinfo['shrate']/100;
            }

            $sxfee = round($insxf*$base_price, 2);
            if($secinfo['jiesuan1']> 0){
                $sxfee = $secinfo['jiesuan1'];
            }

            $num = intval($info['data'][1]['num']);
            if($num<1){
                $num = 1;
            }
            $money = $base_price-$sxfee - $secinfo['hhr_ticheng']*$num - $secinfo['hhr_ticheng2']*$num;

            $hm_config = $_G['cache']['plugin']['xigua_hm'];
            if($money>0){
                C::t('#xigua_hm#xigua_hm_income')->insert(array(
                    'uid'     => $income_uid ? $income_uid : $shdata['uid'],
                    'crts'    => TIMESTAMP,
                    'ratio'   => $insxf*100,
                    'ratio_money' => $sxfee,
                    'indate'  => date('Y-m-d', strtotime('+'.$zhangqi.' days')),
                    'money'   => $money,
                    'info'    => serialize($order_info),
                    'order_id' => $order_info['order_id'],
                    'reach'   => $hm_config['needshen_in'] ? -1 : 0,
                ));
            }
        }

        if($_G['cache']['plugin']['xigua_hh']){
            global $loginfo, $logid;
            if(!$logid){
                $logid = $loginfo['id'];
            }
            @DB::query("UPDATE %t SET reach=%d WHERE idtype='common_seckill' AND FIND_IN_SET(%d ,thirdid)", array('xigua_hh_income', ($_G['cache']['plugin']['xigua_hh']['needshen_in'] ? -1 : 0), $logid));
        }
    }
}