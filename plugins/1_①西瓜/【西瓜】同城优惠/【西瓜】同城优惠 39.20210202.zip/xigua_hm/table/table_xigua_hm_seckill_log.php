<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2015/11/3
 * Time: 15:09
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hm_seckill_log extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_hm_seckill_log';
        $this->_pk = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false)
    {
        global $secinfo;
        $formggs = '';
        if($_GET['formgg'] && $secinfo['id'] == $data['secid']){
            $formgg = explode("\n", trim($secinfo['formgg']));
            foreach ($_GET['formgg'] as $index => $item) {
                $formggs .= trim($formgg[$index]).':'.strip_tags($item).'<br>';
            }
        }
        $data['formggs'] = $formggs;
        $id = parent::insert($data, $return_insert_id, $replace, $silent);
        return $id;
    }

    public function fetch_by_code($code){

        $res = DB::fetch_first('select * from %t where code=%s', array(
            $this->_table,
            $code
        ));
        if($res['hxstatus']==7){
            $res['hxstatus'] = 0;
        }
        if($res['hxstatus']){
            return false;
        }
        return $res;
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false) {
        if($data['order_id'] && $data['status'] ==2 && count($data) == 2){

        }
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function update_by_cond($condition, $data)
    {
        DB::update($this->_table, $data, $condition);
        return DB::affected_rows();
    }

    public function fetch_all_by_where($wherearr, $start_limit, $lpp, $orderby = '', $fields= '*', $keyfield = '', $retarr = 0)
    {
        /*if(is_array($wherearr) && !defined('IN_ADMINCP')){
            $wherearr[] = 'stid='.intval($_GET['st']);
            global $_G;
            if(!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']){
                array_pop($wherearr);
            }
        }*/
        if(($_GET['do'] == 'seckill_li' && $_GET['manage']==1) || $retarr){
            if($_GET['status']){
                $status = intval($_GET['status']);
                if($status==-1){
                    $status = '0';
                    $wherearr[] = " (status=$status OR (status=1 AND hxstatus=7)) ";
                }else{
                    $wherearr[] = "status=$status";
                }
            }
            if($_GET['hx']){
                $hx = intval($_GET['hx']);
                if($hx==-1){
                    $hx = '0';
                }
                $wherearr[] = "hxstatus=$hx";
            }
            if($_GET['notaddr']){
                $wherearr[] = 'addrid=0';
            }
            if ($keyword = stripsearchkey($_GET['keyword'])) {
                if(is_numeric($keyword) && strlen($keyword) == 11){
                    $uid = DB::result_first('SELECT uid FROM %t WHERE mobile=%s ', array('xigua_hb_user', $keyword));
                    $wherearr[] = "uid='$uid'";
                }else{
                    $secids1 = array();
                    foreach (DB::fetch_all("select id from ".DB::table('xigua_hm_seckill')." where title like '%$keyword%'") as $index => $_v) {
                        $secids1[] = intval($_v['id']);
                    }
                    $oror = '';
                    if($secids1){
                        $oror = ' OR secid IN('.implode(',', $secids1).')';
                    }

                    $uids = array();
                    foreach (DB::fetch_all("select uid,username from ".DB::table('common_member')." where username like '%$keyword%'") as $index => $_v) {
                        if($_v['uid']){
                            $uids[] = intval($_v['uid']);
                        }
                    }
                    if($uids){
                        $uids = implode(',', $uids);
                        $wherearr[] = " (uid IN($uids) OR shid='$keyword' OR order_id LIKE '%$keyword%' OR code LIKE '%$keyword%' OR ggname LIKE '%$keyword%' OR postinfo LIKE '%$keyword%' $oror) ";
                    }else{
                        $wherearr[] = " (uid='$keyword' OR shid='$keyword' OR order_id LIKE '%$keyword%' OR code LIKE '%$keyword%' OR ggname LIKE '%$keyword%' OR postinfo LIKE '%$keyword%' $oror) ";
                    }

                }
            }
            if($retarr){
                return $wherearr;
            }
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        if($lpp == 1){
            $result = DB::fetch_first("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby ");
        }else{
            $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp), array(), $keyfield);
        }
        if($fields=='*' && $lpp !=1 ){
            $uids = array();
            foreach ($result as $k => $v) {
                $uids[] = $v['uid'];
            }
            $users = DB::fetch_all('SELECT username,uid FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $rk => $rv) {
                $result[$rk]['user'] = $users[$rv['uid']];
                $result[$rk]['crts_u'] = str_replace('&nbsp;', '', dgmdate($result[$rk]['crts'], 'u'));
                $result[$rk]['usetime_u'] = $result[$rk]['endts'] ? dgmdate($result[$rk]['endts'], 'Y-m-d H:i') : lang('plugin/xigua_hm', 'cqyx');
                $result[$rk]['pay_endts_u'] = dgmdate($result[$rk]['pay_endts'], 'Y-m-d H:i');

                if($rv['status']==2 && $rv['hxstatus']==7){
                    DB::update('xigua_hm_seckill_log', array(
                        'hxstatus' => 0,
                        'tkts' => 0
                    ), array(
                        'id' => $rv['id']
                    ));
                }

                if($rv['order_id'] && $rv['status']==0){
                    $order = DB::fetch_first('SELECT * FROM %t WHERE order_id IN(%n)', array('xigua_hb_order', $rv['order_id']), 'order_id');
                    if($order['paystatus']>0 ) {
                        DB::query("UPDATE %t SET status=2,tkts=0,hxstatus=0 WHERE id=%d AND status=0 limit 1", array(
                            'xigua_hm_seckill_log',
                            $rv['id']
                        ));
                    }
                }

            }
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function fetch_sum_by_page($wherearr = array(), $field = 'num')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first("SELECT  sum($field) as c FROM " . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function check_if_get($secid, $uid)
    {
        $result = DB::fetch_first("SELECT *,sum(num) as alnum FROM %t WHERE secid=%d AND uid=%d AND status=2", array(
            $this->_table,
            $secid,
            $uid
        ));
        return $result;
    }

    public static function prepare($v)
    {
        if($v){
            $v['hxcrts_u'] = dgmdate($v['hxcrts'], 'u');
            $v['crts_u'] = str_replace('&nbsp;', '', dgmdate($v['crts'], 'u'));
            $v['usetime_u'] = $v['endts'] ? dgmdate($v['endts'], 'Y-m-d H:i') : lang('plugin/xigua_hm', 'cqyx');
            $v['pay_endts_u'] = dgmdate($v['pay_endts'], 'Y-m-d H:i');
            $v['postinfo'] = $v['postinfo'] ? unserialize($v['postinfo']) : array();

            if($v['status']==2 && $v['hxstatus']==7){
                DB::update('xigua_hm_seckill_log', array(
                    'hxstatus' => 0,
                    'tkts' => 0
                ), array(
                    'id' => $v['id']
                ));
            }
            $rv = $v;
            if($rv['order_id'] && $rv['status']==0){
                $order = DB::fetch_first('SELECT * FROM %t WHERE order_id IN(%n)', array(
                    'xigua_hb_order', $rv['order_id']
                ), 'order_id');
                if($order['paystatus']>0) {
                    DB::query("UPDATE %t SET status=2,tkts=0,hxstatus=0 WHERE id=%d AND status=0 limit 1", array(
                        'xigua_hm_seckill_log',
                        $rv['id']
                    ));
                }
            }
        }
        return $v;
    }
    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }
}