<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-01-02,16:36:49
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hm/function.php';


function hm_avatar_file($uid, $size) {
    global $_G;

    $var = "home_avatarfile_{$uid}_{$size}";
    if(empty($_G[$var])) {
        $uid = abs(intval($uid));
        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        $_G[$var] = $dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2)."_avatar_$size.jpg";
    }
    return $_G[$var];
}
function hm_resize_img($file, $imgname, $width1=50, $height1=50){
    list($width, $height) = getimagesize($file);
    $percent1 = ($width1/$width);
    $percent2 = ($height1/$height);
    $percent = max($percent1, $percent2);
    $newwidth = $width * $percent;
    $newheight = $height * $percent;
    $src_im = imagecreatefromjpeg($file);
    $dst_im = imagecreatetruecolor($newwidth, $newheight);
    imagecopyresized($dst_im, $src_im, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
    imagejpeg($dst_im, $imgname);
    imagedestroy($dst_im);
    imagedestroy($src_im);
    return $imgname;
}

function hm_imagecreatefrom($filetype){

    $imagecreatefromfunc = 'imagecreatefromjpeg';
    switch($filetype) {
        case 'image/jpeg':
            $imagecreatefromfunc = function_exists('imagecreatefromjpeg') ? 'imagecreatefromjpeg' : '';
            break;
        case 'image/gif':
            $imagecreatefromfunc = function_exists('imagecreatefromgif') ? 'imagecreatefromgif' : '';
            break;
        case 'image/png':
            $imagecreatefromfunc = function_exists('imagecreatefrompng') ? 'imagecreatefrompng' : '';
            break;
    }
    return $imagecreatefromfunc;
}

function hm_draw_txt_to($card, $pos, $str, $iswrite)
{
    $_str_h = $pos["top"];
    $fontsize = $pos["fontsize"];
    $width = $pos["width"];
    $margin_lift = $pos["left"];
    $hang_size = $pos["hang_size"];
    $temp_string = "";
    $font_file = DISCUZ_ROOT.'source/plugin/xigua_hm/static/msyh.ttc';
    $tp = 0;

    $font_color = imagecolorallocate($card, $pos["color"][0], $pos["color"][1], $pos["color"][2]);
    $charset = 'utf8';
    $textcolor = $font_color;
    $lineHeight = $hang_size;
    $startX = $margin_lift;
    $startY = $_str_h+25;

    $lineArr = hm_autoLineSplit($str, $font_file, $fontsize, $charset, $width);
    foreach ($lineArr as $k => $v) {
        imagettftext($card, $fontsize, 0, $startX, ($startY + ($lineHeight* $k)), $textcolor, $font_file, $v);
    }
    return $tp * $hang_size;
}
function hm_autoLineSplit ($str, $fontFamily, $fontSize, $charset, $width) {
    $result = array();

    $len = (strlen($str) + mb_strlen($str, $charset)) / 2;
    $dimensions = imagettfbbox($fontSize, 0, $fontFamily, $str);
    $textWidth = abs($dimensions[4] - $dimensions[0]);
    $singleW = $textWidth / $len;
    $maxCount = floor($width / $singleW);
    while ($len > $maxCount) {
        $result[] = mb_strimwidth($str, 0, $maxCount, '', $charset);
        $str = str_replace($result[count($result) - 1], '', $str);
        $len = (strlen($str) + mb_strlen($str, $charset)) / 2;
    }
    $result[] = $str;

    return $result;
}

function hm_firstfuhao($str)
{
    $fuhaos = array('"', "'",);
    return in_array($str, $fuhaos);
}

$secid = intval($_GET['secid']);
$v = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_id($secid);
$urlext = !$urlext ? $_G['cookie']['URLEXT'] : $urlext;
$url = $_G['siteurl']."plugin.php?id=xigua_hm&ac=seckill_view&secid=$secid".$urlext;

if($v['custom_pic'] && !$_GET['qrcode']){
    $ewm = md5($secid.$urlext.'custompic'.$config['qraut']);
    $topimg = $ewm.'_top';
    $topimg = $ewm.'_final';
    $album = $v['custom_pic'];
    $repath = './source/plugin/xigua_hm/cache/';

    if(!is_file(DISCUZ_ROOT . $repath . $topimg.'.jpg') || $_GET['qrcode']) {
        $qrfile = $repath . $ewm . '.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;
        if (!is_file($abs_qrfile)) {
            if($config['qraut']){
                $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_hb:qrauto&needqrfile=1&ode=hm_{$secid}{$urlext}";
                $qrfile = hb_curl($url);
                $abs_qrfile = DISCUZ_ROOT . $qrfile;
                hm_resize_img($abs_qrfile, $abs_qrfile, 180, 180);
            }else{
                @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                if(class_exists('QRcode')){
                    QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
                }
            }
        }
        $top_stam_info = getimagesize($abs_qrfile);
        switch ($top_stam_info['mime']) {
            case 'image/jpeg':
                $stamp = imagecreatefromjpeg($abs_qrfile);
                break;
            case 'image/gif':
                $stamp = imagecreatefromgif($abs_qrfile);
                break;
            case 'image/png':
                $stamp = imagecreatefrompng($abs_qrfile);
                break;
        }
        $abs_img = DISCUZ_ROOT . $repath . $topimg . '.jpg';
        if (!is_file($abs_img)) {
            file_put_contents($abs_img, hb_curl($album));
        }
        $top_stam_info = getimagesize($abs_img);
        switch ($top_stam_info['mime']) {
            case 'image/jpeg':
                $top_stamp = imagecreatefromjpeg($abs_img);
                break;
            case 'image/gif':
                $top_stamp = imagecreatefromgif($abs_img);
                break;
            case 'image/png':
                $top_stamp = imagecreatefrompng($abs_img);
                break;
        }

        $img = imagecreatetruecolor(720, 1280);
        $white = imagecolorallocate($img, 255, 255, 255);
        $c1 = imagecolorallocate($img, 0, 0, 255);
        imagefill($img, 0, 0, $white);

        $top_stamp_x = 720;
        $top_stamp_y = 1280;

        imagecopy($img, $top_stamp, 0, 0, 0, 0, $top_stamp_x, $top_stamp_y);
        imagecopy($img, $stamp, 485, 1060-35, 0, 0, imagesx($stamp), imagesy($stamp));
        $temp = array("color" => array(33, 33, 33), "fontsize" => 24, "width" => 300, "left" => 120, "top" => 1060-25, "hang_size" => 24);
        $str_h = hm_draw_txt_to($img, $temp, diconv($_G['username'].lang_hm('xntj',0), CHARSET, 'UTF-8'), true);
        if($_G['uid']){
            $avatar_file = DISCUZ_ROOT.'uc_server/data/avatar/'.hm_avatar_file($_G['uid'], 'small');
            if(is_file($avatar_file)){
                $new_avatarfile = DISCUZ_ROOT.$repath.md5($avatar_file).'.jpg';
                hm_resize_img($avatar_file, $new_avatarfile);
                $stamp_avatar = imagecreatefromjpeg($new_avatarfile);
                if($stamp_avatar){
                    imagecopy($img, $stamp_avatar, 55, 1060-35, 0, 0, imagesx($stamp_avatar), imagesy($stamp_avatar));
                    @unlink($new_avatarfile);
                }
            }
        }

        imagejpeg($img, DISCUZ_ROOT . $repath . $topimg . '.jpg', 90);
        imagedestroy($img);
    }
    dheader('Location: '.$_G['siteurl'].$repath.$topimg.'.jpg?2'.VERHASH);
}

$ewm = md5($secid.$_G['cookie']['URLEXT'].$urlext.$config['qraut']);
$topimg = $ewm.'_top';
$topimg = $ewm.'_final';
$album = $v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0];
if(!$album){
    $album = $_G['siteurl'].'source/plugin/xigua_hm/static/images/npic.png';
}

if(!is_file(DISCUZ_ROOT . './source/plugin/xigua_hm/cache/'.$topimg.'.png') || $_GET['qrcode']) {
    $repath = './source/plugin/xigua_hm/cache/';
    $qrfile = $repath . $ewm . '.png';
    $abs_qrfile = DISCUZ_ROOT . $qrfile;

    if (!is_file($abs_qrfile)) {
        if($config['qraut']){
            $url = "$SCRITPTNAME?id=xigua_hb:qrauto&needqrfile=1&ode=hm_{$secid}{$urlext}";
            $qrfile = hb_curl($url);
            $abs_qrfile = DISCUZ_ROOT . $qrfile;
        }else {
            @include_once DISCUZ_ROOT . 'source/plugin/mobile/qrcode.class.php';
            if (class_exists('QRcode')) {
                QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
            }
        }
    }
    if($_GET['qrcode']){
        dheader('Location: '.$_G['siteurl'].$qrfile.'?'.VERHASH);
        exit;
    }
    $stamp = imagecreatefrompng($abs_qrfile);

    $abs_img = DISCUZ_ROOT . './source/plugin/xigua_hm/cache/' . $topimg . '.png';
    if (!is_file($abs_img)) {
        file_put_contents($abs_img, hb_curl($album));
    }
    $top_stam_info = getimagesize($abs_img);
    switch ($top_stam_info['mime']) {
        case 'image/jpeg':
            $top_stamp = imagecreatefromjpeg($abs_img);
            break;
        case 'image/gif':
            $top_stamp = imagecreatefromgif($abs_img);
            break;
        case 'image/png':
            $top_stamp = imagecreatefrompng($abs_img);
            break;
    }

    $img = imagecreatetruecolor(640, 960);
    $white = imagecolorallocate($img, 245, 245, 245);
    $c1 = imagecolorallocate($img, 0, 0, 255);
    imagefill($img, 0, 0, $white);

    $top_stamp_x = 640;
    $top_stamp_y = 640;

    imagecopy($img, $top_stamp, 0, 0, 0, 0, $top_stamp_x, $top_stamp_y);

    imagecopy($img, $stamp, 330, 660, 0, 0, imagesx($stamp), imagesy($stamp));


    $temp = array("color" => array(33, 33, 33), "fontsize" => 27, "width" => 300, "left" => 20, "top" => 660, "hang_size" => 40);
    $str_h = hm_draw_txt_to($img, $temp, diconv($v['title'], CHARSET, 'UTF-8'), true);

    if($v['stype']=='seckill'){

        $temp = array("color" => array(120, 120, 120), "fontsize" => 27, "width" => 300, "left" => 20, "top" => 780, "hang_size" => 40);
        $str_h = hm_draw_txt_to($img, $temp, diconv(lang_hm('yj',0).':'.$v['marketprice'].lang_hm('yuan',0), CHARSET, 'UTF-8'), true);

        $temp = array("color" => array(255, 0, 0), "fontsize" => 27, "width" => 300, "left" => 20, "top" => 830, "hang_size" => 40);
        $str_h = hm_draw_txt_to($img, $temp, diconv(lang_hm('seckill',0).':'.$v['price'].lang_hm('yuan',0), CHARSET, 'UTF-8'), true);
    }else{
        if($v['stype']=='zhekou'){
            $title = "{$v['show_zhekourate']}".lang_hm('zhe',0);
        }else{
            $title = "{$v['marketprice']}".lang_hm('yuan',0)."{$stypes[$v['stype']]}";
        }

        $temp = array("color" => array(120, 120, 120), "fontsize" => 27, "width" => 300, "left" => 20, "top" => 780, "hang_size" => 40);
        $str_h = hm_draw_txt_to($img, $temp, diconv($title, CHARSET, 'UTF-8'), true);

        $temp = array("color" => array(255, 0, 0), "fontsize" => 27, "width" => 300, "left" => 20, "top" => 830, "hang_size" => 40);
        $str_h = hm_draw_txt_to($img, $temp, diconv(lang_hm('seckill',0).':'.$v['price'].lang_hm('yuan',0), CHARSET, 'UTF-8'), true);
    }
    $temp = array("color" => array(255, 0, 0), "fontsize" => 20, "width" => 300, "left" => 20, "top" => 900, "hang_size" => 30);
    $str_h = hm_draw_txt_to($img, $temp, diconv(lang_hm('calq',0), CHARSET, 'UTF-8'), true);


    imagepng($img, DISCUZ_ROOT . './source/plugin/xigua_hm/cache/' . $topimg . '.png');
    imagedestroy($img);
}
dheader('Location: '.$_G['siteurl'].'source/plugin/xigua_hm/cache/'.$topimg.'.png?'.VERHASH);