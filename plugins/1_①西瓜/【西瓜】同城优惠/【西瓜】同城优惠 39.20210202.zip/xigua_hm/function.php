<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function hm_callback_seckill_($param){
    global $_G;
    $hm_config = $_G['cache']['plugin']['xigua_hm'];

    $info = $param['info'];
    $secid = intval($info['data'][0]['id']);
    $shuid = intval($info['data'][0]['uid']);
    $maxnum = $info['data'][0]['maxnum'];
    $num = intval($info['data'][1]['num']);
    $log_id = intval($info['data'][1]['log_id']);

    C::t('#xigua_hm#xigua_hm_seckill_log')->update($log_id, array('order_id' => $param['order_id'], 'status' => 2, 'tkts' => 0, 'hxstatus' => 0));
    $usr = getuserbyuid($param['fromuid']);
    notification_add($shuid,'system', "<a href=\"{url}\">".$usr['username'].lang('plugin/xigua_hm', 'gml').$param['subject'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_hm&ac=seckill_profile&logid='.$log_id),1);
    notification_add($param['fromuid'],'system', "<a href=\"{url}\">".$usr['username'].lang('plugin/xigua_hm', 'gml').$param['subject'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_hm&ac=seckill_profile&logid='.$log_id),1);
    return true;
}

function hm_refund($secid, $param, $log_id){
    C::t('#xigua_hm#xigua_hm_seckill_log')->update($log_id, array('order_id' => $param['order_id'], 'status' => 1,));
    return true;
}

function hm_random_code($uid){
    return substr(mt_rand(10000000, 99999999).$uid, 0, 8);
}
function hm_make($code){
    @include_once DISCUZ_ROOT . './source/plugin/mobile/qrcode.class.php';
    global $_G, $config,$SCRITPTNAME;
    $rs = array();

    $repath = './source/plugin/xigua_hm/cache/';
    $qrfile = $repath . $code . '.png';
    $abs_qrfile = DISCUZ_ROOT . $qrfile;
    $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_hm&ac=scan&code=$code";

    if(!is_file($abs_qrfile)) {
        @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
        if (class_exists('QRcode')) {
            QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 6);
        }
    }
    return $qrfile;
}
function hm_space_number($num){
    $num1 = substr($num, 0, 4);
    $num2 = substr($num, 4);
    return $num1.' '.$num2;
}
function hm_set_parse($str){
    global $_G,$SCRITPTNAME;
    $rs = array();
    if($pic_string = $str){
        $top_pics = array_filter(explode("\n", $pic_string));
        if(!empty($top_pics) && is_array($top_pics)){
            foreach ($top_pics as $top_pic) {
                $top_pic = str_replace(array('|',','), ' ', trim($top_pic));
                list( $word, $src, $href) = explode(' ', $top_pic);
                $word = trim($word);
                $src = trim($src);
                $href = trim($href);
                if(empty($href) || $href == '#'){
                    $href = 'javascript:void(0);';
                }
                if($src && $href){
                    if(strpos($src, 'http://') === false && strpos($src, 'https://') === false){
                        $src = $_G['siteurl'] . $src;
                    }
                    $rs[] = array('href' => str_replace('plugin.php', $SCRITPTNAME ,$href), 'src' =>$src, 'name' => $word);
                }
            }
        }
    }
    return $rs;
}

function lang_hm($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hm', $lang);
    }else{
        return lang('plugin/xigua_hm', $lang);
    }
}

function check_hm_manage(){
    global $_G;
    $shids = array();
    if(!$_G['uid']){
        return $shids;
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array('0'), array_keys($shids1), array_keys($shids2));
    return $shids;
}