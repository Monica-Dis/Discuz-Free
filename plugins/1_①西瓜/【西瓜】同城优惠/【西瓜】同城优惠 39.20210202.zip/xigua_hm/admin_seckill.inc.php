<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2017/11/19
 * Time: 16:38
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hm/function.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";

$stypes = array('youhui' => lang_hm('youhui',0),'daijin'=>lang_hm('daijin',0),'zhekou'=>lang_hm('zhekou',0),'seckill' => lang_hm('seckill',0));
$statuss = array(
    '0' => lang_hm('shwg',0),
    '1' => lang_hm('ddsh',0),
    '2' => lang_hm('ysj',0),
    '3' => lang_hm('yxj',0)
);

$page = max(1, intval(getgpc('page')));
$lpp = 10;
$start_limit = ($page - 1) * $lpp;

if($secid = intval($_GET['secid'])){

    $res = C::t('#xigua_hm#xigua_hm_seckill')->fetch($secid);

    if(!submitcheck('dosubmit')) {
        if(!$res){
            $res = array('id' => '0', 'stype' => 'seckill', 'status' => '2', 'uid' => $_G['uid'], 'title' => '', 'shid' => '',
                'allnum' => '1', 'maxnum' => '1', 'stock' => '1',
            'usetime_start' => 0,'usetime' => '', 'starttime' => '', 'endtime' => '', 'marketprice' => '20.00',
                'price' => '0.00','hkprice' => '0.00', 'dingprice' => '0.00', 'fee' => '0.00',
                'srange' => '', 'tuijian' => '', 'biaoqian' => '', 'jieshao' => '', 'album' => 'a:0:{}',
                'append_img' => 'a:0:{}', 'append_text' => 'a:0:{}', 'crts' => '', 'upts' => '', 'views' => '0', 'shares' => '0', 'yuyue' => '0', 'gongkai' => '1', 'underline' => '0', 'fanwei' => '', 'zhekourate' => '0', 'displayorder' => '0', 'hxnum' => '0','formgg' => '');
        }

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_hm('spgl',0) . ($secid>0?$secid:''). "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&secid=$secid'> ".lang_hm('back',0)."</a>");

        foreach ($res as $index => $re) {
            if(in_array($index, array('hangye_id1','hangye_id2','shname', 'not_start', 'end','srange_ary','xiajia','shen', 'quan', 'yuanprice','id','shares',
                'qun','qrcache','hhr2rate','hhrrate',/*'shrate',*/'jiesuan2'
            ))){
                continue;
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('endts', 'dig_endts', 'crts', 'upts', 'usetime', 'starttime', 'endtime'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('stype'))){
                $cs = '<select name="editform[stype]">';
                foreach ($stypes as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('shid'))){
                $cs = '<select name="editform[shid]">';
                foreach (DB::fetch_all('select shid,`name` from %t WHERE display=1 AND endts>=%d ORDER BY shid desc ', array(
                    'xigua_hs_shanghu',
                    TIMESTAMP
                ), 'shid') as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['name']}[".lang_hm('sh',0)."ID:{$c['shid']}]</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('thumb', 'custom_pic'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('yuyue' ,'gongkai', 'allowtk', 'guoqitui','appzhekou', 'fszx'))){
                $tp = 'radio';
            }elseif(in_array($index, array('hmgg','formgg'))){
                $tp = 'textarea';
            }

            if (in_array($index, array('album', 'append_img', 'append_text'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $hs_config = $_G['cache']['plugin']['xigua_hs'];
                $loopnum = $hs_config['maximg'];
                if ($index == 'append_text') {
                    $tp = 'text';
                }
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_hm($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'jieshao'){
                if(strpos($v['jieshao'], '&lt;') !== false  && strpos($v['jieshao'], '&gt;') !== false) :
                    $v['jieshao'] = htmlspecialchars_decode($v['jieshao']);
                    $v['jieshao'] = preg_replace(array("/<script(.*?)<\/script>/is",'/on(mousewheel|mouseover|click|load|onload|submit|focus|blur)="[^"]*"/i'), array('',''), $v['jieshao']);
                endif;
                $_tmp1 = lang_hm($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                showsetting(lang_hm($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach (array('crts', 'upts', 'usetime', 'starttime', 'endtime') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        $editform['jieshao'] = ($editform['jieshao']);
        $editform['append_text'] = array_slice($editform['append_text'], 0, count($editform['append_img']));

        foreach (array('album', 'append_text', 'append_img') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }

        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($editform['shid']);
        if(!$sh){
            cpmsg(lang_hm('shnotexists',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&secid=$secid", 'error');
        }
        $editform['shname']     = $sh['name'];
        $editform['shid']       = $sh['shid'];
        $editform['hangye_id1'] = $sh['hangye_id1'];
        $editform['hangye_id2'] = $sh['hangye_id2'];

        $editform['srange'] = str_replace(' ', "\t", trim($editform['srange']));

        if($secid>0){
            $rs = C::t('#xigua_hm#xigua_hm_seckill')->update($secid, $editform);
        }else{
            $rs = C::t('#xigua_hm#xigua_hm_seckill')->insert($editform);
        }
        cpmsg(lang_hm('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&secid=$secid", 'succeed');
    }
}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_hm#xigua_hm_seckill')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_hm#xigua_hm_seckill')->update($id, array('displayorder' => $item['displayorder'], 'status' => $item['status']));
        }

        cpmsg(lang_hm('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = ' ( uid=' . intval($keyword) .' OR id='.intval($keyword) .') ';
    }else if ($keyword = stripsearchkey($keyword)) {
        $wherearr[] = " (title LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR biaoqian LIKE '%$keyword%' OR fanwei LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }
    if(isset($_GET['stype']) && $stypes[$_GET['stype']]){
        $wherearr[] = 'stype=\'' . ($_GET['stype']).'\'';
    }
    if(isset($_GET['secid1'])){
        $wherearr = array('id=\'' . intval($_GET['secid1']).'\'');
    }

    $ob = ' displayorder DESC, id DESC';

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_hm('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($statuss as $index => $_v) {
        echo '<input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v;
    }

    echo '&nbsp;';
    foreach ($stypes as $index => $_v) {
        echo '<input type="radio" name="stype" value="'.$index.'" ' . (isset($_GET['stype'])&&$_GET['stype']==$index ? 'checked' : '') . ' />' . $_v;
    }
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&secid=-1\">".lang_hm('tjsp',0)."</a></div>";

    showtableheader(lang_hm('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_hm('del', 0),
        lang_hm('displayorder', 0),
        lang_hm('stypess', 0),
        lang_hm('thumb', 0),
        lang_hm('hsname', 0).'<br>'.lang_hm('title', 0),
        lang_hm('allnum', 0),
        lang_hm('kc', 0),
        lang_hm('yssl', 0).'<br>'.
        lang_hm('hxfhl', 0),
        lang_hm('spzt', 0),
        lang_hm('xszt', 0),
        lang_hm('caozuo', 0),
        lang_hm('crendts', 0),
    ));

    $res = C::t('#xigua_hm#xigua_hm_seckill')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = C::t('#xigua_hm#xigua_hm_seckill')->fetch_count_by_page($wherearr);

    $shids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $shids[$v['shid']] = $v['shid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($shids){
        $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $shid = $v['shid'];
        $thumb = $v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0];
        $stat = lang_hm('jxz',0);
        if($v['not_start']){
            $stat =lang_hm( 'wks',0);
        }elseif ($v['end']){
            $stat = lang_hm('yjs',0);
        }
        if($v['stock']<=0){
            $stat = lang_hm('ysw',0);
        }


        $checked = $v['display'] ? 'checked' : '';

        $has_hx = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_sum_by_page(array('status=2', 'secid='.$id,'hxstatus=1'));
        $has_buycount = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_sum_by_page(array('status=2', 'secid='.$id));

        $has_hx = intval($has_hx);
        $has_buycount = intval($has_buycount);
        $appeend = '';
        foreach ($v['append_img_ary'] as $__k => $__v) {
            $appeend .= "<p><img style='width:180px;display:block' src=\"{$__v}\" /></p>";
            $appeend .= "<p>" . nl2br($v['append_text_ary'][$__k]) . "</p>";
        }

        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($statuss as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        $c = ($v['endts'] < TIMESTAMP ? 'style="color:red"' : 'style="color:forestgreen"');

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input type='text' name='row[$id][displayorder]' value='{$v['displayorder']}' style='width:40px' />",
            $stypes[$v['stype']],
            "<img src='$thumb' style='width:70px;height:40px' />",
            "<a target='_blank' href='".ADMINSCRIPT."?action=plugins&operation=config&do=&identifier=xigua_hs&pmod=admin_shanghu&shid=".$v['shid']."'>".$shinfos[$v['shid']]['name'].'</a><br>'.$v['title'],
            "<input class='txt' style='width:40px' name='row[$id][allnum]' value='{$v['allnum']}' />",
            "<input class='txt' style='width:40px' name='row[$id][stock]' value='{$v['stock']}' />",
            lang_hm('yssl',0).':'.$has_buycount.'<br>'.
            lang_hm('hxfhl',0).':'.$has_hx,

            $status_u,
            $stat,

            '<a class="btn" href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&secid=$id" . '">' . lang_hm('edit', 0) . '</a> '.
            '<a class="btn" href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckilllog&secid=$id" . '">' . lang_hm('gmjl', 0) . '</a>',

            $v['crts_u'].'<br>'.$v['start_u'].'/'.$v['end_u'],
        ));
    }
    unset($_GET['page']);
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hm&pmod=admin_seckill&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/

    /*echo '<pre>';
    print_r($res);
    echo '</pre>';*/
}