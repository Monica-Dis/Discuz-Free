<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/9/30
 * Time: 9:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$t =lang('plugin/xigua_hm','fangwen'). $_G['siteurl'].'plugin.php?id=xigua_hm<br><br><!--'.lang('plugin/xigua_hb','jiaocheng').'http://dism.taobao.com/?@xigua_hb.plugin.75088-->';
cpmsg($t, '','succeed');