<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2018/8/22
 * Time: 10:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if ($_GET['do']=='zs'){
    include_once DISCUZ_ROOT.'source/plugin/xigua_hm/common_ext.php';
    global $_G;
    $hm_config = $_G['cache']['plugin']['xigua_hm'];
    $note = $_GET['note'];
    $touser = $_GET['touid'];
    $touid = DB::result_first('SELECT uid from %t where username=%s', array('common_member', $_GET['touid']));
    $myo2 = $_G['siteurl'].$SCRITPTNAME."?id=xigua_hm&ac=seckill_profile{$urlext}&logid=";

    if($touid==$_G['uid']){
       hb_message(lang_hm('bnzs',0), 'error');
    }
    if(0>=$_GET['num']){
        hb_message(lang_hm('zsslcw',0), 'error');
    }
    if(!$touid){
        hb_message(lang_hm('zsyhbcz',0), 'error');
    }
    $num = intval($_GET['num']);
    if(!submitcheck('formhash')){
        hb_message('formhash error', 'error');
    }
    $v = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_stock($secid, $num);
    if(!(hm_get_shids_by_uid1($v['shid']) || IS_ADMINID)){
        hb_message(lang_hm('wqx',0), 'error');
    }
    if($v['end']){
        hb_message(lang_hm('qgjs',0), 'error');
    }
    if($v['not_start']){
        hb_message(lang_hm('qgwks',0), 'error');
    }
    if(!$v){
        hb_message(lang_hm('kcbz',0), 'error');
    }
    if($v['xiajia']){
        hb_message(lang_hm('spyxj',0), 'error');
    }
    if($v['shen']){
        hb_message(lang_hm('spshz',0), 'error');
    }

    $updatestock = C::t('#xigua_hm#xigua_hm_seckill')->update_stock($secid, $num);
    if($updatestock) {
        $totalprice = $v['price'] * $num + $v['fee'];
        $title = $v['title'] . $num . lang_hm('fen',0);
        $note = $_G['username'].lang_hm('zsg',0).$touser.'-'. $title.' <br>'.lang_hm('ly',0).$note;
        $pay_end = TIMESTAMP;
        $secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_id($secid);

        $log_id = C::t('#xigua_hm#xigua_hm_seckill_log')->insert(array(
            'secid' => $secid,
            'shid' => $secinfo['shid'],
            'stype' => $secinfo['stype'],
            'uid' => $touid,
            'order_id' => '',
            'num' => $num,
            'price' => $totalprice,
            'note' => $note,
            'crts' => TIMESTAMP,
            'endts' => $v['usetime'],
            'startts' => TIMESTAMP+$v['usetime_start'],
            'status' => 0,
            'addrid' => '',
            'ggname' => '',
            'code' => hm_random_code($_G['uid']),
            'pay_endts' => $pay_end,
            'stid' => intval($_GET['st'])
        ), true);
        if($totalprice>0) {
            $insxf = $totalprice;
            if($hm_config['hhrmethod']==2){
                if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/common.php')){
                    include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
                    $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($secinfo['shid']);
                    $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                    $zhangqi = intval(abs($vipinfo['zhangqi']));
                    $insxf   = intval(abs($vipinfo['insxf']))/100;
                    $sxfee = round($insxf*$totalprice, 2);
                }
            }

            $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_seckill', array(
                'data' => array($v, array(
                    'num' => $num,
                    'item_price' => $v['price'],
                    'price' => $totalprice,
                    'note' => $note,
                    'log_id' => $log_id,
                    'sxfee' => $sxfee,
                )),
                'callback' => array(
                    'file' => 'source/plugin/xigua_hm/function.php',
                    'method' => 'hm_callback_seckill_'
                ),
                'location' => $myo2.$log_id,
                'referer' => "$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid=$secid",
                'tip' => ($v['dingprice'] > 0 ? lang_hm('tx', 0) . (($v['yuanprice'] - $v['price']) * $num) . lang_hm('yuan', 0) : ''),
            ), $pay_end, $touid);
            C::t('#xigua_hb#xigua_hb_order')->update($order_id, array(
                'paystatus' => 1,
                'fromopenid' => '',
                'payupts' => TIMESTAMP,
                'paymethod' => 'ZENGSONG',
                'order_sn'  => '',
                'postprice'  => '0',
                'baseprice'  => '0',
            ));
            C::t('#xigua_hm#xigua_hm_seckill_log')->update($log_id, array('order_id' => $order_id, 'status' => 2, 'tkts' => 0, 'hxstatus' => 0));
            notification_add($secinfo['uid'],'system', "<a href=\"{url}\">".lang('plugin/xigua_hm', 'zsong').$touser.$secinfo['title'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_hm&ac=seckill_profile&logid='.$log_id),1);
            notification_add($touid,'system', "<a href=\"{url}\">".$note.'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_hm&ac=seckill_profile&logid='.$log_id),1);
        }else{
            C::t('#xigua_hm#xigua_hm_seckill_log')->update($log_id, array('status' => 2));
            $usr = getuserbyuid($_G['uid']);
            notification_add($secinfo['uid'],'system', "<a href=\"{url}\">".$usr['username'].lang('plugin/xigua_hm', 'lql').$secinfo['title'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_hm&ac=seckill_profile&logid='.$log_id),1);
            notification_add($touid,'system', "<a href=\"{url}\">".$note.'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_hm&ac=seckill_profile&logid='.$log_id),1);
        }
        hb_message(lang_hm('zscg',0), 'success', "$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid=$secid");
    }else{
        hb_message(lang_hm('kcbz',0), 'error');
    }

}else{
if(submitcheck('logid')){
        $v = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch($_GET['logid']);
        $sec = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_ids(array($v['secid']));
        $sec = $sec[$v['secid']];

        $r = DB::update('xigua_hm_seckill_log', array(
            'status' => 1,
            'hxstatus' => 6,
            'tkts' => TIMESTAMP
        ), array('id' => $_GET['logid'],
            'uid' => $_G['uid'],
            'hxstatus' => 0,
            'postinfo' => '',
        ));
        if($r){
            $hborder = C::t('#xigua_hb#xigua_hb_order')->fetch($v['order_id']);
            if($hborder['fromopenid'] && $hborder['baseprice']>0){
                try{
                    $out_trade_no = $v['order_id'];
                    $total_fee = ($hborder['baseprice']*100);
                    if($tp = ($v['price']*100) != $total_fee){
                        $total_fee = $tp;
                    }
                    $refund_fee = $total_fee;

                    $input = new WxPayRefundSF();

                    $input->SetOut_trade_no($out_trade_no);
                    $input->SetTotal_fee($total_fee);
                    $input->SetRefund_fee($refund_fee);
                    $refund_order = substr(md5($out_trade_no), 0,8).date("YmdHis");
                    $input->SetOut_refund_no($refund_order);
                    $input->SetOp_user_id(WxPayConfigSF::MCHID);

                    if($rett = WxPayApiSF::refund($input, 10)){
                        if($rett['result_code'] =='SUCCESS'){
                            DB::update('xigua_hm_seckill_log', array(
                                'refund' => lang_hm('tkdh',0).$refund_order.'<br>'.lang_hm('tkje',0).floatval($refund_fee/100).'<br>'.lang_hm('zfje',0).floatval($total_fee/100),
                            ), array('id' => $v['id']));
                        }else{
                            DB::update('xigua_hm_seckill_log', array(
                                'refund' => $rett['err_code'] . ':'.diconv($rett['err_code_des'], 'UTF-8', CHARSET).'<br>'.lang_hm('tkje',0).floatval($refund_fee/100).'<br>'.lang_hm('zfje',0).floatval($total_fee/100),
                            ), array('id' => $v['id']));
                        }
                    }
                }catch (Exception $e){
                    DB::update('xigua_hm_seckill_log', array(
                        'refund' => $e->getCode() . ':'.diconv($e->getMessage(), 'UTF-8', CHARSET).'<br>'.lang_hm('tkje',0).floatval($refund_fee/100).'<br>'.lang_hm('zfje',0).floatval($total_fee/100),
                    ), array('id' => $v['id']));
                }
            }else{
                C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                    'uid' => $_G['uid'],
                    'crts' =>TIMESTAMP,
                    'size' => $v['price'],
                    'note' => $sec['title'].lang_hm('tkcg',0).'<br>'.lang_hm('order_id', 0) . ':'.$v['order_id'],
                    'link' => "",
                ));
                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($_G['uid'], 'money', $v['price']);
            }
            //�˿�ʱ�����ϻ���
            if($_G['cache']['plugin']['xigua_hh']) {
                DB::query("DELETE FROM " . DB::table('xigua_hh_income') . " WHERE info LIKE '%{$v['order_id']}%' and reach<>1 LIMIT 2");
            }
        }

        hb_message(lang_hm('tkcg',0), 'success', 'reload');
    }
}