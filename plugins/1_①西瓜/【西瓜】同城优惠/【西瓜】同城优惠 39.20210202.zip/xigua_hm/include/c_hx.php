<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2018/4/12
 * Time: 15:43
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['do'] == 'showqr'){
    $shids = check_hm_manage();
    unset($shids[0]);
    $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_hm&ac=my_order&do=seckill&status=2&hx=-1&notaddr=1&sh=".implode('_', $shids);

    $repath = './source/plugin/xigua_hm/cache/';
    $qrfile = $repath . md5($url) . '.png';
    $abs_qrfile = DISCUZ_ROOT . $qrfile;

    if (!is_file($abs_qrfile)) {
        @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
        if(class_exists('QRcode')){
            QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
        }
    }
    $navtitle = lang_hm('tgewmgkhsm',0);
}elseif($_GET['do'] == 'hxsucceed'){

    $secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch($secid);
    $code = $_GET['code'];
    include template('xigua_hm:hxsucceed');
    exit;
}else{
    if(!$hm_config['allowdhm']){
        hb_message('error~', 'error');
    }
    if(submitcheck('code')){
        $code = $_GET['code'];
        if(!$code && !$_GET['code']){
            $error = lang_hm('dhmbcz',0);
            hb_message($error, 'error');
        }
        $loginfo = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_by_code($code);
        if(!$loginfo || $_G['uid'] != $loginfo['uid']){
            $error =  lang_hm('dhmbcz',0);
            hb_message($error, 'error');
        }
        if($loginfo['hxstatus']!=0){
            $error =  lang_hm('dhmysy',0);
            hb_message($error, 'error');
        }
        if($loginfo['endts'] && $loginfo['endts']<TIMESTAMP){
            $error =  lang_hm('dhqygq',0);
            hb_message($error, 'error');
        }
        if($loginfo['startts'] && $loginfo['startts']>TIMESTAMP){
            $error =  lang_hm('usestart',0).date('Y-m-d H:i:s', $loginfo['startts']);
            hb_message($error, 'error');
        }

        if($loginfo['order_id']) {
            $order_info = C::t('#xigua_hb#xigua_hb_order')->fetch($loginfo['order_id']);
            if(!$order_info['paystatus']){
                hb_message(lang_hb('wei',0), 'error');
            }
        }

        C::t('#xigua_hm#xigua_hm_seckill_log')->update_by_cond(array('code' => $code,), array(
            'hxstatus' => 1,
            'hxcrts' => TIMESTAMP,
            'hxuid' => $_G['uid'],
        ));
        C::t('#xigua_hm#xigua_hm_seckill')->incr($loginfo['secid'], 'hxnum', $loginfo['num']);
        $secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch($loginfo['secid']);

        if($loginfo['order_id']){
            C::t('#xigua_hm#xigua_hm_income')->initincome($order_info);
        }

        notification_add($loginfo['uid'],'system', "<a href=\"{url}\">".$order_info['subject'].' '.lang_hm('dhm',0).$loginfo['code'].' '.lang('plugin/xigua_hm', 'hxcg').'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_hm&ac=seckill_profile&logid='.$loginfo['id']),1);
        notification_add($secinfo['uid'],'system', "<a href=\"{url}\">".$order_info['subject'].' '.lang_hm('dhm',0).$loginfo['code'].' '.lang('plugin/xigua_hm', 'hxcg').'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_hm&ac=seckill_profile&logid='.$loginfo['id']),1);

        $error = lang_hm('sycg',0);

        hb_message($error, 'success', $SCRITPTNAME.'?id=xigua_hm&ac=hx&do=hxsucceed&code='.$code.'&secid='.$loginfo['secid']);

    }
}