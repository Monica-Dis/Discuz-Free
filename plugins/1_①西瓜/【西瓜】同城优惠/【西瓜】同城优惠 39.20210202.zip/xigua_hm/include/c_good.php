<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2017/12/10
 * Time: 22:12
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$navtitle = $cat_list_tmp[$_GET['hyid']]? $cat_list_tmp[$_GET['hyid']]['name'].$hm_config['good_navtitle'] : $hm_config['good_navtitle'];
$desc = $hm_config['good_desc'];

if(!checkmobile()){
    include template('xigua_hb:index');
    exit;
}

$cat_group = DB::fetch_all('select id,name,icon from %t WHERE goodindex=1 order by o ASC,id ASC', array(
    'xigua_hs_hangye',
), 'id');
$cat_list= $cat_group;
if($cat_list){
    array_unshift($cat_list, array('id' => 0, 'name' => lang_hm('all',0), 'icon' => 'source/plugin/xigua_hm/static/images/8.png'));
    array_unshift($cat_list, array('id' => -1, 'name' => lang_hb('shouye',0), 'icon' => 'source/plugin/xigua_hm/static/images/index.png'));
}
if(!$_GET['hyid']){
    $sec_group = array();
    foreach ($cat_group as $tmp_key => $item) {
        $tmp_key = intval($tmp_key);
        $sec_group_where = array('endtime=0', 'stype=\'seckill\'');
        $sec_group_where[] = " ( hangye_id1 =$tmp_key OR hangye_id2=$tmp_key ) ";
        $sec_group[$tmp_key] = C::t('#xigua_hm#xigua_hm_seckill')->fetch_all_by_where($sec_group_where, 0, 8, ' stock desc,displayorder desc, endtime desc');
    }
}

if (is_file(DISCUZ_ROOT . "source/plugin/xigua_hm/template/touch/$ac.php")) {
    include template('xigua_hm:good_index');
}
exit;