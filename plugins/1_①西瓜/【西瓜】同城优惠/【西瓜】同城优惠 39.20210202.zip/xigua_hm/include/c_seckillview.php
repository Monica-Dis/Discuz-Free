<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if ($config['sxlink']){
    $kflnk = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=$sh[uid]";
    $shmember = getuserbyuid($sh['uid']);
    $shavat = avatar($sh['uid'], 'middle', true);
    $kflnk = str_replace(array('{uid}', '{username}', '{avatar}'), array($sh['uid'], $shmember['username'], $shavat), $config['sxlink']);
    if(!(IN_QIANFAN||IN_MAGAPP) && ($config['magapp_secret'] || $config['hostname'])):
        $kflnk = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=$sh[uid]";
    endif;
}else{
    $kflnk = 'tel:'.$sh['tel'];
    $kflnk = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=$sh[uid]";
}