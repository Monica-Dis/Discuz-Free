<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2018/4/12
 * Time: 15:43
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$navtitle = lang_hm('xzhxfs',0);