<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_hm/function.php';
$hm_config = $_G['cache']['plugin']['xigua_hm'];
$stypes = array('youhui' => lang_hm('youhui', 0), 'daijin' => lang_hm('daijin', 0), 'zhekou' => lang_hm('zhekou', 0), 'seckill' => lang_hm('seckill', 0));
$statuss = array('0' => lang_hm('shwg', 0), '1' => lang_hm('ddsh', 0), '2' => lang_hm('ysj', 0), '3' => lang_hm('yxj', 0));
$svicerange = array();
foreach (explode("\n", trim($hm_config['svicerange'])) as $index => $item) {
	$svicerange[] = trim($item);
}
$aclist = array('index', 'seckill_view', 'my_seckill', 'seckill_view', 'seckill_li', 'seckill', 'my_order', 'buylog', 'buylog_li', 'stock_edit', 'seckilledit', 'seckill_profile', 'scan', 'coupon', 'income', 'income_li', 'inqr', 'hx', 'tk');
$aclist_login = array('seckill_profile', 'seckilledit', 'stock_edit', 'scan', 'seckill', 'income', 'income_li', 'tk');
$ac = $_GET['ac'];
$do = $_GET['do'];
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
$isself = in_array($ac, $aclist_login) || !(strpos($ac, 'my') === false) && !$_G['uid'];
if ($isself && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval(getgpc('page')));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$shid = intval($_GET['shid']);
$secid = intval($_GET['secid']);
$mysec = $_G['siteurl'] . $SCRITPTNAME . '?id=xigua_hm&ac=my_order&do=seckill';
$myo2 = $_G['siteurl'] . $SCRITPTNAME . ('?id=xigua_hm&ac=seckill_profile' . $urlext . '&logid=');
$checkmobile = array_flip(unserialize($hm_config['checkmobile']));
if ($hm_config['paywait'] <= 30) {
	$hm_config['paywait'] = 30;
}
C::t('#xigua_hm#xigua_hm_seckill')->restore_stock();
$kaquan_stype = array('youhui', 'daijin', 'zhekou');
$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$url = rtrim($url, '/') . '/';
switch ($ac) {
	case 'seckilledit':
		if ($_G['cache']['plugin']['xigua_hs']) {
			$where = array();
			$where[] = 'uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP;
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
		}
		$old_data = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_id($secid);
		if ($old_data['stype'] != 'seckill') {
			$kaquan = 1;
		}
		$navtitle = lang_hm('bjhd', 0);
		include template('xigua_hm:my_seckill');
		break;
	case 'stock_edit':
		if (submitcheck('formhash')) {
			$data = array();
			if ($do == 'del') {
				$data['status'] = 3;
				$rs = C::t('#xigua_hm#xigua_hm_seckill')->update_G($secid, $data);
				hb_message(lang_hm('xjcg', 0), 'success', $SCRITPTNAME . '?id=xigua_hm&ac=my_seckill');
			} elseif ($do == 'shangjia') {
				$data['status'] = 2;
				$rs = C::t('#xigua_hm#xigua_hm_seckill')->update_G($secid, $data);
				hb_message(lang_hm('sjcg', 0), 'success', $SCRITPTNAME . '?id=xigua_hm&ac=my_seckill');
			} else {
				$data['stock'] = intval($_GET['allnum']);
				if ($data['stock'] < 0) {
					hb_message(lang_hm('kcbnfs', 0), 'error');
				}
				$old_data = C::t('#xigua_hm#xigua_hm_seckill')->fetch($secid);
				if ($data['stock'] > $old_data['allnum']) {
					hb_message(lang_hm('kcbndy', 0) . $old_data['allnum'], 'error');
				}
				$rs = C::t('#xigua_hm#xigua_hm_seckill')->update_G($secid, $data);
				hb_message(lang_hm('xgcg', 0), 'success');
			}
		}
		break;
	case 'index':
		$topnavslider = array();
		$topnavslider = hb_parse_set($hm_config['loopbanner'], 1);
		$indexstype = hm_set_parse($hm_config['indexstype']);
		$index_count = count($indexstype);
		$cat_list_tmp = DB::fetch_all('select id,name,icon from %t WHERE miao=1 order by o ASC,id ASC', array('xigua_hs_hangye'), 'id');
		$cat_list = array_values($cat_list_tmp);
		$toutiao = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where(array('status=2'), 0, 8, 'id desc', '*');
		$secids = array();
		foreach ($toutiao as $index => $item) {
			$secids[$item['secid']] = $item['secid'];
		}
		if (!$_GET['stype']) {
			$_GET['stype'] = 'seckill';
		}
		$pfix = $stypes[$_GET['stype']];
		$navtitle = $hm_config[$_GET['stype'] . '_title'];
		$desc = $hm_config[$_GET['stype'] . '_desc'];
		if (!$navtitle) {
			$navtitle = $pfix . '_' . $config['tname'];
			$desc = $hm_config['pindao'];
		}
		if ($_GET['keyword']) {
			$navtitle .= ' ' . $_GET['keyword'];
			$desc .= ' ' . $_GET['keyword'];
		}
		$secs = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_ids($secids, 'stype,title,id', 'id');
		if ($do == 'good' && is_file(DISCUZ_ROOT . 'source/plugin/xigua_hm/include/c_good.php')) {
			include_once DISCUZ_ROOT . 'source/plugin/xigua_hm/include/c_good.php';
		}
		break;
	case 'seckill_view':
		$v = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_id($secid);
		$dft = C::t('#xigua_hb#xigua_hb_user_addr')->fetch_dft($_G['uid']);
		$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid'], 0);
		$lgwhr = array('secid=' . $secid, 'status=2');
		if ($hm_config['showreal']) {
			$v['logs'] = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where($lgwhr, $start_limit, $lpp, 'id DESC', '*');
			$v['logs_count'] = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_count_by_page($lgwhr);
		}
		$has_buycount = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_sum_by_page(array('uid=' . $_G['uid'], 'status=2', 'secid=' . $secid));
		$v['old_maxnum'] = $v['maxnum'];
		if ($v['maxnum'] > 0) {
			$v['maxnum'] -= $has_buycount;
		}
		$navtitle = $v['title'];
		$desc = $v['tuijian'];
		$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
		$custom_side = array($SCRITPTNAME . '?id=xigua_hm&ac=my_order&do=seckill' . $urlext, lang_hm('wddd', 0));
		$get_where = array('uid=' . $_G['uid'], 'pay_endts>' . TIMESTAMP, 'secid=' . $secid, 'status=0');
		$get = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where($get_where, 0, 1);
		if ($get) {
			$order_id = $get['order_id'];
			$rl = urlencode($get['id'] ? $myo2 . $get['id'] : $mysec);
			$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
		}
		$geting = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_count_by_page(array('pay_endts>' . TIMESTAMP, 'secid=' . $secid));
		if ($v['stock'] <= 0) {
			$v['end'] = 1;
		}
		$hidebackfont = 1;
		$followed = C::t('#xigua_hs#xigua_hs_follow')->fetch_follow_by_shid_uid($v['shid'], $_G['uid']);
		if ($v['stype'] != 'seckill') {
			$hidebackfont = 0;
			$navtitle = $v['title'];
			if ($_G['uid'] > 0) {
				$had = C::t('#xigua_hm#xigua_hm_seckill_log')->check_if_get($secid, $_G['uid']);
			}
			$hide_nav = 1;
			include template('xigua_hm:quan_view');
			exit(0);
		}
		break;
	case 'seckill':
		$get_where = array('uid=' . $_G['uid'], 'pay_endts>' . TIMESTAMP, 'secid=' . $secid, 'status=0');
		$get = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where($get_where, 0, 1);
		if ($get) {
			$order_id = $get['order_id'];
		} else {
			$num = intval($_GET['num']);
			$addrid = intval($_GET['addrid']);
			$note = strip_tags($_GET['note']);
			if (!submitcheck('formhash')) {
				hb_message('formhash error', 'error');
			}
			if ($num < 1) {
				hb_message(lang_hm('slcw', 0), 'error');
			}
			$v = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_stock($secid, $num);
			if ($v['end']) {
				hb_message(lang_hm('qgjs', 0), 'error');
			}
			if ($v['not_start']) {
				hb_message(lang_hm('qgwks', 0), 'error');
			}
			if ($v['ggary']) {
				$gginput = $_GET['gginput'];
				if (!$gginput || !$v['ggary'][$gginput]) {
					hb_message(lang_hm('ggerror', 0), 'error');
				}
				$gglev = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_sum_by_page(array('status=2 AND ggname=\'' . daddslashes($gginput) . '\' AND secid=' . $secid));
				if ($v['ggary'][$gginput][1] - $gglev < $num) {
					hb_message(lang_hm('ggerror1', 0) . $num . lang_hm('fen', 0), 'error');
				}
				if ($v['ggary'][$gginput][2] > 0) {
					$v['price'] = $v['ggary'][$gginput][2];
				}
				if ($_G['cache']['plugin']['xigua_hk']) {
					$card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G['uid']);
					if ($card && $v['ggary'][$gginput][3] > 0) {
						$v['price'] = $v['ggary'][$gginput][3];
					}
				}
			}
			if (!$v) {
				hb_message(lang_hm('kcbz', 0), 'error');
			}
			if ($v['xiajia']) {
				hb_message(lang_hm('spyxj', 0), 'error');
			}
			if ($v['shen']) {
				hb_message(lang_hm('spshz', 0), 'error');
			}
			$has_buycount = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_sum_by_page(array('uid=' . $_G['uid'], 'status=2', 'secid=' . $secid));
			$has_buycount = abs($has_buycount);
			if ($v['maxnum'] > 0 && $has_buycount + $num > $v['maxnum']) {
				hb_message(lang_hm('cgxg', 0), 'error');
			}
			$updatestock = C::t('#xigua_hm#xigua_hm_seckill')->update_stock($secid, $num);
			if ($updatestock) {
				$totalprice = $v['price'] * $num + $v['fee'];
				$title = $v['title'] . $num . lang_hm('fen', 0) . ($gginput ? ' ' . $gginput : '');
				$pay_end = TIMESTAMP + $hm_config['paywait'];
				$secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_id($secid);
				$backjifen = 0;
				if ($secinfo['dimoney'] > 0 && $secinfo['cnum'] > 0 && getuserprofile('extcredits' . $config['credit_type']) > $secinfo['cnum'] * $num) {
					$totalprice -= $secinfo['dimoney'] * $num;
					$GLOBALS['backjifen'] = $secinfo['cnum'] * $num;
					$GLOBALS['backjifen_type'] = $config['credit_type'];
					$GLOBALS['newtouid'] = $secinfo['uid'];
				}
				$log_id = C::t('#xigua_hm#xigua_hm_seckill_log')->insert(array('secid' => $secid, 'shid' => $secinfo['shid'], 'stype' => $secinfo['stype'], 'uid' => $_G['uid'], 'order_id' => '', 'num' => $num, 'price' => $totalprice, 'note' => $note, 'crts' => TIMESTAMP, 'endts' => $v['usetime'], 'startts' => TIMESTAMP + $v['usetime_start'], 'status' => 0, 'addrid' => $addrid, 'ggname' => $gginput, 'code' => hm_random_code($_G['uid']), 'pay_endts' => $pay_end, 'stid' => intval($_GET['st'])), true);
				if ($totalprice > 0) {
					$insxf = $totalprice;
					if ($hm_config['hhrmethod'] == 2) {
						if (is_file(DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php')) {
							include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
							$shdata = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($secinfo['shid']);
							$vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
							$zhangqi = intval(abs($vipinfo['zhangqi']));
							$insxf = intval(abs($vipinfo['insxf'])) / 100;
							$sxfee = round($insxf * $totalprice, 2);
						}
					}
					$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_seckill', array('data' => array($v, array('num' => $num, 'item_price' => $v['price'], 'price' => $totalprice, 'note' => $note, 'log_id' => $log_id, 'sxfee' => $sxfee)), 'callback' => array('file' => 'source/plugin/xigua_hm/function.php', 'method' => 'hm_callback_seckill_'), 'location' => $myo2 . $log_id, 'referer' => $SCRITPTNAME . '?id=xigua_hm&ac=seckill_view&secid=' . $secid, 'tip' => $v['dingprice'] > 0 ? lang_hm('tx', 0) . ($v['yuanprice'] - $v['price']) * $num . lang_hm('yuan', 0) : ''), $pay_end);
					C::t('#xigua_hm#xigua_hm_seckill_log')->update($log_id, array('order_id' => $order_id));
					$rl = urlencode($log_id ? $myo2 . $log_id : $mysec);
					$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
					hb_message(lang_hm('jumppay', 0), 'loading', $jumpurl);
				} else {
					C::t('#xigua_hm#xigua_hm_seckill_log')->update($log_id, array('status' => 2));
					$usr = getuserbyuid($_G['uid']);
					notification_add($secinfo['uid'], 'system', '<a href="{url}">' . $usr['username'] . lang('plugin/xigua_hm', 'lql') . $secinfo['title'] . '</a>', array('url' => $_G['siteurl'] . 'plugin.php?id=xigua_hm&ac=seckill_profile&logid=' . $log_id), 1);
					hb_message(lang_hm('lqcg', 0), 'success', $SCRITPTNAME . '?id=xigua_hm&ac=seckill_profile&logid=' . $log_id);
				}
			} else {
				hb_message(lang_hm('kcbz', 0), 'error');
			}
		}
		break;
	case 'seckill_li':
		$field = '*';
		$order_by = '';
		if (in_array($_GET['stype'], array('seckill', 'youhui', 'daijin', 'zhekou', 'quan'))) {
			$stype = $_GET['stype'];
		} else {
			$stype = 'seckill';
		}
		if ($stype == 'quan') {
			if ($_GET['is_my'] && $_G['uid'] > 0) {
				$order_by = 'id desc';
				$where = array('stype<>\'seckill\'', 'uid=' . $_G['uid']);
				if ($_GET['kucun'] == 1) {
					$where[] = 'stock>0';
				} elseif ($_GET['kucun'] == 2) {
					$where[] = '(stock=0 or endtime<' . TIMESTAMP . ')';
				} elseif ($_GET['kucun'] == 3) {
					$where[] = 'status=1';
				}
			} else {
				$where = array('stype<>\'seckill\'');
				$order_by = ' displayorder desc, id desc';
			}
		} else {
			$where = array('stype=\'' . $stype . '\'');
			if ($_GET['is_my'] && $_G['uid'] > 0) {
				$order_by = 'id desc';
				if ($_GET['offline'] == 1) {
					$where[] = 'uid=' . $_G['uid'] . ' and status<>3 and endtime<>\'0\' AND endtime<' . TIMESTAMP;
				} elseif ($_GET['offline'] == 2) {
					$where[] = 'uid=' . $_G['uid'] . ' and status=3';
				} else {
					if ($_GET['shen']) {
						$where[] = 'uid=' . $_G['uid'] . ' and status=1';
					} else {
						$where[] = 'uid=' . $_G['uid'] . ' and status=2 and (endtime=0 OR endtime>=' . TIMESTAMP . ')';
					}
				}
			} else {
				$order_by = ' displayorder desc, id desc';
			}
		}
		if ($do == 'good') {
			$where[] = 'endtime=0';
			if ($hyid = $_GET['hyid']) {
				$where[] = ' ( hangye_id1 =' . $hyid . ' OR hangye_id2=' . $hyid . ' ) ';
			}
		}
		if ($cat_id = intval($_GET['cat_id'])) {
			$where[] = '(hangye_id1=' . $cat_id . ' or hangye_id2=' . $cat_id . ')';
		}
		switch ($_GET['dtp']) {
			case 'ing':
				$where[] = ' (status=2 AND stock>0 AND (endtime=0 OR endtime>' . TIMESTAMP . ')) ';
				break;
			case 'wangqi':
				$where[] = ' (status=2 AND ((endtime>0 AND endtime<' . TIMESTAMP . ') OR stock<=0)) ';
				break;
			default:
				if (!$_GET['is_my']) {
					$where[] = 'status=2';
					if (!$hm_config['showend']) {
						$where[] = ' (endtime=0 OR endtime>=' . TIMESTAMP . ') ';
					}
				}
		}
		if ($_GET['shid']) {
			$where[] = ' shid=' . intval($_GET['shid']);
		}
		$list = C::t('#xigua_hm#xigua_hm_seckill')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);
		if ($_G['uid'] > 0) {
			$secids = array();
			foreach ($list as $index => $item) {
				$secids[] = intval($item['id']);
			}
			if ($secids) {
				$hads = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where(array('uid=' . $_G['uid'] . ' and status=2 AND secid in(' . implode(',', $secids) . ')'), 0, $lpp, '', 'id,secid', 'secid');
			}
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_hm:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'my_seckill':
		if (submitcheck('formhash') && $do == 'add') {
			$data = $srg = $append_img = $append_text = array();
			$form = $_GET['form'];
			$required = array('title', 'shname', 'starttime', 'jieshao');
			foreach ($required as $index => $item) {
				$form[$item] = trim($form[$item]);
				if (!$form[$item]) {
					if ($form['stype'] == 'seckill' || $item != 'price') {
						hb_message(lang_hm($item . '_tip', 0), 'error');
					}
				}
			}
			if (!$form['marketprice']) {
				$form['marketprice'] = $form['price'];
			}
			if ($form['fee_type'] == 1) {
				$form['fee'] = 0;
			}
			if ($form['dingprice'] > 0 && $form['fee'] > 0) {
				hb_message(lang_hm('psfsqxz', 0), 'error');
			}
			$allnum = intval($form['allnum']);
			if (!($sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']))) {
				hb_message(lang_hm('shname_tip', 0), 'error');
			}
			if ($form['marketprice'] < $form['price']) {
				hb_message(lang_hm('bnda', 0), 'error');
			}
			foreach ($svicerange as $index => $item) {
				if ($form['tagid'][$index]) {
					$srg[] = $item;
				}
			}
			foreach ($form['append_img'] as $index => $item) {
				$append_img[] = $item;
				$append_text[] = $form['append_text'][$index];
			}
			$up = $form['id'] > 0;
			if ($up) {
				$data['upts'] = TIMESTAMP;
			} else {
				$data['uid'] = $_G['uid'];
			}
			$data['stype'] = $form['stype'];
			$data['gongkai'] = intval($form['gongkai']);
			$data['allowtk'] = intval($form['allowtk']);
			$data['fanwei'] = $form['fanwei'];
			$data['zhekourate'] = intval($form['zhekourate']);
			$data['underline'] = $form['underline'];
			$data['title'] = $form['title'];
			$data['starttime'] = intval(strtotime($form['starttime']));
			$data['endtime'] = intval(strtotime($form['endtime']));
			$data['shname'] = $sh['name'];
			$data['shid'] = $sh['shid'];
			$data['hangye_id1'] = $sh['hangye_id1'];
			$data['hangye_id2'] = $sh['hangye_id2'];
			$data['marketprice'] = $form['marketprice'];
			$data['price'] = $form['price'];
			$data['appprice'] = $form['appprice'];
			$data['hkprice'] = $form['hkprice'];
			$data['allnum'] = $allnum;
			$data['stock'] = $allnum;
			$data['maxnum'] = $form['maxnum'];
			$data['srange'] = implode('	', $srg);
			$data['tuijian'] = $form['tuijian'];
			$data['biaoqian'] = implode('	', explode(' ', $form['biaoqian']));
			$data['jieshao'] = $form['jieshao'];
			$data['append_img'] = serialize($append_img);
			$data['append_text'] = serialize($append_text);
			$data['album'] = serialize($form['album']);
			$data['fee'] = round($form['fee'], 2);
			$data['fee_type'] = $form['fee_type'];
			$data['dingprice'] = round($form['dingprice'], 2);
			$data['yuyue'] = intval($form['yuyue']);
			$data['usetime'] = strtotime($form['usetime']);
			$data['usetime_start'] = intval($form['usetime_start']) * 60;
			$data['fansqr'] = $form['fansqr'][0];
			$data['jifenrate'] = $form['jifenrate'];
			$data['fszx'] = $form['fszx'];
			$data['crts'] = TIMESTAMP;
			$jp = $SCRITPTNAME . '?id=xigua_hm&ac=my_seckill';
			if ($hm_config['s_needshen']) {
				$data['status'] = 1;
				$jp .= '&shen=1';
			}
			if ($up) {
				$rs = C::t('#xigua_hm#xigua_hm_seckill')->update_G($form['id'], $data);
			} else {
				$data['stid'] = intval($_GET['st']);
				$data['status'] = 2;
				if ($hm_config['s_needshen']) {
					$data['status'] = 1;
				}
				$data['upts'] = $data['crts'];
				$rs = C::t('#xigua_hm#xigua_hm_seckill')->insert($data);
			}
			if ($rs) {
				if ($form['stype'] != 'seckill') {
					hb_message(lang_hm('czcg', 0), 'success', $SCRITPTNAME . '?id=xigua_hm&ac=my_seckill&do=quan' . $urlext);
				} else {
					hb_message(lang_hm('czcg', 0), 'success', $SCRITPTNAME . '?id=xigua_hm&ac=my_seckill' . $urlext);
				}
			}
		} else {
			$stype = '';
			if ($do == 'quan') {
				$navtitle = lang_hm('kqgl', 0);
				$stype = 'quan';
				$kaquan = 1;
			} else {
				$navtitle = lang_hm('qggl', 0);
				$stype = 'seckill';
			}
			if ($_G['cache']['plugin']['xigua_hs']) {
				$where = array();
				$where[] = 'uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP;
				$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
				$vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0, 99, 'id');
				foreach ($sh as $tmp_k => $tmp_v) {
					if ($kaquan == 1) {
						if (!in_array('youhui', $vips[$tmp_v['viptype']]['access'])) {
							$sh[$tmp_k] = array();
						}
					} else {
						if (!in_array('qianggou', $vips[$tmp_v['viptype']]['access'])) {
							$sh[$tmp_k] = array();
						}
					}
				}
				if (!$sh) {
					dheader('Location: ' . $SCRITPTNAME . '?id=xigua_hs&ac=enter&from=hm' . $urlext);
				}
			}
			if (!$hide_nav) {
				$custom_side = array('javascript:full_input(this, 0);', lang_hm('pub', 0));
			}
			$back_to_overwrite = $SCRITPTNAME . '?id=xigua_hs&ac=shcenter';
		}
		break;
	case 'buylog':
		$navtitle = lang_hm('yqgd', 0);
		break;
	case 'buylog_li':
		$lgwhr = array('secid=' . $secid, 'status=2');
		$list = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where($lgwhr, $start_limit, $lpp, 'id DESC');
		include template('xigua_hb:header_ajax');
		include template('xigua_hm:buylog_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'my_order':
		$custom_side = array($SCRITPTNAME . '?id=xigua_hb&ac=my', lang_hb('wode', 0));
		switch ($do) {
			case 'seckill':
				$navtitle = lang_hm('wddd', 0);
				include template('xigua_hm:my_order_' . $do);
				exit(0);
				break;
			case 'seckill_li':
				if ($_GET['manage'] == 1) {
					$manage = 1;
					$shids = check_hm_manage();
					$where = array('shid in (' . implode(',', $shids) . ')');
					$order_by = 'id DESC';
					if ($_GET['stype'] == 'quan') {
						$where[] = 'stype<>\'seckill\'';
					} else {
						$where[] = 'stype=\'seckill\'';
					}
				} else {
					$where = array('uid=' . $_G['uid']);
					if ($_GET['status']) {
						$status = intval($_GET['status']);
						if ($status == 0 - 1) {
							$status = '0';
						}
						$where[] = 'status=' . $status;
					}
					if ($_GET['hx']) {
						$hx = intval($_GET['hx']);
						if ($hx == 0 - 1) {
							$hx = '0';
						}
						$where[] = 'hxstatus=' . $hx;
					}
					if ($_GET['notaddr']) {
						$where[] = 'addrid=0';
					}
					if ($shs = array_filter(explode('_', trim($_GET['sh'])))) {
						$shs = implode(',', dintval($shs, 1));
						$where[] = 'shid in (' . $shs . ')';
					}
					$order_by = 'id DESC';
				}
				if ($_GET['shid']) {
					$where[] = 'shid=' . intval($_GET['shid']);
				}
				if ($_GET['confirm']) {
					$where[] = '(tkts=\'\' and postinfo=\'\' and hxstatus=0 and (endts=0 or endts>' . TIMESTAMP . '))';
				}
				$list = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where($where, $start_limit, $lpp, $order_by);
				$secids = array();
				foreach ($list as $index => $item) {
					$secids[] = $item['secid'];
				}
				foreach ($list as $index => $item) {
					if ($item['pay_endts'] >= TIMESTAMP) {
						$order_id = $item['order_id'];
						$rl = urlencode($item['id'] ? $myo2 . $item['id'] : $mysec);
						$list[$index]['jumpurl'] = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
					}
				}
				$seclist = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_ids($secids);
				include template('xigua_hb:header_ajax');
				include template('xigua_hm:my_order_' . $do);
				include template('xigua_hb:footer_ajax');
				break;
			case 'manage':
				$back_to_overwrite = $SCRITPTNAME . '?id=xigua_hs&ac=shcenter';
				$navtitle = lang_hm('gldd', 0);
				include template('xigua_hm:my_order_manage');
				exit(0);
				break;
			case 'fahuo':
				if (submitcheck('lid')) {
					$cpny = trim($_GET['company']);
					$danhao = trim($_GET['danhao']);
					$logid = intval($_GET['lid']);
					$loginfo = $v = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch($logid);
					$shids = check_hm_manage();
					if (!in_array($v['shid'], $shids)) {
						hb_message(lang_hm('wqx', 0), 'error');
					}
					if (!$cpny) {
						hb_message(lang_hm('qtxkd', 0), 'error');
					}
					if (!$danhao) {
						hb_message(lang_hm('qtxdh', 0), 'error');
					}
					C::t('#xigua_hm#xigua_hm_seckill_log')->update($logid, array('hxstatus' => 1, 'hxcrts' => TIMESTAMP, 'hxuid' => $_G['uid'], 'postinfo' => serialize(array('company' => $cpny, 'danhao' => $danhao))));
					if ($v['order_id']) {
						$order_info = C::t('#xigua_hb#xigua_hb_order')->fetch($v['order_id']);
						C::t('#xigua_hm#xigua_hm_income')->initincome($order_info);
					}
					notification_add($loginfo['uid'], 'system', '<a href="{url}">' . $order_info['subject'] . ' ' . lang('plugin/xigua_hm', 'fhcg') . ' ' . lang_hm('kdgs', 0) . ':' . $cpny . ',' . lang_hm('dh', 0) . ':' . $danhao . '</a>', array('url' => $_G['siteurl'] . 'plugin.php?id=xigua_hm&ac=seckill_profile&logid=' . $logid), 1);
					notification_add($_G['uid'], 'system', '<a href="{url}">' . $order_info['subject'] . ' ' . lang('plugin/xigua_hm', 'fhcg') . ' ' . lang_hm('kdgs', 0) . ':' . $cpny . ',' . lang_hm('dh', 0) . ':' . $danhao . '</a>', array('url' => $_G['siteurl'] . 'plugin.php?id=xigua_hm&ac=seckill_profile&logid=' . $logid), 1);
					hb_message(lang_hm('fhcg', 0), 'success', 'reload');
				}
				break;
			default:
				$navtitle = lang_hm('wddd', 0);
		}
		break;
	case 'seckill_profile':
		$logid = intval($_GET['logid']);
		$v = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch($logid);
		$shids = check_hm_manage();
		$admin_show = 1;
		if (in_array($v['shid'], $shids)) {
			$admin_show = 1;
		} else {
			if ($v['uid'] != $_G['uid']) {
				$error = lang_hm('wqx', 0);
				include template('xigua_hm:error');
				exit(0);
			}
		}
		$v = table_xigua_hm_seckill_log::prepare($v);
		$sec = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_ids(array($v['secid']));
		$v['sec'] = C::t('#xigua_hm#xigua_hm_seckill')->prepare($sec[$v['secid']]);
		$v['sh'] = $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($v['sec']['shid']);
		$codeurl = hm_make($v['code']);
		$navtitle = lang_hm('ddxq', 0);
		if ($v['addrid']) {
			$dft = C::t('#xigua_hb#xigua_hb_user_addr')->fetch($v['addrid']);
		}
		$v['user'] = DB::fetch_first('select * from %t where uid=%d', array('common_member', $v['uid']));
		$order = DB::fetch_all('SELECT * FROM %t WHERE order_id =%s ', array('xigua_hb_order', $v['order_id']), 'order_id');
		$rl = urlencode($logid ? $myo2 . $logid : $mysec);
		$v['jumpurl'] = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $v['order_id'] . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
		$custom_side = array($SCRITPTNAME . '?id=xigua_hm&ac=my_order&do=seckill' . $urlext, lang_hm('wddd', 0));
		break;
	case 'scan':
		$navtitle = lang_hm('hxdd', 0);
		if ($do == 'scan_li') {
			$shids = check_hm_manage();
			$where = array('shid in (' . implode(',', $shids) . ') and hxstatus=1');
			$list = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where($where, $start_limit, $lpp, 'id DESC');
			$uids = array();
			foreach ($list as $k => $v) {
				$uids[] = $v['hxuid'];
			}
			$users = DB::fetch_all('SELECT username,uid FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
			foreach ($list as $rk => $rv) {
				$list[$rk]['hxuser'] = $users[$rv['hxuid']];
			}
			include template('xigua_hb:header_ajax');
			include template('xigua_hm:scan_li');
			include template('xigua_hb:footer_ajax');
		} else {
			if (submitcheck('formhash') && $do == 'add' || $_GET['code']) {
				$code = $_GET['form']['code'];
				if (!$code && !$_GET['code']) {
					$error = lang_hm('dhmbcz', 0);
					if ($toast) {
						include template('xigua_hm:error');
						exit(0);
					}
					hb_message($error, 'error');
				}
				if (!$code) {
					$toast = 1;
					$code = $_GET['code'];
				}
				$loginfo = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_by_code($code);
				if (!$loginfo) {
					$error = lang_hm('dhmbcz', 0);
					if ($toast) {
						include template('xigua_hm:error');
						exit(0);
					}
					hb_message($error, 'error');
				}
				if ($loginfo['endts'] && $loginfo['endts'] < TIMESTAMP) {
					$error = lang_hm('dhqygq', 0);
					if ($toast) {
						include template('xigua_hm:error');
						exit(0);
					}
					hb_message($error, 'error');
				}
				if ($loginfo['startts'] && $loginfo['startts'] > TIMESTAMP) {
					$error = lang_hm('usestart', 0) . date('Y-m-d H:i:s', $loginfo['startts']);
					if ($toast) {
						include template('xigua_hm:error');
						exit(0);
					}
					hb_message($error, 'error');
				}
				if ($loginfo['hxstatus'] != 0) {
					$error = lang_hm('dhmysy', 0);
					if ($toast) {
						include template('xigua_hm:error');
						exit(0);
					}
					hb_message($error, 'error');
				}
				$secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch($loginfo['secid']);
				$access = 0;
				if (IS_ADMINID) {
					$access = 1;
				}
				if (!$access) {
					$yuaninfo = C::t('#xigua_hs#xigua_hs_yuan')->fetch_yuan_by_shid_uid($secinfo['shid'], $_G['uid']);
					if ($yuaninfo) {
						$access = 1;
					}
				}
				if (!$access) {
					if ($coki = authcode(getcookie('hstax' . $secinfo['shid']), 'DECODE')) {
						$shv = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($secinfo['shid'], 0);
						if ($shv['hxpwd'] == $coki) {
							$access = 1;
						}
					}
				}
				if (!$access) {
					$error = lang_hs('qsrhxmm', 0);
					if ($toast) {
						include template('xigua_hm:error');
						exit(0);
					}
					hb_message($error, 'error', 'javascript:input_hx_mm(' . $secinfo['shid'] . ');');
				}
				if ($loginfo['order_id']) {
					$order_info = C::t('#xigua_hb#xigua_hb_order')->fetch($loginfo['order_id']);
					if (!$order_info['paystatus']) {
						hb_message(lang_hb('wei', 0), 'error');
					}
				}
				if (!$_GET['quren'] && $toast) {
					$error = lang_hm('queren', 0);
					$loginfo = table_xigua_hm_seckill_log::prepare($loginfo);
					$loginfo['user'] = DB::fetch_first('select * from %t where uid=%d', array('common_member', $loginfo['uid']));
					$__profile = C::t('#xigua_hb#xigua_hb_user')->fetch($loginfo['uid']);
					if (!$__profile['mobile']) {
						$__profile = C::t('common_member_profile')->fetch($loginfo['uid']);
					}
					if ($toast) {
						include template('xigua_hm:error');
						exit(0);
					}
				}
				C::t('#xigua_hm#xigua_hm_seckill_log')->update_by_cond(array('code' => $code), array('hxstatus' => 1, 'hxcrts' => TIMESTAMP, 'hxuid' => $_G['uid']));
				C::t('#xigua_hm#xigua_hm_seckill')->incr($loginfo['secid'], 'hxnum', $loginfo['num']);
				$secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch($loginfo['secid']);
				if ($loginfo['order_id']) {
					C::t('#xigua_hm#xigua_hm_income')->initincome($order_info);
				}
				notification_add($loginfo['uid'], 'system', '<a href="{url}">' . $order_info['subject'] . ' ' . lang_hm('dhm', 0) . $loginfo['code'] . ' ' . lang('plugin/xigua_hm', 'hxcg') . '</a>', array('url' => $_G['siteurl'] . 'plugin.php?id=xigua_hm&ac=seckill_profile&logid=' . $loginfo['id']), 1);
				notification_add($secinfo['uid'], 'system', '<a href="{url}">' . $order_info['subject'] . ' ' . lang_hm('dhm', 0) . $loginfo['code'] . ' ' . lang('plugin/xigua_hm', 'hxcg') . '</a>', array('url' => $_G['siteurl'] . 'plugin.php?id=xigua_hm&ac=seckill_profile&logid=' . $loginfo['id']), 1);
				$error = lang_hm('hxcg', 0);
				if ($toast) {
					include template('xigua_hm:error');
					exit(0);
				}
				if ($_GET['back']) {
					hb_message($error, 'success', $SCRITPTNAME . '?id=xigua_hm&ac=my_order&do=manage');
				}
				hb_message($error, 'success');
			} else {
				if ($_GET['logid']) {
					$logid = intval($_GET['logid']);
					$loginfo = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch($logid);
					$dftcode = $loginfo['code'];
				}
			}
		}
		break;
	case 'income':
		$back_to_overwrite = $SCRITPTNAME . '?id=xigua_hm&ac=my_order&do=manage';
		$navtitle = lang_hm('rzjl', 0);
		$custom_side = array($SCRITPTNAME . '?id=xigua_hm&ac=my_order&do=manage', lang_hm('dd', 0));
		break;
	case 'income_li':
		$uid = intval($_G['uid']);
		$where[] = 'uid=' . $uid;
		if ($do == 'reach') {
			$where[] = 'indate<=\'' . date('Y-m-d', TIMESTAMP) . '\'';
			$where[] = 'reach=1';
		} else {
			$where[] = 'reach<>1';
		}
		$list = C::t('#xigua_hm#xigua_hm_income')->fetch_u_order($where, $start_limit, $lpp);
		include template('xigua_hb:header_ajax');
		include template('xigua_hm:income_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'inqr':
		include_once DISCUZ_ROOT . ('source/plugin/xigua_hm/include/c_' . $ac . '.php');
		break;
	case 'hx':
		include_once DISCUZ_ROOT . 'source/plugin/xigua_hm/include/c_hx.php';
		break;
	case 'tk':
		include_once DISCUZ_ROOT . 'source/plugin/xigua_hm/include/c_tk.php';
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_hm/template/touch/' . $ac . '.php'))) {
	include template('xigua_hm:' . $ac);
}