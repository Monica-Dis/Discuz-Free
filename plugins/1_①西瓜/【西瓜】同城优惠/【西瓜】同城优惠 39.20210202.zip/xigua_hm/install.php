<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_hm_seckill_log` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `secid` int(11) NOT NULL,
 `stype` varchar(20) NOT NULL,
 `shid` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `order_id` char(24) NOT NULL,
 `num` int(11) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `note` varchar(800) NOT NULL,
 `crts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `addrid` int(11) NOT NULL,
 `code` varchar(200) NOT NULL,
 `status` int(11) NOT NULL,
 `hxstatus` int(1) NOT NULL,
 `pay_endts` int(11) NOT NULL,
 `hxcrts` int(11) NOT NULL,
 `hxuid` int(11) NOT NULL,
 `postinfo` varchar(2000) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `code` (`code`),
 KEY `secid` (`secid`),
 KEY `order_id` (`order_id`),
 KEY `endts` (`endts`),
 KEY `hxstatus` (`hxstatus`),
 KEY `shid` (`shid`),
 KEY `stype` (`stype`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hm_seckill` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `stype` varchar(20) NOT NULL,
 `status` int(11) NOT NULL DEFAULT '0',
 `uid` int(11) NOT NULL,
 `title` varchar(256) NOT NULL,
 `shid` int(11) NOT NULL,
 `hangye_id1` int(11) NOT NULL,
 `hangye_id2` int(11) NOT NULL,
 `shname` varchar(256) NOT NULL,
 `allnum` int(11) NOT NULL,
 `maxnum` int(11) NOT NULL,
 `stock` int(11) unsigned NOT NULL,
 `usetime` int(11) NOT NULL,
 `starttime` int(11) NOT NULL,
 `endtime` int(11) NOT NULL,
 `marketprice` decimal(10,2) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `dingprice` decimal(10,2) NOT NULL,
 `fee` decimal(10,2) NOT NULL,
 `srange` varchar(1024) NOT NULL,
 `tuijian` varchar(256) NOT NULL,
 `biaoqian` varchar(512) NOT NULL,
 `jieshao` text NOT NULL,
 `album` text NOT NULL,
 `append_img` text NOT NULL,
 `append_text` text NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `yuyue` int(11) NOT NULL,
 `gongkai` int(1) NOT NULL,
 `underline` decimal(10,2) NOT NULL,
 `fanwei` varchar(200) NOT NULL,
 `zhekourate` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `hxnum` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `status` (`status`),
 KEY `upts` (`upts`),
 KEY `crts` (`crts`),
 KEY `stock` (`stock`),
 KEY `type` (`stype`),
 KEY `gongkai` (`gongkai`),
 KEY `shhyid` (`hangye_id2`),
 KEY `hangye_id1` (`hangye_id1`),
 KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hm_income` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `reach` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `indate` date NOT NULL,
 `money` decimal(10,2) NOT NULL,
 `info` text NOT NULL,
 `ratio` int(11) NOT NULL,
 `ratio_money` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `crts` (`crts`),
 KEY `indate` (`indate`),
 KEY `reach` (`reach`)
) ENGINE=InnoDB;
SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/discuz_plugin_xigua_hm_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hm/install.php');

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hasqiang\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL
ALTER TABLE `pre_xigua_hm_seckill` ADD `hasqiang` INT(11) NOT NULL;
SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'appzhekou\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL
ALTER TABLE `pre_xigua_hm_seckill` ADD `appzhekou` INT(11) NOT NULL;
SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'income_uid\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL
ALTER TABLE `pre_xigua_hm_seckill` ADD `income_uid` INT(11) NOT NULL;
SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'order_id\'', array('xigua_hm_income'), true);
if(!$r2){
$sql =<<<SQL
ALTER TABLE `pre_xigua_hm_income` ADD `order_id` VARCHAR(80) NOT NULL;
SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'goodindex\'', array('xigua_hs_hangye'), true);
if(!$r2){
$sql =<<<SQL
ALTER TABLE `pre_xigua_hs_hangye` ADD `goodindex` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hs_hangye` ADD INDEX(`goodindex`);
SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'appprice\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `appprice` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hkprice\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `hkprice` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'custom_pic\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `custom_pic` VARCHAR(2000) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'stid\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `stid` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hm_seckill` ADD INDEX(`stid`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'stid\'', array('xigua_hm_seckill_log'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill_log` ADD `stid` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hm_seckill_log` ADD INDEX(`stid`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'shrate\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `hhrrate` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hm_seckill` ADD `shrate` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hm_seckill` ADD `hhr2rate` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fee_type\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `fee_type` INT NOT NULL;

ALTER TABLE `pre_xigua_hm_seckill` ADD `allowtk` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'tkts\'', array('xigua_hm_seckill_log'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill_log` ADD `tkts` INT(11) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hhr_ticheng\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `hhr_ticheng` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'refund\'', array('xigua_hm_seckill_log'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill_log` ADD `refund` VARCHAR(800) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hmgg\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `hmgg` VARCHAR(2000) NOT NULL;

ALTER TABLE `pre_xigua_hm_seckill_log` ADD `ggname` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'qun\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `qun` VARCHAR(200) NOT NULL;

ALTER TABLE `pre_xigua_hm_seckill` ADD `qrcache` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}

$sql = <<<SQL

ALTER TABLE `pre_xigua_hm_seckill` CHANGE `hasqiang` `hasqiang` INT(11) UNSIGNED NOT NULL;

SQL;
runquery($sql);


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hhr_ticheng2\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `hhr_ticheng2` DECIMAL(10,2) NOT NULL AFTER hhr_ticheng;
ALTER TABLE `pre_xigua_hm_seckill` ADD `fansqr` VARCHAR(800) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'usetime_start\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `usetime_start` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hm_seckill_log` ADD `startts` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'jiesuan1\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `jiesuan1` DECIMAL(10,2) NOT NULL AFTER `shrate`;
ALTER TABLE `pre_xigua_hm_seckill` ADD `jiesuan2` DECIMAL(10,2) NOT NULL AFTER `jiesuan1`;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'jifenrate\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `jifenrate` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fszx\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `fszx` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'formgg\'', array('xigua_hm_seckill'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill` ADD `formgg` VARCHAR(2000) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'formggs\'', array('xigua_hm_seckill_log'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hm_seckill_log` ADD `formggs` VARCHAR(2000) NOT NULL;

SQL;
    runquery($sql);
}