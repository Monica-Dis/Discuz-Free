function hm_GetRunTime(mallstart, mallend, itimer, step) {
var endtime = new Date(mallend.replace(/-/g, '/'));
var starttime = new Date(mallstart.replace(/-/g, '/'));
var keeptime = endtime - starttime;
var nowtime = new Date();
var t = endtime.getTime() - nowtime.getTime();
var st = starttime.getTime() - nowtime.getTime();
var tit = HM_JJS;
if (typeof noTit !== 'undefined') {
tit = '';
}
if (!mallend) {
itimer.html('<span class="timer">' + CQYX + '</span>');
return;
}
if (t <= 0) {
if (typeof noTit !== 'undefined') {
itimer.html('<span class="timer">' + mallend + '</span>');
} else {
itimer.html(HM_YY + '<span class="timer">' + mallend + '</span>' + HM_JS);
}
$('.doseckill').html(HM_YJS).removeClass('doseckill');
$('#page__bd').addClass('hasend');
return;
}
if (st > 0) {
t = st;
tit = HM_JKS;
}
var dd = t / 1000;
var d = Math.floor(dd / 3600 / 24);
var h = Math.floor(dd / 3600 % 24);
var m = Math.floor(dd / 60 % 60);
var s = Math.floor(dd % 60);
var o = '';
if (h < 10) {
h = '0' + h;
}
if (m < 10) {
m = '0' + m;
}
if (s < 10) {
s = '0' + s;
}
if (step === 10) {
o = Math.floor(t / 10 % 100);
if (o < 10) {
o = '0' + o;
}
o = "<i>" + o + "</i>";
}
var width = t / keeptime * 100;
var ddis = '', hdis = '', mdis = '', sdis = '';
if (d > 0) {
ddis = '<i>' + d + '</i>' + h_t;
}
hdis = '<i>' + h + '</i>' + h_h;
mdis = '<i>' + m + '</i>' + h_f;
sdis = '<i>' + s + '</i>' + h_sec;
itimer.html(tit + '<span class="timer">' + ddis + hdis + mdis + sdis + o + '</span>');
setTimeout(function () {
hm_GetRunTime(mallstart, mallend, itimer, step);
}, step || 1000);
}

function panew_popup() {
$('#pay_ctrl').popup();
if (typeof needaddr !== 'undefined') {
$.toast(qws);
setTimeout(function () {
window.location.href = _APPNAME + '?id=xigua_hb&ac=myaddr' + _URLEXT;
}, 2000);
}
}

function hm_digmode() {
if ($('#digmode:checked').length) {
$('.digmode').show();
} else {
$('.digmode').hide();
$('input[name="form[dingprice]"]').val('0');
}
return true;
}

$(function () {
if ($(".slider_hm").length > 0) {
var mySwiper = new Swiper(".slider_hm", {
slidesPerView: "auto",
centeredSlides: !0,
watchSlidesProgress: !0,
pagination: ".swiper-pagination",
paginationClickable: !0,
loop: true,
onProgress: function (a) {
var b, c, d;
for (b = 0; b < a.slides.length; b++) c = a.slides[b], d = c.progress, scale = 1 - Math.min(Math.abs(.2 * d), 1), es = c.style, es.opacity = 1 - Math.min(Math.abs(d / 2), 1), es.webkitTransform = es.MsTransform = es.msTransform = es.MozTransform = es.OTransform = es.transform = "translate3d(0px,0," + -Math.abs(150 * d) + "px)"
},
onSetTransition: function (a, b) {
for (var c = 0; c < a.slides.length; c++) es = a.slides[c].style, es.webkitTransitionDuration = es.MsTransitionDuration = es.msTransitionDuration = es.MozTransitionDuration = es.OTransitionDuration = es.transitionDuration = b + "ms"
}
});
}
$(document).on('click', '.sec_item, .m_jump', function () {
console.log($(this).data('id'));
if ($(this).data('id')) {
var jmpurl = _APPNAME + '?id=xigua_hm&ac=seckill_view&secid=' + $(this).data('id') + (typeof _URLEXT !== 'undefined' ? _URLEXT : '');
if (typeof mag !== 'undefined') {
mag.newWin(GSITE + jmpurl);
return false;
}
if (typeof QFH5 !== 'undefined') {
QFH5.jumpNewWebview(GSITE + jmpurl);
return false;
}
if (typeof wx !== 'undefined') {
if (window.__wxjs_environment === 'miniprogram') {
GSITE = GSITE.replace(/http:\/\//, 'https://');
wx.miniProgram.navigateTo({url: '/pages/index/index?url=' + encodeURIComponent(GSITE + jmpurl)});
return false;
}
}
if (typeof sq !== 'undefined') {
sq.urlRequest(GSITE + jmpurl);
return false;
}
window.location.href = jmpurl;
}
});
$(document).on('click', '.doseckill', function () {
var that = $(this);
if (that.attr('href') != 'javascript:;') {
return true;
}
if (HM_QZGZ && !IN_APP) {
var unscb = 0;
$.showLoading();
$.ajax({
type: 'get',
url: _APPNAME + '?id=xigua_hb&ac=checksub&inajax=1&openid=' + (typeof OPENID !== 'undefined' ? OPENID : ''),
data: {formhash: FORMHASH},
dataType: 'xml',
async: false,
success: function (data) {
if (null == data) {
return false;
}
var s = $.trim(data.lastChild.firstChild.nodeValue);
if (s.split('|')[1] != 'subscribe') {
unscb = 1;
}
$.hideLoading();
}
});
$.hideLoading();
if (unscb) {
$.alert("<img src='" + HM_QRCODE + "'/><br>" + HM_QZG, HM_GZQCHANGAN);
return false;
}
}
if (that.data('needpopup')) {
panew_popup();
return false;
}
var tnum = that.data('num') || $('#item_num').val();
if (!tnum) {
tnum = 1;
}
$.showLoading();
var datav = {
'secid': that.data('id'),
'note': $('#item_note').val(),
'num': tnum,
'addrid': that.data('addrid'),
'gginput': $('#gginput').val(),
'formhash': FORMHASH
};
var endv = 0;
$('.formggdiv').each(function(){
if(!endv && !$(this).val()){
$.alert($(this).attr('placeholder'));
endv = 1;
}
datav[$(this).attr('name')] = $(this).val();
});
if(endv){
$.hideLoading();
return false;
}
$.ajax({
type: 'post',
url: _APPNAME + '?id=xigua_hm&ac=seckill&inajax=1' + _URLEXT,
data: datav,
dataType: 'xml',
success: function (data) {
$.hideLoading();
if (null == data) {
tip_common('error|' + ERROR_TIP);
return false;
}
var s = data.lastChild.firstChild.nodeValue;
tip_common(s);
},
error: function () {
$.hideLoading();
}
});
});
$(document).on('click', '.inc-num', function () {
var ipt = $('.inc-input'), that = $(this);
var num = parseInt(ipt.val());
if (parseInt(that.data('step')) === 1) {
if (!ipt.data('max') || num < ipt.data('max')) {
ipt.val(++num);
}
} else {
if (num > 1) {
ipt.val(--num);
}
}
var nu = parseInt(ipt.val());
$('#num_display').text(nu);
var num_rs = nu * parseFloat(ipt.attr('data-price')) + parseFloat(ipt.data('fee'));
$('#num_price').text(num_rs.toFixed(2));
});
hb_setcookie('seckill_wait', window.location.href, 1200);
$(document).on('click', '#pay_address', function () {
window.location.href = _APPNAME + '?id=xigua_hb&ac=myaddr' + _URLEXT;
});
if ($('#digmode').length > 0) {
hm_digmode();
}
if ($('#driving').length > 0) {
var driv = $('#driving'), dnt = 0;
var drivInterval = setInterval(function () {
hs_getlocation(function (position) {
$.ajax({
type: 'post',
url: _APPNAME + '?id=xigua_hs&ac=driving&shid=' + driv.data('id') + '&inajax=1&from=' + (position.latitude || position.lat) + ',' + (position.longitude || position.lng),
data: {'formhash': FORMHASH},
dataType: 'xml',
success: function (data) {
if (null == data) {
    return false;
}
var s = data.lastChild.firstChild.nodeValue;
var sary = s.split('|');
if (sary[0] == 'success') {
    $('#driving').show().html(sary[1]);
}
clearInterval(drivInterval);
},
error: function () {
$('#driving').hide();
}
});
});
dnt++;
if (dnt > 2) {
clearInterval(drivInterval);
$('#driving').show().html('');
}
}, 1500);
}
$(document).on('click', '.ajaxhmcat', function () {
var that = $(this);
page = 1;
lm = false;
loadingurl = loadingurl.replace(/\&cat_id=\d+/, '').replace(/\&page=\d*/, '').replace(/dtp=ing/, '').replace(/dtp=wangqi/, '') + '&cat_id=' + that.data('id') + '&page=';
that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
DOAPPEND = 0;
$.ajax({
type: 'post', url: loadingurl + '' + page, dataType: 'xml', success: function (data) {
if (null == data) {
tip_common('error|' + ERROR_TIP);
return false;
}
var s = data.lastChild.firstChild.nodeValue;
$('#loading-show').addClass('hidden');
if (!s) {
$('#loading-show').addClass('hidden');
$('#loading-none').removeClass('hidden');
setTimeout(function () {
$('#loading-show').addClass('hidden');
$('#loading-none').removeClass('hidden');
}, 300);
$("#list").html(s);
page = -1;
return;
}
$("#list").html(s);
if (typeof loadingCallback !== 'undefined') {
loadingCallback();
}
page++;
}, error: function () {
}
});
});
$(document).on('click', '.sec_ewm', function () {
var that = $(this);
$.alert("<img src='" + _APPNAME + "?id=xigua_hm:qrcode&secid=" + $(this).data('id') + "' />" + that.data('ext'), fxqg);
$('.weui-dialog__title').attr('style', 'font-size:15px;');
});
$(document).on('click', '.custom_pic', function () {
$.alert("<img src='" + $(this).data('url') + "' />", fxqg);
$('.weui-dialog__title').attr('style', 'font-size:15px;');
});
if ($('.coupon_swiper').length > 0) {
var coupon_swiper = new Swiper('.coupon_swiper', {
slidesPerView: 'auto',
paginationClickable: true,
spaceBetween: 0
});
}
});
var toutiao_timeout;

function noti_toutiao(text, duration, index) {
if (!text) {
return;
}
var $t = $('.noti');
$t.html(text);
clearTimeout(toutiao_timeout);
if (!$t.hasClass('noti_visible')) {
$t.addClass('noti_visible');
}
toutiao_timeout = setTimeout(function () {
$t.removeClass('noti_visible').transitionEnd(function () {
noti_toutiao(TOUTIAOS[index + 1], duration, index + 1);
});
}, duration);
}

if (typeof TOUTIAOS !== 'undefined') {
if (TOUTIAOS) {
noti_toutiao(TOUTIAOS[0], 3000, 0);
}
}
$(document).on('click', '.do_follow2', function () {
var that = $(this);
$.showLoading();
$.ajax({
type: 'post',
url: _APPNAME + '?id=xigua_hs&ac=follow&do=do_follow&shid=' + that.data('id') + '&inajax=1',
data: {'formhash': FORMHASH},
dataType: 'xml',
success: function (data) {
$.hideLoading();
if (null == data) {
tip_common('error|' + ERROR_TIP);
return false;
}
var s = data.lastChild.firstChild.nodeValue;
if (s.split('|')[1] == '1') {
tip_common('success|' + HMGZCG);
setTimeout(function () {
window.location.reload();
}, 1200);
} else {
tip_common(s);
}
},
error: function () {
$.hideLoading();
}
});
});