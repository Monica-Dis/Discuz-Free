<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class xigua_s
{
    public function newthread_extraInfo()
    {
        global $_G;
        include_once DISCUZ_ROOT.'source/plugin/xigua_s/mobile.class.php';
        $global_header = mobileplugin_xigua_s::global_header_mobile();
        $global_footer = mobileplugin_xigua_s::global_footer_mobile();
        $hidden = '<input type="hidden" name="hidden_for_subject" value="1" />' ;

        if($global_footer){
            $ret = $hidden.$global_header.$global_footer;
        }else{
            $ret = <<<HTML
<script>
localStorage.removeItem('{$_G['uid']}thread_subject');
jq('#subject').val('');</script >
HTML;
        }
        return $ret;
    }

}