<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class plugin_xigua_s{

    function common(){
        if ($_GET['hidden_for_subject']==1 &&  strtolower($_SERVER['REQUEST_METHOD']) === 'post' ) {
            include_once DISCUZ_ROOT.'source/plugin/xigua_s/mobile.class.php';
            mobileplugin_xigua_s_forum::post_xigua_s_newthread();
        }
    }

    function global_header_mobile() {
        if(!in_array($_GET['action'], array('newthread'))){
            return '';
        }
        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_s'];
        $field = $config['field'];
        if(!in_array($_GET['fid'], unserialize($config['forums']))){
            return '';
        }

        return "<style>input[name=\"$field\"]{display:none!important;}</style >";
    }

    function global_footer_mobile(){
        if(!in_array($_GET['action'], array('newthread'))){
            return '';
        }

        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_s'];
        $field = $config['field'];
        if(!in_array($_GET['fid'], unserialize($config['forums']))){
            return '';
        }

        return <<<HTML
<script>var sctrl= $('input[name="$field"]'); $('#$field').hide();$('#needsubject').parent().parent().hide(); sctrl.hide().val("{$config['default_title']}");
setInterval(function(){sctrl.trigger('keyup');}, 1000);
</script >
HTML;
    }

    function global_header(){
        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_s'];
        $str = $config['openpc'] ? $this->global_header_mobile() : '';
        return $str;
    }
    function global_footer(){
        if( $this->global_footer_mobile()){
            global $_G;
            $config = $_G['cache']['plugin']['xigua_s'];
            $str = $config['openpc'] ? <<<HTML
<script>$('subject').style.display='none';$('subjectchk').style.display='none'; $('subject').value = "{$config['default_title']}";</script>
HTML
            : '';
            return $str;
        }
        return '';
    }
}


class  mobileplugin_xigua_s extends plugin_xigua_s{

}

class mobileplugin_xigua_s_forum extends mobileplugin_xigua_s {


    public static function post_xigua_s_newthread(){
        global $_G;

        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_s'];
        $allowfids = unserialize($config['forums']);

        if(in_array($_GET['fid'], $allowfids) && submitcheck('message') && in_array($_GET['action'], array('newthread'))) {
            $_GET['subject'] =  cutstr(self::clear_message($_GET['message'], $config), 60);
            if(!$_GET['message'] && $_GET['typeoption']){
                $ty = array_values($_GET['typeoption']);
                foreach ($ty as $index => $item) {
                    $_GET['subject'] =  $item;
                    if($item){
                        break;
                    }
                }
            }
        }
    }

    public static function clear_message($message, $config)
    {
        if(!$config['max_len']){
            $config['max_len'] = 40;
        }

        $message = trim($message);
        $sppos = strpos($message, chr(0).chr(0).chr(0));
        if($sppos !== false) {
            $message = substr($message, 0, $sppos);
        }
        $message = preg_replace(array(lang('forum/misc', 'post_edit_regexp'), lang('forum/misc', 'post_edithtml_regexp'), lang('forum/misc', 'post_editnobbcode_regexp')), '', $message);
        if(strpos($message, '[/hide]') !== FALSE){
            $message = preg_replace('/\[hide\].*?\[\/hide\]/i', '', $message);
        }
        if (
            strpos($message, '[/attach]') !== FALSE ||
            strpos($message, '[/attachimg]') !== FALSE ||
            strpos($message, '[/url]') !== FALSE ||
            strpos($message, '[/img]') !== FALSE ||
            strpos($message, '[/media]') !== FALSE ||
            strpos($message, '[/audio]') !== FALSE ||
            strpos($message, '[/flash]') !== FALSE
        ) {
            $pattern = "/(\[attach(img)?\]|\[(img|url|media|audio|flash)(.*)\]).*?(\[\/attach(img)?\]|\[\/(img|url|media|audio|flash)\])/i";
            $message = preg_replace($pattern, '', $message);
        }
        $message = preg_replace('/\{?\:\w+/', '', $message);
        $find    = array('&nbsp;', '&amp;', '&quot;', '&lt;', '&gt;', '[', ']', "\n", "\r", ' ', '  ');
        $replace = array('', '', '', '', '', '<', '>', '', '', '', '');
        $message = str_replace($find, $replace, $message);
        $message = strip_tags($message);
        $message = self::mobile_parsesmiles($message);

        if($filter = trim($config['filter'])){
            $filter = array_filter(explode("\n", $filter));
            foreach ($filter as $index => $item) {
                $filter[$index] = trim($item);
            }
            $message = str_ireplace($filter, '', $message);
        }

        $message = cutstr($message, $config['max_len']);
        if(!$message){
            $message = $config['default_title'];
        }

        return $message;
    }

    public static function mobile_parsesmiles($message) {
        global $_G;
        static $enablesmiles;
        if($enablesmiles === null) {
            $url = !in_array(strtolower(substr(STATICURL, 0, 6)), array('http:/', 'https:', 'ftp://')) ? $_G['siteurl'] : '';
            $enablesmiles = false;
            if(!empty($_G['cache']['smilies']) && is_array($_G['cache']['smilies'])) {
                foreach($_G['cache']['smilies']['replacearray'] AS $key => $smiley) {
                    $enablesmiles[$key] = '<img width="18px" src="'.$url.STATICURL.'image/smiley/'.$_G['cache']['smileytypes'][$_G['cache']['smilies']['typearray'][$key]]['directory'].'/'.$smiley.'" />';
                }
            }
        }
        $enablesmiles && $message = preg_replace($_G['cache']['smilies']['searcharray'], $enablesmiles, $message, $_G['setting']['maxsmilies']);
        return strip_tags($message);
    }

}


class plugin_xigua_s_forum extends mobileplugin_xigua_s_forum
{
    public static function post_xigua_s_newthread()
    {
        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_s'];
        if($config['openpc']){
            return parent::post_xigua_s_newthread();
        }
    }
}