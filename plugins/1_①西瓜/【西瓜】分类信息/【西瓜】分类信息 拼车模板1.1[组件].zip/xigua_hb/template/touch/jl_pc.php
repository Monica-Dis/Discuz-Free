<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{loop $list $v}-->
<!--{eval
$_vars = array_values($v[vars]);
$calltel = "tel:$v[mobile]";
if($v[wancheng]):
    $calltel = "javascript:$.toast('{lang xigua_hb:xinxiwc}','error');";
else:
    $vcatid = $v[catid];
    $vtelp  = $cats[$vcatid]['telpri'];
    if($vtelp>0):
        include DISCUZ_ROOT. 'source/plugin/xigua_hb/include/c_addon.php';
        if(!$viewtels[$v[id]] && !$ishk):
            $calltel = "javascript:hb_paytel('$v[id]','$vtelp','$vcatid');";
        endif;
    endif;
endif;
$ht0 = array_reverse(array_filter(explode(' ', $_vars[0][html])));
$ht1 = array_reverse(array_filter(explode(' ', $_vars[1][html])));
}-->
<div class="mod-post-list-item<!--{if $v[wancheng]}--> op6<!--{/if}-->" id="li_$v[id]" <!--{if $v[dig_on] && $v[zdcolor]}-->style="background-color:{$v[zdcolor]}"<!--{/if}-->>
<div class="mod-feed-header">
    <div class="usr-name mod-usr-name lv" style="margin-left: -3px;">
        <a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$v[catid]" class="mod-lv is-green">$cats[$v[catid]][name]</a>
        <!--{if $v[dig_on]}--><div class="mod-lv is-star"><!--{if $v[zdword]}-->$v[zdword]<!--{else}-->{lang xigua_hb:zhiding}<!--{/if}--></div><!--{/if}-->
        <!--{if $v[hb_num]}--><div class="mod-lv is-hot">{lang xigua_hb:hb}</div><!--{/if}-->
    </div>
    <div>
        <span class="name">{$ht0[0]}</span>
        <span class="name"><img style="width:1rem;vertical-align:middle" src="source/plugin/xigua_hb/static/img/arrow_oneway.png" /></span>
        <span class="name">{$ht1[0]}</span>
    </div>
</div>
<div class="mod-feed-content">
    <!--{if array_filter($v[tags])}-->
    <div class="cl mt8 item_tags view_jump" data-id="$v[id]">
        <!--{loop $v[tags] $k $tag}-->
        <!--{if $tag}--><span class="mod-feed-tag b-color{$k}">$tag</span><!--{/if}-->
        <!--{/loop}-->
    </div>
    <!--{/if}-->

    <div id="view_jump_$v[id]" class="view_jump mod-feed-text" data-id="$v[id]" style="color:#808080">
        <div class="f15">
            <!--{eval array_shift($_vars);array_shift($_vars);}-->
            <!--{loop $_vars $_var}-->
            <!--{if  $_var[type]!='pics'}-->
            <span class="block name"><span class="main_color">{$_var[title]}{lang xigua_hb:m}</span>$_var[html]</span>
            <!--{/if}-->
            <!--{/loop}-->
        </div>
        <div class="is-three f15">{echo nl2br(str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v[description]))));}</div>
    </div>
    <div class="mod-photos is-three feed-preview-pic">
        <!--{loop $v[img_preview] $k $img}-->
        <div class="G-img-wrap mod-img-pic imgloading">
            <img src="$img">
            <!--{if $k==2 && $v[img_count]>3}--><span class="num">$v[img_count]{lang xigua_hb:zhang}</span><!--{/if}-->
        </div>
        <!--{/loop}-->
    </div>
</div>
<div class="mod-feed-footer" style="margin-top:0">
    <div class="footer-text">
        <span>{$v[time_u]}</span>
        <span><i class="vm iconfont icon-faxian"></i> {$v[views]}</span>
    </div>
    <div class="footer-opt">
        <a href="$calltel" class=" mod-feed-tag b-color1" style="padding:.15rem .3rem;position: absolute;right: 0;top:.65rem;display: block;">
            <i class="icon-dianhua2 iconfont f12"></i>{lang xigua_hb:tel}
        </a>
    </div>
</div>
<!--{if $v[wancheng]}--><div class="wxexpired"></div><!--{/if}-->
</div>
<!--{/loop}-->