<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_hb:common_header}--><!--{eval
$c80 = hb_hex2rgb($config['maincolor'], .8);
$orderby_list['zan'] = lang_hb('dzl', 0);
if(!$orderby):
    $orderby = $_GET['orderby'];
endif;
}--><style>.x_header,.x_header_fix,.weui-navbar{display:none}.pc_search{background: #fff;position: relative;padding: .75rem;margin-bottom:.5rem;}
.p_search{background:url('source/plugin/xigua_hb/static/img/qh.png') center center no-repeat;background-size:1rem;margin-right:.5rem}
.p_search input {width: 33%;padding: 0 4%;line-height: 1.8rem;margin:0;outline: 0;height: 1.8rem;background: #F8F8F8;border: 0.05rem solid #EFEFEF;border-radius: 2.2rem;outline: none;-webkit-appearance: none;-webkit-tap-highlight-color: rgba(0, 0, 0, 0);}
.pi_button{height: 1.8rem;line-height: 1.8rem;background-blend-mode: screen;padding: 0 .5rem;border-radius: 0.35rem;text-align: center;white-space: nowrap;color: #fff;
font-size: 0.7rem;font-weight: 600;outline: 0;border: none;display: block;background:linear-gradient(to right, $c80, $config[maincolor]) no-repeat}
.banner_fix,.banner{height:1.9rem}.tag_list a{margin-top:0}
.mask{display:none!important;}
.nav_expand_panel{width: auto;height: auto;right: .5rem;top: 2.1rem;position: absolute;box-shadow: 0 0 .05rem rgba(0,0,0,.2);border-radius: .35rem;}
</style>
<div class="page__bd">
    <!--{if $catinfo['share_pic']}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$catinfo['share_pic']" /></div><!--{/if}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{loop $newindex_list $_k $_v}-->
    <!--{if $_k==99}-->
    <div class="swipe cl" data-speed="5000">
        <div class="swipe-wrap">
            <!--{loop $_v $__k $__v}-->
            <div><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $_v $__k $__v}-->
                <li <!--{if $__k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{else}-->
    <!--{eval
    if(!$_k):
        $_k = 4;
    endif;
    $tmpp = array_chunk($_v, $_k);
    }--><!--{loop $tmpp $__k $tmpp2}-->
    <!--{eval $counttmpp2 = count($tmpp2);}-->
    <ul class="inedxicon cl">
        <!--{loop $tmpp2 $__k $__v}-->
        <li style="width:{echo 100/$counttmpp2;}%"><a href="$__v[adlink]"><img src="$__v[icon]"></a></li>
        <!--{/loop}-->
    </ul>
    <!--{/loop}-->
    <!--{/if}-->
    <!--{/loop}-->

    <!--{if $jing_list = $subcats}-->
    <!--{eval
    $catinfotm= $catinfo;
    $catinfotm['name'] =  lang_hb('quanbu',0);
    $jing_list = array_values(array_merge(array($catinfotm), $jing_list));
    $cntlist = count($jing_list);
    $numi1 = min($cntlist, 5);
    $widthshow = $numi1>0 ? (100/$numi1).'%' : '20%';
    $jing_count = range(0, ceil($cntlist/$numi1)-1);
    }-->
    <nav class=" nav-list cl swipe" style="padding-top:.35rem">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $jing_list $k $n}-->
                    <!--{if $k && $k%$numi1==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li style="width:$widthshow">
                        <a href="$SCRITPTNAME?id=xigua_hb&ac=cat&$query&cat_id=$n[id]">
                            <span>
                                <img src="$n['icon']"/>
                            </span>
                            <em class="m-piclist-title <!--{if $_GET[cat_id]==$n[id]}-->main_color<!--{/if}-->">{$n['name']}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position position1">
                <!--{loop $jing_count $k $v}-->
                <li {if $k==0} class="current" {/if}></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </nav>
    <!--{/if}-->
    <div class="pc_search cl">
        <form  action="$SCRITPTNAME" method="get" id="searchForm">
            <input type="hidden" name="id" value="xigua_hb">
            <input type="hidden" name="ac" value="cat">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <input type="hidden" name="cat_id" value="$_GET[cat_id]">

            <div class="weui-flex">
                <div class="p_search cl">
                    <input class="z" type="text" name="keyword1" placeholder="{lang xigua_hb:cfdss}" value="$_GET[keyword1]">
                    <input class="y" type="text" name="keyword2" placeholder="{lang xigua_hb:mddss}" value="$_GET[keyword2]">
                </div>
                <button class="pi_button  weui-flex__item" type="submit">{lang xigua_hb:sousuo}</button>
            </div>
            <div class="weui-cells__title color-red2 bgf f12" style="padding:0;margin-bottom:0"><i class="iconfont icon-hot1 f12"></i> {lang xigua_hb:mzsm}</div>
        </form>
    </div>
    <!--{if $tag_childs}-->
    <div class="banner_fix cl">
        <div class="banner">
            <nav class="weui-flex tag_list">
                <a href="$SCRITPTNAME?id=xigua_hb&ac=cat&$query" class="pstyle <!--{if !$_GET[tag]}-->main_color<!--{/if}-->">{lang xigua_hb:buxian}</a>
                <!--{loop $tag_childs $_kk $tag_child}-->
                <!--{eval $tag_child = trim($tag_child);}-->
                <a href="$SCRITPTNAME?id=xigua_hb&ac=cat&$query&tag=$tag_child" class="pstyle <!--{if $tag_child==$_GET[tag]}-->main_color<!--{/if}-->">$tag_child</a>
                <!--{/loop}-->
            </nav>
        </div>
    </div>
    <!--{/if}-->

    <!--{if $catinfo['adimage']}-->
    <div class="">
        <a href="{eval echo $catinfo['adlink'] ? $catinfo['adlink'] : $SCRITPTNAME.'?id=xigua_hb&ac=cat&cat_id='.$cat_id}"><img src="$catinfo['adimage']" class="block" /></a>
    </div>
    <!--{/if}-->
    <!--{if $catinfo['customad']}-->{echo htmlspecialchars_decode($catinfo['customad'])}<!--{/if}-->
    <div class="weui-cells__title weui_title f15 border_bottom mt0">
        <span class="c3">{$old_catinfo[name]}{lang xigua_hb:xinxi}</span>
        <a data-id="3" class="dist_nav y c9 f14">
            <span>$orderby_list[$orderby] <i class="iconfont icon-xiangxia f12"></i></span>
        </a><div id="dist_show_3" class="nav_expand_panel border_top">
            <div class="weui-flex">
                <div class="weui-">
                    <ul>
                        <li class="<!--{if !$orderby && !$_GET[hb]}-->checked main_color<!--{/if}--> border_bottom"><a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">$orderby_list['']</a></li>
                        <li class="<!--{if $orderby=='hot'}-->checked main_color<!--{/if}--> border_bottom"><a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=hot&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">$orderby_list[hot]</a></li>
                        <li class="<!--{if $orderby=='new'}-->checked main_color<!--{/if}--> border_bottom"><a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=new&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">$orderby_list[new]</a></li>
                        <li class="<!--{if $orderby=='img'}-->checked main_color<!--{/if}--> border_bottom"><a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=img&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">$orderby_list[img]</a></li>
                        <li class="<!--{if $orderby=='zan'}-->checked main_color<!--{/if}--> border_bottom"><a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=zan&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">{lang xigua_hb:dzl}</a></li>
                        <!--{if $_G['cache']['plugin']['xigua_hs'] && $config[showfj]}-->
                        <li class="<!--{if $orderby=='near'}-->checked main_color<!--{/if}--> border_bottom"><a id="near_xinxi" data-href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=near&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">{lang xigua_hb:near}</a></li>
                        <!--{/if}-->
                        <li class="<!--{if $_GET[hb]}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_hb&hb=1&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">{lang xigua_hb:hb}</a></li>
                    </ul>
                </div>

            </div>
        </div>
    </div>
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->
</div>
<!--{if $hide_nav && !$showfloatapp}-->
<a href="javascript:$('#srh_popup').popup()" class="backtotop backtotop_show" style="bottom:-10px"> <span class="icon-vertical-align-top"><i class="iconfont icon-sousuo"></i></span></a>
<!--{/if}-->
<script>
    var loadingurl = window.location.href+'&ac=list_item&inajax=1&page=';
    scrollto = 0;
    function hs_getnext(id, name, datahref){
        $('.sub_check a').removeClass('checked').removeClass('main_color');
        $('.sub_check a').parent().removeClass('checked').removeClass('main_color');
        $('#sub_check'+id).addClass('checked').addClass('main_color');
        $.ajax({
            type: 'get',
            url: _APPNAME + '?id=xigua_hb&province='+$('.first_check+.checked').find('a').text()+'&name='+name+'&ctid='+id+'&datahref='+encodeURIComponent(datahref)+'&inajax=1',
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $('.ajaxbox_cheker').html(s);
            }
        });
    }
    $(document).on('click','.choose', function () {
        var that = $(this), c_jmpurl = '';
        if(that.data('href')){ c_jmpurl = that.data('href'); }
        if(that.data('ctid')){ c_jmpurl = $('#sub_check'+that.data('ctid')).data('href'); }
        window.location.href= c_jmpurl;
    });
    $(document).on('click','.dist_check', function () {$('.dist_check').removeClass('checked').removeClass('main_color'); $(this).addClass('checked').addClass('main_color');});
    $(document).on('click','.dist_nav', function () {if($('.autotrigger').length>0){$('.autotrigger').find('a').trigger('click');}});
    $(document).on('click','.first_check', function () {$('.ajaxbox_cheker').html('');});
    $(document).on('click','.gray-tags a', function () {
        var that = $(this);
        that.siblings().removeClass('tag-on');
        that.addClass('tag-on');
    });
    $(document).on('click','#filtervar_btn', function () {
        var res = '';
        $('.gray-tags a.tag-on').each(function () {
            var that = $(this);
            res+= that.data('title')+'_'+that.data('value')+'__';
        });
        hb_jump('$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province=$_GET[province]&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&filter='+res);
    });
    $(document).on('click','#filtervar_clear', function () {
        $('.gray-tags a').removeClass('tag-on');
    });
</script>
<!--{eval $tabbar=1;}-->
<!--{template xigua_hb:common_footer}-->
<!--{if $_G['cache']['plugin']['xigua_hs'] && $config[showfj]}-->
<script>
    var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";
</script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script>$(document).on('click','#near_xinxi', function () {
    var that = $(this);
    var href= window.location.href+'&orderby=near';
    hs_getlocation(function (position) {
        var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
        window.location.href= href+ '&lat='+lat+'&lng='+lng;
    });
});
</script>
<!--{/if}-->
<!--{if $_GET['srch']}--><script>$('#srh_popup').popup();</script><!--{/if}-->