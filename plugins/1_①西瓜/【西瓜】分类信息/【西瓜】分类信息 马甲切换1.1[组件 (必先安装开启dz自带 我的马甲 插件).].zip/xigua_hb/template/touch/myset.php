<?php exit('Author: ���²����http://t.cn/Aiux1Jx1 ΢�� wxiguabbs'); ?>
<!--{template xigua_hb:common_header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->


    <div class="weui-cells">

        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=mysetxx">
            <div class="weui-cell__hd"><i class="iconfont icon-weixinzhifu1 color-forest"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:xiaoxishezhi}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
<!--{if $dxp}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=myzl">
            <div class="weui-cell__hd"><i class="iconfont icon-shouji color-red"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:bindmobile}</p>
            </div>
            <div class="weui-cell__ft">$muhumobile</div>
        </a>
<!--{/if}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=myaddr&mobile=2{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-coordinates_fill color-soundcloud"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:myaddr}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>

        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=mytx">
            <div class="weui-cell__hd"><i class="iconfont icon-zhifubao color-paypal"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:txfs}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>

<!--{if $_G['cache']['plugin']['xigua_member']}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_member:profile">
            <div class="weui-cell__hd"><i class="iconfont icon-fabuxuqiu color-amazon"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:member}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
<!--{/if}-->

    <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=mycover">
        <div class="weui-cell__hd"><i class="iconfont icon-xiangji color-good"></i></div>
        <div class="weui-cell__bd">
            <p>{lang xigua_hb:setbg}</p>
        </div>
        <div class="weui-cell__ft"></div>
    </a>

<!--{if $_G['cache']['plugin']['xigua_st']}-->
<!--{eval
    $hotcity = DB::fetch_all("select * from %t WHERE status=1 ORDER BY displayorder DESC", array('xigua_st'), 'stid');
    $extuser = $user;
}-->
    <a class="weui-cell weui-cell_access" href="javascript:;">
        <div class="weui-cell__hd"><i class="iconfont icon-iconfenxiao color-dribbble"></i></div>
        <div class="weui-cell__bd">
            <input class="weui-input" id="site" placeholder="{lang xigua_hb:mrfz}" type="text" value="{echo $hotcity[$user[dftst]][name]}">
        </div>
        <div class="weui-cell__ft"></div>
    </a>
<!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_hr']['inputpos']==2}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hr&ac=my&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-yanzheng color-green"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hr:rzzx}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
<!--{/if}-->
<!--{if $_G['cache']['plugin']['myrepeats'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_myrepeats.php')}-->
<!--{eval include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_myrepeats.php'}-->
<a class="weui-cell weui-cell_access" href="javascript:;">
    <div class="weui-cell__hd"><i class="iconfont icon-yanzheng color-green"></i></div>
    <div class="weui-cell__bd">
        <input class="weui-input" id="qiehuan" placeholder="{echo lang('plugin/myrepeats', 'memcp');} {$_G[username]}" type="text" value="">
    </div>
    <div class="weui-cell__ft"></div>
</a>
<script>
$("#qiehuan").select({
    title: "{echo lang('plugin/myrepeats', 'memcp');}",
    items: [<!--{loop $rlist $v}-->{title: "{$v[user]}",value: "{$v[link]}",},<!--{/loop}-->],
    onOpen:function () {$('.masker').fadeIn();},
    beforeClose:function () {$('.masker').fadeOut(150);return true;},
    onChange: function(d) {
        if(typeof d.values !='undefined'){
            $.showLoading();
            if(d.values.indexOf('switch')===-1){
                hb_jump(d.values);
            }else{$.ajax({
                type: 'post',
                url: d.values+'&inajax=1',
                data:{formhash : FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
            }
        }
    }
});
</script>
<!--{/if}-->
    </div>
    <div class="weui-cells">
        <a class="weui-cell weui-cell_access" href="member.php?mod=logging&action=logout&formhash={FORMHASH}" >
            <div class="weui-cell__hd"><i class="iconfont icon-tuichu color-gray"></i></div>
            <div class="weui-cell__bd">
                <p>{lang logout_mobile}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
    </div>
</div>
<div class="masker" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);display:none;z-index:1000" onclick='$("#site").select("close")'></div>

<!--{eval $tabbar=1;}-->
<!--{template xigua_hb:common_footer}-->
<!--{if $_G['cache']['plugin']['xigua_st'] && $hotcity}-->
<script>
var oldshid = '{echo intval($extuser[dftst]);}';
$("#site").select({
    title: "{lang xigua_hb:mrfz}",
    items: [{title:"{$_G['cache']['plugin']['xigua_st']['zongname']}", value:0},<!--{loop $hotcity $v}-->{title: "{$v[name]}",value: "{$v[stid]}",},<!--{/loop}-->],
    onOpen:function () {$('.masker').fadeIn();},
    beforeClose:function () {$('.masker').fadeOut(150);return true;},
    onChange: function(d) {
        if(typeof d.values !='undefined'){
            if(oldshid==d.values){
                return false;
            }
            console.log(d.values);
            oldshid =d.values;
            $.showLoading();
            $.ajax({
                type: 'post',
                url: _APPNAME +'?id=xigua_hb&ac=myset&newstid='+d.values+'&inajax=1',
                data:{formhash : FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }
    }
});
</script>
<!--{/if}-->