<?php exit('Author: 最新插件：http://t.cn/Aiux1Jx1 微信 wxiguabbs'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hb:common_nav}-->
<style>.border_full {border: 1px solid rgba(0, 0, 0, 0.2);border-radius: 4px;padding-left: 2px;}
.pztable{width:100%;margin-top: 10px;background: #fff;padding: 10px;}
.pztable thead.alt1 td{font-weight:bold}
.pztable tr td{padding: 2px!important;text-align: center;}</style>
<form method="post" autocomplete="off" action="plugin.php?id=xigua_hb:memcp&pluginop=add" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <div class="weui-cells__title">{lang myrepeats:adduser}</div>
    <div class="weui-cells weui-cells_form">
        <!--{if $permusers}-->
        <div class="weui-cell weui-cell_select weui-cell_select-after">
            <div class="weui-cell__hd"><label class="weui-label">{lang myrepeats:select_rrepeats}</label></div>
            <div class="weui-cell__bd">
                <select id="userselect" onchange="$('#usernamenew').val(this.value)" class="weui-select">
                    <option value="">{lang myrepeats:select_rrepeats}</option>
                    <!--{loop $permusers $user}-->
                    <option value="$user">$user</option>
                    <!--{/loop}-->
                </select>
            </div>
        </div>
        <!--{/if}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{lang myrepeats:username}</label></div>
            <div class="weui-cell__bd">
                <input name="usernamenew" id="usernamenew" type="text" class="weui-input" value="$username" tabindex="1" placeholder="{lang myrepeats:username}" />
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{lang myrepeats:password}</label></div>
            <div class="weui-cell__bd">
                <input type="password" name="passwordnew" class="weui-input"  tabindex="2" placeholder="{lang myrepeats:password}" />
            </div>
        </div>

        <div class="weui-cell weui-cell_select weui-cell_select-after">
            <div class="weui-cell__bd">
                <select class="weui-select sel_list"  name="questionidnew" tabindex="3"  >
                    <option value="0">{lang myrepeats:security_question}</option>
                    <option value="1">{lang myrepeats:security_question_1}</option>
                    <option value="2">{lang myrepeats:security_question_2}</option>
                    <option value="3">{lang myrepeats:security_question_3}</option>
                    <option value="4">{lang myrepeats:security_question_4}</option>
                    <option value="5">{lang myrepeats:security_question_5}</option>
                    <option value="6">{lang myrepeats:security_question_6}</option>
                    <option value="7">{lang myrepeats:security_question_7}</option>
                </select>
            </div>
        </div>

        <div class="weui-cell answerli" style="display:none">
            <div class="weui-cell__bd">
                <input type="text" name="answernew" autocomplete="off"  class="weui-input" tabindex="1" placeholder="{lang myrepeats:security_answer}" />
            </div>
        </div>

        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{lang myrepeats:comment}</label></div>
            <div class="weui-cell__bd">
                <input type="text" name="commentnew" id="username_myrepeats" autocomplete="off"  class="weui-input" tabindex="1" value="" placeholder="{lang myrepeats:comment}"  />
            </div>
        </div>

        <div class="fix-bottom" style="position:relative">
            <input name="adduser1" value="1" type="hidden">
            <input type="submit" class="weui-btn weui-btn_primary" name="adduser" id="submitnew" value="{lang myrepeats:add}">
        </div>
    </div>
</form>

<form method="post" autocomplete="off" action="plugin.php?id=xigua_hb:memcp&pluginop=update">
    <input type="hidden" name="formhash" value="{FORMHASH}" />
    <!--{if $repeatusers}-->
    <table class="pztable">
        <thead class="alt1">
        <tr>
            <td class="f12">{lang myrepeats:delete_check}</td>
            <td class="f12">{lang myrepeats:username}</td>
            <td class="f12">{lang myrepeats:commentrow}</td>
            <td class="f12">{lang myrepeats:lastswitch}</td>
        </tr>
        </thead>
        <!--{loop $repeatusers $user}-->
        <tr>
            <td class="f12"><input name="delete[]" type="checkbox" class="pc" value="$user[username]" /></td>
            <td class="f12"><b><!--{if !$user[locked]}-->
<a class="locjs" href="javascript:;" data-href="plugin.php?id=xigua_hb:switch&username=$user[usernameenc]&formhash={FORMHASH}">$user[username]</a></b><!--{else}-->$user[username] ({lang myrepeats:locked})<!--{/if}--></td>
            <td class="f12"><input name="comment[{$user[username]}]" class="border_full" value="$user[comment]" size="10" /></td>
            <td class="f12"><!--{if $user[lastswitch]}-->$user[lastswitch]<!--{else}-->{lang myrepeats:nouse}<!--{/if}--></td>
        </tr>
        <!--{/loop}-->
    </table>
    <div class="fix-bottom" style="position:relative">
        <input name="updateuser1" value="1" type="hidden">
        <button type="submit" class="weui-btn weui-btn_primary" name="updateuser" value="yes" >{lang submit}</button>
    </div>
    <!--{/if}-->
</form>
<script>
$(document).on('change', '.sel_list', function() {
    var obj = $(this);
    $('.span_question').text(obj.find('option:selected').text());
    if(obj.val() == 0) {
        $('.answerli').css('display', 'none');
    } else {
        $('.answerli').css('display', 'block');
    }
});
$(document).on('click','.locjs', function () {
    var link = $(this).attr('data-href');$.ajax({
        type: 'get',
        url: link,
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        }
    });
});
</script>
<!--{template xigua_hb:common_footer}-->