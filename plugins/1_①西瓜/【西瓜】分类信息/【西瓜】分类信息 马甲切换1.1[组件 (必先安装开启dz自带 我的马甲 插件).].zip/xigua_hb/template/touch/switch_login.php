<?php exit('Author: ���²����http://t.cn/Aiux1Jx1 ΢�� wxiguabbs'); ?>
<!--{template xigua_hb:common_header}-->
<div class="weui-cells__title">{lang myrepeats:switch_tips}</div>
<form method="post" autocomplete="off" name="myrepeats" id="form" class="cl" action="plugin.php?id=xigua_hb:switch&dosubmit=yes&handlekey=myrepeat">
	<div class="cl">
		<input type="hidden" name="formhash" value="{FORMHASH}" />
		<input type="hidden" name="authorfirst" value="yes" />
		<input type="hidden" name="referer" value="$referer" />
		<div class="weui-cells weui-cells_form">
			<div class="weui-cell">
				<div class="weui-cell__hd"><label class="weui-label">{lang myrepeats:username}</label></div>
				<div class="weui-cell__bd">
					<input type="text" name="username" id="username_myrepeats" autocomplete="off"  class="weui-input" tabindex="1" value="$username" readonly />
				</div>
			</div>
			<div class="weui-cell">
				<div class="weui-cell__hd"><label class="weui-label">{lang myrepeats:password}</label></div>
				<div class="weui-cell__bd">
					<input type="password" id="password3_myrepeats" name="password"  class="weui-input" tabindex="1" />
				</div>
			</div>
			<div class="weui-cell weui-cell_select weui-cell_select-after">
				<div class="weui-cell__bd">
						<select class="weui-select sel_list" id="loginquestionid_myrepeats" name="questionid">
							<option value="0">{lang myrepeats:security_question}</option>
							<option value="1">{lang myrepeats:security_question_1}</option>
							<option value="2">{lang myrepeats:security_question_2}</option>
							<option value="3">{lang myrepeats:security_question_3}</option>
							<option value="4">{lang myrepeats:security_question_4}</option>
							<option value="5">{lang myrepeats:security_question_5}</option>
							<option value="6">{lang myrepeats:security_question_6}</option>
							<option value="7">{lang myrepeats:security_question_7}</option>
						</select>
				</div>
			</div>
			<div class="weui-cell answerli" style="display:none">
				<div class="weui-cell__bd">
					<input type="text" name="answer" autocomplete="off"  class="weui-input" tabindex="1" placeholder="{lang myrepeats:security_answer}" />
				</div>
			</div>
		</div>
	</div>
	<div class="fix-bottom">
		<input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="submitnew" value="{lang myrepeats:confirm}">
	</div>
</form>
<script>
$(document).on('change', '.sel_list', function() {
    var obj = $(this);
    $('.span_question').text(obj.find('option:selected').text());
    if(obj.val() == 0) {
        $('.answerli').css('display', 'none');
    } else {
        $('.answerli').css('display', 'block');
    }
});
</script>
<!--{template xigua_hb:common_footer}-->