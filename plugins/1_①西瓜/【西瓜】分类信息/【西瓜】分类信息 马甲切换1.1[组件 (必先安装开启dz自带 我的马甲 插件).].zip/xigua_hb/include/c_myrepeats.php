<?php

if(in_array('', $myrepeatsusergroups)) {
    $myrepeatsusergroups = array();
}
$userlist = array();
if(!in_array($_G['groupid'], $myrepeatsusergroups)) {
    $userlist = get_rrepeats($_G['username']);
    $count = count($userlist);
    if(!$count) {
        unset($_G['setting']['plugins']['spacecp']['myrepeats:memcp']);
    }
}

foreach(C::t('#myrepeats#myrepeats')->fetch_all_by_uid($_G['uid']) as $user) {
    $userlist[$user['username']] = $user['username'];
}
$rlist =  array();
foreach($userlist as $user) {
    if(!$user) {
        continue;
    }
    $rlist[] = array(
        'link' => "plugin.php?id=xigua_hb:switch&username=".rawurlencode($user).'&formhash='.FORMHASH,
        'user' => $user,
        'ajax' => 1,
    );
}
$rlist[] = array(
    'link' => 'plugin.php?id=xigua_hb:memcp',
    'user'=>lang('plugin/myrepeats', 'memcp'),
);

//.= '<li><a href="">'..'</a></li>';



function get_rrepeats($username) {
    $users = C::t('#myrepeats#myrepeats')->fetch_all_by_username($username);
    $uids = array();
    foreach($users as $user) {
        $uids[] = $user['uid'];
    }
    $userlist = array();
    foreach(C::t('common_member')->fetch_all($uids) as $user) {
        $userlist[$user['username']] = $user['username'];
    }
    return $userlist;
}