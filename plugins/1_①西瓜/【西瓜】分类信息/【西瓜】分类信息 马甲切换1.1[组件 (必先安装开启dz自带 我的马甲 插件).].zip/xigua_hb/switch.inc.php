<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: switch.inc.php 29558 2012-04-18 10:17:22Z monkey $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}

include_once DISCUZ_ROOT. 'source/plugin/xigua_hb/common.php';
if(!$_G['uid']) {
    hb_message1('not_loggedin', 'error');
}
if(!$_G['cache']['plugin']){
    loadcache('plugin');
}

$myrepeatsusergroups = (array)dunserialize($_G['cache']['plugin']['myrepeats']['usergroups']);

if(!empty($_GET['list'])) {
	if(in_array('', $myrepeatsusergroups)) {
		$myrepeatsusergroups = array();
	}
	$userlist = array();
	if(!in_array($_G['groupid'], $myrepeatsusergroups)) {
		$userlist = get_rrepeats($_G['username']);
		$count = count($userlist);
		if(!$count) {
			unset($_G['setting']['plugins']['spacecp']['myrepeats:memcp']);
		}
	}

	foreach(C::t('#myrepeats#myrepeats')->fetch_all_by_uid($_G['uid']) as $user) {
		$userlist[$user['username']] = $user['username'];
	}
	$list = '<ul>';
	foreach($userlist as $user) {
		if(!$user) {
			continue;
		}
		$list .= '<li><a href="plugin.php?id=myrepeats:switch&username='.rawurlencode($user).'&formhash='.FORMHASH.'" onclick="showWindow(\'myrepeat\', this.href);return false;">'.$user.'</a></li>';
	}
	$list .= '<li><a href="home.php?mod=spacecp&ac=plugin&id=myrepeats:memcp">'.lang('plugin/myrepeats', 'memcp').'</a></li>';
	include template('common/header_ajax');
	echo $list;
	include template('common/footer_ajax');
	exit;
}

if($_GET['formhash'] != FORMHASH) {
    hb_message1('undefined_action', 'error');
}

$referer = dreferer();

if(in_array('', $myrepeatsusergroups)) {
	$myrepeatsusergroups = array();
}
if(!in_array($_G['groupid'], $myrepeatsusergroups)) {
	$users = C::t('#myrepeats#myrepeats')->fetch_all_by_username($_G['username']);
	if(!$users) {
        hb_message1(lang('plugin/myrepeats', 'usergroup_disabled'), 'error');
	} else {
		$permusers = array();
		foreach($users as $user) {
			$permusers[] = $user['uid'];
		}
		$member = C::t('common_member')->fetch_by_username($_GET['username']);
		if(!$member || !in_array($member['uid'], $permusers)) {
            hb_message1(lang('plugin/myrepeats', 'usergroup_disabled'), 'error');
		}
	}
}

require_once libfile('function/member');

$_G['myrepeats_loginperm'] = logincheck($_GET['username']);
if(!$_G['myrepeats_loginperm']) {
    hb_message1(lang('plugin/myrepeats', 'login_strike'), 'error');
}

if(!empty($_GET['authorfirst']) && submitcheck('dosubmit')) {
	$result = userlogin($_GET['username'], $_GET['password'], $_GET['questionid'], $_GET['answer'], 'username', $_G['clientip']);
	$_G['myrepeats_ucresult'] = $result['ucresult'];
	if($result['status'] > 0) {
		$logindata = addslashes(authcode($_GET['password']."\t".$_GET['questionid']."\t".$_GET['answer'], 'ENCODE', $_G['config']['security']['authkey']));
		if(C::t('#myrepeats#myrepeats')->count_by_uid_username($_G['uid'], $_GET['username'])) {
			C::t('#myrepeats#myrepeats')->update_logindata_by_uid_username($_G['uid'], $_GET['username'], $logindata);
		} else {
			C::t('#myrepeats#myrepeats')->insert(array(
				'uid' => $_G['uid'],
				'username' => $_GET['username'],
				'logindata' => $logindata,
				'comment' => ''
			));
		}
	} else {
		myrepeats_loginfailure($_GET['username'], $_GET['password'], $_GET['questionid'], $_GET['answer']);
	}
}

$user = C::t('#myrepeats#myrepeats')->fetch_all_by_uid_username($_G['uid'], $_GET['username']);
$user = current($user);
$olddiscuz_uid = $_G['uid'];
$olddiscuz_user = $_G['username'];
$olddiscuz_userss = $_G['member']['username'];

if(!$user) {
	$newuid = C::t('common_member')->fetch_uid_by_username($_GET['username']);
	if(C::t('#myrepeats#myrepeats')->count_by_uid_username($newuid, $olddiscuz_userss)) {
		$username = ($_GET['username']);
		if($_GET['inajax']==1){
		    hb_message(lang_hb('loading',0), 'success', 'plugin.php?id=xigua_hb:switch&username='.urlencode($username).'&formhash='.formhash());
        }
		include template('xigua_hb:touch/switch_login');
		exit;
	}
    hb_message1(lang('plugin/myrepeats', 'user_nonexistence'), 'error');
} elseif($user['locked']) {
    hb_message1(lang('plugin/myrepeats', 'user_locked'), 'error');
}

list($password, $questionid, $answer) = explode("\t", authcode($user['logindata'], 'DECODE', $_G['config']['security']['authkey']));

$result = userlogin($_GET['username'], $password, $questionid, $answer, 'username', $_G['clientip']);
$_G['myrepeats_ucresult'] = $result['ucresult'];
if($result['status'] > 0) {
	setloginstatus($result['member'], 2592000);
	C::t('#myrepeats#myrepeats')->update_lastswitch_by_uid_username($olddiscuz_uid, $_GET['username'], TIMESTAMP);
	$ucsynlogin = $_G['setting']['allowsynlogin'] ? uc_user_synlogin($_G['uid']) : '';
	dsetcookie('mrn', '');
	dsetcookie('mrd', '');
	$comment = $user['comment'] ? '('.$user['comment'].') ' : '';
    hb_message1(lang('plugin/myrepeats', 'login_succeed'), 'success', "$SCRITPTNAME?id=xigua_hb&ac=my");
} elseif($result['status'] == -1) {
	clearcookies();
	$_G['myrepeats_ucresult']['username'] = addslashes($_G['myrepeats_ucresult']['username']);
	$_G['username'] = '';
	$_G['uid'] = 0;
	$auth = authcode($_G['myrepeats_ucresult']['username']."\t".formhash(), 'ENCODE');
    hb_message1(lang('plugin/myrepeats', 'login_activation'), 'success', "$SCRITPTNAME?id=xigua_hb&ac=my");
} else {
	myrepeats_loginfailure($_GET['username'], $password, $questionid, $answer);
}

function myrepeats_loginfailure($username, $password, $questionid, $answer) {
	global $_G;
	$password = preg_replace("/^(.{".round(strlen($password) / 4)."})(.+?)(.{".round(strlen($password) / 6)."})$/s", "\\1***\\3", $password);
	$errorlog = dhtmlspecialchars(
		TIMESTAMP."\t".
		($_G['myrepeats_ucresult']['username'] ? $_G['myrepeats_ucresult']['username'] : stripslashes($username))."\t".
		$password."\t".
		"Ques #".intval($questionid)."\t".
		$_G['clientip']);
	writelog('illegallog', $errorlog);
	loginfailed($username);
	$fmsg = $_G['myrepeats_ucresult']['uid'] == '-3' ? (empty($questionid) || $answer == '' ? 'login_question_empty' : 'login_question_invalid') : 'login_invalid';
	if($_G['myrepeats_loginperm'] > 1) {
        hb_message1(lang('plugin/myrepeats', str_replace('{loginperm}', $_G['myrepeats_loginperm'], $fmsg)), 'error');
	} elseif($_G['myrepeats_loginperm'] == -1) {
        hb_message1(lang('plugin/myrepeats', 'login_password_invalid'), 'error');
	} else {
        hb_message1(lang('plugin/myrepeats', 'login_strike'), 'error');
	}
}

function get_rrepeats($username) {
	$users = C::t('#myrepeats#myrepeats')->fetch_all_by_username($username);
	$uids = array();
	foreach($users as $user) {
		$uids[] = $user['uid'];
	}
	$userlist = array();
	foreach(C::t('common_member')->fetch_all($uids) as $user) {
		$userlist[$user['username']] = $user['username'];
	}
	return $userlist;
}

function hb_message1($msg, $type, $url = ''){
    $msg = str_replace('{user} {comment}', '', $msg);
    hb_message($msg, $type, $url);
}