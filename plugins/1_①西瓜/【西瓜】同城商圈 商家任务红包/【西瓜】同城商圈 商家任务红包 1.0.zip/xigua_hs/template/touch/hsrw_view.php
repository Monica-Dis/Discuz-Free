<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
if($_GET[edid] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php')):
    include_once DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php';
endif;
}--><!--{if $_G[uid] && $v[hbtiaojian]>0}--><!--{eval
$oldhbtmp = DB::fetch_first('select * from %t where shid=%d and uidtmp=%d and uid=0', array('xigua_hb_hongbaolog', $shid, $_G['uid']));
$oldhbtmp1 = DB::result_first('select size from %t where shid=%d ORDER BY id DESC', array('xigua_hb_hongbaolog', $shid));
$hbuserlist1 = DB::fetch_all('select * from %t where toid=%s and rwuid=%d', array('xigua_hb_hbvlog', 'hs_'.$shid, $_G['uid']));
}--><script>function showfxhs(){
$.modal({title: "{lang xigua_hb:rwhb}",
    text: "<div class=''>{lang xigua_hb:qks1} <em class='main_color'>{$v[hbtiaojian]} {lang xigua_hb:ren}{lang xigua_hb:ll}</em>, {lang xigua_hb:qks2} <em class='color-red2'>{$oldhbtmp1} {lang xigua_hb:yuan}{lang xigua_hb:hb}</em><br>{lang xigua_hb:qks3} <em class='main_color'>{echo count($hbuserlist1);} {lang xigua_hb:ren}{lang xigua_hb:ll}</em></div><div class='cl'><!--{loop $hbuserlist1 $_k $_v}--><div class='hvlist'><img onerror=\"this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'\" src='{avatar($_v[uid], 'middle', 1)}' /></div><!--{/loop}--></div>",
    buttons: [{text:'{lang xigua_hb:close}', className: "default", onClick:function () {}}, { text: "{lang xigua_hb:qks}", onClick: function(){
        <!--{if !$_GET[edid]}-->
        localStorage.setItem('shwetip_$shid', 1);
        hb_jump('$SCRITPTNAME?id=xigua_hs&ac=view&shid=$shid&edid={$_G[uid]}')
        <!--{else}-->
        $('.hs_share').trigger('click');
        <!--{/if}-->
    }}]
});return false;}
</script><!--{/if}-->