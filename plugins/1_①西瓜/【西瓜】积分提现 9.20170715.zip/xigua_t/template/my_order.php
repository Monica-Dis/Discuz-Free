<?php exit('hehehe!') ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport"
          content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <link href="source/plugin/xigua_t/static/common.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_t/static/iconfont.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_t/static/weui.css?{VERHASH}" rel="stylesheet"/>
    <script src="source/plugin/xigua_t/static/jquery.min.js?{VERHASH}"></script>
    <script src="source/plugin/xigua_t/static/custom.js?{VERHASH}"></script>
    <style>.topnav{background:#F6584F;position:relative;}.topnav .home-return{top:0}
        .js_dialog .weui-label { width: 55px; text-align: left; }
        .js_dialog .weui-dialog__bd {padding-left:.6rem;padding-right:.6rem}
        .js_dialog .weui-cells_form ,.delmark{display:none}
        .weui-cell_link div{font-size:17px;margin:10px 0 }
        .thc{color: #999;font-size: 14px;}
    </style>
    <!--{if $config[bgcolor]}-->
    <style>
        .topnav{background:{$config[bgcolor]}}
    </style>
    <!--{/if}-->
</head>
<body>
<div id="page-loading-overlay">
    <div class="ajxloading"></div>
</div>
<!--{if $apple}-->
<!--{else}-->
<div class="topnav cl">
    <a class="home-return" href="plugin.php?id=xigua_t">{lang xigua_t:back}</a>
</div>
<!--{/if}-->
<div class="container_map_ami container_map">
    <div class="weui-cells__title">$navtitle</div>
        <!--{if $res}-->

    <!--{eval
        include template('xigua_t:my_order_item');
        echo $html;
    }-->
        <!--{else}-->
    <div class="weui-panel">
        <div class="weui-panel__bd">
            <div class="weui-media-box weui-media-box_text">
                <h4 class="weui-media-box__title">{lang xigua_t:none}</h4>
            </div>
        </div>
    </div>
        <!--{/if}-->

    </div>
</div>
<div id="backtotop" class="backtotop"><span class="icon-vertical-align-top"></span></div>

<script>
    var p=1;
    var stop=true;
    var endstop=0;
    $(window).scroll(function() {
        if(endstop){
            return ;
        }
        if ($(this).scrollTop() + $(window).height() + 100 >= $(document).height() && $(this).scrollTop() > 100) {
            if(stop==true){
                stop=false;
                p=p+1;
                var url = window.location.href + '&ajax=1&page='+p;
                $(".container_map").append('<div class="weui-loadmore"><i class="weui-loading"></i><span class="weui-loadmore__tips">{lang xigua_t:l1}</span></div>');
                $.ajax({
                    url:url,
                    type:'get',
                    async:false,
                    cache:false,
                    success:function (data) {
                        $(".weui-loadmore").remove();
                        if(data){
                            $(".container_map").append(data);
                            stop=true;
                        }else{
                            endstop = 1;
                        }
                    }
                });
            }
        }
    });
</script>
</body>
</html>