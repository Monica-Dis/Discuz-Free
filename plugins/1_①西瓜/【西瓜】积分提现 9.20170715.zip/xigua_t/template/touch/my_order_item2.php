
{block html}
<!--{loop $res $k $v}-->
<div class="weui-panel">
    <div class="weui-panel__bd">
        <div class="weui-media-box weui-media-box_text">
            <h4 class="weui-media-box__title">{lang xigua_t:chongzhi}{$v[amount]}{lang xigua_t:GDP}</h4>
            <p class="weui-media-box__desc">$v[bank_name] $v[account_name] $v[account]</p>
            <ul class="weui-media-box__info">
                <li class="weui-media-box__info__meta">$v[addfundamount]  $_G['setting']['extcredits'][$v['ctype']]['title']</li>
                <li class="weui-media-box__info__meta">{eval $crts= date('m-d H:i', $v[crts]); }{$crts}</li>
                <li class="weui-media-box__info__meta weui-media-box__info__meta_extra">$status[$v[status]]</li>
                <!--{if $v[upts]}-->
                <li class="weui-media-box__info__meta ">{eval $upts= date('m-d H:i', $v[upts]); }{$upts}</li>
                <!--{/if}-->
            </ul>
        </div>
    </div>
</div>
<!--{/loop}-->
{/block}