<?php exit('hehehe!') ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport"
          content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <link href="source/plugin/xigua_t/static/common.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_t/static/iconfont.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_t/static/weui.css?{VERHASH}" rel="stylesheet"/>
    <script src="source/plugin/xigua_t/static/jquery.min.js?{VERHASH}"></script>
    <script src="source/plugin/xigua_t/static/custom.js?{VERHASH}"></script>
    <style>.topnav{background:#F6584F;position:relative;}.topnav .home-return{top:0}
        .js_dialog .weui-label { width: 55px; text-align: left; }
        .js_dialog .weui-dialog__bd {padding-left:.6rem;padding-right:.6rem}
        .js_dialog .weui-cells_form ,.delmark{display:none}
        .weui-cell_link div{font-size:17px;margin:10px 0 }
        .thc{color: #999;font-size: 14px;}
    </style>
    <!--{if $config[bgcolor]}-->
    <style>
        .topnav{background:{$config[bgcolor]}}
    </style>
    <!--{/if}-->
</head>
<body>
<div id="page-loading-overlay">
    <div class="ajxloading"></div>
</div>
    <!--{if $apple}-->
    <!--{else}-->
<div class="topnav cl">
    <a class="home-return" href="plugin.php?id=xigua_t">{lang xigua_t:back}</a>
</div>
    <!--{/if}-->
<div class="container_map_ami container_map">
    <div class="weui-cells__title">{lang xigua_t:z1}</div>
    <div class="weui-cells weui-cells_radio">
        <form action="plugin.php?id=xigua_t:index" method="post" id="setdefault">
            <input name="setdefault" value="1" type="hidden">
            <input name="formhash" value="{FORMHASH}" type="hidden">
            <!--{eval $count = count($datalist)-1;$checked =0;}-->
        <!--{loop $datalist $k $v}-->
        <label class="weui-cell weui-check__label" for="x{$k}">
            <div class="weui-cell__bd">
                <p>$v[bank_name]<!--{if $v[account_name]}-->($v[account_name])<!--{/if}--></p>
                <p class="thc">$v[account]</p>
            </div>
            <div class="weui-cell__ft">
                <input type="radio" class="weui-check" name="radio1" value="$v[id]" data-id="$v[id]" id="x{$k}"
                <!--{if $v['isdefault']}-->
                <!--{eval $checked=1;}-->
                checked
                <!--{/if}-->
                <!--{if !$checked && $count==$k}-->checked<!--{/if}-->
                >
                <span class="weui-icon-checked"></span>
            </div>
        </label>
        <!--{/loop}-->
        <a href="javascript:void(0);" class="weui-cell weui-cell_link" id="showActionSheet">
            <div class="weui-cell__bd">{lang xigua_t:z2}</div>
        </a>
        <a href="javascript:void(0);" class="weui-cell weui-cell_link" id="showActionSheet2">
            <div class="weui-cell__bd">{lang xigua_t:z3}</div>
        </a>
        </form>
    </div>
</div>

<!--{eval $cardtype = unserialize($config['cardtype']);}-->
<div>
    <div class="weui-mask" id="iosMask" style="display: none"></div>
    <div class="weui-actionsheet" id="iosActionsheet">
        <div class="weui-actionsheet__menu">
            <!--{if in_array(1,$cardtype)}--><div class="weui-actionsheet__cell iositem imark" data-value="ali">{lang xigua_t:z4}</div><!--{/if}-->
            <!--{if in_array(2,$cardtype)}--><div class="weui-actionsheet__cell iositem imark" data-value="cwxnum">{lang xigua_t:z6}</div><!--{/if}-->
            <!--{if in_array(3,$cardtype)}--><div class="weui-actionsheet__cell iositem imark" data-value="bank">{lang xigua_t:账号地址}</div><!--{/if}-->
            <!--{if in_array(4,$cardtype)}--><!--{if INC_WECHAT && $wxpay}--><div class="weui-actionsheet__cell iositem imark" data-value="cwx">{lang xigua_t:z5}</div><!--{/if}--><!--{/if}-->



            <!--{loop $datalist $v}-->
            <div class="weui-actionsheet__cell iositem delmark" data-del="$v[id]">$v[bank_name] $v[account]</div>
            <!--{/loop}-->
        </div>
        <div class="weui-actionsheet__action">
            <div class="weui-actionsheet__cell" id="iosActionsheetCancel">{lang xigua_t:q4}</div>
        </div>
    </div>
</div>

<!--BEGIN dialog1-->
<div id="dialogs">
<div class="js_dialog" id="iosDialog1" style="display: none;">
    <div class="weui-mask"></div>
    <form action="plugin.php?id=xigua_t:index" method="post" onsubmit="return checkfotm();" id="methodform">
        <input name="methodform" value="1" type="hidden">
        <input name="formhash" value="{FORMHASH}" type="hidden">
    <div class="weui-dialog">
        <div class="weui-dialog__hd"><strong class="weui-dialog__title"></strong></div>
        <div class="weui-dialog__bd">
            <div class="weui-cells_form bank">
                <div class="weui-cell">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_t:钱包名称}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" required name="account_name[bank]" type="text" placeholder="{lang xigua_t:请输入名称，如Imtoken}">
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_t:随机码}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" required name="account[bank]" type="number" pattern="[0-9]*" placeholder="{lang xigua_t:请输入1-9的随机码}">
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_t:账号地址}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="bank_name" type="text" placeholder="{lang xigua_t:请输入0x开头的账户地址}">
                    </div>
                </div>
            </div>
            <div class="weui-cells_form cwxnum">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <input class="weui-input" required name="account[cwxnum]" type="text" placeholder="{lang xigua_t:x5}">
                    </div>
                </div>
            </div>
            <div class="weui-cells_form ali">
                <div class="weui-cell">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_t:x6}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" required name="account_name[ali]" type="text" placeholder="{lang xigua_t:x7}">
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_t:x8}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" required name="account[ali]" type="text" placeholder="{lang xigua_t:x9}">
                    </div>
                </div>
            </div>
            <div class="weui-cells_form del_cell"></div>
        </div>
        <div class="weui-dialog__ft">
            <a href="javascript:;" class="weui-dialog__btn weui-dialog__btn_default">{lang xigua_t:q4}</a>
            <a href="javascript:;" class="weui-dialog__btn weui-dialog__btn_primary">{lang xigua_t:c1}</a>
        </div>
    </div>
    </form>
</div>
</div>
<!--END dialog1-->

<!--BEGIN toast-->
<div id="toast" style="display: none;">
    <div class="weui-mask_transparent"></div>
    <div class="weui-toast">
        <i class="weui-icon-success-no-circle weui-icon_toast"></i>
        <p class="weui-toast__content">{lang xigua_t:c3}</p>
    </div>
</div>
<!--end toast-->


<script>
    function showtip() {
        var toast = $('#toast');
        if (toast.css('display') != 'none') return;

        toast.fadeIn(100);
        setTimeout(function () {
            toast.fadeOut(100);
        }, 2000);
    }
    function checkfotm() {
        var ret = 0;
        $('.weui-cells_form:visible .weui-input').each(function () {
            if($(this).attr('required') && !$(this).val() && !ret){
                alert($(this).attr('placeholder'));
                setTimeout(function () {
                    $(this).focus();
                },200);
                ret =1;
            }
        });
        console.log(ret);
        if(ret){
            return false;
        }
        $.post($('#methodform').attr('action'), $('#methodform').serialize(), function (data) {
            if(data>0){
                showtip();
                setTimeout(function () {
                    window.location.reload();
                }, 2000);
            }
        });
        return false;
    }
    $(function(){

        $('input[name="radio1"]').on("click", function () {
            $('#setdefault').submit();
        });

        $('.weui-dialog__btn_primary').on('click', function () {
            $('#methodform').submit();
        });

        function js_dialog(){
            $(this).parents('.js_dialog').fadeOut(200);
        }
        var iosDialog1 = $('#iosDialog1');
        $('#dialogs').on('click', '.weui-dialog__btn_default', js_dialog);

        var iosActionsheet = $('#iosActionsheet');
        var iosMask = $('#iosMask');
        var iositem = $('.iositem');

        function hideActionSheet() {
            iosActionsheet.removeClass('weui-actionsheet_toggle');
            iosMask.fadeOut(200);
        }

        iosMask.on('click', hideActionSheet);
        iositem.on('click', function () {
            var type = $(this).attr('data-value');
            var del = $(this).attr('data-del');
            $('.weui-dialog__title').html($(this).html());
            $('.weui-cells_form').hide();
            $('.del_cell').html('');
            if(type){
                if(type=='cwx'){
                    window.location.href = 'plugin.php?id=xigua_t&ac=method&bindmethod=1';
                    return ;
                }else{
                    $('.'+type).show();
                }
            }else if(del){
                $('.del_cell').show().html('{lang xigua_t:c2}'+$(this).html()+'?'+'<input type="hidden" name="del_id" value="'+del+'" />');
            }
            iosDialog1.fadeIn(200);
            hideActionSheet();
            setTimeout(function () {
                $('.weui-cell input:first-child').focus();
            },50);
        });
        $('#iosActionsheetCancel').on('click', hideActionSheet);
        $("#showActionSheet").on("click", function(){
            $('.imark').show();
            $('.delmark').hide();
            iosActionsheet.addClass('weui-actionsheet_toggle');
            iosMask.fadeIn(200);
        }); $("#showActionSheet2").on("click", function(){
            $('.imark').hide();
            $('.delmark').show();
            iosActionsheet.addClass('weui-actionsheet_toggle');
            iosMask.fadeIn(200);
        });
    });
</script>
</body>
</html>