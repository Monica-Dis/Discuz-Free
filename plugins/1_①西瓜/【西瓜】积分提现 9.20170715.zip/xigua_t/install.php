<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/1/23
 * Time: 17:20
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_t_card` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `type` varchar(20) NOT NULL,
 `account` varchar(800) NOT NULL,
 `account_name` varchar(2000) NOT NULL,
 `bank_name` varchar(2000) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `isdefault` int(1) NOT NULL DEFAULT '0',
 `openid` varchar(80) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `isdefault` (`isdefault`)
) ENGINE=InnoDB ;

CREATE TABLE IF NOT EXISTS `pre_xigua_t_tixian` (
 `tixianid` char(24) NOT NULL,
 `amount` decimal(10,2) NOT NULL,
 `crts` int(11) NOT NULL,
 `return_msg` varchar(200) NOT NULL,
 `err_code_des` varchar(500) NOT NULL,
 `return_code` varchar(20) NOT NULL,
 `openid` char(32) NOT NULL,
 `uid` int(11) NOT NULL,
 `account` varchar(800) NOT NULL,
 `type` varchar(20) NOT NULL,
 `bank_name` varchar(2000) NOT NULL,
 `account_name` varchar(800) NOT NULL,
 `ctype` int(11) NOT NULL,
 `bilv` int(11) NOT NULL,
 `sxf` int(11) NOT NULL,
 `addfundamount` int(11) NOT NULL,
 `status` int(1) NOT NULL,
 `upts` int(11) NOT NULL,
 `note` varchar(2000) NOT NULL,
 PRIMARY KEY (`tixianid`)
) ENGINE=InnoDB;
SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_t/discuz_plugin_xigua_t.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_t/discuz_plugin_xigua_t_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_t/discuz_plugin_xigua_t_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_t/discuz_plugin_xigua_t_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_t/discuz_plugin_xigua_t_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_t/install.php');


$pluginid = 'xigua_t';

$Hooks = array(
    'profile_extraInfo'
);

$data = array();
foreach($Hooks as $Hook) {
    $data[] = array(
        $Hook => array(
            'plugin' => $pluginid,
            'include' => 'api.class.php',
            'class' => $pluginid,
            'method' => $Hook,
            'order' => 999,
        )
    );
}

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);
