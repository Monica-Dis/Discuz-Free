<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * Date: 2016/10/21
 * Time: 16:01
 */
include_once DISCUZ_ROOT .'source/plugin/xigua_t/common.php';

if(!$_G['uid']){
    $loginurl = $_G['siteurl'].'member.php?mod=logging&action=login&mobile=2';
    if(INC_WECHAT){
        if($_G['cache']['plugin']['xigua_login']){
            $loginurl = $_G['siteurl'].'plugin.php?id=xigua_login:login&backreferer='.urlencode(current_url());
        }
    }
    dheader('Location: '.$loginurl);
}

$wxpay = $config['appid'] && $config['appsecert'] && $config['key'];


if(INC_WECHAT && $wxpay && !$_GET['formhash'] && $_GET['bindmethod']){
    $tools = new JsApiPaySF();
    $openid = $_G['cookie'][$ckey1] ? authcode($_G['cookie'][$ckey1], 'DECODE', $authkey) : '';
    if(! $openid){
        $opendata = $tools->GetOpenid();
        if($openid = $opendata['openid']){
            dsetcookie($ckey1, authcode($openid, 'ENCODE', $authkey), 7100);
            dsetcookie('reaccesstoken', authcode($opendata['access_token'], 'ENCODE', $authkey), 7100);
        }
    }
    $wxuser = $tools->getUserInfoById(authcode($_G['cookie']['reaccesstoken'], 'DECODE', $authkey), $openid);
    foreach ($wxuser as $index => $item) {
        $wxuser[$index] = diconv($wxuser[$index], 'utf-8');
    }

    if($wxuser){
        C::t('#xigua_t#xigua_t_card')->insert_card('cwx', "<img style='height:20px;vertical-align:middle' src='{$wxuser['headimgurl']}' /> {$wxuser['nickname']}", '', lang('plugin/xigua_t', 'bddwx'), $openid);
        dheader('location: plugin.php?id=xigua_t&ac=method');
    }
}
//loadcache('creditrule');
//print_r($_G['cache']['creditrule']);
$creditsformulaexp = str_replace('*', 'X', $_G['setting']['creditsformulaexp']);
$creditype = $_G['setting']['extcredits'][$config['ctype']]['title'];
$creditunit = $_G['setting']['extcredits'][$config['ctype']]['unit'];

//print_r($tmp2);

$lpp  = 15;
$page = max(1, intval($_GET['page']));
$start_limit = ($page - 1) * $lpp;

if($_GET['ac'] == 'order'){


    $res = C::t('#xigua_t#xigua_t_tixian')->fetch_by_uid($_G['uid'], $start_limit, $lpp);

    if($_GET['ajax']){
        include template('xigua_t:my_order_item');
        echo trim($html);
        exit;
    }

    $status = array(
        0 => '<strong style="color:orangered;">'.lang('plugin/xigua_t', 'weidakuan').'</strong>',
        1 => '<strong style="color:forestgreen;">'.(lang('plugin/xigua_t','succeed2')).'</strong>',
        2 => '<strong style="color:grey;">'.(lang('plugin/xigua_t','canceled2')).'</strong>',
    );

    $navtitle = lang('plugin/xigua_t', 'myorder_title');
    include template('xigua_t:my_order');
}else if($_GET['ac']=='method'){
    $navtitle = $config['title'] ? $config['title']: lang('plugin/xigua_t', 'jifen');
    $datalist = C::t('#xigua_t#xigua_t_card')->fetch_list($_G['uid']);
//    print_r($datalist);
    include template('xigua_t:method');
}else{
    $navtitle = $config['title'] ? $config['title']: lang('plugin/xigua_t', 'jifen');
    $nocard = 0;
    $default = C::t('#xigua_t#xigua_t_card')->get_default($_G['uid']);
    if(!$default){
        $default['bank_name'] = '<span class="weui-cell_warn">'.lang('plugin/xigua_t','q1').'</span>';
        $default['account'] = lang('plugin/xigua_t','.');
        $nocard = 1;
    }
    include template('xigua_t:credit');
}