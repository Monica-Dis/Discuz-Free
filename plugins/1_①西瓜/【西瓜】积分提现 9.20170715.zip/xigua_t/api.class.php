<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * Date: 2016/1/26
 * Time: 15:15
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class xigua_t
{
    function profile_extraInfo()
    {
        global $_G;
        $link = $_G['siteurl']. 'plugin.php?id=xigua_t';
        $return[] = array(
            'name' => "<a href='$link'>".lang('plugin/xigua_t', 'datixian')."</a>",
            'link' => $link,
        );
        return $return;
    }
}