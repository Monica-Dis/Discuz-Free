<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * Date: 2016/1/22
 * Time: 16:38
 */

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!function_exists('curl_init')){
    exit('Missing curl extension! DISM.TAOBAO.COM');
}
if(!function_exists('openssl_csr_export')){
    exit('Missing openssl extension! DISM.TAOBAO.COM');
}

$pluginversion = '20161023';

global $_G;
if(!$_G['cache']['plugin']){
    loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_t'];
$authkey = $_G['config']['security']['authkey'];

include_once libfile('function/cache');

define('SF_APPID', trim($config['appid']));
define('SF_MCHID', trim($config['shanghuid']));
define('SF_APPSECRET', trim($config['appsecert']));
define('SF_WXPAY_KEY', trim($config['key']));
define('SF_NOTIFY_URL', $_G['siteurl'].'source/plugin/xigua_t/notify.inc.php');
define('INC_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
$repath = './source/plugin/xigua_t/cache/';


include_once DISCUZ_ROOT."source/plugin/xigua_t/lib/wxpay/lib/WxPay.Config.php";
include_once DISCUZ_ROOT."source/plugin/xigua_t/lib/wxpay/lib/WxPay.Api.php";
include_once DISCUZ_ROOT."source/plugin/xigua_t/lib/wxpay/example/WxPay.JsApiPay.php";
include_once DISCUZ_ROOT.'source/plugin/xigua_t/lib/wxpay/example/WxPay.NativePay.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_t/lib/wxpay/example/log.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_t/lib/wxpay/lib/WxPay.Data.php';
$ckey1  = substr(md5(VERHASH.$_G['siteurl'].SF_APPID.SF_MCHID.SF_APPSECRET), 0, 9);

if(!function_exists('current_url')) {
    function current_url() {
        $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
        $php_self = $_SERVER['PHP_SELF'] ? safe_replace($_SERVER['PHP_SELF']) : safe_replace($_SERVER['SCRIPT_NAME']);
        $path_info = isset($_SERVER['PATH_INFO']) ? safe_replace($_SERVER['PATH_INFO']) : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? safe_replace($_SERVER['REQUEST_URI']) : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.safe_replace($_SERVER['QUERY_STRING']) : $path_info);
        return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
    }
}

/**
 * @param $string
 * @return mixed
 */
if(!function_exists('safe_replace')) {
    function safe_replace($string) {
        $string = str_replace('%20','',$string);
        $string = str_replace('%27','',$string);
        $string = str_replace('%2527','',$string);
        $string = str_replace('*','',$string);
        $string = str_replace('"','&quot;',$string);
        $string = str_replace("'",'',$string);
        $string = str_replace('"','',$string);
        $string = str_replace(';','',$string);
        $string = str_replace('<','&lt;',$string);
        $string = str_replace('>','&gt;',$string);
        $string = str_replace("{",'',$string);
        $string = str_replace('}','',$string);
        $string = str_replace('\\','',$string);
        return $string;
    }
}
if(!function_exists('js_reajaxget')) {
    function js_reajaxget($link, $ext)
    {
        return '<a href="' . $link . '" onclick="ajaxget(\'' . $link . '\', \'gridtable\');return false;"' . $ext . '>';
    }
}

if(!function_exists('ToUrlParams')){
    function ToUrlParams($urlObj)
    {
        $buff = "";
        foreach ($urlObj as $k => $v)
        {
            $buff .= $k . "=" . $v . "&";
        }

        $buff = trim($buff, "&");
        return $buff;
    }
}

$apple = 0;
if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPad')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPod')){
    $apple = 1;
}
if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false){
    $apple = 1;
}

$sxf = $bilv = $tmp = $tmp2 = array();
foreach (explode("\n", trim($config['bilv'])) as $index => $item) {
    list($k, $v) = explode('=', trim($item));
    list($tmpv1, $tmpv2) = explode('/', $v);
    $tmp[$k] = $tmpv2 ? ($tmpv1/$tmpv2) : 0;
}
foreach (explode("\n", trim($config['sxf'])) as $index => $item) {
    list($k, $v) = explode('=', $item);
    $tmp2[$k] = floatval(str_replace('%', '', $v));
}
foreach ($_G['setting']['extcredits'] as $cid => $extcredit) {
    if($tmp[$extcredit['title']]){
        $bilv[$cid] = $tmp[$extcredit['title']];
    }
    if(isset($tmp2[$extcredit['title']])){
        $sxf[$cid] = $tmp2[$extcredit['title']];
    }
}