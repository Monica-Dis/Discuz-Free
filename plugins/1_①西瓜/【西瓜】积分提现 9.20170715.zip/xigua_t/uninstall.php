<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$pluginid = 'xigua_t';


function xgb_delete_all($directory, $empty = false, $strict = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return true;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    $ret = xgb_delete_all($path, $empty, $strict);
                    if($strict && !$ret){
                        return false;
                    }
                } else {
                    if(!@unlink($path)){
                        if($strict){
                            return false;
                        }
                    }
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}


xgb_delete_all(DISCUZ_ROOT . './source/plugin/xigua_t', true);
@rmdir(DISCUZ_ROOT . './source/plugin/xigua_t');

$sql = <<<SQL
  DROP TABLE pre_xigua_t_card;
  
  DROP TABLE pre_xigua_t_tixian;
SQL;
runquery($sql);

$finish = TRUE;
require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::delAPIHook($pluginid);
