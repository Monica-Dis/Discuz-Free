<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 15/9/3
 * Time: 17:31
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$page = max(1, intval(getgpc('page')));
$lpp   = 30;
$start_limit = ($page - 1) * $lpp;
$url = "plugins&operation=config&do=$pluginid&identifier=xigua_login&pmod=user&page=$page";

if(submitcheck('acter') ){
    $uid = intval($_GET['actid']);
    $username = DB::result_first('SELECT username FROM %t WHERE uid=%d', array('common_member', $uid));

    switch ($_GET['acter']){
        case 'unbindanddel':

            include_once libfile('function/delete');
            $numdeleted = deletemember(array($uid), 0);
            loaducenter();
            uc_user_delete(array($uid));
            cpmsg(sprintf(lang('plugin/xigua_login', 'delete_succeed1'), 'UID��'.$uid.' '.$username) , "action=$url", 'succeed');

            break;
        case 'unbinduser':
            if(DB::query("DELETE FROM %t WHERE userid=%d LIMIT 1", array('user_weixin_relations', $uid))){

                include_once DISCUZ_ROOT.'source/plugin/xigua_login/function.php';
                remove_magapp($uid);

                cpmsg(sprintf(lang('plugin/xigua_login', 'delete_succeed2'), 'UID��'.$uid.' '.$username), "action=$url", 'succeed');
            }
            break;
    }
}

if(submitcheck('searchtxt')){
    $txt = stripsearchkey($_GET['searchtxt']);
    if(is_numeric($txt)){
        $user = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('common_member', array($txt)), 'uid');
    }else{
        $user = DB::fetch_all("SELECT * FROM %t WHERE username LIKE %s", array('common_member', '%'.$txt.'%'), 'uid');
    }
    foreach ($user as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
    }

    $list  = DB::fetch_all('SELECT *,userid as uid FROM %t WHERE userid IN (%n)', array('user_weixin_relations', $uids), 'uid');

    $count = count($user);
}
else
{
    $list  = DB::fetch_all("SELECT *,userid as uid FROM %t ORDER BY userid DESC " . DB::limit($start_limit, $lpp), array('user_weixin_relations'));
    foreach ($list as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
    }
    $user = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');

    $count = DB::result_first('SELECT count(*) as c FROM '.DB::table('user_weixin_relations'));
}

$multipage = multi($count, $lpp, $page, ADMINSCRIPT."?action=$url");

showformheader($url,'','vlist');

echo '<div><input type="text" id="searchtxt" name="searchtxt" value="'.$txt.'" class="txt" /> <input type="submit" class="btn" value="'.cplang('search').'" /></div>';
showtableheader(('manage_user'));

$rowhead = array(
    'openid',
    'unionid',
    'UID',
    cplang('username'),
    cplang('forums_edit_perm_formula_regdate'),
);

showtablerow('class="header"', array(), $rowhead);
$lang_unbind = lang('plugin/xigua_login', 'unbind');
$lang_unbindandel = lang('plugin/xigua_login', 'unbindanddel');
$confirm1 = lang('plugin/xigua_login', 'confirm1');
$confirm2 = lang('plugin/xigua_login', 'confirm2');

foreach ($list as $row) {
    $uid = $row['uid'];
    $username = $user[$uid]['username'];

    $rowbody = array(
        $row['openid'],
        $row['unionid'],
        $uid,
        "<img src='".avatar($uid, 'small', true)."' style='vertical-align:middle;height:20px;width:20px;' /> $username",
        date('Y-m-d H:i:s', $user[$uid]['regdate']),
        "<a onclick=\"return unbinduser($uid, '$username');\" class=\"btn\">$lang_unbind</a>"
    );
    showtablerow('', array(), $rowbody);
}

showtablerow('', 'colspan="99"', $multipage.'<input type="hidden" name="actid" id="actid" value="0" /><input type="hidden" name="acter" id="acter" value="" />');
showtablefooter(); //Dism��taobao��com
showformfooter(); /*dis'.'m.tao'.'bao.com*/
?>
<script>
    function unbinduser(uid, username){
        if(confirm('<?php echo $confirm2; ?>'.replace('%s', 'UID:'+uid+' '+username))) {
            $('actid').value = uid;
            $('acter').value = 'unbinduser';
            $('vlist').submit();
        }
        return false;
    }
    function unbindanddel(uid, username){
        if(confirm('<?php echo $confirm1; ?>'.replace('%s', 'UID:'+uid+' '+username))) {
            $('actid').value = uid;
            $('acter').value = 'unbindanddel';
            $('vlist').submit();
            return false;
        }
    }
</script>