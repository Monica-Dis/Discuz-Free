<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/7/16
 * Time: 21:40
 */

$pluginid = 'xigua_login';

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_user_qq_relations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `create_time` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `phone` (`openid`)
) ENGINE=MyISAM;


CREATE TABLE IF NOT EXISTS `pre_user_weixin_relations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned DEFAULT NULL,
  `unionid` varchar(255) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `create_time` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `phone` (`unionid`)
) ENGINE=MyISAM;


CREATE TABLE IF NOT EXISTS `pre_user_weixin_relations_copy` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned DEFAULT NULL,
  `unionid` varchar(255) DEFAULT NULL,
  `openid` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `create_time` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  KEY `phone` (`unionid`)
) ENGINE=MyISAM;
SQL;
runquery($sql);

$r1 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'conuintoken\'', array('common_member_connect'), true);
if(!$r1){
    $sql .= <<<SQL
ALTER TABLE `pre_common_member_connect` ADD  `conuintoken` CHAR( 32 ) NOT NULL ;
SQL;
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'conuintoken\'', array('common_connect_guest'), true);
if(!$r2){
    $sql .= <<<SQL

ALTER TABLE `pre_common_connect_guest` ADD  `conuintoken` CHAR( 32 ) NOT NULL ;
SQL;
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'unionid\'', array('common_member_wechat'), true);
if(!$r2){
    $sql .= <<<SQL

ALTER TABLE `pre_common_member_wechat` ADD `unionid` VARCHAR(80) NOT NULL AFTER `isregister`;
ALTER TABLE `pre_common_member_wechat` ADD INDEX(`unionid`);
SQL;
}

if($sql){
    runquery($sql);
}

@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/install.php');
$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/install.php');