<?php
/**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * Date: 2016/3/10
 * Time: 21:35
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
if(function_exists('match412')){
    function match412(array $match) {
        return strlen($match[0]) >= 4 ? '' : $match[0];
    }
}

if(!function_exists('filterEmoji12')){
    function filterEmoji12($str){
        $str = preg_replace_callback( '/./u', 'match412', $str);

        $str = diconv($str, 'utf-8', 'gbk');
        $str = diconv($str, 'gbk', 'utf-8');

        $str = safe_replace($str, 1);
        return $str;
    }
}

if(!function_exists('current_url')) {
    function current_url() {
        $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
        $php_self = $_SERVER['PHP_SELF'] ? safe_replace($_SERVER['PHP_SELF']) : safe_replace($_SERVER['SCRIPT_NAME']);
        $path_info = isset($_SERVER['PATH_INFO']) ? safe_replace($_SERVER['PATH_INFO']) : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? safe_replace($_SERVER['REQUEST_URI']) : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.safe_replace($_SERVER['QUERY_STRING']) : $path_info);
        return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
    }
}
if(!function_exists('safe_replace')) {
    function safe_replace($string) {
        $string = str_replace('%20','',$string);
        $string = str_replace('%27','',$string);
        $string = str_replace('%2527','',$string);
        $string = str_replace('*','',$string);
        $string = str_replace('"','&quot;',$string);
        $string = str_replace("'",'',$string);
        $string = str_replace('"','',$string);
        $string = str_replace(';','',$string);
        $string = str_replace('<','&lt;',$string);
        $string = str_replace('>','&gt;',$string);
        $string = str_replace("{",'',$string);
        $string = str_replace('}','',$string);
        $string = str_replace('\\','',$string);
        return $string;
    }
}

include_once libfile('function/cache');
include_once libfile('function/member');
@include_once DISCUZ_ROOT.'./source/plugin/mobile/qrcode.class.php';
include_once DISCUZ_ROOT. 'source/plugin/wechat/wechat.lib.class.php';
include_once 'function.php';

$config = $_G['cache']['plugin']['xigua_login'];
$authkey = $_G['config']['security']['authkey'];
define('WX_APPID', trim($config['appid']));
define('WX_APPSECRET', trim($config['appsecert']));
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);

$cookie = substr(md5('wechatdd'.$_G['siteurl'].WX_APPID), 0, 8);
$openid = !empty($_G['cookie'][$cookie]) ? authcode($_G['cookie'][$cookie], 'DECODE', $authkey) : '';
$wechat_client = new WeChatClient(WX_APPID, WX_APPSECRET);

if(strpos($_GET['backreferer'], 'logout') !== false){
    $_GET['backreferer'] = $_G['siteurl'];
}

if(isset($_GET['check'])) {
    $code = authcode(base64_decode($_GET['check']), 'DECODE', $authkey);
    if($code) {
        $authcode = C::t('#wechat#mobile_wechat_authcode')->fetch_by_code($code);
        if($authcode['status']) {
            require_once libfile('function/member');
            $member = getuserbyuid($authcode['uid'], 1);
            setloginstatus($member, 1296000);
            dsetcookie('wechat_ticket', '', -1);
            $echostr = 'done';
        } else {
            $echostr = '1';//json_encode($authcode);
        }
    } else {
        $echostr = '-1';
    }

    if(!ob_start($_G['gzipcompress'] ? 'ob_gzhandler' : null)) {
        ob_start();
    }

    if($echostr === 'done'){
        C::t('#wechat#mobile_wechat_authcode')->delete($authcode['sid']);
    }

    include template('common/header_ajax');
    echo $echostr;
    include template('common/footer_ajax');
    exit;
}

if (IN_WECHAT && checkmobile()) {


    if(!$openid) {
        if(empty($_GET['oauth'])) {
            if($config['rhref'] = trim($config['rhref'])){
                $jieurl = (strpos($config['rhref'], 'http://') === false && strpos($config['rhref'], 'https://') === false) ? "http://" . $config['rhref'] : $config['rhref'];
                if(strpos($jieurl, '.html')===false){
                    $jieurl = rtrim($jieurl, '/').'/source/plugin/xigua_login/r.html';
                }

                $redirect_uri = urlencode($_G['siteurl'].'plugin.php?id=xigua_login:login&c='.urlencode($_GET['c']).'&oauth=yes&backreferer='.urlencode($_GET['backreferer']));
                $redirect_uri = "$jieurl?appid={$config['appid']}&redirect_uri={$redirect_uri}&response_type=code&scope=snsapi_userinfo&state=#wechat_redirect";
            }else{
                $redirect_uri = $wechat_client->getOAuthConnectUri($_G['siteurl'].'plugin.php?id=xigua_login:login&c='.urlencode($_GET['c']).'&oauth=yes&backreferer='.urlencode($_GET['backreferer']), '', 'snsapi_userinfo');
            }
            dheader('location: '.$redirect_uri);
        } else {
            $tockeninfo = $wechat_client->getAccessTokenByCode($_GET['code']);
            $access_token = $tockeninfo['access_token'];
            $openid = $tockeninfo['openid'];
            if(!$openid){
                showmessage($tockeninfo['errmsg']);
            }

            dsetcookie($cookie, authcode($openid, 'ENCODE', $authkey), 7100);
            dsetcookie('accessn', authcode($access_token, 'ENCODE', $authkey), 7100);
        }
    }

    $userinfo = $wechat_client->getUserInfoByAuth(authcode($_G['cookie']['accessn'], 'DECODE', $authkey), $openid);
    if($userinfo['errcode']){
        dsetcookie($cookie, '', -1);
        dsetcookie('accessn', '', -1);
        showmessage($userinfo['errmsg']);
    }
    $userinfo['nickname'] = filterEmoji12($userinfo['nickname']);
    foreach ($userinfo as $index => $item) {
        $userinfo[$index] = diconv($userinfo[$index], 'utf-8');
    }

    $authcode = C::t('#wechat#mobile_wechat_authcode')->fetch_by_code(authcode(base64_decode($_GET['c']), 'DECODE', $authkey));

    $succeed = 0;
    if(!$openid){
        showmessage('openid empty!');
    }
    $unionid = $userinfo['unionid'];
    if($unionid){
        $fetch =  DB::fetch_first('SELECT *,userid as uid FROM %t WHERE unionid=%s ORDER BY userid ASC', array('user_weixin_relations', $unionid));
    }
    if(!$fetch){
        $fetch =  DB::fetch_first('SELECT *,userid as uid FROM %t WHERE openid=%s ORDER BY userid ASC', array('user_weixin_relations', $openid));
    }

    /*��ͨ������̿�ʼ*/
    dsetcookie('appunionid', authcode($unionid, 'ENCODE', $authkey), 7100);
    if($unionid){

        if($fetch['uid'] && !$fetch['unionid']){
            DB::query("UPDATE %t SET unionid=%s where userid=%d ", array('user_weixin_relations',$unionid, $fetch['uid']));
        }

        if(!$fetch['uid']){
//            C::t('#xigua_login#user_weixin_relations')->delete(0);  //ɾ��uidΪ0

            $fetch =  DB::fetch_first('SELECT *,userid as uid FROM %t WHERE unionid=%s ORDER BY userid ASC', array('user_weixin_relations', $unionid));  //�Ȳ鱾�ر���û��
            if(!$fetch['uid']){  //���û�У����Դ���ױ���ȡ
                $fetch =  fetch_magapp($unionid);

                if($fetch['uid']){
                    $member_tmp = getuserbyuid($fetch['uid'], 1);
                    if(!$member_tmp){
                        remove_magapp($fetch['uid']);
                        $fetch = array();
                    }
                }

                if($fetch['uid']){  //�����ȡ��������ױ�ͬ����ϵͳ�ı�
                    xg_wechat_bind($fetch['uid'], $openid, $unionid, 0);
                }
            }
        }
    }

    if(!$fetch && $unionid){
        $fetch = DB::fetch_first('SELECT *,userid as uid FROM %t WHERE unionid=%s ORDER BY userid ASC', array('user_weixin_relations', $unionid));
    }

    if($fetch['uid']){
        $member_tmp = getuserbyuid($fetch['uid'], 1);
        if(!$member_tmp){
            $fetch = array();
            C::t('#xigua_login#user_weixin_relations')->delete($fetch['uid']);
        }
    }

    if(($uid = $fetch['uid'])){
        if(!$authcode['uid']){
            C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
            $succeed = 1;
            if($uid && $unionid){
                $upary = array();
                $upary['unionid'] = $unionid;
                if(IN_WECHAT){
                    $upary['openid'] = $openid;
                }
                C::t('#xigua_login#user_weixin_relations')->update($uid, $upary);
                set_magapp_connection($uid, $unionid);
            }

        }else if($authcode['uid'] != $fetch['uid']){
            showmessage(lang('plugin/xigua_login', 'tiptip3'));
        }else{
            C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
            $succeed = 1;
            if($uid && $unionid){
                $upary = array();
                $upary['unionid'] = $unionid;
                if(IN_WECHAT){
                    $upary['openid'] = $openid;
                }
                C::t('#xigua_login#user_weixin_relations')->update($uid, $upary);
                set_magapp_connection($uid, $unionid);
            }

        }
    }else{  //δ��
        if($authcode['uid']) {  //bind
            $uid = $authcode['uid'];
            $member = getuserbyuid($uid, 1);
            if($member){
                xg_wechat_bind($uid, $openid, $unionid);
                C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
                $succeed = 1;
            }
        } else {  // reg and bind

if($_G['cache']['plugin']['xigua_login']['wxmiao']){
            include_once DISCUZ_ROOT.'source/plugin/xigua_login/function.php';
            $userinfo['nickname'] = str_replace(array(" ", "\t", "\n", "\r"), '', $userinfo['nickname']);
            $uid = xg_register($userinfo['nickname'], $userinfo['headimgurl'], 1);

if($uid == '-9999' || $uid == -1|| $uid == -2|| $uid == -3 || !$uid){  //rename hack
    dsetcookie('reg_nickname', authcode($userinfo['nickname'], 'ENCODE', $authkey), 7100);
    dsetcookie('reg_headimgurl', authcode($userinfo['headimgurl'], 'ENCODE', $authkey), 7100);
    dsetcookie('reg_sid', authcode($authcode['sid'], 'ENCODE', $authkey), 7100);
    $url = $_GET['backreferer'] ? $_GET['backreferer']: ($config['weret'] ? $config['weret'] : $_G['siteurl']."home.php?mod=space&uid=$uid&do=profile&mycenter=1&mobile=2");
    dsetcookie('backreferer', $url, 7100);
    dheader('Location: plugin.php?id=xigua_login:reg&has=1');
    exit;
}
            if($uid){
                xg_wechat_bind($uid, $openid, $unionid);
                C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
                $succeed = 1;
            }
}else{
                dsetcookie('reg_nickname', authcode($userinfo['nickname'], 'ENCODE', $authkey), 7100);
                dsetcookie('reg_headimgurl', authcode($userinfo['headimgurl'], 'ENCODE', $authkey), 7100);
                dsetcookie('reg_sid', authcode($authcode['sid'], 'ENCODE', $authkey), 7100);
                $url = $_GET['backreferer'] ? $_GET['backreferer']: ($config['weret'] ? $config['weret'] : $_G['siteurl']."home.php?mod=space&uid=$uid&do=profile&mycenter=1&mobile=2");
                dsetcookie('backreferer', $url, 7100);
                dheader('Location: plugin.php?id=xigua_login:reg');
}
        }
    }
    if($succeed){
        require_once libfile('function/member');
        $member = getuserbyuid($uid, 1);
        setloginstatus($member, 1296000);
        $url = $_GET['backreferer'] ? $_GET['backreferer']: ($config['weret'] ? $config['weret'] : $_G['siteurl']."home.php?mod=space&uid=$uid&do=profile&mycenter=1&mobile=2");

    }else{
        $url = $_G['siteurl'];
    }

    if(strpos($url, 'oauthbase=yes')!==false || strpos($url, 'oauth=yes')!==false){
        $url = $_G['siteurl'];
    }
    if($config['weret']/* && stripos($_SERVER['HTTP_USER_AGENT'], 'miniProgram')!==false*/){
        $url = $config['weret'];
    }

    if($uid && $unionid){
        DB::query("UPDATE %t set unionid=%s where userid=%d limit 1", array('user_weixin_relations', $unionid, $uid));
    }
    dheader("Location: $url");

}else{

    $code = $i = 0;
    do {
        $code = rand(100000, 999999);
        $codeexists = C::t('#wechat#mobile_wechat_authcode')->fetch_by_code($code);
        $i++;
    } while($codeexists && $i < 10);

    $codeenc = urlencode(base64_encode(authcode($code, 'ENCODE', $authkey)));
    C::t('#wechat#mobile_wechat_authcode')->insert(array('sid' => $code, 'uid' => $_G['uid'], 'code' => $code, 'createtime' => TIMESTAMP), 0, 1);
    if(!discuz_process::islocked('clear_wechat_authcode')) {
        C::t('#wechat#mobile_wechat_authcode')->delete_history();
        discuz_process::unlock('clear_wechat_authcode');
    }

    $repath = './source/plugin/xigua_login/cache/';
    $bindurl = $_G['siteurl'] .'plugin.php?id=xigua_login:login&c='.$codeenc;
    $qrfile = $repath.$code.'.png';
    if(!is_file(DISCUZ_ROOT . $qrfile)){
        @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
        if (class_exists('QRcode')) {
            QRcode::png($bindurl, DISCUZ_ROOT . $qrfile, QR_ECLEVEL_L, 5);
        }
    }
    $qrcodeurl = $_G['siteurl'] . $qrfile;
    /*$qrcodeurl = 'http://qr.kegood.com/?m=0&e=L&p=10&url='.urlencode($bindurl);*/
    if ($config['pcsubscribe']||     0     ) {
        $qrcodeurl2 = $qrcodeurl;
        $qrcodeurl = $_G['siteurl'] . 'plugin.php?id=xigua_login:qrcode&ode=' . $code;
    }
    $tiptip = lang('plugin/xigua_login', 'tiptip2');
    include_once template('xigua_login:wechat_qrcode');
}