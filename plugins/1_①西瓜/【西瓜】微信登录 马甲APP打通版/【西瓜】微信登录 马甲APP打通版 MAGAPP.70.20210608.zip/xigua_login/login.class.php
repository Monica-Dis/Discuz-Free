<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2015/7/15
 * Time: 15:43
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

require_once libfile('function/member');
require_once DISCUZ_ROOT.'source/plugin/wechat/wechat.class.php';


class plugin_xigua_login{
    public function register_logging_method()
    {
        global $_G;
        $config = $_G['cache']['plugin']['xigua_login'];
        if(!$config['pcbind']){
            return '';
        }
        return '<a href="javascript:;" onclick="showWindow(\'wechat_bind1\', \'plugin.php?id=xigua_login:login\')"><img src="source/plugin/xigua_login/static/wechat_login1.png" align="absmiddle"></a> ';
    }

    public function global_usernav_extra1()
    {
        global $_G;
        $config = $_G['cache']['plugin']['xigua_login'];
        if(!$config['pcbind']){
            return '';
        }
        global $_G;
        $has = '<span class="pipe">|</span><a href="javascript:;" onclick="showWindow(\'wechat_bind1\', \'plugin.php?id=xigua_login:login\')"><img src="source/plugin/xigua_login/static/wechat_bind.png" class="qq_bind" align="absmiddle"></a> ';
        if($_G['uid']){
            $fetch = C::t('#xigua_login#user_weixin_relations')->fetch($_G['uid']);
            if($fetch){
                $has = '';
            }
        }
        return !$_G['uid'] ? '<span class="pipe">|</span><a href="javascript:;" onclick="showWindow(\'wechat_bind1\', \'plugin.php?id=xigua_login:login\')"><img src="source/plugin/xigua_login/static/wechat_login.png" class="qq_bind" align="absmiddle"></a> ' : $has;
    }

    public function global_login_text()
    {
        return $this->logging_method();
    }
    function logging_method()
    {
        global $_G;
        $config = $_G['cache']['plugin']['xigua_login'];
        if(!$config['pcbind']){
            return '';
        }
        return '<a href="javascript:;" onclick="showWindow(\'wechat_bind1\', \'plugin.php?id=xigua_login:login\')"><img src="source/plugin/xigua_login/static/wechat_login1.png" align="absmiddle"></a> ';
    }
    function global_login_extra(){
        global $_G;
        $config = $_G['cache']['plugin']['xigua_login'];
        if(!$config['pcbind']){
            return '';
        }
        return "<div class=\"fastlg_fm y\" style=\"margin-right: 10px; padding-right: 10px\">
		<p><a href=\"javascript:;\" onclick=\"showWindow('wechat_bind1', 'plugin.php?id=xigua_login:login')\"><img src=\"source/plugin/xigua_login/static/wechat_login1.png\" class=\"vm\"/></a></p>
		<p class=\"hm xg1\" style=\"padding-top: 2px;\">{$config['onekey']}</p>
	</div>";
    }

}

class plugin_xigua_login_member extends plugin_xigua_login{}

class mobileplugin_xigua_login_member extends plugin_xigua_login
{
    public function logging_1_output(){
        $pluginversion = '2015072602';

        if($_GET['infloat']){
            return false;
        }
        if(strtolower($_SERVER['REQUEST_METHOD']) != 'get'){
            return false;
        }
        if ($_GET['action'] != 'login') {
            return false;
        }
        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }

        $referer = $_GET['referer'] ? $_GET['referer'] : $_SERVER['HTTP_REFERER'];
        if(strpos($referer, 'http://') === false && strpos($referer, 'https://') === false){
            $referer = $_G['siteurl'] . $referer;
        }

        $wechat = unserialize($_G['setting']['mobilewechat']);
        $config = $_G['cache']['plugin']['xigua_login'];
        if(!$config['get']){
            return false;
        }
        if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'magapp')  !== false){
            return false;
        }
        if(!$config['bgcolor']){
            $config['bgcolor'] ='#f5f5f5';
        }
        if($config['radius']){
            $rds = intval($config['radius']).'px';
            $radius = ".form-control input, .form-control select,.btn{border-radius:$rds}";
        }
        if ($config['opacity']) {
            $opacity = $config['opacity']/100;
            $opacity = ".login_from{opacity:$opacity}";
        }
        if($config['logincolor']){
            $logincolor = ".btn-outline{background-color:$config[logincolor]}";
        }
        if($config['onekeycolor']){
            $onekeycolor = ".btn-orange{background-color:$config[onekeycolor]}";
        }
        if($config['bgimg']){
            if($zTopbg = array_filter(explode("\n", trim($config['bgimg']))) ){
                $_k = array_rand($zTopbg, 1);
                $topbg = trim($zTopbg[$_k]);
            }

            $bgimg = "html,body{background:url($topbg) no-repeat center center;background-size:cover}";
        }
        if($config['regcolor']){
            $regcolor = ".reg_link, .reg_link a{font-size:14px;color:$config[regcolor]}";
        }

        $customstyle = "html,body{background-color:$config[bgcolor];}$radius$opacity$logincolor$onekeycolor$bgimg$regcolor";


        $param = urlencode(($referer));
        $wehaturl = $_G['siteurl'] . "plugin.php?id=xigua_login:login&backreferer=$param";

        $inwechat = strpos($_SERVER["HTTP_USER_AGENT"], "MicroMessenger") !== false;
        if($config['hidebtn']){
            $inwechat = false;
        }
        $logo = $_G['style']['boardlogo'] ?$_G['style']['boardlogo']:"<img src=\"$wechat[wsq_sitelogo]\" />";
        if($config['logo']){
            $logo = "<img src=\"$config[logo]\" />";
        }
        if(!$_G['connect']['login_url']){
            $_G['connect']['login_url'] = $_G['siteurl'].'connect.php?mod=login&op=init';
        }

        $loginhash = 'L'.random(4);

        if($_G['uid']) {
            dheader('Location:'.($referer ? $referer : './'));
        }

        if($config['openautologin'] && (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false)){
            $url = dreferer() ? dreferer() : $this->currenturl_232();
            if(strpos($url, 'code=') !== false || strpos($url, 'logout') !== false|| strpos($url, 'login') !== false){
                $url = $_G['siteurl'];
            }
            if(strpos($url, 'logout') === false){
                dheader("Location: ".$_G['siteurl'].'plugin.php?id=xigua_login:login&backreferer='.urlencode($url));
            }
        }
        if(function_exists('seccheck')){
            list($seccodecheck) = seccheck('login');
            if(!empty($_GET['auth'])) {
                $dauth = authcode($_GET['auth'], 'DECODE', $_G['config']['security']['authkey']);
                list(,,,$secchecklogin2) = explode("\t", $dauth);
                if($secchecklogin2) {
                    $seccodecheck = true;
                }
            }
            $seccodestatus = !empty($_GET['lssubmit']) ? false : $seccodecheck;
            $invite = getinvite();
            if($seccodecheck) {
                $seccode = random(6, 1) + $seccode{0} * 1000000;
            }
        }

        $auth = '';
        $username = !empty($_G['cookie']['loginuser']) ? dhtmlspecialchars($_G['cookie']['loginuser']) : '';
        $please_inwechat = lang('plugin/xigua_login', 'please_inwechat');

        if(!empty($_GET['auth'])) {
            list($username, $password, $questionexist) = explode("\t", authcode($_GET['auth'], 'DECODE', $_G['config']['security']['authkey']));
            $username = dhtmlspecialchars($username);
            $auth = dhtmlspecialchars($_GET['auth']);
        }

        $cookietimecheck = !empty($_G['cookie']['cookietime']) || !empty($_GET['cookietime']) ? 'checked="checked"' : '';

        dsetcookie('xg_referer', $referer, 86400);
        $navtitle = lang('core', 'title_login');


        dsetcookie('widthauto', '', 0);
        include template('xigua_login:member/login');
        dexit();
    }
    function currenturl_232($related = 0) {
        $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
        return $related ? $relate_url : $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
    }
    function logging_bottom_mobile(){
        global $_G;
        $config = $_G['cache']['plugin']['xigua_login'];
        if($config['hidebtn']){
            return false;
        }
        $referer = $_SERVER['HTTP_REFERER'];
        if(strpos($referer, 'http://') === false && strpos($referer, 'https://') === false){
            $referer = $_G['siteurl'] . $referer;
        }
        $param = urlencode(($referer));
        $wehaturl = $_G['siteurl'] . "plugin.php?id=xigua_login:login&backreferer=$param";

        $inwechat = strpos($_SERVER["HTTP_USER_AGENT"], "MicroMessenger") !== false;
        if(!$inwechat){
            $please_inwechat = lang('plugin/xigua_login', 'please_inwechat');
            $wehaturl = "javascript:alert('$please_inwechat');";
//            $wehaturl = "javascript:BSL.Login('WEIXIN', '', 'login');";
        }else{
            $wehaturl = $wehaturl;
        }
        if(!$config['bgcolor']){
            $config['bgcolor'] ='#f5f5f5';
        }
        if($config['radius']){
            $rds = intval($config['radius']).'px';
            $radius = ".form-control input, .form-control select,.btn{border-radius:$rds}";
        }
        if ($config['opacity']) {
            $opacity = $config['opacity']/100;
            $opacity = ".login_from{opacity:$opacity}";
        }
        if($config['logincolor']){
            $logincolor = ".btn-outline{background-color:$config[logincolor]}";
        }
        if($config['onekeycolor']){
            $onekeycolor = ".btn-orange{background-color:$config[onekeycolor]}";
        }

        if($config['regcolor']){
            $regcolor = ".reg_link, .reg_link a{font-size:14px;color:$config[regcolor]}";
        }

        $customstyle = "$radius$opacity$logincolor$onekeycolor$regcolor";
        $wechatword = lang('plugin/xigua_login', 'wechatword');
        $sanguide = lang('plugin/xigua_login', 'sanguide');
        $html = <<<HTML
<style>
.reg_link1{text-align: center;width:100%;margin-top:12px}
.reg_tp{background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAABAQMAAAAGv++CAAAABlBMVEX////Z2dl4b8nnAAAAAXRSTlMAQObYZgAAABRJREFUeNpj+E8Y/GBABYxE6PkAAHcsR6Qt8qYTAAAAAElFTkSuQmCC) no-repeat center center;margin:0 15px}
.loginbtn1{display: -moz-box;display: -webkit-box;display:box;text-align: center;width:160px;margin:15px auto;}
.loginbtn1 div{-moz-box-flex: 1;-webkit-box-flex: 1;box-flex: 1;}
.loginbtn1 a {width:40px;height:40px;display: block;margin: 0 auto;border-radius: 50%;background-color: #55BC22;}
.loginbtn1 .btn_wechatlogin span{ line-height:24px; }
.loginbtn1 a img{width:100%;height:100%;display:block;border-radius:50px;}
.loginbtn1 a span{font-size: 20px;line-height:40px;color:#fff;}
$customstyle
</style>
<div class="reg_link1">
    <div class="reg_tp">$sanguide</div>
    <div class="loginbtn1">
        <div class="btn_wechatlogin">
            <a href="$wehaturl"><img src="source/plugin/xigua_login/template/touch/member/wechat-08-535x535.png"></a>
            <span>$wechatword</span>
        </div>
    </div>
</div>
HTML;

        return $html;
    }
}
class mobileplugin_xigua_login extends plugin_xigua_login{

    public function common(){
        global $_G;
        $inwchat = (strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
        $config = $_G['cache']['plugin']['xigua_login'];
        if(
            !$_G['cookie']['widthauto'] &&
            $config['openautologin'] &&
            !$_G['uid'] &&
            $inwchat &&
            CURSCRIPT!='plugin' &&
            CURSCRIPT!='member' &&
            CURSCRIPT!='check' &&
            !$_G['inajax'] &&
            !defined('IN_MOBILE_API')
            &&!$_GET['version']
        ){
            dsetcookie('widthauto', 1, 120);
            dheader("Location: ".$_G['siteurl'].'plugin.php?id=xigua_login:login&backreferer='.urlencode($this->currenturl_231()));
        }
    }

    function currenturl_231($related = 0) {
        $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
        $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
        $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
        $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
        return $related ? $relate_url : $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
    }

    function logging_bottom_mobile(){
        global $_G;
        $config = $_G['cache']['plugin']['xigua_login'];
        $referer = dreferer();
        $html = '';
        if(strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'magapp')  !== false){
            include template('xigua_login:app');
        }
        return $html;
    }
}

class mobileplugin_xigua_login_connect extends plugin_xigua_login{}
class plugin_xigua_login_connect extends plugin_xigua_login{}

class mobileplugin_xigua_login_plugin extends plugin_xigua_login
{
    public function wechat_callback(){
        if($_GET['code']){
            $_GET['receive'] = 'yes';
        }
        $this->login_callback();
    }
}

class plugin_xigua_login_plugin extends plugin_xigua_login
{
}