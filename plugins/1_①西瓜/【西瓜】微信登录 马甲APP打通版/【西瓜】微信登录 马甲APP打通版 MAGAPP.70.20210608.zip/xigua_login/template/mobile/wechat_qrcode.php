<?php exit('hrh');?>
<!--{template common/header}-->
<div class="c" align='center'>
    <img src="$qrcodeurl" />
    <br />
    $tiptip2
</div>
<!--{template common/footer}-->