<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/3/29
 * Time: 13:03
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$config = $_G['cache']['plugin']['xigua_login'];
$authkey        = $_G['config']['security']['authkey'];
$reg_nickname   = authcode($_GET['reg_nickname'], 'DECODE', $authkey);
$reg_headimgurl = authcode($_GET['reg_headimgurl'], 'DECODE', $authkey);
$reg_sid        = authcode($_GET['reg_sid'], 'DECODE', $authkey);
$openid         = authcode($_GET['openid'], 'DECODE', $authkey);
$unionid         = authcode($_GET['unionid'], 'DECODE', $authkey);

$fetch =  DB::fetch_first('SELECT *,userid as uid FROM %t WHERE unionid=%s ORDER BY userid ASC', array('user_weixin_relations', $unionid));

if(!$fetch['uid']){
    showmessage('info empty!');
}
$uid = intval($fetch['uid']);

require_once libfile('function/member');
$member = getuserbyuid($uid, 1);
setloginstatus($member, 1296000);

C::t('common_member_status')->update($uid, array('lastip'=>$_G['clientip'], 'lastvisit'=>TIMESTAMP, 'lastactivity' => TIMESTAMP));
$ucsynlogin = '';
if($_G['setting']['allowsynlogin']) {
    loaducenter();
    $ucsynlogin = uc_user_synlogin($uid);
}

$url = $_GET['backreferer'] ? $_GET['backreferer']: $_G['siteurl'];



if($ucsynlogin){
    loadcache('usergroup_'.$member['groupid']);
    $_G['group'] = $_G['cache']['usergroup_'.$member['groupid']];
    $_G['group']['grouptitle'] = $_G['cache']['usergroup_'.$_G['groupid']]['grouptitle'];
    $param = array('username' => $member['username'], 'usergroup' => $_G['group']['grouptitle']);
    if($config['showscmsg']){
        showmessage('login_succeed', $url, $param, array('extrajs' => $ucsynlogin));
    }
}
if(strpos($url, 'oauthbase=yes')!==false || strpos($url, 'oauth=yes')!==false){
    $url = $_G['siteurl'];
}
if($url_cookie = getcookie('page_front')){
    $url = $url_cookie;
}
if($_GET['custom_url']){
    $_GET['custom_url'] = str_replace('//http://', 'http://', $_GET['custom_url']);
    $_GET['custom_url'] = str_replace('//https://', 'https://', $_GET['custom_url']);
    $url= $_GET['custom_url'];
    if($config['weret']){ $url = $config['weret']; }
    dheader("Location: $url");
}else{
    if($config['weret']){ $url = $config['weret']; }
    dheader("Location: $url");
}