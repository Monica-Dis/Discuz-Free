<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/9/9
 * Time: 22:26
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include DISCUZ_ROOT.'source/plugin/xigua_login/function.php';
$configfile = DISCUZ_ROOT . 'source/plugin/xigua_login/cache/mdb.php';

if(submitcheck('test', 1) &&FORMHASH == $_GET['formhash']){

    $r = fetch_magapp('test');
    cpmsg(cplang('cloud_doctor_result_success').' '.cplang('available'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_login&pmod=db", 'succeed', array());
}

$mdb = @include $configfile;
if(submitcheck('dosubmit')){
    if($_GET['m']['dbpw'] == '********'){
        $mdb = @include $configfile;
        $_GET['m']['dbpw'] = $mdb[1]['dbpw'];
    }
    $_GET['m']['pconnect'] = '0';
    $_GET['m']['dbcharset'] = 'utf8';
    $_GET['m']['tablepre'] = $_GET['m']['tablepre'] ? $_GET['m']['tablepre'] : 'lab_';

    $mdb = array('1' => $_GET['m']);
    $cachedata = var_export($mdb, true) .';';
    if($fp = @fopen($configfile, 'wb')) {
        fwrite($fp, "<?php if(!defined('IN_DISCUZ')) {exit('Access Denied');} \n//Discuz! cache file, DO NOT modify me!\n//Identify: ".md5($script.'.php'.$cachedata.$_G['config']['security']['authkey'])."\n\n return $cachedata");
        fclose($fp);
        $msg = 'groups_setting_succeed';
    } else {
        $msg = 'Can not write to cache files, please check directory ./source/plugin/xigua_login/cache/ .';
    }
    sleep(2);
    cpmsg($msg, "action=plugins&operation=config&do=$pluginid&identifier=xigua_login&pmod=db&rand=".time(), 'succeed', array());
}


showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_login&pmod=db");
showtableheader();


//lab_user_wxconnect

showsetting(lang('plugin/xigua_login', 'dbhost'), 'm[dbhost]', $mdb[1]['dbhost'], 'text', $disable, 0 , lang('plugin/xigua_login', 'dbhost_c'));
showsetting(lang('plugin/xigua_login', 'dbuser'), 'm[dbuser]', $mdb[1]['dbuser'], 'text', $disable,0, lang('plugin/xigua_login', 'dbuser_c'));
showsetting(lang('plugin/xigua_login', 'dbpw'), 'm[dbpw]', '********', 'text', $disable,0,lang('plugin/xigua_login', 'dbpw_c'));
showsetting(lang('plugin/xigua_login', 'dbname'), 'm[dbname]', $mdb[1]['dbname'], 'text', $disable,0,lang('plugin/xigua_login', 'dbname_c'));
showsetting(lang('plugin/xigua_login', 'tablepre'), 'm[tablepre]', $mdb[1]['tablepre'], 'text', $disable,0, lang('plugin/xigua_login', 'tablepre_c'));
showsetting(lang('plugin/xigua_login', 'test'), '', '',
    "<a href=\"".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_login&pmod=db&test=1&formhash=".FORMHASH."\" target=\"_blank\">".lang('plugin/xigua_login', 'test_c')."</a><br />"
);
showsubmit('dosubmit');
showtablefooter(); //Dism��taobao��com
showformfooter(); /*dis'.'m.tao'.'bao.com*/

