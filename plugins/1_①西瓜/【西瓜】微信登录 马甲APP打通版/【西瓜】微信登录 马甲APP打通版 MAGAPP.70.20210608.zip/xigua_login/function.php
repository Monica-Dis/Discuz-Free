<?php
/**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * Date: 2016/3/11
 * Time: 0:03
 */
function xglogin_x_unescape($str) {
    $str = str_replace(array('&','_','>','<','~','|','=','-',';','"','}','{', '`', '(', ')', ',',
        '%','(',')','!','@','$','~','^','*','#','\\','.','?','/','+',' '), '', $str);
    $str = rawurldecode($str);
    preg_match_all("/(?:%u.{4})|&#x.{4};|&#\d+;|.+/U",$str,$r);
    $ar = $r[0];
    foreach($ar as $k=>$v) {
        if(substr($v,0,2) == "%u"){
            $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,-4)));
        }
        elseif(substr($v,0,3) == "&#x"){
            $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,3,-1)));
        }
        elseif(substr($v,0,2) == "&#") {

            $ar[$k] = iconv("UCS-2BE","UTF-8",pack("n",substr($v,2,-1)));
        }
    }
    return implode("",$ar);
}
function xg_register($username, $avatar, $auto = 1, $showmsg = 1) {
    global $_G;
    $config = $_G['cache']['plugin']['xigua_login'];
    if(!$username) {
        return 0;
    }

    $username = xglogin_x_unescape($username);
    if(dstrlen($username)<=3){
        $username = $username.mt_rand(100000, 999999);
    }
    if(!$_G['wechat']['setting']) {
        $_G['wechat']['setting'] = unserialize($_G['setting']['mobilewechat']);
    }
    if(!$username){
        $username = 'wx_'.mt_rand(111111, 999999);
    }

    loaducenter();
    $groupid = $config['groupid'] ? $config['groupid'] : $_G['setting']['newusergroupid'];

    $password = md5(random(10));
    $email = strtolower(random(12)).'@wechat.com';

    if($auto){
        $usernamelen = dstrlen($username);
        if($usernamelen < 3) {
            $username = $username.mt_rand(1000, 9999);
        }
        if($usernamelen > 15) {
            $username = cutstr($username, 15, '');
        }

        if(C::t('common_member')->fetch_by_username($username) || uc_user_checkname($username)!='1'){
            $username =  cutstr($username, 13, '').mt_rand(1, 99);
            if($config['confilt']){
                return '-9999';
            }
        }
    }
    global $openid, $unionid;
    if($unionid){
        $fetch = DB::fetch_first('SELECT *,userid as uid FROM %t WHERE unionid=%s ORDER BY userid ASC', array('user_weixin_relations', $unionid));
        if($fetch){
            return $fetch['uid'];
        }
    }else if($openid){
        $fetch = DB::fetch_first('SELECT *,userid as uid FROM %t WHERE openid=%s ORDER BY userid ASC', array('user_weixin_relations', $openid));
        if($fetch){
            return $fetch['uid'];
        }
    }

    $censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';
    $_G['setting']['censoruser'] && @preg_replace($censorexp, '_', $username);

    $sms = '';
    @include_once DISCUZ_ROOT. 'source/discuz_version.php';
    if(DISCUZ_VERSION == 'F1.0' && function_exists('uc_user_register_new')){
        $sms = $_GET['mobile'] ? $_GET['mobile'] : '189'.mt_rand(10000000, 99999999);
        $uid = uc_user_register_new(addslashes($username), $password, $email, $sms, '', '', $_G['clientip']);
    }else{
        $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
    }
    if($uid <= 0) {
        if($uid == -1) {
            return $uid;
//            showmessage('profile_username_illegal');
        } elseif($uid == -2) {
            return $uid;
//            showmessage('profile_username_protect');
        } elseif($uid == -3) {


            return $uid;
//            showmessage('profile_username_duplicate');
        } elseif($uid == -4) {
            if($showmsg){
                showmessage('profile_email_illegal');
            }
        } elseif($uid == -5) {
            if($showmsg) {
                showmessage('profile_email_domain_illegal');
            }
        } elseif($uid == -6) {
            if($showmsg) {
                showmessage('profile_email_duplicate');
            }
        } else {
            if($showmsg) {
                showmessage($sms . '_' . $uid . '_undefined_action');
            }
        }
        return $uid;
    }

    $init_arr = array('credits' => explode(',', $_G['setting']['initcredits']), 'emailstatus' => 1);
    if($sms) {
        C::t('common_member')->insert_new($uid, $username, $password, $email, $sms, $_G['clientip'], $groupid, $init_arr);
    }else{
        C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

        /*$extdata = $init_arr;
        $adminid = 0;
        $ip = $_G['clientip'];

        $credits = isset($extdata['credits']) ? $extdata['credits'] : array();
        $profile = isset($extdata['profile']) ? $extdata['profile'] : array();
        $profile['uid'] = $uid;
        $base = array(
            'uid' => $uid,
            'username' => (string)$username,
            'password' => (string)$password,
            'email' => (string)$email,
            'adminid' => intval($adminid),
            'groupid' => intval($groupid),
            'regdate' => TIMESTAMP,
            'emailstatus' => intval($extdata['emailstatus']),
            'credits' => dintval($credits[0]),
            'timeoffset' => 9999
        );
        $status = array(
            'uid' => $uid,
            'regip' => (string)$ip,
            'lastip' => (string)$ip,
            'lastvisit' => TIMESTAMP,
            'lastactivity' => TIMESTAMP,
            'lastpost' => 0,
            'lastsendmail' => 0
        );
        $count = array(
            'uid' => $uid,
            'extcredits1' => dintval($credits[1]),
            'extcredits2' => dintval($credits[2]),
            'extcredits3' => dintval($credits[3]),
            'extcredits4' => dintval($credits[4]),
            'extcredits5' => dintval($credits[5]),
            'extcredits6' => dintval($credits[6]),
            'extcredits7' => dintval($credits[7]),
            'extcredits8' => dintval($credits[8])
        );
        $ext = array('uid' => $uid);
        DB::insert('common_member', $base);
        C::t('common_member_status')->insert($status, false, true);
        C::t('common_member_count')->insert($count, false, true);
        C::t('common_member_profile')->insert($profile, false, true);
        C::t('common_member_field_forum')->insert($ext, false, true);
        C::t('common_member_field_home')->insert($ext, false, true);*/

    }


    if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
        C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
        if($_G['setting']['regctrl']) {
            C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
        }
    }

    if($_G['setting']['regverify'] == 2) {
        C::t('common_member_validate')->insert(array(
            'uid' => $uid,
            'submitdate' => $_G['timestamp'],
            'moddate' => 0,
            'admin' => '',
            'submittimes' => 1,
            'status' => 0,
            'message' => '',
            'remark' => '',
        ), false, true);
        manage_addnotify('verifyuser');
    }

    if($showmsg){
        setloginstatus(array(
            'uid' => $uid,
            'username' => $username,
            'password' => $password,
            'groupid' => $groupid,
        ), 0);

        C::t('common_member_status')->update($uid, array('lastip'=>$_G['clientip'], 'lastvisit'=>TIMESTAMP, 'lastactivity' => TIMESTAMP));
        $ucsynlogin = '';
        if($_G['setting']['allowsynlogin']) {
            loaducenter();
            $ucsynlogin = uc_user_synlogin($uid);
        }
    }

    //统计
    include_once libfile('function/stat');
    updatestat('register');
    xg_syncAvatar($uid, $avatar);

    if(!function_exists('build_cache_userstats')) {
        require_once libfile('cache/userstats', 'function');
    }
    build_cache_userstats();

    return $uid;
}

function xg_syncAvatar($uid, $avatar) {

    if(!$uid || !$avatar) {
        return false;
    }

    if(!$content = dfsockopen($avatar)) {
        return false;
    }

    $tmpFile = DISCUZ_ROOT.'./data/avatar/'.TIMESTAMP.random(6);
    file_put_contents($tmpFile, $content);

    if(!is_file($tmpFile)) {
        return false;
    }

    $result = uploadUcAvatar1::upload($uid, $tmpFile);
    unlink($tmpFile);

    C::t('common_member')->update($uid, array('avatarstatus'=>'1'));

    return $result;
}

class uploadUcAvatar1 {

    /**
     * 上传至uc头像
     */
    public static function upload($uid, $localFile) {


        $uid = sprintf("%09d", $uid);
        $dir1 = substr($uid, 0, 3);
        $dir2 = substr($uid, 3, 2);
        $dir3 = substr($uid, 5, 2);
        $file1 = DISCUZ_ROOT.'uc_server/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_small.jpg';
        $file2 = DISCUZ_ROOT.'uc_server/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_middle.jpg';
        $file3 = DISCUZ_ROOT.'uc_server/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/'.substr($uid, -2).'_avatar_big.jpg';
        dmkdir(DISCUZ_ROOT.'uc_server/data/avatar/'.$dir1.'/'.$dir2.'/'.$dir3.'/', 0777);
        $r1 = file_get_contents($localFile);
        file_put_contents($file1, $r1);
        file_put_contents($file2, $r1);
        file_put_contents($file3, $r1);
        return true;

        global $_G;
        if(!$uid || !$localFile) {
            return false;
        }

        list($width, $height, $type, $attr) = getimagesize($localFile);
        if(!$width) {
            return false;
        }

        if($width < 10 || $height < 10 || $type == 4) {
            return false;
        }

        $imageType = array(1 => '.gif', 2 => '.jpg', 3 => '.png');
        $fileType = $imageType[$type];
        if(!$fileType) {
            $fileType = '.jpg';
        }
        $avatarPath = $_G['setting']['attachdir'];
        $tmpAvatar = $avatarPath.'./temp/upload'.$uid.$fileType;
        file_exists($tmpAvatar) && @unlink($tmpAvatar);
        file_put_contents($tmpAvatar, file_get_contents($localFile));

        if(!is_file($tmpAvatar)) {
            return false;
        }

        $tmpAvatarBig = './temp/upload'.$uid.'big'.$fileType;
        $tmpAvatarMiddle = './temp/upload'.$uid.'middle'.$fileType;
        $tmpAvatarSmall = './temp/upload'.$uid.'small'.$fileType;

        $image = new image;
        if($image->Thumb($tmpAvatar, $tmpAvatarBig, 200, 250, 1) <= 0) {
            return false;
        }
        if($image->Thumb($tmpAvatar, $tmpAvatarMiddle, 120, 120, 1) <= 0) {
            return false;
        }
        if($image->Thumb($tmpAvatar, $tmpAvatarSmall, 48, 48, 2) <= 0) {
            return false;
        }

        $tmpAvatarBig = $avatarPath.$tmpAvatarBig;
        $tmpAvatarMiddle = $avatarPath.$tmpAvatarMiddle;
        $tmpAvatarSmall = $avatarPath.$tmpAvatarSmall;

        $avatar1 = self::byte2hex(file_get_contents($tmpAvatarBig));
        $avatar2 = self::byte2hex(file_get_contents($tmpAvatarMiddle));
        $avatar3 = self::byte2hex(file_get_contents($tmpAvatarSmall));

        $extra = '&avatar1='.$avatar1.'&avatar2='.$avatar2.'&avatar3='.$avatar3;
        $result = self::uc_api_post_ex('user', 'rectavatar', array('uid' => $uid), $extra);

        @unlink($tmpAvatar);
        @unlink($tmpAvatarBig);
        @unlink($tmpAvatarMiddle);
        @unlink($tmpAvatarSmall);

        return true;
    }

    public static function byte2hex($string) {
        $buffer = '';
        $value = unpack('H*', $string);
        $value = str_split($value[1], 2);
        $b = '';
        foreach($value as $k => $v) {
            $b .= strtoupper($v);
        }

        return $b;
    }

    public static function uc_api_post_ex($module, $action, $arg = array(), $extra = '') {
        $s = $sep = '';
        foreach($arg as $k => $v) {
            $k = urlencode($k);
            if(is_array($v)) {
                $s2 = $sep2 = '';
                foreach($v as $k2 => $v2) {
                    $k2 = urlencode($k2);
                    $s2 .= "$sep2{$k}[$k2]=".urlencode(uc_stripslashes($v2));
                    $sep2 = '&';
                }
                $s .= $sep.$s2;
            } else {
                $s .= "$sep$k=".urlencode(uc_stripslashes($v));
            }
            $sep = '&';
        }
        $postdata = uc_api_requestdata($module, $action, $s, $extra);
        return uc_fopen2(UC_API.'/index.php', 500000, $postdata, '', TRUE, UC_IP, 20);
    }
}

function xg_wechat_bind($uid, $openid, $unionid, $bindappbyme=1, $isregister = 1){
    C::t('#xigua_login#user_weixin_relations')->insert(array('userid' => $uid,'unionid' => $unionid, 'openid' => $openid,), false, true);
    if($bindappbyme){
        set_magapp_connection($uid, $unionid);
    }
}
function connect_magapp(){
    return false;
    static $magdb = NULL;
    $configfile = DISCUZ_ROOT . 'source/plugin/xigua_login/cache/mdb.php';
    $mdb = @include $configfile;
    if(!$mdb){
        return false;
    }
    if($magdb === NULL&& $mdb){
        $driver = function_exists('mysql_connect') ? 'db_driver_mysql' : 'db_driver_mysqli';
        $magdb = new $driver;
        $magdb->set_config($mdb);
        $magdb->connect();
    }
    return $magdb;
}

function set_magapp_connection($uid, $unionid){
    $magdb = connect_magapp();
    if(!$magdb){
        return ;
    }

    $mag_config = $magdb->fetch_first("SELECT * FROM `{$magdb->config[1]['tablepre']}system_config` WHERE `key` LIKE 'site_regist_wx_appid' LIMIT 1");
    $appid = $mag_config['value'];

    $re = 0;
    $has = $magdb->fetch_first("SELECT * FROM {$magdb->config[1]['tablepre']}user_wxconnect WHERE unionid='".addslashes($unionid)."'");
    if(!$has){
        $re = $magdb->query("INSERT INTO `{$magdb->config[1]['tablepre']}user_wxconnect` (`uid`, `appid`, `openid`, `unionid`) VALUES ('$uid', '$appid', '', '$unionid')");
    }
    return $re;
}

function fetch_magapp($unionid){
    $magdb = connect_magapp();
    if(!$magdb){
        return ;
    }

    $re = $magdb->fetch_first("SELECT * FROM {$magdb->config[1]['tablepre']}user_wxconnect WHERE unionid='".addslashes($unionid)."'");
    return $re;
}

function remove_magapp($uid){
    $magdb = connect_magapp();
    if(!$magdb){
        return ;
    }

    $re = $magdb->query("DELETE FROM {$magdb->config[1]['tablepre']}user_wxconnect WHERE uid='".intval($uid)."'");
    return $re;
}


function login_access($openid, $code, $userinfo, $config)
{
    global $_G;
    $authkey = $_G['config']['security']['authkey'];
    $succeed = 0;



    $authcode = C::t('#wechat#mobile_wechat_authcode')->fetch_by_code($code);
    $unionid = $userinfo['unionid'];
    if($unionid){
        $fetch =  DB::fetch_first('SELECT *,userid as uid FROM %t WHERE unionid=%s ORDER BY userid ASC', array('user_weixin_relations', $unionid));
    }else{
        $fetch =  DB::fetch_first('SELECT *,userid as uid FROM %t WHERE openid=%s ORDER BY userid ASC', array('user_weixin_relations', $openid));
    }

    $arr = array(
        'reg_nickname'   => authcode($userinfo['nickname'], 'ENCODE', $authkey),
        'reg_headimgurl' => authcode($userinfo['headimgurl'], 'ENCODE', $authkey),
        'reg_sid'        => authcode($authcode['sid'], 'ENCODE', $authkey),
        'openid'         => authcode($openid, 'ENCODE', $authkey),
        'unionid'         => authcode($unionid, 'ENCODE', $authkey),
    );


    if(($uid = $fetch['uid'])){
        if(!$authcode['uid']){
            C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
            $succeed = 1;
        }else if($authcode['uid'] != $fetch['uid']){
            $succeed = 1;
        }else{
            C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
            $succeed = 1;
        }
    }else{
        if($authcode['uid']) {
            $uid = $authcode['uid'];
            $member = getuserbyuid($uid, 1);
            if($member){
                xg_wechat_bind($uid, $openid, $unionid);
                C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
                $succeed = 1;
            }
        } else {
            if($config['wxmiao']||1){
                $uid = xg_register($userinfo['nickname'], $userinfo['headimgurl'], 1, 0);

                if($uid <=0){
                    $jumpurl = 'plugin.php?id=xigua_login:reg&has=1&'.http_build_query($arr);
                }else{
                    xg_wechat_bind($uid, $openid, $unionid);
                    C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
                    $succeed = 1;
                }
            }else{
                $jumpurl = 'plugin.php?id=xigua_login:reg&'.http_build_query($arr);
            }
        }
    }


    if($succeed) {
        $member = getuserbyuid($uid, 0);
        $succeemsg = str_replace('{siteurl}', $_G['siteurl'], '恭喜！登录成功！');
        $msg = $member['username'].'您好'.$succeemsg;
        if($GLOBALS['custom_url']){
            $arr['custom_url'] = $GLOBALS['custom_url'];
            $msg = $member['username'].'您好';
        }
        $syncurl = $_G['siteurl'].'plugin.php?id=xigua_login:dingyue&'.http_build_query($arr);
        $extmsg = '点击该链接立即访问社区';

        $list = array();
        $list[0] = array(
            'title' => $msg,
            'desc'  => $extmsg,
            'pic'   => $_G['siteurl'].'/logo.gif',
            'url'   => $syncurl,
        );
        echo WeChatServer::getXml4RichMsgByArray($list);
    }elseif ($jumpurl){
        $jumpurl = $_G['siteurl'].$jumpurl;
        $msg = '请点击链接开始注册';
        if($uid == -9999 || $uid == -3){
            $msg = lang('plugin/xigua_login', 'profile_username_duplicate');
        }elseif($uid == -1){
            $msg = lang('plugin/xigua_login', 'profile_username_illegal');
        }elseif($uid == -2){
            $msg = lang('plugin/xigua_login', 'profile_username_protect');
        }
        echo WeChatServer::getXml4Txt("<a href='$jumpurl'>".$msg.($uid ? " ($uid)" : '')."</a>");

        $list = array();
        $list[0] = array(
            'title' => $msg,
            'desc'  => $msg,
            'pic'   => $_G['siteurl'].'/logo.gif',
            'url'   => $jumpurl,
        );
        echo WeChatServer::getXml4RichMsgByArray($list);
    }else{
        echo WeChatServer::getXml4Txt(lang('plugin/xigua_login', 'login_failed'));
    }
}