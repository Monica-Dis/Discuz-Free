<?php

/**
 *      [DisM!] (C)2019-2021 DISM.Taobao.COM.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_common_member_wechat.php 34506 2014-05-13 02:09:15Z DISM.TAOBAO.COM $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_user_weixin_relations extends discuz_table {

    public function __construct() {
        $this->_table = 'user_weixin_relations';
        $this->_pk = 'userid';
        $this->_pre_cache_key = 'user_weixin_relations_';

        parent::__construct(); //dis'.'m.tao'.'bao.com
    }

    public function fetch_by_openid($openid) {
        return DB::fetch_first('SELECT *,userid as uid FROM %t WHERE openid=%s ORDER BY userid asc ', array($this->_table, $openid));
    }

}
