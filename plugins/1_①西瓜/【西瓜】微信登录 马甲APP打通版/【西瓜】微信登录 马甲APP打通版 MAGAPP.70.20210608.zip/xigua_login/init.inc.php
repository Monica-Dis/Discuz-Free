<?php

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
include_once libfile('function/cache');
if(is_file(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')){
    include_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    $updatedata = array(
        'receiveEvent::subscribe' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'subscribe'
        ),
        'receiveAllEnd' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'receiveAllEnd'
        ),
        'receiveEvent::scan' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'scan'
        ),
        'receiveMsg::text' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'text'
        ),
        'receiveEvent::click' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'click'
        ),
    );
    $responsehook = WeChatHook::updateResponse($updatedata, 552);
}