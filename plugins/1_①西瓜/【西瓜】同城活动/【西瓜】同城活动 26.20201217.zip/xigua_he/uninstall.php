<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
  DROP TABLE pre_xigua_he_var;
  DROP TABLE pre_xigua_he_order;
  DROP TABLE pre_xigua_he_index;
  DROP TABLE pre_xigua_he_huodong;
  DROP TABLE pre_xigua_he_hangye;
  DROP TABLE pre_xigua_he_cat;
  DROP TABLE pre_xigua_he_nav;
EOT;
runquery($sql);

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/install.php');

xwbhe_delall(DISCUZ_ROOT . "./source/plugin/xigua_he");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_he");


function xwbhe_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwbhe_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}