<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$navtitle = lang_he('fabu0',0);
$list = C::t('#xigua_he#xigua_he_cat')->list_by_pid(0, TRUE);
foreach ($list as $index => $item) {
    $list[$index]['child'] = C::t('#xigua_he#xigua_he_cat')->get_childs_by_pids($item['id']);
}

$sh =he_get_my_shs();
$he_config = $_G['cache']['plugin']['xigua_he'];
if(!$sh && !$he_config['allowgr']){
    dheader('Location:'.$SCRITPTNAME.'?id=xigua_he&ac=none'.$urlext);
}