<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$navtitle = lang_he('tjsp',0);
switch ($do){
    case 'autosave':
        $r = C::t('#xigua_he#xigua_he_huodong')->update_G($hid, $form);
        break;
    default:
        $vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99, 'id');
        if(!submitcheck('formhash')){
            if($hid){
                $old_data = $he_huodong->fetch_by_id($hid);
                if($old_data['uid']!=$_G['uid'] && !IS_ADMINID){
                    hb_message('error', 'error');
                }
                $_GET['catid'] = $old_data['catid'];
            }
            $topcat = $he_cat->fetch_by_catid($_GET['catid']);

            $bdvars = array();
            foreach (he_vars($_GET['catid']) as $index => $bdvar) {
                $bdvars['f_'.$bdvar['pluginvarid']] = $bdvar['title'];
            }
            $bmfield = $bdvars;

            $navtitle = lang_he('pub',0).$topcat['name'];
            if($old_data){
                $navtitle = lang_he('edit',0).'-'.$old_data['title'];
                /*
                print_r($old_data['bdfield']);
                print_r($old_data['required']);*/
                $needs = '';
                foreach ($old_data['bdfield'] as $index => $old_datum) {
                    $needs .= $bmfield[$index].' ';
                }
            }/*
            print_r($old_data);
            print_r($bmfield);*/

            $he_config['pubprice'] = floatval($topcat['price']);
            $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('uid='.$_G['uid']), 0, 99, 'shid DESC', 'shid,name,viptype');
            if(!$sh && !$he_config['allowgr']){
                dheader('Location:'.$SCRITPTNAME.'?id=xigua_he&ac=none'.$urlext);
            }
            foreach ($sh as $index => $_sh) {
                if(!in_array('huodong', $vips[$_sh['viptype']]['access'])){
                    unset($sh[$index]);
//                    print_r($_sh['viptype']);
//                    print_r($vips[$_sh['viptype']]['access']);
                }else{
//                    print_r($sh[$index]);
                }
            }
            $sh = array_values($sh);
        }else{

            $data = $srg = $append_img = $append_text = array();
            $form = $_GET['form'];
            $hid = $form['id'];
            $required = array(
                'title',
                'starttime',
                'endtime',
                'tel'
            );
            foreach ($required as $index => $item) {
                $form[$item] = trim($form[$item]);
                if(!$form[$item]){
                    hb_message(lang_he($item.'_tip', 0), 'error');
                }
            }

            foreach ($svicerange as $index => $item) {
                if($form['tagid'][$index]){
                    list($_rangt, $_rangd) = explode("#", $item);
                    $srg[] = $_rangt;
                }
            }
            foreach ($form['append_img'] as $index => $item) {
                $append_img[] = $item;
                $append_text[] = $form['append_text'][$index];
            }
            $up = $form['id']>0;

            $data = array(
                'lat' => $form['lat'],
                'lng' => $form['lng'],
                'province' => $form['province'],
                'city' => $form['city'],
                'district' => $form['district'],
                'street' => $form['street'],
                'street_number' => $form['street_number'],
                'addr' => $form['addr'],
            );
            if($up){
                $data['upts'] = TIMESTAMP;
            }else{
                $data['uid']  = $_G['uid'];
                $data['crts'] = TIMESTAMP;
                $data['upts'] = TIMESTAMP;
            }
            if($form['shname']){
                $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']);
                if($sh){
                    if(!in_array('huodong', $vips[$sh['viptype']]['access'])){
                       hb_message(lang_he('noaccess',0),'error');
                    }
                    $data['shname'] = $sh['name'];
                    $data['shid']   = $sh['shid'];
                }
            }
            $data['title'] = $form['title'];
            $data['starttime'] = intval(strtotime($form['starttime']));
            $data['endtime'] = intval(strtotime($form['endtime']));
            if($data['starttime']>$data['endtime']){
                hb_message(lang_he('ksbnxyjs',0), 'error');
            }
            if($data['bstarttime']>$data['bendtime']){
                hb_message(lang_he('jssjgz',0), 'error');
            }
            if($form['jz']){
                $form['pzname'] =array (0 =>$form['title']);
                $form['pzprice'] =array (0 => '0');
                $form['pzhkprice'] =array (0 => '0');
                $form['pznum'] =array (0 => '');
                $form['pzmin'] =array (0 => '1',);
                $form['pzmax'] =array (0 => '9999');
            }
            $data['jz'] = $form['jz'];
            foreach ($pzfield as $index => $item) {
                $data[$item] = serialize($form[$item]);
            }
            $data['allnum'] = array_sum($form['pznum']);

            $minhp = floatval(min($form['pzprice']));
            $maxhp = floatval(max($form['pzprice']));
            if(!$maxhp){
                $data['pricerange'] = $minhp==$maxhp ? $minhp : 0;
            }else{
                $data['pricerange'] = $minhp==$maxhp ? $minhp : ($minhp).'-'.$maxhp;
            }

            $minhp = floatval(min($form['pzhkprice']));
            $maxhp = floatval(max($form['pzhkprice']));
            if(!$maxhp){
                $data['hkpricerange'] = $minhp==$maxhp ? $minhp : 0;
            }else{
                $data['hkpricerange'] = $minhp==$maxhp ? $minhp : $minhp.'-'.$maxhp;
            }

            $data['tel'] = $form['tel'];
            $data['showbm'] = $form['showbm'];
            $data['bdfield'] = serialize($form['bdfield']);
            if(!$form['bdfield']){
                hb_message(lang_he('qszbmbd',0), 'error');
            }
            $data['required'] = serialize($form['required']);
            $data['bstarttime'] = intval(strtotime($form['bstarttime']));
            if(!$data['bstarttime']){
                $data['bstarttime'] = TIMESTAMP;
            }
            $data['bendtime'] = intval(strtotime($form['bendtime']));
            $data['jieshao'] = $form['jieshao'];
            $data['append_img'] = serialize($append_img);
            $data['append_text'] = serialize($append_text);
            $data['fengmian'] = is_array($form['fengmian']) ? $form['fengmian'][0] : $form['fengmian'];
            if(!$data['fengmian']){
                hb_message(lang_he('hdfm',0), 'error');
            }
            $data['album'] = serialize($form['album']);
            $data['srange'] = implode("\t", $srg);
            $data['status'] = -1;
            $data['catid'] = $form['catid'];
            $data['allow_tk'] = $form['allow_tk'];
            $data['stid'] = $form['st'];
            $urlext .= "&st=".$form['st'];

            $topcat = $he_cat->fetch_by_catid($form['catid']);
            $he_config['pubprice'] = $topcat['price'];
            if(!$hid){
                if($he_config['pubprice']>0){
                    $newhid = $he_huodong->insert($data, true);
                    $data['id'] = $newhid;
                    dsetcookie('newhid', $newhid, 7200);

                    $price = $he_config['pubprice'];
                    $rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_he&ac=myhe{$urlext}";
                    $title = lang_he('fbhd',0).'-'.$data['title'];
                    $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price, $title, 'common_hepub', array(
                        'data' => $data,
                        'callback' => array(
                            'file' => 'source/plugin/xigua_he/function.php',
                            'method' => 'hepub_callback'
                        ),
                        'location' => $rtl,
                        'referer' => $rtl,
                    ));
                    $he_huodong->update($newhid, array('order_id' => $order_id));

                    $rl = urlencode($rtl);
                    $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext);
                    hb_message(lang_he('zhiftiao', 0), 'success', $jumpurl);
                }else{
                    $data['status'] = $he_config['freedis'] ? -1 : 2;
                    $newhid = $he_huodong->insert($data, true);
                    dsetcookie('newhid', $newhid, 7200);
                    if($he_config['freedis']){
                        $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_he&ac=manage&".$urlext;
                        he_postx(lang_he('new_need_shen',0), array('url' => $url, 'id'=>$newhid));
                    }else{
                        $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_he&ac=view&hid=$newhid".$urlext;
                        he_postx(lang_he('new_in',0), array('url' => $url, 'id'=>$newhid));
                    }
                    $referer = "$SCRITPTNAME?id=xigua_he&ac=myhe".$urlext;
                    hb_message(lang_he('fabuok', 0), 'success', $referer);
                }
            }else{
                $data['status'] = $he_config['freedis'] ? -1 : 2;
                $referer = "$SCRITPTNAME?id=xigua_he&ac=myhe&status=".$data['status'].$urlext;
                $data['upts'] = TIMESTAMP;
                $shid = $he_huodong->update($hid, $data);
                hb_message(lang_he('xgch', 0), 'success', $referer);
            }

        }
        break;
}