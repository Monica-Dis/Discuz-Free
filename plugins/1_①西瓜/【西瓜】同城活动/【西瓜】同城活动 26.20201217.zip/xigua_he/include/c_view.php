<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$custext = array();
if($v['customtxt']){
    foreach (explode("\n", trim($v['customtxt'])) as $index => $item) {
        list($cus_name, $cus_desc) = explode('|', trim($item));
        $cus_name= trim($cus_name);
        $cus_desc = trim($cus_desc);
        if($cus_name&& $cus_desc){
            $custext[$cus_name] = $cus_desc;
        }
    }
}