<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($do == 'sxj'){
    $stat = intval($_GET['stat']);
    $v = $he_huodong->fetch_G($hid);
    if($v['status'] == -1 || $v['status'] == 1){
        hb_message(lang_he(lang_he('shzwfzc',0),0), 'error');
    }
    if(!in_array($stat, array(-2, 2))){
        hb_message('error', 'error');
    }
    $he_huodong->update_G($hid, array(
        'status' => $stat
    ));
    hb_message(lang_he('czcg',0),'success', 'reload');
}elseif($do =='complete'){
    $cancomplete = 0;
    $finishstat = 6;
    if(submitcheck('bmid')){
        $v = $he_order->fetch_by_bmid($bmid);

        if($v['status']==2){
            if($hxcode = $_GET['hxcode']){
                $shids = he_get_shids_by_uid();
                if($_G['uid']){
                    $hinfo = $he_huodong->fetch($v['hid']);
                }
                $ismanage = ($v['shid']&&in_array($v['shid'], $shids)) || $hinfo['uid']==$_G['uid'];
                if(!$ismanage){
                    hb_message('error', 'error');
                }
                $r = DB::update('xigua_he_order', array( 'status' => $finishstat, 'hxuid' => $_G['uid'], 'hxcrts' => TIMESTAMP ), "hxcode='{$hxcode}' AND id=$bmid AND status=2");
            }else{
                $r = DB::update('xigua_he_order', array( 'status' => $finishstat, 'hxuid' => $_G['uid'], 'hxcrts' => TIMESTAMP ), "uid={$_G['uid']} AND id=$bmid AND status=2");
            }
            $cancomplete = 1;
        }
    }
    if($_GET['autocomplete'] && $he_config['zdsj']>0){
        if (discuz_process::islocked('autocomplete', 10)) {
            hb_message('lock', 'success', 'reload');
        }
        $bm = DB::fetch_first('select o.id as bmid,o.uid as bmuid from %t as o,%t as h where o.status=2 and h.endtime<%d and o.hid=h.id order by o.id asc limit 1',array('xigua_he_order', 'xigua_he_huodong', TIMESTAMP+$he_config['zdsj']));
        $bmid = $bm['bmid'];
        $bmuid = $bm['bmuid'];
        if($bmid){
            $r = DB::update('xigua_he_order', array( 'status' => $finishstat, 'hxuid' => $bmuid, 'hxcrts' => TIMESTAMP ), "id=$bmid AND status=2");
            $cancomplete = 1;
        }
    }
    if($cancomplete){
        $v = $he_order->fetch_by_bmid($bmid);
        $paymoney = $v['pay_money'];
        if($r && $v['pay_ts']>0 && $paymoney >0 && $v['status']==$finishstat){
            $huodong = $he_huodong->fetch($v['hid']);

            $shid = $huodong['shid'];

            include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
            $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
            $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
            $insxf   = intval(abs($vipinfo['insxf']))/100;
            if($shdata['shinsxf']){
                $insxf  = intval(abs($shdata['shinsxf']))/100;
            }

            $sxfee = round($insxf*$paymoney, 2);
            $money = $paymoney-$sxfee;

            global $_G;
            $he_config = $_G['cache']['plugin']['xigua_he'];
            if($he_config['jiesuantype']=='cb'){
                $price_cb = $v['pzinfo']['chengben_price'];
                $money = $price_cb*$v['num'];
            }

            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                'uid' => $huodong['uid'],
                'crts' =>TIMESTAMP,
                'size' => $money,
                'note' => $v['title'].lang_he('kcsxf',0).$sxfee.';'.lang_he('rz',0).$money,
                'link' => "$SCRITPTNAME?id=xigua_he&ac=order_profile&bmid={$v['id']}&manage=1".$urlext,
            ));
            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($huodong['uid'], 'money', $paymoney);
        }
        if($_G['cache']['plugin']['xigua_hh']){
            @DB::query("UPDATE %t SET reach=%d WHERE idtype='common_bm' AND FIND_IN_SET(%d ,thirdid)", array('xigua_hh_income', ($_G['cache']['plugin']['xigua_hh']['needshen_in'] ? -1 : 0), $bmid));
        }
        hb_message(lang_he('ypcg',0),'success', 'reload');
    }
}elseif($do =='tk'){
    if(submitcheck('bmid')){
        $v = $he_order->fetch_by_bmid($bmid);
        $vs = $he_order->fetch_by_orderid($bmid);
        $canbacktowx = 0;
        if(count($vs)==1){
            $canbacktowx = 1;
        }
        $paymoney = $v['pay_money'];
        $jup = "$SCRITPTNAME?id=xigua_he&ac=order_profile&bmid={$bmid}$urlext";
        $vh = $he_huodong->fetch($v['hid']);
        if($he_config['hdksq']>0 && $vh['starttime']-$he_config['hdksq'] <TIMESTAMP){
            hb_message(lang_he('hdjjks',0), 'error');
        }
        if($vh['starttime']+$he_config['yxtksj'] <TIMESTAMP){
            hb_message(lang_he('hdyks',0), 'error');
        }

        if($he_order->check_allow_refund($v)){
            $r = DB::update('xigua_he_order', array( 'status' => 4, 'refund_ts' => TIMESTAMP ), array(
                'uid' => $_G['uid'],
                'id' => $bmid,
            ));
            if($r && $v['pay_ts']>0 && $paymoney >0){
                $wxback = 0;
                if($canbacktowx){
                    $hborder = C::t('#xigua_hb#xigua_hb_order')->fetch($v['order_id']);
                    if($hborder['fromopenid']){
                        $out_trade_no = $v['order_id'];
                        $total_fee = intval($paymoney*100);
                        $refund_fee = $total_fee;
                        $tkprofile= '<br>'.lang('plugin/xigua_he', 'tkje').floatval($refund_fee/100).'<br>'.lang('plugin/xigua_he', 'zfje').floatval($total_fee/100);
                        try{
                            $input = new WxPayRefundSF();
                            $input->SetOut_trade_no($out_trade_no);
                            $input->SetTotal_fee($total_fee);
                            $input->SetRefund_fee($refund_fee);
                            $refund_order = substr(md5($out_trade_no), 0,8).date("YmdHis").mt_rand(100,999);
                            $input->SetOut_refund_no($refund_order);
                            $input->SetOp_user_id(WxPayConfigSF::MCHID);

                            $rett = WxPayApiSF::refund($input, 10);
                            $ret1 = diconv(var_export($rett, 1), 'UTF-8', CHARSET);
                            $ret2 = lang('plugin/xigua_he', 'tkxq').lang('plugin/xigua_he', $rett['return_code']).diconv($rett['return_msg'],'UTF-8', CHARSET);
                            if($rett["return_code"] == "SUCCESS" && $rett["result_code"] == "SUCCESS"){
                                $wxback = 1;
                            }
                        }catch (Exception $e){
                        }
                    }
                }

                if($_G['cache']['plugin']['xigua_hh']) {
                    DB::query("DELETE FROM " . DB::table('xigua_hh_income') . " WHERE info LIKE '%{$v['order_id']}%' and reach<>1 LIMIT 2");
                }
                C::t('#xigua_he#xigua_he_huodong')->incr($v['hid'], 'joins', -1);
                if($wxback){
                    DB::update('xigua_he_order', array('refund' => lang('plugin/xigua_he', 'dh').$refund_order.'<br>'.$ret1 ), array('id' => $bmid));

                    notification_add($v['uid'],'system', lang('plugin/xigua_he', 'tksq_tip2'),array('url' => $jup),1);
                    hb_message(lang_he('tksq_tip2_',0), 'success', 'reload');
                }else{
                    DB::update('xigua_he_order', array('refund' => lang_he('tksq_tip3_',0) ), array('id' => $bmid));

                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid' => $v['uid'],
                        'crts' =>TIMESTAMP,
                        'size' => $v['pay_money'],
                        'note' => lang_he('tksq_tip3_',0),
                        'link' => $jup,
                    ));
                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['uid'], 'money', $v['pay_money']);

                    notification_add($v['uid'],'system', lang('plugin/xigua_he', 'tksq_tip3'),array('url' => $jup),1);
                    hb_message(lang_he('tksq_tip3_',0), 'success', 'reload');
                }
            }
        }
    }
}elseif($do == 'shenhe'){
    if(submitcheck('bmid')){
        $v = $he_order->fetch_by_bmid($bmid);
        $shids = he_get_shids_by_uid();
        if($_G['uid']){
            $hinfo = $he_huodong->fetch($v['hid']);
        }
        $ismanage = ($v['shid']&&in_array($v['shid'], $shids)) || $hinfo['uid']==$_G['uid'];
        if(!$ismanage){
            hb_message('error', 'error');
        }
        if($v['status'] != 5){
//            hb_message('error', 'error');
        }
        if($_GET['stat']==2){
            $he_order->update($bmid, array('status' => 2, 'upts'=> TIMESTAMP,));
        }else{
            $he_order->update($bmid, array('status' => 7, 'upts'=> TIMESTAMP,));
        }
        hb_message(lang_he('czcg',0), 'success', 'reload');
    }
}elseif($do == 'showqr') {
    $v = C::t('#xigua_he#xigua_he_order')->fetch($_GET['bmid']);
    if ($v['hxcode']) {
        if ($r = he_qrcode_make($v['id'], $v['hxcode'])) {
            dheader("Location: $r?".VERHASH);
        }
    }
}