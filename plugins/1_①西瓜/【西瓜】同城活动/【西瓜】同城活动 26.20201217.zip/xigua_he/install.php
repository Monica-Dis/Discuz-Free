<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_he_cat` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `fid` varchar(20) NOT NULL,
 `in_ad` varchar(800) NOT NULL,
 `in_adlnk` varchar(800) NOT NULL,
 `isshow` int(11) NOT NULL,
 `multiprice` varchar(2000) NOT NULL,
 `tpl` varchar(20) NOT NULL,
 `telpri` decimal(10,2) NOT NULL,
 `groups` varchar(800) NOT NULL,
 `verify1` int(11) NOT NULL,
 `verify2` int(11) NOT NULL,
 `bao` int(11) NOT NULL,
 `maxdig` int(11) NOT NULL,
 `apprice` decimal(10,2) NOT NULL DEFAULT '0.00',
 `share_title` varchar(200) NOT NULL,
 `share_desc` varchar(200) NOT NULL,
 `share_pic` varchar(200) NOT NULL,
 `cat_link` varchar(200) NOT NULL,
 `zdprice` varchar(800) NOT NULL,
 `jiaobiao` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `isshow` (`isshow`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_he_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_he_huodong` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `status` int(11) NOT NULL DEFAULT '0',
 `uid` int(11) NOT NULL,
 `title` varchar(256) NOT NULL,
 `shid` int(11) NOT NULL,
 `catid` int(11) NOT NULL,
 `starttime` int(11) NOT NULL,
 `endtime` int(11) NOT NULL,
 `bstarttime` int(11) NOT NULL,
 `bendtime` int(11) NOT NULL,
 `tel` varchar(80) NOT NULL,
 `fengmian` varchar(200) NOT NULL,
 `jieshao` text NOT NULL,
 `bdfield` varchar(1000) NOT NULL,
 `required` varchar(1000) NOT NULL,
 `pzname` varchar(800) NOT NULL,
 `pzprice` varchar(800) NOT NULL,
 `pzhkprice` varchar(800) NOT NULL,
 `pznum` varchar(800) NOT NULL,
 `pzshenhe` varchar(800) NOT NULL,
 `pzmin` varchar(800) NOT NULL,
 `pzmax` varchar(800) NOT NULL,
 `album` text NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `joins` int(11) NOT NULL,
 `favs` int(11) NOT NULL,
 `allow_tk` int(11) NOT NULL,
 `tuijian` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `lat` varchar(32) NOT NULL,
 `lng` varchar(32) NOT NULL,
 `province` varchar(80) NOT NULL,
 `city` varchar(80) NOT NULL,
 `district` varchar(80) NOT NULL,
 `street` varchar(80) NOT NULL,
 `street_number` varchar(80) NOT NULL,
 `addr` varchar(200) NOT NULL,
 `showbm` int(11) NOT NULL,
 `shname` varchar(80) NOT NULL,
 `allnum` int(11) NOT NULL,
 `pricerange` varchar(80) NOT NULL,
 `hkpricerange` varchar(80) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `dig_startts` int(11) NOT NULL,
 `srange` varchar(1000) NOT NULL,
 `order_id` varchar(80) NOT NULL,
 `stid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `append_img` text NOT NULL,
 `append_text` text NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `status` (`status`),
 KEY `upts` (`upts`),
 KEY `crts` (`crts`),
 KEY `hangye_id1` (`catid`),
 KEY `displayorder` (`displayorder`),
 KEY `stid` (`stid`),
 KEY `joins` (`joins`),
 KEY `dig_endts` (`dig_endts`),
 KEY `dig_startts` (`dig_startts`),
 KEY `tuijian` (`tuijian`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_he_index` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(500) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_he_order` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `crts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `order_id` varchar(200) NOT NULL,
 `pay_money` decimal(10,2) NOT NULL,
 `pzmoney` decimal(10,2) NOT NULL,
 `pay_ts` int(11) NOT NULL,
 `hid` int(11) NOT NULL,
 `hdinfo` text NOT NULL,
 `title` varchar(200) NOT NULL,
 `status` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `hxuid` int(11) NOT NULL,
 `hxcrts` int(11) NOT NULL,
 `hxnote` varchar(500) NOT NULL,
 `hxcode` varchar(20) NOT NULL,
 `refund` varchar(800) NOT NULL,
 `refund_id` int(11) NOT NULL,
 `refund_ts` int(11) NOT NULL,
 `bminfo` text NOT NULL,
 `shid` int(11) NOT NULL,
 `num` int(11) NOT NULL,
 `pzinfo` varchar(2000) NOT NULL,
 `stid` int(11) NOT NULL,
 `pz_preprice` decimal(10,2) NOT NULL,
 `pz_typ` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `order_id` (`order_id`),
 KEY `crts` (`crts`),
 KEY `pay_ts` (`pay_ts`),
 KEY `gid` (`hid`),
 KEY `status` (`status`),
 KEY `refund_id` (`refund_id`),
 KEY `shid` (`shid`),
 KEY `pz_typ` (`pz_typ`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_he_var` (
 `pluginvarid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
 `pluginid` varchar(20) NOT NULL DEFAULT '0',
 `displayorder` tinyint(3) NOT NULL DEFAULT '0',
 `title` varchar(100) NOT NULL DEFAULT '' ,
 `description` varchar(255) NOT NULL DEFAULT '',
 `type` varchar(20) NOT NULL DEFAULT 'text',
 `value` text NOT NULL,
 `extra` text NOT NULL,
 `unitnew` varchar(80) NOT NULL,
 `required` int(11) NOT NULL,
 `unchangeable` int(11) NOT NULL,
 `formsearch` int(11) NOT NULL,
 `placehd` varchar(512) NOT NULL,
 PRIMARY KEY (`pluginvarid`),
 KEY `pluginid` (`pluginid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_he_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

SQL;
runquery($sql);




$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'numtotal\'', array('xigua_he_order'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_he_order` ADD `numtotal` INT(11) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'pzhhr1\'', array('xigua_he_huodong'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_he_huodong` ADD `pzhhr1` VARCHAR(800) NOT NULL;

ALTER TABLE `pre_xigua_he_huodong` ADD `pzhhr2` VARCHAR(800) NOT NULL;

SQL;
    runquery($sql);
}
$sql =<<<SQL

ALTER TABLE `pre_xigua_he_huodong` CHANGE `pzhhr1` `pzhhr1` VARCHAR(1000) NOT NULL;
ALTER TABLE `pre_xigua_he_huodong` CHANGE `srange` `srange` VARCHAR(800) NOT NULL;
ALTER TABLE `pre_xigua_he_huodong` CHANGE `pzshenhe` `pzshenhe` VARCHAR(1000) NOT NULL;

SQL;
runquery($sql);


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'chengben_price\'', array('xigua_he_huodong'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_he_huodong` ADD `chengben_price` VARCHAR(1000) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'xuniuid\'', array('xigua_he_huodong'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_he_huodong` ADD `xuniuid` TEXT NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hk_d_price\'', array('xigua_he_huodong'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_he_huodong` CHANGE `pzmin` `pzmin` VARCHAR(1000) NOT NULL;
ALTER TABLE `pre_xigua_he_huodong` CHANGE `pzmax` `pzmax` VARCHAR(1000) NOT NULL;
ALTER TABLE `pre_xigua_he_huodong` CHANGE `pzhkprice` `pzhkprice` VARCHAR(1000) NOT NULL;
ALTER TABLE `pre_xigua_he_huodong` ADD `d_price` VARCHAR(1000) NOT NULL;
ALTER TABLE `pre_xigua_he_huodong` ADD `hk_d_price` VARCHAR(1000) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'jz\'', array('xigua_he_huodong'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_he_huodong` ADD `jz` INT(11) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'customtxt\'', array('xigua_he_huodong'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_he_huodong` ADD `customtxt` VARCHAR(1000) NOT NULL;

SQL;
    runquery($sql);
}


@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/discuz_plugin_xigua_he_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_he/install.php');

