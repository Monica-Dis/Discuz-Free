<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_he/function.php';


$hid = intval($_GET['hid']);

$url = $_G['siteurl']."$SCRITPTNAME?id=xigua_he&ac=view&hid=$hid&st={$_GET['st']}".$_G['cookie']['URLEXT'];

$ewm = md5($hid.$url.$_G['cookie']['URLEXT']);

$repath = './source/plugin/xigua_he/cache/';
$qrfile = $repath . $ewm . '.png';
$abs_qrfile = DISCUZ_ROOT . $qrfile;

if (!is_file($abs_qrfile)) {
    @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
    if(class_exists('QRcode')){
        QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
    }
}
dheader('Location: '.$_G['siteurl'].$qrfile.'?'.VERHASH);