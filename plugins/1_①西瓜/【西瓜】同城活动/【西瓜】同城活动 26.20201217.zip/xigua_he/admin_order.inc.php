<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_he/function.php';

$pzfield = array('pzname', 'pzprice', 'pzhkprice', 'pznum', 'pzshenhe', 'pzmin', 'pzmax', 'pzhhr1', 'pzhhr2', 'chengben_price','d_price', 'hk_d_price');
he_doinit_status();

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}

$page = max(1, intval($_GET['page']));
$lpp = $_GET['lpp'] ? $_GET['lpp'] : 10;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_he#xigua_he_order')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            C::t('#xigua_he#xigua_he_order')->update($index, $item);
        }
    }
    unset($_GET['formhash']);
    unset($_GET['r']);
    unset($_GET['permsubmit']);
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_order".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey(addslashes($_GET['keyword']));
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword'";
}elseif($keyword){
    $wherearr[] = " order_id like '%$keyword%' OR hdinfo like '%$keyword%' OR title like '%$keyword%' OR bminfo like '%$keyword%'";
}

$order = 'id desc';
if($_GET['status']){
    $wherearr[] = "status='".intval($_GET['status'])."'";
}
echo '<link rel="stylesheet" href="source/plugin/xigua_he/static/admincp.css?1" />';
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_order");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_he('searchinput',0).'" value="'.$_GET['keyword'].'" class="txt"  style="width: 220px;"/> ';

echo '<select name="status"><option value="0">'.lang_he('qb',0).'</option>';
foreach ($order_status as $index => $item) {
    $chk = isset($_GET['status']) && $_GET['status']==$index ? 'selected':'';
    echo " <option value=\"$index\" $chk>$item</option>";
}
echo '</select>';

echo '&nbsp;&nbsp;&nbsp;';
$lpp_se = "<select name=\"lpp\">";
foreach (array(1, 10 ,20, 50, 100, 200, 500, 1000, 5000, 10000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;

echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_order".' class="btn" >'.cplang('reset').'</a> ';

echo ' <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_order&".http_build_query($_GET).'&doexport=1" class="btn" >'.lang_he('dc', 0).'</a> ';


echo '</div>';


$spmc = lang_he('spmc',0);
$sssj = lang_he('sssj',0);
$lxdh = lang_he('lxdh',0);
$hddz = lang_he('hddz',0);
$bmsj = lang_he('bmsj',0);
$hdsj = lang_he('hdsj',0);
$ddzt = lang_he('ddzt',0);
$hxm = lang_he('hxm',0);
$dzp = lang_he('dzp',0);
$ypsj = lang_he('ypsj',0);
$ypr = lang_he('ypr',0);
$zfje = lang_he('zfje',0);
showtableheader(lang_he('tichengmanage', 0));
$ress = array();

showtablerow('class="header"',array(),$ress[] = array(
    lang_hb('del', 0),
    lang_he('ID', 0),
    lang_he('bmxq', 0),
    lang_he('ddxinxi', 0).
    lang_he('status', 0),
    lang_he('pzname', 0),
    lang_he('spxq', 0),
));

$res = C::t('#xigua_he#xigua_he_order')->fetch_all_by_where($wherearr, $start_limit, $lpp, $order);
$icount = C::t('#xigua_he#xigua_he_order')->fetch_count_by_where($wherearr);

$uids = $ordersns= array();
foreach ($res as $v) {
    $uids[] = $v['uid'];
    $uids[] = $v['hxuid'];
    $ordersns[] = $v['order_id'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $vusers = DB::fetch_all('SELECT uid,realname,mobile FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}
if($ordersns){
    $ordersns = DB::fetch_all('SELECT order_id,order_sn,paystatus,baseprice FROM %t WHERE order_id IN (%n)', array('xigua_hb_order', $ordersns), 'order_id');
}
$kdgs = lang_he('kdgs',0);
$kddh = lang_he('kddh',0);
$uname = lang_he('fkyh', 0);
$lxr = lang_he('lxr', 0);
$lxsj = lang_he('lxsj', 0);
foreach ($res as $k => $v) {
    $id = $v['id'];
    $uid = $v['uid'];
    $v['hxcrts_u'] = $v['hxcrts'] ? date('Y-m-d H:i:s', $v['hxcrts']) : '';

    $seltxt = '';
    $sel =  '';
    foreach ($order_status as $index => $item) {
        if($v['status'] == $index){
            $sel .= "<option value=\"$index\" selected>$item</option>";
            $seltxt = $item;
        }else{
            $sel .= "<option value=\"$index\">$item</option>";
        }
    }
    $bminf = '<table class="pztable" style="width:200px">';
    $bminf .= <<<HTML
    <tr><td>UID</td><td>$uid</td></tr>
    <tr><td>$uname</td><td><a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a></td></tr>
    <tr><td>$lxr</td><td>{$vusers[$uid]['realname']}</td></tr>
    <tr><td>$lxsj</td><td>{$vusers[$uid]['mobile']}</td></tr>
HTML;
    $bmxq = '';
    foreach($v['bminfo'] as $__k => $__v) {
        $bminf .= "<tr><td>{$__v['title']}</td><td>";

        if($__v['type']=='pics') {
            if(is_array($__v['value'])) foreach($__v['value'] as $_img) {
                $bminf .= <<<HTML
 <span class="sp">
     <img class="imgi" src="$_img" onmouseover="$('icon{$k}_{$__k}').style.display='block'" onmouseout="$('icon{$k}_{$__k}').style.display='none'" />
     <img id="icon{$k}_{$__k}" src="$_img"  class="imgprevew" />
 </span>
HTML;
            }
        } else {
            $bminf .= $__v['html'];
        }
        $bminf .= '</td></p>';
        $bmxq .= $__v['title'].':'.str_replace(',','',$__v['html'])." ";
    }
    $bminf .= '</table>';

    $pinfo = "<table class='pztable' style='width:300px'>";
    foreach ($pzfield as  $pzvar) {
        $pz_var_ary = $v['pzinfo'];
        if($pzvar =='pzshenhe'){
            $chvar = $pz_var_ary[$i] ? cplang('yes') : cplang('no');
            $pinfo .= " <tr><td>".lang_he($pzvar, 0). "</td> <td>$chvar</td> </tr> ";
        }else{
            $pinfo .= "<tr><td>".lang_he($pzvar, 0). "</td> <td> $pz_var_ary[$pzvar] </td></tr> ";
        }
    }
    $pinfo .= '</table>';

    $hinfo = <<<HTML
<table class="pztable" style="width:400px">
<tr><td>$spmc</td><td>{$v['hdinfo']['title']} (ID : {$v['hdinfo']['id']})</td></tr>
<tr><td>$sssj</td><td>{$v['hdinfo']['shname']} (ID : {$v['hdinfo']['shid']})</td></tr>
<tr><td>$lxdh</td><td>{$v['hdinfo']['tel']}</td></tr>
<tr><td>$hddz</td><td>{$v['hdinfo']['city']}{$v['hdinfo']['district']}{$v['hdinfo']['street']}{$v['hdinfo']['addr']}</td></tr>
<tr><td>$bmsj</td><td>{$v['hdinfo']['bstart_u']} - {$v['hdinfo']['bend_u']}</td></tr>
<tr><td>$hdsj</td><td>{$v['hdinfo']['start_u']} - {$v['hdinfo']['end_u']}</td></tr>
</table>
HTML;

    $rplink = '';
    if ($v['hxcode']) {
        $rplink = he_qrcode_make($v['id'], $v['hxcode']);
    }
    $stinfo = <<<HTML
<tr><td>$ddzt</td><td><select name='r[$id][status]'>$sel</select></td></tr>
<tr><td>$hxm</td><td>{$v['hxcode']}</td></tr>
<tr><td>$dzp</td><td><a href="$rplink" target="_blank"><img src="$rplink" style="width:80px;" /></a> </td></tr>
<tr><td>$ypsj</td><td>{$v['hxcrts_u']}</td></tr>
<tr><td>$ypr</td><td>{$users[$v['hxuid']]['username']}</td></tr>
</table>
HTML;
    showtablerow('', array(), $res_ = array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
        $id,
        $bminf,
        '<table class="pztable"  style="width:280px"><tr><td>'.lang_hb('orderid',0).'</td><td><a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_order&keyword=".$v['order_id']."&note=0&page=1".'">'.$v['order_id'] . '</a></td></tr><tr><td>'.
        (lang_hb('ordersn',0).'</td><td>'.$ordersns[$v['order_id']]['order_sn'] . '</td></tr><td>' ).
        lang_he('crts',0).'</td><td>'. $v['crts_u'] .'</td></tr><td>'.
        lang_he('zfsj',0).'</td><td>'. $v['pay_ts_u'] . '</td></tr><td>'.
        lang_he('ddje',0).'</td><td><b>&yen; '. floatval($ordersns[$v['order_id']]['baseprice']) . '</b></td></tr>'.
        "<tr><td>$zfje</td><td><b>&yen; {$v['pay_money']}</b></td></tr>".
        ''.$stinfo,
        $pinfo,
        $hinfo,
    ));


    $resk[$k][] = $uid;
    $resk[$k][] = $users[$uid]['username'];
    $resk[$k][] = $vusers[$uid]['realname'] ?$vusers[$uid]['realname']: '-';
    $resk[$k][] = $vusers[$uid]['mobile'] ? $vusers[$uid]['mobile'] : '-';
    $resk[$k][] = $bmxq;
    $resk[$k][] = $v['order_id'];
    $resk[$k][] = $ordersns[$v['order_id']]['order_sn'];
    $resk[$k][] = $v['crts_u'];
    $resk[$k][] = $v['pay_ts_u'];
    $resk[$k][] = floatval($ordersns[$v['order_id']]['baseprice']);
    $resk[$k][] = $v['pay_money'];
    $resk[$k][] = $seltxt;
    $resk[$k][] = $v['hxcode'];
    $resk[$k][] = $v['hxcrts_u'];
    $resk[$k][] = $users[$v['hxuid']]['username'];
    $resk[$k][] = $v['pzinfo']['pzname'];
    $resk[$k][] = "{$v['hdinfo']['title']} (ID : {$v['hdinfo']['id']})";
    $resk[$k][] = "{$v['hdinfo']['shname']} (ID : {$v['hdinfo']['shid']})";
    $resk[$k][] = $v['hdinfo']['tel'];
    $resk[$k][] = "{$v['hdinfo']['city']}{$v['hdinfo']['district']}{$v['hdinfo']['street']}{$v['hdinfo']['addr']}";
    $resk[$k][] = "{$v['hdinfo']['bstart_u']} - {$v['hdinfo']['bend_u']}";
    $resk[$k][] = "{$v['hdinfo']['start_u']} - {$v['hdinfo']['end_u']}";

    $resk[$k][] = ' ';
}

if($_GET['doexport']==1){
    $title_arr= array(
        'UID',
        $uname,
        $lxr,
        $lxsj,
        lang_he('bmxq', 0),
        lang_hb('orderid',0),
        lang_hb('ordersn',0),
        lang_he('crts',0),
        lang_he('zfsj',0),
        lang_he('ddje',0),
        $zfje,
        $ddzt,
        $hxm,
        $ypsj,
        $ypr,
        lang_he('pzname', 0),
        $spmc,
        $sssj,
        $lxdh,
        $hddz,
        $bmsj,
        $hdsj,
        ' ',
    );
    $resk = array_values($resk);

  /*  echo '<pre>';
    print_r($resk);
    echo '</pre>';
    exit;*/

    export_csv($resk, $title_arr);
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_order&lpp=$lpp".http_build_query($_GET).'&doexport=0', 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/
