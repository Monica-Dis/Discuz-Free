function he_getlocation(callback){
if(0&&typeof mag != 'undefined'){
mag.getLocation(function(res){
callback(res);
});
}else if(typeof sq != 'undefined'){
sq.getLocation(function(res){
callback(res);
});
}else if(typeof QFH5 != 'undefined') {
QFH5.getLocation(function (state, data) {
if (state == 1) {callback(data);} else {alert(data.error);}});
}else if(HB_INWECHAT&& HS_MULTIUPLOAD) {
wx.getLocation({
type: 'gcj02',
success: function (res) {
callback(res);
},
cancel: function (res) {
}
});
}else{
console.log('myapp');
var geolocation = new qq.maps.Geolocation(mkey, "myapp");
geolocation.getLocation(callback, function () {
}, {timeout:4000, failTipFlag:true});
}
}
function he_getnext(id, name, datahref){
$('.sub_check a').removeClass('checked').removeClass('main_color');
$('.sub_check a').parent().removeClass('checked').removeClass('main_color');
$('#sub_check'+id).addClass('checked').addClass('main_color');
$.ajax({
type: 'get',
url: _APPNAME + '?id=xigua_hb&ac=chosecity&province='+$('.first_check+.checked').find('a').text()+'&name='+name+'&ctid='+id+'&datahref='+encodeURIComponent(datahref)+'&inajax=1',
dataType: 'xml',
success: function (data) {
if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
var s = data.lastChild.firstChild.nodeValue;
$('.ajaxbox_cheker').html(s);
}
});
}

$(document).on('click', '.jump_he', function () {
var that = $(this);
var jmpurl = _APPNAME +'?id=xigua_he&ac=view&hid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
if(typeof mag !== 'undefined'){
mag.newWin(GSITE+jmpurl);
return false;
}
if(typeof wx !=='undefined'){
if (window.__wxjs_environment === 'miniprogram') {
wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
return false;
}
}
window.location.href = jmpurl;
return false;
});

$(document).on('click','#dosearch', function () {
if($('#searchInput').val()){
$('#dosearchform').submit();
}else{
$.alert($('#searchInput').attr('placeholder'));
}
});
$(document).on('click','.herefresh', function () {
var that = $(this);
$.ajax({
type: 'get',
url: _APPNAME + '?id=xigua_he&ac=index&do=gettj&inajax=1&st='+that.data('st'),
dataType: 'xml',
success: function (data) {
if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
var s = data.lastChild.firstChild.nodeValue;
if(s){
$('.index_recom_list').html(s);
}}});});
$(document).on('click','.nearctrl', function () {
var that = $(this);
var href= that.data('href');
he_getlocation(function (position) {
var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
window.location.href= href+ '&lat='+lat+'&lng='+lng;
});});