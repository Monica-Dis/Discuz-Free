<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
$he_config = $_G['cache']['plugin']['xigua_he'];
include_once DISCUZ_ROOT . 'source/plugin/xigua_he/function.php';
he_do_get_config();
he_doinit_status();
$pzfield = array('pzname', 'pzprice', 'pzhkprice', 'pznum', 'pzshenhe', 'pzmin', 'pzmax', 'pzhhr1', 'pzhhr2', 'chengben_price', 'd_price', 'hk_d_price');
$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$url = rtrim($url, '/') . '/';
switch ($ac) {
	case 'getloc':
		$ret = _he_current_location($_GET['lat'], $_GET['lng']);
		if (is_array($ret)) {
			hb_message(json_encode($ret), 'success');
		} else {
			hb_message($ret, 'error');
		}
		break;
	case 'index':
		if ($he_config['sytjgs'] > 0) {
			$tuijian_hds = $he_huodong->fetch_all_by_where(array('status=2 AND tuijian=1'), 0, $he_config['sytjgs'], 'rand() DESC');
		}
		if ($do == 'gettj') {
			include template('xigua_hb:header_ajax');
			include template('xigua_he:tuijian_li');
			include template('xigua_hb:footer_ajax');
		}
		he_index();
		break;
	case 'cate':
		$navtitle = $he_config['indextitle'];
		$list = $he_cat->list_by_pid(0, true);
		break;
	case 'wode':
		$navtitle = lang_he('wdhd', 0);
		he_wode();
		break;
	case 'view':
		$v = $he_huodong->fetch_by_id($hid);
		$navtitle = $v['title'];
		$desc = strip_tags(nl2br($v['jieshao']));
		array_unshift($v['album'], $v['fengmian']);
		he_view();
		if ($v['jz']) {
			$totaljz = DB::result_first('select sum(pay_money) from %t where hid=%d and pay_ts>0', array('xigua_he_order', $hid));
		}
		break;
	case 'baoming':
		$navtitle = lang_he('bmxq', 0);
		break;
	case 'baoming_li':
		$hid = intval($hid);
		$huodongv = $he_huodong->fetch_by_id($hid);
		$wherearr = array('status in(2,5,6) AND hid=' . $hid);
		$order = 'id desc';
		$list = $he_order->fetch_all_by_where($wherearr, $start_limit, $lpp, $order, '*', 1);
		include template('xigua_hb:header_ajax');
		include template('xigua_he:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'shop':
		he_shop();
		break;
	case 'next':
		he_check_bind();
		$navtitle = lang_he('bm', 0);
		if (!$hid) {
			$hid = intval($_GET['form']['hid']);
		}
		$v = $he_huodong->fetch_by_id($hid);
		$num = $_GET['num'] ? intval($_GET['num']) : intval($_GET['form']['num']);
		$typ = $_GET['typ'] ? intval($_GET['typ']) : intval($_GET['form']['typ']);
		$pzinfo = array();
		foreach ($pzfield as $index => $item) {
			$pzinfo[$item] = $v[$item][$typ];
		}
		$numary = range(1, $num);
		if ($num < $pzinfo['pzmin']) {
			$errmsg = he_message(lang_he('zsbm', 0) . $pzinfo['pzmin'] . lang_he('r', 0), 'error');
		}
		$myhasjoin = $he_order->fetch_count_by_where('uid=' . $_G['uid'] . ' AND hid=' . $hid . ' AND pz_typ=' . $typ . ' AND status in(2,5,6)');
		if ($myhasjoin + $num > $pzinfo['pzmax']) {
			$errmsg = he_message(lang_he('zdbm', 0) . $pzinfo['pzmax'] . lang_he('r', 0), 'error');
		}
		if ($v['bstarttime'] > TIMESTAMP) {
			$errmsg = he_message(lang_he('hdwks', 0), 'error');
		}
		if ($v['hasend']) {
			$errmsg = he_message(lang_he('hdyjs', 0), 'error');
		}
		if ($v['bhasend']) {
			$errmsg = he_message(lang_he('bmyjs', 0), 'error');
		}
		if ($pzinfo['pznum'] > 0) {
			$hd_hasjoin = $he_order->fetch_count_by_where('hid=' . $hid . ' AND pz_typ=' . $typ . ' AND status in(2,5,6)');
			if ($hd_hasjoin + $num > $pzinfo['pznum']) {
				$errmsg = he_message(lang_he('rsym', 0), 'error');
			}
		}
		$bdvars = array();
		foreach ($he_vars = he_vars($v['catid']) as $index => $bdvar) {
			$bdvars['f_' . $bdvar['pluginvarid']] = $bdvar['title'];
		}
		$bmfield = $bdvars;
		$pzprice = $pzinfo['d_price'] > 0 ? $pzinfo['d_price'] : $pzinfo['pzprice'];
		if ($_GET['jzp']) {
			$pzprice = floatval($_GET['jzp']);
		}
		$ralprice = floatval($pzprice * $num);
		if (!$_GET['jzp'] && $_G['cache']['plugin']['xigua_hk']) {
			$card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G['uid']);
			if ($card && $pzinfo['pzhkprice'] > 0) {
				$pzprice = $pzinfo['pzhkprice'];
			}
			if ($pzinfo['d_price'] > 0) {
				$pzprice = $pzinfo['d_price'];
			}
			if ($card && $pzinfo['hk_d_price'] > 0) {
				$pzprice = $pzinfo['hk_d_price'];
			}
		}
		$pzinfo['price'] = $pzinfo['pzprice'] = $price = $pzprice;
		$totprice = floatval($pzprice * $num);
		if (submitcheck('formhash')) {
			$form = $_GET['form'];
			$datas = array();
			$_order_id = 'HD' . date('YmdHis') . mt_rand(100000, 999999);
			for ($i = 0; $i < $num; $i++) {
				$data = array();
				$bminfo = array();
				foreach ($he_vars as $index => $vvar) {
					if ($v['bdfield']['f_' . $index]) {
						$vindex = 'vars_' . $i;
						$var = $form[$vindex][$index];
						if (!$var && $v['required']['f_' . $index]) {
							hb_message(lang_hb('qtx', 0) . $vvar['title'], 'error');
						}
						$html = '';
						foreach (explode("\n", trim($vvar['extra'])) as $str => $extra_string) {
							list($_tmp1, $_tmp2) = explode('=', trim($extra_string));
							$_tmp2 = trim($_tmp2);
							if ($_tmp1 == $var) {
								$html = $_tmp2;
								break;
							}
							if (in_array($_tmp1, $var)) {
								$html .= ' ' . $_tmp2;
							}
						}
						$bminfo[$index] = array('title' => $vvar['title'], 'value' => $var, 'html' => ($html ? $html : (is_array($var) ? $var[0] : $var)) . $vvar['unitnew'], 'type' => $vvar['type']);
					}
				}
				$data['uid'] = $_G['uid'];
				$data['crts'] = TIMESTAMP;
				$data['upts'] = TIMESTAMP;
				$data['status'] = 1;
				$data['pz_typ'] = $typ;
				$data['hid'] = $hid;
				$data['num'] = 1;
				$data['numtotal'] = $num;
				$data['stid'] = $form['st'];
				$data['pzinfo'] = serialize($pzinfo);
				$data['hdinfo'] = serialize($v);
				$data['pay_money'] = $price;
				$data['pay_ts'] = 0;
				$data['title'] = lang_he('cjhd', 0) . '-' . $v['title'];
				$data['bminfo'] = serialize($bminfo);
				$data['shid'] = $v['shid'];
				$data['order_id'] = $_order_id;
				$data['pzmoney'] = $pzprice;
				$data['pz_preprice'] = $price;
				$data['status'] = $totprice > 0 ? 1 : ($pzinfo['pzshenhe'] ? 5 : 2);
				$data['hxcode'] = substr(mt_rand(100000000, 999999999), 0, 9);
				$bmid = $he_order->insert($data, true);
				$data['id'] = $bmid;
				$datas[$bmid] = $data;
			}
			$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_he&ac=order_profile&bmid=' . $bmid . $urlext);
			if ($totprice > 0) {
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totprice, $data['title'], 'common_bm', array('data' => $datas, 'callback' => array('file' => 'source/plugin/xigua_he/function.php', 'method' => 'he_baoming_callback'), 'location' => $rtl, 'referer' => $rtl));
				foreach ($datas as $index => $item) {
					$he_order->update($index, array('order_id' => $order_id));
				}
				$rl = urlencode($rtl);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext);
				hb_message(lang_he('zhiftiao', 0), 'success', $jumpurl);
			} else {
				C::t('#xigua_he#xigua_he_huodong')->incr($hid, 'joins', $num);
				if ($data['status'] == 5) {
					$url = $_G['siteurl'] . $SCRITPTNAME . '?id=xigua_he&ac=bgm&status=5&hid=' . $hid . $urlext;
					he_post_byshid(lang_he('new_need_shen_dd', 0), array('url' => $url, 'id' => $hid), $shid);
				} else {
					$url = $_G['siteurl'] . $SCRITPTNAME . '?id=xigua_he&ac=bgm&hid=' . $hid . $urlext;
					he_post_byshid(lang_he('new_in_dd', 0), array('url' => $url, 'id' => $hid), $shid);
				}
				hb_message(lang_he('bmok', 0), 'success', $rtl);
			}
		}
		break;
	case 'order':
		$navtitle = lang_he('wddd', 0);
		break;
	case 'order_li':
		$wherearr = array();
		$order = 'id DESC';
		if ($_GET['manage']) {
			$shids = he_get_shids_by_uid();
			if ($shids) {
				$wherearr[] = 'shid in (' . implode(',', $shids) . ')';
			}
		} else {
			$wherearr[] = 'uid=' . $_G['uid'];
		}
		if ($_GET['status']) {
			$sta = dintval(explode(',', $_GET['status']), 1);
			$wherearr[] = 'status IN ( ' . implode(',', $sta) . ' )';
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (title LIKE \'%' . $keyword . '%\' OR order_id LIKE \'%' . $keyword . '%\') ';
		}
		$GLOBALS['need_sh'] = 1;
		$lpp = 50;
		$list = array();
		$listall = $he_order->fetch_all_by_where($wherearr, $start_limit, $lpp, $order, '*');
		foreach ($listall as $index => $item) {
			if (!$list[$item['order_id']]) {
				$list[$item['order_id']] = $item;
			}
			$list[$item['order_id']]['newbminfo'][] = $item['bminfo'];
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_he:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'order_profile':
		$navtitle = lang_he('ddxq', 0);
		$bmid = intval($_GET['bmid']);
		$vs = $he_order->fetch_by_orderid($bmid);
		$bmstr = '';
		$pay_money = 0;
		$pzmoney = 0;
		$bminfo = array();
		foreach ($vs as $index => $item) {
			foreach ($item['bminfo'] as $index1 => $item1) {
				$bmstr .= !($item1['type'] == 'pics') ? ' ' . $item1['html'] : '';
			}
			if ($bmstr) {
				$bmstr .= ' ';
			}
			$pay_money += $item['pay_money'];
			$pzmoney += $item['pzmoney'];
		}
		$v = $vs[0];
		$shids = he_get_shids_by_uid();
		$ismanage = $_GET['manage'] && in_array($v['shid'], $shids);
		if ($v['uid'] != $_G['uid']) {
			if (!$ismanage) {
				dheader('Location: ' . $SCRITPTNAME . '?id=xigua_he');
			}
		}
		$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid'], 0);
		$v['user'] = getuserbyuid($v['uid']);
		if (!$ismanage) {
			$back_to_overwrite = $SCRITPTNAME . '?id=xigua_he&ac=order' . $urlext;
		}
		$hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($v['uid']);
		$mobile = $hbuser['mobile'];
		if (!$mobile) {
			$__profile = C::t('common_member_profile')->fetch($v['uid']);
			$mobile = $__profile['mobile'];
		}
		$v['mobile'] = $mobile;
		break;
	case 'myhe':
		$data = he_myhe();
		$navtitle = lang_he('fabuguanli', 0);
		$custom_side = array($SCRITPTNAME . '?id=xigua_he&ac=wode&view=zbf' . $urlext, lang_he('wode', 0));
		break;
	case 'myhe_li':
		$wherearr = array();
		$wherearr[] = 'uid=' . $_G['uid'];
		if ($_GET['status']) {
			$wherearr[] = 'status=' . intval($_GET['status']);
		}
		if ($_GET['endts'] == 1) {
			$wherearr[] = 'bendtime>0 AND bendtime<' . TIMESTAMP;
		} else {
			if ($_GET['status'] == 2) {
				$wherearr[] = ' ( bendtime>=' . TIMESTAMP . ' OR bendtime=0 )';
			}
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (title LIKE \'%' . $keyword . '%\' OR jieshao LIKE \'%' . $keyword . '%\') ';
		}
		$order_by = 'id DESC';
		$list = $he_huodong->fetch_all_by_where($wherearr, $start_limit, $lpp, $order_by);
		include template('xigua_hb:header_ajax');
		include template('xigua_he:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'he_li':
		$wherearr = array();
		$wherearr[] = 'status=2';
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (title LIKE \'%' . $keyword . '%\' OR jieshao LIKE \'%' . $keyword . '%\') ';
		}
		if ($not = intval($_GET['not'])) {
			$wherearr[] = ' id!=' . $not . ' ';
		}
		if ($shid = intval($_GET['shid'])) {
			$wherearr[] = ' shid=' . $shid . ' ';
		}
		if ($_GET['uid']) {
			$wherearr[] = 'uid=' . intval($_GET['uid']);
		}
		$order_by = 'id DESC';
		$viewtype = $_GET['viewtype'];
		if (!$viewtype) {
			$viewtype = $orderby = $_GET['orderby'];
		}
		$orary = $he_huodong->get_order($viewtype);
		$order_by = $orary['order_by'];
		$field = $orary['field'];
		if ($hyid = intval($_GET['hyid'])) {
			$pids = array($hyid);
			if ($hyinfo = $he_cat->get_childs_by_pids($hyid)) {
				foreach ($hyinfo as $index => $item) {
					$pids[] = intval($item['id']);
				}
				if ($pids) {
					$wherearr[] = ' catid IN(' . implode(',', $pids) . ') ';
				}
			} else {
				$wherearr[] = ' catid =' . $hyid;
			}
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (title LIKE \'%' . $keyword . '%\' OR addr LIKE \'%' . $keyword . '%\' OR jieshao LIKE \'%' . $keyword . '%\' OR srange LIKE \'%' . $keyword . '%\' ) ';
		}
		if ($province = daddslashes($_GET['province'])) {
			$wherearr[] = ' province=\'' . $province . '\' ';
		}
		if ($city = daddslashes($_GET['city'])) {
			$wherearr[] = ' city=\'' . $city . '\' ';
		}
		if ($dist = daddslashes($_GET['dist'])) {
			$wherearr[] = ' district=\'' . $dist . '\' ';
		}
		if ($tag = stripsearchkey($_GET['tag'])) {
			$wherearr[] = ' srange LIKE \'%' . $tag . '%\' ';
		}
		if ($_G['uid'] > 0 && $_GET['fav']) {
			$_lst = C::t('#xigua_hb#xigua_hb_follow')->fetch_all_by_page(array('favtype=\'huodong\' AND uid=' . $_G['uid']), $start_limit, $lpp);
			$_tp = array();
			foreach ($_lst as $v) {
				$_tp[] = $v['favid'];
			}
			if ($_tp) {
				$wherearr[] = ' id in (' . implode(',', $_tp) . ')';
			} else {
				$wherearr[] = ' id=\'abc\' ';
			}
		}
		$list = $he_huodong->fetch_all_by_where($wherearr, $start_limit, $lpp, $order_by, $field);
		include template('xigua_hb:header_ajax');
		include template('xigua_he:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'bgm':
		$huodong = $he_huodong->fetch_by_id($hid);
		$navtitle = lang_he('tichengmanage', 0) . ($huodong ? '-' . $huodong['title'] : '');
		$custom_side = array($SCRITPTNAME . '?id=xigua_he&ac=wode&view=zbf' . $urlext, lang_he('wode', 0));
		break;
	case 'bgm_li':
		$wherearr = array();
		$order = 'id DESC';
		$shids = he_get_shids_by_uid();
		if ($shids) {
			$wherearr[] = 'shid in (' . implode(',', $shids) . ')';
		}
		if ($_GET['status']) {
			$sta = dintval(explode(',', $_GET['status']), 1);
			$wherearr[] = 'status IN ( ' . implode(',', $sta) . ' )';
		}
		if ($hid) {
			$wherearr[] = 'hid=' . $hid;
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (title LIKE \'%' . $keyword . '%\' OR order_id LIKE \'%' . $keyword . '%\' OR bminfo LIKE \'%' . $keyword . '%\') ';
		}
		$GLOBALS['need_sh'] = 1;
		$uids = array();
		if ($_GET['export'] != 1) {
			$list = $he_order->fetch_all_by_where($wherearr, $start_limit, $lpp, $order, '*');
			foreach ($list as $index => $item) {
				$uids[] = $item['uid'];
			}
			if ($uids) {
				$users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
			}
		} else {
			if ($_GET['export'] == 1) {
				include_once DISCUZ_ROOT . 'source/plugin/xigua_he/include/c_bgmli.php';
				$kdgs = lang_he('kdgs', 0);
				$kddh = lang_he('kddh', 0);
				$uname = lang_he('fkyh', 0);
				$lxr = lang_he('lxr', 0);
				$lxsj = lang_he('lxsj', 0);
				$spmc = lang_he('spmc', 0);
				$sssj = lang_he('sssj', 0);
				$lxdh = lang_he('lxdh', 0);
				$hddz = lang_he('hddz', 0);
				$bmsj = lang_he('bmsj', 0);
				$hdsj = lang_he('hdsj', 0);
				$ddzt = lang_he('ddzt', 0);
				$hxm = lang_he('hxm', 0);
				$dzp = lang_he('dzp', 0);
				$ypsj = lang_he('ypsj', 0);
				$ypr = lang_he('ypr', 0);
				$zfje = lang_he('zfje', 0);
				$title_arr = array('UID', $uname, $lxr, $lxsj, lang_he('bmxq', 0), lang_hb('orderid', 0), lang_hb('ordersn', 0), lang_he('crts', 0), lang_he('zfsj', 0), lang_he('ddje', 0), $zfje, $ddzt, $hxm, $ypsj, $ypr, lang_he('pzname', 0), $spmc, $sssj, $lxdh, $hddz, $bmsj, $hdsj, ' ');
				$list = $he_order->fetch_all_by_where($wherearr, 0, 99999, $order, '*');
				$uids = $ordersns = array();
				foreach ($list as $index => $item) {
					$uids[] = $item['uid'];
					$uids[] = $item['hxuid'];
					$ordersns[] = $item['order_id'];
				}
				if ($uids) {
					$users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
					$vusers = DB::fetch_all('SELECT uid,realname,mobile FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
				}
				if ($ordersns) {
					$ordersns = DB::fetch_all('SELECT order_id,order_sn,paystatus,baseprice FROM %t WHERE order_id IN (%n)', array('xigua_hb_order', $ordersns), 'order_id');
				}
				$resk = array();
				foreach ($list as $index => $item) {
					$v = $item;
					$id = $v['id'];
					$uid = $v['uid'];
					$k = $index;
					$bmxq = '';
					foreach ($item['bminfo'] as $__k => $__v) {
						$bmxq .= $__v['title'] . ':' . str_replace(',', '', $__v['html']) . ' ';
					}
					$seltxt = '';
					foreach ($order_status as $_index => $_item) {
						if ($item['status'] == $_index) {
							$seltxt = $_item;
						}
					}
					$resk[$k][] = $uid;
					$resk[$k][] = $users[$uid]['username'];
					$resk[$k][] = $vusers[$uid]['realname'] ? $vusers[$uid]['realname'] : '-';
					$resk[$k][] = $vusers[$uid]['mobile'] ? $vusers[$uid]['mobile'] : '-';
					$resk[$k][] = $bmxq;
					$resk[$k][] = $v['order_id'];
					$resk[$k][] = $ordersns[$v['order_id']]['order_sn'];
					$resk[$k][] = $v['crts_u'];
					$resk[$k][] = $v['pay_ts_u'];
					$resk[$k][] = floatval($ordersns[$v['order_id']]['baseprice']);
					$resk[$k][] = $v['pay_money'];
					$resk[$k][] = $seltxt;
					$resk[$k][] = $v['hxcode'];
					$resk[$k][] = $v['hxcrts_u'];
					$resk[$k][] = $users[$v['hxuid']]['username'];
					$resk[$k][] = $v['pzinfo']['pzname'];
					$resk[$k][] = $v['hdinfo']['title'] . ' (ID : ' . $v['hdinfo']['id'] . ')';
					$resk[$k][] = $v['hdinfo']['shname'] . ' (ID : ' . $v['hdinfo']['shid'] . ')';
					$resk[$k][] = $v['hdinfo']['tel'];
					$resk[$k][] = $v['hdinfo']['city'] . $v['hdinfo']['district'] . $v['hdinfo']['street'] . $v['hdinfo']['addr'];
					$resk[$k][] = $v['hdinfo']['bstart_u'] . ' - ' . $v['hdinfo']['bend_u'];
					$resk[$k][] = $v['hdinfo']['start_u'] . ' - ' . $v['hdinfo']['end_u'];
					$resk[$k][] = ' ';
				}
				$resk = array_values($resk);
				he_export_csv(_he_multi_diconv($resk, CHARSET, 'utf-8'), _he_multi_diconv($title_arr, CHARSET, 'utf-8'));
				exit(0);
			}
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_he:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'incr':
		if (submitcheck('formhash')) {
			if (in_array($_GET['incr_type'], array('shares', 'views'))) {
				$he_huodong->incr($hid, $_GET['incr_type']);
				hb_message('success');
			}
		}
		break;
	case 'cat':
		$hyid = intval($_GET['hyid']);
		$hy = $he_cat->fetch($hyid);
		$navtitle = $hy['name'];
		$pid = $hy['pid'];
		if ($_GET['keyword']) {
			$navtitle = $keyword = stripsearchkey($_GET['keyword']);
		}
		if ($_GET['tag']) {
			$navtitle = stripsearchkey($_GET['tag']);
		}
		$list_all = $he_cat->list_all();
		$he_cat->init($list_all);
		$cat_tree_init = $cat_tree = $he_cat->get_tree_array(0);
		$cat_tree = array_values($cat_tree);
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist0 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist0 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['province']) {
			$distname = $_GET['province'];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if ($distname) {
			$navtitle = $distname . $navtitle;
		}
		if (!$distname) {
			$distname = lang_hb('plugins_edit_vars_type_area', 0);
		}
		$quanname = $_GET['quan'];
		if (!$quanname) {
			$quanname = lang_hb('shangquan', 0);
		}
		$lat = floatval($_GET['lat']);
		$lng = floatval($_GET['lng']);
		$catname = $hy['name'] ? $hy['name'] : lang_hb('quanbu', 0);
		$orderby = $_GET['orderby'];
		$orderby_list = array('' => lang_hb('om', 0), 'near' => lang_he('juli', 0), 'hot' => lang_hb('zr', 0), 'new' => lang_hb('zx', 0), 'guanzhu' => lang_he('guanzhu', 0), 'starttime' => lang_he('starttime', 0));
		if (!$navtitle) {
			$navtitle = $orderby_list[$orderby] == lang_hb('om', 0) ? lang_hb('quanbu', 0) . lang_he('huodong', 0) : $orderby_list[$orderby];
		}
		$subcat = $cat_tree;
		if ($pid == 0) {
			$subcats = $cat_tree_init[$hyid]['child'];
		}
		$get_tag = array();
		foreach ($_GET as $index => $item) {
			if ($index != 'tag') {
				$get_tag[$index] = $item;
			}
		}
		$query = http_build_query($get_tag);
		foreach ($list_all as $index => $item) {
			if ($hyid == $item['id']) {
				$catinfo = $item;
				break;
			}
		}
		if ($hy['share_title']) {
			$anavtitle = $navtitle;
			$navtitle = $hy['share_title'];
		}
		if ($hy['share_desc']) {
			$description = $desc = $hy['share_desc'];
		}
		if (!$desc) {
			$desc = $navtitle;
		}
		if (!$hy['share_pic']) {
			$hy['share_pic'] = $hy['icon'];
		}
		break;
	case 'follow':
		if (submitcheck('formhash')) {
			$type = 'huodong';
			if ($old = C::t('#xigua_hb#xigua_hb_follow')->fetch_follow_by_favid_uid($hid, $_G['uid'], $type)) {
				C::t('#xigua_hb#xigua_hb_follow')->deletes(array($old['id']), $type);
				$he_huodong->incr($hid, 'favs', 0 - 1);
				$ret = '-1';
			} else {
				if ($id = C::t('#xigua_hb#xigua_hb_follow')->insert(array('favid' => $hid, 'favtype' => $type, 'uid' => $_G['uid'], 'crts' => TIMESTAMP, 'upts' => TIMESTAMP), true, false, true)) {
					$he_huodong->incr($hid, 'favs');
					$ret = $he_huodong->fetch($hid);
					$ret = $ret['favs'];
				}
			}
			if ($ret > 0) {
				hb_message($ret, 'success');
			} else {
				hb_message(lang_hb('qxsc', 0), 'success');
			}
		} else {
			$navtitle = lang_hb('wdsc', 0);
		}
		break;
	default:
		if (!checkmobile()) {
			include template('xigua_hb:index');
			exit(0);
		}
		if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_he/include/c_' . $ac . '.php'))) {
			include DISCUZ_ROOT . ('source/plugin/xigua_he/include/c_' . $ac . '.php');
		}
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_he/template/touch/' . $ac . '.php'))) {
	include template('xigua_he:' . $ac);
}
function he_check_bind()
{
	global $_G;
	global $he_config;
	global $SCRITPTNAME;
	if ($he_config['mustbind']) {
		$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
		if ($user['mobile']) {
			return true;
		}
		if ($_GET['inajax']) {
			hb_message(lang_hb('plzbind', 0), 'error', $SCRITPTNAME . '?id=xigua_hb&ac=myzl' . $GLOBALS['urlext']);
		} else {
			dheader('location: ' . $SCRITPTNAME . '?id=xigua_hb&ac=myzl&referer=' . urlencode(hb_currenturl()) . $GLOBALS['urlext']);
		}
		return false;
	}
}