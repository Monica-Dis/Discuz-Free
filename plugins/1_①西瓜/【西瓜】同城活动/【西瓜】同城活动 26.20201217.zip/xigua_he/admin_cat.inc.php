<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_he/function.php';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$lang['plugins_edit_vars_type_pics'] = lang_he('plugins_edit_vars_type_pics',0);
$page = max(1, intval($_GET['page']));
$lpp = 2;
$start_limit = ($page - 1) * $lpp;
$cat__id = $_GET['cat__id'];
if(is_numeric($cat__id)){
    $cat_indo = C::t('#xigua_he#xigua_he_cat')->fetch_by_catid($cat__id);
}elseif(strpos($cat__id, 'bm_')!==false){
    $cat_indo = C::t('#xigua_he#xigua_he_cat')->fetch_by_catid(str_replace('bm_', '', $cat__id));
    $cat_indo['name'] .= ' '.lang_he('bmbd',0);
}

if($_GET['subdo'] == 'vars') {

    if(!submitcheck('editsubmit')){
        $back = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat";

        echo '<link rel="stylesheet" href="source/plugin/xigua_he/static/admincp.css?1" />';
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&subdo=vars&cat__id=$cat__id", '', 'varsform');
        showtableheader($cat_indo['name'] . "<a href='$back' style='margin-left:20px'>". lang_hb('back',0)."</a>");
        showsubtitle(array('', 'display_order', 'plugins_vars_title', 'plugins_vars_type', lang_hb('comment_vars', 0), 'threadtype_unit', lang_hb('placehd', 0)));
        foreach (C::t('#xigua_he#xigua_he_var')->fetch_all_by_pluginid($cat__id) as $var) {
            $var['type'] = $lang['plugins_edit_vars_type_' . $var['type']] ? $lang['plugins_edit_vars_type_' . $var['type']] : lang_hb('plugins_edit_vars_type_' . $var['type'], 0);
            $var['title'] .= isset($lang[$var['title']]) ? '<br />' . $lang[$var['title']] : '';
            showtablerow('', array('class="td25"', 'class="td28"'), array(
                "<input class=\"checkbox\" type=\"checkbox\" name=\"delete[]\" value=\"$var[pluginvarid]\">",
                "<input type=\"text\" class=\"txt\" size=\"2\" name=\"displayordernew[$var[pluginvarid]]\" value=\"$var[displayorder]\">",
                $var['title'],
                $var['type'],
                nl2br($var['extra']),
                $var['unitnew'],
                $var['placehd'],
                "<a href=\"" . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&subdo=vars_profile&cat__id=$cat__id&pluginvarid=$var[pluginvarid]\" class=\"act\">$lang[detail]</a>"
            ));
        }
        showtablerow('', array('class="td25"', 'class="td28"'), array(
            cplang('add_new'),
            '<input type="text" class="txt" size="2" name="newdisplayorder" value="0">',
            '<input type="text" class="txt" size="15" name="newtitle">',
            '<select name="newtype">
				<option value="number">' . cplang('plugins_edit_vars_type_number') . '</option>
				<option value="text" selected>' . cplang('plugins_edit_vars_type_text') . '</option>
				<option value="textarea">' . cplang('plugins_edit_vars_type_textarea') . '</option>
				<option value="select">' . cplang('plugins_edit_vars_type_select') . '</option>
				<option value="date">' . cplang('plugins_edit_vars_type_date') . '</option>
				<option value="datetime">' . cplang('plugins_edit_vars_type_datetime') . '</option>
				<option value="selects">' . cplang('plugins_edit_vars_type_selects') . '</option>
				<option value="pics">' . lang_he('pics', 0) . '</option>
			</seletc>',
            ''
        ));
        showsubmit('editsubmit', 'submit', 'del');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
        
    }else{
        if($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_he#xigua_he_var')->delete($delete);
        }

        if(is_array($_GET['displayordernew'])) {
            foreach($_GET['displayordernew'] as $id => $displayorder) {
                C::t('#xigua_he#xigua_he_var')->update($id, array('displayorder' => intval($displayorder)));
            }
        }

        $newtitle = trim($_GET['newtitle']);
        if($newtitle) {
            $newtype = $_GET['newtype'];
            if(!in_array($newtype, array('number', 'text', 'radio', 'textarea', 'select', 'date', 'datetime', 'area', 'selects', 'pics'))){
                $newtype = 'text';
            }
            $data = array(
                'pluginid' => $cat__id,
                'displayorder' => intval($_GET['newdisplayorder']),
                'title' => $newtitle,
                'type' => $newtype,
            );
            C::t('#xigua_he#xigua_he_var')->insert($data);
        }
        cpmsg(lang_hb('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&subdo=vars&cat__id=$cat__id", 'succeed');
    }
    
}else if($_GET['subdo'] == 'vars_profile') {

    $pluginvarid = intval($_GET['pluginvarid']);
    $pluginvar = C::t('#xigua_he#xigua_he_var')->fetch($pluginvarid);

    if(!submitcheck('varsubmit')) {
        $typeselect = '<select name="typenew" onchange="if(this.value.indexOf(\'area\') == -1) $(\'extra\').style.display=\'\'; else $(\'extra\').style.display=\'none\';">';
        foreach(array('number', 'text', 'radio', 'textarea', 'select', 'date', 'datetime', 'selects', 'pics') as $type) {
            $typeselect .= '<option value="'.$type.'" '.($pluginvar['type'] == $type ? 'selected' : '').'>'.($lang['plugins_edit_vars_type_'.$type] ? $lang['plugins_edit_vars_type_'.$type] : lang_hb('plugins_edit_vars_type_'.$type, 0)).'</option>';
        }
        $typeselect .= '</select>';

        echo '<link rel="stylesheet" href="source/plugin/xigua_he/static/admincp.css?1" />';
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&subdo=vars_profile&cat__id=$cat__id&pluginvarid=$pluginvarid");
        showtableheader(); /*Dism_taobao-com*/
        showtitle($cat_indo['name'].' - '.$pluginvar['title']);
        showsetting(lang_hb('setting', 0), 'titlenew', $pluginvar['title'], 'text');
        showsetting('plugins_edit_vars_type', '', '', $typeselect);
        showtagheader('tbody', 'extra', $pluginvar['type'] != 'area');
        showsetting(lang_hb('comment_vars', 0), 'extranew',  $pluginvar['extra'], 'textarea',0,'',lang_hb('comment_vars_comment', 0));
        showtagfooter('tbody');
        showsetting('threadtype_unit', 'unitnew', $pluginvar['unitnew'], 'text');
        showsetting(lang_hb('placehd', 0), 'placehd', $pluginvar['placehd'], 'text',0,'',lang_he('comment_pic_comment', 0) );
        showsetting('required', 'required', $pluginvar['required'], 'radio');
        showsetting('unchangeable', 'unchangeable', $pluginvar['unchangeable'], 'radio');
        showsetting('threadtype_infotypes_formsearch', 'formsearch', $pluginvar['formsearch'], 'radio');
        showsubmit('varsubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/

    } else {
        $titlenew	= cutstr(trim($_GET['titlenew']), 25);
        $descriptionnew	= cutstr(trim($_GET['descriptionnew']), 255);
        $extranew	= trim($_GET['extranew']);
        $unitnew	= trim($_GET['unitnew']);
        $placehd	= trim($_GET['placehd']);

        if(!$titlenew) {
            cpmsg('plugins_edit_var_title_invalid', '', 'error');
        }

        $newtype = $_GET['typenew'];
        if(!in_array($newtype, array('number', 'text', 'radio', 'textarea', 'select', 'date', 'datetime', 'area', 'selects', 'pics'))){
            $newtype = 'text';
        }
        C::t('#xigua_he#xigua_he_var')->update_by_pluginvarid($cat__id, $pluginvarid, array(
            'title'       => $titlenew,
            'description' => $descriptionnew,
            'type'        => $newtype,
            'extra'       => $extranew,
            'unitnew'     => $unitnew,
            'placehd'     => $placehd,
            'required'    =>  intval($_GET['required']),
            'unchangeable'=>  intval($_GET['unchangeable']),
            'formsearch'  =>  intval($_GET['formsearch']),
        ));

        cpmsg(lang_hb('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&subdo=vars&cat__id=$cat__id", 'succeed');
    }
}else{

if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
    $ret = C::t('#xigua_he#xigua_he_cat')->do_delete(intval($_GET['catid']));
    if($ret){
        cpmsg(
            lang_hb('delcat_succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&page=$page",
            'succeed'
        );
    }else{
        cpmsg(
            lang_hb('delcat_error', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&page=$page",
            'error'
        );
    }
}
if(submitcheck('dosubmit')){
    if($new = $_GET['n']){
        $newrow = array();
        foreach ($new['name'] as $k => $v) {
            if(is_array($v)){
                foreach ($v as $kk => $string) {
                    $newrow[] = array(
                        'pid'  => $k,
                        'name' => $string,
                        'o'    => $new['o'][$k][$kk],
                        'isshow'    => $new['isshow'][$k][$kk],
                        'ts'   => TIMESTAMP,
                        'fid'  => trim($new['fid'][$k][$kk]),
                    );
                }
            } else {
                $newrow[] = array(
                    'pid' => 0,
                    'name' => $v,
                    'o'  => $new['o'][$k],
                    'isshow'  => $new['isshow'][$k],
                    'ts'   => TIMESTAMP,
                    'fid'  => trim($new['fid'][$k]),
                );
            }
        }
        foreach ($newrow as $value) {
            C::t('#xigua_he#xigua_he_cat')->insert($value);
        }
    }

    if($_FILES['icon'] || $_FILES['adimage'] || $_FILES['share_pic']){
        $icons = hb_uploads($_FILES['icon']);
        $adimage = hb_uploads($_FILES['adimage']);
        $share_pic = hb_uploads($_FILES['share_pic']);
    }
    if($_FILES['in_ad']){
        $in_ad = hb_uploads($_FILES['in_ad']);
    }

    if($r = $_GET['r']){
        foreach ($r['name'] as $cid => $name) {
            $data = array();

            $data['name']   = $name;
            $data['o']      = $r['o'][$cid];
            $data['isshow'] = $r['isshow'][$cid];
            $data['tpl']    = $r['tpl'][$cid];
            $data['fid']    = $r['fid'][$cid];
            $data['adlink'] = $r['adlink'][$cid];
            $data['in_adlnk'] = $r['in_adlnk'][$cid];
            $data['price']  = round($r['price'][$cid], 2);
            $data['apprice']  = round($r['apprice'][$cid], 2);
            $data['endtime'] = $r['endtime'][$cid];
            $data['telpri'] = $r['telpri'][$cid];
            $data['zdprice'] = $r['zdprice'][$cid];
            $data['cat_link'] = $r['cat_link'][$cid];
            $data['tag']    = trim($r['tag'][$cid]);
            $data['multiprice']    = trim($r['multiprice'][$cid]);
            $data['placehoder']    = trim($r['placehoder'][$cid]);
            $data['jiaobiao']    = trim($r['jiaobiao'][$cid]);


            $data['share_title']    = trim($r['share_title'][$cid]);
            $data['share_desc']    = trim($r['share_desc'][$cid]);


            if($_FILES['adimage']['error'][$cid] === UPLOAD_ERR_OK){
                $data['adimage']= ($adimage[$cid]['errno'] == 0 ? $adimage[$cid]['error'] : '');
            }
            if($_FILES['share_pic']['error'][$cid] === UPLOAD_ERR_OK){
                $data['share_pic']= ($share_pic[$cid]['errno'] == 0 ? $share_pic[$cid]['error'] : '');
            }
            if($_FILES['in_ad']['error'][$cid] === UPLOAD_ERR_OK){
                $data['in_ad']= ($in_ad[$cid]['errno'] == 0 ? $in_ad[$cid]['error'] : '');
            }
            if($_FILES['icon']['error'][$cid] === UPLOAD_ERR_OK) {
                $data['icon'] = ($icons[$cid]['errno'] == 0 ? $icons[$cid]['error'] : '');
            }

            C::t('#xigua_he#xigua_he_cat')->update($cid, $data);
        }
    }
    if($delimg = $_GET['delimg']){
        foreach ($delimg as $catid_ => $fields_) {
            $data_ = array();
            if($fields_['icon'] == 1){
                $data_['icon'] = '';
            }
            if($fields_['adimage'] == 1){
                $data_['adimage'] = '';
            }
            if($fields_['share_pic'] == 1){
                $data_['share_pic'] = '';
            }
            if($fields_['in_ad'] == 1){
                $data_['in_ad'] = '';
            }
            if($data_){
                C::t('#xigua_he#xigua_he_cat')->update(intval($catid_), $data_);
            }
        }
    }
    cpmsg(
        lang_hb('succeed', 0),
        "action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&page=$page",
        'succeed'
    );
}

$listinfo = C::t('#xigua_he#xigua_he_cat')->fetch_all_by_page($start_limit, $lpp);
C::t('#xigua_he#xigua_he_cat')->init($listinfo);
$list = C::t('#xigua_he#xigua_he_cat')->get_tree_array(0);

$totalcount = C::t('#xigua_he#xigua_he_cat')->count_by_page();
$multipage = multi(
    $totalcount, $lpp, $page,
    ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&page=$page"
);

echo '<link rel="stylesheet" href="source/plugin/xigua_he/static/admincp.css?1" />';
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&page=$page", 'enctype');
showtips(sprintf(lang_hb('category_tip', 0), $_G['siteurl'] . "$SCRITPTNAME?id=xigua_he"));

$alink = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&secid=-1&catid";
?>
<link rel="stylesheet" href="source/plugin/xigua_he/static/admincp.css?1" />
<div style="height:30px;line-height:30px;padding-left:25px">
    <a href="javascript:;" onclick="show_all()"><?php echo cplang('show_all')?></a> | <a href="javascript:;" onclick="hide_all()"><?php echo cplang('hide_all')?></a>
</div>
<table class="tb tb2 ">
   <tbody>
    <tr class="header">
     <th>&nbsp;</th>
     <th><?php lang_hb('ID')?></th>
     <th><?php lang_hb('order')?></th>
     <th><?php lang_hb('cat_name')?><br><?php lang_hb('cat_icon')?></th>
    <th><?php lang_he('price')?></th>
    <th><?php lang_hb('mb')?></th>
     <th><?php lang_hb('exit')?></th>
<th><?php lang_hb('cat_link')?></th>
    </tr>
   </tbody>
<?php foreach ($list as $v) { ?>
   <tbody>
    <tr class="hover">
     <td class="td25" onclick="toggle_group('group_<?php echo $v['id']?>', $('a_group_<?php echo $v['id']?>'))"><a href="javascript:;" id="a_group_<?php echo $v['id']?>">[-]</a></td>
     <td class="td25"><?php echo $v['id']?></td>
     <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $v['id']?>]" value="<?php echo $v['o']?>" /></td>
     <td>
       <div class="parentboard"><input type="text" name="r[name][<?php echo $v['id']?>]" value="<?php echo $v['name']?>" class="txt" /></div>
        <div><?php lang_hb('cat_icon')?> :<br>
         <input class="short" name="icon[<?php echo $v['id']?>]" type="file" />
<?php if($v['icon']){?>
 <span class="sp">
     <img class="imgi" src="<?php echo $v['icon']?>" onmouseover="$('icon<?php echo $v['id']?>').style.display='block'" onmouseout="$('icon<?php echo $v['id']?>').style.display='none'" />
     <img id="icon<?php echo $v['id']?>" src="<?php echo $v['icon']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][icon]" value="1" /><?php lang_hb('delshort')?></label>
 </span>
<?php }?></div>
     </td>
    <td>
        <div><div class="intit"><?php lang_he('price')?>:</div> <input class="txt mini" type="text" name="r[price][<?php echo $v['id']?>]" value="<?php echo $v['price'] ?>"></div>
        <div><div class="intit"><?php lang_he('app_price')?>:</div> <input class="txt mini" type="text" name="r[apprice][<?php echo $v['id']?>]" value="<?php echo $v['apprice'] ?>"></div>

    </td>
        <td>
            <div>
                <div class="intit"><?php lang_hb('lbfxbt')?> : </div>
                <div><input type="text" name="r[share_title][<?php echo $v['id']?>]" value="<?php echo $v['share_title']?>" class="txt" /></div>
                <div class="intit"><?php lang_hb('lbfxms')?> :</div>
                <div><input type="text" name="r[share_desc][<?php echo $v['id']?>]" value="<?php echo $v['share_desc']?>" class="txt" /></div>

                <div class="intit"><?php lang_hb('lbfxtp')?> :</div>
                <div>
                    <input class="short"  name="share_pic[<?php echo $v['id']?>]" type="file" /><br>
                    <?php if($v['share_pic']){?>
                        <span class="sp">
    <img class="imgi" src="<?php echo $v['share_pic']?>" onmouseover="$('sharep<?php echo $v['id']?>').style.display='block'" onmouseout="$('sharep<?php echo $v['id']?>').style.display='none'"  />
    <img id="sharep<?php echo $v['id']?>" src="<?php echo $v['share_pic']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][share_pic]" value="1" /><?php lang_hb('delshort')?></label>
</span>
                    <?php }?>
                </div>
            </div>
        </td>
     <td class="btna">
         <a style="background:#4caf50" href="<?php echo $alink."={$v['id']}" ?>"><?php lang_he('fabu0')?></a>
         <a href="<?php echo ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&catid={$v['id']}" ?>"><?php lang_he('fabuguanli')?></a>
         <a style="background:#2366a8"  href="<?php echo ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&subdo=vars&cat__id=bm_{$v['id']}" ?>"><?php lang_he('bmbd')?></a>
         <a style="background:#ccc;color:#666"  href="javascript:;" onclick="return _delid(<?php echo $v['id']?>,'<?php echo str_replace('&#039;', '', $v['name'])?>') "><?php lang_hb('del')?></a>
     </td>

        <td>
            <p style="margin-top:5px">
                <?php lang_hb('cat_link')?> :
                <input type="text" class="txt" style="width:154px" name="r[cat_link][<?php echo $v['id']?>]" placeholder="http://" value="<?php echo $v['cat_link'] ? $v['cat_link'] : ''; ?>" />
            </p>
        </td>
    </tr>
   </tbody>
    <tbody id="group_<?php echo $v['id']?>">
    <?php foreach ($v['child'] as $c) { ?>
        <tr class="hover">
            <td class="td25"></td>
            <td class="td25"><?php echo $c['id']?></td>
            <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $c['id']?>]" value="<?php echo $c['o']?>" /></td>
            <td>
                <div class="board">
                <input type="text" name="r[name][<?php echo $c['id']?>]" value="<?php echo $c['name']?>" class="txt" />
                </div>
            </td>
            <td>

            </td>

            <td>

                <div>
                    <div class="intit"><?php lang_hb('lbfxbt')?> : </div>
                    <div><input type="text" name="r[share_title][<?php echo $c['id']?>]" value="<?php echo $c['share_title']?>" class="txt" /></div>
                    <div class="intit"><?php lang_hb('lbfxms')?> :</div>
                    <div><input type="text" name="r[share_desc][<?php echo $c['id']?>]" value="<?php echo $c['share_desc']?>" class="txt" /></div>

                    <div class="intit"><?php lang_hb('lbfxtp')?> :</div>
                    <div>
                        <input class="short"  name="share_pic[<?php echo $c['id']?>]" type="file" /><br>
                        <?php if($c['share_pic']){?>
                            <span class="sp">
    <img class="imgi" src="<?php echo $c['share_pic']?>" onmouseover="$('sharep<?php echo $c['id']?>').style.display='block'" onmouseout="$('sharep<?php echo $c['id']?>').style.display='none'"  />
    <img id="sharep<?php echo $c['id']?>" src="<?php echo $c['share_pic']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $c['id']?>][share_pic]" value="1" /><?php lang_hb('delshort')?></label>
</span>
                        <?php }?>
                    </div>
                </div>

            </td>

            <td class="btna">
                <a style="background:#4caf50" href="<?php echo $alink."={$c['id']}" ?>"><?php lang_he('fabu0')?></a>
                <a href="<?php echo ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&catid={$c['id']}" ?>"><?php lang_he('fabuguanli')?></a>
                <a style="background:#2366a8"  href="<?php echo ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&subdo=vars&cat__id=bm_{$c['id']}" ?>"><?php lang_he('bmbd')?></a>
                <a style="background:#ccc;color:#666" href="javascript:;" onclick="return _delid(<?php echo $c['id']?>, '<?php echo str_replace('&#039;', '', $c['name'])?>') "><?php lang_hb('del')?></a>
            </td>

            <td>
            </td>
        </tr>
<?php
    }
?>
    </tbody>


   <tbody>
    <tr>
     <td></td>
     <td colspan="4">
      <div class="lastboard">
       <a href="javascript:;" onclick="addrow(this, 1, <?php echo $v['id']?>)" class="addtr"><?php lang_hb('ad_child_cat')?></a>
      </div></td>
     <td>&nbsp;</td>
    </tr>
   </tbody>
<?php }?>

   <tbody>
    <tr>
     <td>&nbsp;</td>
     <td colspan="99"><div>
         <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hb('ad_new_cat')?></a>
      </div></td>
    </tr>
    <?php
    if($multipage){
        showtablerow('', 'colspan="99"', $multipage);
    }
        showsubmit('dosubmit', 'submit', 'td');
    ?>
   </tbody>
  </table>
</form>
<script>
var rowtypedata = [
[
    [2, ''],
    [1,'<input type="text" class="txt" name="n[o][]" value="0" />', 'td25'],
    [5,'<div><input name="n[name][]" value="<?php lang_hb('new_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
],
[
    [2, ''],
    [1,'<input type="text" class="txt" name="n[o][{1}][]" value="0" />', 'td25'],
    [5,'<div class="board"><input name="n[name][{1}][]" value="<?php lang_hb('child_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
]
];
function _delid(id, name){
    if(confirm('<?php lang_hb('del_confirm')?>' + name + '?')){
        window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat&page=$page&del=1&formhash=".FORMHASH.'&catid='?>"+id;
    }
}
</script>
<?php } ?>