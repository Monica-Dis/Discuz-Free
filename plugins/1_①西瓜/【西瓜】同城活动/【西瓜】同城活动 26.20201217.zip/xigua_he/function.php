<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2018/9/24
 * Time: 14:35
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function lang_he($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_he', $lang);
    }else{
        return lang('plugin/xigua_he', $lang);
    }
}

function _he_current_location($lat, $lng){
    global $he_config;
    $url = "http://apis.map.qq.com/ws/geocoder/v1/?location=$lat,$lng&coord_type=5&get_poi=1&key=".$he_config['skey'];
    $ret = hb_curl($url);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        $rt = array();
        $rt[$ret['result']['address']] = array(
            'address'           => str_replace(array($ret['result']['address_component']['province'], $ret['result']['address_component']['city']), '', $ret['result']['address']),
            'address_component' => array(
                'province' => $ret['result']['address_component']['province'],
                'city'     => $ret['result']['address_component']['city'],
                'district' => $ret['result']['address_component']['district'],
                'street'   => $ret['result']['address_component']['street'],
                'street_number'=>$ret['result']['address_component']['street_number'],
            ),
            'location'          => $ret['result']['location'],
            'category'          => diconv(lang_he('default', 0), CHARSET, 'utf-8'),
        );
        foreach ($ret['result']['pois'] as $index => $pois) {
            $rt[$pois['address']] = array(
                'address'           => str_replace(array($pois['ad_info']['province'], $pois['ad_info']['city']), '', $pois['address']),
                'address_component' => array(
                    'province' => $pois['ad_info']['province'],
                    'city'     => $pois['ad_info']['city'],
                    'district' => $pois['ad_info']['district'],
                    'street'   => '',
                    'street_number'=> '',
                ),
                'location'          => $pois['location'],
                'category'          => $pois['category'],
            );
        }
        $rt = array_values($rt);
        return  _he_multi_diconv($rt, 'utf-8', 'utf-8');
    }else{
        return _he_multi_diconv($ret['message'], 'utf-8', CHARSET);
    }
}
function _he_multi_diconv($string, $in_charset, $out_charset){
    if (is_array($string)) {
        foreach ($string as $key => $val) {
            $string[ $key ] = _he_multi_diconv($val, $in_charset, $out_charset);
        }
    } else {
        $string = diconv($string, $in_charset, $out_charset);
    }
    return $string;
}
function he_postx($lang, $vars){
    global $adminids;
    if($adminids){
        $adminids = array_slice($adminids,0,10);
        foreach ($adminids as $adminid) {
            notification_add($adminid,'system', $lang, $vars, 1);
        }
    }
}

function hepub_callback($param){
    global $_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];

    $hid = intval($data['id']);

    C::t('#xigua_he#xigua_he_huodong')->update($hid, array('status' => 2));

    global $SCRITPTNAME,$adminids;
    if($adminids){
        $_lang = lang_he('new_in',0);
        $_vars=array('url' => "{$_G['siteurl']}$SCRITPTNAME?id=xigua_he&ac=view&hid=$hid".$urlext, 'id'=>$hid);
        foreach ($adminids as $adminid) {
            notification_add($adminid,'system', $_lang, $_vars, 1);
        }
    }
    return true;
}


function he_get_my_shs(){
    global $_G,$he_config;
    if($_G['cache']['plugin']['xigua_hs']){
        $shs = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('uid='.$_G['uid']), 0, 99, 'shid DESC', 'shid,name');
    }
    return $shs;
}

function he_myhe(){
    global $_G, $he_config;


}

function he_parse_config(){
    global $he_config;
    $return = array();
    $conf = explode("\n", trim($he_config['bmzd']));
    foreach ($conf as $item) {
        list($key, $name) = explode('=', trim($item));
        $key = trim($key);
        $return[$key] = trim($name);
    }
    return $return;
}

function he_nl2br($txt){
    if(strpos($txt, '&lt;') !== false  && strpos($txt, '&gt;') !== false){
        $v['jieshao'] = htmlspecialchars_decode($txt);
        $v['jieshao'] = preg_replace(array("/<script(.*?)<\/script>/is",'/on(mousewheel|mouseover|click|load|onload|submit|focus|blur)="[^"]*"/i'), array('',''), $txt);
    }
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}

function he_do_get_config(){
    if(!he_set_config()){
        return false;
    }
    global $_G, $he_config, $svicerange, $aclist, $aclist_login, $ac, $do,$isself,$page,$lpp,$start_limit,$hid,$he_cat,$he_huodong,$pzfield, $he_order,$bmid;

    $svicerange = array();
    foreach (explode("\n", trim($he_config['svicerange'])) as $index => $item) {
        $svicerange[] = trim($item);
    }
    $aclist = array('index','wode','add','chosecat', 'getloc', 'cate','view', 'myhe', 'myhe_li','com', 'next','pay', 'order', 'order_li', 'order_profile', 'bgm', 'bgm_li', 'he_li','baoming','baoming_li', 'shop', 'incr','cat','follow','none');
    $aclist_login = array('wode','add','chosecat','com', 'next', 'pay', 'order', 'order_li', 'order_profile', 'bgm', 'bgm_li');
    $ac = $_GET['ac'];
    $do = $_GET['do'];
    if (!in_array($ac, $aclist)) {
        $ac = 'index';
    }
    $isself = in_array($ac, $aclist_login) || (strpos($ac, 'my')!==false && !$_G['uid']);
    if ($isself && !$_G['uid']) { hb_jump_login(); }
    $_GET = dhtmlspecialchars($_GET);
    $page = max(1, intval($_GET['page']));
    $lpp   = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
    $start_limit = ($page - 1) * $lpp;
    $hid = intval($_GET['hid']);
    $bmid = intval($_GET['bmid']);
    $he_cat = C::t('#xigua_he#xigua_he_cat');
    $he_huodong = C::t('#xigua_he#xigua_he_huodong');
    $he_order = C::t('#xigua_he#xigua_he_order');
    $pzfield = array('pzname', 'pzprice', 'pzhkprice', 'pznum', 'pzshenhe', 'pzmin', 'pzmax', 'pzhhr1', 'pzhhr2');
}

function he_vars($catid){
    $vars = C::t('#xigua_he#xigua_he_var')->fetch_all_by_pluginid('bm_'.$catid);
    return $vars;
}

function he_baoming_callback($param){
    global $SCRITPTNAME, $_G,$urlext;
    $info = $param['info'];
    $datas = $info['data'];

    foreach ($datas as $index => $data) {
        $bmid = intval($data['id']);
        $pzinfo = unserialize($data['pzinfo']);
        $sta = $pzinfo['pzshenhe'] ? 5: 2;
        C::t('#xigua_he#xigua_he_order')->update($bmid, array('pay_ts' => TIMESTAMP,'status' => $sta));
        C::t('#xigua_he#xigua_he_huodong')->incr($data['hid'], 'joins');
        $hid = $data['hid'];
        $shid = $data['shid'];
    }
    if($data['status']==5){
        $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_he&ac=bgm&status=5&hid=$hid".$urlext;
        he_post_byshid(lang_he('new_need_shen_dd',0), array('url' => $url, 'id'=>$hid), $shid);
    }else{
        $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_he&ac=bgm&hid=$hid".$urlext;
        he_post_byshid(lang_he('new_in_dd',0), array('url' => $url, 'id'=>$hid), $shid);
    }
    return true;
}

function he_get_shids_by_uid(){
    global $_G;
    $shids = array();
    if(!$_G['uid'] || !$_G['cache']['plugin']['xigua_hs']){
        return $shids;
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array('0'), array_keys($shids1), array_keys($shids2));
    return $shids;
}

function he_doinit_status(){
    if(!he_set_config()){
        return false;
    }
    global $order_status;
    $order_status = array(
        1 => lang_he('os1',0),
        2 => lang_he('os2',0),
        3 => lang_he('os3',0),
        4 => lang_he('os4',0),
        7 => lang_he('os7',0),
        5 => lang_he('os5',0),
        6 => lang_he('os6',0),
    );
}

function he_qrcode_make($bmid, $code){
    global $_G, $config,$SCRITPTNAME,$urlext;

    $repath = './source/plugin/xigua_he/cache/';
    $qrfile = $repath . $code . $bmid.'.png';
    $abs_qrfile = DISCUZ_ROOT . $qrfile;
    $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_he&ac=order_profile&manage=1&bmid=$bmid&code=$code".$urlext;

    if (!is_file($abs_qrfile)) {
        @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
        if(class_exists('QRcode')){
            QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
        }
    }
    return $qrfile;
}

function he_set_config(){
    return true;
}

function he_message($msg, $type,$url = '',$extjs = ''){
    if($_SERVER['REQUEST_METHOD'] == 'POST') {
        hb_message($msg, $type, $url, $extjs);
    }else{
        return $msg;
    }
    return false;
}

function he_index(){
    global $he_config, $jing_count, $jing_list, $do,$navtitle,$desc,$midnavslider,$topnavslider,$cat_list,$he_cat,$indexlist;
    $navtitle = $he_config['indextitle'];
    $desc = $he_config['desc'];
    $midnavslider = $topnavslider = array();
    $topnavslider = hb_parse_set($he_config['loopbanner']);
    $cat_list = $he_cat->list_by_pid(0, TRUE);

    $indexlist = C::t('#xigua_he#xigua_he_index')->list_by_pid(0, TRUE);
    $jing_list = array_values($indexlist);
    if($jing_list){
        $jing_count = range(0, ceil(count($jing_list)/10)-1);
    }
}

function he_wode(){
    global $_G,$iszbf,$SCRITPTNAME,$custom_side,$shids,$he_order,$he_huodong,$totalin,$totalhd,$needs,$uid,$myjoins,$myfavs,$shfavs,$totalin,$sh;
    $iszbf = $_GET['view'] == 'zbf';
    if($iszbf){
        $custom_side = array(
            "$SCRITPTNAME?id=xigua_hb&ac=myset",
            lang_hb('shzhi',0)
        );
        $shids = he_get_shids_by_uid();
        if($shids){
            $totalin = $he_order->fetch_sum_by_where('pay_money', "shid in(".implode(',',$shids).") AND status in(2,5,6)");
            $totalhd = $he_huodong->fetch_count_by_where( "shid in(".implode(',',$shids).")");
            $needs = $he_order->fetch_count_by_where("shid in(".implode(',',$shids).") AND status=5");
        }
    }else{
        $custom_side = array(
            "$SCRITPTNAME?id=xigua_hb&ac=myset",
            lang_hb('shzhi',0)
        );
        $uid = intval($_G['uid']);
        $myjoins = $he_order->fetch_count_by_where(array("uid=$uid"));
        $myfavs =  C::t('#xigua_hb#xigua_hb_follow')->fetch_count_by_page(array("uid=$uid AND favtype='huodong'"));
        $shfavs =  C::t('#xigua_hs#xigua_hs_follow')->fetch_count_by_page(array("uid=$uid"));
    }
    $totalin = floatval($totalin);
    $sh = he_get_my_shs();
}

function he_view(){
    global $hd_hasjoin,$errmsg,$cat_list,$he_cat,$SCRITPTNAME,$_G,$hid,$he_huodong,$v,$navtitle,$desc,$sh,$shid,$showshen,$he_order,$hasshen,$veris2,$bao,$joinlist,$followed,$hdcount,$kefulink,$back_to,$faved, $uid,$urlext;

    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid'], 0);
    $sh['jieshao'] = cutstr(strip_tags($sh['jieshao']), 300);
    $shid = intval($sh['shid']);

    if(!$v['album']){
        $v['album'][0] = $v['fengmian'];
    }

    $showshen = 0;
    foreach ($v['pzshenhe'] as $index => $item) {
        if($item==1){
            $showshen =1;
            break;
        }
    }
    $hasshen = 0;
    if($showshen){
        $hasshen = $he_order->fetch_count_by_where('hid='.$hid.' AND status in(2,5,6)');
        if($hasshen> $v['joins']){
            $hasshen = $v['joins'];
        }
    }

    if($_G['cache']['plugin']['xigua_hr']){
        $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris_bysh(array($v['shid']));
        $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($v['uid']));
    }
    if($v['joins']){
        $joinlist = $he_order->fetch_all_by_where('hid='.$hid.' AND status in(2,5,6)', 0, 20, 'id desc', 'uid,num,numtotal', 1);
    }
    if($_G['uid']){
        $followed = C::t('#xigua_hs#xigua_hs_follow')->fetch_follow_by_shid_uid($shid, $_G['uid']);
    }
    $hdcount = $he_huodong->fetch_count_by_where(array('status=2 AND shid='.$shid));
    $kefulink = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid={$sh['uid']}";
    $back_to = "$SCRITPTNAME?id=xigua_he";
    if($_SERVER['HTTP_REFERER']){
        $back_to = "javascript:window.history.go(-1);";
    }
    if($_G['uid']){
        $faved = C::t('#xigua_hb#xigua_hb_follow')->fetch_follow_by_favid_uid($hid, $_G['uid'], 'huodong');
    }
    $cat_list = $he_cat->list_by_pid(0, TRUE);

    if($v['bstarttime']>TIMESTAMP){
        $errmsg = lang_he('wks',0);
    }
    if($v['allnum']>0){
        $hd_hasjoin = $he_order->fetch_count_by_where('hid='.$hid.' AND status in(2,5,6)');
        if($hd_hasjoin>=$v['allnum']){
            $errmsg = lang_he('rsym',0);
        }
    }
    if($v['bhasend']){
        $errmsg = lang_he('bmyjs',0);
    }
    if($v['hasend']){
        $errmsg = lang_he('hdyjs',0);
    }
}

function he_shop(){
    global $urlext,$custom_side,$he_cat,$SCRITPTNAME,$_G,$hid,$he_huodong,$v,$navtitle,$desc,$sh,$shid,$showshen,$he_order,$hasshen,$veris2,$bao,$joinlist,$followed,$hdcount,$kefulink,$back_to,$faved, $uid;

    $shid = intval($_GET['shid']);
    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
    $hdcount = $he_huodong->fetch_count_by_where(array('status=2 AND shid='.$shid));
    $navtitle = $sh['name'].lang_he('dhdzy',0);
    $sh['jieshao'] = cutstr(strip_tags($sh['jieshao']), 500);
    if($_G['cache']['plugin']['xigua_hr']){
        $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris_bysh(array($shid));
        $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($sh['uid']));
    }
    if($_G['uid']){
        $followed = C::t('#xigua_hs#xigua_hs_follow')->fetch_follow_by_shid_uid($shid, $_G['uid']);
    }
    $custom_side = array(
        "$SCRITPTNAME?id=xigua_he".$urlext,
        lang_he('index', 0)
    );
}

function he_post_byshid($lang, $vars, $shid){
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE shid=%d', array(
        'xigua_hs_shanghu',
        $shid
    ),'uid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE shid=%d', array(
        'xigua_hs_yuan',
        $shid
    ),'uid');
    $shids = array_merge(array('0'), array_keys($shids1), array_keys($shids2));
    foreach ($shids as $sh_uid) {
        if($sh_uid>0){
            notification_add($sh_uid,'system', $lang, $vars, 1);
        }
    }
}