<?php exit('xigua_hb');?>
<!--{loop $list $v}-->
<!--{eval $sh = $v[sh];
$num = count($v[newbminfo]);
$ralall = $num * $v['pz_preprice'];
}-->
<div class="he_order_li mt10">
    <div class="he_shlink">
        <!--{if $v['shid']}-->
        <a class="sh_jump" data-id="{$v['shid']}"> <img class="confirm_shlogo" src="{$sh[logo]}"/>
            <span class="f13">{$sh[name]}</span> <i class="f13 iconfont icon-jinrujiantou"></i> </a>
        <!--{/if}-->
        <span class="y f12">{lang xigua_he:order_id}: {$v['order_id']}</span>
    </div>
    <div class="jump_he weui-cell weui-cell_access before_none after_none he_order_he" style="padding-top:10px;background:#f8f8f8" data-id="$v[hid]">
        <div class="weui-cell__hd z">
            <label class="weui-label " style="width:95px">
                <img style="width: 80px;height: 80px;" src="{echo $v['hdinfo']['fengmian'] ?$v['hdinfo']['fengmian'] : $v['hdinfo']['album'][0]}"/>
            </label>
        </div>
        <div class="weui-cell__bd ">
            <p class="f14 c3">{$v[hdinfo][title]}</p>
            <p class="f12 c9">{lang xigua_he:shijian}: {$v[hdinfo][start_u]}
                <!--{if $v[hdinfo][end_u]}-->
                <span>{lang xigua_he:z}</span>
                <span>{$v[hdinfo][end_u]}</span>
                <!--{else}-->
                <span>{lang xigua_he:ks}</span>
                <!--{/if}--></p>
            <!--{if $v[hdinfo][addr]}-->
            <p class="f12 c9">{lang xigua_he:dd}: {$v[hdinfo][city]}{$v[hdinfo][dist]}{$v[hdinfo][addr]}</p>
            <!--{/if}-->
            <p class="f12 c9">{lang xigua_he:xdsj}: {$v[crts_u]}</p>
            <!--{if $v[pay_ts]}-->
            <p class="f12 c9">{lang xigua_he:fksj}: {echo date('Y-m-d H:i:s', $v['pay_ts'])}</p>
            <!--{/if}-->
        </div>
    </div>
    <div class="weui-cell before_none">
        <div class="weui-cell__bd f12">
            <span>{$v[pzinfo][pzname]} <em class="main_color">&yen; {$v['pz_preprice']}</em> x {$num}</span>
            <span>{lang xigua_he:heji} : <em class="main_color">&yen; {$ralall}</em> </span>
        </div>
        <div class="weui-cell__ft">
            <span class="f12">{$order_status[$v[status]]} </span>
            <!--{if $v[jumpurl]}-->
            <a class="weui-btn weui-btn_mini mt0" href="{$v[jumpurl]}">{lang xigua_he:ljzf}</a>
            <!--{else}-->
            <a class="weui-btn weui-btn_mini mt0 hm_c_btn bgf8" href="$SCRITPTNAME?id=xigua_he&ac=order_profile&bmid=$v[id]">{lang xigua_he:ddxq}</a>
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{/loop}-->