<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $tuijian_hds $tuijian_hd}-->
<li class="index_recomlist" >
    <a class="jump_he" href="javascript:" data-id="{$tuijian_hd[id]}">
        <div class="listTop">
            <img src="{echo $tuijian_hd[fengmian] ? $tuijian_hd[fengmian]: $tuijian_hd[album][0]}">
        </div>
        <div class="listBottom">
            <div class="partyTitlt"><span><em class="jxuan">{lang xigua_he:jx}</em> {$tuijian_hd[title]}</span></div>
            <div class="partyDate">{echo substr($tuijian_hd[start_u], 5)} {lang xigua_he:ks}</div>
            <div class="partyAddress">
                <p><!--{if $tuijian_hd[pricerange]}-->&yen;{$tuijian_hd[pricerange]}<!--{else}-->{lang xigua_he:mf}<!--{/if}--></p>
            </div>
        </div>
    </a>
</li>
<!--{/loop}-->
