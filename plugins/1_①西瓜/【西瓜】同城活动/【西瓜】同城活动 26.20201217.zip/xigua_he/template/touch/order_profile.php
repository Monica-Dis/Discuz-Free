<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_he:header}-->
<link rel="stylesheet" href="source/plugin/xigua_he/static/order.css?{VERHASH}" />
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-cells border_none mt0">
        <div class="weui-cell weui-cell_access" onclick="$('#bminfo').toggle();">
            <div class="weui-cell__hd"><label class="weui-label f14">{lang xigua_he:bmrxx}</label></div>
            <div class="weui-cell__bd f14">{lang xigua_he:djck}</div>
            <div class="weui-cell__ft"></div>
        </div>
    </div>
    <div id="bminfo" style="display:none;">
<!--{loop $vs $_k $_v}-->
        <!--{eval $j++;}-->
        <div class="weui-cells__title">{lang xigua_he:di}{$j}{lang xigua_he:wei}</div>
        <div class="weui-cells" >
        <!--{loop $_v[bminfo] $__v}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label f14">{$__v[title]}</label></div>
            <div class="weui-cell__bd f14">
                <!--{if $__v[type]=='pics'}-->
                <div class="cl feed-preview-pic">
                    <!--{loop $__v[value] $_img}-->
                    <span class="imgloading">
                    <img  src="{$_img}" />
                </span>
                    <!--{/loop}--></div>
                <!--{else}-->
                {$__v[html]}
                <!--{/if}-->
            </div>
        </div>
        <!--{/loop}-->
        </div>
<!--{/loop}-->
    </div>

    <div class="he_order_li mt10">
        <div class="he_shlink">
            <!--{if $v['shid']}-->
            <a class="sh_jump" data-id="{$v['shid']}"> <img class="confirm_shlogo" src="{$sh[logo]}"/>
                <span class="f13">{$sh[name]}</span> <i class="f13 iconfont icon-jinrujiantou"></i> </a>
            <!--{/if}-->
        </div>
        <div class="jump_he weui-cell weui-cell_access before_none after_none he_order_he" data-id="$v[hid]">
            <div class="weui-cell__hd z">
                <label class="weui-label " style="width:95px">
                    <img style="width: 80px;height: 80px;" src="{echo $v['hdinfo']['fengmian'] ?$v['hdinfo']['fengmian'] : $v['hdinfo']['album'][0]}"/>
                </label>
            </div>
            <div class="weui-cell__bd ">
                <p class="f14 c3">{$v[hdinfo][title]}</p>
                <p class="f12 c9" id="shijian">{lang xigua_he:shijian}: {$v[hdinfo][start_u]}
                    <!--{if $v[hdinfo][end_u]}-->
                    <span>{lang xigua_he:z}</span>
                    <span>{$v[hdinfo][end_u]}</span>
                    <!--{else}-->
                    <span>{lang xigua_he:ks}</span>
                    <!--{/if}--></p><p class="f12 c9" id="didian">
                <!--{if $v[hdinfo][addr]}-->
                {lang xigua_he:dd}: {$v[hdinfo][city]}{$v[hdinfo][dist]}{$v[hdinfo][addr]}
                <!--{/if}--></p>
            </div>
        </div>
    </div>
    <div class="p_pzlist">
        <!--{loop $vs $_k $_v}-->
        <!--{eval $i++; $bmr = array_values($_v[bminfo]);}-->
        <div class="p_wrapper">
            <div class="p_content">
                <div class="p_title">
                    <span>{$i} {$_v[pzinfo][pzname]} &yen; {$_v[pz_preprice]}</span>
                    <span class="y">{$order_status[$_v[status]]}</span>
                </div>
                <div class="p_time">
                    <div>
                        <!--{loop $bmr $_bmr}-->
                        <!--{if $_bmr[type]!='pics'}-->
                        {$_bmr[title]}: {$_bmr[html]}
                        <!--{/if}-->
                        <!--{/loop}-->

                        <!--{if $_v[hxcrts]}--><p><!--{eval $hxuser = getuserbyuid($_v['hxuid']);}-->
                        {$hxuser['username']}{lang xigua_he:yiyu}{echo date('Y-m-d H:i:s', $_v[hxcrts]);}{lang xigua_he:wchd}</p>
                        <!--{/if}-->
                    </div>
                    <div class="button-sp-area tr">
<!--{if $_GET['code']}-->
    <!--{if in_array($_v[status], array(5,7))}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn bgf8 shbtn" data-id="{$_v[id]}">{lang xigua_he:sh}</a>
    <!--{/if}-->
    <!--{if $_GET['code'] && $_v[status]==2}-->
<a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn bgf8 ypbtn" id="c_{$_v['hxcode']}" data-tip="{$order_status[$_v[status]]}" data-hxcode="{$_v['hxcode']}" data-id="{$_v[id]}">{lang xigua_he:djyp}</a>
    <!--{/if}-->
<!--{else}-->
                        <!--{if $he_order->check_allow_refund($_v)}-->
                        <!--{if $_GET['manage']&&$he_config[sjqx]!=3}-->
                        <!--{else}-->
                        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn bgf8 tkbtn" data-id="$_v[id]">{lang xigua_he:qxbm}</a>
                        <!--{/if}-->
                        <!--{/if}-->
                        <!--{if $_v[status]==2}-->
                        <!--{if !$he_config[zjwc] || ($_GET['manage']&&$he_config[sjqx]!=3)}-->
                        <!--{else}-->
                        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn bgf8 complete" data-id="$_v[id]" data-tip="{echo $v[hdinfo][starttime]<=TIMESTAMP ? '{lang xigua_he:hdyksqr}': '{lang xigua_he:hdwksqr}'}">{lang xigua_he:wchd}</a>
                        <!--{/if}-->
                        <!--{/if}-->
<!--{/if}-->
                    </div>
                </div>
            </div>
            <div class="p_split-line"></div>
            <!--{if $_GET['manage']&&$he_config[sjqx]==2}-->
            <!--{else}-->
            <a class="p_tip main_color" data-cover="<!--{if $_v[status]!=2}-->1<!--{/if}-->" data-tip="{$order_status[$_v[status]]}" data-chushi="{lang xigua_he:csdzp}" data-src="$SCRITPTNAME?id=xigua_he&ac=com&do=showqr&bmid={$_v[id]}{$urlext}">
                {lang xigua_he:ckdzp}
            </a>
            <!--{/if}-->
        </div>
        <!--{/loop}-->
    </div>

    <!--{if $_G['cache']['plugin']['xigua_hk']}-->
    <!--{eval $card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G[uid]); }-->
    <!--{/if}-->
    <!--{eval
    $dingjin = 0;
    $datap = $v[pzinfo][pzprice];

    if($card && $v[pzinfo][pzhkprice]>0):
        $datap = $v[pzinfo][pzhkprice];
    endif;

    if($v[pzinfo][d_price]>0):
        $datap = $v[pzinfo][d_price];
        $dingjin = 1;
    endif;
    if($card && $v[pzinfo][hk_d_price]>0):
        $datap = $v[pzinfo][hk_d_price];
        $dingjin = 1;
    endif;

    }-->
    <div class="weui-cells before_none after_none" id="p_info">

        <div class="weui-cell before_none after_none">
            <div class="weui-cell__bd f14">{$v[pzinfo][pzname]}{lang xigua_he:danjia} : </div>
            <div class="weui-cell__ft f16"><span class="main_color">&yen; {$v[pzinfo][pzprice]}</span>
                <!--{if $v[pzinfo][pzhkprice]>0}-->
                <em class="hksp pr-1">{$_G['cache']['plugin']['xigua_hk']['cardname']}{lang xigua_he:jia} &yen;{echo floatval($v[pzinfo][pzhkprice])}</em>
                <!--{/if}-->
                <!--{if $dingjin}-->
                <em class="hksp pr-1 dj">{lang xigua_he:dj} &yen;{echo floatval($datap)}</em>
                <!--{/if}-->
            </div>
        </div>

        <div class="weui-cell before_none after_none pt0">
            <div class="weui-cell__bd f14">{lang xigua_he:shuliang} : </div>
            <div class="weui-cell__ft f16"> <em class="main_color">x {$v[numtotal]}</em> </div>
        </div>
        <div class="weui-cell before_none after_none pt0">
            <div class="weui-cell__bd f14">{lang xigua_he:sjzf} : </div>
            <div class="weui-cell__ft f16"> <em class="main_color">= &yen; {$pay_money}</em> </div>
        </div>
    </div>

    <div class="weui-cells before_none after_none" id="p_buyer">
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__bd f14">{lang xigua_he:gmyh} : </div>
            <div class="weui-cell__ft f14"> {$v['user'][username]}  (UID : $v[uid])
                <!--{if $_GET['manage']}-->
                <a href="plugin.php?id=xigua_hb&ac=chat&touid={$v[uid]}" class="weui-btn weui-btn_mini hm_c_btn bgf8 ">{lang xigua_hb:sixin}</a>
                <!--{/if}-->
            </div>
        </div>
        <div class="weui-cell before_none after_none pt0">
            <div class="weui-cell__bd f14">
                {lang xigua_he:lxfs} :
            </div>
            <div class="weui-cell__ft f14"> {$hbuser[realname]} {$mobile}
            </div>
        </div>
        <div class="weui-cell before_none after_none pt0">
            <div class="weui-cell__bd f14">{lang xigua_he:ddbh} : </div>
            <div class="weui-cell__ft f14"> $v[order_id] </div>
        </div>
        <div class="weui-cell before_none after_none pt0">
            <div class="weui-cell__bd f14">{lang xigua_he:xdsj} : </div>
            <div class="weui-cell__ft f14"> $v[crts_u] </div>
        </div>
        <!--{if $v[pay_ts]}-->
        <div class="weui-cell before_none after_none pt0">
            <div class="weui-cell__bd f14">{lang xigua_he:fksj} : </div>
            <div class="weui-cell__ft f14"> {echo date('Y-m-d H:i:s', $v['pay_ts'])}</div>
        </div>
        <!--{/if}-->
        <!--{if $v[refund_ts]}-->
        <div class="weui-cell before_none after_none pt0">
            <div class="weui-cell__bd f14">{lang xigua_he:tksj} : </div>
            <div class="weui-cell__ft f14"> {echo date('Y-m-d H:i:s', $v['refund_ts'])}</div>
        </div>
        <!--{/if}-->
    </div>

</div>

<!--{eval $he_tabbar=1;$tabbar=0;}-->
<!--{template xigua_he:footer}-->
<script>
    $(document).on('click','.tkbtn', function () {
        var that = $(this);
        $.confirm({
            title: '{lang xigua_he:qdqx}',
            text: '{lang xigua_he:bmfht}',
            onOK: function () {$.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_he&ac=com&do=tk&inajax=1',
                    data:{formhash:'{FORMHASH}', bmid : that.data('id')},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });
    });
    $(document).on('click','.complete', function () {
        var that = $(this);
        $.confirm({
            title: '{lang xigua_he:ts}',
            text: that.data('tip'),
            onOK: function () {$.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_he&ac=com&do=complete&inajax=1',
                    data:{formhash:'{FORMHASH}', bmid : that.data('id')},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });
    });
    $(document).on('click','.p_tip', function () {
        var that = $(this);
        var _id = that.data('id');
        if(that.data('src')){
            var extcov = '';
            if(that.data('cover')){
                extcov = '<div class="covdiv">'+that.data('tip')+'</div>';
            }
            $.alert("<div class='covtop'><img src='"+that.data('src')+"' />"+extcov+"</div>"+that.data('tip')+$('#shijian').prop("outerHTML")+$('#didian').prop("outerHTML"), that.data('chushi'),function() {
            });
            return false;
        }
    });

    $(document).on('click','.ypbtn', function () {
        var that = $(this);
        var bmid = that.data('id');
        var cod = that.data('hxcode');
        $.confirm({
            title: '{lang xigua_he:qryp}',
            text: that.data('tip')+$('#shijian').prop("outerHTML")+$('#didian').prop("outerHTML")+$('#p_buyer').prop("outerHTML")+$('#p_info').prop("outerHTML"),
            onOK: function () {

                $.showLoading();
                $.ajax({
                    type: "POST",
                    url: _APPNAME+'?id=xigua_he&ac=com&do=complete&inajax=1',
                    data:{formhash:FORMHASH, bmid:bmid, hxcode:cod},
                    dataType: "xml",
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });

            }
        });
    });
    <!--{if $_GET['code']}-->
    $('#c_{$_GET[code]}').trigger('click');
    <!--{/if}-->
</script>
<!--{template xigua_he:shbtn}-->