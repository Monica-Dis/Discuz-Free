<?php exit('xxxxx');?>
<style>
    .weui-search-bar__cancel-btn{font-size:16px}
    .search_bar_btn{margin-left: 10px;line-height: 28px;white-space: nowrap;display:none;font-size:16px}
    .weui-search-bar.weui-search-bar_focusing .search_bar_btn { display: block}
    div.weui-banner .weui-navbar__item:last-child{padding-right:15px}
</style>
<div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
    <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">

        <input name="id" value="xigua_he" type="hidden">
        <input name="ac" value="cat" type="hidden">
        <input type="hidden" name="st" value="$_GET[st]">
        <input type="hidden" name="idu" value="$_GET[idu]">

        <div class="weui-search-bar__box">
            <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{$sp_config[schtxt]}" required="required" name="keyword" value="$keyword">
            <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
        </div>
        <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
            <i class="weui-icon-search"></i>
            <span>{$sp_config[schtxt]}</span>
        </label>
    </form>
    <a href="javascript:" class="search_bar_btn main_color" id="dosearch">{lang xigua_he:search}</a>
    <a href="javascript:" class="weui-search-bar__cancel-btn" style="color:#999!important;" <!--{if $keyword}-->id="searchCancel"<!--{/if}-->>{lang xigua_he:qx}</a>
</div>
