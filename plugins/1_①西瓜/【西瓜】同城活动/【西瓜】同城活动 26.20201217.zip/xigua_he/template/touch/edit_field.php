<?php exit('xxxxxxx'); ?>
<div id="edit_field" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__modal bgf8">
        <div class="fixpopuper">
            <div class="weui-cells__title">{lang xigua_he:rsxs}</div>
            <div class="weui-cells ">
                <div class="weui-cell weui-cell_switch">
                    <div class="weui-cell__bd">{lang xigua_he:xsbmrs}</div>
                    <div class="weui-cell__ft">
                        <input class="weui-switch" type="checkbox" checked="checked" name="form[showbm]" value="1">
                    </div>
                </div>

            </div>

            <div class="weui-cells__title">{lang xigua_he:bmbd}</div>
            <div class="weui-cells weui-cells_checkbox" id="namebox">
                <!--{loop $old_data['bdfield'] $k $v}-->
                <label class="weui-cell" id="{$k}">
                    <div class="weui-cell__bd">{$bmfield[$k]}</div>
                    <div class="weui-cell__ft">
                        <span class="color-gray">{lang xigua_he:bitian}</span><input type="checkbox" class="weui-check" data-name="{$bmfield[$k]}" name="form[required][{$k}]" value="1" <!--{if $old_data['required'][$k]}-->checked="checked"<!--{/if}-->><i class="weui-icon-checked"></i>
                    </div>
                    <input type=hidden name="form[bdfield][{$k}]" value="1">
                </label>
                <!--{/loop}-->
            </div>

            <div class="weui-cells__title">{lang xigua_he:cybmx}</div>
            <div class="weui-cells ">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <div class="post-tags cl" id="bmx">
                            <!--{loop $bmfield $k $v}-->
                            <a class="weui-btn weui-btn_mini weui-btn_default $k <!--{if $old_data['bdfield'][$k]}-->tag-on<!--{/if}-->" data-id="$k">$v</a>
                            <!--{/loop}-->
                        </div>
                    </div>
                </div>
                <div class="weui-cell none">
                    <a href="javascript:;" id="add_bmx" class="weui-cell__bd tc main_color">+{lang xigua_he:xzbmx}</a>
                </div>
            </div>



            <div class="weui-cells__title">{lang xigua_he:bmsjsz}</div>
            <div class="weui-cells ">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_he:starttime}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input time_ctrl" name="form[bstarttime]" type="text" placeholder="{lang xigua_he:qxz}{lang xigua_he:bmkssj}" value="{echo $old_data ? $old_data[bstart_u] : '';}">
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_he:endtime}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input time_ctrl" name="form[bendtime]" type="text" placeholder="{lang xigua_he:qxz}{lang xigua_he:bmjzsj}" value="{echo $old_data ? $old_data[bend_u] : '';}">
                </div>
            </div>
            </div>

            <div class="fix-bottom mt10" style="position:relative">
                <a class="mt0 weui-btn weui-btn_default" onclick='return edit_finish();' href="javascript:;">{lang xigua_he:wcbj}</a>
            </div>
        </div>
    </div>
</div>



<div id="edit_price" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__modal bgf8">
        <div class="fixpopuper">
            <div class="weui-cells__title">{lang xigua_he:pzsz}</div>

            <div id="pz">

            </div>
            <label class="weui-agree" onclick="add_pz('','','','','','1','5')">
                <span class="weui-agree__text"><a href="javascript:void(0);"> + {lang xigua_he:tjxpz}</a> </span>
            </label>

            <div class="fix-bottom mt10" style="position:relative">
                <a class="mt0 weui-btn weui-btn_default" onclick='return ftlimit_finish();' href="javascript:;">{lang xigua_he:wcbj}</a>
            </div>
        </div>
    </div>
</div>


<script>
    $(document).on('click', '.lxfs_btn', function () {
        $('.lxfs').append('<div class="weui-cell weui-cell_vcode">' + $('.copyfrom').html() + '</div>');
    });
    $(document).on('click', '.lxfs_btn1', function () {
        $(this).parent().parent().remove();
    });
    $(document).on('click','#bmx a', function () {
        var that = $(this);
        if(that.hasClass('tag-on')){
            that.removeClass('tag-on');
            $('#'+that.data('id')).remove();
        }else{
            that.addClass('tag-on');
            addtext(that.html(), that.data('id'), 0);
        }
    });

    function addtext(title, id, checked){
        $("#namebox").append("<label id="+id+" class=\"weui-cell\">" +
            "<div class=\"weui-cell__bd\">" +
            "<p>"+title+"</p>" +
            "</div><div class=\"weui-cell__ft\">" +
            "<span class=\"color-gray\">{lang xigua_he:bitian}</span>" +
            "<input type=\"checkbox\" class=\"weui-check\" data-name=\""+title+"\" value='1' name=\"form[required]["+id+"]\" "+(checked?'checked="checked"':'')+">" +
            "<i class=\"weui-icon-checked\"></i>" +
            "</div>" +
            "<input type='hidden' value='1' name='form[bdfield]["+id+"]' >" +
            "</label>");
    }
    $(document).on('click','.shanchuer', function () {
        var that = $(this);
        if($('.pzlist').length<=1){
            $.alert('{lang xigua_he:zsblyg}');
        }else{
            that.parent().parent().parent().remove();
        }
    });
    function ftlimit_finish(){
        var pznameallow = 1;
        var pzpriceallow = 1;
        var pznumallow = 1;
        var fytxt = '';
        $('input[name="form[pzname][]"]').each(function () {
            if(!$(this).val()){
                pznameallow =0;
            }
            fytxt = $(this).val()+ ' ';
        });
        $('input[name="form[pzprice][]"]').each(function () {
            if(!$(this).val()){
                pzpriceallow =0;
            }
        });
        $('input[name="form[pznum][]"]').each(function () {
            if(!$(this).val()){
                pznumallow =0;
            }
        });
        if(!pznameallow){
            $.toast('{lang xigua_he:qtxpzmc}');
            return;
        }
        /*if(!pzpriceallow){
            $.toast('����дƱ�۽��');
            return;
        }*/
        /*if(!pznumallow){
            $.toast('����дƱ�ֿɹ����������');
             return;
        }*/
        $('#feiyong').val(fytxt);
        $.closePopup();
    }
<!--{if !$old_data}-->
add_pz('','','','','','1','5');
<!--{else}-->
var fytxt = '';
    <!--{loop $old_data['pzname'] $_k $_v}-->
    add_pz('{$_v}','{$old_data[pzprice][$_k]}','{$old_data[pzhkprice][$_k]}','{$old_data[pznum][$_k]}','{$old_data[pzshenhe][$_k]}','{$old_data[pzmin][$_k]}','{$old_data[pzmax][$_k]}');
fytxt += '$_v ';
<!--{/loop}-->
$('#feiyong').val(fytxt);
<!--{/if}-->
    function add_pz(pzname, pzprice, pzhkprice, pznum, pzshenhe, pzmin, pzmax){
        var HTML = '' +
            '<div class="weui-cells pzlist" style="margin-top:10px!important">' +
            '    <div class="weui-cell">' +
            '        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:pzname}</label></div>' +
            '        <div class="weui-cell__bd">' +
            '            <input class="weui-input" name="form[pzname][]" type="text" placeholder="{lang xigua_he:qtxpzmc}" value="'+pzname+'">' +
            '        </div>' +
            '        <div class="weui-cell__ft"><a class="shanchuer"><i class="weui-icon-warn iconfont icon-shanchu"></i></a></div>' +
            '    </div>' +
            '    <div class="weui-cell">' +
            '        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:pjia}</label></div>' +
            '        <div class="weui-cell__bd">' +
            '            <input class="weui-input" name="form[pzprice][]" type="tel" placeholder="{lang xigua_he:qtxpjia}" value="'+pzprice+'">' +
            '        </div>' +
            '        <div class="weui-cell__ft">{lang xigua_he:yuan}</div>' +
            '    </div>' +
<!--{if $_G[cache][plugin][xigua_hk][cardname]}-->
            '    <div class="weui-cell">' +
            '        <div class="weui-cell__hd"><label class="weui-label">{$_G[cache][plugin][xigua_hk][cardname]}{lang xigua_he:jia}</label></div>' +
            '        <div class="weui-cell__bd">' +
            '            <input class="weui-input" name="form[pzhkprice][]" type="tel" placeholder="{lang xigua_he:btzw}{$_G[cache][plugin][xigua_hk][cardname]}{lang xigua_he:jia}" value="'+pzhkprice+'">' +
            '        </div>' +
            '        <div class="weui-cell__ft">{lang xigua_he:yuan}</div>' +
            '    </div>' +
<!--{/if}-->
            '    <div class="weui-cell">' +
            '        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:shuliang}</label></div>' +
            '        <div class="weui-cell__bd">' +
            '            <input class="weui-input" name="form[pznum][]" type="tel" placeholder="{lang xigua_he:btwxzsl}" value="'+pznum+'">' +
            '        </div>' +
            '    </div>' +
            '    <div class="weui-cell weui-cell_switch">' +
            '        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:sh}</label></div>' +
            '        <div class="weui-cell__bd">{lang xigua_he:xysh}</div>' +
            '        <div class="weui-cell__ft">' +
            '            <input class="weui-switch" type="checkbox" '+(pzshenhe ? 'checked="checked"':'')+' name="form[pzshenhe][]" value="1">' +
            '        </div>' +
            '    </div>' +
            '    <div class="weui-cell">' +
            '        <div class="weui-cell__hd">{lang xigua_he:xiangou}</div>' +
            '        <div class="weui-cell__bd" style="text-align:right">' +
            '            <input style="width:30px;border-bottom:1px solid;" class="weui-input tc" name="form[pzmin][]" type="tel" value="'+pzmin+'">' +
            '            {lang xigua_he:zqs}' +
            '            <input style="width:30px;border-bottom:1px solid;" class="weui-input tc" name="form[pzmax][]" type="tel" value="'+pzmax+'">' +
            '            {lang xigua_he:zhang}' +
            '        </div>' +
            '    </div>' +
            '</div>';
        $('#pz').append(HTML);
    }
    /*function add_bmx() {
    $.actions({
    title: '���ӱ�������',
    actions: [{text: "<div class='field_text'>���ı� <span class=color-gray>(�����ڱ�������д��������)</span> </div>",onClick: function () { $('#text_field').popup(); }},{text: "<div class='field_textarea'>���ı� <span class=color-gray>(�����ڱ�������д�϶�����)</span></div>",onClick: function () { }}, {
    text: "<div class='field_radio'>��ѡ <span class=color-gray>(������ֻ��ѡ��һ��)</span></div>",onClick: function () { }}, {text: "<div class='field_selects'>��ѡ <span class=color-gray>(�����߿�ѡ����)</span></div>",
    onClick: function () { }}, {text: "<div class='field_upload'>ͼƬ <span class=color-gray>(�����߿����ύͼƬ,��9��)</span></div>",
    onClick: function () { }}]});
    }
    $(document).on('click', '#add_bmx', function () {
    add_bmx();
    });*/
</script>
<!--<div id="text_field" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__modal bgf8">
        <div class="fixpopuper">
            <div class="weui-cells ">
                <div class="weui-cell weui-cell_switch">
                    <div class="weui-cell__bd">��Ϊ������</div>
                    <div class="weui-cell__ft">
                        <input class="weui-switch" type="checkbox" checked>
                    </div>
                </div>
            </div>
            <div class="weui-cells__title">������������</div>
            <div class="weui-cells ">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <input class="weui-input" type="text" placeholder="���������(����80������)">
                    </div>
                </div>
            </div>

            <div class="weui-cells lxfs">
                <div class="weui-cell weui-cell_vcode">
                    <div class="weui-cell__bd ">
                        <input class="weui-input" type="tel" name="form[111][]" placeholder="����дѡ��1" value="">
                    </div>
                    <div class="weui-cell__ft">
                        <div class="weui-vcode-btn lxfs_btn"><i class="iconfont icon-tianjia f22"></i></div>
                    </div>
                </div>

                <div class="weui-cell weui-cell_vcode copyfrom none">
                    <div class="weui-cell__bd ">
                        <input class="weui-input" type="tel" name="form[111][]" placeholder="����дѡ��" value="">
                    </div>
                    <div class="weui-cell__ft">
                        <div class="weui-vcode-btn lxfs_btn1"><i class="iconfont icon-jianshao2 f22 color-red"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>-->