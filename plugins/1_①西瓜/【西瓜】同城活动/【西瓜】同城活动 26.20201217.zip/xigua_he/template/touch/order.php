<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_he:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{eval $mang = $_GET['manage']? '&manage=1':'';}-->

    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">

            <input name="id" value="xigua_he" type="hidden">
            <input name="ac" value="order" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">

            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_he:spmcddh}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_he:spmcddh}</span>
            </label>
        </form>
        <a href="javascript:;" class="search_bar_btn main_color" id="dosearch">{lang xigua_he:search}</a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=order{$mang}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_he:qx}</a>
    </div>

    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_he&ac=order&keyword=$keyword{$mang}" class="weui-navbar__item <!--{if !$_GET[status]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:qb}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=order&keyword=$keyword&status=1{$mang}" class="weui-navbar__item <!--{if $_GET[status]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:dfk}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=order&keyword=$keyword&status=2{$mang}" class="weui-navbar__item <!--{if $_GET[status]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:dcy}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=order&keyword=$keyword&status=5{$mang}" class="weui-navbar__item <!--{if $_GET[status]==5}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:dsh}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=order&keyword=$keyword&status=3,4,7{$mang}" class="weui-navbar__item <!--{if $_GET[status]=='3,4,7'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:os4}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=order&keyword=$keyword&status=6{$mang}" class="weui-navbar__item <!--{if $_GET[status]=='6'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:ywc}</span>
        </a>
    </div>



    <div  id="list" class="weui-cells p0 mt0 before_none after_none" style="background:transparent"></div>



    <!--{template xigua_hb:loading}-->
</div>

<script>
    var loadingurl = window.location.href+'&ac=order_li&inajax=1&page=';
    var noTit = true;
</script>
<!--{eval $he_tabbar=1;$tabbar=0;}-->
<!--{template xigua_he:footer}-->