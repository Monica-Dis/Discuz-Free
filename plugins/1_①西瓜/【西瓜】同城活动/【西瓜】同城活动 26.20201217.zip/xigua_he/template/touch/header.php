<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<link rel="stylesheet" href="source/plugin/xigua_he/static/he.css?{VERHASH}" />
<!--{if $ac=='wode'}--><link rel="stylesheet" href="source/plugin/xigua_hb/static/css/mynew.css?{VERHASH}" /><!--{/if}-->
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked,.float_btn{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}
.pay_tags .aa.main_color.weui-btn_mini.weui-btn:after,.p_content{border-color:$config[maincolor]}
.mpview_area a,.in_bottom_y a.buynow,.in_bottom_sec a,.next_step{background-color:$config[maincolor]}
.main_color2{color:{$he_config[mainc2]}!important}
.jxuan{background-color:{$he_config[mainc2]}}
.index_re_List_tip{border-color:$he_config[mainc2];color:$he_config[mainc2];background-color:{echo hb_hex2rgb($he_config[mainc2], 0.13)}}
</style>
<script>
var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_he'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";
var GOOGLE = "{$_G['cache']['plugin']['xigua_he']['google']}", PUB_VARID = 0, IGNORETIP = 0, SCCG='{lang xigua_hb:sccg}';
</script>