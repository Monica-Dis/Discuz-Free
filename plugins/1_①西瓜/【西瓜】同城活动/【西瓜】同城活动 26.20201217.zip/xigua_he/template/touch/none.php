<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_he:header}-->
<div class="page__bd">
    <div class="weui-msg">
        <div class="weui-msg__icon-area"><i class="weui-icon-info weui-icon_msg"></i></div>
        <div class="weui-msg__text-area">
            <h2 class="weui-msg__title">{lang xigua_he:bnj}</h2>
            <p class="weui-msg__desc">{lang xigua_he:bnjdesc}</p>
        </div>
        <div class="weui-msg__opr-area">
            <p class="weui-btn-area">
                <a href="$SCRITPTNAME?id=xigua_hs&ac=enter&mobile=2" class="weui-btn weui-btn_primary">{lang xigua_he:ljrz}</a>
                <!--{if $he_config[allowgr]}-->
                <a href="$SCRITPTNAME?id=xigua_he&ac=chosecat&mobile=2&person=1" class="weui-btn weui-btn_default">{lang xigua_he:grfb}</a>
                <!--{/if}-->
                <a href="javascript:history.back();" class="weui-btn weui-btn_default">{lang xigua_he:fhsyy}</a>
            </p>
        </div>
        <div class="weui-msg__extra-area">
            <div class="weui-footer">
                <p class="weui-footer__links">
                    <a href="$SCRITPTNAME?id=xigua_he" class="weui-footer__link">{lang xigua_he:hdsy}</a>
                </p>
            </div>
        </div>
    </div>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_he:footer}-->