<?php exit('xxxx');?>

<div class="tuan_recommend" id="tuan_recommend">
    <div class="tuan_recommend_title"><span class="tuan_recommend_title_text"><!--{if $ac=='index'}-->{lang xigua_he:rmtj}<!--{else}-->{lang xigua_he:rmtj}<!--{/if}--></span></div>

    <div class="weui-cells fixbanner before_none mt0">

        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="$SCRITPTNAME?id=xigua_he&mobile=2" class="weui-navbar__item weui_bar__item_on ">
                <span>{lang xigua_he:tj}</span>
            </a>
            <!--{if $he_config[allowfj] && $ac=='index'}-->
            <a href="javascript:;" class="weui-navbar__item nearctrl" data-href="$SCRITPTNAME?id=xigua_he&orderby=near&ac=cat&hyid=$hyid&province=$province&city=$city&dist=$dist&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">
                <span>{lang xigua_he:juli}</span>
            </a>
            <!--{/if}-->

            <!--{loop $cat_list $cat}-->
            <a href="$SCRITPTNAME?id=xigua_he&ac=cat&hyid={$cat[id]}" class="weui-navbar__item ">
                <span>$cat[name]</span>
            </a>
            <!--{/loop}-->
        </div>

    </div>
    <ul class="helist mt0" id="list" style="padding-top:0"> </ul>
</div>
<!--{template xigua_hb:loading}-->
<!--{if $ac=='view' && $v[shid] && !$he_config[showall]}-->
<script>var loadingurl = _APPNAME+'?id=xigua_he&ac=he_li&shid={$v[shid]}&not=$hid&inajax=1&page=';</script>
<!--{else}-->
<script>var loadingurl = _APPNAME+'?id=xigua_he&ac=he_li&cat_id={$v[hangye_id1]}&inajax=1&not=$hid&page=';</script>
<!--{/if}-->