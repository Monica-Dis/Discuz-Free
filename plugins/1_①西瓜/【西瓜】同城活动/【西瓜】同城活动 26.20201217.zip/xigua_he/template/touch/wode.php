<?php exit('xxxx');?>
<!--{template xigua_he:header}--><!--{eval $no_header_fix=1;}--><style>.x_header{position:relative}</style>
<style>.my_new_bd .my__head_user{margin:30px 15px;}.weui-cells{overflow: hidden;background: #fff;margin: 15px;border-radius: 10px;position: relative;padding: 0;}.weui-cells:before, .weui-cells:after, .weui-grids:before,.weui-grids:after,.weui-grid:before,.weui-grid:after{display:none}.my_new_bd .my__head_new{margin-bottom:35px}.weui-grid{padding:20px 0}</style>
<div class="page__bd my_new_bd ">
    <div class="do_bd">
        <!--{template xigua_hb:common_nav}-->
        <!--{if $iszbf && $sh}-->
        <a href="$SCRITPTNAME?id=xigua_hs&ac=shcenter" class="more_sh">{lang xigua_he:wddp}<i class="iconfont icon-jinrujiantou f12 vm"></i></a>
        <!--{/if}-->

        <div class="mt0 main_bg hh_my_head">
            <i class="header-annimate-element1"></i>
            <i class="header-annimate-element4"></i>
            <i class="header-annimate-element5"></i>
            <i class="header-annimate-element6"></i>
            <i class="header-annimate-element7"></i>
            <i class="header-annimate-element8"></i>
            <i class="header-annimate-element9"></i>


            <div class="my__head_user cl">
                <!--{if $_G['cache']['plugin']['xigua_member']}-->
                <a href="$SCRITPTNAME?id=xigua_member:profile" class="my__head_avatar z"><img src="{avatar($_G[uid], 'big', true)}" ></a>
                <!--{else}-->
                <span class="my__head_avatar z"><img src="{avatar($_G[uid], 'big', true)}" ></span>
                <!--{/if}-->
                <div>
                    <div class="my__head_nickname f16">{$_G[username]}</div>
                    <a class="qblink">UID : {$_G[uid]}</a>
                </div>
            </div>
        </div>
        <!--{if $iszbf}-->
        <div class="weui-grids weui-grids-mini toptjw">
            <a href="javascript:;" class="weui-grid" style="width:33.33333%!important;">
                <div class="tc main_color">
                    <span id="njum1" class="countup f20">$totalin</span><em class="f12">{lang xigua_he:yuan}</em>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_he:hdzsr}<span class="c9 f12 none">({lang xigua_he:bhsxf})</span></p>
            </a>
            <a href="javascript:;" class="weui-grid" style="width:33.33333%!important;">
                <div class="tc">
                    <span id="njum2" class="countup f20 main_color">{$totalhd}</span>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_he:huodong}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_he&ac=bgm&status=5{$urlext}" class="weui-grid" style="width:33.33333%!important;">
                <div class="tc">
                    <span id="njum3" class="countup f20 main_color">{$needs}</span>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_he:dsh}</p>
            </a>
        </div>

        <div class="weui-cells">
        <div class="weui-grids">
            <a class="weui-grid" style="width:33.3333%" href="$SCRITPTNAME?id=xigua_he&ac=myhe&status=2&from=index{$urlext}">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-huodong f24 main_color"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_he:fabuguanli}</p>
            </a>
            <a class="weui-grid" style="width:33.3333%" id="saoyisao" href="javascript:;" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-saoyisao color-good f20" style="position:relative;top:3px"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_he:smyp}</p>
            </a>
            <a class="weui-grid" style="width:33.3333%" <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jump_download();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao&mobile=2"<!--{/if}--><!--{/if}--> class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-qianbao2  color-red2 f24"></i>
                <!--{if $qianbao[money]>0}--><span class="weui-badge">&yen;{echo $qianbao[money]*100/100}</span><!--{/if}-->
            </div>
            <p class="weui-grid__label">{lang xigua_hb:myqb}</p>
            </a>
        </div>
        </div>


        <div class="weui-cells">

            <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=about&mobile=2">
                <div class="weui-cell__hd"><i class="iconfont icon-guize color-forest"></i></div>
                <div class="weui-cell__bd">
                    <p class="f14">{lang xigua_hb:bangzhu}</p>
                </div>
                <div class="weui-cell__ft"> </div>
            </a>
            <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
                <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
                <div class="weui-cell__bd">
                    <p class="f14">{lang xigua_hb:kefu}</p>
                </div>
                <div class="weui-cell__ft f14">{lang xigua_hb:zhwo}</div>
            </a>
        </div>
        <!--{else}-->
        <div class="weui-grids weui-grids-mini toptjw">
            <a href="javascript:;" class="weui-grid">
                <div class="tc">
                    <span id="njum1" class="countup f20 main_color">$myjoins</span>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_he:bm}</p>
            </a>
            <a href="javascript:;" class="weui-grid">
                <div class="tc">
                    <span id="njum2" class="countup f20 main_color ">$myfavs</span>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_he:shoucang}</p>
            </a>
            <a href="javascript:;" class="weui-grid">
                <div class="tc">
                    <span id="njum3" class="countup f20 main_color">{$shfavs}</span>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_he:gz}</p>
            </a>
        </div>
        <div class="weui-cells">
            <div class="c3 f14 weui_title">{lang xigua_he:wdbm}
                <a class="y" href="$SCRITPTNAME?id=xigua_he&ac=order">{lang xigua_he:qb} <i class="f13 iconfont icon-jinrujiantou"></i></a>
            </div>
            <div class="weui-cell cl">
                <a href="$SCRITPTNAME?id=xigua_he&ac=order{$urlext}" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-icons- main_color2 f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_he:qb}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_he&ac=order&status=1" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-xianshiqianggou main_color2 f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_he:dfk}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_he&ac=order&status=2" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-huodong1 main_color2 f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_he:dcy}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_he&ac=order&status=3,4,7" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-ganxie1 main_color2 f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_he:os4}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_he&ac=order&status=6" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-ganxie main_color2 f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_he:ywc}</p>
                </a>
            </div>
        </div>


        <div class="weui-cells">

        <div class="weui-grids  ">
            <a class="weui-grid" style="width:33.3333%" href="$SCRITPTNAME?id=xigua_he&ac=follow{$urlext}">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-shoucang1 f24 main_color"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_he:wdsc}</p>
            </a>
            <a class="weui-grid" style="width:33.3333%" href="$SCRITPTNAME?id=xigua_hs&ac=myfav&mobile=2" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-shoplight color-paypal  f24"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_he:wdgz}</p>
            </a>
            <a class="weui-grid" style="width:33.3333%" <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jump_download();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao&mobile=2"<!--{/if}--><!--{/if}--> class="weui-grid">
            <div class="weui-grid__icon">
                <i class="iconfont icon-qianbao2 color-red2 f24"></i>
                <!--{if $qianbao[money]>0}--><span class="weui-badge">&yen;{echo $qianbao[money]*100/100}</span><!--{/if}-->
            </div>
            <p class="weui-grid__label">{lang xigua_hb:myqb}</p>
            </a>
        </div>
        </div>


        <div class="weui-cells">

            <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=about&mobile=2">
                <div class="weui-cell__hd"><i class="iconfont icon-guize color-forest"></i></div>
                <div class="weui-cell__bd">
                    <p class="f14">{lang xigua_hb:bangzhu}</p>
                </div>
                <div class="weui-cell__ft"> </div>
            </a>
            <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
                <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
                <div class="weui-cell__bd">
                    <p class="f14">{lang xigua_hb:kefu}</p>
                </div>
                <div class="weui-cell__ft f14">{lang xigua_hb:zhwo}</div>
            </a>
        </div>
        <!--{/if}-->




    </div>
</div>
<!--{if $sh  || $he_huodong->fetch_is_G()}-->
<!--{if $iszbf}-->
<a class="zbf main_bg" href="$SCRITPTNAME?id=xigua_he&ac=wode&mobile=2{$urlext}" id="shguide">{lang xigua_he:qhwcyz}</a>
<!--{else}-->
<a class="zbf main_bg" href="$SCRITPTNAME?id=xigua_he&ac=wode&view=zbf&mobile=2{$urlext}" id="shguide">{lang xigua_he:qhwzbf}</a>
<!--{/if}-->
<!--{/if}-->

<!--{eval $tabbar=0;$he_tabbar=1;}-->
<!--{template xigua_he:footer}-->
<script src="source/plugin/xigua_hb/static/countUp.js"></script>
<script>
    $(document).on('click','#saoyisao', function () {
        <!--{if IN_MAGAPP}-->mag.scanQR(function(text){window.location.href=text});
        <!--{elseif IN_QIANFAN}-->qianfanScan();
        <!--{elseif IN_APPBYME}-->appbymeScan();
        <!--{else}-->wx.scanQRCode();<!--{/if}-->
    });
    function appbymeScan() {
        sq.scan(function(result){
            window.location.href=result.url;
        });
    }
    function qianfanScan(){
        QFH5.jumpScan(function(state,data){
            if(state==1){
                window.location.href=data.content;
            }else{
            }
        })
    }
    var options = {useEasing : true,useGrouping : true,separator : '',decimal : '.',prefix : '',suffix : ''};
    new countUp("njum1", 0, $('#njum1').text(), 0, 2.5, options).start();
    new countUp("njum2", 0, $('#njum2').text(), 0, 2.5, options).start();
    new countUp("njum3", 0, $('#njum3').text(), 0, 2.5, options).start();
</script>