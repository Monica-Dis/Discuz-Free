<?php exit('xxxxx');?>
<!--{if $sh[name]}-->
<div class="weui-cells f15 border_none">
    <div class="shincard">
        <div class="cl">
            <img src="{$sh[logo]}" class="shinlogo" alt="{$sh[name]}">
            <div class="shinname">
                <h4><a href="$SCRITPTNAME?id=xigua_he&ac=shop&shid=$sh[shid]">{$sh[name]}</a></h4>
<!--{if ($veris2[$shid] || $bao[$v[uid]])}-->
    <div class="sp_desc sp_tag">
        <!--{if $veris2[$shid]}--><!--{if $_G[cache][plugin][xigua_hr][qytb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][qytb]" /> <!--{else}--><i class="iconfont icon-qiyerenzheng color-dropbox vm"></i><!--{/if}--><!--{/if}-->
        <!--{if $bao[$v[uid]]}--><!--{if !$bao[$v[uid]][icon]}--><!--{eval $bao[$v[uid]][icon] = $_G[cache][plugin][xigua_hr][bzjtb];}--><!--{/if}--><!--{if $bao[$v[uid]][icon]}--><img class="rzimg vm" src="$bao[$v[uid]][icon]" /> <!--{else}--><i class="iconfont icon-baozhengjinmoshi color-good vm pr_1" style="font-size:19px"></i><!--{/if}--><!--{if $_G[cache][plugin][xigua_hr][bzjed]}--><span class="f13 main_color">{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</span><!--{/if}--><!--{/if}-->
    </div>
<!--{/if}-->
                <div class="shindesc">
                    <span>{$hdcount}{lang xigua_he:huodong}</span> <span>{$sh[follow]}{lang xigua_he:fensi}</span>
                </div>
                <!--{if $he_config[sjys]==2}-->
                <!--{if $followed}-->
                <a href="javascript:;" class="do_follow smbtn main_color " data-id="$shid"><em>{lang xigua_hs:yiguanzhu}</em></a>
                <!--{else}-->
                <a href="javascript:;" class="do_follow smbtn main_color " data-wei="1" data-id="$shid"><em>{lang xigua_hs:jiaguanzhu}</em></a>
                <!--{/if}-->
                <!--{if $he_config[xzlxfs] && !C::t('#xigua_he#xigua_he_order')->fetch_count_by_where('uid='.$_G['uid'].' AND hid='.$hid.' AND status in(2,5,6)')}-->
                    <a href="javascript:;" onclick="$.alert('{lang xigua_he:qlxsj}');" class=" smbtn smbtn_tel">{lang xigua_he:lxt}</a>
                <!--{else}-->
                    <a href="tel:{$v[tel]}" class=" smbtn smbtn_tel ">{lang xigua_he:lxt}</a>
                <!--{/if}-->
                <!--{/if}-->
            </div>
        </div>
    </div>
    <!--{if !$he_config['hidede']}-->
    <p class="shinjs">$sh[jieshao]</p>
    <!--{/if}-->
    <!--{if $he_config[sjys]==1}-->
    <div class="mpview_area ">
    <!--{if $followed}-->
        <a href="javascript:;" class="do_follow" data-id="$shid"><em>{lang xigua_hs:yiguanzhu}</em></a>
    <!--{else}-->
        <a href="javascript:;" class="do_follow" data-wei="1" data-id="$shid"><em>{lang xigua_hs:jiaguanzhu}</em></a>
    <!--{/if}-->
        <a href="tel:{$v[tel]}">{lang xigua_he:lxt}</a>
    </div>
    <!--{/if}-->
</div>
<!--{/if}-->