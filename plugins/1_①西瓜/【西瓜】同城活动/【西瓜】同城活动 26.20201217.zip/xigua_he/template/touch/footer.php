<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_he:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_he/static/he.js?{VERHASH}"></script>
<!--{if $he_config['zdsj']}--><script>$.ajax({type: 'get',url: _APPNAME + '?id=xigua_he&ac=com&do=complete&autocomplete=1',dataType: 'xml',success: function (data) {},});</script><!--{/if}-->