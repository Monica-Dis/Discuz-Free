<?php exit('xxx'); ?>
<!--{template xigua_he:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd ">
    <form action="$SCRITPTNAME?id=xigua_he&ac=next" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="form[hid]" value="{$hid}">
        <input type="hidden" name="form[num]" value="{$_GET[num]}">
        <input type="hidden" name="form[typ]" value="{$_GET[typ]}">
        <input type="hidden" name="form[st]" value="{$_GET[st]}">
        <input type="hidden" name="form[idu]" value="{$_GET[idu]}">
        <input type="hidden" name="form[jzp]" value="{$_GET[jzp]}">
        <input type="hidden" name="jzp" value="{$_GET[jzp]}">

<!--{loop $numary $_k $_v}-->
        <div class="weui-cells__title">{$pzinfo[pzname]} {lang xigua_he:di}{$_v}{lang xigua_he:wei}
            <!--{if $_k==0}--><a class="y main_color" href="javascript:window.history.go(-1);">{lang xigua_hb:back}</a>
            <!--{/if}--></div>
        <div class="weui-cells ">
  <!--{loop $v[bdfield] $__k $__v}-->
<!--{eval $bd_title = $bmfield[$__k];
$var_key = str_replace('f_', '', $__k);
$var = $he_vars[$var_key];
$formfix = "form[vars_".$_k."]";
if(!$var[placehd]):
$var[placehd] = lang_he('qtx', 0). $bd_title;
endif;
}-->
            <!--{if $var['type']=='number'}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">$bd_title<!--{if $v[required][$__k]}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="$formfix[{$var[pluginvarid]}]" type="tel" placeholder="{$var[placehd]}" value="{$var[extra]}">
                </div>
                <!--{if $var[unitnew]}--><div class="weui-cell__ft">$var[unitnew]</div><!--{/if}-->
            </div>
            <!--{elseif $he_vars[$var_key]['type']=='text'}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">$bd_title<!--{if $v[required][$__k]}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="$formfix[{$var[pluginvarid]}]" type="text" placeholder="{$var[placehd]}" value="{$var[extra]}">
                </div>
                <!--{if $var[unitnew]}--><div class="weui-cell__ft">$var[unitnew]</div><!--{/if}-->
            </div>
            <!--{elseif $he_vars[$var_key]['type']=='textarea'}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <textarea class="weui-textarea" name="$formfix[{$var[pluginvarid]}]" placeholder="{$var[placehd]}" rows="3" value="{$var[extra]}">{$var[extra]}</textarea>
                </div>
            </div>
            <!--{elseif $he_vars[$var_key]['type']=='datetime'}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{$bd_title}<!--{if $v[required][$__k]}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" id="datetime_picker_{$_k}_{$var[pluginvarid]}" name="$formfix[{$var[pluginvarid]}]" type="text" placeholder="{$var[placehd]}" value="{$var[extra]}">
                </div>
                <script>$("#datetime_picker_{$_k}_{$var[pluginvarid]}").datetimePicker();</script>
            </div>
            <!--{elseif $he_vars[$var_key]['type']=='date'}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{$bd_title}<!--{if $v[required][$__k]}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" id="date_picker_{$_k}_{$var[pluginvarid]}" name="$formfix[{$var[pluginvarid]}]" type="text" placeholder="{$var[placehd]}" value="{$var[extra]}">
                </div>
                <script>$("#date_picker_{$_k}_{$var[pluginvarid]}").calendar();</script>
            </div>
            <!--{elseif $he_vars[$var_key]['type']=='select'}-->
            <!--{eval $extra = trim($var[extra]);$extra = explode("\n", $extra);}-->
            <div class="weui-cell weui-cell_select weui-cell_select-after">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{$bd_title}<!--{if $v[required][$__k]}--><em class="color-red">*</em><!--{/if}--></label>
                </div>
                <div class="weui-cell__bd">
                    <select class="weui-select" name="$formfix[{$var[pluginvarid]}]">
                    <!--{loop $extra $extra_string}-->
                    <!--{eval list($tmp1, $tmp2) = explode('=', trim($extra_string));}-->
                    <option value="$tmp1" <!--{if {$old_data[vars][$var[pluginvarid]][value]}==$tmp1}-->selected="selected"<!--{/if}-->>$tmp2</option>
                    <!--{/loop}-->
                    </select>
                </div>
            </div>
            <!--{elseif $he_vars[$var_key]['type']=='selects'}-->
            <!--{eval $extra = trim($var[extra]);$extra = explode("\n", $extra);}-->
            <div class="weui-cell weui-cell_select weui-cell_select-after">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{$bd_title}<!--{if $v[required][$__k]}--><em class="color-red">*</em><!--{/if}--></label>
                </div>
                <div class="weui-cell__bd">
                    <select multiple="multiple" class="weui-select" name="$formfix[{$var[pluginvarid]}][]" <!--{if $old_data && $var[unchangeable]}-->disabled="disabled"<!--{/if}--> >
                    <!--{loop $extra $extra_string}-->
                    <!--{eval list($tmp1, $tmp2) = explode('=', trim($extra_string));}-->
                    <option value="$tmp1" <!--{if in_array($tmp1, $old_data[vars][$var[pluginvarid]][value]) }-->selected="selected"<!--{/if}-->>$tmp2</option>
                    <!--{/loop}-->
                    </select>
                </div>
            </div>
            <!--{elseif $he_vars[$var_key]['type']=='pics'}-->
            <!--{eval $var[placehd] = intval( $var[placehd]);}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{$bd_title}<!--{if $v[required][$__k]}--><em class="color-red">*</em><!--{/if}--></p>
                            <div class="weui-uploader__info">{echo $var[placehd] ? str_replace('n', $var[placehd], lang_hb('zuiduozhao',0)) : ''}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{$var[placehd]}" data-maxtip="{echo str_replace('n', $var[placehd], lang_he('zuiduozhao',0))}">
                                <!--{loop $old_data[album] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                                    <input type="hidden" name="$formfix[{$var[pluginvarid]}][]" value="$img"/>
                                    <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="$formfix[{$var[pluginvarid]}]" data-multi="1"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="$formfix[{$var[pluginvarid]}]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--{/if}-->
  <!--{/loop}-->
        </div>
<!--{/loop}-->

        <div class="fix-bottom fix_next" style="position:fixed">
            <div class="weui-flex">
                <div class="weui-flex__item">{lang xigua_he:heji} <span class="mony main_color">&yen; <em id="money_show">$totprice</em></span>
                </div>
                <div class="weui-flex__item tc next_step main_bg">
                    <input type="submit" style="height:50px;" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_he:xyb}"/>
                </div>
            </div>
        </div>
    </form>

    <div id="popctrl" class="weui-popup__container" style="z-index:1001">
        <div class="weui-popup__modal">
            <div style="height: 100vh"><img id="photo"></div>
            <div class="pub_funcbar">
                <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
                <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
            </div>
        </div>
    </div>
</div>
<!--{eval $he_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_he:enter_up}-->
<!--{template xigua_he:footer}-->
<!--{if $errmsg}-->
<script>
    $.alert('$errmsg', function () {
        window.history.go(-1);
    });
</script>
<!--{/if}-->