<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<li class="index_re_List border_bottom<!--{if $v[hasend]||$v[bhasend]}--> op6<!--{/if}-->">
    <!--{if $v[hasend]||$v[bhasend]}--><div class="hd_complete"></div><!--{/if}-->
    <a class="index_new_wap_list jump_he" href="javascript:;" data-id="{$v[id]}" >
        <div class="c">
            <div class="index_re_List_Pic dt_content_pic">
                <fieldset >
                    <img src="{echo $v[fengmian] ? $v[fengmian]: $v[album][0]}" alt="{$v[title]}">
                </fieldset>
            </div>
        </div>

        <div class="b">
            <div class="index_re_List_Txt">
                <h4 class="index_re_List_Tittle">
                    <span>{$v[title]}</span>
                </h4>
                <div class="index_re_List_timeQu">
                    <p class="index_re_List_time">{$v[start_u]} {lang xigua_he:ks}</p>
                    <!--{if $v[dist]}--><p>{$v[dist]}</p><!--{/if}-->
                </div>
                <div class="index_re_list_plus">
                    <!--{if $v[hkpricerange]}-->
                        <p class="lis_hksp">{$_G['cache']['plugin']['xigua_hk']['cardname']}{lang xigua_he:jia}{$v[hkpricerange]}{lang xigua_he:yuan}</p>
                    <!--{elseif $v[pricerange] && $v[allow_tk]}-->
                        <span class="hb_tag">{lang xigua_he:zctk}</span>
                    <!--{elseif $v['srange_ary']}-->
                        <!--{loop $v['srange_ary'] $_v}-->
                    <span class="hb_tag">$_v</span>
                        <!--{/loop}-->
                    <!--{/if}-->
                </div>
                <div class="index_re_list_price">
                    <p class="index_re_List_join main_color2"><em><!--{if $v[pricerange]}-->&yen;{$v[pricerange]}<!--{else}-->{lang xigua_he:mf}<!--{/if}--></em></p>
                </div>
                <div class="index_re_List_tip">
<!--{if $v[hasend]}-->
{lang xigua_he:hdyjs}
<!--{elseif $v[bhasend]}-->
{lang xigua_he:bmyjs}
<!--{elseif $v[bstarttime]>=TIMESTAMP && $v[bendtime]<TIMESTAMP}-->
{lang xigua_he:bmjjz}
<!--{else}-->
<!--{if $v[jz]}-->
{lang xigua_he:gyjk}
<!--{else}-->
<!--{if $v[pricerange]}-->{lang xigua_he:lj}<!--{else}-->{lang xigua_he:mf}<!--{/if}-->{lang xigua_he:bm}
<!--{/if}-->
<!--{/if}-->
                </div>
            </div>
        </div>
    </a>
</li>
<!--{/loop}-->