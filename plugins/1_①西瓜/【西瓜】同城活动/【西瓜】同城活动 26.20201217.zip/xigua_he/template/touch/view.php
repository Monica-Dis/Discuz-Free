<?php exit('xxxx');?>
<!--{template xigua_he:header}--><!--{eval $no_header_fix=1;}--><style>.x_header{position:relative}</style>

<div class="hm_view_nav">
    <a href="$back_to"><i class="iconfont icon-fanhui"></i></a>
    <a href="$SCRITPTNAME?id=xigua_he"><i class="iconfont icon-index"></i></a>
    <a href="javascript:;" class="" onclick="return he_newewm();"><i class=" f12">{lang xigua_he:yq}</i></a>
</div>
<div class="page__bd view_body">
    <!--{if $v[fengmian]}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$v[fengmian]" /></div><!--{/if}-->
    <div class="swipe cl" id="goodinfo">
        <div class="swipe-wrap">
            <!--{if !$v[album]}-->
            <!--{eval $v[album] = $v[append_img_ary];}-->
            <!--{/if}-->
            <!--{loop $v[album] $slider}-->
            <div><img src='$slider' onerror="this.error=null;$(this).remove();" <!--{if $he_config[viewh]}-->style="height:{$he_config[viewh]}px"<!--{/if}--> /></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $v[album] $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}--> ></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <div class="bgf">
        <div class="topcard" <!--{if $he_config[style]==2}-->style="margin:0"<!--{/if}-->>
            <h2 class="view_title">{$v['title']}</h2>

            <div class="weui-cell fullcell view_bar">
                <div class="weui-cell__bd f12">
                    <span><i class="iconfont icon-browse f12"></i> {echo intval($v[views])}</span>
                    <span><i class="iconfont icon-fenxiang1 f12"></i> {echo intval($v[shares])}</span>
                    <span><i class="iconfont icon-shoucang1 f12"></i> {echo intval($v[favs])}</span>

                    <div class="y">
                        <!--{if $v['allow_tk']}-->
                        <span class=" main_color2">
                        <i class="iconfont icon-duigou2 f12"></i> {lang xigua_he:zctk}
                    </span>
                        <!--{else}-->
                        <span class=" main_color2">
                        <i class="iconfont icon-duigou2 f12"></i> {lang xigua_he:bzctk}
                    </span>
                        <!--{/if}-->
                        <!--{loop $v['srange_ary'] $range}-->
                        <span class=" main_color2"><i class="iconfont icon-duigou2 f12"></i> $range</span>
                        <!--{/loop}-->
                    </div>
                </div>
            </div>

            <div class="weui-cell fullcell" style="align-items:normal" href="javascript:;">
                <div class="weui-cell__hd"><i class="iconfont icon-shijian "></i></div>
                <div class="weui-cell__bd f13">
                    <div>
                        <span>{lang xigua_he:bmsj}:</span>
                        <span>{echo substr($v[bstart_u], 5)}</span>
                        <!--{if $v[bend_u]}-->
                        <span>{lang xigua_he:z}</span>
                        <span>{echo substr($v[bend_u], 5)}</span>
                        <!--{else}-->
                        <span>{lang xigua_he:ks}</span>
                        <!--{/if}-->
                    </div>
                    <div>
                        <span>{lang xigua_he:hdsj}:</span>
                        <span>{echo substr($v[start_u], 5)}</span>
                        <!--{if $v[end_u]}-->
                        <span>{lang xigua_he:z}</span>
                        <span>{echo substr($v[end_u], 5)}</span>
                        <!--{else}-->
                        <span>{lang xigua_he:ks}</span>
                        <!--{/if}-->
                    </div>
                </div>
            </div>

            <!--{if $v[addr] || $v[district]}-->
            <a class="weui-cell weui-cell_access fullcell" href="javascript:;" id="v_openLocation" data-lat="$v[lat]" data-lng="$v[lng]" data-name="$v[title]" data-addr="{$v[city]}{$v[district]}{$v[street]}">
                <div class="weui-cell__hd"><i class="iconfont icon-mudedi"></i></div>
                <div class="weui-cell__bd">
                    <p class="f14">{$v[city]}{$v[district]}{$v[street]}{echo str_replace(array($v[city], $v[district], $v[street]), '', $v[addr])}</p>
                    <!--{if $he_config[showjuli]}-->
                    <p class="f13 c9" id="driving" data-id="$v[shid]">{lang xigua_hs:jisuan}</p>
                    <!--{/if}-->
                </div>
                <div class="weui-cell__ft">
                </div>
            </a>
            <!--{/if}-->

<!--{if $v[showbm]}-->
            <div class="weui-cell fullcell ">
                <div class="weui-cell__hd"><i class="iconfont icon-jieban "></i></div>
                <div class="weui-cell__bd f14">
                    <span>{lang xigua_he:ybm}{$v[joins]}{lang xigua_he:r}</span>
                    <!--{if $hasshen}--><span class="view_shtxt">{lang xigua_he:ysh}{$hasshen}{lang xigua_he:r} /</span><!--{/if}-->
                    <span class="view_shtxt"><!--{if $v[allnum]}-->{lang xigua_he:zuiduo}{$v[allnum]}{lang xigua_he:r}<!--{else}-->{lang xigua_he:bxrs}<!--{/if}-->
                    </span>
                </div>
            </div>
<!--{/if}-->
            <a class="weui-cell weui-cell_access fullcell <!--{if $errmsg}-->buybtn<!--{else}-->buynow<!--{/if}-->" href="javascript:;">
                <div class="weui-cell__hd"><i class="iconfont icon-icons- "></i></div>
                <div class="weui-cell__bd">
                    <!--{if $v[jz]}-->
                    <span class="main_color2 mr10">
                        {lang xigua_he:zjzprice} &yen; $totaljz
                    </span>
                    <!--{else}-->
                    <span class="main_color2 mr10"><!--{if $v[pricerange]}-->&yen;{$v[pricerange]}<!--{else}-->{lang xigua_he:mf}<!--{/if}--></span>
                    <!--{/if}-->
                    <!--{if $v[hkpricerange]}-->
                        <span class="lis_hksp pr-1">{$_G['cache']['plugin']['xigua_hk']['cardname']}{lang xigua_he:jia}{$v[hkpricerange]}{lang xigua_he:yuan}</span>
                    <!--{/if}-->
                </div>
                <div class="weui-cell__ft">
                </div>
            </a>
<!--{eval include DISCUZ_ROOT.'source/plugin/xigua_he/include/c_view.php';}-->
        <!--{loop $custext $__k $__v}-->
        <div class="weui-cell fullcell ">
            <div class="weui-cell__hd"><i class="iconfont icon-daohangguize "></i></div>
            <div class="weui-cell__bd f14">
                <span class="c3">$__k</span>
                <span class="c6">$__v</span>
            </div>
        </div>
        <!--{/loop}-->

        </div>
    </div>

    <!--{template xigua_he:card}-->


    <div class="weui-cells f15  before_none after_none">
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <p>{lang xigua_he:hdjs1}</p>
            </div>

        </div>
        <article class="weui-cell weui-article f14">
            <section>
                <p>{echo he_nl2br($v['jieshao']);}</p>
                <!--{loop $v[append_img_ary] $__k $__v}-->
                <p><img src="{$__v}" /></p>
                <p>{echo he_nl2br($v[append_text_ary][$__k]);}</p>
                <!--{/loop}-->
            </section>
        </article>
    </div>


    <!--{if $v[showbm] && $joinlist}-->
    <div class="weui-cells f15 before_none after_none weui-cell_access">
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <p>{lang xigua_he:ybm}({$v[joins]})</p>
            </div>
            <a href="$SCRITPTNAME?id=xigua_he&ac=baoming&hid=$hid&mobile=2{$urlext}" class="weui-cell__ft main_color">{lang xigua_he:gdbm}</a>
        </div>
        <div class="weui-cell">
            <div class="share_list cl">
                <!--{loop $joinlist $_v}-->
                <div class="z">
                    <img class="share_tz" src="{avatar($_v[uid], 'middle', true)}">
                    <!--{if $_v[numtotal]>1}-->
                    <em class="">x {$_v[numtotal]}</em>
                    <!--{/if}-->
                    <span>{$_v['username']}</span>
                </div>
                <!--{/loop}-->
            </div>
        </div>
    </div>
    <!--{/if}-->

    <!--{if $_G['cache']['plugin']['xigua_dp'] && in_array('he', unserialize($_G['cache']['plugin']['xigua_dp']['opens']))}-->
    <style>.gzbtn{background-color:$config[maincolor]}</style><div id="ptdiv2" style="display:none"></div>
    <script>
        $.ajax({type: 'get',dataType: 'xml',
            url: '$SCRITPTNAME?id=xigua_dp&ac=jingxuan&inajax=1&type=he&typeid=$v[id]&shid=$sh[shid]&pagesize=5&page=1',
            success: function (data) {
                if(null==data){ $('#ptdiv2').remove(); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(!s){ $('#ptdiv2').remove(); return false;}
                $('head').append('<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?{VERHASH}" />');
                $('body').append('<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"><\/script>');
                $('#ptdiv2').html(s).show();
            },
            error: function () {$('#ptdiv2').remove();}
        });
    </script>
    <!--{/if}-->

    <!--{template xigua_he:tuijian}-->
<!--{eval
$showbtns = unserialize($he_config[viewbtn]);
}-->
    <div class="in_bottom weui-flex border_top">
        <!--{if in_array(1, $showbtns)}-->
        <!--{if $sh[shid]}-->
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_he&ac=shop&shid=$sh[shid]" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-shoplight weui-tabbar__icon f25"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_he:jd}</p>
            </a>
        </div>
        <!--{else}-->
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hb&ac=chat&touid={$v[uid]}" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-sixin2 weui-tabbar__icon f25"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_he:lxt}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{/if}-->
        <!--{if in_array(2, $showbtns)}-->
        <div class="in_bottom_z">
            <a href="javascript:;" class="weui-tabbar__item dofollow" data-id="$hid">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont  weui-tabbar__icon f24 icon-<!--{if $faved}-->shoucang<!--{else}-->shoucang1<!--{/if}-->"></i>
                </span>
                <p class="weui-tabbar__label"><em<!--{if !$faved}--> class="none"<!--{/if}-->>{lang xigua_he:yi}</em>{lang xigua_he:shoucang}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if in_array(4, $showbtns)}-->
        <div class="in_bottom_z">
            <a href="{$kefulink}" class="weui-tabbar__item">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-kefu1 weui-tabbar__icon f22"></i>
                </span>
                <p class="weui-tabbar__label">{lang xigua_he:zxzx}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if in_array(3, $showbtns)}-->
        <div class="in_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_he&ac=order" class="weui-tabbar__item">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-icons- weui-tabbar__icon f24"></i>
                </span>
                <p class="weui-tabbar__label">{lang xigua_he:wdbm}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if $v[status]!=2}-->
        <!--{eval $errmsg = lang_he('hdyjs',0);}-->
        <!--{/if}-->
        <div class="weui-flex__item in_bottom_y in_bottom_main">
            <a href="javascript:;" class="bgcolor_sec mc_bg <!--{if $errmsg}-->buybtn<!--{else}-->buynow<!--{/if}-->">
<div class="fqpd"><!--{if $errmsg}-->$errmsg<!--{else}-->
<!--{if $v[jz]}-->{lang xigua_he:gyjk}<!--{else}-->{lang xigua_he:wybm}<!--{/if}-->
<!--{/if}--></div>
            </a>
        </div>
    </div>
</div>

<!--{template xigua_he:yqk}-->
<!--{eval $tabbar=0;}-->
<!--{template xigua_he:pay_ctrl}-->
<!--{template xigua_he:footer}-->
<script src="source/plugin/xigua_hb/static/js/html2canvas.min.js?{VERHASH}"></script>
<script>
if($('#driving').length>0){
    var driv = $('#driving'), dnt = 0;
    var drivInterval=setInterval(function () {
        he_getlocation(function(position){
            $.ajax({
                type: 'post',
                url: _APPNAME +'?id=xigua_hs&ac=driving&shid='+driv.data('id')+'&inajax=1&from='+(position.latitude||position.lat) + ','+ (position.longitude||position.lng),
                data: {'formhash':FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    if(null==data){return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    var sary = s.split('|');
                    if(sary[0]=='success'){
                        $('#driving').show().html(sary[1]);
                    }
                    clearInterval(drivInterval);
                },
                error: function () { $('#driving').hide(); }
            });
        });
        dnt++;
        if(dnt>2){
            clearInterval(drivInterval);
            $('#driving').show().html('');
        }
    }, 1500);
}
$(document).on('click', '#v_openLocation', function () {
    var that = $(this);
    if(('{HB_INWECHAT}' && "{$_G['cache']['plugin']['xigua_hb'][multiupload]}")==1){
        wx.openLocation({
            latitude: that.data('lat'),
            longitude: that.data('lng'),
            name: that.data('name'),
            address: that.data('addr'),
            scale: 14,
            infoUrl:window.location.href
        });
    }else if(GOOGLE){
        window.location.href = _APPNAME+'?id=xigua_hs&ac=googleMap&lat='+that.data('lat')+"&lng="+that.data('lng');
    }else{
        window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:"+that.data('lat')+","+that.data('lng')+";title:"+that.data('name')+";addr:"+that.data('addr');
    }
    return false;
});
$(document).on('click','.do_follow', function () {
    var that = $(this);
    $.showLoading();
    $.ajax({
        type: 'post',
        url: _APPNAME +'?id=xigua_hs&ac=follow&do=do_follow&shid='+that.data('id')+'&inajax=1',
        data: {'formhash':FORMHASH},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s.split('|')[1]=='1'){
                that.html('{lang xigua_hs:yiguanzhu}').addClass('weui-btn_disabled');
            }else{
                tip_common(s);
                that.html('{lang xigua_hs:jiaguanzhu}').removeClass('weui-btn_disabled');
            }
        },
        error: function () {
            $.hideLoading();
        }
    });
});
$(document).on('click','.dofollow', function () {
    var that = $(this);
    $.showLoading();
    $.ajax({
        type: 'post',
        url: _APPNAME +'?id=xigua_he&ac=follow&hid='+that.data('id')+'&inajax=1',
        data: {'formhash':FORMHASH},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s.split('|')[1]> 0){
                tip_common('success|'+SCCG+'||');
                that.find('.iconfont').removeClass('icon-shoucang1').addClass('icon-shoucang');
                that.find('em').removeClass('none');
            }else{
                tip_common(s);
                that.find('.iconfont').removeClass('icon-shoucang').addClass('icon-shoucang1');
                that.find('em').addClass('none');
            }
        },
        error: function () {
            $.hideLoading();
        }
    });
});
</script>