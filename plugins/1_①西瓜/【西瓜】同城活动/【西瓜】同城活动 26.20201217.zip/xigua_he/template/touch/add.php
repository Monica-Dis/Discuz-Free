<?php exit('xigua_he'); ?>
<!--{template xigua_he:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd">
    <form action="$SCRITPTNAME?id=xigua_he&ac=add" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="form[id]" value="{$old_data[id]}">
        <input type="hidden" name="form[st]" value="{echo $old_data ? $old_data['stid'] : $_GET[st]}">
        <input type="hidden" name="form[catid]" value="{echo $old_data ? $old_data[catid] : $_GET[catid]}">
        <input type="hidden" id="lat" name="form[lat]" value="{$old_data['lat']}">
        <input type="hidden" id="lng" name="form[lng]" value="{$old_data['lng']}">
        <input type="hidden" id="province" name="form[province]" value="{$old_data['province']}">
        <input type="hidden" id="city" name="form[city]" value="{$old_data['city']}">
        <input type="hidden" id="district" name="form[district]" value="{$old_data['district']}">
        <input type="hidden" id="street" name="form[street]" value="{$old_data['street']}">
        <input type="hidden" id="street_number" name="form[street_number]" value="{$old_data['street_number']}">

        <div class="weui-cells__title">
            <!--{if $old_data}-->{lang xigua_he:bjhd}{$old_data[title]}<!--{else}--> $navtitle
            <!--{/if}-->
        </div>
        <div class="weui-cells ">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:title}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[title]" placeholder="{lang xigua_he:qtx}{lang xigua_he:title}" value="{$old_data[title]}">
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_he:starttime}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input time_ctrl" name="form[starttime]" type="text" placeholder="{lang xigua_he:qxz}{lang xigua_he:hdkssj}" value="{echo $old_data ? $old_data[start_u] : date('Y-m-d H:i');}">
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_he:endtime}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input time_ctrl" name="form[endtime]" type="text" placeholder="{lang xigua_he:qxz}{lang xigua_he:hdjssj}" value="{$old_data[end_u]}">
                </div>
            </div>
            <!--{if $sh}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:guanlian}</label></div>
                <div class="weui-cell__bd">
                    <input id="choose_sh" class="weui-input" name="form[shname]" type="text" value="{echo $old_data ? $old_data['shname'] : ''}" placeholder="{lang xigua_hs:qxzguanlian}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->
        </div>
        <div class="weui-cells__title">{lang xigua_he:hdsz}</div>
        <div class="weui-cells ">
            <!--{if $he_config[openjz]}-->
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_he:gyjk}</label></div>
                <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_he:gyjk_tip}</span></div>
                <div class="weui-cell__ft" style="height:32px">
                    <input onclick="return pzprice_field(this);" class="weui-switch" type="checkbox" name="form[jz]" value="1" <!--{if $old_data[jz]}-->checked<!--{/if}-->>
                </div>
            </div>
            <!--{/if}-->
            <div id="pzprice_field" class="weui-cell weui-cell_access"  onclick='$("#edit_price").popup();'>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:pzfy}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id="feiyong" readonly placeholder="{lang xigua_he:qszpz}" value="">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{if $he_config[allowtck]}-->
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_he:yxtk}</label></div>
                <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_he:yxtk_tip}</span></div>
                <div class="weui-cell__ft" style="height:32px">
                    <input class="weui-switch" type="checkbox" name="form[allow_tk]" value="1" <!--{if $old_data[allow_tk]}-->checked<!--{/if}-->>
                </div>
            </div>
            <!--{/if}-->
            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_he:xxdz}</label>
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" name="form[addr]" type="text" value="{$old_data[addr]}" placeholder="{lang xigua_he:qdjdw}">
                </div>
                <div class="weui-cell__ft">
                    <button class="weui-vcode-btn" id="openlocation" type="button">{lang xigua_hb:dingwei}</button>
                </div>
            </div>
            <div class="weui-cell" onclick=''>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:lxdh}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[tel]" value="{$old_data[tel]}"  placeholder="{lang xigua_he:qszlxdh}">
                </div>
            </div>
        </div>


        <div class="weui-cells__title">{lang xigua_he:spxq}</div>
        <div class="weui-cells ">

            <div class="weui-cell weui-cell_access" onclick='$("#edit_field").popup();'>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:bmsz}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id="edit_field_plc" value="{echo $old_data ? $needs : ''}" readonly placeholder="{lang xigua_he:qszbmbd}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>

            <div class="weui-cell weui-cell_access" onclick='$("#edit_jieshao").popup();'>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:spxq}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id="edit_jieshao_holder" value="{$old_data[jieshao]}" readonly placeholder="{lang xigua_he:djspxq}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_he:hdfm1}</p>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1">
                                <!--{if $old_data[fengmian]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[fengmian])"><input type="hidden" name="form[fengmian]" value="$old_data[fengmian]"/>
                                    <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/if}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[fengmian]" type="file" data-multi="1"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[fengmian]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_he:splbt}</p>
                            <div class="weui-uploader__info">{echo str_replace('n', $he_config['maximg'], lang_he('zuiduozhao',0))}
                            </div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{$he_config['maximg']}" data-maxtip="{echo str_replace('n', $he_config['maximg'], lang_he('zuiduozhao',0))}">
                                <!--{loop $old_data[album] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                                    <input type="hidden" name="form[album][]" value="$img"/>
                                    <div class="weui-uploader__file-content">
                                        <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="weui-cells__title">{lang xigua_he:hdbq}</div>
        <div class="weui-cells ">

            <!--{if $svicerange}-->
            <div class="weui-cell" style="padding-bottom:6px;">
                <div class="weui-cell__bd">
                    <div class="post-tags cl" id="post-typeid">
                        <!--{loop $svicerange $_rangk $_rangv}-->
                        <!--{eval list($_rangt, $_rangd) = explode("#", $_rangv);}-->
                        <a class="weui-btn weui-btn_mini weui-btn_default <!--{if in_array($_rangt, $old_data[srange_ary])}-->tag-on<!--{/if}-->" href="javascript:;" data-id="$_rangk">$_rangt</a>
                        <input name="form[tagid][{$_rangk}]" type="hidden" value="<!--{if in_array($_rangt, $old_data[srange_ary])}-->1<!--{else}-->0<!--{/if}-->">
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
            <!--{/if}-->
        </div>

        <label class="weui-agree mt10" onclick='$("#agree__text").popup();'>
            <input id="weuiAgree" type="checkbox" checked="checked" disabled readonly class="weui-agree__checkbox">
            <span class="weui-agree__text"> {lang xigua_hb:agree}<a href="javascript:void(0);" >{lang xigua_hb:xiyi1}</a> </span>
        </label>

        <div id="agree__text" class="weui-popup__container">
            <div class="weui-popup__overlay"></div>
            <div class="weui-popup__modal">
                <div class="fixpopuper">
                    <article class="weui-article">
                        <h1>{lang xigua_hb:xiyi}</h1>
                        <section>
                            {echo nl2br($he_config[xieyi]);}
                        </section>
                    </article>
                    <div class="footer_fix"></div>
                    <div class="bottom_fix"></div>
                </div>
                <div class="fix-bottom">
                    <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:woyi}</a>
                </div>
            </div>
        </div>

        <div class="fix-bottom mt10" style="position:relative">
            <!--{if $he_config['pubprice']>0}-->
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_he:zf}{$he_config['pubprice']}{lang xigua_he:yfb}"/>
            <!--{else}-->
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="<!--{if $old_data}-->{lang xigua_he:xiugai}<!--{else}-->{lang xigua_he:pub}<!--{/if}-->"/>
            <!--{/if}-->
            <a class="weui-btn weui-btn_default" href="javascript:window.history.go(-1);">{lang xigua_hb:back}</a>
        </div>


        <!--{template xigua_he:edit_jieshao}-->
        <!--{template xigua_he:edit_field}-->

    </form>
</div>

<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>

<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div class="masker" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);display:none;z-index:1000" onclick='$("#choose_sh").select("close");$(".choose_ctrl").select("close")'></div>
<script>
var itar = [], MAXTAG = '{echo intval($he_config[maxtag])}', MAXTAGTIP = "{eval echo str_replace('n', $he_config['maxtag'], lang_hb('zdng',0));}";
function cropCallback() {return false;}
function pzprice_field(obj){
    if($(obj).is(':checked')){
        $('#pzprice_field').hide();
    }else{
        $('#pzprice_field').show();
    }
    return true;
}
function edit_finish() {
    var plc = '';
    $('#namebox').find('.weui-check').each(function () {
        plc += $(this).data('name')+' ';
    });
    if(!plc){
        $.toast('{lang xigua_he:qszbmx}');
        return false;
    }
    $("#edit_field_plc").val(plc);
    $.closePopup();
    return cropCallback();
}
function edit_finisher(){
    $("#edit_jieshao_holder").val($('#jieshao').val());
    $.closePopup();
    return cropCallback();
}
$(document).on('click','#post-typeid a', function () {
    var that = $(this);
    if (that.hasClass('tag-on')) {
        that.removeClass('tag-on');
        $('input[name="form[tagid][' + that.data('id') + ']"]').val('0');
    } else {
        that.addClass('tag-on');
        $('input[name="form[tagid][' + that.data('id') + ']"]').val('1');
    }
});
<!--{if $sh}-->
var itar = [];
<!--{loop $sh $_sh}-->
itar.push({title:'{$_sh[name]}'});
<!--{/loop}-->
$("#choose_sh").select({
    title: "{lang xigua_hs:qxzguanlian}",
    items: itar,
    onOpen:function () {$('.masker').fadeIn();},
    beforeClose:function () {$('.masker').fadeOut(150);return true;}
});
<!--{/if}-->
</script>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$_G['cache']['plugin']['xigua_he']['mkey']}"></script>
<!--{if $_G['cache']['plugin']['xigua_he']['baidusdk']}--><script type="text/javascript" src="//api.map.baidu.com/api?v=2.0&ak={$_G['cache']['plugin']['xigua_he']['baidusdk']}"></script><!--{/if}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.min.js" charset="utf-8"></script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_he:footer}-->
<!--{template xigua_he:enter_up}-->
<!--{if $he_config[diquxuanz]}-->
<!--{eval
$_key = 'hscityIdist'.intval($_GET['st']);
loadcache($_key);
$jsary1 = $_G['cache'][$_key]['variable'][1];
if(!json_encode($jsary1) || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000)) :
    $GLOBALS['nojson'] = 0;
    $dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
    $list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
    C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
    $jsary1 = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    foreach ($dist0 as $index => $item) :
        C::t('#xigua_hb#xigua_hb_district')->empty_child();
        $dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
    endforeach;
    savecache($_key, array('variable' => array($dist0, $jsary1), 'expiration' => TIMESTAMP));
endif;
$jsary1 = array_values($jsary1);
$pickercityjson = json_encode($jsary1);
$pickerdefault = diconv($jsary1[0]['name'].' '. $jsary1[0]['sub'][0]['name'].' '.$jsary1[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
}-->
<script> +function ($) {$.rawCitiesData1 = $pickercityjson;}($);var DFTFIELD = '$pickerdefault';</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/picker.js?_{VERHASH}" charset="utf-8"></script>
<script>
$("#diqu").cityPicker1({
title: "{lang xigua_he:qxzsjdq}",
onChange: function (picker, values, displayValues) {
console.log(displayValues);
$('#needdiqu').html("<input type=\"hidden\" name=\"form[province]\" value=\"" + displayValues[0] + "\">\n" +
"<input type=\"hidden\" name=\"form[city]\" value=\"" + displayValues[1] + "\">\n" +
"<input type=\"hidden\" name=\"form[district]\" value=\"" + displayValues[2] + "\">");
}
});
</script>
<!--{/if}--><!--{if !$sh[0][name] && !$he_config[allowgr]}-->
<script>
$.alert("{lang xigua_he:noaccess1}", function() {
    hb_jump("$SCRITPTNAME?id=xigua_hs&ac=shcenter&mobile=2{$urlext}");
});
</script>
<!--{/if}-->