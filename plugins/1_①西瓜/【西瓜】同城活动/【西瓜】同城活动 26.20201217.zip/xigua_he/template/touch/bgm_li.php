<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class=" weui-cell weui-cell__access">
    <div class="weui-cell__hd bgm_user">
        <img class="bgm_avatar" src="{avatar($v['uid'], 'big', true)}">
    </div>
    <div class="weui-cell__bd">
        <ul class="lingqu_ul">
            <li>{$users[$v[uid]]['username']}</li>
            <li>{$v[pzinfo][pzname]}  <!--{if $v[pzinfo][price]}-->&yen;{$v[pzinfo][price]}<!--{/if}-->  </li>
            <!--{loop $v[bminfo] $_k $_v}-->
            <!--{if $_v[type]!='pics'}-->
            <li>{$_v[title]} : {$_v[html]}</li>
            <!--{/if}-->
            <!--{/loop}-->
        </ul>
    </div>
    <div class="weui-cell__ft">
        <div>
            <p>{$order_status[$v[status]]}</p>
            <p class="f12">{lang xigua_he:bmsj}: {$v[crts_u]}</p>
            <!--{if $v[pay_ts]}-->
            <p class="f12">{lang xigua_he:zfsj}: {$v[pay_ts_u]}</p>
            <!--{/if}-->
            <p>
                <!--{if in_array($v[status], array(5,7))}-->
                <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn bgf8 shbtn" data-id="{$v[id]}">{lang xigua_he:sh}</a>
                <!--{/if}-->
                <a href="$SCRITPTNAME?id=xigua_he&ac=order_profile&manage=1&bmid=$v[id]" class="weui-btn weui-btn_mini hm_c_btn bgf8 xqbtn mt0">{lang xigua_he:xq}</a>
            </p>
        </div>
    </div>
</div>
<!--{/loop}-->