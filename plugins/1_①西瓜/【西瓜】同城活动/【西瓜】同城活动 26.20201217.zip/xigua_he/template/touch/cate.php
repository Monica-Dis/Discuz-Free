<?php exit('xxx'); ?>
<!--{eval  $config[intopindex]=0;}-->
<!--{template xigua_he:header}-->
<style>.fixbanner_in .ajaxcat{min-width:28px}</style>
<!--{if $he_config[pindaologo]}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$he_config[pindaologo]" /></div><!--{/if}-->
<div class="page__bd ">

    <!--{if getcookie('miniprogram') && $ac=='index'}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
    <!--{if $ac=='index' && $config[showheader]}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
    <!--{if !$hide_nav}-->
    <header class="x_header bgcolor_11 cl  weui-flex f15" <!--{if $config[intopindex]}-->style="background:transparent!important;position:absolute"<!--{/if}-->>
    <!--{if $_G['cache']['plugin']['xigua_st']['showfz']}-->
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_he&mobile=2");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
    <!--{else}-->
    <a class="z x_logo" href="$SCRITPTNAME?id=xigua_hb"><!--{if strpos($config['logo'],'/')!==false}--><img src="$config[logo]" /> <!--{else}--><span style="margin:0 15px">$config[logo]</span><!--{/if}--></a><!--{/if}-->
    <form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
        <input type="hidden" name="id" value="xigua_he">
        <input type="hidden" name="ac" value="index">
        <!--{loop $_GET $lk $loopin}-->
        <input type="hidden" name="$lk" value="$_GET[$lk]">
        <!--{/loop}-->
        <input type="hidden" name="st" value="$_GET[st]">
        <input type="hidden" name="idu" value="$_GET[idu]">
        <input name="keyword" class="x_logo_input" type="text" value="{$_GET['keyword']}" placeholder="$he_config[indexkey]" x-webkit-speech="" <!--{if $config[intopindex]}-->style="background: rgba(255,255,255,.8)"<!--{/if}-->>
        <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
    </form>
    </header>
    <!--{if !$no_header_fix}-->
    <div class="x_header_fix" <!--{if $config[intopindex]&&$ac=='index'}-->style="display:none"<!--{/if}-->></div>
<!--{/if}-->
<!--{/if}-->


<div class="weui-cells__title"></div>
<div class="weui-grids bgf weui-grids-nob">
    <!--{loop $list $cat}-->
    <a <!--{if $he_config['numpd']!=4&&$he_config['numpd']>0}--> {eval echo "style='width:".(100/$he_config['numpd'])."%!important'";}<!--{/if}--> href="<!--{if  !$cat[cat_link]}-->$SCRITPTNAME?id=xigua_he&ac=cat&hyid=$cat[id]{$urlext}<!--{else}-->$cat[cat_link]<!--{/if}-->" class="weui-grid js_grid">
    <div class="weui-grid__icon">
        <img src="$cat[icon]" alt="$cat[name]">
    </div>
    <p class="weui-grid__label"> $cat[name] </p>
    </a>
    <!--{/loop}-->
</div>
</div>
<!--{eval $he_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_he:footer}-->