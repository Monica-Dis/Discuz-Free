<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="weui-cell">
    <div class="weui-cell__hd" style="position: relative;margin-right: 10px;">
        <img src="{avatar($v[uid], 'big', true)}" style="width:30px;height:30px;margin-right:5px;display:block;border-radius:50%" />
    </div>
    <div class="weui-cell__bd">
        <p>{$v[username]}
            <!--{if $v['hdinfo']['jz']}-->
            <em class="color-red2">{lang xigua_he:jzprice} &yen; {$v['pay_money']}</em>
            <!--{/if}-->
            <!--{if $v[numtotal]>1}-->
            <em class="">x {$v[numtotal]}</em>
            <!--{/if}--></p>
    </div>
    <div class="weui-cell__ft">
        {echo substr($v[crts_u], 5, 5);}
    </div>
</div>
<!--{/loop}-->
