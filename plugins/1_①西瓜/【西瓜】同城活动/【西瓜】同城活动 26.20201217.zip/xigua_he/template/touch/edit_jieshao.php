<?php exit('xxxx');?>

<div id="edit_jieshao" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__modal bgf8">
        <div class="fixpopuper">
            <div class="weui-cells__title">{lang xigua_he:bjsp}</div>
            <div class="weui-cells ">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <textarea class="weui-textarea" name="form[jieshao]" id="jieshao" placeholder="{lang xigua_he:hdjs}" rows="3">{$old_data[jieshao]}</textarea>
                    </div>
                </div>
            </div>

            <div class="weui-cells before_none nobg center_upload">
                <div class="weui-cell" id="first_append_img">
                    <div class="weui-cell__bd">
                        <div class="weui-uploader">
                            <div class="weui-uploader__bd">
                                <div class="weui-uploader__input-box">
                                    <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                    <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                    <!--{else}-->
                                    <input class="center_upload__input" data-name="form[append_img]" type="file">
                                    <!--{/if}-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!--{loop $old_data[append_text_ary] $__k $__v}-->
                <div class="weui-cell bgf" id="arear_{$__k}">
                    <ul id="cimg_{$__k}" data-only="1">
                        <li class="weui-uploader__file weui-uploader__file_status"
                            style="background-image:url({$old_data['append_img_ary'][$__k]})">
                            <input type="hidden" name="form[append_img][{$__k}]"
                                   value="{$old_data['append_img_ary'][$__k]}">
                            <div class="weui-uploader__file-content"><i
                                    class="weui-icon-warn iconfont icon-shanchu"></i></div>
                        </li>
                    </ul>
                    <div class="weui-cell__bd">
                        <textarea class="weui-textarea" placeholder="{lang xigua_hb:inputtext}" rows="3"
                                  name="form[append_text][{$__k}]">{$__v}</textarea>
                    </div>
                    <a class="iconfont icon-guanbijiantou closeHt" data-index="{$__k}"></a>
                </div>
                <div class="weui-cell" id="cell_{$__k}">
                    <div class="weui-cell__bd">
                        <div class="weui-uploader">
                            <div class="weui-uploader__bd">
                                <div class="weui-uploader__input-box">
                                    <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                    <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                    <!--{else}-->
                                    <input class="center_upload__input" data-name="form[append_img]" type="file">
                                    <!--{/if}-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--{/loop}-->
            </div>

            <div class="fix-bottom" id="center_upload_btn" style="position:relative">
                <a class="mt0 weui-btn weui-btn_default" onclick='return edit_finisher();'
                   href="javascript:;">{lang xigua_he:wcbj}</a>
            </div>
        </div>
    </div>
</div>
