<?php exit('xxxxxx');?>
<!--{eval
$avatar_img = avatar($_G['uid'], 'middle',  1, 0, 1);
$tmpfile = 'source/plugin/xigua_he/cache/'.md5($avatar_img).'1.png';
if(0&& strpos($avatar_img, $_G[siteurl])===false):
    if(!is_file(DISCUZ_ROOT.$tmpfile)):
        file_put_contents(DISCUZ_ROOT.$tmpfile, file_get_contents($avatar_img));
    endif;
endif;

$fm = $v['fengmian'];
if(strpos($fm, $_G[siteurl])===false):
    $tmpfile1 = 'source/plugin/xigua_he/cache/'.md5($fm).'.png';
    if(!is_file(DISCUZ_ROOT.$tmpfile1)):
        file_put_contents(DISCUZ_ROOT.$tmpfile1, file_get_contents($fm));
    endif;
endif;
}-->
<div id="shot" style="position:absolute;top:-100000px">
<div class="yqk">
    <img class="bg" src="source/plugin/xigua_he/static/img/hbbg.jpg" />
    <img class="cov" src="{$tmpfile1}" onerror="this.src='$fm';this.error=null;"/>
    <div class="ava">
        <img src="{$avatar_img}">
    </div>
    <div class="huser">
        <p class="main_color">{$_G[username]}</p>
        <p>{lang xigua_he:gntjl}</p>
    </div>
    <div class="hprice">
        <span class="main_color2"><!--{if $v[pricerange]}-->{$v[pricerange]}{lang xigua_he:yuan}<!--{else}-->{lang xigua_he:mf}<!--{/if}--></span>
        <!--{if $v[hkpricerange]}-->
        <span class="lis_hksp hkp">{$_G[cache][plugin][xigua_hk][cardname]}{lang xigua_he:jia}{$v[hkpricerange]}{lang xigua_he:yuan}</span>
        <!--{/if}-->
    </div>
    <div class="ytitle">
        {$v['title']}
    </div>
    <div class="ydesc">
        <div>
            <span>{lang xigua_he:bmsj}:</span>
            <span>{echo substr($v[bstart_u], 5)}</span>
            <!--{if $v[bend_u]}-->
            <span>{lang xigua_he:z}</span>
            <span>{echo substr($v[bend_u], 5)}</span>
            <!--{else}-->
            <span>{lang xigua_he:ks}</span>
            <!--{/if}-->
        </div>
        <div>
            <span>{lang xigua_he:hdsj}:</span>
            <span>{echo substr($v[start_u], 5)}</span>
            <!--{if $v[end_u]}-->
            <span>{lang xigua_he:z}</span>
            <span>{echo substr($v[end_u], 5)}</span>
            <!--{else}-->
            <span>{lang xigua_he:ks}</span>
            <!--{/if}-->
        </div>
        <!--{if $v[addr] || $v[district]}-->
        <div>
            <span>{lang xigua_he:hddd}:</span>
            <span>{$v[city]}{$v[district]}{$v[street]}$v[addr]</span>
        </div>
        <!--{/if}-->
    </div>

    <div class="yqr">
    <!--{if $_G['cache']['plugin']['xigua_hx'] && IN_PROG}-->
    <!--{eval include_once 'source/plugin/xigua_he/include/c_xcx.php';}-->
        <img src="$shqr">
    <!--{else}-->
        <img src="$SCRITPTNAME?id=xigua_he:qrcode&hid=$hid&qrcode=1{$urlext}" />
    <!--{/if}-->
        <p>{lang xigua_he:casb}</p>
    </div>
    <div class="main_color ylogo">{$he_config[indextitle]}</div>
</div>
</div>

<script>
function he_newewm(){
    $.showLoading();
    html2canvas(document.querySelector(".yqk")).then(canvas => {
        var dataURL = canvas.toDataURL();
        COMCLAS = 'shot_outer';
        $.hideLoading();
        $.alert("<img src='" + dataURL + "' />", '{lang xigua_he:cabc}');
        $('.weui-dialog__title').css('font-size', '14px');
        COMCLAS = '';
    });
    share_incr();
    return false;
}
if("undefined" === typeof menuShareCommon) {
    function menuShareCommon(){ share_incr(); }
}
if("undefined" === typeof menuShareTimeline) {
    function menuShareTimeline(){ share_incr(); }
}
function share_incr(){
    $.ajax({
        type: 'post',
        url: _APPNAME +'?id=xigua_he&ac=incr&incr_type=shares&hid=$hid&inajax=1',
        data: {'formhash': FORMHASH},
        dataType: 'xml'
    });
}
</script>