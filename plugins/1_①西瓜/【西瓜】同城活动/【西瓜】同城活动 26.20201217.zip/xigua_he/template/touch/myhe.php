<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_he:header}-->
<!--{eval $keyword = $_GET['keyword'];}-->
<style>
    .weui-search-bar__cancel-btn{font-size:16px}
    .search_bar_btn{margin-left: 10px;line-height: 28px;white-space: nowrap;display:none;font-size:16px}
    .weui-search-bar.weui-search-bar_focusing .search_bar_btn { display: block}
    .weui-search-bar__form{background: transparent}
    .weui-search-bar__box{background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAFoAAABaCAYAAAA4qEECAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAALEgAACxIB0t1+/AAAABZ0RVh0Q3JlYXRpb24gVGltZQAwOS8wNi8xOLnuRBwAAAAcdEVYdFNvZnR3YXJlAEFkb2JlIEZpcmV3b3JrcyBDUzbovLKMAAAH4klEQVR4nO2d+W8SQRTH38xCkaMpFmyKJcb+VrSt0tQD4hHU1CP+uR4VDzxCrZV0KyFpfzCaKK3a2wpWLHT8oaHpNW8PZnYX5PvrDjs7Hx4zs++9eRDGGFitXC7HyuUybG5uQrVaBd4zEELA5XKB1+sFv98Po6OjxOJHFSZiBej379+zlZUV2NraEnI/t9sNoVAILly40DTgpYFWVZV9//4dqtWqlPvX5XK5oLe3F+LxuKOhCwc9OTnJlpeXudOBLBFCIBwOw+XLlx0JXBhoVVXZwsICbG9vC7mfWVFK4eTJk46zcCGgx8fHmaj5V5RcLhfcvXvXMbAbAp3NZtnq6qrAxxGvYDAIV69etR24adBPnjxhf//+NfVZt9sNgUAAgsEgDA4OohAKhQJbX1+HUqlketfidrvhzp07tsI2BfrRo0esVqvp74QQ8Pv9kEqlhAw2k8mwcrlsaMGllEJ/fz+cOXPGFuCGQOfzefblyxfdA6SUQiQSgZGRESmDU1WVffv2DfR+6YQQ6Ovrs2Wh1A16ZmaGFYtFXZCtXvnz+TwrFou6gUciEcvfMnWBNgK5q6sLrl27ZsvP08gePhqNWmrZukA/ePCAabVTFAXu3btn++oOoG+7SQiB+/fvOwe0noXP6/XCrVu3HAG5rkwmw0qlEtrGSuNAQT99+pT9+fMHvcHx48fhypUrjoJc18TEBFtZWUHbeDweGBsbk/78lHfh7du3mpBDoZBjIQMAJJNJEg6H0TaVSgWy2ax0xwwXtJYlhEIhSCaTjoVcVyKRIKFQCG2zuroKs7OzUmEfCfr58+fo4hcIBJoCcl3JZJIEAgG0zdevX6U+wyHQqqqy379/cz/gdruFveFZqVQqRTweD/d6pVKBXC4nzaoPgf7x4we3MSEETp8+LetZpGtsbIwQwreRpaUlaX3vA53L5dD9Z1dXFwwMDDSdNe8VNl9Xq1V49+6dFKveBxpzebpcLke4GxtVIpEgHR0d3Otra2tS+t0FXSgUWKVS4TY8ceKElAewQ5FIhHtta2sL8vm8cKveBb28vMxt5Ha7mzrUf1DDw8PowoixMKtd0NhOQ2vT34zq7u7mXtvc3BTeHwXY2dLx/BmKorSUNdc1OjpKFEU58tr29jaoqip0+qAAABsbG9wGfr9fZH+OEvYSgzExIwqA/1S0Xl+bWdgCj02lZkQBgJtNpCiKZvC0mRWLxbjTh5GYqB7RQqHA9Wtg+81WEW+MjDH48OGDsHmaYs7xY8eOierHscLGWC6XhfVDsdwMn88nrCOnChujyARNit3M6/UK68ipwlIhLAMdi8VadiHUI6GgeQshpdzgS8uJN1aRqcdcmpjfttVkxVj/H7O1WVzQdhwisktWjJVijpX/Rbyx8tiYEcUWvUKh0PJmjaUZiNwQUOw1W4Zf1mnCxijSBUGxSMP/ABpzQWBsjIpiPlmtlLBWEDZGraQbI6KxWIzw5iKnnbSSId7bH6VU6JsxBdhJJThKMkI6TlI+n+eG8HhMzIoC4M4jWXkOThCWxyLaoUYBrI8IO0VYuApjYkYUAGBwcJBg08fk5GTLTR+5XA6dNkSH8HZXQSza3YrTB5YkIyPyvwu6p6eH20hm8p8d0krmxFiY1S7ogYEBgoV1tE4ANJMwa/Z4PFIyZvdtoLFvslarwatXr5reqrPZLGrNvb29UvrdB3poaIhgUeGNjQ2YmZlpWthzc3MMW288Hg8MDw9LiQIceiWMRqPoBxYWFmQ8hyX69OkT6nvG0nkb1SHQsVgMPVhTq9UgnU43nVWn02n0YKrP54OhoSFpMa0jnRypVIqbKgWwc7Amk8k0DexMJoMm2RNC4ObNm1IDh1zPttbPqFQqNQXsN2/eaB5VtuI0Axd0PB7XPJtXKpXgxYsXjoX98uVLtr6+jrbx+/1w6dIl+44oA2ifzQPYyU8bHx93HOx0Os1+/fqFtlEUBW7cuGH/ofu69FQ4oJRCNBqFc+fO2ZoQMjs7yz5//qw77TYcDkMikZD+zLor0Oip2QGws3rLXlh4ev36Nfv586fhz1kBWzfoubk59vHjR105EIQQCIVCllgKAMDU1BRbWlpqKEVCNmzDVcIePnzI9A6IEALBYFBaqYlsNsvW1taEJcDIrNhgqhzb48ePmdFMS1EVcqenp9ni4qLheCYhRNcXIgu26QKDz549Y2ajL4SQ3SKDPp+PW0SqXmmhXlzQ7LPWSxHpLcIlA3ZDJTOnpqbY4uKiY/P0CCHQ09MDFy9e3IVmF2whRWAbKZ8pSx0dHXD79u0jQdkBW1hZY6P7V1lSFAX6+/s1czKshi28UHc+n2fz8/PSK6EflMvlglOnTsHZs2d1Q7ESttQa/2aKtRoRIQQ6Ozvh+vXrpiFYBduSP1MA2HHwlMvlhvOuFUWBzs5OoUVarIBtGeiDqm/d9sKvz+91X7iiKOD3+8Hr9UqvIyobtm2gnShVVVmxWNRsZwZ2+7DQHsXjcaIVMwXYSb2YmJgwZKFt0AckC3Yb9BGSAbsNmiPRsNugEYmE3QatIVGw26B1SATsNmidahR2G7QBNQK7Ddqg4vE46evr02x3EHYbtAmNjIwYht32dTSg6elpNj8/r9muu7u7bdGNSI9l1/+QrQ26QWGwCSEQjUbh/PnzpA1agI6CvRcyQHsxFKa9sA9CBmgvhsKlqiqjlB7Kqv0HrBwj5VaL/jMAAAAASUVORK5CYII=) 10px center no-repeat;background-size: 16px}
</style>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_he&ac=myhe&status=2" class="weui-navbar__item <!--{if !$_GET[endts] &&$_GET[status]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:jxz}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=myhe&status=-1" class="weui-navbar__item <!--{if $_GET[status]==-1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:dsh}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=myhe&status=2&endts=1" class="weui-navbar__item <!--{if $_GET[endts]==1&&$_GET[status]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:yjs}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=myhe&status=-2" class="weui-navbar__item <!--{if $_GET[status]==-2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_he:yxj1}</span>
        </a>
    </div>


    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">

            <input name="id" value="xigua_he" type="hidden">
            <input name="ac" value="myhe" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <input type="hidden" name="status" value="$_GET[status]">
            <input type="hidden" name="endts" value="$_GET[endts]">

            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_he:spmc}" data-hold="{lang xigua_he:qtx}{lang xigua_he:spmc}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_he:spmc}</span>
            </label>
        </form>
        <a href="javascript:" class="search_bar_btn main_color" id="dosearch">{lang xigua_he:search}</a>
        <a href="$SCRITPTNAME?id=xigua_he&ac=myhe&status={$_GET[status]}&endts={$_GET[endts]}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_he:qx}</a>
    </div>


    <div id="list" class="mod-post x-postlist p0">

    </div>

    <!--{template xigua_hb:loading}-->
</div>
<a href="$SCRITPTNAME?id=xigua_he&ac=chosecat" class="float_btn main_bg"><i class="iconfont icon-zengjia"></i> {lang xigua_he:new_evt}</a>

<script>var loadingurl = window.location.href+'&ac=myhe_li&is_my=1&inajax=1&page=';</script>
<!--{eval $tabbar=0;$he_tabbar=0;}-->
<!--{template xigua_he:footer}-->
<script>
$(document).on('click','.shangxijia', function () {
    var acmod = [];
    var that = $(this);
    var gid = that.data('gid');
    if(that.data('type')=='shang'){
        acmod.push({ text: '{lang xigua_he:sj}', onClick: function(){
                $.showLoading();
                $.ajax({
                    type: "POST",
                    url: _APPNAME+"?id=xigua_he&ac=com&do=sxj&stat=2&inajax=1&hid="+gid,
                    async: false,
                    dataType: "xml",
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    }
                });
            } }
        );
    }
    if(that.data('type')=='xia') {
        acmod.push({ text: '{lang xigua_he:xj}', onClick: function () {
                    $.showLoading();
                    $.ajax({
                        type: "POST",
                        url: _APPNAME + "?id=xigua_he&ac=com&do=sxj&stat=-2&inajax=1&hid=" + gid,
                        async: false,
                        dataType: "xml",
                        success: function (data) {
                            $.hideLoading();
                            if (null == data) {
                                tip_common('error|' + ERROR_TIP);
                                return false;
                            }
                            var s = data.lastChild.firstChild.nodeValue;
                            tip_common(s);
                        }
                    });
                }
            }
        );
    }
    acmod.push({ text: '{lang xigua_he:qx}', className: "default", onClick: function(){ console.log(3)} });
    $.modal({
        title: that.data('title'),
        text: that.data('text'),
        buttons: acmod
    });
});

$(document).on('click','#dosearch', function () {
    if($('#searchInput').val()){
        $('#dosearchform').submit();
    }else{
        $.alert($('#searchInput').data('hold'));
    }
});
</script>