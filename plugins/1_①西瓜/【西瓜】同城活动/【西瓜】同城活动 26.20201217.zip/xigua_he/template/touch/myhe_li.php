<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="dis_list">
    <div class="dis_row jump_he" data-id="{$v[id]}">
        <div class="dis_pic">
            <img src="{echo $v[fengmian] ? $v[fengmian]: $v[album][0]}">
            <div class="dis_mask"><div class="title">{$v[title]}</div></div>
            <span class="righttopcard">
                <span><i class="iconfont icon-browse f12"></i>$v[views]</span>
                <span><i class="iconfont icon-fenxiang1 f12"></i>$v[shares]</span>
                <span><i class="iconfont icon-shoucang1 f12"></i>$v[favs]</span>
            </span>
        </div>
        <div class="dis_pir weui-flex">
            <div class="weui-flex__item">
                <p class="price">
                    <span class="ptcolor">
                    <em class="f12">{lang xigua_he:ybm}{$v[joins]}{lang xigua_he:r}</em></span>
                    <span class="f12 gray y"><!--{if $v[start_u] || $v[end_u]}-->{$v[start_u]}{lang xigua_he:z}{$v[end_u]}<!--{else}-->{lang xigua_he:bx}<!--{/if}--></span>
                </p>
            </div>
        </div>
    </div>
    <div class="button-sp-area">
        <a href="$SCRITPTNAME?id=xigua_he&ac=add&hid={$v[id]}" class="weui-btn weui-btn_mini hm_c_btn bgf8">{lang xigua_he:xiugai}</a>
        <!--{if $v[jumpurl]}-->
        <a class="weui-btn weui-btn_mini mt0" href="{$v[jumpurl]}">{lang xigua_he:ljzf}</a>
        <!--{else}-->
        <a href="$SCRITPTNAME?id=xigua_he&ac=bgm&hid={$v[id]}" class="weui-btn weui-btn_mini hm_c_btn bgf8">{lang xigua_he:tichengmanage}</a>
        <!--{if $_GET[status]==-2}-->
        <a href="javascript:;" data-gid="{$v[id]}" data-type="shang" data-title="{lang xigua_he:sj}" data-text="$v[title]" class="weui-btn weui-btn_mini hm_c_btn bgf8 shangxijia">{lang xigua_he:sj}</a>
        <!--{elseif $_GET[status]==2}-->
        <a href="javascript:;" data-gid="{$v[id]}" data-type="xia" data-title="{lang xigua_he:xj}" data-text="$v[title]<br>{lang xigua_he:xjhwf}" class="weui-btn weui-btn_mini hm_c_btn bgf8 shangxijia">{lang xigua_he:xj}</a>
        <!--{/if}-->
        <!--{/if}-->
    </div>
</div>
<!--{/loop}-->