<?php exit('xxxxxxx');?>
<!--{eval $showkh = 0;}-->
<!--{if $_G['cache']['plugin']['xigua_hk']}-->
<!--{eval $card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G[uid]); }-->
<!--{/if}-->
<div id="pay_ctrl" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_he:qx}</a>
                <h1 class="title">{lang xigua_he:wybm}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <div class="weui-cell f14" <!--{if $v[jz]}-->style="display:none"<!--{/if}-->>
                    <div class="weui-cell__bd">
                        <div class="pay_tags cl">
<!--{loop $v[pzname] $_k $_v}-->
<!--{eval
$dingjin = 0;
$datap = $v[pzprice][$_k];

if($card && $v[pzhkprice][$_k]>0):
    $datap = $v[pzhkprice][$_k];
endif;

if($v[d_price][$_k]>0):
    $datap = $v[d_price][$_k];
    $dingjin = 1;
endif;
if($card && $v[hk_d_price][$_k]>0):
    $datap = $v[hk_d_price][$_k];
    $dingjin = 1;
endif;

}--><div class="aa weui-btn weui-btn_mini weui-btn_default <!--{if $_k==0}-->main_color<!--{/if}-->" href="javascript:;"
data-price="{$datap}" data-k="{$_k}" data-pzmin="{$v[pzmin][$_k]}" data-pzmax="{$v[pzmax][$_k]}">
        <div class="z">{$_v}</div>
        <div class="y cl">
            <span class="main_color">&yen;{echo floatval($v[pzprice][$_k])}</span>
            <!--{if $v[pzhkprice][$_k]>0}-->
            <!--{eval $showkh = 1;}-->
            <em class="hksp pr-1">{$_G['cache']['plugin']['xigua_hk']['cardname']}{lang xigua_he:jia} &yen;{echo floatval($v[pzhkprice][$_k])}</em>
            <!--{/if}-->
            <!--{if $dingjin}-->
            <em class="hksp pr-1 dj">{lang xigua_he:dj} &yen;{echo floatval($datap)}</em>
            <!--{/if}-->
        </div>
    </div>
<!--{/loop}-->
                        </div>
                    </div>
                </div>
                <!--{if $v[jz]}-->
                <div class="weui-cell f14 before_none">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_he:jzprice}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" id="jzpt" type="tel" onkeyup="changeJzPrice();" placeholder="{lang xigua_he:jzprice_tip}" value="">
                    </div>
                    <div class="weui-cell__ft">{lang xigua_hb:yuan}</div>
                </div>
                <!--{/if}-->
                <div class="weui-cell f14">
                    <div class="weui-cell__bd">
                        <p>{lang xigua_he:xzsl}</p>
                    </div>
                    <div class="weui-cell__ft">
                        <i class="iconfont icon-jianshao2 inc-num" data-step="-1"></i>
                        <input class="inc-input" type="tel" name="item_num" id="item_num" value="1" readonly="readonly" />
                        <i class="iconfont icon-tianjia1 inc-num" data-step="1"></i>
                        <span id="item_num_tip"></span>
                    </div>
                </div>


                <div class="weui-agree" style="margin-bottom: 20px;">
                    <input id="weuiAgree" name="agree__text" type="checkbox" checked="checked" class="weui-agree__checkbox">
                    <span class="weui-agree__text">{lang xigua_he:ydhd} <a id="hdsm" href="javascript:void(0);">{lang xigua_he:hdsm}</a></span>
                </div>

            </div>

            <!--{if $_G['cache']['plugin']['xigua_hk']}-->
                <!--{if $showkh && !$card}-->
                <div class="kklink">
                    <i class="iconfont icon-huiyuan2 main_color f12"></i>
                    {lang xigua_he:kt}{$_G['cache']['plugin']['xigua_hk']['cardname']},{lang xigua_he:cjljx}
                    <a class="y main_color" href="$SCRITPTNAME?id=xigua_hk&ac=join{$urlext}">{lang xigua_he:ljkt} &raquo;</a>
                </div>
                <!--{/if}-->
            <!--{/if}-->

            <div class="fix-bottom fix_next">
                <div class="weui-flex">
                    <div class="weui-flex__item">{lang xigua_he:heji} <span class="mony main_color">&yen; <em id="money_show">0</em></span>
                    </div>
                    <div class="weui-flex__item tc next_step main_bg">
                        <a href="javascript:;" id="next_btn">{lang xigua_he:xyb}</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div id="agree__text" style="display:none">{echo nl2br($he_config[hdxy]);}</div>
<script>
$(function () {
    var isPageHide = false;
    window.addEventListener('pageshow', function () {
        if (isPageHide) {
            window.location.reload();
        }
    });
    window.addEventListener('pagehide', function () {
        isPageHide = true;
    });
});
function setSpgg(id, obj) {
    var par = $(obj).parent();
    var tgo = par.find('.tag-on');
    if(tgo.length> 0){
        tgo.removeClass('tag-on');
        par.find('input').val('0');
    }

    if ($(obj).hasClass('tag-on')) {
        $(obj).removeClass('tag-on');
        $('#gginput').val('');
    } else {
        $(obj).addClass('tag-on');
        $('#gginput').val(id);
    }
}
var clickLock = 0;
$(document).on('click','.buynow', function () {
    if(clickLock){
        return;
    }
    clickLock = 1;
    $('#pay_ctrl').popup();
    setTimeout(function () {
        clickLock = 0;
    }, 100);
});

$(document).on('click','.inc-num', function () {
    var that = $(this);
    var topv = $('.aa.main_color');
    var ipt = that.parent().find('.inc-input');
    var num = parseInt(ipt.val());
    if(parseInt(that.data('step'))===1){
        if (!topv.data('pzmax') || num <topv.data('pzmax')) {
            ipt.val(++num);
        }
    }else{
        if (!topv.data('pzmin') || num>topv.data('pzmin')) {
            if (num > 1) {
                ipt.val(--num);
            }
        }
    }
    if(typeof incNumCallback !=='undefined'){
        incNumCallback();
    }
});
function incNumCallback(){
    var ipt = $('#item_num');
    var nuu = parseInt(ipt.val());
    var topv = $('.aa.main_color');
    var pzprc = topv.data('price');
    var lastp = parseFloat(pzprc * nuu);
    console.log(lastp);
    $('#money_show').html(lastp);
    if(topv.data('pzmax')){
        $('#item_num_tip').html('{lang xigua_he:mrx}'+topv.data('pzmax')+'{lang xigua_he:gme}');
    }
    $('#next_btn').attr('data-href', '$SCRITPTNAME?id=xigua_he&ac=next&hid=$hid<!--{if $v[jz]}-->&jzp='+$('#jzpt').val()+'<!--{/if}-->&num='+nuu+'&typ='+topv.data('k')+'{$urlext}');
}
$(document).on('click','.aa', function () {
    var that = $(this);
    that.parent().find('.aa').removeClass('main_color');
    that.addClass('main_color');
    $('#item_num').val(that.data('pzmin'));
    incNumCallback();
});
incNumCallback();
$(document).on('click','#hdsm', function () {
    $.alert($('#agree__text').html(), '{lang xigua_he:hdsm}');
});
$(document).on('click','#next_btn', function () {
    <!--{if $v[jz]}-->changeJzPrice();<!--{/if}-->
    if($('#weuiAgree:checked').length<=0){
        $.alert('{lang xigua_he:qydhds}');
    }else{
        hb_jump($(this).data('href'));
    }
});
<!--{if $v[jz]}-->
function changeJzPrice() {
    var obj = $('#jzpt');
    obj.val(obj.val().replace(/\./g,''));
    if(obj.val()>0){
        $('.aa').data('price', obj.val());
        incNumCallback();
        clearInterval(setJz);
    }
}
var setJz = setInterval(function(){
    changeJzPrice();
}, 100);
<!--{/if}-->
</script>