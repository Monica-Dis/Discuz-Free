<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_he:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <ul class="helist mt0" id="list" style="padding-top:0"> </ul>
    <!--{template xigua_hb:loading}-->
</div>

<script>
    var loadingurl = _APPNAME+'?id=xigua_he&ac=he_li&fav=1&inajax=1&page=';
</script>
<!--{eval $tabbar=0;$he_tabbar=1}-->
<!--{template xigua_he:footer}-->