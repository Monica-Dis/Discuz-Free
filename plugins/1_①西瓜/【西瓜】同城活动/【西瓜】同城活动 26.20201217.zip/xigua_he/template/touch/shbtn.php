<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<script>
    $(document).on('click', '.shbtn', function () {
        var acmod = [];
        var that = $(this);
        var gid = that.data('id');
        acmod.push({
                text: '{lang xigua_he:shtg}', onClick: function () {
                    $.showLoading();
                    $.ajax({
                        type: "POST",
                        url: _APPNAME + "?id=xigua_he&ac=com&do=shenhe&stat=2&inajax=1&bmid=" + gid,
                        data:{formhash:FORMHASH},
                        dataType: "xml",
                        success: function (data) {
                            $.hideLoading();
                            if (null == data) {
                                tip_common('error|' + ERROR_TIP);
                                return false;
                            }
                            var s = data.lastChild.firstChild.nodeValue;
                            tip_common(s);
                        }
                    });
                }
            }
        );
        acmod.push({
                text: '{lang xigua_he:shjj}', onClick: function () {
                    $.showLoading();
                    $.ajax({
                        type: "POST",
                        url: _APPNAME + "?id=xigua_he&ac=com&do=shenhe&stat=7&inajax=1&bmid=" + gid,
                        data:{formhash:FORMHASH},
                        dataType: "xml",
                        success: function (data) {
                            $.hideLoading();
                            if (null == data) {
                                tip_common('error|' + ERROR_TIP);
                                return false;
                            }
                            var s = data.lastChild.firstChild.nodeValue;
                            tip_common(s);
                        }
                    });
                }
            }
        );
        acmod.push({
            text: '{lang xigua_he:qx}', className: "default", onClick: function () {
                console.log(3)
            }
        });
        $.modal({
            title: that.data('title'),
            text: that.data('text'),
            buttons: acmod
        });
    });

</script>
