<?php exit('xigua_he');?>
<!--{template xigua_he:header}-->
<!--{if $he_config[toptip]}--><div class="weui-cells__title">$he_config[toptip]</div><!--{/if}-->
<div class="weui-cells__title">{lang xigua_he:xuanlei}</div>
<div class="weui-grids bgf weui-grids-nob">
    <!--{loop $list $cat}-->
    <!--{if $he_config[pubhide] && $cat[cat_link]}-->
    <!--{eval continue;}-->
    <!--{/if}-->
    <a <!--{if $he_config['numi2']!=4&&$he_config['numi2']>0}--> {eval echo "style='width:".(100/$he_config['numi2'])."%!important'";}<!--{/if}--> <!--{if  !$cat[cat_link]}-->onclick="return showcat('$cat[id]', '$cat[name]');"<!--{else}-->href="$cat[cat_link]"<!--{/if}--> class="weui-grid js_grid">
    <div class="weui-grid__icon">
        <img src="$cat[icon]" alt="">
    </div>
    <p class="weui-grid__label"> $cat[name] </p>
    </a>
    <!--{/loop}-->
</div>

<div class="footer_fix"></div>
<div class="bottom_fix"></div>

<script>
    var CAT = [];
    <!--{loop $list $cat}-->
    <!--{if $cat[child]}-->
    <!--{loop $cat[child] $c}-->
    CAT.push({pid:'$c[pid]', id:'$c[id]', name:'$c[name]'});
    <!--{/loop}-->
    <!--{/if}-->
    <!--{/loop}-->
    <!--{if $_GET[ct]}-->
    var ct = '';
    for(var i =0; i<CAT.length; i++){
        if(CAT[i].id=='$_GET[ct]'){
            ct = CAT[i].name
        }
    }
    showcat('$_GET[ct]', ct);
    <!--{eval $pub0 = "$SCRITPTNAME?id=xigua_he&ac=add&ct=$_GET[ct]";}-->
    <!--{/if}-->
    function showcat(id, name){
        var act = [];
        for(var i =0; i<CAT.length; i++){
            if(CAT[i].pid==id){
                var surl = '$SCRITPTNAME?id=xigua_he&ac=add&catid='+CAT[i].id+_URLEXT;
                act.push({text: '<a class="sel_a" href="'+surl+'">'+CAT[i].name+'</a>'});
            }
        }
        console.log(act);
        if(act.length==0){
            window.location.href = '$SCRITPTNAME?id=xigua_he&ac=add&catid='+id+_URLEXT;
            return false;
        }
        $.actions({
            title: '{lang xigua_he:fabu0}'+name+'',
            actions: act
        });
        return false;
    }

</script>
<!--{eval $he_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_he:footer}-->