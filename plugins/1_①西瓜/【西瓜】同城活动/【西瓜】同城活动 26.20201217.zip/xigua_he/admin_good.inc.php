<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_he/function.php';

$he_huodong = C::t('#xigua_he#xigua_he_huodong');

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$statuss = array(
 2=> lang_he('ysj',0),
 -1=> lang_he('dsh',0),
 -2=> lang_he('yxj',0),
);
$pzfield = array('pzname', 'pzprice', 'pzhkprice', 'pznum', 'pzshenhe', 'pzmin', 'pzmax', 'pzhhr1', 'pzhhr2', 'chengben_price','d_price', 'hk_d_price');

$he_config = $_G['cache']['plugin']['xigua_he'];
$svicerange = array();
foreach (explode("\n", trim($he_config['svicerange'])) as $index => $item) {
    $svicerange[] = trim($item);
}
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_he/static/admincp.css?1243\" />";
if($secid = intval($_GET['secid'])){

    $res = $he_huodong->fetch($secid);
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $res = array (
                'status' => '2',
                'uid' => '0',
                'title' => '',
                'shid' => '0',
                'catid' => $_GET['catid'],
                'starttime' => TIMESTAMP,
                'endtime' => '0',
                'bstarttime' => TIMESTAMP,
                'bendtime' => '0',
                'tel' => '',
                'fengmian' => '',
                'jieshao' => '',
                'bdfield' => '',
                'required' => '',
                'album' => 'a:0:{}',
                'views' => '0',
                'shares' => '0',
                'joins' => '0',
                'favs' => '0',
                'allow_tk' => '0',
                'tuijian' => '0',
                'displayorder' => '0',
                'lat' => '',
                'lng' => '',
                'province' => '',
                'city' => '',
                'district' => '',
                'street' => '',
                'street_number' => '',
                'addr' => '',
                'showbm' => '1',
                'shname' => '',
                'allnum' => '0',
                'pricerange' => '0',
                'hkpricerange' => '0',
                'dig_endts' => '0',
                'dig_startts' => '0',
                'srange' => '',
                'order_id' => '',
                'stid' => '0',
                'crts' => TIMESTAMP,
                'upts' => TIMESTAMP,
                'append_img' => 'a:0:{}',
                'append_text' => 'a:0:{}',
                'pzname' => 'a:1:{i:0;s:0:"";}',
                'pzprice' => 'a:1:{i:0;s:4:"0.00";}',
                'pzhkprice' => 'a:1:{i:0;s:4:"0.000";}',
                'pznum' => 'a:1:{i:0;s:0:"";}',
                'pzshenhe' => 'a:1:{i:0;s:1:"0";}',
                'pzmin' => 'a:1:{i:0;s:1:"1";}',
                'pzmax' => 'a:1:{i:0;s:1:"5";}',
            );
            $neww = 1;
        }

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&secid=$secid", 'enctype');
        showtableheader(); /*Dism_taobao-com*/
        showtitle(lang_he('spgl',0) . ($secid>0?$secid:''). "&nbsp;&nbsp;<a class='abtn' href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good'> ".lang_he('back',0)."</a>");


        $bdvars = array();
        foreach (he_vars($res['catid']) as $index => $bdvar) {
            $bdvars['f_'.$bdvar['pluginvarid']] = $bdvar['title'];
        }
        $bmfield = $bdvars;

        foreach ($res as $index => $re) {
            if(in_array($index, array('allnum' ,'id','shname', 'pricerange', 'hkpricerange','required','pzprice', 'pzhkprice','pznum','pzshenhe','pzmin','pzmax','pzhhr1','pzhhr2', 'chengben_price','d_price', 'hk_d_price'))){
                continue;
            }

            $listinfo = C::t('#xigua_he#xigua_he_cat')->list_all(1);
            C::t('#xigua_he#xigua_he_cat')->init($listinfo);
            $cat_list = C::t('#xigua_he#xigua_he_cat')->get_tree_array(0);
            $hangye = "<select name=\"editform[catid]\">";
            foreach ($cat_list as $k => $v) {
                $hangye .= "<option ".($res['catid']== $v['id'] ? 'selected': '')." value=\"$v[id]\">$v[name]</option>";
                foreach ($v['child'] as $kk => $vv) {
                    $s = '';
                    if($res['catid']== $vv['id']){
                        $s = 'selected';
                    }
                    $hangye .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;---$vv[name]</option>";
                }
            }
            $hangye .= '</select>';

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('crts', 'upts', 'starttime', 'bstarttime', 'endtime', 'bendtime','dig_startts','dig_endts'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('shid'))){
                $cs = '<select name="editform[shid]">';
                foreach (DB::fetch_all('select shid,`name` from %t WHERE display=1 AND endts>=%d ORDER BY shid asc', array(
                    'xigua_hs_shanghu',
                    TIMESTAMP
                ), 'shid') as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['shid']} {$c['name']}</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('thumb'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('showbm' ,'tuijian','showdis', 'selfdis', 'orderdis', 'newp', 'allow_tk','baoyou_type','jz'))){
                $tp = 'radio';
            }elseif(in_array($index, array('srange'))){
                $re = explode("\t", $re);
                $cs = '<select name="editform[srange][]" multiple="multiple">';
                foreach ($svicerange as $__v) {
                    $shortv = explode('#', $__v);
                    $shortv = $shortv[0];
                    $s = '';
                    if(in_array($shortv, $re)){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$shortv'>$shortv</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('catid'))){
                $tp = $hangye;
            }

            if(in_array($index, array('fengmian'))){
                $tp = 'filetext';
            }
            if (in_array($index, array('album', 'append_img', 'append_text'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $sp_config = $_G['cache']['plugin']['xigua_he'];
                $loopnum = $sp_config['maximg'];
                if ($index == 'append_text') {
                    $tp = 'text';
                }
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_he($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'customtxt'){
                $tp = 'textarea';
                $cmt = lang_he('customtxttip',0);
                showsetting(lang_he($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }elseif($index == 'bdfield'){
                $re_ary = unserialize($re);
                $required_ary = unserialize($res['required']);
                $tp = 'textarea';

                $tp = '';
                $shengxiao = lang_he('shengxiao',0);
                $bitian = lang_he('bitian',0);
                foreach ($bmfield as $_index => $_item) {
                    $bcheck = $re_ary[$_index]? 'checked' : '';
                    $rcheck = $required_ary[$_index]? 'checked' : '';
                    $tp .= "<p class='pli'><span>$_item</span> <label><input type='checkbox' name='editform[bdfield][$_index]' value='1' $bcheck />$shengxiao</label> ";
                    $tp .= " <label><input type='checkbox' name='editform[required][$_index]' value='1' $rcheck />$bitian</label> ";
                    $tp .= "</p>";
                }
                showsetting(lang_he($index.'desc', 0), "editform[$index]", $res[$index] , $tp, '', 0, $cmt, $_extra);

            }elseif($index == 'pzname'){
                $pzname_ary = unserialize($re);

                $tp = '';
                foreach ($pzname_ary as $i => $item) {
                    $tp .= "<table class='pztable' id=\"pzname_table_$i\">";
                    $j = 0;
                    foreach ($pzfield as  $pzvar) {
                        $j++;
                        $jv = '';
                        if($i>0){
                            if($j==1){
                                $jv = '<a href="javascript:;" onclick="delPz(this)">X</a>';
                            }
                        }else{
                            if($j==1){
                                $jv = '<a href="javascript:;" markdel>X</a>';
                            }
                        }

                        $pz_var_ary = unserialize($res[$pzvar]);
                        if($pzvar =='pzshenhe'){
                            $ch1 = $pz_var_ary[$i]?'selected' :'';
                            $ch2 = !$pz_var_ary[$i]?'selected' :'';
                            /*$chvar = "<input type='radio' name='editform[$pzvar][]' value='1' $ch1 />".cplang('yes');
                            $chvar .= " <input type='radio' name='editform[$pzvar][]' value='0' $ch2 />".cplang('no');*/
                            $yyes = cplang('yes');
                            $nno = cplang('no');
                            $chvar = "<select name='editform[$pzvar][]'><option value='1' $ch1>$yyes</option><option value='0' $ch2>$nno</option></select>";
                            $tp .= " <tr><td>".lang_he($pzvar, 0). "</td> <td>$chvar</td><td> $jv </td> </tr> ";
                        }else{
                            $tp .= "<tr><td>".lang_he($pzvar, 0). "</td> <td> <input type='text' class='txt' name='editform[$pzvar][]' value='{$pz_var_ary[$i]}' /></td> <td> $jv </td> </tr> ";
                        }
                    }
                    $tp .= '</table>';
                }
                $xzpz = lang_he('xzpz',0);
                $tp .= '<div id="newpz"></div><a href="javascript:;" class="abtn mt10 ib" onclick="addPz();">'.$xzpz.'</a>';

                showsetting(lang_he($index.'desc', 0), "editform[$index]", $res[$index] , $tp, '', 0, $cmt, $_extra);
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_he($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                showsetting(lang_he($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach (array('crts', 'upts', 'starttime', 'endtime', 'bstarttime', 'bendtime') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        $editform['jieshao'] = ($editform['jieshao']);
        $editform['append_text'] = array_slice($editform['append_text'], 0, count($editform['append_img']));

        foreach (array('album', 'append_text', 'append_img') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }

        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($editform['shid']);
        if(!$sh){
            cpmsg(lang_he('shnotexists',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&secid=$secid", 'error');
        }

        $editform['shname']     = $sh['name'];
        $editform['shid']       = $sh['shid'];



        $srg = array();
        foreach ($editform['srange'] as $index => $item) {
            list($_rangt, $_rangd) = explode("#", $item);
            $srg[] = $_rangt;
        }
        $editform['srange']     = implode("\t", $srg);


        $minhp = floatval(min($editform['pzprice']));
        $maxhp = floatval(max($editform['pzprice']));
        if(!$maxhp){
            $editform['pricerange'] = $minhp==$maxhp ? $minhp : 0;
        }else{
            $editform['pricerange'] = $minhp==$maxhp ? $minhp : ($minhp).'-'.$maxhp;
        }

        $minhp = floatval(min($editform['pzhkprice']));
        $maxhp = floatval(max($editform['pzhkprice']));
        if(!$maxhp){
            $editform['hkpricerange'] = $minhp==$maxhp ? $minhp : 0;
        }else{
            $editform['hkpricerange'] = $minhp==$maxhp ? $minhp : $minhp.'-'.$maxhp;
        }

        $editform['allnum'] = array_sum($editform['pznum']);
        foreach ($pzfield as $index => $item) {
            $editform[$item] = serialize($editform[$item]);
        }
        $editform['bdfield'] = serialize($editform['bdfield']);
        $editform['required'] = serialize($editform['required']);
        if(!$editform['bstarttime']){
            $editform['bstarttime'] = TIMESTAMP;
        }
        if($secid>0){
            $rs = $he_huodong->update($secid, $editform);
            $hid = $secid;
        }else{
            $hid = $he_huodong->insert($editform, 1);
        }

        cpmsg(lang_he('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&secid=$hid", 'succeed');
    }
}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            $he_huodong->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            $he_huodong->update($id, array('displayorder' => $item['displayorder'], 'status' => $item['status'], 'tuijian' => intval($item['tuijian'])));
        }

        cpmsg(lang_he('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey(addslashes($keyword))) {
        $wherearr[] = " (title LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR append_text LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }
    if($_GET['catid']){
        $wherearr[] = 'catid=' . intval($_GET['catid']);
    }

    $ob = ' displayorder DESC, id desc';

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_he('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($statuss as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good".' class="btn" >'.cplang('reset').'</a> ';
//    echo " </div>";
    echo " <a style=\"background:#4caf50\" href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_cat\" class=\"btn\">".lang_he('tjsp',0)."</a></div>";

    showtableheader(lang_he('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_he('del', 0),
        lang_he('displayorder', 0),
        lang_he('thumb', 0),
        lang_he('title', 0),
        lang_he('author', 0),
        lang_he('hsname', 0),
        lang_he('jxhd', 0),
        lang_he('spzt', 0),
        lang_he('caozuo', 0),
        lang_he('crendts', 0),
    ));

    $res = $he_huodong->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = $he_huodong->fetch_count_by_page($wherearr);

    $shids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $shids[$v['shid']] = $v['shid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($shids){
        $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $shid = $v['shid'];
        $thumb = $v['fengmian'] ? $v['fengmian'] : ($v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0]);
        $stat = lang_he('jxz',0);
        if($v['not_start']){
            $stat =lang_he( 'wks',0);
        }elseif ($v['isend']){
            $stat = lang_he('yjs',0);
        }
        if($v['stock']<=0){
            $stat = lang_he('ysw',0);
        }


        $checked = $v['display'] ? 'checked' : '';

        $appeend = '';
        foreach ($v['append_img_ary'] as $__k => $__v) {
            $appeend .= "<p><img style='width:180px;display:block' src=\"{$__v}\" /></p>";
            $appeend .= "<p>" . nl2br($v['append_text_ary'][$__k]) . "</p>";
        }

        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($statuss as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        $jx_u = "<select name=\"row[$id][tuijian]\">";
        $jx_u .= "<option ".($v['tuijian'] ? 'selected': '')." value=\"1\">".cplang('yes')."</option>";
        $jx_u .= "<option ".(!$v['tuijian'] ? 'selected': '')." value=\"0\">".cplang('none')."</option>";
        $jx_u .= '</select>';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input type='text' name='row[$id][displayorder]' value='{$v['displayorder']}' style='width:50px' />",
            "<img src='$thumb' style='width:70px;height:40px' />",
            "<p style='font-size:15px;color:#369'>{$v['title']}</p><p style='color:coral'>{$v['subtitle']}</p>",
            '<em>[UID:'.$v['uid'].']</em><br> '.$users[$v['uid']]['username'],
            "<a target='_blank' href='".ADMINSCRIPT."?action=plugins&operation=config&do=&identifier=xigua_hs&pmod=admin_shanghu&shid=".$v['shid']."'>".$shinfos[$v['shid']]['name'].'</a>',


            $jx_u,
            $status_u,

            '<a class=\'abtn\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&secid=$id" . '">' . lang_he('edit', 0) . '</a> '.
        '',
            $v['crts_u'],
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_he&pmod=admin_good&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/

    /*echo '<pre>';
    print_r($res);
    echo '</pre>';*/
}
?>
<script>
    function addPz(){
        var div1 = document.createElement('table');
        div1.setAttribute('class', 'pztable');
        div1.setAttribute('id', '');
        div1.innerHTML = document.getElementById('pzname_table_0').innerHTML.replace('markdel', 'onclick="delPz(this)"');
        document.getElementById('newpz').appendChild(div1);
    }
    function delPz(obj){
        obj.parentNode.parentNode.parentNode.remove();
    }
</script>
