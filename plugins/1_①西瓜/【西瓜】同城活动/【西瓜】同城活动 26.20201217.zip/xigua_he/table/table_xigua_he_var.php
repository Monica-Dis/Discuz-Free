<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_he_var extends discuz_table
{
    public function __construct() {

        $this->_table = 'xigua_he_var';
        $this->_pk    = 'pluginvarid';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function fetch_all_by_pluginid($pluginid) {
        return DB::fetch_all("SELECT * FROM %t WHERE pluginid=%s ORDER BY displayorder", array($this->_table, $pluginid), $this->_pk);
    }
    public function count_by_pluginid($pluginid) {
        return DB::result_first("SELECT COUNT(*) FROM %t WHERE pluginid=%s %i", array($this->_table, $pluginid, "AND (`type` NOT LIKE 'forum\_%' AND `type` NOT LIKE 'group\_%')"));
    }

    public function update_by_variable($pluginid, $variable, $data) {
        DB::update($this->_table, $data, DB::field('pluginid', $pluginid).' AND '.DB::field('variable', $variable));
    }

    public function update_by_pluginvarid($pluginid, $pluginvarid, $data) {
        DB::update($this->_table, $data, DB::field('pluginid', $pluginid).' AND '.DB::field('pluginvarid', $pluginvarid));
    }

    public function check_variable($pluginid, $variable) {
        return DB::result_first("SELECT COUNT(*) FROM %t WHERE pluginid=%s AND variable=%s", array($this->_table, $pluginid, $variable));
    }

    public function delete_by_pluginid($pluginid) {
        DB::delete($this->_table, DB::field('pluginid', $pluginid));
    }

    public function delete_by_variable($pluginid, $variable) {
        DB::delete($this->_table, DB::field('pluginid', $pluginid).' AND '.DB::field('variable', $variable));
    }

}