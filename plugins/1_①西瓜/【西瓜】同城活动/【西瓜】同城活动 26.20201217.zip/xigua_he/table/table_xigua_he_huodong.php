<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class table_xigua_he_huodong extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_he_huodong';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first('select * from %t WHERE id=%d AND uid=%d', array(
            $this->_table,
            $id,
            $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }

    public function fetch_is_G(){
        global $_G;
        $r = DB::fetch_first('select * from %t WHERE uid=%d LIMIT 1', array(
            $this->_table,
            $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false)
    {
        $good_id = parent::insert($data, true, $replace, $silent);
        return $good_id;
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }
    public function fetch_count_by_where($wherearr)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if(!is_array($wherearr) && $wherearr){
            $wheresql = "WHERE ".$wherearr;
        }
        $result = DB::result_first("SELECT count(*) as cnt FROM " . DB::table($this->_table) . " $wheresql ");
        return $result;
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'views DESC', $fields= '*')
    {
        global $_G,$he_config;
        if($he_config['hdfz']){
            if(is_array($wherearr) && !defined('IN_ADMINCP')){
                $wherearr[] = 'stid='.intval($_GET['st']);
                if(!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']){
                    array_pop($wherearr);
                }
            }
        }
        if($_GET['gtype']=='he'){
            $wherearr[] = 'hkpricerange!=\'0\'';
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            if($v['album']){
                $v['album'] = unserialize($v['album']);
            }
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['start_u'] = $v['starttime'] ? date('Y-m-d H:i', $v['starttime']) : '';
            $v['end_u'] =  $v['endtime'] ? date('Y-m-d H:i', $v['endtime']) : '';
            $v['bstart_u'] = $v['bstarttime'] ? date('Y-m-d H:i', $v['bstarttime']) : '';
            $v['bend_u'] =  $v['bendtime'] ? date('Y-m-d H:i', $v['bendtime']) : '';

            $v['append_img_ary'] = unserialize($v['append_img']);
            $v['append_text_ary'] = unserialize($v['append_text']);
            $v['bdfield'] = unserialize($v['bdfield']);
            $v['required'] = unserialize($v['required']);
            $v['srange_ary'] = array_filter(explode("\t", trim($v['srange'])));

            foreach ($GLOBALS['pzfield'] as $index => $item) {
                $v[$item] = unserialize($v[$item]);
            }
            if($v['status']==-1 && $v['order_id']){
                global $_G,$SCRITPTNAME,$urlext;
                $order_id = $v['order_id'];
                $rl = urlencode($_G['siteurl'].$SCRITPTNAME."?id=xigua_he&ac=myhe$urlext");
                $v['jumpurl'] = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
            }
            $v['bhasend'] = $v['bendtime']>0 && $v['bendtime']<TIMESTAMP;
            $v['hasend'] = $v['endtime']>0 && $v['endtime']<TIMESTAMP;

            if($v['bhasend']||$v['hasend']){
                DB::query('UPDATE %t SET displayorder=-99 WHERE id=%d', array(
                    'xigua_he_huodong', $v['id']
                ));
            }
            if($v['displayorder']==-99 && !($v['bhasend']||$v['hasend'])){
                DB::query('UPDATE %t SET displayorder=0 WHERE id=%d', array(
                    'xigua_he_huodong', $v['id']
                ));
            }
            if($_GET['ac']=='view'&&$v['xuniuid']){
                $v['joins'] += substr_count($v['xuniuid'],',')+1;
            }
        }
        return $v;
    }

    public function fetch_by_id($secid){
        $rs = parent::fetch($secid);
        $this->incr($secid, 'views');
        /*if(submitcheck('jid')) {
            if ($rs['stock'] < 1) {
                hb_message(lang_hd('kcbz', 0), 'error');
            }
        }*/
        if($_GET['ac']=='next'){
            global $shid;
            $shid = $rs['shid'];
            unset($rs['jieshao']);
            unset($rs['album']);
            unset($rs['append_img']);
            unset($rs['append_text']);
            if($rs['status']!=2){
                global $errmsg;
                $errmsg = he_message(lang_he('hdyjs',0), 'error');
                return false;
            }
        }
        return $this->prepare($rs);
    }

    public function incr($pubid, $field, $num = 1)
    {
        if(strpos($pubid, ',')!==false){
            $pubid = dintval(array_filter(explode(',', $pubid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $pubid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $pubid));
        }
    }

    public function updateStock($secid, $num = 1)
    {
        DB::query('update %t set stock=stock-%d WHERE '.$this->_pk.'=%d AND stock>=%d', array(
            $this->_table,
            $num,
            $secid,
            $num,
        ));
        return DB::affected_rows();
    }

    public function fetch_by_ids($ids, $fields='*', $key_field = '')
    {
        $rs = DB::fetch_all("SELECT $fields FROM %t WHERE id IN (%n)", array(
            $this->_table,
            $ids
        ), $key_field ? $key_field : $this->_pk);
        foreach ($rs as $index => $r) {
            $rs[$index] = self::prepare($r);
        }
        return $rs;
    }

    public function get_order($viewtype)
    {
        global $he_config;
        $field = '*';
        switch ($viewtype){
            case "new":
                $order_by = 'dig_endts DESC, id DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                switch ($he_config['digorder']){
                    case '3':
                        $order_by = 'distance ASC, dig_startts DESC, dig_endts DESC';
                        break;
                    case '2':
                        $order_by = 'distance ASC, dig_endts DESC';
                        break;
                    default:
                        $order_by = 'distance ASC, (dig_endts-dig_startts) DESC';
                        break;
                }
                break;
            case 'guanzhu':
                $order_by = 'favs DESC';
                break;
            case 'fenxiang':
                $order_by = 'shares DESC';
                break;
            case 'starttime':
                $order_by = 'starttime ASC';
                break;
            default:
                switch ($he_config['digorder']){
                    case '3':
                        $order_by = ' dig_startts DESC, dig_endts DESC, displayorder DESC, views DESC ';
                        break;
                    case '2':
                        $order_by = 'dig_endts DESC, displayorder DESC, views DESC';
                        break;
                    default:
                        $order_by = ' (dig_endts-dig_startts) DESC, displayorder DESC, id DESC ';
                        break;
                }
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }
}