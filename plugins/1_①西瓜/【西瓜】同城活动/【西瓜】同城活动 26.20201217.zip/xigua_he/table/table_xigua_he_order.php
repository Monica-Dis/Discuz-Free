<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019
 * Time: 17:30
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * Class table_xigua_he_order
 */
class table_xigua_he_order extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_he_order';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false) {
        if(!defined('IN_ADMINCP') && count($data)==2 && $data['pay_ts'] && in_array($data['status'], array(2,5))){
            $v = C::t('#xigua_he#xigua_he_order')->fetch($val);
            $v['hdinfo'] = $huodong = unserialize($v['hdinfo']);
            if($v['hdinfo']['jz']){
                $data['status'] = 6;
                $data['hxuid'] = $v['uid'];
                $data['hxcrts'] = TIMESTAMP;
                $money = $v['pay_money'];
                if($money>0){
                    global $SCRITPTNAME;
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid' => $huodong['uid'],
                        'crts' =>TIMESTAMP,
                        'size' => $money,
                        'note' => $v['title'].lang_he('kcsxf',0).'0;'.lang_he('rz',0).$money,
                        'link' => "$SCRITPTNAME?id=xigua_he&ac=order_profile&bmid={$v['id']}&manage=1",
                    ));
                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($huodong['uid'], 'money', $money);
                }
            }
        }
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        return DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first('select * from %t WHERE id=%d AND uid=%d', array(
            $this->_table,
            $id,
            $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*', $need_user = 0, $need_sh = 0)
    {
        global $_G, $SCRITPTNAME,$urlext;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($wherearr && !is_array($wherearr)){
            $wheresql =' WHERE '.$wherearr;
        }
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $groupby = '';
        if($GLOBALS['ac']=='baoming_li' || $GLOBALS['ac']=='view'){
            global $hid,$he_huodong,$huodongv;
            if(!$huodongv['jz']){
                $groupby = ' GROUP BY uid';
            }
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $groupby $orderby " . DB::limit($start_limit, $lpp));

        $uids = $shids = array();

        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $uids[] = $item['uid'];
            $shids[] = $item['shid'];
        }
        if($need_user && $uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['username'] = $users[$item['uid']]['username'];
            }
        }
        if(($need_sh||$GLOBALS['need_sh']) && $shids){
            $shs = DB::fetch_all('SELECT shid,`name`,logo FROM %t WHERE shid IN (%n)', array('xigua_hs_shanghu', $shids), 'shid');
            foreach ($result as $index => $item) {
                $result[$index]['sh'] = $shs[$item['shid']];
            }
        }
        if($start_limit == 0 && ($GLOBALS['ac']=='baoming_li' || $GLOBALS['ac']=='view')) {
            global $hid;
            $uuus = array();
            $huod = DB::fetch_first("SELECT xuniuid,bstarttime,crts FROM %t where id=%d", array('xigua_he_huodong', $hid));
            $xuniuids = $huod['xuniuid'];
            $bstarttime = $huod['bstarttime'];
            $crts = $huod['crts'];
            if ($xuniuids && $bstarttime <= TIMESTAMP) {
                $xuniuids = explode(',', $xuniuids);
                $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $xuniuids), 'uid');
                foreach ($users as $index => $user) {
                    $uuus[] = array(
                        'crts_u' => date('Y-m-d H:i:s', max($bstarttime, $crts) + mt_rand($crts, 100)),
                        'numtotal' => 1,
                        'uid' => $user['uid'],
                        'username' => $user['username'],
                    );
                }
                if ($uuus) {
                    $result = array_merge($result, $uuus);
                }
            }
        }
        return $result;
    }
    public function fetch_count_by_where($wherearr)
    {
        $wheresql = !empty($wherearr) ? (is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : ' WHERE '.$wherearr) : '';
        if(!is_array($wherearr) && $wherearr){
            $wheresql = "WHERE ".$wherearr;
        }
        $result = DB::result_first("SELECT count(*) as cnt FROM " . DB::table($this->_table) . " $wheresql ");
        return $result;
    }
    public function fetch_sum_by_where($field, $wherearr)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if(!is_array($wherearr) && $wherearr){
            $wheresql = "WHERE ".$wherearr;
        }
        $result = DB::result_first("SELECT sum($field) as cnt FROM " . DB::table($this->_table) . " $wheresql ");
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*', $groupby = '')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        if($groupby){
            $groupby = "GROUP BY $groupby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby $groupby" . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_by_bmid($gid)
    {
        $ret = $this->fetch($gid);
        $ret = self::prepare($ret);
        return $ret;
    }

    public function check_allow_refund($v)
    {
        return in_array($v['status'], array(1, 2, 5)) && !$v['hxcrts'] && (($v['hdinfo']['allow_tk']&&$v['pay_money']) || !$v['pay_money']) /*&& $v['starttime']>TIMESTAMP*/;
    }

    public function fetch_by_orderid($gid)
    {
        $return = array();
        $ret = $this->fetch($gid);
        if($ret['order_id']){
            $return = $this->fetch_all_by_array(array('order_id' => $ret['order_id']),0,99);
        }
        return $return;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        global $_G, $SCRITPTNAME,$urlext;
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i:s', $v['crts']) : '';
            $v['pay_ts_u'] = $v['pay_ts']>0 ? date('Y-m-d H:i:s', $v['pay_ts']) : '';
            $v['hdinfo'] = unserialize($v['hdinfo']);
            $v['bminfo'] = unserialize($v['bminfo']);
            $v['pzinfo'] = unserialize($v['pzinfo']);
            $v['pzmoney'] = floatval($v['pzmoney']);
            $v['pay_money'] = floatval($v['pay_money']);
            $v['pz_preprice'] = floatval($v['pz_preprice']);

            if($v['status'] == 1){
                $order_id = $v['order_id'];
                $rl = urlencode($_G['siteurl'].$SCRITPTNAME."?id=xigua_he&ac=order_profile$urlext&bmid=".$v['id']);
                $v['jumpurl'] = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
            }
        }
        return $v;
    }
}