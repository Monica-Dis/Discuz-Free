<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{if $_GET['is_my'] || $_GET['is_admin']}--><!--{template xigua_hb:mypub_item}--><!--{else}--><!--{if $list}--><div class="flow_bbs_over"><!--{loop $list $k $v}-->
<div class="flow-bbs-card flow-card <!--{if $v[wancheng]}-->op6<!--{/if}-->">
  <aside class="img-box view_jump" data-id="$v[id]">
  <img style="height:50vw" src="{echo $v[video_cover] ? $v[video_cover] : $v[img_preview][0]}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'">
<!--{if $v['video_cover'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
<img class="video_c_img" style="position:absolute;width:2rem;height:2rem" src="source/plugin/xigua_hb/static/img/vp.png" >
<!--{/if}-->
  <!--{if $cats[$v[catid]][name]}-->
  <span>{$cats[$v[catid]][name]}</span>
  <!--{/if}-->
  </aside>
  <main class="content-box <!--{if $v[wancheng]}-->pr<!--{/if}-->">
    <p class="title view_jump" style="height:2.1rem" data-id="$v[id]"><!--{if $v[dig_on]}--><em class="mod-lv is-star" style="margin-left:0">{lang xigua_hb:zhiding}</em><!--{/if}-->{echo cutstr(str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v[description]))), 80);}</p>
    <div class="other-box">
      <a href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]" class="author">
        <i class="avatar" style="background: url({avatar($v[uid], 'middle', true)}) center center / 100% no-repeat;"></i>
        <span class="name">{$users[$v[uid]][username]}</span> </a>
      <div class="nums">{echo hb_trans2($v[views]);}</div>
    </div>
<!--{if $v[wancheng]}--><div class="wxexpired1" style="position: absolute;top: 0;left: 0;right: 0;bottom: 0;background-position: right top;background-color: rgba(255,255,255,.7);"></div><!--{/if}-->
  </main>
</div>
<!--{/loop}--></div><!--{/if}--><!--{/if}-->