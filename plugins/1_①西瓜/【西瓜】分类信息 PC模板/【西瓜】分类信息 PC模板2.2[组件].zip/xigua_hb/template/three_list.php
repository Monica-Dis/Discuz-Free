<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{eval $_v[vars] = array_values($_v[vars]); $top3 = array_slice($_v[vars], 0, 3); $top3cnt = count($top3);}-->
<a href="{echo hb_pc_rewriteoutput('view_page', $_v[id])}" target="_blank"  class="item" >
    <div class="item-title ellipsis <!--{if !$top3}-->towrow<!--{/if}-->">{echo strip_tags($_v[description])}</div>
    <p class="job-requirement ellipsis">
        <!--{loop $top3 $__k $__v}-->
        <!--{if !$__v[html]}-->
        <!--{eval continue;}-->
        <!--{/if}-->
        <span>$__v[html]</span>
        <!--{if $__k<$top3cnt-1}-->
        <em class="vline"></em>
        <!--{/if}-->
        <!--{/loop}-->
    </p>
    <p class="job-compnay ellipsis">{$newlist_cat_all[$_v[catid]][name]}</p>
    <div class="job-salary-box">
        <!--{if $_v[vars][0][html]}-->
        <div class="salary-container" >
            <span class="salary">{echo cutstr(str_replace(' ', '', $_v[vars][0][html]), 14)}</span>
        </div>
        <!--{else}-->{echo $_v[realname]!='-' ? $_v[realname]:''}{$_v[time_u]}{lang xigua_hb:fabu0}
        <!--{/if}-->
        <!--{if $_v[tags][0]}-->
        <span class="bao-tag"><em>{$_v[tags][0]}</em></span>
        <!--{/if}-->
    </div>
</a>
