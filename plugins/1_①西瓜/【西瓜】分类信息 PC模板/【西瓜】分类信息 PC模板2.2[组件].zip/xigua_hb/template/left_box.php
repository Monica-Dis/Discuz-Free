<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="infoblock">
    <!--{if $catinfo['adimage']}-->
    <a href="{eval echo $catinfo['adlink'] ? $catinfo['adlink'] : hb_pc_rewriteoutput('cat_page', $cat_id)}"  target="_blank"  class="recently-browse zp-daoliu-bg c-blocka"><img style="width:100%" src="$catinfo['adimage']" class="block" /></a>
    <!--{elseif $hb_setting[catmiddle]}-->
    <a href="$hb_setting[catmiddle_link]"  target="_blank"  class="recently-browse zp-daoliu-bg c-blocka"><img style="width:100%" src="$hb_setting[catmiddle]" class="block" /></a>
    <!--{/if}-->
    <!--{if $hb_setting[appqrcode]}-->
    <div class="infowraper clearfix">
        <img class="qrcode erwei z" src="{$hb_setting[appqrcode]}" alt="">
        <div class="inlineblock tips1 z">
            <p>{$hb_setting[appname]}</p>
            <p>{$hb_setting[apptext]}</p>
        </div>
    </div>
    <!--{/if}-->
    <!--{if $ac =='view' && $likeslist}-->
    <div class="sidebar-filter safe-tip">
        <div class="title">{lang xigua_hb:xsxx}
            <a href="{echo hb_pc_rewriteoutput('cat_page', $likeslist[0][catid])}" class="y txt txt-link-more" style="display: inline-block;padding-right: 8px;margin: 0;background-position:right 8px">{lang xigua_hb:more}</a>
        </div>
        <div>
            <!--{loop $likeslist $_k $_v}-->
            <a class="recentitem" href="{echo hb_pc_rewriteoutput('view_page', $_v[id])}" target="_blank">
                <img src="{$_v[imglist][0]}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" alt="">
                <div class="jobher ">
                    <span class="timu inlineblock">{echo strip_tags($_v[description])}</span><span class="qian inlineblock">{$_v[time_u]}</span>
                </div>
                <div class="gongsi">{$_v[realname]}</div>
            </a>
            <!--{/loop}-->
        </div>
    </div>
    <!--{else}-->
    <div class="sidebar-filter safe-tip">
        <div class="title"><i class="iconfont icon-jubao2 color-red2"></i> {lang xigua_hb:aqxts}</div>
        <p class="sidebar-filter-block">
            $hb_setting[aqxts]
        </p></div>
    <!--{/if}-->
</div>