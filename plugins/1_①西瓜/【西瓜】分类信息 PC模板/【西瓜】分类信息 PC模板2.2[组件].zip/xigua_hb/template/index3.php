<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
    <div class="main home-content" <!--{if $hb_setting[pictoppic]}-->style="background-image:url($hb_setting[pictoppic])"<!--{/if}-->>
        <div class="inner home-inner">
            <div class="search-box ">
                <div class="search-form clearfix ">
                    <div  class="clearfix">
                        <div class="search-form-con">
                            <div class="position-sel search-form-ele">
                                <i class="line"></i><span class="label-text search-form-ele"><em class="search-form-ele" id="searchv">{lang xigua_hb:xinxi}</em><i class="icon more-down-icon"></i></span>
                                <div class="industry-box">
                                    <ul>
                                        <li><a href="javascript:;" data-id="xigua_hb" data-ac="cat" data-txt="{lang xigua_hb:xinxi}">{lang xigua_hb:xinxi}</a></li>
                                        <li><a href="javascript:;" data-id="xigua_hs" data-ac="hangye" data-txt="{lang xigua_hb:shj}">{lang xigua_hb:shj}</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="ipt-wrap">
                            <form class="z x_form" id="searchForm" method="get" action="$SCRITPTNAME">
                                <input type="hidden" name="id" value="xigua_hb">
                                <input type="hidden" name="ac" value="cat">
                                <input type="hidden" name="st" value="$_GET[st]">
                                <input type="hidden" name="idu" value="$_GET[idu]">
                                <input type="text" name="keyword" autocomplete="off" maxlength="50" placeholder="$config[sousuoinput]" value="" class="ipt-search search-form-ele">
                            </form>
                            </div>
                            <div class="search-btn">
                                <i class="icon search-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<!--{eval for($i=1; $i<=10; $i++):
$key1 = 'tonglan'.$i;
$key2 = 'tonglan_link'.$i;
}-->
<!--{if $hb_setting[$key1]}-->
<a href="$hb_setting[$key2]" target="_blank"><img src="$hb_setting[$key1]" style="width:1200px;margin: 0 auto;display: block;"></a>
<!--{/if}-->
<!--{eval endfor;$i=0;}-->
        <div class="inner home-inner page-core clearfix" style="margin-top:10px">
            <div class="left job-classify" <!--{if $hb_setting[leftcolor]}-->style="background:{echo $hb_setting[leftcolor]=='#000000'? $config[maincolor] : $hb_setting[leftcolor]}"<!--{/if}-->>
                <!--{loop $cat_tree_all $_k $_v}--><!--{eval
$ii++;
$ij = 0;
if($ii>10):
    break;
endif;
}-->
                <div class="box">
                    <div class="first-item">
                        <a href="{echo $_v[cat_link] ? $_v[cat_link] : hb_pc_rewriteoutput('cat_page', $_v[id], $cityauto)}" class="query-item">$_v[name]</a>
                        <!--{if !$hb_setting[hidecat]}-->
                        <!--{loop $_v[child] $__k $__v}-->
                        <a href="{echo $__v[cat_link] ? $__v[cat_link] : hb_pc_rewriteoutput('cat_page', $__v[id], $cityauto)}" class="query-item">$__v[name]</a>
                        <!--{/loop}-->
                        <!--{/if}-->
                    </div>
                    <div class="job-menu-sub" style="top:{echo $i*40;}px;height:auto">
                        <div class="popover">
                            <i class="popover-left-triangle" style="top:5px;left:-35px;"></i>
                            <!--{eval $i++;}-->
                        </div>
                        <ul>
                            <li class="clearfix">
                                <div class="head-txt">$_v[name]</div>
                                <div class="text">
                                    <!--{if !$_v[child]}-->
                                    <a href="{echo $_v[cat_link] ? $_v[cat_link] : hb_pc_rewriteoutput('cat_page', $_v[id], $cityauto)}" class="job-classify-btn">$_v[name]</a>
                                    <!--{else}-->
                                    <!--{loop $_v[child] $__k $__v}-->
                                    <a href="{echo $__v[cat_link] ? $__v[cat_link] : hb_pc_rewriteoutput('cat_page', $__v[id], $cityauto)}" class="job-classify-btn">$__v[name]</a>
                                    <!--{/loop}-->
                                    <!--{/if}-->
                                </div>
                            </li>
                            <!--{loop $cat_tree_all $tmp_k $tmp_v}-->
                            <!--{if $tmp_k==$_v[id]}-->
                            <!--{eval continue;}-->
                            <!--{/if}--><!--{eval
$ij++;
if($ij>0):
    break;
endif;
}-->
                            <li class="clearfix">
                                <div class="head-txt">$tmp_v[name]</div>
                                <div class="text">
                                    <!--{if !$tmp_v[child]}-->
                                    <a href="{echo $tmp_v[cat_link] ? $tmp_v[cat_link] : hb_pc_rewriteoutput('cat_page', $tmp_v[id], $cityauto)}" class="job-classify-btn">$tmp_v[name]</a>
                                    <!--{else}-->
                                    <!--{loop $tmp_v[child] $__k $__v}-->
                                    <a href="{echo $__v[cat_link] ? $__v[cat_link] : hb_pc_rewriteoutput('cat_page', $__v[id], $cityauto)}" class="job-classify-btn">$__v[name]</a>
                                    <!--{/loop}-->
                                    <!--{/if}-->
                                </div>
                            </li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
                <!--{/loop}-->
            </div>
            <div class="middle banner">
                <div class="ivu-carousel"  style="width:690px">
                    <!--{if $hb_setting[pcslider1]}-->
                    <div class="swiper-container pc_swiper">
                        <div class="swiper-wrapper">
<!--{eval for($i=1; $i<=4; $i++):
$key1 = 'pcslider'.$i;
$key2 = 'pcslider_link'.$i;
}-->
                            <!--{if $hb_setting[$key1]}-->
                            <div class="swiper-slide">
                                <a target="_blank" href="{$hb_setting[$key2]}"><img src="{$hb_setting[$key1]}"></a>
                            </div>
                            <!--{/if}-->
<!--{eval endfor;}-->
                        </div>
                        <div class="swiper-pagination"></div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                    <!--{elseif $topnavslider}-->
                    <div class="swiper-container pc_swiper">
                        <div class="swiper-wrapper">
                            <!--{loop $topnavslider $slider}-->
                            <div class="swiper-slide">$slider</div>
                            <!--{/loop}-->
                        </div>
                        <div class="swiper-pagination"></div>
                        <div class="swiper-button-next"></div>
                        <div class="swiper-button-prev"></div>
                    </div>
                    <!--{/if}-->
                </div>
            </div>
            <div class="right job-video">
                <div class="nav clearfix">
                    <ul class="jav_right">
                        <!--{if $tidlist && $config[toutitle]}-->
                        <li class="cur"><a class="title">$config[toutitle]</a></li>
                        <li><a class="title">{lang xigua_hb:zuixin}</a></li>
                        <!--{else}-->
                        <li class="cur"><a class="title">{lang xigua_hb:zuixin}</a></li>
                        <!--{/if}-->
                    </ul>
                </div>
                <!--{if $tidlist}-->
                <div class="content jav_right_bottom">
                    <!--{loop $tidlist $_k $_v}-->
                    <!--{eval $_k=$_k+1;}-->
                    <a target="_blank" href="forum.php?mod=viewthread&tid=$_v[tid]" class="paihang-item source">
                        <div class="paihang-item-rank">$_k</div>
                        <div class="paihang-item-left ellipsis" style="max-width:175px">$_v[subject]</div>
                        <!--<div class="paihang-item-right">$_v[time_u]</div>-->
                    </a>
                    <!--{/loop}-->
                    <a target="_blank" href="forum.php?mod=forumdisplay&fid={echo $_fid ? $_fid : $config['fid_s']}" class="txt txt-link-more">{lang xigua_hb:ck}{lang xigua_hb:more}</a>
                </div>
                <!--{/if}-->
                <div class="content jav_right_bottom" <!--{if $tidlist}-->style="display:none"<!--{/if}-->>
                    <!--{loop $toutiao $v}-->
                    <!--{eval $v[cat_name] = $v[cat_name] ? $v[cat_name] : $tmpcats[$v[catid]][name];
                    $vimg_src = $v[imglist] ? unserialize($v[imglist]): array();
                    $vimg_src = $vimg_src ? $vimg_src[0] : avatar($v['uid'], 'middle', true);
                    }-->
                    <a target="_blank" href="{echo hb_pc_rewriteoutput('view_page', $v[id])}"  class="zixun-item source">
                        <img src="$vimg_src" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" class="zixun-item-img">
                        <div class="zixun-item-bd">
                            <h4 class="zixun-bd-tt c-line-clamp2" style="-webkit-box-orient: vertical;">{$v[user][username]}{$v[cr_time]}{lang xigua_hb:fabule}{$v[cat_name]}{lang xigua_hb:xinxi}</h4>
                        </div>
                    </a>
                    <!--{/loop}-->
                    <a target="_blank"  href="{echo hb_pc_rewriteoutput('cat_page', 0)}" class="txt txt-link-more">{lang xigua_hb:ck}{lang xigua_hb:more}</a>
                </div>
            </div>
        </div>
        <div class="quanzhi inner home-inner">
            <div class="left">
                <div class="quanzhi-title">
                    <div class="ele-pointer">{lang xigua_hb:zx}{lang xigua_hb:xinxi}</div>
                </div>
                <div class="quanzhi-logo ele-pointer"></div>
                <div class="quanzhi-logo-txt ele-pointer">{lang xigua_hb:yzxxqxk}</div>
                <div  class="quanzhi-recomand">
                    <!--{loop $newjing_list $_k $_v}-->
                    <p>
                        <a href="{echo $_v[0][cat_link] ? $_v[0][cat_link] : hb_pc_rewriteoutput('cat_page', $_v[0][id], $cityauto)}" target="_blank" class="first">$_v[0][name]</a>
                        <em class="vline v-line-spc"></em>
                        <a href="{echo $_v[1][cat_link] ? $_v[1][cat_link] : hb_pc_rewriteoutput('cat_page', $_v[1][id], $cityauto)}" target="_blank" class="second">$_v[1][name]</a>
                    </p>
                    <!--{/loop}-->
                </div><a href="{echo hb_pc_rewriteoutput('cat_page', 0)}" target="_blank"  class="quanzhi-more">{lang xigua_hb:ck}{lang xigua_hb:more}</a>
            </div>
            <div class="right recomand-content clearfix">
                <div>
                    <!--{loop $diglist $_k $_v}-->
                    <!--{subtemplate xigua_hb:three_list}-->
                    <!--{/loop}-->
                </div>
            </div>
        </div>
<!--{if is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/shlist.php')}-->
<!--{template xigua_hs:shlist}-->
<!--{else}-->
<!--{template xigua_hb:shlist}-->
<!--{/if}-->
<!--{template xigua_hb:tuijian}-->
        <div class="brand-box" >
            <div class="inner home-inner brand-box-content clearfix">
                <p class="brand-box-title">{$config[tname]}</p>
                <div class="brand-box-container" style="display:flex">
                    <dl>
                        <dt>{$totalviews}+</dt>
                        <dd>{lang xigua_hb:xinxi}{lang xigua_hb:views}</dd>
                    </dl>
                    <!--{if $totalsh}-->
                    <dl>
                        <dt>{$totalsh}+</dt>
                        <dd>{lang xigua_hb:yiruzhu}{lang xigua_hb:shj}</dd>
                    </dl>
                    <!--{/if}-->
                    <dl>
                        <dt>{$totalpub}+</dt>
                        <dd>{lang xigua_hb:pubs}</dd>
                    </dl>
                    <dl>
                        <dt>{$totalshares}+</dt>
                        <dd>{lang xigua_hb:views2}</dd>
                    </dl>
                </div>
            </div>
        </div>
    </div>
<!--{template xigua_hb:common_footer}-->