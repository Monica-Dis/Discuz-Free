<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{if $new_hangyes || $shlist}-->
<div class="quanzhi inner home-inner shixi" >
    <div class="left">
        <div class="quanzhi-title">
            <div class="ele-pointer">{lang xigua_hb:hotsh}</div>
        </div>
        <div class="quanzhi-logo ele-pointer quanzhi-logo-shixi"></div>
        <div class="quanzhi-logo-txt ele-pointer">{lang xigua_hb:sj}</div>
        <div  class="quanzhi-recomand">
            <!--{loop $new_hangyes $_k $_v}-->
            <p>
                <a href="javascript:;" class="first">$_v[0][name]</a>
                <em class="vline v-line-spc"></em>
                <a href="javascript:;" class="second">$_v[1][name]</a>
            </p>
            <!--{/loop}-->
        </div>
        <a href="javascript:;"  class="quanzhi-more">{lang xigua_hb:ck}{lang xigua_hb:more}</a>
    </div>
    <div class="right recomand-content clearfix">
        <div>
            <!--{loop $shlist $_k $_v}-->
            <!--{eval
if(!$config[qraut]):
$yuanurl = $_G['siteurl']."$SCRITPTNAME?id=xigua_hs&ac=view&shid=".$_v['shid']."&x=1&st=".$_v['stid'];
$_qrfile = './source/plugin/xigua_hs/cache/' . md5($yuanurl) . '.jpg';
if (!is_file(DISCUZ_ROOT . $_qrfile)) :
@include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
if(class_exists('QRcode')):
QRcode::png($yuanurl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
endif;
endif;
endif;
}-->
            <a href="javascript:;" class="shixi-item"><img src="$_v[logo]" class="img">
                <div class="job-compnay ellipsis">{$_v[name]}</div>
                <img class="innner_shqr" src="<!--{if $config[qraut]}-->$SCRITPTNAME?id=xigua_hb:qrauto&ode=sh_{$_v[shid]}{$urlext}<!--{else}-->$_qrfile<!--{/if}-->">
            </a>
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{/if}-->
