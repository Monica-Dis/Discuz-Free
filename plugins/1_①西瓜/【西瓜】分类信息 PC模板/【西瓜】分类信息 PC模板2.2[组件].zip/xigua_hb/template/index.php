<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head><!--{eval $desc = strip_tags($desc);}-->
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<title>$navtitle</title>
<meta name="keywords" content="{$navtitle}">
<meta name="description" content="{$desc}">
<!--{eval  function hex2rgb($colour, $a)
{
if ($colour[0] == '#') :
$colour = substr($colour, 1);
endif;
if (strlen($colour) == 6) :
list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
elseif (strlen($colour) == 3) :
list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
else :
return false;
endif;
$r = hexdec($r)-mt_rand(1, 50);
$g = hexdec($g)-mt_rand(1, 60);
$b = hexdec($b)-mt_rand(1, 90);
$r = $r<0 ? 0 : $r;
$g = $g<0 ? 0 : $g;
$b = $b<0 ? 0 : $b;
return "rgba($r, $g, $b, 1)";
   }-->
<!--{eval
}
$clor = hex2rgb($config[maincolor], 1);
$url = hb_currenturl();
$ewm = md5($url);
$repath = './source/plugin/xigua_hb/tmp/';
$qrfile = $repath . $ewm . '.png';
$abs_qrfile = DISCUZ_ROOT . $qrfile;
if (!is_file($abs_qrfile)) :
@include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
if(class_exists('QRcode')):
    QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
endif;
endif;
if(($_GET['id']=='xigua_hb'||$_GET['id']=='xigua_hb:xigua_hb') &&($_GET['ac']=='index' ||!$_GET['ac'])):
else:
$config[qrcode] = $qrfile;
endif;
if(!$config[qrcode]):
$config[qrcode] = $qrfile;
endif;
}-->
<style type="text/css">body, div, dl, dt, dd, ul, ol, li, h1, h2, h3, h4, h5, h6, pre, code, form, fieldset, legend, input, button, textarea, p, blockquote, th, td {margin: 0;padding: 0}
li {overflow: hidden}
body {font-size: 12px;text-align: center}
fieldset, img {border: 0}
address, caption, cite, code, dfn, em, strong, th, var, optgroup {font-style: normal;font-weight: 400}
h1, h2, h3, h4, h5, h6 {font-size: 100%;font-weight: 400}
abbr, acronym {border: 0;font-variant: normal}
input, button, textarea, select, optgroup, option {font-family: inherit;font-size: inherit;font-style: inherit;font-weight: inherit}
ol, ul {list-style: none}
table {border-collapse: collapse;border-spacing: 0}
caption, th {text-align: left}
sup, sub {font-size: 100%;vertical-align: baseline}
blockquote, q {quotes: none}
blockquote:before, blockquote:after, q:before, q:after {content: none}
.clearfix {zoom: 1}
.clearfix:after {content: ".";display: block;height: 0;clear: both;visibility: hidden}
code, kbd, samp, tt, input, button, textarea, select {font-size: 100%}
:link, :visited, ins, a {text-decoration: none}
:focus {outline: 0 none}
button::-moz-focus-inner, input[type="reset"]::-moz-focus-inner, input[type="button"]::-moz-focus-inner, input[type="submit"]::-moz-focus-inner, input[type="file"] > input[type="button"]::-moz-focus-inner {border: none;padding: 0}
* html, * htmlbody {background-attachment: fixed}
body {font-size: 14px;line-height: 1.5;font-family: "Hiragino Sans GB", Tahoma, arial, sans-serif;color: #404040;text-align: left;/*background-image: linear-gradient(to left top,$clor,$config[maincolor]);*/background-color: $config[maincolor];}
a {color: #404040}
.bottom {position: absolute;left: 0;bottom: 0;width: 100%;height: 133px;background: url(source/plugin/xigua_hb/static/img/bbg.png) repeat-x center top;font-size: 0;z-index: 30;}
.bottom.mobile {position: fixed;height: 66px;background-size: 489px 66px;}
.top {position: fixed;left: 0;top: 20px;width: 100%;height: 158px;background: url(source/plugin/xigua_hb/static/img/stars.png) repeat-x center top;background-size: 320px 158px;}
.content{display: block;height:250px;width:250px;position: absolute;top: 50%;left: 50%;margin-top: -200px;margin-left: -125px;}
.content h2{font-size:18px;margin-top:20px;color:#fff;text-align: center;}
.content img{display: block;width:100%;height:100%;}
#particles-js{position: absolute;top: 0;left: 0;height: 100%;width: 100%;z-index: 0;}
.beian{position: absolute;bottom:50px;text-align: center;width: 100%;z-index:31}.beian a{color: #fff;font-size:14px}
</style>
</head>

<body>
<div id="particles-js"><canvas class="particles-js-canvas-el" style="width: 100%; height: 100%;"></canvas></div>
<div class="top"></div>
<div class="bottom mobile"></div>

<div class="content">
<img src="{$config[qrcode]}" />
<h2>$navtitle</h2>
</div>
<div class="beian"><a href="http://beian.miit.gov.cn/" target="_blank">&copy; {$_G['setting']['sitename']} {$_G['setting']['icp']}</a></div>
<script src="source/plugin/xigua_hb/static/particles.min.js" ></script>
<script>var particlesSettings = {particles: {number: {value: 30,density: {enable: !0,value_area: 800}},color: {value: "#FFF"},shape: {type: "circle",stroke: {width: 0,color: "#F0F0F0"},polygon: {nb_sides: 5},image: {src: "img/github.svg",width: 100,height: 100}},opacity: {value: .5,random: !1,anim: {enable: !1,speed: .5,opacity_min: .1,sync: !1}},size: {value: 3,random: !0,anim: {enable: !1,speed: 10,size_min: .1,sync: !1}},line_linked: {enable: !0,distance: 150,color: "#FFF",opacity: .4,width: 1},move: {enable: !0,speed: 1,direction: "none",random: !1,straight: !1,out_mode: "out",bounce: !1,attract: {enable: !1,rotateX: 600,rotateY: 1200}}},interactivity: {detect_on: "canvas",events: {onhover: {enable: !0,mode: "grab"},onclick: {enable: !0,mode: "push"},resize: !0},modes: {grab: {distance: 140,line_linked: {opacity: 1}},bubble: {distance: 400,size: 40,duration: 2,opacity: 8,speed: 1.5},repulse: {distance: 200,duration: .4},push: {particles_nb: 4},remove: {particles_nb: 2}}
},retina_detect: !0};particlesJS('particles-js', particlesSettings);</script>
<!--{if $config[tjcode]}--><div>{$config[tjcode]}</div><!--{/if}-->
</body>
</html>