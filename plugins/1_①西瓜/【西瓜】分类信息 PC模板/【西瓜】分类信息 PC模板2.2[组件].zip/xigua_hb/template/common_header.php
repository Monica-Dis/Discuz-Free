<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{eval
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_common.php';
if($config['mustlogin'] && !$_G[uid]):
    hb_check_login();
endif;
$desc = strip_tags($desc);
$description = strip_tags($description);
$navtitle = strip_tags($navtitle);
$navtitle = $navtitle?$navtitle:$config[tname];
if($config[tnameshow]):
    if($navtitle!=$config[tname]):
        $navtitle = "$navtitle - $config[tname]";
    endif;
endif;
if(is_file("$stpath/hook2.php")):
    include_once "$stpath/hook2.php";
endif;
$CMAPP = false;
$INAPP = 0;
if($_G['cache']['plugin']['xigua_st']):
    if($_GET['st']<1):
        $stinfo['name'] = $_G['cache']['plugin']['xigua_st']['zongname'];
    endif;
    $navtitle = str_replace('tname', $stinfo['name'], $navtitle);
    $desc     = str_replace('tname', $stinfo['name'], $desc ? $desc : $description);
endif;
$c06 = hb_hex2rgb($config['maincolor'], .06);
if(!$hb_setting):
$cache_key = 'hb_ext_setting';
loadcache($cache_key);
$hb_setting = $_G['cache'][$cache_key];
endif;
}-->
<!doctype html>
<html lang="zh-cmn-Hans">
<head>
<meta charset="{CHARSET}">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
<meta http-equiv="X-UA-Compatible" content="ie=edge">
<!--{if $hb_setting['base']}--><base href="{$hb_setting['base']}/" /><!--{/if}-->
<title>{$navtitle}</title>
<meta name="description" content="{echo $desc ? $desc : $description}">
<link rel="stylesheet" href="source/plugin/xigua_hb/static/pc/style.css?7{VERHASH}">
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/swiper.min.css?7{VERHASH}">
<link rel="stylesheet" href="source/plugin/xigua_hb/static/iconfont.css?7{VERHASH}">
<style>.swiper-pagination-bullet-active{background:#fff}.card_car_tag.blue {background:$c06;border:1px solid $c06}
.card_car_tag.blue i {color:$config['maincolor'];}.ifoset{font-family:DINAlternate-Bold;src:local("DINAlternate-Bold"),url(source/plugin/xigua_hb/static/css/DINAlternate-Bold.ttf) format("truetype")}
.card_activity_tag.orange{background:{$config[maincolor]};color:#fff}.main_color{color:$config[maincolor]!important}
.hover_sidebar{background:$c06;color:{$config[maincolor]}!important}.mod_lv.is-red{background:{$c06}!important;color:$config[maincolor]!important;border:1px solid $c06}
.dialog-wrap .btn-err:active,.dialog-wrap .btn-err.active,.dialog-wrap .btn-err:hover,.dialog-wrap .btn.active,.dialog-wrap .btn:hover,.search-form.active,.search-form:hover,.show-industry .search-form,.quanzhi-more:hover,.quanzhi-more:active,.dialog-wrap .btn:active{border-color:$config[maincolor]}.hover-layer .popover-right-triangle{border-left-color:$config[maincolor]}
.industry-box,.suggest-result,.asider-item-click .app-layer,.asider-item-click .layer,.city-choose .city-txt.active,.city-choose:hover .city-txt:after,.city-choose-layer{border:1px solid $config[maincolor];}
.active,.zixun-item-bd:hover,.new-staff-box:hover,.txt:hover,.job-menu-sub .text a:hover,.quanzhi-more:hover,.quanzhi-recomand a:hover,.quanzhi-logo-txt,.hotsearch .list .items a:hover,.condition-box a:hover,.copyright .link-hover:hover,.footer-about dl dd a:hover,.dialog-wrap .btn-err.active,.dialog-wrap .btn-err:hover,.dialog-wrap .btn.active,.dialog-wrap .btn:hover,.dialog-wrap .dialog .dialog-ft .ft-btn:first-child,.dialog-wrap .dialog .dialog-ft .ft-btn:only-child,.suber-add-subsetup,.txt-link-more:hover,.third-key a:hover,.nav li a.publish,.tab .tab-li.active,.tab .tab-li:hover,.c-btn-primary .c-icon,.c-location-header-tips-success,.c-location-header-btn-in-active,.c-location-header-btn-in-active .c-icon,.item-bd .bd-txt a{color:$config[maincolor]}
.apply-btn,.job-video .nav li.cur a:after,.quanzhi-logo-txt:after,.quanzhi-logo-txt:before,.hover-layer .tip-txt,.nav li.cur a:after,.nav li a.publish:active,.tabs li.active:after{background-image:linear-gradient(45deg,$config[maincolor],$config[maincolor])}
.votebtn,.head-tab .ht-tab-item.active:after,.main_bg,.fareitemactive,.areaitemactive,.moneyitemactive{background-color:$config[maincolor]}
</style><script>var IN_WECHAT = '{HB_INWECHAT}',IN_PROG='{IN_PROG}', AVATAR = "{echo avatar($_G['uid'], 'middle', true)}", UID = '{$_G[uid]}', FORMHASH = '{FORMHASH}', PLZINPUT = "{lang xigua_hb:inputtext}", BODA = '{lang xigua_hb:boda}', DELCONFIRM = '{lang xigua_hb:delconfirm}', SUIBIANSHUO = '{lang xigua_hb:suibianshuo}', HUIFU1 = '{lang xigua_hb:huifu1}', ERROR_TIP = '{lang xigua_hb:error_}';var loading = false, page = 1, _APPNAME = '{$SCRITPTNAME}', scrollto =0, plzinput_mobile = '{lang xigua_hb:plzinput_mobile}';
var cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', IN_APP='<!--{if IN_MAGAPP}-->magapp<!--{elseif IN_APPBYME}-->appbyme<!--{elseif IN_QIANFAN}-->qianfan<!--{/if}-->', LISTINCR = '{$config[listincr]}', _URLEXT = '{$_G[cookie][URLEXT]}{$urlext}', GSITE='{$_G[siteurl]}', MAXTAG = '{echo intval($config[maxtag])}', MAXTAGTIP = "{eval echo str_replace('n', $config['maxtag'], lang_hb('zdng',0));}", FASIXIN = '{lang xigua_hb:fsx}'<!--{if $config[xiala]}-->,XL=1<!--{/if}-->, LXFS ='{lang xigua_hb:cklxfs}',CKXFF = '{lang xigua_hb:cklxfsxzf}<strong class="amount">', QRZF ='</strong>{lang xigua_hb:yuan}<br>{lang xigua_hb:qrzf}', CKLXFS = '{lang xigua_hb:cklxfs}', ISADMINID = '{echo IS_ADMINID}', QUXIAO = '{lang xigua_hb:quxiao}', SHANCHU = '{lang xigua_hb:dodel}', QUEDING = '{lang xigua_hb:queding}', lm=false;</script>
<script src="source/plugin/xigua_hb/static/lib/jquery-2.1.4.js?23{VERHASH}"></script>
<script src="source/plugin/xigua_hb/static/js/swiper.min.js?{VERHASH}"></script>
</head>
<body>
<div class="home-body" <!--{if $_GET['ac']=='cat' && $hb_setting[cattoppic]}-->style="background:url($hb_setting[cattoppic]) no-repeat 0px 68px;background-size:contain"<!--{/if}--> <!--{if $_GET['ac']=='hangye' && $hs_setting[shhy_toppic]}-->style="background:url($hs_setting[shhy_toppic]) no-repeat 0px 68px;background-size:contain"<!--{/if}-->>
<div id="header">
    <div class="inner home-inner clearfix" style="display:flex">
        <!--{if $hb_setting['logo']}-->
        <div class="logo">
            <a href="{eval echo $indexhome ? $indexhome : hb_pc_rewriteoutput('index_page')}"><!--{if strpos($hb_setting['logo'],'//')!==false}--><img style="width:100%;height:100%;object-fit:contain" src="$hb_setting[logo]" /> <!--{else}--><strong class="f28" style="position:relative;top:5px;">{echo strip_tags($hb_setting[logo])}</strong><!--{/if}--></a>
        </div>
        <!--{/if}-->
<!--{template xigua_hb:st}-->
<div class="nav cl header_nav">
    <ul class="cl">
<!--{eval $toplink = explode("\n", $hb_setting[toplink]);}-->
<!--{loop $toplink $_k $_v}-->
<!--{eval list($_link, $_name, $_color, $_target) = explode('|', trim($_v));
$cat_id =isset($_GET['cat_id'])? intval($_GET['cat_id']):'';
if(!$_name):
    contiune;
endif;
}-->
<li <!--{if ($_GET[id]=='xigua_hs:xigua_hs'||$_GET[id]=='xigua_hs')&& (strpos($_link,'xigua_hs')!==false||strpos($_link,'shangjia')!==false||strpos($_link,'hangye')!==false||strpos($_link,'shop')!==false) &&!$hascur}-->class="cur"<!--{eval $hascur =1;}--><!--{/if}--> <!--{if $ac=='index'&&($_GET[id]=='xigua_hb:xigua_hb'||$_GET[id]=='xigua_hb')&&$_k==0&&!$hascur}-->class="cur"<!--{eval $hascur =1;}--><!--{/if}--><!--{if ($_GET[id]=='xigua_hb:xigua_hb'||$_GET[id]=='xigua_hb') && $ac!='index'&&$ac!='view' && (strpos($_link, 'cat_id='.$cat_id)!==false || strpos($_link, 'cat_'.$cat_id)!==false)&&!$hascur}-->class="cur"<!--{eval $hascur =1;}--><!--{/if}-->><a href="$_link" <!--{if $_target}-->target="_blank"<!--{/if}--> <!--{if $_color}-->style="color:$_color"<!--{/if}-->>$_name</a></li>
<!--{/loop}-->
                <!--{if $_G[uid]}-->
                <li class="y header_user_vatar">
                    <div href="javascript:;" class="header_user_vatar_a"><img src="{avatar($_G[uid], 'middle', 1)}" class="img"></div>
                    <div class="share-panel3">
                        <div class="share-layer share-layer-comp">
                            <div class="popover" style="height:1px">
                                <i class="popover-tag popover-bottom-triangle" style="top:-2px"></i>
                            </div>
                            <div>
                                <a class="logbtn" target="_blank" href="home.php?mod=space&do=notice">{lang remind} <!--{if $_G[member][newprompt]}--><span class="f12 color-red2">$_G[member][newprompt]</span><!--{/if}--></a>
                                <a class="logbtn" href="member.php?mod=logging&action=logout&formhash={FORMHASH}">{lang xigua_hb:logout_mobile}</a>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{else}-->
                <li class="y header_user_vatar">
                    <div href="javascript:;" class="header_user_vatar_a"><img alt="" src="{avatar(0, 'middle', 1)}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" class="img"></div>
                    <div class="share-panel3">
                        <div class="share-layer share-layer-comp">
                            <div class="popover" style="height:1px">
                                <i class="popover-tag popover-bottom-triangle" style="top:-2px"></i>
                            </div>
                            <div>
                                <a class="logbtn" href="member.php?mod=logging&action=login">{lang xigua_hb:login_mobile}</a>
                            </div>
                        </div>
                    </div>
                </li>
                <!--{/if}-->
                <!--{if strpos($_GET['id'], 'xigua_hs')!==false}-->
        <li class="y" style="position:relative"><a href="javascript:;" class="publish">{lang xigua_hb:sh_pub}</a>
                <div class="share-panel3" >
                    <div class="share-layer share-layer-comp" <!--{if $hb_setting[appnamepub] && $hb_setting[appqrcode]}-->style="width:440px"<!--{/if}-->>
                        <div class="popover">
                            <i class="popover-tag popover-bottom-triangle"></i>
                        </div>
                        <div>
                            <!--{if $hb_setting[appnamepub] && $hb_setting[appqrcode]}-->
                            <div style="float: left;width: 220px;"><img src="{$hb_setting[appqrcode]}">
                                <p style="text-align:center;margin-bottom:10px;line-height:1.5">$hb_setting[appnamepub]</p></div>
                            <div style="float: left;width: 220px;"><img src="$SCRITPTNAME?id=xigua_hb:qrcode&isenter=1">
                                <p style="text-align:center;margin-bottom:10px;line-height:1.5">{lang xigua_hb:saoma}{lang xigua_hs:ruzhu}{lang xigua_hb:shj}</p></div>
                            <!--{else}-->
                            <img src="$SCRITPTNAME?id=xigua_hb:qrcode&isenter=1">
                            <p style="text-align:center;margin-bottom:10px;line-height:1.5">{lang xigua_hb:saoma}{lang xigua_hs:ruzhu}{lang xigua_hb:shj}</p>
                            <!--{/if}-->
                        </div>
                    </div>
            </div>
        </li>
                <!--{else}-->
                <li class="y" style="position:relative"><a href="javascript:;" class="publish">{lang xigua_hb:fabuxinxi}</a>
                    <div class="share-panel3" >
                        <div class="share-layer share-layer-comp" <!--{if $hb_setting[appnamepub] && $hb_setting[appqrcode]}-->style="width:440px"<!--{/if}-->>
                            <div class="popover">
                                <i class="popover-tag popover-bottom-triangle"></i>
                            </div>
                            <div>
                                <!--{if $hb_setting[appnamepub] && $hb_setting[appqrcode]}-->
                                <div style="float: left;width: 220px;"><img src="{$hb_setting[appqrcode]}">
                                    <p style="text-align:center;margin-bottom:10px;line-height:1.5">$hb_setting[appnamepub]</p></div>
                                <div style="float: left;width: 220px;"><img src="$SCRITPTNAME?id=xigua_hb:qrcode&ispub=1">
                                    <p style="text-align:center;margin-bottom:10px;line-height:1.5">{lang xigua_hb:saoma}{lang xigua_hb:fabuxinxi}</p></div>
                                <!--{else}-->
                                <img src="$SCRITPTNAME?id=xigua_hb:qrcode&ispub=1">
                                <p style="text-align:center;margin-bottom:10px;line-height:1.5">{lang xigua_hb:saoma}{lang xigua_hb:fabuxinxi}</p>
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </li>
        <!--{/if}-->
            </ul>
        </div>
    </div>
</div>