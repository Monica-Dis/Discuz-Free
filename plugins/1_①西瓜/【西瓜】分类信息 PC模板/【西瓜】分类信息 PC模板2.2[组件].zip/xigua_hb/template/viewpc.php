<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_hb:common_header}--><!--{if $totalpubs<1}--><!--{eval $totalpubs=1;}--><!--{/if}-->
<!--{eval
if($_G['uid']==$v[uid] || IS_ADMINID):
    $catinfo['telpri']=0;
endif;
$bttxt = lang_hb('duanxin', 0);
$calltel = $v[mobile] ? "tel:$v[mobile]" : '';
$callsms = $v[mobile] ? "sms:$v[mobile]" : '';
if($v[weixin]):
  $calltel = "javascript:lxfs_tip(this, '$v[mobile]', '$v[weixin]');";
endif;
if($_G['uid']):
  $viewtels = C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], array($pubid));
endif;
if($v[wancheng]):
  $callsms = $calltel = "javascript:$.toast('{lang xigua_hb:xinxiwc}','error');";
else:
  $vcatid = $v[catid];
  $vtelp = $catinfo['telpri'];
  if($vtelp>0):
    include DISCUZ_ROOT. 'source/plugin/xigua_hb/include/c_addon.php';
    if(!$viewtels[$v[id]] && !$ishk):
      $callsms = $calltel = "javascript:hb_paytel('$v[id]','$vtelp','$vcatid');";
    endif;
  endif;
endif;
if($catinfo['hidereal']):
$calltel = $callsms = '';
endif;
$vavatar = avatar($v['uid'], 'middle', true, false, true);
$subtit = $disvar = '';
foreach($v[vars] as $___k => $___v):
  if($___v[autoin]):
    $subtit = '| '.$___v[html];
  endif;
  if($___v[type]=='location' || $___v[type]=='area'):
    $disvar = $___v[html];
    unset($v[vars][$___k]);
  endif;
endforeach;
if($v[vars]):
  $v[vars] = array_values($v[vars]);
endif;
if($catinfo['pid']>0 && function_exists('array_column')):
    $pidindex = array_search($catinfo['pid'], array_column($cat_list, 'id'));
    $pidcat = $cat_list[$pidindex];
endif;
$hasvideo = $v['video'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php');
$vimglist = range(0, count($v[imglist])-1);
if($hasvideo):
    $vimglist = range(0, count($v[imglist]));
endif;
}-->
<div id="main" class="main home-content" style="padding-top: 30px;">
    <div class="inner home-inner clearfix job-info">
        <!--{if !$hb_setting[hidetoppic] && ($v[imglist] || $hasvideo)}-->
        <div class="swiper-container pc_swiper z v_swiper">
            <div class="swiper-wrapper">
                <!--{if $hasvideo}-->
                <div class="swiper-slide vcide"><video poster="{$v['video_cover']}" src="{$v['video']}" controls="controls" <!--{if !IN_PROG}-->x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<!--{/if}-->></video></div>
                <!--{/if}-->
                <!--{loop $v[imglist] $_k $slider}-->
                <div class="swiper-slide vcide"><img style="object-fit: contain;" src="$slider" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" /> </div>
                <!--{/loop}-->
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <!--{/if}-->
        <div class="y" <!--{if !$hb_setting[hidetoppic] && ($v[imglist] || $hasvideo)}-->style="width:710px"<!--{else}-->style="width:100%"<!--{/if}-->>
            <div class="share-favor-report">
                <div class="item3 share"><p class="link-item link-share">{lang xigua_hb:shares}</p>
                    <div class="share-panel">
                        <div class="share-layer share-layer-comp">
                            <div class="popover">
                                <i class="popover-tag popover-bottom-triangle"></i>
                            </div>
                            <div>
                                <img src="$qrcodeurl1" />
                                <p style="text-align: center;margin-bottom: 10px;">{lang xigua_hb:wxsysfx}</p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="item3">
                    <p class="link-item link-views">{lang xigua_hb:views}{$v[views]}</p>
                </div>
            </div>
            <h4 class="job-name">
                <!--{if $v[dig_on]}--><span class="mod_lv is-star" style="margin-right:8px;vertical-align:middle"><!--{if $v[zdword]}-->$v[zdword]<!--{else}-->{lang xigua_hb:zhiding}<!--{/if}--></span><!--{/if}-->
                <!--{if $v[hb_num]}--><span class="mod_lv is-hot" style="margin-right:8px;vertical-align:middle">{lang xigua_hb:hb}</span><!--{/if}-->
                <!--{if $catinfo['pid']>0 && $pidcat[name]}-->{$pidcat[name]} {lang xigua_hb:dot1} {$catinfo[name]}<!--{else}-->{$catinfo[name]}<!--{/if}--> $subtit
            </h4>
            <div class="user-operations clearfix">
                <div class="source">
                    <!--{if $v[refresh_times]}-->{lang xigua_hb:up_time}<!--{else}-->{lang xigua_hb:cr_time}<!--{/if}--> <span>{echo $v[up_time]!='0000-00-00 00:00:00'&&$v[up_time] ? $v[up_time] : $v[cr_time]}</span>
                </div>
            </div>
            <div class="salary-box clearfix">
                <!--{if !$v[vars][0][autoin]}-->
                <div class="salary-container">
                    <span class="salary">{echo $v[vars][0][html] ? $v[vars][0][html] : $v[vars][0][value]}</span>
                </div>
                <!--{/if}-->
                <!--{if 0 && $calltel == 'tel:'.$v[mobile]}-->
                <div class="apply-btn" data-mobile="$v[mobile]" style="position:relative;top:-15px">{lang xigua_hb:ckdh}</div>
                <!--{else}-->
            <div class="mobile-layer clearfix">
                <div class="apply-btn apply-btn2" data-mobile="" style="position:relative;top:-15px">{lang xigua_hb:smddh}</div>
                <div class="share-panel2">
                    <div class="share-layer share-layer-comp">
                        <div class="popover">
                            <i class="popover-tag popover-bottom-triangle"></i>
                        </div>
                        <div>
                            <img src="$qrcodeurl1" />
                            <p style="text-align: center;margin-bottom: 10px;">{lang xigua_hb:wx}{lang xigua_hb:smddh}</p>
                        </div>
                    </div>
                </div>
            </div>
                <!--{/if}-->
            </div>
            <div class="job-require">
                <!--{eval $tmp = array_slice($v[vars], 1, 4);}-->
                <!--{loop $tmp $___k $___v}-->
                <span><!--{if $___k!=0}--><em class="vline"></em><!--{/if}--> <em>{$___v[title]}{lang xigua_hb:m}</em> <em>{echo $___v[html] ? $___v[html] : $___v[value]}</em></span>
                <!--{/loop}-->
            </div>
            <!--{if  $v[tags]}-->
            <ul class="tagsS">
                <!--{loop $v[tags] $___k $tag}--><!--{if $tag}--><li class="card_car_tag blue"><i>$tag</i></li><!--{/if}--><!--{/loop}-->
            </ul>
            <!--{/if}-->
            <div class="job-guide-nofraud">
                <p class="tip-txt-item nofraud">{lang xigua_hb:aqxts}{lang xigua_hb:m}$hb_setting[aqxts]</p>
            </div>
        </div>
    </div>
    <div class="job-desc-box inner home-inner clearfix">
        <div class="job-desc right-box job-detail-area">
            <div class="job-desc-item" style="min-height:304px">
                <div class="title-box clearfix"><p class="title">{lang xigua_hb:xxms}</p></div>
                <div class="job-classfiy">
                    <!--{eval $tmp = $v[vars];}-->
                    <!--{loop $tmp $___k $___v}-->
                    <!--{if $___v[type]=='pics'}-->
                        <div class="cl feed-preview-pic">
                            {$___v[title]}{lang xigua_hb:m}
                            <!--{loop $___v[value] $_img}-->
                                <img src="{$_img}" />
                            <!--{/loop}-->
                        </div>
                    <!--{else}-->
                    <p>{$___v[title]}{lang xigua_hb:m} <em>{echo $___v[html] ? $___v[html] : $___v[value]}</em></p>
                    <!--{/if}-->
                    <!--{/loop}-->
                </div>
                <div class="job-description">
                    <div class="job-detail">
                        <!--{if $v[description]}-->
                        {echo hb_nl2br($v[description])}<br><br>{echo str_replace('tname', $stinfo['name']?$stinfo['name']:$config[tname], $config[seefrom])}
                        <!--{else}-->
                        {$v[user][username]}{lang xigua_hb:tl}<br><br>{echo str_replace('tname', $stinfo['name']?$stinfo['name']:$config[tname], $config[seefrom])}
                        <!--{/if}-->
                        <!--{if $hb_setting[showpic]}-->
                        <div class="view_img_preview">
                        <!--{loop $v[imglist] $_k $slider}-->
                        <img src="$slider" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" />
                        <!--{/loop}-->
                        </div>
                        <!--{/if}-->
                    </div>
                </div>
            </div>
            <div class="job-desc-item">
                <div class="title-box clearfix"><p class="title">{lang xigua_hb:lianxiren}</p></div>
                <div class="media-item source">
                    <img src="{$vavatar}" class="item-img" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'">
                    <div class="item-bd"><h4 class="bd-tt">{echo $v[realname]&& $v[realname]!='-' ?$v[realname] :$v[user][username]}
                            <span style="margin-left:20px">
                            <!--{eval
            if($_G['cache']['plugin']['xigua_hr']):
            $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($v[uid]));
            $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($v[uid]), 2);
            $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($v[uid]));
            endif;
            if($_G['cache']['plugin']['xigua_hr']['showhbview']):
            $shwv1 =1;
            endif;
            if($_G['cache']['plugin']['xigua_hr']['showbview']):
            $shwv2 =2;
            endif;
            }-->
                            <!--{if $veris1[$v[uid]] && !$veris2[$v[uid]]}--><a href="javascript:;" class="f14"><i class="iconfont icon-duigou2 f13 main_color"></i> {lang xigua_hr:gr}</a><!--{/if}-->
                            <!--{if $veris2[$v[uid]]}--><a href="javascript:;" class="f14"><i class="iconfont icon-duigou2 f13 main_color"></i> {lang xigua_hr:qy}</a><!--{/if}-->
                            <!--{if $bao[$v[uid]]}--><a href="javascript:;" class="f14"><i class="iconfont icon-duigou2 f13 main_color"></i> <!--{if $_G[cache][plugin][xigua_hr][bzjed]}-->{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}<!--{else}-->{lang xigua_hr:yjbzj}<!--{/if}--></a><!--{/if}--></span>
                        </h4>
                        <div class="bd-txt">{echo str_replace('tname', $stinfo['name']?$stinfo['name']:$config[tname], $config[seefrom])}</div>
                    </div>
                    <!--{if 0 && $calltel == 'tel:'.$v[mobile]}-->
                    <div class="apply-btn" data-mobile="$v[mobile]" style="position:relative;top:10px">{lang xigua_hb:ljlx}</div>
                    <!--{else}-->
                    <div class="mobile-layer clearfix">
                        <div class="apply-btn apply-btn2" data-mobile="" style="position:relative;top:10px">{lang xigua_hb:ljlx}</div>
                        <div class="share-panel2">
                            <div class="share-layer share-layer-comp" style="margin-top: 35px;">
                                <div class="popover">
                                    <i class="popover-tag popover-bottom-triangle"></i>
                                </div>
                                <div>
                                    <img src="$qrcodeurl1" />
                                    <p style="text-align: center;margin-bottom: 10px;">{lang xigua_hb:wx}{lang xigua_hb:smddh}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--{/if}-->
                </div>
            </div>
        </div>
        <div class="left-box">
            <!--{template xigua_hb:left_box}-->
        </div>
    </div>
    <!--{template xigua_hb:tuijian}-->
</div>
<!--{template xigua_hb:common_footer}-->
