<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{if $_G['cache']['plugin']['xigua_st'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_st/xigua_st.inc.php')}-->
<!--{eval include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_st.php';}-->
<!--{if $hb_setting[zongname]}-->
<div class="city-choose">
    <span  class="city-txt">{echo $stinfo['name2']?$stinfo['name2']:($hb_setting[zongname] ? $hb_setting[zongname] : $_G['cache']['plugin']['xigua_st']['zongname'])}<i class="icon more-down-icon"></i></span>
    <div class="city-choose-layer">
        <div class="tabs">
            <div class="citys-box">
                <div  class="tabs-ctn-item clearfix">
                    <div  class="city-content clearfix">
                        <div  class="second-key ellipsis">{lang xigua_st:emcs}</div>
                        <div  class="third-key">
                            <a class="city" href="{$hb_currenturl}&st=-1">{echo $hb_setting[zongname] ? $hb_setting[zongname] : $st_config[zongname];}</a>
                            <!--{loop $hotcity $_v}-->
                            <a class="city" href="$hb_currenturl&st={$_v[stid]}">{echo $_v['name2']?$_v['name2']:$_v[name]}</a>
                            <!--{/loop}-->
                        </div>
                    </div>
                    <!--{loop $abccitys $_k $_v}-->
                    <div  class="city-content clearfix">
                        <div  class="second-key ellipsis">$_k</div>
                        <div  class="third-key">
                            <!--{loop $_v $__v}-->
                            <a  href="$hb_currenturl&st={$__v[stid]}" class="city">{echo $__v['name2']?$__v['name2']:$__v[name]}</a>
                            <!--{/loop}-->
                        </div>
                    </div>
                    <!--{/loop}-->
                </div>
                <div  class="tabs-ctn-item clearfix"></div>
                <div  class="tabs-ctn-item clearfix"></div>
                <div  class="tabs-ctn-item clearfix"></div>
                <div  class="tabs-ctn-item clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!--{/if}-->
<!--{/if}-->
