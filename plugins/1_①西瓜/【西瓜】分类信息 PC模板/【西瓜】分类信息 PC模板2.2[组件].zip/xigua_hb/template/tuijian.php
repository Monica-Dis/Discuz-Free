<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{if $tuijianlist}-->
<div class="recomand">
    <div class="inner home-inner"><h4 class="recomand-title">{lang xigua_hb:tuijian}</h4>
        <div class="recomand-content clearfix">
            <!--{loop $tuijianlist $_k $_v}-->
            <!--{subtemplate xigua_hb:three_list}-->
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{/if}-->