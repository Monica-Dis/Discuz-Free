<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/custom.css?{VERHASH}52">
<style>
.prompt{align-items:flex-start;padding:12px;line-height:24px;background:#fffdf5;border:1px solid #fce3b4;border-radius:6px;font-size:14px;color:#666;margin-top:12px}
.content-wrapper{border-radius:6px;width:1210px;background:#fff;margin:20px auto;min-height:820px;box-sizing:border-box}
.auth-step{padding:0 50px 38px 50px}
.step-title{width:100%;box-sizing:border-box;border-bottom:1px solid #e7e7e7;height:87px;line-height:87px;font-size:24px;color:#333;font-weight:900}
.ivu-form-item{margin-top:38px;margin-bottom:30px;vertical-align:top;zoom:1}
.ivu-form-item-content{position:relative;line-height:32px;font-size:13px;margin-left:112px}
.ivu-btn{min-width:110px;display:inline-block;margin-bottom:0;font-weight:400;text-align:center;vertical-align:middle;touch-action:manipulation;cursor:pointer;background-image:none;border:1px solid transparent;white-space:nowrap;line-height:1.5;user-select:none;padding:7px 15px;font-size:12px;border-radius:6px;transition:color .2s linear,background-color .2s linear,border .2s linear,box-shadow .2s linear;color:#555;background-color:#fff;border-color:#d9d9d9}
.ivu-btn-large{padding:6px 15px 7px 15px;font-size:16px}
.ivu-btn,.ivu-btn:active,.ivu-btn:focus{outline:0}
.ivu-form-item-label{position:relative;text-align:right;vertical-align:middle;float:left;font-size:14px;color:#555;box-sizing:border-box;line-height:26px;height:26px}
.ivu-input-wrapper{display:inline-block;width:100%;position:relative;vertical-align:middle;line-height:normal}
.ivu-input-wrapper-job{font-size:18px;height:36px;width:400px;line-height:36px}
.ivu-input{display:inline-block;width:100%;height:26px;line-height:1.5;padding:4px 12px;font-size:13px;border:1px solid #d9d9d9;border-radius:6px;color:#555;background-color:#fff;background-image:none;position:relative;cursor:text;transition:border .2s ease-in-out,background .2s ease-in-out,box-shadow .2s ease-in-out}
.pubchckcat a{color:#000;border-radius:6px;font-size:14px;letter-spacing:0;margin-left:15px;display:inline-block;position:relative;cursor:pointer;line-height:26px;height:26px}
.pubchckcat div{margin-bottom:10px}
.ivu-checkbox-group{
    display: inline-block;
    vertical-align: middle;
    line-height: 26px;}
.pubchckcat_sub:empty{display:none!important;}
.pubchckcat a:hover{color: {$config[maincolor]}}
.pubchckcat a.nob{color:#555;margin-left:0;padding-left:0;border:0}
.ivu-btn-primary {color: #fff;background-color: {$config[maincolor]};border-color: {$config[maincolor]};}
</style>
<div class="main home-content">
<!--{if !$_GET[step]}-->
<!--{template xigua_hb:step1}-->
<!--{else}-->
<form action="$SCRITPTNAME?id=xigua_hb&ac=pub&step=$_GET[step]&catid=$_GET[catid]" method="post" id="forms" enctype="multipart/form-data" onsubmit="return false;">
    <!--{loop $_GET $key $item}-->
    <input type="hidden" name="$key" value="{$item}">
    <!--{/loop}-->
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <input type="hidden" name="form[catid]" value="{$_GET[catid]}">
    <!--{if $old_data}--><input type="hidden" name="pubid" value="$old_data[id]" /><!--{/if}-->
    <input type="hidden" id="dist1" name="form[dist1]" value="{$old_data[dist1]}">
    <input type="hidden" id="dist2" name="form[dist2]" value="{$old_data[dist2]}">
    <input type="hidden" id="dist3" name="form[dist3]" value="{$old_data[dist3]}">
<div class="content-wrapper">
    <div>
        <div class="auth-step auth-step1">
            <div style="margin-bottom: 30px;">
                <div class="step-title">
                    $navtitle
                    <a href="$SCRITPTNAME?id=xigua_hb&ac=pub" class="y" style="font-size:14px;font-weight:normal">����ѡ�����</a>
                </div>
            </div>
            <div class="prompt">
                <!--{if $config[pubtip]}-->$config[pubtip]<br><!--{/if}-->
                <!--{if !$catinfo[multiprice] && !$needsafe}-->
                {lang xigua_hb:ben}<!--{if $catinfo[price]>0&&$catinfo[price]!='0.00'}-->{lang xigua_hb:fabuxinxi}{lang xigua_hb:m}<em class="color-red">{echo floatval($catinfo[price]);}{lang xigua_hb:yuan}/{lang xigua_hb:tiao}</em><!--{else}--><em class="color-red">{lang xigua_hb:mianfei}</em><!--{/if}--> <!--{if $catinfo[endtime] &&$catinfo[endtime]!=9999}-->{lang xigua_hb:youxiaoqi}<em class="color-red">{$catinfo[endtime]}{lang xigua_hb:day}</em><!--{/if}-->
                <!--{if !$INAPP && $catinfo[apprice]!='0.00'&&$config[qbguidelink]}-->
                <p><span class="main_color"><!--{if $catinfo[apprice]=='0.03'}-->{lang xigua_hb:xzapp}<!--{else}-->{lang xigua_hb:xzapp1}{$catinfo[apprice]}{lang xigua_hb:y1}<!--{/if}-->&nbsp;&nbsp;<a class="color-red" href="{$config[qbguidelink]}">{lang xigua_hb:dwljxz}</a></span></p>
                <!--{/if}-->
                <!--{/if}-->
                <!--{if $realpubcnt>0}-->
                <p>{lang xigua_hb:dqzh}<b class="main_color">{$realpubcnt}{lang xigua_hb:tiao}</b>{lang xigua_hb:xinxi}</p>
                <!--{/if}-->
                <!--{if $config[tcpub]}--><p class="color-red"><a href="$SCRITPTNAME?id=xigua_hb&ac=buypub&mobile=2{$urlext}">{lang xigua_hb:gmczfw}</a></p><!--{/if}-->
            </div>



            <!--{loop $vars $var}-->
        <!--{eval $defaultvalue = $old_data?$old_data[vars][$var[pluginvarid]][value]:$var[extra];}-->
        <!--{eval $var[placehd] = $var[placehd] ? $var[placehd] : $var[title];}-->
        <!--{if $var[type]=='number'}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{$var[title]}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[vars][{$var[pluginvarid]}]" <!--{if $old_data && $var[unchangeable]}-->readonly="readonly"<!--{/if}--> type="tel" placeholder="{$var[placehd]}" value="{$defaultvalue}">
            </div>
            <!--{if $var[unitnew]}--><div class="weui-cell__ft">$var[unitnew]</div><!--{/if}-->
        </div>
        <!--{elseif $var[type]=='text' || $var[type]=='linkurl'}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{$var[title]}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[vars][{$var[pluginvarid]}]" <!--{if $old_data && $var[unchangeable]}-->readonly="readonly"<!--{/if}--> type="text" placeholder="{$var[placehd]}" value="{$defaultvalue}">
            </div>
            <!--{if $var[unitnew]}--><div class="weui-cell__ft">$var[unitnew]</div><!--{/if}-->
        </div>
        <!--{elseif $var[type]=='textarea'}-->
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <textarea class="weui-textarea" name="form[vars][{$var[pluginvarid]}]" <!--{if $old_data && $var[unchangeable]}-->readonly="readonly"<!--{/if}--> placeholder="{$var[placehd]}" rows="3" value="{$defaultvalue}">{$defaultvalue}</textarea>
            </div>
        </div>
        <!--{elseif $var[type]=='area'}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label class="weui-label">{$var[title]}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[vars][{$var[pluginvarid]}]" <!--{if $old_data && $var[unchangeable]}-->readonly="readonly"<!--{/if}--> id="city_picker_{$var[pluginvarid]}" type="text" placeholder="{$var[placehd]}" value="{echo $defaultvalue ? $defaultvalue : ''}">
                <script>
                    +function($){
                        $.rawCitiesData = $cityjson;
                    }($);
                </script>
                <script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
                <script>
                    $("#city_picker_{$var[pluginvarid]}").cityPicker({/*showDistrict: false,*/
                        title: "{lang xigua_hb:qingxuan}{$var[title]}"
                    });
                </script>
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{elseif $var[type]=='datetime'}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{$var[title]}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" id="datetime_picker{$var[pluginvarid]}" name="form[vars][{$var[pluginvarid]}]" <!--{if $old_data && $var[unchangeable]}-->readonly="readonly"<!--{/if}--> type="text" placeholder="{$var[placehd]}" value="{$defaultvalue}">
            </div>
            <script>$("#datetime_picker{$var[pluginvarid]}").datetimePicker();</script>
        </div>
        <!--{elseif $var[type]=='date'}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{$var[title]}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" id="date_picker{$var[pluginvarid]}" name="form[vars][{$var[pluginvarid]}]" <!--{if $old_data && $var[unchangeable]}-->readonly="readonly"<!--{/if}--> type="text" placeholder="{$var[placehd]}" value="{$defaultvalue}">
            </div>
            <script>$("#date_picker{$var[pluginvarid]}").calendar();</script>
        </div>
        <!--{elseif $var[type]=='select'}-->
        <!--{eval $extra1 = C::t('#xigua_hb#xigua_hb_cat')->get_tree($var[extra], $old_data[vars][$var[pluginvarid]][value]);}-->
        <!--{if $extra1[1]}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd">
                <label class="weui-label">{$var[title]}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label>
            </div>
            <div class="weui-cell__bd">
                <input class="weui-input" <!--{if $old_data && $var[unchangeable]}-->readonly="readonly"<!--{/if}--> id="select_picker_{$var[pluginvarid]}" type="text" placeholder="{$var[placehd]}" value="$extra1[4]" />
                <input type="hidden" name="form[vars][{$var[pluginvarid]}]" id="sel_picker_{$var[pluginvarid]}" value="{echo $old_data ? $old_data[vars][$var[pluginvarid]][value] : $extra1[5][0]}" />
                <script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
                <script>$("#select_picker_{$var[pluginvarid]}").cityPicker({
                        showDistrict:<!--{if $extra1[1]==1}-->false<!--{else}-->true<!--{/if}-->,
                        citiesData:{echo json_encode($extra1[2]);},
                        title: "{lang xigua_hb:qingxuan}{$var[title]}",
                        onChange:function(v, values){
                            var len1 = values[values.length-1] ? values.length - 1 : values.length - 2;
                            var indexdata = {echo json_encode($extra1[5]);};
                            $('#sel_picker_{$var[pluginvarid]}').val(indexdata[values[len1]]);
                        }
                    });</script>
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{else}-->
        <div class="weui-cell weui-cell_select weui-cell_select-after">
            <div class="weui-cell__hd">
                <label for="" class="weui-label">{$var[title]}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label>
            </div>
            <div class="weui-cell__bd">
                <select class="weui-select" name="form[vars][{$var[pluginvarid]}]" <!--{if $old_data && $var[unchangeable]}-->disabled="disabled"<!--{/if}-->>
                <!--{loop $extra1[0] $tmp1 $tmp2}-->
                <!--{eval $tmp2 = $tmp2['name']}-->
                <option value="$tmp1" <!--{if {$old_data[vars][$var[pluginvarid]][value]}==$tmp1}-->selected="selected"<!--{/if}-->>$tmp2</option>
                <!--{/loop}-->
                </select>
            </div>
        </div>
        <!--{/if}-->
        <!--{elseif $var[type]=='selects'}-->
        <!--{eval $extra = trim($var[extra]);}-->
        <!--{eval $extra = explode("\n", $extra);}-->
        <div class="weui-cell weui-cell_select weui-cell_select-after">
            <div class="weui-cell__hd">
                <label for="" class="weui-label">{$var[title]}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label>
            </div>
            <div class="weui-cell__bd">
                <select multiple="multiple" class="weui-select" name="form[vars][{$var[pluginvarid]}][]" <!--{if $old_data && $var[unchangeable]}-->disabled="disabled"<!--{/if}--> >
                <!--{loop $extra $extra_string}-->
                <!--{eval list($tmp1, $tmp2) = explode('=', trim($extra_string));}-->
                <option value="$tmp1" <!--{if in_array($tmp1, $old_data[vars][$var[pluginvarid]][value]) }-->selected="selected"<!--{/if}-->>$tmp2</option>
                <!--{/loop}-->
                </select>
            </div>
        </div>
        <!--{elseif $var[type]=='location' && $_G['cache']['plugin']['xigua_hs']}-->
        <!--{eval $defaultvalue = $old_data?$old_data[vars][$var[pluginvarid]][value][0]:'';$needpopmap = 1;}-->
        <div class="weui-cell weui-cell_vcode">
            <div class="weui-cell__hd">
                <label class="weui-label">{$var[title]}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label>
            </div>
            <div class="weui-cell__bd enter_addr">
                <input class="weui-input" id="location_{$var[pluginvarid]}" name="form[vars][{$var[pluginvarid]}][]" type="text" placeholder="{$var[placehd]}" value="{$defaultvalue}" <!--{if $old_data && $var[unchangeable]}-->readonly="readonly"<!--{/if}-->>
                <input type="hidden" id="location_lat_{$var[pluginvarid]}" name="form[vars][{$var[pluginvarid]}][]" value="{$old_data[vars][$var[pluginvarid]][value][1]}">
                <input type="hidden" id="location_lng_{$var[pluginvarid]}" name="form[vars][{$var[pluginvarid]}][]" value="{$old_data[vars][$var[pluginvarid]][value][2]}">
            </div>
            <div class="weui-cell__ft">
                <button class="weui-vcode-btn openlocation" data-id="{$var[pluginvarid]}" type="button">{lang xigua_hb:dingwei}</button>
            </div>
        </div>
        <!--{elseif $var[type]=='pics'}-->
        <!--{eval $var[placehd] = intval( $var[placehd]);}-->
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">{$var[title]}<!--{if $v[required][$__k]}--><em class="color-red">*</em><!--{/if}--></p>
                        <div class="weui-uploader__info"></div>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-max="{$var[placehd]}" data-maxtip="{echo str_replace('n', $var[placehd], lang_hb('zuiduozhao',0))}">
                            <!--{loop $old_data[vars][$var[pluginvarid]][value] $img}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                                <input type="hidden" name="form[vars][{$var[pluginvarid]}][]" value="$img"/>
                                <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                            </li>
                            <!--{/loop}-->
                        </ul>
                        <div class="weui-uploader__input-box">
                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                            <a class="weui-uploader__input" data-name="form[vars][{$var[pluginvarid]}]" data-multi="1"></a>
                            <!--{else}-->
                            <input class="weui-uploader__input" data-name="form[vars][{$var[pluginvarid]}]" type="file" data-multi="1">
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--{/if}-->
        <!--{/loop}-->

        <div class="weui-cell">
            <div class="weui-cell__bd">
                <textarea name="form[description]" class="weui-textarea" placeholder="{$catinfo['placehoder']}" rows="3">$old_data[description]</textarea>
            </div>
        </div>

        <!--{if $sh}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:guanlian}</label></div>
            <div class="weui-cell__bd">
                <input id="choose_sh" class="weui-input" name="form[shname]" readonly type="text" value="{echo $old_data ? $old_data['shname'] : ''}" placeholder="{lang xigua_hs:qxzguanlian}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{/if}-->
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">{lang xigua_hb:plzupload}</p>
                        <div class="weui-uploader__info"></div>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-max="{echo intval($config['maximg'])}" data-maxtip="{echo str_replace('n', $config['maximg'], lang_hb('zuiduozhao',0))}" id="uploaderFiles">
                            <!--{loop $old_data[imglist] $img}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[imglist][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                            <!--{/loop}-->
                        </ul>
                        <!--{if is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')&&is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/template/touch/video.php')}-->
                        <!--{eval
                        $showv = 0;
                        }-->
                        <div class="weui-uploader__input-box newupload">
                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                            <a id="uploaderInput" class="weui-uploader__input" data-name="form[imglist]" data-multi="1"></a>
                            <!--{else}-->
                            <input id="uploaderInput" class="weui-uploader__input" data-name="form[imglist]" type="file" data-multi="1">
                            <!--{/if}-->
                            <img src="source/plugin/xigua_hb/static/img/up.png">
                            <p>{lang xigua_hb:plzupload}</p>
                        </div>
                        <!--{if $showv&&!$catinfo[a_video]}-->
                        <div class="weui-uploader__input-box newupload">
                            <img src="source/plugin/xigua_hb/static/img/video.png">
                            <p>{lang xigua_hb:upvideo}</p>
                            <input class="weui-uploader__input_video" data-name="form[video]" type="file" accept="video/*">
                        </div><!--{/if}-->
                        <!--{else}-->
                        <div class="weui-uploader__input-box">
                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                            <a id="uploaderInput" class="weui-uploader__input" data-name="form[imglist]" data-multi="1"></a>
                            <!--{else}-->
                            <input id="uploaderInput" class="weui-uploader__input" data-name="form[imglist]" type="file" data-multi="1">
                            <!--{/if}-->
                        </div>
                        <!--{/if}-->

                    </div>
                </div>
            </div>
        </div>

        <!--{if array_filter($catinfo['tag'])}-->
        <div class="weui-cell" style="padding-bottom:6px">
            <div class="weui-cell__bd">
                <div class="post-tags cl" id="post-typeid">
                    <!--{loop $catinfo['tag'] $tag_id $tagname}-->
                    <!--{eval $tag_on = in_array($tagname, $old_data['tags']) ? 'tag-on' : '';}-->
                    <a class="weui-btn weui-btn_mini weui-btn_default $tag_on" href="javascript:;" onclick="return setTypeid($tag_id, this);">$tagname</a>
                    <input name="form[tagid][$tag_id]" type="hidden" value="<!--{if $tag_on}-->1<!--{else}-->0<!--{/if}-->" />
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <!--{/if}-->

        <!--{if !$catinfo['hidereal']}--><div class="weui-cells__title">{lang xigua_hb:lianxiren}</div><!--{/if}-->




    <div class="ivu-form-item <!--{if $catinfo['hidereal']}-->none<!--{eval $lastrealname='';}--><!--{/if}-->">
        <label class="ivu-form-item-label">{lang xigua_hb:lianxiren}</label>
        <div class="ivu-form-item-content">
            <div class="ivu-input-wrapper ivu-input-type ivu-input-wrapper-job">
                <input name="form[realname]" value="{echo $old_data ?$old_data[realname] : $lastrealname}" autocomplete="off" spellcheck="false" type="text" placeholder="{lang xigua_hb:lianxiren_tip}" class="ivu-input">
            </div>
        </div>
    </div>


        <div class="weui-cells weui-cells_form before_none after_none ">
            <!--{eval
            $m = unserialize($config['mustbind']);
            $lastmobile = $lastmobile?$lastmobile:'';
            }-->
            <!--{if 1 || $dxp && !IS_ADMINID && in_array(7, $m)}-->
            <div class="ivu-form-item">
                <label class="ivu-form-item-label">{lang xigua_hb:mobile}</label>
                <div class="ivu-form-item-content">
                    <div class="ivu-input-wrapper ivu-input-type ivu-input-wrapper-job">
                        <input name="form[mobile]" data-old="$lastmobile" class="ivu-input" type="tel" placeholder="{lang xigua_hb:mobile_tip}" value="{echo $old_data ? $old_data[mobile]: $lastmobile}" <!--{if $lastmobile}-->id="vcode_tel"<!--{/if}-->>
                    </div>
                    <div class="ivu-checkbox-group" id="vcode_btn">
                        <button type="button" class="ivu-btn ivu-btn-large" id="vcodebtn">{lang xigua_hb:vcode_get}</button>
                    </div>
                </div>
            </div>

            <div class="weui-cell <!--{if $lastmobile}-->none<!--{/if}-->" id="vcode_area">
                <div class="weui-cell__hd">
                    <i class="iconfont icon-sixin1 main_color"></i>
                </div>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hb:vcode}</label></div>
                <div class="weui-cell__bd">
                    <input name="vcode" class="weui-input" type="tel" maxlength="4" placeholder="{lang xigua_hb:vcode_input}">
                </div>
            </div>
            <!--{else}-->
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <i class="iconfont icon-dianhua2 main_color"></i>
                </div>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hb:mobile}</label></div>
                <div class="weui-cell__bd">
                    <input name="form[mobile]" class="weui-input" type="tel" placeholder="{lang xigua_hb:mobile_tip}" value="{echo $old_data ? $old_data[mobile]: $lastmobile}">
                </div>
            </div>
            <!--{/if}-->

            <!--{if $config[wxinput]}-->
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <i class="iconfont icon-weixin3 f12 main_color"></i>
                </div>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hb:wxh}</label></div>
                <div class="weui-cell__bd">
                    <input name="form[weixin]" class="weui-input" type="text" placeholder="{lang xigua_hb:qtxwxh}" value="{echo $old_data ?$old_data[weixin] : ''}">
                </div>
                <div class="weui-cell__ft">
                    <label class="weui-agree" onclick="syncweixin();" style="padding:0">
                        <input id="weuiAgree2" type="checkbox" value="2" readonly="readonly" class="weui-agree__checkbox">
                        <span class="weui-agree__text">{lang xigua_hb:wxdhth}</span>
                    </label>
                </div>
            </div>
            <!--{/if}-->

            <!--{if count($gs)>=2 && !$old_data}-->
            <div class="weui-cell weui-cell_select weui-cell_select-after">
                <div class="weui-cell__hd">
                    <i class="iconfont icon-erified main_color"></i>
                </div>
                <div class="weui-cell__hd">
                    <label  class="weui-label">{lang xigua_hb:shenfen}</label>
                </div>
                <div class="weui-cell__bd">
                    <select class="weui-select" name="form[uuid]">
                        <!--{loop $gs $uuid $uuinfo}-->
                        <option value="{$uuid}">{$uuinfo[username]}</option>
                        <!--{/loop}-->
                    </select>
                </div>
            </div>
            <!--{/if}-->

            <div class="btn-bottom ivu-form-item">
                <div class="ivu-form-item-content">
                    <button type="button" class="ivu-btn ivu-btn-large" style="margin-right:20px" onclick="window.location.href='$SCRITPTNAME?id=xigua_hb&ac=pub'"><span>��һ��</span></button>
                    <button type="button" class="ivu-btn ivu-btn-primary ivu-btn-large"><span>ȷ������</span></button>
                </div>
            </div>
        </div>
    </div>
</div>
</form>
<!--{/if}-->
</div>
<!--{template xigua_hb:common_footer}-->