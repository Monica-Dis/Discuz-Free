<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="content-wrapper">
    <div>
        <div class="auth-step auth-step1">
            <div style="margin-bottom: 30px;">
                <div class="step-title">
                    {lang xigua_hb:xuanlei}
                </div>
            </div>
            <div class="prompt">$config[pubtip]</div>

            <div class="ivu-form-item">
                <div class="ivu-form-item-content">
                    <div class="pubchckcat">
                        <!--{loop $list $cat}-->
                        <div>
                            <!--{if $config[pubhide] && $cat[cat_link]}-->
                            <!--{eval continue;}-->
                            <!--{/if}-->
                            <a class="nob" <!--{if !$cat[cat_link]}-->href="$SCRITPTNAME?id=xigua_hb&ac=pub&step=3&catid=$cat[id]"<!--{else}-->href="$cat[cat_link]"<!--{/if}-->>{$cat[name]}</a>
                            <!--{if $cat[child]}-->
                            <!--{loop $cat[child] $c}--><a <!--{if !$c[cat_link]}-->href="$SCRITPTNAME?id=xigua_hb&ac=pub&step=3&catid=$c[id]"<!--{else}-->href="$c[cat_link]"<!--{/if}-->>{$c[name]}</a><!--{/loop}-->
                            <!--{else}-->
                            <a <!--{if !$cat[cat_link]}-->href="$SCRITPTNAME?id=xigua_hb&ac=pub&step=3&catid=$cat[id]"<!--{else}-->href="$cat[cat_link]"<!--{/if}-->>{$cat[name]}</a>
                            <!--{/if}-->
                        </div>
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
            <div class="btn-bottom ivu-form-item" style="display:none">
                <div class="ivu-form-item-content">
                    <button type="button" class="ivu-btn ivu-btn-primary ivu-btn-large"><span>NEXT</span></button>
                </div>
            </div>
        </div>
    </div>
</div>