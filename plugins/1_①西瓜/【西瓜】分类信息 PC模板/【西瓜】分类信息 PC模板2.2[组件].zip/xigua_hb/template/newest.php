<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $cat_tree_all $tmp_k $tmp_v}-->
<div class="quanzhi inner home-inner item2">
    <div class="left">
        <div class="quanzhi-title">
            <div class="ele-pointer">{$tmp_v[name]}{lang xigua_hb:xinxi}</div>
        </div>
        <div class="quanzhi-logo ele-pointer"></div>
        <div class="quanzhi-logo-txt ele-pointer">{lang xigua_hb:yzxxqxk}</div>
        <div  class="quanzhi-recomand">
            <p style="width: 200px;overflow: hidden;display: block;margin: 0 auto;">
<!--{eval $i=0;}-->
<!--{loop $tmp_v[child] $__k $__v}-->
<!--{eval $tmp_v[childs][] = $__v['id'];}-->
    <a href="{echo $__v[cat_link] ? $__v[cat_link] : hb_pc_rewriteoutput('cat_page', $__v[id], $cityauto)}" target="_blank" >$__v[name]</a>
<!--{eval $i++;}-->
<!--{if $i%2==1}--><em class="vline v-line-spc"></em><!--{/if}-->
<!--{/loop}-->
            </p>
        </div><a href="{echo hb_pc_rewriteoutput('cat_page', $tmp_v[id])}" target="_blank"  class="quanzhi-more">{lang xigua_hb:ck}{lang xigua_hb:more}</a>
    </div>
    <div class="right recomand-content clearfix">
        <div>
            <!--{eval
            $in = $tmp_v[id];
            if($tmp_v[childs]):
                $in .= ','.implode(',', $tmp_v[childs]);
            endif;
            $where = array('display=1 AND endts>' . TIMESTAMP . ' AND catid IN ('.$in.')');
            $catpublist = C::t('#xigua_hb#xigua_hb_pub')->fetch_all_bypage_pub($where, 0, 8);
            }-->
            <!--{loop $catpublist $_k $_v}-->
            <!--{eval $_v[vars] = array_values($_v[vars]); $top3 = array_slice($_v[vars], 0, 3); $top3cnt = count($top3);}-->
            <a href="{echo hb_pc_rewriteoutput('view_page', $_v[id])}" target="_blank"  class="item" >
                <div class="item-title ellipsis <!--{if !$top3}-->towrow<!--{/if}-->">{echo strip_tags($_v[description])}</div>
                <p class="job-requirement ellipsis">
                    <!--{loop $top3 $__k $__v}-->
                    <!--{if !$__v[html]}-->
                    <!--{eval continue;}-->
                    <!--{/if}-->
                    <span>$__v[html]</span>
                    <!--{if $__k<$top3cnt-1}-->
                    <em class="vline"></em>
                    <!--{/if}-->
                    <!--{/loop}-->
                </p>
                <p class="job-compnay ellipsis">{$newlist_cat_all[$_v[catid]][name]}</p>
                <div class="job-salary-box">
                    <!--{if $_v[vars][0][html]}-->
                    <div class="salary-container" >
                        <span class="salary">{echo cutstr(str_replace(' ', '', $_v[vars][0][html]), 14)}</span>
                    </div>
                    <!--{else}-->{echo $_v[realname]!='-' ? $_v[realname]:''}{$_v[time_u]}{lang xigua_hb:fabu0}
                    <!--{/if}-->
                    <!--{if $_v[tags][0]}-->
                    <span class="bao-tag"><em>{$_v[tags][0]}</em></span>
                    <!--{/if}-->
                </div>
            </a>
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{/loop}-->