<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<div class="inner home-inner">
    <div class="search-box ">
        <div class="search-form clearfix ">
            <div  class="clearfix">
                <div class="search-form-con">
                    <div class="position-sel search-form-ele" style="width:0;background:transparent;padding-left:12px"></div>
                    <form  action="$SCRITPTNAME" method="get" id="searchForm">
                        <input type="hidden" name="id" value="xigua_hb">
                        <input type="hidden" name="ac" value="cat">
                        <input type="hidden" name="st" value="$_GET[st]">
                        <input type="hidden" name="idu" value="$_GET[idu]">
                    <div class="ipt-wrap">
                        <input type="text" name="keyword" autocomplete="off" maxlength="50" placeholder="$config[sousuoinput]" class="ipt-search search-form-ele"  <!--{if $keyword}-->value="$keyword"<!--{/if}-->>
                    </div>
                    </form>
                    <div class="search-btn">
                        <i class="icon search-icon"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="inner home-content">
    <div class="filterwraper">
        <div class="filterarea">
            <div class="area clearfix"><span class="areatitle">{lang xigua_hb:plugins_edit_vars_type_area}{lang xigua_hb:m}</span>
                <div class="arearight inlineblock">
                    <a  class="first_check areaitem<!--{if !$_GET[province]}-->active<!--{/if}-->" href='{eval echo hb_pc_rewriteoutput("cat_page", $cat_id, "province=&city=&orderby=$orderby&keyword=".urlencode($keyword)."&lat=$lat&lng=$lng&filter=".urlencode($filter));}'>{lang xigua_hb:quanbu}</a>
                    <!--{loop $dist0 $v}-->
                    <a class="first_check areaitem<!--{if $_GET[province]==$v[name]}-->active<!--{eval $city_id=$v['id'];}--><!--{/if}-->" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($v[name]);}&city=&orderby=$orderby&keyword={echo urlencode($keyword);}&lat=$lat&lng=$lng&filter={echo urlencode($filter);}{$urlext}">$v[name]</a>
                    <!--{/loop}-->

                    <!--{loop $dist0 $k $v}-->
                    <!--{if $_GET[province]!=$v['name']}--><!--{eval continue;}--><!--{/if}-->
                    <div class="subcat_text sub_cheker" id="sub_cheker_$v[id]">
                        <a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($v[name]);}&city=&orderby=$orderby&keyword={echo urlencode($keyword);}&lat=$lat&lng=$lng&filter={echo urlencode($filter);}{$urlext}" class="fareitem fareitem<!--{if !$_GET[city]}-->active<!--{/if}-->">{lang xigua_hb:quan}{$v[name]}</a>
                        <!--{loop $v[child] $vv}-->
                        <a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($v[name]);}&city={echo urlencode($vv[name]);}&orderby=$orderby&keyword={echo urlencode($keyword);}&lat=$lat&lng=$lng&filter={echo urlencode($filter);}{$urlext}" id="sub_check{$vv[id]}" class="fareitem fareitem<!--{if $city==$vv[name]&&$_GET[city]}-->active<!--{/if}-->">$vv[name]</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->

                </div>
            </div>
            <div class="fare clearfix"><span class="faretitle">{lang xigua_hb:cat}{lang xigua_hb:m}</span>
                <div class="arearight inlineblock">
                    <a class="first_cat_check fareitem<!--{if !$cat_id}-->active<!--{/if}-->" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=$orderby&lat=$lat&lng=$lng&filter={echo urlencode($filter);}{$urlext}">{lang xigua_hb:buxian}</a>
                    <!--{loop $cat_tree $k $v}-->
                    <!--{if !$v[cat_link]}-->
                    <a class="first_cat_check fareitem<!--{if $cat_id==$v[id]||$pid==$v[id]}-->active<!--{/if}-->" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$v[id]&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=$orderby&lat=$lat&lng=$lng&filter={echo urlencode($filter);}{$urlext}">$v[name]</a>
                    <!--{else}-->
                    <a class="first_cat_check fareitem<!--{if $cat_id==$v[id]||$pid==$v[id]}-->active<!--{/if}-->" href="$v[cat_link]">$v[name]</a>
                    <!--{/if}-->
                    <!--{/loop}-->
                    <!--{loop $cat_tree $k $v}-->
                    <!--{if !($cat_id==$v[id]||$pid==$v[id]) || !$v[child]}--><!--{eval continue;}--><!--{/if}-->
                    <div class="subcat_text" id="sub_cat_cheker_$v[id]">
                        <a class="sub_cat_check fareitem<!--{if $cat_id==$v[id]}-->active<!--{/if}-->" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$v[id]&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=$orderby&lat=$lat&lng=$lng&filter={echo urlencode($filter);}{$urlext}">{lang xigua_hb:quanbu}</a>
                        <!--{loop $v[child] $vv}-->
                        <a class="sub_cat_check fareitem<!--{if $cat_id==$vv[id]}-->active<!--{/if}-->"  href="<!--{if $vv[cat_link]}-->$vv[cat_link]<!--{else}-->$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$vv[id]&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=$orderby&lat=$lat&lng=$lng&filter={echo urlencode($filter);}{$urlext}<!--{/if}-->">$vv[name]</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
            </div>
            <!--{if $tag_childs}-->
            <div class="money clearfix">
                <span class="faretitle">{lang xigua_hb:tags}{lang xigua_hb:m}</span>
                <div class="arearight inlineblock">
                    <a href="$SCRITPTNAME?id=xigua_hb&ac=cat&$query" class="moneyitem moneyitem<!--{if !$_GET[tag]}-->active<!--{/if}-->">{lang xigua_hb:buxian}</a>
                    <!--{loop $tag_childs $_kk $tag_child}-->
                    <!--{eval $tag_child = trim($tag_child);}-->
                    <a href="$SCRITPTNAME?id=xigua_hb&ac=cat&$query&tag={echo urlencode($tag_child);}" class="moneyitem moneyitem<!--{if $tag_child==$_GET[tag]}-->active<!--{/if}-->">$tag_child</a>
                    <!--{/loop}-->
                </div>
            </div>
            <!--{/if}-->
        </div>
    </div>
    <div class="bigblock clearfix">
        <div class="listblock">
            <div id="recentblock" class="filterwraper">
                <div class="listfilter clearfix">
                    <div class="leftzone  z">
                        <span  style="display:inline-block;">
                            <a class="sort <!--{if !$orderby && !$_GET[hb]}-->active<!--{/if}-->" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">$orderby_list['']</a>
                            <a class="news <!--{if $orderby=='hot'}-->active<!--{/if}-->" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=hot&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">$orderby_list[hot]</a>
                            <a class="news <!--{if $orderby=='new'}-->active<!--{/if}-->" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=new&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">$orderby_list[new]</a>
                            <a class="top <!--{if $orderby=='zan'}-->active<!--{/if}-->" href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=zan&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}">{lang xigua_hb:dz1}</a>
                        </span>
                    </div>
                    <div class="rightzone y">
                        <span class="guaree"><label class="checkouter"><input data-href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=img&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}" type="checkbox" name="guaree" class="checkit" <!--{if $orderby=='img'}-->checked<!--{/if}-->><span class="gap6">{lang xigua_hb:zk}{$orderby_list[img]}</span></label></span>
                    </div>
                </div>
            </div>
            <div class="listwraper">
                <div id="list" class="listitems mod-post x-postlist pt0"></div>
                <div href="javascript:;" class="load-more"> {lang xigua_hb:ck}{lang xigua_hb:more} <i class="iconfont icon-jinrujiantou f14"></i></div>
                <div class="weui-loadmore weui-loadmore_line">
                    <div class="hs_empty"><i class="icon iconfont icon-zanwuwenda"></i><p>{lang xigua_hb:zanwugengduo}</p></div>
                </div>
            </div>
        </div>
        <!--{template xigua_hb:left_box}-->
    </div>
</div>
<script>
var loadingurl = '$SCRITPTNAME?id=xigua_hb&cat_id=$_GET[cat_id]&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby={$_GET[orderby]}&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}{$urlext}&ac=list_item&inajax=1&page=';
</script>
<!--{template xigua_hb:common_footer}-->