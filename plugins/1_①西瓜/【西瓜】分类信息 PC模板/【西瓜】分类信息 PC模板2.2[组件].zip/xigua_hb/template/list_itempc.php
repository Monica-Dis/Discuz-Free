<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{loop $list $k $v}-->
<!--{eval
$msg = (str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v[description]))));
$price1 = array_slice($v[vars], 0, 1);
if(!$price1[0][autoin]):
$price1 = $price1[0][html]?$price1[0][html]:$price1[0][value];
else:
$price1 = '';
endif;
$v[vars] = array_slice($v[vars], 1);
$line1 = array();
foreach($v[vars] as $__k=> $__v):
    if($__v[type]=='pics' || $__v[type]=='linkurl'):
        unset($v[vars][$__k]);
        continue;
    endif;
    if(count($line1)<3):
        $line_text = $__v[html] ?$__v[html] :$__v[value];
        if($line_text):
            unset($v[vars][$__k]);
            $line1[] = $line_text;
        endif;
    endif;
endforeach;
$line1 = implode('<em>/</em>', $line1);
$showideo = $v['video_cover'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php');
$v[vars] = array_values($v[vars]);
$stext = $v[stid]>0? "&st=$v[stid]" :'';
}-->
<a class="card_row view_jump" data-id="$v[id]" data-stid="$v[stid]" target="_blank" href="{echo hb_pc_rewriteoutput('view_page', $v[id], $stext)}">
    <div class="card_left">
        <img class="card_abs_img" src="<!--{if $v[img_preview][0]}-->$v[img_preview][0]<!--{elseif $showideo}-->$v[video_cover]<!--{/if}-->" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'">
        <!--{if $showideo}-->
        <div class="card_video_play"></div>
        <!--{/if}-->
    </div>
    <div class="card_right"><h3>
            <!--{if $v[dig_on]}--><span class="mod_lv is-star" style="margin-left:0"><!--{if $v[zdword]}-->$v[zdword]<!--{else}-->{lang xigua_hb:zhiding}<!--{/if}--></span><!--{/if}-->
            <!--{if $v[hb_num]}--><span class="mod_lv is-hot" style="margin-left:0">{lang xigua_hb:hb}</span><!--{/if}-->
            <span class="mod_lv is-red">{$cats[$v[catid]][name]}</span> {$msg}</h3>
        <!--{if $line1}--><div class="car_info">{$line1}</div><!--{/if}-->
        <!--{if $price1}--><div class="car_info2"><span class="priceC"><i class="ifoset">$price1</i></span></div><!--{/if}-->
        <div class="bt_box">
            <ul class="tagsS">
                <!--{loop $v[tags] $___k $tag}--><!--{if $tag}--><li class="card_car_tag blue"><i>$tag</i></li><!--{/if}--><!--{/loop}-->
                <!--{loop $v[vars] $_k $_v}--><!--{eval $__varhtml = $_v[html] ? $_v[html] : $_v[value];}--><!--{if $__varhtml}--><li class="card_car_tag grayY"><i>$__varhtml</i></li><!--{/if}--><!--{/loop}-->
            </ul>
        </div>
    </div>
</a>
<!--{/loop}-->