<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function hb_pc_rewriteoutput($type = 'index_page') {
    global $_G, $SCRITPTNAME, $urlext;
    $fextra = '';
    $cache_key = 'hb_seo_setting';
    loadcache($cache_key);
    $hb_seo_setting = $_G['cache'][$cache_key];
    $r = array();
    if($urlext=='?'){
        $urlext = '';
    }
    switch ($type){
        case 'index_page':
            list( , $param) = func_get_args();
            if($param) {
                $fextra = '?'.$param;
            }
            if(!$hb_seo_setting['open']){
                return rtrim("$SCRITPTNAME?id=xigua_hb&{$param}{$urlext}", '&');
            }
            break;
        case 'cat_page':
            list( , $catid, $param) = func_get_args();
            if($param) {
                $fextra = '?'.$param;
            }
            $r = array(
                '{catid}' => $catid
            );
            if(!$hb_seo_setting['open']){
                return rtrim("$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id={$catid}&{$param}{$urlext}", '&');
            }
            break;
        case 'view_page':
            list( , $pubid, $param) = func_get_args();
            if($param) {
                $fextra = '?'.$param;
            }
            $r = array(
                '{pubid}' => $pubid
            );
            if(!$hb_seo_setting['open']){
                return rtrim("$SCRITPTNAME?id=xigua_hb&ac=view&pubid={$pubid}&{$param}{$urlext}", '&');
            }
            break;
        case 'hsindex_page':
            list( , $param) = func_get_args();
            if($param) {
                $fextra = '?'.$param;
            }
            if(!$hb_seo_setting['open']){
                return rtrim("$SCRITPTNAME?id=xigua_hs&{$param}{$urlext}", '&');
            }
            break;
        case 'hangye_page':
            list( , $hyid, $param) = func_get_args();
            if($param) {
                $fextra = '?'.$param;
            }
            $r = array(
                '{hyid}' => $hyid
            );
            if(!$hb_seo_setting['open']){
                return rtrim("$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid={$hyid}&{$param}{$urlext}", '&');
            }
            break;
        case 'shop_page':
            list( , $shid, $param) = func_get_args();
            if($param) {
                $fextra = '?'.$param;
            }
            $r = array(
                '{shid}' => $shid
            );
            if(!$hb_seo_setting['open']){
                return rtrim("$SCRITPTNAME?id=xigua_hs&ac=view&shid={$shid}&{$param}{$urlext}", '&');
            }
            break;
    }
    return str_replace(array_keys($r), $r, $hb_seo_setting[$type]) . $fextra;
}