<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_common.php';
if (!$hb_setting):
    $cache_key = 'hb_ext_setting';
    loadcache($cache_key);
    $hb_setting = $_G['cache'][$cache_key];
endif;
if ($hb_setting['open']) {
    if (!checkmobile()) {
        switch ($ac) {
            case 'index':
                $list_cat_all = C::t('#xigua_hb#xigua_hb_cat')->list_all();
                C::t('#xigua_hb#xigua_hb_cat')->init($list_cat_all);
                $cat_tree_all = C::t('#xigua_hb#xigua_hb_cat')->get_tree_array(0);
                $newlist_cat_all = array();
                foreach ($list_cat_all as $index => $item) {
                    $newlist_cat_all[$item['id']] = $item;
                }
                if ($hs_config = $_G['cache']['plugin']['xigua_hs']) {
                    $totalviews += C::t('#xigua_hs#xigua_hs_shanghu')->total_views();
                    $totalsh = C::t('#xigua_hs#xigua_hs_shanghu')->count();
                    $hangyes = C::t('#xigua_hs#xigua_hs_hangye')->list_by_pid(0, TRUE);
                    $new_hangyes = array_chunk(array_slice($hangyes, 0, 8), 2);
                    $wherenew = array();
                    $wherenew[] = 'display=1 AND endts>=' . TIMESTAMP;
                    $shlist = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($wherenew, 0, 10, 'dig_endts DESC, views DESC', 'shid,name,logo');
                }

                if ($config['fid_s']) {
                    $tidlist = C::t('#xigua_hb#xigua_hb_pub')->fetch_thread_for_index_light(0, 7);
                    $_fid = explode(',', $config['fid_s']);
                    $_fid = intval($_fid[0]);
                }
                $newjing_list = array_chunk(array_slice($jing_list, 0, 8), 2);

                $where = array('display=1 AND endts>' . TIMESTAMP . '');
                $diglist = C::t('#xigua_hb#xigua_hb_pub')->fetch_all_bypage_pub($where, 0, 6);
                if ($hb_setting['tuijian']) {
                    $tujid = dintval(explode('|', $hb_setting['tuijian']), 1);
                    if ($tujid) {
                        $where[] = ' id in (' . implode(',', $tujid) . ')';
                        $tuijianlist = C::t('#xigua_hb#xigua_hb_pub')->fetch_all_bypage_pub($where, 0, 12);
                    }
                }

                include template('xigua_hb:index3');
                exit;
                break;
            case 'cat':
                include template('xigua_hb:cat');
                exit;
                break;
            case 'view':
                $pubid = $pubid;
                if (!$hb_setting):
                    $cache_key = 'hb_ext_setting';
                    loadcache($cache_key);
                    $hb_setting = $_G['cache'][$cache_key];
                endif;
                if ($hb_setting['tuijian']) {
                    $where = array('display=1 AND endts>' . TIMESTAMP . '');
                    $tujid = dintval(explode('|', $hb_setting['tuijian']), 1);
                    if ($tujid) {
                        $where[] = ' id in (' . implode(',', $tujid) . ')';
                        $tuijianlist = C::t('#xigua_hb#xigua_hb_pub')->fetch_all_bypage_pub($where, 0, 12);
                    }
                }
                $likeslist = C::t('#xigua_hb#xigua_hb_pub')->fetch_all_bypage_pub(array('display=1 AND endts>' . TIMESTAMP . ' AND (catid=' . intval($v['catid']) . ' OR catid='.intval($catinfo['pid']).' ) AND id!=' . $pubid), 0, 3, 'rand() desc');
//            dmp($likeslist);
                if ($config['qraut']) {
                    $qrcodeurl1 = "$SCRITPTNAME?id=xigua_hb:qrauto&ode=pub_{$pubid}{$urlext}";
                } else {
                    $qrcodeurl1 = "$SCRITPTNAME?id=xigua_hb:qrcode&pubid={$pubid}{$urlext}";
                }
                include template('xigua_hb:viewpc');
                exit;
                break;
            case 'pub':
                if($_G['uid']==1){
                    if($_GET['step']==3 && !$_GET['catid']){
                        dheader("Location: $SCRITPTNAME?id=xigua_hb&ac=pub".$urlext);
                    }
                    include DISCUZ_ROOT.'source/plugin/xigua_hb/include/ext.php';
                    include template('xigua_hb:pub2');
                    exit;
                }
                break;
        }
    }
}
