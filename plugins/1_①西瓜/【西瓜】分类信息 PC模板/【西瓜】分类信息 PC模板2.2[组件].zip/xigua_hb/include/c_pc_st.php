<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_common.php';
$hb_currenturl = hb_currenturl();
$hb_currenturl = preg_replace('/\&st\=\-?\d+/', '', $hb_currenturl);

$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
if($hb_currenturl == $sys_protocal.$_SERVER['HTTP_HOST'].'/'){
    $hb_currenturl = hb_pc_rewriteoutput('index_page');
}
if(strpos($hb_currenturl, '?')===false):
    $hb_currenturl.= '?';
endif;
global $hotcity, $abccity, $abccitys, $ac;
$hotcity = DB::fetch_all("select * from %t WHERE status=1 AND ishot=1 ORDER BY displayorder DESC", array('xigua_st'), 'stid');
$abccity = DB::fetch_all("select * from %t WHERE status=1 ORDER BY szm ASC, displayorder DESC", array('xigua_st'), 'stid');
$abccitys = array();
foreach ($abccity as $index => $item):
    if($st_config['shaitype']==1):
        $abccitys[$item['szm']][] = $item;
    else:
        $abccitys[$item['area1']][] = $item;
    endif;
endforeach;