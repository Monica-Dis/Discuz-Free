<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (!$hb_setting):
    $cache_key = 'hb_ext_setting';
    loadcache($cache_key);
    $hb_setting = $_G['cache'][$cache_key];
endif;
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_common.php';
if ($hb_setting['open']) {
    if (!checkmobile()) {
        switch ($ac) {
            case 'list_item':
                $tpl = 'xigua_hb:list_itempc';
                break;
        }
    }
}