<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<style>
#map_box{width:100%;height:80vw;max-height:32rem}
img.csssprite{border-radius:1.6rem}
.infowin{font-size:.7rem;display:flex}
.infowin .infologo{margin-right:.5rem}
.infowin img{width:2rem;height:2rem;display:block}
.infoaddr p:first-child{font-size:.7rem;color:#333;white-space:nowrap}
.infoaddr p:last-child{font-size:.6rem;color:#666;white-space:nowrap}
.pbtn{color:#fff;line-height:1.4rem;font-size:.6rem;padding:0 .25rem;width:4.5rem;margin-top:.5rem}
<!--{if $_GET['showmap']==2}-->
#list3,.weui-tabbar,.weui-loadmore{display:none}#map_box{height:100vh;max-height:100%}
<!--{elseif $_GET['showmap']==3}-->
#list3,.weui-tabbar,.weui-loadmore,.x_header,.x_header_fix,.fix_float_fix,.weui-navbar,.banner_fix{display:none}
#map_box{height:100vh;max-height:100%;position:absolute !important;top:0;left:0;z-index:500;}
.btmmapc{position: absolute;z-index: 502;background: #fff;border-radius: .5rem;bottom: 1rem;width: calc(100% - 3.5rem);left: 1rem;padding: .75rem;box-shadow: 1px 1px 10px rgba(0,0,0,0.1);}
<!--{/if}-->
</style>
<div id="map_box"></div>
<div id="list3" class="mod-post x-postlist pt0"></div>
<!--{template xigua_hb:loading}-->
<!--{if $_GET['showmap']==3}-->
    <div class="btmmapc" style="display:none">
        <div>xxxx</div>
        <div>
            <a>xxx</a>
            <a>xxx</a>
        </div>
    </div>
<!--{/if}-->