<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$query = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_st` (
 `stid` int(11) NOT NULL AUTO_INCREMENT,
 `name` varchar(200) NOT NULL,
 `status` int(1) NOT NULL,
 `icon` varchar(500) NOT NULL,
 `description` varchar(500) NOT NULL,
 `ratio` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `username` varchar(80) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `qr` varchar(512) NOT NULL,
 PRIMARY KEY (`stid`),
 KEY `uid` (`uid`),
 KEY `endts` (`endts`),
 KEY `status` (`status`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_st_income` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `reach` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `indate` date NOT NULL,
 `money` decimal(10,2) NOT NULL,
 `ratio` decimal(10,2) NOT NULL,
 `info` text NOT NULL,
 `stid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `crts` (`crts`),
 KEY `indate` (`indate`),
 KEY `reach` (`reach`),
 KEY `stid` (`stid`)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS `pre_xigua_st_shenqing` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `order_id` varchar(200) NOT NULL,
 `note` varchar(800) NOT NULL,
 `upts` int(11) NOT NULL,
 `pay_ts` int(11) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `checkstid` varchar(80) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `crts` (`crts`),
 KEY `stid` (`stid`),
 KEY `orderid` (`order_id`)
) ENGINE=InnoDB;
SQL;

runquery($query);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_st/discuz_plugin_xigua_st.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_st/discuz_plugin_xigua_st_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_st/discuz_plugin_xigua_st_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_st/discuz_plugin_xigua_st_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_st/discuz_plugin_xigua_st_TC_UTF8.xml');

$finish = TRUE;


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'uid2\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `uid2` VARCHAR(1000) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hs_name\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `hs_name` VARCHAR(200) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `hs_desc` VARCHAR(500) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `area1` VARCHAR(80) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD INDEX(`area1`);


SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'area2\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL


ALTER TABLE `pre_xigua_st` ADD `area2` VARCHAR(80) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `area3` VARCHAR(80) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `index_topad` TEXT NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `index_midad` TEXT NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `sh_topad` TEXT NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `color` VARCHAR(20) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `color_title` VARCHAR(20) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `doamin` VARCHAR(512) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `index_topad_lnk` TEXT NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `index_midad_lnk` TEXT NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `sh_topad_lnk` TEXT NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `showcnt` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD INDEX(`area2`);

ALTER TABLE `pre_xigua_st` ADD INDEX(`area3`);

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'displayorder\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `displayorder` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD INDEX(`displayorder`);

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'cats\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `cats` VARCHAR(1000) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD INDEX(`cats`);

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'name2\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `name2` VARCHAR(20) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'nohhrate\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `nohhrate` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `shprice` varchar(2000) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'szm\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `szm` VARCHAR(20) NOT NULL;

ALTER TABLE `pre_xigua_st` ADD `ishot` INT(1) NOT NULL DEFAULT '-1';

ALTER TABLE `pre_xigua_st` ADD INDEX(`szm`);

ALTER TABLE `pre_xigua_st` ADD INDEX(`ishot`);

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'orderid\'', array('xigua_st_income'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st_income` ADD `orderid` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_st_income` ADD INDEX(`orderid`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'lng\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `lat` VARCHAR(32) NOT NULL;
ALTER TABLE `pre_xigua_st` ADD `lng` VARCHAR(32) NOT NULL;
ALTER TABLE `pre_xigua_st` ADD `length` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_st` ADD INDEX(`lat`);
ALTER TABLE `pre_xigua_st` ADD INDEX(`lng`);
ALTER TABLE `pre_xigua_st` ADD INDEX(`length`);

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'tid\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `tid` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'joinprice\'', array('xigua_st'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_st` ADD `joinprice` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}

@unlink(DISCUZ_ROOT . './source/plugin/xigua_st/install.php');
