<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
$st_config = $_G['cache']['plugin']['xigua_st'];
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET); //d'.'is'.'m.tao'.'ba'.'o.com
}

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_st#xigua_st_shenqing')->deletes($delete);
    }
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_shenqing", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey(addslashes($_GET['keyword']));
if($keyword){
    $intk = intval($keyword);
    if($intk){
        $wherearr[] = "(uid='$keyword' OR stid='$keyword' OR checkstid='$keyword')";
    }else{
        $wherearr[] = "(checkstid='$keyword' OR note like '%$keyword%')";
    }
}else{
    $wherearr[] = "1";
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_shenqing");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_st('uidstinfo', 0).'" value="'.$_GET['keyword'].'" class="txt" /> ';
echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo '</div>';

showtableheader(lang_st('shenqmanage', 0));
showtablerow('class="header"',array(),array(
    lang_hb('del', 0),
    lang_hb('ID', 0),
    lang_st('shenqingren', 0),
    lang_st('jmf', 0),
    lang_st('sqzd', 0),
    lang_st('sqyy', 0),
    lang_st('crts', 0),
));

$res = C::t('#xigua_st#xigua_st_shenqing')->fetch_all_by_page($start_limit, $lpp, $wherearr);
$icount = C::t('#xigua_st#xigua_st_shenqing')->fetch_count_by_page($wherearr);

$uids = array();
foreach ($res as $v) {
    $uids[] = $v['uid'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}

foreach ($res as $v) {
    $id = $v['id'];
    $uid = $v['uid'];
    $info = $v['note'];

    $crts = date('Y-m-d H:i:s', $v['crts']);

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",$id,
        "[uid:$uid]<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
'<p>'.    $v['price'].'</p>'.
'<p>'. lang_hb('orderid',0) . ': ' .  $v['order_id'].'</p>'.
'<p>'. lang_hb('zhifushijian1',0). ': ' .($v['pay_ts'] ? date('Y-m-d H:i:s', $v['pay_ts']) : '<em style="color:red">'.lang_hb('wei',0) .'<em>').'</p>'
    ,
        $v['checkstid'],
        $info,
        $crts,
    ));
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_shenqing&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); //From: Dism��taobao��com
showformfooter(); //From: Dism_taobao-com

function lang_st($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_st', $lang);
    }else{
        return lang('plugin/xigua_st', $lang);
    }
}