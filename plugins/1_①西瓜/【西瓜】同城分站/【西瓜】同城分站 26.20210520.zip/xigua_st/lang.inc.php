<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$plugin = 'xigua_st';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";

loadcache('pluginlanguage_script');

if(submitcheck('dosubmit')){
    if(checkmobile()){
        cpmsg('not allow!', "action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=lang", 'succeed');
    }


    $cache = DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
    $data = unserialize($cache);
    $data[$plugin] = $_GET['configary1'];
    C::t('common_syscache')->update('pluginlanguage_template', $data);
    unset($data);

    $cache = DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
    $data = unserialize($cache);
    $data[$plugin] = $_GET['configary1'];
    C::t('common_syscache')->update('pluginlanguage_script', $data);


    cpmsg(lang('plugin/xigua_st', 'succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=lang", 'succeed');
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=lang");
showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com


foreach ($_G['cache']['pluginlanguage_script'][$plugin] as $arr => $item) {
    showsetting($arr, 'configary1['.$arr.']', $item, 'text', 0, 0 );
}

showsubmit('dosubmit');
showtablefooter(); //From: Dism��taobao��com
showformfooter(); //From: Dism_taobao-com
