<?php
/**
 * Created by DisM.
 * User: DisM!应用中心
 * From: DisM.taobao.Com
 * 本资源来源于网络收集,仅供个人学习交流，请勿用于商业用途，并于下载24小时后删除!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_G['uid']!=1){
    exit('no access');
}

$sqltpl = <<<SQL
INSERT IGNORE INTO `pre_xigua_st` (`stid`, `name`, `status`, `icon`, `description`, `ratio`, `uid`, `username`, `crts`, `upts`, `endts`, `hs_name`, `hs_desc`, `area1`, `area2`, `area3`, `qr`, `index_topad`, `index_midad`, `sh_topad`, `color`, `color_title`, `doamin`, `index_topad_lnk`, `index_midad_lnk`, `sh_topad_lnk`, `showcnt`, `displayorder`, `cats`, `name2`, `nohhrate`, `shprice`, `szm`, `ishot`, `lat`, `lng`, `length`, `uid2`, `tid`) VALUES
(NULL, '======', 1, '', '', 0, 0, '', 1595667278, 1595667278, 0, '', '', '----', '____', '||||||', '', '', '', '', '', '', '', 'a:0:{}', 'a:0:{}', 'a:0:{}', 0, 0, '', '======', 0, '', '', -1, '', '', 0, '', '');
SQL;


$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(2);
$dist1 = DB::fetch_all('SELECT * FROM %t WHERE ' . DB::field('level', 1) . ' order by displayorder desc', array('xigua_hb_district'), 'id');
//dmp($dist1);
//dmp($dist0);

foreach ($dist0 as $index => $item) {
    echo str_replace(array('____', 1595667278, '----', '||||||', '======'), array($item['name'], TIMESTAMP, $dist1[$item['upid']]['name'], '', $item['name']), $sqltpl).'<BR>';

    $dist3 = DB::fetch_all('select * from %t where upid=%d', array('xigua_hb_district', $item['id']));
    foreach ($dist3 as $index3 => $item3) {
        if($item3['name']){
            echo str_replace(array('____', 1595667278, '----', '||||||', '======'), array($item['name'], TIMESTAMP, $dist1[$item['upid']]['name'], $item3['name'], $item3['name']), $sqltpl).'<BR>';
        }
    }

}