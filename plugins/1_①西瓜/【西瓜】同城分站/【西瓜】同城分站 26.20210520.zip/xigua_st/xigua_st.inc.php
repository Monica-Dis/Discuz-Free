<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_st/function.php';
global $_G, $st_config, $aclist, $aclist_login, $ac, $do, $isself, $page, $lpp, $start_limit;
$st_config = $_G['cache']['plugin']['xigua_st'];
$aclist = array('my', 'set', 'income', 'income_li', 'city', 'comset', 'shenqing', 'dist_li', 'checkfee');
$aclist_login = array('my', 'set', 'income', 'income_li', 'comset', 'shenqing');
$ac = $_GET['ac'];
$do = $_GET['do'];
if (!in_array($ac, $aclist)) {
    $ac = 'index';
}
$isself = in_array($ac, $aclist_login) || (strpos($ac, 'my') !== false && !$_G['uid']);
if ($isself && !$_G['uid']) {
    hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET); //d'.'is'.'m.tao'.'ba'.'o.com
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;

$urlext = '&st=' . $_GET['st'];
if (in_array($ac, $aclist_login) && $ac != 'shenqing') {
    $stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status_uid($_G['uid']);
    if (!$stinfo) {
        dheader("Location: $SCRITPTNAME?id=xigua_hb" . $urlext);
    }
    $stid = $stinfo['stid'];
    $urlext = '&st=' . $stid;
}
switch ($ac) {
    case 'shenqing':
        global $_G, $uid, $config, $navtitle, $SCRITPTNAME, $urlext, $st_config, $abccity, $projson;
        hb_check_bind(8);
        $navtitle = lang_st('sqcwzz', 0);
        if(!$st_config['newshenqing']){
            $abccity = DB::fetch_all("select * from %t WHERE uid=0 ORDER BY szm ASC, displayorder DESC", array('xigua_st'), 'stid');
            $projson = array();
            if ($abccity) {
                foreach ($abccity as $pro) {
                    $projson[] = $pro['name'];
                }
            }
            $projson[] = lang_st('dmy', 0);
        }elseif(0){
            $hassts = DB::fetch_all("select stid,name2 from %t WHERE uid>0", array('xigua_st'), 'name2');
            $hassts = array_keys($hassts);
        }
        $_key = 'hbpubIdist'.intval($_GET['st']);
        loadcache($_key);
        if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
            C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
            $distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
            $distjsary = array_values($distjsary);
            savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
        } else {
            $distjsary = $_G['cache'][$_key]['variable'][0];
        }
        $st_config['maxareawant'] = 1;

        if (submitcheck('formhash')) {
            if ($st_config['zzjmf'] <= 0) {
                hb_message('error', 'error');
            }
            $form = $_GET['form'];
            if (!$form['note']) {
                hb_message(lang_st('qtxsqyy', 0), 'error');
            }
            $name = $form['checkstid'];
            $abccity = DB::fetch_first("select * from %t WHERE (name=%s OR name2=%s OR area1=%s OR area2=%s OR area3=%s)", array('xigua_st', $name, $name, $name, $name, $name));
            $money = $abccity['joinprice']>0?$abccity['joinprice']:$st_config['zzjmf'];
            if($abccity['uid']>0){
                hb_message(lang_st('hasshenqing', 0), 'error');
            }
            if ($money > 0) {
                $log = array(
                    'uid' => $_G['uid'],
                    'crts' => TIMESTAMP,
                    'upts' => 0,
                    'pay_ts' => 0,
                    'order_id' => '',
                    'price' => $money,
                    'note' => $form['note'],
                    'checkstid' => $form['checkstid'],
                );
                $stidauto = $abccity? $abccity['stid'] : 0;

                $lodig = C::t('#xigua_st#xigua_st_shenqing')->insert($log, 1);
                $log['id'] = $lodig;

                $url = "$SCRITPTNAME?id=xigua_hb&ac=my&ac=myorder{$urlext}";

                $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $money, $_G['username'] . lang_st('sqjm', 0) . $form['checkstid'] . '' . $money . lang_hb('yuan', 0), 'common_jm', array(
                    'data' => array($log, $stidauto),
                    'callback' => array(
                        'file' => 'source/plugin/xigua_st/function.php',
                        'method' => 'st_callback_shenqing'
                    ),
                    'location' => $_GET['backto'] ? $_GET['backto'] : $_G['siteurl'] . $url,
                ));
                C::t('#xigua_st#xigua_st_shenqing')->update($lodig, array('order_id' => $order_id));

                $rl = urlencode($url);
                $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl" . $urlext) . $urlext;
                hb_message(lang_st('jumppay', 0), 'success', $jumpurl);
            }
        }

        break;
    case 'my':
        global $config, $navtitle, $_G, $today_sum, $total_sum, $hbuser, $hb_money;
        $navtitle = $config['tname'] . lang_st('gl', 0);;
        $today_sum = C::t('#xigua_st#xigua_st_income')->sum_today_by_uid($_G['uid']);
        $total_sum = C::t('#xigua_st#xigua_st_income')->sum_total_by_uid($_G['uid']);
        $hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);

        $today_sum = round($today_sum, 2);
        $total_sum = round($total_sum, 2);
        $hb_money = round($hbuser['money'], 2);
        $stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status_uid($_G['uid']);

        break;
    case 'income':
        global $_G, $uid, $config, $navtitle, $SCRITPTNAME, $urlext, $custom_side;
        $uid = intval($_G['uid']);
        $navtitle = $config['tname'] . lang_st('sr', 0);
        $custom_side = array(
            "$SCRITPTNAME?id=xigua_hb&ac=qianbao" . $urlext,
            lang_hb('qb', 0)
        );
        break;
    case 'income_li':
        global $config, $where, $_G, $uid, $start_limit, $lpp, $list;
        $uid = intval($_G['uid']);
        $where = array();
        $where[] = "uid=$uid";
        $where[] = 'reach=1';
        $list = C::t('#xigua_st#xigua_st_income')->fetch_u_order($where, $start_limit, $lpp);
        include template('xigua_hb:header_ajax');
        include template('xigua_st:income_li');
        include template('xigua_hb:footer_ajax');
        break;
    case 'set':
        $old_data = $stinfo;
        global $shcolor, $st_config;
        $shcolor = array();
        if ($st_config['colors']) {
            foreach (explode("\n", trim($st_config['colors'])) as $index => $item) {
                list($_color, $_title) = explode('=', trim($item));
                $shcolor[$_title] = trim($_color);
            }
        }
        if (submitcheck('formhash')) {
            $form = $_GET['form'];
            if (!$form['name'] || !$form['stid']) {
                hb_message(lang_st('qtxname', 0), 'error');
            }
            if (!$form['description']) {
                hb_message(lang_st('qtxdesc', 0), 'error');
            }
            if (!$form['icon'][0]) {
                hb_message(lang_st('qsczdtb', 0), 'error');
            }
            if (!$form['qr'][0]) {
                hb_message(lang_st('qsckfewm', 0), 'error');
            }
            $data = array(
                'name' => $form['name'],
                'description' => $form['description'],
                'icon' => $form['icon'][0],
                'qr' => $form['qr'][0],
                'hs_name' => $form['hs_name'],
                'hs_desc' => $form['hs_desc'],
                'upts' => TIMESTAMP,
                'color' => $shcolor[$form['color']],
                'color_title' => $form['color'],
            );
            if (C::t('#xigua_st#xigua_st')->update($form['stid'], $data)) {
                hb_message(lang_st('succeed', 0), 'success', 'reload');
            }
        }
        break;
    case 'city':
        include_once DISCUZ_ROOT . 'source/plugin/xigua_st/hook1.php';

        global $hotcity, $abccity, $abccitys, $ac;
        $hotcity = DB::fetch_all("select * from %t WHERE status=1 AND ishot=1 ORDER BY displayorder DESC", array('xigua_st'), 'stid');
        $abccity = DB::fetch_all("select * from %t WHERE status=1 ORDER BY szm ASC, displayorder DESC", array('xigua_st'), 'stid');
        $abccitys = array();
        foreach ($abccity as $index => $item) {
            if($st_config['shaitype']==1){
                $abccitys[$item['szm']][] = $item;
            }else{
                $abccitys[$item['area1']][] = $item;
            }
        }
        $ac = 'city_new';
        break;
    case 'comset':
        global $stinfo, $old_data, $adary;
        $old_data = $stinfo;
        $old_data['index_topad_ary'] = unserialize($stinfo['index_topad']);
        $old_data['index_topad_lnk_ary'] = unserialize($stinfo['index_topad_lnk']);

        $old_data['index_midad_ary'] = unserialize($stinfo['index_midad']);
        $old_data['index_midad_lnk_ary'] = unserialize($stinfo['index_midad_lnk']);

        $old_data['sh_topad_ary'] = unserialize($stinfo['sh_topad']);
        $old_data['sh_topad_lnk_ary'] = unserialize($stinfo['sh_topad_lnk']);
        $adary = array('index_topad', 'index_midad', 'sh_topad');
        $navtitle = $config['tname'] . lang_st('cysz', 0);
        if (submitcheck('formhash')) {
            $form = $_GET['form'];
            if (!$form['stid']) {
                hb_message(lang_st('qtxname', 0), 'error');
            }
            if ($_GET['type1'] == 'showcnt') {
                C::t('#xigua_st#xigua_st')->update($form['stid'], array(
                    'showcnt' => $form['showcnt']
                ));
                hb_message(lang_st('succeed', 0), 'success', 'reload');
            }
            if (!in_array($_GET['type1'], $adary)) {
                hb_message('error', 'error');
            }
            $type = $_GET['type1'];
            $data = array(
                $type => serialize($form[$type]),
                $type . '_lnk' => serialize($form[$type . '_lnk']),
            );
            if (C::t('#xigua_st#xigua_st')->update($form['stid'], $data)) {
            }
            hb_message(lang_st('succeed', 0), 'success', 'reload');
        }
        break;
    case 'dist_li':
        if(0 && $st_config['newshenqing']){
            $hassts = DB::fetch_all("select stid,name2 from %t WHERE uid>0", array('xigua_st'), 'name2');
            $hassts = array_keys($hassts);
        }
        $rlist = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($_GET['ctid']);
        include template('xigua_hb:header_ajax');
        include template('xigua_st:dist_li');
        include template('xigua_hb:footer_ajax');
        break;
    case 'checkfee':
        $name = $_GET['name'];
        $abccity = DB::fetch_first("select * from %t WHERE (name=%s OR name2=%s OR area1=%s OR area2=%s OR area3=%s)", array('xigua_st', $name, $name, $name, $name, $name));
        $pp = $abccity['joinprice']>0?$abccity['joinprice']:$st_config['zzjmf'];
        if($abccity['uid']>0){
            hb_message(lang_st('hasshenqing', 0), 'error');
        }
        include template('xigua_hb:header_ajax');
        echo floatval($pp);
        include template('xigua_hb:footer_ajax');
        break;
}
if ($_GET['mini'] == '11') {
    $navtitle = strip_tags($navtitle);
    $navtitle = $navtitle ? $navtitle : $config['tname'];
    if ($config['tnameshow']) {
        if ($navtitle != $config['tname']) {
            $navtitle = $config['tname'] . $navtitle;
        }
    }
    ob_end_clean();
    function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
    header("Content-type: application/json; charset=utf-8");
    echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
    exit;
}

if (!checkmobile()) {
    include template('xigua_hb:index');
    exit;
}
if (is_file(DISCUZ_ROOT . "source/plugin/xigua_st/template/touch/$ac.php")) {
    include template('xigua_st:' . $ac);
}