<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_st extends discuz_table
{
    public static $stinfo_static = null;
    public function __construct()
    {
        $this->_table = 'xigua_st';
        $this->_pk = 'stid';


        parent::__construct(); //dis'.'m.tao'.'bao.com
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = array();
        $result = DB::fetch_all("SELECT * FROM %t  ORDER BY displayorder DESC,stid DESC " . DB::limit($start_limit, $lpp), array($this->_table));
        return $result;
    }

    public function count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function fetch_by_status($stid)
    {
        if(self::$stinfo_static!==null){
            return self::$stinfo_static;
        }
        self::$stinfo_static = DB::fetch_first("select * from %t WHERE stid=%d AND status=1", array($this->_table, $stid));
        return self::$stinfo_static;
    }

    public function fetch_field_by_status($stid, $field = '*')
    {
        return DB::fetch_first("select $field from %t WHERE stid=%d AND status=1", array($this->_table, $stid));
    }

    public function fetch_by_status_uid($uid)
    {
        return DB::fetch_first("select * from %t WHERE uid=%d OR FIND_IN_SET(%d, uid2) AND status=1", array($this->_table, $uid, $uid));
    }

    public function fetch_by_status_stid($stid)
    {
        return DB::fetch_first("select * from %t WHERE stid=%d AND status=1", array($this->_table, $stid));
    }

    public function fetch_by_dist($area1, $area2, $area3 = '')
    {
        if($area3){
            $res = DB::fetch_first("select * from %t WHERE area1=%s AND area2=%s AND area3=%s AND status=1", array($this->_table, $area1, $area2, $area3));
        }
        if(!$res){
            $res = DB::fetch_first("select * from %t WHERE area1=%s AND area2=%s AND status=1", array($this->_table, $area1, $area2));
        }
        if(!$res){
            $res = DB::fetch_first("select * from %t WHERE area1=%s AND status=1", array($this->_table, $area1));
        }
        return $res;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public function fetch_by_type($id)
    {
        $res = parent::fetch($id);
        $res = $this->prepare($res);
        return $res;
    }

    public function prepare($vipinfo)
    {
        if($vipinfo){
            if($vipinfo['endts']>0&&$vipinfo['status']==1 && $vipinfo['endts']<TIMESTAMP){
                DB::query("update %t set status=0 WHERE {$this->_pk}=%d", array($this->_table,  $vipinfo['stid']));
            }
        }
        return $vipinfo;
    }

    public function do_delete($id)
    {
        return $this->delete($id);
    }


    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'displayorder DESC,stid DESC', $fields= '*')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){

            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }
}