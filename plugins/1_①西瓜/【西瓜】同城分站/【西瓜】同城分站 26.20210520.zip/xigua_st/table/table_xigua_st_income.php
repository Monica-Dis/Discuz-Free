<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_st_income extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_st_income';
        $this->_pk = 'id';

        parent::__construct(); //dis'.'m.tao'.'bao.com
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }

    public function sum_today_by_uid($uid)
    {
        return DB::result_first("SELECT sum(money) as m FROM %t WHERE uid=%d AND reach<>-2 AND crts BETWEEN %s AND %s", array($this->_table, $uid, strtotime(date('Y-m-d')), strtotime(date('Y-m-d 23:59:59'))));
    }

    public function sum_week_group($uid)
    {
        $ret = array();
        $stime = TIMESTAMP;
        $oldend = $etime = strtotime(date("Y-m-d 00:00:00", strtotime('-1 week +1 day')));

        while($stime>= $etime){
            $ret[date('m-d',$etime)] = 0;
            $etime=$etime + 3600*24;
        }

        $all = DB::fetch_all("SELECT money,FROM_UNIXTIME(crts) as `days` FROM %t WHERE uid=%d AND reach<>-2 AND crts>=%s", array($this->_table, $uid, $oldend));
        foreach ($all as $index => $item) {
            $ret[substr($item['days'], 5, 5)] += $item['money'];
        }
        return $ret;
    }

    public function sum_total_by_uid($uid)
    {
        return DB::result_first("SELECT sum(money) as m FROM %t WHERE uid=%d AND reach<>-2 ", array($this->_table, $uid));
    }

    public function fetch_u_order($wherearr,  $start_limit , $lpp){
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $uids = $ouids = array();
        $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table)." $wheresql ORDER BY crts DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = self::prepare($item);
            $ouids[] = $result[$index]['info']['fromuid'];
        }

        if($ouids){
            $ousers = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $ouids), 'uid');
        }
        foreach ($result as $index => $item) {
            $result[$index]['orderuser'] = $ousers[$item['info']['fromuid']];
        }
        return $result;
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = dgmdate($v['crts'], 'u');
            $v['info'] = unserialize($v['info']);
        }
        return $v;
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY crts DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = self::prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function init_income($postprice, $extinfo)
    {
        global $_G,$SCRITPTNAME;
        $st_config = $_G['cache']['plugin']['xigua_st'];

        if($extinfo['note'] == 'red' || $extinfo['note'] == 'shred' || $extinfo['note']=='hb_rwhb_callback' || $extinfo['note']=='hb_rwhs_callback' ){
            $postprice = $postprice - intval($extinfo['info']['price']*100);
        }
        if($extinfo['note'] == 'common_seckill'){
            $postprice = round($extinfo['info']['data'][1]['sxfee'], 2)*100;
        }
        if($extinfo['note']=='common_fk' || $extinfo['note']=='common_qianbao' || $extinfo['note']=='common_paybao' || $extinfo['note']=='common_hrjoin'){
            return 0;
        }
        if(in_array($extinfo['note'], array('common_rwhb'))){
            return 0;
        }

        if($extinfo['note'] == 'common_seckill'){
            $sxfee = $totalprice = $extinfo['info']['data'][1]['price'];
            if($_G['cache']['plugin']['xigua_hm']['hhrmethod']==2){
                include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
                $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($extinfo['info']['data'][0]['shid']);
                $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                $insxf   = $vipinfo['insxf']/100;

                if($shdata['shinsxf']){
                    $insxf   = $shdata['shinsxf']/100;
                }
                $secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch($extinfo['info']['data'][0]['id']);
                if($secinfo['shrate']){
                    $insxf = $secinfo['shrate']/100;
                }
                $sxfee = round($insxf*$totalprice, 2);
            }
            $postprice = round($sxfee, 2)*100;
        }elseif($extinfo['note'] =='common_pt') {
            $sxfee = $totalprice = $extinfo['info']['data']['pay_money'];
            if ($_G['cache']['plugin']['xigua_pt']['hhrmethod'] == 2) {
                include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
                $shdata = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($extinfo['info']['data'][0]['shid']);
                $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                $insxf = $vipinfo['insxf'] / 100;
                if ($shdata['shinsxf']) {
                    $insxf = $shdata['shinsxf'] / 100;
                }
                $sxfee = round($insxf * $totalprice, 2);
            }
            $postprice = round($sxfee, 2)*100;
        }
        elseif($extinfo['note'] =='common_sp') {
            $infodata = $extinfo['info']['data'];
            if($infodata['crts']>0){
                $sxfee    = $totalprice = $infodata['pay_money'];
                $shid     = $infodata['shid'];
            }else{
                $shid     = $extinfo['info']['callback']['shid'];
                $sxfee    = $totalprice = $extinfo['info']['callback']['price_l'];
            }
            if ($_G['cache']['plugin']['xigua_sp']['hhrmethod'] == 2) {
                include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
                $shdata = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                $insxf = $vipinfo['insxf'] / 100;
                if ($shdata['shinsxf']> 0) {
                    $insxf = $shdata['shinsxf'] / 100;
                }
                $sxfee = round($insxf * $totalprice, 2);
            }
            $postprice = round($sxfee, 2)*100;
        }

        $stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status_stid($extinfo['stid']);
        $urlext = '&st='.$stinfo['stid'];

        if($postprice==$extinfo['baseprice']*100 && $stinfo['nohhrate']){  //no hhr
            $stinfo['ratio'] = $stinfo['nohhrate'];
        }

        $money = round($postprice*$stinfo['ratio']/10000, 2);
        if($money>0){
            C::t('#xigua_st#xigua_st_income')->insert(array(
                'uid'     => $stinfo['uid'],
                'crts'    => TIMESTAMP,
                'ratio'   => $stinfo['ratio'],
                'indate'  => date('Y-m-d', TIMESTAMP),
                'money'   => $money,
                'info'    => serialize($extinfo),
                'reach'   => 1,
                'stid'    => $extinfo['stid'],
                'orderid' => $extinfo['order_id'],
            ));
            $uuser = getuserbyuid($extinfo['fromuid'], 1);

            $ratio = str_replace('.00', '', $stinfo['ratio']).'%';
            $tc = lang('plugin/xigua_st', 'tc');
            $rz = lang('plugin/xigua_st', 'rz');
            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($stinfo['uid'], 'money', $money);
            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                'uid'  => $stinfo['uid'],
                'crts' => TIMESTAMP,
                'size' => $money,
                'note' => $uuser['username'].$extinfo['subject']."<br>{$tc}{$ratio},{$rz}&yen;{$money}",
                'link' => "$SCRITPTNAME?id=xigua_hb&ac=member&uid={$extinfo['fromuid']}$urlext",
            ));
            notification_add($stinfo['uid'],'system', lang('plugin/xigua_st', 'note_3'),array('url' => "$SCRITPTNAME?id=xigua_st&ac=income$urlext", 'money'=>$money),1);
        }

    }
}