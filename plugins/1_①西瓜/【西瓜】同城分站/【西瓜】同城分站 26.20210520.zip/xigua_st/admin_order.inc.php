<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
$st_config = $_G['cache']['plugin']['xigua_st'];
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET); //d'.'is'.'m.tao'.'ba'.'o.com
}
$sta = array(
    -2=>lang_st('ostat-2',0),
    -1=>lang_st('ostat-1',0),
    0 =>lang_st('ostat0',0),
    1 =>lang_st('ostat1',0),
);

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_st#xigua_st_income')->deletes($delete);
    }
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_order", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey(addslashes($_GET['keyword']));
if($keyword){
    $wherearr[] = "uid='$keyword' OR stid='$keyword' OR info like '%$keyword%'";
}
$wherearr[] = "reach=1";

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_order");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_st('uidorder', 0).'" value="'.$_GET['keyword'].'" class="txt" /> ';
echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo '</div>';

showtableheader(lang_st('tichengmanage', 0));
showtablerow('class="header"',array(),array(
    lang_hb('del', 0),
    lang_hb('ID', 0),
    lang_st('hhr', 0),
    lang_st('st', 0),
    lang_st('zt', 0),
    lang_st('ruzhangqi', 0),
    lang_st('tichengyuan', 0),
    lang_st('tichengbl', 0),
    lang_st('ddxinxi', 0),
    lang_st('crts', 0),
));

$res = C::t('#xigua_st#xigua_st_income')->fetch_all_by_page($start_limit, $lpp, $wherearr);
$icount = C::t('#xigua_st#xigua_st_income')->fetch_count_by_page($wherearr);

$uids = array();
foreach ($res as $v) {
    $uids[] = $v['uid'];
    $uids[] = $v['info']['fromuid'];
    $stids = $v['stid'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}
if($stids){
    $sts = DB::fetch_all('SELECT * FROM %t WHERE stid IN (%n)', array('xigua_st', $stids), 'stid');
}

foreach ($res as $v) {
    $id = $v['id'];
    $uid = $v['uid'];
    $info = $v['info'];
    $fromuid = $info['fromuid'];

    $sel = $seltype = '';
    foreach ($sta as $index => $item) {
        if($v['reach'] == $index){
            $sel .= "<option value=\"$index\" selected>$item</option>";
        }else{
            $sel .= "<option value=\"$index\">$item</option>";
        }
    }
    /*if($v['reach']==1){
        $dis = 'disabled';
    }*/
    $endts = date('Y-m-d H:i:s', $v['endts']);
    $crts = date('Y-m-d H:i:s', $v['crts']);

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
        $id,
        "[uid:$uid]<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
        "[id:{$v['stid']}]".$sts[$v['stid']]['name'],
        $sta[$v['reach']],
        $v['crts_u'],
        $v['money'],
        "{$v['ratio']}%",


        lang_st('oinfo1',0).':'.$info['subject'].
        '<br>'.lang_st('oinfo2',0).':'.$info['baseprice'].
        '<br>'.lang_st('oinfo3',0).':'.$info['order_id'].
        '<br>'.lang_st('oinfo4',0).':'."<a href='home.php?mod=space&uid=$fromuid&do=profile' target='_blank'>{$users[$fromuid]['username']}</a>",
        "$crts",

    ));
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_order&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); //From: Dism��taobao��com
showformfooter(); //From: Dism_taobao-com

function lang_st($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_st', $lang);
    }else{
        return lang('plugin/xigua_st', $lang);
    }
}