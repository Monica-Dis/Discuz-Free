<?php exit('Author: https://dism.taobao.com/?@xigua DISM.TAOBAO.COM �ͷ�QQ 467783778'); ?>
<!--{template xigua_hb:common_header}-->
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}</style>
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<link href="source/plugin/xigua_st/static/st.css?{VERHASH}" rel="stylesheet" />
<div class="page__bd">
    <form action="$SCRITPTNAME?id=xigua_st&ac=comset&type1=showcnt" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >
        <input type="hidden" name="form[stid]" value="{$old_data[stid]}" >

        <div class="weui-cells__title">{lang xigua_st:cysz}</div>
        <div class="weui-cells ">
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__bd">{lang xigua_st:xszztj}</div>
                <div class="weui-cell__bd" style="font-size: 13px;color: #999;">{echo str_replace('n', intval($config[cachettl]/60), lang_st('showcnttip', 0));}</div>
                <div class="weui-cell__ft" style="height:32px">
                    <input class="weui-switch" type="checkbox" name="form[showcnt]" value="1" {echo $old_data[showcnt]==1?'checked':''}>
                </div>
            </div>
        </div>

        <div class="weui-cells__title">{lang xigua_st:lbgg}</div>
        <div class="weui-cells ">

            <!--{loop $adary $__k $_vv}-->
            <div class="weui-cell weui-cell_access start_popup" data-field="$_vv">
                <div class="weui-cell__hd"><label class="weui-label">{echo lang_st($_vv, 0);}</label></div>
                <div class="weui-cell__bd"></div>
                <div class="weui-cell__ft">{echo count(array_filter($old_data[$_vv.'_ary']));}{lang xigua_st:z}</div>
            </div>
            <!--{/loop}-->

        </div>

        <div class="fix-bottom mt10">
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}"/>
            <a class="weui-btn weui-btn_default" href="javascript:window.history.go(-1);">{lang xigua_st:fanhui}</a>
        </div>
    </form>
</div>
<!--{eval $_k = 0; }-->
<!--{loop $adary $__k $_vv}-->
<div id="{$_vv}" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:quxiao}</a>
                <h1 class="title"><em class="titem"></em>{lang xigua_st:tjcc}</h1>
            </div>
        </div>
        <div class="modal-content">
            <form action="$SCRITPTNAME?id=xigua_st&ac=comset&type1=$_vv" method="post" id="form" enctype="multipart/form-data">
                <input type="hidden" name="formhash" value="{FORMHASH}">
                <input type="hidden" name="form[stid]" value="{$old_data[stid]}">
                <div class="weui-cells before_none after_none center_upload">
<!--{loop $old_data[$_vv.'_ary'] $k $v}-->
<!--{eval $_k++;}-->
                    <div class="weui-cell bgf" id="arear_{$_k}">
                        <ul id="cimg_{$_k}" data-only="1">
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($v)">
                                <input type="hidden" name="form[$_vv][]" value="$v">
                                <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                            </li>
                        </ul>
                        <div class="weui-cell__bd">
                            <textarea class="weui-textarea" placeholder="{lang xigua_st:lnk}" rows="3" name="form[{$_vv}_lnk][]">{echo $old_data[{$_vv}.'_lnk_ary'][$k]}</textarea>
                        </div>
                        <a class="iconfont icon-guanbijiantou closeHt" data-index="$_k"></a>
                    </div>
<!--{/loop}-->
                    <a class="weui-cell weui-cell_access first_append_img" href="javascript:;">
                        <div class="weui-cell__bd">
                            <p>{lang xigua_st:crlbt}</p>
                        </div>
                        <div class="weui-cell__ft"></div>
                        <input class="center__input" <!--{if HB_INWECHAT&&$config[multiupload]}-->onclick="return false;"<!--{/if}--> data-max="$st_config[maximg]" data-maxtip="{lang xigua_st:maxtip1}{$st_config[maximg]}{lang xigua_st:maxtip2}" data-name="form[ggimg]" type="file">
                    </a>
                    <div class="fix-bottom" style="position:relative"><input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}"></div>
                </div>
            </form>
        </div>
    </div>
</div>
<!--{/loop}-->


<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<!--{template xigua_st:enter_up}-->
<script>
$(document).on('click','.start_popup', function () {
    var that = $(this);
    var fdb = $("#"+that.data('field'));
    ICnt = $('.closeHt').length;
    console.log(ICnt);
    fdb.find('.titem').html(that.find('.weui-label').html());
    fdb.popup();
    $(".center__input").attr('data-name', 'form['+that.data('field')+']').attr('data-text', that.data('field')+'_lnk');
});
</script>