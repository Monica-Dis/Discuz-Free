<?php exit('Author: https://dism.taobao.com/?@xigua DISM.TAOBAO.COM �ͷ�QQ 467783778'); ?>
<!--{template xigua_hb:common_header}-->
<link href="source/plugin/xigua_st/static/st.css?{VERHASH}" rel="stylesheet" />
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{if $stinfo[uid]==$_G[uid]}-->
<div class="mt0 main_bg hh_my_head">
    <i class="header-annimate-element1"></i>
    <i class="header-annimate-element4"></i>
    <i class="header-annimate-element5"></i>
    <i class="header-annimate-element6"></i>
    <i class="header-annimate-element7"></i>
    <i class="header-annimate-element8"></i>
    <i class="header-annimate-element9"></i>

    <div class="hh_my_head_in">
        <div class="main_yen">
            <span><em class="f18">&yen;&nbsp;</em><em id="njum1">{$today_sum}</em></span>
            <em class="f12">{lang xigua_st:today}</em>
        </div>

        <div class="weui-flex sec_yen">
            <a class="weui-flex__item" href="$SCRITPTNAME?id=xigua_hb&ac=qianbao">
                <span><em class="f18">&yen;&nbsp;</em><em id="njum2">{$hb_money}</em></span>
                <em class="f12">{lang xigua_st:keti}</em>
            </a>
            <div class="weui-flex__item">
                <span><em class="f18">&yen;&nbsp;</em><em id="njum3">{$total_sum}</em></span>
                <em class="f12">{lang xigua_st:leijiti}</em>
            </div>
            <div class="weui-flex__item">
                <span><em id="njum3">{$stinfo[ratio]}</em><em class="f18">%</em></span>
                <em class="f12">{lang xigua_st:ratio}</em>
            </div>
        </div>
    </div>
</div>
    <!--{/if}-->

    <div class="weui-cells mt0 border_none">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_st&ac=set{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-shezhi color-red f18"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_st:zdsz}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_st&ac=comset{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-guanlianfujian color-twitter f18"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_st:cysz}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
    </div>

    <div class="weui-cells">

        <!--{if $stinfo[uid]==$_G[uid]}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_st&ac=income{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-shouru color-red"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_st:zdsr}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
        <!--{/if}-->

        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=manage&stat=display&display=0{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-fabu color-paypal"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_st:xxgl}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>

        <!--{if $_G['cache']['plugin']['xigua_hs']}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hs&ac=myshop&manage=1&stat=display&display=0{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-shopfill color-amazon"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_st:sjgl}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
        <!--{/if}-->
    </div>
</div>

<!--{eval $tabbar=1;}-->
<!--{template xigua_hb:common_footer}-->