<?php exit('Author: https://dism.taobao.com/?@xigua DISM.TAOBAO.COM �ͷ�QQ 467783778'); ?>
<!--{template xigua_hb:common_header}-->
<!--{eval
if($st_config['zongname2']):
    $st_config['zongname']=$st_config['zongname2'];
endif;
}-->
<style>.wbtn {background-color: #fff!important;color: #666;width:32%;float: left;padding: 0;margin-right: 1.6%;height: 1.75rem;line-height:1.8rem;border-radius:.1rem;margin-bottom:.6rem;font-size:.7rem;max-width: 7rem;}
    .wbtn:nth-child(3n){margin-right:0;}.weui-btn:after{border-radius:.2rem;}.newpd{padding: .5rem 1.5rem .5rem .75rem}.text-now {width: 3.5rem;height: 3.5rem;position: fixed;top: 50%;left: 50%;margin-top: -1.75rem;margin-left: -1.75rem;background: #FFFFFF;border:1px solid #E6E6E6;border-radius:.2rem;text-align: center;font-size: 1.75rem;line-height:3.4rem;color:{$config[maincolor]};opacity: 0;z-index: -1;}.text-show {opacity: 1;z-index: 1000;}.char-list {height: 100vh;top: 2.5rem;position: fixed;right:.1rem;padding-top:calc(50vh - 2.5rem - {echo count($abccitys)*22.5/40}rem);z-index: 108;transform-origin: 0 0 0;opacity: 1;transform: scale(1, 1);-moz-transform: scale(1, 1);-ms-transform: scale(1, 1);-webkit-transform: scale(1, 1);-o-transform: scale(1, 1);background-color: transparent;text-align: center;width: 1.4rem;}.char-list div {word-break: break-all;word-wrap: break-word;font-size:.7rem;color:{$config[maincolor]};}.char-list>div>span {display: inline-block;width: 1.4rem;text-align: center;}
    <!--{if $st_config[style]==2}-->.weui-cell{float:left}<!--{elseif $st_config[style]==3}-->.wbtn{border-radius: 1.75rem;background-color:#f2f2f2!important;color: #333;}.chartitle{color:#333}
    .wbtn:after {display: none;}.footer_fix,.page__bd{background:#fff!important;}.cur_newpd .wbtn{background-color:$config[maincolor]!important;color:#fff}<!--{/if}-->
</style>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{eval $back = $_GET[back] ? $_GET[back].'&st=-1' : "$SCRITPTNAME?id=xigua_hb&st=-1";}-->
    <div class="cityp15">
        <div class="weui-cells__title cl">{lang xigua_st:dqcs}

<!--{if $_G['cache']['plugin']['xigua_st']['zzjmf']>0}-->
    <a href="$SCRITPTNAME?id=xigua_st&ac=shenqing&mobile=2{$urlext}" class="y main_color">{lang xigua_st:sqjm1} &raquo;</a>
<!--{/if}-->
        </div>
        <!--{if $stinfo}-->
        <!--{eval $doamin = ($stinfo['doamin'] ? $stinfo['doamin']:($st_config['siteurl'] ?$st_config['siteurl']: $_G['siteurl']));}-->
        <div class="cl newpd cur_newpd">
            <a class="weui-btn weui-btn_mini mt0 wbtn" onclick="hb_jump_st('{$doamin}{$back}&st={$stinfo[stid]}');" href="javascript:;">{echo $stinfo['name2']?$stinfo['name2']:$stinfo['name']}</a>
        </div>
        <!--{else}-->
        <!--{if $st_config[showzinc]}-->
        <div class="cl newpd">
            <a class="weui-btn weui-btn_mini mt0 wbtn" onclick="hb_jump_st('{$st_config[siteurl]}{$back}');" href="javascript:;">{$st_config['zongname']}</a>
        </div>
        <!--{/if}-->
        <!--{/if}-->
        <div class="weui-cells__title chartitle chartitle_0">{lang xigua_st:emcs}</div>
        <div class="cl newpd">
            <!--{if $st_config[showzinc]}-->
            <a class="weui-btn weui-btn_mini  mt0 wbtn" onclick="hb_jump_st('{$st_config[siteurl]}{$back}');" href="javascript:;">$st_config[zongname]</a>
            <!--{/if}-->
            <!--{loop $hotcity $v}-->
            <!--{eval $doamin = ($v['doamin'] ? $v['doamin']:($st_config['siteurl'] ?$st_config['siteurl']: $_G['siteurl']));}-->
            <a class="weui-btn weui-btn_mini  mt0 wbtn" onclick="hb_jump_st('{$doamin}{$back}&st={$v[stid]}');" href="javascript:;">{echo $v['name2']?$v['name2']:$v[name]}</a>
            <!--{/loop}-->
        </div>
    </div>
    <!--{if $st_config['shaitype']==1}-->
    <div class="char-list">
        <div class="charlist" data-letter="{lang xigua_st:hott}"><span>{lang xigua_st:hott}</span></div>
        <!--{loop $abccitys $_k $_v}-->
        <div class="charlist" data-letter="$_k"><span>$_k</span></div>
        <!--{/loop}-->
    </div>
    <!--{/if}-->
    <div class="text-now"></div>

    <!--{loop $abccitys $_k $_v}-->
    <div class="weui-cells__title chartitle chartitle_$_k">$_k</div>
    <!--{if $st_config[style]==3}-->
    <div class="cl newpd">
        <!--{loop $_v $__v}-->
        <!--{eval $doamin = ($__v['doamin'] ? $__v['doamin']:($st_config['siteurl'] ?$st_config['siteurl']: $_G['siteurl']));}-->
        <a class="weui-btn weui-btn_mini  mt0 wbtn" href="javascript:;" onclick="hb_jump_st('{$doamin}{$back}&st={$__v[stid]}');return false;">{echo $__v['name2']?$__v['name2']:$__v[name]}</a>
        <!--{/loop}-->
    </div>
    <!--{else}-->
    <div class="weui-cells before_none after_none">
        <!--{loop $_v $__v}-->
        <!--{eval $doamin = ($__v['doamin'] ? $__v['doamin']:($st_config['siteurl'] ?$st_config['siteurl']: $_G['siteurl']));}-->
        <a class="weui-cell weui-cell_access <!--{if $st_config[style]==2}-->before_none<!--{/if}-->" href="javascript:;" onclick="hb_jump_st('{$doamin}{$back}&st={$__v[stid]}');return false;">
            <div class="weui-cell__bd">
                <p>{echo $__v['name2']?$__v['name2']:$__v[name]}</p>
            </div>
        </a>
        <!--{/loop}-->
    </div>
    <!--{/if}-->
    <!--{/loop}-->
</div>
<!--{template xigua_hb:common_footer}-->
<script>
    $(document).on('click','.charlist', function () {
        var that = $(this);
        console.log(that.data('letter'));
        $('.text-now').html(that.data('letter')).addClass('text-show');
        setTimeout(function () {
            $('.text-now').removeClass('text-show')
        }, 1200);
        var id = that.data('letter');
        if(id =='{lang xigua_st:hott}'){
            id='0';
        }
        $('.chartitle').removeClass('main_color');
        $('.chartitle_'+id).addClass('main_color');
        var sctop =$('.chartitle_'+id).offset().top-55;
        console.log(sctop);
        $('body,html').animate({scrollTop:sctop}, 180);
    });
    function hb_jump_st(jpurl){
        if (typeof wx !== 'undefined' && jpurl.indexOf('javascript') === -1) {
            if (window.__wxjs_environment === 'miniprogram') {
                GSITE = GSITE.replace(/http:\/\//, 'https://');
                var needfix = (jpurl.indexOf('http://') === -1 && jpurl.indexOf('https://') === -1) ? (GSITE + '' + jpurl) : jpurl;
                wx.miniProgram.redirectTo({url: '/pages/index/index?url=' + encodeURIComponent(needfix)});
                return false;
            }else{
                window.location.href = jpurl;
            }
        }else{
            window.location.href = jpurl;
        }
    }
</script>