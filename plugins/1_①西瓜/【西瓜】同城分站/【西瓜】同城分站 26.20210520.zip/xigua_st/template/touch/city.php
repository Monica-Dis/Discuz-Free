<?php exit('Author: https://dism.taobao.com/?@xigua DISM.TAOBAO.COM �ͷ�QQ 467783778'); ?>
<!--{template xigua_hb:common_header}-->
<!--{eval
if($st_config['zongname2']):
    $st_config['zongname']=$st_config['zongname2'];
endif;
}-->
<style>
    .wbtn {background-color: #fff!important;color: #666;width: 32%;float: left;padding: 0;margin-right: 1.6%;height: 35px;line-height: 36px;border-radius:2px;margin-bottom:12px;}
    .wbtn:nth-child(3n){margin-right:0;}.weui-btn:after{border-radius:4px;}
</style>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{eval $back = $_GET[back] ? $_GET[back].'&st=-1' : "$SCRITPTNAME?id=xigua_hb&st=-1";}-->

    <div class="cityp15">
        <div class="weui-cells__title">{lang xigua_st:dqcs}</div>
        <!--{if $stinfo}-->
        <!--{eval $doamin = ($stinfo['doamin'] ? $stinfo['doamin']:($st_config['siteurl'] ?$st_config['siteurl']: $_G['siteurl']));}-->
        <div class="cl " style="padding:10px 15px">
            <a class="weui-btn weui-btn_mini mt0 wbtn" onclick="window.location.href='{$doamin}{$back}&st={$stinfo[stid]}'" href="javascript:;">{echo $stinfo['name2']?$stinfo['name2']:$stinfo['name']}</a>
        </div>
        <!--{else}-->
        <div class="cl " style="padding:10px 15px">
            <a class="weui-btn weui-btn_mini mt0 wbtn" onclick="window.location.href='{$back}'" href="javascript:;">{$st_config['zongname']}</a>
        </div>
        <!--{/if}-->

        <div class="weui-cells__title">{lang xigua_st:emcs}</div>
        <div class="cl " style="padding:10px 15px">
            <a class="weui-btn weui-btn_mini  mt0 wbtn" onclick="window.location.href='{$back}'" href="javascript:;">$st_config[zongname]</a>
            <!--{loop $hotcity $v}-->
            <!--{eval $doamin = ($v['doamin'] ? $v['doamin']:($st_config['siteurl'] ?$st_config['siteurl']: $_G['siteurl']));}-->
            <a class="weui-btn weui-btn_mini  mt0 wbtn" onclick="window.location.href='{$doamin}{$back}&st={$v[stid]}'" href="javascript:;">{echo $v['name2']?$v['name2']:$v[name]}</a>
            <!--{/loop}-->
        </div>

    </div>


</div>

<!--{template xigua_hb:common_footer}-->