<?php exit('Author: https://dism.taobao.com/?@xigua DISM.TAOBAO.COM �ͷ�QQ 467783778'); ?>
<!--{template xigua_hb:common_header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<link href="source/plugin/xigua_st/static/st.css?{VERHASH}" rel="stylesheet" />
<div class="page__bd">
    <form action="$SCRITPTNAME?id=xigua_st&ac=set" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >
        <input type="hidden" name="form[stid]" value="{$old_data[stid]}" >

        <div class="weui-cells__title">{lang xigua_st:zdxx}</div>
        <div class="weui-cells ">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_st:title}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[name]" placeholder="{lang xigua_st:qtx}{lang xigua_st:title}" value="{$old_data[name]}">
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_st:zdjj}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[description]" placeholder="{lang xigua_st:qtx}{lang xigua_st:zdjj}" value="{$old_data[description]}">
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_st:hs_name}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[hs_name]" placeholder="{lang xigua_st:qtx}{lang xigua_st:hs_name}" value="{$old_data[hs_name]}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_st:hs_desc}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[hs_desc]" placeholder="{lang xigua_st:qtx}{lang xigua_st:hs_desc}" value="{$old_data[hs_desc]}">
                </div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_st:zdfg}</label></div>
                <div class="weui-cell__bd enter_addr">
                    <input id="choose_color" class="weui-input" name="form[color]" type="text" value="{$old_data['color_title']}" placeholder="{lang xigua_st:qxzzdfg}" data-value="{$old_data[color]}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_st:icon}</p>
                            <div class="weui-uploader__info">{lang xigua_st:tj}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[icon]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[icon])"><input type="hidden" name="form[icon][]" value="$old_data[icon]"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box">
                                <input  class="weui-uploader__input" data-name="form[icon]" type="file">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_st:kfqr}</p>
                            <div class="weui-uploader__info">{lang xigua_st:kfqrtj}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[qr]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[qr])"><input type="hidden" name="form[qr][]" value="$old_data[qr]"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box">
                                <input  class="weui-uploader__input" data-name="form[qr]" type="file">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <div class="weui-cells__title">{lang xigua_st:fwdz1}</div>
        <div class="weui-cells">
            <div class="weui-cell">
                <div class="weui-cell__hd"></div>
                <div class="weui-cell__bd">
                    <p class="f13">{echo ($old_data['doamin'] ? $old_data['doamin']: ($st_config['siteurl'] ?$st_config['siteurl']: $_G['siteurl']))."$SCRITPTNAME?id=xigua_hb&st=".$stid;}</p>
                </div>
            </div>
        </div>
        <div class="fix-bottom mt10" style="position:relative">
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}"/>
            <a class="weui-btn weui-btn_default" href="javascript:window.history.go(-1);">{lang xigua_st:fanhui}</a>
        </div>

    </form>
</div>


<div class="masker" onclick='$(".choose_ctrl").select("close")'></div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<!--{eval $tabbar=0;$config[multiupload]=0;}-->
<!--{template xigua_hb:common_footer}-->
<!--{template xigua_st:enter_up}-->
<script>
    <!--{if $shcolor}-->
    var itar = [];
    <!--{loop $shcolor $_title $_color}-->
    itar.push({title:'{$_title}', value:'{$_color}', style:'color:{$_color}'});
    <!--{/loop}-->
    $("#choose_color").select({
        title: "{lang xigua_st:qxzzdfg}",
        items: itar,
        onOpen:function () {
            $('.masker').fadeIn();
        },
        beforeClose:function () {
            $('.masker').fadeOut(300);
            return true;
        }
    });
    <!--{/if}-->
</script>