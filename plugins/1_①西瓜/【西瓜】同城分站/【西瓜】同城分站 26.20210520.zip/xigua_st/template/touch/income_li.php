<?php exit('Author: https://dism.taobao.com/?@xigua DISM.TAOBAO.COM �ͷ�QQ 467783778'); ?>
<!--{loop $list $v}-->
<a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=member&uid={$v[orderuser][uid]}">
    <div class="weui-cell__bd">
        <p class="color-red f16">+{$v[money]} {lang xigua_hb:yuan}  <em class="icon-info-message icon-color-1">$stinfo[name]{lang xigua_st:dd}</em></p>
        <p class="weui-desc f13 c9">{$v[orderuser][username]} {$v[info][subject]}</p>
        <p class="weui-desc f13 c9">{$v[crts_u]}</p>
    </div>
    <div class="weui-cell__ft"></div>
</a>
<!--{/loop}-->
