<?php exit('Author: https://dism.taobao.com/?@xigua DISM.TAOBAO.COM �ͷ�QQ 467783778'); ?>
<!--{template xigua_hb:common_header}-->
<div class="page__bd">

    <!--{template xigua_hb:common_nav}-->
    <div class="weui-cells__title">
        <b class="main_color">{lang xigua_st:wrtip1}<a href="$SCRITPTNAME?id=xigua_hb&ac=qianbao" class="a">{lang xigua_st:qianbao}</a>{lang xigua_st:wrtip2}</b>
    </div>

    <div  id="list" class="weui-cells p0 mt0 before_none"></div>

    <script>
        var loadingurl = window.location.href+'&ac=income_li&inajax=1&do=$do&pagesize=20&page=';
    </script>

    <!--{template xigua_hb:loading}-->

</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->