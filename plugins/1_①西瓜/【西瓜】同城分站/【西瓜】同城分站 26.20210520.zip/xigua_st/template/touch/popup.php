<?php exit('Author: https://dism.taobao.com/?@xigua DISM.TAOBAO.COM �ͷ�QQ 467783778'); ?>
<div id="popup_areawant" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:queding}</a>
                <h1 class="title">{lang xigua_st:xzqy}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="border_bottom post_com_tag post-tags cl" id="p2"><!--{loop $old_data['areawant_ary'] $_k $_v}--><a id="id_p2{$_v}" data-form="checkstid" data-ld="p2" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">{$old_data['areawant_str_ary'][$_k]}<input name="form[checkstid][]" type="hidden" value="$_v"></a><!--{/loop}--></div>
            <div class="pupc-btm">
                <div class="pupc-btm-in">
                    <!--{loop $distjsary $_k $_v}-->
                    <a class="border_bottom check1 <!--{if $_k==0}-->main_color<!--{/if}-->" data-title="{$_v[id]}" data-titfix="p2_" ><!--{eval $namediconv = diconv($_v[name], 'UTF-8', CHARSET);}--><!--{if in_array($namediconv, $hassts)}--><i class="iconfont icon-hot-02 color-red2 f13"></i><!--{/if}--> {$namediconv}</a>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left">
                    <!--{loop $distjsary $_k $_v}-->
                    <div class="pupc-btm-in_list <!--{if $_k>0}-->none<!--{/if}-->" id="p2_{$_v[id]}">
                        <a class="check2 pupc_check_a border_bottom" data-name="{echo diconv($_v[name], 'UTF-8', CHARSET)}" data-max="{echo $st_config[maxareawant]-1}" data-maxtip="{lang xigua_st:zd}{$st_config[maxareawant]}{lang xigua_st:g}" data-form="checkstid" data-ld="p2" data-title="p2{$_v[id]}" data-value="{$_v[id]}">{lang xigua_hb:quan}{echo diconv($_v[name], 'UTF-8', CHARSET)} <i class="iconfont icon-coordinates_fill f14 "></i></a>
                        <!--{loop $_v[sub] $__v}-->
                        <!--{eval $__name = diconv($__v[name], 'UTF-8', CHARSET);}-->
                        <a class="check3 pupc_check_a border_bottom" data-name="$__name" data-max="{echo $st_config[maxareawant]-1}" data-maxtip="{lang xigua_st:zd}{$st_config[maxareawant]}{lang xigua_st:g}" data-form="checkstid" data-ld="p2" data-title="p2{$__v[id]}" data-value="{$__v[id]}"><!--{if in_array($__name, $hassts)}--><i class="iconfont icon-hot-02 color-red2 f13"></i><!--{/if}--> $__name</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left none" id="distbox"></div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).on('click','.check1', function () {
        var that = $(this);
        that.siblings().removeClass('main_color');
        that.addClass('main_color');
        that.parent().parent().find('.pupc-btm-in_list').hide();
        $('#'+that.data('titfix')+that.data('title')).show();
    });
    $(document).on('click','.check2', function(){
        var that = $(this);
        $('.check2').removeClass('main_color');
        that.addClass('main_color');
        var dt = that.data('title'),dv = that.data('value'), tame = that.html();
        if(that.data('name')){
            tame = that.data('name');
        }
        $('.post_com_tag .weui-btn_default').trigger('click');
        $('#id_'+dt).remove();
        $('#'+that.data('ld')).append('<a id="id_'+dt+'" data-ld="'+that.data('ld')+'" data-form="'+that.data('form')+'" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">'+tame+'<input name="form['+that.data('form')+'][]" type="hidden" value="'+dv+'" /></a>');
        sync_formid(that.data('ld'), that.data('form'));
    });
    $(document).on('click','.post_com_tag .weui-btn_default', function () {
        var that = $(this);
        that.remove();
        sync_formid(that.data('ld'), that.data('form'));
    });
    function sync_formid(apend, dform){
        var val = '';
        $('#'+apend).find('a').each(function () {  val+=',' + $(this).text(); });
        $('#'+dform).val(val.substr(1));
        console.log(val.substr(1));
        $.ajax({type: 'GET',url: _APPNAME + '?id=xigua_st&ac=checkfee&name='+val.substr(1)+'&inajax=1',
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                console.log(s.indexOf('error'));
                if(s.indexOf('error')!==-1){
                    tip_common(s);
                }else{
                    $('#dosubmit').val("{lang xigua_st:sq}({lang xigua_st:jmf}"+s+"{lang xigua_hb:yuan})");
                }
            }
        });
    }
    $(document).on('click','.check3', function(){
        var that = $(this);
        $('.check3').removeClass('main_color');
        that.addClass('main_color');
        $.ajax({type: 'GET',url: _APPNAME + '?id=xigua_st&ac=dist_li&name='+that.data('name')+'&ctid='+that.data('value')+'&inajax=1',
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $('#distbox').html(s).removeClass('none');
            }
        });
    });
</script>