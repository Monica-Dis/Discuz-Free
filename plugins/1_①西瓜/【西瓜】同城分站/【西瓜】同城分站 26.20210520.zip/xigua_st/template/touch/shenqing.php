<?php exit('Author: https://dism.taobao.com/?@xigua DISM.TAOBAO.COM �ͷ�QQ 467783778'); ?>
<!--{template xigua_hb:common_header}-->
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}</style>
<link href="source/plugin/xigua_st/static/st.css?{VERHASH}" rel="stylesheet" />
<div class="page__bd">
    <form action="$SCRITPTNAME?id=xigua_st&ac=shenqing" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >

        <div class="weui-cells__title">{lang xigua_st:sqzz}</div>
        <div class="weui-cells weui-cells_form before_none after_none">
            <!--{if $st_config[newshenqing]}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_st:xzqy}</label></div>
                <div class="weui-cell__bd">
                    <input id="checkstid" class="weui-input" name="form[checkstid]" type="text" readonly placeholder="{lang xigua_st:xzqy}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{else}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{lang xigua_st:xzqy}</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" id="start" name="form[checkstid]" type="text" value="{$projson[0]}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <textarea class="weui-textarea" name="form[note]" placeholder="{lang xigua_st:plzxxdz}" rows="3"></textarea>
                </div>
            </div>
        </div>

        <div class="fix-bottom mt10" style="position:relative;">
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_st:sq}({lang xigua_st:jmf}{$st_config[zzjmf]}{lang xigua_hb:yuan})"/>
            <a class="weui-btn weui-btn_default" href="javascript:window.history.go(-1);">{lang xigua_st:fanhui}</a>
        </div>
    </form>
</div>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<!--{eval $pecho = implode('\',\'', $projson);}-->
<!--{template xigua_st:popup}-->
<script>$("#start").picker({title: "{lang xigua_st:qxzqy}",cols: [{textAlign: 'center',values: ['$pecho']}]});
$(document).on('click','#checkstid', function () {
    var popcm =$('#popup_areawant');
    popcm.popup();
    popcm.show();
    setTimeout(function(){
        popcm.show();
    }, 500);
    return false;
});
</script>