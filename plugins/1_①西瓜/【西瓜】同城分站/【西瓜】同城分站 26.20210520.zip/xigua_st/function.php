<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function lang_st($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_st', $lang);
    }else{
        return lang('plugin/xigua_st', $lang);
    }
    return '';
}
function st_callback_shenqing($param){
    global $_G;
    $info = $param['info'];
    $logdata = $info['data'][0];
    $stidauto = $info['data'][1];
    C::t('#xigua_st#xigua_st_shenqing')->update($logdata['id'], array('pay_ts' => TIMESTAMP));

    if($stidauto> 0){
        $st_config = $_G['cache']['plugin']['xigua_st'];
        if($logdata['uid']){
            $us = getuserbyuid($logdata['uid']);
        }
        C::t('#xigua_st#xigua_st')->update($stidauto, array('uid' => $logdata['uid'],'username'=>$us['username'], 'upts' => TIMESTAMP, 'endts' => TIMESTAMP+$st_config['zzjmf_last']*365*86400, 'status' => 1));
        global $adminids;
        if($adminids){
            $adminids = array_slice($adminids,0,10);
            foreach ($adminids as $adminid) {
                notification_add($adminid,'system', lang('plugin/xigua_st','new_shenqing1').' '.$logdata['checkstid'].'('.$logdata['note'].')', array(), 1);
            }
        }
    }else{
        global $adminids;
        if($adminids){
            $adminids = array_slice($adminids,0,10);
            foreach ($adminids as $adminid) {
                notification_add($adminid,'system', lang('plugin/xigua_st','new_shenqing').' '.$logdata['checkstid'].'('.$logdata['note'].')', array(), 1);
            }
        }
    }
    return true;
}