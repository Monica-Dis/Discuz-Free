<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_G['cookie']['nowst'] && !$_GET['st']){
    $_GET['st'] = $_G['cookie']['nowst'];
}
$urlext = '';
$stadmin = 0;
if($_G['cache']['plugin']['xigua_st']) {
    if($_GET['st']<0){
        $_GET['st'] = 0;
        dsetcookie('nowst', 0, -1);
    }
    if (($st = intval($_GET['st']))) {
        $stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status($st);
        if ($stinfo) {
            if ($stinfo['name']) {
                $config['tname'] = $stinfo['name'];
            }
            $config['fid_s'] = $stinfo['tid'];
            if ($stinfo['icon']) {
                $_G['cache']['plugin']['xigua_f']['defaultlogo'] = $config['logo'] = $stinfo['icon'];
                if($_G['cache']['plugin']['xigua_hs']){
                    $_G['cache']['plugin']['xigua_hs']['shlogo'] = $hs_config['shlogo'] = $stinfo['icon'];
                }
            }
            if ($stinfo['description']) {
                $config['desc'] = $stinfo['description'];
            }
            if ($stinfo['qr']) {
                $config['kfqrcode'] = $stinfo['qr'];
                if($_G['cache']['plugin']['xigua_hs']){
                    $_G['cache']['plugin']['xigua_hs']['qrcode'] = $hs_config['qrcode'] = $stinfo['qr'];
                }
            }
            if($_G['cache']['plugin']['xigua_hs']) {
                if ($stinfo['hs_name']) {
                    $_G['cache']['plugin']['xigua_hs']['shindex'] = $stinfo['hs_name'];
                }
                if ($stinfo['hs_desc']) {
                    $_G['cache']['plugin']['xigua_hs']['shdesc'] = $stinfo['hs_desc'];
                }
            }
            if($stinfo['color']){
                $config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $stinfo['color'];
            }
            if($stinfo['index_topad']){
                $iii = '';
                $stinfo['index_topad_ary'] = array_reverse(unserialize($stinfo['index_topad']));
                $stinfo['index_topad_lnk_ary'] = array_reverse(unserialize($stinfo['index_topad_lnk']));
                foreach ($stinfo['index_topad_ary'] as $i => $ii) {
                    $iii .= "$ii,".$stinfo['index_topad_lnk_ary'][$i]."\n";
                }
                if($iii = trim($iii)){
                    $config['topslider'] = $iii;
                }
            }
            if($stinfo['index_midad']){
                $iii = '';
                $stinfo['index_midad_ary'] = array_reverse(unserialize($stinfo['index_midad']));
                $stinfo['index_midad_lnk_ary'] = array_reverse(unserialize($stinfo['index_midad_lnk']));
                foreach ($stinfo['index_midad_ary'] as $i => $ii) {
                    $iii .= "$ii,".$stinfo['index_midad_lnk_ary'][$i]."\n";
                }
                if($iii = trim($iii)){
                    $config['midslider'] = $iii;
                }
            }
            if($stinfo['sh_topad'] && $_G['cache']['plugin']['xigua_hs']){
                $iii = '';
                $stinfo['sh_topad_ary'] = array_reverse(unserialize($stinfo['sh_topad']));
                $stinfo['sh_topad_lnk_ary'] = array_reverse(unserialize($stinfo['sh_topad_lnk']));
                foreach ($stinfo['sh_topad_ary'] as $i => $ii) {
                    $iii .= "$ii,".$stinfo['sh_topad_lnk_ary'][$i]."\n";
                }
                if($iii = trim($iii)){
                    $_G['cache']['plugin']['xigua_hs']['slider'] = $iii;
                }
            }
            if($stinfo['showcnt']){
                $_G['cache']['plugin']['xigua_st']['shoucount2'] = 1;
            }

            if($stinfo['cats']){
                $GLOBALS['st_cats'] = array_filter(explode(',', trim($stinfo['cats'])));
            }

            $urlext = '&st=' . $_GET['st'];
            dsetcookie('ST', $urlext, 7200);
            if ($_G['uid']> 0 && ($_G['uid'] == $stinfo['uid'] || in_array($_G['uid'], explode(',', $stinfo['uid2']))) && $_GET['st']> 0) {
                $stadmin = $_G['uid'];
                if ($_G['cache']['plugin']['xigua_hs']&& $_GET['shid'] > 0) {
                    $stadmin = 0;
                    $tmp = DB::result_first('SELECT stid FROM %t WHERE shid=%d AND stid=%d', array(
                        'xigua_hs_shanghu',
                        $_GET['shid'],$_GET['st']
                    ));
                    if ($tmp) {
                        $stadmin = $_G['uid'];
                    }
                }
                if ($_GET['pubid']) {
                    $stadmin = 0;
                    $tmp = DB::result_first('SELECT stid FROM %t WHERE id=%d AND stid=%d', array(
                        'xigua_hb_pub',
                        $_GET['pubid'],$_GET['st']
                    ));
                    if ($tmp) {
                        $stadmin = $_G['uid'];
                    }
                }
            }
        } else {
            $urlext = '';
            unset($_GET['st']);
        }
    }
    if ($_G['cache']['plugin']['xigua_st']['showfz']) {
        $config['indexshowdist'] = 0;
        $config['getbygeo'] = 0;
    }
}
if($_GET['st']>0 && $_G['cache']['plugin']['xigua_st']['jiyi']){
    dsetcookie('nowst', intval($_GET['st']), $_G['cache']['plugin']['xigua_st']['jiyi']);
}