<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
$st_config = $_G['cache']['plugin']['xigua_st'];
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";


function lang_st($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_st', $lang);
    }else{
        return lang('plugin/xigua_st', $lang);
    }
}
if($_SERVER['REQUEST_METHOD'] == 'POST') {
//    $_GET = dhtmlspecialchars($_GET); //d'.'is'.'m.tao'.'ba'.'o.com
}function getFirstCharter($str)
{
    if (empty($str)) {
        return '';
    }
    $fchar = ord($str{0});
    if ($fchar >= ord('A') && $fchar <= ord('z')) return strtoupper($str{0});
    $s1 = iconv('UTF-8', 'gb2312', $str);
    $s2 = iconv('gb2312', 'UTF-8', $s1);
    $s = $s2 == $str ? $s1 : $str;
    $asc = ord($s{0}) * 256 + ord($s{1}) - 65536;
    if ($asc >= -20319 && $asc <= -20284) return 'A';
    if ($asc >= -20283 && $asc <= -19776) return 'B';
    if ($asc >= -19775 && $asc <= -19219) return 'C';
    if ($asc >= -19218 && $asc <= -18711) return 'D';
    if ($asc >= -18710 && $asc <= -18527) return 'E';
    if ($asc >= -18526 && $asc <= -18240) return 'F';
    if ($asc >= -18239 && $asc <= -17923) return 'G';
    if ($asc >= -17922 && $asc <= -17418) return 'H';
    if ($asc >= -17417 && $asc <= -16475) return 'J';
    if ($asc >= -16474 && $asc <= -16213) return 'K';
    if ($asc >= -16212 && $asc <= -15641) return 'L';
    if ($asc >= -15640 && $asc <= -15166) return 'M';
    if ($asc >= -15165 && $asc <= -14923) return 'N';
    if ($asc >= -14922 && $asc <= -14915) return 'O';
    if ($asc >= -14914 && $asc <= -14631) return 'P';
    if ($asc >= -14630 && $asc <= -14150) return 'Q';
    if ($asc >= -14149 && $asc <= -14091) return 'R';
    if ($asc >= -14090 && $asc <= -13319) return 'S';
    if ($asc >= -13318 && $asc <= -12839) return 'T';
    if ($asc >= -12838 && $asc <= -12557) return 'W';
    if ($asc >= -12556 && $asc <= -11848) return 'X';
    if ($asc >= -11847 && $asc <= -11056) return 'Y';
    if ($asc >= -11055 && $asc <= -10247) return 'Z';
    return null;
}

$page = max(1, intval(getgpc('page')));
$lpp = 15;
$start_limit = ($page - 1) * $lpp;
$st_config = $_G['cache']['plugin']['xigua_st'];

$shcolor = array();
if($st_config['colors']){
    foreach (explode("\n", trim($st_config['colors'])) as $index => $item) {
        list($_color, $_title) = explode('=', trim($item));
        $shcolor[$_title] = trim($_color);
    }
}

if($stid = intval($_GET['stid'])){

    if(!submitcheck('varsubmit')) {
        $res = DB::fetch_first("select * from %t WHERE stid=%d", array('xigua_st', $stid));

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&page=$page&stid=$stid", 'enctype');
        showtableheader(); //d'.'i'.'sm.ta'.'o'.'bao.com
        showtitle($res['name'] .' - ' . $stid. "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&page=$page'> ".lang_st('back',0)."</a>");
        $vips = array(
             0 => lang_st('yxx', 0),
             1 => lang_st('ysx', 0),
             -1 => lang_st('dsh', 0),
        );
        $vp = '<select name="editform[status]">';
        foreach ($vips as $index => $vip) {
            $s = '';
            if($res['status']==$index){
                $s = 'selected';
            }
            $vp .= "<option $s value='$index'>$vip</option>";
        }
        $vp .= '</select>';

        foreach ($res as $index => $re) {
            if(in_array($index, array('stid', 'color_title', 'ishot','username'))){
                continue;
            }
            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('endts', 'dig_endts', 'crts', 'upts'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }
            if($index == 'color'){
                $cs = '<select name="editform[color_title]">';
                foreach ($shcolor as $c_t => $c) {
                    $s = '';
                    if($c== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c_t</option>";
                }
                $tp = $cs;
            }

            if(in_array($index, array('showcnt'))){
                $tp = 'radio';
            }
            if(in_array($index, array('status'))){
                $tp = $vp;
            }
            if(in_array($index, array('qr', 'icon'))){
                $tp = 'filetext';
            }
            if(in_array($index, array('shprice'))){
                $tp = 'textarea';
            }
            if (in_array($index, array('index_topad', 'index_midad', 'sh_topad', 'index_topad_lnk', 'index_midad_lnk', 'sh_topad_lnk'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $loopnum = $st_config['maximg'];
                if (in_array($index , array('index_topad_lnk', 'index_midad_lnk', 'sh_topad_lnk'))) {
                    $tp = 'text';
                }
                for ($i = 0; $i < $loopnum; $i++) {
                    if($tp=='filetext'){
                        $cmt = $re[$i] ? '<a href="'. $re[$i] .'" target="_blank"><img src="'. $re[$i] .'" style="height:100px;display:inline-block;vertical-align:middle" /></a>': '';
                    }
                    showsetting(lang_st($index, 0) .'-'. ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }else{
                if($tp=='filetext'){
                    $cmt = $re ? '<a href="'. $re .'" target="_blank"><img src="'. $re .'" style="height:100px;display:inline-block;vertical-align:middle" /></a>': '';
                }
                showsetting(lang_st($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('varsubmit');
        showtablefooter(); //From: Dism��taobao��com
        showformfooter(); //From: Dism_taobao-com
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
HTML;
    }else{

        $editform = $_GET['editform'];
        $editform['color'] = $shcolor[$editform['color_title']];

        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if (in_array($__k , array('index_topad', 'index_midad', 'sh_topad'))) {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        $editform['crts'] = strtotime($editform['crts']);
        $editform['upts'] = strtotime($editform['upts']);

        if(!$editform['name2']){
            $editform['name2'] = $editform['name'];
        }

        if($editform['uid']){
            $us = getuserbyuid($editform['uid']);
            $editform['username'] = $us['username'];
        }

        foreach (array('index_topad', 'index_midad', 'sh_topad', 'index_topad_lnk', 'index_midad_lnk', 'sh_topad_lnk') as $index => $item) {
            if($editform[$item]){
                $editform[$item] = serialize(array_filter($editform[$item]));
            }else{
                $editform[$item] = '';
            }
        }

        if($editform['endts']){
            $editform['endts'] = strtotime($editform['endts']);
        }

        C::t('#xigua_st#xigua_st')->update($stid, $editform);

        cpmsg(lang_st('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&stid=$stid&page=$page", 'succeed');
    }

//edit end
}else{

if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
    $ret = C::t('#xigua_st#xigua_st')->do_delete(intval($_GET['catid']));
    if($ret){
        cpmsg(
            lang_st('delcat_succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&page=$page",
            'succeed'
        );
    }else{
        cpmsg(
            lang_st('delcat_error', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&page=$page",
            'error'
        );
    }
}
if(submitcheck('dosubmit')){
    if($new = $_GET['n']){
        /*$names = DB::fetch_all('select * from %t where level=2', array('xigua_hb_district'));
        foreach ($names as $index => $nam) {
            $new['name'][] = $nam['name'];
        }*/
        $newrow = array();
        foreach ($new['name'] as $k => $v) {
            if(is_array($v)){
                foreach ($v as $kk => $string) {
                    $newrow[] = array(
                        'name' => $string,
                        'name2' => $string,
                        'szm' => getFirstCharter($string),
                        'crts' => TIMESTAMP,
                        'upts' => TIMESTAMP,
                    );
                }
            } else {
                $newrow[] = array(
                    'name' => $v,
                    'name2' => $v,
                    'szm' => getFirstCharter($v),
                    'crts' => TIMESTAMP,
                    'upts' => TIMESTAMP,
                );
            }
        }
        foreach ($newrow as $value) {
            C::t('#xigua_st#xigua_st')->insert($value);
        }
    }

    if($_FILES['icon']){
        $icons = hb_uploads($_FILES['icon']);
    }

    if($_FILES['qr']){
        $qr = hb_uploads($_FILES['qr']);
    }

    if($r = $_GET['r']){
        foreach ($r['name'] as $cid => $name) {
            $user = getuserbyuid($r['uid'][$cid]);
            $data = array(
                'name' => $name,
                'upts' => TIMESTAMP,
                'status' => $r['status'][$cid],
//                'description' => $r['description'][$cid],
                'ratio' => $r['ratio'][$cid],
//                'uid' => $r['uid'][$cid],
//                'username' => $user['username'],
//                'endts' => $r['endts'][$cid],
                'joinprice' => $r['joinprice'][$cid],
                'displayorder' => $r['displayorder'][$cid],
                'name2' => $r['name2'][$cid],
                'szm' => strtoupper($r['szm'][$cid]),
                'ishot' => $r['ishot'][$cid],
            );
            if($_FILES['icon']['error'][$cid] === UPLOAD_ERR_OK) {
                $data['icon'] = ($icons[$cid]['errno'] == 0 ? $icons[$cid]['error'] : '');
            }
            if($_FILES['qr']['error'][$cid] === UPLOAD_ERR_OK) {
                $data['qr'] = ($qr[$cid]['errno'] == 0 ? $qr[$cid]['error'] : '');
            }

            C::t('#xigua_st#xigua_st')->update($cid, $data);
        }
    }
    if($delimg = $_GET['delimg']){
        foreach ($delimg as $catid_ => $fields_) {
            $data_ = array();
            if($fields_['icon'] == 1){
                $data_['icon'] = '';
            }
            if($fields_['qr'] == 1){
                $data_['qr'] = '';
            }
            if($data_){
                C::t('#xigua_st#xigua_st')->update(intval($catid_), $data_);
            }
        }
    }
    cpmsg(
        lang_st('succeed', 0),
        "action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&page=$page",
        'succeed'
    );
}

$wherearr = array();
$keyword = $_GET['keyword'];
if ($keyword = stripsearchkey(addslashes($keyword))) {
    $start_limit = 0;
    $wherearr[] = " (name LIKE '%$keyword%' OR name2 LIKE '%$keyword%' OR description LIKE '%$keyword%' OR username LIKE '%$keyword%' ) ";
}

$list = C::t('#xigua_st#xigua_st')->fetch_all_by_where($wherearr, $start_limit, $lpp);
$totalcount = C::t('#xigua_st#xigua_st')->fetch_count_by_page($wherearr);

$multipage = multi(
    $totalcount, $lpp, $page,
    ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&keyword=$keyword&page=$page"
);

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&page=$page", 'enctype');


echo '<div><input type="text" id="keyword" placeholder="'.lang_st('title',0) .'/'. lang_st('name2',0) .'/'.  lang_st('desc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" style="width:280px" /> ';
echo '&nbsp;';
echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st".' class="btn" >'.cplang('reset').'</a> ';
echo " </div>";


$alink = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_pub&catadd";
?>
<style>
    .imgi{height:20px;vertical-align:middle;cursor:pointer;max-width:90px}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
    .short{width:100px}
    .td23 input{width:80px!important;}
</style>
<table class="tb tb2 ">
    <tbody>
    <tr class="header">
        <th><?php lang_st('stid')?></th><th><?php lang_st('displayorder')?></th>
        <th><?php lang_st('title')?>/<?php lang_st('name2')?>/<?php lang_st('szm')?></th>
        <td><?php lang_st('zdzt')?></td>
        <td><?php lang_st('tichengbl')?></td>
        <td><?php lang_st('icon')?></td>
<!--        <td>--><?php //lang_st('qr')?><!--</td>-->
        <th><?php lang_st('hot')?></th>
        <td><?php lang_st('ssqy')?></td>
        <td><?php lang_st('gly')?>/<?php lang_st('gly2')?></td>
        <td><?php lang_st('fwdz') ?></td>
        <td><?php lang_st('joinprice') ?></td>
        <th><?php lang_st('cz')?></th>

    </tr>
    </tbody>
    <?php foreach ($list as $v) {
        $stid = $v['stid'];

        $repath = './source/plugin/xigua_st/cache/';

        $url = ($v['doamin'] ? $v['doamin']:($st_config['siteurl'] ?$st_config['siteurl']: $_G['siteurl']))."$SCRITPTNAME?id=xigua_hb&st=".$stid;
        $qrfile = $repath . md5($url) . 'a.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;
        if (!is_file($abs_qrfile)) {
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')):
                QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
            endif;
        }
        ?>
        <tbody>
        <tr class="hover">
            <td><?php echo $v['stid']?></td>
            <td>
                <input type="text" name="r[displayorder][<?php echo $stid?>]" value="<?php echo $v['displayorder']?>" class="txt" style="width:20px" /></td>
            <td>
                <div>
                    <input type="text" name="r[name][<?php echo $stid?>]" value="<?php echo $v['name']?>" class="txt" style="width:50px;margin-right:2px" />
                    <input type="text" name="r[name2][<?php echo $stid?>]" value="<?php echo $v['name2']?>" class="txt" style="width:50px;margin-right:2px" />
                    <input type="text" name="r[szm][<?php echo $stid?>]" value="<?php echo $v['szm']?>" class="txt" style="width:12px" />
                </div>
            </td>

            <td >
                <select name="r[status][<?php echo $stid?>]">
                    <option value="0" <?php echo !$v['status']?'selected':'';?>>+<?php lang_st('yxx')?>+</option>
                    <option value="1" <?php echo $v['status']==1?'selected':'';?>>=<?php lang_st('ysx')?>=</option>
                    <option value="-1" <?php echo $v['status']==-1?'selected':'';?>>=<?php lang_st('dsh')?>=</option>
                </select>
                <?php
                if($v['endts']> 0){ $v['endts_u'] = date('Y-m-d H:i:s',$v['endts'] );
                    ?>
                    <p style="color:forestgreen"><?php echo $v['endts_u']. lang_st('guoqi', 0)?></p>
                <?php  } ?>
            </td>

            <td>
                <input type="text" name="r[ratio][<?php echo $stid?>]" value="<?php echo $v['ratio']?>" class="txt" style="width:30px;margin-right:2px" />%</td>
            <td>
                <input class="short" name="icon[<?php echo $stid?>]" type="file" />
                <?php if($v['icon']){?>
                    <span class="sp">
                        <a target="_blank" href="<?php echo $v['icon']?>">
 <img class="imgi" src="<?php echo $v['icon']?>" onmouseover="$('icon<?php echo $stid?>').style.display='block'" onmouseout="$('icon<?php echo $stid?>').style.display='none'" /></a>
 <img id="icon<?php echo $stid?>" src="<?php echo $v['icon']?>"  class="imgprevew" />
 <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $stid?>][icon]" value="1" /><?php lang_st('delshort')?></label>
</span>
                <?php }?>
            </td>
            <!--<td>
                <input class="short" name="qr[<?php /*echo $stid*/?>]" type="file" />
                <?php /*if($v['qr']){*/?>
                    <span class="sp">
 <img class="imgi" src="<?php /*echo $v['qr']*/?>" onmouseover="$('qr<?php /*echo $stid*/?>').style.display='block'" onmouseout="$('qr<?php /*echo $stid*/?>').style.display='none'" />
 <img id="qr<?php /*echo $stid*/?>" src="<?php /*echo $v['qr']*/?>"  class="imgprevew" />
 <label><input type="checkbox" class="checkbox" name="delimg[<?php /*echo $stid*/?>][qr]" value="1" /><?php /*lang_st('delshort')*/?></label>
</span>
                <?php /*}*/?>
            </td>-->

            <td >
                <select name="r[ishot][<?php echo $stid?>]">
                    <option <?php if($v['ishot']==1){ echo "selected";}?> value="1"><?php lang_st('hot')?></option>
                    <option <?php if($v['ishot']==-1){echo "selected";}?> value="-1"><?php lang_st('ptzd')?></option>
                </select>
            </td>
            <td><?php echo $v['area1'];?><br>
                <?php echo $v['area2'];?><br>
                <?php echo $v['area3'];?></td>
            <td>
                <input type="text" name="r[uid][<?php echo $stid?>]" value="<?php echo $v['uid']?>" class="txt" style="width:50px;display:none" >
                <?php if($v['uid']){ ?> <img style="vertical-align:middle;width:14px;height:14px;display:inline-block" src="<?php echo avatar($v['uid'], 'middle', 1)?>" /> <?php echo $v['username']?>
                <?php }?>
                <p><?php echo $v['uid2']?></p>
            </td>
            <td>
                <a href="<?php echo $url; ?>" target="_blank"><?php lang_st('fwdz') ?></a>
                <br>
                <a href="<?php echo $qrfile; ?>" target="_blank"><img src="<?php echo $qrfile; ?>" style="display:inline-block;width:20px;"></a>
                <?php if ($_G['cache']['plugin']['xigua_hx']) { ?>
                    <a href="<?php echo 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&url=' . urlencode($url); ?>" target="_blank">
                        <img onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'" src="<?php echo 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&url=' . urlencode($url); ?>" style="display:inline-block;width:20px;"></a>
                <?php } ?>
            </td>
            <!--<td >
                <table class="pztable" style="width:350px">
                    <tr>
                        <td><?php /*lang_st('desc')*/?></td>
                        <td>
                            <textarea class="txt mini" rows="3" name="r[description][<?php /*echo $stid*/?>]"><?php /*echo $v['description'] */?></textarea></td>
                    </tr>
                </table>
            </td>-->
            <td>
                <div>
                    <input type="text" name="r[joinprice][<?php echo $stid?>]" value="<?php echo floatval($v['joinprice'])?>" class="txt" style="width:40px;" />
                </div>
            </td>
            <td>
                <a class="btn" href="<?php echo ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&stid=$stid&page=$page"?>" ><?php lang_st('xx')?></a>
                <a href="javascript:;" onclick="return _delid(<?php echo $stid?>,'<?php echo str_replace('&#039;', '', $v['name'])?>') "><?php lang_st('del')?></a>
            </td>
        </tr>
        </tbody>
    <?php }?>

    <tbody>
    <tr>
        <td>&nbsp;</td>
        <td colspan="99"><div>
                <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_st('new')?></a>
            </div></td>
    </tr>
    <?php
    if($multipage){
        showtablerow('', 'colspan="99"', $multipage);
    }
    showsubmit('dosubmit', 'submit', 'td');
    ?>
    </tbody>
</table>
</form>
<script>
    var rowtypedata = [
        [
            [1, ''],
            [99,'<div><input name="n[name][]" value="<?php lang_st('newname')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_st('del')?></a></div>']
        ]
    ];
    function _delid(id, name){
        if(confirm('<?php lang_st('del_confirm')?>' + name + '?')){
            window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_st&page=$page&del=1&formhash=".FORMHASH.'&catid='?>"+id;
        }
    }
</script>
<?php }