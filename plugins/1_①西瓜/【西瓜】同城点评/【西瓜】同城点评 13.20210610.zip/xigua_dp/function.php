<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function lang_dp($lang, $echo = 1)
{
    $ret = lang('plugin/xigua_dp', $lang);
    if ($echo) {
        echo $ret;
    } else {
        return $ret;
    }
}

function dp_star_start()
{
}

function dump($t)
{
    echo '<pre>';
    print_r($t);
    echo '</pre>';
}

function dp_get_info_by_type($type = '', $type_id = 0)
{
    global $SCRITPTNAME,$urlext,$dp_config,$_G,$noadd,$noaddjump;
    if(!$type_id){
        $type_id = $_GET['typeid'] ? daddslashes($_GET['typeid']) : daddslashes($_GET['form']['typeid']);
    }
    if(!$_GET['type']){
        $_GET['type'] = $_GET['form']['type'];
    }
    if(!$type){
        $type = $_GET['type'];
    }
    $xiaofeihou = 0;
    switch ($type) {
        case 'sh':
            $shinfo = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($type_id);
            $jumpurl = $SCRITPTNAME.'?id=xigua_hs&ac=view&shid='.$shinfo['shid'].$urlext;
            if(0 && $_GET['ac']=='add'){
                $hd_hasjoin  = C::t('#xigua_hs#xigua_hs_fukuan')->fetch_all_by_where(array('uid='.$_G['uid'].' AND shid='.$shinfo['shid']), 0, 1 );
                if(!$hd_hasjoin && $_G['cache']['plugin']['xigua_sp']){
                    $hd_hasjoin = DB::fetch_first("select * from %t where shid=%d and uid=%d and pay_ts>0 and tui_ts=0 and status in(2,5,6)", array(
                        'xigua_sp_order',
                        $shinfo['shid'],
                        $_G['uid'],
                    ));
                }
                if(!$dp_config['allowbeforedp'] && !$hd_hasjoin){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        hb_message(lang_dp('qcyhdhz',0), 'error', $jumpurl );
                    }else{
                        $noadd = lang_dp('qcyhdhz',0);
                        $noaddjump = $jumpurl;
                    }
                }elseif($hd_hasjoin){
                    $xiaofeihou = 1;
                }
            }
            $return = array(
                'xfh' => $xiaofeihou,
                'type' => lang('plugin/xigua_dp', 'sh'),
                'name' => $shinfo['name'],
                'logo' => $shinfo['logo'],
                'link' => $jumpurl,
            );
            break;
        case 'he':
            $shinfo = C::t('#xigua_he#xigua_he_huodong')->fetch_by_id($type_id);
            $jumpurl = $SCRITPTNAME.'?id=xigua_he&ac=view&hid='.$shinfo['id'].$urlext;
            if(!$_GET['shid']){
                $_GET['shid'] = $shinfo['shid'];
            }
            if($_GET['ac']=='add'){
                $hd_hasjoin = C::t('#xigua_he#xigua_he_order')->fetch_count_by_where('uid='.$_G['uid'].' AND hid='.$shinfo['id'].' AND status in(2,5,6)');
                if(!$dp_config['allowbeforedp'] && !$hd_hasjoin){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        hb_message(lang_dp('qcyhdhz',0), 'error', $jumpurl );
                    }else{
                        $noadd = lang_dp('qcyhdhz',0);
                        $noaddjump = $jumpurl;
                    }
                }elseif($hd_hasjoin){
                    $xiaofeihou = 1;
                }
            }
            $return = array(
                'xfh' => $xiaofeihou,
                'type' => lang('plugin/xigua_dp', 'he'),
                'name' => $shinfo['title'],
                'logo' => $shinfo['fengmian'] ? $shinfo['fengmian']: $shinfo['album'][0],
                'link' => $jumpurl,
            );
            break;
        case 'hm':
            $shinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_id($type_id);
            $jumpurl = $SCRITPTNAME.'?id=xigua_hm&ac=seckill_view&secid='.$shinfo['id'].$urlext;
            if(!$_GET['shid']){
                $_GET['shid'] = $shinfo['shid'];
            }
            if($_GET['ac']=='add'){
                $hm_hasjoin = DB::fetch_first("select * from %t where secid=%d and uid=%d and tkts=0 and status=2", array(
                    'xigua_hm_seckill_log',
                    $shinfo['id'],
                    $_G['uid'],
                ));
                if(!$dp_config['allowbeforedp'] && !$hm_hasjoin){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        hb_message(lang_dp('qcyhdhz',0), 'error',  $jumpurl);
                    }else{
                        $noadd = lang_dp('qcyhdhz',0);
                        $noaddjump = $jumpurl;
                    }
                }elseif($hm_hasjoin){
                    $xiaofeihou = 1;
                }
            }
            $return = array(
                'xfh' => $xiaofeihou,
                'type' => lang('plugin/xigua_dp', 'hm'),
                'name' => $shinfo['title'],
                'logo' => $shinfo['album'][0],
                'link' => $jumpurl,
            );
            break;
        case 'pt':
            $shinfo = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($type_id);
            $jumpurl = $SCRITPTNAME.'?id=xigua_pt&ac=view&gid='.$shinfo['id'].$urlext;
            if(!$_GET['shid']){
                $_GET['shid'] = $shinfo['shid'];
            }
            if($_GET['ac']=='add'){
                $hm_hasjoin = DB::fetch_first("select * from %t where gid=%d and uid=%d and pay_ts>0 and tui_ts=0 and status in(2,5,6)", array(
                    'xigua_pt_order',
                    $shinfo['id'],
                    $_G['uid'],
                ));
                if(!$dp_config['allowbeforedp'] && !$hm_hasjoin){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        hb_message(lang_dp('qcyhdhz',0), 'error',  $jumpurl);
                    }else{
                        $noadd = lang_dp('qcyhdhz',0);
                        $noaddjump = $jumpurl;
                    }
                }elseif($hm_hasjoin){
                    $xiaofeihou = 1;
                }
            }
            $return = array(
                'xfh' => $xiaofeihou,
                'type' => lang('plugin/xigua_dp', 'pt'),
                'name' => $shinfo['title'],
                'logo' => $shinfo['album'][0],
                'link' => $jumpurl,
            );
            break;
        case 'hk':
            $shinfo = C::t('#xigua_hk#xigua_hk_good')->fetch_by_good_id($type_id);
            $jumpurl = $SCRITPTNAME.'?id=xigua_hk&ac=view&gid='.$shinfo['id'].$urlext;
            if(!$_GET['shid']){
                $_GET['shid'] = $shinfo['shid'];
            }
            if($_GET['ac']=='add'){
                $hm_hasjoin = DB::fetch_first("select * from %t where gid=%d and uid=%d and status=2", array(
                    'xigua_hk_lingqu',
                    $shinfo['id'],
                    $_G['uid'],
                ));
                if(!$dp_config['allowbeforedp'] && !$hm_hasjoin){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        hb_message(lang_dp('qcyhdhz',0), 'error',  $jumpurl);
                    }else{
                        $noadd = lang_dp('qcyhdhz',0);
                        $noaddjump = $jumpurl;
                    }
                }elseif($hm_hasjoin){
                    $xiaofeihou = 1;
                }
            }
            $return = array(
                'xfh' => $xiaofeihou,
                'type' => lang('plugin/xigua_dp', 'hk'),
                'name' => $shinfo['title'],
                'logo' => $shinfo['album'][0],
                'link' => $jumpurl,
            );
            break;
        case 'hd':
            $shinfo = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_id($type_id);
            $jumpurl = $SCRITPTNAME.'?id=xigua_hd&ac=view&did='.$shinfo['id'].$urlext;
            if(!$_GET['shid']){
                $_GET['shid'] = $shinfo['shid'];
            }
            if($_GET['ac']=='add'){
                $hm_hasjoin = DB::fetch_first("select * from %t where did=%d and uid=%d and status=1", array(
                    'xigua_hd_join',
                    $shinfo['id'],
                    $_G['uid'],
                ));
                if(!$dp_config['allowbeforedp'] && !$hm_hasjoin){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        hb_message(lang_dp('qcyhdhz',0), 'error',  $jumpurl);
                    }else{
                        $noadd = lang_dp('qcyhdhz',0);
                        $noaddjump = $jumpurl;
                    }
                }elseif($hm_hasjoin){
                    $xiaofeihou = 1;
                }
            }
            $return = array(
                'xfh' => $xiaofeihou,
                'type' => lang('plugin/xigua_dp', 'hd'),
                'name' => $shinfo['title'],
                'logo' => $shinfo['album'][0],
                'link' => $jumpurl,
            );
            break;
        case 'ho':
            list($needloguid, $needlogid) = explode('_', $type_id);
            $needlog = C::t('#xigua_ho#xigua_ho_needlog')->fetch($needlogid);
            $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($needloguid ? $needloguid : $needlog['uid']);
            $jumpurl = $SCRITPTNAME.'?id=xigua_ho&ac=shifu&shifuid='.$shifu['id'].$urlext;
            if($_GET['ac']==='add'){
                $hm_hasjoin = $needlog['status']==3;
                if(!$dp_config['allowbeforedp'] && !$hm_hasjoin){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        hb_message(lang_dp('qcyhdhz',0), 'error',  $jumpurl);
                    }else{
                        $noadd = lang_dp('qcyhdhz',0);
                        $noaddjump = $jumpurl;
                    }
                }elseif($hm_hasjoin){
                    $xiaofeihou = 1;
                }
            }
            $return = array(
                'xfh' => $xiaofeihou,
                'type' => lang('plugin/xigua_ho', 'ho'),
                'name' => $shifu['realname'],
                'logo' => $shifu['avatar'],
                'link' => $jumpurl,
            );
            break;
        case 'hb':
            list($pubid, $needlogid) = explode('_', $type_id);
            $pub = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid);
            $jumpurl = $SCRITPTNAME.'?id=xigua_hb&ac=view&pubid='.$pubid.$urlext;

            $return = array(
                'xfh' => 1,
                'type' => lang('plugin/xigua_hb', 'fabu0'),
                'name' => cutstr(strip_tags($pub['description']), 80),
                'logo' => $pub['imglist'][0] ? $pub['imglist'][0] : avatar($pub['uid'], 'small', true),
                'link' => $jumpurl,
            );
            break;
        case 'sp':
            $shinfo = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($type_id);
            $jumpurl = $SCRITPTNAME.'?id=xigua_sp&ac=view&gid='.$shinfo['id'].$urlext;
            if(!$_GET['shid']){
                $_GET['shid'] = $shinfo['shid'];
            }
            if($_GET['ac']=='add'){
                $hm_hasjoin = DB::fetch_first("select * from %t where gid=%d and uid=%d and pay_ts>0 and tui_ts=0 and status in(2,5,6)", array(
                    'xigua_sp_order',
                    $shinfo['id'],
                    $_G['uid'],
                ));
                if(!$dp_config['allowbeforedp'] && !$hm_hasjoin){
                    if($_SERVER['REQUEST_METHOD'] == 'POST'){
                        hb_message(lang_dp('qcyhdhz',0), 'error',  $jumpurl);
                    }else{
                        $noadd = lang_dp('qcyhdhz',0);
                        $noaddjump = $jumpurl;
                    }
                }elseif($hm_hasjoin){
                    $xiaofeihou = 1;
                }
            }
            $return = array(
                'xfh' => $xiaofeihou,
                'type' => lang('plugin/xigua_dp', 'pt'),
                'name' => $shinfo['title'],
                'logo' => $shinfo['album'][0],
                'link' => $jumpurl,
            );
            break;
    }
    return $return;
}

function get_star($star){
    $s = '';
    for($i=0;$i<$star;$i++){
        $s .= '<img style="max-width:1rem" src="source/plugin/xigua_dp/static/img/star.png">';
    }
    for($j=0;$j<5-$star;$j++){
        $s .= '<img style="max-width:1rem" src="source/plugin/xigua_dp/static/img/unstar.png">';
    }
    return $s;
}

function dp_get_shids_by_uid(){
    global $_G;
    $shids = array();
    if(!$_G['uid'] || !$_G['cache']['plugin']['xigua_hs']){
        return $shids;
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array_keys($shids1), array_keys($shids2));
    return $shids;
}

function dp_nl2br($txt){
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}

function dp_get_pflx($hy_id = 0){
    global $dp_config,$score_names,$score_colors,$pfary;
    if($dp_config['hylx']){
        foreach (explode("\n", trim($dp_config['hylx'])) as $item) {
            list($hyid, $pfnames) = explode('=', trim($item));
            if($hy_id == intval($hyid)){
                $dp_config['pflx'] = implode("\n", explode(',', trim($pfnames)));
                break;
            }
        }
    }
    $_i = 1;
    foreach (explode("\n", trim($dp_config['pflx'])) as $item) {
        $pfary[$_i++] = trim($item);
    }
    foreach (explode("\n", trim($dp_config['fsms'])) as $index => $item) {
        list($score, $score_name, $score_color) = explode("|", trim($item));
        $score_names[] = $score_name;
        $score_colors[] = $score_color;
    }
}