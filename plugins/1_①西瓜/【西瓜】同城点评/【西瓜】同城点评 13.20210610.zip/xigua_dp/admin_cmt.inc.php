<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_dp/function.php';
$dp_config = $_G['cache']['plugin']['xigua_dp'];
$page = max(1, intval($_GET['page']));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;
$opens = unserialize($_G['cache']['plugin']['xigua_dp']['opens']);
$types = array(
    'sh' => lang_dp( 'sh',0),
    'he' => lang_dp( 'he',0),
    'hm' => lang_dp( 'hm',0),
    'pt' => lang_dp( 'pt',0),
    'sp' => lang_dp( 'sp',0),
    'hk' => lang_dp( 'hk',0),
    'hd' => lang_dp( 'hd',0),
    'hb' => lang_dp( 'hb',0),
    'ho' => lang_dp( 'ho',0),
);

$pfary = array();
$_i = 1;
foreach (explode("\n", trim($dp_config['pflx'])) as $item) {
    $pfary[$_i++] = trim($item);
}
$fsms = $score_names = $score_colors = array();
foreach (explode("\n", trim($dp_config['fsms'])) as $index => $item) {
    list($score, $score_name, $score_color) = explode("|", trim($item));
    $score_names[] = $score_name;
    $score_colors[] = $score_color;
}

if($cid = intval($_GET['cid'])){

    $res = C::t('#xigua_dp#xigua_dp_comment')->fetch($cid);
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $res = array (
            );
            $neww = 1;
        }

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_cmt&cid=$cid", 'enctype');
        showtableheader();
        showtitle(lang_dp('spgl',0) . ($cid>0?$cid:''). "&nbsp;&nbsp;<a class='abtn' href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_cmt'> ".lang_dp('back',0)."</a>");



        foreach ($res as $index => $re) {
            if(in_array($index, array('isnew' ,'cid','tagid', 'stid'))){
                continue;
            }

            $listinfo = C::t('#xigua_hs#xigua_hs_hangye')->list_all(1);
            C::t('#xigua_hs#xigua_hs_hangye')->init($listinfo);
            $cat_list = C::t('#xigua_hs#xigua_hs_hangye')->get_tree_array(0);
            $hangye = "<select name=\"editform[hy_id]\">";
            foreach ($cat_list as $k => $v) {
                $hangye .= "<option ".($res['hy_id']== $v['id'] ? 'selected': '')." value=\"$v[id]\">$v[name]</option>";
                foreach ($v['child'] as $kk => $vv) {
                    $s = '';
                    if($res['hy_id']== $vv['id']){
                        $s = 'selected';
                    }
                    $hangye .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;---$vv[name]</option>";
                }
            }
            $hangye .= '</select>';

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('crts', 'upts', 'starttime', 'bstarttime', 'endtime', 'bendtime','dig_startts','dig_endts'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('shid'))){
                $cs = '<select name="editform[shid]">';
                foreach (DB::fetch_all('select shid,`name` from %t WHERE display=1 AND endts>=%d ORDER BY shid asc', array(
                    'xigua_hs_shanghu',
                    TIMESTAMP
                ), 'shid') as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['shid']} {$c['name']}</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('thumb'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('niming' ,'xfh','jx'))){
                $tp = 'radio';
            }elseif(in_array($index, array('srange'))){
                $re = explode("\t", $re);
                $cs = '<select name="editform[srange][]" multiple="multiple">';
                foreach ($svicerange as $__v) {
                    $shortv = explode('#', $__v);
                    $shortv = $shortv[0];
                    $s = '';
                    if(in_array($shortv, $re)){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$shortv'>$shortv</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('type'))){
                $cs = '<select name="editform[type]">';
                foreach ($types as $__k => $__v) {
                    $s = '';
                    if($__k == $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$__k'>$__v</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('hy_id'))){
                $tp = $hangye;
            }

            if(in_array($index, array('fengmian'))){
                $tp = 'filetext';
            }
            if (in_array($index, array('album'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $sp_config = $_G['cache']['plugin']['xigua_dp'];
                $loopnum = $sp_config['maximg'];
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_dp($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'message'){
                $_tmp1 = lang_dp($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[message]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                showsetting(lang_dp($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); //Dism��taobao��com
        showformfooter(); /*dis'.'m.tao'.'bao.com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach (array('crts', 'upts') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }


        foreach (array('album') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }

        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($editform['shid']);
        if(!$sh){
            cpmsg(lang_dp('shnotexists',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_cmt&cid=$cid", 'error');
        }
        $editform['shid']       = $sh['shid'];

/*        $srg = array();
        foreach ($editform['srange'] as $index => $item) {
            list($_rangt, $_rangd) = explode("#", $item);
            $srg[] = $_rangt;
        }
        $editform['srange']     = implode("\t", $srg);*/

        if($cid>0){
            $rs = C::t('#xigua_dp#xigua_dp_comment')->update($cid, $editform);
            $hid = $cid;
        }else{
            $hid = C::t('#xigua_dp#xigua_dp_comment')->insert($editform, 1);
        }

        cpmsg(lang_dp('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_cmt&cid=$hid", 'succeed');
    }


}else{
    if(submitcheck('permsubmit')){
        if($delete = dintval($_GET['delete'], true)) {
            $r = C::t('#xigua_dp#xigua_dp_comment')->deletes($delete);
        }
        if($r){
            cpmsg(lang_hb('delete_succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_cmt&page=$page", 'succeed');
        }
    }


    echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_cmt&page=$page");
    echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_dp('repseaarch2',0).'" value="'.$_GET['keyword'].'" class="txt" /> ';
    echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
    echo '</div>';
    showtableheader(lang_hb('pinglunguanli', 0));
    showtablerow('class="header"',array(),array(
        lang('plugin/xigua_hb','del'),
        lang_hb('username', 0),
        lang('plugin/xigua_dp','bdp'),
        lang('plugin/xigua_hb','note'),
        lang('plugin/xigua_dp','pf'),
        lang('plugin/xigua_hb','crts'),
        lang('plugin/xigua_hb','caozuo'),
    ));

    $wherearr = array();
    $keyword = stripsearchkey(addslashes($_GET['keyword']));
    if(is_numeric($keyword) && $keyword<9999999999){
        $wherearr[] = " (authorid='$keyword' OR cid=$keyword OR shid=$keyword OR typeid=$keyword) ";
    }elseif($keyword){
        $wherearr[] = " ( author LIKE '%$keyword%' OR message LIKE '%$keyword%' OR subject LIKE '%$keyword%' ) ";
    }

    $_GET['needsh'] = 1;
    $res = C::t('#xigua_dp#xigua_dp_comment')->fetch_all_bypage($wherearr, $start_limit, $lpp);
    $icount = C::t('#xigua_dp#xigua_dp_comment')->fetch_count_bypage($wherearr);

    $uids = array();
    foreach ($res as $v) {
        $uids[] = $v['authorid'];
    }
    if ($uids) {
        $mobiles = DB::fetch_all('SELECT uid,mobile,realname FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
    }

    foreach ($res as $v) {
        $cid = $v['cid'];
        $tyinfo = dp_get_info_by_type($v['type'], $v['typeid']);

        $img = $v['album_ary'];
        $vimg = array();
        if($v['video_cover'] || $v['video']){
            $img[] = $v['video_cover'] ;
        }
        if($img){
            foreach ($img as $index => $item) {
                $vimg[] = "<a href='$item' style='margin-right:2px' target='_blank'><img src='$item' style='height:40px;display:inline-block' /></a>";
            }
        }

        $scoreinfo = '';

        dp_get_pflx($v['hy_id']);
        foreach ($pfary as $__k => $__v) {
            $scoreinfo .= "<div class=\"dp_dafen_dafen df_{$v['star'.$__k]}\">{$__v}{$v['star'.$__k]}</div>";
        }
        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$cid' /> $cid",
            $v['author'].'(UID:'.$v['authorid'].')'.'<br>'.
            lang_dp('realname',0).':'.$mobiles[$v['authorid']]['realname'].'<br>'.
            lang_dp('mobile',0).':'.  $mobiles[$v['authorid']]['mobile'] ,
            "[{$tyinfo['type']}]".$tyinfo['name'].'(ID:'.$v['typeid'].')<BR>'.
            ($v['sh']['name'] ? $v['sh']['name'].'(ID:'.$v['shid'].')' : ''),
            "<div style='width:200px'>".cutstr($v['message'], 100, '...'). ($vimg ? '<br>'.implode('', $vimg) : '')."</div>",
            $scoreinfo,
            date('m-d H:i:s', $v['crts']),
            '<a class=\'abtn\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_cmt&cid=$cid" . '">' . lang_dp('edit', 0) . '</a> '.
            '',
        ));
    }
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_cmt&lpp=$lpp", 0, 10);
    showsubmit('permsubmit', 'submit', 'del', '', $multipage);
    showtablefooter(); //Dism��taobao��com
    showformfooter(); /*dis'.'m.tao'.'bao.com*/
}