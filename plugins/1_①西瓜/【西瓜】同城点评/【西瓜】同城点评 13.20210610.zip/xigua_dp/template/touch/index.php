<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{template xigua_dp:header}-->
<!--{if $_G['cache']['plugin']['xigua_dp']['defaultlogo']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="{$_G['cache']['plugin']['xigua_dp']['defaultlogo']}" /></div><!--{/if}--><!--{if $_G['cache']['plugin']['xigua_dp']['allowfz'] && $_G['cache']['plugin']['xigua_st']['showfz']}-->
<header class="x_header bgcolor_11 cl  weui-flex f15" style="background:transparent!important;position:absolute">
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_dp");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
</header>
<!--{/if}-->

<div class="page__bd ">

    <!--{if $topnavslider}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $topnavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $topnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->

    <!--{if $indexlist}-->
    <ul class="inedxicon cl">
        <!--{loop $indexlist $_k $_v}-->
        <li><a href="$_v[adlink]"><img src="$_v[icon]"></a></li>
        <!--{/loop}-->
    </ul>
    <!--{/if}-->

    <div class="weui-cells fixbanner before_none after_none">
        <div class="weui-navbar weui-banner nobg fixbanner_in after_none">
            <a href="javascript:;" data-save="nav=new" class="weui-navbar__item dp_cat <!--{if !$_GET[nav]||$_GET[nav]=='new'}-->weui_bar__item_on<!--{/if}-->" data-id="0">
                <span>{lang xigua_dp:tj}</span>
            </a>
            <a href="javascript:;" data-save="nav=shipin" class="weui-navbar__item dp_cat <!--{if $_GET[nav]=='shipin'}-->weui_bar__item_on<!--{/if}-->" data-id="0" >
                <span>{lang xigua_dp:shipin}</span>
            </a>
            <a href="javascript:;" data-save="nav=near" class="weui-navbar__item dp_cat <!--{if $_GET[nav]=='near'}-->weui_bar__item_on<!--{/if}-->" data-needgeo="1" data-id="0">
                <span>{lang xigua_hs:near}</span>
            </a>
            <!--{loop $hyinfo $_k $_v}-->
            <a href="javascript:;" data-save="nav=hy_$_v[id]" class="weui-navbar__item dp_cat <!--{if $_GET[nav]=='hy_'.$_v[id]}-->weui_bar__item_on<!--{/if}-->" data-id="{$_v[id]}" >
                <span>{$_v[name]}</span>
            </a>
            <!--{/loop}-->
        </div>
    </div>
    <!--{template xigua_dp:dp}-->

</div>
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<!--{eval $dp_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_dp:footer}-->