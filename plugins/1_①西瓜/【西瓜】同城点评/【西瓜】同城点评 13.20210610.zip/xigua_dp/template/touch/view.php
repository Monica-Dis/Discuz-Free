<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{template xigua_dp:header}-->
<div class="dp_view_nav">
    <a href="$back_to"><i class="iconfont icon-fanhui"></i></a>
    <a href="$SCRITPTNAME?id=xigua_dp"><i class="iconfont icon-index f22"></i></a>
</div>
<div class="page__bd">
<!--{if !$dp_config[shipinlunb] &&$v['video']&& is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
<video poster="{$v['video_cover']}" style="width:100%" src="{$v['video']}" controls="controls" <!--{if !IN_PROG}-->x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<!--{/if}-->></video>
<div style="width:0;height:0;overflow:hidden;display:none"><img src="{$v['video_cover']}" /></div>
<!--{else}-->
<div class="dp_swipe cl" style="position:relative;margin:0;overflow:hidden" <!--{if $dp_config[shipinlunb] && $v['video']&& is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->data-speed="100000000"<!--{/if}-->>
    <div class="swipe-wrap" style="transition: all .3s;-webkit-transition: all .3s;background:#000">
        <!--{if $dp_config[shipinlunb] && $v['video']&& is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
        <div class="swp" style="overflow:hidden;<!--{if $dp_config[topswiperh]}-->height:{$dp_config[topswiperh]}px<!--{/if}-->">
            <video poster="{$v['video_cover']}" style="width:100%;<!--{if $dp_config[topswiperh]}-->height:{$dp_config[topswiperh]}px<!--{/if}-->" src="{$v['video']}" controls="controls" <!--{if !IN_PROG}-->x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<!--{/if}-->></video>
        </div>
        <!--{/if}-->
        <!--{loop $v[album_ary] $slider}-->
        <div class="swp"><img src='$slider' <!--{if $dp_config[topswiperh]}-->style="height:{$dp_config[topswiperh]}px"<!--{/if}--> /></div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $v[album_ary] $k $slider}-->
            <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{/if}-->
<div class="dp_view bgf">
    <div class="dp_top weui-flex">
        <a href="{$_v[authorlink]}"><img class="dpavatar" src="{$v[avatar]}" /></a>
        <div class="weui-flex__item">
            <div class="userc">{$v[author]}</div>
            <div class="c9 f12">{$v[crts_u]}</div>
        </div>
        <div class="pr">
            <!--{if !$v[niming]}-->
            <a class="gzusebtn <!--{if !$hasfave}-->main_color<!--{/if}-->" id="gz{$v[authorid]}" data-to="{$v[authorid]}">
                <!--{if !$hasfave}-->{lang xigua_hb:jgz}<!--{else}-->{lang xigua_hb:ygz}<!--{/if}-->
            </a>
            <!--{/if}-->
        </div>
    </div>
    <div class="dp_main <!--{if $v[jx]}-->dp_yz<!--{/if}-->">
<div class="dp_tuijian weui-flex" style="display:none">
    <div class="c6">tuijian:</div>
    <div>
        <!--{loop $v[tagid_ary]  $_k $_v}-->
        <a class="userc">$_v</a>
        <!--{/loop}-->
    </div>
</div>
    <!--{if $v['xfh']}-->
        <span class="mod-feed-tag b-color2" style="float:none;">{lang xigua_dp:xfh}</span>
    <!--{/if}-->
        <div class="dp_dafen weui-flex">
            <div class="dp_dafen_tit">{lang xigua_dp:df}</div>
            <div class="dp_dafen_stars">{echo get_star($v[star1]);}</div>
            <!--{if $v[renjun]}-->
            <div class="dp_dafen_ft">{$v[renjun]}{lang xigua_dp:yuan}/{lang xigua_dp:ren}</div>
            <!--{/if}-->
        </div>
        <div class="dp_dafen cl">
            <!--{loop $pfary $__k $__v}-->
            <div class="dp_dafen_dafen df_{$v['star'.$__k]}">{$__v}{$score_names[$v['star'.$__k]-1]}</div>
            <!--{/loop}-->
        </div>

        <!--{if !$dp_config[shipinlunb] && $v['video']&& is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
        <div class="dp_pics cl feed-preview-pic">
            <!--{loop $v[album_ary] $k $img}-->
            <span class="imgloading">
                <img src="$img">
            </span>
            <!--{/loop}-->
        </div>
        <!--{/if}-->

        <div class="dp_main_desc">
            {echo dp_nl2br($v[message]);}
        </div>

        <!--{if $v[sh]}-->
        <div class="dp_top_good">
            <div class="dp_top_gdmsd sh_jump" data-id="{$v[sh]['shid']}">
                <div class="dp_top_gimg" style="background-image: url({$v[sh][logo]});"></div>
                <div class="dp_top_gdesc_outer">
                    <p class="dp_top_gdesc">{$v[sh][name]}</p>
                    <!--{template xigua_dp:shbtn}-->
                </div>
            </div>
            <!--{template xigua_dp:shtype}-->
        </div>
        <!--{/if}-->

        <!--{if $dp_config[defaultlogo]}-->
        <div style="width:0;height:0;overflow:hidden;display:none"><img src="{$dp_config['defaultlogo']}" /></div>
        <!--{/if}-->
        <div class="cl dg_cmtfld">
            <p class="time">
                <span><em>$v[views]</em>{lang xigua_hb:liulandot}</span>
                <span><em>$v[shares]</em>{lang xigua_dp:fx}</span>
            </p>
        </div>

        <div class="r" id="r_{$v[cid]}"></div>
        <div class="cmt-wrap" id="cmt_wrap_{$v[cid]}">
            <span class="likenum dp_praise" data-id="$v[cid]" data-href="$SCRITPTNAME?id=xigua_dp&ac=misc&do=vote&cid={$v[cid]}&formhash={FORMHASH}">
                <img src="source/plugin/xigua_dp/static/img/zan.png" class="btn_zan">
                <em id="praises_{$v[cid]}" class="praises_{$v[cid]}">$v[zans]</em>
            </span>
            <div class="like cl">
                <span class="likeuser z" id="praise_list_{$v[cid]}">
                <!--{if $v[zanlist]}-->
                <!--{loop $v[zanlist] $_v}-->
                    <a href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$_v[uid]" class="uavatar_a"><img class="uavatar" src="{echo avatar($_v[uid], 'middle', true);}" /></a>
                <!--{/loop}-->
                <!--{else}-->
                    <em class="dp_rep_empty">{lang xigua_dp:kldz}</em>
                <!--{/if}-->
                </span>
            </div>
        </div>

        <!--{if ($_G[uid] && $_G[uid]==$v['authorid']) || IS_ADMINID|| in_array($v['shid'], dp_get_shids_by_uid())}-->
        <div class="po-act po-act1">
            <a class="weui-btn weui-btn_mini p0 mt0" href="javascript:;" onclick="dp_edit('{$v[type]}','{$v[typeid]}','{$v[cid]}');">{lang xigua_dp:edit}</a>
            <a class="weui-btn weui-btn_mini p0 mt0" href="javascript:;" onclick="dp_delete('{$v[cid]}');">{lang xigua_dp:del}</a>
        </div>
        <!--{/if}-->

    </div>
</div>
    <div class="dp_view bgf mt10">
        <div class="dp_view_reply_title"><span>{lang xigua_dp:pl}</span><em> ({$replies_count})</em></div>
        <div class="weui-panel weui-panel_access mt0 after_none">
            <div class="weui-panel__bd comment_ul" id="list" data-id="{$v[cid]}">
            </div>
            <!--{template xigua_hb:loading}-->
        </div>
    </div>

    <div class="view_bottom weui-flex border_top dp_ft">
        <div class="view_bottom_z cmtBar">
            <a href="javascript:;" class="weui-tabbar__item comment_dp" id="comment_{$v[cid]}" data-id="{$v[cid]}" data-multi="1"><em>{lang xigua_dp:sdsm}</em></a>
        </div>
        <div class="view_bottom_z">
            <a href="javascript:;" class="weui-tabbar__item dp_ft_a dp_praise" data-id="$v[cid]" data-href="$SCRITPTNAME?id=xigua_dp&ac=misc&do=vote&cid={$v[cid]}&formhash={FORMHASH}">
                <img src="source/plugin/xigua_dp/static/img/zan.png" class="btn_mg" />
                <em class="innernum"><i class="praises_{$v[cid]}">$v[zans]</i></em>
            </a>
        </div>
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hb&ac=pub" class="weui-tabbar__item dp_ft_a comment_dp" data-id="{$v[cid]}" data-multi="1">
                <img src="source/plugin/xigua_dp/static/img/rep.png" class="btn_mg" />
                <!--{if $replies_count}-->
                <em class="innernum"><i class="">$replies_count</i></em>
                <!--{/if}-->
            </a>
        </div>
    </div>
</div>
<script>
var loadingurl = window.location.href+'&ac=reply_li&inajax=1&multi=1&cid={$v[cid]}&page=';
scrollto = 0;
var lockIng = 0;
</script>
<!--{template xigua_dp:haibao}-->
<!--{eval $dp_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_dp:footer}-->
<script>
$('div.dp_swipe').each(function () {
    dp_slider($(this), $(this).data('speed') || 3000)
});
var dp_seiper = null;
function dp_slider(_this, auto) {
    var bullets = _this.find('nav.bullets');
    var position = _this.find('ul.position');
    dp_seiper = new Swipe2(_this[0], {
        visibilityFullFit : true,
        startSlide: 0, speed: 500, auto: auto, continuous: true, callback: function (index) {
            if (bullets.length > 0) {
                bullets.find('em:first-child').text(index + 1);
            }
            if (position.length > 0) {
                var selectors = position[0].children;
                for (var t = 0; t < selectors.length; t++) {
                    selectors[t].className = selectors[t].className.replace("current", "");
                }
                if (typeof selectors[(index) % (selectors.length)] != 'undefined') {
                    selectors[(index) % (selectors.length)].className = "current";
                }
            }
            var H = $(".swipe-wrap .swp").eq(index).height();
            $('.dp_swipe .swipe-wrap').css('height', H);
            $('.dp_swipe').css('height', H);
        }
    });
}
var hnew = $(".swipe-wrap .swp:first-child").height();
$('.dp_swipe .swipe-wrap').css('height', hnew);
$('.dp_swipe').css('height', hnew);
</script>