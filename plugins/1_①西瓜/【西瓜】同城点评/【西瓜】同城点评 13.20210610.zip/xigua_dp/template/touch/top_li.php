<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{loop $list $_k $v}-->
<div class="dp_top_item <!--{if $v[jx]}-->dp_yz<!--{/if}--> border_bottom" data-id="$v[cid]">
    <div class="dp_top_head">
        <div class="useravatu">
            <a href="{$v[authorlink]}"><img class="avatu" src="{$v[avatar]}"></a>
        </div>
        <div class="userinfou">
            <div class="userinfou_uname">
                $v[author]
            </div>
            <div class="userinfou_star">
                <div class="dp_dafen_stars">{echo get_star($v[star1]);}</div>
            </div>
            <div class="userinfou_ts">
                $v[crts_u]
            </div>
        </div>
    </div>
    <!--{if $v['xfh']}-->
    <span class="mod-feed-tag b-color2" style="float:none;">{lang xigua_dp:xfh}</span>
    <!--{/if}-->
    <p class="dp_top_cmt dp_jump" data-id="$v[cid]">$v[message]</p>

<!--{if $dp_config[showinyz]}-->
    <div class="pr">
        <div class="dp_list_li_img cl dp_jump" data-id="$v[cid]">
            <!--{if $v['video'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
            <!--{eval array_pop($v[album_ary1]);}-->
            <div class="imgloading dp_vide dp_jump" data-id="$v[cid]">
                <em class="emvbg" style="background-image:url({$v['video_cover']})"></em><em class="emvdo"></em>
            </div><!--{/if}-->
            <!--{loop $v[album_ary1] $__k $__v}-->
            <div class="imgloading"><img src="$__v" /></div>
            <!--{/loop}-->
        </div>
        <!--{if ($imgc = count($v[album_ary]))>3}-->
        <div class="imgc"><i class="iconfont icon-img f12"></i> $imgc</div>
        <!--{/if}-->
    </div>
<!--{/if}-->
    <div class="dp_top_good" >
        <div class="dp_top_gdmsd sh_jump" data-id="{$v[sh]['shid']}">
            <div class="dp_top_gimg" style="background-image: url({$v[sh][logo]});"></div>
            <div class="dp_top_gdesc_outer">
                <p class="dp_top_gdesc">{$v[sh][name]}</p>
                <!--{template xigua_dp:shbtn}-->
                <a  class=" dp_top_pr main_bg" href="javascript:;" >{lang xigua_dp:qkk}</a>
            </div>
        </div>
        <!--{template xigua_dp:shtype}-->
        <!--{if $v[zanlist]}-->
        <div class="dp_top_ulist border_top dp_jump" data-id="$v[cid]">
            <div>
                <!--{loop $v[zanlist] $_v}-->
                <img class="dp_top_user" src="{echo avatar($_v, 'middle', true);}">
                <!--{/loop}-->
                <!--{if $v[zans]>8}-->
                <img class="dp_top_user" src="source/plugin/xigua_dp/static/img/uv.png">
                <!--{/if}-->
            </div>
            <div class="dp_top_zan">{lang xigua_dp:y}{$v[zans]}{lang xigua_dp:rxh}</div>
        </div>
        <!--{/if}-->
    </div>
    <!--{if ($_G[uid] && $_G[uid]==$v['authorid']) || IS_ADMINID|| ($dp_config[shallowdel] && in_array($v['shid'], dp_get_shids_by_uid()))}-->
    <div class="po-act po-act1">
        <a class="weui-btn weui-btn_mini p0 mt0" href="javascript:;" onclick="dp_edit('{$v[type]}','{$v[typeid]}','{$v[cid]}');">{lang xigua_dp:edit}</a>
        <a class="weui-btn weui-btn_mini p0 mt0" href="javascript:;" onclick="dp_delete('{$v[cid]}');">{lang xigua_dp:del}</a>
    </div>
    <!--{/if}-->
</div>
<!--{/loop}-->