<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{eval
if($_GET['type'] == 'sh'):
    $desc = DB::result_first("SELECT jieshao from %t where shid=%d", array('xigua_hs_shanghu', $_GET[typeid]));
    $desc = trim(strip_tags($desc));
endif;
}-->
<!--{template xigua_dp:header}-->
<div class="page__bd ">
    <!--{if $_GET['type']}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <div id="list" class="mod-post x-postlist p0 cl" style="background:#fff"></div>
    <!--{template xigua_hb:loading}-->
    <script>
        var loadingurl = _APPNAME+'?id=xigua_dp&ac=dp_li&tpl=top_li&needsh=1&needzan=1&jx=1&type=$_GET[type]&typeid=$_GET[typeid]&inajax=1&page=';
        scrollto = 1;
        var lockIng = 0;
    </script>
</div>
<!--{eval $dp_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_dp:footer}-->