<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{template xigua_hb:common_header}-->
<link rel="stylesheet" href="source/plugin/xigua_dp/static/dp.css?32{VERHASH}" />
<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?3{VERHASH}" />
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}.gzbtn{background-color:$config[maincolor]}
</style>
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";
var GOOGLE = "{$_G['cache']['plugin']['xigua_hs']['google']}", PUB_VARID = 0, IGNORETIP = 0;var  PLZALLOW = '{lang xigua_hs:plzallow}', gengduodongtai = '{lang xigua_hs:gengduodongtai}', guanzhu_sj = '{lang xigua_hs:guanzhu_sj}', yiguanzhu = '{lang xigua_hs:yiguanzhu}', jiaguanzhu='{lang xigua_hs:jiaguanzhu}';
</script>