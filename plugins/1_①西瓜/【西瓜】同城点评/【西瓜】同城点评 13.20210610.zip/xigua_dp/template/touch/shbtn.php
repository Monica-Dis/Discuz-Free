<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<p class="f13 c9 dp_sh_p"><i class="f13 vm pr-1 iconfont icon-shijian" style="left:1px"></i> {lang xigua_hs:opentime}: {$v[sh][opentime]}</p>
<p class="f13 c9 dp_sh_p"><i class="iconfont icon-mudedi vm f14 pr-1"></i>{$v[sh][addr]}</p>
