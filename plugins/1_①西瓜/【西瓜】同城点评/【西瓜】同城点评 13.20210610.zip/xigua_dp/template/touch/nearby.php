<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{template xigua_dp:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hs/static/hs.css?2{VERHASH}" /><style>.dp_top_item{background:#fff;padding: 15px;margin: 0;}</style>
<!--{if $_G['cache']['plugin']['xigua_dp']['defaultlogo']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="{$_G['cache']['plugin']['xigua_dp']['defaultlogo']}"/></div><!--{/if}-->
<div class="page__bd ">
    <!--{if $indexlist}-->
    <ul class="inedxicon cl">
        <!--{loop $indexlist $_k $_v}-->
        <li><a href="$_v[adlink]"><img src="$_v[icon]"></a></li>
        <!--{/loop}-->
    </ul>
    <!--{/if}-->

    <div class="weui-cells fixbanner before_none">
        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="javascript:;" id="neardp" data-save="nav=near" class="weui-navbar__item needgeo dp_cat <!--{if $_GET[nav]=='near'}-->weui_bar__item_on<!--{/if}-->" data-needgeo="1" data-id="0">
                <span>{lang xigua_hs:near}{lang xigua_dp:dp}</span></a>
            <a href="javascript:;" id="nearsh" data-loadingurl="$SCRITPTNAME?id=xigua_hs&ac=myshop_li&viewtype=near&inajax=1<!--{if $_GET[lat]}-->&lat={$_GET['lat']}&lng={$_GET['lng']}<!--{/if}-->&page=" data-save="nav=nearsh" data-cls="1" class="weui-navbar__item needgeo dp_cat <!--{if $_GET[nav]=='nearsh'}-->weui_bar__item_on<!--{/if}-->" data-needgeo="1" data-id="0">
                <span>{lang xigua_hs:near}{lang xigua_hs:shangjia}</span></a>
            <a href="javascript:;" id="guanzhu" data-loadingurl="$SCRITPTNAME?id=xigua_dp&ac=dp_li&tpl=top_li&isfav=1&needsh=1&needzan=1&inajax=1&page=" data-save="nav=guanzhu" data-cls="1" class="weui-navbar__item dp_cat <!--{if $_GET[nav]=='guanzhu'}-->weui_bar__item_on<!--{/if}-->" data-id="0">
                <span>{lang xigua_hs:guanzhu}</span></a>
        </div>
    </div>
    <div id="list" class="mod-post x-postlist cl p0"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>
scrollto = 1;
var lockIng = 0;
var HB_INWECHAT = '{HB_INWECHAT}', mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",
HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";
</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<!--{if $_GET[nav]=='near'}-->
<script>
    /*javascript:hs_getlocation(function (position) {latold=(position.latitude||position.lat);lngold=(position.longitude||position.lng);var lngstr ='&lat='+latold+'&lng='+lngold;location.href='plugin.php?nav=near&id=xigua_dp&ac=jingxuan&do=nearby'+lngstr;});*/
    indexloadingurl = _APPNAME+'?id=xigua_dp&ac=dp_li&inajax=1&hy_id=0&lat={$_GET[lat]}&lng={$_GET[lng]}&page=';
    $('#neardp').trigger('click');
    setTimeout(function(){
        if(typeof wx!='undefined') {
            wx.ready(function () {
                $('#neardp').trigger('click');
            });
        }else{$('#neardp').trigger('click');}
    }, 200);</script>
<!--{/if}-->
<!--{eval $dp_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_dp:footer}-->
