<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{template xigua_dp:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd adddiv">
    <form  action="$SCRITPTNAME?id=xigua_dp&ac=add&st={$_GET['st']}" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}">
        <input name="form[type]" value="{echo $old_data[type]?$old_data[type]:$_GET['type']}" type="hidden">
        <input name="form[typeid]" value="{echo $old_data[typeid]?$old_data[typeid]:$_GET['typeid']}" type="hidden">
        <input name="form[stid]" value="{echo $old_data[stid]?$old_data[stid]:$_GET['st']}" type="hidden">
        <input name="form[cid]" value="{$old_data[cid]}" type="hidden">
        <input name="ref" value="{$_GET[ref]}" type="hidden">
        <input name="shid" value="{echo $old_data ? $old_data[shid] : $_GET['shid']}" type="hidden">

    <div class="dp_shlink">
        <a class="sp_sh_jump" href="{$typeinfo[link]}">
            <img class="confirm_shlogo" src="{$typeinfo[logo]}">
            <span class="f13">{$typeinfo[name]}</span>
            <i class="f13 iconfont icon-jinrujiantou"></i>
        </a>
    </div>

    <div class="weui-cells mt0">
        <!--{loop $pfary $_k $_v}-->
        <!--{eval $starN = 'star'.$_k;}-->
        <div class="weui-cell">
            <div class="weui-cell__hd">
                <label class="weui-label">$_v</label>
            </div>
            <div class="weui-cell__bd">
                <div id="pf{$_k}"></div>
                <input name="form[$starN]" id="$starN" value="{$old_data[$starN]}" type="hidden">
            </div>
            <div class="weui-cell__ft"> <div id="pftip{$_k}"></div></div>
        </div>
        <!--{/loop}-->

        <div class="weui-cell" id="hide_subject" <!--{if $old_data && $old_data[subject]}-->
        <!--{else}-->style="display:none"<!--{/if}-->>
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_dp:bt}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[subject]" placeholder="{lang xigua_dp:tjyjh}" value="{$old_data[subject]}">
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <textarea class="weui-textarea" name="form[message]" placeholder="{lang xigua_dp:qin}" rows="3">{$old_data[message]}</textarea>
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="post-tags cl" id="post-typeid">
                    <a class="weui-btn weui-btn_mini weui-btn_default subject_ctrl" href="javascript:;" >
                        <i class="iconfont icon-tianjia1 main_color f12 bold"></i> {lang xigua_dp:bt}</a>
                </div>
            </div>
        </div>

        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">{lang xigua_dp:splbt}</p>
                        <div class="weui-uploader__info">{echo str_replace('n', $dp_config['maximg'], lang_dp('zuiduozhao',0))}
                        </div>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-max="{$dp_config['maximg']}" data-maxtip="{echo str_replace('n', $dp_config['maximg'], lang_dp('zuiduozhao',0))}">
                            <!--{loop $old_data[album_ary] $img}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                                <input type="hidden" name="form[album][]" value="$img"/>
                                <div class="weui-uploader__file-content">
                                    <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                            </li>
                            <!--{/loop}-->
                        </ul>
                        <!--{if is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
                        <!--{eval
                        $showv = ($config['qn_ak'] && $config['qn_sk'] && $config['qn_bk'] && $config['qn_url']) || ($config['ACCESS_ID'] && $config['ACCESS_KEY'] && $config['ENDPOINT'] && $config['BUCKET']);
                        }-->
                        <div class="weui-uploader__input-box newupload">
                            <input id="uploaderInput" class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                            <img src="source/plugin/xigua_hb/static/img/up.png">
                            <p>{lang xigua_hb:plzupload}</p>
                        </div>
                        <!--{if $showv&&!$catinfo[a_video]}-->
                        <div class="weui-uploader__input-box newupload">
                            <img src="source/plugin/xigua_hb/static/img/video.png">
                            <p>{lang xigua_hb:upvideo}</p>
                            <input class="weui-uploader__input_video" data-name="form[video]" type="file" accept="video/*">
                        </div><!--{/if}-->
                        <!--{else}-->
                        <div class="weui-uploader__input-box">
                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                            <a id="uploaderInput" class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1"></a>
                            <!--{else}-->
                            <input id="uploaderInput" class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                            <!--{/if}-->
                        </div>
                        <!--{/if}-->
                    </div>
                </div>
            </div>
        </div>

        <!--{if is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
        <!--{template xigua_hb:video_field}-->
        <!--{/if}-->

    </div>

    <div class="weui-cells__title" style="display:none">tuijiancai</div>
    <div class="weui-cells " style="display:none">
        <div class="weui-cell" style="padding-bottom:6px;">
            <div class="weui-cell__bd">
                <div class="dptags post-tags cl" id="post-typeid">
                    <!--{loop array('xxxxxx') $_k $_v}-->
                    <a class="weui-btn weui-btn_mini weui-btn_default <!--{if in_array($_v, $old_data[tagid_ary])}-->tag-on<!--{/if}-->" href="javascript:;" onclick="return setTid('$_k', '$_v', this);">$_v</a>
                    <!--{if in_array($_v, $old_data[tagid_ary])}-->
                    <input name="form[tagid][$_k]" type="hidden" value="$_v">
                    <!--{else}-->
                    <input name="form[tagid][$_k]" type="hidden" value="">
                    <!--{/if}-->
                    <!--{/loop}-->
                </div>
            </div>
        </div>
    </div>

<!--{if $dp_config[showrj]}-->
    <div class="weui-cells">
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_dp:rj}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="tel" name="form[renjun]" placeholder="{lang xigua_dp:qsrxfjr}" value="{$old_data[renjun]}">
            </div>
        </div>
    </div>
<!--{/if}-->
<!--{if IS_ADMINID || in_array($shid, dp_get_shids_by_uid())}-->
    <div class="weui-cells">
        <div class="weui-cell weui-cell_switch">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_dp:yzdp}</label></div><div class="weui-cell__bd"></div>
            <div class="weui-cell__ft">
                <input class="weui-switch" type="checkbox" name="form[jx]" value="1" <!--{if $old_data[jx]}-->checked<!--{else}--><!--{/if}-->>
            </div>
        </div>
    </div>
<!--{/if}-->

<!--{if $dp_config[allownm]}-->
<div class="weui-cells">
    <div class="weui-cell weui-cell_switch">
        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_dp:nmdp}</label></div><div class="weui-cell__bd"></div>
        <div class="weui-cell__ft">
            <input class="weui-switch" type="checkbox" name="form[niming]" value="1" <!--{if $old_data[niming]}-->checked<!--{else}--><!--{/if}-->>
        </div>
    </div>
</div>
<label for="weuiAgree" class="weui-agree">
    <span class="weui-agree__text">{lang xigua_dp:xznm}</span>
</label>
<!--{/if}-->
    <div class="fix-bottom mt10" style="position:relative">
        <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:tijiao}">
        <a href="javascript:window.history.go(-1);" class="weui-btn weui-btn_default close-popup">{lang xigua_hb:back}</a>
    </div>

    <div id="popctrl" class="weui-popup__container" style="z-index:1001">
        <div class="weui-popup__modal">
            <div style="height: 100vh"><img id="photo"></div>
            <div class="pub_funcbar">
                <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
                <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
            </div>
        </div>
    </div>

    </form>
</div>
<script src="source/plugin/xigua_dp/static/lq-score.min.js?{VERHASH}"></script>
<!--{template xigua_hb:enter_up}-->
<!--{eval $dp_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_dp:footer}-->
<!--{if is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
<!--{template xigua_hb:video}-->
<!--{/if}-->
<script>
$(function () {
<!--{loop $pfary $_k $_v}-->
<!--{eval $starN = 'star'.$_k;}-->
$("#pf$_k").lqScore({
    isReScore: true, tipEle: $("#pftip$_k"),
    tips: [$score_names],
    selectColor:[$score_colors],
    zeroTip: "{lang xigua_dp:wdf}",
    score:{echo intval($old_data[$starN]);},
    callBack:function(score,ele){ $('#$starN').val(score);}
});
<!--{/loop}-->
    $(document).on('click','.subject_ctrl', function () {
        $('#hide_subject').toggle();
    });
});
<!--{if $noadd}-->
$.alert('$noadd', function () {
    hb_jump('$noaddjump');
});
<!--{/if}-->
</script>