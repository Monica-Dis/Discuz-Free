<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{if $dp_tabbar}-->
<!--{if $dp_config[allowhb]}-->
<!--{eval $tabbar = 1;}-->
<!--{template xigua_hb:common_tabbar}-->
<!--{else}-->
<div class="weui-tabbar <!--{if $showfloatapp}-->none<!--{/if}-->">
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hb{$urlext}" class="weui-tabbar__item <!--{if $ac=='index'&&$_GET[id]=='xigua_hb'}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-index weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">{lang xigua_hb:shouye}</p>
    </a>
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_dp{$urlext}" class="weui-tabbar__item <!--{if in_array($ac,array('index'))}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-sixin2 weui-tabbar__icon f26"></i>
        <p class="weui-tabbar__label">{lang xigua_dp:rp}</p>
    </a>

    <a href="{$siteurl}$SCRITPTNAME?id=xigua_dp&ac=top{$urlext}" class="weui-tabbar__item <!--{if in_array($ac,array('top'))}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-ganxie1 weui-tabbar__icon f26"></i>
        <p class="weui-tabbar__label">{lang xigua_dp:yzdp}</p>
    </a>

    <a href="{$siteurl}$SCRITPTNAME?id=xigua_dp&ac=my{$urlext}" class="weui-tabbar__item <!--{if  strpos($ac,'follow')!==false||strpos($ac,'wode')!==false||strpos($ac,'order')!==false||strpos($ac,'my')!==false}-->weui-bar__item_on<!--{/if}-->">
        <span style="display: inline-block;position: relative;">
            <i class="iconfont icon-xiaolian2 weui-tabbar__icon"></i>
        </span>
        <p class="weui-tabbar__label">{lang xigua_hb:wode}</p>
    </a>
</div>
<!--{/if}-->
<!--{/if}-->