<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{template xigua_dp:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"></script>
<script>
function dp_delete(cid){
    $.confirm('{lang xigua_dp:qdsc}', function () {
        $.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME + '?id=xigua_dp&ac=del&inajax=1',
            data: {
                'cid': cid,
                'formhash': FORMHASH
            },
            dataType: 'xml',
            success: function(data) {
                $.hideLoading();
                if (null == data) {
                    tip_common('error|' + ERROR_TIP);
                    return false;
                }
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function() {
                $.hideLoading();
            }
        });
    });
}
</script>