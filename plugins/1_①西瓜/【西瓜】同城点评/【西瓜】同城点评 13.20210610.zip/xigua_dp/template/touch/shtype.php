<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{if $v[type]!='sh'}-->
<!--{if !$tyinfo}-->
<!--{eval $tyinfo = dp_get_info_by_type($v['type'], $v['typeid']);}-->
<!--{/if}-->
<a href="{$tyinfo[link]}" class="weui-cell weui-cell_access mt10" style="padding:.5rem 0 0 0;">
    <div class="weui-cell__hd" style="position:relative;margin-right:.5rem">
        <img src="{$tyinfo[logo]}" style="width:1.5rem;height:1.5rem;margin-right:.25rem;display:block;border-radius:50%">
    </div>
    <div class="weui-cell__bd">
        <p>{$tyinfo[name]}</p>
    </div>
    <div class="weui-cell__ft"></div>
</a>
<!--{/if}-->