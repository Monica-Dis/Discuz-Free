<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{loop $replies $reply}-->
<a href="javascript:void(0);" class="weui-media-box weui-media-box_appmsg rereply_dp" data-pubid="$reply[pubid]" data-cmtid="$reply[cid]" data-authorid="$reply[authorid]" data-author="$reply[author]">
<div class="weui-media-box__hd">
    <img class="weui-media-box__thumb" src="{avatar($reply['authorid'], 'big', true)}">
</div>
<div class="weui-media-box__bd">
    <h4 class="weui-media-box__title">
        <span class="y f14 c9">$reply[crts] <!--{if $reply[new]}--><span class="weui-badge weui-badge_dot" style="margin-left:5px;"></span><!--{/if}--></span>
        <!--{if $reply[touser]}--> <span>$reply[author] </span> {lang xigua_hb:huifu} <span>$reply[touser] :</span> <!--{else}--> <span>$reply[author]: </span> <!--{/if}-->
    </h4>
    <p class="weui-media-box__desc">{$reply[comment]}</p>
    <span class="userc dp_rep_bnt">{lang xigua_dp:reply}</span>
</div>
</a>
<!--{/loop}-->