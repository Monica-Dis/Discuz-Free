<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<div class="dp_jx_title">
    <div class="weui-cells__title weui_title border_bottom">
        <span>{lang xigua_dp:jxdp} ({$total})</span>
        <a class="gzbtn" href="$SCRITPTNAME?id=xigua_dp&ac=add&type=$type&typeid=$typeid&shid=$_GET['shid']"> {lang xigua_dp:xdp} </a>
    </div>
<!--{if $total}-->
<div class="weui-cells" style="display:none">
    <div class="weui-cell">
        <div class="weui-cell__bd">
            <div class="post-tags cl" id="post-typeid">
                <a class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;" >xxxxx</a>
                <a class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;" >xxxxx</a>
            </div>
        </div>
    </div>
</div>
    <div class="dp_list">
        <!--{loop $list $_k $_v}-->
        <div class="dp_list_li <!--{if $_v[jx]}-->dp_yz<!--{/if}--> <!--{if $_k+1!=$count_list}-->border_bottom<!--{/if}-->">
            <a class="useravatu" href="{$_v[authorlink]}">
                <img class="avatu" src="{$_v[avatar]}">
            </a>
            <div class="dp_list_li_main">
                <div class="userinfou">
                    <a href="{$_v[authorlink]}" class="userinfou_uname">$_v[author]</a>
                    <div class="userinfou_ts">$_v[crts_u]</div>
                    <!--{if !$_v[niming]}-->
                    <a class="gzusebtn main_color" id="gz{$_v[authorid]}" data-to="{$_v[authorid]}">{lang xigua_dp:jgz}</a>
                    <!--{/if}-->
                </div>
                <div class="pr dp_jump weui-flex" data-id="$_v[cid]">
                    <span>{lang xigua_dp:df}</span>
                    <div class="userinfou_star"><div class="dp_dafen_stars">{echo get_star($_v[star1]);}</div></div>
                    <!--{if $_v[renjun]}--><div class="dp_dafen_ft">{$_v[renjun]}{lang xigua_dp:yr}</div><!--{/if}-->
                </div>
                <div class="dp_list_desc dp_jump" data-id="$_v[cid]">
                    $_v[message]
                </div>
                <div class="dp_list_li_img cl dp_jump" data-id="$_v[cid]">
<!--{if $_v['video'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
<!--{eval array_pop($_v[album_ary1]);}-->
<div class="imgloading dp_vide dp_jump" data-id="$_v[cid]">
    <em class="emvbg" style="background-image:url({$_v['video_cover']})"></em><em class="emvdo"></em>
</div><!--{/if}-->
                    <!--{loop $_v[album_ary1] $__k $__v}-->
                    <div class="imgloading"><img src="$__v" /></div>
                    <!--{/loop}-->
                </div>
<!--{if ($imgc = count($_v[album_ary]))>3}-->
<div class="imgc"><i class="iconfont icon-img f12"></i> $imgc</div>
<!--{/if}-->
            </div>
        </div>
        <!--{/loop}-->
        <!--{if count($list)<$total || 1}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_dp&ac=top&type=$type&typeid=$typeid">
            <div class="weui-cell__bd">
                <span class="f14">{lang xigua_dp:ckqb} $total {lang xigua_dp:tdp}</span>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <!--{/if}-->
    </div>
<!--{else}-->
    <div class="weui-cells border_none">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_dp&ac=add&type=$type&typeid=$typeid">
            <div class="weui-cell__bd c9 tc f14">
                {lang xigua_dp:hmydp}
            </div>
        </a>
    </div>
<!--{/if}-->
</div>