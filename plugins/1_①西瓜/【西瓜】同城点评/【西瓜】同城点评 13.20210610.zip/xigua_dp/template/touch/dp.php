<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<div id="list" class="dp_index mod-post x-postlist cl" ></div>
<!--{template xigua_hb:loading}-->
<script>var loadingurl = window.location.href+'&ac=dp_li&inajax=1&page=';scrollto = 1;var lockIng = 0;</script>