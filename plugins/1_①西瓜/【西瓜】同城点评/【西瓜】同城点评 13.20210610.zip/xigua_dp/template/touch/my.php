<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{template xigua_dp:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->

    <div id="list" class="mod-post x-postlist p0 cl" style="background:#fff"></div>

    <!--{template xigua_hb:loading}-->
</div>

<script>
    var loadingurl = window.location.href+'&ac=dp_li&is_my=1&needsh=1&needzan=1&inajax=1&page=';
    scrollto = 1;
</script>
<!--{eval $tabbar=0;$dp_tabbar=1;}-->
<!--{template xigua_dp:footer}-->