<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_dp_comment` (
 `cid` int(11) NOT NULL AUTO_INCREMENT,
 `isnew` int(11) NOT NULL DEFAULT '0',
 `type` varchar(32) NOT NULL,
 `typeid` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 `hy_id` int(11) NOT NULL,
 `authorid` int(11) NOT NULL,
 `author` varchar(80) NOT NULL,
 `niming` int(11) NOT NULL,
 `subject` varchar(200) NOT NULL,
 `message` text NOT NULL,
 `renjun` decimal(10,2) NOT NULL,
 `xfh` tinyint(1) NOT NULL,
 `star1` tinyint(3) NOT NULL,
 `star2` tinyint(3) NOT NULL,
 `star3` tinyint(3) NOT NULL,
 `star4` tinyint(3) NOT NULL,
 `star5` tinyint(3) NOT NULL,
 `video` varchar(200) NOT NULL,
 `video_cover` varchar(200) NOT NULL,
 `tagid` text NOT NULL,
 `zans` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `replies` int(11) NOT NULL,
 `jx` int(1) NOT NULL,
 `lat` varchar(20) NOT NULL,
 `lng` varchar(20) NOT NULL,
 `album` text NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 PRIMARY KEY (`cid`),
 KEY `authorid` (`authorid`),
 KEY `type` (`type`),
 KEY `gid` (`typeid`),
 KEY `isnew` (`isnew`),
 KEY `shid` (`shid`),
 KEY `jx` (`jx`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_dp_index` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_dp_reply` (
 `cid` int(11) NOT NULL AUTO_INCREMENT,
 `pubid` int(11) NOT NULL,
 `authorid` int(11) NOT NULL,
 `author` varchar(80) NOT NULL,
 `touid` int(11) NOT NULL,
 `touser` varchar(80) NOT NULL,
 `comment` varchar(2000) NOT NULL,
 `crts` int(11) NOT NULL,
 `pubuid` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 `star` tinyint(3) NOT NULL,
 `imglist` text NOT NULL,
 `type` int(11) NOT NULL,
 `new` int(11) NOT NULL,
 `gid` int(11) NOT NULL,
 `isnew` int(11) NOT NULL DEFAULT '0',
 PRIMARY KEY (`cid`),
 KEY `pubuid` (`pubuid`),
 KEY `authorid` (`authorid`),
 KEY `touid` (`touid`),
 KEY `shid` (`shid`),
 KEY `type` (`type`),
 KEY `new` (`new`),
 KEY `pubid` (`pubid`),
 KEY `star` (`star`),
 KEY `gid` (`gid`),
 KEY `isnew` (`isnew`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_dp_votelog` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `pubid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `pubid` (`pubid`),
 KEY `uid` (`uid`)
) ENGINE=InnoDB;
SQL;
if($sql){
    runquery($sql);
}

$sql = <<<SQL

ALTER TABLE `pre_xigua_dp_comment` CHANGE `typeid` `typeid` VARCHAR(20) NOT NULL;

SQL;
runquery($sql);
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/install.php');
