<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2021 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
$dp_config = $_G['cache']['plugin']['xigua_dp'];
include_once DISCUZ_ROOT . 'source/plugin/xigua_dp/function.php';
dp_star_start();
$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$url = rtrim($url, '/') . '/';
global $_G;
global $do;
global $shid;
global $voteobj;
global $dp_config;
global $ac;
global $aclist;
global $aclist_login;
global $_G;
global $page;
global $lpp;
global $start_limit;
global $uid;
global $cmtobj;
global $indexobj;
global $cid;
global $repobj;
$shid = intval($_GET['shid']);
$ac = $_GET['ac'];
$do = $_GET['do'];
$aclist = array('index', 'my', 'add', 'dp_li', 'view', 'misc', 'reply_li', 'top', 'top_li', 'jingxuan', 'incr', 'del');
$aclist_login = array('add', 'misc', 'my', 'del');
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
if (in_array($ac, $aclist_login) && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$uid = $_G['uid'];
$cid = intval($_GET['cid']);
$cmtobj = C::t('#xigua_dp#xigua_dp_comment');
$indexobj = C::t('#xigua_dp#xigua_dp_index');
$repobj = C::t('#xigua_dp#xigua_dp_reply');
$voteobj = C::t('#xigua_dp#xigua_dp_votelog');
$opens = unserialize($_G['cache']['plugin']['xigua_dp']['opens']);
$pfary = $fsms = $score_names = $score_colors = array();
switch ($ac) {
	case 'incr':
		if (in_array($_GET['incr_type'], array('shares', 'views', 'zans', 'replies'))) {
			$cmtobj->incr($_GET['cid'], $_GET['incr_type']);
			hb_message('success');
		}
		break;
	case 'misc':
		switch ($_GET['do']) {
			case 'vote':
				if (submitcheck('formhash')) {
					$pubid = intval($_GET['cid']);
					if ($voteobj->fetch_by_uid($_G['uid'], $pubid)) {
						hb_message(lang_hb('zanguo', 0), 'error');
					} else {
						$cmtobj->incr($pubid, 'zans');
						$voteobj->insert(array('uid' => $_G['uid'], 'pubid' => $pubid, 'crts' => TIMESTAMP));
						$avatar = avatar($_G['uid'], 'middle', '1');
						hb_message(lang_hb('chengong', 0), 'success');
					}
				}
				break;
			case 'comment':
				if (submitcheck('formhash')) {
					if (!$_G['uid']) {
						hb_check_login();
					}
					$cmt_id = intval($_GET['cmt_id']);
					if ($_GET['do1'] == 'del') {
						if (IS_ADMINID) {
							$repobj->delete($_GET['replyid']);
							hb_message(lang_hb('del_succeed', 0), 'success', 'reload');
						}
						hb_message('error', 'error');
					}
					$hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
					if ($hbuser['pingbi']) {
						hb_message(lang_hb('ybpb', 0), 'error');
					}
					if (!$_G['group']['allowreply']) {
						hb_message(lang_hb('no_permission_to_post', 0), 'error');
					}
					hb_check_bind(4);
					if (!($cmg = trim($_GET['comment']))) {
						hb_message(lang_hb('empt', 0), 'error');
					}
					$cinfo = $cmtobj->fetch($cmt_id);
					$comment_msg = censor($cmg, NULL, true);
					if (is_array($comment_msg) && $comment_msg['message']) {
						hb_message($comment_msg['message'], 'error');
					}
					if ($config['discmtmobile']) {
						$comment_msg = preg_replace('/(\\d{7,})/', '****', $comment_msg);
					}
					$ret = $repobj->add($_G['uid'], intval($_GET['touid']), $cmt_id, $comment_msg, $cinfo['authorid'], 0, 5, array(), 0);
					if ($ret) {
						$url = $_G['siteurl'] . $SCRITPTNAME . '?id=xigua_dp&ac=view&cid=' . $cmt_id;
						notification_add($_GET['touid'] ? $_GET['touid'] : $cinfo['authorid'], 'system', lang_hb('comment_to', 0), array('url' => $url, 'username' => $_G['username'], 'info' => $comment_msg), 1);
						$cmtobj->incr($cmt_id, 'replies');
						hb_message(lang_hb('huifuchenggong', 0), 'success', '', $ret);
					} else {
						hb_message(lang_hb('huifushibai', 0), 'error');
					}
				}
		}
		break;
	case 'jingxuan':
		if ($_GET['do'] == 'nearby') {
			$navtitle = lang('plugin/xigua_hs', 'near');
			$indexlist = $indexobj->list_by_pid(0, true);
			include template('xigua_dp:nearby');
			exit(0);
		} else {
			$type = $_GET['type'];
			$typeid = daddslashes($_GET['typeid']);
			$pagesize = intval($_GET['pagesize']);
			if (!in_array($type, array('sh', 'pt', 'sp', 'hm', 'hd', 'he', 'hk', 'ho', 'hb'))) {
				$type = '';
			}
			$where = array();
			if ($_GET['typelike']) {
				$tplike = explode('_', $_GET['typelike']);
				$where[] = 'typeid like \'' . intval($tplike[0]) . '_%\'';
				$typeid = $_GET['typelike'];
			} else {
				$where[] = 'typeid=\'' . $typeid . '\'';
			}
			$where[] = 'type=\'' . $type . '\'';
			$total = $cmtobj->fetch_count_bypage($where);
			$list = $cmtobj->fetch_all_bypage($where, 0, $pagesize);
			$count_list = count($list);
			include template('xigua_hb:header_ajax');
			include template('xigua_dp:jingxuan');
			include template('xigua_hb:footer_ajax');
		}
		break;
	case 'top':
		$navtitle = lang_dp('jx', 0);
		if ($_GET['type']) {
			$typeinfo = dp_get_info_by_type();
			$navtitle = $typeinfo['name'] . lang_dp('dp', 0);
		}
		break;
	case 'reply_li':
		$replies = array();
		if ($_GET['rpid']) {
			$replies[] = $repobj->fetch($_GET['rpid']);
		} else {
			if ($cid) {
				$replies = $repobj->fetch_comment_by_pubid($cid, $start_limit, $lpp);
			}
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_dp:reply_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'index':
		$navtitle = $dp_config['defaulttitle'];
		$desc = $dp_config['defaultdesc'];
		$topnavslider = hb_parse_set($dp_config['topslider']);
		$hyinfo = C::t('#xigua_hs#xigua_hs_hangye')->get_childs_by_pids(0);
		$indexlist = $indexobj->list_by_pid(0, true);
		break;
	case 'view':
		$navtitle = lang_dp('dpxq', 0);
		$v = $cmtobj->fetch_by_cid($cid);
		dp_get_pflx($v['hy_id']);
		if (!$v) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_dp' . $urlext);
		}
		$desc = strip_tags($v['message']);
		if ($_GET['a']) {
			dump($v);
		}
		$v['sh'] = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($v['shid']);
		$back_to = $SCRITPTNAME . '?id=xigua_dp';
		if ($_SERVER['HTTP_REFERER']) {
			$back_to = 'javascript:window.history.go(-1);';
		}
		$replies_count = $repobj->fetch_count_bypage(array('pubid=' . intval($v['cid'])));
		if ($v['subject']) {
			$navtitle = $v['subject'];
		}
		if ($_G['uid']) {
			$hasvote = $voteobj->fetch_by_uid($_G['uid'], $v['cid']);
			$hasfave = C::t('#xigua_hb#xigua_hb_follow')->fetch_follow_by_favid_uid($v['authorid'], $_G['uid'], 'favuser');
		}
		if ($v['type'] != 'sh') {
			$tyinfo = dp_get_info_by_type($v['type'], $v['typeid']);
		}
		if ($dp_config['kqdsp']) {
			if (!$_GET['n'] && $v['video'] && is_file(DISCUZ_ROOT . 'source/plugin/xigua_dp/template/touch/view_vd.php')) {
				$_GET['view_tpl'] = 'view_vd';
			}
			if (checkmobile() && $_GET['view_tpl'] && is_file(DISCUZ_ROOT . ('source/plugin/xigua_dp/template/touch/' . $_GET['view_tpl'] . '.php')) && !$_GET['mini']) {
				$nexts = DB::fetch_all('select cid from %t where video!=\'\' order by upts DESC LIMIT 0,299', array('xigua_dp_comment', TIMESTAMP), 'cid');
				$nextids = array_keys($nexts);
				$nowindex = array_search($v['cid'], $nextids);
				$preid = $nextids[$nowindex - 1];
				$nextid = $nextids[$nowindex + 1];
				include template('xigua_dp:' . $_GET['view_tpl']);
				exit(0);
			}
		}
		break;
	case 'dp_li':
		$ob = 'upts DESC';
		$where = array();
		if ($_GET['is_my'] && $_G['uid'] > 0) {
			$_GET['tpl'] = 'top_li';
			$where[] = 'authorid=' . $_G['uid'];
		}
		if ($_GET['nav'] == 'shipin') {
			$where[] = 'video!=\'\'';
		}
		if ($_GET['hy_id']) {
			$where[] = 'hy_id = ' . intval($_GET['hy_id']);
		}
		if ($_GET['type']) {
			$where[] = 'type=\'' . daddslashes($_GET['type']) . '\'';
		}
		if ($_GET['typeid']) {
			$where[] = 'typeid=\'' . daddslashes($_GET['typeid']) . '\'';
		}
		if ($_GET['jx'] && !$_GET['typeid']) {
			$where[] = 'jx=1';
		}
		$list = $cmtobj->fetch_all_bypage($where, $start_limit, $lpp, $ob);
		include template('xigua_hb:header_ajax');
		if ($_GET['tpl'] == 'top_li') {
			include template('xigua_dp:top_li');
		} else {
			include template('xigua_dp:dp_li');
		}
		include template('xigua_hb:footer_ajax');
		break;
	case 'add':
		hb_check_bind(4);
		$typeinfo = dp_get_info_by_type();
		$typeinfo['link'] = $_GET['ref'] ? str_replace('&amp;', '&', $_GET['ref']) : $typeinfo['link'];
		$form = $_GET['form'];
		$shid = $_GET['shid'] ? $_GET['shid'] : ($form['type'] == 'sh' ? $form['typeid'] : 0);
		if (!$shid) {
			$shid = $_GET['type'] == 'sh' ? $_GET['typeid'] : 0;
		}
		if ($shid) {
			$shinfo = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($shid);
		}
		dp_get_pflx($shinfo['hangye_id1']);
		$score_names = '\'' . implode('\',\'', $score_names) . '\'';
		$score_colors = '\'' . implode('\',\'', $score_colors) . '\'';
		$navtitle = lang_dp('fbdp', 0);
		if (submitcheck('formhash')) {
			$hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			if ($hbuser['pingbi']) {
				hb_message(lang_hb('ybpb', 0), 'error');
			}
			$form['message'] = censor($form['message'], NULL, true);
			if (is_array($form['message']) && $form['message']['message']) {
				hb_message($form['message']['message'], 'error');
			}
			if (!$form['message']) {
				hb_message(lang_dp('plzmsg', 0), 'error');
			}
			C::t('#xigua_hb#xigua_hb_pub')->checkmsdg($form['message']);
			if ($dp_config['mustpic'] && !$form['album'] && !$form['video_cover']) {
				hb_message(lang_dp('qsczp', 0), 'error');
			}
			$newdata = array('star1' => $form['star1'], 'star2' => $form['star2'], 'star3' => $form['star3'], 'star4' => $form['star4'], 'star5' => $form['star5'], 'subject' => $form['subject'], 'message' => $form['message'], 'video' => $form['video'], 'video_cover' => $form['video_cover'], 'renjun' => $form['renjun'], 'niming' => $form['niming'], 'album' => serialize($form['album']), 'tagid' => serialize($form['tagid']), 'type' => $form['type'], 'typeid' => $form['typeid'], 'stid' => $form['stid'] ? $form['stid'] : $_GET['st'], 'upts' => TIMESTAMP, 'shid' => $shid, 'hy_id' => $shinfo['hangye_id1'], 'lat' => $form['lat'] ? $form['lat'] : $shinfo['lat'], 'lng' => $form['lng'] ? $form['lng'] : $shinfo['lng'], 'xfh' => $typeinfo['xfh']);
			if (IS_ADMINID || in_array($shid, dp_get_shids_by_uid())) {
				$newdata['jx'] = intval($form['jx']);
			}
			if ($cid = intval($form['cid'])) {
				$cmtobj->update_G($cid, $newdata);
				hb_message(lang_dp('xgcg', 0), 'success', $typeinfo['link']);
			} else {
				$newdata['crts'] = TIMESTAMP;
				$newdata['isnew'] = 1;
				$newdata['authorid'] = $_G['uid'];
				$newdata['author'] = $_G['username'];
				$cid = $cmtobj->do_insert($newdata);
				if ($cid) {
					hb_message(lang_dp('fbcg', 0), 'success', $typeinfo['link']);
				}
			}
		} else {
			if ($cid = intval($_GET['cid'])) {
				$old_data = $cmtobj->fetch_by_cid($cid);
			} else {
				$old_data = $cmtobj->fetch_by_G();
			}
			$_GET['type'] = $old_data['type'] ? $old_data['type'] : $_GET['type'];
			$_GET['typeid'] = $old_data['typeid'] ? $old_data['typeid'] : $_GET['typeid'];
		}
		break;
	case 'my':
		$navtitle = lang_dp('wddp', 0);
		$custom_side = array($SCRITPTNAME . '?id=xigua_hb&ac=my' . $urlext, lang_dp('grzx', 0));
		break;
	case 'del':
		if (submitcheck('cid')) {
			$cmtobj->delete_G($_GET['cid']);
			hb_message(lang_dp('del1', 0), 'success', 'reload');
		}
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_dp/template/touch/' . $ac . '.php'))) {
	include template('xigua_dp:' . $ac);
}