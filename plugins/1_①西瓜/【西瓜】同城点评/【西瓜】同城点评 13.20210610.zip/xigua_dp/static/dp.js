function setTid(id,value,obj){if($(obj).hasClass('tag-on')){$(obj).removeClass('tag-on');$('input[name="form[tagid]['+id+']"]').val('')}else{var MaxTagNum=parseInt(MAXTAG);if(MaxTagNum>0&&$('.tag-on').length>MaxTagNum-1){$.toast(MAXTAGTIP);return false}$(obj).addClass('tag-on');$('input[name="form[tagid]['+id+']"]').val(value)}}$(document).on('click','.dp_jump',function(){var that=$(this);var jmpurl=_APPNAME+'?id=xigua_dp&ac=view&cid='+that.data('id')+(that.data('stid')?'&st='+that.data('stid'):'')+(typeof _URLEXT!=='undefined'?_URLEXT:'');if(typeof mag!=='undefined'){mag.newWin(GSITE+jmpurl);return false}if(typeof sq!=='undefined'){sq.urlRequest(GSITE+jmpurl);return false}if(typeof wx!=='undefined'){if(window.__wxjs_environment==='miniprogram'){GSITE=GSITE.replace(/http:\/\//,'https://');wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});return false}}if(typeof QFH5!=='undefined'){QFH5.jumpNewWebview(GSITE+jmpurl);return false}window.location.href=jmpurl;return false});$(document).on('click','.gzusebtn',function(){var that=$(this);$.showLoading();$.ajax({type:'post',url:_APPNAME+'?id=xigua_hb&ac=fav&fav=user&inajax=1',data:{'touid':that.data('to'),'formhash':FORMHASH},dataType:'xml',success:function(data){$.hideLoading();if(null==data){tip_common('error|'+ERROR_TIP);return false}var s=data.lastChild.firstChild.nodeValue;tip_common(s)},error:function(){$.hideLoading()}})});$(document).on('click','.comment_dp',function(){var that=$(this);do_dp_comment(that.data('id'),0,SUIBIANSHUO,0);return false});$(document).on('click','.rereply_dp',function(){var that=$(this);var _pbid=that.parent().data('id')||that.data('pubid');do_dp_comment(_pbid,that.data('authorid'),HUIFU1+that.data('author'),0,that.data('cmtid'));return false});$(document).on('click','.dp_praise',function(){var that=$(this);var did=that.attr('data-id');if(!that.attr('data-href')){return false}if(UID<1){window.location.href="member.php?mod=logging&action=login";return false}$.ajax({type:'post',url:that.attr('data-href')+'&inajax=1',data:that.serialize(),dataType:'xml',success:function(data){if(null==data){tip_common('error|'+ERROR_TIP);return false}var s=data.lastChild.firstChild.nodeValue;if(s.indexOf('success')!==-1){dp_vote_success(did)}else{tip_common(s)}},error:function(){}});$('#c_icon_'+did).trigger('click');return false});function do_dp_comment(cmt_id,touid,title,aype,replyid){if(ISADMINID&&typeof replyid!='undefined'){$.modal({title:title,text:"<div class=\"b-color13 fixipt13\"><textarea class=\"weui-textarea weui-prompt-input needsclick\" id=\"weui-modal-input\" placeholder=\""+PLZINPUT+"\" rows=\"3\"></textarea></div>",buttons:[{text:QUXIAO,className:"default",onClick:function(){}},{text:SHANCHU,className:"default",onClick:function(){$.showLoading();$.ajax({type:'post',url:_APPNAME+'?id=xigua_dp&ac=misc&do=comment&do1=del&inajax=1',data:{'replyid':replyid,'formhash':FORMHASH},dataType:'xml',success:function(data){$.hideLoading();if(null==data){tip_common('error|'+ERROR_TIP);return false}var s=data.lastChild.firstChild.nodeValue;tip_common(s)},error:function(){$.hideLoading()}})}},{text:QUEDING,className:"primary",onClick:function(){var input=$('#weui-modal-input').val();$.showLoading();$.ajax({type:'post',url:_APPNAME+'?id=xigua_dp&ac=misc&do=comment&inajax=1&type='+0+'&cmt_id='+cmt_id,data:{'comment':input,'touid':touid,'formhash':FORMHASH},dataType:'xml',success:function(data){$.hideLoading();if(null==data){tip_common('error|'+ERROR_TIP);return false}var s=data.lastChild.firstChild.nodeValue;var msgar=tip_common(s);if(msgar[0]=='success'){var cmurl=_APPNAME+'?id=xigua_dp&ac=reply_li&rpid='+msgar[3]+'&inajax=1';cmurl=cmurl+'&multi=1';$.ajax({type:'get',url:cmurl,dataType:'xml',success:function(data){if(null==data){tip_common('error|'+ERROR_TIP);return false}var s=data.lastChild.firstChild.nodeValue;$('#cmt_wrap_'+cmt_id).show();$('#r_'+cmt_id).show();$('#cmt_list_'+cmt_id).show().prepend(s);$('#list').show().prepend(s)}})}},error:function(){$.hideLoading()}})}},]});return false}$.prompt({title:title,input:PLZINPUT,empty:false,onOK:function(input){$.showLoading();$.ajax({type:'post',url:_APPNAME+'?id=xigua_dp&ac=misc&do=comment&inajax=1&type=0&cmt_id='+cmt_id,data:{'comment':input,'touid':touid,'formhash':FORMHASH},dataType:'xml',success:function(data){$.hideLoading();if(null==data){tip_common('error|'+ERROR_TIP);return false}var s=data.lastChild.firstChild.nodeValue;var msgar=tip_common(s);if(msgar[0]=='success'){var cmurl=_APPNAME+'?id=xigua_dp&ac=reply_li&rpid='+msgar[3]+'&inajax=1';cmurl=cmurl+'&multi=1';$.ajax({type:'get',url:cmurl,dataType:'xml',success:function(data){if(null==data){tip_common('error|'+ERROR_TIP);return false}var s=data.lastChild.firstChild.nodeValue;$('#cmt_wrap_'+cmt_id).show();$('#r_'+cmt_id).show();$('#cmt_list_'+cmt_id).show().prepend(s);$('#list').show().prepend(s)}})}},error:function(){$.hideLoading()}})},onCancel:function(){}})}function dp_vote_success(did){$('.praises_'+did).each(function(){$(this).text(parseInt($(this).text())+1)});$('#cmt_wrap_'+did).show();$('#r_'+did).show();var likeu=$('#praise_list_'+did);if(likeu.find('.uavatar_a').length>0){likeu.prepend('<a class="uavatar_a"><img class="uavatar" src="'+AVATAR+'" /> </a>')}else{likeu.html('<a class="uavatar_a"><img class="uavatar" src="'+AVATAR+'" /> </a>')}}function dp_edit(type,typeid,cid){hb_jump(_APPNAME+"?id=xigua_dp&ac=add&type="+type+"&typeid="+typeid+"&cid="+cid+"&ref="+encodeURIComponent(location.href))}

$(document).on('click', '.dp_cat', function () {
    var that = $(this);
    loadingurl = _APPNAME+'?id=xigua_dp&ac=dp_li&inajax=1&hy_id=' + that.data('id') + '&' + that.data('save') + '&page=';
    if (that.data('loadingurl')) {
        loadingurl = that.data('loadingurl') + '&' + that.data('save')
    }
    if(that.data('needgeo') && loadingurl.indexOf('lng=')===-1){
        dp_getlocation(function (position) {
            latold=(position.latitude||position.lat);
            lngold=(position.longitude||position.lng);
            var lngstr ='&lat='+latold+'&lng='+lngold;
            loadingurl += ''+lngstr+'&page=';
            var newthat = that.data('save')+lngstr;
            that.data('save', newthat);
            $('.needgeo').data('save', newthat);
            dp_list(that,loadingurl);
        });
        return false;
    }
    dp_list(that, loadingurl);
});

function dp_list(that, lurl){
    var lst = $('#list');
    page = 1;
    if(lm==1){
        return false;
    }
    lm = 1;
    that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
    DOAPPEND = 0;
    $.ajax({
        type: 'get', url: lurl + '' + page +_URLEXT, dataType: 'xml', success: function (data) {
            lm = 0;
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false
            }
            if(that.data('cls')){
                lst.removeClass('dp_index');
            }else{
                lst.addClass('dp_index');
            }
            var s = data.lastChild.firstChild.nodeValue;
            $('#loading-show').addClass('hidden');
            if (!s) {
                $('#loading-show').addClass('hidden');
                $('#loading-none').removeClass('hidden');
                setTimeout(function () {
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden')
                }, 300);
                lst.html(s);
                page = -1;
                return
            }
            lst.html(s);
            if (typeof loadingCallback !== 'undefined') {
                loadingCallback()
            }
            page++
        }, error: function () {
        }
    });
    if (that.data('save')) {
        var oldu = dp_getparget().replace(/nav\=\w+\&/, '');
        var su = that.data('save')+'';
        oldu = oldu.replace(su + '&', '').replace('id=xigua', su + '&id=xigua');
        history.replaceState(null, '', oldu)
    }
}

function dp_getlocation(callback){
    if(0&&typeof mag != 'undefined'){
        mag.getLocation(function(res){
            callback(res);
        });
    }else if(typeof sq != 'undefined'){
        sq.getLocation(function(res){
            callback(res);
        });
    }else if(typeof QFH5 != 'undefined') {
        QFH5.getLocation(function (state, data) {
            if (state == 1) {
                callback(data);
            } else {
                alert(data.error);
            }
        });
    }else if((HB_INWECHAT&&HS_MULTIUPLOAD)==1) {
        wx.getLocation({
            type: 'gcj02',
            success: function (res) {
                callback(res);
            },
            cancel: function (res) {
            }
        });
    }else{
        console.log('myapp');
        var geolocation = new qq.maps.Geolocation(mkey, "myapp");
        geolocation.getLocation(callback, function () {
        }, {timeout:4000, failTipFlag:true});
    }
}

function dp_getparget(){
    var rst = '';
    var $_GET = (function(){
        var url = window.location.href.toString();
        var u = url.split("?");
        if(typeof(u[1]) === "string"){
            u = u[1].split("&");
            var get = {};
            for(var i in u){
                var j = u[i].split("=");
                if(typeof j[0] !=='undefined' && typeof j[1] !=='undefined'){
                    get[j[0]] = j[1];
                }
            }
            return get;
        } else {
            return {};
        }
    })();
    for(var i in $_GET){
        rst += i+"="+$_GET[i]+"&";
    }
    return '?'+rst;
}