<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_dp/function.php';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$dp_config = $_G['cache']['plugin']['xigua_dp'];
$page = max(1, intval($_GET['page']));
$lpp   = 50;
$start_limit = ($page - 1) * $lpp;
$opens = unserialize($_G['cache']['plugin']['xigua_dp']['opens']);
$types = array(
    'sh' => lang_dp( 'sh',0),
    'he' => lang_dp( 'he',0),
    'hm' => lang_dp( 'hm',0),
    'pt' => lang_dp( 'pt',0),
    'sp' => lang_dp( 'sp',0),
    'hk' => lang_dp( 'hk',0),
    'hd' => lang_dp( 'hd',0),
);

$pfary = array();
$_i = 1;
foreach (explode("\n", trim($dp_config['pflx'])) as $item) {
    $pfary[$_i++] = trim($item);
}
$fsms = $score_names = $score_colors = array();
foreach (explode("\n", trim($dp_config['fsms'])) as $index => $item) {
    list($score, $score_name, $score_color) = explode("|", trim($item));
    $score_names[] = $score_name;
    $score_colors[] = $score_color;
}

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        $r = C::t('#xigua_dp#xigua_dp_reply')->deletes($delete);
    }
    if($r){
        cpmsg(lang_hb('delete_succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_rep&page=$page", 'succeed');
    }
}




echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_rep&page=$page");
echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_dp('repseaarch',0).'" value="'.$_GET['keyword'].'" class="txt" /> ';
echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo '</div>';
showtableheader(lang_hb('pinglunguanli', 0));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_hb','del'),
    lang_hb('username', 0),
    lang_hb('touid', 0),
    lang('plugin/xigua_dp','dpid'),
    lang('plugin/xigua_hb','note'),
    lang('plugin/xigua_hb','crts'),
));

$wherearr = array();
$keyword = stripsearchkey(addslashes($_GET['keyword']));
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = " (authorid='$keyword' OR touid=$keyword OR pubid=$keyword OR shid=$keyword) ";
}elseif($keyword){
    $wherearr[] = " ( author LIKE '%$keyword%' OR touser LIKE '%$keyword%' OR comment LIKE '%$keyword%' ) ";
}



$res = C::t('#xigua_dp#xigua_dp_reply')->fetch_all_bypage($wherearr, $start_limit, $lpp);
$icount = C::t('#xigua_dp#xigua_dp_reply')->fetch_count_bypage($wherearr);


foreach ($res as $v) {
    $cid = $v['cid'];

    $img = $v['imglist'] ? unserialize($v['imglist']) : array();
    $vimg = array();
    if($img){
        foreach ($img as $index => $item) {
            $vimg[] = "<a href='$item' target='_blank'><img src='$item' style='height:40px;display:inline-block' /></a>";
        }
    }

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$cid' /> $cid",
        $v['author'].'(UID:'.$v['authorid'].')',
        $v['touid'] ?  ($v['touser'].'(UID:'.$v['touid'].')') : '-',
        $v['pubid'],
        $v['comment']. ($vimg ? '<br>'.implode('', $vimg) : ''),
        date('m-d H:i:s', $v['crts']),
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_dp&pmod=admin_rep&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); //Dism��taobao��com
showformfooter(); /*dis'.'m.tao'.'bao.com*/