<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_dp_comment extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_dp_comment';
        $this->_pk = 'cid';

        parent::__construct(); //dis'.'m.tao'.'bao.com
    }
    public function fetch_description($description, $uid, $type, $typeid)
    {
        $rpid = DB::result_first('SELECT cid from %t WHERE authorid=%d AND type=%d AND typeid=%d AND message=%s', array(
            $this->_table,
            $uid,
            $type,
            $typeid,
            $description,
        ));
        return $rpid;
    }
    public function do_insert($data, $return_insert_id = true, $replace = false, $silent = false)
    {
        global $config,$_G;
        if($data['message']){
            if($config['discmtmobile']){
                $data['message'] = preg_replace('/(\d{7,})/', '****', $data['message']);
            }
            if($config['require_cnt']){
                if($this->fetch_description($data['message'], $data['authorid'], $data['type'], $data['typeid'])){
                    hb_message(lang_hb('xiangsi_exists',0), 'error');
                }
            }
        }
        $secid = parent::insert($data, $return_insert_id, $replace, $silent);
        return $secid;
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['authorid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        global $config;
        if($data['message']){
            if($config['discmtmobile']){
                $data['message'] = preg_replace('/(\d{7,})/', '****', $data['message']);
            }
        }
        global $shid;
        if(IS_ADMINID || in_array($shid, dp_get_shids_by_uid())){
            return DB::update($this->_table, $data, array(
                'cid'  => $id,
            ));
        }else{
            return DB::update($this->_table, $data, array(
                'authorid' => $_G['uid'],
                'cid'  => $id,
            ));
        }
    }

    public function delete_G($id)
    {
        global $_G;
        $v = $this->fetch($id);
        if(IS_ADMINID){
            return $this->delete($id);
        }elseif(in_array($v['shid'], dp_get_shids_by_uid())){
            $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid']);
            $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
            if(in_array('cmtt', $vipinfo['access'])){
                return $this->delete($id);
            }
        }else{
            return DB::delete($this->_table, 'cid='.intval($id).' AND authorid='.$_G['uid']);
        }
    }

    public function fetch_by_cid($id){
        $result = parent::fetch($id);
        $result = self::prepare($result);
        $this->incr($id, 'views');
        return $result;
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }
    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE cid IN (%n)', array($this->_table, $ids));
    }
    public function fetch_all_bypage($wherearr, $start_limit, $lpp, $order = '')
    {
        if(!$order){
            $order = "crts DESC";
        }

        $field = '*';
        $near = $_GET['nav']=='near' && $_GET['lat']&&$_GET['lng'];
        if($near){
            $lat = floatval($_GET['lat']);
            $lng = floatval($_GET['lng']);
            $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
            $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
            $order = 'distance ASC, crts DESC';
        }

        if($_GET['isfav']){
            global $_G;
            $_lst = C::t('#xigua_hs#xigua_hs_follow')->fetch_all_by_page(array('uid='.$_G['uid']), 0, 99);
            $_tp = array();
            foreach ($_lst as $v) {
                $_tp[]=$v['shid'];
            }
            if($_tp){
                $where[]=" shid in (".implode(',', $_tp).")";
            }else{
                $where[]=" shid='abc' ";
            }
        }

        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql  ORDER BY $order" . DB::limit($start_limit, $lpp));
        $shids  = $cids = array();
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $shids[] = $result[$index]['shid'];
            $cids[] = $item['cid'];
        }
        if($_GET['needsh'] && $shids){
            if($shids){
                $shinfos = DB::fetch_all('SELECT shid,`name`,logo,addr,opentime FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
            }
            foreach ($result as $index => $item) {
                $result[$index]['sh'] = $shinfos[$item['shid']];
            }
        }
        if($_GET['needzan'] && $cids){
            $table = DB::table('xigua_dp_votelog');
            $cids = implode(',', $cids);
            $zanlist = DB::fetch_all("SELECT uid,pubid FROM $table b WHERE b.pubid IN ($cids) GROUP BY CONCAT(b.`pubid`, b.`id` % 8)");
            $tmp = array();
            foreach ($zanlist as $index => $item) {
                $tmp[$item['pubid']][] = $item['uid'];
            }
            foreach ($result as $index => $item) {
                $result[$index]['zanlist'] = $tmp[$item['cid']];
            }
        }

        if($near){
            foreach ($result as $k => $v) {
                $distance = intval($v['distance']);
                if($distance<=1000){
                    $distance = intval($distance). 'm';
                }else if($distance>1000){
                    $distance = round($distance/1000, 1). 'km';
                }
                $result[$k]['distance'] = $distance;
            }
        }
        return $result;
    }

    public function fetch_count_bypage($wherearr)
            {
                $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
                $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table). " $wheresql ");
                return $result;
            }

            public function prepare($v)
            {
                global $_G,$SCRITPTNAME;
                if($v){
                    $v['crts_u'] = dgmdate($v['crts'], 'u');
                    $v['album_ary'] = unserialize($v['album']);
                    $v['album_ary1'] = array_slice($v['album_ary'], 0, 3);
                    $v['tagid_ary'] = unserialize($v['tagid']);
                    $v['cover'] = $v['video_cover'] ? $v['video_cover'] : $v['album_ary'][0];
                    if(!$v['cover']){
                        $v['cover'] = 'source/plugin/xigua_dp/static/img/nologo.png';
                    }
                    if(!$v['album_ary'][0]&& $_GET['ac']!='add'){
                        $v['album_ary'][0] = $v['cover'];
                    }
                    if(!$v['subject'] && $_GET['ac']!='add'){
                        $v['subject'] = cutstr(strip_tags($v['message']), 80);
                    }
                    if($v['niming']){
                        $v['authorlink'] = 'javascript:;';
                        $v['author'] = lang('plugin/xigua_dp', 'niming');
                        $v['avatar'] = 'source/plugin/xigua_dp/static/img/niming.png';
                    }else{
                        $v['authorlink'] = "$SCRITPTNAME?id=xigua_hb&ac=member&uid={$v['authorid']}";
                        $v['avatar'] = avatar($v['authorid'], 'small', true);
                    }
                    if($v['renjun']){
                        $v['renjun'] = floatval($v['renjun']);
                    }
                    if($_GET['ac']=='view'){
                        $v['zanlist'] = C::t('#xigua_dp#xigua_dp_votelog')->fetch_by_pubid($v['cid'], 0, 12);
                    }
                    if($v['type']=='sh'){
                        $v['shid'] = $v['typeid'];
                    }
                }
                return $v;
            }

            public function incr($pubid, $field, $num = 1)
            {
                global $_G;
                if ($field == 'shares' && discuz_process::islocked('incrlock'.$pubid.$field.$_G['uid'], 10)) {
                    return null;
                }
                if(!$field){
            return null;
        }
        if(strpos($pubid, ',')!==false){
            $pubid = dintval(array_filter(explode(',', $pubid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $pubid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $pubid));
        }
    }

    public function fetch_by_G()
    {
        global $dp_config;
        if(IS_ADMINID && $dp_config['allowshy']){
            return array();
        }
        global $_G;
        if($_G['uid']<=0){
            return array();
        }
        $v = DB::fetch_first("select * from %t where authorid=%d and type=%s and typeid=%d ", array(
            $this->_table,
            $_G['uid'],
            $_GET['type'],
            $_GET['typeid'],
        ));
        return $this->prepare($v);
    }
}