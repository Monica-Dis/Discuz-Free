<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_dp_reply extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_dp_reply';
        $this->_pk = 'cid';

        parent::__construct(); //dis'.'m.tao'.'bao.com
    }

    public function fetch($id){
        $result = parent::fetch($id);
        $result['crts'] = dgmdate($result['crts'], 'u');
        return $result;
    }

    /**
     * @param $authorid
     * @param $touid
     * @param $pubid
     * @param $comment
     * @return mixed
     */
    public function add($authorid, $touid, $pubid, $comment, $pubuid, $shid = 0, $star = 5, $imglist = array(), $type = 0)
    {
        global $config,$_G;
        $author = getuserbyuid($authorid);
        $touser = getuserbyuid($touid);

        if($_G['cache']['plugin']['xigua_hc']['allowtbhf'] && $pubid){
            $pubinfo = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid);
            if($synctid = $pubinfo['tid']){
                include_once libfile('post/threadsorts', 'include');
                include_once libfile('function/forum');
                include_once libfile('function/post');
                global $_G;
                $tofid = $pubinfo['fid'];
                $uid = $_G['uid'];
                $username = $_G['username'];
                $time = TIMESTAMP;
                $subject = cutstr($comment, 60);
                $syncpid = insertpost(array('fid' => $tofid,'tid' => $synctid,'first' => '0','author' => $username,'authorid' => $uid,'subject' => '','dateline' => $time,'message' => $comment,'useip' => $_G['clientip'],'invisible' => '0','anonymous' => '0','usesig' => '0','htmlon' => '0','bbcodeoff' => '0','smileyoff' => '0','parseurloff' => '0','attachment' => '0',));
                updatepostcredits('+', $uid, 'post', $tofid);
                $synclastpost = "$synctid\t".addslashes($subject)."\t$time\t$username";
                DB::query("UPDATE ".DB::table('forum_forum')." SET lastpost='$synclastpost',  posts=posts+1, todayposts=todayposts+1 WHERE fid='$tofid'", 'UNBUFFERED');
            }
        }

        return $this->insert(array(
            'authorid' => intval($authorid),
            'author'   => $author['username'],
            'touid'    => intval($touid),
            'touser'   => $touser['username'],
            'comment'  => $comment,
            'pubid'    => $pubid,
            'crts'     => TIMESTAMP,
            'pubuid'   => $pubuid,
            'shid'     => $shid,
            'star'     => $star,
            'imglist'  => serialize($imglist),
            'type'  => intval($type),
            'new' => $type?1:0,
        ), true);
    }

    public function fetch_comment_by_pubid($pubid, $start_limit = 0, $lpp = 10)
    {
        $needrev = $start_limit ==0 && $lpp==5;
        $pubid = intval($pubid);
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE pubid=$pubid ORDER BY cid DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index]['crts'] = dgmdate($item['crts'], 'u');
        }
        if($needrev){
//            $result = array_reverse($result);
        }
        return $result;
    }

    public function fetch_type1_num(){
        global $_G;
        return DB::result_first('select COUNT(*) as num from %t WHERE touid=%d AND `type`=1 AND `new`=1', array($this->_table, $_G['uid'], $_G['uid']));
    }

    public function fetch_comment_by_type($uid, $type, $start_limit = 0, $lpp = 10)
    {
        $page = max(1, intval($_GET['page']));
        $lpp   = $_GET['pagesize'] ? intval($_GET['pagesize']) : 50;
        $start_limit = ($page - 1) * $lpp;
        $type = intval($type);
        $tmpcids = DB::fetch_all(' SELECT cid,authorid FROM ' . DB::table($this->_table) . " WHERE (touid=$uid OR authorid=$uid) AND `type`=$type ORDER BY cid DESC " . DB::limit($start_limit, $lpp));
        $cids = array();
        foreach (array_reverse($tmpcids) as $index => $tmpcid) {
            $cids[$tmpcid['authorid']] = $tmpcid['cid'];
        }
        $result = DB::fetch_all(' SELECT * FROM %t WHERE cid in(%n) ORDER BY cid DESC', array(
            $this->_table,
            $cids
        ));
//        $result = DB::fetch_all(' select * from ( select cid from '.DB::table($this->_table)." WHERE touid=$uid AND `type`=$type order by cid desc) as tt group by authorid ORDER BY cid DESC ". DB::limit($start_limit, $lpp));

        foreach ($result as $index => $item) {
            $result[$index]['crts'] = dgmdate($item['crts'], 'u');
            DB::query("update %t set `new`=0 WHERE touid=%d AND authorid=%d ", array($this->_table, $item['touid'], $item['authorid']));
        }
        return $result;
    }

    public function fetch_comment_by_shid($shid, $start_limit = 0, $lpp = 10)
    {
        $shid = intval($shid);
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE shid=$shid AND pubid=0 AND gid=0 ORDER BY cid DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index]['crts'] = dgmdate($item['crts'], 'u');
        }
        return $result;
    }

    public function fetch_comment_by_pubuid($uid, $start_limit = 0, $lpp = 10)
    {
        $uid = intval($uid);
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE pubuid=$uid ORDER BY cid DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index]['crts'] = dgmdate($item['crts'], 'u');
        }
        return $result;
    }

    public function fetch_comment_by_authorid($uid, $start_limit = 0, $lpp = 10)
    {
        $uid = intval($uid);
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE authorid=$uid AND `type`=0 ORDER BY cid DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index]['crts'] = dgmdate($item['crts'], 'u');
        }
        return $result;
    }


    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }
    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE cid IN (%n)', array($this->_table, $ids));
    }
    public function fetch_all_bypage($wherearr, $start_limit, $lpp, $order = '')
    {
        if(!$order){
            $order = "$this->_pk DESC";
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql  ORDER BY $order" . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_bypage($wherearr)
    {
        if($wherearr == array('pubid=')){
            return 0;
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table). " $wheresql ");
        return $result;
    }

    public function prepare($v)
    {
        global $_G;
        if($v){
            $v['crts_u'] = dgmdate($v['crts'], 'u');
            $v['avatar'] = avatar($v['authorid'], 'middle', 1);
            if($v['touid']==$_G['uid']){
                $v['who'] =  'guest';
            } elseif ($v['authorid'] == $_G['uid']){
                $v['who'] =  'me';
            }
        }
        return $v;
    }

    public function fetch_by_cid($id){
        $result = parent::fetch($id);
        $result = $this->prepare($result);
        return $result;
    }
}