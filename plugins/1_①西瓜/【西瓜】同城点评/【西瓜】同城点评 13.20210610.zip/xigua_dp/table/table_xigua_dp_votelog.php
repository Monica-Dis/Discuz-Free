<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_dp_votelog extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_dp_votelog';
        $this->_pk = 'id';

        parent::__construct(); //dis'.'m.tao'.'bao.com
    }

    public function fetch_by_uid($uid, $pubid)
    {
        return DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND pubid=%d LIMIT 1', array(
            $this->_table,
            $uid,
            $pubid
        ));
    }

    public function fetch_by_pubid($pubid, $start_limit = 0, $lpp = 10)
    {
        $pubid = intval($pubid);
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE pubid=$pubid ORDER BY id DESC " . DB::limit($start_limit, $lpp));

        return $result;
    }

    public function fetch_by_uid_pubids($uid, $pubids)
    {
        $result = DB::fetch_all('SELECT id,pubid FROM %t WHERE uid=%d AND pubid IN (%n) ' , array(
            $this->_table,
            $uid,
            $pubids,
        ), 'pubid');

        return $result;
    }
}