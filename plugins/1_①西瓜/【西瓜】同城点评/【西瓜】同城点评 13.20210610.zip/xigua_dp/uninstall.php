<?php
/**
 * Created by https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958  ΢��wxiguabbs
 * User: yangzhiguo
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
DROP TABLE pre_xigua_dp_reply;
DROP TABLE pre_xigua_dp_index;
DROP TABLE pre_xigua_dp_comment;
DROP TABLE pre_xigua_dp_votelog;
EOT;
runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/discuz_plugin_xigua_dp_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dp/install.php');

xwbdelall(DISCUZ_ROOT . "./source/plugin/xigua_dp");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_dp");

$finish = TRUE;

function xwbdelall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);
        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwbdelall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}