<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $config['qn_ak'] && $config['qn_sk'] && $config['qn_bk'] && $config['qn_url']}-->
<script src="https://unpkg.com/qiniu-js@2.5.4/dist/qiniu.min.js"></script>
<!--{elseif ($config['ACCESS_ID'] && $config['ACCESS_KEY'] && $config['ENDPOINT'] && $config['BUCKET'])}-->
<!--{eval
$config['REGION'] = str_replace(array('http://','https://', '.aliyuncs.com'), '', $config['ENDPOINT']);
$config['ossurl'] = $config['ossurl'] ? $config['ossurl'] : str_replace(array('http://', 'https://'), array('http://'.$config['BUCKET'].'.', 'https://'.$config['BUCKET'].'.'), $config['ENDPOINT']);
$config['ossurl'] = rtrim($config['ossurl'], '/'). '/';
}-->
<script src="https://gosspublic.alicdn.com/aliyun-oss-sdk-6.1.0.min.js"></script>
<!--{/if}-->
<script>
    var FileBlob = null, MAXVSIZE = {echo intval($vipinfo['maxsize'])};
    var videoField = '.weui-uploader__input_video';

    $(document).on('change', videoField, function () {
        if (this.files[0]) {
            FileBlob = this.files[0];
            var fsize = FileBlob.size;
            if(fsize>MAXVSIZE*1048576){
                $.toast('{lang xigua_hb:UPLOAD_ERR_FORM_SIZE}', 'error');
                $(videoField).val('');
                return false;
            }
            console.log(fsize);
            var ext = FileBlob.name.substring(FileBlob.name.lastIndexOf('.') + 1);
            var myDate = new Date();
            var timestamp = myDate.getTime() + '_' + Math.ceil(Math.random() * 9999);
            var filename = myDate.getFullYear()+''+myDate.getMonth()+''+myDate.getDate()+"/" + timestamp + "." + ext;
            hs_upload_video(filename);
        }
    });
    function hs_upload_video(filename){
        <!--{if $config['qn_ak'] && $config['qn_sk'] && $config['qn_bk'] && $config['qn_url']}-->
        $.ajax({
            type: 'get',
            url: _APPNAME + '?id=xigua_hs:hs_api&inajax=1',
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    var tk = s.split('|')[1];
                    var QNC = qiniu.upload(FileBlob, filename, tk, {Params:null,MimeType: null,Crc32:1,CheckCrc:0}, []);
                    var subscription = QNC.subscribe(function (rate) {
                        $.hideLoading();
                        $.showLoading(Math.floor(rate.total.percent)+'%');
                    }, function (res) {
                        $(videoField).val('');
                        $.hideLoading();
                        $.toast(res.err.message);
                    }, function (result) {
                        $(videoField).val('');
                        $.hideLoading();
                        var vsrc = "{$config['qn_url']}/"+result.key;
                        var vposter = vsrc + '?vframe/jpg/offset/1';
                        $('.video_cover').val(vposter);
                        insert_video_ul(vsrc, vposter);
                    });
                } else {
                    $(videoField).val('');
                    tip_common(s);
                }
            }
        });
        <!--{elseif ($config['ACCESS_ID'] && $config['ACCESS_KEY'] && $config['ENDPOINT'] && $config['BUCKET'])}-->
        var OSSC = new OSS({ region:"{$config['REGION']}", accessKeyId:"{$config['ACCESS_ID']}", accessKeySecret:"{$config['ACCESS_KEY']}", bucket:"{$config['BUCKET']}" });
        OSSC.multipartUpload(filename, FileBlob, {
            progress: function (rate) {
                $.hideLoading();
                $.showLoading(Math.floor(rate * 100)+'%');
            }
        }).then(function (result) {
            $(videoField).val('');
            $.hideLoading();
            var snapshot = OSSC.signatureUrl(filename, { 'process': 'video/snapshot,t_5000,f_jpg,w_640,h_0,m_fast' })+'&x-oss-process=video/snapshot,t_5000,f_jpg,w_640,h_0,m_fast';
            var vsrc = "{$config['ossurl']}"+result.name;
            insert_video_ul(vsrc, '');
            create_poster(snapshot);
        }).catch(function (err) {
            $(videoField).val('');
            $.hideLoading();
            if(err){ $.alert('', err); }
        });
        <!--{/if}-->
    }
    function create_poster (snapshot) {
        var image = new Image();
        image.crossOrigin = "Anonymous";
        image.src = snapshot;
        image.onload = function () {
            var canvas = document.createElement("canvas");
            canvas.width = image.width;
            canvas.height = image.height;
            canvas.getContext('2d').drawImage(image, 0, 0, image.width, image.height);
            canvas.toBlob(function (blob) {
                upload_cover(blob);
            }, 'image/jpeg', 1);
        }
    }
    function upload_cover(blob){
        var formdata=new FormData();
        formdata.append('file',blob);
        $.ajax({
            type: 'post',
            url: _APPNAME+'?id=xigua_hb&ac=uploader&inajax=1&formhash='+FORMHASH,
            data :  formdata,
            processData : false,
            contentType : false,
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    var sv = s.split('|')[1];
                    $('.video_LI').css('background-image', 'url('+sv+')');
                    $('.video_LI').find('.video_cover').val(sv);
                } else {
                    tip_common(s);
                }
            }
        });
    }
    function insert_video_ul(vsrc, poster) {
        var inrthtml ="<li class=\"video_LI weui-uploader__file weui-uploader__file_status\" style=\"background-image:url("+poster+")\">\n" +
            "<div class=\"emvdo\"></div>" +
            "<input type=\"hidden\" name=\"form[video]\" value=\""+vsrc+"\">\n" +
            "<div class=\"weui-uploader__file-content\"><i class=\"weui-icon-warn iconfont icon-shanchu\"></i></div>\n" +
            "<input type=\"hidden\" name=\"form[video_cover]\" class=\"video_cover\" value=\""+poster+"\"></li>";
        $('.weui_videos').html(inrthtml);
    }
<!--{if $old_data['video']}-->insert_video_ul("{$old_data['video']}", "{$old_data['video_cover']}");<!--{/if}-->
<!--{if $old_data && in_array('video', $vipinfo['access'])}-->$('#vycanshow').removeClass('none');<!--{/if}-->
$(document).on('click','.typevip', function () {
    var that = $(this);
    var acs = that.data('acs');
    MAXVSIZE = acs;
    $('#maxsizev').html(MAXVSIZE);
    if(acs>0){
        $('#vycanshow').removeClass('none');
    }else{
        $('#vycanshow').addClass('none');
    }
    var access_qr = that.data('access_qr');
    var access_album = that.data('access_album');
    var access_jieshao2 = that.data('access_jieshao2');
    if(access_qr){
        $('#access_qr').show();
    }else{
        $('#access_qr').hide();
    }
    if(access_album){
        $('#access_album').show();
    }else{
        $('#access_album').hide();
    }
    if(access_jieshao2){
        $('#access_jieshao2').show();
    }else{
        $('#access_jieshao2').hide();
    }
});
</script>
