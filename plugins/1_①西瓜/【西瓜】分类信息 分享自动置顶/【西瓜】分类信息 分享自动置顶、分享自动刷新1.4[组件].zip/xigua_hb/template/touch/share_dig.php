<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $catinfo['share_dig'] && $catinfo['share_dig_days'] && $info['mark_autodig']<=0}-->
<script>
history.replaceState(null, '', window.location.href.replace(/ecid\=\d+\&/, '')+'&ecid={$_G[uid]}');
$.modal({
    title: "{lang xigua_hb:gx_dig}",
    text: "{echo str_replace(array('ren', 'day','nnn'), array('<em class=main_color>'.$catinfo['share_dig'].'</em>', '<em class=main_color>'.$catinfo['share_dig_days'].'</em>', '<em class=main_color>'.$info['realview'].'</em>'), lang_hb('share_dig_tip', 0));}",
    buttons: [{text:'{lang xigua_hb:close}', className: "default", onClick:function () {}}, { text: "{lang xigua_hb:qufenxiang}", onClick: function(){
            localStorage.setItem('wetip_$pubid',1);
            hb_jump('$SCRITPTNAME?id=xigua_hb&ac=view&pubid=$pubid&ecid={$_G[uid]}')}
    }]
});
</script>
<!--{elseif $catinfo['share_refresh'] && $info['mark_autorefresh']<=0}-->
<script>
history.replaceState(null, '', window.location.href.replace(/ecid\=\d+\&/, '')+'&ecid={$_G[uid]}');
$.modal({
    title: "{lang xigua_hb:gx_refresh}",
    text: "{echo str_replace(array('ren', 'nnn'), array('<em class=main_color>'.$catinfo['share_refresh'].'</em>', '<em class=main_color>'.$info['realview'].'</em>'), lang_hb('share_refresh_tip', 0));}",
    buttons: [{text:'{lang xigua_hb:close}', className: "default", onClick:function () {}}, { text: "{lang xigua_hb:qufenxiang}", onClick: function(){
            localStorage.setItem('wetip_$pubid',1);
            hb_jump('$SCRITPTNAME?id=xigua_hb&ac=view&pubid=$pubid&ecid={$_G[uid]}')}
    }]
});
</script>
<!--{/if}-->