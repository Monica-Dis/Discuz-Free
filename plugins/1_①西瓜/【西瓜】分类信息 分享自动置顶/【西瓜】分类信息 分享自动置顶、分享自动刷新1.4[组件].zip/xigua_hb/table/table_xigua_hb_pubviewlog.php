<?php
/**
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hb_pubviewlog extends discuz_table
{
    public function __construct() {

        $this->_table = 'xigua_hb_pubviewlog';
        $this->_pk    = 'id';

        parent::__construct();
    }

    public function doinsert($pubid, $info, $catinfo)
    {
        if(!$_GET['ecid']){
            return false;
        }
        $pubinfo = $info;
        global $_G;
        $ip = $_G['clientip'];
        if(!$ip){
            return false;
        }
        if($info['uid']==$_G['uid']){
            return false;
        }
        if($info['mark_autodig']>0 || $info['mark_autorefresh']>0){
            return false;
        }
        $old = DB::fetch_first('select * from %t where toid=%d and ip=%s limit 1', array($this->_table, $pubid,  $ip));
        if(!$old){
           $newid = parent::insert(array(
                'uid' => $_G['uid'],
                'toid' => $pubid,
                'crts' => TIMESTAMP,
                'ip'  => $ip
            ), 1);
            C::t('#xigua_hb#xigua_hb_pub')->incr($pubid, 'realview');
            $realview = $info['realview']+1;
            if($catinfo['share_dig']>0 && $catinfo['share_dig_days']>0){
                if($realview>=$catinfo['share_dig'] && $info['mark_autodig']<=0){
                    $replace = array(
                        'dig_endts'=> max(TIMESTAMP, $pubinfo['dig_endts'])+ (86400*$catinfo['share_dig_days']),
                        'dig_crts' => TIMESTAMP,
                        'mark_autodig' => TIMESTAMP,
                    );
                    C::t('#xigua_hb#xigua_hb_pub')->update($pubid, $replace);
                }
            }elseif( $catinfo['share_refresh']>0){
                if($realview>=$catinfo['share_refresh'] && $info['mark_autorefresh']<=0){
                    $replace = array(
                        'refresh_times'=> $pubinfo['refresh_times']+1,
                        'up_time' => dgmdate(TIMESTAMP, 'Y-m-d H:i:s'),
                        'mark_autorefresh' => TIMESTAMP,
                    );
                    C::t('#xigua_hb#xigua_hb_pub')->update($pubid, $replace);
                }
            }
        }
        return true;
    }
}