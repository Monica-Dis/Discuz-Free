<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $SCRITPTNAME, $urlext, $pubid, $config;
if ($_GET['do'] == 'pubhb' && submitcheck('pshid')) {
    hb_check_bind(2);
    $shid = intval($_GET['pshid']);
    if ($_GET['hbmoney'] <= 0) {
        hb_message(lang_hb('qtx', 0) . lang_hb('hb', 0) . lang_hb('zong', 0) . lang_hb('jine', 0), 'error');
    }
    if ($_GET['hbnum'] <= 0) {
        hb_message(lang_hb('qtx', 0) . lang_hb('hb', 0) . lang_hb('zong', 0) . lang_hb('num', 0), 'error');
    }
    if ($_GET['hbtiaojian'] < 1) {
        hb_message(lang_hb('qtx', 0) . lang_hb('lqtj', 0), 'error');
    }
    if ($_GET['hbmoney'] / $_GET['hbnum'] < 0.01) {
        hb_message(lang_hb('mghbzdyf', 0), 'error');
    }

    $amount = $_GET['hbmoney'];
    $url = "$SCRITPTNAME?id=xigua_hs&ac=view&shid=$shid$urlext";
    $sxf = 0;
    if($config['hbsxf']){
        $sxf=$amount*($config['hbsxf']/100);
        $sxf=sprintf("%.2f",$sxf);
    }

    $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $amount+$sxf, lang_hb('pubhbrw', 0) . $_GET['hbmoney'] . lang_hb('yuan', 0) . $_GET['hbnum'] . lang_hb('bao', 0), 'common_rwhb', array(
        'data' => array(
            'uid' => $_G['uid'],
            'hbmoney' => $amount,
            'shid' => $shid,
            'hbnum' => $_GET['hbnum'],
            'hbtiaojian' => $_GET['hbtiaojian'],
        ),
        'callback' => array(
            'file' => 'source/plugin/xigua_hb/function_hbrw.php',
            'method' => 'hb_rwhs_callback'
        ),
        'location' => $_GET['backto'] ? $_GET['backto'] : $_G['siteurl'] . $url,
    ));

    $rl = urlencode($url);
    $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl" . $urlext) . $urlext;
    hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
} elseif ($_GET['do'] == 'pubhb' && submitcheck('pubid')) {
    hb_check_bind(2);
//    $pubinfo = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid);
    if ($_GET['hbmoney'] <= 0) {
        hb_message(lang_hb('qtx', 0) . lang_hb('hb', 0) . lang_hb('zong', 0) . lang_hb('jine', 0), 'error');
    }
    if ($_GET['hbnum'] <= 0) {
        hb_message(lang_hb('qtx', 0) . lang_hb('hb', 0) . lang_hb('zong', 0) . lang_hb('num', 0), 'error');
    }
    if ($_GET['hbtiaojian'] < 1) {
        hb_message(lang_hb('qtx', 0) . lang_hb('lqtj', 0), 'error');
    }
    if ($_GET['hbmoney'] / $_GET['hbnum'] < 0.01) {
        hb_message(lang_hb('mghbzdyf', 0), 'error');
    }

    $amount = $_GET['hbmoney'];
    $url = "$SCRITPTNAME?id=xigua_hb&ac=view&pubid=$pubid$urlext";
    $sxf = 0;
    if($config['hbsxf']){
        $sxf=$amount*($config['hbsxf']/100);
        $sxf=sprintf("%.2f",$sxf);
    }
    $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $amount+$sxf, lang_hb('pubhbrw', 0) . $_GET['hbmoney'] . lang_hb('yuan', 0) . $_GET['hbnum'] . lang_hb('bao', 0), 'common_rwhb', array(
        'data' => array(
            'uid' => $_G['uid'],
            'hbmoney' => $amount,
            'pubid' => $pubid,
            'hbnum' => $_GET['hbnum'],
            'hbtiaojian' => $_GET['hbtiaojian'],
        ),
        'callback' => array(
            'file' => 'source/plugin/xigua_hb/function_hbrw.php',
            'method' => 'hb_rwhb_callback'
        ),
        'location' => $_GET['backto'] ? $_GET['backto'] : $_G['siteurl'] . $url,
    ));

    $rl = urlencode($url);
    $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&sxf=$sxf&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl" . $urlext) . $urlext;
    hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
}