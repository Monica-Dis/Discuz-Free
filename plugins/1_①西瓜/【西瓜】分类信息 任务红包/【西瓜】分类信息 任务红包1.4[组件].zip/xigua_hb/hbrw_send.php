<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_G['uid'] && $_GET['edid'] && $_G['uid']!=$_GET['edid']){
    hbsend1();
}
function logwrite_hbvlog($toid, $uidtmp){
    global $_G;
    DB::insert('xigua_hb_hbvlog', array(
        'uid' => $_G['uid'],
        'toid' => $toid,
        'crts' => TIMESTAMP,
        'ip' => $_G['clientip'],
        'rwuid' => $uidtmp,
    ), 1);
}
function hbsend1(){
    global $_G, $v, $pubid, $shid, $SCRITPTNAME, $urlext;

    $faqiuid = $_GET['edid'];  //��������
    //�������ظ���
    $rwtype = $_GET['pubid']? 'pub_'.$_GET['pubid'] : 'hs_'.$_GET['shid'];
    $num = DB::fetch_first('select * from %t where uid=%d and toid=%s and rwuid=%d', array('xigua_hb_hbvlog', $_G['uid'], $rwtype, $faqiuid));
    if($num){
        return false;
    }
    //ÿ����Ϣÿ��������10���������������
    $num = DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND toid=%s AND crts BETWEEN %d AND %d', array(
        'xigua_hb_hbvlog',
        $_G['uid'],
        $rwtype,
        strtotime(date('Y-m-d 00:00:00')),
        strtotime(date('Y-m-d 23:59:59'))
    ));
    if(count($num)>= 10 ){
        return false;
    }
    if($_GET['pubid']){
        $hongbaolog1=C::t('#xigua_hb#xigua_hb_hongbaolog')->fetch_by_uid_pubid($faqiuid, $pubid);
        if($v['hb_num']>$v['hb_sendnum']  && !$hongbaolog1){
            $info = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid, 1);
            if ($info['hb_num'] <= 0) {
                return false;
            }
            if ($info['hb_num'] <= $info['hb_sendnum']) {
                return false;
            }
            $oldhbtmp = DB::fetch_first('select * from %t where pubid=%d and uid=0 and uidtmp=%d', array('xigua_hb_hongbaolog', $pubid, $faqiuid));
            if(!$oldhbtmp){
                DB::query("UPDATE %t SET uidtmp=%d,viewnum=1 WHERE pubid=%d AND uidtmp=0 and uid=0  LIMIT 1", array('xigua_hb_hongbaolog', $faqiuid, $pubid));
                $rows = DB::affected_rows();
                if(!$rows){
                    return false;
                }
            }else{
                DB::query("UPDATE %t SET viewnum=viewnum+1 WHERE pubid=%d AND uidtmp=%d and uid=0  LIMIT 1", array('xigua_hb_hongbaolog', $pubid, $faqiuid ));
            }
            $_note = '<a href="{url}">'.$_G['username'].'{ts}'.lang('plugin/xigua_hb','ll').'{title}</a>';
            notification_add($faqiuid,'system',$_note,array(
                'ts' => date('Y-m-d H:i:s', TIMESTAMP),
                'url' => $_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=view&pubid=".$_GET['pubid'],
                'title' => lang_hb('xinxi',0).lang_hb('m',0).cutstr(str_replace(array("\n","\r"),'',strip_tags($info['description'])),20),
            ),1);
            logwrite_hbvlog($rwtype, $faqiuid);

            $oldhbtmp = DB::fetch_first('select * from %t where pubid=%d and uid=0 and uidtmp=%d', array('xigua_hb_hongbaolog', $pubid, $faqiuid));
            $hcc  = DB::result_first('select count(*) from %t where toid=%s and rwuid=%d', array('xigua_hb_hbvlog', $rwtype, $faqiuid));
            if($oldhbtmp['viewnum']>=$v['hbtiaojian'] || $hcc>=$v['hbtiaojian']){
                if (C::t('#xigua_hb#xigua_hb_hongbaolog')->update_one($pubid, $faqiuid)) {
                    C::t('#xigua_hb#xigua_hb_pub')->incr($pubid, 'hb_sendnum');
                    $hblog = C::t('#xigua_hb#xigua_hb_hongbaolog')->fetch_by_uid_pubid($faqiuid, $pubid);
                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($faqiuid, 'money', $hblog['size']);
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array('uid' => $faqiuid, 'crts' => TIMESTAMP, 'size' => $hblog['size'], 'note' => lang_hb('fenleixinxihongbao', 0) . '(ID:' . $pubid . ')', 'link' => "$SCRITPTNAME?id=xigua_hb&ac=view&pubid=$pubid$urlext"));
                    notification_add($faqiuid,'system',lang('plugin/xigua_hb','gxnoti'),array(
                        'url' => "$SCRITPTNAME?id=xigua_hb&ac=qianbao",
                        'title' => lang_hb('xinxi',0),
                        'n' => $v['hbtiaojian'],
                        'x' => $hblog['size'],
                    ),1);
                } else {
                }
            }

        }
    }elseif ($_GET['shid']){
        $shid = $_GET['shid'];
        $faqiuid = $_GET['edid'];
        $hongbaolog1=C::t('#xigua_hb#xigua_hb_hongbaolog')->fetch_by_uid_shid($faqiuid, $shid);
        if($v['hong_num']>$v['hong_sendnum']  && !$hongbaolog1){

            $info = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($shid);
            if ($info['hong_num'] <= 0) {
                return false;
            }
            if ($info['hong_num'] <= $info['hong_sendnum']) {
                return false;
            }
            $oldhbtmp = DB::fetch_first('select * from %t where shid=%d and uid=0 and uidtmp=%d', array('xigua_hb_hongbaolog', $shid, $faqiuid));
            if(!$oldhbtmp){
                DB::query("UPDATE %t SET uidtmp=%d,viewnum=1 WHERE shid=%d AND uidtmp=0 and uid=0 limit 1", array('xigua_hb_hongbaolog', $faqiuid, $shid));
                $rows = DB::affected_rows();
                if(!$rows){
                    return false;
                }
            }else{
                DB::query("UPDATE %t SET viewnum=viewnum+1 WHERE shid=%d AND uidtmp=%d and uid=0  LIMIT 1", array('xigua_hb_hongbaolog', $shid, $faqiuid ));
            }
            $_note = '<a href="{url}">'.$_G['username'].'{ts}'.lang('plugin/xigua_hb','ll').'{title}</a>';
            notification_add($faqiuid,'system',$_note,array(
                'ts' => date('Y-m-d H:i:s', TIMESTAMP),
                'url' => $_G['siteurl']."$SCRITPTNAME?id=xigua_hs&ac=view&shid=".$_GET['shid'],
                'title' => lang_hb('shj',0).lang_hb('m',0).$info['name'],
            ),1);
            logwrite_hbvlog($rwtype, $faqiuid);
            $oldhbtmp = DB::fetch_first('select * from %t where shid=%d and uid=0 and uidtmp=%d', array('xigua_hb_hongbaolog', $shid, $faqiuid));
            $hcc  = DB::result_first('select count(*) from %t where toid=%s and rwuid=%d', array('xigua_hb_hbvlog', $rwtype, $faqiuid));

            if($oldhbtmp['viewnum']>=$v['hbtiaojian'] || $hcc>=$v['hbtiaojian']){
                if (C::t('#xigua_hb#xigua_hb_hongbaolog')->update_one_by_shid($shid, $faqiuid)) {
                    C::t('#xigua_hs#xigua_hs_shanghu')->incr($shid, 'hong_sendnum');
                    $hblog = C::t('#xigua_hb#xigua_hb_hongbaolog')->fetch_by_uid_shid($faqiuid, $shid);
                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($faqiuid, 'money', $hblog['size']);
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid' => $faqiuid,
                        'crts' =>TIMESTAMP,
                        'size' => $hblog['size'],
                        'note' => lang_hb('shhb',0).'(ID:'.$shid.')',
                        'link' => "$SCRITPTNAME?id=xigua_hs&ac=view&shid=$shid".$urlext,
                    ));
                } else {
                }
            }
        }
    }
}