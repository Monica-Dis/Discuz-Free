<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function hb_rwhb_callback($param){
    $info = $param['info'];
    $data = $info['data']; /*
            'uid' => $_G['uid'],
            'hbmoney' => $amount,
            'pubid' => $pubid,
            'hbnum' => $_GET['hbnum'],
            'hbtiaojian' => $_GET['hbtiaojian'],*/
    $pubinfo = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($data['pubid']);

    $replace = array(
        'hb_num'   => intval($pubinfo['hb_num'])+$data['hbnum'],
        'hb_money'   => $pubinfo['hb_money'] + $data['hbmoney'],
        'hb_sendnum' => intval($pubinfo['hb_sendnum'])+0,
        'hbtiaojian' => $data['hbtiaojian'],
    );
    C::t('#xigua_hb#xigua_hb_pub')->update($data['pubid'], $replace);
    include_once DISCUZ_ROOT. 'source/plugin/xigua_hb/lib/hb.class.php';
//    $hblist = randBean($data['hbmoney'], $data['hbnum']);
    $hblist = range(0, $data['hbnum']-1);
    foreach ($hblist as $size) {
        /*
ALTER TABLE `w_xigua_hb_hongbaolog` ADD `uidtmp` INT(11) NOT NULL AFTER `jid`, ADD `viewnum` INT(11) NOT NULL AFTER `uidtmp`;*/
        C::t('#xigua_hb#xigua_hb_hongbaolog')->insert(array(
            'uid'  => 0,
            'pubid'=> $data['pubid'],
            'size' => $data['hbmoney']/$data['hbnum'],
            'viewnum' => 0,
            'uidtmp' => 0,
            'crts' => 0
        ));
    }

    return true;
}

function hb_rwhs_callback($param){
    $info = $param['info'];
    $data = $info['data']; /*
            'uid' => $_G['uid'],
            'hbmoney' => $amount,
            'shid' => $shid,
            'hbnum' => $_GET['hbnum'],
            'hbtiaojian' => $_GET['hbtiaojian'],*/
    $shinfo = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($data['shid']);

    $replace = array(
        'hong_num'   => intval($shinfo['hong_num'])+$data['hbnum'],
        'hong_money'   => $shinfo['hong_money'] + $data['hbmoney'],
        'hong_sendnum' => intval($shinfo['hong_sendnum'])+0,
        'hbtiaojian' => $data['hbtiaojian'],
    );
    C::t('#xigua_hs#xigua_hs_shanghu')->update($data['shid'], $replace);
    include_once DISCUZ_ROOT. 'source/plugin/xigua_hb/lib/hb.class.php';
//    $hblist = randBean($data['hbmoney'], $data['hbnum']);
    $hblist = range(0, $data['hbnum']-1);
    foreach ($hblist as $size) {
        /*
ALTER TABLE `w_xigua_hb_hongbaolog` ADD `uidtmp` INT(11) NOT NULL AFTER `jid`, ADD `viewnum` INT(11) NOT NULL AFTER `uidtmp`;*/
        C::t('#xigua_hb#xigua_hb_hongbaolog')->insert(array(
            'uid'  => 0,
            'pubid'=> 0,
            'shid'=> $data['shid'],
            'size' => $data['hbmoney']/$data['hbnum'],
            'viewnum' => 0,
            'uidtmp' => 0,
            'crts' => 0
        ));
    }

    return true;
}