<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{eval
if($_GET[edid] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php')):
    include_once DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php';
endif;
}--><!--{if $_G[uid] &&  $v[hbtiaojian]>0}--><!--{eval
$oldhbtmp = DB::fetch_first('select * from %t where pubid=%d and uidtmp=%d and uid=0', array('xigua_hb_hongbaolog', $pubid, $_G['uid']));
$oldhbtmp1 = DB::result_first('select size from %t where pubid=%d ORDER BY id DESC', array('xigua_hb_hongbaolog', $pubid));
$hbuserlist1 = DB::fetch_all('select * from %t where toid=%s and rwuid=%d', array('xigua_hb_hbvlog', 'pub_'.$pubid, $_G['uid']));
}--><script>function showfxhb(){
history.replaceState(null, '', window.location.href.replace(/edid\=\d+\&/, '')+'&edid={$_G[uid]}');
$.modal({title: "{lang xigua_hb:rwhb}",
    text: "<div class=''>{lang xigua_hb:qks1} <em class='main_color'>{$v[hbtiaojian]} {lang xigua_hb:ren}{lang xigua_hb:ll}</em>, {lang xigua_hb:qks2} <em class='color-red2'>{$oldhbtmp1} {lang xigua_hb:yuan}{lang xigua_hb:hb}</em><br>{lang xigua_hb:qks3} <em class='main_color'>{echo count($hbuserlist1);} {lang xigua_hb:ren}{lang xigua_hb:ll}</em></div><div class='cl'><!--{loop $hbuserlist1 $_k $_v}--><div class='hvlist'><img onerror=\"this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'\" src='{avatar($_v[uid], 'middle', 1)}' /></div><!--{/loop}--></div>",
    buttons: [{text:'{lang xigua_hb:close}', className: "default", onClick:function () {}}, { text: "{lang xigua_hb:qks}", onClick: function(){
        localStorage.setItem('wetip_$pubid',1);
        hb_jump('$SCRITPTNAME?id=xigua_hb&ac=view&pubid=$pubid&edid={$_G[uid]}')}
}]
});return false;}</script><!--{/if}-->