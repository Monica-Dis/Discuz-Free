<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<script>
function hb_selecthbtype(id) {
    $.modal({
        title: "{lang xigua_hb:fhb}",
        text: "{lang xigua_hb:qxzfhb}",
        buttons: [
            { text: "{lang xigua_hb:quxiao}", className: "default", onClick: function(){ } },
            { text: "{lang xigua_hb:putong}",  onClick: function(){
                    $.actions({title: '{lang xigua_hb:hongbaojine}',actions: [<!--{loop $red $item}-->{text: "{$item[title]}",onClick: function() { hb_jump('$SCRITPTNAME?id=xigua_hb&ac=pay&redtype={$item[price]}&pubid='+id+_URLEXT);}},<!--{/loop}-->]});
                } },
            { text: "{lang xigua_hb:rwhb}",  onClick: function(){
                    $('#pubhb_ctrl').popup().show();$('.pubidhb').val(id).html(id+'');
                } },
        ]
    });
}
var formlockx = 0;
$(document).on('submit', '#formx', function () {
    var dosubbtn = $('#dosubmitx');
    var that = $(this);
    if (formlockx === 1) {
        return false;
    }
    $.showLoading();
    formlockx = 1;
    $.ajax({
        type: 'post',
        url: that.attr('action') + '&inajax=1' + _URLEXT,
        data: that.serialize(),
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            formlockx = 0;
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () {
            $.hideLoading();
            formlockx = 0;
        }
    });
    return false;
});
</script>
<div id="pubhb_ctrl" style="z-index:999;display:none" class="weui-popup__container popup-bottom">
    <form  action="$SCRITPTNAME?id=xigua_hb&ac=hbrw&do=pubhb&st={$_GET['st']}" method="post" id="formx">
        <input name="formhash" value="{FORMHASH}" type="hidden">
        <input name="inajax" value="1" type="hidden">
        <input name="pubid" class="pubidhb" value="0" type="hidden">
        <input name="pshid" class="pshid" value="0" type="hidden">
        <div class="weui-popup__overlay"></div>
        <div class="weui-popup__modal">
            <div class="toolbar">
                <div class="toolbar-inner">
                    <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:quxiao}</a>
                    <h1 class="title">{lang xigua_hb:pubhbrw}</h1>
                </div>
            </div>
            <div class="modal-content">
                <div class="weui-cells before_none after_none">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hb:hbzje}</label></div>
                        <div class="weui-cell__bd">
                            <input name="hbmoney" class="weui-input" type="tel" placeholder="{lang xigua_hb:qtx}{lang xigua_hb:hbzje}" value="">
                        </div>
                        <div class="weui-cell__ft">
                            {lang xigua_hb:yuan}
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hb:hb}{lang xigua_hb:num}</label></div>
                        <div class="weui-cell__bd">
                            <input name="hbnum" class="weui-input" type="tel" placeholder="{lang xigua_hb:qtx}{lang xigua_hb:hb}{lang xigua_hb:num}" value="">
                        </div>
                        <div class="weui-cell__ft">{lang xigua_hb:j}</div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hb:lqtj}</label></div>
                        <div class="weui-cell__bd">
                            <input name="hbtiaojian" class="weui-input" type="tel" placeholder="{lang xigua_hb:ckcs}" value="">
                        </div>
                        <div class="weui-cell__ft">{lang xigua_hb:c}</div>
                    </div>
                </div>
                <div class="fix-bottom" style="position: relative">
                    <input type="submit" id="dosubmitx" href="javascript:;" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}">
                </div>
            </div>
        </div>
    </form>
</div>