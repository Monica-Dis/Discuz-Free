<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<div class="weui-cell" id="video_box" <!--{if !$old_data['video']}-->style="display:none"<!--{/if}-->>
    <input type="hidden" name="form[video_cover]" class="video_cover" value="{$old_data['video_cover']}">
    <div class="weui-cell__bd">
        <!--{if $old_data['video']}-->
        <video id="newvideo" poster="{$old_data['video_cover']}" class="video_prev" src="{$old_data['video_cover']}" controls="controls"></video><input type="hidden" name="form[video]" value="{$old_data['video']}" />
        <!--{/if}-->
    </div>
    <div class="video_del"><i class="color-red2 iconfont icon-shanchu f24"></i></div>
</div>
