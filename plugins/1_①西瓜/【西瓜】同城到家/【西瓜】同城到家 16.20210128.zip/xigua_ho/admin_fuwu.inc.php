<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if (empty($_G['cache']['plugin'])) :
    loadcache('plugin');
endif;
$ho_config = $_G['cache']['plugin']['xigua_ho'];
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_ho/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_ho/common_status.php';

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$pzfield = array();

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" /><style>img{object-fit:cover}</style>";
if($secid = intval($_GET['secid'])){
    $res = C::t('#xigua_ho#xigua_ho_fuwu')->fetch_by_id($secid);
    $unsetary =array(
        'allnum' ,'id', 'hy', 'hangye_id1', 'shname', 'type_u','is_dig','dig_endts_u', 'upts_u','crts_u','gender_u','fuli_ary','jdstatus','endts', 'dig_days',
        'jineng_ary','jineng_str_ary','areawant','areawant_str_ary','level_str', 'score' ,'jineng_str', 'areawant_ary', 'shifuid','shid','jingyan','orderid','payts','tuijian','order_id','shares'
    );
    $ts_ary = array('crts', 'upts', 'dig_startts','dig_endts', 'endts', 'payts');
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $neww = 1;
            $res = array ( 'id' => '1', 'displayorder' => '0', 'uid' => '0', 'price' => 0, 'unit' => '1', 'dingjin_open' => '0', 'dingprice' => 0, 'yuyue' => '0','opentime' => '8:00-21:00', 'title' => '', 'shifuid' => '0', 'status' => '1', 'addr' => '', 'province' => '', 'city' => '', 'district' => '', 'street' => '', 'street_number' => '', 'lat' => '', 'lng' => '', 'shname' => '', 'shid' => '0', 'jineng' => '0', 'jineng_str' => '', 'jingyan' => '0', 'areawant' => '', 'areawant_str' => '', 'jieshao' => '', 'album' => array (), 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'dig_startts' => '', 'dig_endts' => '', 'dig_days' => '0', 'endts' => '0', 'views' => '0', 'shares' => '0', 'stid' => '0',  'payts' => '0',  'jineng_ary' => array ( ), 'jineng_str_ary' => array ( ) );
        }
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_ho('spgl',0) . ($secid>0?'-'. $res['title']." [ID : $secid]" :''). "&nbsp;&nbsp;<a class='abtn' href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu'>".lang_ho('back',0)."</a>");

        $listinfo = C::t('#xigua_ho#xigua_ho_cat')->list_all(1);
        C::t('#xigua_ho#xigua_ho_cat')->init($listinfo);
        $cat_list = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
        foreach ($res as $index => $re) {
            if(in_array($index, $unsetary)){
                continue;
            }
            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, $ts_ary)){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('jingyan', 'xueli'))){
                if($index=='jingyan'){
                    $__tmp = $jingyan;
                    $cs = '<select name="editform[jingyan]">';
                }elseif($index=='xueli'){
                    $__tmp = $xueli;
                    $cs = '<select name="editform[xueli]">';
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('type', 'gender','level', 'bxtype', 'unit'))){
                if($index=='type'){
                    $__tmp = $ho_need_types;
                    $cs = '<select name="editform[type]">';
                }elseif($index=='gender'){
                    $__tmp = $gender_ary;
                    $cs = '<select name="editform[gender]">';
                }elseif($index=='level'){
                    $__tmp = $alllevels;
                    $cs = '<select name="editform[level]">';
                }elseif($index=='bxtype'){
                    $__tmp = $allbaoxian;
                    $cs = '<select name="editform[bxtype]">';
                }elseif($index=='unit'){
                    $__tmp = $fwunits;
                    $cs = '<select name="editform[unit]">';
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    if($index=='level'){
                        $cs .= "<option $s value='$c_t'>{$c['name']}</option>";
                    }else{
                        $cs .= "<option $s value='$c_t'>$c</option>";
                    }
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('jineng'))){
                $__tmp = $cat_list;
                $cs = '<select name="editform[jineng][]" multiple="multiple" style="height:200px">';
                $re_tmp = explode(',', $re);
                foreach ($cat_list as $c_t => $c) {
                    $s = $extp = '';
                    $cs .= "<optgroup label='$c[name]'>";
                    foreach ($c['child'] as $vv) {
                        $s = '';
                        if(in_array($vv['id'], $re_tmp)){
                            $s = 'selected';
                        }
                        $cs .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;L$vv[name]</option>";
                    }
                    $cs .= '</optgroup>';
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($fuwu_status as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('showbm' ,'tuijian','showdis', 'selfdis', 'orderdis', 'newp', 'allow_tk','openmobile','dingjin_open','yuyue'))){
                $tp = 'radio';
            }elseif(in_array($index, array('catid'))){
                $hangye = "<select name=\"editform[catid]\" onchange='changeurl(this.value)'>";
                foreach ($cat_list as $k => $v) {
                    $hangye .= "<optgroup label='$v[name]'>";
                    foreach ($v['child'] as $vv) {
                        $s = '';
                        if($res['catid']== $vv['id']){
                            $s = 'selected';
                        }
                        $hangye .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;L$vv[name]</option>";
                    }
                    $hangye .= '</optgroup>';
                }
                $hangye .= '</select>';
                $tp = $hangye;
            }

            if(in_array($index, array('fengmian'))){
                $tp = 'filetext';
            }
            if (in_array($index, array('album'))) {
                $re = !is_array($re) ? explode("\t", $re) : $re;
                $tp = 'filetext';
                $ho_config = $_G['cache']['plugin']['xigua_ho'];
                $loopnum = $ho_config['maximg'];
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_ho($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'customtxt'){
                $tp = 'textarea';
                $cmt = lang_ho('customtxttip',0);
                showsetting(lang_ho($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_ho($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }elseif($index=='title'){
                showsetting(lang_ho('fwxm', 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }elseif($index=='uid'){
                showsetting(lang_ho('shifuuid', 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }elseif($index=='price'){
                showsetting(lang_ho('sfbz', 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }else{
                showsetting(lang_ho($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');
function changeurl(val){window.location.href = window.location.href+'&catid='+val;}
</script>
HTML;

    }else{
        $listinfo = C::t('#xigua_ho#xigua_ho_cat')->list_all(1);
        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach ($ts_ary as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }
        $jineng_str = $listwithkey = array();
        foreach ($listinfo as $index => $item) {
            $listwithkey[$item['id']] = $item;
        }
        foreach ($editform['jineng'] as $index => $item) {
            $jineng_str[] = $listwithkey[$item]['name'];
        }
        $editform['jineng'] = implode(',', $editform['jineng']);
        $editform['jineng_str'] = implode(',', $jineng_str);

        $eqdq = explode(',', $editform['areawant_str']);
        $__areawant = $areawant_str_tmp = array();
        $distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
        foreach ($distlist as $index => $item) {
            $itemname = diconv($item['name'], 'UTF-8', CHARSET);
            $areawant_str_tmp[$itemname] = $item['code'];
        }
        foreach ($eqdq as $index => $item) {
            $__areawant[$item] = $areawant_str_tmp[$item];
        }
        $editform['areawant'] = implode(',', $__areawant);

        $jntmp = explode(',', $editform['jineng_str']);

        $editform['jieshao'] = htmlspecialchars_decode($editform['jieshao']);
        foreach (array('album') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }
        if($secid>0){
            $rs = C::t('#xigua_ho#xigua_ho_fuwu')->update($secid, $editform);
            $hid = $secid;
        }else{
            $hid = C::t('#xigua_ho#xigua_ho_fuwu')->insert($editform, 1);
        }
        cpmsg(lang_ho('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu&secid=$hid", 'succeed');
    }
}else {
    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_ho#xigua_ho_fuwu')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_ho#xigua_ho_fuwu')->update($id, array( 'status' => $item['status'], 'displayorder' => $item['displayorder']));
        }
        cpmsg(lang_ho('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu&shid={$_GET['shid']}&page=$page", 'succeed');
    }
    $wherearr = array();
    if($_GET['catid']){
        $where[] = "FIND_IN_SET(".intval($_GET['catid']).", jineng)";
    }
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey(daddslashes($keyword))) {
        $wherearr[] = " (title LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR addr LIKE '%$keyword%' OR mobile LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }
    $ob = 'displayorder desc,id desc';
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_ho('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($fuwu_status as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }
    $listinfo = C::t('#xigua_ho#xigua_ho_cat')->list_all(1);
    C::t('#xigua_ho#xigua_ho_cat')->init($listinfo);
    $cat_list = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
    $check0 = $_GET['catid']?'':'selected';
    $csearch = "&nbsp;<select name=\"catid\">";
    $csearch .= "<option value=\"0\" $check0 >".lang_hb('quanbu',0)."</option>";
    foreach ($cat_list as $k => $v) {
        $check1 = $_GET['catid']==$v['id']?'selected':'';
        $csearch .= "<option value=\"$v[id]\" $check1 >$v[name]</option>";
        foreach ($v['child'] as $kk => $vv) {
            $check2 = $_GET['catid']==$vv['id']?'selected':'';
            $csearch .= "<option value=\"$vv[id]\" $check2 >&nbsp;&nbsp;$vv[name]</option>";
        }
    }
    $csearch .= '</select>';
    echo $csearch;

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu".' class="btn" >'.cplang('reset').'</a> ';
    echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}.mt3{margin-top:3px}.c9{color:#999}
.jobtit{font-size:13px;color:#369}.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;font-size:12px;border-radius:2px}
.jthumb{width:70px;height:50px}.red{color:#ff6565}.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.tyu{width:60px;display:block;color:#4caf50}.tyu.jingjia{color:#ff6565}.vdesc{max-width:250px;max-height:150px;overflow-y:auto}.priceText{color:#ff6565}.btn2{padding: 3px 5px;line-height:30px;white-space:nowrap}.btn3{background: #DADADA;color: #999;}
</style>";
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu&secid=-1\" class=\"btn bg_green\">".lang_ho('tjsp',0)."</a></div>";

    showtableheader(lang_ho('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_ho('del', 0),
        lang_ho('displayorder', 0),
        lang_ho('thumb', 0),
        lang_ho('fwxm', 0),
        lang_ho('fwms', 0),
        lang_ho('status', 0),
        lang_ho('shifu', 0),
        lang_ho('crts', 0),
        lang_ho('caozuo', 0),
    ));
    $res = C::t('#xigua_ho#xigua_ho_fuwu')->fetch_all_by_page($start_limit, $lpp, $wherearr, '*', $ob);
    $icount = C::t('#xigua_ho#xigua_ho_fuwu')->fetch_count_by_page($wherearr);

    foreach ($res as $k => $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        $mobiles = DB::fetch_all('SELECT uid,mobile,realname FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
    }
    $areawant_str = lang_ho('areawant_str',0);
    $jineng_str = lang_ho('jineng_str',0);
    $opentime = lang_ho('opentime',0);
    $sfbz = lang_ho('sfbz',0);
    $fwxm = lang_ho('fwxm',0);
    $sfyy = lang_ho('sfyy',0);
    $fuwudan = lang_ho('fuwudan',0);
    $miaoshu = lang_ho('jieshao',0);
    $gongzi = lang_ho('gongzi',0);
    $bxprice = lang_ho('bxprice',0);
    $totalprice = lang_ho('totalprice',0);
    $tlevel = lang_ho('level',0);
    $lang_r = lang_ho('r',0);
    $lang_day = lang_ho('day',0);
    foreach ($res as $v) {
        $id = $v['id'];
        $thumb = $v['album'][0] ?$v['album'][0] : avatar($v['uid'], 'middle', true);

        $img = '';
        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($fuwu_status as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';
        $digstr = $v['is_dig'] ? '<span class="dig">'.lang_ho('dig',0).'</span>' : '';

        $fuwuinfo = $v;
        $title_ext = "<ul class=\"v_mingxi cl\">
    <li><span class='c9'>$sfbz</span> <span class=\"priceText f12\">&yen; {$fuwuinfo['price']} {$fwunits[$fuwuinfo['unit']]} </span></li>
    <li><span class='c9'>$areawant_str</span> <span class=\" f12\">{$fuwuinfo['areawant_str']}</span></li>
    <li><span class='c9'>$opentime</span> <span class=\" f12\">{$fuwuinfo['opentime']}</span></li>
    <li><span class='c9'>$jineng_str</span> <span class=\" f12\">{$fuwuinfo['jineng_str']}</span></li>
    <li><span class='c9'>$sfyy</span> <span class=\" f12\">".($fuwuinfo['yuyue'] ? lang_ho('xxyy',0):lang_ho('wxyy',0))."</span></li>
    ".($fuwuinfo['dingjin_open'] ? "<li><span class='c9'>".lang_ho('djje',0)."</span> <span class=\"priceText f12\">&yen; ".$fuwuinfo['dingprice']."</span></li>" : '')."
</ul>";
        $description = '<div class="mt3 vdesc">'."<p>{$fuwuinfo['jieshao']}</p><p class=\"mt3\">$img</p></div>";

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input style='width:20px' type='text' class='txt' name='row[$id][displayorder]' value='{$v[displayorder]}' />",
            "<img src='$thumb' class='jthumb' />",
            $v['title'].
            "<p class=\"mt3\">$title_ext</p>",
            $description,
            $status_u . ' '. $digstr,
            '<p><em class="c9">'.lang_ho('username',0).' : </em>'.$users[$v['uid']]['username'].' <em>[ '.$v['uid'].' ]</em></p>'.
            ($mobiles[$v['uid']]['realname'] ? '<p class="mt3"><em class="c9">'.lang_ho('realname',0).' : </em>'.$mobiles[$v['uid']]['realname'].'</p>' : '').
            '<p class="mt3"><em class="c9">'.lang_ho('sjh',0).' : </em>'.$mobiles[$v['uid']]['mobile'].'</p>',

            '<p><em class="c9">'.lang_ho('crts',0).' : </em>'.date('Y-m-d H:i:s', $v['crts']).'</p>'.
            '<p class="mt3"><em class="c9">'.lang_ho('upts2',0).' : </em>'.date('Y-m-d H:i:s', $v['upts']).'</p>'.
            ($v['payts'] ? '<p class="mt3 c_green"><em>'.lang_ho('payts',0).' : </em>'.date('Y-m-d H:i:s', $v['payts']).'</p>':'').
            ($v['dig_endts_u'] ? '<p class="mt3"><em class="c9">'.lang_ho('dig_endts',0).' : </em>'.$v['dig_endts_u'].'</p>':'').
            '',
            '<a class=\'btn bg_green btn2\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu&secid=$id" . '">' . lang_ho('edit', 0) . '</a> '.
            (in_array($v['status'], array(1,2,3,9))&& $v['payts']>0 ? ('<a class=\'btn btn2 btn3\' href="javascript:;">' . lang_ho('tuikuan', 0) . '</a>') : ''),
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_fuwu&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
}