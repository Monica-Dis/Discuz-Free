<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<link rel="stylesheet" href="source/plugin/xigua_ho/static/join.css?{VERHASH}">
<form action="$SCRITPTNAME?id=xigua_ho&ac=join&st={$_GET['st']}" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <input name="form[stid]" value="{echo $old_data[stid]?$old_data[stid]:$_GET['st']}" type="hidden">
    <input type="hidden" id="lat" name="form[lat]" value="{$old_data['lat']}">
    <input type="hidden" id="lng" name="form[lng]" value="{$old_data['lng']}">
    <input type="hidden" id="province" name="form[province]" value="{$old_data['province']}">
    <input type="hidden" id="city" name="form[city]" value="{$old_data['city']}">
    <input type="hidden" id="district" name="form[district]" value="{$old_data['district']}">
    <input type="hidden" id="street" name="form[street]" value="{$old_data['street']}">
    <input type="hidden" id="street_number" name="form[street_number]" value="{$old_data['street_number']}">

    <div class="page__bd ">
        <!--{template xigua_hb:common_nav}-->
        <div class="bgf cl">
            <!--{if $_G['cache']['plugin']['xigua_hs']}-->
            <div class="top_tip" style="background:#fafafa">
                <!--{if $_GET['type']=='sh'}-->
                {lang xigua_ho:qyrzsf}<a class="main_color" href="$SCRITPTNAME?id=xigua_ho&ac=join&mobile=2$urlext">{lang xigua_ho:qhw}{lang xigua_ho:gr}</a>
                <!--{else}-->
                {lang xigua_ho:qyrzgr}<a class="main_color" href="$SCRITPTNAME?id=xigua_ho&ac=join&type=sh&mobile=2$urlext">{lang xigua_ho:qhw}{lang xigua_ho:qy}</a>
                <!--{/if}-->
            </div>
            <!--{else}-->
            <!--{/if}-->
        </div>
        <div class="weui-cells mt0 before_none after_none">
            <!--{if $_GET['type']=='sh'}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_ho:xz}{lang xigua_ho:qy}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input choose_ctrl" readonly name="form[shname]" type="text" value="{echo $old_data?$old_data['shname']:$sh[0]['name']}" placeholder="{lang xigua_ho:qxz}{lang xigua_ho:qy}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->
            <div class="weui-cell list4">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_ho:realname}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[realname]" value="{echo $old_data['realname']?$old_data['realname']:$lastrealname}" placeholder="{lang xigua_ho:qtxxm}">
                </div>
                <!--{if !$ho_config[hidexb]}-->
                <div class="weui-cell__ft weui-cells_radio">
                    <label class="z weui-check__label mr10" for="x11">
                        <input type="radio" class="weui-check" name="form[gender]" value="1" id="x11" <!--{if $old_data[gender]!=2}-->checked<!--{/if}-->>
                        <span class="weui-icon-checked"></span> {lang xigua_ho:gender1}
                    </label>
                    <label class="z weui-check__label" for="x12">
                        <input type="radio" class="weui-check" name="form[gender]" value="2" id="x12" <!--{if $old_data[gender]==2}-->checked<!--{/if}-->>
                        <span class="weui-icon-checked"></span> {lang xigua_ho:gender2}
                    </label>
                </div>
                <!--{/if}-->
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:mobile}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="tel" name="form[mobile]" placeholder="{lang xigua_ho:qtx}{lang xigua_ho:mobile}" value="{echo $old_data[mobile] ? $old_data[mobile] : $lastmobile}">
                </div>
            </div>
            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_ho:lxaddr}<em class="color-red">*</em></label>
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" id="location_" name="form[addr]" placeholder="{lang xigua_ho:qdjybdw}" type="text" value="{$old_data[addr]}" readonly>
                </div>
                <div class="weui-cell__ft">
                    <button class="weui-vcode-btn" id="openlocation" type="button">{lang xigua_hb:dingwei}</button>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:fwjy}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[jingyan]" type="tel" value="{$old_data['jingyan']}" placeholder="{lang xigua_ho:qtxfwjyns}">
                </div>
                <div class="weui-cell__ft">{lang xigua_ho:nian}</div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:jineng}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input id="jineng" class="weui-input" name="form[jineng]" type="text" readonly value="{$old_data[jineng_str]}" placeholder="{lang xigua_ho:qxzjineng}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:fwqy}</label></div>
                <div class="weui-cell__bd">
                    <input id="areawant" class="weui-input" name="form[areawant]" type="text" readonly value="{$old_data[areawant_str]}" placeholder="{lang xigua_ho:qxzfwqy}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <p class="cl c3">{lang xigua_ho:gzzp}
                        <span class="y c9 f12 pr2">{lang xigua_ho:gzzp_tip}</span>
                    </p>
                    <div class="weui-uploader mt10">
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1" data-maxtip="{echo str_replace('n', 1, lang_ho('zuiduozhao',0))}">
                                <!--{if $avatar}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($avatar)">
                                    <input type="hidden" name="form[avatar]" value="$avatar"/>
                                    <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/if}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if HB_INWECHAT && $config[multiupload]}-->
                                <a class="weui-uploader__input" data-name="form[avatar]"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[avatar]" type="file">
                                <!--{/if}-->
                            </div>
                            <div class="imgloading demo1">
                                <img src="source/plugin/xigua_ho/static/img/demo.png">
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <p class="cl c3">{lang xigua_ho:alzp}
                        <span class="y c9 f12 pr2">{lang xigua_ho:ksczsal}{echo str_replace('n', $ho_config['maximg'], lang_ho('zuiduozhao',0))}</span>
                    </p>
                    <div class="weui-uploader mt10">
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{$ho_config['maximg']}" data-maxtip="{echo str_replace('n', $ho_config['maximg'], lang_ho('zuiduozhao',0))}">
                                <!--{loop $old_data[album] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                                    <input type="hidden" name="form[album][]" value="$img"/>
                                    <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/loop}--></ul>
                            <div class="weui-uploader__input-box">
                                <!--{if HB_INWECHAT && $config[multiupload]}-->
                                <a class="weui-uploader__input" data-name="form[album]" data-multi="1"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <textarea class="weui-textarea" name="form[jieshao]" placeholder="{lang xigua_ho:qtxwyms}" rows="3" value="{$old_data[jieshao]}">{$old_data[jieshao]}</textarea>
                </div>
            </div>
        </div>

<!--{if $_G['cache']['plugin']['xigua_hr'] && $ho_config['mustrz']}-->
    <div class="weui-cells__title cl c6">{lang xigua_ho:grrzcl}  <!--{if $verify_data[lock]}--><em class="c9 y"> $verify_data[status_text] </em><!--{/if}--></div>
    <div class="weui-cells weui-cells_form before_none after_none">
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title c3">{lang xigua_hr:scsfz}</p>
                        <div class="weui-uploader__info f12">{lang xigua_hr:qsrscsfz}</div>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-only="1"><!--{if $verify_data[zm]}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($verify_data[zm])"><input type="hidden" name="form[zm][]" value="$verify_data[zm]"/></li>
                            <!--{/if}-->
                        </ul>
                        <div class="weui-uploader__input-box">
                            <!--{if (HB_INWECHAT&&$config[multiupload]) }-->
                            <a class="weui-uploader__input" data-name="form[zm]" type="file"></a>
                            <!--{else}-->
                            <input class="weui-uploader__input" data-name="form[zm]" type="file">
                            <!--{/if}-->
                        </div>
                        <div class="imgloading">
                            <img class="demo1" src="source/plugin/xigua_hr/static/demo.jpg" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title c3">{lang xigua_hr:sfzfm}</p>
                        <div class="weui-uploader__info f12">{lang xigua_hr:qsrsfzfm}</div>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-only="1"><!--{if $verify_data[fm]}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($verify_data[fm])"><input type="hidden" name="form[fm][]" value="$verify_data[fm]"/></li>
                            <!--{/if}-->
                        </ul>
                        <div class="weui-uploader__input-box">
                            <!--{if (HB_INWECHAT&&$config[multiupload]) }-->
                            <a  class="weui-uploader__input" data-name="form[fm]" type="file"></a>
                            <!--{else}-->
                            <input  class="weui-uploader__input" data-name="form[fm]" type="file">
                            <!--{/if}-->
                        </div>
                        <div class="imgloading">
                            <img class="demo1" src="source/plugin/xigua_hr/static/demo2.jpg" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<!--{/if}-->
    </div>
    <label class="weui-agree mt10" onclick='$("#agree__text").popup();'>
        <input id="weuiAgree" type="checkbox" checked="checked" disabled readonly class="weui-agree__checkbox">
        <span class="weui-agree__text"> {lang xigua_hb:agree}<a href="javascript:void(0);" >{lang xigua_hb:xiyi1}</a> </span>
    </label>
    <div class="footer_fix"></div>
    <div class="fix-bottom">
        <!--{if $ho_config['rzfy']>0 && !$old_data}-->
        <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_ho:zf} {$ho_config['rzfy']}{lang xigua_ho:yuan} {lang xigua_ho:ruzhu}">
        <!--{else}-->
        <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_ho:queding}">
        <!--{/if}-->
    </div>
    <!--{template xigua_ho:popup}-->
</form>
<div class="masker masker1" onclick='$(".choose_ctrl").select("close")'></div>
<div id="agree__text" class="weui-popup__container" style="z-index:1000;">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <article class="weui-article">
                <h1>{lang xigua_hb:xiyi}</h1>
                <section>
                    $ho_config[xieyi]
                </section>
            </article>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:woyi}</a>
        </div>
    </div>
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<!--{eval $tabbar=0;$ho_tabbar=0;}-->
<!--{template xigua_hb:enter_up}-->
<!--{template xigua_ho:footer}-->
<!--{template xigua_ho:location_js}-->
<script>
$(document).on('click','#jineng', function () {
    var popcm =$('#popup_jineng');
    popcm.popup();
    popcm.show();
    setTimeout(function(){
        popcm.show();
    }, 500);
    return false;
});
$(document).on('click','#areawant', function () {
    var popcm =$('#popup_areawant');
    popcm.popup();
    popcm.show();
    setTimeout(function(){
        popcm.show();
    }, 500);
    return false;
});
var itar = [];
<!--{loop $sh $_sh}--><!--{if $_sh[name]}-->
itar.push({title:'{$_sh[name]}'});
<!--{/if}--><!--{/loop}-->
$(".choose_ctrl").select({
    title: "{lang xigua_ho:qxz}{lang xigua_ho:qy}",
    items: itar,
    onOpen:function () {
        $('.masker1').fadeIn();
    },
    beforeClose:function () {
        $('.masker1').fadeOut(300);
        return true;
    }
});
<!--{if $_GET['type']=='sh' && !$sh}-->
$.modal({
    autoClose:false,
    title: "{lang xigua_ho:mykysj}",
    text: '{lang xigua_ho:nkyxz}',
    buttons: [
    { text: "{lang xigua_ho:rzgrsf}", className: "default", onClick: function(){hb_jump('$SCRITPTNAME?id=xigua_ho&ac=join');}},
    { text: "{lang xigua_ho:rzsj}", onClick: function(){hb_jump("$SCRITPTNAME?id=xigua_hs&ac=enter&mobile=2{$urlext}&backto=$backto");}}
]});
<!--{/if}-->
</script>