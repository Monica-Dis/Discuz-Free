<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="popup_jineng" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_ho:wc}</a>
                <h1 class="title">{lang xigua_ho:qxzjineng}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="border_bottom post_com_tag post-tags cl" id="p1"><!--{loop $old_data['jineng_ary'] $_k $_v}--><a id="id_p1{$_v}" data-form="jineng" data-ld="p1" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">{$old_data['jineng_str_ary'][$_k]}<input name="form[jineng][]" type="hidden" value="$_v"></a><!--{/loop}--></div>
            <div class="pupc-btm">
                <div class="pupc-btm-in">
                    <!--{loop $jsary $_k $_v}-->
                    <a class="border_bottom check1 <!--{if $_k==0}-->main_color<!--{/if}-->" data-title="{$_v[id]}" data-titfix="p1_" >{$_v[oname]}</a>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left">
                    <!--{loop $jsary $_k $_v}-->
                    <div class="pupc-btm-in_list <!--{if $_k>0}-->none<!--{/if}-->" id="p1_{$_v[id]}">
                        <!--{loop $_v[child] $__v}-->
                        <a class="check2 pupc_check_a border_bottom" data-max="{echo $ho_config[maxjineng]-1}" data-maxtip="{lang xigua_ho:zd}{$ho_config[maxjineng]}{lang xigua_ho:g}" data-form="jineng" data-ld="p1" data-title="p1{$__v[id]}" data-value="{$__v[id]}">{$__v[oname]}</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
    </div>
</div><div id="popup_areawant" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_ho:wc}</a>
                <h1 class="title">{lang xigua_ho:qxzfwqy}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="border_bottom post_com_tag post-tags cl" id="p2"><!--{loop $old_data['areawant_ary'] $_k $_v}--><a id="id_p2{$_v}" data-form="areawant" data-ld="p2" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">{$old_data['areawant_str_ary'][$_k]}<input name="form[areawant][]" type="hidden" value="$_v"></a><!--{/loop}--></div>
            <div class="pupc-btm">
                <div class="pupc-btm-in">
                    <!--{loop $distjsary $_k $_v}-->
                    <a class="border_bottom check1 <!--{if $_k==0}-->main_color<!--{/if}-->" data-title="{$_v[id]}" data-titfix="p2_" >{echo diconv($_v[name], 'UTF-8', CHARSET)}</a>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left">
                    <!--{loop $distjsary $_k $_v}-->
                    <div class="pupc-btm-in_list <!--{if $_k>0}-->none<!--{/if}-->" id="p2_{$_v[id]}">
                        <a class="check2 pupc_check_a border_bottom" data-name="{echo diconv($_v[name], 'UTF-8', CHARSET)}" data-max="{echo $ho_config[maxareawant]-1}" data-maxtip="{lang xigua_ho:zd}{$ho_config[maxareawant]}{lang xigua_ho:g}" data-form="areawant" data-ld="p2" data-title="p2{$_v[id]}" data-value="{$_v[id]}">{lang xigua_hb:quan}{echo diconv($_v[name], 'UTF-8', CHARSET)} <i class="iconfont icon-coordinates_fill f14 "></i></a>
                        <!--{loop $_v[sub] $__v}-->
                        <!--{eval $__name = diconv($__v[name], 'UTF-8', CHARSET);}-->
                        <a class="check3 pupc_check_a border_bottom" data-name="$__name" data-max="{echo $ho_config[maxareawant]-1}" data-maxtip="{lang xigua_ho:zd}{$ho_config[maxareawant]}{lang xigua_ho:g}" data-form="areawant" data-ld="p2" data-title="p2{$__v[id]}" data-value="{$__v[id]}">$__name</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left none" id="distbox"></div>
            </div>
        </div>
    </div>
</div>
<script>
$(document).on('click','.check1', function () {
    var that = $(this);
    that.siblings().removeClass('main_color');
    that.addClass('main_color');
    that.parent().parent().find('.pupc-btm-in_list').hide();
    $('#'+that.data('titfix')+that.data('title')).show();
});
$(document).on('click','.check2', function(){
    var that = $(this);
    var dt = that.data('title'),dv = that.data('value'), tame = that.html();
    if(that.data('name')){
        tame = that.data('name');
    }
    if(that.data('max') && $('#'+that.data('ld')).find('a').length> that.data('max')){
        $.toast( that.data('maxtip'), 'error');
        return false;
    }
    <!--{if $need_to_jump}-->
    var newUrl= window.location.href+'&catid='+that.data('value');
    history.replaceState(null,null,newUrl);
    window.location.reload();
    return false;
    <!--{/if}-->
    $('#id_'+dt).remove();
    $('#'+that.data('ld')).append('<a id="id_'+dt+'" data-ld="'+that.data('ld')+'" data-form="'+that.data('form')+'" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">'+tame+'<input name="form['+that.data('form')+'][]" type="hidden" value="'+dv+'" /></a>');
    sync_formid(that.data('ld'), that.data('form'));
});
$(document).on('click','.post_com_tag .weui-btn_default', function () {
    var that = $(this);
    that.remove();
    sync_formid(that.data('ld'), that.data('form'));
});
function sync_formid(apend, dform){
    var val = '';
    $('#'+apend).find('a').each(function () {  val+=',' + $(this).text(); });
    $('#'+dform).val(val.substr(1));
}
$(document).on('click','.check3', function(){
    var that = $(this);
    $.ajax({type: 'GET',url: _APPNAME + '?id=xigua_ho&ac=dist_li&name='+that.data('name')+'&ctid='+that.data('value')+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('#distbox').html(s).removeClass('none');
        }
    });
});
</script>