<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="weui-navbar__item weui_bar__item_on index_ti"> <span>{$indexmod['hylist']}</span></div>
<!--{eval
C::t('#xigua_ho#xigua_ho_cat')->init($allcat);
$cat_tree_init = $cat_tree = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
$cat_tree = array_values($cat_tree);
$hy_num = 3;
}-->
<!--{if $cat_tree}--><div class="hylist">
<!--{loop $cat_tree $cat}-->
<div>
<div class="weui-grids weui-grids-min">
<a href="$SCRITPTNAME?id=xigua_ho&ac=cat&cat_id={$cat[id]}" class="weui-grid w100">
<div class="hytit weui-flex">
<img src="{$cat[icon]}" />
<span class="f15 c3">{$cat[name]}</span>
</div>
</a>
</div>
<div class="weui-grids weui-grids-min">
<!--{eval $cat[child] = array_values($cat[child]);}-->
<!--{loop $cat[child] $k $suncat}-->
<a href="$SCRITPTNAME?id=xigua_ho&ac=cat&cat_id={$suncat[id]}" class="weui-grid" style="width:{echo intval(100/$hy_num)}%">
<div class="pr">
<span class="f14 c3">$suncat[name]</span>
</div>
</a>
<!--{if $k && ($k+1)%$hy_num==0}-->
</div>
<div class="weui-grids weui-grids-min"><!--{/if}-->
<!--{/loop}--></div>
</div>
    <!--{/loop}-->
</div><!--{/if}-->