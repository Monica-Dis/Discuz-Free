<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<div class="page__bd ">
<div>
    <div class="shifu_top">
        <div class="weui-cells mt0 before_none after_none">
            <div class="weui-cell aib">
                <div class="weui-cell__hd mr10">
                    <a href="javascript:;"><img src="{avatar($v['uid'], 'middle', 1)}" class="v_head shif_face" id="shottag_head"></a>
                </div>
                <div class="weui-cell__bd">
                    <a class="c3 f15" href="javascript:;">{$v['member'][username]}</a>
                    <!--{if $v[is_dig]}-->
                    <div class="mod-lv is-star ml0">{lang xigua_ho:dig}</div>
                    <!--{/if}-->
                    <div class="secp">
                        <div class="shifu_type jbtn main_color"><a href="javascript:;">{$catinfo[name]}</a></div>
                    </div>
                </div>
                <div class="weui-cell_ft">
                    <span class="c9 f12 inblock">{$v[upts_u]} {lang xigua_ho:pub}</span>
                </div>
            </div>
        </div>
        <div class="weui-cells need_vlist">
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:xuqiu}</label>
                </div>
                <div class="weui-cell__bd">
                    <p class="main_color">$v[title]<!--{if !$catinfo[hideyg]}--> / $v[neednum]{lang xigua_ho:ren} / $v[needays]{lang xigua_ho:day}<!--{/if}--></p>
                </div>
            </div>
            <!--{loop $v[vars] $_k $_v}-->
            <!--{if $_v}-->
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>$_v[title]</label>
                </div>
                <div class="weui-cell__bd">
                    <p><!--{if is_numeric($_v[html])&&strlen($_v[html])==11}--><a href="tel:$_v[html]">$_v[html]</a>
                    <!--{else}-->$_v[html]<!--{/if}--></p>
                </div>
            </div>
            <!--{/if}-->
            <!--{/loop}-->
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:level}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>{$alllevels[$v['level']]['name']}</p>
                </div>
            </div>
            <div class="weui-cell h20">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:xqzj}</label>
                </div>
                <div class="weui-cell__bd">
                    <!--{if $v['type']=='yikou'}-->
                    <p class="priceText">&yen; {echo floatval($v[totalprice]);}</p>
                    <!--{else}-->
                    <p class="priceText">{lang xigua_ho:qbj}</p>
                    <!--{/if}-->
                </div>
                <!--{if $v['type']=='yikou'}-->
                <div class="weui-cell__ft rightarrow rightarrow_gray">{lang xigua_ho:mx}</div>
                <!--{/if}-->
            </div>
            <ul class="v_mingxi cl">
                <li><span>{lang xigua_ho:gongzi}</span> <span class="priceText f12">&yen; $v[gongzi]</span></li>
                <li><span>{lang xigua_ho:bxprice}</span> <span class="priceText f12">&yen; $v[bxprice]</span></li>
                <li><span>{lang xigua_ho:totalprice}</span> <span class="priceText f12">&yen; $v[totalprice]</span></li>
            </ul>
        </div>
        <div class="weui-cells wxts">
            <a class="weui-cell" href="plugin.php?id=xigua_hj">
                <div class="weui-cell__hd f14 c3">{lang xigua_ho:wxts}</div>
                <div class="weui-cell__bd c8">
                    <p>{lang xigua_ho:mfan}</p>
                </div>
                <div class="weui-cell__ft tc">
                    <i class="main_color iconfont icon-jubao2"></i>
                    <p class="main_color">{lang xigua_ho:ts}</p>
                </div>
            </a>
        </div>
        <div class="weui-cells need_vlist">
            <!--{if $v[addr]}-->
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>$ddname</label>
                </div>
                <div class="weui-cell__bd">
                    <p>$v[addr]</p>
                </div>
            </div>
            <!--{/if}-->
            <div class="weui-cell aib">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:xqms}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>{eval echo hb_nl2br($v[description])}</p>
                </div>
            </div>
            <!--{if $v[album]}-->
            <div class="weui-cell aib">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:xqzp}</label>
                </div>
                <div class="weui-cell__bd">
                    <div class="cl feed-preview-pic"><!--{loop $v[album] $img}--><span class="imgloading"><img src="$img"></span><!--{/loop}--></div>
                </div>
            </div>
            <!--{/if}-->
            <!--{if $_G['cache']['plugin']['xigua_ho'][mkey] && $v[lng]}-->
            <div class="vmap" id="v_openlocation_ho" data-lat="$v[lat]" data-lng="$v[lng]" data-name="$v[title]" data-addr="$v[addr]">
                <img src="https://apis.map.qq.com/ws/staticmap/v2/?center={$v[lat]},{$v[lng]}&zoom=15&size=640*320&maptype=roadmap&markers=size:large|color:0xFFCCFF|{$v[lat]},{$v[lng]}
&key={$_G['cache']['plugin']['xigua_ho'][mkey]}" />
            </div>
            <!--{/if}-->
        </div>
    </div>
<!--{if $v[type]!='yikou' && $ho_config['showjjjl']}-->
<div class="weui-cells__title c3 cl">{lang xigua_ho:jjjl}
<!--{if $isme}-->
    <a class="y" href="$SCRITPTNAME?id=xigua_ho&ac=needlog&needid=$v[id]">{lang xigua_ho:ckbj}{lang xigua_ho:xq}</a>
<!--{/if}-->
</div>
<div class="weui-cells need_vlist">
<!--{if $neelogs}-->
    <!--{loop $neelogs $_k $_v}-->
    <div class="weui-cell">
        <div class="weui-cell__hd">
            <label class="cjlab"><img src="{$_v[shifu][avatar]}" /> {$_v[shifu][realname]}</label>
        </div>
        <div class="weui-cell__bd">
            <p class="c8">{$_v[crts_u]}</p>
        </div>
        <div class="weui-cell__ft priceText">
            <p class="f14">{$_v[chujia]}{lang xigua_ho:yuan}</p>
        </div>
    </div>
    <!--{/loop}-->
<!--{else}-->
    <div class="weui-cell">
        <div class="weui-cell__bd c8">
            <p>{lang xigua_ho:zwjj}</p>
        </div>
    </div>
<!--{/if}-->
</div>
<!--{/if}-->
    </div>
    <div class="bottom_fix"></div>

    <!--{if $is_mine}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right">
            <a href="$SCRITPTNAME?id=xigua_ho&high=0" class="jv_viewbtn border_right">{lang xigua_ho:index}</a>
        </div>
        <!--{if $v[status]==9}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right offline_btn" data-needid="$v[id]" data-xiajia="0">{lang xigua_ho:sjia}</a>
        </div>
        <!--{else}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right offline_btn" data-needid="$v[id]" data-xiajia="1">{lang xigua_ho:xjia}</a>
        </div>
        <!--{/if}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right refresh_btn" data-needid="$v[id]">{lang xigua_ho:shuaxin}</a>
        </div>
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right dig_btn" data-needid="$v[id]">{lang xigua_ho:dig}</a>
        </div>
    </div>
    <!--{else}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right">
            <a href="$SCRITPTNAME?id=xigua_ho&high=0" class="jv_viewbtn border_right">{lang xigua_ho:index}</a>
        </div>
        <!--{if $v[bxtype]>0}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right f12"><i class="iconfont icon-yanzheng color-good f12"></i>{lang xigua_ho:ygmbz}</a>
        </div>
        <!--{else}-->
        <!--{/if}-->
        <div class="weui-flex__item in_bottom_y">
            <!--{if $neelog}-->
            <a href="javascript:;" class="jv_viewbtn disabled">{lang xigua_ho:need_status4}</a>
            <!--{elseif $v[status]!=2}-->
            <a href="javascript:;" class="jv_viewbtn disabled">$need_status[$v[status]]</a>
            <!--{else}-->
<!--{if !$hasq}-->
    <!--{if $v['type']=='yikou'}-->
    <a href="javascript:;" class="jv_viewbtn jv_qiang" data-needid="$v[id]">{lang xigua_ho:wyqd}</a>
    <!--{else}-->
    <a href="javascript:;" class="jv_viewbtn jv_baojia" data-needid="$v[id]">{lang xigua_ho:wybj}</a>
    <!--{/if}-->
<!--{else}-->
    <a href="$SCRITPTNAME?id=xigua_ho&ac=order" class="jv_viewbtn" >{lang xigua_ho:yjd}</a>
<!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
    <!--{/if}-->
</div>
<!--{if $v[type]!='yikou'}-->
<div id="baojia_ctrl" style="z-index:999" class="weui-popup__container popup-bottom">
    <form  action="$SCRITPTNAME?id=xigua_ho&ac=com&do=baojia&st={$_GET['st']}" method="post" id="form">
        <input name="formhash" value="{FORMHASH}" type="hidden">
        <input name="inajax" value="1" type="hidden">
        <input name="needid" value="$needid" type="hidden">
        <div class="weui-popup__overlay"></div>
        <div class="weui-popup__modal">
            <div class="toolbar">
                <div class="toolbar-inner">
                    <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:quxiao}</a>
                    <h1 class="title">{lang xigua_ho:wybj}</h1>
                </div>
            </div>
            <div class="modal-content">
                <div class="weui-cells before_none after_none">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:xuqiu}</label></div>
                        <div class="weui-cell__bd">
                            <p class="main_color">$v[title]<!--{if !$catinfo[hideyg]}--> / $v[neednum]{lang xigua_ho:ren} / $v[needays]{lang xigua_ho:day}<!--{/if}--></p>
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:baojia}</label></div>
                        <div class="weui-cell__bd">
                            <input name="baojia" class="weui-input" type="tel" placeholder="{lang xigua_hb:qtx}{lang xigua_ho:bjje}" value="">
                        </div>
                        <div class="weui-cell__ft color-red2">{lang xigua_ho:yuan}</div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:note}</label></div>
                        <div class="weui-cell__bd">
                            <input name="beizhu" class="weui-input" type="text" placeholder="{lang xigua_hb:qtx}{lang xigua_ho:note}" value="">
                        </div>
                    </div>
                </div>
                <div class="fix-bottom" style="position: relative">
                    <input type="submit" id="dosubmit" href="javascript:;" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}">
                </div>
            </div>
        </div>
    </form>
</div>
<!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_ho']['logo']}--><div class="hide none"><img src="{$_G['cache']['plugin']['xigua_ho']['logo']}" /></div><!--{/if}-->
<!--{eval $ho_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_ho:footer}--><!--{eval $jdmzsm = str_replace("'", '', ($ho_config['jdmzsm']));$jdmzsm=str_replace(array("\n","\r"),'', $jdmzsm);}--><script>
$(document).on('click','.jv_baojia', function () { $('#baojia_ctrl').popup().show();});
$(document).on('click','.jv_qiang', function () {
    var that = $(this);
    var needid = that.data('needid');
    $.modal({
    title: "<div class=\"tuan_recommend_title\"><span class=\"tuan_recommend_title_text\">{lang xigua_ho:mzsm}</span></div>",
    text: '{$jdmzsm}',
    buttons: [
        { text: "{lang xigua_ho:guanbi}", className: "default", onClick: function(){ }},
        { text: "{lang xigua_ho:tongyi}", onClick: function(){
            $.ajax({
                type: 'post',
                url: _APPNAME +'?id=xigua_ho&ac=com&do=qiangdan&inajax=1',
                data: {'formhash':FORMHASH, 'needid':needid},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {}
            });
        }}
    ]});
});</script>
<!--{template xigua_ho:haibao}-->