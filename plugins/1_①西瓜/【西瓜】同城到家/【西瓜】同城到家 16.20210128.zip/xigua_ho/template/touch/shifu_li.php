<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?><?php exit('xigua_hb');?>
<!--{loop $list $v}-->
<div class="weui-cell shifu_li aib shifu_jump" data-shifuid="{$v[id]}">
    <div class="weui-cell__hd">
        <img src="{$v[avatar]}" onerror="this.error=null;this.src='source/plugin/xigua_ho/static/img/dftava.png'" />
    </div>
    <div class="weui-cell__bd" style="max-width: calc(100% - 4.5rem);">
<h4 class="shifuname">{$v[realname]}
<!--{if $v[shid]}-->
<a href="javascript:;" class="btnsha btnsha_qiye" style="right: auto;top: 6px;margin-left: -8px;">{lang xigua_ho:qy}</a>
<!--{else}-->
<a href="javascript:;" class="btnsha" style="right: auto;top: 6px;margin-left: -8px;">{lang xigua_ho:gr}</a>
<!--{/if}-->
<a href="javascript:;" class="level level_inline level{echo $v[level]+1}"></a></h4>
<!--{if dstrlen($v[realname])<=16}-->
<!--{if $_GET['orderby']=='newest'}-->
<span class="shifu_jingyan c8">{$v[crts_u]}{lang xigua_ho:ruzhu}</span>
<!--{elseif $v[distance]}-->
<span class="shifu_jingyan c8">$v[distance]</span>
<!--{elseif $_GET['orderby']=='jiedannum'}-->
<span class="shifu_jingyan c8">{lang xigua_ho:yjd}: $v[jiedannum]</span>
<!--{else}-->
<span class="shifu_jingyan c8">{lang xigua_ho:short_jingyan}{$v[jingyan]}{lang xigua_ho:nian}<!--{if $gender_ary[$v['gender']]}-->/{$gender_ary[$v['gender']]}<!--{/if}--></span>
<!--{/if}-->
<!--{/if}-->
    <!--{if 0}-->
        <div class="cl f12 c3 mt5">
            <p class="z mr10">{lang xigua_ho:yfd} : {$v['fadannum']}{lang xigua_ho:g}</p>
            <p class="z">{lang xigua_ho:yjd} : {$v['jiedannum']}{lang xigua_ho:g}</p>
        </div>
        <div class="cl f13 weui-cells before_none shifli_new">
            <div class="weui-cell before_none">
                <div class="weui-cell__hd c8 mr8">{lang xigua_ho:jineng_str}</div>
                <div class="weui-cell__bd c3">{$v[jineng_str]}</div>
            </div>
            <div class="weui-cell before_none">
                <div class="weui-cell__hd c8 mr8">{lang xigua_ho:lxdh}</div>
                <div class="weui-cell__bd c3">{$v[mobile]}</div>
            </div>
            <div class="weui-cell weui-cell_access before_none">
                <div class="weui-cell__hd c8 mr8"><!--{if $v[addr]||!$v[areawant_str]}-->{lang xigua_ho:lxaddr}<!--{else}-->{lang xigua_ho:fwqy}<!--{/if}--></div>
                <div class="weui-cell__bd">
                    <div class="pr35 c3"><!--{if $v[addr]||!$v[areawant_str]}-->{$v[city]}{$v[addr]}<!--{else}-->{$v[areawant_str]}<!--{/if}--></div>
                    <!--{if $v[lat]}-->
                    <img class="mapicon" style="right:0" src="https://apis.map.qq.com/ws/staticmap/v2/?center={$v[lat]},{$v[lng]}&zoom=15&size=79*79&maptype=roadmap&markers=size:small|color:0xFFCCFF|{$v[lat]},{$v[lng]}
&key={$_G['cache']['plugin']['xigua_ho'][mkey]}" onerror="this.error=null;this.style.display='none';" />
                    <!--{/if}-->
                </div>
                <div class="weui-cell__ft"></div>
            </div>
        </div>
    <!--{else}-->
        <div>
            <ul class="hrlist cl">
                <!--{if $veris1[$v[uid]]}--><li><i class="iconfont icon-erified"></i> {lang xigua_ho:shiming}</li><!--{/if}-->
                <!--{if $v[shid] && $veris2[$v[uid]]}--><li><i class="iconfont icon-yanzheng"></i> {lang xigua_hr:qy}</li><!--{/if}-->
                <!--{if $bao[$v[uid]]}--><li><i class="iconfont icon-yongjin2"></i> {$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</li><!--{/if}-->
            </ul>
        </div>
        <!--{if $ho_config[xqstyle]==2}-->
        <div class="cl xqstyle2">
            <p class="lh18"><!--{if $v[distance]||!$v[areawant_str]}-->{$v[city]}{$v[addr]}<!--{else}-->{$v[areawant_str]}<!--{/if}--></p>
            <p class="cl"><!--{loop $v[jineng_str_ary] $_k $_v}--><span class="tagshif">$_v</span><!--{/loop}--></p>
        </div>
        <!--{else}-->
        <div class="cl mt10 c3 f13">
            <!--{if $v[addr]||!$v[areawant_str]}-->
            <p><span class="c8">{lang xigua_ho:lxaddr}: </span> {$v[city]}{$v[addr]}</p>
            <!--{else}-->
            <p><span class="c8">{lang xigua_ho:fwqy}: </span> {$v[areawant_str]}</p>
            <!--{/if}-->
            <p><span class="c8">{lang xigua_ho:jineng_str}: </span> {$v[jineng_str]}</p>
        </div>
        <!--{/if}-->
    <!--{/if}-->
    </div>
</div>
<!--{/loop}-->