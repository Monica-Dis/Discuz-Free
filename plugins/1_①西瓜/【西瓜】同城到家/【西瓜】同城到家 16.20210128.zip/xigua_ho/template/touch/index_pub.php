<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="weui-flex index_join">
    <!--{if $ho_config[indexbtnac]==1}-->
    <a class="weui-flex__item" href="javascript:;" id="faxuqiu">{lang xigua_ho:fbxq}<em></em></a>
    <!--{elseif $ho_config[indexbtnac]==2}-->
    <a class="weui-flex__item" href="$SCRITPTNAME?id=xigua_ho&ac=need&type=yikou{$urlext}">{lang xigua_ho:fbxq}<em></em></a>
    <!--{else}-->
    <a class="weui-flex__item" href="$SCRITPTNAME?id=xigua_ho&ac=need&type=jingjia{$urlext}">{lang xigua_ho:fbxq}<em></em></a>
    <!--{/if}-->
    <a class="weui-flex__item" href="$SCRITPTNAME?id=xigua_ho&ac=join{$urlext}">{lang xigua_ho:fwzrz}<em></em></a>
</div>
