<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<style>
    .cl1 li {
        display: block;
        background: #e0e0e0;
        width: 33.3333333%;
        float: left;
        text-align: center;
        color: #000;
        height: 2.5rem;
        line-height: 2.5rem;
    }
    .cl1 li.active{
        background:#fff;
    }
</style>
<div class="index_card" style="
    position: relative;
    top: -2rem;
    margin-bottom: -2rem;
    font-size: .8rem;">
    <ul class="cl cl1">
        <!--{loop $jing_list $_k $_v}-->
        <li data-id="{$_v[id]}" class="click_li <!--{if $_k==0}--> active<!--{/if}-->">{$_v[name]}</li>
        <!--{/loop}-->
    </ul>
    <!--{loop $jing_list $_k $_v}-->
    <div class="click_show" id="click_show_{$_v[id]}">
        <!--{loop $allcat_index[$_v[id]] $__k $__v}-->
        <div class="chip ">
            <div>
                <p><img src="{echo $__v[icon]?$__v[icon]:'source/plugin/xigua_hb/static/img/icon.png'}"><a href="$SCRITPTNAME?id=xigua_ho&ac=cat&cat_id={$__v[id]}">{$__v[name]}</a></p>
            </div>
        </div>
        <!--{/loop}-->
    </div>
    <!--{/loop}-->

</div>

<div class="index_bar cl" style="
    top: 0;
">
    <div class="search_tool" style="
    box-shadow: none;
    background: #e0e0e0;
    width: calc(100% - 1.5rem);
    margin: 1rem 0;
    /* left: auto; */
    position: relative;
"><a href="javascript:;">$ho_config['schtxt']</a></div>
</div>
<script>
$(document).on('click','.click_li', function () {
    var that = $(this);
    $('.click_show').hide();
    $('#click_show_'+that.data('id')).show();
    $('.click_li').removeClass('active');
    that.addClass('active');
});
$('.click_li:first-child').trigger('click');
</script>