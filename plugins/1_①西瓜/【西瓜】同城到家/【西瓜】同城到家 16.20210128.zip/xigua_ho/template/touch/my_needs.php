<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_ho&ac=my_needs" class="weui-navbar__item <!--{if !$_GET[type]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_ho:qb}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_ho&ac=my_needs&type=yikou" class="weui-navbar__item <!--{if $_GET[type]=='yikou'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_ho:yikou}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_ho&ac=my_needs&type=jingjia" class="weui-navbar__item <!--{if $_GET[type]=='jingjia'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_ho:jingjia}</span>
        </a>
    </div>
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->
    <a href="javascript:;" class="float_btn main_bg" style="z-index:0" id="faxuqiu"><i class="iconfont icon-zengjia f14"></i>{lang xigua_ho:fbxq}</a>
</div>
<script>
var loadingurl = window.location.href+'&ac=need_li&is_my=1&inajax=1&page=';scrollto = 0;
</script>
<!--{eval $tabbar=0;$job_tabbar=0;}-->
<!--{template xigua_ho:footer}-->