<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?><?php exit('xigua_hb');?>
<!--{loop $list $v}--><!--{if $v[needid]}-->
<!--{eval
$needinfo = unserialize($v[needinfo]);
$album = explode("\t", $needinfo[album]);
$album = $album[0]?$album[0]:avatar($needinfo[uid], 'middle', 1);
$hideyg = DB::result_first('select hideyg from %t where id = %d', array('xigua_ho_cat', $needinfo[catid] ));
}--><div class="ho_order_li mt10">
    <div class="weui-cell weui-cell_access aib before_none after_none jump_need" data-id="$v[needid]">
        <div class="weui-cell__hd">
            <label class="weui-label ho_avatar" >
                <img src="{$album}" />
                <a href="javascript:;" class="shifu_type jbtn main_color mt10">{$short_need_types[$v[type]]}</a>
            </label>
        </div>
        <div class="weui-cell__bd ho_order_li_info">
            <p class="main_color">$needinfo[title] <!--{if !$hideyg}-->/ $needinfo[neednum]{lang xigua_ho:ren} / $needinfo[needays]{lang xigua_ho:day}<!--{/if}--></p>
            <p><span>{lang xigua_ho:fdr}: </span>{$v['need_username']}</p>
            <!--{if $needinfo[addr]}-->
            <p><span>{lang xigua_ho:fuwu}{lang xigua_ho:addr}: </span>{$needinfo[city]}{$needinfo[dist]}{$needinfo[addr]}</p>
            <!--{/if}-->
            <p class="mt5"><span>{lang xigua_ho:jdr}: </span>{$shifus[$v[uid]][realname]} <em class="c3">[{$shifus[$v[uid]][level_str]}]</em></p>
            <p><span>{lang xigua_ho:jdsj}: </span>{$v[crts_u]}</p>
            <p><span>{lang xigua_ho:upts2}: </span>{$v[upts_u]}</p>
            <!--{if $v[beizhu]}-->
            <p><span>{lang xigua_ho:note}: </span>{$v[beizhu]}</p>
            <!--{/if}-->
        </div>
        <div class="weui-cell__ft"></div>
    </div>
    <div class="weui-cell after_none">
        <div class="weui-cell__bd f12">
            <!--{if $v[type]=='yikou'}-->
            <span>{lang xigua_ho:gongzi}</span> <span class="priceText f12">&yen; $needinfo[gongzi]</span>
            <!--{if $needinfo[bxprice]>0}-->
            <span>{lang xigua_ho:bxprice}</span> <span class="priceText f12">&yen; $needinfo[bxprice]</span>
            <!--{/if}-->
            <span>{lang xigua_ho:totalprice}</span> <span class="priceText f12">&yen; $needinfo[totalprice]</span>
            <!--{else}-->
            <span>{lang xigua_ho:bjje}</span> <span class="priceText f12">&yen; $v[chujia]</span>
            <!--{if $v[payts]}-->
            <span>{lang xigua_ho:yzfje}</span> <span class="priceText f12">&yen; $v[chujia]</span>
            <!--{/if}-->
            <!--{/if}-->
        </div>
        <div class="weui-cell__ft">
            <span class="f12 c3">{$needlog_status[$v[status]]}</span>
        </div>
    </div>
<!--{if $ispuber && $v[status]!=2}-->
<div class="weui-cell after_none"><div class="weui-cell__bd f12">
    <div class="z">
    <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn shifu_jump" data-shifuid="{$shifus[$v[uid]][id]}">{lang xigua_ho:chsf}</a>
    <a href="tel:{$shifus[$v[uid]][mobile]}" class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_ho:dhlx}</a>
    <!--{if $v[status]==-1}-->
        <!--{if $v[type]=='yikou'}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn confirm_order" data-title="{lang xigua_ho:qddd}" data-text="{lang xigua_ho:qdjdr}{$shifus[$v[uid]][realname]}{lang xigua_ho:ddd}?<br>{lang xigua_ho:qdhbrhqx}" data-needlogid="{$v[id]}">{lang xigua_ho:qddd}</a>
        <!--{elseif $v[type]=='jingjia'}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn confirm_pay_order" data-title="{lang xigua_ho:qddd}" data-text="{lang xigua_ho:qdjdr}{$shifus[$v[uid]][realname]}{lang xigua_ho:dddbzf}?<br>{lang xigua_ho:qdhbrhqx}" data-needlogid="{$v[id]}">{lang xigua_ho:qddd}</a>
        <!--{/if}-->
    <!--{/if}-->
    </div>
    <div class="y">
        <!--{if $v[status]==-1}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn confirm_cancel" data-title="{lang xigua_ho:qxdd}" data-text="{lang xigua_ho:queding}{lang xigua_ho:quxiao}{lang xigua_ho:jdr}{$shifus[$v[uid]][realname]}{lang xigua_ho:ddd}?" data-needlogid="{$v[id]}">{lang xigua_ho:quxiao}</a>
        <!--{/if}-->
        <!--{if $v[status]==1}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn confirm_complete" data-title="{lang xigua_ho:qdwg}" data-text="{lang xigua_ho:qdwg}{lang xigua_ho:jdr}{$shifus[$v[uid]][realname]}{lang xigua_ho:ddd}?<br>{lang xigua_ho:qdhtgzr}" data-needlogid="{$v[id]}">{lang xigua_ho:qdwg}</a>
        <!--{/if}-->
        <!--{if $v[status]==3 && $_G['cache']['plugin']['xigua_dp']}-->
        <a href="$SCRITPTNAME?id=xigua_dp&ac=add&type=ho&typeid={$v[uid]}_{$v[id]}" class="weui-btn weui-btn_mini hm_c_btn confirm_dp"><!--{if !$dps[$v[uid].'_'.$v[id]]}-->{lang xigua_ho:ljpj}<!--{else}-->{lang xigua_ho:ypj}<!--{/if}--></a>
        <!--{/if}-->
    </div>
</div></div>
<!--{elseif !$ispuber && in_array($v[status], array(-1,1,3))}-->
<div class="weui-cell after_none"><div class="weui-cell__bd f12">
    <div class="z">{lang xigua_ho:fdrqrwcfw}</div>
    <div class="y">
        <!--{if $v[status]==-1}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn confirm_cancel" data-title="{lang xigua_ho:qxdd}" data-text="{lang xigua_ho:queding}{lang xigua_ho:quxiao}{lang xigua_ho:jdr}{$shifus[$v[uid]][realname]}{lang xigua_ho:ddd}?" data-needlogid="{$v[id]}">{lang xigua_ho:quxiao}</a>
        <!--{/if}-->
        <!--{if strpos($v[kefulink], $v['mobile'])===false}-->
        <a href="tel:$v['mobile']" class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_ho:dh}</a>
        <!--{/if}-->
        <a href="{$v[kefulink]}" class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_ho:lxfdr}</a>
    </div>
</div></div>
<!--{/if}-->
</div>
<!--{elseif $v[fuwuid]}-->
<!--{eval
$fuwuinfo = unserialize($v[fuwuinfo]);
$album = unserialize($fuwuinfo[album]);
$album = $album[0]?$album[0]:avatar($fuwuinfo[uid], 'middle', 1);
}--><div class="ho_order_li mt10">
    <div class="weui-cell weui-cell_access aib before_none after_none jump_fuwu" data-id="$v[fuwuid]">
        <div class="weui-cell__hd">
            <label class="weui-label ho_avatar" >
                <img src="{$album}" />
                <a href="javascript:;" class="shifu_type jbtn main_color mt10">{lang xigua_ho:fuwudan}</a>
            </label>
        </div>
        <div class="weui-cell__bd ho_order_li_info">
            <p class="main_color">$fuwuinfo[title]</p>
            <p><span>{lang xigua_ho:xdr}: </span>{$v['need_username']}</p>
            <p><span>{lang xigua_ho:areawant_str}: </span>{$fuwuinfo['areawant_str']}</p>
            <p><span>{lang xigua_ho:jineng_str}: </span>{$fuwuinfo['jineng_str']}</p>
            <p><span>{lang xigua_ho:opentime}: </span>{$fuwuinfo['opentime']}</p>
            <p><span>{lang xigua_ho:jdr}: </span>{$shifus[$v[uid]][realname]} <em class="c3">[{$shifus[$v[uid]][level_str]}]</em></p>
            <p><span>{lang xigua_ho:jdsj}: </span>{$v[crts_u]}</p>
            <p><span>{lang xigua_ho:upts2}: </span>{$v[upts_u]}</p>
            <!--{if $v[payts]}-->
            <p><span>{lang xigua_ho:payts}: </span>{echo date('Y-m-d H:i', $v['payts']);}</p>
            <!--{/if}-->
            <!--{if $v[beizhu]}-->
            <p><span>{lang xigua_ho:note}: </span>{$v[beizhu]}</p>
            <!--{/if}-->
        </div>
        <div class="weui-cell__ft"></div>
    </div>
    <div class="weui-cell after_none">
        <div class="weui-cell__bd f12">
            <span>{lang xigua_ho:sfbz}</span> <span class="priceText f12">&yen; $fuwuinfo[price] {$fwunits[$fuwuinfo[unit]]}</span>
            <!--{if $v[payts] && $fuwuinfo[dingprice]>0}-->
            <span>{lang xigua_ho:yjfdj}</span> <span class="priceText f12">&yen; $fuwuinfo[dingprice]</span>
            <!--{/if}-->
        </div>
        <div class="weui-cell__ft">
            <span class="f12 c3">{$needlog_status[$v[status]]}</span>
        </div>
    </div>
    <!--{if $ispuber && $v[status]!=2}-->
    <div class="weui-cell after_none"><div class="weui-cell__bd f12">
            <div class="z">
                <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn shifu_jump" data-shifuid="{$shifus[$v[uid]][id]}">{lang xigua_ho:chsf}</a>
                <a href="tel:{$shifus[$v[uid]][mobile]}" class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_ho:dhlx}</a>
            </div>
            <div class="y">
                <!--{if $v[status]==1}-->
                <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn confirm_cancel" data-title="{lang xigua_ho:qxdd}" data-text="{lang xigua_ho:queding}{lang xigua_ho:quxiao}{lang xigua_ho:jdr}{$shifus[$v[uid]][realname]}{lang xigua_ho:ddd}?<br>{lang xigua_ho:qxkcdj}" data-needlogid="{$v[id]}">{lang xigua_ho:quxiao}</a>
                <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn confirm_complete" data-title="{lang xigua_ho:qdwg}" data-text="{lang xigua_ho:qdwg}{lang xigua_ho:jdr}{$shifus[$v[uid]][realname]}{lang xigua_ho:ddd}?<br>{lang xigua_ho:qdhtgzr}" data-needlogid="{$v[id]}">{lang xigua_ho:qdwg}</a>
                <!--{/if}-->
                <!--{if $v[status]==3 && $_G['cache']['plugin']['xigua_dp']}-->
                <a href="$SCRITPTNAME?id=xigua_dp&ac=add&type=ho&typeid={$v[uid]}_{$v[id]}" class="weui-btn weui-btn_mini hm_c_btn confirm_dp"><!--{if !$dps[$v[uid].'_'.$v[id]]}-->{lang xigua_ho:ljpj}<!--{else}-->{lang xigua_ho:ypj}<!--{/if}--></a>
                <!--{/if}-->
            </div>
        </div></div>
    <!--{elseif !$ispuber && in_array($v[status], array(-1,1,3))}-->
    <div class="weui-cell after_none"><div class="weui-cell__bd f12">
            <div class="z">{lang xigua_ho:fdrqrwcfw}</div>
            <div class="y">
                <!--{if strpos($v[kefulink], $v['mobile'])===false}-->
                <a href="tel:$v['mobile']" class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_ho:dh}</a>
                <!--{/if}-->
                <a href="{$v[kefulink]}" class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_ho:lxfdr}</a>
            </div>
        </div></div>
    <!--{/if}-->
</div>
<!--{/if}-->
<!--{/loop}-->