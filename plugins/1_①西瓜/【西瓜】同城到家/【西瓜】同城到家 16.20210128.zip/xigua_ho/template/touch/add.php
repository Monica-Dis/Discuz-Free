<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/taocan.css?{VERHASH}" />
<link rel="stylesheet" href="source/plugin/xigua_ho/static/join.css?{VERHASH}"><style>.car-type .car-year-season{background-color:$config[maincolor];}.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}.car-type .type-item-active:after{border-color:$config[maincolor]}.car-type .type-item-active {background:{echo hb_hex2rgb($config[maincolor], 0.06)}}.weui-cells_radio .weui-check:checked+.weui-icon-checked:before{content:'\EA06';font-size:21px;display:block}.weui-cells_radio .weui-icon-checked:before{content:'\EA01';color:#c9c9c9;font-size:21px;display:block;margin:0}</style>
<div class="page__bd ">
    <form action="$SCRITPTNAME?id=xigua_ho&ac=add" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="form[old_id]" value="{$_GET[old_id]}">
        <input type="hidden" name="form[stid]" value="{$_GET[st]}">
        <input type="hidden" name="form[idu]" value="{$_GET[idu]}">
        <div class="weui-cells__title c3">$navtitle</div>
        <div class="weui-cells__title mt0">{lang xigua_ho:fwdesc}</div>
        <div class="weui-cells mt0 before_none after_none">
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:jineng}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input id="jineng" class="weui-input" type="text" readonly value="{$old_data[jineng_str]}" placeholder="{lang xigua_ho:qxzjineng}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:fwmc}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[title]" type="text" placeholder="{lang xigua_ho:qtx}{lang xigua_ho:fwmc}" value="{echo $old_data[title]?$old_data[title]: ''}">
                </div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:fwqy}</label></div>
                <div class="weui-cell__bd">
                    <input id="areawant" class="weui-input" name="form[areawant]" type="text" readonly value="{$old_data[areawant_str]}" placeholder="{lang xigua_ho:qxzfwqy}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{lang xigua_ho:sfbz}</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[price]" type="tel" placeholder="{lang xigua_ho:qtx}{lang xigua_ho:sfbz}" value="{$old_data[price]}">
                </div>
                <div class="weui-cell__ft color-red">
                    <select class="weui-select select_abs" name="form[unit]">
                        <!--{loop $fwunits $_k $_v}-->
                        <option value="{$_k}" <!--{if $old_data[unit]==$_k}-->selected<!--{/if}-->>$_v</option>
                        <!--{/loop}-->
                    </select>
                </div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_ho:opentime}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[opentime]" id="opentime" type="text" value="{echo $old_data ? $old_data[opentime] : ''}" placeholder="{lang xigua_ho:opentime_tip}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{lang xigua_ho:xxyy}</label>
                </div>
                <div class="weui-cell__bd f12 c9">{lang xigua_ho:xxyy_tip}</div>
                <div class="weui-cell__ft">
                    <input class="weui-switch" type="checkbox" name="form[yuyue]" value="1" <!--{if $old_data[yuyue]}-->checked<!--{/if}-->>
                </div>
            </div>
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{lang xigua_ho:djms}</label>
                </div>
                <div class="weui-cell__bd f12 c9">
                    {lang xigua_ho:djmsdesc}
                </div>
                <div class="weui-cell__ft">
                    <input class="weui-switch" type="checkbox" id="digmode"  name="form[dingjin_open]" value="1"  <!--{if $old_data[dingjin_open]}-->checked<!--{/if}-->>
                </div>
            </div>
            <div class="weui-cell dgmode" <!--{if !$old_data || !$old_data[dingjin_open]}-->style="display:none"<!--{/if}-->>
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{lang xigua_ho:djje}</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[dingprice]" type="tel" placeholder="{lang xigua_ho:qtx}{lang xigua_ho:djje}" value="{$old_data[dingprice]}" />
                </div>
                <div class="weui-cell__ft color-red">{lang xigua_ho:yuan}</div>
            </div>
        </div>
        <div class="weui-cells before_none after_none">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <textarea name="form[jieshao]" class="weui-textarea" placeholder="{lang xigua_ho:fuwxq}" rows="3">{$old_data[jieshao]}</textarea>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{echo intval($ho_config['maximg'])}" data-maxtip="{echo str_replace('n', $ho_config['maximg'], lang_hb('zuiduozhao',0))}" id="uploaderFiles">
                                <!--{loop $old_data[album] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) }-->
                                <a id="uploaderInput" class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1"></a>
                                <!--{else}-->
                                <input id="uploaderInput" class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <label class="weui-agree mt10" onclick='$("#agree__text").popup();'>
            <input id="weuiAgree" type="checkbox" checked="checked" disabled readonly class="weui-agree__checkbox">
            <span class="weui-agree__text"> {lang xigua_hb:agree}<a href="javascript:void(0);" >{lang xigua_ho:fbxygz}</a> </span>
        </label>
        <div class="footer_fix"></div>
        <!--{template xigua_ho:popup}-->
        <div class="fix-bottom mt10">
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hb:queding}">
        </div>
    </form>
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div id="agree__text" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <article class="weui-article">
                <h1>{lang xigua_ho:fbxygz}</h1>
                <section>
                    <section>
                        $ho_config[fbxy]
                    </section>
                </section>
            </article>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:woyi}</a>
        </div>
    </div>
</div>
<!--{eval $tabbar=0;$ho_tabbar=0;}-->
<!--{template xigua_hb:enter_up}-->
<!--{template xigua_ho:footer}-->
<!--{template xigua_ho:location_js}-->
<script>
    $(document).on('click','#jineng', function () {
        var popcm =$('#popup_jineng');
        popcm.popup();
        popcm.show();
        setTimeout(function(){
            popcm.show();
        }, 500);
        return false;
    });
    $(document).on('click','#areawant', function () {
        var popcm =$('#popup_areawant');
        popcm.popup();
        popcm.show();
        setTimeout(function(){
            popcm.show();
        }, 500);
        return false;
    });
    $(document).on('click','#digmode', function () {
        if($('#digmode:checked').length){
            $('.dgmode').show();
        }else{
            $('.dgmode').hide();
        }
    });
    $('#digmode').trigger('click').trigger('click');
    <!--{eval
    $opentime = array();
        for($i=0;$i<24;$i++):
            $opentime[] = $i.':00';
            $opentime[] = $i.':30';
        endfor;
        $opentimeend = $opentime;
        $opentime[] = '00:00';
        $opentime = json_encode($opentime);
        $opentimeend[] = '24:00';
        $opentimeend = json_encode($opentimeend);
    }-->$("#opentime").picker({
        title: "{lang xigua_ho:opentime_tip}",
        value:['8:00', '21:00'],
        formatValue: function (p, values, displayValues) {
            return values[0]+'-'+values[1];
        },
        cols: [
            {textAlign: 'center',values: $opentime},
            {divider: true, content: '-'},
            {textAlign: 'center',values: $opentimeend}
        ]
    });
</script>
