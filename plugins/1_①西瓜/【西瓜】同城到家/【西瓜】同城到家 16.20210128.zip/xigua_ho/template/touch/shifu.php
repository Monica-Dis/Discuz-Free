<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<link rel="stylesheet" href="source/plugin/xigua_ho/static/wufu.css?{VERHASH}" ><style>.need_vlist .weui-cell{align-items: normal;}</style>
<div class="page__bd ">
    <!--{template xigua_hb:common_nav}-->
    <div>
        <div class="shifu_top">
        <div class="weui-cells shifu_field">
            <div class="weui-cell aib">
                <div class="weui-cell__hd">
                    <img class="shif_face" src="{$v[avatar]}" />
                </div>
                <div class="weui-cell__bd">
                    <div style="display:flex">
                        <h4 class="shifuname" style="padding-right:0;flex:1;white-space:normal">{$v[realname]}</h4>
                        <div style="flex:1"><span class="shifu_jingyan" style="right:2.2rem">{lang xigua_ho:short_jingyan}{$v[jingyan]}{lang xigua_ho:nian}/{$gender_ary[$v['gender']]}</span>
                            <!--{if $v[shid]}-->
                            <a href="javascript:;" class="btnsha btnsha_qiye">{lang xigua_ho:qy}</a>
                            <!--{else}-->
                            <a href="javascript:;" class="btnsha">{lang xigua_ho:gr}</a>
                            <!--{/if}--></div>
                    </div>
                    <p class="level level{echo $v[level]+1} mt10">$v[level_str]</p>
                    <div>
                        <ul class="hrlist cl">
                            <!--{if $veris1[$v[uid]]}--><li><i class="iconfont icon-erified"></i> {lang xigua_ho:shiming}</li><!--{elseif !$veris2[$v[uid]]}-->
                            <li class="dishr"><!--{if $isme}--><a href="$SCRITPTNAME?id=xigua_hr&ac=join&ct=1"><i class="iconfont icon-erified"></i> {lang xigua_ho:wshiming}</a><!--{else}--><i class="iconfont icon-erified"></i> {lang xigua_ho:wshiming}<!--{/if}--></li>
                            <!--{/if}-->
                            <!--{if $v[shid] && $veris2[$v[uid]]}--><li><i class="iconfont icon-yanzheng"></i> {lang xigua_hr:qy}</li><!--{/if}-->
                            <!--{if $bao[$v[uid]]}--><li><i class="iconfont icon-yongjin2"></i> {$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</li><!--{/if}-->
                        </ul>
                    </div>
                    <div class="cl mt10 c3 f12">
                        <p class="z mr10">{lang xigua_ho:yfd}:{$fadanshu}{lang xigua_ho:g}</p>
                        <p class="z">{lang xigua_ho:yjd}:{$jiedanshu}{lang xigua_ho:g}</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="weui-cells need_vlist">
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:jineng_str}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>$v[jineng_str]</p>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:fwqy}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>$v[areawant_str]</p>
                </div>
            </div>
            <!--{if $sh}-->
            <a  href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]" class="weui-cell weui-cell_access">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:shid}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>$sh[name]</p>
                </div>
                <div class="weui-cell__ft"></div>
            </a>
            <!--{/if}-->
            <a href="javascript:;" class="weui-cell weui-cell_access" id="v_openlocation_ho" data-lat="$v[lat]" data-lng="$v[lng]" data-name="$v[realname]" data-addr="$v[addr]">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:lxaddr}</label>
                </div>
                <div class="weui-cell__bd">
                    <div class="pr35">{$v[city]}{$v[addr]}</div>
                    <img class="mapicon" src="https://apis.map.qq.com/ws/staticmap/v2/?center={$v[lat]},{$v[lng]}&zoom=15&size=79*79&maptype=roadmap&markers=size:small|color:0xFFCCFF|{$v[lat]},{$v[lng]}
&key={$_G['cache']['plugin']['xigua_ho'][mkey]}" onerror="this.error=null;this.style.display='none';" />
                </div>
                <div class="weui-cell__ft"></div>
            </a>
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:lxdh}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>$v[showtel] <span class="f12 c9">({$ho_config[laizi]})</span></p>
                </div>
            </div>
        </div>
        </div>
        <!--{if $v[jieshao]}-->
        <div class="jv_desc weui-cells before_none after_none">
            <h2 class="h2top">{lang xigua_ho:jieshao}</h2>
            <div>{eval echo hb_nl2br($v[jieshao])}</div>
        </div>
        <!--{/if}-->
        <!--{if $fuwus}-->
        <div class="jv_desc weui-cells before_none after_none">
            <h2 class="h2top">{lang xigua_ho:fuwun}</h2>
            <div class="swiper-container coupon_swiper swiper-container-horizontal">
                <div class="swiper-wrapper">
                    <!--{loop $fuwus $_k $_v}-->
                    <div class="swiper-slide seclight_box swiper-slide-active">
                        <a href="$SCRITPTNAME?id=xigua_ho&ac=fuwu&fuwuid={$_v[id]}">
                            <div class="pr">
                                <!--{if $_v[yuyue]}--><em class="mia2_">{lang xigua_ho:xyy}</em><!--{/if}-->
                                <img class="seclight_img" src="{$_v[album][0]}">
                            </div>
                            <div class="p1">{$_v['title']}</div>
                            <div class="p2">
                                <!--{if $_v[dingjin_open] && $_v[dingprice]}-->
                                <span class="color-sec"><em class="f16">{$_v[dingprice]}</em><em class="f12">{lang xigua_hb:yuan}</em></span>
                                <em class="sp_bubble">{lang xigua_ho:dj}</em>
                                <!--{else}-->
                                <span class="color-sec"><em class="f16">{$_v[price]}</em><em class="f12">{$fwunits[$_v['unit']]}</em></span>
                                <!--{/if}-->
                            </div>
                        </a>
                    </div>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <!--{/if}-->

        <!--{if $v[album]}-->
        <div class="jv_desc weui-cells before_none after_none">
            <h2 class="h2top">{lang xigua_ho:alzp}</h2>
            <div class="cl feed-preview-pic"><!--{loop $v[album] $img}--><span class="imgloading"><img src="$img"></span><!--{/loop}--></div>
        </div>
        <!--{/if}-->
        <div class="weui-cells wxts">
            <a class="weui-cell" href="$SCRITPTNAME?id=xigua_hj">
                <div class="weui-cell__hd f14 c3">{lang xigua_ho:wxts}</div>
                <div class="weui-cell__bd c6">
                    <p class="color-red2">{lang xigua_ho:wxts2}</p>
                    <p class="c9">{lang xigua_ho:wxts1}</p>
                </div>
                <div class="weui-cell__ft tc">
                    <i class="main_color iconfont icon-jubao2"></i>
                    <p class="main_color">{lang xigua_hj:wyjb}</p>
                </div>
            </a>
        </div>
<!--{if $_G['cache']['plugin']['xigua_dp']}-->
<style>.gzbtn{background-color:$config[maincolor]}.gzbtn{display:none}.dp_jx_title .weui_title span {font-size: 16px;color: #333}</style><div id="ptdiv2" style="display:none"></div>
<script>
$.ajax({type: 'get',dataType: 'xml',
url: '$SCRITPTNAME?id=xigua_dp&ac=jingxuan&inajax=1&type=ho&typelike=$v[uid]_0&pagesize=5&page=1',
success: function (data) {
if(null==data){ $('#ptdiv2').remove(); return false;}
var s = data.lastChild.firstChild.nodeValue;
if(!s){ $('#ptdiv2').remove(); return false;}
$('head').append('<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?{VERHASH}" />');
$('body').append('<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"><\/script>');
$('#ptdiv2').html(s).show();
},
error: function () {$('#ptdiv2').remove();}
});
</script>
<!--{/if}-->
    </div>
    <div class="cl bottom_fix"></div>
    <!--{if $isme}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right">
            <a href="$SCRITPTNAME?id=xigua_ho&ac=index" class="jv_viewbtn border_right">{lang xigua_ho:index}</a>
        </div>
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right hbtn_share">{lang xigua_ho:share}</a>
        </div>
        <div class="weui-flex__item in_bottom_y">
            <a href="$SCRITPTNAME?id=xigua_ho&ac=join&mobile=2" class="jv_viewbtn">{lang xigua_hb:edit}</a>
        </div>
    </div>
    <!--{else}-->
<!--{if $ho_config[shifurz]}--><!--{eval $widthnew ='style="width:20%"';}--><!--{/if}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right" $widthnew>
            <a href="$SCRITPTNAME?id=xigua_ho&ac=index" class="jv_viewbtn border_right">{lang xigua_ho:index}</a>
        </div>
        <div class="in_bottom_z border_right" $widthnew>
            <a href="javascript:;" class="jv_viewbtn border_right hbtn_share">{lang xigua_ho:share}</a>
        </div>
        <!--{if $widthnew}-->
        <div class="in_bottom_z border_right" $widthnew>
            <a href="$SCRITPTNAME?id=xigua_ho&ac=join" class="jv_viewbtn border_right">{lang xigua_ho:ruzhu}</a>
        </div>
        <!--{/if}-->
        <!--{if $v[mobile] && !$ho_config[showsx]}-->
        <div class="weui-flex__item in_bottom_y">
            <a href="tel:{$v[mobile]}" class="jv_viewbtn">{lang xigua_ho:dhzx}</a>
        </div>
        <!--{else}--><!--{eval include DISCUZ_ROOT.'source/plugin/xigua_ho/include/c_shifu_ext.php'}-->
        <div class="weui-flex__item in_bottom_y">
            <a href="$kflnk" class="jv_viewbtn">{lang xigua_ho:ljlx}</a>
        </div>
        <!--{/if}-->
    </div>
    <!--{/if}-->
</div>
<!--{if $_G['cache']['plugin']['xigua_ho']['logo']}--><div class="hide none"><img src="{$_G['cache']['plugin']['xigua_ho']['logo']}" /></div><!--{/if}-->
<!--{eval $ho_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_ho:footer}--><script>if($('.coupon_swiper').length>0){var coupon_swiper = new Swiper('.coupon_swiper', {slidesPerView: 'auto',paginationClickable: true,spaceBetween: 0});}</script>
<!--{template xigua_ho:haibao}-->