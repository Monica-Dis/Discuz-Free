<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">

            <input name="id" value="xigua_ho" type="hidden">
            <input name="ac" value="order" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">

            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_ho:ddhsp}" data-hold="{lang xigua_ho:qtx}{lang xigua_ho:ddhsp}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_ho:ddhsp}</span>
            </label>
        </form>
        <a href="javascript:" class="search_bar_btn main_color" id="dosearch">{lang xigua_ho:search}</a>
        <a href="$SCRITPTNAME?id=xigua_ho&ac=order{$mang}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_ho:qx}</a>
    </div>

    <div class="weui-navbar after_none">
        <a href="$SCRITPTNAME?id=xigua_ho&ac=order&keyword=$keyword{$mang}" class="weui-navbar__item <!--{if !$_GET[status]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_ho:qb}</span>
        </a>
        <!--{loop $needlog_status $_k $_v}-->
        <a href="$SCRITPTNAME?id=xigua_ho&ac=order&keyword=$keyword&status=$_k{$mang}" class="weui-navbar__item <!--{if $_GET[status]==$_k}-->weui_bar__item_on<!--{/if}-->">
            <span>{$_v}</span>
        </a>
        <!--{/loop}-->
    </div>
    <div  id="list" class="weui-cells p0 mt0 before_none after_none" style="background:transparent"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>
var loadingurl = window.location.href+'&ac=order_li&inajax=1&page=';
var noTit = true;
$(document).on('click','#dosearch', function () {
    if($('#searchInput').val()){
        $('#dosearchform').submit();
    }else{
        $.alert($('#searchInput').attr('placeholder'));
    }
});
</script>
<!--{eval $ho_tabbar=1;$tabbar=0;}-->
<!--{template xigua_ho:footer}-->