<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<!--{eval
if($catinfo[pubtype]):
    if($catinfo[pubtype]=='yikou' && $_GET[type]!='yikou'):
        dheader("Location: $SCRITPTNAME?id=xigua_ho&ac=need&catid=$_GET[catid]&type=yikou$urlext");
    endif;
    if($catinfo[pubtype]=='jingjia' && $_GET[type]!='jingjia'):
        dheader("Location: $SCRITPTNAME?id=xigua_ho&ac=need&catid=$_GET[catid]&type=jingjia$urlext");
    endif;
endif;
}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/taocan.css?{VERHASH}" />
<link rel="stylesheet" href="source/plugin/xigua_ho/static/join.css?{VERHASH}"><style>.car-type .car-year-season{background-color:$config[maincolor];}.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}.car-type .type-item-active:after{border-color:$config[maincolor]}.car-type .type-item-active {background:{echo hb_hex2rgb($config[maincolor], 0.06)};}.weui-cells_radio .weui-check:checked+.weui-icon-checked:before{content:'\EA06';font-size:21px;display:block}.weui-cells_radio .weui-icon-checked:before{content:'\EA01';color:#c9c9c9;font-size:21px;display:block;margin:0}</style>
<div class="page__bd ">
    <form action="$SCRITPTNAME?id=xigua_ho&ac=need" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="form[type]" value="{$_GET[type]}">
        <input type="hidden" name="form[catid]" value="{$_GET[catid]}">
        <input type="hidden" name="form[st]" value="{$_GET[st]}">
        <input type="hidden" name="form[idu]" value="{$_GET[idu]}">
        <input type="hidden" id="location_lat" name="form[lat]" value="{$old_data[lat]}">
        <input type="hidden" id="location_lng" name="form[lng]" value="{$old_data[lng]}">
        <input type="hidden" id="dist1" name="form[dist1]" value="{$old_data[dist1]}">
        <input type="hidden" id="dist2" name="form[dist2]" value="{$old_data[dist2]}">
        <input type="hidden" id="dist3" name="form[dist3]" value="{$old_data[dist3]}">
        <input type="hidden" id="addr" name="form[addr]" value="{$old_data[addr]}">
        <div class="weui-cells__title c3">$navtitle</div>
        <div class="weui-cells__title mt0"><!--{if $canprice}-->{lang xigua_ho:yikou_tip}<!--{else}-->{lang xigua_ho:jingjia_tip}<!--{/if}--></div>
        <div class="weui-cells mt0 before_none after_none">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:xuqiumoshi}<em class="color-red">*</em></label></div>
                <div class="cl weui-cells_radio c3">
                    <label class="z weui-check__label mr10 <!--{if $catinfo[pubtype]&& $catinfo[pubtype]!='yikou'}-->none<!--{/if}-->" for="O11">
                        <input type="radio" class="weui-check formtype" value="yikou" id="O11" <!--{if $_GET['type']=='yikou'}-->checked<!--{/if}-->><span class="weui-icon-checked pr-1"></span> {lang xigua_ho:yikou_short}
                    </label> <label class="z weui-check__label <!--{if $catinfo[pubtype]&& $catinfo[pubtype]!='jingjia'}-->none<!--{/if}-->" for="O12">
                        <input type="radio" class="weui-check formtype" value="jingjia" id="O12" <!--{if $_GET['type']=='jingjia'}-->checked<!--{/if}-->><span class="weui-icon-checked pr-1"></span> {lang xigua_ho:jingjia_short}
                    </label>
                </div>
            </div>
            <!--{if !$ho_config[fbzj]}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:jineng}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input id="jineng" class="weui-input" type="text" readonly value="{$catinfo[name]}" placeholder="{lang xigua_ho:qxzjineng}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:xqmc}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[title]" type="text" placeholder="{lang xigua_ho:qtx}{lang xigua_ho:xqmc}" value="{echo $old_data[title]?$old_data[title]: $catinfo['name']}">
                </div>
            </div>
<!--{loop $he_vars $__k $var}--><!--{eval
$bd_title = $var[title];
$formfix = 'form[vars_0]';
if(!$var[placehd]):
    $var[placehd] = (in_array($var['type'], array('number', 'text','textarea')) ? lang_ho('qtx',0) : lang_ho('qxz',0)).$bd_title;
endif;
}-->
            <!--{if $var['type']=='number'}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">$bd_title<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="$formfix[{$var[pluginvarid]}]" type="tel" placeholder="{$var[placehd]}" value="{$var[extra]}">
                </div>
                <!--{if $var[unitnew]}--><div class="weui-cell__ft">$var[unitnew]</div><!--{/if}-->
            </div>
            <!--{elseif $var['type']=='text'}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">$bd_title<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="$formfix[{$var[pluginvarid]}]" type="text" placeholder="{$var[placehd]}" value="{$var[extra]}">
                </div>
                <!--{if $var[unitnew]}--><div class="weui-cell__ft">$var[unitnew]</div><!--{/if}-->
            </div>
            <!--{elseif $var['type']=='textarea'}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <textarea class="weui-textarea" name="$formfix[{$var[pluginvarid]}]" placeholder="{$var[placehd]}" rows="3" value="{$var[extra]}">{$var[extra]}</textarea>
                </div>
            </div>
            <!--{elseif $var['type']=='datetime'}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{$bd_title}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" id="datetime_picker_{$__k}_{$var[pluginvarid]}" name="$formfix[{$var[pluginvarid]}]" type="text" placeholder="{$var[placehd]}" value="{$var[extra]}">
                    <script>$("#datetime_picker_{$__k}_{$var[pluginvarid]}").datetimePicker();</script>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{elseif $var['type']=='date'}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{$bd_title}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" id="date_picker_{$__k}_{$var[pluginvarid]}" name="$formfix[{$var[pluginvarid]}]" type="text" placeholder="{$var[placehd]}" value="{$var[extra]}">
                    <script>$("#date_picker_{$__k}_{$var[pluginvarid]}").calendar();</script>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{elseif $var['type']=='select'}-->
            <!--{eval $extra = trim($var[extra]);$extra = explode("\n", $extra);}-->
            <div class="weui-cell weui-cell_select weui-cell_select-after">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{$bd_title}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label>
                </div>
                <div class="weui-cell__bd">
                    <select class="weui-select" name="$formfix[{$var[pluginvarid]}]">
                        <!--{loop $extra $extra_string}-->
                        <!--{eval list($tmp1, $tmp2) = explode('=', trim($extra_string));}-->
                        <option value="$tmp1" <!--{if {$old_data[vars][$var[pluginvarid]][value]}==$tmp1}-->selected="selected"<!--{/if}-->>$tmp2</option>
                        <!--{/loop}-->
                    </select>
                </div>
            </div>
            <!--{elseif $var['type']=='selects'}-->
            <!--{eval $extra = trim($var[extra]);$extra = explode("\n", $extra);}-->
            <div class="weui-cell weui-cell_select weui-cell_select-after">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{$bd_title}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label>
                </div>
                <div class="weui-cell__bd">
                    <select multiple="multiple" class="weui-select" name="$formfix[{$var[pluginvarid]}][]" <!--{if $old_data && $var[unchangeable]}-->disabled="disabled"<!--{/if}--> >
                    <!--{loop $extra $extra_string}-->
                    <!--{eval list($tmp1, $tmp2) = explode('=', trim($extra_string));}-->
                    <option value="$tmp1" <!--{if in_array($tmp1, $old_data[vars][$var[pluginvarid]][value]) }-->selected="selected"<!--{/if}-->>$tmp2</option>
                    <!--{/loop}-->
                    </select>
                </div>
            </div>
            <!--{elseif $var['type']=='pics'}-->
            <!--{eval $var[placehd] = intval( $var[placehd]);}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{$bd_title}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></p>
                            <div class="weui-uploader__info">{echo $var[placehd] ? str_replace('n', $var[placehd], lang_hb('zuiduozhao',0)) : ''}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{$var[placehd]}" data-maxtip="{echo str_replace('n', $var[placehd], lang_ho('zuiduozhao',0))}">
                                <!--{loop $old_data[album] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                                    <input type="hidden" name="$formfix[{$var[pluginvarid]}][]" value="$img"/>
                                    <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if HB_INWECHAT && $config[multiupload]}-->
                                <a class="weui-uploader__input" data-name="$formfix[{$var[pluginvarid]}]" data-multi="1"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="$formfix[{$var[pluginvarid]}]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--{elseif $var[type]=='location'}-->
            <!--{eval $defaultvalue = $old_data?$old_data[vars][$var[pluginvarid]][value][0]:'';$needpopmap = 1;}-->
            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label">{$bd_title}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label>
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" id="location_{$var[pluginvarid]}" name="$formfix[{$var[pluginvarid]}][]" type="text" placeholder="{$var[placehd]}" value="{$defaultvalue}" readonly="readonly">
                    <input type="hidden" id="location_lat_{$var[pluginvarid]}" name="$formfix[{$var[pluginvarid]}][]" value="{$old_data[vars][$var[pluginvarid]][value][1]}">
                    <input type="hidden" id="location_lng_{$var[pluginvarid]}" name="$formfix[{$var[pluginvarid]}][]" value="{$old_data[vars][$var[pluginvarid]][value][2]}">
                </div>
                <div class="weui-cell__ft">
                    <button class="weui-vcode-btn openlocation" data-id="{$var[pluginvarid]}" type="button">{lang xigua_hb:dingwei}</button>
                </div>
            </div>
            <!--{elseif $var[type]=='area'}-->
            <!--{eval $defaultvalue = $old_data?$old_data[vars][$var[pluginvarid]][value]:$defaultcty;}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{$bd_title}<!--{if $var[required]}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input area_field" name="$formfix[{$var[pluginvarid]}]" <!--{if $old_data && $var[unchangeable]}-->readonly="readonly"<!--{/if}--> id="city_picker_{$var[pluginvarid]}" type="text" placeholder="{$var[placehd]}" value="{$defaultvalue}">
                    <script>+function($){$.rawCitiesData = $cityjson;}($);</script>
                    <script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
                    <script>$("#city_picker_{$var[pluginvarid]}").cityPicker({title: "{lang xigua_hb:qingxuan}{$var[title]}"});</script>
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->
    <!--{/loop}-->
            <div class="weui-cell <!--{if $catinfo[hideyg]}-->none<!--{/if}-->">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:neednum}<em class="color-red">*</em></label></div>
                <div class="weui-cell__ft">
                    <div class="weui-count">
                        <a class="weui-count__btn weui-count__decrease"></a>
                        <input class="weui-count__number" name="form[neednum]" type="tel" value="1" />
                        <a class="weui-count__btn weui-count__increase"></a>
                    </div>
                </div>
            </div>
            <div class="weui-cell <!--{if $catinfo[hideyg]}-->none<!--{/if}--> <!--{if !$canprice}-->border_bottom15<!--{/if}-->">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_ho:needays}<em class="color-red">*</em></label></div>
                <div class="weui-cell__ft">
                    <div class="weui-count">
                        <a class="weui-count__btn weui-count__decrease"></a>
                        <input class="weui-count__number" name="form[needays]" type="tel" value="1" />
                        <a class="weui-count__btn weui-count__increase"></a>
                    </div>
                </div>
            </div>
            <div class="weui-cell <!--{if !$catinfo[hidelevel]}-->border_bottom15<!--{/if}--> <!--{if !$canprice}-->none<!--{/if}-->">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{lang xigua_ho:price_}</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[price]" type="tel" placeholder="{lang xigua_ho:qtx}{lang xigua_ho:price_}" value="">
                </div>
                <div class="weui-cell__ft color-red">{lang xigua_ho:yuan}</div>
            </div>
            <div class="weui-cells__title c3 <!--{if $catinfo[hidelevel]}-->none<!--{/if}-->">{lang xigua_ho:xzsfjb}</div>
            <div class="cl car-type car-typefor <!--{if $catinfo[hidelevel]}-->none<!--{/if}-->">
                <div class="type-item-box">
                    <!--{loop $alllevels $___k $___v}-->
                    <label for="s_{$___k}" class="type-item J_ping <!--{if $___k==-1}-->type-item-active<!--{else}-->type-item-gray<!--{/if}-->">
                        <input type="radio" class="none" name="form[level]" value="{echo $___k}" id="s_{$___k}" <!--{if $___k==-1}-->checked="checked"<!--{/if}-->>
                        <div class="type-title">{$___v[name]}</div>
                        <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
                    </label>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <div class="weui-cells before_none after_none <!--{if $catinfo[hidetext]&&$catinfo[hidepic]}-->none<!--{/if}-->">
            <div class="weui-cell <!--{if $catinfo[hidetext]}-->none<!--{/if}-->">
                <div class="weui-cell__bd">
                    <textarea name="form[description]" class="weui-textarea" placeholder="{lang xigua_ho:qsrms}" rows="3">$old_data[description]</textarea>
                </div>
            </div>
            <div class="weui-cell <!--{if $catinfo[hidepic]}-->none<!--{/if}-->">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{echo intval($ho_config['maximg'])}" data-maxtip="{echo str_replace('n', $ho_config['maximg'], lang_hb('zuiduozhao',0))}" id="uploaderFiles">
                                <!--{loop $old_data[album] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) }-->
                                <a id="uploaderInput" class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1"></a>
                                <!--{else}-->
                                <input id="uploaderInput" class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--{if !$old_data && $canprice && $baoxian}-->
        <div class="weui-cells__title">{lang xigua_ho:gmbz}</div>
        <div id="dftvip" class="cl car-type">
            <div class="type-item-box">
                <!--{loop $allbaoxian $___k $___v}-->
                <label for="s{$___k}" class="type-item J_ping <!--{if $___k==-1}-->type-item-active<!--{else}-->type-item-gray<!--{/if}-->">
                    <input type="radio" class="none" name="form[bxtype]" value="{echo floatval($___v[price])}" data-size="{echo floatval($___v[price])}" id="s{$___k}" <!--{if $___k==-1}-->checked="checked"<!--{/if}-->>
                    <div class="type-title">{$___v[name]}</div>
                    <div class="car-sku-year cl">
                        <div class="type-discount">
                            <span class="car-price">{echo floatval($___v[price])}</span><span class="car-unit">{lang xigua_hb:yuan}/{lang xigua_ho:r}</span>
                        </div>
                    </div>
                    <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
                </label>
                <!--{/loop}-->
            </div>
        </div>
        <div class="weui-cells mt0 after_none none">
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{lang xigua_ho:gmfs}</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[bxnum]" type="tel" placeholder="{lang xigua_ho:gmfs_tip}" value="">
                </div>
            </div>
        </div>
        <!--{/if}-->
        <label class="weui-agree mt10" onclick='$("#agree__text").popup();'>
            <input id="weuiAgree" type="checkbox" checked="checked" disabled readonly class="weui-agree__checkbox">
            <span class="weui-agree__text"> {lang xigua_hb:agree}<a href="javascript:void(0);" >{lang xigua_ho:needxieyi}</a> </span>
        </label>
        <div class="bottom_fix"></div>

        <!--{if $canprice}-->
        <div class="fix-bottom fix_next mt10" style="position:relative">
            <div class="weui-flex f15">
                <div class="weui-flex__item cl" style="padding-right: 15px;">
                    {lang xigua_ho:heji} : <span class="mony main_color">&yen; <em id="money_show">0</em></span>
                    <a class="mx">{lang xigua_ho:mx}</a>
                </div>
                <div class="weui-flex__item tc next_step main_bg">
                    <input type="submit" style="height:50px;" id="dosubmit" class="weui-btn weui-btn_primary f15" value="{lang xigua_ho:xyb}"/>
                </div>
            </div>
        </div>
        <!--{else}-->
        <div class="fix-bottom mt10">
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hb:queding}">
        </div>
        <!--{/if}-->
    </form>
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div id="agree__text" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <article class="weui-article">
                <h1>{lang xigua_ho:needxieyi}</h1>
                <section>
                    <section>
                        $ho_config[needxieyi]
                    </section>
                </section>
            </article>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:woyi}</a>
        </div>
    </div>
</div>
<div id="mx_list" class='weui-popup__container popup-bottom z501'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:close}</a>
                <h1 class="title">{lang xigua_ho:fymx}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <div class="weui-cell">
                    <div class="weui-cell__bd">{lang xigua_ho:price_}</div>
                    <div class="weui-cell__ft main_color"><em class="f12">&yen;</em> <em id="mx1">0</em></div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">{lang xigua_ho:gmbz}</div>
                    <div class="weui-cell__ft main_color"><em class="f12">&yen;</em> <em id="mx2">0</em></div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">{lang xigua_ho:heji}</div>
                    <div class="weui-cell__ft main_color"><em class="f12">&yen;</em> <em id="mx3">0</em></div>
                </div>
            </div>
        </div>
    </div>
</div>
<!--{if !$ho_config[fbzj]}--><!--{template xigua_ho:popup}--><!--{/if}-->
<!--{eval $ho_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_hb:enter_up}-->
<!--{template xigua_ho:needmap}-->
<!--{template xigua_ho:footer}-->
<script><!--{if !$ho_config[fbzj]}-->
$(document).on('click','#jineng', function () {var popcm =$('#popup_jineng');popcm.popup();popcm.show();setTimeout(function(){popcm.show();
$('.check2').each(function () {
    var that = $(this);
    if(that.text() == '{$catinfo[name]}'){
        var tindex = that.parent().index();
        $('.check1:eq('+tindex+')').trigger('click');
        console.log(tindex);
    }
});}, 500);return false;});
    <!--{/if}-->
var MAX = 99, MIN = 1;
$('.weui-count__decrease').click(function (e) {
    var input = $(e.currentTarget).parent().find('.weui-count__number');
    var number = parseInt(input.val() || "0") - 1;
    if (number < MIN) number = MIN;
    input.val(number);
    calc_money();
});
$('.weui-count__increase').click(function (e) {
    var input = $(e.currentTarget).parent().find('.weui-count__number');
    var number = parseInt(input.val() || "0") + 1;
    if (number > MAX) number = MAX;
    input.val(number);
    calc_money();
});
function calc_money(){
    var f_price = $('input[name="form[price]"]');
    var f_neednum = $('input[name="form[neednum]"]');
    var f_needays = $('input[name="form[needays]"]');
    var f_bxtype = $('input[name="form[bxtype]"]:checked');
    var _tmpv = f_price.val();
    if(!_tmpv){
        _tmpv = 0;
    }
    var _tmpv2 = parseInt(f_neednum.val()) * parseInt(f_needays.val());
    var _tmpcl = parseFloat(_tmpv) * _tmpv2;
    var _tmpbx = parseFloat(f_bxtype.data('size')) * parseInt(f_neednum.val());
    if(isNaN(_tmpbx)){
        _tmpbx = 0;
    }

    var f_price_v = parseFloat(_tmpcl + _tmpbx).toFixed(2);
    f_price_v = f_price_v.replace('.00', '');

    _tmpcl = _tmpcl.toFixed(2).replace('.00', '');
    _tmpbx = _tmpbx.toFixed(2).replace('.00', '');

    $('#money_show').html(f_price_v);
    $('#mx1').html(_tmpcl);
    $('#mx2').html(_tmpbx);
    $('#mx3').html(f_price_v);
}
$(document).on('keyup','input[name="form[price]"]', function () {
    calc_money();
});
$(document).on('click','.J_ping', function () {
    calc_money();
});
$(document).on('click','.formtype', function () {
    var noUrl = window.location.href.replace('&type=yikou', '').replace('&type=jingjia', '');
    if($(this).val()=='yikou'){
<!--{if $_GET['type']!='yikou'}-->var newUrl= noUrl+'&type=yikou';history.replaceState(null,null,newUrl);window.location.reload();return false;<!--{/if}-->
    }else{
<!--{if $_GET['type']!='jingjia'}-->var newUrl= noUrl+'&type=jingjia';history.replaceState(null,null,newUrl);window.location.reload();return false;<!--{/if}-->
    }
});
</script>
