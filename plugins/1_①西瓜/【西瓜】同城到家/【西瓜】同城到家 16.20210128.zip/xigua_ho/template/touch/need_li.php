<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $k $v}-->
<!--{if $_GET['is_my']}-->
<div class="job_li cl border_bottom">
    <div class="job_top jump_need" data-id="$v[id]">
        <h4>
            <!--{if $v[is_dig]}-->
            <span class="jbtn is_dig">{lang xigua_ho:dig}</span>
            <!--{/if}-->
            <span class="flex1">{$v[title]}</span>
            <span class="jbtn">{$v[type_u]}</span>
            <span class="jbtn jbtn_gray">{$need_status[$v[status]]}</span>
        </h4>
    </div>
    <div class="job_li_mid cl jump_need" data-id="$v[id]">
        <div class="z">
            <span class="resume_spani"> {lang xigua_ho:views} <em class="c3">{$v[views]}</em></span>
            <!--{if $v[payts]>0}-->
            <span class="resume_spani">{lang xigua_ho:ytg} <em class="main_color">&yen; $v[price]</em></span>
            <!--{/if}-->
        </div>
        <div class="y">
            <span class="resume_spani">{$v[upts_u]}{lang xigua_ho:shuaxin}</span>
        </div>
    </div>
    <!--{if $v[dig_endts_u]}-->
    <div class="job_li_mid cl">
        <div class=" f12 c9">{lang xigua_ho:dig_endts}: {$v[dig_endts_u]}</div>
    </div>
    <!--{/if}-->
<div class="job_mid cl">
    <div class="z">
<!--{if $v[status]!=-2}-->
    <!--{if $v[status]==9}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn offline_btn" data-needid="$v[id]" data-xiajia="0">{lang xigua_ho:sjia}</a>
    <!--{else}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn offline_btn" data-needid="$v[id]" data-xiajia="1">{lang xigua_ho:xjia}</a>
    <!--{/if}-->
<!--{/if}-->
    <!--{if !$loglist[$v[id]]}-->
    <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn delete_need" data-needid="$v[id]" data-title="{lang xigua_ho:del_confirm}" data-text="{lang xigua_ho:del}{$v[title]}{lang xigua_ho:sch}">{lang xigua_ho:del}</a>
        <!--{/if}-->
    <!--{if 0}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn refund_tuoguan">{lang xigua_ho:tuikuan}</a>
    <!--{/if}-->
    <!--{if $loglist[$v[id]]}-->
        <!--{if $v[type]=='yikou'}-->
            <a href="$SCRITPTNAME?id=xigua_ho&ac=needlog&needid=$v[id]"  class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_ho:ckjd}</a>
        <!--{else}-->
            <a href="$SCRITPTNAME?id=xigua_ho&ac=needlog&needid=$v[id]"  class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_ho:ckbj}</a>
        <!--{/if}-->
    <!--{/if}-->
    </div>
    <!--{if $v[status]!=-2}-->
    <div class="y">
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn1 refresh_btn" data-needid="$v[id]">{lang xigua_ho:shuaxin}</a>
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn1 dig_btn" data-needid="$v[id]">{lang xigua_ho:dig}</a>
    </div>
    <!--{/if}-->
</div>
</div>
<!--{else}-->
<div class="weui-cell need_list aib jump_need" data-id="{$v[id]}" data-lat="$v[lat]" data-lng="$v[lng]" data-addr="$v[addr]" data-title="{$v[title]}">
    <div class="weui-cell__hd">
        <img src="{echo $v[album][0]?$v[album][0]: avatar($v['uid'], 'middle', true)}" onerror="this.error=null;this.src='source/plugin/xigua_ho/static/img/dft.png'" />
        <span class="btnsha">{$short_need_types[$v[type]]}</span>
    </div>
    <div class="weui-cell__bd">
<h4>{$v[title]}<!--{if $v[is_dig]}-->
<span class="jbtn is_dig pr-1">{lang xigua_ho:dig}</span>
<!--{/if}-->
<!--{if $v[bxtype]>0}-->
<em class="f12"><i class="iconfont icon-yanzheng color-good f12"></i>{lang xigua_ho:ytb}</em>
<!--{/if}-->
<!--{if $v[type]=='yikou'}-->
<!--{if $v[distance]}-->
<span class="pcfiled">$v[distance] <em class="priceText">&yen;{echo floatval($v[totalprice]);}</em></span>
<!--{else}-->
<span class="pcfiled">{lang xigua_ho:yzf} <em class="priceText">&yen;{echo floatval($v[totalprice]);}</em></span>
<!--{/if}-->
<!--{else}-->
<!--{if $v[distance]}-->
<span class="pcfiled">$v[distance]</span>
<!--{elseif $v[status]!=4}-->
<span class="pcfiled"><em class="priceText">{lang xigua_ho:dbj}</em></span>
<!--{/if}-->
<!--{/if}--></h4>
        <div class="cl need_list_desc">
            <!--{if !$v[vars]}-->
            <p><span class="c8">{lang xigua_ho:xqms}: </span> {$v[description]}</p>
            <!--{if $v[addr]}-->
            <p><span class="c8">{lang xigua_ho:lxaddr}: </span> {$v[city]}{$v[addr]}</p>
            <!--{/if}-->
            <!--{else}-->
            <!--{loop $v[vars] $_k $_v}-->
            <p><span class="c8">{$_v[title]}: </span> {$_v[html]}</p>
            <!--{/loop}-->
            <!--{/if}-->
            <p><span class="c8">{lang xigua_ho:sfyq}: </span> {$alllevels[$v['level']]['name']}</p>
            <!--{if $_GET['orderby']=='newest'}-->
            <p class="shifu_jingyan c8">{$v[crts_u]} {lang xigua_ho:fabu}</p>
            <!--{/if}-->
        </div>
        <!--{if $v[status]==2}-->
        <!--{if $need_check[$v[id]]}-->
        <a class="xq_btn main_bg jump_need op6" data-id="{$v[id]}" href="javascript:;">{lang xigua_ho:yq}</a>
        <!--{else}-->
        <a class="xq_btn main_bg jump_need" data-id="{$v[id]}" href="javascript:;">{lang xigua_ho:qd}</a>
        <!--{/if}-->
        <!--{else}-->
        <a class="xq_btn main_bg jump_need op6" data-id="{$v[id]}" href="javascript:;">{$need_status[$v[status]]}</a>
        <!--{/if}-->
    </div>
</div>
<!--{/if}-->
<!--{/loop}-->