<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="weui-navbar__item weui_bar__item_on index_ti"> <span>{lang xigua_ho:jineng}</span></div>
<!--{loop $jing_list $_k $_v}-->
<div class="weui-cells after_none before_none index_card">
    <div class="chip-l pd0 before_none" onclick="hb_jump('$SCRITPTNAME?id=xigua_ho&ac=cat&cat_id={$_v[id]}');return false;">
        <em class="rightarrow" style="color:{$_v['color']}">{lang xigua_ho:ckqb}</em>
        <a href="javascript:;" class="bigh" style="background-image:url($_v[share_pic])"> {$_v[name]} </a>
    </div>
    <!--{loop $allcat_index[$_v[id]] $__k $__v}-->
    <div class="chip <!--{if $__k%2==1}-->chip_none<!--{/if}-->">
        <div>
            <p><img src="{echo $__v[icon]?$__v[icon]:'source/plugin/xigua_hb/static/img/icon.png'}"><a href="$SCRITPTNAME?id=xigua_ho&ac=cat&cat_id={$__v[id]}">{$__v[name]}</a></p>
        </div>
    </div>
    <!--{/loop}-->
</div>
<!--{/loop}-->