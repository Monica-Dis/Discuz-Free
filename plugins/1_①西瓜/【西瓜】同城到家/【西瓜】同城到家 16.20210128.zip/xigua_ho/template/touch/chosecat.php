<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<!--{if $ho_config[toptip]}--><div class="weui-cells__title">$ho_config[toptip]</div><!--{/if}-->
<div class="weui-cells__title c3">$navtitle</div>
<div class="weui-grids bgf weui-grids-nob">
    <!--{loop $list $cat}-->
    <a <!--{if $ho_config['numi2']!=4&&$ho_config['numi2']>0}--> {eval echo "style='width:".(100/$ho_config['numi2'])."%!important'";}<!--{/if}--> <!--{if  !$cat[cat_link]}-->onclick="return showcat('$cat[id]', '$cat[name]');"<!--{else}-->href="$cat[cat_link]"<!--{/if}--> class="weui-grid js_grid">
    <div class="weui-grid__icon">
        <img src="$cat[icon]" alt="">
    </div>
    <p class="weui-grid__label"> $cat[name] </p>
    </a>
    <!--{/loop}-->
</div>

<div class="footer_fix"></div>
<div class="bottom_fix"></div>

<script>
    var CAT = [];
<!--{loop $list $cat}-->
    <!--{loop $cat[child] $c}-->
        CAT.push({pid:'$c[pid]', id:'$c[id]', name:'$c[name]'});
    <!--{/loop}-->
    <!--{/loop}-->
    <!--{if $_GET[ct]}-->
    var ct = '';
    for(var i =0; i<CAT.length; i++){
        if(CAT[i].id=='$_GET[ct]'){
            ct = CAT[i].name
        }
    }
    showcat('$_GET[ct]', ct);
    <!--{/if}-->
    function showcat(id, name){
        var act = [];
        for(var i =0; i<CAT.length; i++){
            if(CAT[i].pid==id){
                var surl = '$SCRITPTNAME?id=xigua_ho&ac=need&type=$_GET[type]&catid='+CAT[i].id+_URLEXT;
                act.push({text: '<a class="sel_a" href="'+surl+'">'+CAT[i].name+'</a>'});
            }
        }
        console.log(act);
        if(act.length==0){
            window.location.href = '$SCRITPTNAME?id=xigua_ho&ac=need&type=$_GET[type]&catid='+id+_URLEXT;
            return false;
        }
        $.actions({
            title: '{lang xigua_ho:fabu}'+name+'',
            actions: act
        });
        return false;
    }
</script>
<!--{eval $ho_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_ho:footer}-->