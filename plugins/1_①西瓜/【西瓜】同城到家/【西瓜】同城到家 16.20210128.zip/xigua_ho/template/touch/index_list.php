<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="weui-navbar__item weui_bar__item_on index_ti"> <span>{lang xigua_ho:newestxuqiu}</span></div>
<div id="list3" class="mod-post x-postlist pt0"></div><!--{eval $index_list=1;}-->