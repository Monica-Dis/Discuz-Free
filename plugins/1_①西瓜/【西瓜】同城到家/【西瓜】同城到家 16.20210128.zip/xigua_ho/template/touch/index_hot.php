<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $jing_list}-->
<div class="weui-navbar__item weui_bar__item_on index_ti"> <span>{lang xigua_ho:rmfw}</span></div>
<nav class=" nav-list nav-list-big cl swipe" <!--{if $config[swiperbg]}-->style="background:url($config[swiperbg]); background-size:cover;background-color:#fff"<!--{/if}-->>
    <div class="swipe-wrap">
        <div>
            <ul class="cl">
                <!--{loop $jing_list $k $n}-->
                <!--{if $k && $k% ($numi1*2) ==0}-->
            </ul>
        </div>
        <div>
            <ul class="cl">
                <!--{/if}-->
                <li<!--{if $config['numi1']!=5&&$config['numi1']>0}--> {eval echo "style='width:".(100/$config['numi1'])."%'";}<!--{/if}-->>
                <a href="{echo $n['cat_link'] ? $n['cat_link'] : "$SCRITPTNAME?id=xigua_ho&ac=cat&cat_id=".$n['id']}">
                    <span>
                        <img src="$n['icon']"/>
                    </span>
                    <em class="m-piclist-title">{$n['name']}</em>
                </a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position position1">
            <!--{loop $jing_count $k $v}-->
            <li {if $k==0} class="current" {/if}></li>
            <!--{/loop}-->
        </ul>
    </nav>
</nav>
<!--{/if}-->