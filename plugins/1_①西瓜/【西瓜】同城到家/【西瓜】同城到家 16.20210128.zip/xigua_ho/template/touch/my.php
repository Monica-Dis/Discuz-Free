<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}--><link rel="stylesheet" href="source/plugin/xigua_hb/static/css/mynew.css?{VERHASH}" /><style>.x_header{position:relative}.centtop1 a i{color:{$config[maincolor]}}.centtop2 a i{color:#999}.my_new_bd .my__head_user{width:calc(100% - 30px);position: relative;margin-top: 0;}.cardstyle2{background-image:linear-gradient(135deg, $config[maincolor]d6 0,$config[maincolor] 100%);-webkit-background-image:linear-gradient(135deg, $config[maincolor]d6 0,$config[maincolor] 100%);background-color:$config[maincolor]}</style>
<!--{if $_G['cache']['plugin']['xigua_ho']['logo']}--><div class="hide none"><img src="{$_G['cache']['plugin']['xigua_ho']['logo']}" /></div><!--{/if}-->
<div class="page__bd my_new_bd">
    <div class="cardstyle2">
        <div class="cl myho_top planet-wrap">
            <div class="my__head_user z">
                <a href="javascript:;" class="my__head_avatar z"><img src="{$avatar}"></a>
                <div>
                    <!--{if $shifuis}-->
                    <a class="y f13 mt5" href="$SCRITPTNAME?id=xigua_ho&ac=shifu&shifuid={$old_data[id]}">{lang xigua_ho:grzy}<i class="f12 iconfont icon-jinrujiantou"></i></a>
                    <!--{elseif !$old_data[status]}-->
                    <a class="y f13 mt5" href="$SCRITPTNAME?id=xigua_ho&ac=join">{lang xigua_ho:cwsf}<i class="f12 iconfont icon-jinrujiantou"></i></a>
                    <!--{/if}-->
                    <div class="my__head_nickname f16">{$name} <em class="f12 op6">UID:{$_G[uid]}</em></div>
                    <!--{if $shifuis && $old_data[shid]}-->
                    <a  class="qblink mr10" href="javascript:;"><i class="iconfont icon-home_fill_light f12"></i> {lang xigua_ho:qy}</a>
                    <!--{elseif $shifuis}-->
                    <a class="qblink mr10" href="javascript:;"><i class="iconfont icon-wode1 f12"></i> {lang xigua_ho:gr}</a>
                    <!--{/if}-->
                    <!--{if $shifuis && $old_data[uid]}-->
                    <a class="qblink" href="$SCRITPTNAME?id=xigua_ho&ac=shifu&ismine=1"><i class="iconfont icon-huiyuan f12"></i> $mylevel</a>
                    <!--{else}-->
                    <a class="qblink" href="javascript:;"><i class="iconfont icon-wode1 f12"></i> {lang xigua_ho:kehuban}</a>
                    <!--{/if}-->
                </div>
            </div>
        </div>
    </div>
<!--{if $shifuis}-->
    <div class="centtop centtop1">
        <div class="weui-cells__title weui_title mt0 f15 c3">{lang xigua_ho:wdjd}
            <a class="y" href="$SCRITPTNAME?id=xigua_ho&ac=order">{lang xigua_ho:ckqb} <i class="f13 iconfont icon-jinrujiantou"></i></a>
        </div>
        <div class="cl myho_order">
            <a href="$SCRITPTNAME?id=xigua_ho&ac=order&status=-1" class="z" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-qianbao f24"></i>
                </div>
                <p class="weui-grid__label f12">{lang xigua_ho:dqr}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_ho&ac=order&status=1" class="z" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-xianshiqianggou f24"></i>
                </div>
                <p class="weui-grid__label f12">{lang xigua_ho:dfw}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_ho&ac=order&status=2" class="z" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-huodong1 f24"></i>
                </div>
                <p class="weui-grid__label f12">{lang xigua_ho:jdstatus3}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_ho&ac=order&status=3" class="z" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-ganxie1 f24"></i>
                </div>
                <!--{if $_G['cache']['plugin']['xigua_dp']}-->
                <p class="weui-grid__label f12">{lang xigua_ho:dpj}</p>
                <!--{else}-->
                <p class="weui-grid__label f12">{lang xigua_ho:needlog_status3}</p>
                <!--{/if}-->
            </a>
        </div>
    </div>
<!--{else}-->
    <div class="centtop centtop1">
        <div class="weui-cells__title weui_title mt0 f15 c3">{lang xigua_ho:wddd}
            <a class="y" href="$SCRITPTNAME?id=xigua_ho&ac=order">{lang xigua_ho:ckqb} <i class="f13 iconfont icon-jinrujiantou"></i></a>
        </div>
        <div class="cl myho_order">
            <a href="$SCRITPTNAME?id=xigua_ho&ac=order&status=-1" class="z" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-qianbao f24"></i>
                </div>
                <p class="weui-grid__label f12">{lang xigua_ho:dqr}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_ho&ac=order&status=1" class="z" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-xianshiqianggou f24"></i>
                </div>
                <p class="weui-grid__label f12">{lang xigua_ho:dfw}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_ho&ac=order&status=2" class="z" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-huodong1 f24"></i>
                </div>
                <p class="weui-grid__label f12">{lang xigua_ho:jdstatus3}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_ho&ac=order&status=3" class="z" >
                <div class="weui-grid__icon">
                    <i class="iconfont icon-ganxie1 f24"></i>
                </div>
                <!--{if $_G['cache']['plugin']['xigua_dp']}-->
                <p class="weui-grid__label f12">{lang xigua_ho:dpj}</p>
                <!--{else}-->
                <p class="weui-grid__label f12">{lang xigua_ho:needlog_status3}</p>
                <!--{/if}-->
            </a>
        </div>
    </div>
<!--{/if}-->

    <div class="centtop " style="padding-bottom: 0">
        <!--{if !$shifuis}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_ho&ac=my_needs&type=yikou&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-huojian color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_ho:wfbd}{lang xigua_ho:yikou_short}</p>
            </div>
            <div class="weui-cell__ft f15">$myneed_yikou</div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_ho&ac=my_needs&type=jingjia&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-yongjin2 color-pink"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_ho:wfbd}{lang xigua_ho:jingjia_short}</p>
            </div>
            <div class="weui-cell__ft f15">$myneed_jingjia</div>
        </a>
        <!--{/if}-->
        <!--{if $shifuis}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_ho&ac=join&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-fensiguanli color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_ho:sfxq}</p>
            </div>
            <div class="weui-cell__ft f15"><!--{if $old_data['status']==1}-->{lang xigua_ho:yrz}<!--{elseif $old_data['status']&&$old_data['status']!=1}-->{$shifu_status[$old_data[status]]}<!--{else}-->{lang xigua_ho:wrz}<!--{/if}--></div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_ho&ac=myfw&mobile=2"><!--fuwu-->
            <div class="weui-cell__hd"><i class="iconfont icon-gengduo3 color-red2"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_ho:wfbdfw}</p>
            </div>
            <div class="weui-cell__ft f15">$myfuwu</div>
        </a>
        <!--{/if}-->
        <a class="weui-cell weui-cell_access" <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jump_download();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao&mobile=2"<!--{/if}--><!--{/if}-->>
            <div class="weui-cell__hd"><i class="iconfont icon-qianbao2 color-red2"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_hb:myqb}</p>
            </div>
            <div class="weui-cell__ft f15 color-red2">&yen;{echo $qianbao[money]*100/100}</div>
        </a>
        <!--{if $_G['cache']['plugin']['xigua_hr'] && $shifuis}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hr&ac=my&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-yanzheng color-green"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_ho:wdrz}</p>
            </div>
            <div class="weui-cell__ft">
                <!--{if $veris1[$_G[uid]]}--><!--{if $_G[cache][plugin][xigua_hr][grtb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][grtb]" /> <!--{else}--><i class="iconfont icon-erified color-forest vm"></i><!--{/if}--><!--{/if}-->
                <!--{if $veris2[$_G[uid]]}--><!--{if $_G[cache][plugin][xigua_hr][qytb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][qytb]" /> <!--{else}--><i class="iconfont icon-qiyerenzheng color-blue vm"></i><!--{/if}--><!--{/if}-->
            </div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hr&ac=paybao&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-baozhengjinmoshi color-green f17"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_ho:wdbzj}</p>
            </div>
            <!--{if $bao[$_G[uid]][price]>0}-->
            <div class="weui-cell__ft f15"><span class="main_color f15">{$bao[$_G[uid]][price]}{lang xigua_hb:yuan}</span></div>
            <!--{else}-->
            <div class="weui-cell__ft f15">{lang xigua_ho:wjn}</div>
            <!--{/if}-->
        </a>
        <!--{/if}-->
        <a class="weui-cell weui-cell_access f15" href="$SCRITPTNAME?id=xigua_hb&ac=mysetxx&hide_side=1">
            <div class="weui-cell__hd"><i class="iconfont icon-weixinzhifu1 color-forest"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:xiaoxishezhi}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <!--{if $dxp}-->
        <a class="weui-cell weui-cell_access f15" href="$myzlurl">
            <div class="weui-cell__hd"><i class="iconfont icon-shouji color-red"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hb:bindmobile}</p>
            </div>
            <div class="weui-cell__ft">$muhumobile</div>
        </a>
        <!--{/if}-->
    </div>
    <div class="centtop " style="padding-bottom: 0">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=about&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-guize color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_hb:bangzhu}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
            <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_hb:kefu}</p>
            </div>
            <div class="weui-cell__ft f15">{lang xigua_hb:zhwo}</div>
        </a>
    </div>
</div>

<!--{if $old_data['status']}-->
    <!--{if $shifuis}-->
    <a class="zbf main_bg" href="$SCRITPTNAME?id=xigua_ho&ac=my&is=kehu&mobile=2{$urlext}" id="shguide">{lang xigua_ho:qhw}{lang xigua_ho:kehuban}</a>
    <!--{else}-->
    <a class="zbf main_bg" href="$SCRITPTNAME?id=xigua_ho&ac=my&is=shifu&mobile=2{$urlext}" id="shguide">{lang xigua_ho:qhw}{lang xigua_ho:shifuban}</a>
    <!--{/if}-->
<!--{/if}-->

<!--{eval $ho_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_ho:footer}-->
<script>
function jump_download() {
    $.confirm("$config[qbguide]", function() {
        window.location.href = '$config[qbguidelink]';
    }, function() {
    });
    return false;
}
</script>