<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<!--{if $_G['cache']['plugin']['xigua_ho']['logo']}--><div class="hide none"><img src="{$_G['cache']['plugin']['xigua_ho']['logo']}" /></div><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_ho']['showfz'] && $_G['cache']['plugin']['xigua_st']['showfz']}-->
<header class="x_header bgcolor_11 cl  weui-flex f15" style="background:transparent!important;position:absolute">
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_ho");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
</header>
<!--{/if}-->
<div class="page__bd bgf index_page">
<!--{eval
foreach($indexmod as $_index_index => $_index_name):
    include template('xigua_ho:index_'.$_index_index);
endforeach;
}-->
</div>
<!--{eval $ho_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_ho:footer}-->
<script>$(document).on('click','.search_tool a', function () { hb_jump('{$SCRITPTNAME}?id=xigua_ho&ac=search&high=$_GET[high]');});</script>
<!--{if $_G['cache']['plugin']['xigua_st']['showfz']}-->
<!--{if $_G['cache']['plugin']['xigua_st']['dingwei'] && !getcookie('setcitygeo')}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_ho'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script>
function autolbho(){
ho_getlocation(function (position) {
    var citylat = (position.latitude||position.lat);
    var citylng = (position.longitude||position.lng);
    $.ajax({
        type: 'GET',
        url: _APPNAME + '?id=xigua_ho&ac=getloc&checkst=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            var m = s.split('|');
            if('success' == m[0]){
                var _t = m[1].split(',');
                if(_t[0]>0 && _t[0]!='{$_GET[st]}'){
                    $.confirm("{lang xigua_hb:dqdws}"+_t[1]+'{lang xigua_hb:setcitygeo2}', function() {
                        window.location.href = _APPNAME+"?id=xigua_ho&st="+_t[0];
                        hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                    }, function() {
                        hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                    });
                }else{
                    hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                }
            }else{
            }
        }
    });
});
}
if(typeof wx!='undefined'){wx.ready(function () { autolbho(); });}else{setTimeout(function(){ autolbho(); }, 300);}
</script><!--{/if}--><!--{/if}-->