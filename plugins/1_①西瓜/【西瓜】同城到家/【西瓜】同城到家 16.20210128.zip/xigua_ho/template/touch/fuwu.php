<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<div class="page__bd ">
    <div>
    <div class="shifu_top">
        <div class="weui-cells mt0 before_none after_none">
            <div class="weui-cell aib">
                <div class="weui-cell__hd mr10">
                    <a href="javascript:;" class="shifu_jump shif_face" data-shifuid="{$shifu[id]}"><img src="{avatar($v['uid'], 'middle', 1)}" class="v_head" id="shottag_head"></a>
                </div>
                <div class="weui-cell__bd">
                    <a class="c3 f15 shifu_jump" href="javascript:;" data-shifuid="{$shifu[id]}">{$v['member'][username]}</a>
                    <!--{if $v[is_dig]}-->
                    <div class="mod-lv is-star ml0">{lang xigua_ho:dig}</div>
                    <!--{/if}-->
                    <div class="secp">
                        <!--{loop $v['jineng_str_ary'] $_k $_v}-->
                        <div class="shifu_type jbtn main_color"><a href="javascript:;">{$_v}</a></div>
                        <!--{/loop}-->
                    </div>
                </div>
                <div class="weui-cell_ft">
                    <span class="c9 f12 inblock">{$v[upts_u]} {lang xigua_ho:pub}</span>
                </div>
            </div>
        </div>
        <div class="weui-cells need_vlist">
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:fwxm}</label>
                </div>
                <div class="weui-cell__bd">
                    <p class="main_color">$v[title]</p>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:fwqy}</label>
                </div>
                <div class="weui-cell__bd">
                    <p class="main_color">$v[areawant_str]</p>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:opentime}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>$v[opentime]</p>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:level}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>{$alllevels[$shifu['level']]['name']}</p>
                </div>
            </div>
            <div class="weui-cell h20">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:sfbz}</label>
                </div>
                <div class="weui-cell__bd cl">
                    <span class="priceText"><em class="f12">&yen;</em> {echo floatval($v[price]);}<em class="f12">{$fwunits[$v[unit]]}</em></span>
                </div>
            </div>
            <!--{if $v[dingprice]>0}-->
            <div class="weui-cell h20">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:yfdj}</label>
                </div>
                <div class="weui-cell__bd cl">
                    <span class="priceText">
                       <em class="f12"> &yen;</em> {echo floatval($v[dingprice]);}
                    </span>
                </div>
            </div>
            <!--{/if}-->
            <!--{if $v[dingjin_open]}-->
            <a class="weui-cell weui-cell_access" href="tel:{$shifu[mobile]}">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:sfyy}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>{lang xigua_ho:sfyy_tip}</p>
                </div>
                <div class="weui-cell__ft">{lang xigua_ho:ljyy}</div>
            </a>
            <!--{/if}-->
        </div>
        <div class="weui-cells wxts">
            <a class="weui-cell" href="$SCRITPTNAME?id=xigua_hj">
                <div class="weui-cell__hd f14 c3">{lang xigua_ho:wxts}</div>
                <div class="weui-cell__bd c6">
                    <p class="color-red2">{lang xigua_ho:wxts2}</p>
                    <p class="c9">{lang xigua_ho:wxts1}</p>
                </div>
                <div class="weui-cell__ft tc">
                    <i class="main_color iconfont icon-jubao2"></i>
                    <p class="main_color">{lang xigua_hj:wyjb}</p>
                </div>
            </a>
        </div>
        <div class="weui-cells need_vlist">
            <div class="weui-cell aib">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:fwms}</label>
                </div>
                <div class="weui-cell__bd">
                    <p>{eval echo hb_nl2br($v[jieshao])}</p>
                </div>
            </div>
            <!--{if $v[album]}-->
            <div class="weui-cell aib aibalbum">
                <div class="weui-cell__hd">
                    <label>{lang xigua_ho:alzp}</label>
                </div>
                <div class="weui-cell__bd">
                    <div class="cl feed-preview-pic"><!--{loop $v[album] $img}--><span class="imgloading"><img src="$img"></span><!--{/loop}--></div>
                </div>
            </div>
            <!--{/if}-->
            <!--{if $_G['cache']['plugin']['xigua_ho'][mkey] && $v[lng]}-->
            <div class="vmap" id="v_openlocation_ho" data-lat="$v[lat]" data-lng="$v[lng]" data-name="$v[title]" data-addr="$v[addr]">
                <img src="https://apis.map.qq.com/ws/staticmap/v2/?center={$v[lat]},{$v[lng]}&zoom=15&size=640*320&maptype=roadmap&markers=size:large|color:0xFFCCFF|{$v[lat]},{$v[lng]}
&key={$_G['cache']['plugin']['xigua_ho'][mkey]}" />
            </div>
            <!--{/if}-->
        </div>
    </div>
        <div class="weui-cells__title c3 cl needlogs">{lang xigua_ho:fwjl}</div>
        <div class="weui-cells need_vlist needlogs">
            <!--{if $neelogs}-->
            <!--{loop $neelogs $_k $_v}-->
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label class="cjlab" style="width:35px!important;"><img src="{avatar($_v['need_uid'], 'middle', true)}" /> </label>
                </div>
                <div class="weui-cell__bd">
                    {$_v[username]}
                </div>
                <div class="weui-cell__ft">
                    <p class="f14">{$_v[crts_u]}</p>
                </div>
            </div>
            <!--{/loop}-->
            <!--{else}-->
            <div class="weui-cell">
                <div class="weui-cell__bd c8">
                    <p>{lang xigua_ho:zwjl}</p>
                </div>
            </div>
            <!--{/if}-->
        </div>
    </div>
    <div class="bottom_fix"></div>

    <!--{if $is_mine}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right">
            <a href="$SCRITPTNAME?id=xigua_ho&high=0" class="jv_viewbtn border_right">{lang xigua_ho:index}</a>
        </div>
        <!--{if $v[yuyue]}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right f12"><i class="iconfont icon-yanzheng color-good f12"></i>{lang xigua_ho:xdqqyy}</a>
        </div>
        <!--{/if}-->
        <div class="weui-flex__item in_bottom_y">
            <a href="$SCRITPTNAME?id=xigua_ho&ac=add&old_id=$fuwuid" class="jv_viewbtn">{lang xigua_ho:edit}</a>
        </div>
    </div>
    <!--{else}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right">
            <a href="$SCRITPTNAME?id=xigua_ho&high=0" class="jv_viewbtn border_right">{lang xigua_ho:index}</a>
        </div>
        <!--{if $v[yuyue]}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right f12"><i class="iconfont icon-yanzheng color-good f12"></i>{lang xigua_ho:xdqqyy}</a>
        </div>
        <!--{/if}-->
        <div class="weui-flex__item in_bottom_y">
            <!--{if $v[status]!=1}-->
            <a href="javascript:;" class="jv_viewbtn disabled">$fuwu_status[$v[status]]</a>
            <!--{else}-->
            <a href="javascript:;" data-fuwuid="{$fuwuid}" class="jv_viewbtn jv_qiang2">{lang xigua_ho:ljxd}</a>
            <!--{/if}-->
        </div>
    </div>
    <!--{/if}-->
</div>
<!--{if $_G['cache']['plugin']['xigua_ho']['logo']}--><div class="hide none"><img src="{$_G['cache']['plugin']['xigua_ho']['logo']}" /></div><!--{/if}-->
<!--{eval $ho_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_ho:footer}--><!--{eval $jdmzsm = str_replace("'", '', ($ho_config['jdmzsm']));$jdmzsm=str_replace(array("\n","\r"),'', $jdmzsm);}-->
<script>
$(document).on('click','.jv_qiang2', function () {
var that = $(this);
var fuwuid = that.data('fuwuid');
$.modal({
title: "<div class=\"tuan_recommend_title\"><span class=\"tuan_recommend_title_text\">{lang xigua_ho:mzsm}</span></div>",
text: '{$jdmzsm}',
buttons: [
    { text: "{lang xigua_ho:guanbi}", className: "default", onClick: function(){ }},
    { text: "{lang xigua_ho:tongyi}", onClick: function(){
        $.ajax({
            type: 'POST',
            url: _APPNAME +'?id=xigua_ho&ac=com&do=qiangdan&inajax=1',
            data: {'formhash':FORMHASH, 'fuwuid':fuwuid},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {}
        });
    }}
]});
});</script>
<!--{template xigua_ho:haibao}-->