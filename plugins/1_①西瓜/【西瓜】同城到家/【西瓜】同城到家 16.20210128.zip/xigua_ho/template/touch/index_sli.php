<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $topnavslider}-->
<div class="swipe cl">
    <div class="swipe-wrap">
        <!--{loop $topnavslider $slider}-->
        <div>$slider</div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $topnavslider $k $slider}-->
            <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{/if}-->
<div class="index_bar">
    <div class="search_tool" ><a href="javascript:;">$ho_config['schtxt']</a></div>
</div>
