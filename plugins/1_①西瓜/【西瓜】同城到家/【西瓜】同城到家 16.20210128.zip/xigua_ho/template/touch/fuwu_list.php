<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:header}-->
<div class="page__bd">
    <!--{if $catinfo['share_pic']}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$catinfo['share_pic']" /></div><!--{/if}-->
    <!--{if IN_MAGAPP}--><style>.nav_expand_panel{position:absolute;height:auto!important;}.nav_expand_panel .weui-flex__item{height:auto;overflow:hidden!important;}</style><!--{/if}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{if !$hide_nav}-->
    <div class="cl fix_float_fix"></div>
    <!--{else}-->
    <div class="cl fix_float_fix"></div>
    <style>.fix_float{top:0}.nav_expand_panel{top:2.45rem}#dist_show_4{height:calc(100vh - 95px)}</style>
    <!--{/if}-->
    <div class="weui-navbar fix_float">
        <a data-id="1" class="dist_nav weui-navbar__item <!--{if $inmap}-->none<!--{/if}-->">
            <span>$distname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <a data-id="2" class="dist_nav weui-navbar__item">
            <span>$catname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <a data-id="3" class="dist_nav weui-navbar__item">
            <span>$orderby_list[$orderby]<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{if $filtervars}-->
        <a data-id="4" class="dist_nav weui-navbar__item">
            <span>{lang xigua_hb:sxx}<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{/if}-->
    </div>
    <div class="dist_show">
        <div id="dist_show_1" class="nav_expand_panel border_top">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="first_check border_bfull <!--{if !$_GET[province]}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=$cat_id&province=&city=&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&inmap=$inmap&filter=$filter{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $dist0 $v}-->
                        <li class="first_check border_bfull <!--{if $_GET[province]==$v[name]}-->checked main_color<!--{eval $city_id=$v['id'];}--><!--{/if}-->" data-id="$v[id]" data-link="{$v[link]}"><a>$v[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="weui-flex__item checked">
                    <!--{loop $dist0 $k $v}-->
                    <ul class="sub_cheker <!--{if $_GET[province]!=$v['name']}-->none<!--{else}-->checked<!--{/if}-->" id="sub_cheker_$v[id]">
                        <li class="sub_check border_bfull"><a data-href="$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=$cat_id&province={$v[name]}&city=&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&inmap=$inmap&filter=$filter{$urlext}" class="choose color-red">{lang xigua_hb:quan}{$v[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a></li>
                        <!--{loop $v[child] $vv}-->
                        <li class="sub_check border_bfull <!--{if $city==$vv[name]&&$_GET[city]}-->checked main_color autotrigger<!--{/if}-->"><a data-href="$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=$cat_id&province=$v[name]&city=$vv[name]&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&inmap=$inmap&filter=$filter{$urlext}" id="sub_check{$vv[id]}" data-id="$vv[id]" onclick="hs_getnext($vv[id], '{$vv[name]}','$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=$cat_id&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&inmap=$inmap&filter=$filter{$urlext}','{$vv[link]}')">$vv[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                    <!--{/loop}-->
                </div>
                <div class="weui-flex__item checked" id="ajaxbox"> <ul class="ajaxbox_cheker"></ul> </div>
            </div>
        </div>
        <div id="dist_show_2" class="nav_expand_panel border_top">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="first_cat_check border_bfull <!--{if !$cat_id}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=&province=$_GET[province]&city=$city&dist=$dist&orderby=$orderby&lat=$lat&lng=$lng&inmap=$inmap&filter=$filter{$urlext}">{lang xigua_hb:quanbu}{lang xigua_ho:fuwu}</a></li>
                        <!--{loop $cat_tree $k $v}-->
                        <!--{if !$v[cat_link]}-->
                        <li class="first_cat_check border_bfull <!--{if $cat_id==$v[id]||$pid==$v[id]}-->checked main_color<!--{/if}-->"<!--{if $v[child]}--> data-id="$v[id]"<!--{/if}-->><a <!--{if !$v[child]}--> href="$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=$v[id]&province=$_GET[province]&city=$city&dist=$dist&orderby=$orderby&lat=$lat&lng=$lng&inmap=$inmap&filter=$filter{$urlext}"<!--{/if}-->>$v[name]</a></li>
                        <!--{else}-->
                        <li class="first_cat_check border_bfull <!--{if $cat_id==$v[id]||$pid==$v[id]}-->checked main_color<!--{/if}-->"<!--{if $v[child]}--> data-id="$v[id]"<!--{/if}-->><a <!--{if !$v[child]}--> href="$v[cat_link]"<!--{/if}-->>$v[name]</a></li>
                        <!--{/if}-->
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="weui-flex__item checked">
                    <!--{loop $cat_tree $k $v}-->
                    <ul class="sub_cat_cheker <!--{if !($cat_id==$v[id]||$pid==$v[id])}-->none<!--{/if}-->" id="sub_cat_cheker_$v[id]">
                        <li class="sub_cat_check border_bfull"><a <!--{if $cat_id==$v[id]}-->class="checked main_color"<!--{/if}--> href="$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=$v[id]&province=$_GET[province]&city=$city&dist=$dist&orderby=$orderby&lat=$lat&lng=$lng&inmap=$inmap&filter=$filter{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $v[child] $vv}-->
                        <li class="sub_cat_check border_bfull"><a <!--{if $cat_id==$vv[id]}-->class="checked main_color"<!--{/if}--> href="<!--{if $vv[cat_link]}-->$vv[cat_link]<!--{else}-->$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=$vv[id]&province=$_GET[province]&city=$city&dist=$dist&orderby=$orderby&lat=$lat&lng=$lng&inmap=$inmap&filter=$filter{$urlext}<!--{/if}-->">$vv[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <div id="dist_show_3" class="nav_expand_panel border_top">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul><!--{loop $orderby_list $_k $_v}--><!--{eval
$checked = $orderby==$_k? 'checked main_color':'';
$idxinx = $_k=='near' ? 'id="near_xinxi" data-':'';
                }--><li class="$checked border_bfull"><a {$idxinx}href="$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=$cat_id&province=$_GET[province]&city=$city&dist=$dist&orderby=$_k&keyword=$keyword&inmap=$inmap&filter=$filter{$urlext}">$_v</a></li>
                        <!--{/loop}--></ul>
                </div>
            </div>
        </div>

        <!--{if $filtervars}-->
        <div id="dist_show_4" class="nav_expand_panel border_top">
            <!--{loop $filtervars $_k $_v}-->
            <!--{eval $extra = trim($_v[extra]);}-->
            <div class="weui-cells__title c3">{echo $_v[title]?$_v[title]:$_v[bc][title]}</div>
            <div class="weui-cells before_none after_15">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <!--{if $_v[data]}--><div class="main_color cat_m" data-title="{$_k}" id="cat_tit_{$_k}" style="display:none"><span>{lang xigua_hb:yx}</span><span id="cat_tit_in_{$_k}"></span><span>X</span></div><!--{/if}-->
                        <div class="post-tags cl gray-tags">
                            <!--{if $extra}-->
                            <!--{eval $extra = explode("\n", $extra);}-->
                            <!--{loop $extra $__k $extra_string}-->
                            <!--{eval list($tmp1, $tmp2) = explode('=', trim($extra_string));}-->
                            <a class="weui-btn weui-btn_mini weui-btn_default <!--{if $_filter[$_k]==$tmp1}-->tag-on<!--{/if}-->" data-title="{$_k}" data-value="$tmp1" href="javascript:;" <!--{if $_v['type']=='selects'}-->data-multi="1"<!--{/if}-->>$tmp2</a>
                            <!--{/loop}-->
                            <!--{elseif $_v[data]}-->
                            <!--{loop $_v[data] $sub0}-->
                            <a class="weui-btn weui-btn_mini weui-btn_default <!--{if $_filter[$_k]==$sub0[index]}-->tag-on<!--{/if}--> level_1_{$_k}" data-lv="$sub0[index]" data-title="{$_k}" data-value="$sub0[index]" href="javascript:;">$sub0[name]</a>
                            <!--{if $sub0[sub]}--><!--{loop $sub0[sub] $sub1}-->
                            <a style="display:none" class="weui-btn weui-btn_mini weui-btn_default <!--{if $_filter[$_k]==$sub1[index]}-->tag-on<!--{/if}--> level_2_{$_k}"  data-lv="$sub1[index]" data-title="{$_k}" data-value="$sub1[index]" href="javascript:;">$sub1[name]</a>
                            <!--{if $sub1[sub]}--><!--{loop $sub1[sub] $sub2}-->
                            <a style="display:none" class="weui-btn weui-btn_mini weui-btn_default <!--{if $_filter[$_k]==$sub2[index]}-->tag-on<!--{/if}--> level_3_{$_k}"  data-lv="$sub2[index]" data-title="{$_k}" data-value="$sub2[index]" href="javascript:;">$sub2[name]</a>
                            <!--{/loop}--><!--{/if}-->
                            <!--{/loop}--><!--{/if}-->
                            <!--{/loop}-->
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
            <!--{/loop}-->

            <div class="weui-flex">
                <input type="button" id="filtervar_clear" class="weui-btn weui-btn_default " value="{lang xigua_hb:czhi}" style="margin:15px;color: #666;" />
                <input type="button" id="filtervar_btn" class="weui-btn weui-btn_default  main_color" value="{lang xigua_hb:queding}" style="margin: 15px;" />
            </div>
        </div>
        <!--{/if}-->
    </div>

    <!--{if $catinfo['adimage']}-->
    <div class="">
        <a href="{eval echo $catinfo['adlink'] ? $catinfo['adlink'] : $SCRITPTNAME.'?id=xigua_ho&ac=fuwu_list&cat_id='.$cat_id}"><img src="$catinfo['adimage']" class="block" /></a>
    </div>
    <!--{/if}-->
    <!--{if $catinfo['customad']}-->{echo htmlspecialchars_decode($catinfo['customad'])}<!--{/if}-->
    <!--{if !$inmap}-->
    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">
            <input name="id" value="xigua_ho" type="hidden">
            <!--{loop $_GET $_k $_v}-->
            <input type="hidden" name="$_k" value="$_v">
            <!--{/loop}-->
            <input name="ac" value="fuwu_list" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_ho:qtxsxfw}" data-hold="{lang xigua_ho:qtxsxfw}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_ho:qtxsxfw}</span>
            </label>
        </form>
        <a href="javascript:" class="search_bar_btn main_color" id="dosearch">{lang xigua_ho:search}</a>
        <a href="javascript:;" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_ho:qx}</a>
    </div>
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->
    <!--{else}-->
    <!--{eval $nedmapjs = 1;$ho_config[showqg]=$ho_config[listqg];$ho_config[ditudj]= $ho_config[ditudj2];}-->
    <!--{template xigua_ho:map}-->
    <!--{/if}-->
</div>
<div class="footer_fix"></div>
<div class="bottom_fix"></div>
<!--{if $listrz = unserialize($ho_config[listrz])}-->
<!--{if in_array(2,$listrz)}-->
<div class="right_float hbtn hbtn_fabu" id="faxuqiu"></div>
<!--{/if}-->
<!--{/if}-->
<script>
    <!--{if !$inmap}-->
    var loadingurl = window.location.href+'&ac=fuwu_li&inajax=1&pagesize=20&page=';
    <!--{/if}-->
    scrollto = 1;
    function hs_getnext(id, name, datahref, datalink){
        if(datalink){
            hb_jump(datalink);
            return false
        }
        $('.sub_check a').removeClass('checked').removeClass('main_color');
        $('.sub_check a').parent().removeClass('checked').removeClass('main_color');
        $('#sub_check'+id).addClass('checked').addClass('main_color');
        $.ajax({
            type: 'get',
            url: _APPNAME + '?id=xigua_hb&province='+$('.first_check+.checked').find('a').text()+'&name='+name+'&ctid='+id+'&datahref='+encodeURIComponent(datahref)+'&inajax=1',
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $('.ajaxbox_cheker').html(s);
            }
        });
    }
    $(document).on('click','.choose', function () {
        if($(this).data('link')){
            hb_jump($(this).data('link'));
            return false
        }
        var that = $(this), c_jmpurl = '';
        if(that.data('href')){ c_jmpurl = that.data('href'); }
        if(that.data('ctid')){ c_jmpurl = $('#sub_check'+that.data('ctid')).data('href'); }
        window.location.href= c_jmpurl;
    });
    $(document).on('click','.dist_check', function () {$('.dist_check').removeClass('checked').removeClass('main_color'); $(this).addClass('checked').addClass('main_color');});
    $(document).on('click','.dist_nav', function () {if($('.autotrigger').length>0){$('.autotrigger').find('a').trigger('click');}});
    $(document).on('click','.first_check', function () {
        if($(this).data('link')){
            hb_jump($(this).data('link'));
            return false
        }
        $('.ajaxbox_cheker').html('');
    });
    $(document).on('click','.gray-tags a', function () {
        var that = $(this), lv=that.data('lv'), dt=that.data('title'), dv=that.data('value');
        if(lv){
            $('#cat_tit_in_'+dt).append('<a style="margin-right:5px" class="tag-on" data-title="'+dt+'" data-value="'+dv+'">'+that.html()+'</a>')
            $('#cat_tit_'+dt).show();

            that.hide();
            that.siblings().hide();
            that.parent().find('a').each(function () {
                var tt = $(this);
                var ttlv = tt.data('lv')+'';
                if(ttlv.indexOf(lv+'.')===0){
                    if(that.hasClass('level_1_'+dt) && tt.hasClass('level_2_'+dt)){
                        tt.show();
                    }
                    if(that.hasClass('level_2_'+dt) && tt.hasClass('level_3_'+dt)){
                        tt.show();
                    }
                }
            });
        }else{
            that.siblings().removeClass('tag-on');
            that.addClass('tag-on');
        }
    });
    $(document).on('click','.cat_m', function () {
        var that = $(this), dt=that.data('title');
        $('#cat_tit_in_'+dt).html('');
        $('#cat_tit_'+dt).hide();
        $('.level_1_'+dt).show();
        $('.level_2_'+dt).hide();
        $('.level_3_'+dt).hide();
    });
    $(document).on('click','#filtervar_btn', function () {
        var res = '';
        $('a.tag-on').each(function () {
            var that = $(this);
            res+= that.data('title')+'_'+that.data('value')+'__';
        });
        hb_jump('$SCRITPTNAME?id=xigua_ho&ac=fuwu_list&cat_id=$cat_id&province=$_GET[province]&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&inmap=$inmap&filter='+res);
    });
    $(document).on('click','#filtervar_clear', function () {
        $('.gray-tags a').removeClass('tag-on');
        $('.cat_m').trigger('click');
    });
    if($('.sub_cheker').length===$('.sub_cheker.none').length){$('.sub_cheker:first-child').removeClass('none');}
    $(document).on('click','#dosearch', function () {
        if($('#searchInput').val()){
            $('#dosearchform').submit();
        }else{
            $.alert($('#searchInput').attr('placeholder'));
        }
    });
</script>
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_ho'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script>$(document).on('click','#near_xinxi', function () {var that = $(this);var href= that.data('href');ho_getlocation(function (position) {
        var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);window.location.href= href+ '&lat='+lat+'&lng='+lng;});});</script>
<!--{eval $ho_tabbar=1;$tabbar=0;}-->
<!--{template xigua_ho:footer}-->