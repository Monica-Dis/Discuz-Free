<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval $newset_shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_tuijian(5);}-->
<!--{if $newset_shifu}-->
<div class="weui-cells__title weui_title border_none"><span class="f15">{lang xigua_ho:tcfw}</span><a class="y c9" href="$SCRITPTNAME?id=xigua_ho{$urlext}">{lang xigua_hb:more}<i class="f13 iconfont icon-jinrujiantou"></i></a></div>
<ul class="index_sf cl">
    <!--{loop $newset_shifu $_k $_v}--><li onclick="hb_jump(_APPNAME+'?id=xigua_ho&ac=shifu&shifuid={$_v[id]}');">
        <img src="{$_v[avatar]}" />
        <span>{$_v[realname]}</span>
        <span>{$_v[jineng_str_ary][0]}</span>
    </li><!--{/loop}-->
</ul>
<!--{/if}-->