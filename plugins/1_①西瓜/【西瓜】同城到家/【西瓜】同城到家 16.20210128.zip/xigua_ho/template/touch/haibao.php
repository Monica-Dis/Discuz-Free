<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
$ccc = $config[maincolor];
if($shot_img = $v[avatar]):
    $shot_file = 'source/plugin/xigua_ho/cache/'.md5($shot_img).'.png';
    if(strpos($shot_img, $_G[siteurl])===false):
        if(!is_file(DISCUZ_ROOT.$shot_file)):
            file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($shot_img));
        endif;
        $shot_img = $shot_file;
    endif;
endif;
$hb_currenturl = hb_currenturl();
}--><style>.mpc {margin: 15px;box-shadow: 1px 1px 10px rgba(0, 0, 0, .1);border-radius: 10px;overflow: hidden;}.mpc_body .dh_viewheader{margin-bottom:0;}
.mpc_body {position: relative;background:#fff;background-size: cover;width: calc(100vw - 30px);min-height: calc(((100vw) / 1.95) - 15px);text-align: center;}
.qrblock{width:90px;height:90px;display:block;float:right}.qreidl{padding:0 15px 15px;color: #fff;background:$ccc;}.dh_viewheader .shot_img img{width:100%;display:block;max-height:400px}
.shot_info{position: relative;border-radius: 50px;text-align: left;}.shot_info .need_vlist{margin-top:0}.shot_info .shifu_type{right:1px}.qreidl .ttile{font-size:22px}.shot_in{padding-top: 1px;padding-bottom: 1px;border-radius: 10px;overflow: hidden;}.shot_in .hrlist li:after,.shot_in .jbtn:after,.shot_in .wxts,.shot_in .vmap,.shot_in .aibalbum{display:none}
</style><script src="source/plugin/xigua_hb/static/js/html2canvas.min.js?{VERHASH}"></script>
<div id="shot" style="position:fixed;bottom:-100000px">
    <div class="shot_in main_bg">
        <div class="mpc">
            <div class="mpc_body">
                <div class="dh_viewheader">
                    <div class="shot_info"></div>
                </div>
            </div>
        </div>
        <div class="weui-flex qreidl">
            <div class="weui-flex__item" style="height:90px!important;">
                <p class="ttile">$ho_config[hbtitle]</p>
                <p class="f16 mt8">$ho_config[hbdesc]</p>
            </div>
        <div>
<!--{eval include_once 'source/plugin/xigua_ho/include/c_haibao.php';}-->
<!--{if $_G['cache']['plugin']['xigua_hx'] && IN_PROG}-->
    <img src="$shqr" class="qrblock">
<!--{else}-->
    <img src="{eval echo ho_qrcode($_GET['shifuid'], $hb_currenturl, $shot_img, $_GET['fuwuid'], $_GET['needid']);}"  class="qrblock" />
<!--{/if}-->
            </div>
        </div>
    </div>
</div>
<!--{eval $hbword = lang_hb('haibao',0) ."<em class='iconfont icon-jinrujiantou f12'></em>";}-->
<a href="javascript:;" class="hbzder1 main_bg hbtn_share">$hbword</a>
<script>
setTimeout(function () {$('.hbzder1').addClass('r-21');}, 800);
$(document).on('click','.hbtn_share', function () {
<!--{if $_GET[shifuid]}-->$.ajax({type: 'post',url: _APPNAME +'?id=xigua_ho&ac=com&do=incr&incr_type=shares&shifuid=$_GET[shifuid]&inajax=1',data: {'formhash':FORMHASH},dataType: 'xml'});<!--{/if}-->
$.showLoading();
var shiftop = $('.shifu_top');
$('.shot_info').html(shiftop.html().replace(shiftop.find('.shif_face').attr('src'), '$shot_img'));
html2canvas(document.querySelector(".shot_in")).then(canvas => {
    var dataURL = canvas.toDataURL();
    COMCLAS = 'shot_outer';
    $.hideLoading();
    $.modal({
        title: "{lang xigua_ho:ca}",
        text: "<img style='display:block' src='"+dataURL+"' />",
        buttons: [{ text: "{lang xigua_hb:close}", onClick: function(){} }]
    });
    $('.weui-dialog__title').css('font-size', '14px');
    COMCLAS = '';
});
return false;
});
</script>