<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $k $v}-->
<!--{if $_GET['is_my']}-->
<div class="job_li cl border_bottom">
    <div class="job_top jump_fuwu" data-id="$v[id]">
        <h4>
            <!--{if $v[is_dig]}-->
            <span class="jbtn is_dig">{lang xigua_ho:dig}</span>
            <!--{/if}-->
            <span class="flex1">{$v[title]}</span>
            <span class="jbtn jbtn_gray">{$shifu_status[$v[status]]}</span>
            <!--{if $v[yuyue]}-->
            <span class="jbtn jbtn_gray">{lang xigua_ho:yuyue}</span>
            <!--{/if}-->
        </h4>
    </div>
    <div class="job_li_mid cl jump_fuwu" data-id="$v[id]">
        <div class="z">
            <span class="resume_spani"> <em class="main_color">&yen; $v[price]</em> {$fwunits[$v[unit]]} </span>
            <!--{if $v[dingjin_open]}-->
            <span class="resume_spani"> {lang xigua_ho:djje} <em class="main_color">&yen; $v[dingprice]</em></span>
            <!--{/if}-->
        </div>
        <div class="y">
            <span class="resume_spani">{$v[upts_u]}{lang xigua_ho:shuaxin}</span>
        </div>
    </div>
    <div class="job_li_mid cl f12 c9">
        <div class="z">{lang xigua_ho:views} <em class="c3">{$v[views]}</em></div>
        <!--{if $v[dig_endts_u]}-->
        <div class="y">{lang xigua_ho:dig_endts}: {$v[dig_endts_u]}</div>
        <!--{/if}-->
    </div>
    <div class="job_mid cl">
        <div class="z">
            <!--{if $v[status]==-2}-->
            <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn offline_btn2" data-fuwuid="$v[id]" data-xiajia="0">{lang xigua_ho:sjia}</a>
            <!--{else}-->
            <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn offline_btn2" data-fuwuid="$v[id]" data-xiajia="1">{lang xigua_ho:xjia}</a>
            <!--{/if}-->
            <a href="$SCRITPTNAME?id=xigua_ho&ac=add&old_id={$v[id]}{$urlext}" class="weui-btn weui-btn_mini hm_c_btn">{lang xigua_ho:xiugai}</a>
        </div>
        <div class="y">
            <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn1 refresh_btn2" data-fuwuid="$v[id]">{lang xigua_ho:shuaxin}</a>
            <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn1 dig_btn2" data-fuwuid="$v[id]">{lang xigua_ho:dig}</a>
        </div>
    </div>
</div>
<!--{else}-->
<div class="weui-cell need_list aib jump_fuwu" data-id="{$v[id]}">
    <div class="weui-cell__hd">
        <img src="{echo $v[album][0]?$v[album][0]: avatar($v['uid'], 'middle', true)}" onerror="this.error=null;this.src='source/plugin/xigua_ho/static/img/dft.png'" />
        <!--{if $v[yuyue]}--><em class="btnsha mia2_">{lang xigua_ho:xyy}</em><!--{/if}-->
    </div>
    <div class="weui-cell__bd">
        <h4>{$v[title]}<!--{if $v[is_dig]}-->
            <span class="jbtn is_dig pr-1">{lang xigua_ho:dig}</span>
            <!--{/if}-->
            <!--{if $v[dingjin_open] && $v[dingprice]}-->
            <span class="color-sec pcfiled color-red2"><em class="f16 color-red2">{$v[dingprice]}</em><em class="f12 color-red2">{lang xigua_hb:yuan}</em></span>
            <em class="sp_bubble">{lang xigua_ho:dj}</em>
            <!--{else}-->
            <span class="color-sec pcfiled color-red2"><em class="f16 color-red2">{$v[price]}</em><em class="f12 color-red2">{$fwunits[$v['unit']]}</em></span>
            <!--{/if}-->
        </h4>
        <div class="cl f13">
            <div>
                <ul class="hrlist cl">
                    <!--{if $veris1[$v[uid]]}--><li style="margin:.2rem"><i class="iconfont icon-erified"></i> {lang xigua_ho:shiming}</li><!--{/if}-->
                    <!--{if $v[shid] && $veris2[$v[uid]]}--><li><i class="iconfont icon-yanzheng"></i> {lang xigua_hr:qy}</li><!--{/if}-->
                    <!--{if $bao[$v[uid]]}--><li style="margin:.2rem"><i class="iconfont icon-yongjin2"></i> {$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</li><!--{/if}-->
                </ul>
            </div>
            <p class="c3 none"><span class="c8">{lang xigua_ho:level}: </span> {$alllevels[$shifus[$v[shifuid]]['level']]['name']}</p>
            <!--{if $v[opentime]}-->
            <p class="c3"><span class="c8">{lang xigua_ho:opentime}: </span> {$v[opentime]}</p>
            <!--{/if}-->
            <!--{if $v[jineng_str]}-->
            <p class="c3"><span class="c8">{lang xigua_ho:jineng_str}: </span> {$v[jineng_str]}</p>
            <!--{/if}-->
            <!--{if $v[areawant_str]}-->
            <p class="c3"><span class="c8">{lang xigua_ho:fwqy}: </span> {$v[areawant_str]}</p>
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{/if}-->
<!--{/loop}-->