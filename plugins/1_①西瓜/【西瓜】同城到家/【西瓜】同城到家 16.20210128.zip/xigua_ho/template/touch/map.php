<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $ho_config[clickmod]==1}--><style>img.csssprite{border-radius:32px}</style><!--{/if}--><div id="map_box"></div><div id="list2" class="mod-post x-postlist pt0"></div>
<!--{template xigua_hb:loading}-->