<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_ho:tabbar}-->
<div id="pub_ctrl" class='weui-popup__container popup-bottom z501'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <h1 class="title">{lang xigua_ho:zxrzlx}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">

                <a href="$SCRITPTNAME?id=xigua_ho&ac=join&type=sh&mobile=2{$urlext}" class="weui-cell before_none">
                    <div class="weui-cell__hd" >
                        <label><img src="source/plugin/xigua_ho/static/img/quanzhi.png"></label>
                    </div>
                    <div class="weui-cell__bd">
                        <p>{lang xigua_ho:qyrz}</p>
                        <p>{lang xigua_ho:qgg}</p>
                    </div>
                </a>
                <a href="$SCRITPTNAME?id=xigua_ho&ac=join&mobile=2{$urlext}" class="weui-cell before_none">
                    <div class="weui-cell__hd" >
                        <label><img src="source/plugin/xigua_ho/static/img/jianzhi.png"></label>
                    </div>
                    <div class="weui-cell__bd">
                        <p>{lang xigua_ho:sfrz}</p>
                        <p>{lang xigua_ho:gr}{lang xigua_ho:sfrz}</p>
                    </div>
                </a>
                <a href="javascript:;" class="picker-button close-popup iclose"><i class="iconfont icon-guanbijiantou c9 f24"></i></a>
            </div>

        </div>
    </div>
</div>
<div id="need_ctrl" class='weui-popup__container popup-bottom z501 pub_ctrl'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <h1 class="title">{lang xigua_ho:pub}{lang xigua_ho:fwxq}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <!--{if $ho_config[fbzj]}-->
                <a href="$SCRITPTNAME?id=xigua_ho&ac=chosecat&type=yikou&mobile=2{$urlext}" class="weui-cell before_none">
                <!--{else}-->
                <a href="$SCRITPTNAME?id=xigua_ho&ac=need&type=yikou&mobile=2{$urlext}" class="weui-cell before_none">
                <!--{/if}-->
                    <div class="weui-cell__bd">
                        <div class="pr fbbtn">
                            <img src="source/plugin/xigua_ho/static/img/p1.png">
                            <p class="fbbtn_t">{lang xigua_ho:yikou_short}</p>
                            <p class="fbbtn_p">{lang xigua_ho:yikou_tip}</p>
                        </div>
                    </div>
                </a>
                <!--{if $ho_config[fbzj]}-->
                <a href="$SCRITPTNAME?id=xigua_ho&ac=chosecat&type=jingjia&mobile=2{$urlext}" class="weui-cell before_none">
                <!--{else}-->
                <a href="$SCRITPTNAME?id=xigua_ho&ac=need&type=jingjia&mobile=2{$urlext}" class="weui-cell before_none">
                <!--{/if}-->
                    <div class="weui-cell__bd">
                        <div class="pr fbbtn">
                            <img src="source/plugin/xigua_ho/static/img/p2.png" />
                            <p class="fbbtn_t">{lang xigua_ho:jingjia_short}</p>
                            <p class="fbbtn_p">{lang xigua_ho:jingjia_tip}</p>
                        </div>
                    </div>
                </a>
                <a href="javascript:;" class="picker-button close-popup iclose"><i class="iconfont icon-guanbijiantou c9 f24"></i></a>
            </div>
        </div>
    </div>
</div>
<script src="source/plugin/xigua_ho/static/ho.js?321{VERHASH}"></script>
<script>$(document).on('click','.dig_btn', function () {var that = $(this);var act = [];$.actions({title: '{lang xigua_hb:qingxuanzezhiding}',
actions: [<!--{loop $dig_prices $_d_i}-->{text: "{$_d_i[title]}", onClick: function () {$.showLoading();$.ajax({type: 'post',url: _APPNAME+'?id=xigua_ho&ac=com&do=dig&digtype={$_d_i[type]}',data:{needid:that.data('needid'), formhash:FORMHASH},dataType: 'xml',success: function (data) {$.hideLoading();if(null==data){ tip_common('error|'+ERROR_TIP); return false;}var s = data.lastChild.firstChild.nodeValue;
tip_common(s);},error: function() {$.hideLoading();}});}},<!--{/loop}-->]});});</script>
<!--{template xigua_hb:common_footer}-->
<!--{if $nedmapjs}-->
<!--{template xigua_ho:map_jsp}-->
<!--{/if}-->
<!--{if $index_list}--><script>$.ajax({url: window.location.href+'&ac=need_li&orderby=newest&inajax=1&pagesize={$ho_config[mappagsize]}&page=',
type: 'GET',dataType: 'xml',success: function (data) {var s = data.lastChild.firstChild.nodeValue;$('#loading-show').addClass('hidden');$('#loading-none').removeClass('hidden');$('#list3').html(s);}});</script><!--{/if}-->