<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $newset_shifu}-->
<div class="weui-navbar__item weui_bar__item_on index_ti"> <span>{lang xigua_ho:tuijian}</span></div>
<div class="hoslide"><ul class="index_shifu cl" style="width:calc((100vw - .75rem)*{echo count($newset_shifu);}/5)">
    <!--{loop $newset_shifu $_k $_v}-->
    <li class="shifu_jump" data-shifuid="{$_v[id]}">
        <img src="{$_v[avatar]}" />
        <span>{$_v[realname]}</span>
        <span>{$_v[jineng_str_ary][0]}</span>
    </li>
    <!--{/loop}-->
</ul></div>
<!--{/if}-->