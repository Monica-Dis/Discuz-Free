<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $_G['cache']['plugin']['xigua_ho']['toutext']}-->
<div class="weui-cells mt0 after_none before_none">
    <div class="chip-row">
        <div class="toutiao">{$indexmod['tz']}</div>
        <div class="toutiao-slider swiper-container" id="newsSlider">
            <ul class="swiper-wrapper">
                <!--{eval $toutiaoitems = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_ho']['toutext'])));}-->
                <!--{loop $toutiaoitems $toutiaoitem}-->
                <!--{eval list($font, $link)= explode(",", trim($toutiaoitem));}-->
                <li class="swiper-slide"><a href="$link">$font</a></li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
</div>
<!--{/if}-->