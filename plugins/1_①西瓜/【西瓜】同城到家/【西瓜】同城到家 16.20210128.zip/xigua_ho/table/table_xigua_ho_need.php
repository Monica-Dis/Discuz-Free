<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_ho_need extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_ho_need';
        $this->_pk = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function fetch_by_id($id)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE id=%d', array($this->_table, $id));
        return self::_prepare($first);
    }

    public function fetch_by_uid($uid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
        return self::_prepare($first);
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $field = '*', $orderby = 'upts DESC', $key_field = '')
    {
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }else{
            $orderby = '';
        }
        global $ho_config;
        if($ho_config['showfz'] && is_array($wherearr) && !defined('IN_ADMINCP')){
            $_stid = intval($_GET['st']);
            $wherearr[] = " (stid=$_stid) ";
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql $orderby " . DB::limit($start_limit, $lpp));
        $return = array();
        foreach ($result as $index => $item) {
            if($key_field){
                $return[$item[$key_field]] = self::_prepare($item);
            }else{
                $return[$index] = self::_prepare($item);
            }
        }
        return $return;
    }

    public function get_order($viewtype)
    {
        $field = '*';
        $order_by = 'ORDER BY dig_endts DESC,displayorder DESC,upts desc';
        switch ($viewtype){
            case "newest":
                $order_by = 'id DESC';
                break;
            case "level":
                $order_by = '(dig_endts-dig_startts) DESC, level DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                $order_by = 'distance ASC, (dig_endts-dig_startts) DESC';
                break;
            default:
                $order_by = ' (dig_endts-dig_startts) DESC, displayorder DESC, id desc';
                break;
        }
        if($_GET['is_my']){
            $order_by  = 'upts desc';
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['id']);
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        if(IS_ADMINID){
            return DB::update($this->_table, $data, array(
                'id'  => $id,
            ));
        }else{
            return DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                'id'  => $id,
            ));
        }
    }

    public static function _prepare($item)
    {
        global $ho_need_types;
        if($item){
            $item['type_u'] = $ho_need_types[$item['type']];
            $item['album'] = $item['album'] ? explode("\t", $item['album']) : array();
            $item['is_dig'] = $item['dig_endts']>TIMESTAMP ? 1:0;
            $item['dig_endts_u']  = $item['dig_endts'] ? dgmdate($item['dig_endts'], 'u') : '';
            if(!$item['is_dig'] && $item['dig_endts']){
                DB::query("update %t set dig_startts=0,dig_endts=0 WHERE id=%d", array('xigua_ho_need',  $item['id']));
            }
            $item['upts_u']  = dgmdate($item['upts'], 'u');
            $item['crts_u']  = dgmdate($item['crts'], 'u');
            $item['price']  = floatval($item['price']);
            if($item['distance']){
                $distance = intval($item['distance']);
                if($distance<=1000){
                    $distance = intval($distance). 'm';
                }else if($distance>1000){
                    $distance = round($distance/1000, 1). 'km';
                }
                $item['distance'] = $distance;
            }
        }
        return $item;
    }

    public function incr($id, $field, $num = 1)
    {
        global $_G;
        if(strpos($id, ',')!==false){
            $id = dintval(array_filter(explode(',', $id)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $id));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
        }
    }

    public function total_views()
    {
        global $_G, $config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);

        $key = 'need_views'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }

    public function fetch_count_by_uid($_uid, $type = 'yikou')
    {
        if(!$type){
            $return = DB::result_first('SELECT count(*) FROM %t WHERE uid=%d', array($this->_table, $_uid));
        }else{
            $return = DB::result_first('SELECT count(*) FROM %t WHERE uid=%d AND `type`=%s', array($this->_table, $_uid, $type));
        }
        return $return;
    }
}