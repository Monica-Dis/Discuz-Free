<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_ho_cat extends  discuz_table
{
    public $arr = array();

    public $nbsp = "&nbsp;";

    public $ret = '';

    public $child = array();

    public $tree_id = 'id';
    public $tree_pid = 'pid';

    public function __construct()
    {
        $this->_table = 'xigua_ho_cat';
        $this->_pk = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }


    public function fetch_pid_by_catid($cat_id)
    {
        $pid = DB::result_first('SELECT pid FROM %t WHERE `id`=%d', array(
            $this->_table,
            $cat_id
        ));
        return $pid;
    }

    public function format_filter($cat_id)
    {
        $pid = $this->fetch_pid_by_catid($cat_id);
        $vars = hb_vars($cat_id, $pid);
        $conds = $_filter = array();

        foreach (array_filter(explode('__', trim($_GET['filter']))) as $index => $item) {
            list($varid, $val) = explode('_', $item);
            $vt = $vars[$varid]['title'];

            $htmlaty = array();
            $extra = trim($vars[$varid]['extra']);
            foreach (array_filter(explode("\n", $extra)) as $index1 => $item1) {
                list($tmp1, $tmp2) = explode('=', trim($item1));
                $htmlaty[$tmp1] = $tmp2;
            }

            if($vars[$varid]['type']=='selects'){
                $conds[] = ' vars LIKE \'%'.stripsearchkey($htmlaty[$val]).'%\'';
            }else{
                $_filter[$varid] = array(
                    'title' => $vt,
                    'value' => $val,
                    'html'  => $htmlaty[$val]
                );
                $conds[] = ' vars LIKE \'%'.stripsearchkey(serialize($_filter[$varid])).'%\'';
            }
        }

        $sql = '';
        if($conds){
            $sql = '('.implode(' AND ', $conds).')';
        }
        return $sql;
    }

    public function fetch_by_name($name)
    {
        $res = DB::fetch_first('SELECT id,pid FROM %t WHERE `name`=%s', array(
            $this->_table,
            $name
        ));
        if($res['pid'] && $res['id']){
            return array($res['id']);
        }elseif(!$res['pid'] && $res['id']){
            $tds = $this->get_childs_by_pids($res['id']);
            $ret = array($res['id']);
            foreach ($tds as $index => $td) {
                $ret[] = $td['id'];
            }
            return $ret;
        }else{
            return array();
        }
    }

    public function count_by_page(){
        $result = DB::result_first(
            'SELECT count(*) FROM %t  WHERE pid=0 ',
            array($this->_table)
        );
        return $result;
    }

    public function fetch_all_by_page($start_limit , $lpp){
        $result = DB::fetch_all(
            "SELECT * FROM %t  WHERE pid=0  ORDER BY o ASC,id ASC " . DB::limit($start_limit, $lpp),
            array(
                $this->_table,
            ),
            $this->_pk
        );

        $sub_result = DB::fetch_all(
            "SELECT * FROM %t  WHERE pid in(%n)  ORDER BY o ASC,id ASC ",
            array(
                $this->_table,
                array_keys($result),
            ),
            $this->_pk
        );

        return array_merge($result, $sub_result);
    }

    public function list_all($simple = 0, $indexkey = false)
    {
        global $_G;
        if($simple){
            $field = 'id,pid,name';
        }else{
            $field = '*';
        }
        $where = '';
        if(!$simple){
            $where = ' WHERE isshow=0 ';
        }
        $rs = DB::fetch_all("SELECT $field FROM %t $where ORDER BY o ASC,id ASC", array($this->_table), $this->_pk);

        if(!$indexkey){
            $rs = array_values($rs);
        }
        return $rs;
    }

    public function list_by_pushtype()
    {
        return DB::fetch_all("SELECT id,name,icon,pushtype FROM %t WHERE pushtype!='' ORDER BY o ASC,id ASC LIMIT 10", array($this->_table));
    }

    public function list_by_pid($pid = 0, $notshow = 0)
    {
        $where = '';
        if($notshow){
            $where = ' AND isshow=0 ';
        }
        $ret = DB::fetch_all("SELECT * FROM %t WHERE (pid=%d OR id=%d) $where ORDER BY o ASC,id ASC", array(
            $this->_table,
            $pid,
            $pid,
        ));
        $_G = $GLOBALS['_G'];

        $return = array();
        foreach ($ret as $index => $item) {
            if(!$item['icon']){
                $item['icon'] = $_G['siteurl'].'source/plugin/xigua_hb/static/img/icon.png';
            }

            if($item['apprice']> 0 && (IN_MAGAPP || IN_APPBYME ||IN_QIANFAN )){
                if(intval($item['apprice']*100) == 3){
                    $item['apprice'] = 0;
                }
                $item['price'] = $item['apprice'];
            }

            $return[$item['id']] = $item;
        }


        return $return;
    }

    public function list_by_pid_light($pid = 0)
    {
        return DB::fetch_all("SELECT id,pid,`name`,adlink,cat_link FROM %t WHERE pid=%d  ORDER BY o ASC,id ASC", array(
            $this->_table,
            $pid,
        ));
    }

    /*
    public function formact($res){global $_G;$vt = array();$var = '';$form = $_GET['form'];if($form['vars']) {$cat = C::t('#xigua_hb#xigua_hb_cat')->get_pid_by_childs(array($form['catid']));$vars = hb_vars($cat['id'], $cat['pid']);foreach ($vars as $index => $vvar) {if($vvar['title'] ==''){$vt =$vvar;$var = $form['vars'][$index];break;}}if($vt){$html = '';foreach (explode("\n", trim($vt['extra'])) as $str => $extra_string) {list($_tmp1, $_tmp2) = explode('=', trim($extra_string));$_tmp2 = trim($_tmp2);if($_tmp1 == $var){$html = $_tmp2;break;}}list($fid, $sortname, $types) = explode(',', $res['fid']);$res['fid'] = $fid.','.$sortname.','.$html;}}return $res;}*/

    public function fetch_by_catid($catid = 0)
    {
        $_G = $GLOBALS['_G'];
        $item = parent::fetch($catid);
        if($item){
            $item['icon'] = $_G['siteurl'].'source/plugin/xigua_hb/static/img/icon.png';
        }
        return $item;
    }

    public function fetchs_light($catids = array())
    {
        return DB::fetch_all("SELECT id,name FROM %t WHERE id IN(%n)", array($this->_table, $catids), $this->_pk);
    }

    public function get_childs_by_pids($pids){
        $childs = DB::fetch_all("SELECT id,pid,`name` FROM %t WHERE pid IN (%n) ORDER BY o ASC,id ASC", array(
            $this->_table,
            $pids
        ));
        return $childs;
    }

    public function get_pid_by_childs($childids){
        $childs = DB::fetch_first("SELECT id,pid FROM %t WHERE id IN (%n)", array(
            $this->_table,
            $childids
        ));
        return $childs;
    }

    public function do_delete($id)
    {
        $has = DB::fetch_first('SELECT pid FROM %t WHERE pid=%d', array(
            $this->_table,
            $id
        ));
        if($has){
//            return false;
        }
        return $this->delete($id);
    }

    public function do_pushtype($id, $pushtype)
    {
        $r = DB::query("UPDATE %t SET pushtype=%s WHERE id=%d", array(
            $this->_table,
            $pushtype,
            $id
        ));
        if(!$r){
            $r = DB::query("UPDATE %t SET pushtype=%s WHERE id=%d", array(
                $this->_table,
                '',
                $id
            ));
        }
        return $r;
    }

    public function init($arr = array()) {
        $this->arr = $arr;
        $this->ret = '';
        return is_array($arr);
    }

    public function get_parent($myid) {
        $newarr = array();
        if (!isset($this->arr[$myid]))
            return false;
        $pid = $this->arr[$myid][$this->tree_pid];
        $pid = $this->arr[$pid][$this->tree_pid];
        if (is_array($this->arr)) {
            foreach ($this->arr as $id => $a) {
                if ($a[$this->tree_pid] == $pid)
                    $newarr[$id] = $a;
            }
        }
        return $newarr;
    }

    public function get_child($myid) {
        $a = $newarr = array();
        if (is_array($this->arr)) {
            foreach ($this->arr as $id => $a) {
                if ($a[$this->tree_pid] == $myid)
                    $newarr[$id] = $a;
            }
        }
        return $newarr ? $newarr : false;
    }

    public function get_all_child($myid) {
        $number = 1;
        $child = $this->get_child($myid);
        if (is_array($child)) {
            $total = count($child);
            foreach ($child as $id => $value) {
                $this->child[]= $value;
                $this->get_all_child($value[$this->tree_id]);
                $number++;
            }
        }
        return $this->child;
    }

    public function get_pos($myid, &$newarr) {
        $a = array();
        if (!isset($this->arr[$myid]))
            return false;
        $newarr[] = $this->arr[$myid];
        $pid = $this->arr[$myid][$this->tree_pid];
        if (isset($this->arr[$pid])) {
            $this->get_pos($pid, $newarr);
        }
        if (is_array($newarr)) {
            krsort($newarr);
            foreach ($newarr as $v) {
                $a[$v[$this->tree_id]] = $v;
            }
        }
        return $a;
    }

    public function get_tree_array($myid) {
        $retarray = array();
        $child = $this->get_child($myid);
        if (is_array($child)) {
            $total = count($child);
            foreach ($child as $id => $value) {
                @extract($value);
                $retarray[$id] = $value;
                $retarray[$id]["child"] = $this->get_tree_array($id, '');
            }
        }
        return $retarray;
    }

    private function have($list, $item) {
        return(strpos(',,' . $list . ',', ',' . $item . ','));
    }

    public function list_json()
    {
        $result = DB::fetch_all("SELECT id,pid,`name`,id as code FROM %t ORDER BY o ASC,id ASC", array($this->_table));
        foreach ($result as $index => $item) {
            $result[$index]['oname'] = $item['name'];
            $result[$index]['name'] = diconv($item['name'], CHARSET, 'utf-8');
        }
        return $result;
    }
}