<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_ho_needlog extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_ho_needlog';
        $this->_pk = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function fetch_logs($needid, $type)
    {
        $limit = 50;
        $wherearr = array();
        $wherearr[] = 'needid='.intval($needid);
        $wherearr[] = 'type=\''.daddslashes($type).'\'';
        $result = $this->fetch_all_by_where($wherearr, 0 , $limit, 'chujia DESC', 'id,uid,crts,upts,needid,need_uid,status,type,chujia,payts');
        $uids = array();
        foreach ($result as $index => $item) {
            $uids[] = $item['uid'];
        }
        if($uids){
            global $levels;
            $shifus = DB::fetch_all('select uid,level,realname,avatar from %t where uid in (%n)', array('xigua_ho_shifu', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['shifu'] = $shifus[$item['uid']];
                $firstname = substr(diconv($result[$index]['shifu']['realname'], CHARSET, 'utf-8'), 0, 3);
                $firstname = diconv($firstname, 'utf-8', CHARSET);
                $result[$index]['shifu']['realname'] = $firstname.'**';
                $chj = floatval($result[$index]['chujia']);
                $lastchj = substr($chj, 0, 1);
                $result[$index]['chujia'] = str_pad($lastchj, strlen($chj),'*', STR_PAD_RIGHT);
                $result[$index]['level_str'] = $levels[$shifus[$item['uid']]['level']];
            }
        }
        return $result;
    }

    public function fetch_fuwu_logs($fuwuid)
    {
        $limit = 50;
        $wherearr = array();
        $wherearr[] = 'fuwuid='.intval($fuwuid);
        $result = $this->fetch_all_by_where($wherearr, 0 , $limit, 'id DESC', 'id,uid,crts,upts,fuwuid,need_uid');
        $uids = array();
        foreach ($result as $index => $item) {
            $uids[] = $item['need_uid'];
        }
        if($uids){
            global $levels;
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['username'] = $users[$item['need_uid']]['username'];
            }
        }
        return $result;
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'id DESC', $fields= '*', $needuser = 0)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        $uids = array();
        foreach ($result as $index => $item) {
            $uids[] = $item['need_uid'];
            $result[$index] = $this->prepare($item);
        }
        if($needuser && $uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            $hbusers = DB::fetch_all('SELECT uid,mobile FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['need_username'] = $users[$item['need_uid']]['username'];
                $result[$index]['mobile'] = $hbusers[$item['need_uid']]['mobile'];
            }
        }
        return $result;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i', $v['upts']) : '';
        }
        return $v;
    }

    public function fetch_by_uid($uid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
        $v = self::prepare($v);
        return $v;
    }
    public function fetch_count_all_uid($uid, $needid)
    {
        $v = DB::result_first("SELECT  count(*) FROM %t WHERE uid=%d AND needid=%d ", array($this->_table, $uid, $needid));
        return $v;
    }
    public function fetch_used_count_by_uid($uid, $needid, $date)
    {
        $v = DB::result_first("SELECT  count(*) FROM %t WHERE uid=%d AND needid=%d AND `usedate`=%s AND hxstatus=1 ", array($this->_table, $uid, $needid, $date));
        return $v;
    }
    public function fetch_by_uid_needid($uid, $needid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND needid=%d AND status IN(-1,1,3,4)", array($this->_table, $uid, $needid));
        return $v;
    }
    public function fetch_by_needid_status($needid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE status IN(3) AND needid=%d ", array($this->_table, $needid));
        return $v;
    }
    public function fetch_count_by_uid($_uid, $type = 'yikou')
    {
        if(!$type){
            $return = DB::result_first('SELECT count(*) FROM %t WHERE uid=%d AND status IN(-1,1,3)', array($this->_table, $_uid));
        }else{
            $return = DB::result_first('SELECT count(*) FROM %t WHERE uid=%d AND `type`=%s AND status IN(-1,1,3)', array($this->_table, $_uid, $type));
        }
        return $return;
    }

    public function cancel_order($id, $val)
    {
        global $SCRITPTNAME, $_G, $ho_config;
        $r = lang('plugin/xigua_ho', 'r');
        $day = lang('plugin/xigua_ho', 'day');
        $href = $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=order&status=2";
        if($val['needid']) {
            $this->update($id, array('status' => 2, 'upts' => TIMESTAMP));

            $order_cancel = lang('plugin/xigua_ho', 'order_cancel');
            $needinfo = unserialize($val['needinfo']);
            $title = $needinfo['city'] . $needinfo['dist'] . $needinfo['addr'] . ' ' /*. "{$needinfo['title']}/{$needinfo['neednum']}$r/{$needinfo['needays']}$day"*/;
            notification_add($val['uid'], 'system', $order_cancel, array('title' => $title, 'href' => $href), 1);
        }elseif($val['fuwuid']){
            $this->update($id, array('status' => 2, 'upts' => TIMESTAMP));

            $order_cancel = lang('plugin/xigua_ho', 'order_cancel2');
            $fuwuinfo = unserialize($val['fuwuinfo']);
            $title = $fuwuinfo['title'];
            $user = getuserbyuid($val['need_uid']);
            notification_add($val['uid'], 'system', $order_cancel, array('title' => $title, 'href' => $href, 'username' => $user['username']), 1);
        }
        $user = C::t('#xigua_hb#xigua_hb_user')->fetch($val['uid']);
        if($ho_config['order_cancel'] && $user['mobile']){
            $this->hb_sendsms($user['mobile'], $ho_config['order_cancel'], array('title' => $title,));
        }
        return true;
    }

    public function confirm_order($id, $val)
    {
        global $SCRITPTNAME, $_G, $ho_config;
        $r = lang('plugin/xigua_ho', 'r');
        $day = lang('plugin/xigua_ho', 'day');
        if($val['needid']){
            $order_confirm = lang('plugin/xigua_ho', 'order_confirm');
            $needinfo = unserialize($val['needinfo']);
            $title = $needinfo['city'] .$needinfo['dist'] . $needinfo['addr'] .' '/*. "{$needinfo['title']}/{$needinfo['neednum']}$r/{$needinfo['needays']}$day"*/;
            $this->update($id, array('status'=>1, 'upts' => TIMESTAMP));
            DB::update($this->_table, array('status'=>2, 'upts' => TIMESTAMP), 'needid='.intval($val['needid']) .' AND id!='.$id );
            DB::update('xigua_ho_need', array('status'=>8), 'id='.intval($val['needid']) );
            $href = $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=order&status=1";
            notification_add($val['uid'],'system', $order_confirm, array('title' => $title, 'href' => $href),1);

            $user = C::t('#xigua_hb#xigua_hb_user')->fetch($val['uid']);
            if($ho_config['order_confirm'] && $user['mobile']){
                $this->hb_sendsms($user['mobile'], $ho_config['order_confirm'], array('title' => cutstr($title, 30),));
            }
        }elseif ($val['fuwuid']){
            $this->update($id, array('status' => 1, 'upts' => TIMESTAMP));
        }
        return true;
    }

    public function confirm_complete($id, $val)
    {
        global $SCRITPTNAME, $_G;
        $r = lang('plugin/xigua_ho', 'r');
        $day = lang('plugin/xigua_ho', 'day');
        $order_confirm = lang('plugin/xigua_ho', 'order_complete');
        $jiedanshutip = lang('plugin/xigua_ho', 'jiedanshutip');
        if($val['needid']){
            $needinfo = unserialize($val['needinfo']);
            $title = $needinfo['city'] .$needinfo['dist'] . $needinfo['addr'] .' '. "{$needinfo['title']}";
            if($val['type']=='yikou'){
                $allp = $needinfo['totalprice'];
            }elseif($val['type']=='jingjia'){
                $allp = $val['chujia'];
            }
        }elseif($val['fuwuid']){
            $fuwuinfo = unserialize($val['fuwuinfo']);
            $title = $fuwuinfo['title'];
            $allp = $fuwuinfo['dingprice'];
        }
        $href = $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=order&status=3";
        $this->update($id, array('status'=>3, 'upts' => TIMESTAMP, 'confirmts' => TIMESTAMP));

        $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($val['uid']);
        $shifu['jiedannum']++;
        C::t('#xigua_ho#xigua_ho_shifu')->update($shifu['id'], array('jiedannum'=>$shifu['jiedannum']));
        global $levels;
        $tmplevel = null;
        $rlevels = array_reverse($levels, true);
        foreach ($rlevels as $index => $level) {
            if($shifu['jiedannum']>= $level['autonum']){
                $tmplevel = $index;
                break;
            }
        }
        if($tmplevel!==null && $tmplevel!=$shifu['level']){
            C::t('#xigua_ho#xigua_ho_shifu')->update($shifu['id'], array('level'=>$tmplevel));
            $leveltmp = $levels[$tmplevel];
            notification_add($val['uid'],'system', $jiedanshutip, array('num' => $shifu['jiedannum'], 'name' => $leveltmp['name'], 'href' => $href),1);
        }
        if(!$leveltmp){
            $leveltmp = $levels[$shifu['level']];
        }
        $prate = intval(str_replace('%', '', $leveltmp['prate']))/100;
        $shouxufei = round($allp*$prate, 2);
        $income = $allp-$shouxufei;
        $ret = $this->fetch($id);
        if($income>0 && ($ret['payts']>0||$needinfo['payts']>0)){
            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                'uid' => $val['uid'],
                'crts' =>TIMESTAMP,
                'size' => $income,
                'note' => str_replace(array('{title}', '{shouxufei}', '{totalprice}',), array( $title, $shouxufei, $income, ), strip_tags($order_confirm)),
                'link' => $href,
            ));
            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($val['uid'], 'money', $income);
            $datavars = array('title' => $title, 'href' => $href, 'shouxufei'=>$shouxufei, 'totalprice'=> $income);
            notification_add($val['uid'],'system', $order_confirm, $datavars,1);
            $ho_config = $_G['cache']['plugin']['xigua_ho'];

            $user = C::t('#xigua_hb#xigua_hb_user')->fetch($val['uid']);
            if($ho_config['order_complete'] && $user['mobile']){
                unset($datavars['href']);
                $this->hb_sendsms($user['mobile'], $ho_config['order_complete'], $datavars);
            }
        }else{
            $datavars = array('title' => $title, 'href' => $href, 'shouxufei'=> $shouxufei, 'totalprice'=> 0);
            notification_add($val['uid'],'system', $order_confirm, $datavars,1);
        }
        return true;
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $field = '*', $orderby = 'id DESC', $key_field = '')
    {
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }else{
            $orderby = '';
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql $orderby " . DB::limit($start_limit, $lpp));
        $return = array();
        foreach ($result as $index => $item) {
            if($key_field){
                $return[$item[$key_field]] = $item;
            }else{
                $return[$index] = $item;
            }
        }
        return $return;
    }
    public function do_delete($id)
    {
        return $this->delete($id);
    }

    function hb_sendsms($mobile, $smsTemplateCode = '', $vars = array()){
        global $config;
        if(!($config['smsAppKey'] && $config['smssecretKey'] && $config['smsFreeSignName'] && $smsTemplateCode)){
            return false;
        }
        if (version_compare(phpversion(), '5.3', '<')) {
            return 'php version ('.phpversion().') isn\'t high enough';
        }
        include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/lib/alisms/api_demo/SmsDemo.php';
        $demo = new SmsDemo(
            $config['smsAppKey'],
            $config['smssecretKey']
        );
        try {
            $response = $demo->sendSms(diconv($config['smsFreeSignName'], CHARSET, 'utf-8'),
                $smsTemplateCode,
                $mobile,
                $vars
            );
            $response = (array)$response;
            if ($response['Code'] != 'OK') {
                $res = diconv($response['Message'], 'utf-8', CHARSET) . $response['Code'];
            } else {
                $res = '';
            }
        } catch (Exception $e) {
            $res = var_export($e->getMessage(), true);
        }
        if($res){
            hb_message($res, 'error', 'reload');
        }
        return $res;
    }
}