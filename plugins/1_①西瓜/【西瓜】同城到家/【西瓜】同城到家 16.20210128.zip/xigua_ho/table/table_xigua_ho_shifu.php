<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_ho_shifu extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_ho_shifu';
        $this->_pk = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function get_next($id)
    {
        $rskey = $this->_pk;
        return DB::result_first("select $rskey from %t WHERE $rskey<%d order by $rskey desc", array(
            $this->_table,
            $id
        ));
    }

    public function fetch_by_id($id)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE id=%d', array($this->_table, $id));
        return self::_prepare($first);
    }

    public function fetch_by_uids($uids, $fields = '*', $keyfield = 'uid')
    {
        $return = array();
        $result = DB::fetch_all("SELECT $fields FROM %t WHERE uid IN (%n)", array($this->_table, $uids), $keyfield);
        foreach ($result as $index => $item) {
            if($keyfield){
                $return[$item[$keyfield]] = self::_prepare($item);
            }else{
                $return[$index] = self::_prepare($item);
            }
        }
        return $return;
    }
    public function fetch_by_uid($uid)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE uid=%d', array($this->_table, $uid));
        return self::_prepare($first);
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $field = '*', $orderby = 'upts DESC', $key_field = '')
    {
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }else{
            $orderby = '';
        }
        global $ho_config;
        if($ho_config['showfz'] && is_array($wherearr) && !defined('IN_ADMINCP')){
            $_stid = intval($_GET['st']);
            $wherearr[] = " (stid=$_stid) ";
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql $orderby " . DB::limit($start_limit, $lpp));
        $return = array();
        foreach ($result as $index => $item) {
            if($key_field){
                $return[$item[$key_field]] = self::_prepare($item);
            }else{
                $return[$index] = self::_prepare($item);
            }
        }
        return $return;
    }

    public function fetch_newest()
    {
        $num = 5;
        $where = array('avatar!=\'\' AND status=1');
        $ob = "$this->_pk DESC";
        return $this->fetch_all_by_page(0,$num, $where, "$this->_pk, realname, avatar, jineng_str", $ob);
    }

    public function fetch_tuijian($num = 0)
    {
        if(!$num){
            $num = 20;
        }
        $where = array('avatar!=\'\' AND status=1 AND tuijian=1');
        $ob = "displayorder DESC, $this->_pk DESC";
        return $this->fetch_all_by_page(0,$num, $where, "$this->_pk, realname, avatar, jineng_str", $ob);
    }

    public function get_order($viewtype)
    {
        global $job_config;
        $field = '*';
        $order_by = ' displayorder DESC, id DESC ';
        switch ($viewtype){
            case "newest":
                $order_by = 'crts DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                $order_by = 'distance ASC, displayorder DESC, id DESC';
                break;
            case 'level':
                $order_by = 'level DESC, displayorder DESC, id DESC';
                break;
            case 'jingyan':
                $order_by = 'jingyan DESC, displayorder DESC, id DESC';
                break;
            case 'jiedannum':
                $order_by = 'jiedannum DESC, displayorder DESC, id DESC';
                break;
            default:
                $order_by = ' displayorder DESC, id DESC ';
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['id']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        if(IS_ADMINID){
            unset($data['uid']);
            return DB::update($this->_table, $data, array(
                'id'  => $id,
            ));
        }else{
            $ret = DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                'id'  => $id,
            ));
            $this->notice_to_admin($data);
            return $ret;
        }
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        $ret = DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
        $this->notice_to_admin($data);
        return $ret;
    }

    public function notice_to_admin($data)
    {
        if($data['status']==-1&&!defined('IN_ADMINCP')){
            $member = getuserbyuid($data['uid']);
            global $_G;
            $hbconfig = $_G['cache']['plugin']['xigua_hb'];
            if($hbconfig['adminids']) {
                $__ds = dintval(explode(',', str_replace(';', ',', trim($hbconfig['adminids']))), true);
                $_adminids = array_slice(array_filter($__ds), 0, 1);
            }
            if($_adminids){
                foreach ($_adminids as $adminid) {
                    notification_add($adminid,'system', lang('plugin/xigua_ho', 'newshifushen'),array(
                        'realname'=>$data['realname'],
                        'username'=>$member['username'],
                        'uid'=>$data['uid'],
                        'mobile'=>$data['mobile'],
                    ),1);
                }
            }
        }
        return true;
    }

    public static function _prepare($item)
    {
        if($item){
            global $levels;
            $item['jineng_ary'] = explode(',', $item['jineng']);
            $item['jineng_str_ary'] = explode(',', $item['jineng_str']);
            $item['album'] = $item['album'] ? unserialize($item['album']) : array();
            $item['is_dig'] = $item['dig_endts']>TIMESTAMP ? 1:0;
            $item['dig_endts_u']  = $item['dig_endts'] ? dgmdate($item['dig_endts'], 'u') : '';
            if(!$item['is_dig'] && $item['dig_endts']){
                DB::query("update %t set dig_startts=0,dig_endts=0 WHERE id=%d", array('xigua_ho_shifu',  $item['id']));
            }
            $item['upts_u']  = dgmdate($item['upts'], 'u');
            $item['crts_u']  = dgmdate($item['crts'], 'u');
            $item['areawant_ary'] = array_filter(explode(',', trim($item['areawant'])));
            $item['areawant_str_ary'] = explode(',', trim($item['areawant_str']));
            $item['level_str'] = $levels[ $item['level']]['name'];
            if($item['distance']){
                $distance = intval($item['distance']);
                if($distance<=1000){
                    $distance = intval($distance). 'm';
                }else if($distance>1000){
                    $distance = round($distance/1000, 1). 'km';
                }
                $item['distance'] = $distance;
            }
        }
        return $item;
    }

    public function incr($id, $field, $num = 1)
    {
        global $_G;
        if(strpos($id, ',')!==false){
            $id = dintval(array_filter(explode(',', $id)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $id));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
        }
    }

    public function total_views()
    {
        global $_G, $config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);

        $key = 'shifu_views'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }

    public function sync_verify()
    {
        global $adminids, $SCRITPTNAME, $_G, $ho_config;
        if($_G['cache']['plugin']['xigua_hr']){
            $formtmp = $_GET['form'];
            if(!$formtmp['zm'][0] && !$formtmp['fm'][0]){
                if($ho_config['mustrz']){
                    hb_message(lang_ho('qscrzzl',0), 'error');
                }
                return false;
            }
            $tmpdata = array();
            $tmpdata['realname'] = $formtmp['realname'];
            $tmpdata['idcard'] = '';
            $tmpdata['mobile'] = $formtmp['mobile'];
            $tmpdata['zm'] = $formtmp['zm'][0];
            $tmpdata['fm'] = $formtmp['fm'][0];
            $tmpdata['verinfo'] = $formtmp['jieshao'];
            $tmpdata['upts'] = TIMESTAMP;
            $tmpdata['ct']  = 1;
            $tmpdata['status']  = 2;
            if($old_data = C::t('#xigua_hr#xigua_hr_verify')->fetch_verify_by_uid($_G['uid'], $tmpdata['ct'])){
                if($old_data['uid']!=$_G['uid'] && !IS_ADMINID){
                    return false;
                }
                if($old_data['lock'] || ($tmpdata['zm']==$old_data['zm']  && $tmpdata['fm']==$old_data['fm'])){
                    return false;
                }
                $r = C::t('#xigua_hr#xigua_hr_verify')->update($old_data['id'], $tmpdata);
            }else{
                $tmpdata['crts'] = TIMESTAMP;
                $tmpdata['uid'] = $_G['uid'];
                $r = C::t('#xigua_hr#xigua_hr_verify')->insert($tmpdata);
            }
            if($r){
                if($adminids){
                    foreach ($adminids as $adminid) {
                        notification_add($adminid,'system', lang('plugin/xigua_hr', 'notice_shen'),array(
                            'ct' => $tmpdata['ct']==2?lang('plugin/xigua_hr',  'qy'):lang('plugin/xigua_hr', 'gr') ,
                            'user'=>$_G['username']
                        ),1);
                    }
                }
            }
        }
        return false;
    }

    public function notice_to_shifu($needid, $title, $catid, $username)
    {
        global $_G,$SCRITPTNAME,$urlext;
        $shifus = DB::fetch_all('select uid from %t where status=1 and FIND_IN_SET(%d, jineng) limit 100', array($this->_table, $catid));
        $href = $_G['siteurl']."{$SCRITPTNAME}?id=xigua_ho&ac=view&needid={$needid}{$urlext}";
        foreach ($shifus as $touida) {
            if($touid = $touida['uid']){
                notification_add($touid,'system', lang('plugin/xigua_ho', 'newxuqiu'),array(
                    'info'=>$title,
                    'username'=>$username,
                    'href'=>$href,
                ),1);
            }
        }
        return true;
    }
}