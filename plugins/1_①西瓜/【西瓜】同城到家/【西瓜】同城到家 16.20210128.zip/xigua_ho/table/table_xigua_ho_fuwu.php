<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_ho_fuwu extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_ho_fuwu';
        $this->_pk = 'id';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function get_next($id)
    {
        $rskey = $this->_pk;
        return DB::result_first("select $rskey from %t WHERE $rskey<%d order by $rskey desc", array(
            $this->_table,
            $id
        ));
    }

    public function fetch_by_id($id)
    {
        $first = DB::fetch_first('SELECT * FROM %t WHERE id=%d', array($this->_table, $id));
        $this->incr($id, 'views', 1);
        return self::_prepare($first);
    }

    public static function _prepare($item)
    {
        if($item){
            $item['jineng_ary'] = explode(',', $item['jineng']);
            $item['jineng_str_ary'] = explode(',', $item['jineng_str']);
            $item['album'] = $item['album'] ? unserialize($item['album']) : array();
            $item['is_dig'] = $item['dig_endts']>TIMESTAMP ? 1:0;
            $item['dig_endts_u']  = $item['dig_endts'] ? dgmdate($item['dig_endts'], 'u') : '';
            if(!$item['is_dig'] && $item['dig_endts']){
                DB::query("update %t set dig_startts=0,dig_endts=0 WHERE id=%d", array('xigua_ho_shifu',  $item['id']));
            }
            $item['upts_u']  = dgmdate($item['upts'], 'u');
            $item['crts_u']  = dgmdate($item['crts'], 'u');
            $item['areawant_ary'] = array_filter(explode(',', trim($item['areawant'])));
            $item['areawant_str_ary'] = explode(',', trim($item['areawant_str']));
            if($item['distance']){
                $distance = intval($item['distance']);
                if($distance<=1000){
                    $distance = intval($distance). 'm';
                }else if($distance>1000){
                    $distance = round($distance/1000, 1). 'km';
                }
                $item['distance'] = $distance;
            }
            $item['price'] = floatval($item['price']);
            if(!$item['dingjin_open']){
                $item['dingprice'] = 0;
            }else{
                $item['dingprice'] = floatval($item['dingprice']);
            }
        }
        return $item;
    }

    public function fetch_by_uids($uids, $fields = '*', $keyfield = 'uid')
    {
        $return = array();
        $result = DB::fetch_all("SELECT $fields FROM %t WHERE uid IN (%n)", array($this->_table, $uids), $keyfield);
        foreach ($result as $index => $item) {
            if($keyfield){
                $return[$item[$keyfield]] = self::_prepare($item);
            }else{
                $return[$index] = self::_prepare($item);
            }
        }
        return $return;
    }

    public function fetch_newest()
    {
        $num = 5;
        $where = array('status=1');
        $ob = "$this->_pk DESC";
        return $this->fetch_all_by_page(0,$num, $where, "$this->_pk,  jineng_str", $ob);
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $field = '*', $orderby = 'upts DESC', $key_field = '')
    {
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }else{
            $orderby = '';
        }
        global $ho_config;
        if($ho_config['showfz'] && is_array($wherearr) && !defined('IN_ADMINCP')){
            $_stid = intval($_GET['st']);
            $wherearr[] = " (stid=$_stid) ";
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql $orderby " . DB::limit($start_limit, $lpp));
        $return = array();
        foreach ($result as $index => $item) {
            if($key_field){
                $return[$item[$key_field]] = self::_prepare($item);
            }else{
                $return[$index] = self::_prepare($item);
            }
        }
        return $return;
    }

    public function fetch_tuijian()
    {
        $num = 5;
        $where = array('status=1 AND tuijian=1');
        $ob = "displayorder DESC, $this->_pk DESC";
        return $this->fetch_all_by_page(0,$num, $where, "$this->_pk, jineng_str", $ob);
    }

    public function get_order($viewtype)
    {
        $field = '*';
        switch ($viewtype){
            case "newest":
                $order_by = '(dig_endts-dig_startts) DESC, upts DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                $order_by = 'distance ASC, displayorder DESC, id DESC';
                break;
            default:
                $order_by = ' displayorder DESC,(dig_endts-dig_startts) DESC, upts DESC ';
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['id']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        if(IS_ADMINID){
            unset($data['uid']);
            return DB::update($this->_table, $data, array(
                'id'  => $id,
            ));
        }else{
            $ret = DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                'id'  => $id,
            ));
            $this->notice_to_admin($data);
            return $ret;
        }
    }

    public function notice_to_admin($data)
    {
        if($data['status']==-1&&!defined('IN_ADMINCP')){
            $member = getuserbyuid($data['uid']);
            global $_G;
            $hbconfig = $_G['cache']['plugin']['xigua_hb'];
            if($hbconfig['adminids']) {
                $__ds = dintval(explode(',', str_replace(';', ',', trim($hbconfig['adminids']))), true);
                $_adminids = array_slice(array_filter($__ds), 0, 1);
            }
            if($_adminids){
                foreach ($_adminids as $adminid) {
                    notification_add($adminid,'system', lang('plugin/xigua_ho', 'newfuwushen'),array(
                        'title'=>$data['title'],
                        'username'=>$member['username'],
                        'uid'=>$data['uid'],
                    ),1);
                }
            }
        }
        return true;
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        $ret = DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
        $this->notice_to_admin($data);
        return $ret;
    }

    public function incr($id, $field, $num = 1)
    {
        global $_G;
        if(strpos($id, ',')!==false){
            $id = dintval(array_filter(explode(',', $id)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $id));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
        }
    }
    public function fetch_count_by_uid($_uid)
    {
        $return = DB::result_first('SELECT count(*) FROM %t WHERE uid=%d', array($this->_table, $_uid));
        return $return;
    }
}