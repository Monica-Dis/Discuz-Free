<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/1/23
 * Time: 17:20
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_ho_cat` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `fid` varchar(20) NOT NULL,
 `in_ad` varchar(800) NOT NULL,
 `in_adlnk` varchar(800) NOT NULL,
 `isshow` int(11) NOT NULL,
 `multiprice` varchar(2000) NOT NULL,
 `tpl` varchar(20) NOT NULL,
 `telpri` decimal(10,2) NOT NULL,
 `groups` varchar(800) NOT NULL,
 `verify1` int(11) NOT NULL,
 `verify2` int(11) NOT NULL,
 `bao` int(11) NOT NULL,
 `maxdig` int(11) NOT NULL,
 `apprice` decimal(10,2) NOT NULL DEFAULT '0.00',
 `share_title` varchar(200) NOT NULL,
 `share_desc` varchar(200) NOT NULL,
 `share_pic` varchar(200) NOT NULL,
 `cat_link` varchar(200) NOT NULL,
 `zdprice` varchar(800) NOT NULL,
 `jiaobiao` varchar(20) NOT NULL,
 `color` varchar(10) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `isshow` (`isshow`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_ho_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `share_title` varchar(200) NOT NULL,
 `share_desc` varchar(200) NOT NULL,
 `share_pic` varchar(200) NOT NULL,
 `showindex` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `stids` (`stids`(255)),
 KEY `showindex` (`showindex`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_ho_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_ho_need` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `catid` int(11) NOT NULL,
 `type` varchar(20) NOT NULL,
 `uid` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '1:wait  -2:notpay 2:haspay',
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `title` varchar(80) NOT NULL,
 `level` int(11) NOT NULL,
 `neednum` int(11) NOT NULL,
 `needays` int(11) NOT NULL,
 `vars` text NOT NULL,
 `description` text NOT NULL,
 `album` varchar(2000) NOT NULL,
 `addr` varchar(500) NOT NULL,
 `lat` varchar(20) NOT NULL,
 `lng` varchar(20) NOT NULL,
 `dist1` varchar(80) NOT NULL,
 `dist2` varchar(80) NOT NULL,
 `dist3` varchar(80) NOT NULL,
 `street` varchar(80) NOT NULL,
 `street_number` varchar(80) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `dig_startts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `dig_days` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `zans` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `follows` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `orderid` varchar(32) NOT NULL,
 `payts` int(11) NOT NULL,
 `jdstatus` int(11) NOT NULL DEFAULT '-1',
 `bxtype` int(11) NOT NULL,
 `bxnum` int(11) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `totalprice` decimal(10,2) NOT NULL,
 `gongzi` decimal(10,2) NOT NULL,
 `bxprice` decimal(10,2) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `realname` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `stid` (`stid`),
 KEY `status` (`status`),
 KEY `lat` (`lat`),
 KEY `lng` (`lng`),
 KEY `province` (`dist1`),
 KEY `city` (`dist2`),
 KEY `district` (`dist3`),
 KEY `displayorder` (`displayorder`),
 KEY `uid` (`uid`),
 KEY `dig_startts` (`dig_startts`,`dig_endts`),
 KEY `catid` (`catid`),
 KEY `upts` (`upts`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_ho_needlog` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `needid` int(11) NOT NULL,
 `need_uid` int(11) NOT NULL,
 `status` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `needinfo` text NOT NULL,
 `type` varchar(20) NOT NULL,
 `chujia` decimal(10,2) NOT NULL,
 `payts` int(11) NOT NULL,
 `confirmts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `stid` (`stid`),
 KEY `uid` (`uid`),
 KEY `needid` (`needid`),
 KEY `need_uid` (`need_uid`),
 KEY `chujia` (`chujia`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_ho_shifu` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `displayorder` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `level` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '-1:wait 1:normal  -2:notpay',
 `realname` varchar(80) NOT NULL,
 `gender` int(11) NOT NULL,
 `avatar` varchar(200) NOT NULL,
 `addr` varchar(500) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `province` varchar(80) NOT NULL,
 `city` varchar(80) NOT NULL,
 `district` varchar(80) NOT NULL,
 `street` varchar(80) NOT NULL,
 `street_number` varchar(80) NOT NULL,
 `lat` varchar(20) NOT NULL,
 `lng` varchar(20) NOT NULL,
 `shname` varchar(200) NOT NULL,
 `shid` int(11) NOT NULL,
 `jineng` varchar(80) NOT NULL,
 `jineng_str` varchar(1000) NOT NULL,
 `jingyan` int(11) NOT NULL,
 `areawant` varchar(80) NOT NULL,
 `areawant_str` varchar(800) NOT NULL,
 `jieshao` text NOT NULL,
 `album` varchar(2000) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `dig_startts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `dig_days` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `jiedannum` int(11) NOT NULL,
 `fadannum` int(11) NOT NULL,
 `score` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `zans` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `follows` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `tuijian` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `stid` (`stid`),
 KEY `status` (`status`),
 KEY `lat` (`lat`),
 KEY `lng` (`lng`),
 KEY `province` (`province`),
 KEY `city` (`city`),
 KEY `district` (`district`),
 KEY `displayorder` (`displayorder`),
 KEY `uid` (`uid`),
 KEY `dig_startts` (`dig_startts`,`dig_endts`),
 KEY `endts` (`endts`),
 KEY `level` (`level`),
 KEY `jingyan` (`jingyan`),
 KEY `jiedannum` (`jiedannum`),
 KEY `tuijian` (`tuijian`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_ho_var` (
 `pluginvarid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
 `pluginid` varchar(20) NOT NULL DEFAULT '0',
 `displayorder` tinyint(3) NOT NULL DEFAULT '0',
 `title` varchar(100) NOT NULL DEFAULT '',
 `description` varchar(255) NOT NULL DEFAULT '',
 `type` varchar(20) NOT NULL DEFAULT 'text',
 `value` text NOT NULL,
 `extra` text NOT NULL,
 `unitnew` varchar(80) NOT NULL,
 `required` int(11) NOT NULL,
 `unchangeable` int(11) NOT NULL,
 `formsearch` int(11) NOT NULL,
 `placehd` varchar(512) NOT NULL,
 PRIMARY KEY (`pluginvarid`),
 KEY `pluginid` (`pluginid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_ho_fuwu` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `displayorder` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `unit` int(11) NOT NULL,
 `dingjin_open` int(11) NOT NULL,
 `dingprice` decimal(10,2) NOT NULL,
 `yuyue` int(11) NOT NULL,
 `opentime` varchar(80) NOT NULL,
 `title` varchar(200) NOT NULL,
 `shifuid` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '-1:wait 1:normal  -2:notpay',
 `addr` varchar(500) NOT NULL,
 `province` varchar(80) NOT NULL,
 `city` varchar(80) NOT NULL,
 `district` varchar(80) NOT NULL,
 `street` varchar(80) NOT NULL,
 `street_number` varchar(80) NOT NULL,
 `lat` varchar(20) NOT NULL,
 `lng` varchar(20) NOT NULL,
 `shname` varchar(200) NOT NULL,
 `shid` int(11) NOT NULL,
 `jineng` varchar(80) NOT NULL,
 `jineng_str` varchar(1000) NOT NULL,
 `jingyan` int(11) NOT NULL,
 `areawant` varchar(80) NOT NULL,
 `areawant_str` varchar(800) NOT NULL,
 `jieshao` text NOT NULL,
 `album` varchar(2000) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `dig_startts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `dig_days` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `payts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `stid` (`stid`),
 KEY `status` (`status`),
 KEY `displayorder` (`displayorder`),
 KEY `uid` (`uid`),
 KEY `dig_startts` (`dig_startts`),
 KEY `dig_endts` (`dig_endts`),
 KEY `endts` (`endts`)
) ENGINE=InnoDB;

SQL;
if($sql){
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'order_id\'', array('xigua_ho_shifu'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_ho_shifu` ADD `order_id` VARCHAR(40) NOT NULL;
ALTER TABLE `pre_xigua_ho_shifu` ADD `payts` INT(11) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'nocheck\'', array('xigua_ho_cat'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_ho_cat` ADD `nocheck` INT(11) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hidelevel\'', array('xigua_ho_cat'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_ho_cat` ADD `tuij` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_ho_cat` ADD `hidelevel` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_ho_cat` ADD `hideyg` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_ho_cat` ADD `hidetext` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_ho_cat` ADD `hidepic` INT(11) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fuwuid\'', array('xigua_ho_needlog'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_ho_needlog` ADD `fuwuid` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_ho_needlog` ADD `fuwu_uid` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_ho_needlog` ADD `fuwuinfo` TEXT NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'pubtype\'', array('xigua_ho_cat'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_ho_cat` ADD `pubtype` VARCHAR(20) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t where `Field`=\'beizhu\'', array('xigua_ho_needlog'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_ho_needlog` ADD `beizhu` VARCHAR(1000) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t WHERE `Field`=\'area_keys\'', array('xigua_ho_shifu'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_ho_shifu` ADD `area_keys` VARCHAR(2000) NOT NULL;
ALTER TABLE `pre_xigua_ho_shifu` ADD INDEX(`area_keys`);

SQL;
    runquery($sql);
}

@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/install.php');
