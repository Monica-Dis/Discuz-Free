<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!is_file(DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php')) {
	exit('Please install <a href="https://dism.taobao.com/?@xigua_hb.plugin">https://dism.taobao.com/?@xigua_hb.plugin</a>');
}
if (empty($_G['cache']['plugin'])) {
	loadcache('plugin');
}
$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$url = rtrim($url, '/') . '/';
$ho_config = $_G['cache']['plugin']['xigua_ho'];
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_ho/common_status.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_ho/common.php';
global $config;
global $ho_config;
global $_G;
global $ac;
global $do;
global $aclist;
global $aclist_login;
global $page;
global $lpp;
global $start_limit;
global $shid;
define('QMAPZOOM', $ho_config['ditudj']);
$shid = intval($_GET['shid']);
$ac = $_GET['ac'];
$do = $_GET['do'];
$aclist = array('index', 'add', 'my', 'del', 'com', 'join', 'need', 'chosecat', 'next', 'view', 'my_needs', 'need_li', 'search', 'com', 'order', 'order_li', 'needlog', 'shifu', 'cat', 'shifu_li', 'needs', 'googleMap', 'getloc', 'dist_li', 'myfw', 'fw_li', 'fuwu', 'fuwu_li', 'fuwu_list');
$aclist_login = array('add', 'my', 'del', 'join', 'need', 'chosecat', 'next', 'my_needs', 'order', 'order_li', 'needlog', 'myfw');
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
if (in_array($ac, $aclist_login) && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $ho_config['maincolor'];
switch ($ac) {
	case 'index':
		$navtitle = str_replace('{tname}', $stinfo['name'], $ho_config['defaulttitle']);
		$desc = str_replace('{tname}', $stinfo['name'], $ho_config['defaultdesc']);
		$topnavslider = hb_parse_set($ho_config['topslider']);
		$indexstype = ho_set_parse($ho_config['indexstype']);
		$jing_list = $allcat_index = array();
		$allcat = C::t('#xigua_ho#xigua_ho_cat')->list_all();
		foreach ($allcat as $index => $item) {
			if ($item['pid'] == 0 && $item['tuij']) {
				$jing_list[] = $item;
			} else {
				if (count($allcat_index[$item['pid']]) <= 3) {
					$allcat_index[$item['pid']][] = $item;
				}
			}
		}
		if ($jing_list) {
			if (!($numi1 = $config['numi1'])) {
				$numi1 = 5;
			}
			$jing_count = range(0, ceil(count($jing_list) / $numi1) - 1);
		}
		$newset_shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_tuijian();
		$indexmod = array();
		foreach (explode("\n", trim($ho_config['indexmod'])) as $index => $item) {
			list($modindex, $modname) = explode('=', trim($item));
			$indexmod[$modindex] = $modname;
		}
		break;
	case 'join':
		$_key = 'ho_hangye1';
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$listjson = C::t('#xigua_ho#xigua_ho_cat')->list_json();
			C::t('#xigua_ho#xigua_ho_cat')->init($listjson);
			$jsary = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
			savecache($_key, array('variable' => array($listjson, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$listjson = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		$_key = 'hbpubIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
			$distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			$distjsary = array_values($distjsary);
			savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
		} else {
			$distjsary = $_G['cache'][$_key]['variable'][0];
		}
		if (submitcheck('formhash')) {
			$form = $_GET['form'];
			if (!$form['realname']) {
				hb_message(lang_ho('qtxlxr', 0), 'error');
			}
			if (!$form['mobile']) {
				hb_message(lang_ho('qtxsjhm', 0), 'error');
			}
			if (!$form['addr']) {
				hb_message(lang_ho('qtxlxdz', 0), 'error');
			}
			if (!$form['jingyan']) {
				hb_message(lang_ho('qtxfwjyns', 0), 'error');
			}
			if ($form['jineng']) {
				foreach ($listjson as $index => $item) {
					if (in_array($item['code'], $form['jineng'])) {
						$jineng_string_tmp[$item['code']] = $item['oname'];
					}
				}
				foreach ($form['jineng'] as $index => $item) {
					$jineng_string[$item] = $jineng_string_tmp[$item];
				}
				$form['jineng_str'] = implode(',', $jineng_string);
				$form['jineng'] = implode(',', $form['jineng']);
			} else {
				hb_message(lang_ho('min1jineng', 0), 'error');
			}
			if ($form['areawant']) {
				$eqdq = $form['areawant'];
				$areawant_str = $areawant_str_tmp = array();
				$distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
				foreach ($distlist as $index => $item) {
					if (in_array($item['code'], $eqdq)) {
						$areawant_str_tmp[$item['code']] = diconv($item['name'], 'UTF-8', CHARSET);
					}
				}
				foreach ($form['areawant'] as $index => $item) {
					$areawant_str[$item] = $areawant_str_tmp[$item];
				}
				$form['areawant'] = implode(',', $form['areawant']);
				$form['areawant_str'] = implode(',', $areawant_str);
				C::t('#xigua_hb#xigua_hb_district')->init($distlist);
				$distlist_key = array();
				foreach ($distlist as $index => $item) {
					$distlist_key[$item['code']] = $item;
				}
				$tmp_ = array();
				foreach ($eqdq as $index => $item) {
					$_parent = $distlist_key[$distlist_key[$item]['upid']];
					if ($_parent['upid'] > 0) {
						$__parent = $distlist_key[$_parent['upid']];
					}
					$tmp_[] = diconv($__parent['name'] . ' ' . $_parent['name'] . ' ' . $distlist_key[$item]['name'], 'UTF-8', CHARSET);
				}
				$form['area_keys'] = implode(',', $tmp_);
			}
			if ($form['shname'] && $_G['cache']['plugin']['xigua_hs']) {
				$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']);
			}
			include_once DISCUZ_ROOT . 'source/plugin/xigua_ho/include/c_common.php';
			$status = 1;
			if ($ho_config['rz_shen']) {
				$status = 0 - 1;
			}
			if ($ho_config['rzfy'] > 0) {
				$status = 0 - 2;
			}
			$data = array('uid' => $_G['uid'], 'stid' => $form['stid'], 'shid' => $sh['shid'], 'shname' => $form['shname'], 'lat' => $form['lat'], 'lng' => $form['lng'], 'province' => $form['province'], 'city' => $form['city'], 'district' => $form['district'], 'street' => $form['street'], 'street_number' => $form['street_number'], 'realname' => $form['realname'], 'gender' => $form['gender'], 'mobile' => $form['mobile'], 'addr' => $form['addr'], 'jineng' => $form['jineng'], 'jineng_str' => $form['jineng_str'], 'album' => serialize($form['album']), 'areawant' => $form['areawant'], 'areawant_str' => $form['areawant_str'], 'jieshao' => $form['jieshao'], 'jingyan' => $form['jingyan'], 'avatar' => is_array($form['avatar']) ? $form['avatar'][0] : $form['avatar'], 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'area_keys' => $form['area_keys']);
			if ($old_data = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($_G['uid'])) {
				if ($ho_config['rz_shen']) {
					$data['status'] = $status;
					$msg = lang_ho('bccgsc', 0);
				} else {
					$msg = lang_ho('bccg', 0);
				}
				C::t('#xigua_ho#xigua_ho_shifu')->update_G($old_data['id'], $data);
				C::t('#xigua_ho#xigua_ho_shifu')->sync_verify();
				hb_message($msg, 'success', $SCRITPTNAME . '?id=xigua_ho&ac=my&mobile=2' . $urlext);
			} else {
				$data['status'] = $status;
				$newid = C::t('#xigua_ho#xigua_ho_shifu')->insert($data, 1);
				C::t('#xigua_ho#xigua_ho_shifu')->sync_verify();
				if ($status == 0 - 1) {
					hb_message(lang_ho('rzcgsc', 0), 'success', $SCRITPTNAME . '?id=xigua_ho&ac=my&mobile=2' . $urlext);
				} elseif ($status == 0 - 2) {
					$title = $data['realname'] . '_' . lang_ho('ruzhu', 0);
					$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_ho&ac=my' . $urlext);
					$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $ho_config['rzfy'], $title, 'common_ruzhusf', array('data' => array('newid' => $newid, 'newdata' => $data), 'callback' => array('file' => 'source/plugin/xigua_ho/function.php', 'method' => 'ho_common_ruzhusf'), 'location' => $rtl, 'referer' => $rtl));
					$rl = urlencode($rtl);
					$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext);
					C::t('#xigua_ho#xigua_ho_shifu')->update($newid, array('order_id' => $order_id, 'payts' => 0));
					hb_message(lang_ho('jumppay', 0), 'loading', $jumpurl);
				} else {
					hb_message(lang_ho('rzcg', 0), 'success', $SCRITPTNAME . '?id=xigua_ho&ac=my&mobile=2' . $urlext);
				}
			}
		} else {
			$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			$lastrealname = $user['realname'];
			$lastmobile = $user['mobile'];
			if ($_GET['type'] == 'sh') {
				$navtitle = lang_ho('qyrz', 0);
			} else {
				$navtitle = lang_ho('grsfrz', 0);
			}
			if ($_G['cache']['plugin']['xigua_hs']) {
				$sh = ho_get_shs_by_uid();
			}
			$backto = urlencode(hb_currenturl());
			$old_data = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($_G['uid']);
			$avatar = $old_data['avatar'] ? $old_data['avatar'] : avatar($_G['uid'], 'middle', 1);
			if ($_G['cache']['plugin']['xigua_hr']) {
				$status_text = array('0' => lang('plugin/xigua_hr', 'status0'), '1' => lang('plugin/xigua_hr', 'status1'), '2' => lang('plugin/xigua_hr', 'status2'), '3' => lang('plugin/xigua_hr', 'status3'));
				$verify_data = C::t('#xigua_hr#xigua_hr_verify')->fetch_verify_by_uid($_G['uid'], 1);
			}
			$custom_side = array($SCRITPTNAME . '?id=xigua_ho&ac=my&mobile=2' . $urlext, $old_data['uid'] ? $shifu_status[$old_data['status']] : lang_ho('wd', 0));
		}
		break;
	case 'cat':
		$cat_id = intval($_GET['cat_id']);
		$catinfo = C::t('#xigua_ho#xigua_ho_cat')->fetch_by_catid($cat_id);
		$navtitle = $catinfo['name'];
		$pid = $catinfo['pid'];
		if ($_GET['keyword']) {
			$navtitle = $keyword = stripsearchkey(addslashes($_GET['keyword']));
		}
		$list_all = C::t('#xigua_ho#xigua_ho_cat')->list_all();
		C::t('#xigua_ho#xigua_ho_cat')->init($list_all);
		$cat_tree_init = $cat_tree = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
		$cat_tree = array_values($cat_tree);
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist0 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist0 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['province']) {
			$distname = $_GET['province'];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if (!$navtitle && $distname) {
			$navtitle = $distname . lang_ho('fuwu', 0);
		}
		if (!$distname) {
			$distname = lang_ho('fwqy', 0);
		}
		$catname = $catinfo['name'] ? $catinfo['name'] : lang_ho('jineng', 0);
		$orderby = $_GET['orderby'];
		$orderby_list = array('' => lang_hb('om', 0), 'newest' => lang_ho('newest', 0), 'near' => lang_ho('near', 0), 'level' => lang_ho('level', 0), 'jingyan' => lang_ho('jingyan', 0), 'jiedannum' => lang_ho('jiedannum', 0));
		if (!$navtitle) {
			$navtitle = ($orderby_list[$orderby] == lang_hb('om', 0) ? lang_hb('quanbu', 0) : $orderby_list[$orderby]) . lang_ho('fuwu', 0);
		}
		$subcat = $cat_tree;
		if ($pid == 0) {
			$subcats = $cat_tree_init[$cat_id]['child'];
		}
		$tag_childs = array_filter(explode("\n", trim($catinfo['tag'])));
		if ($catinfo['share_title']) {
			$anavtitle = $navtitle;
			$navtitle = $catinfo['share_title'];
		}
		if ($catinfo['share_desc']) {
			$description = $catinfo['share_desc'];
		}
		break;
	case 'chosecat':
		if ($_GET['type'] == 'jingjia') {
			$navtitle = lang_ho('fabujingjia', 0);
		} else {
			$navtitle = lang_ho('fabuyikou', 0);
		}
		$list = C::t('#xigua_ho#xigua_ho_cat')->list_by_pid(0, true);
		foreach ($list as $index => $item) {
			$list[$index]['child'] = C::t('#xigua_ho#xigua_ho_cat')->get_childs_by_pids($item['id']);
		}
		ho_check_bind();
		break;
	case 'my':
		$navtitle = lang_ho('wddj', 0);
		$no_header_fix = 1;
		if ($_G['cache']['plugin']['xigua_hr']) {
			$veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($_G['uid']));
			$veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($_G['uid']), 2);
			$bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($_G['uid']));
		}
		$old_data = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($_G['uid']);
		$level = intval($old_data['level']);
		$mylevel = $levels[$level]['name'];
		$avatar = $old_data['avatar'] ? $old_data['avatar'] : avatar($_G['uid'], 'middle', 1);
		$name = $old_data['realname'] ? $old_data['realname'] : $_G['username'];
		$myneed_yikou = C::t('#xigua_ho#xigua_ho_need')->fetch_count_by_uid($_G['uid'], 'yikou');
		$myneed_jingjia = C::t('#xigua_ho#xigua_ho_need')->fetch_count_by_uid($_G['uid'], 'jingjia');
		$myfuwu = C::t('#xigua_ho#xigua_ho_fuwu')->fetch_count_by_uid($_G['uid']);
		$qianbao = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
		$dxp = $config['smsAppKey'] && $config['smssecretKey'] && $config['smsFreeSignName'] && $config['smsTemplateCode'] || $config['smsusername'] && $config['smsusername'] && $config['sendtype'] && $config['smstongtpl'];
		$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
		$muhumobile = $qianbao['mobile'] ? substr($qianbao['mobile'], 0, 3) . '******' . substr($qianbao['mobile'], 0 - 2) : '';
		$myzlurl = $SCRITPTNAME . '?id=xigua_hb&ac=myzl&hide_side=1&referer=' . urlencode(hb_currenturl()) . $urlext;
		if ($_GET['is'] == 'kehu') {
			dsetcookie('is_kehu', 1, 8640000);
		} elseif ($_GET['is'] == 'shifu') {
			dsetcookie('is_kehu', 0, 0);
		}
		$shifuis = !$_G['cookie']['is_kehu'];
		if ($shifuis && !$old_data['status']) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_ho&ac=my&is=kehu');
		}
		break;
	case 'my_needs':
		$navtitle = lang_ho('wdxq', 0);
		if ($_GET['type'] && $ho_need_types[$_GET['type']]) {
			$navtitle = lang_ho('wd', 0) . $ho_need_types[$_GET['type']];
		}
		$custom_side = array($SCRITPTNAME . '?id=xigua_ho&ac=my' . $urlext, lang_hb('wode', 0));
		break;
	case 'need':
		$catid = $_GET['catid'] ? intval($_GET['catid']) : intval($_GET['form']['catid']);
		$_key = 'ho_hangye1';
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$listjson = C::t('#xigua_ho#xigua_ho_cat')->list_json();
			C::t('#xigua_ho#xigua_ho_cat')->init($listjson);
			$jsary = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
			savecache($_key, array('variable' => array($listjson, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$listjson = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		$need_to_jump = 1;
		if (!$catid) {
			$catary_values = array_values($jsary);
			$catshift = array_shift($catary_values[0]['child']);
			$catid = $catshift['id'];
		}
		ho_check_bind();
		$he_vars = ho_vars($catid);
		if (!$he_vars) {
			$list = C::t('#xigua_ho#xigua_ho_cat')->list_json();
			foreach ($list as $index => $item) {
				if ($item['id'] == $catid) {
					$pid = $item['pid'];
					break;
				}
			}
			$he_vars = ho_vars($pid);
		}
		$_key = 'hbpubIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
			$distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			$distjsary = array_values($distjsary);
			savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
		} else {
			$distjsary = $_G['cache'][$_key]['variable'][0];
		}
		$defaultcty = diconv($distjsary[0]['name'] . ' ' . $distjsary[0]['sub'][0]['name'] . ' ' . $distjsary[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
		$cityjson = json_encode($distjsary);
		$catinfo = C::t('#xigua_ho#xigua_ho_cat')->fetch_by_catid($catid);
		if (!$_GET['type'] && $_GET['form']['type']) {
			$_GET['type'] = $_GET['form']['type'];
		}
		if ($_GET['type'] == 'jingjia') {
			$navtitle2 = $catinfo['name'] . lang_ho('jingjia', 0);
		} else {
			$navtitle2 = $catinfo['name'] . lang_ho('yikou', 0);
		}
		$navtitle = lang_ho('fabu', 0) . $navtitle2;
		$canprice = $_GET['type'] == 'yikou';
		if (submitcheck('formhash')) {
			$form = $_GET['form'];
			$canprice = $form['type'] == 'yikou';
			$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			$lastrealname = $user['realname'];
			$lastmobile = $user['mobile'];
			if (!$form['title']) {
				hb_message(lang_ho('qtxxqmc', 0), 'error');
			}
			$varinfo = array();
			foreach ($he_vars as $index => $vvar) {
				$var = $form['vars_0'][$index];
				if ($vvar['required']) {
					$reqtitle = $vvar['placehd'];
					if (!$reqtitle) {
						$reqtitle = lang_hb('qtx', 0) . $vvar['title'];
					}
					if (is_array($var) && !$var[0]) {
						hb_message($reqtitle, 'error');
					} else {
						if (!$var) {
							hb_message($reqtitle, 'error');
						}
					}
				}
				$html = '';
				foreach (explode("\n", trim($vvar['extra'])) as $str => $extra_string) {
					list($_tmp1, $_tmp2) = explode('=', trim($extra_string));
					$_tmp2 = trim($_tmp2);
					if ($_tmp1 == $var) {
						$html = $_tmp2;
						break;
					}
					if (in_array($_tmp1, $var)) {
						$html .= ' ' . $_tmp2;
					}
				}
				$varinfo[$index] = array('title' => $vvar['title'], 'value' => $var, 'html' => ($html ? $html : (is_array($var) ? $var[0] : $var)) . $vvar['unitnew'], 'type' => $vvar['type']);
			}
			if ($form['neednum'] <= 0) {
				hb_message(lang_ho('qtxxyrs', 0), 'error');
			}
			if ($form['needays'] <= 0) {
				hb_message(lang_ho('qtxygts', 0), 'error');
			}
			if ($form['price'] <= 0 && $canprice) {
				hb_message(lang_ho('qtxsfcl', 0), 'error');
			}
			if (!$form['description'] && !$catinfo['hidetext']) {
				hb_message(lang_ho('qsrms', 0), 'error');
			}
			$gongzi = $form['needays'] * $form['neednum'] * $form['price'];
			$bxprice = $form['bxtype'] * $form['neednum'];
			$totalprice = $gongzi + $bxprice;
			if ($canprice && $catinfo['apprice'] > 0 && $totalprice < $catinfo['apprice']) {
				hb_message(lang_ho('xqjebn', 0) . floatval($catinfo['apprice']) . lang_ho('yuan', 0), 'error');
			}
			$data = array('type' => $form['type'], 'uid' => $_G['uid'], 'catid' => $catid, 'stid' => $form['st'], 'lat' => $form['lat'], 'lng' => $form['lng'], 'dist1' => $form['dist1'], 'dist2' => $form['dist2'], 'dist3' => $form['dist3'], 'addr' => $form['addr'], 'title' => $form['title'], 'vars' => serialize($varinfo), 'neednum' => $form['neednum'], 'needays' => $form['needays'], 'price' => $form['price'], 'level' => $form['level'], 'description' => $form['description'], 'album' => implode('	', $form['album']), 'bxtype' => $form['bxtype'], 'bxnum' => $form['neednum'], 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'status' => 0 - 2, 'totalprice' => $totalprice, 'gongzi' => $gongzi, 'bxprice' => $bxprice, 'mobile' => $lastmobile, 'realname' => $lastrealname);
			$title = lang_ho('xyb', 0) . '-' . $navtitle;
			$newid = C::t('#xigua_ho#xigua_ho_need')->insert($data, 1);
			C::t('#xigua_ho#xigua_ho_shifu')->incr($_G['uid'], 'fadannum', 1);
			$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_ho&ac=my' . $urlext);
			if ($canprice) {
				$newdata = $data;
				$newdata['id'] = $newid;
				$newdata['description'] = $newdata['vars'] = $newdata['album'] = '';
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_pubneed', array('data' => array('newid' => $newid, 'newdata' => $newdata), 'callback' => array('file' => 'source/plugin/xigua_ho/function.php', 'method' => 'ho_pubneed_callback'), 'location' => $rtl, 'referer' => $rtl));
				$rl = urlencode($rtl);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext);
				C::t('#xigua_ho#xigua_ho_need')->update($newid, array('orderid' => $order_id));
				hb_message(lang_ho('jumppay', 0), 'loading', $jumpurl);
			} else {
				$updata = array('status' => $ho_config['need_shen'] ? 1 : 2);
				C::t('#xigua_ho#xigua_ho_need')->update($newid, $updata);
				if ($ho_config['fbxqtz'] && $updata['status'] == 2) {
					C::t('#xigua_ho#xigua_ho_shifu')->notice_to_shifu($newid, $data['title'], $data['catid'], $_G['username']);
				}
				hb_message(lang_ho('fbcg', 0), 'success', $rtl);
			}
		}
		break;
	case 'need_li':
		$where = array();
		if ($_GET['is_my']) {
			$where[] = 'uid=' . $_G['uid'];
		} else {
			if ($ho_config['showcj']) {
				$where[] = ' status in(2,4,8)';
			} else {
				$where[] = ' status in(2)';
			}
			if ($_GET['cat_id']) {
				$cat_id = intval($_GET['cat_id']);
				$pids = array($cat_id);
				$catinfo = C::t('#xigua_ho#xigua_ho_cat')->get_childs_by_pids($cat_id);
				if ($catinfo) {
					foreach ($catinfo as $index => $item) {
						$pids[] = intval($item['id']);
					}
					if ($pids) {
						$where[] = ' catid IN(' . implode(',', $pids) . ') ';
					}
				} else {
					$where[] = ' catid =' . $cat_id;
				}
			}
			if ($_GET['keyword']) {
				$keyword = stripsearchkey(addslashes($_GET['keyword']));
				$where[] = ' (title LIKE \'%' . $keyword . '%\' OR description LIKE \'%' . $keyword . '%\' OR vars LIKE \'%' . $keyword . '%\') ';
			}
			if ($_GET['province']) {
				$prov = stripsearchkey(addslashes($_GET['province']));
				$where[] = ' dist1 LIKE \'%' . $prov . '%\' ';
			}
			if ($_GET['city'] && $_GET['city'] != 0 - 1) {
				$city = stripsearchkey(addslashes($_GET['city']));
				$where[] = ' (dist2 LIKE \'%' . $city . '%\') ';
			}
			if ($_GET['dist']) {
				$dst = stripsearchkey(addslashes($_GET['dist']));
				$where[] = ' (dist3 LIKE \'%' . $dst . '%\') ';
			}
			if ($notpubid = intval($_GET['notid'])) {
				$where[] = ' id!=' . $notpubid;
			}
			if ($author_uid = intval($_GET['uid'])) {
				$where[] = ' uid=' . $author_uid;
			}
			if ($_GET['orderby'] == 'yikou') {
				$where[] = 'type=\'yikou\'';
			}
			if ($_GET['orderby'] == 'jingjia') {
				$where[] = 'type=\'jingjia\'';
			}
		}
		if ($_GET['type']) {
			$where[] = 'type=\'' . daddslashes($_GET['type']) . '\'';
		}
		if ($_GET['map']) {
			$left_top_lat = $_GET['left_lat'];
			$left_top_lng = $_GET['left_lng'];
			$right_bottom_lat = $_GET['right_lat'];
			$right_bottom_lng = $_GET['right_lng'];
			$where[] = ' (lat>' . $left_top_lat . ' AND lat<' . $right_bottom_lat . ' AND lng>' . $left_top_lng . ' AND lng<' . $right_bottom_lng . ') ';
		}
		$orary = C::t('#xigua_ho#xigua_ho_need')->get_order($_GET['orderby']);
		$list = C::t('#xigua_ho#xigua_ho_need')->fetch_all_by_page($start_limit, $lpp, $where, $orary['field'], $orary['order_by']);
		$catids = $needids = array();
		foreach ($list as $index => $item) {
			$needids[] = $item['id'];
			$catids[] = $item['catid'];
			$list[$index]['vars'] = array_slice(unserialize($item['vars']), 0, 3);
			if (!$list[$index]['vars']) {
				$list[$index]['description'] = cutstr(strip_tags($item['description']), 40);
			}
		}
		if ($_GET['is_my'] && $needids) {
			$loglist = DB::fetch_all('select needid,id from %t where needid in(%n) limit ' . count($needids), array('xigua_ho_needlog', $needids), 'needid');
		}
		if (!$_GET['is_my']) {
			if ($catids) {
				$catlist = DB::fetch_all('select id,name from %t where id in(%n)', array('xigua_ho_cat', $catids), 'id');
			}
		}
		$need_check = DB::fetch_all('SELECT uid,needid FROM %t WHERE uid=%d AND needid IN(%n) AND status IN(1,3,4)', array('xigua_ho_needlog', $_G['uid'], $needids), 'needid');
		include template('xigua_hb:header_ajax');
		include template('xigua_ho:need_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'needlog':
		if ($needid = intval($_GET['needid'])) {
			$v = $need = C::t('#xigua_ho#xigua_ho_need')->fetch($needid);
			$navtitle = $need['title'] . '-' . lang_ho('yjdgl', 0);
			$custom_side = array($SCRITPTNAME . '?id=xigua_ho&ac=my_needs&type=' . $v['type'] . $urlext, lang_ho('wdxq', 0));
		} else {
			if ($fuwuid = intval($_GET['fuwuid'])) {
				$fuwu = C::t('#xigua_ho#xigua_ho_fuwu')->fetch($fuwuid);
				$navtitle = $fuwu['title'] . '-' . lang_ho('fuwudan', 0);
				$custom_side = array($SCRITPTNAME . '?id=xigua_ho&ac=my&mobile=2' . $urlext, lang_ho('wd', 0));
			}
		}
		break;
	case 'order':
		$shifuis = !$_G['cookie']['is_kehu'];
		$navtitle = $shifuis ? lang_ho('wdjd', 0) : lang_ho('wddd', 0);
		$keyword = $_GET['keyword'];
		break;
	case 'order_li':
		$keyword = $_GET['keyword'];
		$wherearr = array();
		$orderby = 'id DESC';
		$shifuis = !$_G['cookie']['is_kehu'];
		if (!$shifuis) {
			$_GET['ispuber'] = 1;
		}
		if ($_GET['status']) {
			$wherearr[] = 'status=' . intval($_GET['status']);
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (needinfo LIKE \'%' . $keyword . '%\') ';
		}
		if ($_GET['ispuber']) {
			$wherearr[] = 'need_uid=' . $_G['uid'];
			if ($_GET['needid']) {
				$wherearr[] = 'needid=' . intval($_GET['needid']);
			}
			$list = C::t('#xigua_ho#xigua_ho_needlog')->fetch_all_by_where($wherearr, $start_limit, $lpp, $orderby, '*', 1);
			if ($list) {
				$ispuber = 1;
			}
			$shifuids = array();
			foreach ($list as $index => $item) {
				$shifuids[] = $item['uid'];
			}
			$shifus = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uids($shifuids, '*', 'uid');
		} else {
			$wherearr[] = 'uid=' . $_G['uid'];
			$shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($_G['uid']);
			$shifus[$_G['uid']] = $shifu;
			$list = C::t('#xigua_ho#xigua_ho_needlog')->fetch_all_by_where($wherearr, $start_limit, $lpp, $orderby, '*', 1);
			foreach ($list as $index => $item) {
				if ($ho_config['showsx'] && (IN_MAGAPP || IN_QIANFAN)) {
					$shmember = getuserbyuid($item['need_uid']);
					$shavat = avatar($item['need_uid'], 'middle', true);
					$kefulink = str_replace(array('{uid}', '{username}', '{avatar}'), array($item['need_uid'], $shmember['username'], $shavat), $ho_config['showsx']);
				} else {
					$kefulink = $SCRITPTNAME . '?id=xigua_hb&ac=chat&touid=' . $item['need_uid'];
				}
				$list[$index]['kefulink'] = $kefulink;
			}
		}
		if ($_G['cache']['plugin']['xigua_dp']) {
			$checks = array();
			foreach ($list as $index => $item) {
				if ($item['status'] == 3) {
					$checks[] = $item['uid'] . '_' . $item['id'];
				}
			}
			if ($checks) {
				$dps = DB::fetch_all('select typeid from %t where type=\'ho\' AND typeid in(%n) limit ' . count($checks), array('xigua_dp_comment', $checks), 'typeid');
			}
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_ho:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'search':
		$_ac = 'cat';
		$_type = $_GET['type'];
		$_high = $_GET['high'];
		$navtitle = $ho_config['schtxt'];
		break;
	case 'shifu':
		if ($_GET['ismine']) {
			$v = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($_G['uid']);
			$shifuid = intval($v['shifuid']);
		} else {
			$shifuid = intval($_GET['shifuid']);
			$v = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_id($shifuid);
		}
		if (!$v) {
			dheader('Location:' . $SCRITPTNAME . '?id=xigua_ho' . $urlext);
		}
		$navtitle = $v['realname'] . '-' . str_replace(',', '_', $v['jineng_str']);
		$desc = $v['jieshao'] ? $v['jieshao'] : $navtitle;
		$isme = $_G['uid'] && $_G['uid'] == $v['uid'];
		if ($_G['cache']['plugin']['xigua_hr']) {
			$veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($v['uid']));
			$veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($v['uid']), 2);
			$bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($v['uid']));
		}
		$fadanshu = $v['fadannum'];
		$jiedanshu = $v['jiedannum'];
		$update_v = array();
		$update_v['views'] = $v['views'] + 1;
		C::t('#xigua_ho#xigua_ho_shifu')->update($shifuid, $update_v);
		$v['jineng_str'] = str_replace(',', lang_ho('dot', 0), $v['jineng_str']);
		$v['areawant_str'] = str_replace(',', lang_ho('dot', 0), $v['areawant_str']);
		if ($v['shid'] && $_G['cache']['plugin']['xigua_hs']) {
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($v['shid']);
		}
		$v['showtel'] = $v['mobile'];
		if ($ho_config['sftel'] == 2) {
			$v['showtel'] = substr($v['mobile'], 0, 3) . '*****' . substr($v['mobile'], 0 - 3);
		} elseif ($ho_config['sftel'] == 3) {
			$v['showtel'] = substr($v['mobile'], 0, 3) . '*****' . substr($v['mobile'], 0 - 3);
		}
		$fuwus = C::t('#xigua_ho#xigua_ho_fuwu')->fetch_all_by_page(0, 20, array('status=1 AND uid=' . $v['uid']), 'id,title,album,price,unit,dingjin_open,dingprice,yuyue', 'dig_endts DESC,id DESC');
		break;
	case 'shifu_li':
		$uids = array();
		$where = array('status=1');
		if ($_GET['cat_id']) {
			$cat_id = intval($_GET['cat_id']);
			$pids = array($cat_id);
			$catinfo = C::t('#xigua_ho#xigua_ho_cat')->get_childs_by_pids($cat_id);
			if ($catinfo) {
				foreach ($catinfo as $index => $item) {
					$pids[] = intval($item['id']);
				}
				if ($pids) {
					$tmpw = array();
					foreach ($pids as $index => $pid) {
						$tmpw[] = 'FIND_IN_SET(' . $pid . ', jineng)';
					}
					$where[] = '(' . implode(' OR ', $tmpw) . ')';
				}
			} else {
				$where[] = 'FIND_IN_SET(' . $cat_id . ', jineng)';
			}
		}
		if ($_GET['keyword']) {
			$keyword = stripsearchkey(addslashes($_GET['keyword']));
			$where[] = ' (jineng_str LIKE \'%' . $keyword . '%\' OR jieshao LIKE \'%' . $keyword . '%\' OR realname LIKE \'%' . $keyword . '%\') ';
		}
		if ($_GET['province']) {
			$prov = stripsearchkey(addslashes($_GET['province']));
			$where[] = ' (province LIKE \'%' . $prov . '%\' OR areawant_str LIKE \'%' . $prov . '%\' OR area_keys LIKE \'%' . $prov . '%\') ';
		}
		if ($_GET['city'] && $_GET['city'] != 0 - 1) {
			$city = stripsearchkey(addslashes($_GET['city']));
			$where[] = ' (city LIKE \'%' . $city . '%\' OR areawant_str LIKE \'%' . $city . '%\' OR area_keys LIKE \'%' . $city . '%\') ';
		}
		if ($_GET['dist']) {
			$dst = stripsearchkey(addslashes($_GET['dist']));
			$where[] = ' (district LIKE \'%' . $dst . '%\' OR areawant_str LIKE \'%' . $dst . '%\' OR area_keys LIKE \'%' . $dst . '%\') ';
		}
		if ($shid = intval($_GET['shid'])) {
			$where[] = ' shid=\'' . $shid . '\'';
		}
		if ($notpubid = intval($_GET['notid'])) {
			$where[] = ' id!=' . $notpubid;
		}
		if ($author_uid = intval($_GET['uid'])) {
			$where[] = ' uid=' . $author_uid;
		}
		$orary = C::t('#xigua_ho#xigua_ho_shifu')->get_order($_GET['orderby']);
		$list = C::t('#xigua_ho#xigua_ho_shifu')->fetch_all_by_page($start_limit, $lpp, $where, $orary['field'], $orary['order_by']);
		foreach ($list as $index => $item) {
			$uids[] = $item['uid'];
			$list[$index]['jineng_str'] = str_replace(',', lang_ho('dot', 0), $item['jineng_str']);
			$list[$index]['areawant_str'] = str_replace(',', lang_ho('dot', 0), $item['areawant_str']);
		}
		if ($_G['cache']['plugin']['xigua_hr']) {
			$veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids);
			$veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids, 2);
			$bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_ho:shifu_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'view':
		$needid = intval($_GET['needid']);
		$v = $need = C::t('#xigua_ho#xigua_ho_need')->fetch_by_id($needid);
		$v['member'] = getuserbyuid($v['uid']);
		C::t('#xigua_ho#xigua_ho_need')->incr($needid, 'views');
		$vpr = $v['totalprice'] > 0 ? floatval($v['totalprice']) . lang_ho('yuan', 0) : '';
		$navtitle = str_replace(array('{subject}', '{price}', '{type}', '{username}'), array($v['title'], $vpr, $short_need_types[$v['type']], $v['member']['username']), $ho_config['titlevar']);
		$v['vars'] = unserialize($v['vars']);
		foreach ($v['vars'] as $index => $item) {
			if ($item['type'] == 'location') {
				$ddname = $item['title'];
				$v['vars'][$index] = array();
			}
		}
		$isme = $_G['uid'] && $_G['uid'] == $v['uid'];
		$is_mine = $_GET['mine'] && $isme;
		if ($is_mine) {
			$navtitle .= '(' . $need_status[$v['status']] . ')';
		}
		if (!$ddname) {
			$ddname = lang_ho('fwdd', 0);
		}
		$neelog = C::t('#xigua_ho#xigua_ho_needlog')->fetch_by_needid_status($needid);
		$catinfo = C::t('#xigua_ho#xigua_ho_cat')->fetch_by_catid($v['catid']);
		if ($v['type'] != 'yikou' && $ho_config['showjjjl']) {
			$neelogs = C::t('#xigua_ho#xigua_ho_needlog')->fetch_logs($needid, $v['type']);
		}
		$desc = strip_tags($v['description']);
		if (!$desc) {
			$desc = $v['title'] . ' / ' . $v['neednum'] . lang_ho('ren', 0) . ' / ' . $v['needays'] . lang_ho('day', 0);
		}
		$hasq = DB::fetch_first('SELECT uid FROM %t WHERE uid=%d AND needid=%d AND status IN(1,3,4)', array('xigua_ho_needlog', $_G['uid'], $needid));
		break;
	case 'needs':
		$navtitle = lang_ho('xqlb', 0);
		$cat_id = intval($_GET['cat_id']);
		$catinfo = C::t('#xigua_ho#xigua_ho_cat')->fetch_by_catid($cat_id);
		$navtitle = $catinfo['name'];
		$pid = $catinfo['pid'];
		if ($_GET['keyword']) {
			$navtitle = $keyword = stripsearchkey(addslashes($_GET['keyword']));
		}
		$list_all = C::t('#xigua_ho#xigua_ho_cat')->list_all();
		C::t('#xigua_ho#xigua_ho_cat')->init($list_all);
		$cat_tree_init = $cat_tree = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
		$cat_tree = array_values($cat_tree);
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist0 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist0 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['province']) {
			$distname = $_GET['province'];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if (!$navtitle && $distname) {
			$navtitle = $distname . lang_ho('xuqiu', 0);
		}
		if (!$distname) {
			$distname = lang_hb('plugins_edit_vars_type_area', 0);
		}
		$catname = $catinfo['name'] ? $catinfo['name'] : lang_hb('quanbu', 0) . lang_ho('xuqiu', 0);
		$orderby = $_GET['orderby'];
		$orderby_list = array('' => lang_hb('om', 0), 'newest' => lang_ho('newestxuqiu', 0), 'near' => lang_hb('near', 0), 'level' => lang_ho('level', 0), 'yikou' => lang_ho('yikou_short', 0), 'jingjia' => lang_ho('jingjia_short', 0));
		if (!$navtitle) {
			$showob = $orderby_list[$orderby];
			$showob = str_replace(lang_ho('xuqiu', 0), '', $showob);
			$navtitle = ($orderby_list[$orderby] == lang_hb('om', 0) ? lang_hb('quanbu', 0) : $showob) . lang_ho('xuqiu', 0);
		}
		if ($catinfo['share_title']) {
			$anavtitle = $navtitle;
			$navtitle = $catinfo['share_title'];
		}
		if ($catinfo['share_desc']) {
			$description = $catinfo['share_desc'];
		}
		$filter = $_GET['filter'];
		$city = $_GET['city'];
		$dist = $_GET['dist'];
		$lat = $_GET['lat'];
		$lng = $_GET['lng'];
		$inmap = $_GET['inmap'];
		$filtervars = array();
		if ($inmap) {
			$custom_side = array($SCRITPTNAME . '?id=xigua_ho&ac=needs&inmap=1&zoom=4' . $urlext, lang_ho('kqg', 0));
		} else {
			$custom_side = array($SCRITPTNAME . '?id=xigua_ho&ac=needs&inmap=1' . $urlext, lang_ho('dituzhao', 0));
		}
		break;
	case 'dist_li':
		$rlist = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($_GET['ctid']);
		include template('xigua_hb:header_ajax');
		include template('xigua_ho:dist_li');
		include template('xigua_hb:footer_ajax');
}
$ac_file = DISCUZ_ROOT . ('source/plugin/xigua_ho/include/c_' . $ac . '.php');
if (is_file($ac_file)) {
	include_once $ac_file;
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
include template('xigua_ho:' . $ac);