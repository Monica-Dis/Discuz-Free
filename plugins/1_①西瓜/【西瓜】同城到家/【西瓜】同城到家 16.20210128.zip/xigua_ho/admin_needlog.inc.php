<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if (empty($_G['cache']['plugin'])) :
    loadcache('plugin');
endif;
$ho_config = $_G['cache']['plugin']['xigua_ho'];
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_ho/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_ho/common_status.php';

$page = max(1, intval($_GET['page']));
$lpp = 10;
$start_limit = ($page - 1) * $lpp;
$pzfield = array();

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" /><style>img{object-fit:cover}</style>";

if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
    $ret = C::t('#xigua_ho#xigua_ho_needlog')->do_delete(intval($_GET['delid']));
    if($ret){
        cpmsg(
            lang_ho('delcat_succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog&page=$page",
            'succeed'
        );
    }else{
        cpmsg(
            lang_ho('del_error', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog&page=$page",
            'error'
        );
    }
}
if(submitcheck('complete', 1) && FORMHASH == $_GET['formhash']){
    $needlogid = intval($_GET['complete_id']);
    $needlog = C::t('#xigua_ho#xigua_ho_needlog')->fetch($needlogid);
    C::t('#xigua_ho#xigua_ho_needlog')->confirm_complete($needlogid, $needlog);
    if($needlog['needid']){
        C::t('#xigua_ho#xigua_ho_need')->update($needlog['needid'], array('status'=>4));
    }
    cpmsg(
        lang_ho('confirm_complete_success', 0),
        "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog&page=$page",
        'succeed'
    );
}
if (submitcheck('permsubmit')) {
    if ($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_ho#xigua_ho_needlog')->deletes($delete);
    }
    foreach ($_GET['row'] as $id => $item) {
        C::t('#xigua_ho#xigua_ho_needlog')->update($id, array( 'status' => $item['status']));
    }
    cpmsg(lang_ho('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog&shid={$_GET['shid']}&page=$page", 'succeed');
}
$wherearr = array();
$keyword = $_GET['keyword'];
if (is_numeric($keyword) && $keyword<9999999) {
    $wherearr[] = 'uid=' . intval($keyword);
}else if ($keyword = stripsearchkey(addslashes($keyword))) {
    $wherearr[] = " (`realname` LIKE '%$keyword%' OR jineng_str LIKE '%$keyword%' OR areawant_str LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR addr LIKE '%$keyword%' OR mobile LIKE '%$keyword%') ";
}
if(isset($_GET['status'])){
    $wherearr[] = 'status=' . intval($_GET['status']);
}
if(($_GET['type'])){
    $wherearr[] = 'type=\'' .daddslashes($_GET['type']).'\'';
}
$ob = 'id desc';
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog&shid={$_GET['shid']}");

echo '<div><input type="text" id="keyword" placeholder="'.lang_ho('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
foreach ($needlog_status as $index => $_v) {
    echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
}
echo '&nbsp;&nbsp;';
$listinfo = C::t('#xigua_ho#xigua_ho_cat')->list_all(1);
C::t('#xigua_ho#xigua_ho_cat')->init($listinfo);
$cat_list = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
$check0 = $_GET['type']?'':'selected';
$csearch = "&nbsp;<select name=\"type\">";
$csearch .= "<option value=\"0\" $check0 >".lang_hb('quanbu',0)."</option>";
foreach ($ho_need_types as $k => $v) {
    $check1 = $_GET['type']==$k?'selected':'';
    $csearch .= "<option value=\"$k\" $check1 >$v</option>";
}
$csearch .= '</select>';
echo '&nbsp;&nbsp;';
echo $csearch;
echo '&nbsp;';
echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog".' class="btn" >'.cplang('reset').'</a> ';
echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}.mt3{margin-top:3px}.c9{color:#999}
.jobtit{font-size:13px;color:#369}.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;border-radius:2px}
.jthumb{width:50px;height:50px}.red{color:#ff6565}.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.tyu{display:block;color:#4caf50}.tyu.jingjia{color:#ff6565}.vdesc{width:250px;max-height:150px;overflow-y:auto}.priceText{color:#ff6565}.qy{color:#4F7CB8}.v_mingxi{max-width:250px}.shifavatar{width:30px;height:30px;border-radius:50%}.btn2{padding: 3px 5px;line-height:30px;white-space:nowrap}.btn3{background: #DADADA;color: #999;}
</style>";
echo " </div>";
$jineng_str = lang_ho('jineng_str',0);
$miaoshu = lang_ho('shifu_xq',0);
$gongzi = lang_ho('gongzi',0);
$sfbz = lang_ho('sfbz',0);
$fwxm = lang_ho('fwxm',0);
$sfyy = lang_ho('sfyy',0);
$fuwudan = lang_ho('fuwudan',0);
$areawant_str = lang_ho('areawant_str',0);
$opentime = lang_ho('opentime',0);
$bxprice = lang_ho('bxprice',0);
$totalprice = lang_ho('totalprice',0);
$tlevel = lang_ho('level',0);
$shiming = lang_ho('shiming',0);
$lang_qy = lang('plugin/xigua_hr', 'qy');
$lang_jineng_str = lang('plugin/xigua_ho', 'jineng_str');
$lang_yuan = lang('plugin/xigua_ho', 'yuan');
$lang_nian = lang('plugin/xigua_ho', 'nian');
$lang_short_jingyan = lang('plugin/xigua_ho', 'short_jingyan');
$lang_fwqy = lang('plugin/xigua_ho', 'fwqy');
$lang_lxaddr = lang('plugin/xigua_ho', 'lxaddr');
$lang_shid = lang('plugin/xigua_ho', 'shid');
$lang_qy = lang('plugin/xigua_ho', 'qy');
$lang_gr = lang('plugin/xigua_ho', 'gr');
$lang_username = lang('plugin/xigua_ho', 'username');
$lang_realname = lang('plugin/xigua_ho', 'realname');
$lang_sjh = lang('plugin/xigua_ho', 'sjh');
$lang_r = lang_ho('r',0);
$lang_day = lang_ho('day',0);
$lang_chujia = lang_ho('chujia',0);
$lang_payts = lang_ho('payts',0);

showtableheader(lang_ho('fabuguanli', 0));
showtablerow('class="header"', array(), array(
    lang_ho('id', 0),
    lang_ho('fdr', 0),
    lang_ho('description', 0),
    lang_ho('jdr', 0),
    lang_ho('status', 0),
    lang_ho('xdsj', 0),
    lang_ho('caozuo', 0),
));
$res = C::t('#xigua_ho#xigua_ho_needlog')->fetch_all_by_page($start_limit, $lpp, $wherearr, '*', $ob);
$icount = C::t('#xigua_ho#xigua_ho_needlog')->fetch_count_by_page($wherearr);

$uids = $shifuids = $needids = array();
foreach ($res as $k => $v) {
    $shifuids[$v['uid']] = $v['uid'];
    $uids[$v['uid']] = $v['uid'];
    $uids[$v['need_uid']] = $v['need_uid'];

    $needids[$v['needid']] = $v['needid'];
}
if($_G['cache']['plugin']['xigua_hr']){
    $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids);
    $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids, 2);
    $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $mobiles = DB::fetch_all('SELECT uid,mobile,realname FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}
if($shifuids){
    $shifus = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('xigua_ho_shifu', $uids), 'uid');
}
foreach ($res as $v) {
    $id = $v['id'];
    $status_u = "<select name=\"row[$id][status]\">";
    foreach ($needlog_status as $k => $vv) {
        if($v['status']== $k){
            $s = 'selected';
        }else{
            $s = '';
        }
        $status_u .= "<option $s value=\"$k\">$vv</option>";
    }
    $status_u .= '</select>';
    $shifu = $shifus[$v['uid']];
    $thumb = $shifu['avatar'] ?$shifu['avatar'] : 'source/plugin/xigua_ho/static/img/dftava.png';
    $shiflevel = "<p class='mt3'><em class='c9'>$tlevel : </em>{$alllevels[$shifu['level']]['name']}</p>";
    $shifu_str = "<table><tr><td><img class='shifavatar' src='$thumb' /></td><td>".
        "<p><em class=\"c9\">$lang_username : </em>".$users[$v['uid']]['username'].' <em>[ '.$v['uid'].' ]</em></p>'.
        ($shifu['realname'] ? '<p class="mt3"><em class="c9">'.$lang_realname.' : </em>'.$shifu['realname'].'</p>' : '').
        '<p class="mt3"><em class="c9">'.$lang_sjh.' : </em>'.$shifu['mobile'].'</p>'.$shiflevel.
        "<p class=\"mt3\">$lang_short_jingyan{$shifu['jingyan']}$lang_nian / {$gender_ary[$shifu['gender']]}</p> ".
        "<p class=\"mt3\"><a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_user&mid={$shifu[uid]}'>".lang_hb('qbjl',0)."</a>
<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_user&mtid={$shifu[uid]}'>".lang_hb('txjl',0)."</a></p>"
        ."</td></tr></table>";
    $img = '';

    $payts_u = !$v['payts'] ? '': date('Y-m-d H:i:s', $v['payts']);
    $payts_u = $payts_u ? "<li><span class='c9'>$lang_payts</span> <span class=\"f12\">{$payts_u}</span></li>" : '';
    if($v['fuwuid']){
        $fuwuinfo = unserialize($v['fuwuinfo']);
        $fuwuinfo['album'] = array_filter(unserialize($fuwuinfo['album']));
        foreach ($fuwuinfo['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }
        $title_ext = "<ul class=\"v_mingxi cl\">
    <li><span class='c9'>$sfbz</span> <span class=\"priceText f12\">&yen; {$fuwuinfo['price']} {$fwunits[$fuwuinfo['unit']]} </span></li>
    <li><span class='c9'>$fwxm</span> <span class=\" f12\">{$fuwuinfo['title']}</span></li>
    <li><span class='c9'>$areawant_str</span> <span class=\" f12\">{$fuwuinfo['areawant_str']}</span></li>
    <li><span class='c9'>$jineng_str</span> <span class=\" f12\">{$fuwuinfo['jineng_str']}</span></li>
    <li><span class='c9'>$opentime</span> <span class=\" f12\">{$fuwuinfo['opentime']}</span></li>
    <li><span class='c9'>$sfyy</span> <span class=\" f12\">".($fuwuinfo['yuyue'] ? lang_ho('xxyy',0):lang_ho('wxyy',0))."</span></li>
    ".($fuwuinfo['dingjin_open'] ? "<li><span class='c9'>".lang_ho('djje',0)."</span> <span class=\"priceText f12\">&yen; ".$fuwuinfo['dingprice']."</span></li>" : '')."
    $payts_u
</ul>";
        $description = '<div class="mt3 vdesc"><span class="tyu">'.$fuwuinfo['title'].' [ '.$fuwudan.' ]</span>'.
            "<p class=\"mt3\">$title_ext</p><p>{$fuwuinfo['jieshao']}</p><p class=\"mt3\">$img</p></div>";
    }else{
        $needinfo = unserialize($v['needinfo']);
        $needinfo['album'] = array_filter(explode("\t", $needinfo['album']));
        foreach ($needinfo['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }
        $price_txt = "<ul class=\"v_mingxi cl\">
    <li><span class='c9'>$gongzi</span> <span class=\"priceText f12\">&yen; $needinfo[gongzi]</span></li>
    <li><span class='c9'>$bxprice</span> <span class=\"priceText f12\">&yen; $needinfo[bxprice]</span></li>
    <li><span class='c9'>$totalprice</span> <span class=\"priceText f12\">&yen; $needinfo[totalprice]</span></li>
    $payts_u
</ul>";
        $price_txt_jj = "<ul class=\"v_mingxi cl\">
    <li><span class='c9'>$lang_chujia</span> <span class=\"priceText f12\">&yen; {$v['chujia']}</span></li>
    $payts_u
</ul>";
        $title_ext = $needinfo && $needinfo['type']=='yikou' ? $price_txt : $price_txt_jj;
        $description = '<div class="mt3 vdesc"><span class="tyu '.$needinfo['type'].'">'.$ho_need_types[$needinfo['type']].' [ '.$v['needid'].' ]</span>'.
            $needinfo['title']." / $needinfo[neednum]$lang_r / $needinfo[needays] $lang_day".
            "<p class=\"mt3\">$title_ext</p><p>{$needinfo['description']}</p><p class=\"mt3\">$img</p></div>";
    }

    $fdr_zl = "<ul class=\"v_mingxi cl\">
<li><span class='c9'>$lang_username : </span> <span> {$users[$v['need_uid']]['username']} [ {$v['need_uid']} ]</span></li>
".($mobiles[$v['need_uid']]['realname']?"<li><span class='c9'>$lang_realname : </span> <span> {$mobiles[$v['need_uid']]['realname']}</span></li>":'')."
<li><span class='c9'>$lang_sjh : </span> <span>  {$mobiles[$v['need_uid']]['mobile']}</span></li>
</ul>";
    showtablerow('', array(), array(
        $id,
        $fdr_zl,
        $description,
        $shifu_str,
        $status_u,
        '<p><em class="c9">'.lang_ho('crts',0).' : </em>'.date('Y-m-d H:i:s', $v['crts']).'</p>'.
        '<p class="mt3"><em class="c9">'.lang_ho('upts2',0).' : </em>'.date('Y-m-d H:i:s', $v['upts']).'</p>'.
        ($v['confirmts'] ? '<p class="mt3 c_green"><em class="c9">'.lang_ho('qrwg',0).' : </em>'.date('Y-m-d H:i:s', $v['confirmts']).'</p>' : '').
        '',
        ($v['status']==1 ? (' <a class=\'btn btn2\' href="javascript:;" onclick="return _confim_complete('.$id.');">' . lang_ho('wg', 0) . '</a> ') : '').
        '<a class=\'btn btn2 btn3\' href="javascript:;" onclick="return _confim_del('.$id.');">' . lang_ho('del', 0) . '</a> ',
    ));
}
$dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', '', "", $multipage);
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/
?>
<script>
function _confim_del(id){
    if(confirm('<?php lang_ho('del_confirm')?> ID : ' + id + ' ?')){
        window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog&page=$page&del=1&formhash=".FORMHASH.'&delid='?>"+id;
    }
}
function _confim_complete(id){
    if(confirm('<?php lang_ho('qrwg_confirm')?> ID : ' + id + ' ?')){
        window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_needlog&page=$page&complete=1&formhash=".FORMHASH.'&complete_id='?>"+id;
    }
}
</script>
