<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
/*
if($vars):
    foreach($vars as $ab => $bc):
        if($bc['type']=='selects'){
            $filtervars[$ab] = $bc;
        }else if( $bc['type']=='select'){
            $extra1 = C::t('#xigua_ho#xigua_ho_cat')->get_tree($bc['extra']);
            if($extra1[1]){
                $filtervars[$ab] = array(
                    'bc' => $bc,
                    'data' => $extra1[0]
                );
            }else{
                $filtervars[$ab] = $bc;
            }
        }
    endforeach;
endif;

$_filter = array();
if($_GET['filter']):
    foreach (array_filter(explode('__', trim($_GET['filter']))) as $index => $item) :
        list($varid, $val) = explode('_', $item);
        $_filter[$varid] = $val;
    endforeach;
endif;*/