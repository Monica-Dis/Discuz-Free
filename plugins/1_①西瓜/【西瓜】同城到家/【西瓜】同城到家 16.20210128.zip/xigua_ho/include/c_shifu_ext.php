<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$shmember = getuserbyuid($v['uid']);
if($config['hostname']):
    $shavat = avatar($v['uid'], 'middle', true);
endif;
$kflnk = str_replace(array('{uid}', '{username}', '{avatar}'), array($v['uid'], $shmember['username'], $shavat), $ho_config['showsx']);
if(!(IN_QIANFAN||IN_MAGAPP) && ($config['magapp_secret'] || $config['hostname'])):
    $kflnk = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=".$v['uid'];
endif;