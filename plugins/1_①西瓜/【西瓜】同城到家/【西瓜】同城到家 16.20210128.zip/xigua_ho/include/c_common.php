<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['ac']=='join'){
    if($ho_config['rz_shen'] && $ho_config['notshen'] && $_G['cache']['plugin']['xigua_hr']){
        if($ho_config['notshen']==1){
            $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($_G['uid']));
            if($veris1[$_G['uid']]){
                $ho_config['rz_shen'] = 0;
            }
        }
        if($ho_config['notshen']==2){
            $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($_G['uid']), 2);
            if($veris2[$_G['uid']]){
                $ho_config['rz_shen'] = 0;
            }
        }
        if($ho_config['notshen']==3){
            $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($_G['uid']));
            $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($_G['uid']), 2);
            if($veris2[$_G['uid']] || $veris1[$_G['uid']]){
                $ho_config['rz_shen'] = 0;
            }
        }
    }
}