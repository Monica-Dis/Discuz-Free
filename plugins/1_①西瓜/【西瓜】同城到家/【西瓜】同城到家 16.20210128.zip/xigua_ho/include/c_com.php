<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
switch ($_GET['do']){
    case 'offline':
        if(submitcheck('formhash')){
            if($needid = intval($_GET['needid'])){
                if($_GET['xiajia']){$sta = 9;}else{$sta =  2;}
                C::t('#xigua_ho#xigua_ho_need')->update_G($needid, array('status' => $sta));
            }elseif($fuwuid= intval($_GET['fuwuid'])){
                if($_GET['xiajia']){$sta = -2;}else{$sta = 1;}
                C::t('#xigua_ho#xigua_ho_fuwu')->update_G($fuwuid, array('status' => $sta));
            }
            hb_message(lang_ho('succeed',0),'success', 'reload');
        }
        break;
    case 'refresh':
        if(submitcheck('formhash')){
            if($needid = intval($_GET['needid'])){
                $need =  C::t('#xigua_ho#xigua_ho_need')->fetch($needid);
                if($need['upts']>=TIMESTAMP-86400){hb_message(lang_ho('jty',0), 'error');}
                C::t('#xigua_ho#xigua_ho_need')->update_G($needid, array('upts' => TIMESTAMP,));
            }elseif($fuwuid= intval($_GET['fuwuid'])){
                $fuwu =  C::t('#xigua_ho#xigua_ho_fuwu')->fetch($fuwuid);
                if($fuwu['upts']>=TIMESTAMP-86400){hb_message(lang_ho('jty',0), 'error');}
                C::t('#xigua_ho#xigua_ho_fuwu')->update_G($fuwuid, array('upts' => TIMESTAMP,));
            }
            hb_message(lang_ho('refresh_succeed',0),'success', 'reload');
        }
        break;
    case 'dig':
        if(submitcheck('formhash')){
            if($needid = intval($_GET['needid'])) {
                $need = C::t('#xigua_ho#xigua_ho_need')->fetch($needid);
                $dig_price = $dig_prices[$_GET['digtype']];
                if($dig_price['price']>0){
                    $title = lang_ho('zdxq',0).$need['title'].$dig_price['type'].lang_hb('day', 0);
                    $rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_ho&ac=my_needs{$urlext}";
                    $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $dig_price['price'], $title , 'common_needdig', array(
                        'data' => array('needid' => $needid, 'last' => $dig_price['type'],),
                        'callback' => array(
                            'file' => 'source/plugin/xigua_ho/function.php',
                            'method' => 'need_dig_callback'
                        ),
                        'location' => $rtl,
                        'referer' => $rtl,
                    ));
                    $rl = urlencode($rtl);
                    $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
                    hb_message(lang_ho('jumppay',0), 'loading', $jumpurl);
                }
            }elseif($fuwuid= intval($_GET['fuwuid'])){
                $fuwu = C::t('#xigua_ho#xigua_ho_fuwu')->fetch($fuwuid);
                $dig_price = $dig_prices[$_GET['digtype']];
                if($dig_price['price']>0){
                    $title = lang_ho('zdfw',0).$fuwu['title'].$dig_price['type'].lang_hb('day', 0);
                    $rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_ho&ac=myfw{$urlext}";
                    $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $dig_price['price'], $title , 'common_fuwudig', array(
                        'data' => array('fuwuid' => $fuwuid, 'last' => $dig_price['type'],),
                        'callback' => array(
                            'file' => 'source/plugin/xigua_ho/function.php',
                            'method' => 'fuwu_dig_callback'
                        ),
                        'location' => $rtl,
                        'referer' => $rtl,
                    ));
                    $rl = urlencode($rtl);
                    $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
                    hb_message(lang_ho('jumppay',0), 'loading', $jumpurl);
                }
            }
        }
        break;
    case 'baojia':
        $needid = intval($_GET['needid']);
        $need = C::t('#xigua_ho#xigua_ho_need')->fetch($needid);
        $needlv = $alllevels[$need['level']];
        $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($_G['uid']);
        if(!$shifu){
            hb_message(lang_ho('qxrz',0), 'error', "$SCRITPTNAME?id=xigua_ho&ac=join$urlext");
        }
        if($shifu['status']==-1){
            hb_message(lang_ho('shifu',0).lang_ho('shifu_status-1',0).lang_ho('baojia',0).lang('plugin/xigua_hb', 'sb'), 'error', 'reload');
        }
        if($shifu['status']==-2){
            hb_message(lang_ho('shifu',0).lang_ho('shifu_status-2',0).lang_ho('baojia',0).lang('plugin/xigua_hb', 'sb'), 'error', 'reload');
        }
        if($ho_config['mustbao'] && $_G['cache']['plugin']['xigua_hr']){
            $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($_G['uid']));
            if(!$bao){
                hb_message(lang_ho('mustbao',0), 'error', "$SCRITPTNAME?id=xigua_hr&ac=paybao$urlext");
            }
        }
        if($need['level']> $shifu['level']){
            hb_message(lang_ho('yaoqiu',0).$needlv['name'].','.lang_ho('djwfjd',0), 'error');
        }
        $neelog = C::t('#xigua_ho#xigua_ho_needlog')->fetch_by_needid_status($needid);
        if($neelog){
            hb_message(lang_ho('ddybqz',0), 'error');
        }
        if(C::t('#xigua_ho#xigua_ho_needlog')->fetch_by_uid_needid($_G['uid'], $needid)){
            hb_message(lang_ho('yjdwfcfjd',0), 'error', "$SCRITPTNAME?id=xigua_ho&ac=order$urlext");
        }
        if($_GET['baojia']<=0){
            hb_message(lang_ho('bjjetd',0), 'error');
        }
        $catinfo = C::t('#xigua_ho#xigua_ho_cat')->fetch_by_catid($need['catid']);
        if($catinfo['apprice']>0 && $_GET['baojia']<$catinfo['apprice']){
            hb_message(lang_ho('bjjetd1',0).floatval($catinfo['apprice']).lang_ho('yuan',0), 'error');
        }
        $data = array(
            'uid' => $_G['uid'],
            'crts' => TIMESTAMP,
            'upts' => TIMESTAMP,
            'needid' => $needid,
            'need_uid' => $need['uid'],
            'needinfo' => serialize($need),
            'status' => -1,
            'stid' => $_GET['st'],
            'type' => $need['type'],
            'chujia' => floatval($_GET['baojia']),
            'beizhu' => $_GET['beizhu'],
        );
        $logid = C::t('#xigua_ho#xigua_ho_needlog')->insert($data, 1);
        if($logid>0){
            hb_message(lang_ho('bjcg',0), 'success', $SCRITPTNAME.'?id=xigua_ho&ac=order'.$urlext);
        }
        break;
    case 'qiangdan':
        check_bind(7);
       if($needid = intval($_GET['needid'])){
           $need = C::t('#xigua_ho#xigua_ho_need')->fetch($needid);
           $needlv = $alllevels[$need['level']];
           $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($_G['uid']);
           if(!$shifu){
               hb_message(lang_ho('qxrz',0), 'error', "$SCRITPTNAME?id=xigua_ho&ac=join$urlext");
           }
           if($shifu['status']==-1){
               hb_message(lang_ho('shifu',0).lang_ho('shifu_status-1',0).lang_ho('qd',0).lang('plugin/xigua_hb', 'sb'), 'error', 'reload');
           }
           if($shifu['status']==-2){
               hb_message(lang_ho('shifu',0).lang_ho('shifu_status-2',0).lang_ho('qd',0).lang('plugin/xigua_hb', 'sb'), 'error', 'reload');
           }
           if($ho_config['mustbao'] && $_G['cache']['plugin']['xigua_hr']){
               $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($_G['uid']));
               if(!$bao){
                   hb_message(lang_ho('mustbao',0), 'error', "$SCRITPTNAME?id=xigua_hr&ac=paybao$urlext");
               }
           }
           if($need['level']> $shifu['level']){
               hb_message(lang_ho('yaoqiu',0).$needlv['name'].','.lang_ho('djwfjd',0), 'error');
           }
           $neelog = C::t('#xigua_ho#xigua_ho_needlog')->fetch_by_needid_status($needid);
           if($neelog){
               hb_message(lang_ho('ddybqz',0), 'error');
           }
           if(C::t('#xigua_ho#xigua_ho_needlog')->fetch_by_uid_needid($_G['uid'], $needid)){
               hb_message(lang_ho('yjdwfcfjd',0), 'error', "$SCRITPTNAME?id=xigua_ho&ac=order$urlext");
           }
           $data = array(
               'uid' => $_G['uid'],
               'crts' => TIMESTAMP,
               'upts' => TIMESTAMP,
               'needid' => $needid,
               'need_uid' => $need['uid'],
               'needinfo' => serialize($need),
               'status' => -1,
               'stid' => $_GET['st'],
               'type' => $need['type'],
               'chujia' => floatval($_GET['chujia']),
               'fuwuid' => 0,
               'fuwu_uid' => 0,
               'fuwuinfo' => serialize(array()),
           );
           $logid = C::t('#xigua_ho#xigua_ho_needlog')->insert($data, 1);
           if($logid>0){
               $catinfo = C::t('#xigua_ho#xigua_ho_cat')->fetch_by_catid($need['catid']);
               $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($_G['uid']);
               if($catinfo['nocheck']){
                   $needlog = C::t('#xigua_ho#xigua_ho_needlog')->fetch($logid);
                   C::t('#xigua_ho#xigua_ho_needlog')->confirm_order($logid, $needlog);
                   notification_add($need['uid'],'system', lang('plugin/xigua_ho', 'jdcg2'),array(
                       'realname' => $shifu['realname'],
                       'mobile' => $shifu['mobile'],
                       'level' => $shifu['level_str'],
                       'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=needlog&needid=$needid",
                   ),1);
                   hb_message(lang_ho('jdcg21',0), 'success', "$SCRITPTNAME?id=xigua_ho&ac=order&status=1");
               }else{
                   notification_add($need['uid'],'system', lang('plugin/xigua_ho', 'jdcg1'),array(
                       'realname' => $shifu['realname'],
                       'mobile' => $shifu['mobile'],
                       'level' => $shifu['level_str'],
                       'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=needlog&needid=$needid",
                   ),1);
                   hb_message(lang_ho('jdcg',0), 'success', "$SCRITPTNAME?id=xigua_ho&ac=order&status=-1");
               }
           }
       }elseif($fuwuid = intval($_GET['fuwuid'])){
           $fuwu =  C::t('#xigua_ho#xigua_ho_fuwu')->fetch($fuwuid);
           $fuwu_uid = $fuwu['uid'];
           $data = array(
               'uid' => $fuwu_uid,
               'crts' => TIMESTAMP,
               'upts' => TIMESTAMP,
               'needid' => 0,
               'need_uid' => $_G['uid'],
               'needinfo' => serialize(array()),
               'status' => -1,
               'stid' => $_GET['st'],
               'type' => '',
               'chujia' => 0,
               'fuwuid' => $fuwuid,
               'fuwu_uid' => $fuwu_uid,
               'fuwuinfo' => serialize($fuwu),
           );
           $logid = C::t('#xigua_ho#xigua_ho_needlog')->insert($data, 1);
           if($logid>0){
               if($fuwu['dingjin_open'] && $fuwu['dingprice']>0){
                   $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($fuwu_uid);
                   $title = lang_ho('gm',0).$fuwu['title'] .'-'.$shifu['realname'].'['.$shifu['level_str'].']'.lang_ho('dj',0);
                   $rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_ho&ac=order&status=1{$urlext}";
                   $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $fuwu['dingprice'], $title , 'common_fuwudprice', array(
                       'data' => array(
                           'needlogid' => $logid,
                           'fuwuid' => $fuwuid,
                           'price'  => $fuwu['dingprice']
                       ),
                       'callback' => array(
                           'file' => 'source/plugin/xigua_ho/function_fuwu.php',
                           'method' => 'ho_fuwu_pay_callback'
                       ),
                       'location' => $rtl,
                       'referer' => $rtl,
                   ));
                   $rl = urlencode($rtl);
                   $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
                   hb_message(lang_ho('jumppay',0), 'loading', $jumpurl);
               }else{
                   $needlog = C::t('#xigua_ho#xigua_ho_needlog')->fetch($logid);
                   C::t('#xigua_ho#xigua_ho_needlog')->confirm_order($logid, $needlog);

                   $user = C::t('#xigua_hb#xigua_hb_user')->fetch($needlog['need_uid']);
                   notification_add($fuwu_uid,'system', lang('plugin/xigua_ho', 'jdcg3'),array(
                       'realname' => $user['realname'] ? $user['realname'] : $_G['username'],
                       'mobile' => $user['mobile'],
                       'title' => $fuwu['title'],
                       'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=needlog&fuwuid=$fuwuid$urlext",
                   ),1);

                   $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($fuwu_uid);
                   notification_add($needlog['need_uid'],'system', lang('plugin/xigua_ho', 'jdcg4'),array(
                       'realname' => $shifu['realname'],
                       'mobile' => $shifu['mobile'],
                       'title' => $fuwu['title'],
                       'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=order&status=1",
                   ),1);

                   dsetcookie('is_kehu', 1, 8640000);
                   hb_message(lang_ho('jdcgtip',0), 'success', "$SCRITPTNAME?id=xigua_ho&ac=order&status=1$urlext");
               }
           }
       }
        break;
    case 'confirm_cancel':
        $needlogid = intval($_GET['needlogid']);
        $needlog = C::t('#xigua_ho#xigua_ho_needlog')->fetch($needlogid);
        if($needlog['need_uid']!=$_G['uid'] && $needlog['uid']!=$_G['uid'] && !IS_ADMINID){
            hb_message('no access!', 'error');
        }
        C::t('#xigua_ho#xigua_ho_needlog')->cancel_order($needlogid, $needlog);
        hb_message(lang_ho('qxcg',0), 'success', "$SCRITPTNAME?id=xigua_ho&ac=order&status=2");
        break;
    case 'confirm_order':
        $needlogid = intval($_GET['needlogid']);
        $needlog = C::t('#xigua_ho#xigua_ho_needlog')->fetch($needlogid);
        if($needlog['need_uid']!=$_G['uid'] && !IS_ADMINID){
            hb_message('no access!', 'error');
        }
        if($needlog['type']=='yikou'){
            C::t('#xigua_ho#xigua_ho_needlog')->confirm_order($needlogid, $needlog);
            hb_message(lang_ho('qrcg',0), 'success', 'reload');
        }else{
            $price= $needlog['chujia'];
            $needinfo = unserialize($needlog['needinfo']);
            $user = getuserbyuid($needinfo['uid']);
            $catinfo_tmp = C::t('#xigua_ho#xigua_ho_cat')->fetch_by_catid($needinfo['catid']);
            $extinf = !$catinfo_tmp['hideyg'] ? '/'. $needinfo['neednum'].lang_ho('ren',0) .'/'. $needinfo['needays'].lang_ho('day',0) :'';
            $title = lang_ho('xyb',0).'-'.$user['username']. lang_ho('dxq',0).$needinfo['title'] . $extinf;
            if($price<=0){
                $price = 1;
            }
            $rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_ho&ac=needlog&needid={$needinfo['id']}{$urlext}";
            $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price, $title , 'common_confirmneed', array(
                'data' => array(
                    'needlogid' => $needlogid,
                    'needid' => $needinfo['id'],
                    'price'  => $price
                ),
                'callback' => array(
                    'file' => 'source/plugin/xigua_ho/function.php',
                    'method' => 'ho_confirmneed_callback'
                ),
                'location' => $rtl,
                'referer' => $rtl,
            ));
            $rl = urlencode($rtl);
            $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
            hb_message(lang_ho('jumppay',0), 'loading', $jumpurl);
        }
        break;
    case 'confirm_complete':
        $needlogid = intval($_GET['needlogid']);
        $needlog = C::t('#xigua_ho#xigua_ho_needlog')->fetch($needlogid);
        if($needlog['need_uid']!=$_G['uid'] && !IS_ADMINID){
            hb_message('no access!', 'error');
        }
        C::t('#xigua_ho#xigua_ho_needlog')->confirm_complete($needlogid, $needlog);
        if($needlog['needid']){
            C::t('#xigua_ho#xigua_ho_need')->update($needlog['needid'], array('status'=>4));
        }
        hb_message(lang_ho('succeed',0), 'success', "$SCRITPTNAME?id=xigua_ho&ac=order&status=3");
        break;
    case 'delete_need':
        $needid = intval($_GET['needid']);
        $need = C::t('#xigua_ho#xigua_ho_need')->fetch($needid);
        if($need['uid']!=$_G['uid'] && !IS_ADMINID){
            hb_message('no access!', 'error');
        }
        C::t('#xigua_ho#xigua_ho_need')->delete($needid);
        hb_message(lang_ho('delcat_succeed',0), 'success', 'reload');
        break;
    case 'incr':
        if(submitcheck('formhash')) {
            $shifuid = intval($_GET['shifuid']);
            if($_GET['incr_type']=='shares'){
                C::t('#xigua_ho#xigua_ho_shifu')->incr($shifuid, 'shares', 1);
                hb_message('success', 'success');
            }
        }
        break;
}
exit;