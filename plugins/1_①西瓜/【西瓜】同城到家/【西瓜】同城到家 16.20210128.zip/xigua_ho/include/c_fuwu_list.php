<?php

$navtitle = '������Ŀ';
$cat_id = intval($_GET['cat_id']);
$catinfo = C::t('#xigua_ho#xigua_ho_cat')->fetch_by_catid($cat_id);
$navtitle = $catinfo['name'];
$pid = $catinfo['pid'];
if($_GET['keyword']){$navtitle = $keyword = stripsearchkey(addslashes($_GET['keyword']));}
$list_all = C::t('#xigua_ho#xigua_ho_cat')->list_all();
C::t('#xigua_ho#xigua_ho_cat')->init($list_all);
$cat_tree_init = $cat_tree = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
$cat_tree = array_values($cat_tree);
$_key = 'hbIdist'.intval($_GET['st']);
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    $dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
    $GLOBALS['nojson'] = 1;
    $list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
    C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
    $jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    foreach ($dist0 as $index => $item) {
        C::t('#xigua_hb#xigua_hb_district')->empty_child();
        $dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
    }
    savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
} else {
    $dist0 = $_G['cache'][$_key]['variable'][0];
    $jsary = $_G['cache'][$_key]['variable'][1];
}
if($_GET['province']){$distname = $_GET['province'];}
if($_GET['city']){$distname = $_GET['city'];}
if($_GET['dist']){$distname = $_GET['dist'];}
if(!$navtitle && $distname){
    $navtitle = $distname.lang_ho('fuwu',0);
}
if(!$distname){
    $distname = lang_hb('plugins_edit_vars_type_area',0);
}
$catname = $catinfo['name'] ? $catinfo['name']: lang_hb('quanbu',0).lang_ho('fuwu',0);
$orderby = $_GET['orderby'];
$orderby_list = array(
    '' => lang_hb('om',0),
    'newest' => lang_hb('zuixin',0),
    'near' => lang_hb('near',0),
    'level' => lang_ho('level', 0),
);
if(!$navtitle){
    $showob = $orderby_list[$orderby];
    $showob = str_replace(lang_ho('fuwu',0),'', $showob);
    $navtitle = ($orderby_list[$orderby]==lang_hb('om',0) ? lang_hb('quanbu',0):$showob).lang_ho('fuwu',0);
}

if($catinfo['share_title']){
    $anavtitle = $navtitle;
    $navtitle = $catinfo['share_title'];
}
if($catinfo['share_desc']){
    $description = $catinfo['share_desc'];
}
$filter = $_GET['filter'];
$city = $_GET['city'];
$dist = $_GET['dist'];
$lat = $_GET['lat'];
$lng = $_GET['lng'];
$inmap = $_GET['inmap'];
$filtervars = array();