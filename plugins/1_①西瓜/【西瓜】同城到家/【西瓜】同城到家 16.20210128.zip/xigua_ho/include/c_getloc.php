<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['do']=='change') {
    $lng = floatval($_GET['lng']);
    $lat = floatval($_GET['lat']);
    $from = intval($_GET['from']);
    $to = intval($_GET['to']);
    if (!$ak = $_GET['ak']) {
        $ak = $_G['cache']['plugin']['xigua_ho']['baidusrak'];
    }
    $ret = hb_curl("http://api.map.baidu.com/geoconv/v1/?coords=$lng,$lat&from=$from&to=$to&ak=$ak");
    $ret = json_decode($ret, 1);
    echo $ret['result'][0]['x'] . ',' . $ret['result'][0]['y'];
    exit;
}else{
    $ret = ho_current_location($_GET['lat'], $_GET['lng']);
    if(is_array($ret)){
        if($_GET['checkst'] && $_G['cache']['plugin']['xigua_st']){
            $geoinfo = ho_multi_diconv($ret[0]['address_component'],'utf-8', CHARSET);

            if($rs = DB::fetch_first("select `stid`,area3 from %t where area3<>'' AND `area3` IN (%n)", array('xigua_st', $geoinfo))) {
                hb_message(implode(',', $rs).','.implode(',', $geoinfo), 'success');
            }
            if($rs = DB::fetch_first("select `stid`,area2 from %t where area2<>'' AND `area2` IN (%n) AND area3=''", array('xigua_st', $geoinfo))) {
                hb_message(implode(',', $rs).','.implode(',', $geoinfo), 'success');
            }
            if($rs = DB::fetch_first("select `stid`,area2 from %t where area1<>'' AND `area1` IN (%n) AND area2='' AND area3=''", array('xigua_st', $geoinfo))) {
                hb_message(implode(',', $rs).','.implode(',', $geoinfo), 'success');
            }
            hb_message('error', 'error');
        }

        if($_GET['checkallow']&&$config['areaallow']){
            $areaallow = array_filter(explode("\n", trim($config['areaallow'])));
            foreach ($areaallow as $index => $item) {
                $areaallow[$index] = trim($item);
            }
            if($areaallow){
                $ar1 = ho_multi_diconv($ret[0]['address_component'],'utf-8', CHARSET);
                if(!array_intersect($ar1, $areaallow)){
                    hb_message(lang_hb('notallowq1',0).implode(',', $ar1).lang_hb('notallowq2',0).implode(',', $areaallow), 'error');
                }
            }
        }

        if($_GET['geoauto']){
            $geoinfo = ho_multi_diconv($ret[0]['address_component'],'utf-8', CHARSET);
            if($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['district']))){
                hb_message($rs.':dist='.urlencode($rs), 'success');
            }
            if($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['city']))){
                hb_message($rs.':city='.urlencode($rs), 'success');
            }
            if($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['province']))){
                hb_message($rs, 'success');
            }
            hb_message('error', 'error');
        }

        hb_message(json_encode($ret), 'success');
    }else{
        hb_message($ret, 'error');
    }
}