<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$navtitle = lang_ho('fbfw',0);
$catid = $_GET['catid'] ? intval($_GET['catid']) : intval($_GET['form']['catid']);
$_key = 'ho_hangye1';
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    $listjson = C::t('#xigua_ho#xigua_ho_cat')->list_json();
    C::t('#xigua_ho#xigua_ho_cat')->init($listjson);
    $jsary = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
    savecache($_key, array('variable' => array($listjson, $jsary), 'expiration' => TIMESTAMP));
} else {
    $listjson = $_G['cache'][$_key]['variable'][0];
    $jsary = $_G['cache'][$_key]['variable'][1];
}
if(!$catid){
    $catary_values = array_values($jsary);
    $catshift = array_shift($catary_values[0]['child']);
    $catid = $catshift['id'];
}
ho_check_bind();
$_key = 'hbpubIdist'.intval($_GET['st']);
loadcache($_key);
if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
    C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
    $distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    $distjsary = array_values($distjsary);
    savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
} else {
    $distjsary = $_G['cache'][$_key]['variable'][0];
}
$defaultcty = diconv($distjsary[0]['name'].' '. $distjsary[0]['sub'][0]['name'].' '.$distjsary[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
$cityjson = json_encode($distjsary);
$catinfo = C::t('#xigua_ho#xigua_ho_cat')->fetch_by_catid($catid);

if(submitcheck('formhash')){
    $form = $_GET['form'];
    if(!$form['title']){
        hb_message(lang_ho('qtx',0).lang_ho('fwmc',0), 'error');
    }
    if($form['dingjin_open'] && !$form['dingprice']){
        hb_message(lang_ho('qtx',0).lang_ho('djje',0), 'error');
    }
    if($form['jineng']){
        foreach ($listjson as $index => $item) {
            if(in_array($item['code'], $form['jineng'])){
                $jineng_string_tmp[$item['code']] = $item['oname'];
            }
        }
        foreach ($form['jineng'] as $index => $item) {
            $jineng_string[$item] = $jineng_string_tmp[$item];
        }
        $form['jineng_str'] = implode(',', $jineng_string);
        $form['jineng'] = implode(',', $form['jineng']);
    }else{
        hb_message(lang_ho('min1jineng',0), 'error');
    }
    if($form['areawant']){
        $eqdq = $form['areawant'];
        $areawant_str = $areawant_str_tmp = array();
        $distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
        foreach ($distlist as $index => $item) {
            if(in_array($item['code'], $eqdq)){
                $areawant_str_tmp[$item['code']] = diconv($item['name'], 'UTF-8', CHARSET);
            }
        }
        foreach ($form['areawant'] as $index => $item) {
            $areawant_str[$item] = $areawant_str_tmp[$item];
        }
        $form['areawant'] = implode(',', $form['areawant']);
        $form['areawant_str'] = implode(',', $areawant_str);
    }
    $status = 1;
    $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($_G['uid']);

    $data = array (
        'yuyue' => $form['yuyue'],
        'price' => $form['price'],
        'unit' => $form['unit'],
        'dingjin_open' => $form['dingjin_open'],
        'dingprice' => $form['dingprice'],
        'opentime' => $form['opentime'],
        'uid' =>  $_G['uid'],
        'stid' =>  $form['stid'],
        'title' =>  $form['title'],
        'shid' =>  $shifu['shid'],
        'shname' =>  $shifu['shname'],
        'lat' => $shifu['lat'],
        'lng' => $shifu['lng'],
        'province' => $shifu['province'],
        'city' => $shifu['city'],
        'district' => $shifu['district'],
        'street' => $shifu['street'],
        'street_number' => $shifu['street_number'],
        'addr' => $shifu['addr'],
        'jineng' => $form['jineng'],
        'jineng_str' => $form['jineng_str'],
        'album' => serialize($form['album']),
        'areawant' => $form['areawant'],
        'areawant_str' => $form['areawant_str'],
        'jieshao' => $form['jieshao'],
        'crts' => TIMESTAMP,
        'upts' => TIMESTAMP,
    );
    if($old_data = C::t('#xigua_ho#xigua_ho_fuwu')->fetch_by_id($form['old_id'])){
        $msg = lang_ho('bccg', 0);
        C::t('#xigua_ho#xigua_ho_fuwu')->update_G($old_data['id'], $data);
        hb_message($msg, 'success', "$SCRITPTNAME?id=xigua_ho&ac=myfw&mobile=2$urlext");
    }else{
        $data['status']=$status;
        $newid = C::t('#xigua_ho#xigua_ho_fuwu')->insert($data, 1);
        if($status==-1){
            hb_message(lang_ho('fbcgsc',0), 'success', "$SCRITPTNAME?id=xigua_ho&ac=myfw&mobile=2$urlext");
        }else{
            hb_message(lang_ho('fbcg',0), 'success', "$SCRITPTNAME?id=xigua_ho&ac=myfw&mobile=2$urlext");
        }
    }
}else{
    $old_data = C::t('#xigua_ho#xigua_ho_fuwu')->fetch_by_id($_GET['old_id']);
    if($old_data['uid']!=$_G['uid']){
        $old_data = array();
    }
}