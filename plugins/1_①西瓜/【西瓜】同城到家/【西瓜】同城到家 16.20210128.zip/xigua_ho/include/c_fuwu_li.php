<?php

$where = $uids = array();
if($_GET['sta']){
    $where[] = 'status='.intval($_GET['sta']);
}
if ($_GET['cat_id']) {
    $cat_id = intval($_GET['cat_id']);
    $pids = array($cat_id);
    $catinfo = C::t('#xigua_ho#xigua_ho_cat')->get_childs_by_pids($cat_id);
    if ($catinfo) {
        foreach ($catinfo as $index => $item) {
            $pids[] = intval($item['id']);
        }
        if ($pids) {
            $tmpw = array();
            foreach ($pids as $index => $pid) {
                $tmpw[] = "FIND_IN_SET($pid, jineng)";
            }
            $where[] = '('.implode(' OR ', $tmpw).')';
        }
    } else {
        $where[] = "FIND_IN_SET($cat_id, jineng)";
    }
}
if ($_GET['keyword']) {
    $keyword = stripsearchkey(addslashes($_GET['keyword']));
    $where[] = " (jineng_str LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR title LIKE '%$keyword%') ";
}
if ($_GET['province']) {
    $prov = stripsearchkey(addslashes($_GET['province']));
    $where[] = " (province LIKE '%$prov%' OR areawant_str LIKE '%$prov%') ";
}
if ($_GET['city'] && $_GET['city'] != -1) {
    $city = stripsearchkey(addslashes($_GET['city']));
    $where[] = " (city LIKE '%$city%' OR areawant_str LIKE '%$city%') ";
}
if ($_GET['dist']) {
    $dst = stripsearchkey(addslashes($_GET['dist']));
    $where[] = " (district LIKE '%$dst%' OR areawant_str LIKE '%$dst%') ";
}
if ($shid = intval($_GET['shid'])) {
    $uids2 = DB::fetch_all('select uid from %t where shid=%d', array('xigua_ho_shifu', $shid), 'uid');
    if($uids2){
        $uids2 = array_keys($uids2);
        if($uids2){
            $where[] = 'uid IN ('.implode(',', $uids2).')';
        }
    }
    /*$where[] = " shid='$shid'";*/
}
if ($notpubid = intval($_GET['notid'])) {
    $where[] = ' id!=' . $notpubid;
}
if($_GET['is_my']){
    $where[] = 'uid='.$_G['uid'];
}
$orary = C::t('#xigua_ho#xigua_ho_fuwu')->get_order($_GET['orderby']);
$list = C::t('#xigua_ho#xigua_ho_fuwu')->fetch_all_by_page($start_limit, $lpp, $where, $orary['field'], $orary['order_by']);
foreach ($list as $index => $item) {
    $uids[] = $item['uid'];
    $list[$index]['jineng_str'] = str_replace(',', lang_ho('dot',0), $item['jineng_str']);
    $list[$index]['areawant_str'] = str_replace(',', lang_ho('dot',0), $item['areawant_str']);
}
if($_G['cache']['plugin']['xigua_hr'] && $uids){
    $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids);
    $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids, 2);
    $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
}
include template('xigua_hb:header_ajax');
include template('xigua_ho:fw_li');
include template('xigua_hb:footer_ajax');