<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($shifuid = intval($_GET['shifuid'])){
    $upar = parse_url(hb_currenturl());
    $hb_currenturltmp = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_ho&ac=shifu&shifuid=$shifuid&x=1{$urlext}");
    $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&url='.$hb_currenturltmp;
}elseif ($fuwuid = intval($_GET['fuwuid'])){
    $upar = parse_url(hb_currenturl());
    $hb_currenturltmp = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_ho&ac=fuwu&fuwuid=$fuwuid&x=1{$urlext}");
    $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&url='.$hb_currenturltmp;
}elseif ($needid = intval($_GET['needid'])){
    $upar = parse_url(hb_currenturl());
    $hb_currenturltmp = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_ho&ac=view&needid=$needid&x=1{$urlext}");
    $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&url='.$hb_currenturltmp;
}