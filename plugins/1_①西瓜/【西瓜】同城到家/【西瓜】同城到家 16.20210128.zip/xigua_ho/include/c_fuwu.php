<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$fuwuid = intval($_GET['fuwuid']);
$v = C::t('#xigua_ho#xigua_ho_fuwu')->fetch_by_id($fuwuid);
$shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($v['uid']);
$v['member']['username'] =$shifu['realname'];
$navtitle = $v['title'] .'-'.$shifu['realname'].'['.$shifu['level_str'].']';
$neelogs = C::t('#xigua_ho#xigua_ho_needlog')->fetch_fuwu_logs($fuwuid);
$is_mine = $_G['uid'] && $_G['uid']==$v['uid'];