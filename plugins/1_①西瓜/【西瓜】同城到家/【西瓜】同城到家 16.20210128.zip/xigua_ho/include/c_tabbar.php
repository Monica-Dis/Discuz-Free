<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$custom_nav = C::t('#xigua_ho#xigua_ho_nav')->fetch_index();
$navcount = count($custom_nav);
$is_off = 1;
$curturl = hb_currenturl();
$ehckac=$_GET['ac'];
if(!isset($_GET['high'])){
    $curturl .= '&high=0';
}elseif($ehckac=='order' && !$_GET['high']){
    $curturl .= '&high=3';
}