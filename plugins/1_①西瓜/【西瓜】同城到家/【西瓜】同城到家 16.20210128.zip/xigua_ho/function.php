<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

function ho_pubneed_callback($param){
    global $_G,$urlext;
    $ho_config = $_G['cache']['plugin']['xigua_ho'];
    $info = $param['info'];
    $data = $info['data'];

    $newid = intval($data['newid']);
    $newdata = $data['newdata'];
    C::t('#xigua_ho#xigua_ho_need')->update($newid, array(
        'status' => 2,
        'payts'  => TIMESTAMP,
    ));
    if($ho_config['fbxqtz']){
        $user = getuserbyuid($newdata['uid'], 1);
        C::t('#xigua_ho#xigua_ho_shifu')->notice_to_shifu($newid, $newdata['title'], $newdata['catid'], $user['username']);
    }
    return true;
}

function ho_common_ruzhusf($param){
    global $_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];

    $newid = intval($data['newid']);
    $newdata = $data['newdata'];
    C::t('#xigua_ho#xigua_ho_shifu')->update($newid, array(
        'status' => 1,
        'payts'  => TIMESTAMP,
    ));
    return true;
}

function need_dig_callback($param){
    global $_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];

    $needid = intval($data['needid']);
    $need = C::t('#xigua_ho#xigua_ho_need')->fetch($needid);
    $last = intval($data['last'])*86400;
    C::t('#xigua_ho#xigua_ho_need')->update($needid, array('dig_startts' => TIMESTAMP, 'dig_endts' => max($need['dig_endts'], TIMESTAMP)+$last));
    return true;
}
function fuwu_dig_callback($param){
    global $_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];

    $fuwuid = intval($data['fuwuid']);
    $fuwu = C::t('#xigua_ho#xigua_ho_fuwu')->fetch($fuwuid);
    $last = intval($data['last'])*86400;
    C::t('#xigua_ho#xigua_ho_fuwu')->update($fuwuid, array('dig_startts' => TIMESTAMP, 'dig_endts' => max($fuwu['dig_endts'], TIMESTAMP)+$last));
    return true;
}

function ho_confirmneed_callback($param){
    global $_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];
    $needlogid = intval($data['needlogid']);
    $needid = $data['needid'];
    $price = $data['price'];

    C::t('#xigua_ho#xigua_ho_need')->update($needid, array(
        'status' => 2,
        'payts'  => TIMESTAMP,
        'totalprice'  => $price,
        'gongzi'  => $price,
    ));
    C::t('#xigua_ho#xigua_ho_needlog')->update($needlogid, array(
        'payts'  => TIMESTAMP,
    ));
    $needlog = C::t('#xigua_ho#xigua_ho_needlog')->fetch($needlogid);
    C::t('#xigua_ho#xigua_ho_needlog')->confirm_order($needlogid, $needlog);
    return true;
}