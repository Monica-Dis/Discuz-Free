<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}

function ho_init(){
}
function lang_ho($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_ho', $lang);
    }else{
        return lang('plugin/xigua_ho', $lang);
    }
}
function ho_set_parse($str){
    global $_G,$SCRITPTNAME;
    $rs = array();
    if($pic_string = $str){
        $top_pics = array_filter(explode("\n", $pic_string));
        if(!empty($top_pics) && is_array($top_pics)){
            foreach ($top_pics as $top_pic) {
                $top_pic = str_replace(array('|',','), ' ', trim($top_pic));
                list( $word, $src, $href) = explode(' ', $top_pic);
                $word = trim($word);
                $src = trim($src);
                $href = trim($href);
                if(empty($href) || $href == '#'){
                    $href = 'javascript:void(0);';
                }
                if($src && $href){
                    if(strpos($src, 'http://') === false && strpos($src, 'https://') === false){
                        $src = $_G['siteurl'] . $src;
                    }
                    $rs[] = array('href' => str_replace('plugin.php', $SCRITPTNAME ,$href), 'src' =>$src, 'name' => $word);
                }
            }
        }
    }
    return $rs;
}

function ho_vars($catid){
    $vars = C::t('#xigua_ho#xigua_ho_var')->fetch_all_by_pluginid('bm_'.$catid);
    return $vars;
}

function ho_check_bind(){
    global $_G,$ho_config,$SCRITPTNAME;
    $user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
    if(!$ho_config['chkmobile']){
        return true;
    }
    if($user['mobile']){
        return true;
    }else{
        if ($_GET['inajax']) {
            hb_message(lang_hb('plzbind', 0), 'error', $SCRITPTNAME.'?id=xigua_hb&ac=myzl'.$GLOBALS['urlext']);
        } else {
            dheader('location: ' . $SCRITPTNAME.'?id=xigua_hb&ac=myzl&referer='.urlencode(hb_currenturl()).$GLOBALS['urlext']);
        }
        return false;
    }
}

function ho_qrcode($mpid, $url, $avatar = '', $fuwuid = 0, $needid = 0){
    global $SCRITPTNAME, $job_config, $_G,$urlext;

    if($job_config['typewx'] ==2){
        $upar = parse_url($url);
        if($fuwuid){
            $hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_ho&ac=fuwu&fuwuid=$fuwuid&x=1");
            $_qrfile = './source/plugin/xigua_ho/cache/fuwu' . $fuwuid . '.jpg';
        }elseif($needid){
            $hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_ho&ac=view&needid=$needid&x=1");
            $_qrfile = './source/plugin/xigua_ho/cache/need_' . $needid . '.jpg';
        }else{
            $hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_ho&ac=shifu&shifuid=$mpid&x=1");
            $_qrfile = './source/plugin/xigua_ho/cache/shifu' . $mpid . '.jpg';
        }
        if (!is_file(DISCUZ_ROOT . $_qrfile)){
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')){
                QRcode::png($hb_currenturl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
            }
        }
        $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&logo='.urlencode($avatar).'&url='.$hb_currenturl;
        return $shqr;
    }else{
        $config = $_G['cache']['plugin']['xigua_hb'];
        if($config['qraut']){
            if($fuwuid) {
                return "$SCRITPTNAME?id=xigua_hb:qrauto&ode=fuwu_{$fuwuid}{$urlext}";
            }elseif($needid){
                return "$SCRITPTNAME?id=xigua_hb:qrauto&ode=need_{$needid}{$urlext}";
            }else{
                return "$SCRITPTNAME?id=xigua_hb:qrauto&ode=shifu_{$mpid}{$urlext}";
            }
        }
        $repath = './source/plugin/xigua_ho/cache/';
        $qrfile = $repath . $mpid.'_'.$fuwuid.'_'.$needid . '.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;
        if(!is_file($abs_qrfile)) {
            if (!is_file($abs_qrfile)) {
                @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                if(class_exists('QRcode')){
                    QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
                }
            }
        }
        return $qrfile;
    }
}


function ho_current_location($lat, $lng){
    global $ho_config;
    $url = "http://apis.map.qq.com/ws/geocoder/v1/?location=$lat,$lng&coord_type=5&get_poi=1&key=".$ho_config['skey'];
    $ret = hb_curl($url);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        $rt = array();
        $rt[$ret['result']['address']] = array(
            'address'           => str_replace(array($ret['result']['address_component']['province'], $ret['result']['address_component']['city']), '', $ret['result']['address']),
            'address_component' => array(
                'province' => $ret['result']['address_component']['province'],
                'city'     => $ret['result']['address_component']['city'],
                'district' => $ret['result']['address_component']['district'],
                'street'   => $ret['result']['address_component']['street'],
                'street_number'=>$ret['result']['address_component']['street_number'],
            ),
            'location'          => $ret['result']['location'],
            'category'          => diconv(lang('plugin/xigua_ho', 'default'), CHARSET, 'utf-8'),
        );
        foreach ($ret['result']['pois'] as $index => $pois) {
            $rt[$pois['address']] = array(
                'address'           => str_replace(array($pois['ad_info']['province'], $pois['ad_info']['city']), '', $pois['address']),
                'address_component' => array(
                    'province' => $pois['ad_info']['province'],
                    'city'     => $pois['ad_info']['city'],
                    'district' => $pois['ad_info']['district'],
                    'street'   => '',
                    'street_number'=> '',
                ),
                'location'          => $pois['location'],
                'category'          => $pois['category'],
            );
        }
        $rt = array_values($rt);
        return  ho_multi_diconv($rt, 'utf-8', 'utf-8');
    }else{
        return ho_multi_diconv($ret['message'], 'utf-8', CHARSET);
    }
}
function ho_multi_diconv($string, $in_charset, $out_charset){
    if (is_array($string)) {
        foreach ($string as $key => $val) {
            $string[ $key ] = ho_multi_diconv($val, $in_charset, $out_charset);
        }
    } else {
        $string = diconv($string, $in_charset, $out_charset);
    }
    return $string;
}

function ho_hex2rgb($colour, $a){
    if ($colour[0] == '#') {
        $colour = substr($colour, 1);
    }
    if (strlen($colour) == 6) {
        list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
    }
    elseif (strlen($colour) == 3) {
        list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
    }
    else {
        return false;
    }
    $r = hexdec($r);
    $g = hexdec($g);
    $b = hexdec($b);
    return "rgba($r, $g, $b, $a)";
}

function ho_get_shs_by_uid(){
    global $_G;
    $shids = array();
    if(!$_G['uid'] || !$_G['cache']['plugin']['xigua_hs']){
        return array();
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array_keys($shids1), array_keys($shids2));
    if($shids){
        $ret = DB::fetch_all('select uid,shid,name from %t WHERE shid in (%n)', array(
            'xigua_hs_shanghu',
            $shids
        ),'shid');
        return $ret;
    }
    return array();
}