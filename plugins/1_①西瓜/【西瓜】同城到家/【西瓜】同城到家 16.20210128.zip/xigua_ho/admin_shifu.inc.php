<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if (empty($_G['cache']['plugin'])) :
    loadcache('plugin');
endif;
$ho_config = $_G['cache']['plugin']['xigua_ho'];
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_ho/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_ho/common_status.php';

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$pzfield = array();

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" /><style>img{object-fit:cover}</style>";
if($secid = intval($_GET['secid'])){
    $res = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_id($secid);
    $unsetary =array(
        'allnum' ,'id', 'hy', 'hangye_id1', 'shname', 'type_u','is_dig','dig_endts_u', 'upts_u','crts_u','gender_u','fuli_ary','jdstatus','endts', 'dig_days',
        'jineng_ary','jineng_str_ary','areawant','areawant_str_ary','level_str', 'score' ,'jineng_str', 'areawant_ary'
    );
    $ts_ary = array('crts', 'upts', 'dig_startts','dig_endts', 'endts', 'payts');
    $listinfo = C::t('#xigua_ho#xigua_ho_cat')->list_all(1);
    C::t('#xigua_ho#xigua_ho_cat')->init($listinfo);
    $cat_list = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $neww = 1;
            $res = array ('displayorder' => '0', 'uid' => '1', 'level' => '0', 'status' => '1', 'realname' => '', 'gender' => '1', 'avatar' => '', 'addr' => '', 'mobile' => '', 'province' => '', 'city' => '', 'district' => '', 'street' => '', 'street_number' => '', 'lat' => '', 'lng' => '', 'shname' => '', 'shid' => '0', 'jineng' => '', 'jineng_str' => '', 'jingyan' => '0', 'areawant' => '', 'areawant_str' => '', 'jieshao' => '', 'album' => array (  ), 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'dig_startts' => '0', 'dig_endts' => '0', 'dig_days' => '0', 'endts' => '0', 'jiedannum' => '0', 'fadannum' => '0', 'score' => '0', 'views' => '0', 'zans' => '0', 'shares' => '0', 'follows' => '0', 'stid' => '0',  );
        }
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_ho('spgl',0) . ($secid>0?'-'. $res['title']." [ID : $secid]" :''). "&nbsp;&nbsp;<a class='abtn' href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu'>".lang_ho('back',0)."</a>");

        foreach ($res as $index => $re) {
            if(in_array($index, $unsetary)){
                continue;
            }
            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, $ts_ary)){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('shid')) && $_G['cache']['plugin']['xigua_hs']){
                $cs = '<select name="editform[shid]">';
                $shs = DB::fetch_all('select shid,`name` from %t WHERE display=1 AND endts>=%d ORDER BY shid asc', array( 'xigua_hs_shanghu',TIMESTAMP), 'shid');
                $shs[0] = array('shid' => 0,'name' => '------',);
                foreach ($shs as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['shid']} {$c['name']}</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('jineng'))){
                $__tmp = $cat_list;
                $cs = '<select name="editform[jineng][]" multiple="multiple" style="height:200px">';
                $re_tmp = explode(',', $re);
                foreach ($cat_list as $c_t => $c) {
                    $s = $extp = '';
                    $cs .= "<optgroup label='$c[name]'>";
                    foreach ($c['child'] as $vv) {
                        $s = '';
                        if(in_array($vv['id'], $re_tmp)){
                            $s = 'selected';
                        }
                        $cs .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;L$vv[name]</option>";
                    }
                    $cs .= '</optgroup>';
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('type', 'gender','level'))){
                if($index=='type'){
                    $__tmp = $ho_need_types;
                    $cs = '<select name="editform[type]">';
                }elseif($index=='gender'){
                    $__tmp = $gender_ary;
                    $cs = '<select name="editform[gender]">';
                }elseif($index=='level'){
                    $__tmp = $levels;
                    $cs = '<select name="editform[level]">';
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    if($index=='level'){
                        $cs .= "<option $s value='$c_t'>{$c['name']}</option>";
                    }else{
                        $cs .= "<option $s value='$c_t'>$c</option>";
                    }
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($shifu_status as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('showbm' ,'tuijian','showdis', 'selfdis', 'orderdis', 'newp', 'allow_tk','openmobile'))){
                $tp = 'radio';
            }elseif(in_array($index, array('catid'))){
                $hangye = "<select name=\"editform[catid]\" onchange='changeurl(this.value)'>";
                foreach ($cat_list as $k => $v) {
                    $hangye .= "<optgroup label='$v[name]'>";
                    foreach ($v['child'] as $vv) {
                        $s = '';
                        if($res['catid']== $vv['id']){
                            $s = 'selected';
                        }
                        $hangye .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;L$vv[name]</option>";
                    }
                    $hangye .= '</optgroup>';
                }
                $hangye .= '</select>';
                $tp = $hangye;
            }elseif(in_array($index, array('avatar'))){
                $tp = 'filetext';
            }
            if (in_array($index, array('album'))) {
                $re = !is_array($re) ? unserialize($re) : $re;
                $tp = 'filetext';
                $ho_config = $_G['cache']['plugin']['xigua_ho'];
                $loopnum = $ho_config['maximg'];
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_ho($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'customtxt'){
                $tp = 'textarea';
                $cmt = lang_ho('customtxttip',0);
                showsetting(lang_ho($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_ho($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                showsetting(lang_ho($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');function changeurl(val){window.location.href = window.location.href+'&catid='+val;}</script>
HTML;

    }else{
        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach ($ts_ary as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }
        $jineng_str = $listwithkey = array();
        foreach ($listinfo as $index => $item) {
            $listwithkey[$item['id']] = $item;
        }
        foreach ($editform['jineng'] as $index => $item) {
            $jineng_str[] = $listwithkey[$item]['name'];
        }
        $editform['jineng'] = implode(',', $editform['jineng']);
        $editform['jineng_str'] = implode(',', $jineng_str);

        $eqdq = explode(',', $editform['areawant_str']);
        $__areawant = $areawant_str_tmp = array();
        $distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
        foreach ($distlist as $index => $item) {
            $itemname = diconv($item['name'], 'UTF-8', CHARSET);
            $areawant_str_tmp[$itemname] = $item['code'];
        }
        foreach ($eqdq as $index => $item) {
            $__areawant[$item] = $areawant_str_tmp[$item];
        }
        $editform['areawant'] = implode(',', $__areawant);

        $jntmp = explode(',', $editform['jineng_str']);

        $editform['jieshao'] = htmlspecialchars_decode($editform['jieshao']);
        foreach (array('album') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }
        if($secid>0){
            $rs = C::t('#xigua_ho#xigua_ho_shifu')->update($secid, $editform);
            $hid = $secid;
        }else{
            $hid = C::t('#xigua_ho#xigua_ho_shifu')->insert($editform, 1);
        }
        cpmsg(lang_ho('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu&secid=$hid", 'succeed');
    }
}else {
    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_ho#xigua_ho_shifu')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            $old_status = DB::fetch_first('select uid,status from %t where id=%d', array('xigua_ho_shifu', $id));
            C::t('#xigua_ho#xigua_ho_shifu')->update($id, array( 'status' => $item['status'], 'displayorder' => $item['displayorder'], 'tuijian' => $item['tuijian']));
            if($old_status['status'] == -1 && $item['status']==1){
                notification_add($old_status['uid'],'system', lang('plugin/xigua_ho', 'shenhetongshif'),array(
                    'href'=>$_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=my",
                ),1);
            }
        }
        cpmsg(lang_ho('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu&shid={$_GET['shid']}&page=$page", 'succeed');
    }
    $wherearr = array();
    if($_GET['catid']){
        $wherearr[] = 'find_in_set('.intval($_GET['catid']) .', jineng)';
    }
    if($_GET['level']){
        $wherearr[] = 'level='.intval($_GET['level']);
    }
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey(addslashes($keyword))) {
        $wherearr[] = " (`realname` LIKE '%$keyword%' OR jineng_str LIKE '%$keyword%' OR areawant_str LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR addr LIKE '%$keyword%' OR mobile LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }
    $ob = 'displayorder desc,id desc';
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_ho('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($shifu_status as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }
    echo '&nbsp;&nbsp;';
    foreach ($alllevels as $index => $_v) {
        echo '<label> <input type="radio" name="level" value="'.$index.'" ' . (isset($_GET['level'])&&$_GET['level']==$index ? 'checked' : '') . ' />' . $_v['name'].'</label>';
    }
    echo '&nbsp;&nbsp;';
    $listinfo = C::t('#xigua_ho#xigua_ho_cat')->list_all(1);
    C::t('#xigua_ho#xigua_ho_cat')->init($listinfo);
    $cat_list = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
    $check0 = $_GET['catid']?'':'selected';
    $csearch = "&nbsp;<select name=\"catid\">";
    $csearch .= "<option value=\"0\" $check0 >".lang_hb('quanbu',0)."</option>";
    foreach ($cat_list as $k => $v) {
        $check1 = $_GET['catid']==$v['id']?'selected':'';
        $csearch .= "<option value=\"$v[id]\" $check1 >$v[name]</option>";
        foreach ($v['child'] as $kk => $vv) {
            $check2 = $_GET['catid']==$vv['id']?'selected':'';
            $csearch .= "<option value=\"$vv[id]\" $check2 >&nbsp;&nbsp;$vv[name]</option>";
        }
    }
    $csearch .= '</select>';
    echo '&nbsp;&nbsp;';
    echo $csearch;

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu".' class="btn" >'.cplang('reset').'</a> ';
    echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}.mt3{margin-top:3px}.c9{color:#999}
.jobtit{font-size:13px;color:#369}.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;font-size:12px;border-radius:2px}
.jthumb{width:50px;height:50px;border-radius:50%}.red{color:#ff6565}.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.tyu{width:60px;display:block;color:#4caf50}.tyu.jingjia{color:#ff6565}.vdesc{width:250px;max-height:150px;overflow-y:auto}.priceText{color:#ff6565}.qy{color:#4F7CB8}.v_mingxi{max-width:250px}.btn2{padding: 3px 5px;line-height:30px;}.btn3{background: #DADADA;color: #999;}
</style>";
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu&secid=-1\" class=\"btn bg_green\">".lang_ho('tjsp',0)."</a></div>";

    showtableheader(lang_ho('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_ho('del', 0),
        lang_ho('displayorder', 0),
        lang_ho('tuijian', 0),
        lang_ho('avatar', 0),
        lang_ho('shifu', 0),
        lang_ho('shif_zl', 0),
        lang_ho('shifu_xq', 0),
        lang_ho('status', 0),
        lang_ho('crts', 0),
        lang_ho('caozuo', 0),
    ));
    $res = C::t('#xigua_ho#xigua_ho_shifu')->fetch_all_by_page($start_limit, $lpp, $wherearr, '*', $ob);
    $icount = C::t('#xigua_ho#xigua_ho_shifu')->fetch_count_by_page($wherearr);

    $uids = $shids = array();
    foreach ($res as $k => $v) {
        $uids[$v['uid']] = $v['uid'];
        if ($v['shid']) {
            $shids[$v['shid']] = $v['shid'];
        }
    }
    if($_G['cache']['plugin']['xigua_hr']){
        $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids);
        $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids, 2);
        $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($_G['cache']['plugin']['xigua_hs'] && $shids){
        $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }
    $miaoshu = lang_ho('shifu_xq',0);
    $gongzi = lang_ho('gongzi',0);
    $bxprice = lang_ho('bxprice',0);
    $totalprice = lang_ho('totalprice',0);
    $tlevel = lang_ho('level',0);
    $shiming = lang_ho('shiming',0);
    $lang_qy = lang('plugin/xigua_hr', 'qy');
    $lang_jineng_str = lang('plugin/xigua_ho', 'jineng_str');
    $lang_yuan = lang('plugin/xigua_ho', 'yuan');
    $lang_nian = lang('plugin/xigua_ho', 'nian');
    $lang_short_jingyan = lang('plugin/xigua_ho', 'short_jingyan');
    $lang_fwqy = lang('plugin/xigua_ho', 'fwqy');
    $lang_lxaddr = lang('plugin/xigua_ho', 'lxaddr');
    $lang_shid = lang('plugin/xigua_ho', 'shid');
    $lang_qy = lang('plugin/xigua_ho', 'qy');
    $lang_gr = lang('plugin/xigua_ho', 'gr');
    foreach ($res as $v) {
        $id = $v['id'];
        $thumb = $v['avatar'] ?$v['avatar'] : 'source/plugin/xigua_ho/static/img/dftava.png';
        $img = '';
        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }
        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($shifu_status as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';
        $digstr = $v['is_dig'] ? '<span class="dig">'.lang_ho('dig',0).'</span>' : '';
        $shiftupe = $v['shid'] ? "<em class=\"qy\">$lang_qy</em>" : "<em class=\"c_green\">$lang_gr</em>";
        $shif = "<p class='mt3'><em class='c9'>$tlevel : </em>{$alllevels[$v['level']]['name']}</p>";
        $description = "<div class=\"vdesc\">$shif $detail<p class='mt3'><em class='c9'>$miaoshu : </em>".$v['jieshao']."</p><p class=\"mt3\">$img</p></div>";

        $shifu_zl = "<ul class=\"v_mingxi cl\"><li>
".($veris1[$v['uid']] ? "<span class='c_green'> $shiming</span> " : '')."
".($v['shid'] && $veris2[$v['uid']] ? " <span class='qy'> $lang_qy</span>" : '')."
".($bao[$v['uid']] ? " <span class='priceText'>{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}$lang_yuan </span>" : '')."
</li><li><span class='c9'>$lang_jineng_str : </span> <span> $v[jineng_str]</span></li>
<li><span class='c9'>$lang_fwqy : </span> <span> $v[areawant_str]</span></li>
<li><span class='c9'>$lang_lxaddr : </span> <span> $v[province]$v[city]$v[addr]</span></li>
".($v['shid'] ? "<li><span class='c9'>$lang_shid : </span> <span> {$shinfos[$v['shid']]['name']} [ {$v['shid']} ]</span></li>" : '')."
</ul>";
        $istuijian = $v['tuijian'] ? 'checked':'';
        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input style='width:20px' type='text' class='txt' name='row[$id][displayorder]' value='{$v[displayorder]}' />",
            "<input type=\"checkbox\" class=\"checkbox\" name=\"row[$id][tuijian]\" value=\"1\" $istuijian />",
            "<img src='$thumb' class='jthumb' />",

            '<p><em class="c9">'.lang_ho('username',0).' : </em>'.$users[$v['uid']]['username'].' <em>[ '.$v['uid'].' ]</em></p>'.
            ($v['realname'] ? '<p class="mt3"><em class="c9">'.lang_ho('realname',0).' : </em>'.$v['realname'].'</p>' : '').
            '<p class="mt3"><em class="c9">'.lang_ho('sjh',0).' : </em>'.$v['mobile'].'</p>'.
            "<p class=\"mt3\">$shiftupe $lang_short_jingyan{$v[jingyan]}$lang_nian / {$gender_ary[$v['gender']]}</p>",

            $shifu_zl,
            $description,
            $status_u,
            '<p><em class="c9">'.lang_ho('crts',0).' : </em>'.date('Y-m-d H:i:s', $v['crts']).'</p>'.
            '<p class="mt3"><em class="c9">'.lang_ho('upts2',0).' : </em>'.date('Y-m-d H:i:s', $v['upts']).'</p>'.
            ($v['dig_endts_u'] ? '<p class="mt3"><em class="c9">'.lang_ho('dig_endts',0).' : </em>'.$v['dig_endts_u'].'</p>':'').
            ($v['payts'] ? '<p class="mt3 c_green"><em>'.lang_ho('payts',0).' : </em>'.date('Y-m-d H:i:s', $v['payts']).'</p>':'').
            '',
            '<a class=\'btn bg_green btn2\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu&secid=$id" . '">' . lang_ho('edit', 0) . '</a>',
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_shifu&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
}