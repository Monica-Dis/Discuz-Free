<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}
$rzfy = $ho_config['rzfy'];
$levels = array();
foreach (array_filter(explode("\n", trim($ho_config['levels']))) as $index => $item) {
    list($name, $prate, $autonum) = explode('|', trim($item));
    $levels[$index] = array(
        'name' => $name,
        'autonum' => $autonum,
        'prate' => $prate
    );
}
$array1 = array(-1=>array(
    'name' => lang('plugin/xigua_ho', 'buxian'),
));
$alllevels = $array1+$levels;
$baoxian = array();
foreach (array_filter(explode("\n", trim($ho_config['bxtc']))) as $index => $item) {
    list($name, $price) = explode('|', trim($item));
    $baoxian[$index] = array(
        'name' => $name,
        'price' => $price,
    );
}
$array1 = array(-1=>array(
    'name' => lang('plugin/xigua_ho', 'bgm'),
    'price' => 0
));
$allbaoxian = $array1+$baoxian;
$need_status=array(
    1 => lang('plugin/xigua_ho', 'need_status1'),
    -2=> lang('plugin/xigua_ho', 'need_status-2'),
    3 => lang('plugin/xigua_ho', 'need_status3'),
    9 => lang('plugin/xigua_ho', 'need_status9'),
    2 => lang('plugin/xigua_ho', 'need_status2'),
    4 => lang('plugin/xigua_ho', 'need_status4'),
    8 => lang('plugin/xigua_ho', 'need_status8'),
);
$ho_need_types = array(
    'yikou' => lang('plugin/xigua_ho', 'yikou'),
    'jingjia' => lang('plugin/xigua_ho', 'jingjia'),
);
$short_need_types = array(
    'yikou' => lang('plugin/xigua_ho', 'yikou_short'),
    'jingjia' => lang('plugin/xigua_ho', 'jingjia_short'),
);
$jdstatus = array(
    -1=> lang('plugin/xigua_ho', 'jdstatus-1'),
    1=> lang('plugin/xigua_ho', 'jdstatus1'),
    2=> lang('plugin/xigua_ho', 'jdstatus2'),
    3=> lang('plugin/xigua_ho', 'jdstatus3'),
);
$dig_prices = array();
if($ho_config['digtys']){
    foreach (explode("\n", trim($ho_config['digtys'])) as $item) {
        list($tmp_type, $tmp_price) = explode('=', trim($item));
        $tmp_lang = lang_hb('days_'.$tmp_type, 0);
        $dig_prices[$tmp_type] = array(
            'type'  => $tmp_type,
            'title' => lang_hb('zhiding', 0). ($tmp_lang == "days_$tmp_type" ? $tmp_type. lang_hb('day', 0) : $tmp_lang) ."(".lang_hb('shoufei', 0)."$tmp_price".lang_hb('yuan', 0).")",
            'price' => $tmp_price,
        );
    }
}
$needlog_status = array(
    '-1' => lang('plugin/xigua_ho', 'needlog_status-1'),
    '1'  => lang('plugin/xigua_ho', 'needlog_status1'),
    '4'  => lang('plugin/xigua_ho', 'needlog_status4'),
    '2'  => lang('plugin/xigua_ho', 'needlog_status2'),
    '3'  => lang('plugin/xigua_ho', 'needlog_status3'),
);
$gender_ary = array(
    -1 => lang('plugin/xigua_ho', 'buxian'),
    1 => lang('plugin/xigua_ho', 'gender1'),
    2 => lang('plugin/xigua_ho', 'gender2'),
);
$shifu_status = array(
    1=> lang('plugin/xigua_ho', 'shifu_status1'),
    -1=>lang('plugin/xigua_ho', 'shifu_status-1'),
    -2=>lang('plugin/xigua_ho', 'shifu_status-2'),
);
$fuwu_status = array(
    1=> lang('plugin/xigua_ho', 'fuwu_status1'),
    -1=>lang('plugin/xigua_ho', 'fuwu_status-1'),
    -2=>lang('plugin/xigua_ho', 'fuwu_status-2'),
);$fwunits = array();
foreach (array_filter(explode("\n", $ho_config['fuwudw'])) as $index => $item) {
    list($kkk, $vvv) = explode('=', trim($item));
    $fwunits[$kkk] = $vvv;
}