<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if (empty($_G['cache']['plugin'])) :
    loadcache('plugin');
endif;
$ho_config = $_G['cache']['plugin']['xigua_ho'];
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_ho/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_ho/common_status.php';

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$pzfield = array();

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" /><style>img{object-fit:cover}</style>";
if($secid = intval($_GET['secid'])){
    $res = C::t('#xigua_ho#xigua_ho_need')->fetch_by_id($secid);
    $unsetary =array('allnum' ,'id', 'hy', 'hangye_id1', 'shname', 'type_u','is_dig','dig_endts_u', 'upts_u','crts_u','gender_u','fuli_ary','jdstatus','endts', 'dig_days');
    $ts_ary = array('crts', 'upts', 'dig_startts','dig_endts', 'endts');
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $neww = 1;
            $res = array ('catid' => $_GET['catid'],'type' => 'jingjia','uid' => '0','status' => '2','crts' => TIMESTAMP,'upts' => TIMESTAMP,'title' => '','level' => '0',
'neednum' => '0','needays' => '0','vars' => '','description' => '','album' => array(),'addr' => '','lat' => '','lng' => '','dist1' => '','dist2' => '','dist3' => '','street' => '',
'street_number' => '','displayorder' => '0','dig_startts' => '0','dig_endts' => '0','dig_days' => '0','endts' => '0','views' => '6','zans' => '0','shares' => '0','follows' => '0','stid' => '0',
'orderid' => '','payts' => '0','jdstatus' => '-1','bxtype' => '0','bxnum' => '1','price' => 0,'totalprice' => '0.00','gongzi' => '0.00','bxprice' => '0.00','mobile' => '','realname' => '');
        }
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_ho('spgl',0) . ($secid>0?'-'. $res['title']." [ID : $secid]" :''). "&nbsp;&nbsp;<a class='abtn' href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need'>".lang_ho('back',0)."</a>");

        $listinfo = C::t('#xigua_ho#xigua_ho_cat')->list_all(1);
        C::t('#xigua_ho#xigua_ho_cat')->init($listinfo);
        $cat_list = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
        if($neww && !$_GET['catid']){
            $catkeys = array_keys($cat_list);
            $_GET['catid'] = $catkeys[0];
        }
        $res['catid'] = $_GET['catid'] ? $_GET['catid'] : $res['catid'];
        $vars = ho_vars($res['catid']);
        foreach ($res as $index => $re) {
            if(in_array($index, $unsetary)){
                continue;
            }
            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, $ts_ary)){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('jingyan', 'xueli'))){
                if($index=='jingyan'){
                    $__tmp = $jingyan;
                    $cs = '<select name="editform[jingyan]">';
                }elseif($index=='xueli'){
                    $__tmp = $xueli;
                    $cs = '<select name="editform[xueli]">';
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('type', 'gender','level', 'bxtype', 'jiesuan'))){
                if($index=='type'){
                    $__tmp = $ho_need_types;
                    $cs = '<select name="editform[type]">';
                }elseif($index=='gender'){
                    $__tmp = $gender_ary;
                    $cs = '<select name="editform[gender]">';
                }elseif($index=='level'){
                    $__tmp = $alllevels;
                    $cs = '<select name="editform[level]">';
                }elseif($index=='bxtype'){
                    $__tmp = $allbaoxian;
                    $cs = '<select name="editform[bxtype]">';
                }elseif($index=='jiesuan'){
                    $__tmp = $jiesuan;
                    $cs = '<select name="editform[jiesuan]">';
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    if($index=='level'){
                        $cs .= "<option $s value='$c_t'>{$c['name']}</option>";
                    }elseif($index =='bxtype'){
                        $cs .= "<option $s value='$c_t'>{$c['name']} ({$c['price']}".lang_ho('yuan', 0).") </option>";
                    }else{
                        $cs .= "<option $s value='$c_t'>$c</option>";
                    }
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($need_status as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('showbm' ,'tuijian','showdis', 'selfdis', 'orderdis', 'newp', 'allow_tk','openmobile'))){
                $tp = 'radio';
            }elseif(in_array($index, array('catid'))){
                $hangye = "<select name=\"editform[catid]\" onchange='changeurl(this.value)'>";
                foreach ($cat_list as $k => $v) {
                    $hangye .= "<optgroup label='$v[name]'>";
                    foreach ($v['child'] as $vv) {
                        $s = '';
                        if($res['catid']== $vv['id']){
                            $s = 'selected';
                        }
                        $hangye .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;L$vv[name]</option>";
                    }
                    $hangye .= '</optgroup>';
                }
                $hangye .= '</select>';
                $tp = $hangye;
            }

            if(in_array($index, array('fengmian'))){
                $tp = 'filetext';
            }
            if (in_array($index, array('vars'))) {
                $re = unserialize($re);
                foreach ($vars as $ii => $var) {
                    $varname = "editform[$index][{$var['pluginvarid']}]";
                    if ($var['type'] == 'select' || $var['type'] == 'selects') {
                        $multisl = '';
                        if($var['type'] == 'selects'){
                            $multisl = 'multiple=\'multiple\'';
                            $varname = "editform[$index][{$var['pluginvarid']}][]";
                        }
                        $options = '';
                        $extra = explode("\n", trim($var['extra']));
                        foreach ($extra as $extra_string) {
                            list($tmp1, $tmp2) = explode('=', trim($extra_string));
                            if($multisl){
                                $sel = in_array($tmp1, $re[$var['pluginvarid']]['value'])  ? 'selected' : '';
                            }else{
                                $sel = $re[$var['pluginvarid']]['value'] == $tmp1 ? 'selected' : '';
                            }
                            $options .= "<option value=\"$tmp1\" $sel>$tmp2</option>";
                        }

                        showsetting($var['title'], '', '', "<select $multisl name=\"$varname\">$options</select>");
                    } elseif($var['type']=='location') {
                        showsetting($var['title'], $varname, $re[$var['pluginvarid']]['html'], 'text');
                    } elseif($var['type']=='datetime') {
                        showsetting($var['title'], $varname, $re[$var['pluginvarid']]['value'], 'calendar', '', 0, $cmt, 1);
                    } else {
                        showsetting($var['title'], $varname, $re[$var['pluginvarid']]['value'], 'text');
                    }
                }
            }elseif (in_array($index, array('album'))) {
                $re = !is_array($re) ? explode("\t", $re) : $re;
                $tp = 'filetext';
                $ho_config = $_G['cache']['plugin']['xigua_ho'];
                $loopnum = $ho_config['maximg'];
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_ho($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'customtxt'){
                $tp = 'textarea';
                $cmt = lang_ho('customtxttip',0);
                showsetting(lang_ho($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }elseif($index == 'description'){
                $_tmp1 = lang_ho($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[description]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                showsetting(lang_ho($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');
function changeurl(val){window.location.href = window.location.href+'&catid='+val;}
</script>
HTML;

    }else{
        $editform = $_GET['editform'];
        $vars = ho_vars($editform['catid']);
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach ($ts_ary as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }
        $editform['description'] = htmlspecialchars_decode($editform['description']);
        foreach (array('album') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = implode("\t", $editform[$item]);
        }
        foreach ($editform['vars'] as $index => $var) {
            $html = '';
            foreach (explode("\n", trim($vars[$index]['extra'])) as $str => $extra_string) {
                list($_tmp1, $_tmp2) = explode('=', trim($extra_string));
                $_tmp2 = trim($_tmp2);
                if($_tmp1 == $var){
                    $html = $_tmp2;
                    break;
                }elseif(in_array($_tmp1, $var)){
                    $html .= ' '.$_tmp2;
                }
            }
            if($vars[$index]['type']=='location'){
                $html = $var;
                $var = array(
                    $var,
                    $editform['lat'],
                    $editform['lng'],
                );
            }
            $editform['vars'][$index] = array(
                'title' => $vars[$index]['title'],
                'value' => $var,
                'html'  => ($html ? $html : $var).$vars[$index]['unitnew'],
                'type' => $vars[$index]['type'],
            );
            if($vars[$index]['type']=='area'){
                list($tmp1, $tmp2, $tmp3) = explode(' ', $var);
                $editform['dist1'] = $tmp1;
                $editform['dist2'] = $tmp2;
                $editform['dist3'] = $tmp3;
            }
        }
        $editform['vars'] = serialize($editform['vars']);
        if($secid>0){
            $rs = C::t('#xigua_ho#xigua_ho_need')->update($secid, $editform);
            $hid = $secid;
        }else{
            $hid = C::t('#xigua_ho#xigua_ho_need')->insert($editform, 1);
        }
        cpmsg(lang_ho('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need&secid=$hid", 'succeed');
    }
}else {
    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_ho#xigua_ho_need')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_ho#xigua_ho_need')->update($id, array( 'status' => $item['status'], 'displayorder' => $item['displayorder']));
        }
        cpmsg(lang_ho('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need&shid={$_GET['shid']}&page=$page", 'succeed');
    }
    $wherearr = array();
    if($_GET['catid']){
        $wherearr[] = 'catid='.intval($_GET['catid']);
    }
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey(daddslashes($keyword))) {
        $wherearr[] = " (title LIKE '%$keyword%' OR vars LIKE '%$keyword%' OR description LIKE '%$keyword%' OR addr LIKE '%$keyword%' OR mobile LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }
    $ob = 'displayorder desc,id desc';
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_ho('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($need_status as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }
    $listinfo = C::t('#xigua_ho#xigua_ho_cat')->list_all(1);
    C::t('#xigua_ho#xigua_ho_cat')->init($listinfo);
    $cat_list = C::t('#xigua_ho#xigua_ho_cat')->get_tree_array(0);
    $check0 = $_GET['catid']?'':'selected';
    $csearch = "&nbsp;<select name=\"catid\">";
    $csearch .= "<option value=\"0\" $check0 >".lang_hb('quanbu',0)."</option>";
    foreach ($cat_list as $k => $v) {
        $check1 = $_GET['catid']==$v['id']?'selected':'';
        $csearch .= "<option value=\"$v[id]\" $check1 >$v[name]</option>";
        foreach ($v['child'] as $kk => $vv) {
            $check2 = $_GET['catid']==$vv['id']?'selected':'';
            $csearch .= "<option value=\"$vv[id]\" $check2 >&nbsp;&nbsp;$vv[name]</option>";
        }
    }
    $csearch .= '</select>';
    echo $csearch;

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need".' class="btn" >'.cplang('reset').'</a> ';
    echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}.mt3{margin-top:3px}.c9{color:#999}
.jobtit{font-size:13px;color:#369}.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;font-size:12px;border-radius:2px}
.jthumb{width:70px;height:50px}.red{color:#ff6565}.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.tyu{width:60px;display:block;color:#4caf50}.tyu.jingjia{color:#ff6565}.vdesc{max-width:250px;max-height:150px;overflow-y:auto}.priceText{color:#ff6565}.btn2{padding: 3px 5px;line-height:30px;white-space:nowrap}.btn3{background: #DADADA;color: #999;}
</style>";
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need&secid=-1\" class=\"btn bg_green\">".lang_ho('tjsp',0)."</a></div>";

    showtableheader(lang_ho('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_ho('del', 0),
        lang_ho('displayorder', 0),
        lang_ho('thumb', 0),
        lang_ho('xqmc', 0),
        lang_ho('description', 0),
        lang_ho('status', 0),
        lang_ho('fdr', 0),
        lang_ho('crts', 0),
        lang_ho('caozuo', 0),
    ));
    $res = C::t('#xigua_ho#xigua_ho_need')->fetch_all_by_page($start_limit, $lpp, $wherearr, '*', $ob);
    $icount = C::t('#xigua_ho#xigua_ho_need')->fetch_count_by_page($wherearr);
    $catids = array();
    foreach ($res as $k => $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $res[$k]['vars'] = unserialize($v['vars']);
        $catids[] = $v['catid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        $mobiles = DB::fetch_all('SELECT uid,mobile,realname FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
    }
    if($catids){
        $catinfo_tmp = DB::fetch_all('select id,hideyg from %t where id in(%n)', array('xigua_ho_cat',$catids ), 'id');
    }
    $miaoshu = lang_ho('description',0);
    $gongzi = lang_ho('gongzi',0);
    $bxprice = lang_ho('bxprice',0);
    $totalprice = lang_ho('totalprice',0);
    $tlevel = lang_ho('level',0);
    $lang_r = lang_ho('r',0);
    $lang_day = lang_ho('day',0);
    foreach ($res as $v) {
        $id = $v['id'];
        $thumb = $v['album'][0] ?$v['album'][0] : avatar($v['uid'], 'middle', true);

        $img = '';
        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }
        $detail = '';
        foreach ($v['vars'] as $index => $var) {
            $detail .=  '<p class="mt3"><em class="c9">'.$var['title'].' : </em>'.$var['html'].'</p>';
        }

        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($need_status as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';
        $digstr = $v['is_dig'] ? '<span class="dig">'.lang_ho('dig',0).'</span>' : '';

        $price_txt = "<ul class=\"v_mingxi cl\">
    <li><span>$gongzi</span> <span class=\"priceText f12\">&yen; $v[gongzi]</span></li>
    <li><span>$bxprice</span> <span class=\"priceText f12\">&yen; $v[bxprice]</span></li>
    <li><span>$totalprice</span> <span class=\"priceText f12\">&yen; $v[totalprice]</span></li>
</ul>";
        $title_ext = $v['type']=='yikou' ? $price_txt : '';

        $shif = "<p class='mt3'><em class='c9'>$tlevel : </em>{$alllevels[$v['level']]['name']}</p>";
        $description = "<div class=\"vdesc\">$shif $detail<p class='mt3'><em class='c9'>$miaoshu : </em>".$v['description']."</p><p class=\"mt3\">$img</p></div>";

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input style='width:20px' type='text' class='txt' name='row[$id][displayorder]' value='{$v[displayorder]}' />",
            "<img src='$thumb' class='jthumb' />",
            '<span class="tyu '.$v['type'].'">'.$v['type_u'].'</span> '.$v['title'].  (!$catinfo_tmp[$v['catid']]['hideyg'] ? " / $v[neednum]$lang_r / $v[needays] $lang_day" : '').
            "<p class=\"mt3\">$title_ext</p>",
            $description,
            $status_u . ' '. $digstr,
            '<p><em class="c9">'.lang_ho('username',0).' : </em>'.$users[$v['uid']]['username'].' <em>[ '.$v['uid'].' ]</em></p>'.
            ($mobiles[$v['uid']]['realname'] ? '<p class="mt3"><em class="c9">'.lang_ho('realname',0).' : </em>'.$mobiles[$v['uid']]['realname'].'</p>' : '').
            '<p class="mt3"><em class="c9">'.lang_ho('sjh',0).' : </em>'.$mobiles[$v['uid']]['mobile'].'</p>',

            '<p><em class="c9">'.lang_ho('crts',0).' : </em>'.date('Y-m-d H:i:s', $v['crts']).'</p>'.
            '<p class="mt3"><em class="c9">'.lang_ho('upts2',0).' : </em>'.date('Y-m-d H:i:s', $v['upts']).'</p>'.
            ($v['payts'] ? '<p class="mt3 c_green"><em>'.lang_ho('payts',0).' : </em>'.date('Y-m-d H:i:s', $v['payts']).'</p>':'').
            ($v['dig_endts_u'] ? '<p class="mt3"><em class="c9">'.lang_ho('dig_endts',0).' : </em>'.$v['dig_endts_u'].'</p>':'').
            '',
            '<a class=\'btn bg_green btn2\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need&secid=$id" . '">' . lang_ho('edit', 0) . '</a> '.
            (in_array($v['status'], array(1,2,3,9))&& $v['payts']>0 ? ('<a class=\'btn btn2 btn3\' href="javascript:;">' . lang_ho('tuikuan', 0) . '</a>') : ''),
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_ho&pmod=admin_need&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
}