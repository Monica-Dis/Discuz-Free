<?php
/**
 * Created by https://dism.taobao.com/?@xigua
 * User: yangzhiguo
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
DROP TABLE pre_xigua_ho_cat;
DROP TABLE pre_xigua_ho_hangye;
DROP TABLE pre_xigua_ho_nav;
DROP TABLE pre_xigua_ho_need;
DROP TABLE pre_xigua_ho_needlog;
DROP TABLE pre_xigua_ho_shifu;
DROP TABLE pre_xigua_ho_var;
DROP TABLE pre_xigua_ho_fuwu;
EOT;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/discuz_plugin_xigua_ho_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_ho/install.php');

xwbdelall(DISCUZ_ROOT . "./source/plugin/xigua_ho");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_ho");

$finish = TRUE;

function xwbdelall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);
        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwbdelall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}