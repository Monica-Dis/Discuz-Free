<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function ho_fuwu_pay_callback($param){
    global $_G,$urlext,$SCRITPTNAME;
    $info = $param['info'];
    $data = $info['data'];
    $needlogid = intval($data['needlogid']);
    $fuwuid = intval($data['fuwuid']);

    $needlog = C::t('#xigua_ho#xigua_ho_needlog')->fetch($needlogid);
    $fuwu =  C::t('#xigua_ho#xigua_ho_fuwu')->fetch($fuwuid);
    $fuwu_uid = $fuwu['uid'];

    C::t('#xigua_ho#xigua_ho_needlog')->confirm_order($needlogid, $needlog);
    C::t('#xigua_ho#xigua_ho_needlog')->update($needlogid, array('payts'  => TIMESTAMP,));

    $needuser = getuserbyuid($needlog['uid']);
    $user = C::t('#xigua_hb#xigua_hb_user')->fetch($needlog['need_uid']);
    notification_add($fuwu_uid,'system', lang('plugin/xigua_ho', 'jdcg3'),array(
        'realname' => $user['realname'] ? $user['realname'] : $needuser['username'],
        'mobile' => $user['mobile'],
        'title' => $fuwu['title'],
        'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=needlog&fuwuid=$fuwuid$urlext",
    ),1);

    $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($fuwu_uid);
    notification_add($needlog['need_uid'],'system', lang('plugin/xigua_ho', 'jdcg4'),array(
        'realname' => $shifu['realname'],
        'mobile' => $shifu['mobile'],
        'title' => $fuwu['title'],
        'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=order&status=1$urlext",
    ),1);

    return true;
}