<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{loop $list $k $v}-->
<style>
    .ydxs1,.ydxs2,.ydxs3{overflow:hidden;border-radius:.25rem}
    
    .ydxs1>div:first-child{height:5rem}
    
    .ydxs2>div:first-child{width:calc(50% - .15rem);height:5rem;float:left}
    .ydxs2>div:nth-child(2){float:left;width:calc(50% - .15rem);height:5rem;margin-top:0;margin-left:.3rem}
    
    .ydxs3>div:first-child{width:calc(33% - .2rem);height:5rem;float:left}
    .ydxs3>div:nth-child(2){float:left;width:calc(34% - .1rem);height:5rem;margin-top:0;margin-left:.25rem}
    .ydxs3>div:nth-child(3){float:left;width:calc(33% - .2rem);height:5rem;margin-top:0;margin-left:.25rem}
    
    /*.ydxs3>div:first-child{width:calc(50% - .15rem);height:6.3rem;float:left}
    .ydxs3>div:nth-child(2){float:left;width:calc(50% - .15rem);height:3rem;margin-top:0;margin-left:.3rem}
    .ydxs3>div:nth-child(3){float:left;width:calc(50% - .15rem);height:3rem;margin-top:.3rem;margin-left:.3rem}
    
    .ydxs4>div:first-child{width:calc(50% - .15rem);height:3rem;float:left}
    .ydxs4>div:nth-child(2){float:left;width:calc(50% - .15rem);height:3rem;margin-top:0;margin-left:.3rem}
    .ydxs4>div:nth-child(3){width:calc(50% - .15rem);height:3rem;float:left;margin-top:.3rem}
    .ydxs4>div:nth-child(4){float:left;width:calc(50% - .15rem);height:3rem;margin-top:.3rem;margin-left:.3rem}
    
    .ydxs5>div:first-child{width:calc(50% - .15rem);height:4.15rem;float:left}
    .ydxs5>div:nth-child(2){float:left;width:calc(50% - .15rem);height:2rem;margin-top:0;margin-left:.15rem}
    .ydxs5>div:nth-child(3){float:left;width:calc(50% - .15rem);height:2rem;margin-top:.15rem;margin-left:.15rem}
    .ydxs5>div:nth-child(4){width:calc(50% - .15rem);height:2rem;float:left;margin-top:.15rem}
    .ydxs5>div:nth-child(5){float:left;width:calc(50% - .15rem);height:2rem;margin-top:.15rem;margin-left:.15rem}*/
    
    .mod-lv {border-radius: .2rem;margin: 0 .15rem;padding: .05rem .25rem;line-height: .8rem;font-size: .5rem;}
    
    .chip-row{display:none;}.tl {display: none;}
    
</style>


<div class="mod-post-list-item<!--{if $v[wancheng]}--> op6<!--{/if}-->" id="li_$v[id]" style="<!--{if $v[hb_num]}-->background:rgb(254 145 122 / 0.3);<!--{/if}--><!--{if $v[dig_on]}-->background:rgb(253 207 113 / 0.3);<!--{/if}--><!--{if $v[hb_num] && $v[dig_on]}-->background:rgb(103 180 252 / 0.3);<!--{/if}--><!--{if IS_ADMINID}--><!--{else}--><!--{if ($_G[uid] == $v[uid]||IS_ADMINID)}-->background:rgb(255 255 0);<!--{/if}--><!--{/if}-->margin:1.2rem.3rem;padding: .45rem .8rem;border-radius:.2rem;box-shadow: 0 0 3px 0 rgb(189 189 189);">
    
    <section style="text-align: left;margin-bottom: -20px;margin-top: -20px;">
        <section style="display: inline-block;vertical-align: top;border-bottom: .55rem solid #accaf200;border-left: .15rem solid transparent !important;width: 0px;height: 0;"></section>
        <section style="display: inline-block;padding-left: 3px;margin-left: -5px;background-color: #67B4FC;/*border-radius: 0 8px 0 8px;*/">
            <div class="mod-lv is-star" style="background: #67B4FC;color: #ffffff;"><a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id=$v[catid]">$cats[$v[catid]][name]</a></div>
        </section>
    <!--{if $v[dig_on]}-->
        <section style="display: inline-block;vertical-align: top;border-bottom: .55rem solid #accaf2;border-left: .15rem solid transparent !important;width: 0px;height: 0;"></section>
        <section style="display: inline-block;padding-left: 3px;margin-left: -5px;background-color: #FDCF71;/*border-radius: 0 8px 0 8px;*/">
            <div class="mod-lv is-star" style="background: #FDCF71;color: #ff0000;">{lang xigua_hb:zhiding}</div>
        </section>
    <!--{/if}-->
    <!--{if $v[hb_num]}-->
        <section style="display: inline-block;vertical-align: top;border-bottom: .55rem solid #accaf2;border-left: .15rem solid transparent !important;width: 0px;height: 0;"></section>
        <section style="display: inline-block;padding-left: 3px;margin-left: -5px;background-color: #FE917A;/*border-radius: 0 8px 0 8px;*/">
            <div class="mod-lv is-hot" style="background: #FE917A;color: #ffffff;">{lang xigua_hb:hb}</div>
        </section>
    <!--{/if}-->
    <!--{if ($_G[uid] == $v[uid]||IS_ADMINID) /*&& $_GET['is_my']*/ }-->
        <section style="display: inline-block;vertical-align: top;border-bottom: .55rem solid #accaf2;border-left: .15rem solid transparent !important;width: 0px;height: 0;"></section>
        <section style="display: inline-block;padding-left: 3px;margin-left: -5px;background-color: #F00;/*border-radius: 0 8px 0 8px;*/">
            <span class="mod-lv is-hot" style="float:right;font-size: .6rem;background-color: #F00;color: #fff;">&nbsp;&nbsp;{lang xigua_hb:xinxi}ID:$v[id]</span>
        </section>
    <!--{/if}-->      
    </section>
    
    
    
    
        <div class="mod-feed-header" style="display:none">
        <!--<div class="mod-avatar mod-usrface">
            <div class="G-img-wrap" style="height: 1rem;line-height: 1rem;">
                <img src="{avatar($v[uid], 'middle', true)}" class="usr-face" style="top: 0.2rem;">
            </div>
        </div>-->
        </div>
    
    <div class="mod-feed-content"style="margin-top: 25px;">
        <!--{if $v['video'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
        <div class="video_set"><video poster="{$v['video_cover']}" src="{$v['video']}" controls="controls"  <!--{if !IN_PROG}-->x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<!--{/if}-->></video></div>
        <!--{/if}-->
        
        <!--{eval
        $msg = (str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v[description]))));
        $price1 = array_slice($v[vars], 0, 1);
        $price1 = $price1[0][html]?$price1[0][html]:$price1[0][value];
        $v[vars] = array_slice($v[vars], 1);
        $line1 = array();
        foreach($v[vars] as $__k=> $__v):
            if($__v[type]=='pics' || $__v[type]=='linkurl'):
                unset($v[vars][$__k]);
                continue;
            endif;
            if(count($line1)<3):
                $line_text = $__v[html] ?$__v[html] :$__v[value];
                if($line_text):
                    unset($v[vars][$__k]);
                    $line1[] = $line_text;
                endif;
            endif;
        endforeach;
        $line1 = implode('<em>/</em>', $line1);
        $showideo = $v['video_cover'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php');
        $v[vars] = array_values($v[vars]);
        }-->
        
<div class="jzp" style="margin: 0rem;">
    <div class="item-shenqing-style item-shenqing view_jump" data-id="$v[id]" data-stid="$v[stid]">
        <div class="shenqing-btn" style="<!--{if $tag>=0}-->top: 0.5rem;<!--{/if}-->top: 1.75rem;">
            <!--{if ($_G[uid] == $v[uid]||IS_ADMINID) /*&& $_GET['is_my']*/ }-->
        <a href="javascript:;" data-id="$v[id]" data-uid="$v[uid]" data-wc="{$v[wancheng]}" <!--{if $v[display]}-->data-canzd="1"<!--{/if}--> <!--{if (!$v[hb_num]||$v[hb_num]==$v[hb_sendnum])&&$v[display]}-->data-canhb="1"<!--{/if}--> <!--{if !$v[pay_status]}-->data-catid="$v[catid]"<!--{/if}--> onclick="return showansi(this);">{lang xigua_hb:guanli}</a>
        <!--{else}-->
        <span><a href="$SCRITPTNAME?id=xigua_hb&ac=view&pubid=$v[id]">{lang xigua_hb:note}</a></span>
        <!--{/if}-->  </div>
    </div>
   
    <div class="item-content" style="<!--{if $v[img_count]>0}-->border-radius: .35rem;box-shadow: inset 0px 0px 1px 0 rgb(189 189 189);<!--{else}-->box-shadow: 0 0 0 0 rgb(189 189 189);<!--{/if}-->">
        <dl class="item-content-up view_jump" data-id="$v[id]" data-stid="$v[stid]">
            <dt class="item-title" style="<!--{if $tag>=0}-->padding-right: 2.5rem;<!--{/if}-->padding-right: 0rem;">
               
                <strong>{eval echo $titlel ? $titlel : $msg}</strong></dt>
            <dd class="item-desc">
                <!--{if $pricel}-->
                <span class="item-salary">{$pricel}</span>
                <!--{/if}-->
                <!--{if $firstl}-->
                <span class="item-cate tagic">$firstl</span>
                <!--{/if}-->
            </dd>
            <dd class="cl mt8 item_tags">
                <!--{if array_filter($v[tags])}-->
                <!--{loop $v[tags] $___k $tag}-->
                <!--{if $tag}--><span class="mod-feed-tag b-color13">$tag</span><!--{/if}-->
                <!--{/loop}-->
                <!--{/if}-->
                <!--{loop $v[vars] $___k $___tag}-->
                <!--{if $___tag['html']}--><span class="mod-feed-tag b-color13">$___tag['html']</span><!--{/if}-->
                <!--{/loop}-->
            </dd>
        </dl>

    </div>
</div>

        <!--{if $v[img_count]>0}-->
        <div class="mod-photos is-three feed-preview-pic <!--{if $v[img_count]>=3&&$v[img_count]<4}-->ydxs3<!--{elseif $v[img_count]>=2&&$v[img_count]<3}-->ydxs2<!--{elseif $v[img_count]>=4&&$v[img_count]<5}-->ydxs3<!--{elseif $v[img_count]>=1&&$v[img_count]<2}-->ydxs1<!--{else}-->ydxs3<!--{/if}-->" style="/*box-shadow: 1px 1px 5px 1px rgb(189 189 189);*/background-color: transparent;");>
            <!--{eval
             $v[imglist] = array_values($v[imglist]);$img_preview_cnt = count($v[img_preview])-1;
             if($v[img_count]>=3&&$v[img_count]<4):
                $max = 3;
             endif;
             if($v[img_count]>=2&&$v[img_count]<3):
                $max = 2;
             endif;
             /*if($v[img_count]>=4&&$v[img_count]<5):
                $max = 4;
             endif;*/
             if($v[img_count]>=1&&$v[img_count]<2):
                $max = 1;
             endif;
             if($v[img_count]>3):
                $max = 3;
             endif;
            }-->
            <!--{loop $v[imglist] $k $img}-->
            <!--{if $k>=$max}-->
            <!--{eval break;}-->
            <!--{/if}-->
            <div <!--{if $config[picin]}--> class="imgloading view_jump" data-id="$v[id]"<!--{else}-->class="imgloading"<!--{/if}-->>
            <img src="$img" style="border-radius: .25rem;">
            <!--{if /*$k==$img_preview_cnt &&*/ $v[img_count]>0}--><span class="num">{lang xigua_hb:gong} $v[img_count] {lang xigua_hb:zhang}</span><!--{/if}-->
            </div>
            <!--{/loop}-->
        </div>
        <!--{/if}-->

        <!--{if array_filter($v[tags])}-->
        <div class="cl mt8 item_tags view_jump" data-id="$v[id]">
            <!--{loop $v[tags] $k $tag}-->
            <!--{if $tag}--><span class="mod-feed-tag b-color{$k}">$tag</span><!--{/if}-->
            <!--{/loop}-->
        </div>
        <!--{/if}-->
</div>

<div class="mod-feed-footer before_none" style="margin-top:0;padding-top:0">
    <div class="footer-text"><a href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]">
        <span><img src="{avatar($v[uid], 'middle', true)}" class="usr-face" style="height:1rem;float:left;margin-right:-.3rem;border-radius:.5rem"></span>
        <!--{if $veris1[$v[uid]]}--><!--{if $_G[cache][plugin][xigua_hr][grtb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][grtb]" /> <!--{else}--><i class="iconfont icon-erified color-forest vm"></i><!--{/if}--><!--{/if}-->
            <!--{if $veris2[$v[uid]]}--><!--{if $_G[cache][plugin][xigua_hr][qytb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][qytb]" /> <!--{else}--><i class="iconfont icon-qiyerenzheng color-dropbox vm"></i><!--{/if}--><!--{/if}-->
            <!--{if $bao[$v[uid]]}--><!--{if !$bao[$v[uid]][icon]}--><!--{eval $bao[$v[uid]][icon] = $_G[cache][plugin][xigua_hr][bzjtb];}--><!--{/if}--><!--{if $bao[$v[uid]][icon]}--><img class="rzimg vm" src="{$bao[$v[uid]][icon]}" /> <!--{else}--><i class="iconfont icon-baozhengjinmoshi color-good vm pr_1" style="font-size:19px"></i><!--{/if}--><!--{/if}-->
        <span class="name" style="margin-right:.2rem;font-size: .65rem;color:rgb(96 125 139);"><b>�� </b>$users[$v[uid]][username]</span></a>
        <!--{if ($_G[uid] == $v[uid]||IS_ADMINID) /*&& $_GET['is_my']*/ }-->
            <span style="float:right;font-size: .6rem;color: #f00;">&nbsp;&nbsp;{lang xigua_hb:yh}UID:$v[uid]</span>
        <!--{/if}-->
    </div>
    
    
    <a class="circle-name">
            <span class="mod-cricle-headertypes" style="font-size:.6rem;color:rgb(63 81 181);">&nbsp;&nbsp;&nbsp;&nbsp;{$v[time_u]}{lang xigua_hb:fabu0}&nbsp;&nbsp;&nbsp;&nbsp;</span>
            <span style="float:right;font-size: .6rem;<!--{if $v[views]>5000}-->color:rgb(255 0 0);<!--{/if}-->"><i class="<!--{if $v[views]>5000}-->vm iconfont icon-hot-02 f12<!--{/if}--><!--{if $v[views]<=5000}-->vm iconfont icon-faxian f12<!--{/if}-->"></i>{$v[views]}</span>
    </a>
</div>
<!--{if $v[wancheng]}--><div class="wxexpired"></div><!--{/if}-->
</div>
<!--{/loop}-->