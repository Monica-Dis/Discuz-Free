<?php exit('Author: https://dism.taobao.com/?@xigua DISM �ͷ�QQ 467783778'); ?>
<!--{if $_GET['is_my'] || $_GET['is_admin']}-->
<!--{template xigua_hb:mypub_item}-->
<!--{else}-->
<!--{loop $list $k $v}-->
<!--{eval
$msg = (str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v[description]))));
$price1 = array_slice($v[vars], 0, 1);
$price1 = $price1[0][html]?$price1[0][html]:$price1[0][value];
$price2 = array_slice($v[vars], 3, 1);
$price2 = $price2[0][html]?$price2[0][html]:$price2[0][value];
$price3 = array_slice($v[vars], 4, 1);
$price3 = $price3[0][html]?$price3[0][html]:$price3[0][value];
$locr = $subtit = '';
$v[vars] = array_values($v[vars]);
foreach($v[vars] as $__k=> $__v):
    if($__v[type]=='location' || $__v[type]=='area'):
        $locr = str_replace(' ', '', $__v['html']);
        unset($v[vars][$__k]);
    endif;
    if($__v[type]=='pics' || $__v[type]=='linkurl'):
        unset($v[vars][$__k]);
    endif;
    if($__v[autoin]):
        $subtit = $__v[html];
  endif;
endforeach;
$v[vars] = array_values($v[vars]);
if(!$subtit):
    if(strpos($v[vars][0]['html'], '-')===false):
        $titlel = trim($v[vars][0]['html']);
        $pricel = trim($v[vars][1]['html']);
    else:
        $titlel = trim($v[vars][1]['html']);
        $pricel = trim($v[vars][0]['html']);
    endif;
else:
    $titlel = $subtit;
    if(strpos($v[vars][0]['html'], '-')===false):
        $pricel = trim($v[vars][1]['html']);
    else:
        $pricel = trim($v[vars][0]['html']);
    endif;
endif;
$firstl = $v[vars][2]['html'];
unset($v[vars][0]);
unset($v[vars][1]);
unset($v[vars][2]);
if($v[dist1]):
    $locr = $v['dist1']. ($v['dist2']&&$v[dist2]!=$v[dist1] ? '<span class="tagic">'. $v[dist2].'</span>' : '');
endif;
}-->
<div class="jzp">
    <div class="item-shenqing-style item-shenqing view_jump" data-id="$v[id]" data-stid="$v[stid]">
        <div class="shenqing-btn">{lang xigua_hb:ck}</div>
    </div>
    <div class="item-type"><!--{if $locr}-->$locr<!--{else}-->{$cats[$v[catid]][name]}<!--{/if}--></div>
    <div class="item-content">
        <dl class="item-content-up view_jump" data-id="$v[id]" data-stid="$v[stid]">
            <dt class="item-title">
                <!--{if $v[dig_on]}--><div class="mod-lv is-star" style="margin-left:0">{lang xigua_hb:zhiding}</div><!--{/if}-->
                <!--{if $v[hb_num]}--><div class="mod-lv is-hot" style="margin-left:0">{lang xigua_hb:hb}</div><!--{/if}-->
                <i class="ifoset" style="color:#f00;">$price1</i>
                <!--{if $firstl}-->
                <span class="item-cate tagic">$firstl</span>
                <!--{/if}-->
                </dt>
            <dd class="item-desc">
                <!--{if $price3}-->
                <span class="item-salary f12 main_color">{$price3}</span>
                <!--{/if}-->
                <!--{if $price2}-->
                <span class="item-salary f12 main_color">{$price2}</span>
                <!--{/if}-->
            </dd>
            <dd class="cl mt8 item_tags">
                <!--{if array_filter($v[tags])}-->
                <!--{loop $v[tags] $___k $tag}-->
                <!--{if $tag}--><span class="mod-feed-tag b-color13">$tag</span><!--{/if}-->
                <!--{/loop}-->
                <!--{/if}-->
                <!--{loop $v[vars] $___k $___tag}-->
                <!--{if $___tag['html']}--><span class="mod-feed-tag b-color13">$___tag['html']</span><!--{/if}-->
                <!--{/loop}-->
            </dd>
        </dl>
        <div class="item-content-down">
            <div class="item-company content-down" onclick="hb_jump('$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]');"><div class="content-avatr" style="background-image:url({avatar($v[uid], 'middle', true)});"></div> <span>{$users[$v[uid]][username]}</span></div>
            <div class="item-addr content-down">{$v[time_u]}</div>
        </div>
    </div>
</div>
<!--{/loop}-->
<!--{/if}-->