<?php
/**
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2015/6/16
 * Time: 11:42
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_dt/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_dt/upgrade.php');
$finish = TRUE;

if(is_file(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')){

    include_once DISCUZ_ROOT. 'source/plugin/wechat/wechat.lib.class.php';
    $pluginid = 'xigua_dt';

    $Hooks = array(
        'sendreply_extraInfo',
        'newthread_extraInfo',
    );

    $data = array();
    foreach($Hooks as $Hook) {
        $data[] = array(
            $Hook => array(
                'plugin' => $pluginid,
                'include' => 'api.class.php',
                'class' => $pluginid,
                'method' => $Hook,
                'order'  => 0,
            )
        );
    }
    WeChatHook::updateAPIHook($data);
}

