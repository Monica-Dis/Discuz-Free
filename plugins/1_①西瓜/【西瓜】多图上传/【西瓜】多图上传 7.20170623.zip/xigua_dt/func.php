<?php
/**
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Date: 2016/4/11
 * Time: 20:51
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function ysignature($appid,$appsecret, $noncestr, $acurl, $timestamp, $retaccesstoken = 0, $ticket = 0)
{
    $appid = trim($appid);
    $appsecret = trim($appsecret);
    if(empty($appid) || empty($appsecret)){
        return '';
    }

    $access_token = xgetAccessToken($appid, $appsecret,1,0);
    if($retaccesstoken){
        return $access_token;
    }
    
    $TICKET = xgetTicket($access_token, 1);
    $TICKET = $TICKET['ticket'];
    $string1 = "jsapi_ticket=$TICKET&noncestr=$noncestr&timestamp=$timestamp&url=$acurl";
    if($ticket){
        return "jsapi_ticket=$TICKET&noncestr=$noncestr&timestamp=$timestamp";
    }

    $signature = sha1( $string1 );
    return $signature;
}

function xgetTicket($access_token, $dorep = 1){
    $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=$access_token&type=jsapi";

    $ret1 = dfsockopen($url);
    if(!$ret1){
        $ret1 = file_get_contents($url);
    }
    $ret1 = json_decode($ret1, TRUE);
    if(xcheckSuc($ret1)===null&& $dorep){

        global $_G;
        $config = $_G['cache']['plugin']['xigua_dt'];
        $appid = $config['appid'];
        $appsecret = $config['appsecret'];

        $access_token = xgetAccessToken($appid, $appsecret, 1, 1);
        return xgetTicket($access_token, 0);
    }
    return $ret1;
}


function xcheckSuc($res)
{
    $result = true;
    if (is_string($res)) {
        $res = json_decode($res, true);
    }
    if (isset($res['errcode']) && (0 !== (int)$res['errcode'])) {
        $result = false;
        if($res['errcode'] == '40001'){
            $result = null;
        }
    }
    return $result;
}

function xgetAccessToken($appid,$appsecret, $tokenOnly = 1, $nocache = 0)
{
    global $_G;
    $myTokenInfo = null;
    $cachename = 'wechatat_' . $appid;
    loadcache($cachename);

    $myTokenInfo = $_G['cache'][$cachename];

    if (time() >= $myTokenInfo['expiration'] || $nocache) {
        $myTokenInfo = null;
        $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";
        $json = dfsockopen($url);
        if(!$json){
            $json = file_get_contents($url);
        }

        $res = json_decode($json, true);

        if (xcheckSuc($res)) {
            $myTokenInfo = array(
                'token' => $res['access_token'],
                'expiration' => time() + (int)$res['expires_in'] - 1000,
            );
            savecache($cachename, $myTokenInfo);
        }
    }
    return $tokenOnly ? $myTokenInfo['token'] : $myTokenInfo;
}

function ycurrenturl($related = 0) {
    $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
    $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
    $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
    $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.$_SERVER['QUERY_STRING'] : $path_info);
    return $related ? $relate_url : $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
}
