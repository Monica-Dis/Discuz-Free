<?php exit('xxx')?>
{block html}
<script>
    var uploadfield = 'input[name="Filedata"]';
    var uploadctrl =$(uploadfield);
    uploadctrl.unbind();
    uploadctrl.attr({'accept':"image/*","multiple":"multiple",'id':'jsfiledata'});

    uploadctrl.on('change', function() {
        if(this.files.length){
            popup.open('<img src="' + IMGDIR + '/imageloading.gif">');
        }

        uploadsuccess = function(data) {
            if(data == '') {
                popup.open('{lang uploadpicfailed}', 'alert');
            }
            var dataarr = data.split('|');
            if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                popup.close();
                $('#imglist').append('<li><span style="position:absolute;z-index:999" aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a style="position:relative;height:63px;display:block" href="javascript:;" onclick="insertinto('+dataarr[3]+');"><img style="height:54px;width:54px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /><span style="position: absolute;bottom:0;left: 0;width: 100%;height: 20px;background: rgba(0,0,0,.5);color: #fff;line-height: 20px;text-align: center;font-size: 14px;">{lang xigua_dt:insert}</span></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>');
            } else {
                var sizelimit = '';
                if(dataarr[7] == 'ban') {
                    sizelimit = '{lang uploadpicatttypeban}';
                } else if(dataarr[7] == 'perday') {
                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                } else if(dataarr[7] > 0) {
                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                }
                popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
            }
        };
        for (var i = 0; i < this.files.length; i++) {
            var files1 = [];
            files1.push(this.files[i]);
            $.buildfileupload({
                uploadurl: 'misc.php?mod=swfupload&operation=upload&type=image&inajax=yes&infloat=yes&simple=2',
                files: files1,
                uploadformdata: { uid: "$_G[uid]", hash: "$auth" },
                uploadinputname: 'Filedata',
                maxfilesize: "$swfconfig[max]",
                success: uploadsuccess,
                error: function () { popupopen('{lang uploadpicfailed}');popupclose(); }
            });
        }
    });


    function insertinto(aid) {
        var old = $('textarea[name="message"]').val();
        old+="[attachimg]"+aid+"[/attachimg]";
        $('textarea[name="message"]').val(old);
    }
</script>

{/block}
