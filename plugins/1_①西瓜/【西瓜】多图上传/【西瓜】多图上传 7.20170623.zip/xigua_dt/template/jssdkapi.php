<?php

$insertlang = lang('plugin/xigua_dt', 'insert');
$__VERHASH = VERHASH;$html = <<<EOF

<script type="text/javascript" src="//res.wx.qq.com/open/js/jweixin-1.0.0.js?{$__VERHASH}"></script >
<script type="text/javascript" src="{$_G['siteurl']}source/plugin/xigua_dt/static/sha1.js?{$__VERHASH}"></script >
<script type="text/javascript">
    function chooseimg() {
        var signature = hex_sha1('{$ticket}&url='+window.location.href);
        var images={};
        wx.config({
    //    debug:true,
            appId: '{$appid}',
            timestamp: '{$timestamp}',
            nonceStr: '{$noncestr}',
            signature: signature,
            jsApiList: ['checkJsApi','chooseImage','previewImage','uploadImage','downloadImage']
        });
    
        wx.chooseImage({
            success: function (res) {
                images.localId = res.localIds;
                if (images.localId.length> 0) {
                    var i = 0, length = images.localId.length;
                    images.serverId = "";
                    function upload() {
                        wx.uploadImage({
                            localId: images.localId[i],
                            success: function (res) {
                                i++;
                                images.serverId+= ("&serverId[]="+res.serverId);
                                if (i < length) {
                                    upload();
                                }else{
                                    $.ajax({
                                        type: "POST",
                                        url: "{$_G['siteurl']}plugin.php?id=xigua_dt:download&fid={$_G['fid']}",
                                        data: images.serverId,
                                        dataType: "json",
                                        success: function(data){
                                            if(!data || data.length <1) {
                                                alert('{$uploadpicfailed}');
                                            }
                                            for(var i=0; i<data.length; i++){
                                                var dataarr = data[i].split('|');
                                                if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                                                    if($('#replyForm').length>0){
                                                        $('#replyForm').append('<input type="hidden" name="attachnew['+dataarr[3]+'][description]" />');
                                                    }
                                                    var id = Date.now() + i;
                                                    var html = '<li id="li' + id + '"><input type="hidden" name="attachnew['+dataarr[3]+'][description]" />' +
                                                        '<div class="photoCut" data-id="'+dataarr[3]+'"><img src="{$_G['setting']['attachurl']}forum/'+dataarr[5]+'" class="attchImg" alt="photo"><span style="position: absolute;bottom:0;left: 0;width: 100%;height: 20px;background: rgba(0,0,0,.5);color: #fff;line-height: 20px;text-align: center;font-size: 14px;z-index:999">$insertlang</span></div>' +
                                                    '<div class="maskLay"></div>' +
                                                    '<a href="javascript:;" class="cBtn cBtnOn pa db" title="" _id="' + id + '"> X </a></li>';
                                                    jq('#addPicApi').before(html);
                                                } else {
                                                    var sizelimit = '';
                                                    if(dataarr[7] == 'ban') {
                                                        sizelimit = '{$uploadpicatttypeban}';
                                                    } else if(dataarr[7] == 'perday') {
                                                        sizelimit = '{$donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                                                    } else if(dataarr[7] > 0) {
                                                        sizelimit = '{$donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                                                    }
                                                    alert(STATUSMSG[dataarr[2]] + sizelimit);
                                                }
                                            }
                                        }
                                    });
                                }
                            },
                            fail: function (res) {
                                alert(JSON.stringify(res));
                            }
                        });
                    }
                    upload();
                }
            }
        });
    }
if(isWeiXin()){
    $('#uploadFile').attr("id", "uploadFileApi");
    $('#addPic').attr("id", "addPicApi");

    $('#addPicApi').on("click", function () {
        chooseimg();
        return false;
    });
}
function isWeiXin(){
    var ua = window.navigator.userAgent.toLowerCase();
    if(ua.match(/MicroMessenger/i) == 'micromessenger'){
        return true;
    }else{
        return false;
    }
}

$(document).off("click", '.photoCut');    
$(document).on('click', '.photoCut', function(){
    var aid = $(this).attr('data-id');
    old = $('textarea[name="message"]').val();
    old+="[attachimg]"+aid+"[/attachimg]";
    $('textarea[name="message"]').val(old);
});
</script >

EOF;
?>