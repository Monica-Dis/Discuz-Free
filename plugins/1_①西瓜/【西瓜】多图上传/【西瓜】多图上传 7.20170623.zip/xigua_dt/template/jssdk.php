<?php exit('111')?>
{block html}
<script type="text/javascript" src="//res.wx.qq.com/open/js/jweixin-1.0.0.js?{VERHASH}"></script>
<script type="text/javascript">
function chooseimg() {
    var images={};
    wx.config({
//        debug:true,
        appId: '{$appid}',
        timestamp: '{$timestamp}',
        nonceStr: '{$noncestr}',
        signature: '{$signature}',
        jsApiList: ['checkJsApi','chooseImage','previewImage','uploadImage','downloadImage']
    });
    wx.chooseImage({
        success: function (res) {
            images.localId = res.localIds;
            if (images.localId.length> 0) {
                var i = 0, length = images.localId.length;
                images.serverId = "";
                function upload() {
                    wx.uploadImage({
                        localId: images.localId[i],
                        success: function (res) {
                            i++;
                            images.serverId+= ("&serverId[]="+res.serverId);
                            if (i < length) {
                                upload();
                            }else{
                                $.ajax({
                                    type: "POST",
                                    url: "{$_G[siteurl]}plugin.php?id=xigua_dt:download&fid={$_G[fid]}",
                                    data: images.serverId,
                                    dataType: "json",
                                    success: function(data){
                                        if(!data || data.length <1) {
                                            popup.open('{lang uploadpicfailed}', 'alert');
                                            return;
                                        }
                                        var imglist = '';
                                        for(var i=0; i<data.length; i++){
                                            var dataarr = data[i].split('|');
                                            if(dataarr[0] == 'DISCUZUPLOAD' && dataarr[2] == 0) {
                                                popup.close();
                                                imglist += '<li><span style="position:absolute;z-index:999" aid="'+dataarr[3]+'" class="del"><a href="javascript:;"><img src="{STATICURL}image/mobile/images/icon_del.png"></a></span><span class="p_img"><a style="position:relative;height:63px;display:block" href="javascript:;" onclick="insertinto('+dataarr[3]+');"><img style="height:54px;width:54px;" id="aimg_'+dataarr[3]+'" title="'+dataarr[6]+'" src="{$_G[setting][attachurl]}forum/'+dataarr[5]+'" /><span style="position: absolute;bottom:0;left: 0;width: 100%;height: 20px;background: rgba(0,0,0,.5);color: #fff;line-height: 20px;text-align: center;font-size: 14px;">{lang xigua_dt:insert}</span></a></span><input type="hidden" name="attachnew['+dataarr[3]+'][description]" /></li>';
                                            } else {
                                                var sizelimit = '';
                                                if(dataarr[7] == 'ban') {
                                                    sizelimit = '{lang uploadpicatttypeban}';
                                                } else if(dataarr[7] == 'perday') {
                                                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[8]/1024)+'K)';
                                                } else if(dataarr[7] > 0) {
                                                    sizelimit = '{lang donotcross}'+Math.ceil(dataarr[7]/1024)+'K)';
                                                }
                                                popup.open(STATUSMSG[dataarr[2]] + sizelimit, 'alert');
                                            }
                                        }
                                        if(imglist){
                                            $('#imglist').append(imglist).show();
                                        }
                                    }
                                });
                            }
                        },
                        fail: function (res) {
                            alert(JSON.stringify(res));
                        }
                    });
                }
                upload();
            }
        }
    });
}

setTimeout(function () {
    wx.config({
        appId: '{$appid}',
        timestamp: '{$timestamp}',
        nonceStr: '{$noncestr}',
        signature: '{$signature}',
        jsApiList: ['checkJsApi','chooseImage','previewImage','uploadImage','downloadImage']
    });
}, 500);

$('input[name="Filedata"]').attr('readonly', 1).on("click", function () {
    chooseimg();
    return false;
});
function insertinto(aid) {
    var old = $('textarea[name="message"]').val();
    old+="[attachimg]"+aid+"[/attachimg]";
    $('textarea[name="message"]').val(old);
}
</script>
{/block}
