<?php
/**
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$pluginid = 'xigua_dt';

if(is_file(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')){
    include_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    WeChatHook::delAPIHook($pluginid);
}


$finish = TRUE;

function xigua_dtdelete_all($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xigua_dtdelete_all($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}

xigua_dtdelete_all(DISCUZ_ROOT.'./source/plugin/xigua_dt', true);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dt/discuz_plugin_xigua_dt_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_dt/uninstall.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_dt/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_dt/upgrade.php');
