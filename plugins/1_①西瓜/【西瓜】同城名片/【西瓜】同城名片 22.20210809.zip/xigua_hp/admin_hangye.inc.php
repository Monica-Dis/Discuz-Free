<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/4/15
 * Time: 11:15
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/common.php')){
    include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
}else{

    include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
    function lang_hs($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_hs', $lang);
        }else{
            return lang('plugin/xigua_hs', $lang);
        }
    }
}
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$page = max(1, intval(getgpc('page')));
$lpp = 5;
$start_limit = ($page - 1) * $lpp;
$cat__id = intval($_GET['cat__id']);
if($cat__id){
    $cat_indo = C::t('#xigua_hp#xigua_hp_hangye')->fetch_by_catid($cat__id);
}
$GLOBALS['needchild'] = 1;
if(1){
    if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
        $ret = C::t('#xigua_hp#xigua_hp_hangye')->do_delete(intval($_GET['catid']));
        if($ret){
            cpmsg(
                lang_hs('delcat_succeed', 0),
                "action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_hangye&page=$page",
                'succeed'
            );
        }else{
            cpmsg(
                lang_hs('delcat_error', 0),
                "action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_hangye&page=$page",
                'error'
            );
        }
    }
    if(submitcheck('dosubmit')){
        if($new = $_GET['n']){
            $newrow = array();
            foreach ($new['name'] as $k => $v) {
                if(is_array($v)){
                    foreach ($v as $kk => $string) {
                        $newrow[] = array(
                            'pid'  => $k,
                            'name' => $string,
                            'o'    => $new['o'][$k][$kk],
                            'ts'   => TIMESTAMP,
                            'cat_ids'   => trim($new['cat_ids'][$k][$kk]),
                            'price'  => $new['price'][$k][$kk],
                            'telprice'  => $new['telprice'][$k][$kk],
                            'stids'  => $new['stids'][$k][$kk],
                        );
                    }
                } else {
                    $newrow[] = array(
                        'pid' => 0,
                        'name' => $v,
                        'o'  => $new['o'][$k],
                        'ts'   => TIMESTAMP,
                        'cat_ids'   => trim($new['cat_ids'][$k]),
                        'price'  => $new['price'][$k],
                        'telprice'  => $new['telprice'][$k],
                        'stids'  => $new['stids'][$k],
                    );
                }
            }
            foreach ($newrow as $value) {
                C::t('#xigua_hp#xigua_hp_hangye')->insert($value);
            }
        }

        if($_FILES['icon'] || $_FILES['adimage']){
            $icons = hb_uploads($_FILES['icon']);
            $adimage = hb_uploads($_FILES['adimage']);
        }
        if($r = $_GET['r']){
            foreach ($r['name'] as $cid => $name) {
                $data = array();

                $data['name']   = $name;
                $data['o']      = $r['o'][$cid];
                $data['cat_ids']= $r['cat_ids'][$cid];
                $data['adlink'] = $r['adlink'][$cid];
                $data['price']  = $r['price'][$cid];
                $data['telprice']  = $r['telprice'][$cid];
                $data['stids']  = $r['stids'][$cid];
                $data['tag']    = trim($r['tag'][$cid]);
                $data['placehoder']    = trim($r['placehoder'][$cid]);
                if($_FILES['adimage']['error'][$cid] === UPLOAD_ERR_OK){
                    $data['adimage']= ($adimage[$cid]['errno'] == 0 ? $adimage[$cid]['error'] : '');
                }
                if($_FILES['icon']['error'][$cid] === UPLOAD_ERR_OK) {
                    $data['icon'] = ($icons[$cid]['errno'] == 0 ? $icons[$cid]['error'] : '');
                }

                C::t('#xigua_hp#xigua_hp_hangye')->update($cid, $data);
            }
        }
        if($delimg = $_GET['delimg']){
            foreach ($delimg as $catid_ => $fields_) {
                $data_ = array();
                if($fields_['icon'] == 1){
                    $data_['icon'] = '';
                }
                if($fields_['adimage'] == 1){
                    $data_['adimage'] = '';
                }
                if($data_){
                    C::t('#xigua_hp#xigua_hp_hangye')->update(intval($catid_), $data_);
                }
            }
        }
        cpmsg(
            lang_hs('succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_hangye&page=$page",
            'succeed'
        );
    }

    $listinfo = C::t('#xigua_hp#xigua_hp_hangye')->fetch_all_by_page($start_limit, $lpp);
    C::t('#xigua_hp#xigua_hp_hangye')->init($listinfo);
    $list = C::t('#xigua_hp#xigua_hp_hangye')->get_tree_array(0);

    $totalcount = C::t('#xigua_hp#xigua_hp_hangye')->count_by_page();
    $multipage = multi(
        $totalcount, $lpp, $page,
        ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_hangye&page=$page"
    );

    echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_hangye&page=$page", 'enctype');
    $alink = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_pub&catadd";

    ?>
    <style>
        .imgi{height:20px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
        .short{width:150px}
        .td23 input{width:120px!important;}
    </style>
    <div style="height:30px;line-height:30px;padding-left:25px">
        <a href="javascript:;" onclick="show_all()"><?php echo cplang('show_all')?></a> | <a href="javascript:;" onclick="hide_all()"><?php echo cplang('hide_all')?></a>
    </div>
    <table class="tb tb2 ">
        <tbody>
        <tr class="header">
            <th>&nbsp;</th>
            <th><?php lang_hs('hangye_id')?></th>
            <th><?php lang_hs('order')?></th>
            <th><?php lang_hs('cat_name')?></th>
            <th><?php lang_hs('caozuo')?></th>
        </tr>
        </tbody>
        <?php foreach ($list as $v) { ?>
            <tbody>
            <tr class="hover">
                <td class="td25" onclick="toggle_group('group_<?php echo $v['id']?>', $('a_group_<?php echo $v['id']?>'))"><a href="javascript:;" id="a_group_<?php echo $v['id']?>">[-]</a></td>
                <td class="td25"><?php echo $v['id']?></td>
                <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $v['id']?>]" value="<?php echo $v['o']?>" /></td>
                <td class="td23">
                    <div class="parentboard"><input type="text" name="r[name][<?php echo $v['id']?>]" value="<?php echo $v['name']?>" class="txt" /></div>
                </td>
                <td>
                    <a href="javascript:;" onclick="return _delid(<?php echo $v['id']?>,'<?php echo str_replace('&#039;', '', $v['name'])?>') "><?php lang_hs('del')?></a>
                </td>
            </tr>
            </tbody>
            <tbody id="group_<?php echo $v['id']?>">
            <?php foreach ($v['child'] as $c) { ?>
                <tr class="hover">
                    <td class="td25"></td>
                    <td class="td25"><?php echo $c['id']?></td>
                    <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $c['id']?>]" value="<?php echo $c['o']?>" /></td>
                    <td class="td23">
                        <div class="board">
                            <input type="text" name="r[name][<?php echo $c['id']?>]" value="<?php echo $c['name']?>" class="txt" />
                        </div>
                    </td>
                    <td>
                        <a href="javascript:;" onclick="return _delid(<?php echo $c['id']?>, '<?php echo str_replace('&#039;', '', $c['name'])?>') "><?php lang_hs('del')?></a>
                    </td>
                </tr>
                <?php
            }
            ?>
            </tbody>


            <tbody>
            <tr>
                <td></td>
                <td colspan="4">
                    <div class="lastboard">
                        <a href="javascript:;" onclick="addrow(this, 1, <?php echo $v['id']?>)" class="addtr"><?php lang_hs('ad_child_cat')?></a>
                    </div></td>
                <td>&nbsp;</td>
            </tr>
            </tbody>
        <?php }?>

        <tbody>
        <tr>
            <td>&nbsp;</td>
            <td colspan="99"><div>
                    <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hs('ad_new_cat')?></a>
                </div></td>
        </tr>
        <?php
        if($multipage){
            showtablerow('', 'colspan="99"', $multipage);
        }
        showsubmit('dosubmit', 'submit', 'td');
        ?>
        </tbody>
    </table>
    </form>
    <script>
        var rowtypedata = [
            [
                [1, ''],
                [1, ''],
                [1,'<input type="text" class="txt" name="n[o][]" value="0" />', 'td25'],
                [5,'<div><input name="n[name][]" value="<?php lang_hs('new_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hs('del')?></a></div>']
            ],
            [
                [1, ''],
                [1, ''],
                [1,'<input type="text" class="txt" name="n[o][{1}][]" value="0" />', 'td25'],
                [5,'<div class="board"><input name="n[name][{1}][]" value="<?php lang_hs('child_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hs('del')?></a></div>']
            ]
        ];
        function _delid(id, name){
            if(confirm('<?php lang_hs('del_confirm')?>' + name + '?')){
                window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_hangye&page=$page&del=1&formhash=".FORMHASH.'&catid='?>"+id;
            }
        }
    </script>
<?php } ?>