<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/11/19
 * Time: 16:38
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/common.php')){
    include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
}else{
    include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';

    function lang_hs($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_hs', $lang);
        }else{
            return lang('plugin/xigua_hs', $lang);
        }
    }
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hp/function.php';

function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}


$page = max(1, intval(getgpc('page')));
$lpp = 50;
$start_limit = ($page - 1) * $lpp;
$statuss = array(
    '1' => lang_hp('status1',0),
    '-1' => lang_hp('status-1',0),
    '-2' => lang_hp('status-2',0)
);

if($secid = intval($_GET['secid'])){

    $res = C::t('#xigua_hp#xigua_hp_user')->fetch($secid);
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $res = array ('uid' => '0', 'order_id' => '', 'crts' => '0', 'upts' => '0', 'payts' => '0', 'status' => '1', 'stid' => '0', 'note' => '', 'name' => '', 'hy' => '', 'hangye_id1' => '', 'hangye_id2' => '', 'addr' => '', 'mobile' => '', 'wx' => '', 'avatar' => '', 'lat' => '', 'lng' => '', 'province' => '', 'city' => '', 'district' => '', 'street' => '', 'street_number' => '', 'zw' => '', 'wfz' => '', 'openmobile' => '1', 'openwx' => '1', 'openaddr' => '1', 'bm' => '', 'company' => '', 'views' => '0', 'zans' => '0', 'shares' => '0', 'follows' => '0', 'shname' => '', 'shid' => '0', 'displayorder' => '0', );
        }
        unset($res['shixian']);

        echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_hp('spgl',0) . ($secid>0?$secid:''). "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user'> ".lang_hp('back',0)."</a>");

        foreach ($res as $index => $re) {
            if(in_array($index, array('hangye_id1','dig_days','hangye_id2','bigweek','payts','bigrate','shname', 'not_start', 'end','srange_ary','xiajia','shen', 'quan', 'yuanprice','mpid','color_title', 'is_end', 'order_id', 'paytype'))){
                continue;
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('endts', 'crts', 'upts', 'usetime', 'startts','dig_startts', 'dig_endts','endts'))){
                $re = $re>($index=='endts'?-1:0) ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('thumb'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('openmobile' ,'openwx','openaddr', 'selfdis', 'orderdis'))){
                $tp = 'radio';
            }elseif(in_array($index, array('srange'))){
                $re = explode("\t", $re);
                $cs = '<select name="editform[srange]" multiple="multiple">';
                foreach ($svicerange as $__v) {
                    $s = '';
                    if(in_array($__v, $re)){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$__v'>$__v</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }

            if (in_array($index, array('avatar'))) {
                $tp = 'filetext';
                showsetting(lang_hp($index, 0), "editform[$index]", $re, $tp);
            }else{
                showsetting(lang_hp($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*dism �� taobao �� com*/
        showformfooter();
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['avatar']){
            $editform['avatar'] = '';
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__v['errno'] == 0) {
                $editform[$__k] = $__v['error'];
            }
        }
        foreach (array('crts', 'upts', 'dig_startts', 'dig_endts', 'endts') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        if($editform['shid']){
            $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($editform['shid']);
        }
        if(!$sh){
//            cpmsg(lang_hp('shnotexists',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&secid=$secid", 'error');
        }
        $editform['shname']     = $sh['name'];
        $editform['shid']       = $sh['shid'];
        if($sh){
            $editform['hangye_id1'] = $sh['hangye_id1'];
            $editform['hangye_id2'] = $sh['hangye_id2'];
        }else{
            if($_G['cache']['plugin']['xigua_hp']['hytype'] == 1){
                $hyobj = C::t('#xigua_hs#xigua_hs_hangye');
            }else{
                $hyobj = C::t('#xigua_hp#xigua_hp_hangye');
            }
            $hy_ret = $hyobj-> fetch_by_name(array_filter(explode(' ', trim($editform['hy']))));
            $hangye_ids = array_keys($hy_ret);
            $editform['hangye_id1'] = $hangye_ids[0];
            $editform['hangye_id2'] = $hangye_ids[1];
        }

        if($secid>0){
            $rs = C::t('#xigua_hp#xigua_hp_user')->update($secid, $editform);
        }else{
            $rs = C::t('#xigua_hp#xigua_hp_user')->insert($editform);
        }
        cpmsg(lang_hp('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&secid=$secid", 'succeed');
    }
}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_hp#xigua_hp_user')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_hp#xigua_hp_user')->update($id, array(
                'displayorder' => $item['displayorder'],
                'status' => $item['status'],
                'views' => $item['views'],
                'zans' => $item['zans'],
                'follows' => $item['follows'],
                'shares' => $item['shares'],
            ));
        }

        cpmsg(lang_hp('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey($keyword)) {
        $wherearr[] = " (name LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR company LIKE '%$keyword%' OR wx LIKE '%$keyword%' OR mobile LIKE '%$keyword%' OR wfz LIKE '%$keyword%' OR addr LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }

    $ob = ' displayorder DESC, mpid DESC';

    echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_hp('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($statuss as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user".' class="btn" >'.cplang('reset').'</a> ';
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&secid=-1\" class=\"btn\">".lang_hp('tjsp',0)."</a>";
    echo ' <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&".http_build_query($_GET).'&doexport=1" class="btn" >'.lang('admincp', 'export').'</a> ';
    echo "</div>";

    showtableheader(lang_hp('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_hp('del', 0),
        lang_hp('displayorder', 0),
        lang_hp('avatar', 0),
        lang_hp('ziliao', 0),
        lang_hp('spzt', 0),
        lang_hp('digendts', 0),
        lang_hp('viewzans', 0),
        lang_hp('shname', 0),
        lang_hp('caozuo', 0),
        lang_hp('crendts', 0).'<br>'. lang_hp('endts', 0),
    ));


    $res = C::t('#xigua_hp#xigua_hp_user')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = C::t('#xigua_hp#xigua_hp_user')->fetch_count_by_page($wherearr);

    $shids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $shids[$v['shid']] = $v['shid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($shids && is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/common.php')){
        $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }
    $resk = array();

    foreach ($res as $kk=> $v) {
        $id = $v['mpid'];
        $shid = $v['shid'];
        $thumb = $v['avatar'];


        $checked = $v['display'] ? 'checked' : '';

        $statusfonr= '';
        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($statuss as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
                $statusfonr = $vv;
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input type='text' name='row[$id][displayorder]' value='{$v['displayorder']}' class='smtxt' />",
            "<img src='$thumb' style='width:40px;height:40px' />",

            lang_hp('name',0).' : '.$v['name'] ."<br>".
            lang_hp('hy',0).' : '.$v['hy'] ."<br>".
            lang_hp('addr',0).' : '.$v['province'].$v['city'].$v['addr'] ."<br>".
            lang_hp('mobile',0).' : '.$v['mobile'] ."<br>".
            lang_hp('wx',0).' : '.$v['wx'] ."<br>".
            lang_hp('latlng',0).' : '.$v['lat'].' '.$v['lng'] ."<br>".
            lang_hp('company',0).' : '.$v['company']."<br>".
            lang_hp('zw',0).' : '.$v['zw']."<br>".
            lang_hp('bm',0).' : '.$v['bm']."<br>".
        '',
            $status_u,
            $v['dig_startts'] ? (lang_hp('dig_startts',0).' '.date('Y-m-d H:i:s', $v['dig_startts']).'<br>'.
                lang_hp('dig_endts',0).' '. date('Y-m-d H:i:s', $v['dig_endts']).
                '') : '',
            "<input name='row[$id][views]' value='{$v['views']}' class='smtxt' />&nbsp;".
            "<input name='row[$id][shares]' value='{$v['shares']}' class='smtxt' />&nbsp;".
            "<input name='row[$id][follows]' value='{$v['follows']}' class='smtxt' />&nbsp;".
            "<input name='row[$id][zans]' value='{$v['zans']}' class='smtxt' />"  ,
            "<a target='_blank' href='".ADMINSCRIPT."?action=plugins&operation=config&do=&identifier=xigua_hs&pmod=admin_shanghu&shid=".$v['shid']."'>".$shinfos[$v['shid']]['name'].'</a><br>'.
            ($v['order_id'] ? lang_hp('order_id',0). ' ' . $v['order_id'] .'<br>': '').
            ($v['payts_u'] ? lang_hp('payts',0). ' ' . $v['payts_u'] : '').
            '',
            '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&secid=$id" . '">' . lang_hp('edit', 0) . '</a> ',
            $v['crts_u'].'<br>'.$v['upts_u'].'<br>'.
            $v['endts_u'],
        ));


        $resk[$kk][] = $v['uid'];
        $resk[$kk][] = $users[$v['uid']]['username'];
        $resk[$kk][] = $v['name'];
        $resk[$kk][] = $v['hy'] ;
        $resk[$kk][] = $v['province'].$v['city'].$v['addr'];
        $resk[$kk][] = $v['mobile'] ;
        $resk[$kk][] = $v['wx'] ;
        $resk[$kk][] = $v['lat'].' '.$v['lng'] ;
        $resk[$kk][] = $v['company'];
        $resk[$kk][] = $v['zw'];
        $resk[$kk][] = $v['bm'];
        $resk[$kk][] = $v['crts_u'];
        $resk[$kk][] = $v['upts_u'];
        $resk[$kk][] = $v['endts_u'];
        $resk[$kk][] = date('Y-m-d H:i:s', $v['dig_startts']);
        $resk[$kk][] = date('Y-m-d H:i:s', $v['dig_endts']);

        $resk[$kk][] = $statusfonr;

        $resk[$kk][] = $v['views'];
        $resk[$kk][] = $v['shares'];
        $resk[$kk][] = $v['follows'];
        $resk[$kk][] = $v['zans'];
        $resk[$kk][] = $shinfos[$v['shid']]['name'];

        $resk[$kk][] = ' ';

    }



    if($_GET['doexport']==1){
        $title_arr= array(
            'UID',
            lang_hb('user',0),

            lang_hp('name',0),
            lang_hp('hy',0),
            lang_hp('addr',0),
            lang_hp('mobile',0),
            lang_hp('wx',0),
            lang_hp('latlng',0),
            lang_hp('company',0),
            lang_hp('zw',0),
            lang_hp('bm',0),
            lang_hp('crendts', 0),
            lang_hp('crendts', 0),
            lang_hp('endts', 0),
            lang_hp('dig_startts', 0),
            lang_hp('dig_endts', 0),
            lang_hp('spzt', 0),
            lang_hp('views', 0),
            lang_hb('shares', 0),
            lang_hp('follows', 0),
            lang_hp('dz', 0),
            lang_hp('shname', 0),

            ' ',
        );
        $resk = array_values($resk);

        export_csv($resk, $title_arr);
    }


    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hp&pmod=admin_user&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dism �� taobao �� com*/
    showformfooter();

    /*echo '<pre>';
    print_r($res);
    echo '</pre>';*/
}