<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hp_user extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hp_user';
        $this->_pk = 'mpid';

        parent::__construct(); /*dism��taobao��com*/
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false) {
        global $hp_config;
        if($hp_config['mfshen']){
            $data['status'] = -1;
        }
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'mpid DESC', $fields= '*')
    {
        global $hp_config;
        if($_GET['st']>0 && $hp_config['allowst']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        if($_GET['ac']=='my'||$_GET['ac']=='join' || defined('IN_ADMINCP')) {
        }else{
            $wherearr[] = " ( endts=-1 OR endts>".TIMESTAMP .') ';
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){

            global $hp_config/*, $needrank*/;
            if(!$needrank){
                switch ($hp_config['digorder']){
                    case '3':
                        $orderby = " dig_startts DESC, dig_endts DESC, $orderby";
                        break;
                    case '2':
                        $orderby = " dig_endts DESC, $orderby";
                        break;
                    default:
                        $orderby = " (dig_endts-dig_startts) DESC, $orderby";
                        break;
                }
            }

            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
    public function fetch_count_by_page($wherearr = array())
    {
        global $hp_config;
        if($_GET['st'] && $hp_config['allowst']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }
    public function delete_by_where($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::query('DELETE FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i', $v['upts']) : '';
            $v['payts_u'] = $v['payts'] ? date('Y-m-d H:i', $v['payts']) : '';
            if($v['endts']==0){
                $v['endts_u'] = '';
            }else{
                $v['endts_u'] = $v['endts']>=0 ? date('Y-m-d H:i', $v['endts']) : lang_hp('cqyx',0);
            }
            $v['is_end'] = $v['endts']!=-1 && $v['endts']<=TIMESTAMP;
            if($_GET['ac']=='my' && $v['endts_u']){
                $dq =  $v['endts_u']!=lang_hp('cqyx',0) ? lang_hp('dq',0) : '';
                $v['endts_uu'] = $v['is_end'] ? ($v['endts_u'].' '.lang_hp('ygq',0)) :  ($v['endts_u'].' '.$dq  );
            }

            if($v['status']==1 && $_GET['ac']=='view'){
                C::t('#xigua_hp#xigua_hp_user')->incr($v['mpid'], 'views');
            }
            if($v['dig_endts'] && $v['dig_endts']<TIMESTAMP){
                DB::query("update %t set dig_endts=0,dig_startts=0,dig_days=0 WHERE mpid=%d", array('xigua_hp_user', $v['mpid']));
            }
            global $SCRITPTNAME, $hp_config;

            $kefulink = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=".$v['uid'];
            if ( (IN_MAGAPP||IN_QIANFAN)&&$hp_config['sxlink']){
                $shmember = getuserbyuid($v['uid']);
                $shavat = avatar($v['uid'], 'middle', true);
                $kefulink = str_replace(array('{uid}','{username}','{avatar}'), array($v['uid'], $shmember['username'], $shavat ), $hp_config['sxlink']);
            }
            $v['kefulink'] = $kefulink;
        }
        return $v;
    }

    public function fetch_by_uid($uid)
    {
        global $hp_config;
        if($hp_config['allowst']) {
            $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND stid=%d", array($this->_table, $uid, $_GET['st']));
        }else{
            $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
        }
        $v = self::prepare($v);
        return $v;
    }

    public function update_endts($mpid, $allts, $order_id)
    {
        $payts = TIMESTAMP;
        $old_data = $this->fetch($mpid, TRUE);
        if($old_data['endts']<TIMESTAMP){
            DB::query("update %t set endts=%d WHERE {$this->_pk}=%d", array($this->_table, TIMESTAMP, $mpid));
        }
        return DB::query("update %t set endts=endts+%d,status=1,order_id=%s,payts=%d WHERE {$this->_pk}=%d", array($this->_table, $allts, $order_id, $payts, $mpid));
    }

    public function fetch_online_card($uid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND status=1 AND endts>%s", array($this->_table, $uid, TIMESTAMP));
        $v = self::prepare($v);
        return $v;
    }
    public function fetch_online_card_num()
    {
        $v = DB::result_first("SELECT count(*) FROM %t WHERE status=1 AND endts>%s", array($this->_table, TIMESTAMP));
        return $v;
    }
    public function do_delete($id)
    {
        return $this->delete($id);
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = array();
        $result = DB::fetch_all("SELECT * FROM %t  ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp), array($this->_table));
        if($result){
            foreach ($result as $index => $item) {
                $result[$index] = self::prepare($item);
            }
        }
        return $result;
    }

    public function count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }


    public function incr($gid, $field, $num = 1)
    {
        if(!$field){
            return null;
        }
        global $config;
        if($field == 'views' && $config['cusview']>0 && $config['cusview']<1000){
            $num = $num * mt_rand(1, $config['cusview']);
        }
        if(strpos($gid, ',')!==false){
            $gid = dintval(array_filter(explode(',', $gid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $gid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $gid));
        }
    }

    public function del_by_uid_mpid($mpid)
    {
        global $_G;
        return DB::delete($this->_table, array(
            'mpid' => $mpid,
            'uid' => $_G['uid'],
        ));
    }

    public function total_views()
    {
        global $_G,$config,$dh_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st ) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st ) ";
                }
            }
        }

        $key = 'xigua_hp_total_views'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $dh_config['cusview'] + $return;
    }
    public function total_count()
    {
        global $_G,$config,$dh_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st ) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st ) ";
                }
            }
        }

        $key = 'xigua_hp_total_count'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT count(*) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $dh_config['cusview'] + $return;
    }
    public function total_count_user()
    {
        global $_G,$config,$dh_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st ) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st ) ";
                }
            }
        }

        $key = 'xigua_hpcount_user'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT count(distinct uid) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $dh_config['cusview'] + $return;
    }

    public function fetch_newest_card()
    {
        global $hp_config;
        $wherearr = array();
        if($_GET['st'] && $hp_config['allowst']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        $wherearr[] = " ( endts=-1 OR endts>".TIMESTAMP .') ';
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';

        $orderby = "ORDER BY mpid desc";
        $result = DB::fetch_all("SELECT * FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit(0, 5));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
}