<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hp:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hb/static/js/clipboard.min.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hp/static/js/hp.js?{VERHASH}"></script>
<script>
<!--{if $dig_prices}-->
$(document).on('click','.hpdig', function () {
    var that = $(this);

    $.actions({
        title: '{lang xigua_hb:zhidingkuosan}: '+that.data('name'),
        actions: [
            <!--{loop $dig_prices $item}-->
            {text: "{$item[title]}", onClick: function () {
                    var _axjurl = '$SCRITPTNAME?id=xigua_hp&ac=dodig&digtype={$item[type]}&mpid='+that.data('id');
                    $.showLoading();
                    $.ajax({
                        type: 'post',
                        url: _axjurl,
                        data: {'formhash' :FORMHASH},
                        dataType: 'xml',
                        success: function (data) {
                            $.hideLoading();
                            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                            var s = data.lastChild.firstChild.nodeValue;
                            var msgar = tip_common(s);
                        },
                        error: function () {
                            $.hideLoading();
                        }
                    });
                }},
            <!--{/loop}-->
        ],
        onClose:function () {
            if($('.weui-dialog__btn').length>0){
                $($('.weui-mask')[0]).replaceWith('<div class="weui-mask weui-actions_mask weui-mask--visible"></div>');
            }
        }
    });

});
<!--{/if}-->
</script>