<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}--><link rel="stylesheet" href="source/plugin/xigua_hp/static/css/hp.css?{VERHASH}" />
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked,.float_btn{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}
.light_box a.main_color:after,.index_bd,.tsbtn,.tsbtn_mini{background:$config[maincolor]}.main_border{;border-color:$config[maincolor]!important}
.lq_mine{background:{echo hp_hex2rgb($config[maincolor], .05);};border:1px solid $config[maincolor]}.tiing{background-color:$config[maincolor]}
<!--{if $hp_config[mbg]}-->.mpc_body{background-image: url("$hp_config[mbg]")}<!--{/if}-->
</style>
<script>var HB_INWECHAT = '{HB_INWECHAT}', PLZALLOW = '{lang xigua_hs:plzallow}', gengduodongtai = '{lang xigua_hs:gengduodongtai}', guanzhu_sj = '{lang xigua_hs:guanzhu_sj}', yiguanzhu = '{lang xigua_hs:yiguanzhu}', jiaguanzhu='{lang xigua_hs:jiaguanzhu}', mkey = '$hs_config[mkey]', GOOGLE = '{$hs_config[google]}', HS_MULTIUPLOAD = '{$config[multiupload]}', HP_YZ='{lang xigua_hp:yz}',HP_YSC = '{lang xigua_hp:ysc}', HP_YFZ = '{lang xigua_hp:yfz}', HP_WXH = '{lang xigua_hp:wx}';</script>