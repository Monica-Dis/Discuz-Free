<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval $viewtels=C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], array($_GET[mpid]), 'mpid');
$myused = DB::result_first('SELECT count(*) as allnum FROM %t WHERE uid=%d AND idtype=%s AND (crts BETWEEN %d AND %d)' , array(
    'xigua_hb_viewtel', $_G['uid'], 'mpid',
    strtotime(date('Y-m-d 00:00:00')),
    strtotime(date('Y-m-d 23:59:59')),
));
$ckcs = array();
foreach( explode("\n", $hp_config[ckcs]) as $_k => $_v):
    list($gpid, $gnum) = explode("=", trim($_v));
    $gpid = intval($gpid);
    $ckcs[$gpid] = intval($gnum);
endforeach;
$hasuse = $ckcs[$_G[groupid]] - $myused;
if($hasuse<=0):
   $hasuse = 0;
endif;
$jumcurl = hb_currenturl();
$uuu = 'member.php?mod=logging&action=login&needlogin=1&referer=' . rawurlencode($jumcurl);
}-->
<!--{if !$viewtels}-->
<style>.view_bottom.border_topm,.usebtn{display:none}.mpc_main_list>li:first-child{display:none}.zdlist>div:first-child,.zdlist>div:nth-child(2){display:none}</style>
<div class="view_bottom weui-flex">
    <div class="weui-flex__item view_bottom_y">
    <!--{if !$_G[uid]}-->
        <a href="javascript:;" class="mc_bg" onclick="hb_jump('{$uuu}')" >
            <span class="block f16">�����Ա�����鿴</span>
        </a>
    <!--{elseif !$hasuse}-->
        <a href="javascript:;" class="mc_bg" >
            <span class="block f16">���ղ鿴�������þ�����δ��Ϊ��Ա</span>
        </a>
    <!--{else}-->
        <a href="javascript:;" class="mc_bg usebtn1" data-mpid="$_GET[mpid]" >
            <span class="block f16">�������һ�β鿴����</span>
        </a>
    <!--{/if}-->
    </div>
</div>
<!--{/if}-->
<script>
    $(document).on('click','.usebtn1', function () {
        var that = $(this);
        $.ajax({
            type: 'post',
            url: _APPNAME +'?id=xigua_hp&ac=zan&mmppid='+that.data('mpid'),
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {}
        });
    });
</script>