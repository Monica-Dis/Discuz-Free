<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hp:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd">
    <!--{if stripos($_SERVER['HTTP_USER_AGENT'], 'Android') && HB_INWECHAT}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <form action="$SCRITPTNAME?id=xigua_hp&ac=join&mobile=2{$urlext}" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >
        <input type="hidden" name="mpid" value="{echo $old_data['mpid']?$old_data['mpid']:$_GET['mpid']}">
        <input type="hidden" id="lat" name="form[lat]" value="{$old_data['lat']}">
        <input type="hidden" id="lng" name="form[lng]" value="{$old_data['lng']}">
        <input type="hidden" id="province" name="form[province]" value="{$old_data['province']}">
        <input type="hidden" id="city" name="form[city]" value="{$old_data['city']}">
        <input type="hidden" id="district" name="form[district]" value="{$old_data['district']}">
        <input type="hidden" id="street" name="form[street]" value="{$old_data['street']}">
        <input type="hidden" id="street_number" name="form[street_number]" value="{$old_data['street_number']}">

<div class="bgf cl">
        <div class="main_color top_tip" style="background:{echo hp_hex2rgb($config[maincolor], .05);}">
            {lang xigua_hp:ws}
        </div>

        <div class="change_mpava">
            <div class="change_avatar">
                <div id="box_avatar"><img src="{echo $old_data[avatar] ? $old_data[avatar] : avatar($_G['uid'], 'big', true)}"><input type="hidden" name="form[avatar]" value="$old_data[avatar]"></div>
                <i class="iconfont icon-xiangji"></i>
                <!--{if HB_INWECHAT && $config[multiupload]}-->
                <a class="center_upload__input" data-name="form[avatar]" data-boxer="box_avatar" data-only="1"></a>
                <!--{else}-->
                <input class="center_upload__input" data-name="form[avatar]" data-boxer="box_avatar" data-only="1" type="file">
                <!--{/if}-->
            </div>
        </div>
</div>
<!--{eval $btzd = unserialize($hp_config['btzd']);}-->
        <div class="weui-cells mt0 ">
            <!--{if in_array('name', $mpzd)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hp:name}<!--{if in_array('name', $btzd)}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[name]" placeholder="{lang xigua_hp:qtx}{lang xigua_hp:name}" value="{echo $old_data[name] ? $old_data[name] : $lastrealname}">
                </div>
            </div>
            <!--{/if}-->

            <!--{if in_array('mobile', $mpzd)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hp:mobile}<!--{if in_array('mobile', $btzd)}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="tel" name="form[mobile]" placeholder="{lang xigua_hp:qtx}{lang xigua_hp:mobile}" value="{echo $old_data[mobile] ? $old_data[mobile] : $lastmobile}">
                </div>
            </div>
            <!--{/if}-->
            <!--{if in_array('wx', $mpzd)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hp:wx}<!--{if in_array('wx', $btzd)}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[wx]" placeholder="{lang xigua_hp:qtx}{lang xigua_hp:wx}" value="{$old_data[wx]}">
                </div>
            </div>
            <!--{/if}-->


            <!--{if $sh && $dftshname}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hp:sydp}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input choose_ctrl" name="form[shname]" type="text" data-values="{echo $old_data?$old_data['shid']:0}" value="{echo $old_data?$old_data['shname']:''}" placeholder="{lang xigua_hp:qxzsydp}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->

            <!--{if in_array('company', $mpzd)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hp:company}<!--{if in_array('company', $btzd)}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id="company" name="form[company]" placeholder="{lang xigua_hp:company_tip}" value="{$old_data[company]}">
                </div>
            </div>
            <!--{/if}-->

            <!--{if in_array('bm', $mpzd)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hp:bm}<!--{if in_array('bm', $btzd)}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[bm]" placeholder="{lang xigua_hp:bm_tip}" value="{$old_data[bm]}">
                </div>
            </div>
            <!--{/if}-->

            <!--{if in_array('zw', $mpzd)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hp:zw}<!--{if in_array('zw', $btzd)}--><em class="color-red">*</em><!--{/if}--></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[zw]" placeholder="{lang xigua_hp:zw_tip}" value="{$old_data[zw]}">
                </div>
            </div>
            <!--{/if}-->

            <!--{if in_array('wfz', $mpzd)}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <textarea class="weui-textarea" name="form[wfz]" placeholder="{lang xigua_hp:wfz_tip}" rows="3" value="{$old_data[wfz]}">{$old_data[wfz]}</textarea>
                </div>
            </div>
            <!--{/if}-->

            <!--{if in_array('addr', $mpzd)}-->
            <div class="weui-cell <!--{if $_G['cache']['plugin']['xigua_hs']}-->weui-cell_vcode<!--{/if}-->">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_hp:wz}<!--{if in_array('addr', $btzd)}--><em class="color-red">*</em><!--{/if}--></label>
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" id="location_" name="form[addr]" placeholder="{lang xigua_hp:addr_tip}" type="text" value="{$old_data[addr]}">
                </div>
                <!--{if $_G['cache']['plugin']['xigua_hs']}-->
                <div class="weui-cell__ft">
                    <button class="weui-vcode-btn" id="openlocation" type="button">{lang xigua_hb:dingwei}</button>
                </div>
                <!--{/if}-->
            </div>
            <!--{/if}-->

            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hp:hy}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[hy]" id="hangye" type="text" value="$default_hy" placeholder="">
                </div>
                <div class="weui-cell__ft"></div>
            </div>

        </div>

        <div class="weui-cells__title">{lang xigua_hp:yssz}</div>
        <div class="weui-cells ">
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hp:gksjh}</label></div>
                <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hp:zmpzsj}</span></div>
                <div class="weui-cell__ft">
                    <input class="weui-switch" type="checkbox" <!--{if $old_data['openmobile']||!$old_data}-->checked<!--{/if}--> name="form[openmobile]" value="1">
                </div>
            </div>
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hp:gkwxh}</label></div>
                <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hp:zmpzwx}</span></div>
                <div class="weui-cell__ft">
                    <input class="weui-switch" type="checkbox" <!--{if $old_data['openwx']||!$old_data}-->checked<!--{/if}--> name="form[openwx]" value="1">
                </div>
            </div>
            <div class="weui-cell weui-cell_switch">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hp:gkwz}</label></div>
                <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hp:zmpzgkxs}</span></div>
                <div class="weui-cell__ft">
                    <input class="weui-switch" type="checkbox" <!--{if $old_data['openaddr']||!$old_data}-->checked<!--{/if}--> name="form[openaddr]" value="1">
                </div>
            </div>
        </div>

        <!--{if !$_GET[mpid]}-->
        <div class="weui-cells__title">{lang xigua_hp:qxzjrlx}</div>
        <div class="weui-cells weui-cells_checkbox">
            <!--{loop $mp_price $k $v}-->
            <!--{if $needsafe && $v[price]>0}-->
            <!--{eval $safecnt++; continue;}-->
            <!--{/if}-->
            <label class="weui-cell weui-check__label" for="s{$v[type]}">
                <div class="weui-cell__hd">
                    <input type="radio" class="weui-check" name="form[paytype]" value="{$v[type]}" id="s{$v[type]}" <!--{if $k==0}-->checked="checked"<!--{/if}-->>
                    <i class="weui-icon-checked"></i>
                </div>
                <div class="weui-cell__bd">
                    <p>{$v[title]}</p>
                </div>
            </label>
            <!--{/loop}-->
        </div>
        <!--{/if}-->

        <div class="fix-bottom mt10" style="position:relative">
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hp:bc}">
            <!--{if $old_data}-->
            <a class="weui-btn weui-btn_default dompdel" data-id="{$old_data['mpid']}">{lang xigua_hp:sc}</a>
            <a href="javascript:window.history.go(-1);" class="weui-btn weui-btn_default">{lang xigua_hp:back}</a>
            <!--{/if}-->
        </div>
    </form>
    <div class="footer_fix"></div>
</div>

<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>

<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div class="masker" onclick='$(".choose_ctrl").select("close")'></div>

<script> +function($){  $.rawCitiesData = $cityjson; }($);</script>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$_G['cache']['plugin']['xigua_hs']['mkey']}"></script>
<!--{if $_G['cache']['plugin']['xigua_hs']['baidusdk']}--><script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak={$_G['cache']['plugin']['xigua_hs']['baidusdk']}"></script><!--{/if}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script>
    var itar = [], oldshid=0;
    <!--{loop $sh $_sh}--><!--{if $_sh[name]}-->
    itar.push({title: '{$_sh[name]}', value:'{$_sh[shid]}'});
    <!--{/if}--><!--{/loop}-->
    $(".choose_ctrl").select({
        title: "{lang xigua_hp:qxzsydp}",
        items: itar,
        onOpen: function () {
            $('.masker').fadeIn();
        },
        beforeClose: function () {
            $('.masker').fadeOut(300);
            return true;
        },
        onChange: function(d) {
            if(d.values!=='undefined' && d.values>0){
                if(oldshid===d.values){
                    return false;
                }
                oldshid =d.values;
                $.showLoading();
                $.ajax({
                    type: 'get',
                    url: _APPNAME +'?id=xigua_hp&ac=getshinfo&shid='+d.values+'&inajax=1',
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        var rt = s.split('|')[1];
                        var cmp = rt.split('<<>>');
                        $('#company').val(cmp[1]);
                        $('#hangye').val(cmp[2]);
                        $('#location_').val(cmp[3]);
                        $('#lat').val(cmp[4]);
                        $('#lng').val(cmp[5]);
                        $('#province').val(cmp[6]);
                        $('#city').val(cmp[7]);
                        $('#district').val(cmp[8]);
                        $('#street').val(cmp[9]);
                        $('#street_number').val(cmp[10]);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        }
    });
    $("#hangye").cityPicker({
        title: "{lang xigua_hp:plzhy}",
        showDistrict: false,
        onChange: function (picker, values, displayValues) {
            console.log(values);
        }
    });
    $(document).on('click','.dompdel', function () {
        var that = $(this);
        $.confirm({
            title: '{lang xigua_hp:qr}',
            text: '{lang xigua_hp:qrsc}',
            onOK: function () {$.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME +'?id=xigua_hp&ac=dompdel&mpid='+that.data('id')+'&inajax=1',
                    data:{formhash:FORMHASH},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });

    });
</script>
<!--{eval $tabbar=0;$hp_tabbar=1;}-->
<!--{template xigua_hp:footer}-->
<!--{template xigua_hp:enter_up}-->
<script>
<!--{if !$old_data}-->
if($('#openlocation').length>0){
    setTimeout(function () {
        IGNORETIP = 1;
        hs_getlocation(setPoint);
    }, 800);
}
if(typeof wx!=='undefined'){
    wx.ready(function () {
        if($('#openlocation').length>0){
            hs_getlocation(setPoint);
        }
    });
}
<!--{/if}-->


<!--{if $safecnt==count($mp_price) && $needsafe}-->
$.alert('{lang xigua_hb:chyzbzc}', function() {
    wx.miniProgram.redirectTo({url: '/pages/pub/index'});
    setTimeout(function(){
        window.history.go(-1);
    }, 600);
});
<!--{/if}-->
</script>