<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval $shot_img = $v[avatar];}-->
<!--{eval
$shot_file = 'source/plugin/xigua_hp/cache/2'.md5($shot_img).'.png';
if(strpos($shot_img, $_G[siteurl])===false):
    if(!is_file(DISCUZ_ROOT.$shot_file)):
        file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($shot_img));
    endif;
    $shot_img = $shot_file;
endif;
}-->
<div id="shot" style="position:fixed;bottom:-100000px">
    <div class="shot_in main_bg" style="padding-top:1px;">
        <div class="mpc">
            <div class="mpc_body">
                <div class="mpc_main">
                    <div class="mpc_main_top cl">
                        <h2>{$v[name]}</h2>
                        <p>{$v[bm]} {$v[zw]}</p>
                        <div class="ava">
                            <img src="$shot_img" onerror="this.error=null;this.src='$hp_config[dftavatar]'" />
                        </div>
                    </div>
                    <div class="mpc_main_list cl">
                        <div>{$v[company]} <!--{if $v[shid]}-->
                            <a href="$SCRITPTNAME?id=xigua_hs&ac=view&mobile=2&shid={$v[shid]}&mobile=2{$urlext}" class="main_color">{lang xigua_hp:jd}<i class="iconfont icon-shopfill f14 vm"></i></a>
                            <!--{/if}--></div>
                        <!--{if $v[openaddr]}-->
                        <div>{lang xigua_hp:wz} : $v[addr]</div>
                        <!--{/if}-->
                        <!--{if $v[openmobile]}-->
                        <div>{lang xigua_hp:dh} : <em class="main_color" data-clipboard-text="$v[mobile]">$v[mobile]</em></div>
                        <!--{elseif !$hp_config[yinsi]}-->
                        <div>{lang xigua_hp:dh} : <em class="main_color">{echo substr_replace($v[mobile], '****', 3, 4);}</em></div>
                        <!--{/if}-->
                        <!--{if $v[openwx]}-->
                        <div>{lang xigua_hp:wx_} : <em class="main_color btn" data-clipboard-text="$v[wx]">$v[wx]</em></div>
                        <!--{/if}-->
                    </div>
                    <!--{if $v[wfz]}-->
                    <div class="mpc_main_ft tc">
                        "{$v[wfz]}"
                    </div>
                    <!--{/if}-->
                </div>
            </div>
        </div>
        <div class="weui-flex p15 bgf" style="padding-bottom:0">
            <div class="mr15">
                <!--{eval $hb_currenturl = hb_currenturl();}-->
                <!--{if $hp_config['typewx'] ==2}-->
                <!--{eval $hb_currenturl = str_replace('http://', 'https://', $hb_currenturl);}-->
                <!--{/if}-->
                <img src="{eval echo hp_qrcode_mak($v[mpid], $hb_currenturl.'&z=9', $v[avatar]);}" style="width:90px;height:90px" class="block" />
            </div>
            <div class="weui-flex__item" style="height:90px!important;">
                <p class="f18">$new_navtitle</p>
                <p class="c9 f14 mt8">{lang xigua_hp:casm}</p>
            </div>
        </div>
    </div>
</div>