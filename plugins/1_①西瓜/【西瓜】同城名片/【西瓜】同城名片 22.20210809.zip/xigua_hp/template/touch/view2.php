<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hp:header}-->
<style>.page, body{background:#fff}
.zdlist{padding:.75rem;font-size:.7rem}
.zdlist>div{height:1.5rem;line-height:1.5rem}
.zdtit{width:2.5rem;color:#999}
.zdpro{color:#333;float:left;max-width:70vw}
.f15{font-size:.75rem!important}
.jv_desc>div{color:#333;font-size:.7rem}
.jv_addr,.jv_box,.jv_desc{position:relative;padding:.5rem .75rem}
.jv_top{position:relative;padding:.75rem}
.h2top{font-size:.8rem;color:#333;margin-bottom:.75rem;font-weight:700}
</style>
<!--{if $_G['cache']['plugin']['xigua_hs']}--><link rel="stylesheet" href="source/plugin/xigua_hs/static/hs.css?{VERHASH}" /><!--{/if}-->
<div class="page__bd" style="
    overflow: hidden;
    width: 100%;">
    <!--{if $v[avatar]}--><div style="width:0;height:0;display:none"><img src="$v[avatar]" /> </div><!--{/if}-->
    <!--{if $indeximg}--><div style="width:0;height:0;display:none"><img src="$indeximg" /> </div><!--{/if}-->
    <!--{template xigua_hb:common_nav}-->
    <div style="width:100%;position:relative">
<div class="main_bg" style="overflow: hidden;border-radius: 0 0 25rem 25rem;width: 140vw;margin-left: -20vw;height:6rem;position: absolute;">
    </div>
    </div>
    <div class="mpc">
        <div class="mpc_body">
            <!--{if !$v[mpid]}-->
            <div class="mpc_guide">{$v[tip1]}</div>
            <a class="mpc_link" href="$SCRITPTNAME?id=xigua_hp&ac=join&mobile=2{$urlext}">{$v[tip2]}</a>
            <!--{elseif $v[status]==-1}-->
            <div class="mpc_guide">{lang xigua_hp:mpshz}</div>
            <a class="mpc_link" href="javascript:;">{lang xigua_hp:wfck}</a>
            <!--{elseif $v[status]==-2}-->
            <div class="mpc_guide">{lang xigua_hp:wzf}</div>
            <a class="mpc_link" href="javascript:;">{lang xigua_hp:wfck}</a>
            <!--{else}-->
            <div class="mpc_main">
                <div class="mpc_main_top cl">
                    <h2>{$v[name]}</h2>
                    <p>{$v[bm]} {$v[zw]}</p>
                    <div class="ava">
                        <img src="{$v[avatar]}" onerror="this.error=null;this.src='$hp_config[dftavatar]'" />
                    </div>
                    <div class="f14" style="float:left;width:100%;">{$v[company]} <!--{if $v[shid]}-->
                        <a href="$SCRITPTNAME?id=xigua_hs&ac=view&mobile=2&shid={$v[shid]}&mobile=2{$urlext}" class="main_color">{lang xigua_hp:jd}<i class="iconfont icon-shopfill f14 vm"></i></a>
                        <!--{/if}--></div>
                </div>
                <ul class="mpc_main_list cl" style="margin-top:2rem">
                    <!--{if $v[openmobile]}-->
                    <li><i class="iconfont icon-dianhua1 f14 main_color"></i> <em class="main_color" data-clipboard-text="$v[mobile]">$v[mobile]</em></li>
                    <!--{elseif !$hp_config[yinsi]}-->
                    <li><i class="iconfont icon-dianhua1 f14 main_color"></i> <em class="main_color">{echo substr_replace($v[mobile], '****', 3, 4);}</em></li>
                    <!--{/if}-->
                    <!--{if $v[openaddr]}-->
                    <li class="before_none" style="padding-left:0"><i class="iconfont icon-mudedi f14 main_color"></i> $v[addr]</li>
                    <!--{/if}-->
                </ul>
            </div>
            <!--{/if}-->
        </div>
        </div>
   <div class="cl zdlist">
       <div class="cl" <!--{if !$v[openmobile]&&$hp_config[yinsi]}-->style="display:none"<!--{/if}-->>
           <span class="zdtit z">{lang xigua_hp:dh}</span>
           <span class="zdpro">
            <!--{if $v[openmobile]}--><em class="main_color" data-clipboard-text="$v[mobile]">$v[mobile]</em></li>
               <!--{else}--><em class="main_color">{echo substr_replace($v[mobile], '****', 3, 4);}</em></li>
           <!--{/if}--></span>
           <span class="y"><i class="iconfont icon-dianhua1 f15 c9"></i></span>
       </div>
       <!--{if $v[openwx]}-->
       <div class="cl">
           <span class="zdtit z">{lang xigua_hp:wx_}</span>
           <span class="zdpro">
               <em class="main_color btn" data-clipboard-text="$v[wx]">$v[wx]</em><!--{if $hp_config[showfz]}--><em class="btn ml8" data-clipboard-text="$v[wx]">{lang xigua_hp:yjfz}</em><!--{/if}-->
           </span>
           <span class="y"><i class="iconfont icon-sixin2 f16 c9"></i></span>
       </div>
       <!--{/if}-->
       <!--{if $v[openaddr]}-->
       <div class="cl">
           <span class="zdtit z">{lang xigua_hp:wz}</span>
           <span class="zdpro">$v[addr]
           </span>
       </div>
       <!--{/if}-->
       <div class="cl">
           <span class="zdtit z">{lang xigua_hp:company}</span>
           <span class="zdpro">{$v[company]} <!--{if $v[shid]}-->
                        <a href="$SCRITPTNAME?id=xigua_hs&ac=view&mobile=2&shid={$v[shid]}&mobile=2{$urlext}" class="main_color">{lang xigua_hp:jd}<i class="iconfont icon-shopfill f14 vm"></i></a>
               <!--{/if}-->
           </span>
       </div>
   </div>
</div>

    <div class="mpview_area weui-flex" style="padding:.75rem">
        <div class="weui-flex__item">
            <p>{lang xigua_hp:views} : {echo intval($v[views])}</p>
        </div>
        <div class="weui-flex__item">
            <p>{lang xigua_hp:dz} : <em id="dzan">{echo intval($v[zans])}</em></p>
        </div>
        <div class="weui-flex__item">
            <p>{lang xigua_hp:follows} : <em id="dshoucun">{echo intval($v[follows])}</em></p>
        </div>
        <div class="weui-flex__item">
            <p>{lang xigua_hp:zf} : {echo intval($v[shares])}</p>
        </div>
    </div>
<!--{if $v[status]==1}-->
    <div class="mpview_area weui-flex">
        <div class="weui-flex__item tc">
            <a class="usebtn dozan <!--{if $zans}-->main_color<!--{/if}-->" href="javascript:;" data-id="$v[mpid]" data-target="dzan"><i class="iconfont icon-praise"></i> <em><!--{if $zans}-->{lang xigua_hp:yz}<!--{else}-->{lang xigua_hp:dz}<!--{/if}--></em></a>
        </div>
        <div class="weui-flex__item tc">
            <a class="usebtn shoucun <!--{if $shoucun}-->main_color<!--{/if}-->" href="javascript:;" data-id="$v[mpid]" data-target="dshoucun"><i class="iconfont icon-mingpianjia"></i> <em><!--{if $shoucun}-->{lang xigua_hp:yi}<!--{/if}-->{lang xigua_hp:follows}</em></a>
        </div>
        <div class="weui-flex__item tc">
            <!--{if 0}-->
            <a class="usebtn mag_share" data-id="$v[mpid]"><i class="iconfont icon-fenxiang  "></i> {lang xigua_hp:zf}</a>
            <!--{else}-->
            <!--{if $hp_config[fxtype]==1}-->
            <a class="usebtn hp_share" data-id="$v[mpid]"><i class="iconfont icon-fenxiang  "></i> {lang xigua_hp:zf}</a>
            <!--{else}-->
            <a class="usebtn sec_newewm" data-id="$v[mpid]"><i class="iconfont icon-fenxiang  "></i> {lang xigua_hp:zf}</a>
            <!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
    <!--{if $hp_config[fxtype]==2}-->
        <!--{template xigua_hp:qrcode}-->
    <!--{/if}-->
<!--{/if}-->
<div class="jv_desc weui-cells before_none after_none">
    <h2 class="h2top">{lang xigua_hp:grjj}</h2>
    <div>$v[wfz]</div>
</div>
<div class="weui-cells fixbanner before_none">
    <div class="weui-navbar weui-banner nobg fixbanner_in fixban_in2">
        <a href="javascript:;" class="weui-navbar__item weui_bar__item_on ajaxcat3" data-loadingurl="$SCRITPTNAME?id=xigua_hb&ac=list_item&uid={$v[uid]}&inajax=1&pagesize=10&page=">
            <span>{lang xigua_hp:dt}</span>
        </a>
        <!--{if $_G['cache']['plugin']['xigua_hs']}-->
        <a href="javascript:;" class="weui-navbar__item ajaxcat3" data-loadingurl="$SCRITPTNAME?id=xigua_hs&ac=myshop_li&uid={$v[uid]}&inajax=1&pagesize=10&page=">
            <span>{lang xigua_hp:dp}</span>
        </a>
        <!--{/if}-->
        <!--{if $hp_config[zdylj] && $hp_config[zdyljwz]}-->
        <!--{eval $linik = str_replace('[uid]',$v['uid'],$hp_config['zdylj']);}-->
        <a href="{$linik}" class="weui-navbar__item">
            <span>{$hp_config[zdyljwz]}</span>
        </a>
        <!--{/if}-->
    </div>
</div>
<div id="list" class="mod-post x-postlist p0"></div>
<!--{template xigua_hb:loading}-->

    <div class="view_bottom weui-flex border_top">
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hp&mobile=2{$urlext}" class="weui-tabbar__item weui-bar__item_on">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-mingpianjia weui-tabbar__icon pr-1"></i>
                </span>
                <p class="weui-tabbar__label">{lang xigua_hp:mpb}</p>
            </a>
        </div>
        <div class="view_bottom_z">
            <a href="{$kefulink}" data-uid="$v[uid]" class="weui-tabbar__item">
            <span style="display: inline-block;position: relative;">
                <i class="icon-sixin2 iconfont weui-tabbar__icon f22"></i>
            </span>
                <p class="weui-tabbar__label">{lang xigua_hp:sx}</p>
            </a>
        </div>
        <!--{if $v[openwx]}-->
        <div class="view_bottom_z">
            <a href="javascript:;" class="weui-tabbar__item btn" data-clipboard-text="$v[wx]">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-weixin3 weui-tabbar__icon f22 c8"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_hp:wx_}</p>
            </a>
        </div>
        <!--{/if}-->
        <div class="weui-flex__item view_bottom_y" <!--{if !$v[openmobile]&&$hp_config[yinsi]}-->style="display:none"<!--{/if}-->>
            <a href="tel:$v[mobile]" class="mc_bg" style="line-height:1.25rem">
                <i class="iconfont icon-unie607" style="font-size:1.1rem;vertical-align: middle;line-height:1.75rem;"></i>
                <span class="block f12" style="line-height: 1;position: relative;top:-.5rem;"><!--{if $v[openmobile]}-->$v[mobile]<!--{else}-->{echo substr_replace($v[mobile], '****', 3, 4);}<!--{/if}--></span>
            </a>
        </div>
<!--{if !$v[openmobile]&&$hp_config[yinsi]}--><style>.view_bottom_z{flex:1}</style><!--{/if}-->
    </div>
</div>
<div class="footer_fix"></div>
<!--{if !($config[showguide]||!HB_INWECHAT)}-->
<div id="wechat-mask"><div id="wechat-guider"></div></div>
<!--{/if}-->
<script>
    /*loadingurl="$SCRITPTNAME?id=xigua_hb&ac=list_item&uid={$v[uid]}&inajax=1&pagesize=10&page=";*/
    function shareIncr(){
        $.ajax({type: 'post',url: _APPNAME +'?id=xigua_hp&ac=incr&incr_type=shares&mpid=$v[mpid]&inajax=1',data: {'formhash':FORMHASH},dataType: 'xml'});
    }
<!--{if !$indeximg}-->
var customImg = '{$v[avatar]}';
<!--{/if}-->
</script>
<!--{eval $tabbar=0;$hp_tabbar=0;}-->
<!--{template xigua_hp:footer}-->
<!--{eval $canmask = !getcookie("dishpmask_$v[mpid]");}-->
<!--{if $_GET[d] && $canmask}-->
<script>
    <!--{if $hp_config[fxtype]==2}-->
    setTimeout(function(){
        $('.sec_newewm').trigger('click');
    }, 200);
    <!--{else}-->$('#wechat-mask').show();
    <!--{/if}-->
    hb_setcookie('dishpmask_$v[mpid]', 1, 8640000);</script>
<!--{/if}-->
<!--{if $hp_config[fxtype]==2}-->
<script src="source/plugin/xigua_hp/static/js/html2canvas.min.js?{VERHASH}"></script>
<script>
$(document).on('click','.sec_newewm', function () {
    shareIncr();
    $.showLoading();
    html2canvas(document.querySelector(".shot_in")).then(canvas => {
        var dataURL = canvas.toDataURL();
        COMCLAS = 'shot_outer';
        $.hideLoading();
        $.modal({
            title: "{lang xigua_hp:ca}",
            text: "<img style='display:block' src='"+dataURL+"' />",
            buttons: [{ text: "{lang xigua_hb:close}", onClick: function(){} }]
        });
        $('.weui-dialog__title').css('font-size', '.7rem');
        COMCLAS = '';
    });
    return false;
});
</script>
<!--{/if}-->
<!--{if 0}-->
<script>
    $(document).on('click','.mag_share', function () {
        $.showLoading();
        shareIncr();
        html2canvas(document.querySelector(".shot_in")).then(canvas => {
        var dataURL = canvas.toDataURL();
        COMCLAS = 'shot_outer';
        hpp_doupload(dataURL);
        COMCLAS = '';
    });
        return false;
    });
    function hpp_doupload(cmp_photo){
        var img = cmp_photo.split(',')[1];
        img = window.atob(img);
        var ia = new Uint8Array(img.length);
        for (var i = 0; i < img.length; i++) {
            ia[i] = img.charCodeAt(i);
        }
        var blob = new Blob([ia], {type:"image/jpeg"});
        var formdata=new FormData();
        formdata.append('file',blob);

        $.ajax({
            type: 'post',
            url: _APPNAME+'?id=xigua_hb&ac=uploader&inajax=1&formhash='+FORMHASH,
            data :  formdata,
            processData : false,
            contentType : false,
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    var SHAREIMG = s.split('|')[1];
                    mag.setData({shareData: {
                        type: 1, imageurl:SHAREIMG, picurl:  SHAREIMG
                    }});
                    mag.share('ALL', function(res){},function(){ });
                } else {
                    tip_common(s);
                }
            }
        });
    }
</script>
<!--{/if}-->
<script>
    var locker = 0;
    $(document).on('click', '.ajaxcat3', function () {
        var that = $(this), ld = $("#list");
        if(locker){
            return;
        }
        locker = 1;
        page = 1;
        lm = 0;
        var newloadingurl = window.location.href + (window.location.href.indexOf('?') === -1 ? '?' : '&') + 'ac=list_item&inajax=1&cat_id=' + that.data('id') + '&page=';
        if (that.data('loadingurl')) {
            newloadingurl = that.data('loadingurl');
        }
        that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
        DOAPPEND = 0;
        $.ajax({
            type: 'get', url: newloadingurl + '' + page, dataType: 'xml', success: function (data) {
                locker = 0;
                if (null == data) {
                    tip_common('error|' + ERROR_TIP);
                    return false;
                }
                var s = data.lastChild.firstChild.nodeValue;
                $('#loading-show').addClass('hidden');
                if (that.data('save') == 'nav=dp') {
                    ld.addClass('dp_index');
                } else {
                    ld.removeClass('dp_index');
                }
                if (!s) {
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                    setTimeout(function () {
                        $('#loading-show').addClass('hidden');
                        $('#loading-none').removeClass('hidden');
                    }, 300);
                    ld.html(s);
                    page = -1;
                    return;
                }
                ld.html(s);
                if (typeof loadingCallback !== 'undefined') {
                    loadingCallback();
                }
                page++;
                loadingurl = newloadingurl;
            }, error: function () {
                locker = 0;
            }
        });
        if (that.data('save')) {
            var oldu = window.location.href.replace(/nav\=\w+\&/, '');
            var su = that.data('save');
            history.replaceState(null, '', oldu.replace(su + '&', '').replace('id=xigua', su + '&id=xigua'));
        }
    });
    $('.fixban_in2 a:first-child').trigger('click');
</script>