<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<li class="sub_check border_bfull"><a class="ftb color-red" data-idid="3" data-sort="&city={$_GET[name]}" href="javascript:;" data-orihtml="{$_GET[name]}">{lang xigua_hp:quan}{$_GET[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a></li>
<!--{loop $rlist $v}-->
<li class="sub_check1 border_bfull "><a class="ftb" data-idid="3" data-sort="&city={$v[name]}"  href="javascript:;" >$v[name]</a></li>
<!--{/loop}-->