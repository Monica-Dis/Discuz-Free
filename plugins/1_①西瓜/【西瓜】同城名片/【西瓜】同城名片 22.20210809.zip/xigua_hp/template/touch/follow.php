<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hp:header}--><!--{eval $keyword = $_GET[keyword];}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->

    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">

            <input name="id" value="xigua_hp" type="hidden">
            <input name="ac" value="cat" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <input type="hidden" name="ac" value="follow">

            <div class="weui-search-bar__box" style="padding-left:10px">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{$hp_config[sousuoinput]}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i><span>{$hp_config[sousuoinput]}</span>
            </label>
        </form>
        <a href="javascript:" class="search_bar_btn main_color" style="margin-left:10px" id="dosearch">{lang xigua_hp:search}</a>
        <a href="javascript:" class="weui-search-bar__cancel-btn" style="color:#999!important;" <!--{if $keyword}-->id="searchCancel"<!--{/if}-->>{lang xigua_hp:qx}</a>
    </div>


    <div class="">
        <div id="list" class="mod-post x-postlist p0"></div>
        <!--{template xigua_hb:loading}-->
    </div>
<script>
    var loadingurl = window.location.href+'&ac=good_li&inajax=1&keyword=$keyword&follow=1&page=';
    scrollto = 1;
    var lockIng = 0;
    $(document).on('click','#dosearch', function () {
        if($('#searchInput').val()){
            $('#dosearchform').submit();
        }
    });
</script>
</div>

<!--{eval $hp_tabbar=1;}-->
<!--{template xigua_hp:footer}-->