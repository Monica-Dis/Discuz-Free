<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<!--{eval $pai = $needrank && $_G['uid']==$v[uid]&& $_G['uid']>0;}-->
<div class="lingqu_li weui-cell before_none <!--{if $pai}-->lq_mine<!--{/if}-->" id="lingqu_{$v[mpid]}" >
    <!--{if $_GET['follow']}-->
    <a class="iconfont icon-shanchu delicon c9" data-id="$v[mpid]" data-text="{lang xigua_hp:yc}{$v[name]}" data-title="{lang xigua_hp:qryc}?"></a>
    <!--{/if}-->
    <!--{if $needrank}-->
    <!--{eval $ranker= ++$rankindex;}-->
    <a class="rank rank{$ranker} <!--{if $ranker>=10}-->rankmini<!--{/if}-->">$ranker</a>
    <!--{/if}-->
    <div class="weui-cell__hd hp_glist" data-id="{$v[mpid]}">
        <img src="$v[avatar]" class="block" onerror="this.error=null;this.src='$hp_config[dftavatar]'" />
        <!--{if $_GET['orderby']=='nearby'}-->
        <span class="c9 f12">{$v[distance]}</span>
        <!--{/if}-->
    </div>
    <div class="weui-cell__bd hp_glist" data-id="{$v[mpid]}">
        <h2 class="f16">{$v[name]}<!--{if $v[dig_endts]>=TIMESTAMP}--> <div class="mod-lv is-star">{lang xigua_hb:zhiding}</div><!--{/if}-->
        </h2>
        <!--{if $v[zw]||$v[bm]}-->
        <p class="f14 c9">{$v[bm]} <span class="ml8">{$v[zw]}</span></p>
        <!--{/if}-->
        <p class="f14 c9">{$v[company]}</p>
        <!--{if $hp_config[showwfz] && $v[wfz]}-->
        <p class="f14 swfz" style="<!--{if $hp_config[wfzcolor]}-->color:$hp_config[wfzcolor]<!--{/if}-->">"{$v[wfz]}"</p>
        <!--{/if}-->

        <div class="hb_funshow">
            <p class="f14 c9">
                <span><em class="main_color">{$v[views]}</em>{lang xigua_hp:views}</span>
                <span><em class="main_color">{$v[follows]}</em>{lang xigua_hp:follows}</span>
                <span><em class="main_color">{$v[zans]}</em>{lang xigua_hp:dz}</span>
                <!--{if $v[shid]}-->
                <a href="$SCRITPTNAME?id=xigua_hs&ac=view&mobile=2&shid={$v[shid]}&mobile=2{$urlext}" class="ml8 f12 main_color"> <i class="iconfont icon-shopfill f12 vm"></i>{lang xigua_hp:jd}</a>
                <!--{/if}-->
            </p>
        </div>
    </div>
    <div class="weui-cell__ft">
        <!--{if $pai}-->
        <a class="tsbtn" href="javascript:;" data-id="$v[mpid]" data-name="$v[name]">{lang xigua_hp:tspm}</a>
        <!--{else}-->
        <div class="hp_gmobile">
            <a class="comment_to1" href="{$v[kefulink]}" data-uid="$v[uid]"><i class="icon-sixin2 iconfont main_color f24"></i></a>
            <!--{if $v[openmobile]}--><a href="tel:{$v[mobile]}"><i class="iconfont icon-dianhua1 main_color f22"></i></a><!--{/if}-->
        </div>
        <!--{/if}-->
    </div>
</div>
<!--{/loop}-->