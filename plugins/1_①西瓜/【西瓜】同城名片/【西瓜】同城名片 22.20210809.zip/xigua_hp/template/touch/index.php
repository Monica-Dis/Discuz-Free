<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hp:header}-->
<div class="page__bd"><!--{if $indeximg}--><div style="width:0;height:0;display:none"><img src="$indeximg" /> </div><!--{/if}-->

    <header class="x_header bgcolor_11 cl  weui-flex f15" style="background:transparent!important;position:absolute;top:3px">
        <!--{if $_G['cache']['plugin']['xigua_hp']['showfz'] && $hp_config[allowst]}-->
        <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_hp&mobile=2");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
        <!--{else}-->
        <span class="fzopen">&nbsp;&nbsp;</span>
        <!--{/if}-->
        <form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
            <input type="hidden" name="id" value="xigua_hp">
            <input type="hidden" name="ac" value="index">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <input name="keyword" class="index_input" type="text" value="$_GET[keyword]" placeholder="$hp_config[sousuoinput]" x-webkit-speech="" style="background:rgba(255,255,255,.8);<!--{if $_G['cache']['plugin']['xigua_hp']['showfz']}-->width:90%;min-width:30vw;border:0;height:28px;margin-top:7px;left:0;border-radius:28px;padding-left:12px;line-height:28px;padding-top:1px<!--{/if}-->">
            <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
        </form>
    </header>

    <!--{if $topnavslider}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $topnavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $topnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->
    <div class="cl">
        <!--{template xigua_hp:filter}-->
    </div>
</div>

<div id="tisheng" style="display:none">
    <!--{if $dig_prices}-->
    <div class="weui-cell digindex">
        <div class="weui-flex" style="width:100%">
            <div><i class="iconfont icon-huojian f24 main_color"></i></div>
            <div class="weui-flex__item">
                <p class="c6 f14">{lang xigua_hb:zhidingkuosan}</p>
                <p class="c9 f12">{lang xigua_hp:zddesc}</p>
            </div>
            <div>
                <a class="tsbtn_mini hpdig" dataid0="" dataname0="" href="javascript:;">{lang xigua_hp:zd}</a>
            </div>
        </div>
    </div>
    <!--{/if}-->
    <div class="weui-cell">
        <div class="weui-flex" style="width:100%">
            <div><i class="iconfont icon-fabu main_color f24"></i></div>
            <div class="weui-flex__item">
                <p class="c6 f14">{lang xigua_hp:fbxx}</p>
                <p class="c9 f12">{lang xigua_hp:fbxxdesc}</p>
            </div>
            <div>
                <a class="tsbtn_mini" href="$SCRITPTNAME?id=xigua_hb&ac=pub{$urlext}">{lang xigua_hp:qw}</a>
            </div>
        </div>
    </div>
    <!--{if $_G['cache']['plugin']['xigua_hs']}-->
    <div class="weui-cell">
        <div class="weui-flex" style="width:100%">
            <div><i class="iconfont icon-shopfill main_color f24"></i></div>
            <div class="weui-flex__item">
                <p class="c6 f14">{lang xigua_hp:cjdp}</p>
                <p class="c9 f12">{lang xigua_hp:cjdpdesc}</p>
            </div>
            <div>
                <a class="tsbtn_mini" href="$SCRITPTNAME?id=xigua_hs&ac=enter{$urlext}">{lang xigua_hp:qw}</a>
            </div>
        </div>
    </div>
    <!--{/if}-->
    <div class="weui-cell">
        <div class="weui-flex" style="width:100%">
            <div><i class="iconfont icon-fenxiang main_color f24"></i></div>
            <div class="weui-flex__item">
                <p class="c6 f14">{lang xigua_hp:zfwdmp}</p>
                <p class="c9 f12">{lang xigua_hp:zfwdmpdesc}</p>
            </div>
            <div>
                <a class="tsbtn_mini hp_glist" dataid0="" data-cookie="dishpmask_" href="javascript:;">{lang xigua_hp:zf}</a>
            </div>
        </div>
    </div>
</div>

<!--{eval $hp_tabbar=1;}-->
<!--{template xigua_hp:footer}-->
<script>
$(document).on('click','.tsbtn', function () {
    var that = $(this);
    var htm = $('#tisheng').html() ;
    htm = htm.replace(/dataid0\=\"\"/, 'data-id="'+that.data('id')+'"');
    htm = htm.replace(/dataid0\=\"\"/, 'data-id="'+that.data('id')+'"');
    htm = htm.replace(/dataname0\=\"\"/, 'data-name="'+that.data('name')+'"');
    console.log(htm);
    $.alert(htm, "{lang xigua_hp:qs}", function() {
    });
});
</script>