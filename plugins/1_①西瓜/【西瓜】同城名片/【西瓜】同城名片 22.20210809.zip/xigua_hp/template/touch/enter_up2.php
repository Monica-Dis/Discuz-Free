<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<style>.pub_funcbar2 a:first-child{position:absolute;left:0;right:0;bottom:75px;margin:0 30px}
    .pub_funcbar2 a:last-child{position:absolute;left:0;right:0;bottom:15px;margin:0 30px}
</style>
<div id="popctrl2" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo2"></div>
        <div class="pub_funcbar2 ">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<script src="source/plugin/xigua_hb/static/dist/cropper.min.js?{VERHASH}"></script>
<script>
    var loadingImg2 ='<li id="loadingimg" class="weui-uploader__file weui-uploader__file_status"><div class="weui-uploader__file-content"><img src="source/plugin/xigua_hb/static/img/loading.gif"/></div></li>';
    var photoct2 = $('#photo2');
    var imgpop2 = $('#popctrl2');
    var uploadinput_obj2;
    var uploadinput2 = $('.weui-uploader__input');
    var boxer2 = null, filedname2 = '', ICnt = {echo intval($__k);}, canmulti = 0, max_upload_num = 10, max_upload_maxtip = '';
    $(function () {

        var URL = window.URL || window.webkitURL;
        var blobURL;
        var file;
        <!--{if HB_INWECHAT&&$config[multiupload]}-->
        canmulti = 1;
        uploadinput2.on("touchstart", function () {
            uploadinput_obj2 = $(this);
            boxer2 = $(this).parent().prev();
            max_upload_num = boxer2.data('max');
            max_upload_maxtip = boxer2.data('maxtip');
            if(boxer2.find('li').length>=max_upload_num){
                $.toast(max_upload_maxtip, 'error');
                return false;
            }
            wx_upload2();
            return false;
        });
        <!--{elseif IN_MAGAPP}-->
        uploadinput2.on('touchstart', function(){
            uploadinput_obj2 = $(this);
            boxer2 = $(this).parent().prev();
            max_upload_num = boxer2.data('max');
            max_upload_maxtip = boxer2.data('maxtip');
            if(boxer2.find('li').length>=max_upload_num){
                $.toast(max_upload_maxtip, 'error');
                return false;
            }
            magPicPick2();
            return false;
        });
        <!--{else}-->
        uploadinput2.on("change", function () {
            uploadinput_obj2 = $(this);
            boxer2 = $(this).parent().prev();
            if(boxer2.data('max')){
                if(boxer2.children('li').length>=boxer2.data('max')){
                    $.toast(boxer2.data('maxtip'), 'error');
                    return false;
                }
            }
            filedname2 = $(this).data('name');
            photoct2.cropper('destroy').cropper({
                minContainerHeight: 320,
                autoCropArea:1
            });
            var files = this.files;
            if (!photoct2.data('cropper')) {
                return;
            }
            if (files && files.length) {
                file = files[0];
                if (/^image\/\w+$/.test(file.type)) {
                    blobURL = URL.createObjectURL(file);
                    photoct2.one('built.cropper', function () {
                        URL.revokeObjectURL(blobURL);
                    }).cropper('reset').cropper('replace', blobURL);
                    uploadinput_obj2.val('');
                    imgpop2.popup();
                } else {
                    $.toptip('Please choose an image file.', 'error');
                }
            }
        });
        <!--{/if}-->

        $('.pub_funcbar2 a').each(function () {
            var btn = $(this);
            var mtd = btn.attr('data-method');
            btn.on('click', function () {
                if (mtd == 'destroy') {
                } else if (mtd == 'confirm') {
                    result = photoct2.cropper('getCroppedCanvas');
                    photo2 = result.toDataURL('image/jpeg');
                    var img=photo2.split(',')[1];
                    img=window.atob(img);
                    var ia = new Uint8Array(img.length);
                    for (var i = 0; i < img.length; i++) {
                        ia[i] = img.charCodeAt(i);
                    }
                    var bfile = new Blob([ia], {type:"image/jpeg"});


                    compress2(bfile, function(TMP){
                        hs_doupload2(TMP, typeof cropCallback!=='undefined'?cropCallback:null);
                    });

                    if(boxer2.data('only')){ boxer2.html(loadingImg2); }else{ boxer2.append(loadingImg2); }
                } else {
                    var opt = btn.attr('data-option');
                    photoct2.cropper(mtd, opt);
                }
            });
        });
    });
    function compress2(file, callback){
        var reader = new FileReader();

        reader.onload = function (e) {

            var image = $('<img/>');
            image.on('load', function () {
                var square = 640;
                var canvas = document.createElement('canvas');


                if (this.width > this.height) {
                    canvas.width = Math.round(square * this.width / this.height);
                    canvas.height = square;
                } else {
                    canvas.height = Math.round(square * this.height / this.width);
                    canvas.width = square;
                }

                var context = canvas.getContext('2d');
                context.clearRect(0, 0, square, square);
                var imageWidth = canvas.width;
                var imageHeight = canvas.height;
                var offsetX = 0;
                var offsetY = 0;
                context.drawImage(this, offsetX, offsetY, imageWidth, imageHeight);
                var data = canvas.toDataURL('image/jpeg', 0.8);
                console.log([imageWidth,imageHeight]);
                callback(data);
            });

            image.attr('src', e.target.result);
        };

        reader.readAsDataURL(file);
    }
    <!--{if HB_INWECHAT && $config[multiupload]}-->
    var syncUpload2 = function(localIds){
        var localId = localIds.shift();
        wx.uploadImage({
            localId: localId,
            isShowProgressTips:1,
            success: function (res) {
                var serverId = res.serverId;
                do_download2("&serverId[]="+serverId);
                if(localIds.length > 0){
                    syncUpload2(localIds);
                }
            }
        });
    };
    function do_download2(serverId){
        if(max_upload_num>0 && (boxer2.find('li').length>=max_upload_num) && !boxer2.data('only')){
            $.toptip(max_upload_maxtip, 'warning');
            return false;
        }
        $.showLoading();
        $.ajax({
            type: "POST",
            url: "$SCRITPTNAME?id=xigua_hb&ac=uploader&do=download&inajax=1",
            data: serverId,
            async: false,
            dataType: "xml",
            success: function(data){
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                var sar = s.split('|');
                if(sar[0]=='success'){
                    var imgary = sar[1].split('((()))');
                    if(boxer2.data('only')){
                        var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgary[0] + ')"><input type="hidden" name="'+ uploadinput_obj2.data('name')+'[]" value="' + imgary[0] + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        boxer2.html(html);
                    }else{
                        var html_imga = '';
                        for(var j=0;j<imgary.length; j++){
                            html_imga += '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgary[j] + ')"><input type="hidden" name="form[album][]" value="' + imgary[j] + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        }
                        boxer2.append(html_imga);
                    }
                }else{
                    tip_common(s);
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    }
    function wx_upload2(){
        wx.chooseImage({
            success: function (res) {
                var localIds = res.localIds;
                syncUpload2(localIds);
            },
            fail: function (res) {
                alert(JSON.stringify(res));
            }
        });
    }
    <!--{/if}-->

    function hs_doupload2(cmp_photo, callback){
        var img = cmp_photo.split(',')[1];
        img = window.atob(img);
        var ia = new Uint8Array(img.length);
        for (var i = 0; i < img.length; i++) {
            ia[i] = img.charCodeAt(i);
        }
        var blob = new Blob([ia], {type:"image/jpeg"});
        var formdata=new FormData();
        formdata.append('file',blob);

        $.ajax({
            type: 'post',
            url: _APPNAME+'?id=xigua_hb&ac=uploader&inajax=1&formhash='+FORMHASH,
            data :  formdata,
            processData : false,
            contentType : false,
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + cmp_photo + ')"><input type="hidden" name="'+filedname2+'[]" value="' + s.split('|')[1] + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                    $('#loadingimg').remove();
                    if(boxer2.data('only')){
                        boxer2.html(html);
                    }else{
                        boxer2.append(html);
                    }
                    if(callback && typeof callback === 'function') {
                        callback();
                    }
                } else {
                    tip_common(s);
                }
            }
        });
    }
    <!--{if IN_MAGAPP}-->
    function magPicPick2(){
        mag.picPick({
            preview: function(res){
                $.showLoading();
            },
            success: function(res){
                $.hideLoading();
                var imgu = typeof res.url!=='undefined' ? res.url : ('{$config[magapp_url]}/core/attachment/attachment/attach?aid='+res.aid);

                if(boxer2.data('only')){
                    var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="'+ uploadinput_obj2.data('name')+'[]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                    boxer2.html(html);
                }else{
                    var html_imga = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="form[album][]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                    boxer2.append(html_imga);
                }

            },
            fail: function(res){
                $.hideLoading();
            }
        });
    }
    <!--{/if}-->
</script>