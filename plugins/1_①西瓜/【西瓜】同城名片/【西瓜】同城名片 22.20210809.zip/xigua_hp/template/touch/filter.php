<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="weui-navbar border_top before_none after_none">
    <a data-id="1" id="ftb1" class="filter_nav weui-navbar__item">
        <span class="block border_right"><em data-html="{lang xigua_hp:sjpx}">{lang xigua_hp:sjpx}</em><i class="iconfont icon-xiangxia f12"></i></span>
    </a>
    <a data-id="2" id="ftb2" class="filter_nav weui-navbar__item">
        <span class="block border_right"><em data-html="{lang xigua_hp:qbfl}">{lang xigua_hp:qbfl}</em><i class="iconfont icon-xiangxia f12"></i></span>
    </a>
    <a data-id="3" id="ftb3" class="filter_nav weui-navbar__item">
        <span><em data-html="{lang xigua_hp:qbsq}">{lang xigua_hp:qbsq}</em><i class="iconfont icon-xiangxia f12"></i></span>
    </a>
</div>
<div class="dist_show">
    <div id="dist_show_1" class="nav_expand_panel hp_panel border_top">
        <div class="weui-flex">
            <div class="weui-flex__item">
                <ul>
                    <li class="first_check border_bfull"><a class="ftb" id="order_auto" data-idid="1" href="javascript:;" data-sort="&orderby=auto">{lang xigua_hp:znpx}</a></li>
                    <li class="first_check border_bfull"><a class="ftb" id="order_nearby" data-idid="1" href="javascript:;" data-sort="&orderby=nearby">{lang xigua_hp:fjyx}</a></li>
                    <li class="first_check border_bfull"><a class="ftb" id="order_zans" data-idid="1" href="javascript:;" data-sort="&orderby=zans">{lang xigua_hp:zans}</a></li>
                    <li class="first_check border_bfull"><a class="ftb" id="order_views" data-idid="1" href="javascript:;" data-sort="&orderby=views">{lang xigua_hp:rqzg}</a></li>
                    <li class="first_check border_bfull"><a class="ftb" id="order_follow" data-idid="1" href="javascript:;" data-sort="&orderby=follow">{lang xigua_hp:scb}</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div id="dist_show_2" class="nav_expand_panel hp_panel border_top">
        <div class="weui-flex">
            <div class="weui-flex__item">
                <ul>
                    <li class="first_cat_check border_bfull"><a class="ftb" data-idid="2" data-sort="&hyid=0">{lang xigua_hb:quanbu}{lang xigua_hp:fenlei}</a></li>
                    <!--{loop $cat_tree $k $v}-->
                    <!--{if !$v[adlink]}-->
                    <li class="first_cat_check border_bfull" <!--{if $v[sub]}--> data-id="$v[id]"<!--{/if}-->><a <!--{if !$v[sub]}--> class="ftb" data-idid="2" data-sort="&hyid={$v[id]}"<!--{/if}-->>$v[name]</a></li>
                    <!--{/if}-->
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="weui-flex__item checked">
                <!--{loop $cat_tree $k $v}-->
                <ul class="sub_cat_cheker <!--{if !($hyid==$v[id]||$pid==$v[id])}-->none<!--{/if}-->" id="sub_cat_cheker_$v[id]">
                    <li class="sub_cat_check border_bfull"><a class="ftb" data-idid="2" data-sort="&hyid={$v[id]}" data-orihtml="{$v[name]}">{lang xigua_hb:quanbu}</a></li>
                    <!--{loop $v[sub] $vv}-->
                    <li class="sub_cat_check border_bfull"><a class="ftb" data-idid="2" data-sort="&hyid={$vv[id]}">$vv[name]</a></li>
                    <!--{/loop}-->
                </ul>
                <!--{/loop}-->
            </div>
        </div>
    </div>
    <div id="dist_show_3" class="nav_expand_panel hp_panel border_top">
        <div class="weui-flex">
            <div class="weui-flex__item">
                <ul>
                    <li class="first_check border_bfull"><a class="ftb" data-idid="3" data-sort="&city=-1" href="javascript:;">{lang xigua_hb:quanbu}{lang xigua_hp:sq}</a></li>
                    <!--{loop $dist0 $v}-->
                    <li class="first_check border_bfull" data-id="$v[id]"><a>{$v[name]}</a></li>
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="weui-flex__item checked">
                <!--{loop $dist0 $k $v}-->
                <ul class="sub_cheker <!--{if $city_id!=$v['id']}-->none<!--{else}-->checked<!--{/if}-->" id="sub_cheker_$v[id]">
                    <li class="sub_check border_bfull"><a class="ftb color-red" data-idid="3" data-sort="&city={$v[name]}" href="javascript:;" data-orihtml="{$v[name]}">{lang xigua_hp:quan}{$v[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a></li>
                    <!--{loop $v[child] $vv}-->
                    <li class="sub_check border_bfull <!--{if $dist==$vv[name]&&$_GET[dist]}-->checked main_color<!--{/if}-->"><a href="javascript:;" id="sub_check{$vv[id]}" data-id="$vv[id]" onclick="getnext($vv[id],'$vv[name]')">$vv[name]</a></li>
                    <!--{/loop}-->
                </ul>
                <!--{/loop}-->
            </div>
            <div class="weui-flex__item checked" id="ajaxbox" style="position:relative;height:65vh"> <ul class="ajaxbox_cheker"></ul> </div>
        </div>
    </div>
</div>

<div class="">
    <!--{if $nomine}-->
    <a href="$SCRITPTNAME?id=xigua_hp&ac=my&mobile=2{$urlext}" class="lingqu_li weui-cell before_none lq_mine jobox">
        <div class="jocard main_border"></div>
        <div class="jocard main_border"></div>
        <div class="jocard main_border"></div>
        <div class="weui-cell__bd">
            <h2 class="f18 main_color">{lang xigua_hp:nhmymp}</h2>
            <p class="f14 main_color">{lang xigua_hp:djljyy}</p>
        </div>
        <div class="weui-cell__ft">
            <i class="iconfont icon-jinrujiantou f22 main_color"></i>
        </div>
    </a>
    <!--{/if}-->
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
</div><!--{eval
if($_GET[indexorder]):
    $hp_config[indexorder] = $_GET[indexorder];
endif;
}--><script>
var _pre = window.location.href;
if(_pre.indexOf('?')===-1&& _pre.indexOf('&')===-1){
    _pre = _APPNAME+'?id=xigua_hp';
}
<!--{if $hp_config[indexorder]=='nearby'}-->
var loadingurl = _pre+'&ac=good_li&inajax=1&page=';
setTimeout(function () {$('#order_{$hp_config[indexorder]}').trigger('click');if (typeof wx !== 'undefined') {wx.ready(function () {$('#order_{$hp_config[indexorder]}').trigger('click');});}}, 200);
<!--{elseif $hp_config[indexorder]}-->
var loadingurl = _pre+'&ac=good_li&inajax=1&orderby={$hp_config[indexorder]}&page=';
var thatO = $('#order_{$hp_config[indexorder]}');
thatO.parent().parent().find('.checked').removeClass('checked main_color');
thatO.parent().addClass('checked main_color');
var oem = $('#ftb'+thatO.data('idid')).find('em');
var showhtm = thatO.html();
if(thatO.data('orihtml')){showhtm = thatO.data('orihtml');}
oem.data('html', oem.html()).html(showhtm);
<!--{else}-->
var loadingurl = _pre+'&ac=good_li&inajax=1&page=';
<!--{/if}-->
scrollto = 1;
var lockIng = 0;
</script>