<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hp:header}-->
<style>.page, body{background:#fff}</style>
<div class="page__bd">
    <!--{if stripos($_SERVER['HTTP_USER_AGENT'], 'Android') && HB_INWECHAT}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <!--{loop $vlist $v}-->
    <div class="mpc">
        <div class="mpc_body">
            <!--{if !$v[mpid]}-->
            <div class="mpc_guide">{$v[tip1]}</div>
            <a class="mpc_link" href="$SCRITPTNAME?id=xigua_hp&ac=join&mobile=2{$urlext}">{$v[tip2]}</a>
            <!--{elseif $v[status]==-1}-->
            <div class="mpc_guide">{lang xigua_hp:mpshz}</div>
            <a class="mpc_link" href="$SCRITPTNAME?id=xigua_hp&ac=join&mobile=2{$urlext}">{lang xigua_hp:bjmp}</a>
            <!--{elseif $v[status]==-2}-->
            <div class="mpc_guide">{lang xigua_hp:ddzf}</div>
            <a class="mpc_link" href="javascript:;" onclick="return confirm_pay($v[mpid], '$v[jumpurl]');">{lang xigua_hp:ljzf}</a>
            <!--{else}-->
            <div class="mpc_main">
                <div class="mpc_main_top cl">
                    <h2>{$v[name]}</h2>
                    <div class="f12 c9">
                        <span><em class="main_color">{echo intval($v[views])}</em>{lang xigua_hp:views}</span>
                        <span><em class="main_color">{echo intval($v[zans])}</em>{lang xigua_hp:dz}</span>
                        <span><em class="main_color">{echo intval($v[follows])}</em>{lang xigua_hp:follows}</span>
                    </div>
                    <div class="ava">
                        <img src="{$v[avatar]}" />
                    </div>
                </div>
                <ul class="mpc_main_list cl">
                    <li>{$v[bm]} {$v[zw]}</li>
                    <li>{$v[company]} <!--{if $v[shid]}-->
                        <a href="$SCRITPTNAME?id=xigua_hs&ac=view&mobile=2&shid={$v[shid]}&mobile=2{$urlext}" class="main_color">{lang xigua_hp:jd}<i class="iconfont icon-shopfill f14 vm"></i></a>
                    <!--{/if}--></li>
                    <!--{if $v[openaddr]}-->
                    <li>{lang xigua_hp:wz} : $v[addr]</li>
                    <!--{/if}-->
                    <!--{if $v[openmobile]}-->
                    <li>{lang xigua_hp:dh} : <em class="main_color" data-clipboard-text="$v[mobile]">$v[mobile]</em></li>
                    <!--{else}-->
                    <li>{lang xigua_hp:dh} : <em class="main_color">{echo substr_replace($v[mobile], '****', 3, 4);}</em></li>
                    <!--{/if}-->
                    <!--{if $v[openwx]}-->
                    <li>{lang xigua_hp:wx_} : <em class="main_color btn" data-clipboard-text="$v[wx]">$v[wx]</em></li>
                    <!--{/if}-->
                </ul>
                <!--{if $v[wfz]}-->
                <div class="mpc_main_ft tc">
                    "{$v[wfz]}"
                </div>
                <!--{/if}-->
                <div class="tiing <!--{if $v[is_end]}-->tiing1<!--{/if}-->">{$v[endts_uu]}</div>
            </div>
            <!--{/if}-->
        </div>
        <!--{if $v[mpid]}-->
        <div class="mpc_area weui-flex">
            <a class="weui-flex__item hpxufei" data-id="{$v[mpid]}" data-name="{$v[name]}" href="javascript:;">
                <i class="iconfont icon-shijian f20 color-red"></i>
                <p>{lang xigua_hp:xufei}</p>
            </a>
            <a class="weui-flex__item" href="$SCRITPTNAME?id=xigua_hp&ac=join&mpid={$v[mpid]}&mobile=2{$urlext}">
                <i class="iconfont icon-bianjixiugai f20 main_color"></i>
                <p>{lang xigua_hp:edit}</p>
            </a>
            <!--{if $dig_prices}-->
            <a class="weui-flex__item hpdig" data-id="{$v[mpid]}" data-name="{$v[name]}" href="javascript:;">
                <i class="iconfont icon-huidaodingbu f20 main_color"></i>
                <p>{lang xigua_hp:zd}</p>
            </a>
            <!--{/if}-->
            <a class="weui-flex__item hp_glist" data-id="{$v[mpid]}" data-cookie="dishpmask_" href="javascript:;">
                <i class="iconfont icon-mingpian f20 main_color"></i>
                <p>{lang xigua_hp:dmp}</p>
            </a>
        </div>
        <!--{/if}-->
<!--        <a ><i class="iconfont icon-normal"></i></a>-->
    </div>
    <!--{/loop}-->

    <div class="weui-flex mpb">
        <a href="$SCRITPTNAME?id=xigua_hb&ac=pub&mobile=2{$urlext}" class="weui-flex__item" >

            <i class="iconfont icon-fabu1 main_color f24"></i>
            <p class="weui-grid__label">{lang xigua_hp:fbdt}</p>
        </a>
        <!--{if $_G['cache']['plugin']['xigua_hs']}-->
        <a href="$SCRITPTNAME?id=xigua_hp&ac=mysh&mobile=2{$urlext}" class="weui-flex__item">

            <i class="iconfont icon-shop color-rss f24"></i>
            <p class="weui-grid__label">{lang xigua_hp:wddp}</p>
        </a>
        <!--{/if}-->
        <a href="$SCRITPTNAME?id=xigua_hp&indexorder=views&mobile=2{$urlext}" class="weui-flex__item">

            <i class="iconfont icon-mingpianjia color-red f24"></i>
            <p class="weui-grid__label">{lang xigua_hp:mpph}</p>
        </a>

    </div>
</div>
<div class="footer_fix"></div>
<!--{eval $tabbar=0;$hp_tabbar=1;}-->
<!--{template xigua_hp:footer}-->
<script>
function confirm_pay(mpid, jumpurl){
    $.modal({
        title: "{lang xigua_hp:ddzf}",
        text: "{lang xigua_hp:hxzf} <em class='main_color'>{$hp_config[mpprice]}{lang xigua_hp:yuan}</em>",
        buttons: [
            { text: "{lang xigua_hp:cancel}", className: "default", onClick: function(){ } },
            { text: "{lang xigua_hp:qxdd}", onClick: function(){
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME+'?id=xigua_hp&ac=delmy&inajax=1&mpid='+mpid,
                    data:{formhash:FORMHASH},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () { $.hideLoading(); }
                });
                } },
            { text: "{lang xigua_hp:ljzf}", onClick: function(){

                    if(typeof wx !=='undefined'){
                        if (window.__wxjs_environment === 'miniprogram') {
                            wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jumpurl)});
                            return false;
                        }
                    }
                    window.location.href=jumpurl;
                } }
        ]
    });
    return false;
}
<!--{eval $mp_price = hp_parese_price($hp_config['mp_price']);}-->
<!--{if $mp_price}-->
$(document).on('click','.hpxufei', function () {
    var that = $(this);

    $.actions({
        title: '{lang xigua_hp:xufei}: '+that.data('name'),
        actions: [
            <!--{loop $mp_price $item}-->
            {text: "{$item[title]}", onClick: function () {
                    var _axjurl = '$SCRITPTNAME?id=xigua_hp&ac=doxufei&type={$item[type]}&mpid='+that.data('id');
                    $.showLoading();
                    $.ajax({
                        type: 'post',
                        url: _axjurl,
                        data: {'formhash' :FORMHASH},
                        dataType: 'xml',
                        success: function (data) {
                            $.hideLoading();
                            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                            var s = data.lastChild.firstChild.nodeValue;
                            var msgar = tip_common(s);
                        },
                        error: function () {
                            $.hideLoading();
                        }
                    });
                }},
            <!--{/loop}-->
        ],
        onClose:function () {
        }
    });

});
<!--{/if}-->
</script>