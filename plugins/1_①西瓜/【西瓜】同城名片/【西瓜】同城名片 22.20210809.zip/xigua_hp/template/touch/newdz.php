<?php exit('Author: https://dism.taobao.com?/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="weui-cell">
    <div class="weui-cell__hd"><label class="weui-label">Email<!--{if in_array('wx', $btzd)}--><em class="color-red">*</em><!--{/if}--></label></div>
    <div class="weui-cell__bd">
        <input class="weui-input" type="text" name="form[email]" placeholder="{lang xigua_hp:qtx}Email" value="{$old_data[email]}">
    </div>
</div>
<div class="weui-cell">
    <div class="weui-cell__hd"><label class="weui-label">��Ӫ<!--{if in_array('wx', $btzd)}--><em class="color-red">*</em><!--{/if}--></label></div>
    <div class="weui-cell__bd">
        <input class="weui-input" type="text" name="form[zhuying]" placeholder="{lang xigua_hp:qtx}��Ӫ" value="{$old_data[zhuying]}">
    </div>
</div>
<div class="weui-cell">
    <div class="weui-cell__hd"><label class="weui-label">��ǩ<!--{if in_array('wx', $btzd)}--><em class="color-red">*</em><!--{/if}--></label></div>
    <div class="weui-cell__bd">
        <input class="weui-input" type="text" name="form[biaoqian]" placeholder="{lang xigua_hp:qtx}��ǩ,����ո����" value="{$old_data[biaoqian]}">
    </div>
</div>

<div class="weui-cell">
    <div class="weui-cell__bd">
        <div class="weui-uploader">
            <div class="weui-uploader__hd">
                <p class="weui-uploader__title">��Ƭ����</p>
                <div class="weui-uploader__info">����ϴ�2����Ƭ</div>
            </div>
            <div class="weui-uploader__bd">
                <ul class="weui-uploader__files" data-max="2" data-maxtip="{echo str_replace('n', 2, lang_hb('zuiduozhao',0))}" id="uploaderFiles">
                    <!--{loop $old_data[imglist1] $img}-->
                    <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[imglist1][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                    <!--{/loop}-->
                </ul>
                <div class="weui-uploader__input-box">
                    <!--{if HB_INWECHAT && $config[multiupload]}-->
                    <a class="weui-uploader__input" data-name="form[imglist1]" data-multi="1"></a>
                    <!--{else}-->
                    <input class="weui-uploader__input" data-name="form[imglist1]" type="file" data-multi="1">
                    <!--{/if}-->
                </div>
            </div>
        </div>
    </div>
</div>
<div class="weui-cell">
    <div class="weui-cell__bd">
        <div style="margin-bottom:10px">��ҵ���</div>
        <textarea class="weui-textarea" name="form[jianjie]" placeholder="����д��ҵ���" rows="3" value="{$old_data[jianjie]}">{$old_data[jianjie]}</textarea>
    </div>
</div>
<div class="weui-cell">
    <div class="weui-cell__bd">
        <div class="weui-uploader">
            <div class="weui-uploader__hd">
                <p class="weui-uploader__title">��ҵͼƬ</p>
                <div class="weui-uploader__info">����ϴ�6����Ƭ</div>
            </div>
            <div class="weui-uploader__bd">
                <ul class="weui-uploader__files" data-max="6" data-maxtip="{echo str_replace('n', 6, lang_hb('zuiduozhao',0))}" id="uploaderFiles">
                    <!--{loop $old_data[imglist2] $img}-->
                    <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[imglist2][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                    <!--{/loop}-->
                </ul>
                <div class="weui-uploader__input-box">
                    <!--{if HB_INWECHAT && $config[multiupload]}-->
                    <a class="weui-uploader__input" data-name="form[imglist2]" data-multi="1"></a>
                    <!--{else}-->
                    <input class="weui-uploader__input" data-name="form[imglist2]" type="file" data-multi="1">
                    <!--{/if}-->
                </div>
            </div>
        </div>
    </div>
</div>
<!--{template xigua_hp:enter_up2}-->