<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
function lang_hp($lang, $echo = 1)
{
	if ($lang == 'wode') {
		global $v;
		return $v['name'];
	}
	$ret = lang('plugin/xigua_hp', $lang);
	if ($echo) {
		echo $ret;
	} else {
		return $ret;
	}
	return $lang;
}
function hp_join_callback($param)
{
	$info = $param['info'];
	$data = $info['data'];
	$paytype = unserialize($data['paytype']);
	$dataendts = TIMESTAMP + $paytype['type'] * 86400;
	C::t('#xigua_hp#xigua_hp_user')->update($data['mpid'], array('status' => 1, 'payts' => TIMESTAMP, 'endts' => $dataendts));
	return true;
}
function hp_xufei_callback($param)
{
	$info = $param['info'];
	$data = $info['data'];
	$paytype = unserialize($data['paytype']);
	$old = C::t('#xigua_hp#xigua_hp_user')->fetch($data['mpid']);
	$startti = max($old['endts'], TIMESTAMP);
	$dataendts = $startti + $paytype['type'] * 86400;
	C::t('#xigua_hp#xigua_hp_user')->update($data['mpid'], array('endts' => $dataendts));
	return true;
}
function hp_dig_callback($param)
{
	$info = $param['info'];
	$data = $info['data'];
	$old_data = C::t('#xigua_hp#xigua_hp_user')->fetch($data['mpid']);
	$replace = array('dig_endts' => max(TIMESTAMP, $old_data['dig_endts']) + 86400 * $old_data['dig_days'], 'dig_startts' => TIMESTAMP);
	C::t('#xigua_hp#xigua_hp_user')->update($data['mpid'], $replace);
	return true;
}
function hp_parese_price($price, $needkey = 0)
{
	$dig_prices = array();
	foreach (explode("\n", trim($price)) as $item) {
		list($tmp_type, $tmp_price) = explode('=', trim($item));
		$tmp_lang = lang_hb('days_' . $tmp_type, 0);
		if ($tmp_type == 1) {
			$item_price = $tmp_price;
		}
		if ($tmp_type != 1 && $item_price) {
			$s = $tmp_type * $item_price - $tmp_price;
			if ($s <= 0) {
				$s = '';
			} else {
				$s = '<s style=\'color:red\'>' . lang_hp('sheng', 0) . ('&yen;' . $s . '</s>');
			}
		}
		$p = '(' . lang_hb('shoufei', 0) . $tmp_price . lang_hb('yuan', 0) . ($s . ')');
		if ($tmp_price <= 0) {
			$p = '';
		}
		$dig_prices[$tmp_type] = array('type' => $tmp_type, 'title' => lang_hp('yxq', 0) . ($tmp_lang == 'days_' . $tmp_type ? $tmp_type . lang_hb('day', 0) : $tmp_lang) . $p, 'price' => $tmp_price);
	}
	return !$needkey ? array_values($dig_prices) : $dig_prices;
}
function hp_qrcode_make($mpid, $url, $avatar = '')
{
	$url = str_replace('&d=1', '', $url);
	global $SCRITPTNAME;
	global $hp_config;
	global $_G;
	global $urlext;
	if ($hp_config['typewx'] == 2) {
		$upar = parse_url($url);
		$hb_currenturl = urlencode('https://' . $upar['host'] . $upar['path'] . ('?id=xigua_hp&ac=view&mpid=' . $mpid . '&z=9' . $urlext));
		$_qrfile = './source/plugin/xigua_hp/cache/mp_' . $mpid . '.jpg';
		if (!is_file(DISCUZ_ROOT . $_qrfile)) {
			@(include_once DISCUZ_ROOT . 'source/plugin/mobile/qrcode.class.php');
			if (class_exists('QRcode')) {
				QRcode::png($hb_currenturl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
			}
		}
		$shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&logo=' . urlencode($avatar) . '&url=' . $hb_currenturl;
		return $shqr;
	}
	$config = $_G['cache']['plugin']['xigua_hb'];
	if ($config['qraut'] && !$hp_config['yinsi']) {
		return $SCRITPTNAME . '?id=xigua_hb:qrauto&ode=mp_' . $mpid . $urlext;
	}
	$repath = './source/plugin/xigua_hp/cache/';
	$qrfile = $repath . $mpid . '.png';
	$abs_qrfile = DISCUZ_ROOT . $qrfile;
	if (!is_file($abs_qrfile)) {
		@(include_once DISCUZ_ROOT . 'source/plugin/mobile/qrcode.class.php');
		if (class_exists('QRcode')) {
			QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
		}
	}
	return $qrfile;
}
function hppostx($lang, $vars)
{
	global $adminids;
	if ($adminids) {
		$adminids = array_slice($adminids, 0, 10);
		foreach ($adminids as $adminid) {
			notification_add($adminid, 'system', $lang, $vars, 1);
		}
	}
}
function hp_index()
{
		global $hyobj;
		global $stcon;
		global $_G;
		global $gid;
		global $dig_prices;
		global $hp_config;
		global $config;
		global $svicerange;
		global $aclist;
		global $aclist_login;
		global $ac;
		global $do;
		global $isself;
		global $start_limit;
		global $page;
		global $lpp;
		global $uid;
		global $mpid;
		$gid = intval($_GET['gid']);
		$dig_prices = array();
		if ($hp_config['digtype']) {
			foreach (explode("\n", trim($hp_config['digtype'])) as $item) {
				list($tmp_type, $tmp_price) = explode('=', trim($item));
				$tmp_lang = lang_hb('days_' . $tmp_type, 0);
				$dig_prices[$tmp_type] = array('type' => $tmp_type, 'title' => lang_hb('zhiding', 0) . ($tmp_lang == 'days_' . $tmp_type ? $tmp_type . lang_hb('day', 0) : $tmp_lang) . '(' . lang_hb('shoufei', 0) . $tmp_price . lang_hb('yuan', 0) . ')', 'price' => $tmp_price);
			}
		}
		$svicerange = array();
		foreach (explode("\n", trim($hp_config['svicerange'])) as $index => $item) {
			$svicerange[] = trim($item);
		}
		$aclist = array('index', 'join', 'my', 'getshinfo', 'delmy', 'chosecity', 'good_li', 'view', 'zan', 'shoucun', 'incr', 'follow', 'delfollow', 'mysh', 'none', 'dompdel', 'dodig', 'doxufei');
		$aclist_login = array('join', 'dompdel', 'dodig', 'shoucun', 'zan', 'doxufei');
		$ac = $_GET['ac'];
		$do = $_GET['do'];
		if (!in_array($ac, $aclist)) {
			$ac = 'index';
		}
		$isself = in_array($ac, $aclist_login) || !(strpos($ac, 'my') === false) && !$_G['uid'];
		if ($isself && !$_G['uid']) {
			hb_jump_login();
		}
		$_GET = dhtmlspecialchars($_GET);
		$page = max(1, intval($_GET['page']));
		$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
		$start_limit = ($page - 1) * $lpp;
		$uid = $_G['uid'];
		$mpid = intval($_GET['mpid']);
		$stcon = '';
		if ($hp_config['allowst']) {
			$stcon = ' AND stid=' . intval($_GET['st']);
		}
		if ($hp_config['hytype'] == 1) {
			$hyobj = C::t('#xigua_hs#xigua_hs_hangye');
		} else {
			$hyobj = C::t('#xigua_hp#xigua_hp_hangye');
	}
}
function hp_my()
{
	global $desc;
	global $stcon;
	global $_G;
	global $navtitle;
	global $indeximg;
	global $hp_config;
	global $config;
	global $vlist;
	global $SCRITPTNAME;
	global $urlext;
	global $order_id;
	global $rl;
	global $maxnum;
	global $start_limit;
	global $page;
	global $lpp;
	global $uid;
	global $mpid;
	$desc = $navtitle = lang_hp('wdmp', 0);
	$indeximg = $hp_config['viewimg'];
	$vlist = C::t('#xigua_hp#xigua_hp_user')->fetch_all_by_where(array('uid=' . $_G['uid'] . ' ' . $stcon), 0, 99);
	foreach ($vlist as $index => $item) {
		if ($item['status'] == 0 - 2) {
			$order_id = $item['order_id'];
			$rl = urlencode($SCRITPTNAME . '?id=xigua_hp&ac=my' . $urlext);
			$vlist[$index]['jumpurl'] = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
		}
	}
	$maxnum = $hp_config['maxnum'] - count($vlist);
	if (!$vlist) {
		$vlist = array();
		$vlist[] = array('tip1' => lang_hp('nhmymp', 0), 'tip2' => lang_hp('djljyy', 0));
	} else {
		if ($maxnum > 0) {
			$vlist[] = array('tip1' => str_replace('n', $maxnum, lang_hp('hkycj', 0)), 'tip2' => lang_hp('ljcj', 0));
		}
	}
}
function hp__index()
{
	global $topnavslider;
	global $hyobj;
	global $_G;
	global $hyid;
	global $hy;
	global $hp_config;
	global $config;
	global $list_all;
	global $SCRITPTNAME;
	global $urlext;
	global $cat_tree_init;
	global $cat_tree;
	global $catname;
	global $subcat;
	global $subcats;
	global $lpp;
	global $uid;
	global $mpid;
	$topnavslider = hb_parse_set($hp_config['topslider']);
	$hyid = intval($_GET['hyid']);
	$hy = $hyobj->fetch($hyid);
	$list_all = $hyobj->list_all();
	$hyobj->init($list_all);
	$cat_tree_init = $cat_tree = $hyobj->get_tree_array(0);
	$cat_tree = array_values($cat_tree);
	$catname = $hy['name'] ? $hy['name'] : lang_hb('quanbu', 0);
	$subcat = $cat_tree;
	if ($hy['pid'] == 0) {
		$subcats = $cat_tree_init[$hyid]['child'];
	}
}