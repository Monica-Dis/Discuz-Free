<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_hp_shoucun` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `mpid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `pubid` (`mpid`),
 KEY `uid` (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hp_user` (
 `mpid` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `order_id` char(24) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `payts` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '-1:start 1:normal  -2:notpay',
 `stid` int(11) NOT NULL,
 `note` varchar(800) NOT NULL,
 `name` varchar(80) NOT NULL,
 `hy` varchar(80) NOT NULL,
 `hangye_id1` int(11) NOT NULL,
 `hangye_id2` int(11) NOT NULL,
 `addr` varchar(500) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `wx` varchar(80) NOT NULL,
 `avatar` varchar(500) NOT NULL,
 `lat` varchar(20) NOT NULL,
 `lng` varchar(20) NOT NULL,
 `province` varchar(80) NOT NULL,
 `city` varchar(80) NOT NULL,
 `district` varchar(80) NOT NULL,
 `street` varchar(80) NOT NULL,
 `street_number` varchar(80) NOT NULL,
 `zw` varchar(80) NOT NULL,
 `wfz` varchar(200) NOT NULL,
 `openmobile` tinyint(1) NOT NULL,
 `openwx` tinyint(1) NOT NULL,
 `openaddr` tinyint(1) NOT NULL,
 `bm` varchar(80) NOT NULL,
 `company` varchar(80) NOT NULL,
 `views` int(11) NOT NULL,
 `zans` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `follows` int(11) NOT NULL,
 `shname` varchar(200) NOT NULL,
 `shid` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 PRIMARY KEY (`mpid`),
 KEY `order_id` (`order_id`),
 KEY `stid` (`stid`),
 KEY `status` (`status`),
 KEY `shid` (`shid`),
 KEY `lat` (`lat`),
 KEY `lng` (`lng`),
 KEY `wx` (`wx`),
 KEY `hangye_id1` (`hangye_id1`),
 KEY `hangye_id2` (`hangye_id2`),
 KEY `province` (`province`),
 KEY `city` (`city`),
 KEY `district` (`district`),
 KEY `displayorder` (`displayorder`),
 KEY `zans` (`zans`),
 KEY `follows` (`follows`),
 KEY `views` (`views`),
 KEY `shares` (`shares`),
 KEY `uid` (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hp_zan` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `mpid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `pubid` (`mpid`),
 KEY `uid` (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hp_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hp_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;
SQL;



runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hp/discuz_plugin_xigua_hp.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hp/discuz_plugin_xigua_hp_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hp/discuz_plugin_xigua_hp_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hp/discuz_plugin_xigua_hp_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hp/discuz_plugin_xigua_hp_TC_UTF8.xml');

$finish = TRUE;


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'dig_endts\'', array('xigua_hp_user'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hp_user` ADD `dig_startts` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hp_user` ADD `dig_endts` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hp_user` ADD `dig_days` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hp_user` ADD INDEX(`dig_startts`);

ALTER TABLE `pre_xigua_hp_user` ADD INDEX(`dig_endts`);

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'endts\'', array('xigua_hp_user'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hp_user` ADD `endts` INT(11) NOT NULL DEFAULT '-1';
ALTER TABLE `pre_xigua_hp_user` ADD INDEX(`endts`);
ALTER TABLE `pre_xigua_hp_user` ADD `paytype` VARCHAR(2000) NOT NULL;

SQL;
    runquery($sql);
}


@unlink(DISCUZ_ROOT . './source/plugin/xigua_hp/install.php');