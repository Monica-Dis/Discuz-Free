<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
$hp_config = $_G['cache']['plugin']['xigua_hp'];
$cardtype = array();
foreach (explode("\n", trim($hp_config['cardtype'])) as $index => $item) {
    $cardtype[] = explode('#', trim($item));
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hp/function.php';

function hp_qrcode_mak($mpid, $url, $avatar = ''){
    $url = str_replace('&d=1', '', $url);
    global $SCRITPTNAME, $hp_config, $_G,$urlext;
    if($hp_config['typewx'] ==2){
        $upar = parse_url($url);
        $hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_hp&ac=view&mpid=$mpid&z=9{$urlext}");
        $_qrfile = './source/plugin/xigua_hp/cache/mp_' . $mpid . '.jpg';
        if (!is_file(DISCUZ_ROOT . $_qrfile)){
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')){
                QRcode::png($hb_currenturl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
            }
        }
        $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&logo='.urlencode($avatar).'&url='.$hb_currenturl;
        return $shqr;
    }else{
        $config = $_G['cache']['plugin']['xigua_hb'];
        if($config['qraut'] && !$hp_config['yinsi']){
            return "$SCRITPTNAME?id=xigua_hb:qrauto&ode=mp_{$mpid}{$urlext}";
        }
        $repath = './source/plugin/xigua_hp/cache/';
        $qrfile = $repath . $mpid . '.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;

        if(!is_file($abs_qrfile)) {
            if (!is_file($abs_qrfile)) {
                @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                if(class_exists('QRcode')){
                    QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
                }
            }
        }
        return $qrfile;
    }
}

function hp_hex2rgb($colour, $a){
    if ($colour[0] == '#') {
        $colour = substr($colour, 1);
    }
    if (strlen($colour) == 6) {
        list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
    }
    elseif (strlen($colour) == 3) {
        list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
    }
    else {
        return false;
    }
    $r = hexdec($r);
    $g = hexdec($g);
    $b = hexdec($b);
    return "rgba($r, $g, $b, $a)";
}
hp_index();
switch ($ac){
    case 'dompdel':
        if(submitcheck('formhash')){
            C::t('#xigua_hp#xigua_hp_user')->del_by_uid_mpid($mpid);
            hb_message(lang_hp('del_success',0), 'success', "$SCRITPTNAME?id=xigua_hp&ac=my{$urlext}");
        }
        break;
    case 'delfollow':
        if(submitcheck('formhash')){
            C::t('#xigua_hp#xigua_hp_shoucun')->del_by_mpid($mpid);
            hb_message('success');
        }
        break;
    case 'incr':
        if(submitcheck('formhash')){
            if(in_array($_GET['incr_type'], array('shares'))){
                C::t('#xigua_hp#xigua_hp_user')->incr($mpid, $_GET['incr_type']);
                hb_message('success');
            }
        }
        break;
    case 'shoucun':
        if(submitcheck('formhash')){
            if(C::t('#xigua_hp#xigua_hp_shoucun')->fetch_by_uid($_G['uid'], $mpid)){
                hb_message(lang_hp('yjsc',0), 'error');
            }else{
                C::t('#xigua_hp#xigua_hp_user')->incr($mpid, 'follows');
                C::t('#xigua_hp#xigua_hp_shoucun')->insert(array('uid' => $_G['uid'], 'mpid' => $mpid, 'crts' => TIMESTAMP));
                hb_message(lang_hp('sccg',0), 'success');
            }
        }
        break;
    case 'zan':
        if(submitcheck('formhash') && $_GET['mmppid']){
            DB::insert('xigua_hb_viewtel' , array(
                'uid' => $_G['uid'],
                'crts' => TIMESTAMP,
                'pubid' => $_GET['mmppid'],
                'idtype' => 'mpid'
            ));
            hb_message(lang_hb('do_succeed', 0), 'success', 'reload');
        }else
        if(submitcheck('formhash')){
            if(C::t('#xigua_hp#xigua_hp_zan')->fetch_by_uid($_G['uid'], $mpid)){
                hb_message(lang_hb('zanguo',0), 'error');
            }else{
                C::t('#xigua_hp#xigua_hp_user')->incr($mpid, 'zans');
                C::t('#xigua_hp#xigua_hp_zan')->insert(array('uid' => $_G['uid'], 'mpid' => $mpid, 'crts' => TIMESTAMP));
                hb_message(lang_hb('chengong',0), 'success');
            }
        }
        break;
    case 'chosecity':
        if($_GET['ctid']){
            $rlist = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($_GET['ctid']);
            include template('xigua_hb:header_ajax');
            include template('xigua_hp:chosecity');
            include template('xigua_hb:footer_ajax');
        }
        break;
    case 'dodig':
        $url = $_GET['backto'] ? $_GET['backto'] : "$SCRITPTNAME?id=xigua_hp&ac=my$urlext";

        $dig_days  = $dig_prices[$_GET['digtype']]['type'];
        $dig_price = $dig_prices[$_GET['digtype']]['price'];
        if($dig_price) {
            $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $dig_price, sprintf(lang_hp('zhidingsubject', 0), $dig_days, $mpid), 'com', array(
                'data' => array('mpid' => $mpid),
                'callback' => array(
                    'file' => 'source/plugin/xigua_hp/function.php',
                    'method' => 'hp_dig_callback'
                ),
                'location' => $_GET['backto'] ? $_GET['backto'] : $_G['siteurl'] . $url,
            ));
            C::t('#xigua_hp#xigua_hp_user')->update($mpid, array('dig_days' => $dig_days));

            $rl = urlencode($url);
            $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl" . $urlext) . $urlext;
            hb_message(lang_hp('jumppay', 0), 'success', $jumpurl);
        }
        break;
    case 'doxufei':
        $url = $_GET['backto'] ? $_GET['backto'] : "$SCRITPTNAME?id=xigua_hp&ac=my$urlext";
        if(submitcheck('formhash')){
            $mp_price = hp_parese_price($hp_config['mp_price'], 1);
            $paytype = $_GET['type'];
            if(!$mp_price[$paytype]){
                hb_message(lang_hp('paytype_error',0), 'error');
            }
            $mp_p = $mp_price[$paytype];
            if($mp_p['price']>0){
                $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $mp_p['price'], lang_hp('xufshij',0).$mp_p['title'], 'com', array(
                    'data' => array(
                        'mpid' => $mpid,
                        'paytype' =>serialize($mp_p),
                    ),
                    'callback' => array(
                        'file' => 'source/plugin/xigua_hp/function.php',
                        'method' => 'hp_xufei_callback'
                    ),
                    'location' => $_GET['backto'] ? $_GET['backto'] : $_G['siteurl'] . $url,
                ));
                $rl = urlencode($url);
                $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl" . $urlext) . $urlext;
                hb_message(lang_hp('jumppay', 0), 'success', $jumpurl);
            }else{
                $old = C::t('#xigua_hp#xigua_hp_user')->fetch($mpid);
                $startti = max($old['endts'], TIMESTAMP);
                $dataendts = $startti + ($mp_p['type']*86400);
                C::t('#xigua_hp#xigua_hp_user')->update($mpid, array('endts' => $dataendts));
                hb_message(lang_hp('xfcg', 0), 'success', 'reload');
            }
        }
        break;
    case 'join':
        $navtitle = lang_hp('wsmp',0);
        $mpzd = unserialize($hp_config['mpzd']);
        if(submitcheck('formhash')){
            if(!$mpid){
                if($hp_config['maxnum'] <=C::t('#xigua_hp#xigua_hp_user')->fetch_count_by_page(array("uid={$_G['uid']} $stcon"))){
                    hb_message(str_replace('n', $hp_config['maxnum'], lang_hp('zdrz',0)), 'error', "$SCRITPTNAME?id=xigua_hp&ac=my$urlext");
                }
            }
            $form = $_GET['form'];
            $btzd = unserialize($hp_config['btzd']);
            foreach ($btzd as $index => $requry) {
                if(!$form[$requry]){
                    hb_message(lang_hp($requry.'_tip', 0), 'error');
                }
            }

            $hy_ret = $hyobj-> fetch_by_name(array_filter(explode(' ', trim($form['hy']))));
            $form['hangye_ids'] = array_keys($hy_ret);
            if($form['mobile'] && !preg_match($isMob, $form['mobile']) && !preg_match($isTel, $form['mobile'])){
                hb_message(lang_hp('mobile_error',0), 'error');
            }

            if(!$form['avatar']){
                $form['avatar'] = avatar($_G['uid'], 'middle', 1, 0, 1);
            }

            $data = array (
                'name' => $form['name'],
                'hy' => $form['hy'],
                'hangye_id1' => $form['hangye_ids'][0],
                'hangye_id2' => $form['hangye_ids'][1],
                'addr' => $form['addr'],
                'mobile' => $form['mobile'],
                'wx' => $form['wx'],
                'avatar' => $form['avatar'],
                'lat' => $form['lat'],
                'lng' => $form['lng'],
                'province' => $form['province'],
                'city' => $form['city'],
                'district' => $form['district'],
                'street' => $form['street'],
                'street_number' => $form['street_number'],
                'bm'   => $form['bm'],
                'company'   => $form['company'],
                'zw'   => $form['zw'],
                'wfz'   => $form['wfz'],
                'openmobile'   => $form['openmobile'],
                'openwx'   => $form['openwx'],
                'openaddr'   => $form['openaddr'],
                'stid' => intval($_GET['st']),
                'upts' => TIMESTAMP,
                'uid' => $_G['uid'],
            );

            if($form['shname']){
                $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']);
                $data['shname'] = $sh['name'];
                $data['shid'] = $sh['shid'];
            }

            if($mpid){
                $old_data = C::t('#xigua_hp#xigua_hp_user')->fetch($mpid);
                if($old_data['uid'] != $_G['uid']){
                    hb_message('error', 'error');
                }
                @unlink(DISCUZ_ROOT. './source/plugin/xigua_hp/cache/'.$mpid . '.png');
                @unlink(DISCUZ_ROOT. './source/plugin/xigua_hp/cache/'.$mpid . '.jpg');
                C::t('#xigua_hp#xigua_hp_user')->update($mpid, $data);
                hb_message(lang_hp('fabuok', 0), 'success', "$SCRITPTNAME?id=xigua_hp&ac=my$urlext");
            }else{
                $data['crts'] = TIMESTAMP;
                $data['status'] = -1;
                $data['order_id'] = '';

                $mp_price = hp_parese_price($hp_config['mp_price'], 1);
                $paytype = $form['paytype'];
                if(!$mp_price[$paytype]){
                    hb_message(lang_hp('paytype_error',0), 'error');
                }
                $data['endts'] = 0;
                $data['paytype'] = serialize($mp_price[$paytype]);

                if($mp_price[$paytype]['price']>0){
                    $data['status'] = -2;
                    $mpid = C::t('#xigua_hp#xigua_hp_user')->insert($data, true);
                    $url = $_GET['backto'] ? $_GET['backto'] : "$SCRITPTNAME?id=xigua_hp&ac=my$urlext";
                    $data['mpid'] = $mpid;
                    $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $mp_price[$paytype]['price'], $_G['username'].lang_hp('mprz',0), 'com', array(
                        'data' => $data,
                        'callback' => array(
                            'file' => 'source/plugin/xigua_hp/function.php',
                            'method' => 'hp_join_callback'
                        ),
                        'location' => $_GET['backto'] ? $_GET['backto'] : $_G['siteurl'] . $url,
                    ));
                    C::t('#xigua_hp#xigua_hp_user')->update($mpid, array('order_id' => $order_id));

                    $rl = urlencode($url);
                    $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
                    hb_message(lang_hp('jumppay', 0), 'success', $jumpurl);
                }else{
                    $data['endts'] = TIMESTAMP + ($mp_price[$paytype]['type']*86400);
                    $data['status'] = $hp_config['mfshen'] ? -1 : 1;
                    $mpid = C::t('#xigua_hp#xigua_hp_user')->insert($data, true);
                    if($hp_config['mfshen']){
                        hppostx(lang_hp('new_need_shen',0), array('id'=>$mpid));
                    }else{
                        $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_hp&ac=view&mpid=$mpid".$urlext;
                        hppostx(lang_hp('new_in',0), array('url' => $url, 'id'=>$mpid));
                    }
                    hb_message(lang_hp('fabuok', 0), 'success', "$SCRITPTNAME?id=xigua_hp&ac=my$urlext");
                }
            }
        }else{
            $hyobj->init($hyobj->list_json());
            $jsary = $hyobj->get_tree_array(0);
            $jsary = array_values($jsary);
            $default_hy = diconv($jsary[0]['name'].' '. $jsary[0]['sub'][0]['name'], 'utf-8', CHARSET);
            if($_GET['hyid'] && !$_GET['edit']){
                $jsar = $jspr = array();
                $arr = $hyobj->arr;
                foreach ($arr as $index => $item) {
                    $jsar[$item['id']] = $item;
                    $jspr[$item['pid']] = $item;
                }
                if($_hy = $jsar[$_GET['hyid']]){
                    if($_hy['pid']){
                        $default_hy = diconv($jsar[$_hy['pid']]['name'].' '. $_hy['name'], 'utf-8', CHARSET);
                    }else{
                        $default_hy = diconv($_hy['name'].' '. $jspr[$_hy['id']]['name'], 'utf-8', CHARSET);
                    }
                }
            }
            $cityjson = json_encode($jsary);

            if($mpid){
                $vlist = C::t('#xigua_hp#xigua_hp_user')->fetch_all_by_where(array("uid={$_G['uid']} AND mpid=$mpid $stcon"),0, 1);
                $old_data = $vlist[0];
            }

            if($old_data['hy']){
                $default_hy = $old_data['hy'];
            }

            $user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
            $lastrealname = $user['realname'];
            $lastmobile   = $user['mobile'];
            if($_G['cache']['plugin']['xigua_hs']){
                $where = array();
                $where[] = 'uid='.$_G['uid'].' and display=1 and endts>='.TIMESTAMP;
                $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);

                $sh2 = array();
                $shids = DB::fetch_all('select shid from %t WHERE uid=%d', array('xigua_hs_yuan',$_G['uid']),'shid');
                if($shids){
                    $sh2 = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('shid in ('.implode(',', array_keys($shids)).')'));
                }

                $sh = array_merge($sh, $sh2);

                $dftshname = $sh[0]['name'];
                $dftshid = $sh[0]['shid'];
            }
            $mp_price = hp_parese_price($hp_config['mp_price']);
        }
        break;
    case 'my':
        hp_my();
        break;
    case 'delmy':
        if(submitcheck('formhash')){
            C::t('#xigua_hp#xigua_hp_user')->delete_by_where(array("mpid=$mpid",'uid='.$_G['uid'] ));
            hb_message(lang_hp('cancelsucceed',0), 'success', 'reload');
        }
        break;
    case 'getshinfo':
        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($_GET['shid']);
        hb_message(implode('<<>>', array(
            $sh['shid'], $sh['name'], $sh['hangye'], $sh['addr'],
            $sh['lat'], $sh['lng'], $sh['province'],
            $sh['city'],
            $sh['district'],
            $sh['street'],
            $sh['street_number'],
        )), 'success');
        break;
    case 'index':
        hp__index();

        $_key = 'hbIdist'.intval($_GET['st']);
        loadcache($_key);
        if(!$_G['cache'][$_key]['variable'] || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000) || defined('IN_ADMINCP')) {
            $dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
            $GLOBALS['nojson'] = 1;
            $list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
            C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
            $jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
            foreach ($dist0 as $index => $item) {
                C::t('#xigua_hb#xigua_hb_district')->empty_child();
                $dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
            }
            savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
        } else {
            $dist0 = $_G['cache'][$_key]['variable'][0];
            $jsary = $_G['cache'][$_key]['variable'][1];
        }

        if($_GET['city']){
            $distname = $_GET['city'];
        }
        if($_GET['dist']){
            $distname = $_GET['dist'];
        }
        if(!$navtitle && $distname){
            $navtitle = $distname;
        }
        if(!$distname){
            $distname = lang_hb('plugins_edit_vars_type_area',0);
        }

        $navtitle = $hp_config['indextitle'];
        $desc = $hp_config['indexdesc'];
        $indeximg = $hp_config['indeximg'];

        if($_GET['indexorder']){
            $hp_config['indexorder'] = $_GET['indexorder'];
        }
        if($_GET['keyword']){
            $navtitle =  lang_hp('mp_',0).lang_hp('ssjg',0).$_GET['keyword'];
        }
        $nomine = 1;
        $vlist = C::t('#xigua_hp#xigua_hp_user')->fetch_all_by_where(array("uid={$_G['uid']} $stcon"),0, 1);
        if($vlist){
            $nomine = 0;
        }
        break;
    case 'good_li':
        $manage = IS_ADMINID && $ac == 'manage';
        $field = '*';
        $where = array();
        $where[] = "status=1 $stcon";
        if($hyid = intval($_GET['hyid'])){
            $pids = array($hyid);
            if($hyinfo = $hyobj->get_childs_by_pids($hyid)){
                foreach ($hyinfo as $index => $item) {
                    $pids[] = intval($item['id']);
                }
                if($pids){
                    $where[] = ' hangye_id2 IN('.implode(',', $pids).') ';
                }
            }else{
                $where[] = ' hangye_id2 ='. $hyid;
            }
        }

        if($city = daddslashes($_GET['city'])){
            if($city!='-1'){
                $where[] = " (province='$city' OR  city='$city' OR district='$city' OR addr LIKE '%$city%') ";
            }
        }

        if($_GET['not']){
            $where[] = ' mpid !='. intval($_GET['not']);
        }

        if(is_numeric($_GET['keyword'])){
            $where[] = ' (uid ='. intval($_GET['keyword']) .') ';
        }elseif($keyword = stripsearchkey($_GET['keyword'])){
            $where[] = " (name LIKE '%$keyword%' OR addr LIKE '%$keyword%' OR wx LIKE '%$keyword%' OR zw LIKE '%$keyword%' OR wfz LIKE '%$keyword%' OR company LIKE '%$keyword%' OR bm LIKE '%$keyword%' OR shname LIKE '%$keyword%') ";
        }
        $needrank = 0;
        if($_GET['orderby']=='nearby'){
            $lat = floatval($_GET['lat']);
            $lng = floatval($_GET['lng']);
            $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
            $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
            $order_by = 'distance ASC';
        }elseif($_GET['orderby'] =='views'){
            $order_by = ' views DESC';
            $needrank= 1;
        }elseif($_GET['orderby'] =='zans'){
            $order_by = ' zans DESC';
            $needrank= 1;
        }elseif($_GET['orderby'] =='follow'){
            $order_by = ' follows DESC';
            $needrank= 1;
        }else{
            $order_by = ' displayorder DESC, mpid DESC';
        }

        $rankindex = $start_limit;

        if($_GET['follow']){
            $flids = array();

            $tmp = C::t('#xigua_hp#xigua_hp_shoucun')->fetch_by_pages($_G['uid'], $start_limit, $lpp, 'mpid');
            foreach ($tmp as $flid) {
                $flids[] = $flid['mpid'];
            }
            $where = array();
            if($flids){
                $where[] = "mpid IN ( ".implode(',', $flids).")";
            }else{
                $where[] = 'mpid=-1';
            }

            if(is_numeric($_GET['keyword'])){
                $where[] = ' (uid ='. intval($_GET['keyword']) .') ';
            }elseif($keyword = stripsearchkey($_GET['keyword'])){
                $where[] = " (name LIKE '%$keyword%' OR addr LIKE '%$keyword%' OR wx LIKE '%$keyword%' OR zw LIKE '%$keyword%' OR wfz LIKE '%$keyword%' OR company LIKE '%$keyword%' OR bm LIKE '%$keyword%' OR shname LIKE '%$keyword%') ";
            }
        }
        $list = C::t('#xigua_hp#xigua_hp_user')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);

        if($_GET['orderby']=='nearby'){
            foreach ($list as $k => $v) {
                $distance = intval($v['distance']);
                if($distance<=1000){
                    $distance = intval($distance). 'm';
                }else if($distance>1000){
                    $distance = round($distance/1000, 1). 'km';
                }
                $list[$k]['distance'] = $distance;
            }
        }
        if($hp_config['liebie']){
            $mpids = 0;
            foreach ($list as $k => $v) {
                $mpids .= ','.$v['mpid'];
            }
            C::t('#xigua_hp#xigua_hp_user')->incr($mpids, 'views');
        }

        include template('xigua_hb:header_ajax');
        include template('xigua_hp:'.$ac);
        include template('xigua_hb:footer_ajax');
        break;
    case 'view':
        $v = C::t('#xigua_hp#xigua_hp_user')->fetch($mpid);
        if(!$v){
            dheader("Location: $SCRITPTNAME?id=xigua_hp&mobile=2{$urlext}");
        }
        if($hp_config['yinsi']){
            if($_GET['z']==9){
                $v['openmobile'] = 1;
            }
        }
        C::t('#xigua_hp#xigua_hp_user')->incr($mpid, 'views');
        if($v['stid'] && !$_GET['st']){
            dheader("Location: $SCRITPTNAME?id=xigua_hp&ac=view&mpid={$v['mpid']}{$urlext}&st={$v['stid']}");
        }
        if($_G['uid']){
            $zans  = C::t('#xigua_hp#xigua_hp_zan')->fetch_by_uid($_G['uid'], $mpid);
            $shoucun = C::t('#xigua_hp#xigua_hp_shoucun')->fetch_by_uid($_G['uid'], $mpid);
        }
        $myname = $v['name'];
        if($_G['uid'] == $v['uid']){
            $myname = lang_hp('wode',0);;
        }
        $v['addr'] = $v['city'].$v['addr'];

        $navtitle = str_replace(array(
            '{name}', '{mobile}','{company}','{addr}','{wx}','{zw}','{wfz}','{bm}','{shname}'), array(
            $myname, $v['mobile'], $v['company'], $v['addr'], $v['wx'], $v['zw'], $v['wfz'], $v['bm'], $v['shname']), $hp_config['viewtitle']
        );
        $new_navtitle = $navtitle;
        $desc = str_replace(array(
            '{name}', '{mobile}','{company}','{addr}','{wx}','{zw}','{wfz}','{bm}','{shname}'), array(
            $myname, $v['mobile'], $v['company'], $v['addr'], $v['wx'], $v['zw'], $v['wfz'], $v['bm'], $v['shname']), $hp_config['viewdesc']
        );
        $indeximg = $hp_config['viewimg'];
        $kefulink = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=".$v['uid'];
        if ( (IN_MAGAPP||IN_QIANFAN)&&$hp_config['sxlink']){
            $shmember = getuserbyuid($v['uid']);
            $shavat = avatar($v['uid'], 'middle', true);
            $kefulink = str_replace(array('{uid}','{username}','{avatar}'), array($v['uid'], $shmember['username'], $shavat ), $hp_config['sxlink']);
        }
        if($_GET['view2'] || $hp_config['viewtpl']=='view2'){
            include template('xigua_hp:view2');
            exit;
        }
        break;
    case 'follow':
        $navtitle = lang_hp('wdmpj',0);
        $myfollow = 1;
        break;
    case 'mysh':
        if($_G['cache']['plugin']['xigua_hs']){
            $where = array();
            $where[] = 'uid='.$_G['uid'];
            $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
        }
        if(!$sh){
            dheader('Location:'.$SCRITPTNAME.'?id=xigua_hp&ac=none'.$urlext);
        }else{
            dheader('Location:'.$SCRITPTNAME.'?id=xigua_hs&ac=shcenter&mobile=2'.$urlext);
        }
        break;
    case 'none':
        break;
    default:
        if (is_file(DISCUZ_ROOT . "source/plugin/xigua_hp/include/c_$ac.php")) {
            include DISCUZ_ROOT . "source/plugin/xigua_hp/include/c_$ac.php";
        }
        break;
}

if($_GET['mini']=='11'){
    $navtitle = strip_tags($navtitle);
    $navtitle = $navtitle?$navtitle:$config['tname'];
    if($config['tnameshow']) {
        if ($navtitle != $config['tname']){
            $navtitle = $config['tname'] . $navtitle;
        }
    }
    ob_end_clean();
    function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
    header("Content-type: application/json; charset=utf-8");
    echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
    exit;
}
if(!checkmobile()){
    include template('xigua_hb:index');
    exit;
}
if (is_file(DISCUZ_ROOT . "source/plugin/xigua_hp/template/touch/$ac.php")) {
    include template('xigua_hp:' . $ac);
}