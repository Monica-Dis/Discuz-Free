<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$pluginid = 'xigua_guide';

$Hooks = array(
    'viewthread_variables',
);

$data = array();
foreach($Hooks as $Hook) {
    $data[] = array(
        $Hook => array(
            'plugin' => $pluginid,
            'include' => 'api.class.php',
            'class' => $pluginid,
            'method' => $Hook,
            'order' => 0,
        )
    );
}

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);

updateAPIHook($data);

function updateAPIHook($datas) {
    $apihook = WeChatHook::getAPIHook();
    foreach ($datas as $data) {
        foreach ($data as $key => $value) {
            if (!$value['plugin']) {
                continue;
            }
            list($module, $hookname) = explode('_', $key);
            if ($value['include'] && $value['class'] && $value['method']) {
                $v = $value;
                unset($v['plugin']);
                $v['allow'] = 1;
                $apihook[$module][$hookname][$value['plugin']] = $v;
                if($module == 'forumdisplay' && $hookname == 'headerBar'){

                    foreach ($apihook[$module][$hookname] as $hk => $hv) {
                        $apihook[$module][$hookname][$hk]['order'] = 99;
                    }

                    if(isset($apihook[$module][$hookname]['xigua_search'])) {
                        $apihook[$module][$hookname]['xigua_post']['order'] = 0;
                    }

                    $apihook[$module][$hookname]['xigua_guide']['order'] = 1;

                    if(isset($apihook[$module][$hookname]['xigua_search'])){
                        $apihook[$module][$hookname]['xigua_search']['order'] = 2;
                    }
                    if(isset($apihook[$module][$hookname]['xigua_sign'])){
                        $apihook[$module][$hookname]['xigua_sign']['order'] = 3;
                    }
                    if(isset($apihook[$module][$hookname]['xigua_navigation_wsq'])){
                        $apihook[$module][$hookname]['xigua_navigation_wsq']['order'] = 4;
                    }

                    uasort($apihook[$module][$hookname], 'pluginorderapicmp');
                }

            } else {
                unset($apihook[$module][$hookname][$value['plugin']]);
            }
        }
    }

    $settings = array('mobileapihook' => serialize($apihook));
    C::t('common_setting')->update_batch($settings);
    updatecache('setting');
    return $apihook;
}

function pluginorderapicmp($a, $b) {
    return $a['order'] > $b['order'] ? 1 : -1;
}


$finish = TRUE;


@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/install.php');