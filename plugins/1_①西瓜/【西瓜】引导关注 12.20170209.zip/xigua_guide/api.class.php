<?php
/**
*      Copyright 2001-2099 DisM!Ӧ������.
*      This is NOT a freeware, use is subject to license terms
*
*      $Id: install.php 34718 2014-07-14 08:56:39Z nemohou $
*/

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class xigua_guide
{
    public function __construct()
    {

    }

    public function viewthread_variables(& $params)
    {
        global $_G;

        foreach ($params['postlist'] as $index => $item) {
            if($item['first']){
                $params['postlist'][ $index ]['message'] .= "<script>$.get('{$_G['siteurl']}plugin.php?id=xigua_guide:api&isuse=1', function(data) {  $('body').append(data);});</script >";
                break;
            }
        }
        return true;
    }
}