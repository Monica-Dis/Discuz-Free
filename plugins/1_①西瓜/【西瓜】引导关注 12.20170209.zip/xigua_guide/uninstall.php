<?php

/**
 *      Copyright 2001-2099 DisM!Ӧ������.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$pluginid = 'xigua_guide';

require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::delAPIHook($pluginid);



@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/discuz_plugin_'.$pluginid.'_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/uninstall.php');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/api.class.php');
@unlink(DISCUZ_ROOT . './source/plugin/'.$pluginid.'/mobile.class.php');

$finish = TRUE;