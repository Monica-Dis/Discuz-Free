<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 15/9/5
 * Time: 11:18
 *
 *  include_once DISCUZ_ROOT.'source/plugin/xigua_guide/mobile.class.php';
 *  echo mobileplugin_xigua_guide::global_footer_mobile();
 */
if (!defined('IN_DISCUZ')) {
    exit ('Access Denied');
}
class mobileplugin_xigua_guide
{
    public static function global_footer_mobile($onlywx = '')
    {
        global $_G;

        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_guide'];
        $wechat = unserialize($_G['setting']['mobilewechat']);

        if($config['logined']){
            if($_G['uid']>0){
                return '';
            }
        }
        if($_GET['from'] == 'album'){
            return '';
        }
        if($config['inthread']&& $_GET['mod']!='viewthread'){
            return '';
        }

        $cookie__ = 'disguide';
        $ttl = intval($config['ttl']);
        if(getcookie($cookie__)){
            return '';
        }

        $link = $config['link'] ? $config['link'] : 'javascript:;';

        $btnbgcolor = $config['btnbgcolor'] ? $config['btnbgcolor'] : '#0084FF';
        $btnborderradius = $config['borderradius'];
        $btnword = $config['btnword'];

        $logo = $config['logo'] ? $config['logo'] : $wechat['wsq_sitelogo'];
        $logoradius = intval($config['logoradius']);
        $opacity = $config['opacity'] ? ($config['opacity']/100) : 1;
        $bgcolor = $config['bgcolor'] ? $config['bgcolor'] : '#F5F5FA';
        $pos = $config['pos'] == 1 ? 'top:0;' : 'bottom:0;';
        $closebtnsrc = (strpos($config['closebtnsrc'], 'http://') !== false) ? $config['closebtnsrc'] : $_G['siteurl'].$config['closebtnsrc'];
        $mainwordc = $config['mainwordc'] ? $config['mainwordc'] : '#9596AB';
        $subwordc = $config['subwordc'] ? $config['subwordc'] : '#B5B5C4';

        $config['px'] = intval($config['px']);
        if($config['pos'] == 1){
            $pos = "top:".$config['px']."px;";
            $trans = "-webkit-transform: translateY(-100%);transform: translateY(-100%);";
            $extcss = "body{padding-top:50px!important}";
        }else{
            $trans = "-webkit-transform: translateY(100%);transform: translateY(100%);";
            $pos = "bottom:".$config['px']."px;";
        }

        $bgcolor = self::hex2rgb($bgcolor, $opacity);

        /*new*/
        $cont = array();
        $config['cont'] = trim($config['cont']);
        if($tmp = array_filter(explode("\n", $config['cont']))){
            foreach ($tmp as $index => $item) {
                $cont[$index] = explode(',', trim($item));
            }
        }



        $html = '';
        include template('xigua_guide:guide');
        return $html;

    }




    public static function hex2rgb($colour, $a)
    {
        if ($colour[0] == '#') {
            $colour = substr($colour, 1);
        }
        if (strlen($colour) == 6) {
            list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
        }
        elseif (strlen($colour) == 3) {
            list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
        }
        else {
            return false;
        }
        $r = hexdec($r);
        $g = hexdec($g);
        $b = hexdec($b);
//        return array('r' => $r, 'g' => $g, 'b' => $b);
        return "rgba($r, $g, $b, $a)";
    }
}