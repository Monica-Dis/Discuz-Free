<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_sp/function.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_sp/SDK/examples/get_print_status.php';
$jpurl ="action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_od&keyword=$keyword&note={$_GET[note]}&page=".$_GET['page'];
$table = DB::table('xigua_hb_order');

if(submitcheck('printid', 1)){
    $order_id = $_GET['printid'];
    include_once DISCUZ_ROOT.'source/plugin/xigua_sp/print.php';
    print_sp_piao($order_id, 1);
}
if(submitcheck('editixianid')){
    $order_id = $_GET['editixianid'];
    $allorder = DB::fetch_all('SELECT id,order_id,fa_ts FROM %t WHERE order_id=%s', array('xigua_sp_order', $order_id));
    foreach ($allorder as $index => $item) {
        if($_GET['yundan_gs'] && $_GET['yundan']){
            DB::update('xigua_sp_order', array(
                'fa_ts' => TIMESTAMP,
                'yundan_gs' => $_GET['yundan_gs'],
                'yundan' => $_GET['yundan'],
            ), array(
                'id' => $item['id']
            ));
        }
    }
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_od&page=$page&lpp=$lpp", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey(addslashes($_GET['keyword']));
if($_GET['province'] && is_numeric($_GET['province'])){
    $_GET['pid'] =$_GET['province'];
    $_GET['province'] = 'province';
}
if($_GET['city'] && is_numeric($_GET['city'])){
    $_GET['cid'] =$_GET['city'];
    $_GET['city'] = 'city';
}
if($_GET['district'] && is_numeric($_GET['district'])){
    $_GET['did'] =$_GET['district'];
    $_GET['district'] = 'district';
}
if($keyword) {
    $uids = DB::fetch_all("select uid from " . DB::table('common_member') . " where username like '%$keyword%' ", array(), 'uid');
    if ($uids) {
        $wherearr[] = " ( $table.fromuid in (" . implode(',', array_keys($uids)) . ") OR ( $table.fromuid='$keyword' OR  $table.order_id LIKE '%$keyword%' OR $table.order_sn LIKE '%$keyword%' OR $table.subject LIKE '%$keyword%' OR $table.info LIKE '%$keyword%' ) ) ";
    } else {
        $wherearr[] = " ( $table.fromuid='$keyword' OR $table.order_id LIKE '%$keyword%' OR $table.order_sn LIKE '%$keyword%' OR $table.subject LIKE '%$keyword%' OR $table.info LIKE '%$keyword%' ) ";
    }
}

$wherearr[] = $table.'.note=\'common_sp\'';

if($_G['cache']['plugin']['xigua_st']){
    $areas = array();
    $values = array(intval($_GET['pid']), intval($_GET['cid']), intval($_GET['did']));
    $elems = array($_GET['province'], $_GET['city'], $_GET['district']);
    $level = 1;
    $upids = array(0);
    $theid = 0;
    for($i=0;$i<3;$i++) {
        if(!empty($values[$i])) {
            $theid = intval($values[$i]);
            $upids[] = $theid;
            $level++;
        } else {
            for($j=$i; $j<3; $j++) {
                $values[$j] = '';
            }
            break;
        }
    }
    $options = array(1=>array(), 2=>array(), 3=>array());
    $thevalues = array();
    foreach(C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($upids) as $value) {
        $options[$value['level']][] = array($value['id'], $value['name']);
        if($value['upid'] == $theid) {
            $thevalues[] = array($value['id'], $value['name'], $value['displayorder'], $value['usetype'], $value['link']);
        }
    }

    $names = array('province', 'city', 'district');
    for($i=0; $i<3;$i++) {
        $elems[$i] = /*!empty($elems[$i]) ? $elems[$i] :*/ $names[$i];
    }
    $html = '';
    for($i=0;$i<3;$i++) {
        $l = $i+1;
        $jscall = ($i == 0 ? 'this.form.city.value=\'\';this.form.district.value=\'\';' : '')."refreshdistrict('$elems[0]', '$elems[1]', '$elems[2]')";
        $html .= '<select name="'.$elems[$i].'" id="'.$elems[$i].'" onchange="'.$jscall.'">';
        $html .= '<option value="">'.lang('spacecp', 'district_level_'.$l).'</option>';
        foreach($options[$l] as $option) {
            $selected = $option[0] == $values[$i] ? ' selected="selected"' : '';
            if($selected){
                $areas[] =$option[1];
            }
            $html .= '<option value="'.$option[0].'"'.$selected.'>'.$option[1].'</option>';
        }
        $html .= '</select>&nbsp;&nbsp;';
    }
    if($areas){
        if ($areas[2] && $areas[1] && $areas[0]){
            $sts = DB::fetch_all("select stid from %t WHERE area1=%s AND area2=%s AND area3=%s  AND status=1", array('xigua_st', $areas[0], $areas[1], $areas[2]), 'stid');
        }elseif(!$areas[2] && !$areas[1] && $areas[0]){
            $sts = DB::fetch_all("select stid from %t WHERE area1=%s AND status=1", array('xigua_st', $areas[0]), 'stid');
        }elseif (!$areas[2] && $areas[1] && $areas[0]){
            $sts = DB::fetch_all("select stid from %t WHERE area1=%s AND area2=%s AND status=1", array('xigua_st', $areas[0], $areas[1]), 'stid');
        }
        if(!$sts){
            $sts = array('-2'=> '-2');
        }
        $wherearr[] = " ($table.stid IN (" . implode(',', array_keys($sts)) . ') ) ';
    }
}
if($_GET['starttime1'] && $_GET['starttime2']){
    $stime1 = intval(strtotime($_GET['starttime1']));
    $stime2 = intval(strtotime($_GET['starttime2']));

    $wherearr[] = " ($table.payupts BETWEEN $stime1 AND $stime2 ) ";
}elseif ($_GET['starttime1'] ){
    $stime1 = intval(strtotime($_GET['starttime1']));
    $wherearr[] = " ($table.payupts >= $stime1 ) ";
}elseif ($_GET['starttime2'] ){
    $stime2 = intval(strtotime($_GET['starttime2']));
    $wherearr[] = " ($table.payupts <= $stime2 ) ";
}

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_od&keyword=$keyword&note={$_GET[note]}&page=".$_GET['page']);

$page = max(1, intval($_GET['page']));
$lpp   = 10;
$start_limit = ($page - 1) * $lpp;
$total_price = 0;

$wherearr[] = "( $table.paystatus=1 OR ($table.paystatus!=1 AND $table.qforder_id!='') )";
$wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
$res = DB::fetch_all('SELECT * FROM ' . DB::table('xigua_hb_order') . " $wheresql ORDER BY order_id DESC " . DB::limit($start_limit, $lpp));

$icount = C::t('#xigua_hb#xigua_hb_order')->fetch_count_bypage($wherearr);

$stids = array();
foreach ($res as $v) {
    if($v['fromuid']){
        $uids[$v['fromuid']] = $v['fromuid'];
    }
    if($v['stid']){
        $stids[$v['stid']] = $v['stid'];
    }
    $total_price += $v['baseprice'];
}

$today = C::t('#xigua_hb#xigua_hb_order')->fetch_sum_paid_bytime($wherearr, strtotime(date('Y-m-d')));
$all = C::t('#xigua_hb#xigua_hb_order')->fetch_sum_paid_bytime($wherearr, 1);

$querencount = null;

$wheresql = !empty($wherearr) && is_array($wherearr) ? ' '.implode(' AND ', $wherearr) : '1';
//$querencount = DB::result_first("SELECT SUM(baseprice) AS m from %t, %t AS third WHERE $table.order_id=third.order_id AND (third.hxcrts>0||third.shou_ts>0) AND $wheresql" , array('xigua_hb_order','xigua_sp_order'));

if($_G['cache']['plugin']['xigua_st']) {
    $allsts = DB::fetch_all('SELECT stid,`name`,name2,uid FROM %t WHERE 1', array('xigua_st'), 'stid');
    foreach ($allsts as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
    }
    $allsts[0] = array(
        'stid' => 0,
        'name' => lang('plugin/xigua_st', 'zz'),
        'name2' => lang('plugin/xigua_st', 'zz'),
    );
    asort($allsts);
    $sel1 = '<option value="-1" ' . ($_GET['sttt'] == -1 ? 'selected' : '') . '>' . lang_hb('quanbu', 0) . '</option>';
    foreach ($allsts as $index => $item) {
        $item = $item['name'];
        if ($_GET['sttt'] == $index) {
            $sel1 .= "<option value=\"$index\" selected>$item</option>";
        } else {
            $sel1 .= "<option value=\"$index\">$item</option>";
        }
    }

    if(count($sts)==1){
        $st111 = array_values(array_keys($sts));
        $stinfo = C::t('#xigua_st#xigua_st')->fetch($st111[0]);
        $ratio = $stinfo['ratio']/100;
        $siteticheng = round($all * $ratio, 2);
    }

}

echo '<div style="margin-top:3px"><input type="text" id="keyword" name="keyword" placeholder="'.lang('plugin/xigua_hb','searcho').'" value="'.$_GET['keyword'].'" class="txt" style="width:220px" />';
echo ' <input type="hidden" class="btn" name="page" value="1" />';
if($sel1){
    echo '  '.lang_hb('zddq',0).' &nbsp; '.$html;
}
$q1 = lang_hb('qssj',0);
$q2 = lang_hb('jssj',0);

echo  <<<HTML
$q1: <input type="text" id="starttime1" name="starttime1" placeholder="2011-01-01 00:00" value="{$_GET['starttime1']}" onclick="showcalendar(event, this, true)" class="txt" />
$q2: <input type="text" id="starttime2" name="starttime2" placeholder="2037-01-01 23:59" value="{$_GET['starttime2']}" onclick="showcalendar(event, this, true)" class="txt" />
HTML;

echo ' <input type="submit" class="btn" value="'.cplang('search').'" /><br>';
echo " <span> ".lang_hb('curtongji', 0)."<b style='color:red'>&yen;$total_price</b></span>";
echo "&nbsp;&nbsp;<span> ".lang_hb('jrddje', 0).": <b style='color:red'>&yen;$today</b></span>";
echo "&nbsp;&nbsp;<span> ".lang_hb('ddsl', 0).": <b style='color:red'>$icount</b></span>";
echo "&nbsp;&nbsp;<span> ".lang_hb('ddzje', 0).": <b style='color:red'>&yen;$all</b></span>";
if(count($sts)==1){
    echo "&nbsp;&nbsp;<span> ".lang_hb('fztc', 0).": <b style='color:red'>&yen;$siteticheng</b></span>";
}
if($querencount!==null){
    echo "&nbsp;&nbsp;<span> ".lang_hb('yqrshje', 0).": <b style='color:red'>&yen;$querencount</b></span>";
}
echo '</div>';

if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}
showtableheader(lang('plugin/xigua_hb','orderinfo'));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_hb','del'),
    lang('plugin/xigua_hb','stid').'<br>'.lang('plugin/xigua_hb','fzzz'),
    lang('plugin/xigua_hb','orderid'),
    lang('plugin/xigua_hb','gmyh'),
    lang('plugin/xigua_hb','note'),
    lang('plugin/xigua_hb','orderprice'),
    lang('plugin/xigua_hb','status'),
    lang('plugin/xigua_hb', 'method'),
    lang('plugin/xigua_hb','crts').'/'.lang('plugin/xigua_hb','upts'),
    lang('plugin/xigua_sp', 'xiaopiao'),
));

$l_status = lang_sp('status', 0);
$l_bianhao = lang_sp('bianhao', 0);
$l_shijian = lang_sp('shijian', 0);
foreach ($res as $re) {
    $st = $allsts[$re['stid']];
    $resite = $st['name'].'[ID : '.$re['stid'].' ]';
    $order_id = $re['order_id'];
    if($re['pubid']>0){
        $order_id = "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_pub&pubid={$re['pubid']}'>$order_id</a>";
    }
    $reinfo = unserialize($re['info']);
    $hsinfo = DB::fetch_first('select name,shid from %t where shid=%d', array('xigua_hs_shanghu', $reinfo['data']['shid']));

    $paymethod = '';
    $paymethods = array(
        table_xigua_hb_order::ALIPAY => '<span style="color:#51b7ec">'.lang_hb('alipay', 0).'</span>',
        table_xigua_hb_order::WXPAY => '<span style="color:#1AAD19">'.lang_hb('wxpay', 0).'</span>',
        'APP' => 'APP',
        'YUE' => lang_hb('yue',0)
    );
    $paymethod = $paymethods[$re['paymethod']] ? $paymethods[$re['paymethod']] : $re['paymethod'];

    $reinfo = unserialize($re['info']);
    if(!$shid = $reinfo['data']['shid']){
        $tmp = array_values($reinfo['data']);
        $shid = $tmp[0]['shid'];
    }
    $hs_info = DB::fetch_first('select appid, appkey, device_id, device_secret,shid,name from %t where shid=%d', array('xigua_hs_shanghu', $shid));

    if($re['piao']){
        if($hs_info['appid']){
            $PIAOTS = date('Y-m-d H:i:s', $re['piao_ts']);
            $statusp = get_print_status($hs_info['appid'],$hs_info['appkey'],$hs_info['device_id'],$hs_info['device_secret'], $re['piao']);
            $statusp = $statusp==1?lang_sp('yidayin',0):lang_sp('weidayin',0);
            $piaostatus = <<<HTML
$l_status: $statusp<br>
$l_bianhao: {$re['piao']}<br>
$l_shijian: $PIAOTS
HTML;
        }
    }else{
        $href = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_od&page=".$_GET['page'].'&formhash='.FORMHASH.'&printid='.$re['order_id'];
        $piaostatus = "<a href=\"$href\">".lang('plugin/xigua_sp', 'dyxp')."</a>";
    }

    $allorder = DB::fetch_all('SELECT id,order_id,fa_ts FROM %t WHERE order_id=%s', array('xigua_sp_order', $order_id));
    if($allorder[0]['fa_ts']>0){
        $fastatus = '<br>';
        $fastatus.= lang_sp('fh',0).': '.date('Y-m-d H:i:s', $allorder[0]['fa_ts']);
    }else{
        $fastatus = '<br>';
        $fastatus.= '<a href="javascript:;" onclick="_conrim_fh(\''.$re['order_id'].'\', \''.$re['subject'].'\');">'.lang_sp('yjfh',0).'</a>';
    }

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='{$re['order_id']}' />",
        $resite.'<br>'.
        ($st['uid'] ? (/*'UID : '.$st['uid']."<br>".*/$users[$st['uid']]['username']) : ''),

        lang('plugin/xigua_hb','orderid').':'.$order_id.'<br>'.lang('plugin/xigua_hb', 'ordersn').': '. ($re['order_sn']? $re['order_sn'] : '-'),

        '[UID : '.$re['fromuid']." ]<br>".$users[$re['fromuid']]['username'] .(
        $re['credit_num']>0?(
            '<br><strong style="color:forestgreen;">'.lang_hb('jfsl',0).': '.$re['credit_num'].$_G['setting']['extcredits'][$re['credit_type']]['unit'].$_G['setting']['extcredits'][$re['credit_type']]['title'].'</strong>'
        ):''
        ),
        "<div style='width:200px'>".$hs_info['name'].'[ ID :'.$hs_info['shid'].' ]'."<br>{$re['subject']}</div>",
        $re['baseprice'],
        $re['paystatus'] ? '<strong style="color:forestgreen;">'.(lang('plugin/xigua_hb','yi')) .'</strong>' : '<strong style="color:orangered;">'.(lang('plugin/xigua_hb','wei')) .'</strong>',
        $paymethod,
        date('m-d H:i:s', $re['crts']).'<br>'.
        ($re['payupts'] ? date('m-d H:i:s', $re['payupts']) : '-'),
        $piaostatus.$fastatus,
    ));
}
unset($_GET['formhash']);
unset($_GET['page']);
$httpbuild = http_build_query($_GET);
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_od&$httpbuild&keyword=$keyword&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '',$multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*Dism_taobao-com*/
$adminurl = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_od&$httpbuild&keyword=$keyword&lpp=$lpp";
?>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script>
    function refreshdistrict(province, city, district) {
        location.href = "<?php echo $adminurl;?>"
            + "&province="+province+"&city="+city+"&district="+district
            +"&pid="+$(province).value + "&cid="+$(city).value+"&did="+$(district).value;
    }
    function _conrim_fh(id,s) {
        showMenu({'ctrlid': 'rsel', 'evt': 'click', 'duration': 3, 'pos': '00'});
        $('txid').value = id;
        $('cnotr').innerHTML = '<?php lang_sp('yjfh',1)?>:'+s;
    }
</script>
<div id="rsel_menu" class="custom cmain" style="display:none;width:450px;height:200px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr"></h3>
    </div>
    <div id="rsel_content" style="overflow-y:auto;height:95%">
        <?php showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_od&page=$page"); ?>
        <table class="tb tb2 ">
            <tr class="hover">
                <td align="left"><?php lang_sp('kdgs', 1)?></td>
                <td><input  name="yundan_gs" value="" /> </td>
            </tr>
            <tr class="hover">
                <td align="left"><?php lang_sp('kddh', 1)?></td>
                <td><input  name="yundan" value="" /> </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="editixianid" id="txid" value="0">
                    <input type="submit" class="btn" name="editsubmit" value="<?php lang_hb('tijiao');?>" />
                </td>
            </tr>
        </table>
        <?php showformfooter(); /*Dism_taobao-com*/?>
    </div>
</div>