<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
DROP TABLE pre_xigua_sp_good;
DROP TABLE pre_xigua_sp_card;
DROP TABLE pre_xigua_sp_good_price;
DROP TABLE pre_xigua_sp_gwc;
DROP TABLE pre_xigua_sp_hangye;
DROP TABLE pre_xigua_sp_index;
DROP TABLE pre_xigua_sp_order;
EOT;
runquery($sql);

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/install.php');

xwb_delall(DISCUZ_ROOT . "./source/plugin/xigua_sp");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_sp");


function xwb_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwb_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}