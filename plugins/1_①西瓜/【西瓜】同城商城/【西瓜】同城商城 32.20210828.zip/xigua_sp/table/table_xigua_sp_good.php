<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_sp_good extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_sp_good';
        $this->_pk = 'id';

        parent::__construct();
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false)
    {
        if(!$data['stid']&&$GLOBALS['sh']['stid']){
            $data['stid'] = $GLOBALS['sh']['stid'];
        }
        $r = parent::insert($data, $return_insert_id, $replace, $silent);
        return $r;
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        if(!$data['stid']&&$GLOBALS['sh']['stid']){
            $data['stid'] = $GLOBALS['sh']['stid'];
        }
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }

    public function fetchs($ids){
        if(!$ids){
            return array();
        }
        $r = $this->fetch_all_by_where(array(" id in ( ".implode(',', $ids)." )"), 0, count($ids), '', '*', 'id');
        return $r;
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first('select * from %t WHERE id=%d AND uid=%d', array(
            $this->_table,
             $id,
             $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*', $keyfield = '', $ex = '')
    {
        global $sp_config,$_G;
        if(!$sp_config){
            $sp_config = $_G['cache']['plugin']['xigua_sp'];
        }
        if($sp_config['allowfz'] && is_array($wherearr) && !defined('IN_ADMINCP')){
            $wherearr[] = 'stid='.intval($_GET['st']);
            global $_G;
            if(!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']){
                array_pop($wherearr);
            }
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            if($orderby=='id desc'){
                $orderby = 'displayorder desc,id desc';
            }
            $orderby = "ORDER BY $orderby";
        }

        if($keyfield){
            $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp), array(), $keyfield);
        }else{
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        }
        $gids = array();
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $gids[] = $item['id'];
        }
        if($_GET['shid']){
            if($gids){
                $presult = DB::fetch_all("SELECT * FROM " . DB::table('xigua_sp_good_price') . " where gid in(%n) GROUP BY gid ORDER BY id ASC", array($gids), 'gid');
                foreach ($result as $index => $item) {
                    $result[$index]['gprice'] = $presult[$item['id']];
                }
            }
        }
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_by_gid($gid, $with= 1)
    {
        $gid = intval($gid);
        $ret = $this->fetch($gid);
        $ret = self::prepare($ret);

        if($_GET['ac']=='buy'){
            unset($ret['append_img_ary']);
            unset($ret['append_text_ary']);
            unset($ret['append_img']);
            unset($ret['append_text']);
            unset($ret['jieshao']);
            $with = 0;
        }

        if($with){
            $ret['price_list'] = C::t('#xigua_sp#xigua_sp_good_price')->fetch_all_by_where(array("gid=".$gid), 0, 9999, '', '*');

            $price_dm_min = $price_pt_min = 999999;
            $price_sc_max = $price_dm_max =  $price_pt_max = 0.01;
            foreach ($ret['price_list'] as $key => $val) {
                $price_pt_min = min($price_pt_min, $val['price_dm']);
                $price_pt_max = max($price_pt_max, $val['price_dm']);
                $price_dm_min = min($price_dm_min, $val['price_dm']);
                $price_dm_max = max($price_dm_max, $val['price_dm']);
                $price_sc_max = max($price_sc_max, $val['price_sc']);
                $ret['price_list'][$key]['name'] = diconv($ret['price_list'][$key]['name'], CHARSET, 'UTF-8');
                $ret['price_list'][$key]['price_jf_str'] = diconv($ret['price_list'][$key]['price_jf_str'], CHARSET, 'UTF-8');
            }

            $price_pt_min = floatval($price_pt_min);
            $price_pt_max = floatval($price_pt_max);
            $price_dm_min = floatval($price_dm_min);
            $price_dm_max = floatval($price_dm_max);
            $price_sc_max = floatval($price_sc_max);

            $ret['price_pt_min'] = $price_pt_min;
            $ret['price_pt_max'] = $price_pt_max;
            if($price_pt_min == $price_pt_max){
                $ret['price_pt'] = $price_pt_max;
            }else{
                $ret['price_pt'] = $price_pt_min.'-'.$price_pt_max;
            }

            $ret['price_dm_min'] = $price_dm_min;
            $ret['price_dm_max'] = $price_dm_max;
            if($price_pt_min == $price_dm_max){
                $ret['price_dm'] = $price_dm_max;
            }else{
                $ret['price_dm'] = $price_dm_min.'-'.$price_dm_max;
                $ret['price_pt'] = $price_pt_min.'-'.$price_dm_max;
            }

            $ret['price_sc_max'] = $price_sc_max;
        }
        if($_GET['ac']=='buy'){
            global $_G;
            if($ret['groupid'] && !in_array($_G['groupid'], explode(',', $ret['groupid']))){
                hb_message(lang('plugin/xigua_hs', 'no_access'), 'error');
            }
        }
        return $ret;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        global $_G, $config;
        if($v){
            $v['append_img_ary'] = unserialize($v['append_img']);
            $v['append_text_ary'] = unserialize($v['append_text']);
            $v['jtt_ary'] = unserialize($v['jtt']);
            $v['spgg_ary'] = unserialize($v['spgg']);
            $v['album'] = unserialize($v['album']);
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['usetime_u'] = $v['usetime'] ? date('Y-m-d H:i', $v['usetime']) : '';
            $v['srange_ary'] = array_filter(explode("\t", trim($v['srange'])));
            $v['srange2_ary'] = array_filter(explode("\t", trim($v['srange2'])));
            $v['tprice'] = floatval($v['dprice']);
            $v['disprice'] = floatval($v['disprice']);
            if($v['baoyou_num']>0){
                $v['baoyou_num'] = floatval($v['baoyou_num']);
            }
            if($v['tprice']>0 && $v['jifenrate']>0) {
                $dimoney = floatval($v['tprice'] * $v['jifenrate'] / 100);
                $credi_title = $_G['setting']['extcredits'][$config['credit_type']]['title'];
                $crate = explode(':', $config['fkxjb']);
                if ($credi_title && $crate[0] > 0 && $crate[1] > 0){
                    $cnum = intval($dimoney / $crate[1] * $crate[0]);
                    if ($cnum > 0) {
                        $v['jifenprice'] = "{$cnum}{$credi_title}". lang('plugin/xigua_sp', 'd') . $dimoney . lang_hb('yuan', 0);
                        $v['shortjifenprice'] = "{$cnum}{$credi_title}";
                    }
                }
            }
            if($v['newjifenprice']>0){
                $credi_title = $_G['setting']['extcredits'][$config['credit_type']]['title'];
                $v['newjifenprice_str'] = "{$v['newjifenprice']}{$credi_title}";
            }
        }
        return $v;
    }

    public function count_by_shid($shid)
    {
        $result = DB::result_first('SELECT  count(*) as c FROM %t WHERE shid=%d AND stat=1', array(
            $this->_table,
            $shid
        ));
        return $result;
    }


    public function fetch_comment_by_gid($shid, $gid, $start_limit = 0, $lpp = 10)
    {
        $shid = intval($shid);
        $result = DB::fetch_all("SELECT * FROM %t WHERE shid=%d AND gid=%d ORDER BY cid DESC " . DB::limit($start_limit, $lpp), array(
            'xigua_hb_comment',
            $shid,
            $gid
        ));
        foreach ($result as $index => $item) {
            $result[$index]['crts'] = dgmdate($item['crts'], 'u');
        }
        return $result;
    }

    public function comment_add($authorid, $touid, $pubid, $comment, $pubuid, $shid = 0, $star = 5, $imglist = array(), $type = 0, $gid = 0)
    {
        $author = getuserbyuid($authorid);
        $touser = $touid ? getuserbyuid($touid) : array();

        return DB::insert('xigua_hb_comment', array(
            'authorid' => intval($authorid),
            'author'   => $author['username'],
            'touid'    => intval($touid),
            'touser'   => $touser['username'],
            'comment'  => $comment,
            'pubid'    => $pubid,
            'crts'     => TIMESTAMP,
            'pubuid'   => $pubuid,
            'shid'     => $shid,
            'star'     => $star,
            'imglist'  => serialize($imglist),
            'type'  => intval($type),
            'new' => $type?1:0,
            'gid' => $gid,
        ), true);
    }

    public function fetch_commnt_avg($gid)
    {
       $ret = DB::result_first("select avg(star) as star1 from %t WHERE gid=%d" , array('xigua_hb_comment', $gid));
        return $ret>0 ? round($ret, 1) : 100;
    }
    public function fetch_commnt_avg_shid($shid)
    {
       $ret = DB::result_first("select avg(star) as star1 from %t WHERE shid=%d AND gid>0" , array('xigua_hb_comment', $shid));
       return $ret>0 ? round($ret, 1) : 100;
    }
}