<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2015/11/3
 * Time: 15:09
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_sp_refund extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_sp_refund';
        $this->_pk = 'id';

        parent::__construct();
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if(!$orderby){
            $orderby = " {$this->_pk} DESC ";
        }
        $orderby = "ORDER BY $orderby";
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function prepare($v)
    {
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i:s', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i:s', $v['upts']) : '';
        }
        return $v;
    }

    public function delete_G($id)
    {
        global $_G;
        return DB::delete($this->_table, array(
            'uid' => $_G['uid'],
            $this->_pk  => $id,
        ));
    }

    public function fetch_by_ptlogid($ptlogid)
    {
        $r = DB::fetch_first("select * from %t where ptlogid=%d", array($this->_table, $ptlogid));
        return $this->prepare($r);
    }

    public function fetch_by_id($ptlogid)
    {
        $r = DB::fetch_first("select * from %t where {$this->_pk}=%d", array($this->_table, $ptlogid));
        return $this->prepare($r);
    }
}