<?php
/*
 *DisM!Ӧ�����ģ�dism.taobao.com
 *������ҵ���/ģ������ ����DisM!Ӧ������
 *����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 *����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_sp_gwc extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_sp_gwc';
        $this->_pk = 'id';

        parent::__construct();
    }

    public function delete_G($id)
    {
        global $_G;
        return DB::delete($this->_table, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }

    public function delete_by_priceid($price_id)
    {
        global $_G;
        if($price_id){
            return DB::delete($this->_table, array(
                'price_id'  => $price_id,
            ));
        }elseif($_G['uid']){
            return DB::delete($this->_table, array(
                'uid' => $_G['uid'],
            ));
        }
        return false;
    }

    public function input_gwc($data)
    {
        $old = $this->fetch_all_by_array(array(
            'gid' => $data['gid'],
            'uid' => $data['uid'],
            'price_id' => $data['price_id'],
        ));
        $old = $old[0];
        if($old){
            $num = $data['num'] + $old['num'];
            $this->update($old['id'], array(
                'num' => $num,
                'upts' => TIMESTAMP
            ));
        }else{
            $this->insert($data);
        }
        return true;
    }

    public function get_gwc_count($uid)
    {
        return DB::result_first('SELECT sum(num) as c FROM %t WHERE uid=%d ', array($this->_table, $uid));
    }

    public function get_gwc_list($uid)
    {
        return $this->fetch_all_by_array(array(
            'uid' => $uid
        ));
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 999, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 9999, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }


    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
        }
        return $v;
    }

}