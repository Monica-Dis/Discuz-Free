<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2016/9/30
 * Time: 9:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$t =lang('plugin/xigua_hb','fangwen'). $_G['siteurl'].'plugin.php?id=xigua_sp&mobile=2<br><p>'.lang('plugin/xigua_hb','jiaocheng').'https://www.wxigua.com/forum.php?mod=viewthread&tid=4320</p>';
cpmsg($t, '','succeed');