<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{eval
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_common.php';
if($config['mustlogin'] && !$_G[uid]):
    hb_check_login();
endif;
$desc = strip_tags($desc);
$description = strip_tags($description);
$navtitle = strip_tags($navtitle);
$navtitle = $navtitle?$navtitle:$config[tname];
if($config[tnameshow]):
    if($navtitle!=$config[tname]):
        $navtitle = "$navtitle - $config[tname]";
    endif;
endif;
if(is_file("$stpath/hook2.php")):
    include_once "$stpath/hook2.php";
endif;
$CMAPP = false;
$INAPP = 0;
if($_G['cache']['plugin']['xigua_st']):
    if($_GET['st']<1):
        $stinfo['name'] = $_G['cache']['plugin']['xigua_st']['zongname'];
    endif;
    $navtitle = str_replace('tname', $stinfo['name'], $navtitle);
    $desc     = str_replace('tname', $stinfo['name'], $desc ? $desc : $description);
endif;
$c06 = hb_hex2rgb($config['maincolor'], .06);
if(!$hb_setting):
$cache_key = 'hb_ext_setting';
loadcache($cache_key);
$hb_setting = $_G['cache'][$cache_key];
endif;
}-->
<!doctype html>
<html lang="zh-cmn-Hans">
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, viewport-fit=cover">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <!--{if $hb_setting['base']}--><base href="{$hb_setting['base']}/" /><!--{/if}-->
    <title>{$navtitle}</title>
    <meta name="keywords" content="{$navtitle}">
    <meta name="description" content="{echo $desc ? $desc : $description}">
    <link rel="stylesheet" href="source/plugin/xigua_hb/static/pc/style.css?7{VERHASH}">
    <link rel="stylesheet" href="source/plugin/xigua_hb/static/css/swiper.min.css?7{VERHASH}">
    <style>.swiper-pagination-bullet-active{background:#fff}.card_car_tag.blue {background:$c06;border:1px solid $c06}
        .card_car_tag.blue i {color:$config['maincolor'];}.ifoset{font-family:DINAlternate-Bold;src:local("DINAlternate-Bold"),url(source/plugin/xigua_hb/static/css/DINAlternate-Bold.ttf) format("truetype")}
        .card_activity_tag.orange{background:{$config[maincolor]};color:#fff}.main_color{color:$config[maincolor]!important}
        .hover_sidebar{background:$c06;color:{$config[maincolor]}!important}.mod_lv.is-red{background:{$c06}!important;color:$config[maincolor]!important;border:1px solid $c06}
        .dialog-wrap .btn-err:active,.dialog-wrap .btn-err.active,.dialog-wrap .btn-err:hover,.dialog-wrap .btn.active,.dialog-wrap .btn:hover,.search-form.active,.search-form:hover,.show-industry .search-form,.quanzhi-more:hover,.quanzhi-more:active,.dialog-wrap .btn:active{border-color:$config[maincolor]}.hover-layer .popover-right-triangle{border-left-color:$config[maincolor]}
        .industry-box,.suggest-result,.asider-item-click .app-layer,.asider-item-click .layer,.city-choose .city-txt.active,.city-choose:hover .city-txt:after,.city-choose-layer{border:1px solid $config[maincolor];}
        .active,.zixun-item-bd:hover,.new-staff-box:hover,.txt:hover,.job-menu-sub .text a:hover,.quanzhi-more:hover,.quanzhi-recomand a:hover,.quanzhi-logo-txt,.hotsearch .list .items a:hover,.condition-box a:hover,.copyright .link-hover:hover,.footer-about dl dd a:hover,.dialog-wrap .btn-err.active,.dialog-wrap .btn-err:hover,.dialog-wrap .btn.active,.dialog-wrap .btn:hover,.dialog-wrap .dialog .dialog-ft .ft-btn:first-child,.dialog-wrap .dialog .dialog-ft .ft-btn:only-child,.suber-add-subsetup,.txt-link-more:hover,.third-key a:hover,.nav li a.publish,.tab .tab-li.active,.tab .tab-li:hover,.c-btn-primary .c-icon,.c-location-header-tips-success,.c-location-header-btn-in-active,.c-location-header-btn-in-active .c-icon,.item-bd .bd-txt a{color:$config[maincolor]}
        .apply-btn,.job-video .nav li.cur a:after,.quanzhi-logo-txt:after,.quanzhi-logo-txt:before,.hover-layer .tip-txt,.nav li.cur a:after,.nav li a.publish:active,.tabs li.active:after{background-image:linear-gradient(45deg,$config[maincolor],$config[maincolor])}
        .votebtn,.head-tab .ht-tab-item.active:after,.main_bg,.fareitemactive,.areaitemactive,.moneyitemactive{background-color:$config[maincolor]}
    </style><script>var IN_WECHAT = '{HB_INWECHAT}',IN_PROG='{IN_PROG}', AVATAR = "{echo avatar($_G['uid'], 'middle', true)}", UID = '{$_G[uid]}', FORMHASH = '{FORMHASH}', PLZINPUT = "{lang xigua_hb:inputtext}", BODA = '{lang xigua_hb:boda}', DELCONFIRM = '{lang xigua_hb:delconfirm}', SUIBIANSHUO = '{lang xigua_hb:suibianshuo}', HUIFU1 = '{lang xigua_hb:huifu1}', ERROR_TIP = '{lang xigua_hb:error_}';var loading = false, page = 1, _APPNAME = '{$SCRITPTNAME}', scrollto =0, plzinput_mobile = '{lang xigua_hb:plzinput_mobile}';
        var cookiepre = '{$_G[config][cookie][cookiepre]}', cookiedomain = '{$_G[config][cookie][cookiedomain]}', cookiepath = '{$_G[config][cookie][cookiepath]}', IN_APP='<!--{if IN_MAGAPP}-->magapp<!--{elseif IN_APPBYME}-->appbyme<!--{elseif IN_QIANFAN}-->qianfan<!--{/if}-->', LISTINCR = '{$config[listincr]}', _URLEXT = '{$_G[cookie][URLEXT]}{$urlext}', GSITE='{$_G[siteurl]}', MAXTAG = '{echo intval($config[maxtag])}', MAXTAGTIP = "{eval echo str_replace('n', $config['maxtag'], lang_hb('zdng',0));}", FASIXIN = '{lang xigua_hb:fsx}'<!--{if $config[xiala]}-->,XL=1<!--{/if}-->, LXFS ='{lang xigua_hb:cklxfs}',CKXFF = '{lang xigua_hb:cklxfsxzf}<strong class="amount">', QRZF ='</strong>{lang xigua_hb:yuan}<br>{lang xigua_hb:qrzf}', CKLXFS = '{lang xigua_hb:cklxfs}', ISADMINID = '{echo IS_ADMINID}', QUXIAO = '{lang xigua_hb:quxiao}', SHANCHU = '{lang xigua_hb:dodel}', QUEDING = '{lang xigua_hb:queding}', lm=false;</script>
    <script src="source/plugin/xigua_hb/static/lib/jquery-2.1.4.js?23{VERHASH}"></script>
    <script src="source/plugin/xigua_hb/static/js/swiper.min.js?{VERHASH}"></script>
    <link rel="stylesheet" href="source/plugin/xigua_sp/template/bootstrap.min.css?7{VERHASH}">
    <style>
        @media (min-width: 992px){.container {width: 1200px; } }
        @media (min-width: 768px){.container { width: 1200px; } }
        .searchbox{height:50px;padding:10px 0}
        .inputbox1{margin-right:0}
        .inputbox1 .form-control{border-color:#d43f3a}
        a.ftn{font-size:14px;color:white;padding:0 7px;margin-left:5px;cursor:pointer}
        .selectbox{color:#333}
        .selectbox ul.sl1 li{width:120px;float:left;border:solid 1px #c9c9c9;height:28px;line-height:28px;text-align:center;font-weight:bold}
        .selectbox ul.sl1 li select{border:0;font-weight:normal;color:#333}
        .selectbox ul.sl1 li select:focus{outline:0}
        .selectbox ul.sl1 li.no{border-left:none}
        .selectbox ul.sl1 li a{color:#333;font-size:12px}
        .main{background:white;padding:20px;box-shadow:0 0 5px #ccc}
        ul.bline{border-bottom:solid 1px #f2f2f2}
        ul.goodlist li{width:220px;float:left;margin-left: 17px;height:325px;position:relative;overflow:hidden;
            margin-bottom: 25px;}
        ul.goodlist li img {backface-visibility: hidden;-webkit-backface-visibility: hidden;-moz-backface-visibility: hidden;-ms-backface-visibility: hidden;image-rendering: auto;}
        ul.goodlist li a.indexbox{width:220px;height:240px;overflow:hidden;display:inline-block;}
        ul.goodlist li .video-icon{ position: absolute;color: #fff;font-size: 35px;height: 40px;line-height: 40px;display: block;margin: -45px 0 5px 10px; }
        ul.goodlist li .transition_box{position:absolute;bottom:0;left:0;z-index:5;width:220px;height:240px;transition:height .3s;-moz-transition:height .3s;-webkit-transition:height .3s;-o-transition:height .3s}
        ul.goodlist li .transition_box:hover{height:260px;overflow:hidden}
        ul.goodlist li .transition_box:hover .product_desc{overflow:initial;white-space:initial}
        ul.goodlist li p{margin-bottom:0}
        ul.goodlist li p a.goodtitle{font-size:12px;color:#333;font-weight:bold}
        ul.goodlist li p a.goodtitle:hover{text-decoration:underline}
        ul.goodlist li i.tj{position:absolute;left:0;top:0;width:59px;height:59px;z-index: 11;;background:url(/images/bao66/gif.png) no-repeat}
        ul.goodlist li i.original-img{position:absolute;left:0;top:0;width:59px;height:59px;background:url(images/ribbon/origin-zip.png) no-repeat;}
        a.price{color:#666;font-size:14px;font-weight:bold}
        a.price font{font-size:25px;font-weight:normal;font-family:Impact;color:#ea4b35;margin-left:5px}
        a.price span{margin-left:5px;font-size:12px;font-weight:normal}
        .product_desc{font-size: 12px;line-height:20px;display: inline-block;color: #666;max-width: 220px;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;}
        ul.goodlist li:hover .desc_hover{border-bottom: 2px solid #EA4B35;}
        #seachbox{margin-right:15px;float:right}
        .word{color:#333;font-weight:bold;line-height:30px}
        .word font{color:#eb3333;font-weight:normal}
        .word a{color:#333;font-size:14px;margin-left:5px}
        .word .btn{padding:2px 8px}
        .smallbtn .btn{padding:3px 10px}
        /*side ad*/
        .shopright{background:#f2f2f2;border-radius:3px;max-height:2250px;padding: 0;overflow: hidden;}
        .shopright .side-item{ margin-bottom: 20px; }
        .shopright .side-item .img a,.shopright .side-item .img a img{ display: block }
        .shopright .side-item .img a{ width:188px;overflow: hidden;min-height: 188px; }
        .shopright .side-item .img a img{ width: 188px; }
        .shopright .side-item .txt{ width: 188px;min-height: 40px;background-color: #777;padding: 5px; }
        .shopright .side-item .txt .subtxt{ border: 1px solid #fff}
        .shopright .side-item .txt .subtxt h4,.shopright .side-item .txt .subtxt h5{ color:#fff;text-align: center; }
        .shopright .side-item .txt .subtxt h4,.shopright .side-item .txt .subtxt h5{ max-width: 180px;overflow: hidden;word-break:keep-all;white-space:nowrap;text-overflow:ellipsis; }
        .shopright .side-item .txt .subtxt h5{font-size: 15px;font-weight: normal;}
        /*side ad end*/
        .dfword{color:#333;line-height:30px}
        .dfword font{font-weight:bold}
        .dflist{padding-left:0;padding-right:0}
        .dflist li{border:solid 1px #c9c9c9;position:relative;height:305px;margin-bottom:15px;margin-right:14px;width:48%}
        .dflist li:nth-child(even){margin-right:0}
        .dflist li .topdf{color:#06d;margin:10px 0;}
        .dflist li .topdf h3{margin:4px 0;width:45%;float:left;font-weight:bold;font-size:18px}
        .dflist li .topdf h3 a{font-weight:bold;font-size:18px}
        .dflist li .topdf .dfdesc{width:55%;float:right}
        .dflist li .topdf .dfdesc p{margin-bottom:0;line-height:20px;text-align:right}
        .dflist li .topdf .dfdesc p font{color:#d9534f}
        .dflist li .dfdetail{margin-bottom:10px}
        .dflist li .dfdetail p{margin-bottom:0;color:#000;overflow:hidden;text-overflow: ellipsis;white-space: nowrap;}
        .dflist li .dfdetail p.rg{font-size:14px}
        .dflist li .dfdetail p.rg span{color:#0081e6}
        .dflist li .dfdetail p.rg font{font-size:20px;font-weight:normal;font-family:Impact;color:#ea4b35;margin-left:5px;margin-right:5px}
        .dflist li .bottomdf{position:absolute;left:0;bottom:0;height:88px;background:#06c;width:100%}
        .dflist li .bottomdf p{margin-left:15px;line-height:30px}
        .dflist li .bottomdf .dfp1{color:#ffff52;font-size:16px;padding-top:8px}
        .dflist li .bottomdf .dfp2 a{border-color:#06c;padding:3px 6px}
        .paddings{padding:0px 20px;width:1200px}
        #top15{margin-top:15px}
        .carousel-indicators{bottom:10px}
        .phototitle{height:40px;background:url(/images/bao66/photo_title.jpg) no-repeat;padding-left:15px;font-size:14px;color:black;line-height:40px}
        .phototitle font{padding-left:10px}
        .photolist li{padding:0;border:0;padding-right:0}
        .photolist li a{padding:4px 0;border:0}
        #leftbox{width:920px;border-right:#f2f2f2 1px solid;padding-right:10px;padding-top:10px;float:left}
        #rightbox{width:235px}
        .ors{width:445px}
        .sline{border-bottom:#f2f2f2 1px solid;margin-bottom:20px;width:1200px}
        .location{margin-top:10px;margin-bottom:12px;padding-left:6px}
        .photo_good{width:902px;margin:0 auto;height:121px;margin-top:15px;background:url(/images/bao66/photo_bg.jpg) no-repeat}
        .yximg{border:solid 4px #ea4b34;width:60px;height:60px}
        .photo_l1{font-size:16px;font-weight:bold;color:black}
        .nops p{margin-bottom:0}
        .mtlist{padding-top:15px}
        .mtlist li{max-width:400px;float:left;margin-right:2px}
        #dflist li{width:32%;margin-right:13px}
        #dflist li:nth-child(even){margin-right:13px}
        .bggrey{background:#f2f2f2}
        .login_m{margin:30px 0}
        .login_adbox{height:60px;width:150px;margin:0 auto;text-align:center;margin-top:5px}
        .login_box{width:360px;height:345px;border:solid 1px #ccc;border-top:solid 2px #d9534f;padding:20px}
        .sred{color:#d8524e}
        .regbox{width:650px;margin:0 auto;border:solid 1px #ccc;border-top:solid 2px #d9534f}
        .regform{width:450px;margin:0 auto;padding-top:30px;padding-bottom:105px}
        .tabs{margin-bottom:30px}
        .tabs li{width:49%;text-align:center;float:left;background:#f2f2f2;color:black;font-size:16px;line-height:30px;line-height:30px}
        .tabs li a{color:black;font-size:16px}
        .tabs li.cur{background:#d9534f}
        .tabs li.cur a{color:white}
        .phones{font-size:26px;font-weight:normal;font-family:Impact;color:#ea4b35}
        .login_ad{height:340px;margin-top:25px}
        .getpassword_box{width:880px;margin:0 auto;border:solid 1px #ccc;padding:35px;color:black}
        .gpw_1{height:40px;line-height:40px;border-bottom:solid 1px #ccc}
        .getpwstatus h4 span{color:#5cb85c;margin-right:5px;position:relative}
        ul.pwslist{height:20px;line-height:20px;background:url(/images/bao66/pw.jpg) repeat-x;margin-top:15px}
        ul.pwslist li{height:20px}
        ul.pwslist li.cur{background:#5cb85c}
        #btn{padding-left:45px;padding-right:45px}
        .ops{padding-top:45px;padding-bottom:25px}
        #leftbox div.col-lg-9{width:445px}
        .logo_yz{background:#d9534f;width:150px;height:24px;margin-top: 3px!important;line-height:24px;}
        .logo_yz font.as1{color:white;padding:0 10px}
        .logo_yz font.as2{color:#d9534f;padding:0 10px;background:white;border:solid 1px #d9534f;height:22px;line-height:22px}
        .ot{margin-bottom:6px;margin-top:6px}
        .ot .btn{padding:2px 10px}
        .dflist li .photodetail p{font-size:16px;line-height:30px}
        .nopad{padding-left:0;padding-right:0;padding-top:0}
        #dflist li.p{margin-right:22px}
        #dflist li.p:nth-child(3n+0){margin-right:0}
        #dflist li.p .bottomdf{background:#428bca}
        .yz{height:25px;text-align:center;margin-left:18px;margin-top:5px}
        .noright{padding-right:0}
        .noleft{padding-left:0}
        ul,dl,ol{margin:0;padding:0}
        body{font-family:"΢���ź�";color:#666;background:url(/images/2016/img/bg_web.jpg);min-width:1200px;position:relative}
        img{border:0}
        li{list-style-type:none}
        .top5{margin-top:5px}
        .top10{margin-top:10px}
        .top15{margin-top:15px}
        .top20{margin-top:20px}
        .top25{margin-top:25px}
        .top30{margin-top:30px}
        .top40{margin-top:40px}
        .bottom10{margin-bottom:10px}
        .bottom15{margin-bottom:15px}
        .bottom20{margin-bottom:20px}
        .bottom25{margin-bottom:25px}
        .bottom30{margin-bottom:30px}
        .clear{clear:both}
        .base{width:1200px;margin:0 auto}
        .top{background:#f2f2f2;height:30px;line-height:30px;color:#8c8c8c}
        .top a{color:#8c8c8c}
        .top .reg{border:#d9534f solid 1px;padding:1px 10px;color:#d9534f}
        .top select{border:#d9534f solid 1px;padding:0 2px;color:#d9534f;border-left:none;position:relative;left:-6px;background:#f2f2f2;padding-right:0}
        .top select:focus{outline:0}
        .hs{overflow:hidden}
        .top_logo{padding:20px 0}
        .navbg{background:{$hb_setting[leftcolor]};height:41px;line-height:41px}
        .zp-footer{background-color:{$hb_setting[leftcolor]}!important}
        .navs li{max-width:150px;padding:0 27px;float:left;text-align:center;line-height:41px;height:41px;position:relative}
        .navs li i.jp{background:url(/images/bao66/y.png) no-repeat;width:58px;height:28px;position:absolute;top:-15px;left:35px;z-index:100}
        .navs li a{font-size:16px;color:white}
        .navs li.cur{background:#d9534f}
        .navs li:hover{background:#333}
        .navs li.cur:hover{background:#d9534f}
        .navs li.r{background:#428bca;float:right}
        .navs li.r i{position:relative;top:2px}
        .subnav{line-height:30px;height:auto;font-size:12px;background:white}
        .subnav .ps{margin:0;padding:0}
        .subnav .ps a{padding:0 7px}
        .subnav .ps a font{padding:0 7px;color:#666;padding-bottom:2px}
        .subnav .ps a.cur font{padding:0 7px;color:#de2b2a;border-bottom:solid 2px #de2b2a;padding-bottom:2px}
        .subnav .ps a:hover font{padding:0 7px;color:#de2b2a;border-bottom:solid 2px #de2b2a;padding-bottom:2px}
        .wh{background:white}
        .badges{padding:0 4px;color:white;font-size:10px;margin-left:6px}
        .green{background:#17bf00}
        .orange{background:#ff9f19}
        .blue{background:#0c88e8}
        .red{background:#f23030}
        .grey{background:#c90}
        a:hover{text-decoration:none}
        .pagination>li>a,.pagination>li>span{color:#333;font-size:16px;border:1px solid #c9c9c9}
        .pagination>.active>a,.pagination>.active>span,.pagination>.active>a:hover,.pagination>.active>span:hover,.pagination>.active>a:focus,.pagination>.active>span:focus{z-index:2;color:#fff;cursor:default;background-color:#d9534f;border-color:#d4403b}
        .footer{border-top:#c9c9c9 2px solid;background:white;padding-top:35px;text-align:center;}
        .sp_bottom{border-top: 2px solid #ececec;background-color: #F5F5F5;margin-top:20px;}
        .sp_bottom .foot{line-height: 40px;text-align: center;}
        .sp_bottom .foot a{color: #000;margin: 0 7px;font: normal 14px 'Microsoft YaHei';}
        .sp_bottom .copy{ border-top: 1px solid #E9E9E9;text-align: center;color: #666;font: normal 14px/40px 'Microsoft YaHei';}

        select{cursor:pointer}
        .p_top{/*position:fixed;*/left:0;top:0;height:40px;line-height:40px;color:white;background:black;width:100%;z-index:99999}
        .p_top .p_navs{font-size:16px;line-height:40px;color:#474747}
        .p_top .p_navs li{float:left;max-width:170px;padding:0 20px;text-align:center}
        .p_top .p_navs li.d{width:14px;padding:0;color:#474747}
        .p_top .p_navs li.logo{padding-right:30px}
        .p_top .p_navs li.logo:hover,.p_top .p_navs li.member:hover{background:0}
        .p_top .p_navs li a{font-size:16px;font-weight:bold;color:white}
        .p_top .p_navs li.member{width:240px;max-width:240px;text-align:right;float:right;font-size:12px}
        .p_top .p_navs li.member .btn{padding:0 5px}
        .p_top .p_navs li.member ul li a{color:#333;font-size:12px;font-weight:normal}
        .p_top .p_navs li:hover{background:#333}
        .p_top .p_navs li.member ul li:hover{background:0}
        /*����ʽ*/
        .bus_box{overflow:hidden;}
        .bus_box>div{float:left;}
        .bus_name{width:710px;height:auto;overflow:hidden;}
        .bus_name>div{float:left;}
        .p_top_bg{height:107px;background:url(/images/bao66/top_bg.jpg) no-repeat center center;background-color: #210c13;}
        .logoword {color: white;font-size: 40px;font-weight: bold;width: auto;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;padding-right: 10px;max-width: 380px;}
        .footphone{font-family:"Impact";font-size:26px;color:#d9534f;margin-bottom:1px}
        .logoright{padding:0;padding-top:7px;}
        .logoright p,.right_text p{margin:0;color:white}
        .right_text{padding-top:12px;width:490px;}
        .psort{color:#666;border:0}
        span.tx{padding:0 4px;background:#d9534f;color:white;border-radius:4px}
        .btn span.tx{font-size:12px;margin:0 3px}
        .phs font{font-weight:bold;margin-left:30px}
        .nopadding{padding-left:0;padding-right:0}
        .greybg{background:url(/images/bao66/grey.jpg) repeat-x;width:430px;margin:0 auto;height:516px}
        .imgbox{width:430px;margin:0 auto;height:430px;margin-top:15px;margin-bottom:10px;overflow:hidden;}
        .imgbox img{width:430px;}
        .img_slide{padding:0 15px;margin-bottom:15px;padding-bottom:5px}
        .img_slide li{float:left;margin-right:10px;width:60px;height:62px;cursor:pointer;margin-left:10px}
        .img_slide li img{width:60px;height:60px}
        .img_slide li:cur img{border:solid 2px #d9534f}
        .img_slide li:hover img{border:solid 2px #d9534f}
        .img_slide li.cur img{border:solid 2px #d9534f}
        .product_mid{width:460px;margin:0 auto;background:url(/images/bao66/product_md.jpg) no-repeat;margin-top:15px;height:516px}
        ul.product_tab{height:35px;line-height:35px;border-bottom:solid 1px #d9534f}
        ul.product_tab li{width:90px;float:left;text-align:center;background:#f2dede;border:solid 1px #d9534f;height:35px;line-height:35px;border-right:0}
        ul.product_tab li.cur{background:#d8524e}
        ul.product_tab li.last{border-right:solid 1px #d9534f}
        ul.product_tab li a{color:#d8524e;font-size:16px}
        ul.product_tab li.cur a{color:white}
        ul.product_tab li.sq{float:right;width:120px;border:0;text-align:right;background:0}
        ul.product_tab li.sq a{color:#428bca;margin-right:12px}
        .product_title_box{width:430px;margin:0 auto;color:black;padding-top:10px;margin-top:5px;display:none}
        .show{display:block}
        .lines{border-bottom:dashed 1px #ccc;height:1px;margin-bottom:10px}
        .product_title_box p{color:black;line-height:28px;margin-bottom:0}
        .product_title_box p.price_desc{line-height:40px}
        .prices{font-size:28px;font-weight:normal;font-family:Impact;color:#ea4b35;margin-left:3px;position:relative;top:4px}
        .bsc{background:black;padding:5px 6px;color:white;border-radius:4px;margin-left:5px}
        .ksl{margin-left:1px}
        .ksl:first-child{margin-left:0px;}
        .updatep{margin-top:5px;line-height:30px;border-bottom:dashed 1px #ccc}
        .adbox1{background:white;/* margin-top:25px */}
        .details{font-size:16px;color:#d9534f;line-height:40px;text-align:left;margin-top:20px;padding-left:22px}
        .detail_bg{background:url(/images/bao66/detail_bg.jpg) no-repeat;width:900px;height:auto;padding-top:13px}
        .detail_bg p{line-height:20px}
        .pcontent{line-height:22px;padding:10px 5px}
        #goodlist{width:230px;margin:0 auto;margin-top:25px}
        .product_bottom{width:1160px;margin:0 auto;background:url(/images/bao66/product_bottom.jpg) no-repeat;height:127px}
        .qqke{position:absolute;width:27px;height:355px;top:320px;right:10px}
        .glyphicon-modal-window{margin-right:5px}
        .rego .btn{color:#d9534f;border-color:#d9534f;padding:0 3px;font-size:12px}
        /* author :sparkinzy */
        .no-radius{border-radius: 0 !important}
        .bg-white{background-color: white}
        .bg-black{background-color: black}
        .bg-blue{background-color: #337ab7;color:white;border-radius: 3px 3px 0 0 ;}
        .text-white{color:white!important;}
        .text-center{text-align: center;}
        .tabs{margin-bottom:0;}
        .fav{position:absolute;top:0;left:150px;z-index:10000;display:none;}
        .inline-block{display:inline-block}
        .original_pic{ height:30px;backface-visibility: hidden;-webkit-backface-visibility: hidden;-moz-backface-visibility: hidden;-ms-backface-visibility: hidden;image-rendering: auto;}
        .bao66{font-family:"iconfont";font-size:14px;font-style:normal;}
        .label-small{padding: .1em .3em .15em!important;font-weight:normal;}
        .text-small{font-size: 12px;}
        .text-mini{font-size: 10px;}
        .text-normal{font-size: 14px;}
        .text-large{font-size: 16px;}
        .text-huge{font-size: 28px;}
        .padding-20{padding: 20px;}
        .no-padding{padding-left: 0;padding-right: 0;padding-top: 0;padding-bottom: 0;}
        .no-margin{margin:0;}
        .margin-top-40{margin-top: 40px;}
        .margin-top-20{margin-top: 20px;}
        .margin-top-10{margin-top: 10px;}
        .relative{position: relative;}
        .full-width{width:100%!important;}
        .propsul{color:#337ab7!important;}

        @media (min-width: 768px){
            .navbar{min-height:40px;}
            .navbar-nav{
                max-height:40px;
            }
            .navbar-nav>li>a {
                padding-top: 10px;
                padding-bottom: 10px;
            }
            .navbar-brand{
                height:40px;
                padding:10px;
            }
        }
        .text-default{font-size: 14px;}
        /*��ҳ����*/
        .btn-prop{background-color: white;color:#d9534f}
        #web-tabs{
            border-bottom: 1px solid #d9534f;
            padding-left: 0;
            margin-bottom: 0;
            list-style: none;
        }
        #web-tabs>li{
            float: left;
            margin-bottom: -1px;
            position: relative;
            display: block;
        }
        #web-tabs>li>a{
            line-height: 1.42857143;
            position: relative;
            display: block;
            color: #666;
        }
        #web-tabs>li.active>a{border:1px solid #d9534f;background-color:white;border-bottom-color: white;}
        #web-tabs>li>a{display:inline-block; padding:5px 8px; border:1px solid transparent; height:32px;}
        #web-tabs>li>a:hover{background-color: #d9534f;color:white;border:1px solid #d9534f;}
        .search-tabs>li>a{background-color: #F5F5F5;border-left: 1px solid #E7E7E7;border-right: 1px solid #E7E7E7;border-top: 1px solid #E7E7E7}
        /*����*/
        .move{display:inline-block;width:26px;color:white;text-align:center;margin-top:1px;}
        /*����*/
        .search-nav>li>a{padding:0 8px;}
        .search-nav>li>a:hover,.search-nav>li.active>a{background-color:#d9534f;color:white;}
        .search-prop-btn{background-color: transparent;border-color: transparent;}
        /*a:visited {color: #d9534f}*/
        a:hover {color: #FF00FF;text-decoration: none;}
        .remove_prop>a{border:1px solid #ddd;}
        .remove_prop>a:hover{background-color: white!important;color:#666!important;border:1px solid #a94442;}
        .help-block{text-align: center}
        a.nav-text:hover,a.nav-text:focus{background-color: #FF6C60!important}

        @keyframes flashit { 0%{ width: 160px;} 100%{ width: 220px;} }
        .flash { animation-name: flashit;animation-duration: 1s;animation-delay: 0s;animation-iteration-count: 10;}

        .e_price,.s_price{outline:0;width:40px;height:23px;border:solid 1px #dfdfdf;font-family:arial;font-size:12px}
        .guest-btn{float:right;padding:0 10px;height:23px;border:0;border-radius:2px;background:#ff4500;color:#fff;line-height:23px}
        /*���ƻ˫12*/
        .fixed-bottom{ background-color: #fcec25; position: fixed;z-index: 1989;text-align: center;width: 100%;overflow: hidden;bottom: 0; }
        .bottom-banner-close{ font-size: 5rem;display: inline-block;position: absolute;top: 0;right: 20px;color: #fff; z-index: 2000;}
        .bottom-container{ position: relative;width: 1220px;display: inline-block;overflow: hidden; }
        /*����ҳ���Ʒ����*/
        .xz .icon-bofang{ color:#4988C8 !important; }
        #web-tabs>li>a:hover .icon-bofang{ color:#fff !important; }
        .indexbox{ width: 220px;height: 240px;text-align: left;vertical-align: middle;position: relative;overflow: hidden; }
        ul.typeahead{ min-width:221px;max-width:266px;background:#FFF;padding-bottom:0px;padding-top:0px;line-height:150%;border:1px solid #CC3300;position:absolute;top:28px!important;z-index:1989; }
        ul.typeahead li{ margin:0px;padding:0px;border-bottom:1px dashed #E2E2E2;font-size:12px; }
        ul.typeahead li.active a:hover{ background-color:#D9534F; }
        ul.typeahead li.active a{ background-color:#D9534F!important; }
        ul.typeahead li:last-of-type{ border-bottom:0px!important; }
        ul.typeahead a{ padding-left:10px; }
        .search-close{ position:absolute;font-size:20px;font-style:normal;top:0;left:200px;cursor:pointer;display:none;color:#333;z-index:2;}
        /*ͷ��nav*/
        .navs{ position: relative;}
        .navs li a{ display: block;}
        .navs li { width:90px;padding:0px;margin:0px;position: relative;}
        .navs li .subnavs{ position: absolute;z-index: 19890322;display: none; }
        .navs li:hover .subnavs{ display: block;background: #000000;margin-top: -5px; }
        .navs li:hover,.navs li .subnavs li:hover{ background:#D9534F;  }
        .navs li .subnavs li a{ display: block; }
        /*�޸��б���Ʒ����*/
        /*���Ĺ�����*/
        .qzBanner {
            width: 1170px !important;
            height:95px!important;
            display: block;
            margin: 15px !important;
            margin-top: 0 !important;
        }
        .banner_list,qzBanner{
            margin-top: 10px;
            overflow: hidden;
        }
        .banner_list a ,.qzBanner a{
            float: left;
            width: 380px;
            position: relative;
            margin-right: 15px;
        }
        .banner_list a>img ,.qzBanner a>img{
            width:100%;
            height:100%;
        }
        .banner_list a i,.qzBanner a i{
            width: 24px;
            height: 14px;
            position: absolute;
            right: 0;
            bottom: 0;
        }
        .banner_list a:last-child,.qzBanner a:last-child{
            margin-right: 0;
        }
        @media screen and (min-width: 1920px){
            .container {
                width: 1440px;
            }
            .banner_list a,.qzBanner a{
                width: 460px;
            }
            .qzBanner{
                width: 1410px!important;
                height:115px!important;
            }
            .shopright .side-item .img a{
                width: 228px;
            }
            .shopright .side-item .img a img {
                width: 228px;
            }
            .shopright .side-item .txt {
                width: 228px;
            }
            .shopright .side-item .txt .subtxt h4,
            .shopright .side-item .txt .subtxt h5 {
                max-width: 217px;
            }
            #inner_box>.item>img{
                width: 100%;
            }
            #dflist li.p{
                margin-right: 28px;
            }
            .search-close{
                left: 260px;
            }
            ul.typeahead {
                min-width: 285px;
            }
        }

        /*�µ�ע���¼��ť*/
        .header_list_right{
            float: right;
            height: 30px;
            margin:5px 0;
        }
        .header_list_right li{
            float: left;
            position: relative;
            height: 25px;
            width: 70px;
            line-height: 24px;
            text-align: center;
            border: 1px solid #d9534f;
            margin-top: 2px;
            background-color: #fff;
        }
        #nav_user,.register-btn{
            margin-left: -1px;
        }
        .header_list_right li a{
            color: #d9534f;
            font-size:12px;
        }
        a.nav_l{
            max-width: 94px;
            display: inline-block;
            overflow: hidden;
            white-space: nowrap;
            text-overflow: ellipsis;
        }
        .register-btn,.login-btn{
            width: 70px !important;
        }
        .header_list_right li>.nav_user{
            display: none;
            z-index: 1;
            position: absolute;
            right: 1px;
            width: 100%;
            top: 21px;
        }
        .header_list_right li:hover{
            background-color: #e6e6e6;
        }
        .header_list_right li:hover>.nav_user{
            display: block;
        }
        .do-follow {
            display: inline-block;
            font-size: 12px;
            color: rgb(120, 199, 234);
            float: right;
            height: 16px;
            line-height: 16px;
            cursor: pointer;
            font-weight: 300;
            box-sizing: border-box;
            margin: 8px 0px 0px 5px;
            border-width: 1px;
            border-style: solid;
            border-color: rgb(120, 199, 234);
            border-image: initial;
            border-radius: 2px;
            padding: 0px 1.5px;
        }
        .gong-qiu,.icoNew{ position: relative;}
        .gong-qiu>span{ font-size: 12px;position: absolute;top: 0;right: 0;color: #fff;display: inline-block;background: #54C8CB;width: 30px;border-radius: 4px;height: 14px;line-height: 14px;}
        .icoNew>span{ color:#fff;background-color: #f04848;position: absolute;right: 0;top: -8px;line-height: 13px;padding: 1px 3px;font-size: 12px;border-radius: 3px;z-index:5}

    </style>
    <link rel="stylesheet" href="source/plugin/xigua_hb/static/iconfont.css?7{VERHASH}">
</head>
<body>