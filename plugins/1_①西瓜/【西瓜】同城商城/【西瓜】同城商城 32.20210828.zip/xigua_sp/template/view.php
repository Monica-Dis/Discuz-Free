<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_sp:header}--><!--{eval $sh = $v[sh]}-->
<link rel="stylesheet" href="source/plugin/xigua_sp/template/view.css?{VERHASH}"/>
<div class="header_list">
    <div class="header_list_box">
        <ul class="header_list_left">

            <!--{eval $toplink = explode("\n", $sp_setting[toplink]);}-->
            <!--{loop $toplink $_k $_v}-->
            <!--{eval list($_link, $_name, $_color, $_target) = explode('|', trim($_v));
            $cat_id =isset($_GET['cat_id'])? intval($_GET['cat_id']):'';
            if(!$_name):
                contiune;
            endif;
            }-->
            <li>
                <div class="border_right">
                    <div class="modular"><a <!--{if $_target}-->target="_blank"<!--{/if}--> <!--{if $_color}-->style="color:$_color"<!--{/if}--> href="$_link">$_name</a></div>
                </div>
            </li>
            <!--{/loop}-->
        </ul>
    </div>
</div>
<div class="business_box  ">
    <div class="business">
        <div class="name_left">
            <div class="icon_vips" style="margin-right:10px;width:50px;height:40px;background-image:url({$sh[logo]})"></div>
            <div class="name"><a href="javascript:;">{$sh[name]}</a></div>
        </div>
        <div class="site_right">
            <div><b>&#30005;&#35805;</b>: $sh[tel]
            </div>
            <div><b>&#22320;&#22336;</b>: $sh[addr]</div>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="merchant_menu">
        <ul class="seller_menu">
            <li><a href="plugin.php?id=xigua_sp&ac=cat&shid=$sh[shid]">&#25152;&#26377;&#20135;&#21697;</a></li>
            <li class="on"><a href="javascript:void(0)">&#21830;&#21697;&#35814;&#24773;</a></li>
        </ul>
    </div>
</div>
<div class="container" style="margin-bottom:20px">
    <div class="thumbnail_box">
        <div class="picture_box" style="margin-bottom:20px">
            <div class="picture">
                <!--{if !$v[album]}-->
                <!--{eval $v[album] = $v[append_img_ary];}-->
                <!--{/if}-->
                <!--{if !$v[album]}-->
                <!--{eval $v[album] = array($v[fengmian]);}-->
                <!--{/if}-->
                <!--{if $v[album]}-->
                <div class="swiper-container pc_swiper z v_swiper">
                    <div class="swiper-wrapper">
                        <!--{loop $v[album] $slider}-->
                        <div class="swiper-slide vcide">
                            <img src="$slider" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'"/>
                        </div>
                        <!--{/loop}-->
                    </div>
                    <div class="swiper-pagination"></div>
                    <div class="swiper-button-next"></div>
                    <div class="swiper-button-prev"></div>
                </div>
                <!--{/if}-->
            </div>
            <div class="detailed_info" style="margin-bottom:20px">
                <div class="title">
                    <div class="huohao">$v['title']</div>
                </div>
                <div class="promise">$v['subtitle']</div>
                <div class="spot_price">
                    <div class="massage"><span>&#20215;&#26684;</span>&nbsp;:
                        <span class="msg_price">
                            <!--{if $v[price_dm_min]!=$v[price_dm_max]}-->
                            <span style="font-size:14px">&yen;</span><span class="sku-price">{$v[price_dm_min]}</span> -
                            <span style="font-size:14px">&yen;</span><span class="sku-price">{$v[price_dm_max]}</span>
                            <!--{else}-->
                            <span style="font-size:14px">&yen;</span><span class="sku-price">{$v[price_dm_min]}</span>
                            <!--{/if}-->
                        </span>
                    </div>
                </div>
                <div class="category"><span>&#31867;&#22411;&#65306;<span style="font-weight:700;margin-right:15px">{$v[hy]}</span></span>
                </div>


                <!--{loop $v[spgg_ary] $_spk $_spn}-->
                <div class="default-size size_box">
                    <div><span>{$_spn[name]}</span>&nbsp;:
                        <!--{loop $_spn[ggtext] $_ggk $_ggt}-->
                        <span>  <a href="javascript:void(0);" class="sku-size " id="sku-size0" data-title="" data-size="$_ggt">$_ggt</a>  </span>
                        <!--{eval $spcount++;}-->
                        <!--{/loop}-->
                    </div>
                </div>
                <!--{/loop}-->

                <div class="mobile-layer clearfix" style="float:left;">
                    <div class="apply-btn apply-btn2" data-mobile="" style="position:relative;top:10px;margin-bottom:20px">&#31435;&#21363;&#36141;&#20080;</div>
                    <div class="share-panel2">
                        <div class="share-layer share-layer-comp" style="margin-top: 35px;">
                            <div class="popover">
                                <i class="popover-tag popover-bottom-triangle"></i>
                            </div>
                            <div>
                                <img src="$qrfile" />
                                <p style="text-align: center;margin-bottom: 10px;font-size:14px">&#24494;&#20449;&#25195;&#30721;&#31435;&#21363;&#36141;&#20080;</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="info_list">
                <div class="list_button"><a class="on show_one" href="javascript:;">&#21830;&#21697;&#35814;&#24773;</a>
                </div>
                <div class="shoes_info" id="propshowbox">
                    <!--{eval
                    if(strpos($v['jieshao'], '&lt;') !== false  && strpos($v['jieshao'], '&gt;') !== false) :
                        $v['jieshao'] = htmlspecialchars_decode($v['jieshao']);
                        $v['jieshao'] = preg_replace(array("/<script(.*?)<\/script>/is",'/on(mousewheel|mouseover|click|load|onload|submit|focus|blur)="[^"]*"/i'), array('',''), $v['jieshao']);
                    endif;
                    }-->
                    <div>{echo hs_nl2br($v['jieshao']);}</div>
                    <!--{loop $v[append_img_ary] $__k $__v}-->
                    <div><img src="{$__v}"/></div>
                    <div>{echo hs_nl2br($v[append_text_ary][$__k]);}</div>
                    <!--{/loop}-->

                </div>
            </div>
        </div>
        <div class="right-content">
            <div class="bus_info">
                <!--{eval for($i=1; $i<=4; $i++):
                $key1 = 'pc_right'.$i;
                $key2 = 'pc_right_link'.$i;
                }-->
                <!--{if $sp_setting[$key1]}-->
                <a target="_blank" href="{$sp_setting[$key2]}"><img width="100%" src="{$sp_setting[$key1]}">
                    <i></i> </a>
                <!--{/if}-->
                <!--{eval endfor;}-->
            </div>
            <div class="product_right">
                <div class="details_box">
                    <div class="recommend"><span></span>&#21830;&#23478;&#25512;&#33616;&#27454;</div>
                </div>
                <ul class="prod_menu">
                    <!--{loop $xglist $_k $_v}-->
                    <li class="prod_list">
                        <a href="plugin.php?id=xigua_sp&ac=view&gid={$_v[id]}" style="position:relative;display:inline-block"><img src="{echo $_v[fengmian] ? $_v[fengmian] : ($_v[album][0] ? $_v[album][0] : $_v[append_img_ary][0])}">
                        </a>
                        <p class="text embffpe_characters">{$_v[title]}</p>
                        <p class="price_right"><a href="javascript:void(0);" class="price embffpe_price">&yen;<span style="font-size:20px">{$_v[dprice]}</span></a></p>
                        <p class="business_text"><a href="javascript:void(0);" class="goodtitle">{$_v[hy]}</a></p>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
    </div>
</div>
<!--{template xigua_hb:common_footer}-->