<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_hb:common_header}--><style>
</style>
<div class="main home-content" <!--{if $sp_setting[shindex_toppic]}-->style="background-image:url($sp_setting[shindex_toppic])"<!--{/if}-->>
<div class="inner home-inner">
    <div class="search-box ">
        <div class="search-form clearfix ">
            <div  class="clearfix">
                <div class="search-form-con">
                    <div class="position-sel search-form-ele">
                        <i class="line"></i><span class="label-text search-form-ele"><em class="search-form-ele" id="searchv">{lang xigua_sp:jj}</em><i class="icon more-down-icon"></i></span>
                        <div class="industry-box">
                            <ul>
                                <li><a href="javascript:;" data-id="xigua_hb" data-ac="cat" data-txt="{lang xigua_hb:xinxi}">{lang xigua_hb:xinxi}</a></li>
                                <li><a href="javascript:;" data-id="xigua_hs" data-ac="hangye" data-txt="{lang xigua_hb:shj}">{lang xigua_hb:shj}</a></li>
                                <li><a href="javascript:;" data-id="xigua_sp" data-ac="cat" data-txt="{lang xigua_sp:jj}">{lang xigua_sp:jj}</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="ipt-wrap">
                        <form class="z x_form" id="searchForm" method="get" action="$SCRITPTNAME">
                            <input type="hidden" name="id" value="xigua_sp">
                            <input type="hidden" name="ac" value="cat">
                            <input type="hidden" name="st" value="$_GET[st]">
                            <input type="hidden" name="idu" value="$_GET[idu]">
                            <input type="text" name="keyword" autocomplete="off" maxlength="50" placeholder="$sp_config[schtxt]" value="" class="ipt-search search-form-ele">
                        </form>
                    </div>
                    <div class="search-btn">
                        <i class="icon search-icon"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="inner home-inner page-core clearfix">
    <div class="left job-classify" <!--{if $hb_setting[leftcolor]}-->style="background:{echo $hb_setting[leftcolor]=='#000000'? $config[maincolor] : $hb_setting[leftcolor]}"<!--{/if}-->>
    <!--{loop $cat_tree_all $_k $_v}--><!--{eval
$ii++;
$ij = 0;
if($ii>10):
    break;
endif;
}-->
    <div class="box">
        <div class="first-item">
            <a target="_blank" href="{echo $_v[cat_link] ? $_v[cat_link] : hb_pc_rewriteoutput('hangye_page', $_v[id], $cityauto)}" class="query-item">$_v[name]</a>
            <!--{if !$hb_setting[hidecat]}-->
            <!--{loop $_v[sub] $__k $__v}-->
            <a target="_blank" href="{echo $__v[cat_link] ? $__v[cat_link] : hb_pc_rewriteoutput('hangye_page', $__v[id], $cityauto)}" class="query-item">$__v[name]</a>
            <!--{/loop}-->
            <!--{/if}-->
        </div>
        <div class="job-menu-sub" style="top:{echo $i*40;}px;height:auto">
            <div class="popover">
                <i class="popover-left-triangle" style="top:5px;left:-35px;"></i>
                <!--{eval $i++;}-->
            </div>
            <ul>
                <li class="clearfix">
                    <div class="head-txt">$_v[name]</div>
                    <div class="text">
                        <!--{if !$_v[sub]}-->
                        <a target="_blank" href="{echo $_v[cat_link] ? $_v[cat_link] :  hb_pc_rewriteoutput('hangye_page', $_v[id], $cityauto)}" class="job-classify-btn">$_v[name]</a>
                        <!--{else}-->
                        <!--{loop $_v[sub] $__k $__v}-->
                        <a target="_blank" href="{echo $__v[cat_link] ? $__v[cat_link] :  hb_pc_rewriteoutput('hangye_page', $__v[id], $cityauto)}" class="job-classify-btn">$__v[name]</a>
                        <!--{/loop}-->
                        <!--{/if}-->
                    </div>
                </li>
            </ul>
        </div>
    </div>
    <!--{/loop}-->
</div>
<div class="middle banner">
    <div class="ivu-carousel"  style="width:690px">
        <!--{if $sp_setting[pcslider1]}-->
        <div class="swiper-container pc_swiper">
            <div class="swiper-wrapper">
                <!--{eval for($i=1; $i<=4; $i++):
                $key1 = 'pcslider'.$i;
                $key2 = 'pcslider_link'.$i;
                }-->
                <!--{if $sp_setting[$key1]}-->
                <div class="swiper-slide">
                    <a target="_blank" href="{$sp_setting[$key2]}"><img src="{$sp_setting[$key1]}"></a>
                </div>
                <!--{/if}-->
                <!--{eval endfor;}-->
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <!--{elseif $topnavslider}-->
        <div class="swiper-container pc_swiper">
            <div class="swiper-wrapper">
                <!--{loop $topnavslider $slider}-->
                <div class="swiper-slide">$slider</div>
                <!--{/loop}-->
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <!--{/if}-->
    </div>
</div>
<div class="right job-video" style="width:250px;padding-left:10px">
    <!--{eval for($i=1; $i<=4; $i++):
    $key1 = 'pc_right'.$i;
    $key2 = 'pc_right_link'.$i;
    }-->
    <!--{if $sp_setting[$key1]}-->
    <div>
        <a target="_blank" href="{$sp_setting[$key2]}"><img style="height:130px;margin:10px 0;width:240px;display:block" src="{$sp_setting[$key1]}"></a>
    </div>
    <!--{/if}-->
    <!--{eval endfor;}-->
</div>
</div>
<!--{template xigua_hs:shlist}-->
<!--{template xigua_hs:shlist_new}-->
<div class="brand-box" >
    <div class="inner home-inner brand-box-content clearfix">
        <p class="brand-box-title">{$config[tname]}</p>
        <div class="brand-box-container">
            <dl style="width: 33%;padding-left: 0;text-align: center;margin-right: 0;">
                <dt>$totalviews<em>+</em></dt>
                <dd>{lang xigua_hb:shj}{lang xigua_hb:views}</dd>
            </dl>
            <!--{if $totalpub}-->
            <dl style="width: 33%;padding-left: 0;text-align: center;margin-right: 0;">
                <dt>$totalpub<em>+</em></dt>
                <dd>{lang xigua_hb:yiruzhu}{lang xigua_hb:shj}</dd>
            </dl>
            <!--{/if}-->
            <dl style="width: 33%;padding-left: 0;text-align: center;margin-right: 0;">
                <dt>$totalshares<em>+</em></dt>
                <dd>{lang xigua_hb:shj}{lang xigua_hb:views2}</dd>
            </dl>
        </div>
    </div>
</div>
</div>
<!--{template xigua_hb:common_footer}-->