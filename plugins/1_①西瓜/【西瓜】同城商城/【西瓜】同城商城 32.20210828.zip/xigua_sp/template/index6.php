<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_sp:header}--><style>
</style>
<!--{if $_GET['shid']}-->
<link rel="stylesheet" href="source/plugin/xigua_sp/template/view.css?{VERHASH}"/>
<div class="header_list">
    <div class="header_list_box">
        <ul class="header_list_left">

            <!--{eval $toplink = explode("\n", $sp_setting[toplink]);}-->
            <!--{loop $toplink $_k $_v}-->
            <!--{eval list($_link, $_name, $_color, $_target) = explode('|', trim($_v));
            $cat_id =isset($_GET['cat_id'])? intval($_GET['cat_id']):'';
            if(!$_name):
                contiune;
            endif;
            }-->
            <li>
                <div class="border_right">
                    <div class="modular"><a <!--{if $_target}-->target="_blank"<!--{/if}--> <!--{if $_color}-->style="color:$_color"<!--{/if}--> href="$_link">$_name</a></div>
                </div>
            </li>
            <!--{/loop}-->
        </ul>
    </div>
</div>
<div class="business_box  ">
    <div class="business">
        <div class="name_left">
            <div class="icon_vips" style="margin-right:10px;width:50px;height:40px;background-image:url({$sh[logo]})"></div>
            <div class="name"><a href="javascript:;">{$sh[name]}</a></div>
        </div>
        <div class="site_right">
            <div><b>�绰</b>: $sh[tel]
            </div>
            <div><b>��ַ</b>: $sh[addr]</div>
        </div>
        <div style="clear:both"></div>
    </div>
    <div class="merchant_menu">
        <ul class="seller_menu">
            <li class="on"><a href="plugin.php?id=xigua_sp&ac=cat&shid=$sh[shid]">���в�Ʒ</a></li>
            <li><a href="javascript:void(0)">��Ʒ����</a></li>
        </ul>
    </div>
</div>
<div class="container bg-white top10">
<ul id="list" class="goodlist clearfix top10 row">
</ul>

</div>
<script>
    var page = 1;
    var loadingurl = window.location.href+'&ac=cat_li&inajax=1&page=';
</script>
<!--{else}-->
<div class="bg-white">
    <div class="container container-fluid">
        <div class="row top_logo">
            <div class="col-lg-3 col-xs-3">
                <a href="plugin.php?id=xigua_sp" name="home"><img src="{$hb_setting['logo']}"></a>
            </div>
            <div class="col-lg-9 col-xs-9 text-center">
                <!--{if $sp_setting[shindex_toppic]}--><img src="$sp_setting[shindex_toppic]"><!--{/if}-->
            </div>
        </div>
    </div>
</div>
<div class="navbg">
    <ul class="container navs">
        <!--{eval $toplink = explode("\n", $sp_setting[toplink]);}-->
        <!--{loop $toplink $_k $_v}-->
        <!--{eval list($_link, $_name, $_color, $_target) = explode('|', trim($_v));
        $cat_id =isset($_GET['cat_id'])? intval($_GET['cat_id']):'';
        if(!$_name):
            contiune;
        endif;
        }-->
        <li class=""><a <!--{if $_target}-->target="_blank"<!--{/if}--> <!--{if $_color}-->style="color:$_color"<!--{/if}--> href="$_link">$_name</a></li>
        <!--{/loop}-->
    </ul>
</div>
<!--{template xigua_sp:main}-->
<!--{/if}-->
<!--{template xigua_hb:common_footer}-->