<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<div class="container bg-white top10">
    <!-- search -->
    <div class="row bottom10 top15">
        <div class="col-md-3">
            <div class="input-group input-group-sm has-error">
                <form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
                    <input type="hidden" name="id" value="xigua_sp"> <input type="hidden" name="ac" value="cat">
                    <input type="hidden" name="st" value="$_GET[st]"> <input type="hidden" name="idu" value="$_GET[idu]">
                    <input id="keyword"  name="keyword" class="form-control no-radius keyword" type="text" value="" placeholder="{echo $keyword ? $keyword : $sp_config[schtxt]}" x-webkit-speech="" style="width:200px" >
                    <span class="input-group-btn"><button class="btn btn-danger no-radius search" id="search" type="submit">&#25628;&#32034;</button></span>
                </form>
            </div>
        </div>
        <div class="col-md-9">
            <ul id="web-tabs" class="search-tabs clearfix" style="height:33px">

                <li class="<!--{if !$_GET['catid']}-->active<!--{/if}-->">
                    <a class="no-radius btn-prop" href="$SCRITPTNAME?id=xigua_sp&ac=cat&catid=">&#20840;&#37096;</a>
                </li>
                <!--{loop $cat_list $cat}-->
                <li class="<!--{if $cat[id]==$_GET['catid']}-->active<!--{/if}-->">
                    <a class="no-radius btn-prop" href="$SCRITPTNAME?id=xigua_sp&ac=cat&catid={$cat[id]}">$cat[name]</a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <!-- /search -->
    <div class="row search-box text-normal no-margin"><script type="text/javascript">
            var selected_props = "";
            var cid = "all";
            var channel= "new";
            var keyword='';
            keyword=0

            $(document).ready(function(){
                $(".prop").click(function() {
                    var props = "" != selected_props ? selected_props + "^" + $(this).attr("prop") : $(this).attr("prop");
                    window.location.href = '/search/' +channel+ ',' +cid+ ',' +keyword+ ',' +props+ ',1,0.html';
                });

                $("body").on('click',".guest-btn",function () {
                    var s_price = $(".s_price").val();
                    var e_price = $(".e_price").val();
                    if (s_price == '' && e_price == '') {
                        layer.msg('&#35831;&#36755;&#20837;&#20215;&#26684;');
                        return false;
                    } else if(s_price == 0 || e_price == 0) {
                        layer.msg('&#35831;&#36755;&#20837;&#22823;&#20110;&#38646;&#30340;&#20215;&#26684;');
                        return false;
                    }else{
                        var props = "" != selected_props ? selected_props +"^price"+ ":" +s_price+ "-" +e_price : "price"+ ":" +s_price+ "-" +e_price;
                        window.location.href = '/search/' +channel+ ',' +cid+ ',' +keyword+ ',' +props+ ',1,0.html';
                    }
                });
                $(".remove_prop").each(function () {
                    var propNum = $(this).attr("prop");
                    if (propNum.indexOf("price") != -1) {
                        $(this).addClass('choose-price');
                    }
                });
                var shang = $('.choose-price').text();
                var propNum = $('.choose-price').text().replace(/[\u4E00-\u9FA5]/g, '');
                if (shang.indexOf("��") != -1) {
                    $(".s_price").val(propNum);
                } else {
                    if (shang.indexOf("-") != -1) {
                        var arrNum = propNum.split("-");
                        $(".s_price").val(parseInt(arrNum[0]));
                        $(".e_price").val(parseInt(arrNum[1]));
                    } else {
                        $(".e_price").val(propNum);
                    }
                }

                $(".remove_prop").click(function() {
                    var props = "" != selected_props ? selected_props + "|" + $(this).attr("prop") : $(this).attr("prop");
                    window.location.href = '/search/' +channel+ ',' +cid+ ',' +keyword+ ',' +props+ ',1,0.html';
                });

                $('.btn-searech-prop').hover(function() {
                    $(this).find('ul').css('top','15px').show();
                }, function() {
                    $(this).find('ul').hide();
                });
            });

        </script>
    </div>

    <ul id="list" class="goodlist clearfix top10 row">
    </ul>

</div>
<script>
    var loadingurl = window.location.href+'&ac=cat_li&inajax=1&page=';
</script>