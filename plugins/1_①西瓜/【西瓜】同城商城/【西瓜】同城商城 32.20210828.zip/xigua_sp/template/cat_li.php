<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{loop $list $_k $_v}-->
<li class="inline-block">
    <div class="indexbox">
        <i class="tj"></i>
        <div class="transition_box">
            <a href="plugin.php?id=xigua_sp&ac=view&gid={$_v[id]}" target="_blank">
                <img src="{echo $_v[fengmian] ? $_v[fengmian] : ($_v[album][0] ? $_v[album][0] : $_v[append_img_ary][0])}" style="width: 100%;height:100%">
            </a>
            <span class="iconfont icon-bofang video-icon"></span>
            <p class="product_desc" >
                <!--{loop $_v[srange_ary] $__v}-->
                {eval $rv= explode('#', $__v);echo $rv[0];}&nbsp;&nbsp;
                <!--{/loop}--></p>
        </div>
    </div>
    <p class="top5" style="height:38px;overflow:hidden">
        <a href="plugin.php?id=xigua_sp&ac=view&gid={$_v[id]}" target="_blank" class="goodtitle">{$_v['title']}</a></p>
    <p class="desc_hover">
        <a href="plugin.php?id=xigua_sp&ac=view&gid={$_v[id]}" target="_blank" class="price">&yen;<font>{$_v['dprice']}</font><span></span></a>
    </p>
</li>
<!--{/loop}-->