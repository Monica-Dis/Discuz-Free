<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if !$sp_config[closept]}-->
<!--{if $_G['cache']['plugin']['xigua_dp'] && in_array('sp', unserialize($_G['cache']['plugin']['xigua_dp']['opens']))}-->
<style>.gzbtn{background-color:$config[maincolor]}</style><div id="ptdiv2" style="display:none"></div>
<script>
    $.ajax({type: 'get',dataType: 'xml',
        url: '$SCRITPTNAME?id=xigua_dp&ac=jingxuan&inajax=1&type=sp&typeid=$gid&shid={$v[shid]}&pagesize=5&page=1',
        success: function (data) {
            if(null==data){ $('#ptdiv2').remove(); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(!s){ $('#ptdiv2').remove(); return false;}
            $('head').append('<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?{VERHASH}" />');
            $('body').append('<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"><\/script>');
            $('#ptdiv2').html(s).show();
        },
        error: function () {$('#ptdiv2').remove();}
    });
</script>
<!--{else}-->
<div id="comment_profile" class="mt10">
    <div class="view_content mod-post x-postlist p0 comment_ul" id="clist">
        <div class="weui-cells__title weui_title mt0 f15 " id="comment_ul_first">
            <span>{lang xigua_sp:sppj}</span>
            <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_sp&ac=comments&gid={$v[id]}" ><b class="color-red f12">{lang xigua_sp:hp}{$avgstar}%</b><i class="f13 iconfont icon-jinrujiantou"></i></a>
        </div>
    </div>
    <a href="$SCRITPTNAME?id=xigua_sp&ac=comments&gid={$v[id]}" class="weui-media-box weui-media-box_appmsg bgf">
        <div class="weui-media-box__bd">
            <p class="weui-media-box__desc tc mt0 c9">{lang xigua_sp:ckqbpj}</p>
        </div>
    </a>
</div>

<div id="comment_popup" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="fixpopuper">

            <div class="weui-cells__title">{lang xigua_sp:pjsd}</div>
            <div class="weui-cells weui-cells_form">
                <div class="weui-cell">
                    <div class="weui-cell__hd"><img src="$v[album][0]" class="weui-img"></div>
                    <div class="weui-cell__bd">
                        <p class="f14">{$v[title]}</p>
                    </div>
                    <div class="weui-cell__ft"></div>
                </div>

                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <textarea class="weui-textarea" id="comment_content" placeholder="{lang xigua_hs:say}" rows="3"></textarea>
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <div class="weui-uploader">
                            <div class="weui-uploader__hd">
                                <p class="weui-uploader__title">{lang xigua_hs:upload}</p>
                                <div class="weui-uploader__info">{lang xigua_hs:maxupload}{$hs_config[maxcmtpic]}{lang xigua_hs:zphoto}</div>
                            </div>
                            <div class="weui-uploader__bd">
                                <ul class="weui-uploader__files" data-max="$hs_config[maxcmtpic]" data-maxtip="{lang xigua_hs:maxupload}{$hs_config[maxcmtpic]}{lang xigua_hs:zphoto}">
                                </ul>
                                <div class="weui-uploader__input-box">
                                    <!--{if HB_INWECHAT && $config[multiupload]}-->
                                    <a class="weui-uploader__input" data-name="comment_photo" type="file" data-multi="1"></a>
                                    <!--{else}-->
                                    <input class="weui-uploader__input" data-name="comment_photo" type="file" data-multi="1">
                                    <!--{/if}-->
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <div>{lang xigua_sp:pf}</div>
                        <div class="weui-slider-box" id="slider1">
                            <div class="weui-slider">
                                <div id="sliderInner" class="weui-slider__inner">
                                    <div id="sliderTrack" style="width:100%;" class="weui-slider__track"></div>
                                    <div id="sliderHandler" style="left:100%;" class="weui-slider__handler"></div>
                                </div>
                            </div>
                            <div id="sliderValue" class="weui-slider-box__value">100</div>
                        </div>
                    </div>
                </div>


            </div>

            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>

        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary commentsptijiao" data-id="$gid" data-order_id="{$_GET[docmt]}" data-shid="$v[shid]" >{lang xigua_hs:tijiao}</a>
            <a class="weui-btn weui-btn_default close-popup" href="javascript:window.history.go(-1);" >{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>

<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div id="popctrl" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__modal">

        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn weui-btn_primary" data-method="confirm" onclick="$.closePopup('#popctrl');$('#comment_popup').popup();">{lang xigua_hb:queding}</a>
            <a class="weui-btn weui-btn_default" data-method="destroy" onclick="$.closePopup('#popctrl');$('#comment_popup').popup();">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<script>var itar=[];$('#slider1').slider();
<!--{if $_GET[docmt]}-->$('#comment_popup').popup();<!--{/if}-->
</script>
<!--{template xigua_sp:enter_up}-->
<!--{/if}-->
<!--{/if}-->