<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="tuan_recommend" id="tuan_recommend">
    <div class="tuan_recommend_title"><span class="tuan_recommend_title_text"><!--{if $ac=='index'}-->{lang xigua_sp:cnxh}<!--{else}-->{lang xigua_sp:wntj}<!--{/if}--></span></div>

    <div class="weui-cells fixbanner before_none mt0">

        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="$SCRITPTNAME?id=xigua_sp&mobile=2" class="weui-navbar__item weui_bar__item_on ">
                <span>{lang xigua_sp:tj}</span>
            </a>

            <!--{loop $cat_list $cat}-->
            <a href="$SCRITPTNAME?id=xigua_sp&ac=cat&catid={$cat[id]}" class="weui-navbar__item">
                <span>$cat[name]</span>
            </a>
            <!--{/loop}-->
        </div>

    </div>
    <ul class="goodlist mt0" id="list" style="padding-top:0"> </ul>
</div>
<!--{template xigua_hb:loading}-->
<!--{if $ac=='view' && $v[shid]}-->
<script>var loadingurl = _APPNAME+'?id=xigua_sp&ac=cat_li&shid={$v[shid]}&not=$gid&inajax=1&page=';</script>
<!--{else}-->
<script>var loadingurl = _APPNAME+'?id=xigua_sp&ac=cat_li&cat_id={$v[hangye_id1]}&inajax=1&page=';</script>
<!--{/if}-->