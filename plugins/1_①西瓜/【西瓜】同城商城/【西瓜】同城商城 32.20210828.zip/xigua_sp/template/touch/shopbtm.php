<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="wei_fixNav_v2" id="nav-menu-container" style="">
    <ul>
        <li>
            <a class="custom_ " href="$SCRITPTNAME?id=xigua_sp{$urlext}"><i class="vm iconfont icon-index "></i> {lang xigua_sp:sy}</a>
        </li>
        <li>
            <a class="custom_ sh_jump" href="javascript:;" data-id="{$sh['shid']}"><i class="vm iconfont icon-shop "></i> {lang xigua_sp:dpxq}</a>
        </li>
        <li style="display:none;">
            <a href="javascript:void(0)" class="custom" onclick="$(this).toggleClass('on');">{lang xigua_sp:spfl}</a>
        </li>
        <li>
            <a href="javascript:void(0)" class="custom" onclick="$(this).toggleClass('on');">{lang xigua_sp:lxkf}</a>
            <div class="pop">
                <div class="inner">
                    <a href="javascript:;" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_sp:calx}", "{lang xigua_sp:lxwx}");'>{lang xigua_sp:wxkf}</a>
                    <a href="tel:$sh[tel]">{lang xigua_sp:kfdh}</a>
                </div>
            </div>
        </li>
    </ul>
</div>
