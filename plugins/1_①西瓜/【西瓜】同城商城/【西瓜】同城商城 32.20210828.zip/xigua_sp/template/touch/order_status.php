<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<style>.weui-btn_mini{padding:0 5px}</style>
<!--{if $v['exp_method']=='kuaidi' || $v[exp_method]=='hdfk'}-->
    <!--{if !$_GET[manage]}-->
        <!--{if $v[jumpurl] }-->
            <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default cancel_order " data-id="$v[id]">{lang xigua_sp:qxdd}</a>
            <a href="$v[jumpurl]" class="mt0 weui-btn weui-btn_mini weui-btn_primary">{lang xigua_sp:ljzf}</a>
        <!--{elseif in_array($v[status], array(2,6)) && ($v[shou_ts]==-1||$v[fa_ts]==-1)}-->
        <!--{if $v[fa_ts]>1}-->
            <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default qrsh" data-id="$v[id]" data-title="{lang xigua_sp:qrsh}?<p>{lang xigua_sp:qsdsphzqr}</p>">{lang xigua_sp:qrsh}</a>
        <!--{else}-->
        <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_sp:dfh}</a>
        <!--{/if}-->
        <!--{elseif in_array($v[status], array(2,6)) && $v[shou_ts]>1}-->

<!--{if $v[pj_ts]>1}-->
<a href="$SCRITPTNAME?id=xigua_sp&ac=view&gid=$v[gid]{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_sp:zcgm}</a>
<!--{else}-->
<a href="$SCRITPTNAME?id=xigua_sp&ac=view&gid=$v[gid]&docmt={$v[id]}{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default mt0">{lang xigua_sp:ljpj}</a>
<!--{/if}-->

        <!--{elseif in_array($v[status], array(3,4,7)) }-->
            <a href="$SCRITPTNAME?id=xigua_sp&ac=view&gid=$v[gid]{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_sp:zcgm}</a>
        <!--{/if}-->
    <!--{else}-->
        <!--{if $v[jumpurl] }-->
        <a href="javascript:;" class="mt0 weui-btn weui-btn_mini weui-btn_primary">{lang xigua_sp:ddzf}</a>
        <!--{elseif $v[status] == 5}-->
        <a class="mt0 weui-btn weui-btn_mini weui-btn_primary" href="javascript:;">{lang xigua_sp:ptz}</a>
        <!--{elseif $v[status] == 3}-->
        <a class="mt0 weui-btn weui-btn_mini weui-btn_primary dotk" href="javascript:;" data-redund="$v[refund_id]">{lang xigua_sp:cltk}</a>
        <!--{elseif in_array($v[status], array(2,6)) && ($v[shou_ts]==-1||$v[fa_ts]==-1)}-->
        <!--{if $v[fa_ts]>1}-->
        <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_sp:ddqrsh}</a>
        <!--{else}-->
        <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default fahuo" data-id="$v[id]" data-title="{lang xigua_sp:qrfh}<p class='f14'>{lang xigua_sp:shr}: {$v[realname]} {$v[mobile]} <br>{lang xigua_sp:dz}: {$v[addr]}</p>">{lang xigua_sp:djfh}</a>
        <!--{/if}-->
        <!--{elseif in_array($v[status], array(2,6)) && $v[shou_ts]>1}-->
        <a class="f12 block">{lang xigua_sp:ysh} {$v[shou_ts_u]}</a>
        <!--{elseif in_array($v[status], array(3,4,7)) }-->
        <!--{/if}-->
    <!--{/if}-->
<!--{elseif $v['exp_method']=='daodian'}-->
<!--{if $v[priceshot][kami]}-->
<span class="f12">{lang xigua_sp:xnkm}</span>
<!--{else}-->
    <!--{if !$_GET[manage]}-->
        <!--{if $v[jumpurl] }-->
            <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default cancel_order " data-id="$v[id]">{lang xigua_sp:qxdd}</a>
            <a href="$v[jumpurl]" class="mt0 weui-btn weui-btn_mini weui-btn_primary">{lang xigua_sp:ljzf}</a>
        <!--{elseif $v[status] == 5}-->
            <a class="mt0 weui-btn weui-btn_mini weui-btn_primary" href="$SCRITPTNAME?id=xigua_sp&ac=invite&ptlog_id=$v[id]{$urlext}">{lang xigua_sp:yqhyp}</a>
        <!--{elseif in_array($v[status], array(2,6)) && ($v[shou_ts]==-1||$v[fa_ts]==-1)}-->
            <a class="pt_btn_dft weui-btn weui-btn_mini use-btn" data-tip="{lang xigua_sp:csgdy}" data-chushi="{lang xigua_sp:ddcs}" data-src="$SCRITPTNAME?id=xigua_sp&ac=com&do=showqr&ptlog_id={$v[id]}{$urlext}">{lang xigua_sp:djsy}</a>
        <!--{elseif in_array($v[status], array(2,6)) && $v[shou_ts]>1}-->
<!--{if $v[pj_ts]>1}-->
<a href="$SCRITPTNAME?id=xigua_sp&ac=view&gid=$v[gid]{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_sp:zcgm}</a>
<!--{else}-->
<a href="$SCRITPTNAME?id=xigua_sp&ac=view&gid=$v[gid]&docmt={$v[id]}{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default mt0">{lang xigua_sp:ljpj}</a>
<!--{/if}-->
        <!--{elseif in_array($v[status], array(3,4,7)) }-->
            <a href="$SCRITPTNAME?id=xigua_sp&ac=view&gid=$v[gid]{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_sp:zcgm}</a>
        <!--{/if}-->
    <!--{else}-->
            <!--{if $v[jumpurl] }-->
                <a href="javascript:;" class="mt0 weui-btn weui-btn_mini weui-btn_primary">{lang xigua_sp:ddzf}</a>
            <!--{elseif $v[status] == 5}-->
                <a class="mt0 weui-btn weui-btn_mini weui-btn_primary" href="javascript:;">{lang xigua_sp:ptz}</a>
            <!--{elseif $v[status] == 3}-->
                <a class="mt0 weui-btn weui-btn_mini weui-btn_primary dotk" href="javascript:;" data-redund="$v[refund_id]">{lang xigua_sp:cltk}</a>
            <!--{elseif in_array($v[status], array(2,6)) && ($v[shou_ts]==-1||$v[fa_ts]==-1)}-->
                <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_sp:yfkdhx}</a>
            <!--{elseif in_array($v[status], array(2,6)) && $v[shou_ts]>1}-->
                <a class="f12 block">{lang xigua_sp:yhxhxsj} {$v[shou_ts_u]}</a>
            <!--{/if}-->
    <!--{/if}-->

<!--{/if}-->



<!--{/if}-->
<!--{if $ac !='order_profile'}-->
<!--{if !$v[jumpurl]}-->
<a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default sp_good_od mt0" data-id="$v[id]" <!--{if $_GET[manage]}-->data-manage="1"<!--{/if}-->>{lang xigua_sp:ddxq}</a>
<!--{/if}-->
<!--{/if}-->

<!--{if $v[goodshot][allow_tk] && $v['allowtk'] && $v[exp_method]!='hdfk'}-->
<a href="javascript:;" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default mt0 dotuikuan" data-ptlogid="{$v[id]}">{lang xigua_sp:th}</a>
<!--{/if}-->

<!--{if !$_GET[manage] && $v['status']==3 && $v['refund_id']>0}-->
<a href="javascript:;" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default mt0 canceltuikuan" data-ptlogid="{$v[id]}">{lang xigua_sp:qxtk}</a>
<!--{/if}-->