<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<!--{eval $price_name = explode('###', $v[priceshot]['name'])}-->
<div class="pt_order_li">
    <div class="pt_shlink">
        <a style="display: none" class="sh_jump" data-id="{$v['shid']}">
            <img class="confirm_shlogo" src="{$v['sh'][logo]}" />
            <span class="f13">{$v['sh'][name]}</span>
            <i class="f13 iconfont icon-jinrujiantou"></i>
        </a>
        <a>
            <span>{lang xigua_sp:ddbh} : </span>
            <span class="f13">{$v['order_id']}</span>
        </a>
        <!--{if $v[status]==4}-->
        <div class="ptcolor y f14"> {lang xigua_sp:status_44}</div>
        <!--{else}-->
        <!--{if $v[exp_method]=='hdfk'}-->
        <div class="ptcolor y f14">{lang xigua_sp:hdfk}</div>
        <!--{else}-->
        <div class="ptcolor y f14"> {$status_font[$v[status]]}</div>
        <!--{/if}-->
        <!--{/if}-->
    </div>
    <div class="sp_good_od weui-cell weui-cell_access before_none after_none" style="display:block;overflow:hidden" data-id="$v[id]" <!--{if $_GET[manage]}-->data-manage="1"<!--{/if}-->>
        <div class="weui-cell__hd z">
            <label class="weui-label " style="width:4.75rem">
                <img style="width: 4rem;height: 4rem;" src="{eval echo $v[goodshot][fengmian] ? $v[goodshot][fengmian] : ($v[goodshot][album][0] ? $v[goodshot][album][0] : $v[goodshot][append_img_ary][0])}" />
            </label>
        </div>
        <div class="weui-cell__bd ">
            <p class="f14 c3">{$v[goodshot][title]}</p>
            <!--{loop $v[goodshot][spgg_ary] $_spk $_spn}-->
            <p class="f12 c9">{$_spn[name]}: {$price_name[$_spk]}</p>
            <!--{/loop}-->
            <!--{if $v[priceshot][price_jf]>0}-->
            <div class="f14 cl ptcolor">$v[priceshot][price_jf]{$_G['setting']['extcredits'][$config['credit_type']]['title']} / {lang xigua_sp:j}  <span class="y">x {$v[gnum]}</span></div>
            <!--{else}-->
            <div class="f14 cl ptcolor">&yen;{$v[unit_price]} / {lang xigua_sp:j}  <span class="y">x {$v[gnum]}</span></div>
            <!--{/if}-->
        </div>
    </div>
    <div class="pt_func  weui-cell before_none">
        <div class="weui-cell__bd f12">
            <!--{if $v[priceshot][price_jf]>0}-->
            {lang xigua_sp:sfk}: <em class="ptcolor">{echo $v[priceshot][price_jf] * $v[gnum]} {$_G['setting']['extcredits'][$config['credit_type']]['title']}</em>
            <!--{else}-->
            <!--{if $v[exp_method]=='hdfk'}-->{lang xigua_sp:hdfk}:<!--{else}-->{lang xigua_sp:sfk}:<!--{/if}--> <em class="ptcolor">&yen;{$v[pay_money]}</em> (<!--{if $v[yunfee]>0}-->{lang xigua_sp:yf}: {$v[yunfee]} {lang xigua_sp:yuan}<!--{else}-->{lang xigua_sp:myf}<!--{/if}-->)
            <!--{/if}-->
        </div>
        <div class="weui-cell__ft">

            <!--{template xigua_sp:order_status}-->
        </div>
    </div>
    <div class="weui-cell before_none pt0">
        <div class="weui-cell__bd f12"><img src="{avatar($v[uid], middle, true)}" class="pt_usr" style="width:24px;height:24px;" > $v['username']</div>
        <div class="weui-cell__ft f12">
            {lang xigua_sp:xdsj} : {$v[crts_u]}
        </div>
    </div>
</div>
<!--{/loop}-->