<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $sp_tabbar}-->
<!--{eval
$custom_nav = C::t('#xigua_sp#xigua_sp_nav')->fetch_index();
$navcount = count($custom_nav);
$is_off = 1;
$curturl = hb_currenturl();
}-->
<!--{if !$navcount}-->
<div class="weui-tabbar <!--{if $showfloatapp}-->none<!--{/if}-->">
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hb{$urlext}" class="weui-tabbar__item <!--{if $sp_config[hidenav1]}-->none<!--{/if}-->">
        <i class="iconfont icon-index weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">{lang xigua_hb:shouye}</p>
    </a>
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_sp{$urlext}" class="weui-tabbar__item <!--{if $ac=='index'&&$_GET[id]=='xigua_sp'}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-gouwudai weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">{lang xigua_sp:shangcheng}</p>
    </a>
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_sp&ac=cate{$urlext}" class="weui-tabbar__item <!--{if $ac=='cate'}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-fenleisousuo1 weui-tabbar__icon " style="font-size: 23px;"></i>
        <p class="weui-tabbar__label">{lang xigua_sp:fl}</p>
    </a>
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_sp&ac=gwc&needlogin=1{$urlext}" class="weui-tabbar__item <!--{if $ac=='gwc'}-->weui-bar__item_on{eval $hason=1;}<!--{/if}-->">
        <i class="iconfont icon-gouwuche weui-tabbar__icon "></i>
        <p class="weui-tabbar__label">{lang xigua_sp:gwc}</p>
        <span id="gwcnum" class="weui-badge" style="position:absolute;top:-2px;display:none">0</span>
    </a>
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_sp&ac=wode&needlogin=1{$urlext}" class="weui-tabbar__item <!--{if  strpos($ac,'wode')!==false||strpos($ac,'order')!==false}-->weui-bar__item_on<!--{/if}-->">
        <span style="display: inline-block;position: relative;">
            <i class="iconfont icon-wode weui-tabbar__icon"></i>
        </span>
        <p class="weui-tabbar__label">{lang xigua_sp:wodo}</p>
    </a>
</div>
<!--{else}-->
<div class="weui-tabbar<!--{if $showfloatapp}--> none<!--{/if}-->">
    <!--{loop $custom_nav $loop_k $loopin}--><!--{eval
$highlight = '&high='.$loop_k;
$inlink = $loopin['adlink'].$highlight;
$is_on = !$is_on && (  strpos($curturl,$inlink)!==false || strpos($curturl,$highlight)!==false  || ($_GET['high'] && $_GET['high']==$loop_k)  );
if($is_on):
    $loopin[icon] = $loopin[icon2]?$loopin[icon2]:$loopin[icon];
endif;
}-->
    <!--{if $loopin[up]}-->
    <a href="{$inlink}" class="weui-tabbar__item weui-bar__item_on showpubfont"><div class="pub_circle"></div>
        <!--{if $loopin[icon2]}-->
        <img src="$loopin[icon2]" class="tabcon" />
        <!--{/if}-->
        <p class="weui-tabbar__label pub_circle_p" style="color:#777!important">{$loopin[name]}</p>
    </a>
    <!--{else}-->
    <a href="{$inlink}" class="weui-tabbar__item <!--{if $is_on}-->weui-bar__item_on<!--{/if}-->">
        <!--{if $loopin[icon]}-->
        <img src="$loopin[icon]" class="tabcon3" />
        <!--{/if}-->
        <p class="weui-tabbar__label">{$loopin[name]}</p>
    </a>
    <!--{/if}-->
    <!--{/loop}-->
</div>
<!--{/if}-->
<!--{/if}-->