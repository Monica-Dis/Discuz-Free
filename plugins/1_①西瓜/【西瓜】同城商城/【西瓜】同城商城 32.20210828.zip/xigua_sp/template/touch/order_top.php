<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $v[refund_id]}-->
<!--{eval $refund= C::t('#xigua_sp#xigua_sp_refund')->fetch_by_id($v[refund_id]);}-->
<!--{/if}-->
<!--{eval $status = $v[status];}-->
<!--{if $v[status]==5}-->
<div class="pro_top main_bg" style="background-image:url(source/plugin/xigua_sp/static/status_{$v[status]}.png);">
    <p>{lang xigua_sp:ptwcg}</p>
    <p>{lang xigua_sp:yqxhb}</p>
</div>
<!--{elseif in_array($v[status], array(3,4,7))}-->
<div class="pro_top main_bg">
    <p>{lang xigua_sp:ddyqx}</p>
    <!--{if $v[status]==7}-->
    <p>{lang xigua_sp:pdsbytk}</p>
    <!--{/if}-->
    <!--{if $v[status]==3}-->
    <p>{lang xigua_sp:status_3} <span class="f12">{lang xigua_sp:sqsj} $refund[crts_u]</span></p>
    <!--{/if}-->
    <!--{if $v[status]==4 && $refund[upts_u]}-->
    <p>{lang xigua_sp:status_44} <span class="f12">{lang xigua_sp:tksj} $refund[upts_u]</span></p>
    <!--{/if}-->
</div>
<!--{elseif in_array($v[status], array(2,6))}-->
<div class="pro_top main_bg"  <!--{if $v['exp_method']=='daodian'}--><!--{/if}-->>
    <!--{if $v[exp_method]!='hdfk'}-->
    <p>{$status_font[$status]}</p>
    <!--{else}-->
    <p>{lang xigua_sp:hdfk}</p>
    <!--{/if}-->
    <!--{if $v['exp_method']=='kuaidi' || $v['exp_method']=='hdfk'}-->
        <!--{if $v[fa_ts]==-1}-->
        <p>{lang xigua_sp:dfh}</p>
        <!--{elseif $v[shou_ts]==-1}-->
        <p>{lang xigua_sp:dshuo}</p>
        <p>{lang xigua_sp:kd}: {$v[yundan_gs]}</p>
        <p>{lang xigua_sp:ydh}: {$v[yundan]}</p>
        <!--{elseif $v[shou_ts]>1}-->
        <p>{lang xigua_sp:ysh} {$v[shou_ts_u]}</p>
        <p>{lang xigua_sp:kd}: {$v[yundan_gs]}</p>
        <p>{lang xigua_sp:ydh}: {$v[yundan]}</p>
        <!--{/if}-->
    <!--{if $v[yundan]}-->
    <!--{if $sp_config[kdcode]}-->
    <a id="seckdcode" style="display:none" href="https://m.kuaidi100.com/result.jsp?nu={$v[yundan]}" target="_blank">{lang xigua_sp:kdgz}&raquo;</a>
    <!--{else}-->
    <a href="https://m.kuaidi100.com/result.jsp?nu={$v[yundan]}" target="_blank">{lang xigua_sp:kdgz}&raquo;</a>
    <!--{/if}-->
    <!--{/if}-->
    <!--{elseif $v['exp_method']=='daodian'}-->
<!--{if $v[priceshot][kami]}-->
<p>{lang xigua_sp:xnkm}: {$v[hxcode]}</p>
<!--{else}-->
        <!--{if $v[fa_ts]==-1}-->
<!--{if !$_GET[manage]}-->
    <img style="margin:10px 0" src="$SCRITPTNAME?id=xigua_sp&ac=com&do=showqr&ptlog_id={$v[id]}{$urlext}" />
    <p>{lang xigua_sp:csgdy}</p>
<!--{/if}-->
            <p>{lang xigua_sp:wsyhxm} {$v[hxcode]}</p>
        <!--{elseif $v[shou_ts]==-1}-->
            <img style="margin:10px 0" src="$SCRITPTNAME?id=xigua_sp&ac=com&do=showqr&ptlog_id={$v[id]}{$urlext}" />
<p>{lang xigua_sp:csgdy}</p>
            <p>{lang xigua_sp:wsyhxm} {$v[hxcode]}</p>
        <!--{elseif $v[shou_ts]>1}-->
            <p>{lang xigua_sp:yhxhxsj} {$v[shou_ts_u]}</p>
        <!--{/if}-->
    <!--{/if}-->
<!--{/if}-->
</div>
<!--{/if}-->



