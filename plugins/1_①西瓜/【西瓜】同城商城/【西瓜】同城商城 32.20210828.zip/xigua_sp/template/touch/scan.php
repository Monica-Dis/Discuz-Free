<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<div class="page__bd">

<!--{eval $tabbar=0;}-->
<!--{template xigua_sp:footer}-->
<script>
function hxcheck(){
    <!--{if !$access}-->
    $.prompt("{lang xigua_hs:qsrhxmm}", function(text) {
        $.showLoading();
        $.ajax({
            type: 'post',
            url: '$SCRITPTNAME?id=xigua_hs&ac=setpwd&type=check&inajax=1&shid={$shid}',
            data:{formhash:'{FORMHASH}',  hxpwd:text},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                var sar = s.split('|');
                tip_common(s);
                setTimeout(function () {
                    window.location.reload();
                }, 1800);
            },
            error: function () {
                $.hideLoading();
            }
        });

    }, function() {
        window.location.reload();
    });
    return false;
    <!--{/if}-->
    <!--{if !$v || $v[payts]<1}-->
    $.alert("{lang xigua_sp:yhqbcz}", "{lang xigua_sp:ts}", function() {
        window.location.href = _APPNAME+"?id=xigua_sp&mobile=2"+_URLEXT;
    });
    return false;
    <!--{/if}-->
}
hxcheck();
</script>