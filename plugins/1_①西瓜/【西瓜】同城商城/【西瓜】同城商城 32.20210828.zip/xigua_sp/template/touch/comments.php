<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<style>.hs_cmt_var{display:none}</style>
<div class="page__bd ">
    <!--{template xigua_hb:common_nav}-->
    <!--{template xigua_sp:viewtools}-->

    <div id="comment_profile" class="mt0">

        <div class="weui-cells__title weui_title mt0 f15 c30 border_bottom cl" >
            <a href="$SCRITPTNAME?id=xigua_sp&ac=view&gid={$gid}{$urlext}" style="float: left;width: calc(100% - 100px);">$good[title]</a>
            <a class="y c9 pr_1" href="javascript:;" style="width: 100px;text-align: right;">
                {lang xigua_sp:hp}{$avgstar}%
            </a>
        </div>

        <div class="view_content mod-post x-postlist p0 comment_ul" id="list"></div>
        <!--{template xigua_hb:loading}-->
    </div>

</div>
<!--{eval $sp_tabbar = 1;$tabbar=0;}-->
<script>
    loadingurl = _APPNAME+'?id=xigua_sp&ac=comment&gid={$gid}&inajax=1&pagesize=10&page=';
</script>
<!--{template xigua_sp:footer}-->