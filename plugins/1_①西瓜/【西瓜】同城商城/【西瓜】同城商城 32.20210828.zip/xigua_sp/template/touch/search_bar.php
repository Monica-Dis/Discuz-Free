<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
$showsearch = ($ac=='search');
if($_GET['shid']):
$sp_config[schtxt] = lang_sp('ssbd',0);
endif;
}-->
<div class="site_header">
    <!--{if $showsearch}-->
    <form method="get" action="$SCRITPTNAME" id="dosearchform">
        <input name="id" value="xigua_sp" type="hidden">
        <input name="ac" value="cat" type="hidden">
        <input type="hidden" name="st" value="$_GET[st]">
        <input type="hidden" name="idu" value="$_GET[idu]">
        <input type="hidden" name="shid" value="$_GET[shid]">
        <!--{/if}-->
    <header class="x_header cl f15" <!--{if $showsearch}-->style="margin-right:40px"<!--{/if}-->>
        <!--{if !IN_PROG}-->
        <a class="z f14" href="javascript:window.history.go(-1);" style="color:#5e606b;"><i class="iconfont icon-fanhuijiantou w15"></i></a>
        <!--{/if}-->
        <!--{if $showsearch}-->
        <a href="javascript:" class="search_bar_btn main_color" id="dosearch">{lang xigua_sp:search}</a>
        <!--{else}-->
        <a class="y sidectrl view_ctrl" style="color:#5e606b;"><i class="iconfont icon-gengduo1 f22"></i></a>
        <!--{/if}-->

        <div class="navtitle pr">
            <a class="new_search" href="$SCRITPTNAME?{echo http_build_query($_GET)}&id=xigua_sp&ac=search">{echo $keyword ? $keyword : $sp_config[schtxt]}</a>
            <!--{if $showsearch}-->
            <input type="search" class="serchinput" id="searchInput" placeholder="{$sp_config[schtxt]}" required="required" name="keyword" value="$keyword">
            <!--{/if}-->
        </div>
    </header>

<!--{if $showsearch}-->
</form>
<!--{/if}-->

</div>