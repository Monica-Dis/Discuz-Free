<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<style>.fixbanner_in .ajaxcat{min-width:28px}</style>
<!--{if $sp_config[pindaologo]}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$sp_config[pindaologo]" /></div><!--{/if}-->
<div class="page__bd ">

    <header class="x_header bgcolor_11 cl  weui-flex f15" style="background:transparent!important;position:absolute">
        <!--{if $_G['cache']['plugin']['xigua_st']['showfz'] && $sp_config[allowfz]}-->
        <a class="z x_logo" href="javascript:;" onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_sp{$urlext}&mobile=2");}{$urlext}'">
            <span class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
        </a>
        <!--{else}-->
<a class="z x_logo" href="$SCRITPTNAME?id=xigua_sp$urlext">
<!--{if strpos($sp_config['logoindex'],'/')!==false}--><img src="$sp_config['logoindex']" />
<!--{else}--><span style="margin:0 .75rem">$sp_config['logoindex']</span><!--{/if}--></a>
        <!--{/if}-->

        <form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
            <input type="hidden" name="id" value="xigua_sp"> <input type="hidden" name="ac" value="cat">
            <input type="hidden" name="st" value="$_GET[st]"> <input type="hidden" name="idu" value="$_GET[idu]">
            <input name="keyword" class="x_logo_input" type="text" value="" placeholder="{echo $keyword ? $keyword : $sp_config[schtxt]}" x-webkit-speech="" style="background: rgba(255,255,255,.8)">
            <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
        </form>
    </header>

    <!--{if $topnavslider}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $topnavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $topnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->

<div class="index_card"><!--{if $jing_list}-->
    <nav class=" nav-list cl swipe" style="padding-top:3px">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $jing_list $k $n}-->
                    <!--{if $k && $k%10==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li>
                        <a href="{$n['adlink']}">
                            <span>
                                <img src="$n['icon']"/>
                            </span>
                            <em class="m-piclist-title">{$n['name']}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position position1">
                <!--{loop $jing_count $k $v}-->
                <li {if $k==0} class="current" {/if}></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </nav>
    <!--{/if}--><!--{if $sp_config[toutitle]}-->
    <div class="weui-cells mt0 after_none" style="border-radius:10px">
        <div class="chip-row">
            <div class="toutiao">$sp_config[toutitle]</div>
            <div class="toutiao-slider swiper-container" id="newsSlider">
                <ul class="swiper-wrapper">
                    <!--{eval $toutiaoitems = array_filter(explode("\n", trim($sp_config['toutext'])));}-->
                    <!--{loop $toutiaoitems $toutiaoitem}-->
                    <!--{eval list($font, $link)= explode(",", trim($toutiaoitem)); }-->
                    <li class="swiper-slide"> <a href="$link">$font</a> </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
    </div>
<!--{/if}--></div>

    <!--{if $_G['cache']['plugin']['xigua_sp']['bighui'] || $_G['cache']['plugin']['xigua_sp']['smallhui']}-->
    <div class="index_card weui-cells after_none before_none">
        <!--{eval list($link1, $icon1) = explode(",", trim($_G['cache']['plugin']['xigua_sp']['bighui']));}-->
        <!--{if $icon1}--><div class="chip-l" style="padding:0"><a href="$link1" class="bigh" style="background-image:url($icon1)"></a></div><!--{/if}-->

        <!--{eval $smallhuis = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_sp']['smallhui'])));}-->
        <!--{loop $smallhuis $smallhui}-->
        <!--{eval list($font1, $font2, $icon, $link)= explode(",", trim($smallhui)); }-->
        <div class="chip">
            <div>
                <p><a style="display:block" href="$link">$font1</a></p>
                <p><a style="display:block" href="$link">$font2</a></p>
            </div>
            <a href="$link"><img src="$icon"></a>
        </div>
        <!--{/loop}-->
    </div>
    <!--{/if}-->
<!--{loop $index_cards $_k $_v}-->
<div class="index_card cl">
<!--{loop $_v $__k $__v}-->
        <!--{if $__v[adimage] && $__v[icon]}-->
        <a class="big-space" href="{$__v[adlink]}">
            <p class="title" >{$__v[name]}</p>
            <p class="des" >{$__v[name2]}</p>
            <img src="{$__v[icon]}">
            <img src="{$__v[adimage]}">
        </a>
        <!--{else}-->
        <a class="small-space" href="{$__v[adlink]}">
            <p class="title" >{$__v[name]}</p>
            <p class="des" >{$__v[name2]}</p>
            <img src="{$__v[icon]}">
        </a>
        <!--{/if}-->
<!--{/loop}-->
</div>
<!--{/loop}-->
<div class="index_top2">
    <!--{template xigua_sp:tuijian}-->
</div>
</div>
<!--{eval $sp_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_sp:footer}-->


<!--{if $_G['cache']['plugin']['xigua_st']['showfz'] && $_G['cache']['plugin']['xigua_hs'] && $_G['cache']['plugin']['xigua_st']['dingwei'] && !getcookie('setcitygeo')}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script>
function autolbshs(){
hs_getlocation(function (position) {
    var citylat = (position.latitude||position.lat);
    var citylng = (position.longitude||position.lng);
    $.ajax({
        type: 'GET',
        url: _APPNAME + '?id=xigua_hs&ac=getloc&checkst=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            var m = s.split('|');
            if('success' == m[0]){
                var _t = m[1].split(',');
                if(_t[0]>0 && _t[0]!='{$_GET[st]}'){
                    $.confirm("{lang xigua_hb:dqdws}"+_t[1]+'{lang xigua_hb:setcitygeo2}', function() {
                        window.location.href = _APPNAME+"?id=xigua_sp&st="+_t[0];
                        hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                    }, function() {
                        hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                    });
                }else{
                    hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
                }
            }else{}
        }
    });
});
}
if(typeof wx!='undefined'){
    wx.ready(function () { autolbshs(); });
}else{
    setTimeout(function(){ autolbshs(); }, 300);
}
</script><!--{/if}-->