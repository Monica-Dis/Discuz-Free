<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<div class="page__bd bgf">
<style>.new_search, #searchInput{background:#f5f5f5}</style>
    <!--{template xigua_sp:search_bar}-->

<!--{if $reckys}-->
    <div id="reckys">
    <div class="weui-cells__title">{lang xigua_sp:zjss}
    <a href="javascript:;" class="delrecent y"><i class="iconfont icon-shanchu vm"></i>{lang xigua_sp:qk}</a>
    </div>
    <div class="weui-cells before_none after_none">
        <div class="recenttags cl">
            <!--{loop $reckys $_k $_v}-->
            <span><a href="{$SCRITPTNAME}?id=xigua_sp&ac=cat&keyword={$_k}">{$_k}</a></span>
            <!--{/loop}-->
        </div>
    </div>
    </div>
<!--{/if}-->


    <div class="weui-cells__title">{lang xigua_sp:rmss}</div>
    <div class="weui-cells before_none after_none">
        <div class="recenttags cl">
            <!--{eval $sp_config[hotsearch] = explode("\n", trim($sp_config[hotsearch]))}-->
            <!--{loop $sp_config[hotsearch] $_k $_v}-->
            <span><a href="{$SCRITPTNAME}?id=xigua_sp&ac=cat&keyword={echo trim($_v)}">{echo trim($_v)}</a></span>
            <!--{/loop}-->
        </div>
    </div>


</div>
<!--{eval $sp_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_sp:footer}-->
<script>
$(document).on('click','.delrecent', function () {
    hb_setcookie('reckys', '');
    $('#reckys').remove();
});
</script>