<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<style>.left_float{z-index:501}
.pupc-btm{position:relative;overflow:visible;width:100%;background:#fff;display:flex;transform:translate(0,0);transition:transform .3s;font-size:.7rem}
.pupc-btm-in{width:100%;flex:1;height:16rem;overflow-y:scroll;overflow-x:hidden;-webkit-overflow-scrolling:touch;position:relative}
.pupc-btm-in a{line-height:2rem;height:2rem;display:block;padding:0 .75rem;color:#666;text-decoration:none;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
.pupc-btm-in a:last-child:before{display:none}
.post_com_tag{padding:.75rem .75rem .55rem;background:#fff}
.post_com_tag:empty{display:none}
.post_com_tag:empty{display:none}
.post_com_tag .weui-btn_default{padding-right:1.25rem!important;background:url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAACHUlEQVRoQ9XaTU7CQBTA8ffKzo0kUGEnKRfwAhq8gUeQG+hNvAEewRvgDeACxLozEhKMxuU805YiLaWdjzftlA2k4eP/60DTmYLBwF8AQheFeFx9bl6gBbfxRe+OEGcAGGIw7IcIeJl0i+nqY/PssmE87N0DeLOokYDeceT7V55Hr4h47joiE0/0JQROMIpuA6IoPlyvlzHAdcSp+Kh7D3AVURZ/BHANURVfCHAFIRN/EtA0Qja+FNAUQiW+ElA3QjVeClAXQideGmAboRuvBLCFMIlXBnAjTOO1AFwIjnhtgCmCK94IoIvgjDcGqCK441kAsggb8WyAKoSteFZAjBj2Jx3AefQ4uYlpcr+bw+6mgdFM6v85Zo8yExqzt0penZt0/yLgWbSdLMSzj0C6AxJEvOwRbyKiHyHwmnPPp5/FPgJHo0AUbfoWAm9aATj8CsV7fzfxJqKtEHjLjWAdgWh5ptOBRcmPmB3BBtitLc0RsZsegdJVvtxhlBXBAiiLz/6w94dTNoQxQCbeJsIIoBJvC6EN0Im3gdACmMRzI5QBHPGcCCUAZzwXQhpgI54DIQWwGW+KqATUEW+CKAXUGa+LOAloIl4HUQhoMl4VcQRwIV4FUXSRr/CUmGO+rPMeVafi+cusTsXLjMThhW4n46sQ6V8NnI4vQ2Aw9N8QYJSfBup8X+t4TXbdCUIMBv4SkLoo6KFVf7fx8AkIt39Ozxjpmu2SFAAAAABJRU5ErkJggg==') no-repeat right .5rem center;background-size:.5rem}
</style>
<div id="popup_hangye" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal" style="z-index:503">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hs:queding}</a>
                <h1 class="title">{lang xigua_sp:qxz}{lang xigua_sp:spfl}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="border_bottom post_com_tag post-tags cl" id="p1"><!--{loop $hyids $_k $_v}--><a id="id_p1{$_v}" data-form="hangye" data-ld="p1" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">{echo diconv($new_ary[$_v][name], 'UTF-8', CHARSET)}<input name="form[hangye][]" type="hidden" value="$_v"></a><!--{/loop}--></div>
            <div class="pupc-btm">
                <div class="pupc-btm-in">
                    <!--{loop $jsary $_k $_v}-->
                    <a class="border_bottom check1 <!--{if $_k==0}-->main_color<!--{/if}-->" data-title="{$_v[id]}" data-titfix="p1_" >{echo diconv($_v[name], 'UTF-8', CHARSET)}</a>
                    <!--{/loop}-->
                </div>
                <div class="pupc-btm-in border_left">
                    <!--{loop $jsary $_k $_v}-->
                    <div class="pupc-btm-in_list <!--{if $_k>0}-->none<!--{/if}-->" id="p1_{$_v[id]}">
                        <!--{loop $_v[sub] $__v}-->
                        <a class="check2 pupc_check_a border_bottom" data-form="hangye" data-ld="p1" data-title="p1{$__v[id]}" data-value="{$__v[id]}">{echo diconv($__v[name], 'UTF-8', CHARSET)}</a>
                        <!--{/loop}-->
                    </div>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).on('click','.check1', function () {
        var that = $(this);
        that.siblings().removeClass('main_color');
        that.addClass('main_color');
        that.parent().parent().find('.pupc-btm-in_list').hide();
        $('#'+that.data('titfix')+that.data('title')).show();
    });
    $(document).on('click','.check2', function(){
        var that = $(this);
        var dt = that.data('title'),dv = that.data('value'), tame = that.html();
        if($('#'+that.data('ld')).find('a').length>{echo $sp_config[maxhy]-1}){
            $.toast('{lang xigua_hs:zuiduo1}{$sp_config[maxhy]}{lang xigua_hs:zuiduo2}', 'error');
            return false;
        }
        $('#id_'+dt).remove();
        $('#'+that.data('ld')).append('<a id="id_'+dt+'" data-ld="'+that.data('ld')+'" data-form="'+that.data('form')+'" class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;">'+tame+'<input name="form['+that.data('form')+'][]" type="hidden" value="'+dv+'" /></a>');
        sync_formid(that.data('ld'), that.data('form'));
    });
    $(document).on('click','.post_com_tag .weui-btn_default', function () {
        var that = $(this);
        that.remove();
        sync_formid(that.data('ld'), that.data('form'));
    });
    function sync_formid(apend, dform){
        var val = '';
        $('#'+apend).find('a').each(function () {  val+=',' + $(this).text(); });
        $('#'+dform).val(val.substr(1));
    }
</script>