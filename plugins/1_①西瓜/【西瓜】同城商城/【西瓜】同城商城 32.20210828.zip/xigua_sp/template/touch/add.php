<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd">
<form action="$SCRITPTNAME?id=xigua_sp&ac=add" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}" >
    <input type="hidden" name="form[id]" value="{$old_data[id]}" >
    <input type="hidden" name="st" value="{echo $old_data[stid] ?$old_data[stid]: $_REQUEST[st]}">
    <div class="weui-cells__title">
        <!--{if $old_data}-->
        {lang xigua_sp:bjsp}{$old_data[title]}
        <a href="$SCRITPTNAME?id=xigua_sp&ac=spgg&gid={$old_data[id]}" class="y main_color none">{lang xigua_sp:spgg}</a>
        <!--{else}-->{lang xigua_sp:tjsp}
        <!--{/if}-->
    </div>
    <div class="weui-cells ">
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_sp:title}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[title]" placeholder="{lang xigua_sp:qtx}{lang xigua_sp:title}" value="{$old_data[title]}">
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_sp:subtitle}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[subtitle]" placeholder="{lang xigua_sp:subtitledesc}" value="{$old_data[subtitle]}">
            </div>
        </div>
        <!--{if $sp_config[maxhy]>1}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_sp:spfl}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" id="hangye" type="text" readonly value="$h_names" placeholder="{lang xigua_hs:djxz}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{else}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_sp:spfl}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[hy]" id="hangye" type="text" value="$default_hy" placeholder="">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{/if}-->

        <!--{if $sh}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_sp:sydp}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input choose_ctrl" name="form[shname]" type="text" value="{echo $old_data?$old_data['shname']:$dftshname}" placeholder="{lang xigua_sp:qxzsydp}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{/if}-->

        <div class="weui-cell" style="display:none">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_sp:dpfl}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" id="intype" name="form[intype]" placeholder="{lang xigua_sp:qxz}{lang xigua_sp:dpfl}" value="{$old_data[intype]}">
            </div>
            <div class="well-cell__ft">
                <a class="main_color f14	 openintype" href="javascript:;">{lang xigua_sp:szdpfl}</a>
            </div>
        </div>
        <!--{if $old_data}-->
        <div class="weui-cell none">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_sp:spxl}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="tel" name="form[sellnum]" placeholder="{lang xigua_sp:qtx}{lang xigua_sp:spxl}" value="{$old_data[sellnum]}">
            </div>
            <div class="well-cell__ft">{lang xigua_sp:jian}</div>
        </div>
        <!--{/if}-->

        <div class="weui-cell weui-cell_select weui-cell_select-after">
            <div class="weui-cell__hd">
                <label for="" class="weui-label">{lang xigua_sp:psfs}</label>
            </div>
            <div class="weui-cell__bd">
                <select class="weui-select" name="form[psfs_val]" onchange="if(this.value==1){$('#yfmb').hide();}else{$('#yfmb').show();}" >
                    <option value="3" <!--{if $old_data[psfs_val]==3}-->selected<!--{/if}-->>{lang xigua_sp:tsddhkd}</option>
                    <option value="1" <!--{if $old_data[psfs_val]==1}-->selected<!--{/if}-->>{lang xigua_sp:ddhx}</option>
                    <option value="2" <!--{if $old_data[psfs_val]==2}-->selected<!--{/if}-->>{lang xigua_sp:kdfy}</option>
                </select>
            </div>
        </div>
    </div>

    <a href="$SCRITPTNAME?id=xigua_hs&ac=add_area" class="weui-agree" id="yfmb" <!--{if $old_data[psfs_val]==1}-->style="display:none"<!--{/if}-->>
        <b class="weui-agree__text main_color">{lang xigua_sp:szyfmb}</b>
    </a>


<div class="weui-cells__title">{lang xigua_sp:jgsz}</div>
    <div class="weui-cells ">
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_sp:dmj}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[dprice]" placeholder="{lang xigua_sp:qtx}{lang xigua_sp:dmj1}" value="{$old_data[dprice]}">
            </div>
            <div class="well-cell__ft">{lang xigua_sp:yuan}</div>
        </div>
        <!--{if $_G['cache']['plugin']['xigua_hk']}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_sp:price_hk}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[hkprice]" placeholder="{lang xigua_sp:qtx}{lang xigua_sp:price_hk}" value="{$old_data[hkprice]}">
            </div>
            <div class="well-cell__ft">{lang xigua_sp:yuan}</div>
        </div>
        <!--{/if}-->

        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_sp:scj}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[disprice]" placeholder="{lang xigua_sp:qtx}{lang xigua_sp:scj}" value="{$old_data[disprice]}">
            </div>
            <div class="well-cell__ft">{lang xigua_sp:yuan}</div>
        </div>

        <!--{if 0 && $sp_config[allowjfzf]}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_sp:jfzf}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[jifenrate]" placeholder="{lang xigua_sp:qtx}{lang xigua_sp:jifenrate}" value="{$old_data[jifenrate]}">
            </div>
            <div class="well-cell__ft">%</div>
        </div>
        <!--{/if}-->
        <!--{if $sp_config[allowtck]}-->
        <div class="weui-cell weui-cell_switch">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_sp:yxtk}</label></div>
            <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_sp:yxtk_tip}</span></div>
            <div class="weui-cell__ft" style="height:32px">
                <input class="weui-switch" type="checkbox" name="form[allow_tk]" value="1" <!--{if $old_data[allow_tk]}-->checked<!--{/if}-->>
            </div>
        </div>
        <!--{/if}-->

        <div class="weui-cell weui-cell_switch">
            <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_sp:sfby}</label></div>
            <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_sp:qxzsfby}</span></div>
            <div class="weui-cell__ft" style="height:32px">
                <input class="weui-switch" id="baoyou_type" type="checkbox" name="form[baoyou_type]" value="1" <!--{if $old_data[baoyou_type]}-->checked<!--{/if}-->>
            </div>
        </div>
        <!--{eval
if($old_data['baoyou_num']<=0):
    $old_data['baoyou_num'] = '';
endif;
        }--><div class="weui-cell" id="baoyou_num" <!--{if !$old_data[baoyou_type]}-->style="display:none"<!--{/if}-->>
            <div class="weui-cell__hd"><label  class="weui-label">{lang xigua_sp:bytj}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[baoyou_num]" placeholder="{lang xigua_sp:mdsby}" value="{$old_data[baoyou_num]}">
            </div>
            <div class="well-cell__ft">{lang xigua_sp:yuan}</div>
        </div>
    </div>


    <div class="weui-cells__title">{lang xigua_sp:jjxq}</div>
    <div class="weui-cells ">

        <div class="weui-cell weui-cell_access" onclick='$("#edit_jieshao").popup();'>
            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_sp:jjxq}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" id="edit_jieshao_holder" value="{$old_data[jieshao]}" readonly placeholder="{lang xigua_sp:djspxq}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>

        <!--{if $sp_config[allowfm]}-->
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">{lang xigua_sp:spfm}</p>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-only="1">
                            <!--{if $old_data[fengmian]}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[fengmian])"><input type="hidden" name="form[fengmian]" value="$old_data[fengmian]"/>
                                <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                            </li>
                            <!--{/if}-->
                        </ul>
                        <div class="weui-uploader__input-box">
                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                            <a class="weui-uploader__input" data-name="form[fengmian]" data-multi="1"></a>
                            <!--{else}-->
                            <input class="weui-uploader__input" data-name="form[fengmian]" type="file" data-multi="1">
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--{/if}-->
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">{lang xigua_sp:splbt}</p>
                        <div class="weui-uploader__info">{echo str_replace('n', $sp_config['maximg'], lang_sp('zuiduozhao',0))}
                        </div>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-max="{$sp_config['maximg']}" data-maxtip="{echo str_replace('n', $sp_config['maximg'], lang_sp('zuiduozhao',0))}">
                            <!--{loop $old_data[album] $img}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/>
                                <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                            </li>
                            <!--{/loop}-->
                        </ul>
                        <div class="weui-uploader__input-box">
                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                            <a class="weui-uploader__input" data-name="form[album]" data-multi="1"></a>
                            <!--{else}-->
                            <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--{if $svicerange}-->
        <div class="weui-cell" style="padding-bottom:6px;">
            <div class="weui-cell__bd">
                <div class="post-tags cl" id="post-typeid">
                    <!--{loop $svicerange $_rangk $_rangv}-->
                    <!--{eval list($_rangt, $_rangd) = explode("#", $_rangv);}-->
                    <a class="weui-btn weui-btn_mini weui-btn_default <!--{if in_array($_rangt, $old_data[srange_ary])}-->tag-on<!--{/if}-->" href="javascript:;" onclick="return setTypeid('{$_rangk}', this);">$_rangt</a>
                    <input name="form[tagid][{$_rangk}]" type="hidden" value="<!--{if in_array($_rangt, $old_data[srange_ary])}-->1<!--{else}-->0<!--{/if}-->">
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <!--{/if}-->
    </div>

    <div class="fix-bottom mt10" style="position:relative">
        <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}"/>
        <a class="weui-btn weui-btn_default" href="javascript:window.history.go(-1);">{lang xigua_hb:fanhui}</a>
    </div>


        <div id="edit_jieshao" class="weui-popup__container" style="z-index:1000">
            <div class="weui-popup__modal bgf8">
                <div class="fixpopuper">
                    <div class="weui-cells__title">{lang xigua_sp:bjsp}</div>
                    <div class="weui-cells ">
                        <div class="weui-cell">
                            <div class="weui-cell__bd">
                        <textarea class="weui-textarea" name="form[jieshao]" id="jieshao" placeholder="{lang xigua_sp:txspxq}"
                                  rows="8">{$old_data[jieshao]}</textarea>
                            </div>
                        </div>
                    </div>

                    <div class="weui-cells before_none nobg center_upload">
                        <div class="weui-cell" id="first_append_img">
                            <div class="weui-cell__bd">
                                <div class="weui-uploader">
                                    <div class="weui-uploader__bd">
                                        <div class="weui-uploader__input-box">
                                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                            <a class="center_upload__input" data-name="form[append_img]"></a>
                                            <!--{else}-->
                                            <input class="center_upload__input" data-name="form[append_img]" type="file">
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--{loop $old_data[append_img_ary] $__k $__v}-->
                        <div class="weui-cell bgf" id="arear_{$__k}">
                            <ul id="cimg_{$__k}" data-only="1">
                                <li class="weui-uploader__file weui-uploader__file_status"
                                    style="background-image:url({$old_data['append_img_ary'][$__k]})">
                                    <input type="hidden" name="form[append_img][{$__k}]"
                                           value="{$old_data['append_img_ary'][$__k]}">
                                    <div class="weui-uploader__file-content"><i
                                                class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                            </ul>
                            <div class="weui-cell__bd">
                        <textarea class="weui-textarea" placeholder="{lang xigua_sp:inputtext}" rows="3" name="form[append_text][{$__k}]">{$old_data['append_text_ary'][$__k]}</textarea>
                            </div>
                            <a class="iconfont icon-guanbijiantou closeHt" data-index="{$__k}"></a>
                        </div>
                        <div class="weui-cell" id="cell_{$__k}">
                            <div class="weui-cell__bd">
                                <div class="weui-uploader">
                                    <div class="weui-uploader__bd">
                                        <div class="weui-uploader__input-box">
                                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                            <a class="center_upload__input" data-name="form[append_img]"></a>
                                            <!--{else}-->
                                            <input class="center_upload__input" data-name="form[append_img]" type="file">
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--{/loop}-->
                    </div>

                    <div class="fix-bottom" id="center_upload_btn" style="position:relative">
                        <a class="mt0 weui-btn weui-btn_default" onclick='return edit_finish();'
                           href="javascript:;">{lang xigua_sp:wcbj}</a>
                    </div>
                </div>
            </div>
        </div>
<!--{if $sp_config[maxhy]>1 && is_file(DISCUZ_ROOT.'source/plugin/xigua_sp/template/touch/addpopup.php')}-->
<!--{template xigua_sp:addpopup}-->
<!--{/if}-->
    </form>
</div>

<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>

<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div class="masker" onclick='$(".choose_ctrl").select("close")'></div>
<script> +function($){  $.rawCitiesData = $cityjson; }($);</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script>
var itar = [];
<!--{loop $sh $_sh}--><!--{if $_sh[name]}-->itar.push({title:'{$_sh[name]}'});<!--{/if}--><!--{/loop}-->
$(".choose_ctrl").select({
    title: "{lang xigua_sp:qxzsydp}",
    items: itar,
    onOpen:function () {
        $('.masker').fadeIn();
    },
    beforeClose:function () {
        $('.masker').fadeOut(300);
        return true;
    }
});
<!--{if $sp_config[maxhy]>1}-->
$(document).on('click','#hangye', function () {
    var popcm =$('#popup_hangye');
    popcm.popup();popcm.show();
    setTimeout(function(){popcm.show();}, 500);
    return false;
});
<!--{else}-->
$("#hangye").cityPicker({
    title: "{lang xigua_sp:qxzspfl}",
    showDistrict: false,
    onChange: function (picker, values, displayValues) {
        console.log(values);
    }
});
<!--{/if}-->
function cropCallback(){
    $("#new_popup").popup();
    return false;
}
function edit_finish(){
    $.closePopup();
    $("#edit_jieshao_holder").val($('#jieshao').val());
    return cropCallback();
}
$("#intype").select({
    title: "{lang xigua_sp:qxz}{lang xigua_sp:dpfl}",
    items: []
});
$(document).on('click','.openintype', function () {
    $.modal({
        title: '{lang xigua_sp:szdpt}',
        text: "<div class=\"b-color13 fixipt13\"><textarea class=\"weui-textarea weui-prompt-input needsclick\" id=\"weui-modal-input\" placeholder=\"\" rows=\"5\"></textarea></div>",
        buttons: [
            { text: QUXIAO, className: "default", onClick: function(){} },
            { text: QUEDING, className: "primary", onClick: function(){
                    var input = $('#weui-modal-input').val();
                    var shname = $(".choose_ctrl").val();
                    $.showLoading();
                    $.ajax({
                        type: 'post',
                        url: _APPNAME +'?id=xigua_sp&ac=com&do=setintype&inajax=1',
                        data: {'comment': input, 'shname': shname, 'formhash' :FORMHASH},
                        dataType: 'xml',
                        success: function (data) {
                            $.hideLoading();
                            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                            var s = data.lastChild.firstChild.nodeValue;
                            var msgar = tip_common(s);
                            if(msgar[0] =='success'){
                            }
                        },
                        error: function () { $.hideLoading();}
                    });
                } },
        ]
    })
});
$(document).on('click','#baoyou_type', function () {
    var that = $(this), baobx = $('#baoyou_num');
    if(that[0].checked){
        baobx.show();
    }else{
        baobx.hide();
    }
});
</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.min.js" charset="utf-8"></script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_sp:footer}-->
<!--{template xigua_sp:enter_up}-->
<!--{if !$sh[0][name]}--><script>$.alert("{lang xigua_sp:qxbz}", function() {hb_jump("$SCRITPTNAME?id=xigua_hs&ac=shcenter&mobile=2{$urlext}");});</script><!--{/if}-->