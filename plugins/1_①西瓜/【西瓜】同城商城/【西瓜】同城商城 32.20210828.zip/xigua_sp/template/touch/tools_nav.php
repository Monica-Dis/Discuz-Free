<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="weui-navbar">
    <a href="javascript:;" data-ext="sort=zonghe" class="shopsort weui-navbar__item weui_bar__item_on">
        <span>{lang xigua_sp:zh}</span>
    </a>
    <a href="javascript:;" data-ext="sort=sellnum" class="shopsort weui-navbar__item">
        <span>{lang xigua_sp:xl}</span>
    </a>
    <a href="javascript:;" data-ext="sort=dprice" class="shopsort weui-navbar__item shop_mod_sortbar up">
        <span>{lang xigua_sp:jg}<i></i></span>
    </a>
    <a href="javascript:;" data-ext="sort=crts" class="shopsort weui-navbar__item">
        <span>{lang xigua_sp:sx}</span>
    </a>
    <a class="weui-navbar__item changestyle">
        <i class="iconfont icon-liebiao"></i>
    </a>
</div>