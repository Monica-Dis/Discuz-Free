<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="popup_item" class="weui-popup__container popup-bottom" style="z-index:1001">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal" style="overflow: inherit;overflow-y: inherit;">
        <a href="javascript:;" class="picker-button close-popup close-pay"><i class="iconfont icon-guanbijiantou"></i></a>
        <div class="cl bgf">
            <div class="buy-item imgloading" id="fm123"> <img src="{echo $v[fengmian] ? $v[fengmian] : $v[album][0]}"> </div>
            <div class="buy-title">
                <div class="tprice2 pt8">
                    <!--{if $v[newjifenprice]>0}-->
                    <em id="pricePt">{$v[newjifenprice_str]}</em>
                    <em id="priceDm" style="display:none;">{$v[newjifenprice_str]}</em>
                    <!--{elseif $v[price_pt] || $v[price_dm]}-->
                    <em class="f12">&yen;</em><em id="pricePt">{$v[price_pt]}</em>
                    <em id="priceDm" style="display:none;">{$v[price_dm]}</em>
                    <!--{/if}--></div>
                <div class=" f12" id="spggname">{lang xigua_sp:qxz} <!--{loop $v[spgg_ary] $_spn}--> {$_spn[name]} <!--{/loop}--></div>
            </div>
        </div>
        <div class="modal-content" style="padding-top: 0">
<form  action="$SCRITPTNAME?id=xigua_sp&ac=confirm&st={$_GET['st']}" method="post" id="form">
<input name="formhash" value="{FORMHASH}" type="hidden">
<input name="gid" value="{$gid}" type="hidden">
<input name="confrm" value="confrm" type="hidden">
<input name="form[type]" value="pt" type="hidden">
<input name="form[price_id]" id="price_id" value="0" type="hidden">
<input name="form[buy_type]" id="buy_type" value="1" type="hidden">
<input name="form[tuan_id]" id="tuan_id" value="0" type="hidden">
            <div class="weui-cells before_none after_none" style="padding-bottom: 10px;max-height: 72vh;overflow-y:auto">
                <!--{eval $spcount = 0;}-->
                <!--{loop $v[spgg_ary] $_spk $_spn}-->
                <div class="weui-cell ">
                    <div class="weui-cell__bd">
                        <p class="f14 c3 mb5">{$_spn[name]}</p>
                        <div class="post-tags buy-tags cl">
                            <!--{loop $_spn[ggtext] $_ggk $_ggt}-->
                            <a class="weui-btn weui-btn_mini weui-btn_default " href="javascript:;" onclick="return setSpgg('$_ggt', this);">$_ggt</a>
                            <input class="gginput" name="form[tagid][$_ggt]" type="hidden" value="0">
                            <!--{eval $spcount++;}-->
                            <!--{/loop}-->
                        </div>
                    </div>
                </div>
                <!--{/loop}-->

                <div class="weui-cell " >
                    <div class="weui-cell__bd">
                        <p class="f14">{lang xigua_sp:sl}</p>
                    </div>
                    <div class="weui-cell__ft main_color">
                        <i class="iconfont icon-jianshao2 inc-num" data-step="-1"></i>
                        <input class="inc-input" type="tel" name="form[item_num]" id="item_num" value="1" data-max="{$v[danci]}" >
                        <i class="iconfont icon-tianjia1 inc-num" data-step="1"></i>
                    </div>
                </div>

                <div class="weui-cell ">
                    <div class="weui-cell__hd"><label class="weui-label f14">{lang xigua_sp:bz}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input f14" name="form[item_note]" id="item_note" type="text" placeholder="{lang xigua_sp:xt}">
                    </div>
                </div>

                <!--{if $v[youhui]>0}-->
                <label id="weuiAgree" class="weui-agree tr">
                    <span class="weui-agree__text ptcolor ">{lang xigua_sp:ktlj}{$v[youhui]}{lang xigua_sp:yuan}</span>
                </label>
                <!--{/if}-->
            </div>
    <div class="weui-flex" id="gwcbox">
        <!--{if $v[newjifenprice]<=0}-->
        <input type="button" data-shid="$v[shid]" data-gid="$gid" id="dosubmit_gwc" class="joingwc mt0 bgsec weui-btn br0" value="{lang xigua_sp:fqpt}" />
        <!--{/if}-->
        <input type="submit" id="dosubmit_now" class="mt0  weui-btn main_spbg br0" value="{lang xigua_sp:ljgm}" />
    </div>
    <div id="quedbox" style="display:none">
        <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary br0 qd1 mt0" value="{lang xigua_hb:queding}" />
        <input type="button" data-shid="$v[shid]" data-gid="$gid" style="display:none" class="joingwc mt0 bgsec weui-btn  br0 qd2 " value="{lang xigua_sp:fqpt}" />
    </div>
</form>
        </div>
    </div>
</div>
<!--{if $v[price_list]}-->
<!--{eval
foreach($v['price_list'] as $_k=>$_v):
    $v['price_list'][$_k]['kami'] = '';
endforeach;
}-->
<script>var PRICE_LIST = {eval echo json_encode($v[price_list])};</script>
<!--{else}-->
<script>var PRICE_LIST = [];</script>
<!--{/if}-->