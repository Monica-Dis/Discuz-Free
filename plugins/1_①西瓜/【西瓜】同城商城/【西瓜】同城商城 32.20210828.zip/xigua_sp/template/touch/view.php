<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $v['stid'] && !isset($_GET['st'])}-->
<!--{eval dheader("Location:$SCRITPTNAME?".http_build_query($_GET).'&st='.$v['stid']);}-->
<!--{/if}-->
<!--{template xigua_sp:header}-->
<style>.in_bottom_z,.view_bottom_z{min-width:50px;width:13%;overflow:hidden}</style>
<div class="page__bd view_body">
    <header class="x_header bgcolor_11 cl f15">
        <!--{if !IN_PROG}-->
        <a class="z f14" href="javascript:window.history.go(-1);"><i class="iconfont icon-fanhuijiantou w15"></i></a>
        <!--{/if}-->
        <a class="y sidectrl view_ctrl"><i class="iconfont icon-gengduo1 f22"></i></a>
        <div class="navtitle cl">
            <a class="color-red" data-name="goodinfo">{lang xigua_sp:jj}</a>
            <a data-name="goodprofile">{lang xigua_sp:xq}</a>
            <a data-name="comment_profile">{lang xigua_sp:ljpj}</a>
            <a data-name="tuan_recommend">{lang xigua_sp:tj}</a>
        </div>
    </header>
    <div class="x_header_fix" ></div>
    <!--{if $v[fengmian]}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$v[fengmian]" /></div><!--{/if}-->
    <!--{template xigua_sp:viewtools}-->
    <div class="sp_swipe cl" style="position:relative;margin:0;overflow:hidden" id="goodinfo">
        <div class="swipe-wrap" style="transition: all .3s;-webkit-transition: all .3s">
            <!--{if !$v[album]}-->
            <!--{eval $v[album] = $v[append_img_ary];}-->
            <!--{/if}-->
            <!--{if !$v[album]}-->
            <!--{eval $v[album] = array($v[fengmian]);}-->
            <!--{/if}-->
            <!--{loop $v[album] $slider}-->
            <div class="swp imgloading"><img src='$slider' <!--{if 0&& $sp_config[viewh]}-->style="height:{$sp_config[viewh]}px"<!--{/if}--> /></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $v[album] $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}--> ></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <div class="weui-cells mt0 before_none view_top after_none">
        <div class="cl view_cell">
            <div class="weui-flex">
                <div class="weui-flex__item" style="position: relative">
                    <!--{if $v[srange2_ary]}-->
                    <!--{loop $v[srange2_ary] $s2}-->
                    <span class="stamp_thin">$s2</span>
                    <!--{/loop}-->
                    <!--{/if}-->
                    <span class="tprice">
                    <!--{if $v[dprice]>0}-->
                    <em class="f12">&yen;</em>$v[dprice]</span>
                    <!--{/if}-->
                    <!--{if $v[newjifenprice] && $v[dprice]<=0}-->
                    <span class="main_color">$v[newjifenprice_str]</span>
                    <!--{elseif $v[jifenprice]}-->
                    <span class="f12 main_color">$v[jifenprice]</span>
                    <!--{/if}-->
                    <span class="c9 f12"><s><em class="f12">&yen;</em>$v[price_sc_max]</s></span>
<!--                    <span class="tnums f12">{lang xigua_sp:yp}{$v[sellnum]}{lang xigua_sp:j}</span>-->
                    <!--{if $v[hkprice]>0}-->
                    <span class="hksp" style="float:none;display:inline-block">{$_G['cache']['plugin']['xigua_hk']['cardname']}{$v[hkprice]}{lang xigua_hb:yuan}</span>
                    <!--{/if}-->
                </div>
            </div>
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <span class="f15 view_title c30">$v[title]</span>
                </div>
            </div>
            <!--{if $v[subtitle]}-->
            <div class="weui-flex">
                <div class="weui-flex__item f13 aten" >
                    $v[subtitle]
                </div>
            </div>
            <!--{/if}-->
        </div>
        <!--{if $v[srange_ary]}-->
        <a class="weui-cell" href="javascript:;" onclick="return $('#poup_srange_ary').popup();">
            <div class="weui-cell__bd">
                <ul class="arguments-treatment">
                    <!--{loop $v[srange_ary] $_v}--><li style="float:left;"><i class="iconfont icon-duigou2 main_color"></i> {$_v}</li><!--{/loop}-->
                </ul>
            </div>
            <div class="weui-cell__ft">
                <i class="f13 iconfont icon-jinrujiantou"></i>
            </div>
        </a>
        <!--{/if}-->


        <!--{if $sp_config[showreal]&&$v[logs]}-->
        <a class="weui-cell" href="javascript:;">
            <div class="weui-cell__bd f14">
                <ul class="seckill_logs z">
                    <!--{loop $v[logs] $_u}-->
                    <li><img src="{avatar($_u[uid], 'middle', true)}" /></li>
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="weui-cell__ft f14">
                {lang xigua_sp:yyou}{echo max($v[sellnum], $v[logs_count]);}{lang xigua_sp:rgm}
            </div>
        </a>
        <!--{/if}-->
        <!--{template xigua_sp:slider}-->
    </div>

    <div class="weui-cells f15 before_none after_none">
        <a href="javascript:;" class="weui-cell fullcell nowbuy" data-type="1" data-needconfirm="1" data-gwc="0">
            <div class="weui-cell__hd ltit">{lang xigua_sp:yx}</div>
            <div class="weui-cell__bd">
                <p class="c30" id="yixuan">{lang xigua_sp:qxz}<!--{loop $v[spgg_ary] $_spk $_spn}-->{$_spn[name]} <!--{/loop}--></p>
            </div>
            <div class="weui-cell__ft"><i class="f13 iconfont icon-jinrujiantou"></i></div>
        </a>
<!--{eval
$showby = 0;
if($sp_config['baoyou']):
    $showby = $sp_config['baoyou'];
endif;
$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($shid);
if($sh['baoyou']):
    $showby = $sh['baoyou'];
endif;
if($v[baoyou_type]==1 && $v[baoyou_num]>0):
    $showby = $v[baoyou_num];
endif;
}-->
        <!--{if $showby>0}-->
        <a href="javascript:;" class="weui-cell fullcell">
            <div class="weui-cell__hd ltit">{lang xigua_sp:yh}</div>
            <div class="weui-cell__bd">
                <p>{lang xigua_sp:man3} <span class="main_color">{$showby}{lang xigua_sp:yuan}</span> {lang xigua_sp:by}</p>
            </div>
        </a>
        <!--{/if}-->
    </div>


<!--{eval $sh = $v[sh]}-->
<div class="weui-cells f15 before_none after_none">
    <div class="weui-cell">
        <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]"><img src="{$sh[logo]}"></a></div>
        <div class="weui-cell__bd">
            <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]">{$sh[name]}</a></p>
            <p class="f13 c9"><i class="iconfont icon-mudedi vm"></i> <em>{$sh[addr]}</em></p>
        </div>
        <div class="weui-cell__ft">
            <a href="javascript:;" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_sp:smj}", "{lang xigua_sp:wxzca}");'><i class="iconfont icon-sixin2 mr15 main_color f24"></i></a>
            <a class="shtel" <!--{if $sh[teljs]}-->$sh[teljs]<!--{else}-->href="tel:{$sh[tel]}"<!--{/if}-->><i class="iconfont icon-unie607 main_color f24"></i></a>
        </div>
    </div>
    <div class="info_tab weui-flex">
        <div class="weui-flex__item"><p class="num">{$sh[follow]}</p><p class="desc">{lang xigua_sp:fsrs}</p></div>
        <div class="weui-flex__item"><p class="num">{$goodnum}</p><p class="desc">{lang xigua_sp:qbsp}</p></div>
        <div class="weui-flex__item"><p class="num"><span>{$avgstarsh}</span></p><p class="desc">{lang xigua_sp:zhpj}</p></div>
    </div>
    <div class="shop_btns weui-flex">
        <!--{if $followed}-->
        <a href="javascript:;" class=" weui-flex__item do_follow" data-id="$sh[shid]" data-qr="$sh[qr]"><i class="iconfont icon-collection_fill vm f28"></i>{lang xigua_hs:yiguanzhu}</a>
        <!--{else}-->
        <a href="javascript:;" class=" weui-flex__item do_follow" data-wei="1" data-id="$sh[shid]" data-qr="$sh[qr]">{lang xigua_hs:jiaguanzhu}</a>
        <!--{/if}-->
        <a class="weui-flex__item" href="$SCRITPTNAME?id=xigua_sp&ac=shop&shid={$v[shid]}&mobile=2{$urlext}"><i class="iconfont icon-shop vm f28"></i>{lang xigua_sp:jdgg}</a>
    </div>
</div>

    <div class="weui-cells f15  before_none after_none" id="goodprofile">
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <p>{lang xigua_sp:jieshao}</p>
            </div>
        </div>
        <!--{eval
        if(strpos($v['jieshao'], '&lt;') !== false  && strpos($v['jieshao'], '&gt;') !== false) :
            $v['jieshao'] = htmlspecialchars_decode($v['jieshao']);
            $v['jieshao'] = preg_replace(array("/<script(.*?)<\/script>/is",'/on(mousewheel|mouseover|click|load|onload|submit|focus|blur)="[^"]*"/i'), array('',''), $v['jieshao']);
        endif;
        }-->
        <article class="weui-cell weui-article f14">
            <section>
                <!--{if $v['jieshao']}-->
                <p class="imgloading">{echo hs_nl2br($v['jieshao']);}</p>
                <!--{/if}-->
                <!--{loop $v[append_img_ary] $__k $__v}-->
                <p class="imgloading"><img src="{$__v}" /></p>
                <p>{echo hs_nl2br($v[append_text_ary][$__k]);}</p>
                <!--{/loop}-->
            </section>
        </article>
    </div>
<!--{template xigua_sp:comment}-->
<!--{template xigua_sp:tuijian}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_sp&ac=shop&shid={$v[shid]}&mobile=2{$urlext}" class="weui-tabbar__item">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-shoplight weui-tabbar__icon pr-1"></i>
                </span>
                <p class="weui-tabbar__label">{lang xigua_sp:jindian}</p>
            </a>
        </div>
        <div class="in_bottom_z">
            <!--{if $kefulink}-->
            <a href="{$kefulink}" class="weui-tabbar__item">
            <!--{else}-->
            <a href="javascript:;" class="weui-tabbar__item" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_sp:calx}", "{lang xigua_sp:lxwx}");'>
            <!--{/if}-->
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-kefu1 weui-tabbar__icon f22"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_sp:kf}</p>
            </a>
        </div>

        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_sp&ac=gwc{$urlext}" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-gouwuche weui-tabbar__icon f22"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_sp:gwc}</p>
                <span class="weui-badge" id="gwcnum" style="position: absolute;top:2px;right:8px;display:none">0</span>
            </a>
        </div>
        <!--{if $_G['cache']['plugin']['xigua_hk'] && $v[hkprice]>0 && (!$_G['uid'] || !$card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G['uid']))}-->
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hk&ac=join" class="weui-tabbar__item" style="background: #2B2B2A;">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-huiyuantequan weui-tabbar__icon f22" style="color: rgb(230,220,190);"></i>
                    </span>
                <p class="weui-tabbar__label" style="color: rgb(230,220,190);">{lang xigua_hk:qkk}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if $v[newjifenprice]<=0}-->
        <div class="weui-flex__item in_bottom_y in_bottom_sec">
            <a href="javascript:;" class="bgcolor_sec mc_bg nowbuy" data-type="1" data-needconfirm="1" data-gwc="0">
                <div class="fqpd1" style="height:2.5rem">{lang xigua_sp:fqpt}</div>
            </a>
        </div>
        <!--{/if}-->
        <div class="weui-flex__item in_bottom_y in_bottom_main">
            <a href="javascript:;" class="main_spbg  mc_bg nowbuy" data-type="1" data-needconfirm="1" data-gwc="0">
                <div class="fqpd1" style="height:2.5rem">{lang xigua_sp:ljgm}</div>
            </a>
        </div>
    </div>

</div>

<div id="poup_srange_ary" class="weui-popup__container popup-bottom" style="z-index:1001">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:quxiao}</a>
                <h1 class="title"><em class="titem"></em>{lang xigua_sp:fwsm}</h1>
            </div>
        </div>
        <div class="modal-content paygg">
            <div class="weui-cells before_none after_none" style="padding-bottom:120px">
                <!--{eval $sviceranges = array();}-->
                <!--{loop $svicerange $_rangk $_rangv}-->
                <!--{eval
                    list($_rangt, $_rangd) = explode("#", $_rangv);
                    $sviceranges[$_rangt] = $_rangd;
                }-->
                <!--{/loop}-->
                <!--{loop $v[srange_ary] $k $__v}-->
                <div class="weui-cell before_none">
                    <div class="weui-cell__hd">
                        <i class="iconfont icon-duigou2 main_color mr15"></i>
                    </div>
                    <div class="weui-cell__bd">
                        <p class="f14">{$__v}</p>
                        <p class="f12 c9">{$sviceranges[$__v]}</p>
                    </div>
                </div>
                <!--{/loop}-->
            </div>
        </div>
    </div>
</div>

<!--{template xigua_sp:payitem}-->
<!--{eval $tabbar=0;}-->
<!--{template xigua_sp:qrcode}-->
<!--{template xigua_sp:footer}-->
<script>
setTimeout(function(){
    ptclock();
}, 1000);
<!--{if $ptuserlist}-->
$('#popup_item').popup();
$('#buy_type').val('2');
$('#pricePt').show();
$('#priceDm').hide();
$.toptip('{$tuanzhang[username]}{lang xigua_sp:yqnpt},{$ptuserlist[0][shixian_u]}{lang xigua_sp:zqyx}', 300000 ,'warning');
$('.weui-toptips').css('z-index', '1001');
<!--{/if}-->
<!--{if $spcount<=1}-->
$('.buy-tags').each(function(){var t = $(this);t.find('a:first-child').trigger('click');});
<!--{/if}-->
comment_do_profile({$v[id]});
$(document).on('click','.navtitle a', function () {
    var that = $(this);
    $('.navtitle a').removeClass('color-red');
    that.addClass('color-red');
    var sctop =$('#'+that.data('name')).offset().top-42;
    console.log(sctop);
    $('body,html').animate({scrollTop:sctop}, 180);
});
$('div.sp_swipe').each(function () {
    sp_slider($(this), $(this).data('speed') || 5000)
});
var sp_seiper = null;
function sp_slider(_this, auto) {
    var bullets = _this.find('nav.bullets');
    var position = _this.find('ul.position');
    sp_seiper = new Swipe2(_this[0], {
        visibilityFullFit : true,
        startSlide: 0, speed: 500, auto: auto, continuous: true, callback: function (index) {
            if (bullets.length > 0) {
                bullets.find('em:first-child').text(index + 1);
            }
            if (position.length > 0) {
                var selectors = position[0].children;
                for (var t = 0; t < selectors.length; t++) {
                    selectors[t].className = selectors[t].className.replace("current", "");
                }
                if (typeof selectors[(index) % (selectors.length)] != 'undefined') {
                    selectors[(index) % (selectors.length)].className = "current";
                }
            }
            var H = $(".swipe-wrap .swp").eq(index).height();
            if(H){
                $('.swipe-wrap').css('height', H);
                $('.sp_swipe').css('height', H);
            }
        }
    });
}
var _H = $(".swipe-wrap .swp").eq(0).height();
if(_H){
    $('.swipe-wrap').css('height', _H);
    $('.sp_swipe').css('height', _H);
}
</script>