<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="dis_list">
    <div class="dis_row jump_sp" data-id="{$v[id]}">
        <div class="dis_pic">
            <img src="{echo $v[fengmian] ? $v[fengmian] : $v[album][0]}">
            <div class="dis_mask"><div class="title">{$v[title]}</div></div>
        </div>
        <div class="dis_pir weui-flex">
            <div class="weui-flex__item">
                <p class="price">
                    <span class="ptcolor">
<!--{if $v[dprice]>0}-->
&yen;<em class="f18">{$v[dprice]}</em>
<!--{/if}-->
<!--{if $v[newjifenprice]}-->
<em class="f12 main_color">$v[newjifenprice_str]</em>
<!--{elseif $v[jifenprice]}-->
<em class="f12 main_color">$v[jifenprice]</em>
<!--{/if}-->
                    </span>

                    <span class="f12 gray y">{lang xigua_sp:yp}{$v[sellnum]}{lang xigua_sp:j}</span>
                </p>
            </div>
        </div>
    </div>
    <div class="button-sp-area">
        <a href="$SCRITPTNAME?id=xigua_sp&ac=add&gid={$v[id]}" class="weui-btn weui-btn_mini hm_c_btn ">{lang xigua_sp:xg}</a>
        <a href="$SCRITPTNAME?id=xigua_sp&ac=spgg&gid={$v[id]}" class="weui-btn weui-btn_mini hm_c_btn ">{lang xigua_sp:spgg}</a>

        <a href="javascript:;" data-gid="{$v[id]}" data-title="{lang xigua_sp:sxj}" data-text="$v[title]<br>{lang xigua_sp:sxjd}" class="weui-btn weui-btn_mini hm_c_btn sxj">{lang xigua_sp:sxj}</a>
    </div>
</div>
<!--{/loop}-->