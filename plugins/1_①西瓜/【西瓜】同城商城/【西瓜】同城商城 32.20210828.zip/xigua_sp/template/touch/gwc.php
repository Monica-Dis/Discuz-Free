<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}--><!--{eval $no_header_fix=1;}--><style>.x_header{position:relative}</style>
<div class="page__bd">
    <div class="do_bd">
        <!--{template xigua_hb:common_nav}-->
        <!--{template xigua_sp:viewtools}-->

        <!--{if $num>0}-->
        <div class="mt0 main_bg hh_my_head" style="height:120px">
            <i class="header-annimate-element1"></i>
            <i class="header-annimate-element4"></i>
            <i class="header-annimate-element5"></i>
            <i class="header-annimate-element6"></i>
            <i class="header-annimate-element7"></i>
            <i class="header-annimate-element8"></i>
            <i class="header-annimate-element9"></i>
            <div class="hh_my_head_in">
                <div class="weui-cells__title" style="color:#fff">{lang xigua_sp:g}{$num}{lang xigua_sp:jian}{lang xigua_sp:jj}</div>
            </div>
        </div>
        <!--{else}-->
        <div class="bgf" style="padding:1px;padding-bottom: 20px;">
            <div style="width: 138px;margin: 50px auto 0 auto;">
                <img src="source/plugin/xigua_sp/static/empty.png" style="width: 100%;">
            </div>
            <a class="thinbtn thinbtn_mid " href="$SCRITPTNAME?id=xigua_sp">{lang xigua_sp:gyg}</a>
        </div>
        <!--{template xigua_sp:tuijian}-->
        <!--{/if}-->

        <!--{loop $newl $_k $_v}-->
        <!--{eval $_sh = $shinfos[$_k]; $price_id_items=array();}-->
        <div class="pt_order_li spgwctop">
            <div class="pt_shlink">
                <a class="sp_sh_jump" href="$SCRITPTNAME?id=xigua_sp&ac=shop&shid={$_sh[shid]}&mobile=2"> <img class="confirm_shlogo" src="{$_sh[logo]}"> <span class="f13">{$_sh[name]}</span> <i class="f13 iconfont icon-jinrujiantou"></i> </a>
            </div>

            <!--{loop $_v $__k $__v}-->
            <!--{eval $vgoodshot = $goods[$__v[gid]]; $vpriceshot = $good_prices[$__v[price_id]]; $price_id_items[] = $__v[price_id];}-->
            <div id="gwc_$__v[id]" class="gwcietm weui-cell after_none" style="display:block;overflow:hidden">
                <div class="weui-cell__hd z">
                    <label class="weui-label jump_sp" style="width:95px" data-id="{$__v[gid]}">
                        <img style="width: 80px;height: 80px;" src="{echo $vgoodshot[fengmian] ? $vgoodshot[fengmian] : ($vgoodshot[album][0] ? $vgoodshot[album][0] : $vgoodshot[append_img_ary][0])}">
                    </label>
                </div>
                <div class="weui-cell__bd ">
                    <p class="f14 c3 jump_sp" data-id="{$__v[gid]}">{$vgoodshot[title]}</p>
                    <p class="spgwcp"><!--{eval $price_name = explode('###', $vpriceshot['name'])}--><!--{loop $vgoodshot[spgg_ary] $_spk $_spn}-->
                        <span class="f12 c9">{$_spn[name]}: {$price_name[$_spk]}</span><!--{/loop}-->
                    </p>
                    <div class="f14 cl spgwclist">
                        <!--{if $vpriceshot['price_dm']>0}-->
                        <span class="main_color">&yen;{$vpriceshot['price_dm']}</span>
                        <!--{elseif $vpriceshot[price_jf]>0}-->
                        <span class="main_color">{$vpriceshot['price_jf_str']}</span>
                        <!--{/if}-->
                        <div class="incnum">

                            <a class="color-red f16 mr10 delgwc" data-id="$__v[id]"><i class="weui-icon-warn iconfont icon-shanchu" style="font-size:18px!important;"></i></a>

                            <i class="iconfont icon-jianshao2 inc-num" data-step="-1"></i>
                            <input class="inc-input" type="tel" data-gid="{$__v[gid]}" data-priceid="$__v[price_id]" data-price="{$vpriceshot['price_dm']}" name="form[item_num][{$__v[price_id]}]" value="{$__v['num']}">
                            <i class="iconfont icon-tianjia1 inc-num" data-step="1"></i>
                        </div>
                    </div>
                </div>
            </div>
            <!--{/loop}-->


            <div class="pt_func  weui-cell">
                <div class="weui-cell__bd f12">
                    {lang xigua_sp:zjia}: <em class="ptcolor ipt_show"></em> ({lang xigua_sp:bhyf})
                </div>
                <div class="weui-cell__ft">
                    <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_primary jiesuanbtn" data-shid="{$_sh[shid]}">{lang xigua_sp:qjs}</a>
                </div>
            </div>
        </div>
        <!--{/loop}-->

    </div>
</div>
<!--{eval $sp_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_sp:footer}-->
<script>
function removeGwc(id){
    var gwcietm = $('#gwc_'+id);
    if(gwcietm.parent().find('.gwcietm').length<=1){
        gwcietm.parent().remove();
    }else{
        gwcietm.remove();
    }
    $('.inc-input').each(function(){
        incNumCallback($(this));
    });
    return false;
}

function incNumCallback(ipt){
    var iptop = ipt.parent().parent().parent().parent().parent();
    var ipts = iptop.find('.inc-input');
    var ipt_show = 0;
    ipts.each(function () {
        var that = $(this);
        ipt_show += that.data('price')*that.val();
    });
    iptop.find('.ipt_show').html('&yen; '+parseFloat(ipt_show).toFixed(2));
}
$('.inc-input').each(function(){
    incNumCallback($(this));
});
$(document).on('click','.jiesuanbtn', function () {
    var that = $(this);
    var iptop = that.parent().parent().parent().find('.inc-input');
    var _pid = '', _gid = '', _num = '';
    iptop.each(function () {
        var _that = $(this);
        _pid += '_'+_that.data('priceid');
        _gid += '_'+_that.data('gid');
        _num += '_'+_that.val();
    });

    hb_jump("$SCRITPTNAME?id=xigua_sp&ac=confirm&num="+_num+"&pid="+_pid+"&gid="+_gid+"&shid="+that.data('shid')+"$urlext");
});
</script>