<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="none view_tools_mask"></div>
<div class="none view_tools animated">
    <ul>
        <li class="border_bottom" ><a href="$SCRITPTNAME?id=xigua_sp"><i class="vm iconfont icon-index "></i> {lang xigua_sp:sy}</a></li>
        <li><a href="$SCRITPTNAME?id=xigua_sp&ac=wode"><i class="vm iconfont icon-wode "></i> {lang xigua_hb:wode}</a></li>
        <!--<li><a href="$SCRITPTNAME?id=xigua_hb&ac=qianbao"><i class="vm iconfont icon-qianbao2  "></i> {lang xigua_sp:wdqb}</a></li>-->
        <li><a href="$SCRITPTNAME?id=xigua_sp&ac=gwc"><i class="iconfont icon-gouwuche"></i> {lang xigua_sp:gwc}</a></li>
        <!--{if C::t('#xigua_hs#xigua_hs_shanghu')->fetch_count_self($_G['uid'])}-->
        <li><a href="$SCRITPTNAME?id=xigua_sp&ac=order_manage"><i class="vm iconfont icon-jieshao1   "></i> {lang xigua_sp:ddgl1}</a></li>
        <li><a href="$SCRITPTNAME?id=xigua_sp&ac=manage"><i class="vm iconfont icon-fenlei  "></i> {lang xigua_sp:spgl1}</a></li>
        <li><a href="$SCRITPTNAME?id=xigua_hs&ac=shcenter"><i class="vm iconfont icon-shop   "></i> {lang xigua_hs:shcenter}</a></li>
        <!--{/if}-->
    </ul>
</div>
