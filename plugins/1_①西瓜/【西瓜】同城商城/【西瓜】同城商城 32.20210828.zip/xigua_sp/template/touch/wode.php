<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}--><!--{eval $no_header_fix=1;
}--><style>.x_header{position:relative}.centtop1 a i{color:{$config[maincolor]}}.centtop2 a i{color:#999}.more_sh {position: absolute;right: 0;background: rgba(0,0,0,.15);color: #fff;padding: 0 10px;
font-size: 12px;border-top-left-radius: 26px;border-bottom-left-radius: 26px;height: 26px;line-height: 26px;}.q_h{position:absolute;right:15px;font-size:14px}</style>
<div class="page__bd my_new_bd ">
    <div class="do_bd">
        <!--{template xigua_hb:common_nav}-->

        <div class="mt0 main_bg hh_my_head" style="height:135px">
            <i class="header-annimate-element1"></i>
            <i class="header-annimate-element4"></i>
            <i class="header-annimate-element5"></i>
            <i class="header-annimate-element6"></i>
            <i class="header-annimate-element7"></i>
            <i class="header-annimate-element8"></i>
            <i class="header-annimate-element9"></i>

            <div class="my__head_user z">
            <!--{if $shcout}-->
                <span class="my__head_avatar z"><img src="{$sh[logo]}" ></span>
            <!--{else}-->
                <!--{if $_G['cache']['plugin']['xigua_member']}-->
                <a href="$SCRITPTNAME?id=xigua_member:profile" class="my__head_avatar z"><img src="{avatar($_G[uid], 'big', true)}" ></a>
                <!--{else}-->
                <span class="my__head_avatar z"><img src="{avatar($_G[uid], 'big', true)}" ></span>
                <!--{/if}-->
            <!--{/if}-->
                <div>
                <!--{if $shcout}-->
                    <div class="my__head_nickname f16">{$sh[name]}</div>
                    <a class="qblink">{$_G[username]} UID : {$_G[uid]}</a>
                    <!--{if $list[1]}--><a href="javascript:;" id="qiehuan" class="q_h" >{lang xigua_hs:djqh}<i style="transform: rotate(0deg);position:relative;" class="iconfont icon-jinrujiantou f12 vm"></i></a>
                    <!--{else}-->
                    <a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]{$urlext}" class="q_h">{lang xigua_hs:cksj}<i style="transform: rotate(0deg);position:relative;" class="iconfont icon-jinrujiantou f12 vm"></i></a>
                    <!--{/if}-->
                <!--{else}-->
                    <div class="my__head_nickname f16">{$_G[username]}</div>
                    <a class="qblink">UID : {$_G[uid]}</a>
                <!--{/if}-->
                </div>
            </div>
        </div>

        <div class="centtop centtop1">
            <div class="weui-cells__title weui_title mt0 f15 bold">{lang xigua_sp:wddd1}

            <a class="y" href="$SCRITPTNAME?id=xigua_sp&ac=order">{lang xigua_sp:ckqbdd} <i class="f13 iconfont icon-jinrujiantou"></i></a>
            </div>

            <div class="cl">
                <a href="$SCRITPTNAME?id=xigua_sp&ac=order&status=1" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-qianbao f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{$status_font[1]}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_sp&ac=order&status=2,6&fa_ts=-1" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-xianshiqianggou f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:dfh}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_sp&ac=order&status=2,6&shou_ts=-1&fa_ts=1" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-huodong1 f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:dshuo}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_sp&ac=order&status=2,6&shou_ts=1&pj_ts=-1" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-ganxie1 f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:dpj}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_sp&ac=order&status=2,6&shou_ts=1&pj_ts=1" class="z" style="width:20%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-ganxie f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:ypj}</p>
                </a>
            </div>
        </div>


        <div class="centtop f15 before_none after_none">
            <div class="weui-cells__title weui_title mt0 f15 bold">{lang xigua_sp:cygj}

                <a class="y" href="$SCRITPTNAME?id=xigua_hb&ac=my">{lang xigua_sp:gd} <i class="f13 iconfont icon-jinrujiantou"></i></a>

            </div>
            <div class="cl">

                <a href="$SCRITPTNAME?id=xigua_hb&ac=myaddr&mobile=2{$urlext}" class="z" style="width:25%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-coordinates_fill color-good f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_hb:myaddr}</p>
                </a>

                <a href="$SCRITPTNAME?id=xigua_hb&ac=myzl&mobile=2&referer={echo urlencode(hb_currenturl());}{$urlext}" class="z" style="width:25%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-shouji  color-red f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:bdsj}</p>
                </a>

                <a class="z" style="width:25%" <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jump_download();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao{$urlext}"<!--{/if}--><!--{/if}-->>
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-qianbao2 color-orange  f22" style="position:relative;top:2px;" ></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:wdqb}</p>
                </a>

                <!--{if $_G['cache']['plugin']['xigua_hs']}-->
                <a href="$SCRITPTNAME?id=xigua_hs&ac=myfav&mobile=2{$urlext}" class="z" style="width:25%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-collection_fill color-vimeo f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_hb:wodeguanzhu}</p>
                </a>
                <!--{/if}-->
            </div>
        </div>


        <!--{if $shcout}-->

        <div class="centtop f15 before_none after_none">
            <div class="weui-cells__title weui_title mt0 f15 bold">{lang xigua_sp:sjgj}</a>
            </div>
            <div class="cl">
                <a href="$SCRITPTNAME?id=xigua_sp&ac=order_manage{$urlext}" class="z" style="width:25%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-jieshao1 f24 color-dropbox"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:ddgl1}</p>
                </a>

                <a href="$SCRITPTNAME?id=xigua_sp&ac=manage{$urlext}" class="z" style="width:25%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-fenlei f22 color-dropbox" style="position:relative;top:1px"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:spgl1}</p>
                </a>

                <a href="$SCRITPTNAME?id=xigua_hs&ac=shcenter{$urlext}" class="z" style="width:25%">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-shop f24 color-dropbox"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_hs:shcenter}</p>
                </a>

                <a href="javascript:;" class="z saoyi" style="width:25%">
                    <div class="weui-grid__icon" style="margin-bottom:4px">
                        <i class="iconfont icon-saoyisao f20 color-dropbox" style="position:relative;top:4px"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:qhhx}</p>
                </a>

                <!--{if $sh[shid]}-->
                <a href="$SCRITPTNAME?id=xigua_hs&ac=myaddr&shid=$sh[shid]{$urlext}" class="z"  style="width:25%;margin-top:15px">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-index color-dropbox f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_hs:szztd}</p>
                </a>
                <!--{/if}-->
                <a href="$SCRITPTNAME?id=xigua_hs&ac=add_area{$urlext}" class="z"  style="width:25%;margin-top:15px">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-mudedi color-dropbox f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_hs:psfsgl}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_sp&ac=shop&shid={$sh[shid]}{$urlext}" class="z"  style="width:25%;margin-top:15px">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-dianpu color-dropbox f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:dpsy}</p>
                </a>
                <a href="javascript:;" class="baoyoubtn z" style="width:25%;margin-top:15px">
                    <div class="weui-grid__icon">
                        <i class="iconfont icon-huodong1 color-dropbox f24"></i>
                    </div>
                    <p class="weui-grid__label f12">{lang xigua_sp:bysz}</p>
                </a>
            </div>
        </div>
        <!--{/if}-->


        <div class="centtop " style="padding-bottom: 0">

            <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=about&mobile=2">
                <div class="weui-cell__hd"><i class="iconfont icon-guize color-forest"></i></div>
                <div class="weui-cell__bd">
                    <p class="f14">{lang xigua_hb:bangzhu}</p>
                </div>
                <div class="weui-cell__ft"> </div>
            </a>
            <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
                <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
                <div class="weui-cell__bd">
                    <p class="f14">{lang xigua_hb:kefu}</p>
                </div>
                <div class="weui-cell__ft f14">{lang xigua_hb:zhwo}</div>
            </a>
        </div>

        <!--{template xigua_sp:viewtools}-->
        <!--{template xigua_sp:tuijian}-->

    </div>
</div>
<div class="masker" style="position: fixed;top: 0;left: 0;right: 0;bottom: 0;background: rgba(0, 0, 0, .5);display: none;z-index:501" onclick='$("#qiehuan").select("close")'></div>
<!--{eval $sp_tabbar=1;$tabbar=0;}-->
<!--{template xigua_sp:footer}-->
<script>
    $(document).on('click','.saoyi', function () {
        <!--{if IN_MAGAPP}-->mag.scanQR(function(text){window.location.href=text});
        <!--{elseif IN_QIANFAN}-->qianfanScan();
        <!--{elseif IN_APPBYME}-->appbymeScan();
        <!--{else}-->wx.scanQRCode();<!--{/if}-->
    });
    function appbymeScan() {
        sq.scan(function(result){
            window.location.href=result.url;
        });
    }
    function qianfanScan(){
        QFH5.jumpScan(function(state,data){
            if(state==1){
                window.location.href=data.content;
            }else{
            }
        })
    }
    function jump_download() {
        $.confirm("$config[qbguide]", function() {
            window.location.href = '$config[qbguidelink]';
        }, function() {
        });
        return false;
    }
    $(document).on('click','.baoyoubtn', function () {
        var that = $(this);
        $.prompt({
            title: '{lang xigua_sp:qtxje}<!--{if $sh[baoyou]}--><br>{lang xigua_sp:ysz}<b class="color-red">{$sh[baoyou]}{lang xigua_hb:yuan}</b> {lang xigua_sp:by}<!--{/if}-->',
            text: '{lang xigua_sp:qtxjedemo}',
            empty: false,
            onOK: function (input) {$.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME +'?id=xigua_sp&ac=wode&do=setbaoyou&shid={$sh[shid]}&inajax=1',
                    data:{formhash:FORMHASH, baoyou:input},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            },
            onCancel: function () {
            }
        });
    }); var itar = [];
    <!--{loop $list $_sh}--><!--{if $_sh[name]}-->
    itar.push({title: '{$_sh[name]}', value:'{$_sh[shid]}'});
    <!--{/if}--><!--{/loop}-->
    $("#qiehuan").select({
        title: "{lang xigua_hs:qxzsydp}",
        items: itar,
        onOpen: function () {
            $('.masker').fadeIn();
        },
        beforeClose: function () {
            $('.masker').fadeOut(300);
            window.location.href=_APPNAME+"?id=xigua_sp&ac=wode&mobile=2&shid="+$("#qiehuan").data('values')+_URLEXT;
            return true;
        }
    });
</script>