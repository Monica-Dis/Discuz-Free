<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<style>.level1 .tab.weui_bar__item_on { font-size: 14px; color: #e02e24; background: #fff!important;}
body {background-color: #fff;}
.site_header_inner{position: fixed;width: 100%;max-width: 48rem;left: 0;right: 0;margin: 0 auto;max-height: 8.5rem;z-index: 30;overflow: hidden;height: 7rem;
}.weui-navbar {background: #fff;position: fixed;top: 7rem;}
.scroll-view.level1.scroll-y{position: fixed!important;top: 9.5rem!important;z-index: 9;height:calc(100vh - 9.5rem);}
.scroll-view.level2.scroll-y{width: calc(100vw - 4.15rem);flex: none;right: 0;left: 4.15rem;top: 9.5rem!important;padding-bottom: 2rem;min-height: calc(100vh - 11.5rem)!important;}
</style>
<div class="page__bd ">
    <div class="site_header" id="js_site_header">
        <div class="site_header_inner">
            <div class="site_header_background_image_inside">
                <div class="shop_brand_image">
                    <img src="source/plugin/xigua_sp/static/shoplogo.png" >
                </div>
            </div>
            <header class="x_header  cl f15">
                <!--{if !IN_PROG}-->
                <a class="z f14" href="javascript:window.history.go(-1);"><i class="iconfont icon-fanhuijiantou w15"></i></a>
                <!--{/if}-->
                <a class="y sidectrl view_ctrl"><i class="iconfont icon-gengduo1 f22"></i></a>
                <div class="navtitle">
                    <a  class="new_search" href="$SCRITPTNAME?id=xigua_sp&ac=search&shid={$sh['shid']}">{lang xigua_sp:ssbd}</a>
                </div>
            </header>
            <div class="shop_profile">
                <a class="shop_profile_link sh_jump" href="javascript:;" data-id="{$sh['shid']}">
                    <div class="shop_profile_logo">
                        <img src="{$sh[logo]}">
                    </div>
                    <div class="shop_profile_name">{$sh[name]} <i class="f13 iconfont icon-jinrujiantou vm"></i>
                    </div>
                    <div class="shop_profile_extra">
                        <span>{$sh['follow']}{lang xigua_sp:rgz}</span>
                        <span class="color-red ml8">{lang xigua_sp:hp}{$avgstar}%</span>
                    </div>
                </a>
                <!--{if $followed}-->
                <a href="javascript:;" class="follow_button js_follow_button do_follow shbtn" data-id="$sh[shid]" data-qr="$sh[qr]"><i class="iconfont icon-collection_fill vm f12"></i>{lang xigua_hs:yiguanzhu}</a>
                <!--{else}-->
                <a href="javascript:;" class="follow_button js_follow_button do_follow shbtn" data-wei="1" data-id="$sh[shid]" data-qr="$sh[qr]">{lang xigua_hs:jiaguanzhu}</a>
                <!--{/if}-->
            </div>
        </div>
    </div>
    <!--{template xigua_sp:viewtools}-->
    <div class="weui-navbar">
        <a href="javascript:;" data-ext="sort=zonghe" class="shopsort weui-navbar__item weui_bar__item_on">
            <span>{lang xigua_sp:zh}</span>
        </a>
        <a href="javascript:;" data-ext="sort=sellnum" class="shopsort weui-navbar__item">
            <span>{lang xigua_sp:xl}</span>
        </a>
        <a href="javascript:;" data-ext="sort=dprice" class="shopsort weui-navbar__item shop_mod_sortbar up">
            <span>{lang xigua_sp:jg}<i></i></span>
        </a>
        <a href="javascript:;" data-ext="sort=crts" class="shopsort weui-navbar__item">
            <span>{lang xigua_sp:sx}</span>
        </a>
    </div>
    <div class="cate cate_pgapp" style="position:relative;top:0;min-height:calc(100vh - 190px)">
        <div class="scroll-view level1 scroll-y"  style="position:relative;top:0;min-height:calc(100vh - 190px)">
            <div  data-ext="catid=0&shid={$sh[shid]}"  class="shopsort tab tab123 <!--{if !$_GET[catid]}-->cur<!--{/if}-->">{lang xigua_hb:quanbu}</div>
            <!--{loop $newcat $lpk $loopin}-->
            <div  data-ext="catid={$loopin[id]}&shid={$sh[shid]}" class="shopsort tab tab123 <!--{if ($lpk==0&&!isset($_GET[catid])) || $_GET[catid]==$loopin[id] }-->cur<!--{/if}-->">{$loopin[name]}</div>
            <!--{/loop}-->
        </div>
        <div class="scroll-view level2 scroll-y" style="position:relative;top:0;min-height:calc(100vh - 190px)">
            <ul class="goodlist good_2" id="list"> </ul>
            <!--{template xigua_hb:loading}-->
        </div>
    </div>
</div>
<div class="right_float hbtn" style="bottom:158px" onclick="hb_jump('$SCRITPTNAME?id=xigua_sp&ac=gwc');">
    <span id="gwcnum" class="weui-badge" style="position:absolute;top:-2px;display:none;right:0"></span>
    <i class="iconfont icon-gouwuche f22 cfff" style="line-height:40px"></i></div>
<!--{template xigua_sp:shopbtm}-->

<!--{eval $sp_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_sp:footer}-->
<script>
    loadingurl = _APPNAME+'?id=xigua_sp&ac=cat_li&catid={$_GET[catid]}&shid={$sh[shid]}&inajax=1&sort=zonghe&page=';
    $(document).on('click','.tab123', function () {
        $(this).siblings().removeClass('cur').removeClass('weui_bar__item_on');
    });
</script>