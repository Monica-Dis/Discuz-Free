<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<!--{eval $keyword = $_GET['keyword'];}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_sp&ac=manage&stat=1" class="weui-navbar__item <!--{if 1==$_GET[stat]||!$_GET[stat]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_sp:jxz}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_sp&ac=manage&stat=2" class="weui-navbar__item <!--{if $_GET[stat]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_sp:dsh}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_sp&ac=manage&stat=3" class="weui-navbar__item <!--{if $_GET[stat]==3}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_sp:yxj}</span> </a>
    </div>


    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">

            <input name="id" value="xigua_sp" type="hidden">
            <input name="ac" value="manage" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">

            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_sp:spmc}" data-hold="{lang xigua_sp:qtx}{lang xigua_sp:spmc}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_sp:spmc}</span>
            </label>
        </form>
        <a href="javascript:" class="search_bar_btn main_color" id="dosearch">{lang xigua_sp:search}</a>
        <a href="$SCRITPTNAME?id=xigua_sp&ac=manage{$mang}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_sp:qx}</a>
    </div>

    <div>
        <div id="list" class="mod-post x-postlist p0"></div>
        <!--{template xigua_hb:loading}-->
    </div>

    <div class="footer_fix"></div>
    <!--{template xigua_sp:viewtools}-->
</div>
<a href="$SCRITPTNAME?id=xigua_sp&ac=add" class="float_btn"><i class="iconfont icon-zengjia"></i> {lang xigua_sp:fbsp}</a>

<script>
    var loadingurl = window.location.href+'&ac=good_li&inajax=1&page=';
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_sp:footer}-->