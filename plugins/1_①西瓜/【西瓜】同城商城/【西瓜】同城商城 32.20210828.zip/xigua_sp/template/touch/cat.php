<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<style>.fixbanner_in .ajaxcat{min-width:28px}</style>
<div class="page__bd ">
<!--{eval $showcat = !$keyword && !$_GET['shid']}-->
    <!--{template xigua_sp:search_bar}-->
    <!--{template xigua_sp:viewtools}-->
    <!--{if $showcat}-->
    <div class="weui-cells fixbanner before_none mt0" style="top:auto">
        <div class="weui-navbar weui-banner nobg fixbanner_in">

            <a href="$SCRITPTNAME?id=xigua_sp&mobile=2" class="weui-navbar__item none">
                <span>{lang xigua_sp:tj}</span>
            </a>

            <!--{loop $cat_list $cat}-->
            <a href="$SCRITPTNAME?id=xigua_sp&ac=cat&catid={$cat[id]}" class="weui-navbar__item <!--{if $cat[id]==$_GET['catid']||$mypid==$cat[id]}-->weui_bar__item_on<!--{/if}-->">
                <span>$cat[name]</span>
            </a>
            <!--{/loop}-->
        </div>
    </div>
    <!--{/if}-->

    <!--{if count($jing_list)==4}-->
    <!--{eval $jingw = "width:calc(25% - 12px)";}-->
    <!--{/if}-->
    <!--{if $showcat && $jing_list}-->
    <nav class="nav-list cl swipe transparent mt3 border_bottom" style="padding-top:.2rem;border-radius:0">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $jing_list $k $n}-->
                    <!--{if $k && $k%5==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li style="{$jingw}" class="ajax_cat <!--{if ($k==0&&!$_GET['catid']) || $n[id]==$_GET['catid']}-->ajax_cat_cur<!--{/if}-->" data-id="{$n[id]}">
                        <a href="javascript:;">
                            <span>
                                <img src="{echo $n['icon'] ?$n['icon'] : 'source/plugin/xigua_hb/static/img/icon.png'}"/>
                            </span>
                            <em class="m-piclist-title <!--{if intval($_GET[cat_id])==$n[id]}-->main_color<!--{/if}-->">{$n['name']}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <nav class="cl bullets bullets1" style="display:none">
            <ul class="position position1">
                <!--{loop $jing_count $k $v}-->
                <li {if $k==0} class="current" {/if}></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </nav>
    <!--{/if}-->

    <!--{template xigua_sp:tools_nav}-->

    <ul class="goodlist" id="list"> </ul>
    <!--{template xigua_hb:loading}-->
</div>
<script>
    var loadingurl = window.location.href+'&ac=cat_li&inajax=1&page=';
</script>
<!--{eval $sp_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_sp:footer}-->