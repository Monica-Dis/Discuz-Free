<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<style>.weui-cells_radio .weui-check:checked+.weui-icon-checked:before{content:'\EA06';font-size:21px;display:block}.weui-cells_radio .weui-icon-checked:before{content:'\EA01';color:#c9c9c9;font-size:21px;display:block;margin:0}
.s_quan_tag{position:absolute;left:0;bottom:.4rem;background-color:#fff6f6;color:#fb6165;padding:.1rem .25rem;line-height:1;border-radius:1rem;font-size:.6rem}
.s_quan_tag:after{border-radius:1rem!important}</style>
<div class="page__bd">
<form  action="$SCRITPTNAME?id=xigua_sp&ac=buy&st={$_GET['st']}" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <!--{loop $_GET $gk $gv}-->
    <input type="hidden" name="form[$gk]" value="{$gv}">
    <!--{/loop}-->
    <!--{if $tye != 'single'}-->
    <input  type="hidden" name="form[mult]" value="1">
    <!--{/if}-->
    <input type="hidden" name="form[isdf]" value="0">
    <div class="weui-cells before_none after_none mt0">

        <div class="weui-cell weui-cell_access after_none">
            <div class="weui-cell__hd"><a class="z f16" href="javascript:window.history.go(-1);"><i class="iconfont icon-fanhuijiantou w15"></i></a></div>
            <div class="weui-cell__hd"><img class="confirm_shlogo" src="$sh[logo]" onerror="this.error=null;$(this).remove();" /></div>
            <div class="weui-cell__bd"><span class="f14">$sh[name]</span></div>
        </div>

        <!--{if $tye == 'single'}-->
        <div class="weui-cell weui-cell_access after_none" style="display:block;overflow:hidden">

            <div class="weui-cell__hd z">
                <label class="weui-label " style="width:95px">
                    <img style="width: 80px;height: 80px;" src="{echo $v[album][0]?$v[album][0]:$v[fengmian]}">
                </label>
            </div>
            <div class="weui-cell__bd pr">
                <p class="f14 c3">{$v[title]}</p>
                <!--{loop $v[spgg_ary] $_spk $_spn}-->
                <p class="f12 c9">{$_spn[name]}: {$v['price_name'][$_spk]}</p>
                <!--{/loop}-->

                <!--{if $v[baoyou_type]==1}-->
                <p class="f12 c9">{lang xigua_sp:man3} <span class="main_color">{$v[baoyou_num]}{lang xigua_sp:yuan}</span> {lang xigua_sp:by}</p>
                <!--{/if}-->
                <p class="f14 main_color" >
                <!--{if $good_price[price_pt]>0}-->
                &yen;{$good_price[price_pt]} / {lang xigua_sp:j}
                <!--{/if}-->
                <!--{if $good_price[price_jf]>0}-->
                {$good_price[price_jf_str]}
                <!--{elseif $good_price[jifenprice]>0}-->
                {$good_price[jifenprice]}
                <!--{/if}-->
                </p>
            </div>
        </div>
        <div class="weui-cell before_none">
            <div class="weui-cell__bd">
                <p class="f14">{lang xigua_sp:sl}</p>
            </div>
            <div class="weui-cell__ft main_color">
                <i class="iconfont icon-jianshao2 inc-num" data-step="-1"></i>
                <input class="inc-input" type="tel" name="form[item_num]" id="item_num" value="{$_GET['num']}" data-max="$v[danci]" data-price="{$good_price[price_pt]}"  >
                <i class="iconfont icon-tianjia1 inc-num" data-step="1"></i>
            </div>
        </div>
        <!--{else}-->
        <!--{loop $good_prices $_k $_v}-->
<!--{eval
$good = $goods[$_v[gid]];
$good['price_name'] = explode('###', $_v['name']);
$psfs_val = $good[psfs_val];
}-->
        <div data-psfs="$psfs_val" class="weui-cell weui-cell_access after_none" style="display:block;overflow:hidden">
            <div class="weui-cell__hd z">
                <label class="weui-label " style="width:95px">
                    <img style="width: 80px;height: 80px;" src="{echo $good[album][0] ? $good[album][0] : $good[fengmian]}" />
                </label>
            </div>
            <div class="weui-cell__bd pr">
                <p class="f14 c3">{$good[title]}</p>
                <!--{loop $good[spgg_ary] $_spk $_spn}-->
                <p class="f12 c9">{$_spn[name]}: {$good['price_name'][$_spk]}</p>
                <!--{/loop}-->
                <!--{if $_v[price_pt]>0}-->
                <p class="f14 main_color" >&yen;{$_v[price_pt]} / {lang xigua_sp:j}</p>
                <!--{/if}-->
            </div>
        </div>
        <div class="weui-cell before_none">
            <div class="weui-cell__bd">
                <p class="f14">{lang xigua_sp:sl}</p>
            </div>
            <div class="weui-cell__ft main_color">
                <i class="iconfont icon-jianshao2 inc-num" data-step="-1"></i>
                <input class="inc-input" type="tel" name="form[item_num][{$_v[id]}]" value="{$gidnum[$_k]}" data-max="$good[danci]" data-price="{$_v[price_pt]}" >
                <i class="iconfont icon-tianjia1 inc-num" data-step="1"></i>
            </div>
        </div>
        <!--{/loop}-->

        <!--{/if}-->
    </div>

    <div class="weui-cells__title">{lang xigua_sp:bz}</div>
    <div class="weui-cells before_none after_none">
        <div class="weui-cell ">
            <div class="weui-cell__bd">
                <input class="weui-input f14" name="form[note]" id="item_note" type="text" placeholder="{lang xigua_sp:xt}" value="{$_GET['note']}">
            </div>
        </div>
    </div>
<!--{if 0&& $_G['cache']['plugin']['xigua_hm'] && $sh[shid]}-->
<div class="weui-cells__title">{lang xigua_hs:yhq}</div>
<div id="list" class=" x-postlist p0"></div>
<script>
    var loadingurl = _APPNAME+'?id=xigua_hm&ac=my_order&do=seckill_li&&stype=youhui&inajax=1&shid={$sh[shid]}&confirm=1&status=2&pagesize=4&page=';
    $('head').append('<link rel="stylesheet" href="source/plugin/xigua_hs/static/hs.css?{VERHASH}" />');</script>
<!--{/if}-->

    <div class="weui-cells__title">{lang xigua_sp:psfs}</div>
    <div class="weui-cells before_none after_none">
        <div class="weui-cell ">
            <div class="weui-cell__bd">
                <div class="post-tags buy-tags cl">
<!--{if $good_price[kami]}-->
    <input type="hidden" name="form[exp_method]" id="showmethod" value="daodian">
    <a class="weui-btn weui-btn_mini weui-btn_default tag-on" data-tyid="daodian" style="margin-bottom:0" href="javascript:;">{lang xigua_sp:xnkmzdfh}</a>
<!--{else}-->
    <!--{if $v['psfs_val']==2||$psfs_val==2}-->
        <a class="weui-btn weui-btn_mini weui-btn_default tag-on" data-tyid="kuaidi" style="margin-bottom:0" href="javascript:;">{lang xigua_sp:kdfy}</a>
        <!--{if $sp_config[allowdf]}-->
            <a class="weui-btn weui-btn_mini weui-btn_default" data-tyid="daifa" style="margin-bottom:0" href="javascript:;">{lang xigua_sp:dfdd}</a>
        <!--{/if}-->
        <!--{if $sp_config[allowhd]}-->
            <a class="weui-btn weui-btn_mini weui-btn_default hdfkbtn" data-tyid="hdfk" style="margin-bottom:0" href="javascript:;">{lang xigua_sp:hdfk}</a>
        <!--{/if}-->
        <input type="hidden" name="form[exp_method]" id="showmethod" value="kuaidi">
    <!--{elseif $v['psfs_val']==1||$psfs_val==1}-->
        <a class="weui-btn weui-btn_mini weui-btn_default" id="trigger_daodian" data-tyid="daodian" style="margin-bottom:0" href="javascript:;">{lang xigua_sp:ddhx}</a>
        <input type="hidden" name="form[exp_method]" id="showmethod" value="daodian">
    <!--{else}-->
        <a class="weui-btn weui-btn_mini weui-btn_default tag-on" data-tyid="kuaidi" style="margin-bottom:0" href="javascript:;">{lang xigua_sp:kdfy}</a>
        <!--{if $sp_config[allowdf]}-->
        <a class="weui-btn weui-btn_mini weui-btn_default" data-tyid="daifa" style="margin-bottom:0" href="javascript:;">{lang xigua_sp:dfdd}</a>
        <!--{/if}-->
        <!--{if $sp_config[allowhd]}-->
        <a class="weui-btn weui-btn_mini weui-btn_default hdfkbtn" data-tyid="hdfk" style="margin-bottom:0" href="javascript:;">{lang xigua_sp:hdfk}</a>
        <!--{/if}-->
        <a class="weui-btn weui-btn_mini weui-btn_default" data-tyid="daodian" style="margin-bottom:0" href="javascript:;">{lang xigua_sp:ddhx}</a>
        <input type="hidden" name="form[exp_method]" id="showmethod" value="kuaidi">
    <!--{/if}-->
<!--{/if}-->
                </div>
            </div>
        </div>
    </div>

    <div class="weui-cells before_none after_none weui-cells_radio <!--{if $good_price[kami]}-->none<!--{/if}-->">
        <a class="weui-cell weui-cell_access after_none payaddress" href="javascript:;" id="pay_address">
            <div class="weui-cell__hd">
                <label class="weui-label mr8" style="width:auto"><i class="f20 c3 iconfont icon-mudedi vm"></i></label>
            </div>
            <div class="weui-cell__bd c3">
                <!--{if $dft[mobile]}-->
                <div class="f12 "><span class="f14">{$dft[realname]}</span>&nbsp;{$dft[mobile]}</div>
                <div class="f12 mt3">{$dft[dist1]}&nbsp;{$dft[dist2]}&nbsp;{$dft[dist3]}&nbsp;{$dft[address]}</div>
                <input type="hidden" name="form[dist1]" value="$dft[dist1]">
                <input type="hidden" name="form[dist2]" value="$dft[dist2]">
                <input type="hidden" name="form[dist3]" value="$dft[dist3]">
                <input type="hidden" name="form[address]" value="$dft[address]">
                <input type="hidden" name="form[realname]" value="$dft[realname]">
                <input type="hidden" name="form[mobile]" value="$dft[mobile]">
                <input type="hidden" name="form[addrid]" value="$addr[id]">
                <!--{else}-->
                <div class="f14">{lang xigua_sp:djszshdz}</div>
                <!--{/if}-->
            </div>
            <div class="weui-cell__ft">
            </div>
            <div class="addrbx"></div>
        </a>

        <div id="vopenLocation" style="display: none">
            <!--{eval
            if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/table/table_xigua_hs_addr.php')):
                $daodianlist = C::t('#xigua_hs#xigua_hs_addr')->fetch_all_by_page($start_limit, $lpp, array("shid=".intval($sh[shid])));
            endif;
            if(!$daodianlist):
                $daodianlist = array();
            endif;

            $daodianlist[] = array(
                'dist1' => $sh[province],
                'dist2' => $sh[city],
                'dist3' => $sh[district],
                'realname' => $sh[name],
                'mobile' => $sh[tel],
                'address' => $sh[addr],
            );
            }-->
            <!--{loop $daodianlist $_k $_v}-->
            <label class="weui-cell weui-check__label" for="x$_k">
                <div class="weui-cell__hd">
                    <label class="weui-label mr8" style="width:auto"><i class="f20 c3 iconfont icon-mudedi vm"></i></label>
                </div>
                <div class="weui-cell__bd c3">
                    <div class="f12 "><span class="f14">{lang xigua_sp:ztd}</span> {lang xigua_sp:lxr_}{$_v[realname]} {lang xigua_sp:sjh_}{$_v[mobile]}</div>
                    <div class="f12">{$_v[dist1]}{$_v[dist2]}{$_v[dist3]}{$_v[address]}</div>
                </div>
                <div class="weui-cell__ft">
                    <input <!--{if $_k==0}-->checked<!--{/if}--> type="radio" class="weui-check" name="form[ziti]" value="{lang xigua_sp:lxr_}{$_v[realname]} {lang xigua_sp:sjh_}{$_v[mobile]}||||{$_v[dist1]}{$_v[dist2]}{$_v[dist3]}{$_v[address]}||||$_v[lat]||||$_v[lng]" id="x$_k">
                    <span class="weui-icon-checked"></span>
                </div>
            </label>
            <!--{/loop}-->
        </div>
<!--{if $sp_config[allowdf]}-->
        <div id="df" style="display:none">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="iconblack">{lang xigua_sp:ji}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[jaddr]" value="{echo getcookie('jaddr')}" placeholder="{lang xigua_sp:qtxjaddr}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <input class="weui-input" type="text" name="form[jname]" value="{echo getcookie('jname')}" placeholder="{lang xigua_sp:qtxjname}">
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[jmobile]" value="{echo getcookie('jmobile')}" placeholder="{lang xigua_sp:qtxjmobile}">
                </div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="iconblack main_bg">{lang xigua_sp:shou}</label></div>
                <div class="weui-cell__bd">
                    <!--{if $dft[mobile]}-->
                    <div class="f12 "><span class="f14">{$dft[realname]}</span>&nbsp;{$dft[mobile]}</div>
                    <div class="f12 mt3">{$dft[dist1]}&nbsp;{$dft[dist2]}&nbsp;{$dft[dist3]}&nbsp;{$dft[address]}</div>
                    <input type="hidden" name="form[dist1]" value="$dft[dist1]">
                    <input type="hidden" name="form[dist2]" value="$dft[dist2]">
                    <input type="hidden" name="form[dist3]" value="$dft[dist3]">
                    <input type="hidden" name="form[address]" value="$dft[address]">
                    <input type="hidden" name="form[realname]" value="$dft[realname]">
                    <input type="hidden" name="form[mobile]" value="$dft[mobile]">
                    <input type="hidden" name="form[addrid]" value="$addr[id]">
                    <!--{else}-->
                    <div class="f14">{lang xigua_sp:qxzsjr}</div>
                    <!--{/if}-->
                </div>
                <div class="weui-cell__ft">
                    <a href="javascript:;" class="payaddress main_color">{lang xigua_sp:dzb}</a>
                </div>
            </div>
        </div><!--{/if}-->
    </div>

    <div class="footer_fix"></div>
    <div class="fix-bottom" style="padding:0">

        <div class="confirm_foot">
            <div class="confirm_foot_d">
                <em>{lang xigua_sp:sfk}:</em>
                <span class="price"><a id="danwei">&yen;</a><a href="javascript:;" id="price_last">{$price_last}</a>
                <!--{if $good_price[price_jf]>0}-->
                    <a href="javascript:;" id="danwei2 none ptcolor f12">{$_G['setting']['extcredits'][$config['credit_type']]['title']}</a>
                <!--{/if}-->
                </span>
                <em class="ptcolor f12" id="price_yf">
                    <!--{if $yf>0}-->{lang xigua_sp:yf}: $yf {lang xigua_sp:yuan}<!--{else}-->{lang xigua_sp:myf}<!--{/if}-->
                </em>
            </div>
            <input class="confirm_foot_btn" value="{lang xigua_sp:ljxd}" id="dosubmit" name="dosubmit" type="submit">
        </div>

    </div>
</form>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_sp:footer}-->
<!--{if $sp_config[allowdf]}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.min.js" charset="utf-8"></script>
<script>$("#dist").cityPicker({ title: "{lang xigua_hb:plzdist}" });</script>
<!--{/if}-->
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script>
var YUNFEI = $yf, YUNFEISTO = $yf;
var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}", HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";
function incNumCallback(ipt){
    <!--{if $tye == 'single'}-->
    incNum();
    <!--{else}-->
    var iptop = ipt.parent().parent().parent();
    var ipts = iptop.find('.inc-input');
    var ipt_show = 0;
    ipts.each(function () {
        var that = $(this);
        ipt_show += parseFloat(that.data('price')*that.val());
    });
    $('#price_last').html(parseFloat(ipt_show+YUNFEI).toFixed(2));
    $('#price_yf').html(YUNFEI ? '{lang xigua_sp:yf}: '+YUNFEI+' {lang xigua_sp:yuan}' :'{lang xigua_sp:myf}');
    <!--{/if}-->
}
function incNum(){
    var ipt = $('.inc-input');
    console.log(ipt.val());
    <!--{if $good_price[price_pt]>0}-->
    $.ajax({
        type: 'GET',
        url: _APPNAME + '?id=xigua_sp&gid={$_GET[gid]}&ac=shisuan&num='+ipt.val()+'&price={$good_price[price_pt]}&yf='+YUNFEI+'&inajax=1'+_URLEXT,
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            console.log(s.split('_'));
            if(s){
                $('#danwei2').hide();
                $('#price_last').html(s.split('_')[0]);
                $('#price_yf').html(s.split('_')[1] ? '{lang xigua_sp:yf}: '+s.split('_')[1]+' {lang xigua_sp:yuan}' :'{lang xigua_sp:myf}');
            }
        }
    });
    <!--{elseif $good_price[price_jf]>0}-->
    $.ajax({
        type: 'GET',
        url: _APPNAME + '?id=xigua_sp&gid={$_GET[gid]}&ac=shisuan&num='+ipt.val()+'&price={$good_price[price_jf]}&yf=0&inajax=1'+_URLEXT,
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            console.log(s.split('_'));
            if(s){
                $('#danwei').html('');
                $('#danwei2').show();
                $('#price_last').html(s.split('_')[0]);
                $('#price_yf').html(s.split('_')[1] ? '{lang xigua_sp:yf}: '+s.split('_')[1]+' {lang xigua_sp:yuan}' :'{lang xigua_sp:myf}').hide();
            }
        }
    });
    <!--{/if}-->
}
$(document).on('click','.buy-tags a', function () {
    var that = $(this);
    var exp_method = that.data('tyid');
    $('.buy-tags').find('a').removeClass('tag-on');
    that.addClass('tag-on');
    if(exp_method =='kuaidi'){
        $('#showmethod').val('kuaidi');
        YUNFEI = YUNFEISTO;
        $('#pay_address').show();
        $('#vopenLocation').hide();
        $('#df').hide();
        $('input[name="form[isdf]"]').val('0');
    }else if(exp_method=='daifa'){
        $('#showmethod').val('kuaidi');
        YUNFEI = YUNFEISTO;
        $('#df').show();
        $('#pay_address').hide();
        $('#vopenLocation').hide();
        $('input[name="form[isdf]"]').val('1');
    }else if(exp_method=='hdfk'){
        $('#showmethod').val('hdfk');
        YUNFEI = YUNFEISTO;
        $('#df').show();
        $('#pay_address').show();
        $('#vopenLocation').hide();
        $('#df').hide();
        $('input[name="form[isdf]"]').val('0');
    }else{
        $('#showmethod').val('daodian');
        YUNFEI = 0;
        $('#pay_address').hide();
        $('#vopenLocation').show();
        $('#df').hide();
        $('input[name="form[isdf]"]').val('0');
<!--{if $sp_config[allowdw]}-->
        hs_getlocation(function (position) {
            var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
            $.ajax({
                type: 'get',
                url: _APPNAME + '?id=xigua_sp&ac=com&do=addrlist&shid={$sh[shid]}&lat='+lat+'&lng='+lng,
                dataType: 'xml',
                success: function (data) {
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    if(s){
                        $('#vopenLocation').html(s);
                    }
                    $.hideLoading();
                },
                error: function() {
                    $.hideLoading();
                }
            });
        });
<!--{/if}-->
    }
    incNumCallback($('.inc-input'));
});
<!--{if $v['psfs_val']==1||$psfs_val==1}-->
$('#trigger_daodian').trigger('click');
<!--{/if}-->
incNumCallback($('.inc-input'));


$(document).on('click','.weuicheck1', function () {
    $(this).parent().parent().parent().parent().siblings().find('.weuicheck1:checked').removeAttr('checked');
});
</script>