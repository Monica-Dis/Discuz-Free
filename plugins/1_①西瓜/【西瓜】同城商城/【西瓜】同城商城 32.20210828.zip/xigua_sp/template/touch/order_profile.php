<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->

    <!--{template xigua_sp:order_top}-->

<!--{if $v['exp_method']=='kuaidi'}-->
    <div class="weui-cells before_none after_none mt0">
        <!--{if $v[jaddr]}-->
        <div class="weui-cell after_none" href="javascript:;">
            <div class="weui-cell__hd">
                <label class="weui-label" style="width:auto"><i class="iconblack">{lang xigua_sp:fa}</i></label>
            </div>
            <div class="weui-cell__bd c3">
                <div class="f12 "><span class="f14">{$v[jname]}</span>&nbsp;{$v[jmobile]}   <span style="font-size: 12px;color: #fff;border-radius:12px;padding:0 5px;background:{$config[maincolor]}">{lang xigua_sp:dfddxq}</span></div>
                <div class="f12 mt3">{$v[jaddr]}</div>
            </div>
        </div>
        <!--{/if}-->
        <a class="weui-cell weui-cell_access after_none" href="javascript:;" <!--{if $v[status]==1||$v[status]==5}-->id="pay_address"<!--{/if}--> >
            <div class="weui-cell__hd">
                <label class="weui-label" style="width:auto"><i class="iconblack main_bg">{lang xigua_sp:shou}</i></label>
            </div>
            <div class="weui-cell__bd c3">
                <div class="f12 "><span class="f14">{$v[realname]}</span>&nbsp;{$v[mobile]}</div>
                <div class="f12 mt3">{$v[addr]}</div>
            </div>
            <!--{if $v[status]==1||$v[status]==5}--><div class="weui-cell__ft"></div><!--{/if}-->
            <div class="addrbx"></div>
        </a>
    </div>
<!--{elseif $v['exp_method']=='daodian'}-->
<!--{if $v[priceshot][kami]}-->
<!--{else}-->
<!--{eval $sh = $v['sh'];
$vziti = $vziti2 = array();
foreach(explode('||||', $v[ziti]) as $_tmp1 => $_tmp2):
    if(!is_numeric($_tmp2)):
        $vziti[$_tmp1] = $_tmp2;
    else:
        $vziti2[$_tmp1] = $_tmp2;
    endif;
endforeach;
if($vziti2):
    $sh[addr] = $vziti[1];
    $sh[lat] = $vziti2[2];
    $sh[lng] = $vziti2[3];
endif;
}-->
    <div class="weui-cells f15 before_none after_none mt0">
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <span class="main_color"><!--{if $_GET['manage']==1}-->{lang xigua_sp:ddqhewm}<!--{else}-->{lang xigua_sp:gmhqdd}<!--{/if}--></span>
                <!--{if $v[ziti]}-->
                <p class="f13">{lang xigua_sp:ztd_}</p>
                <p class="c9 f13">{echo implode('<br>', $vziti);}</p>
                <!--{/if}-->
            </div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]"><img src="{$sh[logo]}"></a></div>
            <div class="weui-cell__bd">
                <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]">{$sh[name]}</a></p>
                <p class="f13 c9">{lang xigua_sp:yysj}: <em>{$sh[opentime]}</em></p>
            </div>
            <div class="weui-cell__ft">
                <a href="javascript:;" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_sp:smj}", "{lang xigua_sp:wxzca}");'><i class="iconfont icon-sixin2 mr15 main_color f24"></i></a>
                <a class="shtel" <!--{if $sh[teljs]}-->$sh[teljs]<!--{else}-->href="tel:{$sh[tel]}"<!--{/if}-->><i class="iconfont icon-unie607 main_color f24"></i></a>
            </div>
        </div>

        <a class="weui-cell weui-cell_access" href="javascript:;" id="v_openLocation" data-lat="{$sh[lat]}" data-lng="{$sh[lng]}" data-name="{$sh[name]}" data-addr="{$sh[addr]}">
            <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
            <div class="weui-cell__bd">
                <p class="f14">{$sh[addr]}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
    </div>
<!--{/if}-->
<!--{/if}-->


    <!--{template xigua_sp:viewtools}-->

    <!--{if $_GET['manage'] && $_GET['code']}-->
    <div class="fix-bottom" style="position: relative;box-shadow:none">
        <!--{if $v[hxcrts]>0}-->
        <a href="javascript:;" class="weui-btn weui-btn_default">{lang xigua_sp:hxcg}</a>
        <!--{elseif $v[status]==2 || $v[status]==6}-->
        <a href="javascript:;" class="weui-btn weui-btn_primary upscan">{lang xigua_sp:djhx}</a>
        <!--{/if}-->
    </div>
    <!--{/if}-->
    <!--{template xigua_sp:ptuserlist}-->
    <div class="pt_order_li mt10">
        <div class="pt_shlink">
            <a class="sh_jump" data-id="{$v['shid']}"> <img class="confirm_shlogo" src="{$v['sh'][logo]}"/>
                <span class="f13">{$v['sh'][name]}</span> <i class="f13 iconfont icon-jinrujiantou"></i> </a>
        </div>
        <div class="jump_sp weui-cell weui-cell_access before_none after_none" style="display:block;overflow:hidden" data-id="{$v[goodshot][id]}">
            <div class="weui-cell__hd z">
                <label class="weui-label " style="width:4.75rem">
                    <img style="width: 4rem;height: 4rem;" src="{echo $v[goodshot][album][0] ? $v[goodshot][album][0] : $v[goodshot][fengmian]}"/>
                </label>
            </div>
            <div class="weui-cell__bd ">
                <p class="f14 c3">{$v[goodshot][title]}</p>
                <!--{eval $price_name = explode('###', $v[priceshot]['name'])}-->
                <!--{loop $v[goodshot][spgg_ary] $_spk $_spn}-->
                <p class="f12 c9">{$_spn[name]}: {$price_name[$_spk]}</p>
                <!--{/loop}-->
<!--{if $v[priceshot][price_jf]>0}-->
    <div class="f14 cl ptcolor">$v[priceshot][price_jf]{$_G['setting']['extcredits'][$config['credit_type']]['title']} / {lang xigua_sp:j}  <span class="y">x {$v[gnum]}</span></div>
<!--{else}-->
    <div class="f14 cl ptcolor">&yen;{$v[unit_price]} / {lang xigua_sp:j} <span class="y">x {$v[gnum]}</span></div>
<!--{/if}-->
            </div>
        </div>
        <div class="pt_func  weui-cell">
            <div class="weui-cell__bd f12">
<!--{if $v[priceshot][price_jf]>0}-->
    {lang xigua_sp:sfk}: <em class="ptcolor">{echo $v[priceshot][price_jf] * $v[gnum]} {$_G['setting']['extcredits'][$config['credit_type']]['title']}</em>
<!--{else}-->
    <!--{if $v[exp_method]=='hdfk'}-->{lang xigua_sp:hdfk}:<!--{else}-->{lang xigua_sp:sfk}:<!--{/if}-->
    <em class="ptcolor">&yen;{$v[pay_money]}</em> (<!--{if $v[yunfee]>0}--> {lang xigua_sp:yf}: {$v[yunfee]} {lang xigua_sp:yuan}<!--{else}--> {lang xigua_sp:myf}<!--{/if}--> )
<!--{/if}-->
            </div>
            <div class="weui-cell__ft">
                <!--{template xigua_sp:order_status}-->
            </div>
        </div>
    </div>
    <!--{if $v[yundan]&&$sp_config[kdcode]}-->
    <div class="weui-cells__title" id="kdcode_title">{lang xigua_sp:kdgz}</div>
    <div class="wuei-cells" id="kdcode"></div>
    <script>
        var s2 = localStorage.getItem('kd{$v[yundan]}');
        var s3 = localStorage.getItem('kd{$v[yundan]}_expire')>{echo time();};
        console.log(localStorage.getItem('kd{$v[yundan]}_expire'));
        if(s2 && s3){
            $('#seckdcode').hide();
            $('#kdcode').html(s2).show();
            $('#kdcode_title').show();
        }else{
            $.ajax({type: 'get',url: _APPNAME +'?id=xigua_sp&ac=com&do=kd&inajax=1&danhao={$v[yundan]}',dataType: 'xml',
                success: function (data) {
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    if(!s){
                        $('#seckdcode').show();
                        $('#kdcode').hide();
                        $('#kdcode_title').hide();
                    }else{
                        $('#seckdcode').hide();
                        $('#kdcode').html(s).show();
                        $('#kdcode_title').show();
                        localStorage.setItem('kd{$v[yundan]}', s);
                        localStorage.setItem('kd{$v[yundan]}_expire', '{echo time()+$sp_config[kdcache];}');
                    }
                }
            });
        }
    </script>
    <!--{/if}-->
    <div class="weui-cells before_none after_none">
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_sp:gmyh} :
            </div>
            <div class="weui-cell__bd f14">
                <img src="{avatar($v[uid], middle, true)}" class="pt_usr" style="width:24px;height:24px;margin-left:10px" > $v['username']
                <!--{if $_GET['manage']}-->
                <a href="$kflnk" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default sp_good_od mt0">{lang xigua_hb:sixin}</a>
                <!--{/if}-->
            </div>
        </div>
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_hb:bind_mobile} :
            </div>
            <!--{eval
            $mobile = $v['mobile'];
            if(!$mobile):
                $__profile = C::t('common_member_profile')->fetch($v['uid']);
                $mobile = $__profile['mobile'];
            endif;
            }-->
            <div class="weui-cell__bd f14"> {$mobile}
            </div>
        </div>
        <!--{if $v['note']}-->
        <div class="weui-cell before_none after_none">

            <div class="weui-cell__hd f14">
                {lang xigua_sp:bz} :
            </div>
            <div class="weui-cell__bd f14">
                $v['note']
            </div>
        </div>
        <!--{/if}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_sp:ddbh} :
            </div>
            <div class="weui-cell__bd f14">
                $v['order_id']
            </div>
        </div>
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_sp:xdsj} :
            </div>
            <div class="weui-cell__bd f14">
                $v['crts_u']
            </div>
        </div>
        <!--{if $v['pay_ts_u'] && $v[exp_method]!='hdfk'}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_sp:zfsj_} :
            </div>
            <div class="weui-cell__bd f14">
                $v['pay_ts_u']
            </div>
        </div>
        <!--{/if}-->
        <!--{if $v['tuicfm_ts_u']}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                <!--{if $v[pay_ts]>0}-->{lang xigua_sp:tksj} :
                <!--{else}-->{lang xigua_sp:qxdd} :
                <!--{/if}-->
            </div>
            <div class="weui-cell__bd f14">
                $v['tuicfm_ts_u']
            </div>
        </div>
        <!--{/if}-->
    </div>
<!--{if $v[cmtid]>0}-->
    <div class="view_content x-postlist p0 comment_ul mt10" id="list"></div>
    <!--{template xigua_hb:loading}-->
<!--{/if}-->
</div>
<!--{eval $sp_tabbar=1;$tabbar=0;}-->
<!--{if $v[cmtid]>0}-->
<script>loadingurl = _APPNAME+'?id=xigua_sp&ac=comment&gid={$gid}&cid={$v[cmtid]}&inajax=1&pagesize=1&page=';</script>
<!--{/if}-->
<!--{template xigua_sp:footer}-->
<script>
setTimeout(function(){
    page = -1;
}, 100);
<!--{if $_GET['code'] && $v[hxcrts]>0}-->
$.alert('{lang xigua_sp:hxerror}');
<!--{/if}-->
$(document).on('click','.upscan', function () {
    $.showLoading();
    $.ajax({
        type: "POST",
        url: _APPNAME+"?id=xigua_sp&ac=com&do=upscan&inajax=1&code={$_GET['code']}&ptlog_id={$v[id]}",
        data:{formhash:FORMHASH},
        dataType: "xml",
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () {
            $.hideLoading();
        }
    });
});
</script>