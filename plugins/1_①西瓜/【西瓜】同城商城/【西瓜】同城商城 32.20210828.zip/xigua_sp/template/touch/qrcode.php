<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<script src="source/plugin/xigua_sp/static/html2canvas.min.js"></script>
<!--{template xigua_sp:hbbutton}-->
<!--{eval $shot_img = $shot_img2 = $v[album][0]?$v[album][0]:$v[append_img_ary][0];}-->
<!--{eval
$shot_file = 'source/plugin/xigua_sp/cache/'.md5($shot_img).'.png';
if(strpos($shot_img, $_G[siteurl])===false):
    if(!is_file(DISCUZ_ROOT.$shot_file)):
        file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($shot_img));
    endif;
    $shot_img = $shot_file;
endif;
}-->
<div id="shot" style="position:absolute;top:-100000px">
    <div class="shot_in" style="width:100vw;">
        <div class="qr_pr">
            <img src="{$shot_img}" crossOrigin="anonymous" class="qr_img_src" style="width:100%;max-width:100vw" onerror="this.error=null;this.src='$shot_img2'"/>
        </div>
        <div class="cl bgf">
        <!--{if $_G['cache']['plugin']['xigua_hx'] && ((IN_PROG && $sp_config[qrmode]==1) || $sp_config[qrmode]==3)}-->
        <!--{eval include_once 'source/plugin/xigua_sp/include/c_haibao.php';}-->
            <img src="$shqr" class="z" style="width:100px;height:100px;margin-right: 10px;">
        <!--{else}-->
            <!--{if $config[qraut]}-->
            <img src="$SCRITPTNAME?id=xigua_hb:qrauto&ode=sp_{$gid}{$urlext}" class="z" style="width:100px;height:100px;">
            <!--{else}-->
            <img src="$SCRITPTNAME?id=xigua_sp:qrcode&gid=$gid&st=$_GET[st]{$urlext}" class="z" style="width:100px;height:100px;">
            <!--{/if}-->
        <!--{/if}-->
            <div class="cl " style="padding:10px 10px 0 10px;">
                <p class="f14">
                    <!--{if $v[srange2_ary]}-->
                    <!--{loop $v[srange2_ary] $s2}-->
                    <span class="stamp_thin" style="border-radius:3px">$s2</span>
                    <!--{/loop}-->
                    <!--{/if}-->
                    {$v[title]}{lang xigua_sp:zhixu}{$v[price_pt_min]}{lang xigua_sp:yuan}</p>
                <p class="c9 f13">{$_G[username]}{lang xigua_sp:xntbtj}</p>
            </div>
        </div>
    </div>
</div>
<!--{if $pt_config[qzgz] && !getcookie('miniprogram') && ($config['secert']||$config['magapp_secret'])&& HB_INWECHAT}-->
<!--{eval
$wxpay = $config['appid'] && $config['appsecert'] && $config['key'];
if(HB_INWECHAT && $wxpay):
$openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
    if(!$openid):
      $tools = new JsApiPaySF();
      $opendata = $tools->GetFollowOpenid(hb_currenturl().'&oauth=yes');
      if($openid = $opendata['openid']):
        dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 86400);
      endif;
    endif;
endif;
}-->
<!--{if $openid}-->
<script>var OPENID='$openid';</script>
<!--{/if}-->
<!--{/if}-->