<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:header}-->
<div class="page__bd ">
    <div class="site_header" id="js_site_header">

        <div class="site_header_inner">
            <div class="site_header_background_image_inside">
                <div class="shop_brand_image">
                    <img src="source/plugin/xigua_sp/static/shoplogo.png" >
                </div>
            </div>


            <header class="x_header  cl f15">
<!--{if !IN_PROG}-->
<a class="z f14" href="javascript:window.history.go(-1);"><i class="iconfont icon-fanhuijiantou w15"></i></a>
<!--{/if}-->
                <a class="y sidectrl view_ctrl"><i class="iconfont icon-gengduo1 f22"></i></a>
                <div class="navtitle">
                    <a  class="new_search" href="$SCRITPTNAME?id=xigua_sp&ac=search&shid={$sh['shid']}">{lang xigua_sp:ssbd}</a>
                </div>
            </header>


            <div class="shop_profile">
                <a class="shop_profile_link sh_jump" href="javascript:;" data-id="{$sh['shid']}">
                    <div class="shop_profile_logo">
                        <img src="{$sh[logo]}">
                    </div>
                    <div class="shop_profile_name">{$sh[name]} <i class="f13 iconfont icon-jinrujiantou vm"></i>
                    </div>
                    <div class="shop_profile_extra">
                        <span>{$sh['follow']}{lang xigua_sp:rgz}</span>
                        <span class="color-red ml8">{lang xigua_sp:hp}{$avgstar}%</span>
                    </div>
                </a>
                <!--{if $followed}-->
                <a href="javascript:;" class="follow_button js_follow_button do_follow shbtn" data-id="$sh[shid]" data-qr="$sh[qr]"><i class="iconfont icon-collection_fill vm f12"></i>{lang xigua_hs:yiguanzhu}</a>
                <!--{else}-->
                <a href="javascript:;" class="follow_button js_follow_button do_follow shbtn" data-wei="1" data-id="$sh[shid]" data-qr="$sh[qr]">{lang xigua_hs:jiaguanzhu}</a>
                <!--{/if}-->
            </div>


            <div class="weui-navbar none" style="background-color: rgba(0,0,0,0);">
                <a href="" class="weui-navbar__item weui_bar__item_on">
                    <span>{lang xigua_sp:qbsp}</span>
                </a>
                <a href="" class="weui-navbar__item ">
                    <span>{lang xigua_sp:hd_}</span>
                </a>
                <a href="" class="weui-navbar__item ">
                    <span>{lang xigua_sp:sx}</span>
                </a>
                <a href="" class="weui-navbar__item ">
                    <span>{lang xigua_sp:dt}</span>
                </a>
            </div>

        </div>
    </div>

    <!--{template xigua_sp:viewtools}-->


    <!--{template xigua_sp:tools_nav}-->

    <ul class="goodlist" id="list"> </ul>



    <!--{template xigua_hb:loading}-->

</div>

<!--{template xigua_sp:shopbtm}-->

<!--{eval $sp_tabbar = 0;$tabbar=0;}-->
<!--{template xigua_sp:footer}-->
<script>
loadingurl = _APPNAME+'?id=xigua_sp&ac=cat_li&shid={$sh[shid]}&inajax=1&sort=zonghe&page=';
</script>