<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_sp:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script src="source/plugin/xigua_sp/static/sp.js?{VERHASH}"></script>
<!--{if $sp_config['autoconfirm'] && $_G['uid']}--><script>$.ajax({type: 'get',url: _APPNAME + '?id=xigua_sp&ac=com&do=shouhuo&autoconfirm=1',dataType: 'xml',success: function (data) {},});</script><!--{/if}-->