<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function print_sp_piao($order_id, $isadmin = 0){
    global $jpurl;
    include_once DISCUZ_ROOT.'source/plugin/xigua_sp/SDK/web/print.php';
    $restatus  = array(
        '0' => lang_sp('d0', 0),
        '1' => lang_sp('d1', 0),
        '2' => lang_sp('d2', 0),
    );
    $order = DB::fetch_first('select * from %t where order_id=%s', array('xigua_hb_order', $order_id));
    $reinfo = unserialize($order['info']);

    $sporder_info = DB::fetch_first('SELECT * FROM %t where order_id=%s', array('xigua_sp_order', $order_id));
    $sporder_info['goodinfo'] = unserialize($sporder_info['goodinfo']);
    $sporder_info['priceinfo'] = unserialize($sporder_info['priceinfo']);

    $hs_info = DB::fetch_first('select * from %t where shid=%d', array('xigua_hs_shanghu', $sporder_info['shid']));
    /*    $hs_info['appid'] = '8000418';
        $hs_info['appkey'] = 'd8dab4b725e414109f02df134908814b';
        $hs_info['device_id'] = '12383586';
        $hs_info['device_secret'] = '26wcp6pj';*/
    if(!$hs_info['appid']){
        if($isadmin){
            cpmsg(lang_sp('errr', 0), $jpurl, 'error');
        }else{
            return false;
        }
    }
    $otime = date(lang_sp('time_ts', 0), $order['crts']);
    if(!$sporder_info['note']){
        $sporder_info['note'] = lang_sp('wu', 0);
    }
    $l_zxsc = lang_sp('zxsc', 0);
    $l_zxzf = lang_sp('zxzf', 0);
    $l_bz = lang_sp('bz', 0);
    $l_xdsj = lang_sp('xdsj', 0);
    $l_ddbh = lang_sp('ddbh', 0);
    $l_jj = lang_sp('jj', 0);
    $l_psf = lang_sp('psf', 0);
    $l_ddzj = lang_sp('ddzj', 0);
    $l_zfje = lang_sp('zfje', 0);

    if($reinfo['data']['goodinfo']){
        $sporder_info['title'] = str_replace($sporder_info['gnum'].' '.lang_sp('jian', 0), '',$sporder_info['title'] );
        $print_data = "<S2><C> $l_zxsc </C></S2>................................<S2><C>----$l_zxzf----</C></S2><S1><C>{$hs_info['name']}</C></S1>$l_xdsj:$otime<RN>$l_ddbh:$order_id<RN>**************$l_jj**************<TR><TD>{$sporder_info['title']}</TD><TD>x{$sporder_info['gnum']}</TD><TD>{$sporder_info['unit_price']}</TD></TR>********************************<H2>$l_psf:{$sporder_info['yunfee']}<RN></H2><RN>********************************<H2>$l_ddzj:{$sporder_info['pay_money']}<RN></H2><S1>{$sporder_info['addr']}</S1><RN><S1>{$sporder_info['realname']}<RN>{$sporder_info['mobile']}</S1><RN><S1>$l_bz:{$sporder_info['note']}</S1>";
    }else{
        $goodlist = '';
        $total = 0;
        foreach ($reinfo['data'] as $index => $item) {
            $item['title'] = str_replace($item['gnum'].' '.lang_sp('jian', 0), '',$item['title'] );
            $goodlist .= "<TR><TD>{$item['title']}</TD><TD>x{$item['gnum']}</TD><TD>{$item['unit_price']}</TD></TR>";
            $total += ($item['gnum']*$item['unit_price']);
        }
        $sporder_info['yunfee'] = max($order['baseprice']-$total, 0);
        $total += $sporder_info['yunfee'];

        $print_data = "<S2><C> $l_zxsc </C></S2>................................<S2><C>----$l_zxzf----</C></S2><S1><C>{$hs_info['name']}</C></S1>$l_xdsj:$otime<RN>$l_ddbh:$order_id<RN>**************$l_jj**************$goodlist<RN>********************************<H2>$l_psf:{$sporder_info['yunfee']}<RN></H2><RN>********************************<H2>$l_ddzj:{$total}<RN>$l_zfje{$order['baseprice']}<RN></H2><S1>{$sporder_info['addr']}</S1><RN><S1>{$sporder_info['realname']}<RN>{$sporder_info['mobile']}</S1><RN><S1>$l_bz:{$sporder_info['note']}</S1>";
    }
//    dmp($reinfo);
//    print_r(dhtmlspecialchars($print_data));
//    exit;
    $print_data = diconv($print_data, CHARSET, 'UTF-8');

	global $_G;
    $sp_config = $_G['cache']['plugin']['xigua_sp'];
	if(!$sp_config['zhangshu']){
		$sp_config['zhangshu'] = 2;
	}
	for($i=0;$i<$sp_config['zhangshu'];$i++){
    	$ret_data = print_piao($hs_info['appid'],$hs_info['appkey'],$hs_info['device_id'],$hs_info['device_secret'], $print_data);
	}
    if(is_array($ret_data) && $ret_data['id']){
        DB::query('update %t set piao=%d ,piao_ts=%d where order_id=%s', array('xigua_hb_order', $ret_data['id'], TIMESTAMP, $order_id));
        if($isadmin){
            cpmsg($restatus[$ret_data['status']] ? $restatus[$ret_data['status']] : var_export($ret_data,1), $jpurl, 'succeed');
        }else{
            return true;
        }
    }else{
        if($isadmin) {
            $ret_data = diconv($ret_data, 'utf-8', CHARSET);
            cpmsg($ret_data, $jpurl, 'error');
        }else{
            return false;
        }
    }
}