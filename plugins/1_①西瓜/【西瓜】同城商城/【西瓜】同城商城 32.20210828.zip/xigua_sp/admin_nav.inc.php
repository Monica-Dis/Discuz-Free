<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_sp/function.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$pt_index_class = C::t('#xigua_sp#xigua_sp_nav');
$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;

$GLOBALS['needchild'] = 1;
$iconlist = array(
);
if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
    $ret = $pt_index_class->do_delete(intval($_GET['catid']));
    if($ret){
        cpmsg(
            lang_hb('delcat_succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_nav&page=$page",
            'succeed'
        );
    }else{
        cpmsg(
            lang_hb('delcat_error', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_nav&page=$page",
            'error'
        );
    }
}
if(submitcheck('dosubmit')){
    if($new = $_GET['n']){
        $newrow = array();
        foreach ($new['name'] as $k => $v) {
            if(is_array($v)){
                foreach ($v as $kk => $string) {
                    $newrow[] = array(
                        'pid'  => $k,
                        'name' => $string,
                        'o'    => $new['o'][$k][$kk],
                        'ts'   => TIMESTAMP,
                        'cat_ids'   => trim($new['cat_ids'][$k][$kk]),
                        'price'  => $new['price'][$k][$kk],
                        'telprice'  => $new['telprice'][$k][$kk],
                        'stids'  => $new['stids'][$k][$kk],
                        'iconname'  => $new['iconname'][$k][$kk],
                    );
                }
            } else {
                $newrow[] = array(
                    'pid' => 0,
                    'name' => $v,
                    'o'  => $new['o'][$k],
                    'ts'   => TIMESTAMP,
                    'cat_ids'   => trim($new['cat_ids'][$k]),
                    'price'  => $new['price'][$k],
                    'telprice'  => $new['telprice'][$k],
                    'stids'  => $new['stids'][$k],
                    'iconname'  => $new['iconname'][$k],
                );
            }
        }
        foreach ($newrow as $value) {
            $pt_index_class->insert($value);
        }
    }

    if($_FILES['icon'] || $_FILES['icon2']){
        $icons = hb_uploads($_FILES['icon']);
        $icon2 = hb_uploads($_FILES['icon2']);
    }
    if($r = $_GET['r']){
        foreach ($r['name'] as $cid => $name) {
            $data = array();

            $data['name']   = $name;
            $data['o']      = $r['o'][$cid];
            $data['cat_ids']= $r['cat_ids'][$cid];
            $data['adlink'] = $r['adlink'][$cid];
            $data['price']  = $r['price'][$cid];
            $data['telprice']  = $r['telprice'][$cid];
            $data['stids']  = $r['stids'][$cid];
            $data['iconname']  = $r['iconname'][$cid];
            $data['type']  = $r['type'][$cid];
            $data['tag']    = trim($r['tag'][$cid]);
            $data['placehoder']    = trim($r['placehoder'][$cid]);
            $data['up']    = trim($r['up'][$cid]);
            $data['highlight']    = trim($r['highlight'][$cid]);
            if($_FILES['icon2']['error'][$cid] === UPLOAD_ERR_OK){
                $data['icon2']= ($icon2[$cid]['errno'] == 0 ? $icon2[$cid]['error'] : '');
            }
            if($_FILES['icon']['error'][$cid] === UPLOAD_ERR_OK) {
                $data['icon'] = ($icons[$cid]['errno'] == 0 ? $icons[$cid]['error'] : '');
            }

            $pt_index_class->update($cid, $data);
        }
    }
    if($delimg = $_GET['delimg']){
        foreach ($delimg as $catid_ => $fields_) {
            $data_ = array();
            if($fields_['icon'] == 1){
                $data_['icon'] = '';
            }
            if($fields_['icon2'] == 1){
                $data_['icon2'] = '';
            }
            if($data_){
                $pt_index_class->update(intval($catid_), $data_);
            }
        }
    }
    cpmsg(
        lang_hb('succeed', 0),
        "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_nav&page=$page",
        'succeed'
    );
}

$listinfo = $pt_index_class->fetch_all_by_page($start_limit, $lpp);
$pt_index_class->init($listinfo);
$list = $pt_index_class->get_tree_array(0);

$totalcount = $pt_index_class->count_by_page();
$multipage = multi(
    $totalcount, $lpp, $page,
    ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_nav&page=$page"
);

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_nav&page=$page", 'enctype');
$alink = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_pub&catadd";

$hb_cats = C::t('#xigua_hb#xigua_hb_cat')->list_all(1);

$hb_catsting = '';



foreach ($hb_cats as $index => $hb_cat) {
    $hb_catsting.= "[{$hb_cat['name']}: <b>{$hb_cat['id']}</b>] ";
}
?>
<link rel="stylesheet" href="source/plugin/xigua_hb/static/iconfont.css">
<style>
    .imgi{height:20px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
    .short{width:150px}
    .td23 input{width:120px!important;}
</style>
<table class="tb tb2 ">
    <tbody>
    <tr class="header">
        <th><?php lang_hb('index_id')?></th>
        <th><?php lang_hb('order')?></th>
        <th><?php lang_hb('index_name')?></th>
        <th><?php lang_sp('icon')?></th>
        <th><?php lang_sp('icon2')?></th>
        <th><?php lang_hb('index_link')?></th>
        <th><?php lang_hb('up')?></th>
        <th><?php lang_hb('caozuo')?></th>
    </tr>
    </tbody>
    <?php foreach ($list as $v) {

        $cs = '<select onchange="dochangre(this, '.$v['id'].')" name="r[iconname]['.$v['id'].']">';
        foreach ($iconlist as $index => $item) {
            $s = '';
            if($item== $v['iconname']){
                $s = 'selected';
            }
            $cs .= "<option $s value='$item'>$item</option>";
        }
        $cs .= '</select> <i style="font-size:24px" id="iconfont'.$v['id'].'" class="iconfont icon-'.$v['iconname'].'"></i>';
        ?>
        <tbody>
        <tr class="hover">
            <td class="td25">&nbsp;&nbsp;<?php echo $v['id']?></td>
            <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $v['id']?>]" value="<?php echo $v['o']?>" /></td>
            <td class="td23">
                <div class="parentboard"><input type="text" name="r[name][<?php echo $v['id']?>]" value="<?php echo $v['name']?>" class="txt" /></div>
            </td>
            <td>
                <input class="short" name="icon[<?php echo $v['id']?>]" type="file" />
                <?php if($v['icon']){?>
                    <span class="sp">
 <img class="imgi" src="<?php echo $v['icon']?>" onmouseover="$('icon<?php echo $v['id']?>').style.display='block'" onmouseout="$('icon<?php echo $v['id']?>').style.display='none'" />
 <img id="icon<?php echo $v['id']?>" src="<?php echo $v['icon']?>"  class="imgprevew" />
 <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][icon]" value="1" /><?php lang_hb('delshort')?></label>
</span>
                <?php }?>
            </td>
            <td>
                <input class="short" name="icon2[<?php echo $v['id']?>]" type="file" />
                <?php if($v['icon2']){?>
                    <span class="sp">
 <img class="imgi" src="<?php echo $v['icon2']?>" onmouseover="$('icon2<?php echo $v['id']?>').style.display='block'" onmouseout="$('icon2<?php echo $v['id']?>').style.display='none'" />
 <img id="icon2<?php echo $v['id']?>" src="<?php echo $v['icon2']?>"  class="imgprevew" />
 <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][icon2]" value="1" /><?php lang_hb('delshort')?></label>
</span>
                <?php }?>
            </td>
            <td>
                <p>
                    <input type="text" name="r[adlink][<?php echo $v['id']?>]" value="<?php echo $v['adlink'] ? $v['adlink'] : ''; ?>" />
                </p>
            </td>
            <!--<td>
                <input type="text" class="txt" name="r[highlight][<?php /*echo $v['id']*/?>]"  value="<?php /*echo $v['highlight']*/?>" />
            </td>-->
            <td>
                <input name='r[up][<?php echo $v['id']?>]' type='radio' value='1' <?php echo $v['up']?'checked':''; ?> /> <?php echo cplang('yes')?>
                <input name='r[up][<?php echo $v['id']?>]' type='radio' value='0' <?php echo $v['up']?'':'checked'; ?>/><?php echo cplang('no')?>
            </td>
            <td>
                <a href="javascript:;" onclick="return _delid(<?php echo $v['id']?>,'<?php echo str_replace('&#039;', '', $v['name'])?>') "><?php lang_hb('del')?></a>
            </td>
        </tr>
        </tbody>

    <?php }?>

    <tbody>
    <tr>
        <td>&nbsp;</td>
        <td colspan="99"><div>
                <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hb('ad_new')?></a>
            </div></td>
    </tr>
    <?php
    if($multipage){
        showtablerow('', 'colspan="99"', $multipage);
    }
    showsubmit('dosubmit', 'submit', 'td');
    ?>
    </tbody>
</table>
</form>

<script>
    var rowtypedata = [
        [
            [1, ''],
            [1,'<input type="text" class="txt" name="n[o][]" value="0" />', 'td25'],
            [5,'<div><input name="n[name][]" value="<?php lang_hb('new__name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
        ],
        [
            [1, ''],
            [1,'<input type="text" class="txt" name="n[o][{1}][]" value="0" />', 'td25'],
            [5,'<div class="board"><input name="n[name][{1}][]" value="<?php lang_hb('child_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
        ]
    ];
    function _delid(id, name){
        if(confirm('<?php lang_hb('del_confirm')?>' + name + '?')){
            window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_nav&page=$page&del=1&formhash=".FORMHASH.'&catid='?>"+id;
        }
    }
    function dochangre(obj, id){
        console.log(obj.options[obj.options.selectedIndex].value);
        document.getElementById('iconfont'+id).className = 'iconfont icon-'+obj.options[obj.options.selectedIndex].value;
    }
</script>