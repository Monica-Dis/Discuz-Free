<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_sp/function.php';
global $status_font;
global $_G;
global $sp_config;
global $svicerange;
global $aclist;
global $aclist_login;
global $ac;
global $do;
global $isself;
global $page;
global $lpp;
global $start_limit;
global $gid;
global $config;
$status_font = array(1 => lang_sp('status_1', 0), 2 => lang_sp('status_2', 0), 3 => lang_sp('status_3', 0), 4 => lang_sp('status_4', 0));
$sp_config = $_G['cache']['plugin']['xigua_sp'];
$svicerange = array();
foreach (explode("\n", trim($sp_config['svicerange'])) as $index => $item) {
	$svicerange[] = trim($item);
}
$aclist = array('index', 'cate', 'shop', 'wode', 'manage', 'add', 'spgg', 'good_li', 'none', 'search', 'comments', 'cat_li', 'tuihuo', 'cat', 'view', 'order_profile', 'confirm', 'buy', 'shisuan', 'order', 'order_li', 'cat_li', 'cat', 'com', 'invite', 'cate', 'cancel_order', 'order_manage', 'help', 'comment', 'gwc');
$aclist_login = array('manage', 'add', 'spgg', 'confirm', 'tuihuo', 'order_li', 'buy', 'order_manage', 'gwc', 'wode', 'order');
$ac = $_GET['ac'];
$do = $_GET['do'];
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
$isself = in_array($ac, $aclist_login) || !(strpos($ac, 'my') === false) && !$_G['uid'];
if ($isself && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$gid = intval($_GET['gid']);
$config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $sp_config['maincolor'];
switch ($ac) {
	case 'shisuan':
		$price = floatval($_GET['price']);
		$num = intval($_GET['num']);
		$good_pr = $price * $num;
		if (is_numeric($_GET['gid'])) {
			$ginfo = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid);
			if ($ginfo['baoyou_num'] > 0 && $ginfo['baoyou_type'] == 1 && $good_pr >= $ginfo['baoyou_num']) {
				$_GET['yf'] = 0;
			}
		}
		$ret = floatval($good_pr + $_GET['yf'] - $_GET['youhui']);
		include template('xigua_hb:header_ajax');
		echo $ret . '_' . ($_GET['yf'] ? floatval($_GET['yf']) : '');
		include template('xigua_hb:footer_ajax');
		break;
	case 'index':
		$navtitle = $sp_config['indextitle'];
		$desc = $sp_config['indexdesc'];
		$midnavslider = $topnavslider = array();
		$topnavslider = hb_parse_set($sp_config['loopbanner']);
		$cat_list = C::t('#xigua_sp#xigua_sp_hangye')->list_by_pid(0, true);
		$indexlist = C::t('#xigua_sp#xigua_sp_index')->list_by_pid(0, true);
		$jing_list = array_values($indexlist);
		if ($jing_list) {
			$jing_count = range(0, ceil(count($jing_list) / 10) - 1);
		}
		$tmp = C::t('#xigua_sp#xigua_sp_card')->fetch_all_by_page(0, 99);
		$index_cards = array();
		foreach ($tmp as $index => $index_card) {
			$index_cards[$index_card['group1']][] = $index_card;
		}
		break;
	case 'cate':
		$navtitle = lang_sp('spfl', 0);
		$cat_list = C::t('#xigua_sp#xigua_sp_hangye')->list_by_pid(0, true);
		foreach ($cat_list as $index => $item) {
			$cat_list[$index]['child'] = C::t('#xigua_sp#xigua_sp_hangye')->get_childs_by_pids($item['id']);
		}
		$catlist = array_values($cat_list);
		$nowcat = $cat_list[$_GET['catid']] ? $cat_list[$_GET['catid']] : $catlist[0];
		break;
	case 'shop':
		$shid = intval($_GET['shid']);
		$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 1);
		if (!$sh) {
			dheader('Location:' . $SCRITPTNAME . '?id=xigua_sp&ac=none' . $urlext);
		}
		$navtitle = $sh['name'];
		$desc = cutstr(strip_tags($sh['jieshao']), 80);
		if ($_G['uid']) {
			$followed = C::t('#xigua_hs#xigua_hs_follow')->fetch_follow_by_shid_uid($shid, $_G['uid']);
		}
		$avgstar = C::t('#xigua_sp#xigua_sp_good')->fetch_commnt_avg_shid($shid);
		$hyids = DB::fetch_all('select hangye_id2 from %t where shid=%d', array('xigua_sp_good', $shid), 'hangye_id2');
		if ($hyids && $sp_config['tpl']) {
			$hyids = array_keys($hyids);
			$cat_list = C::t('#xigua_sp#xigua_sp_hangye')->list_all(1);
			$newcat = array();
			foreach ($cat_list as $index => $item) {
				if (in_array($item['id'], $hyids)) {
					$newcat[$index] = $item;
				}
			}
			include template('xigua_sp:shopnew');
			dexit();
		}
		break;
	case 'manage':
		$navtitle = lang_sp('qggl', 0);
		if ($_G['cache']['plugin']['xigua_hs']) {
			$where = array();
			$where[] = 'uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP;
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
		}
		$need_side = 1;
		break;
	case 'add':
		$navtitle = lang_sp('fbsp', 0);
		if ($_G['cache']['plugin']['xigua_hs']) {
			$where = array();
			$where[] = 'uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP;
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
		}
		if ($gid = $_GET['gid']) {
			$old_data = C::t('#xigua_sp#xigua_sp_good')->fetch_G($gid);
			if (!$old_data) {
				dheader('Location: ' . $SCRITPTNAME . '?id=xigua_sp&ac=manage');
			}
		}
		if ($sp_config['maxhy'] > 1) {
			$hyids = array_filter(explode(',', $old_data['hangye_ids']));
			if (!$hyids && $old_data['hangye_id2']) {
				$hyids = array($old_data['hangye_id2']);
			}
			$h_names = array();
			$hangye_ary = C::t('#xigua_sp#xigua_sp_hangye')->list_json();
			$new_ary = array();
			foreach ($hangye_ary as $index => $item) {
				$new_ary[$item['id']] = $item;
			}
			foreach ($hyids as $index => $item) {
				$h_names[] = diconv($new_ary[$item]['name'], 'UTF-8', CHARSET);
			}
			$h_names = implode(',', $h_names);
		}
		if (submitcheck('formhash')) {
			$data = $srg = $append_img = $append_text = array();
			$form = $_GET['form'];
			if (!($sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']))) {
				hb_message(lang_sp('shname_tip', 0), 'error');
			}
			if ($sp_config['fbqx']) {
				$vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0, 99, 'id');
				if (!in_array('tcsp', $vips[$sh['viptype']]['access'])) {
					hb_message(lang_sp('myqx', 0), 'error');
				}
			}
			$required = array('title', 'shname', 'dprice', 'disprice');
			foreach ($required as $index => $item) {
				$form[$item] = trim($form[$item]);
				if (!$form[$item]) {
					hb_message(lang_sp($item . '_tip', 0), 'error');
				}
			}
			foreach ($svicerange as $index => $item) {
				if ($form['tagid'][$index]) {
					list($_rangt, $_rangd) = explode('#', $item);
					$srg[] = $_rangt;
				}
			}
			foreach ($form['append_img'] as $index => $item) {
				$append_img[] = $item;
				$append_text[] = $form['append_text'][$index];
			}
			$up = $form['id'] > 0;
			if ($up) {
				$data['upts'] = TIMESTAMP;
			} else {
				$data['uid'] = $_G['uid'];
				$data['crts'] = TIMESTAMP;
			}
			if (!is_array($form['hangye'])) {
				$hy_ret = C::t('#xigua_sp#xigua_sp_hangye')->fetch_by_name(array_filter(explode(' ', trim($form['hy']))));
				$hangye_ids = array_keys($hy_ret);
				$data['hy'] = $form['hy'];
				$data['hangye_id1'] = $hangye_ids[0];
				$data['hangye_id2'] = $hangye_ids[1];
				$data['hangye_ids'] = implode(',', $hangye_ids);
			} else {
				$_pids = C::t('#xigua_sp#xigua_sp_hangye')->get_pid_by_childs(array($form['hangye'][0]));
				$newhangye_ids = implode(',', $form['hangye']);
				$hynames = C::t('#xigua_sp#xigua_sp_hangye')->fetch_light(array($_pids['pid'], $_pids['id']), 'id,name');
				$data['hangye_id1'] = $_pids['pid'];
				$data['hangye_id2'] = $_pids['id'];
				$data['hy'] = $hynames[$_pids['pid']]['name'] . ' ' . $hynames[$_pids['id']]['name'];
				$data['hangye_ids'] = $newhangye_ids;
			}
			$data['title'] = $form['title'];
			$data['subtitle'] = $form['subtitle'];
			$data['usetime'] = intval(strtotime($form['usetime']));
			$data['shname'] = $sh['name'];
			$data['shid'] = $sh['shid'];
			$data['stock'] = $form['stock'];
			$data['sellnum'] = $form['sellnum'];
			$data['tprice'] = $form['tprice'];
			$data['dprice'] = $form['dprice'];
			$data['hkprice'] = $form['hkprice'];
			$data['disprice'] = $form['disprice'];
			$data['danci'] = $form['danci'];
			$data['zong'] = $form['zong'];
			$data['youhui'] = $form['youhui'];
			$data['ptmin'] = $form['ptmin'];
			$data['ptshixian'] = $form['ptshixian'];
			$data['srange'] = implode('	', $srg);
			$data['jieshao'] = $form['jieshao'];
			$data['append_img'] = serialize($append_img);
			$data['append_text'] = serialize($append_text);
			$data['album'] = serialize($form['album']);
			$data['fengmian'] = is_array($form['fengmian']) ? $form['fengmian'][0] : $form['fengmian'];
			$data['crts'] = TIMESTAMP;
			$data['stat'] = 1;
			$data['stid'] = intval($_GET['st']);
			$data['psfs_val'] = intval($form['psfs_val']);
			$data['allow_tk'] = intval($form['allow_tk']);
			$data['baoyou_type'] = $form['baoyou_type'];
			$data['baoyou_num'] = floatval($form['baoyou_num']);
			$data['jifenrate'] = $form['jifenrate'];
			$jp = $SCRITPTNAME . '?id=xigua_sp&ac=manage';
			if ($sp_config['needshen']) {
				$data['stat'] = 2;
				$jp .= '&stat=2';
			}
			if ($up) {
				$gid = $form['id'];
				$rs = C::t('#xigua_sp#xigua_sp_good')->update_G($form['id'], $data);
			} else {
				$data['upts'] = $data['crts'];
				$gid = $rs = C::t('#xigua_sp#xigua_sp_good')->insert($data, 1);
				$dftspgg = lang_sp('ggdft', 0);
				$spgg = array();
				$spggtmp = array();
				foreach (explode("\n", $dftspgg) as $index => $item) {
					list($name, $value) = explode('=', trim($item));
					$value = explode(',', trim($value));
					if ($name && $value) {
						$spgg[] = array('id' => $index, 'name' => $name, 'ggtext' => $value);
					}
				}
				C::t('#xigua_sp#xigua_sp_good')->update($gid, array('spgg' => serialize($spgg)));
				$price_list = $pow = array();
				$ggtest = $n = array();
				foreach ($spgg as $str => $item) {
					$ggtest[] = $item['ggtext'];
				}
				$ggtest = combina($ggtest);
				foreach ($ggtest as $index => $item) {
					$updata = array('crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'uid' => $_G['uid'], 'gid' => $gid);
					$updata['price_pt'] = $data['tprice'];
					$updata['price_dm'] = $data['dprice'];
					$updata['price_hk'] = $data['hkprice'];
					$updata['price_sc'] = $data['disprice'];
					$updata['stock'] = $data['stock'];
					$updata['name'] = is_array($item) ? implode('###', $item) : $item;
					C::t('#xigua_sp#xigua_sp_good_price')->update_price($updata);
				}
			}
			if ($rs) {
				hb_message(lang_sp('ptfbcg', 0), 'success', $SCRITPTNAME . '?id=xigua_sp&ac=spgg&gid=' . $gid . $urlext);
			}
		} else {
			$hyobj = C::t('#xigua_sp#xigua_sp_hangye');
			$hyobj->init($hyobj->list_json());
			$jsary = $hyobj->get_tree_array(0);
			$jsary = array_values($jsary);
			$default_hy = diconv($jsary[0]['name'] . ' ' . $jsary[0]['sub'][0]['name'], 'utf-8', CHARSET);
			$cityjson = json_encode($jsary);
			if ($old_data['hy']) {
				$default_hy = $old_data['hy'];
			}
		}
		break;
	case 'good_li':
		$viewtype = $_GET['viewtype'];
		if (!$viewtype) {
			$viewtype = $orderby = $_GET['orderby'];
		}
		$manage = IS_ADMINID && $ac == 'manage';
		$field = '*';
		$where = array();
		$where[] = 'uid=' . intval($_G['uid']);
		$stat = intval($_GET['stat']);
		if (!$stat) {
			$stat = 1;
		}
		$where[] = 'stat=' . intval($stat);
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$where[] = ' (title LIKE \'%' . $keyword . '%\') ';
		}
		$order_by = 'id desc';
		$list = C::t('#xigua_sp#xigua_sp_good')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);
		include template('xigua_hb:header_ajax');
		include template('xigua_sp:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'cat':
		if ($keyword = $_GET['keyword']) {
			$reckys = getcookie('reckys');
			if ($reckys) {
				$reckys = unserialize($reckys);
			}
			$reckys[$keyword] = 1;
			dsetcookie('reckys', serialize($reckys), 8640000);
		}
		if ($keyword) {
			$navtitle = lang_sp('sssp', 0) . '-' . $keyword;
		} else {
			if ($shid = intval($_GET['shid'])) {
				$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
				$navtitle = $sh['name'] . lang_sp('jj', 0);
			} else {
				$cat_list = C::t('#xigua_sp#xigua_sp_hangye')->list_by_pid(0, true);
				$jing_list = C::t('#xigua_sp#xigua_sp_hangye')->get_childs_by_pids($_GET['catid']);
				if ($cat_list[$_GET['catid']]['name']) {
					$navtitle = $desc = $cat_list[$_GET['catid']]['name'];
				} else {
					$cat_list2 = C::t('#xigua_sp#xigua_sp_hangye')->list_by_pid($_GET['catid'], true);
					$mypid = $cat_list2[$_GET['catid']]['pid'];
					$jing_list = C::t('#xigua_sp#xigua_sp_hangye')->get_childs_by_pids($mypid);
					$navtitle = $desc = $cat_list2[$_GET['catid']]['name'];
				}
			}
		}
		break;
	case 'cat_li':
		$where = array();
		$where[] = 'stat=1';
		if ($ctid = intval($_GET['catid'])) {
			$cat_list2 = C::t('#xigua_sp#xigua_sp_hangye')->list_by_pid($_GET['catid'], true);
			$idssa = array_filter(array_keys($cat_list2));
			if ($idssa) {
				$idss = implode(',', $idssa);
			}
			if ($idss) {
				$fst = array();
				foreach ($idssa as $vv) {
					$fst[] = ' FIND_IN_SET(' . $vv . ', hangye_ids) ';
				}
				$fst1 = implode(' OR ', $fst);
				$where[] = '(hangye_id1 in (' . $idss . ') OR hangye_id2 in (' . $idss . ') OR ' . $fst1 . ') ';
			} else {
				$where[] = '(hangye_id1=' . $ctid . ' OR hangye_id2=' . $ctid . ' OR FIND_IN_SET(' . $ctid . ', hangye_ids)) ';
			}
		}
		if ($shidd = intval($_GET['shid'])) {
			$where[] = ' shid=' . $shidd . ' ';
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$where[] = ' (title LIKE \'%' . $keyword . '%\' OR shname LIKE \'%' . $keyword . '%\' OR jieshao LIKE \'%' . $keyword . '%\') ';
		}
		if ($gdd = intval($_GET['not'])) {
			$where[] = ' id!=' . $gdd . ' ';
		}
		$order_by = 'id desc';
		switch ($_GET['sort']) {
			case 'dpriceasc':
				$order_by = 'dprice asc';
				break;
			case 'dprice':
				$order_by = 'dprice desc';
				break;
			case 'crts':
				$order_by = 'id desc';
				break;
			case 'sellnum':
				$order_by = 'sellnum desc , id desc';
				break;
			case 'zonghe':
			default:
				$order_by = 'displayorder desc , id desc';
		}
		$list = C::t('#xigua_sp#xigua_sp_good')->fetch_all_by_where($where, $start_limit, $lpp, $order_by);
		if ($_GET['shid'] && count($list) % 2 != 0) {
			$_GET['from'] = 'index';
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_sp:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'view':
		$v = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid);
		if ($v['stat'] != 1) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_sp');
		}
		$navtitle = $v['title'];
		$desc = $v['subtitle'] ? $v['subtitle'] : strip_tags($v['jieshao']);
		$sh = $v['sh'] = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid']);
		$shid = $v['shid'];
		$cat_list = C::t('#xigua_sp#xigua_sp_hangye')->list_by_pid(0, true);
		$avgstar = C::t('#xigua_sp#xigua_sp_good')->fetch_commnt_avg($gid);
		if ($sp_config['showreal']) {
			$lw = array(' ( status in (2,6) AND gid=' . $gid . ' ) ');
			$v['logs'] = C::t('#xigua_sp#xigua_sp_order')->fetch_all_by_where($lw, 0, 8, 'id DESC', 'id,uid,crts', 1);
			$v['logs_count'] = C::t('#xigua_sp#xigua_sp_order')->fetch_count_by_where($lw);
		}
		$goodnum = C::t('#xigua_sp#xigua_sp_good')->count_by_shid($shid);
		$avgstarsh = C::t('#xigua_sp#xigua_sp_good')->fetch_commnt_avg_shid($shid);
		if ($_G['uid']) {
			$followed = C::t('#xigua_hs#xigua_hs_follow')->fetch_follow_by_shid_uid($sh['shid'], $_G['uid']);
		}
		$need_side = 1;
		if ($sp_config['kefulink'] && (IN_MAGAPP || IN_QIANFAN)) {
			$shmember = getuserbyuid($sh['uid']);
			$shavat = avatar($sh['uid'], 'middle', true);
			$kefulink = str_replace(array('{uid}', '{username}', '{avatar}'), array($sh['uid'], $shmember['username'], $shavat), $sp_config['kefulink']);
		} else {
			$kefulink = $SCRITPTNAME . '?id=xigua_hb&ac=chat&touid=' . $sh['uid'];
		}
		break;
	case 'order_profile':
		$navtitle = lang_sp('ddxq', 0);
		$ptlog_id = $_GET['ptlog_id'];
		$cat_list = C::t('#xigua_sp#xigua_sp_hangye')->list_by_pid(0, true);
		if ($_GET['code']) {
			$v = DB::fetch_first('select * from %t WHERE id=%d AND hxcode=%s', array('xigua_sp_order', $ptlog_id, $_GET['code']));
			$gid = $v['gid'];
			$shid = $v['shid'];
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
			$good = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid);
			$access = 0;
			if (IS_ADMINID) {
				$access = 1;
			} else {
				if ($v['uid'] == $_G['uid']) {
					$access = 0;
				} elseif ($good['uid'] == $_G['uid']) {
					$access = 1;
				}
			}
			if (!$access) {
				$yuaninfo = C::t('#xigua_hs#xigua_hs_yuan')->fetch_yuan_by_shid_uid($shid, $_G['uid']);
				if ($yuaninfo) {
					$access = 1;
				}
			}
			if (!$access) {
				if ($coki = authcode(getcookie('hstax' . $shid), 'DECODE')) {
					$shv = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
					if ($shv['hxpwd'] == $coki) {
						$access = 1;
					}
				}
			}
			if (!$access) {
				include template('xigua_sp:scan');
				exit(0);
			}
			$_GET['manage'] = 1;
			$v = C::t('#xigua_sp#xigua_sp_order')->prepare($v);
		} elseif ($_GET['manage']) {
			$shids = sp_get_shids_by_uid();
			$v = DB::fetch_first('select * from %t WHERE shid IN(%n) AND id=%d ', array('xigua_sp_order', $shids, $ptlog_id));
			$v = C::t('#xigua_sp#xigua_sp_order')->prepare($v);
		} else {
			$v = C::t('#xigua_sp#xigua_sp_order')->fetch_G($ptlog_id);
		}
		if (!$v) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_sp&mobile=2' . $urlext);
		}
		$v['sh'] = DB::fetch_first('SELECT * FROM %t WHERE shid =%d', array('xigua_hs_shanghu', $v['shid']));
		$v['username'] = DB::result_first('select username from %t where uid=%d', array('common_member', $v['uid']));
		$need_side = 1;
		$kflnk = str_replace(array('{uid}', '{username}', '{avatar}'), array($v['uid'], $v['username'], avatar($v['uid'], 'middle', 1)), $config['sxlink']);
		if (!IN_QIANFAN && !IN_MAGAPP && ($config['magapp_secret'] || $config['hostname'])) {
			$kflnk = $SCRITPTNAME . '?id=xigua_hb&ac=chat&touid=' . $v['uid'];
		}
		break;
	case 'confirm':
		if (submitcheck('confrm')) {
			$form = $_GET['form'];
			$priceid = intval($form['price_id']);
			$num = intval($form['item_num']);
			$buy_type = intval($form['buy_type']);
			if (!$priceid) {
				hb_message(lang_sp('qxzgg', 0), 'error');
			}
			$good_price = C::t('#xigua_sp#xigua_sp_good_price')->fetch($priceid);
			if ($good_price['gid'] != $gid) {
				hb_message('error~~', 'error');
			}
			if ($good_price['stock'] < $num) {
				hb_message(lang_sp('kcbz', 0), 'error');
			}
			$jumpurl = $SCRITPTNAME . '?id=xigua_sp&ac=confirm&num=' . $num . '&buy_type=' . $buy_type . '&pid=' . $priceid . '&gid=' . $gid . $t . '&note=' . $form['item_note'] . $urlext;
			if ($sp_config['musttel']) {
				$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
				if (!$user['mobile']) {
					hb_message(lang_sp('qtxsjhm', 0), 'loading', $SCRITPTNAME . '?id=xigua_hb&ac=myzl&referer=' . urlencode($jumpurl) . $GLOBALS['urlext']);
				}
			}
			hb_message(lang_sp('tzz', 0), 'loading', $jumpurl);
		} else {
			$navtitle = lang_sp('qrdd', 0);
			$_pid = trim($_GET['pid'], '_');
			$_num = trim($_GET['num'], '_');
			$_gid = trim($_GET['gid'], '_');
			$yf = 0;
			$dft = C::t('#xigua_hb#xigua_hb_user_addr')->fetch_dft($_G['uid']);
			if (is_numeric($_pid)) {
				$tye = 'single';
				$_GET['pid'] = $_pid;
				$_GET['num'] = $_num;
				$gid = $_GET['gid'] = $_gid;
				$priceid = intval($_GET['pid']);
				$num = intval($_GET['num']);
				$v = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid, 0);
				$good_price = C::t('#xigua_sp#xigua_sp_good_price')->fetch($priceid);
				if ($good_price['gid'] != $gid) {
					hb_message('error~~', 'error');
				}
				$v['price_name'] = explode('###', $good_price['name']);
				$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($v['shid']);
				if ($sh['baoyou']) {
					$sp_config['baoyou'] = $sh['baoyou'];
				}
				$dft['address'] = daddslashes($dft['address']);
				$dft['dist1'] = daddslashes($dft['dist1']);
				$dft['dist2'] = daddslashes($dft['dist2']);
				$dft['dist3'] = daddslashes($dft['dist3']);
				$addr = C::t('#xigua_hs#xigua_hs_yf')->fetch_all_by_query('( LOCATE(dist1,\'' . $dft['address'] . '\')>0 OR dist1=\'' . $dft['dist3'] . '\' OR dist1=\'' . $dft['dist2'] . '\' OR dist1=\'' . $dft['dist1'] . '\' ) ' . ' and FIND_IN_SET(' . $v['shid'] . ', shids)');
				$yf = floatval($addr['yunfei']);
				$gps = $num * $good_price['price_pt'];
				if ($sp_config['baoyou'] && $gps >= $sp_config['baoyou']) {
					$yf = 0;
				}
				if ($good_price['kami']) {
					$yf = 0;
				}
				$price_last = floatval($gps + $yf);
			} else {
				$_pid = array_filter(explode('_', $_pid));
				$_num = array_filter(explode('_', $_num));
				$_gid = array_filter(explode('_', $_gid));
				$shid = intval($_GET['shid']);
				$gidnum = array_combine($_pid, $_num);
				$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($shid);
				if ($sh['baoyou']) {
					$sp_config['baoyou'] = $sh['baoyou'];
				}
				$goods = $good_prices = array();
				if ($_pid) {
					$good_prices = C::t('#xigua_sp#xigua_sp_good_price')->fetchs($_pid);
				}
				if ($_gid) {
					$goods = C::t('#xigua_sp#xigua_sp_good')->fetchs($_gid);
				}
				$dft['address'] = daddslashes($dft['address']);
				$dft['dist1'] = daddslashes($dft['dist1']);
				$dft['dist2'] = daddslashes($dft['dist2']);
				$dft['dist3'] = daddslashes($dft['dist3']);
				$addr = C::t('#xigua_hs#xigua_hs_yf')->fetch_all_by_query('( LOCATE(dist1,\'' . $dft['address'] . '\')>0 OR dist1=\'' . $dft['dist3'] . '\' OR dist1=\'' . $dft['dist2'] . '\' OR dist1=\'' . $dft['dist1'] . '\' ) ' . ' and FIND_IN_SET(' . $shid . ', shids)');
				$yf = floatval($addr['yunfei']);
				$price_last = 0;
				foreach ($good_prices as $index => $_price) {
					$price_last += $_price['price_pt'] * $gidnum[$index];
					if (!in_array($_price['gid'], $_gid)) {
						hb_message('error~~', 'error');
					}
				}
				if ($sp_config['baoyou'] && $price_last >= $sp_config['baoyou']) {
					$yf = 0;
				}
				$price_last = floatval($price_last) + $yf;
			}
		}
		break;
	case 'buy':
		if (submitcheck('formhash')) {
			$form = $_GET['form'];
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($form['shid']);
			if ($sh['baoyou']) {
				$sp_config['baoyou'] = $sh['baoyou'];
			}
			$note = strip_tags($form['note']);
			$addrid = intval($form['addrid']);
			if (!$form['exp_method']) {
				hb_message(lang_sp('qxz', 0) . lang_sp('psfs', 0), 'error');
			}
			if ($form['isdf']) {
				if (!$form['jaddr']) {
					hb_message(lang_sp('qtxjaddr', 0), 'error');
				}
				if (!$form['jname']) {
					hb_message(lang_sp('qtxjname', 0), 'error');
				}
				if (!$form['jmobile']) {
					hb_message(lang_sp('qtxjmobile', 0), 'error');
				}
				dsetcookie('jaddr', $form['jaddr'], 8640000);
				dsetcookie('jname', $form['jname'], 8640000);
				dsetcookie('jmobile', $form['jmobile'], 8640000);
			}
			if ($form['mult']) {
				$numary = $form['item_num'];
				$yf = 0;
				if ($form['exp_method'] == 'kuaidi') {
					$yfary = C::t('#xigua_hs#xigua_hs_yf')->fetch($addrid);
					$yf = floatval($yfary['yunfei']);
					if (!($form['dist1'] . $form['dist2'] . $form['dist3'] . $form['address'])) {
						hb_message(lang_sp('qszshdz', 0), 'error');
					}
					if (!$form['mobile']) {
						hb_message(lang_hb('mobile_tip', 0), 'error');
					}
				}
				foreach ($numary as $priceid => $item) {
					$numary[$priceid] = $num = intval($item);
					if ($num < 1) {
						hb_message(lang_sp('slcw', 0), 'error');
					}
					$good_price = C::t('#xigua_sp#xigua_sp_good_price')->fetch_by_stock($priceid, $num);
					if (!$good_price) {
						hb_message(lang_sp('kcbz', 0), 'error');
					}
					$good = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($good_price['gid'], 0);
					if ($good['stat'] != 1) {
						hb_message(lang_sp('spyxj', 0), 'error');
					}
				}
				$totalprice = 0;
				$titles = '';
				$ptlogs = array();
				foreach ($numary as $priceid => $num) {
					if ($num < 1) {
						hb_message(lang_sp('slcw', 0), 'error');
					}
					$good_price = C::t('#xigua_sp#xigua_sp_good_price')->fetch_by_stock($priceid, $num);
					if (!$good_price) {
						hb_message(lang_sp('kcbz', 0), 'error');
					}
					$good = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($good_price['gid'], 0);
					if ($good['stat'] != 1) {
						hb_message(lang_sp('spyxj', 0), 'error');
					}
					$title = $good['title'] . str_replace('###', ',', $good_price['name']) . $num . ' ' . lang_sp('fen', 0);
					if (!$titles) {
						$titles = $good['title'] . str_replace('n', count($numary), lang_sp('djsp', 0));
					}
					$item_price = floatval($num * $good_price['price_pt']);
					$totalprice += $item_price;
					$ptlog = array('crts' => TIMESTAMP, 'uid' => $_G['uid'], 'order_id' => '', 'buy_type' => $form['buy_type'], 'pay_money' => $item_price, 'addrid' => $addrid, 'addr' => $form['dist1'] . $form['dist2'] . $form['dist3'] . $form['address'], 'mobile' => $form['mobile'], 'realname' => $form['realname'], 'gid' => $good['id'], 'priceid' => $priceid, 'priceinfo' => serialize($good_price), 'goodinfo' => serialize($good), 'note' => $note, 'yunfee' => 0, 'title' => $title, 'gnum' => $num, 'status' => 1, 'pay_endts' => 0, 'tuan_id' => 0, 'tuan_num' => 1, 'shid' => $good['shid'], 'exp_method' => $form['exp_method'], 'chengben' => $good['chengben'], 'unit_price' => $good_price['price_pt']);
					$ptlog_id = C::t('#xigua_sp#xigua_sp_order')->insert($ptlog, true);
					$ptlog['id'] = $ptlog_id;
					$ptlogs[$ptlog_id] = $ptlog;
				}
				if ($sp_config['baoyou'] && $totalprice >= $sp_config['baoyou']) {
					$yf = 0;
				}
				if (($code = $form['confirm_quan']) && $_G['cache']['plugin']['xigua_hm']) {
					$loginfo = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_by_code($code);
					$secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch($loginfo['secid']);
					if ($totalprice >= $secinfo['underline']) {
						$totalprice = $totalprice - $secinfo['marketprice'];
					}
				}
				$price_l = floatval($totalprice + $yf);
				$location = $_G['siteurl'] . $SCRITPTNAME . ('?id=xigua_sp&ac=order' . $urlext);
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price_l, $titles, 'common_sp', array('data' => $ptlogs, 'callback' => array('file' => 'source/plugin/xigua_sp/function.php', 'method' => 'callback_sp_mpay', 'shid' => $good['shid'], 'price_l' => $price_l, 'ptlog_ids' => implode(',', array_keys($ptlogs)), 'code' => $code, 'uid' => $_G['uid'], 'secid' => $loginfo['secid'], 'secnum' => $loginfo['num']), 'location' => $location, 'referer' => $SCRITPTNAME . '?id=xigua_sp&ac=order' . $urlext, 'tip' => ''), 0);
				foreach ($ptlogs as $ptlog_id => $ptlog) {
					C::t('#xigua_sp#xigua_sp_order')->update($ptlog_id, array('order_id' => $order_id));
				}
				$rl = urlencode($location);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
				hb_message(lang_sp('jumppay', 0), 'loading', $jumpurl);
			} else {
				$priceid = intval($form['pid']);
				$num = intval($form['item_num']);
				if ($num < 1) {
					hb_message(lang_sp('slcw', 0), 'error');
				}
				$gid = intval($form['gid']);
				$good = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid, 0);
				$good_price = C::t('#xigua_sp#xigua_sp_good_price')->fetch_by_stock($priceid, $num);
				if (!$good_price) {
					hb_message(lang_sp('kcbz', 0), 'error');
				}
				$yf = 0;
				if ($form['exp_method'] == 'kuaidi') {
					$yfary = C::t('#xigua_hs#xigua_hs_yf')->fetch($addrid);
					$yf = floatval($yfary['yunfei']);
					if ($good['baoyou_type'] == 1) {
						if ($good['baoyou_num'] > 0 && $num * $good_price['price_pt'] >= $good['baoyou_num']) {
							$yf = 0;
						}
					}
					if (!($form['dist1'] . $form['dist2'] . $form['dist3'] . $form['address'])) {
						hb_message(lang_sp('qszshdz', 0), 'error');
					}
					if (!$form['mobile']) {
						hb_message(lang_hb('mobile_tip', 0), 'error');
					}
				}
				if ($sp_config['baoyou'] && $num * $good_price['price_pt'] >= $sp_config['baoyou']) {
					$yf = 0;
				}
				if ($good_price['kami']) {
					$yf = 0;
				}
				$price_last = floatval($num * $good_price['price_pt'] - $good['youhui']);
				$backjifen = 0;
				if ($good_price['dimoney'] > 0 && $good_price['cnum'] > 0 && getuserprofile('extcredits' . $config['credit_type']) > $good_price['cnum'] * $num) {
					$price_last -= $good_price['dimoney'] * $num;
					$GLOBALS['backjifen'] = $good_price['cnum'] * $num;
					$GLOBALS['backjifen_type'] = $config['credit_type'];
					$GLOBALS['newtouid'] = $good['uid'];
				}
				if ($good_price['price_jf'] > 0) {
					$GLOBALS['newtouid'] = $good['uid'];
					$GLOBALS['price_jfs'] = $good_price['price_jf'] * $num;
					$GLOBALS['jifen_type'] = $config['credit_type'];
					$price_last = 0;
					$yf = 0;
				}
				if ($good['stat'] != 1) {
					hb_message(lang_sp('spyxj', 0), 'error');
				}
				if (($code = $form['confirm_quan']) && $_G['cache']['plugin']['xigua_hm']) {
					$loginfo = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_by_code($code);
					$secinfo = C::t('#xigua_hm#xigua_hm_seckill')->fetch($loginfo['secid']);
					if ($price_last >= $secinfo['underline']) {
						$price_last = $price_last - $secinfo['marketprice'];
					}
				}
				$totalprice = $price_last + $yf;
				if ($totalprice <= 0) {
					$totalprice = 0;
				}
				$title = $good['title'] . str_replace('###', ',', $good_price['name']) . $num . ' ' . lang_sp('fen', 0);
				$ptlog = array('crts' => TIMESTAMP, 'uid' => $_G['uid'], 'order_id' => '', 'buy_type' => $form['buy_type'], 'pay_money' => $totalprice, 'addrid' => $addrid, 'addr' => $form['dist1'] . $form['dist2'] . $form['dist3'] . $form['address'], 'mobile' => $form['mobile'], 'realname' => $form['realname'], 'gid' => $gid, 'priceid' => $priceid, 'priceinfo' => serialize($good_price), 'goodinfo' => serialize($good), 'note' => $note, 'yunfee' => $yf, 'title' => $title, 'gnum' => $num, 'status' => 1, 'pay_endts' => 0, 'tuan_id' => 0, 'tuan_num' => 1, 'shid' => $good['shid'], 'exp_method' => $form['exp_method'], 'chengben' => $good['chengben'], 'unit_price' => $good_price['price_pt']);
				$ptlog_id = C::t('#xigua_sp#xigua_sp_order')->insert($ptlog, true);
				$location = $_G['siteurl'] . $SCRITPTNAME . ('?id=xigua_sp&ac=order_profile&ptlog_id=' . $ptlog_id . $urlext);
				$ptlog['id'] = $ptlog_id;
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_sp', array('data' => $ptlog, 'callback' => array('file' => 'source/plugin/xigua_sp/function.php', 'method' => 'callback_sp_pay', 'code' => $code, 'uid' => $_G['uid'], 'secid' => $loginfo['secid'], 'secnum' => $loginfo['num']), 'location' => $location, 'referer' => $SCRITPTNAME . '?id=xigua_sp&ac=view&gid=' . $gid . $urlext, 'tip' => ''), 0);
				C::t('#xigua_sp#xigua_sp_order')->update($ptlog_id, array('order_id' => $order_id));
				if ($form['exp_method'] == 'hdfk' && $sp_config['allowhd']) {
					callback_sp_pay(array('info' => array('data' => $ptlog)));
					hb_message(lang_sp('xdcg', 0), 'success', $location);
				} else {
					$rl = urlencode($location);
					$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
					hb_message(lang_sp('jumppay', 0), 'loading', $jumpurl);
				}
			}
		}
		break;
	case 'order':
		$navtitle = lang_sp('wddd1', 0);
		if ($_GET['manage']) {
			$navtitle = lang_sp('ddgl1', 0);
		}
		$keyword = stripsearchkey($_GET['keyword']);
		$need_side = 1;
		break;
	case 'order_li':
		$wherearr = array();
		$order = 'id DESC';
		if ($_GET['manage']) {
			$shids = sp_get_shids_by_uid();
			if ($shids) {
				$wherearr[] = 'shid in (' . implode(',', $shids) . ')';
			}
		} else {
			$wherearr[] = 'uid=' . $_G['uid'];
		}
		if ($_GET['status']) {
			$sta = dintval(explode(',', $_GET['status']), 1);
			$wherearr[] = 'status IN ( ' . implode(',', $sta) . ' )';
		}
		if ($_GET['shou_ts'] == 0 - 1) {
			$wherearr[] = 'shou_ts=-1';
		} elseif ($_GET['shou_ts'] == 1) {
			$wherearr[] = 'shou_ts>1';
		}
		if ($_GET['fa_ts'] == 0 - 1) {
			$wherearr[] = 'fa_ts=-1';
		} elseif ($_GET['fa_ts'] == 1) {
			$wherearr[] = 'fa_ts>1';
		}
		if ($_GET['pj_ts'] == 0 - 1) {
			$wherearr[] = 'pj_ts=-1';
		} elseif ($_GET['pj_ts'] == 1) {
			$wherearr[] = 'pj_ts>1';
		}
		if ($_GET['tk'] == 1) {
			$order = 'refund_id DESC';
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (title LIKE \'%' . $keyword . '%\' OR order_id LIKE \'%' . $keyword . '%\' OR mobile like \'%' . $keyword . '%\' OR realname like \'%' . $keyword . '%\') ';
		}
		$GLOBALS['need_sh'] = 1;
		$list = C::t('#xigua_sp#xigua_sp_order')->fetch_all_by_where($wherearr, $start_limit, $lpp, $order, '*', 1);
		include template('xigua_hb:header_ajax');
		include template('xigua_sp:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'comment':
		if (submitcheck('formhash') && $do == 'comment') {
			$star = intval($_GET['star']);
			$shid = intval($_GET['shid']);
			if ($star < 1) {
				$star = 0;
			}
			if ($star > 100) {
				$star = 100;
			}
			if (!$_G['group']['allowreply']) {
				hb_message(lang_hb('no_permission_to_post', 0), 'error');
			}
			$shdata = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 1);
			if (!$shdata) {
				hb_message(lang_hs('shangjia', 0) . lang_hs('yiguoqi', 0), 'error');
			}
			$oid = intval($_GET['order_id']);
			if (!$oid) {
				hb_message(lang_sp('ddbcz', 0), 'error');
			}
			$olist = C::t('#xigua_sp#xigua_sp_order')->fetch_all_by_where(array('id=' . $oid, 'pj_ts=-1 AND status in(2,6) AND shou_ts>1'));
			if (!$olist) {
				hb_message(lang_sp('ddbcz', 0), 'error');
			}
			$touid = intval($_GET['touid']);
			if (!trim($_GET['comment'])) {
				hb_message(lang_hb('empt', 0), 'error');
			}
			$comment_msg = censor($_GET['comment'], NULL, true);
			if (is_array($comment_msg) && $comment_msg['message']) {
				hb_message($comment_msg['message'], 'error');
			}
			$cmtimg = array_filter(explode(',', trim($_GET['cmtphoto'], ',')));
			$ret = C::t('#xigua_sp#xigua_sp_good')->comment_add($_G['uid'], $touid, 0, $comment_msg, $shdata['uid'], $shid, $star, $cmtimg, 0, $gid);
			if ($ret) {
				C::t('#xigua_sp#xigua_sp_order')->update($oid, array('pj_ts' => TIMESTAMP, 'cmtid' => $ret));
				notification_add($touid ? $touid : $shdata['uid'], 'system', lang_hb('comment_to', 0), array('url' => $_G['siteurl'] . $SCRITPTNAME . '?id=xigua_sp&ac=view&gid=' . $gid . $urlext, 'username' => $_G['username'], 'info' => $comment_msg), 1);
				hb_message(lang_sp('huifuchenggong', 0), 'success', $SCRITPTNAME . '?id=xigua_sp&ac=order&status=2,6&shou_ts=1&pj_ts=1');
			} else {
				hb_message(lang_sp('huifushibai', 0), 'error');
			}
		} else {
			$comments = array();
			if ($cid = intval($_GET['cid'])) {
				$comments[] = C::t('#xigua_hb#xigua_hb_comment')->fetch($cid);
			} else {
				if ($gid) {
					$good = C::t('#xigua_sp#xigua_sp_good')->fetch($gid);
					$comments = C::t('#xigua_sp#xigua_sp_good')->fetch_comment_by_gid($good['shid'], $gid, $start_limit, $lpp);
					if ($_G['uid']) {
						$shdata = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
						if ($shdata['uid'] == $_G['uid']) {
							$vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
						}
					}
				}
			}
			include template('xigua_hb:header_ajax');
			include template('xigua_sp:comment_li');
			include template('xigua_hb:footer_ajax');
		}
		break;
	default:
		if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_sp/include/c_' . $ac . '.php'))) {
			include DISCUZ_ROOT . ('source/plugin/xigua_sp/include/c_' . $ac . '.php');
		}
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (is_file(DISCUZ_ROOT . 'source/plugin/xigua_sp/include/c_pc_sp.php')) {
	include DISCUZ_ROOT . 'source/plugin/xigua_sp/include/c_pc_sp.php';
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_sp/template/touch/' . $ac . '.php'))) {
	include template('xigua_sp:' . $ac);
}