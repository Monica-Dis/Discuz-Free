<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_sp/function.php';

$status_font = array(
    1 => lang_sp('status_1',0),
    2 => lang_sp('status_2',0),
    3 => lang_sp('status_3',0),
    4 => lang_sp('status_4',0),
//    5 => lang_sp('status_5',0),
//    6 => lang_sp('status_6',0),
//    7 => lang_sp('status_7',0),
);


if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$sta = $status_font;

function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}



$page = max(1, intval($_GET['page']));
$lpp = $_GET['lpp'] ? $_GET['lpp'] : 10;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('ptlogid')){
    $ptlogid = $_GET['ptlogid'];
    if($_GET['yundan_gs'] && $_GET['yundan']){
        DB::update('xigua_sp_order', array(
            'fa_ts' => TIMESTAMP,
            'yundan_gs' => $_GET['yundan_gs'],
            'yundan' => $_GET['yundan'],
        ), array(
            'id' => $ptlogid
        ));
        unset($_GET['yundan_gs']);
        unset($_GET['yundan']);
        unset($_GET['formhash']);
        unset($_GET['permsubmit']);
        unset($_GET['ptlogid']);
        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_order&".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
    }
}

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_sp#xigua_sp_order')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            if ($item['shou_ts'] == 1) {
                $old = C::t('#xigua_sp#xigua_sp_order')->fetch($index);
                if ($old['shou_ts']<1) {
                    $item['shou_ts'] = TIMESTAMP;
                    if (!$old['shou_confirm_ts']) {
                        $item['shou_confirm_ts'] = TIMESTAMP;
                        $shid = $old['shid'];

                        include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
                        $shdata = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                        $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                        $insxf = intval(abs($vipinfo['insxf'])) / 100;
                        if ($shdata['shinsxf']) {
                            $insxf = intval(abs($shdata['shinsxf'])) / 100;
                        }

                        $sxfee = round($insxf * $old['pay_money'], 2);
                        $money = $old['pay_money'] - $sxfee;

                        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', $money);
                        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                            'uid' => $shdata['uid'],
                            'crts' => TIMESTAMP,
                            'size' => $money,
                            'note' => lang_sp('ddh', 0) . $old['order_id'] . '<br>' . lang_sp('kcsxf', 0) . $sxfee,
                            'link' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id={$old['id']}&manage=1" . $urlext,
                        ));

                        if ($_G['cache']['plugin']['xigua_hh']) {
                            @DB::query("UPDATE %t SET reach=%d WHERE idtype='common_sp' AND FIND_IN_SET(%d ,thirdid)", array('xigua_hh_income', ($_G['cache']['plugin']['xigua_hh']['needshen_in'] ? -1 : 0), $index));
                        }
                    }
                }else{
                    unset($item['shou_ts']);
                }
            }
            if($item['status']>=97){
                unset($item['status']);
            }
            if($item['yundan'] || $item['yundan_gs']){
                $item['fa_ts'] = TIMESTAMP;
            }
            if($item['status']==4){
                if ($_G['cache']['plugin']['xigua_hh']) {
                    @DB::query("UPDATE %t SET reach=%d WHERE idtype='common_sp' AND FIND_IN_SET(%d ,thirdid)", array('xigua_hh_income', -2, $index));
                }
            }
            C::t('#xigua_sp#xigua_sp_order')->update($index, $item);
        }
    }
    unset($_GET['formhash']);
    unset($_GET['r']);
    unset($_GET['permsubmit']);
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_order&".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword'";
}elseif($keyword){
    $uids = DB::fetch_all("select uid from " . DB::table('common_member') . " where username like '%$keyword%' ", array(), 'uid');
    if ($uids) {
        $wherearr[] = "( uid in (".implode(',', array_keys($uids)).") OR  mobile like '%$keyword%' OR realname like '%$keyword%' OR title like '%$keyword%' OR goodinfo like '%$keyword%')";
    } else {
        $wherearr[] = " (mobile like '%$keyword%' OR realname like '%$keyword%' OR title like '%$keyword%' OR goodinfo like '%$keyword%')";
    }
}
$sta[97] = lang_sp('hx1',0);
$sta[98] = lang_sp('hx2',0);
$sta[99] = lang_sp('hx3',0);

$order = 'id desc';
if($_GET['status'] == 97){
    $wherearr[] = "status IN ( 2,6 ) AND fa_ts=-1";
    $order = 'pay_ts desc';

}elseif($_GET['status'] == 98){
    $wherearr[] = "status IN ( 2,6 ) AND fa_ts>1";
    $order = 'fa_ts desc';

}elseif($_GET['status'] == 99){
    $wherearr[] = "status IN ( 2,6 ) AND shou_ts>1";
    $order = 'shou_ts desc';
}

if($_GET['status']&&$_GET['status']<97){
    $wherearr[] = "status='".intval($_GET['status'])."'";
}

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_order");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_sp('searchinput',0).'" value="'.$_GET['keyword'].'" class="txt"  style="width: 220px;"/> ';

echo '<select name="status"><option value="0">'.lang_sp('qb',0).'</option>';
foreach ($sta as $index => $item) {
    $chk = isset($_GET['status']) && $_GET['status']==$index ? 'selected':'';
    echo " <option value=\"$index\" $chk>$item</option>";
}
echo '</select>';
/*
$cus = array(
    1 => lang_sp('hx1',0),
    2 => lang_sp('hx2',0),
    3 => lang_sp('hx3',0),
);
echo '&nbsp;&nbsp;&nbsp;';
foreach ($cus as $index => $_v) {
    echo '<label><input type="radio" name="cus" value="'.$index.'" ' . ($_GET['cus']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
}*/

echo '&nbsp;&nbsp;&nbsp;';
$lpp_se = "<select name=\"lpp\">";
foreach (array(1, 10 ,20, 50, 100, 200, 500, 1000, 2000, 5000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;

echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_order".' class="btn" >'.cplang('reset').'</a> ';

echo ' <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_order&".http_build_query($_GET).'&doexport=1" class="btn" >'.lang_sp('dc', 0).'</a> ';

echo '</div>';

showtableheader(lang_sp('tichengmanage', 0));
$ress = array();

showtablerow('class="header"',array(),$ress[] = array(
    lang_hb('del', 0),
    lang_sp('ID', 0),
    lang_sp('fkyh', 0),
    lang_sp('ddxinxi', 0),
    lang_sp('status', 0),
    lang_sp('shdz', 0),
    lang_sp('fhxx', 0),
    lang_sp('spxx', 0),
));

$res = C::t('#xigua_sp#xigua_sp_order')->fetch_all_by_where($wherearr, $start_limit, $lpp, $order);
$icount = C::t('#xigua_sp#xigua_sp_order')->fetch_count_by_where($wherearr);

$refunds = $uids = $ordersns= array();
foreach ($res as $v) {
    $uids[] = $v['uid'];
    $uids[] = $v['hxuid'];
    $ordersns[] = $v['order_id'];
    $refunds[] = $v['refund_id'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $vusers = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}
if($refunds){
    $refunds = DB::fetch_all('SELECT * FROM %t WHERE id IN (%n)', array('xigua_sp_refund', $refunds), 'id');
    foreach ($refunds as $index => $refund) {
        $refunds[$index] = C::t('#xigua_sp#xigua_sp_refund')->prepare($refund);
    }
}
if($ordersns){
    $ordersns = DB::fetch_all('SELECT order_id,order_sn,jifen,jifen_type FROM %t WHERE order_id IN (%n)', array('xigua_hb_order', $ordersns), 'order_id');
}
$kdgs = lang_sp('kdgs',0);
$kddh = lang_sp('kddh',0);
foreach ($res as $k => $v) {
    $v['refund'] = str_replace(array('array (', ')',',',"\n",'\'','=>'), array('', '','<br>','','', ':'), $v['refund']);
    if(strpos($v['refund'], 'result_code : SUCCESS')!==false){
        $v['refund'] = '<p style="color:forestgreen;font-weight:bold">'.lang_sp('tkcg',0).'</p>'.$v['refund'];
    }
    $v['refund'] = trim($v['refund']);

    $id = $v['id'];
    $uid = $v['uid'];
    $info = $v['info'];
    if(!is_array($info['info'])){
        $info['info'] = unserialize($info['info']);
    }

    $mobile = $vusers[$v['uid']]['mobile'];
    if(!$mobile):
        $__profile = C::t('common_member_profile')->fetch($v['uid']);
        $mobile = $__profile['mobile'];
    endif;
    $realname = $vusers[$v['uid']]['realname'];
    if(!$v['mobile']){
        $v['mobile'] = $mobile;
    }
    if(!$v['realname']){
        $v['realname'] = $realname;
    }

    $fromuid = $info['fromuid'];
    $oldvs = $_GET['status'];
    if(in_array($v['status'], array(2,6)) && $v['fa_ts']>1 && $v['shou_ts']=='-1'){
        $oldvs = 98;
    }
    $sel = $seltype = '';
    foreach ($sta as $index => $item) {

        if(in_array($index, array(97,98,99))){
            if($oldvs==$index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }else{
            if($v['status'] == $index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }
    }
    $crts = date('Y-m-d H:i:s', $v['crts']);
    $goodinfo = unserialize($v['goodinfo']);
    $priceinfo = unserialize($v['priceinfo']);

    $pingbi = $v['shou_ts']>1 ? 'selected' : '';
    $unpingbi = $pingbi ? '' : 'selected';

    $shouinfo = '';
    if($priceinfo['kami'] && $v['hxcode']){
        $shouinfo .= lang_sp('xnkm',0).' : '. $v['hxcode'];
    }elseif($v['hxcode']){
        $shouinfo .= $v['hxcrts'] ? lang_sp('yhxhxsj',0).date('Y-m-d H:i:s', $v['hxcrts']) : lang_sp('yfkdhx',0);
        $shouinfo .= '<br>';
        $shouinfo .= lang_sp('hxm',0).' : '. $v['hxcode'];
        $shouinfo .= '<br>';
        $shouinfo .= lang_sp('hxuid',0).' : '. ($v['hxuid'] ? " [UID: {$v['hxuid']}] " . $users[$v['hxuid']]['username'] : '-');
        $h = sp_qrcode_make($v['id'], $v['hxcode']);
        $shouinfo .= "<br><a href='$h' target='_blank'><img style='width:60px;' src='".$h."' /></a>";
    } else{
        $shouinfo = ($v['fa_ts']>1 ? lang_sp('fhsj',0).': '.date('Y-m-d H:i:s', $v['fa_ts']) :'').
            '<br>'. ($v['yundan'] ? lang_sp('ydxx',0) . ' :'.$v['yundan_gs'].' '.$v['yundan'] :'');
    }
$ret_tk = '';
if($v['refund_id']>0 ){
    $rr = $refunds[$v['refund_id']];
    $tkyy = lang_sp('tkyy',0);
    $sqsj = lang_sp('sqsj',0);
    $tkqrsj = lang_sp('tkqrsj',0);
    if($v['yundan']){
        $p1 = '<p>'.lang_sp('khysh',0).'</p>';
    }
    if($rr['status']==2){
        $p2 = "<p>$tkqrsj: {$rr['upts_u']}</p>";
    }

    $ret_tk = <<<HTML
<p>$tkyy: {$rr['note']}</p>
<p>$sqsj: {$rr['crts_u']}</p>
$p1
$p2
<p>{$v['refund']}</p>
HTML;
}
    $selsho = "";
    $selsho .= "<option value=\"1\" $pingbi>".lang_sp('yqrsh',0)."</option>";
    $selsho .= "<option value=\"-1\" $unpingbi>".lang_sp('wqrsh',0)."</option>";

    $jftype = $ordersns[$v['order_id']]['jifen_type'];
    $jifendan =$ordersns[$v['order_id']]['jifen'];
    $jifenall = ($jifendan*$v['gnum']).$_G['setting']['extcredits'][$jftype]['title'];
    $jifendan1 = $jifendan.$_G['setting']['extcredits'][$jftype]['title'];
    showtablerow('', array(), $res_ = array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
        $id,
        "UID: $uid <br><a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
        lang_hb('orderid',0).' : <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_order&keyword=".$v['order_id']."&note=0&page=1".'">'.$v['order_id'] . '</a><br>'.
        ($ordersns[$v['order_id']]['order_sn'] ? lang_hb('ordersn',0).': '.$ordersns[$v['order_id']]['order_sn'] . '<br>' : '').
        lang_sp('crts',0).': '.$crts.'<br>'.

        ($ordersns[$v['order_id']]['jifen']<=0 ? ( $v['exp_method']!='hdfk' ? '<b style="color:orangered">'.lang_sp('zfje',0).$v['pay_money'] . '</b><br>'.lang_sp('zfsj',0).$v['pay_ts_u'] . '<br>' : '<b style="color:orangered">'.lang('plugin/xigua_sp', 'hdfk').':'.$v['pay_money'].'</b><br>') : '<b style="color:forestgreen">'.lang_sp('zfje',0).$jifenall.'</b><br>')
        .
        ($v['shou_ts']>1 ? '<b>'.lang('plugin/xigua_sp', 'shouts').':'.date('Y-m-d H:i:s', $v['shou_ts']).'</b>' : '') ,

        "<select name='r[$id][status]' $dis>$sel</select>".
        ("<div style='margin-top:5px;'><select name='r[$id][shou_ts]'>$selsho</select></div>")

        .($v['exp_method']!='hdfk'?'':'<b style="color:orangered">'.lang('plugin/xigua_sp', 'hdfk').'</b>')."<br>".$ret_tk,

        '<div style="width:200px">'.
        '<p style="color:orangered">'.(
                $v['jaddr'] ? (
                        lang_sp('dfddxq',0).':<br>'.
                        $v['jaddr'].'<br>'.
                        $v['jname'].'<br>'.
                        $v['jmobile'].'<br>'
                ) :''
        ).'</p><br>'.

        ( $v['ziti']&&$v['hxcode'] ? (
                '<p style="color:#4572c5">' .lang_sp('ztd',0) .':<br>'. str_replace('||||', '<br>', $v['ziti']).'</p>'.
                ('<p style="color:orangered;margin-top:5px">'.''.lang_sp('quhuoren',0).':<br>'.
                        lang_sp('zsxm',0).':'.$realname .'<br>'.
                        lang_sp('sjhm',0).':'.$mobile.'</p>'
                )
        )
            : ('<p style="color: forestgreen">'.lang_sp('shdz1',0).':</p>'.
            $v['addr'].'<br>'.
            $v['realname'].'<br>'.$v['mobile'].'<br>') ).

        ($v['hxcode'] ? ' ' : ((in_array($v['status'], array(2,6))) ?
            ( "<table class=\"\">
            <tr class=\"hover\">
                <td align=\"left\">$kdgs <textarea name=\"r[$id][yundan_gs]\" style='width:100px;height:18px;vertical-align:middle'>{$v['yundan_gs']}</textarea></td>
            </tr>
            <tr class=\"hover\">
                <td align=\"left\">$kddh <textarea name=\"r[$id][yundan]\" style='width:100px;height:18px;vertical-align:middle'>{$v['yundan']}</textarea></td>
            </tr>
        </table>". "<br><a style='font-weight:bold;display:none' href=\"javascript:;\" onclick='return _show_company_profile1($id);'>". lang_sp('djfh', 0) . "</a>")

            : '')).'</div>'
    ,


        $shouinfo,
'<div style="width:200px">'.
        $goodinfo['title'].'[ID: '.$goodinfo['id'].']<br>'.
        $goodinfo['shname'].'[ID: '.$goodinfo['shid'].']<br>'.
        implode(' ', explode('###', $priceinfo['name'])).'<br>'.
        ($jifendan ? '<b style="color:forestgreen;">'.lang_sp('dj',0).': '.$jifendan1.'</b><br>' : '<b style="color:orangered;">'.lang_sp('dj',0).': '.$v['unit_price'].'</b><br>').
        '<b style="color:orangered;">'.lang_sp('sl',0).': '.$v['gnum'].'</b><br>'.
        '<b>'.lang_sp('yunfee',0).$v['yunfee'] . '</b><br>'.
        ($priceinfo['price_cb'] ? '<b>'.lang_sp('chengben',0).': '.$priceinfo['price_cb'] . '</b><br>' :'').
        ($v['note'] ? lang_sp('bz',0).': '.$v['note'] . '<br>' :'') .'</div>'
    ,

    ));
    unset($res_[0]);
    unset($res_[6]);
    unset($res_[5]);
    unset($res_[7]);

    $res_[4] = '['.$v['order_id'].']';

    $res_ = array_values($res_);
    array_pop($res_);



    $res_[] = $v['realname'];
    $res_[] = $v['mobile'];
    $res_[] = $v['addr'];

    $res_[] = $v['buy_type']==1? lang_sp('dm',0) : lang_sp('pt',0);

    $res_[] = $sta[$v['status']] .' '.($v['refund'] ? lang_sp('zdtkxq',0).":".$v['refund']:'');

    $res_[] = $goodinfo['title'].'[ID: '.$goodinfo['id'].']';
    $res_[] = $goodinfo['shname'].'[ID: '.$goodinfo['shid'].']';
    $res_[] = implode(' ', explode('###', $priceinfo['name']));
    $res_[] = $v['unit_price'];
    $res_[] = $v['gnum'];
    $res_[] = $v['yunfee'];
    $res_[] = $v['pay_money'];
    $res_[] = $v['note'];

    $res_[] = $crts;
    $res_[] = $v['pay_ts_u'];
    $res_[] = $priceinfo['price_cb'];
    $res_[] = $users[$v['hxuid']]['username'];
    $res_[] = $v['hxcrts'] ? date('Y-m-d H:i:s', $v['hxcrts']) : ' ';
    $res_[] = ' ';



    foreach ($res_ as $index => $item) {
        $item = nl2br($item);
        $item= str_replace('<br>', '   ', $item);
        $item= str_replace('<br />', '   ', $item);
        $item= str_replace(',', '  ', $item);
        $item= str_replace(array("\t","\n","\r"), '  ', $item);
        $res_[$index] = trim(strip_tags($item));
    }
    $ress[] = $res_;
}

if($_GET['doexport']==1){
    $title_arr= array();
    unset($ress[0][0]);
    unset($ress[0][5]);
    unset($ress[0][6]);
    unset($ress[0][7]);
    array_pop($ress[0]);
    foreach ($ress[0] as $index => $item) {
        $title_arr[] = $item;
    }

    $title_arr[] = lang_sp('zsxm',0);
    $title_arr[] = lang_sp('mobile',0);
    $title_arr[] = lang_sp('shdz',0);

    $title_arr[] = lang_sp('gmlx', 0);
    $title_arr[] = lang_sp('status', 0);

    $title_arr[] = lang_sp('title',0);
    $title_arr[] = lang_sp('oinfo5',0);
    $title_arr[] = lang_sp('ggm',0);
    $title_arr[] = lang_sp('dj',0);
    $title_arr[] = lang_sp('sl',0);
    $title_arr[] = lang_sp('yunfee',0);
    $title_arr[] = lang_sp('zfje',0);
    $title_arr[] = lang_sp('bz',0);

    $title_arr[] = lang_sp('crts',0);
    $title_arr[] = lang_sp('zfsj',0);
    $title_arr[] = lang_sp('chengben',0);
    $title_arr[] = lang('plugin/xigua_sp', 'hxuid');
    $title_arr[] = lang_sp('hxcrts',0);
    $title_arr[] = ' ';

    unset($ress[0]);
    $ress = array_values($ress);

    export_csv($ress, $title_arr);
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_order&lpp=$lpp&".http_build_query($_GET).'&doexport=0', 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter(); /*Dism_taobao-com*/

?>
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>


<div id="rsel_menu" class="custom cmain" style="display:none;width:400px;height:250px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr"><?php lang_sp('wanshan');?></h3>
    </div>
    <div id="rsel_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_order&".http_build_query($_GET));
        ?>
        <table class="">
            <tr class="hover">
                <td align="left"><?php lang_sp('kdgs');?></td>
                <td><textarea name="yundan_gs" cols="30" rows="2"></textarea></td>
            </tr>
            <tr class="hover">
                <td align="left"><?php lang_sp('kddh');?></td>
                <td><textarea name="yundan" cols="30" rows="2"></textarea></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="ptlogid" id="ptlogid" value="0">
                    <input type="submit" class="btn" name="editsubmit" value="<?php lang_sp('djfh');?>" />
                </td>
            </tr>
        </table>
        <?php showformfooter(); /*Dism_taobao-com*/?>
    </div>
</div>
<script>
    function _show_company_profile1(ptlogid) {
        showMenu({'ctrlid': 'rsel', 'evt': 'click', 'duration': 3, 'pos': '00'});
        $('ptlogid').value = ptlogid;
    }
</script>