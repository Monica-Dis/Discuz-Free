<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2017/11/19
 * Time: 16:38
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_sp/function.php';
$status_font = array(
    1 => lang_sp('status_1',0),
    2 => lang_sp('status_2',0),
    3 => lang_sp('status_3',0),
    4 => lang_sp('status_4',0),
//    5 => lang_sp('status_5',0),
//    6 => lang_sp('status_6',0),
//    7 => lang_sp('status_7',0),
);

/**/

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$statuss = array(
 1=> lang_sp('ysj',0),
 2=> lang_sp('dsh',0),
 3=> lang_sp('yxj',0),
);

$pt_config = $_G['cache']['plugin']['xigua_sp'];
$svicerange = array();
foreach (explode("\n", trim($pt_config['svicerange'])) as $index => $item) {
    $svicerange[] = trim($item);
}
$svicerange2 = array();
foreach (explode("\n", trim($pt_config['svicerange2'])) as $index => $item) {
    $svicerange2[] = trim($item);
}

if(submitcheck('fzid', 1) && $_GET['formhash']==formhash()){
    $fzid = intval($_GET['fzid']);

    $old_data = C::t('#xigua_sp#xigua_sp_good')->fetch($fzid);
    if($old_data){
        unset($old_data['id']);
        $old_data['title'] = lang_sp('fz',0).$old_data['title'];
        $newgid = C::t('#xigua_sp#xigua_sp_good')->insert($old_data, 1);
        $goodprioce = C::t('#xigua_sp#xigua_sp_good_price')->fetch_all_by_where(array('gid='.$fzid),0,999);
        foreach ($goodprioce as $index => $item) {
            unset($goodprioce[$index]['id']);
            unset($item['id']);
            $goodprioce[$index]['gid'] = $item['gid'] = $newgid;
            C::t('#xigua_sp#xigua_sp_good_price')->insert($item, 1);
        }
        cpmsg(lang_sp('fzsucceed', 0).$newgid, "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good", 'succeed');
    }
}

if($gid = intval($_GET['price_id'])) {

    if(submitcheck('initsubmit')){


        $old_data = C::t('#xigua_sp#xigua_sp_good')->fetch($gid);
        $old_data = C::t('#xigua_sp#xigua_sp_good')->prepare($old_data);

        $editform  = array();
        $spgg = array();
        $spggtmp = array();
        foreach (explode("\n", trim($_GET['spgg'])) as $index => $item) {
            list($name, $value) = explode("=", trim($item));
            $value = explode(',', trim($value));
            if($name&&$value){
                $spgg[] = array(
                    'id' => $index,
                    'name' => $name,
                    'ggtext' => $value
                );
            }
        }
        $editform['spgg'] = serialize($spgg);

        $rs = C::t('#xigua_sp#xigua_sp_good')->update($gid, $editform);

        if($spgg){
            DB::delete('xigua_sp_good_price', array('gid' => $gid));
            $price_list = $pow = array();
            $ggtest = $n = array();
            foreach ($spgg as $str => $item) {
                $ggtest[] = $item['ggtext'];
            }
            $ggtest = combina($ggtest);
            foreach ($ggtest as $index => $item) {
                $data = array();
                $data = array(
                    'crts' => TIMESTAMP,
                    'upts' => TIMESTAMP,
                    'uid' => $item['uid']?$item['uid']:$sh['uid'],
                    'gid' => $gid
                );
                $data['price_pt'] = $old_data['tprice'];
                $data['price_dm'] = $old_data['dprice'];
                $data['price_hk'] = $old_data['tprice'];
                $data['price_sc'] = $old_data['disprice'];
                $data['price_cb'] = $old_data['tprice'];
                $data['price_jf'] = $old_data['price_jf'];
                $data['kami'] = trim($old_data['kami']);
                $data['stock']    = $old_data['stock'];
                $data['name']     = is_array($item) ? implode('###', $item) : $item;
                C::t('#xigua_sp#xigua_sp_good_price')->update_price($data);

            }
        }elseif(!$spgg){
            DB::delete('xigua_sp_good_price', array('gid' => $gid));
        }
        cpmsg(lang_sp('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&price_id={$_GET['price_id']}&page=$page", 'succeed');
    }
    if(submitcheck('permsubmit')){
        $form  = $_GET['r'];
        $names = array();
        foreach ($form as $index => $item) {
            $names[] = $item['name'];
        }


        if($names){
            DB::query("DELETE FROM %t WHERE gid=%d AND `name` NOT IN (%n)", array('xigua_sp_good_price', $gid, $names));
        }

        $_newimglist = hb_uploads($_FILES['editor']);
        $fileform = array();
        foreach ($_newimglist as $__k => $__v) {
            if ($__v['ggfm']['errno'] == 0) {
                $fileform[$__k] = $__v['ggfm']['error'];
            }
        }
        $tmppricejf = 0;
        foreach ($form as $index => $item) {
            $data = array();
            $data = array(
                'upts' => TIMESTAMP,
                'gid' => $gid
            );
            $data['price_pt'] = $item['price_pt'];
            $data['price_dm'] = $item['price_dm'];
            $data['price_hk'] = $item['price_hk'];
            $data['price_sc'] = $item['price_sc'];
            $data['price_cb'] = $item['price_cb'];
            $data['price_jf'] = $item['price_jf'];
            $data['ggfm'] = $fileform[$index];
            $data['kami'] = trim($item['kami']);
            $data['stock']    = $item['stock'];
            $data['name']     = $item['name'];

            C::t('#xigua_sp#xigua_sp_good_price')->update_price($data);
            if($item['price_jf']>0){
                $tmppricejf = $item['price_jf'];
            }
        }
        $rs = C::t('#xigua_sp#xigua_sp_good')->update($gid, array('newjifenprice' => $tmppricejf));
        cpmsg(lang_sp('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&price_id={$_GET['price_id']}&page=$page", 'succeed');
    }else{
        $old_data = C::t('#xigua_sp#xigua_sp_good')->fetch($gid);
        $old_data = C::t('#xigua_sp#xigua_sp_good')->prepare($old_data);
        $list = $old_data['spgg_ary'];
        $tc = 1;
        $pow = array();
        $ggtest = $n = array();
        foreach ($list as $str => $item) {
            $ggtest[] = $item['ggtext'];
        }
        $ggtest = combina($ggtest);
        $price_list = C::t('#xigua_sp#xigua_sp_good_price')->fetch_all_by_where(array("gid=".$gid), 0, 9999, '', '*', 'name');
        echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" /><style>.mb2{margin-bottom:2px}</style>";
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&price_id={$gid}", 'enctype');
        showtableheader($old_data['title']." [ID: {$old_data['id']} ] " ."  <a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good'> ".lang_sp('back',0)."</a>" );
        showtablerow('class="header"', array(), array(
            lang_sp('ID', 0),
            lang_sp('ggtitle', 0),
            lang_sp('ggfm', 0),
            lang_sp('price_dm', 0),
            lang_sp('stock', 0),
            lang_sp('kami', 0),
            lang_sp('crts', 0).'<br>'.
            lang_sp('upts', 0),
        ));

        foreach ($price_list as $index => $item) {
            $id = $item['id'];
            showtablerow('', array(), array(
                $id,
                $item['name']."<input name='r[$id][name]' type='hidden' class='txt' value='{$item['name']}' />",
                "<input name='editor[$id][ggfm]' type='file' class='txt' /> 
<img style='width:60px;height:60px;display: inline-block;vertical-align: middle;' src='{$item['ggfm']}' onerror='this.error=null;this.style.display=\"none\"' />",
                '<div class="mb2">'.lang_sp('price_dm', 0)." <input name='r[$id][price_dm]' class='txt' value='{$item['price_dm']}' /></div>".
                '<div class="mb2">'.lang_sp('price_hk', 0)." <input name='r[$id][price_hk]' class='txt' value='{$item['price_hk']}' /></div>".
                '<div class="mb2">'.lang_sp('price_sc', 0)." <input name='r[$id][price_sc]' class='txt' value='{$item['price_sc']}' /></div>".
                '<div class="mb2">'.lang_sp('chengben1', 0)." <input name='r[$id][price_cb]' class='txt' value='{$item['price_cb']}' /></div>".
                '<div>'.lang_sp('price_jf', 0)." <input name='r[$id][price_jf]' class='txt' value='{$item['price_jf']}' /></div>",
                "<input name='r[$id][stock]' class='txt' value='{$item['stock']}' />",
                "<textarea name='r[$id][kami]'>{$item['kami']}</textarea>",
                date('Y-m-d H:i:s', $item['crts']).'<br>'.
                date('Y-m-d H:i:s', $item['upts']),
            ));
        }
        showsubmit('permsubmit', 'submit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/

        echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&price_id={$gid}");
        showtableheader(lang_sp('spggdesc',0) );

        $re = unserialize($old_data['spgg']);
        $ret = '';
        foreach ($re as  $item) {
            $ret .= $item['name'].'=';
            $retmp = array();
            foreach ($item['ggtext'] as $itemm) {
                $retmp[] = $itemm;
            }
            $ret .= implode(',', $retmp) . "\n";
        }
        $ret = trim($ret);

        echo "<td>
<textarea name='spgg' style='width:500px;height:200px'>{$ret}</textarea>
</td>";
        showsubmit('initsubmit', lang_sp('sycgg',0));
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
    }

}elseif($secid = intval($_GET['secid'])){

    $res = C::t('#xigua_sp#xigua_sp_good')->fetch($secid);
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $res = array (
                'crts' => TIMESTAMP,
                'displayorder' => '0',
                'uid' => '',
                'shid' => '',
                'title' => '',
                'shname' => '',
                'hy' => '',
                'hangye_id1' => '0',
                'hangye_id2' => '0',
                'stock' => '0',
                'sellnum' => '0',
                'dprice' => '0.00',
                'disprice' => '0.00',
                'spgg' => lang_sp('ggdft',0),
                'stat' => '2',
                'status' => '2',
                'danci' => '0',
                'zong' => '0',
                'ptmin' => '2',
                'newp' => '0',
                'ptshixian' => '24',
                'upts' => TIMESTAMP,
                'jieshao' => '',
                'append_img' => '',
                'append_text' => '',
                'album' => '',
                'stid' => '0',
                'srange' => '',
                'jtt' => '',
                'youhui' => '0.00',
                'groupid' => ''
            );
            $neww = 1;
        }
        unset($res['shixian']);
        if($neww!=1){
            unset($res['spgg']);
        }
        unset($res['tprice']);
        unset($res['ptmin']);
        unset($res['ptshixian']);
        unset($res['youhui']);
        unset($res['hangye_id1']);
        unset($res['custom_zz']);
        unset($res['dftyf']);
        unset($res['chengben']);
        unset($res['hangye_id2']);

        echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_sp('spgl',0) . ($secid>0?$secid:''). "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good'> ".lang_sp('back',0)."</a>");

        foreach ($res as $index => $re) {
            if(in_array($index, array('usetime','bigweek','bigdate','bigrate','shname', 'not_start', 'end','srange_ary','xiajia','shen', 'quan', 'yuanprice','id','color_title', 'is_end', 'shares','status','jtt'))){
                continue;
            }

            if($index == 'hy'){
                $re = str_replace(' ', '#', $re);
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('crts', 'upts'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('stat'))){
                $cs = '<select name="editform[stat]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('psfs_val'))){
                $cs = '<select name="editform[psfs_val]">';
                foreach (array(
                    '3' => lang_sp('tsddhkd',0),
                    '1' => lang_sp('ddhx',0),
                    '2' => lang_sp('kdfy',0),
                         ) as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('shid'))){
                $cs = '<select name="editform[shid]">';
                foreach (DB::fetch_all('select shid,`name` from %t WHERE display=1 ORDER BY shid ASC', array(
                    'xigua_hs_shanghu',
                    TIMESTAMP
                ), 'shid') as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['name']}[".lang_sp('sh',0)."ID:{$c['shid']}]</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('thumb'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('yuyue' ,'gongkai','showdis', 'selfdis', 'orderdis', 'newp', 'allow_tk','baoyou_type'))){
                $tp = 'radio';
            }elseif(in_array($index, array('srange'))){
                $re = explode("\t", $re);
                $cs = '<select name="editform[srange][]" multiple="multiple">';
                foreach ($svicerange as $__v) {
                    $shortv = explode('#', $__v);
                    $shortv = $shortv[0];
                    $s = '';
                    if(in_array($shortv, $re)){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$shortv'>$shortv</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('srange2'))){
                $re = explode("\t", $re);
                $cs = '<select name="editform[srange2][]" multiple="multiple">';
                foreach ($svicerange2 as $__v) {
                    $shortv = explode('#', $__v);
                    $shortv = $shortv[0];
                    $s = '';
                    if(in_array($shortv, $re)){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$shortv'>$shortv</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }

            if(in_array($index, array('fengmian'))){
                $tp = 'filetext';
            }
            if (in_array($index, array('album', 'append_img', 'append_text'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $sp_config = $_G['cache']['plugin']['xigua_sp'];
                $loopnum = $sp_config['maximg'];
                if ($index == 'append_text') {
                    $tp = 'text';
                }
                for ($i = 0; $i < $loopnum; $i++) {
                    if($tp=='filetext'){
                        $cmt = $re[$i] ? '<a href="'. $re[$i] .'" target="_blank"><img src="'. $re[$i] .'" style="height:100px;display:inline-block" /></a>': '';
                    }
                    showsetting(lang_sp($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp,'',0, $cmt);
                }
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_sp($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }elseif($index == 'spgg'){
                $re = unserialize($re);
                $tp = 'textarea';

                $ret = '';
                foreach ($re as  $item) {
                    $ret .= $item['name'].'=';
                    $retmp = array();
                    foreach ($item['ggtext'] as $itemm) {
                        $retmp[] = $itemm;
                    }
                    $ret .= implode(',', $retmp) . "\n";
                }
                $ret = trim($ret);
                showsetting(lang_sp($index.'desc', 0), "editform[$index]", $ret ? $ret :$res[$index] , $tp, '', 0, $cmt, $_extra);
            }elseif($index=='groupid'){
                $groups = $forums = array();
                foreach(C::t('common_usergroup')->range() as $group) {
                    $groups[] = array($group['groupid'], $group['grouptitle']);
                }
                $value = explode(',', $re);
                showsetting(cplang('setting_styles_global_allowfloatwin_usergroups'), array('editform[groupid][]', $groups), $value, 'mselect');
            }else{
                if($tp=='filetext'){
                    $cmt = $re ? '<a href="'. $re .'" target="_blank"><img src="'. $re .'" style="height:100px;display:inline-block" /></a>': '';
                }
                showsetting(lang_sp($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter(); /*Dism_taobao-com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['stat'] = intval($editform['stat']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach (array('crts', 'upts') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        $editform['groupid'] = implode(',', $editform['groupid']);
        $editform['jieshao'] = ($editform['jieshao']);
        $editform['append_text'] = array_slice($editform['append_text'], 0, count($editform['append_img']));

        foreach (array('album', 'append_text', 'append_img') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize(array_filter($editform[$item]));
        }

        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($editform['shid']);
        if(!$sh){
            cpmsg(lang_sp('shnotexists',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&secid=$secid", 'error');
        }


        $hy_ret = C::t('#xigua_sp#xigua_sp_hangye')-> fetch_by_name(array_filter(explode('#', trim($editform['hy']))));
        $hangye_ids = array_keys($hy_ret);

        $editform['shname']     = $sh['name'];
        $editform['shid']       = $sh['shid'];
        $editform['hy'] = str_replace('#', ' ', $editform['hy']);
        $editform['hangye_id1'] = $hangye_ids[0];
        $editform['hangye_id2'] = $hangye_ids[1];



        $srg = array();
        foreach ($editform['srange'] as $index => $item) {
            list($_rangt, $_rangd) = explode("#", $item);
            $srg[] = $_rangt;
        }
        $editform['srange']     = implode("\t", $srg);

        $srg = array();
        foreach ($editform['srange2'] as $index => $item) {
            $srg[] = trim($item);
        }
        $editform['srange2']     = implode("\t", $srg);

        if($secid>0){

            $old_data = C::t('#xigua_sp#xigua_sp_good')->fetch($secid);
            $old_data = C::t('#xigua_sp#xigua_sp_good')->prepare($old_data);

            $rs = C::t('#xigua_sp#xigua_sp_good')->update($secid, $editform);
            $gid = $secid;
        }else{
            $spgg = array();
            $spggtmp = array();
            foreach (explode("\n", trim($editform['spgg'])) as $index => $item) {
                list($name, $value) = explode("=", trim($item));
                $value = explode(',', trim($value));
                if($name&&$value){
                    $spgg[] = array(
                        'id' => $index,
                        'name' => $name,
                        'ggtext' => $value
                    );
                }
            }
            $editform['spgg'] = serialize($spgg);

            $gid = C::t('#xigua_sp#xigua_sp_good')->insert($editform, 1);
            if($spgg){
                DB::delete('xigua_sp_good_price', array('gid' => $gid));
                $price_list = $pow = array();
                $ggtest = $n = array();
                foreach ($spgg as $str => $item) {
                    $ggtest[] = $item['ggtext'];
                }
                $ggtest = combina($ggtest);
                foreach ($ggtest as $index => $item) {
                    $data = array();
                    $data = array(
                        'crts' => TIMESTAMP,
                        'upts' => TIMESTAMP,
                        'uid' => $item['uid']?$item['uid']:$sh['uid'],
                        'gid' => $gid
                    );
                    $data['price_pt'] = $editform['tprice'];
                    $data['price_dm'] = $editform['dprice'];
                    $data['price_hk'] = $editform['tprice'];
                    $data['price_sc'] = $editform['disprice'];
                    $data['price_cb'] = $editform['tprice'];
                    $data['price_jf'] = $editform['price_jf'];
                    $data['kami'] = trim($editform['kami']);
                    $data['stock']    = $editform['stock'];
                    $data['name']     = is_array($item) ? implode('###', $item) : $item;
                    C::t('#xigua_sp#xigua_sp_good_price')->update_price($data);
                }
            }
        }

        cpmsg(lang_sp('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&secid=$secid", 'succeed');
    }
}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_sp#xigua_sp_good')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_sp#xigua_sp_good')->update($id, array('displayorder' => $item['displayorder'], 'stat' => $item['stat']));
        }

        cpmsg(lang_sp('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey($keyword)) {
        $wherearr[] = " (title LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR append_text LIKE '%$keyword%' OR subtitle LIKE '%$keyword%') ";
    }
    if(isset($_GET['stat'])){
        $wherearr[] = 'stat=' . intval($_GET['stat']);
    }
    if($catid = intval($_GET['catid'])){
        $wherearr[] = '(hangye_id1=' . $catid.' or hangye_id2='. $catid.')';
    }

    $ob = ' displayorder DESC, id desc';

    echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_sp('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($statuss as $index => $_v) {
        echo '<label><input type="radio" name="stat" value="'.$index.'" ' . (isset($_GET['stat'])&&$_GET['stat']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }

    $listinfo = C::t('#xigua_sp#xigua_sp_hangye')->list_all(1);
    C::t('#xigua_sp#xigua_sp_hangye')->init($listinfo);
    $cat_list = C::t('#xigua_sp#xigua_sp_hangye')->get_tree_array(0);
    echo '&nbsp;&nbsp;&nbsp;';
    $check0 = $_GET['catid']?'':'selected';
    $csearch = '<b>'.lang_hb('cat',0).": </b>&nbsp;<select name=\"catid\">";
    $csearch .= "<option value=\"0\" $check0 >".lang_hb('quanbu',0)."</option>";
    foreach ($cat_list as $k => $v) {
        $check1 = $_GET['catid']==$v['id']?'selected':'';
        $csearch .= "<option value=\"$v[id]\" $check1 >$v[name]</option>";
        foreach ($v['sub'] as $kk => $vv) {
            $check2 = $_GET['catid']==$vv['id']?'selected':'';
            $csearch .= "<option value=\"$vv[id]\" $check2 >&nbsp;&nbsp;$vv[name]</option>";
        }
    }
    $csearch .= '</select>';
    echo $csearch;

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good".' class="btn" >'.cplang('reset').'</a> ';
//    echo " </div>";
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&secid=-1\" class=\"btn\">".lang_sp('tjsp',0)."</a></div>";
echo "<style>.abtn{padding:2px 6px;background:#FF5722;color:#fff;}</style>";
    showtableheader(lang_sp('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_sp('del', 0),
        lang_sp('displayorder', 0),
        lang_sp('thumb', 0),
        lang_sp('title', 0),
        lang_sp('author', 0),
        lang_sp('hsname', 0),
        lang_sp('spzt', 0),
        lang_sp('caozuo', 0),
        lang_sp('crendts', 0),
    ));


    $res = C::t('#xigua_sp#xigua_sp_good')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = C::t('#xigua_sp#xigua_sp_good')->fetch_count_by_page($wherearr);

    $shids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $shids[$v['shid']] = $v['shid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($shids){
        $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $shid = $v['shid'];
        $thumb = $v['fengmian'] ? $v['fengmian'] : ($v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0]);
        $stat = lang_sp('jxz',0);
        if($v['not_start']){
            $stat =lang_sp( 'wks',0);
        }elseif ($v['isend']){
            $stat = lang_sp('yjs',0);
        }
        if($v['stock']<=0){
            $stat = lang_sp('ysw',0);
        }


        $checked = $v['display'] ? 'checked' : '';

        $appeend = '';
        foreach ($v['append_img_ary'] as $__k => $__v) {
            $appeend .= "<p><img style='width:180px;display:block' src=\"{$__v}\" /></p>";
            $appeend .= "<p>" . nl2br($v['append_text_ary'][$__k]) . "</p>";
        }

        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $status_u = "<select name=\"row[$id][stat]\">";
        foreach ($statuss as $k => $vv) {
            if($v['stat']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input type='text' name='row[$id][displayorder]' value='{$v['displayorder']}' style='width:50px' />",
            "<img src='$thumb' style='width:70px;height:40px' />",
            "<p style='font-size:15px;color:#369'>{$v['title']}</p><p style='color:coral'>{$v['subtitle']}</p>",
            'UID: '.$v['uid'].' '.$users[$v['uid']]['username'],
            "<a target='_blank' href='".ADMINSCRIPT."?action=plugins&operation=config&do=&identifier=xigua_hs&pmod=admin_shanghu&shid=".$v['shid']."'>".$shinfos[$v['shid']]['name'].'</a>',


            $status_u,

            '<a class=\'abtn\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&formhash=".formhash()."&fzid=$id" . '">' . lang_sp('fuzhi', 0) . '</a> '.
            '<a class=\'abtn\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&secid=$id" . '">' . lang_sp('edit', 0) . '</a> '.
            '<a class=\'abtn\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&price_id=$id" . '">' . lang_sp('price_edit', 0) . '</a> '.
        '',
            $v['crts_u'],
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_sp&pmod=admin_good&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dism��taobao��com*/
    showformfooter(); /*Dism_taobao-com*/

    /*echo '<pre>';
    print_r($res);
    echo '</pre>';*/
}