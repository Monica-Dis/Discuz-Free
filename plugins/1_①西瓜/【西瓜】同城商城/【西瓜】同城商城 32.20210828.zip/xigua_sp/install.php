<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<HTML
CREATE TABLE IF NOT EXISTS `pre_xigua_sp_card` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(11) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `name2` varchar(80) NOT NULL,
 `group1` int(11) NOT NULL,
 `size` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `group1` (`group1`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_sp_good` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `crts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `shid` varchar(1000) NOT NULL,
 `title` varchar(80) NOT NULL,
 `subtitle` varchar(200) NOT NULL,
 `stat` int(11) NOT NULL COMMENT '1ok 2daishen 3xiajia',
 `usetime` int(11) NOT NULL,
 `shname` varchar(80) NOT NULL,
 `hy` varchar(200) NOT NULL,
 `hangye_id1` int(11) NOT NULL,
 `hangye_id2` int(11) NOT NULL,
 `stock` int(11) NOT NULL,
 `sellnum` int(11) NOT NULL,
 `fee_type` int(11) NOT NULL,
 `tprice` decimal(10,2) NOT NULL,
 `disprice` decimal(10,2) NOT NULL,
 `dprice` decimal(10,2) NOT NULL,
 `spgg` text NOT NULL,
 `status` int(11) NOT NULL,
 `srange` varchar(512) NOT NULL,
 `srange2` varchar(2000) NOT NULL,
 `newp` int(11) NOT NULL,
 `custom_zz` decimal(10,2) NOT NULL,
 `custom_ticheng` decimal(10,2) NOT NULL,
 `danci` int(11) NOT NULL,
 `zong` int(11) NOT NULL,
 `ptmin` int(11) NOT NULL,
 `ptshixian` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `jieshao` text NOT NULL,
 `append_img` text NOT NULL,
 `append_text` text NOT NULL,
 `album` text NOT NULL,
 `stid` int(11) NOT NULL,
 `jtt` varchar(2000) NOT NULL,
 `youhui` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`),
 KEY `stat` (`stat`),
 KEY `shid` (`shid`(255)),
 KEY `uid` (`uid`),
 KEY `title` (`title`),
 KEY `hangye_id1` (`hangye_id1`),
 KEY `hangye_id2` (`hangye_id2`),
 KEY `status` (`status`),
 KEY `dprice` (`dprice`),
 KEY `sellnum` (`sellnum`),
 KEY `crts` (`crts`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_sp_good_price` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `gid` int(11) NOT NULL,
 `name` varchar(200) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `stock` int(11) NOT NULL,
 `price_pt` decimal(10,2) NOT NULL,
 `price_dm` decimal(10,2) NOT NULL,
 `price_sc` decimal(10,2) NOT NULL,
 `sellnum` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `gid_2` (`gid`,`name`),
 KEY `displayorder` (`displayorder`),
 KEY `gid` (`gid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_sp_gwc` (
 `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(10) unsigned NOT NULL,
 `gid` int(11) NOT NULL,
 `price_id` int(11) unsigned NOT NULL,
 `num` int(11) NOT NULL DEFAULT '0',
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`price_id`),
 KEY `pid` (`uid`),
 KEY `shid` (`shid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_sp_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_sp_index` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(11) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_sp_order` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `crts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `order_id` varchar(200) NOT NULL,
 `buy_type` int(11) NOT NULL COMMENT '1dandu2pt',
 `tuan_id` int(11) NOT NULL COMMENT 'tuandan',
 `gnum` int(11) NOT NULL,
 `tuan_num` int(11) NOT NULL,
 `pay_money` decimal(10,2) NOT NULL,
 `addrid` int(11) NOT NULL,
 `addr` varchar(500) NOT NULL,
 `pay_ts` int(11) NOT NULL,
 `fa_ts` int(11) NOT NULL DEFAULT '-1',
 `shou_ts` int(11) DEFAULT '-1',
 `tui_ts` int(11) NOT NULL,
 `tuicfm_ts` int(11) NOT NULL,
 `gid` int(11) NOT NULL,
 `priceid` int(11) NOT NULL,
 `priceinfo` varchar(2000) NOT NULL,
 `goodinfo` text NOT NULL,
 `note` varchar(500) NOT NULL,
 `yunfee` decimal(10,2) NOT NULL,
 `title` varchar(200) NOT NULL,
 `pay_endts` int(11) NOT NULL,
 `mobile` varchar(200) NOT NULL,
 `realname` varchar(200) NOT NULL,
 `status` int(11) NOT NULL COMMENT '1waitpay 2pay_success  3canceling 4cancel_success  5pting  6pt_success 7pt_fail',
 `pt_success_ts` int(11) NOT NULL,
 `cmtid` int(11) NOT NULL DEFAULT '-1',
 `shid` int(11) NOT NULL,
 `unit_price` decimal(10,2) NOT NULL,
 `shixian` int(11) NOT NULL,
 `yundan` varchar(200) NOT NULL,
 `yundan_gs` varchar(200) NOT NULL,
 `upts` int(11) NOT NULL,
 `hxuid` int(11) NOT NULL,
 `hxcrts` int(11) NOT NULL,
 `hxnote` varchar(500) NOT NULL,
 `hxcode` varchar(20) NOT NULL,
 `refund` varchar(800) NOT NULL,
 `exp_method` varchar(20) NOT NULL,
 `pj_ts` int(11) NOT NULL DEFAULT '-1',
 PRIMARY KEY (`id`),
 KEY `tuan_id` (`tuan_id`),
 KEY `order_id` (`order_id`),
 KEY `pay_endts` (`pay_endts`),
 KEY `cmtid` (`cmtid`),
 KEY `shid` (`shid`),
 KEY `buy_type` (`buy_type`),
 KEY `crts` (`crts`),
 KEY `pay_ts` (`pay_ts`),
 KEY `fa_ts` (`fa_ts`),
 KEY `shou_ts` (`shou_ts`),
 KEY `gid` (`gid`),
 KEY `status` (`status`),
 KEY `shid_2` (`shid`),
 KEY `pj_ts` (`pj_ts`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_sp_refund` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `ptlogid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `danhao` varchar(200) NOT NULL,
 `gongsi` varchar(200) NOT NULL,
 `note` varchar(500) NOT NULL,
 `status` int(11) NOT NULL DEFAULT '-1' COMMENT '-1new2success',
 `order_status` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 `refund_info` varchar(2000) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `crts` (`crts`),
 KEY `odid` (`ptlogid`),
 KEY `shid` (`shid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_sp_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;
HTML;



runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/discuz_plugin_xigua_sp_TC_UTF8.xml');


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'kami\'', array('xigua_sp_good_price'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good_price` ADD `kami` TEXT NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'gid\'', array('xigua_hb_comment'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hb_comment` ADD `gid` int(11) NOT NULL;
ALTER TABLE `pre_xigua_hb_comment` ADD INDEX(`star`);
ALTER TABLE `pre_xigua_hb_comment` ADD INDEX(`gid`);

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'psfs_val\'', array('xigua_sp_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good` ADD `psfs_val` INT(11) NOT NULL DEFAULT 3;
ALTER TABLE `pre_xigua_sp_good` ADD `allow_tk` INT(11) NOT NULL DEFAULT '0';

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'refund_id\'', array('xigua_sp_order'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_order` ADD `refund_id` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_sp_order` ADD INDEX(`refund_id`);

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'baoyou_type\'', array('xigua_sp_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good` ADD `baoyou_type` INT(11) NOT NULL DEFAULT '0';
ALTER TABLE `pre_xigua_sp_good` ADD `baoyou_num` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'jaddr\'', array('xigua_sp_order'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_order` ADD `jaddr` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_sp_order` ADD `jname` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_sp_order` ADD `jmobile` VARCHAR(20) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'ziti\'', array('xigua_sp_order'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_order` ADD `ziti` VARCHAR(800) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'shou_confirm_ts\'', array('xigua_sp_order'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_order` ADD `shou_confirm_ts` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'price_hk\'', array('xigua_sp_good_price'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good_price` ADD `price_hk` DECIMAL(10,2) NOT NULL;
ALTER TABLE `pre_xigua_sp_good` ADD `hkprice` DECIMAL(10,2) NOT NULL AFTER `dprice`;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'custom_ticheng2\'', array('xigua_sp_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good` ADD `custom_ticheng2` DECIMAL(10,2) NOT NULL AFTER `custom_ticheng`;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'fengmian\'', array('xigua_sp_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good` ADD `fengmian` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'jifenrate\'', array('xigua_sp_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good` ADD `jifenrate` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'groupid\'', array('xigua_sp_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good` ADD `groupid` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'baoyou\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `baoyou` INT(11) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'chengben\'', array('xigua_sp_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good` ADD `chengben` DECIMAL(10,2) NOT NULL;

ALTER TABLE `pre_xigua_sp_order` ADD `chengben` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'price_cb\'', array('xigua_sp_good_price'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good_price` ADD `price_cb` DECIMAL(10,2) NOT NULL DEFAULT '0.00';

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'price_jf\'', array('xigua_sp_good_price'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good_price` ADD `price_jf` INT(10) NOT NULL DEFAULT '0';
ALTER TABLE `pre_xigua_sp_good_price` ADD `ggfm` VARCHAR(200) NOT NULL DEFAULT '';
ALTER TABLE `pre_xigua_sp_good` ADD `newjifenprice` INT(10) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hangye_ids\'', array('xigua_sp_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good` ADD `hangye_ids` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'maxzuhe\'', array('xigua_sp_good'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_sp_good` ADD `maxzuhe` DECIMAL(10,2) NOT NULL DEFAULT '0.00';

SQL;
    runquery($sql);
}


$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_sp/install.php');