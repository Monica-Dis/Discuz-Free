function compress(file, callback){
    var reader = new FileReader();
    reader.onload = function (e) {
        var image = $('<img/>');
        image.on('load', function () {
            var square = 640;
            var canvas = document.createElement('canvas');
            if (this.width > this.height) {
                canvas.width = Math.round(square * this.width / this.height);
                canvas.height = square;
            } else {
                canvas.height = Math.round(square * this.height / this.width);
                canvas.width = square;
            }
            var context = canvas.getContext('2d');
            context.clearRect(0, 0, square, square);
            var imageWidth = canvas.width;
            var imageHeight = canvas.height;
            var offsetX = 0;
            var offsetY = 0;
            context.drawImage(this, offsetX, offsetY, imageWidth, imageHeight);
            var data = canvas.toDataURL('image/jpeg', 0.8);
            console.log([imageWidth,imageHeight]);
            callback(data);
        });
        image.attr('src', e.target.result);
    };
    reader.readAsDataURL(file);
}

function setSpgg(id, obj) {
    var par = $(obj).parent();
    var tgo = par.find('.tag-on');
    if(tgo.length> 0){
        tgo.removeClass('tag-on');
        par.find('input').val('0');
    }
    if ($(obj).hasClass('tag-on')) {
        $(obj).removeClass('tag-on');
        $('input[name="form[tagid][' + id + ']"]').val('0');
    } else {
        $(obj).addClass('tag-on');
        $('input[name="form[tagid][' + id + ']"]').val(id);
    }
    if(id!==null){changePrice(id, obj);}
}

function changePrice(id, obj){
    var price_name = [];
    $('.gginput').each(function () {
        var that = $(this);
        if(that.val() != '0'){
            price_name.push(that.val());
        }
    });
    priceName = price_name.join('###');
    var show_price_name = YIXUAN+': '+price_name.join(',&nbsp;');
    console.log(price_name);
    if(PRICE_LIST){
        for(var i=0; i <PRICE_LIST.length; i++){
            if(PRICE_LIST[i].name == priceName){
                console.log(PRICE_LIST[i]);
                if(PRICE_LIST[i].stock<=0){
                    $(obj).removeClass('tag-on');
                    $('input[name="form[tagid][' + id + ']"]').val('0');
                    $.toast(KCBZ, "cancel");
                    return false;
                }
                var yixuan = show_price_name + '&nbsp;&nbsp;'+KC1+': '+PRICE_LIST[i].stock;
                $('#spggname').html(yixuan);
                $('#yixuan').html(price_name.join(',&nbsp;'));
                if(PRICE_LIST[i].price_jf>0){
                    $('#pricePt').html(PRICE_LIST[i].price_jf_str);
                    $('#priceDm').html(PRICE_LIST[i].price_jf_str);
                }else{
                    $('#pricePt').html(PRICE_LIST[i].price_pt);
                    $('#priceDm').html(PRICE_LIST[i].price_dm);
                }
                if(PRICE_LIST[i].ggfm){
                    $('#fm123 img').attr('src', PRICE_LIST[i].ggfm);
                }
                $('#price_id').val(PRICE_LIST[i].id);
            }
        }
    }
    return true;
}



function ptclock(){
    $('.hmt').each(function () {
        var that = $(this);
        pt_GetRunTime(that.data('start'),that.data('end'), that);
    });
}

function pt_GetRunTime( mallstart, mallend, itimer, step){
    var endtime= new Date(mallend.replace(/-/g,'/'));
    var starttime= new Date(mallstart.replace(/-/g,'/'));
    var keeptime = endtime - starttime;
    var nowtime = new Date();
    var t = endtime.getTime() - nowtime.getTime();
    var st = starttime.getTime()-nowtime.getTime();
    var tit = '';
    if(typeof noTit!=='undefined'){
        tit = '';
    }
    if(t<=0){
        itimer.html('<span class="timer">'+mallend+'</span>');
        return;
    }
    if(st>0){
        t = st;
    }
    tit = SHY+' ';
    var dd = t/1000;

    var d=Math.floor(dd/3600/24);
    var h=Math.floor(dd/3600%24);
    var m=Math.floor(dd/60%60);
    var s=Math.floor(dd%60);
    var o = '';
    if(h<10){h = '0'+h;}
    if(m<10){m = '0'+m;}
    if(s<10){s = '0'+s;}
    if(step ===10){
        o= Math.floor(t/10%100);
        if(o<10){o = '0'+o;}
        o = "<i>"+o+"</i>";
    }
    var width = t/keeptime*100;

    var ddis = '', hdis = '', mdis = '', sdis = '';
    if(d>0){
        ddis = '<i>'+d+'</i>' + ':'
    }
    hdis = '<i>'+h+'</i>' + ':';
    mdis = '<i>'+m+'</i>' + ':';
    sdis = '<i>'+s+'</i>';
    itimer.html(tit+'<span class="timer">'+ddis + hdis + mdis + sdis+o+'</span>');
    setTimeout(function(){
        pt_GetRunTime( mallstart, mallend, itimer, step);
    }, step||1000);
}

$(function () {
    $(document).on('click','.sp_good_od', function () {
        var that = $(this);
        var jmpurl = _APPNAME +'?id=xigua_sp&ac=order_profile&ptlog_id='+that.data('id')+(that.data('manage') ? '&manage=1':'')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        hb_jump(jmpurl);
    });

    var dolock = 0;
    $(document).on('click','.joingwc', function () {
        var that = $(this);
        var prcid= that.data('_price_id') ? that.data('_price_id') : $('#price_id').val();
        var gid= that.data('_gid') ? that.data('_gid') : $('input[name="gid"]').val();
        var num = that.data('_num') ? that.data('_num') : $('#item_num').val();
        if(dolock===1){
            return false;
        }
        dolock = 1;
        $.showLoading();
        $.ajax({
            type: 'POST',
            url: _APPNAME + '?id=xigua_sp&ac=gwc&do=in&inajax=1',
            data: {formhash: FORMHASH, 'price_id':prcid,'gid':gid, 'num': num },
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if (null == data) { return false; }
                var s = $.trim(data.lastChild.firstChild.nodeValue);
                tip_common(s);
                dolock = 0;
            },error:function () {
                $.hideLoading();
                dolock = 0;
            }
        });
    });

    $(document).on('click', '.jump_sp', function () {
        var that = $(this);
        var jmpurl = _APPNAME +'?id=xigua_sp&ac=view&gid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        hb_jump(jmpurl);
        return false;
    });

    $(document).on('click','.nowbuy', function () {
        var that = $(this);
        $('#buy_type').val(that.data('type'));

        if(that.data('needconfirm')){
            $('#quedbox').hide();$('#gwcbox').show();
        }else{
            $('#quedbox').show();$('#gwcbox').hide();
        }
        if(that.data('gwc')){
            $('.qd1').hide();$('.qd2').show();
        }else{
            $('.qd1').show();$('.qd2').hide();
        }
        console.log(that.data('gwc'));

        $('#pricePt').hide();
        $('#priceDm').show();
        $('#weuiAgree').hide();
        $('#popup_item').popup();
    });

    $(document).on('click','.payaddress', function () {
        hb_setcookie('seckill_wait', window.location.href, 1200);
        window.location.href = _APPNAME+'?id=xigua_hb&ac=myaddr'+_URLEXT;
    });

    $(document).on('click','.inc-num', function () {
        var that = $(this);
        var ipt = that.parent().find('.inc-input');
        var num = parseInt(ipt.val());
        if(parseInt(that.data('step'))===1){
            if (!ipt.data('max') || num <ipt.data('max')) {
                ipt.val(++num);
            }
        }else{
            if (num > 1) {
                ipt.val(--num);
            }
        }
        if(typeof incNumCallback !=='undefined'){
            incNumCallback(ipt);
        }
    });


    $(document).on('click','.ajax_cat', function () {
        var that = $(this);
        page = 1;lm=0;
        history.pushState({}, '', window.location.href.replace(/catid=\d+/, 'catid='+that.data('id')));
        loadingurl = window.location.href+'&ac=cat_li&inajax=1&catid='+that.data('id')+'&page=';
        if(that.data('loadingurl')){
            loadingurl = that.data('loadingurl');
        }
        that.addClass('ajax_cat_cur').siblings().removeClass('ajax_cat_cur');
        DOAPPEND = 0;
        $.ajax({
            type: 'get',
            url: loadingurl+''+page,
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $('#loading-show').addClass('hidden');
                if(!s){
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                    setTimeout(function () {
                        $('#loading-show').addClass('hidden');
                        $('#loading-none').removeClass('hidden');
                    }, 300);
                    $("#list").html(s);
                    page = -1;
                    return ;
                }
                $("#list").html(s);
                page ++;
            },
            error: function() {
            }
        });
    });

    ptclock();

    $(document).on('click','.cate_item', function () {
        var that = $(this);
        hb_jump(_APPNAME+'?id=xigua_sp&ac=cat&subid='+that.data('id')+'&catid='+that.data('pid')+(typeof _URLEXT!=='undefined'? _URLEXT : ''));
    });

    $(document).on('click','#dosearch', function () {
        if($('#searchInput').val()){
            $('#dosearchform').submit();
        }else{
            $.alert($('#searchInput').data('hold'));
        }
    });

    $(document).on('click','.cancel_order', function () {
        var that = $(this);
        $.confirm(QDYX, function () {
            $.showLoading();
            $.ajax({
                type: "POST",
                url: _APPNAME+"?id=xigua_sp&ac=cancel_order&inajax=1&ordid="+that.data('id'),
                data:{formhash:FORMHASH},
                dataType: "xml",
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                }
            });
        }, function () {
        });
    });

    $(document).on('click','.sxj', function () {
        var that = $(this);
        var gid = that.data('gid');
        $.modal({
            title: that.data('title'),
            text: that.data('text'),
            buttons: [
                { text: SHANGJIA, onClick: function(){
                        $.showLoading();
                        $.ajax({
                            type: "POST",
                            url: _APPNAME+"?id=xigua_sp&ac=com&do=sxj&stat=1&inajax=1&gid="+gid,
                            async: false,
                            dataType: "xml",
                            success: function (data) {
                                $.hideLoading();
                                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                var s = data.lastChild.firstChild.nodeValue;
                                tip_common(s);
                            }
                        });
                    } },
                { text: XIAJIA, onClick: function(){

                        $.showLoading();
                        $.ajax({
                            type: "POST",
                            url: _APPNAME+"?id=xigua_sp&ac=com&do=sxj&stat=3&inajax=1&gid="+gid,
                            async: false,
                            dataType: "xml",
                            success: function (data) {
                                $.hideLoading();
                                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                var s = data.lastChild.firstChild.nodeValue;
                                tip_common(s);
                            }
                        });

                    } },
                { text: QXQX, className: "default", onClick: function(){ console.log(3)} },
            ]
        });
    });

    $(document).on('click','.fahuo', function () {
        var that = $(this);

        $.prompt({
            title: that.data('title'),
            empty: false,
            onOK: function (input) {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME+'?id=xigua_sp&ac=com&do=fahuo&inajax=1',
                    data:{formhash:FORMHASH, yundan_gs : input, yundan:$('#actfield').val(), ptlogid:that.data('id')},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });

        $('#weui-prompt-input').replaceWith('<input class="weui-prompt-input needsclick weui-input needsclick_input" type="text" id="weui-prompt-input" placeholder="'+KDGS+'" />');
        setTimeout(function(){
            $('.weui-dialog__bd').after('<div class="dialog_custom"><div><input id="actfield" class="weui-input needsclick_input" type="text" placeholder="'+KDDH+'"></div></div>');
        }, 150);
        document.getElementById('weui-prompt-input').focus();
    });

    var qrshlock = 0;
    $(document).on('click','.qrsh', function () {
        var that = $(this);
        $.confirm(that.data('title'), function () {
            $.showLoading();
            console.log(qrshlock);
            if(qrshlock===1){
                return;
            }
            qrshlock =1;
            $.ajax({
                type: 'post',
                url: _APPNAME+'?id=xigua_sp&ac=com&do=shouhuo&inajax=1',
                data:{formhash:FORMHASH,  ptlogid:that.data('id')},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                    qrshlock = 0;
                },
                error: function () {
                    $.hideLoading();
                    qrshlock = 0;
                }
            });
        }, function () {
        });
    });

    $(document).on('click','.tuan_more', function () {
        var that = $(this);
        var gid = that.data('gid');

        var text = $('#tuan_more');
        $.ajax({
            type: "POST",
            url: _APPNAME+"?id=xigua_sp&ac=com&do=tuans&inajax=1&gid="+gid,
            async: false,
            dataType: "xml",
            success: function (data) {
                if(null==data){ return false;}
                s = data.lastChild.firstChild.nodeValue;
            }
        });
        text.find('.weui-cells').html(s);
        $.alert(text.html(), that.data('title'));
        ptclock();
    });

    $(document).on('click','.commentto', function () {
        var that = $(this);
        PLZINPUT = HIKEFU;
        do_comment(0, that.data('uid'), LXKF, 1);
        $('#c_icon_'+that.data('id')).trigger('click');
        return false;
    });

    $(document).on('click', '#v_openLocation', function () {
        var that = $(this);
        if((HB_INWECHAT&&HS_MULTIUPLOAD)==1){
            wx.openLocation({
                latitude: that.data('lat'),
                longitude: that.data('lng'),
                name: that.data('name'),
                address: that.data('addr'),
                scale: 14,
                infoUrl:window.location.href
            });
        }else if(GOOGLE){
            window.location.href = _APPNAME+'?id=xigua_hs&ac=googleMap&lat='+that.data('lat')+"&lng="+that.data('lng');
        }else{
            window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:"+that.data('lat')+","+that.data('lng')+";title:"+that.data('name')+";addr:"+that.data('addr');
        }
        return false;
    });

    $(document).on('click','.use-btn', function () {
        var that = $(this);
        var _id = that.data('id');
        if(that.data('src')){
            $.alert("<img style='width:180px' src='"+that.data('src')+"' /><br>"+that.data('tip'), that.data('chushi'),function() {
            });
            return false;
        }
    });


    $(document).on('click', '.dospcomment', function () {
        var that = $(this);
        $('#comment_popup').popup();
        return false;
    });
    $(document).on('click', '.commentsptijiao', function () {
        var that = $(this), cmtpic='', cmtmsg = $('#comment_content').val();

        $('input[name="comment_photo[]"]').each(function(){
            cmtpic += ','+$(this).val();
        });
        $('input[name="form[album][]"]').each(function(){
            cmtpic += ','+$(this).val();
        });
        $.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME +'?id=xigua_sp&ac=comment&do=comment&gid='+that.data('id')+'&shid='+that.data('shid')+'&star='+$('#sliderValue').text()+'&inajax=1&order_id='+that.data('order_id'),
            data: {'formhash':FORMHASH, comment:cmtmsg, cmtphoto:cmtpic},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {
                $.hideLoading();
            }
        });
        return false;
    });
    getgwcnu();

    $(document).on('click','.delgwc', function () {
        var that = $(this);
        if(dolock===1){
            return false;
        }
        dolock = 1;
        $.showLoading();
        $.ajax({
            type: 'POST',
            url: _APPNAME + '?id=xigua_sp&ac=gwc&do=del&inajax=1',
            data: {formhash: FORMHASH, 'gwid':that.data('id') },
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if (null == data) { return false; }
                var s = $.trim(data.lastChild.firstChild.nodeValue);
                tip_common(s);
                dolock = 0;
            },error:function () {
                $.hideLoading();
                dolock = 0;
            }
        });
    });

    var loadingLock = 0;
    $(document).on('click','.shopsort', function () {
        if(loadingLock===1){
            return false;
        }
        loadingLock = 1;
        var that = $(this);
        page = 1;
        var dext = that.data('ext');
        if(that.hasClass('shop_mod_sortbar')){
            if(that.hasClass('up')){
                that.removeClass('up');dext = 'sort=dprice';
            }else{
                that.addClass('up');dext = 'sort=dpriceasc';
            }
        }
        loadingurl = window.location.href+'&ac=cat_li&inajax=1&'+dext+'&page=';
        if(that.data('loadingurl')){
            loadingurl = that.data('loadingurl');
        }
        that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
        DOAPPEND = 0;
        $.ajax({
            type: 'get',
            url: loadingurl+''+page,
            dataType: 'xml',
            success: function (data) {
                loadingLock = 0;
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $('#loading-show').addClass('hidden');
                if(!s){
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                    setTimeout(function () {
                        $('#loading-show').addClass('hidden');
                        $('#loading-none').removeClass('hidden');
                    }, 300);
                    $("#list").html(s);
                    page = -1;
                    return ;
                }
                $("#list").html(s);
                if(typeof loadingCallback !=='undefined'){
                    loadingCallback();
                }
                page ++;
            },
            error: function() {
                loadingLock = 0;
            }
        });
    });
    $(document).on('click','.changestyle', function () {
        var that = $(this);
        if(that.find('.icon-gengduo3').length<=0){
            that.html('<i class="iconfont icon-gengduo3"></i>');
            $('#list').addClass('good_2');
        }else{
            that.html('<i class="iconfont icon-liebiao"></i>');
            $('#list').removeClass('good_2');
        }
    });


    $(document).on('click','.do_follow', function () {
        var that = $(this);
        $.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME +'?id=xigua_hs&ac=follow&do=do_follow&shid='+that.data('id')+'&inajax=1',
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.split('|')[1]=='1'){
                    that.html(yiguanzhu).addClass('weui-btn_disabled');
                    if(IN_WECHAT){
                        $.alert("<img src='"+that.data('qr')+"' />"+gengduodongtai, guanzhu_sj);
                    }
                }else{
                    tip_common(s);
                    that.html(jiaguanzhu).removeClass('weui-btn_disabled');
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    });

    $(document).on('click', '.sh_jump', function () {
        var that = $(this);
        var jmpurl = _APPNAME + '?id=xigua_hs&ac=view&shid=' + that.data('id') + (typeof _URLEXT !== 'undefined' ? _URLEXT : '');
        hb_jump(jmpurl);
    });

    $(document).on('click','.dotuikuan', function () {
        var that = $(this);
        var ptlogid = that.data('ptlogid');
        console.log(ptlogid);
        $.prompt({
            title:qrtk_,
            text: qrtk_desc_,
            empty: false,
            onOK: function (input) {
                console.log(input);$.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME+'?id=xigua_sp&ac=tuihuo&inajax=1',
                    data: {'formhash':FORMHASH, 'input':input, 'ptlogid' : ptlogid},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if (null == data) {
                            tip_common('error|' + ERROR_TIP);
                            return false;
                        }
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {$.hideLoading();}
                });
            },
            onCancel: function () {
            }
        });
    });

    $(document).on('click','.canceltuikuan', function () {
        var that = $(this);
        var ptlogid = that.data('ptlogid');
        $.confirm(qrqxtk_, function () {$.showLoading();
            $.ajax({
                type: 'post',
                url: _APPNAME+'?id=xigua_sp&ac=tuihuo&do=backrefund&inajax=1',
                data: {'formhash':FORMHASH, 'ptlogid' : ptlogid},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if (null == data) {
                        tip_common('error|' + ERROR_TIP);
                        return false;
                    }
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {$.hideLoading();}
            });
        }, function () {});
    });

    $(document).on('click','.dotk', function () {
        var that = $(this);
        var redund = that.data('redund');
        $.showLoading();
        $.ajax({
            type: 'GET', url: _APPNAME+'?id=xigua_sp&ac=tuihuo&do=getrefund&inajax=1', data: {'refund_id':redund}, dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if (null == data) {tip_common('error|' + ERROR_TIP);return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $.modal({
                    title:cltk_,
                    text: s.split('|')[1],
                    buttons: [
                        { text:tytk_, onClick: function(){$.showLoading();
                        $.ajax({
                            type: 'post',
                            url: _APPNAME+'?id=xigua_sp&ac=tuihuo&do=confirmtk&inajax=1',
                            data: {'formhash':FORMHASH, 'redund_id' : redund},
                            dataType: 'xml',
                            success: function (data) {
                                $.hideLoading();
                                if (null == data) {
                                    tip_common('error|' + ERROR_TIP);
                                    return false;
                                }
                                var s = data.lastChild.firstChild.nodeValue;
                                tip_common(s);
                            },
                            error: function () {$.hideLoading();}
                        });
                        }},
                        { text:qx_, className: "default", onClick: function(){} },
                    ]
                });
            },
            error: function () {$.hideLoading();}
        });
    });
});

var pge = 1;
function comment_do_profile (spid) {
    lst = $('#clist');
    var cloadingurl = _APPNAME+'?id=xigua_sp&ac=comment&gid='+spid+'&inajax=1&pagesize=10&page=';
    DOAPPEND = 0;
    $.ajax({
        type: 'post',
        url: cloadingurl+''+pge,
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('#loading-show').addClass('hidden');
            if(!s){
                $('#loading-show').addClass('hidden');
                $('#loading-none').removeClass('hidden');
                setTimeout(function () {
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                }, 300);
                $('.weui-media-box__desc').html(zanwupingjia);
                return ;
            }else{
                $('#comment_ul_more').show();
            }
            lst.append(s);
            pge ++;
            lm = false;
        },
        error: function() {
            lm = false;
            $.hideLoading();
        }
    });
    return false;
}
var pt_toutiao_timeout;
function pt_noti_toutiao(text, duration, index) {
    if(!text){
        return ;
    }
    var $t = $('.noti');
    $t.html(text);

    clearTimeout(pt_toutiao_timeout);

    if(!$t.hasClass('noti_visible')) {
        $t.addClass('noti_visible');
    }

    pt_toutiao_timeout = setTimeout(function() {
        $t.removeClass('noti_visible').transitionEnd(function() {
            pt_noti_toutiao(PT_TOUTIAOS[index+1], duration, index+1);
        });
    }, duration);
}
if(typeof PT_TOUTIAOS !== 'undefined'){
    if(PT_TOUTIAOS){
        pt_noti_toutiao(PT_TOUTIAOS[0], 3000, 0);
    }
}

function gwcsucc(nu) {
    $.closePopup('#popup_item');
    getgwcnu();
}

function getgwcnu(){
    var gwcnm = $("#gwcnum");
    if(gwcnm.length>0){
        gwcnm.hide();
        $.ajax({
            type: 'get',
            url: _APPNAME + '?id=xigua_sp&ac=gwc&do=check&inajax=1',
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s>0){
                    gwcnm.html(s).show();
                }
            },
            error: function() {}
        });
    }
}