<?php

function get_print_status( $app_id, $app_secret, $device_id, $device_secret, $id){

    require_once __DIR__."/../vendor/autoload.php";


    $rpc = new \zhongwu\protocol\RpcClient($app_id, $app_secret, 'http://api.zhongwuyun.com');

    $Zprinter = new \zhongwu\Printer($rpc);



    try {

        $rs = $Zprinter->set_args($device_id, $device_secret)->get_print_status($id);

        $rs = (array)$rs;
        $rs['retData'] = (array)$rs['retData'];
        return $rs['retData']['status'];
    } catch (Exception $e) {
        return $e->getMessage();

    }
}