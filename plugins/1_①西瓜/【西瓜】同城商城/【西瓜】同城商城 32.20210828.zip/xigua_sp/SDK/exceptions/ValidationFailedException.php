<?php

namespace zhongwu\exceptions;


class ValidationFailedException extends ServiceException
{

}