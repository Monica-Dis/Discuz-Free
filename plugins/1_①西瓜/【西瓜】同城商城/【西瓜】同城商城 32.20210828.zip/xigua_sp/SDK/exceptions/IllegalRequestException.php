<?php

namespace zhongwu\exceptions;

class IllegalRequestException extends ServiceException
{

}