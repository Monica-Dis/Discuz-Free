<?php

namespace zhongwu\exceptions;

class ExceedLimitException extends ServiceException
{

}