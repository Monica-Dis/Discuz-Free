<?php

namespace zhongwu;

use RuntimeException;

class ServerErrorException extends RuntimeException
{

}