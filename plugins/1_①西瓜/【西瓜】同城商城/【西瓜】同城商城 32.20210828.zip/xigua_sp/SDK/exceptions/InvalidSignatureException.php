<?php

namespace zhongwu\exceptions;

use Exception;

class InvalidSignatureException extends Exception
{

}