<?php

namespace zhongwu\exceptions;

use Exception;

class InvalidTimestampException extends Exception
{

}