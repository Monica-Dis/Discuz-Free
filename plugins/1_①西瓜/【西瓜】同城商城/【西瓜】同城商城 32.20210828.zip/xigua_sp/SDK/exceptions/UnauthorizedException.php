<?php

namespace zhongwu\exceptions;


class UnauthorizedException extends ServiceException
{

}