<?php

namespace zhongwu\exceptions;

class PermissionDeniedException extends ServiceException
{

}