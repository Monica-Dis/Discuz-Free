<?php

namespace zhongwu\exceptions;

use Exception;

class BusinessException extends Exception
{

}