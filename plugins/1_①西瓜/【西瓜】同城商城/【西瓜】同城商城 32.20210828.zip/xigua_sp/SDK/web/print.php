<?php
/*开发者ID（appid）：	8000418
开发者密钥（appsecret）:d8dab4b725e414109f02df134908814b
设备编号（deviceid）:12380626
设备秘钥（devicesecret）:829k186k*/
function print_piao($app_id, $app_secret, $device_id, $device_secret, $printdata){
    require_once __DIR__ . "/../vendor/autoload.php";
    if(!$printdata){
        return false;
    }

    /*$_POST['appid'] = '8000418';
    $_POST['appsecret'] = 'd8dab4b725e414109f02df134908814b';
    $_POST['device_id'] = '12380626';
    $_POST['device_secret'] = '829k186k';
    $_POST['printdata'] = '<MS>3</MS><S2><C> 百度外卖 </C></S2>................................<S2><C>----在线支付----</C></S2><S1><C>test_89176_63080</C></S1>下单时间:09月06日11时19分<RN>订单编号:15362039995244<RN>**************商品**************<C>---1号口袋---</C><H2><TR><TD>api测试商品_9</TD><TD>×1</TD><TD>9.90</TD></TR><TR><TD>api测试商品_7</TD><TD>×1</TD><TD>9.90</TD></TR><TR><TD>蒸鸡蛋</TD><TD>×1</TD><TD>21.00</TD></TR></H2>********************************<H2>配送费:6.00<RN></H2><RN>********************************<H2>订单总价:￥46.80<RN></H2><S2>腾讯北京总部大楼 海淀区西二旗大街</S2><RN><S2>李(先生)<RN>177-5510-5793</S2><RN><H2><S2>备注：[未选择餐具数量]；</S2></H2>';

    $app_id = $_POST['appid'];
    $app_secret = $_POST['appsecret'];
    $device_id = $_POST['device_id'];
    $device_secret = $_POST['device_secret'];*/

    $rpc = new \zhongwu\protocol\RpcClient($app_id, $app_secret, 'http://api.zhongwuyun.com');
    $Zprinter = new \zhongwu\Printer($rpc);

    try {
        $r = ($Zprinter->set_args($device_id, $device_secret)->cloud_print($printdata));
        $r = (array)$r;
        $r['retData'] = (array)$r['retData'];
        return $r['retData'];
    } catch (Exception $e) {
        return $e->getMessage();
    }
}