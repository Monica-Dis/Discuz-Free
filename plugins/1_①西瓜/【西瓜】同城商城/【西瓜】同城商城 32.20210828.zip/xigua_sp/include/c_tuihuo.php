<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/10
 * Time: 19:07
 */


if($_GET['do']=='backrefund') {
    if(submitcheck('formhash')) {
        $ptlogid = intval($_GET['ptlogid']);
        $order = C::t('#xigua_sp#xigua_sp_order')->fetch($ptlogid);
        $refund_log = C::t('#xigua_sp#xigua_sp_refund')->fetch_by_ptlogid($ptlogid);

        C::t('#xigua_sp#xigua_sp_order')->update($ptlogid, array('status' => $refund_log['order_status'], 'refund_id' => 0));

        hb_message(lang_sp('qxtkcg',0), 'success', 'reload');
    }

}else if($_GET['do']=='confirmtk'){
    if(submitcheck('formhash')){
        $rid = intval($_GET['redund_id']);
        if (discuz_process::islocked('xiguasptk'.$_G['uid'].'_'.$rid, 10)) {
            hb_message(lang_sp('czpf',0), 'error');
        }
        $rv = C::t('#xigua_sp#xigua_sp_refund')->fetch_by_id($rid);
        $v = C::t('#xigua_sp#xigua_sp_order')->fetch($rv['ptlogid']);

        $canback = 0;
        if(in_array($rv['shid'], sp_get_shids_by_uid()) || IS_ADMINID){

            $hborder = C::t('#xigua_hb#xigua_hb_order')->fetch($v['order_id']);
            if($hborder['fromopenid']){

                $out_trade_no = $v['order_id'];
                $total_fee = intval($v['pay_money']*100);
                $refund_fee = $total_fee;
                $tkprofile = '<br>'.lang('plugin/xigua_sp', 'tkje').floatval($refund_fee/100).'<br>'.lang('plugin/xigua_sp', 'zfje').floatval($total_fee/100);

                try{
                    $input = new WxPayRefundSF();
                    $input->SetOut_trade_no($out_trade_no);
                    $input->SetTotal_fee($total_fee);
                    $input->SetRefund_fee($refund_fee);
                    $refund_order = substr(md5($out_trade_no), 0,8).date("YmdHis");
                    $input->SetOut_refund_no($refund_order);
                    $input->SetOp_user_id(WxPayConfigSF::MCHID);

                    $rett = WxPayApiSF::refund($input, 10);
                    $ret1 = diconv(var_export($rett, 1), 'UTF-8', CHARSET);
                    $ret2 = lang('plugin/xigua_sp', 'tkxq').lang('plugin/xigua_sp', $rett['return_code']).diconv($rett['return_msg'],'UTF-8', CHARSET);
                    if($rett["return_code"] == "SUCCESS" && $rett["result_code"] == "SUCCESS"){
                        C::t('#xigua_sp#xigua_sp_refund')->update($rid, array('upts' => TIMESTAMP, 'status' => 2));
                        C::t('#xigua_sp#xigua_sp_order')->update($rv['ptlogid'], array('status' => 4,'refund' => lang('plugin/xigua_sp', 'dh').$refund_order.'<br>'.$ret1,));

                        notification_add($v['uid'],'system', lang_sp('tksq_tip2', 0),array(
                            'url' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id={$rv['ptlogid']}$urlext",
                        ),1);
                        if($_G['cache']['plugin']['xigua_hh']) {
                            DB::query("DELETE FROM " . DB::table('xigua_hh_income') . " WHERE info LIKE '%{$v['order_id']}%' and reach<>1 LIMIT 2");
                        }
                        if($v['shou_ts']>0 && $v['shou_confirm_ts']>0){
                            $shid = $v['shid'];
                            include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
                            $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                            $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                            $insxf   = intval(abs($vipinfo['insxf']))/100;
                            if($shdata['shinsxf']){
                                $insxf  = intval(abs($shdata['shinsxf']))/100;
                            }

                            $sxfee = round($insxf*$v['pay_money'], 2);
                            $money = $v['pay_money']-$sxfee;

                            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', -$money);
                            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                                'uid'  => $shdata['uid'],
                                'crts' => TIMESTAMP,
                                'size' => -$money,
                                'note' => lang_sp('tkcg',0).$v['order_id'],
                                'link' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
                            ));
                        }
                        hb_message(lang_sp('tkcg',0), 'success', 'reload');
                    }else{
//                        hb_message($ret2, 'error');
                        $canback = 1;
                    }
                }catch (Exception $e){
                    hb_message(lang('plugin/xigua_sp', 'tkxq').diconv($e->getMessage(), 'UTF-8', CHARSET), 'error');
                }
            }else{
                $canback = 1;
            }
        }else{
            hb_message('ERROR!', 'error');
        }
        if($v['exp_method']=='hdfk'){
            $canback = 0;
        }
        if($canback){
            C::t('#xigua_sp#xigua_sp_refund')->update($rid, array('upts' => TIMESTAMP, 'status' => 2));
            C::t('#xigua_sp#xigua_sp_order')->update($rv['ptlogid'], array('status' => 4,'refund' => '',));

            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                'uid' => $v['uid'],
                'crts' => TIMESTAMP,
                'size' => $v['pay_money'],
                'note' => lang_sp('tkcg',0),
                'link' => "",
            ));
            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['uid'], 'money', $v['pay_money']);
            if($_G['cache']['plugin']['xigua_hh']) {
                DB::query("DELETE FROM " . DB::table('xigua_hh_income') . " WHERE info LIKE '%{$v['order_id']}%' and reach<>1 LIMIT 2");
            }

            if($v['shou_ts']>0 && $v['shou_confirm_ts']>0){
                $shid = $v['shid'];
                include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
                $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                $insxf   = intval(abs($vipinfo['insxf']))/100;
                if($shdata['shinsxf']){
                    $insxf  = intval(abs($shdata['shinsxf']))/100;
                }

                $sxfee = round($insxf*$v['pay_money'], 2);
                $money = $v['pay_money']-$sxfee;

                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', -$money);
                C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                    'uid'  => $shdata['uid'],
                    'crts' => TIMESTAMP,
                    'size' => -$money,
                    'note' => lang_sp('tkcg',0).$v['order_id'],
                    'link' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
                ));
            }

            notification_add($v['uid'],'system', lang_sp('tksq_tip3', 0),array(
                'url' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id={$rv['ptlogid']}$urlext",
            ),1);
            if($_G['cache']['plugin']['xigua_st']){
                $log = DB::fetch_first('select * from %t where orderid=%s', array('xigua_st_income', $v['order_id']));
                if($log['money']>0){
                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($log['uid'], 'money', -$log['money']);
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid'  => $log['uid'],
                        'crts' => TIMESTAMP,
                        'size' => $log['money'],
                        'note' => lang_sp('tkcg',0).', :'.lang_sp('orderid',0).$v['order_id'].' '.$v['title'],
                        'link' => "$SCRITPTNAME?id=xigua_hb&ac=member&uid={$log['uid']}$urlext",
                    ));
                }
            }
            hb_message(lang_sp('tkcg',0), 'success', 'reload');
        }
    }
}else if($_GET['do']=='getrefund'){
    $rid = $_GET['refund_id'];
    $tkyy = lang_sp('tkyy',0);
    $sqsj = lang_sp('sqsj',0);

    $r = C::t('#xigua_sp#xigua_sp_refund')->fetch_by_id($rid);
    $order = C::t('#xigua_sp#xigua_sp_order')->fetch($r['ptlogid']);

    if($order['yundan']){
        $p = '<p>'.lang_sp('khysh',0).'</p>';
    }

    $ret = <<<HTML
<p>$tkyy: {$r[note]}</p>
<p>$sqsj: {$r[crts_u]}</p>$p
HTML;
    hb_message($ret, 'success');
}else{

    if(submitcheck('formhash')){
        $ptlogid = intval($_GET['ptlogid']);
        $order = C::t('#xigua_sp#xigua_sp_order')->fetch($ptlogid);
        $order = C::t('#xigua_sp#xigua_sp_order')->prepare($order);
        if(!$order['allowtk']){
            hb_message(lang_sp('qqrshhztk',0), 'error');
        }

        $rid = C::t('#xigua_sp#xigua_sp_refund')->insert(array(
            'ptlogid' => $ptlogid,
            'crts' => TIMESTAMP,
            'uid' => $_G['uid'],
            'danhao' => '',
            'gongsi' => '',
            'note' => $_GET['input'],
            'status' => '-1',
            'order_status' => $order['status'],
        ), 1);

        C::t('#xigua_sp#xigua_sp_order')->update($ptlogid, array('status' => 3, 'refund_id' => $rid));

        $shinfo = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($order['shid']);

        notification_add($shinfo['uid'],'system', lang_sp('tksq_tip', 0),array(
            'url' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id=$ptlogid$urlext",
            'username'=>$_G['username']
        ),1);
        /*$shuids2 = DB::fetch_all('select uid from %t WHERE shid=%d', array('xigua_hs_yuan', $order['shid']),'uid');
        $shuids2 = array_keys($shuids2);
        foreach ($shuids2 as $item) {
            if($item!=$shinfo['uid']){
                notification_add($item,'system', lang_sp('tksq_tip', 0),array(
                    'url' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id=$ptlogid$urlext",
                    'username'=>$_G['username']
                ),1);
            }
        }*/

        hb_message(lang_sp('sqcg',0), 'success', 'reload');
    }
}