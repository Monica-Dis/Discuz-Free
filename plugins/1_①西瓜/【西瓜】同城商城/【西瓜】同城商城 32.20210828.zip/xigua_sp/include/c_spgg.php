<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/4/22
 * Time: 0:25
 */
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$field_price = array(
    'stock' => lang_sp('kc1',0),
    'price_dm' => lang_sp('price_dm',0),
    'price_hk' => lang_sp('price_hk',0),
    'price_sc' => lang_sp('price_sc',0),
);
if($_G['cache']['plugin']['xigua_hk']){
    $field_price['price_sc'] = lang_sp('price_sc',0);
}

if(!$_G['uid']){
    hb_jump_login();
}
$navtitle = lang_sp('spgg',0);
if($gid = intval($_GET['gid'])){
    $old_data = C::t('#xigua_sp#xigua_sp_good')->fetch_G($gid);
    if(!$old_data){
        dheader("Location: $SCRITPTNAME?id=xigua_sp&ac=manage$urlext");
    }
}

if(submitcheck('formhash')){
    if(isset($_GET['delete'])){
        $spgg = $old_data['spgg_ary'];
        unset($spgg[intval($_GET['delete'])]);
        $spgg = array_values($spgg);
        if(C::t('#xigua_sp#xigua_sp_good')->update_G($gid, array('spgg' => serialize($spgg)))){
            hb_message(lang_sp('sccg',0), 'success', 'reload');
        }
    }elseif($_GET['spjg']){
        $form  = $_GET['form'];
        $names = array();
        foreach ($form as $index => $item) {
            $names[] = $item['stock']['k'];
        }
        if($names){
            DB::query("DELETE FROM %t WHERE gid=%d AND `name` NOT IN (%n)", array('xigua_sp_good_price', $gid, $names));
        }
        foreach ($form as $index => $item) {
            $data = array();
            $data = array(
                'crts' => TIMESTAMP,
                'upts' => TIMESTAMP,
                'uid' => $_G['uid'],
                'gid' => $gid
            );
            $data['price_pt'] = $item['price_pt']['v'];
            $data['price_dm'] = $item['price_dm']['v'];
            $data['price_hk'] = $item['price_hk']['v'];
            $data['price_sc'] = $item['price_sc']['v'];
            $data['stock']    = $item['stock']['v'];
            $data['name']     = $item['stock']['k'];
            C::t('#xigua_sp#xigua_sp_good_price')->update_price($data);
        }
        hb_message(lang_sp('bccg',0), 'success', "reload");
    }else{
        $form = $_GET['form'];
        foreach ($form['ggtext'] as $index => $item) {
            $form['ggtext'][$index] = trim($item);
        }
        if(!$form['name']){
            hb_message(lang_sp('ggmbnwk',0), 'error');
        }
        if(!$form['ggtext']){
            hb_message(lang_sp('qtjggx',0), 'error');
        }

        foreach ($form['ggtext'] as $index => $item) {
            if(!$item){
                hb_message(lang_sp('qtxxmm',0), 'error');
            }
        }

        $old_data = C::t('#xigua_sp#xigua_sp_good')->fetch_G($gid);
        $spgg = $old_data['spgg_ary'];

        if(!$spgg){
            $spgg = array();
        }
        $type1 = intval($_GET['type1']);
        $spgg[$type1] = $form;
        if(C::t('#xigua_sp#xigua_sp_good')->update_G($gid, array('spgg' => serialize($spgg)))){
            hb_message(lang_sp('gxcg',0), 'success', "$SCRITPTNAME?id=xigua_sp&ac=manage$urlext");
        }
    }
}else{
    $list = $old_data['spgg_ary'];
    $tc = 1;
    $pow = array();
    $n = array();
    foreach ($list as $str => $item) {
        $ggtest[] = $item['ggtext'];
    }
    $ggtest = combina($ggtest);
    $price_list = C::t('#xigua_sp#xigua_sp_good_price')->fetch_all_by_where(array("gid=".$gid), 0, 9999, '', '*', 'name');
}