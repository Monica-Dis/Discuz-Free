<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/17
 * Time: 15:50
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$reckys = getcookie('reckys');
if($reckys){
    $reckys = unserialize($reckys);
}
$navtitle= lang_sp('sssp',0);
if($shid = intval($_GET['shid'])){
    $sh =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
    $navtitle = $sh['name'];
}