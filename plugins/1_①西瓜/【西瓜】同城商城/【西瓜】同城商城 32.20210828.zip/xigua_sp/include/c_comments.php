<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/11/18
 * Time: 20:53
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$gid= intval($_GET['gid']);
$good = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid, 0);
$avgstar = C::t('#xigua_sp#xigua_sp_good')->fetch_commnt_avg($gid);

$navtitle =lang_sp('sppj',0);
$need_side = 1;