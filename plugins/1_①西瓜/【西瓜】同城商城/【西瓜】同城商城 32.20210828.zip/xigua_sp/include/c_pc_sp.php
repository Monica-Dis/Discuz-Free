<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��! ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pc_common.php';
if (!$hb_setting):
    $cache_key = 'hb_ext_setting';
    loadcache($cache_key);
    $hb_setting = $_G['cache'][$cache_key];
endif;
if (!$sp_setting):
    $cache_key = 'sp_ext_setting';
    loadcache($cache_key);
    $sp_setting = $_G['cache'][$cache_key];
endif;
$hb_setting['autoscroll'] = 1;
if ($sp_setting['open']) {
    if (!checkmobile()) {
        switch ($ac) {
            case 'view':
//                dmp($v);

                $where = array();
                $where[] = "stat=1";$shidd = intval($v['shid']);
                $where[] = " shid=$shidd ";
                $where[] = " id!=$gid ";
                $order_by = 'displayorder desc , id desc';
                $xglist = C::t('#xigua_sp#xigua_sp_good')->fetch_all_by_where($where, 0, 5, $order_by);



                $url = hb_currenturl();
                $ewm = md5($url);
                $repath = './source/plugin/xigua_hb/tmp/';
                $qrfile = $repath . $ewm . '.png';
                $abs_qrfile = DISCUZ_ROOT . $qrfile;
                if (!is_file($abs_qrfile)) :
                    @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                    if(class_exists('QRcode')):
                        QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
                    endif;
                endif;

                include template('xigua_sp:view');
                exit;
                break;
            case 'cat':
            case 'index':
                foreach ($cat_list as $index => $item) {
                    $cat_list[$index]['sub'] = C::t('#xigua_sp#xigua_sp_hangye')->get_childs_by_pids($item['id']);
                }
                $cat_tree_all = $catlist = array_values($cat_list);
                $hb_setting['logo'] = $sp_setting['logo'];
                $hb_setting['leftcolor'] = $sp_setting['leftcolor'];
                include template('xigua_sp:index6');
                exit;
                break;
            case 'cat_li':
                break;
        }
    }
}
