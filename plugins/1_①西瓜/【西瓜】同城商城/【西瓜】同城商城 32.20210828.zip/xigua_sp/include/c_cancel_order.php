<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/12/1
 * Time: 21:05
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$ordid = intval($_GET['ordid']);
if(submitcheck('ordid')){
    $ov = C::t('#xigua_sp#xigua_sp_order')->fetch_G($ordid);
    if(!$ov || $ov['status']!=1){
        hb_message('error', 'error');
    }
    C::t('#xigua_sp#xigua_sp_order')->update_G($ordid, array(
        'status' => 4,
        'tuicfm_ts' => TIMESTAMP,
        'tui_ts' => TIMESTAMP
    ));
    DB::query("UPDATE %t SET stock=stock+%d WHERE id=%d", array(
        'xigua_sp_good_price',
        intval($ov['gnum']),
        $ordid
    ));
    if($ov['pay_ts']> 0){
        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
            'uid' => $ov['uid'],
            'crts' =>TIMESTAMP,
            'size' => floatval($ov['pay_money']),
            'note' => lang_sp('qxddytk',0),
            'link' => "",
        ));
        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($ov['uid'], 'money', $ov['pay_money']);
    }
    hb_message(lang_sp('ddyqx',0), 'success', 'reload');
}