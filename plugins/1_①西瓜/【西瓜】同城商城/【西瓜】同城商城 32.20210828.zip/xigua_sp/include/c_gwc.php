<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/4
 * Time: 15:33
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

switch ($_GET['do']){
    case 'in':
        $priceid = $_GET['price_id'];
        if(!$gid){
            hb_message(lang_sp('dataerror',0), 'error');
        }
        if(!$priceid){
            hb_message(lang_sp('qxzgg',0), 'error');
        }
        $good = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid);
        $data = array(
            'gid' => $gid,
            'shid' => $good['shid'],
            'price_id' => $_GET['price_id'],
            'uid' => $_G['uid'],
            'num' => $_GET['num'],
            'crts' => TIMESTAMP,
            'upts' => TIMESTAMP,
        );

        $num = C::t('#xigua_sp#xigua_sp_gwc')->input_gwc($data);
        if($num){
            hb_message(lang_sp('jjgwccg',0), 'success', 'javascript:gwcsucc(0);');
        }
        break;
    case 'del':
        $id = intval($_GET['gwid']);
        if(C::t('#xigua_sp#xigua_sp_gwc')->delete_G($id)){
            $num = C::t('#xigua_sp#xigua_sp_gwc')->get_gwc_count($_G['uid']);
            if($num){
                hb_message(lang_sp('sccg',0), 'success', 'javascript:removeGwc('.$id.');');
            }else{
                hb_message(lang_sp('sccg',0), 'success', 'reload');
            }
        }
        break;
    case 'check':
        $num = C::t('#xigua_sp#xigua_sp_gwc')->get_gwc_count($_G['uid']);
        include template('xigua_hb:header_ajax');
        echo $num;
        include template('xigua_hb:footer_ajax');
        break;
    default:
        $navtitle = lang_sp('gwc',0);
        $num = C::t('#xigua_sp#xigua_sp_gwc')->get_gwc_count($_G['uid']);
        $list = C::t('#xigua_sp#xigua_sp_gwc')->get_gwc_list($_G['uid']);


        $need_side = 1;

        $newl =$gids=$priceids=$shids= array();
        foreach ($list as $index => $item) {
            $newl[$item['shid']][] = $item;
            $shids[]=$item['shid'];
            $priceids[]=$item['price_id'];
            $gids[]=$item['gid'];
        }
        $shinfos = DB::fetch_all('SELECT shid,`name`,logo FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
        if($priceids){
            $good_prices =  C::t('#xigua_sp#xigua_sp_good_price')->fetch_all_by_where(array('id in ('.implode(',', $priceids).')'),0,99,'','*', 'id');
        }
        if($gids){
            $goods =  C::t('#xigua_sp#xigua_sp_good')->fetch_all_by_where(array('id in ('.implode(',', $gids).')'),0,99,'','*', 'id');
        }

        $cat_list = C::t('#xigua_sp#xigua_sp_hangye')->list_by_pid(0, TRUE);
        $jing_list = C::t('#xigua_sp#xigua_sp_hangye')->get_childs_by_pids($_GET['catid']);

        break;
}
