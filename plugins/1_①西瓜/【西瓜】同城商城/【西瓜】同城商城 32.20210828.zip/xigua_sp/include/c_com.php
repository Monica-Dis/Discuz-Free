<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/4
 * Time: 15:33
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}if($do == 'sxj'){
    $stat = intval($_GET['stat']);
    $gid = intval($_GET['gid']);
    $v = C::t('#xigua_sp#xigua_sp_good')->fetch_G($gid);
    if($v['stat'] == 2){
        hb_message(lang_sp('shzwf',0), 'error');
    }
    if(!in_array($stat, array(1,3))){
        hb_message('error', 'error');
    }
    C::t('#xigua_sp#xigua_sp_good')->update_G($gid, array(
        'stat' => $stat
    ));
    hb_message(lang_sp('czcg',0),'success', 'reload');
}elseif($do=='fahuo'){
    $ptlogid = intval($_GET['ptlogid']);
    $shids = sp_get_shids_by_uid();
    $v = DB::fetch_first("select * from %t WHERE shid IN(%n) AND id=%d ", array(
        'xigua_sp_order',
        $shids,
        $ptlogid
    ));
    if($v){
        if(!$_GET['yundan_gs']||!$_GET['yundan']){
            hb_message('error','error');
        }
        DB::update('xigua_sp_order', array(
            'fa_ts' => TIMESTAMP,
            'yundan_gs' => $_GET['yundan_gs'],
            'yundan' => $_GET['yundan'],
        ), array(
            'id' => $ptlogid
        ));

        $v = C::t('#xigua_sp#xigua_sp_order')->fetch($ptlogid);

        notification_add($v['uid'],'system', "<a href=\"{url}\">".$v['title'].lang_sp('yfh',0).'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_sp&ac=order_profile&ptlog_id='.$v['id']),1);

        hb_message(lang_sp('fhcg',0), 'success', 'reload');
    }
}elseif($do=='shouhuo'){
    $sp_config = $_G['cache']['plugin']['xigua_sp'];
    if($sp_config['autoconfirm'] && $_GET['autoconfirm']){
        if (discuz_process::islocked('autoconfirm', 30)) {
            hb_message('lock', 'success', 'reload');
        }
        $dats = TIMESTAMP-($sp_config['autoconfirm']*86400);
        $dd = DB::fetch_all('select * from %t where fa_ts>0 AND fa_ts<%d AND shou_ts<=1 AND yundan_gs!=\'\' limit 5', array('xigua_sp_order', $dats));
        foreach ($dd as $index => $item) {
            $v = $old = $item;
            $ptlogid = $old['id'];
            $aff = C::t('#xigua_sp#xigua_sp_order')->update($ptlogid, array(
                'shou_ts' => TIMESTAMP,
                'shou_confirm_ts' => TIMESTAMP,
            ));
            if($aff && $old['shou_ts']<=1&& $old['shou_confirm_ts']<=1 && $old['exp_method']!='hdfk'){
                $shid = $old['shid'];
                include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
                $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                $insxf   = intval(abs($vipinfo['insxf']))/100;
                if($shdata['shinsxf']){
                    $insxf  = intval(abs($shdata['shinsxf']))/100;
                }

                $sxfee = round($insxf*$v['pay_money'], 2);
                $money = $v['pay_money']-$sxfee;

                global $_G;
                $sp_config = $_G['cache']['plugin']['xigua_sp'];
                if($sp_config['jiesuantype']=='cb'){
                    $price_cb = DB::result_first('SELECT price_cb FROM %t WHERE id=%d', array('xigua_sp_good_price', $v['priceid']));
                    if($price_cb> 0){
                        $money = $price_cb*$v['gnum']+$v['yunfee'];
                        $sxfee = 0;
                    }
                }

                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', $money);
                C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                    'uid'  => $shdata['uid'],
                    'crts' => TIMESTAMP,
                    'size' => $money,
                    'note' => lang_sp('ddh',0).$v['order_id'].'<br>'.lang_sp('kcsxf',0).$sxfee,
                    'link' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
                ));

                if($_G['cache']['plugin']['xigua_hh']){
                    @DB::query("UPDATE %t SET reach=%d WHERE idtype='common_sp' AND FIND_IN_SET(%d ,thirdid)", array('xigua_hh_income', ($_G['cache']['plugin']['xigua_hh']['needshen_in'] ? -1 : 0), $ptlogid));
                }
            }
            hb_message('qrshcg~', 'success', 'reload');
        }
        hb_message('empty');
    }
    $ptlogid = intval($_GET['ptlogid']);
    $old = C::t('#xigua_sp#xigua_sp_order')->fetch($ptlogid);

    $aff = C::t('#xigua_sp#xigua_sp_order')->update_G($ptlogid, array(
        'shou_ts' => TIMESTAMP,
        'shou_confirm_ts' => TIMESTAMP,
    ));
    if($aff && $old['shou_ts']<=1&& $old['shou_confirm_ts']<=1&& $old['exp_method']!='hdfk'){
        $v = C::t('#xigua_sp#xigua_sp_order')->fetch($ptlogid);

        $shid = $v['shid'];

        include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
        $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
        $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
        $insxf   = intval(abs($vipinfo['insxf']))/100;
        if($shdata['shinsxf']){
            $insxf  = intval(abs($shdata['shinsxf']))/100;
        }

        $sxfee = round($insxf*$v['pay_money'], 2);
        $money = $v['pay_money']-$sxfee;

        global $_G;
        $sp_config = $_G['cache']['plugin']['xigua_sp'];
        if($sp_config['jiesuantype']=='cb'){
            $price_cb = DB::result_first('SELECT price_cb FROM %t WHERE id=%d', array('xigua_sp_good_price', $v['priceid']));
            if($price_cb> 0){
                $money = $price_cb*$v['gnum']+$v['yunfee'];
                $sxfee = 0;
            }
        }

        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', $money);
        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
            'uid'  => $shdata['uid'],
            'crts' => TIMESTAMP,
            'size' => $money,
            'note' => lang_sp('ddh',0).$v['order_id'].'<br>'.lang_sp('kcsxf',0).$sxfee,
            'link' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
        ));

        if($_G['cache']['plugin']['xigua_hh']){
            @DB::query("UPDATE %t SET reach=%d WHERE idtype='common_sp' AND FIND_IN_SET(%d ,thirdid)", array('xigua_hh_income', ($_G['cache']['plugin']['xigua_hh']['needshen_in'] ? -1 : 0), $ptlogid));
        }

        hb_message(lang_sp('qrshcg',0), 'success', 'reload');
    }
    if($old['exp_method']=='hdfk'){
        hb_message(lang_sp('qrshcg',0), 'success', 'reload');
    }
    hb_message(lang_sp('qrshsb',0), 'error', 'reload');
}elseif($do == 'showqr'){

    $v = C::t('#xigua_sp#xigua_sp_order')->fetch($_GET['ptlog_id']);
    if($v['hxcode']){
        if($r = sp_qrcode_make($v['id'], $v['hxcode'])){
            dheader("Location: $r");
        }
    }
}elseif($do == 'upscan'){
    if(submitcheck('code')) {
        $ptlog_id = intval($_GET['ptlog_id']);
        $v = DB::fetch_first("select * from %t WHERE id=%d AND hxcode=%s AND status IN(2,6) AND hxcrts=0", array(
            'xigua_sp_order',
            $ptlog_id,
            $_GET['code']
        ));
        $gid = $v['gid'];
        $shid = $v['shid'];
        if(!$v){
            hb_message(lang_sp('hxerror',0), 'error');
        }

        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
        $good = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid);

        $access = 0;
        if (IS_ADMINID) {
            $access = 1;
        } elseif ($v['uid'] == $_G['uid']) {
            $access = 1;
        } elseif ($good['uid'] == $_G['uid']) {
            $access = 1;
        }
        if (!$access) {
            $yuaninfo = C::t('#xigua_hs#xigua_hs_yuan')->fetch_yuan_by_shid_uid($shid, $_G['uid']);
            if ($yuaninfo) {
                $access = 1;
            }
        }
        if (!$access) {
            if ($coki = authcode(getcookie('hstax' . $shid), 'DECODE')) {
                $shv = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
                if ($shv['hxpwd'] == $coki) {
                    $access = 1;
                }
            }
        }
        if (!$access) {
            hb_message('noaccess', 'error');
        }

        if(!in_array($v['status'], array(2, 6))){
            hb_message('error', 'error');
        }

        $aff = C::t('#xigua_sp#xigua_sp_order')->update($ptlog_id, array(
            'shou_ts' => TIMESTAMP,
            'fa_ts' => TIMESTAMP,
            'hxuid' => $_G['uid'],
            'hxcrts' => TIMESTAMP,
        ));

        include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
        $shdata =  $sh;
        $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
        $insxf   = intval(abs($vipinfo['insxf']))/100;
        if($shdata['shinsxf']){
            $insxf  = intval(abs($shdata['shinsxf']))/100;
        }

        $sxfee = round($insxf*$v['pay_money'], 2);
        $money = $v['pay_money']-$sxfee;

        global $_G;
        $sp_config = $_G['cache']['plugin']['xigua_sp'];
        if($sp_config['jiesuantype']=='cb'){
            $price_cb = DB::result_first('SELECT price_cb FROM %t WHERE id=%d', array('xigua_sp_good_price', $v['priceid']));
            if($price_cb> 0){
                $money = $price_cb*$v['gnum']+$v['yunfee'];
            }
        }

        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($shdata['uid'], 'money', $money);
        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
            'uid'  => $shdata['uid'],
            'crts' => TIMESTAMP,
            'size' => $money,
            'note' => lang_sp('hxcgdhh',0).$v['order_id'],
            'link' => "$SCRITPTNAME?id=xigua_sp&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
        ));

        if($_G['cache']['plugin']['xigua_hh']){
            @DB::query("UPDATE %t SET reach=%d WHERE idtype='common_sp' AND FIND_IN_SET(%d ,thirdid)", array('xigua_hh_income', ($_G['cache']['plugin']['xigua_hh']['needshen_in'] ? -1 : 0), $ptlog_id));
        }
        hb_message(lang_sp('hxcg',0), 'success', 'reload');


    }
}elseif($do == 'setintype'){
//    print_r($_GET['comment']);

    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($_GET['shname']);
    if(!$sh){
//        hb_message('dpbcz', 'error');
    }

}elseif ($do == 'addrlist'){
    $shid = intval($_GET['shid']);
    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
    if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/table/table_xigua_hs_addr.php')):

        if($lat = floatval($_GET['lat'])){
            $lng = floatval($_GET['lng']);
            $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
            $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
            $orderby = 'distance ASC';
            $daodianlist = DB::fetch_all("SELECT $field FROM %t WHERE shid=$shid ORDER BY $orderby", array('xigua_hs_addr'));
        }else{
            $daodianlist = C::t('#xigua_hs#xigua_hs_addr')->fetch_all_by_page($start_limit, $lpp, array("shid=$shid"));
        }
    endif;
    if(!$daodianlist):
        $daodianlist = array();
    endif;

    $daodianlist[] = array(
        'dist1' => $sh[province],
        'dist2' => $sh[city],
        'dist3' => $sh[district],
        'realname' => $sh[name],
        'mobile' => $sh[tel],
        'address' => $sh[addr],
    );
    $ret = "";
    foreach ($daodianlist as $_k => $_v) {

        $distance = intval($_v['distance']);
        if($distance<=1000){
            $distance = intval($distance). 'm';
        }else if($distance>1000){
            $distance = round($distance/1000, 1). 'km';
        }
        $_v['distance'] = $distance;

        $jn = lang('plugin/xigua_hs', 'junin');
        $ztd = lang_sp('ztd',0);
        $lxr_ = lang_sp('lxr_',0);
        $sjh_ = lang_sp('sjh_',0);

        $ss = '';
        if($distance!='0m'){
            $ss = "<div style=\"background:{$config['maincolor']};font-size: 12px;position:absolute;right: 0;color: #fff;border-radius:12px 0 0 12px;padding-left: 5px;bottom:0;opacity:.7;\">$jn{$_v['distance']}</div>";
        }

        $CHECKED = '';
        if($_k == 0 ){
            $CHECKED = 'checked';
        }

        $ret .=<<<HTML
<label class="weui-cell weui-check__label" for="x$_k">
    <div class="weui-cell__hd">
        <label class="weui-label mr8" style="width:auto"><i class="f20 c3 iconfont icon-mudedi vm"></i></label>
    </div>
    <div class="weui-cell__bd c3">
        <div class="f12 "><span class="f14">$ztd</span> $lxr_{$_v[realname]} $sjh_{$_v[mobile]}</div>
        <div class="f12">{$_v[dist1]}{$_v[dist2]}{$_v[dist3]}{$_v[address]}</div>
    </div>
    <div class="weui-cell__ft">
        <input $CHECKED type="radio" class="weui-check" name="form[ziti]" value="$lxr_{$_v[realname]} $sjh_{$_v[mobile]}||||{$_v[dist1]}{$_v[dist2]}{$_v[dist3]}{$_v[address]}" id="x$_k">
        <span class="weui-icon-checked"></span>
    </div>
    $ss
</label>
HTML;
    }
    include template('xigua_hb:header_ajax');
    echo $ret;
    include template('xigua_hb:footer_ajax');
}elseif ($do =='kd'){
    $host = "https://wuliu.market.alicloudapi.com";
    $path = "/kdi";
    $method = "GET";
    $appcode = $sp_config['kdcode'];
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys = "no=".$_GET['danhao'];
    $bodys = "";
    $url = $host . $path . "?" . $querys;//

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
//curl_setopt($curl, CURLOPT_HEADER, true); �粻���json, ������д��룬��ӡ����ͷ��״̬�롣
//״̬��: 200 ������400 URL��Ч��401 appCode���� 403 �������ꣻ 500 API���ܴ���
    if (1 == strpos("$".$host, "https://"))
    {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }

    $ret = (curl_exec($curl));
    $ret = json_decode($ret, 1);
    $retHtml = '';
    if($ret['result']['list']){
        foreach ($ret['result']['list'] as $index => $item) {
            $item['status'] = diconv($item['status'], 'UTF-8', CHARSET);
            $retHtml .=<<<HTML
<label class="weui-cell">
    <div class="weui-cell__bd c3">
        <div class="f12 c6">{$item['time']}</div>
        <div class="f12">{$item['status']}</div>
    </div>
</label>
HTML;
        }
    }
    include template('xigua_hb:header_ajax');
    echo $retHtml;
    include template('xigua_hb:footer_ajax');
}