<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2018/9/4
 * Time: 15:33
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$navtitle = lang_sp('ddgl1',0);
$need_side = 1;
$keyword = stripsearchkey($_GET['keyword']);