<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['shid']):
    $shid = intval($_GET['shid']);
endif;
if($_GET['do']=='setbaoyou'){
    DB::update('xigua_hs_shanghu', array('baoyou' => intval($_GET['baoyou'])), array(
        'uid' => $_G['uid'],
        'shid'  => $shid,
    ));
    hb_message(lang_sp('bccg',0), 'success', 'reload');
}
$navtitle = lang_sp('wddd1',0);
$cat_list = C::t('#xigua_sp#xigua_sp_hangye')->list_by_pid(0, TRUE);
$jing_list = C::t('#xigua_sp#xigua_sp_hangye')->get_childs_by_pids($_GET['catid']);

$need_side = 1;
$status_font = array(
    1 => lang_sp('status_1',0),
    2 => lang_sp('status_2',0),
    3 => lang_sp('status_3',0),
    4 => lang_sp('status_4',0),
);
$shcout= C::t('#xigua_hs#xigua_hs_shanghu')->fetch_count_self($_G['uid']);
if($shcout){
    $wheere = array();
    $wheere[] = 'uid='.$_G['uid'];
    if($shid){
        $wheere[] = 'shid='.$shid;
    }
    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($wheere);
    if($sh):
        $sh = $sh[0];
    endif;
    $list = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('uid='.$_G['uid']), 0, 10);
}