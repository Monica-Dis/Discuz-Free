<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class mobileplugin_xigua_f
{
    public static function global_footer_mobile()
    {
        global $_G;
        if(strpos($_GET['id'], 'dzapp')!==false){
            return '';
        }
        include DISCUZ_ROOT.'source/plugin/xigua_f/common.php';
        include template('xigua_f:sharejssdk');
        return $html;
    }
}

class mobileplugin_xigua_f_forum extends mobileplugin_xigua_f
{

    public static function viewthread_postbottom_mobile_output()
    {
        include DISCUZ_ROOT.'source/plugin/xigua_f/common.php';

        $opentypes = array_flip(unserialize($config['opentypes']));

        $apps = array(
            'weixin'          => array('weixin',       lang('plugin/xigua_f', 'weixin')),
            'weixin_timeline' => array('weixinFriend', lang('plugin/xigua_f', 'weixin_timeline')),
            'qq'              => array('QQ',           lang('plugin/xigua_f', 'qq')),
            'weibo'           => array('sinaWeibo',    lang('plugin/xigua_f', 'weibo')),
            'qzone'           => array('QZone',        lang('plugin/xigua_f', 'qzone')),
            'more'            => array('',             lang('plugin/xigua_f', 'more')),
        );
        if(!$inmqqbrowser && !$inmucbrowser){
            unset($opentypes['more']);
            unset($apps['more']);
        }
        if($inwechat){
            unset($opentypes['more']);
            unset($apps['more']);
        }
        $width = count($opentypes) ? (100/count($opentypes)) : 0;

        $config['ignoreext'] = $config['ignoreext'] ? $config['ignoreext'] : '\'\'';
        $config['ignorelink'] = $config['ignorelink'] ? $config['ignorelink'] : '\'\'';

        $html = '';
        if($opentypes['none']){
            $opentypes = $apps = array();
            return array();
        }
        global $_G,$postlist;

        foreach (array_values($postlist) as $index => $item) {
            if($item['first'] && $opentypes){
                include template('xigua_f:sharehtml');
                break;
            }
        }

        return array(
            0 => $html,
            '' => $html,
        );
    }
}

class plugin_xigua_f_portal extends mobileplugin_xigua_f_forum
{

    public function view_article_content_output()
    {
        global $content, $_G;
        $GLOBALS['postlist'][0]['first']=1;
        $thml = parent::viewthread_postbottom_mobile_output();
        return $thml[0];
    }
}
class mobileplugin_xigua_f_portal extends plugin_xigua_f_portal{

}
