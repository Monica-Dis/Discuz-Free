<?php

/**
 *      CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z Dism.Taobao.Com $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginid = 'xigua_f';

function xigua_fdelete_all($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xigua_fdelete_all($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}

xigua_fdelete_all(DISCUZ_ROOT.'./source/plugin/xigua_f', true);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_TC_UTF8.xml');
$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_TC_UTF8.xml');


if(is_file(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')){
    include_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    WeChatHook::delAPIHook($pluginid);
}