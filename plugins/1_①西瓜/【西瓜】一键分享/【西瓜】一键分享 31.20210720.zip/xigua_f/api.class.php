<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class xigua_f
{
    public function viewthread_variables(& $params)
    {
        global $_G;

        foreach ($params['postlist'] as $index => $item) {
            if($item['first']){
                $params['postlist'][ $index ]['message'] .= "<script>$.get('{$_G['siteurl']}plugin.php?id=xigua_f:sign&isuse=1', function(data) {  $($('.replyShare')[0]).before(data);});</script >";
                break;
            }
        }
        return true;
    }
}