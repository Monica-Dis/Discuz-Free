<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/8/10
 * Time: 20:30
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

global $_G;
if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}
include_once libfile('function/cache');
include_once DISCUZ_ROOT.'source/plugin/xigua_f/function.php';

$inwechat     = strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') !== false;
$inmqqbrowser = strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'mqqbrowser') !== false;
$inmucbrowser = strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'ucbrowser') !== false;

$config = $_G['cache']['plugin']['xigua_f'];
$config['ignoreext']   = $config['ignoreext'] ? "/^.+\\.({$config['ignoreext']}).*?$/" : 'false';
$config['ignorelink']  = $config['ignorelink'] ? "/^.+({$config['ignorelink']}).*?$/" : 'false';
$config['defaultdesc'] = xf_filter_desc($config['defaultdesc']);
$config['dely']        = $config['dely']>0 ? intval($config['dely']) : 300;

$config['debug'] = $config['debug'] ? 'true' : 'false';
