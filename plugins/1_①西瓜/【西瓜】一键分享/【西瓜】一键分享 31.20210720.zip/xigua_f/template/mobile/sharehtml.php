<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
{block html}
<link rel="stylesheet" href="source/plugin/xigua_f/icon/share.css?123"/>
<!--{if $width}--><style>div.f_Share .list span{width:{$width}%;}</style><!--{/if}-->
<!--{if $config[bg]}--><style>.f_share_title>div{background:$config[bg]}</style><!--{/if}-->
<!--{if $opentypes && $config[showshare_to]}-->
<div id="f_Share" class="f_Share cl">
    <div class="f_share_title"><div>{lang xigua_f:share_to}</div></div>
    <div class="list cl">
        <!--{loop $opentypes $k $v}-->
        <span data-app="{$apps[$k][0]}" class="bShare {$k}"><i></i>{$apps[$k][1]}</span>
        <!--{/loop}-->
    </div>
</div>
<div id="wechat-masker"><div id="wechat-guider" style="display:none"></div><div id="other-guider" style="display:none"></div></div>

<!--{if $config[floatbtn]}--><a href="javascript:;" class="f_sharebtn">{$config[floatbtn]}</a><!--{/if}-->

<div>
    <div class="weui-mask" id="f_iosMask" style="display: none"></div>
    <div class="weui-actionsheet" id="f_iosActionsheet">
        <div class="weui-actionsheet__menu">
            <div class="f_Share">
                <div class="list cl">
                    <!--{loop $opentypes $k $v}-->
                    <span data-app="{$apps[$k][0]}" class="bShare {$k}"><i></i>{$apps[$k][1]}</span>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <div class="weui-actionsheet__action">
            <div class="weui-actionsheet__cell" id="f_iosActionsheetCancel">{lang xigua_f:quxiao}</div>
        </div>
    </div>
</div>
<!--{/if}-->
{/block}