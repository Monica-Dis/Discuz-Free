<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginid = 'xigua_f';


@unlink(DISCUZ_ROOT . 'source/plugin/xigua_f/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_TC_UTF8.xml');
$finish = TRUE;

@unlink(DISCUZ_ROOT . 'source/plugin/xigua_f/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_f/discuz_plugin_xigua_f_TC_UTF8.xml');

if(is_file(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')){
    $Hooks = array('viewthread_variables');

    $data = array();
    foreach($Hooks as $Hook) {
        $data[] = array(
            $Hook => array(
                'plugin' => $pluginid,
                'include' => 'api.class.php',
                'class' => $pluginid,
                'method' => $Hook,
                'order' => 999,
            )
        );
    }

    include_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    WeChatHook::updateAPIHook($data);
}