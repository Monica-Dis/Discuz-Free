<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2016/11/7
 * Time: 16:49
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once 'common.php';

if($_GET['isuse']){
    include_once DISCUZ_ROOT."source/plugin/xigua_f/m.class.php";

    $postlist[0]['first'] = 1;
    $output = mobileplugin_xigua_f_forum::viewthread_postbottom_mobile_output();
    $footer = mobileplugin_xigua_f_forum::global_footer_mobile();

    echo ($output[0].$footer);
    exit;
}

if(submitcheck('formhash', TRUE)&& $_GET['formhash']==FORMHASH){
    if($_GET['url']){
        $sharehtml = xf_get_share($config['appid'], $_GET['url']);

        header("Content-type: application/json");
        echo json_encode($sharehtml);
        exit;
    }else if($_GET['sharelink']){
        $option = $_GET['option'];
        $subject = urlencode(strip_tags(diconv($option['title'], CHARSET, 'UTF-8')));
        $message = urlencode(strip_tags(diconv($option['desc'], CHARSET, 'UTF-8')));
        $Surl    = urlencode($option['link']);
        $pic     = urlencode($option['imgUrl']);

        $ret['weibo']  = "http://service.weibo.com/share/share.php?url=$Surl&appkey=&title=$subject&pic=$pic&language=zh_cn";
        $ret['qq']     = "http://connect.qq.com/widget/shareqq/index.html?url=$Surl&desc=$message&summary=&title=$subject&site=&pics=$pic";
        $ret['qzone']  = "http://openmobile.qq.com/api/check2?page=qzshare.html&loginpage=loginindex.html&logintype=qzone&url=$Surl&summary=$subject&desc=$message&title=$subject&imageUrl=$pic&successUrl=&failUrl=&callbackUrl=&sid=";

        ob_end_clean();
        ob_start();
        @header("Expires: -1");
        @header("Cache-Control: no-store, private, post-check=0, pre-check=0, max-age=0", FALSE);
        @header("Pragma: no-cache");
        header("Content-type: application/json");
        echo json_encode($ret);
        exit;
    }
}