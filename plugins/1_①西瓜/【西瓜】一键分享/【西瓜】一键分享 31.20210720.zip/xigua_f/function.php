<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2017/1/23
 * Time: 13:12
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function xf_currenturl($related = 0)
{
    $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
    $php_self = $_SERVER['PHP_SELF'] ? $_SERVER['PHP_SELF'] : $_SERVER['SCRIPT_NAME'];
    $path_info = isset($_SERVER['PATH_INFO']) ? $_SERVER['PATH_INFO'] : '';
    $relate_url = isset($_SERVER['REQUEST_URI']) ? $_SERVER['REQUEST_URI'] : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . $_SERVER['QUERY_STRING'] : $path_info);
    return $related ? $relate_url : $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
}

function xf_filter_desc($desc)
{
    return str_replace(array(
        '\'', "\n", "\r", "\t", "&nbsp;", "&amp;nbsp;"
    ), '', $desc);
}

function xf_get_share($appid, $currenturl)
{
    $timestamp = time();
    $noncestr = uniqid('wx');

    $jsapi_ticket = xf_get_jsapi_ticket();
    if($jsapi_ticket['errcode'] == '40001'){
        $jsapi_ticket = xf_get_jsapi_ticket(0);
    }
    if($jsapi_ticket['errcode']){
        return $jsapi_ticket;
    }
    $ticket = $jsapi_ticket['ticket'];
    $signature = sha1("jsapi_ticket=$ticket&noncestr=$noncestr&timestamp=$timestamp&url=$currenturl");

    $ret = array(
        'appid'     => $appid,
        'timestamp' => $timestamp,
        'nonceStr'  => $noncestr,
        'signature' => $signature,
    );
    return $ret;
}

function xf_get_jsapi_ticket($cache = 1)
{
    global $_G, $config;
    $appid = $config['appid'];
    $appsecret = $config['appsecret'];

    $tokeninfo = xf_getAccessToken($cache);
    $access_token = $tokeninfo['token'];
    if(!$access_token){
        return $tokeninfo;
    }

//    $cachename = substr(md5('wechatat_' . $appid.$appsecret.date('Y-m-d H')), 0, 8);
    $cachename = 'ticketat_' . $config['appid'];
    loadcache($cachename);

    $jsapi_ticket = $_G['cache'][$cachename];

    if ($jsapi_ticket) {
        if (time() < $jsapi_ticket['expiration']) {
            return  $jsapi_ticket;
        }
    }
    $url = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=$access_token&type=jsapi";
    $json = xf_get_from_https($url);
    $res = json_decode($json, true);
    if ($res['errcode']==0) {
        $cachevalue = array(
            'ticket' => $res['ticket'],
            'expiration' => time() + (int) $res['expires_in']-1000,
        );
        savecache($cachename, $cachevalue);
        return $cachevalue;
    }else{
        savecache($cachename, '');
        return $res;
    }
}
function xf_getAccessToken($cache = 1) {
    global $_G,$config;
    $appid = $config['appid'];
    $appsecret = $config['appsecret'];
//    $cachename = substr(md5('accesstoken:' . $appid.$appsecret.date('Y-m-d H')), 0, 8);
    $cachename = 'wechatat_' . $config['appid'];
    loadcache($cachename);

    $token = $_G['cache'][$cachename];

    // check cache
    if($cache) {
        if ($token) {
            if (time() < $token['expiration']) {
                return $token;
            }
        }
    }

    // get new token
    $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";

    $json = xf_get_from_https($url);
    $res = json_decode($json, true);

    if ($res['errcode']==0) {
        // update cache
        $token = array(
            'token' => $res['access_token'],
            'expiration' => time() + (int) $res['expires_in']-1000,
        );
        savecache($cachename, $token);
        savecache('wechatat_' . $appid, $token);
    }else{
        savecache($cachename, '');
        return $res;
    }
    return $token;
}
function xf_get_from_https($url) {
    $data = dfsockopen($url);
    if(!$data){
        $data = file_get_contents($url);
    }
    return $data;
}
