<?php exit('hehe');?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="{CHARSET}">
    <title></title>
</head>
<body>
<a id="click">click</a>

<script src="source/plugin/xigua_sf/static/jquery-1.11.3.min.js"></script>

<script>

</script>

<!--{if $jsApiParameters}-->
<script>callpay($jsApiParameters);</script>
<!--{else}-->
<script>alert('$error');</script>
<!--{/if}-->
</body>
</html>
