<?php exit('xigua_sf');?>
{block html}
<div id="xsf_c" class="exfm cl" style="display:block;background:#fff;padding:15px"><!--{if !$disable}-->$shou: <input type="text" style="padding: 0 10px;height: 32px;line-height: 32px;width: 100px;" id="xsfrmb" name="xsfrmb" class="px pxs" value="$price" > $uiam<!--{else}-->$shou: <input type="hidden" id="xsfrmb" name="xsfrmb" value="$price" ><span style="font-size:22px;color:orangered;">$price</span> $uiam
<!--{/if}--></div>
{/block}