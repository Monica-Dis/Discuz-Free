<?php exit('11');?>
<!--{template common/header}-->
<link href="source/plugin/xigua_sf/static/webui.css" rel="stylesheet" />
<link href="source/plugin/xigua_sf/static/mobileset.css" rel="stylesheet" />
<link href="source/plugin/xigua_sf/static/my.css?_={$pluginversion}" rel="stylesheet" />


<div class="cl setting" style="margin-top: 0">
    <div class="cl avatar-badge-list">
        <div class="cl avatar-badge-list-wrapper">

            <div class="weui_cells_title">$config[tixian]</div>
            <div class="weui_grids half">

                <a href="javascript:;" class="weui_grid js_grid" data-id="progress">
                    <div class="center">
                        {lang xigua_sf:totalget}
                    </div>
                    <p class="weui_grid_label">
                        {$user['total']}
                    </p>
                </a>

                <a href="javascript:;" class="weui_grid js_grid" data-id="progress">
                    <div class="center">
                        {lang xigua_sf:totalti}
                    </div>
                    <p class="weui_grid_label">
                        {eval echo intval($user[times]);}
                    </p>
                </a>

                <a href="javascript:;" class="weui_grid js_grid" data-id="progress">
                    <div class="center">
                        {lang xigua_sf:yitixian}
                    </div>
                    <p class="weui_grid_label">
                        {$user[settled]}
                    </p>
                </a>

                <a href="javascript:;" onclick="return custom();" class="weui_grid js_grid" data-id="progress">
                    <div class="center">
                        {lang xigua_sf:weitixian}
                    </div>
                    <p class="weui_grid_label">
                        {$user[notsettled]}
                    </p>
                </a>

            </div>

            <div class="weui_cells_title">{lang xigua_sf:liushui}</div>
            <div class="bd" style="    background: #fff;">

                <table class="gridtable">

                    <tbody id="gridtable">

                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<div class="weui_dialog_confirm" id="dialog3" style="display: none;">
    <div class="weui_mask"></div>
    <div class="weui_dialog">
        <div class="weui_dialog_hd"><strong class="weui_dialog_title">{lang xigua_sf:tixianjine}</strong></div>
        <div class="weui_dialog_bd">
            <div class="weui_cells weui_cells_form">
                <div class="weui_cell">
                    <div class="weui_cell_hd"><label class="weui_label">{lang xigua_sf:jine}</label></div>
                    <div class="weui_cell_bd weui_cell_primary">

                        <form name="confirmpost" method="post" id="confirmpost" action="home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting">
                            <input name="formhash" value="{FORMHASH}" type="hidden"/>
                            <input class="weui_input" id="weui_input" type="number" name="amount" value="" autocomplete="off" />
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <div class="weui_dialog_ft">
            <a href="javascript:;" class="weui_btn_dialog default closec">{lang xigua_sf:quxiao}</a>
            <a href="javascript:;" class="weui_btn_dialog primary primaryc">{lang xigua_sf:queding}</a>
        </div>
    </div>
</div>

<div id="toast" class="toast" style="display: none;">
    <div class="weui_mask_transparent"></div>
    <div class="weui_toast">
        <i class="weui_icon_toast"></i>
        <p class="weui_toast_content">{lang xigua_sf:succeed}</p>
    </div>
</div>
<div id="toast2" class="toast" style="display: none;">
    <div class="weui_mask_transparent"></div>
    <div class="weui_toast">
        <i class="weui_icon_toast"></i>
        <p class="weui_toast_content">{lang xigua_sf:unbind}</p>
    </div>
</div>
<iframe style="display:none" id="uploadtarget" name="uploadtarget"></iframe>
<div class="weui_dialog_confirm" id="dialog1" style="display:none" >
    <div class="weui_mask"></div>
    <div class="weui_dialog">
        <div class="weui_dialog_hd"><strong class="weui_dialog_title">{lang xigua_sf:dounbind}</strong></div>
        <div class="weui_dialog_bd">{lang xigua_sf:confir}</div>

        <form action="home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting&type=wxpay" id="unbindform" method="post">
            <div class="weui_dialog_ft">
                <input type="hidden" name="formhash" value="{FORMHASH}">
                <input type="hidden" name="unbind" value="1">
                <input type="hidden" name="unbindsubmit" value="1">
                <a href="javascript:;" class="weui_btn_dialog default">{lang xigua_sf:quxiao}</a>
                <a href="javascript:;" class="weui_btn_dialog primary">{lang xigua_sf:queding}</a>
            </div>
        </form>
    </div>
</div>
<script>
    $.ajax({
        url:'home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting&orderlog=1', success:function(data){
            $('#gridtable').html(data);
        }
    });
    $('.closec').on('click', function(){
        $('#dialog3').hide();
    });
    $('.primaryc').on('touchstart', function(){
        var input = $('#weui_input');
        var price = input.val();
        if(! /^[0-9]+\.{0,1}[0-9]{0,2}$/.test(price)){
            alert('{lang xigua_sf:qing}');
            input.focus();
            return false;
        }
        var form = $('#confirmpost');
        $.ajax({
                type: 'POST',
                url: form.attr('action') + '&inajax=1',
                data: form.serialize(),
                dataType: 'xml'
            })
            .success(function (s) {
                var html = s.lastChild.firstChild.nodeValue.replace(/<script.*?>([\s\S]*?)<\/script>/ig, '');
                html = $(html).find('p').text();
                alert(html);
                window.location.href = window.location.href;
            })
            .error(function () {
                window.location.href = window.location.href;
            });
        return false;
    });
    function ajaxget11(url, target){
        $.ajax({
            url:url+'&inajx=1', success:function(data){
                $('#gridtable').html(data);
            }
        });
        return false;
    }

    function custom(){
        $('#dialog3').show();
        return false;
    }
    function showqr(){
        var dialog = $('#dialog1');
        dialog.show();
        dialog.find('.default').on('click', function () {
            dialog.hide();
        });
        dialog.find('.primary').on('click', function () {
            var form = $('#unbindform');
            $.ajax({
                    type: 'POST',
                    url: form.attr('action') + '&inajax=1',
                    data: form.serialize(),
                    dataType: 'xml'
                })
                .success(function (s) {
                    $('#toast2').show();
                    setTimeout(function(){
                        window.location.href = window.location.href;
                    },2000);
                })
                .error(function () {
                    window.location.href = window.location.href;
                });
            return false;
        });
        return false;
    }

    function doupload(id){
        document.getElementById(id).submit();
    }
    function uploadend(obj){
        if(obj.error !=0){
            alert(obj.message);
            return false;
        }
        var img = document.getElementById(obj.type+'_img');
        img.innerHTML = '<span></span><em style="background:url(' + obj.url + ') no-repeat center;background-size:cover;"></em>';//'<img class="full" src="' + obj.url + '" />';
    }
    function dosubmit(){
        var form = $('#saveqiu');
        $.ajax({
                type: 'POST',
                url: form.attr('action') + '&inajax=1',
                data: form.serialize(),
                dataType: 'xml'
            })
            .success(function (s) {
                $('#toast').show();
                setTimeout(function(){
                    window.location.href = window.location.href;
                },2000);
            })
            .error(function () {
                window.location.href = window.location.href;
            });
        return false;
    }
</script>
<!--{template common/footer}-->
