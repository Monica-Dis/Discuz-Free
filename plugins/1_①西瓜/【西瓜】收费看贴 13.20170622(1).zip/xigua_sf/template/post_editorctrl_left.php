<?php exit('xigua_sf');?>
{block button}
<style>
.b2r #e_sf_part{background:url(source/plugin/xigua_sf/static/sf-small.png) no-repeat center 4px}
#e_sf_part{background:url(source/plugin/xigua_sf/static/sf.png) no-repeat center 4px}
#e_sf_part:hover{background-color:#FFFFFF}
</style>
<a id="e_sf_part" title="$lang">$lang</a>
<script>
    _attachEvent($("e_sf_part"), "click", function(){
        var menu = document.createElement("div");
        menu.id = "e_sf_part_menu";
        menu.style.display = "none";
        menu.className = "p_pof upf";
        menu.style.width = "420px";

        s =  '<div class="p_opt cl"><span class="y" style="margin:-10px -10px 0 0"><a onclick="hideMenu();return false;" class="flbc" href="javascript:;">{lang close}</a></span><div>{lang xigua_sf:inpur}:<br><textarea id="e_sf_part_pa" style="width: 98%" cols="50" rows="5" class="txtarea"></textarea></div><div class="pns mtn"><button type="button" onclick="_insert_sf();" id="e_sf_part_submit" class="pn pnc"><strong>{lang submit}</strong></button></div></div>';
        menu.innerHTML = s;
        $(editorid + "_editortoolbar").appendChild(menu);
        showMenu({"ctrlid":"e_sf_part","mtype":"menu","evt":"click","duration":3,"cache":0,"drag":0,"pos":"43!"});
    });
    function _insert_sf(){
        $('e_iframe').contentWindow.document.body.focus();
        insertText('[sf]'+$('e_sf_part_pa').value+"[/sf] ");
        hideMenu();
    }
</script>
{/block}