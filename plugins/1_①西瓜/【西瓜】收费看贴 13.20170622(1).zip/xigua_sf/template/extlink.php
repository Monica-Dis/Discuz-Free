<?php exit('xigua_sf');?>
{block extlink}
<a class='buynowsf' id="sfitem" href="javascript:void(0);">{$config['buynow']}</a>
<!--{if $jq}--><script src="{$_G['siteurl']}source/plugin/xigua_sf/static/jquery-1.11.3.min.js"></script ><!--{/if}-->
<script>
    $exjs
    $('#sfitem').on('touchstart', function(){
        $.ajax({
            url:'plugin.php?id=xigua_sf:pay&type=wx&iswx=1&tid={$tid}&pid={$pid}',
            dataType:'json',
            success:function(data){
                if(data.error){
                    alert(data.error);
                }else{
                    callpay(data);
                }
            }
        });
        return false;
    });
    function callpay(kapi){
        if (typeof WeixinJSBridge == "undefined"){
            if( document.addEventListener ){
                document.addEventListener('WeixinJSBridgeReady', function(kapi){jsApiCall(kapi);}, false);
            }else if (document.attachEvent){
                document.attachEvent('WeixinJSBridgeReady', function(kapi){jsApiCall(kapi);});
                document.attachEvent('onWeixinJSBridgeReady', function(kapi){jsApiCall(kapi);});
            }
        }else{
            jsApiCall(kapi);
        }
    }
    function jsApiCall(apiKey) {
        WeixinJSBridge.invoke(
            'getBrandWCPayRequest',
            apiKey,
            function(res){
                if(res.err_msg == 'get_brand_wcpay_request:ok'){
                    window.location.href = 'forum.php?mod=viewthread&tid={$tid}&random=_';
                }else{}
            }
        );
    }
</script >
{/block}