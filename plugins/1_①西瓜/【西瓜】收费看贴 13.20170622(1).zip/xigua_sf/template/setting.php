<?php exit('11');?>
<link href="source/plugin/xigua_sf/static/pcset.css" rel="stylesheet" />
<div class="cl pcset">
    <ul class="tb cl">
        <li  class="a" ><a href="home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting">{lang xigua_sf:basic}</a></li>
    </ul>
    <div class="cl avatar-badge-list">
        <div class="E_inner_frame cl p10">
            <div class="WB_cardwrap S_bg2">
                <div class="EM_reward_overview">
                    <div class="WB_cardtitle_b S_line2">
                        <div class="newPay_tip S_link1">
                            <strong class="xi1">$config[tixian]</strong>
                        </div>
                    </div>
                    <div class="WB_innerwrap">
                        <table class="tb_datacnt" cellspacing="0" cellpadding="0">
                            <tbody>
                            <tr>
                                <td class="S_line1 S_line0">
                                    <span class="S_txt2 W_f14 S_link1">{lang xigua_sf:totalget}</span>
                                    <span class="W_icon icon_askS"></span>
                                    <strong class="W_f22 S_link1 xi1">{$user['total']}</strong>
                                </td>
                                <td class="S_line1">
                                    <span class="S_txt2 W_f14">{lang xigua_sf:totalti}</span> <strong class="W_f22">{$user[times]}</strong>
                                </td>
                                <td class="S_line1">
                                    <span class="S_txt2 W_f14">{lang xigua_sf:yitixian}</span>
                                    <strong class="W_f22">{$user[settled]}</strong>
                                </td>
                                <td class="S_line1">
                                    <span class="S_txt2 W_f14">{lang xigua_sf:weitixian}</span>
                                    <span class="W_icon icon_askS"></span> <strong class="W_f22">{$user[notsettled]} <a href="javascript:;" onclick="showconfirm()" class="xi2">{lang xigua_sf:tixian}</a></strong>

                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div>
                <div class="WB_cardwrap S_bg2">
                    <div class="E_PCD_chart6">
                        <div class="WB_cardtitle_b S_line2">
                            <h4 class="obj_name">
                                <span class="main_title W_fb W_f14">{lang xigua_sf:liushui}</span>
                            </h4>
                        </div>
                        <div class="WB_innerwrap">
                            <div>
                                <table class="gridtable">

                                    <tbody id="gridtable">

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="WB_cardpage S_line1">
                        <div class="W_pages"></div>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<script>
    ajaxget('home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting&orderlog=1', 'gridtable');
    function showconfirm(){
        var notice = '<style>.alert_info{padding-left:0;background:none}.sft .px{width:210px}.sft td{padding:5px}</style><div class="cl" style="margin-top:10px;text-align:center"><form name="confirmpost" method="post" id="confirmpost">' +
            '<input name="formhash" value="{FORMHASH}" type="hidden"/>' +
            '<table class="sft" width="100%"><tr><td  align="left">' +
            '{lang xigua_sf:duihuanjin}</td><td>' +
            '<input class="px" type="number" name="amount" id="amount" value="" autocomplete="off" />' +
            '</td><td>{lang xigua_sf:yuan}</td></tr></table>' +
            '</form></div>';
        showDialog1(notice, 'confirm', '{lang xigua_sf:tixianjine}', function(){
            if($('amount').value ==''|| $('amount').value<=0){
                alert('{lang xigua_sf:duihuanjinr}');
                $('amount').focus();
                return true;
            }
            $('confirmpost').submit();
        }, 1, '', '$config[tixian]', '{lang xigua_sf:tixian}', '{lang xigua_sf:quxiao}');
    }


    function showDialog1(msg, mode, t, func, cover, funccancel, leftmsg, confirmtxt, canceltxt, closetime, locationtime) {
        clearTimeout(showDialogST);
        cover = isUndefined(cover) ? (mode == 'info' ? 0 : 1) : cover;
        leftmsg = isUndefined(leftmsg) ? '' : leftmsg;
        mode = in_array(mode, ['confirm', 'notice', 'info', 'right']) ? mode : 'alert';
        var menuid = 'fwin_dialog';
        var menuObj = $(menuid);
        var showconfirm = 1;
        confirmtxtdefault = 'queding';
        closetime = isUndefined(closetime) ? '' : closetime;
        closefunc = function () {
            if(typeof func == 'function') func();
            else eval(func);
            hideMenu(menuid, 'dialog');
        };
        if(closetime) {
            showPrompt(null, null, '<i>' + msg + '</i>', closetime * 1000, 'popuptext');
            return;
        }
        locationtime = isUndefined(locationtime) ? '' : locationtime;
        if(locationtime) {
            leftmsg = locationtime + ' ';
            showDialogST = setTimeout(closefunc, locationtime * 1000);
            showconfirm = 0;
        }
        confirmtxt = confirmtxt ? confirmtxt : confirmtxtdefault;
        canceltxt = canceltxt ? canceltxt : 'cancel';

        if(menuObj) hideMenu('fwin_dialog', 'dialog');
        menuObj = document.createElement('div');
        menuObj.style.display = 'none';
        menuObj.className = 'fwinmask';
        menuObj.id = menuid;
        $('append_parent').appendChild(menuObj);
        var hidedom = '';
        if(!BROWSER.ie) {
            hidedom = '<style type="text/css">object{visibility:hidden;}</style>';
        }
        var s = hidedom + '<table cellpadding="0" cellspacing="0" class="fwin"><tr><td class="t_l"></td><td class="t_c"></td><td class="t_r"></td></tr><tr><td class="m_l">&nbsp;&nbsp;</td><td class="m_c"><h3 class="flb"><em>';
        s += t ? t : '';
        s += '</em><span><a href="javascript:;" id="fwin_dialog_close" class="flbc" onclick="hideMenu(\'' + menuid + '\', \'dialog\')" title="">close</a></span></h3>';
        if(mode == 'info') {
            s += msg ? msg : '';
        } else {
            s += '<div class="c altw"><div class="' + (mode == 'alert' ? 'alert_error' : (mode == 'right' ? 'alert_right' : 'alert_info')) + '"><p>' + msg + '</p></div></div>';
            s += '<p class="o pns">' + (leftmsg ? '<span class="z xg1">' + leftmsg + '</span>' : '') + (showconfirm ? '<button id="fwin_dialog_submit" value="true" class="pn pnc"><strong>'+confirmtxt+'</strong></button>' : '');
            s += mode == 'confirm' ? '<button id="fwin_dialog_cancel" value="true" class="pn" onclick="hideMenu(\'' + menuid + '\', \'dialog\')"><strong>'+canceltxt+'</strong></button>' : '';
            s += '</p>';
        }
        s += '</td><td class="m_r"></td></tr><tr><td class="b_l"></td><td class="b_c"></td><td class="b_r"></td></tr></table>';
        menuObj.innerHTML = s;
        if($('fwin_dialog_submit')) $('fwin_dialog_submit').onclick = function() {
            if(typeof func == 'function') func();
            else eval(func);
        };
        if($('fwin_dialog_cancel')) {
            $('fwin_dialog_cancel').onclick = function() {
                if(typeof funccancel == 'function') funccancel();
                else eval(funccancel);
                hideMenu(menuid, 'dialog');
            };
            $('fwin_dialog_close').onclick = $('fwin_dialog_cancel').onclick;
        }
        showMenu({'mtype':'dialog','menuid':menuid,'duration':3,'pos':'00','zindex':JSMENU['zIndex']['dialog'],'cache':0,'cover':cover});
        try {
            if($('fwin_dialog_submit')) $('fwin_dialog_submit').focus();
        } catch(e) {}
    }
</script>