<?php exit('xigua_sf');?>
{block html}
<style>
.buylocked a{text-decoration:none}
.buylocked{text-align:center;margin-bottom:10px;padding:20px 0}
.buynowtip{font-size: 16px;color: #909090;}
a.buynowsf{display:inline-block;height:34px;line-height:34px;padding: 0 25px;font-size: 16px;text-align: center;vertical-align: middle;color:#fff!important;border-radius:5px;background:$clr;margin:0 auto}
.sflist p{font-size:16px;text-align:center;color:#909090;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAABAQMAAAAGv++CAAAABlBMVEX////Z2dl4b8nnAAAAAXRSTlMAQObYZgAAABRJREFUeNpj+E8Y/GBABYxE6PkAAHcsR6Qt8qYTAAAAAElFTkSuQmCC) no-repeat center center;}
.sflist p a{color:#627C97;font-size:16px}
.sflist ul{margin:0 auto;text-align:center}
.sflist ul li{ display:inline-block;margin: 0 5px 5px 0;vertical-align:top;overflow:hidden}
.sflist ul li img{width:32px;height:32px;max-height:32px;display:block;border-radius:50%;margin:0!important;;padding:0!important;}
.extlink,.sflist p,.sflist ul{margin-top:10px;display:block;color:#909090}
.sflist{padding-top:5px; max-width: 715px;margin: 0 auto;}</style ><div class="buylocked cl"><div class="buynowtip">$tip</div><div class="extlink">$extlink</div>$listhtmldiv</div>
{/block}