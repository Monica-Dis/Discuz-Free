<?php exit('xigua_sf');?>
{block html}
<div id="xsf_c" class="exfm cl" style="display:$show;"><!--{if !$disable}--> $shou: <input type="text" id="xsfrmb" name="xsfrmb" class="px pxs" value="{$showprice}" > $uiam <!--{else}-->$shou:<input type="hidden" id="xsfrmb" name="xsfrmb" value="{$showprice}" ><span style="font-size:22px;color:orangered;">$showprice</span> $uiam<!--{/if}--></div>
{/block}