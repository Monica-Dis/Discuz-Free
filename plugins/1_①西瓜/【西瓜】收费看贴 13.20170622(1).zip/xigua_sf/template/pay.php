<?php exit;?>
<!--{template common/header}-->
<style>
    .iinfoth{width:160px;text-align:center;padding-bottom:10px}
</style>
<h3 class="flb"><em>$config[goumai]</em>
    <!--{if $_G['inajax']}--><span><a href="javascript:void(0);" class="flbc" onclick="hideWindow('payfor')" title="{lang close}">{lang close}</a></span><!--{/if}-->
</h3>
<div>
    <table class="table"  style="width:200px">
        <tbody>
        <tr>
            <td class="iinfoth">
                <img src='$src' />
            </td>
        </tr>
        <tr>
            <td class="iinfoth"><p class="xg1">$config[saomafu]</p></td>
        </tr>
        </tbody>
    </table>
</div>

<script>
    var wechat_checkST = null, wechat_checkCount = 0;
    function wechat_checkstart() {
        setInterval(function () {
            wechat_check();
        }, 2000);
    }
    function wechat_check() {
        var x = new Ajax();
        x.get('plugin.php?id=xigua_sf:check&pid={$_GET[pid]}', function(s, x) {
            s = trim(s);
            if(s == 'done') {
                window.location.href = window.location.href;
            }
        });
    }
    wechat_checkstart();
</script>
<!--{template common/footer}-->