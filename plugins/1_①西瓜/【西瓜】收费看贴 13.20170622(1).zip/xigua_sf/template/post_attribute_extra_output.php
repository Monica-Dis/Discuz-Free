<?php exit('xigua_sf');?>
{block html}
<label id="xsf_b" onclick="showExtra('xsf')" class="$class"><span class="$class" id="xsf_chk">$fufei</span></label>
<script>setTimeout(function(){showExtra('xsf');}, 1000);</script>
{/block}