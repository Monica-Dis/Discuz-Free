<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/22
 * Time: 16:38
 */

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!function_exists('curl_init')){
    exit('Missing curl extension!');
}
if(!function_exists('openssl_csr_export')){
    exit('Missing openssl extension!');
}

$pluginversion = '20160201';

global $_G;
if(!$_G['cache']['plugin']){
    loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_sf'];
$authkey = $_G['config']['security']['authkey'];

include_once libfile('function/cache');

define('SF_APPID', trim($config['appid']));
define('SF_MCHID', trim($config['shanghuid']));
define('SF_APPSECRET', trim($config['appsecert']));
define('SF_WXPAY_KEY', trim($config['key']));
define('SF_NOTIFY_URL', $_G['siteurl'].'source/plugin/xigua_sf/notify_wx.php');
define('INSFWECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);
$repath = './source/plugin/xigua_sf/cache/';


include_once DISCUZ_ROOT."source/plugin/xigua_sf/lib/wxpay/lib/WxPay.Config.php";
include_once DISCUZ_ROOT."source/plugin/xigua_sf/lib/wxpay/lib/WxPay.Api.php";
include_once DISCUZ_ROOT."source/plugin/xigua_sf/lib/wxpay/example/WxPay.JsApiPay.php";
include_once DISCUZ_ROOT.'source/plugin/xigua_sf/lib/wxpay/example/WxPay.NativePay.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_sf/lib/wxpay/example/log.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_sf/lib/wxpay/lib/WxPay.Data.php';
$ckey  = substr(md5('sfwechatopenid5'.$_G['siteurl'].SF_APPID.SF_MCHID.SF_APPSECRET), 0, 8);

function current_url_sf() {
    $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
    $php_self = $_SERVER['PHP_SELF'] ? safe_replace_sf($_SERVER['PHP_SELF']) : safe_replace_sf($_SERVER['SCRIPT_NAME']);
    $path_info = isset($_SERVER['PATH_INFO']) ? safe_replace_sf($_SERVER['PATH_INFO']) : '';
    $relate_url = isset($_SERVER['REQUEST_URI']) ? safe_replace_sf($_SERVER['REQUEST_URI']) : $php_self.(isset($_SERVER['QUERY_STRING']) ? '?'.safe_replace_sf($_SERVER['QUERY_STRING']) : $path_info);
    return $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '').$relate_url;
}

function safe_replace_sf($string) {
    $string = str_replace('%20','',$string);
    $string = str_replace('%27','',$string);
    $string = str_replace('%2527','',$string);
    $string = str_replace('*','',$string);
    $string = str_replace('"','&quot;',$string);
    $string = str_replace("'",'',$string);
    $string = str_replace('"','',$string);
    $string = str_replace(';','',$string);
    $string = str_replace('<','&lt;',$string);
    $string = str_replace('>','&gt;',$string);
    $string = str_replace("{",'',$string);
    $string = str_replace('}','',$string);
    $string = str_replace('\\','',$string);
    return $string;
}

function js_reajaxget_sf($link, $ext)
{
    return '<a href="' . $link . '" onclick="ajaxget(\'' . $link . '\', \'gridtable\');return false;"' . $ext . '>';
}

function ToUrlParams_sf($urlObj)
{
    $buff = "";
    foreach ($urlObj as $k => $v)
    {
        $buff .= $k . "=" . $v . "&";
    }

    $buff = trim($buff, "&");
    return $buff;
}

function init_xigua_sf(){
}
init_xigua_sf();