<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2015/11/3
 * Time: 15:09
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_sf_order extends discuz_table
{
    CONST PAYWAIT = 0;
    CONST PAYSUCCESS = 1;
    CONST PAYFAUIL = 2;
    CONST WXPAY = 'WECAHT';
    CONST ALIPAY = 'ALIPAY';

    public function __construct()
    {
        $this->_table = 'xigua_sf_order';
        $this->_pk = 'order_id';

        parent::__construct();
    }

    public function get_order_id($sfid, $fromuid, $baseprice, $touid, $tid, $pid, $subject)
    {
        $order = array(
            'order_id' => date('YmdHis') . mt_rand(1000000, 9999999),
            'sfid' => $sfid,
            'touid' => $touid,
            'fromuid' => $fromuid,
            'fromopenid' => '',
            'baseprice' => $baseprice,
            'payupts' => 0,
            'crts' => time(),
            'paystatus' => self::PAYWAIT,
            'tid' => $tid,
            'pid' => $pid,
            'subject' => $subject,

        );
        if ($this->insert($order)) {
            return $order['order_id'];
        }
    }

    public function fetch_by_order_id($order_id)
    {
        return $this->fetch($order_id);
    }

    public function finish_order_pay($order_id, $fromopenid, $order_sn, $paymethod = self::WXPAY)
    {
        return $this->update($order_id, array(
            'paystatus' => self::PAYSUCCESS,
            'fromopenid' => $fromopenid,
            'payupts' => time(),
            'paymethod' => $paymethod,
            'order_sn'  => $order_sn,
        ));
    }


    public function clear_order()
    {
        return DB::delete($this->_table, array('paystatus' => self::PAYWAIT));
    }

    public function delete_order($ids)
    {
        return DB::query('DELETE FROM %t WHERE order_id IN (%n)', array($this->_table, $ids));
    }


    public function fetch_all_bypage($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_count_bypage()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function check_paid($fromuid, $pid){
        if(!$fromuid){
            return;
        }
        return DB::fetch_first('SELECT * FROM %t WHERE fromuid=%d AND pid=%d AND paystatus=%d LIMIT 1', array(
            $this->_table,
            $fromuid,
            $pid,
            self::PAYSUCCESS
        ));
    }



    public function fetch_all_paid_bypage($uid, $pid, $start_limit, $lpp)
    {
        if($pid){
            $p = " AND pid=$pid ";
        }else{
            $p = '';
        }
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " WHERE touid=$uid AND paystatus=".self::PAYSUCCESS." $p ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $v) {
            if($v['fromuid']){
                $uids[$v['fromuid']] = $v['fromuid'];
            }
            /*if($v['touid']){
                $uids[$v['touid']] = $v['touid'];
            }*/
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }

        foreach ($result as $index => $item) {
            $result[$index]['fromusername'] = $users[$item['fromuid']]['username'];
            $result[$index]['fromuseravatar'] = avatar($item['fromuid'], 'middle', true);

            /*$result[$index]['tousername']  = $users[$item['touid']]['username'];
            $result[$index]['touseravatar'] = avatar($item['touid'], 'middle', true);*/
        }
        return $result;
    }

    public function fetch_count_paid_bypage($uid)
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table). " WHERE touid=$uid AND paystatus=".self::PAYSUCCESS);
        return $result;
    }

}