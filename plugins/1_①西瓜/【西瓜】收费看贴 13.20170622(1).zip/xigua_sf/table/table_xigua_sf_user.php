<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2015/11/3
 * Time: 15:09
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_sf_user extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_sf_user';
        $this->_pk = 'uid';

        parent::__construct();
    }

    public function init_user($uid)
    {
        if(!DB::result_first('SELECT uid FROM %t WHERE uid=%d LIMIT 1', array($this->_table, $uid))){
            return $this->insert(array('uid' => $uid));
        }else{
            return true;
        }
    }

    public function add_notsettled($price, $uid)
    {

      /* $price = $price/100;
        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($uid, 'money', $price);
        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
            'uid'  => $uid,
            'crts' => TIMESTAMP,
            'size' => $price,
            'note' => '',
            'link' => "",
        ));
        return ''; */

        /*global $_G;
        $shui = intval(round($price*($_G['cache']['plugin']['xigua_re']['bili']/100)));
        $getprice = $price - $shui;
        return C::t('#xigua_re#xgre_user')->update_notsettled($getprice, $uid);*/

        return DB::query('UPDATE %t SET notsettled=notsettled+%d,total=total+%d,times=times+1 WHERE uid=%d LIMIT 1', array(
            $this->_table,
            $price,
            $price,
            $uid
        ));
    }

    public function add_settled($price, $uid)
    {
        return DB::query('UPDATE %t SET notsettled=notsettled-%d,settled=settled+%d WHERE uid=%d LIMIT 1', array(
            $this->_table,
            $price,
            $price,
            $uid
        ));
    }
}