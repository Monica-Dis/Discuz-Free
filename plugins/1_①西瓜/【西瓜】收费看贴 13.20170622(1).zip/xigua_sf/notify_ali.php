<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/4/27
 * Time: 11:25
 */
define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/xigua_sf/', '',$_G['siteurl'] );

if($_GET['back']){
    dheader('location: '.$_G['siteurl'].$_GET['back']);
}
require_once DISCUZ_ROOT.'./api/trade/api_alipay.php';

global $_G;
if(!$_G['cache']['plugin']){
    loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_sf'];

$notifydata = sfali_notifycheck();

if($notifydata['validator']) {

    $order_id = $notifydata['order_no'];
    $postprice = intval($notifydata['price']*100);
//    $order = C::t('forum_order')->fetch($orderid);
//    $order     = C::t('#xigua_sf#xigua_sf_order')->fetch_by_order_id($order_id);

    $order     = C::t('#xigua_sf#xigua_sf_order')->fetch_by_order_id($order_id);
    if(!$postprice){
        $postprice = $order['baseprice'];
    }


    if(
        $order &&
        $order['paystatus'] == table_xigua_sf_order::PAYWAIT
    ) {
        C::t('#xigua_sf#xigua_sf_order')->finish_order_pay($order_id, '', $notifydata['trade_no'], table_xigua_sf_order::ALIPAY);
        C::t('#xigua_sf#xigua_sf_user')->add_notsettled($postprice, $order['touid']);
        C::t('#xigua_sf#xigua_sf')->add_total($order['sfid']);

        if($order['fromuid']){
            $fromusername = DB::result_first('SELECT username FROM %t WHERE uid=%d', array('common_member', $order['fromuid']));
        }

        $ROW = C::t('#xigua_sf#xigua_sf')->fetch($order['sfid']);
        $subject = DB::result_first("SELECT subject FROM ".DB::table('forum_thread')." WHERE tid='$ROW[tid]' LIMIT 1");

        notification_add(
            $order['touid'],
            'system',
            lang('plugin/xigua_sf', 'notice1'),
            array(
                'from'     => $fromusername,
                'linkword' => lang('plugin/xigua_sf', 'goumaile'),
                'subject'  => $subject,
                'url'      => 'home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting',
            ),
            1
        );
        dheader('location: '.$_G['siteurl'].'forum.php?mod=viewthread&tid='.$ROW['tid']);
    }

}

if($notifydata['location']) {
    $order_id = $notifydata['order_no'];
    $order     = C::t('#xigua_sf#xigua_sf_order')->fetch_by_order_id($order_id);
    $ROW = C::t('#xigua_sf#xigua_sf')->fetch($order['sfid']);

    if($ROW['tid']){
        dheader('location: '.$_G['siteurl'].'forum.php?mod=viewthread&tid='.$ROW['tid']);
    }else{
        dheader('location: '.$_G['siteurl'].$_GET['back']);
    }
} else {
    exit($notifydata['notify']);
}




function sfali_notifycheck() {
    global $_G;
    if(!empty($_POST)) {
        $notify = $_POST;
        $location = FALSE;
    } elseif(!empty($_GET)) {
        $notify = $_GET;
        $location = TRUE;
    } else {
        exit('fail');
    }
    unset($notify['diy']);

    if(!$_REQUEST['notify_id']&& $_REQUEST['notify_data']) {
        $notify = FromXml($_REQUEST['notify_data']);
    }

    $url = "http://notify.alipay.com/trade/notify_query.do?partner=".DISCUZ_PARTNER."&notify_id=".$notify['notify_id'];
    $retcheck = file_get_contents($url);
    if(!$retcheck && function_exists('dfsockopen')){
        $retcheck = dfsockopen($url);
    }
    if($notify['notify_id'] && $retcheck !== 'true') {
        exit('fail');
    }

    if($notify['notify_id'] && $_REQUEST['notify_data']){
        return array(
            'validator'  => TRUE,
            'status'     => trade_getstatus(!empty($notify['refund_status']) ? $notify['refund_status'] : $notify['trade_status'], 1),
            'order_no'   => $notify['out_trade_no'],
            'price'      => $notify['price'] ? $notify['price'] : $notify['total_fee'],
            'trade_no'   => $notify['trade_no'],
            'notify'     => 'success',
            'location'   => $location
        );
    }

    if(!DISCUZ_SECURITYCODE) {
        exit('fail');
    }
    ksort($notify);
    $sign = '';
    foreach($notify as $key => $val) {
        if($key != 'sign' && $key != 'sign_type') $sign .= "&$key=$val";
    }
    if($notify['sign'] != md5(substr($sign,1).DISCUZ_SECURITYCODE)) {
        exit('fail');
    }

    return array(
        'validator'  => TRUE,
        'status'     => trade_getstatus(!empty($notify['refund_status']) ? $notify['refund_status'] : $notify['trade_status'], 1),
        'order_no'   => $notify['out_trade_no'],
        'price'      => $notify['price'] ? $notify['price'] : $notify['total_fee'],
        'trade_no'   => $notify['trade_no'],
        'notify'     => 'success',
        'location'   => $location
    );
}

function FromXml($xml)
{
    //��XMLתΪarray
    //��ֹ�����ⲿxmlʵ��
//        libxml_disable_entity_loader(true);
    return json_decode(json_encode(simplexml_load_string($xml, 'SimpleXMLElement', LIBXML_NOCDATA)), true);
}