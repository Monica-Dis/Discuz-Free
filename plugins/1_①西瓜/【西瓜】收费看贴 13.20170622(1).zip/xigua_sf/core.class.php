<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/4/20
 * Time: 14:27
 */
class plugin_xigua_sf
{
    public function post_message($value)
    {
        global $_G;

        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }

        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return FALSE;
        }


        $param = $value['param'];
        $tid = $param[2]['tid'];
        $pid = $param[2]['pid'];
        $fid = $param[2]['fid'];

        if(!$config['allowrep']){
            $tmp = DB::fetch_first( 'SELECT pid FROM %t WHERE pid=%d AND first=1 LIMIT 1',
                array(table_forum_post::get_tablename('tid:' . $tid), $pid)
            );
            if(!$tmp){
                return false;
            }
        }



        $p = intval(abs(floatval($_GET['xsfrmb'])) * 100);
        if($_absprice = trim($config['absprice'])){
            $absprice = array();
            foreach (explode("\n", $_absprice) as $tmpv) {
                list($_fid, $_price) = explode('=', trim($tmpv));
                $absprice[$_fid] = $_price;
            }
            if($absprice && $absprice[$_G['fid']]>0){
                $p = intval($absprice[$_G['fid']] * 100);
            }
        }


        if ( strtolower($_SERVER['REQUEST_METHOD']) == 'post' && isset($_GET['xsfrmb']) ) {
            if($_GET['xsfrmb']){
                $data = array(
                    'uid' => $_G['uid'],
                    'tid' => $tid,
                    'pid' => $pid,
                    'fid' => $fid,
                    'ts' => time(),
                    'price' => $p,
                );

//                C::t('forum_thread')->update($tid, array('price'=> $p*100));
                C::t('#xigua_sf#xigua_sf')->doinsert($data);
                C::t('#xigua_sf#xigua_sf_user')->init_user($_G['uid']);
            }else{
//                C::t('forum_thread')->update($tid, array('price'=> 0));
                C::t('#xigua_sf#xigua_sf')->dodel_by_pid($pid);
            }
        }
    }

    public function discuzcode($args)
    {
        global $_G, $special, $sortid, $adveditor, $extra, $enctype, $noticeauthor, $noticetrimstr, $noticeauthormsg, $reppid, $specialextra, $postinfo, $thread, $quotemessage, $isfirstpost, $typeid, $name, $thread, $isorigauthor, $rushreply, $editorid, $editor, $seccodecheck, $swfconfig, $nofooter, $sectpl, $secqaacheck, $pid, $tid;

        if (!$tid && $_G['tid']) {
            $tid = $_G['tid'];
        }
        if (!$pid && $_G['pid']) {
            $pid = $_G['pid'];
        }

        if(
            strtolower($_SERVER['REQUEST_METHOD']) != 'post' &&
            $args['caller'] == 'discuzcode' &&
            $pid
        ){
            /*$config = $_G['cache']['plugin']['xigua_sf'];
            $tmp = DB::fetch_first( 'SELECT pid FROM %t WHERE pid=%d AND first=1 LIMIT 1',
                array(table_forum_post::get_tablename('tid:' . $tid), $pid)
            );
            if($tmp && $_absprice = trim($config['absprice'])){
                $absprice = array();
                foreach (explode("\n", $_absprice) as $tmpv) {
                    list($_fid, $_price) = explode('=', trim($tmpv));
                    $absprice[$_fid] = $_price;
                }
                if($absprice && $absprice[$_G['fid']]>0){
                    if($absprice && $absprice[$_G['fid']]>0){
                        $p = intval($absprice[$_G['fid']] * 100);
                        $tmp = DB::fetch_first('select * from %t where tid=%d', array('forum_thread', $tid));

                        $data = array(
                            'uid' => $tmp['authorid'],
                            'tid' => $tid,
                            'pid' => $pid,
                            'fid' => $_G['fid'],
                            'ts' => time(),
                            'price' => $p,
                        );

                        C::t('#xigua_sf#xigua_sf')->doinsert($data);
                        C::t('#xigua_sf#xigua_sf_user')->init_user($tmp['authorid']);
                    }

                }
            }*/
            /*$reg = array(
                'sj'  =>  '/\b(\+?86-?)?(18|15|13)[0-9]{9}\b/',
                'tel' =>  '/\b(010|02\d{1}|0[3-9]\d{2})-\d{7,9}(-\d+)?\b/',
                '400' =>  '/\b400(-\d{3,4}){2}\b/',
            );

            foreach ($reg as $v) {
                $_G['discuzcodemessage'] = preg_replace($v, '[sf]\\0[/sf]', $_G['discuzcodemessage']);
            }*/

            if( $ROW = C::t('#xigua_sf#xigua_sf')->fetch_by_pid($pid) ){
                $_G['cache']['plugin']['xigua_re'] = array();
                $price = $ROW['price']/100;

                include_once DISCUZ_ROOT .'source/plugin/xigua_sf/common.php';
                $config = $_G['cache']['plugin']['xigua_sf'];
                $config['tip']  = str_replace('{price}', $price, $config['tip']);

                $hasbuy = C::t('#xigua_sf#xigua_sf_order')->check_paid($_G['uid'], $pid);

                if(in_array($_G['groupid'], (array)unserialize($config['freegroup']) )){
                    $hasbuy['crts'] = time();
                }

                $replace = 0;
                if($_G['uid']==$ROW['uid']){ //is master

                    $tip = str_replace(array('{price}', '{total}'), array($price, $ROW['total']), lang('plugin/xigua_sf', 'shoufeitip'));

                } else if($hasbuy){  //has buy

                    $tip = lang('plugin/xigua_sf', 'hasbuy');
                    $extlink = lang('plugin/xigua_sf', 'hasbuyts'). dgmdate($hasbuy['crts'], 'u');

                }else{
                    $replace = 1;
                    if(checkmobile()){

                        $forumtid = urlencode($_G['siteurl'].'forum.php?mod=viewthread&tid='.$tid);
                        if(INSFWECHAT && $config['key']){
                            $openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
                            if(!$_G['inajax']&& !defined('IN_MOBILE_API')  &&!$_GET['version']){
                                $jq = 1;
                                if(! $openid){
                                    $tools = new JsApiPaySF();
                                    $opendata = $tools->GetOpenid();
                                    if($openid = $opendata['openid']){
                                        dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 8640000);
                                    }
                                }
                            }else{
                                $jq = 0;
                                if(! $openid){
                                    $exjs = "window.location.href='$_G[siteurl]plugin.php?id=xigua_sf:redirect&backurl=".urlencode("$_G[siteurl]forum.php?mod=viewthread&tid=".$tid) ."';";
                                }
                            }
                            if(!$_G['uid']){
                                $extlink = "<a class='buynowsf' id=\"sfitem\" href=\"member.php?mod=logging&action=login&referer=$forumtid\">{$config['buynow']}</a>";
                            }else{
                                $extlink = '';
                                include template('xigua_sf:extlink');
                            }
                        }else if($config['ali']){
                            if(!$_G['uid']) {
                                $extlink = "<a class='buynowsf' href=\"member.php?mod=logging&action=login&referer=$forumtid\" id=\"alipaybtn\">{$config['buynow']}</a>";
                            }else{
                                $extlink = "<a class='buynowsf' href=\"plugin.php?id=xigua_sf:pay&tid={$tid}&pid={$pid}&ac=pc\" id=\"alipaybtn\">{$config['buynow']}</a>";
                            }
                        }

                    }else{

                        if($config['key']){
                            $ext2 = "<a href=\"javascript:void(0);\" onclick=\"showWindow('payfor', 'plugin.php?id=xigua_sf:pay&tid={$tid}&pid={$pid}&type=wx', 'get', 0,{cover:1});\"><img src=\"source/plugin/xigua_sf/static/wec.png\"></a>";
                        }
                        if($config['ali']){
                            $ext1 = "<a href=\"plugin.php?id=xigua_sf:pay&tid={$tid}&pid={$pid}&ac=pc\" id=\"alipaybtn\"><img src=\"source/plugin/xigua_sf/static/alp.png\"></a>";
                        }

                        if(!$_G['uid']){
                            $ext1 = $ext1 ? '<a href="javascript:void(0);" onclick="showWindow(\'login\', \'member.php?mod=logging&action=login\');"><img src="source/plugin/xigua_sf/static/alp.png"></a>' : '';
                            $ext2 = $ext2 ? '<a href="javascript:void(0);" onclick="showWindow(\'login\', \'member.php?mod=logging&action=login\');"><img src="source/plugin/xigua_sf/static/wec.png"></a>' : '';
                        }
                        $extlink = $ext1.$ext2;
                    }
                    $tip = trim($config['tip']);
                }


                $list = C::t('#xigua_sf#xigua_sf_order')->fetch_all_paid_bypage($ROW['uid'],$ROW['pid'], 0, 100);
                $listhtml = '';
                foreach ($list as $item) {
                    $listhtml .= "<li><a href='home.php?mod=space&uid={$item['fromuid']}&do=profile' target='_blank' rel='nofollow' title='{$item['fromusername']}'><img src='{$item['fromuseravatar']}' /> </a></li>";
                }
                $clr = $config['buynowcolor'] ? $config['buynowcolor'] : '#D75847';
                $hasbuynum = lang('plugin/xigua_sf', 'hasbuynum');

                $listhtmldiv = $ROW['total'] ? "<div class=\"sflist\"><p>{$ROW['total']}$hasbuynum</p><ul class=\"cl\">$listhtml</ul></div>" : '';

                $html = '';
                if($GLOBALS['returnsf'] || defined('IN_MOBILE')){
                    include DISCUZ_ROOT.'source/plugin/xigua_sf/template/touch/buylocked_tpl.php';
                }else{
                    include template('xigua_sf:buylocked');
                }

                //output
                if($replace == 1){
                    global $skipaids;
                    $hashide = 0;

                    if(stripos($_G['discuzcodemessage'], '[/sf]')===false){
                        $_G['discuzcodemessage'] = self::get_ignore_js($html);
                        foreach(C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$_G['tid'], 'pid', $_G['forum_attachpids']) as $attach) {
                            $skipaids[] = $attach['aid'];
                        }
                    }else{
                        if(!$_G['username']){
                            $_G['username'] = lang('template', 'guest');
                        }

                        $tstyle = 'style="background:#fff4dd;padding:15px;margin:10px 0;color:#fa7d3c;font-size:17px;clear:both"';
                        $t = "<div $tstyle>{$_G['username']}".lang('plugin/xigua_sf', 'hidefor')."</div>";
                        if(preg_match("/\[sf\](.*?)\[\/sf\]/is", $_G['discuzcodemessage'], $maids)){
                            if($maids[1] && preg_match_all("/\[attach(img)?\](\d+)\[\/attach(img)?\]/is", $maids[1], $disaids)){
                                if($disaids[2]){
                                    $hashide = 1;
                                    $skipaids[] = $disaids[2];
//                                    $skipaids = array_intersect($disaids[2], $skipaids);
                                }
                            }
                        }
                        $_G['discuzcodemessage'] = preg_replace("/\[sf\](.*?)\[\/sf\]/is", $t, $_G['discuzcodemessage']).self::get_ignore_js($html);
                    }
                }else{
                    $_G['discuzcodemessage'] = str_replace(array('[sf]','[/sf]'), '', $_G['discuzcodemessage']);
                    $_G['discuzcodemessage'] = self::get_ignore_js($html).$_G['discuzcodemessage'];
                }

                if($GLOBALS['returnsf']){
                    return array(
                        'html'     => $_G['discuzcodemessage'],
                        'skipaids' => $skipaids
                    );
                }
            }
        }

    }

    public static function get_ignore_js($html){
        $html = str_replace(array("\n","\r", "  ", '   '), '', $html);
        return "<ignore_js_op>$html</ignore_js_op>";
    }
}

class plugin_xigua_sf_forum extends plugin_xigua_sf
{
    public function post_attribute_extra_output()
    {
        global $_G;

        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }

        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return FALSE;
        }

        $pid = intval($_G['pid'] ? $_G['pid'] : $_GET['pid']);

        $tid = intval($_G['tid'] ? $_G['tid'] : $_GET['tid']);
        if($this->retnull){
            return '';
        }

        if($pid && $ROW = C::t('#xigua_sf#xigua_sf')->fetch_by_pid($pid)){
            $this->showprice = $ROW['price']/100;
        }
        $class = $this->showprice ? 'a' : '';
        $fufei = lang('plugin/xigua_sf', 'fufei');

        $html = '';
        include template('xigua_sf:post_attribute_extra_output');
        return $html;
    }

    public function post_attribute_extra_body_output()
    {
        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }
        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return FALSE;
        }

        $show = 'none';
        $showprice = $this->showprice;
        if($showprice){
            $show = 'block';
        }
        $uiam = lang('plugin/xigua_sf', 'yuan');
        $shou = lang('plugin/xigua_sf', 'shou');


        $disable = false;
        if($_absprice = trim($config['absprice'])){
            $absprice = array();
            foreach (explode("\n", $_absprice) as $tmpv) {
                list($_fid, $_price) = explode('=', trim($tmpv));
                $absprice[$_fid] = $_price;
            }
            if($absprice && $absprice[$_G['fid']]>0){
                $showprice = $absprice[$_G['fid']];
                $disable = true;
            }
        }

        $html = '';
        include template('xigua_sf:post_attribute_extra_body_output');
        return $html;
    }

    public function post_editorctrl_left()
    {

        global $_G;

        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }

        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return FALSE;
        }

        $pid = intval($_G['pid'] ? $_G['pid'] : $_GET['pid']);

        $tid = intval($_G['tid'] ? $_G['tid'] : $_GET['tid']);
        if(!$config['allowrep']) {
            if ($tid) {
                $tmp = DB::fetch_first('SELECT pid FROM %t WHERE pid=%d AND first=1 LIMIT 1',
                    array(table_forum_post::get_tablename('tid:' . $tid), $pid)
                );
                if (!$tmp) {
                    $this->retnull = 1;
                    return '';
                }
            }
        }

        $lang = lang('plugin/xigua_sf', 'icon');
        $button = '';
        include template('xigua_sf:post_editorctrl_left');
        return $button;
    }
}

class mobileplugin_xigua_sf extends plugin_xigua_sf_forum
{

}
class mobileplugin_xigua_sf_forum extends plugin_xigua_sf_forum
{


    public static function post_bottom_mobile()
    {
        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }
        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return '';
        }


        $pid = intval($_G['pid'] ? $_G['pid'] : $_GET['pid']);

        $tid = intval($_G['tid'] ? $_G['tid'] : $_GET['tid']);
        if(!$config['allowrep']) {
            if ($tid) {
                $tmp = DB::fetch_first('SELECT pid FROM %t WHERE pid=%d AND first=1 LIMIT 1',
                    array(table_forum_post::get_tablename('tid:' . $tid), $pid)
                );
                if (!$tmp) {
                    return '';
                }
            }
        }

        $price = '0';
        if($pid && $ROW = C::t('#xigua_sf#xigua_sf')->fetch_by_pid($pid)){
            $price = $ROW['price']/100;
        }

        $disable = false;
        if($_absprice = trim($config['absprice'])){
            $absprice = array();
            foreach (explode("\n", $_absprice) as $tmpv) {
                list($_fid, $_price) = explode('=', trim($tmpv));
                $absprice[$_fid] = $_price;
            }
            if($absprice && $absprice[$_G['fid']]>0){
                $price = $absprice[$_G['fid']];
                $disable = true;
            }
        }


        $uiam = lang('plugin/xigua_sf', 'yuan');
        $shou = lang('plugin/xigua_sf', 'shou');
        $html = '';
        include template('xigua_sf:post_bottom_mobile');
        return $html;
    }
}

