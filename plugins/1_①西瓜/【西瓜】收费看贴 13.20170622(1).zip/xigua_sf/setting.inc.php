<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/4/28
 * Time: 18:16
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT .'source/plugin/xigua_sf/common.php';

if(submitcheck('amount')){
    $amount = abs(floatval($_GET['amount']));

    $user = C::t('#xigua_sf#xigua_sf_user')->fetch($_G['uid']);
    $user['notsettled'] = $user['notsettled'] /100;
    $user['settled'] =$user['settled'] /100;
    $user['total'] =$user['total'] /100;

    if($amount> $user['notsettled'] || !$amount){
        showmessage(lang('plugin/xigua_sf', 'amountwrong'), 'home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting');
    }
        //ctype

    updatemembercount($_G['uid'], array($config['ctype'] => $amount*$config['duibi']), true, 'CEC', 0, lang('plugin/xigua_sf', 'plear'), lang('plugin/xigua_sf', 'plear'));
    C::t('#xigua_sf#xigua_sf_user')->add_settled($amount*100, $_G['uid']);

    /*$tmp = C::t('#xigua_re#xgre_user')->fetch_user($_G['uid']);
    $re = WxPayApiSF::promotion(mt_rand(111111,999999), $tmp['openid'], $amount*100, diconv('����', CHARSET, 'UTF-8'));
    if(is_array($re['return_msg'])){
        $re['return_msg'] = var_export($re['return_msg'], TRUE);
    }
    $re['return_msg'] = diconv($re['return_msg'],'UTF-8', CHARSET);
    $re['err_code_des'] = diconv($re['err_code_des'],'UTF-8', CHARSET);
    if($re['result_code'] == 'SUCCESS'){
        C::t('#xigua_sf#xigua_sf_user')->add_settled($amount*100, $_G['uid']);
        showmessage(lang('plugin/xigua_sf', 'succeed1'), 'home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting');
    }else{
        showmessage($re['err_code_des'], 'home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting');
    }*/

    showmessage(lang('plugin/xigua_sf', 'succeed1'), 'home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting');

    exit;
}

if(submitcheck('orderlog', 1)){
    $page = max(1, intval(getgpc('page')));
    $lpp   = 10;
    $start_limit = ($page - 1) * $lpp;
    
    $res = C::t('#xigua_sf#xigua_sf_order')->fetch_all_paid_bypage($_G['uid'], 0, $start_limit, $lpp);
    $icount = C::t('#xigua_sf#xigua_sf_order')->fetch_count_paid_bypage($_G['uid']);
    $checkmobile = checkmobile();
    
    if(!$checkmobile){
        include_once template('common/header');
        $list = '<th>'.(lang('plugin/xigua_sf','wz')).'</th>';
    }
    
    $time = lang('plugin/xigua_sf','time');
    $user = lang('plugin/xigua_sf','user');
    $sr = lang('plugin/xigua_sf','sr');
    $yuan = lang('plugin/xigua_sf','yuan');
    $zanwu = lang('plugin/xigua_sf','zanwu');

    if($res){
        echo $checkmobile ? "" : "<tr><th>$time</th><th>$user</th>$list<th>$sr</th></tr>";

        $realpages = @ceil($icount / $lpp);
        $_G['gp_ajaxtarget'] = '';
        $multi = multi($icount, $lpp, $page, 'home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting&orderlog=1');
        $multi = preg_replace("/<a\shref=\"([\s\S]*?)\"(.*?)>/ies", "js_reajaxget_sf('\\1','\\2')", $multi);
        $multi = str_replace('\"', '"', $multi);


        foreach ($res as $v) {
            if($v['fromuid']){
                $uids[$v['fromuid']] = $v['fromuid'];
            }
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }

        foreach ($res as $v) {
            $baseprice = sprintf('%.2f', $v['baseprice']/100);

            $fromavatar = avatar($v['fromuid'], 'middle', true);

            if($checkmobile){
                $fromimg = "<img style=\"width:40px;height:40px;vertical-align:middle;border-radius:50%;display:block\" src=\"{$fromavatar}\"/>";
                $from = $users[$v['fromuid']]['username'];
                $from .= "<br>".date('m-d H:i', $v['crts']);
            }else{
                $from = '<img style="width:20px;height:20px;vertical-align:middle" src="'.$fromavatar.'"/> '.$users[$v['fromuid']]['username'];
            }

            echo $checkmobile ?
                "<tr><td>$fromimg</td><td align='left'>$from</td>".
                '<td><a href="forum.php?mod=viewthread&tid='.$v['tid'].'" target="_blank">'. $v['subject'].'</a></td>'.
                "<td><span style='font-size:20px'>{$baseprice}</span> {$yuan}</td></tr>" :

                ('<tr>'.
                '<td>'.($checkmobile ? date('m-d H:i', $v['crts']) : date('Y-m-d H:i:s', $v['crts'])).'</td>'.
                '<td>'. $from .'</td>'.
                '<td><a href="forum.php?mod=viewthread&tid='.$v['tid'].'" target="_blank">'. $v['subject'].'</a></td>'.
                '<td>'. $baseprice.$yuan.'</td>'.
                '</tr>');
        }

        if($checkmobile){
            $multi = str_replace('onclick=', 'ontouchstart=', $multi);
            $multi = str_replace('href=', 'data-href=', $multi);
            $multi = str_replace('ajaxget(', 'ajaxget11(', $multi);
            $multi = str_replace('class="pg"', 'class="pgbox"', $multi);
        }

        echo $multi ? '<tr><td colspan="5">'.$multi.'</td></tr>' : '';
    }else{
        echo <<<HTML
<tr><th><p class="text">$zanwu</p></th></tr>
HTML;
    }
    if(!$checkmobile) {
        include_once template('common/footer');
    }
    exit;
}

$user = C::t('#xigua_sf#xigua_sf_user')->fetch($_G['uid']);
$user['notsettled'] = $user['notsettled'] /100;
$user['settled'] = $user['settled'] /100;
$user['total'] =$user['total'] /100;

if(checkmobile()){
    include_once template('xigua_sf:setting');
    exit;
}