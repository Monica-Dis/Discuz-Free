<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/4/25
 * Time: 17:57
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_sf/common.php';

$pid = intval($_GET['pid']);
$tid = intval($_GET['tid']);
$ROW = C::t('#xigua_sf#xigua_sf')->fetch_by_pid($pid);
$price = $ROW['price'];

$subject = DB::result_first("SELECT subject FROM ".DB::table('forum_thread')." WHERE tid='$ROW[tid]' LIMIT 1");

$order_id = C::t('#xigua_sf#xigua_sf_order')->get_order_id($ROW['id'], $_G['uid'], $price, $ROW['uid'], $ROW['tid'], $ROW['pid'], $subject);

$subject = str_replace(array(' ', "\t"), '', $subject);
$subject = $body = diconv($subject, CHARSET, 'UTF-8');

if($_GET['type'] == 'wx'){
    $tools = new JsApiPaySF();

    $notify = new NativePaySF();
    $input = new WxPayUnifiedOrderSF();
    $input->SetBody($body);
    $input->SetAttach($body);
    $input->SetOut_trade_no($order_id);
    $input->SetTotal_fee($price);
    $input->SetTime_start(date("YmdHis"));
//    $input->SetTime_expire(date("YmdHis", time() + 3600));
    $input->SetGoods_tag($body);
    $input->SetNotify_url($_G['siteurl']. 'source/plugin/xigua_sf/notify_wx.php');
    $input->SetTrade_type(INSFWECHAT ? "JSAPI" : "NATIVE");

    if(INSFWECHAT || $_GET['iswx']){

        $openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
        $input->SetOpenid($openid);
        $order = WxPayApiSF::unifiedOrder($input);
        try
        {
            $jsApiParameters = $tools->GetJsApiParameters($order);
        }catch (Exception $e){
            $jsApiParameters = json_encode(array('error' => diconv($e->getMessage(), 'utf-8')));
        }
        echo $jsApiParameters;
        exit;
    }else{
        $input->SetProduct_id($order_id);
        $result = $notify->GetPayUrl($input);
        $url2 = $result["code_url"];

        include_once template('common/header');
        if(!$url2){
            echo diconv($result['return_msg'], 'utf-8');
        }else{
            $src= 'http://qr.topscan.com/api.php?&w=240&bg=ffffff&fg=333333&text='.urlencode($url2);
            include_once template('xigua_sf:pay');
        }
        include_once template('common/footer');
        exit;
    }
}else{

    require_once DISCUZ_ROOT.'./api/trade/api_alipay.php';
    $notify_url = $_G['siteurl']. 'source/plugin/xigua_sf/notify_ali.php';        //�������첽֪ͨҳ��·��

    if(checkmobile()){

        $alipay_config['partner']       = DISCUZ_PARTNER;
        $alipay_config['key']           = DISCUZ_SECURITYCODE;
        $alipay_config['sign_type']     = strtoupper('MD5');;
        $alipay_config['input_charset'] = strtolower('utf-8');
        $alipay_config['cacert']        = DISCUZ_ROOT.'source/plugin/xigua_sf/lib/alipay_m/cacert.pem';
        $alipay_config['transport']     = 'http';
        $seller_email                   = $_G['setting']['ec_account'];
        $format                         = "xml";  //���ظ�ʽ
        $v                              = "2.0";   //���ظ�ʽ
        $req_id                         = date('Ymdhis'); //�����
        $call_back_url = $notify_url; //ҳ����תͬ��֪ͨҳ��·��
        $merchant_url =  $notify_url;          //�����жϷ��ص�ַ

        //����ҵ�������ϸ
        $req_data = '<direct_trade_create_req><notify_url>' . $notify_url . '</notify_url><call_back_url>' . $call_back_url . '</call_back_url><seller_account_name>' . $seller_email . '</seller_account_name><out_trade_no>' . $order_id . '</out_trade_no><subject>' . $subject . '</subject><total_fee>' . ($price/100) . '</total_fee><merchant_url>' . $merchant_url . '</merchant_url></direct_trade_create_req>';

//����Ҫ����Ĳ������飬����Ķ�
        $para_token = array(
            "service" => "alipay.wap.trade.create.direct",
            "partner" => trim($alipay_config['partner']),
            "sec_id"    => trim($alipay_config['sign_type']),
            "format"	=> $format,
            "v"	=> $v,
            "req_id"	=> $req_id,
            "req_data"	=> $req_data,
            "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
        );
        include_once DISCUZ_ROOT.'source/plugin/xigua_sf/lib/alipay_m/AlipaySubmit.php';
        //��������
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestHttp($para_token);
        //URLDECODE���ص���Ϣ
        $html_text = urldecode($html_text);
        //����Զ��ģ���ύ�󷵻ص���Ϣ
        $para_html_text = $alipaySubmit->parseResponse($html_text);

        //��ȡrequest_token
        $request_token = $para_html_text['request_token'];

        //ҵ����ϸ
        $req_data = '<auth_and_execute_req><request_token>' . $request_token . '</request_token></auth_and_execute_req>';


        //����Ҫ����Ĳ������飬����Ķ�
        $parameter = array(
            "service" => "alipay.wap.auth.authAndExecute",
            "partner" => trim($alipay_config['partner']),
            "sec_id" => trim($alipay_config['sign_type']),
            "format"	=> $format,
            "v"	=> $v,
            "req_id"	=> $req_id,
            "req_data"	=> $req_data,
            "_input_charset"	=> trim(strtolower($alipay_config['input_charset']))
        );


        //��������
        $alipaySubmit = new AlipaySubmit($alipay_config);
        $html_text = $alipaySubmit->buildRequestForm($parameter, 'get', '');
        echo $html_text;

    }else{
        
        $args = array(
            'subject'           => $body,
            'body'              => $body,
            'service'           => 'trade_create_by_buyer',
            'partner'           => DISCUZ_PARTNER,
            'notify_url'        => $notify_url,
            'return_url'        => $notify_url,
            'show_url'          => $_G['siteurl'],
            '_input_charset'    => 'UTF-8',
            'out_trade_no'      => $order_id,
            'price'             => $price/100,
            'quantity'          => 1,
            'seller_email'      => $_G['setting']['ec_account'],
            'extend_param'      => 'isv^dz11'
        );
        if(DISCUZ_DIRECTPAY) {
            $args['service'] = 'create_direct_pay_by_user';
            $args['payment_type'] = '1';
        } else {
            $args['logistics_type'] = 'EXPRESS';
            $args['logistics_fee'] = 0;
            $args['logistics_payment'] = 'SELLER_PAY';
            $args['payment_type'] = 1;
        }
        $link = trade_returnurl($args);
        dheader('location: ' . $link);
        exit;
    }
}