<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z nemohou $
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginid = 'xigua_sf';

$Hooks = array(
    'viewthread_variables',
    'newthread_extraInfo',
    'newthread_variables',
);

$data = array();
foreach($Hooks as $Hook) {
    $data[] = array(
        $Hook => array(
            'plugin' => $pluginid,
            'include' => 'api.class.php',
            'class' => $pluginid,
            'method' => $Hook,
            'order' => 999,
        )
    );
}


$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_sf` (
 `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `tid` int(11) NOT NULL,
 `pid` int(11) NOT NULL,
 `fid` int(11) NOT NULL,
 `ts` int(11) NOT NULL,
 `price` int(11) unsigned NOT NULL,
 `total` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `tid` (`tid`),
 KEY `pid` (`pid`)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS `pre_xigua_sf_order` (
 `order_id` char(24) NOT NULL,
 `sfid` int(11) NOT NULL,
 `touid` int(11) unsigned NOT NULL,
 `fromuid` int(11) NOT NULL,
 `fromopenid` char(32) NOT NULL,
 `baseprice` int(11) unsigned NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `payupts` int(11) unsigned NOT NULL,
 `paystatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
 `tid` int(11) unsigned NOT NULL,
 `pid` int(11) unsigned NOT NULL,
 `subject` varchar(2000) NOT NULL,
 `paymethod` varchar(20) NOT NULL,
 `order_sn` varchar(80) NOT NULL,
 PRIMARY KEY (`order_id`),
 KEY `paystatus` (`paystatus`,`payupts`),
 KEY `sfid` (`sfid`)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS `pre_xigua_sf_user` (
 `uid` int(11) unsigned NOT NULL,
 `alipay` varchar(200) NOT NULL DEFAULT '',
 `wxpay` varchar(200) NOT NULL DEFAULT '',
 `total` int(10) NOT NULL DEFAULT '0',
 `settled` int(10) NOT NULL DEFAULT '0',
 `notsettled` int(10) NOT NULL DEFAULT '0',
 `times` int(10) unsigned NOT NULL DEFAULT '0',
 `settling` int(11) NOT NULL,
 PRIMARY KEY (`uid`)
) ENGINE=InnoDB;

ALTER TABLE `pre_xigua_sf` ADD INDEX(`ts`);
SQL;


@unlink(DISCUZ_ROOT . './source/plugin/xigua_sf/discuz_plugin_xigua_sf.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sf/discuz_plugin_xigua_sf_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sf/discuz_plugin_xigua_sf_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sf/discuz_plugin_xigua_sf_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sf/discuz_plugin_xigua_sf_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_sf/install.php');

runquery($sql);
require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);