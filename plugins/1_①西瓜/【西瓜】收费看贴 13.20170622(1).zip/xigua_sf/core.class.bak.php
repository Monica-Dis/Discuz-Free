<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-02-11
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/4/20
 * Time: 14:27
 */
class plugin_xigua_sf
{
    public function post_message($value)
    {
        global $_G;

        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }

        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return FALSE;
        }


        $param = $value['param'];
        $tid = $param[2]['tid'];
        $pid = $param[2]['pid'];
        $fid = $param[2]['fid'];

        $tmp = DB::fetch_first( 'SELECT pid FROM %t WHERE pid=%d AND first=1 LIMIT 1',
            array(table_forum_post::get_tablename('tid:' . $tid), $pid)
        );
        if(!$tmp){
            return false;
        }

        if ( strtolower($_SERVER['REQUEST_METHOD']) == 'post' && isset($_GET['xsfrmb']) ) {
            if($_GET['xsfrmb']){
                $data = array(
                    'uid' => $_G['uid'],
                    'tid' => $tid,
                    'pid' => $pid,
                    'fid' => $fid,
                    'ts' => time(),
                    'price' => intval(abs(floatval($_GET['xsfrmb'])) * 100),
                );

                C::t('#xigua_sf#xigua_sf')->doinsert($data);
                C::t('#xigua_sf#xigua_sf_user')->init_user($_G['uid']);
            }else{
                C::t('#xigua_sf#xigua_sf')->dodel_by_pid($pid);
            }
        }
    }

    public function discuzcode($args)
    {
        global $_G, $special, $sortid, $adveditor, $extra, $enctype, $noticeauthor, $noticetrimstr, $noticeauthormsg, $reppid, $specialextra, $postinfo, $thread, $quotemessage, $isfirstpost, $typeid, $name, $thread, $isorigauthor, $rushreply, $editorid, $editor, $seccodecheck, $swfconfig, $nofooter, $sectpl, $secqaacheck, $pid, $tid;

        if (!$tid && $_G['tid']) {
            $tid = $_G['tid'];
        }
        if (!$pid && $_G['pid']) {
            $pid = $_G['pid'];
        }

        if(
            strtolower($_SERVER['REQUEST_METHOD']) != 'post' &&
            $args['caller'] == 'discuzcode' &&
            $pid
        ){
            if( $ROW = C::t('#xigua_sf#xigua_sf')->fetch_by_pid($pid) ){
                $_G['cache']['plugin']['xigua_re'] = array();
                $price = $ROW['price']/100;

                include_once DISCUZ_ROOT .'source/plugin/xigua_sf/common.php';
                $config = $_G['cache']['plugin']['xigua_sf'];
                $config['tip']  = str_replace('{price}', $price, $config['tip']);

                $hasbuy = C::t('#xigua_sf#xigua_sf_order')->check_paid($_G['uid'], $pid);

                if(in_array($_G['groupid'], (array)unserialize($config['freegroup']) )){
                    $hasbuy['crts'] = time();
                }

                $replace = 0;
                if($_G['uid']==$ROW['uid']){ //is master

                    $tip = str_replace(array('{price}', '{total}'), array($price, $ROW['total']), lang('plugin/xigua_sf', 'shoufeitip'));

                } else if($hasbuy){  //has buy

                    $tip = lang('plugin/xigua_sf', 'hasbuy');
                    $extlink = lang('plugin/xigua_sf', 'hasbuyts'). dgmdate($hasbuy['crts'], 'u');

                }else{
                    $replace = 1;
                    if(checkmobile()){

                        $forumtid = urlencode($_G['siteurl'].'forum.php?mod=viewthread&tid='.$tid);
                        if(INSFWECHAT && $config['key']){
                            $openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
                            if(!$_G['inajax']&& !defined('IN_MOBILE_API')  &&!$_GET['version']){
                                $jq = "<script src=\"$_G[siteurl]source/plugin/xigua_sf/static/jquery-1.11.3.min.js\"></script >";
                                if(! $openid){
                                    $tools = new JsApiPaySF();
                                    $opendata = $tools->GetOpenid();
                                    if($openid = $opendata['openid']){
                                        dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 8640000);
                                    }
                                }
                            }else{
                                $jq = "";
                                if(! $openid){
                                    $exjs = "window.location.href='$_G[siteurl]plugin.php?id=xigua_sf:redirect&backurl=".urlencode("$_G[siteurl]forum.php?mod=viewthread&tid=".$tid) ."';";
                                }
                            }
                            if(!$_G['uid']){
                                $extlink = "<a class='buynowsf' id=\"sfitem\" href=\"member.php?mod=logging&action=login&referer=$forumtid\">{$config['buynow']}</a>";
                            }else{
                                $extlink = <<<HTML
<a class='buynowsf' id="sfitem" href="javascript:void(0);">{$config['buynow']}</a>
$jq
<script>
$exjs
$('#sfitem').on('touchstart', function(){
    $.ajax({
        url:'plugin.php?id=xigua_sf:pay&type=wx&iswx=1&tid={$tid}&pid={$pid}',
        dataType:'json',
        success:function(data){
            if(data.error){
                alert(data.error);
            }else{
                callpay(data);
            }
        }
    });
    return false;
});
function callpay(kapi){
    if (typeof WeixinJSBridge == "undefined"){
        if( document.addEventListener ){
            document.addEventListener('WeixinJSBridgeReady', function(kapi){jsApiCall(kapi);}, false);
        }else if (document.attachEvent){
            document.attachEvent('WeixinJSBridgeReady', function(kapi){jsApiCall(kapi);});
            document.attachEvent('onWeixinJSBridgeReady', function(kapi){jsApiCall(kapi);});
        }
    }else{
        jsApiCall(kapi);
    }
}
function jsApiCall(apiKey) {
    WeixinJSBridge.invoke(
        'getBrandWCPayRequest',
        apiKey,
        function(res){
            if(res.err_msg == 'get_brand_wcpay_request:ok'){
                window.location.href = 'forum.php?mod=viewthread&tid={$tid}&random=_';
            }else{}
        }
    );
}
</script >
HTML;
                            }
                        }else if($config['ali']){
                            if(!$_G['uid']) {
                                $extlink = "<a class='buynowsf' href=\"member.php?mod=logging&action=login&referer=$forumtid\" id=\"alipaybtn\">{$config['buynow']}</a>";
                            }else{
                                $extlink = "<a class='buynowsf' href=\"plugin.php?id=xigua_sf:pay&tid={$tid}&pid={$pid}&ac=pc\" id=\"alipaybtn\">{$config['buynow']}</a>";
                            }
                        }

                    }else{

                        if($config['key']){
                            $ext2 = "<a href=\"javascript:void(0);\" onclick=\"showWindow('payfor', 'plugin.php?id=xigua_sf:pay&tid={$tid}&pid={$pid}&type=wx', 'get', 0,{cover:1});\"><img src=\"source/plugin/xigua_sf/static/wec.png\"></a>";
                        }
                        if($config['ali']){
                            $ext1 = "<a href=\"plugin.php?id=xigua_sf:pay&tid={$tid}&pid={$pid}&ac=pc\" id=\"alipaybtn\"><img src=\"source/plugin/xigua_sf/static/alp.png\"></a>";
                        }

                        if(!$_G['uid']){
                            $ext1 = $ext1 ? '<a href="javascript:void(0);" onclick="showWindow(\'login\', \'member.php?mod=logging&action=login\');"><img src="source/plugin/xigua_sf/static/alp.png"></a>' : '';
                            $ext2 = $ext2 ? '<a href="javascript:void(0);" onclick="showWindow(\'login\', \'member.php?mod=logging&action=login\');"><img src="source/plugin/xigua_sf/static/wec.png"></a>' : '';
                        }
                        $extlink = $ext1.$ext2;
                    }
                    $tip = $config['tip'];
                }


                $list = C::t('#xigua_sf#xigua_sf_order')->fetch_all_paid_bypage($ROW['uid'],$ROW['pid'], 0, 100);
                $listhtml = '';
                foreach ($list as $item) {
                    $listhtml .= "<li><a href='home.php?mod=space&uid={$item['fromuid']}&do=profile' target='_blank' rel='nofollow' title='{$item['fromusername']}'><img src='{$item['fromuseravatar']}' /> </a></li>";
                }
                $clr = $config['buynowcolor'] ? $config['buynowcolor'] : '#D75847';
                $hasbuynum = lang('plugin/xigua_sf', 'hasbuynum');

                $listhtmldiv = $ROW['total'] ? "<div class=\"sflist\"><p>{$ROW['total']}$hasbuynum</p><ul class=\"cl\">$listhtml</ul></div>" : '';
                $html = <<<HTML
<style>
.buylocked a{text-decoration:none}
.buylocked{text-align:center;margin-bottom:10px;padding:20px 0}
.buynowtip{font-size: 16px;color: #909090;}
a.buynowsf{display:inline-block;height:34px;line-height:34px;padding: 0 25px;font-size: 16px;text-align: center;vertical-align: middle;color:#fff!important;border-radius:5px;background:$clr;margin:0 auto}
.sflist p{font-size:16px;text-align:center;color:#909090;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAArwAAAABAQMAAAAGv++CAAAABlBMVEX////Z2dl4b8nnAAAAAXRSTlMAQObYZgAAABRJREFUeNpj+E8Y/GBABYxE6PkAAHcsR6Qt8qYTAAAAAElFTkSuQmCC) no-repeat center center;}
.sflist p a{color:#627C97;font-size:16px}
.sflist ul{margin:0 auto;text-align:center}
.sflist ul li{ display:inline-block;margin: 0 5px 5px 0;vertical-align:top;overflow:hidden}
.sflist ul li img{width:32px;height:32px;max-height:32px;display:block;border-radius:50%;margin:0!important;;padding:0!important;}
.extlink,.sflist p,.sflist ul{margin-top:10px;display:block;color:#909090}
.sflist{padding-top:5px; max-width: 715px;margin: 0 auto;}</style >
<div class="buylocked cl">
    <div class="buynowtip">$tip</div>
    <div class="extlink">$extlink</div>
    $listhtmldiv
</div>
HTML;
                //output
                if($replace == 1){
                    global $skipaids;
                    $hashide = 0;

                    if(stripos($_G['discuzcodemessage'], '[/sf]')===false){
                        $_G['discuzcodemessage'] = self::get_ignore_js($html);
                        foreach(C::t('forum_attachment_n')->fetch_all_by_id('tid:'.$_G['tid'], 'pid', $_G['forum_attachpids']) as $attach) {
                            $skipaids[] = $attach['aid'];
                        }
                    }else{
                        if(!$_G['username']){
                            $_G['username'] = lang('template', 'guest');
                        }

                        $t = "<div style=\"background:#fff4dd;padding:15px;margin: 10px 0;color: #fa7d3c;font-size: 17px;clear:both\">{$_G['username']}".lang('plugin/xigua_sf', 'hidefor')."</div>";
                        if(preg_match("/\[sf\](.*?)\[\/sf\]/is", $_G['discuzcodemessage'], $maids)){
                            if($maids[1] && preg_match_all("/\[attach(img)?\](\d+)\[\/attach(img)?\]/is", $maids[1], $disaids)){
                                if($disaids[2]){
                                    $hashide = 1;
                                    $skipaids[] = $disaids[2];
//                                    $skipaids = array_intersect($disaids[2], $skipaids);
                                }
                            }
                        }
                        $_G['discuzcodemessage'] = preg_replace("/\[sf\](.*?)\[\/sf\]/is", $t, $_G['discuzcodemessage']).self::get_ignore_js($html);
                    }
                }else{
                    $_G['discuzcodemessage'] = str_replace(array('[sf]','[/sf]'), '', $_G['discuzcodemessage']);
                    $_G['discuzcodemessage'] = self::get_ignore_js($html).$_G['discuzcodemessage'];
                }

                if($GLOBALS['returnsf']){
                    return array(
                        'html'     => $_G['discuzcodemessage'],
                        'skipaids' => $skipaids
                    );
                }
            }
        }

    }

    public static function get_ignore_js($html){
        $html = str_replace(array("\n","\r", "  ", '   '), '', $html);
        return "<ignore_js_op>$html</ignore_js_op>";
    }
}

class plugin_xigua_sf_forum extends plugin_xigua_sf
{
    public function post_attribute_extra_output()
    {
        global $_G;

        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }

        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return FALSE;
        }

        $pid = intval($_G['pid'] ? $_G['pid'] : $_GET['pid']);

        $tid = intval($_G['tid'] ? $_G['tid'] : $_GET['tid']);
        if($tid){
            $tmp = DB::fetch_first( 'SELECT pid FROM %t WHERE pid=%d AND first=1 LIMIT 1',
                array(table_forum_post::get_tablename('tid:' . $tid), $pid)
            );
            if(!$tmp){
                return '';
            }
        }

        if($pid && $ROW = C::t('#xigua_sf#xigua_sf')->fetch_by_pid($pid)){
            $this->showprice = $ROW['price']/100;
        }
        $class = $this->showprice ? 'a' : '';
        $fufei = lang('plugin/xigua_sf', 'fufei');
        return '<label id="xsf_b" onclick="showExtra(\'xsf\')" class="'.$class.'"><span class="'.$class.'" id="xsf_chk">'.$fufei.'</span></label>';
    }

    public function post_attribute_extra_body_output()
    {
        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }
        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return FALSE;
        }

        $show = 'none';
        if($this->showprice){
            $show = 'block';
        }
        $uiam = lang('plugin/xigua_sf', 'yuan');
        $shou = lang('plugin/xigua_sf', 'shou');
        return <<<HTML
<div id="xsf_c" class="exfm cl" style="display:$show;">
$shou: <input type="text" id="xsfrmb" name="xsfrmb" class="px pxs" value="{$this->showprice}" > $uiam
</div>
HTML;
    }
}

class mobileplugin_xigua_sf extends plugin_xigua_sf_forum
{

}
class mobileplugin_xigua_sf_forum extends plugin_xigua_sf_forum
{


    public static function post_bottom_mobile()
    {
        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }
        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return '';
        }


        $pid = intval($_G['pid'] ? $_G['pid'] : $_GET['pid']);

        $tid = intval($_G['tid'] ? $_G['tid'] : $_GET['tid']);
        if($tid){
            $tmp = DB::fetch_first( 'SELECT pid FROM %t WHERE pid=%d AND first=1 LIMIT 1',
                array(table_forum_post::get_tablename('tid:' . $tid), $pid)
            );
            if(!$tmp){
                return '';
            }
        }

        $price = '0';
        if($pid && $ROW = C::t('#xigua_sf#xigua_sf')->fetch_by_pid($pid)){
            $price = $ROW['price']/100;
        }

        $disable = false;
        if($_absprice = trim($config['absprice'])){
            $absprice = array();
            foreach (explode("\n", $_absprice) as $tmpv) {
                list($_fid, $_price) = explode('=', trim($tmpv));
                $absprice[$_fid] = $_price;
            }
            if($absprice && $absprice[$_G['fid']]>0){
                $price = $absprice[$_G['fid']];
                $disable = true;
            }
        }


        $uiam = lang('plugin/xigua_sf', 'yuan');
        $shou = lang('plugin/xigua_sf', 'shou');
        $html = '';
        include template('xigua_sf:core');
        return $html;
    }
}

