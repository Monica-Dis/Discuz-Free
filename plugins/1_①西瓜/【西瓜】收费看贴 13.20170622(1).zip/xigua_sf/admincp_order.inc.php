<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(submitcheck('clear')){
    $r = C::t('#xigua_sf#xigua_sf_order')->clear_order();
    if($r){
        cpmsg(lang('plugin/xigua_sf', 'clear_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sf&pmod=admincp_order&page=".$_GET['page'], 'succeed');
    }
}
if(submitcheck('permsubmit')){
    $r = C::t('#xigua_sf#xigua_sf_order')->delete_order($_GET['delete']);
    if($r){
        cpmsg(lang('plugin/xigua_sf', 'delete_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_sf&pmod=admincp_order&page=".$_GET['page'], 'succeed');
    }
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_sf&pmod=admincp_order&page=".$_GET['page']);
showtableheader(lang('plugin/xigua_sf','dorder'));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_sf','del'),
    lang('plugin/xigua_sf','orderid'),
    lang('plugin/xigua_sf','wenzhangming'),
    lang('plugin/xigua_sf','orderprice'),
    lang('plugin/xigua_sf','shouru'),
    lang('plugin/xigua_sf','fuk'),
    lang('plugin/xigua_sf','status'),
    lang('plugin/xigua_sf', 'method'),
    lang('plugin/xigua_sf', 'ordersn'),
    lang('plugin/xigua_sf','crts'),
    lang('plugin/xigua_sf','upts'),
));
$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;
$res = C::t('#xigua_sf#xigua_sf_order')->fetch_all_bypage($start_limit, $lpp);
$icount = C::t('#xigua_sf#xigua_sf_order')->fetch_count_bypage();

foreach ($res as $v) {
    if($v['fromuid']){
        $uids[$v['fromuid']] = $v['fromuid'];
    }
    if($v['touid']){
        $uids[$v['touid']] = $v['touid'];
    }
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}


foreach ($res as $re) {
    $re['baseprice'] = sprintf('%.2f', $re['baseprice']/100);

    $paymethod = '';
    $paymethods = array(
        table_xigua_sf_order::WXPAY => 'wec.png',
        table_xigua_sf_order::ALIPAY => 'alp.png',
    );
    if($paymethods[$re['paymethod']]){
        $paymethod = $_G['siteurl'].'source/plugin/xigua_sf/static/'.$paymethods[$re['paymethod']];
        $paymethod =  "<img style='height:20px' src='$paymethod' />";
    }

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='{$re['order_id']}' />",
        $re['order_id'],
        "<a href='forum.php?mod=viewthread&tid={$re['tid']}' target='_blank'>{$re['subject']}</a>",
        $re['baseprice'],
        $users[$re['touid']] ?$users[$re['touid']]['username'] : '-',
        $users[$re['fromuid']] ?$users[$re['fromuid']]['username']: $re['fromopenid'],
        $re['paystatus'] ? '<strong style="color:forestgreen;">'.(lang('plugin/xigua_sf','yi')) .'</strong>' : '<strong style="color:orangered;">'.(lang('plugin/xigua_sf','wei')) .'</strong>',
        $paymethod,
        $re['order_sn'],
        date('m-d H:i:s', $re['crts']),
        $re['payupts'] ? date('m-d H:i:s', $re['payupts']) : '-',
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_sf&pmod=admincp_order&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '<input type="hidden" name="clear" id="clear" value="0" /><input type="button" class="btn" onclick="$(\'clear\').value=1;$(\'cpform\').submit();" value="'.(lang('plugin/xigua_sf','qingli')) .'">',$multipage);
showtablefooter();/*Dism��taobao-com*/
showformfooter();