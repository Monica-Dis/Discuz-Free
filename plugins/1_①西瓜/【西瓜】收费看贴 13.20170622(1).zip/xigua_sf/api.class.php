<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class xigua_sf
{

    public function viewthread_variables(& $params)
    {
        foreach ($params['postlist'] as $key => $post)
        {
            if ($post['first'] == 1)
            {
                global $tid, $pid, $_G;
                $_G['tid'] = $tid = $post['tid'];
                $_G['pid'] = $pid = $post['pid'];
                $GLOBALS['returnsf'] = 1;

                $old = $_G['discuzcodemessage'];
                $_G['discuzcodemessage'] = $params['postlist'][ $key ]['message'];

                include_once 'source/plugin/xigua_sf/core.class.php';
                $ret = plugin_xigua_sf::discuzcode(array('caller' => 'discuzcode'));

                $_G['discuzcodemessage'] = $old;

                $params['postlist'][ $key ]['message'] = $ret['html'] ? $ret['html'] : $params['postlist'][ $key ]['message'];
                if($ret['skipaids']){
                    foreach ($params['postlist'][$key]['imagelist'] as $index => $aid) {
                        if(in_array($aid, $ret['skipaids'])){
                            unset($params['postlist'][$key]['imagelist'][$index]);
                        }
                   }
                }
                break;
            }

        }
        return TRUE;
    }


    public function newthread_variables(&$variables)
    {
        global $_G;

        if(empty($_GET['xsfrmb'])){
            return;
        }
        $tid =$variables['tid'];
        $pid = $variables['pid'];
        $fid = $variables['fid'];

        if ( strtolower($_SERVER['REQUEST_METHOD']) == 'post' && isset($_GET['xsfrmb']) ) {
            if($_GET['xsfrmb']){
                $data = array(
                    'uid' => $_G['uid'],
                    'tid' => $tid,
                    'pid' => $pid,
                    'fid' => $fid,
                    'ts' => time(),
                    'price' => intval(abs(floatval($_GET['xsfrmb'])) * 100),
                );

                C::t('#xigua_sf#xigua_sf')->doinsert($data);
                C::t('#xigua_sf#xigua_sf_user')->init_user($_G['uid']);
            }else{
                C::t('#xigua_sf#xigua_sf')->dodel_by_pid($pid);
            }
        }

    }

    public function newthread_extraInfo()
    {
        global $_G;
        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_sf'];
        if(!$_G['fid']){
            $_G['fid'] = $_GET['fid'];
        }
        if( (! in_array($_G['groupid'], (array)unserialize($config['groupids']) )) || (! in_array($_G['fid'], (array)unserialize($config['fids']))) ) {
            return FALSE;
        }

        $show = 'block';
        $uiam = lang('plugin/xigua_sf', 'yuan');
        $shou = lang('plugin/xigua_sf', 'shou');
        return <<<HTML
<div id="xsf_c" class="exfm cl" style="display:$show;">
$shou: <input type="text" id="xsfrmb" name="xsfrmb" class="sInput sBg" style="width:120px;" value="{$this->showprice}" > $uiam
</div>
HTML;
    }

}