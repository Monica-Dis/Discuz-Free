<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/27
 * Time: 21:56
 */


define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/xigua_sf/', '',$_G['siteurl'] );
require_once 'common.php';

$notifydata = sf_notifycheck();
if($notifydata['validator']) {

    $order_id  = $notifydata['order_no'];
    $postprice = $notifydata['price'];
    $order     = C::t('#xigua_sf#xigua_sf_order')->fetch_by_order_id($order_id);

    if(
        $order &&
        $order['paystatus'] == table_xigua_sf_order::PAYWAIT
    ) {

        C::t('#xigua_sf#xigua_sf_order')->finish_order_pay($order_id, $notifydata['fromopenid'], $notifydata['trade_no'], table_xigua_sf_order::WXPAY);
        C::t('#xigua_sf#xigua_sf_user')->add_notsettled($postprice, $order['touid']);
        C::t('#xigua_sf#xigua_sf')->add_total($order['sfid']);

        if($order['fromuid']){
            $fromusername = DB::result_first('SELECT username FROM %t WHERE uid=%d', array('common_member', $order['fromuid']));
        }
        $from = $fromusername ?$fromusername: $notifydata['fromopenid'];

        $ROW = C::t('#xigua_sf#xigua_sf')->fetch($order['sfid']);
        $subject = DB::result_first("SELECT subject FROM ".DB::table('forum_thread')." WHERE tid='$ROW[tid]' LIMIT 1");

        notification_add(
            $order['touid'],
            'system',
            lang('plugin/xigua_sf', 'notice1'),
            array(
                'from'     => $from,
                'linkword' => lang('plugin/xigua_sf', 'goumaile'),
                'subject'  => $subject,
                'url'      => 'home.php?mod=spacecp&ac=plugin&id=xigua_sf:setting',
            ),
            1
        );
    }

}
function sf_notifycheck() {
    global $_G;

    $msg = '';

    $notify = WxPayApiSF::notify($msg);

    if(empty($notify)){
        $return = array(
            'return_code'=>'FAIL',
            'return_msg'=>$msg,
        );
        WxPayApiSF::replyNotify(arr2xml($return));
        exit;
    }

    //checksign
    $sign = $notify['sign'];
    unset($notify['sign']);

    ksort($notify);
    $string = ToUrlParams_sf($notify);
    $string = $string . "&key=".WxPayConfigSF::KEY;
    $string = md5($string);
    $result = strtoupper($string);
    if($result != $sign){
        $return = array(
            'return_code'=>'FAIL',
            'return_msg'=> 'sign error!',
        );
        WxPayApiSF::replyNotify(arr2xml($return));
        exit;
    }
    if($notify['result_code'] == 'SUCCESS') {
        return array(
            'validator'  => isset($notify['result_code']) && $notify['result_code'] == 'SUCCESS' ? 1 : 0,
            'order_no'   => $notify['out_trade_no'],
            'trade_no'   => isset($notify['transaction_id']) ? $notify['transaction_id'] : '',
            'price'      => $notify['total_fee'],
            'appid'      => $notify['appid'],
            'notify'     => arr2xml(array('return_code'=>'SUCCESS')),
            'location'   => false,
            'fromopenid' => $notify['openid'],
        );
    }
}


function arr2xml($data){
    $xml = "<xml>";
    foreach ($data as $key=>$val)
    {
        if (is_numeric($val)){
            $xml.="<".$key.">".$val."</".$key.">";
        }else{
            $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
        }
    }
    $xml.="</xml>";
    return $xml;
}