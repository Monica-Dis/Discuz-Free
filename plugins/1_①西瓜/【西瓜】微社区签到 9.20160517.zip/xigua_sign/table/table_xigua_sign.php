<?php
/**
 *      [DisM!] (C)2001-2099 DisM Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: table_common_connect_guest.php 29265 2012-03-31 06:03:26Z yexinhao $
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_sign extends  discuz_table
{

    public function __construct() {
        $this->_table = 'xigua_sign';
        $this->_pk = 'uid';

        parent::__construct();
    }

    public function flush_mdays(){
        global $_G;
        return DB::query("UPDATE %t SET mdays=0", array(
            $this->_table,
        ));
    }

    public function sign_update($mood, $credit, $lasted = 0){
        global $_G;
        $lasted = $lasted ? 'lasted=lasted+1' : 'lasted=1';
        return DB::query("UPDATE %t SET days=days+1,mdays=mdays+1,ts=%s,mood=%s,now_exp=now_exp+%d,last_exp=%d,$lasted WHERE uid=%d", array(
            $this->_table,
            $_G['timestamp'],
            $mood,
            $credit,
            $credit,
            $_G['uid']
        ));
    }
    public function sign_init(){
        global $_G;
        return DB::query("INSERT INTO %t (uid,ts) VALUES (%d,%s)", array(
            $this->_table,
            $_G['uid'], $_G['timestamp']
        ));
    }

    /**
     * @param $start_limit
     * @param $pagesize
     * @param string $adsc
     * @return array
     */
    public function sign_list($start_limit, $pagesize, $adsc = 'DESC')
    {
        global $_G;
        $config = sign_config();
        $today = get_date($_G['timestamp']);

        $list = DB::fetch_all("SELECT m.*,t.username FROM %t AS m, %t AS t WHERE m.uid=t.uid AND m.ts>=%s ORDER BY m.ts $adsc LIMIT %d, %d",
            array($this->_table, 'common_member', $today, $start_limit, $pagesize)
        );
        foreach ($list as $k => $v) {
            if($v['ts'] < $today ){
                $v['if'] = $config['yunsign'];
                $v['ifid'] = 'signNow';
            }else{
                $v['if'] = $config['ysign'];
                $v['ifid'] = 'signed';
            }
            $v['time']  = dgmdate($v['ts'], 'u');
            $v['unit']  = $config['credit_unit'];
            $v['title'] = $config['credit_title'];
            $v['lvinfo'] = level_get($v['now_exp']);
            $list[$k] = $v;
        }

        return $list;
    }

    public function sign_count()
    {
        global $_G;
        $today = get_date($_G['timestamp']);
        $res = DB::result_first('SELECT COUNT(*) FROM %t WHERE ts>=%s', array($this->_table, $today));
        return intval($res);
    }

    public function rank_list($start_limit, $pagesize, $adsc = 'DESC')
    {
        global $_G;
        $config = sign_config();
        $today = get_date($_G['timestamp']);

        $list = DB::fetch_all("SELECT m.*,t.username FROM %t AS m, %t AS t WHERE m.uid=t.uid ORDER BY days $adsc LIMIT %d, %d",
            array($this->_table, 'common_member', $start_limit, $pagesize)
        );
        foreach ($list as $k => $v) {
            if($v['ts'] < $today ){
                $v['if'] = $config['yunsign'];
                $v['ifid'] = 'signNow';
            }else{
                $v['if'] = $config['ysign'];
                $v['ifid'] = 'signed';
            }
            $v['time']  = dgmdate($v['ts'], 'u');
            $v['unit']  = '';
            $v['title'] = '';
            $v['lvinfo'] = level_get($v['now_exp']);
            $v['last_exp'] = sprintf(XG_lang_sign('total_days'), $v['days']);
            $list[$k] = $v;
        }

        return $list;
    }
    public function rank_count()
    {
        $res = DB::result_first('SELECT COUNT(*) FROM %t', array($this->_table));
        return intval($res);
    }

    public function last_list($start_limit, $pagesize, $adsc = 'DESC')
    {
        global $_G;
        $config = sign_config();
        $today = get_date($_G['timestamp']);
        $ts = strtotime(date('Y-m-d', $_G['timestamp']));

        $list = DB::fetch_all("SELECT m.*,t.username FROM %t AS m, %t AS t WHERE m.uid=t.uid AND m.ts>=$ts ORDER BY lasted $adsc LIMIT %d, %d",
            array($this->_table, 'common_member', $start_limit, $pagesize)
        );
        foreach ($list as $k => $v) {
            if($v['ts'] < $today ){
                $v['if'] = $config['yunsign'];
                $v['ifid'] = 'signNow';
            }else{
                $v['if'] = $config['ysign'];
                $v['ifid'] = 'signed';
            }
            $v['time']  = dgmdate($v['ts'], 'u');
            $v['unit']  = '';
            $v['title'] = '';
            $v['lvinfo'] = level_get($v['now_exp']);
            $v['last_exp'] = sprintf(XG_lang_sign('lianxu_days'), $v['lasted']);
            $list[$k] = $v;
        }

        return $list;
    }
    public function last_count()
    {
        $res = DB::result_first('SELECT COUNT(*) FROM %t', array($this->_table));
        return intval($res);
    }

    public function sign_profile($uid, $nocache = 0)
    {
        global $_G;
        $config = sign_config();
        $today = get_date($_G['timestamp']);
        static $infos;
        if(isset($infos[$uid]) && !$nocache){
            return $infos[$uid];
        }

        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d LIMIT 1",
            array($this->_table, $uid)
        );
        if($v['ts'] < $today ){
            $v['if'] = $config['yunsign'];
            $v['ifid'] = 'signNow';
        }else{
            $v['if'] = $config['ysign'];
            $v['ifid'] = 'signed';
        }
        $v['time']  = dgmdate($v['ts'], 'u');
        $v['unit']  = $config['credit_unit'];
        $v['title'] = $config['credit_title'];
        $v['lvinfo'] = level_get($v['now_exp']);

        $infos[$uid] = $v;
        return $v;
    }

    public function sign_ts()
    {
        return DB::result_first("SELECT ts FROM %t ORDER BY ts DESC limit 0,1", array($this->_table));
    }
}