<?php !defined('IN_DISCUZ') && exit('Access Denied');

include_once dirname(__FILE__) . DIRECTORY_SEPARATOR .'function.php';
$config = sign_config();
$_GET['qdxq']     = in_array($_GET['qdxq'], array_keys($config['emots'])) ? $_GET['qdxq'] : $config['emote_default'];
$_GET['formhash'] = $_GET['HASH'] ? $_GET['HASH'] : $_GET['formhash'];

$variable = '';

/*special*/
if($_GET['ani'] && $_GET['ani'] == 1){
    $profile = C::t('#xigua_sign#xigua_sign')->sign_profile($_G['uid']);
    $width = $profile['lvinfo']['width'];
    $variable = <<<HTML
<style>#headerbar #fb_current_progress{width:$width%!important}#topcontainer #fb_current_progress{width:$width%!important}
@-webkit-keyframes fadeOutTop{0%{-webkit-transform:translateY(-10px);opacity:0}25%{-webkit-transform:translateY(-20px);opacity:1}75%{-webkit-transform:translateY(-20px);opacity:1}100%{-webkit-transform:translateY(-20px);opacity:0}}
@keyframes fadeOutTop{0%{transform:translateY(-10px);opacity:0}25%{transform:translateY(-20px);opacity:1}75%{transform:translateY(-20px);opacity:1}100%{transform:translateY(-20px);opacity:0}}</style >
<wsqscript>sTipShow();</wsqscript>
HTML;
    json_output();
}

if($_GET['operation'] == 'qiandao') {
    if(empty($_G['uid'])){
        xg_show_message('to_login');
    }
    if($_GET['formhash'] != FORMHASH) {
//        xg_show_message('ignore_action');
    }
    if (!in_array($GLOBALS['_G']['groupid'], $config['groups'])) {
        xg_show_message('group_is_not_allow');
    }

    $ts = C::t('#xigua_sign#xigua_sign')->sign_ts();

    if(get_date($_G['timestamp'], 'm') != get_date($ts, 'm')){
        C::t('#xigua_sign#xigua_sign')->flush_mdays();
    }

    $profile = C::t('#xigua_sign#xigua_sign')->sign_profile($_G['uid']);
    if($profile['ifid'] == 'signed') {
        xg_show_message('has_signed');
    }

    if(!$profile['uid']) {
        C::t('#xigua_sign#xigua_sign')->sign_init();
    }

    $credit = mt_rand($config['min_credit'], $config['max_credit']);

    $incr = $config['incrNum'] * $profile['lasted'];
    if($config['incrMax']> 0 && $incr> $config['incrMax']){
        $incr = $config['incrMax'];
    }
    $credit += $incr;

    if((get_date($_G['timestamp']) - get_date($profile['ts'])) == 86400){
        C::t('#xigua_sign#xigua_sign')->sign_update($_GET['qdxq'], $credit, 1);
    }else{
        C::t('#xigua_sign#xigua_sign')->sign_update($_GET['qdxq'], $credit);
    }
    updatemembercount($_G['uid'], array($config['credit'] => $credit), true, '', 0, '', XG_lang_sign('log'));
//    $num = C::t('#xigua_sign#xigua_sign')->sign_count();

    $profile['lasted'] = $profile['lasted'] == 0 ? 1 : $profile['lasted'];
    if(!$_GET['fromapi']){  //
        $langincr = $incr ? sprintf(XG_lang_sign('incr'), $incr.$profile['unit'].$profile['title']) : '';
        $msg = sprintf(XG_lang_sign('succeed'), $profile['lasted'], $langincr);
        xg_show_message($msg);
    }else{
        $incrapi = sprintf(XG_lang_sign('incrapi'), $profile['lasted']);
    }
}

$profile = C::t('#xigua_sign#xigua_sign')->sign_profile($_G['uid'], 1);
$levelicon  = $profile['lvinfo']['levelicon'];
$lang_sign  = $profile['if'];
$upper      = $profile['lvinfo']['upper'];
$under      = $profile['lvinfo']['under'];
$sign_width = 'style="width:'.$profile['lvinfo']['width'].'%"';

if($profile['ifid'] == 'signed'){
    $singed_class = 'signed';
    $sign_action = '';
    $href = "$_G[siteurl]plugin.php?id=xigua_sign:index";
}else{
    $singed_class = '';
    $sign_action = 'click="signNow()"';
    $href = "javascript:;";
}
$ctitle = $profile['title'];
$eu = $profile['last_exp'] + $profile['unit'];

$variable .= <<<HTML
<a id="focusBtn"><span id="fb_level_badge" style="background-image:url($levelicon)"></span><div id="fb_exp_progressbar"><div id="fb_current_progress"></div></div>
<div id="fb_exp"><span style="color:#f15a23">$upper</span>/<span>$under</span></div></a>
<a id="signBtn" class="sign $singed_class" href="$href" $sign_action><i id="signIcon"></i>$lang_sign</a><div id="sTip">
<span style="color:#fff">$incrapi $ctitle</span> <span style="color:#8db943">+$eu</span></div>
<wsqscript>showAni();</wsqscript><div id="showAni" style="display:none"></div>
HTML;
json_output();