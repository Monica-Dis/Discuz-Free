<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-09-01,10:51:44
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

$pluginid = 'xigua_sign';

$Hooks = array(
    'forumdisplay_mobilesign',
    'forumdisplay_variables',
    'forumdisplay_headerBar',
    'viewthread_topBar',
    'viewthread_variables',
);

$data = array();
foreach ($Hooks as $Hook) {
    $data[] = array(
        $Hook => array(
            'plugin' => $pluginid,
            'include' => 'api.class.php',
            'class' => $pluginid,
            'method' => $Hook)
    );
}

require_once DISCUZ_ROOT . './source/plugin/wechat/wechat.lib.class.php';
WeChatHook::updateAPIHook($data);

updateAPIHook($data);
function updateAPIHook($datas) {
    $apihook = WeChatHook::getAPIHook();
    foreach ($datas as $data) {
        foreach ($data as $key => $value) {
            if (!$value['plugin']) {
                continue;
            }
            list($module, $hookname) = explode('_', $key);
            if ($value['include'] && $value['class'] && $value['method']) {
                $v = $value;
                unset($v['plugin']);
                $v['allow'] = 1;
                $apihook[$module][$hookname][$value['plugin']] = $v;
                if($module == 'forumdisplay' && $hookname == 'headerBar'){

                    foreach ($apihook[$module][$hookname] as $hk => $hv) {
                        $apihook[$module][$hookname][$hk]['order'] = 99;
                    }

                    if(isset($apihook[$module][$hookname]['xigua_post'])) {
                        $apihook[$module][$hookname]['xigua_post']['order'] = 0;
                    }
                    if(isset($apihook[$module][$hookname]['xigua_guide'])){
                        $apihook[$module][$hookname]['xigua_guide']['order'] = 1;
                    }
                    if(isset($apihook[$module][$hookname]['xigua_search'])){
                        $apihook[$module][$hookname]['xigua_search']['order'] = 2;
                    }
                    $apihook[$module][$hookname]['xigua_sign']['order'] = 3;
                    if(isset($apihook[$module][$hookname]['xigua_navigation_wsq'])){
                        $apihook[$module][$hookname]['xigua_navigation_wsq']['order'] = 4;
                    }
                    uasort($apihook[$module][$hookname], 'pluginorderapicmp');
                }

            } else {
                unset($apihook[$module][$hookname][$value['plugin']]);
            }
        }
    }

    $settings = array('mobileapihook' => serialize($apihook));
    C::t('common_setting')->update_batch($settings);
    updatecache('setting');
    return $apihook;
}
function pluginorderapicmp($a, $b) {
    return $a['order'] > $b['order'] ? 1 : -1;
}

$query = <<<SQL
CREATE TABLE IF NOT EXISTS pre_xigua_sign (
 `uid` int(11) unsigned NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `now_exp` int(11) unsigned NOT NULL,
 `last_exp` int(11) unsigned NOT NULL,
 `mood` varchar(40) NOT NULL,
 `days` int(11) unsigned NOT NULL,
 `mdays` int(11) unsigned NOT NULL,
 `lasted` int(11) unsigned NOT NULL,
 PRIMARY KEY (`uid`),
 KEY `ts` (`ts`),
 KEY `days` (`days`)
) ENGINE=InnoDB;
SQL;
runquery($query);

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_sign/install.php');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sign/discuz_plugin_xigua_sign.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sign/discuz_plugin_xigua_sign_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sign/discuz_plugin_xigua_sign_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sign/discuz_plugin_xigua_sign_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_sign/discuz_plugin_xigua_sign_TC_UTF8.xml');