<?php !defined('IN_DISCUZ') && exit('Access Denied'); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="<?php echo CHARSET ?>">
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <title><?php echo $title; ?></title>
    <meta name="description" content="<?php echo $title; ?>">
    <link href="source/plugin/xigua_sign/static/css/base.css?2015013155" type="text/css" rel="stylesheet"/>
    <style type="text/css"><?php echo $style?></style>
</head>
<body>
<header class="topnav">
    <a class="home-return" target="_top" href="./"><i class="fa fa-arrowleft fa-ad"></i><?php echo XG_lang_sign('return')?></a>
    <h3 class="hd"><?php echo XG_lang_sign('sign')?></h3>
</header>
<section class="xwrap topbg">
<div class="user">
    <img class="avatar" src="<?php echo avatar($_G['uid'], 'middle', 1)?>" onerror="this.error=null;this.src='<?php echo $_G['setting']['ucenterurl']?>/images/noavatar_middle.gif'" />
    <div class="cl">
        <span class="fl"><?php echo $_G['username']?></span>
        <div class="fl rankinfo">
            <span id="fb_level_badge" style="background-image:url(<?php echo $q['lvinfo']['levelicon']?>)"></span>
            <span class="pr5" id="level"><?php echo $q['lvinfo']['levelname'];?></span>
        </div>
    </div>
    <div id="sTip"></div>
    <a id="focusBtn">
        <div id="fb_exp_progressbar">
            <div id="fb_current_progress"></div>
        </div>
        <div id="fb_exp"><span class="org" id="upper"><?php echo $q['lvinfo']['upper']?></span>/<span id="under"><?php echo $q['lvinfo']['under']?></span></div>
    </a>
</div>

<div class="emotwrap"><ul class="cl">
<?php foreach ($emots as $k => $v) {?>
    <li data-id="<?php echo $v['mood']?>"><img src="<?php echo $v['url']?>" />
        <span><?php echo $v['name']?></span>
    </li>
<?php }?>
</ul></div>
<a class="sign1_btn sign1_wrap" id="<?php echo $q['ifid']?>"><?php echo $q['if']?></a>
</section>
<section class="rankwrap">
    <h3 class="fb cl ranktitle">
        <?php if($_GET['rank'] == 1){?>
    <span class="fl"><?php echo XG_lang_sign('rank')?></span>
    <a class="fr c9" href="<?php echo $_G['siteurl']?>plugin.php?id=xigua_sign:index&mobile=no"><?php echo XG_lang_sign('ranklist')?></a>
        <?php }else if($_GET['rank'] == 2){?>
    <span class="fl"><?php echo XG_lang_sign('lianxu')?></span>
    <a class="fr c9" href="<?php echo $_G['siteurl']?>plugin.php?id=xigua_sign:index&mobile=no&rank=1"><?php echo XG_lang_sign('rank')?></a>
        <?php }else{?>
    <span class="fl"><?php echo XG_lang_sign('ranklist')?></span>
    <a class="fr c9" href="<?php echo $_G['siteurl']?>plugin.php?id=xigua_sign:index&mobile=no&rank=2"><?php echo XG_lang_sign('lianxu')?></a>
        <?php }?>
    </h3>
    <ul class="ranklist" id="ranklist">
    <?php if($mrcs){?>
        <?php foreach ($mrcs as $key => $mrc) {?>
        <li>
            <img src="<?php echo avatar($mrc['uid'], 'middle', 1)?>" onerror="this.error=null;this.src='<?php echo $_G['setting']['ucenterurl']?>/images/noavatar_middle.gif'" class="list_avatar"/>
            <div>
                <span class="username"><?php echo $mrc['username']?></span>
                <span class="minigrade"><img class="grade" src="<?php echo $mrc['lvinfo']['levelicon']?>" /><?php echo $mrc['lvinfo']['levelname']?></span>
            </div>
            <div>
                <p class="c9 inline"><i class="fa fa-clock"></i><span class="time"> <?php echo $mrc['time']?></span></p>
                <span><img class="mood" src="<?php echo sign_emots($mrc['mood'])?>" /></span>
            </div>
            <div class="reward"><?php echo '<b>'.$mrc['last_exp'].'</b>',$mrc['unit'],$mrc['title'];?></div>
        </li>
        <?php }?>
    <?php }else{?>
        <li class="tc"><div><?php echo XG_lang_sign('none')?></div></li>
    <?php }?>
    </ul>
</section>

<div class="share_ok"><table><tr><td id="share_ok"></td></tr></table></div>

<?php if($_GET['_hd']){?>
<?php }?>

<script type="text/javascript" src="source/plugin/xigua_sign/static/jquery.min.js?t=201403261231"></script>
<script type="text/javascript">
var loading = 0;
var _pageIndex = 1;
var _pageCount = <?php echo $num?>;

$(function(){
    $(".sign1_btn").on("click",function() {
        $(this).addClass('sign1_btn_active');
    }).on("touchend",function() {
        $(this).removeClass('sign1_btn_active');
    });
    $('#fb_current_progress').css({width:'<?php echo $q['lvinfo']['width']?>%'});
    $('.emotwrap li').on("click", function(){
        $(this).addClass('active').siblings().removeClass('active');
    });

    $('#signNow').on("click",function(){
        if(loading){
            return false;
        }
        loading = 1;
        show_tip('<a class="loading"></a>', false);
        var qdxq = $('li.active').attr('data-id');
        if(!qdxq){
            show_tip('<?php echo XG_lang_sign('emote_is_empty')?>', true);
            return false;
        }
        $.ajax({
            type:'POST',
            url:"<?php echo $_G['siteurl']?>plugin.php?id=xigua_sign:response&operation=qiandao&infloat=1&inajax=1&mobile=no",
            data: {qdmode:3,formhash:'<?php echo FORMHASH?>',qdxq:qdxq},
            dataType:'text',
            success: function(data){
                var message = data;
                show_tip(message, true, 3000);
                if(message){
                    $.ajax({ type:'POST', url : '<?php echo $_G['siteurl'];?>plugin.php?id=xigua_sign:index&mobile=no', data:{formhash:'<?php echo FORMHASH?>',actype:'view'}, dataType:'json',
                        success:function(data){
                            if(data){
                                $('#fb_level_badge').css({backgroundImage:'url('+data.lvinfo.levelicon+')'});
                                $('#level').text(data.level);
                                $('#fb_current_progress').css({width:data.lvinfo.width+'%'});
                                $('#upper').text(data.lvinfo.upper);
                                $('#under').text(data.lvinfo.under);
                                $('#signNow').text(data.if).removeAttr('id').attr({'id':data.ifid});
                                $('#sTip').html('<span style="color:#fff">'+data.title+'</span><span style="color:#8db943">+'+data.last_exp+data.unit+'</span>').show();
                                window.location.reload();
                            }
                        }
                    });
                }
            }
        });
    });
    $('#signed').on('click',function(){
        show_tip('<?php echo XG_lang_sign('has_signed');?>', true);
    });

    var xgpm = {
        widget: 'ranklist',
        isPre: false,
        startY: 0,
        endY: 0,

        init: function () {
            this.touch = ('ontouchstart' in document);
            this.Start = this.touch ? 'touchstart' : 'mousedown';
            this.Move = this.touch ? 'touchmove' : 'mousemove';
            this.End = this.touch ? 'touchend' : 'mouseup';
            document.addEventListener(this.Start, this.proxy(this, this.startEvent), false);
            document.addEventListener(this.Move, this.proxy(this, this.moveEvent), false);
            document.addEventListener(this.End, this.proxy(this, this.endEvent), false);
        },
        startEvent: function (e) {
            this.startY = e.touches[0].clientY;
            this.endY = e.touches[0].clientY;
            var ctrl = $('body');

            if (ctrl.scrollTop() == ($(document).height() - $(window).height() ) ) {
                this.isPre = true;
            }
        },
        moveEvent: function () {
            this.endEvent();
        },
        endEvent: function () {
            var that = this;
            var ctrl = $('body');
            var isbottom = (ctrl.scrollTop() == ($(document).height() - $(window).height()));
            if (isbottom && this.isPre) {
                _pageIndex++;
                if (_pageIndex > _pageCount) {
                    return;
                }
                var wid = $('#' + that.widget);
                if (wid.children('.loading1').length == 0) {
                    wid.append('<div class="loading1"></div>');
                }
                $.post('<?php echo $_G['siteurl'].'plugin.php?id=xigua_sign:index&mobile=no&actype=list&rank='.$_GET['rank']?>',
                    {page: _pageIndex, formhash: '<?php echo FORMHASH?>'},
                    function (data) {
                        wid.append(data);
                        $('.loading1').detach();
                    });
            }
            this.isPre = false;
        },
        proxy: function (context, fn) {
            return function () {
                return fn.apply(context, arguments);
            }
        }
    };
    xgpm.init();
    $('body').scrollTop(0);

});
function show_tip(html, autohide, timeout){
    var tip = $('#share_ok'), dis =$('.share_ok');
    tip.html(html);
    dis.show().addClass('bounceIn animated').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
        $(this).removeClass('bounceIn animated');
    });
    if(autohide){
        setTimeout(function(){
            dis.fadeOut('normal');
            loading = 0;
        }, (timeout ? timeout :2000));
    }
}
</script>

<?php
if(is_file(DISCUZ_ROOT.'source/plugin/xigua_f/m.class.php')){
    include_once DISCUZ_ROOT.'source/plugin/xigua_f/m.class.php';
    echo mobileplugin_xigua_f::global_footer_mobile();
}
//From: Dism��taobao��com
?>
</body>
</html>