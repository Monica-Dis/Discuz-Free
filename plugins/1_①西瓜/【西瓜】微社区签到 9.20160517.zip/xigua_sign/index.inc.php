<?php !defined('IN_DISCUZ') && exit('Access Denied');

define('XIGUA_SIGN_ROOT', dirname(__FILE__) . DIRECTORY_SEPARATOR);
$wechat = unserialize($_G['setting']['mobilewechat']);
include XIGUA_SIGN_ROOT .'function.php';
$config = sign_config();
if($_G['uid']<1){

    if($_G['cache']['plugin']['xigua_login']){
        $loginurl = $_G['siteurl'].'member.php?mod=logging&action=login&mobile=2';
    }else if($wechat['wsq_allow']){
        $loginurl = "http://wsq.dismall.com/?siteid=$wechat[wsq_siteid]&c=index&a=index&login=yes&_backurl=yes";
    }else{
        $loginurl = $_G['siteurl'].'member.php?mod=logging&action=login&mobile=2';
    }

    $referer = 'plugin.php?id=xigua_sign:index';
    dheader("Location: $loginurl&referer=".urlencode($referer));
}
if (!in_array($GLOBALS['_G']['groupid'], $config['groups'])) {
    if($wechat['wsq_allow']){
        dheader("Location: http://wsq.dismall.com/?siteid=$wechat[wsq_siteid]&c=index&a=index");
    }else{
        dheader("Location: ".$_G['siteurl']);
    }
}

/*STYLE*/
$style = $topbg = '';
if($zTopbg = array_filter(explode("\n", trim($config['zTopbg']))) ){
    $_k = array_rand($zTopbg, 1);
    $topbg = trim($zTopbg[$_k]);
}
if($topbg){
    $opacity = $config['opacity'];
    $style .= ".topbg{background-image:url($topbg)}";
}else{
    $opacity = 100;
    $style .= '.user{color:#333;text-shadow:none}.emotwrap{background:none}';
}

if($btncolor_ = hex2rgb($config['zBtncolor'])){
    foreach ($btncolor_ as $k => $v) {
        $rv1 = $v-15;
        $rv2 = $v-35;
        $activebtncolor_[$k] = max($rv1, 0);
        $shadowbtncolor_[$k] = max($rv1, 0);
    }
    $btncolor        = implode(',', $btncolor_);
    $activebtncolor  = implode(',', $activebtncolor_);
    $shadowbtncolor_ = implode(',', $shadowbtncolor_);
    $style .= ".sign1_btn {background-color:rgb($btncolor);box-shadow:0 3px 0 rgb($shadowbtncolor_), 0 2px 3px #484848}
.sign1_btn_active {background-color:rgb($activebtncolor);box-shadow: 0 3px 0 rgb($shadowbtncolor_), 0 3px 4px #181818}";
}
if(is_numeric($opacity)){
    $style .= ".topnav{background:rgba(49,63,70,".($opacity/100).")}";
}
$style .= <<<STYLE
#fb_current_progress {
    background-image: -webkit-linear-gradient(top,$config[fTheme]);
    background-image: linear-gradient(to bottom,$config[fTheme])
}
STYLE;

$page = max(1, intval($_GET['page']));
$pagesize = 100;
$start_limit = ($page - 1) * $pagesize;

$emots = $config['emots'];

/*PROFILE*/
$q = C::t('#xigua_sign#xigua_sign')->sign_profile($_G['uid']);
if($_GET['actype'] == 'view' && submitcheck('formhash')){
    $q['lasted'] = $q['lasted'] == 0 ? 1 : $q['lasted'];

    $q['if']       = diconv($q['if'], CHARSET, 'UTF-8');
    $q['unit']     = diconv($q['unit'], CHARSET, 'UTF-8');
    $q['title']    = diconv(sprintf(XG_lang_sign('incrapi'), $q['lasted']) . ' '. $q['title'], CHARSET, 'UTF-8');
    $q['level']    = diconv($q['lvinfo']['levelname'], CHARSET, 'UTF-8');
    echo json_encode($q);
    exit;
}

/*LIST*/
if($_GET['rank'] == 1){
    $mrcs = C::t('#xigua_sign#xigua_sign')->rank_list($start_limit, $pagesize);
    $num = C::t('#xigua_sign#xigua_sign')->rank_count();
}else if($_GET['rank'] == 2){
    $mrcs = C::t('#xigua_sign#xigua_sign')->last_list($start_limit, $pagesize);
    $num = C::t('#xigua_sign#xigua_sign')->last_count();
}else{
    $mrcs = C::t('#xigua_sign#xigua_sign')->sign_list($start_limit, $pagesize);
    $num = C::t('#xigua_sign#xigua_sign')->sign_count();
}
$num = ceil($num/$pagesize);

if($_GET['actype'] == 'list' && submitcheck('formhash')){
    $response = '';
    $noavatar = $_G['setting']['ucenterurl'].'/images/noavatar_middle.gif';
    foreach ($mrcs as $key => $mrc) {
        $avatar = avatar($mrc['uid'], 'middle', 1);
        $grade = '<img class="grade" src="'.$mrc['lvinfo']['levelicon'].'" />'.$mrc['lvinfo']['levelname'];
        $mood = sign_emots($mrc['mood']);
        $response .=<<<HTML
<li><img src="$avatar" class="list_avatar" onerror="this.error=null;this.src='$noavatar'"/>
<div>
  <span class="username">$mrc[username]</span>
  <span class="minigrade">$grade</span>
</div>
<div>
  <p class="c9 inline"><i class="fa fa-clock"></i><span class="time">$mrc[time]</span></p>
  <span><img class="mood" src="$mood" /></span>
</div>
    <div class="reward"><b>$mrc[last_exp]</b>$mrc[unit]$mrc[title]</div></li>
HTML;
    }
    echo $response;
    exit;
}

$title = XG_lang_sign('sign') .' - '. $wechat['wsq_sitename'];
include XIGUA_SIGN_ROOT . 'template/index.php';