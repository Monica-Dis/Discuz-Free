<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * �����Ϊ Discuz!Ӧ������ ����ɹ���Ӧ��, DisM.Taobao.Com�ṩ����֧�֡�
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
dsetcookie('mobile', '', -1);

function sign_config()
{
    static $config = array();
    if($config){
        return $config;
    }
    global $_G;
    if (!$_G['cache']['plugin']) {
        loadcache('plugin');/*Dism_taobao-com*/
    }
    $config = $_G['cache']['plugin']['xigua_sign'];
    $fThemes = array(
        '1' => '#3385ff,#317ff5',
        '2' => '#8db943,#70a128',
        '3' => '#FF5B1B,#DB1F05',
        '4' => '#149191,#0C7878',
        '5' => '#9F46B9,#70189F',
        '6' => '#C7000C,#AA050E',
    );
    $config['fTheme'] = $fThemes[$config['fTheme']];
    $config['groups'] = unserialize($config['groups']);

    $levelRule = array_filter(explode("\n", trim($config['levelRule'])));
    $config['levels'] = array();
    foreach ($levelRule as $k => $rule) {
        $level = $k + 1;
        $rule_ = explode('|', $rule);
        $ruleName = $rule_[1];
        $needexp = $rule_[0];
        $config['levels'][$level] = array(
            'level' => $level,
            'name' => $ruleName,
            'exp'  => $needexp,
        );
    }

    $config['credit_unit'] = $_G['setting']['extcredits'][ $config['credit'] ]['unit'];
    $config['credit_title'] = $_G['setting']['extcredits'][ $config['credit'] ]['title'];

    $emots = array_filter(explode("\n", trim($config['emots'])));
    $config['emots'] = array();
    foreach ($emots as $k => $emot) {
        $emot_ = explode('|', $emot);
        $emotName = $emot_[1];
        $emotfile = $emot_[0];
        $config['emots'][$emotfile] = array(
            'mood' => $emotfile,
            'name' => $emotName,
            'url'  => sign_emots($emotfile),
        );
        !$config['emote_default'] && $config['emote_default'] = $emotfile;
    }

    list($min, $max) = explode('~',$config['creditRange']);
    $config['max_credit'] = max($min, $max);
    $config['min_credit'] = min($min, $max);
    return $config;
}

function hex2rgb($colour)
{
    if ($colour[0] == '#') {
        $colour = substr($colour, 1);
    }
    if (strlen($colour) == 6) {
        list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
    }
    elseif (strlen($colour) == 3) {
        list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
    }
    else {
        return false;
    }
    $r = hexdec($r);
    $g = hexdec($g);
    $b = hexdec($b);
    return array('r' => $r, 'g' => $g, 'b' => $b);
}

function grade_img($grade, $returnsrc = 0)
{
    global $_G;
    $src = $_G['siteurl'] . 'source/plugin/xigua_sign/static/images/grade-' . $grade . '.png';
    return $returnsrc ? $src : "<img class='grade' src='" . $src . "' />";
}

function level_get($now_exp){
    $now_exp = intval($now_exp);
    $cfg = sign_config();
    $levels = $cfg['levels'];
    $ret = array(
        'curlevel'    => 0,
        'levelicon'   => grade_img(0, 1),
        'levelname'   => $levels[1]['name'],
        'upper' => 0,
        'under' => $levels[1]['exp'],
        'width' => 6
    );
    if($now_exp==0){
        return $ret;
    }

    $total_exp = 0;
    foreach ($levels as $level => $lvinfo) {
        if($now_exp>= $total_exp && $now_exp <$total_exp+$levels[$level]['exp']){
            $ret['curlevel'] = $level;
            $ret['levelicon'] = grade_img($level, 1);
            $ret['levelname'] = $lvinfo['name'];

            $ret['upper'] = $now_exp - $total_exp;
            $ret['under'] = $levels[$level]['exp'];
            $ret['width'] = $ret['under']<1 ? 100 : ($ret['upper']/$ret['under'])*100;
            break;
        }
        $total_exp += $lvinfo['exp'];
    }

    if($ret['curlevel'] == 0){
        $lvinfo = end($levels);
        $ret = array(
            'curlevel'    => $lvinfo['level'],
            'levelicon'   => grade_img($lvinfo['level'], 1),
            'levelname'   => $lvinfo['name'],
            'upper' => $lvinfo['exp'],
            'under' => $lvinfo['exp'],
            'width'       => 100
        );
    }
    return $ret;
}

function sign_emots($key){
    global $_G;
    return $_G['siteurl']."source/plugin/xigua_sign/static/emot/{$key}";
}

function XG_lang_sign($l){
    static $data = array();
    if(isset($data[$l])){
        return $data[$l];
    }
    $data[$l] = lang('plugin/xigua_sign', $l);
    return $data[$l];
}

function xg_show_message($message = ''){
    $message = lang('plugin/xigua_sign', $message);
    if($_GET['fromapi'] == 1){
        showmessage($message);
    }else{
        echo $message;
        exit;
    }
}

function get_date($ts, $format = 'Y-m-d'){
    return strtotime(dgmdate($ts, $format));
}