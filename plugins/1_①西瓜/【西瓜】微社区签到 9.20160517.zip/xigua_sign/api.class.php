<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2019-09-01,10:51:44
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once dirname(__FILE__) . DIRECTORY_SEPARATOR .'function.php';
class xigua_sign
{
    public function __construct()
    {
        $this->config = sign_config();
        $this->fTheme = $this->config['fTheme'];
    }

    public function forumdisplay_mobilesign(){
        global $_G;
        require_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';

        if(!$this->config['normal']){
            return false;
        }


        if(!$this->profile ){
            $profile = $this->profile = C::t('#xigua_sign#xigua_sign')->sign_profile($_G['uid']);
        }else{
            $profile = $this->profile;
        }

        if($profile['ifid'] == 'signed' && $this->config['zhide']){
            return '';
        }

        $retval = array(
            'link' => $_G['siteurl'].'plugin.php?id=xigua_sign:index&mobile=no',
            'text' => ($profile['ifid']=='signed' ? $this->config['ysign'] : $this->config['yunsign'])
        );
        return $retval;
    }

    public function viewthread_variables(&$variables)
    {
        $this->forumdisplay_variables($variables);
    }

    public function viewthread_topBar()
    {
        $res = $this->forumdisplay_headerBar();
        return $res ? str_replace(
            array('#headerbar','height:28px;padding-top:10px;width:100%;display:-webkit-box;','#sTip{display:none;position:absolute;left:20px;top:0;'),
            array('#topcontainer','height:28px;width:100%;display:-webkit-box;','#sTip{display:none;position:fixed;left:20px;top:50px;'),
            $res) : '';
    }

    public function forumdisplay_headerBar()
    {
        global $_G;
        if(!$this->config['fastSign']){
            return false;
        }
        static $xigua_sign;
        if($xigua_sign){
            return '';
        }

        if(!$this->profile ){
            $profile = $this->profile = C::t('#xigua_sign#xigua_sign')->sign_profile($_G['uid']);
        }else{
            $profile = $this->profile;
        }

        $levelicon  = $profile['lvinfo']['levelicon'];
        $lang_sign  = $profile['if'];
        $upper      = $profile['lvinfo']['upper'];
        $under      = $profile['lvinfo']['under'];
        $sign_width = 'style="width:'.$profile['lvinfo']['width'].'%"';
        if($profile['ifid'] == 'signed'){

            if($this->config['zhide']){
                return '<style>#topcontainer{} #topcontainer>div>div,#topcontainer>div>div>div{height:auto;padding:0}</style>'.$this->hook_xigua_plugin();
            }

            $singed_class = 'signed';
            $sign_action = '';
            $href = "$_G[siteurl]plugin.php?id=xigua_sign:index&mobile=no";
        }else{
            $singed_class = '';
            $sign_action = 'click="signNow()"';
            $href = "javascript:;";
        }

        $html = <<<HTML
<style>#topcontainer{}
#topcontainer>div>div,#topcontainer>div>div>div{height:auto;padding:0}
#headerbar #xiguaSign{height:28px;padding-top:10px;width:100%;display:-webkit-box;position:relative;float:left}
#headerbar a{-webkit-tap-highlight-color:rgba(0,0,0,.2)}
#headerbar #signBtn{display:inline-block;margin-left:10px;height:28px;padding:1px 8px 0;overflow: hidden;border-radius:2px;white-space: nowrap;text-overflow:ellipsis;box-sizing:border-box;line-height:28px;font-size:13px;text-align:center;color:#fff}
#headerbar a.sign{background-image:-webkit-linear-gradient(top,$this->fTheme);background-image:linear-gradient(to bottom,$this->fTheme)}
#headerbar a.signed{background-color: #474b5c;background-image:none!important;color:rgba(255,255,255,.6)!important;}
#headerbar #signIcon{position: relative;top: 1px;display: inline-block;width: 12px;height: 12px;background: url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABgAAAAYCAMAAADXqc3KAAAAS1BMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////+DmQsHAAAAGHRSTlMAsMAXcNoRJgq25olABWXyIX9LXMqoNfrCBrZ1AAAAoUlEQVR4Xp3ROQ7DMAxE0ZGtzXsWx/n3P2lAIAJsKVWmnEeQBfVHkuOULkt5SNZT90vHGCUHPuqcFzBL4HXJBGOSwXV+hWCN4NLPsGe10G/YfAsdYy/pXiDvazmQrKfAAE9bBA9zKJACHNKLSVdQ7Nj6mbDUoGVgCBxqQDlgi1rQ7b3ln6DHUzWUVBBriF/wNXiD9lHRgyuvrZNk4mpw1n8A3RkQ6646hjoAAAAASUVORK5CYII=');background-size:12px 12px;margin: 0 2px 0 0}
#headerbar #focusBtn{position:relative;display:-webkit-box;-webkit-box-flex:1;box-sizing:border-box;background:#f4f6f9!important;padding:0 5px 0 25px;border-radius:2px}
#headerbar #fb_exp_progressbar {-webkit-box-flex:1;display:block;height:12px;background-image:url("data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAGCAMAAADXEh96AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyFpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDo3Rjc4RkE4MURCMjkxMUUzQjZGRjg5ODA0NzUxNjlDMSIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDo3Rjc4RkE4MkRCMjkxMUUzQjZGRjg5ODA0NzUxNjlDMSI+IDx4bXBNTTpEZXJpdmVkRnJvbSBzdFJlZjppbnN0YW5jZUlEPSJ4bXAuaWlkOjdGNzhGQTdGREIyOTExRTNCNkZGODk4MDQ3NTE2OUMxIiBzdFJlZjpkb2N1bWVudElEPSJ4bXAuZGlkOjdGNzhGQTgwREIyOTExRTNCNkZGODk4MDQ3NTE2OUMxIi8+IDwvcmRmOkRlc2NyaXB0aW9uPiA8L3JkZjpSREY+IDwveDp4bXBtZXRhPiA8P3hwYWNrZXQgZW5kPSJyIj8+mketkAAAAAZQTFRF19ri3uHpDMv7WAAAABtJREFUeNpiYGBgZGRkQCUZIGwGRhgTJA4QYAABpAATbPyJwwAAAABJRU5ErkJggg==");border-radius:12px;border: 2px solid #e1e3e5;position:relative;margin:6px 6px 0 0}
#headerbar #fb_current_progress {width:0;height:100%;background-image:-webkit-linear-gradient(top,$this->fTheme);background-image: linear-gradient(to bottom,$this->fTheme);border-radius:12px;position:relative;top: 0;left: 0;-webkit-transition:width .8s ease-out}
#headerbar #fb_exp {color:#939596;font:400 12px/12px Arial;text-align:center;word-break: break-all;height:28px;line-height:28px}
#headerbar #fb_level_badge {position: absolute;top:4px;left:0;width: 21px;height: 20px;display: inline-block;line-height:20px;text-align:center;font-size:10px;color: #fff;vertical-align: middle;z-index:10;background-size: 100%;background-image:url("$levelicon")}
#headerbar #sTip{display:none;position:absolute;left:20px;top:0;background:#000;color:#999;font-size:12px;padding:4px;border-radius:3px;opacity:0;-webkit-transform: translateY(-10px);-webkit-animation:fadeOutTop 3s}
#headerbar #sTip:before {content:"";position:absolute;left:50%;bottom:-5px;width:15px;height:15px;margin-left:-8px;-webkit-transform: rotate(45deg);background:#000;opacity:.8;z-index:-1}
</style>
<div id="xiguaSign">
    <a id="focusBtn">
        <span id="fb_level_badge"></span>
        <div id="fb_exp_progressbar">
            <div id="fb_current_progress" $sign_width></div>
        </div>
        <div id="fb_exp"><span style="color:#f15a23">$upper</span>/<span>$under</span></div>
    </a>
    <a id="signBtn" class="sign $singed_class" href="$href" $sign_action><i id="signIcon"></i>$lang_sign</a>
    <div id="sTip"></div>
</div>
HTML;
        $xigua_sign = $html . ' ' .$this->hook_xigua_plugin();
        return $xigua_sign;
    }

    public function forumdisplay_variables(&$variables) {
        if(!$this->config['fastSign']){
            return false;
        }

        if(!$variables['function']){
            $variables['function'] = array();
        }

        $variables['function'] = array_merge(
            array(
                'signNow' => array(
                    'WSQ.ajaxget',
                    array('id=xigua_sign:response&HASH='.FORMHASH.'&mobile=no&operation=qiandao&fromapi=1', 'xiguaSign')
                ),
                'sTipShow' => array(
                    'WSQ.show', array('sTip')
                ),
                'showAni' => array(
                    'WSQ.ajaxget',
                    array('id=xigua_sign:response&HASH='.FORMHASH.'&ani=1', 'showAni')
                )
            ) ,
            $variables['function']
        );
    }

    public function hook_xigua_plugin($hook_plugin = 'xigua_navigation_wsq'){
        global $_G;
        $value = '';
        $param = array();

        if(!empty($_G['setting']['mobileapihook'])) {
            $mobileapihook = unserialize($_G['setting']['mobileapihook']);
            if(empty($mobileapihook[$_GET['module']])) {
                return $value;
            }

            foreach ($mobileapihook as $module => $plugins) {
                foreach($plugins as $hookname => $hooks) {
                    if($hookname != 'headerBar' && $hookname != 'topBar'){
                        continue;
                    }
                    foreach($hooks as $plugin => $hook) {
                        if($plugin != $hook_plugin){
                            continue;
                        }
                        if(!$hook['allow'] || !in_array($plugin, $_G['setting']['plugins']['available'])) {
                            continue;
                        }
                        include_once DISCUZ_ROOT . 'source/plugin/' . $plugin . '/' . $hook['include'];
                        if(!isset($pluginclasses[$hook['class']])) {
                            $pluginclasses[$hook['class']] = new $hook['class'];
                        }
                        $value = $pluginclasses[$hook['class']]->$hook['method']($param);
                        break 3;
                    }
                }
            }
        }
        return $value;
    }
}