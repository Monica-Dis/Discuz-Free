export default {
    basePath: 'https://bbs.xxx.net/source/plugin/xigua_hx/',
    color: "#00c07b",
    domain: 'https://bbs.xxx.net',
    appLogo:'',
    appName:'同城信息',
    appDesc:'轻松打造本地同城分类信息平台',
    appId:'wx14aa9fee45c07e1e'
}