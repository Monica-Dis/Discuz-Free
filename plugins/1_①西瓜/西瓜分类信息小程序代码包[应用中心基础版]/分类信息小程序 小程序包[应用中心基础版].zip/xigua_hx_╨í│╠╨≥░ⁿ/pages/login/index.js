const App = getApp()

Page({
    data: {
        logged: !1,
        normal:false,
        form: {
            username:'',
            password:'',
            mobile:'',
        },
        loading:0,
    },
    onLoad() {
        this.setData({
            __config: App.__config,
        })

        this.WxValidate = App.WxValidate({
            username:{
                required: true,
                minlength: 2,
            },
            password: {
                required: true,
                minlength: 2,
            }
        }, {
            username: {required: '请输入用户名', },
            password: {required: '请输入密码', }
        })
    },
    onShow() {
        const token = App.WxService.getStorageSync('token')
        this.setData({
            logged: !!token
        })
        token && setTimeout(this.goIndex, 1500)
    },
    login() {
        this.wechatSignIn(this.goIndex)
    },
    submitLogin(e) {
        const params = e.detail.value
        var self = this
        var  _form = this.data.form
        self.setData({
            loading: true
        })
        for (var p in params){
            if(params.hasOwnProperty(p))
                _form[p]=params[p];
        }

        if (!this.WxValidate.checkForm(e)) {
            const error = this.WxValidate.errorList[0]
            wx.showToast({
                title: `${error.msg}`,
                duration: 3000
            })
            self.setData({
                loading: false
            })
            return false
        }
        App.HttpService.signIn({
            form: _form,
        }).then(data => {
            self.setData({
                loading: false
            });
            if (data.data.meta.code == 0) {
                App.WxService.setStorageSync('token', data.data.data.items[0].token)
                self.goIndex()
            } else {
                wx.showModal({
                    title: '提示',
                    showCancel: false,
                    content: data.data.meta.message
                })
            }
        });


    },
    goIndex() {
        App.WxService.switchTab('/pages/index/index')
    },
    showModal() {
        App.WxService.showModal({
            title: '友情提示',
            content: '获取用户登录状态失败，请重新登录',
            showCancel: !1,
        })
    },
    wechatDecryptData() {
        let code

        App.WxService.login()
            .then(data => {
                console.log('wechatDecryptData', data.code)
                code = data.code
                return App.WxService.getUserInfo()
            })
            .then(data => {
                return App.HttpService.wechatDecryptData({
                    encryptedData: data.encryptedData,
                    iv: data.iv,
                    rawData: data.rawData,
                    signature: data.signature,
                    code: code,
                })
            })
            .then(data => {
                console.log(data)
            })
    },
    wechatSignIn(cb) {
        if (App.WxService.getStorageSync('token')) return
        var that = this;
        wx.authorize({
            scope: 'scope.userInfo',
            success() {
                console.log(11);
                App.WxService.login()
                    .then(data => {
                        console.log('wechatSignIn1', data.code)
                        App.getUserInfo().then(data => {
                            that.setData({
                                userInfo: data,
                            })
                        });
                        return App.HttpService.wechatSignIn({
                            code: data.code,
                            userInfo: App.globalData.userInfo,
                        })
                    })
                    .then(res => {
                        const data = res.data
                        console.log('wechatSignIn2', data)
                        if (data.meta.code == 0) {
                            App.WxService.setStorageSync('token', data.data.items[0].token)
                            cb()
                        } else {
                            App.WxService.showModal({
                                title: '友情提示',
                                content: '出错啦' + data.meta.code,
                            })
                        }
                    })

            },
            fail(){
                wx.showModal({
                    title: '友情提示',
                    content: '请允许“'+App.__config.appName+'”访问用户信息',
                    success: function(res) {
                        console.log(res);
                        if (res.confirm) {
                            App.WxService.openSetting({});
                        } else if (res.cancel) {
                            that.goIndex();
                        }
                    }
                })
            }
        });
    },
    wechatSignUp(cb) {
        App.WxService.login()
            .then(data => {
                console.log('wechatSignUp', data.code)
                return App.HttpService.wechatSignUp({
                    code: data.code
                })
            })
            .then(res => {
                const data = res.data
                console.log('wechatSignUp', data)
                if (data.meta.code == 0) {
                    App.WxService.setStorageSync('token', data.data.items[0].token)
                    cb()
                } else {
                    App.WxService.showModal({
                        title: '友情提示',
                        content: '出错啦' + data.meta.code,
                    })
                }
            })
    },
    startNoraml(){
      this.setData({
          'normal':!this.data.normal
      });
    },
    signIn(cb) {
        if (App.WxService.getStorageSync('token')) return
        App.HttpService.signIn({
            username: 'admin',
            password: '123456',
    }).then(res => {
            const data = res.data
            console.log(data)
            if (data.meta.code == 0) {
                App.WxService.setStorageSync('token', data.data.items[0].token)
                cb()
            }
            console.log(App.WxService.getUserInfo());
        })
    },
})