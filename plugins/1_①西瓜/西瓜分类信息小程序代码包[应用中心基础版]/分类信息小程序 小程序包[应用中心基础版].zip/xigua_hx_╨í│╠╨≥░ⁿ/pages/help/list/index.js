const App = getApp()

Page({
    data: {
        helps: {},
        prompt: {
            hidden: !0,
            icon: '../../../assets/images/iconfont-empty.png',
        },
    },
    onShareAppMessage: function () {
        return {
            title: App.__config.appName,
            desc: App.__config.appDesc,
            path: 'pages/goods/detail/index?id='+this.data.id
        }
    },
    onShow() {
    },
    onLoad() {
      this.helps = App.HttpResource('api.php?id=xigua_hx&ac=help&:id', {id: '@id'})
        this.onPullDownRefresh()
    },
    initData() {
        this.setData({
            helps: {
                items: [],
                params: {
                    page : 1,
                    limit: 10,
                },
                paginate: {}
            }
        })
    },
    getList() {
        const helps = this.data.helps
        const params = helps.params

        this.helps.queryAsync(params)
        .then(res => {
            const data = res.data
            console.log(data)
            if (data.meta.code == 0) {
                helps.items = [...helps.items, ...data.data.items]
                helps.paginate = data.data.paginate
                helps.params.page = data.data.paginate.next
                helps.params.limit = data.data.paginate.perPage
                this.setData({
                    helps: helps,
                    'prompt.hidden': helps.items.length,
                })
                wx.stopPullDownRefresh();
            }
        })
    },
    onPullDownRefresh() {
        console.info('onPullDownRefresh')
        this.initData()
        this.getList()
    },
    onReachBottom() {
        console.info('onReachBottom')
        if (!this.data.helps.paginate.hasNext) return
        this.getList()
    },
    navigateTo(e) {
      console.log(e)
      App.WxService.navigateTo('/pages/help/detail/index', {
        id: e.currentTarget.dataset.id
      })
    },
})