const App = getApp()

Page({
    data: {
        helps: {
            item: {}
        }
    },
    onShareAppMessage: function () {
        return {
            title: App.__config.appName,
            desc: App.__config.appDesc,
            path: 'pages/goods/detail/index?id='+this.data.id
        }
    },
    onShow() {
    },
    onLoad(option) {
        this.helps = App.HttpResource('api.php?id=xigua_hx&ac=help&helpid=:id', {id: '@id'})
        this.setData({
            id: option.id
        })
    },
    onShow() {
        this.getDetail(this.data.id)
    },
    onReady() {

    },
    getDetail(id) {
        this.helps.getAsync({id: id})
        .then(res => {
            const data = res.data
            console.log(data)
            if (data.meta.code == 0) {
                this.setData({
                    'helps.item': data.data.items[0]
                })
                wx.setNavigationBarTitle({
                    title: data.data.items[0].subject
                })
            }
        })
    },
})