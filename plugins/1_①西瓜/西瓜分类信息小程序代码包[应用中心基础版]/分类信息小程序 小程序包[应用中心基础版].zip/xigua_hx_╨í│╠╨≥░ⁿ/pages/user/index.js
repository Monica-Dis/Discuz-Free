const App = getApp()

Page({
    data: {
        userInfo: {},
        mobile: '',
        username: '',
        avatar: '',
        items: [
            {
                icon: '../../assets/images/iconfont-order.png',
                text: '我的发布',
                path: '/pages/order/list/index'
            },
            {
                icon: '../../assets/images/iconfont-kefu.png',
                text: '联系客服',
                path: '',
            },
        ]
    },
    onShow() {
        if (!App.WxService.getStorageSync('token')) {
            App.WxService.redirectTo('/pages/login/index')
        }
    },
    onLoad() {
        if (!App.WxService.getStorageSync('token')) {
            App.WxService.redirectTo('/pages/login/index')
        }
        this.getUserInfo()
        this.getStorageInfo()
        this.userurl = App.HttpResource('api.php?id=xigua_hx&ac=user&:id', {id: '@id'})
        this.getMember()
    },
    getMember() {
        this.userurl.queryAsync({
            token: App.WxService.getStorageSync('token'),
        }).then(res => {
            const data = res.data
            if (data.meta.code == 0) {
                this.setData({
                    mobile: data.data.items[0].mobile,
                    username: data.data.items[0].username,
                    avatar:data.data.items[0].avatar,
                    'items[1].path': data.data.config.kfdh,
                })
            }
        })
    },
    navigateTo(e) {
        const index = e.currentTarget.dataset.index
        const path = e.currentTarget.dataset.path

        switch (index) {
            case 1:
                App.WxService.makePhoneCall({
                    phoneNumber: path
                })
                break
            default:
                App.WxService.navigateTo(path)
        }
    },
    getUserInfo() {
        const userInfo = App.globalData.userInfo

        if (userInfo) {
            this.setData({
                userInfo: userInfo
            })
            return
        }

        App.getUserInfo().then(data => {
            this.setData({
                userInfo: data
            })
        })
    },
    getStorageInfo() {
        App.WxService.getStorageInfo()
            .then(data => {
                this.setData({
                    'settings[0].path': `${data.currentSize}KB`
                })
            })
    },
    bindtap(e) {
        const index = e.currentTarget.dataset.index
        const path = e.currentTarget.dataset.path

        switch (index) {
            case 0:
                App.WxService.showModal({
                    title: '友情提示',
                    content: '确定要清除缓存吗？',
                })
                    .then(data => data.confirm == 1 && App.WxService.clearStorage())
                break
            default:
                App.WxService.navigateTo(path)
        }
    },
    logout() {
        App.WxService.showModal({
            title: '友情提示',
            content: '确定要退出吗？',
        })
            .then(data => data.confirm == 1 && this.signOut())
    },
    signOut() {
        App.HttpService.signOut()
            .then(res => {
                const data = res.data
                if (data.meta.code == 0) {
                    App.WxService.removeStorageSync('token')
                    App.WxService.switchTab('/pages/index/index')
                }
            })
    },
    getPhoneNumber: function (e) {
        var that = this;
        wx.authorize({
            scope: 'scope.userInfo',
            success() {
                App.WxService.login()
                    .then(data => {
                        App.getUserInfo().then(data => {
                            that.setData({
                                userInfo: data,
                            })
                        });
                        return App.HttpService.wechatSignIn({
                            code: data.code,
                            userInfo: App.globalData.userInfo,
                        })
                    })
                    .then(res => {
                        const data = res.data
                        if (data.meta.code == 0) {
                            App.WxService.setStorageSync('token', data.data.items[0].token)

                            if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
                                wx.showModal({
                                    title: '提示',
                                    showCancel: false,
                                    content: '未授权访问手机号'
                                })
                            } else {
                                const data = e.detail
                                App.HttpService.wechatDecryptData({
                                    encryptedData: data.encryptedData,
                                    iv: data.iv,
                                    token: App.WxService.getStorageSync('token'),
                                }).then(data => {
                                    if (data.data.meta.code == 0) {
                                        that.setData({
                                            mobile: data.data.data.items[0].phoneNumber
                                        })
                                    } else {
                                        wx.showModal({
                                            title: '友情提示',
                                            showCancel: false,
                                            content: '获取用户信息失败，请退出重新绑定'
                                        })
                                    }
                                });
                            }

                        } else {
                            App.WxService.showModal({
                                title: '友情提示',
                                content: '出错啦' + data.meta.code,
                            })
                        }
                    })

            },
            fail(){
                wx.showModal({
                    title: '友情提示',
                    content: '请允许“'+App.__config.appName+'”访问用户信息',
                    success: function(res) {
                        console.log(res);
                        if (res.confirm) {
                            App.WxService.openSetting({});
                        } else if (res.cancel) {
                            that.goIndex();
                        }
                    }
                })
            }
        });
    },
    authSetting: function () {
        wx.openSetting({
            success(res) {
            }
        })
    }
})