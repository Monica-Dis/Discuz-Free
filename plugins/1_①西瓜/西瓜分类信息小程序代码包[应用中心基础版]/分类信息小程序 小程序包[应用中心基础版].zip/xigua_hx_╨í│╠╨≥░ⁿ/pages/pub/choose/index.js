const App = getApp()

Page({
    data: {
        array: ['中国', '美国', '巴西', '日本'],
        index: 0,
        date: '2016-09-01',
        time: '12:01',
    	show: !0,
        pubtip : '',
        jings:[],
        curcat:[]
    },
    onShareAppMessage: function () {
        return {
            title: App.__config.appName,
            desc: App.__config.appDesc,
            path: 'pages/goods/detail/index?id='+this.data.id
        }
    },
    onShow() {
    },
    onLoad() {
        if (!App.WxService.getStorageSync('token')){
            App.WxService.redirectTo('/pages/login/index');
        }

        this.jing = App.HttpResource('api.php?id=xigua_hx&single=1&ac=jing_list&:id', { id: '@id' })

        this.getJing()
    },
	getJing() {
        this.jing.queryAsync({ is_show: !0 })
            .then(res => {
                const data = res.data
                if (data.meta.code == 0) {
                    for (var i = 0; i < data.data.items.length; i++) {
                        data.data.items[i].forEach(n => n.icon = App.renderImage(n.icon))
                    }
                    this.setData({
                        jings: data.data.items,
						pubtip:data.data.config.pubtip
					})
                }
            })
    },
    navigateTo(e) {
    	console.log(e.currentTarget.dataset.id);
        App.WxService.navigateTo('/pages/pub/add/index', {
            id: e.currentTarget.dataset.id
        })
    },
    bindPickerChange: function(e) {
        var catid = this.data.curcat.cindex[e.detail.value]
        this.setData({
            index: e.detail.value
        })
        App.WxService.navigateTo('/pages/pub/add/index', {
            id: catid
        })
    },
    bindPickerTo(e) {
        var catid = e.currentTarget.dataset.id, cat = this.data.jings[0];
        for(var i =0; i<cat.length; i++){
            if(cat[i].id == catid){
                this.setData({
                    curcat:cat[i]
                });
                break;
            }
        }
    },
})