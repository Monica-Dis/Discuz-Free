const App = getApp()
var util = require('../../../helpers/md5.js');

Page({
    data: {
        imageList: [],
        index: 0,
        date: '2016-09-01',
        show: !0,
        time: '12:01',
        form: {
            realname: '',
            tel: '',
            address: '',
        },
        loading:0
    },
    onShow(){
        if (!App.WxService.getStorageSync('token')) {
            App.WxService.redirectTo('/pages/login/index');
        }
    },
    onLoad(option) {
        if (!App.WxService.getStorageSync('token')) {
            App.WxService.redirectTo('/pages/login/index');
        }
        this.pubck = App.HttpResource('api.php?id=xigua_hx&ac=pub&check=1&:id', {id: '@id'})
        this.setData({
            id: option.id
        })
        this.getPub(this.data.id)
    },
    submitForm(e) {
        const params = e.detail.value
        var self = this
        var  _form = this.data.form
        self.setData({
            loading: true
        })


        for (var p in params){
            if(params.hasOwnProperty(p))
                _form[p]=params[p];
        }
        _form.cat_id = self.data.id;
        _form.imglist = self.data.imageList;


        if (!this.WxValidate.checkForm(e)) {
            const error = this.WxValidate.errorList[0]
            wx.showToast({
                title:`${error.msg}`,
                duration:3000
            })
            self.setData({
                loading: false
            })
            return false
        }
        App.HttpService.pub({
            form: _form,
            token: App.WxService.getStorageSync('token'),
            formhash:self.data.config.formhash,
        }).then(data => {
            self.setData({
                loading: false
            });
            if(data.data.meta.code==100||data.data.meta.code==101) {
                wx.showModal({
                    title: '提示',
                    showCancel: false,
                    content: data.data.meta.message
                });
                var pubid = data.data.data.items[0].formdata.rpid;
                App.WxService.navigateTo('/pages/goods/detail/index', {
                    id: pubid
                })
            }else if(data.data.meta.code==99){
                wx.showToast({
                    title: '支付中...',
                    icon: 'loading',
                    duration: 3000
                });
                var pubid = data.data.data.items[0].formdata.rpid;
                var cat_id = data.data.data.items[0].formdata.catid;
                var roid = data.data.data.items[0].formdata.roid;
                App.HttpService.startOrder({
                    token: App.WxService.getStorageSync('token'),
                    formhash:self.data.config.formhash,
                    rpid:pubid,
                    cat_id:cat_id,
                    roid:roid,
                }).then(data => {
                    if(data.data.meta.code == 0){
                        var res = data.data.data.items[0];
                        if(res.return_code != 'SUCCESS'){
                            wx.showModal({
                                title: '提示',
                                showCancel: false,
                                content: res.return_msg
                            });
                        }else{
                            var nowTime = new Date();
                            var appId = res.appid;
                            var timeStamp = Math.round((nowTime.getTime()) / 1000).toString();
                            var nonceStr = res.nonce_str;
                            var prepay_id = "prepay_id=" + res.prepay_id;
                            var key = res.key;
                            var sign = res.sign;
                            var paySign = util.hexMD5("appId=" + appId + "&nonceStr=" + nonceStr + "&package=" + prepay_id + "&signType=MD5&timeStamp=" + timeStamp + "&key=" + key);
                            wx.requestPayment({
                                timeStamp: timeStamp,
                                nonceStr: nonceStr,
                                package: prepay_id,
                                signType: 'MD5',
                                paySign: paySign,
                                success: function (res) {
                                    wx.showModal({
                                        title: '提示',
                                        showCancel: false,
                                        content: '支付成功'
                                    });
                                    App.WxService.redirectTo('/pages/goods/detail/index', {
                                        id: pubid
                                    })
                                },
                                fail: function (res) {
                                    wx.showModal({
                                        title: '提示',
                                        showCancel: false,
                                        content: '支付失败'
                                    });
                                }
                            })
                        }
                    }
                });
            }else{
                wx.showModal({
                    title: '提示',
                    showCancel: false,
                    content:data.data.meta.message
                })
            }
        });

    },
    getPub(id) {
        this.pubck.getAsync({
            cat_id: id,
            token: App.WxService.getStorageSync('token'),
        })
            .then(res => {
                const data = res.data
                if (data.meta.code == 0) {
                    if(data.data.items[0].user[0] && !data.data.items[0].user[0].mobile){
                        /*wx.showModal({
                            title: '提示',
                            showCancel: false,
                            content: '请先绑定手机号',
                            success:function () {
                                App.WxService.switchTab('/pages/user/index')
                            }
                        })*/
                    }
                    var pubData = data.data.items[0];
                    this.setData({
                        pubData: pubData,
                        config: data.data.config,
                        'form.tel': pubData.user[0].mobile,
                        price:pubData.pcat.price
                    })
                    if (data.data.config.title) {
                        wx.setNavigationBarTitle({
                            title: data.data.config.title
                        })
                    }

                    this.WxValidate = App.WxValidate({
                        description:{
                            required: true,
                            minlength: 2,
                        },
                        realname: {
                            required: true,
                            minlength: 2,
                        },
                        tel: {
                            required: true,
                        },
                    }, {
                        description:{required: ''+(pubData.pcat.placehoder?pubData.pcat.placehoder:'请填写信息内容'), },
                        realname: {required: '请填写联系人姓名', },
                        tel: {required: '请填写联系人电话号码', }
                    })
                }
            })
    },
    showToast(message) {
        App.WxService.showToast({
            title: message,
            icon: 'success',
            duration: 1500,
        })
        .then(() => App.WxService.navigateBack())
    },
    mytouchstart: function (e) {
        let that = this;
        that.setData({
            touch_start: e.timeStamp
        })
    },
    mytouchend: function (e) {
        let that = this;
        that.setData({
            touch_end: e.timeStamp
        })
    },
    chooseImg: function () {
        var that = this
        if (that.data.imageList.length > that.data.config.photoCount) {
            return false;
        }
        wx.chooseImage({
            sizeType: ['original', 'compressed'],
            sourceType: ['album', 'camera'],
            count: that.data.config.photoCount,
            success: function (res) {
                var tempFilePaths = res.tempFilePaths;
                var _img = that.data.imageList;
                var maxi = Math.min((that.data.config.photoCount-_img.length), tempFilePaths.length);
                for(var i = 0; i <maxi; i++){
                    App.HttpService.upload({
                        filePath: tempFilePaths[i],
                        name: 'file',
                        formData:{
                            token: App.WxService.getStorageSync('token'),
                            formhash:that.data.config.formhash,
                        },
                        success: function(res){
                            if(res.statusCode==200){
                                var data = JSON.parse(res.data);
                                if(data.data.items[0].errno ==0){
                                    _img.push(data.data.items[0].error);
                                    that.setData({
                                        imageList: _img
                                    })
                                }else{
                                    console.log(data.data.items[0].error);
                                    wx.showToast({
                                        title:data.data.items[0].error,
                                        duration:2000
                                    })
                                }
                            }
                        }
                    });
                }
            }
        })
    },
    previewImage: function (e) {
        var that = this;
        var touchTime = that.data.touch_end - that.data.touch_start;
        var current = e.target.dataset.src;
        var newList = [];
        if (touchTime> 300) {
            wx.showModal({
                content: "确定删除吗？",
                confirmText: "确定",
                cancelText: "取消",
                success: function (res) {
                    if (res.confirm) {
                        for (var i = 0; i < that.data.imageList.length; i++) {
                            if (that.data.imageList[i] != current) {
                                newList.push(that.data.imageList[i]);
                            }
                        }
                        that.setData({
                            imageList: newList,
                            'form.imageList':newList,
                        });
                    }
                },
            })

        } else {
            wx.previewImage({
                current: current,
                urls: that.data.imageList
            })
        }
    },
    bindDateChange: function (e) {
        var vid =e.target.dataset.id||e.currentTarget.dataset.id;
        var _tmp = {};
        _tmp['form.date['+vid+']'] = e.detail.value;
        this.setData(_tmp);
    },
    chooseLocation(e) {
        var vid =e.target.dataset.id||e.currentTarget.dataset.id;
        var _tmp = {};
        App.WxService.chooseLocation()
            .then(data => {
                console.log(data);
                _tmp['form.address['+vid+']'] = data.address;
                _tmp['form.lat['+vid+']'] = data.latitude;
                _tmp['form.lng['+vid+']'] = data.longitude;
                this.setData(_tmp)
            })
    },
    checkboxChange: function (e) {
        var _name = 'form.'+e.target.dataset.id;
        var _tmp = {};
        _tmp[_name] = e.detail.value;
        this.setData(_tmp);
    }
})