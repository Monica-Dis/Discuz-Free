const App = getApp()

Page({
    data: {
        scrollTop: 0,
        floorstatus: false,
        activeIndex: 0,
        navList: [],
        indicatorDots: !0,
        autoplay: 1,
        current: 0,
        interval:6000,
        duration: 400,
        circular: !0,
        goods: {},
        prompt: {
            hidden: !0,
        },
        swiperCurrent: 0,
        swiperCurrent1: 0,
        selectCurrent: 0,
        shareData: {
            title: App.__config.appName,
            desc: App.__config.appDesc,
            path: '/pages/index/index'
        },
        swiperHeight:110
    }
    ,imageLoad: function(e) {
        var screen = wx.getSystemInfoSync();

        var $width=e.detail.width,  $height=e.detail.height, ratio=$width/$height;
        var viewHeight=screen.screenWidth/ratio;
        this.setData({
            swiperHeight:viewHeight
        });
    },
    calling: function (e) {
        wx.makePhoneCall({
            phoneNumber: e.currentTarget.dataset.id
        })
        return false;
    },
    swiperchange: function (e) {
        this.setData({
            swiperCurrent: e.detail.current,
        })
    },
    swiperchange1: function (e) {
        this.setData({
            swiperCurrent1: e.detail.current,
        })
    },
    onShareAppMessage: function () {
        return {
            title: App.__config.appName,
            desc: App.__config.appDesc,
            path: '/pages/index/index'
        }
    },
    onLoad() {
        this.setData({
            __config: App.__config,
        })
        wx.setNavigationBarTitle({
            title: App.__config.appName
        })
        this.banner = App.HttpResource('api.php?id=xigua_hx&ac=banner&:id', {id: '@id'})
        this.jing = App.HttpResource('api.php?id=xigua_hx&ac=jing_list&:id', {id: '@id'})
        this.goods = App.HttpResource('api.php?id=xigua_hx&ac=list_item&:id', {id: '@id'})

        this.getBanners()
        this.getJing()
    },
    getJing() {
        const activeIndex = this.data.activeIndex
        this.jing.queryAsync({is_show: !0})
        .then(res => {
            const data = res.data
            if (data.meta.code == 0) {
                for (var i = 0; i < data.data.items[0].length; i++) {
                    data.data.items[0][i].forEach(n => n.icon = App.renderImage(n.icon))
                }

                this.setData({
                    jings: data.data.items[0],
                    nav_height:(data.data.items[0][0].length<=5 ? '90':175),
                    navList: data.data.items[1],
                    'goods.params.catid': data.data.items[1][activeIndex].id
                })
                this.onPullDownRefresh()
            }
        })
    },
    initData() {
        const type = this.data.goods.params && this.data.goods.params.catid || ''
        const goods = {
            items: [],
            params: {
                page: 1,
                limit: 10,
                cat_id: type,
            },
            paginate: {}
        }

        this.setData({
            goods: goods
        })
    },
    navigateTo(e) {
        App.WxService.navigateTo('/pages/goods/detail/index', {
            id: e.currentTarget.dataset.id
        })
    },
    search() {
        App.WxService.navigateTo('/pages/search/index')
    },
    listIcon(e) {
        wx.setStorageSync('inputVal', e.currentTarget.dataset.id+'' );
        App.WxService.navigateTo('/pages/search/index')
    },
    getBanners() {
        this.banner.queryAsync({is_show: !0})
            .then(res => {
                const data = res.data
                if (data.meta.code == 0) {
                    data.data.items[0].forEach(n => n.path = App.renderImage(n.src))
                    this.setData({
                        images: data.data.items[0],
                        totalpubs: data.data.items[1],
                        totalviews: data.data.items[2],
                        totalshares: data.data.items[3],
                        toutiao: data.data.items[4]
                    })
                }
            })
    },
    getList() {
        const goods = this.data.goods
        const params = goods.params

        this.goods.queryAsync(params)
            .then(res => {
                const data = res.data
                if (data.meta.code == 0) {
                    for (var i in data.data.items) {
                        if (data.data.items[i].imglist) {
                            for (var j = 0; j < data.data.items[i].imglist.length; j++) {
                                data.data.items[i].imglist[j] = App.renderImage(data.data.items[i].imglist[j])
                            }
                        }
                    }
                    data.data.items.forEach(n => n.avatar = App.renderImage(n.avatar))

                    goods.items = [...goods.items, ...data.data.items]
                    goods.paginate = data.data.paginate
                    goods.params.page = data.data.paginate.next
                    goods.params.limit = data.data.paginate.perPage
                    this.setData({
                        goods: goods,
                        'prompt.hidden': goods.items.length,
                    })
                    wx.stopPullDownRefresh();
                }
            })
    },
    onPullDownRefresh() {
        console.info('onPullDownRefresh')
        this.initData()
        this.getList()
    },
    onReachBottom() {
        console.info('onReachBottom')
        if (!this.data.goods.paginate.hasNext) return
        this.getList()
    },
    onTapTag(e) {
        const type = e.currentTarget.dataset.type
        const index = e.currentTarget.dataset.index
        const goods = {
            items: [],
            params: {
                page: 1,
                limit: 10,
                cat_id: type,
            },
            paginate: {}
        }
        this.setData({
            activeIndex: index,
            goods: goods,
        })
        this.getList()
    },
})
