const App = getApp()
var util = require('../../../helpers/md5.js');

Page({
    data: {
        goods: {},
        page: 1,
        activeIndex: 0,
        navList: [],
        order: {},
        prompt: {
            hidden: !0,
            icon: '../../../assets/images/iconfont-empty.png',
            title: '',
            text: '',
        }
    },
    onLoad() {
        if(!App.WxService.getStorageSync('token')) {
            App.WxService.redirectTo('/pages/login/index')
        }
        this.order = App.HttpResource('api.php?id=xigua_hx&ac=list_item&:id', {id: '@id'})
        this.setData({
            navList: [
                {
                    name: '显示中',
                    id: 'display',
                },
                {
                    name: '未显示',
                    id: 'undisplay',
                },
            ]
        })
        this.setData({
            goods:  {
                items: [],
                params: {
                    page: 1,
                    limit: 10,
                    cat_id: 0,
                },
                paginate: {}
            },
            type: 'display',
        });
        this.onPullDownRefresh()
    },
    initData() {
        const order = this.data.order
        const goods = {
            items: [],
            params: {
                page: 1,
                limit: 10,
                cat_id: 0,
            },
            paginate: {}
        };
        this.setData({
            goods: goods
        })
    },
    getList() {

        const goods = this.data.goods

        this.order.queryAsync({
            stat: this.data.type,
            page: this.data.page,
            token:App.WxService.getStorageSync('token'),
            is_my:1,
        })
            .then(res => {
                const data = res.data
                console.log(data)
                if (data.meta.code == 0) {
                    for (var i in data.data.items) {
                        if (data.data.items[i].imglist) {
                            for (var j = 0; j < data.data.items[i].imglist.length; j++) {
                                data.data.items[i].imglist[j] = App.renderImage(data.data.items[i].imglist[j])
                            }
                        }
                    }
                    data.data.items.forEach(n => n.avatar = App.renderImage(n.avatar))

                    console.log(goods.items);

                    goods.items = [...goods.items, ...data.data.items]
                    goods.paginate = data.data.paginate
                    goods.params.page = data.data.paginate.next
                    goods.params.limit = data.data.paginate.perPage
                    this.setData({
                        goods: goods,
                        'prompt.hidden': goods.items.length,
                        page: data.data.paginate.next,
                        config:data.data.config,
                    })
                    wx.stopPullDownRefresh();
                }
            })
    },
    onPullDownRefresh() {
        console.info('onPullDownRefresh')
        this.initData()
        this.getList()
    },
    onReachBottom() {
        console.info('onReachBottom')
        if (!this.data.goods.paginate.hasNext) return
        this.getList()
    },
    onTapTag(e) {
        const type = e.currentTarget.dataset.type
        const index = e.currentTarget.dataset.index
        this.initData()
        this.setData({
            activeIndex: index,
            type: type,
        })
        this.getList()
    },
    navigateTo(e) {
        var config =this.data.config;
        console.log(config);
        if(e.currentTarget.dataset.pay){
            wx.showToast({
                title: '支付中...',
                icon: 'loading',
                duration: 3000
            });
            var pubid = e.currentTarget.dataset.id;
            var cat_id = e.currentTarget.dataset.cat_id;
            var roid = config.roid;
            App.HttpService.startOrder({
                token: App.WxService.getStorageSync('token'),
                formhash:config.formhash,
                rpid:pubid,
                cat_id:cat_id,
                roid:roid,
            }).then(data => {
                if(data.data.meta.code == 0){
                    var res = data.data.data.items[0];
                    if(res.return_code != 'SUCCESS'){
                        wx.showModal({
                            title: '提示',
                            showCancel: false,
                            content: res.return_msg
                        });
                    }else{
                        var nowTime = new Date();
                        var appId = res.appid;
                        var timeStamp = Math.round((nowTime.getTime()) / 1000).toString();
                        var nonceStr = res.nonce_str;
                        var prepay_id = "prepay_id=" + res.prepay_id;
                        var key = res.key;
                        var sign = res.sign;
                        var paySign = util.hexMD5("appId=" + appId + "&nonceStr=" + nonceStr + "&package=" + prepay_id + "&signType=MD5&timeStamp=" + timeStamp + "&key=" + key);
                        wx.requestPayment({
                            timeStamp: timeStamp,
                            nonceStr: nonceStr,
                            package: prepay_id,
                            signType: 'MD5',
                            paySign: paySign,
                            success: function (res) {
                                wx.showModal({
                                    title: '提示',
                                    showCancel: false,
                                    content: '支付成功'
                                });
                                App.WxService.redirectTo('/pages/goods/detail/index', {
                                    id: pubid
                                })
                            },
                            fail: function (res) {
                                wx.showModal({
                                    title: '提示',
                                    showCancel: false,
                                    content: '支付失败'
                                });
                            }
                        })
                    }
                }
            });

        }else{
            App.WxService.navigateTo('/pages/goods/detail/index', {
                id: e.currentTarget.dataset.id
            })
        }
    },
})