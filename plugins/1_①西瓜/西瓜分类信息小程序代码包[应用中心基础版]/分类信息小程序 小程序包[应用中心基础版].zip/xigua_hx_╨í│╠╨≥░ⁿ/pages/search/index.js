const App = getApp()

Page({
    data: {
        goods: {},
        inputVal: '',
        page: 1,
        loading:false
    },
    navigateTo(e) {
        console.log(e)
        App.WxService.navigateTo('/pages/goods/detail/index', {
            id: e.currentTarget.dataset.id
        })
    }, calling: function (e) {
        wx.makePhoneCall({
            phoneNumber: e.currentTarget.dataset.id
        })
        return false;
    },
    clearInput() {
        this.setData({
            inputVal: '',
            page: 1,
        })
        this.onLoad();
    },
    inputTyping(e) {
        var self=this;
        self.setData({
            inputVal: e.detail.value,
            page: 1,
        })
        if (this.data.loading) return
        self.setData({
            loading: true
        })
        setTimeout(function () {
            self.onLoad();
            self.search();
            self.setData({
                loading: false
            })
        }, 500);
    },
    onShareAppMessage: function () {
        return {
            title: this.data.inputVal?this.data.inputVal :App.__config.appName ,
            desc: App.__config.appDesc,
            path: '/pages/index/index'
        }
    },
    onLoad(option) {
        const goods = {
            items: [],
            params: {
                page: 1,
                limit: 10,
                cat_id: 0,
            },
            paginate: {}
        };
        this.setData({
            goods: goods,
            loading: false
        });
        if (wx.getStorageSync('inputVal')) {
            this.setData({
                inputVal: wx.getStorageSync('inputVal')
            });
            wx.removeStorageSync('inputVal');
            this.search();
        }
        this.onPullDownRefresh()
    },
    onPullDownRefresh() {
        console.info('onPullDownRefresh')
        this.search()
    },
    onReachBottom() {
        console.info('onReachBottom')
        if (!this.data.goods.paginate.hasNext) return
        this.search()
    },
    search() {
        var self = this;
        if (!this.data.inputVal) return
        if (this.data.loading) return
        self.setData({
            loading: true
        })

        wx.setNavigationBarTitle({
            title: '搜索-'+self.data.inputVal
        })
        const goods = this.data.goods

        App.HttpService.search({
            keyword: this.data.inputVal,
            page: this.data.page
        })
            .then(res => {
                const data = res.data
                console.log(data)
                if (data.meta.code == 0) {
                    for (var i in data.data.items) {
                        if (data.data.items[i].imglist) {
                            for (var j = 0; j < data.data.items[i].imglist.length; j++) {
                                data.data.items[i].imglist[j] = App.renderImage(data.data.items[i].imglist[j])
                            }
                        }
                    }
                    data.data.items.forEach(n => n.avatar = App.renderImage(n.avatar))

                    console.log(goods.items);

                    goods.items = [...goods.items, ...data.data.items]
                    goods.paginate = data.data.paginate
                    goods.params.page = data.data.paginate.next
                    goods.params.limit = data.data.paginate.perPage
                    this.setData({
                        goods: goods,
                        'prompt.hidden': goods.items.length,
                        page: data.data.paginate.next,
                    })
                    wx.stopPullDownRefresh();
                }
                self.setData({
                    loading: false
                })
            })
    }
})