<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
  DROP TABLE pre_xigua_hk_card;
  DROP TABLE pre_xigua_hk_good;
  DROP TABLE pre_xigua_hk_lingqu;
  DROP TABLE pre_xigua_hk_num;
  DROP TABLE pre_xigua_hk_help;
EOT;
runquery($sql);

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/install.php');

xwb_delall(DISCUZ_ROOT . "./source/plugin/xigua_hk");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_hk");


function xwb_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwb_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}