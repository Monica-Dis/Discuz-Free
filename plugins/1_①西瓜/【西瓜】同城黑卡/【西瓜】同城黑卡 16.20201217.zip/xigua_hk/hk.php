<?php

$hk_config = $_G['cache']['plugin']['xigua_hk'];
$cardtype = array();
foreach (explode("\n", trim($hk_config['cardtype'])) as $index => $item) {
    $cardtype[] = explode('#', trim($item));
}

function get_card_price(){
    global $_G;
    $hk_config = $_G['cache']['plugin']['xigua_hk'];
    $cardtype = array();
    foreach (explode("\n", trim($hk_config['cardtype'])) as $index => $item) {
        $cardtype[] = explode('#', trim($item));
    }
    foreach ($cardtype as $index => $_v) {
        $price =floatval($_v[2]);
        if((IN_MOCUZ||IN_MAGAPP||IN_QIANFAN||IN_APPBYME) && $_v[5]>0):
            $price =floatval($_v[5]);
        endif;
        if($_v[6] && $index == $_GET['cardtype'] && $_GET['cardtype']!=''){
            return $price;
        }
    }
    return 0;
}

function get_card_type(){
    global $_G;
    $hk_config = $_G['cache']['plugin']['xigua_hk'];
    $cardtype = array();
    foreach (explode("\n", trim($hk_config['cardtype'])) as $index => $item) {
        $cardtype[] = explode('#', trim($item));
    }
    foreach ($cardtype as $index => $_v) {
        if($_v[6] ){
            return $cardtype[$index];
        }
    }
    return array();
}