<?php
/**
 * Created by PhpStorm.
 * User: https://dism.taobao.com/?@xigua
 * Date: 2018/6/9
 * Time: 21:08
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99, 'id');
foreach ($sh as $index => $_sh) {
    if(!in_array('heika', $vips[$_sh['viptype']]['access'])){
        unset($sh[$index]);
    }
}