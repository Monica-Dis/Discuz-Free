<?php
/**
 * Created by PhpStorm.
 * User: https://dism.taobao.com/?@xigua
 * Date: 2018/6/9
 * Time: 21:08
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function hk_code(){
    return substr(mt_rand(10000000, 99999999), 0, 8);
}