<?php

function hk_qrcode($mpid, $url, $avatar = ''){

    global $SCRITPTNAME, $hk_config, $_G,$urlext;

    if($hk_config['typewx'] ==2){
        $upar = parse_url($url);
        $hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_hk&ac=view&shid=$mpid&x=1");

        $_qrfile = './source/plugin/xigua_hk/cache/sh' . $mpid . '.jpg';
        if (!is_file(DISCUZ_ROOT . $_qrfile)){
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')){
                QRcode::png($hb_currenturl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
            }
        }
        $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&logo='.urlencode($avatar).'&url='.$hb_currenturl;
        return $shqr;
    }else{
        $config = $_G['cache']['plugin']['xigua_hb'];
        if($config['qraut']){
            return "$SCRITPTNAME?id=xigua_hb:qrauto&ode=hk_{$mpid}{$urlext}";
        }
        $repath = './source/plugin/xigua_hk/cache/';
        $qrfile = $repath . $mpid . '.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;

        if(!is_file($abs_qrfile)) {
            if (!is_file($abs_qrfile)) {
                @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                if(class_exists('QRcode')){
                    QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
                }
            }
        }
        return $qrfile;
    }
}