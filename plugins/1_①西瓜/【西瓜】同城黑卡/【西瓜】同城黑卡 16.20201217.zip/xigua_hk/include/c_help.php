<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2018/6/11
 * Time: 17:22
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['do']=='check'){
    $ret = 0;
    $lingquid = intval($_GET['lingquid']);

    $row = C::t('#xigua_hk#xigua_hk_lingqu')->fetch($lingquid);
    if($row && $row['uid']==$_G['uid'] && $row['hxstatus']==1){
        $ret = $row['hxratemoney'];
    }
   $good = C::t('#xigua_hk#xigua_hk_good')->fetch_by_good_id($row['gid']);
    if($good['zktype']=='q'){
        if($ret>0 && $hk_config['allowxx']){
            $ret = '  '.lang_hk('lj', 0).$good['lijian'].lang_hk('yhxzf', 0).$ret.lang_hb('yuan',0);
        }
    }else{
        if($ret>0 && $hk_config['allowxx']){
            $ret = '  '.$row['rate'].lang_hk('zyhhx', 0).$ret.lang_hb('yuan',0);
        }
    }
    include template('xigua_hb:header_ajax');
    echo $ret;
    include template('xigua_hb:footer_ajax');
}else{
    $card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($uid);
    $navtitle = lang_hk('hksybz',0);
    $data = C::t('#xigua_hk#xigua_hk_help')->fetch_all_by_page(0, 20);
}