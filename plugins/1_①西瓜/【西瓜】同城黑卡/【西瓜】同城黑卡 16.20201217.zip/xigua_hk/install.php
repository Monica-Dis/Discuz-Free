<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<HTML

CREATE TABLE IF NOT EXISTS `pre_xigua_hk_card` (
 `cardno` int(11) NOT NULL AUTO_INCREMENT,
 `endts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `order_id` char(24) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `note` varchar(800) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `payts` int(11) NOT NULL,
 `status` int(1) NOT NULL COMMENT '-1:notpay 1:normal  2:outdate',
 `cardnum` varchar(20) NOT NULL,
 `cardinfo` varchar(800) NOT NULL,
 `usetime` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 PRIMARY KEY (`cardno`),
 UNIQUE KEY `uid` (`uid`),
 KEY `order_id` (`order_id`),
 KEY `hxstatus` (`status`),
 KEY `stid` (`stid`),
 KEY `status` (`status`)
) ENGINE=InnoDB;
ALTER TABLE pre_xigua_hk_card AUTO_INCREMENT=10000;

CREATE TABLE IF NOT EXISTS `pre_xigua_hk_good` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `startts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `title` varchar(200) NOT NULL,
 `shid` int(11) NOT NULL,
 `shname` varchar(80) NOT NULL,
 `hangye_id1` int(11) NOT NULL,
 `hangye_id2` int(11) NOT NULL,
 `lat` varchar(32) NOT NULL,
 `lng` varchar(32) NOT NULL,
 `province` varchar(32) NOT NULL,
 `city` varchar(32) NOT NULL,
 `district` varchar(32) NOT NULL,
 `stock` int(11) NOT NULL,
 `sellnum` int(11) NOT NULL,
 `timeuses` int(11) NOT NULL,
 `week` varchar(80) NOT NULL,
 `date` varchar(500) NOT NULL,
 `rate` decimal(2,1) NOT NULL,
 `bigweek` varchar(80) NOT NULL,
 `bigdate` varchar(500) NOT NULL,
 `bigrate` decimal(2,1) NOT NULL,
 `manmax` int(11) NOT NULL,
 `maxmoney` int(11) NOT NULL,
 `attention` varchar(800) NOT NULL,
 `notice` varchar(800) NOT NULL,
 `jieshao` text NOT NULL,
 `append_img` text NOT NULL,
 `append_text` text NOT NULL,
 `album` text NOT NULL,
 `status` int(11) NOT NULL COMMENT '1:wait 2:normal 3:xiajia',
 `srange` varchar(512) NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`),
 KEY `stid` (`stid`),
 KEY `shid` (`shid`),
 KEY `stock` (`stock`),
 KEY `rate` (`rate`),
 KEY `views` (`views`),
 KEY `sellnum` (`sellnum`),
 KEY `province` (`province`),
 KEY `city` (`city`),
 KEY `district` (`district`),
 KEY `week` (`week`),
 KEY `date` (`date`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hk_help` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `subject` varchar(200) NOT NULL,
 `content` text NOT NULL,
 `crts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hk_lingqu` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `shid` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `rate` decimal(2,1) NOT NULL,
 `note` varchar(800) NOT NULL,
 `crts` int(11) NOT NULL,
 `startts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `code` varchar(200) NOT NULL,
 `status` int(11) NOT NULL COMMENT '0wait 1fail2success',
 `hxstatus` int(1) NOT NULL COMMENT '0:wei 1:yi',
 `usedate` date NOT NULL,
 `hxmoney` decimal(10,2) NOT NULL,
 `hxratemoney` decimal(10,2) NOT NULL,
 `hxcrts` int(11) NOT NULL,
 `hxuid` int(11) NOT NULL,
 `hxnote` varchar(500) NOT NULL,
 `usets` int(11) NOT NULL,
 `gid` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `code` (`code`),
 KEY `endts` (`endts`),
 KEY `hxstatus` (`hxstatus`),
 KEY `shid` (`shid`),
 KEY `stid` (`stid`),
 KEY `usedate` (`usedate`),
 KEY `gid` (`gid`),
 KEY `uid` (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hk_num` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `lastts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `usets` int(11) NOT NULL,
 `cardnum` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `hxstatus` (`usets`),
 KEY `uid` (`uid`),
 KEY `cardnum` (`cardnum`)
) ENGINE=InnoDB;

ALTER TABLE `pre_xigua_hk_card` CHANGE `status` `status` INT(11) NOT NULL;
HTML;



runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/discuz_plugin_xigua_hk_TC_UTF8.xml');

$finish = TRUE;

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'autostock\'', array('xigua_hk_good'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hk_good` ADD `autostock` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hk_good` ADD `lastauto` DATE NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'tiyannum\'', array('xigua_hk_card'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hk_card` ADD `tiyannum` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'allmax\'', array('xigua_hk_good'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hk_good` ADD `allmax` INT(11) NOT NULL AFTER `manmax`;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'viptype\'', array('xigua_hk_num'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hk_num` ADD `viptype` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hk_num` ADD INDEX(`viptype`);

SQL;
    runquery($sql);
}



$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'lijian\'', array('xigua_hk_good'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hk_good` ADD `lijian` DECIMAL(10,2) NOT NULL;

ALTER TABLE `pre_xigua_hk_good` ADD `zktype` VARCHAR(20) NOT NULL;

SQL;
    runquery($sql);
}

/*ALTER TABLE `pre_xigua_hk_card` ADD `used` INT(11) NOT NULL AFTER `tiyannum`, ADD `total` INT(11) NOT NULL AFTER `used`;*/

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hk/install.php');