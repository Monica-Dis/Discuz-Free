<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
$hk_config = $_G['cache']['plugin']['xigua_hk'];
$cardtype = array();
foreach (explode("\n", trim($hk_config['cardtype'])) as $index => $item) {
	$cardtype[] = explode('#', trim($item));
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hk/function.php';
$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$url = rtrim($url, '/') . '/';
$card_status = array('-1' => lang_hk('cstatus-1', 0), '1' => lang_hk('cstatus1', 0), '2' => lang_hk('cstatus2', 0));
$gid = intval($_GET['gid']);
$svicerange = array();
foreach (explode("\n", trim($hk_config['svicerange'])) as $index => $item) {
	$svicerange[] = trim($item);
}
$weekarray = array(lang_hk('w0', 0), lang_hk('w1', 0), lang_hk('w2', 0), lang_hk('w3', 0), lang_hk('w4', 0), lang_hk('w5', 0), lang_hk('w6', 0));
$aclist = array('tejia', 'index', 'join', 'dopay', 'manage', 'good_li', 'add', 'none', 'stock_edit', 'chosecity', 'view', 'lingqu', 'my_order', 'lingqu_li', 'scan', 'hxlog', 'hxlog_li', 'help');
$aclist_login = array('join', 'dopay', 'manage', 'add', 'stock_edit', 'lingqu', 'my_order', 'lingqu_li', 'scan', 'hxlog', 'hxlog_li', 'help');
$ac = $_GET['ac'];
$do = $_GET['do'];
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
$isself = in_array($ac, $aclist_login) || !(strpos($ac, 'my') === false) && !$_G['uid'];
hk_init_charset();
if ($isself && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval(getgpc('page')));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$uid = $_G['uid'];
$date_now = $_GET['date'];
switch ($ac) {
	case 'tejia':
		break;
	case 'hxlog':
		$custom_side = array($SCRITPTNAME . '?id=xigua_hk&ac=manage&is_my=1' . $urlext, lang_hk('more', 0));
		$good = C::t('#xigua_hk#xigua_hk_good')->fetch_by_good_id($gid);
		$navtitle = $good['title'] . lang_hk('xfjl', 0);
		break;
	case 'hxlog_li':
		$where = array();
		$where[] = ' gid=\'' . $gid . '\' AND hxstatus=1';
		$list = C::t('#xigua_hk#xigua_hk_lingqu')->fetch_all_by_where($where, $start_limit, $lpp);
		$gids = $hxuids = array();
		foreach ($list as $index => $kus) {
			$gids[] = $kus['gid'];
			$hxuids[] = $kus['hxuid'];
		}
		$goods = C::t('#xigua_hk#xigua_hk_good')->fetch_in($gids);
		if ($hxuids) {
			$hxusers = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $hxuids), 'uid');
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_hk:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'scan':
		$navtitle = lang_hk('xfhx', 0);
		$where = array();
		$where[] = ' code=\'' . daddslashes($_GET['code']) . '\' AND status=2';
		$lingqu_rs = C::t('#xigua_hk#xigua_hk_lingqu')->fetch_all_by_where($where, 0, 1);
		$v = $lingqu_rs[0];
		$date_now = date('Y-m-d');
		if ($v) {
			$v['sh'] = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($v['shid']);
			$v['good'] = C::t('#xigua_hk#xigua_hk_good')->fetch_by_good_id($v['gid']);
			$v['user'] = getuserbyuid($v['uid']);
		}
		$todayuse = C::t('#xigua_hk#xigua_hk_lingqu')->fetch_used_count_by_uid($v['uid'], $v['gid'], $date_now);
		$access = 0;
		if (IS_ADMINID) {
			$access = 1;
		} else {
			if ($v['sh']['uid'] == $_G['uid']) {
				$access = 1;
			} elseif ($v['good']['uid'] == $_G['uid']) {
				$access = 1;
			}
		}
		if (!$access) {
			$yuaninfo = C::t('#xigua_hs#xigua_hs_yuan')->fetch_yuan_by_shid_uid($v['shid'], $_G['uid']);
			if ($yuaninfo) {
				$access = 1;
			}
		}
		if (!$access) {
			if ($coki = authcode(getcookie('hstax' . $v['shid']), 'DECODE')) {
				$shv = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid'], 0);
				if ($shv['hxpwd'] == $coki) {
					$access = 1;
				}
			}
		}
		if (submitcheck('lingquid')) {
			if (!$access) {
				hb_message(lang_hk('whxqx', 0), 'error');
			}
			if (!$v) {
				hb_message(lang_hk('yhqbcz', 0), 'error');
			}
			if ($v['hxstatus']) {
				hb_message(lang_hk('yhqcf', 0), 'error');
			}
			if ($v['usedate'] != $date_now) {
			}
			$form = $_GET['form'];
			if (!$form['hxmoney']) {
				hb_message(lang_hk('qtxje', 0), 'error');
			}
			if ($v['good']['maxmoney'] > 0 && $form['hxmoney'] < $v['good']['maxmoney']) {
				hb_message(lang_hk('man', 0) . $v['good']['maxmoney'] . lang_hk('yksy', 0), 'error');
			}
			if ($v['good']['zktype'] == 'q') {
				$ratemoney = round($form['hxmoney'] - $v['good']['lijian'], 2);
				$tip = lang_hk('syong', 0) . $v['good']['lijian'] . lang_hk('yhxzf', 0) . '<em class="main_color f20">' . $ratemoney . lang_hk('yuan', 0) . '</em>';
			} else {
				$ratemoney = round($form['hxmoney'] * $v['rate'] / 10, 2);
				$tip = lang_hk('syong', 0) . $v['rate'] . lang_hk('zyhhx', 0) . '<em class="main_color f20">' . $ratemoney . lang_hk('yuan', 0) . '</em>';
			}
			if (C::t('#xigua_hk#xigua_hk_lingqu')->update($_GET['lingquid'], array('hxmoney' => $form['hxmoney'], 'hxratemoney' => $ratemoney, 'hxnote' => $form['hxnote'], 'hxstatus' => 1, 'hxcrts' => TIMESTAMP, 'hxuid' => $_G['uid']))) {
				$tip = str_replace('\'', '', $tip);
				C::t('#xigua_hk#xigua_hk_card')->incr($uid, 'usetime', 1);
				C::t('#xigua_hk#xigua_hk_good')->incr($v['gid'], 'timeuses', 1);
				hb_message(lang_hk('cgxf', 0) . $form['hxmoney'] . lang_hk('yuan', 0), 'success', 'javascript:showRate(\'' . $tip . '\', \'' . $v['gid'] . '\');');
			}
		}
		break;
	case 'my_order':
		$navtitle = lang_hk('wdkq', 0);
		$custom_side = array($SCRITPTNAME . '?id=xigua_hk' . $urlext, lang_hk('lqu', 0));
		break;
	case 'lingqu_li':
		if ($_GET['type'] == 'unuse') {
			$where[] = 'uid=' . $_G['uid'] . ' and status=2 and hxstatus=0 AND ((endts=0 OR endts>=' . TIMESTAMP . ') AND usets>=' . TIMESTAMP . ')';
		} elseif ($_GET['type'] == 'used') {
			$where[] = 'uid=' . $_G['uid'] . ' and status=2 and hxstatus=1 ';
		} elseif ($_GET['type'] == 'expired') {
			$where[] = 'uid=' . $_G['uid'] . ' and status=2 and hxstatus=0 AND ((endts<>\'0\' AND endts<' . TIMESTAMP . ') OR usets<' . TIMESTAMP . ')';
		} else {
			$where[] = 'uid=' . $_G['uid'];
		}
		$list = C::t('#xigua_hk#xigua_hk_lingqu')->fetch_all_by_where($where, $start_limit, $lpp);
		$gids = array();
		foreach ($list as $index => $kus) {
			$gids[] = $kus['gid'];
		}
		$goods = C::t('#xigua_hk#xigua_hk_good')->fetch_in($gids);
		include template('xigua_hb:header_ajax');
		include template('xigua_hk:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'lingqu':
		if (submitcheck('gid')) {
			$goodinfo = C::t('#xigua_hk#xigua_hk_good')->fetch_by_good_id($gid);
			if (!$goodinfo) {
				hb_message(lang_hk('yhqbcz', 0), 'error');
			}
			$hascount = C::t('#xigua_hk#xigua_hk_lingqu')->fetch_count_by_uid($uid, $gid, $date_now);
			if ($goodinfo['manmax'] > 0 && $hascount >= $goodinfo['manmax']) {
				hb_message(lang_hk('xmrmtlq', 0) . $goodinfo['manmax'] . lang_hk('z', 0), 'error');
			}
			if ($goodinfo['allmax'] > 0) {
				$allcount = C::t('#xigua_hk#xigua_hk_lingqu')->fetch_count_all_uid($uid, $gid);
				if ($allcount >= $goodinfo['allmax']) {
					hb_message(lang_hk('xmrmtlq1', 0) . $goodinfo['allmax'] . lang_hk('z', 0), 'error');
				}
			}
			if ($goodinfo['status'] != 2) {
				hb_message(lang_hk('hdyxj', 0), 'error');
			}
			if ($goodinfo['isend']) {
				hb_message(lang_hk('hdygq', 0), 'error');
			}
			if ($goodinfo['stock'] < 1) {
				hb_message(lang_hk('kcbz', 0), 'error');
			}
			$cardexists = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G['uid']);
			if ($cardexists['endts'] < strtotime($date_now)) {
				hb_message(lang_hk('hkyxqbz', 0), 'error');
			}
			include_once DISCUZ_ROOT . 'source/plugin/xigua_hk/include/codemake.php';
			$insert = array();
			$insert['shid'] = $goodinfo['shid'];
			$insert['uid'] = $uid;
			$insert['rate'] = $goodinfo['rate'];
			$insert['crts'] = TIMESTAMP;
			$insert['startts'] = $goodinfo['startts'];
			$insert['endts'] = $goodinfo['endts'];
			$insert['code'] = hk_code();
			$insert['status'] = 2;
			$insert['stid'] = $_GET['st'];
			$insert['usedate'] = $date_now;
			$insert['usets'] = strtotime($date_now . ' 23:59:59');
			$insert['gid'] = $gid;
			$lingquid = C::t('#xigua_hk#xigua_hk_lingqu')->insert($insert, 1);
			if ($lingquid) {
				$codeurl = hk_qrcode_make($insert['code']);
				C::t('#xigua_hk#xigua_hk_good')->incr($gid, 'sellnum', 1);
				C::t('#xigua_hk#xigua_hk_good')->incr($gid, 'stock', 0 - 1);
				hb_message(lang_hk('lqcg', 0), 'success', 'javascript:pop_vi(\'' . $lingquid . '\', \'' . $codeurl . '\');');
			}
		}
		break;
	case 'view':
		$v = C::t('#xigua_hk#xigua_hk_good')->fetch_by_good_id($gid);
		$back_to_overwrite = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : $SCRITPTNAME . '?id=xigua_hk&mobile=2' . $urlext;
		if (!$v) {
			dheader('Location: ' . $back_to_overwrite);
		}
		$v['sh'] = $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid'], 0);
		if (!$date_now) {
			$date_now = date('Y-m-d');
		}
		$date_ts = strtotime($date_now);
		$m_show = date('n', $date_ts);
		$d_show = date('j', $date_ts);
		$wkindex = date('w', strtotime($date_now));
		$check_week = in_array($weekarray[$wkindex], $v['week_ary']);
		$check_date = in_array($d_show, $v['date_ary']);
		if (!$check_date && !$check_week) {
			dheader('Location: ' . $back_to_overwrite);
		}
		$card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($uid);
		$currenturl = urlencode(hb_currenturl() . $urlext);
		$hasbuy = C::t('#xigua_hk#xigua_hk_lingqu')->fetch_unuse_by_uid($uid, $gid, $date_now);
		$navtitle = $v['title'];
		if ($config['tnameshow']) {
			$navtitle = $navtitle . ' ' . $config['tname'];
		}
		$desc = $v['attention'] ? $v['attention'] : ($v['jieshao'] ? $v['jieshao'] : $v['append_text_ary'][0]);
		break;
	case 'chosecity':
		if ($_GET['ctid']) {
			$rlist = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($_GET['ctid']);
			include template('xigua_hb:header_ajax');
			include template('xigua_hk:chosecity');
			include template('xigua_hb:footer_ajax');
		}
		break;
	case 'index':
		$alldate = hk_diouf12date($hk_config['alldays']);
		if (!$_G['uid']) {
			$_G['uid'] = 0;
		}
		$card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($uid);
		$hyid = intval($_GET['hyid']);
		$hy = C::t('#xigua_hs#xigua_hs_hangye')->fetch($hyid);
		$list_all = C::t('#xigua_hs#xigua_hs_hangye')->list_all();
		C::t('#xigua_hs#xigua_hs_hangye')->init($list_all);
		$cat_tree_init = $cat_tree = C::t('#xigua_hs#xigua_hs_hangye')->get_tree_array(0);
		$cat_tree = array_values($cat_tree);
		$catname = $hy['name'] ? $hy['name'] : lang_hb('quanbu', 0);
		$subcat = $cat_tree;
		if ($hy['pid'] == 0) {
			$subcats = $cat_tree_init[$hyid]['child'];
		}
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist00 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist00 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist00[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist00, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist00 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if (!$navtitle && $distname) {
			$navtitle = $distname;
		}
		if (!$distname) {
			$distname = lang_hb('plugins_edit_vars_type_area', 0);
		}
		$where = array();
		if ($hk_config['autos']) {
			$where[] = 'status=2 and (autostock>0 or stock>0 ) and (endts=0 OR endts>=' . TIMESTAMP . ')';
		} else {
			$where[] = 'status=2 AND stock>0 and (endts=0 OR endts>=' . TIMESTAMP . ')';
		}
		$date_list = C::t('#xigua_hk#xigua_hk_good')->fetch_all_by_where($where, 0, 1000, '', 'id,date,week', 1);
		foreach ($date_list as $index => $item) {
			$date_list[$index]['week'] = explode(',', $item['week']);
			$date_list[$index]['date'] = $item['date'] ? explode(',', str_replace(array(lang_hk('meiyue', 0), lang_hk('ri', 0)), '', $item['date'])) : array();
		}
		foreach ($alldate as $index => $item) {
			foreach ($date_list as $index_ => $item_) {
				if (in_array($item['week'], $item_['week']) || in_array($item['date_short'], $item_['date'])) {
					$alldate[$index]['count'][$item_['id']] = 1;
				}
			}
		}
		$lat = floatval($_GET['lat']);
		$lng = floatval($_GET['lng']);
		$navtitle = $hk_config['indextitle'];
		$desc = $hk_config['indexdesc'];
		$indeximg = $hk_config['indeximg'];
		break;
	case 'dopay':
		if (submitcheck('formhash')) {
			$form = $_GET['form'];
			if ($rmobile = $_GET['rmobile']) {
				if (!preg_match($isMob, $rmobile) && !preg_match($isTel, $rmobile)) {
					hb_message(lang_hk('sjhgscw', 0) . $rmobile, 'loading', 'javascript:setTimeout(function(){showUserBox(\'' . $form['paytype'] . '\',\'' . $form['cardtype'] . '\',\'' . $form['cardno'] . '\');}, 1000);');
				}
				C::t('#xigua_hb#xigua_hb_user')->update($_G['uid'], array('mobile' => $rmobile, 'realname' => $_GET['rname']));
			}
			$myu = C::t('#xigua_hb#xigua_hb_user')->fetch($uid);
			if (!$myu['mobile']) {
				hb_message(lang_hk('qszsjh', 0), 'loading', 'javascript:setTimeout(function(){showUserBox(\'' . $form['paytype'] . '\',\'' . $form['cardtype'] . '\',\'' . $form['cardno'] . '\');}, 1000);');
			}
			if ($form['paytype'] == 2) {
				$numdata = C::t('#xigua_hk#xigua_hk_num')->fetch_by_cardnum($form['cardno']);
				if (!$numdata) {
					hb_message(lang_hk('jhmcw', 0), 'error');
				}
				C::t('#xigua_hk#xigua_hk_num')->update($numdata['id'], array('uid' => $_G['uid'], 'usets' => TIMESTAMP));
				if ($cardexists = C::t('#xigua_hk#xigua_hk_card')->fetch_by_uid($_G['uid'])) {
					C::t('#xigua_hk#xigua_hk_card')->update($cardexists['cardno'], array('cardnum' => $numdata['cardnum']));
					C::t('#xigua_hk#xigua_hk_card')->update_endts($cardexists['cardno'], $numdata['lastts'], '');
				} else {
					$cardata = array('uid' => $_G['uid'], 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'status' => 1, 'order_id' => '', 'price' => 0, 'stid' => $_GET['st'], 'endts' => TIMESTAMP + $numdata['lastts'], 'cardnum' => $numdata['cardnum']);
					$cardno = C::t('#xigua_hk#xigua_hk_card')->insert($cardata, 1);
				}
				hb_message(lang_hk('jhcg', 0), 'success', $SCRITPTNAME . '?id=xigua_hk' . $urlext);
			} else {
				$cardkind = $cardtype[intval($form['cardtype'])];
				if (!$cardkind) {
					hb_message(lang_hk('sjyc', 0), 'error');
				}
				$price = $cardkind[2];
				if ((IN_MOCUZ || IN_MAGAPP || IN_QIANFAN || IN_APPBYME) && $cardkind[5] > 0) {
					$price = $cardkind[5];
				}
				$days = $cardkind[1];
				$cardata = array('uid' => $_G['uid'], 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'status' => 0 - 1, 'order_id' => '', 'price' => $price, 'stid' => $_GET['st'], 'endts' => 0, 'cardinfo' => serialize($cardkind));
				if ($price >= 0) {
					$new = 0;
					if ($cardexists = C::t('#xigua_hk#xigua_hk_card')->fetch_by_uid($_G['uid'])) {
						$cardno = $cardexists['cardno'];
						$typeti = lang_hk('xfhk', 0);
						if ($form['cardtype'] == count($cardtype) - 1) {
							$cardata['tiyannum'] = $cardexists['tiyannum'] + 1;
						}
						C::t('#xigua_hk#xigua_hk_card')->update($cardno, array('upts' => TIMESTAMP, 'stid' => $_GET['st'], 'cardinfo' => serialize($cardkind)));
					} else {
						$cardno = C::t('#xigua_hk#xigua_hk_card')->insert($cardata, 1);
						$typeti = lang_hk('kthk_', 0);
						$new = 1;
						if ($form['cardtype'] == count($cardtype) - 1) {
							$cardata['tiyannum'] = 1;
						}
					}
					if ($cardata['tiyannum']) {
						C::t('#xigua_hk#xigua_hk_card')->update($cardno, array('tiyannum' => $cardata['tiyannum']));
					}
					if ($hk_config['tiyanmax'] > 0) {
						if ($hk_config['tiyanmax'] < $cardata['tiyannum']) {
							hb_message(str_replace(array('n'), array($hk_config['tiyanmax']), $cardkind[0] . lang_hk('tiyanmaxn', 0)), 'error');
						}
					}
					$cardata['cardno'] = $cardno;
					$url = $_GET['backto'] ? $_GET['backto'] : $SCRITPTNAME . '?id=xigua_hk&ac=my' . $urlext;
					if ($price > 0) {
						$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price, $_G['username'] . $typeti . $cardkind[0], 'com', array('data' => $cardata, 'callback' => array('file' => 'source/plugin/xigua_hk/function.php', 'method' => 'hk_join_call_back'), 'location' => $_GET['backto'] ? $_GET['backto'] : $_G['siteurl'] . $url));
						if ($new) {
							C::t('#xigua_hk#xigua_hk_card')->update($cardno, array('order_id' => $order_id));
						}
						$rl = urlencode($url);
						$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
						hb_message(lang_hk('jumppay', 0), 'success', $jumpurl);
					} else {
						C::t('#xigua_hk#xigua_hk_card')->update_endts($cardata['cardno'], $cardkind[1] * 86400, '');
						hb_message(lang_hk('czcg', 0), 'success', $SCRITPTNAME . '?id=xigua_hk' . $urlext);
					}
				}
			}
		}
		break;
	case 'manage':
		$navtitle = lang_hk('hdgl', 0);
		$custom_side = array($SCRITPTNAME . '?id=xigua_hk' . $urlext, lang_hk('shouye', 0));
		if ($_G['cache']['plugin']['xigua_hs']) {
			$where = array();
			$where[] = 'uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP;
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where, $start_limit, $lpp);
		}
		break;
	case 'good_li':
		$viewtype = $_GET['viewtype'];
		if (!$viewtype) {
			$viewtype = $orderby = $_GET['orderby'];
		}
		$manage = IS_ADMINID && $ac == 'manage';
		$field = '*';
		$where = array();
		if ($_GET['is_my'] && $_G['uid'] > 0) {
			if ($_GET['offline'] == 1) {
				$where[] = 'uid=' . $_G['uid'] . ' and status<>3 and endts<>\'0\' AND endts<' . TIMESTAMP;
			} elseif ($_GET['offline'] == 2) {
				$where[] = 'uid=' . $_G['uid'] . ' and status=3';
			} else {
				if ($_GET['shen']) {
					$where[] = 'uid=' . $_G['uid'] . ' and status=1';
				} else {
					$where[] = 'uid=' . $_G['uid'] . ' and status=2 and (endts=0 OR endts>=' . TIMESTAMP . ')';
				}
			}
		} else {
			$where[] = 'status=2 and stock>0 and (endts=0 OR endts>=' . TIMESTAMP . ')';
			if (!$date_now) {
				$date_now = date('Y-m-d');
			}
			if ($date_now == date('Y-m-d')) {
				$date_show = lang_hk('jt', 0);
			} else {
				$date_show = date('m-d', strtotime($date_now));
			}
			if ($wdate = date('j', strtotime($date_now))) {
				$wdate_ = str_replace('x', $wdate, lang_hk('myj', 0));
				$wkindex = date('w', strtotime($date_now));
				$wweek_ = $weekarray[$wkindex];
				$where[] = ' (FIND_IN_SET( \'' . $wdate_ . '\', `date` ) OR FIND_IN_SET(\'' . $wweek_ . '\', `week`) ) ';
			}
			if ($hyid = intval($_GET['hyid'])) {
				$pids = array($hyid);
				if ($hyinfo = C::t('#xigua_hs#xigua_hs_hangye')->get_childs_by_pids($hyid)) {
					foreach ($hyinfo as $index => $item) {
						$pids[] = intval($item['id']);
					}
					if ($pids) {
						$where[] = ' hangye_id2 IN(' . implode(',', $pids) . ') ';
					}
				} else {
					$where[] = ' hangye_id2 =' . $hyid;
				}
			}
			if ($city = daddslashes($_GET['city'])) {
				if ($city != '-1') {
					$where[] = ' (province=\'' . $city . '\' OR  city=\'' . $city . '\' OR district=\'' . $city . '\') ';
				}
			}
			if ($_GET['not']) {
				$where[] = ' id !=' . intval($_GET['not']);
			}
			if ($_GET['orderby'] == 'nearby') {
				$lat = floatval($_GET['lat']);
				$lng = floatval($_GET['lng']);
				$lngstr = $lng > 0 ? ' - ' . $lng : ' + ' . abs($lng);
				$field = '*, acos(cos((lng ' . $lngstr . ') * 0.01745329252) * cos((lat - ' . $lat . ') * 0.01745329252)) * 6371004 as distance';
				$order_by = 'distance ASC';
			} elseif ($_GET['orderby'] == 'views') {
				$order_by = ' views DESC,rate ASC ';
			} elseif ($_GET['orderby'] == 'sellnum') {
				$order_by = ' sellnum DESC,rate ASC ';
			} else {
				$order_by = ' displayorder DESC, rate ASC, stock DESC ';
			}
		}
		$list = C::t('#xigua_hk#xigua_hk_good')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);
		if ($_GET['orderby'] == 'nearby') {
			foreach ($list as $k => $v) {
				$distance = intval($v['distance']);
				if ($distance <= 1000) {
					$distance = intval($distance) . 'm';
				} else {
					if ($distance > 1000) {
						$distance = round($distance / 1000, 1) . 'km';
					}
				}
				$list[$k]['distance'] = $distance;
			}
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_hk:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'add':
		$navtitle = lang_hk('new_pub', 0);
		if ($_G['cache']['plugin']['xigua_hs']) {
			$where = array();
			$where[] = 'uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP;
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
		}
		if ($gid = $_GET['gid']) {
			$navtitle = lang_hk('xghd', 0);
			$old_data = C::t('#xigua_hk#xigua_hk_good')->fetch_G($gid);
			if (!$old_data) {
				dheader('Location: ' . $SCRITPTNAME . '?id=xigua_hk&ac=manage' . $urlext);
			}
		}
		if (submitcheck('formhash')) {
			$data = $srg = $append_img = $append_text = array();
			$form = $_GET['form'];
			$required = array('title', 'shname', 'endts', 'attention', 'jieshao');
			foreach ($required as $index => $item) {
				$form[$item] = trim($form[$item]);
				if (!$form[$item]) {
					hb_message(lang_hk($item . '_tip', 0), 'error');
				}
			}
			if (!$form['week'] && !$form['date']) {
				hb_message(lang_hk('date_tip', 0), 'error');
			}
			if (!($sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']))) {
				hb_message(lang_hk('shname_tip', 0), 'error');
			}
			foreach ($svicerange as $index => $item) {
				if ($form['tagid'][$index]) {
					$srg[] = $item;
				}
			}
			foreach ($form['append_img'] as $index => $item) {
				$append_img[] = $item;
				$append_text[] = $form['append_text'][$index];
			}
			$up = $form['id'] > 0;
			if ($up) {
				$data['upts'] = TIMESTAMP;
			} else {
				$data['uid'] = $_G['uid'];
				$data['crts'] = TIMESTAMP;
			}
			if ($form['zktype']) {
				$data['lijian'] = $form['lijian'];
				$data['zktype'] = $form['zktype'];
				if (!$form['lijian']) {
					hb_message(lang_hk('lijian_tip', 0), 'error');
				}
			} else {
				if (isset($form['zktype'])) {
					if (!$form['rate']) {
						hb_message(lang_hk('rate_tip', 0), 'error');
					}
					$data['zktype'] = '';
					$data['lijian'] = '0';
				}
			}
			$data['title'] = $form['title'];
			$data['startts'] = intval(strtotime($form['startts']));
			$data['endts'] = intval(strtotime($form['endts']));
			if ($data['startts'] >= $data['endts']) {
				hb_message(lang_hk('timeerror', 0), 'error');
			}
			$data['shname'] = $sh['name'];
			$data['shid'] = $sh['shid'];
			$data['hangye_id1'] = $sh['hangye_id1'];
			$data['hangye_id2'] = $sh['hangye_id2'];
			$data['lat'] = $sh['lat'];
			$data['lng'] = $sh['lng'];
			$data['province'] = $sh['province'];
			$data['district'] = $sh['district'];
			$data['city'] = $sh['city'];
			$data['sellnum'] = $form['sellnum'];
			$data['stock'] = $form['stock'] ? $form['stock'] : 999999999;
			$data['srange'] = implode('	', $srg);
			$data['notice'] = $form['notice'];
			$data['week'] = $form['week'];
			$data['date'] = $form['date'];
			$data['rate'] = $form['rate'];
			$data['bigweek'] = $form['bigweek'];
			$data['bigdate'] = $form['bigdate'];
			$data['bigrate'] = $form['bigrate'];
			$data['manmax'] = $form['manmax'];
			$data['maxmoney'] = $form['maxmoney'];
			$data['attention'] = $form['attention'];
			$data['jieshao'] = $form['jieshao'];
			$data['append_img'] = serialize($append_img);
			$data['append_text'] = serialize($append_text);
			$data['album'] = serialize($form['album']);
			$data['crts'] = TIMESTAMP;
			$data['status'] = 2;
			$data['stid'] = intval($_GET['st']);
			$data['autostock'] = intval($form['autostock']);
			if ($hk_config['needshen']) {
				$data['status'] = 1;
			}
			if ($up) {
				$rs = C::t('#xigua_hk#xigua_hk_good')->update_G($form['id'], $data);
			} else {
				$data['upts'] = $data['crts'];
				$rs = C::t('#xigua_hk#xigua_hk_good')->insert($data);
			}
			if ($rs) {
				if ($up) {
					$tip = $hk_config['needshen'] ? lang_hk('xgcg1', 0) : lang_hk('xgcg', 0);
				} else {
					$tip = $hk_config['needshen'] ? lang_hk('fbcg1', 0) : lang_hk('fbcg', 0);
				}
				hb_message($tip, 'success', $up ? 'javascript:window.history.go(-1);' : $SCRITPTNAME . '?id=xigua_hk&ac=manage&is_my=1' . $urlext);
			}
		} else {
			$dftshname = $sh[0]['name'];
		}
		break;
	case 'stock_edit':
		if (submitcheck('formhash')) {
			$data = array();
			if ($do == 'del') {
				$data['status'] = 3;
				$rs = C::t('#xigua_hk#xigua_hk_good')->update_G($gid, $data);
				hb_message(lang_hk('xjcg', 0), 'success', 'javascript:window.location.reload();');
			} elseif ($do == 'shangjia') {
				$data['status'] = 2;
				$rs = C::t('#xigua_hk#xigua_hk_good')->update_G($gid, $data);
				hb_message(lang_hk('sjcg', 0), 'success', 'javascript:window.location.reload();');
			}
		}
		break;
	case 'join':
		$mynew = C::t('#xigua_hb#xigua_hb_pub')->fetch_newest_one($_G['uid']);
		$lastrealname = $mynew['realname'];
		$lastmobile = $mynew['mobile'];
		$navtitle = $hk_config['kaikat'];
		$desc = $hk_config['kaikad'];
		$card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G['uid']);
		$card_num = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card_num();
		$backto = $_GET['backto'];
		break;
	default:
		if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_hk/include/c_' . $ac . '.php'))) {
			include DISCUZ_ROOT . ('source/plugin/xigua_hk/include/c_' . $ac . '.php');
		}
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_hk/template/touch/' . $ac . '.php'))) {
	include template('xigua_hk:' . $ac);
}