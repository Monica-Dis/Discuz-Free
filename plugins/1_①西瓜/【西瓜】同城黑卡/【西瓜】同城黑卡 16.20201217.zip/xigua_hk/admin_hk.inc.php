<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_hk/function.php';$card_status = array(
    '-1' => lang_hk('cstatus-1',0),
    '1' => lang_hk('cstatus1',0),
    '2' => lang_hk('cstatus2',0),
);

$hk_config = $_G['cache']['plugin']['xigua_hk'];

$page = max(1, intval(getgpc('page')));
$lpp = $_GET['lpp']? $_GET['lpp'] : 20;
$start_limit = ($page - 1) * $lpp;

function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}
if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hk#xigua_hk_card')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $no => $item) {
            $item['endts'] = strtotime($item['endts']);
            C::t('#xigua_hk#xigua_hk_card')->update($no, $item);
        }
    }
    if($n = $_GET['n']){
        foreach ($n['uid'] as $index => $uid) {
            $uid = intval($uid);
            if($uid<1){
                continue;
            }
            if(C::t('#xigua_hk#xigua_hk_card')->fetch_by_uid($uid)){
                continue;
            }
            $endts = strtotime($n['endts'][$index]);
            $status = $n['status'][$index];
            $data = array(
                'uid'      => $uid,
                'crts'     => TIMESTAMP,
                'upts'     => TIMESTAMP,
                'endts'    => $endts,
                'status'   => $status,
            );
            C::t('#xigua_hk#xigua_hk_card')->insert($data);
        }
    }

    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_hk&page=$page&lpp=$lpp", 'succeed');
}

$wherearr = array();
$keyword = $_GET['keyword'];
if ($keyword = stripsearchkey($keyword)) {
    $wherearr[] = " (uid='$keyword' ) ";
}
if($_GET['hxstatus']){
    $hxstatus = intval($_GET['hxstatus']);
    $wherearr[] = "status='$hxstatus'";
}
$list = C::t('#xigua_hk#xigua_hk_card')->fetch_all_by_where($wherearr, $start_limit, $lpp, 'cardno DESC');
$totalcount = C::t('#xigua_hk#xigua_hk_card')->fetch_count_by_page($wherearr);

foreach ($list as $v) {
    $uids[] = $v['uid'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $reals = DB::fetch_all('SELECT uid,realname,mobile FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}
$multipage = multi(
    $totalcount, $lpp, $page,
    ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_hk&page=$page&lpp=$lpp"
);

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_hk&pmod=admin_hk&page=$page&lpp=$lpp", 'enctype');

echo '<input type="text" id="keyword" placeholder="'.lang_hk('uid',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
foreach ($card_status as $index => $_v) {
    echo '<label><input type="radio" name="hxstatus" value="'.$index.'" ' . (isset($_GET['hxstatus'])&&$_GET['hxstatus']==$index&&$_GET['hxstatus']!=='' ? 'checked' : '') . ' />' . $_v.'</label>';
}

$lpp_se = " <select name=\"lpp\">";
foreach (array(20, 50, 100, 200, 500, 1000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;
echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_hk&formhash=".formhash()."&doexport=1&keyword={$_GET['keyword']}&hxstatus={$_GET['hxstatus']}&lpp=$lpp".' class="btn" >'.lang_hk('dc', 0).'</a> ';

$alink = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_st&pmod=admin_pub&catadd";
?>
<style>
    .imgi{height:20px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
    .short{width:100px}
    .td23 input{width:80px!important;}
</style>
<table class="tb tb2 ">
    <?php

    showtablerow('class="header"',array(),array(
        lang_hb('del', 0),
        lang_hb('UID', 0).'/'.lang_hb('username', 0),
        lang_hk('endts', 0),
        lang_hk('status', 0),
        lang_hk('reals', 0),
        lang_hk('cardinfo', 0),
        lang_hk('uses', 0),
        lang_hk('kaitongts', 0),
        lang_hk('payts', 0),
    ));


    foreach ($list as $k => $v) {
        $no = $v['cardno'];
        $uid = $v['uid'];
        $cinfo = unserialize($v['cardinfo']);
        $d = lang_hk('t',0);
        $yuan = lang_hk('yuan',0);
        $order_id = lang_hk('order_id',0);
        $jhm = lang_hk('jhm',0);
        $endts = date('Y-m-d H:i:s', $v['endts']);

        $sel = $seltype = '';
        foreach ($card_status as $index => $item) {
            if($v['status'] == $index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$no' /> $no",
            "[UID: $uid]<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
            "<input style='width:180px' name='r[$no][endts]' value='$endts' onclick=\"showcalendar(event, this, 1)\" />",
            "<select name='r[$no][status]'>$sel</select>",
            $reals[$uid]['realname']."<br>".$reals[$uid]['mobile'],
            $cardinfo = $v['cardnum'] ? "<p> $jhm: {$v['cardnum']} </p>": "<p>$order_id: $v[order_id]</p><p>$cinfo[0]</p><p>$cinfo[1] $d</p><p>$cinfo[2] $yuan</p> ",
            $v['usetime'],
            $upts_u = $v['crts'] ? date('Y-m-d H:i:s', $v['crts']) : '',
            $v['payts'] ? date('Y-m-d H:i:s', $v['payts']) : '',
        ));


        $list[$k]['uid'] = "[UID: {$v['uid']}]". $users[$v['uid']]['username'];
        $list[$k]['crts'] = $v['crts_u'];
        $list[$k]['cardinfo'] = strip_tags($cardinfo);
        $list[$k]['upts'] = $upts_u;
        $list[$k]['endts'] = $v['endts_u'];
        $list[$k]['status'] = $card_status[$v['status']];
        $list[$k]['endts'] = date('Y-m-d H:i:s', $v['endts']) ;
        unset($list[$k]['usets']);
        unset($list[$k]['src']);
        unset($list[$k]['note']);
        unset($list[$k]['crts_u']);
        unset($list[$k]['upts_u']);
        unset($list[$k]['endts_u']);
        unset($list[$k]['hxcrts_u']);
        unset($list[$k]['isend']);
        unset($list[$k]['status_u']);
    }
    if(submitcheck('formhash', 1) && $_GET['doexport']==1 && $_GET['formhash'] == FORMHASH){
        $title_arr= array();
        foreach ($list[0] as $index => $item) {
            $title_arr[] = lang_hk($index,0);
        }
        export_csv($list, $title_arr);
    }
    ?>
    <tbody>
    <tr>
        <td>&nbsp;</td>
        <td colspan="99"><div>
                <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hk('new_card')?></a>
            </div></td>
    </tr>
    <?php
    if($multipage){
        showtablerow('', 'colspan="99"', $multipage);
    }
    showsubmit('permsubmit', 'submit', 'td');

    $sel = '';
    foreach ($card_status as $index => $item) {
        if($v['status'] == $index){
            $sel .= "<option value=\"$index\" selected>$item</option>";
        }else{
            $sel .= "<option value=\"$index\">$item</option>";
        }
    }
    ?>
    </tbody>
</table>
</form>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script>
    var rowtypedata = [
        [
            [1, ''],
            [2, '<input name="n[uid][]" placeholder="<?php lang_hk('uid')?>" size="15" type="text" class="txt" />'],
            [1, '<input onclick="showcalendar(event, this, 1)" name="n[endts][]" placeholder="<?php lang_hk('endts')?>" size="40" type="text" class="txt" />'],
            [99,'<div>  <select name="n[status][]"><?php echo $sel;?></select> <a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hk('del')?></a></div>']
        ]
    ];
    function _delid(id, name){
        if(confirm('<?php lang_hk('del_confirm')?>' + name + '?')){
            window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_hk&page=$page&lpp=$lpp&del=1&formhash=".FORMHASH.'&catid='?>"+id;
        }
    }
</script>