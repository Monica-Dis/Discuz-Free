<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div data-id="{$v[id]}" data-date="{$_GET['date']}" class="lingqu_li weui-cell">
    <div class="weui-cell__hd" id="rate{$v[id]}">
        <!--{if $goods[$v[gid]][zktype]=='q'}-->
        <span>{$goods[$v[gid]][lijian]}</span><em>{lang xigua_hb:yuan}</em>
        <!--{else}-->
        <span>$v[rate]</span><em>{lang xigua_hk:zhe}</em>
        <!--{/if}-->
    </div>
    <div class="weui-cell__bd">
        <a href="$SCRITPTNAME?id=xigua_hk&ac=view&gid=$v[gid]&date=$v[usedate]&">{$goods[$v[gid]][title]}</a>
        <ul class="lingqu_ul">
            <li id="usedate{$v[id]}">{lang xigua_hk:jx}{$v[usedate]}{lang xigua_hk:syong}</li>
            <!--{if $goods[$v[gid]][maxmoney]}--><li id="maxmoney{$v[id]}">{lang xigua_hk:man}{$goods[$v[gid]][maxmoney]}{lang xigua_hk:yksy}</li><!--{else}--><li id="maxmoney{$v[id]}">{lang xigua_hk:wxz}</li><!--{/if}-->
            <!--{if $goods[$v[gid]][attention]}--><li id="att{$v[id]}">{$goods[$v[gid]][attention]}</li><!--{/if}-->

            <!--{if $v[hxstatus]}-->
            <li style="margin-top:5px">{lang xigua_hk:dm}: {$goods[$v[gid]][shname]}</li>
            <!--{if $goods[$v[gid]][zktype]=='q'}-->
            <li>{lang xigua_hk:xf}: &yen;{$v[hxmoney]} {lang xigua_hk:ss}: &yen;{echo floatval($v[hxmoney]-$goods[$v[gid]][lijian]);}</li>
            <!--{else}-->
            <li>{lang xigua_hk:xf}: &yen;{$v[hxmoney]} {lang xigua_hk:ss}: &yen;{$v[hxratemoney]}</li>
            <!--{/if}-->
            <li>{lang xigua_hk:czr}:{$hxusers[$v[hxuid]][username]}</li>
            <!--{/if}-->
        </ul>
    </div>
    <div class="weui-cell__ft">
        <div>
            <!--{if $v[hxstatus]}-->
            <span class="liqing_time">{lang xigua_hk:y}{$v[hxcrts_u]}{lang xigua_hk:xf}</span>
            <a class="usebtn used" href="javascript:;">{lang xigua_hk:ysy}</a>
            <!--{else}-->
            <!--{if $v[isend]}-->
            <a class="usebtn expired" href="javascript:;">{lang xigua_hk:ygq}</a>
            <!--{else}-->
            <a class="usebtn" data-shid="{$goods[$v[gid]][shid]}" data-title="{$goods[$v[gid]][title]}" data-lingquid="$v[id]" data-src="$v[src]" data-chushi="{$goods[$v[gid]][title]}" data-date="$v[usedate]" data-gid="$v[gid]" data-id="$v[id]" >{lang xigua_hk:jdsy}</a>
            <!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{/loop}-->