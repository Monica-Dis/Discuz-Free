<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hk:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hk&ac=my_order&is_my=1" class="weui-navbar__item <!--{if !$_GET[type]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hk:qb}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_hk&ac=my_order&is_my=1&type=unuse" class="weui-navbar__item <!--{if $_GET[type]=='unuse'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hk:wsy}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_hk&ac=my_order&is_my=1&type=used" class="weui-navbar__item <!--{if $_GET[type]=='used'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hk:ysy}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_hk&ac=my_order&is_my=1&type=expired" class="weui-navbar__item <!--{if $_GET[type]=='expired'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hk:ygq}</span> </a>
    </div>

    <div>
        <div id="list" class="mod-post x-postlist p0" style="background:#f8f8f8!important;"></div>
        <!--{template xigua_hb:loading}-->
    </div>

    <div class="footer_fix"></div>
</div>
<script>
    var loadingurl = window.location.href+'&ac=lingqu_li&is_my=1&inajax=1&page=';
</script>
<!--{eval $hk_tabbar=1;}-->
<!--{template xigua_hk:footer}-->