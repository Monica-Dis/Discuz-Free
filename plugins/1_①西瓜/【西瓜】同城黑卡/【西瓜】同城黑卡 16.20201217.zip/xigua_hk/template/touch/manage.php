<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
if(!$sh[0][name]):
dheader('Location:'.$SCRITPTNAME.'?id=xigua_hk&ac=none');
endif;
}--><!--{template xigua_hk:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hk&ac=manage&is_my=1" class="weui-navbar__item <!--{if !$_GET[offline]&&!$_GET[shen]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hk:jxz}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_hk&ac=manage&is_my=1&shen=1" class="weui-navbar__item <!--{if $_GET[shen]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hk:dsh}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_hk&ac=manage&is_my=1&offline=1" class="weui-navbar__item <!--{if $_GET[offline]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hk:yjs}</span> </a>
        <a href="$SCRITPTNAME?id=xigua_hk&ac=manage&is_my=1&offline=2" class="weui-navbar__item <!--{if $_GET[offline]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hk:yxj}</span> </a>
    </div>

    <div>
        <div id="list" class="mod-post x-postlist p0"></div>
        <!--{template xigua_hb:loading}-->
    </div>

    <div class="footer_fix"></div>
</div>
<a href="$SCRITPTNAME?id=xigua_hk&ac=add" class="float_btn"><i class="iconfont icon-zengjia"></i> {lang xigua_hk:new_pub}</a>

<script>
    var loadingurl = window.location.href+'&ac=good_li&inajax=1&page=';
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hk:footer}-->
<script>
    $(document).on('click','.stock-del', function () {
        var that = $(this);
        $.confirm({
            title: that.data('do')=='del'?'{lang xigua_hk:qrxj}':'{lang xigua_hk:qrsj}',
            text: that.data('do')=='del'?'{lang xigua_hk:qrxjtip}':'',
            onOK: function () {$.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_hk&ac=stock_edit&do='+that.data('do')+'&inajax=1',
                    data:{formhash:'{FORMHASH}', gid: that.data('id')},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });
    });
</script>