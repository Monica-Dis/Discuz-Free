<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hk:header}-->
<div class="page__bd">
    <div>
        <div class="hk_glist bgf">
            <div class="top">
                <div class="pic">
                    <img src="{$v['good'][album][0]}">
                </div>
                <div class="txt">
                    <h3 class="tit">{$v['good'][title]}</h3>
                    <p class="f12 c9">{$v[sh][name]}</p>
                    <p class="f12 c9">{lang xigua_hk:jx}{$v[usedate]}{lang xigua_hk:syong}</p>
                    <!--{if $v['good'][maxmoney]}--><p class="f12 c9">{lang xigua_hk:man}{$v['good'][maxmoney]}{lang xigua_hk:yksy}</p><!--{/if}-->
                    <!--{if $v['good'][attention]}--><p class="f12 c9">{$v['good'][attention]}</p><!--{/if}-->
                <div class="right_act abs">
                    <!--{if $v['good'][zktype]=='q'}-->
                    <span class="color-p f30">{$v['good'][lijian]}</span>
                    <em class="color-p">{lang xigua_hb:yuan}{lang xigua_hk:lj}</em>
                    <!--{else}-->
                    <span class="color-p f30">$v[rate]</span>
                    <em class="color-p">{lang xigua_hk:zhe}</em>
                    <!--{/if}-->
                </div>
            </div>
        </div>
    </div>

    <form action="$SCRITPTNAME?id=xigua_hk&ac=scan&mobile=2{$urlext}" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >
        <input type="hidden" name="backto" value="$backto" >
        <input type="hidden" name="lingquid" value="$v[id]" >
        <input type="hidden" name="code" value="$v[code]" >
    <div class="weui-cells before_none">
        <div class="weui-cell">
            <div class="weui-cell__hd">
                <img style="width:24px;border-radius:24px;display:block" src="{avatar($v['uid'], 'middle', true)}">
            </div>
            <div class="weui-cell__bd">
                <p>{$v[user][username]}</p>
            </div>
            <div class="weui-cell__ft">{lang xigua_hk:jrysy}{$todayuse}{lang xigua_hk:c}</div>
        </div>
        <div class="weui-cell ">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hk:xfje}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" type="text" name="form[hxmoney]" value="" placeholder="{lang xigua_hk:qtxxfje}">
            </div>
            <div class="weui-cell__ft">{lang xigua_hk:yuan}</div>
        </div>
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <textarea class="weui-textarea" placeholder="{lang xigua_hk:xfbz}" name="form[hxnote]" rows="3"></textarea>
            </div>
        </div>
    </div>
        <label for="weuiAgree" class="weui-agree">
            <span class="weui-agree__text">
                {lang xigua_hk:dqczr}: <a href="javascript:void(0);">$_G[username]</a>
            </span>
        </label>
        <div class="fix-bottom" style="position:relative">
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hk:qrhx}">
        </div>
    </form>

</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hk:footer}-->
<script>
function hxcheck(){
    <!--{if !$access}-->
    $.prompt("{lang xigua_hs:qsrhxmm}", function(text) {
        $.showLoading();
        $.ajax({
            type: 'post',
            url: '$SCRITPTNAME?id=xigua_hs&ac=setpwd&type=check&inajax=1&shid={$v[shid]}',
            data:{formhash:'{FORMHASH}',  hxpwd:text},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                var sar = s.split('|');
                tip_common(s);
            },
            error: function () {
                $.hideLoading();
            }
        });

    }, function() {
        window.location.reload();
    });
    return false;
    <!--{/if}-->
    <!--{if !$v}-->
    $.alert("{lang xigua_hk:yhqbcz}", "{lang xigua_hk:ts}", function() {
        window.location.href = _APPNAME+"?id=xigua_hk&mobile=2"+_URLEXT;
    });
    return false;
    <!--{/if}-->
    <!--{if $v[isend]}-->
    $.alert("{lang xigua_hk:yxqygq}", "{lang xigua_hk:ts}", function() {
        window.location.href = _APPNAME+"?id=xigua_hk&mobile=2"+_URLEXT;
    });
    return false;
    <!--{/if}-->
    <!--{if $v[hxstatus]}-->
    $.alert("{lang xigua_hk:yhqcf}", "{lang xigua_hk:ts}", function() {
        window.location.href = _APPNAME+"?id=xigua_hk&mobile=2"+_URLEXT;
    });
    return false;
    <!--{/if}-->
    <!--{if $v[usedate]!=$date_now}-->
    $.alert("{lang xigua_hk:jin}{$v[usedate]}{lang xigua_hk:dtkyhx}", "{lang xigua_hk:ts}", function() {
        //window.location.href = _APPNAME+"?id=xigua_hk&mobile=2"+_URLEXT;
    });
    return false;
    <!--{/if}-->
}
hxcheck();
function showRate(tip, gid){
    $.alert(tip, "{lang xigua_hk:txfk}", function() {
        window.location.href = _APPNAME+"?id=xigua_hk&ac=hxlog&gid="+gid+"&mobile=2"+_URLEXT;
    });
}
</script>