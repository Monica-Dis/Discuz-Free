<?php exit('xigua_hb'); ?>
<li class="sub_check border_bfull"><a class="ftb color-red" data-idid="3" data-sort="&id=xigua_hk&ac=good_li&city={$_GET[ctid]}" href="javascript:;" data-orihtml="{$_GET[name]}">{lang xigua_hk:quan}{$_GET[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a></li>
<!--{loop $rlist $v}-->
<li class="sub_check1 border_bfull "><a class="ftb" data-idid="3" data-sort="&id=xigua_hk&ac=good_li&city={$v[name]}"  href="javascript:;" >$v[name]</a></li>
<!--{/loop}-->