<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hk:header}-->
<div class="page__bd <!--{if $hk_config[cardstyle]==1}-->index_bd<!--{else}-->style2_bd<!--{/if}-->"><!--{if $indeximg}--><div style="width:0;height:0;display:none">$indeximg</div><!--{/if}-->
    <!--{template xigua_hk:card}-->
<!--{if $hk_config[indexdt]}-->
    <!--{eval
    $newest =  C::t('#xigua_hk#xigua_hk_card')->fetch_newest_card(8);
    }-->
    <div class="hk_toutiao">
        <div class="chip-row">
            <div class="toutiao"><i class="iconfont icon-tongzhi f14 "></i>{lang xigua_hk:dt}</div>
            <div class="toutiao-slider swiper-container" id="newsSlider">
                <ul class="swiper-wrapper">
                    <!--{loop $newest $_v}-->
                    <li class="swiper-slide">
                        <a> <img src="{avatar($_v['uid'], 'small', true)}" /> <em class="main_color">{$_v[username]}</em>{lang xigua_hk:gg}{$_v[cardinfo_ary][0]}</a></li>
                    <!--{/loop}-->
                </ul>
            </div>
            <a class="toutiao toutiao_in main_bg" href="$SCRITPTNAME?id=xigua_hk&ac=join&from=index{$urlext}">{lang xigua_hk:kk}</a>
        </div>
    </div>
<!--{/if}-->

    <div class="cl hk_mlist">
    <!--{if $alldate}-->
    <div class="swiper-container hk_swiper">
        <div class="swiper-wrapper">
            <!--{loop $alldate $_k $_lv}-->
            <div class="swiper-slide light_box">
                <a href="javascript:;" data-date="{$_lv[date]}" <!--{if $_k==0}-->class="main_color"<!--{/if}-->>
                    <span>{echo count($_lv[count]);}</span>
                    <p class="f14"><!--{if $_k==0}-->{lang xigua_hk:jt}<!--{else}-->$_lv[week]<!--{/if}--></p>
                    <p>$_lv[date_mid]</p>
                </a>
            </div>
            <!--{/loop}-->
        </div>
    </div>
    <!--{/if}-->

        <!--{template xigua_hk:filter}-->
    </div>
</div>

<!--{eval $hk_tabbar=1;}-->
<!--{template xigua_hk:footer}-->