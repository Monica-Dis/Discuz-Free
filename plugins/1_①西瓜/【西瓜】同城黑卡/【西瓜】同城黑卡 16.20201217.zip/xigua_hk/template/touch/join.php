<?php exit('xigua_hk');?>
<!--{template xigua_hk:header}-->
<div class="page__bd"><!--{if $hk_config[kaikaimg]}--><div style="width:0;height:0;display:none">$hk_config[kaikaimg]</div><!--{/if}-->
    <!--{if stripos($_SERVER['HTTP_USER_AGENT'], 'Android') && HB_INWECHAT}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <form action="$SCRITPTNAME?id=xigua_hk&ac=dopay&mobile=2{$urlext}" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >
        <input type="hidden" name="form[paytype]" id="paytype" value="1" >
        <input type="hidden" name="backto" value="$backto" >

        <!--{if $hk_config[cardstyle]==1}-->
        <div class="card-header main_bg">
        <!--{else}-->
        <div class="bgf" style="padding-bottom:1px;overflow:hidden">
        <!--{/if}-->
            <!--{template xigua_hk:card}-->
            <div class="card_other">
                <div class="card_num"><div class="inner"><span class="num" id="njum1">{$card_num}</span> {lang xigua_hk:rykk}</div></div>
            </div>
        </div>
            <!--{eval
$newest =  C::t('#xigua_hk#xigua_hk_card')->fetch_newest_card(8);
}-->
            <div class="hk_toutiao" style="margin-bottom:0">
                <div class="chip-row">
                    <div class="toutiao"><i class="iconfont icon-tongzhi f14 "></i>{lang xigua_hk:dt}</div>
                    <div class="toutiao-slider swiper-container" id="newsSlider">
                        <ul class="swiper-wrapper">
                            <!--{loop $newest $_v}-->
                            <li class="swiper-slide">
                                <a> <img src="{avatar($_v['uid'], 'small', true)}" /> <em class="main_color">{$_v[username]}</em>{lang xigua_hk:gg}{$_v[cardinfo_ary][0]}</a></li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
            </div>

    <div class="join_body <!--{if $hk_config[cardstyle]==2}-->join_body2<!--{/if}-->">

        <div class="weui-navbar" style="border-top: 10px solid #f8f8f8;">
            <a href="javascript:;" class="navbar weui-navbar__item weui_bar__item_on" data-display="checktype" data-hide="inputcode" data-id="paytype" data-value="1">
                <span>{lang xigua_hk:zxzf}</span>
            </a>
            <a href="javascript:;" class="navbar weui-navbar__item" data-display="inputcode" data-hide="checktype" data-id="paytype" data-value="2">
                <span>{lang xigua_hk:syjhm}</span>
            </a>
        </div>
        <div class="weui-cells weui-cells_checkbox mt0 before_none" id="checktype">
            <!--{loop $cardtype $_k $_v}-->
            <!--{eval $price =floatval($_v[2]);
            if((IN_MOCUZ||IN_MAGAPP||IN_QIANFAN||IN_APPBYME) && $_v[5]>0):
                $price =floatval($_v[5]);
            endif;
            }-->
            <label class="weui-cell weui-check__label" for="x$_k">
                <div class="weui-cell__hd">
                    <input type="radio" class="weui-check" name="form[cardtype]" id="x$_k" value="$_k" <!--{if $_k == 0}-->checked="checked"<!--{/if}-->>
                    <i class="weui-icon-checked"></i>
                </div>
                <div class="weui-cell__bd">
                    <p>$_v[0] <!--{if $_v[4]}--><span class="label-red" >$_v[4]</span><!--{/if}-->
                    </p>
                    <p class="c9 f12"> {lang xigua_hk:xshyqy}<em class="main_color">$_v[1]</em>{lang xigua_hk:t}</p>
                </div>
                <div class="weui-cell__ft">
                    <p class="main_color">
                        <!--{if $price>0}-->
                        <span>{$price}<em class="f12">{lang xigua_hk:yuan}</em></span>
                        <!--{else}-->
                        <span><em>{lang xigua_hs:mf}</em></span>
                        <!--{/if}-->
                    </p>
                    <p class="l1"><s class="c9 f12">{lang xigua_hk:yuanjia}:$_v[3]</s></p>
                </div>
            </label>
            <!--{/loop}-->
        </div>

        <!--{if 0}-->
        <style>.dig_pub_exts{padding:1rem}.dig_pub_div{float:left;width:calc(49% - 1.333333rem - 2px);background:#fff;padding:.45rem .5rem .3rem;font-size:.7rem;box-shadow:0 0 10px rgba(0,0,0,.05);border-radius:.25rem;position:relative;text-align:center;border:1px solid #fff;margin:.5rem .5rem .5rem 0}
            .dig_pub_div:nth-child(2n){margin-right:0}.dig_pub_div .dig_pub_subtag{font-size:12px;position:absolute;top:-.5rem;border-radius:.25rem .25rem .25rem 0;left:-1px;padding:0 .5rem;color:#fff;box-shadow:0 0 10px rgba(0,0,0,.05)}.dig_pub_div .dig_pub_title{color:#000;font-size:.7rem;margin-top:.4rem;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.dig_pub_div .dig_pub_yuan{color:#999;font-size:.7rem;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;height:1.1rem}
            .dig_pub_div .dig_pub_price{font-size:1.4rem;line-height:1.4rem}.dig_pub_div .dig_pub_price em{font-size:.7rem;margin-right:.2rem}.dig_pub_div.active{border-color:$config[maincolor]}</style>
        <div class="dig_pub_exts cl">
            <!--{loop $cardtype $_k $_v}-->
            <!--{eval $price =floatval($_v[2]);
            if((IN_MOCUZ||IN_MAGAPP||IN_QIANFAN||IN_APPBYME) && $_v[5]>0):
                $price =floatval($_v[5]);
            endif;
            }-->
            <label class="dig_pub_div <!--{if $_k == 0}-->active<!--{/if}-->" for="dig_pub_$_k">
                <!--{if $_v[4]}--><div class="dig_pub_subtag main_bg">$_v[4]</div><!--{/if}-->
                <div class="dig_pub_title">$_v[0]</div>
                <div class="dig_pub_price main_color">
                    <!--{if $price>0}-->
                    {$price}<em>{lang xigua_hk:yuan}</em>
                    <!--{else}-->
                    {lang xigua_hs:mf}
                    <!--{/if}--></div>
                <div class="dig_pub_yuan"><em>
                        {lang xigua_hk:yuanjia}:$_v[3] </em></div>
                <input type="radio" style="display:none" class="weui-check" name="form[cardtype]" id="x$_k" value="$_k" >
            </label>
            <!--{/loop}-->
        </div>
        <script>
            $(document).on('click','.dig_pub_div', function () {
                $(this).siblings().removeClass('active');
                $(this).addClass('active');
            });
        </script>
        <!--{/if}-->

        <div class="weui-cells weui-cells_form mt0 before_none" id="inputcode" style="display: none">
            <div class="weui-cell ">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hk:jhm}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[cardno]" value="" placeholder="{lang xigua_hk:qsrjhm}">
                </div>
            </div>
        </div>



    </div>

        <!--
        <div class="card_other">
            <div class="card_num"><div class="inner"><span class="num"></span></div></div>
        </div>-->

    <div class="fix-bottom mt10" style="position:relative">
        <!--{if $card[status_u]||$card[isend]}-->
        <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hk:ljxf}">
        <!--{else}-->
        <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hk:ljkt}">
        <!--{/if}-->
    </div>
    </form>



        <div class="card_other ">
            <div class="card_num"><div class="inner"><span class="num">{lang xigua_hk:heiketequan}</span></div></div>
        </div>
        <div class="weui-grids bgf ">
            <a href="$SCRITPTNAME?id=xigua_hk&mobile=2" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-huiyuan2 color-bluish f26"></i>
                </div>
                <p class="weui-grid__label c9">{lang xigua_hk:zsyh}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hb&ac=pub&mobile=2" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-bianji color-bluish f24"></i>
                </div>
                <p class="weui-grid__label c9">{lang xigua_hk:bjfb}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hm&mobile=2" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-xianshiqianggou color-bluish f24"></i>
                </div>
                <p class="weui-grid__label c9">{lang xigua_hk:tjqg}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hs&ac=enter&mobile=2" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-shop color-bluish f24"></i>
                </div>
                <p class="weui-grid__label c9">{lang xigua_hk:mfrz}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hh&ac=my&mobile=2" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-fenxiao color-bluish f24"></i>
                </div>
                <p class="weui-grid__label c9">{lang xigua_hk:cjhhr}</p>
            </a>
            <a href="javascript:;" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-gengduo1 color-bluish f24"></i>
                </div>
                <p class="weui-grid__label c9">{lang xigua_hk:gdtq}</p>
            </a>
        </div>


    <div class="footer_fix"></div>
</div>


<!--{eval $tabbar=0;$hk_tabbar=1;}-->
<!--{template xigua_hk:footer}-->
<script src="source/plugin/xigua_hb/static/countUp.js"></script>
<script>
    var options = {useEasing : true,useGrouping : true,separator : '',decimal : '.',prefix : '',suffix : ''};
    new countUp("njum1", 0, $('#njum1').text(), 0, 2.5, options).start();
    function showUserBox(paytype, cardtype, cardno) {
        $.hideLoading();
        $.prompt("", function(text) {
            var rname =$('#account').val();
            $.showLoading();
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hk&ac=dopay&inajax=1&form[paytype]='+paytype+'&form[cardtype]='+cardtype+'&form[cardno]='+cardno,
                data:{formhash:'{FORMHASH}', rname:text,rmobile:rname},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    var sar = s.split('|');
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });

        }, function() {
        });

        setTimeout(function(){
            $('.weui-dialog__bd').after('<div class="dialog_custom"><div><input id="account" class="weui-input needsclick_input" type="text" placeholder="{lang xigua_hk:sjhm}"></div></div>');
        }, 50);
        $('#weui-prompt-input').replaceWith('<input class="weui-prompt-input needsclick weui-input needsclick_input" type="text" id="weui-prompt-input" placeholder="{lang xigua_hk:zsxm}" />');
    }
</script>