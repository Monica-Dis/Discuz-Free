<?php exit('xxxxx');?>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hk:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hk/static/js/hk.js?{VERHASH}"></script>
