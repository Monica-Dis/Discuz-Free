<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hk:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->

    <div>
        <div id="list" class="mod-post x-postlist p0" style="background:#f8f8f8!important;"></div>
        <!--{template xigua_hb:loading}-->
    </div>

    <div class="footer_fix"></div>
</div>
<script>
    var loadingurl = window.location.href+'&ac=hxlog_li&is_my=1&inajax=1&page=';
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hk:footer}-->