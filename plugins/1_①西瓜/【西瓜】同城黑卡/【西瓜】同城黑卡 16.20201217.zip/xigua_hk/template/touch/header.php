<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}--><link rel="stylesheet" href="source/plugin/xigua_hk/static/css/hk.css?{VERHASH}" />
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked,.float_btn{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}
.light_box a.main_color:after,.index_bd{background:$config[maincolor]}.main_border{;border-color:$config[maincolor]!important}
<!--{if $hk_config[cardradius]}-->
.ruzhu-card{border-radius:{$hk_config[cardradius]}px;}
<!--{/if}-->
<!--{if $hk_config[redcolor]}-->
.card_other .card_num .num, .color-p, .hk_glist .discounts, .seckill-card h2,.lingqu_li .weui-cell__hd, .lingqu_li .usebtn, .rate{color:$hk_config[redcolor]}
.label-red, .light_box a > span, .hk_wd em.week, #go2use,.view_bottom_y a,.lqbtn{background-color:$hk_config[redcolor]}
.seckill-title-h, .lingqu_li .usebtn{border-color:$hk_config[redcolor]}
.pop_viright_ {box-shadow:$hk_config[redcolor] 0 0 0 300px}
<!--{/if}-->
</style>
<script>var HB_INWECHAT = '{HB_INWECHAT}', PLZALLOW = '{lang xigua_hs:plzallow}', gengduodongtai = '{lang xigua_hs:gengduodongtai}', guanzhu_sj = '{lang xigua_hs:guanzhu_sj}', yiguanzhu = '{lang xigua_hs:yiguanzhu}', jiaguanzhu='{lang xigua_hs:jiaguanzhu}', mkey = '$hs_config[mkey]', GOOGLE = '{$hs_config[google]}', HS_MULTIUPLOAD = '{$config[multiupload]}';</script>