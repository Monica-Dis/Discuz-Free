<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hk:header}-->
<!--{eval include_once DISCUZ_ROOT."source/plugin/xigua_hk/include/c_checkvip.php";}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd">
    <form action="$SCRITPTNAME?id=xigua_hk&ac=add{$urlext}" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="form[id]" value="{$old_data[id]}">

        <div class="weui-cells__title">
            <!--{if $old_data}-->{lang xigua_hk:bjsp}{$old_data[title]}
            <!--{else}-->{lang xigua_hk:tjsp}
            <!--{/if}-->
        </div>
        <div class="weui-cells ">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:title}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[title]" placeholder="{lang xigua_hk:qtx}{lang xigua_hk:title}" value="{$old_data[title]}">
                </div>
            </div>


            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:hdjj}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[attention]" placeholder="{lang xigua_hk:attention}" value="{$old_data[attention]}">
                </div>
            </div>

            <!--{if $sh}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hk:sydp}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input choose_ctrl" name="form[shname]" type="text" value="{echo $old_data?$old_data['shname']:$dftshname}" placeholder="{lang xigua_hk:qxzsydp}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->

            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:kssj}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id='datetime-startts' name="form[startts]" placeholder="{lang xigua_hk:qtx}{lang xigua_hk:kssj}" value="{$old_data[startts_u]}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:jssj}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id='datetime-endts' name="form[endts]" placeholder="{lang xigua_hk:qtx}{lang xigua_hk:jssj}" value="{$old_data[endts_u]}">
                </div>
            </div>
        </div>

        <div class="weui-cells__title">{lang xigua_hk:zksz}</div>
        <div class="weui-cells ">

            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:xq}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id="week" name="form[week]" placeholder="{lang xigua_hk:zxqj}" value="{$old_data[week]}">
                </div>
            </div>


            <div class="weui-cell">
                <div class="weui-cell__hd"><label for="date-multiple" class="weui-label">{lang xigua_hk:rq}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" id="date-multiple" type="text" name="form[date]" placeholder="{lang xigua_hk:zjh}" value="{$old_data[date]}">
                </div>
            </div>
<div class="weui-cell weui-cell_select weui-cell_select-after">
    <div class="weui-cell__hd">
        <label class="weui-label">{lang xigua_hk:zklx}</label>
    </div>
    <div class="weui-cell__bd">
        <select class="weui-select" name="form[zktype]" onchange="dozktype(this);">
        <option value="q" <!--{if $old_data[zktype]=='q'}-->selected="selected"<!--{/if}-->>{lang xigua_hk:yhlj}</option>
        <option value="0" <!--{if !$old_data[zktype]}-->selected="selected"<!--{/if}-->>{lang xigua_hk:dz}</option>
        </select>
    </div>
</div>
            <div class="weui-cell" id="hide_zhe" <!--{if $old_data[zktype]=='q'}-->style="display:none"<!--{/if}-->>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:rate}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[rate]" placeholder="{lang xigua_hk:qtx}{lang xigua_hk:zkw}" value="{$old_data[rate]}">
                </div>
                <div class="well-cell__ft">{lang xigua_hk:zhe}</div>
            </div>
            <div class="weui-cell" id="hide_jian" <!--{if !$old_data[zktype]}-->style="display:none"<!--{/if}-->>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:yhlj}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[lijian]" placeholder="{lang xigua_hk:qtx}{lang xigua_hk:yhljdje}" value="{$old_data[lijian]}">
                </div>
                <div class="well-cell__ft">{lang xigua_hb:yuan}</div>
            </div>
        </div>

        <div class="weui-cells__title" style="display:none">{lang xigua_hk:th}</div>
        <div class="weui-cells " style="display:none">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:bigweek}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id="bigweek" name="form[bigweek]" placeholder="{lang xigua_hk:bigweekn}" value="{$old_data[bigweek]}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:bigdate}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id="bigdate" name="form[bigdate]" placeholder="{lang xigua_hk:bigweekn}" value="{$old_data[bigdate]}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:bigrate}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[bigrate]" placeholder="{lang xigua_hk:bigraten}" value="{$old_data[bigrate]}">
                </div>
                <div class="well-cell__ft">{lang xigua_hk:zhe}</div>
            </div>
        </div>


        <div class="weui-cells__title">{lang xigua_hk:gzsz}</div>
        <div class="weui-cells ">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:mkxc}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[manmax]" placeholder="{lang xigua_hk:manmax}" value="{$old_data[manmax]}">
                </div>
                <div class="well-cell__ft">{lang xigua_hk:ci}</div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:xe}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[maxmoney]" placeholder="{lang xigua_hk:maxmoney}" value="{$old_data[maxmoney]}">
                </div>
                <div class="weui-cell__ft">{lang xigua_hk:yuan}</div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:stock}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="tel" name="form[stock]" placeholder="{lang xigua_hk:stockn}" value="{echo $old_data[stock]>999999?'' : $old_data[stock]}">
                </div>
            </div>
            <!--{if $hk_config[autos]}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:autostock}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="tel" name="form[autostock]" placeholder="{lang xigua_hk:autostockn}" value="{echo $old_data[autostock] ? $old_data[autostock] : ''}">
                </div>
            </div>
            <!--{/if}-->
        </div>



        <div class="weui-cells__title">{lang xigua_hk:hdsm}</div>
        <div class="weui-cells ">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <textarea class="weui-textarea" name="form[notice]" placeholder="{lang xigua_hk:noticen}" rows="3">{$old_data[notice]}</textarea>
                </div>
            </div>
        </div>

        <div class="weui-cells__title">{lang xigua_hk:jjxq}</div>
        <div class="weui-cells ">

            <div class="weui-cell weui-cell_access" onclick='$("#edit_jieshao").popup();'>
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hk:jjxq}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" id="edit_jieshao_holder" value="{$old_data[jieshao]}" readonly placeholder="{lang xigua_hk:djspxq}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>

            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_hk:splbt}</p>
                            <div class="weui-uploader__info">{echo str_replace('n', $hk_config['maximg'], lang_hk('zuiduozhao',0))}
                            </div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{$hk_config['maximg']}" data-maxtip="{echo str_replace('n', $hk_config['maximg'], lang_hk('zuiduozhao',0))}">
                                <!--{loop $old_data[album] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                                    <input type="hidden" name="form[album][]" value="$img"/>
                                    <div class="weui-uploader__file-content">
                                        <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if HB_INWECHAT && $config[multiupload]}-->
                                <a class="weui-uploader__input" data-name="form[album]" data-multi="1"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!--{if $svicerange}-->
            <div class="weui-cell" style="padding-bottom:6px;">
                <div class="weui-cell__bd">
                    <div class="post-tags cl" id="post-typeid">
                        <!--{loop $svicerange $_rangk $_rangv}-->
                        <a class="weui-btn weui-btn_mini weui-btn_default <!--{if in_array($_rangv, $old_data[srange_ary])}-->tag-on<!--{/if}-->" href="javascript:;" onclick="return setTypeid('{$_rangk}', this);">$_rangv</a>
                        <input name="form[tagid][{$_rangk}]" type="hidden" value="<!--{if in_array($_rangv, $old_data[srange_ary])}-->1<!--{else}-->0<!--{/if}-->">
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
            <!--{/if}-->
        </div>

        <div class="fix-bottom mt10" style="position:relative">
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}"/>
            <a class="weui-btn weui-btn_default" href="javascript:window.history.go(-1);">{lang xigua_hb:quxiao}</a>
        </div>


        <div id="edit_jieshao" class="weui-popup__container" style="z-index:1000">
            <div class="weui-popup__modal bgf8">
                <div class="fixpopuper">
                    <div class="weui-cells__title">{lang xigua_hk:bjsp}</div>
                    <div class="weui-cells ">
                        <div class="weui-cell">
                            <div class="weui-cell__bd">
                        <textarea class="weui-textarea" name="form[jieshao]" id="jieshao" placeholder="{lang xigua_hk:txspxq}"
                                  rows="3">{$old_data[jieshao]}</textarea>
                            </div>
                        </div>
                    </div>

                    <div class="weui-cells before_none nobg center_upload">
                        <div class="weui-cell" id="first_append_img">
                            <div class="weui-cell__bd">
                                <div class="weui-uploader">
                                    <div class="weui-uploader__bd">
                                        <div class="weui-uploader__input-box">
                                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                            <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                            <!--{else}-->
                                            <input class="center_upload__input" data-name="form[append_img]" type="file">
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--{loop $old_data[append_text_ary] $__k $__v}-->
                        <div class="weui-cell bgf" id="arear_{$__k}">
                            <ul id="cimg_{$__k}" data-only="1">
                                <li class="weui-uploader__file weui-uploader__file_status"
                                    style="background-image:url({$old_data['append_img_ary'][$__k]})">
                                    <input type="hidden" name="form[append_img][{$__k}]"
                                           value="{$old_data['append_img_ary'][$__k]}">
                                    <div class="weui-uploader__file-content"><i
                                                class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                            </ul>
                            <div class="weui-cell__bd">
                        <textarea class="weui-textarea" placeholder="{lang xigua_hk:inputtext}" rows="3"
                                  name="form[append_text][{$__k}]">{$__v}</textarea>
                            </div>
                            <a class="iconfont icon-guanbijiantou closeHt" data-index="{$__k}"></a>
                        </div>
                        <div class="weui-cell" id="cell_{$__k}">
                            <div class="weui-cell__bd">
                                <div class="weui-uploader">
                                    <div class="weui-uploader__bd">
                                        <div class="weui-uploader__input-box">
                                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                            <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                            <!--{else}-->
                                            <input class="center_upload__input" data-name="form[append_img]" type="file">
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--{/loop}-->
                    </div>

                    <div class="fix-bottom" id="center_upload_btn" style="position:relative">
                        <a class="mt0 weui-btn weui-btn_default" onclick='return edit_finish();'
                           href="javascript:;">{lang xigua_hk:wcbj}</a>
                    </div>
                </div>
            </div>
        </div>

    </form>
</div>

<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>

<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div class="masker" onclick='$(".choose_ctrl").select("close")'></div>
<script>
    var itar = [];
    <!--{loop $sh $_sh}--><!--{if $_sh[name]}-->
    itar.push({title: '{$_sh[name]}'});
    <!--{/if}--><!--{/loop}-->
    $(".choose_ctrl").select({
        title: "{lang xigua_hk:qxzsydp}",
        items: itar,
        onOpen: function () {
            $('.masker').fadeIn();
        },
        beforeClose: function () {
            $('.masker').fadeOut(300);
            return true;
        }
    });

    function cropCallback() {
        $("#new_popup").popup();
        return false;
    }

    function edit_finish() {
        $.closePopup();
        $("#edit_jieshao_holder").val($('#jieshao').val());
        return cropCallback();
    }
</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.min.js" charset="utf-8"></script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hk:footer}-->
<!--{template xigua_hk:enter_up}-->
<script>
    $("#datetime-startts").datetimePicker();
    $("#datetime-endts").datetimePicker();
    $("#week").select({
        title: "{lang xigua_hk:xzj}",
        multi: true,
        items: [
            {title: "{lang xigua_hk:w1}", value: 1},
            {title: "{lang xigua_hk:w2}", value: 2},
            {title: "{lang xigua_hk:w3}", value: 3},
            {title: "{lang xigua_hk:w4}", value: 4},
            {title: "{lang xigua_hk:w5}", value: 5},
            {title: "{lang xigua_hk:w6}", value: 6},
            {title: "{lang xigua_hk:w0}", value: 7}
        ]
    });
    $("#bigweek").select({
        title: "{lang xigua_hk:xzj}",
        multi: true,
        items: [
            {title: "{lang xigua_hk:w1}", value: 1},
            {title: "{lang xigua_hk:w2}", value: 2},
            {title: "{lang xigua_hk:w3}", value: 3},
            {title: "{lang xigua_hk:w4}", value: 4},
            {title: "{lang xigua_hk:w5}", value: 5},
            {title: "{lang xigua_hk:w6}", value: 6},
            {title: "{lang xigua_hk:w0}", value: 7}
        ]
    });
    $("#date-multiple").select({
        title: "{lang xigua_hk:hzx}",
        multi: true,
        items: [<!--{eval $months = range(1, 31);}-->
            <!--{loop $months $v}-->
            {title: "{lang xigua_hk:meiyue}{$v}{lang xigua_hk:ri}", value: $v},
            <!--{/loop}-->
        ]
    });
    $("#bigdate").select({
        title: "{lang xigua_hk:hzx}",
        multi: true,
        items: [<!--{eval $months = range(1, 31);}-->
            <!--{loop $months $v}-->
            {title: "{lang xigua_hk:meiyue}{$v}{lang xigua_hk:ri}", value: $v},
            <!--{/loop}-->
        ]
    });
    function dozktype(obj){
        if(obj.value=='q'){
            $('#hide_zhe').hide();
            $('#hide_jian').show();
        }else{
            $('#hide_zhe').show();
            $('#hide_jian').hide();
        }
    }
<!--{if !$sh[0][name]}-->
$.alert("{lang xigua_hk:bnfb}", function() {
    hb_jump("$SCRITPTNAME?id=xigua_hs&ac=shcenter&mobile=2{$urlext}");
});
<!--{/if}-->
</script>