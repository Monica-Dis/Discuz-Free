<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $hk_tabbar}-->
<div class="weui-tabbar <!--{if $showfloatapp}-->none<!--{/if}-->">
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hb{$urlext}" class="weui-tabbar__item <!--{if $ac=='index'&&$_GET[id]=='xigua_hb'}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-index weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">{lang xigua_hb:shouye}</p>
    </a>

    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hk{$urlext}" class="weui-tabbar__item <!--{if $ac=='index'}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-huiyuan2 weui-tabbar__icon f26 pr-1"></i>
        <p class="weui-tabbar__label">{eval lang_hk('heika')}</p>
    </a>
    <!--{if !isset($card)}-->
    <!--{eval $card = C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G[uid]); }-->
    <!--{/if}-->
    <!--{if !$card}-->
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hk&ac=join{$urlext}" class="weui-tabbar__item <!--{if $ac=='join'}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-SKJYCSTJ weui-tabbar__icon f26"></i>
        <p class="weui-tabbar__label">{lang xigua_hk:mk}</p>
    </a>
    <!--{else}-->
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hk&ac=my_order&type=unuse{$urlext}" class="weui-tabbar__item <!--{if $ac=='my_order'}-->weui-bar__item_on{eval $hason=1;}<!--{/if}-->">
        <i class="iconfont icon-icons- weui-tabbar__icon "></i>
        <p class="weui-tabbar__label">{lang xigua_hk:syong}</p>
    </a>
    <!--{/if}-->

    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hk&ac=help{$urlext}" class="weui-tabbar__item <!--{if $ac=='help'}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-tousu weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">{lang xigua_hb:help}</p>
    </a>

    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hb&ac=my{$urlext}" class="weui-tabbar__item <!--{if !$hason && strpos($ac,'my')!==false}-->weui-bar__item_on<!--{/if}-->">
        <span style="display: inline-block;position: relative;">
            <i class="iconfont icon-xiaolian2 weui-tabbar__icon"></i>
        </span>
        <p class="weui-tabbar__label">{lang xigua_hb:wode}</p>
    </a>
</div>
<!--{/if}-->