<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hk:header}-->
<div class="page__bd">
    <!--{if $hk_config[cardstyle]==1}-->
    <div class="card-header main_bg" style="padding-bottom:15px">
    <!--{else}-->
    <div class="bgf" style="padding-bottom:15px;overflow:hidden">
    <!--{/if}-->
    <!--{template xigua_hk:card}-->
    </div>
    <!--{loop $data $v}-->
    <article class="weui-article<!--{if $hk_config[cardstyle]==2}--> mt10<!--{/if}-->">
        <h1>{$v[subject]}</h1>
        {$v[content]}
    </article>
    <!--{/loop}-->
</div>

<!--{eval $tabbar=0;$hk_tabbar=1;}-->
<!--{template xigua_hk:footer}-->