<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hk:header}-->
<div class="page__bd view_bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="view_num">{lang xigua_hk:req} : {$v['views']}</div>
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{if !$v[album]}-->
            <!--{eval $v[album] = $v[append_img_ary];}-->
            <!--{/if}-->
            <!--{loop $v[album] $slider}-->
            <div><img src='$slider' style="height:{$hk_config[viewh]}px"/></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $v[album] $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}--> ></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <div class="weui-cells mt0 before_none view_top after_none">
        <div class="cl view_cell">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <span class="c3">$v[title]</span>
                </div>
                <div>
                    <div class="view_date  main_border">
                        <p class="main_bg cf">{$m_show}{lang xigua_hk:yue}</p>
                        <p class="main_color">{$d_show}{lang xigua_hk:ri}</p>
                    </div>
                </div>
            </div>
            <div class="weui-flex">
                <div class="weui-flex__item f13 color-p" style="margin-right:50px;margin-top:5px">
                    $v[attention]
                </div>
            </div>
        </div>
        <!--{if $v[srange_ary]}-->
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <ul class="arguments-treatment main_color">
                    <!--{loop $v[srange_ary] $_v}--><li style="float:left;"><i class="iconfont icon-duigou2"></i>{$_v}</li><!--{/loop}-->
                </ul>
            </div>
        </div>
        <!--{/if}-->
    </div>
    <div class="seckill-rule seckill-card ">
        <div class="seckill-title-h">{lang xigua_hk:shj}</div>
        <div class="weui-cells seckill_dianjia after_none before_none">
            <div class="weui-cell pt0">
                <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]"><img src="{$sh[logo]}"></a></div>
                <div class="weui-cell__bd">
                    <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]">{$sh[name]}</a></p>
                    <p class="f13 c9">{lang xigua_hk:yysj}: <em>{$sh[opentime]}</em></p>
                </div>
                <div class="weui-cell__ft">
                    <a href="javascript:;" onclick='$.alert("<img src=$sh[qr] /><br>{lang xigua_hk:smj}", "{lang xigua_hk:wxzca}");'><i class="iconfont icon-sixin2 mr15 main_color f24"></i></a>
                    <a class="shtel" <!--{if $sh[teljs]}-->$sh[teljs]<!--{else}-->href="tel:{$sh[tel]}"<!--{/if}-->><i class="iconfont icon-unie607 main_color f24"></i></a>
                </div>
            </div>

            <a class="weui-cell weui-cell_access" style="padding-bottom:0" href="javascript:;" id="v_openLocation" data-lat="{$sh[lat]}" data-lng="{$sh[lng]}" data-name="{$sh[name]}" data-addr="{$sh[addr]}">
                <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
                <div class="weui-cell__bd">
                    <p class="f14">{$sh[addr]}</p>
                    <p class="f13 c9" id="driving" data-id="$v[shid]"></p>
                </div>
                <div class="weui-cell__ft"></div>
            </a>

        </div>
    </div>



    <div class="seckill-rule seckill-card ">
        <div class="seckill-title-h">{lang xigua_hk:sysm}</div>
        <div class="seckill-rule-c">
            <article class="f14">
                <section>
                    <p>{echo lang_hk('hkhykxs', 0)}
<!--{if $v[zktype]=='q'}-->
<span class="rate">{$v[lijian]}<em class="f14">{lang xigua_hb:yuan}</em></span>{lang xigua_hk:ljyh}
<!--{else}-->
<span class="rate">{$v[rate]}<em class="f14">{lang xigua_hk:zhe}</em></span>{lang xigua_hk:yh}
<!--{/if}-->
<!--{if $v[maxmoney]}--><span class="f12 c9">({lang xigua_hk:man}{$v[maxmoney]}{lang xigua_hk:yksy})</span><!--{/if}--></p>
                    <!--{if 1 && ($v[week_em] || $v[date_em])}-->
                    <div class="hk_wd">
                        <!--{if $v[week_em]}--><div><em class="week">{lang xigua_hk:week}</em>{$v[week_em]} {lang xigua_hk:ky}</div><!--{/if}-->
                        <!--{if $v[date_em]}--><div><em class="date">{lang xigua_hk:date}</em>{$v[date_em]} {lang xigua_hk:ky}</div><!--{/if}-->
                    </div><!--{/if}-->
                    <!--{if $v[manmax]>0}-->
                    <p>{lang xigua_hk:xmrmtlq}<span class="main_color">$v[manmax]</span>{lang xigua_hk:z}</p>
                    <!--{/if}-->
                    <p>{echo hk_nl2br($v['notice']);}</p>
                </section>
            </article>
        </div>
    </div>

    <div class="seckill-rule seckill-card ">
        <div class="seckill-rule-c">
            <div class="card-view-process weui-flex">
                <em class="process-line"></em>
                <div class="weui-flex__item">
                    <i class="main_bg">1</i>
                    <p>{echo lang_hk('kthk', 0)}</p>
                </div>
                <div class="weui-flex__item">
                    <i class="main_bg">2</i>
                    <p>{echo lang_hk('xzhksj', 0)}</p>
                </div>
                <div class="weui-flex__item">
                    <i class="main_bg">3</i>
                    <p>{lang xigua_hk:djlq}</p>
                </div>
                <div>
                    <i class="main_bg">4</i>
                    <p>{lang xigua_hk:csewm}</p>
                </div>
            </div>
        </div>
    </div>

    <div class="seckill-rule seckill-card ">
        <div class="seckill-title-h">{lang xigua_hk:spxq}</div>
        <div class="seckill-rule-c">
            <article class="f14">
                <section>
                    <p>{echo hk_nl2br($v['jieshao']);}</p>
                    <!--{loop $v[append_img_ary] $__k $__v}-->
                    <p><img src="{$__v}" /></p>
                    <p>{echo hk_nl2br($v[append_text_ary][$__k]);}</p>
                    <!--{/loop}-->
                    <!--{if $hk_config[showalbum]}-->
                    <!--{loop $v[album] $__k $__v}-->
                    <p><img src="{$__v}" /></p>
                    <!--{/loop}-->
                    <!--{/if}-->
                </section>
            </article>
        </div>
    </div>

<!--{if $_G['cache']['plugin']['xigua_dp'] && in_array('hk', unserialize($_G['cache']['plugin']['xigua_dp']['opens']))}-->
    <style>.gzbtn{background-color:$config[maincolor]}</style><div id="ptdiv2" style="display:none"></div>
    <script>
        $.ajax({type: 'get',dataType: 'xml',
            url: '$SCRITPTNAME?id=xigua_dp&ac=jingxuan&inajax=1&type=hk&typeid=$v[id]&shid={$v[shid]}&pagesize=5&page=1',
            success: function (data) {
                if(null==data){ $('#ptdiv2').remove(); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(!s){ $('#ptdiv2').remove(); return false;}
                $('head').append('<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?{VERHASH}" />');
                $('body').append('<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"><\/script>');
                $('#ptdiv2').html(s).show();
            },
            error: function () {$('#ptdiv2').remove();}
        });
    </script>
<!--{/if}-->

    <!--{if $hk_config[openinview]}-->
    <div class="seckill-rule seckill-card ">
        <div class="seckill-title-h">{lang xigua_hk:fjyh}</div>
        <div class="seckill-rule-c" id="list" style="padding:0;margin:-10px -15px"></div>
    </div>
    <!--{/if}-->

    <div class="view_bottom weui-flex border_top">
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hk&mobile=2{$urlext}" class="weui-tabbar__item weui-bar__item_on">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-huiyuan2 weui-tabbar__icon pr-1"></i>
                </span>
                <p class="weui-tabbar__label">{eval lang_hk('heika')}</p>
            </a>
        </div>
        <div class="view_bottom_z">
            <a href="javascript:;" onclick="show_shkf();" class="weui-tabbar__item">
            <span style="display: inline-block;position: relative;">
                <i class="iconfont icon-unie607 weui-tabbar__icon f22"></i>
            </span>
                <p class="weui-tabbar__label">{lang xigua_hk:kf}</p>
            </a>
        </div>
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hk&ac=my_order&type=unuse&mobile=2{$urlext}" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-icons- weui-tabbar__icon f22"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_hb:wode}</p>
            </a>
        </div>
        <div class="weui-flex__item view_bottom_y">
            <!--{if $card}-->
            <!--{if $hasbuy}-->
            <a href="javascript:;" id="getQuan" data-use="{lang xigua_hk:ljsy}" data-src="$hasbuy[src]" data-shid="$hasbuy[shid]" data-title="$v[title]" data-lingquid="$hasbuy[id]" data-chushi="{lang xigua_hk:chushi}" data-date="$date_now" data-gid="$gid" class="bgcolor_sec mc_bg">{lang xigua_hk:ljsy}</a>
            <!--{else}-->
            <a href="javascript:;" id="getQuan" data-use="{lang xigua_hk:ljsy}" data-shid="$v[shid]" data-title="$v[title]" data-date="$date_now" data-gid="$gid" class="bgcolor_sec mc_bg">{lang xigua_hk:lq}</a>
            <!--{/if}-->
            <!--{else}-->
            <a href="$SCRITPTNAME?id=xigua_hk&ac=join&backto={$currenturl}{$urlext}" class="bgcolor_sec mc_bg">{echo lang_hk('kthk', 0)}</a>
            <!--{/if}-->
        </div>
    </div>

</div>

<div class="pop_mask"></div>
<div class="pop_vi none">
    <div class="cl pop_vin">
        <div class="pop_vileft">
            <p class="pop_suc">{lang xigua_hk:lqcg}</p>
            <p class="pop_sh"><i class="iconfont icon-shoplight weui-tabbar__icon f22 main_color"></i> <span>{$sh[name]}</span></p>
            <!--{if $v[manmax]>0}-->
            <p class="pop_max">{lang xigua_hk:xmrmtlq}<span class="main_color">$v[manmax]</span>{lang xigua_hk:z}</p>
            <!--{/if}-->
            <p class="pop_xian">{lang xigua_hk:jx}{$date_now}{lang xigua_hk:syong}</p>
        </div>
        <div class="pop_viright">
            <div class="pop_viright_"></div>
            <p class="mt10">{lang xigua_hk:ckqd}</p>
            <p>{lang xigua_hk:wdwsy}</p>
            <!--{if $v[zktype]=='q'}-->
            <p id="rater">{$v[lijian]}<em>{lang xigua_hb:yuan}{lang xigua_hk:ljyh}</em></p>
            <!--{else}-->
            <p id="rater">{$v[rate]}<em>{lang xigua_hk:zhe}</em></p>
            <!--{/if}-->
            <!--{if $v[maxmoney]}--><p id="maxer">{lang xigua_hk:man}{$v[maxmoney]}{lang xigua_hk:yksy}</p><!--{else}--><p id="maxer">{lang xigua_hk:wxz}</p><!--{/if}-->
        </div>
    </div>
    <a href="javascript:;" id="go2use" data-chushi="{lang xigua_hk:chushi}">{lang xigua_hk:ljsy}</a>
</div>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hk:haibao}-->
<!--{template xigua_hk:footer}-->
<script>
if($('#list').length>0){
    var listcnt = 0;
    var listInterval=setInterval(nearList, 2000);
    nearList();
}
function nearList () {
    hs_getlocation(function(position){
        var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
        $.ajax({
            type: 'get',
            url: _APPNAME+'?id=xigua_hk&not=$v[id]&date=$date_now&ac=good_li&orderby=nearby&lat='+lat+'&lng='+lng,
            dataType: 'xml',
            success: function (data) {
                var s = data.lastChild.firstChild.nodeValue;
                $("#list").html(s);
                clearInterval(listInterval);
            },
            error: function () {}
        });
    });
    listcnt++;
    if(listcnt>=2){
        clearInterval(listInterval);
    }
}
function show_shkf() {
    $.alert("<!--{if $sh[qr]}--><img src=$sh[qr] /><!--{/if}--><p>{lang xigua_hk:kfdh}: <a href='tel:{$sh[tel]}' class='main_color'>$sh[tel]</a></p>", "{lang xigua_hk:wxzca}");
}
</script>