<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $hk_config[cardstyle]==1}-->
<div class="ruzhu-card"<!--{if $hk_config[cardbg]}-->  style="background-image:url($hk_config[cardbg])"<!--{/if}-->>
    <!--{if $card && !$card[isend]}-->
    <div class="card_btn_outer">
        <a class="btn on" href="$SCRITPTNAME?id=xigua_hk&ac=join&mobile=2{$urlext}">{lang xigua_hk:yjh}</a>
    </div>
    <!--{else}-->
    <!--{if $ac!='join'}-->
    <a class="btn" href="$SCRITPTNAME?id=xigua_hk&ac=join&mobile=2{$urlext}">{lang xigua_hk:qkk}<i class="iconfont icon-jinrujiantou vm"></i></a>
    <!--{else}-->
    <div class="card_btn_outer">
        <a class="btn on" href="$SCRITPTNAME?id=xigua_hk&mobile=2{$urlext}">{lang xigua_hk:yhsj}</a>
    </div>
    <!--{/if}-->
    <!--{/if}-->
    <div class="info weui-flex">
        <div class="avatar">
            <img src="{avatar($_G[uid], 'middle', 1)}"/>
        </div>
        <div class="p_info">
            <h3>{$_G[username]}</h3>
            <!--{if !$card[isend] && $card[endts_u]}-->
            <span>{echo lang_hk('hkyxqd', 0)}: $card[endts_u]</span>
            <!--{else}-->
            <span>{echo lang_hk('hwjrhk', 0)}</span>
            <!--{/if}-->
        </div>
    </div>
    <div class="btm">{$hk_config[hkbtm]}</div>
</div>
<!--{elseif $hk_config[cardstyle]==2}-->
<div class="cardstyle2 main_bg">
    <div class="ruzhu-card"<!--{if $hk_config[cardbg]}-->  style="background-image:url($hk_config[cardbg])"<!--{/if}-->>
        <!--{if $ac=='join'}-->
            <a class="joinbtn" href="$SCRITPTNAME?id=xigua_hk&mobile=2{$urlext}"><i class="iconfont icon-huiyuan2 f24"></i> {echo lang_hk('yhsj2', 0)}</a>
        <!--{else}-->
            <!--{if $card && !$card[isend]}-->
            <a class="joinbtn" href="$SCRITPTNAME?id=xigua_hk&ac=join&mobile=2{$urlext}"><i class="iconfont icon-huiyuan2 f24"></i> {echo lang_hk('yjh2', 0)}</a>
            <!--{else}-->
            <a class="joinbtn" href="$SCRITPTNAME?id=xigua_hk&ac=join&mobile=2{$urlext}">{lang xigua_hk:qkk}<i class="iconfont icon-jinrujiantou vm"></i></a>
            <!--{/if}-->
        <!--{/if}-->


        <div class="info weui-flex">
            <div class="avatar">
                <img src="{avatar($_G[uid], 'middle', 1)}"/>
            </div>
            <div class="p_info">
                <h3>{$_G[username]}</h3>
                <!--{if !$card[isend] && $card[endts_u]}-->
                <span>{echo lang_hk('hkyxqd', 0)}: $card[endts_u]</span>
                <!--{else}-->
                <span>{echo lang_hk('hwjrhk', 0)}</span>
                <!--{/if}-->
            </div>
        </div>
        <!--{eval $card[cardno] = $card[cardno] ? $card[cardno] : '88888888';$cardNo = str_pad($card[cardno], 8, '0', STR_PAD_LEFT);$cardNo=substr($cardNo, 0 ,4).' '.substr($cardNo, 4)}-->
        <div class="cardNo">NO. $cardNo</div>
    </div>
</div>
<!--{/if}-->