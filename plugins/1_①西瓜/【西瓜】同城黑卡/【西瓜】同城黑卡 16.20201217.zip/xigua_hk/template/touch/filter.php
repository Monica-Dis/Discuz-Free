<?php exit('xxxxx');?>
<!--{eval
$fullindex = unserialize($hk_config[fflx]);
$allowshow4 = !in_array(-1, $fullindex);
if($allowshow4):
    $allowhm1 = $_G['cache']['plugin']['xigua_hm'] && in_array('hm1', $fullindex);
    $allowhm2 = $_G['cache']['plugin']['xigua_hm'] && in_array('hm2', $fullindex);
    $allowhe = $_G['cache']['plugin']['xigua_he'] && in_array('he', $fullindex);
    $allowpt = $_G['cache']['plugin']['xigua_pt'] && in_array('pt', $fullindex);
    $allowsp = $_G['cache']['plugin']['xigua_sp'] && in_array('sp', $fullindex);
endif;
}-->
<!--{if $allowshow4}--><link rel="stylesheet" href="source/plugin/xigua_hk/static/css/ext.css?{VERHASH}" /><!--{/if}-->
<div class="weui-navbar border_top">
    <a data-id="1" id="ftb1" class="filter_nav weui-navbar__item">
        <span class="block border_right"><em data-html="{lang xigua_hk:sjpx}">{lang xigua_hk:sjpx}</em> <i class="iconfont icon-xiangxia f12"></i></span>
    </a>
    <a data-id="2" id="ftb2" class="filter_nav weui-navbar__item">
        <span class="block border_right"><em data-html="{lang xigua_hk:qbfl}">{lang xigua_hk:qbfl}</em> <i class="iconfont icon-xiangxia f12"></i></span>
    </a>
    <a data-id="3" id="ftb3" class="filter_nav weui-navbar__item">
        <span><em data-html="{lang xigua_hk:qbsq}">{lang xigua_hk:qbsq}</em> <i class="iconfont icon-xiangxia f12"></i></span>
    </a>
    <!--{if $allowshow4}--><a data-id="4" id="ftb4" class="filter_nav weui-navbar__item">
        <span><em data-html="{lang xigua_hk:splx}">{lang xigua_hk:splx}</em> <i class="iconfont icon-xiangxia f12"></i></span>
    </a><!--{/if}-->
</div>
<div class="dist_show">
    <div id="dist_show_1" class="nav_expand_panel hk_panel">
        <div class="weui-flex">
            <div class="weui-flex__item">
                <ul>
                    <li class="first_check border_bfull"><a class="ftb" id="order_auto" data-idid="1" href="javascript:;" data-sort="&id=xigua_hk&ac=good_li&orderby=auto">{lang xigua_hk:znpx}</a></li>
                    <li class="first_check border_bfull"><a class="ftb" id="order_nearby" data-idid="1" href="javascript:;" data-sort="&id=xigua_hk&ac=good_li&orderby=nearby">{lang xigua_hk:fjyx}</a></li>
                    <li class="first_check border_bfull"><a class="ftb" id="order_sellnum" data-idid="1" href="javascript:;" data-sort="&id=xigua_hk&ac=good_li&orderby=sellnum">{lang xigua_hk:lqzd}</a></li>
                    <li class="first_check border_bfull"><a class="ftb" id="order_views" data-idid="1" href="javascript:;" data-sort="&id=xigua_hk&ac=good_li&orderby=views">{lang xigua_hk:rqzg}</a></li>
                </ul>
            </div>
        </div>
    </div>
    <div id="dist_show_2" class="nav_expand_panel hk_panel">
        <div class="weui-flex">
            <div class="weui-flex__item">
                <ul>
                    <li class="first_cat_check border_bfull"><a class="ftb" data-idid="2" data-sort="&id=xigua_hk&ac=good_li&hyid=0">{lang xigua_hb:quanbu}{lang xigua_hk:fenlei}</a></li>
                    <!--{loop $cat_tree $k $v}-->
                    <!--{if !$v[adlink]}-->
                    <li class="first_cat_check border_bfull" <!--{if $v[sub]}--> data-id="$v[id]"<!--{/if}-->><a <!--{if !$v[sub]}--> class="ftb" data-idid="2" data-sort="&id=xigua_hk&ac=good_li&hyid={$v[id]}"<!--{/if}-->>$v[name]</a></li>
                    <!--{/if}-->
                    <!--{/loop}-->
                </ul>
            </div>
            <div class="weui-flex__item checked">
                <!--{loop $cat_tree $k $v}-->
                <ul class="sub_cat_cheker <!--{if !($hyid==$v[id]||$pid==$v[id])}-->none<!--{/if}-->" id="sub_cat_cheker_$v[id]">
                    <li class="sub_cat_check border_bfull"><a class="ftb" data-idid="2" data-sort="&id=xigua_hk&ac=good_li&hyid={$v[id]}" data-orihtml="{$v[name]}">{lang xigua_hb:quanbu}</a></li>
                    <!--{loop $v[sub] $vv}-->
                    <li class="sub_cat_check border_bfull"><a class="ftb" data-idid="2" data-sort="&id=xigua_hk&ac=good_li&hyid={$vv[id]}">$vv[name]</a></li>
                    <!--{/loop}-->
                </ul>
                <!--{/loop}-->
            </div>
        </div>
    </div>
<!--{if $hk_config[usesq]}-->
    <!--{eval
$quaninfo = array();
$hs_config = $_G['cache']['plugin']['xigua_hs'];
if($hs_config['quaninfo']):
    foreach (array_filter(explode("\n", trim($hs_config['quaninfo']))) as $index => $item) :
        $quaninfo[$index] = trim($item);
    endforeach;
endif;
    }-->
    <div id="dist_show_3" class="nav_expand_panel hk_panel">
        <div class="weui-flex">
            <div class="weui-flex__item">
                <ul>
                    <li class="first_check border_bfull"><a class="ftb" data-idid="3" data-sort="&id=xigua_hk&ac=good_li&shangquan=-1" href="javascript:;">{lang xigua_hb:quanbu}{lang xigua_hk:sq}</a></li>
                    <!--{loop $quaninfo $quan}-->
                    <li class="sub_check1 border_bfull "><a class="ftb" data-idid="3" data-sort="&id=xigua_hk&ac=good_li&shangquan={$quan}"  href="javascript:;" >{$quan}</a></li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
    </div>
<!--{else}-->
<div id="dist_show_3" class="nav_expand_panel hk_panel">
    <div class="weui-flex">
        <div class="weui-flex__item">
            <ul>
                <li class="first_check border_bfull"><a class="ftb" data-idid="3" data-sort="&id=xigua_hk&ac=good_li&city=-1" href="javascript:;">{lang xigua_hb:quanbu}{lang xigua_hk:sq}</a></li>
                <!--{loop $dist00 $v}-->
                <li class="first_check border_bfull" data-id="$v[id]"><a>{$v[name]}</a></li>
                <!--{/loop}-->
            </ul>
        </div>
        <div class="weui-flex__item checked">
            <!--{loop $dist00 $k $v}-->
            <ul class="sub_cheker <!--{if $city_id!=$v['id']}-->none<!--{else}-->checked<!--{/if}-->" id="sub_cheker_$v[id]">
                <li class="sub_check border_bfull"><a class="ftb color-red" data-idid="3" data-sort="&id=xigua_hk&ac=good_li&city={$v[name]}" href="javascript:;" data-orihtml="{$v[name]}">{lang xigua_hk:quan}{$v[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a></li>
                <!--{loop $v[child] $vv}-->
                <li class="sub_check border_bfull <!--{if $dist==$vv[name]&&$_GET[dist]}-->checked main_color<!--{/if}-->"><a href="javascript:;" id="sub_check{$vv[id]}" data-id="$vv[id]" onclick="getnext($vv[id],'$vv[name]')">$vv[name]</a></li>
                <!--{/loop}-->
            </ul>
            <!--{/loop}-->
        </div>
        <div class="weui-flex__item checked" id="ajaxbox" style="position:relative;height:65vh"> <ul class="ajaxbox_cheker"></ul> </div>
    </div>
</div>
<!--{/if}--><!--{if $allowshow4}-->
<div id="dist_show_4" class="nav_expand_panel hk_panel">
    <div class="weui-flex">
        <div class="weui-flex__item">
            <ul>
                <li class="first_check border_bfull">
                    <a id="hk" class="ftb" data-idid="4" href="javascript:;" data-sort="&id=xigua_hk&ac=good_li&gtype=default">{echo lang_hk('hkzx', 0)}</a>
                </li>
                <!--{if $allowhe}-->
                <li class="first_check border_bfull">
                    <a id="he" class="ftb" data-idid="4" href="javascript:;" data-load="he" data-sort="&id=xigua_he&ac=he_li&gtype=he&city=">{lang xigua_hk:tchd}</a>
                </li>
                <!--{/if}-->
                <!--{if $allowhm1}-->
                <li class="first_check border_bfull">
                    <a id="yhq" class="ftb" data-idid="4" href="javascript:;" data-load="hm1" data-sort="&id=xigua_hm&ac=seckill_li&stype=youhui&dtp=ing&gtype=hm&city=">{lang xigua_hk:yxq}</a>
                </li>
                <!--{/if}-->
                <!--{if $allowhm2}-->
                <li class="first_check border_bfull">
                    <a id="hm" class="ftb" data-idid="4" href="javascript:;" data-load="hm2" data-sort="&id=xigua_hm&ac=seckill_li&stype=&dtp=ing&gtype=hm&city=">{lang xigua_hk:tjqg}</a>
                </li>
                <!--{/if}-->
                <!--{if $allowsp}-->
                <li class="first_check border_bfull">
                    <a id="sp" class="ftb" data-idid="4" href="javascript:;" data-load="sp" data-sort="&id=xigua_sp&ac=cat_li&gtype=sp&from=index&city=">{lang xigua_hk:scsp}</a>
                </li>
                <!--{/if}-->
                <!--{if $allowpt}-->
                <li class="first_check border_bfull">
                    <a id="pt" class="ftb" data-idid="4" href="javascript:;" data-load="pt" data-sort="id=xigua_pt&ac=cat_li&gtype=pt&from=index&city=">{lang xigua_hk:ptsp}</a>
                </li>
                <!--{/if}-->
            </ul>
        </div>
    </div>
</div><!--{/if}-->
</div>

<div class="">
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script><!--{if $hk_config[indexorder]=='nearby'}-->
var loadingurl = window.location.href+'&date={$alldate[0][date]}&ac=good_li&inajax=1&page=';
setTimeout(function () {
    $('#order_{$hk_config[indexorder]}').trigger('click');
    if(typeof wx !=='undefined') {
        wx.ready(function () {
            $('#order_{$hk_config[indexorder]}').trigger('click');
        });
    }
}, 300);
<!--{else}-->
var loadingurl = window.location.href+'&date={$alldate[0][date]}&ac=good_li&inajax=1&orderby={$hk_config[indexorder]}&page=';
<!--{/if}-->
scrollto = 1;
var lockIng = 0;
$(document).on('click', '.jump_sp', function () {
    var that = $(this);
    var jmpurl = _APPNAME +'?id=xigua_sp&ac=view&gid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
    if(typeof mag !== 'undefined'){
        mag.newWin(GSITE+jmpurl);
        return false;
    }
    if(typeof wx !=='undefined'){
        if (window.__wxjs_environment === 'miniprogram') {
            wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
            return false;
        }
    }
    window.location.href = jmpurl;
    return false;
});
$(document).on('click', '.jump_he', function () {
    var that = $(this);
    var jmpurl = _APPNAME +'?id=xigua_he&ac=view&hid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
    if(typeof mag !== 'undefined'){
        mag.newWin(GSITE+jmpurl);
        return false;
    }
    if(typeof wx !=='undefined'){
        if (window.__wxjs_environment === 'miniprogram') {
            wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
            return false;
        }
    }
    window.location.href = jmpurl;
    return false;
});
<!--{if $_GET[nav]}-->
setTimeout(function () {
    $('#{$_GET[nav]}').trigger('click');
}, 200);
<!--{/if}-->
<!--{if $_GET[gtype]}-->
setTimeout(function () {
    $('#{$_GET[gtype]}').trigger('click');
}, 200);
<!--{/if}-->
</script>