<?php exit('xxx');?>
<!--{if $manage || ($_GET['is_my'] && $_G['uid'])}-->
<!--{loop $list $v}-->
<div class="dis_list">
    <div class="dis_row hk_glist p0" data-id="{$v[id]}">
        <div class="dis_pic">
            <img src="{$v[album][0]}">
            <!--{if $v[status]==3}--><i class="iconfont icon-yijieshu status3I"></i><!--{/if}-->
            <div class="dis_mask"><div class="title">{$v[title]}</div></div>
        </div>
        <div class="dis_pir weui-flex">
            <div class="weui-flex__item">
                <div class="price">
<span class="color-p right_rate">
    <!--{if $v[zktype]=='q'}-->
        <em>{$v[lijian]}{lang xigua_hb:yuan}{lang xigua_hk:yhq}</em>
    <!--{else}-->
        <em class="f24">{$v[rate]}</em>{lang xigua_hk:zhe}
    <!--{/if}-->
</span>
                    <!--{if  ($v[week_em] || $v[date_em])}-->
                    <div class="hk_wd">
                        <!--{if $v[week_em]}--><div><em class="week">{lang xigua_hk:week}</em>{$v[week_em]}</div><!--{/if}-->
                        <!--{if $v[date_em]}--><div><em class="date">{lang xigua_hk:date}</em>{$v[date_em]}</div><!--{/if}-->
                    </div><!--{/if}-->
                </div>
                <p class="discount f12">
                    <!--{if $v[maxmoney]}--><p class="f12 c9">{lang xigua_hk:man}{$v[maxmoney]}{lang xigua_hk:yksy}</p><!--{/if}-->
                    <!--{if $v[manmax]>0}--><p class="f12 c9">{lang xigua_hk:xmrmtlq}<span class="main_color">$v[manmax]</span>{lang xigua_hk:z}</p><!--{/if}-->
                    <p class="f12 c9">
                        <span>{lang xigua_hk:kc1}: <em class="main_color">{$v[stock_u]}</em></span>
                        <span class="ml10">{lang xigua_hk:zs}: <em class="main_color">{$v[sellnum]}</em></span>
                        <span class="ml10">{lang xigua_hk:views}: <em class="main_color">$v[views]</em></span>
                    </p>
                </p>
            </div>
        </div>
    </div>
    <div class="button-sp-area">
        <a href="$SCRITPTNAME?id=xigua_hk&ac=add&gid={$v[id]}$urlext" class="weui-btn weui-btn_mini hm_c_btn ">{lang xigua_hk:xg}</a>
        <!--{if $v[status]==3}-->
        <a href="javascript:;" data-id="{$v[id]}" data-do="shangjia" class="weui-btn weui-btn_mini hm_c_btn stock-del">{lang xigua_hk:s}</a>
        <!--{else}-->
        <a href="javascript:;" data-id="{$v[id]}" data-do="del" class="weui-btn weui-btn_mini hm_c_btn stock-del">{lang xigua_hk:x}</a>
        <!--{/if}-->
        <a href="$SCRITPTNAME?id=xigua_hk&ac=hxlog&gid={$v[id]}$urlext" class="weui-btn weui-btn_mini hm_c_btn ">{lang xigua_hk:xfjl}</a>
    </div>
</div>
<!--{/loop}-->
<!--{else}-->
<!--{loop $list $v}-->
<div data-id="{$v[id]}" data-date="{$_GET['date']}" class="hk_glist border_bottom">
    <div class="top">
        <div class="pic">
            <img src="{echo $v[album][0]?$v[album][0]:$v[append_img_ary][0]}">
        </div>
        <div class="txt">
            <h3 class="tit">{$v[title]}</h3>
            <div class="hk_wd">
                <!--{if $v[week_em]}--><div><em class="week">{lang xigua_hk:week}</em>{$v[week_em]}</div><!--{/if}-->
                <!--{if $v[date_em]}--><div><em class="date">{lang xigua_hk:date}</em>{$v[date_em]}</div><!--{/if}-->
            </div>
            <div class="discounts">
                <!--{if $v[zktype]=='q'}-->
                <i class="iconfont icon-quan1 vm"></i>
                <span>{$v[lijian]}{lang xigua_hb:yuan}{lang xigua_hk:yhq}</span>
                <!--{else}-->
                <i class="iconfont icon-zhekou1 vm"></i>
                <span>{$v[rate]}{lang xigua_hk:zyh}</span>
                <!--{/if}-->
            </div>
<!--{if $v[attention]}--><div class="other">$v[attention]</div><!--{/if}-->
        </div>
        <div class="right_act">
            <span>{$v[sellnum]}{lang xigua_hk:fyl}</span>
            <!--{if $_GET['orderby'] =='views'}-->
            <span>{$v[views]}{lang xigua_hk:req}</span>
            <!--{elseif  $_GET['orderby'] =='nearby'}-->
            <span class="location"><i class="iconfont icon-coordinates vm f15"></i>{$v[distance]}</span>
            <!--{else}-->
            <span>{$date_show}</span>
            <!--{/if}-->
            <span class="lqbtn">{lang xigua_hk:ljlq}</span>
        </div>
    </div>
</div>
<!--{/loop}-->
<!--{/if}-->