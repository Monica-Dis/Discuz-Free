<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/11/19
 * Time: 16:38
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hk/function.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";

$page = max(1, intval(getgpc('page')));
$lpp = $_GET['lpp']? $_GET['lpp'] : 20;
$start_limit = ($page - 1) * $lpp;
$hxstatus_ary = array(0=>lang_hk('weihexiaofa',0), 1=>lang_hk('yihexiaofa',0));


function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}
if (submitcheck('permsubmit')) {
    if ($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hk#xigua_hk_lingqu')->deletes($delete);
    }

    cpmsg(lang_hk('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_join&page=$page&lpp=$lpp", 'succeed');
}

$wherearr = array();
$keyword = $_GET['keyword'];
if ($keyword = stripsearchkey($keyword)) {
    $wherearr[] = " (uid='$keyword' OR code LIKE '%$keyword%') ";
}
if(isset($_GET['status'])){
    $wherearr[] = 'status=' . intval($_GET['status']);
}
if($secid = intval($_GET['gid'])){
    $wherearr[] = "gid='$secid'";
}
if(isset($_GET['hxstatus'])){
    $hxstatus = intval($_GET['hxstatus']);
    $wherearr[] = "hxstatus='$hxstatus'";
}

$ob = 'id DESC';

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_join&gid={$_GET['gid']}");

echo '<div><input type="text" id="keyword" placeholder="'.lang_hk('search_log',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
foreach ($hxstatus_ary as $index => $_v) {
    echo '<label><input type="radio" name="hxstatus" value="'.$index.'" ' . (isset($_GET['hxstatus'])&&$_GET['hxstatus']==$index&&$_GET['hxstatus']!=='' ? 'checked' : '') . ' />' . $_v.'</label>';
}
echo '&nbsp;';
$lpp_se = "<select name=\"lpp\">";
foreach (array(20, 50, 100, 200, 500, 1000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;
echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_join&gid={$_GET['gid']}".' class="btn" >'.cplang('reset').'</a> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_join&formhash=".formhash()."&doexport=1&keyword={$_GET['keyword']}&hxstatus={$_GET['hxstatus']}&lpp=$lpp&gid={$_GET['gid']}".' class="btn" >'.lang_hk('dc', 0).'</a> ';

showtableheader(lang_hk('fabuguanli', 0));
showtablerow('class="header"', array(), array(
    lang_hk('del', 0),
    lang_hk('spmc', 0),
    lang_hk('user', 0),
    lang_hk('mobile', 0),
    lang_hk('crts', 0).'/'. lang_hk('outdate', 0),
    lang_hk('hxstatus_danhao', 0),
    lang_hk('syri', 0),
    lang_hk('order_recive', 0),
    lang_hk('mendian', 0),
    lang_hk('hxcrts', 0),
    lang_hk('hxuid', 0)
));


$res = C::t('#xigua_hk#xigua_hk_lingqu')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
$icount = C::t('#xigua_hk#xigua_hk_lingqu')->fetch_count_by_page($wherearr);

$secids = $shids = array();
foreach ($res as $v) {
    if ($v['uid']) {
        $uids[$v['uid']] = $v['uid'];
    }
    if ($v['hxuid']) {
        $uids[$v['hxuid']] = $v['hxuid'];
    }
    $shids[$v['shid']] = $v['shid'];
    $secids[$v['gid']] = $v['gid'];
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $mobiles = DB::fetch_all('SELECT uid,mobile,realname FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}

if($shids){
    $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
}
if($secids){
    $secinfos = DB::fetch_all('SELECT * FROM %t where id in(%n)', array('xigua_hk_good', $secids), 'id');
}

foreach ($res as $k => $v) {
    $id = $v['id'];
    $dinfo = $secinfos[$v['gid']];
$yuan = lang_hk('yuan',0);
$zhe = lang_hk('zhe',0);

    if($dinfo['zktype']){
        $vstr = $dinfo['lijian'].lang('plugin/xigua_hb', 'yuan').lang('plugin/xigua_hk', 'ljyh');
    }else{
        $vstr = $v['rate'].$zhe;
    }
    if($v['hxstatus']==1){
        $hxstat_  = lang_hk('hashx',0);
        $hxstat = '<p style="color:forestgreen;">'. $hxstat_. '</p>';
        $hxstat .= lang_hk('hxmoney',0).":$v[hxmoney]$yuan<br> ".lang_hk('hxratemoney',0).":$v[hxratemoney]$yuan ($vstr)<br> ".lang_hk('hxnote',0).":$v[hxnote]<br>";

    }else{
        $hxstat_  =lang_hk('beenhx',0);
        $hxstat = '<p style="color:orangered;">'. $hxstat_ . '</p>';
    }
    $hxcrts = $v['hxcrts']? date('Y-m-d H:i:s', $v['hxcrts']) : '';

    $ginfo = "</p>".lang_hk('hkhykxs',0).$vstr;
    $ginfo .= $dinfo['maxmoney']>0 ? "<p style='color:#999'>".lang_hk('man',0)."{$dinfo['maxmoney']}".lang_hk('yksy',0)."</p>":'';
    $ginfo .= $dinfo['manmax']>0 ? "<p style='color:#999'>".lang_hk('xmrmtlq',0)."{$dinfo['manmax']}".lang_hk('z',0)."</p>":'';
    $sh = "[ID: {$v['shid']}]".$shinfos[$v['shid']]['name'];
    $hxr = "[UID:{$v['hxuid']}]". $users[$v['hxuid']]['username'];

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
        '<p style="color:#09C">'.$dinfo['title'].$ginfo,
        "[UID: {$v['uid']}]". $users[$v['uid']]['username'],
        $mobiles[$v['uid']]['realname'].'<br>'.$mobiles[$v['uid']]['mobile'],
        $v['crts_u'].'<br>'.$v['endts_u'],
        $hxstat,
        $v['usedate'],
        $v['code'],
        '<p style="color:#09C">'.$sh.'</p>',
        $hxcrts,
        $v['hxuid'] ? $hxr : ''
    ));

    $res[$k]['gid'] .= " ".$dinfo['title'];
    $res[$k]['shid'] = $sh;
    $res[$k]['hxuid'] = $hxr;
    $res[$k]['crts'] = $v['crts_u'];
    $res[$k]['startts'] = date('Y-m-d H:i:s', $res[$k]['startts']);
    $res[$k]['endts'] = $res[$k]['endts_u'];
    $res[$k]['hxstatus'] = $hxstat_;
    $res[$k]['hxcrts'] = $hxcrts;
    unset($res[$k]['usets']);
    unset($res[$k]['src']);
    unset($res[$k]['note']);
    unset($res[$k]['crts_u']);
    unset($res[$k]['status']);
    unset($res[$k]['endts_u']);
    unset($res[$k]['hxcrts_u']);
    unset($res[$k]['isend']);
}
if(submitcheck('formhash', 1) && $_GET['doexport']==1 && $_GET['formhash'] == FORMHASH){
    foreach ($res[0] as $index => $item) {
        $title_arr[] = lang_hk($index,0);
    }
    export_csv($res, $title_arr);
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_join&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', 'del', "", $multipage);
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/