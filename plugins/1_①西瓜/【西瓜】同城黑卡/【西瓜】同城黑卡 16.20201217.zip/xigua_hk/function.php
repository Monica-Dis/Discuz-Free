<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function lang_hk($lang, $echo = 1){
    $ret = lang('plugin/xigua_hk', $lang);
    global $_G;
    $ret = str_replace(lang('plugin/xigua_hk', 'heika'), $_G['cache']['plugin']['xigua_hk']['cardname'], $ret);
    if($echo){
        echo $ret;
    }else{
        return $ret;
    }
}

function hk_join_call_back($param){
    $info = $param['info'];
    $cardata = $info['data'];
    $cardkind = unserialize($cardata['cardinfo']);
    $days  = $cardkind[1];

    C::t('#xigua_hk#xigua_hk_card')->update_endts($cardata['cardno'], $days*86400, $param['order_id']);
    return true;
}


function hk_xufei_callback($param){
    $info = $param['info'];
    $cardata = $info['data'];
    return $param;
}
function hk_init_charset(){
    return hk_xufei_callback('');
}
function hk_diouf12date($num){
    $dates = range(0, $num);

    $weekarray=array(
        lang_hk('w0',0),
        lang_hk('w1',0),
        lang_hk('w2',0),
        lang_hk('w3',0),
        lang_hk('w4',0),
        lang_hk('w5',0),
        lang_hk('w6',0),
    );
    foreach ($dates as $index => $datum) {
        $date = strtotime("+$datum days");
        $dates[$index] = array(
            'date' => date("Y-m-d", $date),
            'date_mid' => date("m-d", $date),
            'date_short' => date("d", $date),
            'week' => $weekarray[date("w", $date)],
        );
    }

    return $dates;
}
function hk_nl2br($txt){
    if(strpos($txt, '&lt;') !== false  && strpos($txt, '&gt;') !== false) {
        $txt = htmlspecialchars_decode($txt);
        $txt = preg_replace(array("/<script(.*?)<\/script>/is", '/on(mousewheel|mouseover|click|load|onload|submit|focus|blur)="[^"]*"/i'), array('', ''), $txt);
    }
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}
function hk_qrcode_make($code){
    global $_G, $config,$SCRITPTNAME,$urlext;

    $repath = './source/plugin/xigua_hk/cache/';
    $qrfile = $repath . $code . '.png';
    $abs_qrfile = DISCUZ_ROOT . $qrfile;
    $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_hk&ac=scan&code=$code".$urlext;

    if(!is_file($abs_qrfile)) {
        if (!is_file($abs_qrfile)) {
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')){
                QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
            }
        }
    }
    return $qrfile;
}