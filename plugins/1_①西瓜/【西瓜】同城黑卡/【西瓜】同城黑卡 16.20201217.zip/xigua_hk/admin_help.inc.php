<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

if($_GET['add']){
    if(!submitcheck('addsubmit')){
        if($_GET['id']){
            $data = C::t('#xigua_hk#xigua_hk_help')->fetch($_GET['id']);
        }
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_help&page=$page&add=1");
        showtableheader(); /*Dism_taobao-com*/
        showtitle(lang_hb('add_help', 0). "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_help&page=$page'> ".lang_hb('back',0)."</a>");
        showsetting(lang_hb('subject', 0), 'form[subject]', $data['subject'], 'text');
?>
<tr>
    <td colspan="2"><?php lang_hb('description')?></td>
</tr>
<tr class="hover">
    <td colspan="2">
        <script name="form[content]" id="c12" type="text/plain" style="width:1024px;height:500px;"><?php echo $data['content'] ?></script>
    </td>
</tr>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('c12');</script>
<input type="hidden" name="id" value="<?php echo $_GET['id']?>" />
<?php
        showsubmit('addsubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
    }else{
        $form = $_GET['form'];
        if(!$_GET['id']){
            C::t('#xigua_hk#xigua_hk_help')->insert(array(
                'subject' => $form['subject'],
                'content' => $form['content'],
                'crts'    => TIMESTAMP,
            ));
        }else{
            C::t('#xigua_hk#xigua_hk_help')->update($_GET['id'], array(
                'subject' => $form['subject'],
                'content' => $form['content'],
                'crts'    => TIMESTAMP,
            ));
        }
        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_help&page=$page", 'succeed');
    }

}else{

    if(submitcheck('permsubmit')){
        if($delete = dintval($_GET['delete'], true)) {
            $r = C::t('#xigua_hk#xigua_hk_help')->deletes($delete);
        }
        if($r){
            cpmsg(lang_hb('delete_succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_help&page=$page", 'succeed');
        }
        if($r = $_GET['row']){
            foreach ($r as $index => $item) {
                C::t('#xigua_hk#xigua_hk_help')->update($index, $item);
            }
        }
        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_help&page=$page", 'succeed');
    }

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_help&page=$page");
    showtableheader(lang_hb('bangzhuguanli', 0));
    showtablerow('class="header"',array(),array(
        lang('plugin/xigua_hb','del'),
        lang('plugin/xigua_hb','order'),
        lang_hb('subject', 0),
        lang('plugin/xigua_hb','crts'),
        lang('plugin/xigua_hb','caozuo'),
    ));

    $res = C::t('#xigua_hk#xigua_hk_help')->fetch_all_by_page($start_limit, $lpp);
    $icount = C::t('#xigua_hk#xigua_hk_help')->fetch_count_by_page();


    $url = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_help&lpp=$lpp";
    foreach ($res as $v) {
        $cid = $v['id'];

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$cid' /> $cid",
            "<input name='row[$cid][displayorder]' value='{$v['displayorder']}' />",
            $v['subject'],
            date('m-d H:i:s', $v['crts']),
            "<a href='$url&add=1&id=$cid'>".lang_hb('edit', 0)."</a>",
        ));
    }
    $multipage = multi($icount, $lpp, $page, $url, 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "<a href='$url&add=1'>".lang_hb('add',0)."</a>", $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/
}