<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/11/19
 * Time: 16:38
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hk/function.php';
$hk_config = $_G['cache']['plugin']['xigua_hk'];

$page = max(1, intval(getgpc('page')));
$lpp = $_GET['lpp']? $_GET['lpp'] : 20;
$start_limit = ($page - 1) * $lpp;
$hxstatus_ary = array(0=>lang_hk('wsy',0), 1=>lang_hk('ysy',0));


function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}
if (submitcheck('permsubmit')) {
    if ($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hk#xigua_hk_num')->deletes($delete);
    }

    cpmsg(lang_hk('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm&page=$page&lpp=$lpp", 'succeed');
}
if(submitcheck('viptype')){
    $vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99);

    if(!$_GET['jhmsl']){
        cpmsg(lang_hk('jhmsl1', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm&page=0", 'error');
    }
    if($num = intval($_GET['jhmsl'])){
        $ary = range(1, $num);
        foreach ($ary as $index => $item) {
            $data = array(
                'uid' => 0,
                'crts' => TIMESTAMP,
                'lastts' => 0,
                'upts' => TIMESTAMP,
                'usets' => 0,
                'viptype' => $_GET['viptype'],
                'cardnum' =>$_GET['qz']. mt_rand(10000000, 99999999)
            );
            C::t('#xigua_hk#xigua_hk_num')->insert($data);
        }
        cpmsg(lang_hk('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm&page=0", 'succeed');
    }
}

if(submitcheck('jhmsl')){
    if(!$_GET['jhmyxq']){
        cpmsg(lang_hk('jhmyxq1', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm&page=0", 'error');
    }
    if(!$_GET['jhmsl']){
        cpmsg(lang_hk('jhmsl1', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm&page=0", 'error');
    }
    if($num = intval($_GET['jhmsl'])){
        $ary = range(1, $num);
        foreach ($ary as $index => $item) {
            $data = array(
                'uid' => 0,
                'crts' => TIMESTAMP,
                'lastts' => $_GET['jhmyxq'] * 86400,
                'upts' => TIMESTAMP,
                'usets' => 0,
                'cardnum' =>$_GET['qz']. mt_rand(10000000, 99999999)
            );
            C::t('#xigua_hk#xigua_hk_num')->insert($data);
        }
        cpmsg(lang_hk('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm&page=0", 'succeed');
    }
}

$wherearr = array();
$keyword = $_GET['keyword'];
if ($keyword = stripsearchkey($keyword)) {
    $wherearr[] = " (uid like '%$keyword%' OR cardnum LIKE '%$keyword%') ";
}
if(isset($_GET['hxstatus'])){
    $hxstatus = intval($_GET['hxstatus']);
    if($hxstatus > 0){
        $wherearr[] = "uid>0";
    }else{
        $wherearr[] = "uid='0'";
    }
}

$ob = 'id DESC';

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm");
echo '<div style="margin-top:10px">'.lang_hk('hkjhm',0).' <input type="text" placeholder="'.lang_hk('jhmqz',0).'" name="qz" value="" class="txt"> <input type="text" placeholder="'.lang_hk('jhmsl',0).'" name="jhmsl" value="" class="txt" /> ';
echo ' <input type="text" placeholder="'.lang_hk('jhmyxq',0).'" name="jhmyxq" value="" class="txt" />';
echo '&nbsp;';
echo ' <input type="submit" class="btn" value="' . lang_hk('plsc', 0) . '" /> </div>';
showformfooter(); /*Dism_taobao_com*/

$vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99, 'id');
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm");
echo '<div style="margin-top:2px;margin-bottom:8px">'.lang_hk('shjhm',0).' <input type="text" placeholder="'.lang_hk('jhmqz',0).'" name="qz" value="" class="txt"> <input type="text" placeholder="'.lang_hk('jhmsl',0).'" name="jhmsl" value="" class="txt" /> ';
echo '<select name="viptype">';
foreach ($vips as $index => $vip) {
    echo '<option value="'.$vip['id'].'">'.$vip['name'].$vip['udays'].'</option>';
}
echo '</select>';
echo '&nbsp;';
echo ' <input type="submit" class="btn" value="' . lang_hk('plsc', 0) . '" /> </div>';
showformfooter(); /*Dism_taobao_com*/

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm&gid={$_GET['gid']}");
echo '<div><input type="text" id="keyword" placeholder="'.lang_hk('jhm_log',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
foreach ($hxstatus_ary as $index => $_v) {
    echo '<label><input type="radio" name="hxstatus" value="'.$index.'" ' . (isset($_GET['hxstatus'])&&$_GET['hxstatus']==$index&&$_GET['hxstatus']!=='' ? 'checked' : '') . ' />' . $_v.'</label>';
}

$lpp_se = "<select name=\"lpp\">";
foreach (array(20, 50, 100, 200, 500, 1000, 5000, 10000, 20000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;
echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm&formhash=".formhash()."&doexport=1&keyword={$_GET['keyword']}&hxstatus={$_GET['hxstatus']}&page=$page&lpp=$lpp&gid={$_GET['gid']}".' class="btn" >'.lang_hk('dc', 0).'</a> ';

showtableheader(lang_hk('jhmgl', 0));
showtablerow('class="header"', array(), array(
    lang_hk('del', 0),
    lang_hk('jhm', 0),
    lang_hk('uid', 0),
    lang_hk('lastts', 0),
    lang_hk('usets', 0),
    lang_hk('crts', 0),
    lang_hk('upts', 0),
));

$res = C::t('#xigua_hk#xigua_hk_num')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
$icount = C::t('#xigua_hk#xigua_hk_num')->fetch_count_by_page($wherearr);

$secids = $shids = array();
foreach ($res as $v) {
    if ($v['uid']) {
        $uids[$v['uid']] = $v['uid'];
    }
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $mobiles = DB::fetch_all('SELECT uid,mobile,realname FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}


foreach ($res as $k => $v) {
    $id = $v['id'];

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
        '<p style="color:#09C">'.$v['cardnum'].'</p>',
        $res[$k]['uid'] = $v['uid'] ? "[UID: {$v['uid']}]". $users[$v['uid']]['username'] : '-',
        $v['lastts'] ? intval($v['lastts']/86400).lang_hk('t',0) : (
            $vips[$v['viptype']]['name'] . $vips[$v['viptype']]['udays']
        ),
        $res[$k]['usets'] = $v['usets']? date('Y-m-d H:i:s', $v['usets']) : '-',
        $res[$k]['crts'] = $v['crts']? date('Y-m-d H:i:s', $v['crts']) : '',
        $res[$k]['upts'] = $v['upts']? date('Y-m-d H:i:s', $v['upts']) : '',
    ));
    unset($res[$k]['lastts']);
}
if(submitcheck('formhash', 1) && $_GET['doexport']==1){
    foreach ($res[0] as $index => $item) {
        $title_arr[] = lang_hk($index,0);
    }
    export_csv($res, $title_arr);
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_jhm&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', 'del', "", $multipage);
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/