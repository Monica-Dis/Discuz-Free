<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hk_card extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hk_card';
        $this->_pk = 'cardno';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'cardno DESC', $fields= '*')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i', $v['upts']) : '';
            $v['endts_u'] = $v['endts'] ? date('Y-m-d', $v['endts']) : '';
            $v['isend'] = $v['endts']&& $v['endts']<TIMESTAMP ? 1 : 0;
            $v['status_u'] = ($v['status']==1 && !$v['isend']) ? 1 : 0;
            if($v['isend'] && $v['status']!=2){
                DB::query("update %t set status=2 WHERE cardno=%d", array('xigua_hk_card', $v['cardno']));
            }elseif(!$v['isend'] && $v['status']==2){
                DB::query("update %t set status=1 WHERE cardno=%d", array('xigua_hk_card', $v['cardno']));
            }
        }
        return $v;
    }

    public function fetch_by_uid($uid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
        $v = self::prepare($v);
        return $v;
    }

    public function update_endts($cardno, $allts, $order_id)
    {
        $payts = TIMESTAMP;
        $old_data = $this->fetch($cardno, TRUE);
        if($old_data['endts']<TIMESTAMP){
            DB::query("update %t set endts=%d WHERE {$this->_pk}=%d", array($this->_table, TIMESTAMP, $cardno));
        }
        return DB::query("update %t set endts=endts+%d,status=1,order_id=%s,payts=%d WHERE {$this->_pk}=%d", array($this->_table, $allts, $order_id, $payts, $cardno));
    }

    public function fetch_online_card($uid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND status=1 AND endts>%s", array($this->_table, $uid, TIMESTAMP));
        $v = self::prepare($v);
        return $v;
    }
    public function fetch_online_card_num()
    {
        global $_G;
        $v = DB::result_first("SELECT count(*) FROM %t WHERE status=1 OR status=2 ", array($this->_table));
        return $v+$_G['cache']['plugin']['xigua_hk']['xnkks'];
    }
    public function do_delete($id)
    {
        return $this->delete($id);
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = array();
        $result = DB::fetch_all("SELECT * FROM %t  ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp), array($this->_table));
        if($result){
            foreach ($result as $index => $item) {
                $result[$index] = self::prepare($item);
            }
        }
        return $result;
    }

    public function count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }


    public function incr($gid, $field, $num = 1)
    {
        if(!$field){
            return null;
        }
        if(strpos($gid, ',')!==false){
            $gid = dintval(array_filter(explode(',', $gid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $gid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $gid));
        }
    }
    public function fetch_newest_card($num = 5)
    {
        $orderby = ' crts DESC ';
        $wherearr = array('status=1');
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql  ORDER BY $orderby LIMIT $num");
        $uids = array();
        foreach ($result as $index => $item) {
            $uids[] = $item['uid'];
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }
        foreach ($result as $index => $item) {
            $result[$index]['username'] = $users[$item['uid']]['username'];
            $result[$index]['cardinfo_ary'] = unserialize($result[$index]['cardinfo']);
        }
        return $result;
    }
}