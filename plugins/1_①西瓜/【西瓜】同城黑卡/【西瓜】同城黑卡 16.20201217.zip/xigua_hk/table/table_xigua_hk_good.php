<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hk_good extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hk_good';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false)
    {
        $good_id = parent::insert($data, true, $replace, $silent);
        if($data['status'] == 2){
            global $_G,$SCRITPTNAME,$urlext;
            $guanids = C::t('#xigua_hs#xigua_hs_follow')->fetch_follow_by_shid($data['shid']);
            foreach ($guanids as $index => $guanid) {
                notification_add($guanid,'system',
                    "<a href='{url}'>{name}".lang('plugin/xigua_hb', 'fabule')."{subject}</a>",array(
                        'name' => $data['shname'],
                        'url' => "{$_G['siteurl']}{$SCRITPTNAME}?id=xigua_hk&ac=view&gid=$good_id&".$urlext,
                        'subject' => $data['title']
                    ),

                    1);
            }
        }
        return $good_id;
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }

    public function fetch_in($ids){
        if(!$ids){
            return array();
        }
        $rs = DB::fetch_all("select * from %t where id IN(%n)", array($this->_table, $ids), 'id');
        foreach ($rs as $index => $r) {
            $rs[$index] = self::prepare($r);
        }
        return $rs;
    }

    public function fetch_by_good_id($gid)
    {
        $rs = parent::fetch($gid);
        $rs = self::prepare($rs);
        $this->incr($gid, 'views');
        return $rs;
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first('select * from %t WHERE id=%d AND uid=%d', array(
            $this->_table,
             $id,
             $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*', $skiprepare = 0)
    {
        global $_G;
        if($_GET['shid']){
            $wherearr[] = 'shid = '. intval($_GET['shid']);
        }
        if($_GET['shangquan'] && $_GET['shangquan']!=-1){
            $shids = DB::fetch_all('select shid FROM %t WHERE shangquan=%s AND display=1 AND endts>=%d limit 1000', array(
                'xigua_hs_shanghu',
                $_GET['shangquan'],
                TIMESTAMP
            ), 'shid');
            if($shids){
                $wherearr[] = 'shid in ('. implode(',',array_keys($shids)).') ';
            }
        }
        if(is_array($wherearr) && !defined('IN_ADMINCP')){
            $wherearr[] = 'stid='.intval($_GET['st']);
            global $_G;
            if(!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']){
                array_pop($wherearr);
            }
        }
        global $date_now;
        if($date_now){
            $ts = strtotime($date_now);
            $ts1 = strtotime($date_now . ' 23:59:59');
            $wherearr[] = " (startts<$ts1 AND $ts<endts )";
        }

        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        if(!$skiprepare){
            foreach ($result as $index => $item) {
                $result[$index] = $this->prepare($item);
            }
        }
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            $v['append_img_ary'] = unserialize($v['append_img']);
            $v['append_text_ary'] = unserialize($v['append_text']);
            $v['album'] = unserialize($v['album']);
            $v['rate'] = str_replace('.0', '', $v['rate']);
            $v['lijian'] = $v['lijian'] ? floatval($v['lijian']) : 0;
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['startts_u'] = $v['startts'] ? date('Y-m-d H:i', $v['startts']) : '';
            $v['endts_u'] = $v['endts'] ? date('Y-m-d H:i', $v['endts']) : '';
            $v['isend']   = $v['endts'] < TIMESTAMP || $v['stock']<=0;
            $v['week_em'] = $v['week'] ? "<em>".str_replace(',', '</em><em>', $v['week'])."</em>" : '';
            $v['date_em'] = $v['date'] ? "<em>".str_replace(array(',',lang('plugin/xigua_hk', 'meiyue')), array('</em><em>',''), $v['date'])."</em>" : '';
            $v['week_ary'] = $v['week'] ? explode(',', $v['week'])  : array();
            $v['date_ary'] = $v['date'] ? explode(',', str_replace(array(lang('plugin/xigua_hk', 'meiyue'), lang('plugin/xigua_hk', 'ri')), '', $v['date']))  : array();
            $v['srange_ary'] = array_filter(explode("\t", trim($v['srange'])));
            $v['stock_u'] = $v['stock'] >= 999999 ? lang('plugin/xigua_hk', 'bx') : $v['stock'];
            $v['not_start'] = $v['startts']>TIMESTAMP;
            if($v['stock'] <999999){
                if($v['autostock']>0 && $v['lastauto']!=date('Y-m-d', TIMESTAMP)){
                    DB::update('xigua_hk_good', array(
                        'stock' => $v['autostock'],
                        'lastauto' => date('Y-m-d', TIMESTAMP)
                    ), array(
                        'id'=> $v['id']
                    ));
                }
            }
        }
        return $v;
    }


    public function incr($gid, $field, $num = 1)
    {
        if(!$field){
            return null;
        }
        if(strpos($gid, ',')!==false){
            $gid = dintval(array_filter(explode(',', $gid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $gid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $gid));
        }
    }
}