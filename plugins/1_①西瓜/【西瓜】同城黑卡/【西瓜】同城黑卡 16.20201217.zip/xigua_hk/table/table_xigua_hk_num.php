<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2015/11/3
 * Time: 15:09
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hk_num extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hk_num';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY displayorder ASC " . DB::limit($start_limit, $lpp));
        return $result;
    }
    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'id DESC', $fields= '*')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_by_cardnum($cardnum)
    {
        $result = DB::fetch_first('SELECT * FROM %t WHERE cardnum=%s AND uid=0', array($this->_table, $cardnum));
        return $result;
    }

    public function prepare($v)
    {
        if($v){

        }
        return $v;
    }
}