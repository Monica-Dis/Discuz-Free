<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hk_lingqu extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hk_lingqu';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'id DESC', $fields= '*')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['endts_u'] = $v['endts'] ? date('Y-m-d H:i', $v['endts']) : '';
            $v['isend'] = ($v['endts'] < TIMESTAMP || $v['usets']<TIMESTAMP) && !$v['hxstatus'] && $v['status']==2;
            $v['hxcrts_u'] = $v['hxcrts'] ? date('Y-m-d H:i', $v['hxcrts']) : '';
            $v['rate'] = str_replace('.0', '', $v['rate']);
            if($v['code']){
                $v['src'] = "source/plugin/xigua_hk/cache/{$v['code']}.png";
            }
        }
        return $v;
    }

    public function fetch_by_uid($uid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
        $v = self::prepare($v);
        return $v;
    }
    public function fetch_count_by_uid($uid, $gid, $date)
    {
        $v = DB::result_first("SELECT  count(*) FROM %t WHERE uid=%d AND gid=%d AND `usedate`=%s ", array($this->_table, $uid, $gid, $date));
        return $v;
    }
    public function fetch_count_all_uid($uid, $gid)
    {
        $v = DB::result_first("SELECT  count(*) FROM %t WHERE uid=%d AND gid=%d ", array($this->_table, $uid, $gid));
        return $v;
    }
    public function fetch_used_count_by_uid($uid, $gid, $date)
    {
        $v = DB::result_first("SELECT  count(*) FROM %t WHERE uid=%d AND gid=%d AND `usedate`=%s AND hxstatus=1 ", array($this->_table, $uid, $gid, $date));
        return $v;
    }
    public function fetch_unuse_by_uid($uid, $gid, $date)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND gid=%d AND `usedate`=%s AND hxstatus=0 ", array($this->_table, $uid, $gid, $date));
        if($v['code']){
            $v['src'] = "source/plugin/xigua_hk/cache/{$v['code']}.png";
        }
        return $v;
    }
}