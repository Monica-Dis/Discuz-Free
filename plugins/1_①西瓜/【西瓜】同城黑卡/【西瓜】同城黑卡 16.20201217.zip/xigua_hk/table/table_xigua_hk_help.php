<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2015/11/3
 * Time: 15:09
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hk_help extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hk_help';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY displayorder ASC " . DB::limit($start_limit, $lpp));
        return $result;
    }
    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }
}