<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/11/19
 * Time: 16:38
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hk/function.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";

$page = max(1, intval(getgpc('page')));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$statuss = array(
    '1' => lang_hk('ddsh',0),
    '2' => lang_hk('ysj',0),
    '3' => lang_hk('yxj',0)
);

$hk_config = $_G['cache']['plugin']['xigua_hk'];
$svicerange = array();
foreach (explode("\n", trim($hk_config['svicerange'])) as $index => $item) {
    $svicerange[] = trim($item);
}

if($secid = intval($_GET['secid'])){

    $res = C::t('#xigua_hk#xigua_hk_good')->fetch($secid);
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $res = array ( 'id' => '0', 'crts' => '0', 'upts' => '0', 'startts' => '0', 'endts' => '0', 'displayorder' => '0', 'uid' => '0', 'title' => '', 'shid' => '0', 'shname' => '', 'province' => '', 'city' => '', 'district' => '', 'stock' => '', 'sellnum' => '', 'timeuses' => '', 'week' => '', 'date' => '', 'zktype' => '', 'rate' => '5.0','lijian' => '0.0', 'bigweek' => '', 'bigdate' => '', 'bigrate' => '0.0', 'manmax' => '3', 'maxmoney' => '300', 'attention' => '', 'notice' => '', 'jieshao' => '', 'append_img' => 'a:0:{}', 'append_text' => 'a:0:{}', 'album' => '', 'status' => '2', 'srange' => '', 'views' => '', 'shares' => '0', 'stid' => '0',  );
        }
        unset($res['shixian']);

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good&secid=$secid", 'enctype');
        showtableheader(); /*Dism_taobao-com*/
        showtitle(lang_hk('spgl',0) . ($secid>0?$secid:''). "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good'> ".lang_hk('back',0)."</a>");

        foreach ($res as $index => $re) {
            if(in_array($index, array('hangye_id1','hangye_id2','bigweek','bigdate','bigrate','shname', 'not_start', 'end','srange_ary','xiajia','shen', 'quan', 'yuanprice','id','color_title', 'is_end', 'shares'))){
                continue;
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('endts', 'crts', 'upts', 'usetime', 'startts'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('shid'))){
                $cs = '<select name="editform[shid]">';
                foreach (DB::fetch_all('select shid,`name` from %t WHERE display=1 AND endts>=%d', array(
                    'xigua_hs_shanghu',
                    TIMESTAMP
                ), 'shid') as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['name']}[".lang_hk('sh',0)."ID:{$c['shid']}]</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('zktype'))){
                $s1 = $s2 = '';
                if('q'== $re){
                    $s1 = 'selected';
                }
                if(''== $re){
                    $s2 = 'selected';
                }
                $cs = '<select name="editform[zktype]">';
                $cs .= "<option value='q' $s1>".lang_hk('yhlj', 0)."</option>";
                $cs .= "<option value='' $s2>".lang_hk('dz', 0)."</option>";
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('thumb'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('yuyue' ,'gongkai','showdis', 'selfdis', 'orderdis', 'autostock'))){
                $tp = 'radio';
            }elseif(in_array($index, array('srange'))){
                $re = explode("\t", $re);
                $cs = '<select name="editform[srange][]" multiple="multiple">';
                foreach ($svicerange as $__v) {
                    $s = '';
                    if(in_array($__v, $re)){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$__v'>$__v</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }

            if (in_array($index, array('album', 'append_img', 'append_text'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $hs_config = $_G['cache']['plugin']['xigua_hs'];
                $loopnum = $hs_config['maximg'];
                if ($index == 'append_text') {
                    $tp = 'text';
                }
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_hk($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_hk($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                $l = lang_hk($index, 0);
                if(in_array($index, array('week', 'date', 'rate'))){
                    $l = lang_hk($index.'__tip', 0);
                }
                showsetting($l, "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach (array('crts', 'upts', 'startts', 'endts') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        $editform['jieshao'] = ($editform['jieshao']);
        $editform['append_text'] = array_slice($editform['append_text'], 0, count($editform['append_img']));

        foreach (array('album', 'append_text', 'append_img') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }

        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($editform['shid']);
        if(!$sh){
            cpmsg(lang_hk('shnotexists',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good&secid=$secid", 'error');
        }
        $editform['shname']     = $sh['name'];
        $editform['shid']       = $sh['shid'];
        $editform['hangye_id1'] = $sh['hangye_id1'];
        $editform['hangye_id2'] = $sh['hangye_id2'];
        $editform['srange']     = implode("\t", $editform['srange']);

        if($secid>0){
            $rs = C::t('#xigua_hk#xigua_hk_good')->update($secid, $editform);
        }else{
            $rs = C::t('#xigua_hk#xigua_hk_good')->insert($editform);
        }
        cpmsg(lang_hk('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good&secid=$secid", 'succeed');
    }
}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_hk#xigua_hk_good')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_hk#xigua_hk_good')->update($id, array('displayorder' => $item['displayorder'], 'status' => $item['status']));
        }

        cpmsg(lang_hk('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey($keyword)) {
        $wherearr[] = " (title LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR attention LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR append_text LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }

    $ob = ' displayorder DESC';

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_hk('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($statuss as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good".' class="btn" >'.cplang('reset').'</a> ';
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good&secid=-1\" class=\"btn\">".lang_hk('tjsp',0)."</a></div>";

    showtableheader(lang_hk('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_hk('del', 0),
        lang_hk('displayorder', 0),
        lang_hk('thumb', 0),
        lang_hk('title', 0),
        lang_hk('hsname', 0),
        lang_hk('ysy',0).'/'.lang_hk('zs', 0),
        lang_hk('kc', 0),
        lang_hk('crendts', 0),
        lang_hk('spzt', 0),
        lang_hk('xszt', 0),
        lang_hk('caozuo', 0),
    ));


    $res = C::t('#xigua_hk#xigua_hk_good')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = C::t('#xigua_hk#xigua_hk_good')->fetch_count_by_page($wherearr);

    $shids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $shids[$v['shid']] = $v['shid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($shids){
        $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $shid = $v['shid'];
        $thumb = $v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0];
        $stat = lang_hk('jxz',0);
        if($v['not_start']){
            $stat =lang_hk( 'wks',0);
        }elseif ($v['isend']){
            $stat = lang_hk('yjs',0);
        }
        if($v['stock']<=0){
            $stat = lang_hk('ysw',0);
        }


        $checked = $v['display'] ? 'checked' : '';

        $appeend = '';
        foreach ($v['append_img_ary'] as $__k => $__v) {
            $appeend .= "<p><img style='width:180px;display:block' src=\"{$__v}\" /></p>";
            $appeend .= "<p>" . nl2br($v['append_text_ary'][$__k]) . "</p>";
        }

        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($statuss as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        $c = ($v['endts'] < TIMESTAMP ? 'style="color:red"' : 'style="color:forestgreen"');

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input type='text' name='row[$id][displayorder]' value='{$v['displayorder']}' style='width:50px' />",
            "<img src='$thumb' style='width:70px;height:40px' />",
            $v['title'],
            "<a target='_blank' href='".ADMINSCRIPT."?action=plugins&operation=config&do=&identifier=xigua_hs&pmod=admin_shanghu&shid=".$v['shid']."'>".$shinfos[$v['shid']]['name'].'</a>',
            "<span>{$v['timeuses']}</span>/<span>{$v['sellnum']}</span>",
            $v['stock_u'],
            $v['crts_u'].'<br>'.$v['startts_u'].'/'.$v['endts_u'],

            $status_u,
            $stat,

            '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good&secid=$id" . '">' . lang_hk('edit', 0) . '</a> '.
            '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_join&gid=$id" . '">' . lang_hk('gmjl', 0) . '</a>',
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hk&pmod=admin_good&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/

    /*echo '<pre>';
    print_r($res);
    echo '</pre>';*/
}