<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2016/9/30
 * Time: 9:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$t =
    lang('plugin/xigua_hk','fangwen'). $_G['siteurl'].'plugin.php?id=xigua_hk&mobile=2<br><br>'.
    lang('plugin/xigua_hk','new_pub').lang('plugin/xigua_hk','m'). $_G['siteurl'].'plugin.php?id=xigua_hk&ac=add&mobile=2<br><br>'.
    lang('plugin/xigua_hk','fabuguanli').lang('plugin/xigua_hk','m'). $_G['siteurl'].'plugin.php?id=xigua_hk&ac=manage&is_my=1&mobile=2<br><br>'.
    lang('plugin/xigua_hk','hksybz').lang('plugin/xigua_hk','m'). $_G['siteurl'].'plugin.php?id=xigua_hk&ac=help&mobile=2<br><br>'.
'';
cpmsg($t, '','succeed');