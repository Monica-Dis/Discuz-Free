$(function () {
    $(document).on('click','.navbar', function () {
        var that = $(this);
        that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
        if(that.data('display')){
            $('#'+that.data('display')).show();
        }
        if(that.data('hide')){
            $('#'+that.data('hide')).hide();
        }
        if(that.data('id')){
            $('#'+that.data('id')).val(that.data('value'));
        }
    });

    if($('.hk_swiper').length>0){
        var hk_swiper = new Swiper('.hk_swiper', {
            slidesPerView: 'auto',
            paginationClickable: true,
            spaceBetween: 0
        });
    }
    $(document).on('click','.light_box a', function () {
        var that =$(this);
        $('.light_box a').removeClass('main_color');
        that.addClass('main_color');
        loadingurl = loadingurl.replace(/\&date\=\d{4}\-\d{2}-\d{2}/, '');
        hk_setlist(null, '&date='+that.data('date'));
    });

    $(document).on('click','.filter_nav', function () {
        $(this).addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
        var curt = $('#dist_show_'+$(this).data('id'));
        curt.siblings().removeClass('show');
        curt.toggleClass('show');
        if(curt.hasClass('show')){
            $(this).parent().addClass('filter_top');
            $(this).find('em').html($(this).find('em').data('html'));
            $('.mask').show();
        }else{
            $(this).parent().removeClass('filter_top');
            $('.mask').hide();
        }
        if(IN_APP==='magapp'){
            $('#backtotop').trigger('click');
        }
        return false;
    });
    $(document).on('click','.mask', function () {
        $('.filter_top').removeClass('filter_top');
        $('.dist_show').find('.nav_expand_panel').removeClass('show');
        $(this).hide();
    });

    $(document).on('click','.ftb', function () {
        var that = $(this);
        that.parent().parent().find('.checked').removeClass('checked main_color');
        that.parent().addClass('checked main_color');
        $('.mask').trigger('click');

        var oem = $('#ftb'+that.data('idid')).find('em');
        var showhtm = that.html();
        if(that.data('orihtml')){
            showhtm = that.data('orihtml');
        }
        oem.data('html', oem.html()).html(showhtm);

        var lnk = that.data('sort');
        if(lnk.indexOf('&orderby=nearby')!==-1){
            if(lockIng) return;
            lockIng = 1;
            setTimeout(function () {
                lockIng = 0;
            }, 200);
            hs_getlocation(function (position) {
                var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
                hk_setlist(that, lnk+'&lat='+lat+'&lng='+lng);
            });
        }else{
            hk_setlist(that, lnk);
        }
    });

    $(document).on('click', '.hk_glist', function () {
        var that = $(this);
        var daten = '';
        if(that.data('date')){
            daten = that.data('date');
        }
        var jmpurl = _APPNAME +'?id=xigua_hk&ac=view&date='+daten+'&gid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        if(typeof mag !== 'undefined'){
            mag.newWin(GSITE+jmpurl);
            return false;
        }
        if(typeof wx !=='undefined'){
            if (window.__wxjs_environment === 'miniprogram') {
                GSITE = GSITE.replace(/http:\/\//, 'https://');
                wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
                return false;
            }
        }
        if(typeof QFH5 !== 'undefined'){
            QFH5.jumpNewWebview(GSITE+jmpurl);
            return false;
        }
        window.location.href = jmpurl;
        return false;
    });

    var getQ = null;
    $(document).on('click','#getQuan', function () {
        var that = $(this);
        if(that.data('src')){
            var maxerhtml = '';
            if($('#maxer').length>0){
                maxerhtml = $('#maxer').html();
            }
            $.alert("<img style='width:180px' src='"+that.data('src')+
                "' /><p>"+$('.pop_xian').html()+'</p><p><span class=\'main_color\'>'+$('#rater').html()+' '+maxerhtml+'</span>',
                that.data('chushi'),function() {
                clearInterval(getQ);
            });
            if(that.data('lingquid')){
                getQ = setInterval(function () {
                    $.ajax({
                        type: 'GET',
                        url: _APPNAME +'?id=xigua_hk&ac=help&do=check&inajax=1&lingquid='+that.data('lingquid'),
                        dataType: 'xml',
                        success: function (data) {
                            $.hideLoading();
                            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                            var s = data.lastChild.firstChild.nodeValue;
                            console.log(s);
                            if(s>0){
                                clearInterval(getQ);
                                $.ajax({
                                    type: 'post',
                                    url: _APPNAME +'?id=xigua_hs&ac=help&do=fuk&inajax=1&gtype=hk&gid='+that.data('lingquid'),
                                    data: {'formhash':FORMHASH,'money' :s,'note':that.data('title'), shid: that.data('shid')},
                                    dataType: 'xml',
                                    success: function (data) {
                                        $.hideLoading();
                                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                        var s = data.lastChild.firstChild.nodeValue;
                                        tip_common(s);
                                    },
                                    error: function () {}
                                });
                            }else if(s!=0 && s){
                                clearInterval(getQ);
                                alert(s);
                                window.location.reload();
                            }
                        },
                        error: function () {
                            clearInterval(getQ);
                        }
                    });
                }, 5000);
            }
            return false;
        }
        $.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME +'?id=xigua_hk&ac=lingqu&date='+that.data('date')+'&gid='+that.data('gid')+'&inajax=1',
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {
                $.hideLoading();
            }
        });
    });

    $(document).on('click','.usebtn', function () {
        var that = $(this);
        var _id = that.data('id');
        if(that.data('src')){
            $.alert("<img style='width:180px' src='"+that.data('src')+"' /><br>"+$('#usedate'+_id).html()+"<br>"+$('#att'+_id).html()+"<br><span class='main_color'>"+$('#rate'+_id).html()+$('#maxmoney'+_id).html()+"</span>", that.data('chushi'),function() {
            });
            if(that.data('lingquid')){
                getQ = setInterval(function () {
                    $.ajax({
                        type: 'GET',
                        url: _APPNAME +'?id=xigua_hk&ac=help&do=check&inajax=1&lingquid='+that.data('lingquid'),
                        dataType: 'xml',
                        success: function (data) {
                            $.hideLoading();
                            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                            var s = data.lastChild.firstChild.nodeValue;
                            console.log(s);
                            if(s>0){
                                clearInterval(getQ);
                                $.ajax({
                                    type: 'post',
                                    url: _APPNAME +'?id=xigua_hs&ac=help&do=fuk&inajax=1&gtype=hk&gid='+that.data('lingquid'),
                                    data: {'formhash':FORMHASH,'money' :s,'note':that.data('title'), shid: that.data('shid')},
                                    dataType: 'xml',
                                    success: function (data) {
                                        $.hideLoading();
                                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                        var s = data.lastChild.firstChild.nodeValue;
                                        tip_common(s);
                                    },
                                    error: function () {}
                                });
                            }else if(s!=0 && s){
                                clearInterval(getQ);
                                alert(s);
                                window.location.reload();
                            }
                        },
                        error: function () {
                            clearInterval(getQ);
                        }
                    });
                }, 5000);
            }
            return false;
        }else{
            window.location.href=_APPNAME+"?id=xigua_hk&ac=view&date="+that.data('date')+'&gid='+_id;
            return false;
        }
    });

    if($('#driving').length>0){
        var driv = $('#driving'), dnt = 0;
        var drivInterval=setInterval(function () {
            hs_getlocation(function(position){
                $.ajax({
                    type: 'post',
                    url: _APPNAME +'?id=xigua_hs&ac=driving&shid='+driv.data('id')+'&inajax=1&from='+(position.latitude||position.lat) + ','+ (position.longitude||position.lng),
                    data: {'formhash':FORMHASH},
                    dataType: 'xml',
                    success: function (data) {
                        if(null==data){return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        var sary = s.split('|');
                        if(sary[0]=='success'){
                            $('#driving').show().html(sary[1]);
                        }
                        clearInterval(drivInterval);
                    },
                    error: function () { $('#driving').hide(); }
                });
            });
            dnt++;
            if(dnt>2){
                clearInterval(drivInterval);
                $('#driving').show().html('');
            }
        }, 1500);
    }
});

function pop_vi(id, src){
    $('.pop_mask').show();
    $('.pop_vi').removeClass('none').show();
    $('#go2use').on('click', function () {
        $('.pop_mask').hide();
        $('.pop_vi').addClass('none');
        var chushi = $(this).data('chushi');
        var gtq =$('#getQuan');
        gtq.html(gtq.data('use')).data('src', src).data('chushi', chushi).data('lingquid', id);
        gtq.trigger('click');
    });
}

function hk_getparget(){
    var rst = '';
    var $_GET = (function(){
        var url = loadingurl.toString();
        var u = url.split("?");
        if(typeof(u[1]) === "string"){
            u = u[1].split("&");
            var get = {};
            for(var i in u){
                var j = u[i].split("=");
                if(typeof j[0] !=='undefined' && typeof j[1] !=='undefined'){
                    get[j[0]] = j[1];
                }
            }
            return get;
        } else {
            return {};
        }
    })();
    for(var i in $_GET){
        rst += i+"="+$_GET[i]+"&";
    }
    return '?'+rst;
}

function hk_setlist(that, ext){
    var lin = hk_getparget();
    var dlo = that===null ? '': that.data('load');
    if(dlo=='he'){
        $('#list').replaceWith('<ul class="helist mt0" id="list" style="padding-top:0"></ul>');
        $('head').append('<link rel="stylesheet" href="source/plugin/xigua_he/static/he.css?{VERHASH}" />');
    }else if(dlo=='hm1'){
        $('head').append('<link rel="stylesheet" href="source/plugin/xigua_hm/static/hm.css?{VERHASH}" /><script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>');
    }else if(dlo=='hm2'){
        $('head').append('<link rel="stylesheet" href="source/plugin/xigua_hm/static/hm.css?{VERHASH}" /><script src="source/plugin/xigua_hm/static/hm.js?{VERHASH}"></script>');
            $('#list').replaceWith('<div id="list" class="mod-post x-postlist p0">');
    }else if(dlo=='sp'){
        $('#list').replaceWith('<ul class="goodlist gsp" id="list"></ul>');
    }else if(dlo=='pt'){
        $('head').append('<link rel="stylesheet" href="source/plugin/xigua_pt/static/pt.css?{VERHASH}" /><script src="source/plugin/xigua_pt/static/pt.js?{VERHASH}"></script>');
        $('#list').replaceWith('<ul class="goodlist" id="list" style="padding-top:0"></ul>');
    }else{
        $('#list').replaceWith('<div id="list" class="mod-post x-postlist p0"></div>');
    }
    page = 1;lm = false;
    loadingurl = _APPNAME+lin+ext+'&page=';
    if(that!==null){
        that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
    }
    DOAPPEND = 0;
    $.ajax({
        type: 'get',
        url: loadingurl+''+page,
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('#loading-show').addClass('hidden');
            if(!s){
                $('#loading-show').addClass('hidden');
                $('#loading-none').removeClass('hidden');
                setTimeout(function () {
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                }, 300);
                $("#list").html(s);
                page = -1;lm = false;
                return ;
            }
            $("#list").html(s);
            page ++;lm = false;
        },
        error: function() {
        }
    });
}
function getnext(id, name) {
    $('.sub_check a').removeClass('checked').removeClass('main_color');
    $('#sub_check'+id).addClass('checked').addClass('main_color');
    $.ajax({
        type: 'get',
        url: _APPNAME + '?id=xigua_hk&ac=chosecity&name='+name+'&ctid='+id+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('.ajaxbox_cheker').html(s);
        }
    });
}