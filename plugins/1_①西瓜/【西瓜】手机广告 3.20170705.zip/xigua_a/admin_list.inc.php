<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once 'common.php';

if(submitcheck('permsubmit')){
    if($_GET['delete']){
        C::t('#xigua_a#xigua_a')->delete($_GET['delete']);
        cpmsg(lang_a('delete_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin_list&typeid=$typeid", 'succeed');
    }
}

$page = max(1, intval(getgpc('page')));
$lpp   = empty($_GET['lpp']) ? 10 : $_GET['lpp'];
$start_limit = ($page - 1) * $lpp;

$typeid = intval($_GET['typeid']);
$posinfo = C::t('#xigua_a#xigua_a_pos')->fetch($typeid);

$list = C::t('#xigua_a#xigua_a')->get_ads($typeid, $start_limit, $lpp, false, 0);
$count = C::t('#xigua_a#xigua_a')->get_ads_count($typeid);

$multipage = multi($count, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin_list&lpp=$lpp&typeid=$typeid", 0, 10, 0, 1);

if(!isset($_G['cache']['forums'])) {
    loadcache('forums');
}
$forumcache = $_G['cache']['forums'];

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin_list&typeid=$typeid");
showtableheader(lang_a('ad_all').($posinfo['name'] ? ' - '.$posinfo['name'] : ''));
showtablerow('class="header"', array(
), array(
    '&nbsp;',
    lang_a('ad_space'),
    lang_a('name_td'),
    lang_a('start') . ' ~ '. lang_a('end'),
    lang_a('style'),
    lang_a('forum_td'),
    lang_a('addtime'),
    lang_a('setting'),
));

foreach ($list as $index => $item) {
    $typeids[] = $item['type'];
}
$typs = C::t('#xigua_a#xigua_a_pos')->fetch_by_typeids($typeids);


$lang_prompt = lang_a('prompt');
$lang_waibu  = lang_a('waibu');
$lang_addad  = lang_a('addad');
$lang_view  = lang_a('view');
$lang_preview  = lang_a('preview');
$lang_buildin  = lang_a('buildin');
$lang_custom  = lang_a('custom');
foreach ($list as $row) {

    $forum_name = array();
    $fid = 0;
    $fname = '<select style="height:50px;width:200px;" size="10" multiple="multiple">';
    foreach (explode(',', $row['fids']) as $fid) {
        if($fid == -1){
            $fname .= '<option selected disabled>'.lang_a('select_all').'</option>';
        }else if($fid == -2){
            $fname .= '<option selected disabled>'.lang('template', 'homepage').'</option>';
        }else{
            $fname .= '<option selected disabled>'.$forumcache[$fid]['name'].'</option>';
        }
    }
    $fname .= '</select>';

    $srcurl   = $_G['siteurl'].'plugin.php?id=xigua_a&js=1&vid='.$row['advid'];
    showtablerow('', array(
    ), array(
        '<input type="checkbox" name="delete[]" value="'.$row['advid'].'" />',
        "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin_list&typeid={$typs[$row['type']]['id']}'>{$typs[$row['type']]['name']}</a>",
        $row['title'],
        date('Y-m-d', $row['starttime']).'~'.date('Y-m-d', $row['endtime']),
        lang_a($row['style']),
        $fname,
        date('Y-m-d H:i:s', $row['crts']),
        "<a href=\"$srcurl&preview=1\" target=\"_blank\">$lang_preview</a> ".
        '<a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin_add&typeid=$row[type]&vid=$row[advid]"
        .'">'.lang_a('edit').'</a> '.
        <<<HTML
<a href="javascript:;" onclick="prompt('$lang_prompt', '<script src=\'$srcurl\'></script>')">$lang_waibu</a>
HTML
,
    ));
}
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter();/*dis'.'m.tao'.'bao.com*/
showformfooter();/*Dism_taobao_com*/