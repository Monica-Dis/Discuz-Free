<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * Date: 2017/4/20
 * Time: 17:40
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once 'common.php';
if($_GET['vid']){
    $rest = C::t('#xigua_a#xigua_a')->fetch($_GET['vid']);
}else if($_GET['typeid']){
    $rest = C::t('#xigua_a#xigua_a')->fetch_first_by_type($_GET['typeid'], $_GET['showmethod'] ? $_GET['showmethod'] : $config['showmethod']);
}
$param = unserialize($rest['param']);
extract($param);
switch ($rest['style']){
    case 'image':
        $code = <<<HTML
<a href="$link"><img class="xigua_a_img" style="display:block!important;clear:both;width:$width;height:$height;" src="$src" alt="$alt"></a>
HTML;

        break;
    case 'code':
        $code =<<<HTML
<div class="cl" style="width:$width;height: $height;">
    $html
</div>
HTML;

        break;
    case 'text':
        $code = <<<HTML
<a class="cl" style="font-size:$size;" href="$link">$title</a>
HTML;

        break;
}
$title = $rest['title'];
if($code){

switch($_GET['typeid']) {
    case 1:
        $lang_close = lang_a('close');
        if(!getcookie('atype_1'.$config['noshow'])){
            $code = "<div class=\"a_fullindex\" id=\"atype_1\">$code <a class=\"a_closerighttop\">$lang_close <span id=\"a_closerighttop\">{$config['wait']}</span></a></div>";
            dsetcookie('atype_1'.$config['noshow'], 1, $config['noshow']);
        }else{
            $code = '';
        }
        break;
    case 2:
        if(!getcookie('atype_2'.$config['noshow2'])){
            $max = $config['maxwidth2'] ? "style=\"max-width:".($config['maxwidth2'])."%\"" : '';
            $close = $config['closetype2'] == 1 ? '<a class="a_close"></a>': '<a class="a_close2"></a>';
            $code = "<div class=\"a_fullindex\"><div class=\"a_popup\" $max>$code $close </div></div>";
            dsetcookie('atype_2'.$config['noshow2'], 1, $config['noshow2']);
        }else{
            $code = '';
        }
        break;
    case 3:
        if(!getcookie('atype_3'.$config['noshow3'])){
            $code = "<div class=\"a_pr cl\">$code <div><a class=\"a_close a_right\"></a></div></div>";
            dsetcookie('atype_3'.$config['noshow3'], 1, $config['noshow3']);
        }else{
            $code = '';
        }
        break;
    case 9999:
        $height = $rest['height'] ? $rest['height'] : '90';
        $html = "<div class='cl' style='width:100%;height:{$height}px'></div>";
        $appendjs = "$('body').append(\"$html\");";

        $code = "<div class=\"cl\" style=\"position:fixed;bottom:0;left:0;right:0;z-index:999998\">$code <div><a class=\" a_close4\"></a></div></div>";
        break;
}

$code = str_replace('\'','"', trim($code));
$code = preg_replace('/\r\n/', '', $code);
include template('xigua_a:show');

}