<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/aiuxbpkp
 * Date: 2017/6/23
 * Time: 11:15
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}


/**
 * @param string $lang
 * @param int $echo
 * @return bool|mixed|null|string
 */
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
$errors = array(
    UPLOAD_ERR_OK         => lang_a( 'UPLOAD_ERR_OK'),
    UPLOAD_ERR_INI_SIZE   => lang_a( 'UPLOAD_ERR_INI_SIZE'),
    UPLOAD_ERR_FORM_SIZE  => lang_a( 'UPLOAD_ERR_FORM_SIZE'),
    UPLOAD_ERR_PARTIAL    => lang_a( 'UPLOAD_ERR_PARTIAL'),
    UPLOAD_ERR_NO_FILE    => lang_a( 'UPLOAD_ERR_NO_FILE'),
    UPLOAD_ERR_NO_TMP_DIR => lang_a( 'UPLOAD_ERR_NO_TMP_DIR'),
    UPLOAD_ERR_CANT_WRITE => lang_a( 'UPLOAD_ERR_CANT_WRITE'),
    99                    => lang_a( 'ONLY_IMAGE_ALLOW'),
);
function lang_a($lang = '', $echo = 0){
    $ret = lang('plugin/xigua_a', $lang);
    if ($echo) {
        echo $ret;
        return TRUE;
    } else {
        return $ret;
    }
}

function do_upload_a($file_data, $dir = 'source/plugin/xigua_a/cache/')
{
    $return_url = $GLOBALS['returl'];
    $imgtype = array('.jpg', '.jpeg', '.png', '.gif','.JPG', '.JPEG', '.PNG', '.GIF');
    $errors = $GLOBALS['errors'];
    $error = $file_data['error'];
    if($error != UPLOAD_ERR_OK){
        cpmsg($errors[$error], $return_url, 'error');
    }

    $type = '.'.addslashes(strtolower(substr(strrchr($file_data['name'], '.'), 1, 10)));
    $t = array_search($type, $imgtype);
    $filetype = $imgtype[$t];
    $file_data['type'] = strtolower($file_data['type']);
    if($t === false || ! $filetype ||!in_array(strtolower($file_data['type']), array('image/jpg', 'image/jpeg', 'image/gif', 'image/png', 'image/x-png'))) {
        cpmsg($errors[99], $return_url, 'error');
    }

    dmkdir($dir);
    $file_attach = $dir. uniqid(mt_rand(0,999)) . $filetype;
    $saved_file = DISCUZ_ROOT . $file_attach;
    $dst_saved_file = DISCUZ_ROOT . $file_attach.$type;
    $dst_file_attach = $file_attach.$type;

    if(is_uploaded_file($file_data['tmp_name']))
    {
        if(
            @copy($file_data['tmp_name'], $saved_file) ||
            @move_uploaded_file($file_data['tmp_name'], $saved_file)
        ){
            @unlink($file_data['tmp_name']);

            return $file_attach;
        }else{
            cpmsg($errors[UPLOAD_ERR_CANT_WRITE], $return_url, 'error');
        }
    }
    cpmsg($errors[UPLOAD_ERR_NO_FILE], $return_url, 'error');
}


function do_parse_ad($param, $type){
    $code = '';
    switch ($type){
        case 'image':
            extract($param);
            include template('xigua_a:image');
            break;
        case 'code':
            extract($param);
            include template('xigua_a:code');
            break;
        case 'text':
            extract($param);
            include template('xigua_a:text');
            break;
    }
    return $code;
}

global $_G;
if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}

$inwechat     = strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'micromessenger') !== false;

$config = $_G['cache']['plugin']['xigua_a'];