<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * User: yangzhiguo
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}



$sql = <<<SQL
  DROP TABLE pre_xigua_a;

  DROP TABLE pre_xigua_a_pos;

SQL;
runquery($sql);


$finish = TRUE;

function xigua_adelete_all($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xigua_adelete_all($path, $empty);
                } else {
                    @unlink($path);
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}

xigua_adelete_all(DISCUZ_ROOT.'./source/plugin/xigua_a', true);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_a/uninstall.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_a/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_a/upgrade.php');
