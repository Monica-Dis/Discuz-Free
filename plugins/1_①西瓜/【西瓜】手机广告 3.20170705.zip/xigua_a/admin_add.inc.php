<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once 'common.php';
$formheader = "plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin_add";



$typeid = intval($_GET['typeid']);
$posinfo = C::t('#xigua_a#xigua_a_pos')->fetch($typeid);
if(!$posinfo){
    $list = C::t('#xigua_a#xigua_a_pos')->get_all_pos();
    showformheader($formheader, '', 'selectname', 'post');
?>
<table class="tb tb2 fixpadding">
    <tbody>
    <tr>
        <td colspan="2" class="td27"><?php echo lang_a('plzsel')?></td>
    </tr>
    <tr class="noborder">
        <td class="vtop rowform">
            <select name="typeid">
                <?php foreach ($list as $index => $item) {
                    echo "<option value='{$item['id']}'>{$item['name']}</option>";
                } ?>
            </select>
        </td>
        <td class="vtop tips2"> </td>
    </tr>
    <tr>
        <td colspan="2"><input type="submit" class="btn" value="<?php echo lang_a('submit')?>">
        </td>
    </tr>
    </tbody>
</table>
<?php
    showformfooter();/*Dism_taobao_com*/
}else{

require_once libfile('function/forumlist');
$GLOBALS['categoryvalue'] = array();

function getcategory($upid) {
    global $_G;
    foreach($_G['cache']['portalcategory'] as $category) {
        if($category['upid'] == $upid) {
            $GLOBALS['categoryvalue'][] = array($category['catid'], str_repeat('&nbsp;', $category['level'] * 4).$category['catname']);
            getcategory($category['catid']);
        }
    }
}

if(submitcheck('advsubmit')){


    $advid  = intval($_GET['vid']);
    $advnew = $_GET['advnew'];

    $returl = "action=plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin_add&typeid={$advnew['type']}&vid=$advid&".http_build_query($advnew);

    if(empty($advnew['type'])){
        cpmsg(lang_a('empty_type'), $returl, 'error');
    }
    if(empty($advnew['title'])){
        cpmsg(lang_a('dage_biedouwole_title'), $returl, 'error');
    }
    if(empty($advnew['fids'])){
        cpmsg(lang_a('dage_biedouwole_fids'), $returl, 'error');
    }
    if(empty($advnew['starttime'])){
        $advnew['starttime'] = date('Y-m-d');
    }
    if(!empty($advnew['endtime']) && $advnew['starttime']>$advnew['endtime']){
        cpmsg(lang_a('dage_biedouwole_endtime'), $returl, 'error');
    }
    $advnew['starttime'] = strtotime( $advnew['starttime'].' 00:00:00');
    $advnew['endtime']   = strtotime( $advnew['endtime'] .' 23:59:59');

    $style = $advnew['style'];
    switch($style){
        case 'code':
            if(empty($advnew['code']['html'])){
                cpmsg(lang_a('dage_biedouwole_html'), $returl, 'error');
            }
            break;
        case 'text':
            $advnew['text']['title'] = strip_tags($advnew['text']['title'], '<b><i><font><u>');
            break;
        case 'image':
            if($_GET['advnewimage']){
                $advnew[$style]['src'] = trim($_GET['advnewimage']);
            }else if(isset($_FILES['advnewimage'])){
                $advnew[$style]['src'] = do_upload_a($_FILES['advnewimage']);
            }else{
                cpmsg($errors[UPLOAD_ERR_NO_FILE], $returl, 'error');
            }
            break;
    }

    $advnew['fids'] = implode(',', $advnew['fids']);
    $advnew['pids'] = implode(',', $advnew['pids']);
    $advnew['groups'] = implode(',', $advnew['groups']);

    $advnew['param'] = serialize($advnew[$style]);
    $advnew['adcode'] = do_parse_ad($advnew[$style], $style);
    unset($advnew['image']);
    unset($advnew['text']);
    unset($advnew['code']);

    if($advid> 0){
        $advnew['upts'] = TIMESTAMP;
        $result = C::t('#xigua_a#xigua_a')->update($advid, $advnew);
        cpmsg(lang_a('update_success'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin_list", 'succeed');
    }else{
        $advnew['crts'] = TIMESTAMP;
        $advnew['upts'] = TIMESTAMP;
        $result = C::t('#xigua_a#xigua_a')->insert($advnew);
        if($result){
            cpmsg(lang_a('save_success'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin_list", 'succeed');
        }
    }
    cpmsg(lang_a('update_error'), $returl, 'error');

}else{

    $forums = '<select name="advnew[fids][]" size="10" multiple="multiple"><option value="-1">'.lang_a('select_all').'</option><option value="-2">'.lang('template', 'homepage').'</option>'.forumselect(FALSE, 0, 0, TRUE).'</select>';

    loadcache('portalcategory');
    loadcache('grouptype');
    getcategory(0);

    $getcategory[] = array(0, lang_a('select_all'));
    foreach ($GLOBALS['categoryvalue'] as $index => $item) {
        $getcategory[] = array($item[0], $item[1]);
    }


    $getgroups[] = array(0, lang_a('select_all'));
    foreach($_G['cache']['grouptype']['first'] as $gid => $group) {
        $getgroups[] = array($gid, $group['name']);
        if($group['secondlist']) {
            foreach($group['secondlist'] as $sgid) {
                $getgroups[] = array($sgid, str_repeat('&nbsp;', 4).$_G['cache']['grouptype']['second'][$sgid]['name']);
            }
        }
    }

    if($advid = intval($_GET['vid'])){
        $data = C::t('#xigua_a#xigua_a')->fetch($advid);
        $data[$data['style']] = unserialize($data['param']);
        $data['fids']   = explode(',', $data['fids']);
        $data['pids']   = explode(',', $data['pids']);
        $data['groups'] = explode(',', $data['groups']);
        $data['starttime'] = date('Y-m-d', $data['starttime'] );
        $data['endtime']   = date('Y-m-d', $data['endtime'] );
    }

    if(!$data){
        $data = $_GET;
    }


    foreach($data['fids'] as $v) {
        $forums = str_replace('<option value="'.$v.'">', '<option value="'.$v.'" selected>', $forums);
    }
}

    showformheader($formheader, 'enctype');
?>
    <script type="text/javascript" src="static/js/calendar.js"></script>
    <table class="tb tb2 fixpadding">
        <tbody>
        <tr>
            <th colspan="15" class="partition"><?php echo lang_a('add_ad') . $posinfo['name'];?></th>
        </tr>
        <?php showsetting(lang_a('name'), 'advnew[title]', $data['title'], 'text');?>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('forum')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform"><?php echo $forums;?></td>
            <td class="vtop tips2"><?php echo lang_a('forum_tip')?></td>
        </tr>

        <?php
//        showsetting(lang('selportal'), array('advnew[pids][]', $getcategory), $data['pids'], 'mselect');
//        showsetting(lang('selgroup'), array('advnew[groups][]', $getgroups), $data['groups'], 'mselect');
        ?>

        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('ad_start_time')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input type="text" class="txt" name="advnew[starttime]" value="<?php echo $data['starttime']?>" onclick="showcalendar(event, this)">
            </td>
            <td class="vtop tips2"><?php echo lang_a('ad_start_time_tip')?></td>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('ad_end_time')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input type="text" class="txt" name="advnew[endtime]" value="<?php echo !($data['endtime'] == '0000-00-00' &&$data['endtime']) ? $data['endtime']:''; ?>" onclick="showcalendar(event, this)">
            </td>
            <td class="vtop tips2"><?php echo lang_a('ad_end_time_tip')?></td>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('display')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <ul class="nofloat" onmouseover="altStyle(this);">
                    <li class="<?php echo !isset($data['style'])?'checked' : ($data['style'] == 'text' ? 'checked' : ''); ?>"><input class="radio" type="radio" name="advnew[style]" value="text" <?php echo !isset($data['style'])?'checked' : ($data['style'] == 'text' ? 'checked' : ''); ?> onclick="$('style_text').style.display = '';$('style_image').style.display = 'none';$('style_code').style.display = 'none';">&nbsp;<?php echo lang_a('font')?>
                    </li>
                    <li class="<?php echo $data['style'] == 'image' ? 'checked': '';?>"><input class="radio" type="radio" name="advnew[style]" value="image" <?php echo $data['style'] == 'image' ? 'checked': '';?> onclick="$('style_text').style.display = 'none';$('style_image').style.display = '';$('style_code').style.display = 'none';">&nbsp;<?php echo lang_a('image')?>
                    </li>


                    <li class="<?php echo $data['style'] == 'code' ? 'checked' : '';?>">
                        <input class="radio" type="radio" name="advnew[style]" value="code" <?php echo $data['style'] == 'code' ? 'checked' : ''; ?> onclick="$('style_code').style.display = '';$('style_text').style.display = 'none';$('style_image').style.display = 'none';">&nbsp;<?php echo lang_a('code')?>
                    </li>

                </ul>
            </td>
            <td class="vtop tips2"><?php echo lang_a('display_tip')?></td>
        </tr>
        </tbody>

        <tbody id="style_code" style="display:<?php echo $data['style'] == 'code' ? '' : 'none'; ?>">
        <tr>
            <th colspan="15" class="partition"><?php echo lang_a('html')?></th>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('html1')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <textarea rows="6" ondblclick="textareasize(this, 1)" onkeyup="textareasize(this, 0)" onkeydown="textareakey(this, event)" name="advnew[code][html]" id="advnew[code][html]" cols="50" class="tarea"><?php echo $data['code']['html']?></textarea></td>
            <td class="vtop tips2"><?php echo lang_a('html1_tip')?></td>
        </tr>


        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('code_width')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input name="advnew[code][width]" value="<?php echo $data['code']['width']?>" type="text" class="txt" id="codewidth"></td>
            <td class="vtop tips2"><?php echo lang_a('code_width_tip')?></td>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('code_height')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input name="advnew[code][height]" value="<?php echo $data['code']['height']?>" type="text" class="txt" id="codeheight"></td>
            <td class="vtop tips2"><?php echo lang_a('code_height_tip')?></td>
        </tr>


        </tbody>

        <tbody id="style_text" style="display:<?php echo !isset($data['style'])?'' : ($data['style'] == 'text' ? '' : 'none'); ?>">
        <tr>
            <th colspan="15" class="partition"><?php echo lang_a('font_ad')?></th>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('font1_ad')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <div id="htmlQ2" class="txt html" contenteditable="true"></div>
                <input id="htmlQ2_v" name="advnew[text][title]" value="<?php echo str_replace('"', '\'',$data['text']['title'])?>" type="hidden">
                <script type="text/javascript">$('htmlQ2').innerHTML="<?php echo str_replace('"', '\'',$data['text']['title'])?>";sethtml('htmlQ2')</script>
                <div id="htmlQ2_c_menu" style="display: none;">
                    <iframe id="htmlQ2_c_frame" src="" frameborder="0" width="210" height="148" scrolling="no"></iframe>
                </div>
            </td>
            <td class="vtop tips2"><?php echo lang_a('font1_ad_tip')?></td>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('font_link')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input name="advnew[text][link]" value="<?php echo $data['text']['link']?>" type="text" class="txt"></td>
            <td class="vtop tips2"><?php echo lang_a('font_link_tip')?></td>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('font_size')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input name="advnew[text][size]" value="<?php echo $data['text']['size']?>" type="text" class="txt"></td>
            <td class="vtop tips2"><?php echo lang_a('font_size_tip')?></td>
        </tr>
        </tbody>
        <tbody id="style_image" style="display:<?php echo $data['style'] == 'image' ? '': 'none';?>">
        <tr>
            <th colspan="15" class="partition"><?php echo lang_a('image_ad')?></th>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('image1_ad')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input id="filedq_0" style="display:<?php echo isset($data['image']) ? 'none' : '';?>" name="advnewimage" value="" type="file" class="txt uploadbtn marginbot">
                <input id="filedq_1" style="display:<?php echo isset($data['image']) ? '' : 'none';?>" name="TMPadvnewimage" value="<?php echo $data['image']['src']?>" type="text" class="txt marginbot">
                <br>
                <a id="filedq_0a" style="font-weight:bold" href="javascript:;" onclick="$('filedq_1a').style.fontWeight = '';this.style.fontWeight = 'bold';$('filedq_1').name = 'TMPadvnewimage';$('filedq_0').name = 'advnewimage';$('filedq_0').style.display = '';$('filedq_1').style.display = 'none'"><?php echo lang_a('upload')?></a>
                &nbsp;
                <a id="filedq_1a" style="" href="javascript:;" onclick="$('filedq_0a').style.fontWeight = '';this.style.fontWeight = 'bold';$('filedq_0').name = 'TMPadvnewimage';$('filedq_1').name = 'advnewimage';$('filedq_1').style.display = '';$('filedq_0').style.display = 'none'"><?php echo lang_a('url')?></a>
                <script type="text/javascript">
                    <?php if($data['image']){?>
                    $('filedq_1a').click();
                    <?php }?>
                </script>
                <?php if($data['image']){?>
                    <img style="max-width:800px;" src="<?php echo $data['image']['src']?>" height="<?php echo $data['image']['height']?>" width="<?php echo $data['image']['width']?>" />
                <?php }?>
            </td>
            <td class="vtop tips2"><?php echo lang_a('image1_ad_tip')?></td>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('imagelink1_ad')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input name="advnew[image][link]" value="<?php echo $data['image']['link']?>" type="text" class="txt"></td>
            <td class="vtop tips2"><?php echo lang_a('imagelink1_ad_tip')?></td>
        </tr>

        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('image_alt')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input name="advnew[image][alt]" value="<?php echo $data['image']['alt']?>" type="text" class="txt"></td>
            <td class="vtop tips2"><?php echo lang_a('image_alt_tip')?></td>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('image_width')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input name="advnew[image][width]" value="<?php echo $data['image']['width']?>" type="text" class="txt" id="imagewidth"></td>
            <td class="vtop tips2"><?php echo lang_a('image_width_tip')?></td>
        </tr>
        <tr>
            <td colspan="2" class="td27"><?php echo lang_a('image_height')?></td>
        </tr>
        <tr class="noborder">
            <td class="vtop rowform">
                <input name="advnew[image][height]" value="<?php echo $data['image']['height']?>" type="text" class="txt" id="imageheight"></td>
            <td class="vtop tips2"><?php echo lang_a('image_height_tip')?></td>
        </tr>
        </tbody>
        <tbody>
        <tr>
            <td colspan="2"><input type="submit" class="btn" name="advsubmit" value="<?php echo lang_a('submit')?>">
                <input name="vid" type="hidden" value="<?php echo $data['advid']?>">
            </td>
        </tr>
        </tbody>
    </table>

<input type="hidden" name="advnew[type]" value="<?php echo $typeid; ?>">
<input type="hidden" name="typeid" value="<?php echo $typeid; ?>">
<?php
showformfooter();/*Dism_taobao_com*/

}