<?php exit('xigua_a');?>
{block code}
<!--{if $link}--><a href="$link"><!--{/if}--><img class="xigua_a_img" style="display:block!important;clear:both;width:<!--{if $width}-->$width<!--{else}-->100%<!--{/if}-->;height:$height;" src="$src" alt="$alt"><!--{if $link}--></a><!--{/if}-->
{/block}
