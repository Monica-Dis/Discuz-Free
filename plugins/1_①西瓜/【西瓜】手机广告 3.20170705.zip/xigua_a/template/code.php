<?php exit('xigua_a');?>
{block code}
<div class="cl" style="width:$width;height: $height;">
    $html
</div>
{/block}