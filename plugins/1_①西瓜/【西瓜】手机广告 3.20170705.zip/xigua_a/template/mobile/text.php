<?php exit('xigua_a');?>
{block code}
<!--{if $link}-->
<a class="cl" style="font-size:$size;" href="$link">$title</a>
<!--{else}-->
<div class="cl" style="font-size:$size;">$title</div>
<!--{/if}-->
{/block}