<?php exit; ?>
<!--{if $_GET['preview']}-->
<!doctype html>
<html lang="en">
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport"
          content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>$title</title>
    <link rel="stylesheet" href="source/plugin/xigua_a/static/common.css?{VERHASH}"/>
</head>
<body>
<!--{/if}-->

<!--{if $_GET['js']}-->
document.write('<link rel="stylesheet" href="source/plugin/xigua_a/static/style.css?{VERHASH}"/>{$code}<script src="source/plugin/xigua_a/static/style.js?{VERHASH}"></script>');
<!--{if $appendjs}-->
setTimeout(function(){
$appendjs
}, 300);
<!--{/if}-->
<!--{else}-->
<link rel="stylesheet" href="source/plugin/xigua_a/static/style.css?{VERHASH}"/>
{$code}
<script src="source/plugin/xigua_a/static/style.js?{VERHASH}"></script>
<!--{/if}-->

<!--{if $_GET['preview']}-->
</body>
</html>
<!--{/if}-->