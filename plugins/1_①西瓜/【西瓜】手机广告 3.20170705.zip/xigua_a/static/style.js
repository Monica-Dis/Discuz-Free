var type_1_close = $('#a_closerighttop');
if(type_1_close.length>0 && typeof a_auto == 'undefined'){
    var a_auto = setInterval(function(){
        if(type_1_close.text() <1){
            clearInterval(a_auto);
            $('#atype_1').fadeOut();
            return;
        }
        type_1_close.text(parseInt(type_1_close.text())-1);
    }, 1000);
    type_1_close.parent().on('click', function(){
        $('#atype_1').fadeOut();
    });
}
$(document).on('click', '.a_close', function () { $(this).parent().parent().fadeOut();});
$(document).on('click', '.a_close2', function () { $(this).parent().parent().fadeOut();});
$(document).on('click', '.a_close4', function () { $(this).parent().parent().fadeOut();});