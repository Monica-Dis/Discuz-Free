<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2015/6/16
 * Time: 11:42
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}


$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_a` (
 `advid` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
 `available` tinyint(1) NOT NULL DEFAULT '0',
 `type` int(10) NOT NULL DEFAULT '0',
 `displayorder` tinyint(3) NOT NULL DEFAULT '0',
 `title` varchar(255) NOT NULL DEFAULT '',
 `fids` text NOT NULL,
 `pids` text NOT NULL,
 `groups` text NOT NULL,
 `starttime` int(10) unsigned NOT NULL DEFAULT '0',
 `endtime` int(10) unsigned NOT NULL DEFAULT '0',
 `style` varchar(20) NOT NULL,
 `param` text NOT NULL,
 `adcode` text NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 PRIMARY KEY (`advid`),
 KEY `type` (`type`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_xigua_a_pos` (
 `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
 `name` varchar(255) NOT NULL,
 `type` varchar(20) NOT NULL,
 `hook` varchar(50) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `name` (`name`)
) ENGINE=MyISAM;


SQL;
runquery($sql);

$sql = <<<SQL
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(1, '$installlang[ist1]', 'core', 'global_header_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(2, '$installlang[ist2]', 'core', 'global_header_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(3, '$installlang[ist3]', 'core', 'global_header_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(4, '$installlang[ist4]', 'core', 'forumdisplay_thread_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(5, '$installlang[ist5]', 'core', 'index_top_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(6, '$installlang[ist6]', 'core', 'index_middle_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(7, '$installlang[ist7]', 'core', 'forumdisplay_top_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(8, '$installlang[ist8]', 'core', 'forumdisplay_bottom_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(9, '$installlang[ist9]', 'core', 'viewthread_fastpost_button_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(10, '$installlang[ist10]', 'core', 'post_bottom_mobile ');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(11, '$installlang[ist11]', 'core', 'viewthread_top_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(12, '$installlang[ist12]', 'core', 'viewthread_bottom_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(13, '$installlang[ist13]', 'core', 'viewthread_posttop_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(14, '$installlang[ist14]', 'core', 'viewthread_postbottom_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(15, '$installlang[ist15]', 'core', 'logging_bottom_mobile');
INSERT INTO `pre_xigua_a_pos` (`id`, `name`, `type`, `hook`) VALUES(16, '$installlang[ist16]', 'core', 'global_footer_mobile');
SQL;

runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_a/discuz_plugin_xigua_a_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_a/install.php');
@unlink(DISCUZ_ROOT . 'source/plugin/xigua_a/upgrade.php');
$finish = TRUE;


