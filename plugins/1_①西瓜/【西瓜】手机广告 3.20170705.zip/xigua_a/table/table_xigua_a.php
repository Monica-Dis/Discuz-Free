<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_a extends  discuz_table
{
    /**
     *
     */
    public function __construct()
    {
        $this->_table = 'xigua_a';
        $this->_pk = 'advid';

        parent::__construct();
    }

    public function fetch_first_by_type($type, $method = 1)
    {
        global $_G;
        if(!$_REQUEST['fid'] && $_G['fid']){
            $_REQUEST['fid'] = $_G['fid'];
        }

        $wheresql = '';
        if($fid = intval($_REQUEST['fid'])){
            $wheresql .= " AND (FIND_IN_SET($fid, fids) OR FIND_IN_SET(-1, fids) ) ";
        }else if($_GET['forumlist'] == 1){
            $wheresql .= " AND FIND_IN_SET(-2, fids)";
        }else{
            $wheresql .= " AND FIND_IN_SET(-1, fids)";
        }
        if($method == 1){
            $data = DB::fetch_first("SELECT * FROM %t WHERE `type`=%s AND starttime<=%s AND endtime>=%s $wheresql order by rand() LIMIT 1",     array($this->_table, $type, TIMESTAMP,TIMESTAMP ));
        }else{
            $data = DB::fetch_first("SELECT * FROM %t WHERE `type`=%s AND starttime<=%s AND endtime>=%s $wheresql ORDER BY advid DESC LIMIT 1", array($this->_table, $type, TIMESTAMP,TIMESTAMP ));
        }
        return $data;
    }

    /**
     * @param $start
     * @param $lpp
     *
     * @return array
     */
    public function get_ads($typeid, $start, $lpp, $allowmethod = false, $method = 1)
    {
        global $_G;
        if(!$_REQUEST['fid'] && $_G['fid']){
            $_REQUEST['fid'] = $_G['fid'];
        }
        $wheresql = ' WHERE 1 ';
        if($typeid){
            $wheresql .= " AND type=".intval($typeid);
        }
        if($fid = intval($_REQUEST['fid'])){
            $wheresql .= " AND (FIND_IN_SET($fid, fids) OR FIND_IN_SET(-1, fids) ) ";
        }else if($_GET['forumlist'] == 1){
            $wheresql .= " AND FIND_IN_SET(-2, fids)";
        }else{
            if($allowmethod){
                $wheresql .= " AND FIND_IN_SET(-1, fids)";
            }
        }
        if($allowmethod){
            $timestamp = TIMESTAMP;
            $od = 'advid';
            if($method == 1){
                $od = 'rand()';
            }
            $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table) . " $wheresql AND starttime<=$timestamp AND endtime>=$timestamp ORDER BY $od DESC" . DB::limit($start, $lpp));
        }else{
            $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table) . " $wheresql ORDER BY advid DESC" . DB::limit($start, $lpp));
        }
        return $result;
    }
    /**
     * @return mixed
     */
    public function get_ads_count($typeid)
    {
        $wheresql = ' WHERE 1 ';
        if($typeid){
            $wheresql .= " AND type=".intval($typeid);
        }
        $result = DB::result_first('SELECT count(*) FROM '.DB::table($this->_table) . $wheresql);
        return $result;
    }
}