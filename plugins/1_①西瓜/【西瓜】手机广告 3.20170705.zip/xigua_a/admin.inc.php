<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once 'common.php';
$formheader = "plugins&operation=config&do=$pluginid&identifier=xigua_a&pmod=admin";
$action = ADMINSCRIPT.'?action='.$formheader;

if(submitcheck('permsubmit') ){

    if($_GET['new']){
        foreach ($_GET['new'] as $index => $item) {
            if($item = trim($item)){
                C::t('#xigua_a#xigua_a_pos')->insert(array('name' => $item, 'type' => 'custom'));
            }
        }
    }

    if($_GET['row']){
        foreach ($_GET['row'] as $id => $name) {
            if($name = trim($name)){
                C::t('#xigua_a#xigua_a_pos')->update($id, array('name' => $name));
            }
        }
    }

    if($_GET['delete']){
        foreach ($_GET['delete'] as $id) {
            if($id = intval($id)){
                if(C::t('#xigua_a#xigua_a')->fetch_first_by_type($id)){
                    cpmsg(lang_a('do_error'), "action=$formheader", 'error');
                }
                C::t('#xigua_a#xigua_a_pos')->delete($id);
            }
        }
    }
    cpmsg(lang_a('save_success'), "action=$formheader", 'succeed');
}

$all_pos = C::t('#xigua_a#xigua_a_pos')->get_all_pos();

showformheader($formheader);
showtableheader(lang_a('ad_space'));
showtablerow('class="header"',array(),array(
    lang_a('del'),
    lang_a('ad_space'),
    lang_a('style'),
    lang_a('hook'),
    lang_a('caozuo'),
));
$lang_prompt = lang_a('prompt');
$lang_waibu  = lang_a('waibu');
$lang_addad  = lang_a('addad');
$lang_view  = lang_a('view');
$lang_preview  = lang_a('preview');
$lang_buildin  = lang_a('buildin');
$lang_custom  = lang_a('custom');
foreach ($all_pos as $k => $v){

    $srcurl   = $_G['siteurl'].'plugin.php?id=xigua_a&js=1&typeid='.$v['id'];
    $operation =<<<HTML
<a href="{$action}_add&typeid={$v['id']}">$lang_addad</a>

<a href="{$action}_list&typeid={$v['id']}">$lang_view</a>

<a href="$srcurl&preview=1" target="_blank">$lang_preview</a> 

<a href="javascript:;" onclick="prompt('$lang_prompt', '<script src=\'$srcurl\'></script>')">$lang_waibu</a>
HTML;

    if($v['type']=='core'){
        $adname = $v['name'];
        $select = "<input type='checkbox' class='checkbox' disabled />";
        $typename = $lang_buildin;
    }else{
        $adname = "<input type=\"text\" name=\"row[{$v['id']}]\" value=\"{$v['name']}\" />";
        $select = "<input type='checkbox' class='checkbox' name='delete[]' value='{$v['id']}' />";
        $typename = $lang_custom;
    }


    showtablerow('', array(), array(
        $select,
        $adname,
        $typename,
        $v['hook'],
        $operation,
    ));
    
    
}


$addnew = lang_a('addnew');
echo <<<HTML
<tr>
    <td>&nbsp;</td>
    <td colspan="99"><div><a href="javascript:;" onclick="addrow(this, 0)" class="addtr">$addnew</a></div></td>
</tr>
HTML;


showsubmit('permsubmit', 'submit', 'select_all', '',$multipage);
showtablefooter();/*dis'.'m.tao'.'bao.com*/
showformfooter();/*Dism_taobao_com*/
?>

<script>
    var rowtypedata = [
        [
            [1,'&nbsp;'],
            [1,'<input type="text" name="new[]" value="" />'],
            [2, '<?php echo $lang_custom; ?>']
        ]
    ];
</script>

