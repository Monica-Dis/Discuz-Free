<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class mobileplugin_xigua_a
{
    public static function global_header_mobile()
    {
        if(strpos($_GET['id'], 'dzapp')!==false){
            return '';
        }
        global $_G;
        if($_G['inajax']){
            return '';
        }
        $adv  = '';
        $adv .= "<script src=\"{$_G['siteurl']}plugin.php?id=xigua_a&typeid=1&js=1&fid=$_G[fid]\"></script>";
        $adv .= "<script src=\"{$_G['siteurl']}plugin.php?id=xigua_a&typeid=2&js=1&fid=$_G[fid]\"></script>";
        $adv .= "<script src=\"{$_G['siteurl']}plugin.php?id=xigua_a&typeid=3&js=1&fid=$_G[fid]\"></script>";
        return $adv;
    }

    public function global_footer_mobile()
    {
        if(strpos($_GET['id'], 'dzapp')!==false){
            return '';
        }
        global $_G;
        if($_G['inajax']){
            return '';
        }
        $adv  = '';
        $adv .=$this->fetch_adcode_by_typeid(16);
        $query['forumlist'] = $_GET['forumlist'];
        if(CURSCRIPT=='forum' && !$_REQUEST['tid'] && !$_REQUEST['fid']){
            $query['forumlist'] = 1;
        }
        $query = http_build_query($query);
        $adv .= "<script src=\"{$_G['siteurl']}plugin.php?$query&id=xigua_a&typeid=9999&js=1&fid=$_G[fid]\"></script>";
        return $adv;
    }

    public function fetch_adcode_by_typeid($typeid)
    {
        if(strpos($_GET['id'], 'dzapp')!==false){
            return '';
        }
        global $_G;
        if($_G['inajax']){
            return '';
        }

        global $_G;
        $config = $_G['cache']['plugin']['xigua_a'];
        if($config['allowjs']){
            $html = "<script src=\"{$_G['siteurl']}plugin.php?id=xigua_a&typeid=$typeid&js=1&fid=$_G[fid]\"></script>";
        } else{
            $rest = C::t('#xigua_a#xigua_a')->fetch_first_by_type($typeid, $config['showmethod']);
            $html = $rest['adcode'];
        }
        return $html;
    }

    public function fetch_adcode_by_typeid_array($typeid, $step = 1)
    {
        if(strpos($_GET['id'], 'dzapp')!==false){
            return '';
        }
        include_once 'common.php';
        global $_G;
        $config = $_G['cache']['plugin']['xigua_a'];
        if($_G['inajax']){
            return '';
        }

        $page = intval($_GET['page']);
        if(!$page){
            $page = 1;
        }
        $_G['tpp'] = ($_G['tpp']?$_G['tpp'] : 10)-1;

        if($config['step']<1){
            $config['step'] = 1;
        }
        $step = $step==1 ? $step : $config['step'];


        $range = range(0, $_G['tpp'], $step);
        $ret = array();

        $advs =  C::t('#xigua_a#xigua_a')->get_ads($typeid, ($page - 1) * $_G['tpp'], count($range), 1, $config['showmethod']);

        foreach ($range as $index => $item) {
            $ret[$item] = $advs[$index]['adcode'];
        }
        return $ret;
    }
}

class mobileplugin_xigua_a_forum extends mobileplugin_xigua_a
{

    public function forumdisplay_thread_mobile()
    {
        return $this->fetch_adcode_by_typeid_array(4, 0);
    }

    public function forumdisplay_top_mobile()
    {
        return $this->fetch_adcode_by_typeid(7);
    }

    public function forumdisplay_bottom_mobile()
    {
        return $this->fetch_adcode_by_typeid(8);
    }

    public function index_top_mobile()
    {
        return $this->fetch_adcode_by_typeid(5);
    }

    public function index_middle_mobile()
    {
        return $this->fetch_adcode_by_typeid(6);
    }

    public function viewthread_fastpost_button_mobile(){
        return $this->fetch_adcode_by_typeid(9);
    }
    public function post_bottom_mobile (){
        return $this->fetch_adcode_by_typeid(10);
    }

    public function viewthread_top_mobile (){
        return $this->fetch_adcode_by_typeid(11);
    }
    public function viewthread_bottom_mobile (){
        return $this->fetch_adcode_by_typeid(12);
    }

    public function viewthread_posttop_mobile (){  //array
        return $this->fetch_adcode_by_typeid_array(13, 1);
    }
    public function viewthread_postbottom_mobile (){  //array
        return $this->fetch_adcode_by_typeid_array(14, 1);
    }
}

class mobileplugin_xigua_a_member extends mobileplugin_xigua_a_forum{


    public function logging_bottom_mobile(){
        if(strpos($_GET['id'], 'dzapp')!==false){
            return '';
        }
        return $this->fetch_adcode_by_typeid(15);
    }
}

class plugin_xigua_a_portal extends mobileplugin_xigua_a_forum
{

}
class mobileplugin_xigua_a_portal extends plugin_xigua_a_portal{

}
