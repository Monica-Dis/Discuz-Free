<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_dh:header}-->
<!--{eval $city = $_GET[city]}-->
<!--{eval $province = $_GET[province]}-->
<!--{eval $dist = $_GET[dist]}-->
<div class="page__bd">
    <!--{if $hy['share_pic']}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$hy['share_pic']" /></div><!--{/if}-->
    <!--{if IN_MAGAPP}--><style>.nav_expand_panel{position:absolute;height:auto!important;}.nav_expand_panel .weui-flex__item{height:auto;overflow:hidden!important;}</style><!--{/if}-->

    <!--{template xigua_hb:common_nav}-->
    <!--{if !$hide_nav}--><div class="cl fix_float_fix"></div><!--{else}--><div class="cl fix_float_fix"></div><style>.fix_float{top:0}.nav_expand_panel{top:2.45rem}</style><!--{/if}-->

    <div class="weui-navbar fix_float">
        <a data-id="1" class="dist_nav weui-navbar__item">
            <span>$distname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <a data-id="2" class="dist_nav weui-navbar__item">
            <span>$catname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <a data-id="3" class="dist_nav weui-navbar__item">
            <span>$orderby_list[$orderby]<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
    </div>
    <div class="dist_show">
        <div id="dist_show_1" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="first_check border_bfull <!--{if !$_GET[province]}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=$hyid&province=&city=&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $dist0 $v}-->
                        <li class="first_check border_bfull <!--{if $_GET[province]==$v[name]}-->checked main_color<!--{eval $city_id=$v['id'];}--><!--{/if}-->" data-id="$v[id]"><a>$v[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="weui-flex__item checked">
                    <!--{loop $dist0 $k $v}-->
                    <ul class="sub_cheker <!--{if $_GET[province]!=$v['name']}-->none<!--{else}-->checked<!--{/if}-->" id="sub_cheker_$v[id]">
                        <li class="sub_check border_bfull"><a data-href="$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=$hyid&province={$v[name]}&city=&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}" class="choose color-red">{lang xigua_dh:quan}{$v[name]}<i class="iconfont icon-coordinates_fill f14 "></i></a></li>
                        <!--{loop $v[child] $vv}-->
                        <li class="sub_check border_bfull <!--{if $city==$vv[name]&&$_GET[city]}-->checked main_color autotrigger<!--{/if}-->"><a data-href="$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=$hyid&province=$v[name]&city=$vv[name]&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}" id="sub_check{$vv[id]}" data-id="$vv[id]" onclick="dh_getnext($vv[id], '{$vv[name]}','$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=$hyid&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}')">$vv[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                    <!--{/loop}-->
                </div>
                <div class="weui-flex__item checked" id="ajaxbox"> <ul class="ajaxbox_cheker"></ul> </div>
            </div>
        </div>
        <div id="dist_show_2" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="first_cat_check border_bfull <!--{if !$hyid}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=&province=$province&city=$city&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $cat_tree $k $v}-->
                        <!--{if !$v[adlink]}-->
                        <li class="first_cat_check border_bfull <!--{if $hyid==$v[id]||$pid==$v[id]}-->checked main_color<!--{/if}-->"<!--{if $v[sub]}--> data-id="$v[id]"<!--{/if}-->><a <!--{if !$v[sub]}--> href="$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=$v[id]&province=$province&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}"<!--{/if}-->>$v[name]</a></li>
                        <!--{/if}-->
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="weui-flex__item checked">
                    <!--{loop $cat_tree $k $v}-->
                    <ul class="sub_cat_cheker <!--{if !($hyid==$v[id]||$pid==$v[id])}-->none<!--{/if}-->" id="sub_cat_cheker_$v[id]">
                        <li class="sub_cat_check border_bfull"><a <!--{if $hyid==$v[id]}-->class="checked main_color"<!--{/if}--> href="$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=$v[id]&province=$province&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $v[sub] $vv}-->
                        <li class="sub_cat_check border_bfull"><a <!--{if $hyid==$vv[id]}-->class="checked main_color"<!--{/if}--> href="$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=$vv[id]&province=$province&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">$vv[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <div id="dist_show_3" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <!--{loop $orderby_list $_ok $_ol}-->
                        <!--{if $_ok == 'near'}-->
                        <li class="<!--{if $orderby==$_ok}-->checked main_color<!--{/if}--> border_bfull"><a data-href="$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=$hyid&province=$province&city=$city&dist=$dist&orderby=$_ok&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}" id="nearcat" href="javascript:;">$_ol</a></li>
                        <!--{else}-->
                        <li class="<!--{if $orderby==$_ok}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=$hyid&province=$province&city=$city&dist=$dist&orderby=$_ok&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">$_ol</a></li>
                        <!--{/if}-->
                        <!--{/loop}-->
                    </ul>
                </div>

            </div>
        </div>
    </div>

<form class="x_form hy_form" style="" id="search" method="get" action="$SCRITPTNAME">
    <input type="hidden" name="id" value="xigua_dh">
    <input type="hidden" name="ac" value="index">
    <!--{loop $_GET $lk $loopin}-->
    <!--{if in_array($lk, array('keyword', 'hyid','st','idu','formhash'))}-->
    <!--{eval continue;}-->
    <!--{/if}-->
    <input type="hidden" name="$lk" value="$_GET[$lk]">
    <!--{/loop}-->
    <input type="hidden" name="st" value="$_GET[st]">
    <input type="hidden" name="idu" value="$_GET[idu]">
    <input name="keyword" class="x_logo_input inputdh" type="text" value="{$_GET['keyword']}" placeholder="$dh_config[indexkey]" x-webkit-speech="">
    <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
</form>
<!--{eval
$adwhere = array();
$adwhere[] = 'types=\'cat\'';
if($_GET['hyid']):
    $adwhere[] = '( FIND_IN_SET('.intval($_GET['hyid']).' , catids) OR FIND_IN_SET(-1, catids) )';
else:
    $adwhere[] = '( FIND_IN_SET(-1, catids) )';
endif;
$index_list =  C::t('#xigua_dh#xigua_dh_index')->list_by_where($adwhere);
$newindex_list = array();
if($index_list):
    foreach ($index_list as $index => $item):
        $newindex_list[$item['style']][] = $item;
    endforeach;
endif;
}-->
<!--{loop $newindex_list $_k $_v}-->
<!--{if $_k==99}-->
<div class="swipe cl" data-speed="5000">
    <div class="swipe-wrap">
        <!--{loop $_v $__k $__v}-->
        <div><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $_v $__k $__v}-->
            <li <!--{if $__k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{else}-->
<!--{eval
if(!$_k):
    $_k = 4;
endif;
$tmpp = array_chunk($_v, $_k);
}--><!--{loop $tmpp $__k $tmpp2}-->
<!--{eval $counttmpp2 = count($tmpp2);}-->
<ul class="inedxicon cl">
    <!--{loop $tmpp2 $__k $__v}-->
    <li style="width:{echo 100/$counttmpp2;}%"><a href="$__v[adlink]"><img src="$__v[icon]"></a></li>
    <!--{/loop}-->
</ul>
<!--{/loop}-->
<!--{/if}-->
<!--{/loop}-->
<div id="list" class="mod-post x-postlist pt0"></div>
<!--{template xigua_hb:loading}-->

</div>

<script>
    var loadingurl = window.location.href+'&ac=myshop_li&inajax=1&page=';scrollto = 1;

    $(document).on('click','.choose', function () {
        var that = $(this), c_jmpurl = '';
        if(that.data('href')){ c_jmpurl = that.data('href'); }
        if(that.data('ctid')){ c_jmpurl = $('#sub_check'+that.data('ctid')).data('href'); }
        window.location.href= c_jmpurl;
    });
    $(document).on('click','.dist_check', function () {$('.dist_check').removeClass('checked').removeClass('main_color'); $(this).addClass('checked').addClass('main_color');});
    $(document).on('click','.dist_nav', function () {if($('.autotrigger').length>0){$('.autotrigger').find('a').trigger('click');}});
    $(document).on('click','.first_check', function () {$('.ajaxbox_cheker').html('');});
    $(document).on('click','#nearcat', function () {
        var that = $(this);
        var href= that.data('href');
        dh_getlocation(function (position) {
            var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
            window.location.href= href+ '&lat='+lat+'&lng='+lng;
        });
    });
</script>
<!--{eval $tabbar=0;$dh_tabbar=1;}-->
<!--{template xigua_dh:footer}-->