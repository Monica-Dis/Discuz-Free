<?php exit('xxxxx');?>
<!--{template xigua_dh:header}-->
<script>
    $.alert('$msg', function () {
        window.history.go(-1);
    });
    setTimeout(function () {
        window.history.go(-1);
    }, 3000);
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_dh:footer}-->