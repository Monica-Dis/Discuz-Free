<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $cat_tree}--><div class="hylist">
    <!--{loop $cat_tree $cat}-->
    <!--{if $cat[adlink]}-->
    <!--{eval continue;}-->
    <!--{/if}-->
    <div>
        <div class="weui-grids weui-grids-min">
            <a href="javascript:;" class="weui-grid w100 hy_jump" data-id="$cat[id]">
                <div class="hytit weui-flex">
                    <img src="{$cat[icon]}" />
                    <span class="f16">{$cat[name]}</span>
                </div>
            </a>
        </div>
        <div class="weui-grids weui-grids-min">
        <!--{eval $cat[sub] = array_values($cat[sub]);}-->
        <!--{loop $cat[sub] $k $suncat}-->
            <a href="javascript:;" class="weui-grid hy_jump" style="width:{echo intval(100/$dh_config[hy_num])}%" data-id="$suncat[id]">
                <div class="pr">
                    <span class="f16">$suncat[name]</span> <!--{if $dh_config[hy_shownum]}--><em class="numshow" style="background:{echo $cat_nusm[$suncat[id]]>0? $dh_config[hy_color] :'#dcdcdc'}">{echo intval($cat_nusm[$suncat[id]])}</em><!--{/if}-->
                </div>
            </a>

            <!--{if $k && ($k+1)%$dh_config[hy_num]==0}-->
        </div>
<div class="weui-grids weui-grids-min"><!--{/if}-->
        <!--{/loop}--></div>
    </div>
    <!--{/loop}-->

</div><!--{/if}-->