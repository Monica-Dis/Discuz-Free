<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_hb:common_header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-cells weui-cells_checkbox mt0">
        <form action="$SCRITPTNAME?id=xigua_dh&ac=getloc&do=dhtc" method="post" id="form" enctype="multipart/form-data">
            <input type="hidden" name="formhash" value="{FORMHASH}">
            <!--{loop $vips $k $v}-->
            <!--{eval $i++;}-->
            <label class="weui-cell weui-check__label" for="s{$v[id]}">
                <div class="weui-cell__hd">
                    <input type="radio" class="weui-check" name="form[viptype]" value="{$v[id]}" id="s{$v[id]}" <!--{if $i==1}-->checked="checked"<!--{/if}--> >
                    <i class="weui-icon-checked"></i>
                </div>
                <div class="weui-cell__bd">
                    <p>{$v[name]}</p>
                    <p class="f12">{$v[desc]}</p>
                </div>
            </label>
            <!--{/loop}-->
            <div class="fix-bottom">
                <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hb:ljgm}">
            </div>
        </form>
    </div>
    <!--{if $mytcan}-->
    <div class="weui-cells__tips">
        <p>{lang xigua_hb:ndqysy} <em class="main_color">{$mytcan[used]}</em> {lang xigua_dh:cchdh}, {lang xigua_hb:sy} <em class="main_color">{$mytcan[total]}</em> {lang xigua_hb:c}</p>
        <p>{lang xigua_hb:lastts} <em class="main_color">{echo date('Y-m-d H:i:s', $mytcan[endts])}</em></p>
    </div>
    <!--{/if}-->
</div>
<script>
</script>
<!--{eval $tabbar = 0;}-->
<!--{template xigua_hb:common_footer}-->