<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval include DISCUZ_ROOT.'source/plugin/xigua_dh/include/c_shopli.php'}--><!--{loop $list $v}-->
<div class="dh_item" id="li_{$v['shid']}">
    <div class="sp_thumb dh_jump" data-id="{$v['shid']}">
        <img src="{$v['logo']}" onerror="this.error=null;this.src='{$dh_config[indeximg]}'">
    </div>
    <div class="sp_main dh_jump" data-id="{$v['shid']}">
        <div class="sp_content">
            <div class="weui-flex">
                <h3 class="weui-flex__item">{$v['name']} <!--{if $v[dig]}--><em class="is-star dig_tag">{lang xigua_dh:dig}</em> <!--{/if}-->
                    <!--{if $v[end]}--><em class="hs_tag"><i class="iconfont icon-jubao c9 f12"> {lang xigua_dh:guoqi}</i></em><!--{/if}-->
                </h3>
            </div>
            <!--{if !$v['addr']||$dh_config[hidetel]}-->
            <!--{eval $hys = explode(' ', trim($v[hangye]));}-->
            <p class="sp_desc sp_tag">
                <!--{loop $hys $hy1}-->
                <span class="mod-feed-tag b-color12">{$hy1}</span>
                <!--{/loop}-->
            </p>
            <!--{/if}-->
            <!--{if !$dh_config[hidetel] && $v[price_view]<=0}-->
            <p class="sp_desc color-gray">
                <i class="iconfont icon-dianhua1 f12"></i>{echo $v['telnames'][0] ? ' '.$v['telnames'][0].': ' : ' '}{$v['tels'][0]}
            </p>
            <!--{/if}-->
            <!--{if $_GET[is_my]}-->
            <p class="sp_desc c9"><!--{if !$v[display]}-->{lang xigua_dh:daishen}<!--{elseif 0==$v[endts]}--> {lang xigua_dh:weizhifu}<!--{else}--><b>{$vips[$v[viptype]][name]}</b> <!--{if $vips[$v[viptype]][days]!='9999'}-->{$v[endts_u]}{lang xigua_dh:guoqi}<!--{else}--> {lang xigua_dh:yjsx}<!--{/if}--><!--{/if}-->
            </p><!--{/if}-->
            <!--{if $v['addr']}-->
            <div class="weui-flex">
                <p class="weui-flex__item color-gray"><i class="iconfont icon-mudedi vm f13 pr-1"></i>{$v['addr']}</p>
            </div>
            <!--{/if}-->
        </div>
    </div>
    <!--{if $_GET[is_my]}-->
    <a class="weui-btn weui-btn_mini whbtn" href="javascript:;" data-id="{$v['shid']}" data-title="{$v['name']}" onclick="return managesh(this);">{lang xigua_dh:caozuo}</a>
    <!--{/if}-->
    <!--{if $viewtype =='new'}-->
    <!--{elseif $viewtype =='near' && $v[lng]}-->
    <span class="li_location tag-gray" data-lat="$v[lat]" data-lng="$v[lng]">{$v[distance]}</span>
    <!--{elseif $viewtype =='guanzhu'}-->
    <span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]">{echo hb_trans($v[follow])}{lang xigua_dh:guanzhu}</span>
    <!--{elseif $viewtype =='fenxiang'}-->
    <span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]">{echo hb_trans($v[shares])}{lang xigua_dh:fenxiang}</span>
    <!--{else}-->
    <!--{if !$_GET[is_my]}--><span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]">{echo hb_trans($v[views])}{lang xigua_dh:view}</span><!--{/if}-->
    <!--{/if}-->
    <!--{if !$_GET[is_my]}-->
    <!--{if $v[price_view]<=0}-->
    <a class="main_color boda" href="tel:{$v['tels'][0]}"><i class="iconfont icon-unie607 sp_tel"></i></a>
    <!--{else}-->
    <a class="main_color boda" href="javascript:;" onclick="dh_paytel($v['shid'],'$v[price_view]','$v[hangye_id2]');"><i class="iconfont icon-unie607 sp_tel"></i></a>
    <!--{/if}-->
    <!--{/if}-->
</div>
<!--{/loop}-->