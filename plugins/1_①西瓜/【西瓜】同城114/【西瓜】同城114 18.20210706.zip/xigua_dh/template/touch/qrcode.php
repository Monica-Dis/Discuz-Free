<?php exit('xxxxxxx');?>
<!--{eval $shot_img = $v[logo];}-->
<!--{eval
$shot_file = 'source/plugin/xigua_dh/cache/'.md5($shot_img).'.png';
if(strpos($shot_img, $_G[siteurl])===false):
    if(!is_file(DISCUZ_ROOT.$shot_file)):
        file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($shot_img));
    endif;
    $shot_img = $shot_file;
endif;
}-->
<div id="shot" style="position:fixed;bottom:-100000px">
    <div class="shot_in main_bg" style="padding-top: 1px;padding-bottom: 1px;">
        <div class="mpc">
            <div class="mpc_body">
            </div><div class="weui-flex qreidl" style="background:{$dh_config[bcolor]}">
                <div class="mr15">
                    <!--{eval $hb_currenturl = hb_currenturl();}-->
                    <img src="{eval echo dh_qrcode_make($shid, $hb_currenturl.'&idu='.$v[uid].$urlext, $shot_img);}"  class="qrblock" />
                </div>
                <div class="weui-flex__item" style="height:90px!important;">
                    <p class="f18">$navtitle</p>
                    <p class="f14 mt8">{lang xigua_dh:casm}</p>
                </div>
            </div>
        </div>
    </div>
</div>