<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_dh:header}-->
<style>.chip-row ul.swiper-wrapper>li{max-width: calc(100vw - 134px);}</style>
<div class="page__bd"><!--{if $indeximg}--><div style="width:0;height:0;display:none"><img src="$indeximg" /> </div><!--{/if}-->
<!--{if IN_PROG && $ac=='index'}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if $ac=='index' && $config[showheader]}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if !$hide_nav}-->
    <header class="x_header bgcolor_11 cl  weui-flex f15" <!--{if $config[intopindex]}-->style="background:transparent!important;position:absolute"<!--{/if}-->>
    <!--{if $_G['cache']['plugin']['xigua_st']['showfz']}-->
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_dh&mobile=2");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
<!--{else}-->
    <a class="z x_logo" href="$SCRITPTNAME?id=xigua_hb"><!--{if strpos($config['logo'],'/')!==false}--><img src="$config[logo]" /> <!--{else}--><span style="margin:0 .75rem">$config[logo]</span><!--{/if}--></a><!--{/if}-->
    <form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
        <!--{loop $_GET $lk $loopin}-->
        <input type="hidden" name="$lk" value="$_GET[$lk]">
        <!--{/loop}-->
        <input type="hidden" name="id" value="xigua_dh">
        <input type="hidden" name="ac" value="hangye">
        <input type="hidden" name="st" value="$_GET[st]">
        <input type="hidden" name="idu" value="$_GET[idu]">
        <input name="keyword" class="x_logo_input inputdh" type="text" value="{$_GET['keyword']}" placeholder="$dh_config[indexkey]" x-webkit-speech="" <!--{if $config[intopindex]}-->style="background-color: rgba(255,255,255,.92)"<!--{/if}-->>
        <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
    </form>
    </header>
<!--{if !$no_header_fix}-->
    <div class="x_header_fix" <!--{if $config[intopindex]&&$ac=='index'}-->style="display:none"<!--{/if}-->></div>
<!--{/if}-->
<!--{/if}-->
<!--{if $topnavslider}-->
<div class="swipe cl">
    <div class="swipe-wrap">
        <!--{loop $topnavslider $slider}-->
        <div>$slider</div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $topnavslider $k $slider}-->
            <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{/if}-->
<!--{if $jing_list}-->
<nav class=" nav-list cl swipe">
    <div class="swipe-wrap">
        <div>
            <ul class="cl">
                <!--{loop $jing_list $k $n}-->
                <!--{if $k && $k%10==0}-->
            </ul>
        </div>
        <div>
            <ul class="cl">
                <!--{/if}-->
                <li>
                    <a href="{echo $n['adlink'] ? $n['adlink'] : "$SCRITPTNAME?id=xigua_dh&ac=hangye&hyid=".$n[id].$urlext}">
                        <span>
                            <img src="$n['icon']"/>
                        </span>
                        <em class="m-piclist-title">{$n['name']}</em>
                    </a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position position1">
            <!--{loop $jing_count $k $v}-->
            <li {if $k==0} class="current" {/if}></li>
            <!--{/loop}-->
        </ul>
    </nav>
</nav>
<!--{/if}-->
<!--{template xigua_dh:index_pic}-->
<!--{if $newest}-->
<div class="dh_toutiao">
    <div class="chip-row">
        <div class="toutiao"><i class="iconfont icon-tongzhi f14 "></i>{$dh_config[toutitle]}</div>
        <div class="toutiao-slider swiper-container" id="newsSlider">
            <ul class="swiper-wrapper">
                <!--{loop $newest $v}-->
                <li class="swiper-slide">{lang xigua_dh:gx}
                    <a href="$SCRITPTNAME?id=xigua_dh&ac=view&shid=$v[shid]{$urlext}"> <img src="{$v[logo]}" onerror="this.error=null;this.src='source/plugin/xigua_dh/static/img/new.png'" />
                        <em class="main_color">{$v[name]}</em> {lang xigua_dh:cgrz}</a></li>
                <!--{/loop}-->
            </ul>
        </div>
        <a class="toutiao toutiao_in main_bg" href="$SCRITPTNAME?id=xigua_dh&ac=join&from=index{$urlext}">{lang xigua_dh:wyrz}</a>
    </div>
</div>
<!--{/if}-->
<div class="weui-cells fixbanner before_none">
    <div class="weui-navbar weui-banner nobg fixbanner_in">
        <a href="javascript:;" class="weui-navbar__item <!--{if $_GET[nav]=='hy'}-->weui_bar__item_on <!--{/if}--> dhlistcat" data-save="nav=hy" data-query="viewtype=hy"><span>{lang xigua_dh:fenlei}</span></a>
        <a href="javascript:;" class="weui-navbar__item <!--{if $_GET[nav]=='ho'}-->weui_bar__item_on <!--{/if}--> dhlistcat" data-save="nav=ho" data-query="viewtype=hot"><span>{lang xigua_dh:hot}</span></a>
        <a href="javascript:;" class="weui-navbar__item <!--{if $_GET[nav]=='nw'}-->weui_bar__item_on <!--{/if}--> dhlistcat" data-save="nav=nw" data-query="viewtype=new"><span>{lang xigua_dh:newin}</span></a>
        <a href="javascript:;" class="weui-navbar__item <!--{if $_GET[nav]=='ne'}-->weui_bar__item_on <!--{/if}--> dhlistcat" data-save="nav=ne" data-query="viewtype=near" data-needgeo="1" id="near_cat"><span>{lang xigua_dh:near}</span></a>
    </div>
</div>
<div id="list" class="mod-post x-postlist pt0"></div>
<!--{template xigua_hb:loading}-->
</div>
<script>
<!--{if $_GET[nav]=='nw'}-->
loadingurl = window.location.href+'&ac=myshop_li&viewtype=new&inajax=1&page=';
<!--{elseif $_GET[nav]=='ne'}-->
var loadingurl =window.location.href+'&ac=myshop_li&viewtype=near&inajax=1&page=';
<!--{elseif $_GET[nav]=='hy'}-->
loadingurl = window.location.href+'&ac=myshop_li&viewtype=hy&inajax=1&page=';
<!--{else}-->
loadingurl = window.location.href+'&ac=myshop_li&inajax=1&page=';
<!--{/if}-->
scrollto = 1;
<!--{if $_GET[nav]=='ne'}-->setTimeout(function () {
$('#near_cat').trigger('click');
if (typeof wx !== 'undefined') {
    wx.ready(function () {
        $('#near_cat').trigger('click');
    });
}
}, 200);<!--{/if}-->
</script>
<!--{eval $dh_tabbar=1;}-->
<!--{template xigua_dh:footer}-->