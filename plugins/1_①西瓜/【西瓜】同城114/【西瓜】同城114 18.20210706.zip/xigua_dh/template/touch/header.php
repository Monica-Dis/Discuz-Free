<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}--><link rel="stylesheet" href="source/plugin/xigua_dh/static/css/dh.css?{VERHASH}" />
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked,.float_btn{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}
.light_box a.main_color:after,.index_bd,.tsbtn,.tsbtn_mini{background:$config[maincolor]}.main_border{;border-color:$config[maincolor]!important}
.lq_mine{background:{echo dh_hex2rgb($config[maincolor], .05);};border:1px solid $config[maincolor]}.tiing{background-color:$config[maincolor]}
.dh_toutiao .chip-row .toutiao_in{position:absolute;right:.6rem;top:.5rem;z-index:1}.dh_toutiao .chip-row{position:relative}
</style>
<script>var HB_INWECHAT = '{HB_INWECHAT}', PLZALLOW = '{lang xigua_dh:plzallow}', gengduodongtai = '{lang xigua_dh:gengduodongtai}', guanzhu_sj = '{lang xigua_dh:guanzhu_sj}', yiguanzhu = '{lang xigua_dh:yiguanzhu}', jiaguanzhu='{lang xigua_dh:jiaguanzhu}', mkey = '$dh_config[mkey]', GOOGLE = '{$dh_config[google]}', HP_YZ='{lang xigua_dh:yz}',HP_YSC = '{lang xigua_dh:ysc}', HP_YFZ = '{lang xigua_dh:yfz}', HP_WXH = '{lang xigua_dh:wx}'; var lockIng = 0, SCCG='{lang xigua_hb:sccg}',DH_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>