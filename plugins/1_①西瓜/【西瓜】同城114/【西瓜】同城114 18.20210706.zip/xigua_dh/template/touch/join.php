<?php exit('xigua_dh');?>
<!--{template xigua_dh:header}-->
<!--{eval
if($old_data):
    $jsar = $jspr = array();
    $arr = $hyobj->arr;
    foreach ($arr as $index => $item) :
        $jsar[$item['id']] = $item;
        $jspr[$item['pid']] = $item;
    endforeach;
    if($_hy = $jsar[$old_data['hangye_id2']]):
        if($_hy['pid']):
            $default_hy = diconv($jsar[$_hy['pid']]['name'].' '. $_hy['name'], 'utf-8', CHARSET);
        else:
            $default_hy = diconv($_hy['name'].' '. $jspr[$_hy['id']]['name'], 'utf-8', CHARSET);
        endif;
    endif;
endif;
$cannewmap = !IN_PROG && $_G['cache']['plugin']['xigua_dh']['newmap'];
if($cannewmap):
    if($_GET['latng']):
        list($getlat, $getlng) = explode(',', $_GET['latng']);
        $getlat = floatval($getlat);
        $getlng = floatval($getlng);
        foreach (array('name','addr', 'city', 'province', 'district', 'street', 'street_number') as $index => $item) :
            $_GET[$item] = diconv($_GET[$item], 'UTF-8', CHARSET);
        endforeach;
        $GLOBALS['nojson'] = 1;
        $allcity = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_name($_GET['city']);
        $allcity1 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($allcity[0]['id']);
        $_GET['province'] = DB::result_first('select name from %t where id=%d', array('xigua_hb_district', $allcity[0]['upid']));
        foreach ($allcity1 as $index => $item)  :
            if(strpos($_GET['addr'], $item['name'])!==false):
                $_GET['district'] = $item['name'];
                break;
            endif;
        endforeach;
        if($_GET['name']==lang_hb('wdwz', 0)):
            $_GET['name'] = '';
        endif;
        $_GET['name'] = str_replace(array($_GET['province'], $_GET['city'], $_GET['district']),'', $_GET['name']);
        $_GET['addr'] = str_replace(array($_GET['province'], $_GET['city']),'', $_GET['addr']).$_GET['name'];
        $backurl = urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_dh&ac=join$urlext");
        unset($_GET['referer']);
        unset($_GET['name']);
    else:
        $backurl = urlencode(hb_currenturl());
    endif;
    $mk = $_G['cache']['plugin']['xigua_dh']['mkey'];
    $zom = $_G['cache']['plugin']['xigua_dh']['indexzoom'];
    $newmapurl = "https://apis.map.qq.com/tools/locpicker?search=1&type=0&policy=1&zoom=$zom&backurl=$backurl&key=$mk&referer=myapp";
endif;
}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd">
    <!--{if stripos($_SERVER['HTTP_USER_AGENT'], 'Android') && HB_INWECHAT}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <form action="$SCRITPTNAME?id=xigua_dh&ac=join&mobile=2{$urlext}" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >
        <input type="hidden" name="manage" value="{$_GET['manage']}">
        <input type="hidden" name="shid" value="{$old_data['shid']}">
        <input type="hidden" id="lat" name="form[lat]" value="{echo $getlat ? $getlat: $old_data['lat']}">
        <input type="hidden" id="lng" name="form[lng]" value="{echo $getlng ? $getlng: $old_data['lng']}">
        <input type="hidden" id="province" name="form[province]" value="{echo $_GET[province] ? $_GET[province] : $old_data['province']}">
        <input type="hidden" id="city" name="form[city]" value="{echo $_GET[city] ? $_GET[city] : $old_data['city']}">
        <input type="hidden" id="district" name="form[district]" value="{echo $_GET[district] ? $_GET[district] : $old_data['district']}">
        <input type="hidden" id="street" name="form[street]" value="{echo $_GET[street] ? $_GET[street] : $old_data['street']}">
        <input type="hidden" id="street_number" name="form[street_number]" value="{echo $_GET[street_number] ? $_GET[street_number] : $old_data['street_number']}">

        <div class="weui-cells__title">{lang xigua_dh:jbxx}

            <a class="y main_color" href="$SCRITPTNAME?id=xigua_dh&ac=my114{$urlext}">{lang xigua_dh:wd114}</a>
        </div>
        <div class="weui-cells ">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_dh:shname}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[name]" placeholder="{lang xigua_dh:plztitle}" value="{$old_data[name]}">
                </div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_dh:sjdq}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[diqu]" id="diqu" type="text" value="{echo $old_data[province] ? $old_data[province].' '.$old_data[city].' '.$old_data[district] :'';}" placeholder="{lang xigua_dh:plzsjdq}">
                </div>
                <div class="weui-cell__ft" id="needdiqu"></div>
            </div>
            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_dh:sjdz}</label>
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" name="form[addr]" type="text" value="{echo $_GET[addr] ? $_GET[addr] : $old_data[addr]}" placeholder="{lang xigua_dh:qdjdw}" readonly>
                </div>
                <div class="weui-cell__ft">
                    <!--{if $cannewmap}-->
                    <a href="$newmapurl" class="weui-vcode-btn" type="button">{lang xigua_dh:dingwei}</a>
                    <!--{else}-->
                    <button class="weui-vcode-btn" id="openlocation" type="button">{lang xigua_dh:dingwei}</button>
                    <!--{/if}-->
                </div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_dh:suoshuhangye}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[hangye]" id="hangye" type="text" value="$default_hy" placeholder="{lang xigua_dh:plzsuoshuhangye}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <textarea class="weui-textarea" name="form[jieshao]" placeholder="{lang xigua_dh:plzjieshao}" rows="3">{$old_data[jieshao]}</textarea>
                </div>
            </div>
        </div>

        <div class="weui-cells__title">{lang xigua_dh:lxfs}</div>
        <div class="weui-cells lxfs">

            <!--{if $dh_config[allowqr]}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_dh:qr}</p>
                            <div class="weui-uploader__info">{lang xigua_dh:plzqr}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[qr]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[qr])">
                                    <input type="hidden" name="form[qr][]" value="$old_data[qr]"/>
                                    <div class="weui-uploader__file-content">
                                        <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box">
                                <!--{if HB_INWECHAT && $config[multiupload]}-->
                                <a class="weui-uploader__input" data-name="form[qr]"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[qr]" type="file">
                                <!--{/if}-->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <!--{/if}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_dh:sjwxh}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[wxhao]" placeholder="{lang xigua_dh:plzsjwxh}" value="{$old_data[wxhao]}">
                </div>
            </div>

            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label"><!--{if $old_data[telnames][0]}-->$old_data[telnames][0]<!--{else}-->{lang xigua_dh:tel}<!--{/if}--></label>
                    <input class="weui-input" type="hidden" name="form[telname][]" placeholder="{lang xigua_dh:tel}" value="{$old_data[telnames][0]}">
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" type="tel" name="form[tel][]" placeholder="{lang xigua_dh:plzlxdh}" value="{$old_data[tels][0]}">
                </div>
                <div class="weui-cell__ft"><div class="weui-vcode-btn lxfs_btn"><i class="iconfont icon-tianjia f22"></i></div></div>
            </div>

            <!--{if $old_data[tels][1]}-->
            <!--{eval array_shift($old_data[tels]);}-->
            <!--{eval array_shift($old_data[telnames]);}-->
            <!--{loop $old_data[tels] $tk $te}-->
            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label"><!--{if $old_data[telnames][$tk]}-->$old_data[telnames][$tk]<!--{else}-->{lang xigua_dh:tel}<!--{/if}--></label>
                    <input class="weui-input" type="hidden" name="form[telname][]" placeholder="{lang xigua_dh:tel}" value="{$old_data[telnames][$tk]}">
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" type="tel" name="form[tel][]" placeholder="{lang xigua_dh:plzlxdh}" value="{$te}">
                </div>
                <div class="weui-cell__ft"><div class="weui-vcode-btn lxfs_btn1"><i class="iconfont icon-jianshao2 f22 color-red"></i></div></div>
            </div>
            <!--{/loop}-->
            <!--{/if}-->


            <div class="weui-cell weui-cell_vcode copyfrom none">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_dh:tel}</label>
                    <input class="weui-input" type="hidden" name="form[telname][]" placeholder="{lang xigua_dh:tel}" value="">
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" type="tel" name="form[tel][]" placeholder="{lang xigua_dh:plzlxdh}" value="">
                </div>
                <div class="weui-cell__ft"><div class="weui-vcode-btn lxfs_btn1"><i class="iconfont icon-jianshao2 f22 color-red"></i></div></div>
            </div>
            <script>
                $(document).on('click','.lxfs_btn', function () {
                    $('.lxfs').append('<div class="weui-cell weui-cell_vcode">'+$('.copyfrom').html()+'</div>');
                });
                $(document).on('click','.lxfs_btn1', function () {
                    $(this).parent().parent().remove();
                });
            </script>
        </div>



        <div class="weui-cells__title">{lang xigua_dh:sjzs}</div>
        <div class="weui-cells weui-cells_form">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_dh:shlogo}</p>
                            <div class="weui-uploader__info">{lang xigua_dh:plzshlogo}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[logo]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[logo])"><input type="hidden" name="form[logo][]" value="$old_data[logo]"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box">
                                <!--{if HB_INWECHAT && $config[multiupload]}-->
                                <a class="weui-uploader__input" data-name="form[logo]"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[logo]" type="file">
                                <!--{/if}-->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <div class="weui-uploader">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">{lang xigua_dh:shalbum}</p>
                        <div class="weui-uploader__info">{echo str_replace('n', $dh_config['maximg'], lang_dh('zuiduozhao',0))}</div>
                    </div>
                    <div class="weui-uploader__bd">
                        <ul class="weui-uploader__files" data-max="{$dh_config['maximg']}" data-maxtip="{echo str_replace('n', $dh_config['maximg'], lang_dh('zuiduozhao',0))}">
                            <!--{loop $old_data[album] $img}-->
                            <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                            <!--{/loop}-->
                        </ul>
                        <div class="weui-uploader__input-box">
                            <!--{if HB_INWECHAT && $config[multiupload]}-->
                            <a class="weui-uploader__input" data-name="form[album]" data-multi="1"></a>
                            <!--{else}-->
                            <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                            <!--{/if}-->
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
        <!--{if !$old_data}-->
        <div class="weui-cells__title">{lang xigua_dh:rzlx}</div>
<!--{eval include DISCUZ_ROOT.'source/plugin/xigua_dh/function_join.php';}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/taocan.css?{VERHASH}" />
<style>
.car-type .car-year-season{background-color:$config[maincolor];}
.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}
.car-type .type-item-active:after{border-color:$config[maincolor]}
.car-type .type-item-active {background:{echo hb_hex2rgb($config[maincolor], 0.06)}}
.car-type .type-item{float: left;width: calc((100vw - 50px) / 3);margin-right: 10px;margin-top: 10px;height: 72px;}
.car-type .type-item:nth-child(3n){margin-right:0}
.car-type .type-item-box, .car-type .type-item-box-last {display:block}
.car-type{padding-top:5px}
</style>
        <div id="dftvip" class="cl car-type">
            <div class="type-item-box">
                <!--{loop $join_prices $___k $___v}-->
                <label for="s{$___k}" class="type-item J_ping <!--{if $___k==0}-->type-item-active<!--{else}-->type-item-gray<!--{/if}-->">
                    <input type="radio" class="none typevip" name="form[viptype]" value="{$___v[title]}" id="s{$___k}" <!--{if $___k==0}-->checked="checked"<!--{/if}-->>
                    <div class="type-title">{echo _dh_days_format($___v[type])}</div>
                    <div class="car-sku-year cl">
                        <div class="type-discount">
                            <span class="car-price">{$___v[price]}</span><span class="car-unit">{lang xigua_hb:yuan}</span>
                        </div>
                    </div>
                    <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
                </label>
                <!--{/loop}-->
            </div>
        </div>
        <script>
            $(document).on('click','.J_ping', function () {
                $('.J_ping').addClass('type-item-gray').removeClass('type-item-active');
                $(this).addClass('type-item-active').removeClass('type-item-gray');
            });
            $('.J_ping:first-child').trigger('click');
            $('.J_ping:first-child').find('.typevip').trigger('click');
        </script>

        <div class="weui-cells none">

            <div class="weui-cell weui-cell_switch none">
                <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_dh:wyzd}</label></div>
                <div class="weui-cell__bd"><span class="c9 f14">yxzjsjzsl</span></div>
                <div class="weui-cell__ft" style="height:32px">
                    <input class="weui-switch" type="checkbox" name="form[dig]" id="digmode" onclick="return dh_digmode();" value="0">
                </div>
            </div>

            <div class="weui-cell weui-cell_access none digmode">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_dh:zdyxq}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input dig_ctrl" name="form[digsize]" type="text" data-values="0" value="" placeholder="{lang xigua_dh:qxzzdsj}" readonly="">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
        </div><!--{/if}-->

        <label class="weui-agree mt10" onclick='$("#agree__text").popup();'>
            <input id="weuiAgree" type="checkbox" checked="checked" disabled readonly class="weui-agree__checkbox">
            <span class="weui-agree__text"> {lang xigua_hb:agree}<a href="javascript:void(0);" >{lang xigua_hb:xiyi1}</a> </span>
        </label>
        <div id="agree__text" class="weui-popup__container">
            <div class="weui-popup__overlay"></div>
            <div class="weui-popup__modal">
                <div class="fixpopuper">
                    <article class="weui-article">
                        <h1>{lang xigua_hb:xiyi}</h1>
                        <section>
                            $dh_config[xieyi]
                        </section>
                    </article>
                    <div class="footer_fix"></div>
                    <div class="bottom_fix"></div>
                </div>
                <div class="fix-bottom">
                    <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:woyi}</a>
                </div>
            </div>
        </div>


        <div class="fix-bottom mt10" style="position:relative">
            <!--{if $old_data}-->
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_dh:baocun}">
            <!--{else}-->
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_dh:ljrz}">
            <!--{/if}-->
        </div>
    </form>
    <div class="footer_fix"></div>
</div>

<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>

<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div class="masker" onclick='$(".choose_ctrl").select("close");$(".dig_ctrl").select("close")'></div>

<script> +function($){  $.rawCitiesData = $cityjson; }($);</script>
<!--{if $_G['cache']['plugin']['xigua_dh']['mkey']}--><script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$_G['cache']['plugin']['xigua_dh']['mkey']}"></script><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_dh']['baidusdk']}--><script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak={$_G['cache']['plugin']['xigua_dh']['baidusdk']}"></script><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_dh']['google']}--><script src="https://maps.googleapis.com/maps/api/js?key={$_G['cache']['plugin']['xigua_dh'][google]}&sensor=false"></script><!--{/if}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script>
    function dh_digmode() {
        if($('#digmode:checked').length){
            $('.digmode').removeClass('none');
        }else{
            $('.digmode').addClass('none');
        }
        return true;
    }
    var itar = [], itar1=[];
    <!--{loop $join_prices $vvv}-->itar.push({title: '{$vvv[title]}', value:'{$vvv[type]}'});<!--{/loop}-->
    <!--{loop $dig_prices $vvv}-->itar1.push({title: '{$vvv[title]}', value:'{$vvv[type]}'});<!--{/loop}-->

    $(".choose_ctrl").select({
        title: "{lang xigua_dh:ruzhutype}",
        items: itar,
        onOpen: function () { $('.masker').fadeIn(); },
        beforeClose: function () { $('.masker').fadeOut(300); return true; },
        onChange: function(d) {
            if(d.values!=='undefined' && d.values>0){
                console.log(d.values);
            }
        }
    });
    $(".dig_ctrl").select({
        title: "{lang xigua_dh:qxzzdyxq}",
        items: itar1,
        onOpen: function () { $('.masker').fadeIn(); },
        beforeClose: function () { $('.masker').fadeOut(300); return true; },
        onChange: function(d) {
            if(d.values!=='undefined' && d.values>0){
                console.log(d.values);
            }
        }
    });

    $("#hangye").cityPicker({
        title: "{lang xigua_dh:plzhy}",
        showDistrict: false,
        onChange: function (picker, values, displayValues) {
            console.log(values);
        }
    });
    $(document).on('click','.dompdel', function () {
        var that = $(this);
        $.confirm({
            title: '{lang xigua_dh:qr}',
            text: '{lang xigua_dh:qrsc}',
            onOK: function () {$.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME +'?id=xigua_dh&ac=dompdel&mpid='+that.data('id')+'&inajax=1',
                    data:{formhash:FORMHASH},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });

    });
</script>
<!--{eval $tabbar=0;$dh_tabbar=0;}-->
<!--{template xigua_dh:footer}-->
<!--{template xigua_dh:enter_up}-->
<!--{eval
$_key = 'hscityIdist'.intval($_GET['st']);
loadcache($_key);
$jsary1 = $_G['cache'][$_key]['variable'][1];
if(!json_encode($jsary1) || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000)) :
    $GLOBALS['nojson'] = 0;
    $dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
    $list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
    C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
    $jsary1 = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    foreach ($dist0 as $index => $item) :
        C::t('#xigua_hb#xigua_hb_district')->empty_child();
        $dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
    endforeach;
    savecache($_key, array('variable' => array($dist0, $jsary1), 'expiration' => TIMESTAMP));
endif;
$jsary1 = array_values($jsary1);
$pickercityjson = json_encode($jsary1);
$pickerdefault = diconv($jsary1[0]['name'].' '. $jsary1[0]['sub'][0]['name'].' '.$jsary1[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
}-->
<script> +function($){  $.rawCitiesData1 = $pickercityjson; }($); var DFTFIELD = '$pickerdefault';</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/picker.js?_{VERHASH}" charset="utf-8"></script>
<script>
    $("#diqu").cityPicker1({
        title: "{lang xigua_dh:plzsjdq}",
        onChange: function (picker, values, displayValues) {
            console.log(displayValues);
            $('#needdiqu').html("<input type=\"hidden\" name=\"form[province]\" value=\""+displayValues[0]+"\">\n" +
                "<input type=\"hidden\" name=\"form[city]\" value=\""+displayValues[1]+"\">\n" +
                "<input type=\"hidden\" name=\"form[district]\" value=\""+displayValues[2]+"\">");
        }
    });
</script>
<!--{template xigua_hb:autosave}-->