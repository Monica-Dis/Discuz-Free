<?php exit('xigua_dh');?>
<script src="source/plugin/xigua_hb/static/dist/cropper.min.js?{VERHASH}"></script>
<script>
    var loadingImg ='<li id="loadingimg" class="weui-uploader__file weui-uploader__file_status"><div class="weui-uploader__file-content"><img src="source/plugin/xigua_hb/static/img/loading.gif"/></div></li>';
    var photoct = $('#photo');
    var imgpop = $('#popctrl');var uploadinput_obj;
    var uploadinput = $('.weui-uploader__input');
    var boxer = null, filedname = '', ICnt = {echo intval($__k);}, canmulti = 0, max_upload_num = 10, max_upload_maxtip = '';
    $(function () {

        var URL = window.URL || window.webkitURL;
        var blobURL;
        var file;
        <!--{if HB_INWECHAT&&$config[multiupload]}-->
        canmulti = 1;
        uploadinput.on("touchstart", function () {
            uploadinput_obj = $(this);
                boxer = $(this).parent().prev();
                max_upload_num = boxer.data('max');
                max_upload_maxtip = boxer.data('maxtip');
                if(boxer.find('li').length>=max_upload_num){
                    $.toast(max_upload_maxtip, 'error');
                    return false;
                }
                wx_upload();
                return false;
        });
        <!--{elseif IN_MAGAPP}-->
        uploadinput.on('touchstart', function(){
            uploadinput_obj = $(this);
            boxer = $(this).parent().prev();
            max_upload_num = boxer.data('max');
            max_upload_maxtip = boxer.data('maxtip');
            if(boxer.find('li').length>=max_upload_num){
                $.toast(max_upload_maxtip, 'error');
                return false;
            }
            magPicPick();
            return false;
        });
        <!--{else}-->
uploadinput.on("change", function () {
            uploadinput_obj = $(this);
            boxer = $(this).parent().prev();
            if(boxer.data('max')){
                if(boxer.children('li').length>=boxer.data('max')){
                    $.toast(boxer.data('maxtip'), 'error');
                    return false;
                }
            }
            filedname = $(this).data('name');
            photoct.cropper('destroy').cropper({
                minContainerHeight: 320,
                autoCropArea:1
            });
            var files = this.files;
            if (!photoct.data('cropper')) {
                return;
            }
            if (files && files.length) {
                file = files[0];
                if (/^image\/\w+$/.test(file.type)) {
                    blobURL = URL.createObjectURL(file);
                    photoct.one('built.cropper', function () {
                        URL.revokeObjectURL(blobURL);
                    }).cropper('reset').cropper('replace', blobURL);
                    uploadinput_obj.val('');
                    imgpop.popup();
                } else {
                    $.toptip('Please choose an image file.', 'error');
                }
            }
        });
        <!--{/if}-->

        $('.pub_funcbar a').each(function () {
            var btn = $(this);
            var mtd = btn.attr('data-method');
            btn.on('click', function () {
                if (mtd == 'destroy') {
                } else if (mtd == 'confirm') {
                    result = photoct.cropper('getCroppedCanvas');
                    photo = result.toDataURL('image/jpeg');
                    var img=photo.split(',')[1];
                    img=window.atob(img);
                    var ia = new Uint8Array(img.length);
                    for (var i = 0; i < img.length; i++) {
                        ia[i] = img.charCodeAt(i);
                    }
                    var bfile = new Blob([ia], {type:"image/jpeg"});


                    compress(bfile, function(TMP){
                        dh_doupload(TMP, typeof cropCallback!=='undefined'?cropCallback:null);
                    });

                    if(boxer.data('only')){ boxer.html(loadingImg); }else{ boxer.append(loadingImg); }
                } else {
                    var opt = btn.attr('data-option');
                    photoct.cropper(mtd, opt);
                }
            });
        });



        <!--{if HB_INWECHAT&&$config[multiupload]}-->
        canmulti = 1;
        $(document).on('touchstart','.center_upload__input', function () {
            uploadinput_obj = $(this);

            ICnt ++;
            var _that = $(this).parent().parent().parent().parent().parent();
            var arear = '<div class="weui-cell bgf" id="arear_'+ICnt+'">' +
                ' <ul id="cimg_'+ICnt+'" data-only="1">'+loadingImg+'</ul>' +
                ' <div class="weui-cell__bd"><textarea class="weui-textarea" placeholder="{lang xigua_dh:shuruwenzi}" rows="3" name="form[append_text][]"></textarea></div>' +
                '  <a class="iconfont icon-guanbijiantou closeHt" data-index="'+ICnt+'"></a></div>';
            _that.after(arear+ '<div class="weui-cell" id="cell_'+ICnt+'">'+$('#first_append_img').html()+'</div>');
            boxer = $('#cimg_'+ICnt);

            wx.chooseImage({
                count:1,
                success: function (res) {
                    var localIds = res.localIds;
                    syncUpload(localIds);
                },
                fail: function (res) {
                }
            });
            return false;
        });
        <!--{elseif IN_MAGAPP}-->
        $(document).on('touchstart','.center_upload__input', function () {
            uploadinput_obj = $(this);

            ICnt ++;
            var _that = $(this).parent().parent().parent().parent().parent();
            var arear = '<div class="weui-cell bgf" id="arear_'+ICnt+'">' +
                ' <ul id="cimg_'+ICnt+'" data-only="1">'+loadingImg+'</ul>' +
                ' <div class="weui-cell__bd"><textarea class="weui-textarea" placeholder="{lang xigua_dh:shuruwenzi}" rows="3" name="form[append_text][]"></textarea></div>' +
                '  <a class="iconfont icon-guanbijiantou closeHt" data-index="'+ICnt+'"></a></div>';
            _that.after(arear+ '<div class="weui-cell" id="cell_'+ICnt+'">'+$('#first_append_img').html()+'</div>');
            boxer = $('#cimg_'+ICnt);

            magPicPick();
            return false;
        });
        <!--{else}-->
        $(document).on('change', '.center_upload__input', function () {
            ICnt ++;
            var _that = $(this).parent().parent().parent().parent().parent();
            var arear = '<div class="weui-cell bgf" id="arear_'+ICnt+'">' +
                ' <ul id="cimg_'+ICnt+'" data-only="1">'+loadingImg+'</ul>' +
                ' <div class="weui-cell__bd"><textarea class="weui-textarea" placeholder="{lang xigua_dh:shuruwenzi}" rows="3" name="form[append_text][]"></textarea></div>' +
                '  <a class="iconfont icon-guanbijiantou closeHt" data-index="'+ICnt+'"></a></div>';
            _that.after(arear+ '<div class="weui-cell" id="cell_'+ICnt+'">'+$('#first_append_img').html()+'</div>');
            filedname = $(this).data('name');
            var files = this.files;
            if (files && files.length) {
                file = files[0];
                if (/^image\/\w+$/.test(file.type)) {
                    boxer = $('#cimg_'+ICnt);
                    compress(file, function(TMP){
                        dh_doupload(TMP,function(){
                        });
                    });
                } else {
                    $.toptip('Please choose an image file.', 'error');
                }
            }
        });
        <!--{/if}-->

        $(document).on('click', '.closeHt', function () {
            var idx = $(this).data('index');
            $.confirm('{lang xigua_dh:confirmshan}', function () {
                $('#arear_'+idx).remove();
                $('#cell_'+idx).remove();
            }, function () {
            });
            return false;
        });
    });
    function compress(file, callback){
        var reader = new FileReader();

        reader.onload = function (e) {

            var image = $('<img/>');
            image.on('load', function () {
                var square = 640;
                var canvas = document.createElement('canvas');


                if (this.width > this.height) {
                    canvas.width = Math.round(square * this.width / this.height);
                    canvas.height = square;
                } else {
                    canvas.height = Math.round(square * this.height / this.width);
                    canvas.width = square;
                }

                var context = canvas.getContext('2d');
                context.clearRect(0, 0, square, square);
                var imageWidth = canvas.width;
                var imageHeight = canvas.height;
                var offsetX = 0;
                var offsetY = 0;
                context.drawImage(this, offsetX, offsetY, imageWidth, imageHeight);
                var data = canvas.toDataURL('image/jpeg', 0.8);
                console.log([imageWidth,imageHeight]);
                callback(data);
            });

            image.attr('src', e.target.result);
        };

        reader.readAsDataURL(file);
    }
    <!--{if HB_INWECHAT && $config[multiupload]}-->
    var syncUpload = function(localIds){
        var localId = localIds.shift();
        wx.uploadImage({
            localId: localId,
            isShowProgressTips:1,
            success: function (res) {
                var serverId = res.serverId;
                do_download("&serverId[]="+serverId);
                if(localIds.length > 0){
                    syncUpload(localIds);
                }
            }
        });
    };
    function do_download(serverId){
        if(max_upload_num>0 && (boxer.find('li').length>=max_upload_num) && !boxer.data('only')){
            $.toptip(max_upload_maxtip, 'warning');
            return false;
        }
        $.showLoading();
        $.ajax({
            type: "POST",
            url: "$SCRITPTNAME?id=xigua_hb&ac=uploader&do=download&inajax=1",
            data: serverId,
            async: false,
            dataType: "xml",
            success: function(data){
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                var sar = s.split('|');
                if(sar[0]=='success'){
                    var imgary = sar[1].split('((()))');
                    if(boxer.data('only')){
                        var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgary[0] + ')"><input type="hidden" name="'+ uploadinput_obj.data('name')+'[]" value="' + imgary[0] + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        boxer.html(html);
                    }else{
                        var html_imga = '';
                        for(var j=0;j<imgary.length; j++){
                            html_imga += '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgary[j] + ')"><input type="hidden" name="form[album][]" value="' + imgary[j] + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        }
                        boxer.append(html_imga);
                    }
                }else{
                    tip_common(s);
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    }
    function wx_upload(){
        wx.chooseImage({
            success: function (res) {
                var localIds = res.localIds;
                syncUpload(localIds);
            },
            fail: function (res) {
            }
        });
    }
    <!--{/if}-->

    $(".time_ctrl").datetimePicker({
        title: '{lang xigua_dh:qxzsj}',
        min: "2017-01-01 12:00",
        max: "2037-01-01 00:00",
        onChange: function (picker, values, displayValues) {
            return values[0]+'-'+values[1]+'-'+values[2]+' '+values[3]+':'+values[4];
        }
    });
    function cropCallback(){
        $("#new_popup").popup();
        return false;
    }

    var chooseMapRes = [], chooseMapGoogle = [], OBJ = {};
    function setForm(lat, lng, deft){
        $.showLoading();
        $.ajax({
            type: 'GET',
            url: location + '&id=xigua_dh&ac=getloc&lat='+lat+'&lng='+lng+'&inajax=1',
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('error')!=-1){
                    tip_common(s);
                }else{
                    var _actions = [];
                    OBJ = jQuery.parseJSON(s.split('|')[1]);
                    if(deft){
                        setFormField(OBJ[0]);
                        return true;
                    }
                    for(var j in OBJ){
                        _actions.push({
                            text: OBJ[j].address,
                            className:'obj_ obj_'+j,
                            onClick: function() {  $.closePopup(); }
                        });
                    }
                    $.actions({ actions:_actions });
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    }
    function setFormField(subj){
        $("input[name='form[addr]']").val(subj.address);
        $("input[name='form[lat]']").val(subj.location.lat);
        $("input[name='form[lng]']").val(subj.location.lng);
        $("input[name='form[province]']").val(subj.address_component.province ? subj.address_component.province : '-');
        $("input[name='form[city]']").val(subj.address_component.city ? subj.address_component.city:'-');
        $("input[name='form[district]']").val(subj.address_component.district);
        $("input[name='form[street]']").val(subj.address_component.street);
        $("input[name='form[street_number]']").val(subj.address_component.street_number);
    }

    function setPoint(position){
        if(typeof position.type != 'undefined'){
            if(position.type == 'ip'){
                if(IGNORETIP){}else {
                    /*$.alert('{lang xigua_hd:locaerror}');*/
                    chooseMap(position);
                }
                return false;
            }
        }
        setForm((position.latitude||position.lat), (position.longitude||position.lng), 1);
    }
    function chooseMap(position) {
        if(typeof mag != 'undefined') {
            mag.mapPick(function (res) {
                setForm(res.lat, res.lng, 0);
            });
            return false;
        }

        <!--{if $_G['cache']['plugin']['xigua_dh']['google']}-->
        var myCenter=new google.maps.LatLng((position.latitude||position.lat), (position.longitude||position.lng));
        var Gmap=new google.maps.Map(document.getElementById("mapcontainer"),{
            center:myCenter,
            zoom:15,
            mapTypeId:google.maps.MapTypeId.ROADMAP
        });
        var Gmarker=new google.maps.Marker({
            position:myCenter
        });
        Gmarker.setMap(Gmap);
        $("#mapouter").popup();
        chooseMapGoogle = [(position.latitude||position.lat), (position.longitude||position.lng)];
        google.maps.event.addListener(Gmap, 'click', function(event) {
            var center = event.latLng;
            var centerlat = center.lat();
            var centerlng = center.lng();
            chooseMapGoogle = [centerlat, centerlng];

            Gmarker.setMap(null);
            Gmarker=new google.maps.Marker({
                position:new google.maps.LatLng(centerlat, centerlng)
            });
            Gmarker.setMap(Gmap);
            setForm(centerlat, centerlng, 0);
            $.closePopup();
        });
        <!--{else}-->
        var center = new qq.maps.LatLng((position.latitude||position.lat), (position.longitude||position.lng));
        var mapinit = function () {
            geocoder = new qq.maps.Geocoder({
                complete: function (result) {
                    chooseMapRes = result;
                }
            });
            geocoder.getAddress(center);
            map = new qq.maps.Map(document.getElementById("mapcontainer"), {center: center, zoom: 13});
            marker = new qq.maps.Marker({
                position: center, map: map
            });
            qq.maps.event.addListener(map, 'click', function (event) {
                var tmpcenter = new qq.maps.LatLng(event.latLng.getLat(), event.latLng.getLng());
                marker.setPosition(tmpcenter);
                geocoder.getAddress(tmpcenter);
            });
            $("#mapouter").popup();
        };
        mapinit();
        <!--{/if}-->
    }
    $(document).on('click', '.obj_', function(){
        var k = parseInt($(this)[0].classList[2].replace('obj_', ''));
        setFormField(OBJ[k]);
        $("#new_popup").popup();
    });

    $('#openlocation').on('click', function(){
        var pot = [];
        IGNORETIP = 0;
        pot.push({ text: "{lang xigua_hb:locacurrt}", onClick: function() { dh_getlocation(setPoint); } });
        if(!(GOOGLE && HB_INWECHAT)){
            pot.push({text: "{lang xigua_hb:xuandian}", onClick: function() { dh_getlocation(chooseMap); } });
        }
        $.actions({ actions: pot});
    });

    <!--{if $_G['cache']['plugin']['xigua_dh']['google']}-->
    $('.confirm-popup').on('click', function(){
        setForm(chooseMapGoogle[0], chooseMapGoogle[1], 0);
    });
    <!--{else}-->
    $('.confirm-popup').on('click', function(){
        setForm(chooseMapRes.detail.location.lat, chooseMapRes.detail.location.lng, 0);
    });
    <!--{/if}-->
    function dh_doupload(cmp_photo, callback){
        var img = cmp_photo.split(',')[1];
        img = window.atob(img);
        var ia = new Uint8Array(img.length);
        for (var i = 0; i < img.length; i++) {
            ia[i] = img.charCodeAt(i);
        }
        var blob = new Blob([ia], {type:"image/jpeg"});
        var formdata=new FormData();
        formdata.append('file',blob);

        $.ajax({
            type: 'post',
            url: _APPNAME+'?id=xigua_hb&ac=uploader&inajax=1&formhash='+FORMHASH,
            data :  formdata,
            processData : false,
            contentType : false,
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + cmp_photo + ')"><input type="hidden" name="'+filedname+'[]" value="' + s.split('|')[1] + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                    $('#loadingimg').remove();
                    if(boxer.data('only')){
                        boxer.html(html);
                    }else{
                        boxer.append(html);
                    }
                    if(callback && typeof callback === 'function') {
                        callback();
                    }
                } else {
                    tip_common(s);
                }
            }
        });
    }
    <!--{if IN_MAGAPP}-->
    function magPicPick(){
        mag.picPick({
            preview: function(res){
                $.showLoading();
            },
            success: function(res){
                $.hideLoading();
                var imgu = typeof res.url!=='undefined' ? res.url : ('{$config[magapp_url]}/core/attachment/attachment/attach?aid='+res.aid);

                if(boxer.data('only')){
                    var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="'+ uploadinput_obj.data('name')+'[]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                    boxer.html(html);
                }else{
                    var html_imga = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="form[album][]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                    boxer.append(html_imga);
                }

            },
            fail: function(res){
                $.hideLoading();
            }
        });
    }
    <!--{elseif IN_QIANFAN}-->
    function magPicPick() {
        var maxqf = boxer.data('only') ? 1 : 9;
        var type = 0;
        var jsUploadOptions = {
            'picFormat': 1,
            'picMaxSize': 1200,
            'compressOption':100,
            'uploadNum': maxqf,
            'uploadType': 0,
            'showCamera':false
        }
        QFH5.uploadImageOrVideo(type, JSON.stringify(jsUploadOptions), function (state, data) {
            if (state == 1) {
                for(var i in data){
                    var imgu = data[i].url;
                    if(boxer.data('only')){
                        var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="'+ uploadinput_obj.data('name')+'[]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        boxer.html(html);
                    }else{
                        var html_imga = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="form[album][]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        boxer.append(html_imga);
                    }
                }
            } else {
            }
        })
    }
    <!--{/if}-->
    <!--{if !$old_data}-->
    if($('#openlocation').length>0){
        if(typeof wx!=='undefined'){
            wx.ready(function () {
                if($('#openlocation').length>0){
                    dh_getlocation(setPoint);
                }
            });
        }else{
            setTimeout(function () {
                IGNORETIP = 1;
                dh_getlocation(setPoint);
            }, 800);
        }
    }
    <!--{/if}-->
</script>