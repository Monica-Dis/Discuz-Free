<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval include DISCUZ_ROOT.'source/plugin/xigua_dh/include/c_shopli.php'}-->
<!--{template xigua_dh:header}--><style>#list img{max-width:100%;}</style><!--{if $_G['cache']['plugin']['xigua_hs']}--><link rel="stylesheet" href="source/plugin/xigua_hs/static/hs.css?{VERHASH}" /><!--{/if}-->
<div class="page__bd">
<div class="none"><img src="$v[logo]" onerror="this.error=null;this.src='source/plugin/xigua_dh/static/img/new.png'" /></div>
<!--{if $dh_config[showlb] && $v[album]}-->
<div class="swipe cl">
    <div class="swipe-wrap">
        <!--{loop $v[album] $slider}-->
        <div><img src='$slider' <!--{if $dh_config[viewh]}-->style="height:{$dh_config[viewh]}px"<!--{/if}--> /></div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $v[album] $k $slider}-->
            <li <!--{if $k==0}-->class="current"<!--{/if}--> ></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{/if}-->
<div class="cl dh_viewheader">
<div id="loadqr">
    <div class="view_htop">
        <div class="view_logo"><img src="$v[logo]" onerror="this.error=null;this.src='source/plugin/xigua_dh/static/img/new.png'" /></div>
        <h2>$v[name] <!--{if $v[dig]}--><em class="is-star dig_tag">{lang xigua_dh:dig}</em> <!--{/if}--></h2>
        <div class="view_rank">
            <!--{loop $hy_ret $hy1}-->
            <span class="mod-feed-tag b-color12">{$hy1[name]}</span>
            <!--{/loop}-->
        </div>
        <div class="viewright">
<span><i class="iconfont icon-browse f12"></i>{echo intval($v[views])}{lang xigua_dh:rkg}</span>
        </div>
    </div>
    <div class="weui-cell dh_main_list" style="padding-bottom:8px;">
        <div class="weui-cell__hd li">{lang xigua_dh:dh}<span style="visibility:hidden"> : </span></div>
        <div class="weui-cell__bd">
            <!--{if $v['price_view']>0}-->
            <p class="notbr main_color cl">
                <a class="weui-btn weui-btn_mini" href="javascript:;" onclick="dh_paytel($v['shid'],'$v[price_view]','$v[hangye_id2]');">{lang xigua_dh:ckdh}</a>
                <!--{if trim($dh_config[taocan])}-->
                <a style="margin-left:.5rem;margin-top:0!important" class="weui-btn weui-btn_mini" href="$SCRITPTNAME?id=xigua_dh&ac=getloc&do=dhtc$urlext">{lang xigua_dh:gmtc}</a>
                <!--{/if}-->
            </p>
            <!--{else}-->
            <!--{loop $v[tels] $kkk $vtels}-->
            <p class="blur main_color"><i class="iconfont icon-dianhua1 f14"></i>{echo substr_replace($vtels, '****',3, 4)}</p>
            <p class="notbr main_color cl f14">
                <a href="tel:{$vtels}"><i class="iconfont icon-dianhua1 f14"></i>{echo $v['telnames'][$kkk] ? ' '.$v['telnames'][$kkk].': ' : ' '}{$vtels}</a>
            <!--{if $dh_config[showbohao]}--><a href="tel:{$vtels}" class="bnphao">{lang xigua_dh:bohao}</a><!--{/if}-->
            </p>
            <!--{/loop}-->
            <!--{/if}-->
        </div>
    </div>
    <!--{if $v[addr]}-->
    <a id="dh_openlocation" data-lat="$v[lat]" data-lng="$v[lng]" data-name="$v[name]" data-addr="$v[addr]" class="weui-cell weui-cell_access dh_main_list">
        <div class="weui-cell__hd li">{lang xigua_dh:dz}<span style="visibility:hidden"> : </span></div>
        <div class="weui-cell__bd">
            <p class="f14 c3">{$v[addr]}</p>
        </div>
        <div class="weui-cell__ft">
        </div>
    </a>
    <!--{/if}-->
</div>
<!--{if $dh_config[showzs] && $v[album]}-->
    <div class="weui-cell dhalbum dh_main_list">
        <div class="weui-cell__hd li">{lang xigua_dh:zs}<span style="visibility:hidden"> : </span></div>
        <div class="weui-cell__bd" style="margin-bottom:-5px;overflow:hidden">
            <div class="cl feed-preview-pic">
                <!--{loop $v[album] $__k $__v}-->
                <span class="imgloading"><img src="$__v"></span>
                <!--{/loop}-->
            </div>
        </div>
    </div>
<!--{/if}-->
<!--{eval
if(!$dh_config[mustbind]):
    if($user && !$user['mobile']):
        $jiucuourl = $myzlurl = '';
    endif;
endif;
}-->
    <div class="mpview_area weui-flex border_top">
        <!--{if !$v[uid]}-->
        <div class="weui-flex__item tc">
            <a <!--{if !$myzlurl}-->class="usebtn renling" href="javascript:;"<!--{else}--> class="usebtn" href="{$myzlurl}"<!--{/if}--> data-id="$shid"><i class="iconfont icon-huiyuanqia f12"></i> <em>{lang xigua_dh:rl}</em>
            </a>
        </div>
        <!--{/if}-->
        <div class="weui-flex__item tc">
            <a <!--{if !$jiucuourl}-->class="usebtn jiucuo" href="javascript:;"<!--{else}--> class="usebtn" href="{$jiucuourl}"<!--{/if}--> data-id="$shid"><i class="iconfont icon-bianji f12"></i> <em>{lang xigua_dh:jc}</em>
            </a>
        </div>
        <div class="weui-flex__item tc">
            <!--{if 0}-->
            <a class="usebtn mag_share" data-id="$shid">
            <!--{else}-->
            <a class="usebtn sec_newewm" data-id="$shid">
            <!--{/if}-->
            <i class="iconfont icon-fenxiang f12"></i>  {lang xigua_dh:zf} <em class="f12">{echo intval($v[shares])}</em></a>
        </div>
    </div>
</div>
<!--{template xigua_dh:view_pic}-->
<div class="weui-cells border_none">
    <a href="$SCRITPTNAME?id=xigua_hj" class="weui-cell weui-cell_access ">
        <div class="weui-cell__bd">
            <p class="f12">{lang xigua_dh:blq}</p>
        </div>
        <div class="weui-cell__ft weui-grids-nob jbright border_left">
            <i class="main_color iconfont icon-jubao2"></i>
            <span class="main_color f12 block">{lang xigua_dh:jb}</span>
        </div>
    </a>
</div>

<!--{eval
$fullindex = unserialize($dh_config[showinview]);
if(!in_array(-1, $fullindex)):
    $allow1 = in_array('1', $fullindex);
    $allow2 = in_array('2', $fullindex);
    $allow3 = in_array('3', $fullindex);
endif;
}-->
<!--{if 1}-->
<div class="weui-cells fixbanner before_none">
    <div class="weui-navbar weui-banner nobg fixbanner_in">
        <a href="javascript:;" class="weui-navbar__item weui_bar__item_on ajaxcat" data-loadingurl="$SCRITPTNAME?id=xigua_dh&ac=getloc&shid=$shid&do=showjie&inajax=1&page=">
            <span>{lang xigua_dh:jianjie}</span>
        </a>
        <!--{if $allow1}-->
        <a href="javascript:;" class="weui-navbar__item ajaxcat" data-loadingurl="$SCRITPTNAME?id=xigua_dh&ac=myshop_li&notshid=$shid&hyid={$v[hangye_id1]}&inajax=1&pagesize=10&page=">
            <span>{lang xigua_dh:wntj}</span>
        </a>
        <!--{eval $hason = 1;}-->
        <!--{/if}-->
        <!--{if $allow2 && $v[uid]}-->
        <a href="javascript:;" class="weui-navbar__item <!--{if !$hason}-->weui_bar__item_on<!--{/if}--> ajaxcat" data-loadingurl="$SCRITPTNAME?id=xigua_hb&ac=list_item&uid={$v[uid]}&inajax=1&pagesize=10&page=">
            <span>{lang xigua_dh:dt}</span>
        </a>
        <!--{eval $hason = 1;}-->
        <!--{/if}-->
        <!--{if $allow3 && $_G['cache']['plugin']['xigua_hs'] && $v[uid]}-->
        <a href="javascript:;" class="weui-navbar__item <!--{if !$hason}-->weui_bar__item_on<!--{/if}--> ajaxcat" data-loadingurl="$SCRITPTNAME?id=xigua_hs&ac=myshop_li&uid={$v[uid]}&inajax=1&pagesize=10&page=">
            <span>{lang xigua_dh:dp}</span>
        </a>
        <!--{/if}-->
    </div>
</div>
<div id="list" class="mod-post x-postlist p0"></div>
<!--{template xigua_hb:loading}-->
<!--{/if}-->

    <div class="footer_fix"></div>

    <div class="view_bottom weui-flex border_top">
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_dh{$urlext}" class="weui-tabbar__item ">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-dianhuaben weui-tabbar__icon"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_dh:114}</p>
            </a>
        </div>
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_dh&ac=join&from=dhview{$urlext}" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-tianjia weui-tabbar__icon f22"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_dh:wyrz1}</p>
            </a>
        </div>
        <div class="view_bottom_z">
            <a href="javascript:;" class="weui-tabbar__item dofollow" data-id="$shid">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-<!--{if $followed}-->shoucang<!--{else}-->shoucang1<!--{/if}-->  weui-tabbar__icon f22"></i>
                    </span>
                <p class="weui-tabbar__label"><em<!--{if !$followed}--> class="none"<!--{/if}-->>{lang xigua_dh:yi}</em>{lang xigua_dh:guanzhu}</p>
            </a>
        </div>

        <!--{if $v['price_view']>0}-->
        <div class="weui-flex__item view_bottom_y">
            <a class="mc_bg" href="javascript:;" onclick="dh_paytel($v['shid'],'$v[price_view]','$v[hangye_id2]');"><i class="iconfont icon-unie607"></i> {lang xigua_dh:ckdh}</a>
        </div>
        <!--{else}-->
        <!--{if $v['wxhao'] || $v[qr]}-->
        <div class="view_bottom_z <!--{if $dh_config[wxbtncolor]}-->" style="background-color:$dh_config[wxbtncolor]"<!--{else}-->main_bg"<!--{/if}-->>
            <!--{if $v[wxhao]}-->
            <a href="javascript:;" class="weui-tabbar__item wxh" data-clipboard-text="$v['wxhao']">
            <!--{else}-->
            <a href="javascript:;" class="weui-tabbar__item qrctrl">
            <!--{/if}-->
                <span style="display:inline-block;position:relative;">
                    <i class="iconfont icon-weixin3 weui-tabbar__icon f20 color-white"></i>
                </span>
                <p class="weui-tabbar__label color-white">{lang xigua_dh:wxlx}</p>
            </a>
        </div>
        <!--{/if}-->
        <div class="weui-flex__item view_bottom_y">
            <a href="tel:{$v['tels'][0]}" class="mc_bg"><i class="iconfont icon-unie607"></i> {lang xigua_hb:boda}</a>
        </div>
    <!--{/if}-->
    </div>

</div>

<!--{template xigua_dh:qrcode}-->
<script>
<!--{if 1}-->
var loadingurl = "$SCRITPTNAME?id=xigua_dh&ac=getloc&shid=$shid&do=showjie&inajax=1&page=";
<!--{elseif $allow1}-->
var loadingurl='$SCRITPTNAME?id=xigua_dh&ac=myshop_li&notshid=$shid&hyid={$v[hangye_id1]}&inajax=1&pagesize=10&page=';
<!--{elseif $allow2&& $v[uid]}-->
var loadingurl='$SCRITPTNAME?id=xigua_hb&ac=list_item&uid={$v[uid]}&inajax=1&pagesize=10&page=';
<!--{elseif $allow3&& $_G['cache']['plugin']['xigua_hs']&& $v[uid]}-->
var loadingurl='$SCRITPTNAME?id=xigua_hs&ac=myshop_li&uid={$v[uid]}&inajax=1&pagesize=10&page=';
<!--{/if}-->
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_dh:footer}-->
<script src="source/plugin/xigua_hb/static/js/html2canvas.min.js?{VERHASH}"></script>
<script>function shareIncr(){
var rphtml = $('#loadqr').html().replace(/blur/g, '').replace(/notbr/g, 'blur');
    <!--{if $v[logo]}-->
rphtml = rphtml.replace('{$v[logo]}','{$shot_img}');
    <!--{/if}-->
    $('.mpc_body').html('<div class="dh_viewheader">'+rphtml+'</div>');
    $.ajax({type: 'post',url: _APPNAME +'?id=xigua_dh&ac=incr&incr_type=shares&shid=$shid&inajax=1',data: {'formhash':FORMHASH},dataType: 'xml'});
}
    $(document).on('click','.renling', function () {
        var that = $(this);
<!--{if $dh_config[rprice]}-->
        var text = "<p style='margin-bottom:10px'>{lang xigua_dh:shtgj}<em class=\"main_color\">{$dh_config[rprice]}{lang xigua_dh:yuan}</em>{lang xigua_dh:msrl}</p>";
        var rldesc = '{lang xigua_dh:qtxrlsm}';
        $.modal({
            text: text+'<div class="b-color13 fixipt13"><textarea class="weui-textarea weui-prompt-input needsclick needsclick1" id="weui-prompt-input" placeholder="' + rldesc + '" rows="3"></textarea></div>',
            autoClose: false,
            title: '{lang xigua_dh:rl}{$v[name]}',
            buttons: [
                { text: "{lang xigua_dh:qx}", className: "default", onClick: function(){ $.closeModal();} },
                <!--{if $dh_config[renlingmtd]==1 || $dh_config[renlingmtd]==2}-->
                { text: "{lang xigua_dh:sqrl}", onClick: function(){
                        var input = $("#weui-prompt-input").val();
                        if ((input === "" || input === null)) {
                            $(".needsclick1").focus()[0].select();
                            return false;
                        }
                        $.showLoading();
                        $.ajax({
                            type: 'post',
                            url: '$SCRITPTNAME?id=xigua_dh&ac=renling&inajax=1',
                            data:{formhash:'{FORMHASH}', shid:'$shid', text: input},
                            dataType: 'xml',
                            success: function (data) {
                                $.hideLoading();
                                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                var s = data.lastChild.firstChild.nodeValue;
                                tip_common(s);
                            },
                            error: function () {
                                $.hideLoading();
                            }
                        });
                        $.closeModal();
                } },
                <!--{/if}-->
                <!--{if $dh_config[renlingmtd]==1 || $dh_config[renlingmtd]==3}-->
                { text: "{lang xigua_dh:zfrl}", onClick: function(){
                        var input = $("#weui-prompt-input").val();
                        if ((input === "" || input === null)) {
                            $(".needsclick1").focus()[0].select();
                            return false;
                        }
                        $.showLoading();
                        $.ajax({
                            type: 'post',
                            url: '$SCRITPTNAME?id=xigua_dh&ac=renling&do=pay&inajax=1',
                            data:{formhash:'{FORMHASH}', shid:'$shid', text: input},
                            dataType: 'xml',
                            success: function (data) {
                                $.hideLoading();
                                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                var s = data.lastChild.firstChild.nodeValue;
                                tip_common(s);
                            },
                            error: function () {
                                $.hideLoading();
                            }
                        });
                        $.closeModal();
                    } }
                <!--{/if}-->
            ]
        }, function () {
            this.find(".weui-prompt-input").focus()[0].select()
        });
<!--{else}-->
        $.prompt({
            title: '{lang xigua_dh:rl}{$v[name]}',
            text: '{lang xigua_dh:rlshmc}',
            input: '',
            empty: false,
            onOK: function (input) {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_dh&ac=renling&inajax=1',
                    data:{formhash:'{FORMHASH}', shid:'$shid', text: input},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            },
            onCancel: function () {
            }
        });
        document.getElementById('weui-prompt-input').focus();
<!--{/if}-->
    });
    $(document).on('click','.jiucuo', function () {
        var that = $(this);
        $.prompt({
            title: '{$v[name]}{lang xigua_dh:jc}',
            text: '{lang xigua_dh:qtxjc}',
            input: '',
            empty: false,
            onOK: function (input) {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_dh&ac=jiucuo&inajax=1',
                    data:{formhash:'{FORMHASH}', shid:'$shid', text: input},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            },
            onCancel: function () {
            }
        });
        document.getElementById('weui-prompt-input').focus();
    });
    <!--{if $v['wxhao']}-->
    new ClipboardJS('.wxh').on('success', function(e) {
        $.alert('{lang xigua_dh:wxhao}"'+e.text+'"{lang xigua_dh:fzcg}'+'<img style="width:100%;margin-top:5px" src="source/plugin/xigua_dh/static/img/shili.png" />');
    });
    <!--{/if}-->
    <!--{if $v['qr']}-->
    $(document).on('click','.qrctrl', function () {
        $.alert('{lang xigua_dh:changan}<br><img style="width:100%;margin-top:5px" src="{$v[qr]}" />');
    });
    <!--{/if}-->
    $(document).on('click','.sec_newewm', function () {
        shareIncr();
        $.showLoading();
        html2canvas(document.querySelector(".shot_in")).then(canvas => {
            var dataURL = canvas.toDataURL();
            COMCLAS = 'shot_outer';
            $.hideLoading();
            $.modal({
                title: "{lang xigua_dh:ca}",
                text: "<img style='display:block' src='"+dataURL+"' />",
                buttons: [{ text: "{lang xigua_hb:close}", onClick: function(){} }]
            });
            $('.weui-dialog__title').css('font-size', '14px');
            COMCLAS = '';
        });
        return false;
    });
<!--{if 0}-->
    $(document).on('click','.mag_share', function () {
        $.showLoading();
        shareIncr();
        html2canvas(document.querySelector(".shot_in")).then(canvas => {
            var dataURL = canvas.toDataURL();
            COMCLAS = 'shot_outer';
            dh_doupload(dataURL);
            COMCLAS = '';
        });
        return false;
    });
    function dh_doupload(cmp_photo){
        var img = cmp_photo.split(',')[1];
        img = window.atob(img);
        var ia = new Uint8Array(img.length);
        for (var i = 0; i < img.length; i++) {
            ia[i] = img.charCodeAt(i);
        }
        var blob = new Blob([ia], {type:"image/jpeg"});
        var formdata=new FormData();
        formdata.append('file',blob);

        $.ajax({
            type: 'post',
            url: _APPNAME+'?id=xigua_hb&ac=uploader&inajax=1&formhash='+FORMHASH,
            data :  formdata,
            processData : false,
            contentType : false,
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    var SHAREIMG = s.split('|')[1];
                    mag.setData({shareData: {
                            type: 1, imageurl:SHAREIMG, picurl:  SHAREIMG
                        }});
                    mag.share('ALL', function(res){},function(){ });
                } else {
                    tip_common(s);
                }
            }
        });
    }
    <!--{/if}-->
</script>