<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $manage}-->
<!--{eval $mg = '&manage=1';}-->
<!--{/if}-->
<!--{eval $keyword = $_GET['keyword']}-->
<!--{template xigua_dh:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_dh&ac=my114$mg" class="weui-navbar__item <!--{if !$_GET[hide]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_dh:zhanshizhong}</span>
        </a>
        <!--{if !$manage}-->
        <a href="$SCRITPTNAME?id=xigua_dh&ac=my114&hide=1$mg" class="weui-navbar__item <!--{if $_GET[hide]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_dh:weizhanshi}</span>
        </a>
        <!--{/if}-->
        <a href="$SCRITPTNAME?id=xigua_dh&ac=my114&hide=2$mg" class="weui-navbar__item <!--{if $_GET[hide]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_dh:daishen}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_dh&ac=my114&hide=3$mg" class="weui-navbar__item <!--{if $_GET[hide]==3}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_dh:rljl}</span>
        </a>
    </div>

    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">
            <input name="id" value="xigua_dh" type="hidden">
            <input name="ac" value="my114" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <input type="hidden" name="manage" value="$manage">
            <input type="hidden" name="hide" value="$_GET[hide]">
            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_dh:spmcddh}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_dh:spmcddh}</span>
            </label>
        </form>
        <a href="javascript:;" class="search_bar_btn main_color" id="dosearch">{lang xigua_dh:search}</a>
        <a href="$SCRITPTNAME?id=xigua_dh&ac=my114&hide={$_GET[hide]}{$mg}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_dh:qx}</a>
    </div>

    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
</div>

<!--{if $_GET[hide]==3}-->
<script>var loadingurl = window.location.href+'&ac=renling_li&is_my=1&inajax=1&manage=$manage&keyword=$keyword&page=';</script>
<!--{else}-->
<script>var loadingurl = window.location.href+'&ac=myshop_li&is_my=1&inajax=1&manage=$manage&keyword=$keyword&page=';</script>
<!--{/if}-->
<!--{eval $tabbar=0;$dh_tabbar=1;}-->
<!--{template xigua_dh:footer}-->
<script>
    function managesh(obj) {
        var act = [], that = $(obj);
        var id= that.data('id'), ttl= that.data('title'), gg= that.data('gg'), hb= that.data('hb'), vipid = that.data('vipid');
        var digprices = [<!--{loop $dig_prices $___k $___v}-->
{text: "{$___v[title]}", onClick: function () {
var _axjurl = '$SCRITPTNAME?id=xigua_dh&ac=dodig{$mg}&type={$___v[type]}&shid=' + id;
$.showLoading();
$.ajax({
    type: 'post', url: _axjurl,
    data: {'formhash' :FORMHASH},
    dataType: 'xml', success: function (data) {
        $.hideLoading();
        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
        var s = data.lastChild.firstChild.nodeValue;
        var msgar = tip_common(s);
    },
    error: function () {
        $.hideLoading();
    }
});
}},<!--{/loop}-->];

act.push({
    text: '{lang xigua_dh:zhidingdianpu}', onClick: function () {
        $.actions({
            title: '{lang xigua_dh:zhidingdianpu} : '+ ttl,
            actions: digprices
        });
    }
});

<!--{if !$manage}-->
act.push( {
    text: '{lang xigua_dh:xufei}', onClick: function () {
        var _vips = [];
        <!--{loop $join_prices $k $__v}-->
        <!--{if $__v[price]<=0}-->
        <!--{eval continue;}-->
        <!--{/if}-->
        _vips.push({text:'{$__v[title]}', onClick:function () {
                window.location.href = '$SCRITPTNAME?id=xigua_dh{$mg}&ac=xufei&viptype={$__v[type]}&shid='+id+_URLEXT;
            }});
        <!--{/loop}-->
        $.actions({
            title: '{lang xigua_dh:xufei} : '+ttl,
            actions: _vips
        });
    }
});
        <!--{/if}-->
<!--{if $manage}-->
act.push({
    text: '{lang xigua_hb:shenhe}', onClick: function () {
        $.modal({
            title: "{lang xigua_hb:shenhe}",
            text: "{lang xigua_hb:qingxuanzeshenhe}",
            buttons: [
                { text: "{lang xigua_hb:quxiao}", className: "default"},
                { text: "{lang xigua_hb:jujue}", onClick: function(){
                        dh_dotong(id, 0);
                    } },
                { text: "{lang xigua_hb:tongguo}", onClick: function(){
                        dh_dotong(id, 1);
                    }}
            ]
        });
    }
});
<!--{/if}-->
act.push( {
text: '{lang xigua_hb:edit}', onClick: function () {
    window.location.href = '$SCRITPTNAME?id=xigua_dh{$mg}&ac=join&edit='+id+_URLEXT;
}
});

act.push( {text: '{lang xigua_hb:xiajia}', onClick: function () { confirm_del('{lang xigua_hb:xiajiaconfirm}', '$SCRITPTNAME?id=xigua_dh{$mg}&ac=join&del='+id+'&formhash={FORMHASH}'); } });
$.actions({ title: '{lang xigua_dh:shangjia}: '+ttl, actions: act });
return false;
    }
<!--{if $newshid}-->
setTimeout(function () {
    $('#li_{$newshid} a').trigger('click');
}, 400);
<!--{/if}-->

$(document).on('click','#dosearch', function () {
    if($('#searchInput').val()){
        $('#dosearchform').submit();
    }else{
        $.alert($('#searchInput').attr('placeholder'));
    }
});
</script>