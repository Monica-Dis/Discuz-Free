<?php exit('xxxxx');?>
<!--{template xigua_dh:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hb/static/js/clipboard.min.js?{VERHASH}"></script>
<script src="source/plugin/xigua_dh/static/js/dh.js?{VERHASH}"></script>
<script>
<!--{if $dig_prices}-->
$(document).on('click','.hpdig', function () {
    var that = $(this);

    $.actions({
        title: '{lang xigua_hb:zhidingkuosan}: '+that.data('name'),
        actions: [
            <!--{loop $dig_prices $item}-->
            {text: "{$item[title]}", onClick: function () {
                    var _axjurl = '$SCRITPTNAME?id=xigua_dh&ac=dodig&digtype={$item[type]}&mpid='+that.data('id');
                    $.showLoading();
                    $.ajax({
                        type: 'post',
                        url: _axjurl,
                        data: {'formhash' :FORMHASH},
                        dataType: 'xml',
                        success: function (data) {
                            $.hideLoading();
                            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                            var s = data.lastChild.firstChild.nodeValue;
                            var msgar = tip_common(s);
                        },
                        error: function () {
                            $.hideLoading();
                        }
                    });
                }},
            <!--{/loop}-->
        ],
        onClose:function () {
            if($('.weui-dialog__btn').length>0){
                $($('.weui-mask')[0]).replaceWith('<div class="weui-mask weui-actions_mask weui-mask--visible"></div>');
            }
        }
    });

});
<!--{/if}-->
<!--{if trim($dh_config[taocan])}-->
<!--{eval $mytcan = DB::fetch_first('select * from %t where uid=%d', array('xigua_dh_taocan', $_G['uid']));}-->
<!--{/if}-->
function dh_paytel(id, pri, pricat){
    if(UID<=0){
        hb_jump("member.php?mod=logging&action=login&needlogin=1&referer="+encodeURIComponent('{echo hb_currenturl()}'));
        return false;
    }
    $.modal({
        title: LXFS,
        text: CKXFF+pri+QRZF+"<!--{if $mytcan}--><p>{lang xigua_hb:ndqysy} <em class=\"main_color\">{$mytcan[used]}</em> {lang xigua_dh:cchdh}, {lang xigua_hb:sy} <em class=\"main_color\">{$mytcan[total]}</em> {lang xigua_hb:c}</p><p>{lang xigua_hb:lastts} <em class=\"main_color\">{echo date('Y-m-d H:i:s', $mytcan[endts])}</em></p><!--{/if}-->",
        buttons: [
            {text: "{lang xigua_hb:close}", className: "default", onClick: function () {}},
            {text: "{lang xigua_hb:paynow}", className: "", onClick: function () {$.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME+'?id=xigua_dh&ac=getloc&do=telpay&hyid='+pricat+'&shid=' + id,
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function() {
                        $.hideLoading();
                    }
                });
            }},
            <!--{if trim($dh_config[taocan])}-->
            {text: "{lang xigua_dh:sytc}", className: "default", onClick: function () {
                    $.showLoading();
                    $.ajax({
                        type: 'post',
                        url: _APPNAME+'?id=xigua_dh&ac=getloc&do=telpay&usetc=1&hyid='+pricat+'&shid=' + id,
                        dataType: 'xml',
                        success: function (data) {
                            $.hideLoading();
                            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                            var s = data.lastChild.firstChild.nodeValue;
                            tip_common(s);
                        },
                        error: function() {
                            $.hideLoading();
                        }
                    });
                }},
            <!--{/if}-->
        ]
    });
}
</script>