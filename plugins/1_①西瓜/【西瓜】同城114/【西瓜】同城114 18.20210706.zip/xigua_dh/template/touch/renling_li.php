<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="dh_item">
    <div class="sp_main" style="margin-left:12px">
        <div class="sp_content">
            <div class="weui-flex">
                <h3 class="weui-flex__item">{$v['realname']} <span class="f12">$v['mobile']</span></h3>
            </div>
            <p class="sp_desc color-gray">
                {lang xigua_dh:crts} : {echo date('Y-m-d H:i:s', $v['crts'])}
            </p>
            <p class="sp_desc color-gray">
                <a href="$SCRITPTNAME?id=xigua_dh&ac=view&shid=$v[shid]">$v['verinfo']</a>
            </p>

            <div class="weui-flex">
                <p class="weui-flex__item color-gray">{$v['status_info']}</p>
            </div>
        </div>
    </div>
    <a class="weui-btn weui-btn_mini whbtn" style="padding: 0 10px!important;width: auto;" href="$SCRITPTNAME?id=xigua_dh&ac=view&shid=$v[shid]" >{$v['status_text']}</a>
</div>
<!--{/loop}-->