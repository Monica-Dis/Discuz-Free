$(function () {
    $(document).on('click','.navbar', function () {
        var that = $(this);
        that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
        if(that.data('display')){
            $('#'+that.data('display')).show();
        }
        if(that.data('hide')){
            $('#'+that.data('hide')).hide();
        }
        if(that.data('id')){
            $('#'+that.data('id')).val(that.data('value'));
        }
    });

    $(document).on('click','.filter_nav', function () {
        $(this).addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
        var curt = $('#dist_show_'+$(this).data('id'));
        curt.siblings().removeClass('show');
        curt.toggleClass('show');
        if(curt.hasClass('show')){
            $(this).parent().addClass('filter_top');
            $(this).find('em').html($(this).find('em').data('html'));
            $('.mask').show();
        }else{
            $(this).parent().removeClass('filter_top');
            $('.mask').hide();
        }
        if(IN_APP==='magapp'){
            $('#backtotop').trigger('click');
        }
        return false;
    });
    $(document).on('click','.mask', function () {
        $('.filter_top').removeClass('filter_top');
        $('.dist_show').find('.nav_expand_panel').removeClass('show');
        $(this).hide();
    });

    $(document).on('click','.ftb', function () {
        var that = $(this);
        that.parent().parent().find('.checked').removeClass('checked main_color');
        that.parent().addClass('checked main_color');
        $('.mask').trigger('click');

        var oem = $('#ftb'+that.data('idid')).find('em');
        var showhtm = that.html();
        if(that.data('orihtml')){
            showhtm = that.data('orihtml');
        }
        oem.data('html', oem.html()).html(showhtm);

        var lnk = that.data('sort');
        //todo
    });

    $(document).on('click','.dhlistcat', function () {
        lm=0;var that = $(this);
        if(that.data('needgeo')){
            dh_getlocation(function (position) {
                var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
                dh_setlist(that, '&lat='+lat+'&lng='+lng);
            });
        }else{
            dh_setlist(that, '');
        }

        if(that.data('save')){
            var oldu = window.location.href.replace(/nav\=\w+\&/, '');
            var su = that.data('save');
            history.replaceState(null,'', oldu.replace(su+'&','').replace('id=xigua',su+'&id=xigua'));
        }
    });

    $(document).on('click', '.dh_jump', function () {
        var that = $(this);
        var jmpurl = _APPNAME +'?id=xigua_dh&ac=view&shid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        dh_jump(jmpurl);
    });
    $(document).on('click', '.hy_jump', function () {
        var that = $(this);
        var jmpurl = _APPNAME +'?id=xigua_dh&ac=hangye&hyid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        dh_jump(jmpurl);
    });
    $(document).on('click','.dofollow', function () {
        var that = $(this);
        $.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME +'?id=xigua_dh&ac=follow&shid='+that.data('id')+'&inajax=1',
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.split('|')[1]> 0){
                    tip_common('success|'+SCCG+'||');
                    that.find('.iconfont').removeClass('icon-shoucang1').addClass('icon-shoucang');
                    that.find('em').removeClass('none');
                }else{
                    tip_common(s);
                    that.find('.iconfont').removeClass('icon-shoucang').addClass('icon-shoucang1');
                    that.find('em').addClass('none');
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    });
    $(document).on('click', '#dh_openlocation', function () {
        var that = $(this);
        if((HB_INWECHAT&&DH_MULTIUPLOAD)==1){
            wx.openLocation({
                latitude: that.data('lat'),
                longitude: that.data('lng'),
                name: that.data('name'),
                address: that.data('addr'),
                scale: 14,
                infoUrl:window.location.href
            });
        }else if(GOOGLE){
            window.location.href = _APPNAME+'?id=xigua_dh&ac=googleMap&lat='+that.data('lat')+"&lng="+that.data('lng');
        }else{
            window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:"+that.data('lat')+","+that.data('lng')+";title:"+that.data('name')+";addr:"+that.data('addr');
        }
        return false;
    });
});
function dh_jump(jmpurl){
    if(typeof mag !== 'undefined'){
        mag.newWin(GSITE+jmpurl);
        return false;
    }
    if(typeof sq !== 'undefined'){
        sq.urlRequest(GSITE+jmpurl);
        return false;
    }
    if(typeof wx !=='undefined'){
        if (window.__wxjs_environment === 'miniprogram') {
            GSITE = GSITE.replace(/http:\/\//, 'https://');
            wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
            return false;
        }
    }
    if(typeof QFH5 !== 'undefined'){
        QFH5.jumpNewWebview(GSITE+jmpurl);
        return false;
    }
    window.location.href = jmpurl;
    return false;
}
function dh_setlist(that, ext){
    page = 1;
    loadingurl = window.location.href+'&'+that.data('query')+ext+'&ac=myshop_li&inajax=1&page=';
    that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
    DOAPPEND = 0;
    $.ajax({
        type: 'get',
        url: loadingurl+''+page,
        dataType: 'xml',
        success: function (data) {
            lockIng = 0;
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('#loading-show').addClass('hidden');
            if(!s){
                $('#loading-show').addClass('hidden');
                $('#loading-none').removeClass('hidden');
                setTimeout(function () {
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                }, 300);
                $("#list").html(s);
                page = -1;
                return ;
            }
            $("#list").html(s);
            page ++;
        },
        error: function() {
            lockIng = 0;
        }
    });
}
function dh_getlocation(callback){
    if(0&&typeof mag != 'undefined'){
        mag.getLocation(function(res){
            callback(res);
        });
    }else if(typeof sq != 'undefined'){
        sq.getLocation(function(res){
            callback(res);
        });
    }else if(typeof QFH5 != 'undefined') {
        QFH5.getLocation(function (state, data) {
            if (state == 1) {
                callback(data);
            } else {
                alert(data.error);
            }
        });
    }else if(HB_INWECHAT&& DH_MULTIUPLOAD) {
        wx.getLocation({
            type: 'gcj02',
            success: function (res) {
                callback(res);
            },
            cancel: function (res) {
            }
        });
    }else{
        console.log('myapp');
        var geolocation = new qq.maps.Geolocation(mkey, "myapp");
        geolocation.getLocation(callback, function () {
        }, {timeout:4000, failTipFlag:true});
    }
}
function dh_getnext(id, name, datahref){
    $('.sub_check a').removeClass('checked').removeClass('main_color');
    $('.sub_check a').parent().removeClass('checked').removeClass('main_color');
    $('#sub_check'+id).addClass('checked').addClass('main_color');
    $.ajax({
        type: 'get',
        url: _APPNAME + '?id=xigua_hb&ac=chosecity&province='+$('.first_check+.checked').find('a').text()+'&name='+name+'&ctid='+id+'&datahref='+encodeURIComponent(datahref)+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('.ajaxbox_cheker').html(s);
        }
    });
}
function dh_dotong(pubid, guo){
    $.showLoading();
    $.ajax({
        type: 'post',
        url: window.location.href + '&ac=manage&inajax=1&shid='+pubid+'&tongguo='+guo,
        data:{formhash:FORMHASH,'domanage':1},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () { $.hideLoading(); }
    });
}