<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/2/15
 * Time: 14:48
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'source/plugin/xigua_dh/common.php';

$dh_config = $_G['cache']['plugin']['xigua_dh'];
$dig_prices = $join_prices = array();
if($dh_config['digtype']){
    foreach (explode("\n", trim($dh_config['digtype'])) as $item) {
        list($tmp_type, $tmp_price) = explode('=', trim($item));
        $tmp_lang = lang_hb('days_'.$tmp_type, 0);
        $dig_prices[$tmp_type] = array(
            'type'  => $tmp_type,
            'title' => lang_hb('zhiding', 0). ($tmp_lang == "days_$tmp_type" ? $tmp_type. lang_hb('day', 0) : $tmp_lang) ."("."$tmp_price".lang_hb('yuan', 0).")",
            'price' => $tmp_price,
        );
    }
}
if($dh_config['joinsize']){
    foreach (explode("\n", trim($dh_config['joinsize'])) as $item) {
        list($tmp_type, $tmp_price) = explode('=', trim($item));
        $tmp_lang = lang_hb('days_'.$tmp_type, 0);
        $join_prices[$tmp_type] = array(
            'type'  => $tmp_type,
            'title' => lang_dh('ruzhu', 0). dh_days_format($tmp_type, $tmp_price),
            'price' => $tmp_price,
            'udays' => dh_days_format($tmp_type, $tmp_price),
        );
    }
}

$status_text = array(
    '0' => lang_dh('status0',0),
    '1' => lang_dh('status1',0),
    '2' => lang_dh('status2',0),
    '3' => lang_dh('status3',0),
);

function dh_hex2rgb($colour, $a){
    if ($colour[0] == '#') {
        $colour = substr($colour, 1);
    }
    if (strlen($colour) == 6) {
        list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
    }
    elseif (strlen($colour) == 3) {
        list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
    }
    else {
        return false;
    }
    $r = hexdec($r);
    $g = hexdec($g);
    $b = hexdec($b);
    return "rgba($r, $g, $b, $a)";
}