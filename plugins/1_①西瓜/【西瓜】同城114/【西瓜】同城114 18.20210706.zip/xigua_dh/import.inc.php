<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/5/23
 * Time: 11:55
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_dh/function.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
if (!$_G['cache']['plugin']['xigua_dh']) {
    loadcache('plugin');
}
$dh_config = $_G['cache']['plugin']['xigua_dh'];
$sjobj = C::t('#xigua_dh#xigua_dh_shangjia');
if($dh_config['hytype'] == 1){
    $hyobj = C::t('#xigua_hs#xigua_hs_hangye');
}else{
    $hyobj = C::t('#xigua_dh#xigua_dh_hangye');
}

$page = max(1, intval($_GET['page']));
$lpp = 16;
$start_limit = ($page - 1) * $lpp;

$pids = $hys = array();
$hy = "";
$list_all = $hyobj->list_all(0, 'id');
foreach ($list_all as $index => $item) {
    if($item['pid']>0){
        $hys[$item['name']] = $item['id'];
        $hy .= '&nbsp;&nbsp;&nbsp;&nbsp;'. $item['name'];
        $pids[$item['name']] = array(
            $item['pid'],
            $list_all[$item['pid']]['name'],
        );
    }
}

if (submitcheck('formhash')) {

    $import = explode("\n", trim($_GET['import']));
    foreach ($import as $index => $item) {
        $line = explode(',', trim($item));
        $name = trim($line[0]);
        $tel = trim($line[1]);
        $hyname = trim($line[2]);

        if(!$sjobj->fetch_by_name($name)){
            $sjobj->insert(array(
                'name' => $name,
                'tel' => $tel,
                'display' => 1,
                'endts' => 2147483647,
                'hangye' => $pids[$hyname][1].' '.$hyname,
                'hangye_id1' => $pids[$hyname][0],
                'hangye_id2' => $hys[$hyname],
                'province' => trim($line[4]),
                'city' => trim($line[5]),
                'district' => trim($line[6]),
                'addr' => trim($line[7]),
                'jieshao' => trim($line[3]),
                'lat' => trim($line[8]),
                'lng' => trim($line[9]),
                'stid' => trim($line[10]),
            ));
        }
    }
    cpmsg(lang_hb('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=import", 'succeed');
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=import");
showtips(lang_dh('import_main_tip', 0) . '<li>'.lang_dh('kyhy',0).$hy.'</li>', 'tips', 1, lang_dh('gssm', 0));
?>
<style>
.mt20{margin-top:20px}
.import{width:800px;height:600px}
</style><?php
echo '<div class="mt20">
<textarea class="import" name="import"></textarea>
';


echo ' <br><input type="submit" name="persubmit" class="btn" value="' . cplang('submit') . '" />';
echo '</div>';
showformfooter(); /*dism��taobao��com*/
