<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/7/15
 * Time: 1:52
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_dh/function.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";

if(!$_G['cache']['plugin']['xigua_dh']){
    loadcache('plugin');
}
global $_G;
$dh_config = $_G['cache']['plugin']['xigua_dh'];

if($dh_config['hytype'] == 1){
    $hyobj = C::t('#xigua_hs#xigua_hs_hangye');
}else{
    $hyobj = C::t('#xigua_dh#xigua_dh_hangye');
}

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;

if(($shid = intval($_GET['shid'])) || ($catadd = intval($_GET['catadd']))){

    if($catadd){  // add
        $res = C::t('#xigua_dh#xigua_dh_shangjia')->fetch_only(0, '*', 1);
        $res['hangye_id2'] = $hangye_id2 = $catadd;
        $shid = 0;
        unset($res['shid']);
    }else{
        $res = C::t('#xigua_dh#xigua_dh_shangjia')->fetch_only($shid, '*');
        $hangye_id2 = intval($res['hangye_id2']);
        unset($res['shid']);
    }

    $catinfo = $hyobj->fetch_by_catid($hangye_id2);


    if(!submitcheck('varsubmit')) {
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=admin_shanghu&shid=$shid&hangye_id2=$hangye_id2&page=$page&catadd=$catadd", 'enctype');
        showtableheader(); /*dism _taobao _com*/
        showtitle($catinfo['name'] . lang_dh('shangjia', 0) . ' - ' . $shid. "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=admin_shanghu&hangye_id2=$hangye_id2&page=$page'> ".lang_dh('back',0)."</a>");


        $listinfo = $hyobj->list_all(1);
        $hyobj->init($listinfo);
        $cat_list = $hyobj->get_tree_array(0);
        $hangye = "<select name=\"editform[hangye_id2]\">";
        foreach ($cat_list as $k => $v) {
            $hangye .= "<optgroup label=\"$v[name]\">";
            foreach ($v['sub'] as $kk => $vv) {
                $s = '';
                if($res['hangye_id2']== $vv['id']){
                    $s = 'selected';
                }
                $hangye .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;$vv[name]</option>";
            }
            $hangye .= '</optgroup>';
        }
        $hangye .= '</select>';


        foreach ($res as $index => $re) {
            if(in_array($index, array('hangye_id1', 'hangye', 'color_title', 'tags', 'viptype',
            'shipin',
            'quanjing',
            'xuanchuan',
            'color',
            'color_title',
            'opentime',
            'shangquan',
            'comments',
            'links',
            'append_img',
            'append_text',
            'hong_num',
            'hong_money',
            'hong_sendnum',
            'shzhangqi',
            'shinsxf',
            'shdiscount',
            'hxpwd',
            'mp3',
            'stids',
            'stida',
            'lastnoti',
            'appid',
            'appkey',
            'openid',
            'pay_ts',
            'tag',
            'tags',
            ))){
                continue;
            }
            if($catadd){
                $re = is_array($re) ? array() : '';
                if(in_array($index, array('endts'))){
                    $re = TIMESTAMP+9999*86400;
                }
                if(in_array($index, array('upts','crts'))){
                    $re = TIMESTAMP;
                }
                if(in_array($index, array('display'))){
                    $re = 1;
                }
                if(in_array($index, array('hangye_id2'))){
                    $re = $catadd;
                }
            }
            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('endts', 'dig_startts', 'dig_endts', 'crts', 'upts','lastnoti'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }
            if(in_array($index, array('display'))){
                $tp = 'radio';
            }
            if(in_array($index, array('hangye_id2'))){
                $tp = $hangye;
            }
            if(in_array($index, array('qr', 'logo'))){
                $tp = 'filetext';
            }
            if($index == 'color'){
                $cs = '<select name="editform[color_title]">';
                foreach ($shcolor as $c_t => $c) {
                    $s = '';
                    if($c== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c_t</option>";
                }
                $tp = $cs;
            }

            if (in_array($index, array('album', 'append_img', 'append_text'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $loopnum = $dh_config['maximg'];
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_dh($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_dh($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                showsetting(lang_dh($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('varsubmit');
        showtablefooter(); /*dism-taobao-com*/
        showformfooter(); /*dism��taobao��com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;
    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        if(!$editform['display']){
            $editform['display'] = 0;
        }else{
            $editform['display'] = 1;
        }
        $editform['color'] = $shcolor[$editform['color_title']];

        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        $endts_u = $editform['endts'];
        $editform['tags'] = trim($editform['tags']);
        $editform['crts'] = strtotime($editform['crts']);
        $editform['upts'] = strtotime($editform['upts']);
        $editform['endts'] = strtotime($editform['endts']);
        $editform['dig_endts'] = strtotime($editform['dig_endts']);
        $editform['dig_startts'] = strtotime($editform['dig_startts']);
        $editform['jieshao'] = htmlspecialchars_decode($editform['jieshao']);

        if(!$editform['uid']){
            $editform['uid'] = 0;
        }
        if(!$editform['hangye_id2']) {
            $editform['hangye_id2'] = $catadd;
        }
        if($editform['hangye_id2']){
            $_hy = $hyobj->fetch_by_catid($editform['hangye_id2']);
            $editform['hangye_id1'] = $_hy['pid'];
            $_hys = $hyobj->fetch_light(array(
                $editform['hangye_id1'],
                $editform['hangye_id2'],
            ), 'id,name', 'id ASC');
            foreach ($_hys as $index => $hy) {
                $editform['hangye'][] = $hy['name'];
            }
            $editform['hangye'] = implode(' ', $editform['hangye']);
        }
        if($editform['album']){
            $editform['album'] = array_filter($editform['album']);
            $editform['album'] = serialize($editform['album']);
        }else{
            $editform['album'] = '';
        }
        if($editform['links']){
            $editform['links'] = array_filter($editform['links']);
            $editform['links'] = serialize($editform['links']);
        }else{
            $editform['links'] = '';
        }
        $editform['append_text'] = array_filter($editform['append_text']);
        $editform['append_img']  = array_filter($editform['append_img']);
        if(!$editform['append_text']){
            $editform['append_text'] = '';
        }else{
            $editform['append_text'] = serialize($editform['append_text']);
        }
        if(!$editform['append_img']){
            $editform['append_img'] = '';
        }else{
            $editform['append_img'] = serialize($editform['append_img']);
        }

        if(!$shid){
            C::t('#xigua_dh#xigua_dh_shangjia')->insert($editform);
        }else{
            $old = C::t('#xigua_dh#xigua_dh_shangjia')->fetch($shid);
            if(!$old['display'] && $editform['display'] && $editform['endts']>TIMESTAMP){
                notification_add($old['uid'],'system', lang_dh('notice_shen', 0),array('url' => "$SCRITPTNAME?id=xigua_dh&ac=view&shid=$shid", 'name' => $old['name'], 'endts' => $endts_u),1);
            }
            C::t('#xigua_dh#xigua_dh_shangjia')->update($shid, $editform);
        }
        cpmsg(lang_dh('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=admin_shanghu&hangye_id2=$hangye_id2&page=$page", 'succeed');
    }

//edit end

}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_dh#xigua_dh_shangjia')->deletes($delete);
        }

        $shids = array();
        foreach ($_GET['row'] as $id => $item) {
            $shids[] = $id;
        }
        if($shids){
            $olds = DB::fetch_all("select * from %t where shid in(%n)", array(
                    'xigua_dh_shangjia',
                    $shids,
            ), 'shid');
        }
        foreach ($_GET['row'] as $id => $item) {

            list($hyid1, $hyid2) = explode('_', $item['hangye_id2']);
            $names = $hyobj->fetch_light(array($hyid1,$hyid2));
            $hangye = $names[$hyid1]['name'].' '. $names[$hyid2]['name'];

            $old = $olds[$id];
            if(!$old['display'] && $item['display']){
                notification_add($old['uid'],'system', lang_dh('notice_shen', 0),array('url' => "$SCRITPTNAME?id=xigua_dh&ac=view&shid=$id", 'name' => $old['name'], 'endts' => dgmdate($old['endts'], 'u')),1);
            }

            C::t('#xigua_dh#xigua_dh_shangjia')->update($id, array('display' => intval($item['display']), 'hangye' => $hangye, 'hangye_id1' => $hyid1,  'hangye_id2' => $hyid2, ));
        }

        cpmsg(lang_dh('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=admin_shanghu&hangye_id2={$_GET['hangye_id2']}&page=$page&display={$_GET['display']}&weishen={$_GET['weishen']}&endts={$_GET['zd']}&display={$_GET['zd']}", 'succeed');
    }

    $wherearr = array();
    if ($hyid = intval($_GET['hangye_id2'])) {
        $pids = array($hyid);
        if ($hyinfo = $hyobj->get_childs_by_pids($hyid)) {
            foreach ($hyinfo as $index => $item) {
                $pids[] = intval($item['id']);
            }
            if ($pids) {
                $wherearr[] = ' hangye_id2 IN(' . implode(',', $pids) . ') ';
            }
        } else {
            $wherearr[] = ' hangye_id2 =' . $hyid;
        }
    }
    $keyword = $_GET['keyword'];
    if ($keyword = stripsearchkey(addslashes($keyword))) {
        $wherearr[] = " (name LIKE '%$keyword%' OR addr LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR tag LIKE '%$keyword%' OR xuanchuan LIKE '%$keyword%' OR tel like '%$keyword%' OR uid like '%$keyword%') ";
    }
    if ($city = daddslashes($_GET['city'])) {
        $wherearr[] = " city='$city' ";
    }
    if ($city = daddslashes($_GET['dist'])) {
        $wherearr[] = " district='$city' ";
    }
    if ($tag = stripsearchkey($_GET['tag'])) {
        $wherearr[] = " tag LIKE '%$tag%' ";
    }
    if ($_GET['display']) {
        $wherearr[] = 'display=1';
    }
    if ($_GET['weishen']) {
        $wherearr[] = 'display=0';
    }
    if ($_GET['endts']) {
        $wherearr[] = 'endts<' . TIMESTAMP;
    }
    if ($_GET['zd']) {
        $wherearr[] = 'dig_endts>' . TIMESTAMP;
    }
    $ob = ' shid DESC';

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=admin_shanghu&hangye_id2={$_GET['hangye_id2']}&page=$page");
?>
<style>
    .abtn{padding:3px 6px;background: #ff7d2d;color: #fff;vertical-align:middle}
</style>
    <?php
    echo '<div style="height:1px;width:100%"></div><div><input type="text" id="keyword" name="keyword" value="' . $_GET['keyword'] . '"  style="width:260px" placeholder="'.lang_dh('bef',0).'" /> ';
    echo '<input type="checkbox" name="display" value="1" ' . ($_GET['display'] ? 'checked' : '') . ' />' . lang_dh('yishen', 0);
    echo '<input type="checkbox" name="weishen" value="1" ' . ($_GET['weishen'] ? 'checked' : '') . ' />' . lang_dh('weishen', 0);
    echo '<input type="checkbox" name="endts" value="1" ' . ($_GET['endts'] ? 'checked' : '') . ' />' . lang_dh('yiguoqi', 0);
    echo '<input type="checkbox" name="zd" value="1" ' . ($_GET['zd'] ? 'checked' : '') . ' />' . lang_dh('zhiding', 0);
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" />';
    echo ' <a class="abtn" href="'.ADMINSCRIPT . '?action=plugins&operation=config&do='.$pluginid.'&identifier=xigua_dh&pmod=admin_shanghu&catadd=1">'.lang_dh('shadd', 0).'</a>';
    echo '</div>';

    showtableheader(lang_dh('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_dh('del', 0),
        lang_dh('shenhe', 0),
        lang_dh('shijianguozhi', 0),
        lang_dh('cat', 0),
        lang_dh('fuk', 0),
        lang_dh('ziliao', 0),
        lang_dh('imglist', 0),
        lang_dh('liulanfenxiang', 0),
        lang_dh('caozuo', 0),
        lang_dh('crts', 0) . '/' . lang_dh('upts', 0),
    ));

    $res = C::t('#xigua_dh#xigua_dh_shangjia')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = C::t('#xigua_dh#xigua_dh_shangjia')->fetch_count_by_page($wherearr);

    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }

    $listinfo = $hyobj->list_all(1);
    $hyobj->init($listinfo);
    $cat_list = $hyobj->get_tree_array(0);
    $hangye = "<select name=\"\" >";
    foreach ($cat_list as $k => $v) {
        $hangye .= "<optgroup label=\"$v[name]\">";
        foreach ($v['sub'] as $kk => $vv) {
            $hangye .= "<option value=\"{$vv['pid']}_{$vv['id']}\">&nbsp;&nbsp;$vv[name]</option>";
        }
        $hangye .= '</optgroup>';
    }
    $hangye .= '</select>';


    foreach ($res as $v) {
        $id = $v['shid'];

        $cat_row = str_replace(
            array("<option value=\"{$v['hangye_id1']}_{$v['hangye_id2']}\"", 'name=""'),
            array("<option selected value=\"{$v['hangye_id1']}_{$v['hangye_id2']}\"", "name=\"row[$id][hangye_id2]\""), $hangye
        );

        $checked = $v['display'] ? 'checked' : '';


        $img = $v['logo'] ? "<a href='{$v['logo']}' target='_blank'><img src='{$v['logo']}' style='width:40px;height:40px;' /></a>  " : '';
        $img .= $v['qr'] ? "<a href='{$v['qr']}' target='_blank'><img src='{$v['qr']}' style='width:40px;height:40px;' /></a>  " : '';
        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $c = ($v['endts'] < TIMESTAMP ? 'style="color:red"><em>'.lang_dh('yiguoqi',0).'</em' : 'style="color:forestgreen"');

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id ",
            "<input type='hidden' name='row[$id][id]' value='$id' /><input type='checkbox' class='checkbox' name='row[$id][display]' $checked value='1' />",
            lang_dh('shijianguozhi', 0).': '."<span $c>" .($v['endts'] ? dgmdate($v['endts'], 'Y-m-d H:i') : '-' ) . '</span><br>'.
            lang_dh('dig_startts', 0).': '. ($v['dig_startts'] ? (dgmdate($v['dig_startts'], 'Y-m-d H:i')) : '-').'<br>'.
            lang_dh('dig_endts', 0).': '. ($v['dig_endts'] ? (dgmdate($v['dig_endts'], 'Y-m-d H:i')) : '-'),
            $cat_row,
            ($v['uid'] ?  'UID:' . $v['uid'] . '<br>' . $users[$v['uid']]['username'] : ''),
            lang_dh('shname', 0) . ':<b>' . $v['name'] . '</b><br>' . lang_dh('tel', 0) . ':' . $v['tel'] .
            '<div style="width:200px;max-height:150px;overflow-y:auto">' .
            ($v['tag'] ? "<b style=\"color:forestgreen\">{$v['tag']}</b><br>" : '') .
            '<br>'.lang_dh('jianjie', 0) .' : '. strip_tags($v['jieshao']) .
            ('<br><br>'.lang_dh('plugins_edit_vars_type_area', 0) .' : '.$v['province'] . ' ' . $v['city'] . ' ' . $v['district'] . ' ' . $v['street'] . ' ' . $v['street_number'] . '<br>' . $v['addr'] . '<br>'.lang_dh('jwd',0).' : ' . $v['lat'] . ',' . $v['lng']).
            '</div>',

            '<div style="width:200px;max-height:100px;overflow-y:auto">' . $img . '</div>',

            $v['views'] . '/' . $v['shares'] . '/' . $v['follow'],

            '<a class="abtn" href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=admin_shanghu&shid=$id" . '">' . lang_dh('moreprofile', 0) . '</a>',
            $v['crts_u'] . '<br>' . $v['upts_u'],
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=admin_shanghu&" . http_build_query($_GET) . "&hangye_id2={$_GET['hangye_id2']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_dh&pmod=admin_shanghu&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dism-taobao-com*/
    showformfooter(); /*dism��taobao��com*/
}