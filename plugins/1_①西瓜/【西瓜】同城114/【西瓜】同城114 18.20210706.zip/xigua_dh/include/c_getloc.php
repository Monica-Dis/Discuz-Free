<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/11/26
 * Time: 19:28
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if ($_GET['do']=='dhtc'){
    global $_G;
    $i = 0;
    $vips = array();
    foreach (explode("\n", trim($dh_config['taocan'])) as $index => $item) {
        list($pr, $tim ,$cishu) = explode('#', $item);
        $pr = floatval($pr);
        $cishu = intval($cishu);
        $vips[$pr] = array(
            'id' => $pr,
            'name' => $pr.lang('plugin/xigua_hb', 'yuan'). $cishu . lang('plugin/xigua_hb', 'c'),
            'desc' => lang('plugin/xigua_hb', 'pay1')." <em class='color-red2'>$pr". lang('plugin/xigua_hb', 'yuan').' </em>'.lang('plugin/xigua_hb', 'goumai') ."<em class='color-red2'> $cishu".lang('plugin/xigua_dh', 'cchdh') .' </em>&nbsp;&nbsp;'. lang('plugin/xigua_hb', 'lastts').' <em class=\'color-red2\'>'.$tim.lang('plugin/xigua_hb', 'day').'</em>',
            'times' => $cishu,
            'yxq' => $tim,
        );
    }
    $url = "$SCRITPTNAME?id=xigua_dh&ac=getloc&do=dhtc$urlext";
    if(submitcheck('formhash')){
        $vp = floatval($_GET['form']['viptype']);
        if($vp>0 && $vips[$vp]['times']>0){
            $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $vp, lang('plugin/xigua_hb', 'goumai').$vips[$vp]['desc'], 'com', array(
                'data' => array(
                    'uid' => $_G['uid'],
                    'times' => $vips[$vp]['times'],
                    'yxq' => $vips[$vp]['yxq'],
                    'desc' => $vips[$vp]['desc'],
                    'price' => $vp,
                ),
                'callback' => array(
                    'file' => 'source/plugin/xigua_dh/function_taocan.php',
                    'method' => 'dh_taocan_callback'
                ),
                'location' => $_G['siteurl'] . $url,
            ));
            $rl = urlencode($url);
            $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl" . $urlext) . $urlext;
            hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
        }
    }else{
        $mytcan = DB::fetch_first('select * from %t where uid=%d', array('xigua_dh_taocan', $_G['uid']));
        $custom_side = array(
            "$SCRITPTNAME?id=xigua_dh&ac=my114".$urlext,
            lang_dh('my114', 0)
        );
        $navtitle = lang_dh('gmtc', 0);
        include template('xigua_dh:dhtc');
    }
    exit;
}elseif ($_GET['do']=='showjie'){
    if($page<=1) {
        $v = $sjobj->fetch_by_shid($shid);
    }
    include template('xigua_hb:header_ajax');
    if($v){
        echo '<div style="background: #fff;padding: 15px;color: #333;">';
        echo dh_nl2br($v['jieshao']);
        echo '</div>';
    }elseif($page<=1){
        echo '<div style="background: #fff;padding: 15px;color: #333;">';
        echo lang_hb('zanwu', 0);
        echo '</div>';
    }
    include template('xigua_hb:footer_ajax');
    exit;
}elseif($_GET['do']=='telpay'){
    $_GET['rl'] = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : $_G['siteurl']."$SCRITPTNAME?id=xigua_dh&ac=view&shid={$shid}$urlext";
    $hyid = intval($_GET['hyid']);
    $shid = intval($_GET['shid']);

    if($_GET['usetc']){
        $mytcan = DB::fetch_first('select * from %t where uid=%d', array('xigua_dh_taocan', $_G['uid']));
        if(!$mytcan){
            hb_message(lang_dh('qgm', 0), 'error', "$SCRITPTNAME?id=xigua_dh&ac=getloc&do=dhtc$urlext");
        }
        if($mytcan['endts']<TIMESTAMP){
            hb_message(lang_dh('tcygq', 0), 'error', "$SCRITPTNAME?id=xigua_dh&ac=getloc&do=dhtc$urlext");
        }
        if($mytcan['total']<1){
            hb_message(lang_dh('tcyyw', 0), 'error', "$SCRITPTNAME?id=xigua_dh&ac=getloc&do=dhtc$urlext");
        }
        DB::update('xigua_dh_taocan' , array(
            'total' => $mytcan['total']-1,
            'used' => $mytcan['used']+1,
        ), array('uid' => $_G['uid']));
        DB::insert('xigua_hb_viewtel' , array(
            'uid' => $_G['uid'],
            'crts' => TIMESTAMP,
            'pubid' => $shid,
            'idtype' => 'dhid'
        ));
        hb_message(lang_dh('sycg', 0), 'success', 'reload');
        exit;
    }

    $telprice = DB::result_first('select telprice from %t where id=%d', array(
        'xigua_dh_hangye',
        $hyid
    ));
    $sh = $shdata = $sjobj->fetch_by_shid($shid, 0);;
        $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $telprice, lang_hb('ckxxjg', 0). $sh['name'] ."(ID:$shid)", 'common_dhtelpay', array(
            'data' => array(
            'uid' => $_G['uid'],
            'price' => $telprice,
            'hyid' => $hyid,
            'shid' => $shid,
        ),
        'callback' => array(
            'file' => 'source/plugin/xigua_dh/function_telpay.php',
            'method' => 'dh_telpay_callback'
        ),
        'location' => $_GET['rl'],
    ));

    $rl = urlencode($_GET['rl']);
    $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
    hb_message(lang_hb('tiaozhuan',0), 'success', $jumpurl);
}else{
$ret = dh_current_location($_GET['lat'], $_GET['lng']);
if(is_array($ret)){
    if($_GET['checkst'] && $_G['cache']['plugin']['xigua_st']){
        $geoinfo = dh_multi_diconv($ret[0]['address_component'],'utf-8', CHARSET);

        if($rs = DB::fetch_first("select `stid`,area3 from %t where area3<>'' AND `area3` IN (%n)", array('xigua_st', $geoinfo))) {
            hb_message(implode(',', $rs).','.implode(',', $geoinfo), 'success');
        }
        if($rs = DB::fetch_first("select `stid`,area2 from %t where area2<>'' AND `area2` IN (%n) AND area3=''", array('xigua_st', $geoinfo))) {
            hb_message(implode(',', $rs).','.implode(',', $geoinfo), 'success');
        }
        if($rs = DB::fetch_first("select `stid`,area2 from %t where area1<>'' AND `area1` IN (%n) AND area2='' AND area3=''", array('xigua_st', $geoinfo))) {
            hb_message(implode(',', $rs).','.implode(',', $geoinfo), 'success');
        }
        hb_message('error', 'error');
    }

    if($_GET['checkallow']&&$config['areaallow']){
        $areaallow = array_filter(explode("\n", trim($config['areaallow'])));
        foreach ($areaallow as $index => $item) {
            $areaallow[$index] = trim($item);
        }
        if($areaallow){
            $ar1 = dh_multi_diconv($ret[0]['address_component'],'utf-8', CHARSET);
            if(!array_intersect($ar1, $areaallow)){
                hb_message(lang_hb('notallowq1',0).implode(',', $ar1).lang_hb('notallowq2',0).implode(',', $areaallow), 'error');
            }
        }
    }

    if($_GET['geoauto']){
        $geoinfo = dh_multi_diconv($ret[0]['address_component'],'utf-8', CHARSET);
        if($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['district']))){
            hb_message($rs.':dist='.urlencode($rs), 'success');
        }
        if($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['city']))){
            hb_message($rs.':city='.urlencode($rs), 'success');
        }
        if($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['province']))){
            hb_message($rs, 'success');
        }
        hb_message('error', 'error');
    }

    hb_message(json_encode($ret), 'success');
}else{
    hb_message($ret, 'error');
}
}