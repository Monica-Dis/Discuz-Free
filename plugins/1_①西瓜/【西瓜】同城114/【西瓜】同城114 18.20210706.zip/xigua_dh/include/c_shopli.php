<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/11/26
 * Time: 19:28
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($list){


    $dhshids = $hyids2 = array();
    foreach ($list as $index => $item) {
        $hyids2[] = $item['hangye_id2'];
        $dhshids[] = $item['shid'];
    }
    if($hyids2){
        if($_G['uid']>0){
            $viewtels = C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], $dhshids, 'dhid');
        }

        $hyprices = DB::fetch_all('select telprice,id from %t where id in(%n)', array(
            'xigua_dh_hangye',
            $hyids2
        ), 'id');
        foreach ($list as $index => $item) {
            $list[$index]['price_view'] = $viewtels[$item['shid']] ? 0 : floatval($hyprices[$item['hangye_id2']]['telprice']);
        }
    }
}elseif($_GET['ac']=='view' && $v){
    if($_G['uid']>0){
        $viewtels = C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], array($v['shid']), 'dhid');
    }

    $hyprices = DB::fetch_all('select telprice,id from %t where id in(%n)', array(
        'xigua_dh_hangye',
        array($v['hangye_id2'])
    ), 'id');

    $v['price_view'] = $viewtels[$v['shid']] ? 0 : floatval($hyprices[$v['hangye_id2']]['telprice']);
}