<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function dh_cm($shid){
    if(!C::t('#xigua_dh#xigua_dh_shangjia')->checkmine($shid)){
        if(!IS_ADMINID){
            if($_GET['inajax'] ) {
                hb_message('not allowed', 'error');
            }else{
                $msg = lang_dh('not allowed', 0);
                include template('xigua_dh:alert');
            }
        }
    }
}
function lang_dh($lang, $echo = 1){
    $ret = lang('plugin/xigua_dh', $lang);
    if($echo){
        echo $ret;
    }else{
        return $ret;
    }
}
function dh_days_format($days, $price) {
    $price = str_replace('.00', '', $price);
    if($days >= 365) {
        $return= intval($days/365).lang_dh('nian', 0).'/';
    } elseif($days >= 30) {
        $return= intval($days/30).lang_dh('yue1', 0).'/';
    } elseif($days >= 1) {
        $return= intval($days).lang_dh('ri', 0).'/';
    }else{
        $return= '';
    }
    if($days == '9999'){
        $return = lang_dh('yongjiu', '0');
    }
    $return .= ($price>0? $price.lang_dh('yuan', 0) : lang_dh('mf',0));
    return $return;
}

function dh_qrcode_make($mpid, $url, $avatar = ''){

    global $SCRITPTNAME, $dh_config, $_G,$urlext;

    if($dh_config['typewx'] ==2){
        $upar = parse_url($url);
        $hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_dh&ac=view&shid=$mpid&x=1");

        $_qrfile = './source/plugin/xigua_dh/cache/sh' . $mpid . '.jpg';
        if (!is_file(DISCUZ_ROOT . $_qrfile)){
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')){
                QRcode::png($hb_currenturl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
            }
        }
        $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&logo='.urlencode($avatar).'&url='.$hb_currenturl;
        return $shqr;
    }else{
        $config = $_G['cache']['plugin']['xigua_hb'];
        if($config['qraut']){
            return "$SCRITPTNAME?id=xigua_hb:qrauto&ode=dh_{$mpid}{$urlext}";
        }
        $repath = './source/plugin/xigua_dh/cache/';
        $qrfile = $repath . $mpid . '.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;

        if(!is_file($abs_qrfile)) {
            if (!is_file($abs_qrfile)) {
                @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                if(class_exists('QRcode')){
                    QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
                }
            }
        }
        return $qrfile;
    }
}


function hppostx($lang, $vars){
    global $adminids;
    if($adminids){
        $adminids = array_slice($adminids,0,10);
        foreach ($adminids as $adminid) {
            notification_add($adminid,'system', $lang, $vars, 1);
        }
    }
}

function dh_get_location_google($lat, $lng){
    global $dh_config;
    $latlng = $lat.','.$lng;
    $rs = hb_curl('https://maps.googleapis.com/maps/api/geocode/json?latlng='.$latlng.'&sensor=true&language=zh-CN&key='.$dh_config['google']);
    if($rs = json_decode($rs, TRUE)){
        if($rs['error_message']){
            return dh_multi_diconv($rs['status'].':'.$rs['error_message'], 'utf-8', CHARSET);
        }elseif($rs['results']){
            $r = array();
            $r['province'] = $rs['results'][0]['address_components'][5]['long_name'];
            $r['city'] = $rs['results'][0]['address_components'][4]['long_name'].' '.$rs['results'][0]['address_components'][3]['long_name'];
            $r['district'] = $rs['results'][0]['address_components'][2]['long_name'];
            $r['street'] = $rs['results'][0]['address_components'][1]['long_name'];
            $r['street_number'] = $rs['results'][0]['address_components'][0]['long_name'];
            $r['addr'] = str_replace(array($r['province'], $r['city']), '', $rs['results'][0]['formatted_address']);

            $rt = array();
            $rt[] = array(
                'address'           => $r['addr'],
                'address_component' => array(
                    'province' => $r['province'],
                    'city'     => $r['city'],
                    'district' => $r['district'],
                    'street'   => $r['street'],
                    'street_number'=>$r['street_number'],
                ),
                'location'          => array(
                    'lat' => $lat,
                    'lng' => $lng,
                ),
                'category' => diconv(lang_dh('default', 0), CHARSET, 'utf-8'),
            );
            return  dh_multi_diconv($rt, 'utf-8', 'utf-8');
        }
    }
    return 'api error';
}

function dh_current_location($lat, $lng){
    global $dh_config;
    if($dh_config['google']){
        return dh_get_location_google($lat, $lng);
    }
    $url = "http://apis.map.qq.com/ws/geocoder/v1/?location=$lat,$lng&coord_type=5&get_poi=1&key=".$dh_config['skey'];
    $ret = hb_curl($url);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        $rt = array();
        $rt[$ret['result']['address']] = array(
            'address'           => str_replace(array($ret['result']['address_component']['province'], $ret['result']['address_component']['city']), '', $ret['result']['address']),
            'address_component' => array(
                'province' => $ret['result']['address_component']['province'],
                'city'     => $ret['result']['address_component']['city'],
                'district' => $ret['result']['address_component']['district'],
                'street'   => $ret['result']['address_component']['street'],
                'street_number'=>$ret['result']['address_component']['street_number'],
            ),
            'location'          => $ret['result']['location'],
            'category'          => diconv(lang_dh('default', 0), CHARSET, 'utf-8'),
        );
        foreach ($ret['result']['pois'] as $index => $pois) {
            $rt[$pois['address']] = array(
                'address'           => str_replace(array($pois['ad_info']['province'], $pois['ad_info']['city']), '', $pois['address']),
                'address_component' => array(
                    'province' => $pois['ad_info']['province'],
                    'city'     => $pois['ad_info']['city'],
                    'district' => $pois['ad_info']['district'],
                    'street'   => '',
                    'street_number'=> '',
                ),
                'location'          => $pois['location'],
                'category'          => $pois['category'],
            );
        }
        $rt = array_values($rt);
        return  dh_multi_diconv($rt, 'utf-8', 'utf-8');
    }else{
        return dh_multi_diconv($ret['message'], 'utf-8', CHARSET);
    }
}
function dh_multi_diconv($string, $in_charset, $out_charset){
    if (is_array($string)) {
        foreach ($string as $key => $val) {
            $string[ $key ] = dh_multi_diconv($val, $in_charset, $out_charset);
        }
    } else {
        $string = diconv($string, $in_charset, $out_charset);
    }
    return $string;
}

function dh_join_callback($param){
    global $join_prices,$_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];

    $shid = intval($data['shid']);
    /*$vipinfo = $join_prices[$data['viptype']];*/

    $endts = TIMESTAMP + $data['viptype'] * 86400;
    C::t('#xigua_dh#xigua_dh_shangjia')->update($shid, array('endts' => $endts, 'display' => 1));

    global $SCRITPTNAME,$adminids;
    if($adminids){
        $_lang = lang_dh('new_in',0);
        $_vars=array('url' => "{$_G['siteurl']}$SCRITPTNAME?id=xigua_dh&ac=view&shid=$shid".$urlext, 'id'=>$shid);
        foreach ($adminids as $adminid) {
            notification_add($adminid,'system', $_lang, $_vars, 1);
        }
    }
    return true;
}
function dh_xufei_callback($param){
    global $join_prices,$_G,$urlext;
    $info = $param['info'];
    $data = $info['data'];

    $shid = intval($data['shid']);
    C::t('#xigua_dh#xigua_dh_shangjia')->update($shid, array('endts' => $data['ents'], 'display' => 1, 'viptype' => $data['newviptype']));
    global $SCRITPTNAME,$adminids;
    if($adminids){
        $_lang = lang_dh('new_in',0);
        $_vars=array('url' => "{$_G['siteurl']}$SCRITPTNAME?id=xigua_dh&ac=view&shid=$shid".$urlext, 'id'=>$shid);
        foreach ($adminids as $adminid) {
            notification_add($adminid,'system', $_lang, $_vars, 1);
        }
    }
    return true;
}

function dh_postx($lang, $vars){
    global $adminids;
    if($adminids){
        $adminids = array_slice($adminids,0,10);
        foreach ($adminids as $adminid) {
            notification_add($adminid,'system', $lang, $vars, 1);
        }
    }
}

function dh_pay_callback($param = ''){
    return $param;
}

function dh_dig_callback($param){
    $info = $param['info'];
    $data = $info['data'];
    $shid = intval($data['shid']);

    $old_data = C::t('#xigua_dh#xigua_dh_shangjia')->fetch($shid);

    $replace = array(
        'dig_endts' => max(TIMESTAMP, $old_data['dig_endts'])+ (86400*$data['dig_days']),
        'dig_startts' => TIMESTAMP,
    );
    C::t('#xigua_dh#xigua_dh_shangjia')->update($shid, $replace);

    return true;
}

function dh_renling_callback($param){
    global $_G;
    $dh_config = $_G['cache']['plugin']['xigua_dh'];
    $info = $param['info'];
    $data = $info['data'];
    $shid = intval($data['shid']);
    $uid = intval($data['uid']);
    $rlid = intval($data['rlid']);

    $replace = array( 'uid' => $uid, 'endts' => TIMESTAMP+$dh_config['renlingents']*86400 );
    C::t('#xigua_dh#xigua_dh_shangjia')->update($shid, $replace);
    C::t('#xigua_dh#xigua_dh_renling')->update($rlid, array('status' => 1, 'upts' => TIMESTAMP));

    return true;
}


function dh_nl2br($txt){
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}

function dh_init(){
    global $gid,$shid,$ac,$do,$svicerange,$dh_config,$aclist,$aclist_login,$_G,$page,$lpp,$start_limit,$uid,$hyobj,$sjobj,$rlobj,$jcobj;
    $gid = intval($_GET['gid']);
    $shid = intval($_GET['shid']);
    $ac = $_GET['ac'];
    $do = $_GET['do'];

    $svicerange = array();
    foreach (explode("\n", trim($dh_config['svicerange'])) as $index => $item) {
        $svicerange[] = trim($item);
    }
    $aclist = array('index','join','my', 'renling', 'dodig','manage', 'chosecity', 'my114', 'view', 'zan', 'shoucun', 'incr', 'follow', 'delfollow', 'mysh', 'none', 'dompdel', 'dodig','xufei','getloc','myshop_li','hangye','follow','googleMap', 'jiucuo','incr','renling_li');
    $aclist_login = array('join','follow','my114','xufei','dodig','manage','renling', 'jiucuo','renling_li');
    if (!in_array($ac, $aclist)) {$ac = 'index';}
    if (in_array($ac, $aclist_login) && !$_G['uid']) { hb_jump_login();}
    $_GET = dhtmlspecialchars($_GET);
    $page = max(1, intval($_GET['page']));
    $lpp   = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
    $start_limit = ($page - 1) * $lpp;
    $uid = $_G['uid'];

    if($dh_config['hytype'] == 1){
        $hyobj = C::t('#xigua_hs#xigua_hs_hangye');
    }else{
        $hyobj = C::t('#xigua_dh#xigua_dh_hangye');
    }
    $sjobj = C::t('#xigua_dh#xigua_dh_shangjia');
    $rlobj = C::t('#xigua_dh#xigua_dh_renling');
    $jcobj = C::t('#xigua_dh#xigua_dh_jiucuo');
}