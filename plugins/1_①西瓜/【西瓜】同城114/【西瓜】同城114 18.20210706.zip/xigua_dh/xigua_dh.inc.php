<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
$dh_config = $_G['cache']['plugin']['xigua_dh'];
$plugi_nid = 'xigua_dh';
$cardtype = array();
foreach (explode("\n", trim($dh_config['cardtype'])) as $index => $item) {
	$cardtype[] = explode('#', trim($item));
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_dh/function.php';
$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$url = rtrim($url, '/') . '/';
dh_init();
switch ($ac) {
	case 'incr':
		if (submitcheck('formhash')) {
			if (in_array($_GET['incr_type'], array('shares'))) {
				$sjobj->incr($shid, $_GET['incr_type']);
				hb_message('success');
			}
		}
		break;
	case 'renling':
		if (submitcheck('formhash')) {
			$ol = $sjobj->fetch($shid);
			if ($ol['uid'] > 0) {
				hb_message(lang_dh('ybrl', 0), 'error');
			}
			$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			if ($do && $dh_config['rprice']) {
				$title = lang_dh('flrl', 0) . $ol['name'];
				$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_dh&ac=my114' . $urlext);
				$rlid = $rlobj->insert(array('uid' => $_G['uid'], 'shid' => $shid, 'crts' => TIMESTAMP, 'verinfo' => $title . $_GET['text'], 'mobile' => $user['mobile'], 'realname' => $user['realname']), 1);
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $dh_config['rprice'], $title, 'common_dhrenling', array('data' => array('shid' => $shid, 'price' => $dh_config['rprice'], 'uid' => $_G['uid'], 'rlid' => $rlid), 'callback' => array('file' => 'source/plugin/xigua_dh/function.php', 'method' => 'dh_renling_callback'), 'location' => $rtl, 'referer' => $rtl));
				$rl = urlencode($rtl);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext);
				$rlobj->update($rlid, array('orderid' => $order_id));
				hb_message(lang_dh('jumppay', 0), 'loading', $jumpurl);
			} else {
				if ($rlobj->fetch_by_uid_shid($_G['uid'], $shid)) {
					hb_message(lang_dh('yjrlqddsh', 0), 'success');
				}
				$rlobj->insert(array('uid' => $_G['uid'], 'shid' => $shid, 'crts' => TIMESTAMP, 'verinfo' => $_GET['text'], 'mobile' => $user['mobile'], 'realname' => $user['realname']));
				hb_message(lang_dh('rlcg', 0), 'success');
			}
		}
		break;
	case 'renling_li':
		$where = array('uid=' . $_G['uid']);
		$list = $rlobj->fetch_all_by_page($start_limit, $lpp, $where);
		include template('xigua_hb:header_ajax');
		include template('xigua_dh:renling_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'jiucuo':
		if (submitcheck('formhash')) {
			$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			$jcobj->insert(array('uid' => $_G['uid'], 'shid' => $shid, 'crts' => TIMESTAMP, 'verinfo' => $_GET['text'], 'mobile' => $user['mobile'], 'realname' => $user['realname']));
			hb_message(lang_dh('tjcg', 0), 'success');
		}
		break;
	case 'my114':
		$navtitle = lang_dh('my114', 0);
		$manage = intval(IS_ADMINID && $_GET['manage']);
		if ($manage) {
			$navtitle = lang_dh('gl114', 0);
		}
		$custom_side = array($SCRITPTNAME . '?id=xigua_hb&ac=my' . $urlext, lang_dh('grzx', 0));
		break;
	case 'manage':
		if (submitcheck('domanage') && IS_ADMINID) {
			$sjobj->manage($shid);
			hb_message(lang_dh('succeed', 0), 'success', 'reload');
		}
		break;
	case 'xufei':
		dh_cm($shid);
		$vtid = intval($_GET['viptype']);
		$vipinfo = $join_prices[$vtid];
		if (!$vipinfo || !$vtid) {
			$msg = lang_dh('ruzhutype', 0);
			include template('xigua_dh:alert');
		}
		$shdata = $sjobj->fetch_by_shid($shid);
		$max = TIMESTAMP;
		if ($shdata['display'] == 1) {
			$max = max(TIMESTAMP, $shdata['endts']);
		}
		$endts = $max + $vipinfo['type'] * 86400;
		$title = lang_dh('xufeisj', 0) . '-' . $shdata['name'] . ' ' . str_replace(array('/'), ' ', $vipinfo['udays']);
		if ($vipinfo['price'] > 0) {
			$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_dh&ac=my114' . $urlext);
			$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $vipinfo['price'], $title, 'common_dhxufei', array('data' => array('shid' => $shid, 'price' => $vipinfo['price'], 'ents' => $endts, 'newviptype' => $vtid), 'callback' => array('file' => 'source/plugin/xigua_dh/function.php', 'method' => 'dh_xufei_callback'), 'location' => $rtl, 'referer' => $rtl));
			$rl = urlencode($rtl);
			$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext);
			dheader('Location: ' . $jumpurl . $urlext);
		} else {
			$sjobj->update($shid, array('endts' => $endts, 'display' => $dh_config['freedis'] ? 0 : 1, 'viptype' => $vtid));
			$msg = lang_dh('xufei_success', 0);
			include template('xigua_dh:alert');
		}
		break;
	case 'dodig':
		if (submitcheck('formhash')) {
			$shdata = $sjobj->fetch_by_shid($shid, 1);
			if (!$shdata) {
				hb_message(lang_dh('not_exists', 0), 'error');
			}
			$digprice = $dig_prices;
			$days = intval($_GET['type']);
			if ($pinfo = $digprice[$days]) {
				$title = $pinfo['title'] . $shdata['name'];
				$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_dh&ac=my114' . $urlext);
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $pinfo['price'], $title, 'common_dhdig', array('data' => array('shid' => $shid, 'price' => $pinfo['price'], 'dig_days' => $days), 'callback' => array('file' => 'source/plugin/xigua_dh/function.php', 'method' => 'dh_dig_callback'), 'location' => $rtl, 'referer' => $rtl));
				$rl = urlencode($rtl);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext);
				hb_message(lang_dh('jumppay', 0), 'loading', $jumpurl);
			}
		}
		break;
	case 'follow':
		if (submitcheck('formhash')) {
			$type = '114';
			if ($old = C::t('#xigua_hb#xigua_hb_follow')->fetch_follow_by_favid_uid($shid, $_G['uid'], $type)) {
				C::t('#xigua_hb#xigua_hb_follow')->deletes(array($old['id']), $type);
				$ret = '-1';
			} else {
				if ($id = C::t('#xigua_hb#xigua_hb_follow')->insert(array('favid' => $shid, 'favtype' => $type, 'uid' => $_G['uid'], 'crts' => TIMESTAMP, 'upts' => TIMESTAMP), true, false, true)) {
					$sjobj->incr($shid, 'follow');
					$ret = $sjobj->fetch($shid);
					$ret = $ret['follow'];
				}
			}
			if ($ret > 0) {
				hb_message($ret, 'success');
			} else {
				hb_message(lang_hb('qxsc', 0), 'success');
			}
		} else {
			$navtitle = lang_hb('wdsc', 0);
		}
		break;
	case 'view':
		if ($_GET['u'] && !$_G['uid']) {
			hb_jump_login();
		}
		$v = $sjobj->fetch_by_shid($shid, 1);
		if (!$v) {
			dheader('Location:' . $SCRITPTNAME . '?id=xigua_dh' . $urlext);
		}
		if ($v['stid'] && !$_GET['st']) {
			dheader('Location:' . $SCRITPTNAME . '?' . http_build_query($_GET) . '&st=' . $v['stid']);
		}
		$hy_ret = $hyobj->fetch_light(array($v['hangye_id1'], $v['hangye_id2']));
		if ($_G['uid']) {
			$followed = C::t('#xigua_hb#xigua_hb_follow')->fetch_follow_by_favid_uid($shid, $_G['uid'], '114');
		}
		if (!$v['uid']) {
			$jiucuourl = $myzlurl = '';
			if ($_G['uid']) {
				$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
				if (!$user['mobile']) {
					$jiucuourl = $myzlurl = $SCRITPTNAME . '?id=xigua_hb&ac=myzl&referer=' . urlencode(hb_currenturl()) . $urlext;
				}
			} else {
				$jiucuourl = $myzlurl = $SCRITPTNAME . '?id=xigua_dh&ac=view&shid=' . $shid . '&u=login' . $urlext;
			}
		}
		$desc = cutstr(strip_tags($v['jieshao']), 80);
		$navtitle = $v['name'];
		$shdata = $v;
		break;
	case 'hangye':
		$hyid = intval($_GET['hyid']);
		$hy = $hyobj->fetch($hyid);
		$navtitle = $hy['name'];
		$pid = $hy['pid'];
		if ($_GET['keyword']) {
			$navtitle = $keyword = stripsearchkey($_GET['keyword']);
		}
		if ($_GET['tag']) {
			$navtitle = stripsearchkey($_GET['tag']);
		}
		$list_all = $hyobj->list_all();
		$hyobj->init($list_all);
		$cat_tree_init = $cat_tree = $hyobj->get_tree_array(0);
		$cat_tree = array_values($cat_tree);
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist0 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist0 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['province']) {
			$distname = $_GET['province'];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if ($distname) {
			$navtitle = $distname . $navtitle;
		}
		if (!$distname) {
			$distname = lang_hb('plugins_edit_vars_type_area', 0);
		}
		$quanname = $_GET['quan'];
		if (!$quanname) {
			$quanname = lang_hb('shangquan', 0);
		}
		$lat = floatval($_GET['lat']);
		$lng = floatval($_GET['lng']);
		$catname = $hy['name'] ? $hy['name'] : lang_hb('quanbu', 0);
		$orderby = $_GET['orderby'];
		$orderby_list = array('' => lang_hb('om', 0), 'near' => lang_dh('juli', 0), 'hot' => lang_hb('zr', 0), 'new' => lang_hb('zx', 0), 'guanzhu' => lang_dh('guanzhu', 0));
		if (!$navtitle) {
			$navtitle = $orderby_list[$orderby] == lang_hb('om', 0) ? lang_hb('quanbu', 0) : $orderby_list[$orderby];
		}
		$custom_side = array($SCRITPTNAME . '?id=xigua_dh&ac=join' . $urlext, lang_dh('wyru', 0));
		$subcat = $cat_tree;
		if ($pid == 0) {
			$subcats = $cat_tree_init[$hyid]['child'];
		}
		$get_tag = array();
		foreach ($_GET as $index => $item) {
			if ($index != 'tag') {
				$get_tag[$index] = $item;
			}
		}
		$query = http_build_query($get_tag);
		$navtitle .= lang_dh('dianhua', 0);
		foreach ($list_all as $index => $item) {
			if ($hyid == $item['id']) {
				$catinfo = $item;
				break;
			}
		}
		if ($hy['share_title']) {
			$anavtitle = $navtitle;
			$navtitle = $hy['share_title'];
		}
		if ($hy['share_desc']) {
			$description = $desc = $hy['share_desc'];
		}
		if (!$desc) {
			$desc = $navtitle;
		}
		if (!$hy['share_pic']) {
			$hy['share_pic'] = $hy['icon'];
		}
		break;
	case 'myshop_li':
		$viewtype = $_GET['viewtype'];
		if (!$viewtype) {
			$viewtype = $orderby = $_GET['orderby'];
		}
		if ($viewtype == 'hy') {
			if ($page <= 1) {
				$list_all = $hyobj->list_all();
				$hyobj->init($list_all);
				$cat_tree_init = $cat_tree = $hyobj->get_tree_array(0);
				$cat_nusm = $sjobj->fetch_all_count();
			}
			include template('xigua_hb:header_ajax');
			include template('xigua_dh:hylist');
			include template('xigua_hb:footer_ajax');
		}
		$manage = IS_ADMINID && $_GET['manage'];
		$field = '*';
		$where = array();
		if ($_GET['is_my'] && $_G['uid'] > 0) {
			if ($manage) {
				$uwh = ' 1 ';
			} else {
				$uwh = 'uid=' . $_G['uid'];
			}
			if ($_GET['hide'] == 1) {
				$where[] = $uwh . ' and (display=0 or (display=1 and endts<' . TIMESTAMP . '))';
			} elseif ($_GET['hide'] == 2) {
				$where[] = $uwh . ' and display=0';
			} else {
				$where[] = $uwh . ' and display=1 and endts>=' . TIMESTAMP;
			}
			$order_by = 'shid desc';
		} else {
			if ($_G['uid'] > 0 && $_GET['fav']) {
				$_lst = C::t('#xigua_hb#xigua_hb_follow')->fetch_all_by_page(array('favtype=\'114\' AND uid=' . $_G['uid']), $start_limit, $lpp);
				$_tp = array();
				foreach ($_lst as $v) {
					$_tp[] = $v['favid'];
				}
				if ($_tp) {
					$where[] = ' shid in (' . implode(',', $_tp) . ')';
				} else {
					$where[] = ' shid=\'abc\' ';
				}
			}
			if (0) {
				$where[] = 'display=1 AND endts>0';
			} else {
				$where[] = 'display=1 AND endts>=' . TIMESTAMP;
			}
			if ($_GET['uid']) {
				$where[] = 'uid=' . intval($_GET['uid']);
			}
			if ($_GET['notshid']) {
				$where[] = 'shid!=' . intval($_GET['notshid']);
			}
			$orary = $sjobj->get_order($viewtype);
			$order_by = $orary['order_by'];
			$field = $orary['field'];
			if ($hyid = intval($_GET['hyid'])) {
				$pids = array($hyid);
				if ($hyinfo = $hyobj->get_childs_by_pids($hyid)) {
					foreach ($hyinfo as $index => $item) {
						$pids[] = intval($item['id']);
					}
					if ($pids) {
						$where[] = ' hangye_id2 IN(' . implode(',', $pids) . ') ';
					}
				} else {
					$where[] = ' hangye_id2 =' . $hyid;
				}
			}
			if ($province = daddslashes($_GET['province'])) {
				$where[] = ' province=\'' . $province . '\' ';
			}
			if ($city = daddslashes($_GET['city'])) {
				$where[] = ' city=\'' . $city . '\' ';
			}
			if ($dist = daddslashes($_GET['dist'])) {
				$where[] = ' district=\'' . $dist . '\' ';
			}
			if ($sq = daddslashes($_GET['quan'])) {
				$where[] = ' shangquan=\'' . $sq . '\' ';
			}
			if ($tag = stripsearchkey($_GET['tag'])) {
				$where[] = ' tag LIKE \'%' . $tag . '%\' ';
			}
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$where[] = ' (name LIKE \'%' . $keyword . '%\' OR addr LIKE \'%' . $keyword . '%\' OR jieshao LIKE \'%' . $keyword . '%\' OR tag LIKE \'%' . $keyword . '%\' OR xuanchuan LIKE \'%' . $keyword . '%\' OR tel like \'%' . $keyword . '%\') ';
		}
		$list = $sjobj->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);
		if ($viewtype == 'near') {
			foreach ($list as $k => $v) {
				$distance = intval($v['distance']);
				if ($distance <= 1000) {
					$distance = intval($distance) . 'm';
				} else {
					if ($distance > 1000) {
						$distance = round($distance / 1000, 1) . 'km';
					}
				}
				$list[$k]['distance'] = $distance;
			}
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_dh:shopli');
		include template('xigua_hb:footer_ajax');
		break;
	case 'index':
		$topnavslider = hb_parse_set($dh_config['topslider']);
		$newest = $sjobj->fetch_newest(5);
		$cat_list = $hyobj->list_by_pid(0, true);
		$jing_list = array_values($cat_list);
		if ($jing_list) {
			$jing_count = range(0, ceil(count($jing_list) / 10) - 1);
		}
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist0 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist0 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if (!$navtitle && $distname) {
			$navtitle = $distname;
		}
		if (!$distname) {
			$distname = lang_hb('plugins_edit_vars_type_area', 0);
		}
		$navtitle = $dh_config['indextitle'];
		$desc = $dh_config['indexdesc'];
		$indeximg = $dh_config['indeximg'];
		if ($_GET['indexorder']) {
			$dh_config['indexorder'] = $_GET['indexorder'];
		}
		if ($_GET['keyword']) {
			$navtitle = lang_dh('ssjg', 0) . $_GET['keyword'];
		}
		$_GET['nav'] = !$_GET['nav'] ? $dh_config['dftindex'] : $_GET['nav'];
		break;
	case 'none':
		break;
	case 'join':
		$navtitle = lang_dh('fabu', 0);
		if (submitcheck('del')) {
			$delid = intval($_GET['del']);
			if (!$sjobj->checkmine($delid)) {
				!IS_ADMINID && hb_message('not allowed!', 'error');
			}
			$sjobj->delete($delid);
			hb_message(lang_dh('xiajia_succeed', 0), 'success', 'reload');
		}
		if (!IS_ADMINID) {
			check_bind(3);
		}
		if (submitcheck('formhash')) {
			if (!$_G['group']['allowreply']) {
				hb_message(lang_hb('no_permission_to_post', 0), 'error');
			}
			$form = $_GET['form'];
			$old_shid = intval($_GET['shid']);
			$form = $_GET['form'];
			$jieshao = strip_tags(htmlspecialchars_decode($form['jieshao']), '<a><abbr><acronym><address><applet><area><b><base><basefont><bdo><big><blockquote><body><br><button><caption><center><cite><code><col><colgroup><dd><del><dir><div><dfn><dl><dt><em><fieldset><font><form><frame><frameset><h1><h2><h3><h4><h5><h6><head><hr><html><i><iframe><img><input><ins><isindex><kbd><label><legend><li><link><map><menu><meta><noframes><noscript><object><ol><optgroup><option><p><param><pre><q><s><samp><script><select><small><span><strike><strong><style><sub><sup><table><tbody><td><textarea><tfoot><th><thead><title><tr><tt><u><ul><var><article><aside><audio><bdi><canvas><command><datalist><details><embed><figcaption><figure><footer><header><hgroup><keygen><mark><nav><output><progress><rp><ruby><source><summary><time><track><video><wbr><rt><section>');
			if (!$form['name']) {
				hb_message(lang_dh('plztitle', 0), 'error');
			}
			$old_data = $sjobj->fetch($old_shid);
			if ($form['name'] != $old_data['name'] && $dh_config['tongming'] && $sjobj->fetch_by_name($form['name'])) {
				hb_message(lang_dh('tmsjycz', 0), 'error');
			}
			if (!$form['province']) {
				hb_message(lang_dh('plzprovince', 0), 'error');
			}
			if (!$form['hangye']) {
				hb_message(lang_dh('plzsuoshuhangye', 0), 'error');
			}
			$hy_ret = $hyobj->fetch_by_name(array_filter(explode(' ', trim($form['hangye']))));
			$form['hangye_ids'] = array_keys($hy_ret);
			if (!$form['addr']) {
				hb_message(lang_dh('plzaddr', 0), 'error');
			}
			if (!$jieshao) {
				hb_message(lang_dh('plzjieshao', 0), 'error');
			}
			if (!$form['lat'] || !$form['lng']) {
				hb_message(lang_dh('plzaddr', 0), 'error');
			}
			$form['tel'] = array_filter($form['tel']);
			if (!$form['tel']) {
				hb_message(lang_dh('plztel', 0), 'error');
			}
			$form['tel'] = array_filter($form['tel']);
			foreach ($form['tel'] as $index => $item) {
				if ($item && !preg_match('/^[0-9\\-]*$/', $item)) {
					hb_message(lang_hb('dianhua2', 0), 'error');
				}
			}
			$form['telname'] = array_filter($form['telname']);
			foreach ($form['telname'] as $index => $item) {
				$form['telname'][$index] = str_replace(' ', '', $item);
			}
			$formqr = $form['qr'][0];
			if (!$formqr) {
			}
			if (!$form['logo']) {
				hb_message(lang_dh('plzshlogo', 0), 'error');
			}
			$viptype = 0 - 1;
			foreach ($join_prices as $index => $join_price) {
				if ($join_price['title'] == $form['viptype']) {
					$viptype = $join_price['type'];
					break;
				}
			}
			if (!$old_shid) {
				if ($viptype == 0 - 1 || !$join_prices[$viptype]) {
					hb_message(lang_dh('ruzhutype', 0), 'error');
				}
			}
			$form['logo'] = $form['logo'][0];
			$form['album'] = serialize($form['album']);
			$data = array('name' => $form['name'], 'hangye' => $form['hangye'], 'hangye_id1' => $form['hangye_ids'][0], 'hangye_id2' => $form['hangye_ids'][1], 'addr' => $form['addr'], 'tel' => implode(' ', $form['tel']), 'telname' => implode(' ', $form['telname']), 'opentime' => $form['opentime'], 'logo' => $form['logo'], 'qr' => $formqr, 'album' => $form['album'], 'lat' => $form['lat'], 'lng' => $form['lng'], 'province' => $form['province'], 'city' => $form['city'], 'district' => $form['district'], 'street' => $form['street'], 'street_number' => $form['street_number'], 'color' => $shcolor[$form['color']], 'color_title' => $form['color'], 'shangquan' => $form['shangquan'], 'jieshao' => $jieshao, 'wxhao' => $form['wxhao'], 'stid' => intval($_GET['st']));
			if (!$old_shid && $data['province'] && $_G['cache']['plugin']['xigua_st']['autotofen']) {
				$_st = C::t('#xigua_st#xigua_st')->fetch_by_dist($data['province'], $data['city'], $data['district']);
				if ($_st['stid']) {
					$data['stid'] = $_st['stid'];
				}
			}
			$referer = $SCRITPTNAME . '?id=xigua_dh&ac=my114' . ($_GET['manage'] ? '&manage=1' : '') . $urlext;
			if (!$old_shid) {
				$data['uid'] = $_G['uid'];
				$data['crts'] = TIMESTAMP;
				$data['upts'] = TIMESTAMP;
				$data['endts'] = 0;
				$data['display'] = 0;
				$data['viptype'] = $viptype;
				$vipinfo = $join_prices[$viptype];
				if ($vipinfo['price'] > 0) {
					$shid = $sjobj->insert($data, true);
					$data['shid'] = $shid;
					dsetcookie('newshid', $shid, 7200);
					$price = $vipinfo['price'];
					$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_dh&ac=my114' . $urlext);
					$title = lang_dh('ruzhu114', 0) . '-' . $data['name'];
					$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price, $title, 'common_dhjoin', array('data' => $data, 'callback' => array('file' => 'source/plugin/xigua_dh/function.php', 'method' => 'dh_join_callback'), 'location' => $rtl, 'referer' => $rtl));
					$rl = urlencode($rtl);
					$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext);
					hb_message(lang_dh('zhiftiao', 0), 'success', $jumpurl);
				} else {
					$data['endts'] = TIMESTAMP + $viptype * 86400;
					$data['display'] = $dh_config['freedis'] ? 0 : 1;
					$shid = $sjobj->insert($data, true);
					dsetcookie('newshid', $shid, 7200);
					if ($dh_config['freedis']) {
						$url = $_G['siteurl'] . $SCRITPTNAME . '?id=xigua_dh&ac=my114&hide=2&manage=1' . $urlext;
						dh_postx(lang_dh('new_need_shen', 0), array('url' => $url, 'id' => $shid));
					} else {
						$url = $_G['siteurl'] . $SCRITPTNAME . '?id=xigua_dh&ac=view&shid=' . $shid . $urlext;
						dh_postx(lang_dh('new_in', 0), array('url' => $url, 'id' => $shid));
					}
					hb_message(lang_dh('fabuok', 0), 'success', $referer);
				}
			} else {
				$data['upts'] = TIMESTAMP;
				$shid = $sjobj->update($old_shid, $data);
				hb_message(lang_dh('xiugaiok', 0), 'success', $referer);
			}
			hb_message('error', 'error');
			exit(0);
		} else {
			$hyobj->init($hyobj->list_json());
			$jsary = $hyobj->get_tree_array(0);
			$jsary = array_values($jsary);
			$default_hy = diconv($jsary[0]['name'] . ' ' . $jsary[0]['sub'][0]['name'], 'utf-8', CHARSET);
			if ($_GET['hyid'] && !$_GET['edit']) {
				$jsar = $jspr = array();
				$arr = $hyobj->arr;
				foreach ($arr as $index => $item) {
					$jsar[$item['id']] = $item;
					$jspr[$item['pid']] = $item;
				}
				if ($_hy = $jsar[$_GET['hyid']]) {
					if ($_hy['pid']) {
						$default_hy = diconv($jsar[$_hy['pid']]['name'] . ' ' . $_hy['name'], 'utf-8', CHARSET);
					} else {
						$default_hy = diconv($_hy['name'] . ' ' . $jspr[$_hy['id']]['name'], 'utf-8', CHARSET);
					}
				}
			}
			$cityjson = json_encode($jsary);
			if ($shid = intval($_GET['edit'])) {
				dh_cm($shid);
				$old_data = $sjobj->fetch($shid);
				$old_data = $sjobj->prepare($old_data);
				$navtitle = lang_dh('edit', 0) . $old_data['name'];
			}
		}
		break;
	default:
		if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_dh/include/c_' . $ac . '.php'))) {
			include DISCUZ_ROOT . ('source/plugin/xigua_dh/include/c_' . $ac . '.php');
		}
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_dh/template/touch/' . $ac . '.php'))) {
	include template('xigua_dh:' . $ac);
}