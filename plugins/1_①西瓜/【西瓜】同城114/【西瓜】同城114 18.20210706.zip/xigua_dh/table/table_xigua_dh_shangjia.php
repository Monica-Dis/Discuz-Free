<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_dh_shangjia extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_dh_shangjia';
        $this->_pk = 'shid';

        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function fetch_my_shanghu($uid)
    {
        global $_G;
        $ttl = 7200;
        $key = 'xigua_dh_s'.$uid.'_'.$ttl;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $ttl) {
            $return = C::t('#xigua_dh#xigua_dh_shangjia')->fetch_all_by_where(array('uid='.$uid.' AND display=1 AND endts>='.TIMESTAMP), 0, 100, 'shid DESC');
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        if($_GET['form']['stids']){
            global $_G;
            $data['stids'] = $_GET['form']['stids'];
            $dtnams = explode(',', $data['stids']);
            if($dtnams){
                $stida = DB::fetch_all("select stid from %t where name in (%n)", array('xigua_st', $dtnams), 'stid');
                if(in_array($_G['cache']['plugin']['xigua_st']['zongname'],$dtnams)){
                    $stida[0] = 1;
                }
                $data['stida'] = implode(',', array_keys($stida));
            }
        }

        if($_GET['ac'] == 'enter' && $data['province'] && $_G['cache']['plugin']['xigua_st']['autotofen']){
            $_st = C::t('#xigua_st#xigua_st')->fetch_by_dist($data['province'], $data['city'], $data['district']);
            if($_st['stid']){
                $data['stid'] = $_st['stid'];
            }
        }
        $shid = DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
        if($_GET['hrvrifyid']){
            C::t('#xigua_hr#xigua_hr_verify')->update($_GET['hrvrifyid'], array(
                'shid' =>$shid
            ));
        }
        return $shid;
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false) {
        if($_GET['form']['stids']){
            global $_G;
            $data['stids'] = $_GET['form']['stids'];
            $dtnams = explode(',', $data['stids']);
            if($dtnams){
                $stida = DB::fetch_all("select stid from %t where name in (%n)", array('xigua_st', $dtnams), 'stid');
                if(in_array($_G['cache']['plugin']['xigua_st']['zongname'],$dtnams)){
                    $stida[0] = 1;
                }
                $data['stida'] = implode(',', array_keys($stida));
            }
        }

        if($_GET['ac'] == 'enter' && $data['province'] && $_G['cache']['plugin']['xigua_st']['autotofen']){
            $_st = C::t('#xigua_st#xigua_st')->fetch_by_dist($data['province'], $data['city'], $data['district']);
            if($_st['stid']){
                $data['stid'] = $_st['stid'];
            }
        }
        if($data['endts']){
            $data['lastnoti'] = 0;
        }
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function fetch_by_name($name)
    {
        $result = DB::fetch_first('SELECT * FROM ' . DB::table($this->_table) .' WHERE `name`=%s ', array($name));
        return $result;
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY {$this->_pk} ASC " . DB::limit($start_limit, $lpp));

        return $result;
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'views DESC', $fields= '*')
    {
        global $_G;
        $dh_config = $_G['cache']['plugin']['xigua_dh'];
        if($dh_config['allowst'] && is_array($wherearr) && !defined('IN_ADMINCP')){
            $_stid = intval($_GET['st']);
            $wherearr[] = " (stid=$_stid OR FIND_IN_SET($_stid ,stida)) ";
            global $_G,$stadmin;
            if((!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']) || (/*$dh_config['showfzsh'] && */$_GET['is_my'] && !$stadmin ) ){
                array_pop($wherearr);
            }
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));

        $shids = $hangyeids = array();

        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $shids[] = $item['shid'];
            $hangyeids[] = $item['hangye_id2'];
        }
        if($dh_config['countinlist'] && $shids){
            $this->incr(implode(',', $shids), 'views');
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        global $_G;

        $items = DB::fetch_all("SELECT * FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids) );
        foreach ($items as $index => $item) {
            $item = $this->prepare($item);
            $imglist = array_merge($item['album'], $item['append_img'], array($item['logo'], $item['qr']));
            foreach ($imglist as $img) {
                if (strpos($img, 'xigua_hb/cache') !== false) {
                    $img = str_replace($_G['siteurl'], DISCUZ_ROOT, $img);
                    @unlink($img);
                }
            }
        }

        $re1 = DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
        if($_G['cache']['plugin']['xigua_hm']){
            $re2 = DB::query("DELETE FROM %t WHERE shid IN (%n)", array('xigua_hm_seckill', $ids));
        }
        return $re1 && $re2;
    }


    public function checkmine($shid)
    {
        global $_G;
        $return = DB::result_first("SELECT {$this->_pk} FROM %t WHERE uid=%d AND {$this->_pk}=%d ", array($this->_table, $_G['uid'], $shid));
        return $return;
    }

    public function fetch_simple($id, $field = 'shid,name,logo,addr')
    {
        $data = DB::fetch_first("SELECT $field FROM %t WHERE shid=%d AND endts>".TIMESTAMP, array(
            $this->_table,
            $id
        ));
        return $data;
    }

    public function fetch_uid_by_shid($shid, $need_yuan = 1, $str = 1)
    {
        $uis = array();
        $uis[] = DB::result_first('SELECT uid FROM ' . DB::table($this->_table) .' WHERE `shid`=%d ', array($shid));
        if($need_yuan){
            $yuids = C::t('#xigua_dh#xigua_dh_yuan')->fetch_yuan_by_shid($shid);
            $uis = array_merge($uis, $yuids);
        }
        if($str){
            $uis= implode(',', $uis);
        }
        return $uis;
    }

    public function fetch_by_shid($id, $check = false)
    {
        global $_G;
        if($check){
            $data = DB::fetch_first('SELECT * FROM %t WHERE shid=%d AND display=1 AND endts>'.TIMESTAMP, array(
                $this->_table,
                $id
            ));
        }else{
            $data = parent::fetch($id);
        }
        $this->incr($id, 'views');
        if($data){
            $data = $this->prepare($data);
        }


        return $data;
    }

    public function incr($id, $field, $num = 1)
    {
        static $has = 0;
        if($field == 'views'){
            if($has){
                return null;
            }
            $has = 1;
            if($_GET['mini']=='11'){
                return null;
            }
            if($_GET['ac']=='shcenter'){
                return null;
            }

            global $dh_config;
            if($dh_config['cusview']>1){
                $num = mt_rand(1, $dh_config['cusview']) * $num;
            }
        }
        if(!$field){
            return null;
        }
        if(strpos($id, ',')!==false){
            $id = dintval(array_filter(explode(',', $id)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $id));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
        }
    }

    public function prepare($item)
    {
        if($item){
            global $_G,$SCRITPTNAME;
            $dh_config = $_G['cache']['plugin']['xigua_dh'];

            $item['album'] = $item['album'] ? unserialize($item['album']) : array();
            $item['end'] = ($item['endts'] && $item['endts']<TIMESTAMP);
/*            foreach ($item['album'] as $index => $vvv) {
                $item['album'][$index] = str_replace('http://', 'https://', $vvv);
            }*/
            $item['links'] = $item['links'] ? unserialize($item['links']) : array();
            $item['show'] = array_slice($item['album'], 0, 5);
            $item['append_img'] = $item['append_img'] ? unserialize($item['append_img']) : array();
/*            foreach ($item['append_img'] as $index => $vvv) {
                $item['append_img'][$index] = str_replace('http://', 'https://', $vvv);
            }$item['logo'] = str_replace('http://', 'https://', $item['logo']);*/
            $item['append_text'] = $item['append_text'] ? unserialize($item['append_text']) : array();
            $item['tels'] = $item['tel'] ? explode(' ', trim($item['tel'])) : array();
            $item['telnames'] = $item['telname'] ? explode(' ', trim($item['telname'])) : array();

            $item['tags']    = array_filter(explode(" ", trim($item['tag'])));
            $item['upts_u']  = dgmdate($item['upts'], 'u');
            $item['crts_u']  = dgmdate($item['crts'], 'u');
            $item['endts_u'] = dgmdate($item['endts'], 'u');
            $item['hangyes'] = array_filter(explode(" ", trim($item['hangye'])));
            $item['dig']     = $item['dig_endts']>TIMESTAMP ? 1 : 0;
            if($item['dig_endts'] && !$item['dig']){
                DB::query("update %t set dig_endts=0,dig_startts=0 WHERE {$this->_pk}=%d", array($this->_table,  $item['shid']));
            }
        }
        return $item;
    }

    public function fetch_newest($num = 5)
    {
        global $_G,$SCRITPTNAME;
        $dh_config = $_G['cache']['plugin']['xigua_dh'];
        $orderby = ' shid DESC ';
        $wherearr = array('endts>'.TIMESTAMP);
        if($dh_config['allowst'] && is_array($wherearr) && !defined('IN_ADMINCP')){
            $_stid = intval($_GET['st']);
            $wherearr[] = " (stid=$_stid OR FIND_IN_SET($_stid ,stida)) ";
            global $_G;
            if(!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']){
                array_pop($wherearr);
            }
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT shid,uid,crts,`name`,logo FROM ' . DB::table($this->_table) . " $wheresql  ORDER BY $orderby LIMIT $num");
        foreach ($result as $index => $item) {
            $result[$index]['crts_u'] = dgmdate($item['crts'], 'm-d');
        }
        return $result;
    }

    public function fetch_sh_by_hbcat($cat_id)
    {
        global $_G;
        $hangyes = C::t('#xigua_dh#xigua_dh_hangye')->fetch_by_hbcat($cat_id);
        if(!$hangyes){
            if($cat = C::t('#xigua_hb#xigua_hb_cat')->get_pid_by_childs(array($cat_id))){
                $hangyes = C::t('#xigua_dh#xigua_dh_hangye')->fetch_by_hbcat($cat['pid']);
            }
        }
        $hids = implode(',', array_keys($hangyes));
        if(!$hids){
            return array();
        }
        $where = array('uid='.$_G['uid'].' and display=1 and endts>='.TIMESTAMP);
        if($hids){
            $where[] = " (hangye_id1 IN ($hids) OR hangye_id2 IN ($hids)) ";
        }
        $list = $this->fetch_all_by_where($where, 0, 100, 'upts DESC', 'shid,name');
        return $list;
    }

    public function fetch_count_self($uid)
    {
        $result = DB::result_first('SELECT shid FROM %t WHERE uid=%d ', array($this->_table, $uid));
        return intval($result);
    }

    public function fetch_rank($views = 0)
    {
        $result = DB::result_first('SELECT  count(*) as c FROM %t WHERE views>=%d ORDER BY views DESC', array($this->_table, $views));
        return $result;
    }


    public function count()
    {
        global $_G,$config,$dh_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }
        }

        $key = 'xigua_dh_shangjia_count'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT COUNT(*) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $dh_config['cussh'] + $return;
    }

    public function total_views()
    {
        global $_G,$config,$dh_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }
        }

        $key = 'xigua_dh_shangjia_total_views'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $dh_config['cusview'] + $return;
    }

    public function total_shares()
    {
        global $_G,$config,$dh_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }
        }

        $key = 'xigua_dh_shangjia_total_shares'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(shares) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $dh_config['cusshare'] + $return;
    }

    public function fetch_only($id, $field = '*', $nowhere = 0)
    {
        if(!$id){
            return array (
                'uid' => '0',
                'display' => '0',
                'endts' => '0',
                'dig_endts' => '0',
                'dig_startts' => '0',
                'upts' => '0',
                'crts' => '0',
                'name' => '',
                'hangye' => '',
                'hangye_id1' => '0',
                'hangye_id2' => '0',
                'tel' => '',
                'opentime' => '',
                'jieshao' => '',
                'logo' => '',
                'qr' => '',
                'album' => '',
                'viptype' => '',
                'lat' => '',
                'lng' => '',
                'province' => '',
                'city' => '',
                'district' => '',
                'street' => '',
                'street_number' => '',
                'addr' => '',
                'tags' => '',
                'views' => '0',
                'shares' => '0',
                'comments' => '0',
                'pubs' => '0',
                'follow' => '0',
                'tag' => '',
                'shipin' => '',
                'quanjing' => '',
                'xuanchuan' => '',
                'color' => '',
                'color_title' => '',
                'shangquan' => '',
                'append_img' => '',
                'append_text' => '',
            );
        }
        if($nowhere){
            $data = DB::fetch_first('SELECT '.$field.' FROM '.DB::table($this->_table). " LIMIT 1 ");
        }else{
            $data = DB::fetch_first('SELECT '.$field.' FROM '.DB::table($this->_table).' WHERE '.DB::field($this->_pk, $id));
        }
//        unset($data['hong_num']);
//        unset($data['hong_money']);
//        unset($data['hong_sendnum']);
        return $data;
    }

    function get_distance($latitude1, $longitude1, $latitude2, $longitude2, $unit=1, $decimal=2){

        $EARTH_RADIUS = 6370.996;
        $PI = 3.1415926;

        $radLat1 = $latitude1 * $PI / 180.0;
        $radLat2 = $latitude2 * $PI / 180.0;

        $radLng1 = $longitude1 * $PI / 180.0;
        $radLng2 = $longitude2 * $PI /180.0;

        $a = $radLat1 - $radLat2;
        $b = $radLng1 - $radLng2;

        $distance = 2 * asin(sqrt(pow(sin($a/2),2) + cos($radLat1) * cos($radLat2) * pow(sin($b/2),2)));
        $distance = $distance * $EARTH_RADIUS * 1000;

        if($unit==2){
            $distance = $distance / 1000;
        }

        return round($distance, $decimal);

    }
    public function manage($shid)
    {
        global $SCRITPTNAME,$_G,$join_prices,$urlext;

        if($_GET['tongguo']==1){
            $shinfo = parent::fetch($shid);
            $vtid = intval($shinfo['viptype']);
            $vipinfo = $join_prices[$vtid];
            $data = array( 'display' => 1, );
            $data['endts'] = max(TIMESTAMP, $shinfo['endts']) + ($vipinfo['type'] * 86400);

            $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_dh&ac=view&shid=$shid$urlext";
            notification_add($shinfo['uid'],'system', lang_dh('tongguo_noti', 0),array('id' => $shid,'url' => $url),1);
        }else{
            $data = array('display' => 0);
        }
        parent::update($shid, $data);
        return true;
    }


    public function fetch_discount()
    {
        global $_G;
        $hrs = DB::fetch_first('select uid,viptype,shdiscount from %t WHERE uid=%d and display=1 and endts>=\'' . TIMESTAMP . '\'', array('xigua_dh_shangjia', $_G['uid']), 'viptype');
        $discount = $hrs['shdiscount'];
        if(!$discount && $hrs){
            $discount = DB::result_first('select discount from %t where id=%d ORDER BY discount DESC', array('xigua_dh_vip', $hrs['viptype']));
        }
        return intval(abs($discount));
    }

    public function get_order($viewtype)
    {
        global $dh_config;
        $field = '*';
        switch ($viewtype){
            case "new":
                $order_by = 'dig_endts DESC, shid DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                switch ($dh_config['digorder']){
                    case '3':
                        $order_by = 'distance ASC, dig_startts DESC, dig_endts DESC';
                        break;
                    case '2':
                        $order_by = 'distance ASC, dig_endts DESC';
                        break;
                    default:
                        $order_by = 'distance ASC, (dig_endts-dig_startts) DESC';
                        break;
                }
                break;
            case 'guanzhu':
                $order_by = 'follow DESC';
                break;
            case 'fenxiang':
                $order_by = 'shares DESC';
                break;
            default:
                switch ($dh_config['digorder']){
                    case '3':
                        $order_by = ' dig_startts DESC, dig_endts DESC, views DESC ';
                        break;
                    case '2':
                        $order_by = 'dig_endts DESC, views DESC';
                        break;
                    default:
                        $order_by = ' (dig_endts-dig_startts) DESC, views DESC ';
                        break;
                }
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }

    public function fetch_all_count()
    {
        $res = DB::fetch_all('SELECT hangye_id2,count(*) AS num FROM %t WHERE endts>'.TIMESTAMP.' AND display=1 GROUP BY hangye_id2', array(
            $this->_table
        ));
        $ret = array();
        foreach ($res as $index => $re) {
            $ret[$re['hangye_id2']] = $re['num'];
        }
        return $ret;
    }
}