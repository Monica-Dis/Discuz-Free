<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_dh_renling extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_dh_renling';
        $this->_pk = 'id';


        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $orderby = '')
    {
        if(!$orderby){
            $orderby = "$this->_pk DESC";
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function fetch_by_uid_shid($uid, $shid = 0,  $field = '*')
    {
        $res = DB::fetch_first("select $field from %t WHERE uid=%d AND shid=%d", array($this->_table, $uid,  $shid));
        return $this->prepare($res);
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public function fetch_by_type($id)
    {
        $res = parent::fetch($id);
        $res = $this->prepare($res);
        return $res;
    }

    public function prepare($vipinfo)
    {
        global $status_text;
        if($vipinfo){
            $vipinfo['lock']  = in_array($vipinfo['status'], array(2, 1));
            $vipinfo['status_text'] = $status_text[$vipinfo['status']];
            $vipinfo['zz_ary'] = unserialize($vipinfo['zz']);
            if(!$vipinfo['zz_ary']){
                $vipinfo['zz_ary'] = array($vipinfo['zz']);
            }
        }
        return $vipinfo;
    }

    public function do_delete($id)
    {
        return $this->delete($id);
    }

    public function fetch_qy_ing($uid){
        $rs = DB::fetch_first('SELECT * FROM %t WHERE uid IN (%n)  AND shid=0 AND (status=1 OR status=2)', array($this->_table, $uid), 'uid');
        return $rs;
    }
    public function fetch_veris_bysh($shid = array())
    {
        $rs = DB::fetch_all('SELECT uid, shid FROM %t WHERE shid IN (%n) AND status=1', array($this->_table, $shid), 'shid');
        return $rs;
    }
}