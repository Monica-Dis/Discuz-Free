<?php

function _dh_days_format($days) {

    $return= lang_dh('zs',0).' '.intval($days).lang_dh('ri', 0);

    if($days >= 365) {
        $return= lang_dh('zs',0).' '.intval($days/365).lang_dh('nian', 0);
    } elseif($days >= 30) {
        $return= lang_dh('zs',0).' '.intval($days/30).lang_dh('yue1', 0);
    } elseif($days >= 1) {
        $return= lang_dh('zs',0).' '.intval($days).lang_dh('ri', 0);
    }else{
        $return= '';
    }
    if($days == '9999'){
        $return = lang_dh('yongjiu', '0').lang_dh('zs',0);
    }
    return $return;
}