<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_dh_index` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `types` varchar(20) NOT NULL,
 `style` varchar(20) NOT NULL,
 `catids` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `types` (`types`),
 KEY `catids` (`catids`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_dh_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(200) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(250) NOT NULL,
 `share_title` varchar(200) NOT NULL,
 `share_desc` varchar(200) NOT NULL,
 `share_pic` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_dh_jiucuo` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 `realname` varchar(80) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `verinfo` varchar(800) NOT NULL,
 `status` tinyint(1) NOT NULL,
 `status_info` text NOT NULL,
 `shid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `status` (`status`),
 KEY `upts` (`upts`),
 KEY `shid` (`shid`),
 KEY `uid` (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_dh_renling` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 `realname` varchar(80) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `verinfo` varchar(800) NOT NULL,
 `status` tinyint(1) NOT NULL,
 `status_info` text NOT NULL,
 `shid` int(11) NOT NULL,
 `orderid` varchar(64) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `status` (`status`),
 KEY `upts` (`upts`),
 KEY `shid` (`shid`),
 KEY `uid` (`uid`),
 KEY `orderid` (`orderid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_dh_shangjia` (
 `shid` int(11) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `display` int(1) NOT NULL,
 `name` varchar(80) NOT NULL,
 `tel` varchar(800) NOT NULL,
 `wxhao` varchar(30) NOT NULL,
 `addr` varchar(200) NOT NULL,
 `hangye` varchar(200) NOT NULL,
 `hangye_id1` int(11) NOT NULL,
 `hangye_id2` int(11) NOT NULL,
 `logo` varchar(200) NOT NULL,
 `endts` int(11) NOT NULL,
 `jieshao` text NOT NULL,
 `province` varchar(200) NOT NULL,
 `city` varchar(200) NOT NULL,
 `district` varchar(200) NOT NULL,
 `street` varchar(200) NOT NULL,
 `street_number` varchar(200) NOT NULL,
 `dig_startts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `opentime` varchar(20) NOT NULL,
 `qr` varchar(200) NOT NULL,
 `album` text NOT NULL,
 `viptype` int(11) NOT NULL,
 `lat` varchar(32) NOT NULL,
 `lng` varchar(32) NOT NULL,
 `tags` text NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `comments` int(11) NOT NULL,
 `pubs` int(11) NOT NULL,
 `follow` int(11) NOT NULL,
 `tag` varchar(800) NOT NULL,
 `shipin` varchar(800) NOT NULL,
 `quanjing` varchar(800) NOT NULL,
 `xuanchuan` varchar(80) NOT NULL,
 `color` varchar(20) NOT NULL,
 `color_title` varchar(20) NOT NULL,
 `shangquan` varchar(40) NOT NULL,
 `append_img` text NOT NULL,
 `append_text` text NOT NULL,
 `links` varchar(2000) NOT NULL,
 `hong_num` int(11) NOT NULL,
 `hong_money` decimal(10,2) NOT NULL,
 `hong_sendnum` int(11) NOT NULL,
 `shzhangqi` int(11) NOT NULL,
 `shinsxf` int(11) NOT NULL,
 `shdiscount` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `hxpwd` varchar(20) NOT NULL,
 `mp3` varchar(512) NOT NULL,
 `stids` varchar(200) NOT NULL,
 `stida` varchar(200) NOT NULL,
 `lastnoti` int(11) NOT NULL,
 `appid` varchar(200) NOT NULL,
 `appkey` varchar(200) NOT NULL,
 `openid` varchar(200) NOT NULL,
 `pay_ts` int(11) NOT NULL,
 PRIMARY KEY (`shid`),
 KEY `uid` (`uid`),
 KEY `shangquan` (`shangquan`),
 KEY `dig_endts` (`dig_endts`),
 KEY `endts` (`endts`),
 KEY `hangye_id2` (`hangye_id2`),
 KEY `hangye_id1` (`hangye_id1`),
 KEY `name` (`name`),
 KEY `views` (`views`),
 KEY `shares` (`shares`),
 KEY `display` (`display`),
 KEY `stid` (`stid`),
 KEY `stida` (`stida`),
 KEY `dig_startts` (`dig_startts`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_dh_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_dh_taocan` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) unsigned NOT NULL,
 `name` varchar(200) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `days` int(11) NOT NULL,
 `total` int(11) unsigned NOT NULL,
 `used` int(11) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `order_id` varchar(200) NOT NULL,
 `payts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `uid` (`uid`),
 KEY `endts` (`endts`)
) ENGINE=InnoDB;
SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_dh/discuz_plugin_xigua_dh.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dh/discuz_plugin_xigua_dh_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dh/discuz_plugin_xigua_dh_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dh/discuz_plugin_xigua_dh_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_dh/discuz_plugin_xigua_dh_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_dh/install.php');


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'telname\'', array('xigua_dh_shangjia'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_dh_shangjia` ADD `telname` VARCHAR(800) NOT NULL;

SQL;
    runquery($sql);
}