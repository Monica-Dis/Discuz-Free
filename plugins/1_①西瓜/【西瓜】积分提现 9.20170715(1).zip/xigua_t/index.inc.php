<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/10/11
 * Time: 11:43
 */


include_once DISCUZ_ROOT .'source/plugin/xigua_t/common.php';

if(submitcheck('doamount')){
//    print_r($_GET);
    $default = C::t('#xigua_t#xigua_t_card')->get_default($_G['uid']);
//    print_r($default);


    $ctype = intval($_GET['crtype']);
    $addfundamount = abs(intval($_GET['addfundamount']));
    $amount = round( $addfundamount*((100-$sxf[$ctype])/100)/$bilv[$ctype] , 2);
/*
    print_r($bilv);
    print_r($sxf);
    print_r($_G['setting']['extcredits'][$ctype]['title']);

    print_r($amount);*/

    $processname = 'amount_tx_cache'.$_G['uid'];
    if(!in_array($_G['groupid'], unserialize($config['groupid']))){
        echo lang('plugin/xigua_t', 'noaccess');
        exit;
    }

    if($config['minc']>$addfundamount){
        echo lang('plugin/xigua_t', 'a1').$config['minc'];
        exit;
    }
    if(getuserprofile('extcredits'.$ctype) <$addfundamount){
        echo lang('plugin/xigua_t', 'a2');
        exit;
    }
    if(discuz_process::islocked($processname, 600)) {
        echo lang('plugin/xigua_t', 'txerr');
        exit;
    }

    $txid = C::t('#xigua_t#xigua_t_tixian')->tixian_insert($amount, $default['openid'], $_G['uid'], $default['account'], $default['type'], $default['bank_name'], $default['account_name'], $ctype, $bilv[$ctype], $sxf[$ctype], $addfundamount);

    updatemembercount($_G['uid'], array($ctype => -$addfundamount), 1, 'TFR', $_G['uid']);
    if($config['auto_wx1']){
        $row = C::t('#xigua_t#xigua_t_tixian')->fetch($txid);
        $status = 1;
        $notice = lang('plugin/xigua_t', 'tixiancg').($row['bank_name'] . ($row['account_name'] ? '('.$row['account_name'].') ' : ' ').$row['account']).
            lang('plugin/xigua_t', 'q5').'('.$_GET['note'] .')';

        if($row['type'] =='cwx' && $row['openid']){
            include_once DISCUZ_ROOT .'source/plugin/xigua_t/common.php';
            $amount = intval($row['amount']*100);

            $re = WxPayApiSF::promotion($row['tixianid'], $row['openid'], $amount, diconv(lang('plugin/xigua_t','datixian'), CHARSET, 'UTF-8'));

            if(is_array($re['return_msg'])){
                $re['return_msg'] = var_export($re['return_msg'], TRUE);
            }
            $re['return_msg'] = diconv($re['return_msg'],'UTF-8', CHARSET);
            $re['err_code_des'] = diconv($re['err_code_des'],'UTF-8', CHARSET);

            if($re['result_code'] == 'SUCCESS'){
                $status = 1;
            }else{
                $status = 0;
                echo $re['err_code_des'];
                exit;
            }
            $r = C::t('#xigua_t#xigua_t_tixian')->finish_tixian($txid, $_GET['note'], $status, $re['result_code'], $re['err_code_des'], $re['return_msg'] );
            if($r){
                notification_add(
                    $_G['uid'],
                    'system',
                    $notice,
                    '',
                    1
                );
                notification_add(
                    1,
                    'system',
                    $notice,
                    '',
                    1
                );
                echo lang('plugin/xigua_t', 'succeed');
                exit;
            }
        }
    }else{
        $lang = lang('plugin/xigua_t', $config['auto_wx1'] ? 'a3' : 'czjl');
        notification_add(
            $_G['uid'],
            'system',
            $lang,
            '',
            1
        );
        notification_add(
            1,
            'system',
            $lang."uid({$_G['uid']})",
            '',
            1
        );
        echo $lang;
        exit;
    }

}elseif(submitcheck('methodform')){
    if($_GET['del_id']){
        C::t('#xigua_t#xigua_t_card')->delete($_GET['del_id']);
        if(!C::t('#xigua_t#xigua_t_card')->get_default($_G['uid'])){
            C::t('#xigua_t#xigua_t_card')->revert_default($_G['uid']);
        }
        if(!checkmobile()){
            dheader("location:plugin.php?id=xigua_t&ac=method");
            exit;
        }
        echo $_GET['del_id'];
        exit;
    }
    $types = array(
        'ali'    => lang('plugin/xigua_t', 'ali'),
        'cwx'    => lang('plugin/xigua_t', 'cwx'),
        'cwxnum' => lang('plugin/xigua_t', 'cwxnum'),
        'bank'   => lang('plugin/xigua_t', 'bank'),
    );
    foreach ($_GET['account'] as $index => $item) {
        if($item){
            $type = $index;
            $account = $item;
            break;
        }
    }
    foreach ($_GET['account_name'] as $index => $item) {
        if($item){
            $account_name = $item;
            break;
        }
    }
    if(!$_GET['bank_name'] && $type!='bank'){
        $_GET['bank_name'] = $types[$type];
    }
   $id = C::t('#xigua_t#xigua_t_card')->insert_card($type, $account, $account_name, $_GET['bank_name']);
    if(!checkmobile()){
        dheader("location:plugin.php?id=xigua_t&ac=method");
        exit;
    }
   echo $id;
   exit;
}else if(submitcheck('setdefault')){
   C::t('#xigua_t#xigua_t_card')->set_default($_GET['radio1']);
   dheader('Location: plugin.php?id=xigua_t');
   exit;
}

