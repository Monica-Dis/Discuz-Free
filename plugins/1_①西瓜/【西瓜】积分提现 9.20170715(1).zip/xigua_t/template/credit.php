<?php exit('hehehe!') ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport"
          content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <link href="source/plugin/xigua_t/static/common.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_t/static/iconfont.css?{VERHASH}" rel="stylesheet"/>
    <link href="source/plugin/xigua_t/static/weui.css?{VERHASH}" rel="stylesheet"/>
    <script src="source/plugin/xigua_t/static/jquery.min.js?{VERHASH}"></script>
    <script src="source/plugin/xigua_t/static/custom.js?{VERHASH}"></script>
    <!--{if $config[bgcolor]}-->
    <style>
        .topavatar{background:{$config[bgcolor]}}
        .ullist li p span{color:{$config[bgcolor]}}
        .weui-btn_primary,.weui-btn_primary:not(.weui-btn_disabled):active, .btn-orange{background-color:{$config[bgcolor]}!important}
        .weui-btn_disabled.weui-btn_primary{opacity:.9!important;}
    </style>
    <!--{/if}-->
</head>
<body>
<div id="page-loading-overlay">
    <div class="ajxloading"></div>
</div>
<div class="topnav cl">
    <!--{if $apple}-->
    <!--{else}-->
    <a class="home-return" href="javascript:window.history.go(-1);">{lang xigua_t:back}</a>
    <!--{/if}-->
    <a class="myorder" href="plugin.php?id=xigua_t&ac=order">{lang xigua_t:myorder}</a>
</div>
<div class="container_map_ami container_map">
    <div class="topavatar">
        <div class="pa">
            <div class="avatarimg">
                <a href="home.php?mod=space&uid={$_G[uid]}&do=profile&mycenter=1"><img src="{avatar($_G[uid], 'middle', 1)}"></a>
            </div>
            <span class="username">{$_G[username]}</span>

            <div class="creditid "><ul class="cl">
                <!--{eval $creditid=0;}-->
                <!--{loop $_G['setting']['extcredits'] $id $credit}-->
                    <!--{if $tmp2 && isset($tmp2[$credit[title]]) }-->
            <li><em><!--{if $credit[img]}-->{$credit[img]}<!--{/if}-->{$credit[title]}</em> <!--{echo $myids[] = $v = getuserprofile('extcredits'.$id); $myttile[]=$credit[title]; $mytip[] = '{lang xigua_t:bil}'.$bilv[$id].':1,{lang xigua_t:sx}'.$sxf[$id].'%'; }-->{$credit[unit]}</li>
                    <!--{/if}-->
                <!--{/loop}-->
                </ul>
            </div>
        </div>
    </div>

    <form id="formc" method="post" action="plugin.php?id=xigua_t:index" onsubmit="return submitformc();">
        <input type="hidden" name="doamount" value="1" >
        <input type="hidden" name="formhash" value="{FORMHASH}" >
    <div class="zlistwrap">
        <div class="zlist b cl">
            <div>
                {lang xigua_t:dz}
            </div>
            <div>
                <a href="plugin.php?id=xigua_t&ac=method">
                    <h3>{$default[bank_name]}<!--{if $default[account_name]}-->($default[account_name])<!--{/if}--></h3>
                </a>
                <span class="act">$default[account]</span>
            </div>
        </div>
        <div class="zlist c cl">
            <div>
                {lang xigua_t:txjf}
            </div>
        </div>
        <div class="d cl">
            <div class="form-control">
                <div id="showIOSActionSheet"></div>
                <input type="tel" size="5" class=" customform" onkeyup="if(this.value.length==1){this.value=this.value.replace(/[^1-9]/g,'')}else{this.value=this.value.replace(/\D/g,'')};changebtnval(this.value);" onafterpaste="if(this.value.length==1){this.value=this.value.replace(/[^1-9]/g,'')}else{this.value=this.value.replace(/\D/g,'')}" id="addfundamount" name="addfundamount" value="" placeholder="{$config[yuzhi]}">
            </div>
        </div>
        <div class="zlist d cl">
            <div class="yuer"></div>
        </div>
    </div>
        <div class="zlistwrap">
            <input type="hidden" name="crtype" value="0" />
            <input type="submit"  class="weui-btn weui-btn_primary" id="submitc" value="{lang xigua_t:chongzhi}"/>
        </div>
    </form>

</div>

<div>
    <div class="weui-mask" id="iosMask" style="display: none"></div>
    <div class="weui-actionsheet" id="iosActionsheet">
        <div class="weui-actionsheet__menu">
            <!--{eval $kkk = 0;}-->
            <!--{loop $_G['setting']['extcredits'] $id $credit}-->
            <!--{if $tmp2 && isset($tmp2[$credit[title]]) }-->
            <div class="weui-actionsheet__cell iositem" data-index="$kkk" data-value="$id">$credit[title]</div>
            <!--{eval $kkk++;}-->
            <!--{/if}-->
            <!--{/loop}-->
        </div>
        <div class="weui-actionsheet__action">
            <div class="weui-actionsheet__cell" id="iosActionsheetCancel">{lang xigua_t:q4}</div>
        </div>
    </div>
</div>

<!--BEGIN toast-->
<div id="toast" style="display: none;">
    <div class="weui-mask_transparent"></div>
    <div class="weui-toast">
        <i class="weui-icon-success-no-circle weui-icon_toast"></i>
        <p class="weui-toast__content"></p>
    </div>
</div>
<!--end toast-->
<div id="backtotop" class="backtotop"><span class="icon-vertical-align-top"></span></div>
<script>
var bilv = {eval echo "[".implode(',', $bilv)."]"};
var sxf = {eval echo "[".implode(',', $sxf)."]"};
var totaljf = {eval echo "[".implode(',', $myids)."]"};
var totaljft = {eval echo "['".implode('\',\'', $myttile)."']"};
var yuer = $('.yuer');
var yuerd ={eval echo "['".implode('\',\'', $mytip)."']"};
showcan(0);

function changebtnval(v){
    var index = $('input[name="crtype"]').attr('data-index');
    if(v==''){
        yuer.html(yuerd[index]);
        return showcan(0);
    }
    if(totaljf[index]<v){
        yuer.html('<span class="weui-cell_warn">{lang xigua_t:cc}'+totaljft[index]+'{lang xigua_t:ye}('+totaljf[index]+')</span>');
        return showcan(0);
    }else{
        v = parseInt(v);
        var mny = xround( (v* ((100-sxf[index])/100)/bilv[index]) , 2);
        yuer.html(yuerd[index]+',{lang xigua_t:ke}<span class="weui-cell_warn">'+mny+'{lang xigua_t:yuan}</span>');
        if(mny<1 && '$default[type]'=='cwx'){
            yuer.html('<span class="weui-cell_warn">{lang xigua_t:tx}'+xround(bilv[index]/((100-sxf[index])/100), 0) +totaljft[index]+'</span>');
            return showcan(0);
        }
        showcan(1);
    }
    if(v <$config['minc']){
        yuer.html('<span class="weui-cell_warn">{lang xigua_t:ni}{$config['minc']}'+totaljft[index]+'</span>');
        return showcan(0);
    }
    if($nocard){
        yuer.html('$default[bank_name]');
        return showcan(0);
    }
}
function xround(x, num){
   return Math.round(x * Math.pow(10, num)) / Math.pow(10, num) ;
}
function showcan(can) {
    if(can){
        $('#submitc').removeClass('weui-btn_disabled').removeAttr('disabled');
    }else{
        $('#submitc').addClass('weui-btn_disabled').attr('disabled', 1);
    }
}
var T_loading = 0;
function submitformc() {
    if(T_loading){return ;}
    showcan(0);
    T_loading = 1;
    $.post($('#formc').attr('action'), $('#formc').serialize(), function (data) {
        if(data){
            showtip(data);
            setTimeout(function () {
                window.location.reload();
            }, 2000);
        }
    });

    return false;
}

// ios
$(function(){
    var iosActionsheet = $('#iosActionsheet');
    var iosMask = $('#iosMask');
    var iositem = $('.iositem');

    function hideActionSheet() {
        iosActionsheet.removeClass('weui-actionsheet_toggle');
        iosMask.fadeOut(200);
    }

    iosMask.on('click', hideActionSheet);
    iositem.on('click', function () {
        hideActionSheet();
        $('input[name="crtype"]').val($(this).attr('data-value'));
        $('input[name="crtype"]').attr('data-index', $(this).attr('data-index'));
        $("#showIOSActionSheet").html($(this).html());
        changebtnval($('#addfundamount').val());
    });
    $('#iosActionsheetCancel').on('click', hideActionSheet);
    $("#showIOSActionSheet").on("click", function(){
        iosActionsheet.addClass('weui-actionsheet_toggle');
        iosMask.fadeIn(200);
    });
    for(var i=0 ; i<totaljf.length; i++){
        if(totaljf[i]>0){
            iositem.eq(i).trigger('click');
        }
    }
    if(totaljf.length==1){
        iositem.eq(0).trigger('click');
    }
});


function showtip(data) {
    var toast = $('#toast');
    if (toast.css('display') != 'none') return;
    toast.find('.weui-toast__content').html(data);
    toast.fadeIn(100);
    setTimeout(function () {
        toast.fadeOut(100);
    }, 2000);
}
</script>
</body>
</html>