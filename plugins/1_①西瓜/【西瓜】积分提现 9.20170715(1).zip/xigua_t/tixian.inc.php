<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/2/15
 * Time: 23:50
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(submitcheck('permsubmit')){
    $r = C::t('#xigua_t#xigua_t_tixian')->delete_order($_GET['delete']);
    if($r){
        cpmsg(lang('plugin/xigua_t', 'delete_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_t&pmod=tixian&page=".$_GET['page'], 'succeed');
        exit;
    }
}
if(submitcheck('editixianid')){
    $row = C::t('#xigua_t#xigua_t_tixian')->fetch($_GET['editixianid']);

    $status = 1;
    $notice = lang('plugin/xigua_t', 'tixiancg').($row['bank_name'] . ($row['account_name'] ? '('.$row['account_name'].') ' : ' ').$row['account']).
        lang('plugin/xigua_t', 'q5').'('.$_GET['note'] .')';

    if($row['type'] =='cwx' && $row['openid'] && $row['status']==0){
        include_once DISCUZ_ROOT .'source/plugin/xigua_t/common.php';
        $amount = intval($row['amount']*100);

        $re = WxPayApiSF::promotion($row['tixianid'], $row['openid'], $amount, diconv(lang('plugin/xigua_t','datixian'), CHARSET, 'UTF-8'));

        if(is_array($re['return_msg'])){
            $re['return_msg'] = var_export($re['return_msg'], TRUE);
        }
        $re['return_msg'] = diconv($re['return_msg'],'UTF-8', CHARSET);
        $re['err_code_des'] = diconv($re['err_code_des'],'UTF-8', CHARSET);

        if($re['result_code'] == 'SUCCESS' && $re['return_code'] == 'SUCCESS'){
            $status = 1;
            C::t('#xigua_t#xigua_t_tixian')->finish_tixian($_GET['editixianid'], $_GET['note'], 1);
        }else{
            $status = 0;
            cpmsg($re['err_code_des'], "action=plugins&operation=config&do=$pluginid&identifier=xigua_t&pmod=tixian&page=".$_GET['page'], 'error');
            exit;
        }
    }

    $r = C::t('#xigua_t#xigua_t_tixian')->finish_tixian($_GET['editixianid'], $_GET['note'], $status, $re['result_code'], $re['err_code_des'], $re['return_msg'] );
    if($r){

        notification_add(
            $row['uid'],
            'system',
            $notice,
            '',
            1
        );
        cpmsg(lang('plugin/xigua_t', 'succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_t&pmod=tixian&page=".$_GET['page'], 'succeed');
        exit;
    }
}
if(submitcheck('cancel')){
    $r = C::t('#xigua_t#xigua_t_tixian')->cancel_tixian($_GET['cancel'], $_GET['note']);
    if($r){
        $row = C::t('#xigua_t#xigua_t_tixian')->fetch($_GET['cancel']);

        updatemembercount($row['uid'], array($row['ctype'] => $row['addfundamount']), 1, 'TFR', $row['uid']);

        notification_add(
            $row['uid'],
            'system',
            lang('plugin/xigua_t', 'cancelnotice').$_GET['note'],
            '',
            1
        );

        cpmsg(lang('plugin/xigua_t', 'cancel_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_t&pmod=tixian&page=".$_GET['page'], 'succeed');
        exit;
    }
}

showtips(str_replace('{url}', $_G['siteurl'], lang('plugin/xigua_t', 'tip')));
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_t&pmod=tixian&page=".$_GET['page']);
showtableheader(lang('plugin/xigua_t','torder'));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_t','del'),
    lang('plugin/xigua_t','orderid'),
    lang('plugin/xigua_t','jine'),
    lang('plugin/xigua_t','user'),
    lang('plugin/xigua_t','dz'),
    lang('plugin/xigua_t','txtime'),
    lang('plugin/xigua_t','status'),
    lang('plugin/xigua_t','set'),
));
$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;
$res = C::t('#xigua_t#xigua_t_tixian')->fetch_bypage($start_limit, $lpp);
$icount =C::t('#xigua_t#xigua_t_tixian')->count_bypage();
//print_r($res);

foreach ($res as $v) {
    if($v['uid']){
        $uids[$v['uid']] = $v['uid'];
    }
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}


$status = array(
    0 => '<strong style="color:orangered;">'.lang('plugin/xigua_t', 'weidakuan').'</strong>',
    1 => '<strong style="color:forestgreen;">'.(lang('plugin/xigua_t','succeed2')).'</strong>',
    2 => '<strong style="color:grey;">'.(lang('plugin/xigua_t','canceled2')).'</strong>',
);

foreach ($res as $v) {
    $v['amount'] = sprintf('%.2f', $v['amount']);
    $ct = $_G['setting']['extcredits'][$v['ctype']]['title'];
    $dis = 100-$v['sxf'];
    $act = $v['bank_name'] . ($v['account_name'] ? '('.$v['account_name'].'): ' : ':').$v['account'];

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='{$v['tixianid']}' />",
        $v['tixianid'],
        "$v[addfundamount]$ct*$dis%/$v[bilv]" .'='. $v['amount'].lang('plugin/xigua_t','yuan'),
        "<a href='admin.php?frames=yes&action=logs&operation=credit&srch_uid=".$v['uid']."&frame=yes'>".$users[$v['uid']]['username'].'</a>',
        $act,
        date('m-d H:i:s', $v['crts']),
        ($v['upts'] ? date('m-d H:i', $v['upts']).' ' : '').
        $status[ $v['status'] ]. '<br>'. $v['note'],

        !$v['status'] ? '<a href="JavaScript:;" onclick="return _show_company_profile(\''.$v['type'].'\',\''.$v['tixianid'].'\',\''.addslashes($act).'\');">'.lang('plugin/xigua_t','q3').'</a>&nbsp;'.
        '<a href="JavaScript:;" onclick="return _show_company_profile1(\''.$v['tixianid'].'\',\''.addslashes($act).'\');">'.lang('plugin/xigua_t','q4').'</a>' : '-',
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_t&pmod=tixian&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '',$multipage);
showtablefooter();/*Dism��taobao-com*/
showformfooter();

?>

<div id="rsel_menu" class="custom cmain" style="display:none;width:400px;height:250px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr"></h3>
    </div>
    <div id="rsel_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_t&pmod=tixian&page=$page");
        ?>
        <table class="tb tb2 ">
            <tr class="hover">
                <td align="left"><?php echo lang('plugin/xigua_t','q5'); ?></td>
                <td><textarea name="note" cols="40" rows="3"></textarea></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="cancel" id="cancel" value="0">
                    <input type="hidden" name="editixianid" id="txid" value="0">
                    <input type="submit" class="btn" name="editsubmit" value="<?php echo lang('plugin/xigua_t','q6'); ?>" />
                    <span id="show1">

                    </span>
                </td>
            </tr>
        </table>
        <?php showformfooter();?>
    </div>
</div>
<script>
    function _show_company_profile(type, id, act) {
        showMenu({'ctrlid': 'rsel', 'evt': 'click', 'duration': 3, 'pos': '00'});
        $('cancel').value = 0;
        $('txid').value = id;
        if(type == 'cwx'){
            $('show1').innerHTML = '<?php echo lang('plugin/xigua_t','q7'); ?>';
        }else{
            $('show1').innerHTML ='<?php echo lang('plugin/xigua_t','q8'); ?>';
        }
        $('cnotr').innerHTML = '<?php echo lang('plugin/xigua_t','q3'); ?>-'+act;
    }
    function _show_company_profile1(id, act) {
        showMenu({'ctrlid': 'rsel', 'evt': 'click', 'duration': 3, 'pos': '00'});
        $('cancel').value = id;
        $('txid').value = 0;
        $('show1').innerHTML = '<?php echo lang('plugin/xigua_t','q9'); ?>';
        $('cnotr').innerHTML = '<?php echo lang('plugin/xigua_t','q4'); ?>-'+act;
    }
</script>
