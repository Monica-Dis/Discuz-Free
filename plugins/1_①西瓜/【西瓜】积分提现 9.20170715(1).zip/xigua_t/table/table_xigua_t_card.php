<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/27
 * Time: 23:22
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_t_card extends discuz_table {

    public function __construct() {
        $this->_table = 'xigua_t_card';
        $this->_pk = 'id';

        parent::__construct();
    }

    public function insert_card($type, $account, $account_name = '', $bank_name = '', $openid = '')
    {
        global $_G;

        if($type == 'cwx'){
            if(DB::result_first('SELECT uid FROM '.DB::table($this->_table)." WHERE uid={$_G['uid']} AND openid=%s", array(
                $openid
            ))){
                return 0;
            }
        }

        $order = array(
            'uid' => $_G['uid'],
            'crts' => TIMESTAMP,
            'type' => $type,
            'account' => $account,
            'account_name' => $account_name,
            'bank_name' => $bank_name,
            'openid' => $openid,
        );
        if($id= $this->insert($order, true)){
            return $id;
        }
    }

    public function fetch_list($uid){
        $uid = intval($uid);
        $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table)." WHERE uid=$uid ORDER BY $this->_pk ASC ");
        return $result;
    }

    public function delete_ids($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public function set_default($id)
    {
        DB::query('UPDATE %t SET isdefault=0 WHERE 1', array($this->_table));
        return DB::query('UPDATE %t SET isdefault=1 WHERE id=%d', array($this->_table, $id));
    }

    public function get_default($uid)
    {
        $result = DB::fetch_first('SELECT * FROM '.DB::table($this->_table)." WHERE uid=$uid AND isdefault=1");
        if(!$result){
            $this->revert_default($uid);
            $result = DB::fetch_first('SELECT * FROM '.DB::table($this->_table)." WHERE uid=$uid AND isdefault=1");
        }
        return $result;
    }

    public function revert_default($uid)
    {
        DB::query('UPDATE %t SET isdefault=0 WHERE 1', array($this->_table));
        return DB::query('UPDATE %t SET isdefault=1 WHERE uid=%d LIMIT 1', array($this->_table, $uid));
    }
}