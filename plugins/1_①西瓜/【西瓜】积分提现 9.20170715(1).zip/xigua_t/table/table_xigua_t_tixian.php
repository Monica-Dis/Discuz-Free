<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/27
 * Time: 23:22
 */

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_t_tixian extends discuz_table {

    public function __construct() {
        $this->_table = 'xigua_t_tixian';
        $this->_pk = 'tixianid';

        parent::__construct();
    }

    public function tixian_insert($amount, $openid, $uid, $account, $type, $bank_name, $account_name, $ctype, $bilv, $sxf, $addfundamount)
    {
        $order = array(
            'tixianid' => date('YmdHis').mt_rand(1000000,9999999),
            'crts' => time(),
            'amount' => $amount,
            'openid' => $openid,
            'uid' => $uid,
//            'return_code' => $code,
//            'err_code_des' => $desc,
//            'return_msg' => $msg,
            'account' => $account,
            'type' => $type,
            'bank_name' => $bank_name,
            'account_name' => $account_name,
            'ctype' => $ctype,
            'bilv' => $bilv,
            'sxf' => $sxf,
            'addfundamount' => $addfundamount,
            'status' => 0,
        );
        if($this->insert($order)){
            return $order['tixianid'];
        }
    }

    public function finish_tixian($txid, $note = '', $status = 1,$code ='', $desc = '', $msg= '' ){
        return $this->update($txid, array(
            'note' => $note,
            'upts' => time(),
            'status' => $status,
            'return_code' => $code,
            'err_code_des' => $desc,
            'return_msg' => $msg,
        ));
    }

    public function cancel_tixian($txid, $note = ''){
        return $this->update($txid, array(
            'note' => $note,
            'upts' => time(),
            'status' => 2,  //cancel
        ));
    }

    public function fetch_bypage( $start_limit , $lpp){
        $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table)."  ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_by_uid( $uid, $start_limit , $lpp){
        $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table)." WHERE uid=$uid  ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function count_bypage(){
        $result = DB::result_first('SELECT  count(*) as c FROM '.DB::table($this->_table));
        return $result;
    }
    public function delete_order($ids)
    {
        return DB::query('DELETE FROM %t WHERE tixianid IN (%n)', array($this->_table, $ids));
    }
}