<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_rw_ad extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_rw_ad';
        $this->_pk = 'adid';

        parent::__construct(); /*dism_ taobao _com*/
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        return DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false) {
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $rw_config, $manage, $_G;
        if($_GET['st']<=0 && $_G['cache']['plugin']['xigua_st']['showsub']){
        }elseif($_GET['st']>0 && $rw_config['allowst'] && !defined('IN_ADMINCP') && !$_GET['is_my'] && !$_GET['manage']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        if($_GET['ac']=='my' || defined('IN_ADMINCP')) {
        }else{
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($_GET['orderby']=='new'){
            $orderby = ' adid DESC ';
        }elseif ($_GET['orderby']=='near'){
            $lat = floatval($_GET['lat']);
            $lng = floatval($_GET['lng']);
            $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
            $fields = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
            $orderby = 'distance ASC, (danshu-complete) DESC, adid DESC';
        }
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }else{
            $orderby = "ORDER BY (danshu-complete) DESC,adid DESC";
        }
        $wxids = array();
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $wxids[] = $item['wxid'];
        }
        if($wxids && $_GET['ac']=='add_li'){
            $wxs = DB::fetch_all('select wxid,uid from %t where wxid in (%n) AND uid>0', array('xigua_rw_wx', $wxids), 'wxid');
            foreach ($result as $index => $item) {
                $tmp = getuserbyuid($wxs[$item['wxid']]['uid'], 1);
                $wxs[$item['wxid']]['username'] = $tmp['username'];
                $result[$index]['wxinfo'] = $wxs[$item['wxid']];
            }
        }
        return $result;
    }

    public static function prepare($v){
        if($v){
            global $statuss;
            $v['jineng_ary'] = array_filter(explode(',', $v['jineng']));
            $v['jineng_str_ary'] = array_filter(explode(',', $v['jineng_str']));
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i', $v['upts']) : '';
            $v['payts_u'] = $v['payts'] ? date('Y-m-d H:i', $v['payts']) : '';
            $v['album_ary'] = array_filter(explode(',', $v['album']));
            $v['areawant_ary'] = array_filter(explode(',', trim($v['areawant'])));
            $v['areawant_str_ary'] = array_filter(explode(',', trim($v['areawant_str'])));

            $v['rent_price'] = floatval($v['rent_price']);
            $v['percent'] = $v['danshu'] ? intval($v['complete']/$v['danshu']*100) : 0;
        }
        return $v;
    }

    public static function rand_kouling()
    {
        $strs="QWERTYUPASDFGHJKLZXCVBNM23456789";
        $name = substr(str_shuffle($strs),mt_rand(0,strlen($strs)-11),4);
        return $name;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        global $rw_config;
        if($_GET['st']>0 && $rw_config['allowst']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function delete_by_where($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::query('DELETE FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public function fetch_by_uid($uid)
    {
        global $rw_config;
        if($rw_config['allowst'] && $_GET['st']>0) {
            $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND stid=%d", array($this->_table, $uid, $_GET['st']));
        }else{
            $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
        }
        $v = self::prepare($v);
        return $v;
    }

    public function do_delete($id)
    {
        return $this->delete($id);
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all("SELECT * FROM %t  ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp), array($this->_table));
        if($result){
            foreach ($result as $index => $item) {
                $result[$index] = self::prepare($item);
            }
        }
        return $result;
    }

    public function count_by_page()
    {
        return DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
    }

    public function del_by_uid_adid($adid)
    {
        global $_G;
        return DB::delete($this->_table, array(
            'adid' => $adid,
            'uid' => $_G['uid'],
        ));
    }

    public function fetch_by_id($adid){
        $rs = parent::fetch($adid);
        $this->incr($adid, 'views');
        return self::prepare($rs);
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first("select * from %t WHERE {$this->_pk}=%d AND uid=%d", array(
            $this->_table,
            $id,
            $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }

    public function incr($gid, $field, $num = 1)
    {
        if(!$field){
            return null;
        }
        if(strpos($gid, ',')!==false){
            $gid = dintval(array_filter(explode(',', $gid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $gid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $gid));
        }
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        if(IS_ADMINID){
            return DB::update($this->_table, $data, array(
                'adid'  => $id,
            ));
        }else {
            return DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                'adid' => $id,
            ));
        }
    }

    public function get_order($viewtype)
    {
        global $rw_config;
        $field = '*';
        switch ($viewtype){
            case "new":
                $order_by = '(dig_endts-dig_startts) DESC, tuijian DESC, upts DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                switch ($rw_config['digorder']){
                    case '3':
                        $order_by = 'distance ASC, dig_startts DESC, dig_endts DESC';
                        break;
                    case '2':
                        $order_by = 'distance ASC, dig_endts DESC';
                        break;
                    default:
                        $order_by = 'distance ASC, (dig_endts-dig_startts) DESC';
                        break;
                }
                break;
            case 'guanzhu':
                $order_by = 'follow DESC';
                break;
            case 'fenxiang':
                $order_by = 'shares DESC';
                break;
            default:
                switch ($rw_config['digorder']){
                    case '3':
                        $order_by = ' dig_startts DESC, dig_endts DESC, views DESC ';
                        break;
                    case '2':
                        $order_by = 'dig_endts DESC, views DESC';
                        break;
                    default:
                        $order_by = ' (dig_endts-dig_startts) DESC, tuijian DESC, views DESC ';
                        break;
                }
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }
    public function fetch_tuijian($num = 5, $fields = '')
    {
        if(!$fields){
            $fields = "$this->_pk,name, jineng_str";
        }
        $where = array('status=1 AND tuijian=1');
        $ob = "(dig_endts-dig_startts) DESC, displayorder DESC, $this->_pk DESC";
        return $this->fetch_all_by_where($where, 0, $num, $ob, $fields );
    }

    public function tuijian($adid)
    {
        if($_GET['tj']==1){
            $data = array( 'tuijian' => 1, );
            parent::update($adid, $data);
        }else{
            $data = array('tuijian' => 0);
            parent::update($adid, $data);
        }
        return true;
    }

    public function total_views()
    {
        global $_G, $config;
        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if( $_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st) ";
                }
            }
        }
        $key = 'rwwx_view_'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            if($return>0) {
                savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
            }
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }
    public function total_count()
    {
        global $_G, $config;
        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if( 0 && $_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st) ";
                }
            }
        }

        $key = 'rwad'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT count(*) FROM %t WHERE wxid=0 and '.$whe, array($this->_table));
            if($return>0){
                savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
            }
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }
}