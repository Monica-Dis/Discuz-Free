<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_rw_log extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_rw_log';
        $this->_pk = 'id';

        parent::__construct(); /*dism_ taobao _com*/
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'id DESC', $fields= '*', $needuser = 1)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        $uids = $wxids = array();
        foreach ($result as $index => $item) {
            $uids[] = $item['wxuid'];
            $uids[] = $item['aduid'];
            $wxids[] = $item['wxid'];
            $result[$index] = $this->prepare($item);
        }
        if($wxids){
            $wxs = DB::fetch_all('SELECT * from %t where wxid in (%n)', array('xigua_rw_wx', $wxids), 'wxid');
            foreach ($result as $index => $item) {
                $result[$index]['wx'] = $wxs[$item['wxid']];
            }
        }
        if($needuser && $uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            $hbusers = DB::fetch_all('SELECT uid,mobile FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['wx_username'] = $users[$item['wxuid']]['username'];
                $result[$index]['wx_mobile'] = $hbusers[$item['wxuid']]['mobile'];
                $result[$index]['ad_username'] = $users[$item['aduid']]['username'];
                $result[$index]['ad_mobile'] = $hbusers[$item['aduid']]['mobile'];
            }
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        global $rw_config;
        if($_GET['st'] && $rw_config['allowst']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i', $v['upts']) : '';
            $v['pz1_crts_u'] = $v['pz1_crts'] ? lang('plugin/xigua_rw', 'scsj').' : '.date('Y-m-d H:i', $v['pz1_crts']) : '';
            $v['pz2_crts_u'] = $v['pz2_crts'] ? lang('plugin/xigua_rw', 'scsj').' : '.date('Y-m-d H:i', $v['pz2_crts']) : '';
            $v['adinfo'] = unserialize($v['adinfo']);
            $v['chujia'] = floatval($v['chujia']);
            $v['pznum'] = intval(!!$v['pz1']) + intval(!!$v['pz2']);
            if($_GET['manage']){
                if(!$v['pz1']){
                    $v['pz1'] = 'source/plugin/xigua_hb/static/img/zhanwei.png';
                }
                if(!$v['pz2']){
                    $v['pz2'] = 'source/plugin/xigua_hb/static/img/zhanwei.png';
                }
            }
            global $rw_config, $_G, $SCRITPTNAME;
            if($rw_config['chaoshi1']>0 && $v['status']==1 && $v['crts']>0){
                if($v['crts']+$rw_config['chaoshi1']*60<TIMESTAMP){
                    DB::query("update %t set status=5,upts=%d WHERE id=%d", array('xigua_rw_log', TIMESTAMP, $v['id']));
                    if($rw_config['kctype']==1){
                        C::t('#xigua_rw#xigua_rw_ad')->incr($v['adid'], 'complete', -1);
                    }
                    $rwlog = $v;
                    $logid = $v['id'];

                    $auto_cancel = lang('plugin/xigua_rw', 'auto_cancel');
                    $href = $_G['siteurl']."$SCRITPTNAME?id=xigua_rw&ac=order&logid=$logid";
                    $adinfo =  C::t('#xigua_rw#xigua_rw_ad')->fetch($rwlog['adid']);
                    $title = cutstr(strip_tags($adinfo['jieshao']), 16);
                    $wxuser = getuserbyuid($rwlog['wxuid']);
                    notification_add($rwlog['wxuid'],'system', $auto_cancel, array('title' => $title, 'href' => $href, 'username'=> $wxuser['username']),1);
                    notification_add($rwlog['aduid'],'system', $auto_cancel, array('title' => $title, 'href' => $href, 'username'=> $wxuser['username']),1);
                }
            }
            if($rw_config['chaoshi2']>0 && $v['status']==2 && $v['pz2_crts']>0 && $v['pz1_crts']>0){
                if($v['pz2_crts']+$rw_config['chaoshi2']*60<TIMESTAMP){
                    DB::query("update %t set status=3,confirmts=%d WHERE id=%d", array('xigua_rw_log', TIMESTAMP, $v['id']));
                    if($rw_config['kctype']==2){
                        C::t('#xigua_rw#xigua_rw_ad')->incr($v['adid'], 'complete', 1);
                    }
                    $rwlog = $v;
                    $logid = $v['id'];

                    $allp = $rwlog['chujia'];
                    if($rw_config['shouxufei']> 0){
                        $prate = intval(str_replace('%', '', $rw_config['shouxufei']))/100;
                        $shouxufei = round($allp*$prate, 2);
                    }else{
                        $shouxufei = 0;
                    }
                    $income = $allp-$shouxufei;
                    $order_complete = lang('plugin/xigua_rw', 'order_complete2');
                    $href = $_G['siteurl']."$SCRITPTNAME?id=xigua_rw&ac=order&logid=$logid";
                    $adinfo =  C::t('#xigua_rw#xigua_rw_ad')->fetch($rwlog['adid']);
                    $title = cutstr(strip_tags($adinfo['jieshao']), 16);
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid' => $rwlog['wxuid'],
                        'crts' => TIMESTAMP,
                        'size' => $income,
                        'note' => str_replace(array('{title}', '{shouxufei}', '{totalprice}',), array( $title, $shouxufei, $income, ), strip_tags($order_complete)),
                        'link' => $href,
                    ));
                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($rwlog['wxuid'], 'money', $income);
                    notification_add($rwlog['wxuid'],'system', $order_complete, array('title' => $title, 'href' => $href, 'shouxufei'=>$shouxufei, 'totalprice'=> $income),1);
                }
            }
            /*
    <!--{if $v[status]==1 && $rw_config[chaoshi1]}-->
    <div class="tr c3 f12" style="padding: 12px 15px 0;line-height: 1;">{lang xigua_rw:chaoshijiezhi1}: <em class="color-red2">{echo date('Y-m-d H:i:s', );}</em></div>
    <!--{/if}-->
    <!--{if $v[status]==2 && $rw_config[chaoshi2]}-->
    <div class="tr c3 f12" style="padding: 12px 15px 0;line-height: 1;">{lang xigua_rw:chaoshijiezhi2}: <em class="color-red2">{echo date('Y-m-d H:i:s', $v[pz2_crts]+$rw_config[chaoshi2]*60);}</em></div>
    <!--{/if}-->*/
        }
        return $v;
    }

    public function fetch_by_uid($uid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE wxuid=%d", array($this->_table, $uid));
        $v = self::prepare($v);
        return $v;
    }

    public function cancel_order($id, $val)
    {
        global $SCRITPTNAME, $_G;
        return true;
    }

    public function confirm_order($id, $val)
    {
        global $SCRITPTNAME, $_G;
        return true;
    }

    public function confirm_complete($id, $val)
    {
        global $SCRITPTNAME, $_G;
        return true;
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array(), $field = '*', $orderby = 'id DESC', $key_field = '')
    {
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }else{
            $orderby = '';
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql $orderby " . DB::limit($start_limit, $lpp));
        $return = array();
        foreach ($result as $index => $item) {
            if($key_field){
                $return[$item[$key_field]] = $item;
            }else{
                $return[$index] = $item;
            }
        }
        return $return;
    }
    public function do_delete($id)
    {
        return $this->delete($id);
    }

    public function check_if_exists($uid, $adid, $wxid, $echo = 1)
    {
        global $SCRITPTNAME,$logid,$urlext;
        $ret = DB::fetch_first('select * from %t where wxuid=%d and adid=%d and wxid=%d', array($this->_table, $uid, $adid, $wxid));
        if($echo){
            if($ret){
                hb_message(lang_rw('wfcf',0), 'error', 'reload'/*$SCRITPTNAME?id=xigua_rw&ac=order&logid=$logid$urlext"*/);
            }
        }else{
            if($ret){
                return 1;
            }else{
                return 0;
            }
        }
    }
    public function total_count()
    {
        global $_G, $config;
        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if( 0 && $_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st) ";
                }
            }
        }

        $key = 'rwlogtn_'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT count(*) FROM %t WHERE '.$whe, array($this->_table));
            if($return>0){
                savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
            }
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }
}