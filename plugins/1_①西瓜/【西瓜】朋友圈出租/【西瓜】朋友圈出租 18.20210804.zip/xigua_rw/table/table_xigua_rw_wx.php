<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_rw_wx extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_rw_wx';
        $this->_pk = 'wxid';

        parent::__construct(); /*dism_ taobao _com*/
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        return DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false) {
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'wxid DESC', $fields= '*')
    {
        global $rw_config, $manage, $_G;
        if($_GET['st']<=0 && $_G['cache']['plugin']['xigua_st']['showsub']){
        }elseif($_GET['st'] && $rw_config['allowst'] && !defined('IN_ADMINCP') && !$_GET['is_my'] && !$_GET['manage']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }

        if($_GET['ac']=='my' || defined('IN_ADMINCP')) {
        }else{
            $wherearr[] = " ( endts<=0 OR endts>".TIMESTAMP .') ';
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $orderby = ' wxid DESC ';
        if($_GET['orderby']=='new'){
            $orderby = ' wxid DESC ';
        }elseif ($_GET['orderby']=='near'){
            $lat = floatval($_GET['lat']);
            $lng = floatval($_GET['lng']);
            $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
            $fields = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
            $orderby = 'distance ASC, wxid DESC';
        }
        $orderby = "ORDER BY $orderby";
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $uids[] = $item['uid'];
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['wx_username'] = $users[$item['uid']]['username'];
            }
        }
        return $result;
    }

    public static function prepare($v){
        if($v){
            global $statuss;
            $v['rent_price'] = floatval($v['rent_price']);
            $v['jineng_ary'] = array_filter(explode(',', $v['jineng']));
            $v['jineng_str_ary'] = array_filter(explode(',', $v['jineng_str']));
            $v['areawant_ary'] = array_filter(explode(',', trim($v['areawant'])));
            $v['areawant_str_ary'] = array_filter(explode(',', trim($v['areawant_str'])));

            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i', $v['upts']) : '';
            $v['is_dig'] = $v['dig'] = $v['dig_endts']>TIMESTAMP ? 1:0;

            if($v['status']==1 && $_GET['ac']=='view'){
                C::t('#xigua_rw#xigua_rw_wx')->incr($v['wxid'], 'views');
            }
        }
        return $v;
    }

    public static function rand_kouling()
    {
        $strs="QWERTYUPASDFGHJKLZXCVBNM23456789";
        $name = substr(str_shuffle($strs),mt_rand(0,strlen($strs)-11),4);
        return $name;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        global $rw_config;
        if($_GET['st'] && $rw_config['allowst']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function delete_by_where($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::query('DELETE FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public function fetch_by_uid($uid)
    {
        global $rw_config;
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
        $v = self::prepare($v);
        return $v;
    }
    public function fetchs_by_uid($uid)
    {
        $result = DB::fetch_all("SELECT * FROM %t WHERE uid=%d AND status=1", array($this->_table, $uid));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $uids[] = $item['uid'];
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['wx_username'] = $users[$item['uid']]['username'];
            }
        }
        return $result;
    }

    public function update_endts($wxid, $allts, $order_id)
    {
        $payts = TIMESTAMP;
        $old_data = $this->fetch($wxid, TRUE);
        if($old_data['endts']<TIMESTAMP){
            DB::query("update %t set endts=%d WHERE {$this->_pk}=%d", array($this->_table, TIMESTAMP, $wxid));
        }
        return DB::query("update %t set endts=endts+%d,status=1,order_id=%s,payts=%d WHERE {$this->_pk}=%d", array($this->_table, $allts, $order_id, $payts, $wxid));
    }

    public function fetch_online_card($uid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND status=1 AND endts>%s", array($this->_table, $uid, TIMESTAMP));
        $v = self::prepare($v);
        return $v;
    }
    public function fetch_online_card_num()
    {
        $v = DB::result_first("SELECT count(*) FROM %t WHERE status=1 AND endts>%s", array($this->_table, TIMESTAMP));
        return $v;
    }
    public function do_delete($id)
    {
        return $this->delete($id);
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all("SELECT * FROM %t  ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp), array($this->_table));
        if($result){
            foreach ($result as $index => $item) {
                $result[$index] = self::prepare($item);
            }
        }
        return $result;
    }

    public function count_by_page()
    {
        return DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
    }

    public function del_by_uid_wxid($wxid)
    {
        global $_G;
        return DB::delete($this->_table, array(
            'wxid' => $wxid,
            'uid' => $_G['uid'],
        ));
    }

    public function fetch_by_ids($ids, $fields='*', $key_field = '')
    {
        $result = DB::fetch_all("SELECT $fields FROM %t WHERE wxid IN (%n)", array(
            $this->_table,
            $ids
        ), $key_field ? $key_field : $this->_pk);
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $uids[] = $item['uid'];
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['wx_username'] = $users[$item['uid']]['username'];
            }
        }
        return $result;
    }

    public function fetch_by_id($wxid){
        $rs = parent::fetch($wxid);
        $this->incr($wxid, 'views');
        return self::prepare($rs);
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first("select * from %t WHERE {$this->_pk}=%d AND uid=%d", array(
            $this->_table,
            $id,
            $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }

    public function incr($gid, $field, $num = 1)
    {
        if(!$field){
            return null;
        }
        if(strpos($gid, ',')!==false){
            $gid = dintval(array_filter(explode(',', $gid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $gid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $gid));
        }
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        if(IS_ADMINID){
            return DB::update($this->_table, $data, array(
                'wxid'  => $id,
            ));
        }else {
            return DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                'wxid' => $id,
            ));
        }
    }

    public function get_order($viewtype)
    {
        global $rw_config;
        $field = '*';
        switch ($viewtype){
            case "new":
                $order_by = '(dig_endts-dig_startts) DESC, tuijian DESC, upts DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                switch ($rw_config['digorder']){
                    case '3':
                        $order_by = 'distance ASC, dig_startts DESC, dig_endts DESC';
                        break;
                    case '2':
                        $order_by = 'distance ASC, dig_endts DESC';
                        break;
                    default:
                        $order_by = 'distance ASC, (dig_endts-dig_startts) DESC';
                        break;
                }
                break;
            case 'guanzhu':
                $order_by = 'follow DESC';
                break;
            case 'fenxiang':
                $order_by = 'shares DESC';
                break;
            default:
                switch ($rw_config['digorder']){
                    case '3':
                        $order_by = ' dig_startts DESC, dig_endts DESC, views DESC ';
                        break;
                    case '2':
                        $order_by = 'dig_endts DESC, views DESC';
                        break;
                    default:
                        $order_by = ' (dig_endts-dig_startts) DESC, tuijian DESC, views DESC ';
                        break;
                }
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }
    public function fetch_tuijian($num = 5, $fields = '')
    {
        if(!$fields){
            $fields = "$this->_pk,name, jineng_str";
        }
        $where = array('status=1 AND tuijian=1');
        $ob = "(dig_endts-dig_startts) DESC, displayorder DESC, $this->_pk DESC";
        return $this->fetch_all_by_where($where, 0, $num, $ob, $fields );
    }

    public function fetch_catall_count()
    {
        /*$res = DB::fetch_all('SELECT hangye_id2,count(*) AS num FROM %t WHERE endts>'.TIMESTAMP.' AND display=1 GROUP BY hangye_id2', array(
            $this->_table
        ));
        $ret = array();
        foreach ($res as $index => $re) {
            $ret[$re['hangye_id2']] = $re['num'];
        }
        return $ret;*/
    }
    public function manage($wxid)
    {
        global $SCRITPTNAME,$_G,$urlext;
        $wxinfo = parent::fetch($wxid);
        $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_rw&ac=view&wxid=$wxid$urlext";

        if($_GET['tongguo']==1){
            $data = array( 'status' => 1, );
            parent::update($wxid, $data);
            notification_add($wxinfo['uid'],'system', lang_rw('tongguo_noti1', 0),array('name' => $wxinfo['name'],'url' => $url),1);
        }else{
            $data = array('status' => -1);
            parent::update($wxid, $data);
            notification_add($wxinfo['uid'],'system', lang_rw('tongguo_noti2', 0),array('name' => $wxinfo['name'],'url' => $url),1);
        }
        return true;
    }

    public function tuijian($wxid)
    {
        if($_GET['tj']==1){
            $data = array( 'tuijian' => 1, );
            parent::update($wxid, $data);
        }else{
            $data = array('tuijian' => 0);
            parent::update($wxid, $data);
        }
        return true;
    }

    public function total_views()
    {
        global $_G, $config;
        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if( $_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st) ";
                }
            }
        }
        $key = 'rwwx_view_'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            if($return>0) {
                savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
            }
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }
    public function total_count()
    {
        global $_G, $config;
        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if( 0 && $_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st) ";
                }
            }
        }

        $key = 'rwwxu'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT count(*) FROM %t WHERE '.$whe, array($this->_table));
            if($return>0){
                savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
            }
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }
}