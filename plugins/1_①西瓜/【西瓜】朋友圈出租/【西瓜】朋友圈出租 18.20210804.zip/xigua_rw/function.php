<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function lang_rw($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_rw', $lang);
    }else{
        return lang('plugin/xigua_rw', $lang);
    }
}

function rw_current_location($lat, $lng){
    global $rw_config;
    $url = "http://apis.map.qq.com/ws/geocoder/v1/?location=$lat,$lng&coord_type=5&get_poi=1&key=".$rw_config['skey'];
    $ret = hb_curl($url);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        $rt = array();
        $rt[$ret['result']['address']] = array(
            'address'           => str_replace(array($ret['result']['address_component']['province'], $ret['result']['address_component']['city']), '', $ret['result']['address']),
            'address_component' => array(
                'province' => $ret['result']['address_component']['province'],
                'city'     => $ret['result']['address_component']['city'],
                'district' => $ret['result']['address_component']['district'],
                'street'   => $ret['result']['address_component']['street'],
                'street_number'=>$ret['result']['address_component']['street_number'],
            ),
            'location'          => $ret['result']['location'],
            'category'          => diconv(lang('plugin/xigua_rw', 'default'), CHARSET, 'utf-8'),
        );
        foreach ($ret['result']['pois'] as $index => $pois) {
            $rt[$pois['address']] = array(
                'address'           => str_replace(array($pois['ad_info']['province'], $pois['ad_info']['city']), '', $pois['address']),
                'address_component' => array(
                    'province' => $pois['ad_info']['province'],
                    'city'     => $pois['ad_info']['city'],
                    'district' => $pois['ad_info']['district'],
                    'street'   => '',
                    'street_number'=> '',
                ),
                'location'          => $pois['location'],
                'category'          => $pois['category'],
            );
        }
        $rt = array_values($rt);
        return  rw_multi_diconv($rt, 'utf-8', 'utf-8');
    }else{
        return rw_multi_diconv($ret['message'], 'utf-8', CHARSET);
    }
}
function rw_multi_diconv($string, $in_charset, $out_charset){
    if (is_array($string)) {
        foreach ($string as $key => $val) {
            $string[ $key ] = rw_multi_diconv($val, $in_charset, $out_charset);
        }
    } else {
        $string = diconv($string, $in_charset, $out_charset);
    }
    return $string;
}
function rwmulti_pay_callback($param){
    $info = $param['info'];
    return true;
}

function rw_nl2br($txt){
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}

function rw_qrcode($mpid, $url, $avatar = ''){
    global $SCRITPTNAME, $rw_config, $_G,$urlext;

    if($rw_config['typewx'] ==2){
        $upar = parse_url($url);
        $hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_rw&ac=view&qunid=$mpid&x=1");

        $_qrfile = './source/plugin/xigua_rw/cache/qun' . $mpid . '.jpg';
        if (!is_file(DISCUZ_ROOT . $_qrfile)){
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')){
                QRcode::png($hb_currenturl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
            }
        }
        $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&logo='.urlencode($avatar).'&url='.$hb_currenturl;
        return $shqr;
    }else{
        $config = $_G['cache']['plugin']['xigua_hb'];
        if($config['qraut']){
            return "$SCRITPTNAME?id=xigua_hb:qrauto&ode=qun_{$mpid}{$urlext}";
        }
        $repath = './source/plugin/xigua_rw/cache/';
        $qrfile = $repath . $mpid . '.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;
        if(!is_file($abs_qrfile)) {
            if (!is_file($abs_qrfile)) {
                @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                if(class_exists('QRcode')){
                    QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
                }
            }
        }
        return $qrfile;
    }
}
function rw_hex2rgb($colour, $a){
    if ($colour[0] == '#') {
        $colour = substr($colour, 1);
    }
    if (strlen($colour) == 6) {
        list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
    }
    elseif (strlen($colour) == 3) {
        list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
    }
    else {
        return false;
    }
    $r = hexdec($r);
    $g = hexdec($g);
    $b = hexdec($b);
    if($a==0){
        $a = 0.1;
    }
    return "rgba($r, $g, $b, $a)";
}

function rw_to_noti($extinfo, $new = 1){
    if(IS_ADMINID){
        return false;
    }
    global $adminids,$_G,$SCRITPTNAME;
    if($adminids) {
        $adminids = array_slice($adminids, 0, 2);
        if ($_G['cache']['plugin']['xigua_st'] && $extinfo['stid']) {
            $stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status($extinfo['stid']);
            if ($stinfo['uid']) {
                $adminids[] = $stinfo['uid'];
            }
        }
        $tourl= $_G['siteurl']."$SCRITPTNAME?id=xigua_rw&ac=my&manage=1&mobile=2";
        $act = $new ? lang_rw('pub',0) : lang_rw('edit',0);
        foreach ($adminids as $adminid) {
            notification_add($adminid, 'system', lang('plugin/xigua_rw', 'shenhe_notice'), array(
                'url' => $tourl,
                'ts' => date('Y-m-d H:i:s', TIMESTAMP),
                'username' => $_G['username'],
                'act' => $act,
                'name' => $extinfo['realname'],
            ), 1);
        }
    }
}

function rw_multi_pay_callback($param){
    global $SCRITPTNAME,$urlext, $_G;
    $info = $param['info'];
    $newid = intval($info['data']['newid']);
    $update = array();
    $update['payts'] = TIMESTAMP;
    $update['status'] = 1;
    C::t('#xigua_rw#xigua_rw_ad')->update($newid, $update);
}

function rw_multis_pay_callback($param){
    global $SCRITPTNAME,$urlext, $_G, $log_status;
    $info = $param['info'];
    $newids = $info['data']['newids'];
    $wxids = $info['data']['wxids'];
    $update = array();
    $update['payts'] = TIMESTAMP;
    $update['status'] = 1;
    foreach ($newids as $index => $newid) {
        $adid = $newid;
        C::t('#xigua_rw#xigua_rw_ad')->update($newid, $update);

        $adinfo =  C::t('#xigua_rw#xigua_rw_ad')->fetch($adid);
        $wxid = intval($adinfo['wxid']);
        $wxinfo =  C::t('#xigua_rw#xigua_rw_wx')->fetch($wxid);
        $logdata = array(
            'logsn' => 'R'.date('YmdHis') . mt_rand(1000, 9999),
            'crts' => TIMESTAMP,
            'upts' => TIMESTAMP,
            'adid' => $adid,
            'aduid' => $adinfo['uid'],
            'adinfo' => serialize($adinfo),
            'wxid' => $wxid,
            'wxuid' => $wxinfo['uid'],
            'status' => 1,
            'stid' => $adinfo['st'],
            'type' => 'beidong',
            'chujia' => $adinfo['rent_price'],
        );
        $logid = C::t('#xigua_rw#xigua_rw_log')->insert($logdata, 1);

        if($logid>0){
            $aduser = getuserbyuid($wxinfo['uid'], 1);
            notification_add($wxinfo['uid'],'system', lang('plugin/xigua_rw', 'jdcg5'),array(
                'username' => $aduser['username'],
                'title' => cutstr($adinfo['jieshao'], 40),
                'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_rw&ac=order&logid=$logid$urlext",
            ),1);

            notification_add($adinfo['uid'],'system', lang('plugin/xigua_rw', 'jdcg6'),array(
                'username' => $aduser['username'],
                'title' => cutstr($adinfo['jieshao'], 40),
                'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_rw&ac=order&logid=$logid$urlext",
            ),1);
        }
    }
}


function rw_ad_noti($extinfo){
    if(IS_ADMINID){
        return false;
    }
    global $adminids,$_G,$SCRITPTNAME;
    if($adminids) {
        $adminids = array_slice($adminids, 0, 2);
        if ($_G['cache']['plugin']['xigua_st'] && $extinfo['stid']) {
            $stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status($extinfo['stid']);
            if ($stinfo['uid']) {
                $adminids[] = $stinfo['uid'];
            }
        }
        $tourl= $_G['siteurl']."$SCRITPTNAME?id=xigua_rw&ac=my&manage=1&mobile=2";
        $act = lang_rw('pub',0);
        foreach ($adminids as $adminid) {
            notification_add($adminid, 'system', lang('plugin/xigua_rw', 'shenhe_notice2'), array(
                'url' => $tourl,
                'ts' => date('Y-m-d H:i:s', TIMESTAMP),
                'username' => $_G['username'],
                'act' => $act,
                'name' => cutstr(strip_tags($extinfo['jieshao']), 80),
            ), 1);
        }
    }
}