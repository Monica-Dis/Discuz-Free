<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
switch ($_GET['do']) {
    case 'offline':
        if (submitcheck('formhash')) {
            if ($wxid= intval($_GET['wxid'])) {
                if ($_GET['xiajia']) {
                    $sta = -3;
                } else {
                    $sta = 1;
                }
                C::t('#xigua_rw#xigua_rw_wx')->update_G($wxid, array('status' => $sta));
            }
            if ($adid = intval($_GET['adid'])) {
                if ($_GET['xiajia']) {
                    $sta = -3;
                } else {
                    $sta = 1;
                }
                C::t('#xigua_rw#xigua_rw_ad')->update_G($adid, array('status' => $sta));
            }
            hb_message(lang_rw('succeed', 0), 'success', 'reload');
        }
    break;
    case 'qiangdan':
        if(submitcheck('wxid')){
            $adid = intval($_GET['adid']);
            /*$hhme = C::t('#xigua_hh#xigua_hh_member')->fetch_prepare($_G['uid']);
            if(!$hhme){
                hb_message('������פ��Ϊ�ϻ���', 'error', 'plugin.php?id=xigua_hh&ac=join&backto='.urlencode('plugin.php?id=xigua_rw&ac=ad_view&adid='.$adid));
            }*/
            $wxid = intval($_GET['wxid']);
            C::t('#xigua_rw#xigua_rw_log')->check_if_exists($_G['uid'], $adid, $wxid);
            $adinfo =  C::t('#xigua_rw#xigua_rw_ad')->fetch($adid);
            if($adinfo['complete']>=$adinfo['danshu']){
                hb_message(lang_rw('bqyqw',0), 'error');
            }
            if($rw_config['kctype']==1){
                C::t('#xigua_rw#xigua_rw_ad')->incr($adid, 'complete', 1);
            }
            $wxinfo =  C::t('#xigua_rw#xigua_rw_wx')->fetch($wxid);
            if(intval($wxinfo['friend_num'])<intval($adinfo['friend_num'])){
                hb_message(lang_rw('hybfhtj',0), 'error');
            }
            $data = array(
                'logsn' => 'R'.date('YmdHis') . mt_rand(1000, 9999),
                'crts' => TIMESTAMP,
                'upts' => TIMESTAMP,
                'adid' => $adid,
                'aduid' => $adinfo['uid'],
                'adinfo' => serialize($adinfo),
                'wxid' => $wxid,
                'wxuid' => $wxinfo['uid'],
                'status' => 1,
                'stid' => $_GET['st'],
                'type' => $_GET['adtype'],
                'chujia' => $adinfo['rent_price'],
            );
            $logid = C::t('#xigua_rw#xigua_rw_log')->insert($data, 1);

            if($logid>0){
                notification_add($adinfo['uid'],'system', lang('plugin/xigua_rw', 'jdcg3'),array(
                    'username' => $_G['username'],
                    'weixin' => $wxinfo['weixin'],
                    'status_text' => $log_status[$data['status']],
                    'title' => cutstr(strip_tags($adinfo['jieshao']), 40),
                    'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_rw&ac=order&manage=1&logid=$logid$urlext",
                ),1);

                notification_add($_G['uid'],'system', lang('plugin/xigua_rw', 'jdcg4'),array(
                    'username' => $_G['username'],
                    'weixin' => $wxinfo['weixin'],
                    'status_text' => $log_status[$data['status']],
                    'title' => cutstr(strip_tags($adinfo['jieshao']), 40),
                    'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_rw&ac=order&logid=$logid$urlext",
                ),1);
                hb_message(lang_rw('jdcgtip',0), 'success', "$SCRITPTNAME?id=xigua_rw&ac=order&logid=$logid$urlext");
            }
        }
        hb_message('error', 'error', "$SCRITPTNAME?id=xigua_rw&ac=order&status={$data['status']}$urlext");
        break;
    case 'uploadlog':
        $logid = intval($_GET['logid']);
        $form = $_GET['form'];
        $pz1 = $form['pz1'][0];
        $pz2 = $form['pz2'][0];
        if(!$logid){
            hb_message('error id', 'error');
        }
        $rwlog = C::t('#xigua_rw#xigua_rw_log')->fetch($logid);
        if(!$pz1){
            hb_message(lang_rw('qscjt1',0), 'error');
        }
        if($rwlog['status']==3 ||$rwlog['status']==5){
            hb_message(lang_rw('shtg1',0), 'error');
        }
        $data = array();
        if($pz1){
            $data['pz1'] = $pz1;
            if($rwlog['pz1']!=$pz1){
                $data['pz1_crts'] = TIMESTAMP;
            }
        }
        if($pz2){
            $data['pz2'] = $pz2;
            if($rwlog['pz2']!=$pz2) {
                $data['pz2_crts'] = TIMESTAMP;
            }
        }
        if($rw_config['jiange']>0){
            $_msg = lang_rw('pzjg',0).' '.$rw_config['jiange'].' '.lang_rw('fz',0);
            if(!$rwlog['pz1_crts']){
                $rwlog['pz1_crts'] =$data['pz1_crts'];
                $hide2 = 1;
            }
            if($data['pz2_crts']-$rwlog['pz1_crts']<$rw_config['jiange']*60){
                if(!$hide2){
                    if($rwlog['status']==4){
                    }else{
                        hb_message($_msg, 'error');
                    }
                }
            }
        }
        if($data['pz1'] && $data['pz2']){
            $data['status'] = 2;
        }
        if($hide2){
            $data['pz2'] = '';
            $data['pz2_crts'] = '';
        }
        DB::update('xigua_rw_log',$data, array('id' => $logid));
        if($hide2){
            hb_message(str_replace('n', $rw_config['jiange'], lang_rw('bccg12',0)), 'success', 'reload');
        }else{
            global $SCRITPTNAME, $urlext;
            $adinfo =  C::t('#xigua_rw#xigua_rw_ad')->fetch($rwlog['adid']);
            notification_add($adinfo['uid'],'system', lang('plugin/xigua_rw', 'upnotice'),array(
                'username' => $_G['username'],
                'title' => cutstr(strip_tags($adinfo['jieshao']), 40),
                'href' => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_rw&ac=order&status=2&manage=1$urlext",
            ),1);
            hb_message(lang_rw('bccg',0), 'success', 'reload');
        }
        break;
    case 'shen':
        if(submitcheck('logid')){
            $logid = intval($_GET['logid']);
            $rwlog = C::t('#xigua_rw#xigua_rw_log')->fetch($logid);
            if($rwlog['aduid']==$_G['uid'] || IS_ADMINID){
                $adinfo =  C::t('#xigua_rw#xigua_rw_ad')->fetch($rwlog['adid']);
                if($_GET['isok'] && $rwlog['status']!=3){
                    C::t('#xigua_rw#xigua_rw_log')->update($logid, array('status' => 3, 'confirmts' => TIMESTAMP));
                    if($rw_config['kctype']==2){
                        C::t('#xigua_rw#xigua_rw_ad')->incr($rwlog['adid'], 'complete', 1);
                    }
                    $allp = $rwlog['chujia'];
                    if($rw_config['shouxufei']> 0){
                        $prate = intval(str_replace('%', '', $rw_config['shouxufei']))/100;
                        $shouxufei = round($allp*$prate, 2);
                    }else{
                        $shouxufei = 0;
                    }
                    $income = $allp-$shouxufei;
                    $order_complete = lang('plugin/xigua_rw', 'order_complete');
                    $href = $_G['siteurl']."$SCRITPTNAME?id=xigua_rw&ac=order&logid=$logid$urlext";
                    $title = cutstr(strip_tags($adinfo['jieshao']), 40);
                    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                        'uid' => $rwlog['wxuid'],
                        'crts' => TIMESTAMP,
                        'size' => $income,
                        'note' => str_replace(array('{title}', '{shouxufei}', '{totalprice}',), array( $title, $shouxufei, $income, ), strip_tags($order_complete)),
                        'link' => $href,
                    ));
                    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($rwlog['wxuid'], 'money', $income);
                    notification_add($rwlog['wxuid'],'system', $order_complete, array('title' => $title, 'href' => $href, 'shouxufei'=>$shouxufei, 'totalprice'=> $income),1);
                    hb_message(lang_rw('shtg',0), 'success', 'reload');
                }else{
                    C::t('#xigua_rw#xigua_rw_log')->update($logid, array('status' => 4, 'confirmts' => TIMESTAMP));
                    hb_message(lang_rw('succeed',0), 'success', 'reload');
                }
            }
        }
        break;
    case 'getsxf':
        $p = $_GET['total'];
        $fdsxf = 0;
        if($rw_config['fdfei']){
            $fdsxf = round($p * $rw_config['fdfei']/100, 2);
        }
        include template('xigua_hb:header_ajax');
        echo floatval($fdsxf + $p);
        include template('xigua_hb:footer_ajax');
        break;
    case 'neword':
        $adinfo =  C::t('#xigua_rw#xigua_rw_ad')->fetch($_GET['adid']);
        $wxid = intval($adinfo['wxid']);
        if($wxid){
            $wxinfo =  C::t('#xigua_rw#xigua_rw_wx')->fetch($wxid);
            $title = 'ID:'.implode(',', $wxid).'-'.lang_rw('dotpub',0).'-'. cutstr(strip_tags($adinfo['jieshao']), 20);
            $rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_rw&ac=order&manage=1{$urlext}";
            $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $wxinfo['rent_price'], $title , 'common_rw_pub', array(
                'data' => array('newids' => array($_GET['adid']), 'newdata' => $adinfo, 'wxids' => array($wxid)),
                'callback' => array(
                    'file' => 'source/plugin/xigua_rw/function.php',
                    'method' => 'rw_multis_pay_callback'
                ),
                'location' => $rtl,
                'referer' => $rtl,
            ));
            $rl = urlencode($rtl);
            $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
            include template('xigua_hb:header_ajax');
            echo $jumpurl;
            include template('xigua_hb:footer_ajax');
        }else{
            $data = $adinfo;
            $totalprice = $data['danshu'] * $data['rent_price'];
            $data['crts'] = TIMESTAMP;
            if($rw_config['adshen']){
                $data['status'] = -1;
            }
            $newid = $_GET['adid'];

            $fdsxf = 0;
            if($rw_config['fdfei']){
                $fdsxf = round($totalprice * $rw_config['fdfei']/100, 2);
            }
            $totalprice += $fdsxf;
            if($totalprice>0){
                $title = 'ID:'.$newid.'-'.lang_rw('dotpub',0).'-'. cutstr(strip_tags($data['jieshao']), 20);
                $rtl = $_G['siteurl']."$SCRITPTNAME?id=xigua_rw&ac=myadd{$urlext}";
                $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title , 'common_rw_pub', array(
                    'data' => array('newid' => $newid, 'newdata' => $data),
                    'callback' => array(
                        'file' => 'source/plugin/xigua_rw/function.php',
                        'method' => 'rw_multi_pay_callback'
                    ),
                    'location' => $rtl,
                    'referer' => $rtl,
                ));
                $rl = urlencode($rtl);
                $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
                include template('xigua_hb:header_ajax');
                echo $jumpurl;
                include template('xigua_hb:footer_ajax');
            }
        }
        break;
}