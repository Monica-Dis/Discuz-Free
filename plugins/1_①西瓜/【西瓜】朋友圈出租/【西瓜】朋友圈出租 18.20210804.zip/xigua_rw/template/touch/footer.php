<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="pub_ctrl" class='weui-popup__container popup-bottom z501'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <h1 class="title">{lang xigua_rw:xzfblx}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <a href="$SCRITPTNAME?id=xigua_rw&ac=join{$urlext}" class="weui-cell before_none">
                    <div class="weui-cell__hd" >
                        <label><img src="source/plugin/xigua_rw/static/img/wechat.png?12"></label>
                    </div>
                    <div class="weui-cell__bd">
                        <p class="cfff f16">{lang xigua_rw:wxhrz}</p>
                        <p class="f14 mt5 cfff">{lang xigua_rw:wsgr}</p>
                    </div>
                </a>
                <a href="$SCRITPTNAME?id=xigua_rw&ac=add{$urlext}" class="weui-cell before_none">
                    <div class="weui-cell__hd" >
                        <label><img src="source/plugin/xigua_rw/static/img/pub.png?12"></label>
                    </div>
                    <div class="weui-cell__bd">
                        <p class="cfff f16">{lang xigua_rw:pubadd}</p>
                        <p class="f14 mt5 cfff">{lang xigua_rw:wxfbgg}</p>
                    </div>
                </a>
                <a href="$SCRITPTNAME?id=xigua_rw&ac=my{$urlext}" class="weui-cell before_none">
                    <div class="weui-cell__hd" >
                        <label><img src="source/plugin/xigua_rw/static/img/gr2.png?12"></label>
                    </div>
                    <div class="weui-cell__bd">
                        <p class="cfff f16">{lang xigua_rw:grzx}</p>
                        <p class="f14 mt5 cfff">{lang xigua_rw:gr_tip}</p>
                    </div>
                </a>
                <a href="javascript:;" class="picker-button close-popup iclose"><i class="iconfont icon-guanbijiantou c9 f24"></i></a>
            </div>
        </div>
    </div>
</div>
<!--{template xigua_rw:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?2{VERHASH}"></script>
<script src="source/plugin/xigua_rw/static/js/rw.js?2{VERHASH}"></script>
<script>
$(document).on('click','.offline_btn', function () {
    var that = $(this);
    $.confirm( that.data('xiajia') ? '{lang xigua_rw:qdxj}':'{lang xigua_rw:qdsj}', function() {$.showLoading();
        $.ajax({
            type: "POST",
            url: _APPNAME+"?id=xigua_rw&ac=com&do=offline&inajax=1",
            data:{formhash:FORMHASH, adid:that.data('id'), xiajia:that.data('xiajia')},
            dataType: "xml",
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            }
        });
    }, function() {
    });
});
var Clipboard = new ClipboardJS('.clickcopy');
Clipboard.on('success', function (e) {
    $.alert('<div class="free_dv">{lang xigua_rw:pyqms}<em class="color-red2">{lang xigua_rw:fzcg}</em></div>');
});
var adid = 0,loceker=0,adtype='';
$(document).on('click','.qiangdan', function () {
<!--{if $rw_config[onlyapp] && $rw_config[apptip]}-->
if(!IN_APP){$.alert("{$rw_config[apptip]}", function() {window.location.href = "{$rw_config[applink]}";});return false;}
<!--{/if}-->
var that = $(this);
adid = that.data('id');
adtype = that.data('adtype');
if(that.data('wx')<1){
    $.modal({
        title: "{lang xigua_rw:jdsb}",
        text: "{lang xigua_rw:jdsb_tip}",
        buttons: [
            { text: "{lang xigua_rw:wzdl}", className: "default"},
            { text: "{lang xigua_rw:sqrz}", onClick: function(){
            hb_jump(_APPNAME+'?id=xigua_rw&ac=join{$urlext}');
            }}
        ]
    });
}else{
    if(that.data('wxid')>0){
        $.modal({
            title: "<div class=\"tuan_recommend_title\"><span class=\"tuan_recommend_title_text c3\">{lang xigua_rw:mzsm}</span></div>",
            text: '{$jdmzsm}',
            buttons: [
                { text: "{lang xigua_rw:guanbi}", className: "default", onClick: function(){ }},
                { text: "{lang xigua_rw:tongyi}", onClick: function(){
                    send_qiang(adid,that.data('wxid'), adtype);
                }}
            ]});
    }else{
        $('#chose_ctrl').popup();
        return false;
    }
}
});
$(document).on('click','.chose_wxid', function () {
    var that = $(this);
    send_qiang(adid,that.data('wxid'), adtype);
});
function send_qiang(adid, wxid, adtype){
    if(loceker){
        return;
    }
    loceker = 1;
    $.ajax({
        type: 'POST',
        url: _APPNAME +'?id=xigua_rw&ac=com&do=qiangdan&inajax=1',
        data: {'formhash':FORMHASH, 'adid':adid, 'wxid': wxid, 'adtype': adtype},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
            setTimeout(function () {
                loceker = 0;
            }, 200);
        },
        error: function () {
            loceker = 0;
        }
    });
}
$(document).on('click','.ztf', function () {
    var that = $(this);
    hb_jump(_APPNAME+'?id=xigua_rw&ac=add&wxid='+that.data('wxid')+_URLEXT);
});
</script>