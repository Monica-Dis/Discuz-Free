<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_rw:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{eval $mg = $_GET['manage']? '&manage=1':'';}-->
    <div class="weui-navbar before_none after_none">
        <!--{loop $log_status2 $_k $_v}-->
        <a href="$SCRITPTNAME?id=xigua_rw&ac=order&status={$_k}$mg" class="weui-navbar__item <!--{if $_GET[status]==$_k}-->weui_bar__item_on<!--{/if}-->">
            <span>$_v</span>
        </a>
        <!--{/loop}-->
    </div>
    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">
            <input name="id" value="xigua_rw" type="hidden">
            <input name="ac" value="order" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <input type="hidden" name="manage" value="$manage">
            <input type="hidden" name="status" value="$_GET[status]">
            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_rw:spmcddh}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_rw:spmcddh}</span>
            </label>
        </form>
        <a href="javascript:;" class="search_bar_btn main_color" id="dosearch">{lang xigua_rw:search}</a>
        <a href="$SCRITPTNAME?id=xigua_rw&ac=order&status={$_GET[status]}{$mg}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_rw:qx}</a>
    </div>

    <div  id="list" class="weui-cells p0 mt0 before_none after_none" style="background:transparent"></div>
    <!--{template xigua_hb:loading}-->
</div>

<script>
    var loadingurl = window.location.href+'&ac=order_li&inajax=1&page=';
    var noTit = true;
</script>
<!--{eval $rw_tabbar=1;$tabbar=0;}-->
<!--{template xigua_rw:footer}-->
<div id="upload_ctrl" class='weui-popup__container popup-bottom z501'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_rw:guanbi}</a>
                <h1 class="title"></h1>
            </div>
        </div>
        <div class="modal-content">
            <form action="$SCRITPTNAME?id=xigua_rw" method="post" id="form_popup">
                <input type="hidden" name="formhash" value="{FORMHASH}">
                <input type="hidden" name="ac" value="com">
                <input type="hidden" name="do" value="uploadlog">
                <input type="hidden" name="logid" id="form_logid" value="0">
                <div class="weui-cells before_none after_none">
                    <div class="weui-cell">
                        <div class="weui-cell__bd">
                            <div class="weui-uploader">
                                <div class="weui-uploader__hd">
                                    <p class="weui-uploader__title c3 f15">{lang xigua_rw:pyqjt1}<em class="color-red">*</em></p>
                                    <div class="weui-uploader__info f12"><span class="color-red">{lang xigua_rw:pyqjt1_tip}</span><div id="pz1_tip"></div></div>
                                </div>
                                <div class="weui-uploader__bd">
                                    <ul class="weui-uploader__files" data-only="1" id="htmlli1"></ul>
                                    <!--{if !$_GET['manage']}-->
                                    <div class="weui-uploader__input-box newupload">
                                        <!--{if HB_INWECHAT && $config[multiupload]}-->
                                        <a class="weui-uploader__input" data-name="form[pz1]" data-multi="1"></a>
                                        <!--{else}-->
                                        <input class="weui-uploader__input" data-name="form[pz1]" type="file" data-multi="1">
                                        <!--{/if}-->
                                        <img src="source/plugin/xigua_rw/static/img/up.png">
                                        <p>$tjtp</p>
                                    </div>
                                    <!--{/if}-->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__bd">
                            <div class="weui-uploader">
                                <div class="weui-uploader__hd">
                                    <p class="weui-uploader__title c3 f15">{lang xigua_rw:pyqjt2}<em class="color-red">*</em></p>
                                    <div class="weui-uploader__info f12"><span class="color-red">{lang xigua_rw:pyqjt2_tip}{$rw_config['jiange']}{lang xigua_rw:fz}{lang xigua_rw:pyqjt3_tip}</span><div id="pz2_tip"></div></div>
                                </div>
                                <div class="weui-uploader__bd">
                                    <ul class="weui-uploader__files logo_fields" data-only="1" id="htmlli12"></ul>
                                    <!--{if !$_GET['manage']}-->
                                    <div class="weui-uploader__input-box newupload">
                                        <!--{if HB_INWECHAT && $config[multiupload]}-->
                                        <a class="weui-uploader__input" data-name="form[pz2]"></a>
                                        <!--{else}-->
                                        <input class="weui-uploader__input" data-name="form[pz2]" type="file">
                                        <!--{/if}-->
                                        <img src="source/plugin/xigua_rw/static/img/up.png">
                                        <p>$tjtp</p>
                                    </div>
                                    <!--{/if}-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="fix-bottom cl" style="position:relative">
                    <!--{if $_GET['manage']}-->
<div class="stas_bx" id="sta_2" style="display:none">
    <a class="manageshen weui-btn z half weui-btn_default" data-ok="0">{lang xigua_rw:shbg}</a>
    <a class="manageshen weui-btn y half weui-btn_primary mt0" data-ok="1">{lang xigua_rw:shtg1}</a>
</div>
<div class="stas_bx" id="sta_1" style="display:none">
    <a class="manageshen weui-btn  weui-btn_default weui-btn_disabled mt0">{lang xigua_rw:ddscpj}</a>
</div>
                    <!--{else}-->
                    <span class="c9 f14">{lang xigua_rw:scpzddtg}</span>
                    <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit_popup" value="{lang xigua_rw:qd}">
                    <!--{/if}-->
                </div>
            </form>
        </div>
    </div>
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<!--{template xigua_hb:enter_up}-->
<script>
$(document).on('click','.uppz', function () {
    var upload_ctrl = $('#upload_ctrl');
    var that = $(this);
    var status_l = that.data('status');
    var pz1_img = that.data('pz1_img');
    var pz2_img = that.data('pz2_img');
    var htmlli1 = pz1_img ? '<li class="imgloading weui-uploader__file1 weui-uploader__file_status" style="background-image:url('+pz1_img+')"><input type="hidden" name="form[pz1][]" value="'+pz1_img+'"/><img src="'+pz1_img+'" style="display:none" /></li>' : '';
    $('#htmlli1').html(htmlli1);
    var htmlli12 = pz2_img ? '<li class="imgloading weui-uploader__file1 weui-uploader__file_status" style="background-image:url('+pz2_img+')"><input type="hidden" name="form[pz2][]" value="'+pz2_img+'"/><img src="'+pz2_img+'" style="display:none" /></li>' : '';
    $('#htmlli12').html(htmlli12);
    $('#form_logid').val(that.data('logid'));
    $('.manageshen').attr('data-id', that.data('logid'));
    $('#pz1_tip').html(that.data('pz1_crts'));
    $('#pz2_tip').html(that.data('pz2_crts'));
    upload_ctrl.find('.title').html(that.data('title'));
    $('.stas_bx').hide();
    $('#sta_'+status_l).show();
    if(!(status_l==1 || status_l==2 || status_l==4)){
        $('.newupload').hide();
    }
    if(that.data('ma')){
    }
    upload_ctrl.popup();
});
var form_popup_lock = 0;
$(document).on('submit', '#form_popup', function () {
    var dosubbtn = $('#dosubmit_popup');
    var that = $(this);
    if (form_popup_lock === 1) {
        return false;
    }
    $.showLoading();
    form_popup_lock = 1;
    $.ajax({
        type: 'post',
        url: that.attr('action') + '&inajax=1' + _URLEXT,
        data: that.serialize(),
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            form_popup_lock = 0;
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () {
            $.hideLoading();
            form_popup_lock = 0;
        }
    });
    return false;
});
function cropCallback(){
    $('#upload_ctrl').popup();
    return false;
}
$(document).on('click','.manageshen', function () {
    var that = $(this);
    var conft = '';
    if(that.data('ok')>0){
        conft = '{lang xigua_rw:qdtgm}';
    }else{
        conft = '{lang xigua_rw:qrshbg}';
    }
    $.confirm(conft, function() {
        $.ajax({
            type: 'post',
            url: '$SCRITPTNAME?id=xigua_rw&ac=com&do=shen&inajax=1' + _URLEXT,
            data: {formhash:'{FORMHASH}', isok:that.data('ok'), logid:that.data('id') },
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if (null == data) {
                    tip_common('error|' + ERROR_TIP);
                    return false;
                }
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {
                $.hideLoading();
            }
        });
    }, function() {
    });
    return false;
});
</script>