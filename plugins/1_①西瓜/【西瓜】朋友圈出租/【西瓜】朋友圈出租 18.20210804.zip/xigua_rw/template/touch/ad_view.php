<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_rw:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="bgf">
    <div class="main_color top_tip" style="background:{$bgc}">
        <p>{lang xigua_rw:add_tip}</p>
    </div>
    </div>
    <div class="jv_desc weui-cells before_none after_none flex12 tc mt0">
        <div class="yaoqiu main_bg">{lang xigua_rw:wxyq}</div>
        <div class="flex34">
            <div class="flex34_desc">{lang xigua_rw:gender1}</div>
            <div>{$v[gender]}</div>
        </div>
        <div class="flex34">
            <div class="flex34_desc">{lang xigua_rw:rsyq}</div>
            <div>{$v[friend_num]}</div>
        </div>
        <div class="flex34">
            <div class="flex34_desc">{lang xigua_rw:dqyq}</div>
            <div style="white-space: nowrap;max-width: 40vw;overflow: hidden;text-overflow: ellipsis;">{$v[areawant_str]}</div>
        </div>
    </div>
    <div class="jv_desc weui-cells before_none after_none cl"><h2 class="h2top cl">{lang xigua_rw:pyqms} <span class="f12 c9 y clickcopy" data-clipboard-text="{echo strip_tags($jieshao_txt)}">{lang xigua_rw:yjfz}</span></h2>
        <div>{$v[jieshao]}</div>

        <!--{if $v[note]}-->
        <div class="mt10 f14">
            <span class="c9 mr10">{lang xigua_rw:note}</span>
            {$v[note]}
        </div>
        <!--{/if}-->

        <div class="viewright c9 f12 mt5 y">
            <span><i class="iconfont icon-browse f12"></i> {lang xigua_hb:views} : $v[views]</span>
        </div>

    </div>
    <div class="jv_desc weui-cells before_none after_none">
        <h2 class="h2top">{lang xigua_rw:pyqtp} <span class="f12 c9 y">{lang xigua_rw:djtp}</span></h2>
        <div class="cl feed-preview-pic">
            <!--{loop $v[album_ary] $_k $_v}-->
            <span class="imgloading"><img src="$_v"></span>
            <!--{/loop}-->
        </div>
    </div>
    <div class="jv_desc weui-cells before_none after_none">
        <h2 class="h2top">{lang xigua_rw:pyqxgt}</h2>
        <div class="cl feed-preview-pic">
            <span class="imgloading"><img src="$v[yangban]" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'"></span>
            <span class="yangban_desc">{lang xigua_rw:pyqxgt_tip}</span>
        </div>
    </div>

    <div class="weui-cells wxts">
        <a class="weui-cell" href="$SCRITPTNAME?id=xigua_hj">
            <div class="weui-cell__bd c6">
                <span class="c3">{lang xigua_rw:wxts}</span>
                <span class="color-red2 ib ml8">{lang xigua_rw:wxts2}</span>
            </div>
            <div class="weui-cell__ft tc">
                <i class="main_color iconfont icon-jubao2"></i>
                <p class="main_color" style="line-height:1">{lang xigua_hj:wyjb}</p>
            </div>
        </a>
    </div>
    <div class="fix-bottom" style="padding:0">
        <div class="confirm_foot">
            <div class="confirm_foot_d">
                <div>
                    <div class="f12 lineheight30"><span>&yen;</span> <span class="ml0 f20">{$v[rent_price]}</span></div>
                    <div class="f12 c9 lineheight1">{lang xigua_rw:wcsy} ({lang xigua_rw:yj} {$v[complete]}/{$v[danshu]})</div>
                </div>
            </div>
            <!--{if !$v[wxid]}-->
            <!--{if $v[complete] == $v[danshu]}-->
            <a class="confirm_foot_btn op8"  href="javascript:;">{lang xigua_rw:yqw}</a>
            <!--{elseif $wxid && $retjie = DB::fetch_first('select * from %t where wxuid=%d and adid=%d and wxid=%d and status in(1,2,3)', array('xigua_rw_log', $_G[uid], $_GET[adid], $wxid))}-->
            <a class="confirm_foot_btn op8"  href="javascript:;">{lang xigua_rw:yiqiang}</a>
            <!--{else}-->
            <a class="confirm_foot_btn qiangdan" data-adtype="zhudong" data-id="$v[adid]" data-wx="{$haswx}" data-wxid="{$wxid}" href="javascript:;">{lang xigua_rw:zhudong}</a>
            <!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
</div>
<div id="chose_ctrl" class='weui-popup__container popup-bottom z501'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_rw:qx}</a>
                <h1 class="title">{lang xigua_rw:qxzwx}</h1>
            </div>
        </div>
        <div class="modal-content" style="max-height:70vh;-webkit-overflow-scrolling: touch;">
            <!--{eval $list = $allme;$_GET['chose']=1;}-->
            <!--{subtemplate xigua_rw:wx_li}-->
        </div>
    </div>
</div>
<a class="right_float hbtn" href="$SCRITPTNAME?id=xigua_rw&high=0" style="background-image:url(source/plugin/xigua_rw/static/img/inedx.png);" ></a>
<!--{eval $tabbar=0;}-->
<!--{template xigua_rw:footer}-->