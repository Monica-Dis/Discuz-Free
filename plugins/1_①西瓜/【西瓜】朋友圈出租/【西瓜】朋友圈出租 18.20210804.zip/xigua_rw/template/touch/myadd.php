<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $manage}-->
<!--{eval $mg = '&manage=1';}-->
<!--{/if}-->
<!--{eval $keyword = $_GET['keyword']}-->
<!--{template xigua_rw:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar before_none after_none">
        <!--{loop $wxstatuss $_k $_v}-->
        <a href="$SCRITPTNAME?id=xigua_rw&ac=myadd&status={$_k}$mg" class="weui-navbar__item <!--{if $_GET[status]==$_k}-->weui_bar__item_on<!--{/if}-->">
            <span>$_v</span>
        </a>
        <!--{/loop}-->
    </div>
    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">
            <input name="id" value="xigua_rw" type="hidden">
            <input name="ac" value="my" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <input type="hidden" name="manage" value="$manage">
            <input type="hidden" name="status" value="$_GET[status]">
            <input type="hidden" name="ac" value="myadd">
            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_rw:gggjc}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_rw:gggjc}</span>
            </label>
        </form>
        <a href="javascript:;" class="search_bar_btn main_color" id="dosearch">{lang xigua_rw:search}</a>
        <a href="$SCRITPTNAME?id=xigua_rw&ac=myadd&status={$_GET[status]}{$mg}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_rw:qx}</a>
    </div>
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
</div>

<div class="right_float hbtn hbtn2" onclick="hb_jump('$SCRITPTNAME?id=xigua_rw&ac=add');"></div>
<script>var loadingurl = window.location.href+'&ac=add_li&status={$_GET[status]}&is_my=1&inajax=1&manage=$manage&keyword=$keyword&page=';</script>
<!--{eval $tabbar=0;$rw_tabbar=1;}-->
<!--{template xigua_rw:footer}-->
<script>
$(document).on('click','.nowpady', function () {
    var that = $(this);
    $.ajax({type: 'get',url: '$SCRITPTNAME?id=xigua_rw&ac=com&do=neword&adid='+that.data('adid'),
        dataType: 'xml',success: function(data) {
            if (null == data) {return false;}
            var s = $.trim(data.lastChild.firstChild.nodeValue);
            if (!s) {return false;}
            console.log(s);
            hb_jump(s);
        }
    });
});
</script>