<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="rwad_li">
    <!--{if $_GET['is_my']}-->
    <div class="yaoqiu2 main_color" style="background-color:$bgc">$wxstatuss[$v[status]]</div>
    <!--{elseif $rw_config[showyq]}-->
    <div class="yaoqiu2 main_color" style="background-color:$bgc">{lang xigua_rw:yq}</div>
    <!--{/if}-->
    <div class="cl rwad_tit adjump" data-id="$v[adid]">
        <div><i class="iconfont icon-weizhidingwei f12 ca"></i> {$v[areawant_str_ary][0]}</div>
        <div><i class="iconfont icon-xingbie f12 ca"></i> {$v[gender]}</div>
        <div><i class="iconfont icon-haoyou f12 ca"></i> {$v[friend_num]}</div>
    </div>
    <div class="rwad_desc cl  adjump" data-id="$v[adid]">
        <div class="z">
            <img src="{$v[album_ary][0]}" />
        </div>
        <div class="z rwad_jieshao">
            $v[jieshao]
        </div>
    </div>
    <div class="rwad_p cl">
        <!--{if $v[wxid]}-->
        <div class="pric_outer color-red2">{lang xigua_rw:pdg}{$v[wxinfo][username]} <em class="f20">{$v[rent_price]}</em><em>{lang xigua_hb:yuan}</em></div>
        <!--{else}-->
        <div class="pric_outer">{lang xigua_rw:wcsy} <em class="f20">{$v[rent_price]}</em><em>{lang xigua_hb:yuan}/{lang xigua_rw:d}</em></div>
        <!--{/if}-->
        <div class="flex1">
            <div class="seckill-percent">
                <div class="percent-line">
                    <div class="percent-fill" style="width:{$v[percent]}%"></div>
                </div>
                <div class="percent-line-word cl c9">{lang xigua_rw:jd} <em class="c3">{$v[percent]}%</em> <em class="y"><span>{$v[complete]} / </span>{$v[danshu]}</em></div>
            </div>
        </div>
        <!--{if $_GET['is_my']}-->
        <div>
        <!--{if !$v[wxid]}-->
            <a href="$SCRITPTNAME?id=xigua_rw&ac=add&old_id=$v[adid]" class="weui-btn weui-btn_mini whbtn_wxul">{lang xigua_rw:edit}</a>
            <!--{if $v[status]==-3}-->
            <a href="javascript:;" class="weui-btn weui-btn_mini whbtn_wxul offline_btn" data-id="$v[adid]" data-xiajia="0">{lang xigua_rw:sj}</a>
            <!--{elseif $v[status]==1}-->
            <a href="javascript:;" class="weui-btn weui-btn_mini whbtn_wxul offline_btn" data-id="$v[adid]" data-xiajia="1">{lang xigua_rw:xj}</a>
            <!--{/if}-->
        <!--{/if}-->
        <!--{if $v[status]==-2}-->
        <a href="javascript:;" data-adid="$v[adid]" class="weui-btn weui-btn_mini whbtn_wxul nowpady">{lang xigua_hb:pay}</a>
        <!--{/if}-->
        </div>
        <!--{else}-->
        <!--{if $v[complete] == $v[danshu]}-->
        <div><a class="weui-btn weui-btn_mini whbtn_wxul qdwx adjump after_none op8" data-id="$v[adid]">{lang xigua_rw:qw}</a></div>
        <!--{else}-->
        <div><a class="weui-btn weui-btn_mini whbtn_wxul qdwx adjump after_none" data-id="$v[adid]">{lang xigua_rw:zhudong}</a></div>
        <!--{/if}-->
        <!--{/if}-->
    </div>
</div>
<!--{/loop}-->