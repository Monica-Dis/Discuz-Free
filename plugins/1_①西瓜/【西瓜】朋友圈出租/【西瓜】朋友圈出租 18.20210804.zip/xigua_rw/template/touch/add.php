<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_rw:header}-->
<!--{template xigua_rw:join_style}-->
<div class="page__bd">
    <!--{if $_GET['old_id']}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <div class="bgf">
    <div class="main_color top_tip" style="background:{$bgc}">
        <p>{lang xigua_rw:add_tip}</p>
    </div></div>
    <form action="$SCRITPTNAME?id=xigua_rw&ac=add" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="manage" value="$manage">
        <input type="hidden" name="old_id" value="{$_GET[old_id]}">
        <input type="hidden" name="form[stid]" value="{$_GET[st]}">
        <input type="hidden" name="form[idu]" value="{$_GET[idu]}">
        <input type="hidden" id="lat" name="form[lat]" value="{$old_data['lat']}">
        <input type="hidden" id="lng" name="form[lng]" value="{$old_data['lng']}">
        <input type="hidden" id="province" name="form[province]" value="{$old_data['province']}">
        <input type="hidden" id="city" name="form[city]" value="{$old_data['city']}">
        <input type="hidden" id="district" name="form[district]" value="{$old_data['district']}">
        <input type="hidden" id="street" name="form[street]" value="{$old_data['street']}">
        <input type="hidden" id="street_number" name="form[street_number]" value="{$old_data['street_number']}">

        <!--{template xigua_rw:zhiding}-->

        <div class="weui-cells__title">{lang xigua_rw:pyqnr}</div>
        <div class="weui-cells mt0 before_none after_none">

            <div class="weui-cell" style="align-items: baseline;">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{lang xigua_rw:jieshao}<em class="color-red">*</em></label>
                </div>
                <div class="weui-cell__bd">
                    <textarea name="form[jieshao]" class="weui-textarea" placeholder="{lang xigua_rw:qtxpyqnr}" rows="3">{$old_data[jieshao]}</textarea>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title c3">{lang xigua_rw:album}<em class="color-red">*</em></p>
                            <div class="weui-uploader__info"><span class="color-red">{lang xigua_rw:zd9}</span></div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="9" data-maxtip="{echo str_replace('n', 9, lang_rw('zuiduozhao',0))}">
                                <!--{loop $old_data[album_ary] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box newupload">
                                <!--{if HB_INWECHAT && $config[multiupload]}-->
                                <a class="weui-uploader__input" data-name="form[album]" data-multi="1"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <!--{/if}-->
                                <img src="source/plugin/xigua_rw/static/img/up.png">
                                <p>{lang xigua_rw:tjtp}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title c3">{lang xigua_rw:fbxg}</p>
                            <div class="weui-uploader__info"><span class="color-red">{lang xigua_rw:fbxg_tip}</span></div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files logo_fields" data-only="1"><!--{if $old_data[yangban]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[yangban])">
                                    <input type="hidden" name="form[yangban][]" value="$old_data[yangban]"/>
                                    <div class="weui-uploader__file-content">
                                        <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box newupload">
                                <!--{if HB_INWECHAT && $config[multiupload]}-->
                                <a class="weui-uploader__input" data-name="form[yangban]"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[yangban]" type="file">
                                <!--{/if}-->
                                <img src="source/plugin/xigua_rw/static/img/up.png">
                                <p>{lang xigua_rw:tjtp}</p>
                            </div>
                            <div>
                                <div class="imgloading">
                                    <img class="demo_set" src="source/plugin/xigua_rw/static/img/demo.jpeg" />
                                </div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--{if !$wxids}-->
        <div class="weui-cells__title">{lang xigua_rw:xqwxlx}</div>
        <div class="weui-cells mt0 before_none after_none">
            <!--{if in_array(2, $rw_config['fbxm'])}-->
            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_rw:wxdq}<em class="color-red">*</em></label>
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" id="location_" name="form[addr]" placeholder="{lang xigua_hb:qingxuan}{lang xigua_rw:wxdq}" type="text" value="{echo $_GET[addr] ? $_GET[addr] : $old_data[addr]}" readonly>
                </div>
                <div class="weui-cell__ft">
                    <button class="weui-vcode-btn" id="openlocation" type="button">{lang xigua_hb:dingwei}</button>
                </div>
            </div>
            <!--{else}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_rw:wxdq}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input id="areawant" class="weui-input" name="form[areawant]" type="text" readonly value="{$old_data[areawant_str]}" placeholder="{lang xigua_rw:qxzfwqy}">
                </div>
                <div class="weui-cell__ft" id="needdiqu"></div>
            </div>
            <!--{/if}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_rw:yqhys}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[friend_num]" id="friend_num" type="tel" value="{$old_data[friend_num]}" placeholder="{lang xigua_rw:qxzyqhy}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_rw:hyxb}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[gender]" id="gender" type="text" value="{$old_data[gender]}" placeholder="{lang xigua_rw:qxzxbpx}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{if !$old_data}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_rw:rent_price1}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[rent_price]" id="rent_price" type="text" value="{$old_data[rent_price]}" placeholder="{lang xigua_rw:qxz}{lang xigua_rw:rent_price1}">
                </div>
                <div class="weui-cell__ft">{lang xigua_rw:yuan}/{lang xigua_rw:d}</div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_rw:danshu}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input name="form[danshu]" onkeyup="shisuan_price();" class="weui-input" type="tel" placeholder="{lang xigua_rw:qtx}{lang xigua_rw:danshu}" value="{echo $old_data ? $old_data[danshu]: ''}">
                </div>
                <div class="weui-cell__ft after_bgf">{lang xigua_rw:d}</div>
            </div>
            <!--{/if}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_rw:note}</label></div>
                <div class="weui-cell__bd">
                    <input name="form[note]" class="weui-input" type="text" placeholder="{lang xigua_rw:qtxnote}" value="{$old_data[note]}">
                </div>
            </div>
        </div>
        <!--{/if}-->
        <label class="weui-agree mt10" onclick='$("#agree__text").popup();'>
            <input id="weuiAgree" type="checkbox" checked="checked" disabled readonly class="weui-agree__checkbox">
            <span class="weui-agree__text"> {lang xigua_hb:agree}<a href="javascript:void(0);">{lang xigua_rw:fbxygz}</a> </span>
        </label>
        <div class="footer_fix"></div>
        <!--{if !$old_data}-->
        <div class="fix-bottom" style="padding:0">
            <div class="confirm_foot">
                <div class="confirm_foot_d">
                    <div>
                        <div class="f12 lineheight30"><span>&yen;</span> <span id="priceall" class="ml0 f20">$dftprice</span></div>
                        <!--{if $wxids}-->
                        <div class="f12 c9 lineheight1"><i class="main_color wxcount">$wxcount</i> {lang xigua_rw:ghj}</div>
                        <!--{else}-->
                        <div class="f12 c9 lineheight1">{echo str_replace('n', $rw_config['fdfei'].'%', lang_rw('zje', 0))}</div>
                        <!--{/if}-->
                    </div>
                </div>
                <input class="confirm_foot_btn" value="{lang xigua_rw:zffb}" id="dosubmit" name="dosubmit" type="submit">
            </div>
        </div>
        <!--{else}-->
        <div class="fix-bottom mt10">
        <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_rw:bc}">
        </div>
        <!--{/if}-->
        <!--{template xigua_rw:popup}-->
    </form>
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div id="agree__text" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <article class="weui-article">
                <h1>{lang xigua_rw:fbxygz}</h1>
                <section>
                    <section>
                        $rw_config[fbxy]
                    </section>
                </section>
            </article>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:woyi}</a>
        </div>
    </div>
</div>
<!--{if in_array(2, $rw_config['fbxm'])}-->
<!--{eval
$baidusdk = $_G['cache']['plugin']['xigua_hs']['baidusdk'] ? $_G['cache']['plugin']['xigua_hs']['baidusdk'] : $config['baidusdk'];
$qqmkey = $_G['cache']['plugin']['xigua_hs']['mkey']?$_G['cache']['plugin']['xigua_hs']['mkey']:$config[mkey];
$googlekey = $_G['cache']['plugin']['xigua_hs']['google'] ? $_G['cache']['plugin']['xigua_hs']['google'] : $config['google'];
}--><script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$qqmkey}"></script>
<!--{if $baidusdk}--><script type="text/javascript" src="//api.map.baidu.com/api?v=2.0&ak={$baidusdk}"></script><!--{/if}-->
<!--{if $googlekey}--><script src="https://maps.googleapis.com/maps/api/js?key={$googlekey}&sensor=false"></script><!--{/if}-->
<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer" style="position:absolute;width:100%;bottom:2.25rem;height:calc(100vh - 2.25rem)"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup popupL" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>
<!--{/if}-->
<div class="masker" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);display:none;z-index:1000" onclick='$("#choose_sh").select("close")'></div>
<!--{eval $tabbar=0;$rw_tabbar=0;}-->
<!--{template xigua_hb:enter_up}-->
<!--{template xigua_rw:footer}-->
<script>$(document).on('click','.J_ping', function(){var that = $(this), dosubm = $('.newbtn'); var nowp = parseFloat(that.find('.car-price').text()), pubp = parseFloat(dosubm.data('price'));if(isNaN(nowp)){nowp = 0;}if(isNaN(pubp)){pubp = 0;}var allp = pubp+nowp;if(nowp>0) {dosubm.val('{lang xigua_rw:pay}' + allp + '{lang xigua_hb:yuan}{lang xigua_rw:pub}{lang xigua_rw:bingzd}');}else if(allp<=0 || isNaN(allp)){dosubm.val('{lang xigua_rw:pub}');}else{dosubm.val('{lang xigua_rw:pay}'+pubp+'{lang xigua_hb:yuan}{lang xigua_rw:pub}');}$('.J_ping').addClass('type-item-gray').removeClass('type-item-active');$(this).addClass('type-item-active').removeClass('type-item-gray');});var jP = $('.J_ping:first-child');jP.trigger('click');jP.find('.typevip').trigger('click');$(document).on('click','#jineng', function () {var popcm =$('#popup_jineng');popcm.popup();popcm.show();setTimeout(function(){popcm.show();}, 500);return false;});

var sqs = [],gendser = [],guidetype = [], ages=[],friendnum=[];
<!--{loop $rent_prices $quan}-->sqs.push({title:'{$quan}', value:'{$quan}'});<!--{/loop}-->$("#rent_price").select({title: "{lang xigua_rw:qxzrent_price}",items: sqs, onChange:function(){ shisuan_price();}});
<!--{loop $guidetype $_k $_v}-->guidetype.push({title:'$_v', value:'$_k'});<!--{/loop}-->$("#guidetype").select({title: "{lang xigua_rw:qxzptlx}",items: guidetype});
<!--{loop $gendser2 $_k $_v}-->gendser.push({title:'$_v', value:'$_k'});<!--{/loop}-->$("#gender").select({title: "{lang xigua_rw:qxzxbpx}",items: gendser});
<!--{loop $ages $_k $_v}-->ages.push({title:'$_v', value:'$_k'});<!--{/loop}-->$("#ages").select({title: "{lang xigua_rw:qxzages}",items: ages});
<!--{loop $friend_nums $_k $_v}-->friendnum.push({title:'$_v', value:'$_k'});<!--{/loop}-->$("#friend_num").select({title: "{lang xigua_rw:qxzyqhy}",items: friendnum});

function shisuan_price(){
    var pric = $('#rent_price').val();
    pric = pric>0 ? parseFloat(pric) :0;
    var danshu = $('input[name="form[danshu]"]').val();
    danshu = danshu>0 ? parseInt(danshu) : 0;
    var ttal = danshu * pric;
    console.log(ttal);
    $('#priceall').html(ttal);
    $.ajax({
        type: 'get',
        url: _APPNAME +'?id=xigua_rw&ac=com&do=getsxf&total='+ttal+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s){
                $('#priceall').html(s);
            }
        },
        error: function () {}
    });
}
$(document).on('click','#areawant', function () {
    var popcm =$('#popup_areawant');
    popcm.popup();
    popcm.show();
    setTimeout(function(){
        popcm.show();
    }, 500);
    return false;
});
<!--{if $wxids}-->
$(document).on('click','.add_wx_li_zk', function () {
    var wxhl = $('.add_wx_li').find('.wxh_li:not(:first-child)');
    var add_wx_li_zk = $('.add_wx_li_zk');
    wxhl.toggleClass('showflex');
    if(wxhl.hasClass('showflex')){
        add_wx_li_zk.html('{lang xigua_rw:yc}');
    }else{
        add_wx_li_zk.html('{lang xigua_rw:zk}');
    }
});
setTimeout(function () {
    $('.add_wx_li_zk').trigger('click');
}, 150);
$(document).on('click','.remove_wxid', function () {
    var that = $(this);
    $('#wxid_'+that.data('wxid')).remove();
    var wxhli = $('.add_wx_li').find('.wxh_li');
    init_add_rent_price();
    $('.add_wx_li_zk').trigger('click').trigger('click');
    if(wxhli.length<1){
        var newUrl= _APPNAME+'?id=xigua_rw&ac=add'+_URLEXT;
        history.replaceState(null,null,newUrl);
        window.location.reload();
    }
});
function init_add_rent_price(){
    var wxhli = $('.add_wx_li').find('.wxh_li'), dftrentprice=0;
    wxhli.each(function () {
        dftrentprice+= parseFloat($(this).data('price'));
    });
    console.log(dftrentprice);
    $('#priceall').text(dftrentprice);
    $('.wxcount').text(wxhli.length);
}
init_add_rent_price();
<!--{/if}-->
<!--{if $rw_config[onlyapp]}-->
if(!IN_APP){
    $.alert('{$rw_config[apptip]}', function() {
        window.location.href = '{$rw_config[applink]}';
    });
}
<!--{/if}-->
if($('#openlocation').length>0){
    setTimeout(function () {
        IGNORETIP = 1;
        he_getlocation(setPoint);
    }, 800);
}
if(typeof wx!=='undefined'){
    wx.ready(function () {
        if($('#openlocation').length>0){
            he_getlocation(setPoint);
        }
    });
}
var chooseMapRes = [], OBJ = {};
function setForm(lat, lng, deft){
    $.showLoading();
    $.ajax({
        type: 'GET',
        <!--{if $_G['cache']['plugin']['xigua_hs']}-->
        url: location + '&id=xigua_hs&ac=getloc&lat='+lat+'&lng='+lng+'&inajax=1',
        <!--{else}-->
        url: location + '&id=xigua_hb:getloc&lat='+lat+'&lng='+lng+'&inajax=1',
        <!--{/if}-->
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s.indexOf('error')!=-1){
                tip_common(s);
            }else{
                var _actions = [];
                OBJ = jQuery.parseJSON(s.split('|')[1]);
                if(deft){
                    setFormField(OBJ[0]);
                    return true;
                }
                for(var j in OBJ){
                    _actions.push({
                        text: OBJ[j].address,
                        className:'obj_ obj_'+j,
                        onClick: function() {  $.closePopup(); }
                    });
                }
                $.actions({ actions:_actions });
            }
        },
        error: function () {
            $.hideLoading();
        }
    });
}
function setFormField(subj){
    $("input[name='form[addr]']").val(subj.address);
    $("input[name='form[lat]']").val(subj.location.lat);
    $("input[name='form[lng]']").val(subj.location.lng);
    $("input[name='form[province]']").val(subj.address_component.province);
    $("input[name='form[city]']").val(subj.address_component.city);
    $("input[name='form[district]']").val(subj.address_component.district);
    $("input[name='form[street]']").val(subj.address_component.street);
    $("input[name='form[street_number]']").val(subj.address_component.street_number);
}

function setPoint(position){
    if(typeof position.type != 'undefined'){
        if(position.type == 'ip'){
            if(IGNORETIP){}else {
                $.alert('{lang xigua_hd:locaerror}');
                chooseMap(position);
            }
            return false;
        }
    }
    setForm((position.latitude||position.lat), (position.longitude||position.lng), 1);
}
function chooseMap(position) {
    if(typeof mag != 'undefined') {
        mag.mapPick(function (res) {
            setForm(res.lat, res.lng, 0);
        });
        return false;
    }
    var center = new qq.maps.LatLng((position.latitude||position.lat), (position.longitude||position.lng));
    var mapinit = function () {
        geocoder = new qq.maps.Geocoder({
            complete: function (result) {
                chooseMapRes = result;
            }
        });
        geocoder.getAddress(center);
        map = new qq.maps.Map(document.getElementById("mapcontainer"), {center: center, zoom: 13});
        marker = new qq.maps.Marker({
            position: center, map: map
        });
        qq.maps.event.addListener(map, 'click', function (event) {
            var tmpcenter = new qq.maps.LatLng(event.latLng.getLat(), event.latLng.getLng());
            marker.setPosition(tmpcenter);
            geocoder.getAddress(tmpcenter);
        });
        $("#mapouter").popup();
    };
    mapinit();
}
$(document).on('click', '.obj_', function(){
    var k = parseInt($(this)[0].classList[2].replace('obj_', ''));
    setFormField(OBJ[k]);
    $("#new_popup").popup();
});
$('#openlocation').on('click', function(){
    var pot = [];
    IGNORETIP = 0;
    pot.push({ text: "{lang xigua_hb:locacurrt}", onClick: function() { he_getlocation(setPoint); } });
    if(!(GOOGLE && HB_INWECHAT)){
        pot.push({text: "{lang xigua_hb:xuandian}", onClick: function() { he_getlocation(chooseMap); } });
    }
    $.actions({ actions: pot});
});

$('.confirm-popup').on('click', function(){
    setForm(chooseMapRes.detail.location.lat, chooseMapRes.detail.location.lng, 0);
});
function he_getlocation(callback){
    if(0&&typeof mag != 'undefined'){
        mag.getLocation(function(res){
            callback(res);
        });
    }else if(typeof sq != 'undefined'){
        sq.getLocation(function(res){
            callback(res);
        });
    }else if(typeof QFH5 != 'undefined') {
        QFH5.getLocation(function (state, data) {
            if (state == 1) {
                callback(data);
            } else {
                alert(data.error);
            }
        });
    }else if((HB_INWECHAT&& {echo intval($config[multiupload])})==1) {
        wx.getLocation({
            type: 'gcj02',
            success: function (res) {
                callback(res);
            },
            cancel: function (res) {
            }
        });
    }else{
        console.log('myapp');
        var geolocation = new qq.maps.Geolocation(mkey, "myapp");
        geolocation.getLocation(callback, function () {
        }, {timeout:4000, failTipFlag:true});
    }
}
</script>