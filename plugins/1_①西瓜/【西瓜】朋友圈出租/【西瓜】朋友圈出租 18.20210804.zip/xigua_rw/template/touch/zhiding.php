<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $wxcount}-->
<div class="zhiding">
    <div class="weui-cells__title cl">
        <span class="z">{lang xigua_rw:x} <em class="main_color wxcount">{$wxcount}</em> {lang xigua_rw:grxwh}</span>
        <span class="y c3 add_wx_li_zk">{lang xigua_rw:zk}</span>
    </div>
    <div class="main_bg add_wx_li">
        <!--{template xigua_rw:wx_li}-->
    </div>
</div>
<!--{/if}-->