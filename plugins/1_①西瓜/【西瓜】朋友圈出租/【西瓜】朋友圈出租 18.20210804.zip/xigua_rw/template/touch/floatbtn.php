<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $ac=='pai'}-->
<a href="javascript:;" class="paibtn main_bg none"><i class="iconfont icon-zengjia"></i> {lang xigua_rw:pl}{lang xigua_rw:beidong}</a>
<div onclick="showmult();" class="right_float hbtn paictrl" style="line-height:2rem;font-size:.6rem;color:#fff;opacity:.95;background-image:none;bottom: 9.5rem;background-size: 1.1rem;">{lang xigua_rw:pl}</div>
<!--{/if}-->
<!--{if $rw_config[floaticon]}-->
<div class="right_float hbtn pubj" id="pubj" style="line-height:2rem;font-size:.6rem;color:#fff;opacity:.95;background-image:none;<!--{if $rw_config[floaticon]!='source/plugin/xigua_rw/static/img/j.png'}-->background-size:2rem;<!--{/if}-->" <!--{if $rw_config[onlyapp]}-->data-onlyapp="1" data-apptip="{$rw_config[apptip]}" data-applink="{$rw_config[applink]}"<!--{/if}-->>{lang xigua_hb:fabu0}</div><!--{/if}-->