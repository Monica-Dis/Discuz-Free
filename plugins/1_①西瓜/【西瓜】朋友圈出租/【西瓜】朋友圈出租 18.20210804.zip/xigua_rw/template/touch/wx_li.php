<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="wxh_li weui-cell" id="wxid_{$v[wxid]}" data-price="$v[rent_price]">
    <label class="z weui-check__label check123 <!--{if !$_GET['showlabel']}-->none<!--{/if}-->" for="chk{$v[wxid]}">
        <input name="newwxids[]" value="$v[wxid]" class="weui-check none" type="checkbox" id="chk{$v[wxid]}">
        <span class="weui-icon-checked"></span>
    </label>
    <div class="weui-cell__hd">
        <!--{if $_GET['chose']}-->
        <img class="imgp" src="{$v[wxqrcode]}" />
        <!--{else}-->
        <span class="pric"><em class="f12">&yen; </em>{$v[rent_price]}</span>
        <span class="pric_tip">{lang xigua_rw:rent_price}</span>
        <!--{/if}-->
        <span class="typbtn <!--{if $v[guidetype]==$guidetype['p_t']}-->typbtn_qy<!--{/if}-->"><!--{if $v[pttype]}-->{$v[pttype]}<!--{else}-->{$v[guidetype]}<!--{/if}--></span>
    </div>
    <div class="weui-cell__bd">
        <ul class="wx_ul f14">
            <li><img class="avat_img" src="{eval echo avatar($v['uid'], 'middle', 1)}"/> {$v[wx_username]}</li>
            <!--{if $v[ptfans]|| $v[pttag]}-->
                <!--{if $v[ptfans]}--><li><em>{lang xigua_rw:ptfans}</em> $v[ptfans]</li><!--{/if}-->
                <!--{if $v[pttag]}--><li><em>{lang xigua_rw:pttag}</em> $v[pttag]</li><!--{/if}-->
            <!--{else}-->
            <li>
                <em>{lang xigua_rw:hy}</em> $v[friend_num]
            </li>
            <!--{/if}-->
            <li><em>{lang xigua_rw:cs}</em> $v[areawant_str]</li>
            <li><em>{lang xigua_rw:fenlei}</em> $v[jineng_str]</li>
            <!--{if $_GET['is_my']|| $_GET['chose']}-->
            <li class="mt5"><em>{lang xigua_rw:realname}</em> $v[realname]</li>
            <li><em>{lang xigua_rw:weixin}</em> $v[weixin]</li>
            <li><em>{lang xigua_rw:sjh}</em> $v[mobile]</li>
            <!--{/if}-->
            <li class="mt5">
                <div class="detail_tags cl" style="height:1rem;overflow:hidden">
                    <!--{if $v[gender]}-->
                    <span class="border_global">{$v[gender]}</span>
                    <!--{/if}-->
                    <!--{if $v[ages]}-->
                    <span class="border_global">{$v[ages]}</span>
                    <!--{/if}-->
                </div>
            </li>
        </ul>
    </div>
    <div class="weui-cell__ft">
        <!--{if $_GET['is_my']}-->
        <!--{if $v[status]==-3}-->
        <a class="weui-btn weui-btn_mini whbtn_wxul offwx_btn" href="javascript:;"  data-id="$v[wxid]" data-xiajia="0">{lang xigua_hb:cxsj}</a>
        <!--{elseif $v[status]==1}-->
        <a class="weui-btn weui-btn_mini whbtn_wxul offwx_btn" href="javascript:;"  data-id="$v[wxid]" data-xiajia="1">{lang xigua_hb:xiajia}</a>
        <!--{/if}-->
        <a class="weui-btn weui-btn_mini whbtn_wxul" href="$SCRITPTNAME?id=xigua_rw&ac=join&old_id={$v[wxid]}$urlext">{lang xigua_rw:edit}</a>
        <!--{elseif $_GET['chose']}-->
        <a class="weui-btn weui-btn_mini whbtn_wxul qdwx after_none chose_wxid" data-wxid="$v[wxid]" href="javascript:;">{lang xigua_rw:xuanze}</a>
        <!--{elseif $_GET['ac']=='add'}-->
        <input name="form[wxids][]" value="$v[wxid]" type="hidden">
        <a class="f13 color-red2 remove_wxid" data-wxid="$v[wxid]" href="javascript:;">{lang xigua_rw:yichu}</a>
        <!--{else}-->
        <a class="weui-btn weui-btn_mini whbtn_wxul qdwx after_none ztf" data-wxid="$v[wxid]" href="javascript:;">{lang xigua_rw:ztf}</a>
        <!--{/if}-->
    </div>
</div>
<!--{/loop}-->