<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="pt_order_li">
    <div class="pt_shlink cl f14">
        <a href="javascript:;">
            <!--{if $v[type]=='zhudong'}-->
            <span class="f14 c3"> {$dantype[$v['type']]}{lang xigua_rw:logsn}: </span>
            <span class="f13 main_color">{$v['logsn']}</span>
            <!--{else}-->
            <span class="f14 color-red2"> {$dantype[$v['type']]}{lang xigua_rw:logsn}: </span>
            <span class="f13 color-red2">{$v['logsn']}</span>
            <!--{/if}-->
        </a>
        <div class="y f14 main_color"> {$log_status[$v[status]]}</div>
    </div>
    <div data-manage="<!--{if $_GET[manage]}-->1<!--{/if}-->" class="sp_good_ weui-cell weui-cell_access before_none after_none " data-id="$v[wxid]" >
        <div class="weui-cell__bd ">
            <p class="f14 c9">{lang xigua_rw:fdr}: <span class="c3"> <img class="avat_img" src="{eval echo avatar($v['aduid'], 'middle', 1)}"/> {$v[ad_username]}</span></p>
            <p class="f14 c9">{lang xigua_rw:jdr}: <span class="c3"> <img class="avat_img" src="{eval echo avatar($v['wxuid'], 'middle', 1)}"/> {$v[wx_username]}</span> <span>({$v[wx][realname]})</span></p>
            <p class="f14 c9">{lang xigua_rw:sjh}: <span class="c3">{$v[wx][mobile]}</span></p>
            <p class="f14 c9">{lang xigua_rw:wxh}: <span class="c3">{$v[wx][weixin]}</span></p>
            <p class="f14 c9">{lang xigua_rw:wxqrcode}: <a class="a" href="javascript:;" onclick="$.alert('<img src={$v[wx][wxqrcode]} />');">{lang xigua_rw:ck}</a></p>
            <p class="f14 c9">{lang xigua_rw:haoyoupic}: <a class="a" href="javascript:;" onclick="$.alert('<img src={$v[wx][haoyoupic]} />');">{lang xigua_rw:ck}</a></p>
        <!--{if $v[wx][ptfans]|| $v[wx][pttag]|| $v[wx][pttype]}-->
            <!--{if $v[wx][pttype]}--><p class="f14 c9">{lang xigua_rw:pttype}: <span class="c3">{$v[wx][pttype]}</span></p><!--{/if}-->
            <!--{if $v[wx][ptfans]}--><p class="f14 c9">{lang xigua_rw:ptfans}: <span class="c3">{$v[wx][ptfans]}</span></p><!--{/if}-->
            <!--{if $v[wx][pttag]}--><p class="f14 c9">{lang xigua_rw:pttag}: <span class="c3">{$v[wx][pttag]}</span></p><!--{/if}-->
        <!--{/if}-->
            <p class="f14 c9">{lang xigua_rw:jdsj}: <span class="c3">{$v[crts_u]}</span></p>
            <div class="cl rwad_tit adjump" data-id="$v[adid]">
                <div class="flexauto"><i class="iconfont icon-weizhidingwei f14 ca"></i> {$v[wx][areawant_str]}</div>
                <div class="flexauto"><i class="iconfont icon-xingbie f14 ca"></i> {$v[wx][gender]}</div>
                <div class="flexauto"><i class="iconfont icon-haoyou f14 ca"></i> {$v[wx][friend_num]}</div>
            </div>
        </div>
        <!--<div class="weui-cell__ft"></div>-->
    </div>
    <!--{if $v[status]==1 && $rw_config[chaoshi1]}-->
    <div class="tr c3 f12" style="padding: 12px 15px 0;line-height: 1;">{lang xigua_rw:chaoshijiezhi1}: <em class="color-red2">{echo date('Y-m-d H:i:s', $v[crts]+$rw_config[chaoshi1]*60);}</em></div>
    <!--{/if}-->
    <!--{if $v[status]==2 && $rw_config[chaoshi2] && $v[pz2_crts]>0}-->
    <div class="tr c3 f12" style="padding: 12px 15px 0;line-height: 1;">{lang xigua_rw:chaoshijiezhi2}: <em class="color-red2">{echo date('Y-m-d H:i:s', $v[pz2_crts]+$rw_config[chaoshi2]*60);}</em></div>
    <!--{/if}-->
    <div class="pt_func  weui-cell before_none">
        <div class="weui-cell__bd f14">
            {lang xigua_rw:wcsy}
            <span class="pric"><em class="f14">&yen; </em>{$v[chujia]}</span>
        </div>
        <div class="weui-cell__ft">
            <a class="weui-btn weui-btn_mini whbtn_wxul mt0 uppz" data-status="$v[status]" data-title="<!--{if !$_GET['manage']}-->{lang xigua_rw:sc}<!--{else}-->{lang xigua_rw:ck}<!--{/if}-->{lang xigua_rw:pzjt}" data-ma="<!--{if $_GET['manage']}-->1<!--{/if}-->" data-logid="{$v[id]}" data-pz1_img="{$v[pz1]}" data-pz1_crts="{$v[pz1_crts_u]}" data-pz2_crts="{$v[pz2_crts_u]}" data-pz2_img="{$v[pz2]}"><!--{if !$_GET['manage']}-->{lang xigua_rw:sc}<!--{else}-->{lang xigua_rw:ck}<!--{/if}-->{lang xigua_rw:pzjt}({$v[pznum]}/2)</a>
            <a class="weui-btn weui-btn_mini whbtn_wxul mt0 adjump" data-id="$v[adid]">{lang xigua_rw:rwjt}</a>
        </div>
    </div>
</div>
<!--{/loop}-->