<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $manage}-->
<!--{eval $mg = '&manage=1';}-->
<!--{/if}-->
<!--{eval $keyword = $_GET['keyword']}-->
<!--{template xigua_rw:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar before_none after_none">
        <!--{loop $wxstatuss $_k $_v}-->
        <a href="$SCRITPTNAME?id=xigua_rw&ac=mywx&status={$_k}$mg" class="weui-navbar__item <!--{if $_GET[status]==$_k}-->weui_bar__item_on<!--{/if}-->">
            <span>$_v</span>
        </a>
        <!--{/loop}-->
    </div>
    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">
            <input name="id" value="xigua_rw" type="hidden">
            <input name="ac" value="my" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <input type="hidden" name="manage" value="$manage">
            <input type="hidden" name="status" value="$_GET[status]">
            <input type="hidden" name="ac" value="mywx">
            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_rw:spmcddh}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_rw:spmcddh}</span>
            </label>
        </form>
        <a href="javascript:;" class="search_bar_btn main_color" id="dosearch">{lang xigua_rw:search}</a>
        <a href="$SCRITPTNAME?id=xigua_rw&ac=mywx&status={$_GET[status]}{$mg}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_rw:qx}</a>
    </div>
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
</div>

<div class="right_float hbtn" onclick="hb_jump('$SCRITPTNAME?id=xigua_rw&ac=join');"></div>
<script>var loadingurl = window.location.href+'&ac=wx_li&status={$_GET[status]}&is_my=1&inajax=1&manage=$manage&keyword=$keyword&page=';</script>
<!--{eval $tabbar=0;$rw_tabbar=1;}-->
<!--{template xigua_rw:footer}-->
<script>
$(document).on('click','.offwx_btn', function () {
    var that = $(this);
    $.confirm( that.data('xiajia') ? '{lang xigua_rw:qdxj}':'{lang xigua_rw:qdsj}', function() {$.showLoading();
        $.ajax({
            type: "POST",
            url: _APPNAME+"?id=xigua_rw&ac=com&do=offline&inajax=1",
            data:{formhash:FORMHASH, wxid:that.data('id'), xiajia:that.data('xiajia')},
            dataType: "xml",
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            }
        });
    }, function() {
    });
});
</script>