<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_rw:header}-->
<link href="source/plugin/xigua_hb/static/css/mynew.css?{VERHASH}" rel="stylesheet" /><style>.weui-cells{overflow: hidden;background: #fff;margin: 15px;border-radius: 10px;position: relative;padding: 0;}.weui-cells:before, .weui-cells:after, .weui-grids:before,.weui-grids:after,.weui-grid:before,.weui-grid:after{display:none}.my_new_bd .my__head_new{margin-bottom:35px}.weui-grid{padding:20px 0}.weui-grid__icon{text-align:center}
.weui-cell__bd{color:#272a2a}.weui-cell__ft{color:#a4a4ad}
</style>
<div class="page__bd my_new_bd">
    <div class="my__head_new main_bg" style="height:35vw">
    <i class="header-annimate-element1"></i><i class="header-annimate-element4"></i>
    <i class="header-annimate-element5"></i><i class="header-annimate-element6"></i>
    <i class="header-annimate-element7"></i><i class="header-annimate-element8"></i>
    <i class="header-annimate-element9"></i>
    <div class="my__head_wap block" style="height:35vw">
        <a class="setting" href="$SCRITPTNAME?id=xigua_hb&ac=myset">{lang xigua_hb:shzhi}</a>
        <div class="my__head_user z">
            <!--{if $_G['cache']['plugin']['xigua_member']}-->
            <a href="$SCRITPTNAME?id=xigua_member:profile" class="my__head_avatar z"><img src="{eval echo avatar($_G['uid'], 'middle', 1)}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'" ></a>
            <!--{else}-->
            <span class="my__head_avatar z"><img src="{eval echo avatar($_G['uid'], 'middle', 1)}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'"></span>
            <!--{/if}-->
            <div>
                <div class="my__head_nickname f16">{$_G[username]}</div>
                <a class="qblink">UID : {$_G[uid]}</a>
            </div>
        </div>
    </div>
</div>
<!--{eval $toutiaoitems = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_rw']['toutext'])));}-->
<!--{if $toutiaoitems}-->
<div class="float_nav weui-flex cl">
    <div class="swiper-container" id="newsSlider" data-autoplay="5000" data-speed="3000">
        <ul class="swiper-wrapper">
            <!--{loop $toutiaoitems $toutiaoitem}-->
            <!--{eval list($font, $link)= explode(",", trim($toutiaoitem)); }-->
            <li class="swiper-slide"> <b class="main_color mr8 f14"><i class="iconfont icon-tongzhi f14 "></i>{lang xigua_hb:xtgg}</b> <a href="$link" class="c9 f14">$font</a> </li>
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{/if}-->
<div class="weui-cells">
    <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_rw&ac=order">
        <div class="weui-cell__hd"><i class="iconfont icon-huojian color-forest"></i></div>
        <div class="weui-cell__bd">
            <p class="f15">{lang xigua_rw:wdrw}</p>
        </div>
        <div class="weui-cell__ft f15">$mylogcount</div>
    </a>
    <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_rw&ac=mywx">
        <div class="weui-cell__hd"><i class="iconfont icon-weixinzhifu1 color-forest"></i></div>
        <div class="weui-cell__bd">
            <p class="f15">{lang xigua_rw:wdwx}</p>
        </div>
        <div class="weui-cell__ft f15">$mywxcount</div>
    </a>
    <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_rw&ac=myadd">
        <div class="weui-cell__hd"><i class="iconfont icon-gengduo3 color-red2"></i></div>
        <div class="weui-cell__bd">
            <p class="f15">{lang xigua_rw:glwxq}</p>
        </div>
        <div class="weui-cell__ft f15">$myaddcount</div>
    </a>
    <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_rw&ac=order&manage=1">
        <div class="weui-cell__hd"><i class="iconfont icon-xianshiqianggou color-red2"></i></div>
        <div class="weui-cell__bd">
            <p class="f15">{lang xigua_rw:rwgl}</p>
        </div>
        <div class="weui-cell__ft f15">$myaddmcount</div>
    </a>
</div>
<div class="weui-cells">
    <a class="weui-cell weui-cell_access" <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jump_download();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao&mobile=2"<!--{/if}--><!--{/if}-->>
    <div class="weui-cell__hd"><i class="iconfont icon-qianbao2 color-red2"></i></div>
    <div class="weui-cell__bd">
        <p class="f15">{lang xigua_hb:myqb}</p>
    </div>
    <div class="weui-cell__ft f15 color-red2"><em class="f12">&yen;</em> {echo $qianbao[money]*100/100}</div>
    </a>
    <a class="weui-cell weui-cell_access f15" href="$SCRITPTNAME?id=xigua_hb&ac=mysetxx&hide_side=1">
        <div class="weui-cell__hd"><i class="iconfont icon-weixinzhifu1 color-forest"></i></div>
        <div class="weui-cell__bd">
            <p>{lang xigua_hb:xiaoxishezhi}</p>
        </div>
        <div class="weui-cell__ft"> </div>
    </a>
    <!--{if $dxp}-->
    <a class="weui-cell weui-cell_access f15" href="$myzlurl">
        <div class="weui-cell__hd"><i class="iconfont icon-shouji color-red"></i></div>
        <div class="weui-cell__bd">
            <p>{lang xigua_hb:bindmobile}</p>
        </div>
        <div class="weui-cell__ft">$muhumobile</div>
    </a>
    <!--{/if}-->
</div>
    <!--{template xigua_rw:floatbtn}-->
    <div class="weui-cells">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=about&mobile=2">
            <div class="weui-cell__hd"><i class="iconfont icon-guize color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_hb:bangzhu}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <!--{if IN_MAGAPP&& $config[magkefu]}-->
        <!--songtao://assistant?id=729661326364ccea8521d4f745c40342&name=xxx-->
        <a class="weui-cell weui-cell_access f15" href="{$config[magkefu]}">
            <!--{else}-->
            <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
                <!--{/if}-->
                <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
                <div class="weui-cell__bd">
                    <p class="f15">{lang xigua_hb:kefu}</p>
                </div>
                <div class="weui-cell__ft f15">{lang xigua_hb:zhwo}</div>
            </a>
    </div>
    <div class="footer_fix"></div>
</div>
<!--{eval $rw_tabbar=1;}-->
<!--{template xigua_rw:footer}-->
<script>
function jump_download() {
    $.confirm("$config[qbguide]", function() {
        window.location.href = '$config[qbguidelink]';
    }, function() {
    });
    return false;
}</script>