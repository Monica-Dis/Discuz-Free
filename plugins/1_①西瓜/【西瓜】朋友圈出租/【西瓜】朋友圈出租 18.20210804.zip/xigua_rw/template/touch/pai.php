<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_rw:header}-->
<!--{if $rw_config[pailogo]}--><div style="width:0;height:0;display:none"><img src="$rw_config[pailogo]" /></div><!--{/if}-->
<div class="page__bd">
    <!--{if $midnavslider}-->
    <div class="swipe cl" data-speed="6000">
        <div class="swipe-wrap">
            <!--{loop $midnavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $midnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->
    <!--{if $rw_config[paitype]==2}-->
    <div class="bgf">
        <div class="flnav">
            <div class="weui-cell__bd">
                <i class="iconfont icon-hot1 color-red2 f14"></i>
                <span class="ml3 f14">{lang xigua_rw:ggs}: <em class="main_color">{$total_count_ad} {lang xigua_rw:g}</em></span>
                <span class="ml3 f14">{lang xigua_rw:yrz}: <em class="main_color">{$total_count_wx} {lang xigua_rw:ren}</em></span>
                <span class="ml3 f14">{lang xigua_rw:dd}: <em class="main_color">{$total_count_dd} {lang xigua_rw:g}</em></span>
            </div>
        </div>
    </div>
    <!--{elseif $rw_config[paitype]==3}-->
    <style>
        .float_nav{position:relative;top:-.75rem;z-index:2;background:#fff;width:calc(100vw - 1.5rem);margin-left:.75rem;border-radius:.5rem;height:2rem;line-height:2rem;overflow:hidden;box-shadow:0 0 .5rem rgba(0,0,0,.05);font-size:.7rem}
        .float_nav>div{margin:0 .75rem}
        .float_nav>div .swiper-slide{white-space:nowrap;text-overflow:ellipsis;overflow:hidden}
        .float_nav{max-width:30.5rem}
    </style>
    <div class="float_nav weui-flex cl">
        <div class="swiper-container" id="newsSlider" data-autoplay="5000" data-speed="3000">
            <ul class="swiper-wrapper">
                <!--{eval $toutiaoitems = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_rw']['toutext'])));}-->
                <!--{loop $toutiaoitems $toutiaoitem}-->
                <!--{eval list($font, $link)= explode(",", trim($toutiaoitem)); }-->
                <li class="swiper-slide"> <b class="main_color mr8 f14"><i class="iconfont icon-tongzhi f14 "></i>{lang xigua_hb:xtgg}</b> <a href="$link" class="c9 f14">$font</a> </li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <!--{/if}-->
    <!--{eval
        if(!$numi1 = $rw_config['painum']*2):
            $numi1 = 10;
        endif;
        $jing_count = range(0, ceil(count($jing_list)/$numi1)-1);
    }-->
    <!--{if $jing_list}-->
    <nav class=" nav-list cl swipe">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $jing_list $k $n}-->
                    <!--{if $k && $k%$numi1==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li<!--{if $rw_config['painum']!=5&&$rw_config['painum']>0}--> {eval echo "style='width:".(100/$rw_config['painum'])."%'";}<!--{/if}-->>
                    <a href="{echo $n['outlink'] ? $n['outlink'] : "$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=".$n[id].$urlext}">
                    <span>
                        <img src="$n['icon']"/>
                    </span>
                        <em class="m-piclist-title">{$n['name']}</em>
                    </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position position1">
                <!--{loop $jing_count $k $v}-->
                <li {if $k==0} class="current" {/if}></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </nav>
    <!--{/if}-->
<!--{if $rw_config[paitext]}--><div class="weui-cells after_none before_none p15 f14" style="margin-bottom:.5rem">$rw_config[paitext]</div><!--{/if}-->
    <style>.nav_expand_panel{top:auto;height:auto;position:absolute;box-shadow:0 3px 20px rgba(0,0,0,.05);}.mask{display:none!important;}</style>
    <div class="weui-navbar fix_float" style="position:relative;top:auto;width:calc(100% - 1rem);padding:0 .5rem">
        <a data-id="1" class="dist_nav weui-navbar__item">
            <span>$distname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{if !in_array(5, $rw_config['rzbt'])}-->
        <a data-id="2" class="dist_nav weui-navbar__item <!--{if $jing_list}-->none<!--{/if}-->">
            <span>$catname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{/if}-->
        <a data-id="3" class="dist_nav weui-navbar__item">
            <span>$dftgender<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <a data-id="4" class="dist_nav weui-navbar__item">
            <span>$renshu<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{if in_array(5, $rw_config['rzbt'])}-->
        <a data-id="5" class="dist_nav weui-navbar__item">
            <span>$orderby_list[$orderby]<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{/if}-->
    </div>
    <div class="dist_show">
        <div id="dist_show_5" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <!--{loop $orderby_list $_ok $_ol}-->
                        <!--{if $_ok == 'near'}-->
                        <li class="<!--{if $orderby==$_ok}-->checked main_color<!--{/if}--> border_bfull"><a data-href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$cat_id&province=$province&city=$city&dist=$dist&gender={$_GET[gender]}&renshu={$_GET['renshu']}&orderby=$_ok&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}" id="near_cat" href="javascript:;">$_ol</a></li>
                        <!--{else}-->
                        <li class="<!--{if $orderby==$_ok}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$cat_id&province=$province&city=$city&dist=$dist&gender={$_GET[gender]}&renshu={$_GET['renshu']}&orderby=$_ok&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}">$_ol</a></li>
                        <!--{/if}-->
                        <!--{/loop}-->
                    </ul>
                </div>
            </div>
        </div>
        <div id="dist_show_1" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="first_check border_bfull <!--{if !$_GET[province]}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$cat_id&province=&city=&gender={$_GET[gender]}&renshu={$_GET[renshu]}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $dist0 $v}-->
                        <li class="first_check border_bfull <!--{if $_GET[province]==$v[name]}-->checked main_color<!--{eval $city_id=$v['id'];}--><!--{/if}-->" data-id="$v[id]"><a>$v[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="weui-flex__item checked">
                    <!--{loop $dist0 $k $v}-->
                    <ul class="sub_cheker <!--{if $_GET[province]!=$v['name']}-->none<!--{else}-->checked<!--{/if}-->" id="sub_cheker_$v[id]">
                        <li class="sub_check border_bfull"><a data-href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$cat_id&province={$v[name]}&city=&gender={$_GET[gender]}&renshu={$_GET[renshu]}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}" class="choose color-red">{lang xigua_rw:quan}{$v[name]}<i class="iconfont icon-coordinates_fill f14 "></i></a></li>
                        <!--{loop $v[child] $vv}-->
                        <li class="sub_check border_bfull <!--{if $city==$vv[name]&&$_GET[city]}-->checked main_color autotrigger<!--{/if}-->"><a data-href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$cat_id&province=$v[name]&city=$vv[name]&gender={$_GET[gender]}&renshu={$_GET[renshu]}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}" id="sub_check{$vv[id]}" data-id="$vv[id]" onclick="rw_getnext($vv[id], '{$vv[name]}','$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$cat_id&gender={$_GET[gender]}&renshu={$_GET[renshu]}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}')">$vv[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                    <!--{/loop}-->
                </div>
                <div class="weui-flex__item checked" id="ajaxbox"> <ul class="ajaxbox_cheker"></ul> </div>
            </div>
        </div>
        <div id="dist_show_2" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="first_cat_check border_bfull <!--{if !$cat_id}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=&province=$province&city=$city&gender={$_GET[gender]}&renshu={$_GET[renshu]}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $cat_tree $k $v}-->
                        <!--{if !$v[adlink]}-->
                        <li class="first_cat_check border_bfull <!--{if $cat_id==$v[id]||$pid==$v[id]}-->checked main_color<!--{/if}-->"<!--{if $v[sub]}--> data-id="$v[id]"<!--{/if}-->><a <!--{if !$v[sub]}--> href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$v[id]&province=$province&city=$city&dist=$dist&gender={$_GET[gender]}&renshu={$_GET[renshu]}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}"<!--{/if}-->>$v[name]</a></li>
                        <!--{/if}-->
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="weui-flex__item checked">
                    <!--{loop $cat_tree $k $v}-->
                    <ul class="sub_cat_cheker <!--{if !($cat_id==$v[id]||$pid==$v[id])}-->none<!--{/if}-->" id="sub_cat_cheker_$v[id]">
                        <li class="sub_cat_check border_bfull"><a <!--{if $cat_id==$v[id]}-->class="checked main_color"<!--{/if}--> href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$v[id]&province=$province&city=$city&dist=$dist&gender={$_GET[gender]}&renshu={$_GET[renshu]}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $v[sub] $vv}-->
                        <li class="sub_cat_check border_bfull"><a <!--{if $cat_id==$vv[id]}-->class="checked main_color"<!--{/if}--> href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$vv[id]&province=$province&city=$city&dist=$dist&gender={$_GET[gender]}&renshu={$_GET[renshu]}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}">$vv[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <div id="dist_show_3" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <!--{loop $gender $_ok $_ol}-->
                        <li class="<!--{if $_GET['gender']==$_ok}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$cat_id&province=$province&city=$city&dist=$dist&gender=$_ok&renshu={$_GET[renshu]}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}">$_ol</a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
            </div>
        </div>
        <div id="dist_show_4" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <!--{loop $friend_nums $_ok $_ol}-->
                        <li class="<!--{if $_GET['renshu']==$_ok}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_rw&ac=pai&cat_id=$cat_id&province=$province&city=$city&dist=$dist&gender={$_GET[gender]}&renshu={$_ok}&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&high={$_GET[high]}{$urlext}">$_ol</a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
</div>
<!--{template xigua_rw:floatbtn}-->
<script>scrollto = 1;var loadingurl = window.location.href+'&ac=wx_li&inajax=1&page=';
$(document).on('click','.choose', function () {var that = $(this), c_jmpurl = '';if(that.data('href')){ c_jmpurl = that.data('href'); }if(that.data('ctid')){ c_jmpurl = $('#sub_check'+that.data('ctid')).data('href'); }window.location.href= c_jmpurl;});
$(document).on('click','.dist_check', function () {$('.dist_check').removeClass('checked').removeClass('main_color'); $(this).addClass('checked').addClass('main_color');});
$(document).on('click','.dist_nav', function () {if($('.autotrigger').length>0){$('.autotrigger').find('a').trigger('click');}});
$(document).on('click','.first_check', function () {$('.ajaxbox_cheker').html('');});

function showmult(){
    if($('.paibtn').hasClass('none')){
        $('.check123').removeClass('none');
        $('.paibtn').removeClass('none');
        loadingurl = loadingurl.replace('&inajax=1', '&showlabel=1&inajax=1');
    }else{
        $('.check123').addClass('none');
        $('.paibtn').addClass('none');
        loadingurl = loadingurl.replace('&inajax=1', '&showlabel=0&inajax=1');
    }
}
$(document).on('change','input[name="newwxids[]"]', function () {
    var nu = $('input[name="newwxids[]"]:checked').length;
    var arg = '';
    $('input[name="newwxids[]"]:checked').each(function (){
        arg += '_'+$(this).val();
    });
    $('.paibtn').html('{lang xigua_rw:x} '+nu+' {lang xigua_rw:ren}{lang xigua_rw:beidong}').attr('href', _APPNAME+'?id=xigua_rw&ac=add&wxid='+arg);
});
</script>
<!--{eval $rw_tabbar=1;}-->
<!--{template xigua_rw:footer}-->
<!--{if in_array(5, $rw_config['rzbt'])}-->
<!--{eval
$baidusdk = $_G['cache']['plugin']['xigua_hs']['baidusdk'] ? $_G['cache']['plugin']['xigua_hs']['baidusdk'] : $config['baidusdk'];
$qqmkey = $_G['cache']['plugin']['xigua_hs']['mkey']?$_G['cache']['plugin']['xigua_hs']['mkey']:$config[mkey];
$googlekey = $_G['cache']['plugin']['xigua_hs']['google'] ? $_G['cache']['plugin']['xigua_hs']['google'] : $config['google'];
}--><script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$qqmkey}"></script>
<!--{if $baidusdk}--><script type="text/javascript" src="//api.map.baidu.com/api?v=2.0&ak={$baidusdk}"></script><!--{/if}-->
<!--{if $googlekey}--><script src="https://maps.googleapis.com/maps/api/js?key={$googlekey}&sensor=false"></script><!--{/if}-->
<script>
$(document).on('click', '#near_cat', function () {
    var that = $(this);
    var href = that.data('href');
    he_getlocation(function (position) {
        var lat = (position.latitude || position.lat), lng = (position.longitude || position.lng);
        window.location.href = href + '&lat=' + lat + '&lng=' + lng;
    });
});
function he_getlocation(callback){
    if(0&&typeof mag != 'undefined'){
        mag.getLocation(function(res){
            callback(res);
        });
    }else if(typeof sq != 'undefined'){
        sq.getLocation(function(res){
            callback(res);
        });
    }else if(typeof QFH5 != 'undefined') {
        QFH5.getLocation(function (state, data) {
            if (state == 1) {
                callback(data);
            } else {
                alert(data.error);
            }
        });
    }else if((HB_INWECHAT&& {echo intval($config[multiupload])})==1) {
        wx.getLocation({
            type: 'gcj02',
            success: function (res) {
                callback(res);
            },
            cancel: function (res) {
            }
        });
    }else{
        console.log('myapp');
        var geolocation = new qq.maps.Geolocation(mkey, "myapp");
        geolocation.getLocation(callback, function () {
        }, {timeout:4000, failTipFlag:true});
    }
}
</script>
<!--{/if}-->