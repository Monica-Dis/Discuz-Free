<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $rw_tabbar}-->
<!--{eval
$custom_nav = C::t('#xigua_rw#xigua_rw_nav')->fetch_index();
$navcount = count($custom_nav);
$is_off = 1;
$curturl = hb_currenturl();
}-->
<!--{if !$navcount}-->
<div class="weui-tabbar <!--{if $showfloatapp}-->none<!--{/if}-->">
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_rw{$urlext}" class="weui-tabbar__item <!--{if $ac=='index'&&$_GET[id]=='xigua_rw'}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-index weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">{lang xigua_hb:shouye}</p>
    </a>
    <a href="javascript:;" class="pubj weui-tabbar__item weui-bar__item_on <!--{if $config[showpubfont]}-->showpubfont<!--{/if}-->" id="pubj" <!--{if $rw_config[onlyapp]}-->data-onlyapp="1" data-apptip="{$rw_config[apptip]}" data-applink="{$rw_config[applink]}"<!--{/if}-->>
        <div class="pub_circle"></div>
        <i class="iconfont icon-fabuhei weui-tabbar__icon"></i>
        <p class="weui-tabbar__label pub_circle_p" style="color:#777!important">{lang xigua_rw:fabuqun}</p>
    </a>
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_rw&ac=my&status=1{$urlext}" class="weui-tabbar__item <!--{if strpos($ac,'my')!==false}-->weui-bar__item_on<!--{/if}-->">
        <span style="display: inline-block;position: relative;">
            <i class="iconfont icon-xiaolian2 weui-tabbar__icon"></i>
        </span>
        <p class="weui-tabbar__label">{lang xigua_hb:wode}</p>
    </a>
</div>
<!--{else}-->
<div class="weui-tabbar<!--{if $showfloatapp}--> none<!--{/if}-->">
    <!--{loop $custom_nav $loop_k $loopin}--><!--{eval
$highlight = '&high='.$loop_k;
if($loopin['adlink']=='pub'):
    $inlink = 'javascript:;" class="pubj weui-tabbar__item weui-bar__item_on showpubfont" id="pubj';
    if($rw_config[onlyapp]):
        $inlink = 'javascript:;" data-onlyapp="1" data-apptip="'.$rw_config[apptip].'" data-applink="'.$rw_config[applink].'" class="pubj" id="pubj';
    endif;
else:
    $inlink = $loopin['adlink'].$highlight;
endif;
$is_on = !$is_on && (  strpos($curturl,$inlink)!==false || strpos($curturl,$highlight)!==false  || ($_GET['high'] && $_GET['high']==$loop_k)  );
if($is_on):
    $loopin[icon] = $loopin[icon2]?$loopin[icon2]:$loopin[icon];
endif;
}-->
<!--{if $loopin[up]}-->
<a href="{$inlink}" class="weui-tabbar__item weui-bar__item_on showpubfont"><div class="pub_circle"></div>
    <!--{if $loopin[icon2]}-->
    <img src="$loopin[icon2]" class="tabcon" />
    <!--{/if}-->
    <p class="weui-tabbar__label pub_circle_p" style="color:#777!important">{$loopin[name]}</p>
</a>
<!--{else}-->
<a href="{$inlink}" class="weui-tabbar__item <!--{if $is_on}-->weui-bar__item_on<!--{/if}-->">
    <!--{if $loopin[icon]}-->
    <img src="$loopin[icon]" class="tabcon3" />
    <!--{/if}-->
    <p class="weui-tabbar__label">{$loopin[name]}</p>
</a>
<!--{/if}-->
<!--{/loop}-->
</div>
<!--{/if}-->
<!--{/if}-->