<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!is_file(DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php')) {
	exit('Please install <a href="https://dism.taobao.com/?@xigua_hb.plugin">https://dism.taobao.com/?@xigua_hb.plugin</a>');
}
if (!is_file(DISCUZ_ROOT . 'source/plugin/xigua_hb/function_callback.php')) {
	exit('Please install <a href="https://dism.taobao.com/?@xigua_hb.plugin">https://dism.taobao.com/?@xigua_hb.plugin</a>');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
if (empty($_G['cache']['plugin'])) {
	loadcache('plugin');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_rw/function.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_rw/common_status.php';
$rw_config = $_G['cache']['plugin']['xigua_rw'];
$rw_config['rzbt'] = unserialize($rw_config['rzbt']);
$rw_config['fbxm'] = unserialize($rw_config['fbxm']);
$config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $rw_config['maincolor'];
$jdmzsm = str_replace('\'', '', $rw_config['jdmzsm']);
$jdmzsm = str_replace(array("\n", "\r"), '', $jdmzsm);
$ac = $_GET['ac'];
$do = $_GET['do'];
$aclist = array('index', 'my', 'add', 'join', 'qun_li', 'view', 'misc', 'manage', 'top', 'dodig', 'getloc', 'incr', 'del', 'hangye', 'googleMap', 'refresh', 'pubadd', 'mywx', 'wx_li', 'dist_li', 'myadd', 'add_li', 'com', 'pai', 'ad_view', 'order', 'order_li');
$aclist_login = array('add', 'join', 'misc', 'my', 'del', 'dodig', 'manage', 'refresh', 'pubadd', 'mywx');
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
if (in_array($ac, $aclist_login) && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$qunid = intval($_GET['qunid']);
$orderby_list = array('' => lang_hb('om', 0), 'near' => lang_hb('near', 0), 'new' => lang_hb('zx', 0));
$orderby = $_GET['orderby'];
switch ($ac) {
	case 'index':
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist0 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist0 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['province']) {
			$distname = $_GET['province'];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if ($distname) {
			$navtitle = $distname . $navtitle;
		}
		if (!$distname) {
			$distname = lang_hb('quanbu', 0) . lang_hb('plugins_edit_vars_type_area', 0);
		}
		$cat_id = intval($_GET['cat_id']);
		$hy = C::t('#xigua_rw#xigua_rw_hangye')->fetch($cat_id);
		$navtitle = $hy['name'];
		$pid = $hy['pid'];
		$catname = $hy['name'] ? $hy['name'] : lang_hb('quanbu', 0) . lang_rw('fenlei', 0);
		$gender = $gendser2;
		$dftgender = $_GET['gender'] ? $gender[$_GET['gender']] : $gender['manwoman'];
		$renshu = $_GET['renshu'] ? $friend_nums[$_GET['renshu']] : $friend_nums['fnum0'];
		$navtitle = str_replace('{tname}', $stinfo['name'], $rw_config['title']);
		$desc = str_replace('{tname}', $stinfo['name'], $rw_config['desc']);
		$topnavslider = hb_parse_set($rw_config['topslider']);
		$indeximg = $rw_config['shareimg'];
		$_GET['nav'] = !$_GET['nav'] ? $firstmod : $_GET['nav'];
		if ($rw_config['indextype'] == 2) {
			$total_count_ad = C::t('#xigua_rw#xigua_rw_ad')->total_count();
			$total_count_wx = C::t('#xigua_rw#xigua_rw_wx')->total_count();
			$total_count_dd = C::t('#xigua_rw#xigua_rw_log')->total_count();
		}
		break;
	case 'myadd':
		$navtitle = lang_rw('glwxq', 0);
		if (!$_GET['status']) {
			$_GET['status'] = 1;
		}
		$custom_side = array($SCRITPTNAME . '?id=xigua_rw&ac=my' . $urlext, lang_rw('wd', 0));
		break;
	case 'add_li':
		$bgc = rw_hex2rgb($config['maincolor'], 0);
		$where = array();
		if (!$_GET['is_my']) {
			$where[] = 'wxid=0';
		}
		if ($_GET['status']) {
			$where[] = 'status=' . intval($_GET['status']);
		} else {
			$where[] = 'status=1';
		}
		if ($_GET['is_my']) {
			$where[] = 'uid=' . $_G['uid'];
		}
		if ($_GET['cat_id']) {
			$cat_id = intval($_GET['cat_id']);
			$pids = array($cat_id);
			$catinfo = C::t('#xigua_rw#xigua_rw_hangye')->get_childs_by_pids($cat_id);
			if ($catinfo) {
				foreach ($catinfo as $index => $item) {
					$pids[] = intval($item['id']);
				}
				if ($pids) {
					$tmpw = array();
					foreach ($pids as $index => $pid) {
						$tmpw[] = 'FIND_IN_SET(' . $pid . ', jineng)';
					}
					$where[] = '(' . implode(' OR ', $tmpw) . ')';
				}
			} else {
				$where[] = 'FIND_IN_SET(' . $cat_id . ', jineng)';
			}
		}
		if ($_GET['province']) {
			$prov = stripsearchkey(daddslashes($_GET['province']));
			$where[] = ' (area_keys LIKE \'%' . $prov . '%\') ';
		}
		if ($_GET['city'] && $_GET['city'] != 0 - 1) {
			$city = stripsearchkey(daddslashes($_GET['city']));
			$where[] = ' (area_keys LIKE \'%' . $city . '%\') ';
		}
		if ($_GET['dist']) {
			$dst = stripsearchkey(daddslashes($_GET['dist']));
			$where[] = ' (area_keys LIKE \'%' . $dst . '%\') ';
		}
		if ($_GET['renshu'] && $_GET['renshu'] != 'fnum0') {
			$where[] = 'friend_num = \'' . daddslashes($friend_nums[$_GET['renshu']]) . '\'';
		}
		if ($_GET['gender'] && $_GET['gender'] != 'manwoman') {
			$where[] = 'gender = \'' . daddslashes($gendser2[$_GET['gender']]) . '\'';
		}
		$list = C::t('#xigua_rw#xigua_rw_ad')->fetch_all_by_where($where, $start_limit, $lpp, $order_by);
		include template('xigua_hb:header_ajax');
		include template('xigua_rw:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'mywx':
		$navtitle = lang_rw('wxgl', 0);
		if (!$_GET['status']) {
			$_GET['status'] = 1;
		}
		$custom_side = array($SCRITPTNAME . '?id=xigua_rw&ac=my' . $urlext, lang_rw('wd', 0));
		break;
	case 'wx_li':
		$where = array();
		if ($_GET['status']) {
			$where[] = 'status=' . intval($_GET['status']);
		}
		if ($_GET['is_my']) {
			$where[] = 'uid=' . $_G['uid'];
		} else {
			$where[] = 'status=1';
		}
		if ($_GET['cat_id']) {
			$cat_id = intval($_GET['cat_id']);
			$pids = array($cat_id);
			$catinfo = C::t('#xigua_rw#xigua_rw_hangye')->get_childs_by_pids($cat_id);
			if ($catinfo) {
				foreach ($catinfo as $index => $item) {
					$pids[] = intval($item['id']);
				}
				if ($pids) {
					$tmpw = array();
					foreach ($pids as $index => $pid) {
						$tmpw[] = 'FIND_IN_SET(' . $pid . ', jineng)';
					}
					$where[] = '(' . implode(' OR ', $tmpw) . ')';
				}
			} else {
				$where[] = 'FIND_IN_SET(' . $cat_id . ', jineng)';
			}
		}
		if ($_GET['province']) {
			$prov = stripsearchkey(daddslashes($_GET['province']));
			$where[] = ' (area_keys LIKE \'%' . $prov . '%\') ';
		}
		if ($_GET['city'] && $_GET['city'] != 0 - 1) {
			$city = stripsearchkey(daddslashes($_GET['city']));
			$where[] = ' (area_keys LIKE \'%' . $city . '%\') ';
		}
		if ($_GET['dist']) {
			$dst = stripsearchkey(daddslashes($_GET['dist']));
			$where[] = ' (area_keys LIKE \'%' . $dst . '%\') ';
		}
		if ($_GET['renshu'] && $_GET['renshu'] != 'fnum0') {
			$where[] = 'friend_num = \'' . daddslashes($friend_nums[$_GET['renshu']]) . '\'';
		}
		if ($_GET['gender'] && $_GET['gender'] != 'manwoman') {
			$where[] = 'gender = \'' . daddslashes($gendser2[$_GET['gender']]) . '\'';
		}
		$list = C::t('#xigua_rw#xigua_rw_wx')->fetch_all_by_where($where, $start_limit, $lpp, $order_by);
		include template('xigua_hb:header_ajax');
		include template('xigua_rw:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'dist_li':
		$rlist = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($_GET['ctid']);
		include template('xigua_hb:header_ajax');
		include template('xigua_rw:dist_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'order':
		if ($_GET['manage']) {
			$navtitle = lang_rw('rwgl', 0);
			$tjtp = '';
		} else {
			$navtitle = lang_rw('wdrw', 0);
			$tjtp = lang_rw('tjtp', 0);
		}
		$custom_side = array($SCRITPTNAME . '?id=xigua_rw&ac=my', lang_hb('wode', 0));
		$config['closecj'] = 1;
		break;
	case 'order_li':
		$where = array();
		if ($_GET['manage']) {
			$where[] = 'aduid=' . $_G['uid'];
		} else {
			$where[] = 'wxuid=' . $_G['uid'];
		}
		if ($_GET['status']) {
			$where[] = 'status=' . intval($_GET['status']);
		}
		$list = C::t('#xigua_rw#xigua_rw_log')->fetch_all_by_where($where, $start_limit, $lpp);
		include template('xigua_hb:header_ajax');
		include template('xigua_rw:order_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'ad_view':
		$navtitle = $rw_config['ggtitle'] ? $rw_config['ggtitle'] : lang_rw('adinfo', 0);
		$adid = intval($_GET['adid']);
		$bgc = rw_hex2rgb($config['maincolor'], 0);
		$v = C::t('#xigua_rw#xigua_rw_ad')->fetch_by_id($adid);
		$jieshao_txt = str_replace('"', '', $v['jieshao']);
		$desc = strip_tags($jieshao_txt);
		$haswx = 0;
		if ($_G['uid'] && ($haswxnum = C::t('#xigua_rw#xigua_rw_wx')->fetch_count_by_page(array('uid=' . $_G['uid'] . ' AND status=1')))) {
			$haswx = $haswxnum;
		}
		if ($haswx) {
			$allme = C::t('#xigua_rw#xigua_rw_wx')->fetchs_by_uid($_G['uid']);
		}
		$wxid = 0;
		if (count($allme) == 1) {
			$wxid = $allme[0]['wxid'];
		}
		$custom_side = array($SCRITPTNAME . '?id=xigua_rw&ac=my' . $urlext, lang_hb('wode', 0));
		$aduser = getuserbyuid($v['uid'], 1);
		$navtitle = str_replace(array('{msg}', '{username}', '{price}', '{gender}', '{area}', '{friends}', '{complete}'), array(strip_tags($v['jieshao']), $aduser['username'], $v['rent_price'], $v['gender'], $v['areawant_str'], $v['friend_num'], $v['complete'] . '/' . $v['danshu']), $navtitle);
		break;
	case 'pai':
		$midnavslider = hb_parse_set($rw_config['midslider']);
		$list_all = C::t('#xigua_rw#xigua_rw_hangye')->list_all();
		C::t('#xigua_rw#xigua_rw_hangye')->init($list_all);
		$cat_tree_init = $cat_tree = C::t('#xigua_rw#xigua_rw_hangye')->get_tree_array(0);
		$cat_tree = array_values($cat_tree);
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist0 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist0 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['province']) {
			$distname = $_GET['province'];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if ($distname) {
			$navtitle = $distname . $navtitle;
		}
		if (!$distname) {
			$distname = lang_hb('quanbu', 0) . lang_hb('plugins_edit_vars_type_area', 0);
		}
		$cat_id = intval($_GET['cat_id']);
		$hy = C::t('#xigua_rw#xigua_rw_hangye')->fetch($cat_id);
		$navtitle = $hy['name'];
		$pid = $hy['pid'];
		$catname = $hy['name'] ? $hy['name'] : lang_hb('quanbu', 0) . lang_rw('fenlei', 0);
		$gender = $gendser2;
		$dftgender = $_GET['gender'] ? $gender[$_GET['gender']] : $gender['manwoman'];
		$renshu = $_GET['renshu'] ? $friend_nums[$_GET['renshu']] : $friend_nums['fnum0'];
		$navtitle = str_replace('{tname}', $stinfo['name'], $rw_config['paititle']);
		$desc = str_replace('{tname}', $stinfo['name'], $rw_config['paidesc']);
		if ($rw_config['paitype'] == 2) {
			$total_count_ad = C::t('#xigua_rw#xigua_rw_ad')->total_count();
			$total_count_wx = C::t('#xigua_rw#xigua_rw_wx')->total_count();
			$total_count_dd = C::t('#xigua_rw#xigua_rw_log')->total_count();
		}
		$cat_list = C::t('#xigua_rw#xigua_rw_hangye')->list_by_pid(0, true);
		$jing_list = array_values($cat_list);
		break;
	case 'my':
		$navtitle = lang_rw('wd', 0);
		$qianbao = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
		$dxp = $config['smsAppKey'] && $config['smssecretKey'] && $config['smsFreeSignName'] && $config['smsTemplateCode'] || $config['smsusername'] && $config['smsusername'] && $config['sendtype'] && $config['smstongtpl'];
		$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
		$muhumobile = $qianbao['mobile'] ? substr($qianbao['mobile'], 0, 3) . '******' . substr($qianbao['mobile'], 0 - 2) : '';
		$myzlurl = $SCRITPTNAME . '?id=xigua_hb&ac=myzl&hide_side=1&referer=' . urlencode(hb_currenturl()) . $urlext;
		$mylogcount = C::t('#xigua_rw#xigua_rw_log')->fetch_count_by_page(array('wxuid=' . $_G['uid']));
		$mywxcount = C::t('#xigua_rw#xigua_rw_wx')->fetch_count_by_page(array('uid=' . $_G['uid']));
		$myaddcount = C::t('#xigua_rw#xigua_rw_ad')->fetch_count_by_page(array('uid=' . $_G['uid']));
		$myaddmcount = C::t('#xigua_rw#xigua_rw_log')->fetch_count_by_page(array('aduid=' . $_G['uid']));
		break;
	case 'add':
		global $_G;
		global $rw_config;
		$_key = 'hbpubIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
			$distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			$distjsary = array_values($distjsary);
			savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
		} else {
			$distjsary = $_G['cache'][$_key]['variable'][0];
		}
		$defaultcty = diconv($distjsary[0]['name'] . ' ' . $distjsary[0]['sub'][0]['name'] . ' ' . $distjsary[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
		$cityjson = json_encode($distjsary);
		if (submitcheck('formhash')) {
			$hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			if ($hbuser['pingbi']) {
				hb_message(lang_hb('ybpb', 0), 'error');
			}
			$form = $_GET['form'];
			if ($form['areawant']) {
				$eqdq = $form['areawant'];
				$areawant_str = $areawant_str_tmp = array();
				$GLOBALS['nojson'] = 1;
				$distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
				foreach ($distlist as $index => $item) {
					if (in_array($item['code'], $eqdq)) {
						$areawant_str_tmp[$item['code']] = $item['name'];
					}
				}
				foreach ($form['areawant'] as $index => $item) {
					$areawant_str[$item] = $areawant_str_tmp[$item];
				}
				$form['areawant'] = implode(',', $form['areawant']);
				$form['areawant_str'] = implode(',', $areawant_str);
				C::t('#xigua_hb#xigua_hb_district')->init($distlist);
				$distlist_key = array();
				foreach ($distlist as $index => $item) {
					$distlist_key[$item['code']] = $item;
				}
				$tmp_ = array();
				foreach ($eqdq as $index => $item) {
					$_parent = $distlist_key[$distlist_key[$item]['upid']];
					if ($_parent['upid'] > 0) {
						$__parent = $distlist_key[$_parent['upid']];
					}
					$tmp_[] = $__parent['name'] . ' ' . $_parent['name'] . ' ' . $distlist_key[$item]['name'];
				}
				$form['area_keys'] = implode(',', $tmp_);
			}
			if ($form['city'] && !$form['areawant']) {
				$new_dist_ary = array_filter(array($form['province'], $form['city'], $form['district'], $form['street'], $form['street_number']));
				if (!$distlist) {
					$GLOBALS['nojson'] = 1;
					$distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
				}
				$areawant_str = $areawant_str_tmp = array();
				foreach ($distlist as $index => $item) {
					if (in_array($item['name'], $new_dist_ary)) {
						$areawant_str_tmp[$item['name']] = $item['code'];
					}
				}
				$form['areawant'] = implode(',', $areawant_str_tmp);
				$form['areawant_str'] = implode(',', $new_dist_ary);
				$form['area_keys'] = implode(' ', $new_dist_ary);
			}
			$data = array('stid' => $form['stid'], 'idu' => $form['idu'], 'jieshao' => $form['jieshao'], 'areawant' => $form['areawant'], 'areawant_str' => $form['areawant_str'], 'area_keys' => $form['area_keys'], 'friend_num' => $form['friend_num'], 'gender' => $form['gender'], 'note' => $form['note'], 'addr' => $form['addr'], 'lat' => $form['lat'], 'lng' => $form['lng'], 'province' => $form['province'], 'city' => $form['city'], 'district' => $form['district'], 'street' => $form['street'], 'street_number' => $form['street_number']);
			if (!$_GET['old_id']) {
				$data['rent_price'] = $form['rent_price'];
				$data['danshu'] = $form['danshu'];
				$requires = array('areawant', 'friend_num', 'gender', 'rent_price', 'danshu');
			} else {
				$requires = array('areawant', 'friend_num', 'gender');
			}
			if (!$data['jieshao']) {
				hb_message(lang_rw('qtxpyqnr', 0), 'error');
			}
			$_tmpmsg = censor($data['jieshao'], NULL, true);
			if (is_array($_tmpmsg) && $_tmpmsg['message']) {
				hb_message($_tmpmsg['message'], 'error');
			}
			if ($data['note']) {
				$_tmpmsg = censor($data['note'], NULL, true);
				if (is_array($_tmpmsg) && $_tmpmsg['message']) {
					hb_message($_tmpmsg['message'], 'error');
				}
			}
			$form['album'] = array_filter($form['album']);
			if (!$form['album']) {
				hb_message(lang_rw('qtxalbum', 0), 'error');
			}
			$data['album'] = implode(',', $form['album']);
			$data['yangban'] = $form['yangban'][0] ? $form['yangban'][0] : $form['yangban'];
			if (is_array($data['yangban'])) {
				$data['yangban'] = array_values($data['yangban']);
				$data['yangban'] = $data['yangban'][0];
			}
			if (!$data['yangban'] || is_array($data['yangban'])) {
			}
			if ($form['wxids']) {
				$wxids = $form['wxids'];
				$list = C::t('#xigua_rw#xigua_rw_wx')->fetch_by_ids($wxids);
				$totalprice = 0;
				foreach ($list as $index => $item) {
					$totalprice += $item['rent_price'];
				}
				$newids = array();
				foreach ($list as $index => $item) {
					$data['areawant'] = $item['areawant'];
					$data['areawant_str'] = $item['areawant_str'];
					$data['friend_num'] = $item['friend_num'];
					$data['gender'] = $item['gender'];
					$data['rent_price'] = $item['rent_price'];
					$data['danshu'] = 1;
					$data['danshu'] = 1;
					$data['wxid'] = $item['wxid'];
					$data['crts'] = TIMESTAMP;
					$data['upts'] = TIMESTAMP;
					$data['status'] = $item['rent_price'] > 0 ? 0 - 2 : 0 - 1;
					$data['uid'] = $_G['uid'];
					$newids[] = C::t('#xigua_rw#xigua_rw_ad')->insert($data, 1);
				}
				if ($totalprice > 0 && $newids) {
					$title = 'ID:' . implode(',', $newids) . '-' . lang_rw('dotpub', 0) . '-' . cutstr(strip_tags($data['jieshao']), 20);
					$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_rw&ac=order&manage=1' . $urlext);
					$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_rw_pub', array('data' => array('newids' => $newids, 'newdata' => $data, 'wxids' => $wxids), 'callback' => array('file' => 'source/plugin/xigua_rw/function.php', 'method' => 'rw_multis_pay_callback'), 'location' => $rtl, 'referer' => $rtl));
					$rl = urlencode($rtl);
					$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
					hb_message(lang_rw('jumppay', 0), 'loading', $jumpurl);
				}
			} else {
				foreach ($requires as $index => $item) {
					if (!$data[$item]) {
						$fix = 'qxz';
						if ($item == 'friend_num') {
							$item = 'friend_num1';
						}
						if ($item == 'rent_price') {
							$item = 'rent_price1';
						}
						if ($item == 'danshu') {
							$fix = 'qtx';
						}
						hb_message(lang_rw($fix, 0) . lang_rw($item, 0), 'error');
					}
				}
				$data['upts'] = TIMESTAMP;
				if ($_GET['old_id']) {
					if ($rw_config['adshen']) {
						$data['status'] = 0 - 1;
					}
					C::t('#xigua_rw#xigua_rw_ad')->update_G($_GET['old_id'], $data);
					if ($data['status'] == 0 - 1) {
						rw_ad_noti($data);
						hb_message(lang_rw('save_succeed_shen', 0), 'success', $SCRITPTNAME . '?id=xigua_rw&ac=myadd&status=-1&mobile=2' . $urlext);
					} else {
						hb_message(lang_rw('save_succeed', 0), 'success', $SCRITPTNAME . '?id=xigua_rw&ac=myadd&status=1&mobile=2' . $urlext);
					}
				}
				$totalprice = $data['danshu'] * $data['rent_price'];
				$data['crts'] = TIMESTAMP;
				$data['status'] = $totalprice > 0 ? 0 - 2 : 0 - 1;
				$data['uid'] = $_G['uid'];
				if ($rw_config['adshen']) {
					$data['status'] = 0 - 1;
				}
				$newid = C::t('#xigua_rw#xigua_rw_ad')->insert($data, 1);
				$fdsxf = 0;
				if ($rw_config['fdfei']) {
					$fdsxf = round($totalprice * $rw_config['fdfei'] / 100, 2);
				}
				$totalprice += $fdsxf;
				if ($totalprice > 0) {
					$title = 'ID:' . $newid . '-' . lang_rw('dotpub', 0) . '-' . cutstr(strip_tags($data['jieshao']), 20);
					$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_rw&ac=myadd' . $urlext);
					$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_rw_pub', array('data' => array('newid' => $newid, 'newdata' => $data), 'callback' => array('file' => 'source/plugin/xigua_rw/function.php', 'method' => 'rw_multi_pay_callback'), 'location' => $rtl, 'referer' => $rtl));
					$rl = urlencode($rtl);
					$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
					hb_message(lang_rw('jumppay', 0), 'loading', $jumpurl);
				} else {
					if ($data['status'] == 0 - 1) {
						rw_ad_noti($data);
						hb_message(lang_rw('fbcgsc', 0), 'success', $SCRITPTNAME . '?id=xigua_rw&ac=myadd&status=-1&mobile=2' . $urlext);
					} else {
						hb_message(lang_rw('fbcg1', 0), 'success', $SCRITPTNAME . '?id=xigua_rw&ac=myadd&mobile=2' . $urlext);
					}
				}
			}
		} else {
			$navtitle = lang_rw('pubadd', 0);
			if ($_GET['old_id']) {
				$navtitle = lang_rw('gggl', 0);
			}
			$bgc = rw_hex2rgb($config['maincolor'], 0);
			$mynew = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			$lastrealname = $mynew['realname'];
			$lastmobile = $mynew['mobile'];
			$list_all2 = C::t('#xigua_rw#xigua_rw_hangye')->list_all();
			C::t('#xigua_rw#xigua_rw_hangye')->init($list_all2);
			$jsary = C::t('#xigua_rw#xigua_rw_hangye')->get_tree_array(0);
			if ($_GET['old_id']) {
				$old_data = C::t('#xigua_rw#xigua_rw_ad')->fetch_G($_GET['old_id']);
			}
			$dftprice = 0;
			if ($_GET['wxid']) {
				$wxids = array_filter(explode('_', $_GET['wxid']));
				$list = C::t('#xigua_rw#xigua_rw_wx')->fetch_by_ids($wxids);
				$wxcount = count($wxids);
			}
		}
		break;
	case 'join':
		global $_G;
		global $rw_config;
		$_key = 'hbpubIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
			$distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			$distjsary = array_values($distjsary);
			savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
		} else {
			$distjsary = $_G['cache'][$_key]['variable'][0];
		}
		$defaultcty = diconv($distjsary[0]['name'] . ' ' . $distjsary[0]['sub'][0]['name'] . ' ' . $distjsary[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
		$cityjson = json_encode($distjsary);
		if (submitcheck('formhash')) {
			$hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			if ($hbuser['pingbi']) {
				hb_message(lang_hb('ybpb', 0), 'error');
			}
			$form = $_GET['form'];
			if ($form['areawant']) {
				$eqdq = $form['areawant'];
				$areawant_str = $areawant_str_tmp = array();
				$GLOBALS['nojson'] = 1;
				$distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
				foreach ($distlist as $index => $item) {
					if (in_array($item['code'], $eqdq)) {
						$areawant_str_tmp[$item['code']] = $item['name'];
					}
				}
				foreach ($form['areawant'] as $index => $item) {
					$areawant_str[$item] = $areawant_str_tmp[$item];
				}
				$form['areawant'] = implode(',', $form['areawant']);
				$form['areawant_str'] = implode(',', $areawant_str);
				C::t('#xigua_hb#xigua_hb_district')->init($distlist);
				$distlist_key = array();
				foreach ($distlist as $index => $item) {
					$distlist_key[$item['code']] = $item;
				}
				$tmp_ = array();
				foreach ($eqdq as $index => $item) {
					$_parent = $distlist_key[$distlist_key[$item]['upid']];
					if ($_parent['upid'] > 0) {
						$__parent = $distlist_key[$_parent['upid']];
					}
					$tmp_[] = $__parent['name'] . ' ' . $_parent['name'] . ' ' . $distlist_key[$item]['name'];
				}
				$form['area_keys'] = implode(',', $tmp_);
			}
			if ($form['city'] && !$form['areawant']) {
				$new_dist_ary = array_filter(array($form['province'], $form['city'], $form['district'], $form['street'], $form['street_number']));
				if (!$distlist) {
					$GLOBALS['nojson'] = 1;
					$distlist = C::t('#xigua_hb#xigua_hb_district')->list_all();
				}
				$areawant_str = $areawant_str_tmp = array();
				foreach ($distlist as $index => $item) {
					if (in_array($item['name'], $new_dist_ary)) {
						$areawant_str_tmp[$item['name']] = $item['code'];
					}
				}
				$form['areawant'] = implode(',', $areawant_str_tmp);
				$form['areawant_str'] = implode(',', $new_dist_ary);
				$form['area_keys'] = implode(' ', $new_dist_ary);
			}
			$data = array('stid' => $form['stid'], 'idu' => $form['idu'], 'guidetype' => $form['guidetype'], 'areawant' => $form['areawant'], 'areawant_str' => $form['areawant_str'], 'area_keys' => $form['area_keys'], 'friend_num' => $form['friend_num'], 'rent_price' => $form['rent_price'], 'gender' => $form['gender'], 'ages' => $form['ages'], 'realname' => $form['realname'], 'mobile' => $form['mobile'], 'weixin' => $form['weixin'], 'ptfans' => $form['ptfans'], 'pttag' => $form['pttag'], 'pttype' => $form['pttype'], 'addr' => $form['addr'], 'lat' => $form['lat'], 'lng' => $form['lng'], 'province' => $form['province'], 'city' => $form['city'], 'district' => $form['district'], 'street' => $form['street'], 'street_number' => $form['street_number']);
			$data['wxqrcode'] = $form['wxqrcode'][0] ? $form['wxqrcode'][0] : $form['wxqrcode'];
			$data['haoyoupic'] = $form['haoyoupic'][0] ? $form['haoyoupic'][0] : $form['haoyoupic'];
			if (is_array($data['wxqrcode'])) {
				$data['wxqrcode'] = array_values($data['wxqrcode']);
				$data['wxqrcode'] = $data['wxqrcode'][0];
			}
			if (is_array($data['haoyoupic'])) {
				$data['haoyoupic'] = array_values($data['haoyoupic']);
				$data['haoyoupic'] = $data['haoyoupic'][0];
			}
			if (!$data['wxqrcode'] && in_array(2, $rw_config['rzbt'])) {
				hb_message(lang_rw('qtxwxqrcode', 0), 'error');
			}
			if (in_array(3, $rw_config['rzbt'])) {
				if (!$data['haoyoupic'] || is_array($data['haoyoupic'])) {
					hb_message(lang_rw('qtxhaoyoupic', 0), 'error');
				}
			}
			$checkdata = array();
			if (in_array(4, $rw_config['rzbt'])) {
				$checkdata[] = 'guidetype';
			}
			$checkdata[] = 'areawant';
			$checkdata[] = 'friend_num';
			$checkdata[] = 'rent_price';
			$checkdata[] = 'realname';
			foreach ($checkdata as $index => $item) {
				if (!$data[$item]) {
					hb_message(lang_rw('qxz', 0) . lang_rw($item, 0), 'error');
				}
			}
			if (!$form['weixin'] && !$form['mobile']) {
				hb_message(lang_rw('qtx', 0) . lang_rw('mobile', 0) . lang_rw('huo', 0) . lang_rw('weixin', 0), 'error');
			}
			if ($form['jineng']) {
				$listjson = C::t('#xigua_rw#xigua_rw_hangye')->list_json();
				foreach ($listjson as $index => $item) {
					if (in_array($item['code'], $form['jineng'])) {
						$jineng_string_tmp[$item['code']] = $item['oname'];
					}
				}
				foreach ($form['jineng'] as $index => $item) {
					$jineng_string[$item] = $jineng_string_tmp[$item];
				}
				$data['jineng_str'] = implode(',', $jineng_string);
				$data['jineng'] = implode(',', $form['jineng']);
			} else {
				if (in_array(7, $rw_config['rzbt'])) {
					hb_message(lang_rw('min1jineng', 0), 'error');
				}
			}
			$manage = IS_ADMINID && $_GET['manage'];
			$data['upts'] = TIMESTAMP;
			if ($old_data = C::t('#xigua_rw#xigua_rw_wx')->fetch_by_id($form['old_id'])) {
				if (!$manage) {
					if ($rw_config['mfshen']) {
						$data['status'] = 0 - 1;
					}
				}
				C::t('#xigua_rw#xigua_rw_wx')->update_G($old_data['wxid'], $data);
				if ($data['status'] == 0 - 1) {
					rw_to_noti($data, 0);
					hb_message(lang_rw('bccgsc', 0), 'success', $SCRITPTNAME . '?id=xigua_rw&ac=mywx&status=-1&mobile=2' . $urlext . ($manage ? '&manage=1' : ''));
				} else {
					hb_message(lang_rw('bccg', 0), 'success', $SCRITPTNAME . '?id=xigua_rw&ac=mywx&mobile=2' . $urlext . ($manage ? '&manage=1' : ''));
				}
			} else {
				$data['uid'] = $_G['uid'];
				$data['crts'] = TIMESTAMP;
				if (IS_ADMINID) {
					$rw_config['mfshen'] = 0;
				}
				if ($rw_config['mfshen']) {
					$data['status'] = 0 - 1;
				} else {
					$data['status'] = 1;
				}
				$newid = C::t('#xigua_rw#xigua_rw_wx')->insert($data, 1);
				if ($data['status'] == 0 - 1) {
					rw_to_noti($data, 1);
					hb_message(lang_rw('fbcgsc', 0), 'success', $SCRITPTNAME . '?id=xigua_rw&ac=mywx&status=-1&mobile=2' . $urlext);
				} else {
					hb_message(lang_rw('fbcg', 0), 'success', $SCRITPTNAME . '?id=xigua_rw&ac=mywx&mobile=2' . $urlext);
				}
			}
			hb_message(lang_rw('fbcg', 0), 'success', $SCRITPTNAME . '?id=xigua_rw&ac=mywx&mobile=2' . $urlext);
		} else {
			$navtitle = lang_rw('wxhrz', 0);
			if ($_GET['old_id']) {
				$navtitle = lang_rw('wxhxg', 0);
			}
			$bgc = rw_hex2rgb($config['maincolor'], 0);
			$mynew = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			$lastrealname = $mynew['realname'];
			$lastmobile = $mynew['mobile'];
			$list_all2 = C::t('#xigua_rw#xigua_rw_hangye')->list_all();
			C::t('#xigua_rw#xigua_rw_hangye')->init($list_all2);
			$jsary = C::t('#xigua_rw#xigua_rw_hangye')->get_tree_array(0);
			if ($_GET['old_id']) {
				$old_data = C::t('#xigua_rw#xigua_rw_wx')->fetch_G($_GET['old_id']);
			}
		}
		break;
	default:
		if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_rw/include/c_' . $ac . '.php'))) {
			include DISCUZ_ROOT . ('source/plugin/xigua_rw/include/c_' . $ac . '.php');
		}
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_rw/template/touch/' . $ac . '.php'))) {
	include template('xigua_rw:touch/' . $ac);
}