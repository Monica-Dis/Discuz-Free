<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$rw_config = $_G['cache']['plugin']['xigua_rw'];

$zujin = array_filter(explode(',', $rw_config['zujin']));
if(!$zujin){
    $rent_prices = array(0.1,0.5,1,2,5,10,15,20,30,40,50,100);
}else{
    $rent_prices = $zujin;
}

$guidetype = array(
    'g_r' => lang('plugin/xigua_rw', 'g_r'),
    'p_t' => lang('plugin/xigua_rw', 'p_t'),
);
$gendser = array(
    'manwoman' => lang('plugin/xigua_rw', 'manwoman'),
    'woman' => lang('plugin/xigua_rw', 'woman'),
    'man' => lang('plugin/xigua_rw', 'man'),
);
$gendser2 = array(
    'manwoman' => lang('plugin/xigua_rw', 'manwoman'),
    'woman' => lang('plugin/xigua_rw', 'woman'),
    'man' => lang('plugin/xigua_rw', 'man'),
);
$ages = array();
$cages = array_filter(explode("\n", $rw_config['ages']));
foreach ($cages as $index => $cage) {
    $cage = trim($cage);
    if($cage){
        $key = $index+1;
        $key = 'age'.$key;
        $ages[$key] = $cage;
    }
}

$friend_nums = array();
$cfriend_nums = array_filter(explode("\n", $rw_config['haoyoushu']));
foreach ($cfriend_nums as $index => $cfriend_num) {
    $cfriend_num = trim($cfriend_num);
    if($cfriend_num){
        $key = $index;
        $key = 'fnum'.$key;
        $friend_nums[$key] = $cfriend_num;
    }
}
$statuss = array(
    1 => lang('plugin/xigua_rw', 'status1'),
    -1 => lang('plugin/xigua_rw', 'status-1'),
    -2 => lang('plugin/xigua_rw', 'status-2'),
);
$wxstatuss = array(
    1 => lang('plugin/xigua_rw', 'status1'),
    -1 => lang('plugin/xigua_rw', 'status-1'),
    -3 => lang('plugin/xigua_rw', 'status-3'),
    -2 => lang('plugin/xigua_rw', 'status-2'),
);
$log_status = array(
    '1' => lang('plugin/xigua_rw', 'log_status1'),
    '2' => lang('plugin/xigua_rw', 'log_status2'),
    '3' => lang('plugin/xigua_rw', 'log_status3'),
    '4' => lang('plugin/xigua_rw', 'log_status4'),
    '5' => lang('plugin/xigua_rw', 'log_status5'),
);
$log_status2 = array(
    '0' => lang('plugin/xigua_rw', 'log_status20'),
    '1' => lang('plugin/xigua_rw', 'log_status21'),
    '2' => lang('plugin/xigua_rw', 'log_status22'),
    '3' => lang('plugin/xigua_rw', 'log_status23'),
    '4' => lang('plugin/xigua_rw', 'log_status24'),
    '5' => lang('plugin/xigua_rw', 'log_status25'),
);
$dantype = array(
    'zhudong' => lang('plugin/xigua_rw', 'zhudong'),
    'beidong' => lang('plugin/xigua_rw', 'beidong'),
);
$pttype = array();
$pttype_tmp = array_filter(explode("\n", $rw_config['pttype']));
foreach ($pttype_tmp as $index => $cage) {
    $cage = trim($cage);
    if($cage){
        $key = $index+1;
        $key = 'pttype_'.$key;
        $pttype[$key] = $cage;
    }
}
$pttag = array();
$pttag_tmp = array_filter(explode("\n", $rw_config['pttag']));
foreach ($pttag_tmp as $index => $cage) {
    $cage = trim($cage);
    if($cage){
        $key = $index+1;
        $key = 'pttag_'.$key;
        $pttag[$key] = $cage;
    }
}
$ptfans= array();
$ptfans_tmp = array_filter(explode("\n", $rw_config['ptfans']));
foreach ($ptfans_tmp as $index => $cage) {
    $cage = trim($cage);
    if($cage){
        $key = $index+1;
        $key = 'ptfans_'.$key;
        $ptfans[$key] = $cage;
    }
}