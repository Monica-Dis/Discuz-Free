<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_rw_ad` (
 `adid` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `tuijian` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '-1:start 1:normal  -2:notpay',
 `jineng` varchar(200) NOT NULL,
 `jineng_str` varchar(800) NOT NULL,
 `friend_num` varchar(200) NOT NULL,
 `rent_price` decimal(10,2) NOT NULL,
 `gender` varchar(100) NOT NULL,
 `jieshao` varchar(2000) NOT NULL,
 `realname` varchar(100) NOT NULL,
 `mobile` varchar(100) NOT NULL,
 `danshu` int(11) NOT NULL,
 `complete` int(11) NOT NULL,
 `areawant` varchar(200) NOT NULL,
 `areawant_str` varchar(2000) NOT NULL,
 `album` varchar(2000) NOT NULL,
 `yangban` varchar(200) NOT NULL,
 `lat` varchar(20) NOT NULL,
 `lng` varchar(20) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `dig_startts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `payts` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 `shname` varchar(200) NOT NULL,
 `idu` int(11) NOT NULL,
 `guidetype` varchar(80) NOT NULL,
 `wxid` int(11) NOT NULL,
 PRIMARY KEY (`adid`),
 KEY `status` (`status`),
 KEY `views` (`views`),
 KEY `uid` (`uid`),
 KEY `tuijian` (`tuijian`),
 KEY `danshu` (`danshu`),
 KEY `complete` (`complete`),
 KEY `wxid` (`wxid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_rw_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `share_title` varchar(200) NOT NULL,
 `share_desc` varchar(200) NOT NULL,
 `share_pic` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_rw_log` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `adid` int(11) NOT NULL,
 `aduid` int(11) NOT NULL,
 `adinfo` text NOT NULL,
 `wxid` int(11) NOT NULL,
 `wxuid` int(11) NOT NULL,
 `status` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `type` varchar(20) NOT NULL,
 `chujia` decimal(10,2) NOT NULL,
 `payts` int(11) NOT NULL,
 `confirmts` int(11) NOT NULL,
 `beizhu` varchar(1000) NOT NULL,
 `logsn` varchar(16) NOT NULL,
 `pz1` varchar(200) NOT NULL,
 `pz2` varchar(200) NOT NULL,
 `pz1_crts` int(11) NOT NULL,
 `pz2_crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `stid` (`stid`),
 KEY `adid` (`adid`),
 KEY `wxid` (`wxid`),
 KEY `chujia` (`chujia`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_rw_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_rw_wx` (
 `wxid` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `tuijian` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '-1:start 1:normal  -2:notpay',
 `guidetype` varchar(80) NOT NULL,
 `jineng` varchar(200) NOT NULL,
 `wxqrcode` varchar(200) NOT NULL,
 `jineng_str` varchar(800) NOT NULL,
 `haoyoupic` varchar(200) NOT NULL,
 `friend_num` varchar(200) NOT NULL,
 `rent_price` decimal(10,2) NOT NULL,
 `gender` varchar(100) NOT NULL,
 `ages` varchar(100) NOT NULL,
 `realname` varchar(100) NOT NULL,
 `mobile` varchar(100) NOT NULL,
 `weixin` varchar(100) NOT NULL,
 `areawant` varchar(200) NOT NULL,
 `areawant_str` varchar(2000) NOT NULL,
 `lat` varchar(20) NOT NULL,
 `lng` varchar(20) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `dig_startts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `payts` int(11) NOT NULL,
 `zans` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 `shname` varchar(200) NOT NULL,
 `idu` int(11) NOT NULL,
 PRIMARY KEY (`wxid`),
 KEY `status` (`status`),
 KEY `views` (`views`),
 KEY `uid` (`uid`),
 KEY `tuijian` (`tuijian`)
) ENGINE=InnoDB;
SQL;
runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/xigua_rw/discuz_plugin_xigua_rw.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_rw/discuz_plugin_xigua_rw_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_rw/discuz_plugin_xigua_rw_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_rw/discuz_plugin_xigua_rw_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_rw/discuz_plugin_xigua_rw_TC_UTF8.xml');

$finish = TRUE;


$r3 = DB::fetch_first('SELECT * FROM %t  WHERE 1 LIMIT 1', array('xigua_rw_nav'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_rw_nav` (`id`, `pid`, `name`, `icon`, `icon2`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `aprice`, `iconname`, `up`, `highlight`, `type`) VALUES
(1, 0, '$installlang[jiedan]', 'source/plugin/xigua_rw/static/img/n1.png', 'source/plugin/xigua_rw/static/img/o1.png', '', 'plugin.php?id=xigua_rw&amp;ac=index', 1590650458, 1, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(2, 0, '$installlang[wode]', 'source/plugin/xigua_rw/static/img/n2.png', 'source/plugin/xigua_rw/static/img/o2.png', '', 'plugin.php?id=xigua_rw&amp;ac=my', 1590650458, 3, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(3, 0, '$installlang[paidan]', 'source/plugin/xigua_rw/static/img/n3.png', 'source/plugin/xigua_rw/static/img/o3.png', '', 'plugin.php?id=xigua_rw&amp;ac=pai', 1590650458, 2, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', '');
SQL;
    runquery($sql);
}

$r3 = DB::fetch_first('SELECT * FROM %t  WHERE 1 LIMIT 1', array('xigua_rw_hangye'), true);
if(!$r3){
    $sql = <<<SQL
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(1, 0, '$installlang[xiaoshou]', '', '', '', 1589337716, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(2, 1, '$installlang[xiaoshou]', '', '', '', 1589337720, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(4, 0, '$installlang[canyin]', '', '', '', 1590807544, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(5, 0, '$installlang[jiudian]', '', '', '', 1590807544, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(6, 0, '$installlang[jianzhu]', '', '', '', 1590807544, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(7, 4, '$installlang[meishi]', '', '', '', 1590807551, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(8, 5, '$installlang[kuaijie]', '', '', '', 1590807583, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(9, 5, '$installlang[binguan]', '', '', '', 1590807583, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(10, 5, '$installlang[gaodang]', '', '', '', 1590807583, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(11, 6, '$installlang[jianzhu]', '', '', '', 1590807583, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
INSERT IGNORE INTO `pre_xigua_rw_hangye` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `share_title`, `share_desc`, `share_pic`) VALUES(12, 6, '$installlang[zhuangxiu]', '', '', '', 1590807594, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '', '', '');
SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t WHERE `Field`=\'area_keys\'', array('xigua_rw_ad'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_rw_ad` ADD `area_keys` VARCHAR(2000) NOT NULL;
ALTER TABLE `pre_xigua_rw_wx` ADD `area_keys` VARCHAR(2000) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t WHERE `Field`=\'note\'', array('xigua_rw_ad'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_rw_ad` ADD `note` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t WHERE `Field`=\'pos\'', array('xigua_rw_hangye'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_rw_hangye` ADD `pos` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_rw_hangye` ADD `outlink` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t WHERE `Field`=\'pttype\'', array('xigua_rw_wx'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_rw_wx` ADD `pttype` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_wx` ADD `pttag` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_wx` ADD `ptfans` VARCHAR(80) NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t WHERE `Field`=\'addr\'', array('xigua_rw_wx'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_rw_wx` ADD `addr` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_rw_wx` ADD `province` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_wx` ADD `city` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_wx` ADD `district` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_wx` ADD `street` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_wx` ADD `street_number` VARCHAR(80) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t WHERE `Field`=\'addr\'', array('xigua_rw_ad'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_rw_ad` ADD `addr` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_rw_ad` ADD `province` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_ad` ADD `city` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_ad` ADD `district` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_ad` ADD `street` VARCHAR(80) NOT NULL;
ALTER TABLE `pre_xigua_rw_ad` ADD `street_number` VARCHAR(80) NOT NULL;

SQL;
    runquery($sql);
}

@unlink(DISCUZ_ROOT . './source/plugin/xigua_rw/install.php');

