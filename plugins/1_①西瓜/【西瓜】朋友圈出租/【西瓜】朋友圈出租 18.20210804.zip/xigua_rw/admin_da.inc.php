<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
if (empty($_G['cache']['plugin'])) :
    loadcache('plugin');
endif;
$rw_config = $_G['cache']['plugin']['xigua_rw'];
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_rw/function.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_rw/common_status.php';

$page = max(1, intval($_GET['page']));
$lpp = 10;
$start_limit = ($page - 1) * $lpp;
$pzfield = array();

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" /><style>img{object-fit:cover}</style>";
if($secid = intval($_GET['secid'])){
    $res = C::t('#xigua_rw#xigua_rw_ad')->fetch_by_id($secid);
    $unsetary =array(
        'allnum' ,'adid', 'dig', 'is_dig','dig_endts_u', 'upts_u','crts_u','gender_u','digtype','endts_u','endts', 'dig_days','chaoshi',
        'jineng_ary','jineng_str_ary','areawant','area_keys','areawant_str_ary','showqr', 'is_end' ,'jineng_str', 'areawant_ary', 'payts_u','shname','status_str','orderid','payts','tuijian','order_id','shares','jineng','jineng_str','realname','mobile','album_ary','percent','idu','guidetype','dig_startts','dig_endts','shid','lat','lng'
    );
    $ts_ary = array('crts', 'upts', 'dig_startts','dig_endts', 'endts', 'payts');
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $neww = 1;
            $res =array (
                'uid' => '0',
                'status' => '1',
                'jineng' => '',
                'jineng_str' => '',
                'friend_num' => '',
                'rent_price' => 0,
                'gender' => '',
                'jieshao' => '',
                'realname' => '',
                'mobile' => '',
                'danshu' => '0',
                'complete' => '0',
                'areawant' => '',
                'areawant_str' => '',
                'album' => '',
                'yangban' => '',
                'crts' => TIMESTAMP,
                'upts' => TIMESTAMP,
                'endts' => '0',
                'dig_startts' => '0',
                'dig_endts' => '0',
                'views' => '0',
                'shares' => '0',
                'stid' => '0',
                'displayorder' => '0',
                'payts' => '0',
                'wxid' => '0',
            );
        }
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_rw('glwxq',0) . ($secid>0?'-'. $res['name']." [ ID : $secid ]" :''). "&nbsp;&nbsp;<a class='' href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}'>".lang_rw('back',0)."</a>");

        $listinfo = C::t('#xigua_rw#xigua_rw_hangye')->list_all(1);
        C::t('#xigua_rw#xigua_rw_hangye')->init($listinfo);
        $cat_list = C::t('#xigua_rw#xigua_rw_hangye')->get_tree_array(0);
        foreach ($res as $index => $re) {
            if(in_array($index, $unsetary)){
                continue;
            }
            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, $ts_ary)){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('rent_price', 'gender','friend_num'))){
                if($index=='gender'){
                    $__tmp = $gendser2;
                    $cs = '<select name="editform[gender]">';
                }elseif($index=='friend_num'){
                    $__tmp = $friend_nums;
                    $cs = '<select name="editform[friend_num]">';
                }elseif($index=='rent_price'){
                    $__tmp = $rent_prices;
                    $cs = '<select name="editform[rent_price]">';
                }elseif($index=='unit'){
                    $__tmp = $fwunits;
                    $cs = '<select name="editform[unit]">';
                }
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if($c== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('jineng'))){
                $__tmp = $cat_list;
                $cs = '<select name="editform[jineng][]" multiple="multiple" style="height:200px">';
                $re_tmp = explode(',', $re);
                foreach ($cat_list as $c_t => $c) {
                    $s = $extp = '';
//                    $cs .= "<optgroup label='$c[name]'>";
                    $s0 = in_array($c['id'], $re_tmp) ? 'selected' : '';
                    $cs .= "<option $s0 value=\"$c[id]\">$c[name]</option>";
                    foreach ($c['sub'] as $vv) {
                        $s = '';
                        if(in_array($vv['id'], $re_tmp)){
                            $s = 'selected';
                        }
                        $cs .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;&nbsp;&nbsp;L $vv[name]</option>";
                    }
//                    $cs .= '</optgroup>';
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('showbm' ,'tuijian','showdis', 'selfdis', 'orderdis', 'newp', 'allow_tk','openmobile','dingjin_open','yuyue','dl_status'))){
                $tp = 'radio';
            }

            if(in_array($index, array('logo', 'yangban'))){
                $tp = 'filetext';
            }
            if (in_array($index, array('album'))) {
                $re = !is_array($re) ? explode(",", $re) : $re;
                $tp = 'filetext';
                $rw_config = $_G['cache']['plugin']['xigua_rw'];
                $loopnum = $rw_config['maximg'] = 9;
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_rw($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_rw($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }elseif($index == 'fanwei'){
                showsetting(lang_rw($index, 0), "editform[$index]", $re, $tp, '', 0, lang_rw('fanwei_tip',0), $_extra);
            }else{
                showsetting(lang_rw($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*dis'.'m.tao'.'bao.com*/
        showformfooter(); /*dism��taobao��com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');
function changeurl(val){window.location.href = window.location.href+'&catid='+val;}
</script>
HTML;

    }else{
        $listinfo = C::t('#xigua_rw#xigua_rw_hangye')->list_all(1);
        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach ($ts_ary as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }
        $jineng_str = $listwithkey = array();
        foreach ($listinfo as $index => $item) {
            $listwithkey[$item['id']] = $item;
        }
        foreach ($editform['jineng'] as $index => $item) {
            $jineng_str[] = $listwithkey[$item]['name'];
        }
        $editform['jineng'] = implode(',', $editform['jineng']);
        $editform['jineng_str'] = implode(',', $jineng_str);

        $editform['jieshao'] = htmlspecialchars_decode($editform['jieshao']);
        foreach (array('album') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = implode(',', $editform[$item]);
        }
        if($secid>0){
            $rs = C::t('#xigua_rw#xigua_rw_ad')->update($secid, $editform);
            $hid = $secid;
        }else{
            $hid = C::t('#xigua_rw#xigua_rw_ad')->insert($editform, 1);
        }
        cpmsg(lang_rw('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}&secid=$hid", 'succeed');
    }
}else {

    if(submitcheck('dailiid')){
        $adid = intval($_GET['dailiid']);
        $dldata = array(
            'kouling' => $_GET['kouling'],
            'rand_kl' => $_GET['rand_kl'],
            'dl_status' => $_GET['dl_status'],
        );
        C::t('#xigua_rw#xigua_rw_ad')->update($adid, $dldata);
        cpmsg(lang_rw('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}&page=$page", 'succeed');
    }

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_rw#xigua_rw_ad')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_rw#xigua_rw_ad')->update($id, array(
                'status' => $item['status'],
                'tuijian' => $item['tuijian'],
            ));
        }
        cpmsg(lang_rw('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}&page=$page", 'succeed');
    }
    $wherearr = array();
/*    if($_GET['catid']){
        $wherearr[] = "FIND_IN_SET(".intval($_GET['catid']).", jineng)";
    }*/
    if($_GET['guidetype']=='beidong'){
        $wherearr[] = "wxid>0";
    }elseif($_GET['guidetype']=='zhudong'){
        $wherearr[] = "wxid=0";
    }
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey(daddslashes($keyword))) {
        $wherearr[] = " (friend_num LIKE '%$keyword%' OR gender LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR areawant_str LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }
    $ob = 'adid DESC';
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_rw('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($fuwu_status as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }
    $listinfo = C::t('#xigua_rw#xigua_rw_hangye')->list_all(1);
    C::t('#xigua_rw#xigua_rw_hangye')->init($listinfo);
    $cat_list = C::t('#xigua_rw#xigua_rw_hangye')->get_tree_array(0);
    $check0 = $_GET['catid']?'':'selected';
    /*$csearch = "&nbsp;<select name=\"catid\">";
    $csearch .= "<option value=\"0\" $check0 >".lang_hb('quanbu',0)."</option>";
    foreach ($cat_list as $k => $v) {
        $check1 = $_GET['catid']==$v['id']?'selected':'';
        $csearch .= "<option value=\"$v[id]\" $check1 >$v[name]</option>";
        foreach ($v['sub'] as $kk => $vv) {
            $check2 = $_GET['catid']==$vv['id']?'selected':'';
            $csearch .= "<option value=\"$vv[id]\" $check2 >&nbsp;&nbsp;$vv[name]</option>";
        }
    }
    $csearch .= '</select>';*/

    $csearch = "&nbsp;<select name=\"guidetype\">";
    $csearch .= "<option value=\"0\" $check0 >".lang_rw('leixing',0)."</option>";
    foreach ($dantype as $k => $v) {
        $check1 = $_GET['guidetype']==$k?'selected':'';
        $csearch .= "<option value=\"$k\" $check1 >$v</option>";
    }
    $csearch .= '</select>';
    echo $csearch;
    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}".' class="btn" >'.cplang('reset').'</a> ';
    echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px}.mt3{margin-top:3px}.c9{color:#999}.dig.dian{color:#fff;background-color:#67a1f2;}
.jobtit{font-size:13px;color:#369}.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;font-size:12px;border-radius:2px}
.jthumb{width:70px;height:50px}.red{color:#ff6565}.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.tyu{width:60px;display:block;color:#4caf50}.tyu.jingjia{color:#ff6565}.vdesc{max-width:250px;max-height:150px;overflow-y:auto}.priceText{color:#ff6565}.btn2{padding: 3px 5px;line-height:30px;white-space:nowrap}.btn3{background: #DADADA;color: #999;}.previewimg{width:30px;height:30px;vertical-align:middle}.v_mingxi li{margin-bottom:3px}
</style>";
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}&secid=-1\" class=\"btn bg_green\">".lang_rw('tjsp',0)."</a></div>";

    showtableheader(lang_rw('glwxq', 0));
    showtablerow('class="header"', array(), array(
        lang_rw('del', 0),
//        lang_rw('tuijian', 0),
//        lang_rw('yangban', 0),
        lang_rw('name', 0),
        lang_rw('jieshao', 0),
//        lang_rw('shifu', 0),
        lang_rw('status', 0),
        lang_rw('crts', 0),
        lang_rw('caozuo', 0),
    ));
    $res = C::t('#xigua_rw#xigua_rw_ad')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob,  '*');
    $icount = C::t('#xigua_rw#xigua_rw_ad')->fetch_count_by_page($wherearr);
    $wxids = array();
    foreach ($res as $k => $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        if ($v['wxid']) {
            $wxids[$v['wxid']] = $v['wxid'];
        }
    }
    $wxlist = C::t('#xigua_rw#xigua_rw_wx')->fetch_by_ids($wxids, '*', 'wxid');
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        $mobiles = DB::fetch_all('SELECT uid,mobile,realname FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
    }
    $wxqr = lang_rw('yangban',0);
    $jineng_str = lang_rw('jineng_str',0);
    $zhiding = lang_rw('zhiding',0);
    $fenlei = lang_rw('fenlei',0);
    $_name = lang_rw('name',0);
    $qunzhuwx = lang_rw('friend_num',0);
    $shoufei = lang_rw('rent_price',0);
    $kouling = lang_rw('gender123',0);
    $jieshao = lang_rw('jieshao',0);
    $wancheng = lang_rw('wancheng',0);
    $fanwei = lang_rw('quyu',0);
    $album = lang_rw('album',0);
    $age = lang_rw('age',0);
    $lang_r = lang_rw('r',0);
    $lang_yuan = lang_rw('yuan',0);
    $lang_day = lang_rw('day',0);
    foreach ($res as $v) {
        if($wxlist[$v['wxid']]){
            $wxuser = getuserbyuid($wxlist[$v['wxid']]['uid'], 1);
        }
        $id = $v['adid'];
        $v['album'] = explode(',', $v['album']);
        $thumb = $v['yangban']?$v['yangban']:$v['album'][0];
        $thumb = $thumb ? $thumb :'source/plugin/xigua_rw/static/img/new.png';

        $img = '';
        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' class='previewimg' /> </a>";
        }
        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($statuss as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        $dltxt = '';

        $digstr = $v['is_dig'] ? '<span class="dig">'.lang_rw('dig',0).'</span>' : '';
        $digstr .= $v['shid'] ? ' <span class="dig dian">'.lang_rw('dian',0).'</span>' : '';
        $fuwuinfo = $v;
        $title_ext = "<ul class=\"v_mingxi cl\">
    ".($v['friend_num']?"<li><span class='c9'>$qunzhuwx : </span> <span class=\" f12\">{$v['friend_num']}</span></li>":'')."
    ".($v['rent_price']>0 ? "<li><span class='c9'>$shoufei : </span> <span class=\" f12\">{$v['rent_price']}$lang_yuan</span></li>":'')."
    ".($v['gender']?"<li><span class='c9'>$kouling : </span> <span class=\" f12\">{$v['gender']}</span></li>":'')."
    ".($v['age']?"<li><span class='c9'>$age : </span> <span class=\" f12\">{$v['age']}</span></li>":'')."
    ".($v['areawant_str']?"<li><span class='c9'>$fanwei : </span> <span class=\" f12\">{$v['areawant_str']}</span></li>":'')."
</ul>";
        $description = "<ul class=\"v_mingxi cl\">".
            ($v['wxid']?"<li><span class='c9'>$zhiding : </span> <span class=\" f12\"  style='color:orangered'>{$wxuser['username']} [ {$wxuser['uid']} ]</span></li>":'').
            ($v['danshu']?"<li><strong class='c9'>$wancheng : </strong> <strong class=\" f12\">{$v['complete']} / {$v['danshu']}</strong></li>":'').
            "<li><span class='c9'>$jieshao : </span> <span class=\"f12\">{$v['jieshao']}</span></li>".
            "<li><span class='c9'>$album : </span> <span class=\"f12\">{$img}</span></li>".
            "<li><span class='c9'>$wxqr : </span> <span class=' f12'><a href='{$v['yangban']}' target='_blank'><img class='previewimg' src='{$v['yangban']}' onerror=\"this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'\" /></a></span></li>".
            '';
        $description.= "</ul>";
        $istuijian = $v['tuijian'] ? 'checked':'';
        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            $title_ext.
            '<p><em class="c9">'.lang_rw('username',0).' : </em>'.$users[$v['uid']]['username'].' <em>[ '.$v['uid'].' ]</em></p>'.
            ($mobiles[$v['uid']]['realname'] ? '<p class="mt3"><em class="c9">'.lang_rw('realname',0).' : </em>'.$mobiles[$v['uid']]['realname'].'</p>' : '').
            '<p class="mt3"><em class="c9">'.lang_rw('mobile',0).' : </em>'.$mobiles[$v['uid']]['mobile'].'</p>',
            "<div style='width:250px'>$description</div>",
            $status_u,

            '<p><em class="c9">'.lang_rw('crts',0).' : </em>'.$v['crts_u'].'</p>'.
            '<p class="mt3"><em class="c9">'.lang_rw('upts2',0).' : </em>'.$v['upts_u'].'</p>'.
            ($v['payts'] ? '<p class="mt3 c_green"><em>'.lang_rw('payts',0).' : </em>'.$v['payts_u'].'</p>':'').
            '',
            '<a class=\'btn bg_green btn2\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}&secid=$id" . '">' . lang_rw('edit', 0) . '</a> ',
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}&" . http_build_query($_GET) . "&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dis'.'m.tao'.'bao.com*/
    showformfooter(); /*dism��taobao��com*/
}
?>

<div id="rsel_menu" class="custom cmain" style="display:none;width:450px;height:220px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr"></h3>
    </div>
    <div id="rsel_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_da&guidetype={$_GET[guidetype]}&page=$page");
        ?>
        <table class="tb tb2 ">
            <tr>
                <td><?php lang_rw('kouling_tip'); ?></td>
                <td><input name="kouling" value="" id="qkl" style="width:250px"> </td>
            </tr>
            <tr>
                <td><?php lang_rw('rand_kl'); ?></td>
                <td><input name="rand_kl" value="" id="rand_kl" style="width:250px"> </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <div style="width:300px"> <span id="show1" style="color:orangered"><?php lang_rw('dltip');?> </span></div>
                    <input type="hidden" name="dl_status" id="dl_status" value="1">
                    <input type="hidden" name="dailiid" id="dailiid" value="0">
                    <input type="submit" class="btn" name="editsubmit" value="<?php lang_hb('tijiao');?>" />
                </td>
            </tr>
        </table>
        <?php showformfooter(); /*dism��taobao��com*/?>
    </div>
</div>