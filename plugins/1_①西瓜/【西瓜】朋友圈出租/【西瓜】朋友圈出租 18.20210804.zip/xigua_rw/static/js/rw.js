$(document).on('click','#pubj, .pubj', function () {
    var that = $(this);
    if(that.data('onlyapp') && !IN_APP){
        $.alert(that.data('apptip'), function() {
            window.location.href = that.data('applink');
        });
        return false;
    }
    $('#pub_ctrl').popup();
});
function rw_getlocation(callback) {
    if (typeof mag != 'undefined') {
        mag.getLocation(function (res) {
            callback(res);
        });
    } else if (typeof sq != 'undefined') {
        sq.getLocation(function (res) {
            callback(res);
        });
    } else if (typeof QFH5 != 'undefined') {
        QFH5.getLocation(function (state, data) {
            if (state == 1) {
                callback(data);
            } else {
                alert(data.error);
            }
        });
    } else if ((HB_INWECHAT && HB_MULTIUPLOAD) == 1) {
        wx.getLocation({
            type: 'gcj02', success: function (res) {
                callback(res);
            }, cancel: function (res) {
            }
        });
    } else {
        console.log('myapp');
        var geolocation = new qq.maps.Geolocation(mkey, "myapp");
        geolocation.getLocation(callback, function () {}, {timeout: 4000, failTipFlag: true});
    }
}
$(document).on('click','.adjump', function () {
    hb_jump(_APPNAME+'?id=xigua_rw&ac=ad_view&adid='+$(this).data('id')+(typeof _URLEXT!=='undefined' ? _URLEXT : ''));
});
$(document).on('click','.wxjump', function () {
    hb_jump(_APPNAME+'?id=xigua_rw&ac=wx_view&wxid='+$(this).data('id')+(typeof _URLEXT!=='undefined' ? _URLEXT : ''));
});

function rw_getnext(id, name, datahref) {
    $('.sub_check a').removeClass('checked').removeClass('main_color');
    $('.sub_check a').parent().removeClass('checked').removeClass('main_color');
    $('#sub_check' + id).addClass('checked').addClass('main_color');
    $.ajax({
        type: 'get',
        url: _APPNAME + '?id=xigua_hb&ac=chosecity&province=' + $('.first_check+.checked').find('a').text() + '&name=' + name + '&ctid=' + id + '&datahref=' + encodeURIComponent(datahref) + '&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            $('.ajaxbox_cheker').html(s);
        }
    });
}