<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if (empty($_G['cache']['plugin'])) :
    loadcache('plugin');
endif;
$rw_config = $_G['cache']['plugin']['xigua_rw'];
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_rw/function.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_rw/common_status.php';

$page = max(1, intval($_GET['page']));
$lpp = 10;
$start_limit = ($page - 1) * $lpp;
$pzfield = array();

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" /><style>img{object-fit:cover}</style>";

if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
    $ret = C::t('#xigua_rw#xigua_rw_log')->do_delete(intval($_GET['delid']));
    if($ret){
        cpmsg(
            lang_rw('delcat_succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_order&page=$page",
            'succeed'
        );
    }else{
        cpmsg(
            lang_rw('del_error', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_order&page=$page",
            'error'
        );
    }
}
if(submitcheck('complete', 1) && FORMHASH == $_GET['formhash']){
    $needlogid = intval($_GET['complete_id']);
    $needlog = C::t('#xigua_rw#xigua_rw_log')->fetch($needlogid);
    C::t('#xigua_rw#xigua_rw_log')->confirm_complete($needlogid, $needlog);
    if($needlog['adid']){
        C::t('#xigua_rw#xigua_ho_need')->update($needlog['adid'], array('status'=>4));
    }
    cpmsg(
        lang_rw('confirm_complete_success', 0),
        "action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_order&page=$page",
        'succeed'
    );
}
if (submitcheck('permsubmit')) {
    if ($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_rw#xigua_rw_log')->deletes($delete);
    }
    foreach ($_GET['row'] as $id => $item) {
        if($item['status']==3){
            $logid = $id;
            $rwlog = C::t('#xigua_rw#xigua_rw_log')->fetch($logid);
            if($rwlog['confirmts']<=0){
                $adinfo =  C::t('#xigua_rw#xigua_rw_ad')->fetch($rwlog['adid']);
                C::t('#xigua_rw#xigua_rw_log')->update($logid, array('status' => 3, 'confirmts' => TIMESTAMP));
                if($rw_config['kctype']==2) {
                    C::t('#xigua_rw#xigua_rw_ad')->incr($rwlog['adid'], 'complete', 1);
                }
                $allp = $rwlog['chujia'];
                if($rw_config['shouxufei']> 0){
                    $prate = intval(str_replace('%', '', $rw_config['shouxufei']))/100;
                    $shouxufei = round($allp*$prate, 2);
                }else{
                    $shouxufei = 0;
                }
                $income = $allp-$shouxufei;
                $order_complete = lang('plugin/xigua_rw', 'order_complete');
                $href = $_G['siteurl']."$SCRITPTNAME?id=xigua_rw&ac=order&logid=$logid$urlext";
                $title = cutstr(strip_tags($adinfo['jieshao']), 40);
                C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                    'uid' => $rwlog['wxuid'],
                    'crts' => TIMESTAMP,
                    'size' => $income,
                    'note' => str_replace(array('{title}', '{shouxufei}', '{totalprice}',), array( $title, $shouxufei, $income, ), strip_tags($order_complete)),
                    'link' => $href,
                ));
                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($rwlog['wxuid'], 'money', $income);
                notification_add($rwlog['wxuid'],'system', $order_complete, array('title' => $title, 'href' => $href, 'shouxufei'=>$shouxufei, 'totalprice'=> $income),1);
            }
        }else{
            C::t('#xigua_rw#xigua_rw_log')->update($id, array( 'status' => $item['status']));
        }
    }
    cpmsg(lang_rw('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_order&shid={$_GET['shid']}&page=$page", 'succeed');
}
$wherearr = array();
$keyword = $_GET['keyword'];
if (is_numeric($keyword) && $keyword<9999999) {
    $wherearr[] = 'aduid=' . intval($keyword) .' OR wxuid='.intval($keyword);
}else if ($keyword = stripsearchkey(addslashes($keyword))) {
    $wherearr[] = " (`logsn` LIKE '%$keyword%'  OR adinfo LIKE '%$keyword%' ) ";
}
if(isset($_GET['status'])){
    $wherearr[] = 'status=' . intval($_GET['status']);
}
if(($_GET['type'])){
    $wherearr[] = 'type=\'' .daddslashes($_GET['type']).'\'';
}
$ob = 'id desc';
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_order&shid={$_GET['shid']}");

echo '<div><input type="text" id="keyword" placeholder="'.lang_rw('spmc2',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
foreach ($log_status as $index => $_v) {
    echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
}
echo '&nbsp;&nbsp;';
$listinfo = C::t('#xigua_rw#xigua_rw_hangye')->list_all(1);
C::t('#xigua_rw#xigua_rw_hangye')->init($listinfo);
$cat_list = C::t('#xigua_rw#xigua_rw_hangye')->get_tree_array(0);
$check0 = $_GET['type']?'':'selected';
$csearch = "&nbsp;<select name=\"type\">";
$csearch .= "<option value=\"0\" $check0 >".lang_hb('quanbu',0)."</option>";
foreach ($dantype as $k => $v) {
    $check1 = $_GET['type']==$k?'selected':'';
    $csearch .= "<option value=\"$k\" $check1 >$v</option>";
}
$csearch .= '</select>';
echo '&nbsp;&nbsp;';
echo $csearch;
echo '&nbsp;';
echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_order".' class="btn" >'.cplang('reset').'</a> ';
echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}.mt3{margin-top:3px}.c9{color:#999}
.jobtit{font-size:13px;color:#369}.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;border-radius:2px}
.jthumb{width:50px;height:50px}.red{color:#ff6565}.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.tyu{display:block;color:#4caf50}.tyu.jingjia{color:#ff6565}.vdesc{width:250px;max-height:150px;overflow-y:auto}.priceText{color:#ff6565}.qy{color:#4F7CB8}.v_mingxi{max-width:250px}.shifavatar{width:30px;height:30px;border-radius:50%}.btn2{padding: 3px 5px;line-height:30px;white-space:nowrap}.btn3{background: #DADADA;color: #999;}.zhudong{color:#0e0e0e}.beidong{color:#F44336}.proce{font-size:18px;color:#F44336}
</style>";
echo " </div>";
$lang_chujia = lang_rw('chujia',0);
$lang_payts = lang_rw('payts',0);

showtableheader(lang_rw('fabuguanli', 0));
showtablerow('class="header"', array(), array(
    lang_rw('id', 0),
    lang_rw('xdsj', 0),
    lang_rw('status', 0),
    lang_rw('ddje', 0),
    lang_rw('jdr', 0),
    lang_rw('adinfo', 0),
    lang_rw('caozuo', 0),
));
$res = C::t('#xigua_rw#xigua_rw_log')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob, '*');
$icount = C::t('#xigua_rw#xigua_rw_log')->fetch_count_by_page($wherearr);

$wxqr = lang_rw('yangban',0);
$jineng_str = lang_rw('jineng_str',0);
$zhiding = lang_rw('zhiding',0);
$fenlei = lang_rw('fenlei',0);
$_name = lang_rw('name',0);
$qunzhuwx = lang_rw('friend_num',0);
$shoufei = lang_rw('rent_price',0);
$kouling = lang_rw('gender1',0);
$jieshao = lang_rw('yunyingleixing',0);
$wancheng = lang_rw('ages',0);
$fanwei = lang_rw('areawant',0);
$hangye1 = lang_rw('jineng',0);
$album = lang_rw('qrcode',0);
$haoyoupic_ = lang_rw('haoyoupic',0);
$km = lang_rw('km',0);
$lang_r = lang_rw('r',0);
$lang_yuan = lang_rw('yuan',0);
$lang_day = lang_rw('day',0);
$album1  = lang_rw('album',0);
$jieshao1  = lang_rw('jieshao',0);
$jiedanren  = lang_rw('jdr',0);
$wxh  = lang_rw('wxh',0);
$sjh  = lang_rw('sjh',0);
$qrcode  = lang_rw('qrcode',0);
$haoyoupic  = lang_rw('haoyoupic',0);
$fdr1  = lang_rw('fdr',0);


foreach ($res as $v) {
    $id = $v['id'];
    $status_u = "<select name=\"row[$id][status]\">";
    foreach ($log_status as $k => $vv) {
        if($v['status']== $k){
            $s = 'selected';
        }else{
            $s = '';
        }
        $status_u .= "<option $s value=\"$k\">$vv</option>";
    }
    $status_u .= '</select>';
    $jdr = "<p><em class='c9'>$jiedanren : </em> {$v['wx_username']}</p>".
        "<p><em class='c9'>$wxh : </em> {$v['wx']['weixin']}</p>".
        "<p><em class='c9'>$sjh : </em> {$v['wx']['mobile']}</p>".
        "<p><span class='c9'>$jieshao : </span> <span class='f12'>{$v['wx']['guidetype']}</span></p>".
        ($v['wx']['friend_num']?"<p><span class='c9'>$qunzhuwx : </span> <span class=\" f12\">{$v['wx']['friend_num']}</span></p>":'').
        ($v['wx']['rent_price']>0 ? "<p><span class='c9'>$shoufei : </span> <span class=\" f12\">{$v['wx']['rent_price']}$lang_yuan</span></p>":'').
        ($v['wx']['gender']?"<p><span class='c9'>$kouling : </span> <span class=\" f12\">{$v['wx']['gender']}</span></p>":'').
        ($v['wx']['ages']?"<p><span class='c9'>$wancheng : </span> <span class=\" f12\">{$v['wx']['ages']}</span></p>":'').
        ($v['wx']['areawant_str']?"<p><span class='c9'>$fanwei : </span> <span class=\" f12\">{$v['wx']['areawant_str']}</span></p>":'').
        ($v['wx']['jineng_str']?"<p><span class='c9'>$hangye1 : </span> <span class=\" f12\">{$v['wx']['jineng_str']}</span></p>":'').
        "<p><em class='c9'>$qrcode : </em> <a href='{$v['wx']['wxqrcode']}' target='_blank'><img style='width:20px;height:20px' src='{$v['wx']['wxqrcode']}' /></a></p>".
        "<p><em class='c9'>$haoyoupic : </em> <a href='{$v['wx']['haoyoupic']}' target='_blank'><img style='width:20px;height:20px' src='{$v['wx']['haoyoupic']}' /></a></p>".
    '';

    $img = '';
    foreach (explode(',', $v['adinfo']['album']) as $index => $item) {
        $img .= "<a href='$item' target='_blank'><img style='width:20px;height:20px' src='$item' class='previewimg' /> </a>";
    }
    $fdr = "".
        "<p><em class='c9'>$fdr1 : </em> {$v['ad_username']}</p>".
        "<p><em class='c9'>$sjh : </em> {$v['ad_mobile']}</p>".
    ($v['adinfo']['friend_num']?"<p><span class='c9'>$qunzhuwx : </span> <span class=\" f12\">{$v['adinfo']['friend_num']}</span></p>":'')."
    ".($v['adinfo']['rent_price']>0 ? "<p><span class='c9'>$shoufei : </span> <span class=\" f12\">{$v['adinfo']['rent_price']}$lang_yuan</span></p>":'')."
    ".($v['adinfo']['gender']?"<p><span class='c9'>$kouling : </span> <span class=\" f12\">{$v['adinfo']['gender']}</span></p>":'')."
    ".($v['adinfo']['areawant_str']?"<p><span class='c9'>$fanwei : </span> <span class=\" f12\">{$v['adinfo']['areawant_str']}</span></p>":'').
    '';

    $yb = $v['adinfo']['yangban'] ? $v['adinfo']['yangban'] :'source/plugin/xigua_rw/static/img/new.png';
    $adinfo = "".
        "<p style='max-width:200px'><span class='c9'>$jieshao1 : </span> <span class=\"f12\">{$v['adinfo']['jieshao']}</span></p>".
        "<p><span class='c9'>$album1 : </span> <span class=\"f12\">{$img}</span></p>".
        "<p><span class='c9'>$wxqr : </span> <span class=' f12'><a href='{$yb}' target='_blank'><img style='width:20px;height:20px' class='previewimg' src='{$yb}' /></a></span></p>".
    '';
    $ddxq = "".
        "<p><em class='c9'>".lang_rw('wcsy',0)." : </em> <em class='proce'>{$v['chujia']}</em></p>".
        ($v['pz1'] ? "<p><span class='c9'>".lang_rw('pz1',0)." : </span> <span class=' f12'><a href='{$v['pz1']}' target='_blank'><img style='width:20px;height:20px' class='previewimg' src='{$v['pz1']}' /></a></span></p>" : '').
        "{$v['pz1_crts_u']}".
        ($v['pz2'] ?  "<p><span class='c9'>".lang_rw('pz2',0)." : </span> <span class=' f12'><a href='{$v['pz2']}' target='_blank'><img style='width:20px;height:20px' class='previewimg' src='{$v['pz2']}' /></a></span></p>" : '').
        "{$v['pz2_crts_u']}".
    '';

    showtablerow('', array(), array(
        $id,
        '<p><em class="c9 '.$v['type'].'">'.$dantype[$v['type']].lang_rw('logsn',0).' : </em>'.$v['logsn'].'</p>'.
        '<p><em class="c9">'.lang_rw('crts',0).' : </em>'.date('Y-m-d H:i:s', $v['crts']).'</p>'.
        '<p class="mt3"><em class="c9">'.lang_rw('upts2',0).' : </em>'.date('Y-m-d H:i:s', $v['upts']).'</p>'.
        ($v['confirmts'] ? '<p class="mt3 c_green"><em class="c9">'.lang_rw('qrwg',0).' : </em>'.date('Y-m-d H:i:s', $v['confirmts']).'</p>' : '').
        '',
        $status_u,
        $ddxq,
        '<div style="max-height:150px;max-width:200px;overflow-y:auto">'.$jdr.'</div>',
        '<div style="max-height:150px;max-width:200px;overflow-y:auto">'.$adinfo.'<div>-------------------------------</div>'.$fdr.'</div>',
        '<a class=\'btn btn2 btn3\' href="javascript:;" onclick="return _confim_del('.$id.');">' . lang_rw('del', 0) . '</a> ',
    ));
}
$dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_order&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_order&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', '', "", $multipage);
showtablefooter(); /*dis'.'m.tao'.'bao.com*/
showformfooter(); /*dism��taobao��com*/
?>
<script>
    function _confim_del(id){
        if(confirm('<?php lang_rw('del_confirm')?> ID : ' + id + ' ?')){
            window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_rw&pmod=admin_order&page=$page&del=1&formhash=".FORMHASH.'&delid='?>"+id;
        }
    }
</script>
