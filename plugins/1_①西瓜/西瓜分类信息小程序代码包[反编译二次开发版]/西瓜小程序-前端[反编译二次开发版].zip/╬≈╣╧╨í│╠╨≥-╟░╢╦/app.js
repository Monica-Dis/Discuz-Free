App({
    onLaunch: function() {},
    globalData: {
        userInfo: null
    }
});