getApp();

var e = require("../../utils/md5"), n = require("../../utils/config"), t = n.config().appid, o = n.config().siteurl, i = (n.config().title, 
n.config().desc, n.config().color);

Page({
    data: {
        motto: "",
        userInfo: {},
        hasUserInfo: !1,
        canIUse: wx.canIUse("button.open-type.getUserInfo")
    },
    onLoad: function(n) {
        wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: i
        }), wx.showLoading({
            title: "加载中"
        }), wx.login({
            success: function(i) {
                wx.request({
                    url: o + "source/plugin/xigua_hx/api.php?id=xigua_hx&newapp=" + t + "&ac=user&signin=1&code=" + i.code,
                    header: {
                        "content-type": "application/json"
                    },
                    success: function(i) {
                        if (void 0 === i.data) return wx.showModal({
                            title: "提示",
                            showCancel: !1,
                            content: JSON.stringify(i)
                        }), !1;
                        if (void 0 === i.data.data) return wx.showModal({
                            title: "提示",
                            showCancel: !1,
                            content: JSON.stringify(i)
                        }), !1;
                        if (void 0 === i.data.data.items) return wx.showModal({
                            title: "提示",
                            showCancel: !1,
                            content: JSON.stringify(i)
                        }), !1;
                        if (void 0 === i.data.data.items[0].openid) return wx.showModal({
                            title: "提示",
                            showCancel: !1,
                            content: JSON.stringify(i.data.data.items)
                        }), !1;
                        var a = i.data.data.items[0].openid;
                        wx.request({
                            url: o + "source/plugin/xigua_hx/api.php?id=xigua_hx&newapp=" + t + "&ac=pay",
                            header: {
                                "content-type": "application/json"
                            },
                            data: {
                                order_id: n.order_id,
                                uid: n.uid,
                                openid: a
                            },
                            success: function(o) {
                                var i = n.j;
                                -1 !== i.indexOf("%3A") && (i = decodeURIComponent(i)), console.log(i);
                                var a = new Date(), c = Math.round(a.getTime() / 1e3).toString();
                                if (void 0 === o.data.meta.code) return wx.showModal({
                                    title: "提示",
                                    showCancel: !1,
                                    content: JSON.stringify(o)
                                }), !1;
                                if ("0" == o.data.meta.code) {
                                    var d = o.data.data.items[0];
                                    console.log(d);
                                    var s = "prepay_id=" + d.prepay_id, r = e.hexMD5("appId=" + t + "&nonceStr=" + d.nonce_str + "&package=" + s + "&signType=MD5&timeStamp=" + c + "&key=" + d.key);
                                    wx.hideLoading(), wx.requestPayment({
                                        timeStamp: c,
                                        nonceStr: d.nonce_str,
                                        package: s,
                                        signType: "MD5",
                                        paySign: r,
                                        success: function(e) {
                                            wx.showModal({
                                                title: "提示",
                                                showCancel: !1,
                                                content: "支付成功",
                                                success: function(e) {
                                                    wx.redirectTo({
                                                        url: "/pages/index/index?url=" + encodeURIComponent(i)
                                                    });
                                                }
                                            });
                                        },
                                        fail: function(e) {
                                            wx.showModal({
                                                title: "提示",
                                                showCancel: !1,
                                                content: -1 === JSON.stringify(e).indexOf("cancel") ? "支付失败了，原因：" + JSON.stringify(e) + JSON.stringify(d) : "取消支付",
                                                success: function(e) {
                                                    e.confirm ? wx.redirectTo({
                                                        url: "/pages/index/index?url=" + encodeURIComponent(i)
                                                    }) : e.cancel && wx.redirectTo({
                                                        url: "/pages/index/index?url=" + encodeURIComponent(i)
                                                    });
                                                }
                                            });
                                        }
                                    });
                                } else wx.hideLoading(), wx.showModal({
                                    title: "提示",
                                    showCancel: !1,
                                    content: o.data.meta.message,
                                    success: function(e) {
                                        e.confirm ? wx.redirectTo({
                                            url: "/pages/index/index?url=" + encodeURIComponent(i)
                                        }) : e.cancel && wx.redirectTo({
                                            url: "/pages/index/index?url=" + encodeURIComponent(i)
                                        });
                                    }
                                });
                            }
                        });
                    }
                });
            },
            fail: function() {
                wx.showModal({
                    title: "提示",
                    showCancel: !1,
                    content: "支付失败!"
                }), wx.hideLoading();
            },
            complete: function(e) {
                wx.hideLoading();
            }
        });
    }
});