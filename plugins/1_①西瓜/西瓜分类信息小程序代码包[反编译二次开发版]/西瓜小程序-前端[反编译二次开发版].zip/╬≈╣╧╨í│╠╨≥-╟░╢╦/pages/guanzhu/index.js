getApp(), require("../../utils/md5");

var t = require("../../utils/config"), a = (t.config().siteurl, t.config().indexurl, 
t.config().title), e = t.config().desc, i = (t.config().logo, t.config().color);

Page({
    data: {
        url: "",
        apptitle: "",
        imgUrl: ""
    },
    onShareAppMessage: function(t) {
        var i = this;
        return void 0 !== i.data.imgUrl ? {
            title: i.data.apptitle && "<" != i.data.apptitle && "F" != i.data.apptitle ? i.data.apptitle : a,
            desc: e,
            imageUrl: i.data.imgUrl,
            path: "/pages/index/index?url=" + encodeURIComponent(t.webViewUrl)
        } : {
            title: i.data.apptitle && "<" != i.data.apptitle && "F" != i.data.apptitle ? i.data.apptitle : a,
            desc: e,
            path: "/pages/index/index?url=" + encodeURIComponent(t.webViewUrl)
        };
    },
    onLoad: function(t) {
        wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: i
        }), wx.showShareMenu({
            withShareTicket: !0
        });
    },
    msgHandler: function(t) {
        var a = this;
        a.setData({
            imgUrl: t.detail.data[0].imgUrl
        }), console.log(a.data);
    }
});