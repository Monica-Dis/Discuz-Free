getApp(), require("../../utils/md5");

var t = require("../../utils/config"), a = t.config().siteurl, e = t.config().indexurl, i = t.config().title, o = t.config().desc, l = (t.config().logo, 
t.config().color);

Page({
    data: {
        url: "",
        apptitle: "",
        imgUrl: ""
    },
    onShareAppMessage: function(t) {
        var a = this;
        return void 0 !== a.data.imgUrl ? {
            title: a.data.apptitle && "<" != a.data.apptitle && "F" != a.data.apptitle ? a.data.apptitle : i,
            desc: o,
            imageUrl: a.data.imgUrl,
            path: "/pages/index/index?url=" + encodeURIComponent(t.webViewUrl)
        } : {
            title: a.data.apptitle && "<" != a.data.apptitle && "F" != a.data.apptitle ? a.data.apptitle : i,
            desc: o,
            path: "/pages/index/index?url=" + encodeURIComponent(t.webViewUrl)
        };
    },
    onLoad: function(t) {
        wx.setNavigationBarColor({
            frontColor: "#ffffff",
            backgroundColor: l
        }), wx.showShareMenu({
            withShareTicket: !0
        });
        var i = "", o = this;
        t.url ? (i = decodeURIComponent(t.url), this.setData({
            url: decodeURIComponent(t.url)
        })) : (i = e, this.setData({
            url: e
        }));
        var n = a + "source/plugin/xigua_hx/api.php?mini=11&mobile=2&" + i.slice(i.indexOf(".php?") + 5);
        wx.request({
            url: n,
            header: {
                "content-type": "application/json"
            },
            success: function(t) {
                if (void 0 !== t.data) {
                    var a = t.data[0];
                    o.setData({
                        apptitle: a
                    });
                }
            }
        });
    },
    msgHandler: function(t) {
        var a = this;
        a.setData({
            imgUrl: t.detail.data[0].imgUrl
        }), console.log(a.data);
    }
});