function i(i, t, e) {
    return t in i ? Object.defineProperty(i, t, {
        value: e,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : i[t] = e, i;
}

module.exports = {
    config: function() {
        var t;
        return t = {
          color: "#FF5073",
            siteurl: "https://域名/",
            indexurl: "https://域名/plugin.php?id=xigua_hb&mobile=2&x=1",
            title: "系统同城",
            desc: "优惠信息等。",
            appid: "wx51559dea65da416d"
        }, 
        t;
    }
};