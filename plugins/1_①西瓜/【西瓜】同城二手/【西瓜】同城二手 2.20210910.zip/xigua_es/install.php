<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2020/10/10
 * Time: 15:16
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_es_index` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `types` varchar(20) NOT NULL,
 `style` varchar(20) NOT NULL,
 `catids` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `types` (`types`),
 KEY `catids` (`catids`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_es_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_es_order` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `crts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `order_id` varchar(200) NOT NULL,
 `gnum` int(11) NOT NULL,
 `pay_money` decimal(10,2) NOT NULL,
 `addrid` int(11) NOT NULL,
 `addr` varchar(500) NOT NULL,
 `pay_ts` int(11) NOT NULL,
 `fa_ts` int(11) NOT NULL DEFAULT '-1',
 `shou_ts` int(11) DEFAULT '-1',
 `tui_ts` int(11) NOT NULL,
 `tuicfm_ts` int(11) NOT NULL,
 `gid` int(11) NOT NULL,
 `goodinfo` mediumtext NOT NULL,
 `note` varchar(500) NOT NULL,
 `yunfee` decimal(10,2) NOT NULL,
 `title` varchar(200) NOT NULL,
 `pay_endts` int(11) NOT NULL,
 `mobile` varchar(200) NOT NULL,
 `realname` varchar(200) NOT NULL,
 `status` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 `unit_price` decimal(10,2) NOT NULL,
 `yundan` varchar(200) NOT NULL,
 `yundan_gs` varchar(200) NOT NULL,
 `upts` int(11) NOT NULL,
 `hxuid` int(11) NOT NULL,
 `hxcrts` int(11) NOT NULL,
 `hxnote` varchar(500) NOT NULL,
 `hxcode` varchar(20) NOT NULL,
 `refund` varchar(800) NOT NULL,
 `refund_id` int(11) NOT NULL,
 `ziti` varchar(800) NOT NULL,
 `shou_confirm_ts` int(11) NOT NULL,
 `sxf` decimal(10,2) NOT NULL,
 `seller_uid` int(11) NOT NULL,
 `exp_method` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `order_id` (`order_id`),
 KEY `pay_endts` (`pay_endts`),
 KEY `crts` (`crts`),
 KEY `pay_ts` (`pay_ts`),
 KEY `fa_ts` (`fa_ts`),
 KEY `shou_ts` (`shou_ts`),
 KEY `gid` (`gid`),
 KEY `status` (`status`),
 KEY `refund_id` (`refund_id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_es_refund` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `ptlogid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `danhao` varchar(200) NOT NULL,
 `gongsi` varchar(200) NOT NULL,
 `note` varchar(500) NOT NULL,
 `status` int(11) NOT NULL DEFAULT '-1',
 `order_status` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 `refund_info` varchar(2000) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `crts` (`crts`),
 KEY `odid` (`ptlogid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_es_top` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;
SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es_TC_UTF8.xml');

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/install.php');

$r3 = DB::fetch_first('SELECT * FROM %t WHERE 1 LIMIT 1', array('xigua_es_index'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_es_index` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `aprice`, `types`, `style`, `catids`) VALUES
(1, 0, '1', 'source/plugin/xigua_es/static/img/index_2.png', '', '', 1630043769, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', '2', ''),
(2, 0, '2', 'source/plugin/xigua_es/static/img/index_1.png', '', '', 1630043769, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', '2', ''),
(3, 0, '3', 'source/plugin/xigua_es/static/img/index_3.png', '', '', 1630043794, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', '4', ''),
(4, 0, '4', 'source/plugin/xigua_es/static/img/index_4.png', '', '', 1630046281, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', '4', '');
SQL;
    runquery($sql);
}

$r3 = DB::fetch_first('SELECT * FROM %t WHERE 1 LIMIT 1', array('xigua_es_nav'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_es_nav` (`id`, `pid`, `name`, `icon`, `icon2`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `aprice`, `iconname`, `up`, `highlight`, `type`) VALUES
(1, 0, '{$installlang['index1']}', 'source/plugin/xigua_es/static/img/00.png', 'source/plugin/xigua_es/static/img/01.png', '', 'plugin.php?id=xigua_es', 1629858490, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(2, 0, '{$installlang['index2']}', 'source/plugin/xigua_es/static/img/10.png', 'source/plugin/xigua_es/static/img/11.png', '', 'plugin.php?id=xigua_es&amp;ac=cat', 1629858490, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(3, 0, '{$installlang['index3']}', 'source/plugin/xigua_es/static/img/pub.png', 'source/plugin/xigua_es/static/img/pub.png', '', 'pub', 1629858490, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 1, '', ''),
(4, 0, '{$installlang['index4']}', 'source/plugin/xigua_es/static/img/20.png', 'source/plugin/xigua_es/static/img/21.png', '', 'plugin.php?id=xigua_es&amp;ac=mycomment&amp;type=sx', 1629858490, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(5, 0, '{$installlang['index5']}', 'source/plugin/xigua_es/static/img/30.png', 'source/plugin/xigua_es/static/img/31.png', '', 'plugin.php?id=xigua_es&amp;ac=my', 1629858490, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', '');
SQL;
    runquery($sql);
}

$r3 = DB::fetch_first('SELECT * FROM %t WHERE id=999 LIMIT 1', array('xigua_hb_cat'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_hb_cat` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `fid`, `in_ad`, `in_adlnk`, `isshow`, `multiprice`, `tpl`, `telpri`, `apprice`, `share_title`, `share_desc`, `share_pic`, `cat_link`, `zdprice`, `jiaobiao`, `a_video`, `mfshen`, `shuxin`, `hidereal`, `closeicon`, `customad`, `maxday`, `freeday`, `cmtrsh`, `showinst`, `videosize`, `share_refresh`, `share_dig`, `share_dig_days`, `placr`, `view_tpl`, `zdtps`, `yxff`, `close_pl`) VALUES
(999, 0, '{$installlang['index1']}', '', '', '', 1629950644, 99, '', '0.00', '', '{$installlang['index6']}', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index7']}', 'source/plugin/xigua_es/static/img/t1.png', '', '', 1629950815, 0, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index8']}', 'source/plugin/xigua_es/static/img/t2.png', '', '', 1629950815, 0, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index9']}', 'source/plugin/xigua_es/static/img/t3.png', '', '', 1629950815, 0, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index10']}', 'source/plugin/xigua_es/static/img/t4.pngg', '', '', 1629950815, 99, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index11']}', 'source/plugin/xigua_es/static/img/t5.png', '', '', 1629950815, 0, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index12']}', 'source/plugin/xigua_es/static/img/t6.png', '', '', 1629950815, 0, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index13']}', 'source/plugin/xigua_es/static/img/t7.png', '', '', 1629950815, 0, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index14']}', 'source/plugin/xigua_es/static/img/t8.png', '', '', 1629950815, 0, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index15']}', 'source/plugin/xigua_es/static/img/t9.png', '', '', 1629950815, 0, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0),
(NULL, 999, '{$installlang['index16']}', 'source/plugin/xigua_es/static/img/t10.png', '', '', 1629950815, 0, '', '0.00', '', '', 0, '', '', '', 1, '', '', '0.00', '0.00', '', '', '', '', '', '', 0, 0, '0.00', 0, '', '', 30, 0, 0, '', 10, 0, 0, 0, '', '', 0, 1, 0);
SQL;
    runquery($sql);
}


$r3 = DB::fetch_first('SELECT * FROM %t WHERE pluginid=999 LIMIT 1', array('xigua_hb_var'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_hb_var` (`pluginvarid`, `pluginid`, `displayorder`, `title`, `description`, `type`, `value`, `extra`, `unitnew`, `required`, `unchangeable`, `formsearch`, `placehd`, `autohide`, `autoin`, `needpay`, `maxlen`, `jiaoyi`) VALUES
(NULL, 999, 0, '{$installlang['var1']}', '', 'text', '', '', '', 0, 0, 0, '', 0, 1, '0.00', 0, 0),
(NULL, 999, 12, '{$installlang['var2']}', '', 'number', '', '', '{$installlang['var9']}', 0, 0, 0, '{$installlang['var10']}', 0, 0, '0.00', 0, 1),
(NULL, 999, 14, '{$installlang['var3']}', '', 'number', '', '', '{$installlang['var9']}', 0, 0, 0, '', 0, 0, '0.00', 0, 2),
(NULL, 999, 25, '{$installlang['var4']}', '', 'number', '', '', '{$installlang['var9']}', 0, 0, 0, '{$installlang['var11']}', 0, 0, '0.00', 0, 3),
(NULL, 999, 26, '{$installlang['var5']}', '', 'select', '', '{$installlang['var13']}', '', 0, 0, 0, '', 0, 0, '0.00', 0, 0),
(NULL, 999, 15, '{$installlang['var6']}', '', 'number', '', '', '', 0, 0, 0, '{$installlang['var12']}', 0, 0, '0.00', 0, 4),
(NULL, 999, 26, '{$installlang['var7']}', '', 'select', '', '{$installlang['var14']}', '', 0, 0, 0, '', 0, 0, '0.00', 0, 5),
(NULL, 999, 33, '{$installlang['var8']}', '', 'location', '', '', '', 0, 0, 0, '', 0, 0, '0.00', 0, 0);
SQL;
    runquery($sql);
}

