<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2020/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function lang_es($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_es', $lang);
    }else{
        return lang('plugin/xigua_es', $lang);
    }
}

function es_parse_set($str){
    global $_G;
    if(!$_G['cache']['es_ext_setting']){
        loadcache('es_ext_setting');
    }
    $arr = array();
    for($i=1;$i<=5;$i++){
        $src = $_G['cache']['es_ext_setting'][$str.'_pic'.$i];
        $href = $_G['cache']['es_ext_setting'][$str.'_link'.$i];
        if($src){
            $arr[] = "<a href='$href'><img src='$src'/></a>";
        }
    }
    return $arr;
}

function fetch_by_esid($esid)
{
    $result = DB::fetch_all(
        "SELECT * FROM %t  WHERE id=$esid ",
        array('xigua_hb_cat' ),
        'id'
    );

    $sub_result = DB::fetch_all(
        "SELECT * FROM %t  WHERE pid in(%n)  ORDER BY o ASC,id ASC ",
        array(
            'xigua_hb_cat',
            array_keys($result),
        ),
        'id'
    );
    return array_merge($result, $sub_result);
}

function replace_youfei($tite, $html){
    $html = trim($html);
    if(!$html || $html == lang_hb('yuan',0)){
        return lang_es('baoyou',0);
    }
    return $tite.' &yen;'.$html;
}

function callback_es_pay($param){
    global $_G;
    $data = $param['info']['data'];
    $pubid = $data['gid'];
    $pubinfo = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid, 0);

    $stock = 0;
    foreach ($pubinfo['vars'] as $index => $var) {
        if($var['jiaoyi']==4){
            if($var['value']!==''){
                $stock = $var['value']-1;
                if($stock>=0){
                    $pubinfo['vars'][$index]['html'] = $stock;
                    $pubinfo['vars'][$index]['value'] = $stock;
                }
            }else{
                $pubinfo['vars'][$index]['html'] = 0;
                $pubinfo['vars'][$index]['value'] = 0;
            }
        }
    }
    $uppub = array();
    $uppub['vars'] = serialize($pubinfo['vars']);
    if($stock<=0){
        $uppub['wancheng'] = 1;
    }
    C::t('#xigua_hb#xigua_hb_pub')->update($pubid, $uppub);

    $sec = array('status' => 2, 'pay_ts' => TIMESTAMP, );
    C::t('#xigua_es#xigua_es_order')->update($data['id'], $sec);

    $usr = getuserbyuid($data['uid']);
    notification_add($data['uid'],'system', "<a href=\"{url}\">".lang('plugin/xigua_es', 'gxgmcg').$data['title'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_es&ac=order_profile&ptlog_id='.$data['id']),1);

    notification_add($pubinfo['uid'],'system', "<a href=\"{url}\">".$usr['username'].lang('plugin/xigua_es', 'gggml').$data['title'].lang('plugin/xigua_es', 'jkfh').'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_es&ac=order_profile&manage=1&ptlog_id='.$data['id']),1);
    return true;
}

function total_es_pubs($lists){
    global $_G, $config, $esid;
    $whe1 = '';
    if($lists){
        $keys = array_keys($lists[$esid]['child']);
        $keys[] = $esid;
        $whe1 = ' AND catid IN(' . implode(',', array_filter($keys)) . ') ';
    }
    $whe = 1;
    $st = intval($_GET['st']);
    if($_G['cache']['plugin']['xigua_st']){
        if($st){
            if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                $whe = " (stid=$st OR FIND_IN_SET($st ,pubstida)) ";
            }
        }else{
            if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                $whe = " (stid=$st OR FIND_IN_SET($st ,pubstida)) ";
            }
        }
    }

    $key = 'es_pubs_'.$config['cachettl'].'_'.$st;
    loadcache($key);
    if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
        $return = DB::result_first('SELECT COUNT(*) FROM %t WHERE '.$whe.$whe1, array('xigua_hb_pub'));
        savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
    } else {
        $return = $_G['cache'][$key]['variable'];
    }
    return $config['cuspub'] + $return;
}

function total_es_views($lists){
    global $_G, $config, $esid;
    $whe1 = '';
    if($lists){
        $keys = array_keys($lists[$esid]['child']);
        $keys[] = $esid;
        $whe1 = ' AND catid IN(' . implode(',', array_filter($keys)) . ') ';
    }
    $whe = ' 1 ';
    $st = intval($_GET['st']);
    if($_G['cache']['plugin']['xigua_st']){
        if($st){
            if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                $whe = " (stid=$st OR FIND_IN_SET($st ,pubstida)) ";
            }
        }else{
            if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                $whe = " (stid=$st OR FIND_IN_SET($st ,pubstida)) ";
            }
        }
    }

    $key = 'es_views_'.$config['cachettl'].'_'.$st;
    loadcache($key);
    if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
        $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe.$whe1, array('xigua_hb_pub'));
        savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
    } else {
        $return = $_G['cache'][$key]['variable'];
    }
    return $config['cusview']+$return;
}

function total_es_order(){
    global $_G, $config, $esid;

    $key = 'es_order_'.$config['cachettl'];
    loadcache($key);
    if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
        $return = DB::result_first('SELECT count(*) FROM %t WHERE status in(2,6)', array('xigua_es_order'));
        savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
    } else {
        $return = $_G['cache'][$key]['variable'];
    }
    return $return;
}