<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $es_tabbar}-->
<!--{eval
$custom_nav = C::t('#xigua_es#xigua_es_nav')->fetch_index();
$navcount = count($custom_nav);
$is_off = 1;
$curturl = hb_currenturl();
}-->
<div class="weui-tabbar<!--{if $showfloatapp}--> none<!--{/if}-->">
    <!--{loop $custom_nav $loop_k $loopin}--><!--{eval
$highlight = '&high='.$loop_k;
if($loopin['adlink']=='pub'):
    $inlink = 'javascript:;" class="pubes weui-tabbar__item weui-bar__item_on showpubfont" id="pubes';
else:
    $inlink = $loopin['adlink'].$highlight;
endif;
$is_on = !$is_on && (  strpos($curturl,$inlink)!==false || strpos($curturl,$highlight)!==false  || ($_GET['high'] && $_GET['high']==$loop_k)  );
if($is_on):
    $loopin[icon] = $loopin[icon2]?$loopin[icon2]:$loopin[icon];
endif;
}-->
<!--{if $loopin[up]}-->
<a href="{$inlink}" class="weui-tabbar__item weui-bar__item_on showpubfont"><div class="pub_circle"></div>
    <!--{if $loopin[icon2]}-->
    <img src="$loopin[icon2]" class="tabcon" />
    <!--{/if}-->
    <p class="weui-tabbar__label pub_circle_p" style="color:#777!important">{$loopin[name]}</p>
</a>
<!--{else}-->
<a href="{$inlink}" class="weui-tabbar__item <!--{if $is_on}-->weui-bar__item_on<!--{/if}-->">
    <!--{if $loopin[icon]}-->
    <img src="$loopin[icon]" class="tabcon3" />
    <!--{/if}-->
    <p class="weui-tabbar__label">{$loopin[name]}</p>
<!--{if strpos($inlink, 'type=sx')!==false}--><!--{if $newpm || $newpm = C::t('#xigua_hb#xigua_hb_comment')->fetch_type1_num()}-->
    <span class="weui-badge weui-badge_dot dot_pm">$newpm</span><!--{/if}-->
<!--{/if}-->
</a>
<!--{/if}-->
<!--{/loop}-->
</div>
<!--{/if}-->