<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_es:header}-->
<div class="page__bd">

    <!--{template xigua_hb:common_nav}-->
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->
</div>


<script>
    var loadingurl = window.location.href+'&id=xigua_es&ac=list_item&zuji=1&inajax=1&pagesize=20&page=';
    scrollto = 1;
</script>
<!--{eval $es_tabbar=1;$tabbar=0;}-->
<!--{template xigua_es:footer}-->