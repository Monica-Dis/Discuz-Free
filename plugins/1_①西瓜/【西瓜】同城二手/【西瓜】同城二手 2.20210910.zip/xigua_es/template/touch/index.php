<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_es:header}-->
<!--{if $topnavslider}--><style>.x_header_fix{height:0}.x_header {background: transparent!important;position: absolute;}.navtitle{display: none!important}</style>
<!--{else}--><style>.x_header_fix{height:0}.x_header {position:relative}.navtitle{display: none!important}.flnav.tl{top: 0;box-shadow: none;
padding-left: 0;width: 100%;margin-left: 0;}</style><!--{/if}-->
<!--{if $_G['cache']['es_ext_setting']['share_icon']}--><div class="no"><img src="$_G['cache']['es_ext_setting']['share_icon']" /></div><!--{/if}-->
<div class="page__bd">
    <header class="x_header bgcolor_11 cl  weui-flex f15">
        <!--{if $_G['cache']['plugin']['xigua_st']['showfz'] && $es_config[openst]}-->
        <a class="z x_logo" href="javascript:;" onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_es{$urlext}&mobile=2");}{$urlext}'">
            <span class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
        </a>
        <!--{else}-->
        <a class="z x_logo" href="$SCRITPTNAME?id=xigua_es$urlext">
            <!--{if strpos($_G['cache']['es_ext_setting']['logoindex'],'/')!==false}--><img src="{$_G['cache']['es_ext_setting']['logoindex']}" />
            <!--{else}--><span style="margin:0 .75rem">{$_G['cache']['es_ext_setting']['logoindex']}</span><!--{/if}--></a>
        <!--{/if}-->
        <form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
            <input type="hidden" name="id" value="xigua_es"> <input type="hidden" name="ac" value="cat">
            <input type="hidden" name="st" value="$_GET[st]"> <input type="hidden" name="idu" value="$_GET[idu]">
            <input name="keyword" class="x_logo_input" type="text" value="" placeholder="{echo $keyword ? $keyword : $es_config[schtxt]}" x-webkit-speech="" style="background: rgba(255,255,255,.8)">
            <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
        </form>
    </header>
    <!--{if $topnavslider}-->
    <div class="swipe cl bgf">
        <div class="swipe-wrap">
            <!--{loop $topnavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $topnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->
    <div <!--{if $topnavslider}-->style="height:1.1rem;"<!--{/if}--> class="bgf">
        <div class="flnav tl">
            <div class="weui-cell__bd">
                <i class="iconfont icon-hot1 color-red f14"></i>
                <span class="f14">{lang xigua_es:liulan1}: <em class="ml3 main_color">{echo hb_trans($totalviews);}</em></span>
                <span class="ml3 f14">{lang xigua_es:bbs}: <em class="ml3 main_color">{echo hb_trans($totalpub);}</em></span>
                <span class="ml3 f14">{lang xigua_es:cjl}: <em class="ml3 main_color">{echo hb_trans($totalshares);}</em></span>
            </div>
        </div>
    </div>
    <!--{if $jing_list}-->
    <nav class=" nav-list cl swipe" style="<!--{if $topnavslider}-->padding-top:.35rem<!--{/if}-->">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $jing_list $k $n}-->
                    <!--{if $k && $k%$numshow==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li style="width:$widthshow">
                        <a href="{echo $n['adlink'] ? $n['adlink'] : $SCRITPTNAME.'?id=xigua_es&ac=cat&cat_id='.$n['id']}">
                        <span>
                            <img src="$n['icon']" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'"/>
                        </span>
                            <em class="m-piclist-title c3">{$n['name']}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position position1">
                <!--{loop $jing_count $k $v}-->
                <li {if $k==0} class="current" {/if}></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </nav>
    <!--{/if}-->
<!--{eval
$adwhere = array();
$adwhere[] = 'types=\'\'';
$index_list =  C::t('#xigua_es#xigua_es_index')->list_by_where($adwhere);
$newindex_list = array();
if($index_list):
    foreach ($index_list as $index => $item):
        $newindex_list[$item['style']][] = $item;
    endforeach;
endif;
}-->
<!--{if $newindex_list}-->
<div class="cl es_index_top">
<!--{loop $newindex_list $_k $_v}-->
    <!--{if $_k!=99}-->
        <!--{loop $_v $__k $__v}-->
            <div class="es_index_item" style="width:calc({echo 100/$_k;}% - .5rem)"><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
        <!--{/loop}-->
    <!--{/if}-->
<!--{/loop}-->
</div>
<!--{/if}-->
<!--{if $newindex_list[99]}-->
<div class="swipe cl" data-speed="5000">
    <div class="swipe-wrap">
        <!--{loop $newindex_list[99] $__k $__v}-->
        <div><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $newindex_list[99] $__k $__v}-->
            <li <!--{if $__k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{/if}-->
<div class="weui-cells fixbanner border_none">
    <div class="weui-navbar weui-banner nobg fixbanner_in border_none" style="width:auto">
        <a href="javascript:;" class="weui-navbar__item weui_bar__item_on ajaxcat" data-id="{$esid}&id=xigua_es&province=$_GET['province']&city=$_GET['city']&dist=$_GET['dist']">
            <span>{lang xigua_hb:zuixin}</span>
        </a>
        <!--{if $es_config[showfj] && $_G['cache']['plugin']['xigua_hb'][mkey]}-->
        <a href="javascript:;" class="weui-navbar__item" data-id="{$esid}&id=xigua_es" id="near_xinxi">
            <span>{lang xigua_hb:near}</span>
        </a>
        <!--{/if}-->
        <!--{loop $cat_list $cat}-->
        <!--{if !$cat['cat_link'] && $cat[id]}-->
        <a href="javascript:;" class="weui-navbar__item ajaxcat" data-id="$cat[id]&id=xigua_es&province=$_GET['province']&city=$_GET['city']&dist=$_GET['dist']">
            <span>$cat[name]</span>
        </a>
        <!--{/if}-->
        <!--{/loop}-->
    </div>
</div>
<div id="list" class="mod-post x-postlist pt0"></div>
<!--{template xigua_hb:loading}-->
</div>
<!--{eval $es_tabbar=1;$tabbar=0;}-->
<script>
    loadingurl = _APPNAME+'?id=xigua_es&ac=list_item&inajax=1&cat_id=$esid&page=';
</script>
<!--{template xigua_es:footer}-->
<!--{template xigua_es:fujin}-->