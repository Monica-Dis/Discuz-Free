<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_es:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{template xigua_es:order_top}-->
    <!--{if $v['exp_method']=='kuaidi'}-->
    <div class="weui-cells before_none after_none cardbuy" style="margin-top:-1rem">
        <a class="weui-cell weui-cell_access after_none" href="javascript:;" <!--{if $v[status]==1||$v[status]==5}-->id="pay_address"<!--{/if}--> >
        <div class="weui-cell__hd">
            <label class="weui-label" style="width:auto"><i class="iconblack main_bg">{lang xigua_es:shou}</i></label>
        </div>
        <div class="weui-cell__bd c3">
            <div class="f12 "><span class="f14">{$v[realname]}</span>&nbsp;{$v[mobile]}</div>
            <div class="f12 mt3">{$v[addr]}</div>
        </div>
        <!--{if $v[status]==1||$v[status]==5}--><div class="weui-cell__ft"></div><!--{/if}-->
        <div class="addrbx"></div>
        </a>
    </div>
    <!--{elseif $v['exp_method']=='daodian'}-->
    <div class="weui-cells before_none after_none cardbuy" style="margin-top:-1rem">
        <div style="overflow:hidden; " class="weui-cell " >
            <div class="weui-cell__hd z f15">
                {lang xigua_es:jydd}
            </div>
            <div class="weui-cell__bd"></div>
            <div class="weui-cell__ft" style="max-width: calc(100% - 5rem);float: right;">
                <!--{if $distvar}-->
                <a class="weui-cell before_none p0 loc_o" href="javascript:;" id="hb_openLocation" data-lat="{$distvar[value][1]}" data-lng="{$distvar[value][2]}" data-name="{$distvar[value][0]}" data-addr="{$distvar[value][0]}" style="align-items:normal">
                    <div class="weui-cell__hd loc_oi"></div>
                    <div class="weui-cell__bd loc_if">
                        {$distvar[value][0]}
                    </div>
                </a>
                <!--{else}-->
                <span class="f15">{lang xigua_es:lxmj} <a class="main_color" href="tel:$v[mobile]">$v[mobile]</a></span>
                <!--{/if}-->
            </div>
        </div>
    </div>
    <!--{/if}-->

    <!--{template xigua_es:cardbuy}-->

    <!--{if $v[yundan]&&$es_config[kdcode]}-->
    <div class="wuei-cells cardbuy" id="kdcode"></div>
    <script>
        var s2 = localStorage.getItem('kd{$v[yundan]}');
        var s3 = localStorage.getItem('kd{$v[yundan]}_expire')>{echo time();};
        console.log(localStorage.getItem('kd{$v[yundan]}_expire'));
        if(s2 && s3){
            $('#seckdcode').hide();
            $('#kdcode').html(s2).show();
        }else{
            $.ajax({type: 'get',url: _APPNAME +'?id=xigua_es&ac=com&do=kd&inajax=1&danhao={$v[yundan]}',dataType: 'xml',
                success: function (data) {
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    if(!s){
                        $('#seckdcode').show();
                        $('#kdcode').hide();
                    }else{
                        $('#seckdcode').hide();
                        $('#kdcode').html(s).show();
                        localStorage.setItem('kd{$v[yundan]}', s);
                        localStorage.setItem('kd{$v[yundan]}_expire', '{echo time()+$es_config[kdcache];}');
                    }
                }
            });
        }
    </script>
    <!--{/if}-->
    <div class="weui-cells before_none after_none cardbuy">
        <!--{if $_GET['manage']}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">{lang xigua_es:buyer}  : </div>
            <div class="weui-cell__bd f14">
                <img src="{avatar($v[uid], middle, true)}" class="pt_usr od_user" > $v['realname']
            </div>
            <div class="weui-cell__ft">
                <a href="$kflnkbuy" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default  mt0">{lang xigua_hb:sixin}</a>
            </div>
        </div>
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">{lang xigua_hb:bind_mobile} : </div>
<!--{eval
$mobile = $v['mobile'];
if(!$mobile):
    $__profile = C::t('common_member_profile')->fetch($v['uid']);
    $mobile = $__profile['mobile'];
endif;
}-->
            <div class="weui-cell__bd f14"> {$mobile}
            </div>
            <div class="weui-cell__ft">
                <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default mt0" href="tel:{$mobile}">{lang xigua_hb:tel}</a>
            </div>
        </div>
        <!--{else}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">{lang xigua_es:seller} : </div>
            <div class="weui-cell__bd f14">
                <img src="{avatar($showseller[uid], middle, true)}" class="pt_usr od_user" > $showseller[realname]
            </div>
            <div class="weui-cell__ft">
                <a href="$kflnksell" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default mt0">{lang xigua_hb:sixin}</a>
            </div>
        </div>
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">{lang xigua_hb:bind_mobile} : </div>
            <div class="weui-cell__bd f14"> {$showseller['mobile']}</div>
            <div class="weui-cell__ft">
                <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default mt0" href="tel:{$showseller['mobile']}">{lang xigua_hb:tel}</a>
            </div>
        </div>
        <!--{/if}-->

        <!--{if $v['note']}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_es:bz} : </div>
            <div class="weui-cell__bd f14">
                $v['note']
            </div>
        </div>
        <!--{/if}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_es:ddbh} : </div>
            <div class="weui-cell__bd f14">
                $v['order_id']
            </div>
        </div>
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_es:xdsj} : </div>
            <div class="weui-cell__bd f14">
                $v['crts_u']
            </div>
        </div>
        <!--{if $v['pay_ts_u'] && $v[exp_method]!='hdfk'}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_es:zfsj_} : </div>
            <div class="weui-cell__bd f14">
                $v['pay_ts_u']
            </div>
        </div>
        <!--{/if}-->
        <!--{if $v['tuicfm_ts_u']}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                <!--{if $v[pay_ts]>0}-->{lang xigua_es:tksj}
                <!--{else}-->{lang xigua_es:qxdd}
                <!--{/if}-->
                : </div>
            <div class="weui-cell__bd f14">
                $v['tuicfm_ts_u']
            </div>
        </div>
        <!--{/if}-->
    </div>
</div>
<!--{eval $es_tabbar=1;$tabbar=0;}-->
<!--{template xigua_es:footer}-->
<script>
<!--{if $distvar}-->
$(document).on('click', '#hb_openLocation', function () {
    var that = $(this);
    if(('{HB_INWECHAT}' && "{$_G['cache']['plugin']['xigua_hb'][multiupload]}")==1){
        wx.openLocation({
            latitude: that.data('lat'),
            longitude: that.data('lng'),
            name: that.data('name'),
            address: that.data('addr'),
            scale: 14,
            infoUrl:window.location.href
        });
    }else if("{$_G['cache']['plugin']['xigua_hs']['google']}"){
        window.location.href = _APPNAME+'?id=xigua_hs&ac=googleMap&lat='+that.data('lat')+"&lng="+that.data('lng')+_URLEXT;
    }else{
        window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:"+that.data('lat')+","+that.data('lng')+";title:"+that.data('name')+";addr:"+that.data('addr');
    }
    return false;
});
<!--{/if}--></script>