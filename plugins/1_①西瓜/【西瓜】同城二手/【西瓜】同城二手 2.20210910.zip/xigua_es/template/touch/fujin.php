<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{if $es_config[showfj] && $_G['cache']['plugin']['xigua_hb'][mkey]}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hb'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script>
    $(document).on('click','#near_xinxi', function () {
        var that = $(this);
        var href= that.data('href');
        hb_getlocation(function (position) {
            var lat=(position.latitude||position.lat), lng=(position.longitude||position.lng);
            page = 1;
            loadingurl = _APPNAME+'?id=xigua_es&ac=list_item&inajax=1&cat_id='+that.data('id')+ '&lat='+lat+'&lng='+lng+'&page=';
            that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
            DOAPPEND = 0;
            $.ajax({
                type: 'get',
                url: loadingurl+''+page,
                dataType: 'xml',
                success: function (data) {
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    $('#loading-show').addClass('hidden');
                    if(!s){
                        $('#loading-show').addClass('hidden');
                        $('#loading-none').removeClass('hidden');
                        setTimeout(function () {
                            $('#loading-show').addClass('hidden');
                            $('#loading-none').removeClass('hidden');
                        }, 300);
                        $("#list").html(s);
                        page = -1;
                        return ;
                    }
                    $("#list").html(s);
                    page ++;
                    hb_incr(s);
                },
                error: function() {
                }
            });
        });
    });
    $(document).on('click', '#near_xinxi2', function () {
        var that = $(this);
        var href = that.data('href');
        hb_getlocation(function (position) {
            var lat = (position.latitude || position.lat), lng = (position.longitude || position.lng);
            window.location.href = href + '&lat=' + lat + '&lng=' + lng;
        });
    });
    function hb_getlocation(callback) {
        var HB_INWECHAT = '{HB_INWECHAT}';
        if (1 && typeof mag != 'undefined') {
            mag.getLocation(function (res) {
                callback(res);
            });
        } else if (typeof sq != 'undefined') {
            sq.getLocation(function (res) {
                callback(res);
            });
        } else if (typeof QFH5 != 'undefined') {
            QFH5.getLocation(function (state, data) {
                if (state == 1) {
                    callback(data);
                } else {
                    alert(data.error);
                }
            });
        } else if ((HB_INWECHAT && HB_MULTIUPLOAD) == 1) {
            wx.getLocation({
                type: 'gcj02', success: function (res) {
                    callback(res);
                }, cancel: function (res) {
                }
            });
        } else {
            var geolocation = new qq.maps.Geolocation(mkey, "myapp");
            geolocation.getLocation(callback, function () {
            }, {timeout: 4000, failTipFlag: true});
        }
    }
</script>
<!--{/if}-->