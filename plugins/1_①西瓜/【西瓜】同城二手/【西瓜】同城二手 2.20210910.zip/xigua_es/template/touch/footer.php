<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<div id="pub_ctrl" class='weui-popup__container popup-bottom z501'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <h1 class="title">{lang xigua_es:xzqghcs}</h1>
            </div>
        </div>
        <div class="modal-content pubes_ctrl">
            <div class="weui-cells border_none">
                <a href="$SCRITPTNAME?id=xigua_es&ac=add{$urlext}" class="weui-cell before_none">
                    <div class="weui-cell__bd">
                        <p class="pubes_tit">{lang xigua_es:wyaom}</p>
                        <p class="f13">{lang xigua_es:wyaom_tip}</p>
                        <img src="source/plugin/xigua_es/static/img/l2.png?12">
                    </div>
                </a>
                <!--{if $es_config[qiuid]}-->
                <a href="$SCRITPTNAME?id=xigua_hb&ac=pub&step=3&catid={$es_config[qiuid]}{$urlext}" class="weui-cell before_none">
                    <div class="weui-cell__bd">
                        <p class="pubes_tit">{lang xigua_es:wyaom3}</p>
                        <p class="f13">{lang xigua_es:wyaom3_tip}</p>
                        <img src="source/plugin/xigua_es/static/img/l1.png?12">
                    </div>
                </a>
                <!--{/if}-->
                <a href="javascript:;" class="picker-button close-popup iclose"><i class="iconfont icon-guanbijiantou c9 f24"></i></a>
            </div>
        </div>
    </div>
</div>
<!--{template xigua_es:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script src="source/plugin/xigua_es/static/js/es.js?2{VERHASH}"></script>
<!--{if $es_config['autoconfirm'] && $_G['uid']}--><script>$.ajax({type: 'get',url: _APPNAME + '?id=xigua_es&ac=com&do=shouhuo&autoconfirm=1',dataType: 'xml',success: function (data) {},});</script><!--{/if}-->