<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<div class="site_header">
    <form method="get" action="$SCRITPTNAME" id="dosearchform">
        <input name="id" value="xigua_es" type="hidden">
        <input name="ac" value="cat" type="hidden">
        <input type="hidden" name="st" value="$_GET[st]">
        <input type="hidden" name="idu" value="$_GET[idu]">
        <input type="hidden" name="shid" value="$_GET[shid]">
    <header class="x_header cl f15">
        <!--{if !IN_PROG && !$hide_nav}-->
        <a class="z " href="javascript:window.history.go(-1);" style="color:#333;"><i class="iconfont icon-fanhuijiantou w15"></i></a>
        <!--{/if}-->
        <a href="javascript:" class="search_bar_btn main_color" id="dosearch">{lang xigua_hb:sousuo}</a>
        <div class="navtitle pr" <!--{if IN_PROG || $hide_nav}-->style="margin-left:.75rem;width:calc(100% - 3.7rem)"<!--{/if}-->>
            <a class="new_search" href="javascript:;">{echo $keyword ? $keyword : $es_config[schtxt]}</a>
            <input type="search" class="serchinput" id="searchInput" placeholder="{$es_config[schtxt]}" required="required" name="keyword" value="$keyword">
        </div>
    </header>

</form>

</div>