<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_es:header}-->
<div class="page__bd ">
    <!--{if $config[pubtip]}--><div class="weui-cells__title">$config[pubtip]</div><!--{/if}-->
    <div class="weui-cells__title">{lang xigua_hb:xuanlei}</div>
    <div class="weui-grids bgf weui-grids-nob">
        <!--{loop $list $cat}-->
        <a class="weui-grid js_grid" <!--{if $config['numi2']!=4&&$config['numi2']>0}--> {eval echo "style='width:".(100/$config['numi2'])."%!important'";}<!--{/if}--> <!--{if  !$cat[cat_link]}-->href="$SCRITPTNAME?id=xigua_hb&ac=pub&step=3&catid={$cat[id]}"<!--{else}-->href="$cat[cat_link]"<!--{/if}-->>
            <div class="weui-grid__icon"><img src="$cat[icon]" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'"></div>
            <p class="weui-grid__label">$cat[name]</p>
        </a>
        <!--{/loop}-->
    </div>
</div>
<!--{eval $es_tabbar=1;$tabbar=0;}-->
<!--{template xigua_es:footer}-->