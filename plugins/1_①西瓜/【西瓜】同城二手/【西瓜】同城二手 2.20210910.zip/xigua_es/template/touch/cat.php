<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_es:header}-->
<div class="page__bd">
    <!--{if $catinfo['share_pic']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$catinfo['share_pic']" /></div><!--{/if}-->
    <!--{if IN_MAGAPP}--><style>.nav_expand_panel{position:absolute;}.nav_expand_panel .weui-flex__item{height:auto;overflow:hidden!important;}</style><!--{/if}-->

    <!--{template xigua_es:search_bar}-->
    <div class="weui-cells fixbanner before_none mt0 fixbanner2">
        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="$SCRITPTNAME?id=xigua_es&ac=cat&mobile=2" class="weui-navbar__item <!--{if !$_GET['cat_id']}-->weui_bar__item_on<!--{/if}-->">
                <span>{lang xigua_es:tj}</span>
            </a>
            <!--{loop $cat_tree[0]['child'] $cat}-->
            <a href="$SCRITPTNAME?id=xigua_es&ac=cat&cat_id={$cat[id]}" class="weui-navbar__item <!--{if $cat[id]==$_GET['cat_id']}-->weui_bar__item_on<!--{/if}-->">
                <span>$cat[name]</span>
            </a>
            <!--{/loop}-->
        </div>
    </div>
    <div class="weui-navbar fix_float border_none" style="z-index:501;position:relative;top:0">
        <a data-id="3" class="dist_nav weui-navbar__item"  style="padding-left: .3rem;">
            <span>$orderby_list[$orderby]<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <a data-id="5" id="dist_nav_5" class="dist_nav weui-navbar__item">
            <span>$highprice<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <a data-id="1" class="dist_nav weui-navbar__item">
            <span>$distname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{if $filtervars}-->
        <a data-id="6" class="dist_nav weui-navbar__item <!--{if $filter}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hb:sxx}<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{/if}-->
    </div>
    <div class="dist_show">
        <div id="dist_show_1" class="nav_expand_panel border_top">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="first_check border_bfull <!--{if !$_GET[province]}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province=&city=&orderby=$orderby&keyword={echo urlencode($keyword);}&lat=$lat&lng=$lng&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $dist0 $v}-->
                        <li class="first_check border_bfull <!--{if $_GET[province]==$v[name]}-->checked main_color<!--{eval $city_id=$v['id'];}--><!--{/if}-->" data-id="$v[id]" data-link="{$v[link]}"><a>$v[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="weui-flex__item checked">
                    <!--{loop $dist0 $k $v}-->
                    <ul class="sub_cheker <!--{if $_GET[province]!=$v['name']}-->none<!--{else}-->checked<!--{/if}-->" id="sub_cheker_$v[id]">
                        <li class="sub_check border_bfull"><a data-href="$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province={echo urlencode($v[name]);}&city=&orderby=$orderby&keyword={echo urlencode($keyword);}&lat=$lat&lng=$lng&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}{$urlext}" class="choose color-red">{lang xigua_hb:quan}{$v[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a></li>
                        <!--{loop $v[child] $vv}-->
                        <li class="sub_check border_bfull <!--{if $city==$vv[name]&&$_GET[city]}-->checked main_color autotrigger<!--{/if}-->"><a data-href="$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province={echo urlencode($v[name]);}&city={echo urlencode($vv[name]);}&orderby=$orderby&keyword={echo urlencode($keyword);}&lat=$lat&lng=$lng&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}{$urlext}" id="sub_check{$vv[id]}" data-id="$vv[id]" onclick="hs_getnext($vv[id], '{$vv[name]}','$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&orderby=$orderby&keyword={echo urlencode($keyword);}&lat=$lat&lng=$lng&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}{$urlext}','{$vv[link]}')">$vv[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                    <!--{/loop}-->
                </div>
                <div class="weui-flex__item checked" id="ajaxbox"> <ul class="ajaxbox_cheker"></ul> </div>
            </div>
        </div>
        <div id="dist_show_3" class="nav_expand_panel border_top">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="<!--{if !$orderby && !$_GET[hb]}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}{$urlext}">$orderby_list['']</a></li>
                        <li class="<!--{if $orderby=='price_desc'}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=price_desc&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}{$urlext}">$orderby_list[price_desc]</a></li>
                        <li class="<!--{if $orderby=='price_asc'}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=price_asc&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}{$urlext}">$orderby_list[price_asc]</a></li>
                        <li class="<!--{if $orderby=='new'}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=new&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}{$urlext}">$orderby_list[new]</a></li>
                        <!--{if $es_config[showfj]}-->
                        <li class="<!--{if $orderby=='near'}-->checked main_color<!--{/if}-->"><a id="near_xinxi2" data-href="$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=near&keyword={echo urlencode($keyword);}&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}{$urlext}">{lang xigua_hb:near}</a></li>
                        <!--{/if}-->
                    </ul>
                </div>
            </div>
        </div>
        <!--{if $filtervars}-->
        <div id="dist_show_6" class="nav_expand_panel border_top filtervars">
            <!--{loop $filtervars $_k $_v}-->
            <!--{eval $extra = trim($_v[extra]);}-->
            <div class="weui-cells__title c3 listTc">{echo $_v[title]?$_v[title]:$_v[bc][title]}</div>
            <div class="weui-cells before_none after_15">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <!--{if $_v[data]}--><div class="main_color cat_m" data-title="{$_k}" id="cat_tit_{$_k}" style="display:none"><span>{lang xigua_hb:yx}</span><span id="cat_tit_in_{$_k}"></span><span>X</span></div><!--{/if}-->
                        <div class="post-tags cl gray-tags post-tags3">
                            <!--{if $extra}-->
                            <!--{eval $extra = explode("\n", $extra);}-->
                            <!--{loop $extra $__k $extra_string}-->
                            <!--{eval list($tmp1, $tmp2) = explode('=', trim($extra_string));}-->
                            <!--{if $_v['type']=='select' && !$tmp1}--><!--{eval continue;}--><!--{/if}-->
                            <!--{if $_v['type']=='mselects' && strpos($tmp1,'.')===false}--><div style="width:100%" class="c9 f13 mb8 z">{$tmp2}</div><!--{eval continue;}--><!--{/if}-->
                            <a class="tags3a <!--{if $_filter[$_k]==$tmp1}-->tag-on<!--{/if}-->" data-title="{$_k}" data-value="$tmp1" href="javascript:;" <!--{if $_v['type']=='selects'||$_v['type']=='mselects'}-->data-multi="1"<!--{/if}-->>$tmp2</a>
                            <!--{/loop}-->
                            <!--{elseif $_v[data]}-->
                            <!--{loop $_v[data] $sub0}-->
                            <a class="tags3a <!--{if $_filter[$_k]==$sub0[index]}-->tag-on<!--{/if}--> level_1_{$_k}" data-lv="$sub0[index]" data-title="{$_k}" data-value="$sub0[index]" href="javascript:;">$sub0[name]</a>
                            <!--{if $sub0[sub]}--><!--{loop $sub0[sub] $sub1}-->
                            <a style="display:none" class="tags3a <!--{if $_filter[$_k]==$sub1[index]}-->tag-on<!--{/if}--> level_2_{$_k}"  data-lv="$sub1[index]" data-title="{$_k}" data-value="$sub1[index]" href="javascript:;">$sub1[name]</a>
                            <!--{if $sub1[sub]}--><!--{loop $sub1[sub] $sub2}-->
                            <a style="display:none" class="tags3a <!--{if $_filter[$_k]==$sub2[index]}-->tag-on<!--{/if}--> level_3_{$_k}"  data-lv="$sub2[index]" data-title="{$_k}" data-value="$sub2[index]" href="javascript:;">$sub2[name]</a>
                            <!--{/loop}--><!--{/if}-->
                            <!--{/loop}--><!--{/if}-->
                            <!--{/loop}-->
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
            <!--{/loop}-->
            <div class="weui-flex btns3a">
                <input type="button" class="weui-btn weui-btn_default " value="{lang xigua_es:close}" onclick="$('.dist_nav:last-child').trigger('click');" />
                <input type="button" id="filtervar_clear" class="weui-btn weui-btn_default " value="{lang xigua_es:reset}" />
                <input type="button" id="filtervar_btn" class="weui-btn weui-btn_default  main_color" value="{lang xigua_hb:queding}" />
            </div>
        </div>
        <!--{/if}-->
        <div id="dist_show_5" class="nav_expand_panel border_top price_range">
            <div class="weui-cells__title c3 listTc">{lang xigua_es:jgfw}</div>
            <div class="weui-cells before_none after_15">
                <div class="weui-cell price-box mr-5">
                    <span class="taginput"><input type="tel" id="min_price" name="min_price" placeholder="{lang xigua_es:zuidi}" value="<!--{if $showhighprice==2}-->$minhprice<!--{/if}-->" ></span>
                    <em class="line">-</em>
                    <span class="taginput"><input type="tel" id="max_price" name="max_price" placeholder="{lang xigua_es:zuigao}" value="<!--{if $showhighprice==2}-->$maxhprice<!--{/if}-->" ></span>
                </div>
                <div class="weui-cell border_none pt0">
                    <div class="weui-cell__bd">
                        <div class="post-tags cl gray-tags post-tags3">
                            <!--{loop $pricerange $_k $_v}--><!--data-multi 1-->
                            <a class="tags3a <!--{if $showhighprice==1 && in_array('0_'.$_v, $_prange_keys)}-->tag-on<!--{/if}-->"  data-min="0" data-max="$_v" href="javascript:;">{$_v}{lang xigua_es:yuanyixia}</a>
                            <!--{/loop}-->
                        </div>
                    </div>
                </div>
            </div>
            <div class="weui-flex btns3a">
                <input type="button" class="weui-btn weui-btn_default " value="{lang xigua_es:close}" onclick="$('#dist_nav_5').trigger('click');" />
                <input type="button" id="filterprice_clear" class="weui-btn weui-btn_default " value="{lang xigua_es:reset}" />
                <input type="button" id="filterprice" class="weui-btn weui-btn_default  main_color" value="{lang xigua_hb:queding}" />
            </div>
        </div>
    </div>

    <!--{if $tag_childs}-->
    <div class="banner_fix cl">
        <div class="banner">
            <nav class="weui-flex tag_list">
                <a href="$SCRITPTNAME?id=xigua_es&ac=cat&$query" class="pstyle2 <!--{if !$_GET[tag]}-->pstyle2on main_bg<!--{/if}-->">{lang xigua_hb:buxian}</a>
                <!--{loop $tag_childs $_kk $tag_child}-->
                <!--{eval $tag_child = trim($tag_child);}-->
                <a href="$SCRITPTNAME?id=xigua_es&ac=cat&$query&tag={echo urlencode($tag_child);}" class="pstyle2 <!--{if $tag_child==$_GET[tag]}-->pstyle2on main_bg<!--{/if}-->">$tag_child</a>
                <!--{/loop}-->
            </nav>
        </div>
    </div>
    <!--{/if}-->

    <!--{if $catinfo['adimage']}-->
    <div class="">
        <a href="{eval echo $catinfo['adlink'] ? $catinfo['adlink'] : $SCRITPTNAME.'?id=xigua_es&ac=cat&cat_id='.$cat_id}"><img src="$catinfo['adimage']" class="block" /></a>
    </div>
    <!--{/if}-->
    <!--{if $catinfo['customad']}-->{echo htmlspecialchars_decode($catinfo['customad'])}<!--{/if}-->

    <!--{if $_GET[showmap] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/template/touch/map.php')}-->
    <!--{eval $mapjs=1;}-->
    <!--{template xigua_hb:map}-->
    <!--{else}-->
    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->
    <!--{/if}-->
</div>

<div id="srh_popup" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <form  action="$SCRITPTNAME" method="get" id="searchForm">
                <input type="hidden" name="id" value="xigua_hb">
                <input type="hidden" name="ac" value="cat">
                <!--                <input type="hidden" name="cat_id" value="$_GET[cat_id]">-->
                <input type="hidden" name="st" value="$_GET[st]">
                <input type="hidden" name="idu" value="$_GET[idu]">
                <div class="weui-cells weui-cells_form"  id="searchBar">

                    <div class="weui-cell weui-cell_vcode">
                        <div class="weui-cell__hd">
                            <label class="weui-label" style="width:auto"><i class="c9 iconfont icon-sousuo vm"></i></label>
                        </div>
                        <div class="weui-cell__bd">
                            <input type="search" class="weui-input" id="searchInput" placeholder="$config[sousuoinput]" required="required" name="keyword" <!--{if $keyword}-->data-value="$keyword"<!--{/if}-->>
                        </div>
                        <div class="weui-cell__ft">
                            <button class="weui-vcode-btn" type="submit">{lang xigua_hb:sousuo}</button>
                        </div>
                    </div>
                </div>
            </form>

            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_default close-popup" >{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>

<!--{if 0 && $catinfo[name]}-->
<a href="javascript:;" data-id="$cat_id" id="guanzhu" style="position:fixed;bottom:3rem;left:.75rem;background: rgba(0,0,0,.4);padding:0 .25rem;color:#fff;border-radius:.5rem;text-align:center;z-index:498;font-size:.7rem">{lang xigua_hb:xtxxw}</a>
<script>$(document).on('click','#guanzhu', function () {
        var that = $(this);
        $.prompt({
            title: '{lang xigua_hb:qrtx}{$catinfo[name]}',
            input: '{lang xigua_hb:qrtx1}{$catinfo[name]}{lang xigua_hb:qrtx2}',
            empty: false,
            onOK: function (input) {
                $.ajax({
                    type: 'post',
                    url: _APPNAME+'?id=xigua_hb&ac=myaddr&do=inx&inajax=1',
                    data: {'formhash':'{FORMHASH}', 'input':input,'cat_id' : that.data('id'),'catname':'$catinfo[name]'},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if (null == data) {
                            tip_common('error|' + ERROR_TIP);
                            return false;
                        }
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {$.hideLoading();formlocknew = 0;}
                });
            },
            onCancel: function () {}
        });
    });</script><!--{/if}-->
<script>
    var loadingurl = window.location.href+'&id=xigua_es&ac=list_item&inajax=1&pagesize=20&page=';
    scrollto = 1;
    function hs_getnext(id, name, datahref, datalink){
        if(datalink){
            hb_jump(datalink);
            return false
        }
        $('.sub_check a').removeClass('checked').removeClass('main_color');
        $('.sub_check a').parent().removeClass('checked').removeClass('main_color');
        $('#sub_check'+id).addClass('checked').addClass('main_color');
        $.ajax({
            type: 'get',
            url: _APPNAME + '?id=xigua_hb&province='+encodeURIComponent($('.first_check+.checked').find('a').text())+'&name='+encodeURIComponent(name)+'&ctid='+id+'&datahref='+encodeURIComponent(datahref)+'&inajax=1',
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $('.ajaxbox_cheker').html(s);
            }
        });
    }
    $(document).on('click','.choose', function () {
        if($(this).data('link')){
            hb_jump($(this).data('link'));
            return false
        }
        var that = $(this), c_jmpurl = '';
        if(that.data('href')){ c_jmpurl = that.data('href'); }
        if(that.data('ctid')){ c_jmpurl = $('#sub_check'+that.data('ctid')).data('href'); }
        window.location.href= c_jmpurl;
    });
    $(document).on('click','.dist_check', function () {$('.dist_check').removeClass('checked').removeClass('main_color'); $(this).addClass('checked').addClass('main_color');});
    $(document).on('click','.dist_nav', function () {if($('.autotrigger').length>0){$('.autotrigger').find('a').trigger('click');}});
    $(document).on('click','.first_check', function () {
        if($(this).data('link')){
            hb_jump($(this).data('link'));
            return false
        }
        $('.ajaxbox_cheker').html('');
    });
    $(document).on('click','.gray-tags a', function () {
        var that = $(this), lv=that.data('lv'), dt=that.data('title'), dv=that.data('value');
        if(lv){
            $('#cat_tit_in_'+dt).append('<a style="margin-right:5px" class="tag-on" data-title="'+dt+'" data-value="'+dv+'">'+that.html()+'</a>')
            $('#cat_tit_'+dt).show();

            that.hide();
            that.siblings().hide();
            that.parent().find('a').each(function () {
                var tt = $(this);
                var ttlv = tt.data('lv')+'';
                if(ttlv.indexOf(lv+'.')===0){
                    if(that.hasClass('level_1_'+dt) && tt.hasClass('level_2_'+dt)){
                        tt.show();
                    }
                    if(that.hasClass('level_2_'+dt) && tt.hasClass('level_3_'+dt)){
                        tt.show();
                    }
                }
            });
        }else{
            if(that.data('multi')){
                if(that.hasClass('tag-on')){
                    that.removeClass('tag-on');
                }else{
                    that.addClass('tag-on');
                }
            }else{
                that.siblings().removeClass('tag-on');
                that.addClass('tag-on');
            }
        }
    });
    $(document).on('click','.cat_m', function () {
        var that = $(this), dt=that.data('title');
        $('#cat_tit_in_'+dt).html('');
        $('#cat_tit_'+dt).hide();
        $('.level_1_'+dt).show();
        $('.level_2_'+dt).hide();
        $('.level_3_'+dt).hide();
    });
    $(document).on('click','#filtervar_btn', function () {
        var res = '';
        $('.filtervars a.tag-on').each(function () {
            var that = $(this);
            res+= that.data('title')+'_'+that.data('value')+'__';
        });
        hb_jump('$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=$orderby&keyword={echo urlencode($keyword);}&lat=$lat&lng=$lng&prange={echo urlencode($prange);}&filter='+encodeURIComponent(res));
    });
    $(document).on('click','#filtervar_clear', function () {
        $('.filtervars .gray-tags a').removeClass('tag-on');
        $('.cat_m').trigger('click');
        $('#filtervar_btn').trigger('click');
    });
    $(document).on('click','#filterprice', function () {
        var res = '';
        var minval = parseInt($('#min_price').val());
        if(isNaN(minval)){
            minval = 0;
        }
        var maxval = parseInt($('#max_price').val());
        if(isNaN(maxval)){
            maxval = 0;
        }
        res+= minval+'_'+maxval+'__';
        $('.price_range a.tag-on').each(function () {
            var that = $(this);
            res+= that.data('min')+'_'+that.data('max')+'__';
        });
        hb_jump('$SCRITPTNAME?id=xigua_es&ac=cat&cat_id=$cat_id&province={echo urlencode($_GET[province]);}&city={echo urlencode($city);}&dist={echo urlencode($dist);}&orderby=$orderby&keyword={echo urlencode($keyword);}&lat=$lat&lng=$lng&filter={echo urlencode($filter);}&prange={echo urlencode($prange);}&prange='+encodeURIComponent(res));
    });
    $(document).on('click','#filterprice_clear', function () {
        $('.price_range').find('.tags3a').removeClass('tag-on');
        $('.price_range .taginput').find('input').val('');
        $('#filterprice').trigger('click');
    });
</script>
<!--{eval $es_tabbar=1;$tabbar=0;}-->
<!--{template xigua_es:footer}-->
<!--{template xigua_es:fujin}-->
<script>
if($('.fixbanner2').length>0){
    $('.fixbanner2')[0].scrollLeft = $('.fixbanner2').find('.weui_bar__item_on').offset().left-200;
}
if($('.sub_cheker').length===$('.sub_cheker.none').length){$('.sub_cheker:first-child').removeClass('none');}
if($('.banner').length>0){$('.banner')[0].scrollLeft = $('.banner').find('.main_bg').offset().left-200;}
</script>