<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_hb:common_header}--><!--{if $ac=='my'}--><link rel="stylesheet" href="source/plugin/xigua_hb/static/css/mynew.css?{VERHASH}" /><!--{/if}-->
<link rel="stylesheet" href="source/plugin/xigua_es/static/css/es.css?433{VERHASH}" />
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked,.float_btn{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}
.picker-calendar-day.picker-calendar-day-selected span,.in_bottom_y a.nowbuy,.confirm_foot_btn,.kamibtn{background-color:$config[maincolor]!important;}
.tprice{color:$config[maincolor]}
</style><!--{eval $c20 = hb_hex2rgb($config['maincolor'], .2); $c80 = hb_hex2rgb($config['maincolor'], .8); }--><style>
.es_li.flow_bbs_over .es_tag_li, .es_tag_li{color:$config['maincolor'];border:1px solid $c20}
.es_li.flow_bbs_over .flow-bbs-card .img-box span{background-color:$c80;box-shadow:0 .1rem .2rem 0 $c20;}
.post-tags3 a.tags3a.tag-on{background:$c20;color:$config[maincolor];}
.post-tags3 a.tags3a.tag-on:after{border-color:$config[maincolor];}
.footer-bottom, .buy-bottom{display:-webkit-box;display:flex;position:fixed;left:0;bottom:0;padding-left:.5rem;padding-right:.5rem;padding-top:.5rem;padding-bottom:calc(.5rem + constant(safe-area-inset-bottom));padding-bottom:calc(.5rem + env(safe-area-inset-bottom));width:100%;background:#fff;box-sizing:border-box;z-index:499}
.footer-bottom .btns-icon{display:-webkit-box;display:flex;flex:1}
.footer-bottom a,.footer-bottom span{display:inline-block;overflow:hidden;text-overflow:ellipsis;position:relative}
.footer-bottom .item-focus,.footer-bottom .item-loan{padding-top:0;color:#111e36}
.footer-bottom .btns-icon .item-focus,.footer-bottom .btns-icon a{flex:1;text-align:center;height:2rem}
.footer-bottom .btns-icon em{display:block;font-size:.6rem;line-height:1}
.footer-bottom .btns-icon i{line-height: 1;display: block;height: 1.2rem;}
.footer-bottom .item-prize,.footer-bottom .item_clinfo,.item_clinfo{display:block;height:2rem;line-height:2rem;background:linear-gradient(135deg,#f60,red);border-radius:2rem;text-align:center;font-size:.8rem;color:#fff;flex:1;box-shadow:0 .1rem .2rem 0 rgba(255,152,132,.5)}
.footer-bottom .item-prize{margin-right:.5rem;max-width:5rem}
.footer-bottom .item-prize{background:linear-gradient(135deg,$c80,$config['maincolor']);box-shadow:0 .1rem .2rem 0 $c20;}
.main_bg2{background:linear-gradient(225deg,$c80,$config['maincolor']);background-color:#111e36}
</style>
<script>var HB_INWECHAT = '{HB_INWECHAT}', HB_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}"; var lockIng = 0;var PUB_VARID = 0, IGNORETIP = 0;QDYX = '{lang xigua_es:qdyx}';
var qrtk_ = '{lang xigua_es:qrtk}', qrtk_desc_ = '{lang xigua_es:qrtk_desc}', qrqxtk_ = '{lang xigua_es:qrqxtk}', qx_ = '{lang xigua_es:qx}', cltk_ = '{lang xigua_es:cltk}', tytk_ = '{lang xigua_es:tytk}';
var KDGS = '{lang xigua_es:kdgs}' ,KDDH = '{lang xigua_es:kddh}';
</script>