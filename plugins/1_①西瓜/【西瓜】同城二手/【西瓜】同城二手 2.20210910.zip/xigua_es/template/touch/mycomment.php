<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_es:header}-->
<style>.comment_ul .weui-media-box_appmsg .weui-media-box__hd{width:40px;height:40px;line-height:40px}</style>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{if $_GET[type]!='sx'}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hb&ac=mycomment&type=tome" class="weui-navbar__item <!--{if $_GET[type]!='tother'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hb:comments}{lang xigua_hb:wode}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hb&ac=mycomment&type=tother" class="weui-navbar__item <!--{if $_GET[type]=='tother'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hb:wode}{lang xigua_hb:comments}</span>
        </a>
    </div>
    <!--{/if}-->
    <div id="list" class="weui-panel__bd comment_ul p0 bgf"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>
    var loadingurl = window.location.href+'&id=xigua_hb&ac=comment_li&hidezw=1&inajax=1&type=$_GET[type]&multi=1&pagetype=page&page=';
</script>
<!--{eval $es_tabbar=1;$tabbar=0;}-->
<!--{template xigua_es:footer}-->