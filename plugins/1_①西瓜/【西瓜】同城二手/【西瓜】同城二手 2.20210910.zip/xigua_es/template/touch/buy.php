<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_es:header}-->
<div class="page__bd">

<form  action="$SCRITPTNAME?id=xigua_es&ac=buy&st={$_GET['st']}" method="post" id="form">
<input type="hidden" name="formhash" value="{FORMHASH}">
<input type="hidden" name="pubid" value="{$pubid}">
<!--{if $jymethod!=2}-->
<input type="hidden" name="form[exp_method]" id="showmethod" value="kuaidi">
<!--{else}-->
<input type="hidden" name="form[exp_method]" id="showmethod" value="daodian">
<!--{/if}-->

    <!--{template xigua_es:cardbuy}-->

    <div class="weui-cells before_none after_none cardbuy">
        <div style="display:block;overflow:hidden" class="weui-cell ">
            <div class="weui-cell__hd z f15">
                {lang xigua_es:spje}
            </div>
            <div class="weui-cell__ft ">
                <span class="f18 es_price_red" style="position:absolute;right:.75rem"><em class="f15">&yen;</em> {$jiaoyi_price}</span>
            </div>
        </div>

        <!--{if $jymethod==3}-->
        <div class="weui-cell ">
            <div class="weui-cell__bd">
                <div class="post-tags buy-tags cl">
                    <a class="weui-btn weui-btn_mini weui-btn_default tag-on" data-tyid="kuaidi" style="margin-bottom:0" href="javascript:;">{lang xigua_es:kdfy}</a>
                    <a class="weui-btn weui-btn_mini weui-btn_default" data-tyid="daodian" style="margin-bottom:0" href="javascript:;">{lang xigua_es:ddhx}</a>
                </div>
            </div>
        </div>
        <!--{/if}-->

        <div style="overflow:hidden; <!--{if $jymethod==2}-->display:block<!--{else}-->display:none<!--{/if}-->" class="weui-cell " id="jydd">
            <div class="weui-cell__hd z f15">
                {lang xigua_es:jydd}
            </div>
            <div class="weui-cell__bd"></div>
            <div class="weui-cell__ft" style="max-width: calc(100% - 5rem);float: right;">
                <!--{if $distvar}-->
                <a class="weui-cell before_none p0 loc_o" href="javascript:;" id="hb_openLocation" data-lat="{$distvar[value][1]}" data-lng="{$distvar[value][2]}" data-name="{$distvar[value][0]}" data-addr="{$distvar[value][0]}" style="align-items:normal">
                    <div class="weui-cell__hd loc_oi"></div>
                    <div class="weui-cell__bd loc_if">
                        {$distvar[value][0]}
                    </div>
                </a>
                <!--{else}-->
                <span class="f15">{lang xigua_es:lxmj} <a class="main_color" href="tel:$v[mobile]">$v[mobile]</a></span>
                <!--{/if}-->
            </div>
        </div>
        <div style="overflow:hidden; <!--{if $jymethod==2}-->display:none;<!--{else}-->display:block<!--{/if}-->" class="weui-cell " id="yf">
            <div class="weui-cell__hd z f15">
                {lang xigua_es:yunfei1}
            </div>
            <div class="weui-cell__bd"></div>
            <div class="weui-cell__ft">
                <span class="f15"><em class="f15">&yen;</em> {$youfei}</span>
            </div>
        </div>
    </div>
    <div class="weui-cells before_none after_none weui-cells_radio  cardbuy" id="addrbox" style="<!--{if $jymethod==2}-->display:none<!--{/if}-->">
        <a class="weui-cell weui-cell_access after_none payaddress" href="javascript:;" id="pay_address">
            <div class="weui-cell__hd">
                <label class="weui-label mr8" style="width:auto"><i class="f24 c3 iconfont icon-mudedi vm"></i></label>
            </div>
            <div class="weui-cell__bd c3">
                <!--{if $dft[mobile]}-->
                <div class="f16 "><span class="f16"><b>{$dft[realname]}</b></span>&nbsp;{$dft[mobile]}</div>
                <div class="f13 mt8 c6">{$dft[dist1]}&nbsp;{$dft[dist2]}&nbsp;{$dft[dist3]}&nbsp;{$dft[address]}</div>
                <input type="hidden" name="form[dist1]" value="$dft[dist1]">
                <input type="hidden" name="form[dist2]" value="$dft[dist2]">
                <input type="hidden" name="form[dist3]" value="$dft[dist3]">
                <input type="hidden" name="form[address]" value="$dft[address]">
                <input type="hidden" name="form[realname]" value="$dft[realname]">
                <input type="hidden" name="form[mobile]" value="$dft[mobile]">
                <input type="hidden" name="form[addrid]" value="$addr[id]">
                <!--{else}-->
                <div class="f16">{lang xigua_es:djszshdz}</div>
                <!--{/if}-->
            </div>
            <div class="weui-cell__ft">
            </div>
            <div class="addrbx"></div>
        </a>
    </div>

    <div class="weui-cells before_none after_none cardbuy">
        <div class="weui-cell ">
            <div class="weui-cell__bd">
                <input class="weui-input f14" name="form[note]" id="item_note" type="text" placeholder="{lang xigua_es:xt}" value="{$_GET['note']}">
            </div>
        </div>
    </div>

    <div class="footer_fix"></div>
    <div class="fix-bottom buy-bottom comshadow">
        <div class="confirm_foot_d">
            <em class="hejiem">{lang xigua_es:heji}:</em>
            <span class="f18 es_price_red"><em class="f15">&yen;</em> <i id="price_last" style="margin-left:.25rem">{echo $jiaoyi_price+$youfei}</i></span>
        </div>
        <!--{if $info[wancheng]}-->
        <input class="confirm_foot_btn disablebtn" value="{lang xigua_es:ysw}" type="button">
        <!--{else}-->
        <input class="confirm_foot_btn" value="{lang xigua_es:qrxd}" id="dosubmit" name="dosubmit" type="submit">
        <!--{/if}-->
    </div>
</form>
</div>
<!--{eval $es_tabbar=0;$tabbar=0;}-->
<!--{template xigua_es:footer}-->
<script>
<!--{if $distvar}-->
$(document).on('click', '#hb_openLocation', function () {
    var that = $(this);
    if(('{HB_INWECHAT}' && "{$_G['cache']['plugin']['xigua_hb'][multiupload]}")==1){
        wx.openLocation({
            latitude: that.data('lat'),
            longitude: that.data('lng'),
            name: that.data('name'),
            address: that.data('addr'),
            scale: 14,
            infoUrl:window.location.href
        });
    }else if("{$_G['cache']['plugin']['xigua_hs']['google']}"){
        window.location.href = _APPNAME+'?id=xigua_hs&ac=googleMap&lat='+that.data('lat')+"&lng="+that.data('lng')+_URLEXT;
    }else{
        window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:"+that.data('lat')+","+that.data('lng')+";title:"+that.data('name')+";addr:"+that.data('addr');
    }
    return false;
});
<!--{/if}-->
var YUNFEI = $youfei, YUNFEISTO = $youfei;
$(document).on('click','.buy-tags a', function () {
    var that = $(this);
    var exp_method = that.data('tyid');
    $('.buy-tags').find('a').removeClass('tag-on');
    that.addClass('tag-on');
    if(exp_method==='kuaidi'){
        $('#showmethod').val('kuaidi');
        YUNFEI = YUNFEISTO;
        $('#addrbox').show();
        $('#yf').show();
        $('#jydd').hide();
    }else{
        $('#showmethod').val('daodian');
        YUNFEI = 0;
        $('#addrbox').hide();
        $('#yf').hide();
        $('#jydd').show();
    }
    shisuan(YUNFEI);
});
function shisuan(YUNFEI){
    $.ajax({
        type: 'GET',
        url: _APPNAME + '?id=xigua_es&gid={$pubid}&ac=shisuan&price=$jiaoyi_price&yf='+YUNFEI+'&inajax=1'+_URLEXT,
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            console.log(s.split('_'));
            if(s){
                $('#price_last').html(s.split('_')[0]);
            }
        }
    });
}
</script>