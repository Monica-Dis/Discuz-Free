<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_es:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar border_none">
        <a href="$SCRITPTNAME?id=xigua_es&ac=mypub&stat=display&display=1" class="weui-navbar__item <!--{if $_GET[stat]=='display'&&$_GET[display]==1&&!$_GET[wancheng]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hb:xianshi}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_es&ac=mypub&stat=display&display=0" class="weui-navbar__item <!--{if $_GET[stat]=='display'&&$_GET[display]==0}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hb:daishen}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_es&ac=mypub&stat=display&display=1&wancheng=1" class="weui-navbar__item <!--{if $_GET[wancheng]=='1'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_es:ysw}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_es&ac=mypub&stat=digs&dstat=ing" class="weui-navbar__item <!--{if $_GET[stat]=='digs'}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hb:zhiding}</span>
        </a>
    </div>
    <!--{if $_GET[stat]=='digs'}-->
    <div class="banner_fix cl">
        <div class="banner">
            <nav class="weui-flex tag_list">
                <a href="$SCRITPTNAME?id=xigua_es&ac=mypub&stat=digs&dstat=ing" class="<!--{if !$_GET[dstat]||$_GET[dstat]=='ing'}-->main_color<!--{/if}-->">{lang xigua_hb:yizhiding}</a>
                <a href="$SCRITPTNAME?id=xigua_es&ac=mypub&stat=digs&dstat=end" class="<!--{if $_GET[dstat]=='end'}-->main_color<!--{/if}-->">{lang xigua_hb:zdjs}</a>
            </nav>
        </div>
    </div>
    <!--{/if}-->
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>
    var loadingurl = window.location.href+'&id=xigua_es&ac=list_item&is_my=1&inajax=1&page=';
    scrollto = 0;
</script>
<!--{eval $es_tabbar=1;$tabbar=0;}-->
<!--{template xigua_es:footer}-->
<script>
    <!--{if $_GET['pubid'] && !getcookie('disable_'.$_GET['pubid'])}-->
    <!--{eval dsetcookie('disable_'.$_GET['pubid'], 1, 86400);}-->
    setTimeout(function(){
        if($('#pubitem_$_GET[pubid]').length>0){
            showansi($('#pubitem_$_GET[pubid]')[0]);
        }
    }, 2000);
    <!--{/if}-->
</script>