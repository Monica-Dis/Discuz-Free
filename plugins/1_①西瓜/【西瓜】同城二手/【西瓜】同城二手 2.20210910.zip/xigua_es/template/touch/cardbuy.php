<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<div class="weui-cells before_none after_none cardbuy">
    <!--{if $_GET['ac']=='order_profile'}-->
    <!--{else}-->
    <div <!--{if $showbuyer}-->class="weui-cell weui-cell_access border_none sp_good_od mt0" data-id="$v[id]" data-manage="$_GET['manage']"<!--{else}-->class="weui-cell weui-cell_access border_none"<!--{/if}-->>
    <!--{if $showbuyer}-->
        <div class="weui-cell__hd mr8 f14">
            {lang xigua_es:ddbh} :{$v['order_id']}
        </div>
        <div class="weui-cell__bd"></div>
    <!--{else}-->
        <div class="weui-cell__hd mr8"><img class="confirm_shlogo" src="{echo avatar($v['uid'], 'middle', 1)}" onerror="this.error=null;$(this).remove();"></div>
        <div class="weui-cell__bd"><span class="f15 c3">{$v[realname]}</span></div>
    <!--{/if}-->
        <!--{if $showbuyer}-->
        <div class="weui-cell__ft">
            <!--{if $v[shou_ts]>1}-->
            <div class=" f14" data-statusf="$status_font[$v[status]]" data-yiid="$v['order_id']">{lang xigua_es:jycg}</div>
            <!--{else}-->
            <div class=" f14" data-yiid="$v['order_id']"> {$status_font[$v[status]]}</div>
            <!--{/if}-->
        </div>
        <!--{/if}-->
    </div>
    <!--{/if}-->

    <div class="weui-cell weui-cell_access before_none after_none pricebuy" onclick="hb_jump('$SCRITPTNAME?id=xigua_es&ac=view&pubid=$pubid')">
        <div class="weui-cell__hd z">
            <label class="weui-label ">
                <img src="{$v[imglist][0]}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'">
            </label>
        </div>
        <div class="weui-cell__bd pr">
            <p class="f15 c3 twoline">{$goodname}</p>
            <p class="f18 es_price pricebuy_field"><em class="f15">&yen;</em>&nbsp;{$jiaoyi_price}</p>
        </div>
    </div>

    <!--{if $_GET['ac']=='order_profile'||$showbuyer}-->
    <div class="pt_func  weui-cell">
        <div class="weui-cell__bd f12">
            <!--{if $v[jumpurl]}-->
            {lang xigua_es:status_1}:
            <!--{else}-->
            {lang xigua_es:ddje}:
            <!--{/if}-->
            <em class="es_price_red">&yen;{$v[pay_money]}</em> (<!--{if $v[yunfee]>0}--> {lang xigua_es:yunfei1}: {$v[yunfee]} {lang xigua_es:yuan}<!--{else}--> {lang xigua_es:myf}<!--{/if}--> )
        </div>
        <div class="weui-cell__ft">
            <!--{template xigua_es:order_status}-->
        </div>
    </div>
    <!--{/if}-->

    <!--{if $appendhtml}-->
    <div class="weui-cell ">
        <div class="weui-cell__bd f12"><img src="{avatar($v[uid], middle, true)}" class="pt_usr" style="width:1.2rem;height:1.2rem" > $v['realname']</div>
        <div class="weui-cell__ft f12">
            {lang xigua_es:xdsj} : {$v[crts_u]}
        </div>
    </div>
    <!--{/if}-->
</div>