<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_es:header}--><!--{eval $no_header_fix=1;}--><style>.weui-grids-mini .weui-grid{padding:.75rem .5rem}.x_header{position:relative}.centtop1 a i{color:{$config[maincolor]}}.centtop2 a i{color:#999}.my_new_bd .my__head_wap .weui-grids-mini{position: relative;bottom:0}.my_new_bd .my__head_new{margin-bottom:0;height:7.5rem}.my_new_bd .my__head_user{margin:.5rem .75rem;width:100%}.my_new_bd .jnav .weui-grid__label{margin-top:.5rem}.my_new_bd .qblink{padding-right:.5rem!important}.navtitle{display:none}.x_header{background-color:transparent!important;}.weui-grid__icon{height:1.6rem}
.my_new_bd .my__head_user {margin: .5rem .75rem;width: calc(100% - 1.5rem);}.my_new_bd .my__head_user>div {float: left;width: calc(100% - 3.5rem);}
.my_new_bd .qblink{max-width: 70%;line-height:1rem;height:1rem;overflow:hidden;text-overflow:ellipsis;white-space: nowrap;padding:0;padding-left:.5rem}.icon-shouji:before {position: relative;top: -.1rem;}</style>
<div class="page__bd my_new_bd ">
<div class="do_bd">
<div class="main_bg2">
<!--{template xigua_hb:common_nav}-->
<div class="myes_top">
    <div class="my__head_wap block ">
        <div class="my__head_user z">
            <!--{if $_G['cache']['plugin']['xigua_member']}-->
            <a href="$SCRITPTNAME?id=xigua_member:profile" class="my__head_avatar z"><img src="{avatar($_G[uid], 'big', true)}" ></a>
            <!--{else}-->
            <span class="my__head_avatar z"><img src="{avatar($_G[uid], 'big', true)}" ></span>
            <!--{/if}-->
            <div>
                <div class="my__head_nickname f16">{$_G[username]}</div>
                <a href="javascript:;" class="qblink ifoset">UID : {$_G[uid]}</a>
            </div>
        </div>
        <div class="weui-grids weui-grids-mini w33">
            <a href="$SCRITPTNAME?id=xigua_es&ac=my&do=zuji" class="weui-grid">
                <div class="tc">
                    <span id="njum3" class="countup f16 ifoset">$myzujis</span>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_es:zuji}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_es&ac=my&do=fav&ty=user" class="weui-grid">
                <div class="tc">
                    <span id="njum2" class="countup f16 ifoset">{$myfavuser}</span>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_es:guanzhu}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_es&ac=my&do=fav&ty=fans" class="weui-grid">
                <div class="tc">
                    <span id="njum1" class="countup f16 ifoset">$myfans</span>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_es:fensi}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_es&ac=mycomment&type=sx" class="weui-grid">
                <div class="tc">
                    <span id="njum0" class="countup f16 ifoset">$newpm</span>
                </div>
                <p class="weui-grid__label f13 ">{lang xigua_es:xxx}</p>
            </a>
        </div>
    </div>
</div>
</div>

<div class="centtop centtop1">
    <div class="weui-cells__title weui_title mt0 f15 ">{lang xigua_es:wdjy}</div>
    <div class="cl myjy1">
        <a href="$SCRITPTNAME?id=xigua_es&ac=mypub" class="z">
            <div class="weui-grid__icon">
                <i class="ifoset" id="njum4">$totalpub</i>
            </div>
            <p class="weui-grid__label f13">{lang xigua_es:wfbd}</p>
        </a>
        <a href="$SCRITPTNAME?id=xigua_es&ac=order&manage=1" class="z">
            <div class="weui-grid__icon">
                <i class="ifoset" id="njum5">$mysell</i>
            </div>
            <p class="weui-grid__label f13">{lang xigua_es:wmcd}</p>
        </a>
        <a href="$SCRITPTNAME?id=xigua_es&ac=order" class="z" >
            <div class="weui-grid__icon">
                <i class="ifoset" id="njum6">$mybuy</i>
            </div>
            <p class="weui-grid__label f13">{lang xigua_es:wmdd}</p>
        </a>
        <a href="$SCRITPTNAME?id=xigua_es&ac=my&do=fav&ty=xinxi" class="z" >
            <div class="weui-grid__icon">
                <i class="ifoset" id="njum7">$myfav</i>
            </div>
            <p class="weui-grid__label f13">{lang xigua_es:wscd}</p>
        </a>
    </div>
</div>

<div class="centtop f15 before_none after_none">
    <div class="weui-cells__title weui_title mt0 f15 ">{lang xigua_es:cygj}
        <a class="y" href="$SCRITPTNAME?id=xigua_hb&ac=my">{lang xigua_es:gd}<i class="f13 iconfont icon-jinrujiantou"></i></a>
    </div>
    <div class="cl">
        <a href="$SCRITPTNAME?id=xigua_hb&ac=myaddr&mobile=2{$urlext}" class="z" style="width:25%">
            <div class="weui-grid__icon">
                <i class="iconfont icon-mudedi main_color f24"></i>
            </div>
            <p class="weui-grid__label f13">{lang xigua_hb:myaddr}</p>
        </a>

        <a href="$SCRITPTNAME?id=xigua_hb&ac=myzl&mobile=2&referer={echo urlencode(hb_currenturl());}{$urlext}" class="z" style="width:25%">
            <div class="weui-grid__icon">
                <i class="iconfont icon-shouji main_color f24"></i>
            </div>
            <p class="weui-grid__label f13">{lang xigua_es:bdsj}</p>
        </a>

        <a class="z" style="width:25%" <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jump_download();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao{$urlext}"<!--{/if}--><!--{/if}-->>
        <div class="weui-grid__icon">
            <i class="iconfont icon-qianbao2 main_color  f22" style="position:relative;top:2px;" ></i>
            <span class="weui-badge ifoset">&yen;<em id="njum8">{$qianbao[money]}</em></span>
        </div>
        <p class="weui-grid__label f13">{lang xigua_es:wdqb}</p>
        </a>

        <a href="$SCRITPTNAME?id=xigua_hb&ac=mysetxx{$urlext}" class="z" style="width:25%">
            <div class="weui-grid__icon">
                <i class="iconfont icon-xianshiqianggou main_color f24"></i>
            </div>
            <p class="weui-grid__label f13">{lang xigua_es:txsz}</p>
        </a>
    </div>
</div>

<div class="centtop " style="padding-bottom: 0">
    <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=about&mobile=2">
        <div class="weui-cell__hd"><i class="iconfont icon-guize main_color"></i></div>
        <div class="weui-cell__bd">
            <p class="f14 c3">{lang xigua_hb:bangzhu}</p>
        </div>
        <div class="weui-cell__ft"> </div>
    </a>
    <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
        <div class="weui-cell__hd"><i class="iconfont icon-kefu main_color"></i></div>
        <div class="weui-cell__bd">
            <p class="f14 c3">{lang xigua_hb:kefu}</p>
        </div>
        <div class="weui-cell__ft f14">{lang xigua_hb:zhwo}</div>
    </a>
</div>

</div>
</div>
<div class="masker" style="position: fixed;top: 0;left: 0;right: 0;bottom: 0;background: rgba(0, 0, 0, .5);display: none;z-index:501" onclick='$("#qiehuan").select("close")'></div>
<!--{eval $es_tabbar=1;$tabbar=0;}-->
<!--{template xigua_es:footer}-->
<script src="source/plugin/xigua_hb/static/countUp.js"></script><script>
function jump_download() {
$.confirm("$config[qbguide]", function() {
    window.location.href = '$config[qbguidelink]';
}, function() {
});
return false;
}
var options={useEasing:true,useGrouping:true,separator:'',decimal:'.',prefix:'',suffix:''};
new countUp("njum1", 0, $('#njum1').text(), 0, 2.5, options).start();
new countUp("njum2", 0, $('#njum2').text(), 0, 2.5, options).start();
new countUp("njum3", 0, $('#njum3').text(), 0, 2.5, options).start();
new countUp("njum4", 0, $('#njum4').text(), 0, 2.5, options).start();
new countUp("njum5", 0, $('#njum5').text(), 0, 2.5, options).start();
new countUp("njum6", 0, $('#njum6').text(), 0, 2.5, options).start();
new countUp("njum7", 0, $('#njum7').text(), 0, 2.5, options).start();
new countUp("njum8", 0, $('#njum8').text(), 0, 2.5, options).start();
</script>