<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $v[refund_id]}-->
<!--{eval $refund= C::t('#xigua_es#xigua_es_refund')->fetch_by_id($v[refund_id]);}-->
<!--{/if}-->
<!--{if in_array($v[status], array(3,4,7))}-->
<div class="pro_top main_bg 1">
    <p>{lang xigua_es:ddyqx}</p>
    <!--{if $v[status]==7}-->
    <p>{lang xigua_es:pdsbytk}</p>
    <!--{/if}-->
    <!--{if $v[status]==3}-->
    <p>{lang xigua_es:status_3} <span class="f12">{lang xigua_es:sqsj} $refund[crts_u]</span></p>
    <!--{/if}-->
    <!--{if $v[status]==4 && $refund[upts_u]}-->
    <p>{lang xigua_es:status_44} <span class="f12">{lang xigua_es:tksj} $refund[upts_u]</span></p>
    <!--{/if}-->
</div>
<!--{elseif in_array($v[status], array(2,6))}-->
<div class="pro_top main_bg 2">
    <p>{$status_font[$v[status]]}</p>
<!--{if $v['exp_method']=='kuaidi'}-->
    <!--{if $v[fa_ts]==-1}-->
    <p>{lang xigua_es:dfh}</p>
    <!--{elseif $v[shou_ts]==-1}-->
    <p>{lang xigua_es:dshuo}</p>
    <p>{lang xigua_es:kd}: {$v[yundan_gs]}</p>
    <p>{lang xigua_es:ydh}: {$v[yundan]}</p>
    <!--{elseif $v[shou_ts]>1}-->
    <p>{lang xigua_es:ysh} {$v[shou_ts_u]}</p>
    <p>{lang xigua_es:kd}: {$v[yundan_gs]}</p>
    <p>{lang xigua_es:ydh}: {$v[yundan]}</p>
    <!--{/if}-->
    <!--{if $v[yundan]}-->
        <!--{if $es_config[kdcode]}-->
        <a id="seckdcode" style="display:none" href="https://m.kuaidi100.com/result.jsp?nu={$v[yundan]}" target="_blank">{lang xigua_es:kdgz}&raquo;</a>
        <!--{else}-->
        <a href="https://m.kuaidi100.com/result.jsp?nu={$v[yundan]}" target="_blank">{lang xigua_es:kdgz}&raquo;</a>
        <!--{/if}-->
    <!--{/if}-->
<!--{elseif $v['exp_method']=='daodian'}-->
    <!--{if $v[fa_ts]==-1}-->
        <p class="fa_ts-1">{lang xigua_es:yfkdhx}</p>
    <!--{elseif $v[shou_ts]==-1}-->
        <p class="shou_ts-1">{lang xigua_es:yfkdhx}</p>
    <!--{elseif $v[shou_ts]>1}-->
        <p>{lang xigua_es:jycg} {$v[shou_ts_u]}</p>
    <!--{/if}-->
<!--{/if}-->

</div>
<!--{else}-->
<div class="pro_top main_bg 3">
    <p>{$status_font[$v[status]]}</p>
</div>
<!--{/if}-->



