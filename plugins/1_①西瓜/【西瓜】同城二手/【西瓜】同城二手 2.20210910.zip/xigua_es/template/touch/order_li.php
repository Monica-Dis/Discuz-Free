<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<!--{eval $pubid = $v['gid'];
$jiaoyi_price = floatval($v['pay_money']);
$goodname = $v['title'];
$appendhtml = 1;
}-->
<!--{template xigua_es:cardbuy}-->
<!--{/loop}-->