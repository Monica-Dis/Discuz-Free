<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_es:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div  id="list" class="weui-cells p0 mt0"></div>
    <!--{template xigua_hb:loading}-->
</div>

<script>
    <!--{if $_GET[ty]=='user'}-->
    var loadingurl = _APPNAME+'?id=xigua_hb&ac=fav&fav=user&pagesize=40&inajax=1&page=';
    $(document).on('click','.favuser', function () {
        var that = $(this);
        $.modal({
            title: '{lang xigua_hb:gzgl}',
            text: that.data('username'),
            buttons: [
                { text: "{lang xigua_hb:close}", className: "default", onClick: function(){ } },
                { text: "{lang xigua_hb:qxgz}", className: "default", onClick: function(){
                        $.showLoading();
                        $.ajax({
                            type: 'post',
                            url: _APPNAME + '?id=xigua_hb&ac=fav&fav=user&ref=1&inajax=1',
                            data: {
                                'touid': that.data('uid'),
                                'formhash': FORMHASH
                            },
                            dataType: 'xml',
                            success: function(data) {
                                $.hideLoading();
                                if (null == data) {
                                    tip_common('error|' + ERROR_TIP);
                                    return false;
                                }
                                var s = data.lastChild.firstChild.nodeValue;
                                tip_common(s);
                            },
                            error: function() {
                                $.hideLoading();
                            }
                        });
                    } },
                { text: "{lang xigua_hb:ck}", onClick: function(){ window.location.href=that.data('href')} }
            ]
        });
    });
    <!--{elseif $_GET['ty']=='fans'}-->
    var loadingurl = _APPNAME+'?id=xigua_hb&ac=fav&fav=fans&inajax=1&pagesize=40&page=';
    $(document).on('click','.favuser', function () {
        var that = $(this);
        window.location.href=that.data('href');
    });
    <!--{else}-->
    var loadingurl = _APPNAME+'?id=xigua_es&ac=list_item&fav=1&inajax=1&pagesize=20&page=';
    <!--{/if}-->
</script>
<!--{eval $es_tabbar=1;$tabbar=0;}-->
<!--{template xigua_es:footer}-->