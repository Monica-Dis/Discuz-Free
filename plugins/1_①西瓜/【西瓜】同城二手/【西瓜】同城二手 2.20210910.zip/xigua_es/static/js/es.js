$(function () {
    $(document).on('click','.payaddress', function () {
        hb_setcookie('seckill_wait', window.location.href, 1200);
        window.location.href = _APPNAME+'?id=xigua_hb&ac=myaddr'+_URLEXT;
    });
    $(document).on('click', '.sp_good_od', function () {
        var that = $(this);
        var jmpurl = _APPNAME + '?id=xigua_es&ac=order_profile&ptlog_id=' + that.data('id') + (that.data('manage') ? '&manage=1' : '') + (typeof _URLEXT !== 'undefined' ? _URLEXT : '');
        hb_jump(jmpurl);
    });

    $(document).on('click','#dosearch', function () {
        $('#dosearchform').submit();
    });

    $(document).on('click','.cancel_order', function () {
        var that = $(this);
        $.confirm(QDYX, function () {
            $.showLoading();
            $.ajax({
                type: "POST",
                url: _APPNAME+"?id=xigua_es&ac=cancel_order&inajax=1&ordid="+that.data('id'),
                data:{formhash:FORMHASH},
                dataType: "xml",
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                }
            });
        }, function () {
        });
    });

    $(document).on('click','.dotuikuan', function () {
        var that = $(this);
        var ptlogid = that.data('ptlogid');
        console.log(ptlogid);
        $.prompt({
            title:qrtk_,
            text: qrtk_desc_,
            empty: false,
            onOK: function (input) {
                console.log(input);$.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME+'?id=xigua_es&ac=tuihuo&inajax=1',
                    data: {'formhash':FORMHASH, 'input':input, 'ptlogid' : ptlogid},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if (null == data) {
                            tip_common('error|' + ERROR_TIP);
                            return false;
                        }
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {$.hideLoading();}
                });
            },
            onCancel: function () {
            }
        });
    });
    $(document).on('click','.canceltuikuan', function () {
        var that = $(this);
        var ptlogid = that.data('ptlogid');
        $.confirm(qrqxtk_, function () {$.showLoading();
            $.ajax({
                type: 'post',
                url: _APPNAME+'?id=xigua_es&ac=tuihuo&do=backrefund&inajax=1',
                data: {'formhash':FORMHASH, 'ptlogid' : ptlogid},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if (null == data) {
                        tip_common('error|' + ERROR_TIP);
                        return false;
                    }
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {$.hideLoading();}
            });
        }, function () {});
    });
    $(document).on('click','.dotk', function () {
        var that = $(this);
        var redund = that.data('redund');
        $.showLoading();
        $.ajax({
            type: 'GET', url: _APPNAME+'?id=xigua_es&ac=tuihuo&do=getrefund&inajax=1', data: {'refund_id':redund}, dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if (null == data) {tip_common('error|' + ERROR_TIP);return false;}
                var s = data.lastChild.firstChild.nodeValue;
                $.modal({
                    title:cltk_,
                    text: s.split('|')[1],
                    buttons: [
                        { text:tytk_, onClick: function(){$.showLoading();
                                $.ajax({
                                    type: 'post',
                                    url: _APPNAME+'?id=xigua_es&ac=tuihuo&do=confirmtk&inajax=1',
                                    data: {'formhash':FORMHASH, 'redund_id' : redund},
                                    dataType: 'xml',
                                    success: function (data) {
                                        $.hideLoading();
                                        if (null == data) {
                                            tip_common('error|' + ERROR_TIP);
                                            return false;
                                        }
                                        var s = data.lastChild.firstChild.nodeValue;
                                        tip_common(s);
                                    },
                                    error: function () {$.hideLoading();}
                                });
                            }},
                        { text:qx_, className: "default", onClick: function(){} },
                    ]
                });
            },
            error: function () {$.hideLoading();}
        });
    });

    $(document).on('click','.fahuo', function () {
        var that = $(this);

        $.prompt({
            title: that.data('title'),
            empty: false,
            onOK: function (input) {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: _APPNAME+'?id=xigua_es&ac=com&do=fahuo&inajax=1',
                    data:{formhash:FORMHASH, yundan_gs : input, yundan:$('#actfield').val(), ptlogid:that.data('id')},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });

        $('#weui-prompt-input').replaceWith('<input class="weui-prompt-input needsclick weui-input needsclick_input" type="text" id="weui-prompt-input" placeholder="'+KDGS+'" />');
        setTimeout(function(){
            $('.weui-dialog__bd').after('<div class="dialog_custom"><div><input id="actfield" class="weui-input needsclick_input" type="text" placeholder="'+KDDH+'"></div></div>');
        }, 150);
        document.getElementById('weui-prompt-input').focus();
    });

    var qrshlock = 0;
    $(document).on('click','.qrsh', function () {
        var that = $(this);
        $.confirm(that.data('title'), function () {
            $.showLoading();
            console.log(qrshlock);
            if(qrshlock===1){
                return;
            }
            qrshlock =1;
            $.ajax({
                type: 'post',
                url: _APPNAME+'?id=xigua_es&ac=com&do=shouhuo&inajax=1',
                data:{formhash:FORMHASH,  ptlogid:that.data('id')},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                    qrshlock = 0;
                },
                error: function () {
                    $.hideLoading();
                    qrshlock = 0;
                }
            });
        }, function () {
        });
    });
    $(document).on('click','#pubes', function () {
        $('#pub_ctrl').popup();
    });
});