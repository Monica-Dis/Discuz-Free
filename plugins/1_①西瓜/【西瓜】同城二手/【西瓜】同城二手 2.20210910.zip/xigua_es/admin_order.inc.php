<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_es/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_es/function.php';


if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$sta = $status_font;
unset($sta[5]);
unset($sta[6]);
unset($sta[7]);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['lpp'] ? $_GET['lpp'] : 10;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('ptlogid')){
    $ptlogid = $_GET['ptlogid'];
    if($_GET['yundan_gs'] && $_GET['yundan']){
        DB::update('xigua_es_order', array(
            'fa_ts' => TIMESTAMP,
            'yundan_gs' => $_GET['yundan_gs'],
            'yundan' => $_GET['yundan'],
        ), array(
            'id' => $ptlogid
        ));
        unset($_GET['yundan_gs']);
        unset($_GET['yundan']);
        unset($_GET['formhash']);
        unset($_GET['permsubmit']);
        unset($_GET['ptlogid']);
        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_order&".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
    }
}

if(submitcheck('ptlogid2')){
    $ptlogid = $_GET['ptlogid2'];
    if($ptlogid){
        $old = C::t('#xigua_es#xigua_es_order')->fetch($ptlogid);
        DB::update('xigua_es_order', array(
            'fa_ts' => TIMESTAMP,
            'shou_ts' => TIMESTAMP,
            'shou_confirm_ts' => TIMESTAMP,
            'note' => $_GET['note'],
        ), array(
            'id' => $ptlogid
        ));
        if($old['shou_ts']<=1&& $old['shou_confirm_ts']<=1){
            $v = C::t('#xigua_es#xigua_es_order')->fetch($ptlogid);
            $sxfee = $v['sxf'];
            $money = $v['pay_money'] - $sxfee;

            global $_G;

            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['seller_uid'], 'money', $money);
            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                'uid'  => $v['seller_uid'],
                'crts' => TIMESTAMP,
                'size' => $money,
                'note' => lang_es('ddh',0).$v['order_id'].'<br>'.lang_es('kcsxf',0).$sxfee,
                'link' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
            ));
            unset($_GET['note']);
            unset($_GET['formhash']);
            unset($_GET['permsubmit']);
            cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_order&".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
        }
    }
}

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_es#xigua_es_order')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            if ($item['shou_ts'] == 1) {
                $old = C::t('#xigua_es#xigua_es_order')->fetch($index);
                if ($old['shou_ts']<1) {
                    $item['shou_ts'] = TIMESTAMP;
                    if (!$old['shou_confirm_ts']) {
                        $item['shou_confirm_ts'] = TIMESTAMP;
                        $sxfee = $old['sxf'];
                        $money = $old['pay_money'] - $sxfee;

                        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($old['seller_uid'], 'money', $money);
                        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                            'uid' => $old['seller_uid'],
                            'crts' => TIMESTAMP,
                            'size' => $money,
                            'note' => lang_es('ddh', 0) . $old['order_id'] . '<br>' . lang_es('kcsxf', 0) . $sxfee,
                            'link' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&ptlog_id={$old['id']}&manage=1" . $urlext,
                        ));
                    }
                }else{
                    unset($item['shou_ts']);
                }
            }
            if($item['status']>=97){
                unset($item['status']);
            }
            if($item['yundan'] || $item['yundan_gs']){
                $item['fa_ts'] = TIMESTAMP;
            }
            if($item['status']==4){
            }
            C::t('#xigua_es#xigua_es_order')->update($index, $item);
        }
    }
    unset($_GET['formhash']);
    unset($_GET['r']);
    unset($_GET['permsubmit']);
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_order&".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword'";
}elseif($keyword){
    $uids = DB::fetch_all("select uid from " . DB::table('common_member') . " where username like '%$keyword%' ", array(), 'uid');
    if ($uids) {
        $wherearr[] = "( uid in (".implode(',', array_keys($uids)).") OR  mobile like '%$keyword%' OR realname like '%$keyword%' OR title like '%$keyword%' OR goodinfo like '%$keyword%')";
    } else {
        $wherearr[] = " (mobile like '%$keyword%' OR realname like '%$keyword%' OR title like '%$keyword%' OR goodinfo like '%$keyword%')";
    }
}
$order = 'id desc';
if($_GET['status'] == 97){
    $wherearr[] = "status IN ( 2,6 ) AND fa_ts=-1";
    $order = 'pay_ts desc';

}elseif($_GET['status'] == 98){
    $wherearr[] = "status IN ( 2,6 ) AND fa_ts>1";
    $order = 'fa_ts desc';

}elseif($_GET['status'] == 99){
    $wherearr[] = "status IN ( 2,6 ) AND shou_ts>1";
    $order = 'shou_ts desc';
}

if($_GET['status']&&$_GET['status']<97){
    $wherearr[] = "status='".intval($_GET['status'])."'";
}
if($_GET['starttime1'] && $_GET['starttime2']){
    $stime1 = intval(strtotime($_GET['starttime1']));
    $stime2 = intval(strtotime($_GET['starttime2']));

    $wherearr[] = " (crts BETWEEN $stime1 AND $stime2 ) ";
}elseif ($_GET['starttime1'] ){
    $stime1 = intval(strtotime($_GET['starttime1']));
    $wherearr[] = " (crts >= $stime1 ) ";
}elseif ($_GET['starttime2'] ){
    $stime2 = intval(strtotime($_GET['starttime2']));
    $wherearr[] = " (crts <= $stime2 ) ";
}

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_order");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_es('searchinput',0).'" value="'.$_GET['keyword'].'" class="txt"  style="width: 220px;"/> ';

echo '<select name="status"><option value="0">'.lang_es('qb',0).'</option>';
foreach ($sta as $index => $item) {
    $chk = isset($_GET['status']) && $_GET['status']==$index ? 'selected':'';
    echo " <option value=\"$index\" $chk>$item</option>";
}
echo '</select>';


$q1 = lang_hb('qssj',0);
$q2 = lang_hb('jssj',0);
echo  <<<HTML
&nbsp;$q1: <input type="text" id="starttime1" name="starttime1" placeholder="2011-01-01 00:00" value="{$_GET['starttime1']}" onclick="showcalendar(event, this, true)" class="txt" />
&nbsp;$q2: <input type="text" id="starttime2" name="starttime2" placeholder="2037-01-01 23:59" value="{$_GET['starttime2']}" onclick="showcalendar(event, this, true)" class="txt" />
HTML;

echo '&nbsp;&nbsp;&nbsp;';
$lpp_se = "<select name=\"lpp\">";
foreach (array(1, 10 ,20, 50, 100, 200, 500, 1000, 2000, 5000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;

echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_order".' class="btn" >'.cplang('reset').'</a> ';

echo '</div>';

showtableheader(lang_es('tichengmanage', 0));
$ress = array();

showtablerow('class="header"',array(),$ress[] = array(
    lang_hb('del', 0),
    lang_es('buyer', 0),
    lang_es('seller', 0),
    lang_es('ddxinxi', 0),
    lang_es('spxx', 0),
    lang_es('shdz1', 0),
    lang_es('fhxx', 0),
    lang_es('status', 0),
));

$res = C::t('#xigua_es#xigua_es_order')->fetch_all_by_where($wherearr, $start_limit, $lpp, $order);
$icount = C::t('#xigua_es#xigua_es_order')->fetch_count_by_where($wherearr);

$refunds = $uids = $ordersns= array();
foreach ($res as $v) {
    $uids[] = $v['uid'];
    $uids[] = $v['seller_uid'];
    $ordersns[] = $v['order_id'];
    $refunds[] = $v['refund_id'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $vusers = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}
if($refunds){
    $refunds = DB::fetch_all('SELECT * FROM %t WHERE id IN (%n)', array('xigua_es_refund', $refunds), 'id');
    foreach ($refunds as $index => $refund) {
        $refunds[$index] = C::t('#xigua_es#xigua_es_refund')->prepare($refund);
    }
}
if($ordersns){
    $ordersns = DB::fetch_all('SELECT order_id,order_sn,jifen,jifen_type FROM %t WHERE order_id IN (%n)', array('xigua_hb_order', $ordersns), 'order_id');
}
$kdgs = lang_es('kdgs',0);
$kddh = lang_es('kddh',0);
foreach ($res as $k => $v) {
    $goodinfo = unserialize($v['goodinfo']);
    $v['refund'] = str_replace(array('array (', ')',',',"\n",'\'','=>'), array('', '','<br>','','', ':'), $v['refund']);
    if(strpos($v['refund'], 'result_code : SUCCESS')!==false){
        $v['refund'] = '<p style="color:forestgreen;font-weight:bold">'.lang_es('tkcg',0).'</p>'.$v['refund'];
    }
    $v['refund'] = trim($v['refund']);

    $id = $v['id'];
    $uid = $v['uid'];
    $info = $v['info'];
    if(!is_array($info['info'])){
        $info['info'] = unserialize($info['info']);
    }

    $mobile = $vusers[$v['uid']]['mobile'];
    if(!$mobile):
        $__profile = C::t('common_member_profile')->fetch($v['uid']);
        $mobile = $__profile['mobile'];
    endif;
    $realname = $vusers[$v['uid']]['realname'];
    if(!$v['mobile']){
        $v['mobile'] = $mobile;
    }
    if(!$v['realname']){
        $v['realname'] = $realname;
    }
    $seller_mobile = $goodinfo['mobile'] ? $goodinfo['mobile'] : $vusers[$v['seller_uid']]['mobile'];
    $seller_realname = $goodinfo['realname'] ? $goodinfo['realname'] : $vusers[$v['seller_uid']]['realname'];
    if(!$seller_mobile):
        $__profile = C::t('common_member_profile')->fetch($v['seller_uid']);
        $seller_mobile = $__profile['mobile'];
    endif;

    $fromuid = $info['fromuid'];
    $oldvs = $_GET['status'];
    if(in_array($v['status'], array(2,6)) && $v['fa_ts']>1 && $v['shou_ts']=='-1'){
        $oldvs = 98;
    }
    $sel = $seltype = '';
    foreach ($sta as $index => $item) {

        if(in_array($index, array(97,98,99))){
            if($oldvs==$index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }else{
            if($v['status'] == $index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }
    }
    $crts = date('Y-m-d H:i:s', $v['crts']);

    $pingbi = $v['shou_ts']>1 ? 'selected' : '';
    $unpingbi = $pingbi ? '' : 'selected';

$shouinfo =
($v['fa_ts']>1 ? '<br>'.lang_es('fhsj',0).': '.date('Y-m-d H:i:s', $v['fa_ts']) :'').
($v['shou_ts']>1 ? '<br><b>'.lang('plugin/xigua_es', 'shouts').': '.date('Y-m-d H:i:s', $v['shou_ts']).'</b>' : '') .
($v['yundan'] ? '<br>'. lang_es('ydxx',0) . ' :'.$v['yundan_gs'].' '.$v['yundan'] :'');

$ret_tk = '';
if($v['refund_id']>0 ){
    $rr = $refunds[$v['refund_id']];
    $tkyy = lang_es('tkyy',0);
    $sqsj = lang_es('sqsj',0);
    $tkqrsj = lang_es('tkqrsj',0);
    if($v['yundan']){
        $p1 = '<p>'.lang_es('khysh',0).'</p>';
    }
    if($rr['status']==2){
        $p2 = "<p>$tkqrsj: {$rr['upts_u']}</p>";
    }

    $ret_tk = <<<HTML
<p>$tkyy: {$rr['note']}</p>
<p>$sqsj: {$rr['crts_u']}</p>
$p1
$p2
<p>{$v['refund']}</p>
HTML;
}
    $selsho = "";
    $selsho .= "<option value=\"1\" $pingbi>".lang_es('yqrsh',0)."</option>";
    $selsho .= "<option value=\"-1\" $unpingbi>".lang_es('wqrsh',0)."</option>";

    $addr_need = '<div style="max-width:180px">';
    if($v['exp_method']=='daodian'){
        $distvar = '';
        foreach ($goodinfo['vars'] as $index => $item) {
            if($item['type']=='location' && is_array($item['value']) && count($item['value'])==3 && is_numeric($item['value'][2])):
                $distvar = $item;
                break;
            endif;
        }
        $addr_need.= lang_es('jydd',0).': '.$distvar['value'][0];
        $action_btn = in_array($v['status'], array(2,6)) && $v['shou_ts']<=1 ?
            ("<a style='font-weight:bold' href=\"javascript:;\" onclick='return _show_company_profile2($id);'>". lang_es('djwcjy', 0) . "</a>")
            : '';
    }else{
        $addr_need.= '&#22320;&#22336;: '.$v['addr'].'<br>'.
            '&#22995;&#21517;: '.$v['realname'].'<br>'.
            '&#30005;&#35805;: '.$v['mobile'];
        $action_btn = ((in_array($v['status'], array(2,6))) ?
                ("<a style='font-weight:bold' href=\"javascript:;\" onclick='return _show_company_profile1($id);'>". lang_es('djfh', 0) . "</a>")
                : '');
    }
    $addr_need.='</div>';

    showtablerow('', array(), $res_ = array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
        "<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a><br>".
        '<em style="color:#999">&#22995;&#21517;: '.$v['realname'].' </em><br>'.
        '<em style="color:#999">&#30005;&#35805;: '.$v['mobile'].' </em><br>'
    ,

        "<a href='home.php?mod=space&uid={$v['seller_uid']}&do=profile' target='_blank'>{$users[$v['seller_uid']]['username']}</a><br>".
        '<em style="color:#999">&#22995;&#21517;: '.$seller_realname.' </em><br>'.
        '<em style="color:#999">&#30005;&#35805;: '.$seller_mobile.' </em><br>'
    ,

        lang_hb('orderid',0).' : <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_order&keyword=".$v['order_id']."&note=0&page=1".'">'.$v['order_id'] . '</a><br>'.
        ($ordersns[$v['order_id']]['order_sn'] ? lang_hb('ordersn',0).': '.$ordersns[$v['order_id']]['order_sn'] . '<br>' : '').
        lang_es('crts',0).': '.$crts.'<br>'.
        lang_es('zongjia', 0).': <b style="color:orangered;font-size:14px">'.$v['pay_money'].'</b><br>'.
        '<b>'.lang_es('sxf',0).': -'.$v['sxf'] . '</b><br>'.
        ($v['pay_ts']>0 ? '<b style="color:#4caf50">'.lang_es('zfsj',0).': '.$v['pay_ts_u'].'</b>' : '<em style="color:orangered;">&#26410;&#25903;&#20184;</em>').
        '',

        '<div style="max-width:180px">'.
        '<em style="color:#999">[ '.$goodinfo['id'].' ]</em>'.$v['title'].'<br>'.
        '<b style="color:orangered;">'.lang_es('dj',0).': '.$v['unit_price'].'</b><br>'.
        '<b>'.lang_es('yunfee',0).$v['yunfee'] . '</b><br>'.
        ($v['note'] ? lang_es('bz',0).': '.$v['note'] . '<br>' :'')
        .'</div>',


        $addr_need,

        $action_btn. $shouinfo,
        "<select name='r[$id][status]' >$sel</select>".
        ("<div style='margin-top:5px;'><select name='r[$id][shou_ts]'>$selsho</select></div>")
        ."<br>".$ret_tk,

    ));
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_order&lpp=$lpp&".http_build_query($_GET).'&doexport=0', 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter();

?>
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>


<div id="rsel_menu" class="custom cmain" style="display:none;width:300px;height:250px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr"><?php lang_es('wanshan');?></h3>
    </div>
    <div id="rsel_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_order&".http_build_query($_GET));
        ?>
        <table class="">
            <tr class="hover">
                <td align="left"><?php lang_es('kdgs');?></td>
                <td><textarea name="yundan_gs" cols="30" rows="2"></textarea></td>
            </tr>
            <tr class="hover">
                <td align="left"><?php lang_es('kddh');?></td>
                <td><textarea name="yundan" cols="30" rows="2"></textarea></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="ptlogid" id="ptlogid" value="0">
                    <input type="submit" class="btn" name="editsubmit" value="<?php lang_es('djfh');?>" />
                </td>
            </tr>
        </table>
        <?php showformfooter();?>
    </div>
</div>

<div id="rsel2_menu" class="custom cmain" style="display:none;width:300px;height:160px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr"><?php lang_es('wanshan');?></h3>
    </div>
    <div id="rsel2_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_order&".http_build_query($_GET));
        ?>
        <table class="">
            <tr class="hover">
                <td align="left"><?php lang_es('bz');?></td>
                <td><textarea name="note" cols="30" rows="2"></textarea></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="ptlogid2" id="ptlogid2" value="0">
                    <input type="submit" class="btn" name="editsubmit" value="<?php lang_es('queding');?>" />
                </td>
            </tr>
        </table>
        <?php showformfooter();?>
    </div>
</div>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script>
    function _show_company_profile1(ptlogid) {
        showMenu({'ctrlid': 'rsel', 'evt': 'click', 'duration': 3, 'pos': '00'});
        $('ptlogid').value = ptlogid;
    }
    function _show_company_profile2(ptlogid) {
        showMenu({'ctrlid': 'rsel2', 'evt': 'click', 'duration': 3, 'pos': '00'});
        $('ptlogid2').value = ptlogid;
    }
</script>