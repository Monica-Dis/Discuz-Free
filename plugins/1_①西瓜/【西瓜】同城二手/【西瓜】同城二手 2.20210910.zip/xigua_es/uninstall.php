<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2020/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
DROP TABLE pre_xigua_es_index;
DROP TABLE pre_xigua_es_nav;
DROP TABLE pre_xigua_es_order;
DROP TABLE pre_xigua_es_refund;
DROP TABLE pre_xigua_es_top;
EOT;
runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/discuz_plugin_xigua_es_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_es/install.php');

xwb_delall(DISCUZ_ROOT . "./source/plugin/xigua_es");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_es");

$finish = TRUE;

function xwb_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwb_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}

$cachenames = array();
$cacherows = DB::fetch_all('select cname from '.DB::table('common_syscache').' where cname like \'hbIdist%\' or cname like \'es_views_%\' or cname like \'es_order_%\' or cname like \'es_pubs_%\'');
foreach ($cacherows as $index => $item) {
    $cachenames[$item['cname']] = $item['cname'];
}
if($cachenames) {
    C::t('common_syscache')->delete($cachenames);
}
C::t('common_syscache')->delete('es_ext_setting');