<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2020/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$es_config = $_G['cache']['plugin']['xigua_es'];
if(!$_G['cache']['es_ext_setting']){
    loadcache('es_ext_setting');
}

$status_font = array(
    1 => lang('plugin/xigua_es', 'status_1'),
    2 => lang('plugin/xigua_es', 'status_2'),
    3 => lang('plugin/xigua_es', 'status_3'),
    4 => lang('plugin/xigua_es', 'status_4'),
//    44 => lang('plugin/xigua_es', 'status_44'),
    5 => lang('plugin/xigua_es', 'status_5'),
    6 => lang('plugin/xigua_es', 'status_6'),
    7 => lang('plugin/xigua_es', 'status_7'),
);