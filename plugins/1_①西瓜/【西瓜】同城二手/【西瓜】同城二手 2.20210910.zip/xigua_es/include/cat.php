<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$filter = $_GET['filter'];
$prange = $_GET['prange'];
$city = $_GET['city'];
$dist = $_GET['dist'];
$lat = $_GET['lat'];
$lng = $_GET['lng'];
$filtervars = array();

/*if($_GET['province']||$_GET['dist']||$_GET['city']){
    dsetcookie('dist11', $_GET['province'], 86400);
    dsetcookie('dist12', $_GET['city'], 86400);
    dsetcookie('dist13', $_GET['dist'], 86400);
}
if($_G['cookie']['dist11']){
    $distname = $province = $_GET['province'] = $_G['cookie']['dist11'];
}
if($_G['cookie']['dist12']){
    $distname = $city = $_GET['city'] = $_G['cookie']['dist12'];
}
if($_G['cookie']['dist13']){
    $distname =    $dist = $_GET['dist'] = $_G['cookie']['dist13'];
}*/
if($vars):
    foreach($vars as $ab => $bc):
        if($bc['type']=='selects' ||$bc['type']=='mselects'){
            $filtervars[$ab] = $bc;
        }else if( $bc['type']=='select'){
            $extra1 = C::t('#xigua_hb#xigua_hb_cat')->get_tree($bc['extra']);
            if($extra1[1]){
//                    print_r($extra1);
                $filtervars[$ab] = array(
                    'bc' => $bc,
                    'data' => $extra1[0]
                );
            }else{
                $filtervars[$ab] = $bc;
            }
        }
    endforeach;
endif;

$_filter = array();
if($_GET['filter']):
    foreach (array_filter(explode('__', trim($_GET['filter']))) as $index => $item) :
        list($varid, $val) = explode('_', $item);
        $_filter[$varid] = $val;
    endforeach;
endif;

$showhighprice = 0;
$highprice = lang_es('dj',0);
$_prange = array();
if($_GET['prange']):
    $tmp = array_filter(explode('__', trim($_GET['prange'])));
    foreach ($tmp as $index => $item) {
        list($varid, $val) = explode('_', $item);
        $_prange[$varid.'_'.$val] = array(
            'min' => $varid,
            'max' => $val,
        );
    }
    $_prange_keys = array_keys($_prange);
    $minhprice = $_prange[$_prange_keys[0]]['min'];
    $maxhprice = $_prange[$_prange_keys[0]]['max'];
    if($minhprice || $maxhprice){
        $highprice =  $minhprice.'-'.$maxhprice .'&#20803;';
        $showhighprice = 2;
    }elseif($_prange_keys[1]){
        $highprice = $_prange[$_prange_keys[1]]['max'].'&#20803;&#20197;&#19979;';
        $showhighprice = 1;
    }
endif;

$adwhere = array();
$adwhere[] = 'types=\'cat\'';
if($_GET['cat_id']):
    $adwhere[] = '( FIND_IN_SET('.intval($_GET['cat_id']).' , catids) OR FIND_IN_SET(-1, catids) )';
else:
    $adwhere[] = '( FIND_IN_SET(-1, catids) )';
endif;
$index_list =  C::t('#xigua_hb#xigua_hb_index')->list_by_where($adwhere);
$newindex_list = array();
if($index_list):
    foreach ($index_list as $index => $item):
        $newindex_list[$item['style']][] = $item;
    endforeach;
endif;
if(checkmobile() && !$_GET['mini']){
    switch ($catinfo['tpl']){
        case 'mypub_item_pinstyle':
            $pinstyle = 1;
            $custom_side = array();
            include template('xigua_hb:pinche');
            exit;
            break;
        case 'jl_pc':
            $pinstyle = 0;
            $custom_side = array();
            $old_catinfo = $catinfo;
            if(!$subcats){
                $subcats=$cat_tree_init[$pid]['child'];
                $catinfo = $cat_tree_init[$pid];
            }
            include template('xigua_hb:jl_pc_cat');
            exit;
            break;
    }
}