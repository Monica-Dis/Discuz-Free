<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$navtitle = lang_hb('myset', 0);

$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
$muhumobile = $user['mobile'] ? (substr($user['mobile'], 0, 3).'******'.substr($user['mobile'], -2)) : '';

if(submitcheck('formhash')){
    C::t('#xigua_hb#xigua_hb_user')->update($_G['uid'], array('dftst' => $_GET['newstid'] ));
    hb_message(lang_hb('succeed',0), 'success', "$SCRITPTNAME?id=xigua_hb&ac=myset{$urlext}&st=".$_GET['newstid']);
}