<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['do']=='backrefund') {
    if(submitcheck('formhash')) {
        $ptlogid = intval($_GET['ptlogid']);
        $order = C::t('#xigua_es#xigua_es_order')->fetch($ptlogid);
        $refund_log = C::t('#xigua_es#xigua_es_refund')->fetch_by_ptlogid($ptlogid);

        C::t('#xigua_es#xigua_es_order')->update($ptlogid, array('status' => $refund_log['order_status'], 'refund_id' => 0));
        notification_add($order['seller_uid'],'system', lang_es('tksq_tip4', 0),array(
            'url' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&manage=1&ptlog_id=$ptlogid$urlext",
            'username'=>$_G['username']
        ),1);

        hb_message(lang_es('qxtkcg',0), 'success', 'reload');
    }
}else if($_GET['do']=='confirmtk'){
    if(submitcheck('formhash')){
        $rid = intval($_GET['redund_id']);
        if (discuz_process::islocked('xiguaestk'.$_G['uid'].'_'.$rid, 10)) {
            hb_message(lang_es('czpf',0), 'error');
        }
        $rv = C::t('#xigua_es#xigua_es_refund')->fetch_by_id($rid);
        $v = C::t('#xigua_es#xigua_es_order')->fetch($rv['ptlogid']);

        $canback = 0;
        if($v['seller_uid']==$_G['uid']){
            $hborder = C::t('#xigua_hb#xigua_hb_order')->fetch($v['order_id']);
            if($hborder['fromopenid']){

                $out_trade_no = $v['order_id'];
                $total_fee = intval($v['pay_money']*100);
                $refund_fee = $total_fee;
                $tkprofile = '<br>'.lang('plugin/xigua_es', 'tkje').floatval($refund_fee/100).'<br>'.lang('plugin/xigua_es', 'zfje').floatval($total_fee/100);

                try{
                    $input = new WxPayRefundSF();
                    $input->SetOut_trade_no($out_trade_no);
                    $input->SetTotal_fee($total_fee);
                    $input->SetRefund_fee($refund_fee);
                    $refund_order = substr(md5($out_trade_no), 0,8).date("YmdHis");
                    $input->SetOut_refund_no($refund_order);
                    $input->SetOp_user_id(WxPayConfigSF::MCHID);

                    $rett = WxPayApiSF::refund($input, 10);
                    $ret1 = diconv(var_export($rett, 1), 'UTF-8', CHARSET);
                    $ret2 = lang('plugin/xigua_es', 'tkxq').lang('plugin/xigua_es', $rett['return_code']).diconv($rett['return_msg'],'UTF-8', CHARSET);
                    if($rett["return_code"] == "SUCCESS" && $rett["result_code"] == "SUCCESS"){
                        C::t('#xigua_es#xigua_es_refund')->update($rid, array('upts' => TIMESTAMP, 'status' => 2));
                        C::t('#xigua_es#xigua_es_order')->update($rv['ptlogid'], array('status' => 4,'refund' => lang('plugin/xigua_es', 'dh').$refund_order.'<br>'.$ret1,));

                        notification_add($v['uid'],'system', lang_es('tksq_tip2', 0),array(
                            'url' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&ptlog_id={$rv['ptlogid']}$urlext",
                        ),1);
                        if($v['shou_ts']>0 && $v['shou_confirm_ts']>0){
                            $sxfee = $v['sxf'];
                            $money = $v['pay_money']-$sxfee;

                            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['seller_uid'], 'money', -$money);
                            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                                'uid'  => $v['seller_uid'],
                                'crts' => TIMESTAMP,
                                'size' => -$money,
                                'note' => lang_es('tkcg',0).$v['order_id'],
                                'link' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
                            ));
                        }
                        hb_message(lang_es('tkcg',0), 'success', 'reload');
                    }else{
                        $canback = 1;
                    }
                }catch (Exception $e){
                    hb_message(lang('plugin/xigua_es', 'tkxq').diconv($e->getMessage(), 'UTF-8', CHARSET), 'error');
                }
            }else{
                $canback = 1;
            }
        }else{
            hb_message('ERROR!', 'error');
        }
        if($canback){
            C::t('#xigua_es#xigua_es_refund')->update($rid, array('upts' => TIMESTAMP, 'status' => 2));
            C::t('#xigua_es#xigua_es_order')->update($rv['ptlogid'], array('status' => 4,'refund' => '',));

            C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                'uid' => $v['uid'],
                'crts' => TIMESTAMP,
                'size' => $v['pay_money'],
                'note' => lang_es('tkcg',0),
                'link' => "",
            ));
            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['uid'], 'money', $v['pay_money']);

            if($v['shou_ts']>0 && $v['shou_confirm_ts']>0){
                $sxfee = $v['sxf'];
                $money = $v['pay_money']-$sxfee;

                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['seller_uid'], 'money', -$money);
                C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                    'uid'  => $v['seller_uid'],
                    'crts' => TIMESTAMP,
                    'size' => -$money,
                    'note' => lang_es('tkcg',0).$v['order_id'],
                    'link' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
                ));
            }

            notification_add($v['uid'],'system', lang_es('tksq_tip3', 0),array(
                'url' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&ptlog_id={$rv['ptlogid']}$urlext",
            ),1);
            hb_message(lang_es('tkcg',0), 'success', 'reload');
        }
    }
}else if($_GET['do']=='getrefund'){
    $rid = $_GET['refund_id'];
    $tkyy = lang_es('tkyy',0);
    $sqsj = lang_es('sqsj',0);

    $r = C::t('#xigua_es#xigua_es_refund')->fetch_by_id($rid);
    $order = C::t('#xigua_es#xigua_es_order')->fetch($r['ptlogid']);

    if($order['yundan']){
        $p = '<p>'.lang_es('khysh',0).'</p>';
    }

    $ret = <<<HTML
<p style="text-align:left">$tkyy: {$r['note']}</p>
<p style="text-align:left">$sqsj: {$r['crts_u']}</p>$p
HTML;
    hb_message($ret, 'success');
}else{

    if(submitcheck('formhash')){
        $ptlogid = intval($_GET['ptlogid']);
        $order = C::t('#xigua_es#xigua_es_order')->fetch($ptlogid);
        $order = C::t('#xigua_es#xigua_es_order')->prepare($order);
        if(!$order['allowtk']){
            hb_message(lang_es('qqrshhztk',0), 'error');
        }

        $rid = C::t('#xigua_es#xigua_es_refund')->insert(array(
            'ptlogid' => $ptlogid,
            'crts' => TIMESTAMP,
            'uid' => $_G['uid'],
            'danhao' => '',
            'gongsi' => '',
            'note' => $_GET['input'],
            'status' => '-1',
            'order_status' => $order['status'],
        ), 1);

        C::t('#xigua_es#xigua_es_order')->update($ptlogid, array('status' => 3, 'refund_id' => $rid));

        notification_add($order['seller_uid'],'system', lang_es('tksq_tip', 0),array(
            'url' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&manage=1&ptlog_id=$ptlogid$urlext",
            'username'=>$_G['username']
        ),1);

        hb_message(lang_es('sqcg',0), 'success', 'reload');
    }
}