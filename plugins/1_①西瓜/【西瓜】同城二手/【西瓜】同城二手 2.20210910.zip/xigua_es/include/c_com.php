<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$do = $_GET['do'];
if($do=='fahuo'){
    $ptlogid = intval($_GET['ptlogid']);
    $_GET['manage'] = 1;
    $v = C::t('#xigua_es#xigua_es_order')->fetch_G($ptlogid);
    $_GET['manage'] = 0;
    if($v){
        if(!$_GET['yundan_gs']||!$_GET['yundan']){
            hb_message(lang_es('qtxkdxx',0), 'error');
        }
        DB::update('xigua_es_order', array(
            'fa_ts' => TIMESTAMP,
            'yundan_gs' => $_GET['yundan_gs'],
            'yundan' => $_GET['yundan'],
        ), array(
            'id' => $ptlogid
        ));
        notification_add($v['uid'],'system', "<a href=\"{url}\">".$v['title'].lang_es('yfh',0).'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_es&ac=order_profile&ptlog_id='.$v['id']),1);
        hb_message(lang_es('fhcg',0), 'success', 'reload');
    }
}elseif($do=='shouhuo'){
    $es_config = $_G['cache']['plugin']['xigua_es'];
    if($es_config['autoconfirm'] && $_GET['autoconfirm']){
        if (discuz_process::islocked('esconfirm', 30)) {
            hb_message('lock', 'success', 'reload');
        }
        $dats = TIMESTAMP-($es_config['autoconfirm']*86400);
        $dd = DB::fetch_all('select * from %t where fa_ts>0 AND fa_ts<%d AND shou_ts<=1 AND yundan_gs!=\'\' limit 5', array('xigua_es_order', $dats));
        foreach ($dd as $index => $item) {
            $v = $old = $item;
            $ptlogid = $old['id'];
            $aff = C::t('#xigua_es#xigua_es_order')->update($ptlogid, array(
                'shou_ts' => TIMESTAMP,
                'shou_confirm_ts' => TIMESTAMP,
            ));
            if($aff && $old['shou_ts']<=1&& $old['shou_confirm_ts']<=1){
                $sxfee = $v['sxf'];
                $money = $v['pay_money']-$sxfee;

                global $_G;

                C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['seller_uid'], 'money', $money);
                C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
                    'uid'  => $v['seller_uid'],
                    'crts' => TIMESTAMP,
                    'size' => $money,
                    'note' => lang_es('ddh',0).$v['order_id'].'<br>'.lang_es('kcsxf',0).$sxfee,
                    'link' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
                ));
            }
            hb_message('qrshcg', 'success', 'reload');
        }
        hb_message('empty');
    }
    $ptlogid = intval($_GET['ptlogid']);
    $old = C::t('#xigua_es#xigua_es_order')->fetch($ptlogid);

    if($old['exp_method']=='kuaidi'){
        $aff = C::t('#xigua_es#xigua_es_order')->update_G($ptlogid, array(
            'shou_ts' => TIMESTAMP,
            'shou_confirm_ts' => TIMESTAMP,
        ));
    }else{
        $aff = C::t('#xigua_es#xigua_es_order')->update_G($ptlogid, array(
            'fa_ts' => TIMESTAMP,
            'shou_ts' => TIMESTAMP,
            'shou_confirm_ts' => TIMESTAMP,
        ));
    }
    if($aff && $old['shou_ts']<=1&& $old['shou_confirm_ts']<=1){
        $v = C::t('#xigua_es#xigua_es_order')->fetch($ptlogid);
        $sxfee = $v['sxf'];
        $money = $v['pay_money']-$sxfee;

        global $_G;

        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($v['seller_uid'], 'money', $money);
        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
            'uid'  => $v['seller_uid'],
            'crts' => TIMESTAMP,
            'size' => $money,
            'note' => lang_es('ddh',0).$v['order_id'].'<br>'.lang_es('kcsxf',0).$sxfee,
            'link' => "$SCRITPTNAME?id=xigua_es&ac=order_profile&ptlog_id={$v['id']}&manage=1".$urlext,
        ));

        hb_message(lang_es('qrshcg',0), 'success', 'reload');
    }
    hb_message(lang_es('qrshsb',0), 'error', 'reload');
}elseif ($do =='kd'){
    $host = "https://wuliu.market.alicloudapi.com";
    $path = "/kdi";
    $method = "GET";
    $appcode = $es_config['kdcode'];
    $headers = array();
    array_push($headers, "Authorization:APPCODE " . $appcode);
    $querys = "no=".$_GET['danhao'];
    $bodys = "";
    $url = $host . $path . "?" . $querys;//

    $curl = curl_init();
    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
    curl_setopt($curl, CURLOPT_URL, $url);
    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($curl, CURLOPT_FAILONERROR, false);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($curl, CURLOPT_HEADER, false);
//curl_setopt($curl, CURLOPT_HEADER, true); �粻���json, ������д��룬��ӡ����ͷ��״̬�롣
//״̬��: 200 ������400 URL��Ч��401 appCode���� 403 �������ꣻ 500 API���ܴ���
    if (1 == strpos("$".$host, "https://"))
    {
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
    }

    $ret = (curl_exec($curl));
    $ret = json_decode($ret, 1);
    $retHtml = '';
    if($ret['result']['list']){
        foreach ($ret['result']['list'] as $index => $item) {
            $item['status'] = diconv($item['status'], 'UTF-8', CHARSET);
            $retHtml .=<<<HTML
<label class="weui-cell">
    <div class="weui-cell__bd c3">
        <div class="f12 c6">{$item['time']}</div>
        <div class="f12">{$item['status']}</div>
    </div>
</label>
HTML;
        }
    }
    include template('xigua_hb:header_ajax');
    echo $retHtml;
    include template('xigua_hb:footer_ajax');
}