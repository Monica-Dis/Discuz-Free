<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_es_order extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_es_order';
        $this->_pk = 'id';

        parent::__construct(); /*dism �� taobao �� com*/
    }


    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        return DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        return DB::update($this->_table, $data, array(
            'id'  => $id,
        ));
    }

    public function fetch_G($id){
        global $_G;
        if($_GET['manage']){
            $r = DB::fetch_first('select * from %t WHERE id=%d AND seller_uid=%d', array(
                $this->_table,
                $id,
                $_G['uid'],
            ));
        }else{
            $r = DB::fetch_first('select * from %t WHERE id=%d AND uid=%d', array(
                $this->_table,
                $id,
                $_G['uid'],
            ));
        }
        $r = self::prepare($r);
        return $r;
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*', $need_user = 0, $need_sh = 0)
    {
        global $_G, $SCRITPTNAME,$urlext;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));

        $uids = $shids = array();


        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $uids[] = $item['uid'];
            $shids[] = $item['shid'];
        }
        if($need_user && $uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['username'] = $users[$item['uid']]['username'];
            }
        }
        return $result;
    }
    public function fetch_count_by_where($wherearr)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first("SELECT count(*) as cnt FROM " . DB::table($this->_table) . " $wheresql ");
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_by_gid($gid)
    {
        $ret = $this->fetch($gid);
        $ret = self::prepare($ret);


        return $ret;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        global $_G, $SCRITPTNAME,$urlext,$es_config;
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i:s', $v['crts']) : '';
            $v['pay_ts_u'] = $v['pay_ts']>0 ? date('Y-m-d H:i:s', $v['pay_ts']) : '';
            $v['shou_ts_u'] = $v['shou_ts']>0 ? date('Y-m-d H:i:s', $v['shou_ts']) : '';
            $v['tuicfm_ts_u'] = $v['tuicfm_ts']>0 ? date('Y-m-d H:i:s', $v['tuicfm_ts']) : '';
            $v['goodshot'] = unserialize($v['goodinfo']);

            if($v['order_id'] && $v['status'] == 1){
                $order_id = $v['order_id'];
                $info = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($v['gid'], 1);
                if($info['wancheng']||!$info){
                    $v['jumpurl'] = 'javascript:$.alert(\''.lang_es('ysc',0).'\');';
                }else{
                    $rl = urlencode($_G['siteurl'].$SCRITPTNAME."?id=xigua_es&ac=order_profile$urlext&ptlog_id=".$v['id']);
                    $v['jumpurl'] = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
                }
            }

            $v['allowtk'] = $v['needback'] = 0;
            if(!$_GET['manage'] && in_array($v['status'], array(2,6))){
                $v['allowtk']  = $v['shou_ts']<=0;
                $v['needback'] = $v['fa_ts']>0;
            }
        }
        return $v;
    }
}