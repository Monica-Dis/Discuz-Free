<?php

if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!is_file(DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php')) {
	exit('Please install <a href="https://dism.taobao.com/?plugins/xigua_hb.html">https://dism.taobao.com/?plugins/xigua_hb.html</a>');
}
if (empty($_G['cache']['plugin'])) {
	loadcache('plugin');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_es/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_es/function.php';
if (!$_G['cache']['plugin']['xigua_hb']['mkey']) {
	$_G['cache']['plugin']['xigua_hb']['mkey'] = $_G['cache']['plugin']['xigua_hs']['mkey'];
}
$config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $es_config['dftcolor'];
$data = array();
$ac = $_GET['ac'];
$do = $_GET['do'];
$gid = intval($_GET['gid']);
$aclist = array('index', 'add', 'list_item', 'view', 'cat', 'buy', 'order', 'order_li', 'order_profile', 'shisuan', 'my', 'mypub', 'cancel_order', 'tuihuo', 'com', 'savelog', 'myset', 'mycomment');
$aclist_login = array('add', 'buy', 'order', 'order_li', 'order_profile', 'my', 'mypub', 'cancel_order', 'tuihuo', 'com', 'savelog', 'myset', 'mycomment');
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
if (in_array($ac, $aclist_login) && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
if ($es_config['color']) {
	$config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $es_config['color'];
}
$esid = $es_config['esid'];
switch ($ac) {
	case 'savelog':
		$_GET['pubid'] = intval($_GET['pubid']);
		if ($_GET['view'] && submitcheck('pubid')) {
			$r = DB::result_first('select * from %t where uid=%d and toid=%d', array('xigua_hb_pubviewlog', $_G['uid'], $_GET['pubid']));
			if ($r) {
				DB::update('xigua_hb_pubviewlog', array('crts' => TIMESTAMP), array('uid' => $_G['uid'], 'toid' => $_GET['pubid']));
			} else {
				DB::insert('xigua_hb_pubviewlog', array('uid' => $_G['uid'], 'toid' => $_GET['pubid'], 'crts' => TIMESTAMP, 'ip' => 'view_es'));
			}
		}
		exit(0);
		break;
	case 'tuihuo':
		break;
	case 'cancel_order':
		$ordid = intval($_GET['ordid']);
		if (submitcheck('ordid')) {
			$_GET['manage'] = 1;
			$ov = C::t('#xigua_es#xigua_es_order')->fetch_G($ordid);
			$_GET['manage'] = 0;
			if (!$ov || $ov['status'] != 1) {
				hb_message('error', 'error');
			}
			C::t('#xigua_es#xigua_es_order')->update_G($ordid, array('status' => 4, 'tuicfm_ts' => TIMESTAMP, 'tui_ts' => TIMESTAMP));
			hb_message(lang_es('ddyqx', 0), 'success', 'reload');
		}
		break;
	case 'mypub':
		$navtitle = lang_es('wfbdbb', 0);
		if (!isset($_GET['stat'])) {
			$_GET['stat'] = 'display';
			$_GET['display'] = '1';
		}
		$back_to_overwrite = $SCRITPTNAME . '?id=xigua_es&ac=my' . $urlext;
		break;
	case 'my':
		$back_to_overwrite = $SCRITPTNAME . '?id=xigua_es&ac=my' . $urlext;
		switch ($_GET['do']) {
			case 'zuji':
				$navtitle = lang_es('wdzuji', 0);
				include template('xigua_es:zuji');
				exit(0);
				break;
			case 'fav':
				if ($_GET['ty'] == 'user') {
					$navtitle = lang_hb('wodeguanzhu', 0);
				} elseif ($_GET['ty'] == 'user') {
					$navtitle = lang_es('wdfensi', 0);
				} else {
					$navtitle = lang_es('wdfav', 0);
				}
				include template('xigua_es:my_fav');
				exit(0);
				break;
			default:
				$back_to_overwrite = $SCRITPTNAME . '?id=xigua_es' . $urlext;
				$navtitle = lang_es('wdes', 0);
				$custom_side = array($SCRITPTNAME . '?id=xigua_es&ac=myset', lang_hb('shzhi', 0));
				$qianbao = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
				$catcondition = '1';
				$where = array('uid=' . $_G['uid']);
				$_GET['cat_id'] = $esid;
				if ($_GET['cat_id']) {
					$cat_id = intval($_GET['cat_id']);
					$pids = array($cat_id);
					$catinfo = C::t('#xigua_hb#xigua_hb_cat')->get_childs_by_pids($cat_id);
					if ($catinfo) {
						foreach ($catinfo as $index => $item) {
							$pids[] = intval($item['id']);
						}
						if ($pids) {
							$where[] = $catcondition = 'catid IN(' . implode(',', $pids) . ') ';
						}
					} else {
						$where[] = $catcondition = 'catid=' . $cat_id;
					}
				}
				if ($_G['cookie']['es_tongji']) {
					$es_tongji = unserialize($_G['cookie']['es_tongji']);
					$totalpub = $es_tongji['totalpub'];
					$mysell = $es_tongji['mysell'];
					$mybuy = $es_tongji['mybuy'];
					$myfav = $es_tongji['myfav'];
					$myfavuser = $es_tongji['myfavuser'];
					$myfans = $es_tongji['myfans'];
					$myzujis = $es_tongji['myzujis'];
					$newpm = $es_tongji['newpm'];
				} else {
					$es_tongji['totalpub'] = $totalpub = C::t('#xigua_hb#xigua_hb_pub')->fetch_count_bypage($where);
					$es_tongji['mysell'] = $mysell = DB::result_first('select count(*) from %t where seller_uid=%d', array('xigua_es_order', $_G['uid']));
					$es_tongji['mybuy'] = $mybuy = DB::result_first('select count(*) from %t where uid=%d', array('xigua_es_order', $_G['uid']));
					$es_tongji['myfav'] = $myfav = DB::result_first('select count(*) from %t as a,%t as b where a.favid=b.id and a.favtype=\'pub\' and a.uid=%d AND b.' . $catcondition, array('xigua_hb_follow', 'xigua_hb_pub', $_G['uid']));
					$es_tongji['myfavuser'] = $myfavuser = DB::result_first('select count(*) from %t where uid=%d and favtype=%s', array('xigua_hb_follow', $_G['uid'], 'favuser'));
					$es_tongji['myfans'] = $myfans = DB::result_first('select count(*) from %t where favid=%d and favtype=%s', array('xigua_hb_follow', $_G['uid'], 'favuser'));
					$es_tongji['myzujis'] = $myzujis = DB::result_first('select count(*) from %t where uid=%d and ip=\'view_es\'', array('xigua_hb_pubviewlog', $_G['uid']));
					$es_tongji['newpm'] = $newpm = C::t('#xigua_hb#xigua_hb_comment')->fetch_type1_num();
					dsetcookie('es_tongji', serialize($es_tongji), 60);
				}
		}
		break;
	case 'shisuan':
		include template('xigua_hb:header_ajax');
		echo floatval($_GET['price']) + floatval($_GET['yf']);
		include template('xigua_hb:footer_ajax');
		break;
	case 'index':
		$navtitle = $es_config['pdmc'];
		$description = $es_config['share_desc'];
		$topnavslider = es_parse_set('topnavslider');
		if (!$esid) {
		}
		$listinfo = fetch_by_esid($esid);
		C::t('#xigua_hb#xigua_hb_cat')->init($listinfo);
		$list = C::t('#xigua_hb#xigua_hb_cat')->get_tree_array(0);
		$cat_list = $list[$esid]['child'];
		$jing_list = array_values($list[$esid]['child']);
		$numshow = $es_config['indexnav_1'] * 5;
		$widthshow = $es_config['indexnav_2'] > 0 ? 100 / $es_config['indexnav_2'] . '%' : '20%';
		$totalpub = total_es_pubs($list);
		$totalviews = total_es_views($list);
		$totalshares = total_es_order();
		break;
	case 'list_item':
		$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 20;
		$start_limit = ($page - 1) * $lpp;
		if ($_GET['inajax']) {
			$where = array();
			if ($_GET['is_my'] && $_G['uid'] > 0) {
				if ($_GET['stat'] == 'display') {
					$where = array('uid=' . $_G['uid'] . ' and display=' . intval($_GET['display']) . ' AND endts>' . TIMESTAMP);
				} elseif ($_GET['stat'] == 'endts') {
					$where = array('uid=' . $_G['uid'] . ' and endts<=' . TIMESTAMP);
				} elseif ($_GET['stat'] == 'digs') {
					$where = array('uid=' . $_G['uid'] . ' and display=1 AND endts>' . TIMESTAMP);
					if ($_GET['dstat'] == 'ing') {
						$where[] = 'dig_endts>' . TIMESTAMP;
						$ob = 'dig_endts ASC';
					} else {
						$where[] = 'dig_endts>0 AND dig_endts<' . TIMESTAMP;
					}
				} else {
					$where = array('uid=' . $_G['uid']);
				}
				if ($_GET['wancheng']) {
					$where[] = ' wancheng=1';
				}
			} else {
				$where = array('display=1 AND endts>' . TIMESTAMP);
			}
			$_GET['cat_id'] = $_GET['cat_id'] ? $_GET['cat_id'] : $esid;
			if ($_GET['cat_id']) {
				$cat_id = intval($_GET['cat_id']);
				$pids = array($cat_id);
				$catinfo = C::t('#xigua_hb#xigua_hb_cat')->get_childs_by_pids($cat_id);
				if ($catinfo) {
					foreach ($catinfo as $index => $item) {
						$pids[] = intval($item['id']);
					}
					if ($pids) {
						$where[] = ' catid IN(' . implode(',', $pids) . ') ';
					}
				} else {
					$where[] = ' catid=' . $cat_id;
				}
			}
			if ($_G['uid'] > 0 && $_GET['fav']) {
				$_lst = C::t('#xigua_hb#xigua_hb_follow')->fetch_all_by_page(array('favtype=\'pub\' AND uid=' . $_G['uid']), $start_limit, $lpp);
				$_tp = array();
				foreach ($_lst as $v) {
					$_tp[] = $v['favid'];
				}
				if ($_tp) {
					$where[] = ' id in (' . implode(',', $_tp) . ')';
				} else {
					$where[] = ' id=\'abc\' ';
				}
			}
			if ($_G['uid'] > 0 && $_GET['zuji']) {
				$_lst = DB::fetch_all('select toid from %t where uid=%d and ip=\'view_es\' ORDER BY crts DESC' . DB::limit($start_limit, $lpp), array('xigua_hb_pubviewlog', $_G['uid']));
				$_tp = array();
				foreach ($_lst as $v) {
					$_tp[] = $v['toid'];
				}
				if ($_tp) {
					$where[] = ' id in (' . implode(',', $_tp) . ')';
				} else {
					$where[] = ' id=\'abc\' ';
				}
			}
			if ($_GET['v1'] && $_GET['v2']) {
				$v_1 = stripsearchkey(addslashes($_GET['v1']));
				$v_2 = stripsearchkey(addslashes($_GET['v2']));
				$where[] = ' (vars LIKE \'%' . $v_1 . '%\' AND vars LIKE \'%' . $v_2 . '%\') ';
			}
			if ($_GET['keyword']) {
				$keyword = stripsearchkey(addslashes($_GET['keyword']));
				$where[] = ' (tags LIKE \'%' . $keyword . '%\' OR description LIKE \'%' . $keyword . '%\' OR vars LIKE \'%' . $keyword . '%\') ';
			}
			if ($_GET['keyword1']) {
				$keyword1 = stripsearchkey(addslashes($_GET['keyword1']));
				$where[] = ' vars LIKE \'%' . $keyword1 . '%\' ';
			}
			if ($_GET['keyword2']) {
				$keyword2 = stripsearchkey(addslashes($_GET['keyword2']));
				$where[] = ' vars LIKE \'%' . $keyword2 . '%\' ';
			}
			if ($_GET['filter']) {
				$where[] = C::t('#xigua_hb#xigua_hb_cat')->format_filter($cat_id);
			}
			if ($_GET['prange']) {
				$tmp = array_filter(explode('__', trim($_GET['prange'])));
				foreach ($tmp as $index => $item) {
					list($varid, $val) = explode('_', $item);
					$_prange[$varid . '_' . $val] = array('min' => $varid, 'max' => $val);
				}
				$_prange_keys = array_keys($_prange);
				$minhprice = $_prange[$_prange_keys[0]]['min'];
				$maxhprice = $_prange[$_prange_keys[0]]['max'];
				if ($minhprice || $maxhprice) {
					$where[] = ' price BETWEEN ' . $minhprice . ' AND ' . $maxhprice . ' ';
				} else {
					if ($_prange_keys[1]) {
						$minhprice = 0;
						$maxhprice = $_prange[$_prange_keys[1]]['max'];
						$where[] = ' price BETWEEN ' . $minhprice . ' AND ' . $maxhprice . ' ';
					}
				}
			}
			if ($_GET['province']) {
				$prov = stripsearchkey(addslashes($_GET['province']));
				$where[] = ' dist1 LIKE \'%' . $prov . '%\' ';
			}
			if ($_GET['city'] && $_GET['city'] != 0 - 1) {
				$city = stripsearchkey(addslashes($_GET['city']));
				$where[] = ' dist2 LIKE \'%' . $city . '%\' ';
			}
			if ($_GET['dist']) {
				$dst = stripsearchkey(addslashes($_GET['dist']));
				$where[] = ' dist3 LIKE \'%' . $dst . '%\' ';
			}
			if ($_GET['tag']) {
				$tag = stripsearchkey(addslashes($_GET['tag']));
				$where[] = ' (tags LIKE \'%' . $tag . '%\') ';
			}
			if ($orderby = $_GET['orderby']) {
				if ($orderby == 'hot') {
					$ob = ' views DESC ';
				} elseif ($orderby == 'new') {
					$ob = ' up_time DESC ';
				} elseif ($orderby == 'price_asc') {
					$ob = ' price ASC ';
				} elseif ($orderby == 'price_desc') {
					$ob = ' price DESC ';
				} else {
					$ob = '';
				}
			}
			if ($notpubid = intval($_GET['notpubid'])) {
				$where[] = ' id!=' . $notpubid;
			}
			if ($author_uid = intval($_GET['uid'])) {
				$where[] = ' uid=' . $author_uid;
			}
			$GLOBALS['disablest'] = !$es_config['openst'];
			$list = C::t('#xigua_hb#xigua_hb_pub')->fetch_all_bypage_pub($where, $start_limit, $lpp, $ob);
			$pubids = $catids = $uids = array();
			foreach ($list as $index => $item) {
				$uids[] = $item['uid'];
				$catids[] = $item['catid'];
				$pubids[] = $item['id'];
			}
			if ($uids) {
				$users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
				if ($_G['cache']['plugin']['xigua_hr']['showg']) {
					$veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids);
					$veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids, 2);
				}
				if ($_G['cache']['plugin']['xigua_hr']['showb']) {
					$bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
				}
			}
			if ($catids) {
				$cats = DB::fetch_all('SELECT id,`name`,icon,telpri,closeicon,hidereal FROM %t WHERE id IN (%n)', array('xigua_hb_cat', $catids), 'id');
			}
			include template('xigua_hb:header_ajax');
			include template('xigua_es:es');
			include template('xigua_hb:footer_ajax');
			exit(0);
		}
	case 'add':
		$listinfo = fetch_by_esid($esid);
		C::t('#xigua_hb#xigua_hb_cat')->init($listinfo);
		$list = C::t('#xigua_hb#xigua_hb_cat')->get_tree_array(0);
		$list = $list[$esid]['child'];
		$navtitle = lang_es('qxzbblb', 0);
		break;
	case 'cat':
		$pricerange = array_filter(explode("\n", trim($es_config['pricerange'])));
		foreach ($pricerange as $index => $item) {
			$pricerange[$index] = trim($item);
		}
		$cat_id = intval($_GET['cat_id']);
		if (!$cat_id) {
			$cat_id = $esid;
		}
		$catinfo = C::t('#xigua_hb#xigua_hb_cat')->fetch_by_catid($cat_id);
		$navtitle = $catinfo['name'];
		$pid = $catinfo['pid'];
		if ($_GET['keyword']) {
			$navtitle = $keyword = stripsearchkey(addslashes($_GET['keyword']));
		}
		$listinfo = fetch_by_esid($esid);
		C::t('#xigua_hb#xigua_hb_cat')->init($listinfo);
		$cat_tree_init = $cat_tree = C::t('#xigua_hb#xigua_hb_cat')->get_tree_array(0);
		$cat_tree = array_values($cat_tree);
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist0 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist0 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['province']) {
			$distname = $_GET['province'];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if (!$navtitle && $distname) {
			$navtitle = $distname . lang_hb('xinxi', 0);
		}
		if (!$distname) {
			$distname = lang_hb('plugins_edit_vars_type_area', 0);
		}
		if ($_GET['tag']) {
			$navtitle .= ' ' . $_GET['tag'];
		}
		$catname = $catinfo['name'] ? $catinfo['name'] : lang_hb('quanbu', 0);
		$orderby = $_GET['orderby'];
		$orderby_list = array('' => lang_hb('om', 0), 'price_asc' => lang_es('price_asc', 0), 'price_desc' => lang_es('price_desc', 0), 'new' => lang_es('new', 0), 'near' => lang_es('near', 0));
		if (!$navtitle) {
			$navtitle = ($orderby_list[$orderby] == lang_hb('om', 0) ? lang_hb('quanbu', 0) : $orderby_list[$orderby]) . lang_hb('xinxi', 0);
		}
		$subcat = $cat_tree;
		if ($pid == 0) {
			$subcats = $cat_tree_init[$cat_id]['child'];
		}
		$tag_childs = array_filter(explode("\n", trim($catinfo['tag'])));
		if ($catinfo['share_title']) {
			$anavtitle = $navtitle;
			$navtitle = $catinfo['share_title'];
		}
		if ($catinfo['share_desc']) {
			$description = $catinfo['share_desc'];
		}
		$get_tag = array();
		foreach ($_GET as $index => $item) {
			if ($index != 'tag') {
				$get_tag[$index] = $item;
			}
		}
		$query = http_build_query($get_tag);
		$vars = hb_vars($catinfo['id'], $catinfo['pid']);
		include_once DISCUZ_ROOT . 'source/plugin/xigua_es/include/cat.php';
		break;
	case 'view':
		$pubid = intval($_GET['pubid']);
		$info = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid, 1);
		$info['user'] = getuserbyuid($info['uid']);
		$date_last = intval((TIMESTAMP - $info['user']['regdate']) / 86400);
		$description = $navtitle = cutstr(str_replace(array("\n", "\r"), '', strip_tags($info['description'])), 80);
		$info['description'] = nl2br($info['description']);
		$info['hongbaolog'] = array();
		if ($_G['uid']) {
			$info['hongbaolog'] = C::t('#xigua_hb#xigua_hb_hongbaolog')->fetch_by_uid_pubid($_G['uid'], $pubid);
			$vots = C::t('#xigua_hb#xigua_hb_votelog')->fetch_by_uid_pubids($_G['uid'], array($pubid));
		}
		$v = $info;
		if ($config['sxlink']) {
			$shmember = getuserbyuid($v['uid']);
			$shavat = avatar($v['uid'], 'middle', true);
			$kflnk = str_replace(array('{uid}', '{username}', '{avatar}'), array($v['uid'], $shmember['username'], $shavat), $config['sxlink']);
		}
		$listinfo = fetch_by_esid($esid);
		C::t('#xigua_hb#xigua_hb_cat')->init($listinfo);
		$clist = C::t('#xigua_hb#xigua_hb_cat')->get_tree_array(0);
		$cat_list = $clist[$esid]['child'];
		$authorinfo = C::t('#xigua_hb#xigua_hb_user')->fetch($info['uid']);
		$totalpubs = intval($authorinfo['pubs']);
		$catinfo = C::t('#xigua_hb#xigua_hb_cat')->fetch_by_catid($v['catid']);
		$v = $info;
		if (!$info && !$_GET['do']) {
			dheader('location: plugin.php?id=xigua_es' . $urlext);
		}
		if ($catinfo['share_dig'] && $catinfo['share_dig_days'] || $catinfo['share_refresh'] > 0) {
			C::t('#xigua_hb#xigua_hb_pubviewlog')->doinsert($pubid, $info, $catinfo);
		}
		if ($config['fulltitle']) {
			$dsx = $description;
			$navtitle = $description = $dsx;
		}
		if (IN_APPBYME) {
			$navtitle = $description;
		}
		if (getcookie('miniprogram')) {
			$config['onlytimeline'] = 'no';
		}
		hb_auto_var();
		if ($catinfo['close_pl']) {
			$config['closepl'] = $catinfo['close_pl'];
		}
		if (!$_G['cache']['hb_ext_config']['subjectext']) {
			$navtitle = ($catinfo['name'] ? lang_hb('l', 0) . $catinfo['name'] . lang_hb('r', 0) : '') . $navtitle;
		}
		$px = $v['hb_money'] > 0 && $v['hb_num'] > $v['hb_sendnum'] ? $config['hbprefix'] : '';
		$navtitle = $px . $navtitle;
		$description = $px . $description;
		$vtpl = $_GET['view_tpl'] ? $_GET['view_tpl'] : 'es_v';
		$youfei = 0;
		$stock = $v['wancheng'] ? 0 : 1;
		$jymethod = 1;
		$subtit = $distvar = '';
		foreach ($v['vars'] as $index => $item) {
			if ($item['jiaoyi'] == 1) {
				$jiaoyi_price = floatval($item['value']);
				$v['vars'][$index] = '';
			} elseif ($item['jiaoyi'] == 3) {
				$you = $item;
				$youfei = floatval($you['value']);
				$v['vars'][$index] = '';
			} elseif ($item['jiaoyi'] == 2) {
				$shichang_price = floatval($item['value']);
				$v['vars'][$index] = '';
			} elseif ($item['jiaoyi'] == 4 && $item['value'] !== '') {
				$stock = intval($item['value']);
				$v['vars'][$index] = '';
			} elseif ($item['jiaoyi'] == 5) {
				$jymethod_ary = $item;
				$jymethod = $item['value'];
			}
			if ($item['autoin']) {
				$subtit = ' ' . $item['html'];
			}
			if ($item['type'] == 'location' && is_array($item['value']) && count($item['value']) == 3 && is_numeric($item['value'][2])) {
				$distvar = $item;
			}
		}
		if ($_GET['y']) {
			$jymethod = $_GET['y'];
		}
		$back_to_overwrite = $SCRITPTNAME . '?id=xigua_es&ac=cat&cat_id=' . $v['catid'] . $urlext;
		$vavatar = avatar($v['uid'], 'middle', 1);
		if ($_GET['do'] == 'buy') {
			$goodname = $navtitle;
			$navtitle = lang_es('qrdd', 0);
			$dft = C::t('#xigua_hb#xigua_hb_user_addr')->fetch_dft($_G['uid']);
			include template('xigua_es:buy');
		} else {
			include template('xigua_es:' . $vtpl);
		}
		exit(0);
		break;
	case 'buy':
		$pubid = intval($_GET['pubid']);
		if ($es_config['mustmobile']) {
			global $_G;
			global $config;
			global $SCRITPTNAME;
			$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			if (!$user['mobile']) {
				if ($_GET['inajax']) {
					hb_message(lang_hb('plzbind', 0), 'error', $SCRITPTNAME . '?id=xigua_hb&ac=myzl' . $GLOBALS['urlext']);
				} else {
					dheader('location: ' . $SCRITPTNAME . '?id=xigua_hb&ac=myzl&referer=' . urlencode(hb_currenturl()) . $GLOBALS['urlext']);
				}
			}
		}
		if (submitcheck('formhash')) {
			$v = $pubinfo = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid, 0);
			if ($pubinfo['wancheng']) {
				hb_message(lang_es('ysc', 0), 'error');
			}
			if ($_G['uid'] == $v['uid']) {
				hb_message(lang_es('bnzjgm', 0), 'error');
			}
			$form = $_GET['form'];
			if (!$form['exp_method']) {
				hb_message(lang_es('qxz', 0) . lang_es('psfs', 0), 'error');
			}
			if ($form['exp_method'] == 'kuaidi') {
				if (!($form['dist1'] . $form['dist2'] . $form['dist3'] . $form['address'])) {
					hb_message(lang_es('qszshdz', 0), 'error');
				}
				if (!$form['mobile']) {
					hb_message(lang_hb('mobile_tip', 0), 'error');
				}
			}
			$description = $navtitle = cutstr(str_replace(array("\n", "\r"), '', strip_tags($pubinfo['description'])), 80);
			if ($config['fulltitle']) {
				$dsx = $description;
				$navtitle = $description = $dsx;
			}
			hb_auto_var();
			$catinfo = C::t('#xigua_hb#xigua_hb_cat')->fetch_by_catid($pubinfo['catid']);
			if (!$_G['cache']['hb_ext_config']['subjectext']) {
				$navtitle = ($catinfo['name'] ? lang_hb('l', 0) . $catinfo['name'] . lang_hb('r', 0) : '') . $navtitle;
			}
			$stock = $v['wancheng'] ? 0 : 1;
			$jiaoyi_price = 0;
			foreach ($v['vars'] as $index => $item) {
				if ($item['jiaoyi'] == 1) {
					$jiaoyi_price = floatval($item['value']);
				} elseif ($item['jiaoyi'] == 3) {
					$you = $item;
					$youfei = floatval($you['value']);
				} elseif ($item['jiaoyi'] == 2) {
					$shichang_price = floatval($item['value']);
				} elseif ($item['jiaoyi'] == 4 && $item['value'] !== '') {
					$stock = intval($item['value']);
				}
			}
			if ($stock <= 0) {
				hb_message(lang_es('ysc', 0), 'error');
			}
			$totalprice = $jiaoyi_price + $youfei;
			if ($totalprice <= 0) {
				hb_message(lang_es('error_price', 0), 'error');
			}
			$title = $navtitle;
			$addrid = intval($form['addrid']);
			$sxfee = round($es_config['sxf'] / 100 * $totalprice, 2);
			$ptlog = array('crts' => TIMESTAMP, 'uid' => $_G['uid'], 'order_id' => '', 'unit_price' => $jiaoyi_price, 'pay_money' => $totalprice, 'sxf' => $sxfee, 'addrid' => $addrid, 'addr' => $form['dist1'] . $form['dist2'] . $form['dist3'] . $form['address'], 'mobile' => $form['mobile'], 'realname' => $form['realname'] ? $form['realname'] : $_G['username'], 'gid' => $pubid, 'goodinfo' => serialize($pubinfo), 'note' => $form['note'], 'yunfee' => $youfei, 'title' => $title, 'gnum' => 1, 'status' => 1, 'pay_endts' => 0, 'seller_uid' => $pubinfo['uid'], 'shid' => 0, 'exp_method' => $form['exp_method']);
			$ptlog_id = C::t('#xigua_es#xigua_es_order')->insert($ptlog, true);
			$location = $_G['siteurl'] . $SCRITPTNAME . ('?id=xigua_es&ac=order_profile&ptlog_id=' . $ptlog_id . $urlext);
			$ptlog['id'] = $ptlog_id;
			$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_es', array('data' => $ptlog, 'callback' => array('file' => 'source/plugin/xigua_es/function.php', 'method' => 'callback_es_pay', 'uid' => $_G['uid']), 'location' => $location, 'referer' => $SCRITPTNAME . '?id=xigua_es&ac=order_profile&ptlog_id=' . $ptlog_id . $urlext, 'tip' => ''), 0);
			C::t('#xigua_es#xigua_es_order')->update($ptlog_id, array('order_id' => $order_id));
			$rl = urlencode($location);
			$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
			hb_message(lang_es('jumppay', 0), 'loading', $jumpurl);
		}
		break;
	case 'order_profile':
		$ptlog_id = $_GET['ptlog_id'];
		if ($_GET['manage']) {
			$navtitle = lang_es('mcdbb', 0) . lang_es('ddxq', 0);
			$v = C::t('#xigua_es#xigua_es_order')->fetch_G($ptlog_id);
		} else {
			$navtitle = lang_es('mddbb', 0) . lang_es('ddxq', 0);
			$v = C::t('#xigua_es#xigua_es_order')->fetch_G($ptlog_id);
		}
		$back_to_overwrite = $SCRITPTNAME . '?id=xigua_es&ac=order&manage=' . $_GET['manage'] . $urlext;
		if (!$v) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_es&ac=order&mobile=2' . $urlext);
		}
		$v['goodinfo'] = unserialize($v['goodinfo']);
		$pubid = $v['gid'];
		$v['imglist'] = $v['goodinfo']['imglist'];
		$goodname = $v['title'];
		$jiaoyi_price = $v['unit_price'];
		$kflnkbuy = str_replace(array('{uid}', '{username}', '{avatar}'), array($v['uid'], $v['realname'], avatar($v['uid'], 'middle', 1)), $config['sxlink']);
		$kflnksell = str_replace(array('{uid}', '{username}', '{avatar}'), array($v['seller_uid'], $v['realname'], avatar($v['seller_uid'], 'middle', 1)), $config['sxlink']);
		if (!IN_QIANFAN && !IN_MAGAPP && ($config['magapp_secret'] || $config['hostname'])) {
			$kflnkbuy = $SCRITPTNAME . '?id=xigua_hb&ac=chat&touid=' . $v['uid'];
			$kflnksell = $SCRITPTNAME . '?id=xigua_hb&ac=chat&touid=' . $v['seller_uid'];
		}
		$showseller = getuserbyuid($v['seller_uid']);
		$showseller['realname'] = $v['goodinfo']['realname'];
		$showseller['mobile'] = $v['goodinfo']['mobile'] ? $v['goodinfo']['mobile'] : '';
		if (!$showseller['mobile']) {
			$qianbao = C::t('#xigua_hb#xigua_hb_user')->fetch($v['seller_uid']);
			$showseller['mobile'] = $qianbao['mobile'];
		}
		if (!$showseller['mobile']) {
			$__profile = C::t('common_member_profile')->fetch($v['seller_uid']);
			$showseller['mobile'] = $__profile['mobile'];
		}
		if ($v['exp_method'] == 'daodian') {
			$distvar = '';
			foreach ($v['goodinfo']['vars'] as $index => $item) {
				if ($item['type'] == 'location' && is_array($item['value']) && count($item['value']) == 3 && is_numeric($item['value'][2])) {
					$distvar = $item;
					break;
				}
			}
		}
		break;
	case 'order':
		$navtitle = lang_es('wddd1', 0);
		if ($_GET['manage']) {
			$navtitle = lang_es('ddgl1', 0);
		}
		$keyword = stripsearchkey($_GET['keyword']);
		break;
	case 'order_li':
		$wherearr = array();
		$order = 'id DESC';
		if ($_GET['manage']) {
			$wherearr[] = 'seller_uid=' . $_G['uid'];
		} else {
			$wherearr[] = 'uid=' . $_G['uid'];
		}
		if ($_GET['status']) {
			$sta = dintval(explode(',', $_GET['status']), 1);
			$wherearr[] = 'status IN ( ' . implode(',', $sta) . ' )';
		}
		if ($_GET['shou_ts'] == 0 - 1) {
			$wherearr[] = 'shou_ts=-1';
		} elseif ($_GET['shou_ts'] == 1) {
			$wherearr[] = 'shou_ts>1';
		}
		if ($_GET['fa_ts'] == 0 - 1) {
			$wherearr[] = 'fa_ts=-1';
		} elseif ($_GET['fa_ts'] == 1) {
			$wherearr[] = 'fa_ts>1';
		}
		if ($_GET['tk'] == 1) {
			$order = 'refund_id DESC';
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (title LIKE \'%' . $keyword . '%\' OR order_id LIKE \'%' . $keyword . '%\' OR mobile like \'%' . $keyword . '%\' OR realname like \'%' . $keyword . '%\') ';
		}
		$list = C::t('#xigua_es#xigua_es_order')->fetch_all_by_where($wherearr, $start_limit, $lpp, $order, '*', 1);
		foreach ($list as $index => $item) {
			$item['goodinfo'] = unserialize($item['goodinfo']);
			$list[$index]['imglist'] = $item['goodinfo']['imglist'];
		}
		if ($_GET['manage']) {
			$showbuyer = 1;
		} else {
			$showbuyer = 1;
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_es:' . $ac);
		include template('xigua_hb:footer_ajax');
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
$ac_file = DISCUZ_ROOT . ('source/plugin/xigua_es/include/c_' . $ac . '.php');
if (is_file($ac_file)) {
	include_once $ac_file;
}
include template('xigua_es:' . $ac);