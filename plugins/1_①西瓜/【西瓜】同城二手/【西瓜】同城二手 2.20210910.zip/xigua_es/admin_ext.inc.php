<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_es/common.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_es/function.php';
$_GET['plu'] = 'xigua_es';
$config_ary_merge = array();

$config_ary = array(
    'share_icon' => array('type' => 'filetext', 'lang' => lang_es('share_icon',0),'comment' => lang_es('w200',0)),
    'logoindex' => array('type' => 'filetext', 'lang' => lang_es('logoindex',0)),
);

for($i=1;$i<=5;$i++){
    $config_ary['topnavslider_pic'.$i] = array('type' => 'filetext', 'lang' => lang_es('topnavslider_pic',0).$i);
    $config_ary['topnavslider_link'.$i]= array('type' => 'text', 'lang' => lang_es('topnavslider_link',0).$i);
}

$config_ary = array_merge($config_ary, $config_ary_merge);

if(submitcheck('formhash')){
    $editform = $_GET['editform'];
    $_newimglist = hb_uploads($_FILES['editform']);
    foreach ($_newimglist as $__k => $__v) {
        if ($__v['errno'] == 0) {
            $editform[$__k] = $__v['error'];
        }elseif(isset($editform[$__k])){
            cpmsg($__v['error'], "action=plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_ext&plu=".$_GET['plu'], 'error');
        }
    }
    savecache('es_ext_setting', $editform);
    cpmsg(lang_hb('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_ext&plu=".$_GET['plu'], 'succeed');
}else{
    $link = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_ext&plu=";
    echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?123\" /><style>.naver{border-bottom:1px solid;height:40px;padding:0;display:block;background:#3a4b59}
.btn_var:hover{text-decoration:none;font-weight:700}
.btn_var{margin:0 0 0 10px;padding:0 5px;text-decoration:none;height:39px;line-height:39px;font-size:14px;float:left;display:block;color:#fff}
.btn_var.cur{font-weight:700;background:#3a4b59;color:#fff;border-bottom:2px solid #fd971e}
</style>";
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_es&pmod=admin_ext&plu=".$_GET['plu'], 'enctype');
    showtableheader();
    loadcache('es_ext_setting');
    foreach ($config_ary as $index => $item) {
        $val = $_G['cache']['es_ext_setting'][$index];
        if($val == array()){
            $val = '';
        }
        if(!$val){
            $val = $item['value'];
        }
        if($item['lang']){
            $varlang = $item['lang'];
        }else{
            $varlang = lang_es($index, 0);
            if(preg_match('/(\w+)(\d+)/is', $varlang, $ms)){
                $varlang = lang_es($ms[1], 0).' '.$ms[2];
            }
        }
        if($item['type']=='filetext' && $val){
            $item['comment'] .= ($item['comment']?'<br>':''). '<img style="height:30px;" src="'.$val.'" onerror="this.error=null;this.style.display=\'none\'" />';
        }
        if($item['type']=='mselect'){
            showsetting($varlang, array("editform[$index][]", $item['selects']), $val, $item['type'], '', 0, $item['comment']);
        }else{
            showsetting($varlang, "editform[$index]", $val, $item['type'], '', 0, $item['comment']);
        }
    }
    showsubmit('varsubmit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
}
