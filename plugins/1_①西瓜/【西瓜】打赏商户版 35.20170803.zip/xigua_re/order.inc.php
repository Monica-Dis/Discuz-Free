<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

if(submitcheck('clear')){
    $r = C::t('#xigua_re#xgre_order')->clear_order();
    if($r){
        cpmsg(lang('plugin/xigua_re', 'clear_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_re&pmod=order&page=".$_GET['page'], 'succeed');
    }
}
if(submitcheck('permsubmit')){
    $r = C::t('#xigua_re#xgre_order')->delete_order($_GET['delete']);
    if($r){
        cpmsg(lang('plugin/xigua_re', 'delete_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_re&pmod=order&page=".$_GET['page'], 'succeed');
    }
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_re&pmod=order&page=".$_GET['page']);
showtableheader(lang('plugin/xigua_re','dorder'));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_re','del'),
    lang('plugin/xigua_re','orderid'),
    lang('plugin/xigua_re','wenzhangming'),
    lang('plugin/xigua_re','orderprice'),
    lang('plugin/xigua_re','shouxf'),
    lang('plugin/xigua_re','shouru'),
    lang('plugin/xigua_re','fuk'),
    lang('plugin/xigua_re','status'),
    lang('plugin/xigua_re','crts'),
    lang('plugin/xigua_re','upts'),
));
$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;
$res = C::t('#xigua_re#xgre_order')->fetch_all_bypage($start_limit, $lpp, " paystatus=". table_xgre_order::PAYSUCCESS);
$icount = C::t('#xigua_re#xgre_order')->fetch_count_bypage(" paystatus=". table_xgre_order::PAYSUCCESS);

foreach ($res as $v) {
    if($v['fromuid']){
        $uids[$v['fromuid']] = $v['fromuid'];
    }
    if($v['touid']){
        $uids[$v['touid']] = $v['touid'];
    }
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}

foreach ($res as $re) {
    $re['getprice'] = $re['paystatus'] ? sprintf('%.2f', ($re['baseprice']-$re['getprice'])/100) : '-';
    $re['baseprice'] = sprintf('%.2f', $re['baseprice']/100);

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='{$re['order_id']}' />",
        $re['order_id'],
        "<a href='{$re['url']}' target='_blank'>{$re['subject']}</a>",
        $re['baseprice'],
        $re['getprice'],
        $users[$re['touid']] ?$users[$re['touid']]['username']: $re['toopenid'],
        $re['fromwx'] ? '<img style="width:20px;height:20px;vertical-align:middle" src="'.$re['fromwximg'].'"/> '.$re['fromwx'] : ($users[$re['fromuid']] ?$users[$re['fromuid']]['username']: ($re['fromopenid'] ? $re['fromopenid'] : lang('plugin/xigua_re','niming'))),
        $re['paystatus'] ? '<strong style="color:forestgreen;">'.(lang('plugin/xigua_re','yi')) .'</strong>' : '<strong style="color:orangered;">'.(lang('plugin/xigua_re','wei')) .'</strong>',
        date('m-d H:i:s', $re['crts']),
        $re['payupts'] ? date('m-d H:i:s', $re['payupts']) : '-',
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_re&pmod=order&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '<input type="hidden" name="clear" id="clear" value="0" /><input type="button" class="btn" onclick="$(\'clear\').value=1;$(\'cpform\').submit();" value="'.(lang('plugin/xigua_re','qingli')) .'">',$multipage);
showtablefooter(); /*Dism_taobao_com*/
showformfooter(); /*dism��taobao��com*/