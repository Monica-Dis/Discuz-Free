<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

include_once DISCUZ_ROOT.'./source/plugin/xigua_re/common.php';


$cookie = substr(md5('rewechatopenid'.$_G['siteurl'].WX_APPID.WX_MCHID.WX_APPSECRET), 0, 8);
$config['jin'] = explode(',', trim($config['jin']));
foreach ($config['jin'] as $item) {
    if ($item > 0) {
        $configary[] = $item;
    }
}

$touid = intval($_GET['uid']);
$touser = getuserbyuid($touid);
$toavatar = avatar($touid, 'big', true);
$navtitle = $config['linkword'] . $touser['username'];

$user = C::t('#xigua_re#xgre_user')->fetch_user($touid);
$toopenid = $user['openid'];
if(!$toopenid){
    if($config['needopenid']) {
        dheader('Location:'.dreferer());
        exit;
    }
}

if($_GET['tid']){
    $_GET['subject'] = DB::result_first('select subject from %t where tid=%d', array('forum_thread', $_GET['tid']));
}

if($_GET['url']){
    $_SERVER['HTTP_REFERER'] = $_GET['url'];
}

$color = $config['linkcolor'] ? $config['linkcolor'] : '#D75847';
$tools = new JsApiPay();
if($_GET['ac'] =='pc' && !IN_WECHAT){

    $price = round($_GET['price'], 2);
    if(!$price){
        $subject = $_GET['subject'];
        $postid  = $_GET['postid'];
        $url     = $_GET['url'];
        include_once template('xigua_re:pay3');
    }

    $order_id = C::t('#xigua_re#xgre_order')->get_order_id(
        $fromopenid, $_G['uid'], $touid, $toopenid,
        $price*100,
        $_GET['subject'], $_GET['url'],$_GET['postid'], $_G['cookie']['rewxnickname'], $_G['cookie']['rewxheadimgurl']
    );
    if(!$order_id){
        exit('order_id empty!');
    }
    $body = diconv($navtitle, CHARSET, 'UTF-8');

    $notify = new NativePay();
    $input = new WxPayUnifiedOrder();
    $input->SetBody($body);
    $input->SetAttach($body);
    $input->SetOut_trade_no($order_id);
    $input->SetTotal_fee($price*100);
    $input->SetTime_start(date("YmdHis"));
//    $input->SetTime_expire(date("YmdHis", time() + 3600));
    $input->SetGoods_tag($body);
    $input->SetNotify_url($_G['siteurl']. 'source/plugin/xigua_re/notify_wx.php');
    $input->SetTrade_type("NATIVE");
    $input->SetProduct_id($order_id);
    $result = $notify->GetPayUrl($input);
    $url2 = $result["code_url"];

    if(!$url2){
        $img = diconv($result['return_msg'],'UTF-8',CHARSET );
    }else{
        if(class_exists('QRcode')){
            $qrfile = 'source/plugin/xigua_re/cache/o'.$order_id.'.png';
            QRcode::png($url2, DISCUZ_ROOT.$qrfile, QR_ECLEVEL_L, 3);
            $src = $_G['siteurl'].$qrfile;
        }else{
            $src= 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text='.urlencode($url2);
        }
        $errorsrc= 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text='.urlencode($url2);
        $img =  "<img src='$src' onerror=\"this.error=null;this.src='$errorsrc'\" class=\"payqrcode\" /><p class=\"xg1\" style='margin:10px auto!important;'>".lang('plugin/xigua_re', 'sao')."</p>";
    }
    include_once template('xigua_re:pay2');
    exit;
}
elseif($_GET['ac'] == 'jsApi'){

    if(isset($_GET['index']) && isset($configary[$_GET['index']])){
        $price = $configary[$_GET['index']];
    }else{
        $price = round($_GET['price'], 2);
    }

    $fromopenid = $openid = $_G['cookie'][$cookie] ? authcode($_G['cookie'][$cookie], 'DECODE', $authkey) : '';

    if(!$openid && IN_WECHAT){
        exit(json_encode(array('error' => 'openid empty!')));
    }
    $_GET['url'] = str_replace('&mobile=2', '', $_GET['url']);
    $order_id = C::t('#xigua_re#xgre_order')->get_order_id(
        $fromopenid, $_G['uid'], $touid, $toopenid,
        $price*100,
        $_GET['subject'], $_GET['url'],$_GET['postid'], $_G['cookie']['rewxnickname'], $_G['cookie']['rewxheadimgurl']
    );
    if(!$order_id){
        exit(json_encode(array('error' => 'order_id empty!')));
    }

    $body = diconv($navtitle, CHARSET, 'UTF-8');
    $input = new WxPayUnifiedOrder();
    $input->SetBody($body);
    $input->SetAttach($body);
    $input->SetOut_trade_no($order_id);
    $input->SetTotal_fee($price*100);
    $input->SetTime_start(date("YmdHis"));
//    $input->SetTime_expire(date("YmdHis", time() + 3600));
    $input->SetGoods_tag($body);
    $input->SetNotify_url($_G['siteurl']. 'source/plugin/xigua_re/notify_wx.php');
    if(IN_WECHAT){
        $input->SetTrade_type("JSAPI");
        $input->SetOpenid($openid);
        $order = WxPayApi::unifiedOrder($input);
        $jsApiParameters = $tools->GetJsApiParameters($order);
        echo $jsApiParameters;
    }else{
        $input->SetTrade_type("MWEB");
        $input->SetProduct_id($order_id);
        $input->values['spbill_create_ip'] = re_clientip();
        $result = WxPayApi::unifiedOrder($input);
        $data = array('error' => 0,);
        if($result['return_code'] =='SUCCESS' && $result['result_code'] == 'SUCCESS'){
            $data['mweb_url'] = $result['mweb_url'].'&redirect_url='.urlencode($_SERVER['HTTP_REFERER']);
        }else{
            $data['error'] = $result['return_msg']."({$result['return_code']})";
        }
        echo json_encode($data);
    }
    exit;
}
else{

    if(!$_G['uid']){
        $openid = $_G['cookie'][$cookie] ? authcode($_G['cookie'][$cookie], 'DECODE', $authkey) : '';
        if(!$openid){
            $opendata = $tools->GetOpenid();
            if($openid = $opendata['openid']){
                dsetcookie($cookie, authcode($openid, 'ENCODE', $authkey), 7100);
                dsetcookie('reaccesstoken', authcode($opendata['access_token'], 'ENCODE', $authkey), 7200);
            }
        }
        $wxuser = $tools->getUserInfoById(authcode($_G['cookie']['reaccesstoken'], 'DECODE', $authkey), $openid);
    }else{
        $openid = $_G['cookie'][$cookie] ? authcode($_G['cookie'][$cookie], 'DECODE', $authkey) : '';
        if(!$openid && IN_WECHAT){
            $opendata = $tools->GetOnlyOpenid();
            if($openid = $opendata['openid']){
                dsetcookie($cookie, authcode($openid, 'ENCODE', $authkey), 7100);
            }
        }
        $wxuser = array(
            'nickname'   => diconv($_G['username'], CHARSET,'UTF-8'),
            'headimgurl' => avatar($_G['uid'], 'middle', true),
        );
    }
    if($_GET['tid']){
        $_SERVER['HTTP_REFERER'] = $_G['siteurl'].'forum.php?mod=viewthread&tid='.$_GET['tid'];
    }

    $nickname = diconv($wxuser['nickname'],'UTF-8', CHARSET);
    $nickname && dsetcookie('rewxnickname', $nickname, 86400);
    $wxuser['headimgurl'] && dsetcookie('rewxheadimgurl', $wxuser['headimgurl'], 86400);


    $apple = 0;
    if(strpos($_SERVER['HTTP_USER_AGENT'], 'iPhone')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPad')||strpos($_SERVER['HTTP_USER_AGENT'], 'iPod')){
        $apple = 1;
    }

    if($config['tpl']==1){
        include_once template('xigua_re:choose');
    }else{
        include_once template('xigua_re:choose2');
    }

}



