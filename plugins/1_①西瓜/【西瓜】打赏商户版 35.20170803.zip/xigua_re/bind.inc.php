<?php

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

require_once DISCUZ_ROOT.'./source/plugin/xigua_re/common.php';

$authkey = $_G['config']['security']['authkey'];

$de = authcode($_GET['ba'], 'DECODE', $authkey);
list($uid, $bindauth) = explode("\t", $de);
if(!$uid || !$bindauth){
    exit('Access Denied.');
}

$user = C::t('#xigua_re#xgre_user')->fetch_by_uid_bindauth($uid, $bindauth);

$tools = new JsApiPay();

$openid = $_G['cookie'][$cookie] ? authcode($_G['cookie'][$cookie], 'DECODE', $authkey) : '';
if(!$openid){
    $opendata = $tools->GetOpenid();
    if($openid = $opendata['openid']){
        dsetcookie($cookie, authcode($openid, 'ENCODE', $authkey), 7100);
        dsetcookie('reaccesstoken', authcode($opendata['access_token'], 'ENCODE', $authkey), 7200);
    }
}
$wxuser = $tools->getUserInfoById(authcode($_G['cookie']['reaccesstoken'], 'DECODE', $authkey), $openid);


if($wxuser['errcode']){
    $error = $wxuser;
    print_r($error);
}else{
    foreach ($wxuser as $index => $item) {
        $wxuser[$index] = diconv($wxuser[$index], 'utf-8');
    }
    $ret = C::t('#xigua_re#xgre_user')->update($uid, array(
        'openid' => $openid,
        'wxuser' => serialize($wxuser),
    ));
    if($ret){
        dheader('Location: home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=wxpay');
    }
}
