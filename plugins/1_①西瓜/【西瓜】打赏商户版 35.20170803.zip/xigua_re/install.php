<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
	exit('Access Denied');
}

$sql = <<<EOF

CREATE TABLE IF NOT EXISTS `pre_xgre_order` (
  `order_id` char(24) NOT NULL,
  `baseprice` int(11) unsigned NOT NULL,
  `getprice` int(11) NOT NULL DEFAULT '0',
  `touid` int(11) unsigned NOT NULL,
  `toopenid` varchar(80) NOT NULL,
  `paystatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `crts` int(11) unsigned NOT NULL,
  `payupts` int(11) unsigned NOT NULL,
  `sendstatus` tinyint(1) unsigned NOT NULL DEFAULT '0',
  `fromuid` int(11) NOT NULL,
  `fromopenid` char(32) NOT NULL,
  `sendupts` int(11) NOT NULL,
  `subject` varchar(200) NOT NULL,
  `url` varchar(200) NOT NULL,
  `postid` varchar(80) NOT NULL,
  `fromwx` varchar(200) NOT NULL,
  `fromwximg` varchar(200) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xgre_tixian` (
  `tixianid` char(24) NOT NULL,
  `amount` int(11) NOT NULL,
  `crts` int(11) NOT NULL,
  `return_msg` varchar(200) NOT NULL,
  `err_code_des` varchar(500) NOT NULL,
  `return_code` varchar(20) NOT NULL,
  `openid` char(32) NOT NULL,
  `uid` int(11) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xgre_user` (
  `uid` int(11) unsigned NOT NULL,
  `bindauth` varchar(32) NOT NULL,
  `openid` char(32) NOT NULL,
  `wxuser` varchar(2000) NOT NULL DEFAULT '',
  `total` int(10) NOT NULL DEFAULT '0',
  `settled` int(10) NOT NULL DEFAULT '0',
  `notsettled` int(10) NOT NULL DEFAULT '0',
  `times` int(10) unsigned NOT NULL DEFAULT '0',
  `word` varchar(200) NOT NULL DEFAULT ''
) ENGINE=InnoDB;

ALTER TABLE `pre_xgre_order`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `paystatus` (`paystatus`,`payupts`),
  ADD KEY `postid` (`postid`);

ALTER TABLE `pre_xgre_tixian`
  ADD PRIMARY KEY (`tixianid`);

ALTER TABLE `pre_xgre_user`
  ADD PRIMARY KEY (`uid`),
  ADD KEY `openid` (`openid`);
        
EOF;

runquery($sql);

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/xigua_re/discuz_plugin_xigua_re.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_re/discuz_plugin_xigua_re_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_re/discuz_plugin_xigua_re_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_re/discuz_plugin_xigua_re_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_re/discuz_plugin_xigua_re_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_re/install.php');