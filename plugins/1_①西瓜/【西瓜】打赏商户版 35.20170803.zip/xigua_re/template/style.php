<?php exit('Access denied!');?>
{block html}
<style>
.cl:after { content: "."; display: block; height: 0; clear: both; visibility: hidden; } .cl { zoom: 1; }
.rebtnw a:hover{text-decoration:none;box-shadow:1px 1px 3px #ccc}
.rebtnw a{display:inline-block;height:38px;line-height:38px;padding:0 25px;font-size:16px;text-align: center;margin:0 auto;vertical-align: middle;color: #fff;border-radius: 40px;background:$color}
.rebtnw{padding:10px 0;text-align: center;width:100%;}
.reword{ $reword}
.relist p{font-size:16px;text-align:center;color:#909090}
.relist p a{color:#627C97;font-size:16px}
.relist ul{width:272px;margin:10px auto!important;text-align:center}
.relist ul li{ $relistli;list-style-type:none!important;}
.relist ul li img{width:28px;height:28px;display:block}
.rexg{margin:10px auto;padding:10px;}
</style>
{/block}