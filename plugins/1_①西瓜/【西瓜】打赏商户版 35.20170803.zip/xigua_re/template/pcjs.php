<?php exit('Access denied!');?>
{block pcjs}
<script>
    function showprconfirm(title,uid,subject,postid,url){
        var notice = '<style>.alert_info{padding-left:0;background:none}</style>' +
            '<div class="c altw"><div class="alert_info"><p><style>.alert_info{padding-left:0;background:none}</style></p><div class="cl" style="margin-top:10px;text-align:center" id="inputqrw"><input id="inputqr" class="px" type="number" name="amount" autocomplete="off" value="1"> $yuan</div><p></p></div></div><p class="o pns"><span class="z xg1">$wuhui</span><button id="fwin_dosubmit" value="true" class="pn pnc"><strong>$lijida</strong></button><button id="fwin_dialog_cancel" value="true" class="pn" onclick="hideMenu(\'fwin_dialog\', \'dialog\')"><strong>$guanbi</strong></button></p>';
        showDialog(notice, 'info', title,null,1);
        $('fwin_dosubmit').onclick = function(){
            var price = $('inputqr').value;
            if(! /^[0-9]+\.{0,1}[0-9]{0,2}$/.test(price)){
                alert('$qing');
                $('inputqr').focus();
                return true;
            }
            ajaxget('plugin.php?id=xigua_re:index&ac=pc&uid='+uid+'&price='+price+'&subject='+subject.toString()+'&postid='+postid+'&url='+url, 'inputqrw');
            return true;
        }
    }
</script>
{/block}
