<?php exit('xxxx');?>
{block html}
<!--{loop $ranklist $k $v}-->
<li class="clear">
    <span class="rank_grade rank<!--{if $v[index]<=4}-->$v[index]<!--{else}-->n<!--{/if}-->">$v[index]</span>
    <a href="{$v[link]}" class="rank_user">
        <img class="rank_bar_face" src="{$v[avatar]}">
    </a>
    <div class="rank_bar_info_wrap">
        <p class="rank_bar_name">
            <a href="{$v[link]}">
                $v['username']
                <!--{if ($v['gender'] == 1)}-->
                <i class="fa fa-man"></i>
                <!--{elseif ($v['gender'] == 2)}-->
                <i class="fa fa-woman"></i>
                <!--{/if}-->
            </a>
        </p>

        <p class="rank_bar_today_topic">
            {$v[str]}
        </p>
    </div>
</li>
<!--{/loop}-->
{/block}