<?php exit('xxxx');?>
<!doctype html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>$navtitle</title>
    <link href="source/plugin/xigua_re/static/xigua.css?112" rel="stylesheet" />
    <script src="source/plugin/xigua_re/static/jquery-1.11.3.min.js"></script>
</head>
<body>


<div class="wrap rank_tab">

    <div class="rank_info"><h4><i class="fa-icon fa gold"></i>$navtitle</h4></div>
    <div id="rankList" class="rank_list section-1px">
        <ul id="rankBarList" class="rank_bar_list">
            <li id="loadmore">
                <a href="javascript:;">more</a>
            </li>
        </ul>
    </div>
</div>
<script>
    $(function () {
        var page = 1;
        $('#loadmore a').on('click', function () {
            $.get('plugin.php?id=xigua_re:rank&inajax=1&type={$_GET['type']}&page='+page, function (data) {
                $(data).insertBefore($('#loadmore'));
                page ++;
            });
        });
        $('#loadmore a').trigger('click');

        jQuery(window).scroll(function () {
            var top = (jQuery(document).height() - jQuery(this).scrollTop() - jQuery(this).height());
            if (top<20) {
                $('#loadmore a').trigger('click');
            }
        });
    });

</script>
</body>
</html>
