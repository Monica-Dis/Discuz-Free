<?php exit('11');?>
<link href="source/plugin/xigua_re/static/pcset.css" rel="stylesheet" />
<div class="cl pcset">
    <ul class="tb cl">
        <li {if $_GET[type]=='basic'}class="a"{/if}><a href="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting">{lang xigua_re:basic}</a></li>
        <li {if $_GET[type]=='wxpay'}class="a"{/if}><a href="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=wxpay">{lang xigua_re:wxpay}</a></li>
<!--        <li {if $_GET[type]=='alipay'}class="a"{/if}><a href="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=alipay">{lang xigua_re:alipay}</a></li>-->
        <!--        <li {if $_GET[type]=='qqpay'}class="a"{/if}><a href="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=qqpay">{lang xigua_re:qqpay}</a></li>-->
        <li {if $_GET[type]=='qr'}class="a"{/if}><a href="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=qr">{lang xigua_re:huoqu}</a></li>
        <!--{if $config[default_UID]==$_G[uid]}-->
        <li class="y">{lang xigua_re:def}</li>
        <!--{/if}-->
    </ul>
    <div class="cl avatar-badge-list">
            <!--{if in_array($_GET[type], array('wxpay','alipay','qqpay')) }-->
        <div class="E_inner_frame cl p10">
            <div class="WB_cardwrap S_bg2">
                <div class="EM_reward_overview">
                    <div class="WB_cardtitle_b S_line2">
                        <div class="newPay_tip S_link1">
                            <!--{if $isbind}-->
                            <strong class="xi2">{lang xigua_re:habind}</strong>
                            <!--{else}-->
                            <strong class="xi1">{echo lang('plugin/xigua_re','scan');}</strong>
                            <!--{/if}-->
                        </div>
                    </div>
                    <div class="WB_innerwrap">
                        <!--{if $isbind}-->

                            <form action="" method="post" onsubmit="return submitconfir();">
                                <input type="hidden" name="formhash" value="{FORMHASH}">
                                <input type="hidden" name="unbind" value="1">
                            <!--{if $wxuser[nickname]}--><p class="wxbox">
                                <img class="avatarwx" src="{$wxuser[headimgurl]}" />
                                <span>{$wxuser[nickname]}</span>
                            </p><!--{/if}-->
                            <button type="submit" name="unbindsubmit" value="yes" class="pn pnc"><strong>{lang xigua_re:dounbind}</strong></button>
                            </form>
                            <script>
                                function submitconfir(){
                                    if(confirm('{lang xigua_re:confir}')){
                                        return true;
                                    }
                                    return false;
                                }
                            </script>

                        <!--{else}-->
                        <img src="$qrurl" onerror="this.error=null;this.src='{$errorqrurl}'" />
                        <script>
                            var isbind= 0;
                            setInterval(function(){
                                ajaxget('home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=wxpay&checkbind=1');
                                if(isbind){
                                    window.location.reload();
                                }
                            }, 2000);
                        </script>
                        <!--{/if}-->
                    </div>
                </div>
            </div>
        </div>
            <!--{elseif $_GET[type]=='basic'}-->

                <div class="E_inner_frame cl p10">
                    <div class="WB_cardwrap S_bg2">
                        <div class="EM_reward_overview">
                            <div class="WB_cardtitle_b S_line2">
                                <div class="newPay_tip S_link1">
                                    <strong class="xi1">{echo sprintf(lang('plugin/xigua_re','notice'), $config[min_t], $config[bili]);}</strong>
                                </div>
                            </div>
                            <div class="WB_innerwrap">
                                <table class="tb_datacnt" cellspacing="0" cellpadding="0">
                                    <tbody>
                                    <tr>
                                        <td class="S_line1 S_line0">
                                            <span class="S_txt2 W_f14 S_link1">{lang xigua_re:totalget}</span>
                                            <span class="W_icon icon_askS"></span>
                                            <strong class="W_f22 S_link1 xi1">{$user['total']}</strong>
                                        </td>
                                        <td class="S_line1">
                                            <span class="S_txt2 W_f14">{lang xigua_re:totalti}</span> <strong class="W_f22">{$user[times]}</strong>
                                        </td>
                                        <td class="S_line1">
                                            <span class="S_txt2 W_f14">{lang xigua_re:yitixian}</span>
                                            <strong class="W_f22">{$user[settled]}</strong>
                                        </td>
                                        <td class="S_line1">
                                            <span class="S_txt2 W_f14">{lang xigua_re:weitixian}</span>
                                            <span class="W_icon icon_askS"></span> <strong class="W_f22">{$user[notsettled]} <a href="javascript:;" onclick="showconfirm()" class="xi2">{lang xigua_re:tixian}</a></strong>

                                        </td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="WB_cardwrap S_bg2">
                            <div class="E_PCD_chart6">
                                <div class="WB_cardtitle_b S_line2">
                                    <h4 class="obj_name">
                                        <span class="main_title W_fb W_f14">{lang xigua_re:liushui}</span>
                                    </h4>
                                </div>
                                <div class="WB_innerwrap">
                                    <div>
                                        <table class="gridtable">

                                            <tbody id="gridtable">

                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="WB_cardpage S_line1">
                                <div class="W_pages"></div>
                            </div>
                        </div>
                    </div>
                </div>

            <!--{else}-->
        <div class="E_inner_frame cl p10">
            <div class="WB_cardwrap S_bg2">
                <div class="EM_reward_overview">
                    <div class="WB_cardtitle_b S_line2">
                        <div class="newPay_tip S_link1">
                            <strong class="xi1">{lang xigua_re:plear}</strong>
                        </div>
                    </div>
                        <form action="" method="post">
                            <div class="WB_innerwrap">
                            <input type="hidden" name="wordsubmit" value="true">
                            <input type="hidden" name="formhash" value="{FORMHASH}">
                            <input type="text" name="word" class="px pntxt" value="{$user[word]}" tabindex="1">

                            </div>
                            <div class="WB_innerwrap">
                            <button type="submit" name="wordsubmitbtn" value="true" class="pn pnc pncbtn"><strong>{lang xigua_re:save}</strong></button>
                            </div>
                        </form>
                </div>
            </div>
        </div>

            <!--{/if}-->

    </div>
</div>
<script>
    ajaxget('home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&orderlog=1', 'gridtable');
    function showconfirm(){
        var notice = '<style>.alert_info{padding-left:0;background:none}</style><div class="cl" style="margin-top:10px;text-align:center"><form name="confirmpost" method="post" id="confirmpost"><input name="formhash" value="{FORMHASH}" type="hidden"/><input class="px" type="number" name="amount" value="" autocomplete="off" /> {lang xigua_re:yuan} ' +
            '</form></div>';
        showDialog(notice, 'confirm', '{lang xigua_re:tixianjine}', function(){
            $('confirmpost').submit();
        }, 1, '', '{lang xigua_re:atleaset}', '{lang xigua_re:tixian}', '{lang xigua_re:quxiao}');
    }
</script>