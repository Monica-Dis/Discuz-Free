<?php exit('hrhr');?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link href="source/plugin/xigua_re/static/my.css?t={$pluginversion}" rel="stylesheet" />
    <link href="source/plugin/xigua_re/static/webui.css?t={$pluginversion}" rel="stylesheet" />
    <style>
        html,body{background: #f0eff5}.weui_cells_title{margin-top:1em}
    </style>
</head>
<body>
<div class="bd spacing">
    <div class="weui_cells_title">{lang xigua_re:wenzhang}</div>
    <div class="weui_cells weui_cells_access">
        <a class="weui_cell" href="{$info[url]}">
            <div class="weui_cell_hd">{lang xigua_re:wenzhangming}</div>
            <div class="weui_cell_bd weui_cell_primary">
                <p>{$info[subject]}</p>
            </div>
            <div class="weui_cell_ft">
            </div>
        </a>
        <a class="weui_cell" href="javascript:;">
            <div class="weui_cell_hd">{lang xigua_re:zuozhe}</div>
            <div class="weui_cell_bd weui_cell_primary">
                <p>{$touser[username]}</p>
            </div>
        </a>
    </div>
    <div class="weui_cells_title">{$count}{lang xigua_re:ren}{$config[linkword]}</div>

    <div class="weui_cells weui_cells_access">
        <div class="reward_user_list_inner" id="reward_user_list_inner">
            <!--{loop $ilist $img}-->
            <img src="{$img}" />
            <!--{/loop}-->
        </div>
    </div>
</div>
<script src="source/plugin/xigua_re/static/jquery-1.11.3.min.js"></script>
<script>
    function isbottom() {
        var scrollTop = 0;
        var clientHeight = 0;
        var scrollHeight;
        if (document.documentElement && document.documentElement.scrollTop) {
            scrollTop = document.documentElement.scrollTop;
        } else if (document.body) {
            scrollTop = document.body.scrollTop;
        }
        if (document.body.clientHeight && document.documentElement.clientHeight) {
            clientHeight = (document.body.clientHeight < document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
        } else {
            clientHeight = (document.body.clientHeight > document.documentElement.clientHeight) ? document.body.clientHeight: document.documentElement.clientHeight;
        }
        scrollHeight = Math.max(document.body.scrollHeight, document.documentElement.scrollHeight);
        if (scrollTop + clientHeight<=scrollHeight) {
            return true;
        } else {
            return false;
        }
    }

    var page = 2, lock = 0,stop=0;

    $(window).on('scroll touchmove', function(){
        if(!stop && !lock && isbottom()){
            lock =1;
            $.ajax({
                url:'plugin.php?id=xigua_re:list&fetchimg=1&uid={$_GET[uid]}&postid={$_GET[postid]}&page='+page,
                success:function(data){
                    if(!data){
                        stop = 1;
                    }
                    $('#reward_user_list_inner').append(data);
                    page ++;
                    lock = 0;
                },
                error:function(){
                    lock = 0;
                }
            });
        }
    });
</script>
</body>
</html>