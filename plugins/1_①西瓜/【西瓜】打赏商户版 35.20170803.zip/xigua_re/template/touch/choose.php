<?php exit('hrhr');?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link href="source/plugin/xigua_re/static/my.css?t={$pluginversion}" rel="stylesheet" />
    <link href="source/plugin/xigua_re/static/webui.css?t={$pluginversion}" rel="stylesheet" />
</head>
<body>
<!--{if !$apple}-->
<div class="topnav cl">
    <h2 class="hd"></h2>
    <a class="home-return" href="<!--{if $_GET[url]}-->{$_GET[url]}<!--{else}-->javascript:window.history.go(-1);<!--{/if}-->">&nbsp;</a>
</div>
<!--{/if}-->
<div class="bd spacing">

    <div class="ztop">
        <div class="zintop"></div>
        <div class="userinfo">
            <img src="{$toavatar}" />
            <p class="username">{$touser['username']}</p>
            <p class="tip">{$user['word']}</p>
        </div>
    </div>
</div>
<div class="zlistbox">
    <div class="zlist cl">
        <!--{eval $count=1;}-->
        <!--{loop $configary $k $v}-->
        <div class="zitem" data-p="{$k}"><em>$v</em> <span>{lang xigua_re:yuan}</span></div>
        <!--{if $count%3==0}-->
    </div>
    <div class="zlist cl">
        <!--{/if}-->
        <!--{eval $count++}-->
        <!--{/loop}-->
    </div>
</div>
<div class="other">
    <a id="qita">{lang xigua_re:qita}</a>
</div>

<div class="weui_dialog_confirm" id="dialog2" style="display: none;">
    <div class="weui_mask"></div>
    <div class="weui_dialog">
        <div class="weui_dialog_hd"><strong class="weui_dialog_title">{lang xigua_re:qita}</strong></div>
        <div class="weui_dialog_bd">
            <div class="weui_cells weui_cells_form">
                <div class="weui_cell">
                    <div class="weui_cell_hd"><label class="weui_label">{lang xigua_re:jine}</label></div>
                    <div class="weui_cell_bd weui_cell_primary">
                        <input class="weui_input" id="weui_input" type="number" placeholder="{lang xigua_re:qingt}">
                    </div>
                </div>
            </div>

        </div>
        <div class="weui_dialog_ft">
            <a href="javascript:;" class="weui_btn_dialog default closec">{lang xigua_re:quxiao}</a>
            <a href="javascript:;" class="weui_btn_dialog primary">{lang xigua_re:queding}</a>
        </div>
    </div>
</div>

<script src="source/plugin/xigua_re/static/jquery-1.11.3.min.js"></script>
<script>
    var commonary = [];
    $(function(){
        $('.closec,.primary').on('touchstart', function(){
            $(this).addClass('hover');
        }).on('touchend', function(){
            $(this).removeClass('hover');
        });
        $('.closec').on('click', function(){
            $('#dialog2').hide();
        });
        $('.primary').on('touchstart', function(){
            custom();
        });
        $('#qita').on('touchstart', function(){
            $('#dialog2').show();
        });

        $('.zitem').each(function () {
            var k = $(this).attr('data-p');
            $.ajax({
                url:'plugin.php?id=xigua_re:index&uid={$touid}&ac=jsApi&index='+k+'&postid={$_GET[postid]}&subject={echo urlencode($_GET[subject])}&url={echo urlencode($_GET[url])}',
                dataType:'json',
                success:function(data){
                    if(data){
                        commonary[k]=data;
                    }
                }
            });
        });

        $('.zitem').on('touchstart', function(){
            var k = $(this).attr('data-p');
            if(typeof commonary[k] != 'undefined'){
                callpay(commonary[k]);
            }else {
                $.ajax({
                    url:'plugin.php?id=xigua_re:index&uid={$touid}&ac=jsApi&index='+k+'&postid={$_GET[postid]}&subject={echo urlencode($_GET[subject])}&url={echo urlencode($_GET[url])}',
                    dataType:'json',
                    success:function(data){
                        if(data){
                            callpay(data);
                        }
                    }
                });
            }
            return false;
        });
    });

    function custom(){
        var input = $('#weui_input');
        var price = input.val();
        if(! /^[0-9]+\.{0,1}[0-9]{0,2}$/.test(price)){
            alert('{lang xigua_re:qing}');
            input.focus();
            return false;
        }
        $.ajax({
            url:'plugin.php?id=xigua_re:index&uid={$touid}&ac=jsApi&price='+price+'&postid={$_GET[postid]}&subject={echo urlencode($_GET[subject])}&url={echo urlencode($_GET[url])}',
            dataType:'json',
            success:function(data){
                if(data){
                    callpay(data);
                }
            }
        });
        return false;
    }
    function callpay(kapi){
        if (kapi.error) {
            alert(kapi.error);
            return false;
        } else if(kapi.mweb_url) {
            window.location.href = kapi.mweb_url;
            return false;
        }

        if (typeof WeixinJSBridge == "undefined"){
            if( document.addEventListener ){
                document.addEventListener('WeixinJSBridgeReady', function(kapi){jsApiCall(kapi);}, false);
            }else if (document.attachEvent){
                document.attachEvent('WeixinJSBridgeReady', function(kapi){jsApiCall(kapi);});
                document.attachEvent('onWeixinJSBridgeReady', function(kapi){jsApiCall(kapi);});
            }
        }else{
            jsApiCall(kapi);
        }
    }

    function jsApiCall(apiKey) {
        WeixinJSBridge.invoke(
            'getBrandWCPayRequest',
            apiKey,
            function(res){
                if(res.err_msg == 'get_brand_wcpay_request:ok'){
                    window.location.href = '{$_SERVER[HTTP_REFERER]}';
                }else{

                }
            }
        );
    }

</script>
</body>
</html>