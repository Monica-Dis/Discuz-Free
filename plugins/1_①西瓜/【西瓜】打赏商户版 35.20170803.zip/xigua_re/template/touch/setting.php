<?php exit('11');?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link href="source/plugin/xigua_re/static/webui.css" rel="stylesheet" />
    <link href="source/plugin/xigua_re/static/mobileset.css" rel="stylesheet" />

</head>
<body>
<div class="topnav cl">
    <h2 class="hd"></h2>
    <a class="home-return" href="javascript:window.history.go(-1);">&nbsp;</a>
</div>
<!--{if $config['tpl']==2 }-->
<link href="source/plugin/xigua_re/static/my2.css?t={$pluginversion}" rel="stylesheet" />
<div class="bd spacing" style="margin-bottom:55px">
    <div class="ztop">
        <div class="zintop"></div>
        <div class="userinfo">
            <p class="username">{$_G['username']}</p>
            <!--{if $config[default_UID]==$_G[uid]}-->
            <p class="tip">{lang xigua_re:def}</p>
            <!--{/if}-->
            <img src="{avatar($_G[uid], 'middle', 1)}" />
        </div>
    </div>
</div>
<!--{else}-->
<link href="source/plugin/xigua_re/static/my.css?t={$pluginversion}" rel="stylesheet" />
<div class="bd spacing" style="margin-bottom:120px">
    <div class="ztop">
        <div class="zintop"></div>
        <div class="userinfo">
            <img src="{avatar($_G[uid], 'middle', 1)}" />
            <p class="username">{$_G['username']}</p>
            <!--{if $config[default_UID]==$_G[uid]}-->
            <p class="tip">{lang xigua_re:def}</p>
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{/if}-->

<div class="bd">
    <div class="weui_grids">
        <a href="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting" class="weui_grid js_grid">
            <div class="weui_grid_icon">
                <img src="source/plugin/xigua_re/static/icon_nav_button.png" alt="">
            </div>
            <p class="weui_grid_label">
                {lang xigua_re:basic}
            </p>
        </a>
        <a href="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=wxpay" class="weui_grid js_grid">
            <div class="weui_grid_icon">
                <img src="source/plugin/xigua_re/static/icon_nav_cell.png" alt="">
            </div>
            <p class="weui_grid_label">
                {lang xigua_re:wxpay1}
            </p>
        </a>
        <a href="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=qr" class="weui_grid js_grid">
            <div class="weui_grid_icon">
                <img src="source/plugin/xigua_re/static/icon_nav_toast.png" alt="">
            </div>
            <p class="weui_grid_label">
                {lang xigua_re:huoqu}
            </p>
        </a>
    </div>
</div>

<div class="cl setting">
    <div class="cl avatar-badge-list">
        <div class="cl avatar-badge-list-wrapper">
            <!--{if in_array($_GET[type], array('wxpay','alipay','qqpay')) }-->
            <!--{if $isbind}-->
            <div class="weui_cells_title">{lang xigua_re:yibang}</div>
            <div class="bd spacing" style="padding:10px 15px;">
                <a href="javascript:;" onclick="return showqr();" class="weui_btn weui_btn_warn">{lang xigua_re:jiechu}</a>
            </div>
            <!--{else}-->
            <div class="weui_cells_title">{lang xigua_re:zybangding}</div>
            <div class="bd spacing" style="padding:10px 15px;">
                <a href="{$bindurl}" class="weui_btn weui_btn_primary">{lang xigua_re:ljbd}</a>
            </div>
            <!--{/if}-->
            <!--{elseif $_GET[type]=='qr'}-->
            <div class="badge-list cl p10">

                <form action="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=qr" method="post" id="saveqiu" autocomplete="off">
                    <input type="hidden" name="formhash" value="{FORMHASH}">
                    <input type="hidden" name="wordsubmit" value="true">
                    <input type="hidden" name="wordsubmitbtn" value="1">
                    <div class="weui_cells_title"></div>
                    <div class="weui_cells_title">{lang xigua_re:qiu1}</div>
                    <div class="weui_cells weui_cells_form">
                        <div class="weui_cell">
                            <div class="weui_cell_bd weui_cell_primary">
                                <textarea name="word" class="weui_textarea" placeholder="{lang xigua_re:qiu}" rows="3">{$user[word]}</textarea>
                            </div>
                        </div>
                    </div>
                    <div class="weui_btn_area">
                        <a class="weui_btn weui_btn_primary" href="javascript:;" onclick="return dosubmit('saveqiu');" id="showTooltips">{lang xigua_re:save}</a>
                    </div>
                </form>

            </div>
            <!--{else}-->
            <div class="weui_cells_title">{echo sprintf(lang('plugin/xigua_re','notice'), $config[min_t], $config[bili]);}</div>
            <div class="weui_grids half">

                <a href="javascript:;" class="weui_grid js_grid" data-id="progress">
                    <div class="center">
                        {lang xigua_re:totalget}
                    </div>
                    <p class="weui_grid_label">
                        {$user['total']}
                    </p>
                </a>

                <a href="javascript:;" class="weui_grid js_grid" data-id="progress">
                    <div class="center">
                        {lang xigua_re:totalti}
                    </div>
                    <p class="weui_grid_label">
                        {eval echo intval($user[times]);}
                    </p>
                </a>

                <a href="javascript:;" class="weui_grid js_grid" data-id="progress">
                    <div class="center">
                        {lang xigua_re:yitixian}
                    </div>
                    <p class="weui_grid_label">
                        {$user[settled]}
                    </p>
                </a>

                <a href="javascript:;" onclick="return custom();" class="weui_grid js_grid" data-id="progress">
                    <div class="center">
                        {lang xigua_re:weitixian}
                    </div>
                    <p class="weui_grid_label">
                        {$user[notsettled]}
                    </p>
                </a>

            </div>

            <div class="weui_cells_title">{lang xigua_re:liushui}</div>
            <div class="bd">

                <table class="gridtable">

                    <tbody id="gridtable">

                    </tbody>
                </table>
            </div>
            <!--{/if}-->
        </div>
    </div>
</div>


<div class="weui_dialog_confirm" id="dialog3" style="display: none;">
    <div class="weui_mask"></div>
    <div class="weui_dialog">
        <div class="weui_dialog_hd"><strong class="weui_dialog_title">{lang xigua_re:tixianjine}</strong></div>
        <div class="weui_dialog_bd">
            <div class="weui_cells weui_cells_form">
                <div class="weui_cell">
                    <div class="weui_cell_hd"><label class="weui_label">{lang xigua_re:jine}</label></div>
                    <div class="weui_cell_bd weui_cell_primary">

                        <form name="confirmpost" method="post" id="confirmpost" action="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting">
                            <input name="formhash" value="{FORMHASH}" type="hidden"/>
                            <input class="weui_input" id="weui_input" type="number" name="amount" value="" autocomplete="off" />
                        </form>
                    </div>
                </div>
            </div>

        </div>
        <div class="weui_dialog_ft">
            <a href="javascript:;" class="weui_btn_dialog default closec">{lang xigua_re:quxiao}</a>
            <a href="javascript:;" class="weui_btn_dialog primary primaryc">{lang xigua_re:queding}</a>
        </div>
    </div>
</div>

<div id="toast" class="toast" style="display: none;">
    <div class="weui_mask_transparent"></div>
    <div class="weui_toast">
        <i class="weui_icon_toast"></i>
        <p class="weui_toast_content">{lang xigua_re:succeed}</p>
    </div>
</div>
<div id="toast2" class="toast" style="display: none;">
    <div class="weui_mask_transparent"></div>
    <div class="weui_toast">
        <i class="weui_icon_toast"></i>
        <p class="weui_toast_content">{lang xigua_re:unbind}</p>
    </div>
</div>
<iframe style="display:none" id="uploadtarget" name="uploadtarget"></iframe>
<div class="weui_dialog_confirm" id="dialog1" style="display:none" >
    <div class="weui_mask"></div>
    <div class="weui_dialog">
        <div class="weui_dialog_hd"><strong class="weui_dialog_title">{lang xigua_re:dounbind}</strong></div>
        <div class="weui_dialog_bd">{lang xigua_re:confir}</div>

        <form action="home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=wxpay" id="unbindform" method="post">
        <div class="weui_dialog_ft">
                <input type="hidden" name="formhash" value="{FORMHASH}">
                <input type="hidden" name="unbind" value="1">
                <input type="hidden" name="unbindsubmit" value="1">
                <a href="javascript:;" class="weui_btn_dialog default">{lang xigua_re:quxiao}</a>
                <a href="javascript:;" class="weui_btn_dialog primary">{lang xigua_re:queding}</a>
        </div>
        </form>
    </div>
</div>
<script src="source/plugin/xigua_re/static/jquery-1.11.3.min.js"></script>
<script>
    $.ajax({
        url:'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&orderlog=1', success:function(data){
            $('#gridtable').html(data);
        }
    });
    $('.closec').on('click', function(){
        $('#dialog3').hide();
    });
    var waiting = 0;
    $('.primaryc').on('touchstart', function(){
        if(waiting){ console.log(waiting);return false;}
        var input = $('#weui_input');
        var price = input.val();
        if(! /^[0-9]+\.{0,1}[0-9]{0,2}$/.test(price)){
            alert('{lang xigua_re:qing}');
            input.focus();
            return false;
        }
        var form = $('#confirmpost');
        waiting = 1;
        $(this).html('{lang xigua_re:loading}');
        $.ajax({
                type: 'POST',
                url: form.attr('action') + '&inajax=1',
                data: form.serialize(),
                dataType: 'xml'
            })
            .success(function (s) {
                var html = s.lastChild.firstChild.nodeValue.replace(/<script.*?>([\s\S]*?)<\/script>/ig, '');
                html = $(html).find('p').text();
                alert(html);
                window.location.href = window.location.href;
            })
            .error(function () {
                window.location.href = window.location.href;
            });
        return false;
    });
    function ajaxget(url, target){
        $.ajax({
            url:url, success:function(data){
                $('#gridtable').html(data);
            }
        });
    }

    function custom(){
        $('#dialog3').show();
        return false;
    }
    function showqr(){
        var dialog = $('#dialog1');
        dialog.show();
        dialog.find('.default').on('click', function () {
            dialog.hide();
        });
        dialog.find('.primary').on('click', function () {
            var form = $('#unbindform');
            $.ajax({
                    type: 'POST',
                    url: form.attr('action') + '&inajax=1',
                    data: form.serialize(),
                    dataType: 'xml'
                })
                .success(function (s) {
                    $('#toast2').show();
                    setTimeout(function(){
                        window.location.href = window.location.href;
                    },2000);
                })
                .error(function () {
                    window.location.href = window.location.href;
                });
            return false;
        });
        return false;
    }

    function doupload(id){
        document.getElementById(id).submit();
    }
    function uploadend(obj){
        if(obj.error !=0){
            alert(obj.message);
            return false;
        }
        var img = document.getElementById(obj.type+'_img');
        img.innerHTML = '<span></span><em style="background:url(' + obj.url + ') no-repeat center;background-size:cover;"></em>';//'<img class="full" src="' + obj.url + '" />';
    }
    function dosubmit(){
        var form = $('#saveqiu');
        $.ajax({
                type: 'POST',
                url: form.attr('action') + '&inajax=1',
                data: form.serialize(),
                dataType: 'xml'
            })
            .success(function (s) {
                $('#toast').show();
                setTimeout(function(){
                    window.location.href = window.location.href;
                },2000);
            })
            .error(function () {
                window.location.href = window.location.href;
            });
        return false;
    }
</script>
</body>
</html>
