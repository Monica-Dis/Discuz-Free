<?php exit('xxx');?>
<!--{template common/header}-->
<style reload="1">
    .fwinmask{overflow:hidden!important;}
    #rewardpay_menu{border-radius:6px}
    .pay-modal .modal-header{border-bottom:none;padding:10px 10px 0}
    .pay-modal .modal-footer{padding:0 0 40px;border:none;background-color:transparent;text-align:center}
    .pay-modal .modal-body,.success-pay .modal-body{padding:0 50px 35px;max-height:none}
    .pay-modal .avatar,.top-up-modal .avatar,.withdraw-modal .avatar{width:70px;height:70px;margin-bottom:20px;display:inline-block;border-radius:70px;border: 1px solid #ccc;text-align: center;}
    .pay-modal .avatar img{width:100%;height:100%;border:2px solid #fff;border-radius:50%;box-sizing:border-box}
    .pay-modal .avatar:hover img{border-color:#D75847}
    .pay-modal p,.success-pay p{margin-bottom:30px;font-size:16px;line-height:1.8}
    .pay-modal .pull{-webkit-background-size:18px;background-size:18px;height:18px;width:18px;display:block}
    .pay-modal .pull-left{background-image:url(data:image/gif; base64,R0lGODlhHAAbAMQAAAAAAP////L1+Pf4+djn8tzp8+Xu9efv9e7z9/D099ro8t/r8+Hs9OPt9Orx9uzy9vX3+P///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAABEALAAAAAAcABsAAAWnYCSOZGmeaAQZSToOx5M6BNG6Ty2bA1PbrsZvR4IUfsDTYIEkipbIpInZLAmRCNQh6ijlkDdTIuqMDBTILur4O5hov0LqW1MMTGxdytc2CaJ3SlECb0gLKQhICidXNW5aSAwnVDVqjEgGJ3kEZSR8lSdRUWERm2QiomAkplURqT+krENmrzWkaK8yELVSrrW6vKS8wLXCvyrBJMPIxcrHu80jyy7UJyEAOw==);float:left}
    .pay-modal .pull-right{background-image:url(data:image/gif; base64,R0lGODlhHAAbAMQAAAAAAP////L1+Pf4+djn8tzp8+Xu9efv9e7z9/D099ro8t/r8+Hs9OPt9Orx9uzy9vX3+P///wAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAACH5BAEAABEALAAAAAAcABsAAAWcYCSOZGmeEaGubEKyMPGIcfvW6pzihDvyMhrPJ8TpgMSdsVhLAo/D21LZlNagOCcPW/1tTQkYBEXtgWHkgdj0YBXIArTpwGqQHazFacFykBssB2csAyhqNiUGLAZ3eYMrYycQMAglEAWBhnwrdiQCmCt6JwKbKgqRXiunKDFJTAoCZDA6JSsFsbKmrl4GhWQ7DKgmDLt7lb/IySQhADs=);float:right}
    .page_money.primary .money_navs{padding:0;margin:0 -4%}
    .money_navs{text-align:justify;text-justify:distribute-all-lines;font-size:0;padding:0 6.2%}
    .money_navs:after{display:inline-block;width:100%;height:0;font-size:0;margin:0;padding:0;overflow:hidden;content:"."}
    .page_money.primary .money_nav{width:30%;padding-bottom:15%;margin-bottom:5.5%}
    .page_money.primary .money_nav.navfocus,.page_money.primary .money_nav:hover{background-color:#D75847;color:#fff}
    .money_navs .tj_item{font-size:14px;text-align:center}
    .page_money .money_nav{position:relative;padding-bottom:26%;width:43%;display:inline-block;vertical-align:top;border-radius:5px;-moz-border-radius:5px;-webkit-border-radius:5px;border:2px solid #D75847;color:#D75847;-webkit-tap-highlight-color:transparent;outline:0}
    .page_money.primary .money_num{font-size:32px}
    .money_num{font-size:37px;font-style:italic;margin-right:.1em;letter-spacing:2px}
    .money_wrp{position:absolute;top:50%;left:50%;-webkit-transform:translate(-50%,-50%);transform:translate(-50%,-50%);font-size:13px;display:block}
    #wxpaybtn{background:url(source/plugin/xigua_re/static/sao.png) no-repeat;background-size:185px auto;width:185px;height:43px;display:inline-block;border:none}
    .pay-qrcode .qr-title{margin:10px 0;font-size:17.5px;font-family:inherit;font-weight:700;line-height:20px;color:inherit;text-rendering:optimizelegibility}
    .pay-qrcode .qr-price{font-size:14px;font-weight:400;line-height:20px}
    .pay-qrcode .qr-price span{font-size:16px;color:#D75847}
    .pay-qrcode img.payqrcode{padding:15px;margin:0 auto;background-color:#fff;border:1px solid #eee}
    .wxqrcode{position:relative}
    .pay-qrcode .wxqrcode .paygreen{position:absolute;width:50px;height:50px;left:50%;top:50%;margin-left:-25px;margin-top:-25px;border-radius:6px;display:none}
    .pay-qrcode.pay-success .paygreen,.pay-qrcode.pay-success .qr-title{color:green;display:block}

    .closex{display:inline-block;position:absolute;width:16px;height:16px;right:16px;top:15px;cursor:pointer;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA8AAAAPCAYAAAA71pVKAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAA2hpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNS1jMDE0IDc5LjE1MTQ4MSwgMjAxMy8wMy8xMy0xMjowOToxNSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wTU09Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9tbS8iIHhtbG5zOnN0UmVmPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvc1R5cGUvUmVzb3VyY2VSZWYjIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtcE1NOk9yaWdpbmFsRG9jdW1lbnRJRD0ieG1wLmRpZDowNzgwMTE3NDA3MjA2ODExODA4M0U2ODNENkE4M0RCNyIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDoyOTBENURDOTQ0QjgxMUU1QTlCMzk1NDRBMEM3MjkyNiIgeG1wTU06SW5zdGFuY2VJRD0ieG1wLmlpZDoyOTBENURDODQ0QjgxMUU1QTlCMzk1NDRBMEM3MjkyNiIgeG1wOkNyZWF0b3JUb29sPSJBZG9iZSBQaG90b3Nob3AgQ1M2IChNYWNpbnRvc2gpIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NkQ1M0RGMUYxMjIwNjgxMTgwODNFNjgzRDZBODNEQjciIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MDc4MDExNzQwNzIwNjgxMTgwODNFNjgzRDZBODNEQjciLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz62S+aLAAAAmUlEQVR42oyQwQ3CMAxFjSdrlmCHcq8EPfVaegdmCEOY0bAlRwLXTh3px5Lj9xLldJuXCgAPzgfya+CMyNuT89ZGFpT5l8DEOScFDZR5Qm1mBH+gNPDnsCfYgRaOBC7owVYwRWAEN8HGuWslbyiCi9561VqysAxWfeqqtXoC7IBk/mAnwAMQegJMgKEAk6ArEHhMglZw+QowAFv/Nj5dpEoMAAAAAElFTkSuQmCC) center no-repeat}

    .pay-modal{max-height:680px;text-align:center;overflow:hidden;overflow-y:auto;border-top:2px solid $color;border-radius:2px;background: #fff;}
    .p_pop{padding:0!important;}
    .reward-title{font-size: 14px;height: 46px;line-height: 46px;position: relative;text-align: left;text-indent: 16px;font-weight: 700;color: #333;}
    .page_money .money_na{border: 2px solid $color;color: $color;}
    .pay-qrcode .qr-price span{color: $color}
    .page_money.primary .money_nav:hover, .page_money.primary .money_nav.navfocus{background: $color}
    .m_c,.t_l, .t_c, .t_r, .m_l, .m_r, .b_l, .b_c, .b_r{background:none!important;border:none!important;}
</style>
<div class="pay-modal">
    <h3 class="reward-title">$navtitle <a href="javascript:;" class="closex" onclick="hideWindow('reprice')"></a></h3>

    <div class="new_reward page_money primary" style="width: 620px;" id="inputqrw">
        <div class="modal-body">

            <div class="avatar"><img src="{$toavatar}"></div>
            <p><i class="pull pull-left"></i>{$user[word]}<i class="pull pull-right"></i></p>
            <div class="money_navs" id="js_redpacket_list">
                <!--{loop $configary $k $v}-->
            <a href="javascript:;" onclick="get_price($v);return false;" class="money_nav tj_item" data-price="$v">
            <span class="money_wrp">
                <span class="money_num">$v</span>{lang xigua_re:yuan}
            </span>
            </a>
                <!--{/loop}-->

            </div>
            <a id="qita" href="javascript:;" onclick="return get_cprice();" style="font-size:16px;">{lang xigua_re:qita}</a>
        </div>
        <div class="modal-footer" id="wxpaybtn"></div>
    </div>
</div>
<script reload="1">
    function get_price(price){
        showWindow('reqr', 'plugin.php?id=xigua_re:index&ac=pc&uid={$touid}&tid=$_GET[tid]&price='+price+'&subject={$subject}&postid={$postid}&url={$url}','get',0,{cover:1});
        hideWindow('reprice');
    }
    function get_cprice(){
        showWindow('creqr', 'plugin.php?id=xigua_re:index&ac=pc&uid={$touid}&tid=$_GET[tid]&price=&subject={$subject}&postid={$postid}&url={$url}','get',0,{cover:1});
        hideWindow('reprice');
    }
    if(typeof wechat_checkST1 != 'undefined'){
        clearInterval(wechat_checkST1);
    }
</script>
<!--{template common/footer}-->
