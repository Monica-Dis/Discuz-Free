<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xgre_user extends discuz_table {

    public function __construct() {
        $this->_table = 'xgre_user';
        $this->_pk = 'uid';

        parent::__construct(); /*Dism��taobao-com*/
    }

    public function fetch_by_openid($openid) {
        return DB::fetch_first('SELECT * FROM %t WHERE openid=%s', array($this->_table, $openid));
    }

    public function fetch_by_uids($uids)
    {
        $users = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n) ', array($this->_table, $uids), $this->_pk);

        global $_G;
        $need_init = array_diff(array_keys($users), $uids);
        if($need_init && $_G['cache']['plugin']['xigua_login']){
            $wechatinfos = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('common_member_wechat', $need_init), 'uid');
            $dzusers     = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $need_init), 'uid');

            foreach ($wechatinfos as $uid => $wechatinfo) {
                if($wechatinfo['openid']){
                    $users[$uid] = $tmpuser = array(
                        'uid' => $uid,
                        'bindauth' => md5(uniqid($uid.time())),
                        'openid' => $wechatinfo['openid'],
                        'wxuser' => serialize(array(
                            'openid'     => $wechatinfo['openid'],
                            'headimgurl' => avatar($uid, 'middle', true),
                            'nickname'   => $dzusers[$uid]['username'],
                        )),
                    );
                    $this->insert($tmpuser, false, false, true);
                }
            }
        }

        return $users;
    }

    public function fetch_user($uid)
    {
        if(! $user = $this->fetch($uid)){
            $user = array(
                'uid' => $uid,
                'bindauth' => md5(uniqid($uid.time())),
            );

            global $_G;
            if($uid && $_G['cache']['plugin']['xigua_login']){
                $wechatinfo = C::t('#wechat#common_member_wechat')->fetch($uid);
                if($wechatinfo['openid']){
                    $dzuser = getuserbyuid($uid);
                    $user['openid'] = $wechatinfo['openid'];
                    $user['wxuser'] = serialize(array(
                        'openid'     => $wechatinfo['openid'],
                        'headimgurl' => avatar($uid, 'middle', true),
                        'nickname'   => $dzuser['username'],
                    ));
                }
            }

            $this->insert($user, false, false, true);
        }
/*
        if(!$user['openid']){
            $wechatinfo = C::t('#wechat#common_member_wechat')->fetch($uid);
            if($wechatinfo['openid']){
                $dzuser = getuserbyuid($uid);
                $user['openid'] = $wechatinfo['openid'];
                $user['wxuser'] = serialize(array(
                    'openid'     => $wechatinfo['openid'],
                    'headimgurl' => avatar($uid, 'middle', true),
                    'nickname'   => $dzuser['username'],
                ));
                unset($user['uid']);
                $this->update($uid, $user);
                $user = $this->fetch($uid);
            }

        }*/
        return $user;
    }

    public function fetch_by_uid_bindauth($uid, $bindauth){
        return DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND bindauth=%s', array($this->_table, $uid, $bindauth));
    }

    public function unbind($uid)
    {
        return $this->update($uid, array(
            'openid' => '',
            'wxuser' => '',
        ));
    }

    public function update_word($uid, $word)
    {
        return $this->update($uid, array(
            'word' => $word,
        ));
    }

    public function update_notsettled($price, $uid)
    {
        return DB::query('UPDATE %t SET notsettled=notsettled+%d,total=total+%d,times=times+1 WHERE uid=%d LIMIT 1', array(
            $this->_table,
            $price,
            $price,
            $uid
        ));
    }

    public function update_settled($price, $uid)
    {
        $sql = 'UPDATE %t SET settled=settled+%d,notsettled=notsettled+%d WHERE uid=%d LIMIT 1';
        $arg = array(
            $this->_table,
            $price,
            -$price,
            $uid
        );
        return DB::query($sql,$arg );
    }

}