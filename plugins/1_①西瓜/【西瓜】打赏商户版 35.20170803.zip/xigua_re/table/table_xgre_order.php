<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2020-10-20
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xgre_order extends discuz_table
{
    CONST PAYWAIT = 0;
    CONST PAYSUCCESS = 1;
    CONST PAYFAUIL = 2;
    CONST SENDWAIT = 0;
    CONST SENDED   = 1;

    public function __construct()
    {
        $this->_table = 'xgre_order';
        $this->_pk = 'order_id';

        parent::__construct(); /*Dism��taobao-com*/
    }

    public function get_order_id($fromopenid, $fromuid, $touid, $toopenid, $price,$subject, $url, $postid, $fromwx, $fromwximg)
    {
        $order = array(
            'order_id' => date('YmdHis').mt_rand(1000000,9999999),
            'crts' => time(),
            'paystatus' => self::PAYWAIT,
            'sendstatus' => self::SENDWAIT,
            'fromopenid' => $fromopenid,
            'fromuid' => $fromuid,
            'touid' => $touid,
            'toopenid' => $toopenid,
            'baseprice' => $price,
            'subject' => $subject,
            'url' => $url,
            'postid' => $postid,
            'fromwx' => $fromwx,
            'fromwximg' => $fromwximg,
        );
        if($this->insert($order)){
            return $order['order_id'];
        }
    }

    public function fetch_by_order_id($order_id)
    {
        return $this->fetch($order_id);
    }

    public function finish_order_pay($order_id, $getprice, $fromopenid)
    {
        return $this->update($order_id, array('paystatus'=> self::PAYSUCCESS,'getprice'=> $getprice, 'fromopenid' => $fromopenid,'payupts' => time()));
    }

    public function fetch_all_by_page($touid, $start_limit , $lpp){
        $touid = intval($touid);
        $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table)." WHERE touid=$touid AND paystatus=".self::PAYSUCCESS." ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_count_by_page($touid){
        $touid = intval($touid);
        $result = DB::result_first('SELECT  count(*) as c FROM '.DB::table($this->_table)." WHERE touid=$touid AND paystatus=".self::PAYSUCCESS);
        return $result;
    }

    public function fetch_all_bypage( $start_limit , $lpp, $ext = ''){
        if($ext){
            $ext = " WHERE $ext ";
        }
        $result = DB::fetch_all('SELECT * FROM '.DB::table($this->_table)." $ext  ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_count_bypage( $ext = ''){
        if($ext){
            $ext = " WHERE $ext ";
        }
        $result = DB::result_first('SELECT  count(*) as c FROM '.DB::table($this->_table) . " $ext");
        return $result;
    }

    public function fetch_user_by_postid($postid, $start_limit = 0 , $lpp= 24, $all = 1)
    {/*DISTINCT fromopenid*/
        global  $_G;
        $result = DB::fetch_all('SELECT fromuid,fromwximg FROM %t WHERE postid=%s AND paystatus=%d ORDER BY payupts DESC '. DB::limit($start_limit, $lpp), array(
            $this->_table,
            $postid,
            self::PAYSUCCESS,
        ));
        $ret = array();
        foreach ($result as $index => $item) {
            $avatar = $item['fromwximg'] ? $item['fromwximg']: ($item['fromuid'] ? avatar($item['fromuid'], 'middle', true) :'');
            if($avatar){
                $ret[] = $avatar;
            }else if($all){
                $ret[] = $_G['siteurl'].'source/plugin/xigua_re/static/noavatar.gif';
            }
        }
        return $ret;
    }
    public function fetch_usercount_by_postid($postid){
        $result = DB::result_first('SELECT COUNT(*) as c FROM %t WHERE postid=%s AND paystatus=%d ', array(
            $this->_table,
            $postid,
            self::PAYSUCCESS,

        ));
        return $result;
    }

    public function fetch_subject_by_postid($postid)
    {
        return DB::fetch_first('SELECT url,subject,touid FROM %t WHERE postid=%s ORDER BY order_id DESC LIMIT 1', array(
            $this->_table,            $postid,
        ));
    }

    public function clear_order()
    {
        return DB::delete($this->_table, array('paystatus'=>self::PAYWAIT));
    }

    public function delete_order($ids)
    {
        return DB::query('DELETE FROM %t WHERE order_id IN (%n)', array($this->_table, $ids));
    }
}
