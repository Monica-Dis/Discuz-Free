<?php

class JsApiPay
{
	public $data = null;
	

	public function GetOpenid()
	{
		if (!isset($_GET['code'])){
			$baseUrl = urlencode(re_current_url());
			$url = $this->__CreateOauthUrlForCode($baseUrl);
            global $_G;
            $config = $_G['cache']['plugin']['xigua_login'];
            if($config['rhref'] = trim($config['rhref'])) {
                $jieurl = strpos($config['rhref'], 'http://') === false ? "http://" . $config['rhref'] : $config['rhref'];
                if (strpos($jieurl, 'r.html') === false) {
                    $jieurl = rtrim($jieurl, '/') . '/source/plugin/xigua_login/r.html';
                }
                $url = "$jieurl?appid=".WxPayConfig::APPID."&redirect_uri={$baseUrl}&response_type=code&scope=snsapi_userinfo&state=#wechat_redirect";
            }
			header("Location: $url");
			exit();
		} else {
		    $code = $_GET['code'];
			$openid = $this->getOpenidFromMp($code);
			return $openid;
		}
	}

	public function GetOnlyOpenid()
	{
		if (!isset($_GET['code'])){
			$baseUrl = urlencode(re_current_url());
			$url = $this->__CreateBaseUrlForCode($baseUrl);
            global $_G;
            $config = $_G['cache']['plugin']['xigua_login'];
            if($config['rhref'] = trim($config['rhref'])) {
                $jieurl = strpos($config['rhref'], 'http://') === false ? "http://" . $config['rhref'] : $config['rhref'];
                if (strpos($jieurl, 'r.html') === false) {
                    $jieurl = rtrim($jieurl, '/') . '/source/plugin/xigua_login/r.html';
                }
                $url = "$jieurl?appid=".WxPayConfig::APPID."&redirect_uri={$baseUrl}&response_type=code&scope=snsapi_base&state=#wechat_redirect";
            }
			header("Location: $url");
			exit();
		} else {
		    $code = $_GET['code'];
			$openid = $this->getOpenidFromMp($code);
			return $openid;
		}
	}


	public function getUserInfoById($access_token, $openid, $lang = '')
	{
		if (!$lang) {
			$lang = 'zh_CN';
		}

		$url = "https://api.weixin.qq.com/sns/userinfo?access_token=$access_token&openid=$openid&lang=$lang";
		$res = json_decode(self::get($url), true);
		return $res;
	}

	public function getAccessToken() {
		global $_G;
		$token = null;
		$appid = WX_APPID;
		$appsecret = WX_APPSECRET;
		$cachename = substr(md5('xgreacctkn_' . $appid.$appsecret.date('Y-m-d H')), 0, 8);
		loadcache($cachename);

		$token = $_G['cache'][$cachename];

		// check cache
		if ($token) {
			if (time() < $token['expiration']) {
				return  $token;
			}
		}

		// get new token
		$url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";

		$json = self::get($url);
		$res = json_decode($json, true);

		if ($res['errcode']==0) {
			// update cache
			$token = array(
				'token' => $res['access_token'],
				'expiration' => time() + (int) $res['expires_in']-1000,
			);
			savecache($cachename, $token);
		}else{
			savecache($cachename, '');
			return $res;
		}
		return $token;
	}

	/**
	 * @method get
	 * @static
	 * @param  {string}
	 * @return {string|boolen}
	 */
	public static function get($url) {
		if(!function_exists('curl_init')){
			return file_get_contents($url);
		}
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		# curl_setopt($ch, CURLOPT_HEADER, 1);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);

		if (!curl_exec($ch)) {
			error_log(curl_error($ch));
			$data = '';
		} else {
			$data = curl_multi_getcontent($ch);
		}
		curl_close($ch);
		return $data;
	}

	public function GetJsApiParameters($UnifiedOrderResult)
	{
		if(!array_key_exists("appid", $UnifiedOrderResult)
		|| !array_key_exists("prepay_id", $UnifiedOrderResult)
		|| $UnifiedOrderResult['prepay_id'] == "")
		{
			exit(json_encode(array('error' => $_GET['index'] ." param error!!!")));
		}
		$jsapi = new WxPayJsApiPay();
		$jsapi->SetAppid($UnifiedOrderResult["appid"]);
		$timeStamp = time();
		$jsapi->SetTimeStamp("$timeStamp");
		$jsapi->SetNonceStr(WxPayApi::getNonceStr());
		$jsapi->SetPackage("prepay_id=" . $UnifiedOrderResult['prepay_id']);
		$jsapi->SetSignType("MD5");
		$jsapi->SetPaySign($jsapi->MakeSign());
		$parameters = json_encode($jsapi->GetValues());
		return $parameters;
	}

	public function GetOpenidFromMp($code)
	{
		$url = $this->__CreateOauthUrlForOpenid($code);

		$ch = curl_init();

		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER,FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST,FALSE);
		curl_setopt($ch, CURLOPT_HEADER, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
		if(WxPayConfig::CURL_PROXY_HOST != "0.0.0.0" 
			&& WxPayConfig::CURL_PROXY_PORT != 0){
			curl_setopt($ch,CURLOPT_PROXY, WxPayConfig::CURL_PROXY_HOST);
			curl_setopt($ch,CURLOPT_PROXYPORT, WxPayConfig::CURL_PROXY_PORT);
		}

		$res = curl_exec($ch);
		curl_close($ch);

		$data = json_decode($res,true);
		$this->data = $data;
		return $data;
		$openid = $data['openid'];
		return $openid;
	}

	private function ToUrlParams($urlObj)
	{
		$buff = "";
		foreach ($urlObj as $k => $v)
		{
			if($k != "sign"){
				$buff .= $k . "=" . $v . "&";
			}
		}
		
		$buff = trim($buff, "&");
		return $buff;
	}

	public function GetEditAddressParameters()
	{	
		$getData = $this->data;
		$data = array();
		$data["appid"] = WxPayConfig::APPID;
		$data["url"] = "http://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
		$time = time();
		$data["timestamp"] = "$time";
		$data["noncestr"] = "1234568";
		$data["accesstoken"] = $getData["access_token"];
		ksort($data);
		$params = $this->ToUrlParams($data);
		$addrSign = sha1($params);
		
		$afterData = array(
			"addrSign" => $addrSign,
			"signType" => "sha1",
			"scope" => "jsapi_address",
			"appId" => WxPayConfig::APPID,
			"timeStamp" => $data["timestamp"],
			"nonceStr" => $data["noncestr"]
		);
		$parameters = json_encode($afterData);
		return $parameters;
	}

	private function __CreateOauthUrlForCode($redirectUrl)
	{
		$urlObj["appid"] = WxPayConfig::APPID;
		$urlObj["redirect_uri"] = "$redirectUrl";
		$urlObj["response_type"] = "code";
		$urlObj["scope"] = "snsapi_userinfo";
		$urlObj["state"] = "STATE"."#wechat_redirect";
		$bizString = $this->ToUrlParams($urlObj);
		return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
	}

	private function __CreateBaseUrlForCode($redirectUrl)
	{
		$urlObj["appid"] = WxPayConfig::APPID;
		$urlObj["redirect_uri"] = "$redirectUrl";
		$urlObj["response_type"] = "code";
		$urlObj["scope"] = "snsapi_base";
		$urlObj["state"] = "STATE"."#wechat_redirect";
		$bizString = $this->ToUrlParams($urlObj);
		return "https://open.weixin.qq.com/connect/oauth2/authorize?".$bizString;
	}

	private function __CreateOauthUrlForOpenid($code)
	{
		$urlObj["appid"] = WxPayConfig::APPID;
		$urlObj["secret"] = WxPayConfig::APPSECRET;
		$urlObj["code"] = $code;
		$urlObj["grant_type"] = "authorization_code";
		$bizString = $this->ToUrlParams($urlObj);
		return "https://api.weixin.qq.com/sns/oauth2/access_token?".$bizString;
	}
}