<?php

if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT.'./source/plugin/xigua_re/common.php';

if(!in_array($_GET['type'], array('wxpay','alipay','qqpay','qr','basic'))){
    $_GET['type'] = 'basic';
}
if(!$_G['uid']){
    showmessage(lang('plugin/xigua_re', 'pleaseLogin'));
    exit;
}


if(submitcheck('amount')){
    $processname = 'xgre_cache_lock'.$_G['uid'];
    $amount = intval($_GET['amount']*100);
    if($amount<100){
        showmessage(lang('plugin/xigua_re', 'amountwrong'), 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting');
    }
    if($amount <$config['min_t']*100){
        showmessage(sprintf(lang('plugin/xigua_re', 'min_t'), $config['min_t']), 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting');
    }
    $user = C::t('#xigua_re#xgre_user')->fetch_user($_G['uid']);
    if(!$user['openid']){
        showmessage(lang('plugin/xigua_re', 'unknow'), 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=wxpay');
    }

    if($user['notsettled']<100 || $amount>$user['notsettled']){
        showmessage(lang('plugin/xigua_re', 'notsettled'), 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting');
    }
    if(discuz_process::islocked($processname, 120)) {
        showmessage(lang('plugin/xigua_re', 'amountwrong'), 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=wxpay');
    }
    $r = C::t('#xigua_re#xgre_user')->update_settled($amount, $_G['uid']);

    $tmp = C::t('#xigua_re#xgre_user')->fetch_user($_G['uid']);
    if($tmp['notsettled']<0){
        C::t('#xigua_re#xgre_user')->update_settled(-$amount, $_G['uid']);  //back
        showmessage(lang('plugin/xigua_re', 'notsettled'), 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting');
    }

    $tixianid = C::t('#xigua_re#xgre_tixian')->log(
        $amount, $user['openid'], $_G['uid'], $re['result_code'], $re['err_code_des'], $re['return_msg']
    );
    $re = WxPayApi::promotion($tixianid, $user['openid'], $amount, diconv(lang('plugin/xigua_re','datixian'), CHARSET, 'UTF-8'));

    if(is_array($re['return_msg'])){
        $re['return_msg'] = var_export($re['return_msg'], TRUE);
    }
    $re['return_msg'] = diconv($re['return_msg'],'UTF-8', CHARSET);
    $re['err_code_des'] = diconv($re['err_code_des'],'UTF-8', CHARSET);

    $re['err_code_des'] = str_replace(lang('plugin/xigua_re','reeorcode'), lang('plugin/xigua_re','lianxi'), $re['err_code_des']);
    $re['return_msg'] = str_replace(lang('plugin/xigua_re','reeorcode'), lang('plugin/xigua_re','lianxi'), $re['return_msg']);

    C::t('#xigua_re#xgre_tixian')->update($tixianid, array(
            'return_code' => $re['result_code'],
            'err_code_des' => $re['err_code_des'],
            'return_msg' => $re['return_msg']
        )
    );

//    discuz_process::unlock($processname);
    if($re['result_code'] == 'SUCCESS'){
        showmessage(lang('plugin/xigua_re', 'succeed1'), 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting');
    }else{
        $r = C::t('#xigua_re#xgre_user')->update_settled(-$amount, $_G['uid']);  //back
        showmessage($re['err_code_des'], 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting');
    }
    exit;
}

if(submitcheck('orderlog', 1)){
    $page = max(1, intval(getgpc('page')));
    $lpp   = 10;
    $start_limit = ($page - 1) * $lpp;
    $res = C::t('#xigua_re#xgre_order')->fetch_all_by_page($_G['uid'], $start_limit, $lpp);
    $icount = C::t('#xigua_re#xgre_order')->fetch_count_by_page($_G['uid']);
    $checkmobile = checkmobile();
if(!$checkmobile){
    include_once template('common/header');
    $list = '<th>'.(lang('plugin/xigua_re','wz')).'</th>';
}
    $time = lang('plugin/xigua_re','time');
    $user = lang('plugin/xigua_re','user');
    $sr = lang('plugin/xigua_re','sr');
    $shouxf = lang('plugin/xigua_re','shouxf');
    $yuan = lang('plugin/xigua_re','yuan');
    $zanwu = lang('plugin/xigua_re','zanwu');

    if($res){
        echo $checkmobile ? "" : "<tr><th>$time</th><th>$user</th>$list<th>$sr</th><th>$shouxf</th></tr>";

        $realpages = @ceil($icount / $lpp);
        $_G['gp_ajaxtarget'] = '';
        $multi = multi($icount, $lpp, $page, $_G['siteurl'].'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&orderlog=1');
        $multi = preg_replace("/<a\shref=\"([\s\S]*?)\"(.*?)>/ies", "re_js_reajaxget('\\1','\\2')", $multi);
        $multi = str_replace('\"', '"', $multi);


        foreach ($res as $v) {
            if($v['fromuid']){
                $uids[$v['fromuid']] = $v['fromuid'];
            }
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }

        foreach ($res as $v) {
            $shxf = 0;
            $shxf = sprintf('%.2f', ($v['baseprice']-$v['getprice'])/100);
            $v['getprice'] = sprintf('%.2f', $v['getprice']/100);

            if(!$v['fromwximg']){
                $v['fromwximg'] = $_G['siteurl'].'source/plugin/xigua_re/static/noavatar.gif';
            }

            $fromimg = "<img style=\"width:40px;height:40px;vertical-align:middle;border-radius:50%;display:block\" src=\"{$v['fromwximg']}\"/>";
            if($checkmobile){
                $from = $v['fromwx'] ? $v['fromwx'] : ($users[$v['fromuid']] ?$users[$v['fromuid']]['username']: ($v['fromopenid'] ? $v['fromopenid'] : lang('plugin/xigua_re','niming')));
                $from .= "<br>".date('m-d H:i', $v['crts']);
            }else{
                $from = $v['fromwx'] ? '<img style="width:20px;height:20px;vertical-align:middle" src="'.$v['fromwximg'].'"/> '.$v['fromwx'] : ($users[$v['fromuid']] ?$users[$v['fromuid']]['username']: ($v['fromopenid'] ? $v['fromopenid'] : lang('plugin/xigua_re','niming')));
            }

            echo $checkmobile ? "<tr><td>$fromimg</td><td align='left'>$from</td><td><span style='font-size:20px'>{$v['getprice']}</span> {$yuan}</td></tr>" : ('<tr>'.
                '<td>'.($checkmobile ? date('Y-m-d H:i', $v['crts']) : date('Y-m-d H:i:s', $v['crts'])).'</td>'.
                '<td>'. $from .'</td>'.
                ( !$checkmobile ? '<td><a href="'.$v['url'].'" target="_blank">'. $v['subject'].'</a></td>' : '').
                '<td>'. $v['getprice'].$yuan.'</td>'.
                '<td>'. ($shxf).$yuan.'</td>'.
                '</tr>');
        }
        echo $multi ? '<tr><td colspan="5">'.$multi.'</td></tr>' : '';
    }else{
        echo <<<HTML
<tr><th><p class="text">$zanwu</p></th></tr>
HTML;
    }
    if(!$checkmobile) {
        include_once template('common/footer');
    }
    exit;
}

if(submitcheck('unbind')){
    C::t('#xigua_re#xgre_user')->unbind($_G['uid']);
    showmessage(lang('plugin/xigua_re', 'unbind'), 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=wxpay');
    exit;
}
if(submitcheck('wordsubmit')){
    C::t('#xigua_re#xgre_user')->update_word($_G['uid'],dhtmlspecialchars(strip_tags($_GET['word'])));
    showmessage(lang('plugin/xigua_re', 'succeed'), 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting&type=wxpay&type=qr');
    exit;
}

$user = C::t('#xigua_re#xgre_user')->fetch_user($_G['uid']);
$isbind = ($user['openid'] && $user['wxuser']) ? 1 : 0;

if(submitcheck('checkbind', 1)){
    include_once template('common/header');
    if($isbind){
        echo '<script>isbind = 1;</script>';
    }else{
        echo '<script>isbind = 0;</script>';
    }
    include_once template('common/footer');
    exit;
}

if( ! $isbind){
    $ba = authcode($_G['uid']."\t".$user['bindauth'], 'ENCODE', $_G['config']['security']['authkey']);
    $bindurl = $_G['siteurl'] .'plugin.php?id=xigua_re:bind&ba='.urlencode($ba);
    $qrfile = $repath.md5($ba).'.png';

    $qrurl = 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text='.urlencode($bindurl);
    /*if(class_exists('QRcode')){
        if(!file_exists(DISCUZ_ROOT.$qrfile)) {
            QRcode::png($bindurl, DISCUZ_ROOT.$qrfile, QR_ECLEVEL_L, 4);
        }
        $qrurl = $_G['siteurl'] . $qrfile;
    }else{
    }*/
    $errorqrurl = 'http://qr.liantu.com/api.php?&w=240&bg=ffffff&fg=333333&text='.urlencode($bindurl);

}else{

    $wxuser = unserialize($user['wxuser']);
}
$user['notsettled'] = sprintf('%.2f', $user['notsettled']/100);
$user['settled'] = sprintf('%.2f', $user['settled']/100);
$user['total'] = sprintf('%.2f', $user['total']/100);


if(checkmobile()){
    include_once template('xigua_re:setting');
    exit;
}