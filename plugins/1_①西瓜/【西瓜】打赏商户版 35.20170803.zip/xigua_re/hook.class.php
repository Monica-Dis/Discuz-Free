<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

class plugin_xigua_re{
    function common(){
        global $_G;
        if($_G['basescript'] =='group'){
            $config = $_G['cache']['plugin']['xigua_re'];
            if($config['needgroup']){
                $_G['basescript'] = 'forum';
            }
        }
    }
}

class plugin_xigua_re_portal extends plugin_xigua_re
{
    function view_article_content_output(){
        global $article,$postlist;
        $authorinfo = getuserbyuid($article['uid']);
        $postlist[0]['authorid'] = $article['uid'];
        $postlist[0]['first'] = 1;
        $postlist[0]['groupid'] = $authorinfo['groupid'];
        $postlist[0]['subject'] = $article['title'];
        $postlist[0]['pid'] = 'a_'.$article['aid'];
        $_G['fid'] = 0;

        global $ispc;
        $ispc = 1;
        $ret = mobileplugin_xigua_re_forum::viewthread_postbottom_mobile_output();
        return $ret[0];
    }

}
class mobileplugin_xigua_re_portal extends plugin_xigua_re_portal
{
    function view_article_content_output(){
        global $article,$postlist;
        $authorinfo = getuserbyuid($article['uid']);
        $postlist[0]['authorid'] = $article['uid'];
        $postlist[0]['first'] = 1;
        $postlist[0]['groupid'] = $authorinfo['groupid'];
        $postlist[0]['subject'] = $article['title'];
        $postlist[0]['pid'] = 'a_'.$article['aid'];
        $_G['fid'] = 0;

        global $ispc;
        $ispc = 0;
        $ret = mobileplugin_xigua_re_forum::viewthread_postbottom_mobile_output();
        return $ret[0];
    }
}

class plugin_xigua_re_forum extends plugin_xigua_re
{
    public static function viewthread_postbottom_output(){
        global $ispc;
        $ispc = 1;
        $ret = mobileplugin_xigua_re_forum::viewthread_postbottom_mobile_output();
        return $ret;
    }
}
class  mobileplugin_xigua_re_forum extends plugin_xigua_re
{
    public static function getstyle($ispc, $color)
    {
        $reword = $ispc ? 'text-align: center; font-size: 18px;color: #666;line-height: 36px;clear:both;' : 'font-size:16px;text-align:center;padding-top:10px;color:#909090;clear:both;width:100%;';
        $relistli = $ispc ? 'margin:0 6px 6px 0;float:left' : 'display:inline-block;margin:0 6px 6px 0;vertical-align:top';

        $html = '';
        include_once template('xigua_re:style');
        $style = $html;
        return $style;
    }

    public static function viewthread_postbottom_mobile_output(){
        include_once DISCUZ_ROOT.'./source/plugin/xigua_re/common.php';
        global $_G,$postlist,$ispc;
        $config = $_G['cache']['plugin']['xigua_re'];
        $color = $config['linkcolor'] ? $config['linkcolor'] : '#D75847';
        $hasstyle = 0;
        $data = array();
        $style = self::getstyle($ispc, $color);

        $yuan = lang('plugin/xigua_re', 'yuan');
        $ren = lang('plugin/xigua_re', 'ren');
        $wuhui = lang('plugin/xigua_re', 'wuhui');
        $lijida = lang('plugin/xigua_re', 'lijida');
        $guanbi = lang('plugin/xigua_re', 'guanbi');
        $qing = lang('plugin/xigua_re', 'qing');

        $pcjs = '';
        include_once template('xigua_re:pcjs');

        $authors = array();
        foreach (array_values($postlist) as $item) {
            $authors[] = $item['authorid'];
        }
        $users = C::t('#xigua_re#xgre_user')->fetch_by_uids($authors);

        foreach (array_values($postlist) as $index => $item) {

            /*
            $mem = C::t('common_member')->fetch($item['authorid']);

            foreach(explode("\t", $mem['extgroupids']) as $extgroupid) {
                if($extgroupid = intval(trim($extgroupid))) {
                    $groupidarray[] = $extgroupid;
                }
            }
            if(!in_array($item['groupid'], unserialize($config['opengroups'])) && !array_intersect(unserialize($config['opengroups']), $groupidarray)){
                $data[$index] = '';
                continue;
            }
            */
            if(!in_array($item['groupid'], unserialize($config['opengroups']))){
                $data[$index] = '';
                continue;
            }
            if($_G['fid'] && in_array($_G['fid'], unserialize($config['closefids']))){
                $data[$index] = '';
                continue;
            }
            if($config['first'] && !$item['first']){
                $data[$index] = '';
                continue;
            }
            $user = $users[$item['authorid']];
            if(!$user['openid']){
                if($config['needopenid']){
                    $data[$index] = '';
                    continue;
                }
            }
            if(!$user['word']){
                $user['word'] = $config['preword'];
            }

            $postid = 'pid_'.$item['pid'];
            $tid = $item['tid'];
            $url = urlencode(re_current_url());
            $subject = $item['subject'];
            $subject = urlencode($subject);

            $imgs = $reilist = '';
            $dlist = array();
            $count = C::t('#xigua_re#xgre_order')->fetch_usercount_by_postid($postid);

            if($count){
                $dlist = $list = C::t('#xigua_re#xgre_order')->fetch_user_by_postid($postid);
            }
            if($hasstyle){
                $style = '';
                $pcjs = '';
            }

            $paybtn = '';
            include template('xigua_re:paybtn');
            $data[$index] = $paybtn;
            $hasstyle = 1;
        }

        if($data[0]){
            $data[''] = $data[0];
        }

        return $data;
    }
}