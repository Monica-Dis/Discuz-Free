<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * Copyright (c) 2020 by dism.taobao.com
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!function_exists('curl_init')) {
	exit('Missing curl extension!');
}
if (!function_exists('openssl_csr_export')) {
	exit('Missing openssl extension!');
}
$pluginversion = '20160201';
global $_G;
if (!$_G['cache']['plugin']) {
	loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_re'];
$authkey = $_G['config']['security']['authkey'];
include_once libfile('function/cache');
define('WX_APPID', trim($config['appid']));
define('WX_MCHID', trim($config['shanghuid']));
define('WX_APPSECRET', trim($config['appsecert']));
define('WXPAY_KEY', trim($config['key']));
define('NOTIFY_URL', $_G['siteurl'] . 'source/plugin/xigua_re/notify_wx.php');
$repath = './source/plugin/xigua_re/cache/';
include_once DISCUZ_ROOT . './source/plugin/mobile/qrcode.class.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_re/lib/wxpay/lib/WxPay.Config.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_re/lib/wxpay/lib/WxPay.Api.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_re/lib/wxpay/example/WxPay.JsApiPay.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_re/lib/wxpay/example/WxPay.NativePay.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_re/lib/wxpay/example/log.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_re/lib/wxpay/lib/WxPay.Data.php';
define('IN_WECHAT', !(strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') === false));
$cookie = substr(md5('rewechatopenid3' . $_G['siteurl'] . WX_APPID . WX_MCHID . WX_APPSECRET), 0, 8);
$_GET['subject'] = re_safe_replace($_GET['subject']);
$_GET['url'] = re_safe_replace($_GET['url']);
xigua_re_init();
function re_current_url()
{
	$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
	$php_self = $_SERVER['PHP_SELF'] ? re_safe_replace($_SERVER['PHP_SELF']) : re_safe_replace($_SERVER['SCRIPT_NAME']);
	$path_info = isset($_SERVER['PATH_INFO']) ? re_safe_replace($_SERVER['PATH_INFO']) : '';
	$relate_url = isset($_SERVER['REQUEST_URI']) ? re_safe_replace($_SERVER['REQUEST_URI']) : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . re_safe_replace($_SERVER['QUERY_STRING']) : $path_info);
	return $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
}
function re_safe_replace($string)
{
	$string = str_replace('%20', '', $string);
	$string = str_replace('%27', '', $string);
	$string = str_replace('%2527', '', $string);
	$string = str_replace('*', '', $string);
	$string = str_replace('"', '&quot;', $string);
	$string = str_replace('\'', '', $string);
	$string = str_replace('"', '', $string);
	$string = str_replace(';', '', $string);
	$string = str_replace('<', '&lt;', $string);
	$string = str_replace('>', '&gt;', $string);
	$string = str_replace('{', '', $string);
	$string = str_replace('}', '', $string);
	$string = str_replace('\\', '', $string);
	return $string;
}
function re_js_reajaxget($link, $ext)
{
	return '<a href="' . $link . '" onclick="ajaxget(\'' . $link . '\', \'gridtable\');return false;"' . $ext . '>';
}
function reToUrlParams($urlObj)
{
	$buff = '';
	foreach ($urlObj as $k => $v) {
		$buff .= $k . '=' . $v . '&';
	}
	$buff = trim($buff, '&');
	return $buff;
}
function re_clientip()
{
	$onlineip = '';
	if (getenv('HTTP_CLIENT_IP') && strcasecmp(getenv('HTTP_CLIENT_IP'), 'unknown')) {
		$onlineip = getenv('HTTP_CLIENT_IP');
	} else {
		if (getenv('HTTP_X_FORWARDED_FOR') && strcasecmp(getenv('HTTP_X_FORWARDED_FOR'), 'unknown')) {
			$onlineip = getenv('HTTP_X_FORWARDED_FOR');
		} else {
			if (getenv('REMOTE_ADDR') && strcasecmp(getenv('REMOTE_ADDR'), 'unknown')) {
				$onlineip = getenv('REMOTE_ADDR');
			} else {
				if (isset($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], 'unknown')) {
					$onlineip = $_SERVER['REMOTE_ADDR'];
				}
			}
		}
	}
	return $onlineip;
}
function xigua_re_init()
{
}