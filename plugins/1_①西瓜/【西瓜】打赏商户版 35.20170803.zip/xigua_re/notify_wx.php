<?php

define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/xigua_re/', '',$_G['siteurl'] );
require_once 'common.php';

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
//$re = WxPayApi::promotion('201602022028434331035', 'ohvWAwxEy3M9CvZB5J4HFDuOk8Nc', 100, 'test');
//$re['return_msg'] = diconv($re['return_msg'],'UTF-8', CHARSET);
//$re['err_code_des'] = diconv($re['err_code_des'],'UTF-8', CHARSET);
//var_dump($re);
//if($re['return_code'] == 'SUCCESS'){

//}else{
//
//}
$notifydata = re_notifycheck();
if($notifydata['validator']) {

    $order_id = $notifydata['order_no'];
    $postprice = $notifydata['price'];
    $order = C::t('#xigua_re#xgre_order')->fetch_by_order_id($order_id);

    if(
        $order &&
        $order['paystatus'] == table_xgre_order::PAYWAIT &&
        $order['sendstatus'] == table_xgre_order::SENDWAIT
    ) {
        $shui = intval(round($postprice*($config['bili']/100)));
        $getprice = $postprice - $shui;

        C::t('#xigua_re#xgre_order')->finish_order_pay($order_id, $getprice, $notifydata['fromopenid']);
        C::t('#xigua_re#xgre_user')->update_notsettled($getprice, $order['touid']);

        if($getprice>= 100 && $order['toopenid'] && $getprice>= ($config['min_t']*100)){
            $re = WxPayApi::promotion($order['order_id'], $order['toopenid'], $getprice, diconv(lang('plugin/xigua_re','datixian'), CHARSET, 'UTF-8'));
            if(is_array($re['return_msg'])){
                $re['return_msg'] = var_export($re['return_msg'], TRUE);
            }
            $re['return_msg'] = diconv($re['return_msg'],'UTF-8', CHARSET);
            $re['err_code_des'] = diconv($re['err_code_des'],'UTF-8', CHARSET);

            $re['err_code_des'] = str_replace(lang('plugin/xigua_re','reeorcode'), lang('plugin/xigua_re','lianxi'), $re['err_code_des']);
            $re['return_msg'] = str_replace(lang('plugin/xigua_re','reeorcode'), lang('plugin/xigua_re','lianxi'), $re['return_msg']);

            if($re['result_code'] == 'SUCCESS'){
                C::t('#xigua_re#xgre_user')->update_settled($getprice, $order['touid']);
            }
            C::t('#xigua_re#xgre_tixian')->log(
                $getprice, $order['toopenid'], $order['touid'], $re['result_code'], $re['err_code_des'], $re['return_msg']
            );
        }
//        notification_add($order['uid'], 'credit', 'addfunds', array(
//            'order_id' => $order['order_id'],
//            'price' => $order['price'],
//            'value' => $_G['setting']['extcredits'][$_G['setting']['creditstrans']]['title'].' '.$order['amount'].' '.$_G['setting']['extcredits'][$_G['setting']['creditstrans']]['unit']
//        ), 1);
        if($order['fromuid']){
            $fromusername = DB::result_first('SELECT username FROM %t WHERE uid=%d', array('common_member', $order['fromuid']));
        }
        $from = $order['fromwx'] ? '<img style="width:20px;height:20px;vertical-align:middle" src="'.$order['fromwximg'].'"/> '.$order['fromwx'] : ($fromusername ?$fromusername: ($order['fromopenid'] ? $order['fromopenid'] : lang('plugin/xigua_re','niming')));

        notification_add(
            $order['touid'],
            'system',
            lang('plugin/xigua_re', 'noticel'),
            array(
                'from' => $from,
                'linkword' => $config['linkword'],
                'url' => 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting',
            ),
            1
        );
    }

}
function re_notifycheck() {
    global $_G;

    $msg = '';

    $notify = WxPayApi::notify($msg);

    if(empty($notify)){
        $return = array(
            'return_code'=>'FAIL',
            'return_msg'=>$msg,
        );
        WxPayApi::replyNotify(arr2xml($return));
        exit;
    }

    //checksign
    $sign = $notify['sign'];
    unset($notify['sign']);

    ksort($notify);
    $string = reToUrlParams($notify);
    $string = $string . "&key=".WxPayConfig::KEY;
    $string = md5($string);
    $result = strtoupper($string);
    if($result != $sign){
        $return = array(
            'return_code'=>'FAIL',
            'return_msg'=> 'sign error!',
        );
        WxPayApi::replyNotify(arr2xml($return));
        exit;
    }
    if($notify['result_code'] == 'SUCCESS') {
        return array(
            'validator'	=> isset($notify['result_code']) && $notify['result_code'] == 'SUCCESS' ? 1 : 0,
            'order_no' 	=> $notify['out_trade_no'],
            'trade_no'	=> isset($notify['transaction_id']) ? $notify['transaction_id'] : '',
            'price' 	=> $notify['total_fee'],
            'appid' => $notify['appid'],
            'notify'	=> arr2xml(array('return_code'=>'SUCCESS')),
            'location'	=> false,
            'fromopenid' => $notify['openid'],
        );
    }
}


function arr2xml($data){
    $xml = "<xml>";
    foreach ($data as $key=>$val)
    {
        if (is_numeric($val)){
            $xml.="<".$key.">".$val."</".$key.">";
        }else{
            $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
        }
    }
    $xml.="</xml>";
    return $xml;
}