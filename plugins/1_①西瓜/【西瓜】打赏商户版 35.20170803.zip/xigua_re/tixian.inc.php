<?php

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if(submitcheck('permsubmit')){
    $r = C::t('#xigua_re#xgre_tixian')->delete_order($_GET['delete']);
    if($r){
        cpmsg(lang('plugin/xigua_re', 'delete_succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_re&pmod=tixian&page=".$_GET['page'], 'succeed');
    }
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_re&pmod=tixian&page=".$_GET['page']);
showtableheader(lang('plugin/xigua_re','torder'));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_re','del'),
    lang('plugin/xigua_re','orderid'),
    lang('plugin/xigua_re','jine'),
    lang('plugin/xigua_re','user'),
    'OPENID',
    lang('plugin/xigua_re','status'),
    lang('plugin/xigua_re','txtime'),
));
$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;
$res = C::t('#xigua_re#xgre_tixian')->fetch_bypage($start_limit, $lpp);
$icount = C::t('#xigua_re#xgre_tixian')->count_bypage();


foreach ($res as $v) {
    if($v['uid']){
        $uids[$v['uid']] = $v['uid'];
    }
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}


foreach ($res as $re) {
    $re['amount'] = sprintf('%.2f', $re['amount']/100);

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='{$re['tixianid']}' />",
        $re['tixianid'],
        $re['amount'],
        $users[$re['uid']]['username'],
        $re['openid'],
        $re['return_code']=='SUCCESS' ? '<strong style="color:forestgreen;">'.(lang('plugin/xigua_re','succeed2')).'</strong>' : '<strong style="color:orangered;">'.$re['return_code'].$re['return_msg'].'</strong>',
        date('m-d H:i:s', $re['crts']),
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_re&pmod=tixian&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '',$multipage);
showtablefooter(); /*Dism_taobao_com*/
showformfooter(); /*dism��taobao��com*/