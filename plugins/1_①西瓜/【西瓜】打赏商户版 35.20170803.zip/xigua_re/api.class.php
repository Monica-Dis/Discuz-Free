<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class xigua_re
{
    public function viewthread_variables(& $params)
    {
        include_once DISCUZ_ROOT.'./source/plugin/xigua_re/common.php';
        include_once DISCUZ_ROOT.'./source/plugin/xigua_re/hook.class.php';
        global $_G;
        $config = $_G['cache']['plugin']['xigua_re'];
        $color = $config['linkcolor'] ? $config['linkcolor'] : '#D75847';
        $ren = lang('plugin/xigua_re', 'ren');

        if(in_array($_G['fid'], unserialize($config['closefids']))){
            return;
        }
        foreach ($params['postlist'] as $index => $item) {
            if(!in_array($item['groupid'], unserialize($config['opengroups']))){
                continue;
            }
            if($config['first'] && !$item['first']){
                continue;
            }

            $user = C::t('#xigua_re#xgre_user')->fetch_user($item['authorid']);
            if(!$user['openid']){
                if($config['needopenid']) {
                    continue;
                }
            }
            if(!$user['word']){
                $user['word'] = $config['preword'];
            }

            $subject = $params['thread']['subject'] ? urlencode($params['thread']['subject']) : urlencode($item['recentnote']);
            $subject = str_replace(array(
                '\'', "\n", "\r", "\t", "&nbsp;", "&amp;nbsp;"
            ), '', $subject);

            $postid = 'pid_'.$item['pid'];
            $tid  = $item['tid'];

            $imgs = $reilist = '';
            $count = C::t('#xigua_re#xgre_order')->fetch_usercount_by_postid($postid);

            if($count){
                $list = C::t('#xigua_re#xgre_order')->fetch_user_by_postid($postid);
                foreach ($list as $itm) {
                    $imgs .= "<li style='display:inline-block;margin:0 6px 6px 0;vertical-align:top'><img style='width:28px;height:28px;display:block;margin:0' src=\"$itm\" onerror='this.error=null;this.src=\"{$_G['siteurl']}source/plugin/xigua_re/static/noavatar.gif\"' /> </li>";
                }

                $count = "<a style='color:#627C97;font-size:16px' href=\"{$_G['siteurl']}plugin.php?id=xigua_re:list&uid={$item['authorid']}&tid=$tid&postid=$postid\">$count</a>";
                $reilist = "<div><p style='font-size:16px;text-align:center;color:#909090'>{$count}$ren$config[linkword]</p><ul style='width:272px;margin:10px auto;text-align:center' class=\"cl\">$imgs</ul></div>";
            }

            $params['postlist'][ $index ]['message'] = $params['postlist'][ $index ]['message'].
                <<<HTML
<div style="font-size:16px;text-align:center;padding-top:10px;color:#909090;clear:both;width:100%;">$user[word]</div>
<div style="width:100%;padding:8px 0 25px;text-align:center"><a style="display:inline-block;height:32px;line-height:32px;padding:0 25px;font-size:16px;text-align: center;margin:0 auto;vertical-align: middle;color: #fff;border-radius: 4px;background:$color" href='{$_G['siteurl']}plugin.php?id=xigua_re:index&uid={$item['authorid']}&subject=$subject&tid=$tid&postid=$postid'>$config[linkword]</a></div>
$reilist
HTML;
        }
    }
    function profile_extraInfo()
    {
        global $_G;
        $config = $_G['cache']['plugin']['xigua_re'];
        $link = $_G['siteurl']. 'home.php?mod=spacecp&ac=plugin&id=xigua_re:setting';
        $return[] = array(
            'name' => "<a href='$link'>{$config['navword']}</a>",
            'link' => $link,
        );
        return $return;
    }
}