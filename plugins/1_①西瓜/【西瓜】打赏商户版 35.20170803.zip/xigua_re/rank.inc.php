<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

include_once DISCUZ_ROOT.'./source/plugin/xigua_re/common.php';

function x_get_picurl($pic, $remote = 0){
    global $_G;
    if(!$pic){
        return '';
    }
    if(x_is_picurl($pic)){
        return $pic;
    }

    if(strpos($pic, 'forum.php') !== false){
        return $_G['siteurl'].$pic;
    }

    if($remote){
        $attach__ = $_G['setting']['ftp']['attachurl'] . 'forum/' . $pic;
    }else{
        $pic = $_G['setting']['attachurl'].'forum/'.$pic;
        if(x_is_picurl($pic)){
            return $pic;
        }
        $attach__ = $_G['siteurl'].$pic;
    }
    return $attach__;
}
function x_is_picurl($pic){
    return in_array(strtolower(substr($pic, 0, 6)), array('http:/', 'https:', 'ftp://'));
}

$lpp = 10;
$page = max(1, intval($_G['page']));
$start_limit = ($page - 1) * $lpp;
$uids = array();
if($_GET['type']=='jinzhu') {
    $navtitle = lang('plugin/xigua_re', 'jinzhu');
}else{
    $navtitle = lang('plugin/xigua_re', 'shouru1');
}


if($_GET['inajax']){
    if($_GET['type']=='jinzhu'){
        $ranklist = DB::fetch_all("SELECT *,fromuid as uid,sum(baseprice) as total FROM %t WHERE fromuid!=0 AND payupts>0 group by fromuid order by total desc ". DB::limit($start_limit, $lpp), array('xgre_order'));
        $act = lang('plugin/xigua_re', 'songchu');
        foreach ($ranklist as $index => $item) {
            $ranklist[$index]['link'] = "home.php?mod=space&uid={$item['uid']}&do=profile&mobile=2";
        }
    /*}else if(0){
        $ranklist = DB::fetch_all("SELECT * FROM %t order by total desc ". DB::limit($start_limit, $lpp), array('xgre_user'));
        $act = lang('plugin/xigua_re', 'shoudao');*/
    }else{
        $ranklist = DB::fetch_all("SELECT *,touid as uid,subject as username,sum(baseprice) as total FROM %t WHERE postid!='' AND payupts>0 group by postid order by total desc ". DB::limit($start_limit, $lpp), array('xgre_order'));
        $act = lang('plugin/xigua_re', 'shoudao');
        foreach ($ranklist as $index => $item) {
            $pid = str_replace('pid_', '', $item['postid']);
            $tid = DB::result_first("SELECT tid FROM %t WHERE pid=%d", array('forum_post', $pid));
            $ranklist[$index]['link'] = "forum.php?mod=viewthread&tid=".$tid;

            $query = DB::query("SELECT a.aid,a.tableid from " . DB::table('forum_attachment') . " as a  where a.pid='$pid' ORDER BY aid ASC LIMIT 3");
            while ($arow = DB::fetch($query)) {
                if($arow['tableid'] == 127){
                    continue;
                }
                $table = DB::table('forum_attachment_' . intval($arow['tableid']));
                $aid = $arow['aid'];
                $row = DB::fetch_first("SELECT remote,thumb,attachment,width FROM $table WHERE aid='$aid' AND isimage IN(-1, 1) LIMIT 1");
                if ($row['attachment']) {
                    $ranklist[$index]['pic'][] = x_get_picurl($row['thumb'] ? getimgthumbname($row['attachment']) : $row['attachment'], $row['remote']);
                }
            }
            $ranklist[$index]['avatar'] = $ranklist[$index]['pic'][0];
        }
    }


    foreach ($ranklist as $str => $item) {
        $ranklist[$str]['index'] = $str+$start_limit+1;
        $ranklist[$str]['total'] = ceil($item['total']/100);
        $ranklist[$str]['member'] = getuserbyuid($item['uid']);

        $uids[] = $item['uid'];
    }

    if($uids){
        $genders = DB::fetch_all('SELECT uid,gender FROM %t WHERE uid IN (%n)', array('common_member_profile', $uids), 'uid');
        $users = DB::fetch_all('SELECT username,uid FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    foreach ($ranklist as $k => $v) {
        !$ranklist[$k]['username'] && $ranklist[$k]['gender'] = $genders[$v['uid']]['gender'];
        !$ranklist[$k]['username'] && $ranklist[$k]['username'] = $users[$v['uid']]['username'];
        !$ranklist[$k]['avatar']   && $ranklist[$k]['avatar'] = avatar($v['uid'], 'middle', TRUE);
        $ranklist[$k]['str'] = "$act<b>{$v['total']}</b> &yen;";
    }
    $html = '';
    include_once template('xigua_re:rank_item');
    echo $html;
    exit;
}

include_once template('xigua_re:rank');