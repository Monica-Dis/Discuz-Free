<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_GET['is_my'] || $_GET['is_admin']}-->
<!--{template xigua_hb:mypub_item}-->
<!--{else}-->
<!--{loop $list $k $v}-->
<!--{eval
$msg = (str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v[description]))));
$locr = '';
$v[vars] = array_values($v[vars]);
foreach($v[vars] as $__k=> $__v):
    if($__v[type]=='location' || $__v[type]=='area'):
        $locr = str_replace(' ', '', $__v['html']);
        unset($v[vars][$__k]);
    endif;
    if($__v[type]=='pics' || $__v[type]=='linkurl'):
        unset($v[vars][$__k]);
    endif;
endforeach;
$v[vars] = array_values($v[vars]);
$lt0 = $v[vars][0];
unset($v[vars][0]);
}-->
<div class="jl_fc_list_item" >
    <div class="jl_fc_item">
        <div>
            <div class="jl_fc_price">{$lt0['html']}</div>
            <div class="jl_fc_poster" onclick="hb_jump('$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]');">
                <div class="jl_fc_poster_avatar">
                    <div class="j_avatar" style="background-image:url({avatar($v[uid], 'middle', true)});"></div>
                </div>
                <div class="jl_fc_poster_time"><span class="poster-name">{$users[$v[uid]][username]}</span>
                    <time class="jl_fc_poster_touchtime">{$v[time_u]}</time>
                </div>
            </div>
            <div class="jl_fc_main view_jump" data-id="$v[id]" data-stid="$v[stid]">
                <div class="jl_fc_content">
                    <div class="jl_fc_container"><div class="jl_fc_post_text">
<!--{if $v[dig_on]}--><div class="mod-lv is-star" style="margin-left:0">{lang xigua_hb:zhiding}</div><!--{/if}-->
<!--{if $v[hb_num]}--><div class="mod-lv is-hot" style="margin-left:0">{lang xigua_hb:hb}</div><!--{/if}-->
$msg</div></div>
                </div>
                <!--{if $v[img_preview][0]}-->
                <div class="jl_fc_post_media" style="background: url($v[img_preview][0]) 0% 0% / cover no-repeat;"></div>
                <!--{elseif $v['video_cover'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
                <div class="jl_fc_post_media" style="background: url($v[video_cover]) 0% 0% / cover no-repeat;"><img style="display:block;width:1.5rem;height:1.5rem" src="source/plugin/xigua_hb/static/img/vp.png" ></div>
                <!--{/if}-->
            </div>
        </div>
        <div class="jl_fc_desc_info view_jump" data-id="$v[id]" data-stid="$v[stid]">
            <div class="jl_fc_info1">
                <div class="jl_fc_typelabel"><span class="___content">{$cats[$v[catid]][name]}</span></div>
                <span>{$v[views]}{lang xigua_hb:ck}&emsp;</span></div>
            <!--{if $locr}-->
            <div class="jl_fc_location"><span class="jl_fc_location_icon"></span><span class="jl_fc_location_txt">$locr</span></div>
            <!--{/if}-->
        </div>
        <!--{if array_filter($v[tags])}-->
        <div class="jl_fc_estate view_jump" data-id="$v[id]" data-stid="$v[stid]">
            <!--{loop $v[tags] $___k $tag}-->
            <!--{if $tag}--> <div class="jl_fc_estate_label">$tag</div><!--{/if}-->
            <!--{/loop}-->
            <!--{if 0}-->
            <!--{loop $v[vars] $___k $___tag}-->
            <!--{if $___tag['html']}--> <div class="jl_fc_estate_label">$___tag['html']</div><!--{/if}-->
            <!--{/loop}-->
            <!--{/if}-->
        </div>
        <!--{/if}-->
        <div class="fake-border"></div>
    </div>
</div>
<!--{/loop}-->
<!--{/if}-->