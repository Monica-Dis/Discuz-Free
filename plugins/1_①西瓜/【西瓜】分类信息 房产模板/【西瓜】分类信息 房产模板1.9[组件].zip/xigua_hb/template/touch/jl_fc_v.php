<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template xigua_hb:common_header}--><!--{if $totalpubs<1}--><!--{eval $totalpubs=1;}--><!--{/if}-->
<!--{eval
if($_GET[ecid]||$_GET['edid']||$_GET[fx]):
  $config[showguide] = 1;
endif;
if($_G['uid']==$v[uid] || IS_ADMINID):
    $catinfo['telpri']=0;
endif;
$bttxt = lang_hb('duanxin', 0);
$calltel = $v[mobile] ? "tel:$v[mobile]" : '';
$callsms = $v[mobile] ? "sms:$v[mobile]" : '';
if($v[weixin]):
  $calltel = "javascript:lxfs_tip(this, '$v[mobile]', '$v[weixin]');";
endif;
if($_G['uid']):
  $viewtels = C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], array($pubid));
endif;
if($v[wancheng]):
  $callsms = $calltel = "javascript:$.toast('{lang xigua_hb:xinxiwc}','error');";
else:
  $vcatid = $v[catid];
  $vtelp = $catinfo['telpri'];
  if($vtelp>0):
    include DISCUZ_ROOT. 'source/plugin/xigua_hb/include/c_addon.php';
    if(!$viewtels[$v[id]] && !$ishk):
      $callsms = $calltel = "javascript:hb_paytel('$v[id]','$vtelp','$vcatid');";
    endif;
  endif;
endif;
if($catinfo['hidereal']):
$calltel = $callsms = '';
endif;
}-->
<!--{if ($v[hb_num]>$v[hb_sendnum] && !$v[hongbaolog]) && $config[subscribe] && !getcookie('miniprogram') && ($config['secert']||$config['magapp_secret'])&& HB_INWECHAT}-->
<!--{eval
$wxpay = $config['appid'] && $config['appsecert'] && $config['key'];
if(HB_INWECHAT && $wxpay):
$openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
  if(!$openid):
   $tools = new JsApiPaySF();
   $opendata = $tools->GetFollowOpenid(hb_currenturl().'&oauth=yes');
   if($openid = $opendata['openid']):
    dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 864000);
   endif;
  endif;
endif;
}-->
<!--{/if}-->
<!--{eval
$vavatar = avatar($v['uid'], 'middle', true, false, true);
$subtit = $disvar = '';
foreach($v[vars] as $___k => $___v):
  if($___v[autoin]):
    $subtit = '| '.$___v[html];
    unset($v[vars][$___k]);
  endif;
  if($___v[type]=='location' || $___v[type]=='area'):
    $disvar = trim($___v[html]);
    unset($v[vars][$___k]);
  endif;
endforeach;
if($v[vars]):
  $v[vars] = array_values($v[vars]);
endif;
if($catinfo['pid']>0 && function_exists('array_column')):
    $pidindex = array_search($catinfo['pid'], array_column($cat_list, 'id'));
    $pidcat = $cat_list[$pidindex];
endif;
$hasvideo = $v['video'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php');
$vimglist = range(0, count($v[imglist])-1);
if($hasvideo):
    $vimglist = range(0, count($v[imglist]));
endif;

$adwhere = array();
$adwhere[] = 'types=\'view\'';
if($v['catid']):
    $adwhere[] = '( FIND_IN_SET('.intval($v['catid']).' , catids) OR FIND_IN_SET(-1, catids) )';
else:
    $adwhere[] = '( FIND_IN_SET(-1, catids) )';
endif;
$index_list =  C::t('#xigua_hb#xigua_hb_index')->list_by_where($adwhere);
$newindex_list = array();
if($index_list):
    foreach ($index_list as $index => $item):
        $newindex_list[$item['style']][] = $item;
    endforeach;
endif;
}--><style>#qrpr>div.weui-cells{padding:0 .75rem 0!important;}#qrpr>div.weui-cells:after{display:none}.ti_views{font-size:.7rem;color: #ababab;position: absolute;right: .8rem;}</style>
<div class="page__bd">
<!--{if $config[hbimg]&&$v[hb_money]>0}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$config[hbimg]" /></div><!--{/if}-->
<!--{if $v[imglist] || $hasvideo}-->
<div class="weui-cells after_none before_none mt0">
  <div class="fc_swipe cl" style="position:relative;margin:0;overflow:hidden" <!--{if $hasvideo}-->data-speed="60000000"<!--{else}-->data-speed="6000"<!--{/if}-->>
    <div class="swipe-wrap" style="transition: all .3s;-webkit-transition: all .3s">
        <!--{if $hasvideo}-->
        <div class="swp" style="background:#000"><video poster="{$v['video_cover']}" style="width:100%;display:block;max-height:80vh" src="{$v['video']}" controls="controls" <!--{if !IN_PROG}-->x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<!--{/if}-->></video></div>
        <!--{/if}-->
      <!--{loop $v[imglist] $_k $slider}-->
      <div class="imgloading swp"><img style="width:100%;max-height:80vh" src="$slider" /> </div>
      <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
      <ul class="position">
        <!--{loop $vimglist $k $__slider}-->
        <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
        <!--{/loop}-->
      </ul>
    </nav>
  </div>
</div>
<!--{/if}-->
<!--{if $catinfo['share_pic']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$catinfo['share_pic']" /></div><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_f']['defaultlogo']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$_G['cache']['plugin']['xigua_f']['defaultlogo']" /></div><!--{/if}-->
<div class="shottag2 none"><div class="feed_imglist cl feed-preview-pic"><img src="{echo $v[imglist][0]?$v[imglist][0]:$v['video_cover']}" /></div></div>
  <div>
    <div class="m-detail">
      <div class="m-detail-content">
        <div class="text-wrap"><h3 class="title">
            <i class="title-color main_bg" ></i>{$catinfo[name]}{lang xigua_hb:xinxi}
                <span class="ti_views"><span class="info-view">{$v[views]}{lang xigua_hb:ren}{lang xigua_hb:ck}</span> <span >{$v[shares]}{lang xigua_hb:shares}</span></span>
          </h3>
          <div class="house-for-sale-table table-info shottag1">
            <div class="table-info-title"><!--{if $catinfo['pid']>0 && $pidcat[name]}-->{$pidcat[name]} {lang xigua_hb:dot1} {$catinfo[name]}<!--{else}-->{$catinfo[name]}<!--{/if}--> $subtit</div>
            <div class="table-core-info">
              <div class="fieldr">
                <div class="labelr">{$v[vars][0][title]}</div>
                <div class="valuer">{echo $v[vars][0][html] ? $v[vars][0][html] : $v[vars][0][value]}</div>
              </div>
              <div class="fieldr">
                <div class="labelr">{$v[vars][1][title]}</div>
                  <div class="valuer">{echo $v[vars][1][html] ? $v[vars][1][html] : $v[vars][1][value]}</div>
              </div>
              <div class="fieldr">
                <div class="labelr">{$v[vars][2][title]}</div>
                  <div class="valuer">{echo $v[vars][2][html] ? $v[vars][2][html] : $v[vars][2][value]}</div>
              </div>
            </div>
            <!--{if array_filter($v[tags])}-->
            <div class="table-info-tags">
            <!--{loop $v[tags] $k $tag}-->
            <!--{if $tag}--><span class="tagr">$tag</span><!--{/if}-->
            <!--{/loop}-->
            </div>
          <!--{/if}-->
              <div class="table-more-info more-info">
              <div class="rowr">
<!--{eval $tmp = array_slice($v[vars], 3);}-->
          <!--{loop $tmp $___k $___v}-->
              <!--{if $___k && $___k%2==0}-->
              </div><div class="rowr">
              <!--{/if}-->
                  <div class="column"><span class="labelr">{$___v[title]}{lang xigua_hb:m}</span><span class="valuer">{echo $___v[html] ? $___v[html] : $___v[value]}</span></div>
          <!--{/loop}-->
              </div>
            </div>
          </div>
<!--{if $catinfo[in_ad]}-->
<a class="table-info" href="$catinfo[in_adlnk]" style="margin:0 -.75rem;display: block;"><img src="$catinfo[in_ad]" style="width:100%;display:block"></a>
<!--{/if}-->
          <div class="author">
            <a class="author-info" href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]">
              <img id="shottag_head" src="{avatar($v['uid'], 'middle', true)}" class="author-info-photo touchable">
              <div class="author-info-text">
                <p class="nameer touchable">{$v[realname]}</p>
                <time class="timefc">{$v[time_u]} <!--{if $v[refresh_times]}-->{lang xigua_hb:shuaxin}<!--{else}-->{lang xigua_hb:fabu0}<!--{/if}--></time>
              </div>
            </a>
            <div class="verify">
                <!--{eval
if($_G['cache']['plugin']['xigua_hr']):
$veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($v[uid]));
$veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($v[uid]), 2);
$bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($v[uid]));
endif;
if($_G['cache']['plugin']['xigua_hr']['showhbview']):
$shwv1 =1;
endif;
if($_G['cache']['plugin']['xigua_hr']['showbview']):
$shwv2 =2;
endif;
}-->
                <!--{if $veris1[$v[uid]] && !$veris2[$v[uid]]}--><a href="javascript:;"><i class="iconfont icon-duigou2 f12 main_color"></i> {lang xigua_hr:gr}</a><!--{/if}-->
                <!--{if $veris2[$v[uid]]}--><a href="javascript:;"><i class="iconfont icon-duigou2 f12 main_color"></i> {lang xigua_hr:qy}</a><!--{/if}-->
                <!--{if $bao[$v[uid]]}--><a href="javascript:;"><i class="iconfont icon-duigou2 f12 main_color"></i> <!--{if $_G[cache][plugin][xigua_hr][bzjed]}-->{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}<!--{else}-->{lang xigua_hr:yjbzj}<!--{/if}--></a><!--{/if}-->
            </div>
          </div>
          <div class="articler">
<!--{if $v[description]}-->
<span class="article-desc">{lang xigua_hb:ms}</span>
<p>{echo hb_nl2br($v[description])}</p>
<!--{/if}-->
            <p class="article-content">{echo str_replace('tname', $stinfo['name']?$stinfo['name']:$config[tname], $config[seefrom])}</p>
          </div>
          <div class="infor">
          <!--{if $disvar}-->
            <span class="info-position"><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC0AAAAtCAYAAAA6GuKaAAAAAXNSR0IArs4c6QAAB01JREFUWAntmXtolXUYxz1nm9u0EtG2nEqQqzSS2IyMylhmC5s2QROzEg1BCcVa4q7WtLFL88aISMEkS6lpWYSY9+FckV2WJVRGBFJbpt1M3aVd+jxv73P4vee87zln55z+CPzBb7/n+T237/u8z+/yng0a9D9svkRg7u/v95WVlU3w+XyjobPo1+H3EnwbY3tqauq3lZWVvyUilviIGXRjY2NSa2vrgwAspD+MLwHq1Xp5gBaE76L7dl1d3RkvxWjmYwJdXFxcCIhaAIyPJoipg10P/Ba/37+2urr6rCmLlh4Q6JKSkhtwvB2wdwcHAEw786cYpSR+pg+Fz4Ify5gLn2TaMH+R/nxNTc0Gcz4aOmrQAM7D4W4AjFDHBP0degvjHrJ2grFfZeZYWloqNjOwXUCfasqw2ZGWlraYmu8058PRUYGmHBbgfCsBk21nXfAN0DW1tbUCPOrGgn2gr6+vDl85htEJ6Hxq/U9jzpOMCFoyTIADeEgRL4D9iaEQsJ8JH0sjq8mdnZ0b8bvMsN8/adKkgrlz5/Yac66ko86CNewaPsj8Vbbs8/T09LyqqqrvgnUHwjc1NfUdP35835QpU2QhFtAlednt7e3XtLS07I/kyx9BQRadVcOSYQAXkCVZZAlpvK1XcPSc4expKR+DdyU9QbN4ZgFYd4kurAsTCVjRUMdVJGSX8na9hy1bV9BycAC4Rh3JoounhtWP18jusYwYF0VO3BwSNt9LV+Z1N3Do2CeddXDgTHaHwAM4FA2GtzCGxVXKVD59DP0S/SQgtpHNN6A9G7a/sH7WoVBpK61g3GHTIYNrpnlFs1SToJsjbWsEXNjR0XEK3afo2fQ0+gj6VPy8jnwvwLLUp9tItjeSoG6RYXd7eXn5aDc9mQsBjYHU00w1SE5O3qO02yiAsdmGbJibXOaQP8RbOAzwNC8dZBfQO2zLfT09PXKfcW0hoOW2hqZ1+eHJ29nePnG1ZJJAYwi0SeXotyYlJeWzywznbnEz/Bpkf4scvfEAr1JdtxGb93Qe2/uUDh5DahrnUo/avsLY9WgWBbuGrQwLYF7xnTyI9YoR/0GvZFGdotx0d3gG+Tq617b5pfi1m4lD56wxJNPMmrUnl59wTRad1chSsQFYpwdxIdoN86FMkBA/D3p/QBhE4MOMZ+JwaIaAxnHgXgztlRHLCfKx6m3w4MGeZcRbMGWeGczMzAzEM3FoDB1DQPO0lwNCv3+o0m4jYKy9VWRdXV0Zbjr2nCmTrdC1cYzrdUHuOAEcwcohoFEOPC21OCrYIIg/qTyZma+0OVIyI5EFjmb8B2xMPaHZqaJ6y26gzxjOcgw6hASMbHVWgy5j0c1RXkYBzP69E3Kk8AA+nZOTY9W38MGtu7vbjGficKiGgE5JSfkUjb9srXEVFRU3OiwMxj7p9tlTKbJLcPduYe/eRN8J4K+RWVkGcB99YYSr53R1T5keUTp4DAFNdnpwflQV2eQd2dN5HdmTF6P/jfKMd5H1FfRHoTXDfdAl7CQfGXoOkrhD8BMAjf1Bh4LBhIC2ZY2GzvKGhoZUg3eQBGtjf84h4Hq6gHM05k7T7+EqUO8QBDEs5MUAHS7TYsMDfhGkEmBdQQPiLTR+FC0cjWpra1sUsHAhAN4JqJXYjSbg4/QS+nJe8b25ubm3hMuwuJOkUFrPqmtsN9A9DzW5Z7g2FtVKHFnZwcGv9AkEP+eqHOck9b+W5KwWN8Q5l5GRcX1RUVGHl1vXTIsyvwq9xPC90DgcwQPIh2zCGwt3Iv5LDMdl4QCLnidoeeU89VLD2Tyy/4TBx03W19fL4SX35hRxRrxm3uZWocM1T9BiRJ0ewtFr6oCMbOGee4fy8Yz48p0/f347Pibafjo4XJYQz7OWNV7Yr3FRmjZt2oHe3l65X2fSkymTgry8vF3Nzc0XRB5r4yB5AeBL1B6wi/jBx3NvVj0Zw2ZaFCiTy2RAvmT0V88sHuII8563MLEL1yizVTx8heoAeCNvVcokqhYRtHjhQ+AHLvdzcN4pPBnK5op5FOCBu4LMR9MAXATgOkN3L1vlKoOPSEYFWrzw6o4Ceja9W3iA38QxfYxjfpzw0TS2ttUAXq+6+DrEiTqHh+/RuWhGz33ay5hMye8hu+jWVw+Bz9Fnsuo/9rIBlPwMthmbJ1UHm2NkeDoyzyuo6gaPAwYtDthbZxL0TUAMsR12wD9GXYZ8BKM7DFkjuvkaHP4DAD8C4Is6N5AxJtASgIxPBsj79GvtgP2AeZFju1xvcgC+jTn5eTjbALWVklg60JIw7GP/94U4oUYFzD4TFCCbuHPMo3anM/8y8nTRlYaskrex5l8u9r8xZ1pDAlxuZvJD5QydY5T7+NXKA/YCfRF1/47OxTPGDVqCA9gH+FKAyYHh2JGYk39pzAbw6XiAmraOAKZgIDSg+vmKqaYsZLFZV1pGqfFXWXCTEwlYcCUk0+JIm9yNuX/fCtizLDZ9ABVfGa9k4L/OwD8XQgWZqlS1SQAAAABJRU5ErkJggg=="  class="info-position-img"> <span class="info-position-text">{$disvar}</span></span>
          <!--{/if}-->
          </div>
        </div>
      </div>
      <div class="m-warn">
        <div class="content"><p>{lang xigua_hb:jlgc}</p>
        <p>{lang xigua_hb:jbydc}</p></div>
        <i class="middle-line"></i>
        <a class="report touchable" href="$SCRITPTNAME?id=xigua_hj">
          <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAADLElEQVR4Ae2aA7DeQBDHa9t2O6ht227vLqlt27YGtW3btm3bZr5u92Yyzy/9EL/szD4ffvlv7m73XjjHHHPMMcccC6MGnTpFBUGo5iKkm4vSTsBYOVi9OqItYV2MtUbINxIhENAR/hEQUsNesJSODAgZAvRfidKW9ghjSksisEsJWIb+Bo0bZ7E2LL6fCHuVA7nllO6weii35yCeOAhCZWuq27p1XL9FygPHNtdg6NBIVlR3ojKc4vvcwVrqNmmSESf9y2tgjAxo2jSeZYAlSjf4AXgPPcky25CvsNx5hIAoZjI37NChEVCZ82oAy77R3KFMSHN0UNOBsdLmVLd9+1io7nO1gbHPCzxyzLcNETJKbVg/Z6yFudRt3DgNKvHDTcUWSpRShGiE329xcwF7wSPITIeMFW7CrgjYDgDCI/xJN9uONss2VNiDrWZgCA9rvpvAP4CxtMbCygrpASy3X2nsNiQIjE9EL2DuIIpFjFG3W7foCPBYb2CJ0lM8soyoUQ3iE9AbWIYW9VVXFJPjRL8aBYxtnvAI0/OQsYAPbBSwDD1YL3Xz8CqjCYC/AiEp9Mh1D/EBDQb2O7VpfcioywcyDTBGGjCWV6tcNwpO7p6ZgGU/rNV5uZcKqd7oEPpd5Wu/QEg9ddVt1iwxTuyTCsDPQRRz+vXLWDm/7c23yLnPL+rUVHemykn9S/S3KvfZWx11GzXK5iJE4p2a2XkE4lyTqLEN7TY7bIDQnuWbuoRUtQqsDCyBIGT3dhuK5KL0hnWAZad0j7fn5c6aqMDYDH4PDJTm8LuhUNlR5WqeqctYfAR+p8HTP6TmYUZhAbsJrVtH9mQbmqrRSjouhEVxjUaR1MXdkmsWnNhvjd6xYwGrFdC0aTQc66FGD/c9tGiRwJ1taLPG++UiICQ3CEIhHGunpmMxNk21kqtFtqk/eCxOrbQyL7MTsKzyiNCB5ffJVk7pfiXgH7ZTmNJrSiF9127A6LsUq5E2VLifUrKQj9eJbLRKf+HFi/+docfaaMGi7v5jyhiLK/uNX/SF88R4XskzG34cxA4e8C3L1E7ILb5A8Tsvv8qH/c0xx/4BVg45kkK/F5IAAAAASUVORK5CYII=" class="report-img">
          <span class="report-text">{lang xigua_hj:wyjb}</span></a>
      </div>

<!--{loop $newindex_list $_k $_v}-->
<!--{if $_k==99}-->
<div class="swipe cl" data-speed="5000">
<div class="swipe-wrap">
    <!--{loop $_v $__k $__v}-->
    <div><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
    <!--{/loop}-->
</div>
<nav class="cl bullets bullets1 none">
    <ul class="position">
        <!--{loop $_v $__k $__v}-->
        <li <!--{if $__k==0}-->class="current"<!--{/if}-->></li>
        <!--{/loop}-->
    </ul>
</nav>
</div>
<!--{else}-->
<!--{eval
if(!$_k):
$_k = 4;
endif;
$tmpp = array_chunk($_v, $_k);
}--><!--{loop $tmpp $__k $tmpp2}-->
<!--{eval $counttmpp2 = count($tmpp2);}-->
<ul class="inedxicon cl" style="padding:0">
<!--{loop $tmpp2 $__k $__v}-->
<li style="width:{echo 100/$counttmpp2;}%"><a href="$__v[adlink]"><img src="$__v[icon]"></a></li>
<!--{/loop}-->
</ul>
<!--{/loop}-->
<!--{/if}-->
<!--{/loop}-->

      <a href="$SCRITPTNAME?id=xigua_hb&ac=cat&cat_id={$catinfo[id]}">
        <div class="m-category-title">
          <div class="category-info">
            <img src="{echo $catinfo['pid']>0 && $pidcat[icon] ? $pidcat[icon] : $catinfo[icon]}" class="category-info-icon">
            <div class="category-info-text">
              <h5 class="category-info-text-main">{$catinfo[name]}</h5>
            <!--{if $pidcat}-->
            <span class="category-info-text-sub">{lang xigua_hb:lz}{$pidcat[name]}{lang xigua_hb:xinxi}</span>
            <!--{else}-->
            <span class="category-info-text-sub">{lang xigua_hb:lz}{$catinfo[name]}{lang xigua_hb:xinxi}</span>
            <!--{/if}-->
            </div>
          </div>
          <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAtCAYAAAC53tuhAAAAAXNSR0IArs4c6QAAAT9JREFUWAnt18ENgjAUBmBanICbO3hxB4/EMRzAE2EAwskB2MKEozt4cQdvbAD4HnJoSBpe+/5jm6itPvrR1+QVsyy1lIGUAVAGjGSeuq6P8zyXxpi+aZqv5Jq9GLsXwL9P0/SkVzeO46eqqrPkmr0YEexMUtDKXwhcBFtrb4QP6w1AcNEeM8ir5NVSt1hvYKA9v7Rt+17HQR9imGdF4kEwEg+GUXgUjMCjYS2ugjW4Go7FIXAMDoNDcSjsw/M8P21PNVGt5gmljUso1fa7E8+1vXTGSxcOc1mlI/ThQFzTe2eMh321fJtmlmF77EN9pxcEDkUhK45B1XAsqoI1aDSsRaNgBBoMo9AgGImKYTTKsKhWU5HvKBbyPM0oNxH8D13eVQ/xzjzZwR34+nSeXvloQ/5b9Fnp+5SBlIHgDPwAav8Fwty/hBoAAAAASUVORK5CYII=" class="category-arrow">
        </div>
      </a>
    </div>
  </div>
<!--{if $v[hb_num]}-->
<div class="weui-cells__title weui_title border_none"><span>{lang xigua_hb:yiqiang}<em class="color-red">$v[hb_sendnum]</em>/$v[hb_num]{lang xigua_hb:fen}</span> <!--{if $v[hb_sendnum]}--><a class="y c9" href="$SCRITPTNAME?id=xigua_hb&ac=hong_list&pubid=$v[id]">{lang xigua_hb:kk}<i class="f13 iconfont icon-jinrujiantou"></i></a><!--{/if}--></div>
<div class="weui-cells after_none" id="hong_preview_list"></div>
<!--{/if}-->
<!--{if !$config[closepl]}-->
<div class="mt10 bgf">
<div class="jl_fc_cmt_box">
<div class="weui-cells__title weui_title border_none jl_fc_cmt" style="margin-top:0"><span>{lang xigua_hb:comments}</span> <a class="comment y c9" id="comment_$v[id]" data-id="$v[id]" data-multi="1">{lang xigua_hb:wycomments}<i class="f13 iconfont icon-jinrujiantou"></i></a></div>
<div class="weui-panel weui-panel_access mt0 after_none">
    <div class="weui-panel__bd comment_ul" id="comment_ul_$v[id]" data-id="$v[id]">
    </div>
</div>
</div>
</div>
<!--{/if}-->

<!--{if $config[showother]}-->
<!--{template xigua_hb:list_by_cat}-->
<!--{/if}-->

<!--{if !IN_PROG && $v[hb_num]>$v[hb_sendnum] && !$v[hongbaolog]}-->
<a href="javascript:;"  style="position: fixed;right: .5rem;bottom: 15rem;z-index:99" <!--{if $_G[uid]}--> <!--{if $v[hbtiaojian]}-->onclick="return showfxhb();"<!--{else}-->class="qiang"<!--{/if}--><!--{else}-->onclick="return checklogin();"<!--{/if}-->><img src="source/plugin/xigua_hb/static/img/hbic.png" style="width: 3rem;display: block;"></a>
<!--{if 1}-->
<div class="hong_res animated zoomIn" id="hong_res">
  <a class="hong_close"><i class="iconfont icon-guanbijiantou f22"></i></a>
  <div class="hong_res_wrap">
    <div class="hong_res_head">
      <div class="hong_res_head_in">
        <img src="{avatar($v['uid'], 'middle', true)}">
      </div>
    </div>
    <div class="hong_res_cnt">
      <div class="hong_res_box">
        <p>{$v[user][username]}</p>
        <p>{lang xigua_hb:maile}</p>
      </div>
      <div class="hong_res_list">
        <div class="send_title"></div>
        <div class="hong_tip">{lang xigua_hb:gongxihou}</div>
        <div class="money_bg">
          <p class="hong_money">
            <i>&yen;</i>
            <span id="hong_size">{$v[hb_money]}</span>
            <em>{lang xigua_hb:yuan}</em>
          </p>
        </div>
        <a <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jump_download();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao"<!--{/if}--><!--{/if}--> class="sub_title">{lang xigua_hb:zidongfang}</a>
      </div>
    </div>
    <div class="view_oth">
      <a href="$SCRITPTNAME?id=xigua_hb&ac=hong_list&pubid=$v[id]">{lang xigua_hb:kkdaj}</a>
    </div>
    <div class="sub_bg"></div>
  </div>
</div>
<div class="hong_res hong_box" id="hong_box">
  <div class="hong_box_main zoomIn animated ">
    <div class="hong_box_title">
      <div class="send_title"></div>
      <div class="hong_star"></div>
      <div class="hong_box_showname">
        <p>{lang xigua_hb:zongji}{$v[hb_money]}{lang xigua_hb:yuan}</p>
      </div>
      <div class="hong_btn animated" id="hong_btn" onclick="showHongBox(this);">
        <div class="hong_btn_mask"></div>
        <a href="javascript:;"> </a>
      </div>
    </div>
    <div class="hong_from">
      <p>{$v[user][username]}</p>
      <p>{lang xigua_hb:mai}</p>
    </div>
    <div class="view_oth">
      <p>{lang xigua_hb:lingqu}{$config['tname']}{lang xigua_hb:qb}</p>
    </div>
    <div class="sub_bg"></div>
  </div>
</div>
<!--{/if}-->
<!--{if $config[voice]}-->
<div class="none"><audio id="media" preload="preload"><source src="{$config[voice]}" type="audio/mpeg" /></audio></div>
<!--{/if}-->
<!--{if !$_G[uid]}-->
<script>
  function checklogin(){
    $.showLoading();
    $.ajax({
      type: 'get',
      url: '$SCRITPTNAME?id=xigua_hb&ac=my&inajax=1',
      dataType: 'xml',
      success: function (data) {
        $.hideLoading();
        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
        var s = data.lastChild.firstChild.nodeValue;
        tip_common(s);
      },
      error: function () {
        $.hideLoading();
      }
    });
  }
</script>
<!--{/if}-->
<script>
  var HAS_QIANG = 0, Qlock =0;
  function showHongBox(obj) {
<!--{if $v[hbtiaojian]<=0}-->
    $('#wechat-mask').hide();
    if(Qlock || HAS_QIANG){ console.log('false'); return false;}
    Qlock = 1;
    $.ajax({
      type: 'post',
      url: '$SCRITPTNAME?id=xigua_hb&ac=qiang&pubid=$v[id]&inajax=1'+(typeof hbareaallow !=='undefined'?'&lat='+hblat+'&lng='+hblng:'' ),
      data: {'formhash':FORMHASH},
      dataType: 'xml',
      success: function (data) {
        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
        var s = data.lastChild.firstChild.nodeValue;
        if(s.indexOf('success')!==-1){
          HAS_QIANG = 1;
          $('#hong_box').removeClass('show').hide();
          $('#hong_res').show();
          $('#hong_size').html(s.split('|')[1]);
          $('.fix-bottom').hide();
        }else{
          $('#hong_size').html('???');
          $('#hong_box').removeClass('show').hide();
          tip_common(s);
        }
      },
      error: function () {
      }
    });
<!--{/if}-->
  }

  function focusHongBao(){
<!--{if $v[hbtiaojian]>0}-->
return false;
<!--{/if}-->
    <!--{if $config[subscribe] && !getcookie('miniprogram')&& HB_INWECHAT}-->
    var unscb = 0;
    $.showLoading();
    $.ajax({
      type: 'get',
      url: _APPNAME + '?id=xigua_hb&ac=checksub&inajax=1&openid=$openid',
      data: {formhash: FORMHASH},
      dataType: 'xml', async:false,
      success: function (data) {
        if (null == data) {
          return false;
        }
        var s = $.trim(data.lastChild.firstChild.nodeValue);
        if (s.split('|')[1] != 'subscribe') {
          unscb = 1;
        }
        $.hideLoading();
      }
    });

    $.hideLoading();
    if(unscb){
      /*if(typeof wx !=='undefined') {
        if (window.__wxjs_environment === 'miniprogram') {
          wx.miniProgram.navigateTo({url: '/pages/guanzhu/index'});
          return false;
        }
      }*/
      $.alert("<img src=$SCRITPTNAME?id=xigua_hb:qrauto&ode=pub_{$v[id]} /><br>{lang xigua_hb:gzq}", "{lang xigua_hb:gzqchangan}");
      return false;
    }
    <!--{/if}-->
    $.ajax({type: 'post',url: _APPNAME +'?id=xigua_hb&ac=incr&incr_type=shares&pubid=$pubid&inajax=1',data: {'formhash':FORMHASH},dataType: 'xml'});
    if(!HAS_QIANG) {
      $.ajax({
        type: 'post',
        url: '$SCRITPTNAME?id=xigua_hb&ac=qchk&pubid=$v[id]&inajax=1',
        data: {'formhash':FORMHASH},
        dataType: 'xml',
        success: function (data) {
          if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
          var s = data.lastChild.firstChild.nodeValue;
          if(s.indexOf('success')!==-1){
            $('#hong_box').addClass('show').show();
            <!--{if $config[autoopen]}-->$('#hong_btn').trigger('click');<!--{/if}-->
          }else{
            $('#hong_box').removeClass('show').hide();
            tip_common(s);
          }
        }
      });
    }else{
      $.toast('{lang xigua_hb:qianguole}', 'error');
    }
  }
</script>
<!--{if HB_INWECHAT &&$v[hbtiaojian]<=0}-->
<script>
  <!--{if $config[onlytimeline]=='no'}-->
  function menuShareGet(){
    <!--{else}-->
    function menuShareTimeline(){
      <!--{/if}-->
      focusHongBao();
    }
    function menuShareTimelineErr(){
      $.toast('{lang xigua_hb:quxiaofenxiang}');
      $('#wechat-mask').hide();
    }
    function menuShareCommon(){
      <!--{if $config[onlytimeline] == 'pyq'}-->
      $.toast('{lang xigua_hb:fenxiangqiang}');
      $('#wechat-mask').hide();
      <!--{else}-->
      if(typeof 'menuShareTimeline'!=='undefined'){
        menuShareTimeline();
      }
      if(typeof 'menuShareGet'!=='undefined'){
        menuShareGet();
      }
      <!--{/if}-->
    }
    function menuShareCommonErr(){
      menuShareTimelineErr();
    }
</script>
<!--{elseif IN_MAGAPP}-->
<script>
  function menuShareGet() {
    <!--{if $config[onlytimeline]=='py'}-->
    mag.share('ALL', function (res) {
      focusHongBao();
    });
    <!--{/if}-->
    <!--{if $config[onlytimeline]=='pyq'}-->
    mag.share('WEIXIN_CIRCLE', function (res) {
      focusHongBao();
    });
    <!--{/if}-->
    <!--{if $config[onlytimeline]=='no'}-->
    focusHongBao();
    <!--{/if}-->
  }
</script>
<!--{elseif IN_QIANFAN}-->
<script>
  <!--{if $config[onlytimeline]=='py'}-->
  $(document).on('click', '.qiang', function(){
    if(typeof hbareaallow !=='undefined') {
      if(!hbareaallow()){
        return false;
      }
    }
    QFH5.openShareDialog();
  });
  function openShareDialog(){
    focusHongBao();
  }
  <!--{/if}-->
  <!--{if $config[onlytimeline]=='pyq'}-->
  $(document).on('click', '.qiang', function(){
    if(typeof hbareaallow !=='undefined') {
      if(!hbareaallow()){
        return false;
      }
    }
    QFH5.openShare(1);
  });
  function openShare(){
    focusHongBao();
  }
  <!--{/if}-->
  <!--{if $config[onlytimeline]=='no'}-->
  $(document).on('click', '.qiang', function(){
    if(typeof hbareaallow !=='undefined') {
      if(!hbareaallow()){
        return false;
      }
    }
    focusHongBao();
  });
  <!--{/if}-->
</script>
<!--{elseif IN_APPBYME}-->
<script>
  <!--{if $config[onlytimeline]=='py'}-->
  connectSQJavascriptBridge(function(){
    sq.setShareCallBack(function(data){
      //alert(JSON.stringify(data));//sharePlat
      if(data.errmsg=='SHARE_OK'||data.errmsg=='OK'){
        focusHongBao();
      }
    });
  });
  <!--{/if}-->
  <!--{if $config[onlytimeline]=='pyq'}-->
  connectSQJavascriptBridge(function(){
    sq.setShareCallBack(function(data){
      //alert(JSON.stringify(data));//sharePlat
      if((data.errmsg=='SHARE_OK'||data.errmsg=='OK') && data.sharePlat=='MOMENTS'){
        focusHongBao();
      }
    });
  });
  <!--{/if}-->
  <!--{if $config[onlytimeline]=='no'}-->
  $(document).on('click', '.qiang', function(){
    if(typeof hbareaallow !=='undefined') {
      if(!hbareaallow()){
        return false;
      }
    }
    focusHongBao();
  });
  <!--{/if}-->
</script>
<!--{else}-->
<!--{if $config[onlytimeline]=='no'}-->
<script>
  $(document).on('click', '.qiang', function(){
    if(typeof hbareaallow !=='undefined') {
      if(!hbareaallow()){
        return false;
      }
    }
    focusHongBao();
  });
</script>
<!--{/if}-->
<!--{/if}-->

<!--{/if}-->

</div>

<!--{if ($_G[uid] == $v[uid]||IS_ADMINID) }-->
<a href="javascript:;" style="bottom:7rem;" class="hbzder1 main_bg" id="pubitem_$v[id]" data-id="$v[id]" data-uid="$v[uid]" data-wc="{$v[wancheng]}" <!--{if $v[display]}-->data-canzd="1"<!--{/if}--> <!--{if (!$v[hb_num]||$v[hb_num]==$v[hb_sendnum])&&$v[display]&&$config[red]}-->data-canhb="1"<!--{/if}--> <!--{if !$v[pay_status]}-->data-catid="$v[catid]"<!--{/if}--> onclick="return showansi(this);"><!--{if $_G[uid] == $v[uid]}-->{lang xigua_hb:kuosan}<!--{elseif IS_ADMINID}-->{lang xigua_hb:guanli0}<!--{/if}--><i class="iconfont icon-jinrujiantou f12"></i></a>
<!--{/if}-->
<div class="footer_fix"></div>
<style>.jl_clv_bottom{box-shadow:0 0 0.5rem rgba(0,0,0,.1)}
.footer-bottom{display:-webkit-box;display:flex;position:fixed;left:0;bottom:0;padding-left:.5rem;padding-right:.5rem;padding-top:.5rem;padding-bottom:calc(.5rem + constant(safe-area-inset-bottom));padding-bottom:calc(.5rem + env(safe-area-inset-bottom));width:100%;min-height:3.3rem;background:#fff;box-sizing:border-box;z-index:499}
.footer-bottom .btns-icon{display:-webkit-box;display:flex;flex:1}
.footer-bottom a,.footer-bottom span{display:inline-block;overflow:hidden;text-overflow:ellipsis;position:relative}
.footer-bottom .item-focus,.footer-bottom .item-loan{padding-top:.3rem;color:#111e36}
.footer-bottom .btns-icon .item-focus,.footer-bottom .btns-icon a{flex:1;text-align:center}
.footer-bottom .btns-icon em{display:block;font-size:.6rem;line-height:1}
.footer-bottom .btns-icon i{line-height:1}
.footer-bottom .item-prize,.footer-bottom .item_clinfo{height:2.5rem;line-height:2.5rem;background:#f60;border-radius:.5rem;text-align:center;font-size:.8rem;color:#fff;flex:1}
.footer-bottom .item-prize{margin-right:.5rem;max-width:5rem;margin-left:.5rem}</style>
<div class="footer-bottom jl_clv_bottom">
    <p class="btns-icon">
        <a href="$SCRITPTNAME?id=xigua_hb">
            <span class="item-loan">
                <i class="iconfont icon-index f20"></i>
                <em>{lang xigua_hb:shouye}</em>
            </span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hb&ac=pub">
            <span class="item-loan">
                <i class="iconfont icon-fabu f20"></i>
                <em>{lang xigua_hb:fabu0}</em>
            </span>
        </a>
        <!--{if $config[showguide]||!HB_INWECHAT}-->
        <a style="position:relative;top:-1px" href="javascript:;" <!--{if IN_MAGAPP}-->onclick="return mag.share('ALL', function(res){});"<!--{elseif IN_QIANFAN}-->onclick="QFH5.openShareDialog();return false;"<!--{elseif $config[xxhb]}-->onclick="return sp_newewm();"<!--{/if}-->  class="<!--{if IN_MAGAPP||IN_QIANFAN||$config[xxhb]}--><!--{else}-->we_share<!--{/if}-->" data-id="$v[id]">
        <span class="item-loan">
                <i class="iconfont icon-fenxiang1 f22"></i>
                <em>{lang xigua_hb:shares}</em>
            </span>
        </a>
        <!--{/if}-->
    </p>
    <!--{if $kflnk}--><!--{eval
        if(!(IN_QIANFAN||IN_MAGAPP) && ($config[magapp_secret] || $config[hostname])):
            $kflnk = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=$v[uid]";
        endif;
        $bttxt = lang_hb('sx', 0);
        $callsms = $kflnk;}--><!--{/if}-->
    <!--{if $config[showsms] && $callsms}-->
    <a href="$callsms" class="item-prize main_bg">$bttxt</a>
    <!--{if $calltel}-->
    <a href="$calltel" class="item_clinfo">
        <span class="footer-item">{lang xigua_hb:boda}</span>
    </a>
    <!--{/if}-->
    <!--{elseif $calltel}-->
    <a href="$calltel" class="item_clinfo">
        <span class="footer-item">{lang xigua_hb:boda}</span>
    </a>
    <!--{else}-->
    <a href="$callsms" class="item-prize main_bg">$bttxt</a>
    <!--{/if}-->
</div>
<script>
  var TIMELINE_TITLE = '{$navtitle}'<!--{if 0}-->, custom_title = '{$v[user][username]}{lang xigua_hb:fblyt}{$catinfo[name]}{lang xigua_hb:xinxi}'<!--{/if}-->;
  var loadingurl = '$SCRITPTNAME?id=xigua_hb&ac=list_item&cat_id={$v[catid]}&notpubid=$v[id]&inajax=1&pagesize=5&page=';
  function shareIncr(){
    $.ajax({type: 'post',url: _APPNAME +'?id=xigua_hb&ac=incr&incr_type=shares&pubid=$pubid&inajax=1',data: {'formhash':FORMHASH},dataType: 'xml'});
  }
</script>
<!--{if $config[xxhb]}-->
<!--{template xigua_hb:qrcode}-->
<!--{/if}-->
<!--{template xigua_hb:common_footer}-->
<script>
  setTimeout(function () {$('.hbzder1').addClass('r-21');}, 800);
  if($('#hong_preview_list').length>0){
    load_common_list('$SCRITPTNAME?id=xigua_hb&ac=hong_li&pubid=$v[id]&inview=1&inajax=1&pagesize=5', 'hong_preview_list');
  }
  <!--{if !$config[closepl]}-->
  load_common_list('$SCRITPTNAME?id=xigua_hb&ac=comment_li&pubid=$v[id]&inajax=1&pagesize=5&needmore=1', 'comment_ul_$v[id]');
  var cpage = 1;
  $(document).on('click', '#comment_ul_more', function(){
    $('#comment_ul_more').remove();
    cpage ++;
    load_common_list('$SCRITPTNAME?id=xigua_hb&ac=comment_li&pubid=$v[id]&inajax=1&pagesize=5&needmore=1&page='+cpage, 'comment_ul_$v[id]');
  });
  <!--{/if}-->
  $(function () {
    if(localStorage.getItem('wetip_{$pubid}')){
      $('.we_share').trigger('click');
      localStorage.removeItem('wetip_{$pubid}');
    }
    <!--{if $_G['uid'] && $v[hb_num]>0 && $v[hb_num]==$v[hb_sendnum] && !$v[hongbaolog]}-->
    if(!localStorage.getItem('hbtip_{$pubid}')){
      // $.toast('{lang xigua_hb:qiangwan}', 2000);
      $('body').append('<a href="$SCRITPTNAME?id=xigua_hb&ac=hongbao{$urlext}" class="qwl">{lang xigua_hb:qiangwan1}</a>');
      localStorage.setItem('hbtip_{$pubid}', 1);
    }
    <!--{/if}-->
    <!--{if $_G['cache']['plugin']['xigua_hs']}-->
    <!--{/if}-->
  });
  function jump_download() {
    $.confirm("$config[qbguide]", function() {
      window.location.href = '$config[qbguidelink]';
    }, function() {});
    return false;
  }
  <!--{if $distvar}-->
  $(document).on('click', '#hb_openLocation', function () {
    var that = $(this);
    if(('{HB_INWECHAT}' && "{$_G['cache']['plugin']['xigua_hb'][multiupload]}")==1){
      wx.openLocation({
        latitude: that.data('lat'),
        longitude: that.data('lng'),
        name: that.data('name'),
        address: that.data('addr'),
        scale: 14,
        infoUrl:window.location.href
      });
    }else if("{$_G['cache']['plugin']['xigua_hs']['google']}"){
      window.location.href = _APPNAME+'?id=xigua_hs&ac=googleMap&lat='+that.data('lat')+"&lng="+that.data('lng')+_URLEXT;
    }else{
      window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:"+that.data('lat')+","+that.data('lng')+";title:"+that.data('name')+";addr:"+that.data('addr');
    }
    return false;
  });
  <!--{/if}-->
  $(document).on('click','.dofollow', function () {
    var that = $(this);
    $.showLoading();
    $.ajax({
      type: 'post',
      url: _APPNAME +'?id=xigua_hb&ac=fav&do=do_follow&pubid='+that.data('id')+'&inajax=1',
      data: {'formhash':FORMHASH},
      dataType: 'xml',
      success: function (data) {
        $.hideLoading();
        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
        var s = data.lastChild.firstChild.nodeValue;
        if(s.split('|')[1]> 0){
          tip_common('success|{lang xigua_hb:sccg}||');
          that.find('.iconfont').removeClass('icon-collection').addClass('icon-collection_fill');
          that.find('em').text(s.split('|')[1]);
        }else{
          tip_common(s);
          that.find('em').text(that.find('em').text()-1);
          that.find('.iconfont').removeClass('icon-collection_fill').addClass('icon-collection');
        }
      },
      error: function () {
        $.hideLoading();
      }
    });
  });
</script>
<!--{if $_G['cache']['plugin']['xigua_hs'] && trim($config['areaallow'])}-->
<script>
  var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";
</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script>
  var hblat = '', hblng = '';
  setTimeout(function () {
    hs_getlocation(function (position) {
      hblat = (position.latitude||position.lat);
      hblng = (position.longitude||position.lng);
    });
    if(typeof wx !=='undefined') {
      hs_getlocation(function (position) {
        hblat = (position.latitude||position.lat);
        hblng = (position.longitude||position.lng);
      });
    }
  }, 800);
  function hbareaallow(){
    var hb_areaallow = false;
    if(!hblat || !hblng) {
      $.toast('{lang xigua_hb:plzlat}', 'cancel');
      hs_getlocation(function (position) {
        hblat = (position.latitude||position.lat);
        hblng = (position.longitude||position.lng);
      });
      return false;
    }
    $.ajax({
      type: 'GET',
      async: false,
      url: _APPNAME + '?id=xigua_hs&ac=getloc&lat='+hblat+'&lng='+hblng+'&inajax=1&checkallow=1',
      dataType: 'xml',
      success: function (data) {
        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
        var s = data.lastChild.firstChild.nodeValue;
        if(s.indexOf('error')!=-1){
          tip_common(s);
          hb_areaallow =false;
        }else {
          hb_areaallow = true;
        }
      },
      error: function () {
      }
    });
    return hb_areaallow;
  }
</script>
<!--{/if}-->
<!--{if !$_GET[ecid] && $info[uid]==$_G[uid] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/template/touch/share_dig.php')}-->
<!--{template xigua_hb:share_dig}-->
<!--{/if}-->
<!--{if is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php')}-->
<!--{template xigua_hb:hbrw_view}-->
<!--{/if}-->
<script>
$('div.fc_swipe').each(function () {
    fc_slider($(this), $(this).data('speed') || 3000)
});
var fc_seiper = null;
function fc_slider(_this, auto) {
    var bullets = _this.find('nav.bullets');
    var position = _this.find('ul.position');
    fc_seiper = new Swipe2(_this[0], {
        visibilityFullFit : true,
        startSlide: 0, speed: 500, auto: auto, continuous: true, callback: function (index) {
            if (bullets.length > 0) {
                bullets.find('em:first-child').text(index + 1);
            }
            if (position.length > 0) {
                var selectors = position[0].children;
                for (var t = 0; t < selectors.length; t++) {
                    selectors[t].className = selectors[t].className.replace("current", "");
                }
                if (typeof selectors[(index) % (selectors.length)] != 'undefined') {
                    selectors[(index) % (selectors.length)].className = "current";
                }
            }
            var H = $(".swipe-wrap .swp").eq(index).height();
            $('.fc_swipe .swipe-wrap').css('height', H);
        }
    });
}
</script>