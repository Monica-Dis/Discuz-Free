<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/3/11
 * Time: 0:03
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

//$_G['siteurl'] = str_replace('http://', 'https://', $_G['siteurl']);
include_once DISCUZ_ROOT.'source/plugin/xigua_login/class.php';
function xglogin_x_unescape($str) {
    $str = str_replace(array('&','_','>','<','~','|','=','-',';','"','}','{', '`', '(', ')', ',',
                        '%','(',')','!','@','$','~','^','*','#','\\','.','?','/','+',' '), '', $str);
    $str = rawurldecode($str);
    preg_match_all("/(?:%u.{4})|&#x.{4};|&#\d+;|.+/U",$str,$r);
    $ar = $r[0];
    foreach($ar as $k=>$v) {
        if(substr($v,0,2) == "%u"){
            $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,-4)));
        }
        elseif(substr($v,0,3) == "&#x"){
            $ar[$k] = iconv("UCS-2BE","UTF-8",pack("H4",substr($v,3,-1)));
        }
        elseif(substr($v,0,2) == "&#") {

            $ar[$k] = iconv("UCS-2BE","UTF-8",pack("n",substr($v,2,-1)));
        }
    }
    $return = implode("",$ar);
    $guestexp1 = '\xE3\x80\x80|\xE6\xB8\xB8\xE5\xAE\xA2|\xE9\x81\x8A\xE5\xAE\xA2|^Guest';
    $guestexp2 = '\xA1\xA1|\xD3\xCE\xBF\xCD|^Guest';
    $guestexp3 = '\xA1\x40|\xB9\x43\xAB\xC8|^Guest';
    $return = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&\(\)']|$guestexp1/is",'', $return);
    $return = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&\(\)']|$guestexp2/is",'', $return);
    $return = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&\(\)']|$guestexp3/is",'', $return);
    return $return;
}

function xg_register($username, $avatar, $auto = 1, $showmsg = 1) {
    global $_G;
    $config = $_G['cache']['plugin']['xigua_login'];

    $username = xglogin_x_unescape($username);

    loaducenter();
    $groupid = $config['groupid'] ? $config['groupid'] : $_G['setting']['newusergroupid'];

    if($_GET['password']=trim($_GET['password'])){
        if($_GET['password'] != addslashes($_GET['password'])) {
            if($showmsg) {
                showmessage('profile_passwd_illegal');
            }
        }
    }
    $password = $_GET['password'] ? md5($_GET['password']) : md5(random(10));

    $email = strtolower(random(12)).'@wechat.com';

    if($auto){
        $usernamelen = dstrlen($username);
        if(!$username){
            $username = 'wx_'.mt_rand(100000, 999999);
        }
        if($usernamelen < 3) {
            $username = $username.mt_rand(1000, 9999);
        }
        if($usernamelen > 15) { //uc_client/model/user.php //uc_server/model/user.php check_username ���� 15 ==>25
            $username = cutstr($username, 15, '');
        }

        $guestexp = '\xA1\xA1|\xAC\xA3|^Guest|^\xD3\xCE\xBF\xCD|\xB9\x43\xAB\xC8';
        $username = preg_replace("/\s+|^c:\\con\\con|[%,\*\"\s\<\>\&]|$guestexp/is",'', $username);

        if(C::t('common_member')->fetch_by_username($username) || uc_user_checkname($username)!='1'){
            /*
                        $user = DB::fetch_first('SELECT * FROM %t WHERE username=%s', array('common_member', $username));
                        global $openid;
                        C::t('#wechat#common_member_wechat')->update($user['uid'], array('openid' => $openid));*/

            $username =  cutstr($username, 11, '').mt_rand(1000, 9999);
            if($config['confilt']){
                return '-9999';
            }
        }
    }

    global $openid;
    if($openid){
        $fetch = DB::fetch_first('SELECT * FROM %t WHERE openid=%s ORDER BY uid ASC', array('common_member_wechat', $openid));
        if($fetch){
            return $fetch['uid'];
        }
    }

    $censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';
    $_G['setting']['censoruser'] && @preg_replace($censorexp, '_', $username);

    $sms = '';
    @include_once DISCUZ_ROOT. 'source/discuz_version.php';
    if(DISCUZ_VERSION == 'F1.0' && function_exists('uc_user_register_new')){
        $sms = $_GET['mobile'] ? $_GET['mobile'] : '189'.mt_rand(10000000, 99999999);
        $uid = uc_user_register_new(addslashes($username), $password, $email, $sms, '', '', $_G['clientip']);
    }else{
        if(!$username){
            $username = 'wx_'.mt_rand(10000, 99999);
        }
        $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
    }
    if($uid <= 0) {
        if($uid == -1) {
            return $uid;
//            showmessage('profile_username_illegal');
        } elseif($uid == -2) {
            return $uid;
//            showmessage('profile_username_protect');
        } elseif($uid == -3) {


            return $uid;
//            showmessage('profile_username_duplicate');
        } elseif($uid == -4) {
            if($showmsg){
                showmessage('profile_email_illegal');
            }
        } elseif($uid == -5) {
            if($showmsg) {
                showmessage('profile_email_domain_illegal');
            }
        } elseif($uid == -6) {
            if($showmsg) {
                showmessage('profile_email_duplicate');
            }
        } else {
            if($showmsg) {
                showmessage($sms . '_' . $uid . '_undefined_action');
            }
        }
        return $uid;
    }

    $init_arr = array('credits' => explode(',', $_G['setting']['initcredits']), 'emailstatus' => 1);
    if($sms) {
        C::t('common_member')->insert_new($uid, $username, $password, $email, $sms, $_G['clientip'], $groupid, $init_arr);
    }else{
        C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, $init_arr);

        /*$extdata = $init_arr;
        $adminid = 0;
        $ip = $_G['clientip'];

        $credits = isset($extdata['credits']) ? $extdata['credits'] : array();
        $profile = isset($extdata['profile']) ? $extdata['profile'] : array();
        $profile['uid'] = $uid;
        $base = array(
            'uid' => $uid,
            'username' => (string)$username,
            'password' => (string)$password,
            'email' => (string)$email,
            'adminid' => intval($adminid),
            'groupid' => intval($groupid),
            'regdate' => TIMESTAMP,
            'emailstatus' => intval($extdata['emailstatus']),
            'credits' => dintval($credits[0]),
            'timeoffset' => 9999
        );
        $status = array(
            'uid' => $uid,
            'regip' => (string)$ip,
            'lastip' => (string)$ip,
            'lastvisit' => TIMESTAMP,
            'lastactivity' => TIMESTAMP,
            'lastpost' => 0,
            'lastsendmail' => 0
        );
        $count = array(
            'uid' => $uid,
            'extcredits1' => dintval($credits[1]),
            'extcredits2' => dintval($credits[2]),
            'extcredits3' => dintval($credits[3]),
            'extcredits4' => dintval($credits[4]),
            'extcredits5' => dintval($credits[5]),
            'extcredits6' => dintval($credits[6]),
            'extcredits7' => dintval($credits[7]),
            'extcredits8' => dintval($credits[8])
        );
        $ext = array('uid' => $uid);
        DB::insert('common_member', $base);
        C::t('common_member_status')->insert($status, false, true);
        C::t('common_member_count')->insert($count, false, true);
        C::t('common_member_profile')->insert($profile, false, true);
        C::t('common_member_field_forum')->insert($ext, false, true);
        C::t('common_member_field_home')->insert($ext, false, true);*/

    }


    if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
        C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
        if($_G['setting']['regctrl']) {
            C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
        }
    }

    if($_G['setting']['regverify'] == 2) {
        C::t('common_member_validate')->insert(array(
            'uid' => $uid,
            'submitdate' => $_G['timestamp'],
            'moddate' => 0,
            'admin' => '',
            'submittimes' => 1,
            'status' => 0,
            'message' => '',
            'remark' => '',
        ), false, true);
        manage_addnotify('verifyuser');
    }

    if($showmsg){
        setloginstatus(array(
            'uid' => $uid,
            'username' => $username,
            'password' => $password,
            'groupid' => $groupid,
        ), 0);

        C::t('common_member_status')->update($uid, array('lastip'=>$_G['clientip'], 'lastvisit'=>TIMESTAMP, 'lastactivity' => TIMESTAMP));
        $ucsynlogin = '';
        if($_G['setting']['allowsynlogin']) {
            loaducenter();
            $ucsynlogin = uc_user_synlogin($uid);
        }
    }

    //ͳ��
    include_once libfile('function/stat');
    updatestat('register');
    xg_syncAvatar($uid, $avatar);

    if(!function_exists('build_cache_userstats')) {
        require_once libfile('cache/userstats', 'function');
    }
    build_cache_userstats();

    return $uid;
}

function login_access($openid, $code, $userinfo, $config)
{
    global $_G;
    $authkey = $_G['config']['security']['authkey'];
    $succeed = 0;

    $authcode = C::t('#wechat#mobile_wechat_authcode')->fetch_by_code($code);
    $fetch = C::t('#wechat#common_member_wechat')->fetch_by_openid($openid);


    $arr = array(
        'reg_nickname'   => authcode($userinfo['nickname'], 'ENCODE', $authkey),
        'reg_headimgurl' => authcode($userinfo['headimgurl'], 'ENCODE', $authkey),
        'reg_sid'        => authcode($authcode['sid'], 'ENCODE', $authkey),
        'openid'         => authcode($openid, 'ENCODE', $authkey),
    );

    if($fetch['uid']){
        $member_tmp = getuserbyuid($fetch['uid']);
        if(!$member_tmp){
            $fetch = array();
            C::t('#wechat#common_member_wechat')->delete($fetch['uid']);
        }
    }

    if(($uid = $fetch['uid'])){
        if(!$authcode['uid']){
            C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
            $succeed = 1;
        }else if($authcode['uid'] != $fetch['uid']){
        }else{
            C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
            $succeed = 1;
        }
    }else{
        if($authcode['uid']) {
            $uid = $authcode['uid'];
            $member = getuserbyuid($uid, 1);
            if($member){
                WeChatHook::bindOpenId($uid, $openid, 0);
                C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
                $succeed = 1;
            }
        } else {
            if($config['wxmiao'] && !($config['smsAppKey'] && $config['smssecretKey'] && $config['smsFreeSignName'] && $config['smsTemplateCode'])){
                include_once DISCUZ_ROOT.'source/plugin/xigua_login/function.php';
                $uid = xg_register($userinfo['nickname'], $userinfo['headimgurl'], 1, 0);

                if($uid <=0){
                    $jumpurl = 'plugin.php?id=xigua_login:reg&has=1&'.http_build_query($arr);
                }else{
                    WeChatHook::bindOpenId($uid, $openid, 1);
                    C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
                    $succeed = 1;
                }
            }else{
                $jumpurl = 'plugin.php?id=xigua_login:reg&'.http_build_query($arr);
            }
        }
    }
    if($succeed) {
        $member = getuserbyuid($uid, 0);
        $succeemsg = str_replace('{siteurl}', $_G['siteurl'], lang('plugin/xigua_login', 'login_success'));
        $msg = $member['username'].lang('plugin/xigua_login', 'nihao').$succeemsg;
        if($GLOBALS['custom_url']){
            $arr['custom_url'] = $GLOBALS['custom_url'];
            $msg = $member['username'].lang('plugin/xigua_login', 'nihao');
        }
        $syncurl = $_G['siteurl'].'plugin.php?id=xigua_login:dingyue&'.http_build_query($arr);
        $extmsg = lang('plugin/xigua_login', 'login_now');
//        $msg = "<a href=\"$syncurl\">$msg $extmsg</a>";
//        echo WeChatServer::getXml4Txt($msg);

        $list = array();
        $list[0] = array(
            'title' => $msg,
            'desc'  => $extmsg,
            'pic'   => $_G['siteurl'].'source/plugin/xigua_login/static/XIGUA.jpg',
            'url'   => $syncurl,
        );
        echo WeChatServer::getXml4RichMsgByArray($list);
    }elseif ($jumpurl){
        $jumpurl = $_G['siteurl'].$jumpurl;
        $msg = lang('plugin/xigua_login', 'login_jump');
        if($uid == -9999 || $uid == -3){
            $msg = lang('plugin/xigua_login', 'profile_username_duplicate');
        }elseif($uid == -1){
            $msg = lang('plugin/xigua_login', 'profile_username_illegal');
        }elseif($uid == -2){
            $msg = lang('plugin/xigua_login', 'profile_username_protect');
        }
        echo WeChatServer::getXml4Txt("<a href='$jumpurl'>".$msg.($uid ? " ($uid)" : '')."</a>");

        $list = array();
        $list[0] = array(
            'title' => $msg,
            'desc'  => $msg,
            'pic'   => $_G['siteurl'].'source/plugin/xigua_login/static/XIGUA.jpg',
            'url'   => $jumpurl,
        );
        echo WeChatServer::getXml4RichMsgByArray($list);
    }else{
        echo WeChatServer::getXml4Txt(lang('plugin/xigua_login', 'login_failed'));
    }
}
function match421($match) {
    return strlen($match[0]) >= 4 ? '' : $match[0];
}