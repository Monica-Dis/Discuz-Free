<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2016/7/18
 * Time: 10:43
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once  DISCUZ_ROOT.'source/plugin/xigua_login/function.php';

class LoginResponse
{
    public static function post($url, $data) {
        if (!function_exists('curl_init')) {
            return false;
        }
        $header[]= "Content-type: text/xml";
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$header);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        $data = curl_exec($ch);

        if (!$data) {
            error_log(curl_error($ch));
        }
        curl_close($ch);
        return $data;
    }

    public function receiveAllEnd()
    {
        $postdata = file_get_contents("php://input");

        global $_G;
        if (empty($_G['cache']['plugin'])) {
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_login'];
        unset($_REQUEST['id']);
        unset($_REQUEST['module']);
        if($config['wechaturl'] && strpos($config['wechaturl'], 'id=552')===false){
            $wechat_api= $config['wechaturl'].(strpos($config['wechaturl'], '?')===false?'?':'&').http_build_query($_REQUEST);
            $ret = self::post($wechat_api, $postdata);
            echo $ret;
        }
    }

    public static function do_processs($openid, $code)
    {
        global $_G;
        if (empty($_G['cache']['plugin'])) {
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_login'];
        if(!class_exists('WeChatClient')) {
            include_once DISCUZ_ROOT . 'source/plugin/wechat/wechat.lib.class.php';
        }
        include_once libfile('function/cache');
        $wechat_client = new WeChatClient($config['appid'], $config['appsecert']);
        $userinfo = $wechat_client->getUserInfoById($openid);
        $userinfo['nickname'] = self::filterEmoji12($userinfo['nickname']);
        foreach ($userinfo as $index => $item) {
            $userinfo[$index] = diconv($userinfo[$index], 'utf-8');
        }
        if($userinfo){
            if (is_numeric($code)&& $code>=110000 && $code <=999999){
                login_access($openid, $code, $userinfo, $config);
            }
        }
    }

    public static function subscribe($param)
    {
        list($data) = $param;
        $openid = $data['from'];
        if($openid){

            $content = array();
            global $_G;
            $hb_config = $_G['cache']['plugin']['xigua_hb'];
            $SCRITPTNAME = $hb_config['scriptname'] ? $hb_config['scriptname'] : 'plugin.php';
            $dftlogo = $_G['cache']['plugin']['xigua_f']['defaultlogo'];
            if(strpos($dftlogo, 'https://')===false && strpos($dftlogo, 'http://')===false){
                $dftlogo = $_G['siteurl'].$dftlogo;
            }
            list($datakey, $hhid) = explode('____', $data['key']);
            $data['key'] = $datakey;
            if($hhid){
                $hhid = '&idu='.intval($hhid);
            }else{
                $hhid = '';
            }

            if(strpos($data['key'], 'pub_')!==false) {
                $pubid = str_replace('pub_', '', $data['key']);
                if (is_numeric($pubid)) {
                    if (empty($_G['cache']['plugin'])) {
                        loadcache('plugin');
                    }
                    if (!class_exists('WeChatClient')) {
                        include_once DISCUZ_ROOT . 'source/plugin/wechat/wechat.lib.class.php';
                    }
                    include_once libfile('function/cache');


                    $hbdata = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid, 0);
                    if(!$hbdata['imglist'][0]){
                        $catinfo = C::t('#xigua_hb#xigua_hb_cat')->fetch($hbdata['catid']);
                        $hbdata['imglist'][0] = $catinfo['share_pic'];
                    }

                    if ($hbdata) {
                        $hbdata['title'] = cutstr(strip_tags($hbdata['description']), 60);
                        $hbdata['desc'] = cutstr(strip_tags($hbdata['description']), 100);

                        $desc= cutstr(strip_tags($hbdata['desc']), 100);
                        $content[] = array(
                            "title" => $hbdata['title'],
                            "desc" => $desc,
                            "pic" => ($hbdata['imglist'][0] ? $hbdata['imglist'][0] : $dftlogo),
                            "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=view&pubid=$pubid$hhid",
                        );
                        echo WeChatServer::getXml4RichMsgByArray($content);
                    }
                }
            }elseif(strpos($data['key'], 'hd_')!==false){
                $did_jid = str_replace('hd_', '', $data['key']);
                list($did, $jid) = explode('__', $did_jid);
                $hd_config = $_G['cache']['plugin']['xigua_hd'];

                $v = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_id($did);
                $navtitle = $v['title'];
                $desc = $v['jieshao'] ? $v['jieshao'] : $v['append_text_ary'][0];

                if($jid){
                    $jv = C::t('#xigua_hd#xigua_hd_join')->fetch_by_jid($jid);

                    $curuser = getuserbyuid($jv['uid']);
                    $search = array(
                        '{title}',
                        '{user}',
                        '{price}',
                        '{current}',
                        '{times}',
                        '{floor}',
                        '{range}',
                    );
                    $replace = array(
                        $v['title'],
                        $curuser['username'],
                        $v['biaoprice'],
                        $jv['current'],
                        ($v['zong'] ? ($v['zong']-$jv['jians']) : $jv['jians']),
                        $v['disprice'],
                        $v['biaoprice']-$jv['current'],
                    );
                    $navtitle = str_replace($search, $replace, $hd_config['fxt']);
                    $desc = str_replace($search, $replace, $hd_config['fxd']);
                }

                $img = $v['album'][0] ?$v['album'][0]: $dftlogo;



                $desc= cutstr(strip_tags($desc), 100);
                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hd&ac=view&did=$did&jid=$jid$hhid",
                );
//                file_put_contents(DISCUZ_ROOT.'/1.log', var_export($content, 1), FILE_APPEND);
                echo WeChatServer::getXml4RichMsgByArray($content);



            }elseif(strpos($data['key'], 'hm_')!==false){
                $secid = str_replace('hm_', '', $data['key']);

                $v = C::t('#xigua_hm#xigua_hm_seckill')->fetch_by_id($secid);
                $navtitle = $v['title'];
                $desc= $v['tuijian'] ? $v['tuijian'] : $v['jieshao'];
                $img = $v['album'][0]?$v['album'][0]:$v['append_img_ary'][0];
                if(!$img){
                    $img = $dftlogo;
                }

                $desc= cutstr(strip_tags($desc), 100);
                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid=$secid$hhid",
                );
//                file_put_contents(DISCUZ_ROOT.'/1.log', var_export($content, 1), FILE_APPEND);
                echo WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($data['key'], 'sh_')!==false){
                $shid = str_replace('sh_', '', $data['key']);

                $v = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
                $gonggao = C::t('#xigua_hs#xigua_hs_notice')->fetch_allnotice_by_shid($shid, 2);

                $desc = cutstr(strip_tags($v['xuanchuan'] ? $v['xuanchuan'] :($gonggao[0] ? $gonggao[0]['content'] : $v['jieshao'])),80);
                $navtitle = $v['name'];
                $img = $v['logo'];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hs&ac=view&shid=$shid$hhid",
                );
//                file_put_contents(DISCUZ_ROOT.'/1.log', var_export($content, 1), FILE_APPEND);
                echo WeChatServer::getXml4RichMsgByArray($content);
            }elseif(strpos($data['key'], 'pt_')!==false){
                $pt_tuan_id = str_replace('pt_', '', $data['key']);

                list($gid, $tuan_id) = explode('__', $pt_tuan_id);
                $pt_config = $_G['cache']['plugin']['xigua_pt'];

                $v = C::t('#xigua_pt#xigua_pt_good')->fetch_by_gid($gid);
                if (!$v['album']){
                    $v['album'] = $v['append_img_ary'];
                }
                $navtitle= $v['title'];
                $desc= cutstr(strip_tags($v['jieshao']), 100);
                $img = $v['album'][0] ?$v['album'][0] : $dftlogo;

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_pt&ac=view&gid=$gid&tuan_id=$tuan_id$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($data['key'], 'sp_')!==false){
                $gid = str_replace('sp_', '', $data['key']);
                $sp_config = $_G['cache']['plugin']['xigua_sp'];

                $v = C::t('#xigua_sp#xigua_sp_good')->fetch_by_gid($gid);
                if (!$v['album']){
                    $v['album'] = $v['append_img_ary'];
                }
                $navtitle= $v['title'];
                $desc= cutstr(strip_tags($v['jieshao']), 100);
                $img = $v['album'][0] ?$v['album'][0] : $dftlogo;

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_sp&ac=view&gid=$gid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($data['key'], 'hh_')!==false){
                $idu = str_replace('hh_', '', $data['key']);
                $hh_config = $_G['cache']['plugin']['xigua_hh'];

                $memeber = getuserbyuid($idu);

                $navtitle= $memeber['username'].lang('plugin/xigua_hh', 'xntuij').$hb_config['tname'];
                $desc= $hb_config['desc'];
                $img =$dftlogo;// avatar($idu, 'middle', true);

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=index&idu=$idu$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($data['key'], 'mp_')!==false){
                $mpid = str_replace('mp_', '', $data['key']);
                $hp_config = $_G['cache']['plugin']['xigua_hp'];
                $v = C::t('#xigua_hp#xigua_hp_user')->fetch($mpid);
                $myname = $v['name'];

                $navtitle = str_replace(array(
                    '{name}', '{mobile}','{company}','{addr}','{wx}','{zw}','{wfz}','{bm}','{shname}'), array(
                    $myname, $v['mobile'], $v['company'], $v['addr'], $v['wx'], $v['zw'], $v['wfz'], $v['bm'], $v['shname']), $hp_config['viewtitle']
                );
                $desc = str_replace(array(
                    '{name}', '{mobile}','{company}','{addr}','{wx}','{zw}','{wfz}','{bm}','{shname}'), array(
                    $myname, $v['mobile'], $v['company'], $v['addr'], $v['wx'], $v['zw'], $v['wfz'], $v['bm'], $v['shname']), $hp_config['viewdesc']
                );
                $indeximg = $v['avatar'] ? $v['avatar'] : $hp_config['viewimg'];

                $img =$indeximg ? $indeximg : $dftlogo;

                $content[] = array(
                    "title" => $navtitle,
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl']."$SCRITPTNAME?id=xigua_hp&ac=view&mpid=$mpid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($data['key'], 'dh_')!==false){
                $shid = str_replace('dh_', '', $data['key']);

                $v = C::t('#xigua_dh#xigua_dh_shangjia')->fetch_by_shid($shid, 0);

                $desc = cutstr(strip_tags( $v['jieshao']),80);
                $navtitle = $v['name'];
                $img = $v['logo'];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_dh&ac=view&shid=$shid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);
            }elseif(strpos($data['key'], 'dp_')!==false){
                $cid = str_replace('dp_', '', $data['key']);

                $v = C::t('#xigua_dp#xigua_dp_comment')->fetch_by_cid($cid);

                $desc = cutstr(strip_tags(($v['message'])),80);
                $navtitle = $v['subject'];
                $img = $v['album_ary'][0];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_dp&ac=view&cid=$cid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);
            }elseif(strpos($data['key'], 'hk_')!==false){
                $cid = str_replace('hk_', '', $data['key']);
                $v = C::t('#xigua_hk#xigua_hk_good')->fetch_by_good_id($cid);

                $desc = cutstr(strip_tags(($v['jieshao'])),80);
                $navtitle = $v['title'];
                $img = $v['album'][0];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hk&ac=view&gid=$cid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($data['key'], 'job_')!==false){
                $cid = str_replace('job_', '', $data['key']);
                $v = C::t('#xigua_job#xigua_job_job')->fetch_by_id($cid);

                $desc = cutstr(strip_tags(($v['miaoshu'])),80);
                $navtitle = $v['name'];
                $img = $v['album'][0];
                if(!$img){
                    $img = $dftlogo;
                }

                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_job&ac=view&jobid=$cid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($data['key'], 'shifu_')!==false){
                $cid = str_replace('shifu_', '', $data['key']);
                $v = C::t('#xigua_ho#xigua_ho_shifu')->fetch($cid);
                $desc = cutstr($v['jineng_str'].' '.strip_tags(($v['jieshao'])),80);
                $navtitle = $v['realname'];
                $img = $v['avatar'];
                if(!$img){
                    $img = $dftlogo;
                }
                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=shifu&shifuid=$cid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);
            }elseif(strpos($data['key'], 'need_')!==false){
                $cid = str_replace('need_', '', $data['key']);
                $v = $need = C::t('#xigua_ho#xigua_ho_need')->fetch($cid);
                $desc = cutstr(strip_tags($v['description']),80);
                $navtitle = $v['title'];
                $img = avatar($v['uid'], 'middle', true);
                if(!$img){
                    $img = $dftlogo;
                }
                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=view&needid=$cid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);
            }elseif(strpos($data['key'], 'fuwu_')!==false){
                $cid = str_replace('fuwu_', '', $data['key']);
                $v = C::t('#xigua_ho#xigua_ho_fuwu')->fetch($cid);
                $desc = cutstr($v['jineng_str'].' '.strip_tags(($v['jieshao'])),80);

                $shifu = C::t('#xigua_ho#xigua_ho_shifu')->fetch_by_uid($v['uid']);
                $navtitle = $v['title'] .'-'.$shifu['realname'];
                $img = unserialize($v['album']);
                $img = $img[0];
                if(!$img){
                    $img = $dftlogo;
                }
                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_ho&ac=fuwu&fuwuid=$cid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);

            }elseif(strpos($data['key'], 'qun_')!==false){
                $cid = str_replace('qun_', '', $data['key']);
                $v = C::t('#xigua_hf#xigua_hf_qun')->fetch($cid);
                $desc = cutstr(strip_tags($v['jieshao']),80);
                $hf_config = $_G['cache']['plugin']['xigua_hf'];
                $navtitle = str_replace(array('{name}'), array($v['name'],), $hf_config['subject']);
                $img = $v['logo'];
                if(!$img){
                    $img = $dftlogo;
                }
                $content[] = array(
                    "title" => strip_tags($navtitle),
                    "desc" => $desc,
                    "pic" => $img,
                    "url" => $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hf&ac=view&qunid=$cid$hhid",
                );
                echo WeChatServer::getXml4RichMsgByArray($content);

            }else{
                self::do_processs($openid, $data['key']);
            }
        }
    }

    public static function scan($param)
    {
        self::subscribe($param);
    }

    public function text($param)
    {
        list($data) = $param;
        $content = diconv($data['content'], 'UTF-8');
        if($content==lang('plugin/xigua_login', 'login')){
            $content = '999999';
        }
        $openid = $data['from'];
        if($openid){
            self::do_processs($openid, $content);
        }
    }

    public function click($param)
    {
        list($data) = $param;
        $content = $data['key'];
        if(strtolower($content)=='xigua_login'){
            $content = '999998';
        }else if(substr($content, 0, 12)=='xigua_login|'){
            $GLOBALS['custom_url'] = substr($content, 12);
            if(strpos($GLOBALS['custom_url'] , 'http://')==false ||strpos($GLOBALS['custom_url'] , 'https://')==false){
                $GLOBALS['custom_url'] = '//'.$GLOBALS['custom_url'];
            }
            $content = '999998';
        }
        $openid = $data['from'];
        if($openid){
            self::do_processs($openid, $content);
        }
    }

    public static function filterEmoji12($str){
        $str = preg_replace_callback( '/./u', 'match421', $str);

        $str = diconv($str, 'utf-8', 'gbk');
        $str = diconv($str, 'gbk', 'utf-8');

        $str = self::safe_replace($str, 1);
        $str = str_replace(array(" ", "\t", "\n", "\r"), '',$str);
        return $str;
    }
    public static function safe_replace($string, $empty = 0) {
        $string = str_replace('%20','',$string);
        $string = str_replace('%27','',$string);
        $string = str_replace('%2527','',$string);
        $string = str_replace('*','',$string);
        $string = str_replace('"', ($empty ?'': '&quot;'),$string);
        $string = str_replace("'",'',$string);
        $string = str_replace('"','',$string);
        $string = str_replace(';','',$string);
        $string = str_replace('<',($empty ?'': '&lt;'),$string);
        $string = str_replace('>',($empty ?'': '&gt;'),$string);
        $string = str_replace("{",'',$string);
        $string = str_replace('}','',$string);
        $string = str_replace('\\','',$string);
        return $string;
    }
}