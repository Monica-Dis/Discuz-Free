<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/3/10
 * Time: 21:35
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/*if($_GET['miao']){
    dheader('Location: member.php?mod=logging&action=login');
}*/

//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
function match412($match)
{
    return strlen($match[0]) >= 4 ? '' : $match[0];
}

function filterEmoji12($str)
{
    $str = preg_replace_callback('/./u', 'match412', $str);

    $str = diconv($str, 'utf-8', 'gbk');
    $str = diconv($str, 'gbk', 'utf-8');

    $str = safe_replace($str, 1);
    return $str;
}

function current_url()
{
    $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
    $php_self = $_SERVER['PHP_SELF'] ? safe_replace($_SERVER['PHP_SELF']) : safe_replace($_SERVER['SCRIPT_NAME']);
    $path_info = isset($_SERVER['PATH_INFO']) ? safe_replace($_SERVER['PATH_INFO']) : '';
    $relate_url = isset($_SERVER['REQUEST_URI']) ? safe_replace($_SERVER['REQUEST_URI']) : $php_self . (isset($_SERVER['QUERY_STRING']) ? '?' . safe_replace($_SERVER['QUERY_STRING']) : $path_info);
    return $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '') . $relate_url;
}

function safe_replace($string, $empty = 0)
{
    $string = str_replace('%20', '', $string);
    $string = str_replace('%27', '', $string);
    $string = str_replace('%2527', '', $string);
    $string = str_replace('*', '', $string);
    $string = str_replace('"', ($empty ? '' : '&quot;'), $string);
    $string = str_replace("'", '', $string);
    $string = str_replace('"', '', $string);
    $string = str_replace(';', '', $string);
    $string = str_replace('<', ($empty ? '' : '&lt;'), $string);
    $string = str_replace('>', ($empty ? '' : '&gt;'), $string);
    $string = str_replace("{", '', $string);
    $string = str_replace('}', '', $string);
    $string = str_replace('\\', '', $string);
    $string = str_replace('\0', '', $string);
    $string = str_replace("\0", '', $string);
    return $string;
}

function xgetUserInfoByopenId($wechat_client, $openid)
{
    $info = $wechat_client->getUserInfoById($openid);

    if (!$info || $info['errcode']) {
        $appid = WX_APPID;
        $appsecret = WX_APPSECRET;

        $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$appid&secret=$appsecret";
        $json = dfsockopen($url);
        if (!$json) {
            $json = file_get_contents($url);
        }
        $access_data = json_decode($json, true);
        $access_token = $access_data['access_token'];

        if ($access_token) {
            savecache('wechatat_' . $appid, array(
                'token' => $access_token,
                'expiration' => time() + 6200,
            ));
        }

        $url = "https://api.weixin.qq.com/cgi-bin/user/info?access_token=$access_token&openid=$openid&lang=en";
        $json = dfsockopen($url);
        if (!$json) {
            $json = file_get_contents($url);
        }
        $info = json_decode($json, true);
        if (!$info || $info['errcode']) {
            return array();
        }
    }
    return $info;
}


if (!$_G['cache']['plugin']) {
    loadcache('plugin');
}
$config = $_G['cache']['plugin']['xigua_login'];
if ($config['debug']) {
    ini_set('display_errors', 1);
    error_reporting(E_ALL ^ E_NOTICE);
}

include_once libfile('function/cache');
include_once libfile('function/member');
@include_once DISCUZ_ROOT . './source/plugin/mobile/qrcode.class.php';
include_once DISCUZ_ROOT . 'source/plugin/wechat/wechat.lib.class.php';


$authkey = $_G['config']['security']['authkey'];
define('WX_APPID', trim($config['appid']));
define('WX_APPSECRET', trim($config['appsecert']));
define('IN_WECHAT', strpos($_SERVER['HTTP_USER_AGENT'], 'MicroMessenger') !== false);

$cookie = substr(md5('wechatdd' . $_G['siteurl'] . WX_APPID), 0, 8);
$openid = !empty($_G['cookie'][$cookie]) ? authcode($_G['cookie'][$cookie], 'DECODE', $authkey) : '';
$wechat_client = new WeChatClient(WX_APPID, WX_APPSECRET);
if(!$_GET['backreferer'] && $_GET['referer']){
    $_GET['backreferer'] = $_GET['referer'];
}
if (strpos($_GET['backreferer'], 'logout') !== false) {
    $_GET['backreferer'] = $_G['siteurl'];
}
if (!$_GET['backreferer']) {
    $_GET['backreferer'] = dreferer();
}

if (isset($_GET['synclogin'])) {
    require_once libfile('function/member');
    $member = getuserbyuid($_G['uid'], 1);
    C::t('common_member_status')->update($_G['uid'], array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));
    $ucsynlogin = '';
    if ($_G['setting']['allowsynlogin']) {
        loaducenter();
        $ucsynlogin = uc_user_synlogin($_G['uid']);
        loadcache('usergroup_' . $member['groupid']);
        $_G['group'] = $_G['cache']['usergroup_' . $member['groupid']];
        $_G['group']['grouptitle'] = $_G['cache']['usergroup_' . $_G['groupid']]['grouptitle'];
        $param = array('username' => $member['username'], 'usergroup' => $_G['group']['grouptitle']);
        showmessage('login_succeed', $_GET['backreferer'], $param, array('extrajs' => $ucsynlogin));
    }
}

if (isset($_GET['check'])) {
    $code = authcode(base64_decode($_GET['check']), 'DECODE', $authkey);
    if ($code) {
        $authcode = C::t('#wechat#mobile_wechat_authcode')->fetch_by_code($code);
        if ($authcode['status']) {
            require_once libfile('function/member');
            $member = getuserbyuid($authcode['uid'], 1);
            setloginstatus($member, 1296000);

            C::t('common_member_status')->update($authcode['uid'], array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));

            dsetcookie('wechat_ticket', '', -1);
            $echostr = 'done';
        } else {
            $echostr = '1';//json_encode($authcode);
        }
    } else {
        $echostr = '-1';
    }

    if (!ob_start($_G['gzipcompress'] ? 'ob_gzhandler' : null)) {
        ob_start();
    }

    if ($echostr === 'done') {
        C::t('#wechat#mobile_wechat_authcode')->delete($authcode['sid']);
    }

    include template('common/header_ajax');
    echo $echostr;
    include template('common/footer_ajax');
    exit;
}

if (IN_WECHAT && !$_GET['qr']) {

    if ($config['qrcode']) {
        $qrcodeurl2 = $config['qrcode'];
        $qrcodeurl = $config['qrcode'];
        $tiptip2 = lang('plugin/xigua_login', 'in_wechat_reply_login');
        dsetcookie('page_front', $_GET['backreferer'], 86400);
        include_once template('xigua_login:wechat_qrcode');
        exit;
    }

    if ($config['rhref'] = trim($config['rhref'])) {
        $jieurl = (strpos($config['rhref'], 'http://') === false && strpos($config['rhref'], 'https://') === false) ? "http://" . $config['rhref'] : $config['rhref'];
        if (strpos($jieurl, '.html') === false) {
            $jieurl = rtrim($jieurl, '/') . '/source/plugin/xigua_login/r.html';
        }

        /*info*/
        $basert = urlencode($_G['siteurl'] . 'plugin.php?id=xigua_login:login&c=' . urlencode($_GET['c']) . '&oauth=yes&backreferer=' . urlencode($_GET['backreferer']));
        $redirect_uri = "$jieurl?appid={$config['appid']}&redirect_uri={$basert}&response_type=code&scope=snsapi_userinfo&state=#wechat_redirect";

        /*base*/
        $basert = urlencode($_G['siteurl'] . 'plugin.php?id=xigua_login:login&c=' . urlencode($_GET['c']) . '&oauthbase=yes&backreferer=' . urlencode($_GET['backreferer']));
        $redirect_base = "$jieurl?appid={$config['appid']}&redirect_uri={$basert}&response_type=code&scope=snsapi_base&state=#wechat_redirect";

    } else {
        $redirect_uri = $wechat_client->getOAuthConnectUri($_G['siteurl'] . 'plugin.php?id=xigua_login:login&c=' . urlencode($_GET['c']) . '&oauth=yes&backreferer=' . urlencode($_GET['backreferer']), '', 'snsapi_userinfo');
        $redirect_base = $wechat_client->getOAuthConnectUri($_G['siteurl'] . 'plugin.php?id=xigua_login:login&c=' . urlencode($_GET['c']) . '&oauthbase=yes&backreferer=' . urlencode($_GET['backreferer']), '', 'snsapi_base');
    }

    if (!$openid) {
        if (empty($_GET['oauthbase'])) {
            dheader('location: ' . $redirect_base);
        } else {
            $tockeninfo = $wechat_client->getAccessTokenByCode($_GET['code']);

            $openid = $tockeninfo['openid'];
            if (!$openid) {
//                dheader('Location: plugin.php?id=xigua_login:login&backreferer='.urlencode($_GET['backreferer']));

                var_dump($tockeninfo);
                exit;
            }
            dsetcookie($cookie, authcode($openid, 'ENCODE', $authkey), 7100);
        }
    }

    $authcode = C::t('#wechat#mobile_wechat_authcode')->fetch_by_code(authcode(base64_decode($_GET['c']), 'DECODE', $authkey));
//    print_r($authcode);
//    print_r($_GET['c']);

    $succeed = 0;
    if (!$openid) {
        var_dump('openid is empty!');
        exit;
    }
    $fetch = C::t('#wechat#common_member_wechat')->fetch_by_openid($openid); //����Ƿ��

    //��Ȼ�а���Ϣ�����û��Ѿ������ڵ���� ��ʼ
    if ($fetch['uid']) {
        $member_tmp = getuserbyuid($fetch['uid']);
        if (!$member_tmp) {
            $fetch = array();
            C::t('#wechat#common_member_wechat')->delete($fetch['uid']);
        }
    }
    //��Ȼ�а���Ϣ�����û��Ѿ������ڵ���� ����

    if (($uid = $fetch['uid'])) { //����
        if (!$authcode['uid']) { //δ��¼״̬
            C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
            $succeed = 1;
        } else if ($authcode['uid'] != $fetch['uid']) { //��ǰ΢�Ű󶨵Ĳ����Լ���
            showmessage(lang('plugin/xigua_login', 'tiptip3'));
        } else { //��¼�� �� �󶨵����Լ��ĺ� �ǻ�ɨʲô��
            C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
            $succeed = 1;
        }
    } else {  //δ��
        if ($authcode['uid'] || ($_G['uid'] && $_GET['bindfast'])) {  //bind
            $uid = $_GET['bindfast'] ? $_G['uid'] : $authcode['uid'];
            $member = getuserbyuid($uid, 1);
            if ($member) {
                if ($_GET['bindfast']) {
                    $url = $_GET['backreferer'] ? $_GET['backreferer'] : $_G['siteurl'] . "home.php?mod=space&uid=$uid&do=profile&mycenter=1&mobile=2";
                    if ($config['weret']) {
                        $url = $config['weret'];
                    }
                    dsetcookie('backreferer', $url, 7100);
                    dheader('Location: plugin.php?id=xigua_login:reg&rb=1&lock=1');
                    exit;
                }
                /*WeChatHook::bindOpenId($uid, $openid, 0);*/
                $userinfo = $wechat_client->getUserInfoByAuth(authcode($_G['cookie']['accessn'], 'DECODE', $authkey), $openid);
                $unionid = $userinfo['unionid'];
                C::t('#wechat#common_member_wechat')->insert(array('uid' => $uid, 'status' => 2, 'openid' => $openid,'unionid' => $unionid, 'isregister' => 0), false, true);
                C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
                $succeed = 1;
            }
        } else {  // reg and bind

            if (empty($_GET['oauth'])) {
                $userinfo = xgetUserInfoByopenId($wechat_client, $openid);
            }

            if (!$userinfo['nickname']) {
                if (empty($_GET['oauth'])) {
                    dheader('location: ' . $redirect_uri);
                } else {
                    $tockeninfo = $wechat_client->getAccessTokenByCode($_GET['code']);
                    $access_token = $tockeninfo['access_token'];
                    $openid = $tockeninfo['openid'];
                    if (!$openid) {
//                        dheader('Location: plugin.php?id=xigua_login:login&backreferer='.urlencode($_GET['backreferer']));
                        var_dump($tockeninfo);
                        exit;
                    }
                    dsetcookie($cookie, authcode($openid, 'ENCODE', $authkey), 7100);
                    dsetcookie('accessn', authcode($access_token, 'ENCODE', $authkey), 7100);
                }
                $userinfo = $wechat_client->getUserInfoByAuth(authcode($_G['cookie']['accessn'], 'DECODE', $authkey), $openid);
                if ($userinfo['errcode']) {
                    dsetcookie($cookie, '', -1);
                    dsetcookie('accessn', '', -1);

                    exit(json_encode($userinfo));
                }
            }
            $userinfo['nickname'] = trim(filterEmoji12($userinfo['nickname']));
            if(!$userinfo['nickname']){
                $userinfo['nickname'] = 'mx_'.mt_rand(10000, 99999);
            }
            foreach ($userinfo as $index => $item) {
                $userinfo[$index] = diconv($userinfo[$index], 'utf-8');
            }

            if ($_G['cache']['plugin']['xigua_login']['wxmiao'] && !($config['smsAppKey'] && $config['smssecretKey'] && $config['smsFreeSignName'] && $config['smsTemplateCode'])) {
                include_once DISCUZ_ROOT . 'source/plugin/xigua_login/function.php';
                $userinfo['nickname'] = str_replace(array(" ", "\t", "\n", "\r"), '', $userinfo['nickname']);
                $uid = xg_register($userinfo['nickname'], $userinfo['headimgurl'], 1);

                if ($uid == '-9999' || $uid == -1 || $uid == -2 || $uid == -3 || $uid <=0) {  //rename hack
                    dsetcookie('reg_nickname', authcode($userinfo['nickname'], 'ENCODE', $authkey), 7100);
                    dsetcookie('reg_headimgurl', authcode($userinfo['headimgurl'], 'ENCODE', $authkey), 7100);
                    dsetcookie('reg_sid', authcode($authcode['sid'], 'ENCODE', $authkey), 7100);
                    $url = $_GET['backreferer'] ? $_GET['backreferer'] : $_G['siteurl'] . "home.php?mod=space&uid=$uid&do=profile&mycenter=1&mobile=2";
                    if ($config['weret']) {
                        $url = $config['weret'];
                    }
                    dsetcookie('backreferer', $url, 7100);
                    dheader('Location: plugin.php?id=xigua_login:reg&has=1');
                    exit;
                }
                if ($uid>0) {
//                    WeChatHook::bindOpenId($uid, $openid, 1);
                    $unionid = $userinfo['unionid'];
                    C::t('#wechat#common_member_wechat')->insert(array('uid' => $uid, 'status' => 2, 'openid' => $openid,'unionid' => $unionid, 'isregister' => 0), false, true);
                    C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
                    $succeed = 1;
                }
            } else {
                dsetcookie('reg_nickname', authcode($userinfo['nickname'], 'ENCODE', $authkey), 7100);
                dsetcookie('reg_headimgurl', authcode($userinfo['headimgurl'], 'ENCODE', $authkey), 7100);
                dsetcookie('reg_sid', authcode($authcode['sid'], 'ENCODE', $authkey), 7100);
                $url = $_GET['backreferer'] ? $_GET['backreferer'] : $_G['siteurl'] . "home.php?mod=space&uid=$uid&do=profile&mycenter=1&mobile=2";
                if ($config['weret']) {
                    $url = $config['weret'];
                }
                dsetcookie('backreferer', $url, 7100);
                dheader('Location: plugin.php?id=xigua_login:reg');
            }
        }
    }
    if ($succeed) {
        C::t('#wechat#mobile_wechat_authcode')->update($authcode['sid'], array('uid' => $uid, 'status' => 1));
        require_once libfile('function/member');
        $member = getuserbyuid($uid, 1);
        setloginstatus($member, 1296000);

        $url = $_GET['backreferer'] ? $_GET['backreferer'] : $_G['siteurl'] . "home.php?mod=space&uid=$uid&do=profile&mycenter=1&mobile=2";
        if ($config['weret']) {
            $url = $config['weret'];
        }

        C::t('common_member_status')->update($uid, array('lastip' => $_G['clientip'], 'lastvisit' => TIMESTAMP, 'lastactivity' => TIMESTAMP));
        $ucsynlogin = '';
        if ($_G['setting']['allowsynlogin']) {
            loaducenter();
            $ucsynlogin = uc_user_synlogin($uid);
            loadcache('usergroup_' . $member['groupid']);
            $_G['group'] = $_G['cache']['usergroup_' . $member['groupid']];
            $_G['group']['grouptitle'] = $_G['cache']['usergroup_' . $_G['groupid']]['grouptitle'];
            $param = array('username' => $member['username'], 'usergroup' => $_G['group']['grouptitle']);
            showmessage('login_succeed', $url, $param, array('extrajs' => $ucsynlogin));
        }

        if ($_GET['bindfast']) {
            showmessage(lang('plugin/xigua_login', 'bind_success'), $url);
        }

    } else {
        showmessage('Login failed! uid:'.$uid);
    }

    if (strpos($url, 'oauthbase=yes') !== false || strpos($url, 'oauth=yes') !== false) {
        $url = $_G['siteurl'];
    }
    if ($config['weret']) {
        $url = $config['weret'];
    }
    dheader("Location: $url");

} else {

    $code = $i = 0;
    do {
        $code = mt_rand(110000, 999999);
        $codeexists = C::t('#wechat#mobile_wechat_authcode')->fetch_by_code($code);
        $i++;
    } while ($codeexists && $i < 10);

    $codeenc = urlencode(base64_encode(authcode($code, 'ENCODE', $authkey)));
    C::t('#wechat#mobile_wechat_authcode')->insert(array('sid' => $code, 'uid' => $_G['uid'], 'code' => $code, 'createtime' => TIMESTAMP), 0, 1);
    if (!discuz_process::islocked('clear_wechat_authcode')) {
        C::t('#wechat#mobile_wechat_authcode')->delete_history();
        discuz_process::unlock('clear_wechat_authcode');
    }

    $repath = './source/plugin/xigua_login/cache/';
    $bindurl = $_G['siteurl'] . 'plugin.php?id=xigua_login:login&c=' . $codeenc;
    $qrfile = $repath . $code . '.png';

    if(!is_file(DISCUZ_ROOT . $qrfile)){
        @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
        if (class_exists('QRcode')) {
            QRcode::png($bindurl, DISCUZ_ROOT . $qrfile, QR_ECLEVEL_L, 5);
        }
    }
    $qrcodeurl = $_G['siteurl'] . $qrfile;

    if ($config['pcsubscribe']) {
        $qrcodeurl2 = $qrcodeurl;
        $qrcodeurl = $_G['siteurl'] . 'plugin.php?id=xigua_login:qrcode&ode=' . $code;
    }
//    $qrcodeurl2 = 'http://qrcode.js.cn/js.html?qw=220&qc='.urlencode($bindurl).'&ql=undefined&lw=NaN&lh=NaN&bor=undefined&op=img';

    $tiptip = lang('plugin/xigua_login', 'tiptip2');
    $tiptip2 = lang('plugin/xigua_login', 'please_scan');

    if ($config['qrcode']) {
        $qrcodeurl2 = $config['qrcode'];
        $qrcodeurl = $config['qrcode'];
        $tiptip2 = str_replace('{code}', $code, lang('plugin/xigua_login', 'reply_login'));
    }
    include_once template('xigua_login:wechat_qrcode');
}