<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/7/16
 * Time: 21:40
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$pluginid = 'xigua_login';

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS pre_common_member_wechat (
  `uid` mediumint(8) unsigned NOT NULL,
  `openid` char(32) NOT NULL default '',
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `isregister` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY (`uid`),
  UNIQUE KEY `openid` (`openid`)
) ENGINE=MYISAM;

CREATE TABLE IF NOT EXISTS pre_mobile_wechat_authcode (
  `sid` char(6) NOT NULL,
  `code` int(10) unsigned NOT NULL,
  `uid` mediumint(8) unsigned NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `createtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`sid`),
  UNIQUE KEY `code` (`code`),
  KEY `createtime` (`createtime`)
) ENGINE=MEMORY;

CREATE TABLE IF NOT EXISTS pre_common_member_wechatmp (
  `uid` mediumint(8) unsigned NOT NULL,
  `openid` char(32) NOT NULL default '',
  `status` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `openid` (`openid`)
) ENGINE=MYISAM;

CREATE TABLE IF NOT EXISTS pre_mobile_wsq_threadlist (
  `skey` int(10) unsigned NOT NULL,
  `svalue` text NOT NULL,
  PRIMARY KEY (`skey`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS pre_mobile_wechat_resource (
  `id` int(10) unsigned NOT NULL auto_increment,
  `name` varchar(255) NOT NULL default '',
  `dateline` int(10) unsigned NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `data` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `type` (`type`)
) ENGINE=MYISAM;

CREATE TABLE IF NOT EXISTS pre_mobile_wechat_masssend (
    `id` int(10) unsigned NOT NULL auto_increment,
    `type` char(5) NOT NULL,
    `name` varchar(255) NOT NULL,
    `resource_id` int(10) unsigned NOT NULL,
    `group_id` int(10) unsigned NOT NULL,
    `text` text,
    `media_id`  char(64) DEFAULT '',
    `created_at` int(10) unsigned NOT NULL,
    `sent_at` int(10) unsigned,
    `msg_id` int(10) unsigned,
    `res_status` varchar(50),
    `res_totalcount` int(10),
    `res_filtercount` int(10),
    `res_sentcount` int(10),
    `res_errorcount` int(10),
    `res_finish_at` int(10),
    PRIMARY KEY (`id`)
) ENGINE=MyISAM;

CREATE TABLE IF NOT EXISTS `pre_xigua_login_unbind_log` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) unsigned NOT NULL,
 `openid` char(32) NOT NULL DEFAULT '',
 `status` tinyint(1) NOT NULL DEFAULT '0',
 `isregister` tinyint(1) unsigned NOT NULL DEFAULT '0',
 `unionid` varchar(80) NOT NULL DEFAULT '',
 `mobile` varchar(20) NOT NULL,
 `crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `openid` (`openid`)
) ENGINE=InnoDB;
SQL;
runquery($sql);

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'mobile\'', array('common_member_wechat'), true);
if(!$r2){
    $sql = <<<SQL
ALTER TABLE `pre_common_member_wechat` ADD `mobile` VARCHAR(20) NOT NULL;
SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'unionid\'', array('common_member_wechat'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_common_member_wechat` ADD `unionid` VARCHAR(80) NOT NULL AFTER `isregister`;
ALTER TABLE `pre_common_member_wechat` ADD INDEX(`unionid`);
SQL;
    runquery($sql);
}


@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/install.php');
$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/discuz_plugin_xigua_login_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_login/install.php');


if(is_file(DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php')){
    include_once DISCUZ_ROOT.'./source/plugin/wechat/wechat.lib.class.php';
    $updatedata = array(
        'receiveEvent::subscribe' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'subscribe'
        ),
        'receiveAllEnd' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'receiveAllEnd'
        ),
        'receiveEvent::scan' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'scan'
        ),
        'receiveMsg::text' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'text'
        ),
        'receiveEvent::click' => array(
            'plugin' => 'xigua_login',
            'include' => 'response.class.php', 'class' => 'LoginResponse', 'method' => 'click'
        ),
    );
    $responsehook = WeChatHook::updateResponse($updatedata, 552);
}