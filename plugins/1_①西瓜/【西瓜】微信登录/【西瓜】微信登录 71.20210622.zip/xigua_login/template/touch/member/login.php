<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <title>{$navtitle}</title>
    <meta name="keywords" content="">
    <meta name="description" content="">
    <link href="source/plugin/xigua_login/static/common.css?t={$pluginversion}" rel="stylesheet"/>
    <link href="source/plugin/xigua_login/static/weui.css?t={$pluginversion}" rel="stylesheet"/>
    <script src="source/plugin/xigua_login/static/jquery.min.js?t={$pluginversion}"></script>
    <style>
        .login_select { display: block; position: relative}
        .login_select .login-btn-inner { display: block; font-size: 14px; font-weight:700; min-width: 0.75em; overflow: hidden; position: relative; text-overflow: ellipsis; white-space: nowrap}
        .login-btn-text { float:left}
        .login_select .icon-arrow { width:30px; height:30px; float:right}
        .dialogbox{background:#fff;border-radius:5px}
        .login_pop {}
        .log_tit { text-align:center; font-size:16px; font-weight:700; line-height:45px}
        .login_pop .login_from { margin-bottom: 10px;margin-top:5px}
        .login_pop .login_check { margin:0 0 10px 0; color:#A5A5A5}
        .q_reg a { color:#A5A5A5; font-size:14px}
        .s_code { color:#A5A5A5}
        .s_code .px { color:#A5A5A5}
        .s_code .px:focus { color:#999}
        a.other_c { color:#A5A5A5; margin-left:5px}
        .tip { width:270px; background:#fff; margin:0 auto; -moz-border-radius:5px; border-radius:5px; border-radius:5px;text-align:center;overflow: hidden;padding:15px}
        .tip dt { max-height:175px; font-size:15px;display: block;overflow:hidden}
        .tip dt+dd{margin-top:12px}
        .tip dd {  }
        .tip dd a { margin-left:15px}
        .tip a.weui-btn_mini, .tip .button2, .tip .button{vertical-align:middle;height:31px}
        .tip .tipbtn{margin-top:12px}
        .weui-btn_primary{background-color:$config[logincolor]}
        .button {color: #FFF;background: #de3031 no-repeat}
        .button2,.button {position: relative;margin-left: auto;margin-right: auto;box-sizing: border-box;text-align: center;text-decoration: none;color: #FFFFFF;border-radius: 5px;-webkit-tap-highlight-color: rgba(0, 0, 0, 0);overflow: hidden;background-color:#89CB2B;display: inline-block;padding: 0 1.32em;line-height: 2.3;font-size: 13px;border:0 }
        .fastpost{padding-bottom:10px}
        .fastpost .input{width:100%;height:34px;text-indent:7px;margin-top:2px;border:1px solid #D9D8D8}
        .fastxiangji{line-height:26px}
        .fastpost_title{width:100%;height:42px;line-height:42px;text-align:center;font-size:18px;overflow:hidden;background:#fafafa;position:relative}
        .fastpost_title a{padding:0 12px}
        .fastpost_title a.fastpost_btn{color:#1AAD19}
        .hot_search,.search{margin:15px;position:relative}
        .hot_search{margin:0}
        .search .input{width:100%;height:36px;text-indent:7px;border:0;border-radius:5px 0 0 5px;text-align:center;color:#9B9B9B;background:#FFF;border-right:0}
        .search .button2{height:36px;border-radius:0 4px 4px 0;border:0}

        .tip { width:270px; background:#fff; margin:0 auto; -moz-border-radius:5px; border-radius:5px; border-radius:5px;text-align:center;overflow: hidden;padding:15px}
        .tip dt { max-height:175px; font-size:15px;display: block;overflow:hidden}
        .tip dt+dd{margin-top:12px}
        .tip dd {  }
        .tip dd a { margin-left:15px}
        .tip a.weui-btn_mini, .tip .button2, .tip .button{vertical-align:middle;height:31px}
        {$customstyle}</style>
    </head>
<body>
<!-- userinfo start -->
<div class="container_map container_map_ami">
    <div class="logo">$logo</div>
    <form class="form-control" id="loginform" method="post" action="member.php?mod=logging&action=login&loginsubmit=yes&loginhash=$loginhash&mobile=2" onsubmit="check();{if $_G['setting']['pwdsafety']}pwmd5('password3_$loginhash');{/if}" >
        <input type="hidden" name="formhash" id="formhash" value='{FORMHASH}' />
        <input type="hidden" name="referer" id="referer" value="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->" />
        <input type="hidden" name="fastloginfield" value="username">
        <input type="hidden" name="cookietime" value="2592000">
        <!--{if $auth}-->
        <input type="hidden" name="auth" value="$auth" />
        <!--{/if}-->
        <div class="login_from">
            <ul>
                <li><input type="text" value="" tabindex="1" class="px p_fre" size="30" autocomplete="off" value="" name="username" placeholder="{lang inputyourname}" fwin="login"> </li>
                <li><input type="password" tabindex="2" class="px p_fre" size="30" value="" name="password" placeholder="{lang login_password}" fwin="login"> </li>
                <li class="questionli">
                    <div class="login_select">
                        <select id="questionid_{$loginhash}" name="questionid" class="sel_list">
                            <option value="0" selected="selected">{lang security_question}</option>
                            <option value="1">{lang security_question_1}</option>
                            <option value="2">{lang security_question_2}</option>
                            <option value="3">{lang security_question_3}</option>
                            <option value="4">{lang security_question_4}</option>
                            <option value="5">{lang security_question_5}</option>
                            <option value="6">{lang security_question_6}</option>
                            <option value="7">{lang security_question_7}</option>
                        </select>
                    </div>
                </li>
                <li class="bl_none answerli" style="display:none;"><input type="text" name="answer" id="answer_{$loginhash}" class="px p_fre" size="30" placeholder="{lang security_a}"></li>
            </ul>
            <!--{if $seccodecheck}-->
            {eval
            $sechash = 'S'.random(4);
            $sectpl = !empty($sectpl) ? explode("<sec>", $sectpl) : array('<br />',': ','<br />','');
                $ran = random(5, 1);
                }
                <!--{if $secqaacheck}-->
                <!--{eval
                    $message = '';
                    $question = make_secqaa();
                    $secqaa = lang('core', 'secqaa_tips').$question;
                }-->
                <!--{/if}-->
                <!--{if $sectpl}-->
                <!--{if $secqaacheck}-->
                <p>
                    {lang secqaa}:
                    <span class="xg2">$secqaa</span>
                    <input name="secqaahash" type="hidden" value="$sechash" />
                    <input name="secanswer" id="secqaaverify_$sechash" type="text" class="txt" />
                </p>
                <!--{/if}-->
                <!--{if $seccodecheck}-->
                <div class="sec_code vm">
                    <input name="seccodehash" type="hidden" value="$sechash" />
                    <input type="text" class="txt px vm" autocomplete="off" value="" id="seccodeverify_$sechash" name="seccodeverify" placeholder="{lang seccode}" fwin="seccode">
                    <img src="misc.php?mod=seccode&update={$ran}&idhash={$sechash}&mobile=2" class="seccodeimg"/>
                </div>
                <!--{/if}-->
                <!--{/if}-->
                <script type="text/javascript">
                    (function() {
                        $('.seccodeimg').on('click', function() {
                            $('#seccodeverify_$sechash').attr('value', '');
                            var tmprandom = 'S' + Math.floor(Math.random() * 1000);
                            $('.sechash').attr('value', tmprandom);
                            $(this).attr('src', 'misc.php?mod=seccode&update={$ran}&idhash='+ tmprandom +'&mobile=2');
                        });
                    })();
                </script>

            <!--{/if}-->
        </div>
        <div class="btn_login"><button tabindex="3" value="true" id="dosubmit" name="submit" type="submit" class="weui-btn weui-btn_primary"><span>{lang login}</span></button></div>
        <!--{if $config[showonekey]}-->
        <!--{if $inwechat}-->
            <div class="btn_login onekey">
                <button tabindex="3" type="button" class="weui-btn weui-btn_primary" style="background-color:$config[onekeycolor]!important;"><span>$config[onekey]</span></button>
            </div>
        <!--{else}-->
            <div class="btn_login onekey">
                <button tabindex="3" value="true" type="button" class="weui-btn weui-btn_primary" style="background-color:$config[onekeycolor]!important;"><span>$config[onekey]</span></button>
            </div>
        <!--{/if}-->
        <!--{/if}-->
    </form>

    <div class="reg_link">
        <div class="reg_tp">{lang xigua_login:sanguide}</div>
        <div class="loginbtn">
            <!--{if !$config[hidebtn]}-->
            <div class="btn_wechatlogin">
                <a href="{if $inwechat}$wehaturl{else}javascript:alert('$please_inwechat');{/if}"><span class="icon-wechat"></span></a>
                <span>{lang xigua_login:wechatword}</span>
            </div>
            <!--{/if}-->

            <!--{if $config[qq_uri]}-->
                <!--{eval $qq_uri= $config[qq_uri];}-->
            <!--{else}-->
                <!--{if $_G['setting']['connect']['allow'] && !$_G['setting']['bbclosed']}-->
                <!--{eval $qq_uri= $_G['connect']['login_url']."&statfrom=login_simple";}-->
                <!--{elseif is_file(DISCUZ_ROOT.'/qq.php')}-->
                <!--{eval $qq_uri= 'qq.php?mod=login&referer='.urlencode(dreferer());}-->
                <!--{/if}-->
            <!--{/if}-->

            <!--{if $qq_uri}-->
            <div class="btn_qqlogin">
                <a href="$qq_uri"><span class="icon-qq"></span></a>
                <span>{lang xigua_login:qqword}</span>
            </div>
            <!--{/if}-->
        </div>
        <!--{if $_G['setting']['regstatus']}-->
        <a href="member.php?mod={$_G[setting][regname]}">{lang xigua_login:regfont}</a>
        <!--{/if}-->
    </div>
</div>
<!-- userinfo end -->

<!--{if $_G['setting']['pwdsafety']}-->
<script type="text/javascript" src="{$_G['setting']['jspath']}md5.js?{VERHASH}" reload="1"></script>
<!--{/if}-->
<!--{eval updatesession();}-->

<script src="source/plugin/xigua_login/static/custom.js"></script>
<script type="text/javascript">
(function() {
$(document).on('change', '.sel_list', function() {
var obj = $(this);
$('.span_question').text(obj.find('option:selected').text());
if(obj.val() == 0) {
$('.answerli').css('display', 'none');
$('.questionli').addClass('bl_none');
} else {
$('.answerli').css('display', 'block');
$('.questionli').removeClass('bl_none');
}
});
$('.onekey').on('click', function(){
{if $inwechat} window.location.href = '$wehaturl'; {else} window.location.href = '$qq_uri';{/if}
});
})();

function check() {
    if(!$('input[name="username"]').val()){
        alert('{lang inputyourname}');return false;
    }
    if(!$('input[name="password"]').val()){
        $('input[name="password"]').focus();return false
    }
}
</script>


<!--{if !$_G['uid'] && strpos(strtolower($_SERVER['HTTP_USER_AGENT']), 'appbyme') !== false}-->
<script src="https://market-cdn.app.xiaoyun.com/release/sq-2.3.js"></script>
<script type="text/javascript">
    connectSQJavascriptBridge(function(){
        sq.logout(function(info){
            sq.login(function(userInfo){
                if(userInfo.errmsg == "OK"){
                    window.location.href="<!--{if dreferer()}-->{echo dreferer()}<!--{else}-->forum.php?mobile=2<!--{/if}-->";
                }
            });
        });
    });
</script>
<!--{/if}-->
<script src="static/js/mobile/common.js"></script>
<script>
    var formlock = 0;
    $(document).on('submit', '#loginform', function () {
        var dosubbtn = $('#dosubmit');
        var that = $(this);
        if (formlock === 1) {
            console.log(formlock);
            return false;
        }
        formlock = 1;
        $.ajax({
            type: 'post',
            url: that.attr('action') + '&inajax=1',
            data: that.serialize(),
            dataType: 'xml',
            success: function (data) {
                formlock = 0;
                if (null == data) {
                    return false;
                }
                var s = data;
                popup.open(s.lastChild.firstChild.nodeValue);
                evalscript(s.lastChild.firstChild.nodeValue);
            },
            error: function () {
                formlock = 0;
            }
        });
        return false;
    });
</script>
</body>
</html>