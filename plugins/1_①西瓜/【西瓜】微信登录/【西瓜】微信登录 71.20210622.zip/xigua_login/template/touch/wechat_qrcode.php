<?php exit('hrh');?>
<!--{template common/header}-->

<div class="c cl" align='center' style="width:100%;height:250px;padding:20px 0">
    <img width="220" height="220" src="$qrcodeurl" onerror="this.error=null;this.src='$qrcodeurl2'" />
    <div style="text-align:center;color:#666;font-size:16px">$tiptip2<div>
    $redirect_uri
</div>

<!--{template common/footer}-->