<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT .'source/plugin/xigua_hs/common.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
if(!$_G['cache']['plugin']['xigua_hs']){
    loadcache('plugin');
}
$hs_config = $_G['cache']['plugin']['xigua_hs'];
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$status_text = array(
    '0' => lang_hs('status0',0),
    '1' => lang_hs('status1',0),
    '2' => lang_hs('status2',0),
    '3' => lang_hs('status3',0),
);
$page = max(1, intval($_GET['page']));
$lpp   = 16;
$start_limit = ($page - 1) * $lpp;

if(1){

    if(submitcheck('permsubmit')){
        if($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_hs#xigua_hs_renling')->deletes($delete);
        }
        foreach ($_GET['status'] as $index => $item) {
            $old = C::t('#xigua_hs#xigua_hs_renling')->fetch($index);
            $shid = $old['shid'];
            C::t('#xigua_hs#xigua_hs_renling')->update($index, array('status' => $item, 'status_info' => $_GET['status_info'][$index], 'upts' => TIMESTAMP ));
            if($item == 3 && $old['status']!=3){
                $url = $_G['siteurl']."plugin.php?id=xigua_hs&ac=view&shid=$shid";
                notification_add($old['uid'],'system', lang_hs('notice_shen_error', 0),array('url' => $url,'note' => $_GET['status_info'][$index]),1);
            }
            if($item == 1 && $old['status']!=1){
                $url = $_G['siteurl']."plugin.php?id=xigua_hs&ac=view&shid=$shid";
                C::t('#xigua_hs#xigua_hs_shanghu')->update($shid, array('uid' => $old['uid']));
                notification_add($old['uid'],'system', lang_hs('notice_shen_success', 0),array('url' => $url,'note' => $_GET['status_info'][$index]),1);
            }
        }
        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_renling", 'succeed');
    }

    $wherearr = array();
    if($keyword = stripsearchkey(addslashes($_GET['keyword']))){
        $member = C::t('common_member')->fetch_by_username($keyword);
        if($member['uid']){
            $wherearr[] = 'uid='.$member['uid'];
        }else{
            $wherearr[] = " (uid='$keyword' or realname like '%$keyword%' OR mobile like '%$keyword%' or verinfo like '%$keyword%' or shid='$keyword') ";
        }
    }
    if($_GET['ct']){
        $wherearr[] = "ct='".intval($_GET['ct'])."'";
    }
    if(isset($_GET['selstatus']) && $_GET['selstatus']!=-1){
        $wherearr[] = "status='".intval($_GET['selstatus'])."'";
    }

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_renling");
    ?><style>
        .imgi{height:40px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
        .short{width:100px}
        .td23 input{width:80px!important;}.zlfield{display:block;margin-bottom:3px}.zlfield em{display:inline-block;color:forestgreen;margin:0px;width:100px}
    </style><?php
    echo '<div style="height:1px;width:100%"></div><div><input type="text" id="keyword" name="keyword" placeholder="'.lang_hs('plc', 0).'" value="'.$_GET['keyword'].'" class="txt" style="width:240px" /> ';


    $sel = '&nbsp;&nbsp;<label><select name="selstatus">';
    $sel .= "<option value=\"-1\" ".($_GET['selstatus']==-1||!isset($_GET['selstatus'])?'selected':'').">".lang_hs('qb',0)."</option>";
    foreach ($status_text as $index => $item) {
        if(isset($_GET['selstatus']) && $_GET['selstatus'] == $index){
            $sel .= "<option value=\"$index\" selected>$item</option>";
        }else{
            $sel .= "<option value=\"$index\">$item</option>";
        }
    }
    $sel .= '</select></label>';
    echo $sel;
    echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
    echo '</div>';

    showtableheader(lang_hs('tichengmanage', 0));
    showtablerow('class="header"',array(),array(
        lang_hb('del', 0),
        lang_hb('ID', 0),
        lang_hb('user', 0),
        lang_hs('rzll', 0),
        lang_hs('sh', 0),
        lang_hs('status', 0).'/'.lang_hs('status_info',0),
        lang_hs('crts', 0).'<br>'.lang_hs('upts', 0),
    ));

    $res = C::t('#xigua_hs#xigua_hs_renling')->fetch_all_by_page($start_limit, $lpp, $wherearr, 'id desc');
    $icount = C::t('#xigua_hs#xigua_hs_renling')->fetch_count_by_page($wherearr);

    $uids =$shids = array();
    foreach ($res as $v) {
        $uids[] = $v['uid'];
        $shids[] = $v['shid'];
    }
    if($uids){
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($shids){
        $shs = DB::fetch_all('SELECT * FROM %t WHERE shid IN (%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $uid = $v['uid'];
        $shid = $v['shid'];
        $shi = $shs[$shid];

        $upts = date('Y-m-d H:i:s', $v['upts']);
        $crts = date('Y-m-d H:i:s', $v['crts']);
        $shinfo = '';
        $shinfo .= lang_hs('shname', 0) . ':<b><a target="_blank" href="'.ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&shid=$shid" . '">' . $shi['name'] . '</a></b><br>' . lang_hs('tel', 0) . ':' . $shi['tel'] .
            '<div style="width:200px;max-height:150px;overflow-y:auto">' .
            ($shi['tag'] ? "<b style=\"color:forestgreen\">{$shi['tag']}</b><br>" : '') .
            '<br>'.lang_hs('jianjie', 0) .' : '. $shi['jieshao'] .
            ('<br><br>'.lang_hs('plugins_edit_vars_type_area', 0) .' : '.$shi['province'] . ' ' . $shi['city'] . ' ' . $shi['district'] . ' ' . $shi['street'] . ' ' . $shi['street_number'] . '<br>' . $shi['addr'] . '<br>'.lang_hs('jwd',0).' : ' . $shi['lat'] . ',' . $shi['lng']).
            '</div>';

        $sel = '';
        foreach ($status_text as $index => $item) {
            if($v['status'] == $index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }
        $href = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_renling&vid=$id";

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
            $id,
            "[uid:$uid]<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>".
'<br>'.lang_hs('realname',0).' '.$v['realname'].
'<br>'.lang_hs('mobile',0).' '.$v['mobile']
,
            $v['verinfo'],
$shinfo,
            "<select name='status[$id]'>$sel</select><br> <br> <textarea name='status_info[$id]'>{$v['status_info']}</textarea>",
            $crts.'<br>'.$upts,

        ));
    }

    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_renling&lpp=$lpp&page=$page", 0, 10);
    showsubmit('permsubmit', 'submit', 'del', '', $multipage);
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();

}