<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/5/23
 * Time: 11:55
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
function upload_xlsx($file_data, $dir = ''){
    $imgtype = array('.csv');
    $errors = array(
        UPLOAD_ERR_OK     => lang_hb('UPLOAD_ERR_OK',  0),
        UPLOAD_ERR_INI_SIZE   => lang_hb('UPLOAD_ERR_INI_SIZE',  0),
        UPLOAD_ERR_FORM_SIZE  => lang_hb('UPLOAD_ERR_FORM_SIZE', 0),
        UPLOAD_ERR_PARTIAL  => lang_hb('UPLOAD_ERR_PARTIAL',   0),
        UPLOAD_ERR_NO_FILE  => lang_hb('UPLOAD_ERR_NO_FILE',   0),
        UPLOAD_ERR_NO_TMP_DIR => lang_hb('UPLOAD_ERR_NO_TMP_DIR',0),
        UPLOAD_ERR_CANT_WRITE => lang_hb('UPLOAD_ERR_CANT_WRITE',0),
        99          => lang_hb('ONLY_IMAGE_ALLOW',   0),
    );
    $error = $file_data['error'];
    if($error != UPLOAD_ERR_OK){
        return array(
            'errno' => $error,
            'error' => $errors[$error]
        );
    }

    $type = '.'.addslashes(strtolower(substr(strrchr($file_data['name'], '.'), 1, 10)));
    $t = array_search($type, $imgtype);
    $filetype = $imgtype[$t];
    $file_data['type'] = strtolower($file_data['type']);
    if($t === false || !$filetype) {
        return array(
            'errno' => 99,
            'error' => $errors[99].$file_data['type'].'_'.$t.'_'.$filetype
        );
    }
    if(!$dir){
        $dir = 'source/plugin/xigua_hs/cache/csv/';
    }
    dmkdir($dir);
    $filena = md5($file_data['name']).$filetype;
    $file_attach = $dir. $filena;
    $saved_file = DISCUZ_ROOT . $file_attach;
    if(is_uploaded_file($file_data['tmp_name'])){
        if(@copy($file_data['tmp_name'], $saved_file) || @move_uploaded_file($file_data['tmp_name'], $saved_file)){
            @unlink($file_data['tmp_name']);
            return array('errno' => 0,'error' => $saved_file);
        }else{
            return array('errno' => UPLOAD_ERR_CANT_WRITE,'error' => $errors[UPLOAD_ERR_CANT_WRITE]);
        }
    }
    return array(
        'errno' => UPLOAD_ERR_NO_FILE,
        'error' => $errors[UPLOAD_ERR_NO_FILE]
    );
}
function read_file($file_url = ''){
    if(!is_file($file_url)){
        return FALSE;
    }
    $format_data = array();
    $fp = fopen($file_url, 'r');
    if($fp){
        $i = 0;
        while ($data = fgetcsv($fp)){
            $i++;
            $field_data = array();
            for($j = 0; $j < count($data); $j++){
                $field_data[] = trim($data[$j]);
            }
            if(!empty($field_data) && is_array($field_data)){
                $format_data[] = $field_data;
            }
        }
    }
    fclose($fp);
    return $format_data;
}
$sjobj = C::t('#xigua_hs#xigua_hs_shanghu');

if (submitcheck('formhash')) {
    $res = upload_xlsx($_FILES['import']);
    if($res['errno']){
        cpmsg($res['error'], "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=import", 'error');
    }
    $filename = $res['error'];
    $excelData = read_file($filename);
    $num = 0;
    foreach ($excelData as $index => $excelDatum) {
        if($index==0){
            continue;
        }
        if(!$excelDatum[0] || !is_numeric($excelDatum[0])){
            continue;
        }
        $insert_data = array(
            'uid' => $excelDatum[0],
            'endts' => strtotime($excelDatum[1]),
            'name' => trim($excelDatum[2]),
            'tel' => $excelDatum[4],
            'jieshao'  => $excelDatum[6],
            'province' => $excelDatum[7],
            'city' => $excelDatum[8],
            'district' => $excelDatum[9],
            'addr' => $excelDatum[10],
            'lng' => $excelDatum[11],
            'lat' => $excelDatum[12],
            'xuanchuan' => $excelDatum[13],
            'logo' => $excelDatum[14],
            'qr' => $excelDatum[15],
            'stid' => $excelDatum[16],
        );
        $albums = array();
        for($i=17; $i<=25; $i++){
            if($excelDatum[$i]){
                $albums[] = $excelDatum[$i];
            }
        }
        $insert_data['opentime'] = $excelDatum[26];
        $joints = strtotime($excelDatum[27]);
        $insert_data['crts'] = $joints ? $joints  : TIMESTAMP;
        $insert_data['upts'] = $joints ? $joints  : TIMESTAMP;

        $insert_data['album'] = $albums ? serialize($albums) : '';
        $hyname = $excelDatum[3];
        $hy_ret = C::t('#xigua_hs#xigua_hs_hangye')->fetch_by_name(array_filter(explode(' ', trim($hyname))));
        $hangye_ids = array_keys($hy_ret);
        $insert_data['hangye'] = $hyname;
        $insert_data['hangye_id1'] = $hangye_ids[0];
        $insert_data['hangye_id2'] = $hangye_ids[1];
        $insert_data['hangye_ids'] = implode(',', $hangye_ids);

        $viptype = DB::result_first('select id from %t where name=%s', array('xigua_hs_vip', $excelDatum[5]));
        $insert_data['viptype'] = $viptype;
        $insert_data['display'] = 1;

        $hs = $sjobj->fetch_by_name($insert_data['name']);
        if($hs){
            $shid = $hs['shid'];
            foreach ($insert_data as $index1 => $insert_datum) {
                if(!$insert_datum){
                    unset($insert_data[$index1]);
                }
            }
            $shid = C::t('#xigua_hs#xigua_hs_shanghu')->update($shid, $insert_data);
        }else{

            $shid = C::t('#xigua_hs#xigua_hs_shanghu')->insert($insert_data, true);
        }
        if($shid){
            $num++;
        }
    }
    cpmsg(lang_hb('succeed', 0).' '. $num.'/'.$num .lang_hb('j',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=import", 'succeed');
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=import", 'enctype');
showtips(lang_hs('drts_tip',0), 'tips', 1, lang_hs('drts', 0));

?><style>.mt20{margin-top:20px}.import{width:800px;height:600px}</style><?php
echo '<div class="mt20"><input name="import" type="file" /></div>';
echo ' <br><input type="submit" name="persubmit" class="btn" value="' . cplang('import') . '" />';
echo '</div>';
showformfooter();
