<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';

$hs_config = $_G['cache']['plugin']['xigua_hs'];
$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;

if (!submitcheck('addsubmit')) {
    $data = DB::fetch_first('select * from %t where 1 order by id desc', array('xigua_hs_vipguide'));
    echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?2\" />";
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_ban&page=$page");
    showtableheader();
    showtitle(lang_hs('add_jiesao', 0));
    showsetting(lang_hb('subject', 0), 'form[subject]', $data['subject'], 'text');
    ?>
    <tr class="hover">
        <input type="hidden" name="id" value="<?php echo $data ? $data['id'] : 0; ?>"/>
        <td colspan="2">
            <script id="c12" name="form[content]" type="text/plain" style="width:1024px;height:500px;"><?php echo $data ? $data['content'] : $hs_config['vipguide'] ?></script>
        </td>
    </tr>
    <script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
    <script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"></script>
    <script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
    <script>var ue = UE.getEditor('c12');</script>
    <?php
    showsubmit('addsubmit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
} else {
    $form = $_GET['form'];
    if (!$_GET['id']) {
        C::t('#xigua_hs#xigua_hs_vipguide')->insert(array(
            'id' => $_GET['id'],
            'subject' => $form['subject'],
            'link' => $form['link'],
            'content' => $form['content'],
            'crts' => TIMESTAMP,
        ));
    } else {
        C::t('#xigua_hs#xigua_hs_vipguide')->update($_GET['id'], array(
            'subject' => $form['subject'],
            'link' => $form['link'],
            'content' => $form['content'],
            'crts' => TIMESTAMP,
        ));
    }
    cpmsg(lang_hb('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_ban&page=$page", 'succeed');
}