<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_follow` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `shid` int(11) unsigned NOT NULL,
 `uid` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `shid_2` (`shid`,`uid`),
 KEY `shid` (`shid`),
 KEY `uid` (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_notice` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `shid` int(11) NOT NULL,
 `content` text NOT NULL,
 `crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `shid` (`shid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_shanghu` (
 `shid` int(11) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `display` int(1) NOT NULL,
 `endts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `name` varchar(80) NOT NULL,
 `hangye` varchar(200) NOT NULL,
 `hangye_id1` int(11) NOT NULL,
 `hangye_id2` int(11) NOT NULL,
 `tel` varchar(80) NOT NULL,
 `opentime` varchar(20) NOT NULL,
 `jieshao` text NOT NULL,
 `logo` varchar(200) NOT NULL,
 `qr` varchar(200) NOT NULL,
 `album` text NOT NULL,
 `viptype` int(11) NOT NULL,
 `lat` varchar(32) NOT NULL,
 `lng` varchar(32) NOT NULL,
 `province` varchar(200) NOT NULL,
 `city` varchar(200) NOT NULL,
 `district` varchar(200) NOT NULL,
 `street` varchar(200) NOT NULL,
 `street_number` varchar(200) NOT NULL,
 `addr` varchar(200) NOT NULL,
 `tags` text NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `comments` int(11) NOT NULL,
 `pubs` int(11) NOT NULL,
 `follow` int(11) NOT NULL,
 `tag` varchar(800) NOT NULL,
 `shipin` varchar(800) NOT NULL,
 `quanjing` varchar(800) NOT NULL,
 `xuanchuan` varchar(80) NOT NULL,
 `color` varchar(20) NOT NULL,
 `color_title` varchar(20) NOT NULL,
 `shangquan` varchar(40) NOT NULL,
 `append_img` text NOT NULL,
 `append_text` text NOT NULL,
 PRIMARY KEY (`shid`),
 KEY `uid` (`uid`),
 KEY `shangquan` (`shangquan`),
 KEY `dig_endts` (`dig_endts`),
 KEY `endts` (`endts`),
 KEY `hangye_id2` (`hangye_id2`),
 KEY `hangye_id1` (`hangye_id1`),
 KEY `name` (`name`),
 KEY `views` (`views`),
 KEY `shares` (`shares`),
 KEY `viptype` (`viptype`),
 KEY `display` (`display`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_vip` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `name` varchar(80) NOT NULL,
 `access` varchar(5000) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `days` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `dig_price` varchar(2000) NOT NULL,
 `icon` varchar(200) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_yuan` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `shid` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `realname` varchar(40) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `authorid` int(11) NOT NULL,
 `isadmin` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `shid` (`shid`),
 KEY `uid` (`uid`),
 KEY `mobile` (`mobile`),
 KEY `authorid` (`authorid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_pt_yf` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `dist1` varchar(80) NOT NULL,
 `dist2` varchar(80) NOT NULL,
 `yunfei` decimal(10,2) NOT NULL,
 `crts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `shids` varchar(1000) NOT NULL,
 `stid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_addr` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `realname` varchar(20) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `dist1` varchar(20) NOT NULL,
 `dist2` varchar(20) NOT NULL,
 `dist3` varchar(20) NOT NULL,
 `address` varchar(200) NOT NULL,
 `postcode` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `dft` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `crts` (`crts`),
 KEY `upts` (`upts`),
 KEY `dft` (`dft`),
 KEY `shid` (`shid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_fukuan` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `pay_ts` int(11) NOT NULL DEFAULT '0',
 `do_status` int(11) NOT NULL DEFAULT '-1',
 `order_id` varchar(80) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `shid` int(11) NOT NULL,
 `gid` int(11) NOT NULL,
 `hhruid` int(11) NOT NULL,
 `sjje` decimal(10,2) NOT NULL,
 `hhrje` decimal(10,2) NOT NULL,
 `yhje` decimal(10,2) NOT NULL,
 `fenpei_ts` int(11) NOT NULL,
 `note` varchar(800) NOT NULL,
 `gtype` varchar(20) NOT NULL,
 `jumpurl` varchar(2000) NOT NULL,
 `cancel_ts` int(11) NOT NULL,
 `cancel_user` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `shid` (`shid`),
 KEY `gid` (`gid`),
 KEY `uid` (`uid`),
 KEY `gtype` (`gtype`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_index` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_renling` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 `realname` varchar(80) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `verinfo` varchar(800) NOT NULL,
 `status` tinyint(1) NOT NULL,
 `status_info` text NOT NULL,
 `shid` int(11) NOT NULL,
 `orderid` varchar(64) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `status` (`status`),
 KEY `upts` (`upts`),
 KEY `shid` (`shid`),
 KEY `uid` (`uid`),
 KEY `orderid` (`orderid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hs_vipguide` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `subject` varchar(200) NOT NULL,
 `content` text NOT NULL,
 `crts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `indexpop` int(11) NOT NULL,
 `link` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`),
 KEY `indexpop` (`indexpop`)
) ENGINE=InnoDB;

ALTER TABLE `pre_xigua_hs_shanghu` CHANGE `album` `album` MEDIUMTEXT NOT NULL;

SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs_TC_UTF8.xml');

$finish = TRUE;


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'links\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql =<<<SQL
ALTER TABLE `pre_xigua_hs_shanghu` ADD `links` VARCHAR(2000) NOT NULL;
SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'miao\'', array('xigua_hs_hangye'), true);
if(!$r2){
    $sql =<<<SQL
ALTER TABLE `pre_xigua_hs_hangye` ADD `miao` INT(11) NOT NULL DEFAULT '0';
ALTER TABLE `pre_xigua_hs_hangye` ADD `qiang` INT(11) NOT NULL DEFAULT '0';
SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hong_num\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql =<<<SQL
ALTER TABLE `pre_xigua_hs_shanghu` ADD `hong_num` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hs_shanghu` ADD `hong_money` DECIMAL(10,2) NOT NULL;
ALTER TABLE `pre_xigua_hs_shanghu` ADD `hong_sendnum` INT(11) NOT NULL;
SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'zhangqi\'', array('xigua_hs_vip'), true);
if(!$r2){
    $sql =<<<SQL
ALTER TABLE `pre_xigua_hs_vip` ADD `zhangqi` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hs_vip` ADD `insxf` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hs_vip` ADD `discount` INT(11) NOT NULL;
SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'goodindex\'', array('xigua_hs_hangye'), true);
if(!$r2){
    $sql =<<<SQL
ALTER TABLE `pre_xigua_hs_hangye` ADD `goodindex` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hs_hangye` ADD INDEX(`goodindex`);
SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'shzhangqi\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `shzhangqi` INT(11) NOT NULL;


ALTER TABLE `pre_xigua_hs_shanghu` ADD `shinsxf` INT(11) NOT NULL;


ALTER TABLE `pre_xigua_hs_shanghu` ADD `shdiscount` INT(11) NOT NULL;
SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'stid\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `stid` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hs_shanghu` ADD INDEX(`stid`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hxpwd\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `hxpwd` VARCHAR(20) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'telprice\'', array('xigua_hs_hangye'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_hangye` ADD `telprice` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'mp3\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `mp3` VARCHAR(512) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'stids\'', array('xigua_hs_hangye'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_hangye` ADD `stids` VARCHAR(2000) NOT NULL;

ALTER TABLE `pre_xigua_hs_hangye` ADD INDEX(`stids`);

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'stids\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `stids` VARCHAR(1000) NOT NULL;

ALTER TABLE `pre_xigua_hs_shanghu` ADD `stida` VARCHAR(200) NOT NULL;

ALTER TABLE `pre_xigua_hs_shanghu` ADD INDEX(`stida`);

ALTER TABLE `pre_xigua_hs_shanghu` ADD `dig_startts` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hs_shanghu` ADD INDEX(`dig_startts`);

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'displayorder\'', array('xigua_hs_vip'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_vip` ADD `displayorder` TINYINT(3) NOT NULL;

ALTER TABLE `pre_xigua_hs_vip` ADD INDEX(`displayorder`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'lastnoti\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `lastnoti` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'aprice\'', array('xigua_hs_vip'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_vip` ADD `aprice` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'share_title\'', array('xigua_hs_hangye'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_hangye` ADD `share_title` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_hs_hangye` ADD `share_desc` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_hs_hangye` ADD `share_pic` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/install.php');


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'gid\'', array('xigua_hb_comment'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hb_comment` ADD `gid` int(11) NOT NULL;
ALTER TABLE `pre_xigua_hb_comment` ADD INDEX(`star`);
ALTER TABLE `pre_xigua_hb_comment` ADD INDEX(`gid`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'lat\'', array('xigua_hs_addr'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_addr` ADD `lat` VARCHAR(20) NOT NULL;
ALTER TABLE `pre_xigua_hs_addr` ADD `lng` VARCHAR(20) NOT NULL;
ALTER TABLE `pre_xigua_hs_addr` ADD INDEX(`lat`);
ALTER TABLE `pre_xigua_hs_addr` ADD INDEX(`lng`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'cat_link\'', array('xigua_hs_hangye'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_hangye` ADD `cat_link` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_hs_vip` ADD `freeday` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hs_shanghu` ADD `cover` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'maidanrate\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `maidanrate` DECIMAL(10,1) NOT NULL;
ALTER TABLE `pre_xigua_hs_shanghu` ADD `maidanmin` DECIMAL(10,2) NOT NULL;

ALTER TABLE `pre_xigua_hs_fukuan` ADD `rate` DECIMAL(10,1) NOT NULL;
ALTER TABLE `pre_xigua_hs_fukuan` ADD `ratemoney` DECIMAL(10,2) NOT NULL;
ALTER TABLE `pre_xigua_hs_fukuan` ADD `keepmoney` DECIMAL(10,2) NOT NULL;
ALTER TABLE `pre_xigua_hs_fukuan` ADD `ratemin` DECIMAL(10,2) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hide\'', array('xigua_hs_vip'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_vip` ADD `hide` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hs_vip` ADD INDEX(`hide`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'maxsize\'', array('xigua_hs_vip'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_vip` ADD `maxsize` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'video\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `video` VARCHAR(400) NOT NULL;
ALTER TABLE `pre_xigua_hs_shanghu` ADD `video_cover` VARCHAR(400) NOT NULL;

SQL;

    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hangye_ids\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `hangye_ids` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'guimo\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `guimo` VARCHAR(20) NOT NULL;
ALTER TABLE `pre_xigua_hs_shanghu` ADD `dongjie` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hideindex\'', array('xigua_hs_hangye'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_hangye` ADD `hideindex` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hs_hangye` ADD INDEX(`hideindex`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'appid\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `appid` VARCHAR(32) NOT NULL;
ALTER TABLE `pre_xigua_hs_shanghu` ADD `appkey` VARCHAR(32) NOT NULL;
ALTER TABLE `pre_xigua_hs_shanghu` ADD `device_id` VARCHAR(32) NOT NULL;
ALTER TABLE `pre_xigua_hs_shanghu` ADD `device_secret` VARCHAR(32) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hbtiaojian\'', array('xigua_hs_shanghu'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_shanghu` ADD `hbtiaojian` INT(11) NOT NULL;

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'hy_price\'', array('xigua_hs_vip'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hs_vip` ADD `hy_price` TEXT NOT NULL;

SQL;
    runquery($sql);
}

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'types\'', array('xigua_hs_index'), true);
if(!$r2){
    $sql = <<<SQL

ALTER TABLE `pre_xigua_hs_index` ADD `types` VARCHAR(20) NOT NULL;
ALTER TABLE `pre_xigua_hs_index` ADD `style` VARCHAR(20) NOT NULL;
ALTER TABLE `pre_xigua_hs_index` ADD `catids` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_hs_index` ADD INDEX(`types`);
ALTER TABLE `pre_xigua_hs_index` ADD INDEX(`catids`);

SQL;
    runquery($sql);
}