<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['do']=='add'){
    $config['maincolor'] = '#E96B6A';
    $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
    if(submitcheck('formhash')){
        $form = $_GET['form'];
        $form['money'] = floatval($form['money']);
        $form['keepmoney'] = floatval($form['keepmoney']);

        if(!$form['money'] && !$form['keepmoney']){
            hb_message(lang_hs('jebzq',0), 'error');
        }
//        $form['money'] =  $form['money'] - $form['keepmoney'];
        if($shdata['maidanrate']){
            $ratemoney = $form['money'];
            $ratemin = $shdata['maidanmin'];
            $rate = $shdata['maidanrate'];
            if($form['money']>=$shdata['maidanmin']){
                $form['money'] = $form['money'] * $shdata['maidanrate']/10;
            }
        }
        $money = $form['money']+$form['keepmoney'];
        if (!$money || $money <0) {
//            hb_message(lang_hs('jebzq',0), 'error');
            $money = 0.01;
        }
        $note = $form['note'];
        /*if (!$note) {
            hb_message(lang_hs('qtxfkbz',0), 'error');
        }*/

        if ($money > 0) {

            $hhruid = 0;
            if($_G['cache']['plugin']['xigua_hh']){
                $row = C::t('#xigua_hh#xigua_hh_invite')->fetch_by_fansuid($_G['uid']);
                $hhruid = ($row['uid']==$_G['uid'] ? 0 : $row['uid']);
            }

            $log = array(
                'uid' => $_G['uid'],
                'crts' => TIMESTAMP,
                'upts' => TIMESTAMP,
                'pay_ts' => 0,
                'do_status' => -1,
                'order_id' => '',
                'price' => $money,
                'note' => $note,
                'shid' => $_GET['shid'],
                'gid'   => $_GET['gid'],
                'gtype' => $_GET['gtype'],
                'hhruid' => $hhruid,
                'rate' => $rate,
                'ratemoney' => $ratemoney,
                'keepmoney' => $form['keepmoney'],
                'ratemin' => $ratemin,
            );

            $lodig = C::t('#xigua_hs#xigua_hs_fukuan')->insert($log, 1);
            $log['id'] = $lodig;

            $url = "$SCRITPTNAME?id=xigua_hs&ac=help&do=fukuan";
            $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($_GET['shid']);

            $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $money, $_G['username'] . lang_hs('zfg',0) . $sh['name']. ''.$money.lang_hs('yuan',0) , 'common_fk', array(
                'data' => $log,
                'callback' => array(
                    'file' => 'source/plugin/xigua_hs/function.php',
                    'method' => 'hs_callback_fukuan'
                ),
                'location' => $_GET['backto'] ? $_GET['backto'] : $_G['siteurl'] . $url,
            ));
            C::t('#xigua_hs#xigua_hs_fukuan')->update($lodig, array('order_id' => $order_id));

            $rl = urlencode($url);
            $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl" . $urlext) . $urlext;
            C::t('#xigua_hs#xigua_hs_fukuan')->update($lodig, array('jumpurl' => $jumpurl));
            hb_message(lang_hs('jumppay', 0), 'success', $jumpurl);
        }
    }else{
        $shdata['maidanrate'] = floatval($shdata['maidanrate']);
        $shdata['maidanmin'] = floatval($shdata['maidanmin']);
        $navtitle = lang_hs('x',0).$shdata['name'].lang_hs('fk',0);
        if(!checkmobile()){
            include template('xigua_hb:index');
            exit;
        }
        include template('xigua_hs:buy');
    }
}elseif($_GET['do']=='renling'){
    $sjobj = C::t('#xigua_hs#xigua_hs_shanghu');
    $rlobj = C::t('#xigua_hs#xigua_hs_renling');
    if(submitcheck('formhash')){
        $shid = intval($_GET['shid']);
        $ol = $sjobj->fetch($shid);
        if($ol['uid']>0){
            hb_message(lang_hs('ybrl',0), 'error');
        }
        $user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);

        if($rlobj->fetch_by_uid_shid($_G['uid'], $shid)){
            hb_message(lang_hs('yjrlqddsh',0), 'success');
        }
        $rlobj->insert(array(
            'uid' => $_G['uid'],
            'shid' => $shid,
            'crts' => TIMESTAMP,
            'verinfo' => $_GET['text'],
            'mobile' => $user['mobile'],
            'realname' => $user['realname'],
        ));
        hb_message(lang_hs('rlcg',0), 'success');
    }
}else{
    if (submitcheck('formhash')) {
        if ($_GET['do1'] == 'del') {

            if (IS_ADMINID) {
                C::t('#xigua_hb#xigua_hb_comment')->delete($_GET['cmtid']);
                hb_message(lang_hb('del_succeed', 0), 'success', 'reload');
            }else{
                $cm = C::t('#xigua_hb#xigua_hb_comment')->fetch($_GET['cmtid']);
                $shid = $cm['shid'];
                if($shid && $_G['uid']){
                    $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
                    if($shdata['uid'] == $_G['uid']){
                        $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
                        if(in_array('cmtt', $vipinfo['access'])){
                            C::t('#xigua_hb#xigua_hb_comment')->delete($_GET['cmtid']);
                            hb_message(lang_hb('del_succeed', 0), 'success', 'reload');
                        }
                    }
                }

            }

            hb_message('error', 'error');
        }
    }
}