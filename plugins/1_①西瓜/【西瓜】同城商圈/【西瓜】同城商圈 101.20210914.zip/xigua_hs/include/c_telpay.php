<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$_GET['rl'] = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : $_G['siteurl']."$SCRITPTNAME?id=xigua_hs&ac=view&shid={$shid}$urlext";
$hyid = intval($_GET['hyid']);
$hangyes = C::t('#xigua_hs#xigua_hs_hangye')->fetch_light(array($hyid));
$hangye = $hangyes[$hyid];
$sh = $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);

$vtelp  = $hangye['telprice'];

if($sh['end'] && $_G['cache']['plugin']['xigua_hs']['gqbx']==3 && $_G['cache']['plugin']['xigua_hs']['guoqiprice']>0){
    $vtelp = $_G['cache']['plugin']['xigua_hs']['guoqiprice'];
}

$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $vtelp, lang_hb('ckxxjg', 0). $sh['name'] ."($shid)", 'common_shtelpay', array(
    'data' => array(
        'uid' => $_G['uid'],
        'price' => $hangye['telprice'],
        'hyid' => $hyid,
        'shid' => $shid,
    ),
    'callback' => array(
        'file' => 'source/plugin/xigua_hs/lib/notify_third.php',
        'method' => 'hs_telpay_callback'
    ),
    'location' => $_GET['rl'],
));

$rl = urlencode($_GET['rl']);
$jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
hb_message(lang_hs('jumppay',0), 'success', $jumpurl);