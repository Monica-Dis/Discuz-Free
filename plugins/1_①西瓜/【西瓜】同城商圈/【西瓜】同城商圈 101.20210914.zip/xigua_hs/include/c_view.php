<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if(!in_array('shipin', $vipinfo['access'])){
    $v['old_shipin'] = $v['shipin'] = '';
}
if(!in_array('video', $vipinfo['access'])){
    $v['video'] = $v['video_cover'] = '';
}
if(!in_array('quanjing', $vipinfo['access'])){
    $v['quanjing'] = '';
}
if(!in_array('color', $vipinfo['access'])){
    $mc = $mc_op = $config['maincolor'];
}

$shtel = "tel:$v[tel]";$needpaytel = 0;
if($_G['cache']['plugin']['xigua_hs']['pricetel']):
    $vtelp  = $hangye[$v['hangye_id2']]['telprice'];

    if($v['end'] && $_G['cache']['plugin']['xigua_hs']['gqbx']==3 && $_G['cache']['plugin']['xigua_hs']['guoqiprice']>0){
        $vtelp = $_G['cache']['plugin']['xigua_hs']['guoqiprice'];
        $shdata['qr'] = '';
    }

    if($vtelp>0):
        if($_G['uid']):
            $viewtels = C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], array($v['shid']), 'shid');
        endif;
        $hangye_id2= $v['hangye_id2'];
        if(!$viewtels[$v['shid']]):
            $shtel = "javascript:hs_paytel('$v[shid]','$vtelp','$hangye_id2');";$needpaytel=1;
        endif;
    endif;
endif;
if($_GET['x'] || IN_PROG):
    dsetcookie('miniprogram', 1, 120);
endif;
if(($hs_config['showbgtop'] && $v['album'][0]) || $v['cover']):
    $cover = $v['cover'] ? $v['cover'] : $v['album'][0];
endif;
$showiframe = IN_PROG;
if($showiframe){
    $quanjing = urlencode($v['quanjing']);
    $shipin = urlencode($v['old_shipin']);
    $v['quanjing'] = $v['shipin'] = '';
}
if(!is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/hs_api.inc.php')){
    $v['video'] = '';
}
$filler = $v['quanjing'] || $v['shipin'] || $v['video'] || ($hs_config['topswiper']&&$v['album'][0]);

include_once DISCUZ_ROOT.'source/plugin/xigua_hs/include/c_shtel.php';
if($v['end']&&!$showtel){
    $shtel = "";
    $shdata['qr'] = '';
}
if($_GET['edid']||$_GET['fx']):
    $config['showguide'] = 1;
endif;