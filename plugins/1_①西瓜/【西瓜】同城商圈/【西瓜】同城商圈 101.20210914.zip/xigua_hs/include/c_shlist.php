<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_G['cache']['plugin']['xigua_hs']['showshindex']&&$_G['cache']['plugin']['xigua_hs']['sh_list'] && $_G['cache']['plugin']['xigua_hs']){
    $shnumindex= $_G['cache']['plugin']['xigua_hs']['indexshnum'];
    if(!$shnumindex){
        $shnumindex = 10;
    }
    if($_G['cache']['plugin']['xigua_hs']['sh_list']==1){
        $sh_list = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('display=1 AND endts>='.TIMESTAMP), 0, $shnumindex, 'dig_endts DESC, views DESC', 'shid,name,logo');
    }elseif ($_G['cache']['plugin']['xigua_hs']['sh_list']==2){
        $sh_list = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('display=1 AND endts>='.TIMESTAMP), 0, $shnumindex, 'shid DESC', 'shid,name,logo');
    }
    $shwidth = $shnumindex*98;
    $shwidthauto = $shwidth-345;
    $shtime = $shnumindex*2000;
}