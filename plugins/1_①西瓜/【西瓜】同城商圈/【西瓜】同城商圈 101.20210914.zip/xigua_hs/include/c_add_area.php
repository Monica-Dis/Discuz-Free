<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function get_shids_by_uid(){
    global $_G;
    $shids = array();
    if(!$_G['uid'] || !$_G['cache']['plugin']['xigua_hs']){
        return $shids;
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array('0'), array_keys($shids1), array_keys($shids2));
    return $shids;
}

$navtitle = lang_hs('psfsgl',0);
if(submitcheck('formhash')){
    if($_GET['yfid']){
        C::t('#xigua_hs#xigua_hs_yf')->delete($_GET['yfid']);
        hb_message(lang_hs('sccg',0), 'success', 'reload');
    }
    $form = $_GET['form'];
    /*if($form['yunfei']<=0){
        hb_message('jinecuowu', 'error');
    }*/
    $dst = explode(' ', trim($form['dist']));
    $d1 = $dst[2] ? $dst[2] : ( $dst[1] ?  $dst[1] :  $dst[0]);
    /*if(C::t('#xigua_hs#xigua_hs_yf')->fetch_all_by_array(array('dist1' => $d1, 'uid' => $_G['uid']))){
        hb_message(lang_hs('diquyiqunzai',0), 'error');
    }*/
    $data = array(
        'dist1' => $d1,
        'dist2' => '',
        'uid' => $_G['uid'],
        'shids' => implode(',', get_shids_by_uid()),
        'crts' => TIMESTAMP,
        'yunfei' => $form['yunfei'],
    );
    if(C::t('#xigua_hs#xigua_hs_yf')->insert($data)){
        hb_message(lang_hs('tjcg',0), 'success', 'reload');
    }
}