<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($vipinfo){
    $navtitle .= "({$vipinfo['name']})";
}
$showv = is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/hs_api.inc.php') && (($config['qn_ak'] && $config['qn_sk'] && $config['qn_bk'] && $config['qn_url']) || ($config['ACCESS_ID'] && $config['ACCESS_KEY'] && $config['ENDPOINT'] && $config['BUCKET']));

if($hs_config['sxlink']){
    global $stinfo;
    if($stinfo['uid']> 0){
        $tmpid = $stinfo['uid'];
    }else{
        $tmpid = $adminids[0];
    }
    $shmember = getuserbyuid($tmpid);
    $shavat = avatar($tmpid, 'middle', true);
    $kflnk = str_replace(array('{uid}', '{username}', '{avatar}'), array($tmpid, $shmember['username'], $shavat), $hs_config['sxlink']);
    if(!(IN_QIANFAN||IN_MAGAPP) && ($config['magapp_secret'] || $config['hostname'])){
        $kflnk = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=".$tmpid;
    }
}

$guimo = array();
if($hs_config['gm']):
    foreach (array_filter(explode("\n", trim($hs_config['gm']))) as $index => $item):
        $guimo[$index] = trim($item);
    endforeach;
endif;
$desc = $hs_config['shdesc'];

$get_keystep = 1;
if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pub.php')){
    include DISCUZ_ROOT.'source/plugin/xigua_hb/include/c_pub.php';
}