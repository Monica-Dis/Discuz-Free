<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

if($_GET['magage']){
    $_GET['manage']= 1;
}

function get_shids_by_uid1(){
    global $_G;
    $shids = array();
    if(!$_G['uid'] || !$_G['cache']['plugin']['xigua_hs']){
        return $shids;
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array('0'), array_keys($shids1), array_keys($shids2));
    return $shids;
}

if ($_GET['do'] == 'fuk') {
    if (submitcheck('formhash')) {
        $money = $_GET['money'];
        $note = $_GET['note'];
        if (!$money || $money <0) {
            hb_message(lang_hs('jebzq',0), 'error');
        }
        if (!$note) {
            hb_message(lang_hs('qtxfkbz',0), 'error');
        }
/*        $user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
        if(!$user['mobile']){
            hb_message(lang_hs('qbdsjh',0), "error", "$SCRITPTNAME?id=xigua_hb&ac=myzl&referer=". urlencode(hb_currenturl()).$urlext);
        }*/

        if ($money > 0) {

            $hhruid = 0;
            if($_G['cache']['plugin']['xigua_hh']){
                $row = C::t('#xigua_hh#xigua_hh_invite')->fetch_by_fansuid($_G['uid']);
                $hhruid = ($row['uid']==$_G['uid'] ? 0 : $row['uid']);
            }

            $log = array(
                'uid' => $_G['uid'],
                'crts' => TIMESTAMP,
                'upts' => TIMESTAMP,
                'pay_ts' => 0,
                'do_status' => -1,
                'order_id' => '',
                'price' => $money,
                'note' => $note,
                'shid' => $_GET['shid'],
                'gid'   => $_GET['gid'],
                'gtype' => $_GET['gtype'],
                'hhruid' => $hhruid
            );

            $lodig = C::t('#xigua_hs#xigua_hs_fukuan')->insert($log, 1);
            $log['id'] = $lodig;

            $url = "$SCRITPTNAME?id=xigua_hs&ac=help&do=fukuan";
            $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($_GET['shid']);

            $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $money, $_G['username'] . lang_hs('zfg',0) . $sh['name']. ''.$money.lang_hs('yuan',0) , 'common_fk', array(
                'data' => $log,
                'callback' => array(
                    'file' => 'source/plugin/xigua_hs/function.php',
                    'method' => 'hs_callback_fukuan'
                ),
                'location' => $_GET['backto'] ? $_GET['backto'] : $_G['siteurl'] . $url,
            ));
            C::t('#xigua_hs#xigua_hs_fukuan')->update($lodig, array('order_id' => $order_id));

            $rl = urlencode($url);
            $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl" . $urlext) . $urlext;
            C::t('#xigua_hs#xigua_hs_fukuan')->update($lodig, array('jumpurl' => $jumpurl));
            hb_message(lang_hs('jumppay', 0), 'success', $jumpurl);
        }

    }else{
        dheader("Location: $SCRITPTNAME?id=xigua_hs");
    }
} elseif($_GET['do']=='fukuan') {


    if($_GET['manage'] && $shids = get_shids_by_uid1()){
        $navtitle = lang_hs('skjl',0);
        $custom_side = array(
            "$SCRITPTNAME?id=xigua_hb&ac=qianbao".$urlext,
            lang_hs('tx', 0)
        );
//        $sh =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch($shid);
        $fkimg = hs_qrmake($_G['siteurl'].$SCRITPTNAME.'?id=xigua_hs&ac=view&shid='.$shid.'&lijifuk=1'.$urlext);
    }else{
        $navtitle = lang_hs('wdfkjl',0);
        $custom_side = array(
            "$SCRITPTNAME?id=xigua_hb&ac=my".$urlext,
            lang_hb('wode', 0)
        );
    }


    include template('xigua_hs:fukuan');
    exit;
} elseif($_GET['do']=='fukuan_list') {
    $whwe = array();
    if($_GET['manage'] && $shids = get_shids_by_uid1()){
        $whwe[] = " ( shid in (".implode(',',$shids ).")) ";
    }else{
        $whwe[] = "uid=".$_G['uid'];
    }
    if($_GET['shid']){
        $whwe[] = "shid=".$_GET['shid'];
    }

    $list  = C::t('#xigua_hs#xigua_hs_fukuan')->fetch_all_by_where($whwe, $start_limit, $lpp );

    foreach ($list as $index => $item) {
        $list[$index]['sh'] =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch($item['shid']);
        $list[$index]['user'] =  getuserbyuid($item['uid']);
    }

    include template('xigua_hb:header_ajax');
    include template('xigua_hs:fukuan_list');
    include template('xigua_hb:footer_ajax');
} elseif($_GET['do']=='doqueren') {
} elseif($_GET['do']=='quxiao') {
    $whwe = '1';
    if($_GET['manage'] && $shids = get_shids_by_uid1()){
        $whwe = " ( shid in (".implode(',',$shids ).")) ";
    }else{
        $whwe = " uid=".$_G['uid'];
    }
    $ret = DB::fetch_first("select * from %t WHERE $whwe AND id=%d" , array(
        'xigua_hs_fukuan',
        $_GET['fukid'],
    ));
    if($ret){
        $user = getuserbyuid($_G['uid']);
        $r = DB::query("UPDATE %t SET cancel_ts=%d, cancel_user=%s WHERE $whwe AND id=%d", array(
            'xigua_hs_fukuan',
            TIMESTAMP,
            $user['username'],
            $_GET['fukid'],
        ));
        if($r && $ret['order_id']){
            C::t('#xigua_hb#xigua_hb_order')->delete_order(array($ret['order_id']));
        }
        hb_message(lang_hs('qxcg',0), 'success', 'reload');
    }
} elseif($_GET['do']=='checkvip') {
    $isapp = (IN_MAGAPP||IN_QIANFAN||IN_APPBYME||IN_MOCUZ);
    $hy_price_ary = array();
    $vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99);
    foreach ($vips as $index => $vip) {
        $hy_price_ary[$vip['id']] = $vip['udays'];
        $tmp = '';
        foreach (explode("\n", trim($vip['hy_price'])) as $_index => $item) {
            list($hyid, $p1, $p2) = explode('|', trim($item));
            if(($p1||$p2) && in_array($hyid, array($_GET['hyid1'], $_GET['hyid2']))){
                $hy_price = array('_price' => $p1, '_appprice' => $p2);
                $hy_price_ary[$vip['id']] = C::t('#xigua_hs#xigua_hs_vip')->hs_days_format($vip['days'], $isapp&&$p2?$p2:$p1);
            }
        }
    }
    if($hy_price_ary){
        $exjs = 'javascript:';
        foreach ($hy_price_ary as $index => $item) {
            $exjs .= '$(\'#car_vip_'.$index.'\').html(\''.$item.'\');';
        }
        hb_message('', 'success', $exjs.';');
    }else{
        hb_message('', 'error');
    }
}