<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function get_shidby_uid(){
    global $_G;
    $shids = array();
    if(!$_G['uid'] || !$_G['cache']['plugin']['xigua_hs']){
        return $shids;
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array('0'), array_keys($shids1), array_keys($shids2));
    return $shids;
}
switch ($_GET['do']){
    case 'add':
        if(submitcheck('formhash')){
            $form = $_GET['form'];
            if(!$form['realname']){
                hb_message(lang_hb('plzxm', 0), 'errror');
            }
            if(!$form['mobile']){
                hb_message(lang_hb('dianhua1',0), 'error');
            }
            if(!preg_match($isMob, $form['mobile']) && !preg_match($isTel, $form['mobile'])){
                hb_message(lang_hb('dianhua2',0), 'error');
            }
            if(!$form['address']){
                hb_message(lang_hb('plzxxdz',0), 'errror');
            }
            if(!$form['dist']){
//                hb_message('plzdist', 'errror');
            }
            if(!in_array($form['shid'], get_shidby_uid())){
                hb_message('wuquanxian', 'error');
            }

            $distary = array_filter(explode(' ', trim($form['dist'])));

            if($form['oldid']){
                $ret = C::t('#xigua_hs#xigua_hs_addr')->fetch($form['oldid']);
                if($ret['uid'] != $_G['uid']){
                    hb_message('NoAccess', 'error');
                }
                C::t('#xigua_hs#xigua_hs_addr')->update($form['oldid'] ,array(
                    'realname' => $form['realname'],
                    'mobile'   => $form['mobile'],
                    'address'  => strip_tags(nl2br($form['address'])),
                    'dist1'    => $distary[0],
                    'dist2'    => $distary[1],
                    'dist3'    => $distary[2],
                    'postcode' => $form['postcode'],
                    'crts' => TIMESTAMP,
                    'upts' => TIMESTAMP,
                    'uid'   => $_G['uid'],
                    'shid'   => $form['shid'],
                    'lat' => $form['lat'],
                    'lng' => $form['lng'],
                ));
            }else{
                C::t('#xigua_hs#xigua_hs_addr')->insert(array(
                    'realname' => $form['realname'],
                    'mobile'   => $form['mobile'],
                    'address'  => strip_tags(nl2br($form['address'])),
                    'dist1'    => $distary[0],
                    'dist2'    => $distary[1],
                    'dist3'    => $distary[2],
                    'postcode' => $form['postcode'],
                    'crts' => TIMESTAMP,
                    'upts' => TIMESTAMP,
                    'uid'   => $_G['uid'],
                    'shid'   => $form['shid'],
                    'lat' => $form['lat'],
                    'lng' => $form['lng'],
                ));
            }
            hb_message(lang_hb('succeed',0),'success', $back_to_overwrite ? str_replace('&paynew=1','',$back_to_overwrite).'&paynew=1': "$SCRITPTNAME?id=xigua_hs&ac=myaddr&shid=".$form['shid']);
        }
        break;
    case 'del':
        $id = intval($_GET['delid']);
        if(submitcheck('delid', 1) && $_GET['formhash'] == FORMHASH){
            C::t('#xigua_hs#xigua_hs_addr')->delete($id);
            hb_message(lang_hb('del_succeed',0));
        }
        break;
    default:
        $navtitle = lang_hs('zitidianguanli',0);
        $shid = intval($_GET['shid']);
        $whwere = array(
            "shid=$shid"
        );
        $custom_side = array(
            "$SCRITPTNAME?id=xigua_hs&ac=shcenter$urlext",
            lang_hs('shcenter',0)
        );
        if(!$shid){
            hb_message('wuquanxian', 'error');
        }
        if(!in_array($shid, get_shidby_uid())){
            hb_message('wuquanxian', 'error');
        }

        $list = C::t('#xigua_hs#xigua_hs_addr')->fetch_all_by_page($start_limit, 100, $whwere);
        break;
}