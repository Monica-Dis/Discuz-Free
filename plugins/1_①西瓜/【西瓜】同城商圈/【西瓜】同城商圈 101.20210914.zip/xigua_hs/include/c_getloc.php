<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if($_GET['do']=='change') {
    $lng = floatval($_GET['lng']);
    $lat = floatval($_GET['lat']);
    $from = intval($_GET['from']);
    $to = intval($_GET['to']);
    if (!$ak = $_GET['ak']) {
        $ak = $_G['cache']['plugin']['xigua_hs']['baidusdk'];
    }
    $ret = hb_curl("http://api.map.baidu.com/geoconv/v1/?coords=$lng,$lat&from=$from&to=$to&ak=$ak");
    $ret = json_decode($ret, 1);
    echo $ret['result'][0]['x'] . ',' . $ret['result'][0]['y'];
    exit;
}elseif($_GET['do']=='getshvip'){
    $shname = $_GET['shname'];
    $viptype = DB::result_first('SELECT viptype FROM ' . DB::table('xigua_hs_shanghu') .' WHERE `name`=%s ', array($shname));
    $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($viptype);
    if(in_array($_GET['checkif'], $vipinfo['access'])){
        hb_message('1', 'success');
    }
    hb_message('0', 'success');
}else{
    if(!$_GET['lat']){
        hb_message('lat empty', 'error');
    }
    if(!$_GET['lng']){
        hb_message('lng empty', 'error');
    }
    $ret = hb_current_location($_GET['lat'], $_GET['lng']);
    if(is_array($ret)){
        if($_GET['checkst'] && $_G['cache']['plugin']['xigua_st']){
            $geoinfo = hs_multi_diconv($ret[0]['address_component'],'utf-8', CHARSET);
            if($rs = DB::fetch_first("select `stid`,`name`,area3 from %t where area3<>'' AND `area3` IN (%n) AND status=1", array('xigua_st', $geoinfo))) {
                hb_message(implode(',', $rs).','.implode(',', $geoinfo), 'success');
            }
            if($rs = DB::fetch_first("select `stid`,`name`,area2 from %t where area2<>'' AND `area2` IN (%n) AND area3='' AND status=1", array('xigua_st', $geoinfo))) {
                hb_message(implode(',', $rs).','.implode(',', $geoinfo), 'success');
            }
            if($rs = DB::fetch_first("select `stid`,`name`,area2 from %t where area1<>'' AND `area1` IN (%n) AND area2='' AND area3='' AND status=1", array('xigua_st', $geoinfo))) {
                hb_message(implode(',', $rs).','.implode(',', $geoinfo), 'success');
            }

            if($_G['cache']['plugin']['xigua_st']){
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                $rs = DB::fetch_first("select `stid`,area1,area2,area3,`name` from %t WHERE lat>0 AND lng>0 AND `length`>=(acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004) AND status=1 ORDER BY (acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004) ASC LIMIT 1", array('xigua_st'));
                /*AND `length`>=(acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004)*/
                if($rs){
                    if($rs['area3']){
                        hb_message(implode(',', array($rs['stid'],$rs['area3'])).','.implode(',', $geoinfo), 'success');
                    }elseif($rs['area2']){
                        hb_message(implode(',', array($rs['stid'],$rs['area2'])).','.implode(',', $geoinfo), 'success');
                    }elseif($rs['area']){
                        hb_message(implode(',', array($rs['stid'],$rs['area'])).','.implode(',', $geoinfo), 'success');
                    }else{
                        hb_message(implode(',', array($rs['stid'],$rs['name'])).','.implode(',', $geoinfo), 'success');
                    }
                }
            }
            hb_message('error', 'error');
        }
        if($_GET['checkallow']&&$config['areaallow']){
            $areaallow = array_filter(explode("\n", trim($config['areaallow'])));
            foreach ($areaallow as $index => $item) {
                $areaallow[$index] = trim($item);
            }
            if($areaallow){
                $ar1 = hs_multi_diconv($ret[0]['address_component'],'utf-8', CHARSET);
                if(!array_intersect($ar1, $areaallow)){
                    hb_message(lang_hb('notallowq1',0).implode(',', $ar1).lang_hb('notallowq2',0).implode(',', $areaallow), 'error');
                }
            }
        }
        if($_GET['geoauto']){
            $geoinfo = hs_multi_diconv($ret[0]['address_component'],'utf-8', CHARSET);
            if($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['district']))){
                hb_message($rs.':dist='.urlencode($rs), 'success');
            }
            if($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['city']))){
                hb_message($rs.':city='.urlencode($rs), 'success');
            }
            if($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['province']))){
                hb_message($rs, 'success');
            }
            hb_message('error', 'error');
        }
        hb_message(json_encode($ret), 'success');
    }else{
        hb_message($ret, 'error');
    }
}