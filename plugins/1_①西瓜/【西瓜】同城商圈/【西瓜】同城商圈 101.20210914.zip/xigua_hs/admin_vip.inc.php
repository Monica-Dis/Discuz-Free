<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';

$page = max(1, intval(getgpc('page')));
$lpp = 8;
$start_limit = ($page - 1) * $lpp;


if(submitcheck('permsubmit')){
    if(!empty($_GET['addrs'])) {
        foreach ($_GET['addrs'] as $index => $addr) {
            $row = array(
                'name' => $addr['name'],
                'price' => $addr['price'],
                'days' => $addr['days'],
                'zhangqi' => $addr['zhangqi'],
                'insxf' => $addr['insxf'],
                'discount' => $addr['discount'],
                'dig_price' => trim($addr['dig_price']),
                'hy_price' => trim($addr['hy_price']),
                'crts' => TIMESTAMP,
                'upts' => TIMESTAMP,
                'displayorder' => $addr['displayorder'],
            );
            C::t('#xigua_hs#xigua_hs_vip')->insert($row);
        }
    }
    if($delete = dintval($_GET['delete'], true)) {
        $r = C::t('#xigua_hs#xigua_hs_vip')->deletes($delete);
    }
    if($delimg = $_GET['delimg']){
        foreach ($delimg as $catid_ => $fields_) {
            $data_ = array();
            if($fields_['icon'] == 1){
                $data_['icon'] = '';
            }
            if($data_){
                C::t('#xigua_hs#xigua_hs_vip')->update(intval($catid_), $data_);
            }
        }
    }

    if($_FILES['icon']){
        $icons = hb_uploads($_FILES['icon']);
    }

    if($row = $_GET['row']){
        foreach ($row as $index => $item) {
            $data = array(
                'name' => $item['name'],
                'price' => $item['price'],
                'aprice' => $item['aprice'],
                'days' => $item['days'],
                'zhangqi' => $item['zhangqi'],
                'insxf' => $item['insxf'],
                'discount' => $item['discount'],
                'freeday' => $item['freeday'],
//                'customdesc' => $item['customdesc'],
                'dig_price' => trim($item['dig_price']),
                'hy_price' => trim($item['hy_price']),
                'access' => implode(',', $item['access']),
                'upts' => TIMESTAMP,
                'displayorder' => $item['displayorder'],
                'hide' => $item['hide'],
                'maxsize' => $item['maxsize'],
            );
            if($_FILES['icon']['error'][$index] === UPLOAD_ERR_OK) {
                $data['icon'] = ($icons[$index]['errno'] == 0 ? $icons[$index]['error'] : '');
            }
            $r = C::t('#xigua_hs#xigua_hs_vip')->update($index, $data);
        }
    }
    cpmsg(lang_hs('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_vip&page=$page", 'succeed');
}


echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
showtips(lang_hs('config_tip', 0));
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_vip&page=$page", 'enctype');
showtableheader('');
showtablerow('class="header"', array(), array(
    lang_hs('del', 0),
    lang_hs('order', 0),
    lang_hs('vipname', 0).'/'. lang_hs('icon', 0),
    lang_hs('rzprice', 0),
    lang_hs('kz_price', 0),
    lang_hs('access', 0),
    lang_hs('crts', 0).'<br>'.lang_hs('upts', 0),
));

$option = $access_list;

$list = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page($start_limit , $lpp);
$count = C::t('#xigua_hs#xigua_hs_vip')->fetch_count_by_page();
$multipage = multi($count, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_vip&page=$page");

foreach ($list as $index => $row) {
    $id = $row['id'];
    $access = $row['access'];
    $maxsize = $row['maxsize'];

    $options = '<table class="pztable" style="width:280px">';
    $i = 1;
    foreach ($option as $index1 => $name) {
        $selectd = in_array($index1, $access) ? 'checked="checked"' : '';
        if($i%3==1){
            $options .= "<tr style='display:block'>";
        }
        if($index1=='video'){
            $options .= "<td style='width:200px' colspan='2'><label><input name='row[{$id}][access][$index1]' value='$index1' type='checkbox' $selectd> $name </label> <input style='width:20px' name='row[$id][maxsize]' value='$maxsize' > MB</td>";
        }else{
            $options .= "<td style='width:100px'><label><input name='row[{$id}][access][$index1]' value='$index1' type='checkbox' $selectd> $name </label></td>";
        }
        if($i%3==0){
            $options .= '</tr>';
        }
        $i ++ ;
    }
    $options.='</table>';

    $ei = '';
    if($row['icon']){
        $DEL= lang_hs('delshort', 0);
        $ei = <<<HTML
<span class="sp">
     <img style="height:20px;vertical-align:middle" src="{$row['icon']}" />
     <label><input type="checkbox" class="checkbox" name="delimg[$id][icon]" value="1" />$DEL</label>
 </span>
HTML;
    }
    $t = lang_hs('tiao', 0);
    $d = lang_hs('day', 0);
    $y = lang_hs('yuan', 0);
    $z = lang_hs('zhe', 0);
    $n = lang_hs('freeday',0). "n" . lang_hs('freeday1',0);
    $rz  =lang_hs('rzprice', 0);
    $appp  =lang_hs('aprice', 0);
    $apricetip  =lang_hs('apricetip', 0);
    $zhouqi  =lang_hs('zhouqi', 0);
    $zhouqi_tip =lang_hs('zhouqi_tip', 0);
    $zhangqi  =lang_hs('zhangqi', 0);
    $insxf  =lang_hs('insxf', 0);
    $discount  =lang_hs('discount', 0);
    $discount_tip  =lang_hs('discount_tip', 0);
    $dig_price =lang_hs('dig_price', 0);
    $dig_price_tip =lang_hs('dig_price_tip', 0);
    $hy_price =lang_hs('hy_price', 0);
    $hy_price_tip =lang_hs('hy_price_tip', 0);
    $w = '58px';
$tab =<<<HTML
<table class="pztable" style="width:220px">
<tr>
<td>$rz</td>
<td><input style='width:$w' name='row[{$id}][price]' type='text' value='{$row['price']}'/> $y </td>
</tr>
<tr>
<td>$zhouqi</td>
<td><input style='width:$w' name='row[{$id}][days]' type='text' value='{$row['days']}' placeholder="$zhouqi_tip" /> $d </td>
</tr>
<tr>
<td>$zhangqi</td>
<td><input style='width:$w' name='row[{$id}][zhangqi]' type='text' value='{$row['zhangqi']}' /> $d </td>
</tr>
<tr>
<td>$insxf </td>
<td><input style='width:$w' name='row[{$id}][insxf]' type='text' value='{$row['insxf']}' /> %</td>
</tr>
<tr>
<td>$discount</td>
<td><input style='width:$w' name='row[{$id}][discount]' type='text' value='{$row['discount']}' placeholder="$discount_tip" /> $z </td>
</tr>
<tr>
<td>$n</td>
<td><input style='width:$w' name='row[{$id}][freeday]' type='text' value='{$row['freeday']}' /> $t </td>
</tr>
</table>
HTML;
$w = '120px';
$h = '70px';
$kzp = <<<HTML
<table class="pztable" style="width:220px">
<tr>
<td>$appp</td>
<td><input style='width:$w' name='row[{$id}][aprice]' type='text' value='{$row['aprice']}' placeholder="$apricetip"/></td>
</tr>
<tr>
<td>$dig_price</td>
<td><textarea name='row[{$id}][dig_price]' style='width:$w;height:$h' placeholder="$dig_price_tip">{$row['dig_price']}</textarea></td>
</tr>
<tr>
<td>$hy_price</td>
<td><textarea name='row[{$id}][hy_price]' style='width:$w;height:$h' placeholder="$hy_price_tip">{$row['hy_price']}</textarea></td>
</tr></table>
HTML;

    $chk = $row['hide']?'checked':'';
    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='{$id}' />$id",
        "<input style='width:20px' name='row[{$id}][displayorder]' type='text' value='{$row['displayorder']}' />",
        "<div><input style='width:120px' name='row[{$id}][name]' type='text' value='{$row['name']}' /> ". "<label><input type=\"checkbox\" $chk name=\"row[{$id}][hide]\" value=\"1\" />". lang_hs('yc',0).'</label>'.'</div>'.
        "<div style='margin-top:3px'><input style='width:120px' name=\"icon[{$id}]\" type=\"file\" /> $ei</div>".
       '',
        $tab,
        $kzp,
        $options,
        dgmdate($row['crts'], 'u').'<br>'.dgmdate($row['upts'], 'u'),
    ));
}

$addnew = lang_hs('addnew', 0);
echo "<tr><td>&nbsp;</td><td colspan=\"99\"><div><a href=\"javascript:;\" onclick=\"addrow(this, 0)\" class=\"addtr\">$addnew</a></div></td></tr>";
showsubmit('permsubmit', 'submit', 'select_all', '',$multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter();

?>
<script>var rowtypedata = [ [[2,'&nbsp;']
        , [1,'<input name="addrs[{n}][name]" type="text" placeholder="<?php echo lang_hs('vipname', 0);?>" />']
        , [1,'<input name="addrs[{n}][price]" type="text" placeholder="<?php echo lang_hs('rzprice', 0);?>" />']
        , [4,'<input name="addrs[{n}][days]" type="text" placeholder="<?php echo lang_hs('zhouqi', 0);?>"  /> <?php echo lang_hs('day', 0) ?>']
    ] ];</script>