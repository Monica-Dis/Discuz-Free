<?php exit('Author: https://dism.taobao.com/?@xigua 西瓜先生 客服QQ 1628585958'); ?>
<div id="search_popup" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <form  action="$SCRITPTNAME" method="get" id="searchForm">
                <input name="id" value="xigua_hs" type="hidden">
                <input name="ac" value="hangye" type="hidden">
                <input type="hidden" name="st" value="$_GET[st]">
                <input type="hidden" name="idu" value="$_GET[idu]">
                <input type="hidden" name="zoom" value="4">
                <div class="weui-cells__title">{lang xigua_hs:search}</div>
                <div class="weui-cells weui-cells_form"  id="searchBar">

                    <div class="weui-cell weui-cell_vcode">
                        <div class="weui-cell__hd">
                            <label class="weui-label" style="width:auto"><i class="c9 iconfont icon-sousuo vm"></i></label>
                        </div>
                        <div class="weui-cell__bd">
                            <input type="search" class="weui-input" id="searchInput" placeholder="$hs_config[defaultstxt]" required="required" name="keyword">
                        </div>
                        <div class="weui-cell__ft">
                            <button class="weui-vcode-btn" type="submit">{lang xigua_hs:search}</button>
                        </div>
                    </div>
                </div>
            </form>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_default close-popup" >{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
