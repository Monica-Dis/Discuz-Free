<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->

<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <form action="$SCRITPTNAME?id=xigua_hs&ac=cmt&do=add&shid=$shid" method="post" id="form" enctype="multipart/form-data">
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input name="inajax" value="1" type="hidden">
    <div class="weui-cells__title">
        <i class="iconfont icon-coordinates_fill f14 vm"></i>$shdata[addr]
    </div>

    <div class="weui-cells weui-cells_form border_none" style="margin:0 .75rem .75rem;border-radius:.25rem;overflow:hidden">

        <div class="weui-cell">
            <div class="weui-cell__hd">
                <label class="f15 c3">{lang xigua_hs:ddje}({lang xigua_hb:yuan})</label>
            </div>
            <div class="weui-cell__bd">
                <input type="text" class="weui-input tr f14"  placeholder="{lang xigua_hs:qxw}"  name="form[keepmoney]" >
            </div>
        </div>
        <div class="weui-cell none">
            <div class="weui-cell__hd">
                <label class="f15 c3">{lang xigua_hs:bcyhje}({lang xigua_hb:yuan})</label>
            </div>
            <div class="weui-cell__bd">
                <input type="text" class="weui-input tr f14"  placeholder="{lang xigua_hs:qxw}"  name="form[money]" >
            </div>
        </div>
    </div>

    <div class="weui-cell border_none mt0" style="padding-top:0">
        <div class="weui-cell__hd">
            <i class="iconfont icon-bianjixiugai main_color"></i>
        </div>
        <div class="weui-cell__bd">
            <input type="text" class="weui-input f14"  placeholder="{lang xigua_hs:tjbz}"  name="form[note]" >
        </div>
    </div>

    <!--{if $shdata[maidanrate]>0}-->
    <div class="weui-cells__title" style="margin-top:1.25rem">
        <div class="c3">{lang xigua_hs:sjyh}</div>
        <p>{$shdata[maidanrate]}{lang xigua_hs:zhe} <!--{if $shdata[maidanmin]>0}-->({lang xigua_hs:man}{$shdata[maidanmin]}{lang xigua_hb:yuan}{lang xigua_hs:keyong})<!--{/if}--></p>
    </div>
    <!--{/if}-->

    <div style="margin:1.25rem .75rem 0">
        <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hs:yqr}">
    </div>
    </form>
</div>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->