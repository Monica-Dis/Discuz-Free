<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
$job_config = $_G['cache']['plugin']['xigua_job'];
}--><style>.job_li2{position:relative;background:#fff;padding:0.75rem}.job_li2:last-child:before{display:none}.job_top2 h4{font-size:0.8rem;color:#333;line-height:0.9rem;position:relative;display:block}.job2_tagbtn{font-size:0.6rem;padding:0.4rem 0.2rem;border-radius:0.1rem;position:absolute;border:0;line-height:0;margin-left:0.45rem;height:0;top:0.1rem}.job2_tagbtn.y{right:0;float:none}.job_main2{padding:0.75rem 0 0}.job_main2 .job_imglist img{height:3.75rem;width:4.25rem;position:absolute}.job_main2 .job_imglist img:first-child{right:0;top:0;opacity:.3}.job_main2 .job_imglist img:last-child{opacity:1!important}.job_main2 .job_imglist img:nth-child(2){top:0.25rem;left:0}.job_main2 .job_imglist{float:left;position:relative;width:4.5rem;height:4rem}.job_main2 .job_main_lef{width:calc(100vw - 6rem);float:left}.job_main2 .job_main_lef p{margin-bottom:0.5rem;line-height:1rem;height:1rem;overflow:hidden}.job_main2 .job_main_lef p:last-child{margin-bottom:0}.job_btm2 .jv_avatar{border:0;width:1.4rem;height:1.4rem}.job_btm2{margin-top:0.6rem}.job_btm2,.job_li_link{height:1.4rem;line-height:1.4rem}.job_li_link{width:4.25rem;text-align:center;border:0;position:relative;font-size:0.7rem;overflow:hidden;border-radius:0.25rem}.job_li_link:after{position:absolute;content:'';top:0;left:0;box-sizing:border-box;width:199%;height:199%;transform:scale(.5);transform-origin:top left;pointer-events:none;border:0.05rem solid;border-radius:0.5rem;z-index:1}.job_top_side{font-size:0.6rem;color:#999}.job_nav .sx_outer{background:#fff;position:absolute;right:0;width:3.5rem;top:0;height:2.4rem}.job_nav .sx_outer:after{content:" ";position:absolute;left:0;bottom:0;right:0;height:0.05rem;border-bottom:0.05rem solid #e5e5e5;color:#e5e5e5;transform-origin:0 100%;transform:scaleY(.5);z-index:2}.job_nav .sx{position:absolute;right:0.75rem;flex:1;top:0.6rem;z-index:9;color:#333}.job_nav div.weui-banner .weui-navbar__item{color:#333}.job_nav{position:relative}.job_nav .ftb{flex:none}.job_nav .ftb:last-child{margin-right:3rem}</style>
<div class="weui-cells f15 before_none after_none" id="jobbox" style="display:none" >
    <div class="weui-cells__title weui_title mt0 f15" style="padding-bottom:0">
        <i class="iconfont icon-huiyuanqia vm f18 main_color" style="font-size:.95rem"></i> {lang xigua_job:zhaopin}
    </div>
    <div class="joblist mod-post x-postlist p0"></div>
</div>
<script>
$.ajax({type: 'get',
    url: _APPNAME+'?id=xigua_job&ac=job_li&shid={$shid}&inajax=1&page=1&pagesize={$hs_config[zpnum]}', dataType: 'xml',
    success: function (data) {
        if(null==data){ $('#jobbox').remove(); return false;}
        var s = data.lastChild.firstChild.nodeValue;
        if(s){$('.joblist').html(s);$('#jobbox').show();}else{$('#jobbox').remove();}
    },
    error: function () {$('#jobbox').remove();}
});
$(document).on('click', '.jump_job', function () {
    var that = $(this);
    var jmpurl = _APPNAME +'?id=xigua_job&ac=view&jobid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
    if(typeof mag !== 'undefined'){mag.newWin(GSITE+jmpurl);return false;}
    if(typeof wx !=='undefined'){
        if (window.__wxjs_environment === 'miniprogram') {wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});return false;}
    }
    window.location.href = jmpurl;
    return false;
});</script>