<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<style><!--{eval
    $ho_config = $_G['cache']['plugin']['xigua_ho'];
    }-->
.need_list .weui-cell__hd img, .index_shifu li img, .shifu_field .weui-cell__hd img, .shifu_li .weui-cell__hd img {
    border-radius: .4rem;
}
</style>
<div class="weui-cells f15 before_none after_none" id="hobox" style="display:none" >
    <div class="weui-cells__title weui_title mt0 f15" style="padding-bottom:0">
        <i class="iconfont icon-huodongxiangqu1 f18 main_color"></i> {lang xigua_ho:tj}{lang xigua_ho:shifu}
        <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_ho&ac=cat&shid=$shid" >{lang xigua_hs:more}<i class="f13 iconfont icon-jinrujiantou"></i></a>
    </div>
    <ul class="holist mt0" style="padding:0 .5rem"> </ul>
</div>
<script>
    $.ajax({
        type: 'get',
        url: '$SCRITPTNAME?id=xigua_ho&ac=shifu_li&shid=$shid&orderby=jiedannum&inajax=1&page=',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ $('#hobox').remove(); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s){
                $('head').append('<link rel="stylesheet" href="source/plugin/xigua_ho/static/ho.css?{VERHASH}" />');
                $('.holist').html(s);
                $('#hobox').show();

            }else{
                $('#hobox').remove();
            }
        },
        error: function () {$('#hobox').remove();}
    });
    $(document).on('click','.shifu_jump', function () {hb_jump(_APPNAME+"?id=xigua_ho&ac=shifu&shifuid="+$(this).data('shifuid'));});
</script>