<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<li class="dist_check border_bfull"><a href="javascript:;" data-ctid="{$_GET['ctid']}" class="choose color-red">{lang xigua_hs:quan}{$_GET[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a></li>
<!--{loop $rlist $v}-->
<li class="dist_check border_bfull "><a class="choose" href="javascript:;" data-href="{$_GET['datahref']}&province={$_GET[province]}&city={$_GET[name]}&dist={$v[name]}" data-id="$v[id]" data-link="$v[link]">$v[name]</a></li>
<!--{/loop}-->