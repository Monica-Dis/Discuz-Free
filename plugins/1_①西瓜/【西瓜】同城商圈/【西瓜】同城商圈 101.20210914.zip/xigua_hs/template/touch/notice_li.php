<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $list }-->
<!--{loop $list $v}-->
<div class="weui-media-box weui-media-box_text">
    <h4 class="weui-media-box__title">$v[crts_u]</h4>
    <p class="weui-media-box__desc">{echo nl2br(strip_tags($v[content]));}</p>
</div>
<!--{/loop}-->
<!--{/if}-->