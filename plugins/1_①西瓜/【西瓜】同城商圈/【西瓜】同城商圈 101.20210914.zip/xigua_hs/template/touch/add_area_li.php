<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="weui-cell weui-cell_swiped">
    <div class="weui-cell__bd">
        <div class="weui-cell">
            <div class="weui-cell__bd">
                <p>{$v[dist1]} {$v[dist2]}</p>
            </div>
            <div class="weui-cell__ft">{lang xigua_hs:yf}<b class="main_color">{$v[yunfei]}</b>{lang xigua_hs:yuan}</div>
        </div>
    </div>
    <div class="weui-cell__ft">
        <a class="weui-swiped-btn weui-swiped-btn_warn delete-swipeout" data-id="{$v[id]}" href="javascript:">{lang xigua_hs:shanchu}</a>
    </div>
</div>
<!--{/loop}-->