<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<style>.weui-switch:checked {border-color:$config[maincolor];background-color:$config[maincolor]}</style>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div>
        <div class="weui-cells__title">{lang xigua_hs:zitidianguanli}</div>
        <!--{if $list}-->
        <!--{loop $list $k $v}-->
        <div class="weui-form-preview <!--{if $k>0}-->mt10<!--{/if}-->" id="li_{$v[id]}">
            <div class="weui-form-preview__bd">
                <div class="weui-form-preview__item tl">
                    <span class="f24 c6">{$v[realname]} <em class="f15 main_color">{$v[mobile]}</em>
                    <!--{if $v[dft]}--><em class="f15 y c9">{lang xigua_hb:dft}</em><!--{/if}-->
                    </span>
                    <span class="weui-form-preview__value f15">{$v[dist1]}{$v[dist2]}{$v[dist3]} {$v[address]}</span>
                </div>
            </div>
            <div class="weui-form-preview__ft">
                <a class="weui-form-preview__btn weui-form-preview__btn_default f17" onclick="return confirm_del('{lang xigua_hb:delconfirm}', '$SCRITPTNAME?id=xigua_hs&ac=myaddr&do=del&formhash={FORMHASH}&delid={$v[id]}', '{$v[id]}');" href="javascript:">{lang xigua_hb:dodel}</a>
                <button type="submit" class="weui-form-preview__btn weui-form-preview__btn_primary f17" href="javascript:" onclick="return full_input(this);" data-dft="$v[dft]" data-oldid="$v[id]" data-realname="$v[realname]" data-mobile="$v[mobile]" data-address="$v[address]" data-dist="{$v[dist1]} {$v[dist2]} {$v[dist3]}" data-postcode="$v[postcode]" data-lat="$v[lat]" data-lng="$v[lng]">{lang xigua_hb:xiugai}</button>
            </div>
        </div>
        <!--{/loop}-->
        <!--{else}-->
        <!--{template xigua_hb:loading}-->
        <script>
            $('#loading-show').addClass('hidden');
            $('#loading-none').removeClass('hidden');
        </script>
        <!--{/if}-->
    </div>

    <div class="footer_fix"></div>
    <div class="bottom_fix"></div>
    <div class="fix-bottom">
        <a class="weui-btn weui-btn_primary" data-dft="1" onclick="return full_input(this);">{lang xigua_hb:newaddr}</a>
    </div>
</div>

<div id="new_popup" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <form  action="$SCRITPTNAME?id=xigua_hs&ac=myaddr&do=add" method="post" id="form">
        <div class="fixpopuper">
                <input name="formhash" value="{FORMHASH}" type="hidden">
                <input name="form[oldid]" value="0" type="hidden">
                <input name="form[shid]" value="$shid" type="hidden">
                <input type="hidden" name="form[lat]" value="">
                <input type="hidden" name="form[lng]" value="">

                <div class="weui-cells__title">{lang xigua_hs:plzrelinfo}</div>
                <div class="weui-cells weui-cells_form">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hb:xm}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[realname]" placeholder="{lang xigua_hb:plzxm}">
                        </div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hb:mobile}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="tel" name="form[mobile]" placeholder="{lang xigua_hb:mobile_tip}" value="">
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hb:dist}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" id="dist" name="form[dist]" type="text" placeholder="{lang xigua_hb:plzdist}" value="">
                        </div>
                    </div>
                    <div class="weui-cell weui-cell_vcode">
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[address]" placeholder="{lang xigua_hb:plzxxdz}" value="">
                        </div>
                        <div class="weui-cell__ft">
                            <button class="weui-vcode-btn" id="openlocation" type="button">{lang xigua_hs:dingwei}</button>
                        </div>
                    </div>
                </div>

            <div class="fix-bottom" style="position: relative;margin-top:.5rem">
                <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}" />
                <a class="weui-btn weui-btn_default close-popup" >{lang xigua_hb:quxiao}</a>
            </div>
        </div>
        </form>
    </div>
</div>

<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer" style="position:absolute;width:100%;bottom:2.75rem;height:calc(100vh - 2.75rem)"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup popupL" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.min.js" charset="utf-8"></script>
<script>$("#dist").cityPicker({ title: "{lang xigua_hb:plzdist}" });
function full_input(ob){
    var fd = ['oldid','realname','mobile','dist', 'address', 'lat', 'lng'];
    for(var i in fd){
        var h = $(ob).data(fd[i]);
        if(typeof h === 'undefined' || h === 0){
            h = '';
        }
        $('[name="form['+fd[i]+']"]').val(h+'');
    }
    if($(ob).data('dft')){
        $('[name="form[dft]"]').prop("checked",true);
    }else{
        $('[name="form[dft]"]').prop("checked",false);
    }
    $('#new_popup').popup();
    setTimeout(function () {
        $('#new_popup').show();
    }, 500);
    return false;
}
function update_addr(url){
    $.showLoading();
    $.ajax({
        type: 'post',
        url: url+_URLEXT,
        data: {'formhash' :FORMHASH},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            var msgar = tip_common(s);
        },
        error: function () {
            $.hideLoading();
        }
    });
}
</script>
<!--{eval $tabbar=0;}-->

<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$hs_config[mkey]}"></script>
<!--{if $_G['cache']['plugin']['xigua_hs']['baidusdk']}--><script type="text/javascript" src="http://api.map.baidu.com/api?v=2.0&ak={$_G['cache']['plugin']['xigua_hs']['baidusdk']}"></script><!--{/if}-->
<script>
    var chooseMapRes = [], OBJ = {};
    function setForm(lat, lng, deft){
        $.showLoading();
        $.ajax({
            type: 'get',
            url: location + '&ac=getloc&lat='+lat+'&lng='+lng+'&inajax=1',
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('error')!=-1){
                    tip_common(s);
                }else{
                    var _actions = [];
                    OBJ = jQuery.parseJSON(s.split('|')[1]);
                    if(deft){
                        setFormField(OBJ[0]);
                        return true;
                    }
                    for(var j in OBJ){
                        _actions.push({
                            text: OBJ[j].address,
                            className:'obj_ obj_'+j,
                            onClick: function() {
                                $.closePopup();
                                $('#new_popup').popup();
                                setTimeout(function () {
                                    $('#new_popup').show();
                                }, 500);
                            }
                        });
                    }
                    $.actions({ actions:_actions });
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    }
    function setFormField(subj){
        $("input[name='form[address]']").val(subj.address);
        $("input[name='form[lat]']").val(subj.location.lat);
        $("input[name='form[lng]']").val(subj.location.lng);
    }

    function setPoint(position){
        if(typeof position.type != 'undefined'){
            if(position.type == 'ip'){
                if(IGNORETIP){}else{
                    $.alert('{lang xigua_hs:locaerror}');
                    chooseMap(position);
                }
                return false;
            }
        }
        setForm((position.latitude||position.lat), (position.longitude||position.lng), 1);
    }
    function chooseMap(position) {
        if(typeof mag != 'undefined') {
            mag.mapPick(function (res) {
                setForm(res.lat, res.lng, 0);
            });
            return false;
        }
        <!--{if !$_G['cache']['plugin']['xigua_hs']['baidusdk']}-->
        var center = new qq.maps.LatLng((position.latitude||position.lat), (position.longitude||position.lng));
        var mapinit = function () {
            geocoder = new qq.maps.Geocoder({
                complete: function (result) {
                    chooseMapRes = result;
                }
            });
            geocoder.getAddress(center);
            map = new qq.maps.Map(document.getElementById("mapcontainer"), {center: center, zoom: 13});
            marker = new qq.maps.Marker({
                position: center, map: map
            });
            qq.maps.event.addListener(map, 'click', function (event) {
                var tmpcenter = new qq.maps.LatLng(event.latLng.getLat(), event.latLng.getLng());
                marker.setPosition(tmpcenter);
                geocoder.getAddress(tmpcenter);
            });
            $("#mapouter").popup();
        };
        mapinit();
        <!--{else}-->
        var map = new BMap.Map("mapcontainer");
        var geoc = new BMap.Geocoder();
        var point = new BMap.Point((position.longitude||position.lng), (position.latitude||position.lat));
        map.centerAndZoom(point, 15);
        var marker = new BMap.Marker(point);
        map.addOverlay(marker);

        map.addControl(new BMap.MapTypeControl());
        map.addControl(new BMap.NavigationControl());

        map.addEventListener("click", function (e){
            var marker = new BMap.Marker(new BMap.Point(e.point.lng, e.point.lat));
            map.addOverlay(marker);
            var pt = e.point;
            geoc.getLocation(pt, function(rs){
                var addComp = rs.addressComponents;
                $("input[name='form[address]']").val(addComp.street+addComp.streetNumber);
                $("input[name='form[lat]']").val(e.point.lat);
                $("input[name='form[lng]']").val(e.point.lng);
                $.closePopup();
                $('#new_popup').popup();
                setTimeout(function () {
                    $('#new_popup').show();
                }, 500);
            });
        });
        $("#mapouter").popup();
        <!--{/if}-->
    }

    $(document).on('click', '.obj_', function(){
        var k = parseInt($(this)[0].classList[2].replace('obj_', ''));
        setFormField(OBJ[k]);
    });
    var IGNORETIP = 0;
    $('#openlocation').on('click', function(){
        var pot = [];
        IGNORETIP = 0;
        pot.push({ text: "{lang xigua_hs:locacurrt}", onClick: function() { hs_getlocation(setPoint); } });
        if(!(GOOGLE && HB_INWECHAT)){
            pot.push({text: "{lang xigua_hs:xuandian}", onClick: function() { hs_getlocation(chooseMap); } });
        }
        $.actions({ actions: pot});
    });
    <!--{if !$_G['cache']['plugin']['xigua_hs']['baidusdk']}-->
    $('.confirm-popup').on('click', function(){
        setForm(chooseMapRes.detail.location.lat, chooseMapRes.detail.location.lng, 0);
    });
    <!--{/if}-->
</script>
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->