<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval $desc = cutstr(strip_tags($shdata['xuanchuan'] ? $shdata['xuanchuan'] :($gonggao[0] ? $gonggao[0]['content'] : $shdata['jieshao'])),80);;}-->
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<div class="page__bd">
    <!--{eval $back_to_overwrite="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$shdata[shid]$urlext";}-->
    <!--{template xigua_hb:common_nav}-->
    <div class="album_list">
        <!--{loop $shdata[album] $v}-->
        <a href="javascript:;" class="album_img imgloading">
            <img src="$v">
        </a>
        <!--{/loop}-->
    </div>
</div>
<!--{eval $tabbar=0;$hs_tabbar=1;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->