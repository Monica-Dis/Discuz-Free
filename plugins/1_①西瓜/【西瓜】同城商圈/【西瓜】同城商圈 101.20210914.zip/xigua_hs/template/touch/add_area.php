<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<div class="page__bd ">
<!--{eval $dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
$projson = array();
if($dist0):
    foreach($dist0 as $pro ):
        $projson[] =  $pro['name'];
    endforeach;
endif;
$projson[] = lang_hs('qtdq',0);
}--><!--{template xigua_hb:common_nav}-->
    <div class="weui-cells__title">{lang xigua_hs:qypszh}</div>
    <div class="weui-cells">
        <div id="list" class="mod-post x-postlist p0">
        </div>
    </div>
    <!--{template xigua_hb:loading}-->
    <div class="bottom_fix"></div>
    <div class="fix-bottom weui-flex">
        <a class="weui-btn weui-btn_primary half dftpsf0" href="javascript:;">{lang xigua_hs:xzpsqy}</a>
        <a class="weui-btn weui-btn_default half mt0 dftpsf" href="javascript:;">{lang xigua_hs:morpsf}</a>
    </div>

</div>
<div id="add_ctrl" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hs:qx}</a>
                <h1 class="title">{lang xigua_hs:xzpsqy}</h1>
            </div>
        </div>
        <div class="modal-content">
            <form action="$SCRITPTNAME?id=xigua_hs&ac=add_area" method="post" id="form" enctype="multipart/form-data">
                <input type="hidden" name="formhash" value="{FORMHASH}">
                <div class="weui-cells before_none after_none">
                    <div class="weui-cell" id="ares">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hs:szdq}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" id="start" name="form[dist]" type="text" value="" placeholder="{lang xigua_hs:qszdq}">
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hs:yf}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[yunfei]" placeholder="{lang xigua_hs:qtxyf}" value="">
                        </div>
                        <div class="well-cell__ft">{lang xigua_hs:yuan}</div>
                    </div>
                    <div class="fix-bottom" style="position:relative">
                        <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hs:queding}">
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script>var loadingurl = window.location.href+'&ac=add_area_li&is_my=1&inajax=1&page=';</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.min.js" charset="utf-8"></script>
<script>
    var loadingCallback = function () {
        $('.weui-cell_swiped').swipeout();
    };
    /*$("#start").cityPicker({
        title: "{lang xigua_pt:xzqy}",
        showDistrict: false,
        onChange: function (picker, values, displayValues) {
            console.log(values, displayValues);
        }
    });*/
    <!--{if $hs_config[psfsms]==1}-->
    $("#start").picker({
        title: "{lang xigua_hs:xzqy}",
        cols: [
            {
            textAlign: 'center',
            values: ['<!--{eval echo implode('\',\'', $projson)}-->']
            }
    ]
    });
    <!--{elseif  $hs_config[psfsms]==2}-->
    $("#start").cityPicker({ title: "{lang xigua_hs:xzqy}" });
    <!--{elseif  $hs_config[psfsms]==3}-->
    $("#start").cityPicker({ showDistrict: false, title: "{lang xigua_hs:xzqy}" });
    <!--{/if}-->
    $(document).on('click','.delete-swipeout', function () {
        var yfid = $(this).data('id');
        $.confirm({
            title: '{lang xigua_hs:sfsc}',
            onOK: function () {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_hs&ac=add_area&yfid=' +yfid+ '&inajax=1',
                    data:{formhash:FORMHASH },
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });
    });
    $(document).on('click','.dftpsf0', function () {
        $('#ares').show();
        $('#start').val('');
        $('#add_ctrl').popup();
    });
    $(document).on('click','.dftpsf', function () {
        $('#ares').hide();
        $('#start').val('{lang xigua_hs:qtdq}');
        $('#add_ctrl').popup();
    });
</script>