<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<a href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]{$urlext}" class="weui-cell bgf">
    <div class="weui-cell__hd" style="position: relative;margin-right:.5rem">
        <img src="{avatar($v[uid], 'big', true)}" style="width:1.5rem;height:1.5rem;margin-right:.25rem;display:block;border-radius:50%" />
    </div>
    <div class="weui-cell__bd">
        <p>$users[$v[uid]][username]</p>
    </div>
    <div class="weui-cell__ft">
        $v[crts_u]
    </div>
</a>
<!--{/loop}-->
