<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->

    <div class="weui-cells">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hs&ac=myshop{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-shopfill color-red f18"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hs:dianpu}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
    </div>

<!--{if $_G['cache']['plugin']['xigua_hd']}-->
    <div class="weui-cells">

        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hd&ac=my_evt{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-kanjia color-forest"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hd:jjhd}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>

        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=manage{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-qianggou color-orange"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hd:gldd}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hd&ac=scan&back=manage{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-yongjin2 color-red"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hs:jjhx}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
    </div>
<!--{/if}-->

<!--{if $_G['cache']['plugin']['xigua_hm']}-->
    <div class="weui-cells">

        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-qianggou color-red"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hs:qggl}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>

        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=quan{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-icozhekouquan color-red"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hs:kqgl}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>

        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-dingdan color-vimeo"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hs:ddgl}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>

        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hm&ac=inqr{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-saoma color-forest"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hs:hhrk}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hm&ac=income{$urlext}">
            <div class="weui-cell__hd"><i class="iconfont icon-yongjin color-twitter"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hm:rzjl}</p>
            </div>
            <div class="weui-cell__ft"></div>
        </a>
    </div>
<!--{/if}-->
</div>

<!--{eval $tabbar=1;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->
<script>
    $(document).on('click','.sidectrl', function () {
        <!--{if IN_MAGAPP}-->mag.scanQR(function(text){window.location.href=text});
        <!--{elseif IN_QIANFAN}-->qianfanScan();
        <!--{elseif IN_APPBYME}-->appbymeScan();
        <!--{else}-->wx.scanQRCode();<!--{/if}-->
    });
    function appbymeScan() {
        sq.scan(function(result){
            window.location.href=result.url;
        });
    }
    function qianfanScan(){
        QFH5.jumpScan(function(state,data){
            if(state==1){
                window.location.href=data.content;
            }else{
            }
        })
    }
</script>