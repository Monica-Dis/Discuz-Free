<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="list" class="mod-post x-postlist pt0 <!--{if $_G['cache']['plugin']['xigua_dp'] && $hs_config[indexorder]=='dp' && $hs_config[showdp]}-->dp_index<!--{/if}-->"></div>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script>
var lochrf = window.location.href.indexOf('?')===-1 ? window.location.href+'?' :window.location.href;
if(lochrf.indexOf('/?')!==-1){
    lochrf ='plugin.php?id=xigua_hs&st={$_GET[st]}'
}
<!--{if $hs_config[indexorder]=='newin'}-->
loadingurl = lochrf+'&st={$_GET[st]}&ac=myshop_li&viewtype=new&inajax=1&page=';
<!--{elseif $hs_config[indexorder]=='near'}-->
var neednear =lochrf+'&st={$_GET[st]}&ac=myshop_li&viewtype=near&inajax=1&page=';
<!--{elseif $_G['cache']['plugin']['xigua_dp'] && $hs_config[indexorder]=='dp' && $hs_config[showdp]}-->
var loadingurl =lochrf+'&st={$_GET[st]}&id=xigua_dp&ac=dp_li&inajax=1&page=';
<!--{else}-->
loadingurl = lochrf+'&st={$_GET[st]}&ac=myshop_li&inajax=1&page=';
<!--{/if}-->
scrollto = 1;var lockIng = 0, lngold=0,latold=0;$(document).on('click','.listcat', function () {lm=0;var that = $(this);if(that.data('needgeo')){if(lockIng) return;lockIng = 1;setTimeout(function () {lockIng = 0;}, 100);if(lngold){hs_setlist(that, '&lat='+latold+'&lng='+lngold);}else{hs_getlocation(function (position) {latold=(position.latitude||position.lat);lngold=(position.longitude||position.lng);hs_setlist(that, '&lat='+latold+'&lng='+lngold);});}}else{hs_setlist(that, '');}});function hs_setlist(that, ext){page = 1;var dq = that.data('query');var lst = $("#list");loadingurl = lochrf+'&ac=myshop_li&'+that.data('query')+ext+'&inajax=1&page=';that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
DOAPPEND = 0;$.ajax({type: 'get',url: loadingurl+''+page,dataType: 'xml',success: function (data) {if(null==data){ tip_common('error|'+ERROR_TIP); return false;}if(dq=='id=xigua_dp&ac=dp_li'){lst.addClass('dp_index');}else{lst.removeClass('dp_index');}
var s = data.lastChild.firstChild.nodeValue;$('#loading-show').addClass('hidden');if(!s){$('#loading-show').addClass('hidden');$('#loading-none').removeClass('hidden');setTimeout(function () {$('#loading-show').addClass('hidden');
$('#loading-none').removeClass('hidden');}, 300);lst.html(s);page = -1;return ;}lst.html(s);page ++;},error: function() {}});}</script>
<!--{template xigua_hb:loading}-->
