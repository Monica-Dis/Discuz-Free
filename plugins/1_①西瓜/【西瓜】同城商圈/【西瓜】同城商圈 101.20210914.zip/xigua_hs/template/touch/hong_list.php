<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{eval $no_header_fix=1;}-->
<!--{eval $hidenav=1;}-->
<style>
.hong_res{position: relative}
.footer_fix{display:none}
</style>
<div class="page__bd hong">


    <!--{template xigua_hb:common_nav}-->
    <div class="hong_res animated zoomIn" style="display:block">
        <div class="hong_res_wrap">
            <div class="hong_res_head">
                <div class="hong_res_head_in">
                    <img src="{avatar($v['uid'], 'big', true)}">
                </div>
            </div>
            <div class="hong_res_cnt">
                <div class="hong_res_box">
                    <p>$v[user][username]</p>
                    <p>{lang xigua_hb:mai}</p>
                </div>

                <div class="hong_list_outer" style="display: block">
                    <div class="hong_list_h weui-flex">
                        <span></span>
                        <p class="weui-flex__item tit js-cnt">{lang xigua_hb:gong}<span id="total">$v[hong_num]</span>{lang xigua_hb:mai1}<span id="sendnum">$v[hong_sendnum]</span>{lang xigua_hb:mai2}<span id="over">{eval echo $v[hong_num]-$v[hong_sendnum];}</span>{lang xigua_hb:fen}</p>
                        <span></span>
                    </div>
                    <div class="hong_list" id="hong_list">

                    </div>
                </div>



            </div>
            <div class="sub_bg"></div>
        </div>
    </div>

</div>

<!--{template xigua_hb:common_footer}-->
<script>

    var loadingurl = window.location.href+'&ac=hong_li&inajax=1&page=';
    $(document.body).infinite().on("infinite", function() {
        if(loading) return;
        loading = true;
        load_morehong();
    });
    load_morehong();

    function load_morehong(){
        if(page<=0){
            return ;
        }
        $.ajax({
            type: 'GET',
            url: loadingurl+''+page,
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(!s){
                    page = -1;
                    return ;
                }
                $("#hong_list").append(s);
                loading = false;
                console.log(page);
                page ++;
            },
            error: function() {
                loading = false;
            }
        });
    }
</script>