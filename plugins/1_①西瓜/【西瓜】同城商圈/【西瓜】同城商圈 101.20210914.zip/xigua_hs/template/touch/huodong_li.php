<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<style><!--{eval
    $he_config = $_G['cache']['plugin']['xigua_he'];
}-->.main_color2{color:{$he_config[mainc2]}!important}
.jxuan{background-color:{$he_config[mainc2]}}.index_re_List:last-child:before{display:none}
.index_re_List_tip{border-color:$he_config[mainc2];color:$he_config[mainc2];background-color:{$he_config[mainc2]}21}
</style>
<div class="weui-cells f15 before_none after_none" id="hebox" style="display:none" >
    <div class="weui-cells__title weui_title mt0 f15" style="padding-bottom:0">
        <i class="iconfont icon-huodongxiangqu1 f18 main_color"></i> {lang xigua_hs:dphd}
        <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_he&ac=shop&shid=$shid{$urlext}" >{lang xigua_hs:more}<i class="f13 iconfont icon-jinrujiantou"></i></a>
    </div>
    <ul class="helist mt0" style="padding:0 .5rem"> </ul>
</div>
<script>
    $.ajax({
        type: 'get',
        url: _APPNAME+'?id=xigua_he&ac=he_li&shid={$shid}&inajax=1&page=1&pagesize={$hs_config[huod_num]}',
        dataType: 'xml',
        success: function (data) {
            if(null==data){ $('#hebox').remove(); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s){
                $('head').append('<link rel="stylesheet" href="source/plugin/xigua_he/static/he.css?{VERHASH}" />');
                $('.helist').html(s);
                $('#hebox').show();
                $(document).on('click', '.jump_he', function () {
                    var that = $(this);
                    var jmpurl = _APPNAME +'?id=xigua_he&ac=view&hid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
                    if(typeof mag !== 'undefined'){
                        mag.newWin(GSITE+jmpurl);
                        return false;
                    }
                    if(typeof wx !=='undefined'){
                        if (window.__wxjs_environment === 'miniprogram') {
                            wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
                            return false;
                        }
                    }
                    window.location.href = jmpurl;
                    return false;
                });
            }else{
                $('#hebox').remove();
            }
        },
        error: function () {$('#hebox').remove();}
    });
</script>