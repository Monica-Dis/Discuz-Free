<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="pay_ctrl" style="z-index:999" class="weui-popup__container popup-bottom">
<form  action="$SCRITPTNAME?id=xigua_hs&ac=help&do=fuk&st={$_GET['st']}" method="post" id="form">
    <input name="formhash" value="{FORMHASH}" type="hidden">
    <input name="inajax" value="1" type="hidden">
    <input name="shid" value="{$v[shid]}" type="hidden">

    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hb:quxiao}</a>
                <h1 class="title">{lang xigua_hs:x}{$v[name]}{lang xigua_hs:fk}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hs:fkje}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="money" type="text" placeholder="{lang xigua_hs:qtxfkje}">
                    </div>
                </div>
                <div class="weui-cell f14">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hs:zfbz}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="note" type="text" placeholder="{lang xigua_hs:qtxfkbz}">
                    </div>
                </div>
            </div>

            <div class="fix-bottom" style="position: relative">
                <input type="submit" id="dosubmit" href="javascript:;" class="weui-btn weui-btn_primary" value="{lang xigua_hs:queding}">
            </div>
        </div>
    </div>
    </form>
</div>
