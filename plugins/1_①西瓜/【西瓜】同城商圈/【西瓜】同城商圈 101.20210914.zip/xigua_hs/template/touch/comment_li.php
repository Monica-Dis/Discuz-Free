<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $comments $comment}--><a href="javascript:void(0);" class="weui-media-box weui-media-box_appmsg cmt_sh bgf" data-cmtid="<!--{if in_array('cmtt', $vipinfo['access'])||IS_ADMINID}-->{$comment[cid]}<!--{else}-->0<!--{/if}-->" data-shid="$comment[shid]" data-authorid="$comment[authorid]" data-author="$comment[author]">
    <div class="weui-media-box__hd hs_cmt_var">
        <img class="weui-media-box__thumb" src="{avatar($comment['authorid'], 'big', true)}">
    </div>
    <div class="weui-media-box__bd hs_cmt_cnt">
        <h4 class="weui-media-box__title">
            <!--{if $comment[touser]}--> <span>$comment[author] </span> {lang xigua_hb:huifu}
            <span>$comment[touser] :</span> <!--{else}--> <span>$comment[author]: </span> <!--{/if}-->
            <span class="y f13 c9">$comment[crts]</span>
        </h4>
        <p class="weui-media-box__desc">{$comment[comment]}</p>
        <!--{eval $cmtimglist = $comment[imglist] ? unserialize($comment[imglist]) : array();}-->
        <!--{if $cmtimglist}-->
        <div class="cmt_imglist cl">
        <!--{loop $cmtimglist $_v}-->
            <span class="imgloading cl z"><img src="{$_v}" /></span>
        <!--{/loop}-->
        </div>
        <!--{/if}-->
    </div>
</a><!--{/loop}-->