<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<div class="page__bd sh_center_bd">
    <!--{template xigua_hb:common_nav}-->

    <div class="main_bg weui-cell before_none sh_center">
        <a href="javascript:;" onclick="jumpmanagesh($sh[shid]);return false;" class="more_sh">{lang xigua_hs:moremanage}<i class="iconfont icon-jinrujiantou f12 vm"></i></a>

        <div class="weui-cell__hd">
            <a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]{$urlext}"><img src="{$sh[logo]}" class="sh_center_logo"></a>
        </div>
        <div class="weui-cell__bd">
            <p class="f16"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]{$urlext}">{$sh[name]}</a>
                <a class="ml3" href="$SCRITPTNAME?id=xigua_hs&ac=enter&edit=$sh[shid]{$urlext}"><i class="iconfont icon-bianji f14"></i></a></p>
            <p class="f12"><!--{if 0==$sh[endts]}-->{lang xigua_hs:weizhifu}<!--{elseif !$sh[display]}-->{lang xigua_hs:daishen}<!--{else}--><b>{$vips[$sh[viptype]][name]}</b> <!--{if $vips[$sh[viptype]][days]!='9999'}-->{$sh[endts_u]}{lang xigua_hs:guoqi}<!--{else}-->{lang xigua_hs:yjsx}<!--{/if}--><!--{/if}--></p>
            <p class="f12">
                <!--{if $list[1]}--><a href="javascript:;" id="qiehuan">{lang xigua_hs:djqh}<i class="iconfont icon-jinrujiantou f12 vm"></i></a>
                <!--{else}-->
                <a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$sh[shid]{$urlext}">{lang xigua_hs:cksj}<i class="iconfont icon-jinrujiantou f12 vm"></i></a>
                <!--{/if}-->
            </p>
        </div>
    </div>

    <div class="weui-cells f15 before_none after_none ">
        <div class="weui-cells__title weui_title mt0 f15 bold">{lang xigua_hs:jysj}
        </div>
        <div class="weui-grids">
            <a href="javascript:;" class="weui-grid">
                <p class="weui-grid__label">{lang xigua_hs:dpll}</p>
                <p class="weui-grid__label  mt8 main_color f20">{$sh[views]}</p>
            </a>
            <a href="javascript:;" class="weui-grid">
                <p class="weui-grid__label">{lang xigua_hs:fss}</p>
                <p class="weui-grid__label  mt8 main_color f20">{$sh[follow]}</p>
            </a>
            <a href="javascript:;" class="weui-grid">
                <p class="weui-grid__label">{lang xigua_hs:fxs}</p>
                <p class="weui-grid__label  mt8 main_color f20">{$sh[shares]}</p>
            </a>
        </div>
    </div>

    <div class="weui-cells f15 before_none after_none ">
        <div class="weui-cells__title weui_title mt0 f15 bold">{lang xigua_hs:sjgj}
            <a class="y c9 pr_1" href="javascript:;" onclick="jumpmanagesh($sh[shid]);return false;">{lang xigua_hs:more}<i class="f13 iconfont icon-jinrujiantou"></i></a>
        </div>
        <div class="weui-grids">
            <!--{if in_array('ztd', $vips[$sh[viptype]][access])}-->
            <a href="$SCRITPTNAME?id=xigua_hs&ac=myaddr&shid=$sh[shid]{$urlext}" class="weui-grid" style="width:25%">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-index color-orange f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:szztd}</p>
            </a>
            <!--{/if}-->
            <a href="$SCRITPTNAME?id=xigua_hs&ac=add_area{$urlext}" class="weui-grid" style="width:25%">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-mudedi color-red f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:psfsgl}</p>
            </a>
            <!--{if in_array('zxsk', $vips[$sh[viptype]][access])}-->
            <a href="$SCRITPTNAME?id=xigua_hs&ac=help&do=fukuan&manage=1&shid=$sh[shid]{$urlext}" class="weui-grid" style="width:25%">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-yongjin1 color-good" style="font-size:1.05rem"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:skjl}</p>
            </a>
            <!--{/if}-->
            <!--{if in_array('dianyuan', $vips[$sh[viptype]][access])}-->
            <a href="$SCRITPTNAME?id=xigua_hs&ac=dianyuan&shid=$sh[shid]{$urlext}" class="weui-grid" style="width:25%">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-jieban color-green f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:ac_dianyuan}</p>
            </a>
            <!--{/if}-->
            <!--{if in_array('gonggao', $vips[$sh[viptype]][access])}-->
            <a href="javascript:;" class="weui-grid pubgg" style="width:25%">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-tongzhi color-paypal f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:fabugonggao}</p>
            </a>
            <!--{/if}-->
            <a href="javascript:;" class="weui-grid xufei" style="width:25%">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-shoplight color-red2 f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:xufei}</p>
            </a>
            <a href="javascript:;" class="weui-grid dodiger" style="width:25%">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-huidaodingbu color-pinterest f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:zhidingdianpu}</p>
            </a>
            <!--{if $_G['cache']['plugin']['xigua_he'] && in_array('huodong', $vips[$sh[viptype]][access])}-->
            <a href="$SCRITPTNAME?id=xigua_he&ac=wode&view=zbf{$urlext}" class="weui-grid" style="width:25%">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-huodongxiangqu1  color-orange f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:hdzx}</p>
            </a>
            <!--{/if}-->
        </div>
    </div>


    <!--{if $_G['cache']['plugin']['xigua_sp'] && in_array('tcsp', $vips[$sh[viptype]][access])}-->
    <!--{if !$is_dianyuan}-->
    <div class="weui-cells f15 before_none after_none">
        <div class="weui-cells__title weui_title mt0 f15 bold">{lang xigua_sp:sc}

            <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_sp&ac=wode{$urlext}">{lang xigua_sp:gd}<i class="f13 iconfont icon-jinrujiantou"></i></a>
        </div>
        <div class="weui-grids">
            <a href="$SCRITPTNAME?id=xigua_sp&ac=manage&mobile=2{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-gouwuche color-red f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_sp:spgl1}</p>
            </a>
            <a  href="$SCRITPTNAME?id=xigua_sp&ac=order_manage{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-gengduo3 color-orange f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_sp:ddgl1}</p>
            </a>
            <a  href="$SCRITPTNAME?id=xigua_sp&ac=shop&shid={$sh[shid]}{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-dianpu color-good f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_sp:dpsy}</p>
            </a>
        </div>
    </div>
    <!--{/if}-->
    <!--{/if}-->



    <!--{if $_G['cache']['plugin']['xigua_hd'] && in_array('jianjia', $vips[$sh[viptype]][access])}-->
    <div class="weui-cells f15 before_none after_none">
        <div class="weui-cells__title weui_title mt0 f15 bold">{lang xigua_hd:jjgl}</div>
        <div class="weui-grids">
            <!--{if !$is_dianyuan}-->
            <!--{eval $gwidth=' style="width:33.3333%"';}-->
            <a href="$SCRITPTNAME?id=xigua_hd&ac=my_evt{$urlext}" class="weui-grid"$gwidth>
                <div class="weui-grid__icon">
                    <i class="iconfont icon-kanjia color-green f24"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hd:jjhd}</p>
            </a>
            <a  href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=manage{$urlext}" class="weui-grid"$gwidth>
                <div class="weui-grid__icon">
                    <i class="iconfont icon-qianggou color-orange f24"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hd:gldd}</p>
            </a>
            <!--{/if}-->
            <a href="$SCRITPTNAME?id=xigua_hd&ac=scan&back=manage{$urlext}" class="weui-grid"$gwidth>
                <div class="weui-grid__icon">
                    <i class="iconfont icon-duigou1 color-red f24"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:jjhx}</p>
            </a>
        </div>
    </div>
    <!--{/if}-->


    <!--{if $_G['cache']['plugin']['xigua_hm'] && in_array('youhui', $vips[$sh[viptype]][access])}-->
    <div class="weui-cells f15 before_none after_none">
        <div class="weui-cells__title weui_title mt0 f15 bold">{lang xigua_hs:qggl}</div>
        <div class="weui-grids">
            <!--{if !$is_dianyuan}-->
            <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-qianggou color-red f24"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:qggl}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=quan{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-icozhekouquan color-red f24"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:kqgl}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hm&ac=my_order&do=manage{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-ranking color-vimeo f24"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:ddgl}</p>
            </a>
            <!--{/if}-->
            <a href="$SCRITPTNAME?id=xigua_hm&ac=inqr{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-hexiao color-green f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:hhrk}</p>
            </a>
            <!--{if !$is_dianyuan}-->
            <a href="$SCRITPTNAME?id=xigua_hm&ac=income{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-yongjin2 color-dribbble f24"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hm:rzjl}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hm&mobile=2{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-juqianggou color-paypal f24"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hs:qgsy}</p>
            </a>
            <!--{/if}-->
        </div>
    </div>
    <!--{/if}-->


    <!--{if $_G['cache']['plugin']['xigua_hk'] && in_array('heika', $vips[$sh[viptype]][access])}-->
    <!--{if !$is_dianyuan}-->
    <div class="weui-cells f15 before_none after_none">
        <div class="weui-cells__title weui_title mt0 f15 bold">{eval echo str_replace(lang('plugin/xigua_hk', 'heika'), $_G['cache']['plugin']['xigua_hk']['cardname'], lang('plugin/xigua_hk', 'heikaguanli'));}</div>
        <div class="weui-grids">
            <a href="$SCRITPTNAME?id=xigua_hk&ac=add&mobile=2{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-huiyuan2 color-red2 f26"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_hk:tjsp}</p>
            </a>
            <a  href="$SCRITPTNAME?id=xigua_hk&ac=manage&mobile=2&is_my=1{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-zhekou1 color-good f22"></i>
                </div>
                <p class="weui-grid__label">{eval echo str_replace(lang('plugin/xigua_hk', 'heika'), $_G['cache']['plugin']['xigua_hk']['cardname'], lang('plugin/xigua_hk', 'fabuguanli'));}</p>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hk&mobile=2{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-SKJYCSTJ color-google f24"></i>
                </div>
                <p class="weui-grid__label">{eval echo str_replace(lang('plugin/xigua_hk', 'heika'), $_G['cache']['plugin']['xigua_hk']['cardname'], lang('plugin/xigua_hk', 'hksy'));}</p>
            </a>
        </div>
    </div>
    <!--{/if}-->
    <!--{/if}-->




    <!--{if $_G['cache']['plugin']['xigua_pt'] && in_array('pt', $vips[$sh[viptype]][access])}-->
    <!--{if !$is_dianyuan}-->
    <div class="weui-cells f15 before_none after_none">
        <div class="weui-cells__title weui_title mt0 f15 bold">{lang xigua_pt:ptgl}</div>
        <div class="weui-grids">
            <a href="$SCRITPTNAME?id=xigua_pt&ac=manage&mobile=2{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-fenlei color-red2 f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_pt:spgl1}</p>
            </a>
            <a  href="$SCRITPTNAME?id=xigua_pt&ac=order_manage{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-jieshao1 color-good f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_pt:ddgl1}</p>
            </a>
            <a  href="$SCRITPTNAME?id=xigua_pt{$urlext}" class="weui-grid">
                <div class="weui-grid__icon">
                    <i class="iconfont icon-index color-good f22"></i>
                </div>
                <p class="weui-grid__label">{lang xigua_pt:ptsy}</p>
            </a>
        </div>
    </div>
    <!--{/if}-->
    <!--{/if}-->


</div>
<div class="footer_fix"></div>

<div class="masker" style="position: fixed;top: 0;left: 0;right: 0;bottom: 0;background: rgba(0, 0, 0, .5);display: none;z-index:501" onclick='$("#qiehuan").select("close")'></div>
<a href="$SCRITPTNAME?id=xigua_hb&ac=my&mobile=2{$urlext}" style="height:2.5rem;position:fixed;left: 0;bottom: 4rem;z-index: 501;color: #fff;width: 1rem;font-size: 0.6rem;line-height: 0.75rem;text-align: center;padding-top: 0.25rem;border-radius: 0 0.15rem 0.15rem 0;box-shadow:0 0.1rem 0.25rem rgba(0, 0, 0, 0.25) ;background:$config[maincolor];" id="shguide">{lang xigua_hb:yhb}</a>
<!--{eval $tabbar=1;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->
<script>
    var itar = [];
    <!--{loop $list $_sh}--><!--{if $_sh[name]}-->
    itar.push({title: '{$_sh[name]}', value:'{$_sh[shid]}'});
    <!--{/if}--><!--{/loop}-->
    $("#qiehuan").select({
        title: "{lang xigua_hs:qxzsydp}",
        items: itar,
        onOpen: function () {
            $('.masker').fadeIn();
        },
        beforeClose: function () {
            $('.masker').fadeOut(300);
            window.location.href=_APPNAME+"?id=xigua_hs&ac=shcenter&mobile=2&shid="+$("#qiehuan").data('values')+_URLEXT;
            return true;
        }
    });
    $(document).on('click','.sidectrl', function () {
        <!--{if IN_MAGAPP}-->mag.scanQR(function(text){window.location.href=text});
        <!--{elseif IN_QIANFAN}-->qianfanScan();
        <!--{elseif IN_APPBYME}-->appbymeScan();
        <!--{else}-->wx.scanQRCode();<!--{/if}-->
    });
    function appbymeScan() {
        sq.scan(function(result){
            window.location.href=result.url;
        });
    }
    function qianfanScan(){
        QFH5.jumpScan(function(state,data){
            if(state==1){
                window.location.href=data.content;
            }else{
            }
        })
    }
<!--{if in_array('gonggao', $vips[$sh[viptype]][access])}-->
$(document).on('click','.pubgg', function () {
    $.prompt({
        title: '{lang xigua_hs:fabugonggao} ({echo str_replace("'", "", $sh[name]);})',
        input: PLZINPUT,
        empty: false,
        onOK: function (input) {
            $.showLoading();
            $.ajax({
                type: 'post',
                url: _APPNAME +'?id=xigua_hs&ac=notice&do=add&inajax=1&shid={$sh[shid]}',
                data: {'content': input, 'formhash' :FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    var msgar = tip_common(s);
                },
                error: function () { $.hideLoading(); }
            });
        },
        onCancel: function () {}
    });
});
<!--{/if}-->
$(document).on('click','.xufei', function () {
    var _vips = [];
    <!--{loop $vips $k $__v}-->
<!--{if $__v[hide]}-->
<!--{eval continue;}-->
<!--{/if}-->
    _vips.push({text:'{$__v[name]} ( {$__v[udays]} )', onClick:function () {
            window.location.href = '$SCRITPTNAME?id=xigua_hs&ac=xufei&viptype={$__v[id]}&shid={$sh[shid]}'+_URLEXT;
        }});
    <!--{/loop}-->
    $.actions({
        title: '{lang xigua_hs:xufei} {$sh[name]}',
        actions: _vips
    });
});
$(document).on('click','.dodiger', function () {
    $.actions({
        title: '{lang xigua_hs:zhidingdianpu} {$sh[name]}',
        actions: [<!--{loop $vips[$sh[viptype]]['digprice'] $___k $___v}-->
        {text: "{$___v[title]}", onClick: function () {
            var _axjurl = '$SCRITPTNAME?id=xigua_hs&ac=dodig&type={$___v[type]}&shid={$sh[shid]}';
            $.showLoading();
            $.ajax({
                type: 'post',
                url: _axjurl,
                data: {'formhash' :FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    var msgar = tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }}, <!--{/loop}-->]
    });
});
</script>