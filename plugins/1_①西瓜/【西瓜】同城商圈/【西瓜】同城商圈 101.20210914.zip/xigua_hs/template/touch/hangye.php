<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval $desc = $hyid ?$desc:$hs_config['shdesc'];}-->
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<!--{eval $city = $_GET[city]}-->
<!--{eval $province = $_GET[province]}-->
<!--{eval $dist = $_GET[dist]}-->
<div class="page__bd">
    <!--{if $hy['share_pic']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$hy['share_pic']" /></div><!--{/if}-->
    <!--{if IN_MAGAPP}--><style>.nav_expand_panel{position:absolute;height:auto!important;}.nav_expand_panel .weui-flex__item{height:auto;overflow:hidden!important;}</style><!--{/if}-->
    <!--{template xigua_hb:common_nav}-->
<!--{eval
$adwhere = array();
$adwhere[] = 'types=\'cat\'';
if($_GET['hyid']):
    $adwhere[] = '( FIND_IN_SET('.intval($_GET['hyid']).' , catids) OR FIND_IN_SET(-1, catids) )';
else:
    $adwhere[] = '( FIND_IN_SET(-1, catids) )';
endif;
$index_list =  C::t('#xigua_hs#xigua_hs_index')->list_by_where($adwhere);
$newindex_list = array();
if($index_list):
    foreach ($index_list as $index => $item):
        $newindex_list[$item['style']][] = $item;
    endforeach;
endif;
}--><!--{if $newindex_list}--><style>.nav_expand_panel{top:0}</style><!--{/if}-->
<!--{loop $newindex_list $_k $_v}-->
<!--{if $_k==99}-->
<div class="swipe cl" data-speed="5000">
    <div class="swipe-wrap">
        <!--{loop $_v $__k $__v}-->
        <div><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $_v $__k $__v}-->
            <li <!--{if $__k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{else}-->
<!--{eval
if(!$_k):
    $_k = 4;
endif;
$tmpp = array_chunk($_v, $_k);
}--><!--{loop $tmpp $__k $tmpp2}-->
<!--{eval $counttmpp2 = count($tmpp2);}-->
<ul class="inedxicon cl">
    <!--{loop $tmpp2 $__k $__v}-->
    <li style="width:{echo 100/$counttmpp2;}%"><a href="$__v[adlink]"><img src="$__v[icon]"></a></li>
    <!--{/loop}-->
</ul>
<!--{/loop}-->
<!--{/if}-->
<!--{/loop}-->
    <!--{if !$hide_nav}-->
    <!--{if !$newindex_list}--><div class="cl fix_float_fix"></div><!--{/if}-->
    <!--{else}-->
    <!--{if !$newindex_list}--><div class="cl fix_float_fix"></div><!--{/if}-->
    <style>.fix_float{top:0}.nav_expand_panel{top:2.45rem}</style>
    <!--{/if}-->
    <div class="weui-navbar <!--{if !$newindex_list}-->fix_float<!--{/if}--> after_none">
        <!--{if $hs_config[showarea]}-->
        <a data-id="1" class="dist_nav weui-navbar__item <!--{if $hs_config[showmap] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/touch/map.php')}-->none<!--{/if}-->">
            <span>$distname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{/if}-->
        <!--{if $quaninfo}-->
        <a data-id="4" class="dist_nav weui-navbar__item">
            <span>$quanname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <!--{/if}-->
        <a data-id="2" class="dist_nav weui-navbar__item">
            <span>$catname<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
        <a data-id="3" class="dist_nav weui-navbar__item">
            <span>$orderby_list[$orderby]<i class="iconfont icon-xiangxia f12"></i></span>
        </a>
    </div>
    <div class="dist_show">
        <!--{if $hs_config[showarea]}-->
        <div id="dist_show_1" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="first_check border_bfull <!--{if !$_GET[province]}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$hyid&province=&city=&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $dist0 $v}-->
                        <li class="first_check border_bfull <!--{if $_GET[province]==$v[name]}-->checked main_color<!--{eval $city_id=$v['id'];}--><!--{/if}-->" data-id="$v[id]"><a>$v[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="weui-flex__item checked">
                    <!--{loop $dist0 $k $v}-->
                    <ul class="sub_cheker <!--{if $_GET[province]!=$v['name']}-->none<!--{else}-->checked<!--{/if}-->" id="sub_cheker_$v[id]">
                        <li class="sub_check border_bfull"><a data-href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$hyid&province={$v[name]}&city=&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}" class="choose color-red">{lang xigua_hs:quan}{$v[name]} <i class="iconfont icon-coordinates_fill f14 "></i></a></li>
                        <!--{loop $v[child] $vv}-->
                        <li class="sub_check border_bfull <!--{if $city==$vv[name]&&$_GET[city]}-->checked main_color autotrigger<!--{/if}-->"><a data-href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$hyid&province=$v[name]&city=$vv[name]&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}" id="sub_check{$vv[id]}" data-id="$vv[id]" onclick="hs_getnext($vv[id], '{$vv[name]}','$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$hyid&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}')">$vv[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                    <!--{/loop}-->
                </div>
                <div class="weui-flex__item checked" id="ajaxbox"> <ul class="ajaxbox_cheker"></ul> </div>
            </div>
        </div>
        <!--{/if}-->
        <div id="dist_show_2" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="first_cat_check border_bfull <!--{if !$hyid}-->checked main_color<!--{/if}-->"><a href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=&province=$province&city=$city&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $cat_tree $k $v}-->
                        <!--{if !$v[cat_link]}-->
                        <li class="first_cat_check border_bfull <!--{if $hyid==$v[id]||$pid==$v[id]}-->checked main_color<!--{/if}-->"<!--{if $v[sub]}--> data-id="$v[id]"<!--{/if}-->><a <!--{if !$v[sub]}--> href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$v[id]&province=$province&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}"<!--{/if}-->>$v[name]</a></li>
                        <!--{/if}-->
                        <!--{/loop}-->
                    </ul>
                </div>
                <div class="weui-flex__item checked">
                    <!--{loop $cat_tree $k $v}-->
                    <ul class="sub_cat_cheker <!--{if !($hyid==$v[id]||$pid==$v[id])}-->none<!--{/if}-->" id="sub_cat_cheker_$v[id]">
                        <li class="sub_cat_check border_bfull"><a <!--{if $hyid==$v[id]}-->class="checked main_color"<!--{/if}--> href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$v[id]&province=$province&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $v[sub] $vv}-->
                        <li class="sub_cat_check border_bfull"><a <!--{if $hyid==$vv[id]}-->class="checked main_color"<!--{/if}--> href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$vv[id]&province=$province&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">$vv[name]</a></li>
                        <!--{/loop}-->
                    </ul>
                    <!--{/loop}-->
                </div>
            </div>
        </div>
        <div id="dist_show_3" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <!--{loop $orderby_list $_ok $_ol}-->
                        <!--{if $_ok == 'near'}-->
                        <li class="<!--{if $orderby==$_ok}-->checked main_color<!--{/if}--> border_bfull"><a data-href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$hyid&province=$province&city=$city&dist=$dist&orderby=$_ok&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}" id="near_cat" href="javascript:;">$_ol</a></li>
                        <!--{else}-->
                        <li class="<!--{if $orderby==$_ok}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$hyid&province=$province&city=$city&dist=$dist&orderby=$_ok&keyword=$keyword&lat=$lat&lng=$lng&quan=$_GET[quan]{$urlext}">$_ol</a></li>
                        <!--{/if}-->
                        <!--{/loop}-->
                    </ul>
                </div>

            </div>
        </div>
        <!--{if $quaninfo}-->
        <div id="dist_show_4" class="nav_expand_panel ">
            <div class="weui-flex">
                <div class="weui-flex__item">
                    <ul>
                        <li class="<!--{if !$_GET[quan]}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$hyid&province=$province&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan={$urlext}">{lang xigua_hb:quanbu}</a></li>
                        <!--{loop $quaninfo $quan}-->
                        <li class="<!--{if $quan==$_GET[quan]}-->checked main_color<!--{/if}--> border_bfull"><a href="$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=$hyid&province=$province&city=$city&dist=$dist&orderby=$orderby&keyword=$keyword&lat=$lat&lng=$lng&quan=$quan{$urlext}">$quan</a></li>
                        <!--{/loop}-->
                    </ul>
                </div>
            </div>
        </div>
        <!--{/if}-->
    </div>
<!--{if $hs_config[submode]}-->
<!--{eval
$query = preg_replace('/hyid\=\d+/ies', '', $query);
$knum = $hs_config[submode]==3 ? 10:5;
}-->
<!--{if $subcats2 && ($hs_config[submode]==1||$hs_config[submode]==3)}-->
    <nav class="nav-list cl swipe transparent mt3 border_top" style="padding-top:.2rem">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $subcats2 $k $n}-->
                    <!--{if $k && $k%$knum==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li class="cl">
                        <a href="$SCRITPTNAME?id=xigua_hs&ac=hangye&$query&hyid=$n[id]">
                            <span>
                                <img src="{echo $n['icon'] ?$n['icon'] : 'source/plugin/xigua_hb/static/img/icon.png'}"/>
                            </span>
                            <em class="m-piclist-title <!--{if intval($_GET[hyid])==$n[id]}-->main_color<!--{/if}-->">{$n['name']}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <nav class="cl bullets bullets1" style="display:none">
            <ul class="position position1">
                <!--{loop $jing_count $k $v}-->
                <li {if $k==0} class="current" {/if}></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </nav>
    <!--{elseif $subcats||$curtsub}-->
    <div class="banner_fix cl">
        <div class="banner">
            <nav class="weui-flex tag_list">
                <a href="$SCRITPTNAME?id=xigua_hs&ac=hangye&$query&hyid=0" class="pstyle2 <!--{if $pid==$_GET[hyid]}-->pstyle2on main_bg<!--{/if}-->">{lang xigua_hb:quanbu}</a>
                <!--{if $curtsub}-->
                <a class="pstyle2 <!--{if $curtsub[id]==$_GET[hyid]}-->pstyle2on main_bg<!--{/if}-->" href="$SCRITPTNAME?id=xigua_hs&ac=hangye&$query&hyid=$curtsub[id]">$curtsub[name]</a>
                <!--{/if}-->
                <!--{loop $subcats $_kk $subcat}-->
                <a class="pstyle2 <!--{if $subcat[id]==$_GET[hyid]}-->pstyle2on main_bg<!--{/if}-->" href="$SCRITPTNAME?id=xigua_hs&ac=hangye&$query&hyid=$subcat[id]">$subcat[name]</a>
                <!--{/loop}-->
            </nav>
        </div>
    </div>
    <!--{/if}-->
<!--{/if}-->

    <!--{if $catinfo['adimage']}-->
    <div class="">
        <a href="{eval echo $catinfo['adlink'] ? $catinfo['adlink'] : $SCRITPTNAME.'?id=xigua_hs&ac=hangye&hyid='.$hyid.$urlext}"><img src="$catinfo['adimage']" class="block" style="display:block" /></a>
    </div>
    <!--{/if}-->
<!--{if !$_GET['keyword'] && ($hs_config[showmap]||$_GET[showmap]) && is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/touch/map.php')}-->
<!--{eval $mapjs=1;}--><!--{template xigua_hs:map}-->
<!--{else}--><!--{template xigua_hs:list_cat}-->
<!--{/if}-->
</div>
<!--{template xigua_hs:search}-->

<!--{if $hide_nav}-->
<div id="index_search" class="backtotop backtotop_show" style="bottom:-.5rem"> <span class="icon-vertical-align-top"><i class="iconfont icon-sousuo"></i></span></div>
<!--{/if}-->
<script>var loadingurl = window.location.href+'&ac=myshop_li&inajax=1&page=';scrollto = 1;</script>
<!--{eval $tabbar=0;$hs_tabbar=1;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->
<!--{if $_GET[near_cat]}--><script>setTimeout(function () {$('#near_cat').trigger('click');if(typeof wx !=='undefined') {
    wx.ready(function () {
        $('#near_cat').trigger('click');
    });
}}, 200);</script><!--{/if}-->
<!--{if $hs_config[showarea]}--><script>
$(document).on('click','.choose', function () {
    var that = $(this), c_jmpurl = '';
    if(that.data('href')){ c_jmpurl = that.data('href'); }
    if(that.data('ctid')){ c_jmpurl = $('#sub_check'+that.data('ctid')).data('href'); }
    window.location.href= c_jmpurl;
});
$(document).on('click','.dist_check', function () {$('.dist_check').removeClass('checked').removeClass('main_color'); $(this).addClass('checked').addClass('main_color');});
$(document).on('click','.dist_nav', function () {if($('.autotrigger').length>0){$('.autotrigger').find('a').trigger('click');}});
$(document).on('click','.first_check', function () {$('.ajaxbox_cheker').html('');});</script><!--{/if}-->
<!--{if $mapjs}-->
<!--{template xigua_hs:mapjs}-->
<!--{/if}-->
<!--{if $_GET[s]==1}--><script>$('#search_popup').popup();</script><!--{/if}-->