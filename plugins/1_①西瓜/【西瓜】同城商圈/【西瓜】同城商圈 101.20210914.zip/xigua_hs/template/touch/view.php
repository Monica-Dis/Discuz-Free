<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<!--{eval include DISCUZ_ROOT.'source/plugin/xigua_hs/include/c_view.php';}-->
<style>.x_header{background:transparent!important; position: relative;}.x_header_fix{display:none}.view_header{background-image: linear-gradient(to top, $mc, $mc_op);}.mc_bg{background:$mc!important;}
.mc_clr{color:$mc!important;}
<!--{if $shbtncolor[$v[color_title]]}-->.shbtn{background-color:{$shbtncolor[$v[color_title]]}!important;}<!--{/if}-->
<!--{if $filler}-->.x_header{ position:absolute;width:5rem;z-index:1}.navtitle, .sidectrl{display:none!important;}
.x_header a{font-size:0.65rem;background: rgba(0,0,0,.5);top: 0.5rem;left: 0.5rem;height: 1.5rem;line-height: 1.5rem;border-radius: 1rem;padding: 0 0.5rem }
.x_header i {display:none}<!--{/if}--></style>
<div class="page__bd">
<!--{template xigua_hb:common_nav}-->
<!--{if $v[mp3]}-->
<div id="audio_btn" class="video_exist play_yinfu" style="display:block">
    <div id="yinfu" class="rotate"></div>
    <audio loop="loop" id="auto_play" autoplay="autoplay" preload="preload">
        <source src="{$v[mp3]}" type="audio/mpeg" />
    </audio>
</div>
<!--{/if}-->
<div class="none"><img src="$v[logo]" onerror="this.error=null;this.src='{$hs_config[dftshlogo]}'" /></div>
    <!--{if !$filler}-->
<!--{if $v[cover]}-->
    <img src="$v[cover]" style="width:100%;left:0;display:block;position:relative;top:-2.1rem;filter:blur({$hs_config[blurtop]}px);">
<!--{/if}-->
    <div class="cl view_header" <!--{if $cover}-->style="background:none;<!--{if $v[cover]}-->margin-top:-12.3rem;<!--{/if}-->"<!--{/if}-->>
<!--{if $cover&&!$v[cover]}-->
    <div style="background:url($cover);background-size: cover;filter: blur({$hs_config[blurtop]}px);width:100%;height:10.6rem;position:absolute;top:0;"></div>
<!--{/if}-->
        <div class="view_htop">
            <div class="view_logo"><img src="$v[logo]" onerror="this.error=null;this.src='{$hs_config[dftshlogo]}'" /><!--{if $vipinfo[icon]}--><b class="crown" style="background-image:url({$vipinfo[icon]})"></b><!--{/if}--></div>
            <h1>$v[name]</h1>
            <div class="view_rank">
                <!--{if $v[end]}-->
                <span>{lang xigua_hs:yiguoqi}</span>
                <!--{else}-->
                <span>{$vipinfo['name']}</span>
                <span>{lang xigua_hs:qian}{$v['rank']}{lang xigua_hs:ming}</span>
                <!--{/if}-->
            </div>
        </div>
<!--{if $hs_config[topwater]}-->
<div class="water"><div class="water-c"><div class="water-1"></div><div class="water-2"></div></div></div>
<!--{/if}-->
        <div class="view_hbtm weui-flex">
            <div class="weui-flex__item border_right">{$v[views]}<br> {lang xigua_hs:view} </div>
            <div class="weui-flex__item border_right"><a href=""> {$v[pubs]}<br> {lang xigua_hs:sjxx} </a></div>
            <div class="weui-flex__item border_right hs_share" data-id="$v[shid]">{$v[shares]}<br> {lang xigua_hs:fenxiang} </div>
            <div class="weui-flex__item"><span>{$v['follow']}</span><br>
                <!--{if $followed}-->
                <a href="javascript:;" class="weui-btn weui-btn_mini do_follow weui-btn_disabled lh26 shbtn" data-id="$v[shid]" data-qr="{echo $v[qr] ? $v[qr] : $config[qrcode]}">{lang xigua_hs:yiguanzhu}</a>
                <!--{else}-->
                <a href="javascript:;" class="weui-btn weui-btn_mini do_follow lh26 shbtn" data-wei="1" data-id="$v[shid]" data-qr="{echo $v[qr] ? $v[qr] : $config[qrcode]}">{lang xigua_hs:jiaguanzhu}</a>
                <!--{/if}-->
            </div>
        </div>
    </div>
    <!--{else}-->
        <!--{if $v[quanjing]}-->
<!--{if strpos($v['quanjing'], '.jpg')!==false || strpos($v['quanjing'], '.png')!==false}-->
    <img src="$v['quanjing']" style="display:block;width:100%;" />
<!--{else}-->
    <!--{if !$showiframe}-->
    <iframe src="{$v['quanjing']}" style="height:{$hs_config[vrheight]}px" frameborder="0" class="view_iframe"></iframe>
    <!--{/if}-->
<!--{/if}-->
        <!--{elseif $v[video]}-->
<div class="bgf"><video poster="{$v['video_cover']}" <!--{if $hs_config[autoplay]}-->autoplay muted<!--{/if}--> style="width:100%;max-height:{$hs_config[vrheight]}px;height:{$hs_config[vrheight]}px" src="{$v['video']}" controls="controls" <!--{if !IN_PROG}-->x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<!--{/if}-->></video></div>
        <!--{elseif $v[shipin]}-->$v['shipin']<!--{else}-->
            <!--{if $hs_config[topswiper]}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $v[album] $slider}-->
            <div><img src='$slider' style="height:{$hs_config[topswiperh]}px"/></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $v[album] $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
            <!--{/if}-->
        <!--{/if}-->
    <!--{/if}-->

<div class="weui-cells mt0 view_top before_none after_none">
<!--{if $filler}-->
    <div class="cl view_cell">
        <div class="weui-flex">
            <div class="weui-flex__item">
                <span class="f15">$v[name]</span>
                <!--{if $v[end]}--><span class="hs_tag"><i class="iconfont icon-jubao c9 f12"> {lang xigua_hs:guoqi}</i></span><!--{else}-->
                <span class="f12 c9">{$vipinfo['name']}</span>
                <span class="f12 c9">{lang xigua_hs:qian}{$v['rank']}{lang xigua_hs:ming}</span>
                <!--{/if}-->
            </div>
            <div><!--{if $followed}-->
                <a class="weui-btn weui-btn_mini do_follow weui-btn_disabled shbtn" data-id="$v[shid]" data-qr="$v[qr]">{lang xigua_hs:yiguanzhu}$v[follow]</a>
                <!--{else}-->
                <a class="weui-btn weui-btn_mini do_follow shbtn" data-wei="1" data-id="$v[shid]" data-qr="$v[qr]">{lang xigua_hs:jiaguanzhu}$v[follow]</a>
                <!--{/if}-->
            </div>
        </div>
        <div class="weui-flex">
            <!--{if trim($v[opentime])}-->
            <div class="weui-flex__item f13 c9">
                {lang xigua_hs:opentime}: {$v[opentime]}
            </div>
            <!--{/if}-->
            <div class="f13 c9">
                {lang xigua_hs:fenxiang}:{$v[shares]} {lang xigua_hs:view}:{$v[views]}
            </div>
        </div>
    </div>
<!--{/if}-->
    <!--{if trim($v[xuanchuan]) && in_array('xuanchuan', $vipinfo['access'])}-->
    <div class="weui-cell fullcell view_tel">
        <div class="weui-cell__hd"><i class="iconfont icon-gonggao main_color mr15 f20"></i></div>
        <div class="weui-cell__bd">
            <p class="f14">{$v[xuanchuan]}</p>
        </div>
    </div>
    <!--{/if}-->
    <!--{if $v[show]}-->
    <a class="weui-cell weui-cell_access fullcell view_album" href="javascript:;" onclick="hb_jump('$SCRITPTNAME?id=xigua_hs&ac=album&shid=$shid{$urlext}')">
        <div class="weui-cell__hd"><i class="iconfont icon-tupian1 main_color mr15 f20"></i></div>
        <div class="weui-cell__bd">
<!--{loop $v[show] $slider}-->
<img class="z" src="$slider" onerror="this.error=null;$(this).remove();" />
<!--{/loop}-->
        </div>
        <div class="weui-cell__ft">
        </div>
    </a>
    <!--{/if}-->
    <!--{if $shtel}-->
    <a class="weui-cell weui-cell_access fullcell view_tel" href="$shtel">
        <div class="weui-cell__hd"><i class="iconfont icon-unie607 main_color mr15 f20"></i></div>
        <div class="weui-cell__bd">
            <!--{if !$needpaytel}-->
            <p><img src="source/plugin/xigua_hs/cache/$v[tel].png" onerror="this.error=null;$(this).parent().html('$v[tel]');"></p>
            <!--{else}-->
            <p>{lang xigua_hb:cklxfsxzf}<em class="main_color">{$vtelp}{lang xigua_hb:yuan}</em></p>
            <!--{/if}-->
            <!--{if !$v[quanjing] && !$v[shipin] &&$v[opentime]}--><p class="f13 c9">{lang xigua_hs:opentime}: {$v[opentime]}</p><!--{/if}-->
        </div>
        <div class="weui-cell__ft">
        </div>
    </a>
    <!--{/if}-->
    <!--{if $shdata[qr]}-->
    <a class="weui-cell weui-cell_access fullcell view_tel" href="javascript:;" onclick='$.alert("<img src=$shdata[qr] /><br>{lang xigua_hs:gengduodongtai}", "{lang xigua_hs:guanzhu_sj}");' >
        <div class="weui-cell__hd"><i class="iconfont icon-erweima main_color mr15" style="margin-left:.15rem"></i></div>
        <div class="weui-cell__bd">
            <p class="f14">{lang xigua_hs:shangjia}{lang xigua_hs:guanzhushangjia}</p>
        </div>
        <div class="weui-cell__ft"></div>
    </a>
    <!--{/if}-->
    <a class="weui-cell weui-cell_access fullcell" href="javascript:;" id="v_openLocation" data-lat="$v[lat]" data-lng="$v[lng]" data-name="$v[name]" data-addr="$v[addr]">
        <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
        <div class="weui-cell__bd">
            <p class="f14">{$v[city]}$v[addr]</p>
            <p class="f13 c9" id="driving" data-id="$v[shid]">{lang xigua_hs:jisuan}</p>
        </div>
        <div class="weui-cell__ft">
        </div>
    </a>
    <!--{eval
if($_G['cache']['plugin']['xigua_hr']):
$veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris_bysh(array($v['shid']));
$bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($v[uid]));
endif;
}-->
<!--{if $veris2[$v[shid]] || $bao[$v[uid]]}-->
    <div class="weui-cell weui-cell_access fullcell" >
        <div class="weui-cell__hd"><i class="iconfont icon-qiyerenzheng main_color mr15" style="position: relative;left:.15rem"></i></div>
        <div class="weui-cell__bd">
            <ul class="arguments-treatment main_color">
                <!--{if $veris2[$v[shid]]}--><li style="float:left;"><a href="javascript:;"><i class="iconfont icon-duigou2"></i>{lang xigua_hr:qy}</a></li><!--{/if}-->
                <!--{if $bao[$v[uid]]}--><li style="float:left;"><i class="iconfont icon-duigou2"></i><!--{if $_G[cache][plugin][xigua_hr][bzjed]}--><span class="f13 main_color">{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</span><!--{else}-->{lang xigua_hr:yjbzj}<!--{/if}--></li><!--{/if}-->
            </ul>
        </div>
    </div>
<!--{/if}-->
<!--{if $v[tags] && in_array('tag', $vipinfo['access'])}-->
    <div class="weui-cell fullcell tc">
        <div class="weui-cell__bd">
            <!--{loop $v[tags] $tg}-->
            <a href="$SCRITPTNAME?id=xigua_hs&ac=hangye&tag={echo urlencode($tg);}{$urlext}" class="view_tag b-color0 mc_clr">$tg</a>
            <!--{/if}-->
        </div>
    </div>
<!--{/if}-->
</div>


<!--{eval
$adwhere = array();
$adwhere[] = 'types=\'view\'';
if($_GET['hyid']):
    $adwhere[] = '( FIND_IN_SET('.intval($_GET['hyid']).' , catids) OR FIND_IN_SET(-1, catids) )';
else:
    $adwhere[] = '( FIND_IN_SET(-1, catids) )';
endif;
$index_list =  C::t('#xigua_hs#xigua_hs_index')->list_by_where($adwhere);
$newindex_list = array();
if($index_list):
    foreach ($index_list as $index => $item):
        $newindex_list[$item['style']][] = $item;
    endforeach;
endif;
}-->
<!--{loop $newindex_list $_k $_v}-->
<!--{if $_k==99}-->
<div class="swipe cl" data-speed="5000">
    <div class="swipe-wrap">
        <!--{loop $_v $__k $__v}-->
        <div><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $_v $__k $__v}-->
            <li <!--{if $__k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{else}-->
<!--{eval
if(!$_k):
    $_k = 4;
endif;
$tmpp = array_chunk($_v, $_k);
}--><!--{loop $tmpp $__k $tmpp2}-->
<!--{eval $counttmpp2 = count($tmpp2);}-->
<ul class="inedxicon cl">
    <!--{loop $tmpp2 $__k $__v}-->
    <li style="width:{echo 100/$counttmpp2;}%"><a href="$__v[adlink]"><img src="$__v[icon]"></a></li>
    <!--{/loop}-->
</ul>
<!--{/loop}-->
<!--{/if}-->
<!--{/loop}-->


<!--{if $v[quanjing] && $v[video]}-->
<div class="weui-panel view_notice border_none">
    <div class="weui-cells__title weui_title mt0 f15"><i class="iconfont icon-shipin vm main_color f18"></i> {lang xigua_hs:dianpushipin} </div>
    <div class="weui-panel__bd">
        <div class="weui-media-box weui-media-box_text">
            <video poster="{$v['video_cover']}" <!--{if $hs_config[autoplay]}-->autoplay muted<!--{/if}--> style="width:100%;max-height:{$hs_config[vrheight]}px;height:{$hs_config[vrheight]}px" src="{$v['video']}" controls="controls" <!--{if !IN_PROG}-->x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<!--{/if}-->></video>
        </div>
    </div>
</div>
<!--{/if}-->
<!--{if $v[quanjing] && $v[shipin]}-->
<div class="weui-panel view_notice border_none">
    <div class="weui-cells__title weui_title mt0 f15"><i class="iconfont icon-shipin vm main_color f18"></i> {lang xigua_hs:dianpushipin} </div>
    <div class="weui-panel__bd">
        <div class="weui-media-box weui-media-box_text">
            $v['shipin']
        </div>
    </div>
</div>
<!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_job'] && $hs_config[zpnum]>0}--><!--{template xigua_hs:shjob_li}--><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_hm']}-->
<link href="source/plugin/xigua_hm/static/coupon.css?{VERHASH}" rel="stylesheet">
<!--{if $seclist}-->
<div class="weui-cells f15 before_none after_none">
    <div class="weui-cells__title weui_title mt0 f15">
        <i class="iconfont icon-qiangdanshezhi vm f18 main_color" style="font-size:.95rem"></i> {lang xigua_hs:mk}
        <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_hm&shid=$shid{$urlext}" >{lang xigua_hs:more}<i class="f13 iconfont icon-jinrujiantou"></i></a>
    </div>
    <!--{if count($seclist)==1}-->
    <!--{eval $qv = $seclist[0];}-->
    <div class="seclight weui-cells before_none after_none">
        <div class="weui-cell pt0" onclick="hb_jump('$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid={$qv[id]}{$urlext}')">
            <div class="weui-cell__hd"><!--{if $qv[fszx]}--><em class="mian_">{lang xigua_hm:fensizhuanxiang}</em><!--{else}--><!--{if !$qv[yuyue]}--><em class="mian_">{lang xigua_hs:mian}</em><!--{/if}--><!--{/if}--><img src="{echo $qv[album][0]?$qv[album][0]:$qv[append_img_ary][0]}"></div>
            <div class="weui-cell__bd">
                <p class="p1">{$qv[title]}</p>
                <p class="p2"><span class="color-sec"><em class="f18">{$qv[price]}</em><em class="f12">{lang xigua_hs:yuan}</em><!--{if $qv[dingprice]>0}--> <em class="sp_bubble">{lang xigua_hs:dj}</em><!--{/if}--></span>
                    <span><s class="f12 c9 ">{$qv[marketprice]}{lang xigua_hs:yuan}</s></span></p>
            </div>
            <div class="weui-cell__ft"><a class="coupon-btn"href="javascript:;">{lang xigua_hs:lijiqiang}</a></div>
        </div>
    </div>
    <!--{else}-->
    <div class="swiper-container coupon_swiper">
        <div class="swiper-wrapper">
            <!--{loop $seclist $k $qv}-->
            <div class="swiper-slide seclight_box">
                <a href="$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid={$qv[id]}{$urlext}">
                    <div class="pr">
                        <!--{if $qv[fszx]}--><em class="mian_">{lang xigua_hm:fensizhuanxiang}</em><!--{else}--><!--{if !$qv[yuyue]}--><em class="mian_">{lang xigua_hs:mian}</em><!--{/if}--><!--{/if}--><img class="seclight_img" src="{echo $qv[album][0]?$qv[album][0]:$qv[append_img_ary][0]}">
                    </div>
                    <div class="p1">{$qv[title]}</div>
                    <div class="p2">
                        <span class="color-sec"><em class="f18">{$qv[price]}</em><em class="f12">{lang xigua_hs:yuan}</em><!--{if $qv[dingprice]>0}--> <em class="sp_bubble">{lang xigua_hs:dj}</em><!--{/if}--></span>
                        <span><s class="f12 c9 ">{$qv[marketprice]}{lang xigua_hs:yuan}</s></span>
                    </div>
                </a>
            </div>
            <!--{/loop}-->
        </div>
    </div>
    <!--{/if}-->
</div>
<!--{/if}-->

<!--{if $quanlist}-->
<div class="weui-cells f15 before_none after_none">
    <div class="weui-cells__title weui_title mt0 f15">
        <i class="iconfont icon-quan1 vm f18 main_color "></i> {lang xigua_hs:yhq}
        <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_hm&stype=youhui&shid=$shid{$urlext}" >{lang xigua_hs:more}<i class="f13 iconfont icon-jinrujiantou"></i></a>
    </div>
<!--{if count($quanlist)==1}-->
<!--{eval $qv = $quanlist[0];}-->
    <div class="coupon" onclick="hb_jump('$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid={$qv[id]}{$urlext}')">
        <div class="coupon-left1">
            <div class="coupon-inner">
                <div class="coupon_img">
                    <img src="{echo $qv[album][0]?$qv[album][0]:$qv[append_img_ary][0]}">
                </div>
                <div class="coupon-money">
                    <span>{$qv[title]}</span>
                </div>
                <div class="coupon-condition">
                    <span class="sum"><!--{if $qv[stype]=='zhekou'}-->{$qv[show_zhekourate]}<em class="f14">{lang xigua_hs:zhe}</em><!--{else}-->{$qv[price]}<em class="f12">{lang xigua_hs:yuan}{$stypes[$qv[stype]]}</em><!--{/if}--></span>
                    <span class="c9 f12"><!--{if $qv[underline]}-->{lang xigua_hs:man}{$qv[underline]}{lang xigua_hs:keyong}<!--{else}-->{$qv[fanwei]}<!--{/if}--></span>
                </div>
            </div>
        </div>
        <div class="coupon-right1">
            <div class="coupon-inner">
                <div class="coupon-time">
                    <a class="coupon-btn" href="javascript:;">{lang xigua_hs:lijiling}</a>
                    <p>{lang xigua_hs:yiling}{$qv[hasqiang]}</p>
                </div>
                <i class="coupon-circle top"></i>
                <i class="coupon-circle bottom"></i>
            </div>
        </div>
    </div>
<!--{else}-->
    <div class="swiper-container coupon_swiper">
        <div class="swiper-wrapper">
            <!--{loop $quanlist $k $qv}-->
            <div class="swiper-slide">
                <div class="coupon coupon_col">
                    <div class="coupon-left1">
                        <div class="coupon-inner">
                            <div class="coupon_img">
                                <img src="{echo $qv[album][0]?$qv[album][0]:$qv[append_img_ary][0]}">
                            </div>
                            <div class="coupon-money">
                                <span>{$qv[title]}</span>
                            </div>
                            <div class="coupon-condition">
                                <span class="sum"><!--{if $qv[stype]=='zhekou'}-->{$qv[show_zhekourate]}<em class="f14">{lang xigua_hs:zhe}</em><!--{else}-->{$qv[price]}<em class="f12">{lang xigua_hs:yuan}{$stypes[$qv[stype]]}</em><!--{/if}--></span>
                            </div>
                        </div>
                    </div>
                    <div class="coupon-right1">
                        <div class="coupon-inner">
                            <div class="coupon-time">
                                <a class="coupon-btn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_view&secid={$qv[id]}{$urlext}">{lang xigua_hs:lijiling}</a>
                            </div>
                            <i class="coupon-circle top"></i>
                            <i class="coupon-circle bottom"></i>
                        </div>
                    </div>
                </div>
            </div>
            <!--{/loop}-->
        </div>
    </div>
<!--{/if}-->
</div>
<!--{/if}-->
    <!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_sp'] && $hs_config[sp_num]>0}-->
<!--{eval
$splist = C::t('#xigua_sp#xigua_sp_good')->fetch_all_by_where(array("stat=1 AND shid=$shid"), 0, $hs_config[sp_num], 'sellnum desc , displayorder desc');
}-->
<!--{if $splist}-->
<div class="weui-cells f15 before_none after_none">
    <div class="weui-cells__title weui_title mt0 f15">
        <i class="iconfont icon-gouwuche f18 main_color"></i> {lang xigua_sp:rmsp}
        <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_sp&ac=shop&shid=$shid{$urlext}" >{lang xigua_hs:jdgg}<i class="f13 iconfont icon-jinrujiantou"></i></a>
    </div>
    <div class="swiper-container coupon_swiper">
        <div class="swiper-wrapper">
            <!--{loop $splist $k $qv}-->
            <div class="swiper-slide seclight_box">
                <a href="javascript:;" onclick="hb_jump('$SCRITPTNAME?id=xigua_sp&ac=view&gid={$qv[id]}{$urlext}');">
                    <div class="pr">
                        <img class="seclight_img" style="height:5rem;width:5rem" src="{echo $qv[fengmian] ? $qv[fengmian]: ($qv[album][0]?$qv[album][0]:$qv[append_img_ary][0])}">
                    </div>
                    <div class="p1">{$qv[title]}</div>
                    <div class="p2" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis">
                        <span class="color-sec"><em class="f12">&yen;</em><em class="f18">{$qv[tprice]}</em></span>
                        <span><s class="f12 c9 ">{lang xigua_hs:yj} &yen;{$qv[disprice]}</s></span>
                    </div>
                </a>
            </div>
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{/if}-->
<!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_hd'] && $hdlist}-->
<div class="weui-cells f15 before_none after_none">
<div class="weui-cells__title weui_title mt0 f15">
    <i class="iconfont icon-40kanjia vm f18 main_color" style="font-size:.95rem"></i> {lang xigua_hs:jjhd}
    <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_hd&shid=$shid{$urlext}" >{lang xigua_hs:more}<i class="f13 iconfont icon-jinrujiantou"></i></a>
</div>
<div class="seclight weui-cells before_none after_none">
    <!--{loop $hdlist $k $qv}-->
    <div class="weui-cell <!--{if $k==0}-->pt0<!--{/if}-->" onclick="hb_jump('$SCRITPTNAME?id=xigua_hd&ac=view&did={$qv[id]}{$urlext}')">
        <div class="weui-cell__hd"><img src="{echo $qv[album][0]?$qv[album][0]:$qv[append_img_ary][0]}"></div>
        <div class="weui-cell__bd">
            <p class="p1">{$qv[title]}</p>
            <p class="p2">
                <span class="color-sec"><em class="f12">{lang xigua_hs:dj1}</em><em class="f18">{$qv[disprice]}</em><em class="f12">{lang xigua_hs:yuan}</em></span>
                <span><s class="f12 c9 "><em class="f12">{lang xigua_hs:yj}</em>{$qv[biaoprice]}{lang xigua_hs:yuan}</s></span>
            </p>
        </div>
        <div class="weui-cell__ft"><a class="coupon-btn" href="javascript:;">{lang xigua_hs:ljjj}</a></div>
    </div>
    <!--{/loop}-->
</div>
</div>
<!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_pt'] && $hs_config[pt_num]>0}-->
<div class="weui-cells f15 before_none after_none" id="ptbox" style="display:none" >
    <div class="weui-cells__title weui_title mt0 f15" style="padding-bottom:0">
        <i class="iconfont icon-jieban vm f18 main_color" style="font-size:.95rem"></i> {lang xigua_pt:pt}{lang xigua_pt:jj}
        <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_pt&shid=$shid{$urlext}" >{lang xigua_hs:more}<i class="f13 iconfont icon-jinrujiantou"></i></a>
    </div>
<style>#ptdiv{padding:.5rem .75rem 0}#ptdiv .row_list .item{height:5rem}#ptdiv .row_list .name{margin-right:0}#ptdiv .row_list .tags{display:none}#ptdiv .row_list .btn{right:0}#ptdiv .row_list .info{margin-left:5.4rem;height:5.4rem;padding:0}#ptdiv .row_list .cover{width:5rem;height:5rem;top:0;left:0}</style>
<ul id="ptdiv" class="goodlist cl"></ul>
</div>
<script>$.ajax({type: 'get',url: '$SCRITPTNAME?id=xigua_pt&ac=cat_li&inajax=1&shid=$shid&page=1&pagesize={$hs_config[pt_num]}',dataType: 'xml',
success: function (data) {
    if(null==data){ $('#ptbox').remove(); return false;}
    var s = data.lastChild.firstChild.nodeValue;
    if(s){
        $('head').append('<link rel="stylesheet" href="source/plugin/xigua_pt/static/pt.css?{VERHASH}" />');
        $('#ptdiv').html(s);
        $('#ptbox').show();
    }else{ $('#ptbox').remove();
    }
    $(document).on('click', '.jump_pt', function () {
        var that = $(this);
        var jmpurl = _APPNAME +'?id=xigua_pt&ac=view&gid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        if(typeof mag !== 'undefined'){
            mag.newWin(GSITE+jmpurl);
            return false;
        }
        if(typeof wx !=='undefined'){
            if (window.__wxjs_environment === 'miniprogram') {
                wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
                return false;
            }
        }
        window.location.href = jmpurl;
        return false;
    });
},
error: function () {$('#ptbox').remove();}});</script><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_he'] && $hs_config[huod_num]>0}-->
<!--{template xigua_hs:huodong_li}-->
<!--{/if}-->

<!--{if $_G['cache']['plugin']['xigua_ho']}-->
<!--{eval $ho_tuindex = unserialize($_G['cache']['plugin']['xigua_ho'][tuindex]);}-->
<!--{if in_array(3, $ho_tuindex)}--><!--{template xigua_hs:ho_shifu_li}--><!--{/if}-->
<!--{if in_array(4, $ho_tuindex)}--><!--{template xigua_hs:ho_fuwu_li}--><!--{/if}-->
<!--{/if}-->

<!--{if $_G['cache']['plugin']['xigua_hk'] && $hs_config[hk_num]>0}-->
<div id="ptdiv1" class="mod-post x-postlist p0 cl" style="display:none;margin-top:10px;padding: 0;">
    <div class="weui-cells__title weui_title mt0 f15" style="padding-bottom:0">
        <i class="iconfont icon-huiyuan2 main_color"></i> {lang xigua_hk:heika}{lang xigua_hk:hd_}
        <a class="y c9 pr_1" href="$SCRITPTNAME?id=xigua_hk&ac=index&shid=$shid{$urlext}" >{lang xigua_hs:more}<i class="f13 iconfont icon-jinrujiantou"></i></a>
    </div></div>
<script>
$.ajax({type: 'get', url: '$SCRITPTNAME?id=xigua_hk&ac=good_li&inajax=1&shid=$shid&pagesize={$hs_config[hk_num]}&page=1', dataType: 'xml',
success: function (data) {
    if(null==data){ $('#ptdiv1').remove(); return false;}
    var s = data.lastChild.firstChild.nodeValue;
    if(!s){ $('#ptdiv1').remove(); return false;}
    $('head').append('<link rel="stylesheet" href="source/plugin/xigua_hk/static/css/hk.css?{VERHASH}" />');
    $('#ptdiv1').append(s).show();
    $(document).on('click', '.hk_glist', function () {
        var that = $(this);
        var daten = '';
        if(that.data('date')){
            daten = that.data('date');
        }
        var jmpurl = _APPNAME +'?id=xigua_hk&ac=view&date='+daten+'&gid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        if(typeof mag !== 'undefined'){
            mag.newWin(GSITE+jmpurl);return false;
        }
        if(typeof wx !=='undefined'){
            if (window.__wxjs_environment === 'miniprogram') {
                GSITE = GSITE.replace(/http:\/\//, 'https://');
                wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
                return false;
            }
        }
        if(typeof QFH5 !== 'undefined'){
            QFH5.jumpNewWebview(GSITE+jmpurl);return false;
        }
        window.location.href = jmpurl;
        return false;
    });
},
error: function () {$('#ptdiv1').remove();
}
});
</script>
<!--{/if}-->
<!--{if $gonggao && $gonggao[0][content] && in_array('gonggao', $vipinfo['access'])}-->
    <div class="weui-panel view_notice border_none">
        <div class="weui-cells__title weui_title mt0 f15">
            <i class="iconfont icon-tongzhi vm main_color f18"></i> {lang xigua_hs:dianpugonggao}
            <!--{if count($gonggao)>1}--><a class="y c9 pr_1" href="javascript:;" data-id="$shid" id="history_gonggao">{lang xigua_hs:lishigonggao}<i class="f13 iconfont icon-jinrujiantou"></i></a><!--{/if}-->
        </div>
        <div class="weui-panel__bd">
            <div class="weui-media-box weui-media-box_text">
                <p class="weui-media-box__desc">{echo hs_nl2br(strip_tags($gonggao[0][content]));}</p>
            </div>
        </div>
    </div>
<!--{/if}-->
    <div class="weui-cells fixbanner border_none" id="view_more">

        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="javascript:;" class="weui-navbar__item hscat weui_bar__item_on" data-id="hscat_profile">
                <span>{lang xigua_hs:xiangqing}</span>
            </a>
            <!--{if $hs_config[newdt]}-->
            <!--{eval $hbcat = array();}-->
            <a href="javascript:;" class="weui-navbar__item hscat" data-id="newdt" data-shid="$v[shid]">
                <span>{lang xigua_hs:sjdt}</span>
            </a>
            <!--{/if}-->
            <!--{if $v[links] && in_array('link', $vipinfo['access'])}-->
            <!--{loop $v[links][font] $_i $_f}-->
            <!--{if $_f}-->
            <a href="{$v[links][link][$_i]}" class="weui-navbar__item">
                <span>{$_f}</span>
            </a>
            <!--{/if}-->
            <!--{/loop}-->
            <!--{/if}-->
            <!--{loop $hbcat $cat}-->
            <a href="javascript:;" class="weui-navbar__item hscat" data-id="{$cat[id]}" data-shid="$v[shid]">
                <span>{$cat[name]}</span>
            </a>
            <!--{/loop}-->
            <a href="javascript:;" class="weui-navbar__item hscat" data-shid="$v[shid]">
                <span>{lang xigua_hs:fans}</span>
            </a>
        </div>

    </div>


<div class="view_content mod-post x-postlist p0 comment_ul" id="list"><article class="weui-article f14">
        <section>
            <p>{echo hs_nl2br($v['jieshao']);}</p>
            <!--{loop $v[append_img] $__k $__v}-->
            <p><img src="{$__v}" /></p>
            <p>{echo hs_nl2br($v[append_text][$__k]);}</p>
            <!--{/loop}-->
            <!--{if $hs_config[showalbum]}-->
            <!--{loop $v[album] $__k $__v}-->
            <p><img src="{$__v}" /></p>
            <!--{/loop}-->
            <!--{/if}-->
        </section>
    </article>
</div>

<div class="none" id="hscat_profile">
    <article class="weui-article f14">
        <section>
            <p>{echo hs_nl2br($v['jieshao']);}</p>
            <!--{loop $v[append_img] $__k $__v}-->
            <p><img src="{$__v}" /></p>
            <p>{echo hs_nl2br($v[append_text][$__k]);}</p>
            <!--{/loop}-->
            <!--{if $hs_config[showalbum]}-->
            <!--{loop $v[album] $__k $__v}-->
            <p><img src="{$__v}" /></p>
            <!--{/loop}-->
            <!--{/if}-->
        </section>
    </article>
</div>

<!--{eval
if(0 && !IN_PROG && is_file(DISCUZ_ROOT."source/plugin/xigua_re/hook.class.php")):
include_once DISCUZ_ROOT."source/plugin/xigua_re/hook.class.php";
$authorinfo = getuserbyuid($v['uid']);
$postlist[0]['authorid'] = $v['uid'];
$postlist[0]['first'] = 1;
$postlist[0]['groupid'] = $authorinfo['groupid'];
$postlist[0]['subject'] = cutstr(strip_tags($v['jieshao']),40);
$postlist[0]['pid'] = 'hs_'.$v['id'];
$_G['fid'] = 0;
global $ispc;
$ispc = 1;
$ret = mobileplugin_xigua_re_forum::viewthread_postbottom_mobile_output();
echo $ret[0];
endif;
}-->


<!--{if $_G['cache']['plugin']['xigua_dp'] && in_array('hs', unserialize($_G['cache']['plugin']['xigua_dp']['opens']))}-->
<style>.gzbtn{background-color:$config[maincolor]}</style><div id="ptdiv2" style="display:none"></div>
<script>
$.ajax({type: 'get',dataType: 'xml',
    url: '$SCRITPTNAME?id=xigua_dp&ac=jingxuan&inajax=1&type=sh&typeid=$shid&pagesize=5&page=1',
    success: function (data) {
        if(null==data){ $('#ptdiv2').remove(); return false;}
        var s = data.lastChild.firstChild.nodeValue;
        if(!s){ $('#ptdiv2').remove(); return false;}
        $('head').append('<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?{VERHASH}" />');
        $('body').append('<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"><\/script>');
        $('#ptdiv2').html(s).show();
    },
    error: function () {$('#ptdiv2').remove();}
});
</script>
<!--{eval $hs_config[closept] = 1;}-->
<!--{/if}-->
<!--{if !$hs_config[closept]}-->
<div id="comment_profile" class="mt10">
    <div class="view_content mod-post x-postlist p0 comment_ul" id="clist">
        <div class="weui-cells__title weui_title mt0 f15" id="comment_ul_first">
            {lang xigua_hs:pinglunc}
            <a class="y c9 pr_1 do_comment" href="javascript:;" data-id="$shid" >{lang xigua_hs:woyao}<i class="f13 iconfont icon-jinrujiantou"></i></a>
        </div>
    </div>
    <a href="javascript:;" id="comment_ul_more" class="weui-media-box weui-media-box_appmsg" style="display:none;background:#fff" onclick="comment_profile('$shid')">
        <div class="weui-media-box__bd">
            <p class="weui-media-box__desc tc mt0 c9">{lang xigua_hb:morehuifu}</p>
        </div>
    </a>
</div>
<!--{/if}-->

    <!--{if $v[hong_num] && in_array('hongbao', $vipinfo['access'])}-->
    <div class="weui-cells__title weui_title border_none"><span><i class="iconfont icon-hongbao2 vm f18 main_color "></i> {lang xigua_hb:yiqiang}<em class="color-red">$v[hong_sendnum]</em>/$v[hong_num]{lang xigua_hb:fen}</span>  <!--{if $v[hong_sendnum]}--><a class="y c9" href="$SCRITPTNAME?id=xigua_hs&ac=hong_list&shid=$shid{$urlext}">{lang xigua_hb:kk}<i class="f13 iconfont icon-jinrujiantou"></i></a><!--{/if}--></div>
    <div class="weui-cells after_none" id="hong_preview_list"></div>
    <!--{/if}-->
<!--{if !IN_PROG && $v[hong_num]>$v[hong_sendnum]  && !$v[hongbaolog]}-->
<a href="javascript:;"  style="position: fixed;right: .5rem;bottom: 15rem;z-index:99" <!--{if $_G[uid]}--> <!--{if $v[hbtiaojian]}-->onclick="return showfxhs();"<!--{else}-->class="qiang"<!--{/if}--> <!--{else}-->onclick="return checklogin();"<!--{/if}-->><img src="source/plugin/xigua_hb/static/img/hbic.png" style="width: 3rem;display: block;"></a>

    <!--{if 1}-->
    <div class="hong_res animated zoomIn" id="hong_res">
        <a class="hong_close"><i class="iconfont icon-guanbijiantou f22"></i></a>
        <div class="hong_res_wrap">
            <div class="hong_res_head">
                <div class="hong_res_head_in">
                    <img src="{avatar($v['uid'], 'big', true)}">
                </div>
            </div>
            <div class="hong_res_cnt">
                <div class="hong_res_box">
                    <p>{$v[user][username]}</p>
                    <p>{lang xigua_hb:maile}</p>
                </div>
                <div class="hong_res_list">
                    <div class="send_title"></div>
                    <div class="hong_tip">{lang xigua_hb:gongxihou}</div>
                    <div class="money_bg">
                        <p class="hong_money">
                            <i>&yen;</i>
                            <span id="hong_size"></span>
                            <em>{lang xigua_hb:yuan}</em>
                        </p>
                    </div>
                    <a <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jumpDownload();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao&mobile=2"<!--{/if}--><!--{/if}--> class="sub_title">{lang xigua_hb:zidongfang}</a>
                </div>
            </div>
            <div class="view_oth">
                <a href="$SCRITPTNAME?id=xigua_hs&ac=hong_list&shid=$shid{$urlext}">{lang xigua_hb:kkdaj}</a>
            </div>
            <div class="sub_bg"></div>
        </div>
    </div>
    <div class="hong_res hong_box" id="hong_box">
        <div class="hong_box_main zoomIn animated ">
            <div class="hong_box_title">
                <div class="send_title"></div>
                <div class="hong_star"></div>
                <div class="hong_box_showname">
                    <p>{lang xigua_hb:zongji}{$v[hong_money]}{lang xigua_hb:yuan}</p>
                </div>
                <div class="hong_btn animated" id="hong_btn" onclick="showHongBox(this);">
                    <div class="hong_btn_mask"></div>
                    <a href="javascript:;"> </a>
                </div>
            </div>
            <div class="hong_from">
                <p>{$v[user][username]}</p>
                <p>{lang xigua_hb:mai}</p>
            </div>
            <div class="view_oth">
                <p>{lang xigua_hb:lingqu}{$config['tname']}{lang xigua_hb:qb}</p>
            </div>
            <div class="sub_bg"></div>
        </div>
    </div>
    <!--{/if}-->
    <!--{if $config[voice]}-->
    <div class="none"><audio id="media" preload="preload"><source src="{$config[voice]}" type="audio/mpeg" /></audio></div>
    <!--{/if}-->
    <!--{if !$_G[uid]}-->
    <script>
        function checklogin(){
            $.showLoading();
            $.ajax({
                type: 'get',
                url: '$SCRITPTNAME?id=xigua_hb&ac=my&inajax=1',
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }
    </script>
    <!--{/if}-->
    <!--{if 1}-->
    <script>
        var HAS_QIANG = 0, Qlock =0;
        function showHongBox(obj) {
<!--{if $v[hbtiaojian]<=0}-->
            $('#wechat-mask').hide();
            if(Qlock || HAS_QIANG){ console.log('false'); return false;}
            Qlock = 1;
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hs&ac=qiang&shid=$v[shid]&inajax=1',
                data: {'formhash':FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    if(s.indexOf('success')!==-1){
                        HAS_QIANG = 1;
                        $('#hong_box').removeClass('show').hide();
                        $('#hong_res').show();
                        $('#hong_size').html(s.split('|')[1]);
                        $('.fix-bottom').hide();
                    }else{
                        $('#hong_box').removeClass('show').hide();
                        tip_common(s);
                    }
                },
                error: function () {
                }
            });
<!--{/if}-->
        }
        function focusHongBao(){
<!--{if $v[hbtiaojian]>0}-->return false;<!--{/if}-->
<!--{if $config[subscribe] && !getcookie('miniprogram')&& HB_INWECHAT}-->
var unscb = 0;
$.showLoading();
$.ajax({
    type: 'get',
    url: _APPNAME + '?id=xigua_hb&ac=checksub&inajax=1',
    data: {formhash: FORMHASH},
    dataType: 'xml', async:false,
    success: function (data) {
        if (null == data) { return false; }
        var s = $.trim(data.lastChild.firstChild.nodeValue);
        if (s.split('|')[1] != 'subscribe') {  unscb = 1; }
        $.hideLoading();
    }
});
$.hideLoading();
if(unscb){
    $.alert("<img src=$SCRITPTNAME?id=xigua_hb:qrauto&ode=sh_{$v[shid]}{$urlext} /><br>{lang xigua_hb:gzq}", "{lang xigua_hb:gzqchangan}");
    return false;
}
<!--{/if}-->
            if(!HAS_QIANG) {
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_hb&ac=qchk&inajax=1',
                    data: {'formhash':FORMHASH},
                    dataType: 'xml',
                    success: function (data) {
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        if(s.indexOf('success')!==-1){
                            $('#hong_box').addClass('show').show();
                        }else{
                            $('#hong_box').removeClass('show').hide();
                            tip_common(s);
                        }
                    }
                });
            }else{
                $.toast('{lang xigua_hb:qianguole}', 'error');
            }
            $.ajax({
                type: 'post',
                url: _APPNAME +'?id=xigua_hs&ac=incr&incr_type=shares&shid=$shid&inajax=1',
                data: {'formhash':FORMHASH},
                dataType: 'xml'
            });
        }
    </script>
    <!--{/if}-->

<!--{if HB_INWECHAT &&$v[hbtiaojian]<=0}-->
    <script>
        <!--{if $config[onlytimeline]=='no'}-->
        function menuShareGet(){
            <!--{else}-->
            function menuShareTimeline(){
                <!--{/if}-->
                focusHongBao();
            }
            function menuShareTimelineErr(){
                $.toast('{lang xigua_hb:quxiaofenxiang}');
                $('#wechat-mask').hide();
            }
            function menuShareCommon(){
                <!--{if $config[onlytimeline] == 'pyq'}-->
                $.toast('{lang xigua_hb:fenxiangqiang}');
                $('#wechat-mask').hide();
                <!--{else}-->
                if(typeof 'menuShareTimeline'!=='undefined'){
                    menuShareTimeline();
                }
                if(typeof 'menuShareGet'!=='undefined'){
                    menuShareGet();
                }
                <!--{/if}-->
            }
            function menuShareCommonErr(){
                menuShareTimelineErr();
            }
    </script>
    <!--{elseif IN_MAGAPP}-->
    <script>
        function menuShareGet() {
            <!--{if $config[onlytimeline]=='py'}-->
            mag.share('ALL', function (res) {
                focusHongBao();
            });
            <!--{/if}-->
            <!--{if $config[onlytimeline]=='pyq'}-->
            mag.share('WEIXIN_CIRCLE', function (res) {
                focusHongBao();
            });
            <!--{/if}-->
            <!--{if $config[onlytimeline]=='no'}-->
            focusHongBao();
            <!--{/if}-->
        }
    </script>
    <!--{elseif IN_QIANFAN}-->
    <script>
        <!--{if $config[onlytimeline]=='py'}-->
        $(document).on('click', '.qiang', function(){
            QFH5.openShareDialog();
        });
        function openShareDialog(){
            focusHongBao();
        }
        <!--{/if}-->
        <!--{if $config[onlytimeline]=='pyq'}-->
        $(document).on('click', '.qiang', function(){
            QFH5.openShare(1);
        });
        function openShare(){
            focusHongBao();
        }
        <!--{/if}-->
        <!--{if $config[onlytimeline]=='no'}-->
        $(document).on('click', '.qiang', function(){
            focusHongBao();
        });
        <!--{/if}-->
    </script>
    <!--{elseif IN_APPBYME}-->
    <script>
        <!--{if $config[onlytimeline]=='py'}-->
        connectSQJavascriptBridge(function(){
            sq.setShareCallBack(function(data){
                if(data.errmsg=='SHARE_OK'||1){
                    focusHongBao();
                }
            });
        });
        <!--{/if}-->
        <!--{if $config[onlytimeline]=='pyq'}-->
        connectSQJavascriptBridge(function(){
            sq.setShareCallBack(function(data){
                if(data.errmsg=='SHARE_OK'||1){
                    focusHongBao();
                }
            });
        });
        <!--{/if}-->
        <!--{if $config[onlytimeline]=='no'}-->
        $(document).on('click', '.qiang', function(){
            focusHongBao();
        });
        <!--{/if}-->
    </script>
    <!--{else}-->
        <!--{if $config[onlytimeline]=='no'}-->
<script>
$(document).on('click', '.qiang', function(){
    focusHongBao();
});
</script>
        <!--{/if}-->
    <!--{/if}-->
<!--{/if}-->
<!--{if !(IN_MAGAPP || IN_QIANFAN || IN_APPBYME)}-->
<!--{eval
$upar = parse_url(hb_currenturl());
$yuanurl = $upar[scheme].'://'.$upar[host].$upar[path]."?id=xigua_hs&ac=v&s=$shid&x=1&st=".$v['stid'].'&idu='.$_G['uid'];
$hb_currenturl = urlencode($yuanurl);
$_qrfile = './source/plugin/xigua_hs/cache/' . md5($yuanurl) . '.jpg';
if (!is_file(DISCUZ_ROOT . $_qrfile)) :
    @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
    if(class_exists('QRcode')):
        QRcode::png($yuanurl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
    endif;
endif;
if($_G['cache']['plugin']['xigua_hx'] ):
$hb_currenturlx = urlencode('https://'.$upar[host].$upar[path]."?id=xigua_hs&ac=v&s=$shid&x=1&st=".$v['stid'].'&idu='.$_G['uid']);
$shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&logo='.urlencode($shdata[logo]).'&url='.$hb_currenturlx;
endif;
}-->
<!--{/if}-->
<div id="shqr" class="shqr">
    <div class="cl">
        <div class="shqr_h1">
            <img src="$shqr" onerror="this.error=null;$('#shqr').addClass('shqrmid');$('.shqr_h1').remove();">
            <p class="f14"><em class="main_color">{$v[name]}</em>&#19987;&#23646;&#23567;&#31243;&#24207;&#30721;</p>
        </div>
        <div class="shqr_h2">
<!--{if $config[qraut]}-->
<img src="$SCRITPTNAME?id=xigua_hb:qrauto&ode=sh_{$v[shid]}{$urlext}" onerror="this.error=null;$('#shqr').addClass('shqrmid');$('.shqr_h2').remove();" />
<!--{else}-->
<img src="$_qrfile" onerror="this.error=null;$('#shqr').addClass('shqrmid');$('.shqr_h2').remove();">
<!--{/if}-->
            <p class="f14"><em class="main_color">{$v[name]}</em>&#19987;&#23646;&#20108;&#32500;&#30721;</p>
        </div>
    </div>
</div>
<!--{eval $showbtns = unserialize($hs_config[showbtn]);}-->
    <div class="footer_fix"></div>
    <div class="view_bottom weui-flex border_top">
        <!--{if in_array(1, $showbtns)}-->
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hs{$urlext}" class="weui-tabbar__item ">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-shoplight weui-tabbar__icon f26"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_hs:youdian}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if in_array(2, $showbtns)}-->
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_hs&ac=enter&from=hs{$urlext}" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-fabu weui-tabbar__icon f22"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_hs:shangjiaruzhu}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if in_array(5, $showbtns)}-->
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_dp&ac=add&type=sh&typeid=$shid&shid=$shid{$urlext}" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-bianji weui-tabbar__icon f22"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_dp:xdp}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if in_array(3, $showbtns)}-->
        <div class="view_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_dp&ac=top&type=sh&typeid=$shid{$urlext}" class="weui-tabbar__item">
                    <span style="display: inline-block;position: relative;">
                        <i class="iconfont icon-sixin2 f26 weui-tabbar__icon"></i>
                    </span>
                <p class="weui-tabbar__label">{lang xigua_dp:dp}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if $kflnk&&in_array(4, $showbtns)&& $v['uid']}-->
        <!--{eval
        if(!(IN_QIANFAN||IN_MAGAPP) && ($config[magapp_secret] || $config[hostname])):
            $kflnk = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=$v[uid]";
        endif;
        }-->
        <div class="view_bottom_z">
            <a href="$kflnk" class="weui-tabbar__item">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-kefu1 f22 weui-tabbar__icon"></i>
                </span>
                <p class="weui-tabbar__label">{lang xigua_hb:kefu1}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if $config[showguide]||!HB_INWECHAT}-->
        <div class="view_bottom_z">
            <a href="javascript:;" <!--{if IN_MAGAPP}-->onclick="return mag.share('ALL', function(res){});"<!--{elseif IN_QIANFAN}-->onclick="QFH5.openShareDialog();"<!--{/if}-->  class="weui-tabbar__item hs_share" data-id="$v[shid]">
            <span style="display: inline-block;position: relative;">
                <i class="iconfont icon-fenxiang1 weui-tabbar__icon f28"></i>
            </span>
            <p class="weui-tabbar__label">{lang xigua_hb:shares}</p>
            </a>
        </div>
        <!--{/if}-->
        <!--{if in_array('zxsk', $vipinfo['access'])}-->
        <div class="view_bottom_z" style="background:#E96B6A">
<!--            <a href="javascript:;" class="weui-tabbar__item" id="lijifuk">-->
            <a href="$SCRITPTNAME?id=xigua_hs&ac=cmt&do=add&shid=$shid{$urlext}" class="weui-tabbar__item">
                <span style="display: inline-block;position:relative;">
                    <i class="iconfont icon-yongjin1 weui-tabbar__icon color-white f22"></i>
                </span>
                <p class="weui-tabbar__label color-white">{lang xigua_hs:zxfk}</p>
            </a>
        </div>
        <!--{/if}-->
        <div class="weui-flex__item view_bottom_y">
            <!--{if $shtel}-->
            <a href="$shtel" class="mc_bg"><i class="iconfont icon-unie607"></i> {lang xigua_hb:boda}</a>
            <!--{else}-->
            <a href="javascript:;" style="background:#9e9e9ecc!important;" class="mc_bg">{lang xigua_hb:yiguoqi}</a>
            <!--{/if}-->
        </div>
    </div>

</div>

<!--{if in_array('zxsk', $vipinfo['access'])}-->
<!--{template xigua_hs:fukuan_popup}-->
<!--{/if}-->

<div id="history_popup" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <div class="weui-cells__title">$v[name]{lang xigua_hs:lishigonggao}</div>
            <div class="weui-panel weui-panel_access">
                <div class="weui-panel__bd panel_list" id="history_outer"></div>
            </div>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>

        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:close}</a>
        </div>
    </div>
</div>

<div id="comment_popup" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <div class="weui-cells weui-cells_form">
                <div class="weui-cell">
                    <div class="weui-cell__hd"><img src="$v[logo]" class="weui-img"></div>
                    <div class="weui-cell__bd">
                        <p>{$v[name]}</p>
                    </div>
                    <div class="weui-cell__ft"></div>
                </div>

                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <textarea class="weui-textarea" id="comment_content" placeholder="{lang xigua_hs:say}" rows="3"></textarea>
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <div class="weui-uploader">
                            <div class="weui-uploader__hd">
                                <p class="weui-uploader__title">{lang xigua_hs:upload}</p>
                                <div class="weui-uploader__info">{lang xigua_hs:maxupload}{$hs_config[maxcmtpic]}{lang xigua_hs:zphoto}</div>
                            </div>
                            <div class="weui-uploader__bd">
                                <ul class="weui-uploader__files" data-max="$hs_config[maxcmtpic]" data-maxtip="{lang xigua_hs:maxupload}{$hs_config[maxcmtpic]}{lang xigua_hs:zphoto}">
                                </ul>
                                <div class="weui-uploader__input-box">
                                    <!--{if HB_INWECHAT && $config[multiupload]}-->
                                    <a class="weui-uploader__input" data-name="comment_photo" data-multi="1"></a>
                                    <!--{else}-->
                                    <input class="weui-uploader__input" data-name="comment_photo" type="file" data-multi="1">
                                    <!--{/if}-->
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>

        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary comment_tijiao" data-id="$shid" >{lang xigua_hs:tijiao}</a>
            <a class="weui-btn weui-btn_default close-popup" >{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>

<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div id="popctrl" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__modal">

        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn weui-btn_primary" data-method="confirm" onclick="$.closePopup('#popctrl');$('#comment_popup').popup();">{lang xigua_hb:queding}</a>
            <a class="weui-btn weui-btn_default" data-method="destroy" onclick="$.closePopup('#popctrl');$('#comment_popup').popup();">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>

<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->
<script>$('#loading-show').addClass('hidden');$('#loading-none').addClass('hidden');</script>
<!--{template xigua_hs:enter_up}-->
<script>
    var TIMELINE_TITLE = '{$navtitle}';
    if($('#driving').length>0){
        var driv = $('#driving'), dnt = 0;
        var drivInterval=setInterval(function () {
            hs_getlocation(function(position){
                $.ajax({
                    type: 'post',
                    url: _APPNAME +'?id=xigua_hs&ac=driving&shid='+driv.data('id')+'&inajax=1&from='+(position.latitude||position.lat) + ','+ (position.longitude||position.lng),
                    data: {'formhash':FORMHASH},
                    dataType: 'xml',
                    success: function (data) {
                        if(null==data){return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        var sary = s.split('|');
                        if(sary[0]=='success'){
                            $('#driving').show().html(sary[1]);
                        }
                        clearInterval(drivInterval);
                    },
                    error: function () { clearInterval(drivInterval); $('#driving').hide(); }
                });
            });
            dnt++;
            if(dnt>= 2){
                clearInterval(drivInterval);
                $('#driving').show().html('');
            }
        }, 2000);
    }
    if($('#hong_preview_list').length>0){
        load_common_list('$SCRITPTNAME?id=xigua_hs&ac=hong_li&shid=$shid&inview=1&inajax=1&pagesize=5', 'hong_preview_list');
    }
    $(function () {
        <!--{if $_G['uid'] && $v[hong_num]>0 && $v[hong_num]==$v[hong_sendnum] && !$v[hongbaolog]}-->
        if(!localStorage.getItem('hstip_{$shid}')){
            // $.toast('{lang xigua_hb:qiangwan}', 2000);
            localStorage.setItem('hstip_{$shid}', 1);
        }
        <!--{/if}--><!--{if $hs_config[mustfollow]}-->
        $(document).on('click', '.qiang', function(){
            if($('.do_follow').data('wei')==1){
                $('.do_follow').trigger('click').removeAttr('data-wei');
            }
        });
        <!--{/if}-->
        <!--{if !$v[endts]}-->
        $.toast('{lang xigua_hs:gaishangjia}{lang xigua_hs:yiguoqi}');
        <!--{/if}-->
    });
    comment_profile('$shid');
<!--{if !($v[hong_num]>$v[hong_sendnum]  && !$v[hongbaolog])}-->
if("undefined" === typeof menuShareCommon) {
    function menuShareCommon(){
        $.ajax({
            type: 'post',
            url: _APPNAME + '?id=xigua_hs&ac=incr&incr_type=shares&shid=$shid&inajax=1',
            data: {'formhash': FORMHASH},
            dataType: 'xml'
        });
    }
}
if("undefined" === typeof menuShareTimeline) {
    function menuShareTimeline(){
        $.ajax({
            type: 'post',
            url: _APPNAME + '?id=xigua_hs&ac=incr&incr_type=shares&shid=$shid&inajax=1',
            data: {'formhash': FORMHASH},
            dataType: 'xml'
        });
    }
}
<!--{/if}-->
<!--{if $v[mp3]}-->
if($('#auto_play').length){
    var media_filed= $('#auto_play');
    media_filed[0].play();
    $(document).on('click', '#audio_btn', function () {
        if ($(this).hasClass('play_yinfu')) {
            $(this).addClass('off');
            $(this).removeClass('play_yinfu');
            $('#yinfu').removeClass('rotate');
            media_filed[0].pause();
        } else {
            $(this).addClass('play_yinfu');
            $(this).removeClass('off');
            $('#yinfu').addClass('rotate');
            media_filed[0].play();
        }
    });
}
<!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_hr']['qy_musthr'] && !$veris2}-->
$.alert("{lang xigua_hr:sjrzzwfck}", function() {
    hb_jump("$SCRITPTNAME?id=xigua_hs&mobile=2{$urlext}");
});
<!--{/if}-->
<!--{if in_array('zxsk', $vipinfo['access'])}-->
$(document).on('click','#lijifuk', function () {
    $('#pay_ctrl').popup();
});
<!--{/if}-->
<!--{if $_GET[lijifuk]}-->
<!--{eval dheader("Location: $SCRITPTNAME?id=xigua_hs&ac=cmt&do=add&shid=$shid");}-->
<!--{/if}-->
if(localStorage.getItem('shwetip_$shid')){
    setTimeout(function(){
        $('.hs_share').trigger('click');
    }, 150);
    localStorage.removeItem('shwetip_$shid');
}
</script>
<!--{if is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php') && is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/touch/hsrw_view.php')}-->
<!--{template xigua_hs:hsrw_view}-->
<!--{/if}-->