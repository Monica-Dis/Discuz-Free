<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval include DISCUZ_ROOT.'source/plugin/xigua_hs/include/c_enter.php';}-->
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<style>.weui-popup__overlay, .weui-popup__container{z-index:502}</style>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->

    <form action="$SCRITPTNAME?id=xigua_hs&ac=enter" method="post" id="form" enctype="multipart/form-data">
        <!--{loop $_GET $key $item}-->
        <input type="hidden" name="$key" value="{$item}">
        <!--{/loop}-->
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="referer" value="{$_SERVER[HTTP_REFERER]}">
        <!--{if $old_data}--><input type="hidden" name="shid" value="{$old_data[shid]}" /><!--{/if}-->
        <!--{if $old_data['stid']}-->
        <input type="hidden" name="st" value="{$old_data['stid']}">
        <!--{/if}-->
        <input type="hidden" name="form[lat]" value="{echo $getlat ? $getlat: $old_data['lat']}">
        <input type="hidden" name="form[lng]" value="{echo $getlng ? $getlng: $old_data['lng']}">
        <input type="hidden" id="formprovince" name="form[province]" value="{echo $_GET[province] ? $_GET[province] : $old_data['province']}">
        <input type="hidden" id="formcity" name="form[city]" value="{echo $_GET[city] ? $_GET[city] : $old_data['city']}">
        <input type="hidden" id="formdistrict" name="form[district]" value="{echo $_GET[district] ? $_GET[district] : $old_data['district']}">
        <input type="hidden" name="form[street]" value="{echo $_GET[street] ? $_GET[street] : $old_data['street']}">
        <input type="hidden" name="form[street_number]" value="{echo $_GET[street_number] ? $_GET[street_number] : $old_data['street_number']}">

    <div class="weui-cells weui-cells_form mt0">
        <div class="weui-cell">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:shname}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[name]" type="text" value="{$old_data[name]}" placeholder="{lang xigua_hs:plzshname}">
            </div>
        </div>
        <!--{if $hs_config[showdq]}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:sjdq}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[diqu]" id="diqu" type="text" value="{echo $old_data ? $old_data[province].' '.$old_data[city].' '.$old_data[district] :'';}" placeholder="{lang xigua_hs:qxzsjdq}">
            </div>
            <div class="weui-cell__ft" id="needdiqu"></div>
        </div>
        <!--{/if}-->
        <div class="weui-cell weui-cell_vcode">
            <div class="weui-cell__hd">
                <label class="weui-label">{lang xigua_hs:addr}</label>
            </div>
            <div class="weui-cell__bd enter_addr">
                <input class="weui-input" name="form[addr]" type="text" value="{echo $_GET[addr] ? $_GET[addr] : $old_data[addr]}" placeholder="{lang xigua_hs:plzdingwei}">
            </div>
            <div class="weui-cell__ft">
                <!--{if $cannewmap}-->
                <a href="$newmapurl" class="weui-vcode-btn" type="button">{lang xigua_hs:dingwei}</a>
                <!--{else}-->
                <button class="weui-vcode-btn" id="openlocation" type="button">{lang xigua_hs:dingwei}</button>
                <!--{/if}-->
            </div>
        </div>
        <!--{if $quaninfo}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:suoshushangquan}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[shangquan]" id="shangquan" type="text" value="{$old_data[shangquan]}" placeholder="{lang xigua_hs:plzsuoshushangquan}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{/if}-->
        <!--{if $hs_config[maxhy]>1 && is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/touch/popup.php')}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:suoshuhangye}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" id="hangye" type="text" readonly value="$h_names" placeholder="{lang xigua_hs:djxz}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{else}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:suoshuhangye}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[hangye]" id="hangye" readonly type="text" value="<!--{if $old_data}-->$default<!--{/if}-->" placeholder="{lang xigua_hb:qingxuan}{lang xigua_hs:cat}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{/if}-->
        <!--{if $guimo}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:gm}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[guimo]" id="guimo" readonly type="text" value="{$old_data[guimo]}" placeholder="{lang xigua_hs:djxzgm}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{/if}-->
        <!--{if $hs_config[showopentime]}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:opentime}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[opentime]" id="opentime" type="text" value="{echo $old_data ? $old_data[opentime] : '8:00-21:00'}" placeholder="{lang xigua_hs:plzopentime}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{/if}-->
        <div class="weui-cell">
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:tel}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="form[tel]" type="tel" value="{$old_data[tel]}" placeholder="{lang xigua_hs:plztel}">
            </div>
        </div>

        <!--{if $old_data && $vipinfo['access'] && in_array('jieshao', $vipinfo['access'])}-->
        <div class="weui-cell weui-cell_access" onclick='$("#edit_jieshao").popup();'>
            <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:shangjiajieshao}</label></div>
            <div class="weui-cell__bd">
                <input class="weui-input" name="ignore_jieshao" value="{lang xigua_hs:plzshangjiajieshao}" id="jieshao" type="text" readonly placeholder="{lang xigua_hs:plzshangjiajieshao}">
            </div>
            <div class="weui-cell__ft"></div>
        </div>
        <!--{else}-->
    <!--{if !$old_data || ($old_data && $vipinfo['access'] && in_array('jieshao2', $vipinfo['access']))}-->
        <div class="weui-cell" id="access_jieshao2">
            <div class="weui-cell__bd">
                <textarea class="weui-textarea" name="form[jieshao]" placeholder="{lang xigua_hs:plzjieshao}" rows="3">{$old_data[jieshao]}</textarea>
            </div>
        </div>
    <!--{/if}-->
        <!--{/if}-->
    </div>

        <div class="weui-cells__title">{lang xigua_hs:shangjiaphoto}</div>
        <div class="weui-cells weui-cells_form">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_hs:shlogo}</p>
                            <div class="weui-uploader__info">{lang xigua_hs:plzshlogo}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[logo]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[logo])"><input type="hidden" name="form[logo][]" value="$old_data[logo]"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[logo]" type="file"></a>
                                <!--{else}-->
                                <input  class="weui-uploader__input" data-name="form[logo]" type="file">
                                <!--{/if}-->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
<!--{if !$old_data || ($old_data && $vipinfo['access'] && in_array('qr', $vipinfo['access']))}-->
            <div class="weui-cell" id="access_qr" <!--{if !$hs_config[shqr]}-->style="display:none"<!--{/if}-->>
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_hs:qr}</p>
                            <div class="weui-uploader__info">{lang xigua_hs:plzqr}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[qr]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[qr])"><input type="hidden" name="form[qr][]" value="$old_data[qr]"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[qr]" type="file"></a>
                                <!--{else}-->
                                <input  class="weui-uploader__input" data-name="form[qr]" type="file">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<!--{/if}-->
<!--{if !$old_data || ($old_data && $vipinfo['access'] && in_array('album', $vipinfo['access']))}-->
        <div class="weui-cell" id="access_album">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_hs:shalbum}</p>
                            <div class="weui-uploader__info">{echo str_replace('n', $hs_config['maximg'], lang_hs('zuiduozhao',0))}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{$hs_config['maximg']}" data-maxtip="{echo str_replace('n', $hs_config['maximg'], lang_hs('zuiduozhao',0))}">
                                <!--{loop $old_data[album] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1"></a>
                                <!--{else}-->
                                <input  class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <!--{/if}-->
                            </div>
                        </div>

                    </div>
                </div>
            </div>
<!--{/if}-->
<!--{if $showv}-->
<div class="weui-cell none" id="vycanshow">
    <div class="weui-cell__bd">
        <div class="weui-uploader">
            <div class="weui-uploader__hd">
                <p class="weui-uploader__title">{lang xigua_hs:sjsp}</p>
                <div class="weui-uploader__info">{lang xigua_hs:zdsc}<span id="maxsizev">{$vipinfo[maxsize]}</span>{lang xigua_hs:mbsp}</div>
            </div>
            <div class="weui-uploader__bd">
                <ul class="weui-uploader__files weui_videos"></ul>
                <div class="weui-uploader__input-box">
                    <input class="weui-uploader__input_video" data-name="form[video]" type="file" accept="video/*">
                </div>
            </div>
        </div>
    </div>
</div>
<!--{template xigua_hs:video}-->
<!--{/if}-->
        </div>

        <!--{if $old_data && $vipinfo['access']}-->
        <div class="weui-cells__title">{$vipinfo[name]} <a href="javascript:;" id="vipAbout" onclick="$('#vipAbout__text').popup()" class="y main_color">{lang xigua_hs:banbenqubie}</a></div>
        <div class="weui-cells weui-cells_form">
            <!--{loop $vipinfo['access'] $as}-->
            <!--{if $form_access_list[$as]}-->
            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd"><label for="" class="weui-label">{$access_list[$as]}</label></div>
                <div class="weui-cell__bd enter_addr">
                    <!--{if $as =='link'}-->
                    <input id="choose_{$as}" readonly="readonly" onclick="$('#vipLink__text').popup();" class="weui-input" type="text" value="{$old_data[$as]}" placeholder="{$form_access_list[$as]}" >
                    <!--{elseif $as =='color'}-->
                    <input id="choose_{$as}" class="weui-input" name="form[{$as}]" type="text" value="{$old_data['color_title']}" placeholder="{$form_access_list[$as]}" data-value="{$old_data[$as]}">
                    <!--{else}-->
                    <input id="choose_{$as}" class="weui-input" name="form[{$as}]" type="text" value="{$old_data[$as]}" placeholder="{$form_access_list[$as]}">
                    <!--{/if}-->
                </div>
            </div>
            <!--{/if}-->
            <!--{/loop}-->
        </div>
        <!--{/if}-->

<!--{if !$old_data}-->
        <div class="weui-cells__title"><span id="subt">{lang xigua_hs:ruzhutype}</span>
            <!--{if $_G['cache']['plugin']['xigua_hk']['allowjhmrz']}-->
            <a href="javascript:;" id="syjhm" class=" main_color" style="margin-left:.25rem">{lang xigua_hs:syjhmrz}</a>
            <!--{/if}-->
            <a href="javascript:;" id="vipAbout" onclick="$('#vipAbout__text').popup()" class="y main_color">{lang xigua_hs:banbenqubie}</a></div>

<!--{if $showv}--><!--{eval $bgfc = hs_hex2rgb($config[maincolor], .06);}--><link rel="stylesheet" href="source/plugin/xigua_hs/static/resume.css" /><style>.car-type .car-year-season{background-color:$config[maincolor];}.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}.car-type .type-item-active:after{border-color:$config[maincolor]}.car-type .type-item-active {background:$bgfc}
.car-type .type-item:nth-child(2n){margin-right:0}.car-type .type-item:nth-child(1),.car-type .type-item:nth-child(2){margin-top:0}
.car-type .type-item {float: left;width: calc((100vw - 2.1rem) / 2);margin-top:.5rem;padding-left:1rem}
</style><div id="dftvip" class="cl car-type"><div class="type-item-box cl" style="display:block">
<!--{loop $vips $k $v}-->
<!--{if $v[hide]}-->
<!--{eval unset($vips[$k]);}-->
<!--{/if}-->
<!--{/loop}-->
<!--{loop array_values($vips) $k $v}-->
<!--{if $needsafe && $v[price]>0}-->
<!--{eval $safecnt++; continue;}-->
<!--{/if}-->
    <label for="s{$v[id]}" class="type-item J_ping <!--{if $k==0}-->type-item-active<!--{else}-->type-item-gray<!--{/if}-->">
        <input type="radio" data-access_qr="{echo in_array('qr', $v['access'])?1:0;}" data-access_album="{echo in_array('album', $v['access'])?1:0;}" data-access_jieshao2="{echo in_array('jieshao2', $v['access'])?1:0;}" data-acs="{echo in_array('video', $v['access'])?$v[maxsize]:0;}" class="none typevip" name="form[viptype]" value="{$v[id]}" id="s{$v[id]}" <!--{if $k==0}-->checked="checked"<!--{/if}-->>
        <div class="type-title">{$v[name]} <!--{if $v[icon]}--><img src="{$v[icon]}" style="width:.7rem;height:.7rem;align-items:center;vertical-align: middle;"><!--{/if}--></div>
        <div class="car-sku-year cl">
            <div class="type-discount">
                <span class="car-logo" id="car_vip_{$v[id]}">{$v[udays]}</span>
            </div>
            <!--{if $v[customdesc]}-->
            <div class="car-tip">$v[customdesc]</div>
            <!--{/if}-->
            <!--{if $v[discount]==1}-->
            <div class="car-tip">{lang xigua_hs:mffbxx}</div>
            <!--{elseif $v[freeday]>0}-->
            <div class="car-tip">{lang xigua_hs:mtq}<em class="color-red2">$v[freeday]{lang xigua_hs:tiao}</em>{lang xigua_hs:xxmf}</div>
            <!--{/if}-->
            <!--{if $showv && in_array('video', $v['access']) && $v[maxsize]}-->
            <div class="car-year-season ">{lang xigua_hs:scsqsp}</div>
            <!--{else}-->
            <div class="type-origin "><!--{if $v[discount]>1}-->{lang xigua_hs:fbxxx}<em class="color-red2">{echo floatval($v[discount]/10)}{lang xigua_hs:zhe}</em><!--{/if}--></div>
            <!--{/if}-->
        </div>
        <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
    </label>
<!--{/loop}-->
    </div>
</div>
<!--{else}-->
        <div id="dftvip" class="weui-cells weui-cells_checkbox">
<!--{loop $vips $k $v}-->
<!--{if $v[hide]}-->
<!--{eval unset($vips[$k]);}-->
<!--{/if}-->
<!--{/loop}-->
<!--{loop array_values($vips) $k $v}-->
<!--{if $needsafe && $v[price]>0}-->
<!--{eval $safecnt++; continue;}-->
<!--{/if}-->
<label class="weui-cell weui-check__label J_ping2" for="s{$v[id]}">
    <div class="weui-cell__hd">
        <input type="radio" data-access_qr="{echo in_array('qr', $v['access'])?1:0;}" data-access_album="{echo in_array('album', $v['access'])?1:0;}" data-access_jieshao2="{echo in_array('jieshao2', $v['access'])?1:0;}" data-acs="{echo in_array('video', $v['access'])?$v[maxsize]:0;}" class="weui-check typevip" name="form[viptype]" value="{$v[id]}" id="s{$v[id]}" <!--{if $k==0}-->checked="checked"<!--{/if}-->>
        <i class="weui-icon-checked"></i>
    </div>
    <div class="weui-cell__bd">
        <p>{$v[name]} ( <em id="car_vip_{$v[id]}">{$v[udays]}</em> )</p>
        <!--{if $v[discount]==1}-->
        <p class="f12 main_color">{lang xigua_hs:mffbxx}</p>
        <!--{elseif $v[freeday]>0}-->
        <p class="f12 main_color">{lang xigua_hs:mtq} <em class="color-red2">$v[freeday]{lang xigua_hs:tiao}</em> {lang xigua_hs:xxmffb}</p>
        <!--{/if}-->
        <!--{if $v[discount]>1}-->
        <p class="f12">{lang xigua_hs:fbxxx} <em class="color-red2">{echo floatval($v[discount]/10)}{lang xigua_hs:zhe}</em> {lang xigua_hs:yh}</p>
        <!--{/if}-->
        <!--{if $showv && in_array('video', $v['access']) && $v[maxsize]}-->
        <p class="f12">{lang xigua_hs:scsqsp}</p>
        <!--{/if}-->
    </div>
</label>
<!--{/loop}-->
        </div>
<!--{/if}-->
        <div class="weui-cells weui-cells_form" id="inputcode" style="display: none">
            <div class="weui-cell ">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hk:jhm}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[cardno]" value="" placeholder="{lang xigua_hk:qsrjhm}">
                </div>
            </div>
        </div>
<script>
$(document).on('click','#syjhm', function () {
    var that = $(this);
    if(!that.hasClass('inputcode')){
        $('#dftvip').hide();
        $('#inputcode').show();
        that.addClass('inputcode').html('{lang xigua_hs:qx}');
        $('#subt').html('{lang xigua_hs:syjhmrz}');
    }else{
        $('#dftvip').show();
        $('#inputcode').hide();
        that.removeClass('inputcode').html('{lang xigua_hs:syjhmrz}');
        $('#subt').html('{lang xigua_hs:ruzhutype}');
    }
});
</script>
<!--{if $safecnt==count($vips) && $needsafe}--><script>$.alert('{lang xigua_hb:chyzbzc}', function() {window.location.href='$SCRITPTNAME?id=xigua_hs$urlext';});</script><!--{/if}-->

<!--{/if}-->

<!--{if $_G['cache']['plugin']['xigua_hr']['qy_musthr'] && !$ver2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_qy_ing($_G[uid])}-->
<!--{eval $curr = urlencode(hb_currenturl());}-->
<script>
$.modal({title: "{lang xigua_hr:tishi}",text: "{lang xigua_hr:qxwcqyrz}", buttons: [{ text: "{lang xigua_hr:djrz}", onClick: function(){hb_jump("$SCRITPTNAME?id=xigua_hr&ac=join&ct=2&shid={$old_data[shid]}&backto={$curr}{$urlext}");} },
{ text: "{lang xigua_hr:qx}", className: "default", onClick: function(){window.history.go(-1);} }]});
</script>
<!--{/if}-->

<!--{if $hs_config[openfzenter] && $_G['cache']['plugin']['xigua_st']}-->
<div class="weui-cells__title">{lang xigua_hs:fbdz}</div>
<div class="weui-cells">
    <!--{eval
        $hotcity = DB::fetch_all("select * from %t WHERE status=1 ORDER BY displayorder DESC", array('xigua_st'), 'stid');
    }-->
    <a class="weui-cell weui-cell_access" href="javascript:;">
        <div class="weui-cell__hd"><i class="iconfont icon-iconfenxiao color-dribbble"></i></div>
        <div class="weui-cell__bd">
            <input class="weui-input" id="site" name="form[stids]" placeholder="{lang xigua_hs:qxzzd}" type="text" value="{$old_data[stids]}">
        </div>
        <div class="weui-cell__ft"></div>
    </a>
</div>
<!--{/if}-->

        <label class="weui-agree mt10" onclick='$("#agree__text").popup();'>
            <input id="weuiAgree" type="checkbox" checked="checked" disabled readonly class="weui-agree__checkbox">
            <span class="weui-agree__text">
                {lang xigua_hb:agree}<a href="javascript:void(0);" >{lang xigua_hb:xiyi1}</a>
        </span>
        </label>


        <div class="fix-bottom" style="position: relative">
            <!--{if !$old_data}--><input name="hrvrifyid" type="hidden" value="$ver2[id]"><!--{/if}-->
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="<!--{if !$old_data}-->{lang xigua_hs:queren}<!--{else}-->{lang xigua_hs:queding}<!--{/if}-->">
        </div>

        <!--{if $old_data && $vipinfo['access'] && in_array('jieshao', $vipinfo['access'])}-->
        <div id="edit_jieshao" class="weui-popup__container">
            <!--        <div class="weui-popup__overlay"></div>-->
            <div class="weui-popup__modal bgf8">
                <div class="fixpopuper">
                    <div class="weui-cells__title">{lang xigua_hs:shprofile}</div>
                    <div class="weui-cells weui-cells_form">
                        <div class="weui-cell">
                            <div class="weui-cell__bd">
                                <textarea class="weui-textarea" name="form[jieshao]" placeholder="{lang xigua_hs:startprofile}" rows="3">{$old_data[jieshao]}</textarea>
                            </div>
                        </div>
                    </div>

                    <div class="weui-cells before_none nobg center_upload">
                        <div class="weui-cell" id="first_append_img">
                            <div class="weui-cell__bd">
                                <div class="weui-uploader">
                                    <div class="weui-uploader__bd">
                                        <div class="weui-uploader__input-box">
                                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                            <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                            <!--{else}-->
                                            <input class="center_upload__input" data-name="form[append_img]" type="file">
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!--{loop $old_data[append_img] $__k $__v}-->
                        <div class="weui-cell bgf" id="arear_{$__k}">
                            <ul id="cimg_{$__k}" data-only="1">
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url({$old_data['append_img'][$__k]})">
                                    <input type="hidden" name="form[append_img][{$__k}]" value="{$old_data['append_img'][$__k]}">
                                    <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                            </ul>
                            <div class="weui-cell__bd">
                                <textarea class="weui-textarea" placeholder="{lang xigua_hs:inputtext}" rows="3" name="form[append_text][{$__k}]">{$old_data['append_text'][$__k]}</textarea>
                            </div>
                            <a class="iconfont icon-guanbijiantou closeHt" data-index="{$__k}"></a>
                        </div>
                        <div class="weui-cell" id="cell_{$__k}">
                            <div class="weui-cell__bd">
                                <div class="weui-uploader">
                                    <div class="weui-uploader__bd">
                                        <div class="weui-uploader__input-box">
                                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                            <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                            <!--{else}-->
                                            <input class="center_upload__input" data-name="form[append_img]" type="file">
                                            <!--{/if}-->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--{/loop}-->
                    </div>

                    <div class="fix-bottom" id="center_upload_btn" style="position:relative">
                        <div class="weui-flex">
                            <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hs:close}</a>
                            <a class="mt0 ml15 half weui-btn weui-btn_primary center_upload_save" href="javascript:;">{lang xigua_hs:baocun}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--{/if}-->

        <!--{if $old_data && $vipinfo['access'] && in_array('link', $vipinfo['access'])}-->
        <div id="vipLink__text" class="weui-popup__container">
            <div class="weui-popup__modal">
                <div class="fixpopuper">

                    <div class="weui-cells">
                        <!--{eval $maxlink=range(1, $hs_config[maxlink]); }-->
                        <!--{loop $maxlink $_i $_v}-->
                        <div class="weui-cell  weui-cell_select-before">
                            <div class="weui-cell__hd before_none" style="flex:0.5">
                                <input name="form[links][font][$_i]" value="$old_data[links][font][$_i]" class="weui-input" type="text" placeholder="{lang xigua_hs:inputtext}">
                            </div>
                            <div class="weui-cell__bd">
                                <input name="form[links][link][$_i]" value="$old_data[links][link][$_i]" class="weui-input" type="text" placeholder="{lang xigua_hs:inputlink}">
                            </div>
                        </div>
                        <!--{/loop}-->
                    </div>

                    <div class="footer_fix"></div>
                    <div class="bottom_fix"></div>
                </div>
                <div class="fix-bottom">
                    <div class="weui-flex">
                        <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hs:close}</a>
                        <a class="mt0 ml15 half weui-btn weui-btn_primary center_upload_save" href="javascript:;">{lang xigua_hs:baocun}</a>
                    </div>
                </div>
            </div>
        </div>
        <!--{/if}-->
<!--{if $hs_config[maxhy]>1 && is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/touch/popup.php')}-->
<!--{template xigua_hs:popup}-->
<!--{/if}-->
    </form>

    <div id="mapouter" style="z-index:999" class="weui-popup__container">
        <!--    <div class="weui-popup__overlay"></div>-->
        <div class="weui-popup__modal">
            <div id="mapcontainer" ></div>
            <div class="fix-bottom">
                <div class="weui-flex">
                    <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                    <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
                </div>
            </div>

        </div>
    </div>

    <div id="popctrl" class="weui-popup__container">
<!--        <div class="weui-popup__overlay"></div>-->
        <div class="weui-popup__modal">

            <div style="height: 100vh"><img id="photo"></div>
            <div class="pub_funcbar">
                <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
                <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
            </div>
        </div>
    </div>

    <div id="agree__text" class="weui-popup__container">
<!--        <div class="weui-popup__overlay"></div>-->
        <div class="weui-popup__modal">
        <div class="fixpopuper">
            <article class="weui-article">
                <h1>{lang xigua_hb:xiyi}</h1>
                <section>
                    <section>
                        $config[xieyi]
                    </section>
                </section>
            </article>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:woyi}</a>
        </div>
        </div>
    </div>
    <div id="vipAbout__text" class="weui-popup__container">
<!--        <div class="weui-popup__overlay"></div>--><style>.gridtable table {font-family: verdana, arial, sans-serif;font-size: .7rem;color: #333333;border-width:.05rem;border-color: #666666;border-collapse: collapse;width:90vw;}.gridtable table th {border-width:.05rem;padding:.4rem;border-style: solid;border-color: #666666;background-color: #dedede;}.gridtable table td {border-width:.05rem;padding:.4rem;border-style: solid;border-color: #666666;background-color: #ffffff;}</style>
        <div class="weui-popup__modal">
        <div class="fixpopuper">
            <article class="weui-article">
                <!--{eval $vip_guides = DB::fetch_first('select subject,content from %t where 1 order by id desc', array('xigua_hs_vipguide'))}-->
                <h1><!--{if $vip_guides[subject]}-->{$vip_guides[subject]}<!--{else}-->{lang xigua_hs:banbenqubie}<!--{/if}--></h1>
                <section>
                    <section class="gridtable">
        <!--{if $vip_guides[content]}-->{$vip_guides[content]}<!--{else}-->{$hs_config[vipguide]}<!--{/if}-->
                    </section>
                </section>
            </article>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hs:wozhidao}</a>
        </div>
        </div>
    </div>
</div>

<script> +function($){  $.rawCitiesData = $cityjson; }($);</script>
<!--{if $hs_config['mkey']}--><script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$hs_config[mkey]}"></script><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_hs']['baidusdk']}--><script type="text/javascript" src="//api.map.baidu.com/api?v=2.0&ak={$_G['cache']['plugin']['xigua_hs']['baidusdk']}"></script><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_hs']['google']}--><script src="https://maps.googleapis.com/maps/api/js?key={$hs_config[google]}&sensor=false"></script><!--{/if}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<!--{template xigua_hs:footer}-->
<script>
    var chooseMapRes = [], chooseMapGoogle = [], OBJ = {};
    function setForm(lat, lng, deft){
        $.showLoading();
        $.ajax({
            type: 'get',
            url: location + '&ac=getloc&lat='+lat+'&lng='+lng+'&inajax=1',
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('error')!=-1){
                    tip_common(s);
                }else{
                    var _actions = [];
                    OBJ = jQuery.parseJSON(s.split('|')[1]);
                    if(deft){
                        setFormField(OBJ[0]);
                        return true;
                    }
                    for(var j in OBJ){
                        _actions.push({
                            text: OBJ[j].address,
                            className:'obj_ obj_'+j,
                            onClick: function() {  $.closePopup(); }
                        });
                    }
                    $.actions({ actions:_actions });
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    }
    function setFormField(subj){
        $("input[name='form[addr]']").val(subj.address);
        $("input[name='form[lat]']").val(subj.location.lat);
        $("input[name='form[lng]']").val(subj.location.lng);
        $("#formprovince").val(subj.address_component.province);
        $("#formcity").val(subj.address_component.city);
        $("#district").val(subj.address_component.district);
        $("input[name='form[street]']").val(subj.address_component.street);
        $("input[name='form[street_number]']").val(subj.address_component.street_number);
    }

    function setPoint(position){
        if(typeof position.type != 'undefined'){
            if(position.type == 'ip'){
                if(IGNORETIP){}else{
                    chooseMap(position);
                }
                return false;
            }
        }
        setForm((position.latitude||position.lat), (position.longitude||position.lng), 1);
    }
    function chooseMap(position) {
        if(typeof mag != 'undefined') {
            mag.mapPick(function (res) {
                setForm(res.lat, res.lng, 0);
            });
            return false;
        }
        <!--{if $_G['cache']['plugin']['xigua_hs']['google']}-->
        var myCenter=new google.maps.LatLng((position.latitude||position.lat), (position.longitude||position.lng));
        var Gmap=new google.maps.Map(document.getElementById("mapcontainer"),{
            center:myCenter,
            zoom:15,
            mapTypeId:google.maps.MapTypeId.ROADMAP
        });
        var Gmarker=new google.maps.Marker({
            position:myCenter
        });
        Gmarker.setMap(Gmap);
        $("#mapouter").popup();
        chooseMapGoogle = [(position.latitude||position.lat), (position.longitude||position.lng)];

        google.maps.event.addListener(Gmap, 'click', function(event) {
            var center = event.latLng;
            var centerlat = center.lat();
            var centerlng = center.lng();
            chooseMapGoogle = [centerlat, centerlng];

            Gmarker.setMap(null);
            Gmarker=new google.maps.Marker({
                position:new google.maps.LatLng(centerlat, centerlng)
            });
            Gmarker.setMap(Gmap);
            setForm(centerlat, centerlng, 0);
            $.closePopup();
        });
        <!--{elseif $_G['cache']['plugin']['xigua_hs']['baidusdk']}-->
        var map = new BMap.Map("mapcontainer");
        var geoc = new BMap.Geocoder();
        var point = new BMap.Point((position.longitude||position.lng), (position.latitude||position.lat));
        map.centerAndZoom(point, 15);
        var marker = new BMap.Marker(point);
        map.addOverlay(marker);

        map.addControl(new BMap.MapTypeControl());
        map.addControl(new BMap.NavigationControl());

        map.addEventListener("click", function (e){
            var marker = new BMap.Marker(new BMap.Point(e.point.lng, e.point.lat));
            map.addOverlay(marker);
            var pt = e.point;
            geoc.getLocation(pt, function(rs){
                var addComp = rs.addressComponents;
                $("input[name='form[addr]']").val(addComp.province+addComp.city+addComp.district+addComp.street+addComp.streetNumber);
                $("input[name='form[lat]']").val(e.point.lat);
                $("input[name='form[lng]']").val(e.point.lng);
                $("#formprovince").val(addComp.province);
                $("#formcity").val(addComp.city);
                $("#formdistrict").val(addComp.district);
                $("input[name='form[street]']").val(addComp.street);
                $("input[name='form[street_number]']").val(addComp.streetNumber);
                $.closePopup();
            });
        });
        $("#mapouter").popup();
        <!--{else}-->
        var center = new qq.maps.LatLng((position.latitude||position.lat), (position.longitude||position.lng));
        var mapinit = function () {
            geocoder = new qq.maps.Geocoder({
                complete: function (result) {
                    chooseMapRes = result;
                }
            });
            geocoder.getAddress(center);
            map = new qq.maps.Map(document.getElementById("mapcontainer"), {center: center, zoom: 13});
            marker = new qq.maps.Marker({
                position: center, map: map
            });
            qq.maps.event.addListener(map, 'click', function (event) {
                var tmpcenter = new qq.maps.LatLng(event.latLng.getLat(), event.latLng.getLng());
                marker.setPosition(tmpcenter);
                geocoder.getAddress(tmpcenter);
            });
            $("#mapouter").popup();
        };
        mapinit();
        <!--{/if}-->
    }

    $(document).on('click', '.obj_', function(){
        var k = parseInt($(this)[0].classList[2].replace('obj_', ''));
        setFormField(OBJ[k]);
    });
    var IGNORETIP = 0;
    $('#openlocation').on('click', function(){
        var pot = [];
        IGNORETIP = 0;
        pot.push({ text: "{lang xigua_hs:locacurrt}", onClick: function() { hs_getlocation(setPoint); } });
        pot.push({text: "{lang xigua_hs:xuandian}", onClick: function() { hs_getlocation(chooseMap); } });
        $.actions({ actions: pot});
    });
<!--{if !$old_data}-->
    if($('#openlocation').length>0){
        setTimeout(function () {
            IGNORETIP = 1;
            hs_getlocation(setPoint);
            if(typeof wx!=='undefined'){
                wx.ready(function () {
                    hs_getlocation(setPoint);
                });
            }
        }, 300);
    }
<!--{/if}-->

<!--{if $_G['cache']['plugin']['xigua_hs']['google']}-->
    $('.confirm-popup').on('click', function(){
        setForm(chooseMapGoogle[0], chooseMapGoogle[1], 0);
    });
<!--{elseif !$_G['cache']['plugin']['xigua_hs']['baidusdk']}-->
    $('.confirm-popup').on('click', function(){
        setForm(chooseMapRes.detail.location.lat, chooseMapRes.detail.location.lng, 0);
    });
<!--{/if}-->

    <!--{if $hs_config[maxhy]>1 && is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/touch/popup.php')}-->
    $(document).on('click','#hangye', function () {
        var popcm =$('#popup_hangye');
        popcm.popup();popcm.show();
        setTimeout(function(){popcm.show();}, 500);
        return false;
    });
    <!--{else}-->
    $("#hangye").cityPicker({
        title: "{lang xigua_hs:hangyeleibie}",
        showDistrict: false,
        onChange: function (picker, values, displayValues) {
            console.log(values);
            $.ajax({
                type: 'get',
                url: '$SCRITPTNAME?id=xigua_hs&ac=help&do=checkvip&inajax=1&hyid1='+values[0]+'&hyid2='+values[1],
                dataType: 'xml',
                success: function (data) {
                    var s = data.lastChild.firstChild.nodeValue;
                    if(s.indexOf('success')!==-1){
                        window.location.href = s.split('|')[2];
                    }
                }
            });
        }
    });
    <!--{/if}-->
<!--{eval
$opentime = array();
    for($i=0;$i<24;$i++):
        $opentime[] = $i.':00';
        $opentime[] = $i.':30';
    endfor;
    $opentimeend = $opentime;
    $opentime[] = '00:00';
    $opentime = json_encode($opentime);
    $opentimeend[] = '24:00';
    $opentimeend = json_encode($opentimeend);
}-->$("#opentime").picker({
        title: "{lang xigua_hs:xuanzeopentime}",
        value:['8:00', '21:00'],
        formatValue: function (p, values, displayValues) {
            return values[0]+'-'+values[1];
        },
        cols: [
            {textAlign: 'center',values: $opentime},
            {divider: true, content: '-'},
            {textAlign: 'center',values: $opentimeend}
        ]
    });
    <!--{if $shcolor}-->
    var itar = [];
    <!--{loop $shcolor $_title $_color}-->
    itar.push({title:'{$_title}', value:'{$_color}', style:'color:{$_color}'});
    <!--{/loop}-->
    $("#choose_color").select({
        title: "{lang xigua_hs:desc_color}",
        items: itar
    });
    <!--{/if}-->
    var sqs = [];
    <!--{loop $quaninfo $quan}-->
    sqs.push({title:'{$quan}', value:'{$quan}'});
    <!--{/loop}-->
    $("#shangquan").select({
        title: "{lang xigua_hs:xuanshangquan}",
        items: sqs
    });
    var guimo = [];
    <!--{loop $guimo $quan}-->
    guimo.push({title:'{$quan}', value:'{$quan}'});
    <!--{/loop}-->
    $("#guimo").select({
        title: "{lang xigua_hs:djxzgm}",
        items: guimo
    });
</script>
<!--{if $kflnk}--><!--{eval $config[floatleft]=3;}-->
<div class="left_float"><a href="$kflnk" id="zixunbtn" >{lang xigua_hs:ruzhuzixun}</a></div>
<!--{elseif $config[kfqrcode]}--><!--{eval $config[floatleft]=3;}-->
<div class="left_float"><span id="zixunbtn" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hs:changan}", "{lang xigua_hs:changan}");'>{lang xigua_hs:ruzhuzixun}</span></div>
<!--{/if}-->
<div class="masker" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);display:none;z-index:1000" onclick='$("#site").select("close")'></div>
<!--{template xigua_hb:common_footer}-->
<!--{template xigua_hs:enter_up}-->
<!--{if $_G['cache']['plugin']['xigua_st'] && $hotcity}-->
<script>
$("#site").select({title:"{lang xigua_hs:fbdz}",multi:1,<!--{if $hs_config['maxfz']}-->max:$hs_config['maxfz'],<!--{/if}-->
items: [{title:"{$_G['cache']['plugin']['xigua_st']['zongname']}", value:0},<!--{loop $hotcity $v}-->{title: "{echo $v[hs_name] ? $v[hs_name] : $v[name]}",value: "{$v[stid]}",},<!--{/loop}-->],
onOpen:function () {$('.masker').fadeIn();},
beforeClose:function () {$('.masker').fadeOut(150);return true;}});
</script>
<!--{/if}-->
<!--{if $hs_config[showdq]}-->
<!--{eval
$_key = 'hscityIdist'.intval($_GET['st']);
loadcache($_key);
$jsary1 = $_G['cache'][$_key]['variable'][1];
if(!json_encode($jsary1) || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000)) :
    $GLOBALS['nojson'] = 0;
    $dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
    $list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
    C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
    $jsary1 = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    foreach ($dist0 as $index => $item) :
        C::t('#xigua_hb#xigua_hb_district')->empty_child();
        $dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
    endforeach;
    savecache($_key, array('variable' => array($dist0, $jsary1), 'expiration' => TIMESTAMP));
endif;
$jsary1 = array_values($jsary1);
$pickercityjson = json_encode($jsary1);
$pickerdefault = diconv($jsary1[0]['name'].' '. $jsary1[0]['sub'][0]['name'].' '.$jsary1[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
}-->
<script> +function($){  $.rawCitiesData1 = $pickercityjson; }($); var DFTFIELD = '$pickerdefault';</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/picker.js?_{VERHASH}" charset="utf-8"></script>
<script>$("#diqu").cityPicker1({title: "{lang xigua_hs:qxzsjdq}",onChange: function (picker, values, displayValues) {
$('#needdiqu').html("<input type=\"hidden\" name=\"form[province]\" value=\""+displayValues[0]+"\">\n" +
"<input type=\"hidden\" name=\"form[city]\" value=\""+displayValues[1]+"\">\n" +
"<input type=\"hidden\" name=\"form[district]\" value=\""+displayValues[2]+"\">");}});</script>
<!--{/if}-->
<!--{if IN_PROG}--><script>$('#zixunbtn').unbind('click').on('touchstart', function () {wx.miniProgram.navigateTo({ url: '/pages/kefu/index'});return false;});</script><!--{/if}-->
<script>
<!--{if $old_data[dongjie]}-->$.confirm('{lang xigua_hs:djtip}', function () {hb_jump("$SCRITPTNAME?id=xigua_hs&ac=shcenter&mobile=2{$urlext}");}, function () {hb_jump("$SCRITPTNAME?id=xigua_hs&ac=shcenter&mobile=2{$urlext}");});<!--{/if}-->
<!--{if $showv}-->
$(document).on('click','.J_ping', function () {$('.J_ping').addClass('type-item-gray').removeClass('type-item-active');$(this).addClass('type-item-active').removeClass('type-item-gray');});
$('.J_ping:first-child').trigger('click');$('.J_ping:first-child').find('.typevip').trigger('click');
<!--{else}-->
$(document).on('click','.typevip', function () {
    var that = $(this);
    var access_qr = that.data('access_qr');
    var access_album = that.data('access_album');
    var access_jieshao2 = that.data('access_jieshao2');
    if(access_qr){$('#access_qr').show();}else{$('#access_qr').hide();}
    if(access_album){$('#access_album').show();}else{$('#access_album').hide();}
    if(access_jieshao2){$('#access_jieshao2').show();}else{$('#access_jieshao2').hide();}
});
<!--{if !$old_data}-->$('.J_ping2:first-child').trigger('click');$('.J_ping2:first-child').find('.typevip').trigger('click');<!--{/if}-->
<!--{/if}-->
$('html,body').animate({scrollTop: 0}, 500);
</script><!--{template xigua_hb:autosave}-->