<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<style>.weui-switch:checked {border-color:$config[maincolor];background-color:$config[maincolor]}</style>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div>
        <div class="weui-cells__title">{lang xigua_hs:ac_dianyuan}</div>
        <!--{if $list}-->
        <!--{loop $list $k $v}-->
        <div class="weui-form-preview <!--{if $k>0}-->mt10<!--{/if}-->" id="li_{$v[id]}">
            <div class="weui-form-preview__bd">
                <div class="weui-form-preview__item tl">
                    <span class="f24 c6">
                        {$v[realname]}
                        <em class="f15 c9">[<!--{if $v[isadmin]}-->{lang xigua_hs:guanliyuan}<!--{else}-->{lang xigua_hs:dianyuan}<!--{/if}-->]</em>
                        <em class="f15 main_color">{$v[mobile]}</em>
                    </span>
                    <span class="weui-form-preview__value f15"><img style="width:1rem;height:1rem;vertical-align: middle;" src="{avatar($v[uid], 'middle', true)}" /> {$users[$v[uid]][username]} [UID:{$v[uid]}] </span>
                </div>
            </div>
            <div class="weui-form-preview__ft">
                <a class="weui-form-preview__btn weui-form-preview__btn_default f17" onclick="return confirm_del('{lang xigua_hb:delconfirm}', '$SCRITPTNAME?id=xigua_hs&ac=dianyuan&do=del&formhash={FORMHASH}&shid=$v[shid]&delid={$v[id]}', '{$v[id]}');" href="javascript:">{lang xigua_hb:dodel}</a>
                <button type="submit" class="weui-form-preview__btn weui-form-preview__btn_primary f17" href="javascript:" onclick="return full_input(this);" data-oldid="$v[id]" data-realname="$v[realname]" data-username="$v[username]" data-mobile="$v[mobile]">{lang xigua_hb:xiugai}</button>
            </div>
        </div>
        <!--{/loop}-->
        <!--{else}-->
        <!--{template xigua_hb:loading}-->
        <script>
            $('#loading-show').addClass('hidden');
            $('#loading-none').removeClass('hidden');
        </script>
        <!--{/if}-->
    </div>

    <div class="footer_fix"></div>
    <div class="bottom_fix"></div>
    <div class="fix-bottom">
        <a class="weui-btn weui-btn_primary" onclick="return full_input(this);">{lang xigua_hs:newdy}</a>
    </div>
</div>

<div id="new_popup" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <form  action="$SCRITPTNAME?id=xigua_hs&ac=dianyuan&do=add&shid=$v[shid]" method="post" id="form">
            <div class="fixpopuper">
                <input name="formhash" value="{FORMHASH}" type="hidden">
                <input name="form[oldid]" value="0" type="hidden">

                <div class="weui-cells__title">{lang xigua_hs:plzdyi}</div>
                <div class="weui-cells weui-cells_form">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hs:uid}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[uid]" placeholder="{lang xigua_hs:plzuid}">
                        </div>
                    </div>
                </div>
                <div class="weui-cells__title">{lang xigua_hs:huo}</div>
                <div class="weui-cells weui-cells_form">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hs:yhm}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[username]" placeholder="{lang xigua_hs:plzyhm}">
                        </div>
                    </div>
                </div>
                <div class="weui-cells__title">{lang xigua_hs:huo}</div>
                <div class="weui-cells weui-cells_form">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hs:dyname}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[realname]" placeholder="{lang xigua_hs:plzdy}">
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hs:dymobile}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="tel" name="form[mobile]" placeholder="{lang xigua_hs:plzdymobile}">
                        </div>
                    </div>
                </div>
                <div class="fix-bottom mt10" style="position: relative">
                    <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}" />
                    <a class="weui-btn weui-btn_default close-popup" >{lang xigua_hb:quxiao}</a>
                </div>
            </div>
        </form>
    </div>
</div>

<script>
    function full_input(ob){
        var fd = ['oldid','realname','mobile', 'username'];
        for(var i in fd){
            var h = $(ob).data(fd[i]);
            if(typeof h === 'undefined' || h === 0){
                h = '';
            }
            $('[name="form['+fd[i]+']"]').text(h+'').val(h+'');
        }
        $('#new_popup').popup();
        return false;
    }
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->