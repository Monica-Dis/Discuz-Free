<?php exit('Author:https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->

<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div  id="list" class="weui-cells p0"></div>
    <!--{template xigua_hb:loading}-->
</div>

<script>
    var loadingurl = _APPNAME+'?id=xigua_hs&ac=myshop_li&fav=1&inajax=1&page=';
</script>
<!--{eval $tabbar=1;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->