<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<style>
.lingqu_li .weui-cell__hd{position:relative;margin:0 1rem 0 .5rem;color:#eb5a5c;font-size:1.6rem}
.lingqu_li .weui-cell__hd em{font-size:.6rem}
.lingqu_ul li{position:relative;padding-left:.5rem;font-size:.6rem;line-height:.9rem;color:#999}
.lingqu_ul li:before{content:'';position:absolute;top:.35rem;left:0;right:0;background-color:#ccc;height:.2rem;width:.2rem;border-radius:.5rem}
.lingqu_li .weui-cell__ft>div{width:4rem;overflow:hidden}
.lingqu_li .usebtn{display:inline-block;background:#fff;border:.05rem solid #eb5a5c;color:#eb5a5c;height:2.5rem;line-height:2.5rem;font-size:1.2rem;padding:0 .7rem;border-radius:5rem;text-align:center;transform:scale(.5);-webkit-transform:scale(.5);transform-origin:0;-webkit-transform-origin:0;width:5.5rem}
.lingqu_li .usebtn.used{border:.05rem solid #999;color:#999}
.lingqu_li .usebtn.expired{border:.05rem solid #ccc;color:#ccc}
.lingqu_li{margin:.5rem;background:#fff;border-radius:.25rem}
.lingqu_li .liqing_time{font-size:.5rem;line-height:1.5;display:block;margin-right:.5rem}
.c3{color:#333}
</style>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{if $fkimg}-->
    <div class="weui-cells__title" style="margin-bottom:0">
        <a class="main_color" href="{$fkimg}?">{lang xigua_hs:zxskm}</a>
    </div>
    <!--{/if}-->
    <div>
        <div id="list" class="mod-post x-postlist p0" style="background:#f8f8f8!important;"></div>
        <!--{template xigua_hb:loading}-->
    </div>

    <div class="footer_fix"></div>
</div>
<script>
    var loadingurl = window.location.href+'&ac=help&do=fukuan_list&is_my=1&inajax=1&page=';
</script>
<!--{eval $hk_tabbar=1;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->
<script>
    $(document).on('click','.doqx', function () {
        var taht = $(this);
        $.ajax({
            type: 'post',
            url: _APPNAME +'?id=xigua_hs&ac=help&do=quxiao&manage={$_GET[manage]}&fukid='+taht.data('id')+'&inajax=1',
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {
                $.hideLoading();
            }
        });

    });
</script>