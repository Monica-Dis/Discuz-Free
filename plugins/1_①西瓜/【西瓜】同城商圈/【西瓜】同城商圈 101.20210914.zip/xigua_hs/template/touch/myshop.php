<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
if(!$manage):
$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('uid='.$_G['uid']), 0, 1, 'shid DESC', 'shid,name,viptype');
    if(!$sh):
        dheader("location:"."$SCRITPTNAME?id=xigua_hs&ac=enter".$urlext);
    endif;
endif;
}-->
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->
<style>.weui-search-bar{background:#f3f4f4}
.weui-search-bar__form{background:0 0}
.weui-search-bar__box{background:url(source/plugin/xigua_hs/static/images/s.png) .5rem center no-repeat;background-size:.8rem}
.weui-search-bar__cancel-btn{font-size:.8rem}
.search_bar_btn{margin-left:.5rem;line-height:1.4rem;white-space:nowrap;display:none;font-size:.8rem}
.weui-search-bar.weui-search-bar_focusing .search_bar_btn{display:block}
</style>
<div class="page__bd">
    <!--{template xigua_hb:common_nav}--><!--{if $manage}-->
    <!--{eval $mg = '&manage=1';}-->
    <!--{/if}-->
    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hs&ac=myshop$mg" class="weui-navbar__item <!--{if !$_GET[hide]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hs:zhanshizhong}</span>
        </a>
        <!--{if !$manage}-->
        <a href="$SCRITPTNAME?id=xigua_hs&ac=myshop&hide=1$mg" class="weui-navbar__item <!--{if $_GET[hide]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hs:weizhanshi}</span>
        </a>
        <!--{/if}-->
        <a href="$SCRITPTNAME?id=xigua_hs&ac=myshop&hide=2$mg" class="weui-navbar__item <!--{if $_GET[hide]==2}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hs:daishen}</span>
        </a>
    </div>
    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">
            <input name="id" value="xigua_hs" type="hidden">
            <input name="ac" value="myshop" type="hidden">
            <input name="st" value="$_GET[st]" type="hidden" >
            <!--{if $manage}--><input name="manage" value="1" type="hidden" ><!--{/if}-->
            <input name="hide" value="$_GET[hide]" type="hidden">
            <input name="idu" value="$_GET[idu]" type="hidden" >

            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_hs:plzshname}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_hs:plzshname}</span>
            </label>
        </form>
        <a href="javascript:;" class="search_bar_btn main_color" id="dosearch">{lang xigua_hs:search}</a>
        <a href="$SCRITPTNAME?id=xigua_hs&ac=myshop$mg&hide=$_GET[hide]" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_hs:qx}</a>
    </div>
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>
    var loadingurl = window.location.href+'&ac=myshop_li&is_my=1&keyword=$keyword&hide={$_GET['hide']}&inajax=1&page=';
</script>
<!--{eval $tabbar=1;
$hbrwopen = is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php') && is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/touch/hsrw_view.php');
}-->
<!--{template xigua_hb:common_footer}-->
<!--{template xigua_hs:footer}-->
<script>
<!--{if $hbrwopen}-->
    function hs_selecthstype(id) {
        $.modal({
            title: "{lang xigua_hb:fhb}",
            text: "{lang xigua_hb:qxzfhb}",
            buttons: [
                { text: "{lang xigua_hb:quxiao}", className: "default", onClick: function(){ } },
                { text: "{lang xigua_hb:putong}",  onClick: function(){
                        $.actions({title: '{lang xigua_hb:hongbaojine}',actions: [<!--{loop $red $item}-->{text: "{$item[title]}",onClick: function() { hb_jump('$SCRITPTNAME?id=xigua_hs&ac=redtype&redtype={$item[price]}&shid='+id+_URLEXT);}},<!--{/loop}-->]});
                    } },
                { text: "{lang xigua_hb:rwhb}",  onClick: function(){
                        $('#pubhb_ctrl').popup().show();$('.pshid').val(id).html(id+'');
                    } },
            ]
        });
    }
<!--{/if}-->
    function managesp(obj) {
        var act = [], that = $(obj);
        var id= that.data('id'), ttl= that.data('title'), gg= that.data('gg'), hb= that.data('hb'), vipid = that.data('vipid'), digprices = {};
        <!--{if !$_GET[hide] && $red}-->
        if(hb){
            act.push({
                text: '{lang xigua_hb:hongbaokuosan}', onClick: function () {
<!--{if $hbrwopen}-->hs_selecthstype(id);return false;<!--{/if}-->
                    $.actions({
                        title: '{lang xigua_hb:hongbaojine}',
                        actions: [
                            <!--{loop $red $item}-->
                            {text: "{$item[title]}",onClick: function() {
                                window.location.href= '$SCRITPTNAME?id=xigua_hs&ac=redtype&redtype={$item[price]}&shid='+id+_URLEXT;
                            }},
                            <!--{/loop}-->
                        ]
                    });
                }
            });
        }
        <!--{/if}-->

        if(that.data('ztd')){
            act.push({
                text: '{lang xigua_hs:szztd}', onClick: function () {
                    window.location.href= '$SCRITPTNAME?id=xigua_hs&ac=myaddr&shid='+id+_URLEXT;
                }
            });
        }
        if(that.data('dy')){
            act.push({
                text: '{lang xigua_hs:ac_dianyuan}', onClick: function () {
                    window.location.href= '$SCRITPTNAME?id=xigua_hs&ac=dianyuan&shid='+id+_URLEXT;
                }
            });
        }

        <!--{if !$manage}-->
        act.push( {
            text: '{lang xigua_hs:xufei}', onClick: function () {
                var _vips = [];
<!--{loop $vips $k $__v}-->
_vips.push({text:'{$__v[name]} ( {$__v[udays]} )', onClick:function () {
    if(vipid>$__v[id]){
        $.confirm({
            title: '{lang xigua_hs:qdjj}',
            onOK: function () {
                window.location.href = '$SCRITPTNAME?id=xigua_hs&ac=xufei&viptype={$__v[id]}&shid='+id+_URLEXT;
            }
        });
    }else{
        window.location.href = '$SCRITPTNAME?id=xigua_hs&ac=xufei&viptype={$__v[id]}&shid='+id+_URLEXT;
    }
}});
<!--{/loop}-->
                $.actions({
                    title: '{lang xigua_hs:xufei} ID: '+id,
                    actions: _vips
                });
            }
        });
        <!--{else}-->
        act.push({
            text: '{lang xigua_hb:shenhe}', onClick: function () {
                $.modal({
                    title: "{lang xigua_hb:shenhe}",
                    text: "{lang xigua_hb:qingxuanzeshenhe}",
                    buttons: [
                        { text: "{lang xigua_hb:quxiao}", className: "default"},
                        { text: "{lang xigua_hb:jujue}", onClick: function(){
                                dotong(id, 0);
                            } },
                        { text: "{lang xigua_hb:tongguo}", onClick: function(){
                                dotong(id, 1);
                            }}
                    ]
                });
            }
        });
        <!--{/if}-->
        <!--{if $_GET[hide]==1}-->
        <!--{elseif !$_GET[hide]}-->
        if(gg){
            act.push( {
                text: '{lang xigua_hs:fabugonggao}', onClick: function () {
                    $.prompt({
                        title: '{lang xigua_hs:fabugonggao} ('+ttl+')',
                        input: PLZINPUT,
                        empty: false,
                        onOK: function (input) {
                            $.showLoading();
                            $.ajax({
                                type: 'post',
                                url: _APPNAME +'?id=xigua_hs&ac=notice&do=add&inajax=1&shid='+id,
                                data: {'content': input, 'formhash' :FORMHASH},
                                dataType: 'xml',
                                success: function (data) {
                                    $.hideLoading();
                                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                    var s = data.lastChild.firstChild.nodeValue;
                                    var msgar = tip_common(s);
                                },
                                error: function () {
                                    $.hideLoading();
                                }
                            });
                        },
                        onCancel: function () {
                        }
                    });
                }
            });
        }
        <!--{loop $vips $k $__v}-->
        digprices[{$__v[id]}] =[<!--{loop $__v['digprice'] $___k $___v}-->
        {text: "{$___v[title]}", onClick: function () {
            var _axjurl = '$SCRITPTNAME?id=xigua_hs&ac=dodig&type={$___v[type]}&shid=' + id;
            $.showLoading();
            $.ajax({
                type: 'post',
                url: _axjurl,
                data: {'formhash' :FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    var msgar = tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }}, <!--{/loop}-->];
        <!--{/loop}-->

        if(vipid){
            act.push({
                text: '{lang xigua_hs:zhidingdianpu}', onClick: function () {
                    $.actions({
                        title: '{lang xigua_hs:zhidingdianpu}ID: '+id,
                        actions: digprices[vipid]
                    });
                }
            });
        }
        <!--{/if}-->
        act.push( {
            text: '{lang xigua_hb:edit}{lang xigua_hs:shangjia}', onClick: function () {
                window.location.href = '$SCRITPTNAME?id=xigua_hs&ac=enter&edit='+id+_URLEXT;
            }
        });
        act.push({
            text: '{lang xigua_hs:hxpwd}', onClick: function () {
                $.prompt({
                    text: '{lang xigua_hs:qsrhxmm}',
                    empty: false,
                    onOK: function (input) {
                        $.showLoading();
                        $.ajax({
                            type: 'post',
                            url: '$SCRITPTNAME?id=xigua_hs&ac=setpwd&inajax=1&shid='+id,
                            data:{formhash:'{FORMHASH}',  hxpwd:$('#weui-prompt-input').val()},
                            dataType: 'xml',
                            success: function (data) {
                                $.hideLoading();
                                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                                var s = data.lastChild.firstChild.nodeValue;
                                tip_common(s);
                            },
                            error: function () {
                                $.hideLoading();
                            }
                        });
                    }
                });
                $('#weui-prompt-input').replaceWith('<input class="weui-prompt-input needsclick weui-input needsclick_input" type="tel" id="weui-prompt-input" placeholder="{lang xigua_hs:qsrhxmm}" />');
                document.getElementById('weui-prompt-input').focus();
            }
        });
        <!--{if $_G['cache']['plugin']['xigua_he']}-->
        if(that.data('huodong')){
            act.push({
                text: '{lang xigua_hs:ac_huodong}', onClick: function () {
                    window.location.href = '$SCRITPTNAME?id=xigua_he&ac=chosecat'+_URLEXT;
                }
            });
        }
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['xigua_hd']}-->
        if(that.data('jianjia')){
            act.push({
                text: '{lang xigua_hs:ac_jianjia}', onClick: function () {
                    window.location.href= '$SCRITPTNAME?id=xigua_hd&ac=my_evt&auto=1&shid='+id+_URLEXT;
                }
            });
        }
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['xigua_hk']}-->
        if(that.data('heika')){
            act.push({
                text: '{lang xigua_hs:ac_heika}', onClick: function () {
                    window.location.href= '$SCRITPTNAME?id=xigua_hk&ac=add&shid='+id+_URLEXT;
                }
            });
        }
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['xigua_pt']}-->
        if(that.data('pt')){
            act.push({
                text: '{lang xigua_pt:fqpt}', onClick: function () {
                    window.location.href= '$SCRITPTNAME?id=xigua_pt&ac=manage&mobile=2'+_URLEXT;
                }
            });
        }
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['xigua_hm'] || $_G['cache']['plugin']['xigua_hd']}-->
        if(that.data('qianggou')){
            act.push({
                text: '{lang xigua_hs:ac_qianggou}', onClick: function () {
                    window.location.href= '$SCRITPTNAME?id=xigua_hm&ac=my_seckill'+_URLEXT;
                }
            });
        }
        if(that.data('youhui')){
            act.push({
                text: '{lang xigua_hs:ac_youhui}', onClick: function () {
                    window.location.href = '$SCRITPTNAME?id=xigua_hm&ac=my_seckill&do=quan'+_URLEXT;
                }
            });
        }
        <!--{/if}-->

        <!--{if $_G['cache']['plugin']['xigua_job']}-->
        act.push( {
            text: '{lang xigua_job:fbzw}', onClick: function () {
                hb_jump('$SCRITPTNAME?id=xigua_job&ac=pubjob&type=full');
            }
        });
        <!--{/if}-->
        <!--{if $hs_config[allowxijia] && !$stadmin}-->
        act.push( {
            text: '{lang xigua_hb:xiajia}', onClick: function () {
                confirm_del('{lang xigua_hb:xiajiaconfirm}', '$SCRITPTNAME?id=xigua_hs&ac=enter&del='+id+'&formhash={FORMHASH}');
            }
        });
        <!--{/if}-->
        $.actions({
            title: '{lang xigua_hs:shangjia}ID: '+id + '({lang xigua_hs:huadong})',
            actions: act
        });
        return false;
    }
    <!--{if $newshid}-->
    setTimeout(function () {
        $('#li_{$newshid} a').trigger('click');
    }, 400);
    <!--{/if}-->

    function dotong(pubid, guo){
        $.showLoading();
        $.ajax({
            type: 'post',
            url: window.location.href + '&ac=manage&inajax=1&shid='+pubid+'&tongguo='+guo,
            data:{formhash:FORMHASH,'domanage':1},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () { $.hideLoading(); }
        });
    }
$(document).on('click','#dosearch', function () {
    if($('#searchInput').val()){
        $('#dosearchform').submit();
    }else{
        $.alert($('#searchInput').attr('placeholder'));
    }
});
</script>