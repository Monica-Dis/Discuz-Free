<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<!--{if $_GET['manage']}-->
<div class="lingqu_li weui-cell before_none">
    <div class="weui-cell__bd">
        <ul class="lingqu_ul">
            <li class="f12"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid={$v[sh][shid]}">{lang xigua_hs:sjmc}: <em class="c3">{$v[sh][name]}</em></a></li>
            <li class="f12">{lang xigua_hs:zfkh}: {$v[user][username]}</li>
            <li class="f12 main_color">{lang xigua_hs:zfje}: <em class="">$v[price]</em></li>

            <!--{if $v[keepmoney]>0}-->
            <li class="f12">{lang xigua_hs:bcyhje}: $v[keepmoney]</li>
            <!--{/if}-->
            <!--{if $v[ratemoney]>0}-->
            <li class="f12">{lang xigua_hs:cyyhje}: $v[ratemoney]</li>
            <!--{/if}-->
            <!--{if $v[rate]>0}-->
            <li class="f12">{lang xigua_hs:sjyh}: $v[rate]{lang xigua_hs:zhe} <!--{if $v[ratemin]>0}-->({lang xigua_hs:man}{$v[ratemin]}{lang xigua_hb:yuan}{lang xigua_hs:keyong})<!--{/if}--></li>
            <!--{/if}-->

            <!--{if $v[note]}-->
            <li class="f12">{lang xigua_hs:zfbz}: {$v[note]}</li>
            <!--{/if}-->
            <li class="f12">{lang xigua_hs:cjsj}: $v[crts_u]</li>
            <!--{if $v[pay_ts]>0}-->
            <li class="f12">{lang xigua_hs:zfsj}: {$v[pay_ts_u]}</li>
            <!--{/if}-->
            <!--{if $v[cancel_ts]>0}-->
            <li class="f12">{lang xigua_hs:qxsj}: {echo date('Y-m-d H:i', $v[cancel_ts]);}</li>
            <li class="f12">{lang xigua_hs:czyh}: $v[cancel_user]</li>
            <!--{/if}-->
        </ul>
    </div>
    <div class="weui-cell__ft">
        <div>
            <!--{if $v[cancel_ts]>0}-->
            <a class="usebtn used" href="javascript:;">{lang xigua_hs:yqx}</a>
            <!--{elseif $v[pay_ts]>0}-->
            <a class="usebtn " href="javascript:;">{lang xigua_hs:yzf}</a>
            <!--{if $v[gtype]=='sec'}-->
                <a class="usebtn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[gid]{$urlext}">{lang xigua_hb:ckxq}</a>
            <!--{elseif $v[gtype]=='hk'}-->
            <!--{eval $hkgoodid = DB::result_first("select gid from %t where id=%d", array('xigua_hk_lingqu', $v[gid]));}-->
                <a class="usebtn" href="$SCRITPTNAME?id=xigua_hk&ac=hxlog&gid=$hkgoodid{$urlext}">{lang xigua_hb:ckxq}</a>
            <!--{/if}-->
            <!--{else}-->
            <a class="usebtn expired" href="javascript:;">{lang xigua_hs:wfk}</a>
            <a class="usebtn expired doqx" data-id="$v[id]" href="javascript:;">{lang xigua_hs:qxdd}</a>
            <!--{/if}-->

        </div>
    </div>
</div>
<!--{else}-->
<div class="lingqu_li weui-cell before_none">
    <div class="weui-cell__bd">
        <ul class="lingqu_ul">
            <li class="f12"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid={$v[sh][shid]}">{lang xigua_hs:sjmc}: <em class="c3">{$v[sh][name]}</em></a></li>
            <li class="f12 main_color">{lang xigua_hs:zfje}: <em class="maincolor">$v[price]</em></li>

            <!--{if $v[keepmoney]>0}-->
            <li class="f12">{lang xigua_hs:bcyhje}: $v[keepmoney]</li>
            <!--{/if}-->
            <!--{if $v[ratemoney]>0}-->
            <li class="f12">{lang xigua_hs:cyyhje}: $v[ratemoney]</li>
            <!--{/if}-->
            <!--{if $v[rate]>0}-->
            <li class="f12">{lang xigua_hs:sjyh}: $v[rate]{lang xigua_hs:zhe} <!--{if $v[ratemin]>0}-->({lang xigua_hs:man}{$v[ratemin]}{lang xigua_hb:yuan}{lang xigua_hs:keyong})<!--{/if}--></li>
            <!--{/if}-->


            <!--{if $v[note]}-->
            <li class="f12">{lang xigua_hs:zfbz}: {$v[note]}</li>
            <!--{/if}-->
            <li class="f12">{lang xigua_hs:cjsj}: $v[crts_u]</li>
            <!--{if $v[pay_ts]>0}-->
            <li class="f12">{lang xigua_hs:zfsj}: {$v[pay_ts_u]}</li>
            <!--{/if}-->
            <!--{if $v[cancel_ts]>0}-->
            <li class="f12">{lang xigua_hs:qxsj}: {echo date('Y-m-d H:i', $v[cancel_ts]);}</li>
            <li class="f12">{lang xigua_hs:czyh}: $v[cancel_user]</li>
            <!--{/if}-->
        </ul>
    </div>
    <div class="weui-cell__ft">
        <div>
            <!--{if $v[cancel_ts]>0}-->
            <a class="usebtn used" href="javascript:;">{lang xigua_hs:yqx}</a>
            <!--{elseif $v[pay_ts]>0}-->
            <a class="usebtn " href="javascript:;">{lang xigua_hs:yzf}</a>

            <!--{if $v[gtype]=='sec'}-->
                <a class="usebtn" href="$SCRITPTNAME?id=xigua_hm&ac=seckill_profile&logid=$v[gid]{$urlext}">{lang xigua_hb:ckxq}</a>
            <!--{elseif $v[gtype]=='hk'}-->
             <a class="usebtn" href="$SCRITPTNAME?id=xigua_hk&ac=my_order&is_my=1&type=used{$urlext}">{lang xigua_hb:ckxq}</a>
            <!--{/if}-->

            <!--{else}-->
            <a class="usebtn" href="$v[jumpurl]">{lang xigua_hs:ljfk}</a>
            <a class="usebtn expired doqx" data-id="$v[id]" href="javascript:;">{lang xigua_hs:qxdd}</a>
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{/if}-->
<!--{/loop}-->
