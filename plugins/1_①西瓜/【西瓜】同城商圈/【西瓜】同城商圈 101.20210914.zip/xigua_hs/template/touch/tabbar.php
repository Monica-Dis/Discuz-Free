<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $hs_tabbar}-->
<!--{eval
$custom_nav3 = C::t('#xigua_hs#xigua_hs_nav')->fetch_index();
$navcount = count($custom_nav3);
$is_off = 1;
$curturl = hb_currenturl();
}-->
<!--{if $navcount}-->
<div class="weui-tabbar<!--{if $showfloatapp}--> none<!--{/if}-->">
    <!--{loop $custom_nav3 $loop_k $loopin}--><!--{eval
$highlight = is_numeric($loopin['adlink']) ? '' : '&high='.$loop_k;
$inlink = $loopin['adlink'].$highlight;
$is_on = !$is_on && (  strpos($curturl,$inlink)!==false || strpos($curturl,$highlight)!==false  || ($_GET['high'] && $_GET['high']==$loop_k)  );
if($is_on):
    $loopin[icon] = $loopin[icon2]?$loopin[icon2]:$loopin[icon];
endif;
}-->
    <!--{if $loopin[up]}-->
    <a href="{$inlink}" class="weui-tabbar__item weui-bar__item_on showpubfont"><div class="pub_circle"></div>
        <!--{if $loopin[icon2]}-->
        <img src="$loopin[icon2]" class="tabcon" />
        <!--{/if}-->
        <p class="weui-tabbar__label pub_circle_p" style="color:#777!important">{$loopin[name]}</p>
    </a>
    <!--{else}-->
    <a href="{$inlink}" class="weui-tabbar__item <!--{if $is_on}-->weui-bar__item_on<!--{/if}-->">
        <!--{if $loopin[icon]}-->
        <img src="$loopin[icon]" class="tabcon3" />
        <!--{/if}-->
        <p class="weui-tabbar__label">{$loopin[name]}</p>
    </a>
    <!--{/if}-->
    <!--{/loop}-->
</div>
<!--{else}-->
<div class="weui-tabbar <!--{if $showfloatapp}-->none<!--{/if}-->">
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hb{$urlext}" class="weui-tabbar__item">
        <i class="iconfont icon-index weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">{lang xigua_hb:shouye}</p>
    </a>

    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hs{$urlext}" class="weui-tabbar__item <!--{if in_array($ac, array('index','hangye'))}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-shoplight weui-tabbar__icon f26"></i>
        <p class="weui-tabbar__label">{lang xigua_hb:shangquan}</p>
    </a>

    <a href="<!--{if $publink}-->$publink{$urlext}<!--{else}-->$SCRITPTNAME?id=xigua_hs&ac=enter&from=hs&needlogin=1{$urlext}<!--{/if}-->" class="weui-tabbar__item weui-bar__item_on <!--{if $config[showpubfont]}-->showpubfont<!--{/if}-->">
        <div class="pub_circle"></div>
        <i class="iconfont icon-fabuhei weui-tabbar__icon"></i>
        <!--{if $config[showpubfont]}--><p class="weui-tabbar__label pub_circle_p" style="color:#777!important">{lang xigua_hs:ruzhu1}</p><!--{/if}-->
    </a>
    <!--{if $config[setbuttom]}-->
    <!--{eval $helplink = explode('|', $config[setbuttom]);}-->
    <a href="$helplink[2]" class="weui-tabbar__item <!--{if $ac=='about'}-->weui-bar__item_on<!--{/if}-->">
        <!--{if $helplink[1] && strpos($helplink[1], '.')!==false}--><img src="$helplink[1]" style="width:1rem;height:1rem;display: block;margin: 0 auto;margin-top:.35rem;" /><!--{elseif $helplink[1]}--><i class="iconfont icon-{$helplink[1]} weui-tabbar__icon"></i><!--{else}--><i class="iconfont icon-jieban weui-tabbar__icon"></i><!--{/if}-->
        <p class="weui-tabbar__label">$helplink[0]</p>
    </a>
    <!--{else}-->
    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hb&ac=hongbao{$urlext}" class="weui-tabbar__item <!--{if $ac=='hongbao'}-->weui-bar__item_on<!--{/if}-->">
        <i class="iconfont icon-hongbao2 weui-tabbar__icon"></i>
        <p class="weui-tabbar__label">{lang xigua_hb:hb}</p>
    </a>
    <!--{/if}-->

    <a href="{$siteurl}$SCRITPTNAME?id=xigua_hb&ac=my&needlogin=1{$urlext}" class="weui-tabbar__item <!--{if strpos($ac,'my')!==false}-->weui-bar__item_on<!--{/if}-->">
        <span style="display: inline-block;position: relative;">
            <i class="iconfont icon-xiaolian2 weui-tabbar__icon"></i>
            <!--{if $newpm || $newpm = C::t('#xigua_hb#xigua_hb_comment')->fetch_type1_num()}-->
            <span class="weui-badge weui-badge_dot" style="position:absolute;top:0;right:-.3rem;"></span>
            <!--{/if}-->
        </span>
        <p class="weui-tabbar__label">{lang xigua_hb:wode}</p>
    </a>
</div>
<!--{/if}-->
<!--{/if}-->