<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<script src="source/plugin/xigua_hb/static/dist/cropper.min.js?{VERHASH}"></script>
<script>
    var loadingImg ='<li id="loadingimg" class="weui-uploader__file weui-uploader__file_status"><div class="weui-uploader__file-content"><img src="source/plugin/xigua_hb/static/img/loading.gif"/></div></li>';
    var photoct = $('#photo');
    var imgpop = $('#popctrl');var uploadinput_obj;
    var uploadinput = $('.weui-uploader__input');
    var boxer = null, filedname = '', ICnt = {echo intval($__k);}, canmulti = 0, max_upload_num = 10, max_upload_maxtip = '';
    $(function () {

        var URL = window.URL || window.webkitURL;
        var blobURL;
        var file;
        <!--{if HB_INWECHAT&&$config[multiupload]}-->
        canmulti = 1;
        uploadinput.on("touchstart", function () {
            uploadinput_obj = $(this);
                boxer = $(this).parent().prev();
                max_upload_num = boxer.data('max');
                max_upload_maxtip = boxer.data('maxtip');
                if(boxer.find('li').length>=max_upload_num){
                    $.toast(max_upload_maxtip, 'error');
                    return false;
                }
                wx_upload();
                return false;
        });
        <!--{elseif IN_MAGAPP}-->
uploadinput.on('touchstart', function(){
    uploadinput_obj = $(this);
    boxer = $(this).parent().prev();
    max_upload_num = boxer.data('max');
    max_upload_maxtip = boxer.data('maxtip');
    if(boxer.find('li').length>=max_upload_num){
        $.toast(max_upload_maxtip, 'error');
        return false;
    }
    magPicPick();
    return false;
});
        <!--{else}-->
if(0){
uploadinput.on('touchstart', function(){
    uploadinput_obj = $(this);
    boxer = $(this).parent().prev();
    max_upload_num = boxer.data('max');
    max_upload_maxtip = boxer.data('maxtip');
    if(boxer.find('li').length>=max_upload_num){
        $.toast(max_upload_maxtip, 'error');
        return false;
    }
    magPicPick();
    return false;
});
        }else{
        uploadinput.on("change", function () {
            uploadinput_obj = $(this);
            boxer = $(this).parent().prev();
            if(boxer.data('max')){
                if(boxer.children('li').length>=boxer.data('max')){
                    $.toast(boxer.data('maxtip'), 'error');
                    return false;
                }
            }
            filedname = $(this).data('name');
            photoct.cropper('destroy').cropper({
                minContainerHeight: 320,
                autoCropArea:1
            });
            var files = this.files;
            if (!photoct.data('cropper')) {
                return;
            }
            if (files && files.length) {
                file = files[0];
                if (/^image\/\w+$/.test(file.type)) {
                    blobURL = URL.createObjectURL(file);
                    photoct.one('built.cropper', function () {
                        URL.revokeObjectURL(blobURL);
                    }).cropper('reset').cropper('replace', blobURL);
                    uploadinput_obj.val('');
                    imgpop.popup();
                } else {
                    $.toptip('Please choose an image file.', 'error');
                }
            }
        });
        }
        <!--{/if}-->

        $('.pub_funcbar a').each(function () {
            var btn = $(this);
            var mtd = btn.attr('data-method');
            btn.on('click', function () {
                if (mtd == 'destroy') {
                } else if (mtd == 'confirm') {
                    result = photoct.cropper('getCroppedCanvas');
                    photo = result.toDataURL('image/jpeg');
                    var img=photo.split(',')[1];
                    img=window.atob(img);
                    var ia = new Uint8Array(img.length);
                    for (var i = 0; i < img.length; i++) {
                        ia[i] = img.charCodeAt(i);
                    }
                    var bfile = new Blob([ia], {type:"image/jpeg"});


                    compress(bfile, function(TMP){
                        hs_doupload(TMP, typeof cropCallback!=='undefined'?cropCallback:null);
                    });

                    if(boxer.data('only')){ boxer.html(loadingImg); }else{ boxer.append(loadingImg); }
                } else {
                    var opt = btn.attr('data-option');
                    photoct.cropper(mtd, opt);
                }
            });
        });
        <!--{if HB_INWECHAT&&$config[multiupload]}-->
        canmulti = 1;
        $(document).on('touchstart','.center_upload__input', function () {
            uploadinput_obj = $(this);
            ICnt ++;
            var _that = $(this).parent().parent().parent().parent().parent();
            var arear = '<div class="weui-cell bgf" id="arear_'+ICnt+'">' +
                ' <ul id="cimg_'+ICnt+'" data-only="1">'+loadingImg+'</ul>' +
                ' <div class="weui-cell__bd"><textarea class="weui-textarea" placeholder="{lang xigua_hs:shuruwenzi}" rows="3" name="form[append_text][]"></textarea></div>' +
                '  <a class="iconfont icon-guanbijiantou closeHt" data-index="'+ICnt+'"></a></div>';
            _that.after(arear+ '<div class="weui-cell" id="cell_'+ICnt+'">'+$('#first_append_img').html()+'</div>');
            boxer = $('#cimg_'+ICnt);
            wx.chooseImage({
                count:1,
                success: function (res) {
                    var localIds = res.localIds;
                    syncUpload(localIds);
                },
                fail: function (res) {
                }
            });
            return false;
        });
        <!--{elseif IN_MAGAPP}-->
        $(document).on('touchstart','.center_upload__input', function () {
            uploadinput_obj = $(this);
            ICnt ++;
            var _that = $(this).parent().parent().parent().parent().parent();
            var arear = '<div class="weui-cell bgf" id="arear_'+ICnt+'">' +
                ' <ul id="cimg_'+ICnt+'" data-only="1">'+loadingImg+'</ul>' +
                ' <div class="weui-cell__bd"><textarea class="weui-textarea" placeholder="{lang xigua_hs:shuruwenzi}" rows="3" name="form[append_text][]"></textarea></div>' +
                '  <a class="iconfont icon-guanbijiantou closeHt" data-index="'+ICnt+'"></a></div>';
            _that.after(arear+ '<div class="weui-cell" id="cell_'+ICnt+'">'+$('#first_append_img').html()+'</div>');
            boxer = $('#cimg_'+ICnt);
            magPicPick();
            return false;
        });
        <!--{else}-->
        if(typeof QFH5 !='undefined' && typeof QFH5.uploadImageOrVideo!='undefined'){
            $(document).on('touchstart','.center_upload__input', function () {
                uploadinput_obj = $(this);
                ICnt ++;
                var _that = $(this).parent().parent().parent().parent().parent();
                var arear = '<div class="weui-cell bgf" id="arear_'+ICnt+'">' +
                    ' <ul id="cimg_'+ICnt+'" data-only="1">'+loadingImg+'</ul>' +
                    ' <div class="weui-cell__bd"><textarea class="weui-textarea" placeholder="{lang xigua_hs:shuruwenzi}" rows="3" name="form[append_text][]"></textarea></div>' +
                    '  <a class="iconfont icon-guanbijiantou closeHt" data-index="'+ICnt+'"></a></div>';
                _that.after(arear+ '<div class="weui-cell" id="cell_'+ICnt+'">'+$('#first_append_img').html()+'</div>');
                boxer = $('#cimg_'+ICnt);
                magPicPick();
                return false;
            });
        }else{
        $(document).on('change', '.center_upload__input', function () {
            ICnt ++;
            var _that = $(this).parent().parent().parent().parent().parent();
            var arear = '<div class="weui-cell bgf" id="arear_'+ICnt+'">' +
                ' <ul id="cimg_'+ICnt+'" data-only="1">'+loadingImg+'</ul>' +
                ' <div class="weui-cell__bd"><textarea class="weui-textarea" placeholder="{lang xigua_hs:shuruwenzi}" rows="3" name="form[append_text][]"></textarea></div>' +
                '  <a class="iconfont icon-guanbijiantou closeHt" data-index="'+ICnt+'"></a></div>';
            _that.after(arear+ '<div class="weui-cell" id="cell_'+ICnt+'">'+$('#first_append_img').html()+'</div>');
            filedname = $(this).data('name');
            var files = this.files;
            if (files && files.length) {
                file = files[0];
                if (/^image\/\w+$/.test(file.type)) {
                    boxer = $('#cimg_'+ICnt);
                    compress(file, function(TMP){
                        hs_doupload(TMP,function(){
                        });
                    });
                } else {
                    $.toptip('Please choose an image file.', 'error');
                }
            }
        });
        }
        <!--{/if}-->

        $(document).on('click', '.closeHt', function () {
            var idx = $(this).data('index');
            $.confirm('{lang xigua_hs:confirmshan}', function () {
                $('#arear_'+idx).remove();
                $('#cell_'+idx).remove();
            }, function () {
            });
            return false;
        });
    });
    function compress(file, callback){
        var reader = new FileReader();

        reader.onload = function (e) {

            var image = $('<img/>');
            image.on('load', function () {
                var square = 640;
                var canvas = document.createElement('canvas');


                if (this.width > this.height) {
                    canvas.width = Math.round(square * this.width / this.height);
                    canvas.height = square;
                } else {
                    canvas.height = Math.round(square * this.height / this.width);
                    canvas.width = square;
                }

                var context = canvas.getContext('2d');
                context.clearRect(0, 0, square, square);
                var imageWidth = canvas.width;
                var imageHeight = canvas.height;
                var offsetX = 0;
                var offsetY = 0;
                context.drawImage(this, offsetX, offsetY, imageWidth, imageHeight);
                var data = canvas.toDataURL('image/jpeg', 0.8);
                console.log([imageWidth,imageHeight]);
                callback(data);
            });

            image.attr('src', e.target.result);
        };

        reader.readAsDataURL(file);
    }
    function sms_time() {
        var o = $('#vcodebtn');
        if (SMS_WAIT_TIME <= 0) {
            o.removeAttr("disabled");
            o.html("{lang xigua_hb:vcode_get}");
            SMS_WAIT_TIME = 120;
        } else {
            o.attr("disabled", true);
            o.html("{lang xigua_hb:vcode_again}(" + SMS_WAIT_TIME + ")");
            SMS_WAIT_TIME--;
            setTimeout(function() {
                sms_time();
            }, 1000);
        }
    }
    <!--{if HB_INWECHAT && $config[multiupload]}-->
    var syncUpload = function(localIds){
        var localId = localIds.shift();
        wx.uploadImage({
            localId: localId,
            isShowProgressTips:1,
            success: function (res) {
                var serverId = res.serverId;
                do_download("&serverId[]="+serverId);
                if(localIds.length > 0){
                    syncUpload(localIds);
                }
            }
        });
    };
    function do_download(serverId){
        if(max_upload_num>0 && (boxer.find('li').length>=max_upload_num) && !boxer.data('only')){
            $.toptip(max_upload_maxtip, 'warning');
            return false;
        }
        $.showLoading();
        $.ajax({
            type: "POST",
            url: "$SCRITPTNAME?id=xigua_hb&ac=uploader&do=download&inajax=1",
            data: serverId,
            async: false,
            dataType: "xml",
            success: function(data){
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                var sar = s.split('|');
                if(sar[0]=='success'){
                    var imgary = sar[1].split('((()))');
                    if(boxer.data('only')){
                        var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgary[0] + ')"><input type="hidden" name="'+ uploadinput_obj.data('name')+'[]" value="' + imgary[0] + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        boxer.html(html);
                    }else{
                        var html_imga = '';
                        for(var j=0;j<imgary.length; j++){
                            html_imga += '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgary[j] + ')"><input type="hidden" name="'+ uploadinput_obj.data('name')+'[]" value="' + imgary[j] + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        }
                        boxer.append(html_imga);
                    }
                }else{
                    tip_common(s);
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    }
    function wx_upload(){
        wx.chooseImage({
            success: function (res) {
                var localIds = res.localIds;
                syncUpload(localIds);
            },
            fail: function (res) {
            }
        });
    }
    <!--{/if}-->
    <!--{if IN_MAGAPP}-->
    function magPicPick(){
        mag.picPick({
            preview: function(res){
                $.showLoading();
            },
            success: function(res){
                $.hideLoading();
                var imgu = typeof res.url!=='undefined' ? res.url : ('{$config[magapp_url]}/core/attachment/attachment/attach?aid='+res.aid);

                if(boxer.data('only')){
                    var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="'+ uploadinput_obj.data('name')+'[]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                    boxer.html(html);
                }else{
                    var html_imga = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="'+ uploadinput_obj.data('name')+'[]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                    boxer.append(html_imga);
                }

            },
            fail: function(res){
                $.hideLoading();
            }
        });
    }
    <!--{elseif IN_QIANFAN}-->
    function magPicPick() {
        var maxqf = boxer.data('only') ? 1 : 9;
        var jsUploadOptions = {
            'picFormat': 1,
            'picMaxSize': 1200,
            'compressOption':100,
            'uploadNum': maxqf,
            'uploadType': 0,
            'showCamera':false
        };
        QFH5.uploadImageOrVideo(0, JSON.stringify(jsUploadOptions), function (state, data) {
            if (state == 1) {
                for(var i in data){
                    var imgu = data[i].url;
                    if(boxer.data('only')){
                        var html = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="'+ uploadinput_obj.data('name')+'[]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        boxer.html(html);
                    }else{
                        var html_imga = '<li class="weui-uploader__file weui-uploader__file_status" style="background-image:url(' + imgu + ')"><input type="hidden" name="'+ uploadinput_obj.data('name')+'[]" value="' + imgu + '"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>';
                        boxer.append(html_imga);
                    }
                }
            } else {
            }
        })
    }
    <!--{/if}-->
</script>