<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<!--{template xigua_hs:header}-->

<script>
    alert('$msg');
    window.history.go(-1);
</script>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->