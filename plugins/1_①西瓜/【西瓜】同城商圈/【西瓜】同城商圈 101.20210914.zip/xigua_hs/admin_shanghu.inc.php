<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';

$page = max(1, intval($_GET['page']));
$lpp = $_GET['lpp'] ? intval($_GET['lpp']) : 10;
$start_limit = ($page - 1) * $lpp;
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";

if($_GET['peisong']) {
    $shid = intval($_GET['shid']);
    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($shid);
    if (submitcheck('formhash')) {
        if ($_GET['r']) {
            foreach ($_GET['r'] as $index => $item) {
                C::t('#xigua_hs#xigua_hs_yf')->update($index, $item);
            }
        }
        if ($_GET['delete']) {
            foreach ($_GET['delete'] as $index => $item) {
                $old_yf = C::t('#xigua_hs#xigua_hs_yf')->fetch($item);
                $old_shids = explode(',', $old_yf['shids']);
                foreach ($old_shids as $index1 => $old_shid) {
                    if ($old_shid == $shid) {
                        unset($old_shids[$index1]);
                    }
                }
                if ((count($old_shids) == 1 && $old_shids[0] == 0) || !$old_shids) {
                    C::t('#xigua_hs#xigua_hs_yf')->delete(array($item));
                } else {
                    C::t('#xigua_hs#xigua_hs_yf')->update($item, array('shids' => implode(',', $old_shids)));
                }
            }
        }
        if ($_GET['newyou']) {
            foreach ($_GET['newyou'] as $index => $item) {
                $newdata = array(
                    'dist1' => $item['dist1'],
                    'dist2' => '',
                    'uid' => $sh['uid'],
                    'shids' => "0,$shid",
                    'crts' => TIMESTAMP,
                    'yunfei' => $item['yunfei'],
                );
                C::t('#xigua_hs#xigua_hs_yf')->insert($newdata);
            }
        }
        cpmsg(lang_hs('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&peisong=1&shid=$shid&page=$page", 'succeed');
    }
    echo '<style>.abtn{padding:2px 6px;background:#4baed0;color:#fff;}</style>';
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&peisong=1&shid=$shid&page=$page", 'enctype');
    showtableheader($sh['name'] . '( ' . $sh['shid'] . ' )' . ' ' . lang_hs('psfsgl', 0) . "&nbsp;&nbsp;<a href='javascript:window.history.go(-1);'> " . lang_hb('back', 0) . "</a>");
    showtablerow('class="header"', array(), array(
        lang_hs('shanchu', 0),
        lang_hs('youfei', 0),
        lang_hb('plugins_edit_vars_type_area', 0),
        lang_hs('fuk', 0),
        lang_hb('crts', 0),
    ));
    $res = DB::fetch_all("SELECT * FROM " . DB::table('xigua_pt_yf') . ' WHERE FIND_IN_SET(' . $shid . ", shids) ORDER BY id ASC " . DB::limit(0, 100));

    foreach ($res as $v) {
        $uids[] = $v['uid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    foreach ($res as $v) {
        $uid = $v['uid'];
        $vid = $v['id'];
        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$vid' /> $vid ",
            "<input name='r[$vid][yunfei]' value='{$v['yunfei']}' /> " . lang_hb('yuan', 0),
            "<input name='r[$vid][dist1]' value='{$v['dist1']}' />",
            $users[$uid]['username'] . '(UID:  ' . $uid . ')',
            date('Y-m-d H:i:s', $v['crts'])
        ));
    }
    $addnew = lang_hs('addnew', 0);
    echo "<tr><td>&nbsp;</td><td colspan=\"99\"><div><a href=\"javascript:;\" onclick=\"addrow(this, 0)\" class=\"addtr\">$addnew</a></div></td></tr>";
    showsubmit('permsubmit', 'submit', 'select_all', '');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    ?>
    <script>var rowtypedata = [ [
            [1,'&nbsp;']
            , [1,'<input name="newyou[{n}][yunfei]" type="text" /> <?php echo lang_hb('yuan', 0) ?>']
            , [1,'<input name="newyou[{n}][dist1]" type="text" />']
            , [3,'&nbsp;']
        ] ];</script>
    <?php
}
elseif($_GET['yuangong']){
    $shid = intval($_GET['shid']);
    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($shid);
    if(submitcheck('formhash')){
        if($_GET['delete']){
            foreach ($_GET['delete'] as $index => $item) {
                C::t('#xigua_hs#xigua_hs_yuan')->delete(array($item));
            }
        }
        if($_GET['newyou']){
            foreach ($_GET['newyou'] as $index => $item) {
                $newdata = array(
                    'realname' => $item['yrealname'],
                    'mobile' => $item['ymobile'],
                    'uid' => $item['yuid'],
                    'authorid' => $_G['uid'],
                    'shid' => $shid,
                    'crts' => TIMESTAMP,
                    'upts' => TIMESTAMP,
                );
                C::t('#xigua_hs#xigua_hs_yuan')->insert($newdata);
            }
        }
        cpmsg(lang_hs('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&yuangong=1&shid=$shid&page=$page", 'succeed');
    }
    echo '<style>.abtn{padding:2px 6px;background:#4baed0;color:#fff;}</style>';
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&yuangong=1&shid=$shid&page=$page", 'enctype');
    showtableheader($sh['name'].' [ '.$sh['shid'].' ] '.' '.lang_hs('ac_dianyuan', 0) . "&nbsp;&nbsp;<a href='javascript:window.history.go(-1);'> ".lang_hb('back',0)."</a>");
    showtablerow('class="header"',array(),array(
        lang_hs('shanchu', 0),
        lang_hs('dianyuan', 0),
        lang_hb('realname', 0),
        lang_hs('mobile', 0),
        lang_hb('crts', 0),
    ));
    $res = DB::fetch_all("SELECT * FROM " . DB::table('xigua_hs_yuan') . ' WHERE FIND_IN_SET('.$shid.", shid) ORDER BY id ASC " . DB::limit(0, 100));
    foreach ($res as $v) {
        $uids[] = $v['uid'];
    }
    if($uids){
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    foreach ($res as $v) {
        $uid = $v['uid'];
        $vid = $v['id'];
        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$vid' /> $vid ",
            $users[$uid]['username'] .' [ UID:  '.$uid.' ]',
            $v['realname'],
            $v['mobile'],
            date('Y-m-d H:i:s', $v['crts'])
        ));
    }
    $addnew = lang_hs('addnew', 0);
    echo "<tr><td>&nbsp;</td><td colspan=\"99\"><div><a href=\"javascript:;\" onclick=\"addrow(this, 0)\" class=\"addtr\">$addnew</a></div></td></tr>";
    showsubmit('permsubmit', 'submit', 'select_all', '');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    ?>
<script>var rowtypedata = [ [
    [1,'&nbsp;'],
    [1,'<input name="newyou[{n}][yuid]" placeholder="UID" type="text" />'],
    [1,'<input name="newyou[{n}][yrealname]" placeholder="<?php lang_hb('realname', 1);?>" type="text" />'],
    [1,'<input name="newyou[{n}][ymobile]" placeholder="<?php lang_hs('mobile', 1);?>" type="text" />'],
    [1,'&nbsp;']
] ];</script>
<?php
}elseif(($shid = intval($_GET['shid'])) || ($catadd = intval($_GET['catadd']))){
    if($catadd){  // add
        $res = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_only(0, '*', 1);
        $hangye_id2 = $catadd;
        $shid = 0;
        unset($res['shid']);
        $res['endts'] = TIMESTAMP + 365*864000;
    }else{
        $res = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_only($shid, '*');
        $hangye_id2 = intval($res['hangye_id2']);
        unset($res['shid']);
    }

    $catinfo = C::t('#xigua_hs#xigua_hs_hangye')->fetch_by_catid($hangye_id2);


    if(!submitcheck('varsubmit')) {
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&shid=$shid&hangye_id2=$hangye_id2&page=$page&catadd=$catadd", 'enctype');
        showtableheader();
        showtitle($catinfo['name'] . lang_hs('shangjia', 0) . ' - ' . $shid. "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&hangye_id2=$hangye_id2&page=$page'> ".lang_hs('back',0)."</a>");


        $listinfo = C::t('#xigua_hs#xigua_hs_hangye')->list_all(1);
        C::t('#xigua_hs#xigua_hs_hangye')->init($listinfo);
        $cat_list = C::t('#xigua_hs#xigua_hs_hangye')->get_tree_array(0);
        $hangye = "<select name=\"editform[hangye_id2]\">";
        foreach ($cat_list as $k => $v) {
            $hangye .= "<optgroup label=\"$v[name]\">";
            foreach ($v['sub'] as $kk => $vv) {
                $s = '';
                if($res['hangye_id2']== $vv['id']){
                    $s = 'selected';
                }
                $hangye .= "<option $s value=\"$vv[id]\">&nbsp;&nbsp;$vv[name]</option>";
            }
            $hangye .= '</optgroup>';
        }
        $hangye .= '</select>';

        $vp = '<select name="editform[viptype]">';
        $vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99);
        foreach ($vips as $index => $vip) {
            $s = '';
            if($res['viptype']== $vip['id']){
                $s = 'selected';
            }
            $vp .= "<option $s value='{$vip['id']}'>{$vip['name']}</option>";
        }
        $vp .= '</select>';
        unset($res['hbtiaojian']);
        foreach ($res as $index => $re) {
            if(in_array($index, array('hangye_id1', 'hangye', 'color_title', 'tags', 'pay_ts'))){
                continue;
            }
            if($catadd){
                $re = is_array($re) ? array() : '';
                if(in_array($index, array('endts'))){
                    $re = TIMESTAMP+365*86400;
                }
                if(in_array($index, array('upts','crts'))){
                    $re = TIMESTAMP;
                }
            }
            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('endts', 'dig_startts', 'dig_endts', 'crts', 'upts','lastnoti'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }
            if(in_array($index, array('display', 'dongjie'))){
                $tp = 'radio';
            }
            if(in_array($index, array('hangye_id2'))){
                $tp = $hangye;
            }
            if(in_array($index, array('viptype'))){
                $tp = $vp;
            }
            if(in_array($index, array('qr', 'logo', 'cover'))){
                $tp = 'filetext';
            }
            if($index == 'color'){
                $cs = '<select name="editform[color_title]">';
                foreach ($shcolor as $c_t => $c) {
                    $s = '';
                    if($c== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c_t</option>";
                }
                $tp = $cs;
            }

            if (in_array($index, array('album', 'append_img', 'append_text'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $hs_config = $_G['cache']['plugin']['xigua_hs'];
                $loopnum = $hs_config['maximg'];
                if ($index == 'append_img') {
                    $loopnum = count($re);
                } elseif ($index == 'append_text') {
                    $tp = 'text';
                    $loopnum = count($re);
                }
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_hs($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif(in_array($index, array('links'))){
                $re = unserialize($re);
                for($i =0; $i<$hs_config['maxlink']; $i++){
                    showsetting(lang_hs('linkfont', 0).($i+1), "editform[$index][font][$i]", $re['font'][$i], $tp);
                    showsetting(lang_hs($index, 0).($i+1), "editform[$index][link][$i]", $re['link'][$i], $tp);
                }
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_hs($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }elseif($index == 'uid'){
                $cmt = lang_hs('lkkyrl',0);
                showsetting(lang_hs($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }else{
                showsetting(lang_hs($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('varsubmit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;
    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        if(!$editform['display']){
            $editform['display'] = 0;
        }else{
            $editform['display'] = 1;
        }
        $editform['color'] = $shcolor[$editform['color_title']];

        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        $endts_u = $editform['endts'];
        $editform['tags'] = trim($editform['tags']);
        $editform['crts'] = strtotime($editform['crts']);
        $editform['upts'] = strtotime($editform['upts']);
        $editform['endts'] = strtotime($editform['endts']);
        $editform['dig_endts'] = strtotime($editform['dig_endts']);
        $editform['dig_startts'] = strtotime($editform['dig_startts']);
        $editform['jieshao'] = htmlspecialchars_decode($editform['jieshao']);

        if(!$shid && $catadd && !$editform['hangye_id2']) {
            $editform['hangye_id2'] = $catadd;
        }
        if($editform['hangye_id2']){
            $_hy = C::t('#xigua_hs#xigua_hs_hangye')->fetch_by_catid($editform['hangye_id2']);
            $editform['hangye_id1'] = $_hy['pid'];
            $_hys = C::t('#xigua_hs#xigua_hs_hangye')->fetch_light(array(
                $editform['hangye_id1'],
                $editform['hangye_id2'],
            ), 'id,name', 'id ASC');
            foreach ($_hys as $index => $hy) {
                $editform['hangye'][] = $hy['name'];
            }
            $editform['hangye'] = implode(' ', $editform['hangye']);
        }
        if($editform['album']){
            $editform['album'] = array_filter($editform['album']);
            $editform['album'] = serialize($editform['album']);
        }else{
            $editform['album'] = '';
        }
        if($editform['links']){
            $editform['links'] = array_filter($editform['links']);
            $editform['links'] = serialize($editform['links']);
        }else{
            $editform['links'] = '';
        }
        $editform['append_text'] = array_filter($editform['append_text']);
        $editform['append_img']  = array_filter($editform['append_img']);
        if(!$editform['append_text']){
            $editform['append_text'] = '';
        }else{
            $editform['append_text'] = serialize($editform['append_text']);
        }
        if(!$editform['append_img']){
            $editform['append_img'] = '';
        }else{
            $editform['append_img'] = serialize($editform['append_img']);
        }

        if(!$shid){
            C::t('#xigua_hs#xigua_hs_shanghu')->insert($editform);
        }else{
            $old = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($shid);
            if(!$old['display'] && $editform['display'] && $editform['endts']>TIMESTAMP){
                $endts_u = date('Y-m-d H:i:s', $editform['endts']);
                notification_add($old['uid'],'system', lang_hs('notice_shen', 0),array('url' => "$SCRITPTNAME?id=xigua_hs&ac=view&shid=$shid", 'name' => $old['name'], 'endts' => $endts_u),1);
            }

            if(!$old['hong_num'] && $editform['hong_num']>0 && $editform['hong_money']>0){
                include_once DISCUZ_ROOT. 'source/plugin/xigua_hb/lib/hb.class.php';
                $hblist = randBean($editform['hong_money'], $editform['hong_num']);
                foreach ($hblist as $size) {
                    C::t('#xigua_hb#xigua_hb_hongbaolog')->insert(array(
                        'uid'  => 0,
                        'pubid'=> 0,
                        'size' => $size,
                        'crts' => 0,
                        'shid' => $shid,
                    ));
                }
                if($config['minhbsize'] && $config['minhbsize']<=$editform['hong_money']){
                    $uids = C::t('#xigua_hb#xigua_hb_user')->fetch_all_uids(array('fb_hb=1'));
                    if($uids){
                        global $SCRITPTNAME;
                        $url = "{$_G['siteurl']}{$SCRITPTNAME}?id=xigua_hs&ac=view&shid=$shid";
                        $saveuid = $_G['uid'];
                        $_G['uid'] = $old['uid'];
                        foreach ($uids as $index => $gd) {
                            notification_add($gd,'system', lang_hb('hb_notice',0), array('from' => $old['name'],'price' => $editform['hong_money'],'url'  => $url,),1);
                        }
                        $_G['uid'] = $saveuid;
                    }
                }
            }

            C::t('#xigua_hs#xigua_hs_shanghu')->update($shid, $editform);
        }
        cpmsg(lang_hs('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&hangye_id2=$hangye_id2&page=$page", 'succeed');
    }

//edit end

}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_hs#xigua_hs_shanghu')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {

            list($hyid1, $hyid2) = explode('_', $item['hangye_id2']);
            $names = C::t('#xigua_hs#xigua_hs_hangye')->fetch_light(array($hyid1,$hyid2));
            $hangye = $names[$hyid1]['name'].' '. $names[$hyid2]['name'];

            $old = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($id);

            if($item['stida']){
                $item['stida'] = implode(',', $item['stida']);
            }

            if(!$old['display'] && $item['display']){
                $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch($old['viptype']);
                if($old['endts']<TIMESTAMP){
                    $endts = TIMESTAMP + $vipinfo['days'] * 86400;
                }else{
                    $endts = $old['endts'];
                }
                if($item['endts']){
                    $endts = strtotime($item['endts']);
                }
                notification_add($old['uid'],'system', lang_hs('notice_shen', 0),array('url' => "$SCRITPTNAME?id=xigua_hs&ac=view&shid=$id", 'name' => $old['name'], 'endts' => date('Y-m-d H:i', $endts)),1);
                C::t('#xigua_hs#xigua_hs_shanghu')->update($id, array('display' => intval($item['display']), 'endts' => $endts,'hangye' => $hangye, 'hangye_id1' => $hyid1,  'hangye_id2' => $hyid2,'dongjie'=> intval($item['dongjie']),
                    'stida'=> $item['stida'],
                    'stid'=> $item['stid'],
                ));
            }else{
                C::t('#xigua_hs#xigua_hs_shanghu')->update($id, array('display' => intval($item['display']),'hangye' => $hangye, 'hangye_id1' => $hyid1,  'hangye_id2' => $hyid2,'dongjie'=> intval($item['dongjie']),
                    'stida'=> $item['stida'],
                    'stid'=> $item['stid'],
                    'endts' => strtotime($item['endts']),
                ));
            }
        }

        cpmsg(lang_hs('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&hangye_id2={$_GET['hangye_id2']}&page=$page&display={$_GET['display']}&weishen={$_GET['weishen']}&endts={$_GET['zd']}&display={$_GET['zd']}", 'succeed');
    }

    $wherearr = array();
    if ($hyid = intval($_GET['hangye_id2'])) {
        $pids = array($hyid);
        if ($hyinfo = C::t('#xigua_hs#xigua_hs_hangye')->get_childs_by_pids($hyid)) {
            foreach ($hyinfo as $index => $item) {
                $pids[] = intval($item['id']);
            }
            if ($pids) {
                $wherearr[] = ' hangye_id2 IN(' . implode(',', $pids) . ') ';
            }
        } else {
            $wherearr[] = ' hangye_id2 =' . $hyid;
        }
    }
    $keyword = $_GET['keyword'];
    if ($keyword = stripsearchkey($keyword)) {
        if(is_numeric($keyword)){
            $wherearr[] = "(shid LIKE '$keyword' OR uid LIKE '$keyword' )";
        }else{
            $wherearr[] = " (name LIKE '%$keyword%' OR addr LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR tag LIKE '%$keyword%' OR xuanchuan LIKE '%$keyword%') ";
        }
    }
    if ($city = daddslashes($_GET['city'])) {
        $wherearr[] = " city='$city' ";
    }
    if ($city = daddslashes($_GET['dist'])) {
        $wherearr[] = " district='$city' ";
    }
    if ($tag = stripsearchkey($_GET['tag'])) {
        $wherearr[] = " tag LIKE '%$tag%' ";
    }
    if ($_GET['display']) {
        $wherearr[] = 'display=1';
    }
    if ($_GET['weishen']) {
        $wherearr[] = 'display=0';
    }
    if ($_GET['endts']) {
        $wherearr[] = 'endts<' . TIMESTAMP;
    }
    if ($_GET['zd']) {
        $wherearr[] = 'dig_endts>' . TIMESTAMP;
    }
    if($_G['cache']['plugin']['xigua_st']) {
        if (isset($_GET['sttt'])) {
            if ($_GET['sttt'] >= 0) {
                $sttt = intval($_GET['sttt']);
                $wherearr[] = " (stid=$sttt OR FIND_IN_SET($sttt,stida)) ";
            }
        }
    }
    $ob = ' shid DESC';

    $vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99);
    if($_GET['viptype']){
        $wherearr[] = 'viptype='.intval($_GET['viptype']);
    }
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&hangye_id2={$_GET['hangye_id2']}&page=$page");
?>
<style>.appendimgs img{max-width:220px!important;}.abtn{padding:2px 6px;background:#4baed0;color:#fff;}.ctt{display:inline-block;color:#999;width:60px;vertical-align:middle}</style>
<?php
    echo '<div><input style="width:240px" type="text" id="keyword" name="keyword" placeholder="'.lang_hs('plz_uid',0).'" value="' . $_GET['keyword'] . '" class="txt" /> ';
    echo '<input type="checkbox" name="display" value="1" ' . ($_GET['display'] ? 'checked' : '') . ' />' . lang_hs('yishen', 0);
    echo '<input type="checkbox" name="weishen" value="1" ' . ($_GET['weishen'] ? 'checked' : '') . ' />' . lang_hs('weishen', 0);
    echo '<input type="checkbox" name="endts" value="1" ' . ($_GET['endts'] ? 'checked' : '') . ' />' . lang_hs('yiguoqi', 0);
    echo '<input type="checkbox" name="zd" value="1" ' . ($_GET['zd'] ? 'checked' : '') . ' />' . lang_hs('zhiding', 0);

    $vp = ' <select name="viptype">';
    $vp .= "<option value='0' ".($_GET['viptype'] ? '':'selected').">".lang_hb('quanbu',0)."</option>";
    foreach (C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99) as $index => $vip) {
        $s = '';
        if($_GET['viptype']== $vip['id']){
            $s = 'selected';
        }
        $vp .= "<option $s value='{$vip['id']}'>{$vip['name']}</option>";
    }
    $vp .= '</select> ';
    echo $vp;



    if($_G['cache']['plugin']['xigua_st']) {
        $allsts = DB::fetch_all('SELECT stid,`name`,name2,uid FROM %t WHERE 1', array('xigua_st'), 'stid');
        foreach ($allsts as $v) {
            if ($v['uid']) {
                $uids[$v['uid']] = $v['uid'];
            }
        }
        $allsts[0] = array(
            'stid' => 0,
            'name' => lang('plugin/xigua_st', 'zz'),
            'name2' => lang('plugin/xigua_st', 'zz'),
        );
        asort($allsts);
        $sel1 = '<option value="-1" ' . ($_GET['sttt'] == -1 ? 'selected' : '') . '>' . lang_hb('quanbu', 0) . '</option>';
        foreach ($allsts as $index => $item) {
            $item = $item['name'];
            if ($_GET['sttt'] == $index) {
                $sel1 .= "<option value=\"$index\" selected>$item</option>";
            } else {
                $sel1 .= "<option value=\"$index\">$item</option>";
            }
        }
    }
    if($sel1){
        echo '&nbsp;'.lang_hb('fenzhanx', 0).":&nbsp;<select name=\"sttt\">$sel1</select>&nbsp;";
    }


    echo '&nbsp;&nbsp;&nbsp;';
    $lpp_se = "<select name=\"lpp\">";
    foreach (array(1, 5, 10 ,20, 50, 100, 200, 500, 1000, 5000, 10000) as $item) {
        $sellpp = '';
        if($item == $lpp){
            $sellpp = "selected";
        }
        $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
    }
    $lpp_se .= "</select>";
    echo $lpp_se;

    echo ' <input name="page" value="1" type="hidden" /><input type="submit" class="btn" value="' . cplang('search') . '" />';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu".' class="btn" >'.cplang('reset').'</a> ';

    echo ' <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&".http_build_query($_GET).'&doexport=1" class="btn" >'.lang('template', 'header_export').'</a> ';

    $listinfo = C::t('#xigua_hs#xigua_hs_hangye')->list_all(1);
    C::t('#xigua_hs#xigua_hs_hangye')->init($listinfo);
    $cat_list = C::t('#xigua_hs#xigua_hs_hangye')->get_tree_array(0);
    $tmplist = array_values($cat_list);


    echo ' <a class="btn" href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&catadd={$tmplist[0]['id']}".'">'. lang_hs('shadd', 0) .'</a>';
    echo '</div>';

    showtableheader(lang_hs('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_hs('del', 0),
        lang_hs('shijianguozhi', 0),
        lang_hs('cat', 0),
        lang_hs('ziliao', 0).'<br>'.lang_hs('imglist', 0),
        lang_hs('caozuo', 0),
        lang_hs('crts', 0) . '/' . lang_hs('upts', 0).'<br>'.
        lang_hs('liulanfenxiang', 0),
    ));

    $res = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_count_by_page($wherearr);

    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }

    $hangye = "<select name=\"\" >";
    foreach ($cat_list as $k => $v) {
        $hangye .= "<optgroup label=\"$v[name]\">";
        foreach ($v['sub'] as $kk => $vv) {
            $hangye .= "<option value=\"{$vv['pid']}_{$vv['id']}\">&nbsp;&nbsp;$vv[name]</option>";
        }
        $hangye .= '</optgroup>';
    }
    $hangye .= '</select>';

    $vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99, 'id');
    $resk = array();
    $_k = 0;
    foreach ($res as $v) {
        $id = $v['shid'];
        if($v['stid']<=0){
            $v['stid'] = 0;
        }
        if($_G['cache']['plugin']['xigua_st']){
            $extzd1 = '<select name="row['.$id.'][stida][]" multiple="multiple">';
            foreach ($allsts as $index => $item) {
                $sec12 = in_array($index, explode(',', $v['stida']))?'selected':'';
                $extzd1 .= "<option $sec12 value=\"$index\">{$item['name']}</option>";
            }
            $extzd1 .= '</select>';
        }
        $sel2 = "<select name=\"row[$id][stid]\">";
        foreach ($allsts as $index => $stitem) {
            $stitem = $stitem['name'];
            if ($v['stid'] == $index) {
                $sel2 .= "<option value=\"$index\" selected>$stitem</option>";
            } else {
                $sel2 .= "<option value=\"$index\">$stitem</option>";
            }
        }
        $sel2 .= '</select>';

        $cat_row = str_replace(
            array("<option value=\"{$v['hangye_id1']}_{$v['hangye_id2']}\"", 'name=""'),
            array("<option selected value=\"{$v['hangye_id1']}_{$v['hangye_id2']}\"", "name=\"row[$id][hangye_id2]\""), $hangye
        );

        $checked = $v['display'] ? 'checked' : '';
        $djchecked = $v['dongjie'] ? 'checked' : '';

        $appeend = '';
        foreach ($v['append_img'] as $__k => $__v) {
            $appeend .= "<p><img style='width:160px;display:block' src=\"{$__v}\" /></p>";
            $appeend .= "<p>" . nl2br($v['append_text'][$__k]) . "</p>";
        }

        $shqr  = hs_qrmake($_G['siteurl'].$SCRITPTNAME.'?id=xigua_hs&ac=view&shid='.$id.'&lijifuk=1&idu='.$v['uid']);
        $img = "<a href='$shqr' target='_blank'><img src='$shqr' style='width:40px;height:40px;' /></a>  ";
        $img .= $v['logo'] ? "<a href='{$v['logo']}' target='_blank'><img src='{$v['logo']}' style='width:40px;height:40px;' /></a>  " : '';
        $img .= $v['qr'] ? "<a href='{$v['qr']}' target='_blank'><img src='{$v['qr']}' style='width:40px;height:40px;' /></a>  " : '';
        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $c = ($v['endts'] < TIMESTAMP ? 'style="color:red"' : 'style="color:forestgreen"');
        $c2 = lang_hs('shijianguozhi', 0);

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id ",
            "<div style='width:180px'>".

            "<p><b>{$vips[$v['viptype']]['name']}</b>"."</p>".

            '<p>'.lang_hs('shenhe', 0)."<input type='hidden' name='row[$id][id]' value='$id' /><input type='checkbox' class='checkbox' name='row[$id][display]' $checked value='1' />".
            lang_hs('dongjie', 0)."<input type='checkbox' class='checkbox' name='row[$id][dongjie]' $djchecked value='1' />".'</p>'.

            "<b $c>" .$c2.'</b>:'.'<input onclick="showcalendar(event, this, 1)" style="width:96px" name="row['.$id.'][endts]" value="'.($v['endts'] ? dgmdate($v['endts'], 'Y-m-d H:i') : '' ) . '"/><br>'.
            ($v['dig_startts'] ? (lang_hs('dig_startts', 0).':<b style=color:forestgreen>'. dgmdate($v['dig_startts'], 'Y-m-d H:i').'</b><br>') : '').
            ($v['dig_endts'] ? (lang_hs('dig_endts', 0).':<b style=color:forestgreen>'. dgmdate($v['dig_endts'], 'Y-m-d H:i').'</b><br>') : '').
            '</div>',
            ($allsts[$v['stid']]['name'] ? '<em class="c9">'.lang_hb('sszd1',0).':</em> '.$sel2 .'<br><br>' : '').
            ($extzd1 ? '<em class="c9">'.lang_hb('sszd2',0).':</em> '. $extzd1 .'<br><br>' : '').
            '<em class="c9">'.lang_hs('suoshuhangye',0).':</em> '.$cat_row,

            '<span class="ctt">'.lang_hs('yhm', 0).': </span><b>' . $users[$v['uid']]['username'].' [UID: '.$v['uid'].' ]</b><br>'.
            '<span class="ctt">'.lang_hs('shname', 0) . ': </span><b style="color:forestgreen">' . $v['name'] . '</b><br>' . '<span class="ctt">'.lang_hs('tel', 0) . ': </span><b>' . $v['tel'].'</b><br>' .
            ($v['tag'] ? '<span class="ctt">'.lang_hs('tag',0).":</span> <b style=\"color:forestgreen\">{$v['tag']}</b><br>" : '') .
            '<span class="ctt">'.lang_hs('ssqy', 0).': </span><b style="display:inline-block;max-width:240px">'. $v['province'] . ' ' . $v['city'] . ' ' . $v['district'] . ' ' . $v['street'] . ' ' . $v['street_number'] . '' . $v['addr'] . '</b><br>'. '<span class="ctt">'.lang_hs('latlng',0) .': </span><b>'. $v['lat'] . ',' . $v['lng'].'</b>'.

            '<div style="width:300px;max-height:100px;overflow-y:auto;color:#999;margin:5px 0;">' .
            ($v['xuanchuan'] ? "<b style='color:orangered'>".lang_hs('ac_xuanchuan', 0).": {$v['xuanchuan']}</b><br>" : '') .
            ($v['shipin'] ? "<a target='_blank' href=\"{$v['shipin']}\" style=display:block>".lang_hs('shipin', 0)."</a> " : '') .
            ($v['quanjing'] ? "<a target='_blank' href=\"{$v['quanjing']}\" style=display:block>".lang_hs('quanjing', 0)."</a> " : '') .
            "<div class='appendimgs'>{$v['jieshao']}$appeend</div>".
            '</div>'.
            '<div style="width:260px;max-height:100px;overflow-y:auto">' . $img . '</div>',

            '<a class="abtn" style="white-space:nowrap" href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&shid=$id" . '">' . lang_hs('moreprofile', 0) . '</a>'.
            ' <a class="abtn" style="white-space:nowrap" href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&peisong=1&shid=$id" . '">' . lang_hs('youfei', 0) . '</a>'
           . '<br> <a class="abtn" style="white-space:nowrap" href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&yuangong=1&shid=$id" . '">' . lang_hs('dianyuan', 0) . '</a>',

            date('Y-m-d H:i:s', $v['crts']) . '<br>' .
            date('Y-m-d H:i:s', $v['upts']).'<br>'.
            $v['views'] . '/' . $v['shares'] . '/' . $v['follow'],
        ));

        $_k++;
        $resk[$_k][] = $v['uid'];
        $resk[$_k][] = date('Y-m-d H:i', $v['endts']);
        $resk[$_k][] = $v['name'];
        $resk[$_k][] = $v['hangyes'][0].' '.$v['hangyes'][1];
        $resk[$_k][] = $v['tel'];
        $resk[$_k][] = $vips[$v['viptype']]['name'];
        $resk[$_k][] = trim(str_replace(array("\n","\r",','), '', $v['jieshao']));
        $resk[$_k][] = $v['province'];
        $resk[$_k][] = $v['city'];
        $resk[$_k][] = $v['district'];
        $resk[$_k][] = $v['addr'];
        $resk[$_k][] = $v['lng'];
        $resk[$_k][] = $v['lat'];
        $resk[$_k][] = $v['xuanchuan'];
        $resk[$_k][] = $v['logo'];
        $resk[$_k][] = $v['qr'];
        $resk[$_k][] = $v['stid'];
        $resk[$_k][] = $v['album'][0];
        $resk[$_k][] = $v['album'][1];
        $resk[$_k][] = $v['album'][2];
        $resk[$_k][] = $v['album'][3];
        $resk[$_k][] = $v['album'][4];
        $resk[$_k][] = $v['album'][5];
        $resk[$_k][] = $v['album'][6];
        $resk[$_k][] = $v['album'][7];
        $resk[$_k][] = $v['album'][8];
        $resk[$_k][] = $v['album'][9];
    }
    if($_GET['doexport']==1){
        $title_arr= explode(',', lang_hs('title_ary',0));
        $resk = array_values($resk);
        export_csv($resk, $title_arr);
    }



    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&" . http_build_query($_GET) . "&hangye_id2={$_GET['hangye_id2']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&lpp=$lpp&" . http_build_query($_GET).'&doexport=0', 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
}

function export_csv($data,$title_arr){
    @ini_set("max_execution_time", "3600");
    $csv_data = '';
    $nums = count($title_arr);
    for ($i = 0; $i < $nums - 1; ++$i) {
        $csv_data .= $title_arr[$i] . ',';
    }
    if ($nums > 0) {
        $csv_data .= $title_arr[$nums - 1] . "\r\n";
    }
    foreach ($data as $k => $row) {
        $_tmp_csv_data = '';
        foreach ($row as $key => $r){
            $row[$key] = str_replace("\"", "\"\"", $r);

            if ( $_tmp_csv_data == '' ) {
                $_tmp_csv_data = $row[$key];
            }
            else {
                $_tmp_csv_data .= ','. $row[$key];
            }

        }

        $csv_data .= $_tmp_csv_data.$row[$nums - 1] . "\r\n";
        unset($data[$k]);
    }

    @ob_end_clean();
    $file_name = date('Ym-d-H-i-s', TIMESTAMP) . '.csv';
    header('Content-Type: application/download');
    header("Content-type:text/csv;");
    header("Content-Disposition:attachment;filename=" . $file_name);
    header('Cache-Control:must-revalidate,post-check=0,pre-check=0');
    header('Expires:0');
    header('Pragma:public');
    echo $csv_data;
    exit;
}?>
<script type="text/javascript" src="static/js/calendar.js"></script>