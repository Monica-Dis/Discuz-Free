<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_hb:common_header}-->
<!--{if $hs_config[shlogo]}--><img src="$hs_config[shlogo]" style="visibility:hidden;position:absolute;left:-9999px;top:-9999px" /><!--{/if}-->
<!--{template xigua_hs:header}-->
<!--{eval
if($_GET[style]):
    $hs_config[srchstyle] = intval($_GET[style]);
endif;
}-->
<!--{if $_G['cache']['plugin']['xigua_f']['defaultlogo']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$_G['cache']['plugin']['xigua_f']['defaultlogo']" /></div><!--{/if}-->
<header class="x_header bgcolor_11 cl  weui-flex f15" <!--{if $hs_config[srchstyle]!=3}-->style="background:transparent!important;position:absolute"<!--{/if}-->>
<!--{if $_G['cache']['plugin']['xigua_hs']['openfz'] && $_G['cache']['plugin']['xigua_st']['showfz']}-->
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_hs");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
<!--{else}-->
<a class="z x_logo" href="$SCRITPTNAME?id=xigua_hs$urlext"><!--{if strpos($hs_config['pindaologo'],'/')!==false}--><img src="$hs_config['pindaologo']" /><!--{else}--><span style="margin:0 .75rem">$hs_config['pindaologo']</span><!--{/if}--></a>
<!--{/if}-->
    <!--{if $hs_config[srchstyle]!=1}-->
<form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
    <input type="hidden" name="id" value="xigua_hs"> <input type="hidden" name="ac" value="hangye">
    <input type="hidden" name="st" value="$_GET[st]">
    <input type="hidden" name="idu" value="$_GET[idu]">
    <input type="hidden" name="zoom" value="{$hs_config[indexzoom]}">
    <input name="keyword" class="x_logo_input" type="text" value="" placeholder="{echo $keyword ? $keyword : $hs_config[defaultstxt]}" x-webkit-speech="" style="background: rgba(255,255,255,.8)">
    <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
</form>
    <!--{/if}-->
</header>
<!--{if $hs_config[srchstyle]==3}--><div style="width:100%;height:2.1rem"></div><!--{/if}-->
<div class="page__bd">
<!--{if $topnavslider}-->
<div class="swipe cl">
    <div class="swipe-wrap">
        <!--{loop $topnavslider $slider}-->
        <div>$slider</div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $topnavslider $k $slider}-->
            <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{/if}-->
<div style="height:1.5rem;<!--{if !$topnavslider}-->margin-top:1.5rem;<!--{/if}-->" class="bgf">
    <div class="flnav tl">
    <!--{if $hs_config[srchstyle]==1}-->
        <div class="y">
<!--<a class="index_search f15"><i class="weui-icon-search main_color"></i>{lang xigua_hs:search}</a>-->
            <a class="index_search f14">
                <img class="hsindexs" src="source/plugin/xigua_hs/static/images/search.png">
                <span style="margin-left:1.1rem">{lang xigua_hs:search}</span></a>
        </div>
        <!--{/if}-->
        <div class="weui-cell__bd">
            <span class="f14">{lang xigua_hs:pu}<em class="main_color">{echo hb_trans($totalviews);}{lang xigua_hs:ci}</em></span>
            <span class="ml3 f14">{lang xigua_hs:yiruzhu}<em class="main_color">{echo hb_trans($totalpub);}{lang xigua_hs:jia}</em></span>
            <!--<span class="ml3 f14">{lang xigua_hs:fenxiangliang}<em class="main_color">{echo hb_trans($totalshares);}</em></span>-->
        </div>
    </div>
</div>
<!--{eval
    if(!$numi1 = $hs_config['numi1']*2):
        $numi1 = 10;
    endif;
    $jing_count = range(0, ceil(count($jing_list)/$numi1)-1);
}-->
    <!--{if $jing_list}-->
    <nav class=" nav-list cl swipe">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $jing_list $k $n}-->
                    <!--{if $k && $k%$numi1==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li<!--{if $hs_config['numi1']!=5&&$hs_config['numi1']>0}--> {eval echo "style='width:".(100/$hs_config['numi1'])."%'";}<!--{/if}-->>
                        <a href="{echo $n['cat_link'] ? $n['cat_link'] : "$SCRITPTNAME?id=xigua_hs&ac=hangye&hyid=".$n[id].$urlext}">
                            <span>
                                <img class="lazyload2"  data-src="$n['icon']"/>
                            </span>
                            <em class="m-piclist-title">{$n['name']}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position position1">
                <!--{loop $jing_count $k $v}-->
                <li {if $k==0} class="current" {/if}></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </nav>
    <!--{/if}-->

<!--{eval
$adwhere = array();
$adwhere[] = 'types=\'\'';
$index_list =  C::t('#xigua_hs#xigua_hs_index')->list_by_where($adwhere);
$newindex_list = array();
if($index_list):
    foreach ($index_list as $index => $item):
        $newindex_list[$item['style']][] = $item;
    endforeach;
endif;
}-->
<!--{loop $newindex_list $_k $_v}-->
    <!--{if $_k==99}-->
    <div class="swipe cl" data-speed="5000">
        <div class="swipe-wrap">
            <!--{loop $_v $__k $__v}-->
            <div><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $_v $__k $__v}-->
                <li <!--{if $__k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{else}-->
    <!--{eval
    if(!$_k):
        $_k = 4;
    endif;
    $tmpp = array_chunk($_v, $_k);
    }--><!--{loop $tmpp $__k $tmpp2}-->
    <!--{eval $counttmpp2 = count($tmpp2);}-->
    <ul class="inedxicon cl">
        <!--{loop $tmpp2 $__k $__v}-->
        <li style="width:{echo 100/$counttmpp2;}%"><a href="$__v[adlink]"><img src="$__v[icon]"></a></li>
        <!--{/loop}-->
    </ul>
    <!--{/loop}-->
    <!--{/if}-->
<!--{/loop}-->

    <div class="hs_toutiao">
        <div class="chip-row">
            <div class="toutiao">$hs_config[toutitle]</div>
            <div class="toutiao-slider swiper-container" id="newsSlider">
                <ul class="swiper-wrapper">
                    <!--{eval $toutiaoitems = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_hb']['toutext'])));}-->
                    <!--{loop $toutiaoitems $toutiaoitem}-->
                    <!--{eval list($font, $link)= explode(",", trim($toutiaoitem)); }-->
                    <li class="swiper-slide"> <a href="$link">$font</a> </li>
                    <!--{/loop}-->
                    <!--{loop $newest $v}-->
                    <li class="swiper-slide"> <a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]{$urlext}"> <img  class="lazyload2"  data-src="{$v[logo]}" onerror="this.error=null;this.src='$hs_config[dftshlogo]'" /> <em class="main_color">{$v[name]}</em> {lang xigua_hs:cgrz} [{$v[crts_u]}]</a> </li>
                    <!--{/loop}-->
                </ul>
            </div>
            <a class="toutiao main_color pr0" href="$SCRITPTNAME?id=xigua_hs&ac=enter&from=index{$urlext}">{lang xigua_hs:wyrz}</a>
        </div>
    </div>

<!--{eval include_once DISCUZ_ROOT.'source/plugin/xigua_hs/include/c_shlist.php';}-->
<!--{if $sh_list}-->
    <div class="weui-cells__title weui_title border_none"><span class="f15">{lang xigua_hb:hotsh}</span>  <a class="y c9" href="$SCRITPTNAME?id=xigua_hs&ac=hangye">{lang xigua_hb:more}<i class="f13 iconfont icon-jinrujiantou"></i></a></div>
    <div class="weui-cells after_none before_none p15 pt0">
        <div class="sh_slider">
            <ul class="shangjia" style="width:{$shwidth}px">
                <!--{loop $sh_list $shi}-->
                <li class="s_shangjia">
                    <a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid={$shi[shid]}">
                        <div class="picture"><img  class="lazyload2"  data-src="{$shi[logo]}"></div>
                        <span class="sh_name">{$shi[name]}</span>
                    </a>
                </li>
                <!--{/loop}-->
                <li class="sh_more"> <a href="$SCRITPTNAME?id=xigua_hs&ac=enter&from=hb"> <span class="color-red">{lang xigua_hb:shin}<i class="f13 iconfont icon-jinrujiantou color-red"></i></span>  </a> </li>
            </ul>
        </div>
    </div>
<!--{/if}-->

    <!--{if $midnavslider}-->
    <div class="weui-cells after_none before_none">
        <div class="swipe cl">
            <div class="swipe-wrap">
                <!--{loop $midnavslider $slider}-->
                <div>$slider</div>
                <!--{/loop}-->
            </div>
            <nav class="cl bullets bullets1">
                <ul class="position">
                    <!--{loop $midnavslider $k $slider}-->
                    <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                    <!--{/loop}-->
                </ul>
            </nav>
        </div>
    </div>
    <!--{/if}-->
<!--{if ($hs_config[mapindex]||$_GET[showmap]) && is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/template/touch/map.php')}-->
    <!--{eval $mapjs=1;$hs_config[zooml]=$hs_config[indexzoom];}-->
    <!--{template xigua_hs:map}-->
<!--{else}-->
    <div class="weui-cells fixbanner before_none after_none">
        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <!--{if $hs_config[indexorder]=='newin'}-->
            <a href="javascript:;" class="weui-navbar__item weui_bar__item_on listcat" data-query="viewtype=new&st={$_GET['st']}"><span>{lang xigua_hs:newin}</span></a>
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="st={$_GET['st']}"><span>{lang xigua_hs:hot}</span></a>
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="viewtype=near&st={$_GET['st']}" data-needgeo="1"><span>{lang xigua_hs:near}</span></a>
            <!--{elseif $hs_config[indexorder]=='near'}-->
            <a id="nearctrl" href="javascript:;" class="weui-navbar__item weui_bar__item_on listcat" data-query="viewtype=near&st={$_GET['st']}" data-needgeo="1"><span>{lang xigua_hs:near}</span></a>
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="st={$_GET['st']}"><span>{lang xigua_hs:hot}</span></a>
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="viewtype=new&st={$_GET['st']}"><span>{lang xigua_hs:newin}</span></a>
            <!--{elseif $_G['cache']['plugin']['xigua_dp'] && $hs_config[indexorder]=='dp' && $hs_config[showdp]}-->
            <a href="javascript:;" class="weui-navbar__item listcat weui_bar__item_on" data-query="id=xigua_dp&ac=dp_li&st={$_GET['st']}"><span>{lang xigua_dp:dp}</span></a>
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="st={$_GET['st']}"><span>{lang xigua_hs:hot}</span></a>
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="viewtype=new&st={$_GET['st']}"><span>{lang xigua_hs:newin}</span></a>
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="viewtype=near&st={$_GET['st']}" data-needgeo="1"><span>{lang xigua_hs:near}</span></a>
            <!--{else}-->
            <a href="javascript:;" class="weui-navbar__item weui_bar__item_on listcat" data-query="st={$_GET['st']}"><span>{lang xigua_hs:hot}</span></a>
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="viewtype=new&st={$_GET['st']}"><span>{lang xigua_hs:newin}</span></a>
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="viewtype=near&st={$_GET['st']}" data-needgeo="1"><span>{lang xigua_hs:near}</span></a>
            <!--{/if}-->
            <!--{if $_G['cache']['plugin']['xigua_dp'] && $hs_config[showdp]&&$hs_config[indexorder]!='dp'}-->
            <a href="javascript:;" class="weui-navbar__item listcat" data-query="id=xigua_dp&ac=dp_li&st={$_GET['st']}"><span>{lang xigua_dp:dp}</span></a>
            <!--{/if}-->
            <a href="javascript:;" class="weui-navbar__item listcat none" data-query="id=xigua_hs&ac=myshop_li&fav=1&st={$_GET['st']}"><span>{lang xigua_hs:guanzhu}</span></a>
        </div>
    </div>
<!--{if $_G['cache']['plugin']['xigua_dp'] && $hs_config[showdp]}--><style>
.dp_index{width:calc(100% - 1rem);padding:0 .5rem 0!important}
.dp_li{float:left;background:#fff;border-radius:.2rem;box-shadow:0 0 .5rem #eee;margin-top:.5rem;overflow:hidden;width:calc(50% - .25rem);margin-right:.5rem}
.dp_li img.cov{border-top-right-radius:.2rem;border-top-left-radius:.2rem;width:100%;display:block;height:50vw;max-height:15rem}
.dp_li:nth-child(2n){margin-left:0;margin-right:0}
.dp_li:last-child{margin-bottom:.5rem}
.dp_li .avat{height:1rem;width:1rem;border-radius:100%;position:absolute;left:.5rem;top:.25rem}
.dp_li .tit{color:#3d3d3d;font-size:.65rem;line-height:1rem;min-height:1rem;padding:.4rem .5rem 0;overflow:hidden;text-overflow:ellipsis;-webkit-line-clamp:1;-webkit-box-orient:vertical;word-break:normal;display:-webkit-box}
.dp_li .usrr{display:flex;justify-content:center;align-items:center;height:1.5rem;line-height:1.5rem;position:relative;font-size:.6rem}
.dp_li .usrr a{display:block}
.dp_li_img{position:relative;overflow:hidden}
.dp_li_img .emvdo{height:1.5rem;width:1.5rem;background-size:1.5rem;right:.5rem;top:.5rem;left:auto}
.dp_li .usrr a:first-child{flex:1;padding-left:1.8rem;height:1.5rem;overflow:hidden}
.dp_li .usrr a:last-child img{width:.6rem;height:.6rem;position:absolute;top:.45rem;left:0;display:block}
.dp_li .usrr a:last-child{position:relative;padding:0 .5rem 0 .75rem;display:inline-block}

</style><!--{/if}-->
    <!--{template xigua_hs:list_cat}-->
<!--{/if}-->
</div>
<!--{template xigua_hs:search}-->
<!--{if $newest}--><script>var TOUTIAOS = [];
<!--{loop $newest $v}-->
<!--{eval $v[cat_name] = $v[cat_name] ? $v[cat_name] : $tmpcats[$v[catid]][name];}-->
TOUTIAOS.push("<a href=\"$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]\"> <img src=\"{$v[logo]}\" class='avt' /> <em class=\"main_color\">{$v[name]}</em> {lang xigua_hs:cgrz} [{$v[crts_u]}]</a>");
<!--{/loop}--></script>
<!--{/if}-->
<!--{eval $tabbar=0;$hs_tabbar=1;}-->
<!--{template xigua_hs:footer}-->
<!--{template xigua_hb:common_footer}-->
<!--{if $hs_config[indexorder]=='near'}--><script>
if(typeof wx !=='undefined') {
    wx.ready(function () { $('#nearctrl').trigger('click'); });
}else{
    setTimeout(function () { $('#nearctrl').trigger('click'); }, 120);
}
</script><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_st']['dingwei'] && !getcookie('setcitygeo')}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script>
function autolbshs(){
hs_getlocation(function (position) {
var citylat = (position.latitude||position.lat);
var citylng = (position.longitude||position.lng);
$.ajax({
type: 'GET',
url: _APPNAME + '?id=xigua_hs&ac=getloc&checkst=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
dataType: 'xml',
success: function (data) {
if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
var s = data.lastChild.firstChild.nodeValue;
var m = s.split('|');
if('success' == m[0]){
var _t = m[1].split(',');
console.log(_t);
if(_t[0]>0 && _t[0]!='{$_GET[st]}'){
$.confirm("{lang xigua_hb:dqdws}"+_t[1]+'{lang xigua_hb:setcitygeo2}', function() {
hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
window.location.href = _APPNAME+"?id=xigua_hs&st="+_t[0];
}, function() {
hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
});
}else{
hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
}
}else{
}
}
});
});
}
if(typeof wx!='undefined'){
wx.ready(function () { autolbshs(); });
}else{
setTimeout(function(){ autolbshs(); }, 300);
}
</script>
<!--{elseif (trim($config['getbygeo']) && !getcookie('setcitygeo'))}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script>
function autocitydw(){
hs_getlocation(function (position) {
var citylat = (position.latitude||position.lat);
var citylng = (position.longitude||position.lng);
$.ajax({
type: 'GET',
url: _APPNAME + '?id=xigua_hs&ac=getloc&geoauto=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
dataType: 'xml',
success: function (data) {
if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
var s = data.lastChild.firstChild.nodeValue;
console.log(s);
var m = s.split('|');
if('success' == m[0]){
$.confirm("{lang xigua_hb:setcitygeo1}"+m[1].split(':')[0]+'{lang xigua_hb:setcitygeo2}', function() {
hb_setcookie('setcitygeo', 1, 3600);
window.location.href = _APPNAME+"?id=xigua_hs&"+m[1].split(':')[1]+_URLEXT;
}, function() {
hb_setcookie('setcitygeo', 1, 3600);
});
}else{
hb_setcookie('setcitygeo', 1, 3600);
}
}
});
});
}
if(typeof wx!='undefined'){
wx.ready(function () { autocitydw(); });
}else{
setTimeout(function(){ autocitydw(); }, 350);
}
</script>
<!--{/if}-->
<!--{if $shwidthauto&& $shtime&&$_G['cache']['plugin']['xigua_hs']['sh_list']&& $_G['cache']['plugin']['xigua_hs'][autosh]}-->
<script>var SH_SLIDER = $('.sh_slider');
SH_SLIDER.animate({"scrollLeft":$shwidthauto}, $shtime, 'linear');
SH_SLIDER.on('scroll', function(){
    if($(this).scrollLeft()>=$shwidthauto){
        $(this).animate({"scrollLeft":0}, 1, 'linear');
        $(this).animate({"scrollLeft":$shwidthauto}, $shtime, 'linear');
    }
});
SH_SLIDER.on('touchstart', function () {
    SH_SLIDER.stop().unbind();
});</script><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_dp'] && $hs_config[showdp]}-->
<script>$(document).on('click', '.dp_jump', function () {var that = $(this);var jmpurl = _APPNAME + '?id=xigua_dp&ac=view&cid=' + that.data('id') + (that.data('stid') ? '&st=' + that.data('stid') : '') + (typeof _URLEXT !== 'undefined' ? _URLEXT : '');
if (typeof mag !== 'undefined') {
mag.newWin(GSITE + jmpurl);
return false
}
if (typeof wx !== 'undefined') {
if (window.__wxjs_environment === 'miniprogram') {
GSITE = GSITE.replace(/http:\/\//, 'https://');
wx.miniProgram.navigateTo({url: '/pages/index/index?url=' + encodeURIComponent(GSITE + jmpurl)});
return false
}
}
window.location.href = jmpurl;return false;
});</script>
<!--{/if}-->
<!--{if $mapjs}-->
<!--{template xigua_hs:mapjs}-->
<!--{/if}-->