<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hs:tabbar}-->
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}" charset="utf-8"></script>
<!--{if ($config[floatleft]!=2 && $shdata[qr]&& $hs_config[view_qr]) || ($_G[uid] && $_G[uid]==$v[uid]&& $ac=='view') || (!$v[uid]&& $ac=='view')}-->
<div class="left_float">
<!--{if $shdata[qr] && $hs_config[view_qr]}-->
    <span style="line-height:1.2" onclick='$.alert("<img src=$shdata[qr] /><br>{lang xigua_hs:gengduodongtai}", "{lang xigua_hs:guanzhu_sj}");'>{lang xigua_hb:kefu1}</span>
<!--{/if}-->
    <!--{if ($_G[uid] && $_G[uid]==$v[uid]&& $ac=='view')}-->
    <span style="line-height:1.2" onclick='jumpmanagesh({$shdata[shid]});'>{lang xigua_hs:gl}</span>
    <!--{/if}-->
    <!--{if (!$v[uid] && $ac=='view')}-->
    <span style="line-height:1.2" class="renling">{lang xigua_hs:rl}</span>
    <!--{/if}-->
</div>
<!--{/if}-->
<!--{if (!$v[uid] && $ac=='view')}-->
<script>$(document).on('click','.renling', function () {
$.prompt({title: '{lang xigua_hs:rl}{$v[name]}',text: '{lang xigua_hs:rlshmc}',input: '',empty: false,
onOK: function (input) {
    $.showLoading();
    $.ajax({
        type: 'post',
        url: '$SCRITPTNAME?id=xigua_hs&ac=cmt&do=renling&inajax=1',
        data:{formhash:'{FORMHASH}', shid:'$shid', text: input},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () {$.hideLoading();}
    });
}});document.getElementById('weui-prompt-input').focus();});
</script>
<!--{/if}-->
<script src="source/plugin/xigua_hb/static/lazyload.min.js?{VERHASH}" ></script>
<script type="text/javascript" charset="utf-8">
    $("img.lazyload2").lazyload();
    var loadingCallback = function () {
        $("img.lazyload2").lazyload();
    };
</script>