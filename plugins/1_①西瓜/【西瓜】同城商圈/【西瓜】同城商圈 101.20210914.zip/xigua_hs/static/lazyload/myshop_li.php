<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval include_once DISCUZ_ROOT.'source/plugin/xigua_hs/include/c_shtel.php';}--><!--{loop $list $v}-->
<div class="sp_item" id="li_{$v['shid']}" data-id="{$v[shid]}" data-lat="$v[lat]" data-lng="$v[lng]" data-addr="$v[addr]" data-title="{$v[name]}">
    <div class="sp_thumb sh_jump" data-id="{$v['shid']}"><img class="lazyload2" data-src="{$v['logo']}" onerror="this.error=null;this.src='{$hs_config[dftshlogo]}'"><!--{if $v[end]}--><div class="ygqhs ygqhs2"></div><!--{/if}--><!--{if $vips[$v[viptype]][icon]}--><b class="crown" style="background-image:url({$vips[$v[viptype]][icon]})"></b><!--{/if}--></div>
    <div class="sp_main sh_jump" data-id="{$v['shid']}">
        <div class="sp_content">
            <div class="weui-flex">
                <h3 class="weui-flex__item"><!--{if $v[dig]}--><em class="is-star dig_tag">{lang xigua_hs:dig}</em> <!--{/if}-->{$v['name']} <!--{if $v[shipin]||$v[video]}--><em class="color-red hs_tag"><i class="iconfont icon-shipin"></i></em><!--{/if}--><!--{if $v[quanjing]}--><em class="color-red hs_tag"><i class="iconfont icon-icon-test"></i></em><!--{/if}--><!--{if 0&&$v[end]}--><em class="hs_tag"><i class="iconfont icon-jubao c9 f12"> {lang xigua_hs:guoqi}</i></em><!--{/if}--><!--{if !($_G[cache][plugin][xigua_hr][qytb]||$_G[cache][plugin][xigua_hr][bzjtb]) && ($veris2[$v[shid]] || $bao[$v[uid]])}-->
                        <!--{if $veris2[$v[shid]]}--><!--{if $_G[cache][plugin][xigua_hr][qytb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][qytb]" /> <!--{else}--><i class="iconfont icon-qiyerenzheng color-dropbox vm"></i><!--{/if}--><!--{/if}-->
                        <!--{if $bao[$v[uid]]}--><!--{if !$bao[$v[uid]][icon]}--><!--{eval $bao[$v[uid]][icon] = $_G[cache][plugin][xigua_hr][bzjtb];}--><!--{/if}--><!--{if $bao[$v[uid]][icon]}--><img class="rzimg vm" src="$bao[$v[uid]][icon]" /> <!--{else}--><i class="iconfont icon-baozhengjinmoshi color-good vm pr_1" style="font-size:.95rem"></i><!--{/if}--><!--{if $_G[cache][plugin][xigua_hr][bzjed]}--><span class="f13 main_color">{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</span><!--{/if}--><!--{/if}-->
                    <!--{/if}--></h3>
<!--{if $viewtype =='new'}-->
<span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]" <!--{if $hs_config['showtel']>0}-->style="position:absolute;right:-1.5rem"<!--{/if}-->><!--{eval $v[crts_u]=str_replace('&nbsp;', '', $v[crts_u])}-->{echo strpos($v[crts_u], '-')!==false ? date('m-d', strtotime($v[crts_u])) : $v[crts_u]}{lang xigua_hs:ruzhu}</span>
<!--{elseif $viewtype =='near'}-->
<span class="li_location tag-gray" data-lat="$v[lat]" data-lng="$v[lng]" <!--{if $hs_config['showtel']>0}-->style="position:absolute;right:-1.5rem"<!--{/if}-->>{$v[distance]}</span>
<!--{elseif $viewtype =='guanzhu'}-->
<span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]" <!--{if $hs_config['showtel']>0}-->style="position:absolute;right:-1.5rem"<!--{/if}-->>{echo hb_trans($v[follow])}{lang xigua_hs:guanzhu}</span>
<!--{elseif $viewtype =='fenxiang'}-->
<span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]" <!--{if $hs_config['showtel']>0}-->style="position:absolute;right:-1.5rem"<!--{/if}-->>{echo hb_trans($v[shares])}{lang xigua_hs:fenxiang}</span>
<!--{else}-->
<!--{if !$_GET[is_my]}--><span class="li_location" data-lat="$v[lat]" data-lng="$v[lng]" <!--{if $hs_config['showtel']>0}-->style="position:absolute;right:-1.5rem"<!--{/if}-->>{echo hb_trans($v[views])}{lang xigua_hs:view}</span><!--{/if}-->
<!--{/if}--></div>

            <!--{if ($_G[cache][plugin][xigua_hr][qytb]||$_G[cache][plugin][xigua_hr][bzjtb]) && ($veris2[$v[shid]] || $bao[$v[uid]])}-->
            <p class="sp_desc sp_tag">
                <span>{lang xigua_hr:zizhi}</span>
            <!--{if $veris2[$v[shid]]}--><!--{if $_G[cache][plugin][xigua_hr][qytb]}--><img class="rzimg vm" src="$_G[cache][plugin][xigua_hr][qytb]" /> <!--{else}--><i class="iconfont icon-qiyerenzheng color-dropbox vm"></i><!--{/if}--><!--{/if}-->
            <!--{if $bao[$v[uid]]}--><!--{if !$bao[$v[uid]][icon]}--><!--{eval $bao[$v[uid]][icon] = $_G[cache][plugin][xigua_hr][bzjtb];}--><!--{/if}--><!--{if $bao[$v[uid]][icon]}--><img class="rzimg vm" src="$bao[$v[uid]][icon]" /> <!--{else}--><i class="iconfont icon-baozhengjinmoshi color-good vm pr_1" style="font-size:.95rem"></i><!--{/if}--><!--{if $_G[cache][plugin][xigua_hr][bzjed]}--><span class="f13 main_color">{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}</span><!--{/if}--><!--{/if}-->
            </p><!--{/if}-->

            <!--{if $v[tags]}-->
            <p class="sp_desc main_color sp_tag">
                <!--{loop $v[tags] $tag}-->
                <span class="mod-feed-tag b-color12" style="line-height:.9rem">$tag</span>
                <!--{/loop}-->
            </p>
            <!--{else}-->
            <p class="sp_desc main_color sp_tag">
                <!--{loop $v[hangyes] $hy}-->
                <span class="mod-feed-tag b-color12" style="line-height:.9rem">$hy</span>
                <!--{/loop}-->
            </p>
            <!--{/if}-->

            <!--{if $_GET[is_my]}--><p class="sp_desc c9"><!--{if !$v[display]}-->{lang xigua_hs:daishen}<!--{elseif 0==$v[endts]}-->{lang xigua_hs:weizhifu}<!--{else}--><b>{$vips[$v[viptype]][name]}</b> <!--{if $vips[$v[viptype]][days]!='9999'}-->{$v[endts_u]}{lang xigua_hs:guoqi}<!--{else}-->{lang xigua_hs:yjsx}<!--{/if}--><!--{/if}--></p><!--{/if}-->

            <p class="sp_desc color-red">
                <!--{if $v[xuanchuan]}--><i class="f14 vm pr-1 iconfont icon-praise_fill"></i> {$v[xuanchuan]}<!--{else}-->
<!--{if $hs_config[showopentime]}-->
<i class="f13 vm pr-1 iconfont icon-shijian"></i> {$v[opentime]}
<!--{else}-->{echo strip_tags($v['jieshao'])}<!--{/if}-->
                <!--{/if}-->
            </p>
            <div class="weui-flex">
                <p class="weui-flex__item  color-gray"><i class="iconfont icon-mudedi vm f15 pr-1"></i> {$v[city]}{$v['addr']}</p>
            </div>
<!--{if $v[hong_num] && $v[hong_num]>$v[hong_sendnum]}-->
    <div class="weui-flex pr">
        <div class="weui-flex__item"><span class=" color-red" ><i class="iconfont icon-hongbao2 f18"></i> <span class="f12">&yen;</span><span class="f20">$v[hong_money]</span><span class="f12">{lang xigua_hb:yuan}</span></span></div>
        <!--{if $v[hong_num]>$v[hong_sendnum]}--><div class="color-red f12 hlisttip" style="bottom:0">{lang xigua_hb:qiangjinxingzhong}</div><!--{else}--><div class="color-gray f12 hlisttip" style="bottom:0">{lang xigua_hb:qaingwan}</div><!--{/if}-->
    </div>
<!--{/if}-->
        <!--{if  $v[maidanrate]>0|| $helist[$v[shid]]|| $quanlist[$v[shid]] || $seclist[$v[shid]]||$joblist[$v[shid]]}-->
            <div class="border_bottom xhm_split cl"></div>
        <!--{/if}-->
        <!--{if $quanlist[$v[shid]]}-->
            <p class="sp_desc f12 inquan">
                <span>{lang xigua_hs:yh}</span>
                {$quanlist[$v[shid]][title]}
            </p>
        <!--{/if}-->
        <!--{if $seclist[$v[shid]]}-->
            <p class="sp_desc f12 in_qiang">
                <span>{lang xigua_hm:seckill}</span>
                {$seclist[$v[shid]][title]}
            </p>
        <!--{/if}-->
        <!--{if $v[maidanrate]>0}-->
            <p class="sp_desc f12 inquan" style="color:#E96B6A"><span style="background:#E96B6A">{lang xigua_hs:zk}</span>
                {lang xigua_hs:ddmd}{echo floatval($v[maidanrate]);}{lang xigua_hs:zhe}{lang xigua_hs:yh}<!--{if $v[maidanmin]>0}-->({lang xigua_hs:man}{echo floatval($v[maidanmin]);}{lang xigua_hb:yuan}{lang xigua_hs:keyong})<!--{/if}--></p>
        <!--{/if}-->
        <!--{if $helist[$v[shid]]}-->
            <p class="sp_desc f12 inquan" style="color:#1aad19"><span style="background:#1aad19">{lang xigua_he:huodong}</span>
                {$helist[$v[shid]][title]}
            </p>
        <!--{/if}-->
        <!--{if $jobv = $joblist[$v[shid]]}-->
            <p class="sp_desc f12 inquan" style="color:#db7066"><span style="background:#db7066">{lang xigua_job:zhaopin}</span>
                {echo $jobv['type']=='part'?lang('plugin/xigua_job', 'part'):lang('plugin/xigua_job', 'full')} {$jobv[name]}
            </p>
        <!--{/if}-->
        <!--{if 0}-->
            <!--{eval
$uid = DB::result_first('select uid from %t where shid=%d', array('xigua_hs_shanghu', $v[shid]));
$xinxi = DB::fetch_first('select * from %t where uid=%d and recycle=0 AND display=1 AND endts>%d ORDER BY (dig_endts-dig_crts) DESC, up_time DESC', array('xigua_hb_pub', $uid, TIMESTAMP));
}-->
            <p class="sp_desc f12 inquan" style="color:{$config[maincolor]}"><span style="background:{$config[maincolor]}">{lang xigua_hb:xinxi}</span>
                {echo strip_tags($xinxi[description])}
            </p>
        <!--{/if}-->
        </div>
    </div>
    <!--{if $_GET[is_my]}-->
    <!--{if $manage || $_GET[hide]}-->
    <!--{eval $vips[$v[viptype]][access] = array();}-->
    <!--{/if}-->
    <a class="weui-btn weui-btn_mini whbtn" href="javascript:;" data-id="{$v['shid']}" data-title="{$v['name']}" <!--{if !$manage}-->data-vipid="{$v[viptype]}"<!--{/if}--> <!--{if in_array('qianggou', $vips[$v[viptype]][access])}-->data-qianggou="1"<!--{/if}--> <!--{if in_array('youhui', $vips[$v[viptype]][access])}-->data-youhui="1"<!--{/if}--> <!--{if in_array('dianyuan', $vips[$v[viptype]][access])}-->data-dy="1"<!--{/if}--> <!--{if in_array('gonggao', $vips[$v[viptype]][access])}-->data-gg="1"<!--{/if}--> <!--{if in_array('hongbao', $vips[$v[viptype]][access])}-->data-hb="1"<!--{/if}--> <!--{if in_array('jianjia', $vips[$v[viptype]][access])}-->data-jianjia="1"<!--{/if}--> <!--{if in_array('heika', $vips[$v[viptype]][access])}-->data-heika="1"<!--{/if}--> <!--{if in_array('pt', $vips[$v[viptype]][access])}-->data-pt="1"<!--{/if}--> <!--{if in_array('ztd', $vips[$v[viptype]][access])}-->data-ztd="1"<!--{/if}--> <!--{if in_array('huodong', $vips[$v[viptype]][access])}-->data-huodong="1"<!--{/if}--> onclick="return managesp(this);">{lang xigua_hs:caozuo}</a>

    <!--{elseif $hs_config['showtel']>0}-->
    <a class="main_color" <!--{if $v[end]&&!$showtel}-->style="visibility:hidden"<!--{/if}--> <!--{if $v[teljs]}-->$v[teljs]<!--{else}-->href="tel:{$v['tel']}"<!--{/if}-->><i class="iconfont icon-unie607 sp_tel"></i></a>
    <!--{/if}-->
</div>
<!--{/loop}-->