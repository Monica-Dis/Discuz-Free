<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/function.php';

function hs_hex2rgb($colour, $a){
    if ($colour[0] == '#') {
        $colour = substr($colour, 1);
    }
    if (strlen($colour) == 6) {
        list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
    }
    elseif (strlen($colour) == 3) {
        list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
    }
    else {
        return false;
    }
    $r = hexdec($r);
    $g = hexdec($g);
    $b = hexdec($b);
    return "rgba($r, $g, $b, $a)";
}

$access_list = array(
    'gonggao'   => lang_hs('ac_gonggao', 0),
    'xuanchuan' => lang_hs('ac_xuanchuan', 0),
    'shipin'    => lang_hs('ac_shipin', 0),
    'quanjing'  => lang_hs('ac_quanjing', 0),
    'tag'       => lang_hs('ac_tag', 0),
    'color'     => lang_hs('ac_color', 0),
    'jieshao'   => lang_hs('ac_jieshao', 0),
    'link'      => lang_hs('ac_link', 0),
    'hongbao'   => lang_hs('ac_hongbao', 0),
    'dianyuan'  => lang_hs('ac_dianyuan', 0),
    'youhui'    => lang_hs('ac_youhui', 0),
    'qianggou'  => lang_hs('ac_qianggou', 0),
    'jianjia'   => lang_hs('ac_jianjia', 0),
    'heika'     => lang_hs('ac_heika', 0),
    'mp3'       => lang_hs('ac_mp3', 0),
    'pt'        => lang_hs('ac_pt', 0),
    'cmtt'      => lang_hs('ac_cmtt', 0),
    'tcsp'      => lang_hs('ac_tcsp', 0),
    'ztd'       => lang_hs('ac_ztd', 0),
    'zxsk'      => lang_hs('ac_zxsk', 0),
    'huodong'   => lang_hs('ac_huodong', 0),
    'album'     => lang_hs('shalbum', 0),
    'qr'        => lang('plugin/xigua_hb','wxpay_qr'),
    'jieshao2'  => str_replace(lang('plugin/xigua_hb','qtx'), '', lang_hs('plzjieshao', 0)),
    'video'     => lang_hs('ac_video', 0),
    'zhuanxiang'=> lang_hs('zhuanxiang', 0),
);
$form_access_list = array('tag'=> lang_hs('desc_tag', 0),'shipin'=> lang_hs('desc_shipin', 0),'quanjing'  => lang_hs('desc_quanjing', 0),'xuanchuan' => lang_hs('desc_xuanchuan', 0),
    'color'=> lang_hs('desc_color', 0),'link'=> lang_hs('desc_link', 0),'mp3'=> lang_hs('desc_mp3', 0),);
$hs_config = $_G['cache']['plugin']['xigua_hs'];
if($hs_config['shcolors']){foreach (explode("\n", trim($hs_config['shcolors'])) as $index => $item) {list($_color, $_title) = explode('=', trim($item));
    $tmp = explode(',', $_color);$shcolor[$_title] = $tmp[0];$shbtncolor[$_title] = $tmp[1];}}
$quaninfo = array();
if($hs_config['quaninfo']){foreach (array_filter(explode("\n", trim($hs_config['quaninfo']))) as $index => $item) {$quaninfo[$index] = trim($item);}}
$aclist = array('myshop', 'myshop_li','enter','getloc','xufei','view','notice','album','incr','follow','driving','myshnum','comment','hangye', 'dodig','googleMap','redtype','qiang','hong_list','hong_li','myfav','dianyuan','shcenter','manage', 'setpwd','yyzh','chosecity','telpay', 'cmt','add_area','add_area_li','myaddr','help','v');
$aclist_login = array('enter','xufei','myshop','notice','myshnum', 'dodig','redtype','qiang','myfav','dianyuan','shcenter','manage', 'setpwd', 'yyzh','telpay', 'cmt','add_area','add_area_li','help');