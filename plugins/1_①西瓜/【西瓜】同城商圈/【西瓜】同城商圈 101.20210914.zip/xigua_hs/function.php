<?php
/**
 * Created by https://dism.taobao.com/?ac=developer&id=7402
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function hs_callback_fukuan($param){
    global $_G;
    $info = $param['info'];
    $logdata = $info['data'];
    $shid = $logdata['shid'];

    $lodig= C::t('#xigua_hs#xigua_hs_fukuan')->update($logdata['id'], array('pay_ts' => TIMESTAMP));
    $sh = $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
    $user = getuserbyuid($logdata['uid']);


    $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shdata['viptype']);
    $insxf   = intval(abs($vipinfo['insxf']))/100;
    if($shdata['shinsxf']){
        $insxf   = intval(abs($shdata['shinsxf']))/100;
    }

    $sxfee = round($insxf*$logdata['price'], 2);
    $infee = round($logdata['price']-$sxfee, 2);

    $dvars = array(
        'username' => $user['username'],
        'price' => $logdata['price'],
        'rate' => ($insxf*100).'%',
        'sxf' => $sxfee,
        'infee' => $infee,
        'url' => $_G['siteurl'].'plugin.php?id=xigua_hs&ac=help&do=fukuan&manage=1',
    );

    $note = strip_tags(str_replace(array_keys($dvars), $dvars, lang('plugin/xigua_hs','cgzf_in')));
    $note = str_replace(array('{','}'), '', $note);

    C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($sh['uid'], 'money', $infee);
    C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
        'uid'  => $sh['uid'],
        'crts' => TIMESTAMP,
        'size' => $infee,
        'note' => $note,
        'link' => $dvars['url'],
    ));

    notification_add($sh['uid'],'system',  lang('plugin/xigua_hs','cgzf_in'), $dvars);

    return true;
}

function lang_hs($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hs', $lang);
    }else{
        return lang('plugin/xigua_hs', $lang);
    }
}

function hs_createMobile($mobile = ''){
    if(!is_numeric($mobile)){
        return false;
    }
    $im = imagecreatetruecolor(320, 60);
    $white = imagecolorallocatealpha($im, 0, 0, 0, 127);
    $black = imagecolorallocate($im, 102, 102, 102);
    imagecolortransparent($im, $white);
    imagefill($im,0,0, $white);
    $text = $mobile;
    $font =  DISCUZ_ROOT.'source/plugin/xigua_hs/static/mono.ttf';
    imagettftext($im, 40, 0, 0, 47, $black, $font, $text);
    imagepng($im, DISCUZ_ROOT."source/plugin/xigua_hs/cache/$mobile.png");
    imagedestroy($im);
}

function hs_cm($shid){
    if(!C::t('#xigua_hs#xigua_hs_shanghu')->checkmine($shid)){
        if(!IS_ADMINID){
            if($_GET['inajax'] ) {
                hb_message('not allowed!', 'error');
            }else{
                showmessage('not allowed!');
            }
        }
    }
}

function hs_check_access($viptype, $access, $return = 0){
    $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($viptype);
    if(!$vipinfo){
        if($return){
            return false;
        }else{
            hb_message('no access', 'error');
        }
    }
    if(!in_array($access, $vipinfo['access'])){
        if($return){
            return false;
        }else{
            hb_message('no_access', 'error');
        }
    }
    return $vipinfo;
}

function hs_multi_diconv($string, $in_charset, $out_charset){
    if (is_array($string)) {
        foreach ($string as $key => $val) {
            $string[ $key ] = hs_multi_diconv($val, $in_charset, $out_charset);
        }
    } else {
        $string = diconv($string, $in_charset, $out_charset);
    }
    return $string;
}

function hb_current_location($lat, $lng){
    global $hs_config;
    if($hs_config['google']){
        return hb_get_location_google($lat, $lng);
    }
    $url = "http://apis.map.qq.com/ws/geocoder/v1/?location=$lat,$lng&coord_type=5&get_poi=1&key=".$hs_config['skey'];
    $ret = hb_curl($url);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        $rt = array();
        $rt[$ret['result']['address']] = array(
            'address'           => str_replace(array($ret['result']['address_component']['province'], $ret['result']['address_component']['city']), '', $ret['result']['address']),
            'address_component' => array(
                'province' => $ret['result']['address_component']['province'],
                'city'     => $ret['result']['address_component']['city'],
                'district' => $ret['result']['address_component']['district'],
                'street'   => $ret['result']['address_component']['street'],
                'street_number'=>$ret['result']['address_component']['street_number'],
            ),
            'location'          => $ret['result']['location'],
            'category'          => diconv(lang_hs('default', 0), CHARSET, 'utf-8'),
        );
        foreach ($ret['result']['pois'] as $index => $pois) {
            $rt[$pois['address']] = array(
                'address'           => str_replace(array($pois['ad_info']['province'], $pois['ad_info']['city']), '', $pois['address']),
                'address_component' => array(
                    'province' => $pois['ad_info']['province'],
                    'city'     => $pois['ad_info']['city'],
                    'district' => $pois['ad_info']['district'],
                    'street'   => '',
                    'street_number'=> '',
                ),
                'location'          => $pois['location'],
                'category'          => $pois['category'],
            );
        }
        $rt = array_values($rt);
        return  hs_multi_diconv($rt, 'utf-8', 'utf-8');
    }else{
        return hs_multi_diconv($ret['message'], 'utf-8', CHARSET);
    }
}

function hb_get_location_google($lat, $lng){
    global $hs_config;
    $latlng = $lat.','.$lng;
    $rs = hb_curl('https://maps.googleapis.com/maps/api/geocode/json?latlng='.$latlng.'&sensor=true&language=zh-CN&key='.$hs_config['google']);
    if($rs = json_decode($rs, TRUE)){
        if($rs['error_message']){
            return hs_multi_diconv($rs['status'].':'.$rs['error_message'], 'utf-8', CHARSET);
        }elseif($rs['results']){
            $r = array();
            $r['province'] = $rs['results'][0]['address_components'][5]['long_name'];
            $r['city'] = $rs['results'][0]['address_components'][4]['long_name'].' '.$rs['results'][0]['address_components'][3]['long_name'];
            $r['district'] = $rs['results'][0]['address_components'][2]['long_name'];
            $r['street'] = $rs['results'][0]['address_components'][1]['long_name'];
            $r['street_number'] = $rs['results'][0]['address_components'][0]['long_name'];
            $r['addr'] = str_replace(array($r['province'], $r['city']), '', $rs['results'][0]['formatted_address']);

            $rt = array();
            $rt[] = array(
                'address'           => $r['addr'],
                'address_component' => array(
                    'province' => $r['province'],
                    'city'     => $r['city'],
                    'district' => $r['district'],
                    'street'   => $r['street'],
                    'street_number'=>$r['street_number'],
                ),
                'location'          => array(
                    'lat' => $lat,
                    'lng' => $lng,
                ),
                'category' => diconv(lang_hs('default', 0), CHARSET, 'utf-8'),
            );
            return  hs_multi_diconv($rt, 'utf-8', 'utf-8');
        }
    }
    return 'api error';
}

function hs_price_parese($price){
    $dig_prices = array();
    foreach (explode("\n", trim($price)) as $item) {
        list($tmp_type, $tmp_price) = explode('=', trim($item));
        $tmp_lang = lang_hb('days_'.$tmp_type, 0);
        if($tmp_type==1){
            $item_price = $tmp_price;
        }
        if($tmp_type!=1 && $item_price){
            $s = ($tmp_type*$item_price)-$tmp_price;
            if($s<=0){
                $s = '';
            }else{
                $s = "<s style='color:red'>".lang_hs('province', 0)."&yen;$s</s>";
            }
        }
        $dig_prices[$tmp_type] = array(
            'type'  => $tmp_type,
            'title' => lang_hb('zhiding', 0). ($tmp_lang == "days_$tmp_type" ? $tmp_type. lang_hb('day', 0) : $tmp_lang) ."(".lang_hb('shoufei', 0)."$tmp_price".lang_hb('yuan', 0)."$s)",
            'price' => $tmp_price,
        );
    }
    return $dig_prices;
}

function hs_days_format($days, $price) {
    $price = str_replace('.00', '', $price);
    if($days >= 365) {
        $return= intval($days/365).lang_hs('nian', 0).'/';
    } elseif($days >= 30) {
        $return= intval($days/30).lang_hs('yue1', 0).'/';
    } elseif($days >= 1) {
        $return= intval($days).lang_hs('ri', 0).'/';
    }else{
        $return= '';
    }
    if($days == '9999'){
        $return = lang_hs('yongjiu', '0');
    }
    $return .= '&yen;'.($price>0? $price : lang_hs('mf',0));
    return $return;
}

function hs_strlen($str){
    $len = dstrlen($str);
    if(strtolower(CHARSET)=='gbk'){
        $len = $len/2;
    }
    return $len;
}

function hs_members($uids){
    $users = array();
    if($uids){
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    return $users;
}

function hs_minute2str($secs) {
    $r = '';
    if($secs>=1440) {
        $days = floor($secs / 1440);
        $secs = $secs % 1440;
        $r = $days . lang_hs('ri', 0);
    }
    if($secs>=60) {
        $hours = floor($secs / 60);
        $secs = $secs % 60;
        $r .= $hours . lang_hs('xiaoshi', 0);
    }
    $r .= $secs . lang_hs('fen', 0);
    return $r;
}
function hs_trans2m($m){
    $r = '';
    if($m>=1000) {
        $r = round(($m/1000), 1) . lang_hs('km', 0);
    }else{
        $r .= $m . lang_hs('m', 0);
    }
    return $r;
}
function hs_nl2br($txt){
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}

function hs_parse_media($url, $att = ''){
    global $_G;
    if( stripos($url, '.mp3')!==false){
        return "<audio style='width:100%' controls='controls'><source src=\"$url\" type=\"audio/mpeg\"></audio>";
    }
    if( stripos($url, '.mp4')!==false){
        return "<video style='width:100%;height:240px' controls='controls'><source type=\"video/mp4\" src=\"$url\"></video>";
    }
    $data = daddslashes(array(
        'attr' => $att,
        'url'  => $url,
        'formhash' => FORMHASH
    ));
    $link = $_G['siteurl']. 'plugin.php?id='.urlencode('xigua_media:fetchid').'&param='. urlencode(base64_encode(http_build_query($data)));
    $h = checkmobile() ? $_G['cache']['plugin']['xigua_media']['height']: ($_G['cache']['plugin']['xigua_media']['height']*2);
    return "<iframe class='view_iframe' style=\"height:{$h}px\" frameborder=\"0\" scrolling=\"no\" allowfullscreen=\"false\" src=\"$link\"></iframe>";
}

function hspostx($lang, $vars){
    global $adminids;
    if($adminids){
        $adminids = array_slice($adminids,0,10);
        foreach ($adminids as $adminid) {
            notification_add($adminid,'system', $lang, $vars, 1);
        }
    }
}

function hs_jihuoo($data, $form){
    global $SCRITPTNAME, $urlext, $_G, $referer;
    if($form['cardno']&&$_G['cache']['plugin']['xigua_hk']){
        $numdata = C::t('#xigua_hk#xigua_hk_num')->fetch_by_cardnum($form['cardno']);
        if(!$numdata['viptype']){
            hb_message(lang('plugin/xigua_hk', 'jhmcw'), 'error');
        }
        C::t('#xigua_hk#xigua_hk_num')->update($numdata['id'], array('uid' => $_G['uid'], 'usets' => TIMESTAMP));
        $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($numdata['viptype']);
        $data['endts'] = TIMESTAMP + ($vipinfo['days'] * 86400);
        $data['display'] = 1;
        $shid = C::t('#xigua_hs#xigua_hs_shanghu')->insert($data, true);
        dsetcookie('newshid', $shid, 7200);
        $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_hs&ac=view&shid=$shid".$urlext;
        hspostx(lang_hs('new_in',0), array('url' => $url, 'id'=>$shid));
        hb_message(lang_hs('fabuok', 0), 'success', $referer);
    }
}

function hs_shcenter_new(){
    global $_G,$custom_side,$navtitle,$list,$shid,$sh,$is_dianyuan,$SCRITPTNAME,$urlext,$vips;
    $navtitle = lang_hs('shcenter',0);
    $custom_side = array(
        'javascript:;',
        "<i class='iconfont icon-saoyisao'></i>"
    );
    $list = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('uid='.$_G['uid']), 0, 100);
    if(!$list){
        $shid = DB::result_first('select shid from %t WHERE uid=%d', array('xigua_hs_yuan',$_G['uid']),'shid');
        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);$is_dianyuan=1;
    }
    if(!$sh){
        if($_GET['shid']){
            $sh  = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
            if($sh['uid']!=$_G['uid']){
                dheader("location:"."$SCRITPTNAME?id=xigua_hs&ac=enter".$urlext);
            }
        }else{
            $sh = $list[0];
        }
    }
    if(!$sh){
        dheader("location:"."$SCRITPTNAME?id=xigua_hs&ac=enter".$urlext);
    }
    /*if($_G['cache']['plugin']['xigua_st'] && $sh['stid']>0 && $sh['stid']!=$_GET['st']){
        dheader("location:"."$SCRITPTNAME?id=xigua_hs&ac=shcenter&st=".$_GET['st']);
    }*/
    $vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99, 'id');
    foreach ($vips as $index => $vip) {
        $vips[$index]['digprice'] = hs_price_parese($vip['dig_price']);
    }
}

function hs_index_init(){
    global $aclist,$aclist_login,$ac,$do,$isself,$_G,$page,$lpp,$start_limit,$shid,$config;
    $aclist = array('myshop', 'myshop_li','enter','getloc','xufei','view','notice','album','incr','follow','driving','myshnum','comment','hangye', 'dodig','googleMap','redtype','qiang','hong_list','hong_li','myfav','dianyuan','shcenter','manage', 'setpwd','yyzh','chosecity','telpay', 'cmt','add_area','add_area_li','myaddr','help','v');
    $aclist_login = array('enter','xufei','myshop','notice','myshnum', 'dodig','redtype','qiang','myfav','dianyuan','shcenter','manage', 'setpwd', 'yyzh','telpay', 'cmt','add_area','add_area_li','help');

    $ac = $_GET['ac'];
    $do = $_GET['do'];
    if (!in_array($ac, $aclist)) {$ac='index';}
    $isself = in_array($ac, $aclist_login);
    if ($isself && !$_G['uid']) {hb_jump_login();}
    $_GET = dhtmlspecialchars($_GET);
    $page = max(1, intval($_GET['page']));
    $lpp   = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
    $start_limit = ($page - 1) * $lpp;
    $shid = intval($_GET['shid']);
    if($_GET['s']&&!$shid){
        $shid = intval($_GET['s']);
    }
    if(getcookie('miniprogram')){$config['onlytimeline'] = 'no';}
}

function hs_view_page(){
    global $v,$vipinfo,$gonggao,$followed,$custom_side,$_G,$shbtncolor,$mc,$mc_op,$shid,$config,$hs_config,$SCRITPTNAME,$urlext,$hangye,$hbcatids,$hbcat,$px,$desc,$navtitle,$shdata;
    $v = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 1);
    if(!$v){
        if($hs_config['showguoqi']){
            $v = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid, 0);
            $v['tag'] =$v['xuanchuan'] =$v['color'] =$v['hongbao'] =$v['gonggao'] = $v['shipin'] =$v['quanjing'] = '';
        }else{
            dheader("Location:$SCRITPTNAME?id=xigua_hs".$urlext);
        }
    }
    /*if($v['stid'] && !$_GET['st']){
        dheader("Location:$SCRITPTNAME?".http_build_query($_GET).'&st='.$v['stid']);
    }*/
    $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($v['viptype']);

    foreach ($vipinfo['access'] as $item) {
        if($item=='gonggao'){
            $gonggao = C::t('#xigua_hs#xigua_hs_notice')->fetch_allnotice_by_shid($shid, 2);
            break;
        }
    }

    $followed = 0;
    $v['hongbaolog'] = array();
    if($_G['uid']){
        $followed = C::t('#xigua_hs#xigua_hs_follow')->fetch_follow_by_shid_uid($shid, $_G['uid']);
        $v['hongbaolog'] = C::t('#xigua_hb#xigua_hb_hongbaolog')->fetch_by_uid_shid($_G['uid'], $shid);
    }

    $custom_side = array(
        "$SCRITPTNAME?id=xigua_hs&ac=hangye".$urlext,
        lang_hs('allcat', 0)
    );
    if(!$v['color']){
        $v['color'] = $config['maincolor'];
        $shbtncolor[$v['color_title']] = $hs_config['defaultbtncolor'];
    }else{
        $config['maincolor'] = $v['color'];
    }
    $mc = hs_hex2rgb($v['color'], 1);
    $mc_op = hs_hex2rgb($v['color'], 1);

    if($v['shipin']){
        $v['old_shipin'] = $v['shipin'];
        $v['shipin'] = hs_parse_media($v['shipin']);
    }

    $hangye = C::t('#xigua_hs#xigua_hs_hangye')->fetch_light(array($v['hangye_id1'], $v['hangye_id2']));
    foreach ($hangye as $index => $item) {
        if($item['cat_ids']){
            $hbcatids=explode(',', $item['cat_ids']);
            break;
        }
    }
    if($hbcatids){
        $hbcat = C::t('#xigua_hb#xigua_hb_cat')->fetchs_light($hbcatids);
    }

    if(!$v['shipin'] && !$v['quanjing'] && $shid){
        $v['pubs'] = C::t('#xigua_hb#xigua_hb_pub')->fetch_count_bypage(array("shid=$shid"));
    }
    $v['rank'] = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_rank($v['views']);

    $px = ($v['hong_num']>0&&$v['hong_num']>$v['hong_sendnum'])?$config['hbprefix']:'';
    $desc = cutstr(strip_tags($v['xuanchuan'] ? $v['xuanchuan'] :($gonggao[0] ? $gonggao[0]['content'] : $v['jieshao'])),80);

    $navtitle = $px.$v['name'];
    $shdata = $v;
}

function hs_qrmake($url = ''){
    $_qrfile = './source/plugin/xigua_hs/cache/' . md5($url) . '.jpg';
    if (!is_file(DISCUZ_ROOT . $_qrfile)) {
        @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
        if(class_exists('QRcode')){
            QRcode::png($url, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
        }
    }
    return $_qrfile;
}