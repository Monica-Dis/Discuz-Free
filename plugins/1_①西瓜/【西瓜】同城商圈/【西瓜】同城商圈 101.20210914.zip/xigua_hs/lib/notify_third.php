<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2018/6/15
 * Time: 18:48
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function hs_telpay_callback($param){
    $info = $param['info'];
    $uid = intval($info['data']['uid']);
    $pubid = $info['data']['shid'];

    DB::insert('xigua_hb_viewtel' , array(
        'uid' => $uid,
        'crts' => TIMESTAMP,
        'pubid' => $pubid,
        'idtype' => 'shid'
    ));
    return true;
}