<?php
/**
 * Copyright (c) 2021 by dism.taobao.com
 * User: yangzhiguo
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
DROP TABLE pre_xigua_hs_follow;
DROP TABLE pre_xigua_hs_hangye;
DROP TABLE pre_xigua_hs_notice;
DROP TABLE pre_xigua_hs_shanghu;
DROP TABLE pre_xigua_hs_vip;
DROP TABLE pre_xigua_hs_yuan;
DROP TABLE pre_xigua_pt_yf;
DROP TABLE pre_xigua_hs_addr;
DROP TABLE pre_xigua_hs_fukuan;
DROP TABLE pre_xigua_hs_index;
DROP TABLE pre_xigua_hs_renling;
DROP TABLE pre_xigua_hs_nav;
EOT;
runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/discuz_plugin_xigua_hs_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hs/install.php');

xwb_delall(DISCUZ_ROOT . "./source/plugin/xigua_hs");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_hs");

$finish = TRUE;

function xwb_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwb_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}