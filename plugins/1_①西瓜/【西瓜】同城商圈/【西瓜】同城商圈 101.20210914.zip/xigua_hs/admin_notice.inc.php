<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hs/common.php';

$page = max(1, intval(getgpc('page')));
$lpp   = 40;
$start_limit = ($page - 1) * $lpp;


if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        $r = C::t('#xigua_hs#xigua_hs_notice')->deletes($delete);
    }
    if($r){
        cpmsg(lang_hb('delete_succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_notice&page=$page", 'succeed');
    }
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_notice&page=$page");
showtableheader(lang_hb('bangzhuguanli', 0));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_hs','del'),
    lang_hs('shname', 0),
    lang_hb('subject', 0),
    lang('plugin/xigua_hs','crts'),
));

$res = DB::fetch_all("SELECT * FROM %t ORDER BY shid DESC " . DB::limit($start_limit, $lpp), array( 'xigua_hs_notice' ));
$icount = C::t('#xigua_hs#xigua_hs_notice')->fetch_count_by_page();

$shids = array();
foreach ($res as $index => $re) {
    $shids[] = intval($re['shid']);
}
if($shids){
    $shs = DB::fetch_all("SELECT * FROM %t WHERE shid in (%n)", array(
            'xigua_hs_shanghu',
            $shids
        ) , 'shid');
}

$url = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_notice&lpp=$lpp";
foreach ($res as $v) {
    $cid = $v['id'];

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$cid' /> $cid",
        $shs[$v['shid']]['name'] .' ['.$v['shid'].']',
        '<div style="max-width:450px">'.$v['content'].'</div>',
        date('Y-m-d H:i:s', $v['crts']),
    ));
}
$multipage = multi($icount, $lpp, $page, $url, 0, $lpp);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter();