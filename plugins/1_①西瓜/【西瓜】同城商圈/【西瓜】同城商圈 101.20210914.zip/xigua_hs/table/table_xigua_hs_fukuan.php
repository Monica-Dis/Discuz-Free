<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hs_fukuan extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hs_fukuan';
        $this->_pk = 'id';

        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'id DESC', $fields= '*')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i', $v['upts']) : '';
            $v['pay_ts_u'] = $v['pay_ts'] ? date('Y-m-d H:i', $v['pay_ts']) : '';
        }
        return $v;
    }

    public function fetch_by_uid($uid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
        $v = self::prepare($v);
        return $v;
    }

}