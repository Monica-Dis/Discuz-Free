<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hs_vipguide extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hs_vipguide';
        $this->_pk = 'id';

        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY displayorder ASC " . DB::limit($start_limit, $lpp));
        return $result;
    }
    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public function fetch_by_pop()
    {
        $result = DB::fetch_first('SELECT * FROM ' . DB::table($this->_table) .' WHERE indexpop=1 ORDER BY displayorder ASC');
        return $result;
    }
}