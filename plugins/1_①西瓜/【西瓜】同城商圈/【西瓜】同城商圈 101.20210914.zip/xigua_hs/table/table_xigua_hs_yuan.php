<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hs_yuan extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_hs_yuan';
        $this->_pk = 'id';

        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function fetch_all_by_page($wherearr, $start_limit, $lpp)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table) ." $wheresql ");
        return $result;
    }

    public function deletes($ids)
    {
        $shids = DB::fetch_all("SELECT shid FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids), 'shid');

        $ret = DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
        foreach ($shids as $shid => $v) {
            C::t('#xigua_hs#xigua_hs_shanghu')->incr($shid, 'yuan', -1);
        }
        return true;
    }

    public function fetch_yuan_by_shid($shid)
    {
        $res = DB::fetch_all("select uid from %t WHERE shid=%d ORDER BY id DESC", array($this->_table, $shid), 'uid');
        return array_keys($res);
    }

    public function fetch_yuan_by_shid_uid($shid, $uid)
    {
        $res = DB::fetch_first("select * from %t WHERE shid=%d AND uid=%d ORDER BY id DESC", array($this->_table, $shid, $uid));
        $res = self::prepare($res);
        if(!$res){
            $res = DB::fetch_first('select uid,shid from %t WHERE shid=%d AND uid=%d', array(
                'xigua_hs_shanghu',
                $shid,
                $uid
            ));
        }
        return $res;
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = dgmdate($v['crts'], 'u');
        }
        return $v;
    }
}