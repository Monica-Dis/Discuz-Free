<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hs_vip extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_hs_vip';
        $this->_pk = 'id';

        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function fetch($id, $force_from_db = false){
        $ret = parent::fetch($id, $force_from_db);
        return $this->prepare($ret);
    }

    public function fetch_all_by_page($start_limit, $lpp, $key_field = '')
    {
        $ret = array();

        global $_G;
        $st_config = $_G['cache']['plugin']['xigua_st'];
        /*if($_GET['ac']=='xufei' && $st_config){
            global $shid;
            $shdata =  C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
            if($shdata['stid'] && $shdata['stid']!=$_GET['st']){
                $_GET['st'] = $shdata['stid'];
            }
        }*/
        if($st_config && $_GET['st'] && !defined('IN_ADMINCP')){
            $stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status_stid($_GET['st']);
            $shprices = array();
            $shprice = array_filter(explode("\n",$stinfo['shprice']));
            foreach ($shprice as $index => $item) {
                list($vname, $vprice, $vdate) = explode('|', trim($item));
                $shprices[$vname] = array(
                    'name' => $vname,
                    'price' => $vprice,
                    'days' => $vdate,
                );
            }
        }

        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY displayorder asc " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            if($shprices && $shprices[$item['name']]){
                $item['name'] = $shprices[$item['name']]['name'];
                $item['price'] = $shprices[$item['name']]['price'];
                $item['days'] = $shprices[$item['name']]['days'];
            }
            if($shprices && !$shprices[$item['name']]){
            }else{
                if($key_field) {
                    $ret[$item[$key_field]] = $this->prepare($item);
                }else{
                    $ret[$index] = $this->prepare($item);
                }
            }
        }
        return $ret;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public function fetch_by_type($id)
    {
        $res = parent::fetch($id);

        //$res['price']
        global $old_data,$data,$shdata;
        if($old_data['hangye_id1'] || $old_data['hangye_id2']){
            $hyid1 = $old_data['hangye_id1'];
            $hyid2 = $old_data['hangye_id2'];
        }elseif ($data['hangye_id1'] || $data['hangye_id2']){
            $hyid1 = $data['hangye_id1'];
            $hyid2 = $data['hangye_id2'];
        }elseif ($shdata['hangye_id1'] || $shdata['hangye_id2']){
            $hyid1 = $data['hangye_id1'];
            $hyid2 = $data['hangye_id2'];
        }
        if($hyid1 || $hyid2){
            $isapp = (IN_MAGAPP||IN_QIANFAN||IN_APPBYME||IN_MOCUZ);
            foreach (explode("\n", trim($res['hy_price'])) as $_index => $item) {
                list($hyid, $p1, $p2) = explode('|', trim($item));
                if(($p1||$p2) && $hyid==$hyid1){
                    $res['price'] = $isapp&&$p2?$p2:$p1;
                }
                if(($p1||$p2) && $hyid==$hyid2){
                    $res['price'] = $isapp&&$p2?$p2:$p1;
                }
            }
        }
        global $_G;
        $st_config = $_G['cache']['plugin']['xigua_st'];
        if($st_config && $_GET['st']){
            $stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status_stid($_GET['st']);
            $shprices = array();
            $shprice = array_filter(explode("\n",$stinfo['shprice']));
            foreach ($shprice as $index => $item) {
                list($vname, $vprice, $vdate) = explode('|', trim($item));
                $shprices[$vname] = array(
                    'name' => $vname,
                    'price' => $vprice,
                    'days' => $vdate,
                );
            }
        }
        if($shprices && $shprices[$res['name']]){
            $res['name'] = $shprices[$res['name']]['name'];
            $res['price'] = $shprices[$res['name']]['price'];
            $res['days'] = $shprices[$res['name']]['days'];
        }
        $res = $this->prepare($res);
        return $res;
    }

    public function prepare($vipinfo)
    {
        global $_G;
        if($vipinfo['aprice']> 0 && (IN_MAGAPP || IN_APPBYME ||IN_QIANFAN )){
            if(intval($vipinfo['aprice']*100) == 3){
                $vipinfo['aprice'] = 0;
            }
            $vipinfo['price'] = $vipinfo['aprice'];
        }
        if(!defined('IN_ADMINCP') && $_G['uid'] && $_G['cache']['plugin']['xigua_hk']['shzhe']> 0 && $_G['cache']['plugin']['xigua_hk']['shzhe']<=10){
            if($vipinfo['price']>0 && C::t('#xigua_hk#xigua_hk_card')->fetch_online_card($_G['uid'])){
                $zhekou = $_G['cache']['plugin']['xigua_hk']['shzhe'];
                $vipinfo['price'] = $vipinfo['price']* $zhekou/10;
                if($vipinfo['price']<0.01){
                    $vipinfo['price'] = 0.01;
                }
            }
        }
        $vipinfo['access'] = explode(',',$vipinfo['access'] );
        $vipinfo['udays'] = $this->hs_days_format($vipinfo['days'], $vipinfo['price']);
        return $vipinfo;
    }

    public function hs_days_format($days, $price) {
        $price = str_replace('.00', '', $price);
        if($days >= 365) {
            $return= intval($days/365).lang('plugin/xigua_hs', 'nian').'/';
        } elseif($days >= 30) {
            $return= intval($days/30).lang('plugin/xigua_hs', 'yue1').'/';
        } elseif($days >= 1) {
            $return= intval($days).lang('plugin/xigua_hs', 'ri').'/';
        }else{
            $return= '';
        }
        if($days == '9999'){
            $return = lang('plugin/xigua_hs', 'yongjiu').'/';
        }
        $return .= ($price>0? $price.lang('plugin/xigua_hb', 'yuan') : lang('plugin/xigua_hs', 'mf' ));
        return $return;
    }
}