<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hs_addr extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hs_addr';
        $this->_pk = 'id';
        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }

    public function update_by_uid($uid, $data)
    {
        return DB::update($this->_table, $data, array(
            'uid' => $uid
        ));
    }

    public function fetch_dft($uid)
    {
        $wherearr = array('uid='.intval($uid));
        $wherearr[] = 'dft=1';
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        return DB::fetch_first('SELECT * FROM ' . DB::table($this->_table).' '.$wheresql);
    }
}