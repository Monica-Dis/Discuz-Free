<?php
/**
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hs_shanghu extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_hs_shanghu';
        $this->_pk = 'shid';

        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function fetch_my_shanghu($uid)
    {
        global $_G;
        $ttl = 7200;
        $key = 'xigua_hs_s'.$uid.'_'.$ttl;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $ttl) {
            $return = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('uid='.$uid.' AND display=1 AND endts>='.TIMESTAMP), 0, 100, 'shid DESC');
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }

    public function fetch_my_mp($uid)
    {
        global $_G;
        $ttl = 7200;
        $key = 'xigua_mp_s'.$uid.'_'.$ttl;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $ttl) {
            $return = C::t('#xigua_hp#xigua_hp_user')->fetch_all_by_where(array('uid='.$uid.' AND status=1 '), 0, 100, 'mpid DESC');
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        if($_GET['form']['stids']){
            global $_G;
            $data['stids'] = $_GET['form']['stids'];
            $dtnams = explode(',', $data['stids']);
            if($dtnams){
                $stida = DB::fetch_all("select stid from %t where name in (%n)", array('xigua_st', $dtnams), 'stid');
                if(in_array($_G['cache']['plugin']['xigua_st']['zongname'],$dtnams)){
                    $stida[0] = 1;
                }
                $data['stida'] = implode(',', array_keys($stida));
            }
        }

        if($_GET['form']['cardno']){
            $numdata = DB::fetch_first('SELECT * FROM %t WHERE cardnum=%s', array('xigua_hk_num', $_GET['form']['cardno']));
            if($numdata['viptype']){
                $data['viptype'] = $numdata['viptype'];
            }
        }

        if($_GET['ac'] == 'enter' && $data['province'] && $_G['cache']['plugin']['xigua_st']['autotofen']){
            $_st = C::t('#xigua_st#xigua_st')->fetch_by_dist($data['province'], $data['city'], $data['district']);
            if($_st['stid']){
                $data['stid'] = $_st['stid'];
            }
        }
        if($_GET['ac'] == 'enter' && $_GET['form']){
            global $config, $vipinfo;
            $showv = is_file(DISCUZ_ROOT.'source/plugin/xigua_hs/hs_api.inc.php') && (($config['qn_ak'] && $config['qn_sk'] && $config['qn_bk'] && $config['qn_url']) || ($config['ACCESS_ID'] && $config['ACCESS_KEY'] && $config['ENDPOINT'] && $config['BUCKET']));
            if(!($showv && in_array('video', $vipinfo['access']) && $vipinfo['maxsize'])){
                $_GET['form']['video'] = $_GET['form']['video_cover'] = '';
            }
            $data['video'] = $_GET['form']['video'];
            $data['video_cover'] = $_GET['form']['video_cover'];
        }
        $shid = DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
        if($_GET['hrvrifyid']){
            C::t('#xigua_hr#xigua_hr_verify')->update($_GET['hrvrifyid'], array(
                'shid' =>$shid
            ));
        }
        return $shid;
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false) {
        if($_GET['form']['stids']){
            global $_G;
            $data['stids'] = $_GET['form']['stids'];
            $dtnams = explode(',', $data['stids']);
            if($dtnams){
                $stida = DB::fetch_all("select stid from %t where name in (%n)", array('xigua_st', $dtnams), 'stid');
                if(in_array($_G['cache']['plugin']['xigua_st']['zongname'],$dtnams)){
                    $stida[0] = 1;
                }
                $data['stida'] = implode(',', array_keys($stida));
            }
        }

        if($_GET['ac'] == 'enter' && $data['province'] && $_G['cache']['plugin']['xigua_st']['autotofen']){
            $_st = C::t('#xigua_st#xigua_st')->fetch_by_dist($data['province'], $data['city'], $data['district']);
            if($_st['stid']){
                $data['stid'] = $_st['stid'];
            }
        }
        if($data['endts']){
            $data['lastnoti'] = 0;
        }
        if($_GET['ac'] == 'enter' && $_GET['form']){
            $data['video'] = $_GET['form']['video'];
            $data['video_cover'] = $_GET['form']['video_cover'];
        }
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function fetch_by_name($name)
    {
        $result = DB::fetch_first('SELECT * FROM ' . DB::table($this->_table) .' WHERE `name`=%s AND display=1', array($name));
        return $result;
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY {$this->_pk} ASC " . DB::limit($start_limit, $lpp));

        return $result;
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'views DESC', $fields= '*')
    {
        global $_G;
        $hs_config = $_G['cache']['plugin']['xigua_hs'];
        if(!$_GET['keyword'] && !$_GET['map'] && is_array($wherearr) && !defined('IN_ADMINCP') && !in_array($_GET['ac'], array('seckilledit', 'my_seckill', 'my_evt', 'add','shcenter', 'join'))){
            $pop = 0;
            $_stid = intval($_GET['st']);
            $wherearr[] = " (stid=$_stid OR FIND_IN_SET($_stid ,stida)) ";
            global $_G,$stadmin;
            if((!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']) || (/*$hs_config['showfzsh'] && */$_GET['is_my'] && !$stadmin ) ){
                array_pop($wherearr);
                $pop=1;
            }
            if($_GET['st'] && $_G['cache']['plugin']['xigua_st']['showzongsh']){
                !$pop && array_pop($wherearr);
                $wherearr[] = " (stid=$_stid OR FIND_IN_SET($_stid,stida) OR stid=0) ";
            }
        }
        if($_GET['map'] && $_GET['left_lat'] && $_GET['left_lng'] && $_GET['right_lat'] && $_GET['right_lng']){
            $left_top_lat = $_GET['left_lat'];
            $left_top_lng = $_GET['left_lng'];
            $right_bottom_lat = $_GET['right_lat'];
            $right_bottom_lng = $_GET['right_lng'];
            $wherearr[] = " (lat>=$left_top_lat AND lat<=$right_bottom_lat AND lng>=$left_top_lng AND lng<=$right_bottom_lng) ";
        }
        if($_GET['onlydig']){
            $wherearr[] = 'dig_endts>'.TIMESTAMP;
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));

        $shids = $hangyeids = array();

        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $shids[] = $item['shid'];
            $hangyeids[] = $item['hangye_id2'];
        }
        if($hs_config['countinlist'] && $shids && !defined('IN_ADMINCP')){
            $this->incr(implode(',', $shids), 'views');
        }
        if($_G['cache']['plugin']['xigua_hs']['pricetel']) {
            if ($hangyeids) {
                $hangye = C::t('#xigua_hs#xigua_hs_hangye')->fetch_light($hangyeids);
                foreach ($result as $index => $item) {
                    $hangye_id2 = $item['hangye_id2'];
                    $hshid = $item['shid'];
                    $vtelp = $hangye[$hangye_id2]['telprice'];
                    if($item['end'] && $_G['cache']['plugin']['xigua_hs']['gqbx']==3 && $_G['cache']['plugin']['xigua_hs']['guoqiprice']>0){
                        $vtelp = $_G['cache']['plugin']['xigua_hs']['guoqiprice'];
                    }
                    if ($vtelp > 0):
                        if ($_G['uid']):
                            $viewtels = C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], array($hshid), 'shid');
                        endif;
                        if (!$viewtels[$hshid]):
                            $result[$index]['teljs'] = "onclick=\"javascript:hs_paytel('$hshid','$vtelp','$hangye_id2');\"";
                            $result[$index]['telprice'] = $vtelp;
                        endif;
                    endif;
                }
            }
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        global $_G;

        $items = DB::fetch_all("SELECT * FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids) );
        foreach ($items as $index => $item) {
            $item = $this->prepare($item);
            $imglist = array_merge($item['album'], $item['append_img'], array($item['logo'], $item['qr']));
            foreach ($imglist as $img) {
                if (strpos($img, 'xigua_hb/cache') !== false) {
                    $img = str_replace($_G['siteurl'], DISCUZ_ROOT, $img);
                    @unlink($img);
                }
            }
        }

        $re1 = DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
        if($_G['cache']['plugin']['xigua_hm']){
            $re2 = DB::query("DELETE FROM %t WHERE shid IN (%n)", array('xigua_hm_seckill', $ids));
        }
        return $re1 && $re2;
    }


    public function checkmine($shid)
    {
        global $_G;
        $return = DB::result_first("SELECT {$this->_pk} FROM %t WHERE uid=%d AND {$this->_pk}=%d ", array($this->_table, $_G['uid'], $shid));
        return $return;
    }

    public function fetch_simple($id, $field = 'shid,name,logo,addr')
    {
        $data = DB::fetch_first("SELECT $field FROM %t WHERE shid=%d AND endts>".TIMESTAMP, array(
            $this->_table,
            $id
        ));
        return $data;
    }

    public function fetch_uid_by_shid($shid, $need_yuan = 1, $str = 1)
    {
        $uis = array();
        $uis[] = DB::result_first('SELECT uid FROM ' . DB::table($this->_table) .' WHERE `shid`=%d ', array($shid));
        if($need_yuan){
            $yuids = C::t('#xigua_hs#xigua_hs_yuan')->fetch_yuan_by_shid($shid);
            $uis = array_merge($uis, $yuids);
        }
        if($str){
            $uis= implode(',', $uis);
        }
        return $uis;
    }

    public function fetch_by_shid($id, $check = false)
    {
        global $_G;
        if($check){
            $data = DB::fetch_first('SELECT * FROM %t WHERE shid=%d AND display=1 AND endts>'.TIMESTAMP, array(
                $this->_table,
                $id
            ));
        }else{
            $data = parent::fetch($id);
        }
        if(!defined('IN_ADMINCP')){
            $this->incr($id, 'views');
        }
        if($data){
            $data = $this->prepare($data);
        }

        if($_G['cache']['plugin']['xigua_hs']['pricetel']) {
            if (!($_GET['id'] == 'xigua_hs' && $_GET['ac'] == 'view')) {
                $hangye = C::t('#xigua_hs#xigua_hs_hangye')->fetch_light(array($data['hangye_id2']));
                $vtelp = $hangye[$data['hangye_id2']]['telprice'];
                if($data['end'] && $_G['cache']['plugin']['xigua_hs']['gqbx']==3 && $_G['cache']['plugin']['xigua_hs']['guoqiprice']>0){
                    $vtelp = $_G['cache']['plugin']['xigua_hs']['guoqiprice'];
                }
                if ($vtelp > 0):
                    if ($_G['uid']):
                        $viewtels = C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], array($data['shid']), 'shid');
                    endif;
                    $hangye_id2 = $data['hangye_id2'];
                    if (!$viewtels[$data['shid']]):
                        $data['teljs'] = "onclick=\"javascript:hs_paytel('{$data['shid']}','$vtelp','$hangye_id2');\"";
                        $data['telprice'] = $vtelp;
                    endif;
                endif;
            }
        }

        global $access_list;
        if($_GET['ac']=='view' && $access_list){
            if($data['stid']>0 && !$_GET['st']){
                $_GET['st'] = $v['stid'];
            }
        }

        return $data;
    }

    public function incr($id, $field, $num = 1)
    {
        global $config;
        static $has = 0;
        if($field == 'views'){
            if($has){
                return null;
            }
            $has = 1;
            if($_GET['mini']=='11'){
                return null;
            }
            if($_GET['ac']=='shcenter'){
                return null;
            }
            if($config['cusview']>0 && $config['cusview']<1000){
                $num = $num * mt_rand(1, $config['cusview']);
            }
        }
        if(!$field){
            return null;
        }
        global $_G;
        if(defined('IN_ADMINCP')){
            return null;
        }
        if (($field == 'shares' || $field == 'views') && discuz_process::islocked('incrsh'.$id.$field.$_G['uid'], 1200)) {
            return null;
        }
        if(strpos($id, ',')!==false){
            $id = dintval(array_filter(explode(',', $id)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $id));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
        }
    }

    public function prepare($item)
    {
        if($item){
            global $_G,$SCRITPTNAME;
            $hs_config = $_G['cache']['plugin']['xigua_hs'];

            $item['album'] = $item['album'] ? unserialize($item['album']) : array();
            $item['end'] = ($item['endts'] && $item['endts']<TIMESTAMP);
            if(!$item['logo'] && $hs_config['dftshlogo'] && $_GET['ac']!='enter'){
                $item['logo'] = $hs_config['dftshlogo'];
            }
            /*$_G['cache']['plugin']['xigua_hb']['tihuan_old'] = '';
            $_G['cache']['plugin']['xigua_hb']['tihuan_new'] = '';
            if($_G['cache']['plugin']['xigua_hb']['tihuan_old']){
                $rep = explode(',', $_G['cache']['plugin']['xigua_hb']['tihuan_old']);
                $newpic = explode(',', $_G['cache']['plugin']['xigua_hb']['tihuan_new']);
                foreach ($item['album'] as $index => $vvv) {
                    $item['album'][$index] = str_replace($rep, $newpic, $vvv);
                }
                foreach ($item['append_img'] as $index => $vvv) {
                    $item['append_img'][$index] = str_replace($rep, $newpic, $vvv);
                }
                $item['logo'] = str_replace($rep, $newpic, $item['logo']);
            }*/
            $item['links'] = $item['links'] ? unserialize($item['links']) : array();
            $item['show'] = array_slice(array_reverse($item['album']), 0, 5);
            $item['append_img'] = $item['append_img'] ? unserialize($item['append_img']) : array();
            $item['append_text'] = $item['append_text'] ? unserialize($item['append_text']) : array();

            $item['tags']    = array_filter(explode(" ", trim($item['tag'])));
            $item['upts_u']  = dgmdate($item['upts'], 'u');
            $item['crts_u']  = dgmdate($item['crts'], 'u');
            $item['endts_u'] = dgmdate($item['endts'], 'u');
            $item['hangyes'] = array_filter(explode(" ", trim($item['hangye'])));
            $item['dig']     = $item['dig_endts']>TIMESTAMP ? 1 : 0;
            if($item['dig_endts'] && !$item['dig']){
                DB::query("update %t set dig_endts=0,dig_startts=0 WHERE {$this->_pk}=%d", array($this->_table,  $item['shid']));
            }
            if($item['endts'] && !$item['lastnoti'] && ($item['endts']-TIMESTAMP <= $hs_config['notits']) ){
                $ti = TIMESTAMP;
                $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_hs&ac=shcenter&mobile=2&shid={$item['shid']}";
                $vvr= array(
                    'shname' => $item['name'],
                    'endts_u' => $item['endts_u'],
                    'url' => $url
                );
                notification_add($item['uid'],'system', "<a href='{url}'>".$hs_config['notitpl']."</a>", $vvr,1);
                DB::query("update %t set lastnoti=$ti WHERE {$this->_pk}=%d", array($this->_table,  $item['shid']));
            }
        }
        return $item;
    }

    public function fetch_newest($num = 5)
    {
        if(!checkmobile()){
            $num = 7;
        }
        $orderby = ' shid DESC ';
        $wherearr = array('display=1 AND endts>'.TIMESTAMP);
        if(is_array($wherearr) && !defined('IN_ADMINCP')){
            $pop = 0;
            $_stid = intval($_GET['st']);
            $wherearr[] = " (stid=$_stid OR FIND_IN_SET($_stid ,stida)) ";
            global $_G;
            if(!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']){
                array_pop($wherearr);
                $pop=1;
            }
            if($_GET['st'] && $_G['cache']['plugin']['xigua_st']['showzongsh']){
                !$pop && array_pop($wherearr);
                $wherearr[] = " (stid=$_stid OR FIND_IN_SET($_stid,stida) OR stid=0) ";
            }
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT shid,uid,crts,`name`,logo FROM ' . DB::table($this->_table) . " $wheresql  ORDER BY $orderby LIMIT $num");
        foreach ($result as $index => $item) {
            $result[$index]['crts_u'] = dgmdate($item['crts'], 'm-d');
        }
        return $result;
    }

    public function fetch_sh_by_hbcat($cat_id)
    {
        global $_G;
        $hangyes = C::t('#xigua_hs#xigua_hs_hangye')->fetch_by_hbcat($cat_id);
        if(!$hangyes){
            if($cat = C::t('#xigua_hb#xigua_hb_cat')->get_pid_by_childs(array($cat_id))){
                $hangyes = C::t('#xigua_hs#xigua_hs_hangye')->fetch_by_hbcat($cat['pid']);
            }
        }
        $hids = implode(',', array_keys($hangyes));
        if(!$hids){
            return array();
        }
        $where = array('uid='.$_G['uid'].' and display=1 and endts>='.TIMESTAMP);
        if($hids){
            $where[] = " (hangye_id1 IN ($hids) OR hangye_id2 IN ($hids)) ";
        }
        $list = $this->fetch_all_by_where($where, 0, 100, 'upts DESC', 'shid,name');
        return $list;
    }

    public function fetch_count_self($uid)
    {
        $result = DB::result_first('SELECT shid FROM %t WHERE uid=%d ', array($this->_table, $uid));
//        $result = DB::result_first('SELECT shid FROM %t WHERE uid=%d and display=1 and endts>='.TIMESTAMP, array($this->_table, $uid));
        return intval($result);
    }

    public function fetch_rank($views = 0)
    {
        $result = DB::result_first('SELECT  count(*) as c FROM %t WHERE views>=%d ORDER BY views DESC', array($this->_table, $views));
        return $result;
    }


    public function count()
    {
        global $_G,$config,$hs_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }
        }

        $key = 'xigua_hs_shanghu_count'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT COUNT(*) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $hs_config['cussh'] + $return;
    }

    public function total_views()
    {
        global $_G,$config,$hs_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }
        }

        $key = 'xigua_hs_shanghu_total_views'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $hs_config['cusview'] + $return;
    }

    public function total_shares()
    {
        global $_G,$config,$hs_config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st OR FIND_IN_SET($st ,stida)) ";
                }
            }
        }

        $key = 'xigua_hs_shanghu_total_shares'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(shares) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $hs_config['cusshare'] + $return;
    }

    public function fetch_only($id, $field = '*', $nowhere = 0)
    {
        if(!$id){
            return array (
                'uid' => '0',
                'display' => '0',
                'endts' => '0',
                'dig_endts' => '0',
                'dig_startts' => '0',
                'upts' => '0',
                'crts' => '0',
                'name' => '',
                'hangye' => '',
                'hangye_id1' => '0',
                'hangye_id2' => '0',
                'tel' => '',
                'opentime' => '',
                'jieshao' => '',
                'logo' => '',
                'qr' => '',
                'album' => '',
                'viptype' => '',
                'lat' => '',
                'lng' => '',
                'province' => '',
                'city' => '',
                'district' => '',
                'street' => '',
                'street_number' => '',
                'addr' => '',
                'tags' => '',
                'views' => '0',
                'shares' => '0',
                'comments' => '0',
                'pubs' => '0',
                'follow' => '0',
                'tag' => '',
                'shipin' => '',
                'quanjing' => '',
                'xuanchuan' => '',
                'color' => '',
                'color_title' => '',
                'shangquan' => '',
                'append_img' => '',
                'append_text' => '',
            );
        }
        if($nowhere){
            $data = DB::fetch_first('SELECT '.$field.' FROM '.DB::table($this->_table). " LIMIT 1 ");
        }else{
            $data = DB::fetch_first('SELECT '.$field.' FROM '.DB::table($this->_table).' WHERE '.DB::field($this->_pk, $id));
        }
//        unset($data['hong_num']);
//        unset($data['hong_money']);
//        unset($data['hong_sendnum']);
        return $data;
    }

    function get_distance($latitude1, $longitude1, $latitude2, $longitude2, $unit=1, $decimal=2){

        $EARTH_RADIUS = 6370.996;
        $PI = 3.1415926;

        $radLat1 = $latitude1 * $PI / 180.0;
        $radLat2 = $latitude2 * $PI / 180.0;

        $radLng1 = $longitude1 * $PI / 180.0;
        $radLng2 = $longitude2 * $PI /180.0;

        $a = $radLat1 - $radLat2;
        $b = $radLng1 - $radLng2;

        $distance = 2 * asin(sqrt(pow(sin($a/2),2) + cos($radLat1) * cos($radLat2) * pow(sin($b/2),2)));
        $distance = $distance * $EARTH_RADIUS * 1000;

        if($unit==2){
            $distance = $distance / 1000;
        }

        return round($distance, $decimal);

    }
    public function manage($shid)
    {
        global $SCRITPTNAME,$_G;

        if($_GET['tongguo']==1){
            $shinfo = parent::fetch($shid);
            $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch_by_type($shinfo['viptype']);
            $data = array( 'display' => 1, );
            $data['endts'] = TIMESTAMP + ($vipinfo['days'] * 86400);

            $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_hs&ac=view&shid=$shid";
            notification_add($shinfo['uid'],'system', lang_hs('tongguo_noti', 0),array('id' => $shid,'url' => $url),1);
        }else{
            $data = array('display' => 0);
        }
        parent::update($shid, $data);
        return true;
    }


    public function fetch_discount()
    {
        global $_G;
        $hrs = DB::fetch_first('select uid,viptype,shdiscount from %t WHERE uid=%d and display=1 and endts>=\'' . TIMESTAMP . '\'', array('xigua_hs_shanghu', $_G['uid']), 'viptype');
        $discount = $hrs['shdiscount'];
        if(!$discount && $hrs){
            $discount = DB::result_first('select discount from %t where id=%d ORDER BY discount DESC', array('xigua_hs_vip', $hrs['viptype']));
        }
        return intval(abs($discount));
    }

    public function get_order($viewtype)
    {
        global $hs_config;
        $field = '*';
        switch ($viewtype){
            case "new":
                switch ($hs_config['digorder']){
                    case '3':
                        $order_by = ' dig_startts DESC, dig_endts DESC, shid DESC ';
                        break;
                    case '2':
                        $order_by = 'dig_endts DESC, shid DESC';
                        break;
                    case '4':
                        $order_by = '(dig_endts-now()) DESC, shid DESC';
                        break;
                    default:
                        $order_by = ' (dig_endts-dig_startts) DESC, shid DESC ';
                        break;
                }
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                switch ($hs_config['digorder']){
                    case '3':
                        $order_by = 'distance ASC, dig_startts DESC, dig_endts DESC';
                        break;
                    case '2':
                        $order_by = 'distance ASC, dig_endts DESC';
                        break;
                    default:
                        $order_by = 'distance ASC, (dig_endts-dig_startts) DESC';
                        break;
                }
                break;
            case 'guanzhu':
                $order_by = 'follow DESC';
                break;
            case 'fenxiang':
                $order_by = 'shares DESC';
                break;
            default:
                switch ($hs_config['digorder']){
                    case '3':
                        $order_by = ' dig_startts DESC, dig_endts DESC, views DESC ';
                        break;
                    case '2':
                        $order_by = 'dig_endts DESC, views DESC';
                        break;
                    case '4':
                        $order_by = '(dig_endts-now()) DESC, views DESC';
                        break;
                    default:
                        $order_by = ' (dig_endts-dig_startts) DESC, views DESC ';
                        break;
                }
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }
}