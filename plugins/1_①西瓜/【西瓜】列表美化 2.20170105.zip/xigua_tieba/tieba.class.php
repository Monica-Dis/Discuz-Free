<?php
/**
 * [DisM!] (C)2001-2099 DisM Inc.
 * User: yzg
 * Date: 2016/1/21
 * Time: 10:17
 */
//forumdisplay_thread_subject

class plugin_xigua_tieba{

}

class plugin_xigua_tieba_forum extends plugin_xigua_tieba
{
    public $font_num;
    public $pic_num;
    public $pic_height;
    public $pic_maxwidth;
    public $highlight;
    public $dir = './source/plugin/xigua_tieba/cache/';
    public $expire = 3600;
    public $openfids = array();

    public function forumdisplay_thread_subject_output(){
        global $_G,$extra;

        if(!$_G['cache']['plugin']){
            loadcache('plugin');
        }
        $config = $_G['cache']['plugin']['xigua_tieba'];

        $this->font_num     = $config['font_num'];
        $this->pic_num      = $config['pic_num'];
        $this->expire       = $config['expire'];
        $this->pic_height   = $config['pic_height'];
        $this->pic_maxwidth = $config['pic_maxwidth'];
        $this->highlight    = $config['highlight'];
        $this->openfids    = unserialize($config['openfids']);
        if(!in_array($_G['fid'], $this->openfids)){
            return '';
        }

        $this->dir = DISCUZ_ROOT. $this->dir;


        $htmlary = array();

        $forum_threadlist = array();
        foreach ($_G['forum_threadlist'] as $index => $item) {
            $tids[] = $item['tid'];
            $forum_threadlist[$item['tid']] = $item;
        }

        $ret = $this->forumdisplay_threadBottom($tids);
        $has_style = 0;
        foreach ($ret as $index => $item) {
            $itemhtml = $piclist = '';
            if(!$has_style){
                $itemhtml .= "<style>
a,a:hover,a:visited{text-decoration:none}
.itmx{display:block}
.cl:after{ content:\".\"; display:block; height:0; clear:both; visibility:hidden}
.cl{zoom:1}
.itmmsg{line-height:28px}
.itmp2 li{float:left;height:{$this->pic_height}px;margin:5px 10px 5px 0;position:relative}
.itmp2 li img{height:100%;max-width:{$this->pic_maxwidth}px}
</style>";
                $has_style = 1;
            }

            if($item['piclist']){
                foreach ($item['piclist'] as $pic) {
                    $piclist .= "<li><img src='$pic' ></li>";
                }
            }
            $thread = $forum_threadlist[$index];

            if(!empty($_G['setting']['rewriterule']['forum_viewthread']) && in_array('forum_viewthread', $_G['setting']['rewritestatus'])) {
                $returnurl = rewriteoutput('forum_viewthread', 1, '', $thread['tid'], 1, '', $extra);
                $attr =  "href=\"". $returnurl ."\"";
            } else {
                $returnurl = "forum.php?mod=viewthread&tid=$thread[tid]";
                $attr =  "href=\"". $returnurl;
                if($_GET['archiveid']){
                    $attr .= "&archiveid={$_GET['archiveid']}";
                }else{
                    $attr .= "&";
                }
                $attr .= "extra=$extra\"";
            }

            $attr .= $highlight = $this->highlight ? " {$thread['highlight']} " : '';
            if($thread['isgroup'] == 1 || $thread['forumstick']) {
                $attr .= " target=\"_blank\"";
            }else{
                $attr .= " onclick=\"atarget(this)\"";
            }

            if($thread['displayorder']>0){
                if(!$config['digpic']){
                    $piclist = '';
                }
                if(!$config['digfont']){
                    $item['message'] = '';
                }
            }

            $itemhtml .= ($item['message'] ||$piclist) ? <<<HTML
<a $attr class="itmx cl">
<div class="itmmsg">$item[message]</div>
<ul class="cl itmp2">$piclist</ul>
</a>
HTML
: '';
            $htmlary[] = $itemhtml;
        }
        return $htmlary;
    }


    function forumdisplay_threadBottom($tids) {
        require_once libfile('function/discuzcode');
        require_once libfile('function/cache');

        $return = $this->get_message_from_cache($tids);
        return $return;
    }


    public function get_message_from_cache($tids)
    {
        foreach ($tids as $tid) {
            $img_piclist = array();
            $cache_key = "tid_$tid";
            if(! $data[ $tid ] = $this->readfromcache($cache_key)){

                if($this->font_num> 0) {
                    $message = DB::result_first('SELECT message FROM %t WHERE tid=%d AND first=1  AND invisible=0 LIMIT 1', array(table_forum_post::get_tablename('tid:' . $tid), $tid)
                    );

                    $sppos = strpos($message, chr(0).chr(0).chr(0));
                    if($sppos !== false) {
                        $message = substr($message, 0, $sppos);
                    }

                    $message = preg_replace(array(lang('forum/misc', 'post_edit_regexp'), lang('forum/misc', 'post_edithtml_regexp'), lang('forum/misc', 'post_editnobbcode_regexp')), '', $message);

                    if(strpos($message, '[/hide]') !== FALSE){
                        $message = preg_replace('/\[hide\].*?\[\/hide\]/i', '', $message);
                    }

                    if (
                        strpos($message, '[/attach]') !== FALSE ||
                        strpos($message, '[/attachimg]') !== FALSE ||
                        strpos($message, '[/url]') !== FALSE ||
                        strpos($message, '[/img]') !== FALSE ||
                        strpos($message, '[/media]') !== FALSE ||
                        strpos($message, '[/audio]') !== FALSE ||
                        strpos($message, '[/flash]') !== FALSE
                    ) {

                        if($this->pic_num> 0 && strpos($message, '[/img]') !== FALSE )
                        {
                            $pattern = "/\[img.*?\](.*?)\[\/img\]/i";
                            preg_match_all($pattern, $message, $matchsimg);
                            $img_piclist = $matchsimg[1];
                        }

                        $pattern = "/(\[attach(img)?\]|\[(img|media|audio|flash)(.*)\]).*?(\[\/attach(img)?\]|\[\/(img|media|audio|flash)\])/i";
                        $message = preg_replace($pattern, '', $message);
                    }
                    $message = str_replace(array('&nbsp;', '&amp;', '&quot;', '&lt;', '&gt;', '[', ']'), array('', '', '', '', '', '<', '>'), $message);
                    $message = strip_tags($message);

                    if ($message) {
                        $message = cutstr($message, $this->font_num);
                        $message = $this->mobile_parsesmiles($message);
                        $message = preg_replace('/\{?\:\w+/', '', $message);
                        $message = str_replace(array("\n","\r","\t"), '', $message);
                    }

                    $data[ $tid ]['message'] = trim($message);
                }
                if($this->pic_num> 0) {
                    $piclist = array();

                    $query = DB::query("SELECT a.aid,a.tableid from " . DB::table('forum_attachment') . " as a  where a.tid='$tid' ORDER BY aid ASC LIMIT $this->pic_num");
                    while ($arow = DB::fetch($query)) {
                        if($arow['tableid'] == 127){
                            continue;
                        }
                        $table = DB::table('forum_attachment_' . intval($arow['tableid']));
                        $aid = $arow['aid'];
                        $row = DB::fetch_first("SELECT remote,thumb,attachment FROM $table WHERE aid='$aid' AND isimage IN(-1, 1) LIMIT 1");
                        if ($row['attachment']) {
                            $piclist[] = $this->get_picurl($row['thumb'] ? getimgthumbname($row['attachment']) : $row['attachment'], $row['remote']);
                        }
                    }
                    if((empty($piclist)||count($piclist) <$this->pic_num) && $img_piclist){
                        $merger = array_slice($img_piclist, 0, $this->pic_num-count($piclist));
                        $piclist = array_merge($merger, $piclist);
                    }
                    foreach ($piclist as $index => $item) {
                        if(strpos($item, 'face_') !== false){
                            unset($piclist[$index]);
                        }
                    }
                    $data[ $tid ]['piclist'] = $piclist;
                }

                $this->writetocache($cache_key, $data[ $tid ]);
            }
        }
        return $data;
    }




    function mobile_parsesmiles($message) {
        global $_G;
        static $enablesmiles;
        if($enablesmiles === null) {
            $url = !in_array(strtolower(substr(STATICURL, 0, 6)), array('http:/', 'https:', 'ftp://')) ? $_G['siteurl'] : '';
            $enablesmiles = false;
            if(!empty($_G['cache']['smilies']) && is_array($_G['cache']['smilies'])) {
                foreach($_G['cache']['smilies']['replacearray'] AS $key => $smiley) {
                    $enablesmiles[$key] = '<img width="18px" src="'.$url.STATICURL.'image/smiley/'.$_G['cache']['smileytypes'][$_G['cache']['smilies']['typearray'][$key]]['directory'].'/'.$smiley.'" />';
                }
            }
        }
        $enablesmiles && $message = preg_replace($_G['cache']['smilies']['searcharray'], $enablesmiles, $message, $_G['setting']['maxsmilies']);
        return $message;
    }


    public function get_picurl($pic, $remote = 0){
        global $_G;
        if(self::is_picurl($pic)){
            return $pic;
        }

        if($remote){
            $attach__ = $_G['setting']['ftp']['attachurl'] . 'forum/' . $pic;
        }else{
            $pic = $_G['setting']['attachurl'].'forum/'.$pic;
            if(self::is_picurl($pic)){
                return $pic;
            }
            $attach__ = $_G['siteurl'].$pic;
        }
        return $attach__;
    }

    public static function is_picurl($pic){
        return in_array(strtolower(substr($pic, 0, 6)), array('http:/', 'https:', 'ftp://'));
    }



    function writetocache($script, $array = array(), $prefix = 'm')
    {
        $datas = array(
            'expireat' => time()+$this->expire,
            'data'     => $array
        );
        $cachedata = " return ".arrayeval($datas).";";

        if(memory('check')){
            return memory('set', $prefix.$script, serialize($datas), $this->expire);
        }

        global $_G;

        $dir = $this->dir;
        if(!is_dir($dir)) {
            dmkdir($dir, 0777);
        }
        if($fp = @fopen("$dir$prefix$script.php", 'wb')) {
            fwrite($fp, "<?php\n//Discuz! cache file, DO NOT modify me!\n//Identify: ".md5($prefix.$script.'.php'.$cachedata.$_G['config']['security']['authkey'])."\n\n$cachedata?>");
            fclose($fp);
        } else {
            exit('Can not write to cache files, please check directory '.$dir);
        }
    }

    function readfromcache($script, $prefix = 'm')
    {
        if(memory('check')){
            $data = memory('get', $prefix.$script);
            $ret = unserialize($data);
            return $ret['data'];
        }
        $dir = $this->dir;
        if(!is_dir($dir)) {
            dmkdir($dir, 0777);
        }

        $ret = array();

        if(is_file("$dir$prefix$script.php")){
            $rets =  include "$dir$prefix$script.php";
            $ret = $rets['data'];
            if(time()> $rets['expireat'] )
            {
                $ret = array();
            }
        }
        return $ret;
    }

}
