<?php

/**
 *      [Discuz!] (C)2001-2099 Comsenz Inc.
 *      This is NOT a freeware, use is subject to license terms
 *
 *      $Id: install.php 34718 2014-07-14 08:56:39Z nemohou $
 */

if(!defined('IN_DISCUZ')) {
	exit('Access Denied');
}


@unlink(DISCUZ_ROOT . './source/plugin/xigua_tieba/discuz_plugin_xigua_tieba.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_tieba/discuz_plugin_xigua_tieba_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_tieba/discuz_plugin_xigua_tieba_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_tieba/discuz_plugin_xigua_tieba_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_tieba/discuz_plugin_xigua_tieba_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . 'source/plugin/xigua_tieba/install.php');