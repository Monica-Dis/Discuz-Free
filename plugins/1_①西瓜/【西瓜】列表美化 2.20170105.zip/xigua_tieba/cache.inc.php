<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2020-02-11,11:00:52
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

function xgb_delete_all($directory, $empty = false, $strict = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }

    if(!file_exists($directory) || !is_dir($directory)) {
        return true;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    $ret = xgb_delete_all($path, $empty, $strict);
                    if($strict && !$ret){
                        return false;
                    }
                } else {
                    if(!@unlink($path)){
                        if($strict){
                            return false;
                        }
                    }
                }
            }
        }

        @closedir($directoryHandle);

        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }

        return true;
    }
}

$directory = DISCUZ_ROOT .'./source/plugin/xigua_tieba/cache/';
if(submitcheck('permsubmit'))
{
    if(xgb_delete_all($directory, true, true)){
        cpmsg(lang('plugin/xigua_tieba', 'succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_tieba&pmod=cache", 'succeed');
    }else{
        cpmsg(sprintf(lang('plugin/xigua_tieba', 'failed'), DISCUZ_ROOT.'data/sysdata/xigua_beauty_cache'), '', 'error');
    }
}

$cache_count = 0;

@$directoryHandle = opendir($directory);

while ($contents = @readdir($directoryHandle)) {
    if($contents != '.' && $contents != '..') {
        $cache_count ++;
    }
}
@closedir($directoryHandle);

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_tieba&pmod=cache");
showtableheader(lang('plugin/xigua_tieba', 'cache_desc'));

echo '<tr><td>'.lang('plugin/xigua_tieba', 'cache_items').$cache_count.'</td></tr>';
showsubmit('permsubmit', 'submit');
showtablefooter();
showformfooter();/*Dism_taobao-com*/