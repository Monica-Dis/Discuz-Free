<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{if $_GET['is_my'] || $_GET['is_admin']}--><!--{template xigua_hb:mypub_item}--><!--{else}--><!--{if $list}--><div class="flow_bbs_over es_li"><!--{loop $list $k $v}--><!--{eval
$subtit = '';
foreach($v[vars] as $___k => $___v):
  if($___v[autoin]):
    $subtit = ' '.$___v[html];
    break;
  endif;
endforeach;
$v[vars] = array_values($v[vars]);
}--><div class="flow-bbs-card flow-card<!--{if $v[wancheng]}--> op6<!--{/if}-->">
<div class="img-box view_jump" data-id="$v[id]">
    <img style="height:50vw;" src="{echo $v[video_cover] ? $v[video_cover] : $v[img_preview][0]}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'">
    <!--{if $v['video_cover'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}-->
    <img class="video_c_img" src="source/plugin/xigua_hb/static/img/vp.png" >
    <!--{/if}-->
    <!--{if $cats[$v[catid]][name]}-->
    <span>{$cats[$v[catid]][name]}</span>
    <!--{/if}-->
    <!--{if $showzhang && $v[img_count]>1}-->
    <em class="emnum">$v[img_count] {lang xigua_hb:zhang}</em>
    <!--{/if}-->
</div>
<main class="content-box view_jump <!--{if $v[wancheng]}-->wxexpired1<!--{/if}-->" data-id="$v[id]">
    <div class="title" ><!--{if $v[dig_on]}--><div class="mod-lv is-star" style="margin-left:0">{lang xigua_hb:zhiding}</div><!--{/if}--><!--{if $v[hb_num]}--><div class="mod-lv is-hot" style="margin-left:0">{lang xigua_hb:hb}</div><!--{/if}-->$subtit {echo cutstr(str_replace(array("\n\n","\r\r", "\n\r\n\r"), '', trim(strip_tags($v[description]))), 80);}</div>
    <!--{if $v[vars][1][value]}-->
    <div class="es_price <!--{if is_numeric($v[vars][1][value])}-->fisrlmini<!--{/if}-->"><em><!--{if is_numeric($v[vars][1][value])}-->&yen; <!--{/if}--><!--{if is_array($v[vars][1][value])}-->$v[vars][1][value][0]<!--{else}-->$v[vars][1][value]<!--{/if}--></em></div>
    <!--{elseif $v[vars][0][value]}-->
    <div class="es_price <!--{if is_numeric($v[vars][0][value])}-->fisrlmini<!--{/if}-->"><em><!--{if is_numeric($v[vars][0][value])}-->&yen; <!--{/if}--><!--{if is_array($v[vars][1][value])}-->$v[vars][1][value][0]<!--{else}-->$v[vars][1][value]<!--{/if}--></em></div>
    <!--{/if}-->
    <div class="other-box">
        <a href="$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]" class="author">
            <i class="avatar" style="background: url({avatar($v[uid], 'middle', true)}) center center / 100% no-repeat;"></i>
            <span class="name">{$v[realname]}</span> </a>
        <div class="nums">{echo hb_trans2($v[views]);}</div>
    </div>
<!--{if $v[tags]}-->
    <!--{eval $v[tags] = array_slice($v[tags], 0, 3);}-->
<ul class="cl es_tag"><!--{loop $v[tags] $___k $tag}--><!--{if $tag}--><li class="es_tag_li"><i>$tag</i></li><!--{/if}--><!--{/loop}--></ul>
<!--{/if}-->
</main>
</div>
<!--{/loop}--></div><!--{/if}--><!--{/if}-->