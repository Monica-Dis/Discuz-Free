<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{eval
$c20 = hb_hex2rgb($config['maincolor'], .2);
$c80 = hb_hex2rgb($config['maincolor'], .8);
}--><style>.es_li.flow_bbs_over{background-color:#f8f8f8}
.es_li.flow_bbs_over .flow-bbs-card .content-box .other-box .author{display:inline-flex;width:100%}
.es_li.flow_bbs_over .flow-bbs-card .content-box .other-box .author .avatar{display:inline-block;width:.9rem;height:.9rem;line-height:.9rem;margin-right:.1rem;border-radius:50%;overflow:hidden;background:no-repeat 50%;background-size:100%;font-size: .6rem;vertical-align: middle;}
.es_li.flow_bbs_over .flow-bbs-card .content-box .other-box .author .name{display:inline-block;;font-size:.6rem;line-height:.9rem;color:rgba(0,0,0,.4);max-width:3rem;text-overflow:ellipsis;white-space:nowrap}
.es_li.flow_bbs_over .flow-bbs-card .img-box img.video_c_img{position:absolute;width:2rem;height:2rem}
.es_li.flow_bbs_over .flow-bbs-card .img-box{border-radius:0}
.es_li.flow_bbs_over .flow-bbs-card .img-box img{width: 100%;}
.es_li.flow_bbs_over .flow-bbs-card .img-box .emnum{position: absolute;color: #fff;display: block;padding: 0 10px;font-size: .6rem;right: 0;bottom: .2rem;}
.es_li.flow_bbs_over .flow-bbs-card .img-box span{top:.8rem;border-radius:0 2.4rem 2.4rem 0;padding-right:.5rem;height:1.1rem;line-height:1.1rem;font-size:.6rem;background-image:none}
.es_li.flow_bbs_over .flow-bbs-card .content-box .title{max-height:2rem;font-size:.6rem;line-height:1rem;font-weight:700;color:#000;overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.es_li.flow_bbs_over .flow-card{border-radius:.2rem;overflow:hidden;margin-top:0;margin-bottom:0;padding-bottom:.75rem}
.es_li.flow_bbs_over .flow-bbs-card .content-box{padding:.5rem;width:auto;background-color: #fff;border-radius: 0 0 .2rem .2rem;margin-top: 0;}
.es_li.flow_bbs_over .es_price em,.es_price em{font-family:PingFang SC,sans-serif;font-weight:700;font-size:.8rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.es_li.flow_bbs_over .es_price.fisrlmini em:first-letter,.es_price.fisrlmini em:first-letter{font-weight:400;font-family:arial;font-size:.6rem}
.es_li.flow_bbs_over .es_price,.es_price{display:-webkit-box;display:-webkit-flex;display:flex;color:#f55;-webkit-box-align:end;-webkit-align-items:flex-end;align-items:flex-end}
.es_li.flow_bbs_over .es_tag, .es_tag{margin-top:.3rem}.es_li.flow_bbs_over .es_tag:empty, .es_tag:empty{display:none}
.es_li.flow_bbs_over .es_tag_li:last-child, .es_tag_li:last-child{margin-right:0}
.es_li.flow_bbs_over .es_tag_li, .es_tag_li{display:inline-block;margin-right:.2rem;font-size:.6rem;letter-spacing:0;text-align:justify;line-height:.6rem;padding:.1rem .2rem;border-radius:.2rem;box-sizing:border-box}.v_es_price i{font-size:.7rem}.v_es_price{line-height: 1rem;vertical-align: middle;margin: .5rem 0;}
.v_es_price .es_price em{font-size: 1rem;}.v_es_price .es_price del{display: inline-block;margin-left:.8rem;color: #999;}
.es_li.flow_bbs_over .es_tag_li, .es_tag_li{color:$config['maincolor'];border:1px solid $c20}
.es_li.flow_bbs_over .flow-bbs-card .img-box span{background-color:$c80}</style>