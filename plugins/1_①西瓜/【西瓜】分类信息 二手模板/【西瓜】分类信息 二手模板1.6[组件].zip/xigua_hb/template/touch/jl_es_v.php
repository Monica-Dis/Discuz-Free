<?PHP exit('DisM!Ӧ������ https://dism.taobao.com');?>
<!--{template xigua_hb:common_header}--><!--{if $totalpubs<1}--><!--{eval $totalpubs=1;}--><!--{/if}-->
<!--{eval
if($_GET[ecid]||$_GET['edid']||$_GET[fx]):
  $config[showguide] = 1;
endif;
if($v[realname]=='-'||!$v[realname]):
$v[realname] = $v[user][username];
endif;
if($_G['uid']==$v[uid] || IS_ADMINID):
    $catinfo['telpri']=0;
endif;
$bttxt = lang_hb('duanxin', 0);
$calltel = $v[mobile] ? "tel:$v[mobile]" : '';
$callsms = $v[mobile] ? "sms:$v[mobile]" : '';
if($v[weixin]):
  $calltel = "javascript:lxfs_tip(this, '$v[mobile]', '$v[weixin]');";
endif;
if($_G['uid']):
  $viewtels = C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], array($pubid));
endif;
if($v[wancheng]):
  $callsms = $calltel = "javascript:$.toast('{lang xigua_hb:xinxiwc}','error');";
else:
  $vcatid = $v[catid];
  $vtelp = $catinfo['telpri'];
  if($vtelp>0):
    include DISCUZ_ROOT. 'source/plugin/xigua_hb/include/c_addon.php';
    if(!$viewtels[$v[id]] && !$ishk):
      $callsms = $calltel = "javascript:hb_paytel('$v[id]','$vtelp','$vcatid');";
    endif;
  endif;
endif;
if($catinfo['hidereal']):
$calltel = $callsms = '';
endif;
}-->
<!--{if ($v[hb_num]>$v[hb_sendnum] && !$v[hongbaolog]) && $config[subscribe] && !getcookie('miniprogram') && ($config['secert']||$config['magapp_secret'])&& HB_INWECHAT}-->
<!--{eval
$wxpay = $config['appid'] && $config['appsecert'] && $config['key'];
if(HB_INWECHAT && $wxpay):
$openid = $_G['cookie'][$ckey] ? authcode($_G['cookie'][$ckey], 'DECODE', $authkey) : '';
  if(!$openid):
   $tools = new JsApiPaySF();
   $opendata = $tools->GetFollowOpenid(hb_currenturl().'&oauth=yes');
   if($openid = $opendata['openid']):
    dsetcookie($ckey, authcode($openid, 'ENCODE', $authkey), 864000);
   endif;
  endif;
endif;
}-->
<!--{/if}-->
<!--{eval
$vavatar = avatar($v['uid'], 'middle', 1);
$subtit = $disvar = '';
foreach($v[vars] as $___k => $___v):
  if($___v[autoin]):
    $subtit = ' '.$___v[html];
  endif;
endforeach;
if($v[vars]):
  $v[vars] = array_values($v[vars]);
endif;
if($catinfo['pid']>0 && function_exists('array_column')):
    $pidindex = array_search($catinfo['pid'], array_column($cat_list, 'id'));
    $pidcat = $cat_list[$pidindex];
endif;
$hasvideo = $v['video'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php');
$icc = count($v[imglist]);
$vimglist = range(0, $icc-1);
if($hasvideo):
    $vimglist = range(0, $icc);
    $icc ++;
endif;
$no_header_fix = 1;

$adwhere = array();
$adwhere[] = 'types=\'view\'';
if($v['catid']):
    $adwhere[] = '( FIND_IN_SET('.intval($v['catid']).' , catids) OR FIND_IN_SET(-1, catids) )';
else:
    $adwhere[] = '( FIND_IN_SET(-1, catids) )';
endif;
$index_list =  C::t('#xigua_hb#xigua_hb_index')->list_by_where($adwhere);
$newindex_list = array();
if($index_list):
    foreach ($index_list as $index => $item):
        $newindex_list[$item['style']][] = $item;
    endforeach;
endif;
}--><style>#qrpr>div.weui-cells{padding:0 .75rem 0!important;}#qrpr>div.weui-cells:after{display:none}
.cl_v_head_img .swipe-wrap::after{display:block;content:'';position:absolute;bottom:0;left:0;z-index:10;width:100%;height:2rem;background-image:linear-gradient(180deg,rgba(62,62,62,0) 0,rgba(29,29,29,.6) 100%)}
.cl_v_head_img .bullets{position:absolute;right:0;bottom:1rem;color:#fff;width:auto;left:inherit;z-index:20;background: rgba(0,0,0,.35);border-radius:10rem 0 0 10rem;padding: 0 .5rem;font-size: .7rem}
.clv_carinfo{position:relative;z-index:0;padding:.7rem 1rem;background:#fff}
.clv_carinfo .clv_cartitle{font-size:.9rem;line-height:1.3;color:#1B1B1B;font-weight: bold;margin-bottom: 1rem;}
.clv_twoline{overflow:hidden;text-overflow:ellipsis;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;word-break:keep-all}
.clv_cinfo{display:-webkit-box;display:-ms-flexbox;display:flex;padding:.8rem 0 .8rem;width:100%}
.clv_cinfo_item{position:relative;-webkit-box-flex:1;-ms-flex:1;flex:1;text-align:left;padding-right:0}
.clv_cinfo_item:not(:first-child){margin-left:.5rem}.clv_cinfo_item:not(:last-child){padding-right:.5rem}
.clv_cinfo_item:not(:last-child):before{-webkit-transform:scaleX(.5);position:absolute;-webkit-box-sizing:border-box;box-sizing:border-box;display:block;content:"";pointer-events:none;top:0;right:0;bottom:0;border-right:.05rem solid #f8f9fc;-webkit-transform-origin:right top}
.clv_cinfo_item_name{font-size:.6rem;color:#666d7f}
.clv_cinfo_item_val{display:block;margin-top:.2rem;line-height:1.2rem;color:#333;font-size:.8rem;font-weight:500;text-overflow:ellipsis;white-space:nowrap;max-width:33vw;overflow:hidden}
.clv_cinfo_item:first-child .clv_cinfo_item_val{color:red}
.acti_jlcl_list li.tags{color:#666d7f;border-bottom:none}
.acti_jlcl_list li.acti_jlcltags p{float:left;margin-top:.8rem;margin-right:.4rem;padding:0 .1rem;height:1rem;line-height:1rem;border:1px solid #e6ebf5;border-radius:.2rem 0 .2rem 0}
.acti_jlcl_list li.acti_jlcltags p:last-of-type{margin-right:0}
.acti_jlcl_list li.acti_jlcltags p span{display:block;font-size:.7rem;transform:scale(.8)}
.vehicle-file{background: #fff;padding: .7rem 1rem;}
.bordebottom{border-bottom:1px solid #f8f9fc}
.part-title{padding: .3rem 0 .8rem 0;font-size: .9rem;color: #111e36;line-height: 1;font-weight: normal;}
.vehicle-file .base-data{display:-webkit-box;display:flex;flex-wrap:wrap;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between}
.vehicle-file .base-data li{width:100%;line-height:1.8}
.vehicle-file .base-data li .item-option{font-size:.7rem;color: #999;margin-right: .75rem;}
.vehicle-file .base-data li .item-status{font-size:.7rem;color:#111e36}
.jlcl_report{padding:0 1rem .7rem;display:-webkit-box;display:-webkit-flex;display:-ms-flexbox;display:flex;-webkit-box-pack:justify;-webkit-justify-content:space-between;-ms-flex-pack:justify;justify-content:space-between;background:#fff}
.jlcl_report .jlcl_report_text p {font-size: .7rem;line-height: 2rem;overflow: hidden;width: 100%;white-space: nowrap;text-overflow: ellipsis;}
.jlcl_report .jlcl_report_sign{text-align:center}
.jlcl_report .jlcl_report_sign a{display:block;height:2rem}
.jlcl_report .jlcl_report_sign a .sign_danger{display:inline-block;width:1.1rem;height:1.1rem;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAADLElEQVR4Ae2aA7DeQBDHa9t2O6ht227vLqlt27YGtW3btm3bZr5u92Yyzy/9EL/szD4ffvlv7m73XjjHHHPMMcccC6MGnTpFBUGo5iKkm4vSTsBYOVi9OqItYV2MtUbINxIhENAR/hEQUsNesJSODAgZAvRfidKW9ghjSksisEsJWIb+Bo0bZ7E2LL6fCHuVA7nllO6weii35yCeOAhCZWuq27p1XL9FygPHNtdg6NBIVlR3ojKc4vvcwVrqNmmSESf9y2tgjAxo2jSeZYAlSjf4AXgPPcky25CvsNx5hIAoZjI37NChEVCZ82oAy77R3KFMSHN0UNOBsdLmVLd9+1io7nO1gbHPCzxyzLcNETJKbVg/Z6yFudRt3DgNKvHDTcUWSpRShGiE329xcwF7wSPITIeMFW7CrgjYDgDCI/xJN9uONss2VNiDrWZgCA9rvpvAP4CxtMbCygrpASy3X2nsNiQIjE9EL2DuIIpFjFG3W7foCPBYb2CJ0lM8soyoUQ3iE9AbWIYW9VVXFJPjRL8aBYxtnvAI0/OQsYAPbBSwDD1YL3Xz8CqjCYC/AiEp9Mh1D/EBDQb2O7VpfcioywcyDTBGGjCWV6tcNwpO7p6ZgGU/rNV5uZcKqd7oEPpd5Wu/QEg9ddVt1iwxTuyTCsDPQRRz+vXLWDm/7c23yLnPL+rUVHemykn9S/S3KvfZWx11GzXK5iJE4p2a2XkE4lyTqLEN7TY7bIDQnuWbuoRUtQqsDCyBIGT3dhuK5KL0hnWAZad0j7fn5c6aqMDYDH4PDJTm8LuhUNlR5WqeqctYfAR+p8HTP6TmYUZhAbsJrVtH9mQbmqrRSjouhEVxjUaR1MXdkmsWnNhvjd6xYwGrFdC0aTQc66FGD/c9tGiRwJ1taLPG++UiICQ3CEIhHGunpmMxNk21kqtFtqk/eCxOrbQyL7MTsKzyiNCB5ffJVk7pfiXgH7ZTmNJrSiF9127A6LsUq5E2VLifUrKQj9eJbLRKf+HFi/+docfaaMGi7v5jyhiLK/uNX/SF88R4XskzG34cxA4e8C3L1E7ILb5A8Tsvv8qH/c0xx/4BVg45kkK/F5IAAAAASUVORK5CYII=) no-repeat;background-size:1.1rem 1.1rem}
.jlcl_report .jlcl_report_sign a p{font-size:.6rem;color:#111e36;line-height:1}
.jlcl_report .line {height:2rem;border-right:1px solid #f8f9fc}
.jlcl_report_text{overflow: hidden;width:calc(100% - 4rem)}
.auto_analysis{margin-bottom:.8rem;font-size:.7rem;line-height: 1.5;color:#1B1B1B}
.merchant-info .merchant-logo{float:left;width:2rem;height:2rem;margin-right:.5rem;border-radius:2rem}
.merchant-info .arrow-right{float:right;width:.3rem;height:.6rem;margin-top:.8rem;background:url(source/plugin/xigua_hb/static/css/aroright.png) no-repeat;background-size:.3rem .6rem}
.merchant-info .merchant-title{height:.8rem;font-size:.8rem;color:#111e36}
.merchant-info .merchant-address,.merchant-info .merchant-title strong{overflow:hidden;white-space:nowrap;text-overflow:ellipsis}
.merchant-info .merchant-title strong{display:inline-block;max-width:44%;vertical-align:middle}
.merchant-info .merchant-title strong.show-half{max-width:60%}
.merchant-info .merchant-address{max-width:80%;height:.6rem;margin-top:.55rem;font-size:.6rem;color:#999;line-height:1}
.jl_cl_cmt_box{padding:.25rem}.jl_clv_bottom{box-shadow:0 0 0.5rem rgba(0,0,0,.1)}
.footer-bottom{display:-webkit-box;display:flex;position:fixed;left:0;bottom:0;padding-left:.5rem;padding-right:.5rem;padding-top:.5rem;padding-bottom:calc(.5rem + constant(safe-area-inset-bottom));padding-bottom:calc(.5rem + env(safe-area-inset-bottom));width:100%;background:#fff;box-sizing:border-box;z-index:499}
.footer-bottom .btns-icon{display:-webkit-box;display:flex;flex:1}
.footer-bottom a,.footer-bottom span{display:inline-block;overflow:hidden;text-overflow:ellipsis;position:relative}
.footer-bottom .item-focus,.footer-bottom .item-loan{padding-top:.3rem;color:#111e36}
.footer-bottom .btns-icon .item-focus,.footer-bottom .btns-icon a{flex:1;text-align:center}
.footer-bottom .btns-icon i{line-height:1}
.footer-bottom .item-prize,.footer-bottom .item_clinfo{height:2rem;line-height:2rem;background:linear-gradient(134deg,#f60,red);border-radius:2rem;text-align:center;font-size:.8rem;color:#fff;flex:1}
.footer-bottom .item-prize{margin-right:.5rem;background: linear-gradient(135deg,#ff9e00,#ff6129);}
.x_header_fix{height:0}.navtitle{display:none!important;}.x_header{background: transparent!important;position: absolute;}
.maintg{background:{$config[maincolor]};border-color:{$config[maincolor]}!important;color: #fff;}
#qrpr>div.weui-cells{margin:0 -1rem;}#qrpr .clv_carinfo{top:0}.cl_timeu{position: absolute;left: 1rem;bottom: 1rem;color: #fff;width: auto;font-size: .8rem;z-index: 20;}
#qrpr .vehicle-file{margin-bottom:.5rem}
.pub_es_view{font-size: 0.65rem;margin-top:.5rem;color: #999;}
.x_header a {text-shadow: 0 0 8px rgba(0,0,0,.6);}.footer-bottom-user{width:6rem!important;flex:none!important;line-height:1rem!important;text-align:left!important}
.footer-bottom-user img{width:2rem;height:2rem;float:left;margin-right:.5rem;border-radius:2rem}
.footer-bottom-user em{font-size:.7rem;color:#000;display:block;white-space: nowrap;overflow: hidden;}
.footer-bottom-user em:last-child{display:block;position:absolute;left:2.5rem;font-size:.6rem;background:#f60;color:#fff;line-height:.8rem;height:.8rem;bottom:0;padding:0 .3rem;border-radius:.5rem}
.footer-bottom-user em.shj{background:#4489df}
<!--{if !($v[imglist] || $hasvideo)}-->.x_header{display:none!important;}.clv_carinfo{top:0}<!--{/if}-->
</style>
<div class="page__bd">
    <!--{if $config[hbimg]&&$v[hb_money]>0}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$config[hbimg]" /></div><!--{/if}-->
    <!--{template xigua_hb:common_nav}-->
    <div class="none view_tools_mask"></div>
    <div class="none view_tools animated">
        <ul>
            <!--{if $config[showguide]}-->
            <li class="border_bottom"><a href="javascript:;" style="left:-.15rem" class="we_share pr" data-id="$v[id]"><i class="vm iconfont icon-fenxiang1 f20"></i> {lang xigua_hb:shares}</a></li>
            <!--{/if}-->
            <li class="border_bottom" ><a href="$SCRITPTNAME?id=xigua_hb&ac=cat"><i class="vm iconfont icon-fenlei "></i> {lang xigua_hb:cat}</a></li>
            <li><a href="$SCRITPTNAME?id=xigua_hb&ac=my"><i class="vm iconfont icon-xiaolian2 "></i> {lang xigua_hb:wode}</a></li>
        </ul>
    </div>
    <div class="cl_v_head_img ">
        <!--{if $v[imglist] || $hasvideo}-->
        <div class="fc_swipe cl" style="position:relative;margin:0;overflow:hidden" <!--{if $hasvideo}-->data-speed="60000000"<!--{else}-->data-speed="6000"<!--{/if}-->>
        <div class="swipe-wrap" style="transition: all .3s;-webkit-transition: all .3s">
            <!--{if $hasvideo}-->
            <div class="swp" style="background:#000"><video poster="{$v['video_cover']}" style="width:100%;display:block;max-height:75vh" src="{$v['video']}" controls="controls" <!--{if !IN_PROG}-->x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<!--{/if}-->></video></div>
            <!--{/if}-->
            <!--{loop $v[imglist] $_k $slider}-->
            <div class="imgloading swp"><img style="/*;object-fit:contain;*/;max-height:75vh" src="$slider"  onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" /> </div>
            <!--{/loop}-->
        </div>
        <nav class="bullets "><em>1</em> / <em>$icc</em></nav>
    </div>
    <!--{/if}-->
    <div class="shottag1 bgf">
        <section class="clv_carinfo normal_style cl">
        <h5 class="clv_cartitle "><!--{if $catinfo['pid']>0 && $pidcat[name]}-->{$pidcat[name]} | {$catinfo[name]}<!--{else}-->{$catinfo[name]}<!--{/if}--> <!--{if $subtit}--> {lang xigua_hb:dot1} $subtit<!--{/if}--></h5>
        <div class="v_es_price">
            <!--{if $v[vars][1][value] && !is_array($v[vars][1][value])}-->
            <div class="es_price"><em><!--{if is_numeric($v[vars][1][value])}--><i>&yen;</i> <!--{/if}-->$v[vars][1][value]</em> <del><!--{if is_numeric($v[vars][2][html])}--><i>&yen;</i> <!--{/if}-->$v[vars][2][html]</del></div>
            <!--{elseif $v[vars][0][value] && !is_array($v[vars][0][value])}-->
            <div class="es_price"><em><!--{if is_numeric($v[vars][0][value])}--><i>&yen;</i> <!--{/if}-->$v[vars][0][value]</em> <del><!--{if is_numeric($v[vars][2][html])}--><i>&yen;</i> <!--{/if}-->$v[vars][2][html]</del></div>
            <!--{/if}-->
        </div>
        <ul class="cl es_tag">
            <!--{if $catinfo['pid']>0 && $pidcat[name]}--><li class="es_tag_li">{$pidcat[name]}</li><!--{/if}-->
            <!--{if $catinfo[name]}--><li class="es_tag_li">{$catinfo[name]}</li><!--{/if}-->
            <!--{if array_filter($v[tags])}-->
            <!--{loop $v[tags] $k $tag}-->
            <!--{if $tag}--><li class="es_tag_li">$tag</li><!--{/if}-->
            <!--{/loop}-->
            <!--{/if}-->
        </ul>
            <div class="pub_es_view cl"><span class="z">{$v[time_u]} <!--{if $v[refresh_times]}-->{lang xigua_hb:shuaxin}<!--{else}-->{lang xigua_hb:fabu0}<!--{/if}--></span><span class="y">{lang xigua_hb:liulan} $v[views] {lang xigua_hb:c}</span></div>
        </section>
    </div>

    <section class="vehicle-file mt10">
        <h3 class="part-title">{lang xigua_hb:jbxx}</h3>
        <ul class="base-data">
            <!--{loop $v[vars] $___k $___v}-->
            <li><span class="item-option">{$___v[title]}</span><span class="item-status ">
<!--{if $___v[html]&&is_string($___v[html])}--><!--{if strpos($___v[html], '.jp')!==false||strpos($___v[html], '.png')!==false||strpos($___v[html], '.gif')!==false}--><img src="{$___v[html]}" style="max-width:100%" /><!--{else}-->{$___v[html]}<!--{/if}--><!--{else}-->
<!--{if strpos($___v[value], '.jp')!==false||strpos($___v[value], '.png')!==false||strpos($___v[value], '.gif')!==false}--><img src="{$___v[value]}" style="max-width:100%" /><!--{else}-->{$___v[value]}<!--{/if}-->
<!--{/if}-->
                    </span></li>
            <!--{/loop}-->
        </ul>
    </section>

    <section class="vehicle-file mt10">
        <h3 class="part-title">{lang xigua_hb:xxms}</h3>
        <!--{if $v[description]}-->
        <div class="auto_analysis">{echo hb_nl2br($v[description])}<br>{echo str_replace('tname', $stinfo['name']?$stinfo['name']:$config[tname], $config[seefrom])}</div>
        <!--{else}-->
        <p class="auto_analysis">{$v[realname]}{lang xigua_hb:tl}<br>{echo str_replace('tname', $stinfo['name']?$stinfo['name']:$config[tname], $config[seefrom])}</p>
        <!--{/if}-->
    </section>
    <!--{if $v[sh]}-->
    <section class="vehicle-file mt10">
        <h3 class="part-title">{lang xigua_hb:sjxx}</h3>
        <div class="merchant-info">
            <a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid={$v[sh][shid]}"><img src="{$v[sh][logo]}" class="merchant-logo"><span class="arrow-right"></span>
                <h5 class="merchant-title"><span class="show-half">{$v[sh][name]}</span></h5>
                <p class="merchant-address">{lang xigua_hb:dz}: {$v[sh][addr]}</p>
            </a>
        </div>
    </section>
    <!--{else}-->
    <section class="vehicle-file mt10">
        <div class="merchant-info">
            <div class="cl" onclick="hb_jump('$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]');"><img src="{$vavatar}" class="merchant-logo"><span class="arrow-right"></span>
                <h5 class="merchant-title"><span class="show-half">{$v[realname]}</span></h5>
                <p class="merchant-address">{$v[time_u]}<!--{if $v[refresh_times]}-->{lang xigua_hb:shuaxin}<!--{else}-->{lang xigua_hb:fabu0}<!--{/if}-->
                    <!--{eval
    if($_G['cache']['plugin']['xigua_hr']):
    $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($v[uid]));
    $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris(array($v[uid]), 2);
    $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb(array($v[uid]));
    endif;
    if($_G['cache']['plugin']['xigua_hr']['showhbview']):
    $shwv1 =1;
    endif;
    if($_G['cache']['plugin']['xigua_hr']['showbview']):
    $shwv2 =2;
    endif;
    }-->
                    <!--{if $veris1[$v[uid]] && !$veris2[$v[uid]]}--><a href="javascript:;"><i class="iconfont icon-duigou2 f12 main_color"></i> {lang xigua_hr:gr}</a><!--{/if}-->
                    <!--{if $veris2[$v[uid]]}--><a href="javascript:;"><i class="iconfont icon-duigou2 f12 main_color"></i> {lang xigua_hr:qy}</a><!--{/if}-->
                    <!--{if $bao[$v[uid]]}--><a href="javascript:;"><i class="iconfont icon-duigou2 f12 main_color"></i> <!--{if $_G[cache][plugin][xigua_hr][bzjed]}-->{$_G[cache][plugin][xigua_hr][lbbzjqz]}{$bao[$v[uid]][price]}{lang xigua_hb:yuan}<!--{else}-->{lang xigua_hr:yjbzj}<!--{/if}--></a><!--{/if}-->
                </p>
            </div>
        </div>
    </section>
    <!--{/if}-->
    <div class="jlcl_report">
        <div class="jlcl_report_text">
            <p>{lang xigua_hb:jbydc}</p>
        </div>
        <p class="line"></p>
        <div class="jlcl_report_sign">
            <a href="$SCRITPTNAME?id=xigua_hj">
                <span class="sign_danger"></span>
                <p>{lang xigua_hb:djjb}</p>
            </a>
        </div>
    </div>
</div>
<!--{if $catinfo['share_pic']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$catinfo['share_pic']" /></div><!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_f']['defaultlogo']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$_G['cache']['plugin']['xigua_f']['defaultlogo']" /></div><!--{/if}-->
<div class="shottag2 none"><div class="feed_imglist cl feed-preview-pic"><img src="{echo $v[imglist][0]?$v[imglist][0]:$v['video_cover']}" /></div></div>

<!--{loop $newindex_list $_k $_v}-->
<!--{if $_k==99}-->
<div class="swipe cl" data-speed="5000">
    <div class="swipe-wrap">
        <!--{loop $_v $__k $__v}-->
        <div><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1 none">
        <ul class="position">
            <!--{loop $_v $__k $__v}-->
            <li <!--{if $__k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{else}-->
<!--{eval
if(!$_k):
    $_k = 4;
endif;
$tmpp = array_chunk($_v, $_k);
}--><!--{loop $tmpp $__k $tmpp2}-->
<!--{eval $counttmpp2 = count($tmpp2);}-->
<ul class="inedxicon cl" style="padding:0">
    <!--{loop $tmpp2 $__k $__v}-->
    <li style="width:{echo 100/$counttmpp2;}%"><a href="$__v[adlink]"><img src="$__v[icon]"></a></li>
    <!--{/loop}-->
</ul>
<!--{/loop}-->
<!--{/if}-->
<!--{/loop}-->

<!--{if $v[hb_num]}-->
<div class="weui-cells__title weui_title border_none"><span>{lang xigua_hb:yiqiang}<em class="color-red">$v[hb_sendnum]</em>/$v[hb_num]{lang xigua_hb:fen}</span> <!--{if $v[hb_sendnum]}--><a class="y c9" href="$SCRITPTNAME?id=xigua_hb&ac=hong_list&pubid=$v[id]">{lang xigua_hb:kk}<i class="f13 iconfont icon-jinrujiantou"></i></a><!--{/if}--></div>
<div class="weui-cells after_none" id="hong_preview_list"></div>
<!--{/if}-->
<!--{if !$config[closepl]}-->
<div class="bgf mt10">
    <div class="jl_cl_cmt_box">
        <div class="weui-cells__title weui_title border_none bordebottom mt0"><span class="part-title">{lang xigua_hb:comments}</span> <a class="comment y" style="color:#111e36" id="comment_$v[id]" data-id="$v[id]" data-multi="1">{lang xigua_hb:wycomments}<i class="f13 iconfont icon-jinrujiantou"></i></a></div>
        <div class="weui-panel weui-panel_access mt0 after_none before_none">
            <div class="weui-panel__bd comment_ul" id="comment_ul_$v[id]" data-id="$v[id]">
            </div>
        </div>
    </div>
</div>
<!--{/if}-->

<!--{if $config[showother]}-->
<!--{template xigua_hb:list_by_cat}-->
<!--{/if}-->

<!--{if !IN_PROG && $v[hb_num]>$v[hb_sendnum] && !$v[hongbaolog]}-->
<a href="javascript:;"  style="position: fixed;right: .5rem;bottom: 15rem;z-index:99" <!--{if $_G[uid]}--> <!--{if $v[hbtiaojian]}-->onclick="return showfxhb();"<!--{else}-->class="qiang"<!--{/if}--><!--{else}-->onclick="return checklogin();"<!--{/if}-->><img src="source/plugin/xigua_hb/static/img/hbic.png" style="width: 3rem;display: block;"></a>
<!--{if 1}-->
<div class="hong_res animated zoomIn" id="hong_res">
    <a class="hong_close"><i class="iconfont icon-guanbijiantou f22"></i></a>
    <div class="hong_res_wrap">
        <div class="hong_res_head">
            <div class="hong_res_head_in">
                <img src="{$vavatar}">
            </div>
        </div>
        <div class="hong_res_cnt">
            <div class="hong_res_box">
                <p>{$v[realname]}</p>
                <p>{lang xigua_hb:maile}</p>
            </div>
            <div class="hong_res_list">
                <div class="send_title"></div>
                <div class="hong_tip">{lang xigua_hb:gongxihou}</div>
                <div class="money_bg">
                    <p class="hong_money">
                        <i>&yen;</i>
                        <span id="hong_size">{$v[hb_money]}</span>
                        <em>{lang xigua_hb:yuan}</em>
                    </p>
                </div>
                <a <!--{if !(IN_MAGAPP || IN_QIANFAN)&&$config[qbguide]&&$config[qbguidelink]}-->onclick="return jump_download();"<!--{else}--><!--{if IN_QIANFAN && $config['autoinapp']}-->onclick="QFH5.jumpMyPackage();"<!--{elseif IN_MAGAPP&&$config['autoinapp']}-->onclick="mag.newWin('/mag/user/v1/user/wallet');"<!--{else}-->href="$SCRITPTNAME?id=xigua_hb&ac=qianbao"<!--{/if}--><!--{/if}--> class="sub_title">{lang xigua_hb:zidongfang}</a>
            </div>
        </div>
        <div class="view_oth">
            <a href="$SCRITPTNAME?id=xigua_hb&ac=hong_list&pubid=$v[id]">{lang xigua_hb:kkdaj}</a>
        </div>
        <div class="sub_bg"></div>
    </div>
</div>
<div class="hong_res hong_box" id="hong_box">
    <div class="hong_box_main zoomIn animated ">
        <div class="hong_box_title">
            <div class="send_title"></div>
            <div class="hong_star"></div>
            <div class="hong_box_showname">
                <p>{lang xigua_hb:zongji}{$v[hb_money]}{lang xigua_hb:yuan}</p>
            </div>
            <div class="hong_btn animated" id="hong_btn" onclick="showHongBox(this);">
                <div class="hong_btn_mask"></div>
                <a href="javascript:;"> </a>
            </div>
        </div>
        <div class="hong_from">
            <p>{$v[realname]}</p>
            <p>{lang xigua_hb:mai}</p>
        </div>
        <div class="view_oth">
            <p>{lang xigua_hb:lingqu}{$config['tname']}{lang xigua_hb:qb}</p>
        </div>
        <div class="sub_bg"></div>
    </div>
</div>
<!--{/if}-->
<!--{if $config[voice]}-->
<div class="none"><audio id="media" preload="preload"><source src="{$config[voice]}" type="audio/mpeg" /></audio></div>
<!--{/if}-->
<!--{if !$_G[uid]}-->
<script>
    function checklogin(){
        $.showLoading();
        $.ajax({
            type: 'get',
            url: '$SCRITPTNAME?id=xigua_hb&ac=my&inajax=1',
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {
                $.hideLoading();
            }
        });
    }
</script>
<!--{/if}-->
<script>
    var HAS_QIANG = 0, Qlock =0;
    function showHongBox(obj) {
<!--{if $v[hbtiaojian]<=0}-->
        $('#wechat-mask').hide();
        if(Qlock || HAS_QIANG){ console.log('false'); return false;}
        Qlock = 1;
        $.ajax({
            type: 'post',
            url: '$SCRITPTNAME?id=xigua_hb&ac=qiang&pubid=$v[id]&inajax=1'+(typeof hbareaallow !=='undefined'?'&lat='+hblat+'&lng='+hblng:'' ),
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    HAS_QIANG = 1;
                    $('#hong_box').removeClass('show').hide();
                    $('#hong_res').show();
                    $('#hong_size').html(s.split('|')[1]);
                    $('.fix-bottom').hide();
                }else{
                    $('#hong_size').html('???');
                    $('#hong_box').removeClass('show').hide();
                    tip_common(s);
                }
            },
            error: function () {
            }
        });
<!--{/if}-->
    }

    function focusHongBao(){
<!--{if $v[hbtiaojian]>0}-->
return false;
<!--{/if}-->
        <!--{if $config[subscribe] && !getcookie('miniprogram')&& HB_INWECHAT}-->
        var unscb = 0;
        $.showLoading();
        $.ajax({
            type: 'get',
            url: _APPNAME + '?id=xigua_hb&ac=checksub&inajax=1&openid=$openid',
            data: {formhash: FORMHASH},
            dataType: 'xml', async:false,
            success: function (data) {
                if (null == data) {
                    return false;
                }
                var s = $.trim(data.lastChild.firstChild.nodeValue);
                if (s.split('|')[1] != 'subscribe') {
                    unscb = 1;
                }
                $.hideLoading();
            }
        });

        $.hideLoading();
        if(unscb){
            /*if(typeof wx !=='undefined') {
              if (window.__wxjs_environment === 'miniprogram') {
                wx.miniProgram.navigateTo({url: '/pages/guanzhu/index'});
                return false;
              }
            }*/
            $.alert("<img src=$SCRITPTNAME?id=xigua_hb:qrauto&ode=pub_{$v[id]} /><br>{lang xigua_hb:gzq}", "{lang xigua_hb:gzqchangan}");
            return false;
        }
        <!--{/if}-->
        $.ajax({type: 'post',url: _APPNAME +'?id=xigua_hb&ac=incr&incr_type=shares&pubid=$pubid&inajax=1',data: {'formhash':FORMHASH},dataType: 'xml'});
        if(!HAS_QIANG) {
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hb&ac=qchk&pubid=$v[id]&inajax=1',
                data: {'formhash':FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    if(s.indexOf('success')!==-1){
                        $('#hong_box').addClass('show').show();
                        <!--{if $config[autoopen]}-->$('#hong_btn').trigger('click');<!--{/if}-->
                    }else{
                        $('#hong_box').removeClass('show').hide();
                        tip_common(s);
                    }
                }
            });
        }else{
            $.toast('{lang xigua_hb:qianguole}', 'error');
        }
    }
</script>
<!--{if HB_INWECHAT &&$v[hbtiaojian]<=0}-->
<script>
    <!--{if $config[onlytimeline]=='no'}-->
    function menuShareGet(){
        <!--{else}-->
        function menuShareTimeline(){
            <!--{/if}-->
            focusHongBao();
        }
        function menuShareTimelineErr(){
            $.toast('{lang xigua_hb:quxiaofenxiang}');
            $('#wechat-mask').hide();
        }
        function menuShareCommon(){
            <!--{if $config[onlytimeline] == 'pyq'}-->
            $.toast('{lang xigua_hb:fenxiangqiang}');
            $('#wechat-mask').hide();
            <!--{else}-->
            if(typeof 'menuShareTimeline'!=='undefined'){
                menuShareTimeline();
            }
            if(typeof 'menuShareGet'!=='undefined'){
                menuShareGet();
            }
            <!--{/if}-->
        }
        function menuShareCommonErr(){
            menuShareTimelineErr();
        }
</script>
<!--{elseif IN_MAGAPP}-->
<script>
    function menuShareGet() {
        <!--{if $config[onlytimeline]=='py'}-->
        mag.share('ALL', function (res) {
            focusHongBao();
        });
        <!--{/if}-->
        <!--{if $config[onlytimeline]=='pyq'}-->
        mag.share('WEIXIN_CIRCLE', function (res) {
            focusHongBao();
        });
        <!--{/if}-->
        <!--{if $config[onlytimeline]=='no'}-->
        focusHongBao();
        <!--{/if}-->
    }
</script>
<!--{elseif IN_QIANFAN}-->
<script>
    <!--{if $config[onlytimeline]=='py'}-->
    $(document).on('click', '.qiang', function(){
        if(typeof hbareaallow !=='undefined') {
            if(!hbareaallow()){
                return false;
            }
        }
        QFH5.openShareDialog();
    });
    function openShareDialog(){
        focusHongBao();
    }
    <!--{/if}-->
    <!--{if $config[onlytimeline]=='pyq'}-->
    $(document).on('click', '.qiang', function(){
        if(typeof hbareaallow !=='undefined') {
            if(!hbareaallow()){
                return false;
            }
        }
        QFH5.openShare(1);
    });
    function openShare(){
        focusHongBao();
    }
    <!--{/if}-->
    <!--{if $config[onlytimeline]=='no'}-->
    $(document).on('click', '.qiang', function(){
        if(typeof hbareaallow !=='undefined') {
            if(!hbareaallow()){
                return false;
            }
        }
        focusHongBao();
    });
    <!--{/if}-->
</script>
<!--{elseif IN_APPBYME}-->
<script>
    <!--{if $config[onlytimeline]=='py'}-->
    connectSQJavascriptBridge(function(){
        sq.setShareCallBack(function(data){
            //alert(JSON.stringify(data));//sharePlat
            if(data.errmsg=='SHARE_OK'||data.errmsg=='OK'){
                focusHongBao();
            }
        });
    });
    <!--{/if}-->
    <!--{if $config[onlytimeline]=='pyq'}-->
    connectSQJavascriptBridge(function(){
        sq.setShareCallBack(function(data){
            //alert(JSON.stringify(data));//sharePlat
            if((data.errmsg=='SHARE_OK'||data.errmsg=='OK') && data.sharePlat=='MOMENTS'){
                focusHongBao();
            }
        });
    });
    <!--{/if}-->
    <!--{if $config[onlytimeline]=='no'}-->
    $(document).on('click', '.qiang', function(){
        if(typeof hbareaallow !=='undefined') {
            if(!hbareaallow()){
                return false;
            }
        }
        focusHongBao();
    });
    <!--{/if}-->
</script>
<!--{else}-->
<!--{if $config[onlytimeline]=='no'}-->
<script>
    $(document).on('click', '.qiang', function(){
        if(typeof hbareaallow !=='undefined') {
            if(!hbareaallow()){
                return false;
            }
        }
        focusHongBao();
    });
</script>
<!--{/if}-->
<!--{/if}-->
<!--{/if}-->
</div>
<!--{if ($_G[uid] == $v[uid]||IS_ADMINID) }-->
<a href="javascript:;" style="bottom:7rem;" class="hbzder1 main_bg" id="pubitem_$v[id]" data-id="$v[id]" data-uid="$v[uid]" data-wc="{$v[wancheng]}" <!--{if $v[display]}-->data-canzd="1"<!--{/if}--> <!--{if (!$v[hb_num]||$v[hb_num]==$v[hb_sendnum])&&$v[display]&&$config[red]}-->data-canhb="1"<!--{/if}--> <!--{if !$v[pay_status]}-->data-catid="$v[catid]"<!--{/if}--> onclick="return showansi(this);"><!--{if $_G[uid] == $v[uid]}-->{lang xigua_hb:kuosan}<!--{elseif IS_ADMINID}-->{lang xigua_hb:guanli0}<!--{/if}--><i class="iconfont icon-jinrujiantou f12"></i></a>
<!--{/if}-->
<!--{if IN_PROG}--><a href="$SCRITPTNAME?id=xigua_hb" style="bottom:11rem;" class="hbzder1 main_bg">{lang xigua_hb:shouye}<i class="iconfont icon-jinrujiantou f12"></i></a><!--{/if}-->
<div class="footer_fix"></div>
<div class="footer-bottom jl_clv_bottom">
    <p class="btns-icon">
        <a class="cl footer-bottom-user" href="javascript:;"  onclick="hb_jump('$SCRITPTNAME?id=xigua_hb&ac=member&uid=$v[uid]');">
            <img src="{$vavatar}">
            <em>{$v[realname]}</em>
            <!--{if $v[sh]}-->
            <em class="shj">{lang xigua_hb:shj}</em>
            <!--{else}-->
            <em>{lang xigua_hb:j}{lang xigua_hb:ren}</em>
            <!--{/if}-->
        </a>
    </p>
    <!--{if $kflnk}--><!--{eval
    if(!(IN_QIANFAN||IN_MAGAPP) && ($config[magapp_secret] || $config[hostname])):
        $kflnk = "$SCRITPTNAME?id=xigua_hb&ac=chat&touid=$v[uid]";
    endif;
    $bttxt = lang_hb('sx', 0);
$callsms = $kflnk;}--><!--{/if}--><!--{if $config[showsms] && $callsms}-->
    <a href="$callsms" class="item-prize ">$bttxt</a>
    <!--{if $calltel}-->
    <a href="$calltel" class="item_clinfo">
        <span class="footer-item">{lang xigua_hb:boda}</span>
    </a>
    <!--{/if}-->
    <!--{elseif $calltel}-->
    <a href="$calltel" class="item_clinfo">
        <span class="footer-item">{lang xigua_hb:boda}</span>
    </a>
    <!--{else}-->
    <a href="$callsms" class="item-prize ">$bttxt</a>
    <!--{/if}-->
</div>
<script>
    var TIMELINE_TITLE = '{$navtitle}'<!--{if 0}-->, custom_title = '{$v[realname]}{lang xigua_hb:fblyt}{$catinfo[name]}{lang xigua_hb:xinxi}'<!--{/if}-->;
    var loadingurl = '$SCRITPTNAME?id=xigua_hb&ac=list_item&cat_id={$v[catid]}&notpubid=$v[id]&inajax=1&pagesize=5&page=';
    function shareIncr(){
        $.ajax({type: 'post',url: _APPNAME +'?id=xigua_hb&ac=incr&incr_type=shares&pubid=$pubid&inajax=1',data: {'formhash':FORMHASH},dataType: 'xml'});
    }
</script>
<!--{if $config[xxhb]}-->
<!--{template xigua_hb:qrcode}-->
<!--{/if}-->
<!--{template xigua_hb:common_footer}-->
<script>
    setTimeout(function () {$('.hbzder1').addClass('r-21');}, 800);
    if($('#hong_preview_list').length>0){
        load_common_list('$SCRITPTNAME?id=xigua_hb&ac=hong_li&pubid=$v[id]&inview=1&inajax=1&pagesize=5', 'hong_preview_list');
    }
    <!--{if !$config[closepl]}-->
    load_common_list('$SCRITPTNAME?id=xigua_hb&ac=comment_li&pubid=$v[id]&inajax=1&pagesize=5&needmore=1', 'comment_ul_$v[id]');
    var cpage = 1;
    $(document).on('click', '#comment_ul_more', function(){
        $('#comment_ul_more').remove();
        cpage ++;
        load_common_list('$SCRITPTNAME?id=xigua_hb&ac=comment_li&pubid=$v[id]&inajax=1&pagesize=5&needmore=1&page='+cpage, 'comment_ul_$v[id]');
    });
    <!--{/if}-->
    $(function () {
        if(localStorage.getItem('wetip_{$pubid}')){
            $('.we_share').trigger('click');
            localStorage.removeItem('wetip_{$pubid}');
        }
        <!--{if $_G['uid'] && $v[hb_num]>0 && $v[hb_num]==$v[hb_sendnum] && !$v[hongbaolog]}-->
        if(!localStorage.getItem('hbtip_{$pubid}')){
            // $.toast('{lang xigua_hb:qiangwan}', 2000);
            $('body').append('<a href="$SCRITPTNAME?id=xigua_hb&ac=hongbao{$urlext}" class="qwl">{lang xigua_hb:qiangwan1}</a>');
            localStorage.setItem('hbtip_{$pubid}', 1);
        }
        <!--{/if}-->
        <!--{if $_G['cache']['plugin']['xigua_hs']}-->
        <!--{/if}-->
    });
    function jump_download() {
        $.confirm("$config[qbguide]", function() {
            window.location.href = '$config[qbguidelink]';
        }, function() {});
        return false;
    }
    <!--{if $distvar}-->
    $(document).on('click', '#hb_openLocation', function () {
        var that = $(this);
        if(('{HB_INWECHAT}' && "{$_G['cache']['plugin']['xigua_hb'][multiupload]}")==1){
            wx.openLocation({
                latitude: that.data('lat'),
                longitude: that.data('lng'),
                name: that.data('name'),
                address: that.data('addr'),
                scale: 14,
                infoUrl:window.location.href
            });
        }else if("{$_G['cache']['plugin']['xigua_hs']['google']}"){
            window.location.href = _APPNAME+'?id=xigua_hs&ac=googleMap&lat='+that.data('lat')+"&lng="+that.data('lng')+_URLEXT;
        }else{
            window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:"+that.data('lat')+","+that.data('lng')+";title:"+that.data('name')+";addr:"+that.data('addr');
        }
        return false;
    });
    <!--{/if}-->
    $(document).on('click','.dofollow', function () {
        var that = $(this);
        $.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME +'?id=xigua_hb&ac=fav&do=do_follow&pubid='+that.data('id')+'&inajax=1',
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.split('|')[1]> 0){
                    tip_common('success|{lang xigua_hb:sccg}||');
                    that.find('.iconfont').removeClass('icon-collection').addClass('icon-collection_fill');
                    that.find('em').text(s.split('|')[1]);
                }else{
                    tip_common(s);
                    that.find('em').text(that.find('em').text()-1);
                    that.find('.iconfont').removeClass('icon-collection_fill').addClass('icon-collection');
                }
            },
            error: function () {
                $.hideLoading();
            }
        });
    });
</script>
<!--{if $_G['cache']['plugin']['xigua_hs'] && trim($config['areaallow'])}-->
<script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script>
    var hblat = '', hblng = '';
    setTimeout(function () {
        hs_getlocation(function (position) {
            hblat = (position.latitude||position.lat);
            hblng = (position.longitude||position.lng);
        });
        if(typeof wx !=='undefined') {
            hs_getlocation(function (position) {
                hblat = (position.latitude||position.lat);
                hblng = (position.longitude||position.lng);
            });
        }
    }, 800);
    function hbareaallow(){
        var hb_areaallow = false;
        if(!hblat || !hblng) {
            $.toast('{lang xigua_hb:plzlat}', 'cancel');
            hs_getlocation(function (position) {
                hblat = (position.latitude||position.lat);
                hblng = (position.longitude||position.lng);
            });
            return false;
        }
        $.ajax({
            type: 'GET',
            async: false,
            url: _APPNAME + '?id=xigua_hs&ac=getloc&lat='+hblat+'&lng='+hblng+'&inajax=1&checkallow=1',
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('error')!=-1){
                    tip_common(s);
                    hb_areaallow =false;
                }else {
                    hb_areaallow = true;
                }
            },
            error: function () {
            }
        });
        return hb_areaallow;
    }
</script>
<!--{/if}-->
<!--{if !$_GET[ecid] && $info[uid]==$_G[uid] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/template/touch/share_dig.php')}-->
<!--{template xigua_hb:share_dig}-->
<!--{/if}-->
<!--{if is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/hbrw_send.php')}-->
<!--{template xigua_hb:hbrw_view}-->
<!--{/if}-->
<script>
$('div.fc_swipe').each(function () {
    fc_slider($(this), $(this).data('speed') || 3000)
});
var fc_seiper = null;
function fc_slider(_this, auto) {
    var bullets = _this.find('nav.bullets');
    var position = _this.find('ul.position');
    fc_seiper = new Swipe2(_this[0], {
        visibilityFullFit : true,
        startSlide: 0, speed: 500, auto: auto, continuous: true, callback: function (index) {
            if (bullets.length > 0) {
                bullets.find('em:first-child').text(index + 1);
            }
            if (position.length > 0) {
                var selectors = position[0].children;
                for (var t = 0; t < selectors.length; t++) {
                    selectors[t].className = selectors[t].className.replace("current", "");
                }
                if (typeof selectors[(index) % (selectors.length)] != 'undefined') {
                    selectors[(index) % (selectors.length)].className = "current";
                }
            }
            var H = $(".swipe-wrap .swp").eq(index).height();
            $('.fc_swipe .swipe-wrap').css('height', H);
            $('.fc_swipe').css('height', H);
        }
    });
}
var HTMP = $(".swipe-wrap .swp:first-child").height();
$('.fc_swipe .swipe-wrap').css('height', HTMP);
$('.fc_swipe').css('height', HTMP);
</script>