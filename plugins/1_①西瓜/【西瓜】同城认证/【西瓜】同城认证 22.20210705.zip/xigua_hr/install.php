<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_hr_verify` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `ct` int(1) NOT NULL,
 `uid` int(11) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 `realname` varchar(80) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `idcard` varchar(80) NOT NULL,
 `verinfo` varchar(800) NOT NULL,
 `zm` varchar(800) NOT NULL,
 `fm` varchar(800) NOT NULL,
 `status` tinyint(1) NOT NULL,
 `status_info` text NOT NULL,
 `company_name` varchar(80) NOT NULL,
 `zz` varchar(200) NOT NULL,
 `company_type` varchar(80) NOT NULL,
 `company_num` varchar(80) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `ct` (`ct`,`uid`),
 KEY `status` (`status`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hr_paybao` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `order_id` char(24) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `note` varchar(800) NOT NULL,
 `crts` int(11) NOT NULL,
 `status` int(1) NOT NULL COMMENT '-1:notpay 1:normal 2:back',
 `stid` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `payts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `uid` (`uid`),
 KEY `order_id` (`order_id`),
 KEY `hxstatus` (`status`),
 KEY `stid` (`stid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hr_log` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `money` decimal(10,2) NOT NULL,
 `info` text NOT NULL,
 `order_id` varchar(80) NOT NULL,
 `type` tinyint(1) NOT NULL COMMENT '1:in 2:out',
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `crts` (`crts`)
) ENGINE=InnoDB;

ALTER TABLE `pre_xigua_hr_verify` CHANGE `zz` `zz` TEXT NOT NULL;
ALTER TABLE `pre_xigua_hr_verify` ADD INDEX(`upts`);
ALTER TABLE `pre_xigua_hr_verify` DROP INDEX ct;
ALTER TABLE `pre_xigua_hr_verify` ADD INDEX(`uid`);
ALTER TABLE `pre_xigua_hr_verify` ADD INDEX(`ct`);
SQL;
runquery($sql);


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'expirets\'', array('xigua_hr_verify'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hr_verify` ADD `expirets` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hr_verify` ADD INDEX(`expirets`);
ALTER TABLE `pre_xigua_hr_verify` ADD `payts` INT(11) NOT NULL;

SQL;
    runquery($sql);
}

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hr/discuz_plugin_xigua_hr.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hr/discuz_plugin_xigua_hr_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hr/discuz_plugin_xigua_hr_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hr/discuz_plugin_xigua_hr_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hr/discuz_plugin_xigua_hr_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hr/install.php');


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'shid\'', array('xigua_hr_verify'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hr_verify` ADD `shid` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hr_verify` ADD INDEX(`shid`);

SQL;
    runquery($sql);
}
$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'zs_type\'', array('xigua_hr_verify'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hr_verify` ADD `zs_type` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_hr_verify` ADD `zs_num` VARCHAR(200) NOT NULL;
ALTER TABLE `pre_xigua_hr_verify` ADD `zsphoto` VARCHAR(1000) NOT NULL;

SQL;
    runquery($sql);
}