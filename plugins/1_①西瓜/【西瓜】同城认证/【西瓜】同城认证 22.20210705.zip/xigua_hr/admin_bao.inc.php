<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_hr/function.php';
$st_config = $_G['cache']['plugin']['xigua_hr'];
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$pay_stats = array(
    -1 => lang_hr('paybao-1',0),
    1  => lang_hr('paybao1',0),
    2  => lang_hr('paybao2',0),
    3  => lang_hr('paybao3',0),
);

$page = max(1, intval(getgpc('page')));
$lpp   = 16;
$start_limit = ($page - 1) * $lpp;


if($uid = intval($_GET['uid'])){

    showtableheader(); /*dism _taobao _com*/
    showtitle(lang_hr('jnjl',0). ' - '.($res['ct'] == 2 ? lang_hr('qy',0)  : lang_hr('gr',0)).' ' . ($vid>0?$vid:''). "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_bao&status={$_GET[status]}&page=$page'> ".lang_hr('back',0)."</a>");

    showtablerow('class="header"',array(),array(
        lang_hb('ID', 0),
        lang_hb('user', 0),
        lang_hb('order_id', 0),
        lang_hr('fsmoney', 0),
        lang_hr('info',0),
        lang_hr('crts', 0).'/'.lang_hr('upts', 0),
    ));

    $res = C::t('#xigua_hr#xigua_hr_log')->fetch_all_by_uid_page($uid, $start_limit, $lpp);
    $icount = C::t('#xigua_hr#xigua_hr_log')->count_by_page($uid);

    $uids = array();
    foreach ($res as $v) {
        $uids[] = $v['uid'];
    }
    if($uids){
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $uid = $v['uid'];

        $upts = $v['upts'] ? date('Y-m-d H:i:s', $v['upts']) : '';
        $crts = date('Y-m-d H:i:s', $v['crts']);
        $type = $v['type'] == 1 ? 'in' : 'out';
        $type = lang_hr($type,0);

        showtablerow('', array(), array(
            $id,
            "[uid:$uid]<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
            $v['order_id'],
            "$type&nbsp;<span style='color:orangered;font-size:18px'>&yen;{$v['money']}</span>",
            $v['info'],
            $crts.'<br><b style="color:red;font-weight:bold">'.$upts.'</b>',

        ));
    }

    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_bao&lpp=$lpp&status={$_GET[status]}&page=$page", 0, 10);
    showsubmit('permsubmit', 'submit', '', '', $multipage);
    showtablefooter(); /*dism-taobao-com*/
}else{
    if(submitcheck('editixianid')){
        $uid = intval($_GET['editixianid']);
        $size = floatval($_GET['size']);
        $note = $_GET['note'];

        DB::update('xigua_hr_paybao', array('status' => 3, 'upts' => TIMESTAMP, 'note' => $note), array('uid' => $uid));
        C::t('#xigua_hr#xigua_hr_log')->insert(array(
            'uid' => $uid,
            'order_id' => '',
            'crts' => TIMESTAMP,
            'money' => $size,
            'type' => '2',
            'info' => $note,
        ));

        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($uid, 'money', $size);
        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
            'uid'  => $uid,
            'crts' => TIMESTAMP,
            'size' => $size,
            'note' => $note,
            'link' => "$SCRITPTNAME?id=xigua_hb&ac=member&uid={$uid}",
        ));


        $url = $_G['siteurl'].'plugin.php?id=xigua_hb&ac=qianbao&mobile=2';
        notification_add($uid,'system', lang_hr('pabao_shen_success', 0),array('url' => $url, 'note' => $note),1);

        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_bao", 'succeed');
    }
    if(submitcheck('permsubmit')){
        if($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_hr#xigua_hr_paybao')->deletes($delete);
        }
        foreach ($_GET['note'] as $index => $item) {
            C::t('#xigua_hr#xigua_hr_paybao')->update($index, array('note' => $_GET['note'][$index] ));
        }

        if($n = $_GET['n']){
            foreach ($n['uid'] as $index => $uid) {
                $uid = intval($uid);
                if($uid<1){
                    continue;
                }
                $data = array(
                    'uid'      => $uid,
                    'crts'     => TIMESTAMP,
                    'upts'     => TIMESTAMP,
                    'status'   => 1,
                    'price' => $n['price'][$index]
                );
                C::t('#xigua_hr#xigua_hr_paybao')->insert($data);
            }
        }

        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_bao", 'succeed');
    }

    $wherearr = array();
    if($keyword = stripsearchkey($_GET['keyword'])){
        $wherearr[] = " (uid='$keyword' ) ";
    }
    if($_GET['status']){
        $wherearr[] = "status='".intval($_GET['status'])."'";
    }

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_bao");
    echo '<div><input type="text" id="keyword" name="keyword" placeholder="UID" value="'.$_GET['keyword'].'" class="txt" /> ';

    $chk0 = !$_GET['status'] ? 'checked':'';
    echo " <label><input type=\"radio\" name=\"status\" value=\"0\" $chk0>".lang_hr('bxzt',0)."</label>";
    foreach ($pay_stats as $index => $pay_stat) {
        $chk2 = $_GET['status']==$index ? 'checked':'';
        echo " <label><input type=\"radio\" name=\"status\" value=\"$index\" $chk2>".$pay_stat."</label>";
    }
    echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
    echo '</div>';

    showtableheader(lang_hr('tichengmanage', 0));
    showtablerow('class="header"',array(),array(
        lang_hb('del', 0),
        lang_hb('ID', 0),
        lang_hb('user', 0),
        lang_hb('order_id', 0),
        lang_hr('money', 0),
        lang_hr('status', 0).'/'.lang_hr('note',0),
        lang_hr('crts', 0).'/'.lang_hr('upts', 0),
    ));

    $res = C::t('#xigua_hr#xigua_hr_paybao')->fetch_all_by_page($start_limit, $lpp, $wherearr);
    $icount = C::t('#xigua_hr#xigua_hr_paybao')->fetch_count_by_page($wherearr);

    $uids = array();
    foreach ($res as $v) {
        $uids[] = $v['uid'];
    }
    if($uids){
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $uid = $v['uid'];

        $upts = date('Y-m-d H:i:s', $v['upts']);
        $crts = date('Y-m-d H:i:s', $v['crts']);
        $href = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_bao&uid=$uid";

        $backbtn = $v['status']==2 ? '<a href="javascript:;" onclick="return _show_profile(\''.$uid.'\',\''.$users[$uid]['username'].'\''.',\''.$v['price'].'\');">'.lang_hr('out',0).'</a>':'';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
            $id,
            "[uid:$uid]<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
            $v['order_id'],
            "<span style='color:orangered;font-size:18px'>&yen;{$v['price']}</span>&nbsp;<a href='$href'>".lang_hr('jnjl',0)."</a>",

            " <br> <textarea name='note[$id]'>{$v['note']}</textarea>".'<br><b style="color:red">'.$pay_stats[$v['status']]."</b> $backbtn <br>",

            $crts.'<br><b style="color:red;font-weight:bold">'.$upts.'</b>',

        ));
    }
?>

    <tr>
        <td>&nbsp;</td>
        <td colspan="99"><div>
                <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hr('new')?></a>
            </div></td>
    </tr>
    <?php
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_bao&lpp=$lpp&status={$_GET[status]}&page=$page", 0, 10);
    showsubmit('permsubmit', 'submit', 'del', '', $multipage);
    showtablefooter(); /*dism-taobao-com*/
    showformfooter(); /*dism��taobao��com*/
    ?>
    <script>
        function _show_profile(id,s, size) {
            showMenu({'ctrlid': 'rsel', 'evt': 'click', 'duration': 3, 'pos': '00'});
            $('cancel').value = 0;
            $('txid').value = id;
            $('size').value = size;
            $('cnotr').innerHTML = s;
        }
    </script>

    <div id="rsel_menu" class="custom cmain" style="display:none;width:400px;height:200px">
        <div class="cnote" style="width:100%">
            <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
            <h3><?php lang_hr('type_2');?> <span id="cnotr"></span></h3>
        </div>
        <div id="rsel_content" style="overflow-y:auto;height:95%">
            <?php
            showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_bao&backbao=1");
            ?>
            <table class="tb tb2 ">
                <tr>
                    <td style="width:50px" align="left"><?php lang_hr('outmoney'); ?></td>
                    <td><input name="size" id="size" class="txt" value="" /></td>
                </tr>
                <tr class="hover">
                    <td align="left"><?php lang_hr('info'); ?></td>
                    <td><textarea name="note" cols="40" rows="3"><?php lang_hr('dfttip'); ?></textarea></td>
                </tr>
                <tr>
                    <td>&nbsp;</td>
                    <td>
                        <input type="hidden" name="cancel" id="cancel" value="0">
                        <input type="hidden" name="editixianid" id="txid" value="0">
                        <input type="submit" class="btn" name="editsubmit" value="<?php lang_hb('tijiao');?>" />
                        <span id="show1"><?php lang_hr('tijiaotip');?> </span>
                    </td>
                </tr>
            </table>
            <?php showformfooter(); /*dism��taobao��com*/?>
        </div>
    </div>
    <?php
}
?>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script>
    var rowtypedata = [
        [
            [1, ''],
            [3, '<input name="n[uid][]" placeholder="UID" size="15" type="text" class="txt" />'],
            [99, '<input name="n[price][]" placeholder="0.00" size="40" type="text" class="txt" />']
        ]
    ];
</script>
