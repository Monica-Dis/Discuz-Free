<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function lang_hr($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hr', $lang);
    }else{
        return lang('plugin/xigua_hr', $lang);
    }
}

function hr_is_idcard($vStr){
    $vCity = array(
        '11','12','13','14','15','21','22',
        '23','31','32','33','34','35','36',
        '37','41','42','43','44','45','46',
        '50','51','52','53','54','61','62',
        '63','64','65','71','81','82','91'
    );
    if (!preg_match('/^([\d]{17}[xX\d]|[\d]{15})$/', $vStr)){
        return false;
    }
    if (!in_array(substr($vStr, 0, 2), $vCity)) {
        return false;
    }
    $vStr = preg_replace('/[xX]$/i', 'a', $vStr);
    $vLength = strlen($vStr);
    if ($vLength == 18) {
        $vBirthday = substr($vStr, 6, 4) . '-' . substr($vStr, 10, 2) . '-' . substr($vStr, 12, 2);
    } else {
        $vBirthday = '19' . substr($vStr, 6, 2) . '-' . substr($vStr, 8, 2) . '-' . substr($vStr, 10, 2);
    }
    if (date('Y-m-d', strtotime($vBirthday)) != $vBirthday){
        return false;
    }
    if ($vLength == 18) {
        $vSum = 0;
        for ($i = 17 ; $i >= 0 ; $i--) {
            $vSubStr = substr($vStr, 17 - $i, 1);
            $vSum += (pow(2, $i) % 11) * (($vSubStr == 'a') ? 10 : intval($vSubStr , 11));
        }
        if($vSum % 11 != 1) {
            return false;
        }
    }
    return true;
}

function hr_paybao_finish($param){
    global $_G;
    $hr_config = $_G['cache']['plugin']['xigua_hr'];
    $info = $param['info'];
    $bao = $info['data'];
    C::t('#xigua_hr#xigua_hr_paybao')->update($bao['id'], array('order_id' => $param['order_id'], 'status' => 1, 'payts' => TIMESTAMP));
    C::t('#xigua_hr#xigua_hr_log')->insert(array(
        'uid' => $bao['uid'],
        'order_id' => $param['order_id'],
        'crts' => TIMESTAMP,
        'money' => $bao['price'],
        'type' => '1',
        'info' => '',
    ));

    $user = getuserbyuid($bao['uid']);
    global $adminids, $SCRITPTNAME, $_G;
    if($adminids){
        foreach ($adminids as $adminid) {
            notification_add($adminid,'system', lang_hr('paybao_success', 0),array('user'=>$user['username'], 'money' => $bao['price']),1);
        }
    }

    return true;
}


function hr_parese_price(){
    global $_G;
    $hr_config = $_G['cache']['plugin']['xigua_hr'];
    $bao_prices = array();
    foreach (explode("\n", trim($hr_config['bsize'])) as $item) {
        list($tmp_price, $tmp_type, $tmp_icon) = explode('=', trim($item));
        $bao_prices[] = array(
            'type'  => trim($tmp_type),
            'price' => trim($tmp_price),
            'icon' => trim($tmp_icon),
        );
    }
    return $bao_prices;
}

$status_text = array(
    '0' => lang_hr('status0',0),
    '1' => lang_hr('status1',0),
    '2' => lang_hr('status2',0),
    '3' => lang_hr('status3',0),
);