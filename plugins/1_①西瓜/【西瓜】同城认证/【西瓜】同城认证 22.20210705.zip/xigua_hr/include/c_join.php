<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
$lastrealname = $user['realname'];
$lastmobile   = $user['mobile'];
$ct = intval($_GET['ct']);
$backto = str_replace('&amp;', '&', $_GET['backto']);
if(!$backto){
    $backto = "$SCRITPTNAME?id=xigua_hr&ac=my$urlext";
}
function _hr_days_format($days) {
    $return= lang_hr('zs',0).' '.intval($days).lang_hr('ri', 0);
    if($days >= 365) {
        $return= lang_hr('zs',0).' '.intval($days/365).lang_hr('nian', 0);
    } elseif($days >= 30) {
        $return= lang_hr('zs',0).' '.intval($days/30).lang_hr('yue1', 0);
    } elseif($days >= 1) {
        $return= lang_hr('zs',0).' '.intval($days).lang_hr('ri', 0);
    }else{
        $return= '';
    }
    if($days == '9999'){
        $return = lang_hr('yongjiu', '0').lang_hr('zs',0);
    }
    return $return;
}

if(!$_G['cache']['plugin']){
    loadcache('plugin');
}
$hr_config = $_G['cache']['plugin']['xigua_hr'];
$pricelist = array();
foreach (array_filter(explode("\n", $hr_config['rzfy'])) as $index => $item) {
    list($_type, $_time, $_price, $_note) = explode('|', trim($item));
    if($_type==lang('plugin/xigua_hr', 'qy')){
        $pricelist[2][] = array($_type, $_time, floatval($_price), $_note);
    }elseif($_type==lang('plugin/xigua_hr', 'zyzg')){
        $pricelist[3][] = array($_type, $_time, floatval($_price), $_note);
    }else{
        $pricelist[1][] = array($_type, $_time, floatval($_price), $_note);
    }
}
$nowpricelist = $pricelist[$ct];

if(submitcheck('formhash')){
    $form = $_GET['form'];
    $data = array();
    $repri_info = $nowpricelist[intval($_GET['rztype'])];
    if($repri_info){
        $data['expirets'] = -1;
        if($repri_info[2]>0){
            $data['payts'] = -1;
        }else{
            $data['expirets'] = TIMESTAMP+$repri_info[1]*86400;
        }
    }

    if($ct == 2){
        $data['zz'] ='';
        if($form['zz']){
            if(!is_array($form['zz'])){
                $form['zz'] = array($form['zz']);
            }
            $data['zz'] = serialize($form['zz']);
        }
        $data['company_name'] = $form['company_name'];
        $data['company_type'] = $form['company_type'];
        $data['company_num'] = $form['company_num'];
        $data['mobile'] = $form['mobile'];
        foreach ($data as $index => $datum) {
            if(!trim($datum)){
                hb_message(lang_hr($index.'_err', 0), 'error');
            }
        }
        if(!preg_match($isMob, $data['mobile']) && !preg_match($isTel, $data['mobile'])){
            hb_message(lang_hb('dianhua2',0), 'error');
        }
        $data['shid'] = $_GET['shid'];
        $data['upts'] = TIMESTAMP;
        $data['ct']  = 2;
        $data['status']  = 2;

        if($_GET['old_id']){
            $old_data = C::t('#xigua_hr#xigua_hr_verify')->fetch_verify_by_uid($_G['uid'], $data['ct']);
            if($old_data['lock']){
                hb_message(lang_hr('lock_error',0), 'error');
            }
            if($old_data['uid']!=$_G['uid'] && !IS_ADMINID){
                hb_message('not allow', 'error');
            }
            $r = C::t('#xigua_hr#xigua_hr_verify')->update($old_data['id'], $data);
            if($r){
//                C::t('#xigua_hb#xigua_hb_user')->update($_G['uid'], array('mobile' => $data['mobile']));
                hb_message(lang_hr('tjcg', 0), 'success', $backto);
            }
        }else{
            $data['crts'] = TIMESTAMP;
            $data['uid'] = $_G['uid'];
            $r = C::t('#xigua_hr#xigua_hr_verify')->insert($data);
            if($repri_info[2]>0){
                $_GET['rl'] = $_G['siteurl']."$SCRITPTNAME?id=xigua_hr&ac=my$urlext";
                $title = $repri_info[0].$repri_info[3].$repri_info[1].'_'.lang('plugin/xigua_hr', 'ri').'_'.$repri_info[2].lang('plugin/xigua_hr', 'yuan');
                $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $repri_info[2], $title, 'common_hrjoin', array(
                    'data' => array('uid' => $_G['uid'],'price' => $repri_info[2],'repinfo' => $repri_info,),
                    'callback' => array('file' => 'source/plugin/xigua_hr/function_callback.php', 'method' => 'hr_join_pay'),
                    'location' => $_GET['rl'],
                ));
                $rl = urlencode($_GET['rl']);
                $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
                hb_message(lang_hb('tiaozhuan',0), 'success', $jumpurl);
            }
            if($r){
                global $adminids, $SCRITPTNAME, $_G;
                if($adminids){
                    foreach ($adminids as $adminid) {
                        notification_add($adminid,'system', lang_hr('notice_shen', 0),array('ct' =>($ct==2?lang_hr('qy',0):lang_hr('gr',0)), 'user'=>$_G['username']),1);
                    }
                }
//                C::t('#xigua_hb#xigua_hb_user')->update($_G['uid'], array('mobile' => $data['mobile']));
                hb_message(lang_hr('tjcg', 0), 'success', $backto);
            }
        }
    }elseif($ct==3){
        $data['realname'] = $form['realname'];
        $data['idcard'] = $form['idcard'];
        $data['mobile'] = $form['mobile'];
        $data['zs_num'] = $form['zs_num'];
        $data['zs_type'] = $form['zs_type'];
        $data['zm'] = $form['zm'][0];
        $data['fm'] = $form['fm'][0];
        $data['zsphoto'] = $form['zsphoto'][0];
        foreach ($data as $index => $datum) {
            if(!trim($datum)){
                hb_message(lang_hr($index.'_err', 0), 'error');
            }
            if($index=='mobile'){
                if(!preg_match($isMob, $data['mobile']) && !preg_match($isTel, $data['mobile'])){
                    hb_message(lang_hb('dianhua2',0), 'error');
                }
            }else if($index=='idcard'){
                if(!hr_is_idcard($data['idcard'])){
                    hb_message(lang_hr('idcard_error',0), 'error');
                }
            }
        }
        $data['upts'] = TIMESTAMP;
        $data['ct']  = 3;
        $data['status']  = 2;

        if($_GET['old_id']){
            $old_data = C::t('#xigua_hr#xigua_hr_verify')->fetch_verify_by_uid($_G['uid'], $data['ct']);
            if($old_data['lock']){
                hb_message(lang_hr('lock_error',0), 'error');
            }
            if($old_data['uid']!=$_G['uid'] && !IS_ADMINID){
                hb_message('not allow', 'error');
            }
            $r = C::t('#xigua_hr#xigua_hr_verify')->update($old_data['id'], $data);
        }else{
            $data['crts'] = TIMESTAMP;
            $data['uid'] = $_G['uid'];
            $r = C::t('#xigua_hr#xigua_hr_verify')->insert($data);
            if($repri_info[2]>0){
                $_GET['rl'] = $_G['siteurl']."$SCRITPTNAME?id=xigua_hr&ac=my$urlext";
                $title = $repri_info[0].$repri_info[3].$repri_info[1].'_'.lang('plugin/xigua_hr', 'ri').'_'.$repri_info[2].lang('plugin/xigua_hr', 'yuan');
                $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $repri_info[2], $title, 'common_hrjoin', array(
                    'data' => array('uid' => $_G['uid'],'price' => $repri_info[2],'repinfo' => $repri_info,),
                    'callback' => array('file' => 'source/plugin/xigua_hr/function_callback.php', 'method' => 'hr_join_pay'),
                    'location' => $_GET['rl'],
                ));
                $rl = urlencode($_GET['rl']);
                $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
                hb_message(lang_hb('tiaozhuan',0), 'success', $jumpurl);
            }
        }
        if($r){
            global $adminids, $SCRITPTNAME, $_G;
            if($ct==1){
                $ctmp = lang_hr('gr',0);
            }elseif ($ct==2){
                $ctmp = lang_hr('qy',0);
            }elseif ($ct==3){
                $ctmp = lang_hr('zyzg',0);
            }
            if($adminids){
                foreach ($adminids as $adminid) {
                    notification_add($adminid,'system', lang_hr('notice_shen', 0),array('ct' => $ctmp, 'user'=>$_G['username']),1);
                }
            }
            hb_message(lang_hr('tjcg', 0), 'success', $backto);
        }
    }else{
        $data['realname'] = $form['realname'];
        $data['idcard'] = $form['idcard'];
        /*$data['mobile'] = $form['mobile'];*/
        if(!$hr_config['appcode']){
            $data['zm'] = $form['zm'][0];
            $data['fm'] = $form['fm'][0];
            foreach ($data as $index => $datum) {
                if(!trim($datum)){
                    hb_message(lang_hr($index.'_err', 0), 'error');
                }
            }
        }
        /*if(!preg_match($isMob, $data['mobile']) && !preg_match($isTel, $data['mobile'])){
            hb_message(lang_hb('dianhua2',0), 'error');
        }*/
        if(!hr_is_idcard($data['idcard'])){
            hb_message(lang_hr('idcard_error',0), 'error');
        }

        $data['verinfo'] = $form['verinfo'];
        $data['upts'] = TIMESTAMP;
        $data['ct']  = 1;
        $data['status']  = 2;
        if($hr_config['appcode']){
            $name_ = urlencode(diconv($data['realname'], CHARSET, 'utf-8'));
            $idcard_ = urlencode(diconv($data['idcard'], CHARSET, 'utf-8'));
            $appcode = $hr_config['appcode'];
            $host = "https://idcardv2.shumaidata.com";
            $path = "/new-idcard";
            $method = "GET";
            $headers = array();
            array_push($headers, "Authorization:APPCODE " . $appcode);
            $querys = "idcard=$idcard_&name=".$name_;
            $bodys = "";
            $url = $host . $path . "?" . $querys;
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_CUSTOMREQUEST, $method);
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($curl, CURLOPT_FAILONERROR, false);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($curl, CURLOPT_HEADER, false);
            if (1 == strpos("$".$host, "https://")){
                curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
            }
            $ret_ = curl_exec($curl);
            $ret_ = json_decode($ret_, 1);
            if($ret_['code']==200){
                if($ret_['success'] && $ret_['data']['result']===0){
                    $data['status'] = 1;
                }else{
                    hb_message(lang_hr('btg', 0), 'error');
                }
            }else{
                $msg_ = diconv($ret_['msg'], 'UTF-8', CHARSET);
                hb_message(lang_hr('ercode_'.$ret_['code'], 0).':'.$msg_, 'error');
            }
        }
        if($_GET['old_id']){
            $old_data = C::t('#xigua_hr#xigua_hr_verify')->fetch_verify_by_uid($_G['uid'], $data['ct']);
            if($old_data['lock']){
                hb_message(lang_hr('lock_error',0), 'error');
            }
            if($old_data['uid']!=$_G['uid'] && !IS_ADMINID){
                hb_message('not allow', 'error');
            }
            $r = C::t('#xigua_hr#xigua_hr_verify')->update($old_data['id'], $data);
        }else{
            $data['crts'] = TIMESTAMP;
            $data['uid'] = $_G['uid'];
            $r = C::t('#xigua_hr#xigua_hr_verify')->insert($data);
            if($repri_info[2]>0){
                $_GET['rl'] = $_G['siteurl']."$SCRITPTNAME?id=xigua_hr&ac=my$urlext";
                $title = $repri_info[0].$repri_info[3].$repri_info[1].'_'.lang('plugin/xigua_hr', 'ri').'_'.$repri_info[2].lang('plugin/xigua_hr', 'yuan');
                $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $repri_info[2], $title, 'common_hrjoin', array(
                    'data' => array('uid' => $_G['uid'],'price' => $repri_info[2],'repinfo' => $repri_info,),
                    'callback' => array('file' => 'source/plugin/xigua_hr/function_callback.php', 'method' => 'hr_join_pay'),
                    'location' => $_GET['rl'],
                ));
                $rl = urlencode($_GET['rl']);
                $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
                hb_message(lang_hb('tiaozhuan',0), 'success', $jumpurl);
            }
        }
        if($r){
            global $adminids, $SCRITPTNAME, $_G;
            if($data['status']==1){
                hb_message(lang_hr('rztg', 0), 'success', $backto);
            }
            if($adminids){
                foreach ($adminids as $adminid) {
                    notification_add($adminid,'system', lang_hr('notice_shen', 0),array('ct' =>($ct==2?lang_hr('qy',0):lang_hr('gr',0)), 'user'=>$_G['username']),1);
                }
            }
//            C::t('#xigua_hb#xigua_hb_user')->update($_G['uid'], array('mobile' => $data['mobile']));
            hb_message(lang_hr('tjcg', 0), 'success', $backto);
        }
    }
}else{
    switch ($ct) {
        case '2':
            $_GET['shid'] = intval($_GET['shid']);
            $old_data = C::t('#xigua_hr#xigua_hr_verify')->fetch_verify_by_shid($_G['uid'], $_GET['shid']);
            if($_G['cache']['plugin']['xigua_hs']) {
                if($hr_config['qy_musthr2']){
                    $needupdate = 1;
                }
                if (!$_GET['shid']) {
                }else{
                    $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($_GET['shid']);
                    if($hr_config['qy_musthr2'] && $sh['viptype']){
                        $noteallow = explode("\n", trim($hr_config['qy_musthr2']));
                        $vipinfo = C::t('#xigua_hs#xigua_hs_vip')->fetch($sh['viptype']);
                        if(!in_array($vipinfo['name'], $noteallow)){
                            $needupdate = 0;
                        }
                        $allows = array();
                        $vips = C::t('#xigua_hs#xigua_hs_vip')->fetch_all_by_page(0 , 99, 'id');
                        foreach ($vips as $index => $vip) {
                            if(!in_array($vip['name'], $noteallow)){
                                $allows[] = $vip['name'];
                            }
                        }
                        $allows = implode(',', $allows);
                    }
                }
            }
            $navtitle = lang_hr('qy',0);
            break;
        case '3':
            $old_data = C::t('#xigua_hr#xigua_hr_verify')->fetch_verify_by_uid($_G['uid'], 3);
            $navtitle = lang_hr('zyzg', 0);
            break;
        default:
            $old_data = C::t('#xigua_hr#xigua_hr_verify')->fetch_verify_by_uid($_G['uid'], 1);
            $navtitle = lang_hr('gr', 0);
            break;
    }
}