<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_hr:header}-->
<div class="page__bd cl">
    <!--{template xigua_hb:common_nav}-->
    <div class="hr_card_w cl">
        <div class="hr_card" onclick="hb_jump('$SCRITPTNAME?id=xigua_hr&mobile=2&ac=join&ct=1{$urlext}')">
            <!--{if $_G[cache][plugin][xigua_hr][grtb]}--><img class="jointy" src="$_G[cache][plugin][xigua_hr][grtb]" /> <!--{else}--><i class="iconfont icon-erified color-forest"></i><!--{/if}-->
            <p class="card_t">{lang xigua_hr:gr}</p>
            <p class="bred_w"><a class="bred <!--{if $data1[status]==1}-->finish<!--{/if}-->">{eval $status_1 = explode(' ', $data1[status_text]);echo $status_1[0];}</a></p>
        </div>
        <div class="hr_card" <!--{if $_G[cache][plugin][xigua_hs] && $sh}-->id="choose_sh"<!--{else}-->onclick="hb_jump('$SCRITPTNAME?id=xigua_hr&mobile=2&ac=join&ct=2{$urlext}')"<!--{/if}-->>
            <!--{if $_G[cache][plugin][xigua_hr][qytb]}--><img class="jointy" src="$_G[cache][plugin][xigua_hr][qytb]" /> <!--{else}--><i class="iconfont icon-qiyerenzheng color-dropbox"></i><!--{/if}-->
            <p class="card_t">{lang xigua_hr:qy}</p>
            <p class="bred_w"><a class="bred finish">{lang xigua_hr:ckxq}</a></p>
        </div>
        <div class="hr_card" onclick="hb_jump('$SCRITPTNAME?id=xigua_hr&mobile=2&ac=paybao{$urlext}')">
            <!--{if $_G[cache][plugin][xigua_hr][bzjtb]}--><img class="jointy" src="$_G[cache][plugin][xigua_hr][bzjtb]" /> <!--{else}--><i class="iconfont icon-baozhengjinmoshi color-red2"></i><!--{/if}-->
            <p class="card_t">{lang xigua_hr:cxbzj}</p>
            <p class="bred_w"><a class="bred <!--{if $bao}-->finish<!--{/if}-->"><!--{if $bao}-->{lang xigua_hr:yjn}<!--{else}-->{lang xigua_hr:wjn}<!--{/if}--></a></p>
        </div>
        <div class="hr_card" onclick="hb_jump('$SCRITPTNAME?id=xigua_hr&mobile=2&ac=join&ct=3{$urlext}')">
           <i class="iconfont icon-mingpian2 color-forest"></i>
            <p class="card_t">{lang xigua_hr:zyzg}</p>
            <p class="bred_w"><a class="bred <!--{if $data3[status]==1}-->finish<!--{/if}-->">{eval $status_3 = explode(' ', $data3[status_text]);echo $status_3[0];}</a></p>
        </div>
    </div>
</div>

<div class="masker" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);display:none;z-index:1000" onclick='$("#choose_sh").select("close")'></div>
<!--{eval $tabbar=1;}-->
<!--{template xigua_hr:footer}-->
<script>
$(document).on('click','#choose_sh', function () {
    var act = [], surl = '';
    <!--{loop $sh $_sh}-->
    surl = '$SCRITPTNAME?id=xigua_hr&mobile=2&ac=join&ct=2&shid={$_sh[shid]}'+_URLEXT;
    act.push({text: '<a class="sel_a" href="'+surl+'">{$_sh[name]}</a>'});
    <!--{/loop}-->
    $.actions({title: '{lang xigua_hr:qxzguanlian}',actions: act});
    return false;
});
</script>