<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_hb:common_header}-->
<link href="source/plugin/xigua_hr/static/css/hr.css?{VERHASH}" rel="stylesheet" />
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="mt0 main_bg hh_my_head">
        <i class="header-annimate-element1 element"></i>
        <i class="header-annimate-element4 element"></i>
        <i class="header-annimate-element5 element"></i>
        <i class="header-annimate-element6 element"></i>
        <i class="header-annimate-element7 element"></i>
        <i class="header-annimate-element8 element"></i>
        <i class="header-annimate-element9 element"></i>

        <div class="hh_my_head_in">
            <div class="main_yen">
                <span><em class="f14">&yen;&nbsp;</em><em id="njum1">{$today_sum}</em></span>
                <!--{if $hasjiao}--><em class="f12"> <i class="iconfont icon-dongjie f12"></i> {lang xigua_hr:paybao1} </em>
                <!--{else}-->
                <em class="f12"> {lang xigua_hr:wjn}{lang xigua_hr:cxbzj} </em>
                <!--{/if}-->
            </div>
        </div>
    </div>

    <!--{if $hasjiao}-->
    <div class="weui-cells border_none">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hr&ac=baolog$urlext">
            <div class="weui-cell__hd"><i class="iconfont icon-baozhengjinmoshi color-good f18"></i></div>
            <div class="weui-cell__bd">
                <p>{lang xigua_hr:paybao1}</p>
            </div>
            <div class="weui-cell__ft">{$hasjiao[crts_u]}</div>
        </a>
    </div>
    <!--{/if}-->

    <article class="weui-article" style="background:transparent">
        <section>
            <section>
                <h3><i class="iconfont icon-guize main_color"></i> {lang xigua_hr:bzssm}</h3>
                <p class="f14 c8">
                    {$hr_config['helpbzj']}
                </p>
            </section>
            <section>
                <h3><i class="iconfont icon-guize main_color"></i> {lang xigua_hr:jnhc}</h3>
                <p class="f14 c8">
                    {$hr_config['helphc']}
                </p>
            </section>
            <section>
                <h3><i class="iconfont icon-guize main_color"></i> {lang xigua_hr:rhth}</h3>
                <p class="f14 c8">
                    {$hr_config['helpth']}
                </p>
            </section>
        </section>
    </article>

    <div class="bottom_fix"></div>
    <!--{if $hr_config['allowzjbzj']}-->
    <div class="bottom_fix"></div>
    <div class="bottom_fix"></div><!--{/if}-->
    <div class="fix-bottom">
        <!--{if $hasjiao}-->
            <!--{if $hasjiao[cantui]}-->
        <!--{if $hr_config['allowzjbzj']}-->
                <a class="weui-btn weui-btn_primary" id="dosubmit" >{lang xigua_hr:zjbzj}</a>
        <!--{/if}-->
                <a class="weui-btn weui-btn_default" id="doback">{lang xigua_hr:sqth}</a>
            <!--{elseif $hasjiao[status]==2}-->
                <a class="weui-btn weui-btn_default weui-btn_disabled">{lang xigua_hr:paybao2}</a>
            <!--{else}-->
                <a class="weui-btn weui-btn_default weui-btn_disabled">{lang xigua_hr:sqth}</a>
            <!--{/if}-->
        <!--{else}-->
        <a class="weui-btn weui-btn_primary" id="dosubmit" >{lang xigua_hr:ljjn}</a>
        <!--{/if}-->
    </div>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}--><!--{if $hasjiao[cantui]}-->
<script>
$(document).on('click','#doback', function () {
    var that = $(this);
    $.prompt('{lang xigua_hr:thyy}',that.html(), function(num) {
        $.showLoading();
        $.ajax({
            type: 'post',
            url: '$SCRITPTNAME?id=xigua_hr&ac=doback&inajax=1',
            data:{formhash:'{FORMHASH}', reason:num},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {
                $.hideLoading();
            }
        });
    }, function() {
    });
});
</script><!--{/if}--><script>
$(document).on('click','#dosubmit', function () {
    $.actions({
        title: '{lang xigua_hr:plzbzj}',
        actions: [
            <!--{loop $hr_price $KK $item}-->{
                text: "{$item[type]} <span class='main_color'>{$item[price]}{lang xigua_hb:yuan}</span>", onClick: function () {
                    $.showLoading();
                    $.ajax({
                        type: 'post',
                        url: '$SCRITPTNAME?id=xigua_hr&ac=dopay&paytype=$KK&inajax=1',
                        data:{formhash:'{FORMHASH}'},
                        dataType: 'xml',
                        success: function (data) {
                            $.hideLoading();
                            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                            var s = data.lastChild.firstChild.nodeValue;
                            tip_common(s);
                        },
                        error: function () {
                            $.hideLoading();
                        }
                    });
                }
            },
            <!--{/loop}-->
        ]
    });
});
</script>