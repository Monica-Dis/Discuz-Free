<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_hr:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <form <!--{if !$old_data[lock]}-->action="$SCRITPTNAME?id=xigua_hr&ac=join&ct=$ct{$urlext}" method="post" id="form"<!--{/if}-->>
        <input type="hidden" name="formhash" value="{FORMHASH}" />
        <input type="hidden" name="old_id" value="{$old_data[id]}" />
        <input type="hidden" name="backto" value="{$backto}" />
    <div class="">
        <!--{if $ct == 2}-->
        <input type="hidden" name="shid" value="{echo $old_data[shid] ? $old_data[shid]: $_GET[shid]}" />
        <input type="hidden" name="ct" value="2" />
        <div class="weui-cells__title">{$sh[name]}{lang xigua_hr:rztip}<!--{if $old_data[status_text]}-->
            $old_data[status_text]
            <!--{/if}--></div>
        <div class="weui-cells weui-cells_form before_none after_none">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hr:ztmc}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="{lang xigua_hr:qsrztmc}" name="form[company_name]" value="{$old_data[company_name]}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hr:ztlx}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="{lang xigua_hr:company_type_err}" name="form[company_type]" value="{$old_data[company_type]}" id="picker">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hr:zzh}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="{lang xigua_hr:company_num_err}" name="form[company_num]" value="{$old_data[company_num]}" >
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_hr:dh}</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="tel" placeholder="{lang xigua_hr:qsrdh}" name="form[mobile]" value="{echo $old_data ? $old_data[mobile] : $lastmobile}">
                </div>
            </div>
        </div>

        <div class="weui-cells__title">{lang xigua_hr:zmcl} <!--{if $old_data[status_text]}-->
            $old_data[status_text]
            <!--{/if}--></div>
        <div class="weui-cells weui-cells_form before_none after_none">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_hr:zz}</p>
                            <div class="weui-uploader__info f12">{lang xigua_hr:qsrzz}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{$hr_config[max_yyzz]}">
                                <!--{loop $old_data[zz_ary] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[zz][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[zz]" type="file"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[zz]" type="file">
                                <!--{/if}-->
                            </div>
                            <!--{if $hr_config[max_yyzz]<2}-->
                            <div class="imgloading">
                                <img class="demo1" src="source/plugin/xigua_hr/static/demo3.jpg" />
                            </div>
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!--{else}-->
        <div class="weui-cells__title">{lang xigua_hr:jbxx} <!--{if $old_data[status_text]}-->
            $old_data[status_text]
            <!--{/if}--></div>
        <div class="weui-cells weui-cells_form before_none after_none">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hr:xm}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="{lang xigua_hr:qsrxm}" name="form[realname]" value="{$old_data[realname]}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hr:sfzhm}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="{lang xigua_hr:qsrsfzhm}"  name="form[idcard]" value="{$old_data[idcard]}">
                </div>
            </div>
            <!--{if $ct!=1}-->
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_hr:dh}</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="tel" placeholder="{lang xigua_hr:qsrdh}" name="form[mobile]" value="{echo $old_data ? $old_data[mobile] : $lastmobile}">
                </div>
            </div>
            <!--{/if}-->
            <!--{if $ct==1}-->
            <!--{if !$hr_config[appcode]}-->
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_hr:rzxx}</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="{lang xigua_hr:qsrzxx}" name="form[verinfo]" value="{$old_data[verinfo]}">
                </div>
            </div>
            <!--{/if}-->
            <!--{else}-->
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_hr:zs_type}</label>
                </div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="{lang xigua_hb:qtx}{lang xigua_hr:zs_type}" name="form[zs_type]" value="{$old_data[zs_type]}">
                </div>
            </div>
            <!--{/if}-->
            <!--{if $ct==3}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hr:zs_num}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" placeholder="{lang xigua_hb:qtx}{lang xigua_hr:zs_num}"  name="form[zs_num]" value="{$old_data[zs_num]}">
                </div>
            </div>
            <!--{/if}-->
        </div>
    <!--{if ($ct==1 && !$hr_config[appcode]) || $_GET[ct]!=1}-->
        <div class="weui-cells__title">{lang xigua_hr:zmcl} <!--{if $old_data[status_text]}-->
            $old_data[status_text]
            <!--{/if}--></div>
        <div class="weui-cells weui-cells_form before_none after_none">
        <!--{if !$hr_config[appcode]}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_hr:scsfz}</p>
                            <div class="weui-uploader__info f12">{lang xigua_hr:qsrscsfz}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[zm]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[zm])"><input type="hidden" name="form[zm][]" value="$old_data[zm]"/></li>
                                <!--{/if}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[zm]" type="file"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[zm]" type="file">
                                <!--{/if}-->
                            </div>
                            <div class="imgloading">
                                <img class="demo1" src="source/plugin/xigua_hr/static/demo.jpg" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_hr:sfzfm}</p>
                            <div class="weui-uploader__info f12">{lang xigua_hr:qsrsfzfm}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[fm]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[fm])"><input type="hidden" name="form[fm][]" value="$old_data[fm]"/></li>
                                <!--{/if}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[fm]" type="file"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[fm]" type="file">
                                <!--{/if}-->
                            </div>
                            <div class="imgloading">
                                <img class="demo1" src="source/plugin/xigua_hr/static/demo2.jpg" />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <!--{/if}-->
            <!--{if $_GET[ct]!=1}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_hr:zsphoto}</p>
                            <div class="weui-uploader__info f12">{lang xigua_hr:qsc}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-only="1"><!--{if $old_data[zsphoto]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[zsphoto])"><input type="hidden" name="form[zsphoto][]" value="$old_data[zsphoto]"/></li>
                                <!--{/if}-->
                            </ul>
                            <div class="weui-uploader__input-box">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[zsphoto]" type="file"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[zsphoto]" type="file">
                                <!--{/if}-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--{/if}-->
        </div>
    <!--{/if}-->
        <!--{/if}-->

<!--{if !$old_data && $nowpricelist && !$old_data[lock]}-->
<div class="weui-cells__title">{lang xigua_hr:rzyxq}</div>
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/taocan.css?{VERHASH}" />
<style>.car-type .car-year-season{background-color:$config[maincolor];}
.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}
.car-type .type-item-active:after{border-color:$config[maincolor]}
.car-type .type-item-active {background:{echo hb_hex2rgb($config[maincolor], 0.06)};}
.car-type .type-item{float: left;width: calc((100vw - 40px) / 2);margin-right: 10px;margin-top: 10px;height: 72px;}
.car-type .type-item:nth-child(2n){margin-right:0}
.car-type .type-item-box, .car-type .type-item-box-last {display:block}
.car-type{padding-top:5px}</style>
<div id="dftvip" class="cl car-type">
    <div class="type-item-box">
        <!--{loop $nowpricelist $___k $___v}-->
        <label for="s{$___k}" class="type-item J_ping <!--{if $___k==0}-->type-item-active<!--{else}-->type-item-gray<!--{/if}-->">
            <input type="radio" class="none typevip" name="rztype" value="{$___k}" id="s{$___k}" <!--{if $___k==0}-->checked="checked"<!--{/if}-->>
            <div class="type-title">{$___v[3]}</div>
            <div class="car-sku-year cl">
                <div class="type-discount">
                    <span class="car-price">{$___v[2]}</span><span class="car-unit">{lang xigua_hb:yuan} / {echo _hr_days_format($___v[1])}</span>
                </div>
            </div>
            <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
        </label>
        <!--{/loop}-->
    </div>
</div>
<!--{/if}-->

    </div>

    <div class="bottom_fix"></div>
    <div class="fix-bottom">
        <!--{if !$old_data[lock]}-->
        <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hb:tijiao}">
        <!--{else}-->
        <input type="button" class="weui-btn weui-btn_primary weui-btn_disabled" value="{$old_data[status_text]}">
        <!--{/if}-->
    </div>
    </form>
</div>

<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hr:footer}-->
<!--{template xigua_hr:enter_up}-->
<script>$("#picker").picker({
    title: "{lang xigua_hr:company_type_err}",
    cols: [{textAlign: 'center',values: ['{lang xigua_hr:ctype1}','{lang xigua_hr:ctype2}','{lang xigua_hr:ctype3}','{lang xigua_hr:ctype4}','{lang xigua_hr:ctype5}']}]
});
<!--{if $needupdate}-->
$.modal({
    title: "{lang xigua_hr:wfrz}",
    text: '{lang xigua_hr:sjd}: {$allows}',
    buttons: [
        { text: "{lang xigua_hb:quxiao}", className: "default", onClick: function(){ window.history.go(-1); } },
        { text: "{lang xigua_hb:queding}", onClick: function(){
            hb_setcookie('newshid', '{$_GET[shid]}', 7200);
            hb_jump('$SCRITPTNAME?id=xigua_hs&ac=myshop&shid={$_GET[shid]}');
        } },
    ]
});
<!--{/if}-->
$(document).on('click','.J_ping', function () {
    $('.J_ping').addClass('type-item-gray').removeClass('type-item-active');
    $(this).addClass('type-item-active').removeClass('type-item-gray');
});
$('.J_ping:first-child').trigger('click');
$('.J_ping:first-child').find('.typevip').trigger('click');
</script>