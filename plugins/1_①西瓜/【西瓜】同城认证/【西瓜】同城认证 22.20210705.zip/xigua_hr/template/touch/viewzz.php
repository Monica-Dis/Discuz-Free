<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_hr:header}-->
<div class="page__bd cl">
    <!--{template xigua_hb:common_nav}-->
    <div class="">
        <input type="hidden" name="ct" value="2" />
        <div class="weui-cells__title">{$shdata[name]}{lang xigua_hr:rztip}</div>
        <div class="weui-cells weui-cells_form">
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hr:ztmc}</label></div>
                <div class="weui-cell__bd">
                    $old_data[company_name]
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hr:ztlx}</label></div>
                <div class="weui-cell__bd">
                    {$old_data[company_type]}
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hr:zzh}</label></div>
                <div class="weui-cell__bd">
                    $old_data[company_num]
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_hr:dh}</label>
                </div>
                <div class="weui-cell__bd">
                    $old_data[mobile]
                </div>
            </div>
        </div>

        <div class="weui-cells__title">{lang xigua_hr:zmcl}</div>
        <div class="weui-cells weui-cells_form">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <p class="weui-uploader__title" style="margin-bottom: 10px;">{lang xigua_hr:zz}</p>
                    <!--{loop $old_data[zz_ary] $vv}-->
                    <img src="{$vv}" style="width:100%" class="block" />
                    <!--{/loop}-->
                </div>
            </div>
        </div>


    </div>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hr:footer}-->