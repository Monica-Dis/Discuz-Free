<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{loop $list $v}-->
<div class="weui-cell">
    <div class="weui-cell__hd" style="position: relative;margin-right: 10px;">
        <i class="iconfont icon-shouru main_color" style="font-size:30px"></i>
    </div>
    <div class="weui-cell__bd">
        <p class="f18 main_color">&yen;$v[money]</p>
        <p class="f14 c9">
            <span class="main_color">{echo lang_hr('type_'.$v[type], 0);}</span>
            &nbsp;{$v[info]}</p>
    </div>
    <div class="weui-cell__ft">
        $v[crts_u]
    </div>
</div>
<!--{/loop}-->

