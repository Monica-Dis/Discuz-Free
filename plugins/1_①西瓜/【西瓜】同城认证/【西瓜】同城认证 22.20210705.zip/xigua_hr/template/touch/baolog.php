<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_hr:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div  id="list" class="weui-cells p0 mt0 before_none"></div>
    <script>
        var loadingurl = window.location.href+'&ac=baolog_li&inajax=1&do=$do&pagesize=20&page=';
    </script>
    <!--{template xigua_hb:loading}-->
</div>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hr:footer}-->