<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��! ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hr/function.php';
$hr_config = $_G['cache']['plugin']['xigua_hr'];
$aclist = array('index','join','my','paybao','dopay','baolog','baolog_li','doback','viewzz',);
$aclist_login = array('join','my','paybao','dopay','baolog','baolog_li','doback','viewzz',);
$ac = $_GET['ac'];
$do = $_GET['do'];
if (!in_array($ac, $aclist) || !$ac) {
    $ac = 'my';
}
$isself = in_array($ac, $aclist_login) || (strpos($ac, 'my')!==false && !$_G['uid']);
if ($isself && !$_G['uid']) {
    hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval(getgpc('page')));
$lpp   = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;

switch ($ac){
    case 'viewzz':
        $uid = intval($_GET['uid']);
        $shid = intval($_GET['shid']);
        $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_all_by_page(0, 1, array("shid=$shid AND ct=2"));
        $old_data = $veris2[0];
        $shdata = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($shid);
        $navtitle = $desc = $shdata['name'];
        break;
    case 'index':
        break;
    case 'baolog_li':
        $uid = intval($_G['uid']);
        $list = C::t('#xigua_hr#xigua_hr_log')->fetch_all_by_uid_page($uid, $start_limit, $lpp);
        include template('xigua_hb:header_ajax');
        include template('xigua_hr:baolog_li');
        include template('xigua_hb:footer_ajax');
        break;
    case 'baolog':
        $navtitle = lang_hr('jnjl',0);
        break;
    case 'doback':
        if(!$_GET['reason']){
            hb_message(lang_hr('thyy',0), 'error');
        }
        $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetch_by_uid_status($_G['uid'], 1);
        $logid = C::t('#xigua_hr#xigua_hr_log')->insert(array(
            'uid' => $_G['uid'],
            'order_id' => '',
            'crts' => TIMESTAMP,
            'money' => $bao['price'],
            'type' => '2',
            'info' => $_GET['reason'],
        ), 1);
        DB::update('xigua_hr_paybao', array('status' => 2, 'note' => $logid, 'upts' => TIMESTAMP), array('uid' => $_G['uid']));

        global $adminids, $SCRITPTNAME, $_G;
        if($adminids){
            foreach ($adminids as $adminid) {
                notification_add($adminid,'system', lang_hr('paybao_shen', 0),array('user'=>$_G['username']),1);
            }
        }

        hb_message(lang_hr('sqcg',0), 'success', 'reload');
        break;
    case 'dopay':
        if(submitcheck('formhash')) {
            $hr_price = hr_parese_price();
            $bsize = $hr_price[intval($_GET['paytype'])];
            if(!$bsize){
                hb_message(lang_hr('submiterr', 0));
            }

            $data = array(
                'uid' => $_G['uid'],
                'crts' => TIMESTAMP,
                'upts' => TIMESTAMP,
                'status' => -1,
                'order_id' => '',
                'price' => $bsize['price'],
                'stid' => $_GET['st'],
            );
            $price = abs($bsize['price']);

            if ($price > 0) {
                if($hr_config['allowzjbzj']){
                    $firstrow = DB::fetch_first('select * from %t where uid=%d and status=1', array('xigua_hr_paybao', $_G['uid']));
                    if($firstrow['price']){
                        $data['price'] = $data['price'] + $firstrow['price'];
                    }
                }
                if (C::t('#xigua_hr#xigua_hr_paybao')->insert($data, 1, 1)) {
                    $url = "$SCRITPTNAME?id=xigua_hr&ac=paybao$urlext";
                    $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetch_by_uid($_G['uid']);
                    $data['id'] = $bao['id'];

                    $odata = $data;
                    $odata['size'] = $bsize;

                    $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price, $_G['username'].lang_hr('cxbzj',0), 'common_paybao', array(
                        'data' => $odata,
                        'callback' => array(
                            'file' => 'source/plugin/xigua_hr/function.php',
                            'method' => 'hr_paybao_finish'
                        ),
                        'location' => $_G['siteurl'] . $url,
                    ));
                    C::t('#xigua_hr#xigua_hr_paybao')->update($bao['id'], array('order_id' => $order_id));

                    $rl = urlencode($url);
                    $jumpurl = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=" . urlencode($_G['siteurl'] . "$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl".$urlext).$urlext;
                    hb_message(lang_hr('jumppay', 0), 'success', $jumpurl);
                } else {
                    hb_message(lang_hr('submiterr', 0));
                }
            }
        }
        break;
    default:
        if (is_file(DISCUZ_ROOT . "source/plugin/xigua_hr/include/c_$ac.php")) {
            include DISCUZ_ROOT . "source/plugin/xigua_hr/include/c_$ac.php";
        }
        break;
}

if($_GET['mini']=='11'){
    $navtitle = strip_tags($navtitle);
    $navtitle = $navtitle?$navtitle:$config['tname'];
    if($config['tnameshow']) {
        if ($navtitle != $config['tname']){
            $navtitle = $config['tname'] . $navtitle;
        }
    }
    ob_end_clean();
    function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
    header("Content-type: application/json; charset=utf-8");
    echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
    exit;
}

if(!checkmobile()){
    include template('xigua_hb:index');
    exit;
}
if (is_file(DISCUZ_ROOT . "source/plugin/xigua_hr/template/touch/$ac.php")) {
    include template('xigua_hr:' . $ac);
}