<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_hr/function.php';
$st_config = $_G['cache']['plugin']['xigua_hr'];
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}

$page = max(1, intval(getgpc('page')));
$lpp   = 10;
$start_limit = ($page - 1) * $lpp;

if($vid = intval($_GET['vid'])){

    $res = C::t('#xigua_hr#xigua_hr_verify')->fetch($vid);

    if($res['ct']==1){
        $ctmp = lang_hr('gr',0);
    }elseif ($res['ct']==2){
        $ctmp = lang_hr('qy',0);
    }elseif ($res['ct']==3){
        $ctmp = lang_hr('zyzg',0);
    }
    if(!submitcheck('dosubmit')) {

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_verify&vid=$vid", 'enctype');
        showtableheader(); /*dism _taobao _com*/
        showtitle(lang_hr('tichengmanage',0). ' - '.$ctmp.' ' . ($vid>0?$vid:''). "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_verify&ct={$_GET['ct']}&page=$page'> ".lang_hr('back',0)."</a>");

        foreach ($res as $index => $re) {
            if(in_array($index, array('ct' ,'id'))){
                continue;
            }
            if($res['ct']==2){
                if(in_array($index, array('realname' ,'idcard','zm','fm','verinfo', 'zs_type', 'zs_num', 'zsphoto'))){
                    continue;
                }
            }elseif($res['ct']==3){
                if(in_array($index, array('company_name' ,'company_type', 'company_num','zz','verinfo','shid'))){
                    continue;
                }
            }else{
                if(in_array($index, array('company_name' ,'company_type', 'company_num','zz', 'zs_type', 'zs_num', 'zsphoto','shid'))){
                    continue;
                }
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('crts', 'upts', 'expirets','payts'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($status_text as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('zm', 'fm', 'zsphoto'))){
                $tp = 'filetext';
                $cmt = $re ? '<a href="'.$re.'" target="_blank"><img style="height:80px;" src="'.$re.'" onerror="this.error=null;this.style.display=\'none\'" /></a>' : '';
            }

            if(in_array($index, array('zz'))){
                $re = unserialize($re);
                $tp = 'filetext';
                $loopnum = $_G['cache']['plugin']['xigua_hr']['max_yyzz'];
                for ($i = 0; $i < $loopnum; $i++) {
                    $cmt = $re[$i] ? '<a href="'.$re[$i].'" target="_blank"><img style="height:80px;" src="'.$re[$i].'" onerror="this.error=null;this.style.display=\'none\'" /></a>' : '';
                    showsetting(lang_hr($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i],$tp, '', 0, $cmt, $_extra);
                }
            }else{
                showsetting(lang_hr($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*dism-taobao-com*/
        showformfooter(); /*dism��taobao��com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['zz']){
            $editform['zz'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'zz') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        if($editform['zz']){
            $editform['zz'] = array_filter($editform['zz']);
            $editform['zz'] = serialize($editform['zz']);
        }else{
            $editform['zz'] = '';
        }
        foreach (array('crts', 'upts', 'expirets','payts') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }
        $old = C::t('#xigua_hr#xigua_hr_verify')->fetch($vid);
        $rs = C::t('#xigua_hr#xigua_hr_verify')->update($vid, $editform);

        if($editform['status'] == 3 && $old['status']!=3){
            $url = $_G['siteurl'].'plugin.php?id=xigua_hr&ac=my';
            notification_add($old['uid'],'system', lang_hr('notice_shen_error', 0),array('url' => $url,'note' => $editform['status_info']),1);
        }
        if($editform['status'] == 1 && $old['status']!=1){
            $url = $_G['siteurl'].'plugin.php?id=xigua_hr&ac=my';
            C::t('#xigua_hb#xigua_hb_user')->update($old['uid'], array('mobile' => $old['mobile']));
            notification_add($old['uid'],'system', lang_hr('notice_shen_success', 0),array('url' => $url,),1);
        }

        cpmsg(lang_hr('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_verify&vid=$vid", 'succeed');
    }
}else{

    if(submitcheck('permsubmit')){
        if($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_hr#xigua_hr_verify')->deletes($delete);
        }
        foreach ($_GET['status'] as $index => $item) {
            $old = C::t('#xigua_hr#xigua_hr_verify')->fetch($index);
            C::t('#xigua_hr#xigua_hr_verify')->update($index, array('status' => $item, 'status_info' => $_GET['status_info'][$index] ));
            if($item == 3 && $old['status']!=3){
                $url = $_G['siteurl'].'plugin.php?id=xigua_hr&ac=my';
                notification_add($old['uid'],'system', lang_hr('notice_shen_error', 0),array('url' => $url,'note' => $_GET['status_info'][$index]),1);
            }
            if($item == 1 && $old['status']!=1){
                $url = $_G['siteurl'].'plugin.php?id=xigua_hr&ac=my';
                C::t('#xigua_hb#xigua_hb_user')->update($old['uid'], array('mobile' => $old['mobile']));
                notification_add($old['uid'],'system', lang_hr('notice_shen_success', 0),array('url' => $url,),1);
            }
        }
        if($n = $_GET['n']){
            foreach ($n['uid'] as $index => $uid) {
                $uid = intval($uid);
                if($uid<1){
                    continue;
                }
                $data = array(
                    'uid'      => $uid,
                    'crts'     => TIMESTAMP,
                    'upts'     => TIMESTAMP,
                    'status'   => 1,
                    'ct' => $n['ct'][$index]
                );
                C::t('#xigua_hr#xigua_hr_verify')->insert($data);
            }
        }
        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_verify", 'succeed');
    }

    $wherearr = array();
    if($keyword = stripsearchkey($_GET['keyword'])){
        $member = C::t('common_member')->fetch_by_username($keyword);
        if($member['uid']){
            $wherearr[] = 'uid='.$member['uid'];
        }elseif(is_numeric($keyword)){
            $wherearr[] = 'uid='. intval($keyword);
        }else{
            $wherearr[] = " (uid='$keyword' or realname like '%$keyword%' OR mobile like '%$keyword%' OR idcard like '%$keyword%' or verinfo like '%$keyword%' or company_name like '%$keyword%' or company_type like '%$keyword%' or company_num like '%$keyword%') ";
        }
    }
    if($_GET['ct']){
        $wherearr[] = "ct='".intval($_GET['ct'])."'";
    }
    if(isset($_GET['selstatus']) && $_GET['selstatus']!=-1){
        $wherearr[] = "status='".intval($_GET['selstatus'])."'";
    }

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_verify");
    ?><style>
        .imgi{height:30px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
        .short{width:100px}
        .td23 input{width:80px!important;}.zlfield{display:block;margin-bottom:3px}.zlfield em{display:inline-block;color:forestgreen;margin:0px;width:100px}
    </style><?php
    echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_hr('plc', 0).'" value="'.$_GET['keyword'].'" class="txt" style="width:320px" /> ';
    $chk0 = !$_GET['ct'] ? 'checked' : '';
    $chk1 = $_GET['ct']==1 ? 'checked':'';
    $chk2 = $_GET['ct']==2 ? 'checked':'';
    $chk3 = $_GET['ct']==3 ? 'checked':'';
    echo " <label><input type=\"radio\" name=\"ct\" value=\"0\" $chk0>".lang_hr('bxlx',0)."</label>";
    echo " <label><input type=\"radio\" name=\"ct\" value=\"1\" $chk1>".lang_hr('gr',0)."</label>";
    echo " <label><input type=\"radio\" name=\"ct\" value=\"2\" $chk2>".lang_hr('qy',0)."</label>";
    echo " <label><input type=\"radio\" name=\"ct\" value=\"3\" $chk2>".lang_hr('zyzg',0)."</label>";

    $sel = '&nbsp;&nbsp;<label><select name="selstatus">';
    $sel .= "<option value=\"-1\" ".($_GET['selstatus']==-1||!isset($_GET['selstatus'])?'selected':'').">".lang_hr('qb',0)."</option>";
    foreach ($status_text as $index => $item) {
        if(isset($_GET['selstatus']) && $_GET['selstatus'] == $index){
            $sel .= "<option value=\"$index\" selected>$item</option>";
        }else{
            $sel .= "<option value=\"$index\">$item</option>";
        }
    }
    $sel .= '</select></label>';
    echo $sel;
    echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
    echo '</div>';

    showtableheader(lang_hr('tichengmanage', 0));
    showtablerow('class="header"',array(),array(
        lang_hb('del', 0),
        lang_hb('ID', 0),
        lang_hb('user', 0),
        lang_hr('rzlx', 0),
        lang_hr('rzll', 0),
        lang_hr('status', 0).'/'.lang_hr('status_info',0),
        lang_hr('crts', 0),
        lang_hr('xq', 0),
    ));

    $res = C::t('#xigua_hr#xigua_hr_verify')->fetch_all_by_page($start_limit, $lpp, $wherearr, 'upts desc');
    $icount = C::t('#xigua_hr#xigua_hr_verify')->fetch_count_by_page($wherearr);

    $uids = array();
    foreach ($res as $v) {
        $uids[] = $v['uid'];
    }
    if($uids){
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $uid = $v['uid'];
        $vzz = unserialize($v['zz']);
        if($vzz[0]){
            $v['zz'] = $vzz[0];
        }

        $upts = lang_hr('upts', 0) . ':'. date('Y-m-d H:i:s', $v['upts']);
        $crts =  lang_hr('crts', 0) . ':'. date('Y-m-d H:i:s', $v['crts']);
        $payts = $v['payts']!=0 ? (lang_hr('payts',0).':'. ($v['payts']==-1 ? lang_hr('wzf',0) : date('Y-m-d H:i:s', $v['payts']))) : '';
        $expirets = $v['expirets']==0 ? lang_hr('expirets0',0) : lang_hr('expirets',0).':'.date('Y-m-d H:i:s', $v['expirets']);

        if($v['ct']==2){
            $shinfos = '';
            if($shid = $v['shid']){
                $shinfo = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($shid);
                $href1 = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hs&pmod=admin_shanghu&keyword=".$shinfo['name'];
                $shinfos = "<a href='$href1'>{$shinfo['name']}</a> ";
            }
            $zz = '';
            foreach ($v['zz_ary'] as $i => $item) {
                $zkey = "zz".$i.'_'.$id;
                $zz .= <<<HTML
<span class="sp">
 <a href="$item" target="_blank"><img class="imgi" src="{$item}" onmouseover="$('$zkey').style.display='block'" onmouseout="$('$zkey').style.display='none'" /></a>
 <img id="$zkey" src="{$item}"  class="imgprevew" />
</span>
HTML;
            }
            $zl = '<p class="zlfield"><em>'.lang_hr('company_name',0).':</em>'.$v['company_name'].'[ ID : '.$v['shid'].' ]</p>'.
                '<p class="zlfield"><em>'.lang_hr('company_type',0).':</em>'.$v['company_type'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('company_num',0).':</em>'.$v['company_num'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('mobile',0).':</em>'.$v['mobile'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('zz',0).':</em>'.$zz.'</p>';
        }elseif($v['ct']==3){
            $zm = <<<HTML
<span class="sp">
 <a href="{$v['zm']}" target="_blank"><img class="imgi" src="{$v['zm']}" onmouseover="$('icon$id').style.display='block'" onmouseout="$('icon$id').style.display='none'" /></a>
 <img id="icon$id" src="{$v['zm']}"  class="imgprevew" />
</span>
HTML;
            $fm = <<<HTML
<span class="sp">
  <a href="{$v['fm']}" target="_blank"><img class="imgi" src="{$v['fm']}" onmouseover="$('fm$id').style.display='block'" onmouseout="$('fm$id').style.display='none'" /></a>
 <img id="fm$id" src="{$v['fm']}"  class="imgprevew" />
</span>
HTML;
            $zsphoto = <<<HTML
<span class="sp">
  <a href="{$v['zsphoto']}" target="_blank"><img class="imgi" src="{$v['zsphoto']}" onmouseover="$('zsphoto$id').style.display='block'" onmouseout="$('zsphoto$id').style.display='none'" /></a>
 <img id="zsphoto$id" src="{$v['zsphoto']}"  class="imgprevew" />
</span>
HTML;
            $zl = '<p class="zlfield"><em>'.lang_hr('realname',0).':</em>'.$v['realname'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('mobile',0).':</em>'.$v['mobile'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('idcard',0).':</em>'.$v['idcard'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('zm',0).':</em>'.$zm.'</p>'.
                '<p class="zlfield"><em>'.lang_hr('fm',0).':</em>'.$fm.'</p>'.
                '<p class="zlfield"><em>'.lang_hr('zs_type',0).':</em>'.$v['zs_type'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('zs_num',0).':</em>'.$v['zs_num'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('zsphoto',0).':</em>'.$zsphoto.'</p>';
        }else{
            $zm = <<<HTML
<span class="sp">
 <a href="{$v['zm']}" target="_blank"><img class="imgi" src="{$v['zm']}" onmouseover="$('icon$id').style.display='block'" onmouseout="$('icon$id').style.display='none'" /></a>
 <img id="icon$id" src="{$v['zm']}"  class="imgprevew" />
</span>
HTML;
            $fm = <<<HTML
<span class="sp">
  <a href="{$v['fm']}" target="_blank"><img class="imgi" src="{$v['fm']}" onmouseover="$('fm$id').style.display='block'" onmouseout="$('fm$id').style.display='none'" /></a>
 <img id="fm$id" src="{$v['fm']}"  class="imgprevew" />
</span>
HTML;
            $zl = '<p class="zlfield"><em>'.lang_hr('realname',0).':</em>'.$v['realname'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('mobile',0).':</em>'.$v['mobile'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('idcard',0).':</em>'.$v['idcard'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('verinfo',0).':</em>'.$v['verinfo'].'</p>'.
                '<p class="zlfield"><em>'.lang_hr('zm',0).':</em>'.$zm.'</p>'.
                '<p class="zlfield"><em>'.lang_hr('fm',0).':</em>'.$fm.'</p>';
        }

        $sel = '';
        foreach ($status_text as $index => $item) {
            if($v['status'] == $index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }
        $href = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_verify&vid=$id";


        if($v['ct']==1){
            $ctmp = lang_hr('gr',0);
        }elseif ($v['ct']==2){
            $ctmp = lang_hr('qy',0);
            $shid = $v['shid'];
        }elseif ($v['ct']==3){
            $ctmp = lang_hr('zyzg',0);
        }
        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
            $id,
            "<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a> [ uid : $uid ] ",
            $ctmp,
            "<div style='max-width:300px'>$zl</div>",
            "<select name='status[$id]'>$sel</select><br> <br> <textarea name='status_info[$id]'>{$v['status_info']}</textarea>",
            $crts.'<br>'.
            $upts.'<br>'.
            $payts.'<br>'.
            $expirets,
            "<a href='$href'>".lang_hr('xg',0)."</a>",

        ));
    }
    ?>

    <tr>
        <td>&nbsp;</td>
        <td colspan="99"><div>
                <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hr('new')?></a>
            </div></td>
    </tr>
    <?php

    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hr&pmod=admin_verify&lpp=$lpp&ct={$_GET[ct]}&page=$page", 0, 10);
    showsubmit('permsubmit', 'submit', 'del', '', $multipage);
    showtablefooter(); /*dism-taobao-com*/
    showformfooter(); /*dism��taobao��com*/
?>

    <script>
        var rowtypedata = [
            [
                [1, '&nbsp;'],
                [2, '<input name="n[uid][]" placeholder="UID" size="15" type="text" class="txt" />'],
                [99, '<select name="n[ct][]"><option value=1><?php lang_hr('gr')?></option><option value=2><?php lang_hr('qy')?></option><option value=3><?php lang_hr('zyzg')?></option></select>']
            ]
        ];
    </script>

    <?php
}