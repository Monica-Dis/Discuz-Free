<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class table_xigua_hr_paybao extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_hr_paybao';
        $this->_pk = 'id';


        parent::__construct(); /*dism �� taobao �� com*/
    }
    public function count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function fetch_by_uid($uid, $field = '*')
    {
        $res = DB::fetch_first("select $field from %t WHERE uid=%d ", array($this->_table, $uid));
        return $this->prepare($res);
    }

    public function fetch_by_uid_status($uid, $status = 1, $field = '*')
    {
        $res = DB::fetch_first("select $field from %t WHERE uid=%d and status = %d", array($this->_table, $uid, $status));
        return $this->prepare($res);
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public function fetch_by_type($id)
    {
        $res = parent::fetch($id);
        $res = $this->prepare($res);
        return $res;
    }

    public function prepare($info)
    {
        global $hr_config;
        if($info){
            $info['crts_u'] = dgmdate($info['crts'], 'u');
            $info['cantui'] = $info['status']==1 && $hr_config['baoback']<=TIMESTAMP-$info['crts'];
        }
        return $info;
    }

    public function do_delete($id)
    {
        return $this->delete($id);
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function fetchb($uids)
    {
        global $_G;
        $hr_config = $_G['cache']['plugin']['xigua_hr'];
        $ret = DB::fetch_all('SELECT uid,price FROM %t WHERE uid IN (%n) AND status=1', array($this->_table, $uids), 'uid');

        $icons = array();
        foreach (explode("\n", trim($hr_config['bsize'])) as $item) {
            list($tmp_price, $tmp_type, $tmp_icon) = explode('=', trim($item));
            $tmp_price = floatval($tmp_price);
            $icons[$tmp_price] = $tmp_icon;
        }

        foreach ($ret as $index => $item) {
            $key = floatval($item['price']);
            $ret[$index]['price'] = $key;
            $ret[$index]['icon'] = $icons[$key] ? $icons[$key] : $_G['cache']['plugin']['xigua_hr']['bzjtb'];
        }

        return $ret;
    }
}