<?php
/**
 * DisM!Ӧ�����ģ�dism.taobao.com
 * ������ҵ���/ģ������ ����DisM!Ӧ������
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hr_log extends discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_hr_log';
        $this->_pk = 'id';


        parent::__construct(); /*dism �� taobao �� com*/
    }

    public function fetch_all_by_uid_page($uid, $start_limit, $lpp)
    {
        $result = DB::fetch_all("SELECT * FROM %t  WHERE uid= %d ORDER BY id DESC " . DB::limit($start_limit, $lpp), array($this->_table, $uid));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = array();
        $result = DB::fetch_all("SELECT * FROM %t  ORDER BY id DESC " . DB::limit($start_limit, $lpp), array($this->_table));
        return $result;
    }

    public function count_by_page($uid)
    {
        $uid = intval($uid);
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' WHERE uid= '.$uid);
        return $result;
    }

    public function fetch_by_uid($uid, $field = '*')
    {
        $res = DB::fetch_first("select $field from %t WHERE uid=%d ", array($this->_table, $uid));
        return $this->prepare($res);
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public function fetch_by_type($id)
    {
        $res = parent::fetch($id);
        $res = $this->prepare($res);
        return $res;
    }

    public function prepare($info)
    {
        if($info){
            $info['crts_u'] = dgmdate($info['crts'], 'u');
        }
        return $info;
    }

    public function do_delete($id)
    {
        return $this->delete($id);
    }
}