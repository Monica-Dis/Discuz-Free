$(function () {
    $(document).on('click','.navbar', function () {
        var that = $(this);
        that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
        if(that.data('display')){
            $('#'+that.data('display')).show();
        }
        if(that.data('hide')){
            $('#'+that.data('hide')).hide();
        }
    });
});