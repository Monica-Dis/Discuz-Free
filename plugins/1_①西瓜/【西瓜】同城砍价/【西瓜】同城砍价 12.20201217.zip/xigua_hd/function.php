<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/12/4
 * Time: 9:39
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function lang_hd($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hd', $lang);
    }else{
        return lang('plugin/xigua_hd', $lang);
    }
}
function he_multi_diconv($string, $in_charset, $out_charset){
    if (is_array($string)) {
        foreach ($string as $key => $val) {
            $string[ $key ] = he_multi_diconv($val, $in_charset, $out_charset);
        }
    } else {
        $string = diconv($string, $in_charset, $out_charset);
    }
    return $string;
}
function he_current_location($lat, $lng){
    global $he_config;
    $url = "http://apis.map.qq.com/ws/geocoder/v1/?location=$lat,$lng&coord_type=5&get_poi=1&key=".$he_config['skey'];
    $ret = hb_curl($url);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        $rt = array();
        $rt[$ret['result']['address']] = array(
            'address'           => str_replace(array($ret['result']['address_component']['province'], $ret['result']['address_component']['city']), '', $ret['result']['address']),
            'address_component' => array(
                'province' => $ret['result']['address_component']['province'],
                'city'     => $ret['result']['address_component']['city'],
                'district' => $ret['result']['address_component']['district'],
                'street'   => $ret['result']['address_component']['street'],
                'street_number'=>$ret['result']['address_component']['street_number'],
            ),
            'location'          => $ret['result']['location'],
            'category'          => diconv(lang_hd('default', 0), CHARSET, 'utf-8'),
        );
        foreach ($ret['result']['pois'] as $index => $pois) {
            $rt[$pois['address']] = array(
                'address'           => str_replace(array($pois['ad_info']['province'], $pois['ad_info']['city']), '', $pois['address']),
                'address_component' => array(
                    'province' => $pois['ad_info']['province'],
                    'city'     => $pois['ad_info']['city'],
                    'district' => $pois['ad_info']['district'],
                    'street'   => '',
                    'street_number'=> '',
                ),
                'location'          => $pois['location'],
                'category'          => $pois['category'],
            );
        }
        $rt = array_values($rt);
        return  he_multi_diconv($rt, 'utf-8', 'utf-8');
    }else{
        return he_multi_diconv($ret['message'], 'utf-8', CHARSET);
    }
}
function hd_hex2rgb($colour, $a){
    if ($colour[0] == '#') {
        $colour = substr($colour, 1);
    }
    if (strlen($colour) == 6) {
        list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
    }
    elseif (strlen($colour) == 3) {
        list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
    }
    else {
        return false;
    }
    $r = hexdec($r);
    $g = hexdec($g);
    $b = hexdec($b);
    return "rgba($r, $g, $b, $a)";
}
function hd_nl2br($txt){
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}
function hd_red_callback($param){
    $info = $param['info'];
    $data = $info['data'];
    $jid = $data['jid'];

    include_once DISCUZ_ROOT. 'source/plugin/xigua_hb/lib/hb.class.php';
    $hblist = randBean($data['hbmoney'], $data['hbnum']);
    foreach ($hblist as $size) {
        C::t('#xigua_hb#xigua_hb_hongbaolog')->insert(array(
            'uid'  => 0,
            'pubid'=> 0,
            'shid' => 0,
            'size' => $size,
            'crts' => 0,
            'jid' => $jid,
        ));
    }
    $jv = C::t('#xigua_hd#xigua_hd_join')->fetch_by_jid($jid);
    C::t('#xigua_hd#xigua_hd_join')->update($jid, array(
        'hbnum'   => $jv['hbnum']+$data['hbnum'],
        'hbmoney'   => $jv['hbmoney']+$data['hbmoney'],
        'hbsendnum' => $jv['hbsendnum']+0,
        'hbstatus' => 1,
    ));

    return true;
}

function hd_buy_callback($param){
    global $_G;
    $info = $param['info'];
    $data = $info['data'];
    $jid = $data['jid'];

    if(!$_G['cache']['plugin']['xigua_hd']){
        loadcache('plugin');
    }
    if($_G['cache']['plugin']['xigua_hd']['jkucun'] == 2) {
        $updatestock = C::t('#xigua_hd#xigua_hd_dis')->updateStock($data['did']);
    }

    C::t('#xigua_hd#xigua_hd_join')->update($jid, array(
        'order_id' => $param['order_id'],
        'status' => 1,
        'hxcode' => hd_random_code()
    ));

    $old_data = $data['disinfo'];
    $jv = C::t('#xigua_hd#xigua_hd_join')->fetch_by_jid($jid);
    $buyer = getuserbyuid($jv['uid']);
    notification_add($old_data['uid'],'system', lang_hd('cggm',0), array(
        'url' => $_G['siteurl']."plugin.php?id=xigua_hd&ac=view&did={$data['did']}&jid=$jid",
        'u' => $buyer['username'],
        'p' => $data['price'],
        'a' => $old_data['title'],
    ),1);
    notification_add($jv['uid'],'system', lang_hd('cggm',0), array(
        'url' => $_G['siteurl']."plugin.php?id=xigua_hd&ac=view&did={$data['did']}&jid=$jid",
        'u' => $buyer['username'],
        'p' => $data['price'],
        'a' => $old_data['title'],
    ),1);

    return true;
}
function hd_random_code(){
    return substr(mt_rand(10000000, 99999999), 0, 8);
}

function hd_qrcode_make($code){
    global $_G, $config,$SCRITPTNAME;
    $rs = array();

    $repath = './source/plugin/xigua_hd/cache/';
    $qrfile = $repath . $code . '.png';
    $abs_qrfile = DISCUZ_ROOT . $qrfile;
    $url = $_G['siteurl']."$SCRITPTNAME?id=xigua_hd&ac=scan&code=$code";

    if (!is_file($abs_qrfile)) {
        @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
        if(class_exists('QRcode')){
            QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
        }
    }
    return $qrfile;
}
function check_hd_manage(){
    global $_G;
    $shids = array();
    if(!$_G['uid']){
        return $shids;
    }
    $shids1 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_shanghu',
        $_G['uid']
    ),'shid');
    $shids2 = DB::fetch_all('select uid,shid from %t WHERE uid=%d', array(
        'xigua_hs_yuan',
        $_G['uid']
    ),'shid');
    $shids = array_merge(array('0'), array_keys($shids1), array_keys($shids2));
    return $shids;
}

function xigua_hd_pay_callback(){
    $sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
    $url = $sys_protocal.(isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
    $url = rtrim($url, '/').'/';
}

function hd_ipcheck(){
    global $hd_config, $_G;
    if ($hbarea = array_filter(explode(',', $hd_config['allowip']))) {
        if ($ps = json_decode(hb_curl("http://ip.taobao.com/service/getIpInfo.php?ip=" . $_G['clientip']), true)) {
            $ps = $ps['data'];
            $ps['region'] = diconv($ps['region'], 'utf-8');
            $ps['city'] = diconv($ps['city'], 'utf-8');
            $ps['country'] = diconv($ps['country'], 'utf-8');
            $ps['area'] = diconv($ps['area'], 'utf-8');
            if($ps['country'] || $ps['region'] || $ps['area'] || $ps['city']) {
                if (!(in_array($ps['region'], $hbarea) || in_array($ps['city'], $hbarea) || in_array($ps['area'], $hbarea) || in_array($ps['country'], $hbarea))) {
                    hb_message(str_replace(array('{province}', '{city}'), array($ps['country'] . $ps['area'], $ps['region'] . $ps['city']), lang_hd('ipban', 0)), 'error');
                }
            }
        }
    }
    return true;
}