<?php
/**
* Created by PhpStorm.
* User: Administrator
* Date: 2015/4/15
* Time: 11:15
*/
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hd/function.php';
$he_config = $_G['cache']['plugin']['xigua_hd'];

if($_SERVER['REQUEST_METHOD'] == 'POST') {
$_GET = dhtmlspecialchars($_GET);
}
$page = max(1, intval(getgpc('page')));
$lpp = 10;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
    $ret = C::t('#xigua_hd#xigua_hd_cat')->do_delete(intval($_GET['catid']));
    if($ret){
        cpmsg(
            lang_hb('delcat_succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_cat&page=$page",
            'succeed'
        );
    }else{
        cpmsg(
            lang_hb('delcat_error', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_cat&page=$page",
            'error'
        );
    }
}
if(submitcheck('dosubmit')){
    if($new = $_GET['n']){
        $newrow = array();
        foreach ($new['name'] as $k => $v) {
            if(is_array($v)){
                foreach ($v as $kk => $string) {
                    $newrow[] = array(
                        'pid'  => $k,
                        'name' => $string,
                        'o'    => $new['o'][$k][$kk],
                        'ts'   => TIMESTAMP,
                        'fid'  => trim($new['fid'][$k][$kk]),
                    );
                }
            } else {
                $newrow[] = array(
                    'pid' => 0,
                    'name' => $v,
                    'o'  => $new['o'][$k],
                    'ts'   => TIMESTAMP,
                    'fid'  => trim($new['fid'][$k]),
                );
            }
        }
        foreach ($newrow as $value) {
            C::t('#xigua_hd#xigua_hd_cat')->insert($value);
        }
    }

    if($_FILES['icon'] || $_FILES['adimage']){
        $icons = hb_uploads($_FILES['icon']);
        $adimage = hb_uploads($_FILES['adimage']);
    }
    if($_FILES['in_ad']){
        $in_ad = hb_uploads($_FILES['in_ad']);
    }

    if($r = $_GET['r']){
        foreach ($r['name'] as $cid => $name) {
            $data = array();

            $data['name']   = $name;
            $data['o']      = $r['o'][$cid];
            $data['fid']    = $r['fid'][$cid];
            $data['adlink'] = $r['adlink'][$cid];
            $data['in_adlnk'] = $r['in_adlnk'][$cid];
            $data['price']  = round($r['price'][$cid], 2);
            $data['endtime'] = $r['endtime'][$cid];
            $data['tag']    = trim($r['tag'][$cid]);
            $data['placehoder']    = trim($r['placehoder'][$cid]);
            if($_FILES['adimage']['error'][$cid] === UPLOAD_ERR_OK){
                $data['adimage']= ($adimage[$cid]['errno'] == 0 ? $adimage[$cid]['error'] : '');
            }
            if($_FILES['in_ad']['error'][$cid] === UPLOAD_ERR_OK){
                $data['in_ad']= ($in_ad[$cid]['errno'] == 0 ? $in_ad[$cid]['error'] : '');
            }
            if($_FILES['icon']['error'][$cid] === UPLOAD_ERR_OK) {
                $data['icon'] = ($icons[$cid]['errno'] == 0 ? $icons[$cid]['error'] : '');
            }

            C::t('#xigua_hd#xigua_hd_cat')->update($cid, $data);
        }
    }
    if($delimg = $_GET['delimg']){
        foreach ($delimg as $catid_ => $fields_) {
            $data_ = array();
            if($fields_['icon'] == 1){
                $data_['icon'] = '';
            }
            if($fields_['adimage'] == 1){
                $data_['adimage'] = '';
            }
            if($fields_['in_ad'] == 1){
                $data_['in_ad'] = '';
            }
            if($data_){
                C::t('#xigua_hd#xigua_hd_cat')->update(intval($catid_), $data_);
            }
        }
    }
    cpmsg(
        lang_hb('succeed', 0),
        "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_cat&page=$page",
        'succeed'
    );
}

$list = C::t('#xigua_hd#xigua_hd_cat')->fetch_all_by_page($start_limit, $lpp);
$totalcount = C::t('#xigua_hd#xigua_hd_cat')->count_by_page();

$multipage = multi(
    $totalcount, $lpp, $page,
    ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_cat&page=$page"
);

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_cat&page=$page", 'enctype');



$hb_cats = C::t('#xigua_hs#xigua_hs_hangye')->list_all(1);

$hb_catsting = '';
foreach ($hb_cats as $index => $hb_cat) {
    $hb_catsting.= "<span style='width:120px;display:inline-block'>[{$hb_cat['name']}: <b>{$hb_cat['id']}</b>] </span>";
}
showtips(sprintf('<li>'.$hb_catsting.'</li>', $_G['siteurl'] . "$SCRITPTNAME?id=xigua_hs"));


$alink = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_pub&catadd";
?>
<style>
    .imgi{height:20px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
    .short{width:100px}
    .td23 input{width:80px!important;}
</style>
<table class="tb tb2 ">
    <tbody>
    <tr class="header">
        <th><?php lang_hb('ID')?></th>
        <th><?php lang_hb('order')?></th>
        <th><?php lang_hb('cat_name')?></th>
        <th><?php lang_hb('cat_icon')?></th>
<!--        <th>--><?php //lang_hb('cat_ad')?><!--</th>-->
        <th><?php lang_hd('hyids')?></th>
<!--        <th>--><?php //lang_hd('in_ad')?><!--</th>-->
        <th><?php lang_hb('exit')?></th>
    </tr>
    </tbody>
    <?php foreach ($list as $v) { ?>
        <tbody>
        <tr class="hover">
            <td class="td25"><?php echo $v['id']?></td>
            <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $v['id']?>]" value="<?php echo $v['o']?>" /></td>
            <td class="td23">
                <div class="parentboard"><input type="text" name="r[name][<?php echo $v['id']?>]" value="<?php echo $v['name']?>" class="txt" /></div>
            </td>
            <td>
                <input class="short" name="icon[<?php echo $v['id']?>]" type="file" />
                <?php if($v['icon']){?>
                    <span class="sp">
 <img class="imgi" src="<?php echo $v['icon']?>" onmouseover="$('icon<?php echo $v['id']?>').style.display='block'" onmouseout="$('icon<?php echo $v['id']?>').style.display='none'" />
 <img id="icon<?php echo $v['id']?>" src="<?php echo $v['icon']?>"  class="imgprevew" />
 <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][icon]" value="1" /><?php lang_hb('delshort')?></label>
</span>
                <?php }?>
            </td>
            <!--<td>
                <p>
                    <input class="short"  name="adimage[<?php /*echo $v['id']*/?>]" type="file" />
                    <input type="text" class="txt short" name="r[adlink][<?php /*echo $v['id']*/?>]" placeholder="http://" value="<?php /*echo $v['adlink'] ? $v['adlink'] : ''; */?>" />
                    <?php /*if($v['adimage']){*/?>
                        <span class="sp">
<img class="imgi" src="<?php /*echo $v['adimage']*/?>" onmouseover="$('ad<?php /*echo $v['id']*/?>').style.display='block'" onmouseout="$('ad<?php /*echo $v['id']*/?>').style.display='none'"  />
<img id="ad<?php /*echo $v['id']*/?>" src="<?php /*echo $v['adimage']*/?>"  class="imgprevew" />
 <label><input type="checkbox" class="checkbox" name="delimg[<?php /*echo $v['id']*/?>][adimage]" value="1" /><?php /*lang_hb('delshort')*/?></label>
</span>
                    <?php /*}*/?>
                </p>
            </td>-->
            <td>
                <label>
                    <textarea class="txt mini" name="r[tag][<?php echo $v['id']?>]"><?php echo $v['tag'] ?></textarea>
                </label>
            </td>
            <!--<td>
                <p>
                    <input class="short"  name="in_ad[<?php /*echo $v['id']*/?>]" type="file" />
                    <input type="text" class="txt short" name="r[in_adlnk][<?php /*echo $v['id']*/?>]" placeholder="http://" value="<?php /*echo $v['in_adlnk'] ? $v['in_adlnk'] : ''; */?>" />
                    <?php /*if($v['in_ad']){*/?>
                        <span class="sp">
<img class="imgi" src="<?php /*echo $v['in_ad']*/?>" onmouseover="$('ad<?php /*echo $v['id']*/?>').style.display='block'" onmouseout="$('inad<?php /*echo $v['id']*/?>').style.display='none'"  />
<img id="inad<?php /*echo $v['id']*/?>" src="<?php /*echo $v['in_ad']*/?>"  class="imgprevew" />
 <label><input type="checkbox" class="checkbox" name="delimg[<?php /*echo $v['id']*/?>][in_ad]" value="1" /><?php /*lang_hb('delshort')*/?></label>
</span>
                    <?php /*}*/?>
                </p>
            </td>-->
            <td>
                <a href="javascript:;" onclick="return _delid(<?php echo $v['id']?>,'<?php echo str_replace('&#039;', '', $v['name'])?>') "><?php lang_hb('del')?></a>
            </td>
        </tr>
        </tbody>
    <?php }?>

    <tbody>
    <tr>
        <td>&nbsp;</td>
        <td colspan="99"><div>
                <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hb('ad_new_cat')?></a>
            </div></td>
    </tr>
    <?php
    if($multipage){
        showtablerow('', 'colspan="99"', $multipage);
    }
    showsubmit('dosubmit', 'submit', 'td');
    ?>
    </tbody>
</table>
</form>
<script>
    var rowtypedata = [
        [
            [1, ''],
            [1,'<input type="text" class="txt" name="n[o][]" value="0" />', 'td25'],
            [6,'<div><input name="n[name][]" value="<?php lang_hb('new_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
        ]
    ];
    function _delid(id, name){
        if(confirm('<?php lang_hb('del_confirm')?>' + name + '?')){
            window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_cat&page=$page&del=1&formhash=".FORMHASH.'&catid='?>"+id;
        }
    }
</script>