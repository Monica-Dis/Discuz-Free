<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hd/function.php';

$jid = intval($_GET['jid']);
$did = intval($_GET['did']);

$url = $_G['siteurl']."$SCRITPTNAME?id=xigua_hd&ac=view&did=$did&jid=$jid".$_G['cookie']['URLEXT'].$urlext;
$hd_config = $_G['cache']['plugin']['xigua_hd'];
if($hd_config['dlym']){
    $url = $hd_config['dlym']."$SCRITPTNAME?id=xigua_hd&ac=view&did=$did&jid=$jid".$_G['cookie']['URLEXT'].$urlext;
}

$ewm = md5($url);

if(!is_file(DISCUZ_ROOT . './source/plugin/xigua_hd/cache/'.$ewm.'.png')) {
    $repath = './source/plugin/xigua_hd/cache/';
    $qrfile = $repath . $ewm . '.png';
    $abs_qrfile = DISCUZ_ROOT . $qrfile;

    if (!is_file($abs_qrfile)) {
        @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
        if(class_exists('QRcode')){
            QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
        }
    }
    dheader('Location: '.$_G['siteurl'].$qrfile.'?'.VERHASH);
}
dheader('Location: '.$_G['siteurl'].'source/plugin/xigua_hd/cache/'.$ewm.'.png?'.VERHASH);