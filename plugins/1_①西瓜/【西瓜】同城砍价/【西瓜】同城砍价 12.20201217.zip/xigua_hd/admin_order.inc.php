<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hd/function.php';

if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$sta = array(
    -2=>lang_hd('ostat-2',0),
    -1=>lang_hd('ostat-1',0),
    0 =>lang_hd('ostat0',0),
    1 =>lang_hd('ostat1',0),
);

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hd#xigua_hd_income')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            if(isset($item['reach']) && intval($item['reach'])==0){
                $old = C::t('#xigua_hd#xigua_hd_income')->fetch($index);
            }else{
                $old = array();
            }
            C::t('#xigua_hd#xigua_hd_income')->update($index, $item);
            if($old && $old['reach']!=0){
                notification_add($old['uid'],'system', lang_hd('note_2', 0),array('url' => "$SCRITPTNAME?id=xigua_hd&ac=income", 'money'=>$old['money']),1);
            }
        }
    }
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_order&page=$page", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword'";
}
if($_GET['reach']){
    $wherearr[] = "reach='".intval($_GET['reach'])."'";
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_order");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="UID" value="'.$_GET['keyword'].'" class="txt" /> ';
foreach ($sta as $index => $item) {
    $chk = isset($_GET['reach']) && $_GET['reach']==$index ? 'checked':'';
    echo " <label><input type=\"radio\" name=\"reach\" value=\"$index\" $chk>$item</label>";
}
echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo '</div>';

showtableheader(lang_hd('tichengmanage', 0));
showtablerow('class="header"',array(),array(
    lang_hb('del', 0),
    lang_hb('ID', 0),
    lang_hd('hhr', 0),
    lang_hd('caozuo', 0),
    lang_hd('ruzhangqi', 0),
    lang_hd('tichengyuan', 0),
    lang_hd('tichengbl', 0),
    lang_hd('ddxinxi', 0),
    lang_hd('crts', 0),
));

$res = C::t('#xigua_hd#xigua_hd_income')->fetch_all_by_page($start_limit, $lpp, $wherearr);
$icount = C::t('#xigua_hd#xigua_hd_income')->fetch_count_by_page($wherearr);

$uids = array();
foreach ($res as $v) {
    $uids[] = $v['uid'];
    $uids[] = $v['fansuid'];
    $uids[] = $v['info']['fromuid'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}

foreach ($res as $v) {
    $id = $v['id'];
    $uid = $v['uid'];
    $info = $v['info'];
    if(!is_array($info['info'])){
        $info['info'] = unserialize($info['info']);
    }

    $fromuid = $info['fromuid'];

    $sel = $seltype = '';
    foreach ($sta as $index => $item) {
        if($v['reach'] == $index){
            $sel .= "<option value=\"$index\" selected>$item</option>";
        }else{
            $sel .= "<option value=\"$index\">$item</option>";
        }
    }
    /*if($v['reach']==1){
        $dis = 'disabled';
    }*/
    $endts = date('Y-m-d H:i:s', $v['endts']);
    $crts = date('Y-m-d H:i:s', $v['crts']);

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
        $id,
        "<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
        !in_array($v['reach'], array('-2','-1')) ? $sta[$v['reach']]: "<select name='r[$id][reach]' $dis>$sel</select>",
        "<input type=\"text\" style='width:100px' class=\"txt\" name=\"r[$id][indate]\" value=\"{$v['indate']}\" onclick=\"showcalendar(event, this, 0)\">",
        "<input type=\"text\" style='width:80px' class=\"txt\" name=\"r[$id][money]\" value=\"{$v['money']}\">",
        "{$v['ratio']}%",


        lang_hd('oinfo1',0).' : '.$info['subject'].
        '<br>'.lang_hd('oinfo5',0).' : '.$info['info']['data'][0]['shname'].
        '<br>'.lang_hd('oinfo2',0).' : '.$info['baseprice'].
        '<br>'.lang_hd('oinfo3',0).' : '.$info['order_id'].
        '<br>'.lang_hd('oinfo4',0).' : '."<a href='home.php?mod=space&uid=$fromuid&do=profile' target='_blank'>{$users[$fromuid]['username']}</a>",
        "$crts",

    ));
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_order&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/

?>
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>