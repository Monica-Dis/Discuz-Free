<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/11/19
 * Time: 16:38
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hd/function.php';

$page = max(1, intval(getgpc('page')));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$statuss = array(
    '0' => lang_hd('shwg',0),
    '1' => lang_hd('ddsh',0),
    '2' => lang_hd('ysj',0),
    '3' => lang_hd('yxj',0)
);
$hs_config = $_G['cache']['plugin']['xigua_hs'];
if($hs_config['shcolors']){
    foreach (explode("\n", trim($hs_config['shcolors'])) as $index => $item) {
        list($_color, $_title) = explode('=', trim($item));
        $tmp = explode(',', $_color);
        $shcolor[$_title] = $tmp[0];
    }
}

if($secid = intval($_GET['secid'])){

    $res = C::t('#xigua_hd#xigua_hd_dis')->fetch($secid);

    if(!submitcheck('dosubmit')) {
        if(!$res){
            $res = array ( 'id' => 0, 'status' => '0', 'uid' => '0', 'title' => '', 'shid' => '0', 'hangye_id1' => '0', 'hangye_id2' => '0', 'shname' => '0', 'allnum' => '0', 'stock' => '0', 'usetime' => '0', 'starttime' => '0', 'endtime' => '0', 'disprice' => '0.00', 'biaoprice' => '0.00', 'showdis' => '0', 'jieshao' => '', 'album' => 'a:0:{}', 'append_img' => 'a:0:{}', 'append_text' => 'a:0:{}', 'crts' => '0', 'upts' => '0', 'views' => '0', 'shares' => '0', 'displayorder' => '0', 'orderdis' => '0', 'selfdis' => '0', 'zong' => '0', 'xiaxian' => '0', 'shangxian' => '0', 'music' => '', 'color' => '', 'color_title' => '0', 'income_uid' => '0', 'joins' => '0', );
        }
        unset($res['shixian']);

        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis&secid=$secid", 'enctype');
        showtableheader(); /*Dism_taobao-com*/
        showtitle(lang_hd('spgl',0) . ($secid>0?$secid:''). "<a href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis'> ".lang_hd('back',0)."</a>");

        foreach ($res as $index => $re) {
            if(in_array($index, array('hangye_id1','hangye_id2','shname', 'not_start', 'end','srange_ary','xiajia','shen', 'quan', 'yuanprice','id','color_title', 'is_end'))){
                continue;
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, array('endts', 'dig_endts', 'crts', 'upts', 'usetime', 'starttime', 'endtime'))){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('shid'))){
                $cs = '<select name="editform[shid]">';
                foreach (DB::fetch_all('select shid,`name` from %t WHERE display=1 AND endts>=%d', array(
                    'xigua_hs_shanghu',
                    TIMESTAMP
                ), 'shid') as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['name']}[".lang_hd('sh',0)."ID:{$c['shid']}]</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('thumb'))){
                $tp = 'filetext';
            }elseif(in_array($index, array('yuyue' ,'gongkai','showdis', 'selfdis', 'orderdis'))){
                $tp = 'radio';
            }
            if($index == 'color'){
                $cs = '<select name="editform[color_title]">';
                foreach ($shcolor as $c_t => $c) {
                    $s = '';
                    if($c== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c_t</option>";
                }
                $tp = $cs;
            }

            if (in_array($index, array('album', 'append_img', 'append_text'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $hs_config = $_G['cache']['plugin']['xigua_hs'];
                $loopnum = $hs_config['maximg'];
                if ($index == 'append_text') {
                    $tp = 'text';
                }
                for ($i = 0; $i < $loopnum; $i++) {
                    showsetting(lang_hd($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp);
                }
            }elseif($index == 'jieshao'){
                $_tmp1 = lang_hd($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            }else{
                showsetting(lang_hd($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*Dism��taobao��com*/
        showformfooter(); /*Dism_taobao_com*/
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    }else{

        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['color'] = $shcolor[$editform['color_title']];
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album' || $__k == 'append_img') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach (array('crts', 'upts', 'usetime', 'starttime', 'endtime') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        $editform['jieshao'] = ($editform['jieshao']);
        $editform['append_text'] = array_slice($editform['append_text'], 0, count($editform['append_img']));

        foreach (array('album', 'append_text', 'append_img') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = serialize($editform[$item]);
        }

        $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch($editform['shid']);
        if(!$sh){
            cpmsg(lang_hd('shnotexists',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis&secid=$secid", 'error');
        }
        $editform['shname']     = $sh['name'];
        $editform['shid']       = $sh['shid'];
        $editform['hangye_id1'] = $sh['hangye_id1'];
        $editform['hangye_id2'] = $sh['hangye_id2'];

        if($secid>0){
            $rs = C::t('#xigua_hd#xigua_hd_dis')->update($secid, $editform);
        }else{
            $rs = C::t('#xigua_hd#xigua_hd_dis')->insert($editform);
        }
        cpmsg(lang_hd('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis&secid=$secid", 'succeed');
    }
}else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_hd#xigua_hd_dis')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_hd#xigua_hd_dis')->update($id, array('displayorder' => $item['displayorder'], 'status' => $item['status']));
        }

        cpmsg(lang_hd('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword<9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    }else if ($keyword = stripsearchkey($keyword)) {
        $wherearr[] = " (title LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR jieshao LIKE '%$keyword%' OR append_text LIKE '%$keyword%') ";
    }
    if(isset($_GET['status'])){
        $wherearr[] = 'status=' . intval($_GET['status']);
    }
    if(isset($_GET['secid1'])){
        $wherearr = array('id=\'' . intval($_GET['secid1']).'\'');
    }

    $ob = ' displayorder DESC';

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="'.lang_hd('spmc',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($statuss as $index => $_v) {
        echo '<label><input type="radio" name="status" value="'.$index.'" ' . (isset($_GET['status'])&&$_GET['status']==$index ? 'checked' : '') . ' />' . $_v.'</label>';
    }

    echo '&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis".' class="btn" >'.cplang('reset').'</a> ';
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis&secid=-1\">".lang_hd('tjsp',0)."</a></div>";

    showtableheader(lang_hd('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_hd('del', 0),
        lang_hd('displayorder', 0),
        lang_hd('thumb', 0),
        lang_hd('title', 0),
        lang_hd('hsname', 0),
        lang_hd('zs', 0),
        lang_hd('kc', 0),
        lang_hd('crendts', 0),
        lang_hd('spzt', 0),
        lang_hd('xszt', 0),
        lang_hd('caozuo', 0),
    ));


    $res = C::t('#xigua_hd#xigua_hd_dis')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = C::t('#xigua_hd#xigua_hd_dis')->fetch_count_by_page($wherearr);

    $shids = array();
    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
        $shids[$v['shid']] = $v['shid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    if($shids){
        $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
    }

    foreach ($res as $v) {
        $id = $v['id'];
        $shid = $v['shid'];
        $thumb = $v['album'][0] ?$v['album'][0] :$v['append_img_ary'][0];
        $stat = lang_hd('jxz',0);
        if($v['not_start']){
            $stat =lang_hd( 'wks',0);
        }elseif ($v['end']){
            $stat = lang_hd('yjs',0);
        }
        if($v['stock']<=0){
            $stat = lang_hd('ysw',0);
        }


        $checked = $v['display'] ? 'checked' : '';

        $appeend = '';
        foreach ($v['append_img_ary'] as $__k => $__v) {
            $appeend .= "<p><img style='width:180px;display:block' src=\"{$__v}\" /></p>";
            $appeend .= "<p>" . nl2br($v['append_text_ary'][$__k]) . "</p>";
        }

        foreach ($v['album'] as $index => $item) {
            $img .= "<a href='$item' target='_blank'><img src='$item' style='width:40px;height:40px;' /></a>";
        }

        $status_u = "<select name=\"row[$id][status]\">";
        foreach ($statuss as $k => $vv) {
            if($v['status']== $k){
                $s = 'selected';
            }else{
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        $c = ($v['endts'] < TIMESTAMP ? 'style="color:red"' : 'style="color:forestgreen"');

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input type='text' name='row[$id][displayorder]' value='{$v['displayorder']}' style='width:50px' />",
            "<img src='$thumb' style='width:70px;height:40px' />",
            $v['title'],
            "<a target='_blank' href='".ADMINSCRIPT."?action=plugins&operation=config&do=&identifier=xigua_hs&pmod=admin_shanghu&shid=".$v['shid']."'>".$shinfos[$v['shid']]['name'].'</a>',
            $v['allnum'],
            $v['stock'],
            $v['crts_u'].'<br>'.$v['start_u'].'/'.$v['end_u'],



            $status_u,
            $stat,

            '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis&secid=$id" . '">' . lang_hd('edit', 0) . '</a> '.
            '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_join&did=$id" . '">' . lang_hd('gmjl', 0) . '</a>',
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_dis&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*Dism��taobao��com*/
    showformfooter(); /*Dism_taobao_com*/

    /*echo '<pre>';
    print_r($res);
    echo '</pre>';*/
}