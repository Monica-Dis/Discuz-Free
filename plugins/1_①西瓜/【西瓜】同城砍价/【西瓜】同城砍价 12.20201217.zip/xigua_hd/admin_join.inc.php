<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2017/11/19
 * Time: 16:38
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hs/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hd/function.php';

$page = max(1, intval(getgpc('page')));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;


if (submitcheck('permsubmit')) {
    if ($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hd#xigua_hd_join')->deletes($delete);
    }

    cpmsg(lang_hd('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_join&page=$page", 'succeed');
}

$wherearr = array();
$keyword = $_GET['keyword'];
if ($keyword = stripsearchkey($keyword)) {
    $wherearr[] = " (uid='$keyword' OR order_id LIKE '%$keyword%' OR hxcode LIKE '%$keyword%') ";
}
if(isset($_GET['status'])){
    $wherearr[] = 'status=' . intval($_GET['status']);
}
if(isset($_GET['stype'])){
    if($_GET['stype'] =='2'){
        $wherearr[] = 'order_id!=\'\' AND order_id!=\'-1\'';
    }
}
if($secid = intval($_GET['did'])){
    $wherearr[] = "did='$secid'";
}
if(isset($_GET['hxstatus'])){
    $hxstatus = intval($_GET['hxstatus']);
    $wherearr[] = "hxstatus='$hxstatus'";
}

$ob = 'id DESC';

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_join&did={$_GET['did']}");

echo '<div><input type="text" id="keyword" placeholder="'.lang_hd('search_log',0).'" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
foreach (array(0=>lang_hd('weihexiaofa',0), 1=>lang_hd('yihexiaofa',0)) as $index => $_v) {
    echo '<label><input type="radio" name="hxstatus" value="'.$index.'" ' . (isset($_GET['hxstatus'])&&$_GET['hxstatus']==$index&&$_GET['hxstatus']!=='' ? 'checked' : '') . ' />' . $_v.'</label>';
}
echo '&nbsp;';
$stypes = array(
    '2' => lang_hd('yzf',0),
    '1' => lang_hd('wzf',0),
);
foreach ($stypes as $index => $_v) {
    echo '<label><input type="radio" name="stype" value="'.$index.'" ' . (isset($_GET['stype'])&&$_GET['stype']==$index ? 'checked' : '') . ' />' . $_v .'</label>';
}
echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_join&did={$_GET['did']}".' class="btn" >'.cplang('reset').'</a> ';

showtableheader(lang_hd('fabuguanli', 0));
showtablerow('class="header"', array(), array(
    lang_hd('del', 0),
    lang_hd('order_id', 0),
    lang_hd('order_price_', 0),
    lang_hd('order_recive', 0),
    lang_hd('jjcs', 0),
    lang_hd('user', 0),
    lang_hd('mobile', 0),
    lang_hd('crts', 0),
    lang_hd('outdate', 0),
    lang_hd('hb', 0),
    lang_hd('hxstatus_danhao', 0),
    lang_hd('mendian', 0),
    lang_hd('hxcrts', 0),
    lang_hd('hxuid', 0),
//    lang_hd('jjjl', 0),
));


$res = C::t('#xigua_hd#xigua_hd_join')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
$icount = C::t('#xigua_hd#xigua_hd_join')->fetch_count_by_page($wherearr);

$secids = $shids = array();
foreach ($res as $v) {
    if ($v['uid']) {
        $uids[$v['uid']] = $v['uid'];
        $uids[$v['hxuid']] = $v['hxuid'];
    }
    $shids[$v['shid']] = $v['shid'];
    $secids[$v['did']] = $v['did'];
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $mobiles = DB::fetch_all('SELECT uid,mobile FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}

if($shids){
    $shinfos = DB::fetch_all('SELECT shid,`name` FROM %t where shid in(%n)', array('xigua_hs_shanghu', $shids), 'shid');
}
if($secids){
    $secinfos = DB::fetch_all('SELECT * FROM %t where id in(%n)', array('xigua_hd_dis', $secids), 'id');
}

foreach ($res as $v) {
    $id = $v['id'];
    $dinfo = $secinfos[$v['did']];

    $hxstat = $v['hxstatus']==1?lang_hd('hashx',0):lang_hd('beenhx',0);

    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_join&did={$v['did']}&jid=$id";

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
        $v['order_id'] ? '<span style="color:forestgreen;">'.($v['order_id']==-1?'-':$v['order_id']).'' : '<span style="color:orange;">'.lang_hd('jjz',0).'</span>',
        $v['current'].lang_hd('yuan',0),
        $v['order_id'] ? $v['hxcode'] : '-',
        $v['jians'],
        "[UID: {$v['uid']}]". $users[$v['uid']]['username'],
        $v['realname'].'<br>'.$v['mobile'].'<br>'.($v['liuyan'] ? lang_hd('liuyan',0).$v['liuyan'] : ''),
        $v['crts']? date('Y-m-d H:i:s', $v['crts']) : '',
        $dinfo['usetime']? date('Y-m-d H:i:s', $dinfo['usetime']) : '',
        ($v['hbmoney']>0 ? lang_hd('hb1',0)."{$v['hbmoney']}<br>".lang_hd('hb2',0)."{$v['hbnum']}<br>".lang_hd('hb3',0).$v['hbsendnum'] :''),
        $hxstat,
        "[ID: {$v['shid']}]".$shinfos[$v['shid']]['name'],
        $v['hxcrts']? date('Y-m-d H:i:s', $v['hxcrts']) : '',
        $v['hxuid'] ? "[UID:{$v['hxuid']}]". $users[$v['hxuid']]['username'] : '',
//        "<a href=\"$dlink\">".lang_hd('jjjl', 0).'</a>'
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=admin_join&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', 'del', "", $multipage);
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/
