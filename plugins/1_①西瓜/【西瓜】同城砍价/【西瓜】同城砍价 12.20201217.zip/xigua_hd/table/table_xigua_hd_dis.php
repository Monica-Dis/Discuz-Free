<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hd_dis extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hd_dis';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false)
    {
        $good_id = parent::insert($data, true, $replace, $silent);
        if($data['status'] == 2){
            global $_G,$SCRITPTNAME,$urlext;
            $guanids = C::t('#xigua_hs#xigua_hs_follow')->fetch_follow_by_shid($data['shid']);
            foreach ($guanids as $index => $guanid) {
                notification_add($guanid,'system',
                    "<a href='{url}'>{name}".lang('plugin/xigua_hb', 'fabule')."{subject}</a>",array(
                        'name' => $data['shname'],
                        'url' => "{$_G['siteurl']}{$SCRITPTNAME}?id=xigua_hd&ac=view&did=$good_id".$urlext,
                        'subject' => $data['title']
                    ),

                    1);
            }
        }
        return $good_id;
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'views DESC', $fields= '*')
    {
        global $_G;
        if(is_array($wherearr) && !defined('IN_ADMINCP')){
            $wherearr[] = 'stid='.intval($_GET['st']);
            if(!$_GET['st'] && $_G['cache']['plugin']['xigua_st']['showsubsh']){
                array_pop($wherearr);
            }
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        if($v){
            if($v['album']){
                $v['album'] = unserialize($v['album']);
                $v['start_u'] = $v['starttime'] ? date('Y-m-d H:i', $v['starttime']) : '';
                $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
                $v['end_u'] =  $v['endtime'] ? date('Y-m-d H:i', $v['endtime']) : '';
                $v['usetime_u'] = $v['usetime'] ? date('Y-m-d H:i', $v['usetime']) : '';
                $v['not_start'] = $v['starttime']>TIMESTAMP;
                $v['end'] = (($v['endtime'] && $v['endtime']<TIMESTAMP) || $v['stock']<=0);
                $v['xiajia'] = $v['status']==3;
                $v['shen'] = $v['status']==1;

                $v['append_img_ary'] = unserialize($v['append_img']);
                $v['append_text_ary'] = unserialize($v['append_text']);
                if($v['end'] && !$v['is_end']){
                    DB::update('xigua_hd_dis', array('is_end' => 1), array('id' => $v['id']));
                }elseif (!$v['end'] && $v['is_end']){
                    DB::update('xigua_hd_dis', array('is_end' => 0), array('id' => $v['id']));
                }
                $v['disprice'] = str_replace('.00','',$v['disprice']);
                $v['biaoprice'] = str_replace('.00','',$v['biaoprice']);
            }
        }
        return $v;
    }

    public function fetch_by_id($secid){
        $rs = parent::fetch($secid);
        $this->incr($secid, 'views');
        /*if(submitcheck('jid')) {
            if ($rs['stock'] < 1) {
                hb_message(lang_hd('kcbz', 0), 'error');
            }
        }*/
        return $this->prepare($rs);
    }

    public function incr($pubid, $field, $num = 1)
    {
        if(strpos($pubid, ',')!==false){
            $pubid = dintval(array_filter(explode(',', $pubid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $pubid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $pubid));
        }
    }

    public function updateStock($secid, $num = 1)
    {
        DB::query('update %t set stock=stock-%d WHERE '.$this->_pk.'=%d AND stock>=%d', array(
            $this->_table,
            $num,
            $secid,
            $num,
        ));
        return DB::affected_rows();
    }

    public function fetch_by_ids($ids, $fields='*', $key_field = '')
    {
        $rs = DB::fetch_all("SELECT $fields FROM %t WHERE id IN (%n)", array(
            $this->_table,
            $ids
        ), $key_field ? $key_field : $this->_pk);
        foreach ($rs as $index => $r) {
            $rs[$index] = self::prepare($r);
        }
        return $rs;
    }
    public function total_views()
    {
        global $_G, $config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = 'stid='.$st;
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = 'stid='.$st;
                }
            }
        }

        $key = 'xigua_hd_pub_total_views'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }

        return $return;
    }
    public function total_count() {
        global $_G,$config;
        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = 'stid='.$st;
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = 'stid='.$st;
                }
            }
        }
        $key = 'xigua_hd_dis_count'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT COUNT(*) FROM %t WHERE '.$whe, array($this->_table));
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }
}