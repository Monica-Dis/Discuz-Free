<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hd_cat extends  discuz_table
{
    public $arr = array();

    public $nbsp = "&nbsp;";

    public $ret = '';

    public $child = array();

    public $tree_id = 'id';
    public $tree_pid = 'pid';

    public function __construct()
    {
        $this->_table = 'xigua_hd_cat';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function fetch_by_name($name)
    {
        $res = DB::fetch_first('SELECT id,pid FROM %t WHERE `name`=%s', array(
            $this->_table,
            $name
        ));
        if($res['pid'] && $res['id']){
            return array($res['id']);
        }elseif(!$res['pid'] && $res['id']){
            $tds = $this->get_childs_by_pids($res['id']);
            $ret = array($res['id']);
            foreach ($tds as $index => $td) {
                $ret[] = $td['id'];
            }
            return $ret;
        }else{
            return array();
        }
    }

    public function count_by_page(){
        $result = DB::result_first(
            'SELECT count(*) FROM %t  WHERE pid=0 ',
            array($this->_table)
        );
        return $result;
    }

    public function fetch_all_by_page($start_limit = 0 , $lpp = 20){
        $result = DB::fetch_all(
            "SELECT * FROM %t  WHERE pid=0  ORDER BY o ASC,id ASC " . DB::limit($start_limit, $lpp),
            array(
                $this->_table,
            ),
            $this->_pk
        );
        return array_merge($result);
    }

    public function list_all($simple = 0, $key = false)
    {
        if($simple){
            $field = 'id,pid,name';
        }else{
            $field = '*';
        }
        if($key){
            return DB::fetch_all("SELECT $field FROM %t ORDER BY o ASC,id ASC", array($this->_table), $this->_pk);
        }else{
            return DB::fetch_all("SELECT $field FROM %t ORDER BY o ASC,id ASC", array($this->_table));
        }
    }

    public function fetch_by_catid($catid = 0)
    {
        $item = parent::fetch($catid);
        if($item){
            $item['icon'] = !$item['icon'] ? 'source/plugin/xigua_hb/static/img/icon.png' : $item['icon'];
        }
        return $item;
    }

    public function fetchs_light($catids = array())
    {
        return DB::fetch_all("SELECT id,name FROM %t WHERE id IN(%n)", array($this->_table, $catids), $this->_pk);
    }
    public function do_delete($id)
    {
        return $this->delete($id);
    }

}