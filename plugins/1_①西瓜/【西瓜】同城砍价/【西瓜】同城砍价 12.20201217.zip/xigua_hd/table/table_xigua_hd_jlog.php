<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hd_jlog extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hd_jlog';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'id DESC', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));

        return $result;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public function do_discount($did, $jid, $uid, $dis_data, $money)
    {
        $bottom = $dis_data['disprice']+$money;
        /*if(DB::result_first('select * from %t where did=%d and jid=%d and uid=%d', array($this->_table, $did, $jid, $uid))){
            return -2;
        }*/
        $logid = $this->insert(array(
            'did' => $did,
            'jid' => $jid,
            'uid' => $uid,
            'crts' => TIMESTAMP,
            'crdate' => date('Y-m-d', TIMESTAMP),
            'money' => $money,
        ), true, false, true);
        if($logid>0){
            if(DB::query("update %t set `current`=`current`-$money WHERE id=$jid AND `current`>=$bottom", array('xigua_hd_join'))){
                C::t('#xigua_hd#xigua_hd_join')->incr($jid, 'jians', 1);
                return $logid;
            }else{
                return -1;
            }
        }else{
            return -2;
        }
    }

    public function fetch_by_crdate($jid, $uid, $date = '')
    {
        return DB::fetch_first("select * from %t where jid=%d and uid=%d and crdate=%s", array(
            $this->_table,
            $jid,
            $uid,
            $date ? $date : date('Y-m-d', TIMESTAMP)
        ));
    }

    public function fetch_by_maxjianjid($did, $uid, $jid = 0){
        if($jid){
            return DB::result_first("select count(*) as numer from %t where did=%d and uid=%d and jid=%d", array(
                $this->_table,
                $did,
                $uid,
                $jid,
            ));
        }else{
            return DB::result_first("select count(*) as numer from %t where did=%d and uid=%d", array(
                $this->_table,
                $did,
                $uid,
            ));
        }
    }
}