<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hd_join extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_hd_join';
        $this->_pk = 'id';

        parent::__construct(); /*dis'.'m.tao'.'bao.com*/
    }


    public function update($val, $data, $unbuffered = false, $low_priority = false)
    {
        if(isset($data['liuyan']) && count($data)==1){
            global $did;
            $stock = DB::result_first("select stock from %t where id=%d", array('xigua_hd_dis', $did));
            if($stock<1){
                hb_message(lang_hd('kcbz',0), 'error');
            }
        }
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        $data['upts'] = TIMESTAMP;
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }

    public function incr($id, $field, $num = 1)
    {
        if(strpos($id, ',')!==false){
            $id = dintval(array_filter(explode(',', $id)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $id));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $id));
        }
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'views DESC', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        /*if($orderby=='id DESC'){
            $orderby = 'current ASC';
        }*/
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $res) {
            $result[$index]=$this->prepare($res);
        }
        return $result;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }


    public function do_join($uid, $did, $current, $shid, $mobile= '', $realname = ''){
        return $this->insert(array(
            'uid' => $uid,
            'did' => $did,
            'crts' => TIMESTAMP,
            'status' => 0,
            'hbstatus' => 0,
            'current' => $current,
            'shid' => $shid,
            'mobile' => $mobile,
            'realname' => $realname,
            'stid' => intval($_GET['st']),
        ), TRUE, FALSE, TRUE);
    }

    public function delete_by_uid_did($uid, $did)
    {
        return DB::delete($this->_table, array(
            'uid' => $uid,
            'did' => $did,
        ));
    }

    public function fetch_by_uid_did($uid, $did)
    {
        $res = DB::fetch_first("select * from %t where uid=%d and did=%d", array(
            $this->_table,
            $uid,
            $did,
        ));
        $res=$this->prepare($res);
        return $res;
    }

    public function fetch_by_jid($jid)
    {
        $res = $this->fetch($jid);
        $this->incr($jid, 'views', 1);
        if($res){
            $res['member'] = getuserbyuid($res['uid']);
        }
        $res=$this->prepare($res);
        return $res;
    }
    public function fetch_by_code($code){
        $res = DB::fetch_first('select * from %t where hxcode=%s', array(
            $this->_table,
            $code
        ));
        $res=$this->prepare($res);
        return $res;
    }
    public function update_by_cond($condition, $data)
    {
        DB::update($this->_table, $data, $condition);
        return DB::affected_rows();
    }
    public function total_count() {
        global $_G,$config;

        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if($_G['cache']['plugin']['xigua_st']){
            if($st){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = 'stid='.$st;
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = 'stid='.$st;
                }
            }
        }

        $key = 'xigua_hd_joins_count'.$config['cachettl'].$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return1 = DB::result_first('SELECT COUNT(*) FROM %t WHERE '.$whe, array($this->_table));
            $return2 = DB::result_first('SELECT sum(jians) FROM %t WHERE '.$whe, array($this->_table));
            $return = $return1+$return2;
            savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }

    public function prepare($v)
    {
        if($v){
            $v['current'] = str_replace('.00', '', $v['current']);
        }

        return $v;
    }
}