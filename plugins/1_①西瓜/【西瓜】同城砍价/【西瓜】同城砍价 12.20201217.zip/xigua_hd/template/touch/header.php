<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hb:common_header}-->
<link rel="stylesheet" href="source/plugin/xigua_hd/static/hd.css?1{VERHASH}" />
<style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked,.float_btn{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}</style>
<script>var HB_INWECHAT = '{HB_INWECHAT}', PLZALLOW = '{lang xigua_hd:plzallow}', gengduodongtai = '{lang xigua_hd:gengduodongtai}', guanzhu_sj = '{lang xigua_hd:guanzhu_sj}', yiguanzhu = '{lang xigua_hd:yiguanzhu}', jiaguanzhu='{lang xigua_hd:jiaguanzhu}', mkey = '$hs_config[mkey]', GOOGLE = '{$hs_config[google]}', HS_MULTIUPLOAD = '{$config[multiupload]}', HM_JJS = '{lang xigua_hd:jjsysj}',fxqg = '{lang xigua_hd:fxqg}',qws = '{lang xigua_hd:qws}',
h_t = '{lang xigua_hd:t}', h_h = '{lang xigua_hd:h}', h_f = '{lang xigua_hd:f}',h_sec = '{lang xigua_hd:sec}',
HM_JKS = '{lang xigua_hd:jks}',HM_YJS = '{lang xigua_hd:yjs}',HM_JS = '{lang xigua_hd:jshu}', HM_YY='{lang xigua_hd:yy}', DREFER = '{eval echo rawurlencode($_SERVER[HTTP_REFERER])}', CQYX = '{lang xigua_hd:cqyx}', COMCLAS = '';;</script>
<!--{if $ac!='view'}-->
<!--{if $hd_config['pindaopic']}--><div style="width:0px;height:0px;overflow:hidden;display:none"><img src="$hd_config['pindaopic']" /></div><!--{/if}-->
<!--{/if}-->