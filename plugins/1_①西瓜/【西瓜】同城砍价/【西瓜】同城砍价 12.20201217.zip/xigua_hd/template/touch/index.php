<?php exit('xigua_hd');?>
<!--{template xigua_hd:header}-->
<div class="page__bd">
<!--{if $_G['cache']['plugin']['xigua_st']['showfz']}-->
<header class="x_header bgcolor_11 cl  weui-flex f15" style="background:transparent!important;position:absolute">
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_hd");}{$urlext}'" style="padding:0 10px;display: block;margin:0 10px;text-shadow: 1px 1px 5px rgba(0,0,0,1);">{echo $stinfo['name']?$stinfo['name']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
</header>
<!--{/if}-->
<div class="hm_index_header">

    <!--{if $topnavslider}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $topnavslider $_lv}-->
            <div><a href="{$_lv[href]}"><img src="{$_lv[src]}" class="main-img"></a></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $topnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->


    <div class="weui-cells mt0 border_bottom before_none">
        <div class="weui-cell tr">
            <div class="weui-cell__hd">
                <a class="index_search f15"><i class="weui-icon-search main_color"></i>{lang xigua_hd:search}</a>
            </div>
            <div class="weui-cell__bd">
                <span class="f15">{lang xigua_hd:hd_}:<em class="main_color">{echo hb_trans($total_dis)}{lang xigua_hd:ge}</em></span>
                <span class="ml3 f15">{lang xigua_hd:cy}:<em class="main_color">{echo hb_trans($canyu)}{lang xigua_hd:r}</em></span>
                <span class="ml3 f15">{lang xigua_hd:ll}:<em class="main_color">{echo hb_trans($totalviews)}{lang xigua_hd:c}</em></span>
            </div>
        </div>
    </div>

    <!--{if $jing_list}-->
    <nav class=" nav-list cl swipe transparent mt3" style="padding-top:4px">
        <div class="swipe-wrap">
            <div>
                <ul class="cl">
                    <!--{loop $jing_list $k $n}-->
                    <!--{if $k && $k%5==0}-->
                </ul>
            </div>
            <div>
                <ul class="cl">
                    <!--{/if}-->
                    <li>
                        <a href="$SCRITPTNAME?id=xigua_hd&ac=index&cid=<!--{if $n[name]!='{lang xigua_hd:qb}'}-->{$n[id]}<!--{/if}-->">
                            <span>
                                <img src="{echo $n['icon'] ?$n['icon'] : 'source/plugin/xigua_hb/static/img/icon.png'}"/>
                            </span>
                            <em class="m-piclist-title <!--{if intval($_GET[cid])==$n[id]}-->main_color<!--{/if}-->">{$n['name']}</em>
                        </a>
                    </li>
                    <!--{/loop}-->
                </ul>
            </div>
        </div>
        <nav class="cl bullets bullets1" <!--{if count($jing_list)<=5}-->style="display:none"<!--{/if}-->>
            <ul class="position position1">
                <!--{loop $jing_count $k $v}-->
                <li {if $k==0} class="current" {/if}></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </nav>
    <!--{/if}-->
</div>
<div class="mt0">
    <!--{if !$_GET[cid]}-->
    <div class="weui-cells fixbanner before_none">
        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="$SCRITPTNAME?id=xigua_hd" class="weui-navbar__item <!--{if !$_GET[order_by]}-->weui_bar__item_on<!--{/if}--> ">
                <span>{lang xigua_hd:qb}</span>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hd&order_by=hot"  class="weui-navbar__item  <!--{if $_GET[order_by]=='hot'}-->weui_bar__item_on<!--{/if}-->" >
                <span>{lang xigua_hd:zr}</span>
            </a>
            <a href="$SCRITPTNAME?id=xigua_hd&order_by=new"  class="weui-navbar__item  <!--{if $_GET[order_by]=='new'}-->weui_bar__item_on<!--{/if}-->">
                <span>{lang xigua_hd:zx}</span>
            </a>
        </div>
    </div>
    <!--{/if}-->

<div id="list" class="mod-post x-postlist p0 <!--{if $_GET[cid]}-->mt10<!--{/if}-->">
</div>

    <!--{template xigua_hb:loading}-->
</div>
</div>
<script>
    scrollto = 1;
    var loadingurl = window.location.href+'&ac=evt_li&inajax=1&page=';
</script>

<!--{template xigua_hd:search}-->
<!--{eval $tabbar=1;$hs_tabbar=0;}-->
<!--{eval $config[setbuttom] = $config[setbuttom] ?$config[setbuttom] : lang_hd('jj',0)."|40kanjia|$SCRITPTNAME?id=xigua_hd|index";}-->
<!--{template xigua_hb:common_footer}-->
<script src="source/plugin/xigua_hd/static/hd.js?{VERHASH}"></script>