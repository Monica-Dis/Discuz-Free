<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hd:header}-->
<!--{eval $back_to = "$SCRITPTNAME?id=xigua_hd";}-->
<!--{if $_SERVER[HTTP_REFERER]}-->
<!--{eval $back_to = "javascript:window.history.go(-1);";}-->
<!--{/if}-->
<!--{if $v[shen]}--><script> alert('{lang xigua_hd:shz}');window.history.go(-1);</script><!--{/if}-->
<!--{if $v[color]}--><style>
.seckill_bg{background-color:{$v[color]}}.album_em{background:linear-gradient(to bottom, {$top_c},{$mc})!important;}
.dis_tit,.color-sec{color:$mc!important}.seckill-title-h{border-color:$mc!important}
</style><!--{/if}-->

<div class="fixtop_nav animated fadeInRight">
<!--{if $_SERVER[HTTP_REFERER]}-->
<a class="my-offer" href="$SCRITPTNAME?id=xigua_hd"><i style="position:absolute;left:4px;top:15px" class="iconfont icon-fanhuijiantou f13"></i>{lang xigua_hd:back}</a>
<!--{else}-->
<a class="my-offer" href="$SCRITPTNAME?id=xigua_hd">{lang xigua_hd:sy}</a>
<!--{/if}-->
<!--{if $_G['cache']['plugin']['xigua_hj']}-->
    <a href="$_G['cache']['plugin']['xigua_hj'][jblink]">{lang xigua_hj:wyjb}</a>
<!--{/if}-->
    <a href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=evt">{lang xigua_hd:wode}</a>
    <!--{if $_G['uid'] == $v['uid']}-->
    <a href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=manage">{lang xigua_hd:guanli}</a>
    <!--{/if}-->
    <a class="sharemore" href="javascript:;" >{lang xigua_hd:haibao}</a>
<!--    <a class="telephone" href="tel:{$sh[tel]}" >{lang xigua_hd:lxsj}</a>-->
</div>
<!--{if $v[music]}-->
<div id="audio_btn" class="video_exist play_yinfu" style="display: block;">
    <div id="yinfu" class="rotate"></div>
    <audio loop="loop" id="auto_play" autoplay="autoplay" preload="preload">
        <source src="{$v[music]}" type="audio/mpeg" />
    </audio>
</div>
<!--{/if}-->
<div class="page__bd hong page_pos page__ios">
    <div class="seckill_bg">
        <img src="{$v[album][0]}">
        <em class="album_em"></em>
    </div>

    <div class="seckill-view-c">
        <!--{if $jid>0 && $jv}-->
        <div class="seckill-head">
            <div class="seckill-card radius10">
                <div class="diu_avatar_bg"></div>
                <div class="diu_avatar">
                    <img src="{avatar($jv[uid], 'middle', true)}" />
                </div>
                <p class="diu_username">{$jv[member][username]}<span class="c9">({lang xigua_hd:fqr})</span></p>
                <div class="weui-cell pt0 border_none" style="padding:15px 0">
                    <div class="topna cl">
                        <ul class="cl">
                            <li><p>{lang xigua_hd:yuanjia}</p><span><s class="c9"><em class="f12">&yen;</em>{$v[biaoprice]}</s></span></li>
                            <li><p>{lang xigua_hd:dj}</p><span><b class="color-sec"><em class="f12">&yen;</em>{$v[disprice]}</b></span></li>
                            <li><p>{lang xigua_hd:xjia}</p><span><b class="color-sec"><em class="f12">&yen;</em>{$jv[current]}</b></span></li>
                        </ul>
                    </div>
                </div>
                <!--{if $is_me}-->
<!--{if $jv[status]==1}-->
    <!--{if $jv[hxstatus]==1}-->
    <a class="mt0 weui-btn weui-btn_default" href="javascript:;">{lang xigua_hd:ysy}</a>
    <!--{else}-->
<!--    <a class="mt0 weui-btn weui-btn_primary" onclick="return usenow('');" href="javascript:;">{lang xigua_hd:ljsy}</a>-->
        <p>{lang xigua_hd:xfscs1}</p>
        <img src='$codeurl' style='width:70%;display:block;margin:0 auto;' />
        <p>{lang xigua_hd:hxm1}<em class='main_color'>{$jv[hxcode]}</em></p>
        <p>{lang xigua_hd:syjz1}{echo $v[usetime_u] ? $v[usetime_u] : lang_hd('cqyx', 0)}</p>
    <!--{/if}-->
<!--{elseif !$v[is_end]}-->
    <div class="weui-flex">
    <!--{if $v[orderdis] || $jv[current]<= $v[disprice]}-->
        <a class="mt0 half weui-btn weui-btn_warn" href="javascript:;" onclick="$('#pay_ctrl').popup();">{lang xigua_hd:ljfk}</a>
    <!--{/if}-->

    <!--{if $jv[current]<=$v[disprice]}-->
        <a class="mt0 ml15 half weui-btn weui-btn_default" href="javascript:;">{lang xigua_hd:jjcg}</a>
    <!--{else}-->
        <!--{if $v[selfdis] && !$selfjoin}-->
        <a class="mt0 ml15 half weui-btn weui-btn_primary doclick" data-showid="kcg" data-action="$SCRITPTNAME?id=xigua_hd&ac=discount&did=$did&jid=$jid&formhash={FORMHASH}" href="javascript:;" <!--{if $hd_config[onlyapp]}-->data-onlyapp="1" data-apptip="{$hd_config[apptip]}" data-applink="{$hd_config[applink]}"<!--{/if}-->  >{lang xigua_hd:wyj}</a>
        <!--{else}-->
        <a class="mt0 ml15 half weui-btn weui-btn_primary " id="sharemore" href="javascript:;">{lang xigua_hd:wyj}</a>
        <!--{/if}-->
    <!--{/if}-->
    </div>

                <!--{if $jv[hbnum]>$jv[hbsendnum]}-->
                <div class="f14 c9 hbtip">{lang xigua_hd:bwjj} <em class="color-sec">{$jv[hbmoney]}{lang xigua_hd:yuan}</em> {lang xigua_hd:hb}</div>
                <!--{/if}-->
<!--{/if}-->
                <!--{else}-->
                <div class="weui-flex">
<!--{if $jv[current]<=$v[disprice]}-->
<a class="mt0 ml15 half weui-btn weui-btn_default" href="javascript:;">{lang xigua_hd:jjcg}</a>
<!--{else}-->
<a class="mt0 half weui-btn weui-btn_primary doclick" data-showid="kcg" data-action="$SCRITPTNAME?id=xigua_hd&ac=discount&did=$did&jid=$jid&formhash={FORMHASH}" href="javascript:;" <!--{if $hd_config[onlyapp]}-->data-onlyapp="1" data-apptip="{$hd_config[apptip]}" data-applink="{$hd_config[applink]}"<!--{/if}--> >{lang xigua_hd:btjj}</a>
<!--{/if}-->
                <!--{if $joins}-->
                    <a class="mt0 ml15 half weui-btn weui-btn_primary " href="$SCRITPTNAME?id=xigua_hd&ac=view&did=$did&jid={$joins[id]}">{lang xigua_hd:wddd}</a>
                <!--{else}-->
                    <!--{if $v[end]}-->
                    <a href="javascript:;" class="mt0 ml15 half weui-btn weui-btn_default ">{lang xigua_hd:hdyjs}</a>
                    <!--{else}-->
                    <a href="javascript:;" class="mt0 ml15 half weui-btn weui-btn_primary dojoin">{lang xigua_hd:wycj}</a>
                    <!--{/if}-->
                <!--{/if}-->
                </div>
            <!--{if $jv[hbnum]>$jv[hbsendnum]}-->
                <div class="f14 c9 hbtip">{lang xigua_hd:bwjj} <em class="color-sec">{$jv[hbmoney]}{lang xigua_hd:yuan}</em> {lang xigua_hd:hb}</div>
            <!--{/if}-->
                <!--{/if}-->
                <p class="f12 cl funcbar" style="margin:10px 0">
                    <span class="z">{lang xigua_hd:ll}&nbsp;<em class="color-sec">{$jv[views]}</em></span>
                    <span class="z">{lang xigua_hd:fx}&nbsp;<em class="color-sec">{$jv[shares]}</em></span>
                    <span class="y"><img src="source/plugin/xigua_hd/static/img/kanicon.png" style="width:18px;display: inline-block;">&nbsp;<em class=" color-sec">{$jv[jians]}</em>&nbsp;{lang xigua_hd:cjj}</span>
                </p>
                <p class="f12 cl funcbar">
                    <span class="z" style="margin-right:0">{lang xigua_hd:bhdz}</span>
                    <span class="z">{lang xigua_hd:ll}&nbsp;<em class="color-sec">{$v[views]}</em>&nbsp;</span>
                    <span class="z" style="margin-right:5px">{lang xigua_hd:fx}&nbsp;<em class="color-sec">{$v[shares]}</em>&nbsp;</span>
                    <span class="z">{lang xigua_hd:cy}&nbsp;<em class="color-sec">{$v[joins]}</em></span>
                </p>

            </div>
        </div>
        <!--{else}-->
        <div class="seckill-head">
            <div class="seckill-card radius10">
                <h1 class="dis_tit">$v[title]</h1>
                <p class="dis_pri">
                    <s class="c9 mr10">{lang xigua_hd:yuanjia} <span class="f18"><em class="f12">&yen;</em>{$v[biaoprice]}</span></s>
                    <span>{lang xigua_hd:dj} <b class="color-sec f18"><em class="f12">&yen;</em>{$v[disprice]}</b></span>
                </p>
                <div class="mt10">
                    <p class="sp_desc hmt f14" data-start="{$v[start_u]}" data-end="{$v[end_u]}">{lang xigua_hd:jjsysj}&nbsp;<span class="timer"></span></p>
                    <div class="dis_pribtn"><!--{if $joins[id]}-->
                        <a href="$SCRITPTNAME?id=xigua_hd&ac=view&did=$did&jid={$joins[id]}" class="weui-btn weui-btn_primary">{lang xigua_hd:wddd}</a>
                    <!--{else}-->
                        <!--{if $v[end]}-->
                        <a href="javascript:;" class="weui-btn weui-btn_default">{lang xigua_hd:hdyjs}</a>
                        <!--{else}-->
                        <a href="javascript:;" class="weui-btn weui-btn_primary dojoin">{lang xigua_hd:wycj}</a>
                        <!--{/if}-->
                    <!--{/if}--></div>
                    <p class="f12 cl funcbar">
                        <span class="z">{lang xigua_hd:ll}&nbsp;<em class="color-sec">{$v[views]}</em></span>
                        <span class="z">{lang xigua_hd:fx}&nbsp;<em class="color-sec">{$v[shares]}</em></span>
                        <span class="z">{lang xigua_hd:cy}&nbsp;<em class="color-sec">{$v[joins]}</em></span>
                        <span class="y">{lang xigua_hd:js}&nbsp;<em class=" color-sec">{$v[stock]}</em>&nbsp;{lang xigua_hd:gme}</span>
                    </p>
                </div>
            </div>
        </div>
        <!--{/if}-->
        <div class="seckill-rule seckill-card ">
            <div class="seckill-title-h">{lang xigua_hd:shj}</div>
            <div class="weui-cells seckill_dianjia after_none before_none">
                <div class="weui-cell pt0">
                    <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]"><img src="{$sh[logo]}"></a></div>
                    <div class="weui-cell__bd">
                        <p class="f14" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]">{$sh[name]}</a></p>
                        <p class="f13 c9">{lang xigua_hd:yysj}: <em>{$sh[opentime]}</em></p>
                    </div>
                    <div class="weui-cell__ft"><a class="shtel" <!--{if $sh[teljs]}-->$sh[teljs]<!--{else}-->href="tel:{$sh[tel]}"<!--{/if}-->><i class="iconfont icon-unie607 main_color f30"></i></a></div>
                </div>

                <a class="weui-cell weui-cell_access" style="padding-bottom:0" href="javascript:;" id="v_openLocation" data-lat="{$sh[lat]}" data-lng="{$sh[lng]}" data-name="{$sh[name]}" data-addr="{$sh[addr]}">
                    <div class="weui-cell__hd"><i class="iconfont icon-coordinates main_color mr15 f20"></i></div>
                    <div class="weui-cell__bd">
                        <p class="f14">{$sh[addr]}</p>
                        <p class="f13 c9" id="driving" data-id="$v[shid]"></p>
                    </div>
                    <div class="weui-cell__ft"></div>
                </a>

            </div>
        </div>
        <div class="seckill-rule seckill-card ">
            <div class="seckill-title-h">{lang xigua_hd:jjgz}</div>
            <div class="seckill-rule-c">
                <article class="f14">
                    <section>
                        <p>{echo hd_nl2br($v['jieshao']);}</p>
                        <!--{loop $v[append_img_ary] $__k $__v}-->
                        <p><img src="{$__v}" /></p>
                        <p>{echo hd_nl2br($v[append_text_ary][$__k]);}</p>
                        <!--{/loop}-->
                    <!--{if $hd_config[showalbum]}-->
                        <!--{loop $v[album] $__k $__v}-->
                        <p><img src="{$__v}" /></p>
                        <!--{/loop}-->
                    <!--{/if}-->
                    </section>
                </article>
            </div>
        </div>

<!--{if !$jid}-->
<!--{if $_G['cache']['plugin']['xigua_dp'] && in_array('hd', unserialize($_G['cache']['plugin']['xigua_dp']['opens']))}-->
<style>.gzbtn{background-color:$config[maincolor]}.dp_jx_title,.dp_jx_title .weui_title{margin-top:0}</style>
<div class="seckill-rule seckill-card" id="ptdiv2" style="display:none;padding:0"></div>
<script>
    $.ajax({type: 'get',dataType: 'xml',
        url: '$SCRITPTNAME?id=xigua_dp&ac=jingxuan&inajax=1&type=hd&typeid=$did&shid={$v[shid]}&pagesize=5&page=1',
        success: function (data) {
            if(null==data){ $('#ptdiv2').remove(); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(!s){ $('#ptdiv2').remove(); return false;}
            $('head').append('<link rel="stylesheet" href="source/plugin/xigua_dp/static/jx.css?{VERHASH}" />');
            $('body').append('<script src="source/plugin/xigua_dp/static/dp.js?{VERHASH}"><\/script>');
            $('#ptdiv2').html(s).show();
        },
        error: function () {$('#ptdiv2').remove();}
    });
</script>
<!--{/if}-->
<!--{/if}-->

        <div class="seckill-rule seckill-card seckill-card-last">
            <!--{if $jid>0}-->
            <div class="seckill-title-h">{lang xigua_hd:jjjl}</div>
            <!--{else}-->
            <div class="seckill-title-h">{lang xigua_hd:cyqk}
                <div class="weui-flex dis_tab">
                    <div>
                        <div class="weui-btn weui-btn_mini dis_tab1" >{lang xigua_hd:zxcy}</div>
                    </div>
                    <div>
                        <div class="weui-btn weui-btn_mini dis_tab3 dis_tab_off" >{lang xigua_hd:jjjl}</div>
                    </div>
                    <div class="weui-flex__item">
                        <div class="weui-btn weui-btn_mini dis_tab2 dis_tab_off">{lang xigua_hd:gmajl}</div>
                    </div>
                </div>
            </div>
            <!--{/if}-->

            <div class="seckill-rule-c">
                <div  id="list" class="weui-cells p0" style="background:transparent"></div>
                <!--{template xigua_hb:loading}-->
            </div>
        </div>

        <div class="rule_ask">-&nbsp;{lang xigua_hd:ryyw}&nbsp;-</div>

    </div>
</div>

<div id="joinbox_popup" class='weui-popup__container popup-bottom'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hd:gb}</a>
                <h1 class="title">{lang xigua_hd:txzl}</h1>
            </div>
        </div>
        <div class="modal-content">

            <form  action="$SCRITPTNAME?id=xigua_hd&ac=join" method="post" id="form">
                <input name="formhash" value="{FORMHASH}" type="hidden">
                <input name="id" value="xigua_hd" type="hidden">
                <input name="ac" value="join" type="hidden">
                <input name="did" value="{$v[id]}" type="hidden">
                <div class="weui-cells weui-cells_form" id="searchBar">
                <div class="pdm75">
                        <div class="weui-cell">
                            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hd:zsxm}</label></div>
                            <div class="weui-cell__bd">
                                <input type="text" class="weui-input" placeholder="{lang xigua_hd:qsrxm}" required="required" name="form[realname]" value="$lastrealname">
                            </div>
                        </div>
                        <div class="weui-cell">
                            <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hd:sjhm}</label></div>
                            <div class="weui-cell__bd">
                                <input type="tel" class="weui-input" placeholder="{lang xigua_hd:qsrsjhm}" required="required" name="form[mobile]" value="$lastmobile">
                            </div>
                        </div>

                        <div class="weui-cell weui-cell_switch">
                            <div class="weui-cell__bd"><span class="c9 f15">{lang xigua_hd:fhb}</span>
                            </div>
                            <div class="weui-cell__ft">
                                <input class="weui-switch" id="hbmod" type="checkbox" name="form[hb]" value="1" onclick="return hd_hbmod();">
                            </div>
                        </div>
                        <div class="hbmod none border_top">
                            <div class="weui-cell">
                                <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:hbje}</label></div>
                                <div class="weui-cell__bd">
                                    <input class="weui-input" type="text" name="form[hbmoney]" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:hbje}" value="">
                                </div>
                            </div>
                            <div class="weui-cell">
                                <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:hbgs}</label></div>
                                <div class="weui-cell__bd">
                                    <input class="weui-input" type="tel" name="form[hbnum]" placeholder="{lang xigua_hd:pj}" value="">
                                </div>
                            </div>

                        </div>

                    </div>
            </div>
            <div class="fix-bottom">
                <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hd:fqjj}" />
            </div>

            </form>
        </div>
    </div>
</div>

<div class="hong_res animated zoomIn" id="hong_res">
    <a class="hong_close"><i class="iconfont icon-guanbijiantou f22"></i></a>
    <div class="hong_res_wrap">
        <div class="hong_res_head">
            <div class="hong_res_head_in">
                <img src="{avatar($jv['uid'], 'big', true)}">
            </div>
        </div>
        <div class="hong_res_cnt">
            <div class="hong_res_box">
                <p>{$jv[member][username]}</p>
                <p>{lang xigua_hb:maile}</p>
            </div>
            <div class="hong_res_list">
                <div class="send_title"></div>
                <div class="hong_tip">{lang xigua_hb:gongxihou}</div>
                <div class="money_bg">
                    <p class="hong_money">
                        <i>&yen;</i>
                        <span id="hong_size"></span>
                        <em>{lang xigua_hb:yuan}</em>
                    </p>
                </div>
                <a href="$SCRITPTNAME?id=xigua_hb&ac=qianbao" class="sub_title">{lang xigua_hb:zidongfang}</a>
            </div>
        </div>
        <div class="view_oth">
            <a href="$SCRITPTNAME?id=xigua_hs&ac=hong_list&shid=$shid">{lang xigua_hb:kkdaj}</a>
        </div>
        <div class="sub_bg"></div>
    </div>
</div>

<div id="hb_res" style="display:none">
    <div class="weui-popup__overlay"></div>
    <div class="kcg_hb animated zoomIn">
        <p class="kcg_hb_title"><em class="jianNum"></em><br>{lang xigua_hd:bhdd}<em class="hb_size"></em>{lang xigua_hd:yuan}{lang xigua_hd:hb}</p>
        <p class="kcg_hb_subtitle"><a href="$SCRITPTNAME?id=xigua_hb&ac=qianbao">{lang xigua_hd:ycr}</a></p>
        <a class="kcg_hb_thititle" onclick="$('#hb_res').hide();$('#hb_res').find('.weui-popup__overlay').css('opacity',0);" href="javascript:;">{lang xigua_hb:queding}</a>
    </div>
</div>

<div id="kcg" style="display:none">
    <div class="weui-popup__overlay"></div>
    <div class="kcg_box">
        <img class="kcg_img" src="source/plugin/xigua_hd/static/img/kjje.png">
        <span class="hb_font2">-&yen;<em class="kc_yuan"></em></span>
        <p class="hb_font">{lang xigua_hd:gxcgjj}<em class="kc_yuan"></em>{lang xigua_hd:yuan}<img class="kcg_imginline" src="source/plugin/xigua_hd/static/img/kanicon.png"></p>
        <a class="weui-btn weui-btn_primary" href="javascript:void(0);" onclick="$('#kcg').hide();window.location.reload();">{lang xigua_hb:queding}</a>
    </div>
</div>

<div id="pay_ctrl" class='weui-popup__container popup-bottom'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_hd:qx}</a>
                <h1 class="title">{lang xigua_hd:xzsl}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells before_none after_none">

                <div class="weui-cell before_none">
                    <div class="weui-cell__hd" >
                        <label class="weui-label">{lang xigua_hd:spmc}</label>
                    </div>
                    <div class="weui-cell__bd">
                        <span class="main_color">{$v[title]}</span>
                    </div>
                </div>

                <div class="weui-cell">
                    <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hd:mjly}</label></div>
                    <div class="weui-cell__bd">
                        <input class="weui-input" name="item_note" id="item_note" type="text" placeholder="{lang xigua_hd:mjlytip}">
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd f12 c9" style="padding-right:10px">{lang xigua_hd:gmh}{$v[end_u]}{lang xigua_hd:zsj}</div>
                    <div class="weui-cell__ft main_color">
                        <em id="num_price">{eval echo ($jv[current]);}</em>{lang xigua_hd:yuan}</span>
                    </div>
                </div>

            </div>

            <div class="fix-bottom" style="position: relative">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_primary dobuy" data-jid="$jid" data-did="$did" value="{lang xigua_hd:ljgm}">
            </div>
        </div>
    </div>
</div>

<!--{if $hd_config[showbtmyd]}-->
<!--{if !getcookie('hide_float_btm')}-->
<div class="float_bottom">
    {lang xigua_hd:wyy}
    <!--{if $hd_config[dianimg]}-->
    <a style="color:{$hd_config[diancolor]}" href="javascript:;" class="dwzz_btn">&raquo;{lang xigua_hd:dwzz}</a>
    <!--{else}-->
    <a style="color:{$hd_config[diancolor]}" href="$SCRITPTNAME?id=xigua_hd&ac=my_evt&auto=1">&raquo;{lang xigua_hd:dwzz}</a>
    <!--{/if}-->
    <i class="iconfont icon-guanbijiantou" onclick="$('.float_bottom').remove();hb_setcookie('hide_float_btm', 1, 86400)"></i>
</div>
<!--{/if}-->
<!--{/if}-->

<!--{template xigua_hd:qrcode}-->
<script>
var loadingurl = window.location.href+'&ac=join_li&did=$did&jid=$jid&inajax=1&page=';
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<script>
    var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";
    var QRCODE = '$SCRITPTNAME?id=xigua_hb:qrauto&ode=hd_{$did}__{$jid}', CHANGAN = '{lang xigua_hb:changan}', MUSTSCRB = {echo intval($_G['cache']['plugin']['xigua_hd'][mustscrb]);};
</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hd/static/hd.js?{VERHASH}"></script>
<script>
    $(function () {
        var isPageHide = false;
        window.addEventListener('pageshow', function () {
            if (isPageHide) {
                window.location.reload();
            }
        });
        window.addEventListener('pagehide', function () {
            isPageHide = true;
        });
    });
    var HAS_QIANG = 0, Qlock =0;
    <!--{if $jv[hbnum]>$jv[hbsendnum]}-->
    function showHongBox(jlogid) {
        $.hideLoading();
        if(Qlock || HAS_QIANG){ console.log('false'); return false;}
        Qlock = 1;
        $.ajax({
            type: 'post',
            url: '$SCRITPTNAME?id=xigua_hd&ac=qiang&did=$did&jid=$jid&inajax=1&jlogid='+jlogid,
            data: {'formhash':FORMHASH},
            dataType: 'xml',
            success: function (data) {
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                if(s.indexOf('success')!==-1){
                    HAS_QIANG = 1;
                    $('#hb_res').show().find('.weui-popup__overlay').css('opacity', 1);
                    $('.jianNum').html(jianNum);
                    $('.hb_size').html(s.split('|')[1]);
                }else{
                    tip_common(s);
                }
            },
            error: function () {
            }
        });
    }
    <!--{else}-->
    function showHongBox(jlogid){
        window.location.reload();
    }
    <!--{/if}-->
    function usenow(){
        $.modal({
            title: "{lang xigua_hd:xfscs}",
            text: "<img src='$codeurl' style='width:70%;display:block;margin:0 auto;' /><p>{lang xigua_hd:xfscs1}</p><p>{lang xigua_hd:hxm1}<em class='main_color'>{$jv[hxcode]}</em></p><p>{lang xigua_hd:syjz1}{echo $v[usetime_u] ? $v[usetime_u] : lang_hd('cqyx', 0)}</p>",
            buttons: [
                { text: "{lang xigua_hd:gb}", className: "default", onClick: function(){ } },
            ]
        });
    }
    $('.hmt').each(function () {
        var that = $(this);
        hd_GetRunTime(that.data('start'),that.data('end'), that);
    });
    $('.dis_tab .weui-btn').on('click', function () {
        var that = $(this);
        $('.dis_tab .weui-btn').addClass('dis_tab_off');
        that.removeClass('dis_tab_off');
        if(that.hasClass('dis_tab1')){
            loadingurl = window.location.href+'&ac=join_li&did=$did&jid=$jid&inajax=1&page=';
        }else if(that.hasClass('dis_tab3')){
            loadingurl = window.location.href+'&ac=join_li&did=$did&jid=$jid&inajax=1&jlog=1&page=';
        }else{
            loadingurl = window.location.href+'&ac=join_li&did=$did&jid=$jid&haspay=1&inajax=1&page=';
        }
        page = 1;
        lm = false;
        $("#list").html('');
        load_morelist();
    });

    function menuShareTimeline() {
        menuShareCommon();
    }
    function menuShareCommon() {
        $.ajax({
            type: 'get',
            url: _APPNAME +'?id=xigua_hd&ac=incr&incr_type=shares&jid=$jid&did=$did&inajax=1',
            dataType: 'xml'
        });
    }
    $(document).on('click','.dwzz_btn', function () {
        $.alert("<img src=$hd_config[dianimg] />", "{lang xigua_hb:changan}");
    });
    $(document).on('click','#sharemore, .sharemore', function () {
        menuShareCommon();
        if ($('#audio_btn').hasClass('play_yinfu')) {
            $('#auto_play')[0].pause();
            $('#audio_btn').trigger('click');
        }
        $('#auto_play').remove();
        $.showLoading();
        html2canvas(document.querySelector(".shot_in")).then(canvas => {
            var dataURL = canvas.toDataURL();
            COMCLAS = 'shot_outer';
            $.hideLoading();
            $.alert({
                title: fxqg,
                text: "<img src='"+dataURL+"' />",
                onOK: function () {
                    $('#audio_btn').trigger('click').trigger('click');
                }
            });
            COMCLAS = '';
        });
        return false;
    });
</script>