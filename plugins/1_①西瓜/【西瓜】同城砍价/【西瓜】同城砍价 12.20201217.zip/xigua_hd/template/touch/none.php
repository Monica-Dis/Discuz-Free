<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hd:header}-->
<div class="page__bd">
    <div class="weui-msg">
        <div class="weui-msg__icon-area"><i class="weui-icon-warn weui-icon_msg"></i></div>
        <div class="weui-msg__text-area">
            <h2 class="weui-msg__title">{lang xigua_hd:bnj}</h2>
            <p class="weui-msg__desc">{lang xigua_hd:bnjdesc}</p>
        </div>
        <div class="weui-msg__opr-area">
            <p class="weui-btn-area">
                <a href="$SCRITPTNAME?id=xigua_hs&ac=enter&mobile=2" class="weui-btn weui-btn_primary">{lang xigua_hd:ljrz}</a>
                <a href="javascript:history.back();" class="weui-btn weui-btn_default">{lang xigua_hd:fhsyy}</a>
            </p>
        </div>
        <div class="weui-msg__extra-area">
            <div class="weui-footer">
                <p class="weui-footer__links">
                    <a href="$SCRITPTNAME?id=xigua_hd" class="weui-footer__link">{lang xigua_hd:hdsy}</a>
                </p>
            </div>
        </div>
    </div>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->