<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hd:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
<form  action="$SCRITPTNAME?id=xigua_hd&ac=scan&do=add" method="post" id="form">
    <INPUT TYPE="hidden" name="formhash" value="{FORMHASH}">
    <INPUT TYPE="hidden" name="back" value="{$_GET[back]}">
    <div class="weui-cells__title">{lang xigua_hd:qtx8}</div>
    <div class="weui-cells weui-cells_form">

        <div class="weui-cell weui-cell_vcode">
            <div class="weui-cell__bd">
                <input name="form[code]" class="weui-input" type="tel" placeholder="{lang xigua_hd:qtx8}"> <!--value="{$dftcode}"-->
            </div>
            <div class="weui-cell__ft">
                <button class="weui-vcode-btn" type="submit" id="dosubmit">{lang xigua_hd:ljhx}</button>
            </div>
        </div>
    </div>
    <div class="weui-cells__title">{lang xigua_hd:hxjl}</div>
    <div id="list" class="weui-cells p0 before_none"></div>
    <!--{template xigua_hb:loading}-->

    <div class="footer_fix"></div>
    <div class="bottom_fix"></div>
    <div class="fix-bottom mt10" >
        <a class="weui-btn weui-btn_primary" onclick="<!--{if IN_MAGAPP}-->mag.scanQR(function(text){window.location.href=text});<!--{elseif IN_QIANFAN}-->qianfanScan();<!--{elseif IN_APPBYME}-->appbymeScan();<!--{else}-->wx.scanQRCode();<!--{/if}-->">{lang xigua_hd:smhx}</a>
    </div>
</form>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<script>
    var loadingurl = window.location.href+'&do=scan_li&inajax=1&page=';
    function appbymeScan() {
        sq.scan(function(result){
            window.location.href=result.url;
        });
    }
    function qianfanScan(){
        QFH5.jumpScan(function(state,data){
            if(state==1){
                window.location.href=data.content;
            }else{
            }
        })
    }
    function input_hx_mm(shid) {
        $.prompt("{lang xigua_hs:qsrhxmm}", function(text) {
            $.showLoading();
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hs&ac=setpwd&type=check&inajax=1&shid='+shid,
                data:{formhash:'{FORMHASH}',  hxpwd:text},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    var sar = s.split('|');
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });

        }, function() {
            window.history.go(-1);
        });
    }
</script>