<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hd:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->


    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=manage" class="weui-navbar__item <!--{if !$_GET[stype]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hd:qggl}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=income" class="weui-navbar__item">
            <span>{lang xigua_hd:rzjl}</span>
        </a>
    </div>

    <div  id="list" class="weui-cells p0 "></div>
    <!--{template xigua_hb:loading}-->
</div>

<script src="source/plugin/xigua_hd/static/hd.js?{VERHASH}"></script>
<script>
    var loadingurl = window.location.href+'&do=seckill_li&inajax=1&manage=1&page=';
    var noTit = true;
</script>
<!--{eval $tabbar=1;}-->
<!--{template xigua_hb:common_footer}-->