<?php exit('xxxxx');?>
<!--{loop $list $v}-->
<!--{eval $linfo = unserialize($v['info']['info']);}-->
<a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hd&ac=view&did={$linfo['data']['did']}&jid={$linfo['data']['jid']}">
    <div class="weui-cell__hd weui-head_fix">
        <img class="weui-head_img" src="{avatar($v[orderuser][uid], 'big', true)}" />
        <span class="weui-desc f10">{$v[orderuser][username]}</span>
    </div>
    <div class="weui-cell__bd">
        <p class="main_color f16">+{$v[money]} {lang xigua_hb:yuan}</p>
        <p class="weui-desc"><span class="color-tumblr">{lang xigua_hd:oinfo2}{$v[info][baseprice]}{lang xigua_hb:yuan}</span> <br>{$v[info][subject]}</p>
        <p class="weui-desc color-red">{lang xigua_hd:ddrq}: {$v[indate]}</p>
    </div>
    <div class="weui-cell__ft"></div>
</a>
<!--{/loop}-->
