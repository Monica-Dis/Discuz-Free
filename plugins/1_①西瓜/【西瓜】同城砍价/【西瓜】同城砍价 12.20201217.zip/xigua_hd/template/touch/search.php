<?php exit('xxxxx');?>
<div id="search_popup" class="weui-popup__container" style="z-index:1000">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <form  action="$SCRITPTNAME" method="get" id="searchForm">
                <input name="formhash" value="{FORMHASH}" type="hidden">
                <input name="id" value="xigua_hd" type="hidden">
                <input name="ac" value="index" type="hidden">
                <div class="weui-cells__title">{lang xigua_hd:search}</div>
                <div class="weui-cells weui-cells_form"  id="searchBar">

                    <div class="weui-cell weui-cell_vcode">
                        <div class="weui-cell__hd">
                            <label class="weui-label" style="width:auto"><i class="c9 iconfont icon-sousuo vm"></i></label>
                        </div>
                        <div class="weui-cell__bd">
                            <input type="search" class="weui-input" id="searchInput" placeholder="$hd_config[defaultstxt]" required="required" name="keyword">
                        </div>
                        <div class="weui-cell__ft">
                            <button class="weui-vcode-btn" type="submit">{lang xigua_hd:search}</button>
                        </div>
                    </div>
                </div>
            </form>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_default close-popup" >{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
