<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
if(!$sh[0][name]):
dheader('Location:'.$SCRITPTNAME.'?id=xigua_hd&ac=none'.$urlext);
endif;
}--><!--{template xigua_hd:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd" <!--{if $ac == 'edit'}-->style="display:none"<!--{/if}-->>
<!--{template xigua_hb:common_nav}-->
<div class="weui-navbar">
    <a href="$SCRITPTNAME?id=xigua_hd&ac=my_evt&is_my=1" class="weui-navbar__item <!--{if !$_GET[offline]&&!$_GET[shen]}-->weui_bar__item_on<!--{/if}-->">
        <span>{lang xigua_hd:jxz}</span>
    </a>
    <a href="$SCRITPTNAME?id=xigua_hd&ac=my_evt&is_my=1&shen=1" class="weui-navbar__item <!--{if $_GET[shen]}-->weui_bar__item_on<!--{/if}-->">
        <span>{lang xigua_hd:dsh}</span>
    </a>
    <a href="$SCRITPTNAME?id=xigua_hd&ac=my_evt&is_my=1&offline=1" class="weui-navbar__item <!--{if $_GET[offline]==1}-->weui_bar__item_on<!--{/if}-->">
        <span>{lang xigua_hd:yjs}</span>
    </a>
    <a href="$SCRITPTNAME?id=xigua_hd&ac=my_evt&is_my=1&offline=2" class="weui-navbar__item <!--{if $_GET[offline]==2}-->weui_bar__item_on<!--{/if}-->">
        <span>{lang xigua_hd:yxj}</span>
    </a>
</div>

<div>
    <div id="list" class="mod-post x-postlist p0">

    </div>

    <!--{template xigua_hb:loading}-->
</div>

<div class="footer_fix"></div>
</div>


<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>
<form action="$SCRITPTNAME?id=xigua_hd&ac=my_evt&do=add" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}" >
    <input type="hidden" name="form[id]" value="{$old_data[id]}" >
    <input type="hidden" name="st" value="{echo $old_data ? $old_data['stid'] : $_GET[st]}" >
<!--    <input type="hidden" name="form[lat]" value="{$old_data['lat']}">
    <input type="hidden" name="form[lng]" value="{$old_data['lng']}">
    <input type="hidden" name="form[province]" value="{$old_data['province']}">
    <input type="hidden" name="form[city]" value="{$old_data['city']}">
    <input type="hidden" name="form[district]" value="{$old_data['district']}">
    <input type="hidden" name="form[street]" value="{$old_data['street']}">
    <input type="hidden" name="form[street_number]" value="{$old_data['street_number']}">-->

    <div id="new_popup" class="weui-popup__container" style="z-index:1000">
        <div class="weui-popup__modal">
            <div class="fixpopuper">
                <div class="weui-cells__title">{lang xigua_hd:new_discount}</div>
                <div class="weui-cells ">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hd:title}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[title]" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:title}" value="{$old_data[title]}">
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:spkc}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="tel" name="form[stock]" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:spkc}" value="{$old_data[stock]}">
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:spyj}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[biaoprice]" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:spyj}" value="{$old_data[biaoprice]}">
                        </div>
                        <div class="well-cell__ft">{lang xigua_hd:yuan}</div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:spdj}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[disprice]" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:spdj}" value="{$old_data[disprice]}">
                        </div>
                        <div class="well-cell__ft">{lang xigua_hd:yuan}</div>
                    </div>

                    <div class="weui-cell weui-cell_switch">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hd:mddj}</label>
                        </div>
                        <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hd:mddjkf}</span>
                        </div>
                        <div class="weui-cell__ft">
                            <input class="weui-switch" type="checkbox" name="form[orderdis]" value="1" <!--{if $old_data[orderdis]}-->checked<!--{/if}-->>
                        </div>
                    </div>

                    <div class="weui-cell weui-cell_switch">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hd:zjjj}</label>
                        </div>
                        <div class="weui-cell__bd"><span class="c9 f14">{lang xigua_hd:sfyxzj}</span>
                        </div>
                        <div class="weui-cell__ft">
                            <input class="weui-switch" type="checkbox" name="form[selfdis]" value="1" <!--{if $old_data[selfdis]}-->checked<!--{/if}-->>
                        </div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:kssj}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input time_ctrl" name="form[starttime]" type="text" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:kssj}" value="{echo $old_data ? $old_data[start_u] : date('Y-m-d H:i');}">
                        </div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hd:jssj}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input time_ctrl" name="form[endtime]" type="text" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:jssj}" value="{echo $old_data ? $old_data[end_u] : date('Y-m-d H:i', TIMESTAMP+2592000);}">
                        </div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="name" class="weui-label">{lang xigua_hd:syjz}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input time_ctrl" name="form[usetime]" type="text" placeholder="{lang xigua_hd:plzyxq}" value="{$old_data[usetime_u]}">
                        </div>
                    </div>
                    <!--{if $sh}-->
                    <div class="weui-cell weui-cell_access">
                        <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hd:sydp}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input choose_ctrl" name="form[shname]" type="text" value="{echo $old_data?$old_data['shname']:$dftshname}" placeholder="{lang xigua_hd:qxzsydp}">
                        </div>
                        <div class="weui-cell__ft"></div>
                    </div>
                    <!--{/if}-->
                </div>

                <div class="weui-cells__title">{lang xigua_hd:gjsz}</div>
                <div class="weui-cells ">
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:kjjzs}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[zong]" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:kjjzs}" value="{$old_data[zong]}">
                        </div>
                        <div class="well-cell__ft">{lang xigua_hd:c}</div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:mcjjxx}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[xiaxian]" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:mcjjxx}" value="{$old_data[xiaxian]}">
                        </div>
                        <div class="well-cell__ft">{lang xigua_hd:yuan}</div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:mcjjsx}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[shangxian]" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:mcjjsx}" value="{$old_data[shangxian]}">
                        </div>
                        <div class="well-cell__ft">{lang xigua_hd:yuan}</div>
                    </div>
                </div>

                <div class="weui-cells__title">{lang xigua_hd:jjxq}</div>
                <div class="weui-cells ">

                    <div class="weui-cell weui-cell_access" onclick='$("#edit_jieshao").popup();'>
                        <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hd:jjxq}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" readonly placeholder="{lang xigua_hd:djspxq}">
                        </div>
                        <div class="weui-cell__ft"></div>
                    </div>

                    <div class="weui-cell">
                        <div class="weui-cell__bd">
                            <div class="weui-uploader">
                                <div class="weui-uploader__hd">
                                    <p class="weui-uploader__title">{lang xigua_hd:splbt}</p>
                                    <div class="weui-uploader__info">{echo str_replace('n', $hd_config['maximg'], lang_hd('zuiduozhao',0))}
                                    </div>
                                </div>
                                <div class="weui-uploader__bd">
                                    <ul class="weui-uploader__files" data-max="{$hd_config['maximg']}" data-maxtip="{echo str_replace('n', $hd_config['maximg'], lang_hd('zuiduozhao',0))}">
                                        <!--{loop $old_data[album] $img}-->
                                        <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/>
                                            <div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                        </li>
                                        <!--{/loop}-->
                                    </ul>
                                    <div class="weui-uploader__input-box">
                                        <!--{if HB_INWECHAT && $config[multiupload]}-->
                                        <a class="weui-uploader__input" data-name="form[album]" data-multi="1"></a>
                                        <!--{else}-->
                                        <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                        <!--{/if}-->
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="weui-cells__title">{lang xigua_hd:qtsz}</div>
                <div class="weui-cells ">

                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="time" class="weui-label">{lang xigua_hd:hdyy}</label></div>
                        <div class="weui-cell__bd">
                            <input class="weui-input" type="text" name="form[music]" placeholder="{lang xigua_hd:mp3}" value="{$old_data[music]}">
                        </div>
                    </div>
                    <div class="weui-cell">
                        <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hd:ztys}</label></div>
                        <div class="weui-cell__bd enter_addr">
                            <input id="choose_color" class="weui-input" name="form[color]" type="text" value="{$old_data[color_title]}" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:ztys}" data-value="{$old_data[color]}">
                        </div>
                    </div>
                </div>

                <div class="fix-bottom mt10" style="position:relative">
                    <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_hb:queding}"/>
                    <!--{if $ac != 'edit'}-->
                    <a class="weui-btn weui-btn_default close-popup">{lang xigua_hb:quxiao}</a>
                    <!--{else}-->
                    <a class="weui-btn weui-btn_default" href="javascript:window.history.go(-1);">{lang xigua_hd:gb}</a>
                    <!--{/if}-->
                </div>
            </div>
        </div>
    </div>
        <div id="edit_jieshao" class="weui-popup__container" style="z-index:1000">
        <div class="weui-popup__modal bgf8">
            <div class="fixpopuper">
                <div class="weui-cells__title">{lang xigua_hd:bjsp}</div>
                <div class="weui-cells ">
                    <div class="weui-cell">
                        <div class="weui-cell__bd">
                            <textarea class="weui-textarea" name="form[jieshao]" placeholder="{lang xigua_hd:txspxq}"
                                      rows="3">{$old_data[jieshao]}</textarea>
                        </div>
                    </div>
                </div>

                <div class="weui-cells before_none nobg center_upload">
                    <div class="weui-cell" id="first_append_img">
                        <div class="weui-cell__bd">
                            <div class="weui-uploader">
                                <div class="weui-uploader__bd">
                                    <div class="weui-uploader__input-box">
                                        <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                        <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                        <!--{else}-->
                                        <input class="center_upload__input" data-name="form[append_img]" type="file">
                                        <!--{/if}-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!--{loop $old_data[append_text_ary] $__k $__v}-->
                    <div class="weui-cell bgf" id="arear_{$__k}">
                        <ul id="cimg_{$__k}" data-only="1">
                            <li class="weui-uploader__file weui-uploader__file_status"
                                style="background-image:url({$old_data['append_img_ary'][$__k]})">
                                <input type="hidden" name="form[append_img][{$__k}]"
                                       value="{$old_data['append_img_ary'][$__k]}">
                                <div class="weui-uploader__file-content"><i
                                            class="weui-icon-warn iconfont icon-shanchu"></i></div>
                            </li>
                        </ul>
                        <div class="weui-cell__bd">
                            <textarea class="weui-textarea" placeholder="{lang xigua_hd:inputtext}" rows="3"
                                      name="form[append_text][{$__k}]">{$__v}</textarea>
                        </div>
                        <a class="iconfont icon-guanbijiantou closeHt" data-index="{$__k}"></a>
                    </div>
                    <div class="weui-cell" id="cell_{$__k}">
                        <div class="weui-cell__bd">
                            <div class="weui-uploader">
                                <div class="weui-uploader__bd">
                                    <div class="weui-uploader__input-box">
                                        <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                        <a class="center_upload__input" data-name="form[append_img]" type="file"></a>
                                        <!--{else}-->
                                        <input class="center_upload__input" data-name="form[append_img]" type="file">
                                        <!--{/if}-->
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--{/loop}-->
                </div>

                <div class="fix-bottom" id="center_upload_btn" style="position:relative">
                    <a class="mt0 weui-btn weui-btn_default" onclick='$.closePopup();return cropCallback();'
                       href="javascript:;">{lang xigua_hd:wcbj}</a>
                </div>
            </div>
        </div>
    </div>
    <div id="popctrl" class="weui-popup__container" style="z-index:1001">
        <div class="weui-popup__modal">
            <div style="height: 100vh"><img id="photo"></div>
            <div class="pub_funcbar">
                <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
                <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
            </div>
        </div>
    </div>
</form>

<a href="javascript:full_input(this, 0);" class="float_btn"><i class="iconfont icon-zengjia"></i> {lang xigua_hd:new_pub}</a>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$hd_config[mkey]}"></script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script>
    var mkey = '{$hd_config[mkey]}';
    <!--{if $ac == 'edit' || $_GET[auto]}-->
    $('#new_popup').popup();
    <!--{else}-->
    var loadingurl = window.location.href + '&ac=evt_li&is_my=1&inajax=1&page=';
    <!--{/if}-->
    var itar = [];
    <!--{loop $sh $_sh}-->
    itar.push({title: '{$_sh[name]}'});
    <!--{/loop}-->
    function full_input(ob, id){
        var fd = ['id', 'realname', 'mobile', 'dist', 'address', 'postcode'];
        for (var i in fd) {
            var h = $(ob).data(fd[i]);
            if (typeof h === 'undefined') {
                h = '';
            }
            $('[name="form[' + fd[i] + ']"]').text(h + '').val(h + '');
        }
        $('#new_popup').popup();
        return false;
    }

    var icolor = [];
    <!--{loop $shcolor $_title $_color}-->
    icolor.push({title:'{$_title}', value:'{$_color}', style:'color:{$_color}'});
    <!--{/loop}-->
    $("#choose_color").select({
        title: "{lang xigua_hs:desc_color}",
        items: icolor
    });
    $(document).on('click','.stock-del', function () {
        var that = $(this);
        $.confirm({
            <!--{if $_GET[offline]==2}-->
            title: '{lang xigua_hd:qrsj}',
            text: '{lang xigua_hd:qrsj}',
            <!--{else}-->
            title: '{lang xigua_hd:qrxj}',
            text: '{lang xigua_hd:qrxjtip}',
            <!--{/if}-->
            onOK: function () {
                $.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_hd&ac=stock_edit&do={eval echo $_GET[offline]==2? "shangjia": "del"}&inajax=1',
                    data:{formhash:'{FORMHASH}', did: that.data('id')},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });
    });
</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.min.js" charset="utf-8"></script>
<script src="source/plugin/xigua_hd/static/hd.js?{VERHASH}"></script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<!--{template xigua_hd:enter_up}-->