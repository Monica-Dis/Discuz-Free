<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="dis_list">
    <div class="dis_row jump_dis" data-id="{$v[id]}">
        <div class="dis_pic">
            <img src="{$v[album][0]}">
            <div class="dis_mask"><div class="title">{$v[title]}</div></div>
        </div>
        <div class="dis_pir weui-flex">
            <div class="weui-flex__item">
                <p class="price">
                    <span class="color-sec">{lang xigua_hd:disprice} &yen;<em class="f18">{$v[disprice]}</em></span>
                    <s class="c9 f12">{lang xigua_hd:biaoprice} &yen;{$v[biaoprice]}</s>
                </p>
                <p class="discount f12">
                    <span>{lang xigua_hd:yu} <em class="color-sec">{$v[joins]}</em> {lang xigua_hd:rcyjj}</span>
                    <span>{lang xigua_hd:ll} <em class="color-sec">{$v[views]}</em></span>
                    <span>{lang xigua_hd:fx} <em class="color-sec">{$v[shares]}</em></span>
                </p>
                <!--{if $v[end]}--><div class="wxexpired1 wxexpired" style="top:-20px;height:100px;"></div><!--{/if}-->
            </div>
            <!--{if !$v[end]}-->
            <div class="weui-btn weui-btn_mini f14 ">{lang xigua_hd:qjj}</div>
            <!--{else}-->
            <div class="weui-btn f14 weui-btn_default">{lang xigua_hd:yjs}</div>
            <!--{/if}-->
        </div>
    </div>
    <!--{if $_GET[is_my]}-->
    <div class="button-sp-area">
        <a href="$SCRITPTNAME?id=xigua_hd&ac=edit&did={$v[id]}&st={$v[stid]}&stid={$v[stid]}" class="weui-btn weui-btn_mini hm_c_btn ">{lang xigua_hd:xg}</a>
        <!--{if $_GET[offline]==2}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn stock-del" data-id="{$v[id]}">{lang xigua_hd:s}</a>
        <!--{else}-->
        <a href="javascript:;" class="weui-btn weui-btn_mini hm_c_btn stock-del" data-id="{$v[id]}">{lang xigua_hd:x}</a>
        <!--{/if}-->
    </div>
    <!--{/if}-->
</div>
<!--{/loop}-->