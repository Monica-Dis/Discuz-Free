<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hd:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->


    <div class="weui-navbar">
        <a href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=evt" class="weui-navbar__item <!--{if !$_GET[status]&&!$_GET[hx]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hb:quanbu}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=evt&status=-1" class="weui-navbar__item <!--{if $_GET[status]==-1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hd:wzf}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=evt&status=1&hx=-1" class="weui-navbar__item <!--{if $_GET[hx]==-1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hd:wsy}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_hd&ac=my_order&do=evt&status=1&hx=1" class="weui-navbar__item <!--{if $_GET[hx]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hd:ysy}</span>
        </a>
    </div>

    <div  id="list" class="weui-cells p0 mt0 before_none"></div>
    <!--{template xigua_hb:loading}-->
</div>

<script src="source/plugin/xigua_hd/static/hd.js?{VERHASH}"></script>
<script>
var loadingurl = window.location.href+'&do=seckill_li&inajax=1&page=';
</script>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
<script>
$(document).on('click','.hb_add', function () {
    var that= $(this);
    $.prompt({
        title: '{lang xigua_hd:shbtip}',
        empty: false,
        onOK: function (input) {
            var _hbnum = $('#_hbnum');
            var _hbmoney = $('#weui-prompt-input');
            if(_hbnum.val() <=0){
                return false;
            }
            if(_hbmoney.val() <=0){
                return false;
            }
            var actfield =$('#account');
            $.showLoading();
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hd&ac=sendhb&inajax=1',
                data:{formhash:'{FORMHASH}', hbnum:_hbnum.val(), hbmoney:_hbmoney.val(), jid:that.data('jid'), did:that.data('did')},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }
    });
    $('#weui-prompt-input').replaceWith('<input class="weui-prompt-input needsclick weui-input needsclick_input" type="text" id="weui-prompt-input" placeholder="{lang xigua_hd:qtx}{lang xigua_hd:hbje}" />');
    $('.weui-dialog__bd').after('<div class="dialog_custom"><div><input id="_hbnum" class="weui-input needsclick_input" type="tel" placeholder="{lang xigua_hd:pj}"></div></div>');
});
</script>