<?php exit('xxxx');?>
<!--{template xigua_hd:header}-->
<!--{if $error!=lang_hd('whxqx',0)}-->
<script>
    $.alert('$error', function () {
        window.location.href = _APPNAME+'?id=xigua_hd&ac=scan'+_URLEXT;
    });
</script>
<!--{else}-->
<script>
    function input_hx_mm(shid) {
        $.prompt("{lang xigua_hs:qsrhxmm}", function(text) {
            $.showLoading();
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hs&ac=setpwd&type=check&inajax=1&shid='+shid,
                data:{formhash:'{FORMHASH}',  hxpwd:text},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    var sar = s.split('|');
                    tip_common(s);
                    setTimeout(function () {
                        window.location.href = location.href+'&time='+((new Date()).getTime());
                    }, 2000);
                },
                error: function () {
                    $.hideLoading();
                }
            });

        }, function() {
            window.location.href = location.href+'&time='+((new Date()).getTime());
        });
    }
    input_hx_mm({$jv['shid']});
</script>
<!--{/if}-->
<!--{eval $tabbar=0;}-->
<!--{template xigua_hb:common_footer}-->
