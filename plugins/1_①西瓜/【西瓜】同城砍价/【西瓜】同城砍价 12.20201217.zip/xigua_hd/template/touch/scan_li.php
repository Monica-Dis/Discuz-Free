<?php exit('xxxxx');?>
<!--{loop $list $v}-->
<a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hd&ac=view&did=$v[did]&jid={$v[id]}">
    <div class="weui-cell__hd weui-head_fix">
        <img class="hm_order_avatar" src="{avatar($v[hxuid], 'middle', true)}" />
    </div>
    <div class="weui-cell__bd">
        <div class="weui-desc">{$v[hxuser][username]} {echo dgmdate($v[hxcrts],'Y-m-d H:i')} <!--{if !$v[addrid]}-->{lang xigua_hd:hx}<!--{else}-->{lang xigua_hd:fh}<!--{/if}--></div>
        <!--{if $v[order_id]}--><div class="f12 c9">{lang xigua_hd:order_id}: $v[order_id]</div><!--{/if}-->
        <!--{if !$v[addrid]}--><div class="f12 c9">{lang xigua_hd:hxm}: $v[hxcode]</div><!--{/if}-->
    </div>
    <div class="weui-cell__ft"></div>
</a>
<!--{/loop}-->
