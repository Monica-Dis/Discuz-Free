<?php exit('xxxxxxx');?>
<script src="source/plugin/xigua_hd/static/html2canvas.min.js"></script>
<!--{eval $shot_img = $v[album][0]?$v[album][0]:$v[append_img_ary][0];}-->
<!--{eval
$shot_file = 'source/plugin/xigua_hd/cache/'.md5($shot_img).'.png';
if(strpos($shot_img, $_G[siteurl])===false):
    if(!is_file(DISCUZ_ROOT.$shot_file)):
        file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($shot_img));
    endif;
    $shot_img = $shot_file;
endif;
}-->
<div id="shot" style="position:fixed;bottom:-100000px">
    <div class="shot_in">
    <div class="qr_pr">
        <img src="{$shot_img}" crossOrigin="anonymous" class="qr_img_src"/>
        <div class="qr_time"><!--{if $v[end_u]}-->{lang xigua_hd:jzrq}:<em><!--{$v[end_u]}--></em><!--{else}--><em>{lang xigua_hd:cqyx}</em><!--{/if}--></div>
    </div>
    <div class="qr_outer cl">
        <div class="cl y qrfield">
            <div class="wide_border"></div>
            <!--{if $config[qraut]}-->
            <img src="$SCRITPTNAME?id=xigua_hb:qrauto&ode=hd_{$did}__{$jid}{$urlext}" />
            <!--{else}-->
            <img src="$SCRITPTNAME?id=xigua_hd:qrcode&jid=$jid&did=$did&qrcode=1{$urlext}" />
            <!--{/if}-->
            <div class="qrfield_c qrfield_c1">{lang xigua_hd:casbewm}</div>
            <div class="qrfield_c qrfield_c2"></div>
            <div class="qrfield_c qrfield_c3"></div>
            <div class="qrfield_c qrfield_c4"></div>
        </div>
        <div class="info_field cl tl">
            <p class="ca2 mb10 f14"><em class="qr_tag">{lang xigua_hd:jj}</em> {$jv[member][username]}{lang xigua_hd:zzcj}$v[title]</p>
            
            <p class="c9 f14 mb10">
                <span class="qr_tag">{lang xigua_hd:dj}<em class="ding_price_btn">$v[disprice]{lang xigua_hd:yuan}</em></span>
                <em>{lang xigua_hd:yuanjia}<s>$v[biaoprice]{lang xigua_hd:yuan}</s></em>
            </p>
            <p class="c9 f14">
                {lang xigua_hd:catpbcgghy}
            </p>
        </div>
    </div>
    </div>
</div>