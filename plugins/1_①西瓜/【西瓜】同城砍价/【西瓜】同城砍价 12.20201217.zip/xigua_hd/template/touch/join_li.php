<?php exit('xxxx');?>
<!--{loop $list $v}-->
<!--{if $jid||$_GET[jlog]}-->
<a class="weui-cell" href="javascript:;" style="padding:10px 0">
    <div class="weui-cell__hd weui-head_fix" style="margin-right:10px">
        <img class="hm_order_avatar" src="{avatar($v[uid], 'middle', true)}" />
    </div>
    <div class="weui-cell__bd">
        <div class="weui-desc">{$users[$v[uid]][username]}</div>
        <div class="f12 c9">{eval echo dgmdate($v['crts'], 'u')}</div>
    </div>
    <div class="weui-cell__ft f12">
        <img src="source/plugin/xigua_hd/static/img/kanicon.png" style="width:18px" />
        <!--{if $_GET[jlog]}-->{lang xigua_hd:b} {$jinfos[$v[jid]][username]}<br>{lang xigua_hd:jj}<!--{else}-->{lang xigua_hd:bjj}<!--{/if}-->
         <em class="color-sec">{$v[money]}</em> {lang xigua_hd:yuan}
        <!--{if $hbinfos[$v[hbid]][size]>0}-->
        <p class="hb_item">{lang xigua_hd:bhd} <em class=" color-sec">{$hbinfos[$v[hbid]][size]}</em> {lang xigua_hd:yuan}{lang xigua_hd:hb}</p>
        <!--{/if}-->
    </div>
</a>
<!--{else}-->
<a class="weui-cell" href="$SCRITPTNAME?id=xigua_hd&ac=view&did=$v[did]&jid={$v[id]}" style="padding:10px 0">
    <div class="weui-cell__hd weui-head_fix" style="margin-right:10px">
        <img class="hm_order_avatar" src="{avatar($v[uid], 'middle', true)}" />
    </div>
    <div class="weui-cell__bd">
        <div class="weui-desc">{$users[$v[uid]][username]}</div>
        <!--{if $_GET[haspay]}-->
        <div class="f12 c9">{eval echo dgmdate($orders[$v[order_id]][payupts]?$orders[$v[order_id]][payupts]:$v['crts'], 'u')} {lang xigua_hd:gm}</div>
        <!--{else}-->
        <div class="f12 c9">{eval echo dgmdate($v['crts'], 'u')} {lang xigua_hd:fqjj}</div>
        <!--{/if}-->
    </div>
    <!--{if $_GET[haspay]}-->
    <div class="weui-cell__ft f12">{lang xigua_hd:xf} <em class="color-sec">{echo $orders[$v[order_id]][baseprice] ? $orders[$v[order_id]][baseprice] : 0}</em> {lang xigua_hd:yuan}</div>
    <!--{else}-->
    <div class="weui-cell__ft f12"><img src="source/plugin/xigua_hd/static/img/kanicon.png" style="width:18px" /> {lang xigua_hd:jz} <em class="color-sec">{$v[current]}</em> {lang xigua_hd:yuan}</div>
    <!--{/if}-->
</a>
<!--{/if}-->
<!--{/loop}-->