<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<!--{eval $dinfo = $dlist[$v[did]];}-->
<div class="sp_item sec_item <!--{if $v[hxstatus]==1}-->hasend<!--{/if}-->" >
    <div class="sp_thumb m_jump" data-did="{$v[did]}" data-jid="{$v[id]}"><img src="{echo $dinfo['album'][0] ?$dinfo['album'][0]: $dinfo['append_img_ary'][0]}"></div>
    <div class="sp_main">
        <div class="sp_content">
            <div class="weui-flex">
                <h3 class="weui-flex__item"><a class="m_jump" data-did="{$v[did]}" data-jid="{$v[id]}" href="javascript:;">{$dinfo[title]}</a></h3>
            </div>
        <!--{if $v[status]==0}-->
            <p class="sp_desc mt10">
                <span><em class="color-sec f18"> {echo $v[current]}</em><em class="color-sec f14">{lang xigua_hd:yuan}</em>
                    <s class="f12 c9 ">{lang xigua_hd:yuanjia}:{$dinfo[biaoprice]}{lang xigua_hd:yuan}</s></span>
            </p>
            <p class="sp_desc">
                <span>{$users[$v[uid]][username]} <em class="f12 c9">$v[crts_u]</em></span>
            </p>
            <!--{if !$manage}-->
        <!--{if $v[current]> $dinfo[disprice] && (($dinfo[zong]&&$v[jians]<$dinfo[zong])||!$dinfo[zong])}-->
            <a class="weui-btn percent-btn m_jump mt0" style="position:relative;" data-did="{$v[did]}" data-jid="{$v[id]}" href="javascript:;">{lang xigua_hd:jxjianjia}</a>

            <!--{if $v[hbnum]==$v[hbsendnum]}-->
            <a href="javascript:;"  class="weui-btn percent-btn hb_add mt0" style="position:relative;" data-did="{$v[did]}" data-jid="{$v[id]}">{lang xigua_hd:shb}</a>
            <!--{/if}-->

        <!--{/if}-->
        <!--{if !$dinfo[is_end] && ($dinfo[orderdis] || $v[current]<= $dinfo[disprice])}-->
            <a class="weui-btn percent-btn mt0" style="position:relative;" href="$v[jumpurl]">{lang xigua_hd:ljfk}</a>
        <!--{/if}-->
            <!--{/if}-->
        <!--{else}-->
            <p class="sp_desc c9">{lang xigua_hd:usetime}: {eval echo $dinfo[usetime_u] ? $dinfo[usetime_u] : lang_hd('cqyx', 0)}</p>
            <p class="sp_desc mt10">
                <span><em class="color-sec f18"> {echo $v[current]}</em><em class="color-sec f14">{lang xigua_hd:yuan}</em>
                <s class="f12 c9 ">{lang xigua_hd:yuanjia}:{$dinfo[biaoprice]}{lang xigua_hd:yuan}</s>
                </span>
            </p>
            <p>
                <span>{$users[$v[uid]][username]} <em class="f12 c9">$v[crts_u]</em></span>
            </p>
            <!--{if !$manage}-->
                <a class="weui-btn percent-btn weui-btn_warn" style="position:relative;" href="$SCRITPTNAME?id=xigua_hd&ac=view&did=$v[did]&jid=$v[id]"  <!--{if $v[hxstatus]==1}-->style="background-color:#cdcdcd"<!--{/if}-->><!--{if $v[hxstatus]==1}-->{lang xigua_hd:ysy}<!--{else}-->{lang xigua_hd:wsy}<!--{/if}--></a>
            <!--{/if}-->
        <!--{/if}-->
            <!--{if $manage}-->
        <!--{if $v[liuyan]}-->
            <p class="sp_desc c9">{lang xigua_hd:ly}: $v[liuyan]</p>
        <!--{/if}-->
            <!--{if $v[status]==1}-->
                <!--{if $v[hxstatus]==1}-->
                <p class="sp_desc c9">{lang xigua_hd:dhm}: $v[hxcode]</p>
                <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hd&ac=view&did=$v[did]&jid=$v[id]">{lang xigua_hd:yhx}</a>
                <!--{else}-->
                <a class="weui-btn percent-btn" href="$SCRITPTNAME?id=xigua_hd&ac=scan&did=$v[did]&jid=$v[id]&back=manage">{lang xigua_hd:djhx}</a>
                <!--{/if}-->
            <!--{elseif $dinfo[stock]>0 && ($dinfo['endtime']==0||$dinfo[endtime]>TIMESTAMP)}-->
                <a class="weui-btn percent-btn" href="$v[jumpurl]" style="background-color:#cdcdcd">{lang xigua_hd:dzf}</a>
            <!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{/loop}-->