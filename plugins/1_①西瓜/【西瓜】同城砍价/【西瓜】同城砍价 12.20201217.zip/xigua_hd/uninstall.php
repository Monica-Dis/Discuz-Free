<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
DROP TABLE pre_xigua_hd_cat;
DROP TABLE pre_xigua_hd_dis;
DROP TABLE pre_xigua_hd_income;
DROP TABLE pre_xigua_hd_jlog;
DROP TABLE pre_xigua_hd_join;
EOT;
runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/install.php');

xwb_delall(DISCUZ_ROOT . "./source/plugin/xigua_hd");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_hd");

$finish = TRUE;

function xwb_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwb_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}