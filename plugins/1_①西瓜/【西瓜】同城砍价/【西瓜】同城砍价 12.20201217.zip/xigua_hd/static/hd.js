function hd_hbmod() {
    if($('#hbmod:checked').length){
        $('.hbmod').show();
    }else{
        $('.hbmod').hide();
    }
    return true;
}

function showkcg(yen){
    var showid = $('#kcg');
    showid.find('.weui-popup__overlay').css('opacity', 1);
    showid.show();
    showid.find('.kc_yuan').html(yen);
}

$(document).on('click', '.jump_dis', function () {
    var that = $(this);
    var jmpurl = _APPNAME +'?id=xigua_hd&ac=view&did='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
    if(typeof mag !== 'undefined'){
        mag.newWin(GSITE+jmpurl);
        return false;
    }
    if(typeof wx !=='undefined'){
        if (window.__wxjs_environment === 'miniprogram') {
            wx.miniProgram.navigateTo({url:'/pages/index/index?url='+encodeURIComponent(GSITE+jmpurl)});
            return false;
        }
    }
    window.location.href = jmpurl;
    return false;
});
var jianNum = '';
$(document).on('click', '.doclick', function () {
    var that = $(this);
    $.showLoading();
    if(that.attr('disabled')){
        return false;
    }
    if(MUSTSCRB) {
        var hdsubscribe = 1;
        $.ajax({
            type: 'post',
            url: _APPNAME + '?id=xigua_hb&ac=checksub&inajax=1',
            data: {formhash: FORMHASH},
            dataType: 'xml',
            async: false,
            success: function (data) {
                if (null == data) {
                    return false;
                }
                var s = $.trim(data.lastChild.firstChild.nodeValue);
                if (s.split('|')[1] != 'subscribe') {
                    $.alert("<img src='" + QRCODE + "' /><br>" + CHANGAN, CHANGAN);
                    hdsubscribe = 0;
                }
            }
        });
        if (!hdsubscribe) {
            $.hideLoading();
            return false;
        }
    }
    if(that.data('onlyapp') && !IN_APP){
        $.alert(that.data('apptip'), function() {
            window.location.href = that.data('applink');
        });
        return false;
    }
    that.attr('disabled', '1');
    $.ajax({
        type: 'post',
        url: that.attr('data-action') + '&inajax=1',
        data: that.serialize(),
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            that.removeAttr('disabled');
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(/^\d+(\.\d+)?$/.test(s.split('|')[1])){
                showkcg(s.split('|')[1]);
            }else{
                tip_common(s);
                jianNum = s.split('|')[1];
                $('.sharemore').trigger('click');
            }
        },
        error: function () {
            $.hideLoading();
            that.removeAttr('disabled');
        }
    });
    return false;
});
$(document).on('click', '.dojoin', function () {
    if(UID<1){
        $.showLoading();
        window.location.href = 'member.php?mod=logging&action=login&referer=' + DREFER;
        return false;
    }
    $("#joinbox_popup").popup();
    return false;
});
$(document).on('click','.inc-num', function () {
    var ipt = $('.inc-input'), that = $(this);
    var num = parseInt(ipt.val());
    if(parseInt(that.data('step'))===1){
        if (!ipt.data('max') || num <ipt.data('max')) {
            ipt.val(++num);
        }
    }else{
        if (num > 1) {
            ipt.val(--num);
        }
    }
    var nu = parseInt(ipt.val());
    $('#num_display').text(nu);
    var num_rs = nu*parseFloat(ipt.data('price'))+parseFloat(ipt.data('fee'));
    $('#num_price').text(num_rs.toFixed(2));
});
$(document).on('click','.dobuy', function () {
    var that = $(this);
    $.showLoading();
    if(that.attr('disabled')){
        return false;
    }
    that.attr('disabled', '1');
    $.ajax({
        type: 'post',
        url: _APPNAME + '?id=xigua_hd&ac=buy&inajax=1',
        data:{
            'did' :that.data('did') ,
            'liuyan':$('#item_note').val(),
            'jid' :that.data('jid'),
            'formhash' : FORMHASH
        },
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            that.removeAttr('disabled');
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () {
            $.hideLoading();
            that.removeAttr('disabled');
        }
    });
});
$(document).on('click','.m_jump', function () {
    if($(this).data('did')){
        var did = $(this).data('did');
        var jid = $(this).data('jid');
        var jmpurl = _APPNAME + '?id=xigua_hd&ac=view&did='+did+'&jid='+jid+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        if(typeof mag !== 'undefined'){
            mag.newWin(GSITE+jmpurl);
            return false;
        }
        window.location.href = jmpurl;
    }
});
$(document).on('click','.index_search', function () {
    var that = $(this);
    $('#search_popup').popup();
});

function hd_GetRunTime( mallstart, mallend, itimer, step){
    var endtime= new Date(mallend.replace(/-/g,'/'));
    var starttime= new Date(mallstart.replace(/-/g,'/'));
    var keeptime = endtime - starttime;
    var nowtime = new Date();
    var t = endtime.getTime() - nowtime.getTime();
    var st = starttime.getTime()-nowtime.getTime();
    var tit = HM_JJS;
    if(typeof noTit!=='undefined'){
        tit = '';
    }
    if(!mallend){
        itimer.html('<span class="timer">'+CQYX+'</span>');
        return;
    }
    if(t<=0){
        if(typeof noTit!=='undefined'){
            itimer.html('<span class="timer">'+mallend+'</span>');
        }else {
            itimer.html(HM_YY+'<span class="timer">'+mallend+'</span>'+HM_JS);
        }
        return;
    }
    if(st>0){
        t = st;
        tit = HM_JKS;
    }
    var dd = t/1000;

    var d=Math.floor(dd/3600/24);
    var h=Math.floor(dd/3600%24);
    var m=Math.floor(dd/60%60);
    var s=Math.floor(dd%60);
    var o = '';
    if(h<10){h = '0'+h;}
    if(m<10){m = '0'+m;}
    if(s<10){s = '0'+s;}
    if(step ===10){
        o= Math.floor(t/10%100);
        if(o<10){o = '0'+o;}
        o = "<i>"+o+"</i>";
    }
    var width = t/keeptime*100;

    var ddis = '', hdis = '', mdis = '', sdis = '';
    if(d>0){
        ddis = '<i>'+d+'</i>' + h_t;
    }
    hdis = '<i>'+h+'</i>' + h_h;
    mdis = '<i>'+m+'</i>' + h_f;
    sdis = '<i>'+s+'</i>' + h_sec;
    itimer.html(tit+' <span class="timer">'+ddis + hdis + mdis + sdis+o+'</span>');
    setTimeout(function(){
        hd_GetRunTime( mallstart, mallend, itimer, step);
    }, step||1000);
}
$(function () {
    if($('#auto_play').length){
        var media_filed= $('#auto_play');
        media_filed[0].play();
        $(document).on('click', '#audio_btn', function () {
            if ($(this).hasClass('play_yinfu')) {
                $(this).addClass('off');
                $(this).removeClass('play_yinfu');
                $('#yinfu').removeClass('rotate');
                media_filed[0].pause();
            } else {
                $(this).addClass('play_yinfu');
                $(this).removeClass('off');
                $('#yinfu').addClass('rotate');
                media_filed[0].play();
            }
        });
    }
    if($('#driving').length>0){
        var driv = $('#driving'), dnt = 0;
        var drivInterval=setInterval(function () {
            hs_getlocation(function(position){
                $.ajax({
                    type: 'post',
                    url: _APPNAME +'?id=xigua_hs&ac=driving&shid='+driv.data('id')+'&inajax=1&from='+(position.latitude||position.lat) + ','+ (position.longitude||position.lng),
                    data: {'formhash':FORMHASH},
                    dataType: 'xml',
                    success: function (data) {
                        if(null==data){return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        var sary = s.split('|');
                        if(sary[0]=='success'){
                            $('#driving').show().html(sary[1]);
                        }
                        clearInterval(drivInterval);
                    },
                    error: function () { $('#driving').hide(); }
                });
            });
            dnt++;
            if(dnt>2){
                clearInterval(drivInterval);
                $('#driving').show().html('');
            }
        }, 1500);
    }
});