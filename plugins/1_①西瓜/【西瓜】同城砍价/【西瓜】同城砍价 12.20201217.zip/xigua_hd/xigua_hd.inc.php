<?php
/*
+------------------------------------------------------------------------------------------------
| 
|   Copyright (c) 2020 by dism.taobao.com
|   https://dism.taobao.com
|   Support: DisM!Ӧ������
|   Please don't change the copyright, This is NOT a freeware, use is subject to license terms
|   ���棺��Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
|  
+------------------------------------------------------------------------------------------------
*/
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_hd/function.php';
$hd_config = $_G['cache']['plugin']['xigua_hd'];
xigua_hd_pay_callback();
$aclist = array('index', 'my_evt', 'getloc', 'evt_li', 'view', 'edit', 'join', 'join_li', 'discount', 'qiang', 'buy', 'stock_edit', 'my_order', 'scan', 'none', 'income_li', 'incr', 'sendhb');
$aclist_login = array('edit', 'discount', 'qiang', 'buy', 'stock_edit', 'scan', 'income_li', 'sendhb');
$ac = $_GET['ac'];
$do = $_GET['do'];
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
$isself = in_array($ac, $aclist_login) || !(strpos($ac, 'my') === false) && !$_G['uid'];
if ($isself && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval(getgpc('page')));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$did = intval($_GET['did']);
$jid = intval($_GET['jid']);
if (!$hd_config['mkey'] && $_G['cache']['plugin']['xigua_hs']['mkey']) {
	$hd_config['mkey'] = $_G['cache']['plugin']['xigua_hs']['mkey'];
}
if (!$hd_config['skey'] && $_G['cache']['plugin']['xigua_hs']['skey']) {
	$hd_config['skey'] = $_G['cache']['plugin']['xigua_hs']['skey'];
}
$hs_config = $_G['cache']['plugin']['xigua_hs'];
if ($hs_config['shcolors']) {
	foreach (explode("\n", trim($hs_config['shcolors'])) as $index => $item) {
		list($_color, $_title) = explode('=', trim($item));
		$tmp = explode(',', $_color);
		$shcolor[$_title] = $tmp[0];
	}
}
switch ($ac) {
	case 'incr':
		if (in_array($_GET['incr_type'], array('shares', 'views'))) {
			if ($did) {
				C::t('#xigua_hd#xigua_hd_dis')->incr($did, $_GET['incr_type']);
			}
			if ($jid) {
				C::t('#xigua_hd#xigua_hd_join')->incr($jid, $_GET['incr_type']);
			}
			hb_message('success');
		}
		break;
	case 'index':
		$topnavslider = array();
		$topnavslider = hb_parse_set($hd_config['loopbanner'], 1);
		$navtitle = $hd_config['navtitle'];
		$desc = $hd_config['desc'];
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$navtitle = $keyword;
		}
		if ($cid = intval($_GET['cid'])) {
			$cret = C::t('#xigua_hd#xigua_hd_cat')->fetch_by_catid($cid);
			$navtitle = $cret['name'] . lang_hd('jj', 0);
		}
		$desc = $hd_config['navdesc'];
		$cat_list = C::t('#xigua_hd#xigua_hd_cat')->fetch_all_by_page();
		$jing_list = array_values($cat_list);
		if ($jing_list) {
			$jing_count = range(0, ceil(count($jing_list) / 5) - 1);
		}
		$canyu = C::t('#xigua_hd#xigua_hd_join')->total_count();
		$totalviews = C::t('#xigua_hd#xigua_hd_dis')->total_views();
		$total_dis = C::t('#xigua_hd#xigua_hd_dis')->total_count();
		$pub0 = $SCRITPTNAME . '?id=xigua_hd&ac=my_evt&auto=1';
		break;
	case 'edit':
		if ($_G['cache']['plugin']['xigua_hs']) {
			$where = array();
			$where[] = 'uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP;
			$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
		}
		$old_data = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_id($did);
		include template('xigua_hd:my_evt');
		break;
	case 'my_evt':
		if (submitcheck('do')) {
			$form = $_GET['form'];
			$data = $srg = $append_img = $append_text = array();
			$required = array('title', 'starttime', 'endtime', 'jieshao', 'color');
			foreach ($required as $index => $item) {
				$form[$item] = trim($form[$item]);
				if (!$form[$item]) {
					hb_message(lang_hd($item . '_tip', 0), 'error');
				}
			}
			foreach ($form['append_img'] as $index => $item) {
				$append_img[] = $item;
				$append_text[] = $form['append_text'][$index];
			}
			$up = $form['id'] > 0;
			if ($up) {
				$data['upts'] = TIMESTAMP;
			} else {
				$data['uid'] = $_G['uid'];
			}
			$data['title'] = $form['title'];
			if ($form['shname']) {
				$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']);
				$data['shname'] = $sh['name'];
				$data['shid'] = $sh['shid'];
				$data['hangye_id1'] = $sh['hangye_id1'];
				$data['hangye_id2'] = $sh['hangye_id2'];
			}
			$data['jieshao'] = $form['jieshao'];
			$data['append_img'] = serialize($append_img);
			$data['append_text'] = serialize($append_text);
			if (count($form['album']) < 1) {
				hb_message(lang_hd('zs1', 0), 'error');
			}
			$data['album'] = serialize($form['album']);
			$data['crts'] = TIMESTAMP;
			$data['biaoprice'] = round($form['biaoprice'], 2);
			$data['disprice'] = round($form['disprice'], 2);
			$data['showdis'] = 1;
			$data['orderdis'] = intval($form['orderdis']);
			$data['selfdis'] = intval($form['selfdis']);
			$data['starttime'] = intval(strtotime($form['starttime']));
			$data['endtime'] = intval(strtotime($form['endtime']));
			$data['usetime'] = strtotime($form['usetime']);
			$data['shixian'] = intval($form['shixian']);
			$data['zong'] = intval($form['zong']);
			$data['stock'] = intval($form['stock']);
			$data['xiaxian'] = round($form['xiaxian'], 2);
			$data['shangxian'] = round($form['shangxian'], 2);
			$data['music'] = $form['music'];
			$data['color_title'] = $form['color'];
			$data['color'] = $shcolor[$form['color']];
			$data['stid'] = $sh['stid'];
			$jp = $SCRITPTNAME . '?id=xigua_hd&ac=my_evt';
			if ($up) {
				if ($hd_config['needshen']) {
					$data['status'] = 1;
					$jp .= '&shen=1';
				}
				$rs = C::t('#xigua_hd#xigua_hd_dis')->update_G($form['id'], $data);
			} else {
				$data['allnum'] = $data['stock'];
				$data['status'] = 2;
				if ($hd_config['needshen']) {
					$data['status'] = 1;
					$jp .= '&shen=1';
				}
				$data['upts'] = $data['crts'];
				$rs = C::t('#xigua_hd#xigua_hd_dis')->insert($data);
			}
			if ($rs) {
				hb_message(lang_hd('czcg', 0), 'success', $SCRITPTNAME . '?id=xigua_hd&ac=my_evt' . $urlext);
			}
			exit(0);
		} else {
			$navtitle = lang_hd('jjgl', 0);
			if (!$hide_nav) {
				$custom_side = array('javascript:full_input(this, 0);', lang_hd('pub', 0));
			}
			if ($_G['cache']['plugin']['xigua_hs']) {
				$where = array();
				$where[] = 'uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP;
				$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where);
				$dftshname = $sh[0]['name'];
			}
			if (!$sh) {
				dheader('Location:' . $SCRITPTNAME . '?id=xigua_hd&ac=none' . $urlext);
			}
		}
		break;
	case 'evt_li':
		$field = '*';
		$order_by = '';
		$where = array();
		if ($_GET['is_my']) {
			$order_by = 'id desc';
			if ($_GET['offline'] == 1) {
				$where[] = 'uid=' . $_G['uid'] . ' and status<>3 and endtime<>\'0\' AND endtime<' . TIMESTAMP;
			} elseif ($_GET['offline'] == 2) {
				$where[] = 'uid=' . $_G['uid'] . ' and status=3';
			} else {
				if ($_GET['shen']) {
					$where[] = 'uid=' . $_G['uid'] . ' and status=1';
				} else {
					$where[] = 'uid=' . $_G['uid'] . ' and status=2 and (endtime=0 OR endtime>=' . TIMESTAMP . ')';
				}
			}
		} else {
			if ($_GET['stat']) {
				$where[] = 'status=' . intval($_GET['stat']);
			} else {
				$where[] = 'status=2';
			}
			if (!$hd_config['showend']) {
				$where[] = ' (endtime=0 OR endtime>=' . TIMESTAMP . ') AND stock>0 ';
			}
			if ($_GET['order_by'] == 'hot') {
				$order_by = ' is_end asc,displayorder desc, views DESC, shares DESC, stock desc';
			} elseif ($_GET['order_by'] == 'new') {
				$order_by = ' is_end asc,displayorder desc, id DESC, stock desc';
			} else {
				$order_by = ' is_end asc,displayorder desc, id DESC, stock desc';
			}
			if ($keyword = stripsearchkey($_GET['keyword'])) {
				$where[] = ' (title LIKE \'%' . $keyword . '%\' OR shname LIKE \'%' . $keyword . '%\' OR jieshao LIKE \'%' . $keyword . '%\' OR append_text LIKE \'%' . $keyword . '%\') ';
			}
			if ($cid = intval($_GET['cid'])) {
				$cret = C::t('#xigua_hd#xigua_hd_cat')->fetch_by_catid($cid);
				$hyids = array(0);
				foreach (explode("\n", trim($cret['tag'])) as $___v) {
					$hyids[] = intval($___v);
				}
				$hyids = implode(',', $hyids);
				$where[] = ' hangye_id1 IN (' . $hyids . ') OR hangye_id1 IN(' . $hyids . ')';
			}
		}
		$list = C::t('#xigua_hd#xigua_hd_dis')->fetch_all_by_where($where, $start_limit, $lpp, $order_by);
		include template('xigua_hb:header_ajax');
		include template('xigua_hd:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'getloc':
		$ret = he_current_location($_GET['lat'], $_GET['lng']);
		if (is_array($ret)) {
			hb_message(json_encode($ret), 'success');
		} else {
			hb_message($ret, 'error');
		}
		break;
	case 'view':
		$v = $old_data = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_id($did);
		if ($v['color']) {
			$top_c = hdhex2rgb($v['color'], 0);
		}
		$mynew = C::t('#xigua_hb#xigua_hb_pub')->fetch_newest_one($_G['uid']);
		$lastrealname = $mynew['realname'];
		$lastmobile = $mynew['mobile'];
		$navtitle = $v['title'];
		$desc = $v['jieshao'] ? $v['jieshao'] : $v['append_text_ary'][0];
		if ($jid) {
			$jv = C::t('#xigua_hd#xigua_hd_join')->fetch_by_jid($jid);
			if (!$jv) {
				$jid = 0;
			}
			if ($jid && $jv['status'] == 1) {
				$codeurl = hd_qrcode_make($jv['hxcode']);
			}
			$curuser = getuserbyuid($jv['uid']);
			$search = array('{title}', '{user}', '{price}', '{current}', '{times}', '{floor}', '{range}');
			$replace = array($v['title'], $curuser['username'], $v['biaoprice'], $jv['current'], $v['zong'] ? $v['zong'] - $jv['jians'] : $jv['jians'], $v['disprice'], $v['biaoprice'] - $jv['current']);
			$navtitle = str_replace($search, $replace, $hd_config['fxt']);
			$desc = str_replace($search, $replace, $hd_config['fxd']);
		}
		if ($_G['uid']) {
			$joins = C::t('#xigua_hd#xigua_hd_join')->fetch_by_uid_did($_G['uid'], $did);
		}
		$is_me = 0;
		if ($_G['uid'] == $jv['uid']) {
			$is_me = 1;
			$selfjoin = C::t('#xigua_hd#xigua_hd_jlog')->fetch_by_crdate($jid, $_G['uid']);
		}
		$v['sh'] = $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid'], 0);
		if (!$v['color']) {
			$v['color'] = $config['maincolor'];
			$shbtncolor[$v['color_title']] = $hs_config['defaultbtncolor'];
		} else {
			$config['maincolor'] = $v['color'];
		}
		$mc = $v['color'];
		break;
	case 'buy':
		if (submitcheck('jid')) {
			$old_data = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_id($did);
			if ($old_data['stock'] < 1) {
				hb_message(lang_hd('kcbz', 0), 'error');
			}
			$jv = C::t('#xigua_hd#xigua_hd_join')->fetch_by_jid($jid);
			$price = $jv['current'];
			C::t('#xigua_hd#xigua_hd_join')->update($jid, array('liuyan' => $_GET['liuyan']));
			if ($price > 0) {
				$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $jid);
				$title = lang_hd('id_', 0) . $jid . lang_hd('gmjj1', 0) . $old_data['title'];
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price, $title, 'common_disbuy', array('data' => array('did' => $did, 'jid' => $jid, 'fromuid' => $_G['uid'], 'price' => $price, 'disinfo' => $old_data), 'callback' => array('file' => 'source/plugin/xigua_hd/function.php', 'method' => 'hd_buy_callback'), 'location' => $rtl, 'referer' => $rtl));
				$rl = urlencode($rtl);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&sxf=' . $sxf . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
				hb_message(lang_hd('jumppay', 0), 'loading', $jumpurl);
			} else {
				if ($hd_config['jkucun'] == 2) {
					$updatestock = C::t('#xigua_hd#xigua_hd_dis')->updateStock($did);
				} else {
					$updatestock = 1;
				}
				if (!$updatestock) {
					hb_message(lang_hd('kcbz', 0), 'error');
				}
				C::t('#xigua_hd#xigua_hd_join')->update($jid, array('order_id' => '-1', 'status' => 1, 'liuyan' => $_GET['liuyan'], 'hxcode' => hd_random_code()));
				$buyer = getuserbyuid($_G['uid']);
				notification_add($old_data['uid'], 'system', lang_hd('cggm', 0), array('url' => $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $jid), 'u' => $buyer['username'], 'p' => $price, 'a' => $old_data['title']), 1);
				notification_add($_G['uid'], 'system', lang_hd('cggm', 0), array('url' => $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $jid), 'u' => $buyer['username'], 'p' => $price, 'a' => $old_data['title']), 1);
				hb_message(lang_hd('gmcg', 0), 'success', 'javascript:window.location.reload();');
			}
		}
		break;
	case 'sendhb':
		if (submitcheck('hbmoney') && submitcheck('jid')) {
			$hbmoney = sprintf('%.2f', $_GET['hbmoney']);
			$hbnum = intval($_GET['hbnum']);
			if ($hbnum < 1) {
				hb_message(lang_hd('hbslerr', 0), 'error');
			}
			if ($hbmoney <= 0) {
				hb_message(lang_hd('hbjeerr', 0), 'error');
			}
			if ($hbmoney * 100 / $hbnum < 1) {
				hb_message(lang_hd('hbjeerr', 0), 'error');
			}
			if (!$did || !$jid) {
				hb_message(lang_hd('paramerror', 0), 'error');
			}
			$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $jid);
			$title = lang_hd('jjshb', 0) . $jid . lang_hd('yk', 0);
			$sxf = 0;
			if ($config['hbsxf']) {
				$sxf = $hbmoney * ($config['hbsxf'] / 100);
				$sxf = sprintf('%.2f', $sxf);
			}
			$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $hbmoney + $sxf, $title, 'common_disred', array('data' => array('did' => $did, 'jid' => $jid, 'fromuid' => $_G['uid'], 'hbmoney' => $hbmoney, 'hbnum' => $hbnum, 'total' => $hbmoney + $sxf, 'sxf' => $sxf), 'callback' => array('file' => 'source/plugin/xigua_hd/function.php', 'method' => 'hd_red_callback'), 'location' => $rtl, 'referer' => $rtl));
			$rl = urlencode($rtl);
			$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&sxf=' . $sxf . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
			hb_message(lang_hd('jumppay', 0), 'loading', $jumpurl);
		}
		break;
	case 'join':
		if (submitcheck('did')) {
			$form = $_GET['form'];
			hd_ipcheck();
			if (!$form['realname']) {
				hb_message(lang_hd('qtxxm', 0), 'error');
			}
			if (!$form['mobile']) {
				hb_message(lang_hd('qtxsj', 0), 'error');
			}
			if (!preg_match($isMob, $form['mobile']) && !preg_match($isTel, $form['mobile'])) {
				hb_message(lang_hb('dianhua2', 0), 'error');
			}
			if ($form['hb']) {
				$hbmoney = sprintf('%.2f', $form['hbmoney']);
				$hbnum = intval($form['hbnum']);
				if ($hbnum < 1) {
					hb_message(lang_hd('hbslerr', 0), 'error');
				}
				if ($hbmoney <= 0) {
					hb_message(lang_hd('hbjeerr', 0), 'error');
				}
				if ($hbmoney * 100 / $hbnum < 1) {
					hb_message(lang_hd('hbjeerr', 0), 'error');
				}
			}
			$old_data = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_id($did);
			if ($old_data['not_start']) {
				hb_message(lang_hd('jjhd', 0) . lang_hd('wks', 0), 'error');
			}
			if ($old_data['is_end']) {
				hb_message(lang_hd('hdyjs', 0), 'error');
			}
			$retjid = C::t('#xigua_hd#xigua_hd_join')->do_join($_G['uid'], $did, $old_data['biaoprice'], $old_data['shid'], $form['mobile'], $form['realname']);
			if ($retjid > 0) {
				if ($hd_config['jkucun'] != 2) {
					$updatestock = C::t('#xigua_hd#xigua_hd_dis')->updateStock($did);
				} else {
					$updatestock = 1;
				}
				if ($updatestock) {
					C::t('#xigua_hd#xigua_hd_dis')->incr($did, 'joins');
					if ($hbmoney > 0) {
						$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $retjid);
						$title = lang_hd('jjshb', 0) . $retjid . lang_hd('yk', 0);
						$sxf = 0;
						if ($config['hbsxf']) {
							$sxf = $hbmoney * ($config['hbsxf'] / 100);
							$sxf = sprintf('%.2f', $sxf);
						}
						$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $hbmoney + $sxf, $title, 'common_disred', array('data' => array('did' => $did, 'jid' => $retjid, 'fromuid' => $_G['uid'], 'hbmoney' => $hbmoney, 'hbnum' => $hbnum, 'total' => $hbmoney + $sxf, 'sxf' => $sxf), 'callback' => array('file' => 'source/plugin/xigua_hd/function.php', 'method' => 'hd_red_callback'), 'location' => $rtl, 'referer' => $rtl));
						$rl = urlencode($rtl);
						$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&sxf=' . $sxf . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
						hb_message(lang_hd('jumppay', 0), 'loading', $jumpurl);
					} else {
						hb_message(lang_hd('cjjj', 0), 'success', $SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $retjid);
					}
				} else {
					$ret = C::t('#xigua_hd#xigua_hd_join')->delete_by_uid_did($_G['uid'], $did);
					hb_message(lang_hd('zwsb', 0), 'error');
				}
			} else {
				$ret = C::t('#xigua_hd#xigua_hd_join')->fetch_by_uid_did($_G['uid'], $did);
				hb_message(lang_hd('ycj', 0), 'success', $SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $ret['id']);
			}
		}
		break;
	case 'join_li':
		$where = array('did=' . $did);
		if ($jid) {
			$where[] = 'jid=' . $jid;
			$list = C::t('#xigua_hd#xigua_hd_jlog')->fetch_all_by_where($where, $start_limit, $lpp);
		} else {
			if ($_GET['jlog']) {
				$list = C::t('#xigua_hd#xigua_hd_jlog')->fetch_all_by_where($where, $start_limit, $lpp);
			} else {
				if ($_GET['haspay']) {
					$where[] = 'status=1';
				}
				$order = 'id DESC';
				if ($hd_config['ordre'] == 2) {
					$order = 'current ASC';
				}
				$list = C::t('#xigua_hd#xigua_hd_join')->fetch_all_by_where($where, $start_limit, $lpp, 'id DESC');
			}
		}
		$juinfos = $jids = $jinfos = $hbinfos = $hbs = $orders = $order_ids = $uids = array();
		foreach ($list as $k => $v) {
			$uids[] = $v['uid'];
			if ($v['order_id']) {
				$order_ids[] = $v['order_id'];
			}
			$hbs[$v['hbid']] = $v['hbid'];
			$jids[$v['jid']] = $v['jid'];
		}
		$users = DB::fetch_all('SELECT username,uid FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
		if ($_GET['haspay'] && $order_ids) {
			$orders = DB::fetch_all('SELECT order_id,payupts,baseprice FROM %t WHERE order_id IN (%n)', array('xigua_hb_order', $order_ids), 'order_id');
		}
		if ($hbs) {
			$hbinfos = DB::fetch_all('SELECT * FROM %t WHERE id IN (%n)', array('xigua_hb_hongbaolog', $hbs), 'id');
		}
		if ($_GET['jlog'] && $jids) {
			$jinfos = DB::fetch_all('SELECT j.uid,m.username,j.id AS jid FROM %t AS j,%t AS m WHERE j.id IN (%n) AND m.uid=j.uid', array('xigua_hd_join', 'common_member', $jids), 'jid');
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_hd:join_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'discount':
		$old_data = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_id($did);
		$jv = C::t('#xigua_hd#xigua_hd_join')->fetch_by_jid($jid);
		if ($hd_config['maxjianjid'] > 0) {
			$maxjianjid = C::t('#xigua_hd#xigua_hd_jlog')->fetch_by_maxjianjid($did, $_G['uid'], $jid);
			if ($maxjianjid >= $hd_config['maxjianjid']) {
				hb_message(str_replace('n', $hd_config['maxjianjid'], lang_hd('maxjid1', 0)), 'error');
			}
		}
		if ($hd_config['maxdid'] > 0) {
			$maxjianjid = C::t('#xigua_hd#xigua_hd_jlog')->fetch_by_maxjianjid($did, $_G['uid']);
			if ($maxjianjid >= $hd_config['maxdid']) {
				hb_message(str_replace('n', $hd_config['maxdid'], lang_hd('maxjid2', 0)), 'error');
			}
		}
		if ($old_data['not_start']) {
			hb_message(lang_hd('jjhd', 0) . lang_hd('wks', 0), 'error');
		}
		if ($hd_config['allowjj']) {
			if ($old_data['endtime'] && $old_data['endtime'] < TIMESTAMP) {
				hb_message(lang_hd('hdyjs', 0), 'error');
			}
		} else {
			if ($old_data['is_end']) {
				hb_message(lang_hd('hdyjs', 0), 'error');
			}
		}
		if (!$old_data['selfdis'] && $jv['uid'] == $_G['uid']) {
			hb_message(lang_hd('bnzj', 0), 'error');
		}
		hd_ipcheck();
		if ($old_data['zong'] && $jv['jians'] + 1 > $old_data['zong']) {
			hb_message(lang_hd('ydd', 0) . $old_data['zong'] . lang_hd('csx', 0), 'error');
		}
		$min = intval($old_data['xiaxian'] * 100);
		$max = intval($old_data['shangxian'] * 100);
		$money = sprintf('%.2f', mt_rand($min, $max) / 100);
		$leval = $jv['current'] - $old_data['disprice'];
		if ($money > $leval && $leval > 0) {
			$money = $leval;
		}
		$jlogid = C::t('#xigua_hd#xigua_hd_jlog')->do_discount($did, $jid, $_G['uid'], $old_data, $money);
		if ($jlogid > 0) {
			C::t('#xigua_hd#xigua_hd_dis')->incr($did, 'joins');
			notification_add($jv['uid'], 'system', '<a href="{url}">' . $_G['username'] . ' ' . lang_hd('cgjj', 0) . $money . lang_hd('yuan', 0) . '</a>', array('url' => $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $jid)), 1);
			if ($jv['uid'] != $_G['uid'] && $jv['hbnum'] > $jv['hbsendnum'] && !DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND jid=%d LIMIT 1', array('xigua_hb_hongbaolog', $_G['uid'], $jid))) {
				hb_message(lang_hd('gxcgjj', 0) . $money . lang_hd('yuan', 0), 'loading', 'javascript:showHongBox(' . $jlogid . ');');
			} else {
				hb_message($money, 'success');
			}
		} else {
			if ($jlogid == 0 - 2) {
				hb_message(lang_hd('mt', 0), 'error');
			} else {
				hb_message(lang_hd('yddj', 0), 'error');
			}
		}
		break;
	case 'qiang':
		if (submitcheck('jid')) {
			check_bind(2);
			hb_qchk();
			if (discuz_process::islocked('dis_' . $jid . '_' . $_G['uid'], 1)) {
				hb_message(lang_hb('qianguole', 0), 'error');
			}
			$jv = C::t('#xigua_hd#xigua_hd_join')->fetch_by_jid($jid);
			if ($jv['hbnum'] <= 0) {
				hb_message(lang_hb('hongbnumerror', 0), 'error');
			}
			if ($jv['hbnum'] <= $jv['hbsendnum']) {
				hb_message(lang_hb('qiangwan', 0), 'error');
			}
			hb_area();
			$uin = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			if (DB::query('UPDATE %t SET uid=%d,crts=%d,mobile=%s,ip=%s WHERE jid=%d AND uid=0 LIMIT 1', array('xigua_hb_hongbaolog', $_G['uid'], TIMESTAMP, $uin['mobile'], $_G['clientip'], $jid))) {
				C::t('#xigua_hd#xigua_hd_join')->incr($jid, 'hbsendnum');
				$hblog = DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND jid=%d LIMIT 1', array('xigua_hb_hongbaolog', $_G['uid'], $jid));
				C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($_G['uid'], 'money', $hblog['size']);
				C::t('#xigua_hb#xigua_hb_moneylog')->insert(array('uid' => $_G['uid'], 'crts' => TIMESTAMP, 'size' => $hblog['size'], 'note' => lang_hd('kjhb', 0) . '(ID��' . $jid . ')', 'link' => $SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $jid));
				C::t('#xigua_hd#xigua_hd_jlog')->update($_GET['jlogid'], array('hbid' => $hblog['id']));
				hb_message($hblog['size'], 'success');
			}
		}
		hb_message(lang_hb('hberr', 0), 'error');
		break;
	case 'stock_edit':
		if (submitcheck('formhash')) {
			$data = array();
			if ($do == 'del') {
				$data['status'] = 3;
				$rs = C::t('#xigua_hd#xigua_hd_dis')->update_G($did, $data);
				hb_message(lang_hd('xjcg', 0), 'success', 'javascript:window.location.reload();');
			} elseif ($do == 'shangjia') {
				$data['status'] = 2;
				$rs = C::t('#xigua_hd#xigua_hd_dis')->update_G($did, $data);
				hb_message(lang_hd('sjcg', 0), 'success', 'javascript:window.location.reload();');
			}
		}
		break;
	case 'my_order':
		switch ($do) {
			case 'seckill_li':
				if ($_GET['manage'] == 1) {
					$manage = 1;
					$shids = check_hd_manage();
					$where = array('shid in (' . implode(',', $shids) . ')');
					$order_by = 'id DESC';
				} else {
					$where = array('uid=' . $_G['uid']);
					if ($_GET['status']) {
						$status = intval($_GET['status']);
						if ($status == 0 - 1) {
							$status = '0';
						}
						$where[] = 'status=' . $status;
					}
					if ($_GET['hx']) {
						$hx = intval($_GET['hx']);
						if ($hx == 0 - 1) {
							$hx = '0';
						}
						$where[] = 'hxstatus=' . $hx;
					}
					$order_by = 'id DESC';
				}
				$list = C::t('#xigua_hd#xigua_hd_join')->fetch_all_by_where($where, $start_limit, $lpp, $order_by);
				$uids = $dids = array();
				foreach ($list as $index => $item) {
					$dids[] = $item['did'];
					$uids[$index] = $item['uid'];
					$list[$index]['crts_u'] = dgmdate($item['crts'], 'u');
					$list[$index]['jumpurl'] = $SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $item['did'] . '&jid=' . $item['id'];
				}
				$users = DB::fetch_all('SELECT username,uid FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
				$dlist = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_ids($dids);
				include template('xigua_hb:header_ajax');
				include template('xigua_hd:my_order_' . $do);
				include template('xigua_hb:footer_ajax');
				break;
			case 'manage':
				$navtitle = lang_hd('gldd', 0);
				$custom_side = array($SCRITPTNAME . '?id=xigua_hb&ac=my', lang_hb('wode', 0));
				include template('xigua_hd:my_order_manage');
				exit(0);
				break;
			case 'income':
				$navtitle = lang_hd('gldd', 0);
				$custom_side = array($SCRITPTNAME . '?id=xigua_hb&ac=my', lang_hb('wode', 0));
				include template('xigua_hd:my_order_income');
				exit(0);
				break;
			case 'evt':
			default:
				if (!$do) {
					$do = 'evt';
				}
				$navtitle = lang_hd('wddd', 0);
				$custom_side = array($SCRITPTNAME . '?id=xigua_hb&ac=my', lang_hb('wode', 0));
				include template('xigua_hd:my_order_' . $do);
				exit(0);
		}
		break;
	case 'scan':
		$navtitle = lang_hd('hxdd', 0);
		if ($do == 'scan_li') {
			$shids = check_hd_manage();
			$where = array('shid in (' . implode(',', $shids) . ') and hxstatus=1');
			$list = C::t('#xigua_hd#xigua_hd_join')->fetch_all_by_where($where, $start_limit, $lpp, 'id DESC');
			$uids = array();
			foreach ($list as $k => $v) {
				$uids[] = $v['hxuid'];
			}
			$users = DB::fetch_all('SELECT username,uid FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
			foreach ($list as $rk => $rv) {
				$list[$rk]['hxuser'] = $users[$rv['hxuid']];
			}
			include template('xigua_hb:header_ajax');
			include template('xigua_hd:scan_li');
			include template('xigua_hb:footer_ajax');
		} else {
			if (submitcheck('formhash') && $do == 'add' || $_GET['code']) {
				$code = $_GET['form']['code'];
				if (!$code && !$_GET['code']) {
					$error = lang_hd('dhmbcz', 0);
					hb_message($error, 'error');
				}
				if (!$code) {
					$toast = 1;
					$code = $_GET['code'];
				}
				$jv = C::t('#xigua_hd#xigua_hd_join')->fetch_by_code($code);
				if (!$jv) {
					$error = lang_hd('dhmbcz', 0);
					if ($toast) {
						include template('xigua_hd:error');
						exit(0);
					}
					hb_message($error, 'error');
				}
				if ($jv['hxstatus'] != 0) {
					$error = lang_hd('dhmysy', 0);
					if ($toast) {
						include template('xigua_hd:error');
						exit(0);
					}
					hb_message($error, 'error');
				}
				$old_data = C::t('#xigua_hd#xigua_hd_dis')->fetch_by_id($jv['did']);
				if ($old_data['usetime'] && $old_data['usetime'] < TIMESTAMP) {
					$error = lang_hd('ygq', 0);
					if ($toast) {
						include template('xigua_hd:error');
						exit(0);
					}
					hb_message($error, 'error');
				}
				$access = 0;
				if ($_G['uid'] == $old_data['uid'] || IS_ADMINID) {
					$access = 1;
				}
				if (!$access) {
					$yuaninfo = C::t('#xigua_hs#xigua_hs_yuan')->fetch_yuan_by_shid_uid($jv['shid'], $_G['uid']);
					if ($yuaninfo) {
						$access = 1;
					}
				}
				if (!$access) {
					if ($coki = authcode(getcookie('hstax' . $jv['shid']), 'DECODE')) {
						$shv = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($jv['shid'], 0);
						if ($shv['hxpwd'] == $coki) {
							$access = 1;
						}
					}
				}
				if (!$access) {
					$error = lang_hd('whxqx', 0);
					if ($toast) {
						include template('xigua_hd:error');
						exit(0);
					}
					hb_message($error, 'error', 'javascript:input_hx_mm(' . $jv['shid'] . ');');
				}
				C::t('#xigua_hd#xigua_hd_join')->update_by_cond(array('hxcode' => $code), array('hxstatus' => 1, 'hxcrts' => TIMESTAMP, 'hxuid' => $_G['uid']));
				if ($jv['order_id']) {
					$order_info = C::t('#xigua_hb#xigua_hb_order')->fetch($jv['order_id']);
					C::t('#xigua_hd#xigua_hd_income')->initincome($order_info);
				}
				$jid = $jv['id'];
				$did = $jv['did'];
				notification_add($jv['uid'], 'system', '<a href="{url}">' . $order_info['subject'] . ' ' . lang_hd('dhm', 0) . $jv['hxcode'] . ' ' . lang('plugin/xigua_hd', 'hxcg') . '</a>', array('url' => $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $jid)), 1);
				notification_add($old_data['uid'], 'system', '<a href="{url}">' . $order_info['subject'] . ' ' . lang_hd('dhm', 0) . $jv['hxcode'] . ' ' . lang('plugin/xigua_hd', 'hxcg') . '</a>', array('url' => $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hd&ac=view&did=' . $did . '&jid=' . $jid)), 1);
				$error = $old_data['title'] . $jv['current'] . lang_hd('yuan', 0) . lang_hd('jjd', 0) . lang_hd('hxcg', 0);
				if ($toast) {
					include template('xigua_hd:error');
					exit(0);
				}
				if ($_GET['back']) {
					hb_message($error, 'success', $SCRITPTNAME . '?id=xigua_hd&ac=my_order&do=manage');
				}
				hb_message($error, 'success', $SCRITPTNAME . '?id=xigua_hd&ac=my_order&do=manage');
			} else {
				$jv = C::t('#xigua_hd#xigua_hd_join')->fetch($jid);
				$dftcode = $jv['hxcode'];
			}
		}
		break;
	case 'income_li':
		$uid = intval($_G['uid']);
		$where[] = 'uid=' . $uid;
		if ($_GET['type'] == 'reach') {
			$where[] = 'indate<=\'' . date('Y-m-d', TIMESTAMP) . '\'';
			$where[] = 'reach=1';
		} else {
			$where[] = 'reach<>1';
		}
		$list = C::t('#xigua_hd#xigua_hd_income')->fetch_u_order($where, $start_limit, $lpp);
		include template('xigua_hb:header_ajax');
		include template('xigua_hd:income_li');
		include template('xigua_hb:footer_ajax');
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_hd/template/touch/' . $ac . '.php'))) {
	include template('xigua_hd:' . $ac);
}
function hdhex2rgb($colour, $a)
{
	if ($colour[0] == '#') {
		$colour = substr($colour, 1);
	}
	if (strlen($colour) == 6) {
		list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
	} elseif (strlen($colour) == 3) {
		list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
	} else {
		return false;
	}
	$r = hexdec($r);
	$g = hexdec($g);
	$b = hexdec($b);
	return 'rgba(' . $r . ', ' . $g . ', ' . $b . ', ' . $a . ')';
}