<?php
/**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_hd_dis` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `status` int(11) NOT NULL DEFAULT '0',
 `uid` int(11) NOT NULL,
 `title` varchar(256) NOT NULL,
 `shid` int(11) NOT NULL,
 `hangye_id1` int(11) NOT NULL,
 `hangye_id2` int(11) NOT NULL,
 `shname` varchar(256) NOT NULL,
 `allnum` int(11) NOT NULL,
 `stock` int(11) unsigned NOT NULL,
 `usetime` int(11) NOT NULL,
 `starttime` int(11) NOT NULL,
 `endtime` int(11) NOT NULL,
 `disprice` decimal(10,2) NOT NULL,
 `biaoprice` decimal(10,2) NOT NULL,
 `showdis` int(11) NOT NULL,
 `jieshao` text NOT NULL,
 `album` text NOT NULL,
 `append_img` text NOT NULL,
 `append_text` text NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `orderdis` int(11) NOT NULL,
 `selfdis` int(11) NOT NULL,
 `shixian` int(11) NOT NULL,
 `zong` int(11) NOT NULL,
 `xiaxian` decimal(10,2) NOT NULL,
 `shangxian` decimal(10,2) NOT NULL,
 `music` varchar(2000) NOT NULL,
 `color` varchar(20) NOT NULL,
 `color_title` varchar(20) NOT NULL,
 `income_uid` int(11) NOT NULL,
 `joins` int(11) NOT NULL,
 `is_end` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `status` (`status`),
 KEY `upts` (`upts`),
 KEY `crts` (`crts`),
 KEY `stock` (`stock`),
 KEY `shhyid` (`hangye_id2`),
 KEY `hangye_id1` (`hangye_id1`),
 KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hd_cat` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `fid` varchar(20) NOT NULL,
 `in_ad` varchar(800) NOT NULL,
 `in_adlnk` varchar(800) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS `pre_xigua_hd_income` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `reach` int(11) NOT NULL COMMENT '-2shenignore-1inshen0wait1ok',
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `indate` date NOT NULL COMMENT '',
 `money` decimal(10,2) NOT NULL COMMENT '',
 `info` text NOT NULL,
 `ratio` int(11) NOT NULL COMMENT '',
 `ratio_money` decimal(10,2) NOT NULL,
 `order_id` varchar(80) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `crts` (`crts`),
 KEY `indate` (`indate`),
 KEY `reach` (`reach`)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS `pre_xigua_hd_jlog` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `did` int(11) NOT NULL,
 `jid` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `crdate` date NOT NULL,
 `crts` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '1:success 2:not',
 `money` decimal(10,2) NOT NULL,
 `hbid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `jid` (`jid`,`uid`,`crdate`),
 KEY `did` (`did`),
 KEY `jid_2` (`jid`)
) ENGINE=InnoDB;


CREATE TABLE IF NOT EXISTS `pre_xigua_hd_join` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `did` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `order_id` char(24) NOT NULL,
 `crts` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '0:dft 1:success',
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `jians` int(11) NOT NULL,
 `realname` varchar(200) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `hbmoney` decimal(10,2) NOT NULL,
 `hbnum` int(11) NOT NULL,
 `hbsendnum` int(11) NOT NULL,
 `hbstatus` int(11) NOT NULL COMMENT '0:notpay 1:haspay',
 `current` decimal(10,2) NOT NULL,
 `liuyan` varchar(512) NOT NULL,
 `hxcode` varchar(20) NOT NULL,
 `hxstatus` int(11) NOT NULL DEFAULT '0',
 `hxcrts` int(11) NOT NULL,
 `hxuid` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `did` (`did`,`uid`),
 KEY `shid` (`shid`),
 KEY `hxcode` (`hxcode`),
 KEY `current` (`current`)
) ENGINE=InnoDB;

ALTER TABLE `pre_xigua_hd_dis` CHANGE `xiaxian` `xiaxian` DECIMAL(10,2) NOT NULL;
ALTER TABLE `pre_xigua_hd_dis` CHANGE `shangxian` `shangxian` DECIMAL(10,2) NOT NULL;
SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/discuz_plugin_xigua_hd_TC_UTF8.xml');

$finish = TRUE;





$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'stid\'', array('xigua_hd_dis'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hd_dis` ADD `stid` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hd_dis` ADD INDEX(`stid`);

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'stid\'', array('xigua_hd_join'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hd_join` ADD `stid` INT(11) NOT NULL;

ALTER TABLE `pre_xigua_hd_join` ADD INDEX(`stid`);

SQL;
    runquery($sql);
}
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hd/install.php');