<?php
/**
 * Created by PhpStorm.
 * User: yzg
 * Date: 2016/9/30
 * Time: 9:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$plugin = 'xigua_hd';

loadcache('pluginlanguage_script');

if(submitcheck('dosubmit')){

    if(checkmobile()){
        cpmsg('not allow mobile!', "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=lang", 'succeed');
    }


    $cache = DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_template'");
    $data = unserialize($cache);
    $data[$plugin] = $_GET['configary1'];
    C::t('common_syscache')->update('pluginlanguage_template', $data);
    unset($data);

    $cache = DB::result_first("select data from ".DB::table('common_syscache')." where cname='pluginlanguage_script'");
    $data = unserialize($cache);
    $data[$plugin] = $_GET['configary1'];
    C::t('common_syscache')->update('pluginlanguage_script', $data);


    cpmsg(lang('plugin/xigua_hd', 'succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=lang", 'succeed');
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hd&pmod=lang");
showtableheader(); /*Dism_taobao-com*/


foreach ($_G['cache']['pluginlanguage_script'][$plugin] as $arr => $item) {
    showsetting($arr, 'configary1['.$arr.']', $item, 'text', 0, 0 );
}

showsubmit('dosubmit');
showtablefooter(); /*Dism��taobao��com*/
showformfooter(); /*Dism_taobao_com*/
