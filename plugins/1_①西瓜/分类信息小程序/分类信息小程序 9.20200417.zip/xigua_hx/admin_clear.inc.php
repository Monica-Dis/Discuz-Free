<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

function xgb_delete_all($directory, $empty = false, $strict = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return true;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    $ret = xgb_delete_all($path, $empty, $strict);
                    if($strict && !$ret){
                        return false;
                    }
                } else {
                    if(!@unlink($path)){
                        if($strict){
                            return false;
                        }
                    }
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}

$directory = DISCUZ_ROOT .'./source/plugin/xigua_hx/cache/';
if(submitcheck('permsubmit')){
    if(xgb_delete_all($directory, true, true)){
        cpmsg(lang('plugin/xigua_hx', 'succeed'), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=admin_clear", 'succeed');
    }else{
        cpmsg(sprintf(lang('plugin/xigua_hx', 'failed'), DISCUZ_ROOT.'source/plugin/xigua_tieba/cache/'), '', 'error');
    }
}

$cache_count = 0;

@$directoryHandle = opendir($directory);

while ($contents = @readdir($directoryHandle)) {
    if($contents != '.' && $contents != '..') {
        $cache_count ++;
    }
}
@closedir($directoryHandle);

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=admin_clear");
showtableheader(lang('plugin/xigua_hx', 'cache_desc'));

echo '<tr><td>'.lang('plugin/xigua_hx', 'cache_items').$cache_count.lang('plugin/xigua_hx', 'zhang').'</td></tr>';
showsubmit('permsubmit', 'submit');
showtablefooter();/*Dism_taobao-com*/
showformfooter();