<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hx_user extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_hx_user';
        $this->_pk = 'uid';

        parent::__construct();
    }

    public function fetch_by_openid($openid)
    {
        return DB::result_first('SELECT uid FROM %t WHERE openid=%s', array($this->_table, $openid));
    }

    public function fetch_all_by_page($start_limit, $lpp, $wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY crts DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE $this->_pk IN (%n)", array($this->_table, $ids));
    }

    public function init_user($uid, $openid = '', $unionid = '')
    {
        $profile = C::t('common_member_profile')->fetch($uid);
        $user = getuserbyuid($uid);
        $avatar = avatar($uid, 'middle', true);
        parent::insert(array(
            'uid' => $uid,
            'mobile' => $profile['mobile'],
            'openid' => $openid,
            'username' => $user['username'],
            'crts' => TIMESTAMP,
            'avatar'=> $avatar,
            'unionid' => $unionid,
            'nickName' => $user['username'],
            'headImg' => $avatar,
        ), false, true);
    }
}