﻿﻿<?php

/**
 * 对微信小程序用户加密数据的解密示例代码.
 *
 * @copyright Copyright (c) 1998-2014 Tencent Inc.
 */


include_once "pkcs7Encoder.php";
include_once "errorCode.php";


class WXBizDataCrypt
{
    private $appid;
	private $sessionKey;

	/**
	 * 构造函数
	 * @param $sessionKey string 用户在小程序登录后获取的会话密钥
	 * @param $appid string 小程序的appid
	 */
	public function WXBizDataCrypt( $appid, $sessionKey)
	{
		$this->sessionKey = $sessionKey;
		$this->appid = $appid;
	}


	public function decryptData( $encryptedData, $iv, $d = array() )
	{
		if (strlen($this->sessionKey) != 24) {
			return ErrorCode::$IllegalAesKey;
		}
		$aesKey=base64_decode($this->sessionKey);

        
		if (strlen($iv) != 24) {
			return ErrorCode::$IllegalIv;
		}
		$aesIV=base64_decode($iv);

		$aesCipher=base64_decode($encryptedData);

		$pc = new Prpcrypt($aesKey);
		$result = $pc->decrypt($aesCipher,$aesIV);
		/*print_r(diconv($result[1], 'UTF-8', CHARSET));
		EXIT;*/

		if ($result[0] != 0) {
			return array(
                'errcode' => $result[0],
            );
		}
     
        $dataObj=json_decode( $result[1] );
        if( $dataObj  == NULL )
        {
            return array(
                'errcode' => ErrorCode::$IllegalBuffer,
            );
        }
        if( $dataObj->watermark->appid != $this->appid )
        {
            return array(
                'errcode' => ErrorCode::$IllegalBuffer,
            );
        }
		$data = $result[1];
        return array(
            'errcode' => ErrorCode::$OK,
            'data' => $data,
        );
	}

}

