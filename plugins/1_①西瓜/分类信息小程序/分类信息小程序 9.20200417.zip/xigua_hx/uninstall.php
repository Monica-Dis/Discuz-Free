<?php
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/6/27
 * Time: 13:51
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
  DROP TABLE pre_xigua_hx_user;
  DROP TABLE pre_xigua_hx_app;
EOT;
runquery($sql);

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/install.php');

xwb_delall(DISCUZ_ROOT . "./source/plugin/xigua_hx");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_hx");


function xwb_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwb_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}