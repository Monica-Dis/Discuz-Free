<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/1/23
 * Time: 17:20
 */


if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_hx_user` (
 `uid` int(11) NOT NULL,
 `openid` varchar(128) NOT NULL,
 `username` varchar(20) NOT NULL,
 `crts` int(11) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `avatar` varchar(512) NOT NULL,
 `unionid` varchar(512) NOT NULL,
 `fullmobile` varchar(32) NOT NULL,
 `nickName` varchar(300) NOT NULL,
 `headImg` varchar(1024) NOT NULL,
 PRIMARY KEY (`uid`),
 KEY `openid` (`openid`),
 KEY `mobile` (`mobile`),
 KEY `crts` (`crts`),
 KEY `unionid` (`unionid`(255))
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_hx_app` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `appid` varchar(30) NOT NULL,
 `appsecret` varchar(32) NOT NULL,
 `shappid` varchar(30) NOT NULL,
 `shappsecret` varchar(32) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `appid` (`appid`)
) ENGINE=InnoDB;
SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/discuz_plugin_xigua_hb_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hx/install.php');
