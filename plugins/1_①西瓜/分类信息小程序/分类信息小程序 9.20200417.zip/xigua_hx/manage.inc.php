<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';

$hx_config = $_G['cache']['plugin']['xigua_hx'];

function lang_hx($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hx', $lang);
    }else{
        return lang('plugin/xigua_hx', $lang);
    }
}

$xlang = array();
foreach (explode("\n", trim($hx_config['lang'])) as $sp) {
    list($tplid, $val) = explode('=', trim($sp));
    $xlang[trim($tplid)] = trim($val);
}

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
    $ret = C::t('#xigua_hx#xigua_hx_app')->delete(intval($_GET['delete']));
    if($ret){
        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=manage&page=$page", 'succeed');
    }
}
if(submitcheck('dosubmit')){
    if($new = $_GET['n']){
        $newrow = array();
        foreach ($new['appid'] as $k => $v) {
            $newrow[] = array(
                'appid' => $v,
                'appsecret' => $new['appsecret'][$k],
                'shappid'  => $new['shappid'][$k],
                'shappsecret'  => $new['shappsecret'][$k],
                'crts'   => TIMESTAMP,
                'upts'   => TIMESTAMP,
            );
        }
        foreach ($newrow as $value) {
            C::t('#xigua_hx#xigua_hx_app')->insert($value);
        }
    }
    if($r = $_GET['r']){
        $r = dhtmlspecialchars($r);
        $input = array();
        foreach ($r as $index => $item) {
            C::t('#xigua_hx#xigua_hx_app')->update($index, $item);
        }
    }

    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=manage&page=$page", 'succeed');
}

$wherearr = array();
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=manage&page=$page");


showtableheader(lang_hx('pinglunguanli', 0));
showtablerow('class="header"',array(),array(
    lang_hx('appid', 0),
    lang_hx('appsecret', 0),
    lang_hx('shappid', 0),
    lang_hx('shappsecret', 0),
    lang_hb('crts', 0),
    lang_hb('upts', 0),
));

$res = C::t('#xigua_hx#xigua_hx_app')->fetch_all_by_page($start_limit, $lpp, $wherearr);
$icount = C::t('#xigua_hx#xigua_hx_app')->fetch_count_by_page($wherearr);


foreach ($res as $v) {
    $appid = $v['appid'];
    $id = $v['id'];

    showtablerow('', array(), array(
        "<input style='width:120px' name='r[$id][appid]' value='{$appid}' />",
        "<input style='width:120px' name='r[$id][appsecret]' value='{$v['appsecret']}' />",
        "<input style='width:240px' name='r[$id][shappid]' value='{$v['shappid']}' />",
        "<input style='width:240px' name='r[$id][shappsecret]' value='{$v['shappsecret']}' />",
        dgmdate($v['crts'], 'u'),
        dgmdate($v['crts'], 'u'),
        "<a href=\"javascript:;\" onclick=\"return _delid($id, '$appid') \">". lang_hx('del', 0)."</a>"
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=manage&lpp=$lpp", 0, 10);

?>

<tbody>
<tr>
    <td colspan="99"><div>
            <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hx('add_new')?></a>
        </div></td>
</tr>
<?php
if($multipage){
    showtablerow('', 'colspan="99"', $multipage);
}
showsubmit('dosubmit', 'submit', '');
?>
</tbody>

<?php
showtablefooter();/*Dism_taobao-com*/
showformfooter();
?>
<script>
    var rowtypedata = [
        [
            [1,'<input type="text" class="txt" name="n[appid][]" value="" />', ''],
            [1,'<input type="text" class="txt" name="n[appsecret][]" value="" />', ''],
            [1,'<input type="text" class="txt" name="n[shappid][]" value="" />', ''],
            [3,'<div><input name="n[shappsecret][]" value="" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
        ]
    ];
    function _delid(id, name){
        if(confirm('<?php lang_hx('del_confirm')?>' + name + '?')){
            window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=manage&page=$page&del=1&formhash=".FORMHASH.'&delete='?>"+id;
        }
    }
</script>