<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if(!defined('IN_DISCUZ') ) {
    exit('Access Denied');
}
if(!$_G['cache']['plugin']){
    loadcache('plugin');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
$hx_config = $_G['cache']['plugin']['xigua_hx'];

if($_GET['newapp'] &&$_GET['newapp']!=$hx_config['xappid'] ){
    $dconfig = DB::fetch_first("select * from %t WHERE appid=%s", array('xigua_hx_app', $_GET['newapp']));
    if($dconfig){
        $hx_config['xappid'] =  $dconfig['appid'];
        $hx_config['xappsecret'] =  $dconfig['appsecret'];
        $hx_config['xshid'] =  $dconfig['shappid'];
        $hx_config['xshkey'] =  $dconfig['shappsecret'];
    }
}

!defined('SF_APPID') && define('SF_APPID', trim($hx_config['xappid']));
!defined('SF_MCHID') && define('SF_MCHID', trim($hx_config['xshid']));
!defined('SF_APPSECRET') && define('SF_APPSECRET', trim($hx_config['xappsecret']));
!defined('SF_WXPAY_KEY') && define('SF_WXPAY_KEY', trim($hx_config['xshkey']));

include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hx/common.php';

$pubid = intval($_GET['pubid']);
$shid  = intval($_GET['shid']);
include_once libfile('function/cache');
include_once libfile('function/member');

$page = max(1, intval(getgpc('page')));
$lpp   = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$count = 0;
$replace = array('&nbsp;', '&amp;', "\r\n\r\n\r\n", "\n\n", "\r\n\r\n", "\n\n\n\n", "\n\n\n");
$input = json_decode(file_get_contents('php://input'), 'TRUE');

if($token = authcode($input['token']?$input['token']:$_GET['token'], 'DECODE', $_G['config']['security']['authkey'])){
    if($token = explode("\t", $token)){
        if(is_numeric($token[0])){
            $_G['uid'] = intval($token[0]);
        }else{
            $_G['uid'] = C::t('#xigua_hx#xigua_hx_user')->fetch_by_openid($token[0]);
        }
        setloginstatus(getuserbyuid($_G['uid']), 86400);
    }
}

switch ($_GET['ac']){
    case 'config':
        hx_output($_G['cache']['plugin']['xigua_hb']);
        break;
    case "banner":
        $navtitle = $config['tname'];
        $topnavslider = hb_parse_set($config['topslider'], 1);
        $totalpub  = C::t('#xigua_hb#xigua_hb_pub')->count();
        $totalviews  = C::t('#xigua_hb#xigua_hb_pub')->total_views();
        $totalshares  = C::t('#xigua_hb#xigua_hb_pub')->total_shares();


        $cat_list = C::t('#xigua_hb#xigua_hb_cat')->list_by_pid(0, TRUE);
        $toutiao = C::t('#xigua_hb#xigua_hb_pub')->fetch_newest_light(5);
        $tt = array();
        foreach ($toutiao as $str => $item) {
            $toutiao[$str]['user'] = getuserbyuid($item['uid']);
            $toutiao[$str]['cr_time']  = substr($item['cr_time'], 5,5);
            $tt[] = array(
                'font' => "[{$toutiao[$str]['cr_time']}] {$toutiao[$str]['user']['username']}".lang_hb('fabule',0).$cat_list[$item['catid']]['name'].lang_hb('xinxi',0),
                'id' => $item['id'],
            );
        }
        hx_output(array($topnavslider, hb_trans($totalpub), hb_trans($totalviews), hb_trans($totalshares), $tt));
        break;
    case "jing_list":
        $ocat_list = $cat_list = C::t('#xigua_hb#xigua_hb_cat')->list_by_pid(0, TRUE);
        $pubtip = strip_tags($config['pubtip']);
        if(!$_GET['single']){
            foreach (array_values($cat_list) as $index => $item) {
                $key = floor(($index)/10);
                $jing[$key][] = $item;
            }
            $ocat_list = array_merge(array(array('id' => 0, 'name' => lang_hb('zuixin', 0))), $ocat_list);
            hx_output(array($jing, $ocat_list));
        }else{
            $pids = array();
            foreach ($cat_list as $index => $item) {
                $pids[] = $item['id'];
            }
            $subchilds = C::t('#xigua_hb#xigua_hb_cat')->get_childs_by_pids($pids);
            foreach ($subchilds as $index => $subchild) {
                $cat_list[$subchild['pid']]['child'][] = $subchild['name'];
                $cat_list[$subchild['pid']]['cindex'][] = $subchild['id'];
            }

            $jing[0] = array_values($cat_list);
            hx_output($jing);
        }
        break;
    case "list_item":
        $where = array();
        if($_GET['is_my'] && $_G['uid']> 0){
            if($_GET['stat']=='display'){
                $where = array('uid='.$_G['uid'].' and display=1 AND endts>'.TIMESTAMP);
            }else if($_GET['stat'] == 'undisplay'){
                $where = array('uid='.$_G['uid'].' and ( display=0 OR endts<='.TIMESTAMP .')');
            }else{
                $where = array('uid='.$_G['uid']);
            }
        }else{
            $where = array('display=1 AND endts>'.TIMESTAMP);
            if($_GET['hb']){
                $where[] = 'hb_num>0';
                if($_GET['type']=='has'){
                    $where[] = ' hb_num>hb_sendnum ';
                }
            }
            if($_GET['cat_id']){
                $cat_id = intval($_GET['cat_id']);
                $pids = array($cat_id);
                $catinfo = C::t('#xigua_hb#xigua_hb_cat')->get_childs_by_pids($cat_id);
                if($catinfo){
                    foreach ($catinfo as $index => $item) {
                        $pids[] = intval($item['id']);
                    }
                    if($pids){
                        $where[] = ' catid IN('.implode(',', $pids).') ';
                    }
                }else{
                    $where[] = ' catid ='. $cat_id;
                }
            }
            if($_GET['keyword']){
                $kwd = diconv($_GET['keyword'], 'UTF-8', CHARSET);
                $s_cats = C::t('#xigua_hb#xigua_hb_cat')->fetch_by_name($kwd);
                if($s_cats){
                    $where[] = ' catid IN('.implode(',', $s_cats).') ';
                }else{
                    $keyword = stripsearchkey($kwd);
                    $where[] = " (tags LIKE '%$keyword%' OR description LIKE '%$keyword%' OR vars LIKE '%$keyword%') ";
                }
            }
            if($_GET['city']){
                $city = stripsearchkey($_GET['city']);
                $where[] = " dist2 LIKE '%$city%' ";
            }
            if($_GET['dist']){
                $city = stripsearchkey($_GET['dist']);
                $where[] = " dist3 LIKE '%$city%' ";
            }
            if($_GET['tag']){
                $tag = stripsearchkey($_GET['tag']);
                $where[] = " (tags LIKE '%$tag%') ";
            }
            if($orderby = $_GET['orderby']){
                if($orderby=='hot'){$ob = ' views desc ';}elseif($orderby=='new'){$ob = ' up_time DESC ';}elseif($orderby=='img'){$ob = '';$where[] = " imglist!='' ";}else{$ob = '';}
            }
            if($shid = intval($_GET['shid'])){
                $where[] = " shid='$shid' ";
            }
        }
        if($notpubid = intval($_GET['notpubid'])){
            $where[] = ' id!='.$notpubid;
        }
        if($author_uid = intval($_GET['uid'])){
            $where[] = ' uid='.$author_uid;
        }

        $list = C::t('#xigua_hb#xigua_hb_pub')->fetch_all_bypage_pub($where, $start_limit, $lpp, $ob);
        $pubids = $catids = $uids = array();
        foreach ($list as $index => $item) {
            $uids[]   = $item['uid'];
            $catids[] = $item['catid'];
            $pubids[] = $item['id'];
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }
        if($catids){
            $cats  = DB::fetch_all('SELECT id,`name`,icon FROM %t WHERE id IN (%n)', array('xigua_hb_cat', $catids), 'id');
        }

        foreach ($list as $index => $item) {
            $v=$item;
            $list[$index]['avatar'] = avatar($item['uid'], 'big', true);
            $list[$index]['imglist'] = array_slice($list[$index]['imglist'], 0 ,3);
            $list[$index]['tags'] = array_filter($list[$index]['tags']);
            $list[$index]['user'] = $users[$item['uid']];
            $list[$index]['cat'] = $cats[$item['catid']];
            $list[$index]['description'] = str_replace($replace,'',strip_tags($list[$index]['description']));
            $list[$index]['views'] = str_replace($replace,'',strip_tags("$v[views] ".lang_hb('liulandot',0)." $v[shares] ".lang_hb('fenxiangdot',0)." $v[time_u]".lang_hb('fabu0', 0)));
            $list[$index]['is_my'] = $_GET['is_my'] ? 1 : 0;
            $list[$index]['canpay'] = (!$item['display'] && $item['pay_status']==0);
            $_tmp = array();
            foreach ($item['vars'] as $_i => $_v) {
                if($_v['value']){
                    $_tmp[$_i] = $_v;
                }
            }
            $list[$index]['vars'] =$_tmp;
        }
        $count = C::t('#xigua_hb#xigua_hb_pub')->fetch_count_bypage($where);
        hx_output($list);
        break;
    case 'view':
        $info = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid, 1);
        if(!$info){
            hx_output(array());
        }

        $info['hongbaolog'] = array();
        if($_G['uid']){
            $info['hongbaolog'] = C::t('#xigua_hb#xigua_hb_hongbaolog')->fetch_by_uid_pubid($_G['uid'], $pubid);
        }

        foreach ($info['imglist'] as $k => $v){
            $info['images'][$k] = array('path' => $v, '__v' => 0);
            $f = floor($k/3);
            $info['imggroup'][$f][] = array('path' => $v, '__v' => 0);
        }

        $list = array( $info);

        $pubids = $catids = $uids = array();
        foreach ($list as $index => $item) {
            $uids[]   = $item['uid'];
            $catids[] = $item['catid'];
            $pubids[] = $item['id'];
        }
        if($uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
        }
        if($catids){
            $cats  = DB::fetch_all('SELECT id,`name`,icon FROM %t WHERE id IN (%n)', array('xigua_hb_cat', $catids), 'id');
        }

        foreach ($list as $index => $item) {
            $v=$item;
            $list[$index]['avatar'] = avatar($item['uid'], 'big', true);
            $list[$index]['imglist'] = array_slice($list[$index]['imglist'], 0 ,3);
            $list[$index]['tags'] = array_filter($list[$index]['tags']);
            $list[$index]['user'] = $users[$item['uid']];
            $list[$index]['cat'] = $cats[$item['catid']];
            $list[$index]['description'] = str_replace($replace,'',strip_tags($list[$index]['description']));
            $list[$index]['views'] = str_replace($replace,'',strip_tags("$v[views] ".lang_hb('liulandot',0)." $v[shares] ".lang_hb('fenxiangdot',0)." $v[time_u]".lang_hb('fabu0', 0)));
            $_tmp = array();
            foreach ($item['vars'] as $_i => $_v) {
                if($_v['value']){
                    $_tmp[$_i] = $_v;
                }
            }
            $list[$index]['vars'] =$_tmp;
        }
        $description = $navtitle = cutstr(strip_tags($info['description']),80);
        $navtitle = $info['description'];
        hx_output($list);
        break;
    case 'help':
        if($helpid = intval($_GET['helpid'])){
            $data = C::t('#xigua_hb#xigua_hb_help')->fetch($helpid);
            $data['content'] = str_replace($replace,'',strip_tags($data['content']));
            $data = array($data);
        }else{
            $data = C::t('#xigua_hb#xigua_hb_help')->fetch_all_by_page(0, 20);
        }
        hx_output($data);
        break;
    case 'user':
        if($_GET['signin']){
            $xappid = $hx_config['xappid'];
            $xappsecret = $hx_config['xappsecret'];
            $code = $input['code'] ? $input['code'] :trim($_GET['code']);
            $data = hb_curl("https://api.weixin.qq.com/sns/jscode2session?appid=$xappid&secret=$xappsecret&js_code=$code&grant_type=authorization_code");
            $data = json_decode($data, TRUE);
            if($errcode = $data['errcode']){

            }

            if($hx_config['un'] && $data['unionid'] && $hx_config['wechat_table']){
                if($hx_config['wechat_table'] == 'user_weixin_relations'){
                    $uid = DB::result_first("SELECT userid FROM %t WHERE unionid=%s ", array($hx_config['wechat_table'], $data['unionid']));
                    if(!$uid){
                        $uid = DB::result_first("SELECT uid FROM %t WHERE unionid=%s ", array('common_member_wechat', $data['unionid']));
                    }
                }elseif($hx_config['wechat_table'] == 'thirdbind'){
                    $uid = DB::result_first("SELECT uid FROM %t WHERE unionid=%s ", array($hx_config['wechat_table'], $data['unionid']));
                    if(!$uid){
                        $uid = DB::result_first("SELECT uid FROM %t WHERE unionid=%s ", array('common_member_wechat', $data['unionid']));
                    }
                }elseif($hx_config['wechat_table'] == 'appbyme_connection'){
                    $uid = DB::result_first("SELECT uid FROM %t WHERE param=%s ", array($hx_config['wechat_table'], $data['unionid']));
                    if(!$uid){
                        $uid = DB::result_first("SELECT uid FROM %t WHERE unionid=%s ", array('common_member_wechat', $data['unionid']));
                    }
                }else{
                    $uid = DB::result_first("SELECT uid FROM %t WHERE unionid=%s ", array($hx_config['wechat_table'], $data['unionid']));
                }
            }
            if(!$uid) {
                $binduid = C::t('#xigua_hx#xigua_hx_user')->fetch_by_openid($data['openid']);
                if(!$binduid){
                    if($input['userInfo']['nickName']){
                        $uid = hx_register($data['openid'], diconv($input['userInfo']['nickName'], 'UTF-8', CHARSET), $input['userInfo']['avatarUrl'], $data['unionid']);
                    }
                }else{
                    $uid = $binduid;
                }
            }
            if($uid){
                C::t('#xigua_hb#xigua_hb_user')->init_user($uid);
                C::t('#xigua_hx#xigua_hx_user')->init_user($uid, $data['openid'], $data['unionid']);
                $data['token'] = authcode($data['openid']."\t".$data['session_key']."\t".$data['unionid'], 'ENCODE', $_G['config']['security']['authkey']);
                $data['uid']   = $uid;
            }
            $retdata = array($data);

        }elseif($_GET['signup']){
        }else{
            $r = getuserbyuid($_G['uid'], 1);
            $r['avatar'] = avatar($_G['uid'], 'middle', '1');
            $retdata = array(array_merge(C::t('#xigua_hx#xigua_hx_user')->fetch($_G['uid']), $r ));
        }
        hx_output($retdata);
        break;
    case 'datadecrypt':
        include_once DISCUZ_ROOT.'source/plugin/xigua_hx/lib/aes/wxBizDataCrypt.php';
        $appid = $hx_config['xappid'];
        $sessionKey = $token[1];
        $encryptedData = $input['encryptedData'];
        $iv = $input['iv'];

        $pc = new WXBizDataCrypt($appid, $sessionKey);
        $data = $pc->decryptData($encryptedData, $iv);
        if ($data['errcode'] == 0) {
            $data = $rd = json_decode($data['data'], TRUE);
            C::t('#xigua_hb#xigua_hb_user')->init_user($_G['uid']);
            C::t('#xigua_hb#xigua_hb_user')->update($_G['uid'], array('mobile' => $rd['phoneNumber']));
            C::t('#xigua_hx#xigua_hx_user')->update($_G['uid'], array('mobile' => $rd['phoneNumber']));
            C::t('common_member_profile')->update($_G['uid'], array('mobile'=> $rd['phoneNumber']));
        }else{
            $errcode = $data['errcode'];
        }
        hx_output(array($data));
        break;
    case 'pub':
        $cat_id = $input['form']['cat_id'] ? intval($input['form']['cat_id']): intval($_GET['cat_id']);
        $data = array();
        $catinfo = C::t('#xigua_hb#xigua_hb_cat')->fetch($cat_id);
        $catinfo['tag'] = array_filter(explode("\n", trim($catinfo['tag'])));

        $pubtip = strip_tags($config['pubtip'])."\n";
        $pubtip .= lang_hb('ben',0) .( $catinfo['price']>0 ? (lang_hb('fabuxinxi',0).':'.$catinfo['price'].lang_hb('yuan',0).'/'.lang_hb('tiao',0)):lang_hb('mianfei',0) );
        $pubtip .= $catinfo['endtime'] ? lang_hb('youxiaoqi',0). $catinfo['endtime'].lang_hb('day',0): '';
        $tips = array(
            str_replace('n', $config['maximg'], lang_hb('zuiduozhao',0))
        );

        $hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
        if($hbuser['pingbi']){ hb_message(lang_hb('ybpb',0), 'error'); }

        $navtitle = lang_hb('fabu0',0).$catinfo['name'].lang_hb('xinxi',0);
        $data['pcat'] = $catinfo;
        $vars = C::t('#xigua_hb#xigua_hb_var')->fetch_all_by_pluginid($catinfo['id']);
        if(!$vars){
            $vars = C::t('#xigua_hb#xigua_hb_var')->fetch_all_by_pluginid($catinfo['pid']);
        }
        foreach ($vars as $index => $var) {
            $vars[$index]['extraObj'] = '';
            foreach (array_filter(explode("\n", trim($var['extra']))) as $_index => $_item) {
                list($tmp1, $tmp2) = explode('=', trim($_item));
                $vars[$index]['extrav'][] = array('key' => trim($tmp1), 'val' =>trim($tmp2));
            }
        }
        $data['vars'] = $vars;
        if(!$_GET['check']){

            $form = hx_multi_diconv($input['form'], 'utf-8', CHARSET);

            $form['mobile'] = $form['tel'];
            if(!$_G['group']['allowreply']){
                $errcode = 1;
                $errmsg = lang_hb('no_permission_to_post', 0);
            }
            if($config['maxpub']>0){
                $mycount = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_mycount_today();
                if($mycount>=$config['maxpub']){
                    $errcode = 2;
                    $errmsg = sprintf(lang_hb('maxpubeveryday',0), $config['maxpub']);
                }
            }
            if($config['minimg'] && count($form['imglist'])<$config['minimg']){
                $errcode = 3;
                $errmsg = str_replace('n', $config['minimg'], lang_hb('minimg',0));
            }
            if(!$form['description']){
                $errcode = 4;
                $errmsg = lang_hb('miaoshu1',0);
            }

            $formdata = array();
            $formdata['catid']     = $form['cat_id'];
            $formdata['imglist']   = serialize($form['imglist']);
            $formdata['description'] = hb_fomat($form['description']);
            $formdata['description'] = censor($formdata['description'], NULL, TRUE);
            if(is_array($formdata['description']) && $formdata['description']['message']){
                $errcode = 5;
                $errmsg = $formdata['description']['message'];
                hx_err();
            }
            if(C::t('#xigua_hb#xigua_hb_pub')->fetch_description($formdata['description'], $_G['uid'])){
                $errcode = 5;
                $errmsg = lang_hb('xiangsi_exists',0);
                hx_err();
            }

            $formdata['realname']  = $form['realname'];
            $formdata['mobile']    = $form['mobile'];
            $formdata['uid']       = $_G['uid'];
            if(!$catinfo['endtime']){
                $formdata['endts']     = TIMESTAMP+7776000;
            }else{
                $formdata['endts']     = TIMESTAMP+$catinfo['endtime']*86400;
            }

            $tagary = array();
            foreach ($form['tag'] as $_idx => $_tag) {
                $tagary[] = trim($catinfo['tag'][$_idx]);
            }
            $formdata['tags']    = implode("\t", $tagary);
            if($config['maxtag'] && count($tagary)>$config['maxtag']){
                $errcode = 5;
                $errmsg = str_replace('n', $config['maxtag'], lang_hb('zdng',0));
                hx_err();
            }

            $tmpvars = array();
            foreach ($vars as $index => $vvar) {
                $var = $form["var$index"]?$form["var$index"]:$form["address"][$index];
                if(!$var){
                    $var = $form["date"][$index];
                }

                if(!$var && $vvar['required']){
                    $errcode = 5;
                    $errmsg = lang_hb('qtx',0).$vvar['title'];
                    hx_err();
                }

                $html = '';
                foreach (explode("\n", trim($vvar['extra'])) as $str => $extra_string) {
                    list($_tmp1, $_tmp2) = explode('=', trim($extra_string));
                    $_tmp2 = trim($_tmp2);
                    $_tmp1 = trim($_tmp1);
                    if($_tmp1 == $var){
                        $html = $_tmp2;
                        break;
                    }elseif(in_array($_tmp1, $var)){
                        $html.=' '.$_tmp2;
                    }
                }
                $tmpvars[$index] = array(
                    'title' => $vvar['title'],
                    'value' => $var,
                    'html'  => ($html ? $html : $var).$vvar['unitnew'],
                );
                if($vvar['type']=='area'){
                    $tmp = hx_current_location($form["lat"][$index], $form["lng"][$index]);
                    $formdata['dist1'] = $tmp['province'];
                    $formdata['dist2'] = $tmp['city'];
                    $formdata['dist3'] = $tmp['district'].$tmp['street'].$tmp['street_number'];
                }
            }

            $formdata['vars']    = serialize($tmpvars);

            $formdata['cr_time'] = $formdata['up_time'] = dgmdate(TIMESTAMP, 'Y-m-d H:i:s');

            $rpid = C::t('#xigua_hb#xigua_hb_pub')->insert($formdata, true);
            $newpub = 1;
            C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($_G['uid'], 'pubs', 1);

            $data['result'] = $input;
            $formdata['rpid'] = $rpid;
            $formdata['roid'] = $token[0];
            $data['formdata'] = $formdata;

            if($catinfo['price']>0){
                $errcode = 99;   //zhifu
                $errmsg = lang_hb('tiaozhuan', 0);
                hx_err();
            }else {
                if ($config['freedis']) {
                    $_data = array('order_id' => -1, 'pay_status' => 1);
                    $htd = 2;
                    hb_noti($rpid, 'notice_shen');
                } else {
                    hb_noti($rpid, 'notice_pub', $catinfo['name']);
                    $_data = array('order_id' => -1, 'pay_status' => 1, 'display' => 1);
                    $htd = 1;
                }
                C::t('#xigua_hb#xigua_hb_pub')->update($rpid, $_data);
            }



            if($htd==1){
                $errcode = 100;
                $errmsg = lang_hb('fabu0',0).lang_hb('cg',0);
                hb_thread($rpid);
                hx_err();
            }else{
                $errcode = 101;
                $errmsg = lang_hb('pub_shen',0);
                hx_err();
            }

        }else{
            $data['user'] = array(array_merge(C::t('#xigua_hx#xigua_hx_user')->fetch($_G['uid']), getuserbyuid($_G['uid'], 1) ));
        }
        hx_output(array( $data ));
        break;
    case 'uploader':
        if($_G['uid']){
            $res = hb_upload($_FILES['file']);
            hx_output(array( $res ));
        }
        break;

    case 'pay':
        $order_id = $_GET['order_id'];
        $uid = $_GET['uid'];
        $openid = $_GET['openid'];

        $order_info = C::t('#xigua_hb#xigua_hb_order')->fetch_by_order_id_paywait($order_id);
        if(!$order_info){
            $errcode = 20;
            $errmsg = lang_hb('order_not_exists', 0);
            hx_err();
        }

        C::t('#xigua_hb#xigua_hb_order')->update($order_id, array('order_sn' => SF_APPID));

        $subject  = $order_info['subject'];
        $body = diconv(cutstr(strip_tags($subject), 30), CHARSET, 'UTF-8');
        $order_id = $order_info['order_id'];
        $price  = $order_info['baseprice'];

        $subject = $body;
        $order_obj = new WxPayUnifiedOrderSF();
        $order_obj->SetBody($body);
        $order_obj->SetAttach($body);
        $order_obj->SetOut_trade_no($order_id);
        $order_obj->SetTotal_fee($price*100);
        $order_obj->SetTime_start(date("YmdHis"));
        $pburl = $_G['siteurl'];
        if($_G['cache']['plugin']['xigua_hb']['paynotssl']){
            $pburl = str_replace('https://', 'http://', $_G['siteurl']);
        }
        $order_obj->SetNotify_url($pburl. 'source/plugin/xigua_hx/notify_wx.php');
        $order_obj->SetTrade_type("JSAPI");
        $order_obj->SetOpenid($openid);
        $order = WxPayApiSF::unifiedOrder($order_obj);
        $order = hx_multi_diconv($order, 'utf-8', CHARSET);
        $order['key'] = SF_WXPAY_KEY;
        $order['price'] = $price;
        hx_output(array( $order ));

        break;

    case 'prepare':
        $cat_id   = intval($input['cat_id']);
        $pubid    = intval($input['rpid']);
        $openId   = $input['roid'];
        $xincitip = sprintf(lang_hb('xinxiid', 0), $pubid);

        $catinfo = C::t('#xigua_hb#xigua_hb_cat')->fetch_by_catid($cat_id);
        $pubinfo = C::t('#xigua_hb#xigua_hb_pub')->fetch_by_pubid($pubid);

        $order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id($pubid, $catinfo['price'], lang_hb('fabu0', 0).$catinfo['name'].$xincitip, 'cat');
        C::t('#xigua_hb#xigua_hb_pub')->update($pubid, array('order_id' => $order_id, 'pay_status' => table_xigua_hb_order::PAYWAIT));
        $order_info = C::t('#xigua_hb#xigua_hb_order')->fetch_by_order_id_paywait($order_id);
        if(!$order_info){
            $errcode = 20;
            $errmsg = lang_hb('order_not_exists', 0);
            hx_err();
        }

        $subject  = $order_info['subject'];
        $body = diconv(cutstr(strip_tags($subject), 30), CHARSET, 'UTF-8');
        $order_id = $order_info['order_id'];
        $price  = $order_info['baseprice'];

        $subject = $body;
        $order_obj = new WxPayUnifiedOrderSF();
        $order_obj->SetBody($body);
        $order_obj->SetAttach($body);
        $order_obj->SetOut_trade_no($order_id);
        $order_obj->SetTotal_fee($price*100);
        $order_obj->SetTime_start(date("YmdHis"));
        $order_obj->SetNotify_url($_G['siteurl'] . 'source/plugin/xigua_hx/notify_wx.php');
        $order_obj->SetTrade_type("JSAPI");
        $order_obj->SetOpenid($openId);
        $order = WxPayApiSF::unifiedOrder($order_obj);
        $order = hx_multi_diconv($order, 'utf-8', CHARSET);
        $order['key'] = SF_WXPAY_KEY;
//        $order['shid'] = $order_obj->GetMch_id();
        hx_output(array( $order ));
        break;
    case 'signin':
        $data = array();
        $username = diconv($input['form']['username'], 'utf-8', CHARSET);
        $password = $input['form']['password'];
        if(!function_exists('uc_user_login')) {
            loaducenter();
        }
        include_once libfile('function/cache');
        include_once libfile('function/member');
        if(!($loginperm = logincheck($username))) {
            $errcode = 1;
            $errmsg = lang('message', 'login_strike');
            hx_output(array($data));
        }
        if(!$password || $password != addslashes($password)) {
            $errcode = 2;
            $errmsg = lang('message', 'profile_passwd_illegal');
            hx_output(array($data));
        }

        $result = uc_user_login(addslashes($username), $password, 0, 0, '', '', $_G['clientip']);

        if($result[0] <= 0) {
            loginfailed($username);
            failedip();
            $errcode = 3;
            $errmsg = str_replace('{loginperm}',$loginperm-1, lang('message', 'login_invalid')) ;
        }else{
            $uid = $result[0];
            C::t('#xigua_hb#xigua_hb_user')->init_user($uid);
            C::t('#xigua_hx#xigua_hx_user')->init_user($uid, $input['form']['openid'], $input['form']['unionid']);
            $data['token'] = authcode($uid."\t".mt_rand(1,9999)."\t".mt_rand(10000,99999), 'ENCODE', $_G['config']['security']['authkey']);
            $data['uid']   = $uid;
        }
        hx_output(array($data));
        break;
    case 'qrcode':
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
        if($url = getwxaqrcode($_GET['url'])){
            dheader('Location:'.$url);
        }else{
            echo 'fail';
            exit;
        }
        break;
}

function getwxaqrcode($param)
{
    global $_G;
    if(!$param){
        return false;
    }
    $file_name = md5($param);
    $file_relative = 'source/plugin/xigua_hx/cache/'.$file_name.'.jpg';
    $final = DISCUZ_ROOT.$file_relative;
    global $_G;
    if(is_file($final)){
        return $_G['siteurl'].'/'.$file_relative;
    }
    $access_token =  AccessToken();
    $url = 'https://api.weixin.qq.com/wxa/getwxacode?access_token='.$access_token;
    $path="pages/index/index?url=".urlencode($param);
    $width=400;
    $data='{"path":"'.$path.'","width":'.$width.'}';
    $return = request_post($url,$data);
    file_put_contents($final, $return);
    if($_GET['logo'] && getimagesize($final)){
        if(strpos($_GET['logo'], 'http')!==false){
            $shot_file = 'source/plugin/xigua_hx/cache/'.md5($_GET['logo']).'.png';
            if(!is_file(DISCUZ_ROOT.$shot_file)){
                file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($_GET['logo']));
            }
            resize_img(DISCUZ_ROOT.$shot_file, $final.'logo.jpg');
        }else{
        resize_img($_GET['logo'],$final.'logo.jpg');
        }
        if(is_file($final.'logo.jpg')){
            makequan($final.'logo.jpg', $final.'logo.png');
        }
        if(is_file($final.'logo.png')){
            merge_alpha($final, $final.'logo.png', $final);
        }
    }

    if(is_file($final)){
        @unlink($final.'logo.jpg');
        @unlink($final.'logo.png');
        @unlink(DISCUZ_ROOT.$shot_file);
        return $_G['siteurl'].'/'.$file_relative;
    }
}
function merge_alpha($bigImgPath, $qCodePath, $out){
    $bigImg = imagecreatefromstring(file_get_contents($bigImgPath));
    $qCodeImg = imagecreatefromstring(file_get_contents($qCodePath));

    list($qCodeWidth, $qCodeHight, $qCodeType) = getimagesize($qCodePath);
    $transparent = imagecolorallocatealpha($qCodeImg, 0, 0, 0, 127);
    imagecolortransparent($qCodeImg,$transparent );
    imagecopymerge($bigImg, $qCodeImg, 111, 111, 0, 0, $qCodeWidth, $qCodeHight, 100);

    imagepng($bigImg, $out);
    imagedestroy($bigImg);
    imagedestroy($qCodeImg);
    return $out;
}
function resize_img($url, $imgname){
    $file = $url;
    list($width, $height) = getimagesize($file);
    $percent1 = (178/$width);
    $percent2 = (178/$height);
    $percent = max($percent1, $percent2);
    $newwidth = $width * $percent;
    $newheight = $height * $percent;
    $src_im = imagecreatefromjpeg($file);
    $dst_im = imagecreatetruecolor($newwidth, $newheight);
    imagecopyresized($dst_im, $src_im, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
    imagejpeg($dst_im, $imgname);
    imagedestroy($dst_im);
    imagedestroy($src_im);
    return $imgname;
}

function makequan($url, $dest_path){
    $w = 178;  $h=178;
    $original_path= $url;
    $src = imagecreatefromstring(file_get_contents($original_path));
    $newpic = imagecreatetruecolor($w,$h);
    imagealphablending($newpic,false);
    $transparent = imagecolorallocatealpha($newpic, 0, 0, 0, 127);
    $r=$w/2;
    for($x=0;$x<$w;$x++)
        for($y=0;$y<$h;$y++){
            $c = imagecolorat($src,$x,$y);
            $_x = $x - $w/2;
            $_y = $y - $h/2;
            if((($_x*$_x) + ($_y*$_y)) < ($r*$r)){
                imagesetpixel($newpic,$x,$y,$c);
            }else{
                imagesetpixel($newpic,$x,$y,$transparent);
            }
        }
    imagesavealpha($newpic, true);
    imagepng($newpic, $dest_path);
    imagedestroy($newpic);
    imagedestroy($src);
    return $dest_path;
}
function AccessToken()
{
    global $hx_config;
    $xappid = $hx_config['xappid'];
    $xappsecret = $hx_config['xappsecret'];
    $url = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=$xappid&secret=$xappsecret";
    $AccessToken = request_post($url);
    $AccessToken = json_decode($AccessToken , true);
    $AccessToken = $AccessToken['access_token'];
    return $AccessToken;
}
function request_post($url, $data = array()){
    $ch = curl_init();
    $header = "Accept-Charset: utf-8";
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($url, CURLOPT_HTTPHEADER, $header);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (compatible; MSIE 5.01; Windows NT 5.0)');
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch, CURLOPT_AUTOREFERER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $tmpInfo = curl_exec($ch);
    if (curl_errno($ch)) {
        return false;
    }else{
        return $tmpInfo;
    }
}
function hx_err(){
    global $data;
    hx_output(array( $data ));
}
function hx_output($array = array()){
    global $_G,$config, $hx_config, $input;
    if($input['roid']){
        $openid = $input['roid'];
    }elseif($_G['uid']){
        $_t = C::t('#xigua_hx#xigua_hx_user')->fetch($_G['uid']);
        $openid = $_t['openid'];
    }
    $hx_config['xshid'] = '';
    $hx_config['xshkey'] = '';
    $hx_config['server_key'] = '';
    ob_end_clean();
    function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
    header("Content-type: application/json; charset=utf-8");

    $pages = ceil($GLOBALS['count']/$GLOBALS['lpp']);
    $dftdata = array(
        'meta' => array(
            'code' => $GLOBALS['errcode'] ? $GLOBALS['errcode'] : 0,
            'message' => $GLOBALS['errmsg']?hx_multi_diconv($GLOBALS['errmsg'],CHARSET,'UTF-8'):'ok'
        ),
        'data' => array(
            'items' => array(),
            'paginate' => array(
                'hasNext'=> $GLOBALS['count']>=($GLOBALS['lpp']+$GLOBALS['start_limit']),
                'hasPrev'=> false,
                'next'=> min($pages, $GLOBALS['page']+1),
                'page'=> $GLOBALS['page'],
                'pages'=> $pages,
                'perPage'=> $GLOBALS['lpp'],
                'prev'=> max($GLOBALS['page']-1, 0),
                'total'=> max($GLOBALS['count'], $GLOBALS['lpp']),
                'rt' => $GLOBALS['count']
            ),
            'config' => hx_multi_diconv(array_merge(array(
                'timestamp' =>  TIMESTAMP,
                'title' => $GLOBALS['navtitle'],
                'uid'   => $_G['uid'],
                'roid'  => $openid,
                'pubtip' => $GLOBALS['pubtip'],
                'tips'  => $GLOBALS['tips'],
                'photoCount' => $config['maximg'],
                'formhash' => FORMHASH,
            ), $hx_config), CHARSET, 'UTF-8')
        ),
    );

    $data = $dftdata;
    if($array){
        $data['data']['items'] = hx_multi_diconv(array_values($array), CHARSET, 'UTF-8');
    }
    $data = json_encode($data);

    echo $data?$data : json_encode($dftdata);
    exit;
}

function hx_multi_diconv($string, $in_charset, $out_charset){
    if (is_array($string)) {
        foreach ($string as $key => $val) {
            $string[ $key ] = hx_multi_diconv($val, $in_charset, $out_charset);
        }
    } else {
        $string = diconv($string, $in_charset, $out_charset);
    }
    return $string;
}

function hx_syncAvatar($uid, $avatar) {

    if(!$uid || !$avatar) {
        return false;
    }

    if(!$content = dfsockopen($avatar)) {
        return false;
    }

    $tmpFile = DISCUZ_ROOT.'./data/avatar/'.TIMESTAMP.random(6);
    file_put_contents($tmpFile, $content);

    if(!is_file($tmpFile)) {
        return false;
    }

    $result = uploadUcAvatar2::upload($uid, $tmpFile);
    unlink($tmpFile);

    C::t('common_member')->update($uid, array('avatarstatus'=>'1'));

    return $result;
}

function hx_register($openid, $username, $avatar, $unionid = '', $mobile = '') {
    global $_G, $hx_config;
    $nickName = $username;
    $headImg  = $avatar;

    loaducenter();
    $groupid = $_G['setting']['newusergroupid'];

    $password = $_GET['password'] ? md5($_GET['password']) : md5(random(10));

    $email = strtolower(random(8)).'_xcx@qq.com';
    $usernamelen = dstrlen($username);
    if($usernamelen < 3) {
        $username = $username.'wx'.mt_rand(1000, 99999);
    }
    if($usernamelen > 15) {
        $username = cutstr($username, 15, '');
    }

    if(C::t('common_member')->fetch_by_username($username) || uc_user_checkname($username)!='1'){
        $username =  cutstr($username, 12, '').mt_rand(1, 999);
    }

    $censorexp = '/^('.str_replace(array('\\*', "\r\n", ' '), array('.*', '|', ''), preg_quote(($_G['setting']['censoruser'] = trim($_G['setting']['censoruser'])), '/')).')$/i';
    $_G['setting']['censoruser'] && @preg_replace($censorexp, '_', $username);

    $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
    if($uid <= 0) {
        $username = 'xcx'.mt_rand(10000, 9999999);
        $uid = uc_user_register(addslashes($username), $password, $email, '', '', $_G['clientip']);
    }

    C::t('common_member')->insert($uid, $username, $password, $email, $_G['clientip'], $groupid, array('credits' => explode(',', $_G['setting']['initcredits']), 'emailstatus' => 1));

    if($_G['setting']['regctrl'] || $_G['setting']['regfloodctrl']) {
        C::t('common_regip')->delete_by_dateline($_G['timestamp']-($_G['setting']['regctrl'] > 72 ? $_G['setting']['regctrl'] : 72)*3600);
        if($_G['setting']['regctrl']) {
            C::t('common_regip')->insert(array('ip' => $_G['clientip'], 'count' => -1, 'dateline' => $_G['timestamp']));
        }
    }

    if($_G['setting']['regverify'] == 2) {
        C::t('common_member_validate')->insert(array(
            'uid' => $uid,
            'submitdate' => $_G['timestamp'],
            'moddate' => 0,
            'admin' => '',
            'submittimes' => 1,
            'status' => 0,
            'message' => '',
            'remark' => '',
        ), false, true);
        manage_addnotify('verifyuser');
    }

    include_once libfile('function/stat');
    updatestat('register');
    hx_syncAvatar($uid, $avatar);

    if(!function_exists('build_cache_userstats')) {
        require_once libfile('cache/userstats', 'function');
    }
    build_cache_userstats();

    C::t('#xigua_hx#xigua_hx_user')->insert(array(
        'uid' => $uid,
        'openid' => $openid,
        'username' => $username,
        'crts' => TIMESTAMP,
        'mobile' => $mobile,
        'avatar' => $avatar,
        'unionid' => $unionid,
        'nickName' => $nickName,
        'headImg' => $headImg,
    ));
    C::t('#xigua_hb#xigua_hb_user')->init_user($uid);

    if($hx_config['un'] && $unionid && $_G['cache']['plugin']['xigua_login']){
        if($hx_config['wechat_table'] == 'user_weixin_relations'){
            DB::insert($hx_config['wechat_table'], array(
                'userid' => $uid,
                'openid' => $openid,
                'unionid' => $unionid,
            ));
        }elseif($hx_config['wechat_table'] == 'thirdbind'){
            DB::insert($hx_config['wechat_table'], array(
                'unionid'  => $unionid,
                'weibotype'  => 'wechat',
                'openid' => '',
                'uid'    => $uid,
                'dateline' => time(),
            ));
        }elseif($hx_config['wechat_table'] == 'appbyme_connection'){
            DB::insert($hx_config['wechat_table'], array(
                'param'  => $unionid,
                'openid' => '',
                'uid'    => $uid,
                'status' => 1,
                'type' => 1,
            ));
        }
        DB::insert('common_member_wechat', array(
            'uid' => $uid,
            'openid' => $openid,
            'unionid' => $unionid,
            'status' => 2,
            'isregister' => 1,
        ));
    }

    return $uid;
}

function hx_current_location($lat, $lng){
    global $hx_config;
    $rt = array();
    $url = "http://apis.map.qq.com/ws/geocoder/v1/?location=$lat,$lng&coord_type=5&get_poi=0&key=".$hx_config['server_key'];
    $ret = hb_curl($url);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        $rt = array(
            'province' => $ret['result']['address_component']['province'],
            'city'     => $ret['result']['address_component']['city'],
            'district' => $ret['result']['address_component']['district'],
            'street'   => $ret['result']['address_component']['street'],
            'street_number'=>$ret['result']['address_component']['street_number'],
        );
    }
    return hx_multi_diconv($rt, 'utf-8', CHARSET);
}
