<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';

$hx_config = $_G['cache']['plugin']['xigua_hx'];

$xlang = array();
foreach (explode("\n", trim($hx_config['lang'])) as $sp) {
    list($tplid, $val) = explode('=', trim($sp));
    $xlang[trim($tplid)] = trim($val);
}

$page = max(1, intval(getgpc('page')));
$lpp   = 20;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_hx#xigua_hx_user')->deletes($delete);
        foreach ($delete as $index => $uid) {
            DB::delete('common_member_wechat', array( 'uid' => $uid, ));
            DB::delete($hx_config['wechat_table'], array( 'uid' => $uid, ));
            DB::delete('xigua_hb_user', array( 'uid' => $uid, ));
        }
    }
    if($r = $_GET['r']){
        $r = dhtmlspecialchars($r);
        $input = array();
        foreach ($r as $index => $item) {
            $item['mobile'] = str_replace(array('+', ' '), '', $item['mobile']);
            $input[$index] = array(
                'openid' => $item['openid'],
                'mobile' => is_numeric($item['mobile']) ? $item['mobile'] : '',
                'unionid' => $item['unionid'],
            );
        }
        foreach ($input as $index => $item) {
            C::t('#xigua_hx#xigua_hx_user')->update($index, $item);
            if($item['mobile']){
                C::t('#xigua_hb#xigua_hb_user')->update($_G['uid'], array('mobile' => $item['mobile']));
                C::t('common_member_profile')->update($_G['uid'], array('mobile'=> $item['mobile']));
            }
        }
    }

    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=admin_user&page=$page", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword'";
}elseif($keyword){
    $wherearr[] = " ( uid LIKE '%$keyword%' OR mobile LIKE '%$keyword%' ) ";
}

showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=admin_user&page=$page");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="UID,'.lang_hb('mobile', 0).'" value="'.$_GET['keyword'].'" class="txt" /> ';
echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo '</div>';

showtableheader(lang_hb('pinglunguanli', 0));
showtablerow('class="header"',array(),array(
    lang_hb('del', 0),
    lang_hb('UID', 0),
    lang_hb('username', 0),
    lang_hb('mobile', 0),
    lang_hb('OPENID', 0),
    lang_hb('UNIONID', 0),
    $xlang['avatar'],
    $xlang['nickname'],
    lang_hb('crts', 0),
));

$res = C::t('#xigua_hx#xigua_hx_user')->fetch_all_by_page($start_limit, $lpp, $wherearr);
$icount = C::t('#xigua_hx#xigua_hx_user')->fetch_count_by_page($wherearr);

foreach ($res as $v) {
    $uids[] = $v['uid'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}

foreach ($res as $v) {
    $uid = $v['uid'];
    $v['headImg'] = avatar($v['uid'], 'small', 1);

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$uid' />",
        $uid,
        "<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a>",
        "<input style='width:120px' name='r[$uid][mobile]' value='{$v['mobile']}' />",
        "<input style='width:240px' name='r[$uid][openid]' value='{$v['openid']}' />",
        "<input style='width:240px' name='r[$uid][unionid]' value='{$v['unionid']}' />",
        ($v['headImg'] ? "<img src='{$v['headImg']}' style='width:40px;height:40px;'/>" : ''),
        $v['nickName']? $v['nickName']: $xlang['test'],
        dgmdate($v['crts'], 'u'),
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hx&pmod=admin_user&lpp=$lpp", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter();/*Dism_taobao-com*/
showformfooter();