<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/1/27
 * Time: 21:56
 */


define('IN_API', true);
define('CURSCRIPT', 'api');
define('DISABLEXSSCHECK', true);

require_once '../../../source/class/class_core.php';
$discuz = C::app();
$discuz->init();

$_G['siteurl'] = str_replace('source/plugin/xigua_hx/', '',$_G['siteurl'] );

if(!$_G['cache']['plugin']){
    loadcache('plugin');
}
$hx_config = $_G['cache']['plugin']['xigua_hx'];

$bPreviousValue = libxml_disable_entity_loader(true);
$xmlvalues = json_decode(json_encode(simplexml_load_string(file_get_contents("php://input"), 'SimpleXMLElement', LIBXML_NOCDATA)), true);
libxml_disable_entity_loader($bPreviousValue);
$order_id = $xmlvalues['out_trade_no'];
if($order_id){
    $newapp = C::t('#xigua_hb#xigua_hb_order')->fetch($order_id);
    $_GET['newapp'] = $newapp['order_sn'];
}
if($_GET['newapp'] &&$_GET['newapp']!=$hx_config['xappid'] ){
    $dconfig = DB::fetch_first("select * from %t WHERE appid=%s", array('xigua_hx_app', $_GET['newapp']));
    if($dconfig){
        $hx_config['xappid'] =  $dconfig['appid'];
        $hx_config['xappsecret'] =  $dconfig['appsecret'];
        $hx_config['xshid'] =  $dconfig['shappid'];
        $hx_config['xshkey'] =  $dconfig['shappsecret'];
    }
}
!defined('SF_APPID') && define('SF_APPID', trim($hx_config['xappid']));
!defined('SF_MCHID') && define('SF_MCHID', trim($hx_config['xshid']));
!defined('SF_APPSECRET') && define('SF_APPSECRET', trim($hx_config['xappsecret']));
!defined('SF_WXPAY_KEY') && define('SF_WXPAY_KEY', trim($hx_config['xshkey']));

include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';

$notifydata = xigua_hbnotifycheck();
if($notifydata['validator']) {

    $order_id  = $notifydata['order_no'];
    $postprice = $notifydata['price'];
    $order     =  C::t('#xigua_hb#xigua_hb_order')->fetch_by_order_id($order_id);

    if(
        $order &&
        $order['paystatus'] == table_xigua_hb_order::PAYWAIT
    ) {
        finish_order($order, $notifydata['trade_no'], $postprice, table_xigua_hb_order::WXPAY);
    }

}
function xigua_hbnotifycheck() {
    $_G = $GLOBALS['_G'];

    $msg = '';

    $notify = WxPayApiSF::notify($msg);

    if(empty($notify)){
        $return = array(
            'return_code'=>'FAIL',
            'return_msg'=>$msg,
        );
        WxPayApiSF::replyNotify(xigua_hb_arr2xml($return));
        exit;
    }

    //checksign
    $sign = $notify['sign'];
    unset($notify['sign']);

    ksort($notify);
    $paramstring = ToUrlParams($notify);

    if(!$_G['cache']['plugin']){
        loadcache('plugin');
    }

    if(strtoupper(md5($paramstring . "&key=".SF_WXPAY_KEY)) != $sign){
        $return = array(
            'return_code' => 'FAIL',
            'return_msg' => 'sign error!',
        );
        WxPayApiSF::replyNotify(xigua_hb_arr2xml($return));
        exit;
    }
    if($notify['result_code'] == 'SUCCESS') {
        return array(
            'validator'  => isset($notify['result_code']) && $notify['result_code'] == 'SUCCESS' ? 1 : 0,
            'order_no'   => $notify['out_trade_no'],
            'trade_no'   => isset($notify['transaction_id']) ? $notify['transaction_id'] : '',
            'price'      => $notify['total_fee'],
            'appid'      => $notify['appid'],
            'notify'     => xigua_hb_arr2xml(array('return_code'=>'SUCCESS')),
            'location'   => false,
            'fromopenid' => $notify['openid'],
        );
    }
}


function xigua_hb_arr2xml($data){
    $xml = "<xml>";
    foreach ($data as $key=>$val)
    {
        if (is_numeric($val)){
            $xml.="<".$key.">".$val."</".$key.">";
        }else{
            $xml.="<".$key."><![CDATA[".$val."]]></".$key.">";
        }
    }
    $xml.="</xml>";
    return $xml;
}

function ToUrlParams($urlObj)
{
    $buff = "";
    foreach ($urlObj as $k => $v)
    {
        $buff .= $k . "=" . $v . "&";
    }

    $buff = trim($buff, "&");
    return $buff;
}