<?php exit('Ӧ�ø���֧�֣�https://dism.taobao.com'); ?>
<style>#map_box{width:100%;height:80vw;max-height:640px}img.csssprite{border-radius:32px}.infowin{font-size:14px;display: flex;}.infowin .infologo{margin-right: 10px;}.infowin img{width:40px;height:40px;display:block}
.infoaddr p:first-child{font-size:14px;color:#333;white-space:nowrap}.infoaddr p:last-child{font-size:12px;color:#666;white-space:nowrap}.pbtn{color: #fff;line-height: 28px;font-size: 12px;padding: 0 5px;width:90px;margin-top: 10px;}</style>
<div id="map_box"></div>
<div id="list3" class="mod-post x-postlist pt0"></div>
<!--{template xigua_hb:loading}-->