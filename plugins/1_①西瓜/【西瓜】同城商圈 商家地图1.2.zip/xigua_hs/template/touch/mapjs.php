<?php exit('Ӧ�ø���֧�֣�https://dism.taobao.com'); ?>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$_G['cache']['plugin']['xigua_hs']['mkey']}"></script>
<!--{if $_G['cache']['plugin']['xigua_hs']['baidusdk']}--><script type="text/javascript" src="//api.map.baidu.com/api?v=2.0&ak={$_G['cache']['plugin']['xigua_hs']['baidusdk']}"></script><!--{/if}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hs/static/hs.js?{VERHASH}"></script>
<script type="text/javascript">
    var mapObj, mapBD, infoWin, centerPosLat, centerPosLng, infoWin;
    <!--{if $_G['cache']['plugin']['xigua_hs']['baidusdk']}-->
    function SquareOverlay(center, length, src, id){
        this._center = center;
        this._length = length;
        this.src = src;
        this.id = id;
    }
    SquareOverlay.prototype = new BMap.Overlay();
    SquareOverlay.prototype.initialize = function(map){
        this._map = map;
        var div = document.createElement("div");
        div.style.position = "absolute";
        div.style.borderRadius = this._length + "px";
        div.style.width = this._length + "px";
        div.style.height = this._length + "px";
        div.style.backgroundSize = "cover";
        div.style.backgroundImage = "url("+this.src+")";
        var bugFlag=true;
        var IId = this.id;
        div.addEventListener("touchstart", function(e){
            bugFlag = true;
        });
        div.addEventListener("touchmove", function(e){
            setTimeout(function () { bugFlag = false; },100);
        });
        div.addEventListener("touchend", function(e){
            if(bugFlag==true){
                Bdjump(IId);
            }
        });
        map.getPanes().markerPane.appendChild(div);
        this._div = div;
        return div;
    };
    SquareOverlay.prototype.draw = function(){
        var position = this._map.pointToOverlayPixel(this._center);
        this._div.style.left = position.x - this._length / 2 + "px";
        this._div.style.top = position.y - this._length / 2 + "px";
    };
    function Bdjump(id) {
        var jumrl = _APPNAME+"?id=xigua_hs&ac=view&shid="+id;
        hb_jump(jumrl);
        return false;
    }
    <!--{/if}-->
    function initMaper(position){
        centerPosLat = (position.latitude||position.lat);
        centerPosLng = (position.longitude||position.lng);
        <!--{if $_G['cache']['plugin']['xigua_hs']['baidusdk']}-->
        mapBD = new BMap.Map("map_box");
        var point = new BMap.Point(centerPosLng, centerPosLat);
        mapBD.centerAndZoom(point, {echo $_GET[zoom] ? intval($_GET[zoom]) : intval($hs_config[zooml])});
        var myIcon = new BMap.Icon("source/plugin/xigua_hs/static/images/icon.png", new BMap.Size(32, 32), {anchor: new BMap.Size(16,32)});
        var marker = new BMap.Marker(point, {icon: myIcon});
        mapBD.addOverlay(marker);
        mapBD.addEventListener("dragend", scanData);
        mapBD.addControl(new BMap.NavigationControl());
        scanData();
        <!--{else}-->
        var centerPos = new qq.maps.LatLng(centerPosLat, centerPosLng);
        mapObj = new qq.maps.Map(document.getElementById("map_box"), { center:centerPos, zoom:{echo $_GET[zoom] ? intval($_GET[zoom]) : intval($hs_config[zooml])}});
        infoWin = new qq.maps.InfoWindow({  map: mapObj });
        qq.maps.event.addListener(mapObj, 'bounds_changed', scanData);
        var marker = new qq.maps.Marker({position:centerPos,map:mapObj});
        var anchor = new qq.maps.Point(16, 32), size = new qq.maps.Size(32, 32), origin = new qq.maps.Point(0, 0),markerIcon = new qq.maps.MarkerImage('source/plugin/xigua_hs/static/images/icon.png', size, origin, anchor);
        marker.setIcon(markerIcon);
        infoWin = new qq.maps.InfoWindow({map:mapObj});
        <!--{/if}-->
    }
    function addMarker(mkCenter, content, title, id, logo) {
        var marker = new qq.maps.Marker({title: title,position: mkCenter,map: mapObj});
        var anchor = new qq.maps.Point(16, 32), size = new qq.maps.Size(32, 32), scaleSize = new qq.maps.Size(32, 32), origin = new qq.maps.Point(0, 0), markerIcon = new qq.maps.MarkerImage(logo, size, origin, anchor, scaleSize);
        marker.setIcon(markerIcon);
        qq.maps.event.addListener(marker, 'click', function() {
            var jumrl = _APPNAME+"?id=xigua_hs&ac=view&shid="+id;
            hb_jump(jumrl);
            return false;
            /*infoWin.close();
            infoWin.open();
            infoWin.setContent('<div class="infowin"><div class="infologo"><img src="'+logo+'" /></div><div class="infoaddr"><p>'+title+'</p><p>'+content+'</p></div></div>' +
                '<div><a href="javascript:;" onclick="hb_jump(\''+jumrl+'\')" class="weui-btn pbtn main_bg">{lang xigua_hs:cksj}</a></div>');
            infoWin.setPosition(marker.getPosition());*/
        });
    }
    function scanData() {
        <!--{if $_G['cache']['plugin']['xigua_hs']['baidusdk']}-->
        var bounds = mapBD.getBounds();
        if(!bounds){return false; }
        var leftPos = {'lat': bounds.getSouthWest().lat.toFixed(6), 'lng': bounds.getSouthWest().lng.toFixed(6)};
        var rightPos = {'lat': bounds.getNorthEast().lat.toFixed(6), 'lng': bounds.getNorthEast().lng.toFixed(6)};
        <!--{else}-->
        var bounds = mapObj.getBounds();
        if(!bounds){return false; }
        var leftPos = {'lat': bounds.getSouthWest().getLat().toFixed(6), 'lng': bounds.getSouthWest().getLng().toFixed(6)};
        var rightPos = {'lat': bounds.getNorthEast().getLat().toFixed(6), 'lng': bounds.getNorthEast().getLng().toFixed(6)};
        <!--{/if}-->
        var square = {'lat':centerPosLat,'lng':centerPosLng,'left_lat' : leftPos.lat, 'left_lng' : leftPos.lng, 'right_lat' : rightPos.lat, 'right_lng': rightPos.lng};
        $.ajax({
            url: window.location.href+'&ac=myshop_li&map=1&inajax=1&pagesize=10&page=',
            type: 'GET',
            data:square,
            dataType: 'xml',
            success: function (data) {
                var s = data.lastChild.firstChild.nodeValue;
                $('#loading-show').addClass('hidden');$('#loading-none').removeClass('hidden');
                var lsdv = $('#list3');
                lsdv.html(s);
                lsdv.find('.sp_item').each(function () {
                    var that = $(this);
                    <!--{if $_G['cache']['plugin']['xigua_hs']['baidusdk']}-->
                    // var myIcon = new BMap.Icon(that.find('.sp_thumb img').attr('src'), new BMap.Size(32, 32), {anchor: new BMap.Size(0,0)});
                    // var marker = new BMap.Marker(new BMap.Point(that.data('lng'), that.data('lat')), {icon: myIcon});
                    var mySquare = new SquareOverlay(new BMap.Point(that.data('lng'), that.data('lat')), 32, that.find('.sp_thumb img').attr('src'), that.data('id'));
                    mapBD.addOverlay(mySquare);
                    <!--{else}-->
                    addMarker(new qq.maps.LatLng(that.data('lat'), that.data('lng')), that.data('addr'), that.data('title'), that.data('id'), that.find('.sp_thumb img').attr('src'));
                    <!--{/if}-->
                });
            }
        });
    }
    if(typeof wx !=='undefined') {
        wx.ready(function () {
            hs_getlocation(initMaper);
        });
    }else{
        setTimeout(function () {
            hs_getlocation(initMaper);
        }, 120);
    }
</script>