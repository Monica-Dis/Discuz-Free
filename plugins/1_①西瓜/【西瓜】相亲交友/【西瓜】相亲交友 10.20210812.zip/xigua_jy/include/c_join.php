<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢�� wxiguabbs
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$step = $_GET['step'] ? intval($_GET['step']) : 1;
$userdata = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
if($step==1){
    if($userdata){
        dheader("Location: $SCRITPTNAME?id=xigua_jy&ac=my");
    }
    $navtitle = lang_jy('wsgrzl',0);
    $firstbirth = date('Y-m-d', strtotime('-18 years'));
    $firstbirth2 = date(lang_jy('datefomat_php',0), strtotime('-18 years'));
    if(submitcheck('formhash')){
        $form = $_GET['form'];
        $form['birthday'] = str_replace(array(lang_jy('n',0), lang_jy('y',0), lang_jy('r',0)), array('-','-',''), $form['birthday']);
        if(!$form['gender']){
            hb_message(lang_jy('qxzxb',0),'error');
        }
        if(!$form['nickname']){
            hb_message(lang_jy('qtxndnc',0),'error');
        }
        if(!$form['birthday']){
            hb_message(lang_jy('qtxzssr',0),'error');
        }
        if(C::t('#xigua_jy#xigua_jy_user')->nickname_exists($form['nickname'])){
            hb_message(lang_jy('ncycz',0), 'error');
        }
        $shows = $jy_config['shenhe'] ? -1 : 1;
        if(($jy_config['mode']==3 || ($jy_config['mode']==2&&$form['gender']==2)|| ($jy_config['mode']==1&&$form['gender']==1)) && $jy_config['mode_price']>0){
            $shows = -2;
        }
        $data = array(
            'gender' => $form['gender'],
            'nickname' => $form['nickname'],
            'birthday' => $form['birthday'],
            'uid' => $_G['uid'],
            'status' => 1,
            'crts' => TIMESTAMP,
            'upts' => TIMESTAMP,
            'shows' => $shows,
            'stid' => $_GET['st'],
        );
        $id = C::t('#xigua_jy#xigua_jy_user')->insert($data, 1);
        if($shows==-1){
            global $adminids, $SCRITPTNAME, $_G;
            foreach ($adminids as $adminid) {
                notification_add($adminid,'system', lang_jy('need_shen_shows1', 0),array('id'=>$_G['uid'], 'nickname' => $form['nickname'],),1);
            }
        }
        hb_message(lang_jy('bccg',0), 'success', $SCRITPTNAME.'?id=xigua_jy&ac=join&step=2');
    }
}elseif ($step==2){
    $olddata = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
    if(!$olddata){
        dheader("Location: $SCRITPTNAME?id=xigua_jy&ac=join&step=1");
    }
    $navtitle = lang_jy('rdjgljn',0);

    if(submitcheck('formhash')){
        $form = $_GET['form'];
        $data = array(
            'album' => implode(',', $form['album']),
            'note'  => $form['note'],
        );
        foreach ($choseconfig as $index => $item) {
            foreach ($form[$index] as $_index => $_item) {
                if($_item==1){
                    $data[$index][] = trim($item['data'][$_index]);
                }
            }
            if($item['maxnum'] && !$data[$index]){
                hb_message($item['title_tip'], 'error');
            }
            $data[$index] = implode(',', $data[$index]);
        }
        if(!$form['note']){
            hb_message(lang_jy('qtx',0).lang_jy('note',0), 'error');
        }
        C::t('#xigua_jy#xigua_jy_user')->update($_G['uid'], $data);
        hb_message(lang_jy('bccg',0), 'success', "$SCRITPTNAME?id=xigua_jy&ac=my");
    }
}