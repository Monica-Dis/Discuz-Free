<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if (submitcheck('formhash')) {
    $hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
    if ($hbuser['pingbi']) {
        hb_message(lang_hb('ybpb', 0), 'error');
    }
    if (!$cmg = trim($_GET['comment'])) {
        hb_message(lang_hb('empt', 0), 'error');
    }
    $comment_msg = censor($cmg, NULL, TRUE);
    if (is_array($comment_msg) && $comment_msg['message']) {
        hb_message($comment_msg['message'], 'error');
    }
    if($config['discmtmobile']){
        $comment_msg = preg_replace('/(\d{7,})/', '****', $comment_msg);
    }
    $ret = C::t('#xigua_hb#xigua_hb_comment')->add($_G['uid'], intval($_GET['touid']), 0, $comment_msg, 0, 0, 5, array(), $_GET['type']);
    if ($ret) {
        $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_jy&ac=chats";
        notification_add($_GET['touid'], 'system', lang_hb('comment_to', 0), array('url' => $url, 'username' => $_G['username'], 'info' => $comment_msg), 1);
        hb_message(lang_hb('huifuchenggong', 0), 'success', '', $ret);
    } else {
        hb_message(lang_hb('huifushibai', 0), 'error');
    }
}