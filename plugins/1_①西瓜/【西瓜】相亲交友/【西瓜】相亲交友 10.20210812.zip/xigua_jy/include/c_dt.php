<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!$jy_config['jydt']){
    dheader('Location:'.$SCRITPTNAME.'?id=xigua_jy'.$urlext);
}
$cat_id = $jy_config['jydt'];
if(!$_GET['orderby']){
    $_GET['orderby'] = 'new';
}
$orderby = $_GET['orderby'];
$navtitle = lang_jy('orderby_'.$orderby,0);
$uid = intval($_GET['uid']);
if($uid){
    $myinfo = C::t('#xigua_jy#xigua_jy_user')->fetch($uid);
    $navtitle = $myinfo['nickname'].lang_jy('ddt',0);
}