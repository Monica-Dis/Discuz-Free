<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢�� wxiguabbs
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if (empty($_G['cache']['plugin'])) :
    loadcache('plugin');
endif;

$jy_config = $_G['cache']['plugin']['xigua_jy'];
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common_status.php';

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" /><style>img{object-fit:cover}</style>";
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_jy/static/admin_cp.css?45678\" />";
if ($secid = intval($_GET['secid'])) {
    $res = C::t('#xigua_jy#xigua_jy_hn')->fetch($secid);
    $unsetary = array( 'id', 'upts_u', 'crts_u', );
    $ts_ary = array('crts', 'upts');
    if (!submitcheck('dosubmit')) {
        if (!$res) {
            $neww = 1;
            $res =  array ('uid' => '', 'name' => '', 'wx' => '', 'mobile' => '', 'avatar' => '', 'qrcode' => '', 'description' => '', 'upts' => TIMESTAMP, 'crts' => TIMESTAMP, 'displayorder' => '1', 'status' => '1');
        }
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_jy('hngl', 0) . ($secid > 0 ? ' - ' . $res['name'] . " [ ID : $secid ]" : '') . "&nbsp;&nbsp;<a class='abtn' href='" . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong'>" . lang_jy('back', 0) . "</a>");

        foreach ($res as $index => $re) {
            if (in_array($index, $unsetary)) {
                continue;
            }
            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if (in_array($index, $ts_ary)) {
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            } elseif (in_array($index, array('status'))) {
                $cs = '<select name="editform[status]">';
                foreach (array_slice($hn_status, 1) as $c_t => $c) {
                    $s = '';
                    if ($c_t == $re) {
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            } elseif (in_array($index, array('avatar', 'qrcode'))) {
                $tp = 'filetext';
                $cmt = '<img style="max-height:100px" src="'.$re.'" />';
            }
            if ($index == 'description') {
                $_tmp1 = lang_jy($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[description]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            } else {
                showsetting(lang_jy($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');function changeurl(val){window.location.href = window.location.href+'&catid='+val;}</script>
HTML;

    } else {
        $editform = $_GET['editform'];
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__v['errno'] == 0) {
                $editform[$__k] = $__v['error'];
            }
        }
        foreach ($ts_ary as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }
        $editform['description'] = trim(htmlspecialchars_decode($editform['description']));

        if ($secid > 0) {
            $rs = C::t('#xigua_jy#xigua_jy_hn')->update($secid, $editform);
            $hid = $secid;
        } else {
            $hid = C::t('#xigua_jy#xigua_jy_hn')->insert($editform, 1);
        }
        cpmsg(lang_jy('czcg', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong&secid=$hid", 'succeed');
    }
} else {
    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_jy#xigua_jy_hn')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_jy#xigua_jy_hn')->update($id, array('status' => $item['status'], 'displayorder' => $item['displayorder']));
        }
        cpmsg(lang_jy('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong&page=$page", 'succeed');
    }
    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword < 9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    } else if ($keyword = stripsearchkey(addslashes($keyword))) {
        $wherearr[] = " (`name` LIKE '%$keyword%' OR mobile LIKE '%$keyword%' OR wx LIKE '%$keyword%' OR description LIKE '%$keyword%' ) ";
    }
    if ($_GET['status']) {
        $wherearr[] = 'status=' . intval($_GET['status']);
    }
    $ob = 'displayorder desc,id desc';
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong&page=$page");

    echo '<div><input type="text" id="keyword" placeholder="' . lang_jy('hnxm', 0).'/'. lang_jy('mobile', 0).'/'. lang_jy('wxh', 0) . '" name="keyword" value="' . $_GET['keyword'] . '" class="txt" style="width:200px" /> ';
    foreach ($hn_status as $index => $_v) {
        echo '<label><input type="radio" name="status" value="' . $index . '" ' . ($_GET['status'] == $index ? 'checked' : '') . ' />' . $_v . '</label>';
    }
    echo '&nbsp;&nbsp;';

    echo '&nbsp;';
    echo ' <input name="page" value="1" type="hidden" /><input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href=' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong" . ' class="btn" >' . cplang('reset') . '</a> ';
    echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px;border:1px solid #ffda77;}.mt3{margin-top:3px}.c9{color:#999}
.jobtit{font-size:13px;color:#369}.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;font-size:12px;border-radius:2px}
.jthumb{width:50px;height:50px}.red{color:#ff6565}.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.tyu{width:60px;display:block;color:#4caf50}.tyu.jingjia{color:#ff6565}.vdesc{width:250px;max-height:150px;overflow-y:auto}.priceText{color:#ff6565}.qy{color:#4F7CB8}.v_mingxi{max-width:250px}.btn2{padding: 3px 5px;line-height:30px;}.btn3{background: #DADADA;color: #999;}
</style>";
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong&secid=-1\" class=\"btn bg_green\">" . lang_jy('tjsp', 0) . "</a></div>";

    showtableheader(lang_jy('hngl', 0));
    showtablerow('class="header"', array(), array(
        lang_jy('del', 0),
        lang_jy('displayorder', 0),
        lang_jy('avatar', 0),
        lang_jy('name', 0),
        lang_jy('uids', 0),
        lang_jy('mobile', 0),
        lang_jy('wxh', 0),
        lang_jy('qrcode', 0),
        lang_jy('description', 0),
        lang_jy('status', 0),
        lang_jy('crts', 0),
        lang_jy('caozuo', 0),
    ));
    $res = C::t('#xigua_jy#xigua_jy_hn')->fetch_all_by_page($wherearr, $start_limit, $lpp, '*', $ob);
    $icount = C::t('#xigua_jy#xigua_jy_hn')->fetch_count_by_page($wherearr);

    $uids = $shids = array();
    foreach ($res as $k => $v) {
        $uids[$v['uid']] = $v['uid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    foreach ($res as $v) {
        $id = $v['id'];
        $thumb = $v['avatar'] ? $v['avatar'] : 'source/plugin/xigua_jy/static/img/dftava.png';
        $img = '';
        $status_u = "<select name=\"row[$id][status]\">";
        foreach (array_slice($hn_status, 1) as $k => $vv) {
            if ($v['status'] == $k) {
                $s = 'selected';
            } else {
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input style='width:20px' type='text' class='txt' name='row[$id][displayorder]' value='{$v[displayorder]}' />",
            "<img src='$thumb' class='jthumb' />",
            $v['name'],
            $users[$v['uid']]['username'].' [ '.$v['uid'].' ]',
            $v['mobile'],
            $v['wx'],
            "<img src='{$v['qrcode']}' class='jthumb' />",
            "<div style='width:200px;height:60px;overflow-y:auto'>{$v['description']}</div>",
            $status_u,
            $v['crts_u'].'<br>'.$v['upts_u'],
            '<a class=\'btn bg_green btn2\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong&secid=$id" . '">' . lang_jy('edit', 0) . '</a>',
        ));
    }
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
}