<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2020/10/10
 * Time: 15:16
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_black` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `blackuid` int(11) unsigned NOT NULL,
 `uid` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `blackid` (`blackuid`,`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_hn` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `name` varchar(80) NOT NULL,
 `wx` varchar(200) NOT NULL,
 `mobile` varchar(80) NOT NULL,
 `avatar` varchar(200) NOT NULL,
 `qrcode` varchar(200) NOT NULL,
 `description` text NOT NULL,
 `upts` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `status` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_index` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `types` varchar(20) NOT NULL,
 `style` varchar(20) NOT NULL,
 `catids` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `types` (`types`),
 KEY `catids` (`catids`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_qianxian` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `touid` int(11) unsigned NOT NULL,
 `uid` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `status` int(11) NOT NULL,
 `taocan_id` int(11) NOT NULL,
 `allowalbum` int(11) NOT NULL,
 `allowvideo` int(11) NOT NULL,
 `note` text NOT NULL,
 `hnids` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `touid_2` (`touid`,`uid`),
 KEY `hnids` (`hnids`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_taocan` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `type` varchar(20) NOT NULL,
 `uid` int(11) unsigned NOT NULL,
 `name` varchar(200) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `total` int(11) unsigned NOT NULL,
 `used` int(11) NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `upts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `order_id` varchar(200) NOT NULL,
 `payts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `endts` (`endts`),
 KEY `type` (`type`),
 KEY `uid` (`uid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_user` (
 `uid` int(11) NOT NULL,
 `gender` tinyint(1) NOT NULL,
 `order_id` char(24) NOT NULL,
 `shows` int(11) NOT NULL,
 `status` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `note` varchar(800) NOT NULL,
 `nickname` varchar(80) NOT NULL,
 `birthday` varchar(20) NOT NULL,
 `mobile` varchar(20) NOT NULL,
 `wx` varchar(80) NOT NULL,
 `avatar` varchar(500) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `dig_startts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `zsbq` varchar(300) NOT NULL,
 `wdah` varchar(300) NOT NULL,
 `jtqk` varchar(300) NOT NULL,
 `shuxiang` varchar(20) NOT NULL,
 `xingzuo` varchar(20) NOT NULL,
 `shengao` varchar(20) NOT NULL,
 `tizhong` varchar(20) NOT NULL,
 `jiaxiang` varchar(200) NOT NULL,
 `gongzuodi` varchar(200) NOT NULL,
 `xueli` varchar(20) NOT NULL,
 `hunyin` varchar(20) NOT NULL,
 `zhiye` varchar(20) NOT NULL,
 `shouru` varchar(20) NOT NULL,
 `goufang` varchar(20) NOT NULL,
 `gouche` varchar(20) NOT NULL,
 `xiyan` varchar(20) NOT NULL,
 `hejiu` varchar(20) NOT NULL,
 `video` varchar(200) NOT NULL,
 `video_cover` varchar(200) NOT NULL,
 `album` text NOT NULL,
 `y_nianling` varchar(200) NOT NULL,
 `y_shengao` varchar(200) NOT NULL,
 `y_xueli` varchar(200) NOT NULL,
 `y_zhiye` varchar(200) NOT NULL,
 `y_shouru` varchar(200) NOT NULL,
 `y_hunyin` varchar(200) NOT NULL,
 `y_goufang` varchar(200) NOT NULL,
 `y_xiyan` varchar(200) NOT NULL,
 `y_hejiu` varchar(200) NOT NULL,
 `y_note` varchar(200) NOT NULL,
 `vip_index` int(11) NOT NULL,
 `vip_name` varchar(80) NOT NULL,
 `vip_startts` int(11) NOT NULL,
 `vip_endts` int(11) NOT NULL,
 `vip_info` varchar(800) NOT NULL,
 `hnids` varchar(200) NOT NULL,
 `views` int(11) NOT NULL,
 `follows` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `zans` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `base_status` int(11) NOT NULL,
 `reson` varchar(200) NOT NULL,
 PRIMARY KEY (`uid`),
 KEY `stid` (`stid`),
 KEY `status` (`status`),
 KEY `wx` (`wx`),
 KEY `displayorder` (`displayorder`),
 KEY `zans` (`zans`),
 KEY `follows` (`follows`),
 KEY `views` (`views`),
 KEY `shares` (`shares`),
 KEY `dig_startts` (`dig_startts`),
 KEY `dig_endts` (`dig_endts`),
 KEY `base_status` (`base_status`),
 KEY `video` (`video`),
 KEY `vip_index` (`vip_index`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_viewlog` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(1) NOT NULL,
 `visiter` int(11) NOT NULL,
 `visiter_name` varchar(40) NOT NULL,
 `crts` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_vipguide` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `subject` varchar(200) NOT NULL,
 `content` text NOT NULL,
 `crts` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `indexpop` int(11) NOT NULL,
 `link` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `link` (`link`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_jy_top` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;
SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_jy/discuz_plugin_xigua_jy.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_jy/discuz_plugin_xigua_jy_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_jy/discuz_plugin_xigua_jy_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_jy/discuz_plugin_xigua_jy_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_jy/discuz_plugin_xigua_jy_TC_UTF8.xml');

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/xigua_jy/install.php');


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'reson\'', array('xigua_jy_user'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_jy_user` ADD `reson` VARCHAR(200) NOT NULL;

SQL;
    runquery($sql);
}


$r3 = DB::fetch_first('SELECT * FROM %t  WHERE 1 LIMIT 1', array('xigua_jy_vipguide'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_jy_vipguide` (`id`, `subject`, `content`, `crts`, `displayorder`, `stid`, `indexpop`, `link`) VALUES {$installlang['vipguide']}
SQL;
    runquery($sql);
}

$r3 = DB::fetch_first('SELECT * FROM %t  WHERE 1 LIMIT 1', array('xigua_jy_nav'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_jy_nav` (`id`, `pid`, `name`, `icon`, `icon2`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `aprice`, `iconname`, `up`, `highlight`, `type`) VALUES
(1, 0, '{$installlang['jy']}', 'source/plugin/xigua_jy/static/img/6.png', 'source/plugin/xigua_jy/static/img/25.png', '', 'plugin.php?id=xigua_jy&amp;ac=index', 1613448937, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(2, 0, '{$installlang['sp']}', 'source/plugin/xigua_jy/static/img/2.png', 'source/plugin/xigua_jy/static/img/24.png', '', 'plugin.php?id=xigua_jy&amp;orderby=video', 1613448937, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(3, 0, '{$installlang['hn']}', 'source/plugin/xigua_jy/static/img/3.png', 'source/plugin/xigua_jy/static/img/23.png', '', 'plugin.php?id=xigua_jy&amp;ac=hn', 1613448937, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(4, 0, '{$installlang['lt']}', 'source/plugin/xigua_jy/static/img/4.png', 'source/plugin/xigua_jy/static/img/22.png', '', 'plugin.php?id=xigua_jy&amp;ac=chats', 1613448937, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(5, 0, '{$installlang['wd']}', 'source/plugin/xigua_jy/static/img/5.png', 'source/plugin/xigua_jy/static/img/21.png', '', 'plugin.php?id=xigua_jy&amp;ac=my', 1613448937, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', '');
SQL;
    runquery($sql);
}

$r3 = DB::fetch_first('SELECT * FROM %t  WHERE 1 LIMIT 1', array('xigua_jy_index'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_jy_index` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `aprice`, `types`, `style`, `catids`) VALUES
(4, 0, 'index', 'source/plugin/xigua_jy/static/slider/my_pic_hb.png', '', '', 1616951229, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', '4', ''),
(5, 0, 'index', 'source/plugin/xigua_jy/static/slider/my_pic_hd.png', '', '', 1616951229, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', '4', ''),
(6, 0, 'index', 'source/plugin/xigua_jy/static/slider/my_pic_sj.png', '', '', 1616951229, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', '4', ''),
(8, 0, 'index', 'source/plugin/xigua_jy/static/slider/my_pic_yh.png', '', '', 1616979450, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', '4', '');
SQL;
    runquery($sql);
}

$r3 = DB::fetch_first('SELECT * FROM %t  WHERE 1 LIMIT 1', array('xigua_jy_top'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_jy_top` (`id`, `pid`, `name`, `icon`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `aprice`) VALUES
(1, 0, '{$installlang['tj']}', 'source/plugin/xigua_jy/static/slider/top1.png', '', 'plugin.php?id=xigua_jy&orderby=', 1617132362, 1, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00'),
(2, 0, '{$installlang['bz']}', 'source/plugin/xigua_jy/static/slider/top4.png', '', 'plugin.php?id=xigua_jy&ac=my&do=biaozhun', 1617132366, 4, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00'),
(3, 0, '{$installlang['vip']}', 'source/plugin/xigua_jy/static/slider/top3.png', '', 'plugin.php?id=xigua_jy&ac=my&do=vip', 1617132802, 3, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00'),
(4, 0, '{$installlang['wdxq']}', 'source/plugin/xigua_jy/static/slider/top5.png', '', 'plugin.php?id=xigua_jy&ac=my', 1617132802, 5, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00'),
(8, 0, '{$installlang['hd']}', 'source/plugin/xigua_jy/static/slider/top2.png', '', 'plugin.php?id=xigua_he', 1617133536, 2, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00');

SQL;
    runquery($sql);
}
