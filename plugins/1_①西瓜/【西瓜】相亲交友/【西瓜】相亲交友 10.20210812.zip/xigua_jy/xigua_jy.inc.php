<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!is_file(DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php')) {
	exit('Please install <a href="https://addon.dismall.com/plugins/xigua_hb.html">https://addon.dismall.com/plugins/xigua_hb.html</a>');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
$jy_config = $_G['cache']['plugin']['xigua_jy'];
$data = array();
$ac = $_GET['ac'];
$do = $_GET['do'];
$aclist = array('index', 'add', 'my', 'misc', 'choose', 'view', 'taocan', 'com', 'mytd', 'myview', 'search', 'join', 'album', 'upv', 'mem_li', 'qianxian', 'chats', 'chat', 'comment_li', 'hn', 'hn_li', 'chatcmt', 'dt');
$aclist_login = array('add', 'my', 'choose', 'join', 'album', 'upv', 'view', 'qianxian', 'chats', 'chat', 'chatcmt', 'dt');
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
if (in_array($ac, $aclist_login) && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $jy_config['dftcolor'];
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common_status.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/function.php';
$opens = unserialize($_G['cache']['plugin']['xigua_jy']['opens']);
$pfary = $fsms = $score_names = $score_colors = array();
switch ($ac) {
	case 'upv':
		$ERROR_MSG = '';
		if ($config['qn_ak'] && $config['qn_sk'] && $config['qn_bk'] && $config['qn_url']) {
			include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/lib/Qiniu/upload.php';
			$token = hb_qn_gettoken();
			if ($token) {
				hb_message($token, 'success');
			} else {
				hb_message($ERROR_MSG, 'error');
			}
		}
		hb_message('No data', 'error');
		break;
	case 'comment_li':
		$comments = array();
		if ($_GET['cid']) {
			$comments[] = C::t('#xigua_hb#xigua_hb_comment')->fetch($_GET['cid']);
		} else {
			if ($_GET['type'] == 'tome') {
				$comments = C::t('#xigua_hb#xigua_hb_comment')->fetch_comment_by_pubuid($_G['uid'], $start_limit, $lpp);
			} elseif ($_GET['type'] == 'sx') {
				$comments = C::t('#xigua_hb#xigua_hb_comment')->fetch_comment_by_type($_G['uid'], 1, $start_limit, $lpp);
			}
		}
		$uids = array();
		foreach ($comments as $index => $comment) {
			$uids[] = $comment['authorid'];
		}
		if ($uids) {
			$jyusers = C::t('#xigua_jy#xigua_jy_user')->fetch_all_by_where(array('uid in (' . implode(',', $uids) . ')'), 0, count($uids), 'uid');
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_jy:chats_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'chats':
		$navtitle = lang_jy('lt', 0);
		$_GET['type'] = 'sx';
		break;
	case 'chat':
		$touid = intval($_GET['touid']);
		$touser = getuserbyuid($touid);
		$jyusers = C::t('#xigua_jy#xigua_jy_user')->fetch_all_by_where(array('uid in (' . $touid . ', ' . $_G['uid'] . ')'), 0, 2, 'uid');
		$lpp = 100;
		$online = C::app()->session->fetch_by_uid($touid) ? 1 : 0;
		$navtitle = $desc = lang_hb('yu', 0) . $jyusers[$touid]['nickname'] . ' ' . lang_hb('online_' . $online, 0) . lang_hb('ltz', 0);
		if ($_GET['do'] == 'chat_li') {
			$list = C::t('#xigua_hb#xigua_hb_comment')->fetch_all_bypage(array(' ((touid=\'' . $touid . '\' and authorid=' . $_G['uid'] . ' ) OR (authorid=\'' . $touid . '\' and touid=' . $_G['uid'] . ')) '), $start_limit, $lpp, ' cid DESC ');
			$list = array_reverse($list);
			include template('xigua_hb:header_ajax');
			include template('xigua_jy:chat_li');
			include template('xigua_hb:footer_ajax');
		} elseif ($_GET['do'] == 'fetch') {
			$cid = intval($_GET['cid']);
			$list = array();
			$r = C::t('#xigua_hb#xigua_hb_comment')->fetch_by_cid($cid);
			$list[0] = $r;
			include template('xigua_hb:header_ajax');
			include template('xigua_jy:chat_li');
			include template('xigua_hb:footer_ajax');
		} elseif ($_GET['do'] == 'fetchpm') {
			$list = C::t('#xigua_hb#xigua_hb_comment')->fetch_all_bypage(array(' (authorid=\'' . $touid . '\' and touid=' . $_G['uid'] . ') AND isnew=0 '), $start_limit, $lpp, ' cid DESC ');
			foreach ($list as $index => $item) {
				C::t('#xigua_hb#xigua_hb_comment')->update($item['cid'], array('isnew' => TIMESTAMP));
			}
			$list = array_reverse($list);
			include template('xigua_hb:header_ajax');
			include template('xigua_jy:chat_li');
			include template('xigua_hb:footer_ajax');
		} elseif ($_GET['do'] == 'incr_jf') {
			if ($_G['uid'] > 0) {
				$key = 'jifen1_' . date('Y_m_d') . '_' . $_G['uid'];
				loadcache($key);
				if ($_G['cache'][$key] >= $config['shangxian']) {
					exit('xx');
				}
				savecache($key, $_G['cache'][$key] + $config['meici']);
				updatemembercount($_G['uid'], array($config['credit_type'] => $config['meici']), true, '', $_G['uid']);
				exit('ok');
			}
		}
		break;
	case 'index':
		$navtitle = str_replace(array('{tname}', lang_jy('zhan', 0)), array($stinfo['name'], ''), $jy_config['defaulttitle']);
		$desc = str_replace(array('{tname}', lang_jy('zhan', 0)), array($stinfo['name'], ''), $jy_config['defaultdesc']);
		$topnavslider = hb_parse_set($jy_config['topslider']);
		$_key = 'hbpubIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
			$distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			$distjsary = array_values($distjsary);
			savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
		} else {
			$distjsary = $_G['cache'][$_key]['variable'][0];
		}
		$dftgender = 0;
		if ($_G['uid'] > 0 && $jy_config['yixing'] == 1) {
			$myinfo = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
			$dftgender = $myinfo['gender'] == 1 ? 2 : 1;
		}
		$newest = C::t('#xigua_jy#xigua_jy_qianxian')->fetch_all_by_page(array('status=1'), 0, 5, '*');
		$numshow = $jy_config['indexnav_1'] * 5;
		$widthshow = $jy_config['indexnav_2'] > 0 ? 100 / $jy_config['indexnav_2'] . '%' : '20%';
		$tmp = C::t('#xigua_jy#xigua_jy_top')->list_by_pid(0, true);
		$navlist = $indexlist = array();
		foreach ($tmp as $index => $item) {
			if (!$item['icon']) {
				$navlist[] = $item;
			} else {
				$indexlist[] = $item;
			}
		}
		$jing_list = array_values($indexlist);
		if ($jing_list) {
			$jing_count = range(0, ceil(count($jing_list) / $numshow) - 1);
		}
		break;
	case 'hn_li':
		$ob = 'displayorder desc,id desc';
		$list = C::t('#xigua_jy#xigua_jy_hn')->fetch_all_by_page(array('status=1'), $start_limit, $lpp, '*', $ob);
		include template('xigua_hb:header_ajax');
		include template('xigua_jy:hn_li');
		include template('xigua_hb:footer_ajax');
		exit(0);
		break;
	case 'mem_li':
		if ($_G['uid']) {
			$mine = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
		}
		$where = array();
		if ($jy_config['listws']) {
			$where[] = 'status!=-2 AND shows=1 AND base_status=1';
		} else {
			$where[] = 'status!=-2 AND shows=1';
		}
		if ($keyword = $_GET['keyword']) {
			if (is_numeric($keyword)) {
				$where[] = 'uid=' . $keyword;
			} else {
				$where[] = 'nickname like \'%' . stripsearchkey(addslashes($keyword)) . '%\'';
			}
		}
		if (isset($_GET['gender'])) {
			if ($_GET['gender']) {
				$where[] = 'gender=' . intval($_GET['gender']);
			}
		} else {
			if ($jy_config['yixing'] == 1) {
				if ($mine['gender'] == 1) {
					$where[] = 'gender=2';
				} elseif ($mine['gender'] == 2) {
					$where[] = 'gender=1';
				}
			}
		}
		foreach ($biaozhun_status as $index => $biaozhun_statu) {
			$tmp = array();
			$nolimit = 0;
			if (isset($_GET[$index]) && $_GET[$index] != $nolimit) {
				$valary = explode(',', $_GET[$index]);
				foreach ($valary as $item) {
					$tmp[] = $biaozhun_statu['data_ary'][$item];
				}
			}
			if ($tmp) {
				switch ($index) {
					case 'y_nianling':
						$where[] = parse_age_date($tmp);
						break;
					case 'y_shengao':
						$where[] = parse_shengao($tmp);
						break;
					case 'y_xueli':
						$where[] = parse_like($tmp, 'xueli');
						break;
					case 'y_zhiye':
						$where[] = parse_like($tmp, 'zhiye');
						break;
					case 'y_hunyin':
						$where[] = parse_like($tmp, 'hunyin');
						break;
					case 'y_goufang':
						$where[] = parse_like($tmp, 'goufang');
						break;
					case 'y_xiyan':
						$where[] = parse_like($tmp, 'xiyan');
						break;
					case 'y_hejiu':
						$where[] = parse_like($tmp, 'hejiu');
				}
			}
		}
		if ($_GET['jiaxiang'] && $_GET['jiaxiang'] != 0 - 1) {
			$where[] = parse_like(explode(',', $_GET['jiaxiang']), 'jiaxiang', 1);
		}
		if ($_GET['gongzuodi'] && $_GET['gongzuodi'] != 0 - 1) {
			$where[] = parse_like(explode(',', $_GET['gongzuodi']), 'gongzuodi', 1);
		}
		$GLOBALS['need_verify'] = 1;
		if ($_GET['orderby'] == 'video') {
			$where[] = 'video!=\'\'';
		}
		$where = array_filter($where);
		$list = C::t('#xigua_jy#xigua_jy_user')->fetch_all_by_where($where, $start_limit, $lpp);
		include template('xigua_hb:header_ajax');
		include template('xigua_jy:mem_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'my':
		switch ($_GET['do']) {
			case 'payshows':
				if (submitcheck('formhash')) {
					$user = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
					if (!check_base($user, 1)) {
						hb_message(lang_jy('qwx', 0), 'loading', $SCRITPTNAME . '?id=xigua_jy&ac=my&do=base');
					}
					if ($needpay = $jy_config['mode_price']) {
						$url = $SCRITPTNAME . '?id=xigua_jy&ac=my' . $urlext;
						$title = lang_jy('zfshf', 0) . $needpay . lang_jy('yuan', 0);
						$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $needpay, $title, 'common_jy_shenhe', array('data' => array('uid' => $_G['uid'], 'price' => $needpay, 'name' => $title), 'callback' => array('file' => 'source/plugin/xigua_jy/function_taocan.php', 'method' => 'jy_shows_callback'), 'location' => $_G['siteurl'] . $url));
						$rl = urlencode($url);
						$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
						hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
					}
				}
				break;
			case 'kan':
				$back_to_overwrite = $SCRITPTNAME . '?id=xigua_jy&ac=my' . $urlext;
				if ($_GET['type'] == 'tome') {
					$navtitle = lang_jy('skgw', 0);
					if ($_GET['li'] == 1) {
						$_lst = C::t('#xigua_jy#xigua_jy_viewlog')->fetch_all_by_page(array('uid=' . $_G['uid']), $start_limit, $lpp, 'visiter');
					}
				} else {
					$navtitle = lang_jy('wkgs', 0);
					if ($_GET['li'] == 1) {
						$_lst = C::t('#xigua_jy#xigua_jy_viewlog')->fetch_all_by_page(array('visiter=' . $_G['uid']), $start_limit, $lpp, 'uid');
					}
				}
				if ($_GET['li'] == 1) {
					if ($_lst) {
						$favids = array();
						foreach ($_lst as $index => $item) {
							if ($_GET['type'] == 'tome') {
								$favids[] = intval($item['visiter']);
							} else {
								$favids[] = intval($item['uid']);
							}
						}
						if ($favids) {
							$where = array();
							$where[] = 'status!=-2';
							$where[] = 'uid in (' . implode(',', $favids) . ')';
							$GLOBALS['need_verify'] = 1;
							$extlist = $_lst;
							$list = C::t('#xigua_jy#xigua_jy_user')->fetch_all_by_where($where, $start_limit, $lpp);
						}
					}
					include template('xigua_hb:header_ajax');
					include template('xigua_jy:mem_li');
					include template('xigua_hb:footer_ajax');
				} else {
					$favnum1 = DB::result_first('select count(*) from %t where uid=%d', array('xigua_jy_viewlog', $_G['uid']));
					$favnum2 = DB::result_first('select count(*) from %t where visiter=%d', array('xigua_jy_viewlog', $_G['uid']));
					include template('xigua_jy:my_kan');
				}
				exit(0);
				break;
			case 'qianxian':
				$navtitle = lang_jy('wdqx', 0);
				$user = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
				$avatar = $user['avatar'] ? $user['avatar'] : avatar($_G['uid'], 'middle', true);
				if (!$user) {
					dheader('Location: ' . $SCRITPTNAME . '?id=xigua_jy&ac=join&step=1');
				}
				$my_line = C::t('#xigua_jy#xigua_jy_taocan')->get_my_num($_G['uid'], 'line');
				$my_line_num = $my_line['leave'];
				$lang_qianxian = lang_jy('qianxian', 0);
				$tcname = array();
				$tcname[] = $lang_qianxian;
				if ($tcname) {
					$vipshuoming = DB::fetch_all('select * from %t where subject in (%n)', array('xigua_jy_vipguide', $tcname), 'subject');
				}
				$qxlist_other = C::t('#xigua_jy#xigua_jy_qianxian')->fetch_all_by_page(array('uid=' . intval($_G['uid'])), 0, 99, 'touid');
				$uids = array();
				foreach ($qxlist_other as $index => $item) {
					$uids[] = $item['touid'];
				}
				if ($uids) {
					$list_other = C::t('#xigua_jy#xigua_jy_user')->fetch_all_by_where(array('uid IN(' . implode(',', $uids) . ')'), 0, 999);
				}
				$qxlist_me = C::t('#xigua_jy#xigua_jy_qianxian')->fetch_all_by_page(array('touid=' . intval($_G['uid'])), 0, 99, 'uid');
				$uids = array();
				foreach ($qxlist_me as $index => $item) {
					$uids[] = $item['uid'];
				}
				if ($uids) {
					$list_me = C::t('#xigua_jy#xigua_jy_user')->fetch_all_by_where(array('uid IN(' . implode(',', $uids) . ')'), 0, 999);
				}
				include template('xigua_jy:my_qianxian');
				exit(0);
				break;
			case 'oneline':
				$url = $SCRITPTNAME . '?id=xigua_jy&ac=my' . $urlext;
				if ($backuid = intval($_GET['backuid'])) {
					$url = $SCRITPTNAME . '?id=xigua_jy&ac=view&jyid=' . $backuid . $urlext;
				}
				if (submitcheck('formhash')) {
					if ($jy_config['dcqx']) {
						$needpay = $jy_config['dcqx'];
						$title = lang_jy('gmdc', 0);
						$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $needpay, $title, 'common_jy_danci', array('data' => array('uid' => $_G['uid'], 'price' => $needpay, 'name' => $title), 'callback' => array('file' => 'source/plugin/xigua_jy/function_taocan.php', 'method' => 'jy_danci_callback'), 'location' => $_G['siteurl'] . $url));
						$rl = urlencode($url);
						$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
						hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
					}
				}
				exit(0);
				break;
			case 'do_guanzhu':
				if (submitcheck('formhash')) {
					$doid = intval($_GET['doid']);
					if ($doid == $_G['uid']) {
						hb_message(lang_jy('bngzzj', 0), 'error');
					}
					$type = 'jy';
					if ($old = C::t('#xigua_hb#xigua_hb_follow')->fetch_follow_by_favid_uid($doid, $_G['uid'], $type)) {
						C::t('#xigua_hb#xigua_hb_follow')->deletes(array($old['id']), $type);
						$ret = 0 - 1;
					} else {
						if ($id = C::t('#xigua_hb#xigua_hb_follow')->insert(array('favid' => $doid, 'favtype' => $type, 'uid' => $_G['uid'], 'crts' => TIMESTAMP, 'upts' => TIMESTAMP), true, false, true)) {
							C::t('#xigua_jy#xigua_jy_user')->incr($doid, 'follows');
							$ret = 1;
						}
					}
					if ($ret > 0) {
						hb_message(lang_jy('gzcg', 0), 'success', 'reload');
					} else {
						hb_message(lang_jy('qxgz', 0), 'success', 'reload');
					}
				}
				exit(0);
				break;
			case 'guanzhu':
				$back_to_overwrite = $SCRITPTNAME . '?id=xigua_jy&ac=my' . $urlext;
				if ($_GET['type'] == 'tome') {
					$navtitle = lang_jy('gzwd', 0);
					if ($_GET['li'] == 1) {
						$_lst = C::t('#xigua_hb#xigua_hb_follow')->fetch_all_by_page(array('favtype=\'jy\' AND favid=' . $_G['uid']), $start_limit, $lpp);
					}
				} else {
					$navtitle = lang_hb('wodeguanzhu', 0);
					if ($_GET['li'] == 1) {
						$_lst = C::t('#xigua_hb#xigua_hb_follow')->fetch_all_by_page(array('favtype=\'jy\' AND uid=' . $_G['uid']), $start_limit, $lpp);
					}
				}
				if ($_GET['li'] == 1) {
					if ($_lst) {
						$favids = array();
						foreach ($_lst as $index => $item) {
							$favids[] = intval($item['favid']);
						}
						if ($favids) {
							$where = array();
							$where[] = 'status!=-2';
							$where[] = 'uid in (' . implode(',', $favids) . ')';
							$GLOBALS['need_lastts'] = 1;
							$GLOBALS['need_verify'] = 1;
							$list = C::t('#xigua_jy#xigua_jy_user')->fetch_all_by_where($where, $start_limit, $lpp);
						}
					}
					include template('xigua_hb:header_ajax');
					include template('xigua_jy:mem_li');
					include template('xigua_hb:footer_ajax');
				} else {
					$favnum1 = DB::result_first('select count(*) from %t where favtype=\'jy\' AND uid=%d', array('xigua_hb_follow', $_G['uid']));
					$favnum2 = DB::result_first('select count(*) from %t where favtype=\'jy\' AND favid=%d', array('xigua_hb_follow', $_G['uid']));
					include template('xigua_jy:my_guanzhu');
				}
				exit(0);
				break;
			case 'vip':
				if (submitcheck('formhash')) {
					$viptype = intval($_GET['form']['viptype']);
					$url = $SCRITPTNAME . '?id=xigua_jy&ac=my' . $urlext;
					if ($backuid = intval($_GET['backuid'])) {
						$url = $SCRITPTNAME . '?id=xigua_jy&ac=view&jyid=' . $backuid . $urlext;
					}
					if ($vip_taocan[$viptype]) {
						$needpay = $vip_taocan[$viptype]['price'];
						$title = $vip_taocan[$viptype]['name'] . ' ' . $vip_taocan[$viptype]['desc'];
						$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $needpay, $title, 'common_jy_vip', array('data' => array('uid' => $_G['uid'], 'price' => $needpay, 'vipinfo' => $vip_taocan[$viptype], 'vipindex' => $viptype), 'callback' => array('file' => 'source/plugin/xigua_jy/function_taocan.php', 'method' => 'jy_vip_taocan_callback'), 'location' => $_G['siteurl'] . $url));
						$rl = urlencode($url);
						$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
						hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
					}
				} else {
					$bgfc8 = hb_hex2rgb($config['maincolor'], 0);
					$navtitle = lang_jy('gmvip', 0);
					$user = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
					$avatar = $user['avatar'] ? $user['avatar'] : avatar($_G['uid'], 'middle', true);
					$tcname = array();
					foreach ($vip_taocan as $index => $item) {
						$tcname[] = $item['name'];
					}
					$lang_qianxian = lang_jy('qianxian', 0);
					$tcname[] = $lang_qianxian;
					if ($tcname) {
						$vipshuoming = DB::fetch_all('select * from %t where subject in (%n)', array('xigua_jy_vipguide', $tcname), 'subject');
					}
					include template('xigua_jy:my_vip');
				}
				exit(0);
				break;
			case 'save_status':
				if (submitcheck('formhash')) {
					C::t('#xigua_jy#xigua_jy_user')->update($_G['uid'], array('status' => intval($_GET['status'])));
					hb_message(lang_jy('bccg', 0), 'success', $SCRITPTNAME . '?id=xigua_jy&ac=my');
				}
				exit(0);
				break;
			case 'dig':
				if (submitcheck('formhash')) {
					$digday = $_GET['form']['viptype'];
					$url = $SCRITPTNAME . '?id=xigua_jy&ac=my' . $urlext;
					if ($digtaocan[$digday]) {
						$needpay = $digtaocan[$digday]['id'];
						$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $needpay, $digtaocan[$digday]['name'], 'common_jy_dig', array('data' => array('uid' => $_G['uid'], 'price' => $needpay, 'name' => $digtaocan[$digday]['name'], 'days' => $digtaocan[$digday]['times']), 'callback' => array('file' => 'source/plugin/xigua_jy/function_taocan.php', 'method' => 'jy_dig_taocan_callback'), 'location' => $_G['siteurl'] . $url));
						$rl = urlencode($url);
						$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
						hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
					}
				} else {
					$navtitle = lang_jy('gmzd', 0);
					include template('xigua_jy:my_dig');
				}
				exit(0);
				break;
			case 'line':
				if (submitcheck('formhash')) {
					$vp = $_GET['form']['viptype'];
					$url = $SCRITPTNAME . '?id=xigua_jy&ac=my' . $urlext;
					if ($backuid = intval($_GET['backuid'])) {
						$url = $SCRITPTNAME . '?id=xigua_jy&ac=view&jyid=' . $backuid . $urlext;
					}
					if ($qxtaocan[$vp]) {
						$needpay = $qxtaocan[$vp]['id'];
						$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $needpay, $qxtaocan[$vp]['name'], 'common_jy_line', array('data' => array('uid' => $_G['uid'], 'price' => $needpay, 'name' => $qxtaocan[$vp]['name'], 'times' => $qxtaocan[$vp]['times'], 'endays' => $qxtaocan[$vp]['endays']), 'callback' => array('file' => 'source/plugin/xigua_jy/function_taocan.php', 'method' => 'jy_line_taocan_callback'), 'location' => $_G['siteurl'] . $url));
						$rl = urlencode($url);
						$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
						hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
					}
				} else {
					$navtitle = lang_jy('gmhn', 0);
					include template('xigua_jy:my_line');
				}
				exit(0);
				break;
			case 'biaozhun':
				$navtitle = lang_jy('wdzobz', 0);
				if (submitcheck('formhash')) {
					$form = $_GET['form'];
					$data = array();
					foreach ($biaozhun_status as $index => $item) {
						$data[$index] = $form[$index];
					}
					$data['y_note'] = $form['y_note'];
					$data['upts'] = $form['TIMESTAMP'];
					C::t('#xigua_jy#xigua_jy_user')->update($_G['uid'], $data);
					hb_message(lang_jy('bccg', 0), 'success', $SCRITPTNAME . '?id=xigua_jy&ac=my');
				}
				$old_data = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
				include template('xigua_jy:my_biaozhun');
				exit(0);
				break;
			case 'album':
				if (submitcheck('formhash')) {
					$form = $_GET['form'];
					$data = array('album' => implode(',', $form['album']), 'video' => $form['video'], 'video_cover' => $form['video_cover'], 'upts' => TIMESTAMP);
					C::t('#xigua_jy#xigua_jy_user')->update($_G['uid'], $data);
					hb_message(lang_jy('bccg', 0), 'success', $SCRITPTNAME . '?id=xigua_jy&ac=my');
				}
				$navtitle = lang_jy('wdxc', 0);
				$showv = $jy_config['maxsize'] > 0 && ($config['qn_ak'] && $config['qn_sk'] && $config['qn_bk'] && $config['qn_url'] || $config['ACCESS_ID'] && $config['ACCESS_KEY'] && $config['ENDPOINT'] && $config['BUCKET']);
				$old_data = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
				include template('xigua_jy:my_album');
				exit(0);
				break;
			case 'base':
				$mobile = check_bind_jy();
				$navtitle = lang_jy('bjzl', 0);
				$old_data = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
				if (submitcheck('formhash')) {
					if (!$old_data) {
						hb_message('error', 'error', $SCRITPTNAME . '?id=xigua_jy&ac=join&step=1');
					}
					$form = $_GET['form'];
					if (!$form['nickname']) {
						hb_message(lang_jy('qtxndnc', 0), 'error');
					}
					if (!$form['wx']) {
						hb_message(lang_jy('qtx', 0) . lang_jy('wxh', 0), 'error');
					}
					if (C::t('#xigua_jy#xigua_jy_user')->nickname_exists($form['nickname'])) {
						hb_message(lang_jy('ncycz', 0), 'error');
					}
					$avat = is_array($form['avatar']) ? $form['avatar'][0] : $form['avatar'];
					$form['birthday'] = str_replace(array(lang_jy('n', 0), lang_jy('y', 0), lang_jy('r', 0)), array('-', '-', ''), $form['birthday']);
					$data = array('stid' => $form['stid'], 'avatar' => $avat, 'note' => $form['note'], 'nickname' => $form['nickname'], 'wx' => $form['wx'], 'mobile' => $mobile ? $mobile : $form['mobile'], 'birthday' => $form['birthday'], 'shuxiang' => _jy_get_animal($form['birthday']), 'xingzuo' => _jy_get_constellation($form['birthday']), 'shengao' => intval($form['shengao']), 'tizhong' => intval($form['tizhong']), 'jiaxiang' => $form['jiaxiang'], 'gongzuodi' => $form['gongzuodi'], 'xueli' => $form['xueli'], 'hunyin' => $form['hunyin'], 'zhiye' => $form['zhiye'], 'shouru' => $form['shouru'], 'goufang' => $form['goufang'], 'gouche' => $form['gouche'], 'xiyan' => $form['xiyan'], 'hejiu' => $form['hejiu'], 'upts' => TIMESTAMP);
					if (!$old_data['gender']) {
						$data['gender'] = $form['gender'];
					}
					foreach ($choseconfig as $index => $item) {
						foreach ($form[$index] as $_index => $_item) {
							if ($_item == 1) {
								$data[$index][] = trim($item['data'][$_index]);
							}
						}
						$data[$index] = implode(',', $data[$index]);
					}
					C::t('#xigua_jy#xigua_jy_user')->update($_G['uid'], $data);
					hb_message(lang_jy('bccg', 0), 'success', $SCRITPTNAME . '?id=xigua_jy&ac=my');
					exit(0);
				} else {
					if (!$old_data) {
						dheader('Location: ' . $SCRITPTNAME . '?id=xigua_jy&ac=join&step=1');
					}
					$qianbao = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
					$old_data['avatar'] = $old_data['avatar'] ? $old_data['avatar'] : avatar($_G['uid'], 'middle', true);
					$changemobile = $SCRITPTNAME . '?id=xigua_hb&ac=myzl&referer=' . urlencode(hb_currenturl()) . $GLOBALS['urlext'];
					$old_data['birthday_str'] = date(lang_jy('datefomat_php', 0), strtotime($old_data['birthday']));
					$_key = 'hbpubIdist' . intval($_GET['st']);
					loadcache($_key);
					if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
						C::t('#xigua_hb#xigua_hb_district')->init(C::t('#xigua_hb#xigua_hb_district')->list_all());
						$distjsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
						$distjsary = array_values($distjsary);
						savecache($_key, array('variable' => array($distjsary), 'expiration' => TIMESTAMP));
					} else {
						$distjsary = $_G['cache'][$_key]['variable'][0];
					}
					$cityjson = json_encode($distjsary);
					$custom_side = array($SCRITPTNAME . '?id=xigua_jy&ac=my' . $urlext, lang_jy('wdxq', 0));
					include template('xigua_jy:my_base');
					exit(0);
				}
				break;
			case 'lahei':
				if (submitcheck('formhash')) {
					$laheiuid = intval($_GET['laheiuid']);
					if ($laheiuid == $_G['uid']) {
						hb_message(lang_jy('bnlh', 0), 'error');
					}
					if ($_GET['inhei']) {
						DB::query('delete from %t where uid=%d and blackuid=%d', array('xigua_jy_black', $_G['uid'], $laheiuid));
					} else {
						C::t('#xigua_jy#xigua_jy_black')->insert(array('uid' => $_G['uid'], 'blackuid' => $laheiuid, 'crts' => TIMESTAMP, 'upts' => TIMESTAMP), 1, 1);
					}
					hb_message(lang_jy('czcg', 0), 'success', 'reload');
				}
				exit(0);
				break;
			default:
				$qianbao = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
				$navtitle = lang_jy('wdxq', 0);
				$user = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
				$avatar = $user['avatar'] ? $user['avatar'] : avatar($_G['uid'], 'middle', true);
				if (!$user) {
					dheader('Location: ' . $SCRITPTNAME . '?id=xigua_jy&ac=join&step=1');
				}
				$mybase_status = check_base($user);
				$albumnunm = count($user['album_ary']) + ($user['video'] ? 1 : 0);
				$biaozhun = check_biaozhun($user);
				$showmobiletip = !$qianbao['mobile'] && $jy_config['mustmobile'];
				if ($showmobiletip) {
					$bindurl = $SCRITPTNAME . '?id=xigua_hb&ac=myzl&referer=' . urlencode(hb_currenturl()) . $GLOBALS['urlext'];
				}
				if ($_G['cache']['plugin']['xigua_hr']) {
					$veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($_G['uid']);
					$rz = $veris1[$_G['uid']] ? lang_jy('chakan', 0) : lang_jy('djrz', 0);
				}
				if ($user['shows'] == 1) {
					$nowstatus = $xq_status[$user['status']]['title'];
					$status_cell = 'status_cell';
					$status_link = 'href="javascript:;"';
				} elseif ($user['shows'] == 0 - 1) {
					$nowstatus = lang_jy('zlshz', 0);
					$status_cell = '';
					$status_link = 'href="javascript:;"';
				} elseif ($user['shows'] == 0 - 3) {
					$nowstatus = lang_jy('shows_ary_3_tip', 0);
					$status_cell = '';
					$reason = str_replace(array('\'', '"'), '', lang_jy('reson', 0) . ':' . $user['reson']);
					$status_link = 'onclick="$.alert(\'' . $reason . '\');"';
				} elseif ($user['shows'] == 0 - 2) {
					$nowstatus = lang_jy('zfshf', 0);
					$status_cell = 'pay_shows2';
					$status_link = 'href="javascript:;"';
				}
				$my_line = C::t('#xigua_jy#xigua_jy_taocan')->get_my_num($_G['uid'], 'line');
				$my_line_num = $my_line['leave'];
				$leave_days = $user['dig_endts'] > TIMESTAMP ? round(($user['dig_endts'] - TIMESTAMP) / 86400, 0) : 0;
				$vip = 0;
				$favnum = DB::result_first('select count(*) from %t where favtype=\'jy\' AND (uid=%d OR favid=%d)', array('xigua_hb_follow', $_G['uid'], $_G['uid']));
				$seeme_num = DB::result_first('select count(*) from %t where uid=%d', array('xigua_jy_viewlog', $_G['uid']));
				$mesee_num = DB::result_first('select count(*) from %t where visiter=%d', array('xigua_jy_viewlog', $_G['uid']));
				$Guid = $_G['uid'];
				$qxnum = C::t('#xigua_jy#xigua_jy_qianxian')->fetch_count_by_page(array('uid=' . $Guid . ' OR touid=' . $Guid));
		}
		break;
	case 'qianxian':
		switch ($_GET['do']) {
			case 'first':
				global $adminids;
				global $SCRITPTNAME;
				global $_G;
				if (submitcheck('formhash')) {
					$touid = intval($_GET['touid']);
					if ($touid == $_G['uid']) {
						hb_message(lang_jy('bnhzj', 0), 'error');
					}
					$my_line = C::t('#xigua_jy#xigua_jy_taocan')->get_my_num($_G['uid'], 'line');
					$my_line_num = $my_line['leave'];
					$taocan_id = $my_line['row']['id'];
					if ($my_line_num <= 0) {
						hb_message(lang_jy('qxcsyw', 0), 'error', 'reload');
					}
					if (C::t('#xigua_jy#xigua_jy_qianxian')->fetch_by_uid_status($_G['uid'], $touid)) {
						hb_message(lang_jy('wfcf', 0), 'error', 'reload');
					}
					$from_uid = $_G['uid'];
					$bothuser = DB::fetch_all('select uid,nickname,hnids from %t where uid in(%n)', array('xigua_jy_user', array($from_uid, $touid)), 'uid');
					$st1 = 0 - 2;
					$tip = lang_jy('qxtip1', 0);
					if ($jy_config['qxmode'] == 1) {
						foreach ($bothuser as $index => $item) {
							$adminids[$index] = $index;
						}
					} elseif ($jy_config['qxmode'] == 2) {
						$st1 = 0 - 1;
						$tip = lang_jy('qxtip2', 0);
						notification_add($touid, 'system', lang_jy('shenqing1', 0), array('name' => $bothuser[$from_uid]['nickname'], 'url' => $SCRITPTNAME . '?id=xigua_jy&ac=my&do=qianxian'), 1);
					} elseif ($jy_config['qxmode'] == 3) {
						$st1 = 1;
						$tip = lang_jy('qxtip3', 0);
					}
					$newdata = array('uid' => $_G['uid'], 'touid' => $touid, 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'status' => $st1, 'taocan_id' => $taocan_id);
					C::t('#xigua_jy#xigua_jy_taocan')->incr($taocan_id, 'used', 1);
					C::t('#xigua_jy#xigua_jy_qianxian')->insert($newdata, 1, 1);
					if ($adminids) {
						foreach ($adminids as $adminid) {
							notification_add($adminid, 'system', lang_jy('shenqing2', 0), array('from' => $bothuser[$from_uid]['nickname'], 'to' => $bothuser[$touid]['nickname'], 'url' => $SCRITPTNAME . '?id=xigua_jy'), 1);
						}
					}
					hb_message($tip, 'success', $SCRITPTNAME . '?id=xigua_jy&ac=my&do=qianxian' . $urlext);
				}
				exit(0);
				break;
			case 'confirm':
				if (submitcheck('formhash')) {
					$fromuid = intval($_GET['fromuid']);
					$qxid = intval($_GET['qxid']);
					$qxrow = C::t('#xigua_jy#xigua_jy_qianxian')->fetch($qxid);
					if ($_GET['agree']) {
						$sta = '1';
						$mesg = $qianxian_status[$sta];
						$touserr = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
						notification_add($fromuid, 'system', lang_jy('qianxian_status1_tip', 0), array('name' => $touserr['nickname'], 'url' => $SCRITPTNAME . '?id=xigua_jy&ac=my&do=qianxian'), 1);
					} else {
						$sta = '2';
						if ($jy_config['huifu']) {
							C::t('#xigua_jy#xigua_jy_taocan')->incr($qxrow['taocan_id'], 'used', 0 - 1);
							notification_add($fromuid, 'system', lang_jy('qianxian_status2_tip1', 0), array('url' => $SCRITPTNAME . '?id=xigua_jy&ac=my&do=qianxian'), 1);
						} else {
							notification_add($fromuid, 'system', lang_jy('qianxian_status2_tip2', 0), array('url' => $SCRITPTNAME . '?id=xigua_jy&ac=my&do=qianxian'), 1);
						}
						$mesg = lang_jy('czcg', 0);
					}
					$qxdata = array('status' => $sta, 'upts' => TIMESTAMP);
					if ($sta == 1) {
						$qxdata['allowalbum'] = 1;
						$qxdata['allowvideo'] = 1;
					}
					DB::update('xigua_jy_qianxian', $qxdata, array('id' => $qxid, 'touid' => $_G['uid'], 'uid' => $fromuid));
					hb_message($mesg, 'success', 'reload');
				}
				exit(0);
		}
		break;
	case 'view':
		$uid = intval($_GET['jyid']);
		$GLOBALS['need_lastts'] = 1;
		$GLOBALS['need_verify'] = 1;
		global $vipicons;
		if (!$vipicons) {
			$vipicons = DB::fetch_all('select subject,link from %t where link<>\'\'', array('xigua_jy_vipguide'), 'subject');
		}
		if ($uid) {
			$v = C::t('#xigua_jy#xigua_jy_user')->fetch($uid);
		}
		if (!$v) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_jy&notexists=1');
		}
		if ($v['uid'] != $_G['uid'] && !IS_ADMINID) {
			if ($v['shows'] != 1) {
				dheader('Location: ' . $SCRITPTNAME . '?id=xigua_jy');
			}
		}
		$check_qx = C::t('#xigua_jy#xigua_jy_qianxian')->check_if_success($_G['uid'], $v['uid']);
		$check_black = C::t('#xigua_jy#xigua_jy_black')->check_black($v['uid'], $_G['uid']);
		$iminblack = $check_black[$v['uid']];
		$blackinme = $check_black[$_G['uid']];
		if ($v['status'] == 0 - 2 || $v['status'] == 0 - 1) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_jy');
		} else {
			if ($v['status'] == 2 || $iminblack) {
				$v['album'] = $v['album_ary'] = '';
				$v['video'] = $v['video_cover'] = '';
				$v['wx'] = $v['mobile'] = '';
			}
		}
		$mine = C::t('#xigua_jy#xigua_jy_user')->fetch($_G['uid']);
		$icc = count($v['album_ary']);
		$navtitle = $v['nickname'];
		if (!$_G['cache']['xigua_wr_setting']) {
			loadcache('xigua_wr_setting');
		}
		$xigua_wr_setting = $_G['cache']['xigua_wr_setting'];
		$navtitle = str_replace('{name}', $v['nickname'], $xigua_wr_setting['viewtitlevar']);
		$desc = $v['note'];
		$titlel = $v['nickname'];
		if (!$mine['is_vip'] && !$check_qx['allowalbum']) {
			if ($icc == 1) {
				$v['album_ary'] = array();
			} else {
				if ($icc > 1) {
					foreach ($v['album_ary'] as $index => $item) {
						if ($index > 0) {
							$v['album_ary'][$index] = 'source/plugin/xigua_jy/static/suojie.png';
						}
					}
				}
			}
		}
		$hasze = 0;
		foreach ($zotj as $index => $item) {
			if ($v[$item]) {
				$hasze = 1;
				break;
			}
		}
		$need_side = 1;
		if ($_G['uid']) {
			$gz = C::t('#xigua_hb#xigua_hb_follow')->fetch_follow_by_favid_uid($v['uid'], $_G['uid'], 'jy');
			$my_line = C::t('#xigua_jy#xigua_jy_taocan')->get_my_num($_G['uid'], 'line');
			$my_line_num = $my_line['leave'];
			$qianxian = C::t('#xigua_jy#xigua_jy_qianxian')->fetch_by_uid_status($_G['uid'], $v['uid']);
		}
		$nextid = C::t('#xigua_jy#xigua_jy_user')->get_next($v);
		$showtipbase = !check_base_simple($mine);
		C::t('#xigua_jy#xigua_jy_viewlog')->do_insert($v['uid']);
		C::t('#xigua_jy#xigua_jy_user')->incr($v['uid'], 'views');
		if (!$v['avatar']) {
			$v['avatar'] = avatar($v['uid'], 'middle', true);
		}
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
$ac_file = DISCUZ_ROOT . ('source/plugin/xigua_jy/include/c_' . $ac . '.php');
if (is_file($ac_file)) {
	include_once $ac_file;
}
include template('xigua_jy:' . $ac);