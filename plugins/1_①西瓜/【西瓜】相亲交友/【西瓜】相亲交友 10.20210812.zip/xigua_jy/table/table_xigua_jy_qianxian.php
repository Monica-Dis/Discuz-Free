<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_jy_qianxian extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_jy_qianxian';
        $this->_pk = 'id';

        parent::__construct(); /*dism_ taobao_ com*/
    }

    public function fetch_all_by_page($wherearr, $start_limit, $lpp, $key_field = '')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($key_field){
            $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp), array(), $key_field);
        }else{
            $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp));
        }
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table) ." $wheresql ");
        return $result;
    }

    public function fetch_by_uid_status($uid, $touid){
        return DB::fetch_first('select * from %t where ((uid=%d and touid=%d) OR (touid=%d and uid=%d)) and status!=2', array($this->_table, $uid, $touid, $uid, $touid));
    }

    public function check_if_success($uid, $touid){
        if(!$touid || $touid == $uid || !$uid){
            return false;
        }
        $r = DB::fetch_first('SELECT * FROM %t WHERE ((uid=%d and touid=%d) OR (touid=%d and uid=%d)) AND status=1', array($this->_table, $uid, $touid, $uid, $touid));
        if(!$r){
            return false;
        }
        return $r;
    }

    public function deletes($ids)
    {
        $ret = DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
        return true;
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = dgmdate($v['crts'], 'u');
            $v['upts_u'] = dgmdate($v['upts'], 'u');
            /*    '-2' => '����ǣ����',
                '-1' => '�ȴ��Է�ͬ��',
                '1' => 'ǣ�߳ɹ�',
                '2' => 'ǣ��ʧ��',*/
            if(in_array($v['status'], array(1))){
                $v['crts_word'] = lang_jy('qxts',0);
                $v['status_color'] = 'color-forest';
            }else{
                $v['crts_word'] = lang_jy('sqts',0);
                if($v['status']==2){
                    $v['status_color'] = 'color-gray';
                }else{
                    $v['status_color'] = 'main_color';
                }
            }
        }
        return $v;
    }
}