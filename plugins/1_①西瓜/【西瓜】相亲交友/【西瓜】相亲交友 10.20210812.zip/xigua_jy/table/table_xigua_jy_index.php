<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_jy_index extends  discuz_table
{
    public $arr = array();

    public $nbsp = "&nbsp;";

    public $ret = '';

    public $child = array();

    public $tree_id = 'id';
    public $tree_pid = 'pid';

    public function __construct()
    {
        $this->_table = 'xigua_jy_index';
        $this->_pk = 'id';

        parent::__construct(); /*dism_ taobao_ com*/
    }

    public function fetch_by_hbcat($cat_id){
        $result = DB::fetch_all(
            "SELECT id,`name` FROM %t WHERE FIND_IN_SET($cat_id, cat_ids)  ORDER BY o ASC,id ASC ",
            array( $this->_table, ),
            $this->_pk
        );
        return $result;
    }

    public function fetch_by_name($names){
        foreach ($names as $index => $name) {
            $names[] = trim($name);
        }
        $result = DB::fetch_all(
            "SELECT id,`name` FROM %t WHERE `name` IN (%n) ORDER BY id ASC",
            array( $this->_table, $names),
            $this->_pk
        );
        return $result;
    }

    public function count_by_page(){
        $result = DB::result_first(
            'SELECT count(*) FROM %t  WHERE pid=0 ',
            array($this->_table)
        );
        return $result;
    }
    public function fetch_all_by_page($start_limit , $lpp){
        $result = DB::fetch_all(
            "SELECT * FROM %t  WHERE pid=0  ORDER BY o ASC,id ASC " . DB::limit($start_limit, $lpp),
            array(
                $this->_table,
            ),
            $this->_pk
        );

        $sub_result = DB::fetch_all(
            "SELECT * FROM %t  WHERE pid in(%n)  ORDER BY o ASC,id ASC ",
            array(
                $this->_table,
                array_keys($result),
            ),
            $this->_pk
        );

        return array_merge($result, $sub_result);
    }

    public function list_all($simple = 0, $key = false)
    {
        if($simple){
            $field = 'id,pid,name,stids';
        }else{
            $field = '*';
        }
        if($key){
            $result = DB::fetch_all("SELECT $field FROM %t ORDER BY o ASC,id ASC", array($this->_table), $this->_pk);
        }else{
            $result = DB::fetch_all("SELECT $field FROM %t ORDER BY o ASC,id ASC", array($this->_table));
        }
        if($_GET['st']){
            foreach ($result as $index => $item) {
                if($item['stids']){
                    if(!in_array($_GET['st'], explode(',', $item['stids']))){
                        unset($result[$index]);
                    }
                }
            }
            if(!$key) {
                $result = array_values($result);
            }
        }
        return $result;
    }

    public function list_json()
    {
        $result = DB::fetch_all("SELECT id,pid,`name`,id as code, stids FROM %t ORDER BY o ASC,id ASC", array($this->_table));
        foreach ($result as $index => $item) {
            $result[$index]['name'] = diconv($item['name'], CHARSET, 'utf-8');
        }
        if($_GET['st']){
            foreach ($result as $index => $item) {
                if($item['stids']){
                    if(!in_array($_GET['st'], explode(',', $item['stids']))){
                        unset($result[$index]);
                    }
                }
            }
            $result = array_values($result);
        }
        return $result;
    }

    public function list_by_pushtype()
    {
        return DB::fetch_all("SELECT id,name,icon,pushtype FROM %t WHERE pushtype!='' ORDER BY o ASC,id ASC LIMIT 10", array($this->_table));
    }

    public function list_by_pid($pid = 0)
    {
        $where = '';
        $ret = DB::fetch_all("SELECT * FROM %t WHERE pid=%d OR id=%d $where ORDER BY o ASC,id ASC", array(
            $this->_table,
            $pid,
            $pid,
        ));
        $_G = $GLOBALS['_G'];

        $return = array();
        foreach ($ret as $index => $item) {
            if(!$item['icon']){
                $item['icon'] = 'source/plugin/xigua_hb/static/img/icon.png';
            }
            $return[$item['id']] = $item;

            if($_GET['st']){
                if($item['stids']){
                    if(!in_array($_GET['st'], explode(',', $item['stids']))){
                        unset($return[$item['id']]);
                    }
                }
            }
        }
        return $return;
    }

    public function list_by_pid_light($pid = 0)
    {
        return DB::fetch_all("SELECT id,pid,`name` FROM %t WHERE pid=%d  ORDER BY o ASC,id ASC", array(
            $this->_table,
            $pid,
        ));
    }

    public function fetch_by_catid($catid = 0)
    {
        $item = parent::fetch($catid);
        return $item;
    }

    public function fetch_light($catids = array(), $field = '*', $order = '')
    {
        if(!$order){
            $order = ' id DESC ';
        }
        return DB::fetch_all("SELECT $field FROM %t WHERE id IN(%n) ORDER BY $order", array($this->_table, $catids), $this->_pk);
    }

    public function get_childs_by_pids($pids){
        $childs = DB::fetch_all("SELECT id,pid,`name`,icon FROM %t WHERE pid IN (%n) OR id=%d ORDER BY o ASC,id ASC", array(
            $this->_table,
            $pids,
            $pids,
        ));
        return $childs;
    }

    public function get_pid_by_childs($childids){
        $childs = DB::fetch_first("SELECT id,pid FROM %t WHERE id IN (%n)", array(
            $this->_table,
            $childids
        ));
        return $childs;
    }

    public function do_delete($id)
    {
        $has = DB::fetch_first('SELECT pid FROM %t WHERE pid=%d', array(
            $this->_table,
            $id
        ));
        if($has){
            return false;
        }
        return $this->delete($id);
    }

    public function do_pushtype($id, $pushtype)
    {
        $r = DB::query("UPDATE %t SET pushtype=%s WHERE id=%d", array(
            $this->_table,
            $pushtype,
            $id
        ));
        if(!$r){
            $r = DB::query("UPDATE %t SET pushtype=%s WHERE id=%d", array(
                $this->_table,
                '',
                $id
            ));
        }
        return $r;
    }

    public function init($arr = array()) {
        $this->arr = $arr;
        $this->ret = '';
        return is_array($arr);
    }

    public function get_parent($myid) {
        $newarr = array();
        if (!isset($this->arr[$myid]))
            return false;
        $pid = $this->arr[$myid][$this->tree_pid];
        $pid = $this->arr[$pid][$this->tree_pid];
        if (is_array($this->arr)) {
            foreach ($this->arr as $id => $a) {
                if ($a[$this->tree_pid] == $pid)
                    $newarr[$id] = $a;
            }
        }
        return $newarr;
    }

    public function get_child($myid) {
        $a = $newarr = array();
        if (is_array($this->arr)) {
            foreach ($this->arr as $id => $a) {
                if ($a[$this->tree_pid] == $myid)
                    $newarr[$id] = $a;
            }
        }
        return $newarr ? $newarr : false;
    }

    public function get_all_child($myid) {
        $number = 1;
        $child = $this->get_child($myid);
        if (is_array($child)) {
            $total = count($child);
            foreach ($child as $id => $value) {
                $this->child[]= $value;
                $this->get_all_child($value[$this->tree_id]);
                $number++;
            }
        }
        return $this->child;
    }

    public function get_pos($myid, &$newarr) {
        $a = array();
        if (!isset($this->arr[$myid]))
            return false;
        $newarr[] = $this->arr[$myid];
        $pid = $this->arr[$myid][$this->tree_pid];
        if (isset($this->arr[$pid])) {
            $this->get_pos($pid, $newarr);
        }
        if (is_array($newarr)) {
            krsort($newarr);
            foreach ($newarr as $v) {
                $a[$v[$this->tree_id]] = $v;
            }
        }
        return $a;
    }

    public function get_tree_array($myid) {
        $retarray = array();
        $child = $this->get_child($myid);
        if (is_array($child)) {
            if($GLOBALS['needchild']){
                $total = count($child);
                foreach ($child as $id => $value) {
                    @extract($value);
                    $retarray[$id] = $value;
                    $retarray[$id]["child"] = $this->get_tree_array($id, '');
                }
            }else{
                foreach ($child as $id => $value) {
                    @extract($value);
                    $retarray[$id] = $value;
                    $subary = array_values($this->get_tree_array($id, ''));
                    if($subary){
                        $retarray[$id]["sub"] = $subary;
                    }
                }
            }
        }
        return $retarray;
    }

    private function have($list, $item) {
        return(strpos(',,' . $list . ',', ',' . $item . ','));
    }

    public function empty_child()
    {
        $this->child = array();
        return true;
    }

    public function list_by_where($wherearr = array()){
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY o ASC,id ASC ");
        $return = array();
        foreach ($result as $index => $item) {
            if(!$item['icon']){
                $item['icon'] = 'source/plugin/xigua_hb/static/img/icon.png';
            }
            $return[$item['id']] = $item;

            if($item['stids']){
                if(!in_array(intval($_GET['st']), explode(',', $item['stids']))){
                    unset($return[$item['id']]);
                }
            }
        }
        return $return;
    }
}