<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_jy_black extends discuz_table
{
    public function __construct() {

        $this->_table = 'xigua_jy_black';
        $this->_pk    = 'id';

        parent::__construct(); /*dism_ taobao_ com*/
    }

    public function fetch_all_by_page($wherearr, $start_limit, $lpp, $keyfield = '')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($keyfield){
            $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp), array(), $keyfield);
        }else{
            $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp));
        }
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public static function prepare($v)
    {
        return $v;
    }

    /*����ҵ�uid�ǲ��Ǳ�������*/
    public function check_black($hisuid, $myuid)
    {
        return DB::fetch_all('select * from %t where (uid=%d and blackuid=%d) OR (uid=%d and blackuid=%d) ', array($this->_table, $hisuid, $myuid, $myuid, $hisuid ), 'uid');
    }
}