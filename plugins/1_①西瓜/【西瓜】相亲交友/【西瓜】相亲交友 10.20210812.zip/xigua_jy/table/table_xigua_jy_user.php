<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_jy_user extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_jy_user';
        $this->_pk = 'uid';

        parent::__construct(); /*dism_ taobao_ com*/
    }

    public function fetch($id, $force_from_db = false){
        global $_G;
        $result = parent::fetch($id, $force_from_db);
        $result = self::prepare($result);
        if($GLOBALS['need_verify'] && $_G['cache']['plugin']['xigua_hr'] && $id){
            $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($id);
            $result['verify'] = $veris1[$id] ? 1 : '';
        }
        if($GLOBALS['need_lastts'] && $id){
            $lastvisit= DB::result_first('select lastvisit from %t where uid=%d', array('common_member_status', $id), 'uid');
            $result['lastvisit'] = str_replace('&nbsp;', '', dgmdate($lastvisit, 'u'));
        }
        return $result;
    }

    public function nickname_exists($name)
    {
        global $_G;
        if(!$name){
            return 1;
        }
        $result = DB::result_first("SELECT uid FROM %t WHERE nickname=%s and uid!=%d", array(
            $this->_table,
            $name,
            $_G['uid']
        ));
        return $result;
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false) {
        global $jy_config;
        if($jy_config['mfshen']){
            $data['status'] = -1;
        }
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $keyfield = ''){
        global $jy_config, $_G;
        if($_GET['st']>0 && $jy_config['allowst']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        /*if($_GET['ac']=='mem_li'){
            $wherearr[] = 'avatar<>\'\'';
        }*/
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $orary = $this->get_order($_GET['orderby']);
        $fields = $orary['field'];
        if($orary['order_by']){
            $orderby = "ORDER BY {$orary['order_by']}";
        }
        if($keyfield){
            $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp), array(), $keyfield);
        }else{
            $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        }
        $uids = array();
        global $vipicons;
        if(!$vipicons){
            $vipicons = DB::fetch_all('select subject,link from %t where link<>\'\'', array('xigua_jy_vipguide'), 'subject');
        }
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $uids[] = $item['uid'];
        }
        if($GLOBALS['need_lastts'] && $uids){
            $vis = DB::fetch_all('select uid, lastvisit from %t where uid in (%n)', array('common_member_status', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['lastvisit'] = str_replace('&nbsp;', '', dgmdate($vis[$item['uid']]['lastvisit'], 'u'));
            }
        }
        if($_G['cache']['plugin']['xigua_hr'] && $uids){
            $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids);
            foreach ($result as $index => $item) {
                $result[$index]['verify'] = $veris1[$item['uid']] ? 1 : '';
            }
        }
        return $result;
    }
    public function fetch_count_by_page($wherearr = array())
    {
        global $jy_config;
        if($_GET['st'] && $jy_config['allowst']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }
    public function delete_by_where($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::query('DELETE FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        global $vipicons;
        if($v){
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i', $v['upts']) : '';
            $v['album_ary'] = $v['album'] ? explode(',', $v['album']) : array();
            $v['age'] = get_age($v['birthday']);
            $v['gongzuodi_ary'] = $v['gongzuodi'] ? explode(' ', trim($v['gongzuodi']) ) : array();
            $v['is_vip'] = $v['vip_endts']>TIMESTAMP;
            $v['vip_endts_day'] =  $v['is_vip'] ? date('Y-m-d', $v['vip_endts']) : '';
            $v['is_dig'] = $v['dig_endts']>TIMESTAMP;
            if($v['is_vip']){
                $v['vip_icon'] = $vipicons[$v['vip_name']]['link'] ? $vipicons[$v['vip_name']]['link'] : 'source/plugin/xigua_jy/static/img/vip.png';
            }else{
                $v['vip_name'] = $v['vip_endts']= $v['vip_info'] = '';
            }
            $v['istd'] = $v['status']==-1;
            if(!$v['note']){
                $v['note'] = lang('plugin/xigua_jy', 'tll');
            }
        }
        return $v;
    }

    public function fetch_by_uid($uid)
    {
        global $jy_config;
        if($jy_config['allowst']) {
            $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND stid=%d", array($this->_table, $uid, $_GET['st']));
        }else{
            $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
        }
        $v = self::prepare($v);
        return $v;
    }

    public function do_delete($id)
    {
        return $this->delete($id);
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = array();
        $result = DB::fetch_all("SELECT * FROM %t  ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp), array($this->_table));
        if($result){
            foreach ($result as $index => $item) {
                $result[$index] = self::prepare($item);
            }
        }
        return $result;
    }

    public function count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }


    public function incr($gid, $field, $num = 1)
    {
        if(!$field){
            return null;
        }
        global $config;
        if($field == 'views' && $config['cusview']>0 && $config['cusview']<1000){
            $num = $num * mt_rand(1, $config['cusview']);
        }
        if(strpos($gid, ',')!==false){
            $gid = dintval(array_filter(explode(',', $gid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $gid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $gid));
        }
    }

    public function del_by_uid()
    {
        global $_G;
        return DB::delete($this->_table, array(
            'uid' => $_G['uid'],
        ));
    }

    public function get_next($v){
        $rskey = $this->_pk;
        $where = array();
        $where[] = 'uid!='.intval($v['uid']);
        $where[] = 'status!=-2 AND shows=1';
        if($v['gender']==1){
            $where[] = 'gender=1';
        }else{
            $where[] = 'gender=2';
        }
        $next_row = $this->fetch_all_by_where($where, 0, 1);
        return $next_row[0]['uid'];
    }
    public function get_order($viewtype)
    {
        global $jy_config;
        $field = '*';
        $ext_order = $mid_order =  $pre_order = '';
        switch ($viewtype){
            case "upts":
                $ext_order = 'upts DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                $pre_order = 'distance ASC';
                break;
            case 'new':
                $ext_order = 'crts DESC';
                break;
            default:
                break;
        }
        switch ($jy_config['digorder']){
            case '3':
                $mid_order = " dig_startts DESC, dig_endts DESC";
                break;
            case '2':
                $mid_order = " dig_endts DESC";
                break;
            case '4':
                $mid_order = " (dig_endts-now()) DESC";
                break;
            default:
                $mid_order = " (dig_endts-dig_startts) DESC";
                break;
        }
        if(defined('IN_ADMINCP') && $viewtype == 'new'){
            $mid_order = '';
        }
        $order_by = implode(',', array_filter(array($pre_order, $mid_order, $ext_order)));
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }
}