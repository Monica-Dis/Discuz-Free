<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_jy_hn extends discuz_table
{
    public function __construct() {

        $this->_table = 'xigua_jy_hn';
        $this->_pk    = 'id';

        parent::__construct(); /*dism_ taobao_ com*/
    }

    public function fetch_all_by_page($wherearr, $start_limit, $lpp, $field = '*', $ob = '', $keyfield = '')
    {
        if($ob){
            $oby = " ORDER BY $ob ";
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($keyfield){
            $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql $oby" . DB::limit($start_limit, $lpp), array(), $keyfield);
        }else{
            $result = DB::fetch_all("SELECT $field FROM " . DB::table($this->_table) . " $wheresql $oby" . DB::limit($start_limit, $lpp));
        }
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }
    public function fetch_count_by_page($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = dgmdate($v['crts'], 'u');
            $v['upts_u'] = dgmdate($v['upts'], 'u');
        }
        return $v;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }
}