<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_jy_viewlog extends discuz_table
{
    public function __construct() {

        $this->_table = 'xigua_jy_viewlog';
        $this->_pk    = 'id';

        parent::__construct(); /*dism_ taobao_ com*/
    }

    public function do_insert($uid)
    {
        global $_G;
        if($_G['uid']<=0){
            return false;
        }
        if($uid == $_G['uid']){
            return false;
        }

        $data = array(
            'uid' => $uid,
            'visiter' => $_G['uid'],
            'visiter_name' => $_G['username'],
            'crts' => TIMESTAMP,
        );

        $has = DB::result_first('SELECT * FROM %t WHERE uid=%d AND visiter=%d LIMIT 1', array(
            $this->_table,
            $uid,
            $_G['uid']
        ));
        if($has){
            DB::update($this->_table, array('crts' => TIMESTAMP), array('visiter'=>$_G['uid'],'uid'=>$uid));
            return false;
        }
        return parent::insert($data);
    }

    public function fetch_all_by_page($wherearr, $start_limit, $lpp, $keyfield = '')
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($keyfield){
            $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp), array(), $keyfield);
        }else{
            $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp));
        }
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public static function prepare($v)
    {
        if($v){
            $v['crts_u'] = dgmdate($v['crts'], 'u');
        }
        return $v;
    }

}