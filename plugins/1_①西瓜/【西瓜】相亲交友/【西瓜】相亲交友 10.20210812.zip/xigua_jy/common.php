<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2020/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function lang_jy($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_jy', $lang);
    }else{
        return lang('plugin/xigua_jy', $lang);
    }
}

function check_biaozhun($user){
    global $_G;
    if($user['y_nianling'] && $user['y_shengao']&& $user['y_xueli']&& $user['y_zhiye']&& $user['y_shouru']&& $user['y_hunyin']&& $user['y_goufang']&& $user['y_xiyan']&& $user['y_hejiu']){
        return lang_jy('ysz',0);
    }else{
        return lang_jy('wsz',0);
    }
}

function check_base($user, $return = 0){
    global $_G;
    if($user['avatar']&&$user['note']&&$user['nickname']&&$user['wx']&&$user['mobile']&&$user['birthday']/*&&$user['shengao']&&$user['tizhong']&&$user['jiaxiang']&&$user['gongzuodi']&&$user['xueli']&&$user['hunyin']&&$user['zhiye']&&$user['shouru']&&$user['goufang']&&$user['gouche']&&$user['xiyan']&&$user['hejiu']*/){
        if(!$user['base_status']){
            DB::update('xigua_jy_user', array('base_status' => 1), array('uid' => $user['uid']));
        }
        return $return ? 1 : get_age($user['birthday']) . ' '.$user['xueli'].' '.$user['zhiye'];
    }else{
        return $return ? 0 : lang_jy('xws',0);
    }
}

function check_base_simple($user){
    global $_G;
    if($user['avatar']&&$user['nickname']&&$user['wx']&&$user['mobile']&&$user['birthday']){
        return 1;
    }else{
        return 0;
    }
}

function get_age($birthday){
    $age = strtotime($birthday);
    if($age === false){
        return '22'.lang_jy('sui',0);
    }
    list($y1,$m1,$d1) = explode("-",date("Y-m-d",$age));
    $now = strtotime("now");
    list($y2,$m2,$d2) = explode("-",date("Y-m-d",$now));
    $age = $y2 - $y1;
    if((int)($m2.$d2) < (int)($m1.$d1)){
        $age -= 1;
    }
    return $age.lang_jy('sui',0);
}


function _jy_get_animal($date){
    $animals = array(
        lang('plugin/xigua_jy', 'sx1'),
        lang('plugin/xigua_jy', 'sx2'),
        lang('plugin/xigua_jy', 'sx3'),
        lang('plugin/xigua_jy', 'sx4'),
        lang('plugin/xigua_jy', 'sx5'),
        lang('plugin/xigua_jy', 'sx6'),
        lang('plugin/xigua_jy', 'sx7'),
        lang('plugin/xigua_jy', 'sx8'),
        lang('plugin/xigua_jy', 'sx9'),
        lang('plugin/xigua_jy', 'sx10'),
        lang('plugin/xigua_jy', 'sx11'),
        lang('plugin/xigua_jy', 'sx12'),
    );
    $year = date('Y', strtotime($date));
    $key = ($year - 1900) % 12;
    return $animals[$key];
}
function _jy_get_constellation($date){
    $time = strtotime($date);

    $y   = date("Y").'-';
    $his = ' 00:00:00';
    $birth_month = date("m", $time);
    $birth_date  = date("d", $time);
    $userTime = strtotime($y.$birth_month.'-'.$birth_date.$his);
    $januaryS   = strtotime($y.'01-20'.$his);
    $januaryE   = strtotime($y.'02-18'.$his);
    $februaryS  = strtotime($y.'02-19'.$his);
    $februaryE  = strtotime($y.'03-20'.$his);
    $marchS     = strtotime($y.'03-21'.$his);
    $marchE     = strtotime($y.'04-19'.$his);
    $aprilS     = strtotime($y.'04-20'.$his);
    $aprilE     = strtotime($y.'05-20'.$his);
    $mayS       = strtotime($y.'05-21'.$his);
    $mayE       = strtotime($y.'06-21'.$his);
    $juneS      = strtotime($y.'06-22'.$his);
    $juneE      = strtotime($y.'07-22'.$his);
    $julyS      = strtotime($y.'07-23'.$his);
    $julyE      = strtotime($y.'08-22'.$his);
    $augustS    = strtotime($y.'08-23'.$his);
    $augustE    = strtotime($y.'09-22'.$his);
    $septemberS = strtotime($y.'09-23'.$his);
    $septemberE = strtotime($y.'10-23'.$his);
    $octoberS   = strtotime($y.'10-24'.$his);
    $octoberE   = strtotime($y.'11-22'.$his);
    $novemberS  = strtotime($y.'11-23'.$his);
    $novemberE  = strtotime($y.'12-21'.$his);

    if($userTime >= $januaryS && $userTime <= $januaryE){
        $constellation = lang_jy('xz1',0);
    }elseif($userTime >= $februaryS && $userTime <= $februaryE){
        $constellation = lang_jy('xz2',0);
    }elseif($userTime >= $marchS && $userTime <= $marchE){
        $constellation = lang_jy('xz3',0);
    }elseif($userTime >= $aprilS && $userTime <= $aprilE){
        $constellation = lang_jy('xz4',0);
    }elseif($userTime >= $mayS && $userTime <= $mayE){
        $constellation = lang_jy('xz5',0);
    }elseif($userTime >= $juneS && $userTime <= $juneE){
        $constellation = lang_jy('xz6',0);
    }elseif($userTime >= $julyS && $userTime <= $julyE){
        $constellation = lang_jy('xz7',0);
    }elseif($userTime >= $augustS && $userTime <= $augustE){
        $constellation = lang_jy('xz8',0);
    }elseif($userTime >= $septemberS && $userTime <= $septemberE){
        $constellation = lang_jy('xz9',0);
    }elseif($userTime >= $octoberS && $userTime <= $octoberE){
        $constellation = lang_jy('xz10',0);
    }elseif($userTime >= $novemberS && $userTime <= $novemberE){
        $constellation = lang_jy('xz11',0);
    }else{
        $constellation = lang_jy('xz12',0);
    }
    return $constellation;
}
function parse_age_date($age_range){
    $tmp = array();
    foreach ($age_range as $index => $item) {
        $item = str_replace(array(lang_jy('sui',0),lang_jy('ys',0),' '), array('','-99', '-'), $item);
        $item = explode('-', $item);
        $from = date('Y-m-d', strtotime('-'.$item[1].' years'));
        $to =   date('Y-m-d', strtotime('-'.$item[0].' years'));
        if($from && $to){
            $tmp[] = " (`birthday` BETWEEN '$from' AND '$to') ";
        }
    }
    if(!$tmp){
        return '';
    }
    return '('. implode('OR', $tmp).')';
}

function parse_shengao($age_range){
    $tmp = array();
    foreach ($age_range as $index => $item) {
        $item = str_replace(array('cm',lang_jy('ys',0)), array('','-299'), $item);
        $item = explode('-', $item);
        $from = $item[0];
        $to =   $item[1];
        if($from && $to){
            $tmp[] = " (`shengao` BETWEEN '$from' AND '$to') ";
        }
    }
    if(!$tmp){
        return '';
    }
    return '('. implode('OR', $tmp).')';
}

function parse_like($age_range, $field = '', $like = 0){
    $tmp = array();
    foreach ($age_range as $index => $item) {
        $item = stripsearchkey(addslashes($item));
        if($item){
            if($like){
                $tmp[] = " (`$field` LIKE '%$item%') ";
            }else{
                $tmp[] = " (`$field`='$item') ";
            }
        }
    }
    if(!$tmp){
        return '';
    }
    return '('. implode('OR', $tmp).')';
}


function muhu_uid($uid){
    $uid1 = str_pad($uid,7,'0');
    return substr_replace($uid1, '****', 3, 4);
}
function check_bind_jy(){
    global $_G,$config,$SCRITPTNAME,$jy_config;
    if(!$jy_config['mustmobile']){
        return false;
    }
    $user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
    if($user['mobile']){
        return $user['mobile'];
    }
    $url = $SCRITPTNAME.'?id=xigua_hb&ac=myzl&referer='.urlencode(hb_currenturl()).$GLOBALS['urlext'];
    if ($_GET['inajax']) {
        hb_message(lang_hb('plzbind', 0), 'success', $url);
    } else {
        dheader('location: ' . $url);
    }
    return false;
}