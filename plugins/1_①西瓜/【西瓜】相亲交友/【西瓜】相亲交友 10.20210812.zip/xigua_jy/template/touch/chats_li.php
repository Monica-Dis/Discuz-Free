<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{loop $comments $comment}-->
<!--{if strpos($comment[comment], '|/|')!==false}-->
<!--{eval $comment[comment] = explode('|/|', $comment[comment]); $comment[comment]=  $comment[comment][2];}-->
<!--{/if}-->
<!--{if $comment[authorid]!=$_G[uid] && $jyusers[$comment[authorid]]}-->
<a <!--{if $_GET['pagetype']=='page'}-->href="$SCRITPTNAME?id=xigua_jy&ac=chat&touid={echo $comment[authorid]!=$_G[uid]?$comment[authorid]:$comment[touid]}" class="weui-media-box weui-media-box_appmsg"<!--{else}-->href="javascript:void(0);" class="weui-media-box weui-media-box_appmsg cmt_p"<!--{/if}-->  <!--{if $_GET[type]=='sx'}-->data-type="1"<!--{/if}--> data-pubid="<!--{if $_GET[type]!='sx'}-->$comment[pubid]<!--{else}-->0<!--{/if}-->" data-cmtid="$comment[cid]" data-authorid="$comment[authorid]" data-author="{$jyusers[$comment[authorid]][nickname]}">
<div class="weui-media-box__hd">
    <img class="weui-media-box__thumb" onerror="this.error=null;this.src='source/plugin/xigua_jy/static/img/tx.png?'" style="height:100%" src="{$jyusers[$comment[authorid]][avatar]}">
</div>
<div class="weui-media-box__bd">
    <h4 class="weui-media-box__title c3">
        <span class="y f13 c9" style="margin-top:2px">$comment[crts] <!--{if $comment[new]}--><span class="weui-badge weui-badge_dot" style="margin-left:5px;"></span><!--{/if}--></span>
        <span class="c6 f16">{$jyusers[$comment[authorid]][nickname]}</span>
    </h4>
    <p class="weui-media-box__desc mt0 c9">{$comment[comment]}</p>
</div>
</a>
<!--{/if}-->
<!--{/loop}-->