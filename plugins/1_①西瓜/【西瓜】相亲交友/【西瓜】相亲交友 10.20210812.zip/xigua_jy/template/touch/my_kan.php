<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_jy:header}--><link rel="stylesheet" href="source/plugin/xigua_jy/static/line.css" />
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar">
        <div class="weui-navbar">
            <a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=kan&type=tome" class="weui-navbar__item <!--{if $_GET[type]=='tome'}-->weui_bar__item_on<!--{/if}-->">
                <span>{lang xigua_jy:skgw} ($favnum1)</span>
            </a>
            <a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=kan" class="weui-navbar__item <!--{if !$_GET[type]}-->weui_bar__item_on<!--{/if}-->">
                <span>{lang xigua_jy:wkgs} ($favnum2)</span>
            </a>
        </div>
    </div>

    <div id="list" class="weui-cells p0 mt0 border_none"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>var loadingurl = window.location.href+'&li=1&inajax=1&page=';</script>
<!--{eval $jy_tabbar=1;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->