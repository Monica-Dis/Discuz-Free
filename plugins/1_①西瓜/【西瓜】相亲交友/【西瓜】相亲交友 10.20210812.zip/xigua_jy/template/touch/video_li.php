<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{if $list}--><div class="flow_bbs_over"><!--{loop $list $k $v}-->
<div class="flow-bbs-card flow-card">
    <aside class="img-box memli_jump" data-id="$v[uid]">
        <img class="mem_video" src="{echo $v[video_cover] ? $v[video_cover] : ($v[album_ary][0] ? $v[album_ary][0] : $v[avatar])}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'">
        <!--{if $v['video_cover']}-->
        <img class="video_c_img" style="position:absolute;width:2rem;height:2rem" src="source/plugin/xigua_jy/static/img/vp.png" >
        <!--{/if}-->
        <!--{if $v[is_dig]}--><span>{lang xigua_hb:zhiding}</span><!--{/if}-->
        <!--{if $v[is_vip]||$v[verify]}--><div class="namejbtn">
<!--{if $v[is_vip]}--><img class="rzimg2" src="{$v[vip_icon]}?{VERHASH}"><!--{/if}--><!--{if $v[verify]}--><!--{if $_G[cache][plugin][xigua_hr][grtb]}--><img class="rzimg2" src="$_G[cache][plugin][xigua_hr][grtb]" /> <!--{else}--><img class="rzimg2" src="source/plugin/xigua_jy/static/img/sm.png?{VERHASH}" /><!--{/if}-->
            <!--{/if}-->
</div><!--{/if}-->
    </aside>
    <main class="content-box">
        <!--{if $jy_config[pbustyle]==2}-->
        <div class="other-box" style="margin-top:.5rem;">
            <a href="javascript:;" class="author memli_jump" data-id="$v[uid]" style="width:auto">
                <i class="avatar" style="background: url({$v[avatar]}) center center / cover no-repeat;"></i>
                <span class="name name_jy c3" style="position: relative;">{$v[nickname]} <i class="memli_gender g{$v[gender]}"></i></span>
            </a>
            <div class="jy_rnum">
                <!--{if $v[gongzuodi_ary][$citylevel]}--><span class="">{$v[gongzuodi_ary][$citylevel]}</span><!--{/if}-->
                <!--{if $v[age]}--><span class="">{$v[age]}</span><!--{/if}-->
            </div>
        </div>
        <!--{else}-->
        <p class="title memli_jump" data-id="$v[uid]">{$v[note]}</p>
        <div class="other-box">
            <a href="javascript:;" class="author memli_jump" data-id="$v[uid]" style="width:auto">
                <i class="avatar" style="background: url({$v[avatar]}) center center / cover no-repeat;"></i>
                <span class="name name_jy" style="position: relative;">{$v[nickname]} <i class="memli_gender g{$v[gender]}"></i></span>
            </a>
            <div class="jy_rnum">
                <!--{if $v[gongzuodi_ary][$citylevel]}--><span class="">{$v[gongzuodi_ary][$citylevel]}</span><!--{/if}-->
                <!--{if $v[age]}--><span class="">{$v[age]}</span><!--{/if}-->
            </div>
        </div>
        <!--{/if}-->
    </main>
</div>
<!--{/loop}--></div><!--{/if}-->