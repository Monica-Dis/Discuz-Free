<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{eval $config[tname] = $jy_config[pdmc];}--><!--{template xigua_hb:common_header}-->
<!--{eval $bgfc = hb_hex2rgb($config[maincolor], 0.1);}-->
<link rel="stylesheet" href="source/plugin/xigua_jy/static/jy.css?{VERHASH}" /><style>.weui-switch-cp__input:checked~.weui-switch-cp__box, .weui-switch:checked,.float_btn{background-color:$config[maincolor]!important;border-color:$config[maincolor]!important}.gzbtn,.vip_sm .h5:before,.vip_smh5:before,.taocan_card .card_date{background-color:$config[maincolor]}
.jv_jsbtn,.jy2_tagbtn,.jy_li_link{color:$config[maincolor]!important}.main_red,.jv_xz,.jbtn{color:$config[maincolor]}
.car-type .car-year-season,.picker-calendar-day.picker-calendar-day-selected span{background-color:$config[maincolor]!important;}.jy2_tagbtn,.jy_li_link{background:{$bgfc}!important}
.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]!important;}
.car-type .type-item-active,.jv_jsbtn,.jy2_tagbtn,.jy_li_link{border-color:$config[maincolor]!important}
.car-type .type-item-active {background:{$bgfc}!important;}
.check_box li.oncheck,.btnon{background:{$bgfc};color:$config[maincolor]}
.check_box li.oncheck:after,.btnon:after{border-color:$config[maincolor]}
.bton{background:{$bgfc}!important;color:$config[maincolor]!important}
.view_rightbtn{background-color:$config[maincolor];box-shadow: 0 0 0.3rem $config[maincolor]}
</style><script>var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_jy'][mkey]}",HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}"; var lockIng = 0;var GOOGLE = "{$_G['cache']['plugin']['xigua_jy']['google']}", PUB_VARID = 0, IGNORETIP = 0;var  PLZALLOW = '{lang xigua_jy:plzallow}', gengduodongtai = '{lang xigua_jy:gengduodongtai}', yiguanzhu = '{lang xigua_jy:yiguanzhu}', jiaguanzhu='{lang xigua_jy:jiaguanzhu}', quxiao = '{lang xigua_hb:quxiao}', MAXINDEXHY='$jy_config[maxindexhy]', MAXINDEXHYTIP = '{lang xigua_jy:zdxz}{$jy_config[maxindexhy]}{lang xigua_jy:g}';var tiphqj = '{lang xigua_jy:qj}', tiphlhh = '{lang xigua_jy:lhh}';</script>