<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_jy:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/mynew.css?{VERHASH}" />
<style>.weui-grids-mini .weui-grid{padding:1rem .5rem}.x_header{position:relative}.centtop1 a i{color:{$config[maincolor]}}.centtop2 a i{color:#999}.my_new_bd .my__head_wap{height:7.5rem}.my_new_bd .my__head_wap .weui-grids-mini{position: relative;bottom:0}.my_new_bd .my__head_new{margin-bottom:0;height:7.5rem}.my_new_bd .my__head_user{margin:.5rem .75rem;width:100%}.my_new_bd .jnav .weui-grid__label{margin-top:.5rem}.my_new_bd .qblink{padding-right:.5rem!important}.navtitle{display:none}
.my_new_bd .my__head_user {margin: .5rem .75rem;width: calc(100% - 1.5rem);}.my_new_bd .my__head_user>div {float: left;width: calc(100% - 3.5rem);}.my_new_bd .qblink {max-width: 70%;line-height: 1rem;height: 1rem;overflow: hidden;text-overflow: ellipsis;white-space: nowrap;padding:0;padding-left: .5rem;}
</style>
<div class="page__bd my_new_bd">
    <div class="do_bd">
    <div class="my__head_new <!--{if $user[gender]==2}-->main_bg<!--{/if}--> myjy">
        <!--{template xigua_jy:svg}-->
        <div class="my__head_wap block">
            <div class="my__head_user z">
                <a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=base" class="my__head_avatar z"><img src="$avatar" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'" ></a>
                <div>
                    <div class="my__head_nickname f16">{$user[nickname]} <em class="f12 op6">ID:{$_G[uid]}</em></div>
                    <a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=base" class="qblink">{echo $user[note]?$user[note] :lang_jy('zlxws',0)}</a>
                </div>
            </div>
            <!--{eval $viewsstyle = 'style="width:25%;"';}-->
            <div class="weui-grids weui-grids-mini">
                <a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=qianxian" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum4" class="countup f16">$qxnum</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_jy:wdqx}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=guanzhu" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum3" class="countup f16">{$favnum}</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_jy:wdgz}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=kan&type=tome" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum2" class="countup f16 ">$seeme_num</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_jy:skgw}</p>
                </a>
                <a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=kan" class="weui-grid" $viewsstyle>
                    <div class="tc">
                        <span id="njum1" class="countup f16 ">$mesee_num</span>
                    </div>
                    <p class="weui-grid__label f13 ">{lang xigua_jy:wkgs}</p>
                </a>
            </div>
        </div>
        <a class="main_color mystatus $status_cell" $status_link>$nowstatus</a>
    </div>

    <div class="tcouter"><!--{template xigua_jy:tcard}--></div>
    <div class="weui-cells border_none hcard">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_jy&ac=my&do=base">
            <div class="weui-cell__hd"><i class="iconfont icon-mingpian2 color-blue"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:jbzl}</p>
            </div>
            <div class="weui-cell__ft c9 f14"> $mybase_status </div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_jy&ac=my&do=album">
            <div class="weui-cell__hd"><i class="iconfont icon-tupian1 color-red"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:zpsp}</p>
            </div>
            <div class="weui-cell__ft c9 f14"> {lang xigua_jy:ysc}{$albumnunm}{lang xigua_jy:z} </div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_jy&ac=my&do=biaozhun">
            <div class="weui-cell__hd"><i class="iconfont icon-fensiguanli color-pink"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:zobz}</p>
            </div>
            <div class="weui-cell__ft c9 f14"> $biaozhun </div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_jy&ac=view&jyid={$_G[uid]}">
            <div class="weui-cell__hd"><i class="iconfont icon-shouye color-blue"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:wdzy}</p>
            </div>
            <div class="weui-cell__ft c9 f14">{lang xigua_jy:djck}</div>
        </a>
        <!--{if $jy_config['jydt']}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=pub&step=3&catid=$jy_config['jydt']">
            <div class="weui-cell__hd"><i class="iconfont icon-bianji1 color-red2"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:fbdd}</p>
            </div>
            <div class="weui-cell__ft c9 f14"></div>
        </a>
        <!--{/if}-->
    </div>

    <div class="weui-cells border_none hcard">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_jy&ac=my&do=line">
            <div class="weui-cell__hd"><i class="iconfont icon-ganxie1 color-pink weight"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:qianxian}</p>
            </div>
            <div class="weui-cell__ft c9 f14"><!--{if $my_line_num>0}--><span class="ifoset">{lang xigua_jy:sy} <em class="color-red2">{$my_line_num}</em> {lang xigua_jy:c}</span><!--{else}-->{lang xigua_jy:gmtc}<!--{/if}--></div>
        </a>
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_jy&ac=my&do=dig">
            <div class="weui-cell__hd"><img style="width:.8rem;height:.8rem" class="vm pr-1" src="source/plugin/xigua_jy/static/img/dig.png"/></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:wyzd}</p>
            </div>
            <div class="weui-cell__ft c9 f14"><!--{if $leave_days}--><span class="ifoset">{lang xigua_jy:sy} <em class="color-red2">{$leave_days}</em> {lang xigua_jy:d}</span><!--{else}-->{lang xigua_jy:zdbg}<!--{/if}--></div>
        </a>
        <!--<a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_jy&ac=jieshao">
            <div class="weui-cell__hd"><i class="iconfont icon-erified color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">����Ȧ�ƹ�</p>
            </div>
            <div class="weui-cell__ft c9 f14">?100Ԫ/��</div>
        </a>-->
        <a class="weui-cell weui-cell_access $status_cell" href="javascript:;">
            <div class="weui-cell__hd"><i class="iconfont icon-anquan1 color-forest weight"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:qxsz}</p>
            </div>
            <div class="weui-cell__ft c9 f14">{$nowstatus}</div>
        </a>
        <!--<a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_jy&ac=jieshao">
            <div class="weui-cell__hd"><i class="iconfont icon-erified color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:wdhb}</p>
            </div>
            <div class="weui-cell__ft f14">{lang xigua_jy:schb}</div>
        </a>-->
    </div>

    <div class="weui-cells border_none hcard">
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=qianbao">
            <div class="weui-cell__hd"><i class="iconfont icon-qianbao1 color-red"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:wdqb}</p>
            </div>
            <div class="weui-cell__ft f14 ifoset color-red">{$qianbao[money]}{lang xigua_jy:yuan}</div>
        </a>
        <!--{if $_G[cache][plugin][xigua_hr]}-->
        <!--{eval $curr = urlencode(hb_currenturl());}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hr&ac=join&ct=1&backto={$curr}">
            <div class="weui-cell__hd"><i class="iconfont icon-erified color-forest"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_jy:smrz}</p>
            </div>
            <div class="weui-cell__ft c9 f14">{$rz}</div>
        </a>
        <!--{/if}-->
        <a class="weui-cell weui-cell_access" href="$SCRITPTNAME?id=xigua_hb&ac=about">
            <div class="weui-cell__hd"><i class="iconfont icon-guize color-bluish"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_hb:bangzhu}</p>
            </div>
            <div class="weui-cell__ft"> </div>
        </a>
        <a class="weui-cell weui-cell_access" href="javascript:;" onclick='$.alert("<img src=$config[kfqrcode] /><br>{lang xigua_hb:changan}", "{lang xigua_hb:changan}");'>
            <div class="weui-cell__hd"><i class="iconfont icon-kefu color-pink"></i></div>
            <div class="weui-cell__bd">
                <p class="f15">{lang xigua_hb:kefu}</p>
            </div>
            <div class="weui-cell__ft c9 f14">{lang xigua_hb:zhwo}</div>
        </a>
    </div>
</div>
</div>

<div id="status_ctrl" class='weui-popup__container popup-bottom z501'>
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <h1 class="title">{lang xigua_jy:qxsz}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-cells  weui-cells_form before_none after_none">
                <!--{loop $xq_status $_k $_v}-->
                <div class="weui-cell weui-cell_switch">
                    <div class="weui-cell__bd">
                        <p>{$_v[title]}</p>
                        <p class="c9 f13 mt5">{$_v[desc]}</p>
                    </div>
                    <div class="weui-cell__ft">
                        <input class="weui-switch" type="radio" name="xq_status" value="{$_k}" <!--{if $user[status]==$_k}-->checked<!--{/if}-->>
                    </div>
                </div>
                <!--{/loop}-->
                <a href="javascript:;" class="picker-button close-popup iclose"><i class="iconfont icon-guanbijiantou c9 f24"></i></a>
            </div>

        </div>
    </div>
</div>

<!--{eval $jy_tabbar=1;$tabbar=0;}-->
<!--{template xigua_jy:footer}--><script src="source/plugin/xigua_hb/static/countUp.js"></script><script>
setTimeout(function () {$('.mystatus').addClass('r10');}, 300);
$(document).on('click','.J_ping', function(){
    $('.J_ping').addClass('type-item-gray').removeClass('type-item-active');
    $(this).addClass('type-item-active').removeClass('type-item-gray');
});
$('.J_ping:first-child').trigger('click');
$('.J_ping:first-child').find('.typevip').trigger('click');
$(document).on('click','.tcouter', function () {
    hb_jump('$SCRITPTNAME?id=xigua_jy&ac=my&do=vip&mobile=2');
});
var options={useEasing:true,useGrouping:true,separator:'',decimal:'.',prefix:'',suffix:''};
new countUp("njum1", 0, $('#njum1').text(), 0, 2.5, options).start();
new countUp("njum2", 0, $('#njum2').text(), 0, 2.5, options).start();
new countUp("njum3", 0, $('#njum3').text(), 0, 2.5, options).start();
new countUp("njum4", 0, $('#njum4').text(), 0, 2.5, options).start();

$(document).on('click','.status_cell', function () {
    $('#status_ctrl').popup();
});
$(document).on('click','input[name="xq_status"]', function () {
    var that = $(this);
    var val1 = that.val();
    if(val1=='$user[status]'){
        return false;
    }
    $.ajax({
        type: 'post',
        url: _APPNAME+'?id=xigua_jy&ac=my&do=save_status&inajax=1',
        data: {'formhash':'{FORMHASH}', 'status':val1},
        dataType: 'xml',
        success: function (data) {
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () {}
    });
});
$(document).on('click','.pay_shows2', function () {
    $.ajax({
        type: 'post',
        url: _APPNAME+'?id=xigua_jy&ac=my&do=payshows&inajax=1',
        data: {'formhash':'{FORMHASH}'},
        dataType: 'xml',
        success: function (data) {
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () {}
    });
    return false;
});
<!--{if $_GET['shows']==-3}-->$('.mystatus').trigger('click');<!--{/if}-->
<!--{if $showmobiletip}-->
$.modal({
    title: '{lang xigua_jy:ts}',
    text: '<div class="main_color">{lang xigua_hb:tipmobile}</div>',
    buttons: [ { text: "{lang xigua_jy:queding}", className: "default", onClick: function(){hb_jump("$bindurl");} }]
});
<!--{/if}-->
</script>