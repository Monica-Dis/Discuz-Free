<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<div class="weui-cells mt0 after_none before_none">
<div class="weui-cell">
    <div class="weui-cell__bd">
        <div class="weui-uploader">
            <div class="weui-uploader__hd">
                <p class="weui-uploader__title">{lang xigua_jy:splbt}</p>
                <!--{if $jy_config['maximg']>0}-->
                <div class="weui-uploader__info">{echo str_replace('n', $jy_config['maximg'], lang_jy('zuiduozhao',0))}</div>
                <!--{/if}-->
            </div>
            <div class="weui-uploader__bd">
                <ul class="weui-uploader__files" data-max="{$jy_config['maximg']}" data-maxtip="{echo str_replace('n', $jy_config['maximg'], lang_jy('zuiduozhao',0))}">
                    <!--{loop $old_data[album_ary] $img}-->
                    <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                        <input type="hidden" name="form[album][]" value="$img"/>
                        <div class="weui-uploader__file-content">
                            <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                    </li>
                    <!--{/loop}-->
                </ul>
                <div class="weui-uploader__input-box newupload">
                    <input id="uploaderInput" class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                    <img src="source/plugin/xigua_jy/static/img/up.png">
                    <p>{lang xigua_hb:plzupload}</p>
                </div>
            </div>
        </div>
    </div>
</div>

    <!--{template xigua_jy:choseconfig}-->

    <div class="weui-cell ">
        <div class="weui-cell__bd">
            <div class="weui-uploader__hd">
                <p class="weui-uploader__title">{lang xigua_jy:note}</p>
            </div>
            <textarea name="form[note]" class="weui-textarea texta mt0" placeholder="{lang xigua_jy:note_tip}" rows="3"></textarea>
        </div>
    </div>

</div>

<div class="footer_fix"></div>
<div class="bottom_fix"></div>
<div class="fix-bottom " >
    <a href="$SCRITPTNAME?id=xigua_jy&ac=my" class="weui-btn weui-btn_primary weui-btn_sec main_color">{lang xigua_jy:tg}</a>
    <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_jy:wc}">
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>