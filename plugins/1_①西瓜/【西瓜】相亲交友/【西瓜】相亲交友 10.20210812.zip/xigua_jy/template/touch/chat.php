<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_jy:header}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/chat.css?{VERHASH}" />
<style>.me-talk .content-talk{border:$config[maincolor] solid 1px; background:$config[maincolor] }.me-talk .content-talk::before{ border-top:$config[maincolor] solid 1px; border-right:$config[maincolor] solid 1px; background:$config[maincolor] }
.consult_cell{width: 100%;height: auto;display:block}
.chat___goodsCard{width:100%;box-sizing:border-box;padding:.65rem;margin:0 auto;background:#fff;border-radius:.5rem;display:-webkit-flex;display:flex;-webkit-align-items:flex-start;align-items:flex-start;position:relative}.taro_img img{width:100%;height:100%}.taro_img{display:inline-block;overflow:hidden;position:relative;font-size:0;-webkit-flex-shrink:0;flex-shrink:0;width:4rem;height:4rem;border-radius:.25rem}.chat___goodsInfo___2DueR{margin-left:.5rem;width:calc(100% - 7.5rem)}.chat___name___10ZSG{font-size:.7rem;color:#222;line-height:1rem;display:-webkit-box;-webkit-line-clamp:2;overflow:hidden;word-break:break-all;max-height:2rem}.chat___price___2AE1P{margin-top:.3rem;font-size:.7rem;color:#fe0036;line-height:1rem}.chat___hosName___jk80L{font-size: .65rem;color: #777;line-height: 1rem;margin-top: .3rem;max-height: 2rem;overflow: hidden;text-overflow: ellipsis;display: -webkit-box;-webkit-line-clamp: 2;word-break: break-all;}
.chat___reserveBtn___2Fq9t{width: 3rem;height:1.2rem;background:$config[maincolor];border-radius: 1rem;font-size: .6rem;color: #000;line-height: 1.2rem;text-align: center;position: absolute;color:#fff;right: .75rem;top: 2rem;}</style>
<!--{eval $no_header_fix=1;}-->
<div class="page__bd">
    <div id="chat_widget">
        <div class="widget-list">
            <ul class="talk-msg" id="list1">
            </ul>
        </div>
    </div>
    <div class="none">
        <!--{template xigua_hb:loading}-->
    </div>
    <div class="fix-bottom in_bottom" style="padding:.5rem .75rem 0;z-index:501">
        <div class="weui-cells mt0 before_none after_none" style="margin-bottom:.5rem">
            <div class="weui-cell p0">
                <div class="weui-cell__hd"><a href="$SCRITPTNAME?id=xigua_jy&ac=chats&high=3"><i class="iconfont icon-fanhuijiantou f20"></i></a></div>
                <div class="weui-cell__bd">
                    <input style="background:#f5f5f5;padding:.15rem .25rem;width: calc(100% - 1rem);" class="weui-input" id="commentinput" type="text" name="mesasgae" placeholder="{lang xigua_hb:sendplc}" value="">
                </div>
                <div class="weui-cell__ft">
                    <input type="button" class="weui-btn weui-btn_primary weui-btn_mini" name="smsdosubmit" id="smsdosubmit" value="{lang xigua_hb:send}">
                </div>
            </div>
        </div>
    </div>
    <div class="bottom_fix" style="background:transparent"></div>
</div>

<!--{eval $jy_tabbar=0;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->
<script>
    var loadingurl1 = '$SCRITPTNAME?id=xigua_jy&ac=chat&do=chat_li&inajax=1&touid=$touid&page=';
    scrollto = 1;

    $(document).on('click','#smsdosubmit', function () {
        var input = $('#commentinput').val();
        if(!input){
            return ;
        }
        $.showLoading();
        $.ajax({
            type: 'post',
            url: _APPNAME + '?id=xigua_jy&ac=chatcmt&do=comment&inajax=1&type=1&pubid=0',
            data: {'comment': input, 'touid': '$touid', 'formhash': FORMHASH},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if (null == data) {
                    tip_common('error|' + ERROR_TIP);
                    return false;
                }
                var s = data.lastChild.firstChild.nodeValue;
                var msgar = s.split('|');
                if (msgar[0] == 'success') {
                    $('#commentinput').val('');
                    $.ajax({
                        type: 'get',
                        url: _APPNAME + '?id=xigua_jy&ac=chat&do=fetch&inajax=1&cid='+msgar[3],
                        dataType: 'xml',
                        success: function (data) {
                            $.hideLoading();
                            if (null == data) {
                                tip_common('error|' + ERROR_TIP);
                                return false;
                            }
                            var s = data.lastChild.firstChild.nodeValue;
                            if(s){
                                $('#list1').append(s);
                                $('html,body').animate({scrollTop: $('.bottom_fix').offset().top},800);
                            }
                        }
                    });
                }
            }
        });
    });
    if ($("#list1").length > 0) {
        load_toplist();
        setTimeout(function(){
            $('html,body').animate({scrollTop: $('.bottom_fix').offset().top},1);
        }, 500);
    }
    $(window).on('scroll', function () {
        if($(document).scrollTop()<=0){
            load_toplist();
        }
    });

    var lasts = '';
    function load_toplist() {
        if (page <= 0) {
            return;
        }
        $.ajax({
            type: 'get', url: loadingurl1 + '' + page + _URLEXT, dataType: 'xml', success: function (data) {
                var s = $.trim(data.lastChild.firstChild.nodeValue);
                if (!s) { page = -1; return; }
                if(lasts===s){
                    return;
                }
                $("#list1").prepend(s);
                lasts = s;
                page++;
            }
        });
    }

    var times =0;
    setInterval(function () {
        $.ajax({
            type: 'get',
            url: _APPNAME + '?id=xigua_jy&ac=chat&do=fetchpm&inajax=1&touid=$touid',
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if (null == data) {
                    tip_common('error|' + ERROR_TIP);
                    return false;
                }
                var s = data.lastChild.firstChild.nodeValue;
                if(lasts===s){
                    return;
                }
                if(times>0 && s){
                    $('#list1').append(s);
                    $('html,body').animate({scrollTop: $('.bottom_fix').offset().top},800);
                }
                times=1;
            }
        });
    }, 10000);
</script>