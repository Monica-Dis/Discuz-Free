<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{loop $list $k $v}-->
<!--{eval $qxrow = $qxlist[$v[uid]];}-->
<div class="memli_li cl border_bfull" >
    <div class="memli_left">
        <div class="memli_logo memli_jump" data-id="$v[uid]"><img src="$v[avatar]" onerror="this.error=null;this.src='source/plugin/xigua_jy/static/img/dftava.png'"></div>
        <i class="memli_gender g{$v[gender]}"></i>
    </div>
    <div class="memli_right">
        <div class="memli_realname cl">
            <span class=" memli_jump" data-id="$v[uid]">{$v[nickname]}</span>
            <!--{if $v[is_vip]||$v[verify]}--><span class="jbtn pr-1">
<!--{if $v[is_vip]}--><img class="rzimg2" src="{$v[vip_icon]}?{VERHASH}"><!--{/if}--><!--{if $v[verify]}--><!--{if $_G[cache][plugin][xigua_hr][grtb]}--><img class="rzimg2" src="$_G[cache][plugin][xigua_hr][grtb]" /> <!--{else}--><img class="rzimg2" src="source/plugin/xigua_jy/static/img/sm.png?{VERHASH}" /><!--{/if}-->
                <!--{/if}-->
</span><!--{/if}-->
            <div class="memli_span memli_span_pos">
                <span>{$qxrow[crts_word]} : $qxrow[crts_u]</span>
            </div>
        </div>
        <div class="memli_note cl">
            <p class="z memli_jump" data-id="$v[uid]">{lang xigua_jy:hyid} : $v[uid]</p>
            <!--{if $qxrow[touid]==$_G['uid'] && $qxrow[status]==-1}-->
            <div class="y">
                <a href="javascript:;" class="weui-btn weui-btn_mini qxconfirm" data-qxid="$qxrow[id]" data-agree="1" data-fromuid="{$v[uid]}">{lang xigua_jy:ty}</a>
                <a href="javascript:;" class="weui-btn weui-btn_mini qxconfirm" data-qxid="$qxrow[id]" data-agree="0" data-fromuid="{$v[uid]}">{lang xigua_jy:jj}</a>
            </div>
            <!--{else}-->
            <a class="statv y {$qxrow[status_color]}" href="javascript:;">{$qianxian_status[$qxrow[status]]}</a>
            <!--{/if}-->
        </div>
    </div>
</div>
<!--{/loop}-->
