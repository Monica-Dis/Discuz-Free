<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{if $newest}-->
<div class="jy_toutiao">
    <div class="chip-row">
        <!--{if strpos($jy_config[xibao],'/')===false}-->
        <div class="toutiao"><i class="iconfont icon-tongzhi f14 "></i> {lang xigua_jy:xx}</div>
        <!--{else}-->
        <div class="toutiao"><img class="pr-1" src="$jy_config[xibao]" /></div>
        <!--{/if}-->
        <div class="toutiao-slider swiper-container" id="newsSlider">
            <ul class="swiper-wrapper">
                <!--{loop $newest $_v}-->
                <li class="swiper-slide">{lang xigua_jy:gxhy}{echo muhu_uid($_v[uid]);}{lang xigua_jy:hhy}{echo muhu_uid($_v[touid]);}{lang xigua_jy:qxcg}</li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
</div>
<!--{/if}-->