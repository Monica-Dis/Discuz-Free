<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_jy:header}--><style>.weui-input,.weui-textarea,.weui-uploader__title,.weui-label{font-size:.75rem}</style>
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<form  action="$SCRITPTNAME?id=xigua_jy&ac=my&do=album&st={$_GET['st']}" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <input name="form[stid]" value="{echo $old_data[stid]?$old_data[stid]:$_GET['st']}" type="hidden">
    <div class="page__bd bgf">
        <!--{template xigua_hb:common_nav}-->
        <div class=" cl">
            <div class="main_color top_tip" style="background:$bgfc">{lang xigua_jy:splbt_tip}</div>
        </div>

        <div class="weui-cells mt0 after_none before_none">
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title">{lang xigua_jy:splbt}<!--{if $showv}-->{lang xigua_jy:dotshipin}<!--{/if}--></p>
                            <!--{if $jy_config['maximg']>0}-->
                            <div class="weui-uploader__info f14">{echo str_replace('n', $jy_config['maximg'], lang_jy('zuiduozhao',0))}</div>
                            <!--{/if}-->
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files weui_videos" data-max="{$jy_config['maximg']}" data-maxtip="{echo str_replace('n', $jy_config['maximg'], lang_jy('zuiduozhao',0))}">
                                <!--{loop $old_data[album_ary] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)">
                                    <input type="hidden" name="form[album][]" value="$img"/>
                                    <div class="weui-uploader__file-content">
                                        <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box newupload">
                                <input id="uploaderInput" class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <img src="source/plugin/xigua_jy/static/img/up.png">
                                <p>{lang xigua_hb:plzupload}</p>
                            </div>
                            <!--{if $showv}-->
                            <div class="weui-uploader__input-box newupload">
                                <img src="source/plugin/xigua_jy/static/img/video.png">
                                <p>{lang xigua_hb:upvideo}</p>
                                <input class="weui-uploader__input_video" data-name="form[video]" type="file" accept="video/*">
                            </div>
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
            <!--{template xigua_jy:video}-->
        </div>
        <div class="fix-bottom mt10">
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_jy:save}">
        </div>
    </div>
    <div id="popctrl" class="weui-popup__container" style="z-index:1001">
        <div class="weui-popup__modal">
            <div style="height: 100vh"><img id="photo"></div>
            <div class="pub_funcbar">
                <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
                <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
            </div>
        </div>
    </div>
</form>
<!--{template xigua_hb:enter_up}-->
<!--{eval $jy_tabbar=0;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->