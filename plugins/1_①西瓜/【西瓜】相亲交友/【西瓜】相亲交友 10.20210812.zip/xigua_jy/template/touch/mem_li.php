<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if !$qxlist}-->
<!--{if $_GET['orderby']=='video' || $jy_config[liststyle]=='video'|| $_GET[tpl]=='video'}-->
<!--{template xigua_jy:video_li}-->
<!--{else}-->
<!--{template xigua_jy:mems_li}-->
<!--{/if}-->
<!--{else}-->
<!--{template xigua_jy:memqx_li}-->
<!--{/if}-->