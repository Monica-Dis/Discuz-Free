<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{loop $list $_k $v}-->
<div class="hn_item cl">
    <div class="z cl">
        <div class="hn_pic">
            <img src="{$v[avatar]}" onerror="this.src='source/plugin/xigua_jy/static/img/dftava.png';this.onerror='';">
        </div>
        <div class="hn_txt">
            <div class="hn_name">{$v[name]}</div>
            <div class="f13">{$v[description]}</div>
        </div>
    </div>
    <div class="hn_link">
        <a href="tel:{$v[mobile]}" class="hn_tel"></a>
        <a href="javascript:;" class="hn_wx" data-tip="<div>{lang xigua_jy:cnbchn}</div><br>{lang xigua_jy:htj}<em class=main_color>{$v[wx]}</em>" data-qrcode="{$v[qrcode]}"></a>
    </div>
</div>
<!--{/loop}-->
