<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $jy_tabbar}--><!--{eval include DISCUZ_ROOT.'source/plugin/xigua_jy/include/c_tabbar.php'}--><div class="weui-tabbar<!--{if $showfloatapp}--> none<!--{/if}-->">
    <!--{loop $custom_nav $loop_k $loopin}--><!--{eval
    $highlight = '&high='.$loop_k;
    if($loopin['adlink']=='pub'):
        $inlink = 'javascript:;" id="pubj';
    elseif($loopin['adlink']=='xuqiu'):
        $inlink = 'javascript:;" id="faxuqiu';
    else:
        $inlink = $loopin['adlink'].$highlight;
    endif;
    $is_on = !$is_on && (  strpos($curturl,$inlink)!==false || strpos($curturl,$highlight)!==false  || ($_GET['high'] && $_GET['high']==$loop_k) || ($ehckac&&strpos($inlink,'ac='.$ehckac)!==false)  );
    if($is_off==$navcount):
    endif;
    if($is_on):
        $loopin[icon] = $loopin[icon2]?$loopin[icon2]:$loopin[icon];
    else:
        $is_off++;
    endif;
}--><a href="{$inlink}" class="weui-tabbar__item <!--{if $is_on}-->weui-bar__item_on<!--{/if}-->">
        <!--{if $loopin[icon]}-->
        <img src="$loopin[icon]" class="tabcon3 <!--{if $loopin[up]}-->up_icon<!--{/if}-->" />
        <!--{/if}-->
        <!--{if !$loopin[up]}-->
        <p class="weui-tabbar__label">{$loopin[name]}</p>
        <!--{/if}-->
<!--{if strpos($inlink, 'chats')!==false && $newpm}--><span class="weui-badge weui-badge_dot" style="position:absolute;top:.4rem;right:.7rem"></span><!--{/if}-->
    </a><!--{/loop}-->
</div><!--{/if}-->