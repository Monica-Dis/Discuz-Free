<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_jy:header}-->
<!--{if $_G['cache']['plugin']['xigua_jy']['defaultlogo']}--><div class="hide none"><img src="{$_G['cache']['plugin']['xigua_jy']['defaultlogo']}" /></div><!--{/if}-->
<div class="page__bd ">
    <!--{if getcookie('miniprogram') && $ac=='index'}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
    <!--{if $ac=='index' && $config[showheader]}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if !$hide_nav}--><header class="x_header bgcolor_11 cl  weui-flex f15" style="background:transparent!important;position:absolute;z-index:1"><!--{if $jy_config[allowst] && $_G['cache']['plugin']['xigua_st']['showfz']}-->
<span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_jy&ac=index&high=0");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
<!--{else}-->
<a class="z x_logo"  href="$SCRITPTNAME?id=xigua_jy"><!--{if strpos($jy_config['logo'],'/')!==false}--><img src="$jy_config[logo]" /> <!--{else}--><span style="margin:0 .75rem">$jy_config[logo]</span><!--{/if}--></a>
<!--{/if}-->
</header><!--{/if}-->
    <!--{if $topnavslider}-->
    <div class="swipe cl">
        <div class="swipe-wrap">
            <!--{loop $topnavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $topnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <!--{/if}-->
<!--{if $jing_list}-->
<nav class=" nav-list cl swipe" style="padding-top:.35rem">
    <div class="swipe-wrap">
        <div>
            <ul class="cl">
                <!--{loop $jing_list $k $n}-->
                <!--{if $k && $k%$numshow==0}-->
            </ul>
        </div>
        <div>
            <ul class="cl">
                <!--{/if}-->
                <li style="width:$widthshow">
                    <a href="{$n['adlink']}">
                        <span>
                            <img src="$n['icon']" <!--{if $jy_config[suof]}-->style="transform:scale($jy_config[suof]);"<!--{/if}-->/>
                        </span>
                        <em class="m-piclist-title c3">{$n['name']}</em>
                    </a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position position1">
            <!--{loop $jing_count $k $v}-->
            <li {if $k==0} class="current" {/if}></li>
            <!--{/loop}-->
        </ul>
    </nav>
</nav>
<!--{/if}-->
<!--{template xigua_jy:gonggao}-->
<!--{eval
$adwhere = array();
$adwhere[] = 'types=\'\'';
$index_list =  C::t('#xigua_jy#xigua_jy_index')->list_by_where($adwhere);
$newindex_list = array();
if($index_list):
    foreach ($index_list as $index => $item):
        $newindex_list[$item['style']][] = $item;
    endforeach;
endif;
}-->
<!--{loop $newindex_list $_k $_v}-->
<!--{if $_k==99}-->
<div class="swipe cl" data-speed="5000">
    <div class="swipe-wrap">
        <!--{loop $_v $__k $__v}-->
        <div><a href="$__v[adlink]"><img src="$__v[icon]"></a></div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $_v $__k $__v}-->
            <li <!--{if $__k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{else}-->
<!--{eval
if(!$_k):
    $_k = 4;
endif;
$tmpp = array_chunk($_v, $_k);
}--><!--{loop $tmpp $__k $tmpp2}-->
<!--{eval $counttmpp2 = count($tmpp2);}-->
<ul class="inedxicon cl" style="margin:.5rem 0">
    <!--{loop $tmpp2 $__k $__v}-->
    <li style="width:{echo 100/$counttmpp2;}%"><a href="$__v[adlink]"><img src="$__v[icon]"></a></li>
    <!--{/loop}-->
</ul>
<!--{/loop}-->
<!--{/if}-->
<!--{/loop}-->

    <div class="jy_nav">
        <div class="weui-cells fixbanner before_none mt0">
            <div class="weui-navbar weui-banner nobg fixbanner_in" style="width: calc(100% - 3.5rem);overflow-x: auto;min-width:50%">
                <a href="$SCRITPTNAME?id=xigua_jy" class="weui-navbar__item <!--{if !$_GET['orderby']}-->weui_bar__item_on<!--{/if}-->">
                    <span>&nbsp;{lang xigua_jy:tjdr}</span>
                </a>
                <!--{if 0}-->
                <a href="$SCRITPTNAME?id=xigua_jy&orderby=pipei" class="weui-navbar__item <!--{if 'pipei'==$_GET['orderby']}-->weui_bar__item_on<!--{/if}-->">
                    <span>{lang xigua_jy:zjpp}</span>
                </a>
                <!--{/if}-->
                <a href="$SCRITPTNAME?id=xigua_jy&orderby=new" class="weui-navbar__item <!--{if 'new'==$_GET['orderby']}-->weui_bar__item_on<!--{/if}-->" >
                    <span>{lang xigua_jy:zxhy}</span>
                </a>
                <a href="$SCRITPTNAME?id=xigua_jy&orderby=video" class="weui-navbar__item <!--{if 'video'==$_GET['orderby']}-->weui_bar__item_on<!--{/if}-->">
                    <span>{lang xigua_jy:spxq}</span>
                </a>
                <!--{loop $navlist $_k $_v}-->
                <a href="{$_v['adlink']}" class="weui-navbar__item <!--{if strpos($curturl, $_v['adlink'])!==false}-->weui_bar__item_on<!--{/if}-->">
                    <span>$_v[name]</span>
                </a>
                <!--{/loop}-->
                <!--<a href="javascript:;" class="weui-navbar__item" >
                    <span class="sx sxuan sxbtn">{lang xigua_jy:sx}</span>
                </a>-->
            </div>
            <div class="sx_outer"><span class="sx sxuan sxbtn">{lang xigua_jy:sx}</span></div>
        </div>
    </div>
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
    <!--{template xigua_jy:indexfilter}-->
</div>
<script>
var _pre = window.location.href;
if(_pre.indexOf('?')===-1&& _pre.indexOf('&')===-1){
    _pre = _APPNAME+'?id=xigua_jy';
}
var loadingurl = _pre+'&ac=mem_li&inajax=1&page=';
</script>
<!--{eval $jy_tabbar = 1;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->