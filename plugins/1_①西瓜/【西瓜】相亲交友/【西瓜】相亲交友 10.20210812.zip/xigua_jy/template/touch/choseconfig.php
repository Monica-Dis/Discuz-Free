<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{loop $choseconfig $_k $_v}-->
<!--{eval $old_data_k = explode(',', $old_data[$_k])}-->
<div class="weui-cell" style="padding: .75rem;">
    <div class="weui-cell__bd">
        <div class="weui-uploader__hd">
            <p class="weui-uploader__title">{$_v[title]} <!--{if $_v[maxnum]>1}--> (<em class="nownum">0</em>/{$_v[maxnum]})<!--{/if}--></p>
        </div>
        <div class="post-tags cl" data-max="{$_v[maxnum]}">
            <!--{loop $_v[data] $__k $__v}-->
            <!--{eval $tag_on = in_array(trim($__v), $old_data_k) ? 'tag-on' : '';}-->
            <a class="weui-btn weui-btn_mini weui-btn_default $tag_on" href="javascript:;" onclick="return _setTypeid($__k, this, '$_k');">$__v</a>
            <input name="form[$_k][$__k]" type="hidden" value="<!--{if $tag_on}-->1<!--{else}-->0<!--{/if}-->" />
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{/loop}-->
