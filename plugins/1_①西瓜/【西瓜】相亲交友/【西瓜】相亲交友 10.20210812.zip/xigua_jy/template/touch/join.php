<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_jy:header}--><style>html,.page, body{background:#fff}</style><link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<div class="page__bd bgf">
    <!--{if stripos($_SERVER['HTTP_USER_AGENT'], 'Android') && HB_INWECHAT}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{/if}-->
    <!--{if $step==1}-->
    <form action="$SCRITPTNAME?id=xigua_jy&ac=join&mobile=2{$urlext}" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >
        <input type="hidden" name="step" value="1" >
        <div class="join_step1">
            <div class="join_label cl">
                <label for="gender_1" class="nan gender_on">
                    <input name="form[gender]" value="1" id="gender_1" type="radio" checked>
                    <img class="gender_img" src="source/plugin/xigua_jy/static/nan.png" />
                    <img class="gender_img"  src="source/plugin/xigua_jy/static/nan_off.png" />
                    <img class="dui_img" src="source/plugin/xigua_jy/static/dui.png" />
                </label>
                <label for="gender_2" class="nv gender_off">
                    <input name="form[gender]" value="2" id="gender_2" type="radio">
                    <img class="gender_img" src="source/plugin/xigua_jy/static/nv.png" />
                    <img class="gender_img" src="source/plugin/xigua_jy/static/nv_off.png" />
                    <img class="dui_img" src="source/plugin/xigua_jy/static/dui.png" />
                </label>
                <p class="gender_tit">{lang xigua_jy:qxzndxb}</p>
            </div>
            <div class="join_label cl">
                <div class="join_input">
                    <input placeholder="{lang xigua_jy:qtxndnc}" type="text" class="weui-input join_input_txt" name="form[nickname]" value="{$_G[username]}" />
                </div>
                <p class="gender_tit">{lang xigua_jy:qtxndnc}</p>
            </div>
            <div class="join_label cl">
                <div class="join_input">
                    <input placeholder="{lang xigua_jy:qtxzssr}" type="text" id="date_picker" class="weui-input join_input_txt" name="form[birthday]" value="$firstbirth2" />
                </div>
                <p class="gender_tit">{lang xigua_jy:qtxzssrtip}</p>
            </div>
        </div>

        <div class="join_step1_buttons">
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_jy:wc}">
        </div>
    </form>
    <!--{elseif $step==2}-->
    <form action="$SCRITPTNAME?id=xigua_jy&ac=join&mobile=2{$urlext}" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}" >
        <input type="hidden" name="step" value="2" >
        <!--{template xigua_jy:upload}-->
    </form>
    <!--{/if}-->
</div>

<div class="masker" onclick='$(".choose_ctrl").select("close");$(".dig_ctrl").select("close")'></div>
<!--{eval $tabbar=0;$jy_tabbar=0;}-->
<!--{template xigua_jy:footer}-->
<!--{template xigua_hb:enter_up}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/picker.js?_{VERHASH}" charset="utf-8"></script>
<script>$("#date_picker").calendar({value:['$firstbirth'],dateFormat:'{lang xigua_jy:datefomat}'});</script>