<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_jy:header}-->
<style>.x_header_fix{height:0}.x_header {background: transparent!important;position: absolute;}.navtitle{display: none!important}.page, body{background:#fff}</style>
<div class="page__bd bgf">
    <!--{if $v[album_ary][0]}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$v[album_ary][0]"/></div><!--{/if}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{if $v[album_ary]}-->
    <div class="jyswipe cl" style="position:relative;margin:0;overflow:hidden" >
        <div class="swipe-wrap" style="transition: all .3s;background:#000">
            <!--{loop $v[album_ary] $_k $slider}-->
            <!--{if strpos($slider, 'suo')!==false}-->
            <!--{eval continue;}-->
            <!--{/if}-->
            <div class="swp imgloading"><img style="max-height:70vw" src="$slider"  onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'" /> </div>
            <!--{/loop}-->
        </div>
        <nav class="bullets ifoset none"><em>1</em> / <em>$icc</em></nav>
        <div class="jy_timeu ifoset">{lang xigua_jy:gong} {$icc} {lang xigua_jy:z}</div>
    </div>
    <!--{else}-->
    <div class="jyview_top <!--{if $v[gender]==2}-->main_bg<!--{/if}--> myjy">
        <!--{template xigua_jy:svg}-->
    </div>
    <!--{/if}-->
    <div class="none view_tools_mask"></div>
    <div class="none view_tools animated">
        <ul>
            <li class="border_bottom" ><a href="$SCRITPTNAME?id=xigua_hj"><i class="iconfont icon-anquan1 "></i> {lang xigua_jy:jb}</a></li>
            <!--{if $blackinme}-->
            <li class="border_bottom" ><a href="javascript:;" class="lahei" data-inhei="1" data-uid="{$v[uid]}"><i class="iconfont icon-delete_fill "></i> {lang xigua_jy:jc}</a></li>
            <!--{else}-->
            <li class="border_bottom" ><a href="javascript:;" class="lahei" data-inhei="0" data-uid="{$v[uid]}"><i class="iconfont icon-delete_fill "></i> {lang xigua_jy:lh}</a></li>
            <!--{/if}-->
            <li><a href="$SCRITPTNAME?id=xigua_jy&ac=my"><i class="iconfont icon-xiaolian2 "></i> {lang xigua_jy:wd}</a></li>
        </ul>
    </div>
<div class="shottag1">
    <section class="jyinfo_top normal_style cl">
        <div class="jyinfo_avatar">
            <img src="$v[avatar]" /><i class="memli_gender g{$v[gender]}"></i>
            <em class="jyv_id">ID:{$v[uid]}</em>
        </div>
        <div class="jyinfo_title">
            <h5 class="ifoset"><!--{if $titlel}-->$titlel<!--{/if}--><!--{if $v[is_vip]||$v[verify]}--><span class="jbtn pr-1">
<!--{if $v[is_vip]}--><img class="rzimg2" src="{$v[vip_icon]}?{VERHASH}"><!--{/if}--><!--{if $v[verify]}--><!--{if $_G[cache][plugin][xigua_hr][grtb]}--><img class="rzimg2" src="$_G[cache][plugin][xigua_hr][grtb]" /> <!--{else}--><img class="rzimg2" src="source/plugin/xigua_jy/static/img/sm.png?{VERHASH}" /><!--{/if}-->
<!--{/if}-->
</span><!--{/if}-->
<em class="jyinfo_last">$v[lastvisit]</em></h5>
            <div class="jzv_tit ifoset">
<!--{if $v[gongzuodi_ary][2]}--><span class="memli_spani">{$v[gongzuodi_ary][1]}{$v[gongzuodi_ary][2]}</span>
<!--{elseif $v[gongzuodi_ary][1]}--><span class="memli_spani">{$v[gongzuodi_ary][0]}{$v[gongzuodi_ary][1]}</span><!--{/if}-->
<!--{if $v[age]}--><span class="memli_spani">{$v[age]}</span><!--{/if}-->
<!--{if $v[zhiye]}--><span class="memli_spani">{$v[zhiye]}</span><!--{/if}-->
<!--{if $v[shengao]}--><span class="memli_spani">{$v[shengao]}{$base_status1_fix[shengao]}</span><!--{/if}-->
            </div>
        </div>
    </section>
    <section class="vehicle-file jlv_desc">
        <div class="jlv_outer"></div>
        <div class="auto_analysis">{$v[note]}</div>
    </section>
</div>
<!--{if !$showtipbase}-->
<!--{if $v['video']}-->
<div class="jlv_com">
    <h3 class="part-title">{lang xigua_jy:tdsp}</h3>
    <div class="vehicle-file cl">
        <!--{if $mine['is_vip'] || $check_qx['allowvideo']}-->
        <div class="album_swiper">
            <div class="pr" style="overflow:hidden;width:{$jy_config[vwidth]}%;">
                <!--{if stripos($_SERVER['HTTP_USER_AGENT'], 'iphone')||stripos($_SERVER['HTTP_USER_AGENT'], 'ipad')}-->
                <video  class="video_bg"  x5-video-player-type="h5" x5-video-player-fullscreen="true" x-webkit-airplay="allow" controlslist="nodownload" poster="{$v['video_cover']}" src="{$v['video']}"  preload="auto"   controls="controls"></video>
                <!--{else}-->
                <video id="video_set" class="video_bg"  x5-video-player-type="h5" x5-video-player-fullscreen="true" x-webkit-airplay="allow" controlslist="nodownload"  poster="{$v['video_cover']}" src="{$v['video']}"  preload="auto" ></video>
                <img class="video_v_icon" src="source/plugin/xigua_jy/static/img/vp.png">
                <!--{/if}-->
            </div>
        </div>
        <!--{else}-->
        <div class="isnotvipshow"><a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=vip">{lang xigua_jy:djktvip}</a></div>
        <!--{/if}-->
    </div>
</div>
<!--{/if}-->
<div class="jlv_com">
    <h3 class="part-title">{lang xigua_jy:tdsp2}</h3>
    <div class="vehicle-file cl">
        <!--{if $mine['is_vip'] || $check_qx['allowalbum']}--><!--{else}-->
        <div class="isnotvipshow"><a href="$SCRITPTNAME?id=xigua_jy&ac=my&do=vip">{lang xigua_jy:djktvip2}</a></div>
        <!--{/if}-->
        <div class="swiper-container album_swiper">
            <div class="swiper-wrapper">
                <!--{loop $v[album_ary] $_k $_v}-->
                <div class="swiper-slide imgloading">
                    <div><img src="$_v" onerror="this.error=null;$(this).parent().remove();" <!--{if $_v=='source/plugin/xigua_jy/static/suojie.png'}-->onclick="hb_jump('$SCRITPTNAME?id=xigua_jy&ac=my&do=vip');return false;"<!--{/if}--> /></div>
                </div>
                <!--{/loop}-->
            </div>
        </div>
    </div>
</div>
<div class="jlv_com">
    <h3 class="part-title">{lang xigua_jy:tdsp3}</h3>
    <div class="vehicle-file">
        <ul class="jzv_list cl"><li class="acti_jlcltags">
                <!--{loop $base_status0 $_v}-->
                <!--{if $v[$_v]}--><p class="bton">{if $base_status0_fix[$_v]}$base_status0_fix[$_v]{/if}{$v[$_v]}{if $base_status1_fix[$_v]}$base_status1_fix[$_v]{/if}</p><!--{/if}-->
                <!--{/loop}-->
                <!--{loop $base_status $_k $_v}-->
                <!--{if $v[$_k]}--><p class="bton">{if $base_status0_fix[$_k]}$base_status0_fix[$_k]{/if}{$v[$_k]}{if $base_status1_fix[$_k]}$base_status1_fix[$_k]{/if}</p><!--{/if}-->
                <!--{/loop}-->
            </li>
        </ul>
    </div>
</div>
<div class="jlv_com">
    <h3 class="part-title">{lang xigua_jy:xgah}</h3>
    <div class="vehicle-file">
        <ul class="jzv_list cl"><li class="acti_jlcltags">
                <!--{loop $xingge_aihao $_v}--><!--{if $v[$_v]}-->
                <!--{eval $_v_ary = array_filter(explode(',', $v[$_v]));}-->
                <!--{loop $_v_ary $__k $__v}-->
                <p>{if $base_status0_fix[$_v]}$base_status0_fix[$_v]{/if} $__v</p>
                <!--{/loop}-->
                <!--{/if}--><!--{/loop}-->
            </li>
        </ul>
    </div>
</div>
<!--{if $hasze}-->
<div class="jlv_com">
    <h3 class="part-title">{lang xigua_jy:zobz}</h3>
    <div class="vehicle-file">
        <ul class="jzv_list cl"><li class="acti_jlcltags"><!--{loop $zotj $_k $_v}-->
<!--{if $v[$_v]}--><p>{if $base_status0_fix[$_v]}$base_status0_fix[$_v]{/if}$v[$_v]</p><!--{/if}-->
<!--{/loop}-->
            <!--{if $v[y_note]}-->
            <p>{lang xigua_jy:y_note}: {$v[y_note]}</p>
            <!--{/if}-->
            </li>
        </ul>
    </div>
</div>
<!--{/if}-->

<!--{if !$iminblack}-->
<!--{if $jy_config[lxfs]}-->
<div class="jlv_com" style="margin-bottom:2rem">
    <h3 class="part-title">{lang xigua_jy:lxfs}</h3>
    <div class="vehicle-file f14">
        <!--{if $check_qx}-->
        <!--{if $v['status']==1}-->
        <ul>
            <li><em class="c3">{lang xigua_jy:mobile}:</em> {$v[mobile]}</li>
            <li><em class="c3">{lang xigua_jy:wxh}:</em> {$v[wx]}</li>
        </ul>
        <!--{else}-->
        {lang xigua_jy:duifa}
        <!--{/if}-->
        <!--{else}-->
        {lang xigua_jy:qxcgch}
        <!--{/if}-->
    </div>
</div>
<!--{/if}-->
<!--{if $jy_config['jydt']}-->
<div class="jlv_com" style="margin-bottom:2rem">
    <h3 class="part-title">TA{lang xigua_jy:ddt}</h3>
    <div>
        <div id="list" class="mod-post x-postlist p0"></div>
        <!--{template xigua_hb:loading}-->
    </div>
    <script>
        var loadingurl = _APPNAME+'?id=xigua_hb&ac=list_item&cat_id={$jy_config[jydt]}&orderby=new&uid=$v[uid]&inajax=1&page=';
    </script>
</div>
<!--{/if}-->
<div class="jyview_btm">
    <!--{if $gz}-->
    <a href="javascript:;" class="do_guanzhu" data-uid="{$v[uid]}">{lang xigua_jy:yiguanzhu}<em></em></a>
    <!--{else}-->
    <a href="javascript:;" class="do_guanzhu" data-uid="{$v[uid]}">{lang xigua_jy:guanzhu}<em></em></a>
    <!--{/if}-->
    <!--{if $check_qx}-->
    <a href="javascript:;" class="qianxian" data-uid="{$v[uid]}">{lang xigua_jy:qxcg}<em></em></a>
    <!--{else}-->
    <a href="javascript:;" class="qianxian doqx" data-uid="{$v[uid]}">{lang xigua_jy:qx}<em></em></a>
    <!--{/if}-->
</div>
<!--{/if}-->
</div>
<!--{/if}-->
<div>
    <!--{if $jy_config['jydt']}-->
    <a href="$SCRITPTNAME?id=xigua_jy" class="right_float view_rightbtn _home" style="bottom: 12rem;"></a>
    <a href="$SCRITPTNAME?id=xigua_jy&ac=dt&uid={$v[uid]}" class="right_float view_rightbtn _home" style="background-image:none;color: #fff;line-height: 2rem;bottom: 9.5rem;">
        <i class="iconfont icon-xiaoxi1 f22"></i>
    </a>
    <!--{else}-->
    <a href="$SCRITPTNAME?id=xigua_jy" class="right_float view_rightbtn _home"></a>
    <!--{/if}-->
    <!--{if (!$iminblack && $check_qx ) || DB::result_first("select * from %t where uid=%d", array('xigua_jy_hn', $_G['uid'])) }-->
    <a href="$SCRITPTNAME?id=xigua_jy&ac=chat&touid={$v[uid]}" class="right_float view_rightbtn _sixin"></a>
    <!--{elseif $nextid}-->
    <a href="$SCRITPTNAME?id=xigua_jy&ac=view&jyid=$nextid{$urlext}" class="right_float view_rightbtn _next"></a>
    <!--{/if}-->
</div>

<!--{eval $tabbar=0;$jy_tabbar=0;}-->
<!--{template xigua_jy:footer}-->
<script>
$('div.jyswipe').each(function () {
    dp_slider($(this), $(this).data('speed') || 3000)
});
var jy_seiper = null;
function dp_slider(_this, auto) {
    var bullets = _this.find('nav.bullets');
    var position = _this.find('ul.position');
    jy_seiper = new Swipe2(_this[0], {
        visibilityFullFit : true,
        startSlide: 0, speed: 500, auto: auto, continuous: true, callback: function (index) {
            if (bullets.length > 0) {
                bullets.find('em:first-child').text(index + 1);
            }
            if (position.length > 0) {
                var selectors = position[0].children;
                for (var t = 0; t < selectors.length; t++) {
                    selectors[t].className = selectors[t].className.replace("current", "");
                }
                if (typeof selectors[(index) % (selectors.length)] != 'undefined') {
                    selectors[(index) % (selectors.length)].className = "current";
                }
            }
            // var H = $(".swipe-wrap .swp").eq(index).height();
            // $('.jyswipe .swipe-wrap').css('height', H);
            // $('.jyswipe').css('height', H);
        }
    });
}
// var _H2 = $(".swipe-wrap .swp:first-child").height();
// $('.jyswipe .swipe-wrap').css('height', _H2);
// $('.jyswipe').css('height', _H2);

if ($('.album_swiper').length > 0) {
    var album_swiper = new Swiper('.album_swiper', {
        slidesPerView: 'auto',
        paginationClickable: true,
        spaceBetween: 0
    });
}
$(document).on('click', '.do_guanzhu', function () {
    var that = $(this);
    $.ajax({
        type: 'post', url: _APPNAME + '?id=xigua_jy&ac=my&do=do_guanzhu&inajax=1',
        data: {'formhash': FORMHASH, 'doid': that.attr('data-uid')}, dataType: 'xml', success: function (data) {
            $.hideLoading();
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        }
    });
});
<!--{if $showtipbase}-->
$.modal({
    title: '{lang xigua_jy:ts}',
    text: '<div style="margin: 1rem 0 0;line-height: 1.3rem;color: #666;">{lang xigua_jy:zc}</div><a class="jtip_btn main_bg" href="$SCRITPTNAME?id=xigua_jy&ac=my&do=base">{lang xigua_jy:ljws}</a>',
    buttons: [
        { text: "{lang xigua_jy:quxiao}", className: "default", onClick: function(){
            window.history.go(-1);
            hb_jump(_APPNAME+'?id=xigua_jy');
        } },
    ]
});
<!--{/if}-->
$(document).on('click','.doqx', function () {
    var that = $(this);
<!--{if $my_line_num>0}-->
$.confirm('{lang xigua_jy:qxcgh}', '{lang xigua_jy:qxqd}', function (){
$.ajax({
    type: 'post', url: _APPNAME + '?id=xigua_jy&ac=qianxian&do=first&inajax=1',
    data: {'formhash': FORMHASH, 'touid': that.attr('data-uid')}, dataType: 'xml', success: function (data) {
        $.hideLoading();
        if (null == data) {
            tip_common('error|' + ERROR_TIP);
            return false;
        }
        var s = data.lastChild.firstChild.nodeValue;
        tip_common(s);
    }
});
}, function (){});
<!--{else}-->
$.modal({
    title: '{lang xigua_jy:ts1}',
    text: '{lang xigua_jy:bq}' +
        '<a class="jtip_btn2 " href="$SCRITPTNAME?id=xigua_jy&ac=my&do=vip&backuid=$v[uid]">{lang xigua_jy:ktvip}<em class="iconfont icon-jinrujiantou f13"></em></a>'+
        '<a class="jtip_btn2 " href="$SCRITPTNAME?id=xigua_jy&ac=my&do=line&backuid=$v[uid]">{lang xigua_jy:gmqx}<em class="iconfont icon-jinrujiantou f13"></em></a>'+
        '<!--{if $jy_config[dcqx]}--><a class="jtip_btn2 oneline" data-uid="{$v[uid]}" href="javascript:;">{lang xigua_jy:gmdc} $jy_config[dcqx]{lang xigua_jy:yuan}/{lang xigua_jy:c}<em class="iconfont icon-jinrujiantou f13"></em></a><!--{/if}-->',
    buttons: [{ text: "{lang xigua_jy:quxiao}", className: "default", onClick: function(){ } }]
});
return false;
<!--{/if}-->
});
</script>