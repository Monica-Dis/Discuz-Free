<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="popup_sx" class="weui-popup__container z501"><!--{eval $keyword = $_GET['keyword'];}-->
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal fadeinright">
        <div class="toolbar" style="z-index:9">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup">{lang xigua_jy:quxiao}</a>
                <h1 class="title">{lang xigua_jy:atjss}</h1>
            </div>
        </div>
        <div class="modal-content">
            <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
                <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform" onsubmit="return false;">
                    <div class="weui-search-bar__box">
                        <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_jy:qtxsxfw}" data-hold="{lang xigua_jy:qtxsxfw}" required="required" data-name="keyword" value="$keyword">
                        <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
                    </div>
                    <label class="weui-search-bar__label" id="searchText">
                        <i class="weui-icon-search"></i>
                        <span>{lang xigua_jy:qtxsxfw}</span>
                    </label>
                </form>
                <a href="javascript:;" class="search_bar_btn main_color" id="dosearch">{lang xigua_jy:search}</a>
                <a href="javascript:;" class="weui-search-bar__cancel-btn qxsearch" style="color:#999!important;">{lang xigua_jy:quxiao}</a>
            </div>

            <div class="weui-cells before_none after_none" style="margin-bottom:3.75rem">
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_jy:gender}</p>
                        <ul class="check_box cl">
                            <li data-id="0" data-name="gender" data-only="0" <!--{if $dftgender==0}-->class="oncheck"<!--{/if}-->>{lang xigua_jy:buxian}</li>
                            <li data-id="1" data-name="gender" data-only="1" <!--{if $dftgender==1}-->class="oncheck"<!--{/if}-->>{lang xigua_jy:gender1}</li>
                            <li data-id="2" data-name="gender" data-only="1" <!--{if $dftgender==2}-->class="oncheck"<!--{/if}-->>{lang xigua_jy:gender2}</li>
                        </ul>
                    </div>
                </div>
                <!--{loop $biaozhun_status $__k $__v}-->
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">$__v[title_tip]</p>
                        <ul class="check_box cl">
                            <!--{loop $__v[data_ary] $_k $quan}-->
                            <li data-id="$_k" data-name="$__k" data-only="<!--{if in_array($__k, array('y_hunyin'))}-->1<!--{/if}-->">$quan</li>
                            <!--{/loop}-->
                        </ul>
                    </div>
                </div>
                <!--{/loop}-->

                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_jy:jiaxiang}</p>
                        <ul class="check_box cl filterjobwant">
                            <li data-id="-1" data-name="jiaxiang">{lang xigua_jy:buxian}</li>
                            <!--{loop $distjsary $quan}-->
                            <!--{eval $quanname = diconv($quan[name],'UTF-8',CHARSET);}-->
                            <li data-sub="_$quan[id]" data-id="$quanname" data-name="jiaxiang">{$quanname}</li>
                            <!--{/loop}-->
                        </ul>
                        <!--{loop $distjsary $quan}-->
                        <ul class="check_box cl check_box_sub subid__{$quan[id]}" style="display:none">
                            <li data-backto="$quan[id]"><i class="iconfont icon-fanhui f12"></i>{lang xigua_jy:back}</li>
                            <!--{loop $quan[sub] $_v}-->
                            <!--{eval $quanname = diconv($_v[name],'UTF-8',CHARSET);}-->
                            <li data-id="{$quanname}" data-name="jiaxiang">{$quanname}</li>
                            <!--{/loop}-->
                        </ul>
                        <!--{/loop}-->
                    </div>
                </div>
                <div class="weui-cell">
                    <div class="weui-cell__bd">
                        <p class="list3C">{lang xigua_jy:gongzuodi}</p>
                        <ul class="check_box cl filterjobwant">
                            <li data-id="-1" data-name="gongzuodi">{lang xigua_jy:buxian}</li>
                            <!--{loop $distjsary $quan}-->
                            <!--{eval $quanname = diconv($quan[name],'UTF-8',CHARSET);}-->
                            <li data-sub="_$quan[id]" data-id="$quanname" data-name="gongzuodi">{$quanname}</li>
                            <!--{/loop}-->
                        </ul>
                        <!--{loop $distjsary $quan}-->
                        <ul class="check_box cl check_box_sub subid__{$quan[id]}" style="display:none">
                            <li data-backto="$quan[id]"><i class="iconfont icon-fanhui f12"></i>{lang xigua_jy:back}</li>
                            <!--{loop $quan[sub] $_v}-->
                            <!--{eval $quanname = diconv($_v[name],'UTF-8',CHARSET);}-->
                            <li data-id="{$quanname}" data-name="gongzuodi">{$quanname}</li>
                            <!--{/loop}-->
                        </ul>
                        <!--{/loop}-->
                    </div>
                </div>
            </div>
            <div class="fix-bottom sxbtns sxbtns2 cl">
                <div class="oncheck none" data-name="ac" data-id="mem_li"></div>
                <input type="button" href="javascript:;" class="weui-btn weui-btn_default close-reset" value="{lang xigua_jy:cz}">
                <input type="button" href="javascript:;" class="weui-btn weui-btn_primary confirm-filter" value="{lang xigua_jy:queding}">
            </div>
        </div>
    </div>
</div>