<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $_GET['do']=='vip'}-->
<div class="bgf cl">
    <div class="c3 top_tip tl" style="background:$bgfc">
        <div class="cl taocan_card">
            <div class="z">
                <img src="{$avatar}" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'" />
            </div>
            <div class="z">
                <h3>{lang xigua_jy:ktvip2}</h3>
                <!--{if $user[vip_endts_day]}-->
                <p class="card_date" style="background-color:$bgfc8">{lang xigua_jy:yxq} {$user[vip_endts_day]}</p>
                <!--{else}-->
                <p class="card_date" style="background-color:$bgfc8">{lang xigua_jy:wkt}</p>
                <!--{/if}-->
            </div>
        </div>
    </div>
</div>
<!--{elseif $_GET['do']=='qianxian'}-->
<a class="tcnav tcnav_col" href="$SCRITPTNAME?id=xigua_jy&ac=my&do=vip">
    <!--{if $user[is_vip]}-->
    <div class="tcnav_top cl f14">
        <div class="cl">
            <p class="on vip_icon">{$user[vip_name]}<i class="iconfont icon-jinrujiantou "></i></p>
            <div class="vip_sec">{lang xigua_jy:yxq}{$user[vip_endts_day]}</div>
        </div>
    </div>
    <!--{else}-->
    <div class="tcnav_top off_top cl f14">
        <div class="off vip_icon">{lang xigua_jy:ktvip3}<i class="iconfont icon-jinrujiantou "></i></div>
        <div class="vip_sec">{lang xigua_jy:mfzsqx}</div>
    </div>
    <!--{/if}-->
</a>
<a class="tcnav tcnav_col" href="$SCRITPTNAME?id=xigua_jy&ac=my&do=line">
    <div class="tcnav_top cl f14">
        <div class="cl">
            <p class="on vip_icon qx_icon">{lang xigua_jy:qxfwtc}<i class="iconfont icon-jinrujiantou "></i></p>
            <div class="vip_sec">{lang xigua_jy:gmtcxyh}</div>
        </div>
    </div>
</a>
<!--{else}-->
<div class="tcnav">
    <!--{if $user[is_vip]}-->
    <div class="tcnav_top cl f14">
        <div class="cl">
            <p class="on vip_icon">{lang xigua_jy:ns}{$user[vip_name]}{lang xigua_jy:ddljxq}<i class="iconfont icon-jinrujiantou "></i></p>
            <div class="vip_sec">{lang xigua_jy:yxq} {$user[vip_endts_day]}</div>
        </div>
    </div>
    <!--{else}-->
    <div class="tcnav_top off_top cl f14">
        <div class="off vip_icon">{lang xigua_jy:hmkt}<i class="iconfont icon-jinrujiantou "></i></div>
        <div class="vip_sec">{lang xigua_jy:ktyz}</div>
    </div>
    <!--{/if}-->
</div>
<!--{/if}-->