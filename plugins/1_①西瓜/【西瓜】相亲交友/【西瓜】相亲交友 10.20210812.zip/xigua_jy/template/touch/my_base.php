<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_jy:header}--><style>.weui-input,.weui-textarea,.weui-uploader__title,.weui-label{font-size:.75rem}</style>
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<form  action="$SCRITPTNAME?id=xigua_jy&ac=my&do=base&st={$_GET['st']}" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <input name="form[stid]" value="{echo $old_data[stid]?$old_data[stid]:$_GET['st']}" type="hidden">
    <div class="page__bd bgf">
        <!--{template xigua_hb:common_nav}-->
        <div class="cl">
            <div class="main_color top_tip" style="background:$bgfc">{lang xigua_jy:wszl}
<!--{if $old_data[shows]==-3 && $old_data[reson]}--><p>{lang xigua_jy:reson}:$old_data[reson]</p><!--{/if}-->
            </div>
            <div class="change_mpava">
                <div class="change_avatar">
                    <div id="box_avatar">
                        <ul class="weui-uploader__files" data-only="1" data-max="0" data-maxtip="{lang xigua_jy:zdyz}"><!--{if $old_data[avatar]}-->
                            <div class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[avatar])"><input type="hidden" name="form[avatar][]" value="$old_data[avatar]"/></div>
                            <!--{/if}-->
                        </ul>
                        <div class="box_border">
                            <!--{if HB_INWECHAT && $config[multiupload]}-->
                            <a class="weui-uploader__input" data-name="form[avatar]" data-boxer="box_avatar" data-only="1" data-multi="0" type="file"></a>
                            <!--{else}-->
                            <input class="weui-uploader__input" data-name="form[avatar]" data-boxer="box_avatar" data-only="1" data-multi="0" type="file">
                            <!--{/if}-->
                        </div>
                    </div>
                    <p class="f14 mt2 c3">{lang xigua_jy:djsc}</p>
                </div>
            </div>
        </div>
        <div class="weui-cells weui-cells_form mt0 before_none after_none">
            <div class="weui-cell ">
                <div class="weui-cell__bd">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">{lang xigua_jy:note}</p>
                    </div>
                    <textarea name="form[note]" class="weui-textarea texta mt0" placeholder="{lang xigua_jy:note_tip}" rows="3">{$old_data[note]}</textarea>
                </div>
            </div>
            <div class="weui-cell ">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:nickname}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[nickname]" type="text" value="{$old_data[nickname]}" placeholder="{lang xigua_jy:qtx}{lang xigua_jy:nickname}">
                </div>
            </div>
            <div class="weui-cell ">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:gender}</label></div>
                <div class="weui-cell__bd c9 f14">{lang xigua_jy:bxznyc}</div>
                <div class="cl weui-cells_radio">
                    <!--{if !$old_data[gender]}-->
                    <label class="z weui-check__label mr10" for="x11">
                        <input type="radio" class="weui-check" name="form[gender]" value="1" id="x11" <!--{if $old_data[gender]==1}-->checked<!--{/if}-->><span class="weui-icon-checked"></span>{lang xigua_jy:gender1}</label>
                    <label class="z weui-check__label" for="x12">
                        <input type="radio" class="weui-check" name="form[gender]" value="2" id="x12" <!--{if $old_data[gender]==2}-->checked<!--{/if}-->><span class="weui-icon-checked"></span>{lang xigua_jy:gender2}</label>
                    <!--{else}-->
                    <div class="post-tags cl">
                        <a class="weui-btn weui-btn_mini weui-btn_default mb0 <!--{if $old_data[gender]==1}-->tag-on<!--{/if}-->" href="javascript:;">{lang xigua_jy:gender1}</a>
                        <a class="weui-btn weui-btn_mini weui-btn_default mb0 <!--{if $old_data[gender]==2}-->tag-on<!--{/if}-->" href="javascript:;">{lang xigua_jy:gender2}</a>
                    </div>
                    <!--{/if}-->
                </div>
            </div>
            <!--{if $jy_config['mustmobile']}-->
            <div class="weui-cell weui-cell_access" >
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:mobile}</label></div>
                <div class="weui-cell__bd f15 c9">{$qianbao[mobile]}</div>
                <div class="weui-cell__ft c9" style="font-size:.75rem!important;"><a href="$changemobile">{echo $qianbao[mobile] ? lang_jy('xg',0):lang_jy('bd',0)}</a></div>
            </div>
            <!--{else}-->
            <div class="weui-cell" >
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:mobile}</label></div>
                <div class="weui-cell__bd f15 c9">
                    <input class="weui-input" name="form[mobile]" type="text" value="{echo $old_data['mobile']?$old_data['mobile']: $qianbao[mobile]}" placeholder="{lang xigua_jy:qtxsjh}">
                </div>
            </div>
            <!--{/if}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:wxh}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[wx]" id="qiustatus" type="text" value="{$old_data[wx]}" placeholder="{lang xigua_jy:qtxwxh}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:sr}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" readonly name="form[birthday]" id="birthday" type="text" value="{$old_data[birthday_str]}" placeholder="{lang xigua_jy:qxz}{lang xigua_jy:sr}">
                </div>
            </div>
            <div class="weui-cell <!--{if in_array('y_shengao', $hidety)}-->none<!--{/if}-->">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:shengao}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" readonly name="form[shengao]" id="shengao" type="text" value="{$old_data[shengao]}" placeholder="{lang xigua_jy:qxz}{lang xigua_jy:shengao}">
                </div>
            </div>
            <div class="weui-cell <!--{if in_array('y_tizhong', $hidety)}-->none<!--{/if}-->">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:tizhong}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" readonly name="form[tizhong]" id="tizhong" type="text" value="{$old_data[tizhong]}" placeholder="{lang xigua_jy:qxz}{lang xigua_jy:tizhong}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:jiaxiang}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" readonly name="form[jiaxiang]" id="jiaxiang" type="text" value="{$old_data[jiaxiang]}" placeholder="{lang xigua_jy:qxz}{lang xigua_jy:jiaxiang}">
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_jy:gongzuodi}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" readonly name="form[gongzuodi]" id="gongzuodi" type="text" value="{$old_data[gongzuodi]}" placeholder="{lang xigua_jy:qxz}{lang xigua_jy:gongzuodi}">
                </div>
            </div>
            <!--{loop $base_status $_k $_v}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">$_v[title]</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" readonly name="form[$_k]" id="$_k" type="text" value="{$old_data[$_k]}" placeholder="$_v[title_tip]">
                </div>
            </div>
            <!--{/loop}-->

            <!--{template xigua_jy:choseconfig}-->

        </div>

        <div class="bottom_fix"></div>
        <div class="fix-bottom mt10">
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_jy:save}">
        </div>
    </div>
    <div id="popctrl" class="weui-popup__container" style="z-index:1001">
        <div class="weui-popup__modal">
            <div style="height: 100vh"><img id="photo"></div>
            <div class="pub_funcbar">
                <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
                <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
            </div>
        </div>
    </div>
</form>

<!--{template xigua_hb:enter_up}-->
<!--{eval $jy_tabbar=0;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/picker.js?_{VERHASH}" charset="utf-8"></script>
<script>+function($){$.rawCitiesData = $cityjson;}($);</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/city-picker.js?{VERHASH}" charset="utf-8"></script>
<script>$("#birthday").calendar({value:['{$old_data[birthday]}'],dateFormat:'{lang xigua_jy:datefomat}'});

$("#shengao").picker({title: "{lang xigua_jy:qxz}{lang xigua_jy:shengao}",cols: [{textAlign: 'center',values: [$cms]}]});
$("#tizhong").picker({title: "{lang xigua_jy:qxz}{lang xigua_jy:tizhong}",cols: [{textAlign: 'center',values: [$tizhongs]}]});
$("#jiaxiang").cityPicker({title: "{lang xigua_jy:qxz}{lang xigua_jy:jiaxiang}"});
$("#gongzuodi").cityPicker({title: "{lang xigua_jy:qxz}{lang xigua_jy:gongzuodi}"});
<!--{loop $base_status $_k $_v}-->
$("#$_k").picker({title: "$_v[title_tip]",cols: [{textAlign: 'center',values: [ $_v[data] ]}]});
<!--{/loop}-->


</script>