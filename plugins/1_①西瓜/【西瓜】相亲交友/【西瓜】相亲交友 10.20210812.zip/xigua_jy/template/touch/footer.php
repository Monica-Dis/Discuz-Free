<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_jy:tabbar}-->
<script src="source/plugin/xigua_jy/static/jy.js?{VERHASH}5"></script>
<!--{template xigua_hb:common_footer}-->