<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_jy:header}--><link rel="stylesheet" href="source/plugin/xigua_jy/static/line.css" />
<link rel="stylesheet" href="source/plugin/xigua_hb/static/css/mynew.css?{VERHASH}" /><style>.car-type .car-year-season{background-color:$config[maincolor];}.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}.car-type .type-item-active:after{border-color:$config[maincolor]}.car-type .type-item-active {background:$bgfc}html,body{background:#fff}.x_header_fix{height:0}.x_header {background: transparent!important;position: absolute;}
.my_new_bd .my__head_new.myjy2{margin-bottom: 0;height: 4.5rem;padding-top: 2rem;}.weui-cells__title {color: #333;font-size: .8rem;font-weight: 500;}</style><div class="page__bd my_new_bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="do_bd">
        <div class="my__head_new <!--{if $user[gender]==2}-->main_bg<!--{/if}--> myjy myjy2">
            <!--{template xigua_jy:svg}-->
            <div class="my__head_wap block">
                <div class="my__head_user z">
                    <a href="$SCRITPTNAME?id=xigua_member:profile" class="my__head_avatar z"><img src="$avatar" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/icon.png'" ></a>
                    <div>
                        <div class="my__head_nickname f16">{$user[nickname]} <em class="f12 op6">ID: {$_G[uid]}</em></div>
                        <a href="javascript:;" class="qblink">{lang xigua_jy:syqxcs}: {$my_line_num}</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="tcouter tcouter_col"><!--{template xigua_jy:tcard}--></div>
    </div>

<!--{if $list_me}-->
    <div class="weui-cells__title">{lang xigua_jy:xhwqxdr}</div>
    <div id="list" class="mod-post x-postlist p0 qxing_list">
        <!--{if $list=$list_me}-->
        <!--{eval $qxlist = $qxlist_me;$isme=1;}-->
        <!--{subtemplate xigua_jy:mem_li}-->
        <!--{else}-->
        <p style="background: #fff;padding: .75rem;color: #999;">{lang xigua_jy:zwxhwqxdr}</p>
        <!--{/if}-->
    </div>
<!--{/if}-->

    <div class="weui-cells__title">{lang xigua_jy:sqqxjl}</div>
    <div id="list" class="mod-post x-postlist p0 qxing_list">
        <!--{if $list=$list_other}-->
        <!--{eval $qxlist = $qxlist_other;$isme=0;}-->
        <!--{subtemplate xigua_jy:mem_li}-->
        <!--{else}-->
        <p style="background: #fff;padding: .75rem;color: #999;">{lang xigua_jy:zw}{lang xigua_jy:sqqxjl}</p>
        <!--{/if}-->
    </div>
    <div class="weui-cells__title">{$lang_qianxian}{lang xigua_jy:sm}</div>
    <!--{if $vipshuoming[$lang_qianxian]}-->
    <div class="weui-cells__tips mt10 vip_sm">
        <div class="vip_sm_desc">
            {$vipshuoming[$lang_qianxian]['content']}
        </div>
    </div>
    <!--{/if}-->
    <div class="footer_fix"></div>
    <div class="bottom_fix"></div>
</div>
<script>
</script>
<!--{eval $jy_tabbar=1;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->
<script>
    $(document).on('click','.qxconfirm', function () {
        var that = $(this);
        $.confirm({
            title: '{lang xigua_jy:ts1}',
            text: that.data('agree')?'{lang xigua_jy:qdqx1}':'{lang xigua_jy:qdqx2}',
            onOK: function () {$.showLoading();
                $.ajax({
                    type: 'post',
                    url: '$SCRITPTNAME?id=xigua_jy&ac=qianxian&do=confirm&inajax=1',
                    data:{'formhash':'{FORMHASH}', 'fromuid': that.data('fromuid'), 'agree': that.data('agree'), 'qxid' : that.data('qxid')},
                    dataType: 'xml',
                    success: function (data) {
                        $.hideLoading();
                        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    },
                    error: function () {
                        $.hideLoading();
                    }
                });
            }
        });
    });
</script>