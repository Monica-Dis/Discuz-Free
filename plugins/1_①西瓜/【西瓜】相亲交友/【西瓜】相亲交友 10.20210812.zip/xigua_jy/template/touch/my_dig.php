<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_jy:header}--><link rel="stylesheet" href="source/plugin/xigua_jy/static/line.css" /><style>.car-type .car-year-season{background-color:$config[maincolor];}.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}.car-type .type-item-active:after{border-color:$config[maincolor]}.car-type .type-item-active {background:$bgfc}</style><div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-cells weui-cells_checkbox mt0 border_none">
        <form action="$SCRITPTNAME?id=xigua_jy&ac=my&do=dig" method="post" id="form" enctype="multipart/form-data">
            <input type="hidden" name="formhash" value="{FORMHASH}">
            <div class="cl car-type" style="padding-bottom:0">
                <div class="type-item-box cl twocol" style="display:block">
                    <!--{loop $digtaocan $k $v}-->
                    <label for="s{$v[id]}" data-endays="{$v[endays]}" class="type-item J_ping <!--{if $k==0}-->type-item-active<!--{else}-->type-item-gray<!--{/if}-->">
                        <input type="radio" class="none typevip" name="form[viptype]" value="{$v[id]}" id="s{$v[id]}" <!--{if $k==0}-->checked="checked"<!--{/if}--> >
                        <div class="type-title f16 ">
                            <div>{lang xigua_jy:dig} <em class="color-red2">{$v[times]}</em> {lang xigua_jy:d}</div>
                        </div>
                        <div class="mt4">
                            <em class="f14 color-red2">&yen;</em>
                            <em class="f24 color-red2 mr10">$v[id]</em>
                        </div>
                        <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
                    </label>
                    <!--{/loop}-->
                </div>
            </div>
            <div class="fix-bottom">
                <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hb:ljgm}">
            </div>
        </form>
    </div>
    <div class="weui-cells__tips mt10">
        <div> <i class="iconfont icon-jubao main_color"></i> {lang xigua_jy:yxpx} </div>
    </div>
</div>
<script>
    $(document).on('click', '.J_ping', function () {
        $('.J_ping').addClass('type-item-gray').removeClass('type-item-active');
        $(this).addClass('type-item-active').removeClass('type-item-gray');
        if($(this).data('endays')){
            $('#yxq').html($(this).data('endays'));
        }
    });
    $('.J_ping:first-child').trigger('click');$('.J_ping:first-child').find('.typevip').trigger('click');
</script>
<!--{eval $jy_tabbar=0;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->