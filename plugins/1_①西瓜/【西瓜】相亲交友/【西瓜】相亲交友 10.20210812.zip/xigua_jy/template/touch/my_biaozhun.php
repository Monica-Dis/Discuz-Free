<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_jy:header}--><style>.weui-input,.weui-textarea,.weui-uploader__title,.weui-label{font-size:.75rem}</style>
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}">
<form  action="$SCRITPTNAME?id=xigua_jy&ac=my&do=biaozhun&st={$_GET['st']}" method="post" id="form">
    <input type="hidden" name="formhash" value="{FORMHASH}">
    <input name="form[stid]" value="{echo $old_data[stid]?$old_data[stid]:$_GET['st']}" type="hidden">
    <div class="page__bd bgf">
        <!--{template xigua_hb:common_nav}-->
        <div class=" cl">
            <div class="main_color top_tip" style="background:$bgfc">{lang xigua_jy:szxmzd}</div>
        </div>
        <div class="weui-cells weui-cells_form mt0 before_none after_none">
            <!--{loop $biaozhun_status $_k $_v}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">$_v[title]</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" readonly name="form[$_k]" id="$_k" type="text" value="{echo $old_data[$_k] ? $old_data[$_k] : $_v[data_ary][0]}" placeholder="$_v[title_tip]">
                </div>
            </div>
            <!--{/loop}-->
            <div class="weui-cell ">
                <div class="weui-cell__bd">
                    <div class="weui-uploader__hd">
                        <p class="weui-uploader__title">{lang xigua_jy:y_note}</p>
                    </div>
                    <textarea name="form[y_note]" class="weui-textarea texta mt0" placeholder="{lang xigua_jy:y_note_tip}" rows="3">{$old_data[y_note]}</textarea>
                </div>
            </div>
        </div>
        <div class="fix-bottom mt10">
            <input type="submit" id="dosubmit" class="weui-btn weui-btn_primary" value="{lang xigua_jy:save}">
        </div>
    </div>
    <div id="popctrl" class="weui-popup__container" style="z-index:1001">
        <div class="weui-popup__modal">
            <div style="height: 100vh"><img id="photo"></div>
            <div class="pub_funcbar">
                <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
                <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
            </div>
        </div>
    </div>
</form>
<!--{template xigua_hb:enter_up}-->
<!--{eval $jy_tabbar=0;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->
<script><!--{loop $biaozhun_status $_k $_v}-->
<!--{if $_v[type]=='multi'}-->
$("#$_k").select({title: "$_v[title_tip]",multi: true,items: [ $_v[data] ]});
<!--{else}-->
$("#$_k").picker({title: "$_v[title_tip]",cols: [{textAlign: 'center',values: [ $_v[data] ]}]});
<!--{/if}-->
<!--{/loop}--></script>