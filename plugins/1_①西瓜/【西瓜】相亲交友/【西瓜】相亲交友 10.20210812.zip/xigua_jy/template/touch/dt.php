<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_jy:header}-->
<div class="page__bd">
<style> .content-bottom {padding:.5rem 1.5rem;display: -webkit-flex;display: flex;-webkit-justify-content: space-between;justify-content: space-between;
background:#fff;}.content-bottom .menu-item {position: relative;margin-top: .5rem;display: -webkit-flex;display: flex;-webkit-flex-direction: column;
flex-direction: column;-webkit-align-items: center;align-items: center;}
.content-bottom .menu-img {overflow: hidden;position: relative;font-size: 0;
width:2rem;height:2rem;display: block;margin-bottom:.5rem;}.taro-img__mode-scaletofill {
width: 100%;height: 100%;}.content-bottom .menu-text {font-size: .7rem;color: #333;letter-spacing: 0;text-align: center;line-height:1.4;}
</style>
    <!--{template xigua_hb:common_nav}-->
    <div class="content-bottom">
        <a href="$SCRITPTNAME?id=xigua_jy&ac=dt&cat_id=$cat_id&orderby=new{$urlext}" class="menu-item">
            <div class="taro-img menu-img">
                <img class="taro-img__mode-scaletofill" src="source/plugin/xigua_jy/static/dt/1.png">
            </div>
            <span class="menu-text <!--{if $orderby=='new'}-->checked main_color<!--{/if}--> ">{lang xigua_jy:orderby_new}</span></a>
        <a href="$SCRITPTNAME?id=xigua_jy&ac=dt&cat_id=$cat_id&orderby=hot{$urlext}" class="menu-item">
            <div class="taro-img menu-img">
                <img class="taro-img__mode-scaletofill" src="source/plugin/xigua_jy/static/dt/3.png">
            </div>
            <span class="menu-text <!--{if $orderby=='hot'}-->checked main_color<!--{/if}-->  ">{lang xigua_jy:orderby_hot}</span></a>
        <a href="$SCRITPTNAME?id=xigua_jy&ac=dt&cat_id=$cat_id&orderby=guanzhu{$urlext}" class="menu-item">
            <div class="taro-img menu-img">
                <img class="taro-img__mode-scaletofill" src="source/plugin/xigua_jy/static/dt/4.png">
            </div>
            <span class="menu-text <!--{if $orderby=='guanzhu'&&!$uid}-->checked main_color<!--{/if}--> ">{lang xigua_jy:orderby_guanzhu}</span></a>
    </div>

    <div id="list" class="mod-post x-postlist pt0"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>
    var loadingurl = _APPNAME+'?id=xigua_hb&ac=list_item&cat_id=$cat_id&orderby=$orderby&uid=$uid&inajax=1&page=';
</script>
<!--{eval $jy_tabbar=1;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->