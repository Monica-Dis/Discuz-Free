<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{loop $list $k $v}-->
<div class="memli_li memli_jump cl border_bfull" data-id="$v[uid]">
    <div class="memli_left">
        <div class="memli_logo"><img src="$v[avatar]" style="border-radius:{$jy_config[yuanjiao]}rem" onerror="this.error=null;this.src='source/plugin/xigua_jy/static/img/dftava.png'">
        <!--{if $v[istd]}--><div class="has_td main_color">{lang xigua_jy:ytt}</div><!--{/if}-->
        </div>
        <!--{if $v[is_dig]}-->
        <span class="jbtn is_dig is_vip">{lang xigua_jy:dig}</span>
        <!--{/if}-->
        <i class="memli_gender g{$v[gender]}"></i>
    </div>
    <div class="memli_right">
        <div class="memli_realname cl">
            <span>{$v[nickname]}</span>
            <!--{if $v[is_vip]||$v[verify]}--><span class="jbtn pr-1">
<!--{if $v[is_vip]}--><img class="rzimg2" src="{$v[vip_icon]}?{VERHASH}"><!--{/if}--><!--{if $v[verify]}--><!--{if $_G[cache][plugin][xigua_hr][grtb]}--><img class="rzimg2" src="$_G[cache][plugin][xigua_hr][grtb]" /> <!--{else}--><img class="rzimg2" src="source/plugin/xigua_jy/static/img/sm.png?{VERHASH}" /><!--{/if}-->
                <!--{/if}-->
</span><!--{/if}-->
            <div class="memli_span memli_span_pos">
                <!--{if $extlist[$v[uid]]}--><span class="memli_spani">{$extlist[$v[uid]][crts_u]}</span><!--{else}-->
                <!--{if $v[gongzuodi_ary][$citylevel]}--><span class="memli_spani">{$v[gongzuodi_ary][$citylevel]}</span><!--{/if}-->
                <!--{if $v[age]}--><span class="memli_spani">{$v[age]}</span><!--{/if}-->
                <!--{/if}-->
            </div>
        </div>
        <div class="memli_shortag cl">
            <a class="bton">{$v[age]}</a>
            <!--{if $v[zhiye]}-->
            <a class="bton">{$v[zhiye]}</a>
            <!--{elseif $v[shuxiang]}-->
            <a class="bton">{$base_status0_fix[shuxiang]}{$v[shuxiang]}</a>
            <!--{/if}-->
            <!--{if $v[zhiye]}-->
            <a class="bton">{$v[shengao]}{$base_status1_fix[shengao]}</a>
            <!--{elseif $v[xingzuo]}-->
            <a class="bton">{$v[xingzuo]}</a>
            <!--{/if}-->
        </div>
        <div class="memli_note">
            <p>{$v[note]}</p>
        </div>
        <a class="jy_li_link"> <i class="iconfont icon-jinlingyingcaiwangtubiao44"></i> {lang xigua_jy:qx}</a>
    </div>
</div>
<!--{/loop}-->