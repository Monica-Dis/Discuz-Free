<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{loop $list $_k $v}-->
<!--{if strpos($v['comment'], '|/|')!==false}-->
<!--{eval list($_img, $_link, $_title, $_description, $_price) = explode('|/|', trim($v['comment']));}-->
<li class="consult_cell">
    <time class="date-talk" style="margin-bottom:.5rem">{$v['crts_u']}</time>
    <a href="{$_link}">
        <div class="chat___goodsCard">
            <!--{if $_img}-->
            <div class="taro_img"><img src="$_img"></div>
            <!--{/if}-->
            <div class="chat___goodsInfo___2DueR">
                <div class="chat___name___10ZSG" >$_title</div>
                <!--{if $_price}--><div class="chat___price___2AE1P" >$_price</div><!--{/if}-->
                <div class="chat___hosName___jk80L" >$_description</div>
                <div class="chat___reserveBtn___2Fq9t">{eval echo lang('space', 'click_view')}</div>
            </div>
        </div></a>
</li>
<!--{else}-->
<!--{if strpos($v['comment'], 'https://')!==false||strpos($v['comment'], 'http://')!==false}-->
<!--{eval $v['comment'] .= " <a class=a href='". str_replace('"','', strip_tags($v['comment'])) ."'>".lang('space', 'click_view')."</a>";}-->
<!--{/if}-->
<li class="talk-li">
    <time class="date-talk {$v['who']}-date">{$v['crts_u']}</time>
    <section class="{$v['who']}-talk">
        <a class="avatar-talk" href="$SCRITPTNAME?id=xigua_hb&ac=member&uid={$v['authorid']}"><img src="{$v['avatar']}"></a>
        <div class="content-talk content-wb"><p>{$v['comment']}</p></div>
    </section>
</li>
<!--{/if}-->
<!--{/loop}-->