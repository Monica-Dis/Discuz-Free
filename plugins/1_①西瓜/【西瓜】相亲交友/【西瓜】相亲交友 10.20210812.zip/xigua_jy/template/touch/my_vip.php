<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_jy:header}--><link rel="stylesheet" href="source/plugin/xigua_jy/static/line.css" /><style>html,body{background:#fff}.car-type .car-year-season{background-color:$config[maincolor];}.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}.car-type .type-item-active:after{border-color:$config[maincolor]}.car-type .type-item-active {background:$bgfc}
.weui-cells__title {color: #333;font-size: .8rem;font-weight: 500;}
</style><div class="page__bd">
<!--{template xigua_hb:common_nav}-->
<!--{template xigua_jy:tcard}-->
<div class="weui-cells__title">
        {lang xigua_jy:xzvip}
    </div>
    <div class="weui-cells weui-cells_checkbox mt0 border_none">
        <form action="$SCRITPTNAME?id=xigua_jy&ac=my&do=vip" method="post" id="form" enctype="multipart/form-data">
            <input type="hidden" name="formhash" value="{FORMHASH}">
            <input type="hidden" name="backuid" value="{$_GET['backuid']}">
            <div class="cl car-type">
                <div class="type-item-box cl" style="display:block">
                    <!--{loop $vip_taocan $k $v}-->
                    <label style="height:4rem" for="s{$v[id]}" class="type-item J_ping <!--{if $k==0}-->type-item-active<!--{else}-->type-item-gray<!--{/if}-->">
                        <input type="radio" class="none typevip" name="form[viptype]" value="{$v[id]}" id="s{$v[id]}" <!--{if $k==0}-->checked="checked"<!--{/if}--> >
                        <div class="f16 vip_icon on">
                            <b>$v[name]</b>
                        </div>
                        <div class="vip_price color-red2">
                            <em class="f14 ">&yen;</em>
                            <em class="f30 ">$v[price]</em>
                        </div>
                        <div class="mt3 cl">
                            <span class="taocan_desc f14">{$v[desc]}</span>
                        </div>
                        <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
                    </label>
                    <!--{/loop}-->
                </div>
            </div>
            <div class="fix-bottom">
                <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hb:ljgm}">
            </div>
        </form>
    </div>
    <div class="weui-cells__title">{lang xigua_jy:viptip}</div>
    <!--{loop $vip_taocan $k $v}-->
    <!--{if $vipshuoming[$v[name]]['content']}-->
    <div class="weui-cells__tips mt10 vip_sm">
        <div class="vip_sm_desc">
            <div class="h5">{$v[name]}</div>
            {$vipshuoming[$v[name]]['content']}
        </div>
    </div>
    <!--{/if}-->
    <!--{/loop}-->

    <div class="weui-cells__title">{$lang_qianxian}{lang xigua_jy:sm}</div>
    <!--{if $vipshuoming[$lang_qianxian]}-->
    <div class="weui-cells__tips mt10 vip_sm">
        <div class="vip_sm_desc">
            {$vipshuoming[$lang_qianxian]['content']}
        </div>
    </div>
    <!--{/if}-->

    <div class="footer_fix"></div>
    <div class="bottom_fix"></div>
</div>
<script>
$(document).on('click', '.J_ping', function () {
    $('.J_ping').addClass('type-item-gray').removeClass('type-item-active');
    $(this).addClass('type-item-active').removeClass('type-item-gray');
});
$('.J_ping:first-child').trigger('click');$('.J_ping:first-child').find('.typevip').trigger('click');
</script>
<!--{eval $jy_tabbar=0;$tabbar=0;}-->
<!--{template xigua_jy:footer}-->