<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2020/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$xq_status = array(
    '-2' => array('title' => lang_jy('xq_sattus_2', 0), 'desc' => lang_jy('xq_sattus_2_tip', 0),),
    '-1' => array('title' => lang_jy('xq_sattus_1', 0), 'desc' => lang_jy('xq_sattus_1_tip', 0),),
    '1' => array('title' => lang_jy('xq_sattus1', 0), 'desc' => lang_jy('xq_sattus1_tip', 0),),
    '2' => array('title' => lang_jy('xq_sattus2', 0), 'isvip' => lang_jy('xq_sattus2_isvip', 0), 'desc' => lang_jy('xq_sattus2_tip', 0),),
);
$qianxian_status = array(
    '-2' => lang_jy('qianxian_status_2',0),
    '-1' => lang_jy('qianxian_status_1',0),
    '1' => lang_jy('qianxian_status1',0),
    '2' => lang_jy('qianxian_status2',0),
);

$cms = $shengao_ary = array();
for($cm=140; $cm <=230; $cm++){
    $cms[] = '\''.$cm.'cm\'';
    $shengao_ary[$cm] = $cm.'cm';
}
$cms = implode(',', $cms);

$tza  = $tizhong_ary= array();
for($ti=40; $ti <=120; $ti++){
    $tza[] = '\''.$ti.'kg\'';
    $tizhong_ary[$ti] = $ti.'kg';
}
$tizhongs = implode(',', $tza);

$jtqk = array(
    lang_jy('dszn',0),
    '2'.lang_jy('g',0),
    '3'.lang_jy('g',0),
    '4'.lang_jy('g',0),
    '5'.lang_jy('g',0),
    '6'.lang_jy('g',0),
    '7'.lang_jy('g',0),
    '8'.lang_jy('g',0),
);
$xueli = array(
    lang_jy('xueli8',0),
    lang_jy('xueli1',0),
    lang_jy('xueli2',0),
    lang_jy('xueli3',0),
    lang_jy('xueli5',0),
    lang_jy('xueli6',0),
    lang_jy('xueli7',0),
);
$hunyin = array(
     lang_jy('hunyin1',0),
     lang_jy('hunyin2',0),
     lang_jy('hunyin3',0),
     lang_jy('hunyin4',0),
);
$zhiye = array_filter(explode("\n", trim($jy_config['zhiy'])));
foreach ($zhiye as $index => $item) {
    $zhiye[$index] = trim($item);
}

$shouru = array(
    lang_jy('xinzi1',0),
    lang_jy('xinzi2',0),
    lang_jy('xinzi4',0),
    lang_jy('xinzi5',0),
    lang_jy('xinzi6',0),
    lang_jy('xinzi7',0),
    lang_jy('xinzi8',0),
    lang_jy('xinzi9',0),
);
$goufang = array(
    lang_jy('gf1',0),
    lang_jy('gf2',0),
    lang_jy('gf3',0),
    lang_jy('gf4',0),
    lang_jy('gf5',0),
);
$gouche = array(
    lang_jy('gc1',0),
    lang_jy('gc2',0),
    lang_jy('gc3',0),
);
$xiyan = array(
    lang_jy('cy1',0),
    lang_jy('cy2',0),
    lang_jy('cy3',0),
);
$hejiu = array(
    lang_jy('hj1',0),
    lang_jy('hj2',0),
    lang_jy('hj3',0),
    lang_jy('hj4',0),
);

$base_status = array(
    'xueli' => array(
        'title' => lang_jy('xl',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('xl',0),
        'data' => '\'' . implode('\',\'', $xueli) . '\'',
    ),
    'hunyin' => array(
        'title' => lang_jy('hunyin',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('hunyin',0),
        'data' => '\'' . implode('\',\'', $hunyin) . '\'',
    ),
    'zhiye'=> array(
        'title' => lang_jy('zhiye',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('zhiye',0),
        'data' => '\'' . implode('\',\'', $zhiye) . '\'',
    ),
    'shouru'=> array(
        'title' => lang_jy('shouru',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('shouru',0),
        'data' => '\'' . implode('\',\'', $shouru) . '\'',
    ),
    'goufang'=> array(
        'title' => lang_jy('goufang',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('goufang',0).lang_jy('qk',0),
        'data' => '\'' . implode('\',\'', $goufang) . '\'',
    ),
    'gouche'=> array(
        'title' => lang_jy('gouche',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('gouche',0).lang_jy('qk',0),
        'data' => '\'' . implode('\',\'', $gouche) . '\'',
    ),
    'xiyan'=> array(
        'title' => lang_jy('xiyan',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('sf',0).lang_jy('xiyan',0),
        'data' => '\'' . implode('\',\'', $xiyan) . '\'',
    ),
    'hejiu'=> array(
        'title' => lang_jy('hejiu',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('sf',0).lang_jy('hejiu',0),
        'data' => '\'' . implode('\',\'', $hejiu) . '\'',
    ),
);
$y_nianling = array(
    lang_jy('nl1',0),
    lang_jy('nl2',0),
    lang_jy('nl3',0),
    lang_jy('nl4',0),
    lang_jy('nl5',0),
    lang_jy('nl6',0),
    lang_jy('nl7',0),
    lang_jy('nl8',0),
);
$y_shengao = array(
    lang_jy('sg1',0),
    lang_jy('sg2',0),
    lang_jy('sg3',0),
    lang_jy('sg4',0),
    lang_jy('sg5',0),
    lang_jy('sg6',0),
    lang_jy('sg7',0),
    lang_jy('sg8',0),
    lang_jy('sg9',0),
);
$y_shouru   = array_merge(array(lang_jy('shouru',0).lang_jy('buxian',0)), $shouru);
$y_zhiye   = array_merge(array(lang_jy('zhiye',0).lang_jy('buxian',0)), $zhiye);
$y_goufang = array_merge(array(lang_jy('goufang',0).lang_jy('buxian',0)), $goufang);
$y_xiyan   = array_merge(array(lang_jy('xiyan',0).lang_jy('buxian',0)), $xiyan);
$y_hejiu   = array_merge(array(lang_jy('hejiu',0).lang_jy('buxian',0)), $hejiu);
$y_hunyin   = array_merge( array(lang_jy('hunyinzt',0).lang_jy('buxian',0)), $hunyin);
$y_xueli   = array_merge(array(lang_jy('xueli',0).lang_jy('buxian',0)), $xueli);

$biaozhun_status = array(
    'y_nianling' => array(
        'title' => lang_jy('nianling',0) . lang_jy('fw',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('nianling',0) . lang_jy('fw',0),
        'data' => '\'' . implode('\',\'', $y_nianling) . '\'',
        'data_ary' => $y_nianling,
    ),
    'y_shengao' => array(
        'title' => lang_jy('shengao',0) . lang_jy('fw',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('shengao',0) . lang_jy('fw',0),
        'data' => '\'' . implode('\',\'', $y_shengao) . '\'',
        'data_ary' => $y_shengao,
    ),
    'y_xueli' => array(
        'title' => lang_jy('xueli',0) . lang_jy('fw',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('xueli',0) . lang_jy('fw',0),
        'data' => '\'' . implode('\',\'', $y_xueli) . '\'',
        'data_ary' => $y_xueli,
        'type' => 'multi'
    ),
    'y_zhiye'=> array(
        'title' => lang_jy('lxzy',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('lxzy',0),
        'data' => '\'' . implode('\',\'', $y_zhiye) . '\'',
        'data_ary' => $y_zhiye,
    ),
    'y_shouru'=> array(
        'title' => lang_jy('shouru',0) . lang_jy('fw',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('shouru',0) . lang_jy('fw',0),
        'data' => '\'' . implode('\',\'', $y_shouru) . '\'',
        'data_ary' => $y_shouru,
    ),
    'y_hunyin'=> array(
        'title' => lang_jy('hunyinzt',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('hunyinzt',0),
        'data' => '\'' . implode('\',\'', $y_hunyin) . '\'',
        'data_ary' => $y_hunyin,
        'type' => 'multi'
    ),
    'y_goufang'=> array(
        'title' => lang_jy('goufang',0).lang_jy('qk',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('goufang',0).lang_jy('qk',0),
        'data' => '\'' . implode('\',\'', $y_goufang) . '\'',
        'data_ary' => $y_goufang,
    ),
    'y_xiyan'=> array(
        'title' => lang_jy('xiyan',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('sf',0).lang_jy('xiyan',0),
        'data' => '\'' . implode('\',\'', $y_xiyan) . '\'',
        'data_ary' => $y_xiyan,
    ),
    'y_hejiu'=> array(
        'title' => lang_jy('hejiu',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('sf',0).lang_jy('hejiu',0),
        'data' => '\'' . implode('\',\'', $y_hejiu) . '\'',
        'data_ary' => $y_hejiu,
    ),
);


$choseconfig = array(
    'zsbq' => array(
        'data' => array_filter(explode("\n", trim($jy_config['zsbq']))),
        'title' => lang_jy('xzzsbq',0),
        'title_tip' => lang_jy('xzzsbq',0),
        'maxnum' => 7,
    ),
    'wdah' => array(
        'data' => array_filter(explode("\n", trim($jy_config['wdah']))),
        'title' => lang_jy('ynxah',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('ynxah',0),
        'maxnum' => 5,
    ),
    'jtqk' => array(
        'data' => $jtqk,
        'title' => lang_jy('xdjm',0),
        'title_tip' => lang_jy('qxz',0).lang_jy('xdjm',0),
        'maxnum' => 1,
    ),
);

$base_status0  = array(
    'age',
    'shengao',
    'tizhong',
    'shuxiang',
    'xingzuo',
    'jiaxiang',
    'gongzuodi',
    'jtqk'
);
$base_status0_fix = array(
    'shuxiang' => lang_jy('shu',0),
    'jiaxiang' => lang_jy('jiaxiang',0).': ',
    'gongzuodi' => lang_jy('gongzuodi',0).': ',
    'shouru' => lang_jy('shouru',0).': ',
    'jtqk' => lang('plugin/xigua_jy', 'jtqk').': '
);
$base_status1_fix = array(
  'shengao' => 'cm',
  'tizhong' => 'kg',
);
$xingge_aihao = array(
    'zsbq',
    'wdah'
);
$zotj = array(
    'y_nianling',
    'y_shengao',
    'y_xueli',
    'y_zhiye',
    'y_shouru',
    'y_hunyin',
    'y_goufang',
    'y_xiyan',
    'y_hejiu',
);

if($_GET['ac']=='my' || defined('IN_ADMINCP')){
    $qxtaocan = array();
    foreach (explode("\n", trim($jy_config['qxtaocan'])) as $index => $item) {
        list($_num, $_showprice, $_realprice, $_aprice, $_enddays) = explode('|', $item);
        $pr = (IN_MAGAPP||IN_QIANFAN||IN_APPBYME||IN_MOCUZ) ? $_aprice : $_realprice;
        $pr = trim($pr);
        $cishu = intval($_num);
        $_enddays = intval($_enddays);
        if($pr && $cishu){
            $yxq = $_enddays ? lang_jy('yxq',0).$_enddays.lang_jy('d',0) : '';
            $qxtaocan[$pr] = array(
                'id' => $pr,
                'name' => lang_jy('qxtc',0).$pr.'<em class="f12">'.lang('plugin/xigua_hb', 'yuan').'</em>/'.$cishu.'<em class="f12">'.lang('plugin/xigua_hb', 'c').'</em> '.$yxq,
                'udays' => '<s class="c9">'.lang_hb('yuanjia',0).$_showprice.lang('plugin/xigua_hb', 'yuan').'</s>',
                'desc' => lang_jy('mcy',0).floatval(round($pr/$cishu, 2)).lang('plugin/xigua_hb', 'yuan'),
                'times' => $cishu,
                'endays' => intval($_enddays),
                'aprice' => $_aprice,
            );
        }
    }
    $digtaocan = array();
    foreach (explode("\n", trim($jy_config['digtaocan'])) as $index => $item) {
        list($_num, $_showprice, $_realprice, $_aprice) = explode('|', $item);
        $pr = (IN_MAGAPP||IN_QIANFAN||IN_APPBYME||IN_MOCUZ) ? $_aprice : $_realprice;
        $pr = trim($pr);
        $cishu = intval($_num);
        if($pr && $cishu){
            $digtaocan[$pr] = array(
                'id' => $pr,
                'name' => lang_jy('qxtc',0).$pr.'<em class="f12">'.lang('plugin/xigua_hb', 'yuan').'</em>/'.$cishu.'<em class="f12">'.lang('plugin/xigua_hb', 'c').'</em> ',
                'udays' => '<s class="c9">'.lang_hb('yuanjia',0).$_showprice.lang('plugin/xigua_hb', 'yuan').'</s>',
                'desc' => lang_jy('mcy',0).floatval(round($pr/$cishu, 2)).lang('plugin/xigua_hb', 'yuan'),
                'times' => $cishu,
                'aprice' => $_aprice,
            );
        }
    }
}

/*VIP����|��Ч������|�۸�|APP�۸�|ǣ�ߴ���|�ö�����|�Զ�������*/
$vip_taocan = array();
$vip_i = 0;
foreach (explode("\n", trim($jy_config['viptaocan'])) as $index => $item) {
    list($_name, $_days, $_realprice, $_aprice, $_qianxian, $_digdays, $_desc) = explode('|', $item);
    $pr = (IN_MAGAPP||IN_QIANFAN||IN_APPBYME||IN_MOCUZ) ? $_aprice : $_realprice;
    if($_name){
        $vip_i ++;
        $_qianxian = intval($_qianxian);
        $_digdays = intval($_digdays);
        $zs = '';
        if($_qianxian||$_digdays){
            $zs = lang_jy('zs',0);
            $zsa = array();
            if($_qianxian){
                $zsa[] = " <em class='main_color'>{$_qianxian}</em> ".lang_jy('c',0).lang_jy('qxcs',0);
            }
            if($_digdays){
                $zsa[] = " <em class='main_color'>{$_digdays}</em> ".lang_jy('d',0).lang_jy('dig_ts',0);
            }
            $zs .= implode(',', $zsa);
        }
        $vip_taocan[$vip_i] = array(
            'id' => $vip_i,
            'name' => trim($_name),
            'days' => trim($_days),
            'price' => trim($pr),
            'appprice' => trim($_aprice),
            'qianxian' => $_qianxian,
            'digdays' => $_digdays,
            'desc' => trim($_desc).$zs,
        );
    }
}
$hn_status = array(
'0' => lang_jy('hn_status0',0),
'-1' => lang_jy('hn_status_1',0),
'1' => lang_jy('hn_status1',0),
);
$shows_ary = array(
'1'  => lang_jy('shows_ary1',0),
'-1' => lang_jy('shows_ary_1',0),
'-2' => lang_jy('shows_ary_2',0),
'-3' => lang_jy('shows_ary_3',0),
);
$gender_ary = array(
    1 => lang('plugin/xigua_jy', 'gender1'),
    2 => lang('plugin/xigua_jy', 'gender2'),
);

$citylevel = max(intval($jy_config['citylevel']-1), 0);

$hidety = array_filter(unserialize($jy_config['hidety']));
if($hidety){
    foreach ($hidety as $index => $item) {
        unset($biaozhun_status[$item]);
        $index1 = str_replace('y_', '', $item);
        unset($base_status[$index1]);
    }
}
$jy_ages = range(20, 70);
foreach ($jy_ages as $index => $jy_age) {
    $jy_ages[$index] = $jy_age;
}
$jy_ages =  '\''.implode('\',\'', $jy_ages).'\'';