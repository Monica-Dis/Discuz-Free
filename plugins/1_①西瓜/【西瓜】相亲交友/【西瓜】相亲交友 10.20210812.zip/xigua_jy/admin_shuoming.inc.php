<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if (!is_file(DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php')) {
    exit('Please install <a href="https://addon.dismall.com/plugins/xigua_hb.html">https://addon.dismall.com/plugins/xigua_hb.html</a>');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
$jy_config = $_G['cache']['plugin']['xigua_jy'];
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common_status.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/function.php';

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;

if (!submitcheck('addsubmit')) {
    $datas = DB::fetch_all('select * from %t where 1 order by id desc', array('xigua_jy_vipguide'), 'subject');
    echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?2\" />";
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_shuoming&page=$page", 'enctype');
    showtableheader();
    showtitle(lang_jy('kzsz', 0));
    ?>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<?php

    loadcache('xigua_wr_setting');
    $xigua_wr_setting = $_G['cache']['xigua_wr_setting'];
    showsetting('&#35814;&#24773;&#39029;&#26631;&#39064;', "editform[viewtitlevar]", $xigua_wr_setting['viewtitlevar'], 'text', '', 0, '&#33258;&#23450;&#20041;&#20250;&#21592;&#35814;&#24773;&#26631;&#39064;&#65292;&#21464;&#37327;&#58;&#123;&#110;&#97;&#109;&#101;&#125;&#32;&#20250;&#21592;&#21517;&#31216;');

    foreach ($vip_taocan as $index => $item) {
        $item['name'] = trim($item['name']);
        $content = $datas[$item['name']]['content'];
        showsetting($item['name'].lang_jy('vipicon', 0), "icon[{$item['name']}]", $datas[$item['name']]['link'], 'filetext', '', 0, '<img src="'.$datas[$item['name']]['link'].'" style="max-height:60px" />');
?>
        <tr><td colspan="2" class="td27"><?php echo $item['name']; echo lang_jy('sm',0)?>:</td></tr>
    <tr class="hover">
        <td colspan="2">
<script id="c<?php echo $index;?>" name="form[<?php echo $item['name'];?>]" type="text/plain" style="width:800px;height:200px;"><?php echo $content;?></script>
            <script>UE.getEditor('c<?php echo $index;?>');</script>
        </td>
    </tr>
<?php
    }
    $qianx = lang_jy('qianxian',0);
    $content1 = $datas[$qianx]['content'];
?>
    <tr><td colspan="2" class="td27"><?php echo $qianx; echo lang_jy('sm',0)?>:</td></tr>
    <tr class="hover">
        <td colspan="2">
<script id="c9999" name="form[<?php echo $qianx;?>]" type="text/plain" style="width:800px;height:200px;"><?php echo $content1; ?></script>
            <script>UE.getEditor('c9999');</script>
        </td>
    </tr>
    <?php
    showsubmit('addsubmit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
} else {
    $form = $_GET['form'];
    $icons = $_GET['icon'];

    $_newimglist = hb_uploads($_FILES['icon']);
    foreach ($_newimglist as $__k => $__v) {
        if ($__v['errno'] == 0) {
            $icons[$__k] = $__v['error'];
        }
    }
    foreach ($form as $index => $item) {
        $index = trim($index);
        $item = trim($item);
        $old_data = DB::fetch_first('select * from %t where subject=%s', array('xigua_jy_vipguide', $index));
        if (!$old_data) {
            C::t('#xigua_jy#xigua_jy_vipguide')->insert(array(
                'subject' => $index,
                'content' => $item,
                'crts' => TIMESTAMP,
                'link' => $icons[$index],
            ));
        } else {
            DB::update('xigua_jy_vipguide', array(
                'content' => $item,
                'crts' => TIMESTAMP,
                'link' => $icons[$index],
                ), array(
                'subject' => $index,
            ));
        }
    }
    $editform = $_GET['editform'];
    savecache('xigua_wr_setting', $editform);
    cpmsg(lang_hb('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_shuoming&page=$page", 'succeed');
}