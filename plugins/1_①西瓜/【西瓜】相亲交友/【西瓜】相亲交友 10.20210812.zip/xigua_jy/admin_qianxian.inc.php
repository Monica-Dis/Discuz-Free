<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢�� wxiguabbs
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if (empty($_G['cache']['plugin'])) :
    loadcache('plugin');
endif;

$jy_config = $_G['cache']['plugin']['xigua_jy'];
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common_status.php';

$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;

$userpage = ADMINSCRIPT."?action=plugins&operation=config&do=128&identifier=xigua_jy&pmod=admin_man&keyword=";
$hns = C::t('#xigua_jy#xigua_jy_hn')->fetch_all_by_page(array('status=1'), 0, 999, 'name,id', 'displayorder desc,id desc');
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" /><style>img{object-fit:cover}</style>";

if (submitcheck('permsubmit')) {
    if($new = $_GET['n']){
        $newrow = array();
        foreach ($new['from'] as $k => $v) {
            if(is_array($v)){
                foreach ($v as $kk => $string) {
                    $newrow[] = array(
                        'uid'    => $new['from'][$k][$kk],
                        'touid'  => $new['to'][$k][$kk],
                        'crts' => TIMESTAMP,
                    );
                }
            } else {
                $newrow[] = array(
                    'uid'  => $new['from'][$k],
                    'touid'  => $new['to'][$k],
                    'crts' => TIMESTAMP,
                );
            }
        }
        foreach ($newrow as $value) {
            C::t('#xigua_jy#xigua_jy_qianxian')->insert($value);
        }
    }
    if ($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_jy#xigua_jy_qianxian')->deletes($delete);
    }
    $SCRITPTNAME = $SCRITPTNAME ? $SCRITPTNAME : 'plugin.php';
    foreach ($_GET['row'] as $id => $item) {
        $qxrow = C::t('#xigua_jy#xigua_jy_qianxian')->fetch($id);
        C::t('#xigua_jy#xigua_jy_qianxian')->update($id, array(
            'status' => $item['status'],
            'allowvideo' => $item['allowvideo'],
            'allowalbum' => $item['allowalbum'],
            'upts' => TIMESTAMP,
            'hnids' => $item['hnids'],
        ));
        if($item['status']==2  && ($qxrow['status']==-1||$qxrow['status']==-2)){
            if($jy_config['huifu']){
                C::t('#xigua_jy#xigua_jy_taocan')->incr($qxrow['taocan_id'], 'used', -1);
                notification_add($qxrow['uid'],'system', lang_jy('qianxian_status2_tip1', 0),array(
                    'url' => "$SCRITPTNAME?id=xigua_jy&ac=my&do=qianxian",
                ),1);
            }else{
                notification_add($qxrow['uid'],'system', lang_jy('qianxian_status2_tip2', 0),array(
                    'url' => "$SCRITPTNAME?id=xigua_jy&ac=my&do=qianxian",
                ),1);
            }
        }elseif ($item['status']==1  && ($qxrow['status']==-1||$qxrow['status']==-2)){
            $touserr = C::t('#xigua_jy#xigua_jy_user')->fetch($qxrow['touid']);
            notification_add($qxrow['uid'],'system', lang_jy('qianxian_status1_tip', 0),array(
                'name' => $touserr['nickname'],
                'url' => "$SCRITPTNAME?id=xigua_jy&ac=my&do=qianxian",
            ),1);
        }
    }
    cpmsg(lang_jy('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_qianxian&page=$page", 'succeed');
}

$wherearr = array();
$keyword = $_GET['keyword'];
if (is_numeric($keyword) && $keyword < 9999999) {
    $wherearr[] = 'uid=' . intval($keyword);
} else if ($keyword = stripsearchkey(addslashes($keyword))) {
    $wherearr[] = " (`uid` LIKE '%$keyword%' OR touid LIKE '%$keyword%') ";
}
if ($_GET['status']) {
    $wherearr[] = 'status=' . intval($_GET['status']);
}
if ($_GET['hnids']) {
    $wherearr[] = 'hnids=' . intval($_GET['hnids']);
}
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_qianxian&page=$page");

echo '<div><input type="text" id="keyword" placeholder="' . lang_jy('qsrgjc', 0) . '" name="keyword" value="' . $_GET['keyword'] . '" class="txt" style="width:200px" /> ';
$status_c = "<select name=\"status\">";
$status_c .= "<option value=\"0\">".lang_jy('qb',0)."</option>";
foreach ($qianxian_status as $k => $vv) {
    if ($_GET['status'] == $k) {
        $s = 'selected';
    } else {
        $s = '';
    }
    $status_c .= "<option $s value=\"$k\">{$vv}</option>";
}
$status_c .= '</select>';
echo $status_c.'&nbsp;&nbsp;';


$hns_u1 = "<select id='hn_ids' name=\"hnids\">";
if(!$_GET['hnids']){
    $s = 'selected';
} else {
    $s = '';
}
$hns_u1 .= "<option $s value=\"0\">".lang_jy('qb',0)."</option>";
foreach ($hns as $k => $vv) {
    if ($_GET['hnids'] == $vv['id']) {
        $s = 'selected';
    } else {
        $s = '';
    }
    $hns_u1 .= "<option $s value=\"{$vv['id']}\">{$vv['name']}</option>";
}
$hns_u1 .= '</select>';
echo $hns_u1.'&nbsp;&nbsp;';


echo '&nbsp;';
echo ' <input name="page" value="1" type="hidden" /><input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href=' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_qianxian" . ' class="btn" >' . cplang('reset') . '</a> ';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_jy/static/admin_cp.css?45678\" />";
//echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_qianxian&secid=-1\" class=\"btn bg_green\">" . lang_jy('tjsp', 0) . "</a>";
echo "</div>";

showtableheader(lang_jy('qxgl', 0));
showtablerow('class="header"', array(), array(
    lang_jy('del', 0),
    lang_jy('fqr', 0),
    lang_jy('qxdx', 0),
    lang_jy('album',0).lang_jy('rights',0),
    lang_jy('shipin',0).lang_jy('rights',0),
    lang_jy('caozuo',0),
    lang_jy('hnids',0),
    lang_jy('crts', 0).'/'.lang_jy('upts', 0),
));
$res = C::t('#xigua_jy#xigua_jy_qianxian')->fetch_all_by_page($wherearr, $start_limit, $lpp, '*');
$icount = C::t('#xigua_jy#xigua_jy_qianxian')->fetch_count_by_page($wherearr);

$uids = $shids = array();
foreach ($res as $k => $v) {
    $uids[$v['uid']] = $v['uid'];
    $uids[$v['touid']] = $v['touid'];
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $wherearr = array();
    $wherearr[] = 'uid IN ('.implode(',', $uids).')';
    $jyusers = C::t('#xigua_jy#xigua_jy_user')->fetch_all_by_where($wherearr, 0, count($uids), 'uid');
}
$yes = lang_jy('yes',0);
$no = lang_jy('no',0);

foreach ($res as $v) {
    $id = $v['id'];
    $thumb = $v['avatar'] ? $v['avatar'] : 'source/plugin/xigua_jy/static/img/dftava.png';
    $img = '';
    $status_u = "<select name=\"row[$id][status]\">";
    foreach ($qianxian_status as $k => $vv) {
        if ($v['status'] == $k) {
            $s = 'selected';
        } else {
            $s = '';
        }
        $status_u .= "<option $s value=\"$k\">$vv</option>";
    }
    $status_u .= '</select>';

    $hns_u = "<select id='hn_ids' name=\"row[$id][hnids]\">";
    if(!$v['hnids']){
        $s = 'selected';
    } else {
        $s = '';
    }
    $hns_u .= "<option $s value=\"0\">".lang_jy('wfp',0)."</option>";
    foreach ($hns as $k => $vv) {
        if ($v['hnids'] == $vv['id']) {
            $s = 'selected';
        } else {
            $s = '';
        }
        $hns_u .= "<option $s value=\"{$vv['id']}\">{$vv['name']}</option>";
    }
    $hns_u .= '</select>';

    $allowalbum1 = $v['allowalbum']?'checked':'';
    $allowalbum2 = !$v['allowalbum']?'checked':'';
    $quanxian1 = "<input name='row[$id][allowalbum]' $allowalbum1 type='radio' value='1' />$yes <input name='row[$id][allowalbum]' $allowalbum2 type='radio'  value='0' />$no ";

    $allowvideo1 = $v['allowvideo']?'checked':'';
    $allowvideo2 = !$v['allowvideo']?'checked':'';
    $quanxian2 = "<input name='row[$id][allowvideo]' $allowvideo1 type='radio'  value='1' />$yes <input name='row[$id][allowvideo]' $allowvideo2 type='radio'  value='0' />$no ";

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
        get_jy_user($v['uid']),
        get_jy_user($v['touid']),
        $quanxian1,
        $quanxian2,
        $status_u,
        $hns_u,
        date('Y-m-d H:i:s', $v['crts'] ). '<br>' .
        date('Y-m-d H:i:s', $v['upts'] ),
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_qianxian&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', 'del', '<a href="javascript:;" onclick="addrow(this, 0)" class="addtr">'.lang_jy('tjsp', 0).'</a>', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter();

function get_jy_user($uid){
    global $userpage, $_G;
    global $jyusers;
    $fromu = $jyusers[$uid];
    $prename2 = '<b>'.$fromu['nickname'].' [ '.$uid.' ] '.'</b>'."<i style='display:inline-block;position:relative;top:3px;left:0' class=\"memli_gender g{$fromu['gender']}\"></i>";
    $thumb = $fromu['avatar'] ? $fromu['avatar'] : 'source/plugin/xigua_jy/static/img/dftava.png';
    $extname = ' ';
    $extname .= '<div class="pr-1">';
    if($fromu['is_vip']||$fromu['verify']){
        if($fromu['verify']){
            $tb = $_G[cache][plugin][xigua_hr][grtb] ? $_G[cache][plugin][xigua_hr][grtb] : 'source/plugin/xigua_jy/static/img/sm.png';
            $prename2 .= ' <img class="rzimg2" src="'.$tb.'?{VERHASH}" />';
        }
        if( $fromu['is_vip']){
            $extname .= '<b class="red">'.$fromu['vip_name'].'</b>';
            $prename2 .= ' <img class="rzimg2" src="'.$fromu['vip_icon'].'?{VERHASH}"> ';
        }
    }
    $extname .= ' <a href="'.$userpage.$fromu['nickname'].'" target="_blank">'.lang_jy('hyzl',0).'</a>';
    $extname .= '</div>';
    return "<div class='cl' style='width:200px'>
<img style='width:34px;height:34px;float:left;margin-right:5px' src='$thumb' class='jthumb' /> <div>$prename2 $extname </div></div> ";
}
?>
<script>
    var rowtypedata = [
        [
            [1, ''],
            [1,'<input type="text" class="txt" name="n[from][]" value="" size="20" placeholder="<?php echo lang_jy('fqr', 0) ?>UID" />'],
            [5,'<div><input name="n[to][]" value="" size="20" type="text" class="txt" placeholder="<?php echo lang_jy('qxdx', 0) ?>UID" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
        ]
    ];
</script>
