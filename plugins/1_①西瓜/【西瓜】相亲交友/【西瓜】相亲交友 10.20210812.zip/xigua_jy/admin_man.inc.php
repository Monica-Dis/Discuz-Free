<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢�� wxiguabbs
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
if (empty($_G['cache']['plugin'])) :
    loadcache('plugin');
endif;

$jy_config = $_G['cache']['plugin']['xigua_jy'];
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_jy/common_status.php';

$page = max(1, intval($_GET['page']));
$lpp = $_GET['lpp'] ? $_GET['lpp'] : 10;
$start_limit = ($page - 1) * $lpp;
$keyword = $_GET['keyword'];
$shows = $_GET['shows '];
$status = $_GET['status'];
$hnid = $_GET['hnid'];
$orderby = $_GET['orderby'];
if(!isset($_GET['base_status'])){
    $_GET['base_status'] = -1;
}
$base_status= $_GET['base_status'];

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/admincp.css?1243\" /><style>img{object-fit:cover}</style>";
if($secid = intval($_GET['secid'])){
    $res = C::t('#xigua_jy#xigua_jy_user')->fetch($secid);
    $unsetary =array(
        'vip_index','istd','vip_name', 'zans','vip_startts', 'upts_u','crts_u','vip_endts','vip_info',
        'vip_endts_day','album_ary','age','gongzuodi_ary','is_vip','vip_icon',
        'shares','displayorder','shuxiang','xingzuo','is_dig','hnids','order_id'
    );
    $ts_ary = array('crts', 'upts', 'dig_startts','dig_endts');
    if(!submitcheck('dosubmit')) {
        if(!$res){
            $neww = 1;
            $res =array ( 'uid' => '', 'gender' => '1',  'shows' => '1', 'status' => '1', 'stid' => '0', 'note' => '', 'nickname' => '', 'birthday' => '2003-02-21', 'mobile' => '', 'wx' => '', 'avatar' => '', 'displayorder' => '0', 'dig_startts' => '', 'dig_endts' => '', 'zsbq' => '', 'wdah' => '', 'jtqk' => '', 'shuxiang' => '', 'xingzuo' => '', 'shengao' => '170', 'tizhong' => '55', 'jiaxiang' => '', 'gongzuodi' => '', 'xueli' => '', 'hunyin' => '', 'zhiye' => '', 'shouru' => '', 'goufang' => '', 'gouche' => '', 'xiyan' => '', 'hejiu' => '', 'video' => '', 'video_cover' => '', 'album' => '', 'y_nianling' => '', 'y_shengao' => '', 'y_xueli' => '', 'y_zhiye' => '', 'y_shouru' => '', 'y_hunyin' => '', 'y_goufang' => '', 'y_xiyan' => '', 'y_hejiu' => '', 'y_note' => '', 'vip_name' => '', 'vip_startts' => '', 'vip_endts' => '', 'vip_info' => '', 'views' => '0', 'follows' => '5', 'shares' => '0', 'zans' => '0', 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, );
        }
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_jy('glhy',0) . ($secid>0?'-'. $res['nickname']." [ ID : $secid ]" :''). "&nbsp;&nbsp;<a class='abtn' href='".ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status'>".lang_jy('back',0)."</a>");

        $base_data_map = array(
        'gender' => $gender_ary,'jtqk' => $jtqk,'shengao' => $shengao_ary,'tizhong' => $tizhong_ary,'xueli' => $xueli,'hunyin' => $hunyin,
        'zhiye' => $zhiye,'shouru' => $shouru,'goufang' => $goufang,'gouche' => $gouche,'xiyan' => $xiyan,'hejiu' => $hejiu,'y_nianling' => $y_nianling,
        'y_shengao' => $y_shengao,'y_xueli' => $y_xueli,'y_zhiye' => $y_zhiye,'y_shouru' => $y_shouru,'y_goufang' => $y_goufang,'y_hunyin' => $y_hunyin,
        'y_xiyan' => $y_xiyan,'y_hejiu' => $y_hejiu,'hnids' => $y_hejiu,
        );
        foreach ($res as $index => $re) {
            $l = '';
            if(in_array($index, $unsetary)){
                continue;
            }
            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if(in_array($index, $ts_ary)){
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            }elseif(in_array($index, array('birthday'))){
                $tp = 'calendar';
                $_extra = '';
            }elseif($base_data_map[$index]){
                $__tmp = $base_data_map[$index];
                $cs = '<select name="editform['.$index.']">';
                foreach ($__tmp as $c_t => $c) {
                    $s = '';
                    if(!in_array($index,array('gender', 'shengao', 'tizhong'))){
                        if($c== $re){
                            $s = 'selected';
                        }
                        $cs .= "<option $s value='$c'>$c</option>";
                    }else{
                        if($c_t== $re){
                            $s = 'selected';
                        }
                        $cs .= "<option $s value='$c_t'>$c</option>";
                    }
                }
                $cs .= '</select>';
                $tp = $cs;
                if(strpos($index,'y_')!==false){
                    $cmt = lang_jy('zobz',0);
                    $l = lang_jy(str_replace('y_','', $index),0);
                }
            }elseif(in_array($index, array('status'))){
                $cs = '<select name="editform[status]">';
                foreach ($xq_status as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c['title']}</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('shows'))){
                $cs = '<select name="editform[shows]">';
                foreach ($shows_ary as $c_t => $c) {
                    $s = '';
                    if($c_t== $re){
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>{$c}</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }elseif(in_array($index, array('base_status' ,'tuijian'))){
                $tp = 'radio';
            }elseif(in_array($index, array('note' ,'y_note'))){
                $tp = 'textarea';
            }

            if(in_array($index, array('avatar','video_cover'))){
                $tp = 'filetext';
                $cmt = '';
                if($re){
                    $cmt = '<a target="_blank" href="'.$re.'"><img src="'.$re.'" style="width:80px;height:80px" /></a>';
                }
            }
            if($index == 'video'){
                $cmt = '<a target="_blank" href="'.$re.'">'.$re.'</a>';
            }
            if (in_array($index, array('album'))) {
                $re = !is_array($re) ? explode(",", $re) : $re;
                $tp = 'filetext';
                $hf_config = $_G['cache']['plugin']['xigua_jy'];
                $loopnum = $hf_config['maximg'];
                for ($i = 0; $i < $loopnum; $i++) {
                    $cmt = '';
                    if($re[$i]){
                        $cmt = '<a  target="_blank" href="'.$re[$i].'"><img src="'.$re[$i].'" style="width:80px;height:80px" /></a>';
                    }
                    showsetting(lang_jy($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp, '', 0, $cmt);
                }
            }else{
                $l = $l ? $l : lang_jy($index, 0);
                showsetting($l, "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');
function changeurl(val){window.location.href = window.location.href+'&catid='+val;}
</script>
HTML;

    }else{
        $editform = $_GET['editform'];
        if(!$editform['album']){
            $editform['album'] = array();
        }
        $editform['status'] = intval($editform['status']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach ($ts_ary as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        foreach (array('album') as  $item) {
            if(!$editform[$item]){
                $editform[$item] = array();
            }
            $editform[$item] = implode(',', $editform[$item]);
        }
        if($secid>0){
            $rs = C::t('#xigua_jy#xigua_jy_user')->update($secid, $editform);
            $hid = $secid;
        }else{
            $hid = C::t('#xigua_jy#xigua_jy_user')->insert($editform, 1);
        }
        cpmsg(lang_jy('czcg',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status&secid=$hid", 'succeed');
    }
    exit;
}
if($_GET['type']=='qxtc'){
    $qxtcuid = intval($_GET['qxtcid']);
    if(submitcheck('delqxtcid',1 )){
        C::t('#xigua_jy#xigua_jy_taocan')->delete($_GET['delqxtcid']);
        cpmsg(lang_jy('delsuccess', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&type=qxtc&qxtcid=$qxtcuid", 'succeed');
    }
    if(submitcheck('dosubmit3')){
        if($new = $_GET['n']){
            $newrow = array();
            foreach ($new['uid'] as $k => $v) {
                $newrow[] = array(
                    'uid'   => $qxtcuid,
                    'name'  => $new['name'][$k],
                    'total' => $new['total'][$k],
                    'used'  => $new['used'][$k],
                    'endts'  => strtotime($new['endts'][$k]),
                    'crts'  => TIMESTAMP,
                );
            }
            foreach ($newrow as $value) {
                C::t('#xigua_jy#xigua_jy_taocan')->insert($value);
            }
            cpmsg(lang_jy('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&type=qxtc&qxtcid=$qxtcuid", 'succeed');
        }
    }
    $res = DB::fetch_all('SELECT * FROM %t WHERE uid=%d ORDER BY id DESC', array('xigua_jy_taocan', $qxtcuid));

    $uids = array();
    foreach ($res as $k => $v) {
        $uids[$v['uid']] = $v['uid'];
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }
    $userdata = C::t('#xigua_jy#xigua_jy_user')->fetch($qxtcuid);
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&type=qxtc&qxtcid=$qxtcuid", 'enctype');

    showtableheader($userdata['nickname'].lang('plugin/xigua_jy','de').lang_jy('qxtc', 0). "&nbsp;&nbsp;<a href='javascript:window.history.go(-1);'>".lang_hb('back',0)."</a>");
    showtablerow('class="header"', array(), array(
        'ID',
        lang_jy('uids',0),
        lang_jy('mc',0),
        lang_jy('used',0).'/'.lang_jy('total',0),
        lang_jy('yxq',0),
        lang_jy('price',0),
        lang_jy('order_id',0),
        lang_jy('crts',0),
        lang_jy('payts',0),
        lang_jy('del',0),
    ));
    foreach ($res as $index => $re) {
        showtablerow('', array(), array(
            $re['id'],
            $users[$re['uid']]['username'].'[ '.$re['uid'].' ]',
            $re['name'],
            $re['used'].' / '.$re['total'],
            $re['endts'] ? date('Y-m-d H:i:s', $re['endts']) : '-',
            '<b>'.$re['price'].'</b>',
            $re['order_id'],
            date('Y-m-d H:i:s', $re['crts']),
            $re['payts'] ? date('Y-m-d H:i:s', $re['payts']) : '-',
            '<a class=\'btn bg_red btnwd btn2\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&type=qxtc&qxtcid=$qxtcuid&delqxtcid={$re['id']}&formhash=".FORMHASH . '">' . lang_jy('del', 0) . '</a>',
        ));
    }

?>
<tr>
    <td>&nbsp;</td>
    <td colspan="99"><div><a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_jy('add_tc')?></a></div></td>
</tr>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script>
    var rowtypedata = [
        [
            [1, ''],
            [1,'<input name="n[uid][]" placeholder="UID" value="<?php echo $qxtcuid?>" style="width:40px" type="text" class="txt" />', ''],
            [1,'<input type="text" class="txt" name="n[name][]" value=""  size="5" />', ''],
            [1,'<input type="text" class="txt" name="n[used][]" value="0" style="width:40px" /> / <input type="text" class="txt" name="n[total][]" value="0" style="width:40px" />', ''],
            [1,'<input type="text" style="width:140px" class="txt" name="n[endts][]" value="<?php echo date('Y-m-d H:i:s')?>" onclick="showcalendar(event, this, 1)" />', ''],
            [5,'<div><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>', ''],
        ]
    ];
</script>
<?php
    showsubmit('dosubmit3', 'submit', 'td');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
    exit;
}
if(submitcheck('dosubmit3')){
    $vipnames = trim($_GET['vipnames']);
    $yhid3 = intval($_GET['yhid3']);
    foreach ($vip_taocan as $index => $item) {
        if($vipnames == $item['name']){
            $olddata = C::t('#xigua_jy#xigua_jy_user')->fetch($yhid3);
            $lastts = max($olddata['vip_endts'], TIMESTAMP);
            $vipendts = $item['days']*86400+$lastts;
            C::t('#xigua_jy#xigua_jy_user')->update($yhid3, array(
                'vip_index' => $index,
                'vip_name' => $item['name'],
                'vip_startts' => TIMESTAMP,
                'vip_endts' => $vipendts,
                'vip_info' => serialize($item),
            ));

            if($item['digdays']){
                $lastts = max($olddata['dig_endts'], TIMESTAMP);
                C::t('#xigua_jy#xigua_jy_user')->update($yhid3, array(
                    'dig_startts' => TIMESTAMP,
                    'dig_endts' => $item['digdays']*86400+$lastts,
                ));
            }
            if($item['qianxian']){
                $newdata = array(
                    'type'  => 'line',
                    'uid'   => $yhid3,
                    'name'  => lang_jy('ht',0).lang_jy('gm',0).$item['name'].lang_jy('zs',0).' '.$item['qianxian'],
                    'price' => 0,
                    'total' => $item['qianxian'],
                    'used' => 0,
                    'crts' => TIMESTAMP,
                    'upts' => TIMESTAMP,
                    'payts' => 0,
                    'endts' => $vipendts,
                    'order_id' => '',
                );
                C::t('#xigua_jy#xigua_jy_taocan')->insert($newdata);
            }
            break;
        }else{
            C::t('#xigua_jy#xigua_jy_user')->update($yhid3, array(
                'vip_index' => 0,
                'vip_name' => '',
                'vip_startts' => 0,
                'vip_endts' => 0,
                'vip_info' => '',
            ));
        }
    }
    cpmsg(lang_jy('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status", 'succeed');
}
if(submitcheck('dosubmit2')){
    if($zd_endts = strtotime($_GET['zd_endts'])){
        C::t('#xigua_jy#xigua_jy_user')->update($_GET['yhid2'], array(
            'dig_startts' => TIMESTAMP,
            'dig_endts' => $zd_endts,
        ));
    }
    cpmsg(lang_jy('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status", 'succeed');
}
if(submitcheck('dosubmit5')){
    $newbase = intval($_GET['new_base_status']);
    C::t('#xigua_jy#xigua_jy_user')->update($_GET['yhid5'], array(
        'base_status' => $newbase,
    ));
    cpmsg(lang_jy('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$newbase", 'succeed');
}
/*dosubmit4*/
if(submitcheck('dosubmit4')){
    $reson = $_GET['reson'];
    $vip_shows= $_GET['vip_shows'];

    C::t('#xigua_jy#xigua_jy_user')->update($_GET['yhid4'], array(
        'shows' => $vip_shows,
        'reson' => $reson,
    ));
    if($vip_shows==-3){
        $rreson= $reson ? lang_jy('yy',0).':'.$reson : '';
        notification_add($_GET['yhid4'],'system', lang_jy('vipshows_3', 0),array(
            'reson' => $rreson,
            'url' => "$SCRITPTNAME?id=xigua_jy&ac=my&shows=-3",
        ),1);
    }elseif($vip_shows==1){
        notification_add($_GET['yhid4'],'system', lang_jy('vipshows1', 0),array(
            'url' => "$SCRITPTNAME?id=xigua_jy&ac=my&shows=-3",
        ),1);
    }
    cpmsg(lang_jy('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status", 'succeed');
}
if(submitcheck('hn_ids')){
    C::t('#xigua_jy#xigua_jy_user')->update($_GET['yhid'], array('hnids' => implode(',', $_GET['hn_ids'])));
    cpmsg(lang_jy('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status", 'succeed');
}
if (submitcheck('permsubmit')) {
    if ($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_jy#xigua_jy_user')->deletes($delete);
    }
    foreach ($_GET['row'] as $id => $item) {
        C::t('#xigua_jy#xigua_jy_user')->update($id, array('status' => $item['status'], 'shows' => $item['shows']));
    }
    cpmsg(lang_jy('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status", 'succeed');
}
$wherearr = array();
if (is_numeric($keyword) && $keyword < 9999999) {
    $wherearr[] = 'uid=' . intval($keyword);
} else if ($keyword = stripsearchkey(addslashes($keyword))) {
    $wherearr[] = " (`nickname` LIKE '%$keyword%' OR mobile LIKE '%$keyword%' OR wx LIKE '%$keyword%' OR note LIKE '%$keyword%' ) ";
}
if ($_GET['status']) {
    $wherearr[] = 'status=' . intval($_GET['status']);
}
if ($_GET['shows']) {
    $wherearr[] = 'shows=' . intval($_GET['shows']);
}
if ($_GET['hnid']) {
    $wherearr[] = 'FIND_IN_SET (' . intval($_GET['hnid']).', hnids)';
}
if ($_GET['base_status']>=0) {
    $wherearr[] = 'base_status=' . intval($_GET['base_status']);
}
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status");

echo '<div><input type="text" id="keyword" placeholder="' . lang_jy('qsrgjc', 0). '" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';

$status_c = "<select name=\"status\">";
$status_c .= "<option value=\"0\">".lang_jy('qb',0)."</option>";
foreach ($xq_status as $k => $vv) {
    if ($_GET['status'] == $k) {
        $s = 'selected';
    } else {
        $s = '';
    }
    $status_c .= "<option $s value=\"$k\">{$vv['title']}</option>";
}
$status_c .= '</select>';
echo '&nbsp;&nbsp;';
echo lang_jy('xqzt',0).'&nbsp;&nbsp;'.$status_c;

$status_c = "<select name=\"shows\">";
$status_c .= "<option value=\"0\">".lang_jy('qb',0)."</option>";
foreach ($shows_ary as $k => $vv) {
    if ($_GET['shows'] == $k) {
        $s = 'selected';
    } else {
        $s = '';
    }
    $status_c .= "<option $s value=\"$k\">{$vv}</option>";
}
$status_c .= '</select>';
echo '&nbsp;&nbsp;'.lang_jy('shows',0).'&nbsp;'.$status_c;
echo '&nbsp;&nbsp;';

$hns = C::t('#xigua_jy#xigua_jy_hn')->fetch_all_by_page(array('status=1'), 0, 999, 'name,id', 'displayorder desc,id desc');
$hns_c = "<select name=\"hnid\">";
$hns_c .= "<option value=\"0\">".lang_jy('qb',0)."</option>";
foreach ($hns as $k => $vv) {
    if ($_GET['hnid'] == $vv['id']) {
        $s = 'selected';
    } else {
        $s = '';
    }
    $hns_c .= "<option $s value=\"{$vv['id']}\">{$vv['name']}</option>";
}
$hns_c .= '</select>';
echo '&nbsp;&nbsp;'.lang_jy('hn',0).'&nbsp;'.$hns_c;
echo '&nbsp;&nbsp;';


$lpp_se = lang_jy('base_status1',0)."&nbsp;<select name=\"base_status\">";
foreach (array('-1' => lang_jy('qb',0),'0' => lang_jy('zlxws',0), '1' => lang_jy('zlyws',0), ) as $index => $item) {
    $sellpp = '';
    if($index == $_GET['base_status']){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$index\">".$item."</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;
echo '&nbsp;&nbsp;';

$lpp_se = lang_jy('paixu',0)."&nbsp;<select name=\"orderby\">";
foreach (array('default', 'new', ) as $item) {
    $sellpp = '';
    if($item == $_GET['orderby']){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">".lang_jy($item,0)."</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;
echo '&nbsp;&nbsp;';

$lpp_se = " <select name=\"lpp\">";
foreach (array(1, 10 ,20, 50, 100, 200, 500, 1000, 5000, 10000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;
echo '&nbsp;&nbsp;';

echo ' <input name="page" value="1" type="hidden" /><input type="submit" class="btn" value="' . cplang('search') . '" /> ';
echo ' <a href=' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page" . ' class="btn" >' . cplang('reset') . '</a> ';
echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&secid=-1\" class=\"btn bg_green\">" . lang_jy('tjsp', 0) . "</a>";
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_jy/static/admin_cp.css?45678\" />";
echo "</div>";
$lang_uids = lang_jy('uids', 0);
$lang_mobile = lang_jy('mobile', 0);
$lang_wxh = lang_jy('wxh', 0);

showtableheader(lang_jy('hngl', 0));
showtablerow('class="header"', array(), array(
    lang_jy('del', 0),
    lang_jy('avatar', 0).'/'.
    lang_jy('nickname', 0),
    lang_jy('viplevel', 0).'<br>'.
    $lang_uids.'/'.
    $lang_mobile.'/'.
    $lang_wxh,
    lang_jy('hyzl', 0),
    lang_jy('zobz', 0),
    lang_jy('caozuo', 0),
    lang_jy('crts', 0),
));
$GLOBALS['need_verify'] = 1;
$res = C::t('#xigua_jy#xigua_jy_user')->fetch_all_by_where($wherearr, $start_limit, $lpp);
$icount = C::t('#xigua_jy#xigua_jy_user')->fetch_count_by_page($wherearr);

$uids = $shids = array();
foreach ($res as $k => $v) {
    $uids[$v['uid']] = $v['uid'];
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $mobiles = DB::fetch_all('SELECT uid,mobile FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}

$basehref = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status";
$basehrefhn = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong&page=1&keyword=";
$qianxianpage = ADMINSCRIPT."?action=plugins&operation=config&do=128&identifier=xigua_jy&pmod=admin_qianxian&keyword=";

foreach ($res as $v) {
    $id = $v['uid'];
    if(!$v['avatar']){
        $v['avatar'] = avatar($v['uid'], 'middle', 1);
    }
    $thumb = $v['avatar'] ? $v['avatar'] : 'source/plugin/xigua_jy/static/img/dftava.png';
    if(!$v['mobile']){
        $v['mobile'] = $mobiles[$id]['mobile'];
    }
    $img = '';
    $status_u = "<select class='w56' name=\"row[$id][status]\">";
    foreach ($xq_status as $k => $vv) {
        if ($v['status'] == $k) {
            $s = 'selected';
        } else {
            $s = '';
        }
        $status_u .= "<option $s value=\"$k\">{$vv['title']}</option>";
    }
    $status_u .= '</select>';

    $baseinfo = '<div class="jlcltags cl">';
    $tmp = array();
    if($v['note']){
        $tmp[] = '<p>'.lang_jy('note',0).': '.$v['note'].'</p>';
    }
    foreach ($base_status0 as $index => $_v) {
        if(!$v[$_v]){
            continue;
        }
        $rowstr = '';
        if($base_status0_fix[$_v]){
            $rowstr .= $base_status0_fix[$_v];
        }
        $rowstr .= $v[$_v];
        if($base_status1_fix[$_v]){
            $rowstr .= $base_status1_fix[$_v];
        }
        $tmp[] = '<p>'.$rowstr.'</p>';
    }
    $hnstr = array();
    foreach ($hns as $k => $vv) {
        if (in_array($vv['id'], explode(',', $v['hnids']))) {
            $hnstr[] = "<a href='$basehrefhn{$vv['name']}' target='_blank'>{$vv['name']}</a>";
        }
    }

    $userinfo = '<span class="c9">'.$lang_uids.' : </span>'.$users[$v['uid']]['username'] . ' [ ' . $v['uid'] . ' ]'.'<br>'.
        '<span class="c9">'.$lang_mobile.' : </span>'.$v['mobile'].'<br>'.
        '<span class="c9">'.$lang_wxh.' : </span>'.$v['wx'].
        ($hnstr ? '<br>'.'<span class="c9">'.lang_jy('hn1',0).' : </span>'.implode('&nbsp;', $hnstr) : '').
        '<br>'.( $v['base_status']? '<b class="c_green">'.lang_jy('zlyws',0).'</b>' :'<b class="red">'.lang_jy('zlxws',0).'</b>' )
    ;
    foreach ($base_status as $_k => $_v) {
        if(!$v[$_k]){
            continue;
        }
        $rowstr = '';
        if($base_status0_fix[$_k]){
            $rowstr .= $base_status0_fix[$_k];
        }
        $rowstr .= $v[$_k];
        if($base_status1_fix[$_k]){
            $rowstr .= $base_status1_fix[$_k];
        }
        $tmp[] = '<p>'.$rowstr.'</p>';
    }
    if($v['zsbq']){
        $tmp[] = '<p>'.lang_jy('zsbq',0).': '.$v['zsbq'].'</p>';
    }
    if($v['zsbq']){
        $tmp[] = '<p>'.lang_jy('wdah',0).': '.$v['wdah'].'</p>';
    }
    $tmp[] = '<div class="cl" style="width:100%;float:left;">';
    foreach ($v['album_ary'] as $index => $item) {
        $tmp[] = '<a class="mr5" href="'.$item.'" target="_blank"><img class="jthumb" src="'.$item.'" /></a>';
    }
    if($v['video']){
        $tmp[] = '<a class="mr5 pr" href="'.$v['video'].'" target="_blank"><img class="jthumb" src="'.$v['video_cover'].'" /><em class="emvdo"></em></a>';
    }
    $tmp[] = '</div>';
    $baseinfo.= implode('', $tmp) .'</div>';

    $zobzinfo = '<div class="jlcltags cl acti_s">';
    $tmp = array();
    foreach ($zotj as $index => $_v) {
        if(!$v[$_v]){
            continue;
        }
        $rowstr = '';
        if($base_status0_fix[$_v]){
            $rowstr .= $base_status0_fix[$_v];
        }
        $rowstr .= $v[$_v];
        $tmp[] = '<p>'.$rowstr.'</p>';
    }
    if($v['y_note']){
        $tmp[] = '<p>'.lang_jy('y_note',0).': '.$v['y_note'].'</p>';
    }
    $zobzinfo.= implode('', $tmp) .'</div>';

    $prename = '';
    if($v['is_dig']){
        $prename .= '<span style="left: 5px;" class=" is_dig is_vip">'.lang_jy('dig',0).'</span>';
    }
    $prename2 = '<div><b>'.$v['nickname'].'</b></div>';

    $extname = ' ';
    if($v['is_vip']||$v['verify']){
        $extname .= '<span class="pr-1">';
        if($v['verify']){
            $tb = $_G[cache][plugin][xigua_hr][grtb] ? $_G[cache][plugin][xigua_hr][grtb] : 'source/plugin/xigua_jy/static/img/sm.png';
            $extname .= '<img class="rzimg2" src="'.$tb.'?{VERHASH}" />';
        }
        if( $v['is_vip']){
            $extname .= '<img class="rzimg2" src="'.$v['vip_icon'].'?{VERHASH}">';
            $extname .= '<b class="red">'.$v['vip_name'].'</b>';
            $extname .=  '<br><em class="c9">'.lang_jy('yxq',0).' : </em>'.date('Y-m-d H:i', $v['vip_endts']);
        }
    }
    $extname .= '</span>';

    $ts_u = array();
    $dig_endts_u = date('Y-m-d H:i', $v['dig_endts']);
    $ts_u[] = lang_jy('crts',0).': <em class="nowarp">'.$v['crts_u'].'</em>';
    $ts_u[] = lang_jy('upts',0).': <em class="nowarp">'.$v['upts_u'].'</em>';
    if($v['dig_startts']){
        $ts_u[] = lang_jy('dig_start',0).': <em class="nowarp">'.date('Y-m-d H:i', $v['dig_startts']).'</em>';
    }
    if($v['dig_endts']) {
        $ts_u[] = lang_jy('dig_end',0).': <em class="nowarp">' .$dig_endts_u.'</em>';
    }
    $ts_u = implode('<br>', $ts_u);
    $btns = array();

    $shows_u = "<select class='w56' name=\"row[$id][shows]\">";
    foreach ($shows_ary as $k => $vv) {
        if ($v['shows'] == $k) {
            $s = 'selected';
        } else {
            $s = '';
        }
        $shows_u .= "<option $s value=\"$k\">{$vv}</option>";
    }
    $shows_u .= '</select>';

    $btns[] = "<div>$status_u  $shows_u</div>";

    $btns[] = "<div><a class=\"btn bg_green btnwd btn2\" href=\"$basehref&secid=$id\">" . lang_jy('edit', 0) . '</a>'.
    "<a class=\"btn bg_green btnwd btn2\" href=\"$basehref&qxtcid=$id&type=qxtc\">&#20184;&#36153;&#35760;&#24405;"  . '</a></div>';
    $btns[] = "<div><a class=\"btn bg_yellow btnwd btn2\" target='_blank' href=\"$qianxianpage$id\">&#29301;&#32447;&#35760;&#24405;" . '</a>'.
    "<a class=\"btn bg_yellow btnwd btn2\" href=\"javascript:;\" onclick=\"_show_zd_profile('".$v['nickname'].'\',\''.$dig_endts_u.'\','.$id.")\">" . lang_jy('zd1', 0) . '</a></div>';
    $btns[] = "<div><a class=\"btn bg_yellow btnwd btn2\" href=\"javascript:;\" onclick=\"_show_vip_profile('".$v['nickname'].'\',\''.$v['vip_name'].'\','.$id.")\">" . lang_jy('szvip', 0) . '</a>'.
    '<a class="btn bg_yellow btnwd btn2" href="javascript:;" onclick="_show_hn_profile(\''.$v['nickname'].'\',\''.$v['hnids'].'\','.$id.');">'.lang_jy('szhn',0).'</a></div>';
    $btns[] = '<div><a class="btn bg_yellow btnwd btn2" href="javascript:;" onclick="_show_sh_profile(\''.$v['nickname'].'\',\''.$v['shows'].'\','.$id.', \''.$v['reson'].'\');">'.lang_jy('dsh',0).'</a>'.
        '<a class="btn bg_yellow btnwd btn2" href="javascript:;" onclick="_show_zl_profile(\''.$v['nickname'].'\',\''.$v['base_status'].'\','.$id.');">&#23436;&#21892;&#29366;&#24577;</a>'
        .'</div>';
    $btns = implode(' ', $btns);
    $btns = "<div>$btns</div>";

    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
        "<div class='tc2'><div class='pr pr2'><img src='$thumb' class='jthumb' /><i class=\"memli_gender g{$v['gender']}\"></i> $prename </div> $prename2</div>",
        $extname.'<br>'.
        $userinfo,
        $baseinfo,
        $zobzinfo,
        $btns,
        $ts_u,
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_hong&lpp=$lpp&" . http_build_query($_GET), 0, 10);
showsubmit('permsubmit', 'submit', 'del', "", $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter();
?>

<div id="rsel_menu" class="custom cmain" style="display:none;width:400px;height:170px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr"></h3>
    </div>
    <div id="rsel_content" style="overflow-y:auto;height:95%">
<?php
$hns_u = "<select id='hn_ids' multiple name=\"hn_ids[]\">";
foreach ($hns as $k => $vv) {
    $hns_u .= "<option value=\"{$vv['id']}\">{$vv['name']}</option>";
}
$hns_u .= '</select>';
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&keyword=$keyword&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status");
?>
        <table class="tb tb2 ">
            <tr class="hover">
                <td ><?php echo lang('plugin/xigua_jy','hn'); ?></td>
                <td><?php echo $hns_u;?></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="yhid" id="yhid" value="0">
                    <input type="submit" class="btn" name="editsubmit" value="<?php echo lang('plugin/xigua_hb','queding'); ?>" />
                </td>
            </tr>
        </table>
        <?php showformfooter();?>
    </div>
</div>
<div id="zd_menu" class="custom cmain" style="display:none;width:400px;height:220px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr2"></h3>
    </div>
    <div id="zd_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&keyword=$keyword&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status");
        ?>
        <table class="tb tb2 ">
            <?php
            showsetting(lang_jy('dig_endts',0), "zd_endts", '', 'calendar', '', 0, '',1);
            ?>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="yhid2" id="yhid2" value="0">
                    <?php
                    showsubmit('dosubmit2');
                    ?>
                </td>
            </tr>
        </table>
        <?php showformfooter();?>
    </div>
</div>
<div id="vip_menu" class="custom cmain" style="display:none;width:400px;height:150px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr3"></h3>
    </div>
    <div id="vip_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&keyword=$keyword&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status");

        $vip_u = "<select id='vips_names' name=\"vipnames\">";
        $vip_u .= '<option value="">'.lang_jy('wu',0).'</option>';
        foreach ($vip_taocan as $k => $vv) {
            $vip_u .= "<option value=\"{$vv['name']}\">{$vv['name']} ".lang_jy('yxq',0)."{$vv['days']}".lang_jy('d',0)." {$vv['desc']} </option>";
        }
        $vip_u .= '</select>';
        ?>
        <table class="tb tb2 ">
            <tr class="hover">
                <td ><?php echo lang('plugin/xigua_jy','viplevel'); ?></td>
                <td><?php echo $vip_u;?></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="yhid3" id="yhid3" value="0">
                    <?php
                    showsubmit('dosubmit3');
                    ?>
                </td>
            </tr>
        </table>
        <?php showformfooter();?>
    </div>
</div>

<div id="she_menu" class="custom cmain" style="display:none;width:400px;height:220px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr4"></h3>
    </div>
    <div id="she_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&keyword=$keyword&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby&base_status=$base_status");

        $s_u = "<select id='vip_shows' name=\"vip_shows\">";
        foreach ($shows_ary as $k => $vv) {
            $s_u .= "<option value=\"{$k}\">{$vv}</option>";
        }
        $s_u .= '</select>';
        ?>
        <table class="tb tb2 ">
            <tr class="hover">
                <td ><?php echo lang('plugin/xigua_jy','shenhe'); ?></td>
                <td><?php echo $s_u;?></td>
            </tr>
            <tr class="hover">
                <td ><?php echo lang('plugin/xigua_jy','reson'); ?></td>
                <td><input type='text' class='txt' name='reson' id="reson" value='' style="width:240px" /></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="yhid4" id="yhid4" value="0">
                    <?php
                    showsubmit('dosubmit4');
                    ?>
                </td>
            </tr>
        </table>
        <?php showformfooter();?>
    </div>
</div>
<div id="mybase_menu" class="custom cmain" style="display:none;width:400px;height:150px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr5"></h3>
    </div>
    <div id="mybase_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_jy&pmod=admin_man&keyword=$keyword&page=$page&lpp=$lpp&keyword=$keyword&status=$status&shows=$shows&hnid=$hnid&orderby=$orderby");

        $vip_u = "<select id='new_base_status' name=\"new_base_status\">";
        foreach (array('0' => lang_jy('zlxws',0), '1' => lang_jy('zlyws',0), ) as $k => $vv) {
            $vip_u .= "<option value=\"{$k}\">{$vv}</option>";
        }
        $vip_u .= '</select>';
        ?>
        <table class="tb tb2 ">
            <tr class="hover">
                <td >&#36164;&#26009;&#29366;&#24577;</td>
                <td><?php echo $vip_u;?></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="yhid5" id="yhid5" value="0">
                    <?php
                    showsubmit('dosubmit5');
                    ?>
                </td>
            </tr>
        </table>
        <?php showformfooter();?>
    </div>
</div>

<script type="text/javascript" src="static/js/calendar.js"></script>
<script>
function _show_hn_profile(nickname, hnid, yhid) {
    showMenu({'ctrlid': 'rsel', 'evt': 'click', 'duration': 3, 'pos': '00'});
    var hnid_ary = hnid.split(',');
    var sel=$('hn_ids');
    for(var i=0;i <sel.options.length;i++){
        if(in_array(sel.options[i].value, hnid_ary)){
            sel.options[i].selected=true;
        }else{
            sel.options[i].selected=false;
        }
    }
    $('yhid').value = yhid;
    $('cnotr').innerHTML = '<?php echo lang('plugin/xigua_hb','xiugai')?>'+nickname+'<?php echo lang('plugin/xigua_jy','de').lang('plugin/xigua_jy','hn'); ?>';
}
function in_array(needle, haystack) {
    if(typeof needle == 'string' || typeof needle == 'number') {
        for(var i in haystack) {
            if(haystack[i] == needle) {
                return true;
            }
        }
    }
    return false;
}
function _show_zd_profile(nickname, dig_endts, yhid) {
    showMenu({'ctrlid': 'zd', 'evt': 'click', 'duration': 3, 'pos': '00'});
    $('yhid2').value = yhid;
    $('cnotr2').innerHTML = '<?php lang_jy('dig', 1)?> '+nickname;
}
function _show_vip_profile(nickname, vipname, yhid) {
    showMenu({'ctrlid': 'vip', 'evt': 'click', 'duration': 3, 'pos': '00'});
    var sel=$('vips_names');
    for(var i=0;i <sel.options.length;i++){
        if(sel.options[i].value == vipname){
            sel.options[i].selected=true;
        }else{
            sel.options[i].selected=false;
        }
    }
    $('yhid3').value = yhid;
    $('cnotr3').innerHTML = '<?php lang_jy('szvip',1)?> '+nickname;
}
function _show_sh_profile(nickname, shows, yhid, reson) {
    showMenu({'ctrlid': 'she', 'evt': 'click', 'duration': 3, 'pos': '00'});
    var sel=$('vip_shows');
    for(var i=0;i <sel.options.length;i++){
        if(sel.options[i].value == shows){
            sel.options[i].selected=true;
        }else{
            sel.options[i].selected=false;
        }
    }
    $('yhid4').value = yhid;
    $('reson').value = reson;
    $('cnotr4').innerHTML = '<?php lang_jy('shenhe', 1)?> '+nickname;
}
function _show_zl_profile(nickname, new_status, yhid) {
    showMenu({'ctrlid': 'mybase', 'evt': 'click', 'duration': 3, 'pos': '00'});
    var sel=$('new_base_status');
    for(var i=0;i <sel.options.length;i++){
        if(sel.options[i].value == new_status){
            sel.options[i].selected=true;
        }else{
            sel.options[i].selected=false;
        }
    }
    $('yhid5').value = yhid;
    $('cnotr5').innerHTML = '<?php lang_jy('queding',1)?> '+nickname;
}
</script>