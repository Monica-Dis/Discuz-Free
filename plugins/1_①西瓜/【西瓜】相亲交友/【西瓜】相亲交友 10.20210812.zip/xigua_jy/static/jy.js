$(document).on('click', '.join_label label', function () {
    var that = $(this);
    $('.join_label label').addClass('gender_off').removeClass('gender_on');
    that.removeClass('gender_off').addClass('gender_on');
});

function _setTypeid(id, obj, formname) {
    if ($(obj).hasClass('tag-on')) {
        $(obj).removeClass('tag-on');
        $('input[name="form['+formname+'][' + id + ']"]').val('0');
    } else {
        var MaxTagNum = parseInt($(obj).parent().data('max'));
        var nowNum = $(obj).parent().find('.tag-on').length;
        if(MaxTagNum==1){
            $(obj).parent().find('.tag-on').removeClass('tag-on');
            $(obj).parent().find('input').val('0');
            $(obj).addClass('tag-on');
            $('input[name="form['+formname+'][' + id + ']"]').val('1');
            return false;
        }else if (MaxTagNum > 0 && nowNum > MaxTagNum - 1) {
            return false;
        }
        $(obj).parent().parent().find('.nownum').html(nowNum+1);
        $(obj).addClass('tag-on');
        $('input[name="form['+formname+'][' + id + ']"]').val('1');
    }
}
$(document).on('click','.memli_jump', function () {
    var id = $(this).attr('data-id');
    hb_jump(_APPNAME+'?id=xigua_jy&ac=view&jyid='+id);
});
$(document).on('click', '.sxuan', function () {
    var popcm = $('#popup_sx');
    popcm.popup();
    popcm.show();
    setTimeout(function () {
        popcm.show();
    }, 500);
    return false;
});


$(document).on('click','.check_box li', function () {
    var that = $(this);
    var cbox =that.parent().parent();
    if(that.data('backto')) {
        cbox.find('.filterjobwant').show();
        cbox.find('.zkbtn').show();
        that.parent().hide();
    }else if(that.data('sub')){
        that.addClass('oncheck');
        that.siblings().removeClass('oncheck');

        cbox.find('.check_box_sub').hide();
        cbox.find('.subid_'+that.data('sub')).show();

        cbox.find('.filterjobwant').hide();
        cbox.find('.zkbtn').hide();
    }else{
        if(that.index()===0){
            that.addClass('oncheck');
            that.siblings().removeClass('oncheck');
        }else{
            that.addClass('oncheck');
            if(that.data('only')){
                that.siblings().removeClass('oncheck');
            }else{
                that.parent().find('li:first-child').removeClass('oncheck');
            }
        }
    }
});
$(document).on('click','.confirm-filter', function () {
    var args = {};
    $('.oncheck').each(function () {
        var that = $(this);
        if(args[that.data('name')]){
            args[that.data('name')] += ','+that.data('id');
        }else{
            args[that.data('name')] = that.data('id');
        }
    });
    var get_args = url_Encode(args);
    jy_setlist(null, get_args);
    $.closePopup();
});
function jy_getparget(){
    var rst = '';
    var $_GET = (function(){
        var url = window.location.href.toString();
        var u = url.split("?");
        if(typeof(u[1]) === "string"){
            u = u[1].split("&");
            var get = {};
            for(var i in u){
                var j = u[i].split("=");
                if(typeof j[0] !=='undefined' && typeof j[1] !=='undefined'){
                    get[j[0]] = j[1];
                }
            }
            return get;
        } else {
            return {};
        }
    })();
    for(var i in $_GET){
        rst += i+"="+$_GET[i]+"&";
    }
    return '?'+rst;
}
function jy_setlist(that, ext){
    var lin = jy_getparget();
    page = 1;lm = false;
    loadingurl = _APPNAME+lin+'&ac=mem_li'+ext+'&page=';
    console.log(loadingurl);
    // history.replaceState(null,'', loadingurl.replace(/\&ac\=mem_li/g, '').replace(/\&inajax\=1/g, ''));
    if(that!==null){
        that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
    }
    DOAPPEND = 0;
    $.ajax({
        type: 'get',
        url: loadingurl+''+page,
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            $('#loading-show').addClass('hidden');
            if(!s){
                $('#loading-show').addClass('hidden');
                $('#loading-none').removeClass('hidden');
                setTimeout(function () {
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                }, 300);
                $("#list").html(s);
                page = -1;lm = false;
                return ;
            }
            $("#list").html(s);
            page ++;lm = false;
        },
        error: function() {}
    });
}
function url_Encode(param, key, encode) {
    if(param==null) return '';
    var paramStr = '';
    var t = typeof (param);
    if (t === 'string' || t === 'number' || t === 'boolean') {
        paramStr += '&' + key + '=' + ((encode==null||encode) ? (param) : param);
    } else {
        for (var i in param) {
            var k = key == null ? i : key + (param instanceof Array ? '[' + i + ']' : '.' + i);
            paramStr += url_Encode(param[i], k, encode);
        }
    }
    return paramStr;
}
$(document).on('click','#dosearch', function () {
    var val = $('#searchInput').val();
    if(val){
        $('#searchInput').addClass('oncheck').data('id', val);
        $('.confirm-filter').trigger('click');
    }else{
        $.alert($('#searchInput').attr('placeholder'));
    }
});
$(document).on('click','.qxsearch', function () {
    $('#searchInput').removeClass('oncheck').val('');
});
$(document).on('click','.close-reset', function () {
    $('.check_box li').removeClass('oncheck');
    $('.check_box').each(function () {
        var that = $(this);
        if(!that.hasClass('check_box_sub')) {
            that.find('li:first-child').addClass('oncheck');
        }
    });
});

$(document).on('click','.hn_wx', function () {
    var that = $(this);
    $.alert('<img src="'+that.data('qrcode')+'" />'+that.data('tip'));
});
$(document).on('click','.oneline', function () {
    var that = $(this);
    $.ajax({
        type: 'post', url: _APPNAME + '?id=xigua_jy&ac=my&do=oneline&inajax=1',
        data: {'formhash': FORMHASH, 'backuid': that.attr('data-uid')}, dataType: 'xml', success: function (data) {
            $.hideLoading();
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        }
    });
});
$(document).on('click','.lahei', function () {
    var that = $(this);
    var tiph = '';
    if(that.data('inhei')){
        tiph = tiphqj;
    }else{
        tiph = tiphlhh;
    }
    $.confirm(tiph, function() {
        $.ajax({
            type: 'post', url: _APPNAME + '?id=xigua_jy&ac=my&do=lahei&inajax=1',
            data: {'formhash': FORMHASH, 'laheiuid': that.attr('data-uid'), 'inhei':that.data('inhei')},
            dataType: 'xml', success: function (data) {
                $.hideLoading();
                if (null == data) {
                    tip_common('error|' + ERROR_TIP);
                    return false;
                }
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            }
        });
    }, function() {});
});
$(document).on('click','.video_v_icon', function () {
    var video_obj = $('#video_set'), that = $(this);
    if (video_obj[0].paused){
        video_obj[0].play();
        that.hide();
        if(is_ios()){
            video_obj[0].webkitEnterFullscreen();
        }else{
            video_obj[0].webkitRequestFullScreen();
        }
        video_obj.attr('controls', "controls");
    }else{
        video_obj[0].pause();
        that.show();
    }
});

function is_ios(){
    var ua = navigator.userAgent.toLowerCase();
    return (ua.indexOf('iphone') !== -1) || (ua.indexOf('ipad') !== -1);
}