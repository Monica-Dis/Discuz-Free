<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2020/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);
include_once DISCUZ_ROOT.'source/plugin/xigua_jy/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_jy/common_status.php';

function jy_dig_taocan_callback($param){
    $info = $param['info'];
    $order_id = $param['order_id'];
    $data = $info['data'];
    $old_data = C::t('#xigua_jy#xigua_jy_user')->fetch($data['uid']);
    $lastts = max($old_data['dig_endts'], TIMESTAMP);

    C::t('#xigua_jy#xigua_jy_user')->update($data['uid'], array(
        'dig_startts' => TIMESTAMP,
        'dig_endts' => $data['days']*86400+$lastts,
    ));
    return true;
}
function jy_line_taocan_callback($param){
    $info = $param['info'];
    $order_id = $param['order_id'];
    $data = $info['data'];
    $endts = $data['endays']>0 ? $data['endays']*86400+TIMESTAMP : 0;
    $newdata = array(
        'type'  => 'line',
        'uid'   => $data['uid'],
        'name'  => $data['name'],
        'price' => $data['price'],
        'total' => $data['times'],
        'used' => 0,
        'crts' => TIMESTAMP,
        'upts' => TIMESTAMP,
        'payts' => TIMESTAMP,
        'endts' => $endts,
        'order_id' => $order_id,
    );
    C::t('#xigua_jy#xigua_jy_taocan')->insert($newdata);
    return true;
}
function jy_vip_taocan_callback($param){
    /*$vip_taocan*/
    $info = $param['info'];
    $order_id = $param['order_id'];
    $data = $info['data'];
    $old_data = C::t('#xigua_jy#xigua_jy_user')->fetch($data['uid']);
    $lastts = max($old_data['vip_endts'], TIMESTAMP);
    $vip_endts = $data['vipinfo']['days']*86400+$lastts;

    C::t('#xigua_jy#xigua_jy_user')->update($data['uid'], array(
        'vip_index' => $data['vipindex'],
        'vip_name' => $data['vipinfo']['name'],
        'vip_startts' => TIMESTAMP,
        'vip_endts' => $vip_endts,
        'vip_info' => serialize($data['vipinfo']),
    ));

    if($data['vipinfo']['digdays']){
        $lastts = max($old_data['dig_endts'], TIMESTAMP);
        C::t('#xigua_jy#xigua_jy_user')->update($data['uid'], array(
            'dig_startts' => TIMESTAMP,
            'dig_endts' => $data['vipinfo']['digdays']*86400+$lastts,
        ));
    }
    if($data['vipinfo']['qianxian']){
        $newdata = array(
            'type'  => 'line',
            'uid'   => $data['uid'],
            'name'  => lang_jy('gm',0).$data['vipinfo']['name'].lang_jy('zs',0).' '.$data['vipinfo']['qianxian'],
            'price' => 0,
            'total' => $data['vipinfo']['qianxian'],
            'used' => 0,
            'crts' => TIMESTAMP,
            'upts' => TIMESTAMP,
            'payts' => 0,
            'endts' => $vip_endts,
            'order_id' => '',
        );
        C::t('#xigua_jy#xigua_jy_taocan')->insert($newdata);
    }

    return true;
}

function jy_danci_callback($param){
    $info = $param['info'];
    $order_id = $param['order_id'];
    $data = $info['data'];
    $newdata = array(
        'type'  => 'line',
        'uid'   => $data['uid'],
        'name'  => $data['name'],
        'price' => $data['price'],
        'total' => 1,
        'used' => 0,
        'crts' => TIMESTAMP,
        'upts' => TIMESTAMP,
        'payts' => TIMESTAMP,
        'endts' => 0,
        'order_id' => $order_id,
    );
    C::t('#xigua_jy#xigua_jy_taocan')->insert($newdata);
}

function jy_shows_callback($param){
    $info = $param['info'];
    $order_id = $param['order_id'];
    $data = $info['data'];

    C::t('#xigua_jy#xigua_jy_user')->update($data['uid'], array(
        'shows' => 1,
        'order_id' => $order_id,
    ));
}