<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2020/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
$t =lang('plugin/xigua_hb','fangwen'). $_G['siteurl'].'plugin.php?id=xigua_wr&high=1<br><br><p style="display:none">:</p>';
cpmsg($t, '','succeed');