<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_wr_viewlog extends discuz_table
{
    public function __construct() {

        $this->_table = 'xigua_wr_viewlog';
        $this->_pk    = 'id';

        parent::__construct(); /*dism_ taobao_ com*/
    }

    public function do_insert($uid, $type, $type_desc = '')
    {
        /*C::t('#xigua_wr#xigua_wr_viewlog')->do_insert($uid);*/
        global $_G;
        $data = array(
            'uid' => $uid,
            'act' => $type,
            'actdesc' => $type_desc,
            'crts' => TIMESTAMP,
            'crdate' => date('Y-m-d', TIMESTAMP),
        );

        return parent::insert($data);
    }

}