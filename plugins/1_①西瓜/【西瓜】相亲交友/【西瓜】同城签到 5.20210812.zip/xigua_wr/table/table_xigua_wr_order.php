<?php
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_wr_order extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_wr_order';
        $this->_pk = 'id';

        parent::__construct(); /*dism_ taobao_ com*/
    }


    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        global $good, $_G;
        if($good['danci']>0 && $data['gnum']>$good['danci']){
            hb_message(lang_wr('dancigmbn',0).$good['danci'].lang_wr('fen',0), 'error');
            return false;
        }
        return DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
    }

    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        return DB::update($this->_table, $data, array(
            'uid' => $_G['uid'],
            'id'  => $id,
        ));
    }

    public function fetch_G($id){
        global $_G;
        $r = DB::fetch_first('select * from %t WHERE id=%d AND uid=%d', array(
            $this->_table,
            $id,
            $_G['uid'],
        ));
        $r = self::prepare($r);
        return $r;
    }
    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*', $need_user = 0)
    {
        global $_G, $SCRITPTNAME,$urlext;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));

        $uids = $shids = array();


        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $uids[] = $item['uid'];
            $shids[] = $item['shid'];
        }
        if($need_user && $uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['username'] = $users[$item['uid']]['username'];
            }
        }
        return $result;
    }
    public function fetch_count_by_where($wherearr)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first("SELECT count(*) as cnt FROM " . DB::table($this->_table) . " $wheresql ");
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_by_gid($gid)
    {
        $ret = $this->fetch($gid);
        $ret = self::prepare($ret);


        return $ret;
    }

    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }

    public static function prepare($v)
    {
        global $_G, $SCRITPTNAME,$urlext,$tuan_id;
        if($v){

            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i:s', $v['crts']) : '';
            $v['pay_ts_u'] = $v['pay_ts']>0 ? date('Y-m-d H:i:s', $v['pay_ts']) : '';
            $v['shou_ts_u'] = $v['shou_ts']>0 ? date('Y-m-d H:i:s', $v['shou_ts']) : '';
            $v['tuicfm_ts_u'] = $v['tuicfm_ts']>0 ? date('Y-m-d H:i:s', $v['tuicfm_ts']) : '';
            $v['shixian_u'] = $v['shixian'] ? date('Y-m-d H:i:s', $v['shixian']) : '';
            $v['goodshot'] = unserialize($v['goodinfo']);

            if($v['order_id'] && $v['status'] == 1){
                $order_id = $v['order_id'];
                $good = C::t('#xigua_wr#xigua_wr_good')->fetch_by_gid($v['gid']);
                if($good['stock']<$v['gnum']){
                    $v['jumpurl'] = 'javascript:$.alert(\''.lang_wr('kcbz',0).'\');';
                }else{
                    $rl = urlencode($_G['siteurl'].$SCRITPTNAME."?id=xigua_wr&ac=order_profile$urlext&ptlog_id=".$v['id']);
                    $v['jumpurl'] = "$SCRITPTNAME?id=xigua_hb&ac=pay&order_id=$order_id&rl=".urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hb&ac=mypub&rl=$rl");
                }
            }
        }
        return $v;
    }

}