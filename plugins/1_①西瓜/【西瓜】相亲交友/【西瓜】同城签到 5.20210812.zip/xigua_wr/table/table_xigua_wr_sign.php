<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_wr_sign extends  discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_wr_sign';
        $this->_pk = 'id';

        parent::__construct(); /*dism_ taobao_ com*/
    }

    public function get_list_month($uid, $date = '')
    {
        $nowm = date('n', strtotime($date));
        $hasigns = DB::fetch_all('SELECT signdate FROM %t WHERE uid=%d AND signmonth=%d', array($this->_table, $uid, $nowm), 'signdate');
        $odays = $this->get_day_array(date('Y-m-d'));
        $days = array();
        foreach ($odays as $index => $day) {
            if(strtotime($day)<=TIMESTAMP){
                $days[$day] = $hasigns[$day] ? 1 : -1;
            }
        }
        return $days;
    }

    public function sign_now($ts)
    {
        global $wr_config, $_G;
        $getexp = $wr_config['sign_get'];
        if($wr_config['sign_rand']){
            list($minrand, $maxrand) = explode('-', trim($wr_config['sign_rand']));
            if(is_numeric($minrand) && is_numeric($maxrand) && $minrand>0 && $minrand<$maxrand){
                $getexp += mt_rand($minrand, $maxrand);
            }
        }
        $date = date('Y-m-d', $ts);
        if($this->check_sign($_G['uid'], $date)){
            hb_message(lang_wr('nyqd',0), 'error', 'reload');
        }
        $signday = date('d', $ts);
        $signmonth = date('n', $ts);
        $isbu = $date == date('Y-m-d', TIMESTAMP) ? 0 : 1;

        $ctitle = $_G['setting']['extcredits'][$wr_config['ctypee']]['title'];
        $cunit = $_G['setting']['extcredits'][$wr_config['ctypee']]['unit'];
        $myccount = getuserprofile('extcredits' . $wr_config['ctypee']);

        if($isbu){
            if($myccount<$wr_config['bqjf']){
                hb_message($ctitle.lang_wr('buzu',0).$wr_config['bqjf'].$cunit.' '.lang_wr('bqsb',0), 'error');
            }
            updatemembercount( $_G['uid'], array($wr_config['ctypee'] => -$wr_config['bqjf']), 1, 'WR', $_G['uid'], '', lang_wr('bqxh',0).$wr_config['bqjf'].$cunit.$ctitle);
        }

        $rowlianxu = $this->get_lasted( $_G['uid']);
        $parse_line = $this->parse_line($wr_config['sign_line']);
        $total_line = $this->parse_line($wr_config['sign_total']);

        $lx = $rowlianxu['lianxu']+1;
        $tt = $rowlianxu['total']+1;

        $linexp = $parse_line[$lx];
        $leijiexp = $total_line[$tt];


        $id = parent::insert(array(
            'uid'  => $_G['uid'],
            'crts' => TIMESTAMP,
            'signmonth' => $signmonth,
            'signday' => $signday,
            'signdate' => $date,
            'isbu' => $isbu,
            'getexp' => $getexp,
            'linexp' => $linexp,
            'leijiexp' => $leijiexp,
        ), true, false, true);
        if($id){
            $qdword = $isbu ? lang_wr('bq',0) : lang_wr('sign',0);
            $title = $qdword.lang_wr('cg',0).' <em class="cred1 main_color">+'.$getexp.$cunit.$ctitle.'</em>';
            updatemembercount( $_G['uid'], array($wr_config['ctypee'] => $getexp), 1, 'WR', $_G['uid'], '', strip_tags($title));
            if($linexp>0){
                $title1 = '<br>'.lang_wr('lxqd',0).$lx.lang_wr('tian',0).','.lang_wr('ewjl',0).' <em class="cred1 main_color">+'.$linexp.$cunit.$ctitle.'</em>';
                $title .= $title1;
                updatemembercount( $_G['uid'], array($wr_config['ctypee'] => $linexp), 1, 'WR', $_G['uid'], '', strip_tags($title1));
            }
            if($leijiexp>0){
                $title1 = '<br>'.lang_wr('zjqdm',0).$tt.lang_wr('tian',0).','.lang_wr('ewjl',0).' <em class="cred1 main_color">+'.$leijiexp.$cunit.$ctitle.'</em>';
                $title .= $title1;
                updatemembercount( $_G['uid'], array($wr_config['ctypee'] => $leijiexp), 1, 'WR', $_G['uid'], '', strip_tags($title1));
            }
            $this->update($id, array('note' => $title));
            hb_message($title, 'success');
        }
        return $id;
    }

    public function check_sign($uid, $date)
    {
        return DB::fetch_first('SELECT * FROM %t WHERE uid=%d AND signdate=%s', array($this->_table, $uid, $date), 'signdate');
    }

    public function get_lasted($uid)
    {
        $today = date('Y-m-d');
        $days = $this->get_day_array($today);
        $signmonth = date('n', TIMESTAMP);
        $signlist = DB::fetch_all('SELECT * FROM %t WHERE uid=%d AND signmonth=%d', array($this->_table, $uid, $signmonth), 'signdate');
        $lianxu = 1;
        foreach ($days as $index => $day) {
            if(strtotime($day)>TIMESTAMP){
                break;
            }
            if($signlist[$day]){
                $lianxu++;
            }elseif($today==$day){
            }else{
                $lianxu = 0;
            }
        }
        return array('total'=>count($signlist), 'lianxu' => $lianxu);
    }

    public function get_day_array($date ,$rtype = '2')
    {
        $tem = explode('-' , $date);
        $year = $tem['0'];
        $month = $tem['1'];
        if( in_array($month , array( 1 , 3 , 5 , 7 , 8 , '01' , '03' , '05' , '07' , '08' , '10' , '12'))) {
            $text = '31';
        }elseif( $month == 2 ){
            if ( $year%400 == 0 || ($year%4 == 0 && $year%100 !== 0) ){
                $text = '29';
            }else{
                $text = '28';
            }
        }else{
            $text = '30';
        }
        for ($i = 1; $i <= $text ; $i ++ ) {
            $r[] = $year."-".$month."-".(str_pad($i, '2', '0', STR_PAD_LEFT));
        }
        return $r;
    }

    public function parse_line($str){
        $sign_lines = array();
        $sign_line = array_filter(explode("\n", trim($str)));
        foreach ($sign_line as $index => $item) {
            list($day, $jifen) = explode('=', trim($item));
            if($day = intval($day)){
                $sign_lines[$day] = intval($jifen);
            }
        }
        return $sign_lines;
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*', $need_user = 0)
    {
        global $_G, $SCRITPTNAME,$urlext;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));

        $uids =  array();


        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
            $uids[] = $item['uid'];
        }
        if($need_user && $uids){
            $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
            foreach ($result as $index => $item) {
                $result[$index]['username'] = $users[$item['uid']]['username'];
            }
        }
        return $result;
    }
    public function fetch_count_by_where($wherearr)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first("SELECT count(*) as cnt FROM " . DB::table($this->_table) . " $wheresql ");
        return $result;
    }
    public function fetch_all_by_array($wherearr, $start_limit = 0, $lpp  = 20, $orderby = '', $fields= '*')
    {
        global $_G;
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '. DB::implode( $wherearr, 'AND') : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public static function prepare($v)
    {
        if($v){

        }
        return $v;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }
}