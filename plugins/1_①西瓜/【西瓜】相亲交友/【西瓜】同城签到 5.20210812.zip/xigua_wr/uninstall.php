<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2020/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT

DROP TABLE pre_xigua_wr_good;
DROP TABLE pre_xigua_wr_nav;
DROP TABLE pre_xigua_wr_order;
DROP TABLE pre_xigua_wr_sign;
DROP TABLE pre_xigua_wr_viewlog;

EOT;
runquery($sql);


@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/install.php');

xwb_delall(DISCUZ_ROOT . "./source/plugin/xigua_wr");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_wr");

$finish = TRUE;

function xwb_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwb_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}