<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2019/1/21
 * Time: 17:42
 */

if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!$_GET['inajax'] && $_G['uid']){
    if(  $_GET['ac']=='view' && $_GET['pubid'] && strpos($_GET['id'], 'xigua_hb')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_hb');
    }
    if(  $_GET['ac']=='view' && $_GET['shid'] && strpos($_GET['id'], 'xigua_hs')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_hs');
    }
    if(  $_GET['ac']=='seckill_view' && $_GET['secid'] && strpos($_GET['id'], 'xigua_hm')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_hm');
    }
    if(  $_GET['ac']=='view' && $_GET['cdid'] && strpos($_GET['id'], 'xigua_cd')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_cd');
    }
    if( ( $_GET['ac']=='view'&&$_GET['needid'] || $_GET['ac']=='shifu'&&$_GET['shifuid'] ) && strpos($_GET['id'], 'xigua_ho')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_ho');
    }
    if( ( $_GET['ac']=='view'&&$_GET['jobid'] || $_GET['ac']=='resume_view'&&$_GET['rsid'] ) && strpos($_GET['id'], 'xigua_job')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_job');
    }
    if( ( $_GET['ac']=='view'&&$_GET['qunid'] ) && strpos($_GET['id'], 'xigua_hf')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_hf');
    }
    if( ( $_GET['ac']=='view'&&$_GET['shid'] ) && strpos($_GET['id'], 'xigua_dh')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_dh');
    }
    if( ( $_GET['ac']=='view'&&$_GET['cid'] ) && strpos($_GET['id'], 'xigua_dp')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_dp');
    }
    if( ( $_GET['ac']=='view'&&$_GET['gid'] ) && strpos($_GET['id'], 'xigua_sp')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_sp');
    }
    if( ( $_GET['ac']=='view'&&$_GET['hid'] ) && strpos($_GET['id'], 'xigua_he')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_he');
    }

    if( ( $_GET['ac']=='view'&&$_GET['mpid'] ) && strpos($_GET['id'], 'xigua_hp')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_hp');
    }
    if( ( $_GET['ac']=='view'&&$_GET['gid'] ) && strpos($_GET['id'], 'xigua_hk')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_hk');
    }
    if( ( $_GET['ac']=='view'&&$_GET['did'] ) && strpos($_GET['id'], 'xigua_hd')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_hd');
    }
    if( ( $_GET['ac']=='view'&&$_GET['gid'] ) && strpos($_GET['id'], 'xigua_pt')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_pt');
    }
    if( ( $_GET['ac']=='view'&&$_GET['jyid'] ) && strpos($_GET['id'], 'xigua_jy')!==false && $_SERVER['REQUEST_METHOD'] == 'GET'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'view_jy');
    }
}
if($_GET['inajax'] && $_G['uid']){
    if(  $_GET['ac']=='enter' && $_GET['appappapp'] && !$_GET['edit'] && strpos($_GET['id'], 'xigua_hs')!==false && $_SERVER['REQUEST_METHOD'] == 'POST'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'join_hs');
    }else if(  $_GET['ac']=='join' && $_GET['months']  && strpos($_GET['id'], 'xigua_hh')!==false && $_SERVER['REQUEST_METHOD'] == 'POST'){
        include_once DISCUZ_ROOT.'source/plugin/xigua_wr/function.php';
        wr_get_reward($_G['uid'], 'join_hh');
    }
}