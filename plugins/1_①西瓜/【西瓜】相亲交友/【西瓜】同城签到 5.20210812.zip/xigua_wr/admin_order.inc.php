<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_wr/common.php';

$status_font = array(
    1 => lang_wr('status_1',0),
    2 => lang_wr('status_2',0),
//    3 => lang_wr('status_3',0),
    4 => lang_wr('status_4',0),
);


if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$sta = $status_font;


$page = max(1, intval($_GET['page']));
$lpp = $_GET['lpp'] ? $_GET['lpp'] : 20;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('ptlogid')){
    $ptlogid = $_GET['ptlogid'];
    if($_GET['yundan_gs'] && $_GET['yundan']){
        DB::update('xigua_wr_order', array(
            'fa_ts' => TIMESTAMP,
            'yundan_gs' => $_GET['yundan_gs'],
            'yundan' => $_GET['yundan'],
        ), array(
            'id' => $ptlogid
        ));
        unset($_GET['yundan_gs']);
        unset($_GET['yundan']);
        unset($_GET['formhash']);
        unset($_GET['permsubmit']);
        unset($_GET['ptlogid']);

        $v = C::t('#xigua_wr#xigua_wr_order')->fetch($ptlogid);
        notification_add($v['uid'],'system', "<a href=\"{url}\">".$v['title'].lang_wr('yfh',0).'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_wr&ac=order_profile&ptlog_id='.$v['id']),1);

        cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_order&".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
    }
}

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_wr#xigua_wr_order')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            if($item['status']>=97){
                unset($item['status']);
            }
            if($item['yundan'] || $item['yundan_gs']){
                $item['fa_ts'] = TIMESTAMP;
            }
            C::t('#xigua_wr#xigua_wr_order')->update($index, $item);
        }
    }
    unset($_GET['formhash']);
    unset($_GET['r']);
    unset($_GET['permsubmit']);
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_order&".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword'";
}elseif($keyword){
    $uids = DB::fetch_all("select uid from " . DB::table('common_member') . " where username like '%$keyword%' ", array(), 'uid');
    if ($uids) {
        $wherearr[] = "( uid in (".implode(',', array_keys($uids)).") OR  mobile like '%$keyword%' OR realname like '%$keyword%' OR title like '%$keyword%' OR goodinfo like '%$keyword%')";
    } else {
        $wherearr[] = " (mobile like '%$keyword%' OR realname like '%$keyword%' OR title like '%$keyword%' OR goodinfo like '%$keyword%')";
    }
}
$sta[97] = lang_wr('hx1',0);
$sta[98] = lang_wr('hx2',0);

$order = 'id desc';
if($_GET['status'] == 97){
    $wherearr[] = "status IN ( 2,6 ) AND fa_ts=-1";
    $order = 'pay_ts desc';

}elseif($_GET['status'] == 98){
    $wherearr[] = "status IN ( 2,6 ) AND fa_ts>1";
    $order = 'fa_ts desc';

}elseif($_GET['status'] == 99){
    $wherearr[] = "status IN ( 2,6 ) AND shou_ts>1";
    $order = 'shou_ts desc';
}

if($_GET['status']&&$_GET['status']<97){
    $wherearr[] = "status='".intval($_GET['status'])."'";
}

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_order");

echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_wr('searchinput',0).'" value="'.$_GET['keyword'].'" class="txt"  style="width: 220px;"/> ';

echo '<select name="status"><option value="0">'.lang_wr('qb',0).'</option>';
foreach ($sta as $index => $item) {
    $chk = isset($_GET['status']) && $_GET['status']==$index ? 'selected':'';
    echo " <option value=\"$index\" $chk>$item</option>";
}
echo '</select>';

echo '&nbsp;&nbsp;&nbsp;';
$lpp_se = "<select name=\"lpp\">";
foreach (array(1, 10 ,20, 50, 100, 200, 500, 1000, 2000, 5000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;

echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_order".' class="btn" >'.cplang('reset').'</a> ';


echo '</div>';

showtableheader(lang_wr('tichengmanage', 0));
$ress = array();

showtablerow('class="header"',array(),$ress[] = array(
    lang_hb('del', 0),
    lang_wr('ID', 0),
    lang_wr('spxx', 0),
    lang_wr('fkyh', 0),
    lang_wr('ddxinxi', 0),
    lang_wr('status', 0),
    lang_wr('shdz', 0),
    lang_wr('fhxx', 0),
));

$res = C::t('#xigua_wr#xigua_wr_order')->fetch_all_by_where($wherearr, $start_limit, $lpp, $order);
$icount = C::t('#xigua_wr#xigua_wr_order')->fetch_count_by_where($wherearr);

$uids = $ordersns= array();
foreach ($res as $v) {
    $uids[] = $v['uid'];
    $uids[] = $v['hxuid'];
    $ordersns[] = $v['order_id'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $vusers = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}
if($ordersns){
    $ordersns = DB::fetch_all('SELECT order_id,order_sn,jifen,jifen_type FROM %t WHERE order_id IN (%n)', array('xigua_hb_order', $ordersns), 'order_id');
}
$kdgs = lang_wr('kdgs',0);
$kddh = lang_wr('kddh',0);
foreach ($res as $k => $v) {
    $id = $v['id'];
    $uid = $v['uid'];
    $info = $v['info'];
    if(!is_array($info['info'])){
        $info['info'] = unserialize($info['info']);
    }

    $mobile = $vusers[$v['uid']]['mobile'];
    if(!$mobile):
        $__profile = C::t('common_member_profile')->fetch($v['uid']);
        $mobile = $__profile['mobile'];
    endif;
    $realname = $vusers[$v['uid']]['realname'];
    if(!$v['mobile']){
        $v['mobile'] = $mobile;
    }
    if(!$v['realname']){
        $v['realname'] = $realname;
    }

    $fromuid = $info['fromuid'];
    $oldvs = $_GET['status'];
    if(in_array($v['status'], array(2,6)) && $v['fa_ts']>1){
        $oldvs = 98;
    }
    $sel = $seltype = '';
    foreach ($sta as $index => $item) {

        if(in_array($index, array(97,98,99))){
            if($oldvs==$index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }else{
            if($v['status'] == $index){
                $sel .= "<option value=\"$index\" selected>$item</option>";
            }else{
                $sel .= "<option value=\"$index\">$item</option>";
            }
        }
    }
    $crts = date('Y-m-d H:i:s', $v['crts']);
    $goodinfo = unserialize($v['goodinfo']);

    $pingbi = $v['shou_ts']>1 ? 'selected' : '';
    $unpingbi = $pingbi ? '' : 'selected';

    $shouinfo = '';
    if($goodinfo['kami'] && $v['hxcode']){
        $shouinfo .= lang_wr('xnkm',0).' : '. $v['hxcode'];
    } else{
        $shouinfo = ($v['fa_ts']>1 ? lang_wr('fhsj',0).': '.date('Y-m-d H:i:s', $v['fa_ts']) :'').
            '<br>'. ($v['yundan'] ? lang_wr('ydxx',0) . ' :'.$v['yundan_gs'].' '.$v['yundan'] :'');
    }

    $jifenall = $v['priceinfo'].$ctitle;
    $jifendan1 =$jifenall;
    showtablerow('', array(), $res_ = array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
        $id,
        '<div>'.
        $goodinfo['title'].'[ ID : '.$goodinfo['id'].' ]<br>'.
        '<b style="color:orangered;">'.lang_wr('sl',0).': '.$v['gnum'].'</b><br>'.
        ($v['note'] ? lang_wr('bz',0).': '.$v['note'] . '<br>' :'') .'</div>',
        "<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a> [ UID : $uid ]",
        lang_hb('orderid',0).' : <a href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hb&pmod=admin_order&keyword=".$v['order_id']."&note=0&page=1".'">'.$v['order_id'] . '</a><br>'.
        ($ordersns[$v['order_id']]['order_sn'] ? lang_hb('ordersn',0).': '.$ordersns[$v['order_id']]['order_sn'] . '<br>' : '').
        lang_wr('crts',0).': '.$crts.'<br>'.

        lang_wr('zfsj',0).$v['pay_ts_u'] . '<br>'.
       '<b style="color:orangered">'.lang_wr('zfje',0).$v['pay_money'] . '</b><br>'.
        '<b style="color:forestgreen">'.lang_wr('zfje',0).$jifenall.'</b><br>' ,

        "<select name='r[$id][status]' $dis>$sel</select>",

        '<div>'.
($v['hxcode']?lang_wr('sjh',0).': '.$v['mobile']:(lang_wr('shdz1',0).': '.$v['addr'].'<br>'.
lang_wr('lianxi',0).': '.$v['realname'].'<br>'.
lang_wr('sjh',0).': '.$v['mobile'].'<br>')) .'</div>',

        $shouinfo.
        ($v['hxcode'] ? ' ' : ((in_array($v['status'], array(2,6))) ?
            ( "<table>
<tr class=\"hover\">
<td align=\"left\">$kdgs <textarea name=\"r[$id][yundan_gs]\" style='width:100px;height:18px;vertical-align:middle'>{$v['yundan_gs']}</textarea></td>
</tr>
<tr class=\"hover\">
<td align=\"left\">$kddh <textarea name=\"r[$id][yundan]\" style='width:100px;height:18px;vertical-align:middle'>{$v['yundan']}</textarea></td>
</tr>
</table>". ($v['yundan'] ? '':"<a style='font-weight:bold;' href=\"javascript:;\" onclick='return _show_company_profile1($id);'>". lang_wr('djfh', 0) . "</a>"))
            : '')) ,
    ));
}

$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_order&lpp=$lpp&".http_build_query($_GET).'&doexport=0', 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter();

?>
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>


<div id="rsel_menu" class="custom cmain" style="display:none;width:400px;height:250px">
    <div class="cnote" style="width:100%">
        <span class="right"><a href="javascript:;" class="flbc" onclick="hideMenu();return false;"></a></span>
        <h3 id="cnotr"><?php lang_wr('wanshan');?></h3>
    </div>
    <div id="rsel_content" style="overflow-y:auto;height:95%">
        <?php
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_order&".http_build_query($_GET));
        ?>
        <table class="">
            <tr class="hover">
                <td align="left"><?php lang_wr('kdgs');?></td>
                <td><textarea name="yundan_gs" cols="30" rows="2"></textarea></td>
            </tr>
            <tr class="hover">
                <td align="left"><?php lang_wr('kddh');?></td>
                <td><textarea name="yundan" cols="30" rows="2"></textarea></td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <input type="hidden" name="ptlogid" id="ptlogid" value="0">
                    <input type="submit" class="btn" name="editsubmit" value="<?php lang_wr('djfh');?>" />
                </td>
            </tr>
        </table>
        <?php showformfooter();?>
    </div>
</div>
<script>
    function _show_company_profile1(ptlogid) {
        showMenu({'ctrlid': 'rsel', 'evt': 'click', 'duration': 3, 'pos': '00'});
        $('ptlogid').value = ptlogid;
    }
</script>