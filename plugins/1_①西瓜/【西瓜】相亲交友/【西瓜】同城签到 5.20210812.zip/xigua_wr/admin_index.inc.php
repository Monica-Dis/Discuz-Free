<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}
$pt_index_class = C::t('#xigua_wr#xigua_wr_index');
$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$cat__id = intval($_GET['cat__id']);
if($cat__id){
    $cat_indo = $pt_index_class->fetch_by_catid($cat__id);
}
$GLOBALS['needchild'] = 1;
if(1){
    if(submitcheck('del', 1) && FORMHASH == $_GET['formhash']){
        $ret = $pt_index_class->do_delete(intval($_GET['catid']));
        if($ret){
            cpmsg(
                lang_hb('delcat_succeed', 0),
                "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_index&page=$page",
                'succeed'
            );
        }else{
            cpmsg(
                lang_hb('delcat_error', 0),
                "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_index&page=$page",
                'error'
            );
        }
    }
    if(submitcheck('dosubmit')){
        if($new = $_GET['n']){
            $newrow = array();
            foreach ($new['name'] as $k => $v) {
                if(is_array($v)){
                    foreach ($v as $kk => $string) {
                        $newrow[] = array(
                            'pid'  => $k,
                            'name' => $string,
                            'o'    => $new['o'][$k][$kk],
                            'ts'   => TIMESTAMP,
                            'cat_ids'   => trim($new['cat_ids'][$k][$kk]),
                            'price'  => $new['price'][$k][$kk],
                            'telprice'  => $new['telprice'][$k][$kk],
                            'stids'  => $new['stids'][$k][$kk],
                            'style' => 99
                        );
                    }
                } else {
                    $newrow[] = array(
                        'pid' => 0,
                        'name' => $v,
                        'o'  => $new['o'][$k],
                        'ts'   => TIMESTAMP,
                        'cat_ids'   => trim($new['cat_ids'][$k]),
                        'price'  => $new['price'][$k],
                        'telprice'  => $new['telprice'][$k],
                        'stids'  => $new['stids'][$k],
                        'style' => 99
                    );
                }
            }
            foreach ($newrow as $value) {
                $pt_index_class->insert($value);
            }
        }

        if($_FILES['icon'] || $_FILES['adimage']){
            $icons = hb_uploads($_FILES['icon']);
            $adimage = hb_uploads($_FILES['adimage']);
        }
        if($r = $_GET['r']){
            foreach ($r['name'] as $cid => $name) {
                $data = array();

                $data['name']   = $name;
                $data['o']      = $r['o'][$cid];
                $data['cat_ids']= $r['cat_ids'][$cid];
                $data['adlink'] = $r['adlink'][$cid];
                $data['price']  = $r['price'][$cid];
                $data['telprice']  = $r['telprice'][$cid];
                $data['stids']  = $r['stids'][$cid];
                $data['style']  = $r['style'][$cid];
                $data['types']  = $r['types'][$cid];
                $data['catids']  = implode(',', $r['catids'][$cid]);
                $data['tag']    = trim($r['tag'][$cid]);
                $data['placehoder']    = trim($r['placehoder'][$cid]);
                if($_FILES['adimage']['error'][$cid] === UPLOAD_ERR_OK){
                    $data['adimage']= ($adimage[$cid]['errno'] == 0 ? $adimage[$cid]['error'] : '');
                }
                if($_FILES['icon']['error'][$cid] === UPLOAD_ERR_OK) {
                    $data['icon'] = ($icons[$cid]['errno'] == 0 ? $icons[$cid]['error'] : '');
                }

                $pt_index_class->update($cid, $data);
            }
        }
        if($delimg = $_GET['delimg']){
            foreach ($delimg as $catid_ => $fields_) {
                $data_ = array();
                if($fields_['icon'] == 1){
                    $data_['icon'] = '';
                }
                if($fields_['adimage'] == 1){
                    $data_['adimage'] = '';
                }
                if($data_){
                    $pt_index_class->update(intval($catid_), $data_);
                }
            }
        }
        cpmsg(
            lang_hb('succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_index&page=$page",
            'succeed'
        );
    }

    $listinfo = $pt_index_class->fetch_all_by_page($start_limit, $lpp);
    $pt_index_class->init($listinfo);
    $list = $pt_index_class->get_tree_array(0);

    $totalcount = $pt_index_class->count_by_page();
    $multipage = multi(
        $totalcount, $lpp, $page,
        ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_index&page=$page"
    );

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_index&page=$page", 'enctype');
    $alink = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_pub&catadd";

    ?>
    <link rel="stylesheet" href="source/plugin/xigua_hb/static/admincp.css?1" />
    <table class="tb tb2 ">
        <tbody>
        <tr class="header">
            <th><?php lang_hb('index_id')?></th>
            <th><?php lang_hb('order')?></th>
            <th><?php lang_hb('index_name')?></th>
            <th><?php lang_hb('cat_icon')?></th>
            <th><?php lang_hb('index_link')?></th>
            <th><?php lang_hb('wz')?></th>
            <th><?php lang_hb('style')?></th>
            <th><?php lang_hb('pubstida')?></th>
            <th><?php lang_hb('caozuo')?></th>
        </tr>
        </tbody>
        <?php foreach ($list as $v) {
$v['catids'] = explode(',', $v['catids']);
?>
            <tbody>
            <tr class="hover">
                <td><?php echo $v['id']?></td>
                <td><input style="width:20px" type="text" class="txt" name="r[o][<?php echo $v['id']?>]" value="<?php echo $v['o']?>" /></td>
                <td>
                    <div class="parentboard"><input type="text" name="r[name][<?php echo $v['id']?>]" value="<?php echo $v['name']?>" class="txt" /></div>
                </td>
                <td>
                    <input style="width:100px" name="icon[<?php echo $v['id']?>]" type="file" />
                    <?php if($v['icon']){?>
                        <span class="sp">
     <img class="imgi" src="<?php echo $v['icon']?>" onmouseover="$('icon<?php echo $v['id']?>').style.display='block'" onmouseout="$('icon<?php echo $v['id']?>').style.display='none'" />
     <img id="icon<?php echo $v['id']?>" src="<?php echo $v['icon']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][icon]" value="1" /><?php lang_hb('delshort')?></label>
 </span>
                    <?php }?>
                </td><td>
                    <p>
                        <input type="text" name="r[adlink][<?php echo $v['id']?>]" value="<?php echo $v['adlink'] ? $v['adlink'] : ''; ?>" />
                    </p>
                </td>
                <td>
                        <select style="margin-bottom:2px;width:100px" onchange="showids(this.value, '<?php echo $v['id']?>');" name="r[types][<?php echo $v['id']?>]">
                            <option <?php if(!$v['types']){echo 'selected';} ?> value=""><?php lang_hb('shouye')?></option>
                            <option <?php if($v['types']=='cat'){echo 'selected';} ?> value="cat"><?php lang_hb('lby')?></option>
                            <option <?php if($v['types']=='view'){echo 'selected';} ?> value="view"><?php lang_hb('xqy')?></option>
                        </select>
                    <div <?php if(!$v['types']){echo 'style="display:none;"';} ?> id="typids<?php echo $v['id']?>">
                        <?php
                        $csearch = "<select style='width:100px;height:60px' multiple name=\"r[catids][{$v['id']}][]\">";
                        $csearch .= "<option value=\"-1\" ". (in_array(-1, $v['catids'])?'selected':'') .">".lang_hb('quanbu',0)."</option>";
                        foreach ($cat_list as $k => $_v) {
                            $check1 = (in_array($_v['id'], $v['catids'])?'selected':'');
                            $csearch .= "<option value=\"$_v[id]\" $check1 >$_v[name]</option>";
                            foreach ($_v['child'] as $kk => $vv) {
                                $check2 = (in_array($vv['id'], $v['catids'])?'selected':'');
                                $csearch .= "<option value=\"$vv[id]\" $check2 >&nbsp;&nbsp;$vv[name]</option>";
                            }
                        }
                        $csearch .= '</select>';
                        echo $csearch;
                        ?>
                    </div>
                </td>
                <td>
                    <p>
                        <select name="r[style][<?php echo $v['id']?>]">
                            <option <?php if($v['style']=='99'){echo 'selected';} ?> value="99"><?php lang_hb('pcslider')?></option>
                            <option <?php if($v['style']=='1'){echo 'selected';} ?> value="1">1<?php lang_hb('g')?></option>
                            <option <?php if($v['style']=='2'){echo 'selected';} ?> value="2">2<?php lang_hb('g')?></option>
                            <option <?php if($v['style']=='3'){echo 'selected';} ?> value="3">3<?php lang_hb('g')?></option>
                            <option <?php if($v['style']=='4'){echo 'selected';} ?> value="4">4<?php lang_hb('g')?></option>
                            <option <?php if($v['style']=='5'){echo 'selected';} ?> value="5">5<?php lang_hb('g')?></option>
                            <option <?php if($v['style']=='6'){echo 'selected';} ?> value="6">6<?php lang_hb('g')?></option>
                        </select>
                    </p>
                </td>
                <td>
                    <p>
                        <input type="text" name="r[stids][<?php echo $v['id']?>]" value="<?php echo $v['stids'] ? $v['stids'] : ''; ?>" />
                    </p>
                </td>
                <td>
                    <a href="javascript:;" onclick="return _delid(<?php echo $v['id']?>,'<?php echo str_replace('&#039;', '', $v['name'])?>') "><?php lang_hb('del')?></a>
                </td>
            </tr>
            </tbody>
        <?php }?>

        <tbody>
        <tr>
            <td>&nbsp;</td>
            <td colspan="99"><div>
                    <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hb('ad_new_cat')?></a>
                </div></td>
        </tr>
        <?php
        if($multipage){
            showtablerow('', 'colspan="99"', $multipage);
        }
        showsubmit('dosubmit', 'submit', 'td');
        ?>
        </tbody>
    </table>
    </form>
    <script>
        var rowtypedata = [
            [
                [1, ''],
                [1,'<input type="text" style="width:20px" class="txt" name="n[o][]" value="0" />', 'td25'],
                [5,'<div><input name="n[name][]" value="<?php lang_hb('new_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
            ],
            [
                [1, ''],
                [1,'<input type="text" class="txt" name="n[o][{1}][]" value="0" />', 'td25'],
                [5,'<div class="board"><input name="n[name][{1}][]" value="<?php lang_hb('child_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hb('del')?></a></div>']
            ]
        ];
        function _delid(id, name){
            if(confirm('<?php lang_hb('del_confirm')?>' + name + '?')){
                window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_index&page=$page&del=1&formhash=".FORMHASH.'&catid='?>"+id;
            }
        }
        function showids(val, idstr){
            if(val=='cat'||val=='view'){
                $('typids'+idstr).style.display='block';
            }else{
                $('typids'+idstr).style.display='none';
            }
        }
    </script>
<?php } ?>