<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_wr/common.php';


$page = max(1, intval($_GET['page']));
$lpp = 20;
$start_limit = ($page - 1) * $lpp;
$statuss = array(
    1 => lang_wr('ysj', 0),
    3 => lang_wr('yxj', 0),
);
$ctitle = $_G['setting']['extcredits'][$wr_config['ctypee']]['title'];
$cunit = $_G['setting']['extcredits'][$wr_config['ctypee']]['unit'];

if (submitcheck('fzid', 1) && $_GET['formhash'] == formhash()) {
    $fzid = intval($_GET['fzid']);

    $old_data = C::t('#xigua_wr#xigua_wr_good')->fetch($fzid);
    if ($old_data) {
        unset($old_data['id']);
        $old_data['title'] = lang_wr('fz', 0) . $old_data['title'];
        $newgid = C::t('#xigua_wr#xigua_wr_good')->insert($old_data, 1);
        cpmsg(lang_wr('fzsucceed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good", 'succeed');
    }
}

if ($secid = intval($_GET['secid'])) {
    $res = C::t('#xigua_wr#xigua_wr_good')->fetch($secid);
    if (!submitcheck('dosubmit')) {
        if (!$res) {
            $res = array( 'title' => '', 'subtitle' => '', 'hy' => '', 'disprice' => '0.00', 'price' => '0.00', 'jfprice' => '0', 'stat' => '0', 'fengmian' => '', 'album' => '', 'jieshao' => '', 'stock' => '0', 'danci' => '0', 'sellnum' => '0', 'kami' => '', 'displayorder' => '0', 'uid' => '0', 'crts' => TIMESTAMP, 'upts' => TIMESTAMP, 'stid' => '0');
            $neww = 1;
        }
        echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
        showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good&secid=$secid", 'enctype');
        showtableheader();
        showtitle(lang_wr('spgl', 0) .' - ID : '. ($secid > 0 ? $secid : '') . "<a href='" . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good'> " . lang_wr('back', 0) . "</a>");

        foreach ($res as $index => $re) {
            if (in_array($index, array('id'))) {
                continue;
            }

            $tp = 'text';
            $cmt = '';
            $_extra = '';

            if (in_array($index, array('crts', 'upts'))) {
                $re = $re ? dgmdate($re, 'Y-m-d H:i:s') : '';
                $tp = 'calendar';
                $_extra = '1';
            } elseif (in_array($index, array('stat'))) {
                $cs = '<select name="editform[stat]">';
                foreach ($statuss as $c_t => $c) {
                    $s = '';
                    if ($c_t == $re) {
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$c_t'>$c</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            } elseif (in_array($index, array('thumb'))) {
                $tp = 'filetext';
            } elseif (in_array($index, array('yuyue', 'gongkai', 'showdis', 'selfdis', 'orderdis', 'newp', 'allow_tk', 'baoyou_type'))) {
                $tp = 'radio';
            } elseif (in_array($index, array('hy'))) {
                $cs = '<select name="editform[hy]">';
                foreach ($svicerange as $__v) {
                    $s = '';
                    if (in_array($__v, $re) ||$re ==$__v) {
                        $s = 'selected';
                    }
                    $cs .= "<option $s value='$__v'>$__v</option>";
                }
                $cs .= '</select>';
                $tp = $cs;
            }

            if (in_array($index, array('fengmian'))) {
                $tp = 'filetext';
            }
            if (in_array($index, array('kami'))) {
                $tp = 'textarea';
            }
            if (in_array($index, array('album'))) {
                $re = unserialize($re);
                $tp = 'filetext';
                $loopnum = $wr_config['maximg']?$wr_config['maximg']:5;
                for ($i = 0; $i < $loopnum; $i++) {
                    if ($tp == 'filetext') {
                        $cmt = $re[$i] ? '<a href="' . $re[$i] . '" target="_blank"><img src="' . $re[$i] . '" style="height:100px;display:inline-block" /></a>' : '';
                    }
                    showsetting(lang_wr($index, 0) . ($i + 1), "editform[$index][$i]", $re[$i], $tp, '', 0, $cmt);
                }
            } elseif ($index == 'jieshao') {
                $_tmp1 = lang_wr($index, 0);
                $_re = $re;
                echo <<<HTML
<tr><td colspan="2" class="td27">$_tmp1:</td></tr>
<tr class="noborder"><td class="vtop rowform"  colspan="2">
<script name="editform[jieshao]" id="editform_description" type="text/plain" style="width:1024px;height:500px;">$_re</script>
</td></tr>
HTML;
            } elseif ($index == 'groupid') {
                $groups = $forums = array();
                foreach (C::t('common_usergroup')->range() as $group) {
                    $groups[] = array($group['groupid'], $group['grouptitle']);
                }
                $value = explode(',', $re);
                showsetting(cplang('setting_styles_global_allowfloatwin_usergroups'), array('editform[groupid][]', $groups), $value, 'mselect');
            } else {
                if ($tp == 'filetext') {
                    $cmt = $re ? '<a href="' . $re . '" target="_blank"><img src="' . $re . '" style="height:100px;display:inline-block" /></a>' : '';
                }
                showsetting(lang_wr($index, 0), "editform[$index]", $re, $tp, '', 0, $cmt, $_extra);
            }
        }

        showsubmit('dosubmit');
        showtablefooter(); /*dism��taobao��com*/
        showformfooter();
        echo <<<HTML
<style>.px{min-width:20px!important;}</style>
<script type="text/javascript" src="static/js/calendar.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.config.js"></script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/ueditor.all.min.js"> </script>
<script type="text/javascript" charset="utf-8" src="source/plugin/xigua_hb/lib/u/lang/zh-cn/zh-cn.js"></script>
<script>var ue = UE.getEditor('editform_description');</script>
HTML;

    } else {

        $editform = $_GET['editform'];
        if (!$editform['album']) {
            $editform['album'] = array();
        }
        $editform['stat'] = intval($editform['stat']);
        $_newimglist = hb_uploads($_FILES['editform']);
        foreach ($_newimglist as $__k => $__v) {
            if ($__k == 'album') {
                foreach ($__v as $index => $item) {
                    if ($item['errno'] == 0) {
                        $editform[$__k][$index] = $item['error'];
                    }
                }
            } else {
                if ($__v['errno'] == 0) {
                    $editform[$__k] = $__v['error'];
                }
            }
        }
        foreach (array('crts', 'upts') as $item) {
            $editform[$item] = strtotime($editform[$item]);
        }

        $editform['kami'] = trim($editform['kami']);
        if($editform['kami']){
            $kamiary = array_filter(explode("\n", $editform['kami']));
            $editform['stock'] = count($kamiary);
        }
        /*$editform['groupid'] = implode(',', $editform['groupid']);*/

        foreach (array('album') as $item) {
            if (!$editform[$item]) {
                $editform[$item] = array();
            }
            $editform[$item] = serialize(array_filter($editform[$item]));
        }

        if ($secid > 0) {
            $rs = C::t('#xigua_wr#xigua_wr_good')->update($secid, $editform);
            $gid = $secid;
        } else {

            $gid = C::t('#xigua_wr#xigua_wr_good')->insert($editform, 1);
        }

        cpmsg(lang_wr('czcg', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good&secid=$secid", 'succeed');
    }
} else {

    if (submitcheck('permsubmit')) {
        if ($delete = dintval($_GET['delete'], true)) {
            C::t('#xigua_wr#xigua_wr_good')->deletes($delete);
        }
        foreach ($_GET['row'] as $id => $item) {
            C::t('#xigua_wr#xigua_wr_good')->update($id, array('displayorder' => $item['displayorder'], 'stat' => $item['stat']));
        }

        cpmsg(lang_wr('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good&shid={$_GET['shid']}&page=$page", 'succeed');
    }

    $wherearr = array();
    $keyword = $_GET['keyword'];
    if (is_numeric($keyword) && $keyword < 9999999) {
        $wherearr[] = 'uid=' . intval($keyword);
    } else if ($keyword = stripsearchkey($keyword)) {
        $wherearr[] = " (title LIKE '%$keyword%'  OR jieshao LIKE '%$keyword%' OR subtitle LIKE '%$keyword%') ";
    }
    if (isset($_GET['stat'])) {
        $wherearr[] = 'stat=' . intval($_GET['stat']);
    }

    $ob = ' displayorder DESC, id desc';

    echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good&shid={$_GET['shid']}");

    echo '<div><input type="text" id="keyword" placeholder="' . lang_wr('spmc', 0) . '" name="keyword" value="' . $_GET['keyword'] . '" class="txt" /> ';
    foreach ($statuss as $index => $_v) {
        echo '<label><input type="radio" name="stat" value="' . $index . '" ' . (isset($_GET['stat']) && $_GET['stat'] == $index ? 'checked' : '') . ' />' . $_v . '</label>';
    }

    echo "<style>.abtn,.btn{padding:2px 6px;background:".$wr_config['color'].";color:#fff;}.highink em{color:".$wr_config['color'].";font-weight:bold}
    .km2{padding:0 3px;border-radius:2px;font-size:12px;color:#fff;background:#369;margin-right:3px}.km2:last-child{margin-right:0}</style>";
    echo '&nbsp;&nbsp;&nbsp;';
    echo ' <input type="submit" class="btn" value="' . cplang('search') . '" /> ';
    echo ' <a href=' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good" . ' class="btn" >' . cplang('reset') . '</a> ';
    echo " <a href=\"?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good&secid=-1\" class=\"btn\">" . lang_wr('tjsp', 0) . "</a></div>";
    showtableheader(lang_wr('fabuguanli', 0));
    showtablerow('class="header"', array(), array(
        lang_wr('del', 0),
        lang_wr('displayorder', 0),
        lang_wr('thumb', 0),
        lang_wr('title', 0),
        lang_wr('prices', 0),
        lang_wr('stock', 0),
        lang_wr('yishou', 0),
        lang_wr('spzt', 0),
        lang_wr('caozuo', 0),
    ));


    $res = C::t('#xigua_wr#xigua_wr_good')->fetch_all_by_where($wherearr, $start_limit, $lpp, $ob);
    $icount = C::t('#xigua_wr#xigua_wr_good')->fetch_count_by_page($wherearr);

    foreach ($res as $v) {
        if ($v['uid']) {
            $uids[$v['uid']] = $v['uid'];
        }
    }
    if ($uids) {
        $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    }

    foreach ($res as $v) {
        $v['album'] = array_filter(unserialize($v['album']));
        $id = $v['id'];
        $thumb = $v['fengmian'] ? $v['fengmian'] : $v['album'][0];

        $checked = $v['display'] ? 'checked' : '';

        $status_u = "<select name=\"row[$id][stat]\">";
        foreach ($statuss as $k => $vv) {
            if ($v['stat'] == $k) {
                $s = 'selected';
            } else {
                $s = '';
            }
            $status_u .= "<option $s value=\"$k\">$vv</option>";
        }
        $status_u .= '</select>';
        $tu = '<em class="km2">'.count($v['album']).lang_wr('t',0).'</em>';
        if($v['kami']){
            $tu .= '<em class="km2">'.lang_wr('kami1',0).'</em>';
        }

        $price_line = '';
        $price_line .= '<s>&yen;'.$v['disprice'].'</s>';
        $price_line .= '<div class="highink"><em>&yen;'.$v['price'].'</em>';
        $price_line .= ' + <em>'.$v['jfprice'].$ctitle.'</em></div>';

        $stock_line = '';
        $stock_line .= '<div>';
        $stock_line .= '<b>'.$v['stock'].'</b>';
        $stock_line .= '</div>';

        showtablerow('', array(), array(
            "<input type='checkbox' class='checkbox' name='delete[]' value='$id' /> $id",
            "<input type='text' name='row[$id][displayorder]' value='{$v['displayorder']}' style='width:50px' />",
            "<img src='$thumb' style='height:40px' />",
            "<p style='font-size:15px;color:#369'> $tu {$v['title']}</p><p style='color:".$wr_config['color']."'>{$v['subtitle']}</p>",

            $price_line,
            $stock_line,
            $v['sellnum'],

            $status_u,

            '<a class=\'abtn\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good&formhash=" . formhash() . "&fzid=$id" . '">' . lang_wr('fuzhi', 0) . '</a> ' .
            '<a class=\'abtn\' href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good&secid=$id" . '">' . lang_wr('edit', 0) . '</a> ' .
            '',
        ));
    }
    $dlink = ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good&" . http_build_query($_GET) . "&shid={$_GET['shid']}&doexport=1&page=$page&formhash=" . FORMHASH;
    $multipage = multi($icount, $lpp, $page, ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_good&lpp=$lpp&" . http_build_query($_GET), 0, 10);
    showsubmit('permsubmit', 'submit', 'del', "", $multipage);
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();

    /*echo '<pre>';
    print_r($res);
    echo '</pre>';*/
}