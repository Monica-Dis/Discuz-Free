<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2020/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function callback_wr_pay($param){
    global $_G,$adminids, $wr_config;
    $data = $param['info']['data'];
    if(!$wr_config){
        $wr_config = $_G['cache']['plugin']['xigua_wr'];
    }

    $updatestock = C::t('#xigua_wr#xigua_wr_good')->update_stock($data['gid'], $data['gnum']);
    if($updatestock){
        updatemembercount($data['uid'], array($wr_config['ctypee'] => -$data['priceinfo']), 1, 'WR', $data['uid'],'', $data['title']);
        DB::query("UPDATE %t SET sellnum=sellnum+{$data['gnum']} WHERE id=%d", array(
            'xigua_wr_good',
            $data['gid']
        ));
        $sec = array('status' => 2, 'pay_ts' => TIMESTAMP, );
        C::t('#xigua_wr#xigua_wr_order')->update($data['id'], $sec);

        $goodinfo = C::t('#xigua_wr#xigua_wr_good')->fetch($data['gid']);
        if($goodinfo['kami']){
            $hasuseds = array();
            $hasused = DB::fetch_all('select hxcode from %t WHERE gid=%d', array('xigua_wr_order', $data['gid']));
            foreach ($hasused as $index => $item) {
                $itemary = explode(',', $item);
                foreach ($itemary as $index => $item) {
                    $hasuseds[] = trim($item);
                }
            }
            $kami_all = array_filter(explode("\n", $goodinfo['kami']));
            foreach ($kami_all as $index => $item) {
                $kami_all[$index] = trim($item);
            }
            $hit = array();
            foreach ($kami_all as $index => $kami) {
                if(in_array($kami, $hasuseds)){
                    continue;
                }
                $hit[] = $kami;
                if(count($hit)>= $data['gnum']){
                    break;
                }
            }
            $insert_kami = implode(',', $hit);
            $data1 = array(
                'hxcode' => $insert_kami,
                'shou_ts' => TIMESTAMP,
                'fa_ts' => TIMESTAMP,
                'hxuid' => $data['uid'],
                'hxcrts' => TIMESTAMP,
            );
            C::t('#xigua_wr#xigua_wr_order')->update($data['id'], $data1);

            $kamis_a = array_diff($kami_all, $hasuseds, $hit);
            C::t('#xigua_wr#xigua_wr_good')->update($data['gid'], array('stock' => count($kamis_a), 'kami' => implode("\n", $kamis_a)));

        }
        $usr = getuserbyuid($data['uid']);
        notification_add($data['uid'],'system', "<a href=\"{url}\">".lang('plugin/xigua_wr', 'gxgmcg').$data['title'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_wr&ac=order_profile&ptlog_id='.$data['id']),1);

        foreach ($adminids as $index => $adminid) {
            notification_add($adminid,'system', "<a href=\"{url}\">".$usr['username'].lang('plugin/xigua_wr', 'gggml').$data['title'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_wr&ac=order_profile&manage=1&ptlog_id='.$data['id']),1);
        }
    }

    return true;
}

function callback_wrcz_pay($param){
    global $_G,$adminids, $wr_config;
    $data = $param['info']['data'];
    if(!$wr_config){
        $wr_config = $_G['cache']['plugin']['xigua_wr'];
    }
    $getc1 = $data['cztype'][0];
    $getc2 = $data['cztype'][1];
    $getcall = $getc1+$getc2;
    if($getcall> 0){
        updatemembercount($data['uid'], array($wr_config['ctypee'] => $getcall), 1, 'WR', $data['uid'],'', $data['title']);
        notification_add($data['uid'],'system', "<a href=\"{url}\">".lang('plugin/xigua_wr', 'gxgmcg').$data['title'].'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_wr'),1);
        wr_get_reward($data['uid'], 'chongzhi', 1 );
    }
    return true;
}

function wr_get_reward($uid, $typein){
    global $_G;
    $wr_cache_key = 'wr_ext_setting';
    if(!$_G['cache'][$wr_cache_key]){
        loadcache($wr_cache_key);
    }
    $wr_ext_setting = $_G['cache'][$wr_cache_key];
    if(!in_array($typein, $wr_ext_setting['openwr'])){
        return false;
    }
    if(!$_G['cache']['plugin']){
        loadcache('plugin');
    }
    $wr_config = $_G['cache']['plugin']['xigua_wr'];
    $ctitle = $_G['setting']['extcredits'][$wr_config['ctypee']]['title'];
    $cunit = $_G['setting']['extcredits'][$wr_config['ctypee']]['unit'];
    $exttitle = strip_tags($wr_ext_setting[$typein.'_desc']).lang('plugin/xigua_wr', 'jiangli').$wr_ext_setting[$typein.'_jiangli'].$cunit.$ctitle;
    $checkresult = wr_check_if_finish($uid, $typein, $wr_ext_setting[$typein.'_num'], $exttitle);

    if($wr_ext_setting[$typein.'_jiangli']> 0 && $checkresult){
        $title = lang('plugin/xigua_wr', 'wcrw').$exttitle;
        updatemembercount($uid, array($wr_config['ctypee'] => $wr_ext_setting[$typein.'_jiangli']), 1, 'WR',$uid, '', $title);
        notification_add($uid,'system', "<a href=\"{url}\">".$title.'</a>', array('url' => $_G['siteurl'].'plugin.php?id=xigua_wr&ac=credit_list'),1);
        return true;
    }
    return false;
}

function wr_check_if_finish($uid, $typein, $num, $exttitle){
    $r = DB::result_first('SELECT count(*) AS total FROM %t WHERE uid=%d AND act=%s AND crdate=%s', array('xigua_wr_viewlog', $uid, $typein, date('Y-m-d', TIMESTAMP)));
    if($r> $num){
        return 0;
    }else if($num>$r){
        C::t('#xigua_wr#xigua_wr_viewlog')->do_insert($uid, $typein, '');
        return ($r+1) == $num;
    }else{
        return ($r+1) == $num;
    }
}