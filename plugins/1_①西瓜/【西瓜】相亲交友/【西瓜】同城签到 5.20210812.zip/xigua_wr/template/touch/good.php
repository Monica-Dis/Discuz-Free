<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_wr:header}-->
<!--{if $v[fengmian]}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$v[fengmian]" /></div><!--{/if}-->
<div class="page__bd view_bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="view_num we_share"><i class="iconfont icon-ico_fenxiang f14"></i></div>
    <div class="sp_swipe cl" style="position:relative;margin:0;overflow:hidden" id="goodinfo">
        <div class="swipe-wrap" style="transition: all .3s;-webkit-transition: all .3s">
            <!--{if !$v[album]}--><!--{eval $v[album] = array($v[fengmian]);}--><!--{/if}-->
            <!--{loop $v[album] $slider}-->
            <div class="swp imgloading"><img src='$slider' /></div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $v[album] $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}--> ></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
    <div class="weui-cells mt0 before_none view_top after_none">
        <div class="cl view_cell">
            <div class="weui-flex">
                <div class="weui-flex__item" style="position: relative">
                    <span class="tprice">
                        <!--{if $v[price]>0}--><em class="f14">&yen;</em>$v[price]<!--{/if}--><!--{if $v[jfprice]}--><!--{if $v[price]>0}-->+<!--{/if}-->$v[jfprice]<em class="f14">$ctitle</em><!--{/if}-->
                    </span>
                    <!--{if $v[disprice]>0}-->
                    <span class="f14"><s><em class="f14">&yen;</em>$v[disprice]</s></span>
                    <!--{/if}-->
                    <!--{if $v[kami]}-->
                    <span class="kamibtn">{lang xigua_wr:kmzdfh}</span>
                    <!--{/if}-->
                </div>
            </div>
            <div class="view_title">$v[title]</div>
            <!--{if $v[subtitle]}-->
            <div class="view_subtitle">$v[subtitle]</div>
            <!--{/if}-->
        </div>
    </div>

    <div class="weui-cells f15  before_none after_none" id="goodprofile">
        <div class="sign_rule_head"><span>{lang xigua_wr:spxq}</span></div>
        <article class="weui-cell weui-article f14">
            <section>
                <!--{if $v['jieshao']}-->
                <p class="imgloading">{echo wr_nl2br($v['jieshao']);}</p>
                <!--{/if}-->
                <!--{loop $v[album] $__k $__v}-->
                <p class="imgloading"><img src="{$__v}" /></p>
                <!--{/loop}-->
            </section>
        </article>
    </div>
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_wr&mobile=2{$urlext}" class="weui-tabbar__item">
                <span style="display: inline-block;position: relative;">
                    <i class="iconfont icon-index weui-tabbar__icon "></i>
                </span>
                <p class="weui-tabbar__label">{lang xigua_wr:index}</p>
            </a>
        </div>
        <div class="in_bottom_z">
            <a href="$SCRITPTNAME?id=xigua_wr&ac=order" class="weui-tabbar__item">
                <span style="display:inline-block;position:relative;">
                    <i class="iconfont icon-huodong1 weui-tabbar__icon f26"></i>
                </span>
                <p class="weui-tabbar__label">{lang xigua_wr:wddh}</p>
            </a>
        </div>
        <div class="weui-flex__item in_bottom_y in_bottom_main">
            <a href="javascript:;" class="main_spbg  mc_bg <!--{if $v[stock]>0}-->nowbuy<!--{else}--><!--{/if}-->">
                <div class="fqpd1" style="height:2.5rem">{lang xigua_wr:wydh}</div>
            </a>
        </div>
    </div>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_wr:footer}-->
<script>
    $('div.sp_swipe').each(function () {
        sp_slider($(this), $(this).data('speed') || 5000)
    });
    var sp_seiper = null;
    function sp_slider(_this, auto) {
        var bullets = _this.find('nav.bullets');
        var position = _this.find('ul.position');
        sp_seiper = new Swipe2(_this[0], {
            visibilityFullFit : true,
            startSlide: 0, speed: 500, auto: auto, continuous: true, callback: function (index) {
                if (bullets.length > 0) {
                    bullets.find('em:first-child').text(index + 1);
                }
                if (position.length > 0) {
                    var selectors = position[0].children;
                    for (var t = 0; t < selectors.length; t++) {
                        selectors[t].className = selectors[t].className.replace("current", "");
                    }
                    if (typeof selectors[(index) % (selectors.length)] != 'undefined') {
                        selectors[(index) % (selectors.length)].className = "current";
                    }
                }
                var H = $(".swipe-wrap .swp").eq(index).height();
                if(H){
                    $('.swipe-wrap').css('height', H);
                    $('.sp_swipe').css('height', H);
                }
            }
        });
    }
    var _H = $(".swipe-wrap .swp").eq(0).height();
    if(_H){
        $('.swipe-wrap').css('height', _H);
        $('.sp_swipe').css('height', _H);
    }
    $(document).on('click','.nowbuy', function () {
        hb_jump('$SCRITPTNAME?id=xigua_wr&ac=confirm&gid=$gid');
    });
</script>