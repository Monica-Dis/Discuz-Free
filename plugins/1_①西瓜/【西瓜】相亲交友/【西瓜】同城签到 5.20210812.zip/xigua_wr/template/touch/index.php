<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_wr:header}-->
<style>.x_header_fix{height:0}.x_header {background: transparent!important;position: absolute;}.navtitle{display: none!important}</style>
<!--{if $wr_ext_setting['share_pic']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$wr_ext_setting['share_pic']" /></div><!--{/if}-->
<div class="page__bd">
    <!--{eval $ac='index1';}-->
    <!--{template xigua_hb:common_nav}-->
    <!--{eval $ac='index';}-->
    <div class="cardstyle2" style="<!--{if $wr_ext_setting[indexbg]}-->background-image:url($wr_ext_setting[indexbg])<!--{/if}-->">
        <div class="ruzhu-card">
            <div class="sign_btn">
                <div>
                    <span>{lang xigua_hb:wode}{$ctitle}</span>
                    <span class="main_color">{$myccount}</span>
                </div>
            </div>
            <!--{if $_GET[cz]}-->
            <a href="javascript:docz();" class="sign_days">&#28857;&#20987;&#20805;&#20540;</a>
            <!--{else}-->
            <!--{if !$has}-->
            <a href="javascript:;" onclick="return sign_click('$today');" class="sign_days sign_click" data-date="{$today}">{lang xigua_wr:djqd}</a>
            <!--{else}-->
            <a href="javascript:;" class="sign_days">{lang xigua_wr:ylxqd}{$rowlianxu[lianxu]}{lang xigua_wr:tian}</a>
            <!--{/if}-->
            <!--{/if}-->
            <a href="javascript:;" class="sign_rule_btn" <!--{if $_GET[cz]}-->style="display:none"<!--{/if}-->><i class="iconfont icon-huodong1"></i>{lang xigua_wr:qdgz}</a>
        </div>
    </div>

    <div class="wr_outer" <!--{if $_GET[cz]}-->style="display:none"<!--{/if}-->>
        <input class="weui-input" id="date3" type="hidden">
        <div id="inline-calendar"></div>
    </div>

    <div class="sign_rule" <!--{if !$wr_config[showguize]|| $_GET[cz]}-->style="display:none"<!--{/if}-->>
        <div class="sign_rule_head"><span>{lang xigua_wr:qdgz}</span></div>
        <div id="sign_rule_note">
        <div class="sign_rule_note">
            <p>{$sign_desc}</p>
        </div></div>
    </div>
<!--{template xigua_wr:good_li_index}-->
    <div class="sign_rule">
        <div class="sign_rule_head" <!--{if $_GET[hide]}-->style="display:none"<!--{/if}-->><span>{lang xigua_wr:mrrw}</span></div>
        <div class="weui-cells sign_rule_data mt0 before_none after_none">
            <!--{loop $wr_selects $_k $_v}-->
            <!--{if in_array($_v[0], $wr_ext_setting[openwr])}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><img src="{$wr_ext_setting[$_v[0].'_tubiao']}" onerror="this.error=null;this.src='source/plugin/xigua_wr/static/img/dft.png'" ></div>
                <div class="weui-cell__bd">
                    <p class="sign_rule_tit">{$_v[1]} <!--{if $_v[0]!='sign'&&$wr_ext_setting[$_v[0].'_num']>1}-->({echo intval($mynums[$_v[0]][cnt])}/{$wr_ext_setting[$_v[0].'_num']})<!--{/if}--></p>
                    <p class="sign_rule_desc">{echo $wr_ext_setting[$_v[0].'_desc'] ? $wr_ext_setting[$_v[0].'_desc'] : $_v[1]}</p>
                </div>
                <div class="weui-cell__ft">
                    <!--{if $_v[0]!='sign'}-->
                    <span class="main_color bold">+{echo intval($wr_ext_setting[$_v[0].'_jiangli'])}</span>
                    <!--{/if}-->
<!--{if $_v[0]=='sign'}-->
    <!--{if $has}-->
        <a  href="javascript:;" class="sign_rule_btn_line sign_click fbtn">{$wr_ext_setting[$_v[0].'_fbtn']}</a>
    <!--{else}-->
        <a  href="javascript:;" onclick="return sign_click('$today');" class="sign_rule_btn_line sign_click" data-date="{$today}">{$wr_ext_setting[$_v[0].'_btn']}</a>
    <!--{/if}-->
<!--{else}-->
    <!--{if $mynums[$_v[0]][cnt]>=$wr_ext_setting[$_v[0].'_num']}-->
    <a href="$_v[3]" class="sign_rule_btn_line fbtn">{echo $wr_ext_setting[$_v[0].'_fbtn'] ? $wr_ext_setting[$_v[0].'_fbtn'] : lang_wr('qwc',0)}</a>
    <!--{else}-->
    <a href="$_v[3]" class="sign_rule_btn_line">{echo $wr_ext_setting[$_v[0].'_btn'] ? $wr_ext_setting[$_v[0].'_btn'] : lang_wr('qwc',0)}</a>
    <!--{/if}-->
<!--{/if}-->
                </div>
            </div>
            <!--{/if}-->
            <!--{/loop}-->
        </div>
    </div>
</div>
<!--{eval $wr_tabbar=1;$tabbar=0;}-->
<!--{template xigua_wr:footer}-->
<script>
var budays = [], clickdays = [];
$("#inline-calendar").calendar({
    container: "#inline-calendar",
    maxDate:'$lastday',
    minDate:'$firstday',
    multiple:false,
    input: "#date3",
    toolbarTemplate:'<div class="toolbar"><div class="toolbar-inner"><div class="picker-calendar-month-picker cl"><a href="javascript:;" class="link icon-only picker-calendar-prev-month"><i class="icon icon-prev"></i></a> <div class="flz"><span class="current-year-value"></span> / <span class="current-month-value"></span></div> <a href="javascript:;" class="link icon-only picker-calendar-next-month"><i class="icon icon-next"></i></a></div></div></div>',
    monthNames:['01','02','03','04','05','06','07','08','09','10','11','12'],
    monthNamesShort:['01','02','03','04','05','06','07','08','09','10','11','12'],
    dayNames:['{lang xigua_wr:d7}', '{lang xigua_wr:d1}', '{lang xigua_wr:d2}', '{lang xigua_wr:d3}', '{lang xigua_wr:d4}', '{lang xigua_wr:d5}', '{lang xigua_wr:d6}'],
    dayNamesShort:['{lang xigua_wr:d7}', '{lang xigua_wr:d1}', '{lang xigua_wr:d2}', '{lang xigua_wr:d3}', '{lang xigua_wr:d4}', '{lang xigua_wr:d5}', '{lang xigua_wr:d6}'],
    onDayClick:function (p, dayContainer, year, month, day){
        if(year&&month&&day){
            var values = year+'-'+parseInt(parseInt(month)+1)+'-'+day;
            if(in_array(values, clickdays)){
                console.log(values);
                sign_click(values);
            } else  if(in_array(values, budays)){
                console.log('bu'+values);
                $.confirm('{lang xigua_wr:bqhxh} {$wr_config[bqjf]}{$ctitle},{lang xigua_wr:qdbqm}?','{lang xigua_wr:wxts}',function(){
                    sign_click(values);
                });
            }
        }
    },
});
var formlock2;
function sign_click(date){
    if(formlock2){
        return false;
    }
    formlock2 = 1;
    $.ajax({
        type: 'POST',async:false,
        url:  '$SCRITPTNAME?id=xigua_wr&ac=do_sign&inajax=1',
        data:{formhash:FORMHASH, date:date},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            formlock2 = 0;
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            var m = s.split('|');
            if(m[0]=='success'){
                $.alert(m[1], '<div class="sign_rule_head"><span>{lang xigua_wr:gxqdcg}</span></div>',function (){
                    window.location.reload();
                });
            }else{
                tip_common(s);
            }
        },
        error: function () {
            $.hideLoading();
            formlock2 = 0;
        }
    });
    return false;
}
function load_sign(){
    var ym = $('.current-year-value').text()+'-'+ $('.current-month-value').text();
    var formlockx = 1;
    $.ajax({
        type: 'get',async:true,
        url:  '$SCRITPTNAME?id=xigua_wr&ac=sign_data&inajax=1&month='+ym,
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            formlockx = 0;
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            var m = s.split('|');
            var ms = JSON.parse(m[1]);
            console.log(ms);
            $('.picker-calendar-day').each(function(){
                var datereal =  $(this).data('date');
                var dt =datereal.split('-');
                var dt1 = dt[0]+'-' + parseInt(parseInt(dt[1])+1) + '-'+dt[2];
                if(typeof ms[dt1] !== 'undefined'){
                    if($(this).hasClass('picker-calendar-day-today')) {
                        if(ms[dt1]===-1){
                            clickdays.push(dt1);
                        }else if(ms[dt1]===1){
                            $(this).addClass('c3d4145 cnobg').append('<i class=main_bg></i>');
                        }
                    }else{
                        if(ms[dt1]===-1){
                            budays.push(dt1);
                            $(this).addClass('c3d4145').append('<em>{lang xigua_wr:bq}</em>');
                        }else if(ms[dt1]===1){
                            $(this).addClass('c3d4145').append('<i class=main_bg></i>');
                        }
                    }
                }else{
                    $(this).addClass('c3d4145 noclick');
                }
            });
        },
        error: function () {
            $.hideLoading();
            formlockx = 0;
        }
    });
}
load_sign();
$(document).on('click','.sign_rule_btn', function () {
    $.alert($('#sign_rule_note').html(), '<div class="sign_rule_head"><span>{lang xigua_wr:qdgz}</span></div>');
});
if ($('.coupon_swiper').length > 0) {
    var coupon_swiper = new Swiper('.coupon_swiper', {
        slidesPerView: 'auto',
        paginationClickable: true,
        spaceBetween: 0
    });
}
</script>
<!--{template xigua_wr:cz}-->