<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{loop $list $_k $_v}-->
<div class="credit_li_div">
    <div class="credit_time_u"><span>{$_v[time_u]}</span></div>
    <div class="weui-panel__bd">
        <div class="weui-media-box weui-media-box_text">
            <h4 class="weui-media-box__title">{$_v[title]}</h4>
            <ul class="weui-media-box__info">
                <li class="weui-media-box__info__meta main_color">$ctitle</li>
                <li class="weui-media-box__info__meta main_color">{$_v[fuhao]}{$_v['extcredits']}</li>
                <li class="weui-media-box__info__meta" style="float:right;font-weight:normal">{$_v[time_ts]}</li>
            </ul>
        </div>
    </div>
</div>
<!--{/loop}-->