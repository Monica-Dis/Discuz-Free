<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<script>
function docz() {
    $.actions({
        title: '{lang xigua_wr:chongzhi}',
        actions: [<!--{loop $czcats $price1 $_d_i}-->{
            text: '$_d_i[2]', onClick: function () {
                $.showLoading();
                $.ajax({
                    type: "POST",
                    url: _APPNAME + "?id=xigua_wr&ac=cz&inajax=1",
                    data: {formhash: FORMHASH, 'price1':$price1},
                    dataType: "xml",
                    success: function (data) {
                        $.hideLoading();
                        if (null == data) {
                            tip_common('error|' + ERROR_TIP);
                            return false;
                        }
                        var s = data.lastChild.firstChild.nodeValue;
                        tip_common(s);
                    }
                });
            }
        },<!--{/loop}-->]
    });
}
<!--{if $_GET[cz]}-->
docz();
<!--{/if}-->
</script>