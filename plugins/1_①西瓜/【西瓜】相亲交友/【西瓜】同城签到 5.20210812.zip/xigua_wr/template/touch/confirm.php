<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_wr:header}-->
<style>.weui-cells_radio .weui-check:checked+.weui-icon-checked:before{content:'\EA06';font-size:21px;display:block}.weui-cells_radio .weui-icon-checked:before{content:'\EA01';color:#c9c9c9;font-size:21px;display:block;margin:0}
    .s_quan_tag{position:absolute;left:0;bottom:.4rem;background-color:#fff6f6;color:#fb6165;padding:.1rem .25rem;line-height:1;border-radius:1rem;font-size:.6rem}
    .s_quan_tag:after{border-radius:1rem!important}</style>
<div class="page__bd">
    <form  action="$SCRITPTNAME?id=xigua_wr&ac=buy&st={$_GET['st']}" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <!--{loop $_GET $gk $gv}-->
        <input type="hidden" name="form[$gk]" value="{$gv}">
        <!--{/loop}-->
        <div class="weui-cells before_none after_none mt0">
            <div class="weui-cell weui-cell_access after_none" style="display:block;overflow:hidden">
                <div class="weui-cell__hd z">
                    <label class="weui-label " style="width:4.75rem">
                        <img style="width:4rem;height:4rem;" src="{echo $v[fengmian]?$v[fengmian]:$v[album][0]}">
                    </label>
                </div>
                <div class="weui-cell__bd pr">
                    <p class="f14 c3 mt8">{$v[title]} {$v[subtitle]}</p>
                    <p class="f14 mt8">
                        <strong class="main_color"><!--{if $v[price]>0}-->&yen;{$v[price]}+<!--{/if}-->{$v[jfprice]}$ctitle</strong>
                        <em class="wr_gdc_r"><em class="wr_visb">1</em><s>&yen;{$v[disprice]}</s></em>
                    </p>
                </div>
            </div>
            <div class="weui-cell before_none">
                <div class="weui-cell__bd">
                    <p class="f14">{lang xigua_wr:sl}</p>
                </div>
                <div class="weui-cell__ft main_color">
                    <i class="iconfont icon-jianshao2 inc-num" data-step="-1"></i>
                    <input class="inc-input" type="tel" name="form[item_num]" id="item_num" value="1" data-max="$v[danci]" readonly >
                    <i class="iconfont icon-tianjia1 inc-num" data-step="1"></i>
                </div>
            </div>
        </div>
        <div class="weui-cells__title">{lang xigua_wr:bz}</div>
        <div class="weui-cells before_none after_none">
            <div class="weui-cell ">
                <div class="weui-cell__bd">
                    <input class="weui-input f14" name="form[note]" id="item_note" type="text" placeholder="{lang xigua_wr:xt}" value="{$_GET['note']}">
                </div>
            </div>
        </div>

        <div class="weui-cells before_none after_none weui-cells_radio <!--{if $v[kami]}-->none<!--{/if}-->">
            <a class="weui-cell weui-cell_access after_none payaddress" href="javascript:;" id="pay_address">
                <div class="weui-cell__hd">
                    <label class="weui-label mr8" style="width:auto"><i class="f20 c3 iconfont icon-mudedi vm"></i></label>
                </div>
                <div class="weui-cell__bd c3">
                    <!--{if $dft[mobile]}-->
                    <div class="f12 "><span class="f14">{$dft[realname]}</span>&nbsp;{$dft[mobile]}</div>
                    <div class="f12 mt3">{$dft[dist1]}&nbsp;{$dft[dist2]}&nbsp;{$dft[dist3]}&nbsp;{$dft[address]}</div>
                    <input type="hidden" name="form[dist1]" value="$dft[dist1]">
                    <input type="hidden" name="form[dist2]" value="$dft[dist2]">
                    <input type="hidden" name="form[dist3]" value="$dft[dist3]">
                    <input type="hidden" name="form[address]" value="$dft[address]">
                    <input type="hidden" name="form[realname]" value="$dft[realname]">
                    <input type="hidden" name="form[mobile]" value="$dft[mobile]">
                    <input type="hidden" name="form[addrid]" value="$addr[id]">
                    <!--{else}-->
                    <div class="f14">{lang xigua_wr:djszshdz}</div>
                    <!--{/if}-->
                </div>
                <div class="weui-cell__ft">
                </div>
                <div class="addrbx"></div>
            </a>
        </div>
        <!--{if $v[kami]}-->
        <div class="weui-cells__title pr main_color">{lang xigua_wr:kmzdfh}</div>
        <!--{/if}-->

        <div class="footer_fix"></div>
        <div class="fix-bottom" style="padding:0">
            <div class="confirm_foot">
                <div class="confirm_foot_d">
                    <em>{lang xigua_wr:sfk}:</em>
                    <span class="price">
                        <strong class="main_color"><!--{if $v[price]>0}-->&yen;{$v[price]}+<!--{/if}-->$v[jfprice] $ctitle</strong>
                    </span>
                </div>
                <input class="confirm_foot_btn" value="{lang xigua_wr:ljxd}" id="dosubmit" name="dosubmit" type="submit">
            </div>

        </div>
    </form>
</div>

<!--{eval $tabbar=0;}-->
<!--{template xigua_wr:footer}-->
<script>
var HB_INWECHAT = '{HB_INWECHAT}',mkey = "{$_G['cache']['plugin']['xigua_hs'][mkey]}", HS_MULTIUPLOAD = "{$_G['cache']['plugin']['xigua_hb'][multiupload]}";
function incNumCallback(ipt){
    incNum();
}
function incNum(){
    var ipt = $('.inc-input');
    console.log(ipt.val());
    $.ajax({
        type: 'GET',
        url: _APPNAME + '?id=xigua_wr&gid={$_GET[gid]}&ac=shisuan&num='+ipt.val()+'&inajax=1'+_URLEXT,
        dataType: 'xml',
        success: function (data) {
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s){
                $('.price strong').html(s);
            }
        }
    });
}
incNumCallback($('.inc-input'));
$(document).on('click','.inc-num', function () {
    var that = $(this);
    var ipt = that.parent().find('.inc-input');
    var num = parseInt(ipt.val());
    if(parseInt(that.data('step'))===1){
        if (!ipt.data('max') || num <ipt.data('max')) {
            ipt.val(++num);
        }
    }else{
        if (num > 1) {
            ipt.val(--num);
        }
    }
    if(typeof incNumCallback !=='undefined'){
        incNumCallback(ipt);
    }
});
$(document).on('click','#pay_address', function () {
    hb_setcookie('seckill_wait', window.location.href, 1200);
    window.location.href = _APPNAME+'?id=xigua_hb&ac=myaddr'+_URLEXT;
});
</script>