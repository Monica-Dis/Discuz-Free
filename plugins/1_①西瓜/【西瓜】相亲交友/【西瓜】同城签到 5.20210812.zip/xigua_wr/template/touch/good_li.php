<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{loop $list $_k $v}-->
<div class="wr_gdli">
    <a href="$SCRITPTNAME?id=xigua_wr&ac=good&gid=$v[id]">
        <div class="wr_gdimg">
            <img src="{echo $v[fengmian] ? $v[fengmian]: $v[album][0]}" alt="" onerror="this.error=null;this.src='source/plugin/xigua_hb/static/img/zhanwei.png'">
            <!--{if $v[kami]}--><em class="kamibtn inli">{lang xigua_wr:kami1}</em><!--{/if}-->
        </div>
        <div class="wr_gdc">
            <h2>{$v[title]}</h2>
            <p class="cl">
                <strong class="main_color"><!--{if $v[price]>0}-->&yen;{$v[price]}<!--{/if}--><!--{if $v[jfprice]}--><!--{if $v[price]>0}-->+<!--{/if}-->{$v[jfprice]}$ctitle<!--{/if}--></strong>
                <em class="wr_gdc_r"><em class="wr_visb">1</em><s>&yen;{$v[disprice]}</s></em>
            </p>
        </div>
    </a>
</div>
<!--{/loop}-->
