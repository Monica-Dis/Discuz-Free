<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_wr:header}--><style>.sfixed{top:2.1rem!important;}</style>
<!--{if $wr_ext_setting['goods_pic']}--><div style="width:0;height:0;overflow:hidden;display:none"><img src="$wr_ext_setting['goods_pic']" /></div><!--{/if}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-cells fixbanner before_none mt0 after_none">
        <div class="weui-navbar weui-banner nobg fixbanner_in">
            <a href="$SCRITPTNAME?id=xigua_wr&ac=goods" class="weui-navbar__item <!--{if !$_GET[hy]}-->weui_bar__item_on<!--{/if}-->">
                <span>{lang xigua_hb:quanbu}</span>
            </a>
            <!--{loop $svicerange $_k $_v}-->
            <a href="$SCRITPTNAME?id=xigua_wr&ac=goods&hy={echo urlencode($_v);}" class="weui-navbar__item <!--{if $_GET[hy]==$_v}-->weui_bar__item_on<!--{/if}-->">
                <span>$_v</span>
            </a>
            <!--{/loop}-->
        </div>
    </div>
    <div  id="list" class="weui-cells p0 mt0 before_none after_none" style="background:transparent"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>
    var loadingurl = window.location.href+'&ac=good_li&inajax=1&page=';
</script>
<!--{eval $wr_tabbar=1;$tabbar=0;}-->
<!--{template xigua_wr:footer}-->