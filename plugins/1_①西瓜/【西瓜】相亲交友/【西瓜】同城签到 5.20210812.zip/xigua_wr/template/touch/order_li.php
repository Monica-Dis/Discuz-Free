<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="pt_order_li">
    <div class="pt_shlink">
        <a>
            <span>{lang xigua_wr:ddbh} : </span>
            <span class="f13">{$v['order_id']}</span>
        </a>
        <!--{if $v[fa_ts]>0}-->
        <div class="main_color y f14"> {lang xigua_wr:hx2}</div>
        <!--{else}-->
        <div class="main_color y f14"> {$status_font[$v[status]]}</div>
        <!--{/if}-->
    </div>
    <div class="sp_good_od weui-cell weui-cell_access before_none after_none" style="display:block;overflow:hidden" data-id="$v[id]" <!--{if $_GET[manage]}-->data-manage="1"<!--{/if}-->>
        <div class="weui-cell__hd z">
            <label class="weui-label " style="width:4.75rem">
                <img style="width: 4rem;height: 4rem;" src="{eval echo $v[goodshot][fengmian] ? $v[goodshot][fengmian] : $v[goodshot][album][0]}" />
            </label>
        </div>
        <div class="weui-cell__bd ">
            <p class="f14 c3 order_li_title">{$v[goodshot][title]} {$v[goodshot][subtitle]}</p>
<!--{eval $price_str = C::t('#xigua_wr#xigua_wr_good')->get_price_str($v[goodshot], 1);}-->
            <div class="f14 cl main_color">$price_str  <span class="y">x {$v[gnum]}</span></div>
        </div>
    </div>
    <div class="pt_func  weui-cell before_none">
        <div class="weui-cell__bd f14">
            <!--{eval $price_str = C::t('#xigua_wr#xigua_wr_good')->get_price_str($v[goodshot], $v[gnum]);}-->
            {lang xigua_wr:sfk}:  <strong class="main_color">$price_str</strong>
        </div>
        <div class="weui-cell__ft">

            <!--{template xigua_wr:order_status}-->
        </div>
    </div>
    <div class="weui-cell before_none pt0">
        <div class="weui-cell__bd f12"><img src="{avatar($v[uid], middle, true)}" class="pt_usr" style="width:24px;height:24px;" > $v['username']</div>
        <div class="weui-cell__ft f12">
            {lang xigua_wr:xdsj} : {$v[crts_u]}
        </div>
    </div>
</div>
<!--{/loop}-->