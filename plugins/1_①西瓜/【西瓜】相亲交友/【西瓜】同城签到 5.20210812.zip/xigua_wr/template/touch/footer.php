<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{template xigua_wr:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<script src="source/plugin/xigua_wr/static/js/wr.js?2{VERHASH}"></script>