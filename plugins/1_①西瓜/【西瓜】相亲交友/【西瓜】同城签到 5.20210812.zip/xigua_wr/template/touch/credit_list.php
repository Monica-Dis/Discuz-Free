<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢�� wxiguabbs'); ?>
<!--{template xigua_wr:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div  id="list" class="weui-cells p0 mt0 before_none after_none" style="background:transparent"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>
    var loadingurl = window.location.href+'&ac=credit_li&inajax=1&page=';
</script>
<!--{eval $wr_tabbar=1;$tabbar=0;}-->
<!--{template xigua_wr:footer}-->