<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_wr:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <!--{eval $mang = $_GET['manage']? '&manage=1':'';}-->

    <div class="weui-navbar after_none">
        <a href="$SCRITPTNAME?id=xigua_wr&ac=order&keyword=$keyword{$mang}" class="weui-navbar__item <!--{if !$_GET[status]}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_wr:qb}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_wr&ac=order&keyword=$keyword&status=1{$mang}" class="weui-navbar__item <!--{if $_GET[status]==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{$status_font[1]}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_wr&ac=order&keyword=$keyword&status=2,6&fa_ts=-1{$mang}" class="weui-navbar__item <!--{if $_GET[status]=='2,6'&&$_GET['fa_ts']==-1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_wr:dfh}</span>
        </a>
        <a href="$SCRITPTNAME?id=xigua_wr&ac=order&keyword=$keyword&status=2,6&fa_ts=1{$mang}" class="weui-navbar__item <!--{if $_GET[status]=='2,6'&&$_GET['fa_ts']==1}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_wr:dshuo}</span>
        </a>
    </div>
    <div  id="list" class="weui-cells p0 mt0 before_none after_none" style="background:transparent"></div>
    <!--{template xigua_hb:loading}-->
</div>

<script>
    var loadingurl = window.location.href+'&ac=order_li&inajax=1&page=';
    var noTit = true;
    $(document).on('click','.sp_good_od', function () {
        var that = $(this);
        var jmpurl = _APPNAME +'?id=xigua_wr&ac=order_profile&ptlog_id='+that.data('id')+(that.data('manage') ? '&manage=1':'')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
        hb_jump(jmpurl);
    });
</script>
<!--{eval $wr_tabbar=1;$tabbar=0;}-->
<!--{template xigua_wr:footer}-->