<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{eval $splist = C::t('#xigua_wr#xigua_wr_good')->fetch_all_by_where(array("stat=1"), 0, 6, 'displayorder desc, stock desc');
}--><!--{if $splist}-->
<div class="sign_rule" style="<!--{if $_GET[hide]}-->display:none<!--{/if}-->">
<div class="sign_rule_head"><span>{lang xigua_wr:jfsc}</span></div>
<div>
<style>.coupon_swiper .swiper-slide{width:7.25rem}.seclight_box{width:5.25rem!important;margin:0 .75rem 0 0 ;overflow:hidden}.seclight_img{width:100%;height:4rem;display:block}.seclight_box .p1{font-size:.6rem;color:#333;height:1rem;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:1.1rem}.seclight_box .p2{height:1.4rem!important;overflow:hidden}</style>
<div class="swiper-container coupon_swiper">
    <div class="swiper-wrapper">
        <!--{loop $splist $k $qv}-->
        <!--{eval $spthumb = $qv['fengmian'] ? $qv['fengmian'] : $qv['album'][0];}-->
        <div class="swiper-slide seclight_box">
            <a href="$SCRITPTNAME?id=xigua_wr&ac=good&gid={$qv[id]}{$urlext}">
                <div class="pr">
                    <img class="seclight_img" style="height:5rem;width:5rem" src="{$spthumb}">
                </div>
                <div class="p1">{$qv[title]}</div>
                <div class="p2" style="overflow: hidden;white-space: nowrap;text-overflow: ellipsis">
                    <strong class="main_color f14"><!--{if $qv[price]>0}-->&yen;{$qv[price]}<!--{/if}--><!--{if $qv[jfprice]}--><!--{if $qv[price]>0}-->+<!--{/if}-->{$qv[jfprice]}$ctitle<!--{/if}--></strong>
                    <em class="wr_gdc_r"><s class="f14">&yen;{$qv[disprice]}</s></em>
                </div>
            </a>
        </div>
        <!--{/loop}-->
    </div>
</div>
<a class="moregood" href="$SCRITPTNAME?id=xigua_wr&ac=goods{$urlext}" >{lang xigua_wr:moregood}</a>
</div>
</div>
<!--{/if}-->