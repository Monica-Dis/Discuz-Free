<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval $status = $v[status];}-->
<!--{if $v[status]==5}-->
<div class="pro_top main_bg">
    <p>{lang xigua_wr:ptwcg}</p>
    <p>{lang xigua_wr:yqxhb}</p>
</div>
<!--{elseif in_array($v[status], array(3,4,7))}-->
<div class="pro_top main_bg">
    <p>{lang xigua_wr:ddyqx}</p>
    <!--{if $v[status]==7}-->
    <p>{lang xigua_wr:pdsbytk}</p>
    <!--{/if}-->
    <!--{if $v[status]==3}-->
    <p>{lang xigua_wr:status_3} <span class="f12">{lang xigua_wr:sqsj} $refund[crts_u]</span></p>
    <!--{/if}-->
</div>
<!--{elseif in_array($v[status], array(2,6))}-->
<div class="pro_top main_bg">
    <p>{$status_font[$status]}</p>
<!--{if !$v['hxcode']}-->
        <!--{if $v[fa_ts]==-1}-->
        <p>{lang xigua_wr:dfh}</p>
        <!--{elseif $v[shou_ts]==-1}-->
        <p>{lang xigua_wr:dshuo}</p>
        <p>{lang xigua_wr:kd}: {$v[yundan_gs]}</p>
        <p>{lang xigua_wr:ydh}: {$v[yundan]}</p>
        <!--{elseif $v[shou_ts]>1}-->
        <p>{lang xigua_wr:ysh} {$v[shou_ts_u]}</p>
        <p>{lang xigua_wr:kd}: {$v[yundan_gs]}</p>
        <p>{lang xigua_wr:ydh}: {$v[yundan]}</p>
        <!--{/if}-->
        <!--{if $v[yundan]}-->
            <!--{if $wr_config[kdcode]}-->
                <a id="seckdcode" style="display:none" href="https://m.kuaidi100.com/result.jsp?nu={$v[yundan]}" target="_blank">{lang xigua_wr:kdgz}&raquo;</a>
            <!--{else}-->
                <a href="https://m.kuaidi100.com/result.jsp?nu={$v[yundan]}" target="_blank">{lang xigua_wr:kdgz}&raquo;</a>
            <!--{/if}-->
        <!--{/if}-->
<!--{else}-->
    <!--{eval $kkmm = explode(',', $v[hxcode]);}-->
    <!--{loop $kkmm $_k $_v}-->
    <p>{lang xigua_wr:kami1}: {$_v}</p>
    <!--{/loop}-->
<!--{/if}-->
</div>
<!--{else}-->
<div class="pro_top main_bg">
    <p>{$status_font[$status]}</p>
</div>
<!--{/if}-->



