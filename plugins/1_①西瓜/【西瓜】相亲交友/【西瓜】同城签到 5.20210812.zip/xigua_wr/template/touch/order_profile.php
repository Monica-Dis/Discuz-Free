<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_wr:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->

    <!--{template xigua_wr:order_top}-->

    <div class="shoubox weui-cells before_none after_none mt0">
        <a class="weui-cell weui-cell_access after_none" href="javascript:;" <!--{if $v[status]==1||$v[status]==5}-->id="pay_address"<!--{/if}--> >
            <div class="weui-cell__hd">
                <label class="weui-label" style="width:auto"><i class="iconblack main_bg">{lang xigua_wr:shou}</i></label>
            </div>
            <div class="weui-cell__bd c3">
                <div class="f12 "><span class="f14">{$v[realname]}</span>&nbsp;{$v[mobile]}</div>
                <div class="f12 mt3">{$v[addr]}</div>
            </div>
            <!--{if $v[status]==1||$v[status]==5}--><div class="weui-cell__ft"></div><!--{/if}-->
            <div class="addrbx"></div>
        </a>
    </div>

    <div class="shoubox pt_order_li mt10">
        <div class="jump_wr weui-cell weui-cell_access before_none after_none" style="display:block;overflow:hidden" data-id="{$v[goodshot][id]}">
            <div class="weui-cell__hd z">
                <label class="weui-label " style="width:4.75rem">
                    <img style="width: 4rem;height: 4rem;" src="{echo $v[goodshot][fengmian] ? $v[goodshot][fengmian] : $v[goodshot][album][0] }"/>
                </label>
            </div>
            <div class="weui-cell__bd ">
                <p class="f14 c3">{$v[goodshot][title]} {$v[goodshot][subtitle]}</p>
                <!--{eval $price_str = C::t('#xigua_wr#xigua_wr_good')->get_price_str($v[goodshot], 1);}-->
                <div class="f14 cl main_color">$price_str  <span class="y">x {$v[gnum]}</span></div>
            </div>
        </div>
        <div class="pt_func  weui-cell">
            <div class="weui-cell__bd f14">
                <!--{eval $price_str = C::t('#xigua_wr#xigua_wr_good')->get_price_str($v[goodshot], $v[gnum]);}-->
                {lang xigua_wr:sfk}:  <strong class="main_color">$price_str</strong>
            </div>
            <div class="weui-cell__ft">
                <!--{template xigua_wr:order_status}-->
            </div>
        </div>
    </div>
    <!--{if $v[yundan]&&$wr_config[kdcode]}-->
    <div class="shoubox ">
    <div class="weui-cells__title" id="kdcode_title">{lang xigua_wr:kdgz}</div>
    <div class="wuei-cells" id="kdcode"></div>
    </div>
    <script>
        var s2 = localStorage.getItem('kd{$v[yundan]}');
        var s3 = localStorage.getItem('kd{$v[yundan]}_expire')>{echo time();};
        console.log(localStorage.getItem('kd{$v[yundan]}_expire'));
        if(s2 && s3){
            $('#seckdcode').hide();
            $('#kdcode').html(s2).show();
            $('#kdcode_title').show();
        }else{
            $.ajax({type: 'get',url: _APPNAME +'?id=xigua_wr&ac=com&do=kd&inajax=1&danhao={$v[yundan]}',dataType: 'xml',
                success: function (data) {
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    if(!s){
                        $('#seckdcode').show();
                        $('#kdcode').hide();
                        $('#kdcode_title').hide();
                    }else{
                        $('#seckdcode').hide();
                        $('#kdcode').html(s).show();
                        $('#kdcode_title').show();
                        localStorage.setItem('kd{$v[yundan]}', s);
                        localStorage.setItem('kd{$v[yundan]}_expire', '{echo time()+$sp_config[kdcache];}');
                    }
                }
            });
        }
    </script>
    <!--{/if}-->
    <div class="shoubox weui-cells before_none after_none">
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_wr:gmyh} :
            </div>
            <div class="weui-cell__bd f14">
                <img src="{avatar($v[uid], middle, true)}" class="pt_usr" style="width:24px;height:24px;margin-left:10px" > $v['username']
            </div>
        </div>
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_hb:bind_mobile} :
            </div>
            <!--{eval
            $mobile = $v['mobile'];
            if(!$mobile):
                $__profile = C::t('common_member_profile')->fetch($v['uid']);
                $mobile = $__profile['mobile'];
            endif;
            }-->
            <div class="weui-cell__bd f14"> {$mobile}
            </div>
        </div>
        <!--{if $v['note']}-->
        <div class="weui-cell before_none after_none">

            <div class="weui-cell__hd f14">
                {lang xigua_wr:bz} :
            </div>
            <div class="weui-cell__bd f14">
                $v['note']
            </div>
        </div>
        <!--{/if}-->
        <!--{if $v['order_id']}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_wr:ddbh} :
            </div>
            <div class="weui-cell__bd f14">
                $v['order_id']
            </div>
        </div>
        <!--{/if}-->
        <div class="weui-cell before_none after_none">
            <div class="weui-cell__hd f14">
                {lang xigua_wr:xdsj} :
            </div>
            <div class="weui-cell__bd f14">
                $v['crts_u']
            </div>
        </div>
    </div>
</div>
<!--{eval $wr_tabbar=1;$tabbar=0;}-->
<!--{template xigua_wr:footer}-->