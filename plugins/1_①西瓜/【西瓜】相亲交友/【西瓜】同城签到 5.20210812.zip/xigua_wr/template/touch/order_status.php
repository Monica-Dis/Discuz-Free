<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<style>.weui-btn_mini{padding:0 5px}</style>

<!--{if $v[goodshot][kami]}-->
<span class="f12">{lang xigua_wr:xnkm}</span>
<!--{/if}-->
<!--{if $v[jumpurl] }-->
    <a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default cancel_order " data-id="$v[id]">{lang xigua_wr:qxdd}</a>
    <a href="$v[jumpurl]" class="mt0 weui-btn weui-btn_mini weui-btn_primary">{lang xigua_wr:ljzf}</a>
<!--{elseif in_array($v[status], array(2,6)) && $v[shou_ts]>1}-->
<!--{elseif in_array($v[status], array(3,4,7)) }-->
    <a href="$SCRITPTNAME?id=xigua_wr&ac=good&gid=$v[gid]{$urlext}" class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default">{lang xigua_wr:zcgm}</a>
<!--{/if}-->

<!--{if $ac !='order_profile'}-->
<!--{if !$v[jumpurl]}-->
<a class="pt_btn_dft weui-btn weui-btn_mini weui-btn_default sp_good_od mt0" data-id="$v[id]" <!--{if $_GET[manage]}-->data-manage="1"<!--{/if}-->>{lang xigua_wr:ddxq}</a>
<!--{/if}-->
<!--{/if}-->
