<?php exit('Author: https://addon.dismall.com/?@xigua �������� �ͷ�QQ 1628585958 ΢��wxiguabbs'); ?>
<!--{if $wr_tabbar}-->
<!--{eval
$custom_nav = C::t('#xigua_wr#xigua_wr_nav')->fetch_index();
$navcount = count($custom_nav);
$is_off = 1;
$curturl = hb_currenturl();
}-->
<div class="weui-tabbar<!--{if $showfloatapp}--> none<!--{/if}-->">
    <!--{loop $custom_nav $loop_k $loopin}--><!--{eval
$highlight = '&high='.$loop_k;
if($loopin['adlink']=='pub'):
    $inlink = 'javascript:;" class="pubj weui-tabbar__item weui-bar__item_on showpubfont" id="pubj';
    if($wr_config[onlyapp]):
        $inlink = 'javascript:;" data-onlyapp="1" data-apptip="'.$wr_config[apptip].'" data-applink="'.$wr_config[applink].'" class="pubj" id="pubj';
    endif;
else:
    $inlink = $loopin['adlink'].$highlight;
endif;
$is_on = !$is_on && (  strpos($curturl,$inlink)!==false || strpos($curturl,$highlight)!==false  || ($_GET['high'] && $_GET['high']==$loop_k)  );
if($is_on):
    $loopin[icon] = $loopin[icon2]?$loopin[icon2]:$loopin[icon];
endif;
}-->
<!--{if $loopin[up]}-->
<a href="{$inlink}" class="weui-tabbar__item weui-bar__item_on showpubfont"><div class="pub_circle"></div>
    <!--{if $loopin[icon2]}-->
    <img src="$loopin[icon2]" class="tabcon" />
    <!--{/if}-->
    <p class="weui-tabbar__label pub_circle_p" style="color:#777!important">{$loopin[name]}</p>
</a>
<!--{else}-->
<a href="{$inlink}" class="weui-tabbar__item <!--{if $is_on}-->weui-bar__item_on<!--{/if}-->">
    <!--{if $loopin[icon]}-->
    <img src="$loopin[icon]" class="tabcon3" />
    <!--{/if}-->
    <p class="weui-tabbar__label">{$loopin[name]}</p>
</a>
<!--{/if}-->
<!--{/loop}-->
</div>
<!--{/if}-->