<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2016/2/14
 * Time: 18:49
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_wr/common.php';
DB::query('delete from %t where crdate!=%s', array('xigua_wr_viewlog', date('Y-m-d', TIMESTAMP)));

$page = max(1, intval($_GET['page']));
$lpp = $_GET['lpp'] ? $_GET['lpp'] : 20;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        C::t('#xigua_wr#xigua_wr_sign')->deletes($delete);
    }
    if($r = $_GET['r']){
        foreach ($r as $index => $item) {
            C::t('#xigua_wr#xigua_wr_sign')->update($index, $item);
        }
    }
    unset($_GET['formhash']);
    unset($_GET['r']);
    unset($_GET['permsubmit']);
    cpmsg(lang_hb('succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_sign&".http_build_query($_GET)."&page=$page&lpp=$lpp", 'succeed');
}

$wherearr = array();
$keyword = stripsearchkey($_GET['keyword']);
if(is_numeric($keyword) && $keyword<9999999999){
    $wherearr[] = "uid='$keyword'";
}

$order = 'id desc';
if($_GET['status']&&$_GET['status']<97){
    $wherearr[] = "status='".intval($_GET['status'])."'";
}

echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
echo "<style>.abtn,.btn{padding:2px 6px;background:".$wr_config['color'].";color:#fff;}.highink em{color:".$wr_config['color'].";font-weight:bold}
    .km2{padding:0 3px;border-radius:2px;font-size:12px;color:#fff;background:#369;margin-right:3px}.km2:last-child{margin-right:0}</style>";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_sign");
echo '<div><input type="text" id="keyword" name="keyword" placeholder="UID" value="'.$_GET['keyword'].'" class="txt"  /> ';

echo '&nbsp;&nbsp;&nbsp;';
$lpp_se = "<select name=\"lpp\">";
foreach (array(1, 10 ,20, 50, 100, 200, 500, 1000, 2000, 5000) as $item) {
    $sellpp = '';
    if($item == $lpp){
        $sellpp = "selected";
    }
    $lpp_se .= "<option $sellpp value=\"$item\">$item</option>";
}
$lpp_se .= "</select>";
echo $lpp_se;

echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo ' <a href='.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_sign".' class="btn" >'.cplang('reset').'</a> ';

echo '</div>';

showtableheader(lang_wr('signmanage', 0));
$ress = array();

showtablerow('class="header"',array(),$ress[] = array(
    lang_hb('del', 0),
    lang_wr('ID', 0),
    lang_wr('fkyh', 0),
    lang_wr('signdate', 0),
    lang_wr('getexp', 0),
    lang_wr('linexp', 0),
    lang_wr('leijiexp', 0),
    lang_wr('note', 0),
    lang_wr('crts', 0),
));

$res = C::t('#xigua_wr#xigua_wr_sign')->fetch_all_by_where($wherearr, $start_limit, $lpp, $order);
$icount = C::t('#xigua_wr#xigua_wr_sign')->fetch_count_by_where($wherearr);

foreach ($res as $v) {
    $uids[] = $v['uid'];
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    $vusers = DB::fetch_all('SELECT * FROM %t WHERE uid IN (%n)', array('xigua_hb_user', $uids), 'uid');
}

foreach ($res as $k => $v) {

    $id = $v['id'];
    $uid = $v['uid'];

    showtablerow('', array(), $res_ = array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$id' />",
        $id,
        "<a href='home.php?mod=space&uid=$uid&do=profile' target='_blank'>{$users[$uid]['username']}</a> [ UID: $uid ]",
        $v['signdate'],
        $v['getexp'] ,
        $v['linexp'] ,
        $v['leijiexp'] ,
        $v['note'] ,
        date('Y-m-d H:i:s', $v['crts']) ,

    ));
}


$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_sign&lpp=$lpp&".http_build_query($_GET).'&doexport=0', 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter();
