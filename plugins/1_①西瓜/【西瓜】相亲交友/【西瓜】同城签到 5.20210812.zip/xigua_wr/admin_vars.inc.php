<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT .'source/plugin/xigua_wr/common.php';
DB::query('delete from %t where crdate!=%s', array('xigua_wr_viewlog', date('Y-m-d', TIMESTAMP)));
$_GET['plu'] = 'xigua_wr';
$config_ary_merge = array();
foreach ($wr_selects as $index => $select) {
    $la_num = '';
    foreach ( explode('_', $select[0]) as $index1 => $item) {
        $la_num .= lang_wr($item,0);
    }
    $config_ary_merge[$select[0].'_tubiao'] = array('type' => 'filetext', 'lang' => $la_num.lang_wr('tubiao',0));
    if($select[0]!='sign'){
        $config_ary_merge[$select[0].'_num'] = array('type' => 'text', 'lang' => $la_num.lang_wr('num',0));
        $config_ary_merge[$select[0].'_jiangli'] = array('type' => 'text', 'lang' => $la_num.lang_wr('jiangli',0));
    }
    $config_ary_merge[$select[0].'_desc'] = array('type' => 'text', 'lang' => $la_num.lang_wr('desc',0));
    $config_ary_merge[$select[0].'_btn'] = array('type' => 'text', 'lang' => $la_num.lang_wr('btn',0));
    $config_ary_merge[$select[0].'_fbtn'] = array('type' => 'text', 'lang' => $la_num.lang_wr('fbtn',0));
}

$config_ary = array(
    'openwr' =>  array('type' => 'mselect', 'selects' => $wr_selects),
    'indexbg' => array('type' => 'filetext', 'lang' => lang_wr('indexbg',0)),
    'share_desc' => array('type' => 'text', 'lang' => lang_wr('share_desc',0)),
    'share_pic' => array('type' => 'filetext', 'lang' => lang_wr('share_pic',0)),
    'goods_title' => array('type' => 'text', 'lang' => lang_wr('goods_title',0)),
    'goods_desc' => array('type' => 'text', 'lang' => lang_wr('goods_desc',0)),
    'goods_pic' => array('type' => 'filetext', 'lang' => lang_wr('goods_pic',0)),
);
$config_ary = array_merge($config_ary, $config_ary_merge);

if(submitcheck('formhash')){
    $editform = $_GET['editform'];
    $_newimglist = hb_uploads($_FILES['editform']);
    foreach ($_newimglist as $__k => $__v) {
        if ($__v['errno'] == 0) {
            $editform[$__k] = $__v['error'];
        }
    }
    savecache($wr_cache_key, $editform);
    cpmsg(lang_hb('succeed', 0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_vars&plu=".$_GET['plu'], 'succeed');
}else{
    $link = ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_vars&plu=";
    echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?123\" /><style>.naver{border-bottom:1px solid;height:40px;padding:0;display:block;background:#3a4b59}
.btn_var:hover{text-decoration:none;font-weight:700}
.btn_var{margin:0 0 0 10px;padding:0 5px;text-decoration:none;height:39px;line-height:39px;font-size:14px;float:left;display:block;color:#fff}
.btn_var.cur{font-weight:700;background:#3a4b59;color:#fff;border-bottom:2px solid #fd971e}
</style>";
    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_wr&pmod=admin_vars&plu=".$_GET['plu'], 'enctype');
    showtableheader();
    loadcache($wr_cache_key);
    foreach ($config_ary as $index => $item) {
        $val = $_G['cache'][$wr_cache_key][$index];
        if($val == array()){
            $val = '';
        }
        if(!$val){
            $val = $item['value'];
        }
        if($item['lang']){
            $varlang = $item['lang'];
        }else{
            $varlang = lang_wr($index, 0);
            if(preg_match('/(\w+)(\d+)/is', $varlang, $ms)){
                $varlang = lang_wr($ms[1], 0).' '.$ms[2];
            }
        }
        if($item['type']=='filetext' && $val){
            $item['comment'] .= ($item['comment']?'<br>':''). '<img style="height:30px;" src="'.$val.'" onerror="this.error=null;this.style.display=\'none\'" />';
        }
        if($item['type']=='mselect'){
            showsetting($varlang, array("editform[$index][]", $item['selects']), $val, $item['type'], '', 0, $item['comment']);
        }else{
            showsetting($varlang, "editform[$index]", $val, $item['type'], '', 0, $item['comment']);
        }
    }
    showsubmit('varsubmit');
    showtablefooter(); /*dism��taobao��com*/
    showformfooter();
}


function pvsort($key, $v, $s) {
    $r = '/';
    $p = '';
    foreach($key as $k) {
        $r .= $p.preg_quote($k);
        $p = '|';
    }
    $r .= '/';
    preg_match_all($r, $v, $a);
    $a = $a[0];
    $a = array_flip($a);
    foreach($a as $key => $value) {
        $s = str_replace($key, '$'.($value + 1), $s);
    }
    return $s;
}

function pvadd($s, $t = 0) {
    $s = str_replace(array('$3', '$2', '$1'), array('~4', '~3', '~2'), $s);
    if(!$t) {
        return str_replace(array('~4', '~3', '~2'), array('$4', '$3', '$2'), $s);
    } else {
        return str_replace(array('~4', '~3', '~2'), array('{R:4}', '{R:3}', '{R:2}'), $s);
    }

}

function checkfiles($currentdir, $ext = '', $sub = 1, $skip = '') {
    global $md5data;
    $dir = @opendir(DISCUZ_ROOT.$currentdir);
    $exts = '/('.$ext.')$/i';
    $skips = explode(',', $skip);

    while($entry = @readdir($dir)) {
        $file = $currentdir.$entry;
        if($entry != '.' && $entry != '..' && (($ext && preg_match($exts, $entry) || !$ext) || $sub && is_dir($file)) && !in_array($entry, $skips)) {
            if($sub && is_dir($file)) {
                checkfiles($file.'/', $ext, $sub, $skip);
            } else {
                if(is_dir($file)) {
                    $md5data[$file] = md5($file);
                } else {
                    $md5data[$file] = md5_file($file);
                }
            }
        }
    }
}

function checkcachefiles($currentdir) {
    global $_G;
    $dir = opendir($currentdir);
    $exts = '/\.php$/i';
    $showlist = $modifylist = $addlist = array();
    while($entry = readdir($dir)) {
        $file = $currentdir.$entry;
        if($entry != '.' && $entry != '..' && preg_match($exts, $entry)) {
            $fp = fopen($file, "rb");
            $cachedata = fread($fp, filesize($file));
            fclose($fp);

            if(preg_match("/^<\?php\n\/\/Discuz! cache file, DO NOT modify me!\n\/\/Identify: (\w+)\n\n(.+?)\?>$/s", $cachedata, $match)) {
                $showlist[$file] = $md5 = $match[1];
                $cachedata = $match[2];

                if(md5($entry.$cachedata.$_G['config']['security']['authkey']) != $md5) {
                    $modifylist[$file] = $md5;
                }
            } else {
                $showlist[$file] = '';
            }
        }
    }

    return array($showlist, $modifylist, $addlist);
}

function checkmailerror($type, $error) {
    global $alertmsg;
    $alertmsg .= !$alertmsg ? $error : '';
}

function getremotefile($file) {
    global $_G;
    @set_time_limit(0);
    $file = $file.'?'.TIMESTAMP.rand(1000, 9999);
    $str = @implode('', @file($file));
    if(!$str) {
        $str = dfsockopen($file);
    }
    return $str;
}

function checkhook($currentdir, $ext = '', $sub = 1, $skip = '') {
    global $hooks, $hookdata;
    $dir = opendir($currentdir);
    $exts = '/('.$ext.')$/i';
    $skips = explode(',', $skip);

    while($entry = readdir($dir)) {
        $file = $currentdir.$entry;
        if($entry != '.' && $entry != '..' && (preg_match($exts, $entry) || $sub && is_dir($file)) && !in_array($entry, $skips)) {
            if($sub && is_dir($file)) {
                checkhook($file.'/', $ext, $sub, $skip);
            } else {
                $data = file_get_contents($file);
                $hooks = array();
                preg_replace("/\{hook\/(\w+?)(\s+(.+?))?\}/ie", "findhook('\\1', '\\3')", $data);
                if($hooks) {
                    foreach($hooks as $v) {
                        $hookdata[$file][$v][] = $v;
                    }
                }
            }
        }
    }
}

function findhook($hookid, $key) {
    global $hooks;
    if($key) {
        $key = ' '.$key;
    }
    $hooks[] = '<!--{hook/'.$hookid.$key.'}-->';
}
