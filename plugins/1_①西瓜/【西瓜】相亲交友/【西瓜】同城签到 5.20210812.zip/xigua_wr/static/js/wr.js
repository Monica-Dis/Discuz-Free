
$(document).on('click', '.jump_wr', function () {
    var that = $(this);
    var jmpurl = _APPNAME +'?id=xigua_wr&ac=good&gid='+that.data('id')+(typeof _URLEXT!=='undefined'? _URLEXT : '');
    hb_jump(jmpurl);
    return false;
});
$(document).on('click','.cancel_order', function () {
    var that = $(this);
    $.confirm(QDYX, function () {
        $.showLoading();
        $.ajax({
            type: "POST",
            url: _APPNAME+"?id=xigua_wr&ac=cancel_order&inajax=1&ordid="+that.data('id'),
            data:{formhash:FORMHASH},
            dataType: "xml",
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            }
        });
    }, function () {
    });
});