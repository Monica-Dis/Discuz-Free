<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2020/10/10
 * Time: 15:16
 */

if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_wr_viewlog` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(1) NOT NULL,
 `act` varchar(200) NOT NULL,
 `actdesc` varchar(200) NOT NULL,
 `crts` int(11) NOT NULL,
 `crdate` date NOT NULL,
 `dataid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `act` (`act`),
 KEY `crdate` (`crdate`),
 KEY `dataid` (`dataid`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_wr_sign` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) unsigned NOT NULL,
 `crts` int(11) unsigned NOT NULL,
 `signdate` date NOT NULL,
 `signmonth` int(11) NOT NULL,
 `signday` int(11) NOT NULL,
 `getexp` int(11) unsigned NOT NULL,
 `linexp` int(11) unsigned NOT NULL DEFAULT '0',
 `isbu` int(11) unsigned NOT NULL DEFAULT '0',
 `leijiexp` int(11) NOT NULL,
 `note` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `ts` (`crts`),
 KEY `uid` (`uid`),
 KEY `signdate` (`signdate`),
 KEY `signmonth` (`signmonth`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_wr_order` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `crts` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `order_id` varchar(200) NOT NULL,
 `buy_type` int(11) NOT NULL COMMENT '1dandu2pt',
 `tuan_id` int(11) NOT NULL COMMENT 'tuandan',
 `gnum` int(11) NOT NULL,
 `tuan_num` int(11) NOT NULL,
 `pay_money` decimal(10,2) NOT NULL,
 `addrid` int(11) NOT NULL,
 `addr` varchar(200) NOT NULL,
 `pay_ts` int(11) NOT NULL,
 `fa_ts` int(11) NOT NULL DEFAULT '-1',
 `shou_ts` int(11) DEFAULT '-1',
 `tui_ts` int(11) NOT NULL,
 `tuicfm_ts` int(11) NOT NULL,
 `gid` int(11) NOT NULL,
 `priceid` int(11) NOT NULL,
 `priceinfo` varchar(2000) NOT NULL,
 `goodinfo` text NOT NULL,
 `note` varchar(500) NOT NULL,
 `yunfee` decimal(10,2) NOT NULL,
 `title` varchar(200) NOT NULL,
 `pay_endts` int(11) NOT NULL,
 `mobile` varchar(200) NOT NULL,
 `realname` varchar(200) NOT NULL,
 `status` int(11) NOT NULL,
 `pt_success_ts` int(11) NOT NULL,
 `cmtid` int(11) NOT NULL DEFAULT '-1',
 `shid` int(11) NOT NULL,
 `unit_price` decimal(10,2) NOT NULL,
 `shixian` int(11) NOT NULL,
 `yundan` varchar(200) NOT NULL,
 `yundan_gs` varchar(200) NOT NULL,
 `upts` int(11) NOT NULL,
 `hxuid` int(11) NOT NULL,
 `hxcrts` int(11) NOT NULL,
 `hxnote` varchar(200) NOT NULL,
 `hxcode` text NOT NULL,
 `refund` varchar(80) NOT NULL,
 `exp_method` varchar(20) NOT NULL,
 `pj_ts` int(11) NOT NULL DEFAULT '-1',
 `refund_id` int(11) NOT NULL,
 `ziti` varchar(200) NOT NULL,
 `jaddr` varchar(200) NOT NULL,
 `jname` varchar(80) NOT NULL,
 `jmobile` varchar(20) NOT NULL,
 `shou_confirm_ts` int(11) NOT NULL,
 `kahao` varchar(200) NOT NULL,
 `chengben` decimal(10,2) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `tuan_id` (`tuan_id`),
 KEY `order_id` (`order_id`),
 KEY `pay_endts` (`pay_endts`),
 KEY `shid` (`shid`),
 KEY `buy_type` (`buy_type`),
 KEY `crts` (`crts`),
 KEY `pay_ts` (`pay_ts`),
 KEY `fa_ts` (`fa_ts`),
 KEY `gid` (`gid`),
 KEY `status` (`status`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_wr_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS `pre_xigua_wr_good` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `title` varchar(40) NOT NULL,
 `subtitle` varchar(200) NOT NULL,
 `hy` varchar(200) NOT NULL,
 `disprice` decimal(10,2) NOT NULL,
 `price` decimal(10,2) NOT NULL,
 `jfprice` int(11) NOT NULL,
 `stat` int(11) NOT NULL COMMENT '1ok 2daishen 3xiajia',
 `fengmian` varchar(200) NOT NULL,
 `album` text NOT NULL,
 `jieshao` text NOT NULL,
 `stock` int(11) NOT NULL,
 `danci` int(11) NOT NULL,
 `sellnum` int(11) NOT NULL,
 `kami` mediumtext NOT NULL,
 `displayorder` int(11) NOT NULL,
 `uid` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `displayorder` (`displayorder`),
 KEY `stat` (`stat`),
 KEY `uid` (`uid`),
 KEY `title` (`title`),
 KEY `sellnum` (`sellnum`),
 KEY `crts` (`crts`)
) ENGINE=InnoDB;
SQL;
runquery($sql);

@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/discuz_plugin_xigua_wr_TC_UTF8.xml');

$finish = TRUE;
@unlink(DISCUZ_ROOT . './source/plugin/xigua_wr/install.php');

$r3 = DB::fetch_first('SELECT * FROM %t  WHERE 1 LIMIT 1', array('xigua_wr_nav'), true);
if(!$r3){
    $sql = <<<SQL
INSERT INTO `pre_xigua_wr_nav` (`id`, `pid`, `name`, `icon`, `icon2`, `adimage`, `adlink`, `ts`, `o`, `pushtype`, `price`, `tag`, `placehoder`, `endtime`, `cat_ids`, `miao`, `qiang`, `goodindex`, `telprice`, `stids`, `aprice`, `iconname`, `up`, `highlight`, `type`) VALUES
(1, 0, '{$installlang['index1']}', 'source/plugin/xigua_wr/static/img/index.png', 'source/plugin/xigua_wr/static/img/index_on.png', '', 'plugin.php?id=xigua_hb', 1626146858, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(2, 0, '{$installlang['index2']}', 'source/plugin/xigua_wr/static/img/qiandao.png', 'source/plugin/xigua_wr/static/img/qiandao_on.png', '', 'plugin.php?id=xigua_wr', 1626146858, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(3, 0, '{$installlang['index3']}', 'source/plugin/xigua_wr/static/img/jifen.png', 'source/plugin/xigua_wr/static/img/jifen_on.png', '', 'plugin.php?id=xigua_wr&ac=credit_list', 1626146858, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(4, 0, '{$installlang['index4']}', 'source/plugin/xigua_wr/static/img/shangcheng.png', 'source/plugin/xigua_wr/static/img/shangcheng_on.png', '', 'plugin.php?id=xigua_wr&ac=goods', 1626147167, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', ''),
(5, 0, '{$installlang['index5']}', 'source/plugin/xigua_wr/static/img/duihuan.png', 'source/plugin/xigua_wr/static/img/duihuan_on.png', '', 'plugin.php?id=xigua_wr&ac=order', 1626422135, 0, '', '0.00', '', '', 0, '', 0, 0, 0, '0.00', '', '0.00', '', 0, '', '');
SQL;
    runquery($sql);
}
