<?php
/*
 * CopyRight  : [DisM!] (C)2001-2099 DisM Inc.
 * Created on : 2021-06-17,10:53:25
 * Author     : DisM!Ӧ������ dism.taobao.com $
 * Description: This is NOT a freeware, use is subject to license terms.
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!is_file(DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php')) {
	exit('Please install <a href="https://addon.dismall.com/plugins/xigua_hb.html">https://addon.dismall.com/plugins/xigua_hb.html</a>');
}
if (empty($_G['cache']['plugin'])) {
	loadcache('plugin');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_wr/common.php';
$data = array();
$ac = $_GET['ac'];
$do = $_GET['do'];
$gid = intval($_GET['gid']);
$aclist = array('index', 'add', 'order', 'misc', 'credit_list', 'view', 'credit_li', 'com', 'cancel_order', 'myview', 'search', 'join', 'upv', 'mem_li', 'chats', 'chat', 'comment_li', 'hn', 'sign_data', 'do_sign', 'goods', 'good_li', 'good', 'confirm', 'shisuan', 'buy', 'order_li', 'order_profile', 'cz');
$aclist_login = array('add', 'order', 'credit_list', 'join', 'credit_li', 'upv', 'view', 'sign_data', 'chats', 'chat', 'do_sign', 'confirm', 'shisuan', 'buy', 'order_li', 'order_profile', 'cancel_order', 'cz');
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
if (in_array($ac, $aclist_login) && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
if ($wr_config['color']) {
	$config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $wr_config['color'];
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_wr/common.php';
include_once DISCUZ_ROOT . 'source/plugin/xigua_wr/function.php';
$opens = unserialize($_G['cache']['plugin']['xigua_wr']['opens']);
$pfary = $fsms = $score_names = $score_colors = array();
switch ($ac) {
	case 'cz':
		if (submitcheck('price1')) {
			if (!($cztype = $czcats[$_GET['price1']])) {
				hb_message('error', 'error');
			}
			$totalprice = floatval($_GET['price1']);
			$title = strip_tags($cztype[2]);
			$location = $_G['siteurl'] . $SCRITPTNAME . '?id=xigua_wr&ac=credit_list';
			$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_wrcz', array('data' => array('title' => $title, 'cztype' => $cztype, 'uid' => $_G['uid']), 'callback' => array('file' => 'source/plugin/xigua_wr/function.php', 'method' => 'callback_wrcz_pay', 'uid' => $_G['uid']), 'location' => $location, 'referer' => $SCRITPTNAME . '?id=xigua_wr', 'tip' => ''), 0);
			$rl = urlencode($location);
			$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
			hb_message(lang_wr('jumppay', 0), 'loading', $jumpurl);
		}
		break;
	case 'cancel_order':
		$ordid = intval($_GET['ordid']);
		if (submitcheck('ordid')) {
			$ov = C::t('#xigua_wr#xigua_wr_order')->fetch_G($ordid);
			if (!$ov || $ov['status'] != 1) {
				hb_message('error', 'error');
			}
			C::t('#xigua_wr#xigua_wr_order')->update_G($ordid, array('status' => 4, 'tuicfm_ts' => TIMESTAMP, 'tui_ts' => TIMESTAMP));
			DB::query('UPDATE %t SET stock=stock+%d WHERE id=%d', array('xigua_wr_good', intval($ov['gnum']), $ov['gid']));
			hb_message(lang_wr('ddyqx', 0), 'success', 'reload');
		}
		break;
	case 'order_profile':
		$ptlog_id = intval($_GET['ptlog_id']);
		$v = C::t('#xigua_wr#xigua_wr_order')->fetch_G($ptlog_id);
		if (!$v) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_wr&ac=order&mobile=2' . $urlext);
		}
		$v['username'] = DB::result_first('select username from %t where uid=%d', array('common_member', $v['uid']));
		$back_to_overwrite = $SCRITPTNAME . '?id=xigua_wr&ac=order';
		break;
	case 'order_li':
		$wherearr = array();
		$order = 'id DESC';
		if ($_GET['manage']) {
			$shids = sp_get_shids_by_uid();
			if ($shids) {
				$wherearr[] = 'shid in (' . implode(',', $shids) . ')';
			}
		} else {
			$wherearr[] = 'uid=' . $_G['uid'];
		}
		if ($_GET['status']) {
			$sta = dintval(explode(',', $_GET['status']), 1);
			$wherearr[] = 'status IN ( ' . implode(',', $sta) . ' )';
		}
		if ($_GET['shou_ts'] == 0 - 1) {
			$wherearr[] = 'shou_ts=-1';
		} elseif ($_GET['shou_ts'] == 1) {
			$wherearr[] = 'shou_ts>1';
		}
		if ($_GET['fa_ts'] == 0 - 1) {
			$wherearr[] = 'fa_ts=-1';
		} elseif ($_GET['fa_ts'] == 1) {
			$wherearr[] = 'fa_ts>1';
		}
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$wherearr[] = ' (title LIKE \'%' . $keyword . '%\' OR order_id LIKE \'%' . $keyword . '%\' OR mobile like \'%' . $keyword . '%\' OR realname like \'%' . $keyword . '%\') ';
		}
		$list = C::t('#xigua_wr#xigua_wr_order')->fetch_all_by_where($wherearr, $start_limit, $lpp, $order, '*', 1);
		include template('xigua_hb:header_ajax');
		include template('xigua_wr:' . $ac);
		include template('xigua_hb:footer_ajax');
		break;
	case 'order':
		$navtitle = lang_wr('wddh', 0);
		break;
	case 'buy':
		if (submitcheck('formhash')) {
			$form = $_GET['form'];
			$note = strip_tags($form['note']);
			$addrid = intval($form['addrid']);
			$gid = intval($form['gid']);
			$good = C::t('#xigua_wr#xigua_wr_good')->fetch_by_gid($gid, 0);
			$num = intval($form['item_num']);
			if ($num < 1) {
				hb_message(lang_wr('slcw', 0), 'error');
			}
			if ($good['stock'] < $num) {
				hb_message(lang_wr('kcbz', 0), 'error');
			}
			if ($good['stat'] != 1) {
				hb_message(lang_wr('spyxj', 0), 'error');
			}
			if (!$good['kami']) {
				if (!($form['dist1'] . $form['dist2'] . $form['dist3'] . $form['address'])) {
					hb_message(lang_wr('qszshdz', 0), 'error');
				}
				if (!$form['mobile']) {
					hb_message(lang_hb('mobile_tip', 0), 'error');
				}
			}
			if (getuserprofile('extcredits' . $wr_config['ctypee']) < $good['jfprice'] * $num) {
				hb_message($ctitle . lang_wr('buzu', 0), 'error');
			}
			$price_str = C::t('#xigua_wr#xigua_wr_good')->get_price_str($good, $num, 1);
			$totalprice = $good['price'] * $num;
			$title = $price_str . lang_wr('gm', 0) . $good['title'] . $num . '' . lang_wr('fen', 0);
			$ptlog = array('crts' => TIMESTAMP, 'uid' => $_G['uid'], 'order_id' => '', 'buy_type' => $form['buy_type'], 'pay_money' => $totalprice, 'priceinfo' => abs($good['jfprice'] * $num), 'gnum' => $num, 'addrid' => $addrid, 'addr' => $form['dist1'] . $form['dist2'] . $form['dist3'] . $form['address'], 'mobile' => $form['mobile'], 'realname' => $form['realname'], 'gid' => $gid, 'priceid' => 0, 'goodinfo' => serialize($good), 'note' => $note, 'yunfee' => $yf, 'title' => $title, 'status' => 1, 'pay_endts' => 0, 'tuan_id' => 0, 'tuan_num' => 1);
			$ptlog_id = C::t('#xigua_wr#xigua_wr_order')->insert($ptlog, true);
			$location = $_G['siteurl'] . $SCRITPTNAME . '?id=xigua_wr&ac=order';
			$ptlog['id'] = $ptlog_id;
			if ($totalprice <= 0) {
				callback_wr_pay(array('info' => array('data' => $ptlog)));
				hb_message(lang_wr('xdcg', 0), 'success', $location);
			} else {
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_wr', array('data' => $ptlog, 'callback' => array('file' => 'source/plugin/xigua_wr/function.php', 'method' => 'callback_wr_pay', 'uid' => $_G['uid']), 'location' => $location, 'referer' => $SCRITPTNAME . '?id=xigua_wr&ac=good&gid=' . $gid . $urlext, 'tip' => ''), 0);
				C::t('#xigua_wr#xigua_wr_order')->update($ptlog_id, array('order_id' => $order_id));
				$rl = urlencode($location);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
				hb_message(lang_wr('jumppay', 0), 'loading', $jumpurl);
			}
		}
		break;
	case 'shisuan':
		$num = intval($_GET['num']);
		$v = C::t('#xigua_wr#xigua_wr_good')->fetch($gid);
		$ret = C::t('#xigua_wr#xigua_wr_good')->get_price_str($v, $num);
		include template('xigua_hb:header_ajax');
		echo $ret;
		include template('xigua_hb:footer_ajax');
		break;
	case 'confirm':
		$navtitle = lang_wr('qrdd', 0);
		$v = C::t('#xigua_wr#xigua_wr_good')->fetch($gid);
		$v = C::t('#xigua_wr#xigua_wr_good')->prepare($v);
		if (!$v || $v['stat'] != 1) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_wr&ac=goods');
		}
		$yf = 0;
		$dft = C::t('#xigua_hb#xigua_hb_user_addr')->fetch_dft($_G['uid']);
		break;
	case 'good':
		$v = C::t('#xigua_wr#xigua_wr_good')->fetch($gid);
		$v = C::t('#xigua_wr#xigua_wr_good')->prepare($v);
		if (!$v || $v['stat'] != 1) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_wr&ac=goods');
		}
		$navtitle = $v['title'] . $v['subtitle'];
		break;
	case 'goods':
		$navtitle = lang_wr('splb', 0);
		if ($wr_ext_setting['goods_title']) {
			$navtitle = $wr_ext_setting['goods_title'];
		}
		if ($wr_ext_setting['goods_desc']) {
			$desc = $description = $wr_ext_setting['goods_desc'];
		}
		break;
	case 'good_li':
		$field = '*';
		$where = array();
		$stat = 1;
		$where[] = 'stat=' . intval($stat);
		if ($keyword = stripsearchkey($_GET['keyword'])) {
			$where[] = ' (title LIKE \'%' . $keyword . '%\') ';
		}
		if ($hy = stripsearchkey($_GET['hy'])) {
			$where[] = ' (hy LIKE \'%' . $hy . '%\') ';
		}
		$order_by = 'id desc';
		$list = C::t('#xigua_wr#xigua_wr_good')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);
		include template('xigua_hb:header_ajax');
		include template('xigua_wr:good_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'credit_list':
		$navtitle = lang_wr('jfmx', 0);
		break;
	case 'credit_li':
		$list = DB::fetch_all('select * from %t as f,%t as l where l.uid=%d AND f.logid=l.logid AND operation=\'WR\' ORDER BY l.logid DESC ' . DB::limit($start_limit, $lpp), array('common_credit_log_field', 'common_credit_log', $_G['uid']));
		foreach ($list as $index => $item) {
			$list[$index]['time_u'] = dgmdate($item['dateline'], 'u');
			$list[$index]['time_ts'] = date('Y-m-d H:i:s', $item['dateline']);
			$list[$index]['fuhao'] = $item['extcredits' . $wr_config['ctypee']] > 0 ? '+' : '';
			$list[$index]['extcredits'] = $item['extcredits' . $wr_config['ctypee']];
		}
		include template('xigua_hb:header_ajax');
		include template('xigua_wr:credit_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'index':
		$navtitle = $wr_config['pdmc'];
		$myccount = getuserprofile('extcredits' . $wr_config['ctypee']);
		$firstday = date('Y-m-01', TIMESTAMP);
		$lastday = date('Y-m-d', strtotime($firstday . ' +1 month -1 day'));
		$firstday = date('Y-m-d', strtotime($firstday . ' -1 month -1 day'));
		$today = date('Y-m-d', TIMESTAMP);
		$todaynow = TIMESTAMP * 1000;
		$parse_line = C::t('#xigua_wr#xigua_wr_sign')->parse_line($wr_config['sign_line']);
		$total_line = C::t('#xigua_wr#xigua_wr_sign')->parse_line($wr_config['sign_total']);
		$rowlianxu = C::t('#xigua_wr#xigua_wr_sign')->get_lasted($_G['uid']);
		$has = C::t('#xigua_wr#xigua_wr_sign')->check_sign($_G['uid'], $today);
		$sign_desc = array();
		foreach ($parse_line as $index => $item) {
			$sign_desc[] = lang_wr('lxqd', 0) . (' ' . $index . ' ') . lang_wr('tian', 0) . lang_wr('ewjl', 0) . (' ' . $item . ' ' . $cunit . $ctitle);
		}
		foreach ($total_line as $index => $item) {
			$sign_desc[] = lang_wr('zjqdm', 0) . (' ' . $index . ' ') . lang_wr('tian', 0) . lang_wr('ewjl', 0) . (' ' . $item . ' ' . $cunit . $ctitle);
		}
		$sign_desc = implode(lang_wr('douhao', 0), $sign_desc) . lang_wr('tanhao', 0);
		$sign_desc .= ' ' . lang_wr('bqhxh', 0) . ' ' . $wr_config['bqjf'] . $ctitle . ' ' . lang_wr('tanhao', 0);
		$mynums = DB::fetch_all('SELECT count(*) as cnt,act FROM %t WHERE uid=%d AND crdate=%s GROUP BY act', array('xigua_wr_viewlog', $_G['uid'], date('Y-m-d', TIMESTAMP)), 'act');
		if ($wr_ext_setting['share_desc']) {
			$desc = $description = $wr_ext_setting['share_desc'];
		}
		break;
	case 'do_sign':
		if (submitcheck('date')) {
			$date = $_GET['date'];
			if ($ts = strtotime($date . ' 01:00')) {
				$r = C::t('#xigua_wr#xigua_wr_sign')->sign_now($ts);
			} else {
				hb_message(lang_wr('qdsb', 0), 'error');
			}
		}
		break;
	case 'sign_data':
		$month = $_GET['month'];
		$tmpr = C::t('#xigua_wr#xigua_wr_sign')->get_list_month($_G['uid'], $month);
		$r = array();
		foreach ($tmpr as $index => $item) {
			$index = date('Y-n-j', strtotime($index));
			$r[$index] = $item;
		}
		$r = json_encode($r);
		hb_message($r, 'success');
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
$ac_file = DISCUZ_ROOT . ('source/plugin/xigua_wr/include/c_' . $ac . '.php');
if (is_file($ac_file)) {
	include_once $ac_file;
}
include template('xigua_wr:' . $ac);