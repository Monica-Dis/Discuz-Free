<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2020/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$wr_config = $_G['cache']['plugin']['xigua_wr'];
$ctitle = $_G['setting']['extcredits'][$wr_config['ctypee']]['title'];
$cunit = $_G['setting']['extcredits'][$wr_config['ctypee']]['unit'];
$svicerange = array_filter(explode("\n", trim($wr_config['gooocat'])));
foreach ($svicerange as $index => $item) {
    $svicerange[$index] = trim($item);
}
$czcats = array();
$czcat = array_filter(explode("\n", trim($wr_config['czcat'])));
foreach ($czcat as $index => $item) {
    list($money, $getc) = explode('=', trim($item));
    $money = floatval($money);
    list($getc1, $getc2) = explode(',', trim($getc));
    $tit_ = $money.lang_wr('yuan',0).lang_wr('c',0).$getc1.$ctitle;
    if($getc2>0){
        $tit_ .= '<em class="main_color">'.lang_wr('s',0).$getc2.$ctitle.'</em>';
    }
    $czcats[$money] = array(intval($getc1), intval($getc2), $tit_);
}

function lang_wr($lang, $echo = 1){
    global $ctitle;
    $str = lang('plugin/xigua_wr', $lang);
    $str = str_replace(lang('plugin/xigua_wr','jf'),$ctitle,$str);
    if($echo){
        echo $str;
    }else{
        return $str;
    }
}

$wr_selects = array(
    array('sign', lang_wr('sign_everyday',0)),
    array('view_hb', lang_wr('view',0).lang_wr('hb',0),0, 'plugin.php?id=xigua_hb&ac=cat'),
    array('pub_hb', lang_wr('pub',0).lang_wr('hb',0),0, 'plugin.php?id=xigua_hb&ac=pub'),
    array('view_hs', lang_wr('view',0).lang_wr('hs',0),0, 'plugin.php?id=xigua_hs'),
    array('chongzhi', lang_wr('chongzhi',0),0, 'javascript:docz();'),
    array('join_hs', lang_wr('join',0).lang_wr('hs',0), 0,'plugin.php?id=xigua_hs&ac=enter'),
    array('join_hh', lang_wr('join',0).lang_wr('hh',0), 0,'plugin.php?id=xigua_hh&ac=my'),
    array('view_hm', lang_wr('view',0).lang_wr('hm',0), 0,'plugin.php?id=xigua_hm'),
    array('view_cd', lang_wr('view',0).lang_wr('cd',0), 0,'plugin.php?id=xigua_cd'),
    array('view_ho', lang_wr('view',0).lang_wr('ho',0), 0,'plugin.php?id=xigua_ho'),
    array('view_job', lang_wr('view',0).lang_wr('job',0), 0,'plugin.php?id=xigua_job'),
    array('view_hf', lang_wr('view',0).lang_wr('hf',0), 0,'plugin.php?id=xigua_hf'),
    array('view_dh', lang_wr('view',0).lang_wr('dh',0), 0,'plugin.php?id=xigua_dh'),
    array('view_dp', lang_wr('view',0).lang_wr('dp',0), 0,'plugin.php?id=xigua_dp'),
    array('view_sp', lang_wr('view',0).lang_wr('sp',0), 0,'plugin.php?id=xigua_sp'),
    array('view_he', lang_wr('view',0).lang_wr('he',0), 0,'plugin.php?id=xigua_he'),
    array('view_hp', lang_wr('view',0).lang_wr('hp',0), 0,'plugin.php?id=xigua_hp'),
    array('view_hk', lang_wr('view',0).lang_wr('hk',0), 0,'plugin.php?id=xigua_hk'),
    array('view_hd', lang_wr('view',0).lang_wr('hd',0), 0,'plugin.php?id=xigua_hd'),
    array('view_pt', lang_wr('view',0).lang_wr('pt',0), 0,'plugin.php?id=xigua_pt'),
    array('view_jy', lang_wr('view',0).lang_wr('jy',0), 0,'plugin.php?id=xigua_jy'),
);
$wr_cache_key = 'wr_ext_setting';
if(!$_G['cache'][$wr_cache_key]){
    loadcache($wr_cache_key);
}
$wr_ext_setting = $_G['cache'][$wr_cache_key];

function wr_nl2br($txt){
    if(strpos($txt, '&lt;') !== false  && strpos($txt, '&gt;') !== false) :
        $txt = htmlspecialchars_decode($txt);
        $txt = preg_replace(array("/<script(.*?)<\/script>/is",'/on(mousewheel|mouseover|click|load|onload|submit|focus|blur)="[^"]*"/i'), array('',''), $txt);
    endif;
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}

$status_font = array(
    1 => lang_wr('status_1',0),
    2 => lang_wr('status_2',0),
    3 => lang_wr('status_3',0),
    4 => lang_wr('status_4',0),
);