<?php
/**
 *  Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT .'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hf/function.php';
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    $_GET = dhtmlspecialchars($_GET);
}

$wherearr = array();
$keyword = intval($_GET['keyword']);
if($keyword){
    $wherearr[] = " (uid='$keyword' OR pubid=$keyword) ";
}

$page = max(1, intval($_GET['page']));
$lpp   = 50;
$start_limit = ($page - 1) * $lpp;

if(submitcheck('permsubmit')){
    if($delete = dintval($_GET['delete'], true)) {
        $r = C::t('#xigua_hf#xigua_hf_viewqun')->deletes($delete);
    }
    if($r){
        cpmsg(lang_hb('delete_succeed',0), "action=plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_qunview&page=$page&keyword=$keyword", 'succeed');
    }
}
echo "<style>.zlist{width:390px}.zlist ul.ul1{width:170px;float:left}.zlist ul.ul2{width:220px;float:left}.zlist em{color:#4caf50}
.dig{background:#ffda77;color:#ff6565;padding:0 5px;font-size:12px;border-radius:2px}.mt3{margin-top:3px}.c9{color:#999}.dig.dian{color:#fff;background-color:#67a1f2;}
.jobtit{font-size:13px;color:#369}.jbtn{position: relative;padding: 0 5px;border:1px solid;color: #4caf50;font-size: 12px;padding:0 5px;font-size:12px;border-radius:2px}
.jthumb{width:70px;height:50px}.red{color:#ff6565}.bg_green{background:#4caf50;white-space:nowrap}.c_green{color:#4caf50}.tyu{width:60px;display:block;color:#4caf50}.tyu.jingjia{color:#ff6565}.vdesc{max-width:250px;max-height:150px;overflow-y:auto}.priceText{color:#ff6565}.btn2{padding: 3px 5px;line-height:30px;white-space:nowrap}.btn3{background: #DADADA;color: #999;}.previewimg{width:30px;height:30px;vertical-align:middle}.v_mingxi li{margin-bottom:3px}
</style>";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_qunview&page=$page&keyword=$keyword");
echo '<div><input type="text" id="keyword" name="keyword" placeholder="'.lang_hf('uidqunid',0).'" value="'.$_GET['keyword'].'" class="txt" /> ';
echo ' <input type="submit" class="btn" value="'.cplang('search').'" />';
echo '</div>';
showtableheader(lang_hb('pinglunguanli', 0));
showtablerow('class="header"',array(),array(
    lang('plugin/xigua_hb','del'),
    lang_hb('username', 0),
    lang('plugin/xigua_hf','shangjia'),
    lang('plugin/xigua_hf','jiaqun').lang('plugin/xigua_hf','time'),
));

$res = C::t('#xigua_hf#xigua_hf_viewqun')->fetch_all_bypage($wherearr, $start_limit, $lpp);
$icount = C::t('#xigua_hf#xigua_hf_viewqun')->fetch_count_bypage($wherearr);
foreach ($res as $v) {
    if($v['uid']){
        $uids[$v['uid']] = $v['uid'];
    }
    if($v['pubid']){
        $pubids[$v['pubid']] = $v['pubid'];
    }
}
if($uids){
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
}

if($pubids){
    $quns = DB::fetch_all('SELECT qunid,name FROM %t WHERE qunid IN (%n)', array('xigua_hf_qun', $pubids), 'qunid');
}

foreach ($res as $v) {
    $cid = $v['id'];
    $img = $v['imglist'] ? unserialize($v['imglist']) : array();
    $vimg = array();
    if($img){
        foreach ($img as $index => $item) {
            $vimg[] = "<a href='$item' target='_blank'><img src='$item' style='height:40px;display:inline-block' /></a>";
        }
    }
    showtablerow('', array(), array(
        "<input type='checkbox' class='checkbox' name='delete[]' value='$cid' /> $cid",
        '[ UID: '.$v['uid'].' ] '.$users[$v['uid']]['username'],
        '<a target="_blank" href="'.ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_qun&secid=".$v['pubid'].'">[ ID: '.$v['pubid'].' ] '.$quns[$v['pubid']]['name'].'</a>',
        $v['crts_u']. ($v['idtype']=='qun' ? ' <b>'.lang_hf('fufeijia2',0).'</b>':''),
    ));
}
$multipage = multi($icount, $lpp, $page, ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_qunview&lpp=$lpp&keyword=$keyword", 0, 10);
showsubmit('permsubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism��taobao��com*/
showformfooter();