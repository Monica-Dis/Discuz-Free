<?php
/**
 *  Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

function lang_hf($lang, $echo = 1){
    if($echo){
        echo lang('plugin/xigua_hf', $lang);
    }else{
        return lang('plugin/xigua_hf', $lang);
    }
}

function hf_current_location($lat, $lng){
    global $hf_config;
    $url = "http://apis.map.qq.com/ws/geocoder/v1/?location=$lat,$lng&coord_type=5&get_poi=1&key=".$hf_config['skey'];
    $ret = hb_curl($url);
    $ret = json_decode($ret, true);
    if($ret['status'] == 0){
        $rt = array();
        $rt[$ret['result']['address']] = array(
            'address'           => str_replace(array($ret['result']['address_component']['province'], $ret['result']['address_component']['city']), '', $ret['result']['address']),
            'address_component' => array(
                'province' => $ret['result']['address_component']['province'],
                'city'     => $ret['result']['address_component']['city'],
                'district' => $ret['result']['address_component']['district'],
                'street'   => $ret['result']['address_component']['street'],
                'street_number'=>$ret['result']['address_component']['street_number'],
            ),
            'location'          => $ret['result']['location'],
            'category'          => diconv(lang('plugin/xigua_hf', 'default'), CHARSET, 'utf-8'),
        );
        foreach ($ret['result']['pois'] as $index => $pois) {
            $rt[$pois['address']] = array(
                'address'           => str_replace(array($pois['ad_info']['province'], $pois['ad_info']['city']), '', $pois['address']),
                'address_component' => array(
                    'province' => $pois['ad_info']['province'],
                    'city'     => $pois['ad_info']['city'],
                    'district' => $pois['ad_info']['district'],
                    'street'   => '',
                    'street_number'=> '',
                ),
                'location'          => $pois['location'],
                'category'          => $pois['category'],
            );
        }
        $rt = array_values($rt);
        return  hf_multi_diconv($rt, 'utf-8', 'utf-8');
    }else{
        return hf_multi_diconv($ret['message'], 'utf-8', CHARSET);
    }
}
function hf_multi_diconv($string, $in_charset, $out_charset){
    if (is_array($string)) {
        foreach ($string as $key => $val) {
            $string[ $key ] = hf_multi_diconv($val, $in_charset, $out_charset);
        }
    } else {
        $string = diconv($string, $in_charset, $out_charset);
    }
    return $string;
}
function hfmulti_pay_callback($param){
    $info = $param['info'];
    $qunid = $info['data']['qunid'];
    $pubprice = $info['data']['pubprice'];
    $dig_price = $info['data']['dig_price'];
    $digtype = $info['data']['digtype'];
    $update = array();
    $update['payts'] = TIMESTAMP;
    if($pubprice>0){
        $update['status'] = 1;
    }
    if($dig_price>0){
        $update['dig_startts'] = TIMESTAMP;
        $update['dig_endts'] = TIMESTAMP + $digtype*86400;
        $update['digtype'] = $digtype;
    }
    C::t('#xigua_hf#xigua_hf_qun')->update($qunid, $update);
    return true;
}

$statuss = array(
    1 => lang_hf('status1', 0),
    -1 => lang_hf('status-1', 0),
    -2 => lang_hf('status-2', 0),
);
function hf_nl2br($txt){
    return strpos($txt, '<')!==false&& strpos($txt, '>')!==false ? $txt : nl2br($txt);
}

function hf_dig_callback($param){
    $info = $param['info'];
    $data = $info['data'];
    $qunid = $data['qunid'];

    $old_data = C::t('#xigua_hf#xigua_hf_qun')->fetch($qunid);

    $replace = array(
        'dig_endts' => max(TIMESTAMP, $old_data['dig_endts'])+ (86400*$data['dig_days']),
        'dig_startts' => TIMESTAMP,
        'digtype' => $data['dig_days']
    );
    C::t('#xigua_hf#xigua_hf_qun')->update($qunid, $replace);

    return true;
}
function hf_telpay_callback($param){
    global $SCRITPTNAME,$urlext, $_G;
    $info = $param['info'];
    $uid = intval($info['data']['uid']);
    $qunid = $info['data']['qunid'];
    DB::insert('xigua_hf_viewqun' , array(
        'uid' => $uid,
        'crts' => TIMESTAMP,
        'pubid' => $qunid,
        'idtype' => 'qun'
    ));
    C::t('#xigua_hf#xigua_hf_qun')->incr($qunid, 'zans');

    $toprice = $param['baseprice'];
    $sxfee = round((intval($_G['cache']['plugin']['xigua_hf']['shou'])/100) * $toprice, 2);
    $infee = round($toprice-$sxfee, 2);
    if($infee>0){
        $quninfo = C::t('#xigua_hf#xigua_hf_qun')->fetch($qunid);
        $link = "$SCRITPTNAME?id=xigua_hf&ac=view&qunid=$qunid$urlext";
        $link2 = "$SCRITPTNAME?id=xigua_hb&ac=qianbao$urlext";
        $user = getuserbyuid($uid);
        C::t('#xigua_hb#xigua_hb_user')->increase_by_uid($quninfo['uid'], 'money', $infee);
        C::t('#xigua_hb#xigua_hb_moneylog')->insert(array(
            'uid'  => $quninfo['uid'],
            'crts' => TIMESTAMP,
            'size' => $infee,
            'note' => $user['username'].lang_hf('shenqing',0).$quninfo['name'],
            'link' => $link,
        ));
        notification_add($quninfo['uid'],'system', lang('plugin/xigua_hf', 'note_3') ,array(
            'url' => $link2,
            'username' => $user['username'],
            'money'=>$toprice,
            'sxfee'=>$sxfee,
            'infee'=>$infee,
            'name' => $quninfo['name']
        ),1);
    }
    return true;
}
function hf_qrcode($mpid, $url, $avatar = ''){
    global $SCRITPTNAME, $hf_config, $_G,$urlext;

    if($hf_config['typewx'] ==2){
        $upar = parse_url($url);
        $hb_currenturl = urlencode('https://'.$upar['host'].$upar['path']."?id=xigua_hf&ac=view&qunid=$mpid&x=1");

        $_qrfile = './source/plugin/xigua_hf/cache/qun' . $mpid . '.jpg';
        if (!is_file(DISCUZ_ROOT . $_qrfile)){
            @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
            if(class_exists('QRcode')){
                QRcode::png($hb_currenturl, DISCUZ_ROOT . $_qrfile, QR_ECLEVEL_L, 5);
            }
        }
        $shqr = 'source/plugin/xigua_hx/api.php?id=xigua_hx&ac=qrcode&logo='.urlencode($avatar).'&url='.$hb_currenturl;
        return $shqr;
    }else{
        $config = $_G['cache']['plugin']['xigua_hb'];
        if($config['qraut']){
            return "$SCRITPTNAME?id=xigua_hb:qrauto&ode=qun_{$mpid}{$urlext}";
        }
        $repath = './source/plugin/xigua_hf/cache/';
        $qrfile = $repath . $mpid . '.png';
        $abs_qrfile = DISCUZ_ROOT . $qrfile;
        if(!is_file($abs_qrfile)) {
            if (!is_file($abs_qrfile)) {
                @include_once DISCUZ_ROOT.'source/plugin/mobile/qrcode.class.php';
                if(class_exists('QRcode')){
                    QRcode::png($url, $abs_qrfile, QR_ECLEVEL_L, 5);
                }
            }
        }
        return $qrfile;
    }
}
function hf_hex2rgb($colour, $a){
    if ($colour[0] == '#') {
        $colour = substr($colour, 1);
    }
    if (strlen($colour) == 6) {
        list($r, $g, $b) = array($colour[0] . $colour[1], $colour[2] . $colour[3], $colour[4] . $colour[5]);
    }
    elseif (strlen($colour) == 3) {
        list($r, $g, $b) = array($colour[0] . $colour[0], $colour[1] . $colour[1], $colour[2] . $colour[2]);
    }
    else {
        return false;
    }
    $r = hexdec($r);
    $g = hexdec($g);
    $b = hexdec($b);
    return "rgba($r, $g, $b, $a)";
}

function to_noti($extinfo, $new = 1){
    if(IS_ADMINID){
        return false;
    }
    global $adminids,$_G,$SCRITPTNAME;
    if($adminids) {
        $adminids = array_slice($adminids, 0, 2);
        if ($_G['cache']['plugin']['xigua_st'] && $extinfo['stid']) {
            $stinfo = C::t('#xigua_st#xigua_st')->fetch_by_status($extinfo['stid']);
            if ($stinfo['uid']) {
                $adminids[] = $stinfo['uid'];
            }
        }
        $tourl= $_G['siteurl']."$SCRITPTNAME?id=xigua_hf&ac=my&manage=1&mobile=2";
        $act = $new ? lang_hf('pub',0) : lang_hf('edit',0);
        foreach ($adminids as $adminid) {
            notification_add($adminid, 'system', lang('plugin/xigua_hf', 'shenhe_notice'), array(
                'url' => $tourl,
                'ts' => date('Y-m-d H:i:s', TIMESTAMP),
                'username' => $_G['username'],
                'act' => $act,
                'name' => $extinfo['name'],
            ), 1);
        }
    }
    return false;
}

function check_bind_hf(){
    global $_G,$config,$SCRITPTNAME,$hf_config;
    if(!$hf_config['mustbindhf']){
        return false;
    }
    $user = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
    if($user['mobile']){
        return $user['mobile'];
    }
    $url = $SCRITPTNAME.'?id=xigua_hb&ac=myzl&referer='.urlencode(hb_currenturl()).$GLOBALS['urlext'];
    if ($_GET['inajax']) {
        hb_message(lang_hb('plzbind', 0), 'success', $url);
    } else {
        dheader('location: ' . $url);
    }
    return false;
}