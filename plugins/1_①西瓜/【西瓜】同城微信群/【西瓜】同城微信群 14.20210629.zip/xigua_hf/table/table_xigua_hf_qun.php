<?php
/**
 *  Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_hf_qun extends  discuz_table
{
    public function __construct()
    {
        $this->_table = 'xigua_hf_qun';
        $this->_pk = 'qunid';

        parent::__construct();  //dism - taobao -com
    }

    public function insert($data, $return_insert_id = false, $replace = false, $silent = false) {
        return DB::insert($this->_table, $data, $return_insert_id, $replace, $silent);
    }

    public function update($val, $data, $unbuffered = false, $low_priority = false) {
        return parent::update($val, $data, $unbuffered, $low_priority);
    }

    public function fetch_all_by_where($wherearr, $start_limit = 0, $lpp  = 20, $orderby = 'qunid DESC', $fields= '*')
    {
        global $hf_config, $manage, $_G;
        if($_GET['st']<=0 && $_G['cache']['plugin']['xigua_st']['showsub']){
        }elseif($_GET['st']>0 && $hf_config['allowst'] && !defined('IN_ADMINCP')){
            $wherearr[] = "stid=".intval($_GET['st']);
        }

        /*if($_GET['nots']){
            $nots = dintval(array_filter(explode(',', $_GET['nots'])), 1);
            $wherearr[] = ' qunid NOT IN('. implode(',', $nots)  .')';
        }*/

        if($_GET['ac']=='my' || defined('IN_ADMINCP')) {
        }else{
            $wherearr[] = " ( endts<=0 OR endts>".TIMESTAMP .') ';
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        if($orderby){
            $orderby = "ORDER BY $orderby";
        }
        $result = DB::fetch_all("SELECT $fields FROM " . DB::table($this->_table) . " $wheresql  $orderby " . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public static function prepare($v){
        global $hf_config;
        if(!$hf_config['autoguoqi']){
            $hf_config['autoguoqi'] = 7;
        }
        if($v){
            global $statuss;
            $v['shoufei'] = floatval($v['shoufei']);
            $v['status_str'] = $statuss[$v['status']];
            $v['jineng_ary'] = explode(',', $v['jineng']);
            $v['jineng_str_ary'] = explode(',', $v['jineng_str']);
            $v['crts_u'] = $v['crts'] ? date('Y-m-d H:i', $v['crts']) : '';
            $v['upts_u'] = $v['upts'] ? date('Y-m-d H:i', $v['upts']) : '';
            $v['payts_u'] = $v['payts'] ? date('Y-m-d H:i', $v['payts']) : '';
            $v['endts_u'] = $v['endts']>=0 ? date('Y-m-d H:i', $v['endts']) : lang_hf('cqyx',0);
            $v['is_dig'] = $v['dig'] = $v['dig_endts']>TIMESTAMP ? 1:0;
            $v['album'] = $v['album'] ? unserialize($v['album']) : array();
            $v['is_end'] = $v['endts']>0 && $v['endts']<=TIMESTAMP;
            $v['chaoshi'] = intval($v['upts']+$hf_config['autoguoqi']*86400 <TIMESTAMP);
            if($v['chaoshi'] && $v['qunzhuqr']){
                $v['showqr'] = $v['qunzhuqr'];
            }else{
                $v['showqr'] = $v['wxqr'];
            }

            if($v['status']==1 && $_GET['ac']=='view'){
                C::t('#xigua_hf#xigua_hf_qun')->incr($v['qunid'], 'views');
            }
            if($v['dig_endts'] && $v['dig_endts']<TIMESTAMP){
                DB::query("update %t set dig_endts=0,dig_startts=0 WHERE qunid=%d", array('xigua_hf_qun', $v['qunid']));
            }

            if($distance = intval($v['distance'])){
                if($distance<=1000){
                    $distance = intval($distance). 'm';
                }else if($distance>1000){
                    $distance = round($distance/1000, 1). 'km';
                }
                $v['distance'] = $distance;
            }
            if($v['dl_status'] && ($_GET['ac']=='view' || $_GET['ac']=='qun_li')){
                global $hf_config;
                $v['qunzhuqr'] = $hf_config['guanliqr'];
                $v['qunzhuwx'] = $hf_config['guanliwx'];
                if($v['rand_kl']){
                    $v['kouling'] = $v['rand_kl'].self::rand_kouling();
                }
            }
            if(strpos($v['jieshao'], '&lt;')!==false && strpos($v['jieshao'], '&gt;')!==false){
                $v['jieshao'] = html_entity_decode($v['jieshao']);
            }
        }
        return $v;
    }

    public static function rand_kouling()
    {
        $strs="QWERTYUPASDFGHJKLZXCVBNM23456789";
        $name = substr(str_shuffle($strs),mt_rand(0,strlen($strs)-11),4);
        return $name;
    }

    public function fetch_count_by_page($wherearr = array())
    {
        global $hf_config;
        if($_GET['st']>0 && $hf_config['allowst']){
            $wherearr[] = "stid=".intval($_GET['st']);
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function delete_by_where($wherearr = array())
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::query('DELETE FROM ' . DB::table($this->_table).' '.$wheresql);
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query("DELETE FROM %t WHERE {$this->_pk} IN (%n)", array($this->_table, $ids));
    }

    public function fetch_by_uid($uid)
    {
        global $hf_config;
        if($hf_config['allowst']) {
            $_GET['st'] = $_GET['st']>0?$_GET['st']:0;
            $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND stid=%d", array($this->_table, $uid, $_GET['st']));
        }else{
            $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d", array($this->_table, $uid));
        }
        $v = self::prepare($v);
        return $v;
    }

    public function update_endts($qunid, $allts, $order_id)
    {
        $payts = TIMESTAMP;
        $old_data = $this->fetch($qunid, TRUE);
        if($old_data['endts']<TIMESTAMP){
            DB::query("update %t set endts=%d WHERE {$this->_pk}=%d", array($this->_table, TIMESTAMP, $qunid));
        }
        return DB::query("update %t set endts=endts+%d,status=1,order_id=%s,payts=%d WHERE {$this->_pk}=%d", array($this->_table, $allts, $order_id, $payts, $qunid));
    }

    public function fetch_online_card($uid)
    {
        $v = DB::fetch_first("SELECT * FROM %t WHERE uid=%d AND status=1 AND endts>%s", array($this->_table, $uid, TIMESTAMP));
        $v = self::prepare($v);
        return $v;
    }
    public function fetch_online_card_num()
    {
        $v = DB::result_first("SELECT count(*) FROM %t WHERE status=1 AND endts>%s", array($this->_table, TIMESTAMP));
        return $v;
    }
    public function do_delete($id)
    {
        return $this->delete($id);
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = array();
        $result = DB::fetch_all("SELECT * FROM %t  ORDER BY {$this->_pk} DESC " . DB::limit($start_limit, $lpp), array($this->_table));
        if($result){
            foreach ($result as $index => $item) {
                $result[$index] = self::prepare($item);
            }
        }
        return $result;
    }

    public function count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function del_by_uid_qunid($qunid)
    {
        global $_G;
        return DB::delete($this->_table, array(
            'qunid' => $qunid,
            'uid' => $_G['uid'],
        ));
    }

    public function fetch_by_id($qunid){
        $rs = parent::fetch($qunid);
        $this->incr($qunid, 'views');
        return self::prepare($rs);
    }

    public function incr($gid, $field, $num = 1)
    {
        if(!$field){
            return null;
        }
        if(strpos($gid, ',')!==false){
            $gid = dintval(array_filter(explode(',', $gid)), true);
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk} IN (%n)", array($this->_table, $num, $gid));
        }else{
            return DB::query("update %t set $field=$field+%d WHERE {$this->_pk}=%d", array($this->_table, $num, $gid));
        }
    }
    public function update_G($id, $data){
        global $_G;
        unset($data['uid']);
        unset($data['crts']);
        if(IS_ADMINID){
            return DB::update($this->_table, $data, array(
                'qunid'  => $id,
            ));
        }else {
            return DB::update($this->_table, $data, array(
                'uid' => $_G['uid'],
                'qunid' => $id,
            ));
        }
    }

    public function get_order($viewtype)
    {
        global $hf_config;
        $field = '*';
        switch ($viewtype){
            case "new":
                $order_by = '(dig_endts-dig_startts) DESC, tuijian DESC, upts DESC';
                break;
            case "near":
                $lat = floatval($_GET['lat']);
                $lng = floatval($_GET['lng']);
                $lngstr = $lng > 0 ? " - $lng" : " + ".abs($lng);
                $field = "*, acos(cos((lng $lngstr) * 0.01745329252) * cos((lat - $lat) * 0.01745329252)) * 6371004 as distance";
                switch ($hf_config['digorder']){
                    case '3':
                        $order_by = 'distance ASC, dig_startts DESC, dig_endts DESC';
                        break;
                    case '2':
                        $order_by = 'distance ASC, dig_endts DESC';
                        break;
                    default:
                        $order_by = 'distance ASC, (dig_endts-dig_startts) DESC';
                        break;
                }
                break;
            case 'guanzhu':
                $order_by = 'follow DESC';
                break;
            case 'fenxiang':
                $order_by = 'shares DESC';
                break;
            default:
                switch ($hf_config['digorder']){
                    case '3':
                        $order_by = ' dig_startts DESC, dig_endts DESC, views DESC ';
                        break;
                    case '2':
                        $order_by = 'dig_endts DESC, views DESC';
                        break;
                    default:
                        $order_by = ' (dig_endts-dig_startts) DESC, tuijian DESC, views DESC ';
                        break;
                }
                break;
        }
        return array(
            'order_by' => $order_by,
            'field' => $field,
        );
    }
    public function fetch_tuijian($num = 5, $fields = '')
    {
        if(!$fields){
            $fields = "$this->_pk, logo,name, jineng_str";
        }
        $where = array('status=1 AND tuijian=1');
        $ob = "(dig_endts-dig_startts) DESC, displayorder DESC, $this->_pk DESC";
        return $this->fetch_all_by_where($where, 0, $num, $ob, $fields );
    }

    public function fetch_catall_count()
    {
        /*$res = DB::fetch_all('SELECT hangye_id2,count(*) AS num FROM %t WHERE endts>'.TIMESTAMP.' AND display=1 GROUP BY hangye_id2', array(
            $this->_table
        ));
        $ret = array();
        foreach ($res as $index => $re) {
            $ret[$re['hangye_id2']] = $re['num'];
        }
        return $ret;*/
    }
    public function manage($qunid)
    {
        global $SCRITPTNAME,$_G,$urlext;
        $quninfo = parent::fetch($qunid);
        $url = "{$_G['siteurl']}$SCRITPTNAME?id=xigua_hf&ac=view&qunid=$qunid$urlext";

        if($_GET['tongguo']==1){
            $data = array( 'status' => 1, );
            parent::update($qunid, $data);
            notification_add($quninfo['uid'],'system', lang_hf('tongguo_noti1', 0),array('name' => $quninfo['name'],'url' => $url),1);
        }else{
            $data = array('status' => -1);
            parent::update($qunid, $data);
            notification_add($quninfo['uid'],'system', lang_hf('tongguo_noti2', 0),array('name' => $quninfo['name'],'url' => $url),1);
        }
        return true;
    }

    public function tuijian($qunid)
    {
        if($_GET['tj']==1){
            $data = array( 'tuijian' => 1, );
            parent::update($qunid, $data);
        }else{
            $data = array('tuijian' => 0);
            parent::update($qunid, $data);
        }
        return true;
    }

    public function total_views()
    {
        global $_G, $config;
        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if( $_G['cache']['plugin']['xigua_st']){
            if($st>0){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st) ";
                }
            }
        }
        $key = 'qun_view_'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT sum(views) FROM %t WHERE '.$whe, array($this->_table));
            if($return>0) {
                savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
            }
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }
    public function total_count()
    {
        global $_G, $config;
        $whe = ' 1 ';
        $st = intval($_GET['st']);
        if( $_G['cache']['plugin']['xigua_st']){
            if($st>0){
                if(!$_G['cache']['plugin']['xigua_st']['shoucount2']){
                    $whe = " (stid=$st) ";
                }
            }else{
                if(!$_G['cache']['plugin']['xigua_st']['shoucount1']){
                    $whe = " (stid=$st) ";
                }
            }
        }

        $key = 'qun_tn_'.$config['cachettl'].'_'.$st;
        loadcache($key);
        if(!$_G['cache'][$key] || TIMESTAMP - $_G['cache'][$key]['expiration'] > $config['cachettl']) {
            $return = DB::result_first('SELECT count(*) FROM %t WHERE '.$whe, array($this->_table));
            if($return>0){
                savecache($key, array('variable' => $return, 'expiration' => TIMESTAMP));
            }
        } else {
            $return = $_G['cache'][$key]['variable'];
        }
        return $return;
    }
}