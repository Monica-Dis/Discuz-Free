<?php
/**
 *  Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
class table_xigua_hf_viewqun extends discuz_table
{
    public function __construct() {

        $this->_table = 'xigua_hf_viewqun';
        $this->_pk    = 'id';

        parent::__construct();  //dism - taobao -com
    }

    public function fetch_by_uid_ids($uid, $pubids, $idtype = 'qunid')
    {
        $result = DB::fetch_all('SELECT id,pubid FROM %t WHERE uid=%d AND pubid IN (%n) AND idtype=%s' , array(
            $this->_table,
            $uid,
            $pubids,
            $idtype
        ), 'pubid');
        return $result;
    }

    public function fetch_all_by_page($start_limit, $lpp)
    {
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . "  ORDER BY $this->_pk DESC " . DB::limit($start_limit, $lpp));
        return $result;
    }
    public function fetch_count_by_page()
    {
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table));
        return $result;
    }

    public function deletes($ids)
    {
        return DB::query('DELETE FROM %t WHERE id IN (%n)', array($this->_table, $ids));
    }
    public function fetch_all_bypage($wherearr, $start_limit, $lpp, $order = '')
    {
        if(!$order){
            $order = "$this->_pk DESC";
        }
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::fetch_all('SELECT * FROM ' . DB::table($this->_table) . " $wheresql  ORDER BY $order" . DB::limit($start_limit, $lpp));
        foreach ($result as $index => $item) {
            $result[$index] = $this->prepare($item);
        }
        return $result;
    }

    public function fetch_count_bypage($wherearr)
    {
        $wheresql = !empty($wherearr) && is_array($wherearr) ? ' WHERE '.implode(' AND ', $wherearr) : '';
        $result = DB::result_first('SELECT  count(*) as c FROM ' . DB::table($this->_table). " $wheresql ");
        return $result;
    }

    public function prepare($v)
    {
        global $_G;
        if($v){
            $v['crts_u'] = dgmdate($v['crts'], 'u');
        }
        return $v;
    }
}