<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hf:header}-->
<!--{if $indeximg}--><div style="width:0;height:0;display:none"><img src="$indeximg" /></div><!--{/if}-->
<div class="page__bd">
<!--{if IN_PROG && $ac=='index'}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if $ac=='index' && $config[showheader]}--><!--{eval $hide_nav = 0;}--><!--{/if}-->
<!--{if !$hide_nav}-->
    <header class="x_header bgcolor_11 cl  weui-flex f15" <!--{if $config[intopindex]}-->style="background:transparent!important;position:absolute"<!--{/if}-->>
    <!--{if $_G['cache']['plugin']['xigua_hf']['allowst']}-->
    <span onclick="window.location.href='$SCRITPTNAME?id=xigua_st&ac=city&back={echo urlencode("$SCRITPTNAME?id=xigua_hf&mobile=2");}{$urlext}'" class="fzopen">{echo $stinfo['name2']?$stinfo['name2']:$_G['cache']['plugin']['xigua_st']['zongname']} <i class="iconfont icon-xiangxia f13"></i></span>
    <!--{else}-->
    <a class="z x_logo" href="$SCRITPTNAME?id=xigua_hf"><!--{if strpos($hf_config['logo'],'/')!==false}--><img src="$hf_config[logo]" /> <!--{else}--><span style="margin:0 .75rem">$hf_config[logo]</span><!--{/if}--></a><!--{/if}-->
    <form class="z x_form" style="position: relative;" id="search" method="get" action="$SCRITPTNAME">
        <!--{loop $_GET $lk $loopin}-->
        <input type="hidden" name="$lk" value="$_GET[$lk]">
        <!--{/loop}-->
        <input type="hidden" name="id" value="xigua_hf">
        <input type="hidden" name="ac" value="hangye">
        <input type="hidden" name="st" value="$_GET[st]">
        <input type="hidden" name="idu" value="$_GET[idu]">
        <input name="keyword" class="x_logo_input inputdh" type="text" value="{$_GET['keyword']}" placeholder="$hf_config[indexkey]" x-webkit-speech="" <!--{if $config[intopindex]}-->style="background-color: rgba(255,255,255,.92)"<!--{/if}-->>
        <button class="x_logo_search main_color" type="submit">{lang xigua_hb:sousuo}</button>
    </form>
    </header>
    <!--{if !$no_header_fix}--><div class="x_header_fix" <!--{if $config[intopindex]&&$ac=='index'}-->style="display:none"<!--{/if}-->></div>
<!--{/if}-->
<!--{/if}-->
<!--{if $topnavslider}-->
<div class="swipe cl">
    <div class="swipe-wrap">
        <!--{loop $topnavslider $slider}-->
        <div>$slider</div>
        <!--{/loop}-->
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position">
            <!--{loop $topnavslider $k $slider}-->
            <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
            <!--{/loop}-->
        </ul>
    </nav>
</div>
<!--{/if}-->
<!--{if $hf_config['showtj']}-->
<div style="height:30px;" class="bgf">
    <div class="flnav">
        <div class="weui-cell__bd">
            <i class="iconfont icon-hot1 color-red f14"></i> <span class="f14">{lang xigua_hf:views}{lang xigua_hf:m}<em class="main_color">{echo hb_trans($total_views)}</em></span>
            <span class="ml3 f14">{lang xigua_hf:yiyouqun}{lang xigua_hf:m}<em class="main_color">{$total_count}{lang xigua_hf:g}</em></span>
        </div>
    </div>
</div>
<!--{/if}-->
<!--{if $jing_list}-->
<nav class="nav-list cl swipe <!--{if !$hf_config['showtj']}-->pt10<!--{/if}-->">
    <div class="swipe-wrap">
        <div>
            <ul class="cl">
                <!--{loop $jing_list $k $n}-->
                <!--{if $k && $k%$numi1==0}-->
            </ul>
        </div>
        <div>
            <ul class="cl">
                <!--{/if}-->
                <li<!--{if $hf_config['numi1']!=5&&$hf_config['numi1']>0}--> {eval echo "style='width:".(100/$hf_config['numi1'])."%'";}<!--{/if}-->>
                    <a href="{echo $n['adlink'] ? $n['adlink'] : "$SCRITPTNAME?id=xigua_hf&ac=hangye&cat_id=".$n[id].$urlext}">
                        <span>
                            <img src="$n['icon']"/>
                        </span>
                        <em class="m-piclist-title c3">{$n['name']}</em>
                    </a>
                </li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
    <nav class="cl bullets bullets1">
        <ul class="position position1">
            <!--{loop $jing_count $k $v}-->
            <li {if $k==0} class="current" {/if}></li>
            <!--{/loop}-->
        </ul>
    </nav>
</nav>
<!--{/if}-->

<!--{if $toutiaoitems}-->
<div class="weui-cells after_none before_none">
    <div class="chip-row hf_chip">
        <div class="toutiao">{$_G['cache']['plugin']['xigua_hf']['toutit']}</div>
        <div class="toutiao-slider swiper-container" id="newsSlider">
            <ul class="swiper-wrapper">
                <!--{loop $toutiaoitems $toutiaoitem}-->
                <!--{eval list($font, $link)= explode(",", trim($toutiaoitem));}-->
                <li class="swiper-slide"><a href="$link">$font</a></li>
                <!--{/loop}-->
            </ul>
        </div>
    </div>
</div>
<!--{/if}-->
<!--{if $hf_config[indextext]}--><div class="weui-cells after_none before_none p15 f14">$hf_config[indextext]</div><!--{/if}-->
<!--{if $hf_list}-->
<div class="weui-cells__title weui_title border_none"><span class="f15">{lang xigua_hf:tuijianqun}</span>  <a class="y c9 f15" href="$SCRITPTNAME?id=xigua_hf&ac=hangye&tuijian=1">{lang xigua_hb:more}<i class="f13 iconfont icon-jinrujiantou"></i></a></div>
<div class="weui-cells after_none before_none p15 pt0">
    <div class="hf_slider sh_slider">
        <ul class="shangjia" style="width:{$shwidth}px">
            <!--{loop $hf_list $shi}-->
            <li class="s_shangjia">
                <a href="$SCRITPTNAME?id=xigua_hf&ac=view&qunid={$shi[qunid]}{$urlext}">
                    <div class="picture"><img src="{$shi[logo]}" onerror="this.error=null;this.src='source/plugin/xigua_hf/static/img/new.png'"></div>
                    <span class="sh_name">{$shi[name]}</span>
                </a>
            </li><!--{eval $notids .= $shi[qunid].',';}-->
            <!--{/loop}-->
        </ul>
    </div>
</div>
<!--{/if}-->
<!--{if $midnavslider}-->
<div class="weui-cells after_none before_none">
    <div class="swipe cl" data-speed="6000">
        <div class="swipe-wrap">
            <!--{loop $midnavslider $slider}-->
            <div>$slider</div>
            <!--{/loop}-->
        </div>
        <nav class="cl bullets bullets1">
            <ul class="position">
                <!--{loop $midnavslider $k $slider}-->
                <li <!--{if $k==0}-->class="current"<!--{/if}-->></li>
                <!--{/loop}-->
            </ul>
        </nav>
    </div>
</div>
<!--{/if}-->

<div class="weui-cells fixbanner before_none">
<div class="weui-navbar weui-banner nobg fixbanner_in">
<!--{loop $indexmod $_k $_v}-->
    <!--{if $_k=='hy'}-->
    <a href="javascript:;" class="weui-navbar__item <!--{if $_GET[nav]=='hy'}-->weui_bar__item_on <!--{/if}--> hflistcat" data-save="nav=hy" data-query="viewtype=hy"><span>{lang xigua_hf:fenlei}</span></a>
    <!--{elseif $_k=='ho'}-->
    <a href="javascript:;" class="weui-navbar__item <!--{if $_GET[nav]=='ho'}-->weui_bar__item_on <!--{/if}--> hflistcat" data-save="nav=ho" data-query="viewtype=hot"><span>{lang xigua_hf:hot}</span></a>
    <!--{elseif $_k=='nw'}-->
    <a href="javascript:;" class="weui-navbar__item <!--{if $_GET[nav]=='nw'}-->weui_bar__item_on <!--{/if}--> hflistcat" data-save="nav=nw" data-query="viewtype=new"><span>{lang xigua_hf:newin}</span></a>
    <!--{elseif $_k=='ne'}-->
    <a href="javascript:;" class="weui-navbar__item <!--{if $_GET[nav]=='ne'}-->weui_bar__item_on <!--{/if}--> hflistcat" data-save="nav=ne" data-query="viewtype=near" data-needgeo="1" id="near_cat"><span>{lang xigua_hf:near}</span></a>
    <!--{/if}-->
<!--{/loop}-->
</div>
</div>
<div id="list" class="mod-post x-postlist pt0"></div>
<!--{template xigua_hb:loading}-->
</div>
<script>
<!--{if $_GET[nav]=='nw'}-->
loadingurl = _APPNAME+'?id=xigua_hf&ac=qun_li&viewtype=new&inajax=1&nots=$notids&page=';
<!--{elseif $_GET[nav]=='ne'}-->
loadingurl = _APPNAME+'?id=xigua_hf&ac=qun_li&viewtype=near&inajax=1&nots=$notids&page=';
<!--{elseif $_GET[nav]=='hy'}-->
loadingurl = _APPNAME+'?id=xigua_hf&ac=qun_li&viewtype=hy&inajax=1&nots=$notids&page=';
<!--{else}-->
loadingurl = _APPNAME+'?id=xigua_hf&ac=qun_li&inajax=1&nots=$notids&page=';
<!--{/if}-->
scrollto = 1;
<!--{if $_GET[nav]=='ne'}-->setTimeout(function () {
    $('#near_cat').trigger('click');
    if (typeof wx !== 'undefined') {
        wx.ready(function () {
            $('#near_cat').trigger('click');
        });
    }
}, 200);<!--{/if}-->
</script>
<!--{eval $hf_tabbar=1;}-->
<!--{template xigua_hf:footer}-->
<!--{if $_G['cache']['plugin']['xigua_hf']['allowst'] && $_G['cache']['plugin']['xigua_st']['dingwei'] && !getcookie('setcitygeo')}-->
<script>function hf_auto_location(){hf_getlocation(function (position) {
var citylat = (position.latitude||position.lat);
var citylng = (position.longitude||position.lng);
$.ajax({
type: 'GET',
url: _APPNAME + '?id=xigua_hs&ac=getloc&checkst=1&lat='+citylat+'&lng='+citylng+'&inajax=1',
dataType: 'xml',
success: function (data) {
if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
var s = data.lastChild.firstChild.nodeValue;
var m = s.split('|');
if('success'==m[0]){
var _t = m[1].split(',');
console.log(_t);
if(_t[0]>0 && _t[0]!='{$_GET[st]}'){
$.confirm("{lang xigua_hb:dqdws}"+_t[1]+'{lang xigua_hb:setcitygeo2}', function() {
window.location.href = _APPNAME+"?id=xigua_hf&st="+_t[0];
hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
}, function() {
hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
});
}else{
hb_setcookie('setcitygeo', 1, $_G['cache']['plugin']['xigua_st']['dingagain']);
}
}
}
});
});}
if(typeof wx!='undefined'){wx.ready(function () { hf_auto_location(); });}else{setTimeout(function(){ hf_auto_location(); }, 300);}
</script><!--{/if}-->