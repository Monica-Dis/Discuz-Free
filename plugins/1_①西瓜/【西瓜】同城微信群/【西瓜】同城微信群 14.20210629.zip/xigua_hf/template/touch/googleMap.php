<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hf:tabbar}-->
<script src="https://maps.googleapis.com/maps/api/js?key={$hf_config[google]}&sensor=false"></script>
<script>
    var myCenter=new google.maps.LatLng({$_GET[lat]}, {$_GET[lng]});
    function initialize(){
        var mapProp = {
            center:myCenter,
            zoom:15,
            mapTypeId:google.maps.MapTypeId.ROADMAP
        };

        var map=new google.maps.Map(document.getElementById("googleMap"),mapProp);

        var marker=new google.maps.Marker({
            position:myCenter
        });
        marker.setMap(map);
    }

    google.maps.event.addDomListener(window, 'load', initialize);
</script>
<div id="googleMap" style="width:100vw;height:100vh;"></div>
<!--{eval $tabbar=0;$hf_tabbar=0;}-->
<!--{template xigua_hf:footer}-->