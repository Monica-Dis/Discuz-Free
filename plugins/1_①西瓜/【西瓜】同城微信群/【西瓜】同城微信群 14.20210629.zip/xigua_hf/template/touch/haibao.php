<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{eval
$ccc = $config[maincolor];
if($shot_img = $v[logo]):
    $shot_file = 'source/plugin/xigua_hf/cache/'.md5($shot_img).'.png';
    if(strpos($shot_img, $_G[siteurl])===false):
        if(!is_file(DISCUZ_ROOT.$shot_file)):
            file_put_contents(DISCUZ_ROOT.$shot_file, file_get_contents($shot_img));
        endif;
        $shot_img = $shot_file;
    endif;
endif;
$hb_currenturl = hb_currenturl();
}--><style>.mpc {margin: 15px;box-shadow: 1px 1px 10px rgba(0, 0, 0, .1);border-radius: 10px;overflow: hidden;}.mpc_body .dh_viewheader{margin-bottom:0;}
.mpc_body {position: relative;background:#fff;background-size: cover;width: calc(100vw - 30px);min-height: calc(((100vw) / 1.95) - 15px);text-align: center;}
.qrblock{width:90px;height:90px;display:block;float:right}.qreidl{padding:0 15px 15px;color: #fff;background:$ccc;}.dh_viewheader .shot_img img{width:100%;display:block;max-height:400px}
.shot_info{position: relative;border-radius: 50px;text-align: left;}.shot_info .need_vlist{margin-top:0}.shot_info .shifu_type{right:1px}.qreidl .ttile{font-size:22px}.shot_in{padding-top: 1px;padding-bottom: 1px;border-radius: 10px;overflow: hidden;}.shot_in .hrlist_i:after,.shot_in .hf_tag:after,.shot_in .whbtn_free, .shot_in .hrlist_i i{display:none}.shot_in .hf_tag,.shot_in .hrlist_i{padding-left:0}
</style><script src="source/plugin/xigua_hb/static/js/html2canvas.min.js?{VERHASH}"></script>
<div id="shot" style="position:fixed;bottom:-100000px">
    <div class="shot_in main_bg">
        <div class="mpc">
            <div class="mpc_body">
                <div class="dh_viewheader">
                    <div class="shot_info"></div>
                </div>
            </div>
        </div>
        <div class="weui-flex qreidl">
            <div class="weui-flex__item" style="height:90px!important;">
                <p class="ttile">$hf_config[hbtitle]</p>
                <p class="f16 mt8">$hf_config[hbdesc]</p>
            </div>
        <div>
<!--{eval include_once 'source/plugin/xigua_hf/include/c_haibao.php';}-->
<!--{if $_G['cache']['plugin']['xigua_hx'] && IN_PROG}-->
    <img src="$shqr" class="qrblock">
<!--{else}-->
    <img src="{eval echo hf_qrcode($qunid, $hb_currenturl, $shot_img);}"  class="qrblock" />
<!--{/if}-->
            </div>
        </div>
    </div>
</div>
<script>
$(document).on('click','.hbtn_share', function () {
    $.showLoading();
    var shiftop = $('.shifu_top');
    $('.shot_info').html(shiftop.html().replace(shiftop.find('#appIcon').attr('src'), '$shot_img'));
    html2canvas(document.querySelector(".shot_in")).then(canvas => {
        var dataURL = canvas.toDataURL();
        COMCLAS = 'shot_outer';
        $.hideLoading();
        $.modal({
            title: "{lang xigua_hf:ca}",
            text: "<img style='display:block' src='"+dataURL+"' />",
            buttons: [{ text: "{lang xigua_hb:close}", onClick: function(){} }]
        });
        $('.weui-dialog__title').css('font-size', '14px');
        COMCLAS = '';
    });
    return false;
});
</script>