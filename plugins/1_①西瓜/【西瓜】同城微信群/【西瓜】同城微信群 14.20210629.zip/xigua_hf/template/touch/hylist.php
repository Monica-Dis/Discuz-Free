<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $cat_tree}--><div class="hylist">
<!--{loop $cat_tree $cat}-->
<div>
    <div class="weui-grids weui-grids-min">
        <a href="$SCRITPTNAME?id=xigua_hf&ac=hangye&cat_id={$cat[id]}" class="weui-grid w100 " data-id="$cat[id]">
            <div class="hytit weui-flex">
                <img src="{$cat[icon]}" />
                <span class="f16">{$cat[name]}</span>
            </div>
        </a>
    </div>
    <div class="weui-grids weui-grids-min">
        <!--{eval $cat[sub] = array_values($cat[sub]);}-->
        <!--{loop $cat[sub] $k $suncat}-->
        <a href="$SCRITPTNAME?id=xigua_hf&ac=hangye&cat_id={$suncat[id]}" class="weui-grid" style="width:{echo intval(100/$hf_config[hy_num])}%" data-id="$suncat[id]">
            <div class="pr">
                <span class="f16">$suncat[name]</span>
            </div>
        </a>
        <!--{if $k && ($k+1)%$hf_config[hy_num]==0}-->
    </div>
    <div class="weui-grids weui-grids-min"><!--{/if}-->
        <!--{/loop}--></div>
</div>
    <!--{/loop}-->
</div><!--{/if}-->