<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hf:header}-->
<div class="page__bd">
<div class="shifu_top">
    <div class="header1">
        <div class="h-content cl">
            <div class="app-icon">
                <img id="appIcon" src="{$v[logo]}" onerror="this.error=null;this.src='source/plugin/xigua_hf/static/img/new.png'" >
            </div>
            <div class="app-info">
                <h1 class="app-title"><!--{if $v[dig]}--><em class="is-star dig_tag">{lang xigua_hf:dig}</em> <!--{/if}--><!--{if $v[shid]}--><em class="is-blue dig_tag">{lang xigua_hf:dian}</em> <!--{/if}--><!--{if $v[tuijian]}--><em class="is-red dig_tag">{lang xigua_hf:jian}</em> <!--{/if}--><!--{if $v[video]}--><em class="is-green dig_tag"><i class="iconfont icon-shipin f12"></i></em> <!--{/if}--><!--{if $v[shoufei]}--><em class="is-orange dig_tag"><i class="iconfont icon-qiandai f12"></i></em> <!--{/if}-->$v[name]</h1>
                <p class="app-explain cl">
                    <span class="sv f12 z">{lang xigua_hf:views}{lang xigua_hf:m}{$v[views]}</span>
                    <span class="sv f12 y">{$v[upts_u]}{lang xigua_hf:gengxin}</span>
                </p>
                <div class="sp_desc sp_tag">
                    <!--{loop $v[jineng_str_ary] $hy1}-->
                    <span class="hf_tag main_color">{$hy1}</span>
                    <!--{/loop}-->
                    <!--{if $v[fanwei]}--><span class="hrlist_i hf_tag main_color"><i class="iconfont icon-coordinates_fill main_bg"></i> {lang xigua_hf:jiaxian}{$v[fanwei]}{lang xigua_hf:kmn}</span><!--{/if}-->
                </div>
            </div>
        </div>
    </div>
    <div class="weui-cells hf_vlist">
        <!--{if $v[name]}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd">
                <label>{lang xigua_hf:name}</label>
            </div>
            <div class="weui-cell__bd">
                <p>{$v[name]}</p>
            </div>
        </div>
        <!--{/if}-->
        <!--{if $allcats}-->
        <div class="weui-cell weui-cell_access">
            <div class="weui-cell__hd">
                <label>{lang xigua_hf:fenlei}</label>
            </div>
            <div class="weui-cell__bd">
                <!--{loop $allcats $hy1}-->
                <span class="ib mr8"><a href="$SCRITPTNAME?id=xigua_hf&ac=hangye&cat_id={$hy1[0][id]}" class="main_color none">{$hy1[0][name]}</a> <a href="$SCRITPTNAME?id=xigua_hf&ac=hangye&cat_id={$hy1[1][id]}" class="main_color">{$hy1[1][name]}</a></span>
                <!--{/loop}-->
            </div>
        </div>
        <!--{/if}-->
        <!--{if $v[lat] && $v[addr]}-->
        <a href="javascript:;" class="weui-cell weui-cell_access" id="v_openlocation_ho" data-lat="$v[lat]" data-lng="$v[lng]" data-name="$v[name]" data-addr="$v[addr]">
            <div class="weui-cell__hd">
                <label>{lang xigua_hf:qunweizhi}</label>
            </div>
            <div class="weui-cell__bd">
                <div class="pr35">{$v[city]}{$v[addr]}</div>
                <img class="mapicon" src="https://apis.map.qq.com/ws/staticmap/v2/?center={$v[lat]},{$v[lng]}&zoom=15&size=79*79&maptype=roadmap&markers=size:small|color:0xFFCCFF|{$v[lat]},{$v[lng]}
&key={$_G['cache']['plugin']['xigua_hf'][mkey]}" onerror="this.error=null;this.style.display='none';" />
            </div>
            <div class="weui-cell__ft"></div>
        </a>
        <!--{/if}-->
    <!--{if $show && !$pingbi}-->
        <!--{if $v[qunzhuwx]}-->
        <div class="weui-cell">
            <div class="weui-cell__hd">
                <label>{lang xigua_hf:qunzhuwx2}</label>
            </div>
            <div class="weui-cell__bd">
                <p>{$v[qunzhuwx]}</p>
            </div>
            <div class="weui-cell__ft">
                <a href="javascript:;" class="weui-btn weui-btn_mini whbtn_free clickcopy" data-clipboard-text="{echo $v[qunzhuwx] ? $v[qunzhuwx] : $hf_config[guanliwx]}">{lang xigua_hf:djfz}</a>
            </div>
        </div>
        <!--{/if}-->
        <!--{if $v[kouling]}-->
        <div class="weui-cell">
            <div class="weui-cell__hd">
                <label>{lang xigua_hf:jiakouling}</label>
            </div>
            <div class="weui-cell__bd">
                <p>{$v[kouling]}</p>
            </div>
            <div class="weui-cell__ft">
                <a href="javascript:;" class="weui-btn weui-btn_mini whbtn_free clickcopy2" data-clipboard-text="{$v[kouling]}">{lang xigua_hf:fzkl}</a>
            </div>
        </div>
        <!--{/if}-->
        <!--{if $v[xuzhi]}-->
        <div class="weui-cell">
            <div class="weui-cell__hd">
                <label>{lang xigua_hf:xuzhi}</label>
            </div>
            <div class="weui-cell__bd">
                <p>{$v[xuzhi]}</p>
            </div>
        </div>
        <!--{/if}-->
    <!--{/if}-->
    </div>
</div>
    <div class="jv_desc weui-cells before_none after_none">
        <h2 class="h2top">{lang xigua_hf:jieshao}</h2>
        <div>{echo nl2br($v[jieshao])}</div>
    </div>
    <!--{if $v[sh]}-->
    <div class="jv_desc weui-cells before_none after_none">
        <h2 class="h2top">{lang xigua_hf:qunsj}</h2>
        <div class="weui-cells seckill_dianjia after_none before_none">
            <div class="weui-cell pt0">
                <div class="weui-cell__hd shlogo"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]"><img src="{$sh[logo]}"></a></div>
                <div class="weui-cell__bd">
                    <p class="f15" style="display:block;padding-right:20px"><a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid=$v[shid]">{$sh[name]}</a></p>
                    <p class="f13 c9 js_de">{$sh[jieshao]}</p>
                </div>
                <div class="weui-cell__ft ml8"><a class="shtel" <!--{if $sh[teljs]}-->$sh[teljs]<!--{else}-->href="tel:{$sh[tel]}"<!--{/if}-->><i class="iconfont icon-unie607 main_color f30"></i></a></div>
            </div>
        </div>
    </div>
    <!--{/if}-->
    <!--{if $v[video]}-->
    <div class="jv_desc weui-cells before_none after_none">
        <h2 class="h2top">{lang xigua_hf:video}</h2>
        <div>
            <video poster="{$v['video_cover']}" style="width:100%;<!--{if $hf_config[heifht]}-->height:{$hf_config[heifht]}px<!--{/if}-->" src="{$v['video']}" controls="controls" <!--{if !IN_PROG&&!$hf_config[fullv]}-->x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"<!--{/if}-->></video>
        </div>
    </div>
    <!--{/if}-->
    <!--{if $v[album]}-->
    <div class="jv_desc weui-cells before_none after_none">
        <h2 class="h2top">{lang xigua_hf:album}</h2>
        <div class="cl feed-preview-pic"><!--{loop $v[album] $img}--><span class="imgloading"><img src="$img"></span><!--{/loop}--></div>
    </div>
    <!--{/if}-->
    <div class="weui-cells wxts">
        <a class="weui-cell" href="$SCRITPTNAME?id=xigua_hj">
            <div class="weui-cell__bd c6">
                <span class="c3">{lang xigua_hf:wxts}</span>
                <span class="color-red2 ib ml8">{lang xigua_hf:wxts2}</span>
            </div>
            <div class="weui-cell__ft tc">
                <i class="main_color iconfont icon-jubao2"></i>
                <p class="main_color" style="line-height:1">{lang xigua_hj:wyjb}</p>
            </div>
        </a>
    </div>
    <!--{template xigua_hf:tuijian}-->
    <!--{if $isme}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right">
            <a href="$SCRITPTNAME?id=xigua_hf&ac=my" class="jv_viewbtn border_right">{lang xigua_hb:wode}</a>
        </div>
        <!--{if $hf_config[showback] && !IN_PROG}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:window.history.go(-1);" class="jv_viewbtn border_right">{lang xigua_hf:back}</a>
        </div>
        <!--{/if}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right hbtn_share">{lang xigua_hf:fx}</a>
        </div>
        <div class="weui-flex__item in_bottom_y">
            <a href="$SCRITPTNAME?id=xigua_hf&ac=add&old_id=$qunid&mobile=2" class="jv_viewbtn">{lang xigua_hb:edit}</a>
        </div>
    </div>
    <!--{else}-->
    <div class="in_bottom weui-flex border_top">
        <div class="in_bottom_z border_right">
            <a href="$SCRITPTNAME?id=xigua_hf&ac=index" class="jv_viewbtn border_right">{lang xigua_hb:shouye}</a>
        </div>
        <!--{if $hf_config[showback] && !IN_PROG}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:window.history.go(-1);" class="jv_viewbtn border_right">{lang xigua_hf:back}</a>
        </div>
        <!--{/if}-->
        <div class="in_bottom_z border_right">
            <a href="javascript:;" class="jv_viewbtn border_right hbtn_share">{lang xigua_hf:fx}</a>
        </div>
        <div class="weui-flex__item in_bottom_y">
            <!--{if $v[yqm] && !getcookie('yqm_'.$v[qunid])}-->
            <a href="javascript:;" class="jv_viewbtn syyqm" data-id="$v[qunid]">{lang xigua_hf:yqm3}</a>
            <!--{else}-->
            <!--{if $show}-->
            <a href="javascript:;" class="jv_viewbtn jonnow" data-pb="$pingbi" data-kouling="{$v[kouling]}" data-needlat="{$v[fanwei]}" data-id="{$v['qunid']}" data-clipboard="{echo $v[qunzhuwx] ? $v[qunzhuwx] : $hf_config[guanliwx]}" data-qunzhuqr="<!--{if $hf_config[popqunzhu]}-->{$v[qunzhuqr]}<!--{/if}-->" data-guoqi="{$v[chaoshi]}" data-wxqr="{$v[showqr]}" data-name="{$v[name]}"><!--{if $v[btntext]}-->$v[btntext]<!--{else}-->{lang xigua_hf:shenqing}<!--{/if}--></a>
            <!--{else}-->
            <a href="javascript:;" class="jv_viewbtn hf_paytel" data-needlat="{$v[fanwei]}" data-id="$v[qunid]" data-pri="$v[shoufei]">{lang xigua_hf:pay} {$shoufei}{lang xigua_hb:yuan} {lang xigua_hf:jiaqun}</a>
            <!--{/if}-->
            <!--{/if}-->
        </div>
    </div>
    <!--{/if}-->
</div>
<!--{eval $tabbar=0;}-->
<!--{template xigua_hf:haibao}-->
<!--{template xigua_hf:footer}-->
<!--{if $_GET['show']}--><script>$('.jonnow').trigger('click');</script><!--{/if}-->
<script>
$(document).on('click','.syyqm', function () {
    var that = $(this);
    $.prompt("{lang xigua_hf:yqm4}", function(text) {
        $.showLoading();
        $.ajax({
            type: 'post',
            url: '$SCRITPTNAME?id=xigua_hf&ac=checkyqm&inajax=1&qunid='+that.data('id'),
            data:{formhash:'{FORMHASH}',  yqmpwd:text},
            dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            },
            error: function () {
                $.hideLoading();
            }
        });
    }, function() {
        $.hideLoading();
    });
});
</script>