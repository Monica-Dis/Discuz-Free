<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div id="mapouter" style="z-index:999" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div id="mapcontainer"></div>
        <div class="fix-bottom">
            <div class="weui-flex">
                <a class="mt0 half weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:close}</a>
                <a class="mt0 ml15 half weui-btn weui-btn_primary confirm-popup" href="javascript:;">{lang xigua_hb:queding}</a>
            </div>
        </div>
    </div>
</div>
<script charset="utf-8" src="https://map.qq.com/api/js?v=2.exp&key={$_G['cache']['plugin']['xigua_hf']['mkey']}"></script>
<!--{if $_G['cache']['plugin']['xigua_hf']['baidusdk']}--><script type="text/javascript" src="//api.map.baidu.com/api?v=2.0&ak={$_G['cache']['plugin']['xigua_hf']['baidusdk']}"></script><!--{/if}-->
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script>
var chooseMapRes = [], OBJ = {};
function setForm(lat, lng, deft){
    $.showLoading();
    $.ajax({
        type: 'GET',
        url: location + '&id=xigua_hf&ac=getloc&lat='+lat+'&lng='+lng+'&inajax=1',
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            if(s.indexOf('error')!=-1){
                tip_common(s);
            }else{
                var _actions = [];
                OBJ = jQuery.parseJSON(s.split('|')[1]);
                if(deft){
                    setFormField(OBJ[0]);
                    return true;
                }
                for(var j in OBJ){
                    _actions.push({
                        text: OBJ[j].address,
                        className:'obj_ obj_'+j,
                        onClick: function() {  $.closePopup(); }
                    });
                }
                $.actions({ actions:_actions });
            }
        },
        error: function () {
            $.hideLoading();
        }
    });
}
function setFormField(subj){
    $("input[name='form[addr]']").val(subj.address);
    $("input[name='form[lat]']").val(subj.location.lat);
    $("input[name='form[lng]']").val(subj.location.lng);
    $("input[name='form[province]']").val(subj.address_component.province);
    $("input[name='form[city]']").val(subj.address_component.city);
    $("input[name='form[district]']").val(subj.address_component.district);
    $("input[name='form[street]']").val(subj.address_component.street);
    $("input[name='form[street_number]']").val(subj.address_component.street_number);
}

function setPoint(position){
    if(typeof position.type != 'undefined'){
        if(position.type == 'ip'){
            if(IGNORETIP){}else {
                chooseMap(position);
            }
            return false;
        }
    }
    setForm((position.latitude||position.lat), (position.longitude||position.lng), 1);
}
function chooseMap(position) {
    if(typeof mag != 'undefined') {
        mag.mapPick(function (res) {
            setForm(res.lat, res.lng, 0);
        });
        return false;
    }
    <!--{if $_G['cache']['plugin'][xigua_hf][google]}-->
    var myCenter=new google.maps.LatLng((position.latitude||position.lat), (position.longitude||position.lng));
    var Gmap=new google.maps.Map(document.getElementById("mapcontainer"),{
        center:myCenter,
        zoom:15,
        mapTypeId:google.maps.MapTypeId.ROADMAP
    });
    var Gmarker=new google.maps.Marker({
        position:myCenter
    });
    Gmarker.setMap(Gmap);
    $("#mapouter").popup();

    google.maps.event.addListener(Gmap, 'click', function(event) {
        var center = event.latLng;
        var centerlat = center.lat();
        var centerlng = center.lng();

        Gmarker.setMap(null);
        Gmarker=new google.maps.Marker({
            position:new google.maps.LatLng(centerlat, centerlng)
        });
        Gmarker.setMap(Gmap);
        setForm(centerlat, centerlng, 0);
        $.closePopup();
    });
    <!--{elseif $_G['cache']['plugin']['xigua_hf']['baidusdk']}-->
    var map = new BMap.Map("mapcontainer");
    var geoc = new BMap.Geocoder();
    var point = new BMap.Point((position.longitude||position.lng), (position.latitude||position.lat));
    map.centerAndZoom(point, 15);
    var marker = new BMap.Marker(point);
    map.addOverlay(marker);

    map.addControl(new BMap.MapTypeControl());
    map.addControl(new BMap.NavigationControl());

    map.addEventListener("click", function (e){
        var marker = new BMap.Marker(new BMap.Point(e.point.lng, e.point.lat));
        map.addOverlay(marker);
        var pt = e.point;
        geoc.getLocation(pt, function(rs){
            var addComp = rs.addressComponents;
            $("input[name='form[addr]']").val(addComp.province+addComp.city+addComp.district+addComp.street+addComp.streetNumber);
            $("input[name='form[lat]']").val(e.point.lat);
            $("input[name='form[lng]']").val(e.point.lng);
            $("input[name='form[province]']").val(addComp.province);
            $("input[name='form[city]']").val(addComp.city);
            $("input[name='form[district]']").val(addComp.district);
            $("input[name='form[street]']").val(addComp.street);
            $("input[name='form[street_number]']").val(addComp.streetNumber);
            $.closePopup();
        });
    });
    $("#mapouter").popup();
    <!--{else}-->
    var center = new qq.maps.LatLng((position.latitude||position.lat), (position.longitude||position.lng));
    var mapinit = function () {
        geocoder = new qq.maps.Geocoder({
            complete: function (result) {
                chooseMapRes = result;
            }
        });
        geocoder.getAddress(center);
        map = new qq.maps.Map(document.getElementById("mapcontainer"), {center: center, zoom: 13});
        marker = new qq.maps.Marker({
            position: center, map: map
        });
        qq.maps.event.addListener(map, 'click', function (event) {
            var tmpcenter = new qq.maps.LatLng(event.latLng.getLat(), event.latLng.getLng());
            marker.setPosition(tmpcenter);
            geocoder.getAddress(tmpcenter);
        });
        $("#mapouter").popup();
    };
    mapinit();
    <!--{/if}-->
}
$(document).on('click', '.obj_', function(){
    var k = parseInt($(this)[0].classList[2].replace('obj_', ''));
    setFormField(OBJ[k]);
    $("#new_popup").popup();
});

$('.openlocation').on('click', function(){
    var pot = [];
    IGNORETIP = 0;
    pot.push({ text: "{lang xigua_hb:locacurrt}", onClick: function() { hf_getlocation(setPoint); } });
    if(!(GOOGLE && HB_INWECHAT)){
        pot.push({text: "{lang xigua_hb:xuandian}", onClick: function() { hf_getlocation(chooseMap); } });
    }
    $.actions({ actions: pot});
});

$('.confirm-popup').on('click', function(){
    setForm(chooseMapRes.detail.location.lat, chooseMapRes.detail.location.lng, 0);
});
</script>
