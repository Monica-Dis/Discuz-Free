<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $manage}-->
<!--{eval $mg = '&manage=1';}-->
<!--{/if}-->
<!--{eval $keyword = $_GET['keyword']}-->
<!--{template xigua_hf:header}-->
<div class="page__bd">
    <!--{template xigua_hb:common_nav}-->
    <div class="weui-navbar before_none after_none">
        <!--{loop $statuss $_k $_v}-->
        <a href="$SCRITPTNAME?id=xigua_hf&ac=my&status={$_k}$mg" class="weui-navbar__item <!--{if $_GET[status]==$_k}-->weui_bar__item_on<!--{/if}-->">
            <span>$_v</span>
        </a>
        <!--{/loop}-->
        <!--{if !$manage}-->
        <a href="$SCRITPTNAME?id=xigua_hf&ac=my&status=4$mg" class="weui-navbar__item <!--{if $_GET[status]==4}-->weui_bar__item_on<!--{/if}-->">
            <span>{lang xigua_hf:yijiaru}</span>
        </a>
        <!--{/if}-->
    </div>
    <div class="weui-search-bar before_none after_none <!--{if $keyword}-->weui-search-bar_focusing<!--{/if}-->" id="searchBar">
        <form class="weui-search-bar__form" method="get" action="$SCRITPTNAME" id="dosearchform">
            <input name="id" value="xigua_hf" type="hidden">
            <input name="ac" value="my" type="hidden">
            <input type="hidden" name="st" value="$_GET[st]">
            <input type="hidden" name="idu" value="$_GET[idu]">
            <input type="hidden" name="manage" value="$manage">
            <input type="hidden" name="status" value="$_GET[status]">
            <div class="weui-search-bar__box">
                <input type="search" class="weui-search-bar__input" id="searchInput" placeholder="{lang xigua_hf:spmcddh}" required="required" name="keyword" value="$keyword">
                <a href="javascript:" class="weui-icon-clear" id="searchClear"></a>
            </div>
            <label class="weui-search-bar__label" id="searchText" style="transform-origin:0 0 0; opacity: 1; transform: scale(1, 1);">
                <i class="weui-icon-search"></i>
                <span>{lang xigua_hf:spmcddh}</span>
            </label>
        </form>
        <a href="javascript:;" class="search_bar_btn main_color" id="dosearch">{lang xigua_hf:search}</a>
        <a href="$SCRITPTNAME?id=xigua_hf&ac=my&status={$_GET[status]}{$mg}" class="weui-search-bar__cancel-btn" style="color:#999!important;">{lang xigua_hf:qx}</a>
    </div>
    <div id="list" class="mod-post x-postlist p0"></div>
    <!--{template xigua_hb:loading}-->
</div>

<script>var loadingurl = window.location.href+'&ac=qun_li&status={$_GET[status]}&is_my=1&inajax=1&manage=$manage&keyword=$keyword&page=';</script>
<!--{eval $tabbar=0;$hf_tabbar=1;}-->
<!--{template xigua_hf:footer}-->
<script>
function managesh(obj) {
var act = [], that = $(obj);
var id= that.data('id'), ttl= that.data('title'), _status= that.data('status');
var digprices = [<!--{loop $digtys $___k $___v}--><!--{if $___k==0}-->{eval continue;}<!--{/if}-->
    {text: "{lang xigua_hf:zdjl}{$___k}{lang xigua_hb:day}", onClick: function () {
            var _axjurl = '$SCRITPTNAME?id=xigua_hf&ac=dodig{$mg}&type={$___k}&qunid=' + id;
            $.showLoading();
            $.ajax({
                type: 'post', url: _axjurl,
                data: {'formhash' :FORMHASH},
                dataType: 'xml', success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    var msgar = tip_common(s);
                },
                error: function () {
                    $.hideLoading();
                }
            });
        }},<!--{/loop}-->];
if(_status==1){
    act.push({
    text: '{lang xigua_hf:zhidingdianpu}', onClick: function () {
        $.actions({
            title: '{lang xigua_hf:zhidingdianpu} : '+ ttl,
            actions: digprices
        });
    }
    });
act.push({
    text: '{lang xigua_hb:shuaxin}', onClick: function () {
        $.showLoading();
        $.ajax({
            type: 'post', url: '$SCRITPTNAME?id=xigua_hf&ac=refresh&qunid=' + id + '&inajax=1',
            data: {formhash: FORMHASH}, dataType: 'xml',
            success: function (data) {
                $.hideLoading();
                if (null == data) {
                    tip_common('error|' + ERROR_TIP);
                    return false;
                }
                var s = data.lastChild.firstChild.nodeValue;
                tip_common(s);
            }, error: function () {
                $.hideLoading();
            }
        });
    }
});
}else if(_status==-2){
    act.push( {
        text: '{lang xigua_hb:pay1}', onClick: function () {
            $.ajax({
                type: 'post',
                url: '$SCRITPTNAME?id=xigua_hf&ac=add&pay=1&old_id='+id+_URLEXT,
                data:{formhash:FORMHASH},
                dataType: 'xml',
                success: function (data) {
                    $.hideLoading();
                    if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
                    var s = data.lastChild.firstChild.nodeValue;
                    tip_common(s);
                },
                error: function () { $.hideLoading(); }
            });
        }
    });
}
<!--{if $manage}-->
act.push({
    text: '{lang xigua_hb:shenhe}', onClick: function () {
        $.modal({
            title: "{lang xigua_hb:shenhe}",
            text: "{lang xigua_hb:qingxuanzeshenhe}",
            buttons: [
                { text: "{lang xigua_hb:quxiao}", className: "default"},
                { text: "{lang xigua_hb:jujue}", onClick: function(){hf_dotong(id, 0); } },
                { text: "{lang xigua_hb:tongguo}", onClick: function(){ hf_dotong(id, 1); }}
            ]
        });
    }
});
act.push({
    text: '{lang xigua_hf:tuijian}', onClick: function () {
        $.modal({
            title: "{lang xigua_hf:tuijian}",
            text: "{lang xigua_hf:tuijiantip}",
            buttons: [
                { text: "{lang xigua_hb:quxiao}", className: "default"},
                { text: "{lang xigua_hf:butuijian}", onClick: function(){hf_tuijian(id, 0);} },
                { text: "{lang xigua_hf:tuijian}", onClick: function(){hf_tuijian(id, 1);}}
            ]
        });
    }
});
<!--{/if}-->
act.push( {
    text: '{lang xigua_hb:edit}', onClick: function () {
        window.location.href = '$SCRITPTNAME?id=xigua_hf{$mg}&ac=add&old_id='+id+_URLEXT;
    }
});
act.push( {text: '{lang xigua_hf:del}', onClick: function () { confirm_del('{lang xigua_hf:xiajiaconfirm}', '$SCRITPTNAME?id=xigua_hf{$mg}&ac=add&del='+id+'&formhash={FORMHASH}'); } });
$.actions({ title: '{lang xigua_hf:shangjia}: '+ttl, actions: act });
return false;
}
$(document).on('click','#dosearch', function () {
if($('#searchInput').val()){
    $('#dosearchform').submit();
}else{
    $.alert($('#searchInput').attr('placeholder'));
}
});
<!--{if $manage}-->
function hf_dotong(pubid, guo){
$.showLoading();
$.ajax({
    type: 'post',
    url: window.location.href + '&ac=manage&inajax=1&qunid='+pubid+'&tongguo='+guo,
    data:{formhash:FORMHASH,'domanage':1},
    dataType: 'xml',
    success: function (data) {
        $.hideLoading();
        if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
        var s = data.lastChild.firstChild.nodeValue;
        tip_common(s);
    },
    error: function () { $.hideLoading(); }
});
}
function hf_tuijian(pubid, guo){
    $.showLoading();
    $.ajax({
        type: 'post',
        url: window.location.href + '&ac=manage&inajax=1&qunid='+pubid+'&tj='+guo,
        data:{formhash:FORMHASH,'dotuijian':1},
        dataType: 'xml',
        success: function (data) {
            $.hideLoading();
            if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
            var s = data.lastChild.firstChild.nodeValue;
            tip_common(s);
        },
        error: function () { $.hideLoading(); }
    });
}
<!--{/if}-->
</script>