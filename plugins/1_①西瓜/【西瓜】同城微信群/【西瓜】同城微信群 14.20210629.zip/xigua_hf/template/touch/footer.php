<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hf:tabbar}-->
<!--{template xigua_hb:common_footer}-->
<div id="popup_wxqr" class="weui-popup__container popup-bottom">
    <div class="weui-popup__overlay"></div>
    <div class="weui-popup__modal">
        <div class="toolbar bgf">
            <div class="toolbar-inner">
                <a href="javascript:;" class="picker-button close-popup"><i class="iconfont icon-guanbijiantou f22 main_color"></i></a>
                <h1 class="title"></h1>
            </div>
        </div>
        <div class="modal-content footer_middle">
            <div class="footer_wxqr cl"></div>
            <div class="footer_fuzhi">
                <p class="showwxh mt5">{lang xigua_hf:qtjglwxh} <a href="javascript:;" class="weui-btn weui-btn_mini whbtn_free clickcopy clickcopy1">{lang xigua_hf:djfz}</a></p>
                <p class="mt5">{lang xigua_hf:chsbsq}<span id="klbox"></span>  <a href="javascript:;" class="weui-btn weui-btn_mini whbtn_free clickcopy2" style="display:none">{lang xigua_hf:fzkl}</a></p>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/geolocation.js?{VERHASH}"></script>
<script src="source/plugin/xigua_hf/static/js/hf.js?3{VERHASH}"></script>
<script>
var Clipboard= new ClipboardJS('.clickcopy');var Clipboard2= new ClipboardJS('.clickcopy2');Clipboard.on('success', function(e) {$.alert('<div class="free_dv">{lang xigua_hf:wxh} "'+e.text+'" <em class="color-red2">{lang xigua_hf:fzcg}</em> {lang xigua_hf:fzcg2}</div>'+'<img class="free_gu" src="source/plugin/xigua_hf/static/img/shili.png" />');});Clipboard2.on('success', function(e) {$.alert('<div class="free_dv">{lang xigua_hf:jiakouling} "'+e.text+'" <em class="color-red2">{lang xigua_hf:fzcg}</em></div>');});
function hf_paytel(id, pri) { if (UID<=0){$.alert('{lang xigua_hb:plzlogin}', function() {hb_jump('member.php?mod=logging&action=login&needlogin=1&referer={echo rawurlencode(hb_currenturl());}');});return false;}
$.confirm({title: '{lang xigua_hf:pay}',text: '{lang xigua_hf:pay}<strong class="amount">' + pri + '</strong>{lang xigua_hb:yuan}{lang xigua_hf:jiaqun}',
onOK: function () {$.showLoading();
$.ajax({type: 'POST',url: _APPNAME+'?id=xigua_hf&ac=getloc&do=telpay&qunid=' + id,
data:{formhash:'{FORMHASH}'},dataType: 'xml',success: function (data) {
$.hideLoading();if(null==data){ tip_common('error|'+ERROR_TIP); return false;}
var s = data.lastChild.firstChild.nodeValue;tip_common(s);},error: function() {$.hideLoading();}});}});}</script>