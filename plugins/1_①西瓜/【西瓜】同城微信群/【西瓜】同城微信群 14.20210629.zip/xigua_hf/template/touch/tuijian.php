<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<div class="jv_desc weui-cells before_none after_none tuijian_ul">
    <h2 class="h2top">{lang xigua_hf:tuijianqun}</h2>
    <div id="list" class="mod-post x-postlist pt0" style="background:#fff"></div>
    <!--{template xigua_hb:loading}-->
</div>
<script>var loadingurl = _APPNAME+'?id=xigua_hf&ac=qun_li&not={$qunid}&tuijian=1&inajax=1&page=';</script>