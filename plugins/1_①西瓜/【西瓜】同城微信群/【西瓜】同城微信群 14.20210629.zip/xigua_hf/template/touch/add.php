<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_hf:header}-->
<!--{eval
$showv = is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')&&is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/template/touch/video_field.php') && (($config['qn_ak'] && $config['qn_sk'] && $config['qn_bk'] && $config['qn_url']) || ($config['ACCESS_ID'] && $config['ACCESS_KEY'] && $config['ENDPOINT'] && $config['BUCKET']));
$bgc = hf_hex2rgb($config['maincolor'], 0.06);
$cannewmap = !IN_PROG && $_G['cache']['plugin']['xigua_hf']['newmap'];
if($cannewmap):
    if($_GET['latng']):
        list($getlat, $getlng) = explode(',', $_GET['latng']);
        $getlat = floatval($getlat);
        $getlng = floatval($getlng);
        foreach (array('name','addr', 'city', 'province', 'district', 'street', 'street_number') as $index => $item) :
            $_GET[$item] = diconv($_GET[$item], 'UTF-8', CHARSET);
        endforeach;
        $GLOBALS['nojson'] = 1;
        $allcity = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_name($_GET['city']);
        $allcity1 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_upid($allcity[0]['id']);
        $_GET['province'] = DB::result_first('select name from %t where id=%d', array('xigua_hb_district', $allcity[0]['upid']));
        foreach ($allcity1 as $index => $item)  :
            if(strpos($_GET['addr'], $item['name'])!==false):
                $_GET['district'] = $item['name'];
                break;
            endif;
        endforeach;
        if($_GET['name']==lang_hb('wdwz', 0)):
            $_GET['name'] = '';
        endif;
        $_GET['name'] = str_replace(array($_GET['province'], $_GET['city'], $_GET['district']),'', $_GET['name']);
        $_GET['addr'] = str_replace(array($_GET['province'], $_GET['city']),'', $_GET['addr']).$_GET['name'];
        $backurl = urlencode($_G['siteurl']."$SCRITPTNAME?id=xigua_hf&ac=add$urlext");
        unset($_GET['referer']);
        unset($_GET['name']);
    else:
        $backurl = urlencode(hb_currenturl());
    endif;
    $mk = $_G['cache']['plugin']['xigua_hf']['mkey'];
    $zom = $_G['cache']['plugin']['xigua_hf']['indexzoom'];
    $newmapurl = "https://apis.map.qq.com/tools/locpicker?search=1&type=0&policy=1&zoom=$zom&backurl=$backurl&key=$mk&referer=myapp";
endif;
}-->
<link rel="stylesheet" href="source/plugin/xigua_hb/static/dist/cropper.css?{VERHASH}"><link rel="stylesheet" href="source/plugin/xigua_hb/static/css/taocan.css?{VERHASH}"/><style>
.icon_li3{width: calc(33% - .2rem);float: left;height: 6rem;margin: 0 0.2rem 0.2rem 0;}.icon_li3 img{width:100%;height:100%;display:block}.weui-uploader__info{color:#999}.weui-label {color: #333;width: 95px}::-webkit-input-placeholder {color: #999}.texta {background: #f8f8f8;border-radius: 2px;box-shadow: 0 0 1px #ccc;padding: 10px;width: calc(100vw - 50px);margin-top: 10px;}.masker1 {position: fixed;top: 0;left: 0;right: 0;bottom: 0;background: rgba(0, 0, 0, .5);display: none;z-index: 1000}.weui-cells,.weui-vcode-btn{font-size:15px}.city-picker .picker-items-col{max-width:9rem;font-size:15px;}.city-picker .picker-items-col:first-child{text-align:right;}.car-type .car-year-season{background-color:$config[maincolor];}.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}.car-type .type-item-active:after{border-color:$config[maincolor]}.car-type .type-item-active{background:$bgc}.weui-cells_radio .weui-check:checked + .weui-icon-checked:before{content:'\EA06';font-size:21px;display:block}.weui-cells_radio .weui-icon-checked:before{content:'\EA01';color:#c9c9c9;font-size:21px;display:block;margin:0}.weui-uploader__info{font-size:12px}.car-type .car-year-season{background-color:$config[maincolor];}.car-type .type-item-active .car-active-c{border-bottom-color:$config[maincolor]}.car-type .type-item-active:after{border-color:$config[maincolor]}.car-type .type-item{float:left;width: calc((100vw - 50px) / 3);margin-right: 10px;margin-top: 10px;height: 72px;}
.car-type .type-item:nth-child(3n){margin-right:0}.car-type .type-item-box, .car-type .type-item-box-last {display:block}.car-type{padding-top:5px}.left_float{z-index:501}.pupc-btm{position: relative;overflow: visible;width: 100%;background: #fff;display: flex;transform: translate(0,0);transition: transform .3s;font-size:14px;}
.pupc-btm-in{width: 100%;flex: 1;height:320px;overflow-y: scroll;overflow-x: hidden;-webkit-overflow-scrolling: touch;position: relative;}
.pupc-btm-in a {line-height:40px;height:40px;display: block;padding: 0 15px;color: #666;text-decoration: none;overflow: hidden;white-space: nowrap;text-overflow: ellipsis;}
.pupc-btm-in a:last-child:before{display:none}
.post_com_tag{padding: 15px 15px 11px;background:#fff}
.post_com_tag:empty{display:none;}.post_com_tag:empty{display:none}
.post_com_tag .weui-btn_default{padding-right: 25px!important;background: url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADAAAAAwCAYAAABXAvmHAAACHUlEQVRoQ9XaTU7CQBTA8ffKzo0kUGEnKRfwAhq8gUeQG+hNvAEewRvgDeACxLozEhKMxuU805YiLaWdjzftlA2k4eP/60DTmYLBwF8AQheFeFx9bl6gBbfxRe+OEGcAGGIw7IcIeJl0i+nqY/PssmE87N0DeLOokYDeceT7V55Hr4h47joiE0/0JQROMIpuA6IoPlyvlzHAdcSp+Kh7D3AVURZ/BHANURVfCHAFIRN/EtA0Qja+FNAUQiW+ElA3QjVeClAXQideGmAboRuvBLCFMIlXBnAjTOO1AFwIjnhtgCmCK94IoIvgjDcGqCK441kAsggb8WyAKoSteFZAjBj2Jx3AefQ4uYlpcr+bw+6mgdFM6v85Zo8yExqzt0penZt0/yLgWbSdLMSzj0C6AxJEvOwRbyKiHyHwmnPPp5/FPgJHo0AUbfoWAm9aATj8CsV7fzfxJqKtEHjLjWAdgWh5ptOBRcmPmB3BBtitLc0RsZsegdJVvtxhlBXBAiiLz/6w94dTNoQxQCbeJsIIoBJvC6EN0Im3gdACmMRzI5QBHPGcCCUAZzwXQhpgI54DIQWwGW+KqATUEW+CKAXUGa+LOAloIl4HUQhoMl4VcQRwIV4FUXSRr/CUmGO+rPMeVafi+cusTsXLjMThhW4n46sQ6V8NnI4vQ2Aw9N8QYJSfBup8X+t4TXbdCUIMBv4SkLoo6KFVf7fx8AkIt39Ozxjpmu2SFAAAAABJRU5ErkJggg==) no-repeat right 10px center;background-size: 10px;}</style>
<div class="page__bd ">
    <form action="$SCRITPTNAME?id=xigua_hf&ac=add" method="post" id="form">
        <input type="hidden" name="formhash" value="{FORMHASH}">
        <input type="hidden" name="manage" value="$manage">
        <input type="hidden" name="form[old_id]" value="{$_GET[old_id]}">
        <input type="hidden" name="form[stid]" value="{$_GET[st]}">
        <input type="hidden" name="form[idu]" value="{$_GET[idu]}">
        <!--{if $old_data[status_str]}-->
        <div class="weui-cells__title c3 cl">
            <em class="main_color">{$old_data[status_str]}</em>
        </div>
        <!--{/if}-->
        <div class="weui-cells__title">{$hf_config['pubdesc']}</div>
        <div class="weui-cells mt0 before_none after_none">
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hf:name}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" value="{$old_data[name]}" name="form[name]" placeholder="{lang xigua_hf:qtxname}">
                </div>
            </div>
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hf:fenlei}<em class="color-red">*</em></label></div>
                <div class="weui-cell__bd">
                    <input id="jineng" class="weui-input" type="text" readonly value="{$old_data[jineng_str]}" placeholder="{lang xigua_hf:qxzjineng}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title c3">{lang xigua_hf:logo}</p>
                            <div class="weui-uploader__info">{lang xigua_hf:qtxlogo}<a href="javascript:;" onclick='$("#dftlogo__text").popup();' class="dftlogo main_color">{lang xigua_hf:huoxuan}</a></div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files logo_fields" data-only="1"><!--{if $old_data[logo]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[logo])">
                                    <input type="hidden" name="form[logo][]" value="$old_data[logo]"/>
                                    <div class="weui-uploader__file-content">
                                        <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box newupload">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[logo]"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[logo]" type="file">
                                <!--{/if}-->
                                <img src="source/plugin/xigua_hf/static/img/up.png">
                                <p>{lang xigua_hb:plzupload}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader cl">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title c3">{lang xigua_hf:wxqr}<em class="color-red">*</em></p>
                            <div class="weui-uploader__info"><!--{if $old_data&& $old_data[chaoshi]}--><span class="color-red2">{lang xigua_hf:chaoshi}</span><!--{else}-->{lang xigua_hf:qtxwxqr}<!--{/if}-->
                            </div>
                        </div>
                        <div class="weui-uploader__bd z">
                            <ul class="weui-uploader__files checkifimg" data-only="1" data-hide="wxqr_up" data-extuploadstr="checkqr=1&checkifqun=1&appcode={$hf_config[appcode]}"><!--{if $old_data[wxqr]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[wxqr])">
                                    <input type="hidden" name="form[wxqr][]" value="$old_data[wxqr]"/>
                                    <div class="weui-uploader__file-content">
                                        <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box newupload" id="wxqr_up" <!--{if $old_data[wxqr]}-->style="display:none"<!--{/if}-->>
                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                            <a class="weui-uploader__input" data-name="form[wxqr]"></a>
                            <!--{else}-->
                            <input class="weui-uploader__input" data-name="form[wxqr]" type="file">
                            <!--{/if}-->
                                <img src="source/plugin/xigua_hf/static/img/up.png">
                                <p>{lang xigua_hf:qunwxqr}</p>
                            </div>
                        </div>
                        <div class="weui-uploader__bd z ml8">
                            <ul class="weui-uploader__files checkifimg" data-only="1" data-hide="qunzhuqr_up" data-extuploadstr="checkqr=1&checkifqunzhu=1&appcode={$hf_config[appcode]}"><!--{if $old_data[qunzhuqr]}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($old_data[qunzhuqr])">
                                    <input type="hidden" name="form[qunzhuqr][]" value="$old_data[qunzhuqr]"/>
                                    <div class="weui-uploader__file-content">
                                        <i class="weui-icon-warn iconfont icon-shanchu"></i></div>
                                </li>
                                <!--{/if}--></ul>
                            <div class="weui-uploader__input-box newupload" id="qunzhuqr_up" <!--{if $old_data[qunzhuqr]}-->style="display:none"<!--{/if}-->>
                            <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[qunzhuqr]"></a>
                            <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[qunzhuqr]" type="file">
                            <!--{/if}-->
                                <img src="source/plugin/xigua_hf/static/img/up.png">
                                <p>{lang xigua_hf:qunzhuewm}</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
<!--{if in_array('album', $puballow)}-->
            <div class="weui-cell">
                <div class="weui-cell__bd">
                    <div class="weui-uploader">
                        <div class="weui-uploader__hd">
                            <p class="weui-uploader__title c3">{lang xigua_hf:album}</p>
                            <div class="weui-uploader__info">{echo str_replace('n', $hf_config['maximg'], lang_hf('zuiduofengcai',0))}</div>
                        </div>
                        <div class="weui-uploader__bd">
                            <ul class="weui-uploader__files" data-max="{$hf_config['maximg']}" data-maxtip="{echo str_replace('n', $hf_config['maximg'], lang_hf('zuiduozhao',0))}">
                                <!--{loop $old_data[album] $img}-->
                                <li class="weui-uploader__file weui-uploader__file_status" style="background-image:url($img)"><input type="hidden" name="form[album][]" value="$img"/><div class="weui-uploader__file-content"><i class="weui-icon-warn iconfont icon-shanchu"></i></div></li>
                                <!--{/loop}-->
                            </ul>
                            <div class="weui-uploader__input-box newupload">
                                <!--{if (HB_INWECHAT&&$config[multiupload]) || IN_MAGAPP}-->
                                <a class="weui-uploader__input" data-name="form[album]" data-multi="1"></a>
                                <!--{else}-->
                                <input class="weui-uploader__input" data-name="form[album]" type="file" data-multi="1">
                                <!--{/if}-->
                                <img src="source/plugin/xigua_hf/static/img/up.png">
                                <p>{lang xigua_hb:plzupload}</p>
                            </div>
                            <!--{if $showv}-->
                            <div class="weui-uploader__input-box newupload">
                                <img src="source/plugin/xigua_hb/static/img/video.png">
                                <p>{lang xigua_hb:upvideo}</p>
                                <input class="weui-uploader__input_video" data-name="form[video]" type="file" accept="video/*">
                            </div>
                            <!--{/if}-->
                        </div>
                    </div>
                </div>
            </div>
<!--{/if}-->
            <!--{if $showv}-->
            <!--{template xigua_hb:video_field}-->
            <!--{/if}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hf:qunzhuwx2}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[qunzhuwx]" value="{$old_data[qunzhuwx]}" placeholder="{lang xigua_hf:qunzhuwx_tip}">
                </div>
            </div>
        </div>
        <div class="weui-cells before_none after_none">
            <!--{if in_array('yaoqingma', $puballow)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hf:yqm}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[yqm]" value="{echo $old_data[yqm] ?$old_data[yqm]:''}" placeholder="{lang xigua_hf:yqm_tip}">
                </div>
            </div>
            <!--{/if}-->
            <!--{if in_array('shoufei', $puballow)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hf:shoufei}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[shoufei]" value="{echo $old_data[shoufei]>0 ?$old_data[shoufei]:''}" placeholder="{lang xigua_hf:shoufei_tip}">
                </div>
                <div class="weui-cell__ft">
                    {lang xigua_hb:yuan}
                </div>
            </div>
            <!--{/if}-->
            <!--{if in_array('kouling', $puballow)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hf:kouling}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[kouling]" value="{$old_data[kouling]}" placeholder="{lang xigua_hf:kouling_tip}">
                </div>
            </div>
            <!--{/if}-->
            <!--{if $hf_config[allowqy]}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hf:diqu}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" name="form[diqu]" id="diqu" type="text" value="{echo $old_data[city] ? $old_data[province].' '.$old_data[city].' '.$old_data[district] :'';}" placeholder="{lang xigua_hf:qxzdiqu}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->
            <!--{if in_array('weizhi', $puballow)}-->
            <div class="weui-cell weui-cell_vcode">
                <div class="weui-cell__hd">
                    <label class="weui-label">{lang xigua_hf:addr}</label>
                </div>
                <div class="weui-cell__bd enter_addr">
                    <input class="weui-input" id="location_99" name="form[addr]" type="text" placeholder="{lang xigua_hf:qdw}" value="{echo $_GET[addr] ? $_GET[addr] : $old_data[addr]}">
                    <input type="hidden" id="lat" name="form[lat]" value="{echo $getlat ? $getlat: $old_data['lat']}">
                    <input type="hidden" id="lng" name="form[lng]" value="{echo $getlng ? $getlng: $old_data['lng']}">
                    <input type="hidden" id="province" name="form[province]" value="{echo $_GET[province] ? $_GET[province] : $old_data['province']}">
                    <input type="hidden" id="city" name="form[city]" value="{echo $_GET[city] ? $_GET[city] : $old_data['city']}">
                    <input type="hidden" id="district" name="form[district]" value="{echo $_GET[district] ? $_GET[district] : $old_data['district']}">
                    <input type="hidden" id="street" name="form[street]" value="{echo $_GET[street] ? $_GET[street] : $old_data['street']}">
                    <input type="hidden" id="street_number" name="form[street_number]" value="{echo $_GET[street_number] ? $_GET[street_number] : $old_data['street_number']}">
                </div>
                <div class="weui-cell__ft">
                    <!--{if $cannewmap}-->
                    <a href="$newmapurl" class="weui-vcode-btn" type="button">{lang xigua_hb:dingwei}</a>
                    <!--{else}-->
                    <button class="weui-vcode-btn openlocation" data-id="99" type="button">{lang xigua_hb:dingwei}</button>
                    <!--{/if}-->
                </div>
            </div>
            <!--{/if}-->
            <!--{if in_array('fanwei', $puballow)}-->
            <div class="weui-cell">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hf:fanwei}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[fanwei]" value="{echo $old_data[fanwei]>0 ? $old_data[fanwei] : ''}" placeholder="{lang xigua_hf:fanwei_tip2}">
                </div>
                <div class="weui-cell__ft">
                    {lang xigua_hf:kmn}
                </div>
            </div>
            <!--{/if}-->
        </div>
        <div class="weui-cells before_none after_none">
            <!--{if $hf_config[anniu]}-->
            <div class="weui-cell weui-">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hf:btntext}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[btntext]" value="{$old_data[btntext]}" placeholder="{lang xigua_hf:btntext_tip}">
                </div>
            </div>
            <!--{/if}-->
            <!--{if $hf_config[allowjj]}-->
            <div class="weui-cell weui-">
                <div class="weui-cell__hd"><label class="weui-label">{lang xigua_hf:xuzhi}</label></div>
                <div class="weui-cell__bd">
                    <input class="weui-input" type="text" name="form[xuzhi]" value="{$old_data[xuzhi]}" placeholder="{lang xigua_hf:xuzhi_tip}">
                </div>
            </div>
            <!--{/if}-->
            <div class="weui-cell" style="align-items: baseline;">
                <div class="weui-cell__hd">
                    <label for="" class="weui-label">{lang xigua_hf:jieshao}<em class="color-red">*</em></label>
                </div>
                <div class="weui-cell__bd">
                    <textarea name="form[jieshao]" class="weui-textarea" placeholder="{lang xigua_hf:fuwxq}" rows="3">{$old_data[jieshao]}</textarea>
                </div>
            </div>
            <!--{if $_G['cache']['plugin']['xigua_hs'] && $shs}-->
            <div class="weui-cell weui-cell_access">
                <div class="weui-cell__hd"><label for="" class="weui-label">{lang xigua_hs:guanlian}</label></div>
                <div class="weui-cell__bd">
                    <input id="choose_sh" class="weui-input" name="form[shname]" type="text" value="{echo $old_data ? $old_data['shname'] : ''}" placeholder="{lang xigua_hs:qxzguanlian}">
                </div>
                <div class="weui-cell__ft"></div>
            </div>
            <!--{/if}-->
        </div>
        <!--{if !$old_data && $digtys}-->
        <div class="weui-cells__title c9">{lang xigua_hf:zdhq}</div>
        <div id="dftvip" class="cl car-type">
            <div class="type-item-box">
                <!--{loop $digtys $___k $___v}-->
                <label for="s{$___k}" class="type-item J_ping type-item-gray">
                    <input type="radio" class="none" name="form[digtype]" value="{$___k}" id="s{$___k}" <!--{if $___k==0}-->checked="checked"<!--{/if}-->>
                    <!--{if $___k==0}-->
                    <div class="type-title">{lang xigua_hf:bzd}</div>
                    <!--{else}-->
                    <div class="type-title">{lang xigua_hf:zdjl}{$___k}{lang xigua_hb:day}</div>
                    <!--{/if}-->
                    <div class="car-sku-year cl">
                        <div class="type-discount">
                            <!--{if $___v>0}-->
                            <span class="car-price">{echo floatval($___v)}</span><span class="car-unit">{lang xigua_hb:yuan}</span>
                            <!--{else}-->
                            <span class="car-unit">{lang xigua_hf:mf}</span>
                            <!--{/if}-->
                        </div>
                    </div>
                    <div class="car-active-b">
                        <div class="car-active-c"><i class="iconfont icon-xuanzhong"></i></div>
                    </div>
                </label>
                <!--{/loop}-->
            </div>
        </div>
        <!--{/if}-->
        <label class="weui-agree mt10" onclick='$("#agree__text").popup();'>
            <input id="weuiAgree" type="checkbox" checked="checked" disabled readonly class="weui-agree__checkbox">
            <span class="weui-agree__text"> {lang xigua_hb:agree}<a href="javascript:void(0);">{lang xigua_hf:fbxygz}</a> </span>
        </label>
        <div class="footer_fix"></div>
        <div class="fix-bottom mt10">
            <!--{if $old_data[qunid]}-->
            <input type="submit" class="weui-btn weui-btn_primary" name="dosubmit" id="dosubmit" value="{lang xigua_hf:bc}">
            <!--{else}-->
            <!--{if $hf_config[pubpri]>0}-->
            <input type="submit" class="weui-btn weui-btn_primary newbtn" name="dosubmit" data-price="{$hf_config[pubpri]}" id="dosubmit" value="{lang xigua_hf:pay}{$hf_config[pubpri]}{lang xigua_hb:yuan}{lang xigua_hf:pub}">
            <!--{else}-->
            <input type="submit" class="weui-btn weui-btn_primary newbtn" name="dosubmit" data-price="{$hf_config[pubpri]}" id="dosubmit" value="{lang xigua_hf:pub}">
            <!--{/if}-->
            <!--{/if}-->
        </div>
        <!--{template xigua_hf:popup}-->
    </form>
</div>
<div id="popctrl" class="weui-popup__container" style="z-index:1001">
    <div class="weui-popup__modal">
        <div style="height: 100vh"><img id="photo"></div>
        <div class="pub_funcbar">
            <a class="weui-btn close-popup weui-btn_primary" data-method="confirm">{lang xigua_hb:queding}</a>
            <a class="weui-btn close-popup weui-btn_default" data-method="destroy">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div id="agree__text" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <article class="weui-article">
                <h1>{lang xigua_hf:fbxygz}</h1>
                <section>
                    <section>
                        $hf_config[fbxy]
                    </section>
                </section>
            </article>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_primary close-popup" href="javascript:;">{lang xigua_hb:woyi}</a>
        </div>
    </div>
</div>
<div id="dftlogo__text" class="weui-popup__container">
    <div class="weui-popup__modal">
        <div class="fixpopuper">
            <article class="weui-article">
                <h1>{lang xigua_hf:dianxuan}</h1>
                <div class="cl">
                    <!--{loop $defaulticon $_k $_v}-->
                    <!--{eval $_v = trim($_v);}-->
                    <div class="icon_li3" onclick="seticon_byclick('$_v');"><img src="$_v" onerror="this.error=null;$(this).parent().remove()" /></div>
                    <!--{/loop}-->
                </div>
            </article>
            <div class="footer_fix"></div>
            <div class="bottom_fix"></div>
        </div>
        <div class="fix-bottom">
            <a class="weui-btn weui-btn_default close-popup" href="javascript:;">{lang xigua_hb:quxiao}</a>
        </div>
    </div>
</div>
<div class="masker" style="position:fixed;top:0;left:0;right:0;bottom:0;background:rgba(0,0,0,.5);display:none;z-index:1000" onclick='$("#choose_sh").select("close")'></div>
<!--{eval $tabbar=0;$ho_tabbar=0;}-->
<!--{template xigua_hb:enter_up}-->
<!--{template xigua_hf:footer}-->
<!--{template xigua_hf:location_js}-->
<!--{if $showv}--><!--{template xigua_hb:video}--><!--{/if}-->
<script>$(document).on('click','.J_ping', function(){var that = $(this), dosubm = $('.newbtn'); var nowp = parseFloat(that.find('.car-price').text()), pubp = parseFloat(dosubm.data('price'));if(isNaN(nowp)){nowp = 0;}if(isNaN(pubp)){pubp = 0;}var allp = pubp+nowp;if(nowp>0) {dosubm.val('{lang xigua_hf:pay}' + allp + '{lang xigua_hb:yuan}{lang xigua_hf:pub}{lang xigua_hf:bingzd}');}else if(allp<=0 || isNaN(allp)){dosubm.val('{lang xigua_hf:pub}');}else{dosubm.val('{lang xigua_hf:pay}'+pubp+'{lang xigua_hb:yuan}{lang xigua_hf:pub}');}$('.J_ping').addClass('type-item-gray').removeClass('type-item-active');$(this).addClass('type-item-active').removeClass('type-item-gray');});var jP = $('.J_ping:first-child');jP.trigger('click');jP.find('.typevip').trigger('click');$(document).on('click','#jineng', function () {var popcm =$('#popup_jineng');popcm.popup();popcm.show();setTimeout(function(){popcm.show();}, 500);return false;});<!--{if $shs}-->var itar = [];itar.push({title:'{lang xigua_hf:noguan}'});<!--{loop $shs $_sh}-->
itar.push({title:'{$_sh[name]}'});
<!--{/loop}-->
$("#choose_sh").select({title: "{lang xigua_hs:qxzguanlian}",items: itar,onOpen:function () { $('.masker').fadeIn();},
beforeClose:function () { $('.masker').fadeOut(150);return true;}});
<!--{/if}--></script>
<!--{if $hf_config[allowqy]}-->
<!--{eval
$_key = 'hscityIdist'.intval($_GET['st']);
loadcache($_key);
$jsary1 = $_G['cache'][$_key]['variable'][1];
if(!json_encode($jsary1) || (TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000)) :
    $GLOBALS['nojson'] = 0;
    $dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
    $list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
    C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
    $jsary1 = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
    foreach ($dist0 as $index => $item) :
        C::t('#xigua_hb#xigua_hb_district')->empty_child();
        $dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
    endforeach;
    savecache($_key, array('variable' => array($dist0, $jsary1), 'expiration' => TIMESTAMP));
endif;
$jsary1 = array_values($jsary1);
$pickercityjson = json_encode($jsary1);
$pickerdefault = diconv($jsary1[0]['name'].' '. $jsary1[0]['sub'][0]['name'].' '.$jsary1[0]['sub'][0]['sub'][0]['name'], 'utf-8', CHARSET);
}-->
<script> +function($){  $.rawCitiesData1 = $pickercityjson; }($); var DFTFIELD = '$pickerdefault';</script>
<script type="text/javascript" src="source/plugin/xigua_hb/static/js/picker.js?_{VERHASH}" charset="utf-8"></script>
<script>
$("#diqu").cityPicker1({
    title: "{lang xigua_hf:qxzdiqu}",
    onChange: function (picker, values, displayValues) {
        console.log(displayValues);
        $('#city').val(displayValues[1]);
        $('#province').val(displayValues[0]);
        $('#district').val(displayValues[2]);
    }
});
</script><!--{/if}-->
<script>function seticon_byclick(v) {
    console.log(v);
    var appev =  "<li class=\"weui-uploader__file weui-uploader__file_status\" style=\"background-image:url("+v+")\"><input type=\"hidden\" name=\"form[logo][]\" value=\""+v+"\"><div class=\"weui-uploader__file-content\"><i class=\"weui-icon-warn iconfont icon-shanchu\"></i></div></li>";
    $('.logo_fields').html(appev);
    $.closePopup();
}
</script>