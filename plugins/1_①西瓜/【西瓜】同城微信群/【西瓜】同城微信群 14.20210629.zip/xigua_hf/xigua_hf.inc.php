<?php
 /**
 * Created by DisM.
 * User: DisM!Ӧ������
 * From: DisM.taobao.Com
 * ����Դ��Դ�������ռ�,��������ѧϰ����������������ҵ��;����������24Сʱ��ɾ��!
 * ����ַ�������Ȩ��,�뼰ʱ��֪����,���Ǽ���ɾ��!
 * Time: 2021-06-17
 */
if (!defined('IN_DISCUZ')) {
	exit('Access Denied');
}
if (!is_file(DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php')) {
	exit('Please install <a href="https://dism.taobao.com/?@xigua_hb.plugin">https://dism.taobao.com/?@xigua_hb.plugin</a>');
}
include_once DISCUZ_ROOT . 'source/plugin/xigua_hb/common.php';
if (empty($_G['cache']['plugin'])) {
	loadcache('plugin');
}
$sys_protocal = isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://';
$url = $sys_protocal . (isset($_SERVER['HTTP_HOST']) ? $_SERVER['HTTP_HOST'] : '');
$url = rtrim($url, '/') . '/';
include_once DISCUZ_ROOT . 'source/plugin/xigua_hf/function.php';
$hf_config = $_G['cache']['plugin']['xigua_hf'];
$config['maincolor'] = $_G['cache']['plugin']['xigua_hb']['maincolor'] = $hf_config['maincolor'];
$digtys = array();
foreach (explode("\n", trim($hf_config['digtys'])) as $index => $item) {
	list($_day, $_price) = explode('=', trim($item));
	$digtys[trim($_day)] = trim($_price);
}
$ac = $_GET['ac'];
$do = $_GET['do'];
$aclist = array('index', 'my', 'add', 'qun_li', 'view', 'misc', 'manage', 'top', 'dodig', 'getloc', 'incr', 'del', 'hangye', 'googleMap', 'refresh', 'checkyqm');
$aclist_login = array('add', 'misc', 'my', 'del', 'dodig', 'manage', 'refresh');
if (!in_array($ac, $aclist)) {
	$ac = 'index';
}
if (in_array($ac, $aclist_login) && !$_G['uid']) {
	hb_jump_login();
}
$_GET = dhtmlspecialchars($_GET);
$page = max(1, intval($_GET['page']));
$lpp = $_GET['pagesize'] ? intval($_GET['pagesize']) : 10;
$start_limit = ($page - 1) * $lpp;
$qunid = intval($_GET['qunid']);
switch ($ac) {
	case 'refresh':
		if (submitcheck('formhash')) {
			$_GET['rl'] = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hf&ac=view&qunid=' . $qunid . $urlext);
			$qun = C::t('#xigua_hf#xigua_hf_qun')->fetch($qunid);
			$title = lang_hf('shuaxin_tip', 0) . $qun['name'];
			$price = $hf_config['refpri'] > 0 ? $hf_config['refpri'] : '0.01';
			$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price, $title, 'common_hf_refresh', array('data' => array('uid' => $_G['uid'], 'price' => $price, 'qunid' => $qunid), 'callback' => array('file' => 'source/plugin/xigua_hf/function_refresh.php', 'method' => 'hf_refresh_callback'), 'location' => $_GET['rl']));
			$rl = urlencode($_GET['rl']);
			$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
			hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
		}
		break;
	case 'manage':
		if (submitcheck('domanage') && IS_ADMINID) {
			C::t('#xigua_hf#xigua_hf_qun')->manage($qunid);
			hb_message(lang_hf('succeed', 0), 'success', 'reload');
		}
		if (submitcheck('dotuijian') && IS_ADMINID) {
			C::t('#xigua_hf#xigua_hf_qun')->tuijian($qunid);
			hb_message(lang_hf('succeed', 0), 'success', 'reload');
		}
		break;
	case 'index':
		$navtitle = str_replace('{tname}', $stinfo['name'], $hf_config['title']);
		$desc = str_replace('{tname}', $stinfo['name'], $hf_config['desc']);
		$topnavslider = hb_parse_set($hf_config['topslider']);
		$midnavslider = hb_parse_set($hf_config['midslider']);
		$indeximg = $hf_config['shareimg'];
		$cat_list = C::t('#xigua_hf#xigua_hf_hangye')->list_by_pid(0, true);
		$jing_list = array_values($cat_list);
		if (!($numi1 = $hf_config['numi1'] * 2)) {
			$numi1 = 10;
		}
		if ($jing_list) {
			$jing_count = range(0, ceil(count($jing_list) / $numi1) - 1);
		}
		$toutiaoitems = array_filter(explode("\n", trim($_G['cache']['plugin']['xigua_hf']['toutext'])));
		if ($hf_config['tjnum'] > 0) {
			$hf_list = C::t('#xigua_hf#xigua_hf_qun')->fetch_tuijian($hf_config['tjnum']);
			$shwidth = count($hf_list) * 78;
		}
		if ($hf_config['showtj']) {
			$total_count = C::t('#xigua_hf#xigua_hf_qun')->total_count();
			$total_views = C::t('#xigua_hf#xigua_hf_qun')->total_views();
		}
		$fullindex2 = $hf_config['indexshow'];
		$indexmod = array();
		$firstmod = '';
		foreach (explode("\n", $fullindex2) as $index => $item) {
			list($modindex, $modname) = explode('=', trim($item));
			if (!$firstmod) {
				$firstmod = $modindex;
			}
			$indexmod[$modindex] = $modname;
		}
		$_GET['nav'] = !$_GET['nav'] ? $firstmod : $_GET['nav'];
		break;
	case 'dodig':
		if (submitcheck('formhash')) {
			$qun = C::t('#xigua_hf#xigua_hf_qun')->fetch($qunid);
			if (!$qun) {
				hb_message(lang_hf('not_exists', 0), 'error');
			}
			$days = intval($_GET['type']);
			if ($digprice = $digtys[$days]) {
				$title = lang_hf('zdjl', 0) . $days . lang_hf('day', 0) . '-' . $qun['name'];
				$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hf&ac=my' . $urlext);
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $digprice, $title, 'common_hfhdig', array('data' => array('qunid' => $qunid, 'price' => $digprice, 'dig_days' => $days), 'callback' => array('file' => 'source/plugin/xigua_hf/function.php', 'method' => 'hf_dig_callback'), 'location' => $rtl, 'referer' => $rtl));
				$rl = urlencode($rtl);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext);
				hb_message(lang_hf('jumppay', 0), 'loading', $jumpurl);
			}
		}
		break;
	case 'add':
		global $_G;
		global $config;
		global $SCRITPTNAME;
		check_bind_hf();
		$navtitle = lang_hf('pubwxq', 0);
		$desc = $hf_config['pubdesc'];
		$puballow = unserialize($hf_config['puballow']);
		$defaulticon = array_filter(explode("\n", trim($hf_config['defaulticon'])));
		$manage = IS_ADMINID && $_GET['manage'];
		if (submitcheck('formhash') && $_GET['pay']) {
			$old_data = C::t('#xigua_hf#xigua_hf_qun')->fetch_by_id($_GET['old_id']);
			$pubprice = $hf_config['pubpri'];
			if (!$pubprice) {
				$pubprice = 0;
			}
			$title = lang_hf('dotpub', 0) . $old_data['name'];
			$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hf&ac=my' . $urlext);
			$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $pubprice, $title, 'common_hfmulti_pay', array('data' => array('qunid' => $_GET['old_id'], 'digtype' => 0, 'dig_price' => 0, 'pubprice' => $pubprice), 'callback' => array('file' => 'source/plugin/xigua_hf/function.php', 'method' => 'hfmulti_pay_callback'), 'location' => $rtl, 'referer' => $rtl));
			$rl = urlencode($rtl);
			$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
			hb_message(lang_hf('jumppay', 0), 'loading', $jumpurl);
		} elseif (submitcheck('formhash') && $_GET['del']) {
			if (IS_ADMINID) {
				C::t('#xigua_hf#xigua_hf_qun')->delete($_GET['del']);
			} else {
				C::t('#xigua_hf#xigua_hf_qun')->del_by_uid_qunid($_GET['del']);
			}
			hb_message(lang_hf('del1', 0), 'success', 'reload');
		} else {
			if (submitcheck('formhash')) {
				$hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
				if ($hbuser['pingbi']) {
					hb_message(lang_hb('ybpb', 0), 'error');
				}
				$form = $_GET['form'];
				$data = array('stid' => $form['stid'], 'name' => $form['name'], 'qunzhuwx' => $form['qunzhuwx'], 'shoufei' => $form['shoufei'], 'yqm' => $form['yqm'], 'kouling' => $form['kouling'], 'addr' => $form['addr'], 'lat' => $form['lat'], 'lng' => $form['lng'], 'province' => $form['province'], 'city' => $form['city'], 'district' => $form['district'], 'street' => $form['street'], 'street_number' => $form['street_number'], 'jieshao' => $form['jieshao'], 'digtype' => $form['digtype'], 'uid' => $_G['uid'], 'upts' => TIMESTAMP, 'endts' => 0 - 1, 'fanwei' => $form['fanwei'], 'video' => $form['video'], 'video_cover' => $form['video_cover'], 'xuzhi' => $form['xuzhi'], 'btntext' => $form['btntext']);
				if ($_G['cache']['plugin']['xigua_hs'] && $form['shname']) {
					$sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_name($form['shname']);
					if ($sh) {
						$data['shname'] = $sh['name'];
						$data['shid'] = $sh['shid'];
					} else {
						$data['shname'] = '';
						$data['shid'] = 0;
					}
				}
				$data['wxqr'] = $form['wxqr'][0] ? $form['wxqr'][0] : $form['wxqr'];
				$data['logo'] = $form['logo'][0] ? $form['logo'][0] : $form['logo'];
				$data['qunzhuqr'] = $form['qunzhuqr'][0] ? $form['qunzhuqr'][0] : $form['qunzhuqr'];
				if (is_array($data['qunzhuqr'])) {
					$data['qunzhuqr'] = array_values($data['qunzhuqr']);
					$data['qunzhuqr'] = $data['qunzhuqr'][0];
				}
				if (is_array($data['wxqr'])) {
					$data['wxqr'] = array_values($data['wxqr']);
					$data['wxqr'] = $data['wxqr'][0];
				}
				if (is_array($data['logo'])) {
					$data['logo'] = array_values($data['logo']);
					$data['logo'] = $data['logo'][0];
				}
				$data['album'] = serialize($form['album']);
				if (!$data['name']) {
					hb_message(lang_hf('qtxname', 0), 'error');
				}
				if ($form['jineng']) {
					$listjson = C::t('#xigua_hf#xigua_hf_hangye')->list_json();
					foreach ($listjson as $index => $item) {
						if (in_array($item['code'], $form['jineng'])) {
							$jineng_string_tmp[$item['code']] = $item['oname'];
						}
					}
					foreach ($form['jineng'] as $index => $item) {
						$jineng_string[$item] = $jineng_string_tmp[$item];
					}
					$data['jineng_str'] = implode(',', $jineng_string);
					$data['jineng'] = implode(',', $form['jineng']);
				} else {
					hb_message(lang_hf('min1jineng', 0), 'error');
				}
				if (!$data['wxqr']) {
					hb_message(lang_hf('qtxwxqr1', 0), 'error');
				}
				if (!$data['qunzhuqr'] || is_array($data['qunzhuqr'])) {
					hb_message(lang_hf('qtxwxqr2', 0), 'error');
				}
				if ($data['fanwei'] && !$data['lat']) {
					hb_message(lang_hf('qdw', 0), 'error');
				}
				if (!$data['jieshao']) {
					hb_message(lang_hf('qtxjieshao', 0), 'error');
				}
				if ($old_data = C::t('#xigua_hf#xigua_hf_qun')->fetch_by_id($form['old_id'])) {
					if (!$manage) {
						if ($hf_config['mfshen']) {
							$data['status'] = 0 - 1;
						}
					}
					$msg = lang_hf('bccg', 0);
					C::t('#xigua_hf#xigua_hf_qun')->update_G($old_data['qunid'], $data);
					if ($data['status'] == 0 - 1) {
						to_noti($data, 0);
						hb_message(lang_hf('bccgsc', 0), 'success', $SCRITPTNAME . '?id=xigua_hf&ac=my&status=-1&mobile=2' . $urlext . ($manage ? '&manage=1' : ''));
					} else {
						hb_message(lang_hf('bccg', 0), 'success', $SCRITPTNAME . '?id=xigua_hf&ac=my&mobile=2' . $urlext . ($manage ? '&manage=1' : ''));
					}
				} else {
					$data['crts'] = TIMESTAMP;
					if (IS_ADMINID) {
						$hf_config['pubpri'] = 0;
						$hf_config['mfshen'] = 0;
					}
					$pubprice = $hf_config['pubpri'];
					if ($pubprice > 0) {
						$data['status'] = 0 - 2;
					} else {
						if ($hf_config['mfshen']) {
							$data['status'] = 0 - 1;
						} else {
							$data['status'] = 1;
						}
					}
					$newid = C::t('#xigua_hf#xigua_hf_qun')->insert($data, 1);
					$dig_price = $digtys[$data['digtype']];
					$totalprice = $pubprice + $dig_price;
					if ($totalprice > 0) {
						$title = lang_hf('dotpub', 0) . $data['name'] . ($dig_price ? lang_hf('dotzd', 0) . $data['digtype'] . lang_hf('day', 0) : '');
						$rtl = $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hf&ac=my' . $urlext);
						$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $totalprice, $title, 'common_hfmulti_pay', array('data' => array('qunid' => $newid, 'digtype' => $data['digtype'], 'dig_price' => $dig_price, 'pubprice' => $pubprice), 'callback' => array('file' => 'source/plugin/xigua_hf/function.php', 'method' => 'hfmulti_pay_callback'), 'location' => $rtl, 'referer' => $rtl));
						$rl = urlencode($rtl);
						$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl) . $urlext) . $urlext;
						hb_message(lang_hf('jumppay', 0), 'loading', $jumpurl);
					} else {
						if ($data['status'] == 0 - 1) {
							to_noti($data, 1);
							hb_message(lang_hf('fbcgsc', 0), 'success', $SCRITPTNAME . '?id=xigua_hf&ac=my&status=-1&mobile=2' . $urlext);
						} else {
							hb_message(lang_hf('fbcg', 0), 'success', $SCRITPTNAME . '?id=xigua_hf&ac=my&mobile=2' . $urlext);
						}
					}
				}
				hb_message(lang_hf('fbcg', 0) . '!', 'success', $SCRITPTNAME . '?id=xigua_hf&ac=my&mobile=2' . $urlext);
			} else {
				$old_data = C::t('#xigua_hf#xigua_hf_qun')->fetch_by_id($_GET['old_id']);
				if ($old_data['uid'] != $_G['uid'] && !$manage) {
					$old_data = array();
				}
				$list_all1 = C::t('#xigua_hf#xigua_hf_hangye')->list_all();
				C::t('#xigua_hf#xigua_hf_hangye')->init($list_all1);
				$jsary = C::t('#xigua_hf#xigua_hf_hangye')->get_tree_array(0);
				if ($old_data) {
					$navtitle = lang_hf('xgwxq', 0);
				}
				if ($_G['cache']['plugin']['xigua_hs'] && $hf_config['allowsh']) {
					$shs = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where(array('uid=' . $_G['uid'] . ' and display=1 and endts>=' . TIMESTAMP));
				}
			}
		}
		break;
	case 'hangye':
		$cat_id = intval($_GET['cat_id']);
		$hy = C::t('#xigua_hf#xigua_hf_hangye')->fetch($cat_id);
		$navtitle = $hy['name'];
		$pid = $hy['pid'];
		if ($_GET['keyword']) {
			$navtitle = $keyword = stripsearchkey($_GET['keyword']);
		}
		if ($_GET['tag']) {
			$navtitle = stripsearchkey($_GET['tag']);
		}
		$list_all = C::t('#xigua_hf#xigua_hf_hangye')->list_all();
		C::t('#xigua_hf#xigua_hf_hangye')->init($list_all);
		$cat_tree_init = $cat_tree = C::t('#xigua_hf#xigua_hf_hangye')->get_tree_array(0);
		$cat_tree = array_values($cat_tree);
		$_key = 'hbIdist' . intval($_GET['st']);
		loadcache($_key);
		if (!$_G['cache'][$_key]['variable'] || TIMESTAMP - $_G['cache'][$_key]['expiration'] > 2592000 || defined('IN_ADMINCP')) {
			$dist0 = C::t('#xigua_hb#xigua_hb_district')->fetch_all_by_level(1);
			$GLOBALS['nojson'] = 1;
			$list_all1 = C::t('#xigua_hb#xigua_hb_district')->list_all();
			C::t('#xigua_hb#xigua_hb_district')->init($list_all1);
			$jsary = C::t('#xigua_hb#xigua_hb_district')->get_tree_array(0);
			foreach ($dist0 as $index => $item) {
				C::t('#xigua_hb#xigua_hb_district')->empty_child();
				$dist0[$index]['child'] = C::t('#xigua_hb#xigua_hb_district')->get_child($item['id']);
			}
			savecache($_key, array('variable' => array($dist0, $jsary), 'expiration' => TIMESTAMP));
		} else {
			$dist0 = $_G['cache'][$_key]['variable'][0];
			$jsary = $_G['cache'][$_key]['variable'][1];
		}
		if ($_GET['province']) {
			$distname = $_GET['province'];
		}
		if ($_GET['city']) {
			$distname = $_GET['city'];
		}
		if ($_GET['dist']) {
			$distname = $_GET['dist'];
		}
		if ($distname) {
			$navtitle = $distname . $navtitle;
		}
		if (!$distname) {
			$distname = lang_hb('plugins_edit_vars_type_area', 0);
		}
		$quanname = $_GET['quan'];
		if (!$quanname) {
			$quanname = lang_hb('shangquan', 0);
		}
		$lat = floatval($_GET['lat']);
		$lng = floatval($_GET['lng']);
		$catname = $hy['name'] ? $hy['name'] : lang_hb('quanbu', 0);
		$orderby = $_GET['orderby'];
		$orderby_list = array('' => lang_hb('om', 0), 'near' => lang_hf('juli', 0), 'hot' => lang_hb('zr', 0), 'new' => lang_hb('zx', 0));
		if (!$navtitle) {
			$navtitle = $orderby_list[$orderby] == lang_hb('om', 0) ? lang_hb('quanbu', 0) : $orderby_list[$orderby];
		}
		$custom_side = array($SCRITPTNAME . '?id=xigua_hf&ac=add' . $urlext, lang_hf('wyru', 0));
		$subcat = $cat_tree;
		if ($pid == 0) {
			$subcats = $cat_tree_init[$cat_id]['child'];
		}
		$get_tag = array();
		foreach ($_GET as $index => $item) {
			if ($index != 'tag') {
				$get_tag[$index] = $item;
			}
		}
		$query = http_build_query($get_tag);
		foreach ($list_all as $index => $item) {
			if ($cat_id == $item['id']) {
				$catinfo = $item;
				break;
			}
		}
		if ($hy['share_title']) {
			$anavtitle = $navtitle;
			$navtitle = $hy['share_title'];
		}
		if ($hy['share_desc']) {
			$description = $desc = $hy['share_desc'];
		}
		if (!$desc) {
			$desc = $navtitle;
		}
		if (!$hy['share_pic']) {
			$hy['share_pic'] = $hy['icon'];
		}
		if ($_GET['tuijian']) {
			$navtitle = lang_hf('qbtj', 0);
		}
		break;
	case 'my':
		$navtitle = lang_hf('wdq', 0);
		$manage = intval(IS_ADMINID && $_GET['manage']);
		if ($manage) {
			$navtitle = lang_hf('glwxq', 0);
		}
		$custom_side = array($SCRITPTNAME . '?id=xigua_hb&ac=my' . $urlext, lang_hf('grzx', 0));
		if (!$_GET['status']) {
			$_GET['status'] = 1;
		}
		if (IS_ADMINID && !$manage) {
			$custom_side = array($SCRITPTNAME . '?id=xigua_hf&ac=my&manage=1' . $urlext, lang_hf('gly', 0));
		}
		break;
	case 'qun_li':
		$pingbi = 0;
		if ($_G['uid']) {
			$hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			if ($hbuser['pingbi']) {
				$pingbi = 1;
			}
		}
		$ob = 'upts DESC';
		$where = array();
		$manage = IS_ADMINID && $_GET['manage'];
		$field = '*';
		$stcon = '';
		if ($hf_config['allowst'] && !$manage && $_GET['st'] > 0) {
			$where[] = ' stid=' . intval($_GET['st']);
		}
		if ($_GET['is_my'] && $_G['uid'] > 0) {
			if ($_GET['status'] == 4) {
				$qunids_ary = DB::fetch_all('select pubid,crts from %t where uid=%d order by crts desc' . DB::limit($start_limit, $lpp), array('xigua_hf_viewqun', $_G['uid']), 'pubid');
				$qunids = array_keys($qunids_ary);
				if (!$qunids) {
					$qunids = array('0');
				}
				$where[] = 'qunid IN (' . implode(',', $qunids) . ')';
			} else {
				if (!$manage) {
					$where[] = 'uid=' . $_G['uid'];
				}
				$where[] = 'status=' . intval($_GET['status']);
			}
		} else {
			$where[] = 'status=1';
		}
		if ($_GET['cat_id']) {
			$cat_id = intval($_GET['cat_id']);
			$pids = array($cat_id);
			$catinfo = C::t('#xigua_hf#xigua_hf_hangye')->get_childs_by_pids($cat_id);
			if ($catinfo) {
				foreach ($catinfo as $index => $item) {
					$pids[] = intval($item['id']);
				}
				if ($pids) {
					$tmpw = array();
					foreach ($pids as $index => $pid) {
						$tmpw[] = 'FIND_IN_SET(' . $pid . ', jineng)';
					}
					$where[] = '(' . implode(' OR ', $tmpw) . ')';
				}
			} else {
				$where[] = 'FIND_IN_SET(' . $cat_id . ', jineng)';
			}
		}
		if ($province = daddslashes($_GET['province'])) {
			$where[] = ' province=\'' . $province . '\' ';
		}
		if ($city = daddslashes($_GET['city'])) {
			$where[] = ' city=\'' . $city . '\' ';
		}
		if ($dist = daddslashes($_GET['dist'])) {
			$where[] = ' district=\'' . $dist . '\' ';
		}
		if ($_GET['not']) {
			$where[] = ' qunid !=' . intval($_GET['not']);
		}
		if ($_GET['tuijian']) {
			$where[] = ' tuijian=1 ';
		}
		if (is_numeric($_GET['keyword'])) {
			$where[] = ' (uid =' . intval($_GET['keyword']) . ') ';
		} else {
			if ($keyword = stripsearchkey($_GET['keyword'])) {
				$where[] = ' (name LIKE \'%' . $keyword . '%\' OR addr LIKE \'%' . $keyword . '%\' OR jieshao LIKE \'%' . $keyword . '%\' ) ';
			}
		}
		$viewtype = $_GET['viewtype'];
		if (!$viewtype) {
			$viewtype = $_GET['orderby'];
		}
		if ($viewtype == 'hy') {
			if ($page <= 1) {
				$list_all = C::t('#xigua_hf#xigua_hf_hangye')->list_all();
				C::t('#xigua_hf#xigua_hf_hangye')->init($list_all);
				$cat_tree_init = $cat_tree = C::t('#xigua_hf#xigua_hf_hangye')->get_tree_array(0);
			}
			if (!$hf_config['hy_num']) {
				$hf_config['hy_num'] = 3;
			}
			include template('xigua_hb:header_ajax');
			include template('xigua_hf:hylist');
			include template('xigua_hb:footer_ajax');
			dexit();
		}
		$orary = C::t('#xigua_hf#xigua_hf_qun')->get_order($viewtype);
		if ($manage) {
			$order_by = 'qunid desc';
		} else {
			$order_by = $orary['order_by'];
		}
		$field = $orary['field'];
		$list = C::t('#xigua_hf#xigua_hf_qun')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);
		include template('xigua_hb:header_ajax');
		include template('xigua_hf:qun_li');
		include template('xigua_hb:footer_ajax');
		break;
	case 'view':
		$qunid = intval($_GET['qunid']);
		$v = C::t('#xigua_hf#xigua_hf_qun')->fetch_by_id($qunid);
		$isme = $_G['uid'] && $_G['uid'] == $v['uid'];
		$navtitle = str_replace(array('{name}'), array($v['name']), $hf_config['subject']);
		$desc = strip_tags($v['jieshao']);
		$list_all1 = C::t('#xigua_hf#xigua_hf_hangye')->list_all(1, 'id');
		$allcats = array();
		foreach (explode(',', $v['jineng']) as $index => $item) {
			$allcats[] = array($list_all1[$list_all1[$item]['pid']], $list_all1[$item]);
		}
		$shoufei = floatval($v['shoufei']);
		$show = 1;
		if ($shoufei > 0) {
			$show = 0;
			if ($viewtels = C::t('#xigua_hf#xigua_hf_viewqun')->fetch_by_uid_ids($_G['uid'], array($qunid), 'qun')) {
				$show = 1;
			}
		}
		if ($v['status'] != 1 && !IS_ADMINID && $v['uid'] != $_G['uid']) {
			dheader('Location: ' . $SCRITPTNAME . '?id=xigua_hf&ac=my' . $urlext);
		}
		if ($_G['cache']['plugin']['xigua_hs'] && $v['shid']) {
			$v['sh'] = $sh = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_by_shid($v['shid'], 0);
			$sh['jieshao'] = cutstr(strip_tags($sh['jieshao']), 120);
		}
		$pingbi = 0;
		if ($_G['uid']) {
			$hbuser = C::t('#xigua_hb#xigua_hb_user')->fetch($_G['uid']);
			if ($hbuser['pingbi']) {
				$pingbi = 1;
			}
		}
		break;
	case 'getloc':
		if ($_GET['do'] == 'change') {
			$lng = floatval($_GET['lng']);
			$lat = floatval($_GET['lat']);
			$from = intval($_GET['from']);
			$to = intval($_GET['to']);
			if (!($ak = $_GET['ak'])) {
				$ak = $_G['cache']['plugin']['xigua_hf']['baidusrak'];
			}
			$ret = hb_curl('http://api.map.baidu.com/geoconv/v1/?coords=' . $lng . ',' . $lat . '&from=' . $from . '&to=' . $to . '&ak=' . $ak);
			$ret = json_decode($ret, 1);
			echo $ret['result'][0]['x'] . ',' . $ret['result'][0]['y'];
			exit(0);
		} elseif ($_GET['do'] == 'append') {
			if (submitcheck('formhash')) {
				$qun = DB::fetch_first('select qunid,shoufei from %t where qunid=%d', array('xigua_hf_qun', $qunid));
				if ($qun['shoufei'] <= 0) {
					if ($viewqunid = DB::result_first('select * from %t where uid=%d and pubid=%d and idtype=%s', array('xigua_hf_viewqun', $_G['uid'], $qunid, 'qunview'))) {
						DB::update('xigua_hf_viewqun', array('crts' => TIMESTAMP), array('id' => $viewqunid));
						$vid = $viewqunid . ':update';
					} else {
						$vid = DB::insert('xigua_hf_viewqun', array('uid' => $_G['uid'], 'crts' => TIMESTAMP, 'pubid' => $qunid, 'idtype' => 'qunview'), 1);
						C::t('#xigua_hf#xigua_hf_qun')->incr($qunid, 'zans');
					}
					hb_message($vid, 'success');
				} else {
					hb_message('0:shoufei', 'success');
				}
			}
		} elseif ($_GET['do'] == 'checklat') {
			$lat = floatval($_GET['lat']);
			$lng = floatval($_GET['lng']);
			$lngstr = $lng > 0 ? ' - ' . $lng : ' + ' . abs($lng);
			$field = 'qunid,fanwei, acos(cos((lng ' . $lngstr . ') * 0.01745329252) * cos((lat - ' . $lat . ') * 0.01745329252)) * 6371004 as distance';
			$rs = DB::fetch_first('select ' . $field . ' from %t where qunid=%d', array('xigua_hf_qun', $qunid));
			if ($rs && $rs['fanwei'] * 1000 >= $rs['distance']) {
				hb_message('ok', 'success');
			} else {
				hb_message(lang_hf('cantin1', 0) . $rs['fanwei'] . lang_hf('kmn', 0), 'error');
			}
		} elseif ($_GET['do'] == 'telpay') {
			if (submitcheck('formhash')) {
				$_GET['rl'] = $_SERVER['HTTP_REFERER'] ? $_SERVER['HTTP_REFERER'] : $_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hf&ac=view&qunid=' . $qunid . $urlext);
				$_GET['rl'] .= '&show=1';
				$qun = C::t('#xigua_hf#xigua_hf_qun')->fetch($qunid);
				$title = lang_hf('fufeijia', 0) . $qun['name'];
				$price = $qun['shoufei'] > 0 ? $qun['shoufei'] : '0.01';
				$order_id = C::t('#xigua_hb#xigua_hb_order')->init_order_id(0, $price, $title, 'common_hfjoin', array('data' => array('uid' => $_G['uid'], 'price' => $price, 'qunid' => $qunid), 'callback' => array('file' => 'source/plugin/xigua_hf/function.php', 'method' => 'hf_telpay_callback'), 'location' => $_GET['rl']));
				$rl = urlencode($_GET['rl']);
				$jumpurl = $SCRITPTNAME . '?id=xigua_hb&ac=pay&order_id=' . $order_id . '&rl=' . urlencode($_G['siteurl'] . ($SCRITPTNAME . '?id=xigua_hb&ac=mypub&rl=' . $rl));
				hb_message(lang_hb('tiaozhuan', 0), 'success', $jumpurl);
			}
		} else {
			$ret = hf_current_location($_GET['lat'], $_GET['lng']);
			if (is_array($ret)) {
				if ($_GET['checkst'] && $_G['cache']['plugin']['xigua_st']) {
					$geoinfo = hf_multi_diconv($ret[0]['address_component'], 'utf-8', CHARSET);
					if ($rs = DB::fetch_first('select `stid`,area3 from %t where area3<>\'\' AND `area3` IN (%n)', array('xigua_st', $geoinfo))) {
						hb_message(implode(',', $rs) . ',' . implode(',', $geoinfo), 'success');
					}
					if ($rs = DB::fetch_first('select `stid`,area2 from %t where area2<>\'\' AND `area2` IN (%n) AND area3=\'\'', array('xigua_st', $geoinfo))) {
						hb_message(implode(',', $rs) . ',' . implode(',', $geoinfo), 'success');
					}
					if ($rs = DB::fetch_first('select `stid`,area2 from %t where area1<>\'\' AND `area1` IN (%n) AND area2=\'\' AND area3=\'\'', array('xigua_st', $geoinfo))) {
						hb_message(implode(',', $rs) . ',' . implode(',', $geoinfo), 'success');
					}
					hb_message('error', 'error');
				}
				if ($_GET['checkallow'] && $config['areaallow']) {
					$areaallow = array_filter(explode("\n", trim($config['areaallow'])));
					foreach ($areaallow as $index => $item) {
						$areaallow[$index] = trim($item);
					}
					if ($areaallow) {
						$ar1 = hf_multi_diconv($ret[0]['address_component'], 'utf-8', CHARSET);
						if (!array_intersect($ar1, $areaallow)) {
							hb_message(lang_hb('notallowq1', 0) . implode(',', $ar1) . lang_hb('notallowq2', 0) . implode(',', $areaallow), 'error');
						}
					}
				}
				if ($_GET['geoauto']) {
					$geoinfo = hf_multi_diconv($ret[0]['address_component'], 'utf-8', CHARSET);
					if ($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['district']))) {
						hb_message($rs . ':dist=' . urlencode($rs), 'success');
					}
					if ($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['city']))) {
						hb_message($rs . ':city=' . urlencode($rs), 'success');
					}
					if ($rs = DB::result_first('select `name` from %t where `name`=%s', array('xigua_hb_district', $geoinfo['province']))) {
						hb_message($rs, 'success');
					}
					hb_message('error', 'error');
				}
				hb_message(json_encode($ret), 'success');
			} else {
				hb_message($ret, 'error');
			}
		}
		break;
	case 'checkyqm':
		if (submitcheck('formhash')) {
			$qun = C::t('#xigua_hf#xigua_hf_qun')->fetch($qunid);
			if ($qun['yqm'] == $_GET['yqmpwd']) {
				dsetcookie('yqm_' . $qunid, authcode($_GET['hxpwd'], 'ENCODE'), 86400);
				hb_message(lang_hf('yqm1', 0), 'success', 'reload');
			} else {
				hb_message(lang_hf('yqm2', 0), 'error');
			}
		}
		break;
	default:
		if (!checkmobile()) {
			include template('xigua_hb:index');
			exit(0);
		}
		if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_hf/include/c_' . $ac . '.php'))) {
			include DISCUZ_ROOT . ('source/plugin/xigua_hf/include/c_' . $ac . '.php');
		}
}
if ($_GET['mini'] == '11') {
	$navtitle = strip_tags($navtitle);
	$navtitle = $navtitle ? $navtitle : $config['tname'];
	if ($config['tnameshow']) {
		if ($navtitle != $config['tname']) {
			$navtitle = $config['tname'] . $navtitle;
		}
	}
	ob_end_clean();
	function_exists('ob_gzhandler') ? ob_start('ob_gzhandler') : ob_start();
	header('Content-type: application/json; charset=utf-8');
	echo json_encode(array(diconv($navtitle, CHARSET, 'utf-8')));
	exit(0);
}
if (!checkmobile()) {
	include template('xigua_hb:index');
	exit(0);
}
if (is_file(DISCUZ_ROOT . ('source/plugin/xigua_hf/template/touch/' . $ac . '.php'))) {
	include template('xigua_hf:' . $ac);
}