function hf_getlocation(callback) {
    if (typeof mag != 'undefined') {
        mag.getLocation(function (res) {
            callback(res);
        });
    } else if (typeof sq != 'undefined') {
        sq.getLocation(function (res) {
            callback(res);
        });
    } else if (typeof QFH5 != 'undefined') {
        QFH5.getLocation(function (state, data) {
            if (state == 1) {
                callback(data);
            } else {
                alert(data.error);
            }
        });
    } else if ((HB_INWECHAT && HB_MULTIUPLOAD) == 1) {
        wx.getLocation({
            type: 'gcj02', success: function (res) {
                callback(res);
            }, cancel: function (res) {
            }
        });
    } else {
        console.log('myapp');
        var geolocation = new qq.maps.Geolocation(mkey, "myapp");
        geolocation.getLocation(callback, function () {
        }, {timeout: 4000, failTipFlag: true});
    }
}

var saveLat = 0, saveLng = 0, lm=0;
$(document).on('click', '.hflistcat', function () {
    lm = 0;
    var that = $(this);
    if (that.data('needgeo')) {
        if (saveLat && saveLng) {
            hf_setlist(that, '&lat=' + saveLat + '&lng=' + saveLng);
        } else {
            hf_getlocation(function (position) {
                var lat = (position.latitude || position.lat), lng = (position.longitude || position.lng);
                saveLat = lat;
                saveLng = lng;
                hf_setlist(that, '&lat=' + saveLat + '&lng=' + saveLng);
            });
        }
    } else {
        hf_setlist(that, '');
    }
    if (that.data('save')) {
        var oldu = window.location.href.replace(/nav\=\w+\&/, '');
        var su = that.data('save');
        history.replaceState(null, '', oldu.replace(su + '&', '').replace('id=xigua', su + '&id=xigua'));
    }
});

function hf_setlist(that, ext) {
    if(lm===1){
        return false;
    }
    lm = 1;
    page = 1;
    loadingurl = window.location.href + '&' + that.data('query') + ext + '&ac=qun_li&inajax=1&page=';
    that.addClass('weui_bar__item_on').siblings().removeClass('weui_bar__item_on');
    DOAPPEND = 0;
    $.ajax({
        type: 'get', url: loadingurl + '' + page, dataType: 'xml', success: function (data) {
            lockIng = lm = 0;
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            $('#loading-show').addClass('hidden');
            if (!s) {
                $('#loading-show').addClass('hidden');
                $('#loading-none').removeClass('hidden');
                setTimeout(function () {
                    $('#loading-show').addClass('hidden');
                    $('#loading-none').removeClass('hidden');
                }, 300);
                $("#list").html(s);
                page = -1;
                return;
            }
            $("#list").html(s);
            page++;
        }, error: function () {
            lockIng = lm = 0;
        }
    });
}

$(document).on('click', '.jonnow', function () {
    var popup_wxqr = $("#popup_wxqr");
    var that = $(this);
    if (that.data('pb')) {
        $.alert(HFYBPB);
        return false;
    }
    if (that.data('needlat')) {
        hf_getlocation(function (position) {
            var lat = (position.latitude || position.lat), lng = (position.longitude || position.lng);
            $.ajax({
                type: 'GET',
                url: _APPNAME + '?id=xigua_hf&ac=getloc&do=checklat&inajax=1&qunid=' + that.data('id') + '&lat=' + lat + '&lng=' + lng,
                dataType: 'xml',
                success: function (data) {
                    if (null == data) {
                        tip_common('error|' + ERROR_TIP);
                        return false;
                    }
                    var s = data.lastChild.firstChild.nodeValue;
                    if (s.split('|')[1] === 'ok') {
                        if (that.data('qunzhuqr')) {
                            var nht = '<div class="div2"><img src="' + that.data('qunzhuqr') + '" /><p>' + QZEWM + '</p></div>';
                            nht += '<div class="div2">' + (that.data('guoqi') ? '<div class="choashi_txt">' + HFYGQ + '</div>' : '') + '<img src="' + that.data('wxqr') + '" /><p>' + QEWM + '</p></div>';
                            popup_wxqr.find('.footer_wxqr').html(nht);
                        } else {
                            popup_wxqr.find('.footer_wxqr').html((that.data('guoqi') ? '<div class="choashi_txt">' + HFYGQ + '</div>' : '') + '<img src="' + that.data('wxqr') + '" />');
                        }
                        if (that.data('kouling')) {
                            popup_wxqr.find('#klbox').html(QHUIFU + ' <em class="main_color">' + that.data('kouling') + '</em>');
                            popup_wxqr.find('.clickcopy2').attr('data-clipboard-text', that.data('kouling')).show();
                        }
                        popup_wxqr.find('.title').html(that.data('name'));
                        popup_wxqr.find('.clickcopy1').attr('data-clipboard-text', that.data('clipboard'));
                        if(that.data('qunzhuqr')){
                            popup_wxqr.popup();
                        }else{
                            $.alert($('.footer_middle').html());
                        }
                        hf_setView(that.data('id'));
                    } else {
                        tip_common(s);
                    }
                }
            });
        });
        return false;
    } else {
        if (that.data('qunzhuqr')) {
            var nht = '<div class="div2"><img src="' + that.data('qunzhuqr') + '" /><p>' + QZEWM + '</p></div>';
            nht += '<div class="div2">' + (that.data('guoqi') ? '<div class="choashi_txt">' + HFYGQ + '</div>' : '') + '<img src="' + that.data('wxqr') + '" /><p>' + QEWM + '</p></div>';
            popup_wxqr.find('.footer_wxqr').html(nht);
        } else {
            popup_wxqr.find('.footer_wxqr').html((that.data('guoqi') ? '<div class="choashi_txt">' + HFYGQ + '</div>' : '') + '<img src="' + that.data('wxqr') + '" />');
        }
        if (that.data('kouling')) {
            popup_wxqr.find('#klbox').html(QHUIFU + ' <em class="main_color">' + that.data('kouling') + '</em>');
            popup_wxqr.find('.clickcopy2').attr('data-clipboard-text', that.data('kouling')).show();
        }
        popup_wxqr.find('.title').html(that.data('name'));
        popup_wxqr.find('.clickcopy1').attr('data-clipboard-text', that.data('clipboard'));
        if(that.data('qunzhuqr')){
            popup_wxqr.popup();
            popup_wxqr.show();
            setTimeout(function () {
                popup_wxqr.show();
            }, 500);
        }else{
            $.alert($('.footer_middle').html());
        }
        hf_setView(that.data('id'));
    }
});
$(document).on('click', '.hf_jump', function () {
    hb_jump(_APPNAME + "?id=xigua_hf&ac=view&qunid=" + $(this).data('id') + _URLEXT);
});

function hf_getnext(id, name, datahref) {
    $('.sub_check a').removeClass('checked').removeClass('main_color');
    $('.sub_check a').parent().removeClass('checked').removeClass('main_color');
    $('#sub_check' + id).addClass('checked').addClass('main_color');
    $.ajax({
        type: 'get',
        url: _APPNAME + '?id=xigua_hb&ac=chosecity&province=' + $('.first_check+.checked').find('a').text() + '&name=' + name + '&ctid=' + id + '&datahref=' + encodeURIComponent(datahref) + '&inajax=1',
        dataType: 'xml',
        success: function (data) {
            if (null == data) {
                tip_common('error|' + ERROR_TIP);
                return false;
            }
            var s = data.lastChild.firstChild.nodeValue;
            $('.ajaxbox_cheker').html(s);
        }
    });
}

$(document).on('click', '#v_openlocation_ho', function () {
    var that = $(this);
    if ((HB_INWECHAT && HB_MULTIUPLOAD) == 1) {
        wx.openLocation({
            latitude: that.data('lat'),
            longitude: that.data('lng'),
            name: that.data('name'),
            address: that.data('addr'),
            scale: 14,
            infoUrl: window.location.href
        });
    } else if (GOOGLE) {
        window.location.href = _APPNAME + '?id=xigua_hf&ac=googleMap&lat=' + that.data('lat') + "&lng=" + that.data('lng');
    } else if (typeof BAIDUSDK != 'undefined') {
        window.location.href = '//api.map.baidu.com/marker?location=' + that.data('lat') + "," + that.data('lng') + '&title=' + that.data('name') + '&coord_type=gcj02&zoom=10&output=html&src=webapp.baidu.openAPIdemo&content=' + that.data('addr');
    } else {
        window.location.href = "//apis.map.qq.com/uri/v1/marker?marker=coord:" + that.data('lat') + "," + that.data('lng') + ";title:" + that.data('name') + ";addr:" + that.data('addr');
    }
    return false;
});
$(document).on('click', '.hf_paytel', function () {
    var that = $(this);
    if (that.data('needlat')) {
        hf_getlocation(function (position) {
            var lat = (position.latitude || position.lat), lng = (position.longitude || position.lng);
            $.ajax({
                type: 'GET',
                url: _APPNAME + '?id=xigua_hf&ac=getloc&do=checklat&inajax=1&qunid=' + that.data('id') + '&lat=' + lat + '&lng=' + lng,
                dataType: 'xml',
                success: function (data) {
                    if (null == data) {
                        tip_common('error|' + ERROR_TIP);
                        return false;
                    }
                    var s = data.lastChild.firstChild.nodeValue;
                    if (s.split('|')[1] === 'ok') {
                        hf_paytel(that.data('id'), that.data('pri'));
                    } else {
                        tip_common(s);
                    }
                }
            });
        });
        return false;
    } else {
        hf_paytel(that.data('id'), that.data('pri'));
    }
});

function hf_setView(id) {
    $.ajax({
        type: 'POST',
        url: _APPNAME + '?id=xigua_hf&ac=getloc&do=append&qunid=' + id,
        dataType: 'xml',
        data: {formhash: FORMHASH},
        success: function (data) {
            $.hideLoading();
        },
        error: function () {
            $.hideLoading();
        }
    });
}