<?php
/**
 *  Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function hf_refresh_callback($param){
    $info = $param['info'];
    $data = $info['data'];
    $qunid = $data['qunid'];

    $old_data = C::t('#xigua_hf#xigua_hf_qun')->fetch($qunid);

    $replace = array(
        'upts' => TIMESTAMP,
    );
    C::t('#xigua_hf#xigua_hf_qun')->update($qunid, $replace);

    return true;
}