<?php
/**
 *  Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢��wxiguabbs
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<SQL
CREATE TABLE IF NOT EXISTS `pre_xigua_hf_hangye` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `share_title` varchar(200) NOT NULL,
 `share_desc` varchar(200) NOT NULL,
 `share_pic` varchar(200) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255))
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS `pre_xigua_hf_qun` (
 `qunid` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(11) NOT NULL,
 `tuijian` int(11) NOT NULL,
 `status` int(11) NOT NULL COMMENT '-1:start 1:normal  -2:notpay',
 `name` varchar(80) NOT NULL,
 `jineng` varchar(200) NOT NULL,
 `logo` varchar(200) NOT NULL,
 `jineng_str` varchar(800) NOT NULL,
 `wxqr` varchar(200) NOT NULL,
 `qunzhuqr` varchar(200) NOT NULL,
 `qunzhuwx` varchar(100) NOT NULL,
 `shoufei` decimal(10,2) NOT NULL,
 `kouling` varchar(100) NOT NULL,
 `video` varchar(200) NOT NULL,
 `album` varchar(2000) NOT NULL,
 `jieshao` text NOT NULL,
 `video_cover` varchar(200) NOT NULL,
 `province` varchar(80) NOT NULL,
 `city` varchar(80) NOT NULL,
 `district` varchar(80) NOT NULL,
 `street` varchar(80) NOT NULL,
 `street_number` varchar(80) NOT NULL,
 `addr` varchar(500) NOT NULL,
 `lat` varchar(20) NOT NULL,
 `lng` varchar(20) NOT NULL,
 `fanwei` int(11) NOT NULL,
 `crts` int(11) NOT NULL,
 `upts` int(11) NOT NULL,
 `endts` int(11) NOT NULL,
 `digtype` varchar(1000) NOT NULL,
 `dig_startts` int(11) NOT NULL,
 `dig_endts` int(11) NOT NULL,
 `views` int(11) NOT NULL,
 `shares` int(11) NOT NULL,
 `stid` int(11) NOT NULL,
 `displayorder` int(11) NOT NULL,
 `payts` int(11) NOT NULL,
 `zans` int(11) NOT NULL,
 `shid` int(11) NOT NULL,
 `shname` varchar(200) NOT NULL,
 PRIMARY KEY (`qunid`),
 KEY `status` (`status`),
 KEY `lat` (`lat`),
 KEY `lng` (`lng`),
 KEY `province` (`province`),
 KEY `city` (`city`),
 KEY `district` (`district`),
 KEY `displayorder` (`displayorder`),
 KEY `views` (`views`),
 KEY `uid` (`uid`),
 KEY `dig_startts` (`dig_startts`),
 KEY `dig_endts` (`dig_endts`),
 KEY `endts` (`endts`),
 KEY `tuijian` (`tuijian`)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS `pre_xigua_hf_viewqun` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `uid` int(1) NOT NULL,
 `crts` int(11) NOT NULL,
 `pubid` int(11) NOT NULL,
 `idtype` varchar(10) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `uid` (`uid`),
 KEY `pubid` (`pubid`,`idtype`),
 KEY `crts` (`crts`)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS `pre_xigua_hf_nav` (
 `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
 `pid` int(10) unsigned NOT NULL,
 `name` varchar(80) NOT NULL,
 `icon` varchar(200) NOT NULL,
 `icon2` varchar(300) NOT NULL,
 `adimage` varchar(200) NOT NULL,
 `adlink` varchar(200) NOT NULL,
 `ts` int(11) unsigned NOT NULL,
 `o` int(11) unsigned NOT NULL,
 `pushtype` varchar(20) NOT NULL DEFAULT '',
 `price` decimal(10,2) unsigned NOT NULL DEFAULT '0.00',
 `tag` varchar(5000) NOT NULL,
 `placehoder` varchar(800) NOT NULL,
 `endtime` int(11) NOT NULL,
 `cat_ids` varchar(500) NOT NULL,
 `miao` int(11) NOT NULL DEFAULT '0',
 `qiang` int(11) NOT NULL DEFAULT '0',
 `goodindex` int(11) NOT NULL,
 `telprice` decimal(10,2) NOT NULL,
 `stids` varchar(2000) NOT NULL,
 `aprice` decimal(10,2) NOT NULL,
 `iconname` varchar(80) NOT NULL,
 `up` int(11) NOT NULL DEFAULT '0',
 `highlight` varchar(200) NOT NULL,
 `type` varchar(20) NOT NULL,
 PRIMARY KEY (`id`),
 KEY `o` (`o`),
 KEY `pid` (`pid`),
 KEY `cat_ids` (`cat_ids`(255)),
 KEY `goodindex` (`goodindex`),
 KEY `miao` (`miao`),
 KEY `stids` (`stids`(255)),
 KEY `type` (`type`)
) ENGINE=InnoDB;
SQL;
runquery($sql);

$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'xuzhi\'', array('xigua_hf_qun'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hf_qun` ADD `xuzhi` VARCHAR(120) NOT NULL;
ALTER TABLE `pre_xigua_hf_qun` ADD `btntext` VARCHAR(24) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'dl_status\'', array('xigua_hf_qun'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hf_qun` ADD `dl_status` INT(11) NOT NULL;
ALTER TABLE `pre_xigua_hf_qun` ADD `rand_kl` VARCHAR(100) NOT NULL;

SQL;
    runquery($sql);
}


$r2 = DB::fetch_first('SHOW COLUMNS FROM %t  where `Field`=\'yqm\'', array('xigua_hf_qun'), true);
if(!$r2){
    $sql =<<<SQL

ALTER TABLE `pre_xigua_hf_qun` ADD `yqm` VARCHAR(20) NOT NULL;

SQL;
    runquery($sql);
}


@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf_TC_UTF8.xml');

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/install.php');

