<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2015/4/15
 * Time: 11:15
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
include_once DISCUZ_ROOT.'source/plugin/xigua_hf/function.php';
echo "<link rel=\"stylesheet\" href=\"source/plugin/xigua_hb/static/css/admincp.css?1\" />";
$page = max(1, intval($_GET['page']));
$lpp = 2;
$start_limit = ($page - 1) * $lpp;
$cat__id = intval($_GET['cat__id']);
if($cat__id){
    $cat_indo = C::t('#xigua_hf#xigua_hf_hangye')->fetch_by_catid($cat__id);
}
$GLOBALS['needchild'] = 1;
if(1){
    if($_GET['formhash']==formhash() && $_GET['catid']){
        $ret = C::t('#xigua_hf#xigua_hf_hangye')->do_delete(intval($_GET['catid']));
        if($ret){
            cpmsg(
                lang_hf('succeed', 0),
                "action=plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_hangye&page=$page",
                'succeed'
            );
        }else{
            cpmsg(
                lang_hf('delcat_error', 0),
                "action=plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_hangye&page=$page",
                'error'
            );
        }
    }
    if(submitcheck('dosubmit')){
        if($new = $_GET['n']){
            $newrow = array();
            foreach ($new['name'] as $k => $v) {
                if(is_array($v)){
                    foreach ($v as $kk => $string) {
                        $newrow[] = array(
                            'pid'  => $k,
                            'name' => $string,
                            'o'    => $new['o'][$k][$kk],
                            'ts'   => TIMESTAMP,
                            'cat_ids'   => trim($new['cat_ids'][$k][$kk]),
                            'price'  => $new['price'][$k][$kk],
                            'telprice'  => $new['telprice'][$k][$kk],
                            'stids'  => $new['stids'][$k][$kk],
                        );
                    }
                } else {
                    $newrow[] = array(
                        'pid' => 0,
                        'name' => $v,
                        'o'  => $new['o'][$k],
                        'ts'   => TIMESTAMP,
                        'cat_ids'   => trim($new['cat_ids'][$k]),
                        'price'  => $new['price'][$k],
                        'telprice'  => $new['telprice'][$k],
                        'stids'  => $new['stids'][$k],
                    );
                }
            }
            foreach ($newrow as $value) {
                C::t('#xigua_hf#xigua_hf_hangye')->insert($value);
            }
        }

        if($_FILES['icon'] || $_FILES['adimage'] || $_FILES['share_pic']){
            $icons = hb_uploads($_FILES['icon']);
            $adimage = hb_uploads($_FILES['adimage']);
            $share_pic = hb_uploads($_FILES['share_pic']);
        }
        if($r = $_GET['r']){
            foreach ($r['name'] as $cid => $name) {
                $data = array();

                $data['name']   = $name;
                $data['o']      = $r['o'][$cid];
                $data['cat_ids']= $r['cat_ids'][$cid];
                $data['adlink'] = $r['adlink'][$cid];
                $data['price']  = $r['price'][$cid];
                $data['telprice']  = $r['telprice'][$cid];
                $data['stids']  = $r['stids'][$cid];
                $data['tag']    = trim($r['tag'][$cid]);
                $data['placehoder']    = trim($r['placehoder'][$cid]);

                $data['share_title']    = trim($r['share_title'][$cid]);
                $data['share_desc']    = trim($r['share_desc'][$cid]);

                if($_FILES['adimage']['error'][$cid] === UPLOAD_ERR_OK){
                    $data['adimage']= ($adimage[$cid]['errno'] == 0 ? $adimage[$cid]['error'] : '');
                }
                if($_FILES['share_pic']['error'][$cid] === UPLOAD_ERR_OK){
                    $data['share_pic']= ($share_pic[$cid]['errno'] == 0 ? $share_pic[$cid]['error'] : '');
                }
                if($_FILES['icon']['error'][$cid] === UPLOAD_ERR_OK) {
                    $data['icon'] = ($icons[$cid]['errno'] == 0 ? $icons[$cid]['error'] : '');
                }

                C::t('#xigua_hf#xigua_hf_hangye')->update($cid, $data);
            }
        }
        if($delimg = $_GET['delimg']){
            foreach ($delimg as $catid_ => $fields_) {
                $data_ = array();
                if($fields_['icon'] == 1){
                    $data_['icon'] = '';
                }
                if($fields_['adimage'] == 1){
                    $data_['adimage'] = '';
                }
                if($fields_['share_pic'] == 1){
                    $data_['share_pic'] = '';
                }
                if($data_){
                    C::t('#xigua_hf#xigua_hf_hangye')->update(intval($catid_), $data_);
                }
            }
        }
        cpmsg(
            lang_hf('succeed', 0),
            "action=plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_hangye&page=$page",
            'succeed'
        );
    }

    $listinfo = C::t('#xigua_hf#xigua_hf_hangye')->fetch_all_by_page($start_limit, $lpp);
    C::t('#xigua_hf#xigua_hf_hangye')->init($listinfo);
    $list = C::t('#xigua_hf#xigua_hf_hangye')->get_tree_array(0);

    $totalcount = C::t('#xigua_hf#xigua_hf_hangye')->count_by_page();
    $multipage = multi(
        $totalcount, $lpp, $page,
        ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_hangye&page=$page"
    );

    showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_hangye&page=$page", 'enctype');

    $hb_cats = C::t('#xigua_hb#xigua_hb_cat')->list_all(1);

    $hb_catsting = '';
    foreach ($hb_cats as $index => $hb_cat) {
        $hb_catsting.= "[{$hb_cat['name']}: <b>{$hb_cat['id']}</b>] ";
    }
    ?>
    <style>
        .imgi{height:20px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}
        .short{width:150px}
        .td23 input{width:120px!important;}
        .intit{padding-top:3px}
        .abtn{padding:2px 6px;background: #ff7d2d;color: #fff;}
    </style>
    <div style="height:30px;line-height:30px;padding-left:25px">
        <a href="javascript:;" onclick="show_all()"><?php echo cplang('show_all')?></a> | <a href="javascript:;" onclick="hide_all()"><?php echo cplang('hide_all')?></a>
    </div>
    <table class="tb tb2 ">
        <tbody>
        <tr class="header">
            <th>&nbsp;</th>
            <th><?php lang_hf('hangye_id')?></th>
            <th><?php lang_hf('order')?></th>
            <th><?php lang_hf('cat_name')?></th>
            <th><?php lang_hf('cat_icon')?></th>
            <th><?php lang_hf('caozuo')?></th>
        </tr>
        </tbody>
        <?php foreach ($list as $v) { ?>
            <tbody>
            <tr class="hover">
                <td class="td25" onclick="toggle_group('group_<?php echo $v['id']?>', $('a_group_<?php echo $v['id']?>'))"><a href="javascript:;" id="a_group_<?php echo $v['id']?>">[-]</a></td>
                <td class="td25"><?php echo $v['id']?></td>
                <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $v['id']?>]" value="<?php echo $v['o']?>" /></td>
                <td class="td23">
                    <div class="parentboard"><input type="text" name="r[name][<?php echo $v['id']?>]" value="<?php echo $v['name']?>" class="txt" /></div>
                </td>
                <td>
                    <input class="short" name="icon[<?php echo $v['id']?>]" type="file" />
                    <?php if($v['icon']){?>
                        <span class="sp">
     <img class="imgi" src="<?php echo $v['icon']?>" onmouseover="$('icon<?php echo $v['id']?>').style.display='block'" onmouseout="$('icon<?php echo $v['id']?>').style.display='none'" />
     <img id="icon<?php echo $v['id']?>" src="<?php echo $v['icon']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][icon]" value="1" /><?php lang_hf('delshort')?></label>
 </span>
                    <?php }?>
                </td>
                <td>
                    <div>
                        <div class="intit"><?php lang_hb('lbfxbt')?> : <input type="text" name="r[share_title][<?php echo $v['id']?>]" value="<?php echo $v['share_title']?>" class="txt" /></div>
                        <div class="intit"><?php lang_hb('lbfxms')?> : <input type="text" name="r[share_desc][<?php echo $v['id']?>]" value="<?php echo $v['share_desc']?>" class="txt" /></div>
                        <div class="intit"><?php lang_hb('lbfxtp')?> :
                            <input class="short"  name="share_pic[<?php echo $v['id']?>]" type="file" /><br>
                            <?php if($v['share_pic']){?>
                                <span class="sp">
    <img class="imgi" src="<?php echo $v['share_pic']?>" onmouseover="$('sharep<?php echo $v['id']?>').style.display='block'" onmouseout="$('sharep<?php echo $v['id']?>').style.display='none'"  />
    <img id="sharep<?php echo $v['id']?>" src="<?php echo $v['share_pic']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][share_pic]" value="1" /><?php lang_hb('delshort')?></label>
</span>
                            <?php }?>
                        </div>
                    </div>

                    <div class="intit">
                        <?php lang_hf('cat_ad')?> : <input type="text" placeholder="http://" class="txt short" name="r[adlink][<?php echo $v['id']?>]" value="<?php echo $v['adlink'] ? $v['adlink'] : ''; ?>" />
                    </div>
                    <div class="intit">
                        <?php lang_hf('cat_ad2')?> :
                        <span class="outinput"><input class="short"  name="adimage[<?php echo $v['id']?>]" type="file" /></span>
                        <?php if($v['adimage']){?>
                            <span class="sp">
    <img class="imgi" src="<?php echo $v['adimage']?>" onmouseover="$('ad<?php echo $v['id']?>').style.display='block'" onmouseout="$('ad<?php echo $v['id']?>').style.display='none'"  />
    <img id="ad<?php echo $v['id']?>" src="<?php echo $v['adimage']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $v['id']?>][adimage]" value="1" /><?php lang_hb('delshort')?></label>
</span>
                        <?php }?>
                    </div>
                </td>
                <td>
                    <a class="abtn" href="javascript:;" onclick="return _delid(<?php echo $v['id']?>,'<?php echo str_replace('&#039;', '', $v['name'])?>') "><?php lang_hf('del')?></a>
                </td>
            </tr>
            </tbody>
            <tbody id="group_<?php echo $v['id']?>">
            <?php foreach ($v['child'] as $c) { ?>
                <tr class="hover">
                    <td class="td25"></td>
                    <td class="td25"><?php echo $c['id']?></td>
                    <td class="td25"><input type="text" class="txt" name="r[o][<?php echo $c['id']?>]" value="<?php echo $c['o']?>" /></td>
                    <td class="td23">
                        <div class="board">
                            <input type="text" name="r[name][<?php echo $c['id']?>]" value="<?php echo $c['name']?>" class="txt" />
                        </div>
                    </td>
                    <td>
                        <input class="short" name="icon[<?php echo $c['id']?>]" type="file" />
                        <?php if($c['icon']){?>
                            <span class="sp">
     <img class="imgi" src="<?php echo $c['icon']?>" onmouseover="$('icon<?php echo $c['id']?>').style.display='block'" onmouseout="$('icon<?php echo $c['id']?>').style.display='none'" />
     <img id="icon<?php echo $c['id']?>" src="<?php echo $c['icon']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $c['id']?>][icon]" value="1" /><?php lang_hf('delshort')?></label>
 </span>
                        <?php }?>
                    </td>
                    <td>
                        <div>
                            <div class="intit"><?php lang_hb('lbfxbt')?> : <input type="text" name="r[share_title][<?php echo $c['id']?>]" value="<?php echo $c['share_title']?>" class="txt" /></div>
                            <div class="intit"><?php lang_hb('lbfxms')?> : <input type="text" name="r[share_desc][<?php echo $c['id']?>]" value="<?php echo $c['share_desc']?>" class="txt" /></div>

                            <div class="intit"><?php lang_hb('lbfxtp')?> :
                                <input class="short"  name="share_pic[<?php echo $c['id']?>]" type="file" /><br>
                                <?php if($c['share_pic']){?>
                                    <span class="sp">
    <img class="imgi" src="<?php echo $c['share_pic']?>" onmouseover="$('sharep<?php echo $c['id']?>').style.display='block'" onmouseout="$('sharep<?php echo $c['id']?>').style.display='none'"  />
    <img id="sharep<?php echo $c['id']?>" src="<?php echo $c['share_pic']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $c['id']?>][share_pic]" value="1" /><?php lang_hb('delshort')?></label>
</span>
                                <?php }?>
                            </div>
                            <div class="intit">
                                <?php lang_hf('cat_ad')?> : <input type="text" placeholder="http://" class="txt short" name="r[adlink][<?php echo $c['id']?>]" value="<?php echo $c['adlink'] ? $c['adlink'] : ''; ?>" />
                            </div>
                            <div class="intit">
                                <?php lang_hf('cat_ad2')?> :
                                <span class="outinput"><input class="short"  name="adimage[<?php echo $c['id']?>]" type="file" /></span>
                                <?php if($c['adimage']){?>
                                    <span class="sp">
    <img class="imgi" src="<?php echo $c['adimage']?>" onmouseover="$('ad<?php echo $c['id']?>').style.display='block'" onmouseout="$('ad<?php echo $c['id']?>').style.display='none'"  />
    <img id="ad<?php echo $c['id']?>" src="<?php echo $c['adimage']?>"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[<?php echo $c['id']?>][adimage]" value="1" /><?php lang_hb('delshort')?></label>
</span>
                                <?php }?>
                            </div>
                        </div>
                    </td>
                    <td>
                        <a class="abtn" href="javascript:;" onclick="return _delid(<?php echo $c['id']?>, '<?php echo str_replace('&#039;', '', $c['name'])?>') "><?php lang_hf('del')?></a>
                    </td>
                </tr>
                <?php
            }
            ?>
            </tbody>


            <tbody>
            <tr>
                <td></td>
                <td colspan="4">
                    <div class="lastboard">
                        <a href="javascript:;" onclick="addrow(this, 1, <?php echo $v['id']?>)" class="addtr"><?php lang_hf('ad_child_cat')?></a>
                    </div></td>
                <td>&nbsp;</td>
            </tr>
            </tbody>
        <?php }?>

        <tbody>
        <tr>
            <td>&nbsp;</td>
            <td colspan="99"><div>
                    <a href="javascript:;" onclick="addrow(this, 0)" class="addtr"><?php lang_hf('ad_new_cat')?></a>
                </div></td>
        </tr>
        <?php
        if($multipage){
            showtablerow('', 'colspan="99"', $multipage);
        }
        showsubmit('dosubmit', 'submit', 'td');
        ?>
        </tbody>
    </table>
    </form>
    <script>
        var rowtypedata = [
            [
                [1, ''],
                [1, ''],
                [1,'<input type="text" class="txt" name="n[o][]" value="0" />', 'td25'],
                [5,'<div><input name="n[name][]" value="<?php lang_hf('new_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hf('del')?></a></div>']
            ],
            [
                [1, ''],
                [1, ''],
                [1,'<input type="text" class="txt" name="n[o][{1}][]" value="0" />', 'td25'],
                [5,'<div class="board"><input name="n[name][{1}][]" value="<?php lang_hf('child_cat_name')?>" size="20" type="text" class="txt" /><a href="javascript:;" class="deleterow" onClick="deleterow(this)"><?php lang_hf('del')?></a></div>']
            ]
        ];
        function _delid(id, name){
            if(confirm('<?php lang_hf('del_confirm')?>' + name + '?')){
                window.location.href = "<?php echo ADMINSCRIPT."?action=plugins&operation=config&do=$pluginid&identifier=xigua_hf&pmod=admin_hangye&page=$page&del=1&formhash=".FORMHASH.'&catid='?>"+id;
            }
        }
    </script>
<?php } ?>