<?php
/**
 *  Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1 ΢�� wxiguabbs
 * Date: 2019
 * Time: 17:30
 */
if(!defined('IN_DISCUZ') || !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

$sql = <<<EOT
DROP TABLE pre_xigua_hf_hangye;
DROP TABLE pre_xigua_hf_qun;
DROP TABLE pre_xigua_hf_viewqun;
DROP TABLE pre_xigua_hf_nav;
EOT;
runquery($sql);

$cachenames = array();
$cacherows = DB::fetch_all('select cname from '.DB::table('common_syscache').' where cname like \'hbIdist%\' or cname like \'qun_view_%\' or cname like \'qun_tn_%\' ');
foreach ($cacherows as $index => $item) {
    $cachenames[$item['cname']] = $item['cname'];
}
if($cachenames) {
    C::t('common_syscache')->delete($cachenames);
}

$finish = TRUE;

@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf_SC_GBK.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf_SC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf_TC_BIG5.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/discuz_plugin_xigua_hf_TC_UTF8.xml');
@unlink(DISCUZ_ROOT . './source/plugin/xigua_hf/install.php');

xwbhe_delall(DISCUZ_ROOT . "./source/plugin/xigua_hf");
@rmdir(DISCUZ_ROOT . "./source/plugin/xigua_hf");


function xwbhe_delall($directory, $empty = false) {
    if(substr($directory,-1) == "/") {
        $directory = substr($directory,0,-1);
    }
    if(!file_exists($directory) || !is_dir($directory)) {
        return false;
    } elseif(!is_readable($directory)) {
        return false;
    } else {
        @$directoryHandle = opendir($directory);

        while ($contents = @readdir($directoryHandle)) {
            if($contents != '.' && $contents != '..') {
                $path = $directory . "/" . $contents;

                if(is_dir($path)) {
                    @xwbhe_delall($path);
                } else {
                    @unlink($path);
                }
            }
        }
        @closedir($directoryHandle);
        if($empty == false) {
            if(!@rmdir($directory)) {
                return false;
            }
        }
        return true;
    }
}