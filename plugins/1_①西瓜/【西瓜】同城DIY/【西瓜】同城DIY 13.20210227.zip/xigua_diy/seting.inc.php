<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if(!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}
include DISCUZ_ROOT.'source/plugin/xigua_diy/init.php';
$diy_config = xigua_diyc::config();

$app_url = 'https://dism.taobao.com/?@xigua_diy.plugin';

showtableheader(
    xigua_diyc::l('manager', 0) .
    '<a style="position:absolute;right:10px;color:red;font-weight:bold" href="'.$app_url.'">'.xigua_diyc::l('card_more', 0).'</a>',
    '','style="position:relative"'
);
showtablerow('class="header"', array(), array(
    xigua_diyc::l('card_name',0),
    xigua_diyc::l('card_desc',0),
    xigua_diyc::l('status',0),
));
foreach($diy_config as $k => $v){
    showtablerow('', array(), array($v['modulename'], $v['introduce'],
        xigua_diyc::l('installed',0),
    ));
}
showtablefooter(); /*dism _ taobao _ com*/
