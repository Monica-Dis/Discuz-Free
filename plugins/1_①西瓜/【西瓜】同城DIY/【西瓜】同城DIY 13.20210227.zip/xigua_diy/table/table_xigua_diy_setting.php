<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_diy_setting extends discuz_table
{

    public function __construct()
    {
        $this->_table = 'xigua_diy_setting';
        $this->_pk = 'id';

        parent::__construct(); /*dism - taobao - com*/
    }

    public function list_all($pid)
    {
        $data = array();
        $query = DB::query('SELECT * FROM %t WHERE pid=%d ORDER BY displayorder ASC, id ASC', array($this->_table, $pid));
        while ($value = DB::fetch($query)) {
            $data[ $value['type'] . '_' . $value[ $this->_pk ] ] = $value;
        }

        return $data;
    }
}