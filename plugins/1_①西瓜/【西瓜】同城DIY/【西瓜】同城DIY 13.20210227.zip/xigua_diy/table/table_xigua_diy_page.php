<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

class table_xigua_diy_page extends discuz_table
{
    public $setting_table;

    public function __construct()
    {
        $this->_table = 'xigua_diy_page';
        $this->setting_table = 'xigua_diy_setting';
        $this->_pk = 'pid';

        parent::__construct(); /*dism - taobao - com*/
    }

    public function multi_delete($ids)
    {
        if (empty($ids)) {
            return FALSE;
        }
        $ids = dintval($ids, TRUE);

        DB::query("DELETE FROM %t WHERE $this->_pk IN (" . dimplode($ids) . ')', array($this->_table));
        DB::query("DELETE FROM %t WHERE $this->_pk IN (" . dimplode($ids) . ')', array($this->setting_table));

        return TRUE;
    }
}