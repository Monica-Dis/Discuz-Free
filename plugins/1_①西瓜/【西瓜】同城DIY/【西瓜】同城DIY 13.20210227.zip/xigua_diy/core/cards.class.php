<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}

/**
 * Class xigua_diyc
 */
class xigua_diyc
{
    public static $diy_configs;

    /**
     * @param bool $only_open
     * @return mixed
     */
    public static function config($only_open = true)
    {
        if(isset(self::$diy_configs[$only_open])){
            return self::$diy_configs[$only_open];
        }

        global $_G;
        $cache_key = 'xigua_diy_cache';

        $diy_config = self::init_config();
        /*if(($_G['adminid'] > 0 && $_GET['diy'] == 'yes') || defined('IN_ADMINCP')){
            self::clearfromcache($cache_key);
            $diy_config = self::init_config();
        }else{
            $diy_config = self::readfromcache($cache_key, '', 86400000);
            if(!$diy_config){
                $diy_config = self::init_config();
                self::writetocache($diy_config, $cache_key);
            }
        }*/

        if($only_open){
            foreach ($diy_config as $k => $v) {
                if(!$v['open']){
                    unset($diy_config[$k]);
                }
            }
        }
        self::$diy_configs[$only_open] = $diy_config;
        return self::$diy_configs[$only_open];
    }

    public static function init_config(){
        $data = array();
        $cards_root = DISCUZ_ROOT . 'source/plugin/xigua_diy/template/cards';
        $dh  = opendir($cards_root);
        while (false !== ($filename = readdir($dh))) {
            if($filename != '.' && $filename != '..'){
                $diy_config_file = $cards_root ."/$filename/config.php";
                $data[$filename] = include $diy_config_file;
            }
        }
        return $data;
    }

    /**
     * @param string $lang
     * @param int $echo
     * @return bool
     */
    public static function l($lang = '', $echo = 1)
    {
        static $langs;
        $langs[$lang] = isset($langs[$lang]) ? $langs[$lang] : lang('plugin/xigua_diy', $lang);
        if($echo){
            echo $langs[$lang];
            return TRUE;
        }else{
            return $langs[$lang];
        }
    }

    public static function upload($file_data, $imgtype = array('.gif', '.jpg', '.jpeg', '.png',), $dir = 'source/plugin/xigua_diy/upload/')
    {
        if(is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/common.php')){
            include_once DISCUZ_ROOT.'source/plugin/xigua_hb/common.php';
            global $config, $_G;
            $config = $_G['cache']['plugin']['xigua_hb'];
            $config['shuiyin'] = 0;
            return hb_upload($file_data, 'source/plugin/xigua_hb/pics/');
        }else{
            global $_G;
            $errors = array(
                UPLOAD_ERR_OK         => self::l('UPLOAD_ERR_OK',        0),
                UPLOAD_ERR_INI_SIZE   => self::l('UPLOAD_ERR_INI_SIZE',  0),
                UPLOAD_ERR_FORM_SIZE  => self::l('UPLOAD_ERR_FORM_SIZE', 0),
                UPLOAD_ERR_PARTIAL    => self::l('UPLOAD_ERR_PARTIAL',   0),
                UPLOAD_ERR_NO_FILE    => self::l('UPLOAD_ERR_NO_FILE',   0),
                UPLOAD_ERR_NO_TMP_DIR => self::l('UPLOAD_ERR_NO_TMP_DIR',0),
                UPLOAD_ERR_CANT_WRITE => self::l('UPLOAD_ERR_CANT_WRITE',0),
                99                    => self::l('ONLY_IMAGE_ALLOW',     0),
            );
            $error = $file_data['error'];
            if($error != UPLOAD_ERR_OK){
                return array(
                    'errno' => $error,
                    'error' => $errors[$error]
                );
            }

            $type = '.'.addslashes(strtolower(substr(strrchr($file_data['name'], '.'), 1, 10)));
            $t = array_search($type, $imgtype);
            $filetype = $imgtype[$t];
            if($t === false || ! $filetype) {
                return array(
                    'errno' => 99,
                    'error' => $errors[99]
                );
            }

            $dir .= date('Ym').'/'.date('d').'/';
            dmkdir($dir);
            $file_attach = $dir. uniqid('xgp'.time()) . $filetype;
            $saved_file = DISCUZ_ROOT . $file_attach;

            if(is_uploaded_file($file_data['tmp_name'])){
                if(
                    @copy($file_data['tmp_name'], $saved_file) ||
                    @move_uploaded_file($file_data['tmp_name'], $saved_file)
                ){
                    @unlink($file_data['tmp_name']);
                    return array(
                        'errno' => 0,
                        'error' => $_G['siteurl'] . $file_attach
                    );
                }else{
                    return array(
                        'errno' => UPLOAD_ERR_CANT_WRITE,
                        'error' => $errors[UPLOAD_ERR_CANT_WRITE]
                    );
                }
            }
            return array(
                'errno' => UPLOAD_ERR_NO_FILE,
                'error' => $errors[UPLOAD_ERR_NO_FILE]
            );
        }
    }

    /**
     * @param $card
     * @param bool $parse
     * @return mixed
     */
    public static function run($card, $parse = false)
    {
        $diy_config = self::config(true);

        $type  = $card['type'];
        $tpl   = $diy_config[$type]['tpl'];

        $card['var'] = $card['value'] = unserialize($card['value']);
        $card['hide'] = 0;

        if(!is_file(DISCUZ_ROOT . 'source/plugin/xigua_diy/template/cards/'.$type.'/process.php')){
            return array();
        }
        include_once DISCUZ_ROOT . 'source/plugin/xigua_diy/template/cards/'.$type.'/process.php';
        $function = 'process_'.$type;
        $card = $function($card);

        if($parse && !$card['hide'] && $card['value']) {
            $card['html'] = xigua_parser::parse_string($tpl, $card['var']);
        }
        return $card;
    }

    public static function block($card, $module = 'forum')
    {
        $scripts = array('threadhot', 'threadnew', 'threaddigest', 'threadstick', 'threadspecified',);
        if (!in_array($card['var']['script'], $scripts)) {
            $card['var']['script'] = 'threadhot';
        }
        if($card['var']['script'] == 'threaddigest'){
            $card['var']['param']['digest'] = array(1,2,3);
        }
        if($card['var']['script'] == 'threadstick'){
            $card['var']['param']['stick'] = array(1,2,3);
        }

        $class_name = 'block_' . $card['var']['script'];
        require_once libfile($class_name, 'class/block/'.$module);
        $card['block_class'] = new $class_name();
        return $card;
    }

    public static function sort_by_tids($data, $param)
    {
        $threads = array();
        if($param['tids']){
            $tmp = array();
            foreach ($data['data'] as $thread) {
                $tmp[$thread['id']] = $thread;
            }
            $tids = array_filter(explode(',', $param['tids']));
            foreach ($tids as $tid) {
                if($tmp[$tid]){
                    $threads[] = $tmp[$tid];
                }
            }
        }else{
            $threads = $data['data'];
        }

        return $threads;
    }

    /**
     * @param $tid
     * @return string
     */
    public static function thread_link($tid){
        return "forum.php?mod=viewthread&tid=$tid";
    }

    public static function get_picurl($pic, $thumb = 0){
        global $_G;

        if(in_array(strtolower(substr($pic, 0, 6)), array('http:/', 'https:', 'ftp://')))
        {
            return $pic;
        }
//        $_G['cache']['plugin']['xigua_diy']['remote'] = 'http://zajihe.oss-cn-qingdao.aliyuncs.com/';
        if($_G['cache']['plugin']['xigua_diy']['remote'])
        {
            return rtrim($_G['cache']['plugin']['xigua_diy']['remote'], '/') . '/' . $pic;
        }

        $picurl =  $_G['setting']['attachurl'].$pic;
        if($thumb){
            $picurl = getimgthumbname($picurl);
        }
        if (!in_array(strtolower(substr($picurl, 0, 6)), array('http:/', 'https:', 'ftp://')))
        {
            $pic = $_G['siteurl'].$picurl;
        }
        else
        {
            $pic = $picurl;
        }
        return $pic;
    }

    public static function styles()
    {
        $styles = array();
        $cards_root = DISCUZ_ROOT . 'source/plugin/xigua_diy/static/css/style';
        $dh  = opendir($cards_root);
        while (false !== ($filename = readdir($dh))) {
            if($filename != '.' && $filename != '..'){
                $styles[] = str_replace('.css', '', $filename);
            }
        }
        return $styles;
    }

    public static function get_style($style){
        global $_G;
        return $_G['siteurl'] .'source/plugin/xigua_diy/static/css/style/'.$style.'.css?'.VERHASH;
    }

    public static function writetocache($array = array(), $script = 'xigua_diy_cache', $prefix = '')
    {
        global $_G;
        $datas = array(
            'ts' => $_G['timestamp'],
            'data'     => $array
        );
        savecache($prefix.$script, $datas);
    }

    public static function readfromcache($script = 'xigua_diy_cache', $prefix = '', $expire = 0)
    {
        global $_G;
        $expire = $expire ? $expire : $_G['cache']['plugin']['xigua_diy']['expire'];


        $_key = $prefix.$script;
        loadcache($_key);
        $ret = $_G['cache'][$_key]['data'];
        if($_G['timestamp']> $_G['cache'][$_key]['ts']+ $expire){
            $ret = array();
        }
        return $ret;
    }

    public static function clearfromcache($script = 'xigua_diy_cache', $prefix = '')
    {
        savecache($prefix.$script, array());
        return TRUE;
    }
}