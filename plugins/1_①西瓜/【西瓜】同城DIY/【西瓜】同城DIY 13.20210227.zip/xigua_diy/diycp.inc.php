<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ') && !defined('IN_ADMINCP')) {
    exit('Access Denied');
}

include DISCUZ_ROOT . 'source/plugin/xigua_diy/init.php';

$app_url = 'https://dism.taobao.com/?@xigua_diy.plugin';
$ahead = $_G['siteurl'] . 'plugin.php?id=xigua_diy';
$page = max(1, intval(getgpc('page')));
$lpp = 15;
$start_limit = ($page - 1) * $lpp;

$styles = xigua_diyc::styles();

function diy_upload($file_data, $dir = 'source/plugin/xigua_diy/upload/'){
    $imgtype = array('.jpg', '.jpeg', '.png', '.gif','.JPG', '.JPEG', '.PNG', '.GIF');
    $errors = array(
        UPLOAD_ERR_OK         => lang_diy('UPLOAD_ERR_OK',  0),
        UPLOAD_ERR_INI_SIZE   => lang_diy('UPLOAD_ERR_INI_SIZE',  0),
        UPLOAD_ERR_FORM_SIZE  => lang_diy('UPLOAD_ERR_FORM_SIZE', 0),
        UPLOAD_ERR_PARTIAL    => lang_diy('UPLOAD_ERR_PARTIAL',   0),
        UPLOAD_ERR_NO_FILE    => lang_diy('UPLOAD_ERR_NO_FILE',   0),
        UPLOAD_ERR_NO_TMP_DIR => lang_diy('UPLOAD_ERR_NO_TMP_DIR',0),
        UPLOAD_ERR_CANT_WRITE => lang_diy('UPLOAD_ERR_CANT_WRITE',0),
        99                    => lang_diy('ONLY_IMAGE_ALLOW',   0),
    );
    $error = $file_data['error'];
    if($error != UPLOAD_ERR_OK){
        return array(
            'errno' => $error, 'error' => $errors[$error]
        );
    }
    $type = '.'.addslashes(strtolower(substr(strrchr($file_data['name'], '.'), 1, 10)));
    if($type == '.'){
        switch ($file_data['type']){
            case 'image/gif':
                $type = '.gif';
                break;
            case 'image/png':
            case 'image/x-png':
                $type = '.png';
                break;
            default:
                $type = '.jpg';
                break;
        }
    }
    $t = array_search($type, $imgtype);
    $filetype = $imgtype[$t];
    $file_data['type'] = strtolower($file_data['type']);
    if($t === false || ! $filetype ||!in_array(strtolower($file_data['type']), array('image/jpg', 'image/jpeg', 'image/pjpeg', 'image/gif', 'image/png', 'image/x-png','application/octet-stream'))) {
        return array(
            'errno' => 99,
            'error' => $errors[99].$file_data['type'].'_'.$t.'_'.$filetype
        );
    }
    if(!$dir){
        $dir = 'source/plugin/xigua_diy/upload/';
    }
    dmkdir($dir);
    $filena = uniqid(time()).$filetype;
    $file_attach = $dir. $filena;
    $saved_file = DISCUZ_ROOT . $file_attach;
    if(is_uploaded_file($file_data['tmp_name'])){
        if(@copy($file_data['tmp_name'], $saved_file) || @move_uploaded_file($file_data['tmp_name'], $saved_file)){
            @unlink($file_data['tmp_name']);
            global $_G,$config;
            $imgurl = $GLOBALS['_G']['siteurl'] .$file_attach;
            $config = $GLOBALS['config'];
            return array('errno' => 0,'error' => $imgurl);
        }else{
            return array('errno' => UPLOAD_ERR_CANT_WRITE,'error' => $errors[UPLOAD_ERR_CANT_WRITE]);
        }
    }
    return array(
        'errno' => UPLOAD_ERR_NO_FILE,
        'error' => $errors[UPLOAD_ERR_NO_FILE]
    );
}
function diy_uploads($file_data){
    $ret = $data = array();
    foreach ($file_data['error'] as $k => $error) {
        $data[$k]['name']   = $file_data['name'][$k];
        $data[$k]['type']   = $file_data['type'][$k];
        $data[$k]['tmp_name'] = $file_data['tmp_name'][$k];
        $data[$k]['error']  = $file_data['error'][$k];
        $data[$k]['size']   = $file_data['size'][$k];
    }
    foreach ($data as $k => $row) {
        if(!is_array($row['error'])){
            $ret[$k] = diy_upload($row);
        }else{
            $item = array();
            foreach ($row['error'] as $_k => $_error) {
                $item[$_k]['name']   = $row['name'][$_k];
                $item[$_k]['type']   = $row['type'][$_k];
                $item[$_k]['tmp_name'] = $row['tmp_name'][$_k];
                $item[$_k]['error']  = $row['error'][$_k];
                $item[$_k]['size']   = $row['size'][$_k];
            }
            foreach ($item as $_i => $_row) {
                $ret[$k][$_i] = diy_upload($_row);
            }
        }
    }
    return $ret;
}

$select = '<select name="row[style][]">';
foreach ($styles as $style) {
    $select .= '<option value="' . $style . '">' . xigua_diyc::l('style_' . $style, 0) . '</option>';
}
$select .= '</select>';

if(submitcheck('fzid', 1) && $_GET['formhash']==formhash()){
    $fzid = intval($_GET['fzid']);

    $old_data = C::t('#xigua_diy#xigua_diy_page')->fetch($fzid);
    if($old_data){
        unset($old_data['pid']);
        $old_data['title'] = xigua_diyc::l('fuzhi',0).$old_data['title'];
        $newgid = C::t('#xigua_diy#xigua_diy_page')->insert($old_data, 1);
        $sets = DB::fetch_all('select * from %t where pid=%d', array('xigua_diy_setting', $fzid));
        foreach ($sets as $index => $item) {
            unset($sets[$index]['id']);
            unset($item['id']);
            $item['pid'] = $newgid;
            C::t('#xigua_diy#xigua_diy_setting')->insert($item, 1);
        }
        cpmsg(xigua_diyc::l('fzsucceed', 0).' ID '.$newgid, "action=plugins&operation=config&do=$pluginid&identifier=xigua_diy&pmod=diycp", 'succeed');
    }
}
if (submitcheck('persubmit')) {

    $index = intval($_GET['index']);
    $settings = array('xigua_diy_pid' => $index);
    C::t('common_setting')->update_batch($settings);
    updatecache('setting');


    if (!empty($_GET['new'])) {
        $new = dhtmlspecialchars($_GET['new']);
        foreach ($new['title'] as $key => $row) {
            $data = array();
            $data['title'] = ($row);
            $data['style'] = ($new['style'][$key]);
            $data['adminuid'] = ($new['adminuid'][$key]);
            $data['keywords'] = ($new['keywords'][$key]);
            $data['description'] = ($new['description'][$key]);
            $data['code'] = ($new['code'][$key]);
            C::t('#xigua_diy#xigua_diy_page')->insert($data);
        }
    }

    if($_FILES['icon'] ){
        $icons = diy_uploads($_FILES['icon']);
    }
    if (!empty($_GET['row'])) {
        $rows = dhtmlspecialchars($_GET['row']);
        foreach ($rows['title'] as $key => $row) {
            $data = array();
            $data['title'] = ($row);
            $data['style'] = ($rows['style'][$key]);
            $data['adminuid'] = ($rows['adminuid'][$key]);
            $data['keywords'] = ($rows['keywords'][$key]);
            $data['description'] = ($rows['description'][$key]);
            $data['code'] = $rows['code'][$key];
            if($_FILES['icon']['error'][$key] === UPLOAD_ERR_OK) {
                $data['icon'] = ($icons[$key]['errno'] == 0 ? $icons[$key]['error'] : '');
            }
            C::t('#xigua_diy#xigua_diy_page')->update($key, $data);
        }
    }

    if (!empty($_GET['delete'])) {
        C::t('#xigua_diy#xigua_diy_page')->multi_delete($_GET['delete']);
    }
    if($delimg = $_GET['delimg']){
        foreach ($delimg as $catid_ => $fields_) {
            $data_ = array();
            if($fields_['icon'] == 1){
                $data_['icon'] = '';
            }
            if($data_){
                C::t('#xigua_diy#xigua_diy_page')->update(intval($catid_), $data_);
            }
        }
    }
    cpmsg(
        xigua_diyc::l('succeed', 0),
        "action=plugins&operation=config&do=$pluginid&identifier=xigua_diy&pmod=diycp&page=" . $page,
        'succeed'
    );
}

$list = C::t('#xigua_diy#xigua_diy_page')->range($start_limit, $lpp, 'DESC');
$count = C::t('#xigua_diy#xigua_diy_page')->count();
$multipage = multi(
    $count, $lpp, $page,
    ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_diy&pmod=diycp"
);
echo "
<style>
.imgi{height:20px;vertical-align:middle;cursor:pointer}.imgprevew{position:absolute;z-index:9;display:none;border:2px solid #fff;box-shadow:0 2px 1px rgba(0,0,0,0.2)}.mini{width:150px!important}.noraml{width:60px!important}.sp{position:relative;display:inline-block;background:#fff}.gray{color:orangered;font-weight:700}.short{width:150px}</style>";
showformheader("plugins&operation=config&do=$pluginid&identifier=xigua_diy&pmod=diycp", 'enctype');
showtableheader(xigua_diyc::l('diy_desc', 0) . '<a style="position:absolute;right:10px;color:red;font-weight:bold" href="' . $app_url . '">' . xigua_diyc::l('style_more', 0) . '</a>',
    '', 'style="position:relative"');
showtablerow('class="header"', array(), array(
    'PID',
    xigua_diyc::l('allstyle', 0),
    xigua_diyc::l('adminuid', 0),
    xigua_diyc::l('share_icon', 0),
    xigua_diyc::l('title', 0),
    xigua_diyc::l('keywords', 0),
    xigua_diyc::l('description', 0),
    xigua_diyc::l('code', 0),
    xigua_diyc::l('action', 0),
));

$list = array_values($list);
$max = count($list);
$adminuid_tip = lang_diy('adminuid_tip', 0);
foreach ($list as $k => $row) {
    $pid = $row['pid'];
    $del = lang_diy('del_icon', 0);
    if ($row['icon']) {
        $imgpre = <<<HTML
 <span class="sp">
     <img class="imgi" src="{$row['icon']}" onmouseover="$('icon$pid').style.display='block'" onmouseout="$('icon$pid').style.display='none'" />
     <img id="icon$pid" src="{$row['icon']}"  class="imgprevew" />
     <label><input type="checkbox" class="checkbox" name="delimg[$pid][icon]" value="1" />$del</label>
 </span>
HTML;
    }else{
        $imgpre = '';
    }
    showtablerow('', array(), array(
        '<input type="checkbox" name="delete[]" value="' . $pid . '" />' . $pid,
        str_replace(array('<option value="' . $row['style'], 'row[style][]'), array('<option selected value="' . $row['style'], 'row[style][' . $pid . ']'), $select),
        '<input type="text" class="txt" placeholder="' . $adminuid_tip . '" style="width:120px" name="row[adminuid][' . $pid . ']" value="' . $row['adminuid'] . '" >',
        '<input type="file" class="txt" name="icon[' . $pid . ']" value="' . $row['icon'] . '" >' . $imgpre,
        '<input type="text" class="txt" style="width:100px" name="row[title][' . $pid . ']" value="' . $row['title'] . '" >',
        '<input type="text" class="txt" style="width:120px" name="row[keywords][' . $pid . ']" value="' . $row['keywords'] . '" >',
        '<textarea cols=20 rows=3 name="row[description][' . $pid . ']" >' . $row['description'] . '</textarea>',
        '<textarea cols=20 rows=3 name="row[code][' . $pid . ']" >' . $row['code'] . '</textarea>',
        '<a target="_balnk" href="' . $ahead . '&pid=' . $pid . '&diy=yes">' . xigua_diyc::l('diy_start', 0) . '</a>&nbsp;&nbsp;&nbsp;' .
        '<a target="_balnk" href="' . $ahead . '&pid=' . $pid . '&preview=previews">' . xigua_diyc::l('preview', 0) . '</a>&nbsp;&nbsp;&nbsp;'.
        '<a href="' . ADMINSCRIPT . "?action=plugins&operation=config&do=$pluginid&identifier=xigua_diy&pmod=diycp&formhash=".formhash() . '&fzid='.$pid.'">' . xigua_diyc::l('yjfz', 0) . '</a>&nbsp;&nbsp;&nbsp;'/*.
        '<a href="' . $ahead . '&pid=' . $pid . '&preview=previews">' . xigua_diyc::l('dr', 0) . '</a>&nbsp;&nbsp;&nbsp;'.
        '<a href="' . $ahead . '&pid=' . $pid . '&preview=previews">' . xigua_diyc::l('dc', 0) . '</a>'*/,

    ));
}

echo '<tr>
<td>&nbsp;</td>
<td colspan="99">
    <input type="hidden" name="page" value="' . $page . '">
    <span><a class="addtr" href="javascript:;" onclick="addrow(this, 0)">' . xigua_diyc::l('add', 0) . '</a></span>
</td>
</tr>';

showsubmit('persubmit', 'submit', 'del', '', $multipage);
showtablefooter(); /*dism _ taobao _ com*/
showformfooter(); /*dism��taobao��com*/
?>
<script type="text/JavaScript">
    var rowtypedata = [
        [
            [1, '&nbsp;'],
            [1, '<?php echo str_replace('name="row[style][]"', 'name="new[style][]"', $select)?>'],
            [1, '<input type="text" class="txt" style="width:120px" name="new[adminuid][]" >'],
            [1, '&nbsp;'],
            [1, '<input type="text" class="txt" style="width:100px" name="new[title][]" >'],
            [1, '<input type="text" class="txt" style="width:120px" name="new[keywords][]">'],
            [1, '<textarea  cols=20 rows=3 name="new[description][]"></textarea>'],
            [1, '<textarea  cols=20 rows=3 name="new[code][]"></textarea>'],
            [1, '&nbsp;']
        ]
    ];
    function docheck(index, max) {
        for (var i = 0; i < max; i++) {
            if (i != index) {
                document.getElementById('check_' + i).checked = 0;
            }
        }
        return true;
    }
</script>