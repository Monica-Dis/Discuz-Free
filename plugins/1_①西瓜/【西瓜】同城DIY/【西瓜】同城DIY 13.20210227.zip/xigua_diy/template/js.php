<?php if (!defined('IN_DISCUZ')) { exit('Access Denied'); } ?>
<link href="source/plugin/xigua_diy/static/css/form.css?<?php echo  FORMHASH?>" rel="stylesheet">
<link href="source/plugin/xigua_diy/static/js/colorPicker/colorPicker.css?<?php echo  FORMHASH?>" rel="stylesheet">
<style type="text/css">
html,body{background:#fff}
</style>
<script type="text/javascript">
var actionurl = '<?php echo $actionurl?>',
    FORMHASH = '<?php echo  FORMHASH?>',
    advance_color = '<?php xigua_diyc::l('advance_color')?>',
    default_color = '<?php xigua_diyc::l('default_color')?>',
    error_color = '<?php xigua_diyc::l('error_color')?>',
    deal = '<?php xigua_diyc::l('deal')?>';
</script>
<script src="source/plugin/xigua_diy/static/js/art/lib/jquery-1.10.2.js"></script>
<script src="source/plugin/xigua_diy/static/js/ajaxfileupload.js"></script>
<script src="source/plugin/xigua_diy/static/js/diy.js?20150603"></script>
<script src="source/plugin/xigua_diy/static/js/colorPicker/colorPicker.js"></script>