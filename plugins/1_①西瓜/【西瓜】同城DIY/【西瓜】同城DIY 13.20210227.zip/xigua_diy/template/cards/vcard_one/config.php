<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
return array(
    'modulename' => xigua_diyc::l('news', 0). lang('admincp', 'styles_edit_visual_menu') ,
    'introduce'  => xigua_diyc::l('news', 0).lang('admincp', 'styles_edit_visual_menu') ,
    'icon'       => 'source/plugin/xigua_diy/template/cards/vcard_one/images/2.png',
    'preview'    => '',
    'version'    => '1.0.0',
    'lock'       => 0,
    'open'       => 1,
    'js'         => <<<JS

JS
,
    'src'        => '',
    'tpl'        => '{html}',
    'css'        => <<<CSS
.imgnav{}
.imgnav>div:last-child{margin-bottom:0!important;}
.vcardlist1{position:relative}
.imgnav1{padding:10px 0}
CSS
);