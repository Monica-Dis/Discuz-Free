<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2019/1/21
 * Time: 17:42
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:02
 */
function process_vcard_one($card)
{
    $h = $card['var']['h'] ? intval($card['var']['h']) .'px' : '100%';
    $ha = intval($card['var']['ha']) .'px';
    $num = intval($card['var']['linenum']);

    $w = 100/$num;
    $divs = array();
    $i = $j = 0;

    foreach ($card['var']['imgs'] as $k => $v) {
        $link = $card['var']['link'][$k];
        $src = $card['var']['imgs'][$k];
        $name = $card['var']['navname'][$k];
        $divs[$j][] .= "<a class='vcardlist1' style='float:left;width:$w%;text-align:center;font-size:12px' href=\"$link\"><img style='display:block;width:$h;height:$h;margin:0 auto 5px' src='$src'/> $name</a>";
        $i ++;
        if($i%$num==0){
            $j++;
        }
    }
    $html = '';
    foreach ($divs as $div) {
        $html .= '<div class="cl" style="margin-bottom:'.$ha.'">'.implode('', $div) .'</div>';
    }

    $param = $card['var']['param'];
    $cardid = $card['id'];
    $header = '';

    if($card['var']['title'] || $card['var']['subtitle']) {
        $title_link = $card['var']['title_link'] ? $card['var']['title_link'] : 'javascript:void(0);';
        $header = '<div class="news-t" ' . '><h3>' .
            '<a ' . ' href="' . $title_link . '">' . $card['var']['title'] . '</a></h3>';
        if ($card['var']['subtitle']) {
            $header .= '<nav class="tmore">';
            foreach ($card['var']['subtitle'] as $i => $subtitle) {
                $header .= '<a href="' . $card['var']['subtitle_link'][$i] . '">' . $subtitle . '</a>';
            }
            $header .= '</nav>';
        }
        $header .= '</div>';
    }

    $card['var']['html'] = $header."<div class='imgnav1'>".$html."</div>";

    return $card;
}