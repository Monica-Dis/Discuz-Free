<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
/**
 * @param $card
 *
 * @return mixed
 */
function process_banner($card)
{
    $card['var']['close'] = $card['var']['close'] ? '<a class="close">X</a>' : '';
    $card['var']['cookiexpire'] = intval($card['var']['cookiexpire']);
    $card['var']['id'] = $card['id'];

    return $card;
}