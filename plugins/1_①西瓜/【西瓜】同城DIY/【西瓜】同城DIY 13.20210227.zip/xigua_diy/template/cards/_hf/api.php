<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!function_exists('lang_hf')){
    function lang_hf($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_hf', $lang);
        }else{
            return lang('plugin/xigua_hf', $lang);
        }
    }
}
$config = $_G['cache']['plugin']['xigua_hb'];
$hs_config = $_G['cache']['plugin']['xigua_hs'];
$hf_config = $_G['cache']['plugin']['xigua_hf'];
$start_limit = 0;
$lpp = $_GET['items'];
$field = '*';
$order_by = '';


$pingbi = 0;
$ob = 'upts DESC';
$where = array();
$manage = 0;
$field = '*';
$stcon = '';
if ($_GET['st']) {
    $where[] = " stid=" . intval($_GET['st']);
}
if ($_GET['stid']) {
    $where[] = " stid=" . intval($_GET['stid']);
}
$where[] = "status=1";

if($_GET['hyid'] && is_array($_GET['hyid'])){
    $list_cat = array();
    $listall = array();
    foreach (C::t('#xigua_hf#xigua_hf_hangye')->list_all(1, 1) as $index => $item) {
        if(in_array($item['pid'], $_GET['hyid'])){
            $_jobwant[] = $item['id'];
        }
    }
    $str = array();
    foreach ($_jobwant as $index => $item) {
        $item = intval($item);
        $str[] = " FIND_IN_SET($item, jineng) ";
    }
    if($str){
        $where[] = '('.implode(' OR ', $str).')';
    }
}
if($_GET['tuijian']){
    $where[] = ' tuijian=1 ';
}
$viewtype = $_GET['viewtype'];
if(!$viewtype){
    $viewtype = $_GET['orderby'];
}

if($viewtype=='hy'){
    if($page<=1){
        $list_all = C::t('#xigua_hf#xigua_hf_hangye')->list_all();
        C::t('#xigua_hf#xigua_hf_hangye')->init($list_all);
        $cat_tree_init = $cat_tree = C::t('#xigua_hf#xigua_hf_hangye')->get_tree_array(0);
    }
    if(!$hf_config['hy_num']){
        $hf_config['hy_num'] = 3;
    }
    include template('xigua_hb:header_ajax');
    include template('xigua_hf:hylist');
    include template('xigua_hb:footer_ajax');
    dexit();
}

$orary = C::t('#xigua_hf#xigua_hf_qun')->get_order($viewtype);

if($manage){
    $order_by = 'qunid desc';
}else{
    $order_by = $orary['order_by'];
}
$field = $orary['field'];
if($zdid = array_filter(explode(',', $_GET['zdid']))){
    $wherenew[] = 'status=1';
    if($zdid){
        $wherenew[] = ' qunid in ('.implode(',', $zdid).')';
    }
    $where = $wherenew;
}
$list = C::t('#xigua_hf#xigua_hf_qun')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);

include template('xigua_diy:touch/header_ajax');
include template('xigua_diy:touch/_hf_list');
include template('xigua_diy:touch/footer_ajax');