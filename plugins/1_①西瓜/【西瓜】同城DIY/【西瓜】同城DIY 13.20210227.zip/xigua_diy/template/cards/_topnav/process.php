<?php
!defined('IN_DISCUZ') && exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:02
 */
function process__topnav($card)
{
    $INdiv = '';
    $cc = $card['var']['bgcolor'] ? ' style="color:'.$card['var']['bgcolor'].'"' : '';
    foreach ($card['var']['name'] as $k => $v) {
        if($v){
            $link = $card['var']['link'][$k];
            $title = $card['var']['name'][$k];
            $INdiv .= <<<HTML1
<a href="$link" class="weui-navbar__item ajcat1">
    <span$cc>$title</span>
</a>
HTML1;
        }
    }

    $html = <<<HTML
<div class="weui-cells fixbanner before_none after_none" style="margin-top:0"><div class="weui-navbar weui-banner nobg fixbanner_in" style="width:auto">
$INdiv
</div></div>
HTML;

    $card['var']['html'] = $html;

    return $card;
}