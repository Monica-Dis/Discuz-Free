<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include xp_display('header');
include xp_display('js');

$id = $p['id'];
$bgcolor = $p['value']['bgcolor'];
$title = $p['modulename'] . ' ' . $id;
$v = $p['value'];
$names = $p['value']['name'] ? $p['value']['name'] : array();
$imgs = $p['value']['img'] ? $p['value']['img'] : array();
$links = $p['value']['link'] ? $p['value']['link'] : array();
$p = $p['var'];

?>
<style> .imgsp img {height:30px;vertical-align:middle}</style>
<div class="form">
    <form id="form" <?php if($form_charset){?>accept-charset="<?php echo $form_charset ?>"<?php }?> action="<?php echo $actionsaveurl; ?>" method="POST">
    <table class="table_purview">
        <input type="hidden" name="formhash" value="<?php echo FORMHASH ?>"/>
        <input type="hidden" name="cid" value="<?php echo $id ?>"/>

        <tr>
            <th><?php xigua_diyc::l('color') ?></th>
            <td>
                <span class="J_color_pick color_pick"><em style="background:<?php echo $bgcolor ?>"></em></span>
                <input name="row[bgcolor]" type="hidden" class="J_hidden_color bgcolor" value="<?php echo $bgcolor ?>">
            </td>
        </tr>

        <?php foreach ($names as $k => $vv) { ?>
            <tr>
                <th><?php echo  ($k == 0 )? xigua_diyc::l('nav_list', 0) : '&nbsp;';?></th>
                <td>
                    <input type="text" class="mini" placeholder="<?php xigua_diyc::l('navname')?>" name="row[name][]" value="<?php echo $vv?>" />

                    <input type="text" class="normal2" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="<?php echo $links[$k]?>">
                    <a class="del" onclick="deleterow(this)">x</a>
                </td>
            </tr>
        <?php } ?>
        <tr>
            <th>&nbsp;</th>
            <td>
                <button type="button" class="button1" onclick="addrow(this,0);picker();"><?php xigua_diyc::l('add');?></button>
            </td>
        </tr>
        <tr>
            <th>&nbsp;</th>
            <td>
                <button class="button2 "><?php xigua_diyc::l('save') ?></button>
            </td>
        </tr>
    </table>
    </form>
</div>
<script>
    var rowtypedata = [[
        [1, '&nbsp;', 'th'],
        [1, '<input type="text" class="mini" placeholder="<?php xigua_diyc::l('navname')?>" name="row[name][]" value="" />\
        <input type="text" class="normal2" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="">\
    <a class="del" onclick="deleterow(this)">x</a>']
    ]];
    var dialog = top.dialog.get(window);
    $(function () {
        dialog.title('<?php echo $title;?>');
        dialog.height(400);
    });

    function ajaxFileUpload1(obj) {
        obj.id = 'xiguafile';
        obj.name = 'xiguafile';
        $.ajaxFileUpload({
            url:actionurl,
            secureuri:false,
            fileElementId:'xiguafile',
            dataType: 'json',
            data:{ac:'upload', formhash:FORMHASH},
            success: function (data, status){
                var ob = $('#xiguafile');
                if(typeof(data.errno) != 'undefined' && data.errno != 0){
                    ob.next().html(data.error);
                }else{
                    ob.parent().find('.imgsp').html('<img src="'+data.error+'" />');
                    ob.parent().find('.imgsh').val(data.error);
                }
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            },
            error: function (data, status, e){
                var ob = $('#xiguafile');
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            }
        });
        return false;
    }
</script>
</body></html>