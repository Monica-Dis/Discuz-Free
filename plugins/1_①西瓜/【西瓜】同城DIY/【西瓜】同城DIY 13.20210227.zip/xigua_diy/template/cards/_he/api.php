<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$config = $_G['cache']['plugin']['xigua_hb'];
$hs_config = $_G['cache']['plugin']['xigua_hs'];
$he_config = $_G['cache']['plugin']['xigua_he'];
$start_limit = 0;
$lpp = $_GET['items'];
$field = '*';
$order_by = '';

$he_huodong = C::t('#xigua_he#xigua_he_huodong');

$wherearr = $wherenew = array();
$wherearr[] = 'status=2';
$order_by = 'id DESC';
if($_GET['tuijian']){
    $wherearr[] = 'tuijian=1';
}

$_GET['catid'] = dintval($_GET['hyid'], 1);
if($_GET['catid']){
    $wherearr[] = ' catid IN('.implode(',', $_GET['catid']).') ';
}
$viewtype = $_GET['viewtype'] = $_GET['orderby'];
if(!$viewtype){
    $viewtype = $orderby = $_GET['orderby'];
}
$orary = $he_huodong->get_order($viewtype);
$order_by = $orary['order_by'];
$field = $orary['field'];

if($zdid = array_filter(explode(',', $_GET['zdid']))){
    $wherenew[] = 'status=2';
    if($zdid){
        $wherenew[] = ' id in ('.implode(',', $zdid).')';
    }
    $wherearr = $wherenew;
}
$list = $he_huodong->fetch_all_by_where($wherearr, $start_limit, $lpp, $order_by, $field);
include template('xigua_diy:touch/header_ajax');
include template('xigua_diy:touch/_he_list');
include template('xigua_diy:touch/footer_ajax');