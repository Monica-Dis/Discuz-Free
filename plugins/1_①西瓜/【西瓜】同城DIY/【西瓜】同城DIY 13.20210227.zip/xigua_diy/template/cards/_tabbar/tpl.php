<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include xp_display('header');
include xp_display('js');

$id = $p['id'];
$title = $p['modulename'] . ' ' . $id;
$v = $p['value'];
$names = $p['value']['name'] ? $p['value']['name'] : array('');
$imgs = $p['value']['img'] ? $p['value']['img'] : array();
$links = $p['value']['link'] ? $p['value']['link'] : array();
$prices = $p['value']['price'] ? $p['value']['price'] : array();
$sellnum = $p['value']['sellnum'] ? $p['value']['sellnum'] : array();
$shichang = $p['value']['shichang'] ? $p['value']['shichang'] : array();
$displayorders = $p['value']['displayorder'] ? $p['value']['displayorder'] : array();
$ups = $p['value']['up'] ? $p['value']['up'] : array();
$p = $p['var'];
?>
<div class="form">
    <form id="form" <?php if($form_charset){?>accept-charset="<?php echo $form_charset ?>"<?php }?> action="<?php echo $actionsaveurl; ?>" method="POST">
        <table class="table_purview">
            <input type="hidden" name="formhash" value="<?php echo FORMHASH ?>"/>
            <input type="hidden" name="cid" value="<?php echo $id ?>"/>
            <?php foreach ($names as $k => $vv) { ?>
                <tr>
                    <th><?php echo  ($k == 0 )? xigua_diyc::l('nav_list', 0) : '&nbsp;';?></th>
                    <td>
                        <select name="row[up][]"><option value="0" <?php echo !$ups[$k]?'selected':''?>><?php lang_diy('butuchu');?></option><option value="1" <?php echo $ups[$k]?'selected':''?>><?php lang_diy('tuchu');?></option></select>
                        <input type="text" class="short" placeholder="<?php xigua_diyc::l('displayorder')?>" name="row[displayorder][]" value="<?php echo $displayorders[$k]?>" />
                        <input type="text" class="short" placeholder="<?php xigua_diyc::l('navname')?>" name="row[name][]" value="<?php echo $vv?>" />
                        <input type="text" class="normal2" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="<?php echo $links[$k]?>">

                        <input name="xiguafile[]" class="file" type="file" onchange="return ajaxFileUpload1(this);" style="opacity:1;background:none;position:relative"  />
                        <span class="imgsp"><img src="<?php echo $p['img'][$k]?>" onerror="this.error=null;this.src='source/plugin/xigua_diy/static/images/none.png'" /> </span>
                        <input class="imgsh" name="row[img][]" type="hidden" value="<?php echo $p['img'][$k]?>">

                        <a class="del" onclick="deleterow(this)">x</a>
                    </td>
                </tr>
            <?php } ?>
            <tr>
                <th>&nbsp;</th>
                <td>
                    <button type="button" class="button1" onclick="addrow(this,0);picker();"><?php xigua_diyc::l('add');?></button>
                </td>
            </tr>
            <tr>
                <th>&nbsp;</th>
                <td>
                    <button class="button2 "><?php xigua_diyc::l('save') ?></button>
                </td>
            </tr>
        </table>
    </form>
</div>
<script>
    var rowtypedata = [[
        [1, '&nbsp;', 'th'],
        [1, '\
        <select name="row[up][]"><option value="0" selected><?php lang_diy('butuchu');?></option><option value="1"><?php lang_diy('tuchu');?></option></select>\
        <input type="text" class="short" placeholder="<?php xigua_diyc::l('displayorder')?>" name="row[displayorder][]" value="" />\
        <input type="text" class="short" placeholder="<?php xigua_diyc::l('navname')?>" name="row[name][]" value="" />\
        <input type="text" class="normal2" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="">\
        <input name="xiguafile[]" class="file" type="file" onchange="return ajaxFileUpload1(this);" style="opacity:1;background:none;position:relative" />\
        <span class="imgsp"></span>\
        <input class="imgsh" name="row[img][]" type="hidden" value="">\
    <a class="del" onclick="deleterow(this)">x</a>']
    ]];
    var dialog = top.dialog.get(window);
    $(function () {
        dialog.title('<?php echo $title;?>');
        dialog.height(515);
    });

    function add_subtitle(){
        var v = htmlspecialchars($('#st').val()),
            l = htmlspecialchars($('#stl').val());
        if(v){
            $('#stw').append('<p class="stp"><a href="'+l+'" target="_blank">'+v+'</a><span class="del" onclick="return removelink(this)">X</span>\
            <input class="sth" type="hidden" name="row[subtitle][]" value="'+v+'" />\
            <input class="sthl" type="hidden" name="row[subtitle_link][]" value="'+l+'" /></p>');
            $('#st').val('')
            $('#stl').val('');
        }
        return false;
    }
    function removelink(obj){
        $(obj).parent().remove();
        return false;
    }

    function ajaxFileUpload1(obj) {
        obj.id = 'xiguafile';
        obj.name = 'xiguafile';
        $.ajaxFileUpload({
            url:actionurl,
            secureuri:false,
            fileElementId:'xiguafile',
            dataType: 'json',
            data:{ac:'upload', formhash:FORMHASH},
            success: function (data, status){
                var ob = $('#xiguafile');
                if(typeof(data.errno) != 'undefined' && data.errno != 0){
                    ob.next().html(data.error);
                }else{
                    ob.parent().find('.imgsp').html('<img src="'+data.error+'" />');
                    ob.parent().find('.imgsh').val(data.error);
                }
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            },
            error: function (data, status, e){
                var ob = $('#xiguafile');
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            }
        });
        return false;
    }
</script>
</body></html>