<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function process__tabbar($card){
    $_vars = $card['var'];
    $cardid = $card['id'];

    $list = array();
    foreach ($_vars['img'] as $index => $var) {
        $list[$_vars['displayorder'][$index]] = array(
            'name' => $_vars['name'][$index],
            'img' => $_vars['img'][$index],
            'link' => $_vars['link'][$index],
            'up'   => $_vars['up'][$index],
        );
    }
    ksort($list);

    $listhtml = '';
    include template('xigua_diy:touch/_tabbar');
    $card['var']['html'] = $listhtml;

    return $card;
}