<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$config = $_G['cache']['plugin']['xigua_hb'];
$dh_config = $_G['cache']['plugin']['xigua_dh'];

$sjobj = C::t('#xigua_dh#xigua_dh_shangjia');
if($dh_config['hytype'] == 1){
    $hyobj = C::t('#xigua_hs#xigua_hs_hangye');
}else{
    $hyobj = C::t('#xigua_dh#xigua_dh_hangye');
}

$start_limit = 0;
$lpp = $_GET['items'];
$field = '*';
$order_by = '';

$viewtype = $_GET['viewtype'];
if(!$viewtype){
    $viewtype = $orderby = $_GET['orderby'];
}
$manage = 0;
$field = '*';
$where = array();

if($_GET['datatype']=='listcat'){
    if($page<=1){
        $list_all = $hyobj->list_all();
        $hyobj->init($list_all);
        $cat_tree_init = $cat_tree = $hyobj->get_tree_array(0);
        $cat_nusm = $sjobj->fetch_all_count();
    }
    include template('xigua_diy:touch/header_ajax');
    include template('xigua_diy:touch/_dh_list');
    include template('xigua_diy:touch/footer_ajax');
}else{
    $where[] = 'display=1 AND endts>='.TIMESTAMP;
    $orary = $sjobj->get_order($viewtype);
    $order_by = $orary['order_by'];
    $field = $orary['field'];

    $_GET['catid'] = dintval($_GET['hyid'], 1);
    if($_GET['catid']){
        $where[] = ' hangye_id1 IN('.implode(',', $_GET['catid']).') ';
    }

    if($zdid = array_filter(explode(',', $_GET['zdid']))){
        $wherenew = array();
        $wherenew[] = 'display=1 AND endts>='.TIMESTAMP;
        if($zdid){
            $wherenew[] = ' shid in ('.implode(',', $zdid).')';
        }
        $where = $wherenew;
    }
    $list = $sjobj->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);

    include template('xigua_diy:touch/header_ajax');
    include template('xigua_diy:touch/_dh_list');
    include template('xigua_diy:touch/footer_ajax');
}