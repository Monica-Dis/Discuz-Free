<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function process__video($card)
{
    $header = '';
    $listhtml = '';
    $param = $card['var']['param'];
    $cardid = $card['id'];

    if($card['var']['title'] || $card['var']['subtitle']) {
        $title_link = $card['var']['title_link'] ? $card['var']['title_link'] : 'javascript:void(0);';
        $header = '<div class="news-t" ' . '><h3>' .
            '<a ' . ' href="' . $title_link . '">' . $card['var']['title'] . '</a></h3>';
        if ($card['var']['subtitle']) {
            $header .= '<nav class="tmore">';
            foreach ($card['var']['subtitle'] as $i => $subtitle) {
                $header .= '<a ' . $color . ' href="' . $card['var']['subtitle_link'][$i] . '">' . $subtitle . '</a>';
            }
            $header .= '</nav>';
        }
        $header .= '</div>';
    }

    $style_ext = array();
    $style_ext[] = 'width:100%';
    $style_ext[] = $card['var']['height'] ? 'height:'.$card['var']['height'].'px' : '';
    $style_ext = "style='".implode(';', $style_ext)."'";

    $adddr = $param['video_addr'];
    $video_cover = $param['video_cover'];
    $autoplay = $param['autoplay'] ? 'autoplay="autoplay" muted="muted" preload' : '';
    $fullscreen = !$param['fullscreen'] ? 'x5-playsinline webkit-playsinline playsinline x-webkit-airplay="allow"': '';
if($adddr){
    $listhtml = <<<HTML
<video poster="$video_cover" src="$adddr" controls="controls"  $fullscreen $autoplay $style_ext></video>
HTML;
}
    $card['var']['html'] = $header.$listhtml;

    return $card;
}
