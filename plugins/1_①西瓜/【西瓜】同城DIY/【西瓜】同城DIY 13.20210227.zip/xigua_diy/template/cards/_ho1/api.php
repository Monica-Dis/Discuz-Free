<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!function_exists('lang_ho')){
    function lang_ho($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_ho', $lang);
        }else{
            return lang('plugin/xigua_ho', $lang);
        }
    }
}
$config = $_G['cache']['plugin']['xigua_hb'];
$hs_config = $_G['cache']['plugin']['xigua_hs'];
$ho_config = $_G['cache']['plugin']['xigua_ho'];
$start_limit = 0;
$lpp = $_GET['items'];
$field = '*';
$order_by = '';


$uids = array();
$where = array('status=1');

if($_GET['hyid'] && is_array($_GET['hyid'])){
    $list_cat = array();
    $listall = array();
    foreach (C::t('#xigua_ho#xigua_ho_cat')->list_all(1, 1) as $index => $item) {
        if(in_array($item['pid'], $_GET['hyid'])){
            $_jobwant[] = $item['id'];
        }
    }
    $str = array();
    foreach ($_jobwant as $index => $item) {
        $item = intval($item);
        $str[] = " FIND_IN_SET($item, jineng) ";
    }
    if($str){
        $where[] = '('.implode(' OR ', $str).')';
    }
}

if ($_GET['tuijian']) {
    $where[] = " tuijian='1'";
}

if($zdid = array_filter(explode(',', $_GET['zdid']))){
    $wherenew[] = 'status=1';
    if($zdid){
        $wherenew[] = ' id in ('.implode(',', $zdid).')';
    }
    $where = $wherenew;
}
$orary = C::t('#xigua_ho#xigua_ho_shifu')->get_order($_GET['orderby']);
$list = C::t('#xigua_ho#xigua_ho_shifu')->fetch_all_by_page($start_limit, $lpp, $where, $orary['field'], $orary['order_by']);
foreach ($list as $index => $item) {
    $uids[] = $item['uid'];
    $list[$index]['jineng_str'] = str_replace(',', lang_ho('dot',0), $item['jineng_str']);
    $list[$index]['areawant_str'] = str_replace(',', lang_ho('dot',0), $item['areawant_str']);
}
if($_G['cache']['plugin']['xigua_hr']){
    $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids);
    $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids, 2);
    $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
}

include template('xigua_diy:touch/header_ajax');
include template('xigua_diy:touch/_ho1_list');
include template('xigua_diy:touch/footer_ajax');