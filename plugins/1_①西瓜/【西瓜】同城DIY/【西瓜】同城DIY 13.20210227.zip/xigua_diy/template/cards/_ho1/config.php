<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
return array(
    'modulename' => lang_diy('ho1', 0),
    'introduce'  => lang_diy('ho1_tip', 0),
    'icon'       => 'source/plugin/xigua_diy/static/images/xigua_ho.png',
    'preview'    => '',
    'version'    => '1.0.0',
    'lock'       => 0,
    'open'       => 1,
    'js'         => <<<JS
JS
,
    'src'        => '',
    'link'        => '<link rel="stylesheet" href="source/plugin/xigua_diy/static/css/hb.css?'.VERHASH.'">',
    'tpl'        => '{html}',
    'css'        => <<<HTML
HTML
);