<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$config = $_G['cache']['plugin']['xigua_hb'];
$hs_config = $_G['cache']['plugin']['xigua_hs'];
$dp_config = $_G['cache']['plugin']['xigua_dp'];
$start_limit = 0;
$lpp = $_GET['items'];
$field = '*';
$order_by = '';

$cmtobj = C::t('#xigua_dp#xigua_dp_comment');

$ob = 'upts DESC';

$where = array();
$_GET['nav'] = $_GET['orderby'];

if($_GET['nav']=='shipin'){
    $where[] = "video!=''";
}
$_GET['catid'] = dintval($_GET['hyid'], 1);
if($_GET['catid']){
    $wherearr[] = ' hy_id IN('.implode(',', $_GET['catid']).') ';
}
if($_GET['jx']){
    $where[] = "jx=1";
}

if($zdid = array_filter(explode(',', $_GET['zdid']))){
    if($zdid){
        $wherenew[] = ' cid in ('.implode(',', $zdid).')';
    }
    $where = $wherenew;
}
$list = $cmtobj->fetch_all_bypage($where, $start_limit, $lpp, $ob);


include template('xigua_diy:touch/header_ajax');
include template('xigua_diy:touch/_dp_list');
include template('xigua_diy:touch/footer_ajax');