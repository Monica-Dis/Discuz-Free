<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function process__dp($card)
{
    $param = $card['var']['param'];
    $cardid = $card['id'];

    if($card['var']['title'] || $card['var']['subtitle']) {
        $title_link = $card['var']['title_link'] ? $card['var']['title_link'] : 'javascript:void(0);';
        $header = '<div class="news-t" ' . '><h3>' .
            '<a ' . ' href="' . $title_link . '">' . $card['var']['title'] . '</a></h3>';
        if ($card['var']['subtitle']) {
            $header .= '<nav class="tmore">';
            foreach ($card['var']['subtitle'] as $i => $subtitle) {
                $header .= '<a ' . $color . ' href="' . $card['var']['subtitle_link'][$i] . '">' . $subtitle . '</a>';
            }
            $header .= '</nav>';
        }
        $header .= '</div>';
    }


    $extstyle = '';
    $query = http_build_query($param);
    $listhtml = <<<HTML
<div class="modost mod-post x-postlist dp_index" id="card_$cardid" $extstyle></div>
<script>$.ajax({type: 'get',url: 'plugin.php?id=xigua_diy:api&api=_dp&$query',
dataType: 'xml',success: function(data) {
    if (null == data) {return false;}
    var s = $.trim(data.lastChild.firstChild.nodeValue);
    if (!s) {return false;}
    $("#card_$cardid").append(s);
    if (typeof loadingCallback !== 'undefined') {loadingCallback();}
}
});</script>
HTML;
    $card['var']['html'] = $header.$listhtml;

    return $card;
}
