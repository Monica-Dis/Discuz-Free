<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$config = $_G['cache']['plugin']['xigua_hb'];
$job_config = $_G['cache']['plugin']['xigua_job'];
if(!function_exists('lang_job')){
    function lang_job($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_job', $lang);
        }else{
            return lang('plugin/xigua_job', $lang);
        }
    }
}

$birthinfo = range(1949, date('Y')-16);
$birthinfo = array_reverse($birthinfo);
$jingyan = array(
    '1' => lang_job('buxian',0),
    '2' => lang_job('jingyan2',0),
    '3' => lang_job('jingyan3',0),
    '4' => lang_job('jingyan4',0),
    '5' => lang_job('jingyan5',0),
    '6' => lang_job('jingyan6',0),
    '7' => lang_job('jingyan7',0),
);
$xueli = array(
    -1 => lang_job('buxian',0),
    '1' =>lang_job('xueli1',0),
    '2' =>lang_job('xueli2',0),
    '3' =>lang_job('xueli3',0),
    '5' =>lang_job('xueli5',0),
    '6' =>lang_job('xueli6',0),
    '7' =>lang_job('xueli7',0),
    '8' =>lang_job('xueli8',0),
);
$xinzi = array(
    '10' => lang_job('xinzi10',0),
    '2' => lang_job('xinzi2',0),
    '4' => lang_job('xinzi4',0),
    '5' => lang_job('xinzi5',0),
    '6' => lang_job('xinzi6',0),
    '7' => lang_job('xinzi7',0),
    '8' => lang_job('xinzi8',0),
    '9' => lang_job('xinzi9',0),
);
$qzzt = array(
    '1' => lang_job('qzzt1',0),
    '2' => lang_job('qzzt2',0),
    '3' => lang_job('qzzt3',0),
    '4' => lang_job('qzzt4',0),
    '5' => lang_job('qzzt5',0),
);
$jiesuan = array(
    '1' => lang_job('jiesuan1',0),
    '2' => lang_job('jiesuan2',0),
    '3' => lang_job('jiesuan3',0),
    '4' => lang_job('jiesuan4',0),
);
$yuanshi = array(
    'yuanshi' => lang_job('yuanshi',0),
    'yuantian' => lang_job('yuantian',0),
    'yuanyue' => lang_job('yuanyue',0),
    'yuange' =>  lang_job('yuange',0),
    'yuandan' => lang_job('yuandan',0),
);
$gender_ary = array(
    -1 => lang_job('buxian',0),
    1 => lang_job('gender1',0),
    2 => lang_job('gender2',0),
);
$shiduan = array(
    '2' => lang_job('shiduan2',0),
    '1' => lang_job('shiduan1',0),
    '-1' => lang_job('shiduan-1',0),
);
$job_status = array(
    1=>lang_job('jobstatus1',0),
    2=>lang_job('jobstatus2',0),
    9=>lang_job('jobstatus9',0),
);
$fullstatuss = array(
    -1=>lang_job('fullstatuss-1',0),
    1=>lang_job('fullstatuss1',0),
    2=>lang_job('fullstatuss2',0),
);
$toudi_status = array(
    1 => lang_job('tdstatus1',0),
    2 => lang_job('tdstatus2',0),
    3 => lang_job('tdstatus3',0),
);
$job_types = array(
    'full' => lang_job('full',0),
    'part' => lang_job('part',0),
);
$goodat = array();
$digtys = array();
foreach (explode("\n", trim($job_config['goodat'])) as $index => $item) {
    $goodat[$index] = trim($item);
}
foreach (explode("\n", trim($job_config['digtys'])) as $index => $item) {
    list($_day, $_price) = explode('=', trim($item));
    $digtys[trim($_day)] = trim($_price);
}

$hyobj = C::t('#xigua_job#xigua_job_hangye');
$rsobj = C::t('#xigua_job#xigua_job_resume');
$jobobj = C::t('#xigua_job#xigua_job_job');
$tcobj = C::t('#xigua_job#xigua_job_taocan');

$start_limit = 0;
$lpp = $_GET['items'];
$field = '*';
$order_by = '';

$viewtype = $_GET['viewtype'];
if(!$viewtype){
    $viewtype = $orderby = $_GET['orderby'];
}
$manage = 0;
$field = '*';
$where = array();


$where[] = 'status=2 AND endts>'.TIMESTAMP;

$_GET['catid'] = dintval($_GET['hyid'], 1);
if($_GET['catid']){
    $where[] = ' hangye_id1 IN('.implode(',', $_GET['catid']).') ';
}

if($_GET['st']>0){
    $where[] = 'stid='.intval($_GET['st']);
}
if($_GET['type']){
    $where[] = 'type=\''.daddslashes($_GET['type']).'\'';
}

if($paywant = $xinzi[$_GET['paywant']]){
    $paywant = daddslashes($paywant);
    $where[] = "xinzi = '$paywant'";
}
if($_GET['jingyan']>0 && $_GET['jingyan']!=1 && $_jingyan = $jingyan[$_GET['jingyan']]){
    $_jingyan = daddslashes($_jingyan);
    $where[] = "jingyan = '$_jingyan'";
}
if($_GET['xueli']>0){
    $_xueli = $xueli[$_GET['xueli']];
    $_xueli = daddslashes($_xueli);
    $where[] = "xueli = '$_xueli'";
}
if($_GET['areawant'] && strpos($_GET['areawant'], '-1')===false){
    $_areawant = explode(',', $_GET['areawant']);
    $str = array();
    foreach ($_areawant as $index => $item) {
        $item = daddslashes($item);
        $str[] = $item;
    }
    if($str){
        $str = '\''.implode(' \',\' ', $str).'\'';
        $where[] = "(province IN ($str) OR city IN ($str) OR district IN ($str))";
    }
}
if($keyword = stripsearchkey($_GET['keyword'])){
    $where[] = " (name LIKE '%$keyword%' OR shname LIKE '%$keyword%' OR fuli LIKE '%$keyword%' OR hy LIKE '%$keyword%' OR miaoshu LIKE '%$keyword%') ";
}
$getorder = $jobobj->get_order($_GET['order']);

if($zdid = array_filter(explode(',', $_GET['zdid']))){
    $wherenew = array();
    $wherenew[] = 'status=2 AND endts>'.TIMESTAMP;
    if($zdid){
        $wherenew[] = ' jobid in ('.implode(',', $zdid).')';
    }
    $where = $wherenew;
}
$list = $jobobj->fetch_all_by_page($start_limit, $lpp, $where, 1, $getorder['field'],$getorder['order_by']);
if($_G['cache']['plugin']['xigua_hr']['showg'] || $_G['cache']['plugin']['xigua_hr']['showb'] ){
    $uids = $shids = array();
    foreach ($list as $index => $item) {
        $uids[] = $item['uid'];
        $shids[] = $item['shid'];
    }
    if($_G['cache']['plugin']['xigua_hr']['showg']){
        $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris_bysh($shids);
    }
    if($_G['cache']['plugin']['xigua_hr']['showb']){
        $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
    }
}
include template('xigua_diy:touch/header_ajax');
include template("xigua_diy:touch/_job_list");
include template('xigua_diy:touch/footer_ajax');