<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function process__fgx($card)
{
    $param = $card['var']['param'];
    $cardid = $card['id'];
    $color = array();
    $color[] = $card['var']['themecolor'] ? 'background-color:'.$card['var']['themecolor'] : '';
    $color[] = $card['var']['height'] ? 'height:'.$card['var']['height'].'px' : '';
    $color = implode(';', $color);
    $listhtml = <<<HTML
<div class="hr_line" style="$color"></div>
HTML;
    $card['var']['html'] = $listhtml;

    return $card;
}
