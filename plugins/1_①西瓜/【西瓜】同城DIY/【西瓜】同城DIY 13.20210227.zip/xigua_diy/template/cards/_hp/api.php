<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
global $_G;
$start_limit = 0;
$lpp = $_GET['items'];
$config = $_G['cache']['plugin']['xigua_hb'];
$hp_config = $_G['cache']['plugin']['xigua_hp'];
$manage = $start_limit= 0;
$field = '*';
$stcon = '';
$where = array();
if(!function_exists('lang_hp')){
    function lang_hp($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_hp', $lang);
        }else{
            return lang('plugin/xigua_hp', $lang);
        }
    }
}

$where[] = "status=1 $stcon";
$_GET['catid'] = dintval($_GET['hyid'], 1);
if($_GET['catid']){
    $where[] = ' hangye_id1 IN('.implode(',', $_GET['catid']).') ';
}

if($zdid = array_filter(explode(',', $_GET['zdid']))){
    $wherenew = array();
    $wherenew[] = "status=1 $stcon";
    if($zdid){
        $wherenew[] = ' mpid in ('.implode(',', $zdid).')';
    }
    $where = $wherenew;
}

$needrank = 0;
if($_GET['orderby'] =='views'){
    $order_by = ' views DESC';
    $needrank= 1;
}elseif($_GET['orderby'] =='zans'){
    $order_by = ' zans DESC';
    $needrank= 1;
}elseif($_GET['orderby'] =='follow'){
    $order_by = ' follows DESC';
    $needrank= 1;
}else{
    $order_by = ' displayorder DESC, mpid DESC';
}

$rankindex = $start_limit;

$list = C::t('#xigua_hp#xigua_hp_user')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);

include template('xigua_diy:touch/header_ajax');
include template('xigua_diy:touch/_hp_list');
include template('xigua_diy:touch/footer_ajax');