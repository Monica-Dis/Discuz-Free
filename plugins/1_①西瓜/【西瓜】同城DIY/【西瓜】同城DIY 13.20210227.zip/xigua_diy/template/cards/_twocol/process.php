<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function process__twocol($card){
    $_vars = $card['var'];
    $cardid = $card['id'];

    if($card['var']['title'] || $card['var']['subtitle']) {
        $title_link = $card['var']['title_link'] ? $card['var']['title_link'] : 'javascript:void(0);';
        $header = '<div class="news-t" ' . '><h3>' .
            '<a ' . ' href="' . $title_link . '">' . $card['var']['title'] . '</a></h3>';
        if ($card['var']['subtitle']) {
            $header .= '<nav class="tmore">';
            foreach ($card['var']['subtitle'] as $i => $subtitle) {
                $header .= '<a ' . $color . ' href="' . $card['var']['subtitle_link'][$i] . '">' . $subtitle . '</a>';
            }
            $header .= '</nav>';
        }
        $header .= '</div>';
    }

    $list = array();
    foreach ($_vars['img'] as $index => $var) {
        $list[] = array(
            'name' => $_vars['name'][$index],
            'img' => $_vars['img'][$index],
            'link' => $_vars['link'][$index],
            'price' => $_vars['price'][$index],
            'sellnum' => $_vars['sellnum'][$index],
            'shichang' => $_vars['shichang'][$index],
        );
    }
//    dmp($list);
    $listhtml = '';
    include template('xigua_diy:touch/_twocol_list');
    $card['var']['html'] = $header.$listhtml;

    return $card;
}
