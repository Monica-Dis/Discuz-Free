<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include xp_display('header');
include xp_display('js');

$id = $p['id'];
$title = $p['modulename'] . ' ' . $id;
$v = $p['value'];
$names = $p['value']['name'] ? $p['value']['name'] : array();
$imgs = $p['value']['img'] ? $p['value']['img'] : array();
$links = $p['value']['link'] ? $p['value']['link'] : array();
$prices = $p['value']['price'] ? $p['value']['price'] : array();
$sellnum = $p['value']['sellnum'] ? $p['value']['sellnum'] : array();
$shichang = $p['value']['shichang'] ? $p['value']['shichang'] : array();
$p = $p['var'];

?>
<div class="form">
    <form id="form" <?php if($form_charset){?>accept-charset="<?php echo $form_charset ?>"<?php }?> action="<?php echo $actionsaveurl; ?>" method="POST">
        <table class="table_purview">
            <input type="hidden" name="formhash" value="<?php echo FORMHASH ?>"/>
            <input type="hidden" name="cid" value="<?php echo $id ?>"/>
            <tr>
                <th><?php xigua_diyc::l('title')?></th>
                <td>
                    <span class="J_color_pick color_pick"><em style="background:<?php echo $v['themecolor'] ?>"></em></span>
                    <input name="row[themecolor]" type="hidden" class="J_hidden_color bgcolor" value="<?php echo $v['themecolor'] ?>">
                    <input name="row[title]" type="text" class="mini" value="<?php echo $v['title'] ?>">
                    <input placeholder="<?php xigua_diyc::l('title_link')?>" name="row[title_link]" type="text" class="normal" value="<?php echo $v['title_link'] ?>">
                </td>
            </tr>
            <tr>
                <th><?php xigua_diyc::l('subtitle')?></th>
                <td>
                    <div id="stw">
                        <?php foreach ($v['subtitle'] as $kk => $vv) {
                            $ll = $v['subtitle_link'][$kk];
                            echo '<p class="stp"><a href="'.$ll.'" target="_blank">'.$vv.'</a><span class="del" onclick="return removelink(this)">X</span>'.
                                '<input class="sth" type="hidden" name="row[subtitle][]" value="'.$vv.'" />'.
                                '<input class="sthl" type="hidden" name="row[subtitle_link][]" value="'.$ll.'" /></p>';
                        }
                        ?></div>
                    <div>
                        <input placeholder="<?php xigua_diyc::l('subtitle_hold')?>" id="st" type="text" class="mini">
                        <input placeholder="<?php xigua_diyc::l('subtitle_link')?>" id="stl" type="text" class="normal">
                        <button onclick="return add_subtitle();" class="button1" type="button"><?php xigua_diyc::l('add')?></button>
                    </div>
                </td>
            </tr>
            <?php foreach ($names as $k => $vv) { ?>
                <tr>
                    <th><?php echo  ($k == 0 )? xigua_diyc::l('nav_list', 0) : '&nbsp;';?></th>
                    <td>
                        <input type="text" class="mini" placeholder="<?php xigua_diyc::l('navname')?>" name="row[name][]" value="<?php echo $vv?>" />
                        <input type="text" class="mini" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="<?php echo $links[$k]?>">
                        <input type="text" class="mini" placeholder="<?php xigua_diyc::l('price')?>"  name="row[price][]" value="<?php echo $prices[$k]?>">
                        <input type="text" class="mini" placeholder="<?php xigua_diyc::l('sellnum')?>"  name="row[sellnum][]" value="<?php echo $sellnum[$k]?>">
                        <input type="text" class="mini" placeholder="<?php xigua_diyc::l('shichang')?>"  name="row[shichang][]" value="<?php echo $shichang[$k]?>">

                        <input name="xiguafile[]" class="file" type="file" onchange="return ajaxFileUpload1(this);" style="opacity:1;background:none;position:relative"  />
                        <span class="imgsp"><img src="<?php echo $p['img'][$k]?>" /> </span>
                        <input class="imgsh" name="row[img][]" type="hidden" value="<?php echo $p['img'][$k]?>">

                        <a class="del" onclick="deleterow(this)">x</a>
                    </td>
                </tr>
            <?php } ?>
            <tr>
                <th>&nbsp;</th>
                <td>
                    <button type="button" class="button1" onclick="addrow(this,0);picker();"><?php xigua_diyc::l('add');?></button>
                </td>
            </tr>
            <tr>
                <th>&nbsp;</th>
                <td>
                    <button class="button2 "><?php xigua_diyc::l('save') ?></button>
                </td>
            </tr>
        </table>
    </form>
</div>
<script>
    var rowtypedata = [[
        [1, '&nbsp;', 'th'],
        [1, '<input type="text" class="mini" placeholder="<?php xigua_diyc::l('navname')?>" name="row[name][]" value="" />\
        <input type="text" class="mini" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="">\
        <input type="text" class="mini" placeholder="<?php xigua_diyc::l('price')?>"  name="row[price][]" value="">\
        <input type="text" class="mini" placeholder="<?php xigua_diyc::l('sellnum')?>"  name="row[sellnum][]" value="">\
        <input type="text" class="mini" placeholder="<?php xigua_diyc::l('shichang')?>"  name="row[shichang][]" value="">\
        <input name="xiguafile[]" class="file" type="file" onchange="return ajaxFileUpload1(this);" style="opacity:1;background:none;position:relative" />\
        <span class="imgsp"></span>\
        <input class="imgsh" name="row[img][]" type="hidden" value="">\
    <a class="del" onclick="deleterow(this)">x</a>']
    ]];
    var dialog = top.dialog.get(window);
    $(function () {
        dialog.title('<?php echo $title;?>');
        dialog.height(515);
    });

    function add_subtitle(){
        var v = htmlspecialchars($('#st').val()),
            l = htmlspecialchars($('#stl').val());
        if(v){
            $('#stw').append('<p class="stp"><a href="'+l+'" target="_blank">'+v+'</a><span class="del" onclick="return removelink(this)">X</span>\
            <input class="sth" type="hidden" name="row[subtitle][]" value="'+v+'" />\
            <input class="sthl" type="hidden" name="row[subtitle_link][]" value="'+l+'" /></p>');
            $('#st').val('')
            $('#stl').val('');
        }
        return false;
    }
    function removelink(obj){
        $(obj).parent().remove();
        return false;
    }

    function ajaxFileUpload1(obj) {
        obj.id = 'xiguafile';
        obj.name = 'xiguafile';
        $.ajaxFileUpload({
            url:actionurl,
            secureuri:false,
            fileElementId:'xiguafile',
            dataType: 'json',
            data:{ac:'upload', formhash:FORMHASH},
            success: function (data, status){
                var ob = $('#xiguafile');
                if(typeof(data.errno) != 'undefined' && data.errno != 0){
                    ob.next().html(data.error);
                }else{
                    ob.parent().find('.imgsp').html('<img src="'+data.error+'" />');
                    ob.parent().find('.imgsh').val(data.error);
                }
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            },
            error: function (data, status, e){
                var ob = $('#xiguafile');
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            }
        });
        return false;
    }
</script>
</body></html>