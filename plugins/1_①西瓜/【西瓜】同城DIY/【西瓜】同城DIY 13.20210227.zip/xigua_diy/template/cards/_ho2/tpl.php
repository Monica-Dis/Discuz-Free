<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include xp_display('header');
include xp_display('js');

$id = $p['id'];
$title = $p['modulename'] . ' ' . $id;
$v = $p['value'];
//ini_set('display_errors', 1);
//error_reporting(E_ALL ^ E_NOTICE);

if(!is_file(DISCUZ_ROOT.'source/plugin/xigua_ho/function.php')){
    exit(lang_diy('ins',0).' <a target="_top" style="color:#0a56bb" href="https://dism.taobao.com/?@xigua_ho.plugin">https://dism.taobao.com/?@xigua_ho.plugin</a>');
}
$cats = C::t('#xigua_ho#xigua_ho_cat')->list_by_pid(0, TRUE);
if(!function_exists('lang_ho')){
    function lang_ho($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_ho', $lang);
        }else{
            return lang('plugin/xigua_ho', $lang);
        }
    }
}


$orderby_list = array(
    '' => lang_hb('om',0),
    'newest' => lang_ho('newestxuqiu',0),
    'level' => lang_ho('level', 0),
    'yikou' => lang_ho('yikou_short', 0),
    'jingjia' => lang_ho('jingjia_short', 0),
);
?>
<style>
.stp{display: inline-block; margin: 3px 0;white-space:nowrap;}
#stw{margin-bottom:5px}
#stw a{background:#7BBFF2;color: #fff;padding:3px 6px; border-radius: 2px;}
</style>
<div class="form">
    <form id="form" <?php if($form_charset){?>accept-charset="<?php echo $form_charset ?>"<?php }?> action="<?php echo $actionsaveurl; ?>" method="POST">
        <table class="table_purview">
            <input type="hidden" name="formhash" value="<?php echo FORMHASH ?>"/>
            <input type="hidden" name="cid" value="<?php echo $id ?>"/>
            <tr>
                <th><?php xigua_diyc::l('title')?></th>
                <td>
                    <span class="J_color_pick color_pick"><em style="background:<?php echo $v['themecolor'] ?>"></em></span>
                    <input name="row[themecolor]" type="hidden" class="J_hidden_color bgcolor" value="<?php echo $v['themecolor'] ?>">
                    <input name="row[title]" type="text" class="mini" value="<?php echo $v['title'] ?>">
                    <input placeholder="<?php xigua_diyc::l('title_link')?>" name="row[title_link]" type="text" class="normal" value="<?php echo $v['title_link'] ?>">
                </td>
            </tr>
            <tr>
                <th><?php xigua_diyc::l('subtitle')?></th>
                <td>
                    <div id="stw">
                        <?php foreach ($v['subtitle'] as $kk => $vv) {
                            $ll = $v['subtitle_link'][$kk];
                            echo '<p class="stp"><a href="'.$ll.'" target="_blank">'.$vv.'</a><span class="del" onclick="return removelink(this)">X</span>'.
                                '<input class="sth" type="hidden" name="row[subtitle][]" value="'.$vv.'" />'.
                                '<input class="sthl" type="hidden" name="row[subtitle_link][]" value="'.$ll.'" /></p>';
                            }
                        ?></div>
                    <div>
                        <input placeholder="<?php xigua_diyc::l('subtitle_hold')?>" id="st" type="text" class="mini">
                        <input placeholder="<?php xigua_diyc::l('subtitle_link')?>" id="stl" type="text" class="normal">
                        <button onclick="return add_subtitle();" class="button1" type="button"><?php xigua_diyc::l('add')?></button>
                    </div>
                </td>
            </tr>

            <tr class="vt">
                <th><?php lang_ho('jineng')?></th>
                <td>
                    <select name="row[param][hyid][]" multiple="multiple" size="10" style="height:80px;width:300px">
                        <?php foreach ($cats as $cat) {
                            $checked = in_array($cat['id'], $v['param']['hyid']) ? 'selected' : '';
                            echo "<option $checked value='{$cat['id']}'>{$cat['name']}</option>";
                        }
                        ?>
                    </select>
                </td>
            </tr>
            <tr class="vt">
                <th><?php xigua_diyc::l('order_by')?></th>
                <td>
                    <ul class="pr">
                        <?php foreach ($orderby_list as $index => $item) { ?>
                            <li>
                                <label for="randomid_<?php echo $index?>"><input type="radio" name="row[param][orderby]" id="randomid_<?php echo $index?>" class="pr" value="<?php echo $index?>" <?php if($v['param']['orderby'] ==$index){echo 'checked';}?>  /> <?php echo $item?></label>
                            </li>
                        <?php  }?>
                    </ul>
                </td>
            </tr>
            <tr>
                <th><?php xigua_diyc::l('stid')?></th>
                <td><input type="text" name="row[param][st]" value="<?php echo $v['param']['st']?$v['param']['st']:0 ?>" class="short"  /></td>
            </tr>
            <tr>
                <th><?php xigua_diyc::l('zdid')?></th>
                <td><input type="text" name="row[param][zdid]" value="<?php echo $v['param']['zdid']?$v['param']['zdid']:'' ?>" class="normal" placeholder="<?php lang_diy('zdid_tip',1)?>" /></td>
            </tr>
            <tr>
                <th><?php xigua_diyc::l('article_item')?></th>
                <td><input type="text" name="row[param][items]" value="<?php echo $v['param']['items']?$v['param']['items']:10 ?>" class="short"  /></td>
            </tr>


            <tr>
                <th>&nbsp;</th>
                <td>
                    <button class="button2 "><?php xigua_diyc::l('save') ?></button>
                </td>
            </tr>
        </table>
    </form>
</div>
<script>
    var dialog = top.dialog.get(window);
    $(function () {
        dialog.title('<?php echo $title;?>');
        dialog.height(515);
    });

    function add_subtitle(){
        var v = htmlspecialchars($('#st').val()),
            l = htmlspecialchars($('#stl').val());
        if(v){
            $('#stw').append('<p class="stp"><a href="'+l+'" target="_blank">'+v+'</a><span class="del" onclick="return removelink(this)">X</span>\
            <input class="sth" type="hidden" name="row[subtitle][]" value="'+v+'" />\
            <input class="sthl" type="hidden" name="row[subtitle_link][]" value="'+l+'" /></p>');
            $('#st').val('');
            $('#stl').val('');
        }
        return false;
    }
    function removelink(obj){
        $(obj).parent().remove();
        return false;
    }
</script>
</body></html>