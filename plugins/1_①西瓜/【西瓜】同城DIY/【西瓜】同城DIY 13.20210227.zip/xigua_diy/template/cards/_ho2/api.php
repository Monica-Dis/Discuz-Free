<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
if(!function_exists('lang_ho')){
    function lang_ho($lang, $echo = 1){
        if($echo){
            echo lang('plugin/xigua_ho', $lang);
        }else{
            return lang('plugin/xigua_ho', $lang);
        }
    }
}
include_once DISCUZ_ROOT.'source/plugin/xigua_ho/common_status.php';
$config = $_G['cache']['plugin']['xigua_hb'];
$hs_config = $_G['cache']['plugin']['xigua_hs'];
$ho_config = $_G['cache']['plugin']['xigua_ho'];
$start_limit = 0;
$lpp = $_GET['items'];
$field = '*';
$order_by = '';


$where = array();
if($ho_config['showcj']){
    $where[] = ' status in(2,4,8)';
}else{
    $where[] = ' status in(2)';
}

if($_GET['orderby']=='yikou'){
    $where[] = 'type=\'yikou\'';
}
if($_GET['orderby']=='jingjia'){
    $where[] = 'type=\'jingjia\'';
}
if($_GET['type']){
    $where[] = 'type=\''. daddslashes($_GET['type']).'\'';
}

if($_GET['hyid'] && is_array($_GET['hyid'])){
    $list_cat = array();
    $listall = array();
    foreach (C::t('#xigua_ho#xigua_ho_cat')->list_all(1, 1) as $index => $item) {
        if(in_array($item['pid'], $_GET['hyid'])){
            $_jobwant[] = $item['id'];
        }
    }
    $str = array();
    foreach ($_jobwant as $index => $item) {
        $item = intval($item);
        $str[] = " FIND_IN_SET($item, catid) ";
    }
    if($str){
        $where[] = '('.implode(' OR ', $str).')';
    }
}

if($zdid = array_filter(explode(',', $_GET['zdid']))){
    $wherenew[] = 'status=1';
    if($zdid){
        $wherenew[] = ' id in ('.implode(',', $zdid).')';
    }
    $where = $wherenew;
}
$orary = C::t('#xigua_ho#xigua_ho_need')->get_order($_GET['orderby']);
$list = C::t('#xigua_ho#xigua_ho_need')->fetch_all_by_page($start_limit, $lpp, $where, $orary['field'], $orary['order_by']);
$catids = $needids = array();
foreach ($list as $index => $item) {
    $needids[] = $item['id'];
    $catids[] = $item['catid'];
    $list[$index]['vars'] = array_slice(unserialize($item['vars']), 0, 3);
    if(!$list[$index]['vars']){
        $list[$index]['description'] = cutstr(strip_tags($item['description']), 40);
    }
}

include template('xigua_diy:touch/header_ajax');
include template('xigua_diy:touch/_ho2_list');
include template('xigua_diy:touch/footer_ajax');