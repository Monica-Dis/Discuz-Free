<?php !defined('IN_DISCUZ') && exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:01
 */
return array(
    'modulename' => lang_diy('code1',0),
    'introduce'  => lang_diy('code1_tip',0),
    'icon'       => 'source/plugin/xigua_diy/template/cards/html/images/logo.png',
    'preview'    => '',
    'version'    => '1.0.0',
    'lock'       => 0,
    'open'       => 1,
    'tpl'        => '<div class="htmlw">{html}</div>',
    'js'         => '',
    'css'        => ''
);