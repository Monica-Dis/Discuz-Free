<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function process_thread($card)
{
    $card = xigua_diyc::block($card);

    $param = $card['var']['param'];
//    $param['picrequired'] = '1';

    $cond = array('getpic' => 1);
    if($param['summarylength']> 0){
        $cond['getsummary'] = 1;
    }

    $data = $card['block_class']->getdata($cond, $param);
    unset($card['block_class']);

    $threads = xigua_diyc::sort_by_tids($data, $param);

    if($card['var']['themecolor']){
        $color = 'style="color:'.$card['var']['themecolor'].'"';
        $bordercolor = 'style="border-top-color:'.$card['var']['themecolor'].'"';
    }

    if($card['var']['title'] || $card['var']['subtitle']) {
        $title_link = $card['var']['title_link'] ? $card['var']['title_link'] : 'javascript:void(0);';
        $header = '<div class="news-t" ' . $bordercolor . '><h3>' .
            '<a ' . $color . ' href="' . $title_link . '">' . $card['var']['title'] . '</a></h3>';
        if ($card['var']['subtitle']) {
            $header .= '<nav class="tmore">';
            foreach ($card['var']['subtitle'] as $i => $subtitle) {
                $header .= '<a ' . $color . ' href="' . $card['var']['subtitle_link'][$i] . '">' . $subtitle . '</a>';
            }
            $header .= '</nav>';
        }
        $header .= '</div>';
    }


    $pstyle = $card['var']['color'] ? 'color:'.$card['var']['color'].';' : '';
    $showreply = in_array($card['var']['showreply'], array('replies', 'views')) ? $card['var']['showreply'] : 'views';
    if($showreply == 'views'){
        $class = 'td-v-num';
    }else{
        $class = 'td-r-num';
    }

    $list = '<ul class="td">';
    foreach ($threads as $thread) {

        $img  = xigua_diyc::get_picurl($thread['pic'], (boolean)$card['var']['thumb']);
        $link = xigua_diyc::thread_link($thread['id']);
        if($summary = trim($thread['summary'])){
            $summary =  '<p class="td-s">'.trim(strip_tags($thread['summary'])).'</p>';
//            $pstylefont = 'font-size:15px;';
        }
        $lastpost = strip_tags(dgmdate($thread['fields']['lastpost'], 'u'));
        $num = $thread['fields'][$showreply];
//<em class="td-t-num">{$thread['fields']['author']}</em>

        $list .= <<<LI
<li><a class="cl" href="$link"><div class="td-i" style="background-image:url($img);float:left"></div><div class="td-t" style="padding-right:0;padding-left:90px"><p style="$pstyle">$thread[title]</p>$summary <div class="cl"><em class="td-t-num" $color >{$thread['fields']['forumname']}</em> <em class="td-t-num">{$thread['fields']['author']}</em>  <em class="td-t-num">$lastpost</em><span class="$class">$num</span></div></div></a></li>
LI;
    }
    $list .= '</ul>';

    if($card['var']['title_link']){
//        $list .= '<a href="'.$title_link.'" class="news-more" style="margin:10px 10px 0">'.xigua_diyc::l('showmore',0).'</a>';
    }
    $card['var']['html'] = $header.$list;
    return $card;
}