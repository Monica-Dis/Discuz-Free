<?php !defined('IN_DISCUZ') && exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:43
 */
return array(
    'modulename' => xigua_diyc::l('article', 0).xigua_diyc::l('slider', 0),
    'introduce' => xigua_diyc::l('article', 0).xigua_diyc::l('slider', 0),
    'icon' => 'source/plugin/xigua_diy/template/cards/slidera/images/article.png',
    'preview' => '',
    'version' => '1.0.0',
    'lock' => 0,
    'open' => 1, 'js' => '', 'src' => '',
    'tpl' => '{html}',

    'css' => <<<CSS
.swipe {overflow: hidden;visibility: hidden;position: relative}
.swipe-wrap {overflow: hidden;position: relative}
.swipe-wrap > div {float: left;width: 100%;position: relative}
.swipe-wrap .i{background-repeat: no-repeat;background-size: cover;background-position: center center;width:100%}
.bullets {position: absolute;right:10px;bottom: 0;height:26px;line-height:26px;color:#fff;font-size:12px}
.bullets em:first-child{color:#74BA35}
.position {text-align:right}
.position li {display: inline-block;width: 6px;height: 6px;border-radius: 3px;background: #FFF;margin: 0 1px}
.position li.current{background:#74BA35}
.swipe-title{position: absolute;left: 0;right: 0;bottom: 0;padding: 0 14px;font-size: 14px;font-weight: normal;background: rgba(0,0,0,0.6);height: 26px;line-height: 26px;}
.swipe-title a{color: #FFF;text-shadow: 1px 1px 0 #000}
CSS

);