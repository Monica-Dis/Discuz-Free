<?php
!defined('IN_DISCUZ') && exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:02
 */
function process_sliderc($card)
{
    $h = is_numeric($card['var']['height']) ? ($card['var']['height']) .'px' : $card['var']['height'];
    $div = "<div class=\"swipe-wrap\" style='height:$h'>";

    $bullets1 = !$card['var']['showtitle'] ? 'bullets1' : '';
    $pos2 = !$card['var']['showtitle'] ? 'position2' : '';
    $nav = '<nav class="bullets '.$bullets1.'"><ul class="position '.$pos2.'">';
    $i = 0;

    foreach ($card['var']['img'] as $k => $v) {
        if($v){
            $link = $card['var']['link'][$k];
            $src = $card['var']['img'][$k];
            $title = $card['var']['name'][$k];
            $div .= "<div><a href=\"$link\"><div class='i' style='height:$h;background-image:url($src)'></div></a>".
                ($card['var']['showtitle'] ? "<div class=\"swipe-title\"><a href=\"$link\">$title</a></div>" : '')
                ."</div>";

            if($k == 0){
                $nav .= '<li class="current"></li>';
            }else{
                $nav .= '<li></li>';
            }
            $i ++;
        }
    }
    $div .= '</div>';
    $nav .= '</nav>';

    $nav = $card['var']['pointer'] ? "<nav class=\"bullets $bullets1\"><em>1</em>/<em>$i</em></nav>" : $nav;
    $card['var']['html'] = '<div class="swipe cl">'.$div.$nav .'</div>';

    return $card;
}