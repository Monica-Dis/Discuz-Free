<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include xp_display('header');
include xp_display('js');

$id = $p['id'];
$title = $p['modulename'] . ' ' . $id;
$v = $p['value'];
$names = $p['value']['name'] ? $p['value']['name'] : array();
$imgs = $p['value']['img'] ? $p['value']['img'] : array();
$links = $p['value']['link'] ? $p['value']['link'] : array();
$p = $p['var'];

?>
<style> .imgsp img {height:30px;vertical-align:middle}</style>
<div class="form">
    <form id="form" <?php if($form_charset){?>accept-charset="<?php echo $form_charset ?>"<?php }?> action="<?php echo $actionsaveurl; ?>" method="POST">
    <table class="table_purview">
        <input type="hidden" name="formhash" value="<?php echo FORMHASH ?>"/>
        <input type="hidden" name="cid" value="<?php echo $id ?>"/>
        <tr>
            <th><?php xigua_diyc::l('sliderheight')?></th>
            <td>
                <input type="text" class="mini" name="row[height]" value="<?php echo $v['height'] ? $v['height'] : '200'?>" /> px
            </td>
        </tr>
        <tr>
            <th><?php xigua_diyc::l('pointer')?></th>
            <td>
                <label for="randomid_27">
                    <input type="radio" name="row[pointer]" id="randomid_27" <?php if($v['pointer'] == '1' ){echo 'checked ';}?>value="1"><?php xigua_diyc::l('pointer_1')?>
                </label>
                <label for="randomid_28">
                    <input type="radio" name="row[pointer]" id="randomid_28" <?php if(!$v['pointer'] ){echo 'checked ';}?>value="0"><?php xigua_diyc::l('pointer_2')?>
                </label>
            </td>
        </tr>
        <tr>
            <th><?php xigua_diyc::l('showtitle')?></th>
            <td>
                <select style="width:112px" name="row[showtitle]" class="txt">
                    <option value="0" <?php echo !$v['showtitle']?'selected':''; ?>><?php lang_diy('no');?></option>
                    <option value="1" <?php echo $v['showtitle']?'selected':''; ?>><?php lang_diy('yes');?></option>
                </select>
            </td>
        </tr>
        <?php foreach ($names as $k => $vv) { ?>
            <tr>
                <th><?php echo  ($k == 0 )? xigua_diyc::l('nav_list', 0) : '&nbsp;';?></th>
                <td>
                    <input type="text" class="mini" placeholder="<?php xigua_diyc::l('navname')?>" name="row[name][]" value="<?php echo $vv?>" />

                    <input name="xiguafile[]" class="file" type="file" onchange="return ajaxFileUpload1(this);" style="opacity:1;background:none;position:relative"  />
                    <span class="imgsp"><img src="<?php echo $p['img'][$k]?>" /> </span>
                    <input class="imgsh" name="row[img][]" type="hidden" value="<?php echo $p['img'][$k]?>">

                    <input type="text" class="normal2" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="<?php echo $links[$k]?>">
                    <a class="del" onclick="deleterow(this)">x</a>
                </td>
            </tr>
        <?php } ?>
        <tr>
            <th>&nbsp;</th>
            <td>
                <button type="button" class="button1" onclick="addrow(this,0);picker();"><?php xigua_diyc::l('add');?></button>
            </td>
        </tr>
        <tr>
            <th>&nbsp;</th>
            <td>
                <button class="button2 "><?php xigua_diyc::l('save') ?></button>
            </td>
        </tr>
    </table>
    </form>
</div>
<script>
    var rowtypedata = [[
        [1, '&nbsp;', 'th'],
        [1, '<input type="text" class="mini" placeholder="<?php xigua_diyc::l('navname')?>" name="row[name][]" value="" />\
        <input name="xiguafile[]" class="file" type="file" onchange="return ajaxFileUpload1(this);" style="opacity:1;background:none;position:relative" />\
        <span class="imgsp"></span>\
        <input class="imgsh" name="row[img][]" type="hidden" value="">\
        <input type="text" class="normal2" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="">\
    <a class="del" onclick="deleterow(this)">x</a>']
    ]];
    var dialog = top.dialog.get(window);
    $(function () {
        dialog.title('<?php echo $title;?>');
        dialog.height(400);
    });

    function ajaxFileUpload1(obj) {
        obj.id = 'xiguafile';
        obj.name = 'xiguafile';
        $.ajaxFileUpload({
            url:actionurl,
            secureuri:false,
            fileElementId:'xiguafile',
            dataType: 'json',
            data:{ac:'upload', formhash:FORMHASH},
            success: function (data, status){
                var ob = $('#xiguafile');
                if(typeof(data.errno) != 'undefined' && data.errno != 0){
                    ob.next().html(data.error);
                }else{
                    ob.parent().find('.imgsp').html('<img src="'+data.error+'" />');
                    ob.parent().find('.imgsh').val(data.error);
                }
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            },
            error: function (data, status, e){
                var ob = $('#xiguafile');
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            }
        });
        return false;
    }
</script>
</body></html>