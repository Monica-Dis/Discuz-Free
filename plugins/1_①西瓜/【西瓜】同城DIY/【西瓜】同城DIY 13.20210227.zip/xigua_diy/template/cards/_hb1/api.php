<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$config = $_G['cache']['plugin']['xigua_hb'];
$hs_config = $_G['cache']['plugin']['xigua_hs'];
$where = array('display=1 AND endts>' . TIMESTAMP);
if ($_GET['hb']) {
    $where[] = 'hb_num>0 and hb_num>hb_sendnum ';
}
$_GET['catid'] = dintval($_GET['catid'], 1);
if ($_GET['catid']) {
    $where[] = ' catid IN(' . implode(',', $_GET['catid']) . ') ';
}
if ($orderby = $_GET['orderby']) {
    if ($orderby == 'hot') {
        $ob = ' views desc ';
    } elseif ($orderby == 'new') {
        $ob = ' up_time DESC ';
    } elseif ($orderby == 'img') {
        $ob = '';
        $where[] = " imglist!='' ";
    } elseif ($orderby == 'dig') {
        $ob = '';
        $where[] = " dig_endts>0 ";
    } else {
        $ob = '';
    }
}

if($zdid = array_filter(explode(',', $_GET['zdid']))){
    if($zdid){
        $wherenew[] = ' id in ('.implode(',', $zdid).')';
    }
    $where = $wherenew;
}
$start_limit = 0;
$lpp = $_GET['items'];
$list = C::t('#xigua_hb#xigua_hb_pub')->fetch_all_bypage_pub($where, $start_limit, $lpp, $ob);
$pubids = $catids = $uids = array();
foreach ($list as $index => $item) {
    $uids[]   = $item['uid'];
    $catids[] = $item['catid'];
    $pubids[] = $item['id'];
}
if ($uids) {
    $users = DB::fetch_all('SELECT uid,username FROM %t WHERE uid IN (%n)', array('common_member', $uids), 'uid');
    if ($_G['cache']['plugin']['xigua_hr']['showg']) {
        $veris1 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids);
        $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris($uids, 2);
    }
    if ($_G['cache']['plugin']['xigua_hr']['showb']) {
        $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
    }
}
if ($catids) {
    $cats = DB::fetch_all('SELECT id,`name`,icon,telpri,closeicon,hidereal FROM %t WHERE id IN (%n)', array('xigua_hb_cat', $catids), 'id');
}
if ($_G['uid'] > 0) {
    $viewtels = C::t('#xigua_hb#xigua_hb_viewtel')->fetch_by_uid_ids($_G['uid'], $pubids);
    $vots = C::t('#xigua_hb#xigua_hb_votelog')->fetch_by_uid_pubids($_G['uid'], $pubids);
}
include template('xigua_diy:touch/header_ajax');
include template('xigua_hb:touch/'.$_GET['template']);
include template('xigua_diy:touch/footer_ajax');