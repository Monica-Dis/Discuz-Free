<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$config = $_G['cache']['plugin']['xigua_hb'];
$hs_config = $_G['cache']['plugin']['xigua_hs'];
$pt_config = $_G['cache']['plugin']['xigua_pt'];
$start_limit = 0;
$lpp = $_GET['items'];

$field = '*';
$order_by = '';

$where = $wherenew = array();
$where[] = "stat=1";
$_GET['catid'] = dintval($_GET['catid'], 1);
if($_GET['catid']){
    $where[] = ' hangye_id1 IN('.implode(',', $_GET['catid']).') ';
}
if($zdid = array_filter(explode(',', $_GET['zdid']))){
    $wherenew[] = "stat=1";
    if($zdid){
        $wherenew[] = ' id in ('.implode(',', $zdid).')';
    }
    $where = $wherenew;
}
$order_by = 'id desc';
switch($_GET['orderby']){
    case 'new':
        $order_by = 'id desc';
        break;
    case 'sellnum':
        $order_by = 'sellnum desc , id desc';
        break;
    case 'zonghe':
    default:
        $order_by = 'displayorder desc , id desc';
        break;
}
$list = C::t('#xigua_pt#xigua_pt_good')->fetch_all_by_where($where, $start_limit, $lpp,$order_by);

include template('xigua_diy:touch/header_ajax');
include template('xigua_diy:touch/_pt_list');
include template('xigua_diy:touch/footer_ajax');