<?php
!defined('IN_DISCUZ') && exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:02
 */
function process_imagea($card)
{
    if(!in_array($card['var']['script'], array(
        'articlehot',
        'articlespecified',
        'articlenew',
    ))){
        $card['var']['script'] = 'articlehot';
    }
    $class_name = 'block_' . $card['var']['script'];
    require_once libfile($class_name, 'class/block/portal');
    $card['block_class'] = new $class_name();

    $param = $card['var']['param'];
    $param['items'] = intval($card['var']['param']['items']);
    $param['picrequired'] = '1';

    $data = $card['block_class']->getdata(array(), $param);
    unset($card['block_class']);
    $threads = isort_by_aids($data, $param);

    $div = '';

    foreach ($threads as $k => $v) {
        $link = iportal_article_link($v['id']);
        $src  = xigua_diyc::get_picurl($v['pic'], $card['var']['thumb']);
        $div .= "<li><a href='$link' style='background-image:url($src)'><span class='image-tit'>$v[title]</span></a></li>";
    }

    $color = $card['var']['title_color'] ? 'style="font-size: 23px;margin-left: 12px;overflow: hidden;color:'.$card['var']['title_color'].'"' : 'font-size: 23px;margin-left: 12px;overflow: hidden;';
    $title = $card['var']['title'];

    $id = $card['type'].'-'.$card['id'];
    $style = '<style>#'.$id.'{width:'.(160*count($threads)+10).'px}</style>';

    $div = $style.'<h3 '.$color.'>'.$title.'</h3><div class="image-wrapper"><div id="'.$id.'" class="image-scroller"><ul class="image-list">'.$div.'</ul></div></div>';
    $card['var']['html'] = $div;

    return $card;
}



function isort_by_aids($data, $param)
{
    $threads = array();
    if($param['aids']){
        $tmp = array();
        foreach ($data['data'] as $value) {
            $tmp[$value['id']] = $value;
        }
        $tids = array_filter(explode(',', $param['aids']));
        foreach ($tids as $tid) {
            if($tmp[$tid]){
                $threads[] = $tmp[$tid];
            }
        }
    }else{
        $threads = $data['data'];
    }

    return $threads;
}
function iportal_article_link($aid){
    global $_G;
    return rtrim($_G['siteurl'],'/').'/portal.php?mod=view&aid='.$aid;
}