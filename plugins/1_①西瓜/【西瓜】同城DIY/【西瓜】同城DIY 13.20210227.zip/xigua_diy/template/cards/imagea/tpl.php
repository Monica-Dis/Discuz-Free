<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include xp_display('header');
include xp_display('js');

$id = $p['id'];
$title = $p['modulename'] . ' ' . $id;
$v = $p['value'];


$cats[] = array(0, xigua_diyc::l('article_allcat', 0));
loadcache('portalcategory');
foreach($_G['cache']['portalcategory'] as $value) {
    if($value['level'] == 0) {
        $cats[] = array($value['catid'], $value['catname']);
        if($value['children']) {
            foreach($value['children'] as $catid2) {
                $value2 = $_G['cache']['portalcategory'][$catid2];
                $cats[] = array($value2['catid'], '-- '.$value2['catname']);
                if($value2['children']) {
                    foreach($value2['children'] as $catid3) {
                        $value3 = $_G['cache']['portalcategory'][$catid3];
                        $cats[] = array($value3['catid'], '---- '.$value3['catname']);
                    }
                }
            }
        }
    }
}

?>
<div class="form">
    <form id="form" <?php if($form_charset){?>accept-charset="<?php echo $form_charset ?>"<?php }?> action="<?php echo $actionsaveurl; ?>" method="POST">
    <table class="table_purview">
        <input type="hidden" name="formhash" value="<?php echo FORMHASH ?>"/>
        <input type="hidden" name="cid" value="<?php echo $id ?>"/>
        <tr>
            <th><?php xigua_diyc::l('title')?></th>
            <td>
                <span class="J_color_pick color_pick"><em style="background:<?php echo $v['title_color'] ?>"></em></span>
                <input name="row[title_color]" type="hidden" class="J_hidden_color bgcolor" value="<?php echo $v['title_color'] ?>">
                <input type="text" name="row[title]" class="mini" value="<?php echo $v['title']?>"  />
            </td>
        </tr>
        <tr>
            <th><?php xigua_diyc::l('showthumb')?></th>
            <td>
                <label for="randomid_25"><input type="radio" name="row[thumb]" id="randomid_25" <?php if($v['thumb'] == '1' ){echo 'checked ';}?>value="1"><?php xigua_diyc::l('yes')?></label>
                <label for="randomid_26"><input type="radio" name="row[thumb]" id="randomid_26" <?php if(!$v['thumb'] ){echo 'checked ';}?>value="0"><?php xigua_diyc::l('no')?></label>
            </td>
        </tr>






        <tr>
            <th width="80"><?php xigua_diyc::l('article_from')?></th>
            <td> <select name="row[script]" onchange="return change_tids(this);" class="ps">
                    <option <?php if($v['script'] == 'articlehot'){echo 'selected';}?> value="articlehot" selected=""><?php xigua_diyc::l('article_hot')?></option>
                    <option <?php if($v['script'] == 'articlespecified'){echo 'selected';}?> value="articlespecified"><?php xigua_diyc::l('article_specified')?></option>
                    <option <?php if($v['script'] == 'articlenew'){echo 'selected';}?> value="articlenew"><?php xigua_diyc::l('article_new')?></option>
                </select>
            </td>
        </tr>
        <tr class="ipe" <?php if($v['script'] != 'articlespecified'){ echo 'style="display:none"';}?>>
            <th><?php xigua_diyc::l('article_id')?></th>
            <td>
                <input id="tids" type="text" class="normal" name="row[param][aids]" value="<?php echo $v['param']['aids']?>" placeholder="<?php xigua_diyc::l('article_iddesc')?>" />
            </td>
        </tr>
        <tr class="vt">
            <th><?php xigua_diyc::l('article_cat')?></th>
            <td>
                <select name="row[param][catid][]" multiple="multiple" size="10" style="height:80px;width:300px">
                    <?php foreach ($cats as $cat) {
                        $checked = in_array($cat[0], $v['param']['catid']) ? 'selected' : '';
                        echo "<option $checked value='$cat[0]'>$cat[1]</option>";
                    }
                    ?>
                </select>
            </td>
        </tr>
        <tr class="vt">
            <th><?php xigua_diyc::l('article_order')?></th>
            <td>
                <ul class="pr">
                    <li class="checked">
                        <label for="randomid_3"><input type="radio" name="row[param][orderby]" id="randomid_3" class="pr" value="viewnum" <?php if(!$v['param']['orderby'] || $v['param']['orderby'] =='viewnum'){echo 'checked';}?>  /><?php xigua_diyc::l('article_order1')?></label>
                    </li>
                    <li>
                        <label for="randomid_4"><input type="radio" name="row[param][orderby]" id="randomid_4" class="pr" value="commentnum" <?php if($v['param']['orderby'] =='commentnum'){echo 'checked';}?>  /><?php xigua_diyc::l('article_order2')?></label>
                    </li>
                    <li>
                        <label for="randomid_5"><input type="radio" name="row[param][orderby]" id="randomid_5" class="pr" value="dateline" <?php if($v['param']['orderby'] =='dateline'){echo 'checked';}?>  /><?php xigua_diyc::l('article_order3')?></label>
                    </li>
                </ul>
            </td>
        </tr>
        <tr class="vt">
            <th><?php xigua_diyc::l('article_title')?></th>
            <td><input type="text" name="row[param][titlelength]" class="short" value="<?php echo $v['param']['titlelength'] ?$v['param']['titlelength']:80 ?>" /></td>
        </tr>

        <tr>
            <th><?php xigua_diyc::l('article_item')?></th>
            <td><input type="text" name="row[param][items]" value="<?php echo $v['param']['items']?$v['param']['items']:10 ?>" class="short"  /></td>
        </tr>












        <tr>
            <th>&nbsp;</th>
            <td>
                <button class="button2 "><?php xigua_diyc::l('save') ?></button>
            </td>
        </tr>
    </table>
    </form>
</div>
<script>
    var dialog = top.dialog.get(window);
    $(function () {
        dialog.title('<?php echo $title;?>');
        dialog.height(370);
    });
</script>
</body></html>