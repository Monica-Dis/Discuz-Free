<?php
!defined('IN_DISCUZ') && exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:02
 */

function process_search($card)
{
    global $_G;
    $charset = CHARSET;
    $param = $card['var']['param'];
    $cardid = $card['id'];
    $t = $th = array();

    if($height = intval($card['var']['height'])){
        $t[] = 'height:'.$height.'px;';
        $th[] = 'height:'.($height-10).'px;line-height:'.($height-10).'px;';
    }

    $radius = intval($card['var']['radius']);
    if($radius){
        $v[] = "border-radius:0 {$radius}px {$radius}px 0;";
//        $t[] = "border-radius:{$radius}px 0 0 {$radius}px;";
        $th1[] = "border-radius:{$radius}px 0 0 {$radius}px;";
    }

    if($sboxcolor = $card['var']['sboxcolor']){
        $t[] = "background:$sboxcolor;";
        $t2[] = "background:$sboxcolor;";
    }
    if($sbtncolor = $card['var']['sbtncolor']){
        $v[] = "color:$sbtncolor;";
    }

    $t = 'style="'.implode('', $t) .'""';
    $t2 = 'style="'.implode('', $t2) .'""';
    $v = 'style="'.implode('', $v) .'""';
    $th = 'style="'.implode('', $th) .'""';
    $th1 = 'style="'.implode('', $th1) .'""';

    $dizhi = $card['var']['dizhi'];
    if(!$dizhi){
        $dizhi = 'plugin.php?id=xigua_hb&ac=cat';
    }
    if(strpos($dizhi, 'search.php?mod=forum')!==false){
        $kefield = 'srchtxt';
    }else{
        $kefield = 'keyword';
    }
    $dizhi = parse_url($dizhi);
    $acti = $dizhi['path'];
    $dizhi['query'] = str_replace('&amp;', '&', $dizhi['query']);
    parse_str($dizhi['query'], $queries);
//    print_r($dizhi['query']);
//    print_r($queries);
//    exit;
    $header = <<<H
<form $t class="s" method="GET" autocomplete="off" action="{$acti}"><input type="hidden" value="yes" name="searchsubmit">
H;
    foreach ($queries as $index => $query) {
        $header .= "<input type=\"hidden\" value=\"$query\" name=\"$index\">";
    }

    $yutian = $card['var']['yutian'];
    $ss = $card['var']['searchkey'] ? $card['var']['searchkey'] : lang_diy('ss',0);

    $card['var']['html'] = <<<HTML
$header <input type="hidden" value="true" name="searchsubmit"> <input type="hidden" value="mh" name="source"><input type="hidden" value="" name="formhash"><div class="w">
    <div $th1 class="t"><input $th type="search" autocomplete="off" autocorrect="off" maxlength="64" name="$kefield" class="u" placeholder="$yutian"></div><button type="submit" class="v" $v>$ss</button></div></form>
HTML;

    return $card;
}