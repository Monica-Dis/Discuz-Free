<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$config = $_G['cache']['plugin']['xigua_hb'];
$hs_config = $_G['cache']['plugin']['xigua_hs'];
$hm_config = $_G['cache']['plugin']['xigua_hm'];
$start_limit = 0;
$lpp = $_GET['items'];

$field = '*';
$order_by = '';

if(in_array($_GET['stype'], array('seckill','youhui','daijin','zhekou', 'quan'))){
    $stype = $_GET['stype'];
}else{
    $stype = 'seckill';
}

if($stype =='quan'){
    $where = array("stype<>'seckill'");
    $order_by = ' displayorder desc, id desc';
}else {
    $where = array("stype='$stype'");
    $order_by = ' displayorder desc, id desc';
}

if($zdid = array_filter(explode(',', $_GET['zdid']))){
    if($zdid){
        $where[] = ' id in ('.implode(',', $zdid).')';
    }
}else{
    if($cat_id = dintval($_GET['hyid'], 1)){
        $cat_ids = implode(',', $cat_id);
        if($cat_id){
            $where[] =  "(hangye_id1 in ($cat_ids) or hangye_id2 in ($cat_ids))";
        }
    }
    $where[] = ' (status=2 AND stock>0 AND (endtime=0 OR endtime>' . TIMESTAMP.')) ';
}

$list = C::t('#xigua_hm#xigua_hm_seckill')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);
if($_G['uid']>0){
    $secids = array();
    foreach ($list as $index => $item) {
        $secids[] = intval($item['id']);
    }
    if($secids){
        $hads = C::t('#xigua_hm#xigua_hm_seckill_log')->fetch_all_by_where(
            array('uid='.$_G['uid'].' and status=2 AND secid in('.implode(',', $secids).')'),
            0, $lpp, '','id,secid','secid'
        );
    }
}

$stypes = array('youhui' => lang_hm('youhui',0),'daijin'=>lang_hm('daijin',0),'zhekou'=>lang_hm('zhekou',0),'seckill' => lang_hm('seckill',0));
$statuss = array(
    '0' => lang_hm('shwg',0),
    '1' => lang_hm('ddsh',0),
    '2' => lang_hm('ysj',0),
    '3' => lang_hm('yxj',0)
);
$itemwidth = count($list) * 135;
include template('xigua_diy:touch/header_ajax');
include template('xigua_diy:touch/_hm1_list1');
include template('xigua_diy:touch/footer_ajax');