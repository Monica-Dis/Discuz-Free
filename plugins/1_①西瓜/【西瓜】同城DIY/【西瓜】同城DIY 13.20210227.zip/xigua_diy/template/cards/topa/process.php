<?php
!defined('IN_DISCUZ') && exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:02
 */
function process_topa($card)
{
    if(!in_array($card['var']['script'], array(
        'articlehot',
        'articlespecified',
        'articlenew',
    ))){
        $card['var']['script'] = 'articlehot';
    }
    $class_name = 'block_' . $card['var']['script'];
    require_once libfile($class_name, 'class/block/portal');
    $card['block_class'] = new $class_name();

    $param = $card['var']['param'];
    $data = $card['block_class']->getdata(array(), $param);
    unset($card['block_class']);
    $threads = topa_by_aids($data, $param);
    

    if(!$threads){
        return $card;
    }

    $div = "";
    $first = array_shift($threads);

    if($card['var']['topcolor']){
        $topcolor = 'style="color:'.$card['var']['topcolor'].'"';
        $iconcolor = 'style="background-color:'.$card['var']['topcolor'].'"';
    }
    $icon = $card['var']['showicon'] ? '<em '.$iconcolor.'>'.xigua_diyc::l('topicon', 0).'</em>' : '';
    $link = topa_article_link($first['id']);
    $div .= '<h2 class="topline_p_h2"><a '.$topcolor.' href="'.$link.'">'.$icon.$first['title'].'</a></h2>';

    foreach ($threads as $k => $v) {
        $div .= '<p class="topline_p_mate">';
        $link = topa_article_link($v['id']);
        if($card['var']['showkuo']){
            $v['title'] = '['.$v['title'].']';
        }
        $a = '<a href="'.$link.'">'.$v['title'].'</a>';
        $div .= $a;
        $div .= '</p>';
    }

    $card['var']['html'] = '<div class="topline_p">'.$div .'</div>';

    return $card;
}

function topa_by_aids($data, $param)
{
    $threads = array();
    if($param['aids']){
        $tmp = array();
        foreach ($data['data'] as $value) {
            $tmp[$value['id']] = $value;
        }
        $tids = array_filter(explode(',', $param['aids']));
        foreach ($tids as $tid) {
            if($tmp[$tid]){
                $threads[] = $tmp[$tid];
            }
        }
    }else{
        $threads = $data['data'];
    }

    return $threads;
}
function topa_article_link($aid){
    global $_G;
    return rtrim($_G['siteurl'],'/').'/portal.php?mod=view&aid='.$aid;
}