<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
function process__hs2($card)
{
    $param = $card['var']['param'];
    $cardid = $card['id'];

    if($card['var']['title'] || $card['var']['subtitle']) {
        $title_link = $card['var']['title_link'] ? $card['var']['title_link'] : 'javascript:void(0);';
        $header = '<div class="news-t" ' . '><h3>' .
            '<a ' . ' href="' . $title_link . '">' . $card['var']['title'] . '</a></h3>';
        if ($card['var']['subtitle']) {
            $header .= '<nav class="tmore">';
            foreach ($card['var']['subtitle'] as $i => $subtitle) {
                $header .= '<a ' . $color . ' href="' . $card['var']['subtitle_link'][$i] . '">' . $subtitle . '</a>';
            }
            $header .= '</nav>';
        }
        $header .= '</div>';
    }


    $config = $_G['cache']['plugin']['xigua_hb'];
    $hs_config = $_G['cache']['plugin']['xigua_hs'];
    $viewtype = $param['viewtype'];
    if(!$viewtype){
        $viewtype = $orderby = $param['orderby'];
    }
    $field = '*';
    $where = array();
    if($hs_config['showguoqi']){
        $where[] = 'display=1 AND endts>0';
    }else{
        $where[] = 'display=1 AND endts>='.TIMESTAMP;
    }
    if($param['hb']){
        $where[] = 'hong_num>0 AND hong_num>hong_sendnum';
    }
    $orary = C::t('#xigua_hs#xigua_hs_shanghu')->get_order($viewtype);
    $order_by = $orary['order_by'];
    $field = $orary['field'];

    if($param['hyid']){
        $param['hyid'] = dintval($param['hyid'], 1);
        $where[] = ' hangye_id2 IN('.implode(',', $param['hyid']).')  ';
    }

    $start_limit = 0;
    $lpp = $param['items'];
    if($shids = array_filter(explode(',', $param['shid']))){
        $wherenew = array();
        if($hs_config['showguoqi']){
            $wherenew[] = 'display=1 AND endts>0';
        }else{
            $wherenew[] = 'display=1 AND endts>='.TIMESTAMP;
        }
        $shids = dintval($shids, 1);
        if($shids){
            $wherenew[] = ' shid in ('.implode(',', $shids).')';
        }
        $list = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($wherenew, $start_limit, $lpp, $order_by, $field);
    }else{
        $list = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);
    }

    $shwidth = count($list)*98-80;
    $shwidth = max($shwidth, 200);
    $listhtml = '';
    include template('xigua_diy:touch/_hs2_list2');
    $card['var']['html'] = $header.$listhtml;

    return $card;
}
