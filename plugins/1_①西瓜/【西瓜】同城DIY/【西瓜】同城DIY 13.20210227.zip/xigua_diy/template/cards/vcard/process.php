<?php
!defined('IN_DISCUZ') && exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:02
 */
function process_vcard($card)
{
    $h = $card['var']['h'] ? intval($card['var']['h']) .'px' : '100%';
    $ha = intval($card['var']['ha']) .'px';
    $num = intval($card['var']['linenum']);

    $w = 100/$num;
    $divs = array();
    $i = $j = 0;

    foreach ($card['var']['imgs'] as $k => $v) {
        $link = $card['var']['link'][$k];
        $src = $card['var']['imgs'][$k];
        $divs[$j][] .= "<a class='vcardlist' style='float:left;width:$w%;height:$h;text-align:center;' href=\"$link\"><img style='display:block;max-width:100%;height:$h;margin:0 auto' src='$src'/> </a>";
        $i ++;
        if($i%$num==0){
            $j++;
        }
    }
    $html = '';
    foreach ($divs as $div) {
        $html .= '<div class="cl" style="margin-bottom:'.$ha.'">'.implode('', $div) .'</div>';
    }


    $card['var']['html'] = "<div class='imgnav'>".$html."</div>";

    return $card;
}