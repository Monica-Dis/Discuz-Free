<?php !defined('IN_DISCUZ') && exit('Access Denied');
/**
 * Created by PhpStorm.
 * User: yangzhiguo
 * Date: 15/3/15
 * Time: 11:43
 */
return array(
    'modulename' => xigua_diyc::l('navi', 0),
    'introduce'  => xigua_diyc::l('navi', 0),
    'icon'       => 'source/plugin/xigua_diy/template/cards/image/images/1.png',
    'preview'    => '',
    'version'    => '1.0.0',
    'lock'       => 0,
    'open'       => 1,
    'js'         => <<<JS

JS
,
    'src'        => '',
    'tpl'        => '{html}',
    'css'        => <<<CSS
.imgnav{}
.imgnav>div:last-child{margin-bottom:0!important;}
.vcardlist{position:relative}
.vcardlist:after{content:" ";position:absolute;left:0;bottom:0;top:0;height:100%;width:1px;border-left:1px solid #eee;color:#eee;-webkit-transform-origin:0 0;transform-origin:0 0;-webkit-transform:scaleX(.5);transform:scaleX(.5)}
CSS
);