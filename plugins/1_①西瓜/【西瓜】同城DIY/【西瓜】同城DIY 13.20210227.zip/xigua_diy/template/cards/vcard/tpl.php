<?php
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
include xp_display('header');
include xp_display('js');

$id = $p['id'];
$title = $p['modulename'] . ' ' . $id;
$v = $p['value'];
$names = $p['value']['name'] ? $p['value']['name'] : array('');
$imgs = $p['value']['img'] ? $p['value']['img'] : array('');
$links = $p['value']['link'] ? $p['value']['link'] : array('');

$p = $p['var'];

?>
<style> .imgsp img {height:30px;vertical-align:middle}</style>
<div class="form">
    <form id="form" <?php if($form_charset){?>accept-charset="<?php echo $form_charset ?>"<?php }?> action="<?php echo $actionsaveurl; ?>" method="POST" enctype="multipart/form-data">
    <table class="table_purview">
        <input type="hidden" name="formhash" value="<?php echo FORMHASH ?>"/>
        <input type="hidden" name="cid" value="<?php echo $id ?>"/>


        <tr>
            <th><?php lang_diy('margin',1)?></th>
            <td>
                <input type="text" class="normal"  name="row[ha]" value="<?php echo intval($p['ha'])?>" />px
            </td>
        </tr>
        <tr>
            <th><?php echo lang('admincp', 'adv_edit_style_image_height') ?></th>
            <td>
                <input type="text" class="normal"  name="row[h]" value="<?php echo intval($p['h'])?>" />px
            </td>
        </tr>
        <tr>
            <th><?php xigua_diyc::l('perline_num') ?></th>
            <td>
                <input type="text" class="normal"  name="row[linenum]" value="<?php echo $p['linenum'] ? $p['linenum'] : 2?>" />
            </td>
        </tr>
        <?php foreach ($p['imgs'] as $k => $vv) { ?>
            <tr>
                <th><?php echo  ($k == 0 )? xigua_diyc::l('nav_list', 0) : '&nbsp;';?></th>
                <td>

                    <input name="xiguafile[]" class="file" type="file" onchange="return ajaxFileUpload1(this);" style="opacity:1;background:none;position:relative"  />
                    <span class="imgsp"><img src="<?php echo $p['imgs'][$k]?>" /> </span>
                    <input class="imgsh" name="row[imgs][]" type="hidden" value="<?php echo $p['imgs'][$k]?>">

                    <input type="text" class="normal" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="<?php echo $p['link'][$k]?>">
                    <a class="del" onclick="deleterow(this)">x</a>
                </td>
            </tr>
        <?php } ?>
        <tr>
            <th>&nbsp;</th>
            <td>
                <button type="button" class="button1" onclick="addrow(this,0);picker();"><?php xigua_diyc::l('add');?></button>
            </td>
        </tr>
        <tr>
            <th>&nbsp;</th>
            <td>
                <button class="button2 "><?php xigua_diyc::l('save') ?></button>
            </td>
        </tr>
    </table>
    </form>
</div>
<script>
    var rowtypedata = [[
        [1, '&nbsp;', 'th'],
        [1, '<input name="xiguafile[]" class="file" type="file" onchange="return ajaxFileUpload1(this);" style="opacity:1;background:none;position:relative" />\
        <span class="imgsp"></span>\
        <input class="imgsh" name="row[imgs][]" type="hidden" value="">\
            <input type="text" class="normal" placeholder="<?php xigua_diyc::l('navlink')?>"  name="row[link][]" value="">\
    <a class="del" onclick="deleterow(this)">x</a>']
    ]];
    var dialog = top.dialog.get(window);
    $(function () {
        dialog.title('<?php echo $title;?>');
        dialog.height(400);
    });

    function ajaxFileUpload1(obj) {
        obj.id = 'xiguafile';
        obj.name = 'xiguafile';
        $.ajaxFileUpload({
            url:actionurl,
            secureuri:false,
            fileElementId:'xiguafile',
            dataType: 'json',
            data:{ac:'upload', formhash:FORMHASH},
            success: function (data, status){
                var ob = $('#xiguafile');
                if(typeof(data.errno) != 'undefined' && data.errno != 0){
                    ob.next().html(data.error);
                }else{
                    ob.parent().find('.imgsp').html('<img src="'+data.error+'" />');
                    ob.parent().find('.imgsh').val(data.error);
                }
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            },
            error: function (data, status, e){
                var ob = $('#xiguafile');
                ob.attr('id','');
                ob.attr('name','xiguafile[]');
            }
        });
        return false;
    }

</script>
</body></html>