<?php
/**
 * Copyright 2001-2099 DisM!Ӧ������.
 * This is NOT a freeware, use is subject to license terms
 * Ӧ�ø���֧�֣�https://dism.taobao.com
 * ���²����http://t.cn/Aiux1Jx1
 * Date: 2017/10/10
 * Time: 15:16
 */
if (!defined('IN_DISCUZ')) {
    exit('Access Denied');
}
$config = $_G['cache']['plugin']['xigua_hb'];
$hs_config = $_G['cache']['plugin']['xigua_hs'];
$viewtype = $_GET['viewtype'];
if(!$viewtype){
    $viewtype = $orderby = $_GET['orderby'];
}
$field = '*';
$where = array();
if($hs_config['showguoqi']){
    $where[] = 'display=1 AND endts>0';
}else{
    $where[] = 'display=1 AND endts>='.TIMESTAMP;
}
if($_GET['uid']){
    $where[] = 'uid='.intval($_GET['uid']);
}
if($_GET['hb']){
    $where[] = 'hong_num>0 AND hong_num>hong_sendnum';
}
$orary = C::t('#xigua_hs#xigua_hs_shanghu')->get_order($viewtype);
$order_by = $orary['order_by'];
$field = $orary['field'];

$extndsql = '';
$_GET['hyid'] = dintval($_GET['hyid'], 1);
if($_GET['hyid']){
    $where[] = '( hangye_id2 IN('.implode(',', $_GET['hyid']).') '.$extndsql.' )';
}

$start_limit = 0;
$lpp = $_GET['items'];
if($shids = array_filter(explode(',', $_GET['shid']))){
    $wherenew = array();
    if($hs_config['showguoqi']){
        $wherenew[] = 'display=1 AND endts>0';
    }else{
        $wherenew[] = 'display=1 AND endts>='.TIMESTAMP;
    }
    $shids = dintval($shids, 1);
    if($shids){
        $wherenew[] = ' shid in ('.implode(',', $shids).')';
    }
    $list = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($wherenew, $start_limit, $lpp, $order_by, $field);
}else{
    $list = C::t('#xigua_hs#xigua_hs_shanghu')->fetch_all_by_where($where, $start_limit, $lpp, $order_by, $field);
}

$shids = array();
foreach ($list as $index => $item) {
    $shids[] = $item['shid'];
}
if ($shids) {
    if ($_G['cache']['plugin']['xigua_hm']) {
        $s_shid = implode(',', $shids);
        $quanlist = C::t('#xigua_hm#xigua_hm_seckill')->fetch_all_by_where(array(
            "shid in ($s_shid)", 'gongkai=1', 'stype<>\'seckill\'', 'status=2 and (endtime=0 OR endtime>=' . TIMESTAMP . ')'
        ), 0, count($shids), 'stock desc', 'id,stype,shid,title,stock', 'group by shid', 'shid');
        $seclist = C::t('#xigua_hm#xigua_hm_seckill')->fetch_all_by_where(array(
            "shid in ($s_shid)", 'gongkai=1', 'stype=\'seckill\'', 'status=2 and (endtime=0 OR endtime>=' . TIMESTAMP . ')'
        ), 0, count($shids), 'stock desc', 'id,stype,shid,title,stock', 'group by shid', 'shid');
    }
    if ($_G['cache']['plugin']['xigua_he'] && $hs_config['huod_num'] > 0) {
        $helist = DB::fetch_all('select title,shid from %t where shid in(%n) and status=2 group by shid order by id desc limit '. count($shids), array(
            'xigua_he_huodong',
            $shids,
        ), 'shid');
    }
    if ($_G['cache']['plugin']['xigua_job'] && $hs_config['zpnum'] > 0) {
        $joblist = DB::fetch_all('select `name`,shid,`type` from %t where shid in(%n) and status=2 and endts>%d group by shid order by (dig_endts-dig_crts) DESC, upts DESC limit '. count($shids), array(
            'xigua_job_job', $shids, TIMESTAMP
        ), 'shid');
    }
}
if($_G['cache']['plugin']['xigua_hr']['showg'] || $_G['cache']['plugin']['xigua_hr']['showb'] ){
    $uids = $shids = array();
    foreach ($list as $index => $item) {
        $uids[] = $item['uid'];
        $shids[] = $item['shid'];
    }
    if($_G['cache']['plugin']['xigua_hr']['showg']){
        $veris2 = C::t('#xigua_hr#xigua_hr_verify')->fetch_veris_bysh($shids);
    }
    if($_G['cache']['plugin']['xigua_hr']['showb']){
        $bao = C::t('#xigua_hr#xigua_hr_paybao')->fetchb($uids);
    }
}

include template('xigua_diy:touch/header_ajax');
include template('xigua_hs:touch/myshop_li');
include template('xigua_diy:touch/footer_ajax');