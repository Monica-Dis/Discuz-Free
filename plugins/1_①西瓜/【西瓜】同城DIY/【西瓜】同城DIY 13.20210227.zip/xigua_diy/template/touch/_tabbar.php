<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
{block listhtml}
<footer class="tab_footer">
    <div class="tab_footer_tabbar">
        <!--{loop $list $_k $_v}-->
        <a class="tab_footer_tabbar_item" href="$_v[link]">
            <div class="tab_footer_tabbar_item__icon <!--{if $_v[up]}-->tabout<!--{/if}-->">
                <img src="{$_v[img]}">
            </div>
            <div class="tab_footer_tabbar_item__text">{$_v[name]}</div>
        </a>
        <!--{/loop}-->
    </div>
</footer>
{/block}