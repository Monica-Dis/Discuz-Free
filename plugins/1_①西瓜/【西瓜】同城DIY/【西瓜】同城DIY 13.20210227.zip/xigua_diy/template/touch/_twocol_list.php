<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
{block listhtml}
<div class="cl twolcol">
<!--{loop $list $_k $_v}-->
<div class="twocol_item">
    <a href="{$_v[link]}" class="twocol_item_in">
        <div class="hd">
            <div class="image-box">
                <img src="{$_v[img]}">
            </div>
            <!--{if $_v[sellnum]}-->
            <div class="hd_sale">{$_v[sellnum]}</div>
            <!--{/if}-->
        </div>
        <div class="bd">
            <div class="_top">
                <!--{if $_v[price]}-->
                <div>
                    <span class="now-price __normal"><span class="symbol">&yen;</span><span class="buck">{$_v[price]}</span></span>
                </div>
                <!--{/if}-->
                <!--{if $_v[shichang]}-->
                <div class="f12 c3">{$_v[shichang]}</div>
                <!--{/if}-->
            </div>
            <div class="twocol_item_desc">
                <div class="__title">{$_v[name]}</div>
            </div>
        </div>
    </a>
</div>
<!--{/loop}-->
</div>
{/block}