<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $k $v}-->
<div class="resume_li resume_jump cl border_bfull" data-id="$v[rsid]">
    <div class="resume_left">
        <div class="resume_logo"><img src="$v[avatar]" onerror="this.error=null;this.src='source/plugin/xigua_job/static/img/dftava.png'"></div>
        <i class="resume_gender g{$v[gender]}"></i>
    </div>
    <div class="resume_right">
        <div class="resume_realname cl">
            <span>{$v[realname]}</span>
            <!--{if $v[is_dig]}-->
            <span class="jbtn is_dig pr-1">{lang xigua_job:dig}</span>
            <!--{/if}-->
            <span class="resume_span">{$v[age]}{lang xigua_job:s}</span>
            <div class="resume_span resume_span_pos">
                <!--{loop $v[areawant_str_ary] $_k $_v}-->
                <span class="resume_spani">{$_v}</span>
                <!--{/loop}-->
            </div>
        </div>
        <div class="resume_p">
            <span class="resume_spani main_red ml0">{$v[paywant]}</span>
            <span class="resume_spani">{$v[jingyan]}</span>
            <span class="resume_spani">{$v[xueli]}</span>
        </div>
        <div class="resume_tag cl">
            <a class="bgf">{lang xigua_job:qw}</a>
            <!--{loop $v[jobwant_str_ary] $_k $_v}-->
            <a href="javascript:;">$_v</a>
            <!--{/loop}-->
        </div>
        <!--{if $viewlist[$v[rsid]]}-->
        <div class="resume_p f12 c3">
            {lang xigua_job:llsj}: $viewlist[$v[rsid]][upts_u]
        </div>
        <!--{/if}-->
    </div>
</div>
<!--{/loop}-->