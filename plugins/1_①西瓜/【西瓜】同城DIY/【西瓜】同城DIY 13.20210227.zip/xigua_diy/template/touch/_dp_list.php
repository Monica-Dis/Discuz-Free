<?php exit('https://dism.taobao.com/?ac=developer&id=7402');?>
<!--{loop $list $_k $_v}-->
<div class="dp_li dp_jump" data-id="$_v[cid]">
    <div class="dp_li_img">
        <img class="cov" src="$_v[cover]" />
        <!--{if $_v['video'] && is_file(DISCUZ_ROOT.'source/plugin/xigua_hb/api_qr.inc.php')}--><em class="emvdo"></em><!--{/if}-->
        <!--{if $_v['distance']}--><span class="km1">$_v['distance']</span><!--{/if}-->
    </div>
    <p class="tit">$_v[subject]</>
    <div class="cl usrr">
        <a href="javascript:;">
            <img class="avat" src="{$_v['avatar']}">
            $_v[author]
        </a>
        <a href="javascript:;"><img src="source/plugin/xigua_dp/static/img/zan.png" > $_v[zans]</a>
    </div>
</div>
<!--{/loop}-->