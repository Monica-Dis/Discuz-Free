<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $_GET[qgys]==1}-->
<!--{loop $list $v}-->
<div class="row_list">
    <div class="item">
        <a class="jump_sp" href="javascript:" data-id="{$v[id]}">
            <div class="cover bg_stamp">
                <img class="ll_fadeIn" src="{echo $v[fengmian] ? $v[fengmian] : ($v[album][0] ? $v[album][0] : $v[append_img_ary][0])}">
                <!--{if DB::result_first('SELECT sum(stock) FROM %t WHERE gid=%d', array('xigua_sp_good_price', $v[id]))<=0}-->
                <div class="sellout"></div>
                <img src="source/plugin/xigua_sp/static/shouqing.png?{VERHASH}" class="sellout_img">
                <!--{/if}-->
            </div>
            <div class="info">
                <div class="name">{$v[title]}</div>
                <div class="tags">
                    <!--{loop $v[srange_ary] $_v}-->
                    <span>{eval $rv= explode('#', $_v);echo $rv[0];}</span>
                    <!--{/loop}-->
                </div>
                <div class="price">
                <span>&yen;<em class="f16">{$v[tprice]}</em><!--{if $v[jifenprice]}-->
                    <em class="f12 main_color">$v[shortjifenprice]</em>
                    <!--{/if}--></span>
                    <del class="c9">&yen;{$v[disprice]}</del>
                </div>
                <div class="desc">{lang xigua_sp:yp}{$v[sellnum]}{lang xigua_sp:j}</div>
                <div class="btn">{lang xigua_sp:qpd}</div>
            </div>
        </a>
    </div>
</div>
<!--{/loop}-->
<!--{elseif $_GET[qgys]==3}-->
<!--{loop $list $v}-->
<li class="sp_new">
    <a href="$SCRITPTNAME?id=xigua_sp&ac=view&gid={$v[id]}{$urlext}">
        <div class="cardstyle_r">
            <div class="goodimg jump_sp" data-id="{$v[id]}">
                <img src="{echo $v[fengmian] ? $v[fengmian] : ($v[album][0] ? $v[album][0] : $v[append_img_ary][0])}" class="">
                <!--{if DB::result_first('SELECT sum(stock) FROM %t WHERE gid=%d', array('xigua_sp_good_price', $v[id]))<=0}-->
                <div class="sellout"></div>
                <img src="source/plugin/xigua_sp/static/shouqing.png?{VERHASH}" class="sellout_img">
                <!--{/if}-->
            </div>
            <div class="p57">
                <p class="goodtit f12 jump_sp" data-id="{$v[id]}">
                    {$v[title]}
                </p>
                <div class="tags jump_sp" data-id="{$v[id]}">
                    <!--{loop $v[srange_ary] $_v}-->
                    <span>{eval $rv= explode('#', $_v);echo $rv[0];}</span>
                    <!--{/loop}-->
                </div>
                <div class="goodflex jump_sp" data-id="{$v[id]}">
                    <span class="del_price f12">&yen;{$v[disprice]}</span>
                    <span class="f12 gray">{lang xigua_sp:yp}{$v[sellnum]}{lang xigua_sp:j}</span>
                </div>
                <div class="goodflex jump_sp" data-id="{$v[id]}">
                    <span class="main_color f16" style="white-space:nowrap"><em class="f10">&yen;</em>{$v[tprice]}
                        <!--{if $v[jifenprice]}-->
                    <em class="f12 main_color">$v[shortjifenprice]</em>
                        <!--{/if}--></span>
                    <!--{if $_GET[shid]}-->
                    <span class="stamp_three stamp_mini joingwc" data-shid="$v[shid]" data-gid="$v[id]" data-_price_id="{$v[gprice][id]}" data-_gid="{$v[id]}" data-_num="1"><i class="iconfont icon-gouwuchetianjia f12"></i> {lang xigua_sp:fqpt}</span>
                    <!--{else}-->
                    <!--{if $v[hkprice]>0}-->
                    <span class="hksp">{$_G['cache']['plugin']['xigua_hk']['cardname']}{lang xigua_sp:jia}{echo floatval($v[hkprice]);}</span>
                    <!--{else}-->
                    <span class="stamp_three stamp_mini">{lang xigua_sp:ljgm}</span>
                    <!--{/if}-->
                    <!--{/if}-->
                </div>
            </div>
        </div>
    </a>
</li>
<!--{/loop}-->
<!--{/if}-->