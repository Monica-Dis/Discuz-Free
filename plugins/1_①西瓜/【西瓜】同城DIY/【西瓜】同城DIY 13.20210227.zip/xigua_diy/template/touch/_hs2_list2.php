<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
{block listhtml}
<div class="modost mod-post x-postlist pt0 dp_index" id="card_$cardid">
<div class="sh_slider">
    <ul class="shangjia" style="width:{$shwidth}px">
        <!--{loop $list $shi}-->
        <li class="s_shangjia">
            <a href="$SCRITPTNAME?id=xigua_hs&ac=view&shid={$shi[shid]}">
                <div class="picture"><img src="{$shi[logo]}" onerror="this.error=null;this.src='source/plugin/xigua_hs/static/images/nologo.jpg'"></div>
                <span class="sh_name">{$shi[name]}</span>
            </a>
        </li>
        <!--{/loop}-->
    </ul>
</div>
</div>
{/block}