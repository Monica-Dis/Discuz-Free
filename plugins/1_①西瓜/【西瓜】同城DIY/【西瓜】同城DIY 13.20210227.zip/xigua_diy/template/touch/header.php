<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="{CHARSET}">
    <meta name="apple-mobile-web-app-capable" content="yes"/>
    <meta name="apple-mobile-web-app-status-bar-style" content="black"/>
    <meta content="telephone=no" name="format-detection"/>
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no"/>
    <title>{$title}</title>
    <meta name="keywords" content="{$keywords}">
    <meta name="description" content="{$description}">
    <link href="{$style}" type="text/css" rel="stylesheet"/>
    {$link}
<style type="text/css">{$css}.weui-dialog__btn, .weui-navbar__item.weui_bar__item_on, .color-strong, .chip-row .toutiao, .weui-cells_checkbox .weui-check:checked+.weui-icon-checked:before, .weui-vcode-btn, .weui-dialog__btn_primary, .weui-cells_radio .weui-check:checked+.weui-icon-checked:before, .weui-icon-checked:before, .weui-agree__checkbox:checked:before, .weui-icon-success-circle, .weui-icon-success-no-circle, .weui-search-bar__cancel-btn, .weui-tabbar__item.weui-bar__item_on .weui-tabbar__icon, .weui-tabbar__item.weui-bar__item_on .weui-tabbar__icon>i, .weui-tabbar__item.weui-bar__item_on .weui-tabbar__label,.main_color,.weui-tabbar__item.weui-bar__item--on .weui-tabbar__label,.picker-button,.weui-form-preview__btn_primary {color:$hb_config[maincolor]!important}
.weui_bar__item_on span:after,.weui-btn_primary, .weui-btn_primary:not(.weui-btn_disabled):active,.weui-btn_mini,.x_header, .main_bg,.position li.current, .position1 li.current,.post-tags .tag-on.weui-btn_default,.is-green, .weui-slider__track,.tsbtn_m{background-color:$hb_config[maincolor]!important}.weui-navbar.filter_top .weui_bar__item_on i.icon-xiangxia,.weui-navbar.fix_float .weui_bar__item_on i.icon-xiangxia{border-color:$hb_config[maincolor] transparent transparent transparent}.weui-count .weui-count__increase, .weui-count .weui-count__btn:before,.weui-count .weui-count__btn:after{background:$hb_config[maincolor]}.weui-count .weui-count__increase:after, .weui-count .weui-count__increase:before{background:#fff}.weui-count .weui-count__btn{border-color:$hb_config[maincolor]}
</style><!--{if $diy}--><style>.card-mod._fgx{ min-height:45px!important }.card-mod.html,.card-mod.html .htmlw{min-height:45px!important;}</style><!--{/if}-->
    <script type="text/javascript" src="source/plugin/xigua_diy/static/js/jquery.min.js?{VERHASH}"></script><script>var IN_WECHAT = '{DIY_INWECHAT}',  UID = '{$_G[uid]}', FORMHASH = '{FORMHASH}';var loading = false, page = 1, _APPNAME = '{$SCRITPTNAME}', scrollto =0;var  _URLEXT = '{$_G[cookie][URLEXT]}{$urlext}', GSITE='{$_G[siteurl]}', ISADMINID = 0;<!--{if $pageinfo[icon]}-->var customImg = '{$pageinfo[icon]}';<!--{/if}--></script>
</head>
<body>