<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{template xigua_diy:touch/header}-->
<div id="root">
    <ul class="wrap" id="wrap">
        <!--{loop $cards $_id $_card}-->
<!--{eval
    if(!$card):
        continue;
    endif;
    if(!defined('IN_DIY') && getcookie('close_' . $card['id'])):
        continue;
    endif;
}-->
        <!--{if $_card[template]}-->
        <!--{eval include template('xigua_diy:touch/'.$_card[template]);}-->
        <!--{else}-->
        <li class="card-mod {$_card[type]}" id="{$_id}" data-id="{$_card[id]}">{$_card[html]}</li>
        <!--{/if}-->
        <!--{/loop}-->
</ul>
</div>
<!--{template xigua_diy:touch/footer}-->