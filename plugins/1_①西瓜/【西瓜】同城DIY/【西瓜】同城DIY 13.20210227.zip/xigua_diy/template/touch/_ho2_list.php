<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $k $v}-->
<div class="weui-cell need_list aib jump_need" data-id="{$v[id]}" data-lat="$v[lat]" data-lng="$v[lng]" data-addr="$v[addr]" data-title="{$v[title]}">
    <div class="weui-cell__hd">
        <img src="{echo $v[album][0]?$v[album][0]: avatar($v['uid'], 'middle', true)}" onerror="this.error=null;this.src='source/plugin/xigua_ho/static/img/dft.png'" />
        <span class="btnsha">{$short_need_types[$v[type]]}</span>
    </div>
    <div class="weui-cell__bd">
        <h4>{$v[title]}<!--{if $v[is_dig]}-->
            <span class="jbtn is_dig pr-1">{lang xigua_ho:dig}</span>
            <!--{/if}-->
            <!--{if $v[bxtype]>0}-->
            <em class="f12"><i class="iconfont icon-yanzheng color-good f12"></i>{lang xigua_ho:ytb}</em>
            <!--{/if}-->
            <!--{if $v[type]=='yikou'}-->
            <!--{if $v[distance]}-->
            <span class="pcfiled">$v[distance] <em class="priceText">&yen;{echo floatval($v[totalprice]);}</em></span>
            <!--{else}-->
            <span class="pcfiled">{lang xigua_ho:yzf} <em class="priceText">&yen;{echo floatval($v[totalprice]);}</em></span>
            <!--{/if}-->
            <!--{else}-->
            <!--{if $v[distance]}-->
            <span class="pcfiled">$v[distance]</span>
            <!--{elseif $v[status]!=4}-->
            <span class="pcfiled"><em class="priceText">{lang xigua_ho:dbj}</em></span>
            <!--{/if}-->
            <!--{/if}--></h4>
        <div class="cl need_list_desc">
            <!--{if !$v[vars]}-->
            <p><span class="c8">{lang xigua_ho:xqms}: </span> {$v[description]}</p>
            <!--{if $v[addr]}-->
            <p><span class="c8">{lang xigua_ho:lxaddr}: </span> {$v[city]}{$v[addr]}</p>
            <!--{/if}-->
            <!--{else}-->
            <!--{loop $v[vars] $_k $_v}-->
            <p><span class="c8">{$_v[title]}: </span> {$_v[html]}</p>
            <!--{/loop}-->
            <!--{/if}-->
            <p><span class="c8">{lang xigua_ho:sfyq}: </span> {$alllevels[$v['level']]['name']}</p>
            <!--{if $_GET['orderby']=='newest'}-->
            <p class="shifu_jingyan c8">{$v[crts_u]} {lang xigua_ho:fabu}</p>
            <!--{/if}-->
        </div>
        <!--{if $v[status]==2}-->
        <!--{if $need_check[$v[id]]}-->
        <a class="xq_btn main_bg jump_need op6" data-id="{$v[id]}" href="javascript:;">{lang xigua_ho:yq}</a>
        <!--{else}-->
        <a class="xq_btn main_bg jump_need" data-id="{$v[id]}" href="javascript:;">{lang xigua_ho:qd}</a>
        <!--{/if}-->
        <!--{else}-->
        <a class="xq_btn main_bg jump_need op6" data-id="{$v[id]}" href="javascript:;">{$need_status[$v[status]]}</a>
        <!--{/if}-->
    </div>
</div>
<!--{/loop}-->