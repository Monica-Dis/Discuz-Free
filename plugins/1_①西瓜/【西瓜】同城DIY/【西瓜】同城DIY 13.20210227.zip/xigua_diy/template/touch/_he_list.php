<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{if $_GET[qgys]==1}-->
<!--{loop $list $v}-->
<li class="index_re_List border_bottom<!--{if $v[hasend]||$v[bhasend]}--> op6<!--{/if}-->">
    <!--{if $v[hasend]||$v[bhasend]}--><div class="hd_complete"></div><!--{/if}-->
    <a class="index_new_wap_list jump_he" href="javascript:" data-id="{$v[id]}" >
        <div class="c">
            <div class="index_re_List_Pic dt_content_pic">
                <fieldset >
                    <img src="{echo $v[fengmian] ? $v[fengmian]: $v[album][0]}" alt="{$v[title]}">
                </fieldset>
            </div>
        </div>

        <div class="b">
            <div class="index_re_List_Txt">
                <h4 class="index_re_List_Tittle">
                    <span>{$v[title]}</span>
                </h4>
                <div class="index_re_List_timeQu">
                    <p class="index_re_List_time">{$v[start_u]} {lang xigua_he:ks}</p>
                    <!--{if $v[dist]}--><p>{$v[dist]}</p><!--{/if}-->
                </div>
                <div class="index_re_list_plus">
                    <!--{if $v[hkpricerange]}-->
                    <p class="lis_hksp">{$_G['cache']['plugin']['xigua_hk']['cardname']}{lang xigua_he:jia}{$v[hkpricerange]}{lang xigua_he:yuan}</p>
                    <!--{elseif $v[pricerange] && $v[allow_tk]}-->
                    <span class="hb_tag">{lang xigua_he:zctk}</span>
                    <!--{elseif $v['srange_ary']}-->
                    <!--{loop $v['srange_ary'] $_v}-->
                    <span class="hb_tag">$_v</span>
                    <!--{/loop}-->
                    <!--{/if}-->
                </div>
                <div class="index_re_list_price">
                    <p class="index_re_List_join main_color2"><em><!--{if $v[pricerange]}-->&yen;{$v[pricerange]}<!--{else}-->{lang xigua_he:mf}<!--{/if}--></em></p>
                </div>
                <div class="index_re_List_tip">
                    <!--{if $v[hasend]}-->
                    {lang xigua_he:hdyjs}
                    <!--{elseif $v[bhasend]}-->
                    {lang xigua_he:bmyjs}
                    <!--{elseif $v[bstarttime]>=TIMESTAMP && $v[bendtime]<TIMESTAMP}-->
                    {lang xigua_he:bmjjz}
                    <!--{else}-->
                    <!--{if $v[jz]}-->
                    {lang xigua_he:gyjk}
                    <!--{else}-->
                    <!--{if $v[pricerange]}-->{lang xigua_he:lj}<!--{else}-->{lang xigua_he:mf}<!--{/if}-->{lang xigua_he:bm}
                    <!--{/if}-->
                    <!--{/if}-->
                </div>
            </div>
        </div>
    </a>
</li>
<!--{/loop}-->
<!--{elseif $_GET[qgys]==3}-->
<!--{loop $list $tuijian_hd}-->
<li class="index_recomlist" >
    <a class="jump_he" href="javascript:" data-id="{$tuijian_hd[id]}">
        <div class="listTop">
            <img src="{echo $tuijian_hd[fengmian] ? $tuijian_hd[fengmian]: $tuijian_hd[album][0]}">
        </div>
        <div class="listBottom">
            <div class="partyTitlt"><span><em class="jxuan">{lang xigua_he:jx}</em> {$tuijian_hd[title]}</span></div>
            <div class="partyDate">{echo substr($tuijian_hd[start_u], 5, 5)} {lang xigua_he:ks}</div>
            <div class="partyAddress main_color">
                <p><!--{if $tuijian_hd[pricerange]}-->&yen;{$tuijian_hd[pricerange]}<!--{else}-->{lang xigua_he:mf}<!--{/if}--></p>
            </div>
        </div>
    </a>
</li>
<!--{/loop}-->
<!--{/if}-->