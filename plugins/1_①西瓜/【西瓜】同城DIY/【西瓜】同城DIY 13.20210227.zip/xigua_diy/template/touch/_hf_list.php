<?php exit('Author: https://dism.taobao.com/?@xigua �������� �ͷ�QQ 1628585958'); ?>
<!--{loop $list $v}-->
<div class="hf_item" id="li_{$v['qunid']}">
    <div class="sp_thumb hf_jump" data-id="{$v['qunid']}">
        <img src="{$v['logo']}" onerror="this.error=null;this.src='source/plugin/xigua_hf/static/img/new.png'">
    </div>
    <div class="sp_main">
        <div class="sp_content hf_jump" data-id="{$v['qunid']}">
            <div class="weui-flex">
                <h3 class="weui-flex__item"><!--{if $v[dig]}--><em class="is-star dig_tag">{lang xigua_hf:dig}</em> <!--{/if}--><!--{if $v[shid]}--><em class="is-blue dig_tag">{lang xigua_hf:dian}</em> <!--{/if}--><!--{if $v[tuijian]}--><em class="is-red dig_tag">{lang xigua_hf:jian}</em> <!--{/if}--><!--{if $v[video]}--><em class="is-green dig_tag"><i class="iconfont icon-shipin f12"></i></em> <!--{/if}--><!--{if $v[shoufei]}--><em class="is-orange dig_tag"><i class="iconfont icon-qiandai f12"></i></em> <!--{/if}-->{$v['name']} <!--{if $v[end]}--><em class="hs_tag"><i class="iconfont icon-jubao c9 f12"> {lang xigua_hf:guoqi}</i></em><!--{/if}--></h3>
            </div>
            <!--{if $hf_config[jianhua]}-->
            <p class="sp_desc c9 jianghua">{echo strip_tags($v[jieshao]);}</p>
            <!--{else}-->
            <p class="sp_desc sp_tag">
                <!--{loop $v[jineng_str_ary] $hy1}-->
                <span class="hf_tag main_color">{$hy1}</span>
                <!--{/loop}-->
            </p>
            <p class="sp_desc c9">{echo $v[xuzhi] ?$v[xuzhi] : strip_tags($v[jieshao]);}</p>
            <!--{/if}-->
        </div>
    </div>
    <!--{if $viewtype =='near' && $v[lng]}-->
    <span class="li_location tag-gray" >{$v[distance]}</span>
    <!--{elseif $viewtype =='guanzhu'}-->
    <span class="li_location none" >{echo hb_trans($v[follow])}{lang xigua_hf:guanzhu}</span>
    <!--{elseif $viewtype =='fenxiang'}-->
    <span class="li_location none" >{echo hb_trans($v[shares])}{lang xigua_hf:fenxiang}</span>
    <!--{else}-->
    <span class="li_location <!--{if !$_GET[is_my]}-->none<!--{/if}-->" >{echo hb_trans($v[views])}{lang xigua_hf:view}</span>
    <!--{/if}-->
    <!--{if $qunids_ary[$v[qunid]]}-->
    <span class="c9 f12 titime">{echo date('Y-m-d H:i:s', $qunids_ary[$v[qunid]][crts])}</span>
    <!--{else}-->
    <a class="weui-btn weui-btn_mini whbtn2 hf_jump" data-id="{$v['qunid']}" href="javascript:;">{lang xigua_hf:shenqing}</a>
    <!--{/if}-->
</div>
<!--{/loop}-->